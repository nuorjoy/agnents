/// <reference types="bun-types" />
/**
 * Ashrilogic — security regression test setup (Task 4).
 *
 * DB ISOLATION: every test that touches Prisma runs against a THROWAWAY
 * PostgreSQL test database (TEST_DATABASE_URL — default
 * postgresql://postgres@localhost:5433/ashrilogic_security_test) — never
 * the live dev database. The test database is reset to a clean schema
 * state once per test process (module-level guard on globalThis so it
 * survives per-file module registries); tests in the SAME process share
 * the database, a fresh process starts from a clean state (the same
 * semantics the throwaway db/security-test.db file carried in the SQLite
 * era). The reset uses `prisma db push --force-reset`, which DROPS ALL
 * DATA — correct for a dedicated throwaway database, catastrophic for
 * anything else, hence the name guard below.
 *
 * ENV CONTROL: NODE_ENV=development + demo secrets are (re)installed BEFORE
 * the first dynamic `import()` of any env-binding module (tokens.ts,
 * crypto-vault.ts, @/lib/db) — top-level static imports would bind module
 * state too early. Call ensureDemoEnv() (or getTestDb()) before importing.
 *
 * LIVE-SUITE helpers (resolveServerDatabaseUrl / serverPg / closeServerPg):
 * the LIVE suites provision and clean the DEV SERVER's database — the role
 * db/custom.db played in the SQLite era — reached through the DATABASE_URL
 * the battery's dev.sh-started server shares with the test process.
 */
import { execSync } from "node:child_process";
import { join } from "node:path";
import type { Client } from "pg";
import type { PrismaClient } from "@prisma/client";

/** Repository root (this file lives in tests/security/). */
export const REPO_ROOT = join(import.meta.dir, "..", "..");

/** Throwaway test database — NEVER the live dev database (ashrilogic_dev)
 *  or any production database. Overridable via TEST_DATABASE_URL for
 *  purpose-built environments (the battery / CI set it explicitly). */
export const TEST_DATABASE_URL =
  process.env.TEST_DATABASE_URL ?? "postgresql://postgres@localhost:5433/ashrilogic_security_test";

/** The test database's NAME, parsed from TEST_DATABASE_URL — the isolation
 *  canary compares the bound connection's current_database() against it. */
const TEST_DATABASE_NAME = (() => {
  if (!/^postgres(ql)?:\/\//i.test(TEST_DATABASE_URL)) {
    throw new Error(
      `TEST_DATABASE_URL must be a PostgreSQL connection string ("postgres://…"), got: ${TEST_DATABASE_URL}`
    );
  }
  const name = decodeURIComponent(
    new URL(TEST_DATABASE_URL).pathname.split("/").filter(Boolean).pop() ?? ""
  );
  if (!name) {
    throw new Error(
      `TEST_DATABASE_URL must carry a database name in its path, got: ${TEST_DATABASE_URL}`
    );
  }
  return name;
})();

/* FAIL-CLOSED NAME GUARD: the reset below drops every table in the target
 * database. A TEST_DATABASE_URL pointed at the live dev database or at any
 * production-shaped name must never get that far.
 *
 * ROUND 171 HARDENING — the guard previously matched only /prod/i and the
 * exact dev name; a cloud-managed default such as "neondb" slipped through
 * BOTH patterns and a real force-reset wiped it. The database NAME must now
 * explicitly declare itself a test database (contains "test", matching the
 * documented default "ashrilogic_security_test" and every purpose-built
 * throwaway naming convention). */
if (
  /prod/i.test(TEST_DATABASE_NAME) ||
  /^ashrilogic_dev$/i.test(TEST_DATABASE_NAME) ||
  !/test/i.test(TEST_DATABASE_NAME)
) {
  throw new Error(
    `SECURITY-TEST ISOLATION BROKEN: TEST_DATABASE_URL points at "${TEST_DATABASE_NAME}" — ` +
      "the test harness force-resets its target database, so it must be a dedicated throwaway " +
      "test database whose name explicitly contains \"test\" (the default is " +
      "ashrilogic_security_test), never the live dev database, a production one, or a " +
      "cloud-default database name."
  );
}

type DbModule = typeof import("@/lib/db");
export type TestDb = DbModule["db"];

/** once-per-process flag (globalThis survives per-file module registries) */
const SETUP_FLAG = "__ashrilogicSecurityTestDbSetup";

/**
 * Bind the DEMO environment (development mode, no provisioned secrets,
 * isolated DATABASE_URL) BEFORE importing any env-binding module.
 */
export function ensureDemoEnv(): void {
  // Next's type augmentation declares NODE_ENV readonly at the TYPE level
  // (it is a plain writable property at runtime) — write through a
  // explicitly-writable view instead of weakening typing elsewhere.
  (process.env as { NODE_ENV?: string }).NODE_ENV = "development";
  // demo fallbacks active — no operator-provisioned secrets in tests
  delete process.env.ADMIN_SESSION_SECRET;
  delete process.env.LEGACY_SESSION_SECRET;
  delete process.env.ASHRILOGIC_DATA_KEY;
  // isolated database — never the live dev database
  process.env.DATABASE_URL = TEST_DATABASE_URL;
}

/** Reset the throwaway test database to a clean schema state once per test
 *  process. `--force-reset` drops every table and recreates the schema
 *  from prisma/schema.prisma (non-interactive); tests in the same process
 *  share the state, a new process starts clean — identical semantics to
 *  the old throwaway-file deletion. */
function pushSchemaOnce(): void {
  const g = globalThis as Record<string, unknown>;
  if (g[SETUP_FLAG]) return;
  g[SETUP_FLAG] = true;
  execSync("bunx prisma db push --force-reset --skip-generate --schema prisma/schema.prisma", {
    cwd: REPO_ROOT,
    stdio: "pipe",
    env: { ...process.env, DATABASE_URL: TEST_DATABASE_URL },
  });
}

/**
 * Dynamic import of the Prisma client AFTER the env override — the returned
 * client is bound to the throwaway test database.
 *
 * ISOLATION CANARY: a test file that STATICALLY imports a module
 * transitively binding `@/lib/db` hoists that import ABOVE this file's
 * ensureDemoEnv() call — the Prisma singleton then binds to the live
 * DATABASE_URL (the DEV SERVER's database, e.g. ashrilogic_dev) and every
 * suite read/write silently targets live data. The canary resolves the
 * connection's ACTUAL database via `SELECT current_database()` and fails
 * LOUDLY at setup when it is not the throwaway test database.
 */
export async function getTestDb(): Promise<TestDb> {
  ensureDemoEnv();
  pushSchemaOnce();
  const mod: DbModule = await import("@/lib/db");
  try {
    const rows = (await mod.db.$queryRawUnsafe(
      "SELECT current_database() AS name"
    )) as { name: string }[];
    const bound = rows[0]?.name ?? "";
    if (bound !== TEST_DATABASE_NAME) {
      throw new Error(
        `SECURITY-TEST ISOLATION BROKEN: the Prisma singleton is bound to database "${bound}" instead of the throwaway test database "${TEST_DATABASE_NAME}". ` +
          "A static import hoisted above ensureDemoEnv() captured the live DATABASE_URL before the test override. " +
          "Fix: import db-binding modules DYNAMICALLY in beforeAll (the canonical pattern — see coupon-identity.test.ts)."
      );
    }
  } catch (error) {
    if (error instanceof Error && error.message.includes("ISOLATION BROKEN")) throw error;
    /* current_database() unavailable — the connection itself is broken and
       the suite's first query fails loudly with the real cause; do not turn
       an engine quirk into a false isolation alarm */
  }
  return mod.db;
}

/** Clear every rate-limit hit so each test starts with a clean window. */
export async function resetRateTable(db: TestDb): Promise<void> {
  await db.rateLimitHit.deleteMany({});
}

/* -------------------------------------------------------------------------- */
/* LIVE-SUITE helpers — the DEV SERVER's PostgreSQL database                   */
/* -------------------------------------------------------------------------- */

/* DATABASE_URL inherited from the launching environment, captured at this
 * module's FIRST evaluation. bun test gives every test file its own module
 * registry, so a plain top-level const would RE-CAPTURE in file 2+ — after
 * file 1's ensureDemoEnv() already rebound it to the test database — hence
 * the globalThis memo. The battery (and .zscripts/dev.sh) start the dev
 * server from this same environment, shell env first and .env second,
 * exactly like `next dev` resolves it, so this is the database the live
 * suites must provision and clean. */
const INHERITED_URL_FLAG = "__ashrilogicInheritedDatabaseUrl";
const inheritedMemo = globalThis as Record<string, unknown>;
if (typeof inheritedMemo[INHERITED_URL_FLAG] !== "string") {
  inheritedMemo[INHERITED_URL_FLAG] = process.env.DATABASE_URL;
}
const INHERITED_DATABASE_URL = inheritedMemo[INHERITED_URL_FLAG] as string | undefined;

/**
 * Resolve the LIVE dev server's database URL (the role db/custom.db played
 * in the SQLite era). ASHRILOGIC_LIVE_DATABASE_URL wins (explicit override
 * for environments whose server runs on a URL not visible to the test
 * shell), then the inherited DATABASE_URL. Throws with operator guidance
 * when neither resolves to a PostgreSQL URL — call it lazily (inside
 * helpers / beforeAll), never at module top level, so a suite whose live
 * block is skipped (server down) never errors at import time.
 */
export function resolveServerDatabaseUrl(): string {
  const url = (process.env.ASHRILOGIC_LIVE_DATABASE_URL ?? INHERITED_DATABASE_URL ?? "").trim();
  if (!/^postgres(ql)?:\/\//i.test(url)) {
    throw new Error(
      `LIVE-SUITE DB UNRESOLVED: the dev server's PostgreSQL DATABASE_URL is not available to this test process ` +
        `(expected "postgres://…", got ${url ? `"${url}"` : "nothing"}). ` +
        "The live suites provision and clean the SAME database the :3000 dev server uses. " +
        "Start the environment via `bash .zscripts/dev.sh` from a shell with DATABASE_URL exported " +
        "(or set ASHRILOGIC_LIVE_DATABASE_URL), then rerun the suite."
    );
  }
  return url;
}

/** A lazily-connected pg Client bound to the dev server's database, shared
 *  per test process (a PostgreSQL connection carries a TCP + auth
 *  handshake, so the live suites reuse ONE client instead of reopening per
 *  query the way the SQLite-era file opens did). Resolve failures surface
 *  to the caller — the suites' lenient cleanup paths already handle them. */
export async function serverPg(): Promise<Client> {
  const g = globalThis as { __ashrilogicServerPg?: Client };
  if (g.__ashrilogicServerPg) return g.__ashrilogicServerPg;
  const { Client } = await import("pg");
  const client = new Client({ connectionString: resolveServerDatabaseUrl() });
  await client.connect();
  g.__ashrilogicServerPg = client;
  return client;
}

/** Close the shared live-suite pg connection (call from afterAll). */
export async function closeServerPg(): Promise<void> {
  const g = globalThis as { __ashrilogicServerPg?: Client };
  const client = g.__ashrilogicServerPg;
  g.__ashrilogicServerPg = undefined;
  if (client) await client.end().catch(() => undefined);
}

/** A Prisma client bound to the dev server's database for the live suites
 *  (the old suites hard-coded file:db/custom.db here), constructed lazily
 *  for the same skip-safety reason as resolveServerDatabaseUrl(). Pair
 *  with closeServerPrisma() in afterAll. */
export async function serverPrisma(): Promise<PrismaClient> {
  const g = globalThis as { __ashrilogicServerPrisma?: PrismaClient };
  if (g.__ashrilogicServerPrisma) return g.__ashrilogicServerPrisma;
  const { PrismaClient } = await import("@prisma/client");
  const client = new PrismaClient({ datasourceUrl: resolveServerDatabaseUrl() });
  g.__ashrilogicServerPrisma = client;
  return client;
}

/** Disconnect the shared live-suite Prisma client (call from afterAll). */
export async function closeServerPrisma(): Promise<void> {
  const g = globalThis as { __ashrilogicServerPrisma?: PrismaClient };
  const client = g.__ashrilogicServerPrisma;
  g.__ashrilogicServerPrisma = undefined;
  if (client) await client.$disconnect().catch(() => undefined);
}

/* ROUND 124 — demo-admin password candidates for the LIVE suites.
 *
 * The live suites authenticate against the demo DB's `admin` account, but
 * WHICH password that account carries depends on how the environment was
 * provisioned: `seed-demo` installs the original demo secret
 * (`ashrilogic2024`), while some previously delivered demo databases were
 * bootstrapped with a stronger private credential
 * (`AshriAdmin#2025$ecure` — a dev/test fixture ONLY; production passwords
 * are provisioned via scripts/bootstrap-admin.ts and never live in
 * source). A suite that hard-codes either one
 * breaks the moment the environment is rebuilt the other way (found live:
 * plan-assignment asserting 200 for the seed password against the
 * delivered DB). The candidates are tried IN ORDER under the same rate
 * window (admin login allows 10 per 10 min per ip+username — two attempts
 * are safe), first 200 wins. `ASHRILOGIC_TEST_ADMIN_PASSWORD` overrides
 * everything (for batteries against purpose-built environments). */
export const ADMIN_LOGIN_CANDIDATES: string[] = [
  process.env.ASHRILOGIC_TEST_ADMIN_PASSWORD,
  "AshriAdmin#2025$ecure",
  "ashrilogic2024",
].filter((p): p is string => typeof p === "string" && p.length > 0);

/**
 * Log in as the demo `admin` account, trying every documented candidate
 * password. Returns the FIRST 200 response (session cookie already in the
 * jar), or the LAST response when every candidate failed (so callers can
 * assert a specific failure shape instead of getting an exception).
 *
 * `jfetch` is the suite's own cookie-jar fetch (each live suite defines a
 * slightly different signature — the generic keeps this dependency-free).
 */
export async function loginDemoAdmin<J>(
  jfetch: (path: string, jar: J, method: string, body?: string) => Promise<Response>,
  jar: J
): Promise<Response> {
  let last: Response | undefined;
  for (const password of ADMIN_LOGIN_CANDIDATES) {
    const res = await jfetch(
      "/api/admin/login",
      jar,
      "POST",
      JSON.stringify({ username: "admin", password })
    );
    if (res.status === 200) return res;
    last = res;
  }
  if (!last) throw new Error("ADMIN_LOGIN_CANDIDATES is empty — cannot log in");
  return last;
}
