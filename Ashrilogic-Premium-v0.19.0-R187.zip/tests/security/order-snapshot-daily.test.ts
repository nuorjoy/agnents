/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — order-item image snapshots + daily sales (ROUND 54).
 *
 * Pins under test:
 *  - `snapshotImage` accepts ONLY the managed image-ref shape
 *    (`/api/images/<64 lowercase hex>`): javascript:/data: URLs, traversal,
 *    absolute origins, uppercase hex, non-strings and oversized values all
 *    degrade to undefined — a tampered or legacy row can never push a
 *    hostile value into an <img src> through the snapshot read path;
 *  - `parseOrderSnapshot` reads v2 envelopes (with optional image), legacy
 *    v1 bare arrays, drops malformed entries, caps at 20 items and never
 *    throws on malformed JSON (totals still carry the value elsewhere);
 *  - `aggregateDailySales` buckets by LOCAL calendar day with an injectable
 *    `now`, excludes cancelled and future-dated orders, always returns
 *    exactly `days` zero-filled buckets, and clamps absurd window sizes.
 */
import { describe, test, expect } from "bun:test";
import { parseOrderSnapshot, snapshotImage } from "@/lib/server/order-snapshot";
import { aggregateDailySales } from "@/lib/store-analytics";
import type { SiteOrderAdminDTO, SiteOrderStatus } from "@/lib/types";

const REF = "/api/images/" + "a".repeat(64);

describe("snapshotImage — managed-ref shape guard", () => {
  test("accepts a canonical managed ref", () => {
    expect(snapshotImage(REF)).toBe(REF);
  });
  test("accepts a different sha256 hex digest verbatim", () => {
    const ref = "/api/images/" + "0123456789abcdef".repeat(4);
    expect(snapshotImage(ref)).toBe(ref);
  });
  test("rejects javascript: URLs", () => {
    expect(snapshotImage("javascript:alert(1)")).toBeUndefined();
  });
  test("rejects data: URLs", () => {
    expect(snapshotImage("data:image/png;base64,AAAA")).toBeUndefined();
  });
  test("rejects traversal payloads", () => {
    expect(snapshotImage("/api/images/../../../etc/passwd")).toBeUndefined();
    expect(snapshotImage("../../secret")).toBeUndefined();
  });
  test("rejects absolute origins (open-redirect / SSRF surface)", () => {
    expect(snapshotImage("https://evil.example/pic.png")).toBeUndefined();
    expect(snapshotImage("//evil.example/pic.png")).toBeUndefined();
  });
  test("rejects uppercase hex and short hashes", () => {
    expect(snapshotImage("/api/images/" + "A".repeat(64))).toBeUndefined();
    expect(snapshotImage("/api/images/abc")).toBeUndefined();
  });
  test("rejects non-strings and oversized values", () => {
    expect(snapshotImage(undefined)).toBeUndefined();
    expect(snapshotImage(null)).toBeUndefined();
    expect(snapshotImage(12345)).toBeUndefined();
    expect(snapshotImage({ toString: () => REF })).toBeUndefined();
    expect(snapshotImage(REF + "x".repeat(40))).toBeUndefined();
  });
});

describe("parseOrderSnapshot — defensive snapshot reads", () => {
  test("v2 envelope with images parses fully", () => {
    const items = [
      { recordId: "r1", name: "A", price: 12000, qty: 2, image: REF },
      { recordId: "r2", name: "B", price: 500, qty: 1 },
    ];
    const { items: parsed, legacy } = parseOrderSnapshot(
      JSON.stringify({ v: 2, items })
    );
    expect(legacy).toBe(false);
    expect(parsed).toEqual(items);
  });
  test("a hostile image field inside a v2 envelope degrades to no image", () => {
    const { items } = parseOrderSnapshot(
      JSON.stringify({
        v: 2,
        items: [
          { recordId: "r1", name: "A", price: 1, qty: 1, image: "javascript:alert(1)" },
          { recordId: "r2", name: "B", price: 1, qty: 1, image: "/api/images/" + "A".repeat(64) },
        ],
      })
    );
    expect(items[0].image).toBeUndefined();
    expect(items[1].image).toBeUndefined();
  });
  test("legacy v1 bare array parses with legacy=true (prices stay display units)", () => {
    const { items, legacy } = parseOrderSnapshot(
      JSON.stringify([{ recordId: "r1", name: "A", price: 12.5, qty: 1 }])
    );
    expect(legacy).toBe(true);
    expect(items.length).toBe(1);
    expect(items[0].price).toBe(12.5);
  });
  test("malformed entries are dropped, well-formed ones survive", () => {
    const { items } = parseOrderSnapshot(
      JSON.stringify({
        v: 2,
        items: [
          { recordId: "ok", name: "OK", price: 1, qty: 1 },
          null,
          "string-entry",
          { recordId: 5, name: "X", price: 1, qty: 1 },
          { recordId: "no-price", name: "X", qty: 1 },
          { recordId: "float-qty", name: "X", price: 1, qty: 1.5 },
        ],
      })
    );
    expect(items.length).toBe(1);
    expect(items[0].recordId).toBe("ok");
  });
  test("item list is capped at 20 (flood guard)", () => {
    const items = Array.from({ length: 40 }, (_, i) => ({
      recordId: `r${i}`,
      name: `N${i}`,
      price: 1,
      qty: 1,
    }));
    expect(parseOrderSnapshot(JSON.stringify({ v: 2, items })).items.length).toBe(20);
  });
  test("malformed JSON degrades to empty items (never throws)", () => {
    expect(parseOrderSnapshot("{not json").items).toEqual([]);
    expect(parseOrderSnapshot(undefined).items).toEqual([]);
    expect(parseOrderSnapshot(null).items).toEqual([]);
  });
  test("non-envelope objects degrade to empty items", () => {
    expect(parseOrderSnapshot(JSON.stringify({ v: 1, items: [] })).items).toEqual([]);
    expect(parseOrderSnapshot(JSON.stringify({ v: "2", items: [] })).items).toEqual([]);
    expect(parseOrderSnapshot(JSON.stringify({ v: 2, items: "nope" })).items).toEqual([]);
  });
});

/* ---------------------- daily sales (pure aggregation) ---------------------- */

function order(
  id: string,
  createdAt: string,
  status: SiteOrderStatus,
  total: number
): SiteOrderAdminDTO {
  return {
    id,
    code: null,
    items: [],
    total,
    discount: 0,
    couponCode: null,
    currency: "SAR",
    status,
    note: null,
    statusNote: null,
    statusHistory: [],
    createdAt,
    updatedAt: createdAt,
    customerId: "c1",
    customerName: "عميل",
  };
}

describe("aggregateDailySales", () => {
  /* local-time pin: the sandbox TZ does not matter — we pin `now` and the
   * bucketing is LOCAL-calendar, so construct instants with local
   * constructors (new Date(y, m, d, h)) rather than ISO-Z strings. */
  test("buckets orders into local calendar days with an injectable now", () => {
    const now = new Date(2026, 8, 15, 18, 0, 0); // 2026-09-15 18:00 local
    const buckets = aggregateDailySales(
      [
        order("o1", new Date(2026, 8, 15, 9, 0, 0).toISOString(), "completed", 100),
        order("o2", new Date(2026, 8, 14, 23, 30, 0).toISOString(), "completed", 50),
        order("o3", new Date(2026, 8, 14, 0, 30, 0).toISOString(), "completed", 30),
        order("o4", new Date(2026, 8, 1, 12, 0, 0).toISOString(), "completed", 999), // outside 14d
      ],
      3,
      now
    );
    expect(buckets.length).toBe(3);
    expect(buckets.map((b) => b.day)).toEqual(["2026-09-13", "2026-09-14", "2026-09-15"]);
    const today = buckets[2];
    const yesterday = buckets[1];
    expect(today.orders).toBe(1);
    expect(today.revenue).toBe(100);
    expect(yesterday.orders).toBe(2);
    expect(yesterday.revenue).toBe(80);
  });

  test("exactly `days` zero-filled buckets are always returned (the chart shows gaps)", () => {
    const buckets = aggregateDailySales([], 14);
    expect(buckets.length).toBe(14);
    expect(buckets.every((b) => b.orders === 0 && b.revenue === 0)).toBe(true);
  });

  test("cancelled orders are excluded", () => {
    const now = new Date(2026, 8, 15, 12, 0, 0);
    const buckets = aggregateDailySales(
      [
        order("o1", new Date(2026, 8, 15, 10, 0, 0).toISOString(), "completed", 100),
        order("o2", new Date(2026, 8, 15, 11, 0, 0).toISOString(), "cancelled", 400),
      ],
      1,
      now
    );
    expect(buckets[0].orders).toBe(1);
    expect(buckets[0].revenue).toBe(100);
  });

  test("future-dated rows are ignored (not signal)", () => {
    const now = new Date(2026, 8, 15, 12, 0, 0);
    const buckets = aggregateDailySales(
      [order("o1", new Date(2026, 8, 16, 10, 0, 0).toISOString(), "completed", 100)],
      1,
      now
    );
    expect(buckets[0].orders).toBe(0);
  });

  test("revenue is cent-rounded per bucket (float noise stays out)", () => {
    const now = new Date(2026, 8, 15, 12, 0, 0);
    /* 0.1 + 0.2 = 0.30000000000000004 in IEEE-754 — the bucket must
     * collapse that to a clean 0.3 display value */
    const buckets = aggregateDailySales(
      [
        order("o1", new Date(2026, 8, 15, 10, 0, 0).toISOString(), "completed", 0.1),
        order("o2", new Date(2026, 8, 15, 11, 0, 0).toISOString(), "completed", 0.2),
      ],
      1,
      now
    );
    expect(buckets[0].revenue).toBe(0.3);
  });

  test("window size clamps to [1, 90]", () => {
    expect(aggregateDailySales([], 0).length).toBe(1);
    expect(aggregateDailySales([], -5).length).toBe(1);
    expect(aggregateDailySales([], 91).length).toBe(90);
    expect(aggregateDailySales([], 1000).length).toBe(90);
  });
});
