/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — PUBLIC TRUSTED-SECTOR FEED (ROUND 164).
 *
 * Proves the «قيادات قطاعية تختار Ashrilogic» strip contract (GET /api/partners):
 *  - DYNAMIC: every visible curated row of a HEALTHY registered workspace is
 *    served straight from the database (added rows appear on the next read);
 *  - NO DUPLICATE SECTORS: at most ONE leader per sector — when several
 *    visible rows share a sector, only the first in the curated order
 *    (sortOrder, then createdAt) shows;
 *  - HEALTH GATE: invisible rows, soft-deleted (trashed) workspaces,
 *    permanently-banned, temporarily-banned (future bannedUntil), and
 *    owner-disabled workspaces NEVER showcase as sector leaders;
 *  - IDENTITY LAW: the console's display override wins; an empty override
 *    falls back to the LIVE org name from orgJson; `since` carries the
 *    workspace's real registration date;
 *  - fail-open: the endpoint always answers HTTP 200 `{partners:[…]}`.
 *
 * DB isolation: throwaway PostgreSQL test database via test-setup (never the live DB).
 */

import { beforeAll, afterAll, describe, expect, test } from "bun:test";
import { getTestDb, type TestDb } from "./test-setup";

const RUN = Math.random().toString(36).slice(2, 8);

let db: TestDb;
let route: typeof import("@/app/api/partners/route");
let mapper: typeof import("@/lib/server/instance-mapper");

/** fixture ids — cleaned in afterAll */
const INSTANCE_IDS = [
  `inst-health-a-${RUN}`,
  `inst-health-b-${RUN}`,
  `inst-retail-${RUN}`,
  `inst-legal-hidden-${RUN}`,
  `inst-edu-trashed-${RUN}`,
  `inst-finance-banned-${RUN}`,
  `inst-services-disabled-${RUN}`,
  `inst-media-tempban-${RUN}`,
];
const PARTNER_IDS: string[] = [];

async function makeInstance(id: string, orgName: string, extra: Record<string, unknown> = {}): Promise<string> {
  const sealed = mapper.sealAdminSection({
    name: "مالك",
    email: `${id}@partners.test`,
    role: "owner",
    twoFA: false,
  });
  await db.instance.create({
    data: {
      id,
      systemId: "health",
      orgJson: JSON.stringify({
        name: orgName,
        country: "SA",
        currency: "SAR",
        timezone: "Asia/Riyadh",
        address: "عنوان الاختبار",
        phone: `+96656${String(Math.floor(Math.random() * 1e8)).padStart(8, "0")}`,
      }),
      adminJson: sealed.adminJson,
      adminEmailIndex: sealed.adminEmailIndex,
      prefsJson: JSON.stringify({ lang: "ar", theme: "light", notif: true, backup: true, audit: true, demo: false }),
      modulesJson: JSON.stringify(["pos"]),
      ...extra,
    },
  });
  return id;
}

async function makePartner(
  id: string,
  instanceId: string,
  sector: string,
  opts: { visible?: boolean; sortOrder?: number; nameAr?: string; nameEn?: string } = {}
): Promise<string> {
  await db.sectorPartner.create({
    data: {
      id,
      instanceId,
      sector,
      icon: "building",
      c1: "#6d5dfb",
      c2: "#06b6d4",
      visible: opts.visible ?? true,
      sortOrder: opts.sortOrder ?? 0,
      nameAr: opts.nameAr ?? "",
      nameEn: opts.nameEn ?? "",
    },
  });
  PARTNER_IDS.push(id);
  return id;
}

beforeAll(async () => {
  db = await getTestDb();
  await db.sectorPartner.deleteMany({});
  await db.instance.deleteMany({});
  route = await import("@/app/api/partners/route");
  mapper = await import("@/lib/server/instance-mapper");

  /* healthy leaders */
  await makeInstance(INSTANCE_IDS[0], "مستشفى النخبة");
  await makeInstance(INSTANCE_IDS[1], "عيادات الرياض");
  await makeInstance(INSTANCE_IDS[2], "متجر المستقبل");
  await makeInstance(INSTANCE_IDS[3], "مكتب المحاسبة");
  /* unhealthy workspaces — never showcase */
  await makeInstance(INSTANCE_IDS[4], "جامعة مهجورة", { deletedAt: new Date() });
  await makeInstance(INSTANCE_IDS[5], "صندوق محظور", { bannedPermanently: true });
  await makeInstance(INSTANCE_IDS[6], "مكتب معطّل", { disabledAt: new Date() });
  await makeInstance(INSTANCE_IDS[7], "قناة موقوفة مؤقتاً", {
    bannedUntil: new Date(Date.now() + 24 * 60 * 60 * 1000),
  });

  /* curated showcase rows (visible unless stated) */
  await makePartner(`sp-health-b-${RUN}`, INSTANCE_IDS[1], "health", { sortOrder: 2, nameAr: "عيادات الرياض" });
  await makePartner(`sp-health-a-${RUN}`, INSTANCE_IDS[0], "health", { sortOrder: 1 });
  await makePartner(`sp-retail-${RUN}`, INSTANCE_IDS[2], "retail", { sortOrder: 3, nameAr: "متجر النخبة" });
  /* an invisible row on a distinct sector — the visibility gate filters it */
  await makePartner(`sp-legal-hidden-${RUN}`, INSTANCE_IDS[3], "legal", { visible: false, sortOrder: 0 });
  await makePartner(`sp-edu-${RUN}`, INSTANCE_IDS[4], "education", { sortOrder: 4 });
  await makePartner(`sp-finance-${RUN}`, INSTANCE_IDS[5], "finance", { sortOrder: 5 });
  await makePartner(`sp-services-${RUN}`, INSTANCE_IDS[6], "services", { sortOrder: 6 });
  await makePartner(`sp-media-${RUN}`, INSTANCE_IDS[7], "media", { sortOrder: 7 });
});

afterAll(async () => {
  try {
    await db.sectorPartner.deleteMany({});
    await db.instance.deleteMany({});
  } catch {
    /* throwaway DB */
  }
});

interface FeedPartner {
  id: string;
  nameAr: string;
  nameEn: string;
  sector: string;
  since: string;
}

async function fetchFeed(): Promise<FeedPartner[]> {
  const res = await route.GET();
  expect(res.status).toBe(200);
  const body = (await res.json()) as { partners: FeedPartner[] };
  return body.partners;
}

describe("GET /api/partners — the dynamic sector-leaders feed", () => {
  test("serves exactly the healthy visible leaders — HTTP 200", async () => {
    const partners = await fetchFeed();
    /* health ×2 curated → only the top-ranked one; retail ×1 visible (the
     * hidden retail row never counts); trashed/banned/disabled/temp-banned
     * rows are all filtered → exactly 2 leaders. */
    expect(partners.length).toBe(2);
  });

  test("NO duplicate sectors — one leader card per sector", async () => {
    const partners = await fetchFeed();
    const sectors = partners.map((p) => p.sector);
    expect(sectors.length).toBe(new Set(sectors).size);
    expect(sectors).toEqual(["health", "retail"]);
  });

  test("the top-ranked entry of a repeated sector wins (curated order)", async () => {
    const partners = await fetchFeed();
    const health = partners.find((p) => p.sector === "health");
    expect(health?.id).toBe(`sp-health-a-${RUN}`);
  });

  test("identity law: empty override falls back to the LIVE org name", async () => {
    const partners = await fetchFeed();
    const health = partners.find((p) => p.sector === "health");
    expect(health?.nameAr).toBe("مستشفى النخبة");
    expect(health?.nameEn).toBe("مستشفى النخبة");
  });

  test("identity law: the console display override wins when set", async () => {
    const partners = await fetchFeed();
    const retail = partners.find((p) => p.sector === "retail");
    expect(retail?.nameAr).toBe("متجر النخبة");
  });

  test("since carries the workspace's real registration date", async () => {
    const partners = await fetchFeed();
    const inst = await db.instance.findUnique({ where: { id: INSTANCE_IDS[0] } });
    const health = partners.find((p) => p.sector === "health");
    expect(health?.since).toBe(inst?.createdAt.toISOString());
  });

  test("invisible rows never showcase (the visibility gate)", async () => {
    const partners = await fetchFeed();
    expect(partners.map((p) => p.id)).not.toContain(`sp-legal-hidden-${RUN}`);
    expect(partners.map((p) => p.sector)).not.toContain("legal");
  });

  test("trashed / banned / temp-banned / disabled workspaces never showcase", async () => {
    const partners = await fetchFeed();
    const ids = partners.map((p) => p.id);
    expect(ids).not.toContain(`sp-edu-${RUN}`);
    expect(ids).not.toContain(`sp-finance-${RUN}`);
    expect(ids).not.toContain(`sp-services-${RUN}`);
    expect(ids).not.toContain(`sp-media-${RUN}`);
  });

  test("dynamic: a newly added sector leader appears on the next read", async () => {
    await makeInstance(`inst-logistics-${RUN}`, "شركة الشحن السريع");
    await makePartner(`sp-logistics-${RUN}`, `inst-logistics-${RUN}`, "logistics", { sortOrder: 9 });
    const partners = await fetchFeed();
    const logistics = partners.find((p) => p.sector === "logistics");
    expect(logistics?.nameAr).toBe("شركة الشحن السريع");
    /* still no duplicates */
    const sectors = partners.map((p) => p.sector);
    expect(sectors.length).toBe(new Set(sectors).size);
  });

  test("fail-open: an empty showcase answers 200 with an empty list", async () => {
    await db.sectorPartner.deleteMany({});
    const partners = await fetchFeed();
    expect(partners).toEqual([]);
  });
});
