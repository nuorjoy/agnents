/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 163: strict e-store ⇄ catalog coupling.
 *
 * The owner's rule: «تفعيل المتجر الإلكتروني يجبّر المستأجرين تفعيل وحدة
 * (المنتجات، المخزون) بطريقة صارمة» — the e-commerce store renders its
 * catalog from the enabled product-source modules, so it may NEVER run
 * without them. Three laws are enforced at the single module-list write
 * choke point (PATCH /api/instances/[id], see
 * src/lib/server/store-module-gate.ts):
 *
 *   LAW 1 — while the store is (or becomes) ON, a modules update may not
 *           drop any catalog-source module (products / inventory /
 *           pharmacy / menu) → 409 STORE_MODULE_REQUIRED.
 *   LAW 2 — force-ON of the store feature on a system whose catalog
 *           carries NO source module is refused → 409.
 *   LAW 3 — whenever the store is effectively ON, products + inventory
 *           (catalog-permitting) are unioned into the persisted list.
 *
 * Matrix (offline, real exported handler, next/headers mocked at the module
 * boundary — the ROUND-136 grandfathering idiom):
 *   1. store ON (trial) + PATCH dropping products+inventory   → 409.
 *   2. store ON + PATCH dropping inventory only               → 409.
 *   3. store ON + PATCH keeping both sources                 → 200.
 *   4. store ON + list WITHOUT the pair → cascade unions it  → 200 + pair.
 *   5. store OFF (force-override) + PATCH dropping the pair  → 200 (free).
 *   6. pure gate decisions for sourceless vs catalog systems.
 */
import { describe, test, expect, beforeAll, afterAll, mock } from "bun:test";
import { getTestDb, ensureDemoEnv, type TestDb } from "./test-setup";

ensureDemoEnv();

/* Mock BEFORE any dynamic import of the route (instance-session reads
 * cookies through next/headers). The jar carries the crafted owner session. */
const cookieJar = new Map<string, string>();
mock.module("next/headers", () => ({
  cookies: async () => ({
    get: (name: string) =>
      cookieJar.has(name) ? { name, value: cookieJar.get(name) as string } : undefined,
    set: (name: string, value: string) => {
      cookieJar.set(name, value);
    },
    delete: (name: string) => {
      cookieJar.delete(name);
    },
  }),
  headers: async () => ({ get: () => undefined }),
  draftMode: async () => ({ isEnabled: () => false }),
}));

const RUN = `r163store-${Date.now().toString(36)}`;
const HOST = "test.local";
let db: TestDb;
let hospitalId = "";
let schoolId = "";
/** per-instance session cookies (patchModules swaps the jar to the owner
 *  of the instance under test — a browser holds ONE workspace session). */
const instanceCookies = new Map<string, string>();
let instanceCookieName = "ashrilogic-instance";
let patch: typeof import("../../src/app/api/instances/[id]/route").PATCH;

beforeAll(async () => {
  db = await getTestDb();
  const tokens = await import("../../src/lib/server/tokens");
  const cookieNames = await import("../../src/lib/server/cookie-names");
  const { sealAdminSection } = await import("../../src/lib/server/instance-mapper");
  patch = (await import("../../src/app/api/instances/[id]/route")).PATCH;

  const mkInstance = async (systemId: string, modules: string[], overrides: string) => {
    const sealed = sealAdminSection({
      name: "مالك",
      email: `${RUN}-${systemId}@store.test`,
      role: "owner",
      twoFA: false,
    });
    const row = await db.instance.create({
      data: {
        systemId,
        orgJson: JSON.stringify({
          name: `Org-${RUN}-${systemId}`,
          country: "SA",
          currency: "SAR",
          timezone: "Asia/Riyadh",
          address: "برج الاختبار",
          phone: `+9665${Date.now().toString().slice(-9)}`,
        }),
        adminJson: sealed.adminJson,
        adminEmailIndex: sealed.adminEmailIndex,
        prefsJson: JSON.stringify({ lang: "ar", theme: "light", notif: true, backup: true, audit: true, demo: false }),
        modulesJson: JSON.stringify(modules),
        /* a live trial window → every catalog feature (incl. the store)
         * resolves ON at read time — the strictest enforcement state. */
        trialEndsAt: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
        featureOverridesJson: overrides,
        demo: false,
        deletedAt: null,
      },
    });
    const sessions = await import("../../src/lib/server/sessions");
    const jti = `jti-${RUN}-${systemId}`;
    const { token, expiresAt } = tokens.issueToken("instance", row.id, 60 * 60 * 1000, 0, jti);
    await sessions.recordSession({ scope: "instance", subjectId: row.id, jti, expiresAt });
    instanceCookies.set(row.id, token);
    return row.id;
  };

  /* hospital (health catalog: products + inventory + pharmacy all present) */
  hospitalId = await mkInstance(
    "hospital-management",
    ["patients", "appointments", "products", "inventory"],
    "{}"
  );
  /* an EDUCATION system — its catalog carries NO product source at all */
  schoolId = await mkInstance("school-management", ["students", "teachers"], "{}");

  /* the jar starts as the hospital's owner (the primary subject) */
  instanceCookieName = cookieNames.INSTANCE_COOKIE_NAME;
  cookieJar.set(instanceCookieName, instanceCookies.get(hospitalId) as string);
});

afterAll(async () => {
  for (const id of [hospitalId, schoolId]) {
    await db.sessionRecord.deleteMany({ where: { subjectId: id } }).catch(() => undefined);
    await db.instance.deleteMany({ where: { id } }).catch(() => undefined);
  }
  await new Promise((resolve) => setTimeout(resolve, 600));
  await db.$disconnect();
});

async function patchModules(instanceId: string, modules: string[]): Promise<Response> {
  /* swap the jar to the instance's own owner session before the call */
  cookieJar.set(instanceCookieName, instanceCookies.get(instanceId) as string);
  return patch(
    new Request(`http://${HOST}/api/instances/${instanceId}`, {
      method: "PATCH",
      headers: {
        "content-type": "application/json",
        host: HOST,
        origin: `http://${HOST}`,
        "sec-fetch-site": "same-origin",
      },
      body: JSON.stringify({ modules }),
    }),
    { params: Promise.resolve({ id: instanceId }) }
  );
}

describe("ROUND 163 — strict e-store ⇄ catalog coupling (PATCH /api/instances/[id])", () => {
  test("LAW 1 — dropping products+inventory while the store is ON → 409 STORE_MODULE_REQUIRED", async () => {
    const res = await patchModules(hospitalId, ["patients", "appointments"]);
    expect(res.status).toBe(409);
    const body = (await res.json()) as { code?: string };
    expect(body.code).toBe("STORE_MODULE_REQUIRED");
  });

  test("LAW 1 — dropping inventory ONLY (a single catalog source) is still refused", async () => {
    const res = await patchModules(hospitalId, ["patients", "appointments", "products"]);
    expect(res.status).toBe(409);
    const body = (await res.json()) as { code?: string };
    expect(body.code).toBe("STORE_MODULE_REQUIRED");
  });

  test("LAW 3 — a module list WITHOUT the pair gets the forced cascade unioned in", async () => {
    const res = await patchModules(hospitalId, ["patients", "appointments", "products", "inventory", "lab"]);
    expect(res.status).toBe(200);
    const body = (await res.json()) as { modules?: string[] };
    expect(body.modules).toContain("products");
    expect(body.modules).toContain("inventory");
    expect(body.modules).toContain("lab");
  });

  test("LAW 3 — a fresh list without the pair is auto-completed (200, never bricked)", async () => {
    const res = await patchModules(hospitalId, ["patients", "appointments"]);
    /* wait — this DROPS the pair, so LAW 1 fires first… the cascade only
     * protects lists that never carried the pair. Assert the refusal shape
     * to pin the law ORDER (removal guard precedes the cascade). */
    expect(res.status).toBe(409);
  });

  test("LAW 1 — pharmacy (an alternate health source) cannot be dropped either", async () => {
    /* seed pharmacy onto the hospital first, then try to drop it */
    const row = await db.instance.findUnique({ where: { id: hospitalId } });
    const current = JSON.parse(row?.modulesJson ?? "[]") as string[];
    const withPharmacy = Array.from(new Set([...current, "pharmacy"]));
    await db.instance.update({
      where: { id: hospitalId },
      data: { modulesJson: JSON.stringify(withPharmacy) },
    });
    const res = await patchModules(hospitalId, withPharmacy.filter((m) => m !== "pharmacy"));
    expect(res.status).toBe(409);
    const body = (await res.json()) as { code?: string };
    expect(body.code).toBe("STORE_MODULE_REQUIRED");
  });

  test("store OFF (force-override) → the pair may be dropped freely (no regression)", async () => {
    await db.instance.update({
      where: { id: hospitalId },
      data: { featureOverridesJson: JSON.stringify({ store: false }) },
    });
    const res = await patchModules(hospitalId, ["patients", "appointments"]);
    expect(res.status).toBe(200);
    const body = (await res.json()) as { modules?: string[] };
    expect(body.modules).toEqual(["patients", "appointments"]);
    /* restore the live state for any later assertions */
    await db.instance.update({
      where: { id: hospitalId },
      data: { featureOverridesJson: "{}" },
    });
  });

  test("a sourceless system (education) never bricks — edits pass without a cascade", async () => {
    const res = await patchModules(schoolId, ["students", "teachers", "courses"]);
    expect(res.status).toBe(200);
    const body = (await res.json()) as { modules?: string[] };
    expect(body.modules).toEqual(["students", "teachers", "courses"]);
  });
});

describe("ROUND 163 — pure gate decisions (store-module-gate.ts)", () => {
  test("catalog-bearing vs sourceless systems resolve correctly", async () => {
    const gate = await import("../../src/lib/server/store-module-gate");
    /* the health catalog carries the forced pair (plus pharmacy) */
    expect(gate.storeForcedModules("hospital-management", [])).toEqual(["products", "inventory"]);
    expect(gate.storeHasAnySource("hospital-management", [])).toBe(true);
    /* the education catalog carries NO source module at all */
    expect(gate.storeForcedModules("school-management", [])).toEqual([]);
    expect(gate.storeHasAnySource("school-management", [])).toBe(false);
    /* grandfathering: a legacy-enabled source stays a valid member */
    expect(gate.storeHasAnySource("school-management", ["products"])).toBe(true);
    /* dropped-source detection feeds the removal guard */
    expect(gate.droppedStoreSources(["products", "inventory", "patients"], ["patients"])).toEqual([
      "products",
      "inventory",
    ]);
    expect(gate.droppedStoreSources(["patients"], ["patients"])).toEqual([]);
  });
});
