/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — the ROUND 131 link-pipeline extensions
 * (src/lib/markdown.ts): bare-URL autolinks, schemeless-domain upgrade,
 * root-relative internal links, whitespace-tolerant [](...) forms, angle
 * autolinks, raw-HTML-anchor paste normalization and bidi-direction
 * robustness.
 *
 * The contract under test: NO MATTER HOW the author typed or pasted a link
 * (bare URL, scheme-less host, internal path, spaced brackets, angle form,
 * copied <a href> HTML, RTL-typed with bidi control characters), a SAFE
 * target renders as a real <a> — while every hostile scheme stays literal
 * text and nothing is ever linked twice.
 */
import { describe, test, expect } from "bun:test";
import { renderMarkdown } from "@/lib/markdown";

describe("markdown ROUND 131 — bare-URL autolinks", () => {
  test("a pasted https:// URL in prose becomes a real anchor", () => {
    const html = renderMarkdown("تفاصيل الإطلاق على https://www.ashrilogic.com/blog");
    expect(html).toContain('<a href="https://www.ashrilogic.com/blog"');
    expect(html).toContain('rel="noopener noreferrer nofollow"');
    expect(html).toContain('target="_blank"');
  });

  test("a bare www. host upgrades to https", () => {
    const html = renderMarkdown("الموقع www.example.sa متاح");
    expect(html).toContain('<a href="https://www.example.sa"');
    expect(html).toContain(">www.example.sa</a>");
  });

  test("trailing Latin sentence punctuation peels off the href", () => {
    const html = renderMarkdown("راجع https://example.com/pricing. ثم أكمل");
    expect(html).toContain('href="https://example.com/pricing"');
    expect(html).not.toContain('href="https://example.com/pricing."');
    expect(html).toContain("</a>.");
  });

  test("trailing Arabic question mark peels off the href", () => {
    const html = renderMarkdown("هل زرت https://example.com/a؟");
    expect(html).toContain('href="https://example.com/a"');
    expect(html).not.toContain("https://example.com/a؟");
  });

  test("URLs inside code spans are NEVER autolinked", () => {
    const html = renderMarkdown("نص الأمر `https://literal.example` يظل حرفياً");
    expect(html).toContain("<code>https://literal.example</code>");
    expect(html).not.toContain("<a ");
  });

  test("a URL already inside an explicit anchor is not linked twice", () => {
    const html = renderMarkdown("راجع [التوثيق](https://docs.example.com/start) للتفاصيل");
    const anchors = html.match(/<a /g) ?? [];
    expect(anchors.length).toBe(1);
    expect(html).toContain(">التوثيق</a>");
  });

  test("the https:// label inside an explicit link is not re-autolinked", () => {
    const html = renderMarkdown("[https://mirror.example.com](https://mirror.example.com)");
    const anchors = html.match(/<a /g) ?? [];
    expect(anchors.length).toBe(1);
  });

  test("a javascript: run in plain text is never autolinked", () => {
    const html = renderMarkdown("javascript:alert(1) يظل نصاً");
    expect(html).not.toContain("<a ");
  });

  test("mailto runs are not autolinked (only explicit [t](mailto:) form)", () => {
    const html = renderMarkdown("hi@example.com يظل نصاً");
    expect(html).not.toContain("<a ");
  });
});

describe("markdown ROUND 131 — schemeless and internal link targets", () => {
  test("[label](example.com/path) upgrades the host to https", () => {
    const html = renderMarkdown("[موقعنا](example.com/path) جرب");
    expect(html).toContain('<a href="https://example.com/path"');
  });

  test("[label](/compare) is an INTERNAL same-tab link without target/rel", () => {
    const html = renderMarkdown("قارن عبر [صفحة المقارنة](/compare)");
    expect(html).toContain('<a href="/compare">صفحة المقارنة</a>');
    expect(html).not.toContain("target=");
    expect(html).not.toContain("rel=");
  });

  test("protocol-relative //host targets are refused (not internal)", () => {
    const html = renderMarkdown("[x](//evil.example)");
    expect(html).not.toContain("<a ");
  });

  test("whitespace-padded [label]( url ) now renders (was literal text)", () => {
    const html = renderMarkdown("[النص]( https://x.com/a ) جرب");
    expect(html).toContain('<a href="https://x.com/a"');
  });

  test("[label](mailto:…) keeps the external hardening contract", () => {
    const html = renderMarkdown("[راسلنا](mailto:hi@example.com)");
    expect(html).toContain('href="mailto:hi@example.com"');
    expect(html).toContain('rel="noopener noreferrer nofollow"');
  });
});

describe("markdown ROUND 131 — angle autolinks and pasted HTML anchors", () => {
  test("<https://host/path> renders as an anchor (markdown angle form)", () => {
    const html = renderMarkdown("راجع <https://oecd.org/en/topics> الآن");
    expect(html).toContain('<a href="https://oecd.org/en/topics"');
  });

  test("a pasted <a href=\"https://…\">…</a> normalizes to a safe anchor", () => {
    const html = renderMarkdown('انسخ <a href="https://mckinsey.com/report" target="_blank">التقرير الكامل</a> هنا');
    expect(html).toContain('<a href="https://mckinsey.com/report"');
    expect(html).toContain(">التقرير الكامل</a>");
    /* the pasted raw attribute never leaks through */
    expect(html).not.toContain("target=\"_blank\" target=");
    expect(html).not.toContain("&lt;a");
  });

  test("a pasted anchor with a javascript: href stays ESCAPED literal text", () => {
    const html = renderMarkdown('لا <a href="javascript:alert(1)">تفجير</a> هنا');
    expect(html).not.toContain("<a ");
    expect(html).toContain("&lt;a href=");
  });

  test("a pasted anchor with a data: href stays escaped", () => {
    const html = renderMarkdown('لا <a href="data:text/html,x">@x</a> هنا');
    expect(html).not.toContain("<a ");
  });

  test("single-quoted hrefs normalize too", () => {
    const html = renderMarkdown("<a href='https://weforum.org/trends'>التوجهات</a>");
    expect(html).toContain('<a href="https://weforum.org/trends"');
    expect(html).toContain(">التوجهات</a>");
  });
});

describe("markdown ROUND 131 — RTL/bidi robustness", () => {
  test("RLM/LRM control characters inside a link target are stripped", () => {
    const html = renderMarkdown("راجع https://x.com/\u200Epath اليوم");
    expect(html).toContain('href="https://x.com/path"');
  });

  test("bidi isolates around a [](...) target do not break the match", () => {
    const html = renderMarkdown("[تقرير](\u2066https://x.com/r\u2069) الآن");
    expect(html).toContain('<a href="https://x.com/r"');
  });

  test("links inside an RTL paragraph with mixed Arabic text render fully", () => {
    const html = renderMarkdown(
      "قال **تقرير القطاع**: راجع [المصدر](https://source.example/2026) والتفاصيل على [صفحة المقارنة](/compare)."
    );
    expect(html).toContain('<a href="https://source.example/2026"');
    expect(html).toContain('<a href="/compare">');
  });
});

describe("markdown ROUND 131 — pipeline interactions stay pinned", () => {
  test("images still render (the R129 contract) with padded targets", () => {
    const html = renderMarkdown("![لقطة]( https://cdn.example.com/a.png )");
    expect(html).toContain('<img src="https://cdn.example.com/a.png"');
  });

  test("an image src is never autolinked into an anchor", () => {
    const html = renderMarkdown("![x](https://cdn.example.com/a.png)");
    expect(html).toContain("<img");
    expect(html).not.toContain("<a ");
  });

  test("icon badges after an autolinked URL still emit svg", () => {
    const html = renderMarkdown("انظر https://x.com/a :zap: للتفاصيل");
    expect(html).toContain("<a ");
    expect(html).toContain("<svg");
  });

  test("blockquote lines with a bare URL autolink too", () => {
    const html = renderMarkdown("> اقتباس مع رابط https://quote.example/x");
    expect(html).toContain("<blockquote>");
    expect(html).toContain('<a href="https://quote.example/x"');
  });

  test("list items with a bare URL autolink too", () => {
    const html = renderMarkdown("- مرجع https://list.example/i");
    expect(html).toContain("<li>");
    expect(html).toContain('<a href="https://list.example/i"');
  });
});

/* -------------------- ROUND 146 — internal-path integrity -------------------- */

describe("markdown ROUND 146 — backslash internal-path spoofing", () => {
  test("a /\\evil.com target is NOT treated as an internal path (WHATWG treats \\ as /)", () => {
    // /\evil.com would navigate to evil.com while claiming to be internal
    const html = renderMarkdown("[click](/\\evil.com)");
    expect(html).not.toMatch(/href="\/\\evil\.com"/);
    expect(html).not.toMatch(/href="[^"]*evil\.com[^"]*"/); // never escapes as a link either
    expect(html).toContain("click"); // the label survives as text
  });

  test("legitimate internal paths still render as internal anchors", () => {
    const html = renderMarkdown("[pricing](/packages)");
    expect(html).toMatch(/<a href="\/packages">pricing<\/a>/);
  });
});
