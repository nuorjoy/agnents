/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — the production storage invariant
 * (src/lib/server/storage/object-store.ts).
 *
 * Covers the P0 fail-closed fix: production MUST NOT boot (nor hand out a
 * local object store) on ephemeral local storage without an explicit
 * operator assertion. The historical posture was a console.warn — silently
 * losing uploaded images, the mail spool, and backup off-site members on
 * every container restart.
 *
 * Behaviors pinned:
 *  1. production + local driver (default) → THROWS with remediation text.
 *  2. production + local driver + ALLOW_LOCAL_STORAGE_IN_PRODUCTION=1 →
 *     passes (explicit durable-volume assertion).
 *  3. production + s3 driver → passes (durable backend).
 *  4. development/test + local driver → passes (documented dev posture).
 *  5. objectStorage() itself refuses in production on local (defense in
 *     depth — the invariant does not depend on the boot gate alone).
 */
import { describe, test, expect, beforeAll, afterEach } from "bun:test";
import { ensureDemoEnv } from "./test-setup";

type StoreModule = typeof import("@/lib/server/storage/object-store");
let store: StoreModule;

beforeAll(async () => {
  ensureDemoEnv();
  store = await import("@/lib/server/storage/object-store");
});

const REAL_NODE_ENV = process.env.NODE_ENV;
const REAL_DRIVER = process.env.ASHRILOGIC_STORAGE_DRIVER;
const REAL_DIR = process.env.ASHRILOGIC_STORAGE_DIR;

afterEach(() => {
  (process.env as { NODE_ENV?: string }).NODE_ENV = REAL_NODE_ENV;
  if (REAL_DRIVER === undefined) delete process.env.ASHRILOGIC_STORAGE_DRIVER;
  else process.env.ASHRILOGIC_STORAGE_DRIVER = REAL_DRIVER;
  if (REAL_DIR === undefined) delete process.env.ASHRILOGIC_STORAGE_DIR;
  else process.env.ASHRILOGIC_STORAGE_DIR = REAL_DIR;
  delete process.env.ALLOW_LOCAL_STORAGE_IN_PRODUCTION;
  store.__resetObjectStorageForTests();
});

describe("production storage invariant — fail-closed", () => {
  test("production + local driver (the default) THROWS with remediation", () => {
    (process.env as { NODE_ENV?: string }).NODE_ENV = "production";
    delete process.env.ASHRILOGIC_STORAGE_DRIVER; // the default is "local"
    expect(() => store.assertDurableStorageInvariant()).toThrow(
      /PRODUCTION STORAGE INVARIANT/
    );
  });

  test("production + explicit local driver THROWS too", () => {
    (process.env as { NODE_ENV?: string }).NODE_ENV = "production";
    process.env.ASHRILOGIC_STORAGE_DRIVER = "local";
    expect(() => store.assertDurableStorageInvariant()).toThrow(
      /ALLOW_LOCAL_STORAGE_IN_PRODUCTION=1/
    );
  });

  test("production + local + ALLOW_LOCAL_STORAGE_IN_PRODUCTION=1 passes (durable-volume assertion)", () => {
    (process.env as { NODE_ENV?: string }).NODE_ENV = "production";
    process.env.ASHRILOGIC_STORAGE_DRIVER = "local";
    process.env.ALLOW_LOCAL_STORAGE_IN_PRODUCTION = "1";
    expect(() => store.assertDurableStorageInvariant()).not.toThrow();
  });

  test("production + s3 driver passes", () => {
    (process.env as { NODE_ENV?: string }).NODE_ENV = "production";
    process.env.ASHRILOGIC_STORAGE_DRIVER = "s3";
    expect(() => store.assertDurableStorageInvariant()).not.toThrow();
  });

  test("development + local driver passes (documented dev posture)", () => {
    (process.env as { NODE_ENV?: string }).NODE_ENV = "development";
    delete process.env.ASHRILOGIC_STORAGE_DRIVER;
    expect(() => store.assertDurableStorageInvariant()).not.toThrow();
  });

  test("objectStorage() refuses local in production — defense in depth", async () => {
    (process.env as { NODE_ENV?: string }).NODE_ENV = "production";
    delete process.env.ASHRILOGIC_STORAGE_DRIVER;
    store.__resetObjectStorageForTests();
    await expect(store.objectStorage()).rejects.toThrow(
      /PRODUCTION STORAGE INVARIANT/
    );
  });

  test("objectStorage() serves local in development (unchanged dev behavior)", async () => {
    (process.env as { NODE_ENV?: string }).NODE_ENV = "development";
    delete process.env.ASHRILOGIC_STORAGE_DRIVER;
    store.__resetObjectStorageForTests();
    const s = await store.objectStorage();
    expect(s).toBeTruthy();
  });
});
