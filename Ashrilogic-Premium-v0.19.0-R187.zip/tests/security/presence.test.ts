/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 172 (premium presence).
 *
 * The presence system derives online/offline from the ROUND 45 session
 * registry (SessionRecord.lastSeenAt, throttled to one refresh per minute
 * by sessions.ts). This suite pins the derivation law on the throwaway
 * test DB:
 *
 *  1. ONLINE WINDOW — a live (unrevoked, unexpired) session with a fresh
 *     lastSeenAt marks its subject ONLINE; a stale-but-live session keeps
 *     the subject OFFLINE while still surfacing its lastSeenAt («آخر ظهور»).
 *  2. REVOKATION / EXPIRY — a revoked session (signed out from another
 *     device) and an expired session never keep a subject online, even
 *     with a fresh lastSeenAt.
 *  3. MULTIPLE SESSIONS — the LATEST lastSeenAt across a subject's live
 *     sessions wins (a fresh device + a stale device → online).
 *  4. DIRECTORY SCOPING — the console snapshots include every NON-TRASHED
 *     admin / workspace and never the trashed ones.
 *  5. PUBLIC COUNT — onlineAdminCount counts DISTINCT online admin
 *     subjects (identities never leave the module — the public surface
 *     is the count only).
 *  6. SINGLE-QUERY BATCH — presenceMapFor resolves a batch through ONE
 *     grouped lookup: instrumented delegate counting proves zero
 *     per-subject findUnique-style reads (no N+1).
 */
import { describe, test, expect, beforeAll, afterAll } from "bun:test";
import { getTestDb, ensureDemoEnv, type TestDb } from "./test-setup";

ensureDemoEnv();

const RUN = Math.random().toString(36).slice(2, 8);

let db: TestDb;
let presence: typeof import("@/lib/server/presence");

/* subjects: two live admins + one trashed admin; one instance */
const adminA = `adm-pres-a-${RUN}`;
const adminB = `adm-pres-b-${RUN}`;
const adminTrashed = `adm-pres-t-${RUN}`;
const instanceX = `inst-pres-x-${RUN}`;

function sessionRow(
  subjectId: string,
  scope: "admin" | "instance",
  opts: { lastSeenAt: Date; expiresAt?: Date; revokedAt?: Date | null; jti?: string }
) {
  return {
    id: opts.jti ?? `jti-${subjectId}-${Math.random().toString(36).slice(2, 10)}`,
    scope,
    subjectId,
    ip: null,
    userAgent: "presence-test",
    device: "Test · Linux",
    lastSeenAt: opts.lastSeenAt,
    expiresAt: opts.expiresAt ?? new Date(Date.now() + 60 * 60 * 1000),
    revokedAt: opts.revokedAt ?? null,
  };
}

beforeAll(async () => {
  db = await getTestDb();
  presence = await import("@/lib/server/presence");

  const adminBase = {
    passwordHash: null,
    sessionVersion: 0,
  };
  await db.adminUser.create({
    data: {
      id: adminA,
      username: `pres-a-${RUN}`,
      name: "أ",
      email: `a-${RUN}@pres.test`,
      emailIndex: `idx-a-${RUN}`,
      role: "admin",
      active: true,
      ...adminBase,
    },
  });
  await db.adminUser.create({
    data: {
      id: adminB,
      username: `pres-b-${RUN}`,
      name: "ب",
      email: `b-${RUN}@pres.test`,
      emailIndex: `idx-b-${RUN}`,
      role: "admin",
      active: true,
      ...adminBase,
    },
  });
  await db.adminUser.create({
    data: {
      id: adminTrashed,
      username: `pres-t-${RUN}`,
      name: "ت",
      email: `t-${RUN}@pres.test`,
      emailIndex: `idx-t-${RUN}`,
      role: "admin",
      active: true,
      deletedAt: new Date(),
      ...adminBase,
    },
  });
  await db.instance.create({
    data: {
      id: instanceX,
      systemId: `pres-sys-${RUN}`,
      orgJson: JSON.stringify({ name: `مؤسسة الحضور ${RUN}` }),
      adminJson: JSON.stringify({ name: "مالك", email: `owner-${RUN}@pres.test`, role: "owner", twoFA: false }),
      prefsJson: JSON.stringify({ lang: "ar", theme: "light", notif: true, backup: true, audit: true, demo: false }),
      modulesJson: JSON.stringify(["products"]),
    },
  });
});

afterAll(async () => {
  await db.sessionRecord.deleteMany({ where: { subjectId: { in: [adminA, adminB, adminTrashed, instanceX] } } });
  await db.adminUser.deleteMany({ where: { id: { in: [adminA, adminB, adminTrashed] } } });
  await db.instance.deleteMany({ where: { id: instanceX } });
});

describe("presence derivation (ROUND 172)", () => {
  test("fresh live session → online; stale live session → offline with lastSeenAt", async () => {
    await db.sessionRecord.create({
      data: sessionRow(adminA, "admin", { lastSeenAt: new Date() }),
    });
    const stale = new Date(Date.now() - 10 * 60 * 1000);
    await db.sessionRecord.create({
      data: sessionRow(adminB, "admin", { lastSeenAt: stale }),
    });

    const map = await presence.presenceMapFor("admin", [adminA, adminB]);
    const a = map.get(adminA);
    const b = map.get(adminB);
    expect(a?.online).toBe(true);
    expect(b?.online).toBe(false);
    expect(b?.lastSeenAt).toBe(stale.toISOString());
    /* unknown subject is simply absent — callers default to offline */
    expect(map.has(`unknown-${RUN}`)).toBe(false);
  });

  test("revoked and expired sessions never keep a subject online", async () => {
    /* adminA now signs out that device (revoked) with a FRESH lastSeenAt */
    await db.sessionRecord.updateMany({
      where: { subjectId: adminA, scope: "admin" },
      data: { revokedAt: new Date(), lastSeenAt: new Date() },
    });
    let map = await presence.presenceMapFor("admin", [adminA]);
    expect(map.get(adminA)?.online ?? false).toBe(false);

    /* a NEW unrevoked but already-expired session also stays offline */
    await db.sessionRecord.create({
      data: sessionRow(adminA, "admin", {
        lastSeenAt: new Date(),
        expiresAt: new Date(Date.now() - 1000),
      }),
    });
    map = await presence.presenceMapFor("admin", [adminA]);
    expect(map.get(adminA)).toBeUndefined();
  });

  test("the latest lastSeenAt across live sessions wins (fresh device + stale device)", async () => {
    await db.sessionRecord.deleteMany({ where: { subjectId: adminB, scope: "admin" } });
    await db.sessionRecord.create({
      data: sessionRow(adminB, "admin", { lastSeenAt: new Date(Date.now() - 30 * 60 * 1000) }),
    });
    await db.sessionRecord.create({
      data: sessionRow(adminB, "admin", { lastSeenAt: new Date() }),
    });
    const p = await presence.presenceOf("admin", adminB);
    expect(p.online).toBe(true);
    expect(p.lastSeenAt).not.toBeNull();
    expect(new Date(p.lastSeenAt as string).getTime()).toBeGreaterThan(Date.now() - 60_000);
  });

  test("instance scope derives with the same law", async () => {
    await db.sessionRecord.create({
      data: sessionRow(instanceX, "instance", { lastSeenAt: new Date() }),
    });
    const p = await presence.presenceOf("instance", instanceX);
    expect(p.online).toBe(true);
    await db.sessionRecord.updateMany({
      where: { subjectId: instanceX, scope: "instance" },
      data: { revokedAt: new Date() },
    });
    const p2 = await presence.presenceOf("instance", instanceX);
    expect(p2.online).toBe(false);
    expect(p2.lastSeenAt).toBeNull();
  });

  test("onlineAdminCount counts distinct online admins only (identities stay internal)", async () => {
    /* adminB is the only online admin right now (fresh session, live);
       adminA's sessions are revoked/expired; adminTrashed gets a fresh one. */
    await db.sessionRecord.create({
      data: sessionRow(adminTrashed, "admin", { lastSeenAt: new Date() }),
    });
    const count = await presence.onlineAdminCount();
    /* trashed or not, the session registry counts live admin sessions:
       adminB (online) + adminTrashed (online) = at least 2 — but the count
       must be exactly the distinct online subjects of THIS run to stay
       deterministic under a shared throwaway DB. */
    const map = await presence.presenceMapFor("admin", [adminA, adminB, adminTrashed]);
    const expected = [adminA, adminB, adminTrashed].filter((id) => map.get(id)?.online).length;
    expect(count).toBeGreaterThanOrEqual(expected);
  });

  test("directory snapshots skip trashed rows and resolve one query per batch (no N+1)", async () => {
    /* instrument the sessionRecord delegate: the grouped read must be the
       ONLY sessionRecord read on the batch path */
    const calls: string[] = [];
    const delegate = db.sessionRecord as unknown as Record<string, unknown>;
    const tracked = ["findUnique", "findFirst", "findMany", "groupBy", "aggregate"] as const;
    const originals = new Map<string, unknown>();
    for (const method of tracked) {
      originals.set(method, delegate[method]);
      delegate[method] = new Proxy(originals.get(method) as object, {
        apply(target, thisArg, args) {
          calls.push(method);
          if (method === "findUnique" || method === "findFirst") {
            throw new Error("presenceMapFor must never call per-subject reads (N+1)");
          }
          return (target as (...a: unknown[]) => Promise<unknown>).apply(thisArg, args);
        },
      });
    }
    try {
      const admins = await presence.adminDirectoryPresence();
      const instances = await presence.instanceDirectoryPresence();
      expect(admins[adminB]?.online).toBe(true);
      expect(admins[adminTrashed]).toBeUndefined();
      expect(instances[instanceX]?.online).toBe(false);
      /* exactly ONE grouped read per directory batch (2 batches here),
         zero per-subject reads */
      expect(calls.filter((c) => c === "groupBy").length).toBe(2);
      expect(calls.filter((c) => c === "findUnique" || c === "findFirst" || c === "findMany").length).toBe(0);
    } finally {
      for (const method of tracked) {
        delegate[method] = originals.get(method);
      }
    }
  });

  test("presenceRecord fills every requested id with a safe offline default", () => {
    const now = new Date().toISOString();
    const rec = presence.presenceRecord(
      new Map([
        ["x", { online: true, lastSeenAt: now }],
        ["y", { online: false, lastSeenAt: now }],
      ]),
      ["x", "y", "z"]
    );
    expect(rec.x.online).toBe(true);
    expect(rec.y.online).toBe(false);
    expect(rec.z).toEqual({ online: false, lastSeenAt: null });
  });
});
