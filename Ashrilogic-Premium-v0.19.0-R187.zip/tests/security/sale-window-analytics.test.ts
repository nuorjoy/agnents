/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — window-bound sales + store analytics (ROUND 53).
 *
 * Pins under test:
 *  - `saleEndsAt` write field accepts only ISO timestamps or null —
 *    date-only strings, garbage and arrays are refused by zod (422 before
 *    any handler runs);
 *  - the sale VERDICT requires the window to be OPEN: an expired window
 *    degrades to the regular price on BOTH toSiteProduct (display) and
 *    effectivePriceMinor (charge) — display and charge can never disagree;
 *    saleEndsAt is only exposed while the whole sale applies, so the
 *    storefront countdown chip can never advertise a dead window;
 *  - saleWindowOpen boundary semantics (null = open-ended; equal-ms = closed);
 *  - aggregateTopProducts / salesMomentum / countedRevenue: cancelled orders
 *    are excluded, aggregation keys by recordId, ranking is deterministic,
 *    momentum windows are pinned by the injected `now`.
 */
import { describe, test, expect } from "bun:test";
import type { ModuleRecord } from "@prisma/client";
import { moduleRecordUpdateSchema } from "@/lib/server/module-record-mapper";
import {
  toSiteProduct,
  effectivePriceMinor,
  saleWindowOpen,
} from "@/lib/server/store-mapper";
import {
  aggregateTopProducts,
  salesMomentum,
  countedRevenue,
} from "@/lib/store-analytics";
import type { SiteOrderAdminDTO, SiteOrderStatus } from "@/lib/types";

function fakeRecord(overrides: Partial<ModuleRecord> = {}): ModuleRecord {
  /* inventory column layout: { name:0, category:2, stock:3, price:4 } */
  return {
    id: "r1",
    instanceId: "i1",
    moduleId: "inventory",
    dataJson: JSON.stringify(["جهاز قياس", "", "أجهزة", "12", "450.00"]),
    statusKey: "",
    imageRef: null,
    featured: false,
    salePrice: null,
    saleEndsAt: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    ...overrides,
  } as ModuleRecord;
}

describe("sale window — write schema shapes", () => {
  test("saleEndsAt accepts ISO timestamps (Z and offset) and null", () => {
    expect(
      moduleRecordUpdateSchema.safeParse({ saleEndsAt: "2026-12-31T23:59:59.000Z" }).success
    ).toBe(true);
    expect(
      moduleRecordUpdateSchema.safeParse({ saleEndsAt: "2026-12-31T23:59:59+03:00" }).success
    ).toBe(true);
    expect(moduleRecordUpdateSchema.safeParse({ saleEndsAt: null }).success).toBe(true);
  });

  test("saleEndsAt rejects date-only, garbage, numbers and arrays", () => {
    expect(moduleRecordUpdateSchema.safeParse({ saleEndsAt: "2026-12-31" }).success).toBe(false);
    expect(moduleRecordUpdateSchema.safeParse({ saleEndsAt: "tomorrow" }).success).toBe(false);
    expect(moduleRecordUpdateSchema.safeParse({ saleEndsAt: 1798761599000 }).success).toBe(false);
    expect(moduleRecordUpdateSchema.safeParse({ saleEndsAt: ["2026-12-31T00:00:00Z"] }).success)
      .toBe(false);
  });

  test("saleEndsAt alone satisfies the at-least-one-field refine", () => {
    const parsed = moduleRecordUpdateSchema.safeParse({ saleEndsAt: null });
    expect(parsed.success).toBe(true);
  });
});

describe("saleWindowOpen — boundary semantics", () => {
  const now = new Date("2026-09-15T12:00:00.000Z");
  test("null end = open-ended (always open)", () => {
    expect(saleWindowOpen(null, now)).toBe(true);
  });
  test("future end = open", () => {
    expect(saleWindowOpen(new Date("2026-09-20T00:00:00.000Z"), now)).toBe(true);
  });
  test("past end = closed", () => {
    expect(saleWindowOpen(new Date("2026-09-10T00:00:00.000Z"), now)).toBe(false);
  });
  test("the exact end instant is CLOSED (strictly-before semantics)", () => {
    expect(saleWindowOpen(now, now)).toBe(false);
  });
});

describe("toSiteProduct — window-bound sale verdict", () => {
  /* ROUND 125 — RELATIVE dates: this block asserted against the REAL clock
     (toSiteProduct takes no `now` parameter) with hard-coded 2026-09-15-era
     stamps — a time bomb that detonated the moment the sandbox clock passed
     2026-09-20 (the "future" window became the past → salePrice null → the
     battery failed on an untouched product). The windows are now computed
     from Date.now() so the suite is permanently deterministic. */
  test("future window keeps the sale live and exposes the end timestamp", () => {
    const futureEnd = new Date(Date.now() + 5 * 86_400_000);
    const p = toSiteProduct(
      "inventory",
      fakeRecord({
        salePrice: 35000,
        saleEndsAt: futureEnd,
      })
    );
    expect(p.salePrice).not.toBeNull();
    expect(p.saleEndsAt).toBe(futureEnd.toISOString());
  });

  test("EXPIRED window degrades the sale to the regular price", () => {
    const p = toSiteProduct(
      "inventory",
      fakeRecord({
        salePrice: 35000,
        saleEndsAt: new Date(Date.now() - 5 * 86_400_000),
      })
    );
    expect(p.salePrice).toBeNull();
    expect(p.saleEndsAt).toBeNull();
  });

  test("null window (open-ended) keeps the sale live with a null end", () => {
    const p = toSiteProduct("inventory", fakeRecord({ salePrice: 35000, saleEndsAt: null }));
    expect(p.salePrice).not.toBeNull();
    expect(p.saleEndsAt).toBeNull();
  });

  test("an expired window never leaks the end date (no dead countdown chip)", () => {
    const p = toSiteProduct(
      "inventory",
      fakeRecord({
        salePrice: 35000,
        saleEndsAt: new Date("2000-01-01T00:00:00.000Z"),
      })
    );
    expect(p.saleEndsAt).toBeNull();
  });
});

describe("effectivePriceMinor — window-aware charge mirror", () => {
  test("open window charges the sale price", () => {
    expect(
      effectivePriceMinor(
        fakeRecord({ salePrice: 35000, saleEndsAt: new Date("2099-01-01T00:00:00.000Z") }),
        "inventory"
      )
    ).toBe(35000);
  });

  test("expired window charges the regular price", () => {
    expect(
      effectivePriceMinor(
        fakeRecord({ salePrice: 35000, saleEndsAt: new Date("2000-01-01T00:00:00.000Z") }),
        "inventory"
      )
    ).toBe(45000);
  });

  test("display verdict and charge verdict AGREE across window states", () => {
    const ends = [
      new Date("2099-01-01T00:00:00.000Z"), // live
      new Date("2000-01-01T00:00:00.000Z"), // expired
      null, // open-ended
    ];
    for (const end of ends) {
      for (const sale of [1, 35000, 45000, 45001]) {
        const shown = toSiteProduct("inventory", fakeRecord({ salePrice: sale, saleEndsAt: end }));
        const charged = effectivePriceMinor(
          fakeRecord({ salePrice: sale, saleEndsAt: end }),
          "inventory"
        );
        const shownEffective =
          shown.salePrice != null ? Math.round(shown.salePrice * 100) : charged;
        expect(shownEffective).toBe(charged);
      }
    }
  });
});

/* ---------------------- analytics (pure aggregation) ---------------------- */

function order(
  id: string,
  createdAt: string,
  status: SiteOrderStatus,
  items: Array<{ recordId: string; name: string; price: number; qty: number }>,
  total: number
): SiteOrderAdminDTO {
  return {
    id,
    code: null,
    items,
    total,
    discount: 0,
    couponCode: null,
    currency: "SAR",
    status,
    note: null,
    statusNote: null,
    statusHistory: [],
    createdAt,
    updatedAt: createdAt,
    customerId: "c1",
    customerName: "عميل",
  };
}

describe("aggregateTopProducts", () => {
  test("aggregates qty, revenue and orderCount per recordId", () => {
    const top = aggregateTopProducts([
      order("o1", "2026-09-01T00:00:00Z", "completed", [
        { recordId: "a", name: "A", price: 10, qty: 2 },
        { recordId: "b", name: "B", price: 5, qty: 1 },
      ], 25),
      order("o2", "2026-09-02T00:00:00Z", "completed", [
        { recordId: "a", name: "A", price: 10, qty: 3 },
      ], 30),
    ]);
    const a = top.find((l) => l.recordId === "a")!;
    expect(a.qty).toBe(5);
    expect(a.revenue).toBe(50);
    expect(a.orderCount).toBe(2);
  });

  test("cancelled orders are excluded entirely", () => {
    const top = aggregateTopProducts([
      order("o1", "2026-09-01T00:00:00Z", "completed", [
        { recordId: "a", name: "A", price: 10, qty: 2 },
      ], 20),
      order("o2", "2026-09-02T00:00:00Z", "cancelled", [
        { recordId: "z", name: "Z", price: 99, qty: 9 },
      ], 891),
    ]);
    expect(top.length).toBe(1);
    expect(top[0].recordId).toBe("a");
  });

  test("ranks by qty, breaks ties by revenue deterministically", () => {
    const top = aggregateTopProducts([
      order("o1", "2026-09-01T00:00:00Z", "completed", [
        { recordId: "a", name: "A", price: 10, qty: 4 },
        { recordId: "b", name: "B", price: 50, qty: 4 },
        { recordId: "c", name: "C", price: 1, qty: 4 },
      ], 246),
    ]);
    expect(top.map((l) => l.recordId)).toEqual(["b", "a", "c"]);
    /* same input → same output (stable sort) */
    expect(aggregateTopProducts([
      order("o1", "2026-09-01T00:00:00Z", "completed", [
        { recordId: "c", name: "C", price: 1, qty: 4 },
        { recordId: "a", name: "A", price: 10, qty: 4 },
        { recordId: "b", name: "B", price: 50, qty: 4 },
      ], 246),
    ]).map((l) => l.recordId)).toEqual(["b", "a", "c"]);
  });

  test("respects the limit and returns [] for empty input", () => {
    const many = Array.from({ length: 9 }, (_, i) =>
      order(`o${i}`, "2026-09-01T00:00:00Z", "completed", [
        { recordId: `r${i}`, name: `R${i}`, price: 1, qty: i + 1 },
      ], i + 1)
    );
    expect(aggregateTopProducts(many, 5).length).toBe(5);
    expect(aggregateTopProducts([])).toEqual([]);
  });

  test("revenue stays cent-rounded (no float noise)", () => {
    const top = aggregateTopProducts([
      order("o1", "2026-09-01T00:00:00Z", "completed", [
        { recordId: "a", name: "A", price: 0.1, qty: 3 },
      ], 0.3),
    ]);
    expect(top[0].revenue).toBe(0.3);
  });
});

describe("salesMomentum", () => {
  const now = new Date("2026-09-15T12:00:00.000Z");
  test("splits the last 7 days from the prior 7 (cancelled excluded)", () => {
    const m = salesMomentum(
      [
        order("o1", "2026-09-14T12:00:00Z", "completed", [], 0), // 1d ago → last7
        order("o2", "2026-09-08T12:00:00Z", "completed", [], 0), // 7d ago → prev7
        order("o3", "2026-09-09T00:00:00Z", "cancelled", [], 0), // excluded
        order("o4", "2026-09-02T12:00:00Z", "completed", [], 0), // 13d ago → prev7
      ],
      now
    );
    expect(m.last7).toBe(1);
    expect(m.prev7).toBe(2);
    expect(m.delta).toBeCloseTo(-0.5, 10);
  });

  test("future-dated rows are not momentum signal", () => {
    const m = salesMomentum(
      [order("o1", "2026-09-20T00:00:00Z", "completed", [], 0)],
      now
    );
    expect(m.last7).toBe(0);
    expect(m.prev7).toBe(0);
  });

  test("empty history yields zeros with a safe delta", () => {
    const m = salesMomentum([], now);
    expect(m.last7).toBe(0);
    expect(m.prev7).toBe(0);
    expect(m.delta).toBe(0);
  });
});

describe("countedRevenue", () => {
  test("sums non-cancelled order totals with cent rounding", () => {
    expect(
      countedRevenue([
        order("o1", "2026-09-01T00:00:00Z", "completed", [], 120.5),
        order("o2", "2026-09-02T00:00:00Z", "pending", [], 30.25),
        order("o3", "2026-09-03T00:00:00Z", "cancelled", [], 999),
      ])
    ).toBe(150.75);
  });
});
