/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 40 (task 8-a) content-addressed image storage
 * layer (src/lib/server/image-store.ts + /api/images/[id] +
 * scripts/migrate-images.ts).
 *
 * Isolation: ASHRILOGIC_STORAGE_DIR points at a fresh tmp dir (set BEFORE
 * the first dynamic import of image-store) and every DB touch runs on the
 * throwaway PostgreSQL test database via the test-setup pattern (env bound before
 * importing @/lib/db consumers).
 *
 * Verified behaviors:
 *  - storeImageDataUrl runs the FULL validation pipeline and persists the
 *    sanitized WebP as a content-addressed file + ImageAsset row;
 *  - identical input dedupes to ONE row/file (content addressing);
 *  - isManagedImageRef accepts only /api/images/<64 lowercase hex>;
 *  - validateImageDataUrl keeps its data-URL contract (backward compat);
 *  - migrateImages converts inline data-URL rows to managed refs and is
 *    IDEMPOTENT (second run: zero changes);
 *  - the LIVE serving route 404s bad/unknown ids (shape-gated, no oracle).
 */
import { afterAll, describe, expect, test } from "bun:test";
import { existsSync, mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import sharp from "sharp";
import { getTestDb } from "./test-setup";

/* ------------------------------------------------------------------ */
/* Environment binding (STRICT ORDER)                                  */
/* ------------------------------------------------------------------ */

/* fresh storage root — BEFORE any import that could resolve it */
const STORAGE_DIR = mkdtempSync(join(tmpdir(), "ashrilogic-imgstore-"));
process.env.ASHRILOGIC_STORAGE_DIR = STORAGE_DIR;

/* throwaway DB bound BEFORE importing @/lib/db consumers */
const db = await getTestDb();

const {
  storeImageDataUrl,
  storeImageBuffer,
  getImageAsset,
  isManagedImageRef,
  MANAGED_REF_RE,
  storageImagesDir,
} = await import("@/lib/server/image-store");
const { validateImageDataUrl } = await import("@/lib/server/upload-validation");
const { migrateImages } = await import("../../scripts/migrate-images");

afterAll(() => {
  rmSync(STORAGE_DIR, { recursive: true, force: true });
});

/** Real tiny PNG (8×8 solid red) built with sharp — decodable, safe. */
async function tinyPngDataUrl(): Promise<string> {
  const png = await sharp({
    create: { width: 8, height: 8, channels: 3, background: "#f00" },
  })
    .png()
    .toBuffer();
  return `data:image/png;base64,${png.toString("base64")}`;
}

/* ------------------------------------------------------------------ */
/* storeImageDataUrl — full pipeline + persistence                      */
/* ------------------------------------------------------------------ */

describe("image-store — storeImageDataUrl (pipeline + persistence)", () => {
  test("valid PNG → managed ref, file on disk, ImageAsset row, correct metadata", async () => {
    const url = await tinyPngDataUrl();
    const stored = await storeImageDataUrl(url);

    // the returned reference is a server-minted managed ref
    expect(stored.url).toMatch(MANAGED_REF_RE);
    expect(stored.width).toBe(8);
    expect(stored.height).toBe(8);
    expect(stored.bytes).toBeGreaterThan(0);
    expect(stored.id).toMatch(/^[a-f0-9]{64}$/);

    // the sanitized WebP file exists under the storage root, named by id
    const file = join(storageImagesDir(), `${stored.id}.webp`);
    expect(existsSync(file)).toBe(true);

    // metadata row exists with the byte size and mime
    const row = await db.imageAsset.findUnique({ where: { id: stored.id } });
    expect(row).not.toBeNull();
    expect(row?.mime).toBe("image/webp");
    expect(row?.bytes).toBe(stored.bytes);
    expect(row?.bytes).toBeGreaterThan(0);
    expect(row?.width).toBe(8);
    expect(row?.height).toBe(8);

    // getImageAsset resolves the SAME bytes back (id → buffer + row mime)
    const asset = await getImageAsset(stored.id);
    expect(asset).not.toBeNull();
    expect(asset?.mime).toBe("image/webp");
    expect(asset?.buffer.length).toBe(stored.bytes);
  });

  test("DEDUPE — same data URL twice → same id, exactly ONE row and ONE file", async () => {
    const url = await tinyPngDataUrl();
    const first = await storeImageDataUrl(url);
    const second = await storeImageDataUrl(url);

    expect(second.id).toBe(first.id);
    expect(second.url).toBe(first.url);

    const rows = await db.imageAsset.findMany({ where: { id: first.id } });
    expect(rows.length).toBe(1);

    // only the .webp file (no tmp leftovers) for this id in the dir
    const { readdirSync } = await import("node:fs");
    const names = readdirSync(storageImagesDir()).filter((n) => n.startsWith(first.id));
    expect(names).toEqual([`${first.id}.webp`]);
  });

  test("policy violations throw ImageValidationError with user-presentable messages", async () => {
    const { ImageValidationError } = await import("@/lib/server/upload-validation");
    // SVG — script-capable format, rejected by the pipeline
    const svg = `data:image/svg+xml;base64,${Buffer.from(
      '<svg xmlns="http://www.w3.org/2000/svg"></svg>'
    ).toString("base64")}`;
    try {
      await storeImageDataUrl(svg);
      throw new Error("expected ImageValidationError");
    } catch (error) {
      expect(error).toBeInstanceOf(ImageValidationError);
      expect((error as Error).message).toBe("SVG images are not supported");
    }
  });

  test("storeImageBuffer round-trips pre-validated bytes", async () => {
    const webp = await sharp({
      create: { width: 4, height: 4, channels: 3, background: "#0f0" },
    })
      .webp()
      .toBuffer();
    const stored = await storeImageBuffer(webp, { mime: "image/webp", width: 4, height: 4 });
    expect(stored.url).toMatch(MANAGED_REF_RE);
    expect(existsSync(join(storageImagesDir(), `${stored.id}.webp`))).toBe(true);
    const again = await storeImageBuffer(webp, { mime: "image/webp" });
    expect(again.id).toBe(stored.id); // dedupe by content
  });
});

/* ------------------------------------------------------------------ */
/* isManagedImageRef — strict ref shape                                 */
/* ------------------------------------------------------------------ */

describe("image-store — isManagedImageRef (strict shape guard)", () => {
  test("accepts /api/images/<64 lowercase hex>", () => {
    expect(isManagedImageRef(`/api/images/${"a".repeat(64)}`)).toBe(true);
    expect(isManagedImageRef(`/api/images/${"0123456789abcdef".repeat(4)}`)).toBe(true);
  });

  test("rejects traversal, encoding tricks, bad shape, foreign URLs, plain paths", () => {
    expect(isManagedImageRef("../etc/passwd")).toBe(false);
    expect(isManagedImageRef("..%2f")).toBe(false);
    expect(isManagedImageRef(`/api/images/${"A".repeat(64)}`)).toBe(false); // uppercase
    expect(isManagedImageRef(`/api/images/${"a".repeat(63)}`)).toBe(false); // short
    expect(isManagedImageRef(`/api/images/${"a".repeat(65)}`)).toBe(false); // long
    expect(isManagedImageRef("https://evil.example/x")).toBe(false);
    expect(isManagedImageRef("/api/images/../../etc/passwd")).toBe(false);
    expect(isManagedImageRef("/api/other/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")).toBe(false);
    expect(isManagedImageRef("")).toBe(false);
    expect(isManagedImageRef(null)).toBe(false);
    expect(isManagedImageRef(undefined)).toBe(false);
    expect(isManagedImageRef(12345)).toBe(false);
  });
});

/* ------------------------------------------------------------------ */
/* validateImageDataUrl — backward-compatible contract                  */
/* ------------------------------------------------------------------ */

describe("image-store — validateImageDataUrl contract intact (backward compat)", () => {
  test("still returns a re-encoded webp DATA URL (not a managed ref)", async () => {
    const url = await tinyPngDataUrl();
    const out = await validateImageDataUrl(url);
    expect(out.startsWith("data:image/webp;base64,")).toBe(true);
  });
});

/* ------------------------------------------------------------------ */
/* migrateImages — inline data-URL rows → managed refs, idempotent      */
/* ------------------------------------------------------------------ */

describe("image-store — migrateImages (one-time migration, idempotent)", () => {
  test("converts a data-URL site logo + admin avatar to managed refs; second run changes nothing", async () => {
    await db.site.deleteMany({});
    await db.adminUser.deleteMany({});
    await db.instance.deleteMany({});
    await db.imageAsset.deleteMany({});

    const logoUrl = await tinyPngDataUrl();
    const instance = await db.instance.create({
      data: {
        id: "img-mig-test-instance",
        systemId: "clinics-management",
        orgJson: JSON.stringify({ name: "Img Migration Clinic" }),
        adminJson: JSON.stringify({ name: "Owner", email: "owner@img-mig.test" }),
        prefsJson: JSON.stringify({ lang: "en" }),
        modulesJson: JSON.stringify([]),
      },
    });
    await db.site.create({
      data: {
        instanceId: instance.id,
        published: false,
        theme: "aurora",
        views: 0,
        contentJson: JSON.stringify({
          tagline: "kept",
          heroTitle: "kept",
          logoUrl,
          contactEmail: "kept@x.test",
        }),
      },
    });
    await db.adminUser.create({
      data: {
        username: "img-mig-admin",
        name: "Img Mig Admin",
        email: "enc:v1:not-really-sealed", // migration only touches avatarUrl
        role: "admin",
        active: true,
        avatarUrl: logoUrl,
      },
    });

    /* run 1 — both rows migrate */
    const first = await migrateImages(db);
    expect(first.sites).toBe(1);
    expect(first.admins).toBe(1);

    const siteRow = await db.site.findUnique({ where: { instanceId: instance.id } });
    const content = JSON.parse(siteRow?.contentJson ?? "{}") as {
      logoUrl?: string;
      tagline?: string;
      contactEmail?: string;
    };
    expect(content.logoUrl).toMatch(MANAGED_REF_RE);
    // other fields preserved by the re-serialization
    expect(content.tagline).toBe("kept");
    expect(content.contactEmail).toBe("kept@x.test");

    const adminRow = await db.adminUser.findUnique({ where: { username: "img-mig-admin" } });
    expect(adminRow?.avatarUrl ?? "").toMatch(MANAGED_REF_RE);

    // the converted asset exists as row + file
    const id = (content.logoUrl ?? "").slice("/api/images/".length);
    const assetRow = await db.imageAsset.findUnique({ where: { id } });
    expect(assetRow).not.toBeNull();
    expect(existsSync(join(storageImagesDir(), `${id}.webp`))).toBe(true);
    const asset = await getImageAsset(id);
    expect(asset).not.toBeNull();
    expect(asset?.buffer.length).toBeGreaterThan(0);

    /* run 2 — IDEMPOTENT: zero changes */
    const second = await migrateImages(db);
    expect(second.sites).toBe(0);
    expect(second.admins).toBe(0);
    expect(second.skipped).toBe(0);
    // the rows still hold the same refs
    const siteRow2 = await db.site.findUnique({ where: { instanceId: instance.id } });
    expect(JSON.parse(siteRow2?.contentJson ?? "{}").logoUrl).toBe(content.logoUrl);
  });

  test("dry run validates without writing rows", async () => {
    await db.site.deleteMany({});
    await db.adminUser.deleteMany({});
    await db.instance.deleteMany({});

    const logoUrl = await tinyPngDataUrl();
    const instance = await db.instance.create({
      data: {
        id: "img-dry-test-instance",
        systemId: "clinics-management",
        orgJson: JSON.stringify({ name: "Dry Clinic" }),
        adminJson: JSON.stringify({ name: "Owner", email: "owner@dry.test" }),
        prefsJson: JSON.stringify({ lang: "en" }),
        modulesJson: JSON.stringify([]),
      },
    });
    await db.site.create({
      data: {
        instanceId: instance.id,
        published: false,
        theme: "aurora",
        views: 0,
        contentJson: JSON.stringify({ tagline: "t", heroTitle: "h", logoUrl }),
      },
    });

    const before = await db.imageAsset.count();
    const report = await migrateImages(db, { dry: true });
    expect(report.sites).toBe(1);
    // DRY: the row was NOT rewritten
    const siteRow = await db.site.findUnique({ where: { instanceId: instance.id } });
    expect(JSON.parse(siteRow?.contentJson ?? "{}").logoUrl).toBe(logoUrl);
    // DRY: no file/asset was minted
    expect(await db.imageAsset.count()).toBe(before);
  });
});

/* ------------------------------------------------------------------ */
/* LIVE serving route (dev server :3000 — safe black-box probes)        */
/* ------------------------------------------------------------------ */

describe("image-store — LIVE /api/images/[id] serving (dev server)", () => {
  const BASE = "http://localhost:3000";

  async function serverReachable(): Promise<boolean> {
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 2000);
      try {
        const res = await fetch(`${BASE}/api/status`, { signal: controller.signal });
        return res.ok;
      } finally {
        clearTimeout(timer);
      }
    } catch {
      return false;
    }
  }

  test(
    "malformed id → 404; unknown well-shaped id → 404 (uniform, no oracle)",
    async () => {
      if (!(await serverReachable())) {
        console.log("SKIP — dev server not running");
        return;
      }
      // malformed: not 64-hex (path-traversal shape lives here too)
      const bad = await fetch(`${BASE}/api/images/zz`);
      expect(bad.status).toBe(404);
      expect(await bad.json()).toEqual({ error: "Not found" });
      // well-shaped but unknown asset — same uniform 404
      const unknown = await fetch(`${BASE}/api/images/${"a".repeat(64)}`);
      expect(unknown.status).toBe(404);
      expect(await unknown.json()).toEqual({ error: "Not found" });
    },
    30_000 // cold-compile allowance (dev server compiles the route on demand)
  );
});
