/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — PLATFORM SNAPSHOT HEALTH (ROUND 104).
 *
 * Proves the read-only verifier behind /api/status `backup` reports the
 * truth about the NEWEST platform snapshot. PostgreSQL snapshots
 * (database.dump, manifest databaseFormat "pg_dump-custom") and LEGACY
 * SQLite snapshots (database.db — pre-cutover archives that remain valid
 * DR artifacts) each verify through their format-appropriate battery:
 *
 * PG snapshots:
 *  - a healthy snapshot (real pg_dump custom archive + digest-true
 *    manifest + intact images) verifies ok with accurate age;
 *  - bit rot in the dump is caught by the manifest digest;
 *  - foreign bytes (no PGDMP magic) fail DATABASE_CORRUPT even with a
 *    recomputed digest (a torn write that also updated the manifest);
 *  - a missing dump member reports DATABASE_MISSING.
 *
 * LEGACY SQLite snapshots (the battery stays — the code keeps verifying
 * pre-cutover archives):
 *  - bit rot in the database copy is caught by the manifest digest
 *    (ROUND 104+ manifests) — not just at restore time;
 *  - a truncated/garbage SQLite file fails PRAGMA quick_check;
 *  - tampered or missing image bytes surface as CODE issues;
 *  - a missing manifest, a missing database, and an empty backups
 *    directory each produce their specific code — never a crash, never a
 *    path leak;
 *  - the 10-minute TTL cache serves the cached verdict and { force }
 *    re-verifies (the status route must not re-hash 6MB per poll).
 */

import { describe, expect, test, beforeAll, afterAll } from "bun:test";
import { mkdtempSync, rmSync, mkdirSync, writeFileSync, existsSync, readdirSync, readFileSync, copyFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import { Database } from "bun:sqlite";
import { ensureDemoEnv, getTestDb, TEST_DATABASE_URL } from "./test-setup";

ensureDemoEnv();
/* every fixture lives in its own throwaway storage root — the REAL
   storage/ tree (and the live snapshots inside it) is never touched */
const TMP = mkdtempSync(join(tmpdir(), "ashrilogic-snapshot-health-"));

let health: typeof import("@/lib/server/snapshot-health");

/** one REAL pg_dump custom archive shared by every PG case (built once
 *  in beforeAll against the throwaway test database). */
const PG_DUMP_FIXTURE = join(TMP, "pg-fixture.dump");

/** Build a complete, healthy PostgreSQL snapshot directory. */
function buildPgSnapshot(root: string, name: string, opts: { omitFormatField?: boolean } = {}): void {
  const dir = join(root, "backups", name);
  mkdirSync(join(dir, "images"), { recursive: true });

  /* a REAL pg_dump custom archive (PGDMP magic + a catalog pg_restore
   * can list) — the fixture is dumped once and copied per case */
  const dumpPath = join(dir, "database.dump");
  copyFileSync(PG_DUMP_FIXTURE, dumpPath);

  const dumpDigest = createHash("sha256").update(readFileSync(dumpPath)).digest("hex");

  const images: Array<{ file: string; sha256: string; bytes: number; verified: boolean }> = [];
  for (let i = 0; i < 2; i++) {
    const bytes = Buffer.from(`pg-image-${i}-bytes`);
    const digest = createHash("sha256").update(bytes).digest("hex");
    writeFileSync(join(dir, "images", `${digest}.webp`), bytes);
    images.push({ file: `${digest}.webp`, sha256: digest, bytes: bytes.length, verified: true });
  }

  writeFileSync(
    join(dir, "manifest.json"),
    JSON.stringify(
      {
        createdAt: new Date(Date.now() - 2 * 3_600_000).toISOString(),
        /* omitFormatField: dispatch by database.dump presence — the
           verifier's fallback for manifests without databaseFormat */
        ...(opts.omitFormatField ? {} : { databaseFormat: "pg_dump-custom" }),
        database: "database.dump",
        databaseSha256: dumpDigest,
        databaseBytes: 4096,
        images,
        imagesUnverified: 0,
      },
      null,
      2
    ),
    "utf8"
  );
}

/** Build a complete, healthy snapshot directory. */
function buildHealthySnapshot(root: string, name: string): void {
  const dir = join(root, "backups", name);
  mkdirSync(join(dir, "images"), { recursive: true });

  /* a REAL SQLite database (quick_check must pass) */
  const dbPath = join(dir, "database.db");
  const sqlite = new Database(dbPath);
  sqlite.exec("CREATE TABLE t (id INTEGER PRIMARY KEY, v TEXT)");
  sqlite.exec("INSERT INTO t (v) VALUES ('dr-artifact')");
  sqlite.close();

  const dbDigest = createHash("sha256").update(readFileSync(dbPath)).digest("hex");

  /* two content-addressed images with true digests */
  const images: Array<{ file: string; sha256: string; bytes: number; verified: boolean }> = [];
  for (let i = 0; i < 2; i++) {
    const bytes = Buffer.from(`image-${i}-bytes`);
    const digest = createHash("sha256").update(bytes).digest("hex");
    writeFileSync(join(dir, "images", `${digest}.webp`), bytes);
    images.push({ file: `${digest}.webp`, sha256: digest, bytes: bytes.length, verified: true });
  }

  writeFileSync(
    join(dir, "manifest.json"),
    JSON.stringify(
      {
        /* deterministic age: 2 hours in the past (the healthy-snapshot test
           asserts a ~2h age — same-millisecond fixtures make age 0) */
        createdAt: new Date(Date.now() - 2 * 3_600_000).toISOString(),
        database: "database.db",
        databaseSha256: dbDigest,
        databaseBytes: 8192,
        sourceDatabase: "/dev/null",
        images,
        rowCounts: { instances: 1 },
        imagesUnverified: 0,
      },
      null,
      2
    ),
    "utf8"
  );
}

beforeAll(async () => {
  health = await import("@/lib/server/snapshot-health");
  /* the healthy PG fixture needs a REAL pg_dump custom archive — built
   * ONCE against the throwaway test database (schema guaranteed by
   * getTestDb) so every PG case copies the same valid bytes */
  await getTestDb();
  execFileSync("pg_dump", ["--format=custom", `--file=${PG_DUMP_FIXTURE}`, TEST_DATABASE_URL], {
    stdio: "pipe",
  });
});

afterAll(() => {
  rmSync(TMP, { recursive: true, force: true });
});

describe("snapshot health — read-only verification of the newest platform snapshot", () => {
  test("healthy snapshot → ok:true, no issues, accurate age, cached then forced", async () => {
    const root = mkdtempSync(join(TMP, "case1-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root;
    buildHealthySnapshot(root, "ashrilogic-2026-09-18T00-00-00");
    health.clearSnapshotHealthCache();

    const first = await health.verifyLatestSnapshotHealth({ force: true });
    expect(first.ok).toBe(true);
    expect(first.issues).toEqual([]);
    expect(first.snapshot).toBe("ashrilogic-2026-09-18T00-00-00");
    expect(first.ageHours).toBeGreaterThan(1.9);
    expect(first.ageHours).toBeLessThan(2.1);

    /* cached call returns the SAME verdict object (no re-hash) */
    const cached = await health.verifyLatestSnapshotHealth();
    expect(cached.verifiedAt).toBe(first.verifiedAt);

    /* force bypasses the cache → fresh verifiedAt */
    const forced = await health.verifyLatestSnapshotHealth({ force: true });
    expect(forced.ok).toBe(true);
    expect(forced.verifiedAt).not.toBe(first.verifiedAt);
    rmSync(root, { recursive: true, force: true });
  });

  test("no backups directory → NO_SNAPSHOT (never a crash)", async () => {
    const root = mkdtempSync(join(TMP, "case2-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root;
    health.clearSnapshotHealthCache();
    const result = await health.verifyLatestSnapshotHealth({ force: true });
    expect(result.ok).toBe(false);
    expect(result.snapshot).toBe(null);
    expect(result.issues).toEqual(["NO_SNAPSHOT"]);
    rmSync(root, { recursive: true, force: true });
  });

  test("post-write bit rot in database.db → DATABASE_DIGEST_MISMATCH (quick_check may still pass)", async () => {
    const root = mkdtempSync(join(TMP, "case3-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root;
    buildHealthySnapshot(root, "ashrilogic-2026-09-18T01-00-00");
    health.clearSnapshotHealthCache();

    /* flip ONE byte inside the database file — SQLite may survive this
       (quick_check ok) but the manifest digest must catch it */
    const dbPath = join(root, "backups", "ashrilogic-2026-09-18T01-00-00", "database.db");
    const raw = readFileSync(dbPath);
    raw[raw.length - 1] = raw[raw.length - 1] ^ 0xff;
    writeFileSync(dbPath, raw);

    const result = await health.verifyLatestSnapshotHealth({ force: true });
    expect(result.ok).toBe(false);
    expect(result.issues).toContain("DATABASE_DIGEST_MISMATCH");
    rmSync(root, { recursive: true, force: true });
  });

  test("garbage database bytes → DATABASE_CORRUPT (quick_check fails)", async () => {
    const root = mkdtempSync(join(TMP, "case4-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root;
    buildHealthySnapshot(root, "ashrilogic-2026-09-18T02-00-00");
    health.clearSnapshotHealthCache();

    /* overwrite with bytes that are NOT a SQLite file at all; the manifest
       digest is recomputed to match so ONLY quick_check can catch this
       (simulates a torn write that also updated the manifest) */
    const dir = join(root, "backups", "ashrilogic-2026-09-18T02-00-00");
    const garbage = Buffer.from("definitely not a sqlite database".repeat(50));
    writeFileSync(join(dir, "database.db"), garbage);
    const manifest = JSON.parse(readFileSync(join(dir, "manifest.json"), "utf8"));
    manifest.databaseSha256 = createHash("sha256").update(garbage).digest("hex");
    writeFileSync(join(dir, "manifest.json"), JSON.stringify(manifest));

    const result = await health.verifyLatestSnapshotHealth({ force: true });
    expect(result.ok).toBe(false);
    expect(result.issues).toContain("DATABASE_CORRUPT");
    rmSync(root, { recursive: true, force: true });
  });

  test("tampered + missing images → IMAGE_DIGEST_MISMATCH / IMAGE_MISSING", async () => {
    const root = mkdtempSync(join(TMP, "case5-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root;
    buildHealthySnapshot(root, "ashrilogic-2026-09-18T03-00-00");
    health.clearSnapshotHealthCache();

    const imagesDir = join(root, "backups", "ashrilogic-2026-09-18T03-00-00", "images");
    const files = readdirSync(imagesDir).sort();
    writeFileSync(join(imagesDir, files[0]), Buffer.from("tampered"));
    rmSync(join(imagesDir, files[1]));

    const result = await health.verifyLatestSnapshotHealth({ force: true });
    expect(result.ok).toBe(false);
    expect(result.issues).toContain("IMAGE_MISSING");
    expect(result.issues).toContain("IMAGE_DIGEST_MISMATCH");
    rmSync(root, { recursive: true, force: true });
  });

  test("missing manifest → MANIFEST_INVALID; missing database → DATABASE_MISSING", async () => {
    const root = mkdtempSync(join(TMP, "case6-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root;
    buildHealthySnapshot(root, "ashrilogic-2026-09-18T04-00-00");
    health.clearSnapshotHealthCache();

    const dir = join(root, "backups", "ashrilogic-2026-09-18T04-00-00");
    rmSync(join(dir, "manifest.json"));
    let result = await health.verifyLatestSnapshotHealth({ force: true });
    expect(result.ok).toBe(false);
    expect(result.issues).toEqual(["MANIFEST_INVALID"]);

    /* rebuild a healthy snapshot, then remove ONLY the database file */
    const root2 = mkdtempSync(join(TMP, "case6b-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root2;
    buildHealthySnapshot(root2, "ashrilogic-2026-09-18T05-00-00");
    health.clearSnapshotHealthCache();
    rmSync(join(root2, "backups", "ashrilogic-2026-09-18T05-00-00", "database.db"));
    result = await health.verifyLatestSnapshotHealth({ force: true });
    expect(result.ok).toBe(false);
    expect(result.issues).toEqual(["DATABASE_MISSING"]);
    rmSync(root, { recursive: true, force: true });
    rmSync(root2, { recursive: true, force: true });
  });

  test("newest wins: an older broken snapshot never masks a healthy newest one", async () => {
    const root = mkdtempSync(join(TMP, "case7-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root;
    buildHealthySnapshot(root, "ashrilogic-2026-09-18T06-00-00");
    health.clearSnapshotHealthCache();

    /* older snapshot (earlier timestamp, earlier mtime) with NO manifest */
    const older = join(root, "backups", "ashrilogic-2026-09-17T06-00-00");
    mkdirSync(older, { recursive: true });

    const result = await health.verifyLatestSnapshotHealth({ force: true });
    expect(result.snapshot).toBe("ashrilogic-2026-09-18T06-00-00");
    expect(result.ok).toBe(true);
    expect(existsSync(older)).toBe(true); /* read-only: older dirs untouched */
    rmSync(root, { recursive: true, force: true });
  });

  test("legacy manifest without databaseSha256 still verifies (backward compatible)", async () => {
    const root = mkdtempSync(join(TMP, "case8-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root;
    buildHealthySnapshot(root, "ashrilogic-2026-09-18T07-00-00");
    health.clearSnapshotHealthCache();

    /* strip the ROUND 104 field — pre-104 manifests must still be healthy */
    const dir = join(root, "backups", "ashrilogic-2026-09-18T07-00-00");
    const manifest = JSON.parse(readFileSync(join(dir, "manifest.json"), "utf8"));
    delete manifest.databaseSha256;
    delete manifest.databaseBytes;
    writeFileSync(join(dir, "manifest.json"), JSON.stringify(manifest));

    const result = await health.verifyLatestSnapshotHealth({ force: true });
    expect(result.ok).toBe(true);
    expect(result.issues).toEqual([]);
    rmSync(root, { recursive: true, force: true });
  });
});

describe("snapshot health — PostgreSQL snapshots (database.dump, pg_dump-custom)", () => {
  test("healthy pg snapshot → ok:true, no DATABASE_* issues, accurate age", async () => {
    const root = mkdtempSync(join(TMP, "pg-case1-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root;
    buildPgSnapshot(root, "ashrilogic-2026-09-19T00-00-00");
    health.clearSnapshotHealthCache();

    const result = await health.verifyLatestSnapshotHealth({ force: true });
    expect(result.ok).toBe(true); /* advisory PG_RESTORE_UNAVAILABLE keeps ok true */
    expect(result.issues).not.toContain("DATABASE_MISSING");
    expect(result.issues).not.toContain("DATABASE_CORRUPT");
    expect(result.issues).not.toContain("DATABASE_DIGEST_MISMATCH");
    expect(result.snapshot).toBe("ashrilogic-2026-09-19T00-00-00");
    expect(result.ageHours).toBeGreaterThan(1.9);
    expect(result.ageHours).toBeLessThan(2.1);
    rmSync(root, { recursive: true, force: true });
  });

  test("dispatch by member presence: a manifest WITHOUT databaseFormat still routes database.dump to the pg battery", async () => {
    const root = mkdtempSync(join(TMP, "pg-case2-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root;
    buildPgSnapshot(root, "ashrilogic-2026-09-19T01-00-00", { omitFormatField: true });
    health.clearSnapshotHealthCache();

    const result = await health.verifyLatestSnapshotHealth({ force: true });
    expect(result.ok).toBe(true);
    expect(result.issues).not.toContain("DATABASE_CORRUPT"); /* not run through quick_check */
    rmSync(root, { recursive: true, force: true });
  });

  test("post-write bit rot in database.dump → DATABASE_DIGEST_MISMATCH", async () => {
    const root = mkdtempSync(join(TMP, "pg-case3-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root;
    buildPgSnapshot(root, "ashrilogic-2026-09-19T02-00-00");
    health.clearSnapshotHealthCache();

    /* flip ONE byte inside the archive — the manifest digest must catch it */
    const dumpPath = join(root, "backups", "ashrilogic-2026-09-19T02-00-00", "database.dump");
    const raw = readFileSync(dumpPath);
    raw[raw.length - 1] = raw[raw.length - 1] ^ 0xff;
    writeFileSync(dumpPath, raw);

    const result = await health.verifyLatestSnapshotHealth({ force: true });
    expect(result.ok).toBe(false);
    expect(result.issues).toContain("DATABASE_DIGEST_MISMATCH");
    rmSync(root, { recursive: true, force: true });
  });

  test("foreign bytes with a RECOMPUTED digest → DATABASE_CORRUPT (no PGDMP magic)", async () => {
    const root = mkdtempSync(join(TMP, "pg-case4-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root;
    buildPgSnapshot(root, "ashrilogic-2026-09-19T03-00-00");
    health.clearSnapshotHealthCache();

    /* overwrite with bytes that are NOT a pg_dump archive at all; the
       manifest digest is recomputed to match so ONLY the magic-byte check
       can catch this (a torn write that also updated the manifest) */
    const dir = join(root, "backups", "ashrilogic-2026-09-19T03-00-00");
    const garbage = Buffer.from("definitely not a pg_dump custom archive".repeat(50));
    writeFileSync(join(dir, "database.dump"), garbage);
    const manifest = JSON.parse(readFileSync(join(dir, "manifest.json"), "utf8"));
    manifest.databaseSha256 = createHash("sha256").update(garbage).digest("hex");
    writeFileSync(join(dir, "manifest.json"), JSON.stringify(manifest));

    const result = await health.verifyLatestSnapshotHealth({ force: true });
    expect(result.ok).toBe(false);
    expect(result.issues).toContain("DATABASE_CORRUPT");
    rmSync(root, { recursive: true, force: true });
  });

  test("missing database.dump member → DATABASE_MISSING", async () => {
    const root = mkdtempSync(join(TMP, "pg-case5-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root;
    buildPgSnapshot(root, "ashrilogic-2026-09-19T04-00-00");
    health.clearSnapshotHealthCache();

    rmSync(join(root, "backups", "ashrilogic-2026-09-19T04-00-00", "database.dump"));
    const result = await health.verifyLatestSnapshotHealth({ force: true });
    expect(result.ok).toBe(false);
    expect(result.issues).toEqual(["DATABASE_MISSING"]);
    rmSync(root, { recursive: true, force: true });
  });
});
