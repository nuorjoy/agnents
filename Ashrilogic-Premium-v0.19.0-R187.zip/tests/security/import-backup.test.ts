/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — TENANT BACKUP DR IMPORT (create-from-backup, ROUND 97).
 *
 * Proves the platform-side disaster-recovery path for a LOST Instance row:
 *  - a full tenant is re-created from its backup file (same instance id —
 *    /sites/<id> URLs and audit references stay stable) with a fresh sealed
 *    owner identity + fresh trial, and EVERY business field round-trips
 *    (customer addresses + payment metadata, order status timelines, sealed
 *    team profiles, reviews, coupons, image bytes);
 *  - the login candidate (adminEmailIndex blind index) resolves to the
 *    imported instance and the sealed adminJson carries the bootstrap email;
 *  - an existing instance REFUSES the import (the in-place restore endpoint
 *    is the only path for that case — never a silent merge);
 *  - a backup whose systemId is not in the catalog refuses (unknown-system);
 *  - sealed envelopes that do not open under the running key halt BEFORE
 *    anything is created (sealed-key-mismatch, zero rows written);
 *  - tampered image bytes halt BEFORE anything is created (image-checksum);
 *  - a restore failure AFTER the shell row exists triggers the COMPENSATING
 *    delete — the shell is removed, a foreign tenant's colliding row is
 *    untouched, and the failure lands in the audit trail;
 *  - bootstrap credentials are validated before any database access;
 *  - the import event is audited (instance.import — a SECURITY action).
 */

import { describe, expect, test, beforeAll, afterAll } from "bun:test";
import { mkdtempSync, rmSync, existsSync, unlinkSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createHash, randomBytes } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import { ensureDemoEnv, getTestDb, REPO_ROOT, type TestDb } from "./test-setup";
import { encryptField, decryptField } from "@/lib/server/crypto-vault";

ensureDemoEnv();
/* isolated storage for image files */
const TMP_STORAGE = mkdtempSync(join(tmpdir(), "ashrilogic-import-test-"));
process.env.ASHRILOGIC_STORAGE_DIR = TMP_STORAGE;

let db: TestDb;
let backup: typeof import("@/lib/server/backup");
let backupImport: typeof import("@/lib/server/backup-import");
let imageStore: typeof import("@/lib/server/image-store");
let instanceMapper: typeof import("@/lib/server/instance-mapper");

const NOW = new Date();
const iso = (d: Date) => d.toISOString();

const ACTOR = { actorType: "admin" as const, actorName: "import-test" };
const BOOT = { ownerEmail: "dr-owner@example.com", ownerPassword: "bootstrap-password-123" };

/** Seed a complete tenant (mirrors the backup-completeness fixture shapes). */
async function seedTenant(instanceId: string, systemId = "hospital-management"): Promise<string> {
  await db.instance.create({
    data: {
      id: instanceId,
      systemId,
      orgJson: JSON.stringify({ name: "DR Test Clinic" }),
      adminJson: JSON.stringify({ name: "Old Owner", email: "old-owner@example.com" }),
      prefsJson: JSON.stringify({ lang: "ar" }),
      modulesJson: JSON.stringify(["inventory"]),
      createdAt: NOW,
    },
  });
  await db.site.create({
    data: {
      id: `${instanceId}-site`,
      instanceId,
      published: true,
      theme: "aurora",
      views: 42,
      contentJson: JSON.stringify({ logoUrl: "" }),
      createdAt: NOW,
      updatedAt: NOW,
    },
  });
  await db.siteCustomer.create({
    data: {
      id: `${instanceId}-customer`,
      instanceId,
      name: "DR Customer",
      /* real AES-256-GCM envelopes — mirrors production rows */
      email: encryptField("dr-customer@example.com")!,
      emailIndex: "idx-dr-customer",
      phone: encryptField("+249900000000")!,
      passwordHash: "x",
      status: "active",
      emailVerifiedAt: NOW,
      lastLoginAt: NOW,
      addressesJson: JSON.stringify([
        { id: "addr1", label: "home", city: "Khartoum", isDefault: true },
      ]),
      paymentMethodsJson: JSON.stringify([
        { id: "pm1", brand: "visa", last4: "4242", expMonth: 12, expYear: 2030 },
      ]),
      createdAt: NOW,
      updatedAt: NOW,
    },
  });
  await db.siteOrder.create({
    data: {
      id: `${instanceId}-order`,
      instanceId,
      customerId: `${instanceId}-customer`,
      itemsJson: JSON.stringify([{ recordId: "r1", name: "Item", price: 1000, qty: 2 }]),
      total: 2000,
      currency: "SAR",
      status: "confirmed",
      note: "leave at door",
      statusNote: "called",
      discount: 200,
      couponCode: "DRSAVE",
      code: "A1B2C3",
      phoneIndex: "phone-idx",
      statusHistoryJson: JSON.stringify([
        { status: "pending", at: iso(NOW) },
        { status: "confirmed", at: iso(NOW) },
      ]),
      createdAt: NOW,
      updatedAt: NOW,
    },
  });
  await db.moduleRecord.create({
    data: {
      id: `${instanceId}-record`,
      instanceId,
      moduleId: "inventory",
      dataJson: JSON.stringify(["Item A", "5", "1000"]), /* array shape — the deep schema's parsedOrRaw(jsonArray) */
      statusKey: "in-stock",
      featured: true,
      salePrice: 900,
      createdAt: NOW,
      updatedAt: NOW,
    },
  });
  await db.teamMember.create({
    data: {
      id: `${instanceId}-member`,
      instanceId,
      name: "DR Team Member",
      email: encryptField("dr-member@example.com")!,
      role: "manager",
      profileJson: JSON.stringify({
        phone: encryptField("+249911111111")!,
        jobTitle: "HEAD",
      }),
      createdAt: NOW,
    },
  });
  await db.siteReview.create({
    data: {
      id: `${instanceId}-review`,
      instanceId,
      recordId: `${instanceId}-record`,
      rating: 5,
      name: "Reviewer",
      body: "great",
      hidden: false,
      authorIndex: "rev-idx",
      createdAt: NOW,
      updatedAt: NOW,
    },
  });
  await db.storeCoupon.create({
    data: {
      id: `${instanceId}-coupon`,
      instanceId,
      code: "DRSAVE",
      kind: "percent",
      value: 10,
      minSubtotal: null,
      maxUses: 100,
      usedCount: 3,
      startsAt: null,
      expiresAt: null,
      active: true,
      createdAt: NOW,
      updatedAt: NOW,
    },
  });
  return instanceId;
}

/** The DR event: deleting the Instance row cascades every tenant row away. */
async function loseInstance(instanceId: string): Promise<void> {
  await db.instance.delete({ where: { id: instanceId } });
}

beforeAll(async () => {
  db = await getTestDb();
  backup = await import("@/lib/server/backup");
  backupImport = await import("@/lib/server/backup-import");
  imageStore = await import("@/lib/server/image-store");
  instanceMapper = await import("@/lib/server/instance-mapper");
});

afterAll(() => {
  rmSync(TMP_STORAGE, { recursive: true, force: true });
});

describe("tenant backup DR import (create-from-backup)", () => {
  test("FULL DR round-trip: lost instance re-created from the file, every field back", async () => {
    const instanceId = await seedTenant("dr-import-inst-1");

    /* the operator's DR artifact */
    const envelope = await backup.buildInstanceBackup(instanceId);
    expect(envelope).not.toBeNull();

    /* the disaster: the instance row (and everything cascading from it) is gone */
    await loseInstance(instanceId);
    expect(await db.instance.count({ where: { id: instanceId } })).toBe(0);
    expect(await db.siteCustomer.count({ where: { instanceId } })).toBe(0);
    expect(await db.siteOrder.count({ where: { instanceId } })).toBe(0);
    expect(await db.site.count({ where: { instanceId } })).toBe(0);

    /* the recovery */
    const result = await backupImport.importInstanceBackup(envelope, {
      ...BOOT,
      actor: ACTOR,
    });
    if (!result.ok) console.error("IMPORT REASON:", result.reason);
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.instanceId).toBe(instanceId);
    expect(result.restored).toBe(6); /* record + customer + order + team + review + coupon (site rides separately) */
    expect(result.bootstrapEmail).toBe(BOOT.ownerEmail);

    /* every row is back with the SAME ids */
    const customer = await db.siteCustomer.findUniqueOrThrow({
      where: { id: `${instanceId}-customer` },
    });
    expect(customer.name).toBe("DR Customer");
    expect(decryptField(customer.email)).toBe("dr-customer@example.com");
    expect(JSON.parse(customer.addressesJson!)).toEqual([
      { id: "addr1", label: "home", city: "Khartoum", isDefault: true },
    ]);
    expect(JSON.parse(customer.paymentMethodsJson!)).toEqual([
      { id: "pm1", brand: "visa", last4: "4242", expMonth: 12, expYear: 2030 },
    ]);
    expect(customer.lastLoginAt?.toISOString()).toBe(NOW.toISOString());
    /* the restore engine assigns unusable credentials by design */
    expect(customer.passwordHash).not.toBe("x");

    const order = await db.siteOrder.findUniqueOrThrow({
      where: { id: `${instanceId}-order` },
    });
    expect(order.status).toBe("confirmed");
    expect(JSON.parse(order.statusHistoryJson!)).toHaveLength(2);
    expect(order.couponCode).toBe("DRSAVE");

    const member = await db.teamMember.findUniqueOrThrow({
      where: { id: `${instanceId}-member` },
    });
    expect(decryptField(member.email)).toBe("dr-member@example.com");
    expect(decryptField(JSON.parse(member.profileJson!).phone)).toBe("+249911111111");

    expect(
      await db.moduleRecord.count({ where: { instanceId } })
    ).toBe(1);
    const record = await db.moduleRecord.findUniqueOrThrow({
      where: { id: `${instanceId}-record` },
    });
    expect(record.featured).toBe(true);
    expect(record.salePrice).toBe(900);

    expect(
      await db.siteReview.count({ where: { instanceId } })
    ).toBe(1);
    expect(
      await db.storeCoupon.count({ where: { instanceId } })
    ).toBe(1);

    const site = await db.site.findUniqueOrThrow({ where: { instanceId } });
    expect(site.id).toBe(`${instanceId}-site`); /* SAME site id — URLs stable */
    expect(site.published).toBe(true);
    expect(site.views).toBe(42);

    /* the fresh owner identity: sealed adminJson + blind-index login candidate */
    const imported = await db.instance.findUniqueOrThrow({ where: { id: instanceId } });
    expect(imported.systemId).toBe("hospital-management");
    expect(imported.createdAt.toISOString()).toBe(NOW.toISOString()); /* business history preserved */
    expect(instanceMapper.readAdminEmail(imported.adminJson)).toBe(BOOT.ownerEmail);
    const candidate = await db.instance.findFirst({
      where: { adminEmailIndex: imported.adminEmailIndex },
      select: { id: true },
    });
    expect(candidate?.id).toBe(instanceId);
    /* entitlement levers never travel in the file — fresh trial, no package */
    expect(imported.packageId).toBeNull();
    expect(imported.trialEndsAt).not.toBeNull();

    /* the audit trail: import event (SECURITY) + the restore engine's own row */
    const importRows = await db.auditLog.findMany({
      where: { action: "instance.import", actorName: ACTOR.actorName },
    });
    expect(importRows.length).toBeGreaterThanOrEqual(1);
    expect(importRows.some((r) => r.metaJson?.includes('"outcome":"imported"') ?? false)).toBe(
      true
    );
    const restoreRows = await db.auditLog.count({ where: { action: "instance.restore" } });
    expect(restoreRows).toBeGreaterThanOrEqual(1);
  });

  test("an EXISTING instance refuses the import (in-place case → dashboard restore path)", async () => {
    const instanceId = "dr-import-inst-1"; /* exists from the round-trip above */
    const envelope = await backup.buildInstanceBackup(instanceId);
    expect(envelope).not.toBeNull();

    const result = await backupImport.importInstanceBackup(envelope, {
      ...BOOT,
      actor: ACTOR,
    });
    expect(result.ok).toBe(false);
    expect((result as { reason: string }).reason).toBe("instance-exists");
  });

  test("a systemId outside the catalog refuses (unknown-system)", async () => {
    const instanceId = await seedTenant("dr-import-inst-2", "not-a-real-system");
    const envelope = await backup.buildInstanceBackup(instanceId);
    expect(envelope).not.toBeNull();
    await loseInstance(instanceId);

    const result = await backupImport.importInstanceBackup(envelope, {
      ...BOOT,
      actor: ACTOR,
    });
    expect(result.ok).toBe(false);
    expect((result as { reason: string }).reason).toBe("unknown-system");
    expect(await db.instance.count({ where: { id: instanceId } })).toBe(0);
  });

  test("sealed envelopes the running key cannot open halt BEFORE anything is created", async () => {
    const instanceId = "dr-import-inst-1";
    const envelope = await backup.buildInstanceBackup(instanceId);
    expect(envelope).not.toBeNull();

    /* simulate a file produced under a DIFFERENT ASHRILOGIC_DATA_KEY:
       well-formed enc:v1: envelope whose GCM tag cannot verify (tampered
       ciphertext = the same auth-failure shape); checksum recomputed — the
       digest is unkeyed by design (see backup.ts header). */
    const bad = envelope!.sections.customers[0]!.emailSealed;
    envelope!.sections.customers[0]!.emailSealed = bad.slice(0, -8) + "AAAAAAAA";
    envelope!.meta.checksum = createHash("sha256")
      .update(JSON.stringify(envelope!.sections), "utf8")
      .digest("hex");

    /* the file still VERIFIES — the gate is import-side by design */
    expect((await backup.verifyBackupEnvelope(envelope)).ok).toBe(true);

    await loseInstance(instanceId);
    const result = await backupImport.importInstanceBackup(envelope, {
      ...BOOT,
      actor: ACTOR,
    });
    expect(result.ok).toBe(false);
    expect((result as { reason: string }).reason).toBe("sealed-key-mismatch");
    /* nothing was created — the gate ran before the shell */
    expect(await db.instance.count({ where: { id: instanceId } })).toBe(0);

    /* re-seed for the remaining tests */
    await seedTenant(instanceId);
  });

  test("restore failure AFTER shell creation → compensating rollback, foreign rows untouched", async () => {
    const instanceId = await seedTenant("dr-import-inst-3");
    const envelope = await backup.buildInstanceBackup(instanceId);
    expect(envelope).not.toBeNull();
    await loseInstance(instanceId);

    /* plant a COLLISION: another tenant holds a coupon row with the same PK —
       the restore transaction will fail on insert, AFTER the shell exists */
    const foreignHolder = "dr-import-inst-1"; /* exists (re-seeded above) */
    await db.storeCoupon.create({
      data: {
        id: `${instanceId}-coupon`,
        instanceId: foreignHolder,
        code: "FOREIGN",
        kind: "percent",
        value: 5,
        maxUses: 1,
        usedCount: 0,
        active: false,
        createdAt: NOW,
        updatedAt: NOW,
      },
    });

    const result = await backupImport.importInstanceBackup(envelope, {
      ...BOOT,
      actor: ACTOR,
    });
    expect(result.ok).toBe(false);
    expect((result as { reason: string }).reason).toBe("restore-failed");

    /* the shell was compensated away — database equals the pre-import state */
    expect(await db.instance.count({ where: { id: instanceId } })).toBe(0);
    expect(await db.siteCustomer.count({ where: { instanceId } })).toBe(0);
    /* the foreign row survived every step (scoped teardown + compensating delete) */
    const foreign = await db.storeCoupon.findUniqueOrThrow({
      where: { id: `${instanceId}-coupon` },
    });
    expect(foreign.instanceId).toBe(foreignHolder);

    /* the failure landed in the audit trail */
    const failedRows = await db.auditLog.findMany({
      where: { action: "instance.import" },
    });
    expect(
      failedRows.some((r) => r.metaJson?.includes('"outcome":"failed"') ?? false)
    ).toBe(true);

    /* cleanup the planted collision */
    await db.storeCoupon.delete({ where: { id: `${instanceId}-coupon` } });
  });

  test("image bytes travel + re-materialize end-to-end; tampered bytes abort BEFORE creation", async () => {
    const instanceId = "dr-import-inst-1";
    const bytes = randomBytes(2048);
    const stored = await imageStore.storeImageBuffer(bytes, {
      mime: "image/webp",
      width: 64,
      height: 64,
    });
    await db.moduleRecord.update({
      where: { id: `${instanceId}-record` },
      data: { imageRef: stored.url },
    });

    const envelope = await backup.buildInstanceBackup(instanceId);
    expect(envelope!.meta.imagesCount).toBe(1);
    expect(envelope!.meta.imagesMissing).toBe(0);
    expect(Buffer.from(envelope!.sections.images![0]!.dataBase64!, "base64").equals(bytes)).toBe(true);

    /* total loss: instance row AND the image row + file are gone */
    await loseInstance(instanceId);
    await db.imageAsset.delete({ where: { id: stored.id } });
    const imagePath = join(TMP_STORAGE, "images", `${stored.id}.webp`);
    if (existsSync(imagePath)) unlinkSync(imagePath);

    const result = await backupImport.importInstanceBackup(envelope!, {
      ...BOOT,
      actor: ACTOR,
    });
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.imagesRestored).toBe(1);
      expect(result.imagesMissing).toBe(0);
    }
    /* the asset row + content-addressed file are re-materialized from the file */
    const asset = await db.imageAsset.findUniqueOrThrow({ where: { id: stored.id } });
    expect(asset.mime).toBe("image/webp");
    expect(existsSync(imagePath)).toBe(true);
    const restored = await readFile(imagePath);
    expect(createHash("sha256").update(restored).digest("hex")).toBe(stored.id);

    /* tampered image bytes: checksum recomputed, still a "valid" file — the
       import-side image gate must abort BEFORE the shell is created */
    const envelope2 = await backup.buildInstanceBackup(instanceId);
    envelope2!.sections.images![0]!.dataBase64 = Buffer.concat([
      bytes.subarray(0, bytes.length - 4),
      Buffer.from("TAMPER"),
    ]).toString("base64");
    envelope2!.meta.checksum = createHash("sha256")
      .update(JSON.stringify(envelope2!.sections), "utf8")
      .digest("hex");

    await loseInstance(instanceId);
    const result2 = await backupImport.importInstanceBackup(envelope2!, {
      ...BOOT,
      actor: ACTOR,
    });
    expect(result2.ok).toBe(false);
    expect((result2 as { reason: string }).reason).toBe("image-checksum");
    expect(await db.instance.count({ where: { id: instanceId } })).toBe(0);

    /* re-seed for remaining assertions */
    await seedTenant(instanceId);
  });

  test("bootstrap credentials are validated BEFORE any database access", async () => {
    const envelope = await backup.buildInstanceBackup("dr-import-inst-1");
    expect(envelope).not.toBeNull();

    const weak = await backupImport.importInstanceBackup(envelope, {
      ownerEmail: BOOT.ownerEmail,
      ownerPassword: "short",
      actor: ACTOR,
    });
    expect(weak.ok).toBe(false);
    expect((weak as { reason: string }).reason).toBe("weak-password");

    const badEmail = await backupImport.importInstanceBackup(envelope, {
      ownerEmail: "not-an-email",
      ownerPassword: BOOT.ownerPassword,
      actor: ACTOR,
    });
    expect(badEmail.ok).toBe(false);
    expect((badEmail as { reason: string }).reason).toBe("bad-email");
  });

  test("CLI dry-run (subprocess): verifies, plans, and writes NOTHING", async () => {
    const instanceId = await seedTenant("dr-cli-inst");
    const envelope = await backup.buildInstanceBackup(instanceId);
    expect(envelope).not.toBeNull();
    /* the DR state: the instance row is lost, only the file remains */
    await loseInstance(instanceId);

    const tmpFile = join(TMP_STORAGE, "dr-cli-backup.json");
    await writeFile(tmpFile, JSON.stringify(envelope));

    /* subprocess with the fixture DATABASE_URL + demo env (the child's bun
       auto-loads .env but pre-set process env wins — same contract as the
       re-seal suite) */
    const proc = Bun.spawn(
      ["bun", "scripts/import-backup.ts", tmpFile, "--email", "cli-owner@example.com", "--gen"],
      {
        cwd: REPO_ROOT,
        env: { ...process.env },
        stdout: "pipe",
        stderr: "pipe",
      }
    );
    const out = await new Response(proc.stdout).text();
    const err = await new Response(proc.stderr).text();
    const code = await proc.exited;
    const combined = out + err;

    expect(code).toBe(0);
    expect(combined).toContain("envelope: VERIFIED");
    expect(combined).toContain("DRY-RUN PLAN");
    expect(combined).toContain("dr-cli-inst");
    expect(combined).toContain("Run again with --confirm");
    /* a dry-run performs ZERO writes — the instance row is still absent */
    expect(await db.instance.count({ where: { id: instanceId } })).toBe(0);

    /* --confirm on an EXISTING instance refuses deterministically (no app
       dependency — this is the in-place case, checked BEFORE the port probe):
       exit 1 with the dashboard-restore guidance */
    const keepId = "dr-cli-keep";
    await seedTenant(keepId);
    const keepEnvelope = await backup.buildInstanceBackup(keepId);
    const keepFile = join(TMP_STORAGE, "dr-cli-keep.json");
    await writeFile(keepFile, JSON.stringify(keepEnvelope));
    const procKeep = Bun.spawn(
      ["bun", "scripts/import-backup.ts", keepFile, "--email", "x@example.com", "--gen", "--confirm"],
      { cwd: REPO_ROOT, env: { ...process.env }, stdout: "pipe", stderr: "pipe" }
    );
    const keepErr = await new Response(procKeep.stderr).text();
    const keepCode = await procKeep.exited;
    expect(keepCode).toBe(1);
    expect(keepErr).toContain("ALREADY EXISTS");
    expect(keepErr).toContain("restore");

    /* --confirm with the app RUNNING refuses at the port probe — verified
       only when the dev server is actually up (this sandbox: yes; when it is
       down the case is skipped rather than performing a real import) */
    let appUp = false;
    try {
      appUp = (await fetch("http://localhost:3000/api/status", { signal: AbortSignal.timeout(2000) })).ok;
    } catch {
      appUp = false;
    }
    if (appUp) {
      const proc2 = Bun.spawn(
        ["bun", "scripts/import-backup.ts", tmpFile, "--email", "cli-owner@example.com", "--gen", "--confirm"],
        { cwd: REPO_ROOT, env: { ...process.env }, stdout: "pipe", stderr: "pipe" }
      );
      const err2 = await new Response(proc2.stderr).text();
      const code2 = await proc2.exited;
      expect(code2).toBe(1);
      expect(err2).toContain("RUNNING");
    } else {
      console.warn("dev server down — CLI port-probe refusal case skipped");
    }
    expect(await db.instance.count({ where: { id: instanceId } })).toBe(0);
  });

  test("CLI --confirm (--force): pre-import platform snapshot, full import, rollback instructions", async () => {
    /* the FULL --confirm write path — the pre-import safety snapshot is
     * runPlatformBackup() (pg_dump custom format, the PG-native rollback
     * artifact that replaced the SQLite-era VACUUM INTO): fail-closed, it
     * must exist BEFORE anything is written, and the report must point at
     * the platform-restore runbook. --force skips the :3000 port probe
     * (this sandbox's :3000 is an unrelated preview server; in CI no
     * server runs and the flag is a harmless no-op). */
    const instanceId = "dr-cli-confirm-inst";
    await seedTenant(instanceId);
    const envelope = await backup.buildInstanceBackup(instanceId);
    expect(envelope).not.toBeNull();
    await loseInstance(instanceId);

    const tmpFile = join(TMP_STORAGE, "dr-cli-confirm.json");
    await writeFile(tmpFile, JSON.stringify(envelope));

    const proc = Bun.spawn(
      [
        "bun",
        "scripts/import-backup.ts",
        tmpFile,
        "--email",
        "confirm-owner@example.com",
        "--gen",
        "--confirm",
        "--force",
      ],
      { cwd: REPO_ROOT, env: { ...process.env }, stdout: "pipe", stderr: "pipe" }
    );
    const out = await new Response(proc.stdout).text();
    const err = await new Response(proc.stderr).text();
    const code = await proc.exited;
    const combined = out + err;

    expect(code).toBe(0);
    expect(combined).toContain("IMPORT SUCCEEDED");
    /* the pre-import snapshot was taken and reported */
    expect(combined).toContain("pre-import snapshot:");
    expect(combined).toContain("platform-restore.ts --restore");
    expect(combined).toContain("confirm-owner@example.com");

    /* the snapshot is a REAL pg_dump artifact under the fixture storage
     * root: database.dump + manifest (databaseFormat pg_dump-custom) */
    const { readdirSync } = await import("node:fs");
    const snapshots = readdirSync(join(TMP_STORAGE, "backups")).filter((d) =>
      /^ashrilogic-\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}$/.test(d)
    );
    expect(snapshots.length).toBeGreaterThanOrEqual(1);
    const snapDir = join(TMP_STORAGE, "backups", snapshots[snapshots.length - 1]!);
    expect(existsSync(join(snapDir, "database.dump"))).toBe(true);
    const manifest = JSON.parse(await readFile(join(snapDir, "manifest.json"), "utf8")) as {
      databaseFormat?: string;
    };
    expect(manifest.databaseFormat).toBe("pg_dump-custom");

    /* the import really happened — the tenant is back from the file */
    expect(await db.instance.count({ where: { id: instanceId } })).toBe(1);
    expect(await db.siteCustomer.count({ where: { instanceId } })).toBe(1);

    /* cleanup this case's rows (AuditLog is append-only by design) */
    await db.instance.delete({ where: { id: instanceId } });
    expect(await db.instance.count({ where: { id: instanceId } })).toBe(0);
  });
});
