/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — module-record product-photo field (ROUND 51).
 *
 * Pins under test:
 *  - the `image` field on module-record write bodies accepts EXACTLY three
 *    shapes: undefined (absent), "" (explicit clear), a managed
 *    /api/images/<64hex> ref (editor echo), or a well-formed image data-URL
 *    (fresh upload — the server re-encodes it via the sharp pipeline);
 *  - everything else — cross-origin URLs, relative paths, javascript: URIs,
 *    non-image data-URLs, uppercase/short/garbage hex ids, oversized
 *    payloads — is rejected by the zod schema (422 before any handler runs);
 *  - resolveRecordImage keeps the stored ref untouched when the field is
 *    absent, clears on "", and persists managed refs VERBATIM;
 *  - a data-URL that survives the shape check but fails the sharp pipeline
 *    surfaces ImageValidationError (callers map it to a 400).
 */
import { describe, test, expect } from "bun:test";
import {
  moduleRecordCreateSchema,
  moduleRecordUpdateSchema,
} from "@/lib/server/module-record-mapper";
import {
  isRecordImageDataUrl,
  isManagedImageRef,
  resolveRecordImage,
} from "@/lib/server/record-image";

const HEX64 = "a".repeat(64);
const MANAGED = `/api/images/${HEX64}`;
const PNG_DATA_URL = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==";

describe("module-record image — accepted shapes", () => {
  test("absent (undefined) passes the create schema", () => {
    const parsed = moduleRecordCreateSchema.safeParse({
      moduleId: "menu",
      values: ["شاي كرك", "مشروبات", "10", "45.00"],
      statusKey: "instock",
    });
    expect(parsed.success).toBe(true);
    if (parsed.success) expect(parsed.data.image).toBeUndefined();
  });

  test("empty string (explicit clear) passes", () => {
    const parsed = moduleRecordUpdateSchema.safeParse({ image: "" });
    expect(parsed.success).toBe(true);
  });

  test("a managed /api/images/<64hex> ref passes", () => {
    const parsed = moduleRecordUpdateSchema.safeParse({ image: MANAGED });
    expect(parsed.success).toBe(true);
    if (parsed.success) expect(parsed.data.image).toBe(MANAGED);
  });

  test("a well-formed image data-URL passes", () => {
    const parsed = moduleRecordUpdateSchema.safeParse({ image: PNG_DATA_URL });
    expect(parsed.success).toBe(true);
  });

  test("image-only PATCH satisfies the at-least-one-field refine", () => {
    const parsed = moduleRecordUpdateSchema.safeParse({ image: MANAGED });
    expect(parsed.success).toBe(true);
  });
});

describe("module-record image — rejected shapes (422 surface)", () => {
  const bad = (image: unknown) =>
    moduleRecordUpdateSchema.safeParse({ image });

  test("cross-origin https URL", () => {
    expect(bad("https://evil.example/x.png").success).toBe(false);
  });

  test("relative path / path traversal", () => {
    expect(bad("/etc/passwd").success).toBe(false);
    expect(bad("../../storage/images/x.webp").success).toBe(false);
  });

  test("javascript: URI", () => {
    expect(bad("javascript:alert(1)").success).toBe(false);
  });

  test("non-image data-URL (text/html polyglot)", () => {
    expect(bad("data:text/html;base64,PHNjcmlwdD4=").success).toBe(false);
  });

  test("managed ref with UPPERCASE hex", () => {
    expect(bad(`/api/images/${"A".repeat(64)}`).success).toBe(false);
  });

  test("managed ref with short hex", () => {
    expect(bad(`/api/images/${"a".repeat(32)}`).success).toBe(false);
  });

  test("managed ref with extra segments", () => {
    expect(bad(`/api/images/${HEX64}/../${HEX64}`).success).toBe(false);
  });

  test("bare 64-hex id without the /api/images prefix", () => {
    expect(bad(HEX64).success).toBe(false);
  });

  test("oversized data-URL payload (> 1.5M chars)", () => {
    const big = `data:image/png;base64,${"A".repeat(1_500_001)}`;
    expect(bad(big).success).toBe(false);
  });

  test("empty-ish garbage strings", () => {
    expect(bad("   ").success).toBe(false);
    expect(bad("not-an-image").success).toBe(false);
  });
});

describe("module-record image — resolver semantics (ROUND 120: echoes require LIVE asset rows)", () => {
  test("undefined keeps the stored ref (no change)", async () => {
    const r = await resolveRecordImage(undefined, MANAGED);
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.imageRef).toBe(MANAGED);
      expect(r.changed).toBe(false);
    }
  });

  test("empty string clears the stored ref", async () => {
    const r = await resolveRecordImage("", MANAGED);
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.imageRef).toBeNull();
      expect(r.changed).toBe(true);
    }
  });

  test("clearing an already-empty ref reports no change", async () => {
    const r = await resolveRecordImage("", null);
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.imageRef).toBeNull();
      expect(r.changed).toBe(false);
    }
  });

  test("managed ref echoes VERBATIM when the asset row EXISTS (byte-identical idempotence)", async () => {
    /* ROUND 120 — the write-side guard: an echo whose ImageAsset row was
     * GC'd is REFUSED (IMAGE_GONE); a live row echoes verbatim */
    const other = `/api/images/${"b".repeat(64)}`;
    await seedAssetRow("b".repeat(64));
    const r = await resolveRecordImage(other, MANAGED);
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.imageRef).toBe(other);
      expect(r.changed).toBe(true);
    }
    await cleanupAssetRows();
  });

  test("ROUND 120 — an echo whose asset row is GONE is refused (IMAGE_GONE), never a dangling ref", async () => {
    const ghost = `/api/images/${"c".repeat(64)}`;
    const r = await resolveRecordImage(ghost, null);
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.code).toBe("IMAGE_GONE");
  });

  test("a data-URL upload stores a fresh managed ref", async () => {
    const r = await resolveRecordImage(PNG_DATA_URL, null);
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.imageRef).toMatch(/^\/api\/images\/[a-f0-9]{64}$/);
      expect(r.changed).toBe(true);
    }
  });

  test("a data-URL failing the sharp pipeline surfaces ImageValidationError", async () => {
    const notAnImage = "data:image/png;base64,aGVsbG8gd29ybGQ="; /* "hello world" */
    let threw = false;
    try {
      await resolveRecordImage(notAnImage, null);
    } catch (error) {
      threw = error instanceof Error && error.name === "ImageValidationError";
    }
    expect(threw).toBe(true);
  });
});

/* db fixtures for the resolver-semantics describe (the write-side guard
 * reads ImageAsset — the ROUND 120 contract) */
import { ensureDemoEnv, getTestDb, type TestDb } from "./test-setup";
ensureDemoEnv();
let __db: TestDb | null = null;
async function testDb(): Promise<TestDb> {
  if (!__db) __db = await getTestDb();
  return __db;
}
async function seedAssetRow(id: string): Promise<void> {
  const db = await testDb();
  await db.imageAsset.deleteMany({ where: { id } });
  await db.imageAsset.create({
    data: { id, mime: "image/webp", width: 1, height: 1, bytes: 1 },
  });
}
async function cleanupAssetRows(): Promise<void> {
  const db = await testDb();
  await db.imageAsset.deleteMany({ where: { id: "b".repeat(64) } });
}
