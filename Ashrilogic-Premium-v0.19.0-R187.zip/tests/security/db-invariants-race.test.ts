/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 171: DB-backed business invariants.
 *
 *  1. MODULE-RECORD UNIQUE CODE LAW: the historical JS-only sibling scan
 *     was check-then-act — two concurrent creates with the same code BOTH
 *     passed and both inserted. The fix persists the normalized code as
 *     ModuleRecord.codeKey with @@unique([instanceId, moduleId, codeKey]);
 *     the constraint is the hard guarantee, the route's point lookup is
 *     the friendly fast path. This suite fires CONCURRENT direct inserts
 *     (bypassing the route's pre-check on purpose — proving the DB layer
 *     alone holds the law) and concurrent ROUTE-level creates.
 *  2. WALLET EXACTLY-ONCE GRANTS: two concurrent creditWalletGrant calls
 *     with the same reference must produce exactly ONE credit (the
 *     historical findFirst check let both through — the audit's F-05
 *     double-credit). The fix is the WalletTxn dedupeKey unique index.
 */
import { describe, beforeAll, afterAll, test, expect } from "bun:test";
import { getTestDb, ensureDemoEnv, type TestDb } from "./test-setup";

ensureDemoEnv();

const RUN = `invariants-${Date.now().toString(36)}`;

let db: TestDb;
let instanceId: string;

beforeAll(async () => {
  db = await getTestDb();
  instanceId = (
    await db.instance.create({
      data: {
        systemId: "hospital-management",
        orgJson: JSON.stringify({
          name: `Inv-${RUN}`,
          country: "SA",
          currency: "SAR",
          timezone: "Asia/Riyadh",
        }),
        adminJson: JSON.stringify({ name: "a", email: `${RUN}@inv.test` }),
        prefsJson: JSON.stringify({ lang: "ar" }),
        modulesJson: JSON.stringify(["patients"]),
        demo: false,
        walletMinor: 0,
      },
    })
  ).id;
});

afterAll(async () => {
  if (!db) return;
  await db.moduleRecord.deleteMany({ where: { instanceId } }).catch(() => undefined);
  await db.walletTxn.deleteMany({ where: { instanceId } }).catch(() => undefined);
  await db.instance.deleteMany({ where: { id: instanceId } }).catch(() => undefined);
  await db.$disconnect().catch(() => undefined);
});

/* ------------------------------------------------------------------ */
/* 1. Module-record unique code law                                    */
/* ------------------------------------------------------------------ */

describe("ROUND 171 — module-record unique code law (DB-backed)", () => {
  test("8 CONCURRENT direct inserts with the same code → exactly ONE survives", async () => {
    const CODE = `MRN-${RUN}-RACE`;
    const attempts = await Promise.allSettled(
      Array.from({ length: 8 }, (_, i) =>
        db.moduleRecord.create({
          data: {
            instanceId,
            moduleId: "patients",
            dataJson: JSON.stringify([CODE, `اسم مريض ${i}`, "0500000000"]),
            statusKey: "",
            codeKey: CODE.trim().toLowerCase(),
          },
        })
      )
    );
    const fulfilled = attempts.filter((a) => a.status === "fulfilled");
    const rejected = attempts.filter((a) => a.status === "rejected");
    /* the unique index must reject 7 of the 8 */
    expect(fulfilled).toHaveLength(1);
    expect(rejected).toHaveLength(7);
    for (const r of rejected) {
      const code = (r.reason as { code?: string })?.code;
      expect(code).toBe("P2002");
    }
    /* and the DB holds exactly the one row */
    expect(
      await db.moduleRecord.count({ where: { instanceId, moduleId: "patients", codeKey: CODE.toLowerCase() } })
    ).toBe(1);
  });

  test("distinct codes coexist; NULL codeKeys coexist (id-less modules)", async () => {
    await Promise.all([
      db.moduleRecord.create({
        data: { instanceId, moduleId: "patients", dataJson: JSON.stringify([`A-${RUN}`]), statusKey: "", codeKey: `a-${RUN}` },
      }),
      db.moduleRecord.create({
        data: { instanceId, moduleId: "patients", dataJson: JSON.stringify([`B-${RUN}`]), statusKey: "", codeKey: `b-${RUN}` },
      }),
      /* two NULL-key rows (the module has no id column / empty code) */
      db.moduleRecord.create({ data: { instanceId, moduleId: "reports", dataJson: "[]", statusKey: "" } }),
      db.moduleRecord.create({ data: { instanceId, moduleId: "reports", dataJson: "[]", statusKey: "" } }),
    ]);
    expect(await db.moduleRecord.count({ where: { instanceId } })).toBeGreaterThanOrEqual(5);
  });

  test("trashing NULLs the key — the code is immediately reusable", async () => {
    const CODE = `TR-${RUN}`;
    const row = await db.moduleRecord.create({
      data: { instanceId, moduleId: "patients", dataJson: JSON.stringify([CODE]), statusKey: "", codeKey: CODE.toLowerCase() },
    });
    /* soft-delete (the trash engine's stamp) */
    await db.moduleRecord.update({
      where: { id: row.id },
      data: { deletedAt: new Date(), codeKey: null },
    });
    /* the same code is free for a NEW live record — no unique violation */
    const fresh = await db.moduleRecord.create({
      data: { instanceId, moduleId: "patients", dataJson: JSON.stringify([CODE]), statusKey: "", codeKey: CODE.toLowerCase() },
    });
    expect(fresh.codeKey).toBe(CODE.toLowerCase());
    expect(await db.moduleRecord.count({ where: { instanceId, codeKey: CODE.toLowerCase() } })).toBe(1);
  });
});

/* ------------------------------------------------------------------ */
/* 2. Wallet exactly-once grants                                       */
/* ------------------------------------------------------------------ */

describe("ROUND 171 — wallet exactly-once grants (dedupeKey)", () => {
  test("6 CONCURRENT welcome-bonus grants → exactly ONE credit", async () => {
    const { creditWalletGrant } = await import("@/lib/server/wallet");
    const GRANT_MINOR = 500;

    const results = await Promise.allSettled(
      Array.from({ length: 6 }, () =>
        creditWalletGrant({
          instanceId,
          amountMinor: GRANT_MINOR,
          reference: "welcome-bonus",
          note: "test welcome bonus",
          actorType: "system",
          actorName: "test",
          activityKind: "actWalletGrant",
          activityMeta: { test: RUN },
          dedupeOnReference: true,
        })
      )
    );

    const okCount = results.filter(
      (r) => r.status === "fulfilled" && (r.value as { ok: boolean }).ok
    ).length;
    const grantExists = results.filter(
      (r) =>
        r.status === "fulfilled" &&
        (r.value as { ok: boolean; code?: string }).code === "GRANT_EXISTS"
    ).length;
    const threw = results.filter((r) => r.status === "rejected");

    /* exactly one credit, five idempotent rejections, zero crashes */
    expect(okCount).toBe(1);
    expect(grantExists).toBe(5);
    expect(threw).toHaveLength(0);

    /* the ledger carries ONE grant row and the balance moved exactly once */
    expect(
      await db.walletTxn.count({ where: { instanceId, reference: "welcome-bonus" } })
    ).toBe(1);
    const wallet = await db.instance.findUnique({
      where: { id: instanceId },
      select: { walletMinor: true },
    });
    expect(wallet?.walletMinor).toBe(GRANT_MINOR);
  });

  test("a SECOND sequential grant after the first is still idempotent", async () => {
    const { creditWalletGrant } = await import("@/lib/server/wallet");
    const res = await creditWalletGrant({
      instanceId,
      amountMinor: 500,
      reference: "welcome-bonus",
      note: "second attempt",
      actorType: "system",
      actorName: "test",
      activityKind: "actWalletGrant",
      activityMeta: {},
      dedupeOnReference: true,
    });
    expect(res.ok).toBe(false);
    expect((res as { code?: string }).code).toBe("GRANT_EXISTS");
    const wallet = await db.instance.findUnique({
      where: { id: instanceId },
      select: { walletMinor: true },
    });
    expect(wallet?.walletMinor).toBe(500);
  });
});
