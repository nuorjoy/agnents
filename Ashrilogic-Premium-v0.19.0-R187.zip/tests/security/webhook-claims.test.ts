/// <reference types="bun-types" />
/**
 * Ashrilogic — ROUND 137 reliability regression: WEBHOOK ATOMIC CLAIMS
 * (Phase 3).
 *
 * The R120 dispatcher protected only the RESULT write (attempts-CAS):
 * two workers could still TRANSPORT the same delivery concurrently —
 * the receiver got two POSTs and one verdict was silently dropped.
 * The claim-based dispatcher now CAS-es a due row into `processing`
 * (leaseId + workerId + lockedUntil + startedAt) BEFORE the transport;
 * the settle is lease-scoped. Proven here:
 *
 *   1. CONCURRENT WORKERS — exactly one transport per delivery;
 *   2. LEASE EXPIRY TAKEOVER — an expired `processing` row is claimable
 *      (crash recovery) and re-sent;
 *   3. LEASE-LOST SETTLE — the dispossessed worker's verdict is
 *      discarded by the lease predicate;
 *   4. IDENTITY HEADERS — x-ashrilogic-delivery + x-ashrilogic-attempt
 *      ride every attempt (receiver-side dedupe);
 *   5. JITTERED BACKOFF — the retry delay is bounded in
 *      [base, base·(1+jitter)];
 *   6. endpoint-disabled settles clear the lease (no stuck rows).
 */
import { describe, test, expect, beforeAll, afterAll } from "bun:test";
import { ensureDemoEnv, getTestDb } from "./test-setup";

ensureDemoEnv();

let db: Awaited<ReturnType<typeof getTestDb>>;
let webhooks: typeof import("@/lib/server/webhooks");

const INSTANCE = "webhook-claims-instance";
const NOW = new Date();

interface Captured {
  url: string;
  headers: Record<string, string>;
}
const calls: Captured[] = [];

beforeAll(async () => {
  db = await getTestDb();
  webhooks = await import("@/lib/server/webhooks");
  webhooks.__setWebhookDnsForTests(async () => [{ address: "93.184.216.34", family: 4 }]);
  await db.instance.create({
    data: {
      id: INSTANCE,
      systemId: "inventory",
      orgJson: JSON.stringify({ name: "Claims Test", currency: "SAR" }),
      adminJson: "{}",
      adminEmailIndex: "claims@test",
      prefsJson: "{}",
      modulesJson: JSON.stringify(["inventory"]),
    },
  });
});

afterAll(async () => {
  webhooks.__setWebhookTransportForTests(null);
  webhooks.__setWebhookDnsForTests(null);
  try {
    await db.instance.deleteMany({ where: { id: INSTANCE } });
    await db.webhookEndpoint.deleteMany({});
    await db.webhookDelivery.deleteMany({});
  } catch {
    /* throwaway DB */
  }
});

/** a healthy https endpoint fixture */
async function makeEndpoint(id: string): Promise<string> {
  await db.webhookEndpoint.create({
    data: {
      id,
      instanceId: INSTANCE,
      url: "https://example.com/webhook",
      secret: "s".repeat(64),
      eventsJson: JSON.stringify(["order.placed"]),
    },
  });
  return id;
}

async function makeDelivery(endpointId: string): Promise<string> {
  const row = await db.webhookDelivery.create({
    data: {
      endpointId,
      instanceId: INSTANCE,
      event: "order.placed",
      payloadJson: webhooks.buildWebhookPayload(INSTANCE, "order.placed", { id: "o1" }),
      status: "pending",
    },
  });
  return row.id;
}

/* ------------------------------------------------------------------ */
/* 1 — concurrent workers                                              */
/* ------------------------------------------------------------------ */

describe("ROUND 137 — atomic claims: concurrent workers", () => {
  test("two racing dispatchers: exactly ONE transport fires, one claim wins", async () => {
    await makeEndpoint("ep-claims-race");
    const deliveryId = await makeDelivery("ep-claims-race");
    calls.length = 0;

    /* a GATED transport: worker #1 enters the transport and blocks until
     * released — the perfect window for a second dispatcher to try the
     * same row */
    let release: (() => void) | null = null;
    const gate = new Promise<void>((resolve) => {
      release = resolve;
    });
    webhooks.__setWebhookTransportForTests(async (url, headers) => {
      calls.push({ url, headers });
      await gate;
      return { ok: true, status: 200 };
    });

    const worker1 = webhooks.dispatchDueWebhooks(); /* NOT awaited yet */
    await new Promise((r) => setTimeout(r, 150)); /* let #1 claim + enter the transport */

    const midRow = await db.webhookDelivery.findUnique({ where: { id: deliveryId } });
    expect(midRow?.status).toBe("processing");
    expect(midRow?.leaseId).toBeTruthy();
    expect(midRow?.workerId).toBeTruthy();
    expect(midRow?.startedAt).toBeTruthy();
    expect(midRow?.lockedUntil).toBeTruthy();

    const worker2Count = await webhooks.dispatchDueWebhooks(); /* racing worker */
    expect(worker2Count).toBe(0); /* the claim is live — nothing to take */
    expect(calls.length).toBe(1); /* ONE transport, not two */

    (release as unknown as () => void)();
    const worker1Count = await worker1;
    expect(worker1Count).toBe(1);

    const final = await db.webhookDelivery.findUnique({ where: { id: deliveryId } });
    expect(final?.status).toBe("succeeded");
    expect(final?.attempts).toBe(1);
    expect(final?.leaseId).toBeNull();
    expect(final?.lockedUntil).toBeNull();
  });

  test("identity headers: every attempt carries delivery id + attempt number", async () => {
    await makeEndpoint("ep-claims-headers");
    const deliveryId = await makeDelivery("ep-claims-headers");
    calls.length = 0;
    webhooks.__setWebhookTransportForTests(async (url, headers) => {
      calls.push({ url, headers });
      return { ok: true, status: 200 };
    });
    await webhooks.dispatchDueWebhooks();
    expect(calls.length).toBe(1);
    expect(calls[0]!.headers["x-ashrilogic-delivery"]).toBe(deliveryId);
    expect(calls[0]!.headers["x-ashrilogic-attempt"]).toBe("1");
    expect(calls[0]!.headers["x-ashrilogic-event"]).toBe("order.placed");
    expect(typeof calls[0]!.headers["x-ashrilogic-signature"]).toBe("string");
  });
});

/* ------------------------------------------------------------------ */
/* 2 — lease expiry takeover (crash recovery)                          */
/* ------------------------------------------------------------------ */

describe("ROUND 137 — atomic claims: crash recovery", () => {
  test("an EXPIRED processing lease is reclaimed and re-sent", async () => {
    await makeEndpoint("ep-claims-expiry");
    const deliveryId = await makeDelivery("ep-claims-expiry");
    /* simulate a crashed worker: processing with a long-past lease */
    await db.webhookDelivery.update({
      where: { id: deliveryId },
      data: {
        status: "processing",
        leaseId: "lease-of-the-crashed",
        workerId: "worker-crashed",
        startedAt: new Date(NOW.getTime() - 120_000),
        lockedUntil: new Date(NOW.getTime() - 60_000), /* expired */
        attempts: 0,
      },
    });

    calls.length = 0;
    webhooks.__setWebhookTransportForTests(async (url, headers) => {
      calls.push({ url, headers });
      return { ok: true, status: 200 };
    });
    const count = await webhooks.dispatchDueWebhooks();
    expect(count).toBe(1); /* the takeover claim landed */
    expect(calls.length).toBe(1);
    expect(calls[0]!.headers["x-ashrilogic-attempt"]).toBe("1");

    const row = await db.webhookDelivery.findUnique({ where: { id: deliveryId } });
    expect(row?.status).toBe("succeeded");
    expect(row?.leaseId).toBeNull();
  });

  test("a LIVE processing lease is NOT touchable (no premature takeover)", async () => {
    await makeEndpoint("ep-claims-live");
    const deliveryId = await makeDelivery("ep-claims-live");
    await db.webhookDelivery.update({
      where: { id: deliveryId },
      data: {
        status: "processing",
        leaseId: "lease-live",
        workerId: "worker-live",
        startedAt: new Date(),
        lockedUntil: new Date(Date.now() + 60_000), /* live */
      },
    });
    calls.length = 0;
    const count = await webhooks.dispatchDueWebhooks();
    expect(count).toBe(0);
    expect(calls.length).toBe(0);
  });
});

/* ------------------------------------------------------------------ */
/* 3 — lease-lost settle                                               */
/* ------------------------------------------------------------------ */

describe("ROUND 137 — atomic claims: dispossessed verdicts", () => {
  test("a settle after lease takeover is DISCARDED (the new owner owns the row)", async () => {
    await makeEndpoint("ep-claims-lost");
    const deliveryId = await makeDelivery("ep-claims-lost");

    let release: (() => void) | null = null;
    const gate = new Promise<void>((resolve) => {
      release = resolve;
    });
    webhooks.__setWebhookTransportForTests(async () => {
      await gate;
      return { ok: true, status: 200 };
    });

    const worker1 = webhooks.dispatchDueWebhooks();
    await new Promise((r) => setTimeout(r, 150)); /* #1 claimed + is in-flight */

    /* steal the lease the way a takeover after expiry would */
    await db.webhookDelivery.update({
      where: { id: deliveryId },
      data: { leaseId: "lease-of-the-takeover", lockedUntil: new Date(Date.now() + 60_000) },
    });

    (release as unknown as () => void)();
    await worker1; /* #1's settle runs — against a lease it no longer owns */

    const row = await db.webhookDelivery.findUnique({ where: { id: deliveryId } });
    expect(row?.status).toBe("processing"); /* NOT settled by the dispossessed worker */
    expect(row?.leaseId).toBe("lease-of-the-takeover");
    /* cleanup for the next suites */
    await db.webhookDelivery.delete({ where: { id: deliveryId } });
  });
});

/* ------------------------------------------------------------------ */
/* 4 — jittered backoff + lease hygiene on failure                     */
/* ------------------------------------------------------------------ */

describe("ROUND 137 — atomic claims: retry posture", () => {
  test("a failed attempt schedules a JITTERED backoff and clears the lease", async () => {
    await makeEndpoint("ep-claims-jitter");
    const deliveryId = await makeDelivery("ep-claims-jitter");
    const before = Date.now();
    webhooks.__setWebhookTransportForTests(async () => ({ ok: false, status: 500, errorClass: "invalid-response" }));
    await webhooks.dispatchDueWebhooks();

    const row = await db.webhookDelivery.findUnique({ where: { id: deliveryId } });
    expect(row?.status).toBe("failed");
    expect(row?.attempts).toBe(1);
    expect(row?.error).toBe("invalid-response");
    expect(row?.leaseId).toBeNull();
    expect(row?.lockedUntil).toBeNull();
    /* base backoff for attempt 1 = 60s; jitter ≤ +30% */
    expect(row?.nextAttemptAt).toBeTruthy();
    const delay = (row!.nextAttemptAt as Date).getTime() - before;
    expect(delay).toBeGreaterThanOrEqual(59_000);
    expect(delay).toBeLessThanOrEqual(60_000 * 1.31);
  });

  test("endpoint-disabled settles cleanly (exhausted, lease cleared)", async () => {
    await makeEndpoint("ep-claims-disabled");
    const deliveryId = await makeDelivery("ep-claims-disabled");
    await db.webhookEndpoint.update({
      where: { id: "ep-claims-disabled" },
      data: { active: false },
    });
    const count = await webhooks.dispatchDueWebhooks();
    expect(count).toBe(1);
    const row = await db.webhookDelivery.findUnique({ where: { id: deliveryId } });
    expect(row?.status).toBe("exhausted");
    expect(row?.error).toBe("endpoint-disabled");
    expect(row?.leaseId).toBeNull();
  });
});
