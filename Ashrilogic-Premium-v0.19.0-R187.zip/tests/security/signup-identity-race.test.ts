/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 187: tenant-signup identity uniqueness is
 * race-free under concurrency.
 *
 * The historical signup flow (POST /api/instances) ran
 * deepCheckTenantIdentity as a plain pre-check and created the Instance
 * afterwards — two concurrent signups sharing an email (or an org phone)
 * BOTH passed the pre-check and BOTH workspaces were created
 * (adminEmailIndex / orgPhoneIndex are plain indexes, not unique
 * constraints; the deep scan ignores deletedAt by design).
 *
 * The fix serializes the deep check + the create inside ONE
 * advisory-locked transaction (the withStorageQuotaWrite R171 pattern):
 *   1. pg_advisory_xact_lock on `tenant-signup:email:<index>` (and, for
 *      fresh signups, `tenant-signup:phone:<key>`) — acquired in SORTED
 *      key order so concurrent signups can never deadlock;
 *   2. the deep re-check runs INSIDE the transaction (fresh reads);
 *   3. the create commits with the lock held.
 *
 * This suite reproduces the route's exact critical section and proves:
 *   1. 8 concurrent signups sharing email + phone → exactly ONE created;
 *   2. the phone side alone (different emails, same phone) → exactly ONE;
 *   3. distinct identities do NOT over-serialize (all parallel signups
 *      succeed — no deadlock, no livelock);
 *   4. the loser's re-check observed the winner's COMMITTED row (the
 *      collision arm returned, not an exception).
 */
import { describe, beforeAll, afterAll, test, expect } from "bun:test";
import { getTestDb, ensureDemoEnv, type TestDb } from "./test-setup";

ensureDemoEnv();

const RUN = `signup-race-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

let db: TestDb;
let tenantUniqueness: typeof import("@/lib/server/tenant-uniqueness");
let cryptoVault: typeof import("@/lib/server/crypto-vault");
let adminSession: typeof import("@/lib/server/admin-session");
let rateLimit: typeof import("@/lib/server/rate-limit");
const createdIds: string[] = [];

type Tx = Parameters<Parameters<TestDb["$transaction"]>[0]>[0];

interface SignupOutcome {
  kind: "created" | "collision" | "error";
  emailUsedBy?: string | null;
  phoneUsedBy?: string | null;
  error?: unknown;
}

/** The route's exact critical section (same lock namespace, same order). */
async function provisionSignup(
  email: string,
  phone: string,
  ownerReuse: boolean
): Promise<SignupOutcome> {
  const emailIndex = cryptoVault.blindIndex(email) ?? "";
  const phoneKey = tenantUniqueness.phoneIndexKeyOf(phone);
  const lockKeys = [rateLimit.advisoryLockKey(`tenant-signup:email:${emailIndex}`)];
  if (!ownerReuse && phoneKey) {
    lockKeys.push(rateLimit.advisoryLockKey(`tenant-signup:phone:${phoneKey}`));
  }
  lockKeys.sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));

  try {
    const outcome = await db.$transaction(
      async (tx: Tx) => {
        for (const key of lockKeys) {
          await tx.$executeRaw`SELECT pg_advisory_xact_lock(${key})`;
        }
        if (!ownerReuse) {
          const collisions = await tenantUniqueness.deepCheckTenantIdentity(tx, {
            email,
            phone,
          });
          const emailClash = collisions.emailUsedBy !== null;
          if (emailClash || collisions.phoneUsedBy !== null) {
            return { kind: "collision" as const, emailClash, collisions };
          }
        }
        const row = await tx.instance.create({
          data: {
            systemId: "clinic-management",
            orgJson: JSON.stringify({
              name: `Org-${RUN}`,
              country: "SA",
              currency: "SAR",
              phone,
            }),
            orgPhoneIndex: phoneKey,
            adminJson: JSON.stringify({ name: `Admin-${RUN}`, email }),
            adminEmailIndex: emailIndex,
            prefsJson: JSON.stringify({ lang: "ar" }),
            modulesJson: JSON.stringify(["patients"]),
            passwordHash: adminSession.hashPassword("Signup-Race-2026!"),
          },
          select: { id: true },
        });
        createdIds.push(row.id);
        return { kind: "created" as const, row };
      },
      { timeout: 15_000, maxWait: 15_000 }
    );
    if (outcome.kind === "collision") {
      return {
        kind: "collision",
        emailUsedBy: outcome.collisions.emailUsedBy,
        phoneUsedBy: outcome.collisions.phoneUsedBy,
      };
    }
    return { kind: "created" };
  } catch (error) {
    return { kind: "error", error };
  }
}

beforeAll(async () => {
  db = await getTestDb();
  tenantUniqueness = await import("@/lib/server/tenant-uniqueness");
  cryptoVault = await import("@/lib/server/crypto-vault");
  adminSession = await import("@/lib/server/admin-session");
  rateLimit = await import("@/lib/server/rate-limit");
});

afterAll(async () => {
  /* keep the throwaway database clean for the suites after this one */
  if (createdIds.length > 0) {
    await db.instance.deleteMany({ where: { id: { in: createdIds } } });
  }
});

describe("ROUND 187 — signup identity race (advisory-locked critical section)", () => {
  test("8 concurrent signups sharing email + phone → exactly ONE created", async () => {
    const email = `race-${RUN}@signup.test`;
    const phone = "+966501234567";
    const results = await Promise.all(
      Array.from({ length: 8 }, () => provisionSignup(email, phone, false))
    );

    const created = results.filter((r) => r.kind === "created");
    const collisions = results.filter((r) => r.kind === "collision");
    const errors = results.filter((r) => r.kind === "error");

    expect(errors).toEqual([]);
    expect(created.length).toBe(1);
    expect(collisions.length).toBe(7);
    /* the losers observed the winner's COMMITTED row (not an exception) */
    for (const c of collisions) {
      expect(c.emailUsedBy ?? c.phoneUsedBy).not.toBeNull();
    }

    const emailIndex = cryptoVault.blindIndex(email) ?? "";
    expect(await db.instance.count({ where: { adminEmailIndex: emailIndex } })).toBe(1);
    expect(
      await db.instance.count({ where: { orgPhoneIndex: tenantUniqueness.normalizePhoneDeep(phone) } })
    ).toBe(1);
  });

  test("same PHONE, different emails → exactly ONE created (phone side alone serializes)", async () => {
    const phone = "+966509876543";
    const results = await Promise.all(
      Array.from({ length: 5 }, (_, i) =>
        provisionSignup(`phone-${RUN}-${i}@signup.test`, phone, false)
      )
    );
    const created = results.filter((r) => r.kind === "created");
    const collisions = results.filter((r) => r.kind === "collision");
    expect(results.filter((r) => r.kind === "error")).toEqual([]);
    expect(created.length).toBe(1);
    expect(collisions.length).toBe(4);
    for (const c of collisions) {
      expect(c.phoneUsedBy).not.toBeNull();
    }
  });

  test("distinct identities do NOT over-serialize — all 6 parallel signups succeed", async () => {
    const results = await Promise.all(
      Array.from({ length: 6 }, (_, i) =>
        provisionSignup(`distinct-${RUN}-${i}@signup.test`, `+96650111${String(i).padStart(4, "0")}`, false)
      )
    );
    expect(results.filter((r) => r.kind === "error")).toEqual([]);
    expect(results.filter((r) => r.kind === "created").length).toBe(6);
    expect(results.filter((r) => r.kind === "collision")).toEqual([]);
  });
});
