/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 124: the unified route wrapper
 * (src/lib/server/route.ts).
 *
 * The wrapper is the seam every migrated route handler goes through, so
 * its CONTRACT is the contract: exact error envelopes (byte-compatible
 * with the legacy inline handlers), correlation ids (echo bounded-valid
 * client ids, replace hostile ones), the 500 telemetry line (structured,
 * redacted — no error message text leaks into the ops line), and the
 * bounded-body envelopes reproduced verbatim from readJson.
 *
 * All checks are UNIT level — a handler is wrapped inline and invoked
 * with a synthetic Request; no server, no database rows.
 */
import { describe, test, expect, beforeAll } from "bun:test";
import { ensureDemoEnv } from "./test-setup";

ensureDemoEnv();

let routeHandler: typeof import("@/lib/server/route").routeHandler;
let HttpError: typeof import("@/lib/server/route").HttpError;

beforeAll(async () => {
  const mod = await import("@/lib/server/route");
  routeHandler = mod.routeHandler;
  HttpError = mod.HttpError;
});

const URL_ = "http://localhost:3000/api/test-route";

function post(body?: string, headers: Record<string, string> = {}): Request {
  return new Request(URL_, {
    method: "POST",
    ...(body !== undefined ? { body } : {}),
    headers: { "content-type": "application/json", ...headers },
  });
}

/** UUID v4-ish shape (the generated correlation id). */
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

describe("ROUND 124 — route wrapper envelopes", () => {
  test("HttpError renders the exact legacy { error } envelope (+ optional code)", async () => {
    const handler = routeHandler("fetch thing", async () => {
      throw new HttpError(404, "Package not found");
    });
    const res = await handler(post("{}"));
    expect(res.status).toBe(404);
    const body = (await res.json()) as { error?: string; code?: string };
    expect(body.error).toBe("Package not found");
    expect(body.code).toBeUndefined();
    expect(res.headers.get("x-request-id")).toMatch(UUID_RE);
  });

  test("HttpError with a machine code carries it NEXT TO error (additive)", async () => {
    const handler = routeHandler("fetch thing", async () => {
      throw new HttpError(403, "Plan changes are managed by the platform", "PACKAGE_ADMIN_ONLY");
    });
    const res = await handler(post("{}"));
    expect(res.status).toBe(403);
    const body = (await res.json()) as { error?: string; code?: string };
    expect(body.error).toBe("Plan changes are managed by the platform");
    expect(body.code).toBe("PACKAGE_ADMIN_ONLY");
  });

  test("uncaught error → the exact legacy 500 envelope 'Failed to <label>'", async () => {
    const handler = routeHandler("update package", async () => {
      throw new Error("boom");
    });
    const res = await handler(post("{}"));
    expect(res.status).toBe(500);
    const body = (await res.json()) as { error?: string };
    expect(body.error).toBe("Failed to update package");
  });

  test("a returned NextResponse passes through untouched except x-request-id", async () => {
    const handler = routeHandler("list packages", async () => {
      const res = Response.json({ ok: true, value: 7 }) as import("next/server").NextResponse;
      res.headers.set("x-custom", "kept");
      return res;
    });
    const res = await handler(post("{}"));
    expect(res.status).toBe(200);
    expect((await res.json()) as unknown).toEqual({ ok: true, value: 7 });
    expect(res.headers.get("x-custom")).toBe("kept");
    expect(res.headers.get("x-request-id")).toMatch(UUID_RE);
  });
});

describe("ROUND 124 — correlation ids (x-request-id)", () => {
  test("a bounded-valid client id is ECHOED verbatim", async () => {
    const handler = routeHandler("list packages", async () => {
      return Response.json({}) as import("next/server").NextResponse;
    });
    const res = await handler(post("{}", { "x-request-id": "client-req_24.09-a" }));
    expect(res.headers.get("x-request-id")).toBe("client-req_24.09-a");
  });

  test("a hostile id (spaces — fails the charset) is REPLACED, never echoed", async () => {
    const handler = routeHandler("list packages", async () => {
      return Response.json({}) as import("next/server").NextResponse;
    });
    /* NOTE: a literal newline cannot even be constructed into a fetch
     * Headers value (spec-compliant Bun rejects it) — the wrapper's
     * charset regex is unconditional defense-in-depth for anything a raw
     * socket smuggles past. Spaces are a LEGAL header value that still
     * fails [A-Za-z0-9._-] and prove the replace path. */
    const res = await handler(post("{}", { "x-request-id": "bad id with spaces" }));
    const echoed = res.headers.get("x-request-id") ?? "";
    expect(echoed).not.toContain(" ");
    expect(echoed).not.toBe("bad id with spaces");
    expect(echoed).toMatch(UUID_RE);
  });

  test("an oversized id (65+ chars) is replaced — no log flooding vector", async () => {
    const handler = routeHandler("list packages", async () => {
      return Response.json({}) as import("next/server").NextResponse;
    });
    const res = await handler(post("{}", { "x-request-id": "a".repeat(80) }));
    expect(res.headers.get("x-request-id")).toMatch(UUID_RE);
  });
});

describe("ROUND 124 — bounded body envelopes (readBody/parseBody)", () => {
  test("empty body → 400 'Request body is required' (legacy string)", async () => {
    const handler = routeHandler("create package", async (ctx) => {
      await ctx.readBody();
      throw new Error("unreachable");
    });
    const res = await handler(post());
    expect(res.status).toBe(400);
    expect(((await res.json()) as { error?: string }).error).toBe("Request body is required");
  });

  test("malformed JSON → 400 'Invalid JSON body' (legacy string)", async () => {
    const handler = routeHandler("create package", async (ctx) => {
      await ctx.readBody();
      throw new Error("unreachable");
    });
    const res = await handler(post("{not json"));
    expect(res.status).toBe(400);
    expect(((await res.json()) as { error?: string }).error).toBe("Invalid JSON body");
  });

  test("oversized body → 413 'Request body too large' (legacy string)", async () => {
    const handler = routeHandler("create package", async (ctx) => {
      await ctx.readBody(1000);
      throw new Error("unreachable");
    });
    const res = await handler(post(`{"pad":"${"x".repeat(10_000)}"}`));
    expect(res.status).toBe(413);
    expect(((await res.json()) as { error?: string }).error).toBe("Request body too large");
  });

  test("schema mismatch → 400 zodError envelope (the legacy shape)", async () => {
    const { z } = await import("zod");
    const schema = z.object({ name: z.string().min(2) });
    const handler = routeHandler("create package", async (ctx) => {
      await ctx.parseBody(schema);
      throw new Error("unreachable");
    });
    const res = await handler(post(JSON.stringify({ name: "x" })));
    expect(res.status).toBe(400);
    const err = ((await res.json()) as { error?: string }).error ?? "";
    expect(err.startsWith("Validation failed — ")).toBe(true);
    expect(err).toContain("name");
  });

  test("valid body flows through parseBody typed", async () => {
    const { z } = await import("zod");
    const schema = z.object({ name: z.string() });
    let seen = "";
    const handler = routeHandler("create package", async (ctx) => {
      const data = await ctx.parseBody(schema);
      seen = data.name;
      return Response.json({ ok: true }) as import("next/server").NextResponse;
    });
    const res = await handler(post(JSON.stringify({ name: "Pro" })));
    expect(res.status).toBe(200);
    expect(seen).toBe("Pro");
  });
});

describe("ROUND 124 — 500 telemetry (structured, redacted)", () => {
  /** Capture console.error lines while the wrapped handler fails. */
  async function captureFailure(error: unknown): Promise<string[]> {
    const lines: string[] = [];
    const original = console.error;
    console.error = (...args: unknown[]) => {
      lines.push(args.map((a) => (typeof a === "string" ? a : JSON.stringify(a))).join(" "));
    };
    try {
      const handler = routeHandler("update package", async () => {
        throw error;
      });
      const res = await handler(post("{}", { "x-request-id": "trace-abc-1234" }));
      expect(res.status).toBe(500);
      return lines;
    } finally {
      console.error = original;
    }
  }

  test("one structured ops.route.fail line: requestId, method, path, label, dbClass — and NO message text", async () => {
    const lines = await captureFailure(new Error("SECRET-SQL-FRAGMENT must not leak"));
    const structured = lines.find((l) => l.includes("ops.route.fail"));
    expect(structured).toBeTruthy();
    expect(structured).toContain("trace-abc-1234");
    expect(structured).toContain('"method":"POST"');
    expect(structured).toContain("/api/test-route");
    expect(structured).toContain("update package");
    expect(structured).toContain('"dbClass":"unknown"');
    expect(structured).toContain('"errName":"Error"');
    /* the redaction contract: the ops line carries classification, not text */
    expect(structured).not.toContain("SECRET-SQL-FRAGMENT");
  });

  test("a Prisma-shaped error is classified (P2002 → unique-violation)", async () => {
    const lines = await captureFailure({ code: "P2002", message: "UNIQUE constraint failed" });
    const structured = lines.find((l) => l.includes("ops.route.fail"));
    expect(structured).toBeTruthy();
    expect(structured).toContain('"dbClass":"unique-violation"');
  });

  test("HttpError (a domain response) emits NO failure telemetry", async () => {
    const lines: string[] = [];
    const original = console.error;
    console.error = (...args: unknown[]) => {
      lines.push(String(args[0]));
    };
    try {
      const handler = routeHandler("update package", async () => {
        throw new HttpError(404, "Package not found");
      });
      const res = await handler(post("{}"));
      expect(res.status).toBe(404);
      expect(lines.filter((l) => l.includes("ops.route.fail"))).toHaveLength(0);
    } finally {
      console.error = original;
    }
  });

  test("the telemetry path never includes the query string (token safety)", async () => {
    const lines: string[] = [];
    const original = console.error;
    console.error = (...args: unknown[]) => {
      lines.push(String(args[0]));
    };
    try {
      const failing = routeHandler("list things", async () => {
        throw new Error("x");
      });
      const out = await failing(
        new Request("http://localhost:3000/api/test-route?token=BEARER-SECRET", { method: "GET" })
      );
      expect(out.status).toBe(500);
      const structured = lines.find((l) => l.includes("ops.route.fail"));
      expect(structured).toBeTruthy();
      expect(structured).toContain("/api/test-route");
      expect(structured).not.toContain("BEARER-SECRET");
    } finally {
      console.error = original;
    }
  });
});
