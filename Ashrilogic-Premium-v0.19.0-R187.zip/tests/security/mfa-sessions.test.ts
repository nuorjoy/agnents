/// <reference types="bun-types" />
/**
 * Ashrilogic — ROUND 45 security regression tests.
 *
 * Covers the three new security surfaces:
 *  1. TOTP (RFC 6238) — known-answer vector, drift window, secret sealing,
 *     two-step enrollment, login verification, backup codes (single-use),
 *     code-gated disable.
 *  2. Active sessions — registry rows, revocation semantics (one / others /
 *     all), guard-path record checks.
 *  3. Token jti — pre-jti tokens keep verifying (rollout safety), jti tokens
 *     map to their registry row only.
 *
 * DB isolation: throwaway PostgreSQL test database via test-setup (never the live DB).
 */
import { beforeAll, describe, expect, test } from "bun:test";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { getTestDb, resetRateTable, type TestDb } from "./test-setup";

let db: TestDb;

beforeAll(async () => {
  db = await getTestDb();
  await resetRateTable(db);
  await db.mfaSecret.deleteMany({});
  await db.sessionRecord.deleteMany({});
  await db.webauthnCredential.deleteMany({});
  await db.webauthnChallenge.deleteMany({});
});

/* ------------------------------ TOTP core ------------------------------ */

describe("mfa — TOTP (RFC 6238)", () => {
  test("known-answer vector: the RFC 6238 SHA-1 test secret produces stable 6-digit codes", async () => {
    const { totpCode } = await import("@/lib/server/mfa");
    /* RFC 6238 test key (base32 of "12345678901234567890") */
    const secret = "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ";
    /* T = 59 → counter 1 — the RFC's own vector for SHA1 is 94287082 (8-digit);
       our 6-digit truncation is the last 6 digits: 287082 */
    const t59 = 59_000;
    expect(totpCode(secret, t59)).toBe("287082");
    /* deterministic at a fixed time */
    expect(totpCode(secret, t59)).toBe(totpCode(secret, t59));
  });

  test("verification accepts the current code and ±1 step, rejects everything else", async () => {
    const { generateTotpSecret, totpCode, verifyTotp } = await import("@/lib/server/mfa");
    const secret = generateTotpSecret();
    const now = Date.now();
    expect(verifyTotp(secret, totpCode(secret, now), now)).toBeTrue();
    expect(verifyTotp(secret, totpCode(secret, now + 30_000), now)).toBeTrue();
    expect(verifyTotp(secret, totpCode(secret, now - 30_000), now)).toBeTrue();
    expect(verifyTotp(secret, totpCode(secret, now + 60_000), now)).toBeFalse();
    expect(verifyTotp(secret, "000000", now)).toBeFalse();
    expect(verifyTotp(secret, "abc12", now)).toBeFalse();
    expect(verifyTotp(secret, "1234567", now)).toBeFalse();
  });

  test("generated secrets are 32-char base32 (160 bits)", async () => {
    const { generateTotpSecret } = await import("@/lib/server/mfa");
    const secret = generateTotpSecret();
    expect(secret).toMatch(/^[A-Z2-7]{32}$/);
  });

  test("otpauth URI carries the issuer, label and standard parameters", async () => {
    const { otpauthUri } = await import("@/lib/server/mfa");
    const uri = otpauthUri("GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ", "owner@example.com");
    expect(uri.startsWith("otpauth://totp/Ashrilogic%3Aowner%40example.com?")).toBeTrue();
    expect(uri).toContain("issuer=Ashrilogic");
    expect(uri).toContain("digits=6");
    expect(uri).toContain("period=30");
    expect(uri).toContain("algorithm=SHA1");
  });
});

/* --------------------------- enrollment flow ---------------------------- */

describe("mfa — enrollment + login verification", () => {
  const SCOPE = "instance" as const;
  const SUBJECT = "test-instance-1";
  let secret = "";

  test("start → pending status, sealed secret", async () => {
    const { startMfaEnrollment, getMfaStatus } = await import("@/lib/server/mfa");
    const started = await startMfaEnrollment(SCOPE, SUBJECT, "owner@example.com");
    if ("alreadyEnabled" in started) throw new Error("unexpected alreadyEnabled");
    secret = started.secret;
    expect(started.otpauth).toContain("owner%40example.com");
    const status = await getMfaStatus(SCOPE, SUBJECT);
    expect(status).toEqual({ enabled: false, pending: true, backupCodesLeft: 0 });
    /* the STORED secret is sealed — the raw base32 never lands in the row */
    const row = await db.mfaSecret.findUnique({
      where: { scope_subjectId: { scope: SCOPE, subjectId: SUBJECT } },
    });
    expect(row).not.toBeNull();
    expect(row!.secretSealed).not.toContain(secret);
    expect(row!.secretSealed.length).toBeGreaterThan(50);
  });

  test("confirm with a wrong code is refused; live code enables + returns 10 backup codes", async () => {
    const { confirmMfaEnrollment, getMfaStatus, totpCode } = await import("@/lib/server/mfa");
    const wrong = await confirmMfaEnrollment(SCOPE, SUBJECT, "000000");
    expect(wrong).toEqual({ ok: false, reason: "invalid" });

    const ok = await confirmMfaEnrollment(SCOPE, SUBJECT, totpCode(secret));
    expect(ok.ok).toBeTrue();
    if (!ok.ok) return;
    expect(ok.backupCodes).toHaveLength(10);
    expect(new Set(ok.backupCodes).size).toBe(10); // all distinct
    expect(ok.backupCodes[0]).toMatch(/^[A-Z2-9]{4}-[A-Z2-9]{4}$/);

    const status = await getMfaStatus(SCOPE, SUBJECT);
    expect(status).toEqual({ enabled: true, pending: false, backupCodesLeft: 10 });
  });

  test("backup codes verify ONCE (single-use, replay dies)", async () => {
    const mfa = await import("@/lib/server/mfa");
    /* ROUND 146 — this test owns a FRESH subject: under the one-use timestep
       law every consumption event (confirm → regenerate → login) advances
       lastUsedTimestep, so chained tests sharing one subject would race the
       30s window. A dedicated subject makes the sequence deterministic:
       confirm spends T0, regenerate demands (and spends) T+1, replay of
       either is refused. */
    const SUBJECT_B = "mfa-backup-test-subject";
    const start = await mfa.startMfaEnrollment(SCOPE, SUBJECT_B, "b@x.com");
    if (!("secret" in start)) throw new Error("fresh enrollment failed");
    const confirmed = await mfa.confirmMfaEnrollment(SCOPE, SUBJECT_B, mfa.totpCode(start.secret));
    expect(confirmed.ok).toBeTrue();

    const nextStepMs = Math.ceil(Date.now() / 30_000) * 30_000 + 1_000;
    const regen = await mfa.regenerateBackupCodes(
      SCOPE,
      SUBJECT_B,
      mfa.totpCode(start.secret, nextStepMs)
    );
    /* the CONFIRMING code must NOT open regeneration anymore (replay —
       RFC 6238 §5.2, extended to the management paths in ROUND 146) */
    const confirmingCodeReplay = await mfa.regenerateBackupCodes(
      SCOPE,
      SUBJECT_B,
      mfa.totpCode(start.secret)
    );
    expect(confirmingCodeReplay.ok).toBeFalse();
    expect(regen.ok).toBeTrue();
    if (!regen.ok) return;
    const code = regen.backupCodes[0]!;
    expect(await mfa.verifyMfaLogin(SCOPE, SUBJECT_B, code)).toBeTrue();
    expect(await mfa.verifyMfaLogin(SCOPE, SUBJECT_B, code)).toBeFalse(); // replay
    const status = await mfa.getMfaStatus(SCOPE, SUBJECT_B);
    expect(status.backupCodesLeft).toBe(9);
    /* cleanup: disarm the dedicated subject (next-step code) */
    const disarmStep = Math.ceil(Date.now() / 30_000) * 30_000 + 1_000;
    await mfa.disableMfa(SCOPE, SUBJECT_B, mfa.totpCode(start.secret, disarmStep));
  });

  test("login verification: live TOTP works; garbage never works", async () => {
    const { verifyMfaLogin, totpCode } = await import("@/lib/server/mfa");
    /* ROUND 49 replay guard: the enrollment-confirming code is spent, so a
       NEXT-step code (still inside the ±1 drift window) is the live one.
       ROUND 105 flake fix: "+31s" used to land TWO steps ahead whenever the
       test started in the last second of a step (outside the ±1 window —
       the rare pre-existing boundary flake). Computing the next step
       boundary + 1s is deterministic: always exactly one step ahead. */
    const nextStepMs = Math.ceil(Date.now() / 30_000) * 30_000 + 1_000;
    const nextStepCode = totpCode(secret, nextStepMs);
    expect(await verifyMfaLogin(SCOPE, SUBJECT, nextStepCode)).toBeTrue();
    /* the same code replayed immediately → refused (RFC 6238 §5.2) */
    expect(await verifyMfaLogin(SCOPE, SUBJECT, nextStepCode)).toBeFalse();
    expect(await verifyMfaLogin(SCOPE, SUBJECT, "111111")).toBeFalse();
    /* unknown subject → always false, no oracle */
    expect(await verifyMfaLogin(SCOPE, "missing", totpCode(secret))).toBeFalse();
  });

  test("disable without a valid code is refused; with it, the row dies", async () => {
    const mfa = await import("@/lib/server/mfa");
    /* ROUND 146 — dedicated subject (the login test above spent a code on
       SUBJECT; a fresh subject makes the one-use assertions deterministic):
       the CONFIRMING code is spent by confirm itself, so disabling with it
       is refused; a next-step code disarms. */
    const SUBJECT_C = "mfa-disable-test-subject";
    const start = await mfa.startMfaEnrollment(SCOPE, SUBJECT_C, "c@x.com");
    if (!("secret" in start)) throw new Error("fresh enrollment failed");
    expect((await mfa.confirmMfaEnrollment(SCOPE, SUBJECT_C, mfa.totpCode(start.secret))).ok).toBeTrue();

    expect(await mfa.disableMfa(SCOPE, SUBJECT_C, "999999")).toBeFalse();
    expect((await mfa.getMfaStatus(SCOPE, SUBJECT_C)).enabled).toBeTrue();
    /* the spent confirming code disarms NOTHING anymore */
    expect(await mfa.disableMfa(SCOPE, SUBJECT_C, mfa.totpCode(start.secret))).toBeFalse();
    const nextStepMs = Math.ceil(Date.now() / 30_000) * 30_000 + 1_000;
    expect(await mfa.disableMfa(SCOPE, SUBJECT_C, mfa.totpCode(start.secret, nextStepMs))).toBeTrue();
    expect(await mfa.getMfaStatus(SCOPE, SUBJECT_C)).toEqual({
      enabled: false,
      pending: false,
      backupCodesLeft: 0,
    });
    /* regenerate on the dead row refuses too */
    expect((await mfa.regenerateBackupCodes(SCOPE, SUBJECT_C, mfa.totpCode(start.secret))).ok).toBeFalse();
  });

  test("enrollment cannot start while enabled (must disable first)", async () => {
    const mfa = await import("@/lib/server/mfa");
    const SUBJECT_D = "mfa-restart-test-subject";
    const s1 = await mfa.startMfaEnrollment(SCOPE, SUBJECT_D, "d@x.com");
    if (!("secret" in s1)) throw new Error("fresh enrollment failed");
    await mfa.confirmMfaEnrollment(SCOPE, SUBJECT_D, mfa.totpCode(s1.secret));
    const s2 = await mfa.startMfaEnrollment(SCOPE, SUBJECT_D, "d@x.com");
    expect("alreadyEnabled" in s2).toBeTrue();
    /* ROUND 146 — the confirming code is SPENT by confirm itself; the next
       step's code disables (the one-use law). */
    const nextStepMs = Math.ceil(Date.now() / 30_000) * 30_000 + 1_000;
    await mfa.disableMfa(SCOPE, SUBJECT_D, mfa.totpCode(s1.secret, nextStepMs));
  });
});

/* ---------------------------- session registry --------------------------- */

describe("sessions — registry + revocation", () => {
  const SCOPE = "admin" as const;
  const SUBJECT = "admin-session-test";

  test("device labels parse real UA strings", async () => {
    const { deviceLabel } = await import("@/lib/server/sessions");
    expect(deviceLabel("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36")).toBe("Chrome · macOS");
    expect(deviceLabel("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36 Edg/126.0")).toBe("Edge · Windows");
    expect(deviceLabel("Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1")).toBe("Safari · iOS");
    expect(deviceLabel(null)).toBe("جهاز غير معروف");
  });

  test("record → list → revoke-one keeps others alive", async () => {
    const { recordSession, listSessions, revokeSession, checkSessionRecord } = await import(
      "@/lib/server/sessions"
    );
    await db.sessionRecord.deleteMany({ where: { subjectId: SUBJECT } });

    const jtiA = "sessA0000000001";
    const jtiB = "sessB0000000002";
    await recordSession({ scope: SCOPE, subjectId: SUBJECT, jti: jtiA, ip: "1.2.3.4", userAgent: "Chrome/126 Windows", expiresAt: new Date(Date.now() + 3600_000) });
    await recordSession({ scope: SCOPE, subjectId: SUBJECT, jti: jtiB, ip: "5.6.7.8", userAgent: "Safari iPhone", expiresAt: new Date(Date.now() + 3600_000) });

    const list = await listSessions(SCOPE, SUBJECT);
    expect(list).toHaveLength(2);
    expect(list.some((s) => s.device === "Chrome · Windows" && s.ip === "1.2.3.4")).toBeTrue();

    /* guard checks: both live */
    expect((await checkSessionRecord(SCOPE, SUBJECT, jtiA)).valid).toBeTrue();
    expect((await checkSessionRecord(SCOPE, SUBJECT, jtiB)).valid).toBeTrue();
    /* cross-subject jti NEVER validates */
    expect((await checkSessionRecord(SCOPE, "someone-else", jtiA)).valid).toBeFalse();

    expect(await revokeSession(SCOPE, SUBJECT, jtiA)).toBeTrue();
    expect((await checkSessionRecord(SCOPE, SUBJECT, jtiA)).valid).toBeFalse();
    expect((await checkSessionRecord(SCOPE, SUBJECT, jtiB)).valid).toBeTrue();
    expect(await revokeSession(SCOPE, SUBJECT, jtiA)).toBeFalse(); // already dead
  });

  test("revoke-others keeps the current session; expired rows never list", async () => {
    const { recordSession, listSessions, revokeOtherSessions, checkSessionRecord } = await import(
      "@/lib/server/sessions"
    );
    await db.sessionRecord.deleteMany({ where: { subjectId: SUBJECT } });
    const now = Date.now();
    await recordSession({ scope: SCOPE, subjectId: SUBJECT, jti: "cur00000000001", expiresAt: new Date(now + 3600_000) });
    await recordSession({ scope: SCOPE, subjectId: SUBJECT, jti: "oth00000000002", expiresAt: new Date(now + 3600_000) });
    await recordSession({ scope: SCOPE, subjectId: SUBJECT, jti: "exp00000000003", expiresAt: new Date(now - 1000) }); // expired

    let list = await listSessions(SCOPE, SUBJECT);
    expect(list).toHaveLength(2); // expired row never lists
    const revoked = await revokeOtherSessions(SCOPE, SUBJECT, "cur00000000001");
    /* the OTHER live session + the expired-but-unrevoked row both flip
     * (harmless cleanup — the guard already rejects expired records) */
    expect(revoked).toBe(2);
    list = await listSessions(SCOPE, SUBJECT);
    expect(list).toHaveLength(1);
    expect(list[0]!.id).toBe("cur00000000001");
    expect((await checkSessionRecord(SCOPE, SUBJECT, "oth00000000002")).valid).toBeFalse();
    expect((await checkSessionRecord(SCOPE, SUBJECT, "exp00000000003")).valid).toBeFalse();
  });

  test("revokeAllSessions kills everything (epoch-bump mirror)", async () => {
    const { recordSession, revokeAllSessions, checkSessionRecord } = await import("@/lib/server/sessions");
    await db.sessionRecord.deleteMany({ where: { subjectId: SUBJECT } });
    await recordSession({ scope: SCOPE, subjectId: SUBJECT, jti: "a0000000000001", expiresAt: new Date(Date.now() + 3600_000) });
    await recordSession({ scope: SCOPE, subjectId: SUBJECT, jti: "b0000000000002", expiresAt: new Date(Date.now() + 3600_000) });
    await revokeAllSessions(SCOPE, SUBJECT);
    expect((await checkSessionRecord(SCOPE, SUBJECT, "a0000000000001")).valid).toBeFalse();
    expect((await checkSessionRecord(SCOPE, SUBJECT, "b0000000000002")).valid).toBeFalse();
  });
});

/* -------------------------------- tokens -------------------------------- */

describe("tokens — jti round trip + rollout safety", () => {
  test("a jti-carrying token verifies and exposes it; a pre-jti token still verifies", async () => {
    const { issueToken, verifyToken } = await import("@/lib/server/tokens");
    const withJti = issueToken("admin", "u1", 60_000, 3, "jti-abc-123").token;
    const payload = verifyToken(withJti, "admin");
    expect(payload?.sub).toBe("u1");
    expect(payload?.jti).toBe("jti-abc-123");

    const legacy = issueToken("admin", "u2", 60_000, 0).token; // no jti — rollout safety
    expect(verifyToken(legacy, "admin")?.jti).toBeUndefined();

    /* scope pinning still holds for the new scopes */
    const mfaTicket = issueToken("admin-mfa", "u3", 60_000, 1).token;
    expect(verifyToken(mfaTicket, "admin")).toBeNull(); // never a session
    expect(verifyToken(mfaTicket, "admin-mfa")?.sub).toBe("u3");
    const instTicket = issueToken("instance-mfa", "inst1|idx", 60_000, 1).token;
    expect(verifyToken(instTicket, "instance")).toBeNull();
  });
});

/* --------------------- ROUND 146 — per-account budgets --------------------- */

describe("mfa finish routes — per-ACCOUNT second-factor budgets (ROUND 146)", () => {
  const ROUTES = [
    "src/app/api/admin/login/mfa/route.ts",
    "src/app/api/instances/auth/login/mfa/route.ts",
  ] as const;

  test("both finish routes declare the account-scoped fail-closed rule positioned BEFORE the code check", () => {
    for (const rel of ROUTES) {
      const source = readFileSync(join(import.meta.dir, "..", "..", rel), "utf8");
      /* the account rule exists, is fail-closed, and uses the route's row id */
      expect(source).toContain("MFA_USER_RULE = { limit: 8, windowMs: 5 * 60 * 1000 }");
      expect(source).toMatch(/rateLimited\(`(admin|inst)-mfa-acct:\$\{row\.id\}`,\s*MFA_USER_RULE,\s*\{\s*failClosed:\s*true\s*\}\)/);
      /* ORDER: the account budget fires after the row re-check proves the
       * account, but BEFORE verifyMfaLogin consumes/validates a code. */
      const acctRule = source.indexOf("mfa-acct:");
      const verify = source.indexOf("verifyMfaLogin(");
      expect(acctRule).toBeGreaterThan(-1);
      expect(verify).toBeGreaterThan(acctRule);
      /* the per-IP rule still runs first (both layers, as before) */
      const ipRule = source.indexOf("-mfa:${ip}");
      expect(ipRule).toBeGreaterThan(-1);
      expect(acctRule).toBeGreaterThan(ipRule);
    }
  });

  test("the account budget serves the SAME uniform 429 shape as the IP rule", () => {
    for (const rel of ROUTES) {
      const source = readFileSync(join(import.meta.dir, "..", "..", rel), "utf8");
      const uses = source.split("tooManyRequests(").length - 1;
      expect(uses).toBe(2); /* one for the IP rule, one for the account rule */
      expect(source.match(/Too many verification attempts, please try again later/g)?.length).toBe(2);
    }
  });
});
