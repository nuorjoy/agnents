/// <reference types="bun-types" />
/**
 * Ashrilogic — storage migration (Phase 7) tests: manifest hashing,
 * resumable copy with sha-256 verification, corrupt-file detection,
 * missing-bytes detection against ImageAsset rows.
 */

import { describe, expect, test, beforeAll, afterAll } from "bun:test";
import { mkdirSync, rmSync, writeFileSync, existsSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { ensureDemoEnv, getTestDb } from "./test-setup";

ensureDemoEnv();

let db: Awaited<ReturnType<typeof getTestDb>>;
let storageMod: typeof import("../../scripts/migrate-storage");

let sourceRoot: string;
let targetRoot: string;

/** a deterministic "webp" payload whose sha256 we compute ourselves. */
async function sha256(data: Buffer): Promise<string> {
  const { createHash } = await import("node:crypto");
  return createHash("sha256").update(data).digest("hex");
}

beforeAll(async () => {
  db = await getTestDb();
  storageMod = await import("../../scripts/migrate-storage");
  sourceRoot = mkdtempSync(join(tmpdir(), "ash-store-src-"));
  targetRoot = mkdtempSync(join(tmpdir(), "ash-store-dst-"));
  mkdirSync(join(sourceRoot, "images"), { recursive: true });
});

afterAll(async () => {
  await db.$disconnect();
  rmSync(sourceRoot, { recursive: true, force: true });
  rmSync(targetRoot, { recursive: true, force: true });
});

describe("storage migration — manifest / copy / verify", () => {
  test("manifest hash-verifies content-addressed files and flags corruption", async () => {
    const good = Buffer.from("fake-webp-bytes-good");
    const goodHash = await sha256(good);
    writeFileSync(join(sourceRoot, "images", `${goodHash}.webp`), good);

    const corrupt = Buffer.from("tampered-content");
    const corruptHash = await sha256(Buffer.from("original-content"));
    writeFileSync(join(sourceRoot, "images", `${corruptHash}.webp`), corrupt);

    const manifest = await storageMod.buildStorageManifest(sourceRoot);
    expect(manifest.totals.files).toBe(2);
    const goodEntry = manifest.entries.find((e) => e.sha256 === goodHash);
    expect(goodEntry?.verified).toBe(true);
    const corruptEntry = manifest.entries.find((e) => e.file === `images/${corruptHash}.webp`);
    expect(corruptEntry?.verified).toBe(false);
    expect(manifest.totals.unverified).toBe(1);
  });

  test("copy transfers bytes, verifies them, and is resumable", async () => {
    const good = Buffer.from("fake-webp-bytes-good");
    const goodHash = await sha256(good);
    const first = await storageMod.copyStorage(sourceRoot, targetRoot);
    expect(first.copied).toBe(1); /* ONLY the content-verified file */
    /* the CORRUPT source file (content ≠ its content-addressed name) is
       refused by the copy's own verification — by design */
    expect(first.failures.length).toBe(1);
    expect(first.failures[0]).toContain("failed sha-256 verification");
    /* the content-addressed good file landed byte-identically */
    expect(existsSync(join(targetRoot, "images", `${goodHash}.webp`))).toBe(true);

    /* RESUMABLE: re-running skips every already-verified destination file */
    const second = await storageMod.copyStorage(sourceRoot, targetRoot);
    expect(second.copied).toBe(0);
    expect(second.skippedVerified).toBe(1);
  });

  test("verify flags missing bytes for referenced ImageAsset rows", async () => {
    const good = Buffer.from("fake-webp-bytes-good");
    const goodHash = await sha256(good);
    /* an ImageAsset row whose file is NOT in the (empty) target root */
    await db.imageAsset.create({
      data: { id: goodHash, mime: "image/webp", bytes: good.length },
    });
    const emptyRoot = mkdtempSync(join(tmpdir(), "ash-store-empty-"));
    try {
      const result = await storageMod.verifyStorage(emptyRoot);
      expect(result.ok).toBe(false);
      expect(result.missingBytes.length).toBe(1);
      expect(result.missingBytes[0]).toContain(goodHash.slice(0, 16));
    } finally {
      rmSync(emptyRoot, { recursive: true, force: true });
      await db.imageAsset.delete({ where: { id: goodHash } });
    }

    /* the FULL target root (file copied earlier) verifies clean */
    const okResult = await storageMod.verifyStorage(targetRoot);
    expect(okResult.ok).toBe(true);
    expect(okResult.verifiedFiles).toBeGreaterThanOrEqual(1);
  });

  test("verify detects corrupt destination bytes (hash mismatch)", async () => {
    const files = readdirSync(join(targetRoot, "images")).filter((f) => f.endsWith(".webp"));
    if (files.length === 0) return; /* nothing to corrupt — skip defensively */
    const victim = files[0]!;
    writeFileSync(join(targetRoot, "images", victim), Buffer.from("corrupted-bytes"));
    const result = await storageMod.verifyStorage(targetRoot);
    expect(result.ok).toBe(false);
    expect(result.corruptBytes.some((c) => c.includes(victim))).toBe(true);
    /* repair path: a re-copy replaces the corrupt file */
    const repaired = await storageMod.copyStorage(sourceRoot, targetRoot);
    expect(repaired.copied).toBeGreaterThanOrEqual(1);
    const after = await storageMod.verifyStorage(targetRoot);
    expect(after.ok).toBe(true);
  });
});
