/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — LIVE-SERVER route tests against the running dev
 * server (http://localhost:3000).
 *
 * These are black-box HTTP probes of the integrated hardening stack:
 * session forgery with the OLD public source constant (Task 2 — the
 * headline regression), login-route origin guard + bounded body parsing
 * (Task 3-a), the sanitized anonymous instance directory (Task 3-b), and
 * the platform security headers (Task 2/next.config.ts).
 *
 * RESILIENCE: the suite PROBES /api/status first; when the dev server is
 * down the whole suite is SKIPPED with a console note — a CI run must
 * never fail because the server is not running.
 *
 * The dev server's PostgreSQL database is only READ (a pg query, to pick
 * a real admin row for the forgery probe) and the only writes my requests
 * can induce are the public endpoints' own rate-limit hits (one probe per
 * run, randomized keys — same footprint as any anonymous visitor).
 */
import { describe, test, expect } from "bun:test";
import { createHmac } from "node:crypto";
import { serverPg } from "./test-setup";

const BASE = "http://localhost:3000";

/** The pre-fix hardcoded secret — public source knowledge an attacker has. */
const OLD_PUBLIC_SECRET = "ashrilogic-v2-demo-session-secret";
/** The documented DEV fallback (this deployment signs with it). */
const DEV_FALLBACK_SECRET = "ashrilogic-demo-session-secret";

async function serverReachable(): Promise<boolean> {
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 2000);
    try {
      const res = await fetch(`${BASE}/api/status`, { signal: controller.signal });
      return res.ok;
    } finally {
      clearTimeout(timer);
    }
  } catch {
    return false;
  }
}

/** fetch with a hard timeout so a wedged route can never hang the suite */
const FETCH_TIMEOUT_MS = 25_000;

async function jfetch(path: string, init?: RequestInit): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
  try {
    return await fetch(`${BASE}${path}`, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Live-server test with an extended timeout: the dev server compiles routes
 * on demand, so a COLD route's first response can take several seconds
 * (bun's default per-test timeout is 5s — too tight for cold compiles).
 */
function liveTest(name: string, fn: () => Promise<void>): void {
  test(name, fn, 30_000);
}

interface AdminRow {
  id: string;
  sessionVersion: number;
}

/** READ-ONLY peek at the dev server's database for a real, active admin
 *  row (never writes). An unresolvable/unreachable server DB behaves like
 *  the old missing-file case: null, and the control probe is skipped. */
async function activeAdminRow(): Promise<AdminRow | null> {
  try {
    const pg = await serverPg();
    const result = await pg.query<AdminRow>(
      'SELECT "id", "sessionVersion" FROM "AdminUser" WHERE "active" = true ORDER BY "sessionVersion" ASC, "id" ASC LIMIT 1'
    );
    return result.rows[0] ?? null;
  } catch {
    return null;
  }
}

function craftSessionToken(secret: string, sub: string, ver: number): string {
  const payload = JSON.stringify({ scope: "admin", sub, ver, exp: Date.now() + 60 * 60 * 1000 });
  const body = Buffer.from(payload, "utf8").toString("base64url");
  const mac = createHmac("sha256", secret).update(body).digest("base64url");
  return `${body}.${mac}`;
}

const live = await serverReachable();
const maybeDescribe = live ? describe : describe.skip;
if (!live) {
  console.log(
    "[http-routes] dev server not reachable on :3000 — skipping the live-server suite (CI never fails for a down server)"
  );
}

const adminRow = await activeAdminRow();
const forgedToken = craftSessionToken(
  OLD_PUBLIC_SECRET,
  adminRow?.id ?? "forged-admin-sub",
  adminRow?.sessionVersion ?? 0
);
/* ROUND 49 — a provisioned ADMIN_SESSION_SECRET (real .env deployment) wins
   over the demo fallback inside the running server, so the control token
   must be signed with whichever secret is ACTUALLY active in this env. */
const ACTIVE_DEV_SECRET =
  process.env.ADMIN_SESSION_SECRET && process.env.ADMIN_SESSION_SECRET.length >= 32
    ? process.env.ADMIN_SESSION_SECRET
    : DEV_FALLBACK_SECRET;
const devControlToken = craftSessionToken(
  ACTIVE_DEV_SECRET,
  adminRow?.id ?? "dev-control-sub",
  adminRow?.sessionVersion ?? 0
);

maybeDescribe("http-routes — live dev server (:3000)", () => {
  liveTest("GET /api/admin/me with a FORGED cookie (old public source constant) → 401", async () => {
    const res = await jfetch("/api/admin/me", {
      headers: { cookie: `ashrilogic-admin-session=${forgedToken}` },
    });
    // the pre-fix bug would have VERIFIED this token (source-code forgery)
    expect(res.status).toBe(401);
    expect(res.status).not.toBe(200);
  });

  liveTest("discrimination control: the SAME payload signed with the CURRENT dev secret → 200", async () => {
    if (!adminRow) {
      console.log("[http-routes] no admin rows in the dev DB — control probe not applicable");
      return;
    }
    const res = await jfetch("/api/admin/me", {
      headers: { cookie: `ashrilogic-admin-session=${devControlToken}` },
    });
    // This dev deployment signs with the documented demo fallback (no
    // ADMIN_SESSION_SECRET provisioned) — a valid signature over the very
    // same payload resolves 200, proving the 401 above is HMAC rejection
    // of the old constant, not an id/lookup artifact.
    expect(res.status).toBe(200);
    const body = (await res.json()) as { id?: string };
    expect(body.id).toBe(adminRow.id);
  });

  liveTest("POST /api/admin/login with malformed JSON + matching Origin → 400 (bounded reader)", async () => {
    const res = await jfetch("/api/admin/login", {
      method: "POST",
      headers: { "content-type": "application/json", origin: BASE },
      body: "{",
    });
    expect(res.status).toBe(400);
    const body = (await res.json()) as { error?: string };
    expect(body.error).toBe("Invalid JSON body");
  });

  liveTest("POST /api/admin/login with NO Origin/Referer + session cookie → 403 (strict origin guard)", async () => {
    const res = await jfetch("/api/admin/login", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        cookie: "ashrilogic-admin-session=anything-at-all",
      },
      body: JSON.stringify({ username: "admin", password: "wrong-password" }),
    });
    expect(res.status).toBe(403);
    const body = (await res.json()) as { error?: string };
    expect(body.error).toBe("Origin header required for authenticated requests");
  });

  liveTest("POST /api/admin/login with a CROSS-ORIGIN Origin header → 403", async () => {
    const res = await jfetch("/api/admin/login", {
      method: "POST",
      headers: { "content-type": "application/json", origin: "http://evil.example" },
      body: JSON.stringify({ username: "admin", password: "wrong-password" }),
    });
    expect(res.status).toBe(403);
    const body = (await res.json()) as { error?: string };
    expect(body.error).toBe("Cross-origin request rejected");
  });

  liveTest("GET /api/instances anonymous → 200 with a SANITIZED directory (admin.email always \"\")", async () => {
    const res = await jfetch("/api/instances");
    expect(res.status).toBe(200);
    const listing = (await res.json()) as unknown;
    expect(Array.isArray(listing)).toBe(true);
    const instances = listing as { admin?: { email?: string } }[];
    for (const instance of instances) {
      expect(instance.admin).toBeTypeOf("object");
      expect(instance.admin?.email).toBe("");
    }
  });

  liveTest("POST /api/sites/<nonexistent>/customers/login → 404 (member-login routes removed, never a 500)", async () => {
    // randomized ids/emails per run so keys never accumulate across runs.
    // ROUND 44 — the member-login process was REMOVED from the public
    // websites: the whole customers auth tree (login/register/logout/me/
    // verify/resend) is gone; the surface must 404 cleanly.
    const siteId = `no-such-site-${Date.now()}-${Math.floor(Math.random() * 1e6)}`;
    const email = `probe-${Date.now()}-${Math.floor(Math.random() * 1e6)}@example.com`;
    const res = await jfetch(`/api/sites/${siteId}/customers/login`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email, password: "probe-wrong-password" }),
    });
    expect(res.status).toBe(404);
    expect(res.status).not.toBe(500);
  });

  liveTest("platform security headers are present on /", async () => {
    const res = await jfetch("/");
    expect(res.status).toBe(200);
    expect(res.headers.get("x-content-type-options")).toBe("nosniff");
    expect(res.headers.get("x-frame-options")).toBe("DENY");
    expect(res.headers.get("referrer-policy")).toBe("strict-origin-when-cross-origin");
    /* ROUND 132 unlocked camera=(self)/usb=(self)/bluetooth=(self) for the
     * barcode scanner surfaces (see next.config.ts) while keeping the other
     * sensitive features hard-blocked — the assertion tracks the CURRENT
     * policy instead of the pre-R132 blanket deny. */
    expect(res.headers.get("permissions-policy")).toContain("camera=(self)");
    expect(res.headers.get("permissions-policy")).toContain("microphone=()");
    expect(res.headers.get("permissions-policy")).toContain("geolocation=()");
    expect(res.headers.get("permissions-policy")).toContain("payment=()");
    expect(res.headers.get("permissions-policy")).toContain("interest-cohort=()");
    const csp = res.headers.get("content-security-policy") ?? "";
    expect(csp).toContain("default-src 'self'");
    expect(csp).toContain("object-src 'none'");
    expect(csp).toContain("frame-ancestors 'none'");
  });
});
