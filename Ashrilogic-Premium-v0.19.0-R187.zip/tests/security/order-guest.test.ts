/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — GUEST ORDER PROJECTION (ROUND 119).
 *
 * The shared builder behind BOTH guest-facing receipt surfaces (the track
 * API + the standalone receipt page). Proves the projection contract:
 *  - PII-free: no customer identity ever appears in the output;
 *  - price-column-free: items carry name + qty + image only;
 *  - totals convert minor → display units; discount 0 stays 0;
 *  - legacy NULL code → "" (never null into the DTO);
 *  - an unknown status value degrades to "pending" (the zod catch);
 *  - the v2 items snapshot parses; malformed JSON degrades to empty items
 *    while the totals still carry the value (the documented fail-soft);
 *  - statusHistory: null/absent → empty trail; a valid trail parses.
 */
import { beforeAll, describe, expect, test } from "bun:test";
import { ensureDemoEnv } from "./test-setup";

beforeAll(async () => {
  ensureDemoEnv();
});

async function mod() {
  ensureDemoEnv();
  return import("@/lib/server/order-guest");
}

function row(over: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    code: "ELT-8F3K2Q",
    /* the REAL v2 snapshot shape: { v: 2, items: [{ recordId, name, price
       (integer minor units), qty, image? (managed ref) }] } */
    itemsJson: JSON.stringify({
      v: 2,
      items: [
        {
          recordId: "rec-1",
          name: "قطعة طبية أ",
          price: 12500,
          qty: 2,
          image: `/api/images/${"a".repeat(64)}`,
        },
        { recordId: "rec-2", name: "Item B", price: 9900, qty: 1 },
      ],
    }),
    total: 34_900,
    discount: 5_000,
    couponCode: "WELCOME10",
    currency: "SAR",
    status: "confirmed",
    statusNote: "جارٍ التجهيز",
    statusHistoryJson: JSON.stringify([
      { status: "pending", at: "2026-09-19T10:00:00.000Z", by: "system" },
      { status: "confirmed", at: "2026-09-19T10:05:00.000Z", by: "owner" },
    ]),
    createdAt: new Date("2026-09-19T10:00:00.000Z"),
    updatedAt: new Date("2026-09-19T10:05:00.000Z"),
    ...over,
  };
}

describe("guest order projection", () => {
  test("the happy path: shape + conversion + trail", async () => {
    const { guestOrderProjection } = await mod();
    const p = guestOrderProjection(row() as never);
    expect(p.code).toBe("ELT-8F3K2Q");
    expect(p.items).toHaveLength(2);
    expect(p.items[0]).toEqual({ name: "قطعة طبية أ", qty: 2, image: expect.any(String) });
    expect(p.items[1]).toEqual({ name: "Item B", qty: 1, image: null });
    /* minor → display units */
    expect(p.total).toBe(349);
    expect(p.discount).toBe(50);
    expect(p.couponCode).toBe("WELCOME10");
    expect(p.currency).toBe("SAR");
    expect(p.status).toBe("confirmed");
    expect(p.statusNote).toBe("جارٍ التجهيز");
    expect(p.statusHistory).toHaveLength(2);
    expect(p.statusHistory[1].status).toBe("confirmed");
    expect(p.createdAt).toBe("2026-09-19T10:00:00.000Z");
    /* NO customer identity anywhere in the output */
    expect(JSON.stringify(p)).not.toContain("customer");
    expect(JSON.stringify(p)).not.toContain("phone");
    /* NO unit prices in the items (the guest projection's contract) */
    expect(JSON.stringify(p.items)).not.toContain("priceMinor");
  });

  test("legacy NULL code → empty string (never null into the DTO)", async () => {
    const { guestOrderProjection } = await mod();
    const p = guestOrderProjection(row({ code: null }) as never);
    expect(p.code).toBe("");
  });

  test("zero discount stays exactly 0 (no display-unit rounding)", async () => {
    const { guestOrderProjection } = await mod();
    const p = guestOrderProjection(row({ discount: 0 }) as never);
    expect(p.discount).toBe(0);
  });

  test("unknown status degrades to pending (the zod catch)", async () => {
    const { guestOrderProjection } = await mod();
    const p = guestOrderProjection(row({ status: "weird-future-state" }) as never);
    expect(p.status).toBe("pending");
  });

  test("malformed itemsJson degrades to empty items — totals still carry", async () => {
    const { guestOrderProjection } = await mod();
    const p = guestOrderProjection(row({ itemsJson: "{not json" }) as never);
    expect(p.items).toEqual([]);
    expect(p.total).toBe(349);
  });

  test("null statusHistory → empty trail (legacy rows)", async () => {
    const { guestOrderProjection } = await mod();
    const p = guestOrderProjection(row({ statusHistoryJson: null }) as never);
    expect(p.statusHistory).toEqual([]);
  });

  test("v1 legacy items array still parses (recordId-bearing rows, no images)", async () => {
    const { guestOrderProjection } = await mod();
    const p = guestOrderProjection(
      row({
        itemsJson: JSON.stringify([
          { recordId: "legacy-1", name: "Legacy Item", price: 12.5, qty: 2 },
        ]),
      }) as never
    );
    /* the shared parser's documented v1 degradation: display-float rows
     * parse for name/qty; no image ever survives (v1 predates them) */
    expect(p.items).toHaveLength(1);
    expect(p.items[0].name).toBe("Legacy Item");
    expect(p.items[0].qty).toBe(2);
    expect(p.items.every((it) => it.image === null)).toBe(true);
  });
});
