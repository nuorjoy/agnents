/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — L-1/L-2 (audit): X-Forwarded-Host trust is gated on
 * the SHARED proxy-trust policy (src/lib/server/proxy-trust.ts), never
 * granted unconditionally.
 *
 * The spoof scenario under test — a client-supplied (leftmost)
 * X-Forwarded-Host hop that matches the attacker's Origin, hoping the
 * same-origin guard accepts it and the WebAuthn RP identity mints itself
 * for the attacker's domain:
 *  - UNTRUSTED modes ("never"; "conditional" without the platform edge
 *    anchor, including an EMPTY edge header): the origin decision uses the
 *    REAL Host header only (403 for the spoofed Origin) and the WebAuthn
 *    RP identity derives from the Host (request URL) — fail closed;
 *  - TRUSTED modes ("always"; "conditional" behind the platform edge):
 *    X-Forwarded-Host is still honored (the proxied world keeps working —
 *    the bundled Caddyfile stamps it in overwrite mode, Vercel's edge sets
 *    it), preserving the ROUND 43 preview/re-hosting behavior.
 *
 * Pure unit tests — Requests are constructed locally; the proxy-trust mode
 * is flipped per case and restored afterwards (the policy re-reads
 * TRUST_PROXY_MODE on every call, never caching it at module scope).
 */
import { describe, test, expect, afterEach } from "bun:test";
import { originViolation } from "@/lib/server/origin-guard";
import { effectiveHost, rpConfig } from "@/lib/server/webauthn";
import { forwardedHeadersTrusted, proxyTrustMode } from "@/lib/server/proxy-trust";

const REAL_MODE = process.env.TRUST_PROXY_MODE;

afterEach(() => {
  if (REAL_MODE === undefined) delete process.env.TRUST_PROXY_MODE;
  else process.env.TRUST_PROXY_MODE = REAL_MODE;
});

/** the Host the request is REALLY served under */
const HOST = "real.example";
/** the client-supplied leftmost X-Forwarded-Host hop (the spoof) */
const SPOOF = "evil.example";

/** mutating request whose Origin matches ONLY the spoofed XFH hop */
function spoofedReq(extra: Record<string, string> = {}): Request {
  return new Request(`http://${HOST}/api/probe`, {
    method: "POST",
    headers: {
      host: HOST,
      "x-forwarded-host": SPOOF,
      origin: `https://${SPOOF}`,
      ...extra,
    },
  });
}

/** mutating request whose Origin matches the REAL Host (no XFH) */
function honestReq(): Request {
  return new Request(`http://${HOST}/api/probe`, {
    method: "POST",
    headers: { host: HOST, origin: `https://${HOST}` },
  });
}

describe("proxy-trust — the shared helper itself", () => {
  test("\"never\" → forwarded headers untrusted", () => {
    process.env.TRUST_PROXY_MODE = "never";
    expect(forwardedHeadersTrusted(spoofedReq())).toBe(false);
  });

  test("\"conditional\" without the platform edge → untrusted (fail closed)", () => {
    process.env.TRUST_PROXY_MODE = "conditional";
    expect(forwardedHeadersTrusted(spoofedReq())).toBe(false);
  });

  test("\"conditional\" with an EMPTY edge header → untrusted (an empty value is not an edge signature)", () => {
    process.env.TRUST_PROXY_MODE = "conditional";
    expect(forwardedHeadersTrusted(spoofedReq({ "x-vercel-forwarded-for": "" }))).toBe(false);
  });

  test("\"conditional\" behind the platform edge → trusted", () => {
    process.env.TRUST_PROXY_MODE = "conditional";
    expect(
      forwardedHeadersTrusted(spoofedReq({ "x-vercel-forwarded-for": "203.0.113.9" }))
    ).toBe(true);
  });

  test("\"always\" → trusted (the proxy contract)", () => {
    process.env.TRUST_PROXY_MODE = "always";
    expect(forwardedHeadersTrusted(spoofedReq())).toBe(true);
  });

  test("unset / unrecognized resolves to the historical \"always\" default (production refuses at boot instead)", () => {
    delete process.env.TRUST_PROXY_MODE;
    expect(proxyTrustMode()).toBe("always");
    process.env.TRUST_PROXY_MODE = "sometimes";
    expect(proxyTrustMode()).toBe("always");
  });
});

describe("L-1 — origin-guard: spoofed XFH hops are ignored when the chain is untrusted", () => {
  test("mode \"never\": Origin matching ONLY the spoofed XFH hop → 403 (Host is the sole trusted host)", () => {
    process.env.TRUST_PROXY_MODE = "never";
    const violation = originViolation(spoofedReq());
    expect(violation).not.toBeNull();
    expect(violation?.status).toBe(403);
  });

  test("mode \"conditional\" without the edge anchor: same spoof → 403", () => {
    process.env.TRUST_PROXY_MODE = "conditional";
    const violation = originViolation(spoofedReq());
    expect(violation?.status).toBe(403);
  });

  test("mode \"never\": an Origin matching the REAL Host still passes (the guard stays Host-functional)", () => {
    process.env.TRUST_PROXY_MODE = "never";
    expect(originViolation(honestReq())).toBeNull();
  });

  test("mode \"never\": Origin matching the Host passes even with a spoofed XFH present (spoof is inert)", () => {
    process.env.TRUST_PROXY_MODE = "never";
    const req = new Request(`http://${HOST}/api/probe`, {
      method: "POST",
      headers: { host: HOST, "x-forwarded-host": SPOOF, origin: `https://${HOST}` },
    });
    expect(originViolation(req)).toBeNull();
  });
});

describe("L-1 — origin-guard: XFH is still honored when the policy trusts the chain", () => {
  test("mode \"always\": Origin matching the XFH hop → passes (ROUND 43 preview/re-hosting proxy world)", () => {
    process.env.TRUST_PROXY_MODE = "always";
    expect(originViolation(spoofedReq())).toBeNull();
  });

  test("mode \"conditional\" behind the platform edge: Origin matching the XFH hop → passes", () => {
    process.env.TRUST_PROXY_MODE = "conditional";
    expect(
      originViolation(spoofedReq({ "x-vercel-forwarded-for": "203.0.113.9" }))
    ).toBeNull();
  });
});

describe("L-2 — WebAuthn RP identity: spoofed XFH cannot steer it when untrusted", () => {
  test("mode \"never\": effectiveHost uses the Host (request URL) only", () => {
    process.env.TRUST_PROXY_MODE = "never";
    expect(effectiveHost(spoofedReq())).toBe(HOST);
    expect(rpConfig(spoofedReq()).rpID).toBe(HOST);
  });

  test("mode \"conditional\" without the edge anchor: same — Host only", () => {
    process.env.TRUST_PROXY_MODE = "conditional";
    expect(effectiveHost(spoofedReq())).toBe(HOST);
    expect(rpConfig(spoofedReq()).rpID).toBe(HOST);
  });

  test("mode \"never\": the acceptable-origin set carries no origin for the spoofed host", () => {
    process.env.TRUST_PROXY_MODE = "never";
    const { origins } = rpConfig(spoofedReq());
    for (const o of origins) {
      expect(o.includes(SPOOF)).toBe(false);
    }
  });

  test("mode \"always\": effectiveHost still prefers the forwarded chain (single-hop overwrite stamp)", () => {
    process.env.TRUST_PROXY_MODE = "always";
    expect(effectiveHost(spoofedReq())).toBe(SPOOF);
    expect(rpConfig(spoofedReq()).rpID).toBe(SPOOF);
  });

  test("mode \"conditional\" behind the platform edge: forwarded chain honored", () => {
    process.env.TRUST_PROXY_MODE = "conditional";
    const req = spoofedReq({ "x-vercel-forwarded-for": "203.0.113.9" });
    expect(effectiveHost(req)).toBe(SPOOF);
    expect(rpConfig(req).rpID).toBe(SPOOF);
  });
});
