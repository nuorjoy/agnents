/// <reference types="bun-types" />
/**
 * Ashrilogic — ROUND 137 security regression: the WEBHOOK HTTP PRODUCTION
 * LAW (Phase 2, finding 1).
 *
 * Through R136 plain-http loopback destinations were accepted in EVERY
 * environment (the guard's own comment called it "the documented dev/e2e
 * escape hatch" — but nothing enforced the dev-only half). The law now:
 *
 *   • NODE_ENV=production → http is REFUSED (reason "scheme"), with the
 *     single explicit operator opt-in ALLOW_HTTP_LOOPBACK_WEBHOOKS=1;
 *   • the opt-in NEVER widens the host restriction — loopback literals
 *     only, in every environment;
 *   • dispatch re-validates the same way, so legacy/restored rows cannot
 *     bypass the law.
 */
import { describe, test, expect, beforeAll, afterAll } from "bun:test";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { ensureDemoEnv, getTestDb } from "./test-setup";

ensureDemoEnv();

let db: Awaited<ReturnType<typeof getTestDb>>;
let webhooks: typeof import("@/lib/server/webhooks");

const INSTANCE = "webhook-http-law-instance";

type Env = { nodeEnv?: string; hatch?: string };
async function withEnv<T>(env: Env, fn: () => T | Promise<T>): Promise<T> {
  const savedEnv = process.env.NODE_ENV;
  const savedHatch = process.env.ALLOW_HTTP_LOOPBACK_WEBHOOKS;
  try {
    (process.env as { NODE_ENV?: string }).NODE_ENV = env.nodeEnv;
    if (env.hatch === undefined) delete process.env.ALLOW_HTTP_LOOPBACK_WEBHOOKS;
    else process.env.ALLOW_HTTP_LOOPBACK_WEBHOOKS = env.hatch;
    return await fn();
  } finally {
    (process.env as { NODE_ENV?: string }).NODE_ENV = savedEnv;
    if (savedHatch === undefined) delete process.env.ALLOW_HTTP_LOOPBACK_WEBHOOKS;
    else process.env.ALLOW_HTTP_LOOPBACK_WEBHOOKS = savedHatch;
  }
}

beforeAll(async () => {
  db = await getTestDb();
  webhooks = await import("@/lib/server/webhooks");
  await db.instance.create({
    data: {
      id: INSTANCE,
      systemId: "inventory",
      orgJson: JSON.stringify({ name: "HTTP Law Test", currency: "SAR" }),
      adminJson: "{}",
      adminEmailIndex: "http-law@test",
      prefsJson: "{}",
      modulesJson: JSON.stringify(["inventory"]),
    },
  });
});

afterAll(async () => {
  webhooks.__setWebhookTransportForTests(null);
  webhooks.__setWebhookDnsForTests(null);
  try {
    await db.instance.deleteMany({ where: { id: INSTANCE } });
    await db.webhookEndpoint.deleteMany({});
    await db.webhookDelivery.deleteMany({});
  } catch {
    /* throwaway DB */
  }
});

describe("ROUND 137 — webhook HTTP production law (URL guard)", () => {
  test("dev: http to a loopback literal is accepted (the documented e2e receiver)", () => {
    withEnv({ nodeEnv: "development" }, () => {
      expect(webhooks.assertSafeWebhookUrl("http://localhost:3030/webhook").ok).toBe(true);
      expect(webhooks.assertSafeWebhookUrl("http://127.0.0.1:3030/webhook").ok).toBe(true);
      expect(webhooks.assertSafeWebhookUrl("http://[::1]:3030/webhook").ok).toBe(true);
    });
  });

  test("dev: http to ANY remote host is refused (loopback-only, always)", () => {
    withEnv({ nodeEnv: "development" }, () => {
      const v = webhooks.assertSafeWebhookUrl("http://example.com/webhook");
      expect(v.ok).toBe(false);
      if (!v.ok) expect(v.reason).toBe("scheme");
    });
  });

  test("dev: http to a PRIVATE IP literal is refused (never a loopback escape)", () => {
    withEnv({ nodeEnv: "development" }, () => {
      for (const url of [
        "http://10.0.0.5/webhook",
        "http://192.168.1.10/webhook",
        "http://169.254.169.254/latest/meta-data",
        "http://[fd00::1]/webhook",
      ]) {
        const v = webhooks.assertSafeWebhookUrl(url);
        expect(v.ok).toBe(false);
      }
    });
  });

  test("PRODUCTION: http is REFUSED — even to loopback (the default posture)", () => {
    withEnv({ nodeEnv: "production" }, () => {
      for (const url of [
        "http://localhost:3030/webhook",
        "http://127.0.0.1:3030/webhook",
        "http://[::1]:3030/webhook",
      ]) {
        const v = webhooks.assertSafeWebhookUrl(url);
        expect(v.ok).toBe(false);
        if (!v.ok) expect(v.reason).toBe("scheme");
      }
    });
  });

  test("PRODUCTION: the explicit opt-in re-opens ONLY loopback http", () => {
    withEnv({ nodeEnv: "production", hatch: "1" }, () => {
      expect(webhooks.assertSafeWebhookUrl("http://localhost:3030/webhook").ok).toBe(true);
      const remote = webhooks.assertSafeWebhookUrl("http://example.com/webhook");
      expect(remote.ok).toBe(false);
      if (!remote.ok) expect(remote.reason).toBe("scheme");
    });
  });

  test("PRODUCTION: https destinations are unaffected by the http law", () => {
    withEnv({ nodeEnv: "production" }, () => {
      expect(webhooks.assertSafeWebhookUrl("https://example.com/webhook").ok).toBe(true);
    });
  });
});

describe("ROUND 137 — webhook HTTP production law (dispatch re-validation)", () => {
  test("a LEGACY http row (restored backup / pre-law registration) never dispatches in production", async () => {
    /* the transport stub records everything that FIRES — the legacy row
     * must be refused BEFORE any transport call, classifying unsafe-url */
    const calls: string[] = [];
    webhooks.__setWebhookDnsForTests(async () => [{ address: "93.184.216.34", family: 4 }]);
    webhooks.__setWebhookTransportForTests(async (url) => {
      calls.push(url);
      return { ok: true, status: 200 };
    });

    const endpoint = await db.webhookEndpoint.create({
      data: {
        id: "ep-legacy-http",
        instanceId: INSTANCE,
        url: "http://localhost:3030/webhook",
        secret: "a".repeat(64),
        eventsJson: JSON.stringify(["order.placed"]),
      },
    });
    const delivery = await db.webhookDelivery.create({
      data: {
        endpointId: endpoint.id,
        instanceId: INSTANCE,
        event: "order.placed",
        payloadJson: webhooks.buildWebhookPayload(INSTANCE, "order.placed", { id: "o1" }),
        status: "pending",
      },
    });

    await withEnv({ nodeEnv: "production" }, async () => {
      await webhooks.dispatchDueWebhooks();
    });

    expect(calls.length).toBe(0); /* NEVER transported */
    const row = await db.webhookDelivery.findUnique({ where: { id: delivery.id } });
    expect(row?.status).toBe("failed");
    expect(row?.error).toBe("unsafe-url");
    expect(row?.attempts).toBe(1);
    /* the lease fields are cleared on settle */
    expect(row?.leaseId).toBeNull();
    expect(row?.lockedUntil).toBeNull();
  });
});

/* -------------------- ROUND 146 — the hatch is PORT-SCOPED -------------------- */

describe("ROUND 146 — production loopback-http hatch allows only receiver ports", () => {
  test("with the hatch on, port 3030 (and the operator allowlist) works; other loopback ports are refused", async () => {
    await withEnv({ nodeEnv: "production", hatch: "1" }, () => {
      // the dev receiver port stays legal
      expect(webhooks.assertSafeWebhookUrl("http://127.0.0.1:3030/webhook").ok).toBe(true);
      expect(webhooks.assertSafeWebhookUrl("http://[::1]:3030/webhook").ok).toBe(true);
      // infrastructure ports on loopback are refused (reason "port")
      expect(webhooks.assertSafeWebhookUrl("http://127.0.0.1:5432/webhook")).toEqual({
        ok: false,
        reason: "port",
      });
      expect(webhooks.assertSafeWebhookUrl("http://localhost:6379/webhook")).toEqual({
        ok: false,
        reason: "port",
      });
      // no port = 80 → refused too (the allowlist carries no implicit default)
      expect(webhooks.assertSafeWebhookUrl("http://localhost/webhook")).toEqual({
        ok: false,
        reason: "port",
      });
    });
  });

  test("the operator allowlist extends the legal ports; invalid entries are ignored", async () => {
    const saved = process.env.WEBHOOK_ALLOWED_HTTP_LOOPBACK_PORTS;
    try {
      process.env.WEBHOOK_ALLOWED_HTTP_LOOPBACK_PORTS = "8443, 99999, not-a-port";
      await withEnv({ nodeEnv: "production", hatch: "1" }, () => {
        expect(webhooks.assertSafeWebhookUrl("http://127.0.0.1:8443/webhook").ok).toBe(true);
        expect(webhooks.assertSafeWebhookUrl("http://127.0.0.1:8444/webhook").ok).toBe(false);
      });
    } finally {
      if (saved === undefined) delete process.env.WEBHOOK_ALLOWED_HTTP_LOOPBACK_PORTS;
      else process.env.WEBHOOK_ALLOWED_HTTP_LOOPBACK_PORTS = saved;
    }
  });

  test("dev/test keeps the permissive any-port loopback contract (no regression to the documented dev shape)", async () => {
    await withEnv({ nodeEnv: "development" }, () => {
      expect(webhooks.assertSafeWebhookUrl("http://127.0.0.1:9/hook").ok).toBe(true);
      expect(webhooks.assertSafeWebhookUrl("http://[::1]/hook").ok).toBe(true);
    });
    await withEnv({ nodeEnv: "test" }, () => {
      expect(webhooks.assertSafeWebhookUrl("http://127.0.0.1:9/hook").ok).toBe(true);
    });
  });

  test("the transport prologue no longer has the TDZ landmine (a synchronous throw classifies cleanly)", async () => {
    /* pinnedHttpPost's finish() used to clear a const declared after the
     * try — a prologue throw became a ReferenceError instead of a clean
     * network-class result. Drive it through the public dispatch path with
     * an unreachable URL: the attempt must settle as an errorClass, never
     * reject. */
    const { __setWebhookTransportForTests } = webhooks;
    __setWebhookTransportForTests(null);
    /* an invalid URL passed straight to the transport double-throw path is
     * not reachable through validate-then-dispatch; pin the structural fix:
     * the file declares the timer BEFORE finish uses it. */
    const source = readFileSync(
      join(import.meta.dir, "..", "..", "src/lib/server/webhooks.ts"),
      "utf8"
    );
    const timerDecl = source.indexOf("let hardTimer");
    const finishDecl = source.indexOf("const finish =");
    const clearTimeoutUse = source.indexOf("if (hardTimer !== undefined) clearTimeout(hardTimer)");
    expect(timerDecl).toBeGreaterThan(-1);
    expect(finishDecl).toBeGreaterThan(timerDecl);
    expect(clearTimeoutUse).toBeGreaterThan(timerDecl);
    expect(source).not.toContain("const hardTimer = setTimeout");
  });
});
