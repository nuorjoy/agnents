/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 166: the attendance domain (الحضور والغياب)
 * — src/server/domains/attendance + the PURE 8-state engine in
 * src/lib/server/attendance/derive.ts.
 *
 * THE DESIGN THIS PINSHUTS: the derived daily state is NEVER persisted —
 * it is computed from Movements + Policy + Allowances through a pure
 * engine with an injected clock (tests 5–11 drive synthetic 08:00/08:25
 * check-ins with NO database at all), while the movement/QR lifecycle
 * runs through the real service against the throwaway database with NO
 * server, NO HTTP (the campaign-dispatch pattern):
 *
 *   1. VALID ID          — manual check-in for a live resident: row
 *                          created with SERVER-stamped occurredAt +
 *                          recordedBy (never client input).
 *   2. INVALID ID        — unknown studentCode → 404 STUDENT_NOT_FOUND.
 *   3. DUPLICATE CHECK-IN— second "in" → 409 DUPLICATE_CHECK_IN.
 *   4. INVALID CHECK-OUT — "out" with no prior "in" → 409.
 *   5–11. THE 8 STATES   — present / late(+25) / absent (both arms) /
 *                          excused / authorized / on_leave /
 *                          outside_with_permission OVERDUE (pure engine,
 *                          injected clock).
 *   12. EXPIRED QR       — 410 QR_EXPIRED.
 *   13. REUSED QR        — redeem once ok, replay → 410 QR_REUSED (the
 *                          CAS single-use claim).
 *   14. UNAUTHORIZED     — mint for an unknown/deleted student → 404;
 *                          redeem a token whose student left the roster →
 *                          the movement is REJECTED.
 *   15. AUDIT LOG        — movements + policy + allowance mutations leave
 *                          audit rows with the right kinds.
 *   16. ROSTER           — the full service projection: residents rows →
 *                          derived board + counts + lazy default policy
 *                          (clock-robust state assertions) + a malformed
 *                          date is a loud 400.
 *
 * ROUND 167 (دوام, Task 10-d) — tests 17–22 pin the SHIFT SCHEDULE law:
 * the optional shifts array (empty = the byte-identical legacy path —
 * tests 5–11 NEVER send shifts and stay untouched), the arrival→shift
 * map, per-shift late math from the shift's own start, the partial-hours
 * metadata law, the service's SHIFTS_OVERLAP rejection + zod shape, and
 * the legacy-column stamping on save. They run AFTER test 16 (which
 * asserts the lazy DEFAULT policy) so the shared instance's defaults are
 * observed before any shift-aware PUT lands.
 */
import { describe, test, expect, beforeAll, afterAll } from "bun:test";
import { ensureDemoEnv, getTestDb, type TestDb } from "./test-setup";

/* Bind the throwaway DB BEFORE any db-binding module imports (the
 * isolation-canary contract from test-setup). */
ensureDemoEnv();

let db: TestDb;
let service: typeof import("@/server/domains/attendance/service");
let derive: typeof import("@/lib/server/attendance/derive");
let HttpError: typeof import("@/lib/server/route").HttpError;
type AttendanceActor = import("@/server/domains/attendance/service").AttendanceActor;
type AttendanceShift = import("@/lib/server/attendance/derive").AttendanceShift;
type AttendancePolicyInput = import("@/lib/server/attendance/derive").AttendancePolicyInput;

const RUN = Math.random().toString(36).slice(2, 8);

/* the synthetic SAMS workspace + its roster (residents ModuleRecords) */
let instanceId = "";
let actor: AttendanceActor;

const S1 = "RES-00000001"; /* test 1 + 15 */
const S2 = "RES-00000002"; /* test 3 + 15 */
const S3 = "RES-00000003"; /* test 4 */
const S4 = "RES-00000004"; /* test 14 — soft-deleted mid-test */
const S5 = "RES-00000005"; /* test 13 (QR reuse) */

/** One residents ModuleRecord row (values aligned with the preset cols). */
async function seedResident(code: string, name: string): Promise<string> {
  const row = await db.moduleRecord.create({
    data: {
      instanceId,
      moduleId: "residents",
      dataJson: JSON.stringify([
        code,
        name,
        `2024${Math.random().toString().slice(2, 8)}`,
        "جامعة الملك سعود",
        "كلية الحاسب",
        "RM-002001",
        "مبنى أ",
        "2026-01-01",
        "2026-12-31",
        "1200.00",
        "0500000001",
        "active",
      ]),
      statusKey: "active",
    },
    select: { id: true },
  });
  return row.id;
}

async function expectHttpError(
  promise: Promise<unknown>,
  status: number,
  code: string
): Promise<import("@/lib/server/route").HttpError> {
  let caught: unknown;
  try {
    await promise;
  } catch (e) {
    caught = e;
  }
  expect(caught).toBeInstanceOf(HttpError);
  const err = caught as InstanceType<typeof HttpError>;
  expect(err.status).toBe(status);
  expect(err.code).toBe(code);
  return err;
}

beforeAll(async () => {
  db = await getTestDb();
  service = await import("@/server/domains/attendance/service");
  derive = await import("@/lib/server/attendance/derive");
  ({ HttpError } = await import("@/lib/server/route"));

  const instance = await db.instance.create({
    data: {
      systemId: "student-accommodation",
      orgJson: JSON.stringify({ name: `سكن الحضور ${RUN}`, country: "SA", currency: "SAR" }),
      adminJson: JSON.stringify({ name: "مالك", email: `owner-${RUN}@example.com`, role: "owner" }),
      prefsJson: JSON.stringify({ lang: "ar", theme: "light", notif: true, backup: true, audit: true, demo: false }),
      modulesJson: JSON.stringify(["residents", "attendance"]),
    },
    select: { id: true },
  });
  instanceId = instance.id;
  actor = {
    stampId: `staff:qa-${RUN}`,
    stampName: `qa-owner-${RUN}`,
    audit: {
      actorType: "instance",
      actorId: instanceId,
      actorName: `qa-owner-${RUN}`,
    },
  };

  for (const [code, name] of [
    [S1, "طالب الحضور"],
    [S2, "طالب التكرار"],
    [S3, "طالب الخروج"],
    [S4, "طالب المحذوف"],
    [S5, "طالب الرمز"],
  ] as const) {
    await seedResident(code, name);
  }
});

afterAll(async () => {
  if (!db) return;
  /* the instance delete cascades movements/policy/QR/allowances/records */
  await db.auditLog.deleteMany({ where: { actorId: instanceId } }).catch(() => undefined);
  await db.attendanceQrToken.deleteMany({ where: { instanceId } }).catch(() => undefined);
  await db.attendanceMovement.deleteMany({ where: { instanceId } }).catch(() => undefined);
  await db.attendanceAllowance.deleteMany({ where: { instanceId } }).catch(() => undefined);
  await db.attendancePolicy.deleteMany({ where: { instanceId } }).catch(() => undefined);
  await db.moduleRecord.deleteMany({ where: { instanceId, moduleId: "residents" } }).catch(() => undefined);
  await db.instance.deleteMany({ where: { id: instanceId } }).catch(() => undefined);
});

/* ------------------------------------------------------------------ */
/* the movement lifecycle (service, real database)                     */
/* ------------------------------------------------------------------ */

describe("ROUND 166 — attendance movements (the alternation law)", () => {
  test("1. VALID ID — manual check-in for a live resident (server-stamped row)", async () => {
    const before = Date.now();
    const { movement, state } = await service.recordMovement(actor, instanceId, {
      studentCode: S1,
      direction: "in",
    });
    expect(movement.studentCode).toBe(S1);
    expect(movement.method).toBe("manual");
    expect(movement.direction).toBe("in");
    /* SERVER stamps — occurredAt inside the test's own wall-clock window */
    const occurred = Date.parse(movement.occurredAt);
    expect(occurred).toBeGreaterThanOrEqual(before - 1000);
    expect(occurred).toBeLessThanOrEqual(Date.now() + 1000);
    expect(movement.recordedById).toBe(actor.stampId);
    expect(movement.recordedByName).toBe(actor.stampName);
    /* an "in" movement always derives present|late */
    expect(["present", "late"]).toContain(state.state);

    const row = await db.attendanceMovement.findFirst({
      where: { instanceId, studentCode: S1 },
    });
    expect(row).toBeTruthy();
    expect(row?.method).toBe("manual");
    expect(row?.recordedById).toBe(actor.stampId);
  });

  test("2. INVALID ID — movement for an unknown studentCode → 404 STUDENT_NOT_FOUND", async () => {
    await expectHttpError(
      service.recordMovement(actor, instanceId, {
        studentCode: "RES-99999999",
        direction: "in",
      }),
      404,
      "STUDENT_NOT_FOUND"
    );
  });

  test("3. DUPLICATE CHECK-IN — second consecutive \"in\" → 409", async () => {
    const first = await service.recordMovement(actor, instanceId, {
      studentCode: S2,
      direction: "in",
    });
    expect(first.movement.direction).toBe("in");
    await expectHttpError(
      service.recordMovement(actor, instanceId, { studentCode: S2, direction: "in" }),
      409,
      "DUPLICATE_CHECK_IN"
    );
  });

  test("4. INVALID CHECK-OUT — \"out\" with no prior \"in\" today → 409", async () => {
    await expectHttpError(
      service.recordMovement(actor, instanceId, { studentCode: S3, direction: "out" }),
      409,
      "INVALID_CHECK_OUT"
    );
  });
});

/* ------------------------------------------------------------------ */
/* the 8-state engine (PURE — synthetic policy/movements/allowances,   */
/* injected clock, no database)                                        */
/* ------------------------------------------------------------------ */

describe("ROUND 166 — the pure 8-state derivation engine", () => {
  /** 2026-09-30 — a fixed local day; every timestamp below lives in it. */
  const day = new Date(2026, 8, 30);
  const at = (h: number, m: number) => new Date(2026, 8, 30, h, m);
  const POLICY = {
    dayStartMin: 480, /* 08:00 */
    dayEndMin: 1080, /* 18:00 */
    graceMin: 10,
    absenceEvalMin: 1260, /* 21:00 */
    requireReview: true,
  };

  test("5. PRESENT — check-in 08:05 (inside the grace window) + roster counts", () => {
    const state = derive.deriveDayState({
      policy: POLICY,
      studentCode: S1,
      day,
      movements: [{ studentCode: S1, direction: "in", occurredAt: at(8, 5) }],
      allowances: [],
      now: at(12, 0),
    });
    expect(state.state).toBe("present");
    expect(state.lateMinutes).toBeNull();
    expect(state.lastDirection).toBe("in");

    /* the batch surface: per-state counts over a 2-student roster */
    const { rows, counts } = derive.summarizeRoster({
      policy: POLICY,
      roster: [S1, S2],
      day,
      movements: [{ studentCode: S1, direction: "in", occurredAt: at(8, 5) }],
      allowances: [],
      now: at(12, 0),
    });
    expect(rows).toHaveLength(2);
    expect(counts.present).toBe(1);
    expect(counts.absent_pending_review).toBe(1);
  });

  test("6. LATE — check-in 08:25 → late by exactly 25 minutes", () => {
    const state = derive.deriveDayState({
      policy: POLICY,
      studentCode: S1,
      day,
      movements: [{ studentCode: S1, direction: "in", occurredAt: at(8, 25) }],
      allowances: [],
      now: at(12, 0),
    });
    expect(state.state).toBe("late");
    expect(state.lateMinutes).toBe(25);
  });

  test("7. ABSENT — no movement: settled after review-off OR past the cutoff", () => {
    /* arm 1 — review not required */
    expect(
      derive.deriveDayState({
        policy: { ...POLICY, requireReview: false },
        studentCode: S1,
        day,
        movements: [],
        allowances: [],
        now: at(12, 0),
      }).state
    ).toBe("absent");
    /* arm 2 — review required, but now is past the 21:00 cutoff */
    expect(
      derive.deriveDayState({
        policy: POLICY,
        studentCode: S1,
        day,
        movements: [],
        allowances: [],
        now: at(21, 30),
      }).state
    ).toBe("absent");
    /* arm 3 — the pending arm itself (before the cutoff, review on) */
    expect(
      derive.deriveDayState({
        policy: POLICY,
        studentCode: S1,
        day,
        movements: [],
        allowances: [],
        now: at(12, 0),
      }).state
    ).toBe("absent_pending_review");
  });

  test("8. EXCUSED ABSENCE — excused allowance covering the whole day", () => {
    const state = derive.deriveDayState({
      policy: POLICY,
      studentCode: S1,
      day,
      movements: [],
      allowances: [
        {
          studentCode: S1,
          kind: "excused",
          startsAt: new Date(2026, 8, 29), /* the day BEFORE midnight */
          endsAt: new Date(2026, 9, 1), /* the day AFTER midnight */
        },
      ],
      now: at(12, 0),
    });
    expect(state.state).toBe("excused_absence");
  });

  test("9. AUTHORIZED ABSENCE — authorized allowance covering the whole day", () => {
    const state = derive.deriveDayState({
      policy: POLICY,
      studentCode: S1,
      day,
      movements: [],
      allowances: [
        {
          studentCode: S1,
          kind: "authorized",
          startsAt: new Date(2026, 8, 29),
          endsAt: new Date(2026, 9, 1),
        },
      ],
      now: at(12, 0),
    });
    expect(state.state).toBe("authorized_absence");
  });

  test("10. ON LEAVE — leave allowance covering the whole day", () => {
    const state = derive.deriveDayState({
      policy: POLICY,
      studentCode: S1,
      day,
      movements: [],
      allowances: [
        {
          studentCode: S1,
          kind: "leave",
          startsAt: new Date(2026, 8, 29),
          endsAt: new Date(2026, 9, 1),
        },
      ],
      now: at(12, 0),
    });
    expect(state.state).toBe("on_leave");
  });

  test("11. OVERDUE PERMISSION — out under an outside allowance that ended 1h before now", () => {
    const state = derive.deriveDayState({
      policy: POLICY,
      studentCode: S1,
      day,
      movements: [{ studentCode: S1, direction: "out", occurredAt: at(10, 0) }],
      allowances: [
        {
          studentCode: S1,
          kind: "outside",
          startsAt: at(8, 0),
          endsAt: at(11, 0), /* ended 1h before `now` */
        },
      ],
      now: at(12, 0),
    });
    expect(state.state).toBe("outside_with_permission");
    expect(state.overdue).toBe(true);
    expect(state.expectedReturnAt?.getTime()).toBe(at(11, 0).getTime());
    /* the not-yet-overdue arm: same window, now inside it */
    const fresh = derive.deriveDayState({
      policy: POLICY,
      studentCode: S1,
      day,
      movements: [{ studentCode: S1, direction: "out", occurredAt: at(10, 0) }],
      allowances: [
        { studentCode: S1, kind: "outside", startsAt: at(8, 0), endsAt: at(11, 0) },
      ],
      now: at(10, 30),
    });
    expect(fresh.state).toBe("outside_with_permission");
    expect(fresh.overdue).toBe(false);
  });
});

/* ------------------------------------------------------------------ */
/* the day roster projection (service — residents → derived board)      */
/* ------------------------------------------------------------------ */

describe("ROUND 166 — the day roster projection", () => {
  test("16. ROSTER — residents rows become the derived board + counts", async () => {
    const board = await service.getRoster(instanceId);
    /* the lazy-created default policy rides the response */
    expect(board.policy.dayStartMin).toBe(480);
    expect(board.policy.dayEndMin).toBe(1080);
    expect(board.policy.graceMin).toBe(10);
    expect(board.policy.absenceEvalMin).toBe(1260);
    expect(board.policy.requireReview).toBe(true);
    /* today's date, server-local */
    const today = new Date();
    expect(board.date).toBe(
      `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(
        today.getDate()
      ).padStart(2, "0")}`
    );
    /* all five seeded residents, roster order, with the preset projection */
    expect(board.rows.map((r) => r.studentCode)).toEqual([S1, S2, S3, S4, S5]);
    const s1 = board.rows[0];
    expect(s1.name).toBe("طالب الحضور");
    expect(s1.room).toBe("RM-002001");
    expect(s1.building).toBe("مبنى أ");
    /* S1/S2 checked IN (tests 1+3): present|late regardless of wall-clock;
     * S3 has no movement: pending before the cutoff, absent after it. */
    expect(["present", "late"]).toContain(board.rows[0].state);
    expect(["present", "late"]).toContain(board.rows[1].state);
    expect(["absent_pending_review", "absent"]).toContain(board.rows[2].state);
    expect(board.rows[0].lastMovementAt).toBeTruthy();
    expect(board.rows[2].lastMovementAt).toBeNull();
    /* counts sum to the roster size (every state present, zeros included) */
    const total = Object.values(board.counts).reduce((sum, n) => sum + n, 0);
    expect(total).toBe(5);
    expect(board.counts.present + board.counts.late).toBe(2);
    /* a malformed date is a loud 400, never a silent today */
    await expectHttpError(service.getRoster(instanceId, "2026-13-40"), 400, "BAD_DATE");
  });
});

/* ------------------------------------------------------------------ */
/* the QR lifecycle (service, real database)                           */
/* ------------------------------------------------------------------ */

describe("ROUND 166 — attendance QR tokens (single-use, short-lived)", () => {
  test("12. EXPIRED QR — mint ttl 30s, expire it, redeem → 410 QR_EXPIRED", async () => {
    const minted = await service.mintQr(actor, instanceId, {
      studentCode: S1,
      direction: "out", /* S1 checked IN in test 1 → out is the legal next */
      ttlSeconds: 30,
    });
    expect(minted.token.length).toBeGreaterThanOrEqual(32);
    expect(minted.qrPayload).toContain('"v":1');
    expect(minted.qrPayload).toContain(instanceId);
    expect(minted.qrPayload).toContain(S1);

    /* simulate the clock running past the TTL (db-level, per the plan) */
    await db.attendanceQrToken.update({
      where: { tokenHash: service.qrTokenHash(minted.token) },
      data: { expiresAt: new Date(Date.now() - 60_000) },
    });
    await expectHttpError(
      service.redeemQr(instanceId, { token: minted.token }),
      410,
      "QR_EXPIRED"
    );
  });

  test("13. REUSED QR — redeem once ok (method qr), replay → 410 QR_REUSED", async () => {
    const minted = await service.mintQr(actor, instanceId, {
      studentCode: S5,
      direction: "in",
      ttlSeconds: 300,
    });
    const first = await service.redeemQr(instanceId, { token: minted.token });
    expect(first.movement.method).toBe("qr");
    expect(first.movement.recordedById).toBe("qr");
    expect(first.movement.qrTokenId).toBeTruthy();
    expect(["present", "late"]).toContain(first.state.state);

    const row = await db.attendanceQrToken.findUnique({
      where: { tokenHash: service.qrTokenHash(minted.token) },
    });
    expect(row?.usedAt).toBeTruthy();

    await expectHttpError(
      service.redeemQr(instanceId, { token: minted.token }),
      410,
      "QR_REUSED"
    );
  });

  test("14. UNAUTHORIZED USER — unknown student mint → 404; deleted-roster redeem rejected", async () => {
    /* minting for a student who is not on the roster at all */
    await expectHttpError(
      service.mintQr(actor, instanceId, {
        studentCode: "RES-99999999",
        direction: "in",
      }),
      404,
      "STUDENT_NOT_FOUND"
    );

    /* mint while the student IS live, then remove them from the roster */
    const minted = await service.mintQr(actor, instanceId, {
      studentCode: S4,
      direction: "in",
      ttlSeconds: 300,
    });
    /* soft-delete exactly S4's residents row (codes live inside dataJson —
     * the established in-memory match, then a row-scoped update) */
    const residents = await db.moduleRecord.findMany({
      where: { instanceId, moduleId: "residents", deletedAt: null },
      select: { id: true, dataJson: true },
    });
    const s4row = residents.find((r) => {
      try {
        return (JSON.parse(r.dataJson) as string[])[0] === S4;
      } catch {
        return false;
      }
    });
    expect(s4row).toBeTruthy();
    await db.moduleRecord.update({
      where: { id: s4row?.id },
      data: { deletedAt: new Date() },
    });
    const s4after = await db.moduleRecord.findUnique({
      where: { id: s4row?.id },
      select: { deletedAt: true },
    });
    expect(s4after?.deletedAt).toBeTruthy();

    /* the token is valid + unexpired, but the student left the roster:
     * the movement is REJECTED and nothing is written */
    await expectHttpError(
      service.redeemQr(instanceId, { token: minted.token }),
      404,
      "STUDENT_NOT_FOUND"
    );
    const movementsForS4 = await db.attendanceMovement.findMany({
      where: { instanceId, studentCode: S4 },
    });
    expect(movementsForS4).toHaveLength(0);
  });
});

/* ------------------------------------------------------------------ */
/* the audit trail                                                     */
/* ------------------------------------------------------------------ */

describe("ROUND 166 — attendance audit trail", () => {
  test("15. AUDIT LOG — policy + movement + allowance mutations are audited", async () => {
    /* fresh mutations of every audited kind */
    await service.updatePolicy(actor, instanceId, {
      dayStartMin: 480,
      dayEndMin: 1080,
      graceMin: 15,
      absenceEvalMin: 1260,
      requireReview: false,
    });
    await service.recordMovement(actor, instanceId, {
      studentCode: S1,
      direction: "out", /* S1 checked in during test 1 → legal */
    });
    const allowance = await service.createAllowance(actor, instanceId, {
      studentCode: S2,
      kind: "excused",
      startsAt: new Date(Date.now() - 60_000).toISOString(),
      endsAt: new Date(Date.now() + 2 * 60 * 60_000).toISOString(),
      note: "اختبار المسار",
    });
    expect(allowance.kind).toBe("excused");
    await service.deleteAllowance(actor, instanceId, allowance.id);

    const kinds = new Set(
      (
        await db.auditLog.findMany({
          where: { actorId: instanceId },
          select: { action: true },
        })
      ).map((r) => r.action)
    );
    expect(kinds.has("instance.attendancePolicy")).toBe(true);
    expect(kinds.has("instance.attendanceMovement")).toBe(true);
    expect(kinds.has("instance.attendanceAllowanceCreate")).toBe(true);
    expect(kinds.has("instance.attendanceAllowanceDelete")).toBe(true);
    const relevant = (
      await db.auditLog.findMany({
        where: {
          actorId: instanceId,
          action: {
            in: [
              "instance.attendancePolicy",
              "instance.attendanceMovement",
              "instance.attendanceAllowanceCreate",
              "instance.attendanceAllowanceDelete",
              "instance.attendanceQrMint",
            ],
          },
        },
        select: { id: true },
      })
    ).length;
    expect(relevant).toBeGreaterThanOrEqual(3);
  });
});

/* ------------------------------------------------------------------ */
/* ROUND 167 (دوام) — the shift schedule (pure engine + service)        */
/* ------------------------------------------------------------------ */

describe("ROUND 167 — دوام shift schedule (the pure engine)", () => {
  /** 2026-10-01 — a fixed local day; every timestamp below lives in it. */
  const day = new Date(2026, 9, 1);
  const at = (h: number, m: number) => new Date(2026, 9, 1, h, m);

  /** morning 08:00–15:00 (grace 10) + evening 15:30–22:00 (grace 15) —
   * the classic صباحي/مسائي pair with DIFFERENT graces so the per-shift
   * math is pinned, not accidental. */
  const TWO_SHIFTS: AttendanceShift[] = [
    { type: "morning", startMin: 480, endMin: 900, graceMin: 10 },
    { type: "evening", startMin: 930, endMin: 1260, graceMin: 15 },
  ];
  const SHIFT_POLICY: AttendancePolicyInput = {
    dayStartMin: 480, /* legacy columns — IGNORED while shifts exist */
    dayEndMin: 1080,
    graceMin: 10,
    absenceEvalMin: 1290,
    requireReview: true,
    shifts: TWO_SHIFTS,
  };

  test("17. ARRIVAL→SHIFT MAP — containment / before-first / gap→following / after-last", () => {
    /* inside the morning window */
    expect(derive.resolveShiftForArrival(TWO_SHIFTS, 8 * 60 + 25)?.type).toBe("morning");
    /* inside the evening window (its own start, not the legacy dayStart) */
    expect(derive.resolveShiftForArrival(TWO_SHIFTS, 16 * 60)?.type).toBe("evening");
    /* before the first shift → the FIRST shift */
    expect(derive.resolveShiftForArrival(TWO_SHIFTS, 7 * 60 + 30)?.type).toBe("morning");
    /* the 15:00–15:30 gap → the nearest FOLLOWING shift (evening) */
    expect(derive.resolveShiftForArrival(TWO_SHIFTS, 15 * 60 + 15)?.type).toBe("evening");
    /* after the last shift's end → the LAST shift */
    expect(derive.resolveShiftForArrival(TWO_SHIFTS, 22 * 60 + 30)?.type).toBe("evening");
    /* unsorted input is tolerated (works on a sorted copy) */
    expect(
      derive.resolveShiftForArrival([...TWO_SHIFTS].reverse(), 9 * 60)?.type
    ).toBe("morning");
    /* empty schedule → null (the caller falls back to the legacy window) */
    expect(derive.resolveShiftForArrival([], 8 * 60 + 25)).toBeNull();
  });

  test("18. PER-SHIFT LATE MATH — each shift's own start + grace decide", () => {
    /* 08:25 in the morning shift (08:00 + grace 10) → late 25 from the
     * shift's START (the standing law: grace decides the verdict only). */
    const morningLate = derive.deriveDayState({
      policy: SHIFT_POLICY,
      studentCode: S1,
      day,
      movements: [{ studentCode: S1, direction: "in", occurredAt: at(8, 25) }],
      allowances: [],
      now: at(23, 0),
    });
    expect(morningLate.state).toBe("late");
    expect(morningLate.lateMinutes).toBe(25);

    /* 15:45 in the evening shift (15:30 + grace 15) → exactly at the
     * grace edge → PRESENT — the evening grace is measured from the
     * evening's own start, never from the morning's. */
    const eveningEdge = derive.deriveDayState({
      policy: SHIFT_POLICY,
      studentCode: S1,
      day,
      movements: [{ studentCode: S1, direction: "in", occurredAt: at(15, 45) }],
      allowances: [],
      now: at(23, 0),
    });
    expect(eveningEdge.state).toBe("present");
    expect(eveningEdge.lateMinutes).toBeNull();

    /* 16:05 in the evening shift → late 35 (965 − 930, from ITS start). */
    const eveningLate = derive.deriveDayState({
      policy: SHIFT_POLICY,
      studentCode: S1,
      day,
      movements: [{ studentCode: S1, direction: "in", occurredAt: at(16, 5) }],
      allowances: [],
      now: at(23, 0),
    });
    expect(eveningLate.state).toBe("late");
    expect(eveningLate.lateMinutes).toBe(35);
  });

  test("19. PARTIAL SHIFT — the window derives like any other; partialHours is metadata", () => {
    /* جزئي 08:00–18:00, 4 expected hours, grace 10. */
    const partial = (partialHours: number): AttendancePolicyInput => ({
      dayStartMin: 480,
      dayEndMin: 1080,
      graceMin: 10,
      absenceEvalMin: 1200,
      requireReview: true,
      shifts: [{ type: "partial", startMin: 480, endMin: 1080, graceMin: 10, partialHours }],
    });

    /* 08:05 → inside the grace window → present */
    expect(
      derive.deriveDayState({
        policy: partial(4),
        studentCode: S1,
        day,
        movements: [{ studentCode: S1, direction: "in", occurredAt: at(8, 5) }],
        allowances: [],
        now: at(23, 0),
      }).state
    ).toBe("present");

    /* 08:35 → late, measured from the shift's START (480): 35 minutes —
     * the same law test 6 pins on the legacy window, so a partial card
     * configured over the same 08:00 start derives IDENTICALLY. */
    const late = derive.deriveDayState({
      policy: partial(4),
      studentCode: S1,
      day,
      movements: [{ studentCode: S1, direction: "in", occurredAt: at(8, 35) }],
      allowances: [],
      now: at(23, 0),
    });
    expect(late.state).toBe("late");
    expect(late.lateMinutes).toBe(35);

    /* THE METADATA LAW — partialHours NEVER touches the derivation: the
     * same arrival derives the same state/lateMinutes under 4h and 8h. */
    const under8 = derive.deriveDayState({
      policy: partial(8),
      studentCode: S1,
      day,
      movements: [{ studentCode: S1, direction: "in", occurredAt: at(8, 35) }],
      allowances: [],
      now: at(23, 0),
    });
    expect(under8.state).toBe(late.state);
    expect(under8.lateMinutes).toBe(late.lateMinutes);
  });

  test("20. MAPPING EXTREMES — early→first, gap→following (present), after-last→last (late)", () => {
    /* 07:30 — before the first shift → judged against the MORNING shift:
     * early ⇒ present. */
    expect(
      derive.deriveDayState({
        policy: SHIFT_POLICY,
        studentCode: S1,
        day,
        movements: [{ studentCode: S1, direction: "in", occurredAt: at(7, 30) }],
        allowances: [],
        now: at(23, 0),
      }).state
    ).toBe("present");

    /* 15:15 — the gap between the shifts → the evening shift's own grace
     * (15:30 + 15) still covers it ⇒ present. */
    expect(
      derive.deriveDayState({
        policy: SHIFT_POLICY,
        studentCode: S1,
        day,
        movements: [{ studentCode: S1, direction: "in", occurredAt: at(15, 15) }],
        allowances: [],
        now: at(23, 0),
      }).state
    ).toBe("present");

    /* 22:30 — after the last shift's end → the LAST (evening) shift:
     * 1350 − 930 = 420 minutes late. */
    const nightOwl = derive.deriveDayState({
      policy: SHIFT_POLICY,
      studentCode: S1,
      day,
      movements: [{ studentCode: S1, direction: "in", occurredAt: at(22, 30) }],
      allowances: [],
      now: at(23, 0),
    });
    expect(nightOwl.state).toBe("late");
    expect(nightOwl.lateMinutes).toBe(420);

    /* an OUT movement still closes the day exactly as the legacy path —
     * the per-day 8-state machine is untouched by the schedule. */
    const outDay = derive.deriveDayState({
      policy: SHIFT_POLICY,
      studentCode: S1,
      day,
      movements: [{ studentCode: S1, direction: "out", occurredAt: at(20, 0) }],
      allowances: [],
      now: at(23, 0),
    });
    expect(outDay.state).toBe("absent");
  });
});

describe("ROUND 167 — دوام policy saves (the real service)", () => {
  /** A valid two-shift PUT body (legacy fields carry junk on purpose —
   * with shifts present the service stamps them from the schedule). */
  const twoShiftPut = {
    dayStartMin: 0,
    dayEndMin: 0,
    graceMin: 0,
    absenceEvalMin: 1290, /* 21:30 — ≥ the effective dayEnd 1260 */
    requireReview: true,
    shifts: [
      { type: "morning" as const, startMin: 480, endMin: 900, graceMin: 10 },
      { type: "evening" as const, startMin: 930, endMin: 1260, graceMin: 15 },
    ],
  };

  test("21. SHIFTS_OVERLAP — intersecting windows are a loud 400; the zod shape is strict", async () => {
    /* [480,930) ∩ [900,1260) = [900,930) — overlap → 400 SHIFTS_OVERLAP */
    await expectHttpError(
      service.updatePolicy(actor, instanceId, {
        ...twoShiftPut,
        shifts: [
          { type: "morning", startMin: 480, endMin: 930, graceMin: 10 },
          { type: "evening", startMin: 900, endMin: 1260, graceMin: 10 },
        ],
      }),
      400,
      "SHIFTS_OVERLAP"
    );

    /* the eval cutoff must respect the EFFECTIVE end (the last shift's
     * end, 1260) — not the caller's legacy dayEndMin. */
    await expectHttpError(
      service.updatePolicy(actor, instanceId, {
        ...twoShiftPut,
        absenceEvalMin: 1200, /* < 1260 */
      }),
      400,
      "POLICY_EVAL_INVALID"
    );

    /* the zod shape: partial WITHOUT partialHours is rejected, a
     * non-partial WITH it is rejected, >3 shifts are rejected, and a
     * start≥end window is rejected — all BEFORE any db write. */
    expect(
      service.policyUpdateSchema.safeParse({
        ...twoShiftPut,
        shifts: [{ type: "partial", startMin: 480, endMin: 1080, graceMin: 10 }],
      }).success
    ).toBe(false);
    expect(
      service.policyUpdateSchema.safeParse({
        ...twoShiftPut,
        shifts: [
          { type: "morning", startMin: 480, endMin: 900, graceMin: 10, partialHours: 4 },
        ],
      }).success
    ).toBe(false);
    expect(
      service.policyUpdateSchema.safeParse({
        ...twoShiftPut,
        shifts: [
          { type: "morning", startMin: 60, endMin: 300, graceMin: 10 },
          { type: "evening", startMin: 360, endMin: 600, graceMin: 10 },
          { type: "partial", startMin: 660, endMin: 900, graceMin: 10, partialHours: 2 },
          { type: "partial", startMin: 960, endMin: 1200, graceMin: 10, partialHours: 2 },
        ],
      }).success
    ).toBe(false);
    expect(
      service.policyUpdateSchema.safeParse({
        ...twoShiftPut,
        shifts: [{ type: "morning", startMin: 900, endMin: 480, graceMin: 10 }],
      }).success
    ).toBe(false);
    /* the happy shapes parse (partial with hours; plain morning) */
    expect(
      service.policyUpdateSchema.safeParse({
        ...twoShiftPut,
        shifts: [
          { type: "partial", startMin: 480, endMin: 1080, graceMin: 10, partialHours: 4 },
        ],
      }).success
    ).toBe(true);
  });

  test("22. STAMPING — a shift save derives the legacy columns + GET parses back; omit keeps, [] clears", async () => {
    /* 1. the overlap-free two-shift PUT — the junk legacy fields in the
     * body are OVERRIDDEN by the stamped first-start/last-end/first-grace. */
    const saved = await service.updatePolicy(actor, instanceId, twoShiftPut);
    expect(saved.shifts).toHaveLength(2);
    /* sorted by startMin on save */
    expect(saved.shifts.map((s) => s.type)).toEqual(["morning", "evening"]);
    expect(saved.shifts[0].startMin).toBe(480);
    expect(saved.shifts[1].endMin).toBe(1260);
    /* the legacy columns carry the stamped schedule for every other reader */
    expect(saved.dayStartMin).toBe(480);
    expect(saved.dayEndMin).toBe(1260);
    expect(saved.graceMin).toBe(10);
    const row = await db.attendancePolicy.findUnique({ where: { instanceId } });
    expect(row?.shiftsJson).toContain('"type":"morning"');
    expect(row?.dayEndMin).toBe(1260);

    /* GET returns the parsed schedule (the read path) */
    const read = await service.getPolicy(instanceId);
    expect(read.shifts).toHaveLength(2);
    expect(read.shifts[1].graceMin).toBe(15);

    /* 2. an update WITHOUT the shifts key KEEPS the stored schedule (the
     * backwards-compat arm — legacy clients never wipe a دوام). */
    const untouched = await service.updatePolicy(actor, instanceId, {
      dayStartMin: 480,
      dayEndMin: 1260,
      graceMin: 10,
      absenceEvalMin: 1300,
      requireReview: false,
    });
    expect(untouched.shifts).toHaveLength(2);
    expect(untouched.absenceEvalMin).toBe(1300);

    /* 3. an EXPLICIT empty array is the deliberate return to the legacy
     * single window — the caller's own columns persist again. */
    const cleared = await service.updatePolicy(actor, instanceId, {
      dayStartMin: 540, /* 09:00 */
      dayEndMin: 1140, /* 19:00 */
      graceMin: 20,
      absenceEvalMin: 1260,
      requireReview: true,
      shifts: [],
    });
    expect(cleared.shifts).toHaveLength(0);
    expect(cleared.dayStartMin).toBe(540);
    expect(cleared.dayEndMin).toBe(1140);
    expect(cleared.graceMin).toBe(20);
    const clearedRow = await db.attendancePolicy.findUnique({ where: { instanceId } });
    expect(clearedRow?.shiftsJson).toBe("[]");

    /* 4. a partial save round-trips partialHours (the precise-coverage
     * contract) and lands in the DTO exactly once. */
    const partialSaved = await service.updatePolicy(actor, instanceId, {
      dayStartMin: 480,
      dayEndMin: 1080,
      graceMin: 10,
      absenceEvalMin: 1200,
      requireReview: true,
      shifts: [
        { type: "partial", startMin: 480, endMin: 1080, graceMin: 10, partialHours: 4 },
      ],
    });
    expect(partialSaved.shifts[0]?.type).toBe("partial");
    expect(partialSaved.shifts[0]?.partialHours).toBe(4);
  });
});
