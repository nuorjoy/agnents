/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — field-level cryptography vault
 * (src/lib/server/crypto-vault.ts).
 *
 * Covers: AES-256-GCM seal/unseal roundtrips (incl. unicode), seal
 * idempotence, TAMPER detection (ciphertext / tag / IV mutations degrade
 * to "" — authenticated encryption), blind-index determinism +
 * case-insensitivity + irreversibility shape, Argon2id password records
 * (+ legacy SHA-256 digest acceptance / detection), and a key-separation
 * smoke check (AES envelope never embeds the blind index of its plaintext).
 *
 * Runs with the DEMO data key (ASHRILOGIC_DATA_KEY unset, dev mode) — the
 * behavior under test is format/algorithm-level, not key-material-level.
 */
import { describe, test, expect, beforeAll } from "bun:test";
import { createHash } from "node:crypto";
import { ensureDemoEnv } from "./test-setup";

type VaultModule = typeof import("@/lib/server/crypto-vault");
let vault: VaultModule;

beforeAll(async () => {
  ensureDemoEnv(); // demo data key active before the module binds its keys
  vault = await import("@/lib/server/crypto-vault");
});

const ARABIC = "مستشفى النور — قسم الطوارئ، الطابق الثالث";
const MIXED = "Sarah O'Neill ♥ <script>alert('xss')</script>\nline-2";

describe("crypto-vault — field sealing roundtrip", () => {
  test("encryptField/decryptField roundtrip (ASCII, Arabic, mixed hostile unicode)", () => {
    for (const plaintext of ["plain@value", ARABIC, MIXED]) {
      const sealed = vault.encryptField(plaintext);
      expect(sealed).not.toBeNull();
      expect(sealed).toMatch(/^enc:v1:[A-Za-z0-9+/=]+:[A-Za-z0-9+/=]+:[A-Za-z0-9+/=]+$/);
      expect(sealed).not.toContain(plaintext);
      expect(vault.decryptField(sealed)).toBe(plaintext);
    }
  });

  test("empty string stays empty; null stays null; undefined stays undefined", () => {
    expect(vault.encryptField("")).toBe("");
    expect(vault.encryptField(null)).toBeNull();
    expect(vault.encryptField(undefined)).toBeUndefined();
    expect(vault.decryptField("")).toBe("");
    expect(vault.decryptField(null)).toBeNull();
    expect(vault.decryptField(undefined)).toBeUndefined();
  });

  test("double encryption is idempotent — already-sealed values pass through", () => {
    const once = vault.encryptField("double-seal-probe");
    expect(once).toBeTruthy();
    const twice = vault.encryptField(once as string);
    expect(twice).toBe(once);
  });

  test("legacy plaintext (no marker) passes through unchanged on decrypt", () => {
    expect(vault.decryptField("legacy@example.com")).toBe("legacy@example.com");
  });
});

describe("crypto-vault — tamper detection (GCM authentication)", () => {
  /** Flip one base64 character at an index ('A'→'B', anything else→'A'). */
  function flipChar(segment: string, index: number): string {
    const chars = segment.split("");
    chars[index] = chars[index] === "A" ? "B" : "A";
    return chars.join("");
  }

  function sealedParts(value: string): { iv: string; tag: string; ct: string } {
    const parts = value.split(":"); // enc, v1, iv, tag, ct
    expect(parts.length).toBe(5);
    return { iv: parts[2], tag: parts[3], ct: parts[4] };
  }

  test("tampered CIPHERTEXT degrades to \"\" (auth failure, no throw)", () => {
    const sealed = vault.encryptField("tamper-me-if-you-can") as string;
    const { iv, tag, ct } = sealedParts(sealed);
    const mid = Math.floor(ct.length / 2);
    const tampered = `enc:v1:${iv}:${tag}:${flipChar(ct, mid)}`;
    expect(vault.decryptField(tampered)).toBe("");
  });

  test("tampered AUTH TAG degrades to \"\"", () => {
    const sealed = vault.encryptField("tamper-me-if-you-can") as string;
    const { iv, tag, ct } = sealedParts(sealed);
    const tampered = `enc:v1:${iv}:${flipChar(tag, 0)}:${ct}`;
    expect(vault.decryptField(tampered)).toBe("");
  });

  test("WRONG IV degrades to \"\"", () => {
    const sealed = vault.encryptField("tamper-me-if-you-can") as string;
    const { iv, tag, ct } = sealedParts(sealed);
    const tampered = `enc:v1:${flipChar(iv, Math.floor(iv.length / 2))}:${tag}:${ct}`;
    expect(vault.decryptField(tampered)).toBe("");
  });

  test("structurally malformed envelopes degrade to \"\"", () => {
    expect(vault.decryptField("enc:v1:onlyone")).toBe("");
    expect(vault.decryptField("enc:v1:a:b:c:d")).toBe("");
    expect(vault.decryptField("enc:v1:!!!:!!!:!!!")).toBe("");
  });

  test("isSealedField distinguishes envelopes from plaintext", () => {
    const sealed = vault.encryptField("which-is-it") as string;
    expect(vault.isSealedField(sealed)).toBe(true);
    expect(vault.isSealedField("plain text")).toBe(false);
    expect(vault.isSealedField("")).toBe(false);
    expect(vault.isSealedField(null)).toBe(false);
    expect(vault.isSealedField(undefined)).toBe(false);
  });
});

describe("crypto-vault — HMAC blind index", () => {
  test("deterministic per value", () => {
    expect(vault.blindIndex("deterministic@x.com")).toBe(vault.blindIndex("deterministic@x.com"));
  });

  test("case-insensitive (\"A@X.com\" === \"a@x.com\")", () => {
    expect(vault.blindIndex("A@X.com")).toBe(vault.blindIndex("a@x.com"));
  });

  test("trims surrounding whitespace", () => {
    expect(vault.blindIndex("  a@x.com\t")).toBe(vault.blindIndex("a@x.com"));
  });

  test("different values produce different indexes", () => {
    expect(vault.blindIndex("one@x.com")).not.toBe(vault.blindIndex("two@x.com"));
  });

  test("irreversibility smoke — the index is 64 lowercase hex, never the value", () => {
    const index = vault.blindIndex("irreversible@example.com") as string;
    expect(index).toMatch(/^[0-9a-f]{64}$/);
    expect(index).not.toContain("@");
    expect(index).not.toContain("irreversible");
  });

  test("empty and null stay empty/null (no index rows for blank input)", () => {
    expect(vault.blindIndex("")).toBe("");
    expect(vault.blindIndex(null)).toBeNull();
    expect(vault.blindIndex(undefined)).toBeUndefined();
  });
});

describe("crypto-vault — password hashing", () => {
  test("Argon2id hash/verify roundtrip; wrong password fails", () => {
    const record = vault.hashPasswordArgon2id("correct horse battery staple");
    expect(vault.verifyPasswordArgon2id("correct horse battery staple", record)).toBe(true);
    expect(vault.verifyPasswordArgon2id("Tr0ub4dor&3", record)).toBe(false);
    expect(vault.verifyPasswordArgon2id("", record)).toBe(false);
  });

  test("PHC record format: $argon2id$v=1$m=19456,t=2,p=1$<salt>$<hash>", () => {
    const record = vault.hashPasswordArgon2id("format-probe");
    expect(record).toMatch(/^\$argon2id\$v=1\$m=19456,t=2,p=1\$[A-Za-z0-9+/=]+\$[A-Za-z0-9+/=]+$/);
    const parts = record.split("$").filter(Boolean);
    expect(parts.length).toBe(5);
    // 128-bit salt → 24 base64 chars; 256-bit hash → 44 base64 chars
    expect(parts[3]).toHaveLength(24);
    expect(parts[4]).toHaveLength(44);
  });

  test("two hashes of the SAME password differ (random salt)", () => {
    expect(vault.hashPasswordArgon2id("same-password")).not.toBe(
      vault.hashPasswordArgon2id("same-password")
    );
  });

  test("legacy unsalted SHA-256 hex digest verifies AND is flagged legacy", () => {
    const legacy = createHash("sha256").update("legacy-pass", "utf8").digest("hex");
    expect(vault.verifyPasswordArgon2id("legacy-pass", legacy)).toBe(true);
    expect(vault.verifyPasswordArgon2id("wrong-pass", legacy)).toBe(false);
    expect(vault.isLegacyPasswordHash(legacy)).toBe(true);
  });

  test("isLegacyPasswordHash is false for Argon2id records (and unset values)", () => {
    const record = vault.hashPasswordArgon2id("modern-pass");
    expect(vault.isLegacyPasswordHash(record)).toBe(false);
    expect(vault.isLegacyPasswordHash(null)).toBe(false);
    expect(vault.isLegacyPasswordHash(undefined)).toBe(false);
    expect(vault.isLegacyPasswordHash("")).toBe(false);
  });

  test("malformed stored records fail closed (never throw, never verify)", () => {
    expect(vault.verifyPasswordArgon2id("x", null)).toBe(false);
    expect(vault.verifyPasswordArgon2id("x", undefined)).toBe(false);
    expect(vault.verifyPasswordArgon2id("x", "")).toBe(false);
    expect(vault.verifyPasswordArgon2id("x", "$argon2id$broken")).toBe(false);
    // 64 chars that are NOT hex → Buffer.from(_, "hex") yields nothing → fail
    expect(vault.verifyPasswordArgon2id("x", "z".repeat(64))).toBe(false);
  });
});

describe("crypto-vault — key separation smoke", () => {
  test("the AES envelope never embeds the blind index of its plaintext (no key reuse)", () => {
    const plaintext = "separation-probe@example.com";
    const sealed = vault.encryptField(plaintext) as string;
    const index = vault.blindIndex(plaintext) as string;
    expect(sealed.includes(index)).toBe(false);
    expect(sealed.includes(plaintext)).toBe(false);
    // and the index never leaks the envelope either
    expect(index.includes(sealed)).toBe(false);
  });
});
