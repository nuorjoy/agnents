/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 187: the instance MFA finish step binds the
 * ticket to the workspace's CURRENT owner email blind index.
 *
 * issueInstanceMfaTicket mints `sub = instanceId|emailIndex` (the email
 * whose PASSWORD was verified). The finish step previously re-checked
 * only instanceId + sessionVersion — an email rotation inside the 5-minute
 * ticket TTL does NOT bump sessionVersion (only password changes do), so
 * a ticket issued for the PREVIOUS owner email still finished sign-in.
 *
 * The fix adds the binding comparison (row.adminEmailIndex !==
 * payload.emailIndex → uniform 401). This suite pins:
 *   1. the helper round-trip (issue → verify carries the exact index);
 *   2. the route refuses a mismatched-email ticket with the SAME uniform
 *      401 envelope as an expired ticket (no oracle, no sign-in);
 *   3. a MATCHED-email ticket with a wrong code reaches the code check
 *      (distinct 401 message) — proving the binding check does not
 *      over-block the legitimate flow.
 */
import { describe, beforeAll, afterAll, test, expect } from "bun:test";
import { getTestDb, ensureDemoEnv, type TestDb } from "./test-setup";

ensureDemoEnv();

const RUN = `mfa-bind-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

let db: TestDb;
let instanceSession: typeof import("@/lib/server/instance-session");
let cryptoVault: typeof import("@/lib/server/crypto-vault");
let route: typeof import("@/app/api/instances/auth/login/mfa/route");
const createdIds: string[] = [];

function mfaRequest(ticket: string, code: string): Request {
  return new Request("http://localhost:3000/api/instances/auth/login/mfa", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      host: "localhost:3000",
      origin: "http://localhost:3000",
    },
    body: JSON.stringify({ ticket, code }),
  });
}

beforeAll(async () => {
  db = await getTestDb();
  instanceSession = await import("@/lib/server/instance-session");
  cryptoVault = await import("@/lib/server/crypto-vault");
  route = await import("@/app/api/instances/auth/login/mfa/route");
});

afterAll(async () => {
  if (createdIds.length > 0) {
    await db.instance.deleteMany({ where: { id: { in: createdIds } } });
  }
});

describe("ROUND 187 — instance MFA ticket / owner-email binding", () => {
  test("helper round-trip — the ticket carries the exact email blind index", () => {
    const oldIndex = cryptoVault.blindIndex(`old-${RUN}@mfa.test`) ?? "";
    const ticket = instanceSession.issueInstanceMfaTicket("instance-x", 7, oldIndex);
    const payload = instanceSession.verifyInstanceMfaTicket(ticket);
    expect(payload).not.toBeNull();
    if (payload) {
      expect(payload.instanceId).toBe("instance-x");
      expect(payload.emailIndex).toBe(oldIndex);
      expect(payload.ver).toBe(7);
    }
  });

  test("route — mismatched-email ticket is refused with the uniform expired envelope", async () => {
    const rowIndex = cryptoVault.blindIndex(`new-${RUN}@mfa.test`) ?? "";
    const ticketIndex = cryptoVault.blindIndex(`old-${RUN}@mfa.test`) ?? "";
    const row = await db.instance.create({
      data: {
        systemId: "clinic-management",
        orgJson: JSON.stringify({ name: `MfaBind-${RUN}`, currency: "SAR" }),
        adminJson: JSON.stringify({ name: `Admin-${RUN}` }),
        adminEmailIndex: rowIndex,
        prefsJson: JSON.stringify({ lang: "ar" }),
        modulesJson: JSON.stringify(["patients"]),
        sessionVersion: 3,
      },
      select: { id: true },
    });
    createdIds.push(row.id);
    /* the ticket was minted for the PREVIOUS email, at the SAME epoch —
       pre-ROUND-187 this finished sign-in for the rotated workspace */
    const ticket = instanceSession.issueInstanceMfaTicket(row.id, 3, ticketIndex);

    const res = await route.POST(mfaRequest(ticket, "123456"));
    expect(res.status).toBe(401);
    expect(await res.json()).toEqual({ error: "Verification session expired — sign in again" });
  });

  test("route — matched-email ticket with a wrong code reaches the CODE check (no over-blocking)", async () => {
    const rowIndex = cryptoVault.blindIndex(`new-${RUN}@mfa.test`) ?? "";
    const row = await db.instance.findFirst({
      where: { adminEmailIndex: rowIndex },
      select: { id: true, sessionVersion: true },
    });
    expect(row).not.toBeNull();
    if (!row) return;
    const ticket = instanceSession.issueInstanceMfaTicket(
      row.id,
      row.sessionVersion ?? 0,
      rowIndex
    );

    const res = await route.POST(mfaRequest(ticket, "000000"));
    /* the binding check PASSED (the request reached verifyMfaLogin); the
       code is simply wrong → the distinct second-factor 401 */
    expect(res.status).toBe(401);
    expect(await res.json()).toEqual({ error: "Incorrect verification code" });
  });
});
