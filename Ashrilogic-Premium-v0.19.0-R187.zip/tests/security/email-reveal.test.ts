/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 166: استعادة البريد المختوم — the one-time
 * sealed-email reveal lever (src/lib/server/email-reveal.ts + the
 * EmailRevealToken table + POST/PUT /api/admin/email-reveal).
 *
 * THE DESIGN THIS PINS SHUT: the seal itself is never weakened — a reveal
 * is a privileged, audited, SINGLE-USE event. The service runs against the
 * throwaway database with NO server, NO HTTP (the campaign-dispatch /
 * attendance pattern):
 *
 *   1. MINT (super)        — raw 32-byte token returned once; only its
 *                            sha256 is stored; TTL 15 minutes; audit row.
 *   2. CONSUME ONCE        — the email returned matches the sealed
 *                            original (decryptField of the stored
 *                            envelope); token row stamped usedAt/usedByName.
 *   3. CONSUME AGAIN       — 410 REVEAL_REUSED (the CAS single-use claim).
 *   4. EXPIRED TOKEN       — expiresAt pushed past → 410 REVEAL_EXPIRED.
 *   5. NON-SUPER ACTOR     — moderator mint + consume → 403.
 *   6. MISSING REASON      — 400 REASON_REQUIRED (+ the zod schema rejects).
 *   7. AUDIT MASKING       — mint + consume rows exist; the plaintext
 *                            email appears in NEITHER metaJson NOR
 *                            targetLabel (the consume label is maskEmail).
 *   8. NO PLAINTEXT AT REST— the token row (and its JSON form) never
 *                            contains the email.
 *   9. UNKNOWN TOKEN       — 404 REVEAL_NOT_FOUND.
 *  10. DEAD TARGET         — mint for a nonexistent row → 404
 *                            TARGET_NOT_FOUND (dead tokens never minted).
 *  11. THE 5 RESOLVERS      — subscriber / admin / siteCustomer /
 *                            ticketRequester / quote each reveal the
 *                            right sealed column; the optional instanceId
 *                            scopes the tenant families (a wrong scope
 *                            404s). The quote family is platform-level
 *                            (ROUND 167 — instanceId deliberately
 *                            ignored, like subscriber/admin).
 *  12. SECURITY TRAIL      — the audit rows are written even with the
 *                            business auditLog toggle OFF (the PII lever
 *                            rides the unconditional security trail).
 */
import { describe, test, expect, beforeAll, afterAll } from "bun:test";
import { createHash } from "node:crypto";
import { ensureDemoEnv, getTestDb, type TestDb } from "./test-setup";

/* Bind the throwaway DB BEFORE any db-binding module imports (the
 * isolation-canary contract from test-setup). */
ensureDemoEnv();

let db: TestDb;
let service: typeof import("@/lib/server/email-reveal");
let vault: typeof import("@/lib/server/crypto-vault");
let audit: typeof import("@/lib/server/audit");
let HttpError: typeof import("@/lib/server/route").HttpError;
type RevealActor = import("@/lib/server/email-reveal").RevealActor;

const RUN = Math.random().toString(36).slice(2, 8);

/** sha256 hex — the token row's only stored form of the raw token. */
function sha256Hex(value: string): string {
  return createHash("sha256").update(value, "utf8").digest("hex");
}

/* the sealed fixtures + the acting admins */
let instanceId = "";
let superActor: RevealActor;
let moderatorActor: RevealActor;
let moderatorRowId = "";

const SUB_EMAIL = `reveal-sub-${RUN}@example.com`;
const ADMIN_EMAIL = `reveal-admin-${RUN}@example.com`;
const CUSTOMER_EMAIL = `reveal-cust-${RUN}@example.com`;
const TICKET_EMAIL = `reveal-ticket-${RUN}@example.com`;
const QUOTE_EMAIL = `reveal-quote-${RUN}@example.com`;

let subscriberId = "";
let customerId = "";
let ticketId = "";
let quoteRowId = "";

async function expectHttpError(
  promise: Promise<unknown>,
  status: number,
  code: string
): Promise<import("@/lib/server/route").HttpError> {
  let caught: unknown;
  try {
    await promise;
  } catch (e) {
    caught = e;
  }
  expect(caught).toBeInstanceOf(HttpError);
  const err = caught as InstanceType<typeof HttpError>;
  expect(err.status).toBe(status);
  expect(err.code).toBe(code);
  return err;
}

beforeAll(async () => {
  db = await getTestDb();
  service = await import("@/lib/server/email-reveal");
  vault = await import("@/lib/server/crypto-vault");
  audit = await import("@/lib/server/audit");
  ({ HttpError } = await import("@/lib/server/route"));

  /* ROUND 166 fixture — the business audit toggle is OFF for the whole
   * process: the reveal rows must still write (test 12, the security
   * trail). Created BEFORE any logAudit call so the first settings
   * refresh observes it. */
  await db.platformSetting.create({
    data: { id: "global", auditLog: false },
  });

  /* the acting admins (rows exist so the trail's actor ids resolve) */
  const superRow = await db.adminUser.create({
    data: {
      username: `reveal-super-${RUN}`,
      name: `reveal-super-${RUN}`,
      email: vault.encryptField(`super-${RUN}@example.com`) ?? "",
      role: "super",
    },
    select: { id: true, username: true, name: true, role: true },
  });
  superActor = { ...superRow, role: "super" } satisfies RevealActor;

  const moderatorRow = await db.adminUser.create({
    data: {
      username: `reveal-mod-${RUN}`,
      name: `reveal-mod-${RUN}`,
      email: vault.encryptField(ADMIN_EMAIL) ?? "",
      role: "moderator",
    },
    select: { id: true, username: true, name: true, role: true },
  });
  moderatorActor = { ...moderatorRow, role: "moderator" } satisfies RevealActor;
  moderatorRowId = moderatorRow.id;

  /* the sealed subscriber (target type #1) */
  const subscriber = await db.subscriber.create({
    data: {
      email: vault.encryptField(SUB_EMAIL) ?? "",
      emailIndex: vault.blindIndex(SUB_EMAIL) ?? "",
    },
    select: { id: true },
  });
  subscriberId = subscriber.id;

  /* a tenant workspace + its sealed site customer (#3) + ticket (#4) */
  const instance = await db.instance.create({
    data: {
      systemId: "restaurant-pos",
      orgJson: JSON.stringify({ name: `استعادة ${RUN}`, country: "SA", currency: "SAR" }),
      adminJson: JSON.stringify({ name: "مالك", email: `owner-${RUN}@example.com`, role: "owner" }),
      prefsJson: JSON.stringify({ lang: "ar", theme: "light", notif: true, backup: true, audit: true, demo: false }),
      modulesJson: JSON.stringify(["menu"]),
    },
    select: { id: true },
  });
  instanceId = instance.id;

  const customer = await db.siteCustomer.create({
    data: {
      instanceId,
      name: `عميل الاستعادة ${RUN}`,
      email: vault.encryptField(CUSTOMER_EMAIL) ?? "",
      emailIndex: vault.blindIndex(CUSTOMER_EMAIL) ?? "",
    },
    select: { id: true },
  });
  customerId = customer.id;

  const ticket = await db.supportTicket.create({
    data: {
      subject: `استعادة ${RUN}`,
      message: "sealed requester recovery probe",
      requesterName: `مرسل ${RUN}`,
      requesterEmail: vault.encryptField(TICKET_EMAIL) ?? "",
      requesterEmailIndex: vault.blindIndex(TICKET_EMAIL) ?? "",
      instanceId,
      source: "instance",
    },
    select: { id: true },
  });
  ticketId = ticket.id;

  /* ROUND 167 — a sealed Enterprise quote lead (target type #5): the
   * platform-level row the quotes inbox masks by default. */
  const quote = await db.enterpriseQuote.create({
    data: {
      name: `عميل مؤسسات ${RUN}`,
      email: vault.encryptField(QUOTE_EMAIL) ?? "",
      emailIndex: vault.blindIndex(QUOTE_EMAIL) ?? "",
      company: `مؤسسة ${RUN}`,
      teamSize: "11-50",
      systemsCount: 12,
      notes: "sealed quote recovery probe",
    },
    select: { id: true },
  });
  quoteRowId = quote.id;
});

afterAll(async () => {
  if (!db) return;
  await db.emailRevealToken.deleteMany({
    where: { createdById: { in: [superActor.id, moderatorActor.id] } },
  }).catch(() => undefined);
  await db.auditLog.deleteMany({
    where: { actorId: { in: [superActor.id, moderatorActor.id] } },
  }).catch(() => undefined);
  await db.supportTicket.deleteMany({ where: { instanceId } }).catch(() => undefined);
  await db.siteCustomer.deleteMany({ where: { instanceId } }).catch(() => undefined);
  await db.instance.deleteMany({ where: { id: instanceId } }).catch(() => undefined);
  await db.subscriber.deleteMany({ where: { id: subscriberId } }).catch(() => undefined);
  await db.enterpriseQuote.deleteMany({ where: { id: quoteRowId } }).catch(() => undefined);
  await db.adminUser.deleteMany({
    where: { id: { in: [superActor.id, moderatorActor.id] } },
  }).catch(() => undefined);
  await db.platformSetting.deleteMany({ where: { id: "global" } }).catch(() => undefined);
});

/* ------------------------------------------------------------------ */
/* the single-use lifecycle (service, real database)                   */
/* ------------------------------------------------------------------ */

describe("ROUND 166 — the one-time sealed-email reveal lifecycle", () => {
  let rawToken = "";
  let tokenRowId = "";

  test("1. MINT (super) — raw token once, only sha256 stored, 15-minute TTL, audit row", async () => {
    const minted = await service.mintRevealToken(superActor, {
      targetType: "subscriber",
      targetId: subscriberId,
      reason: "اختبار الاستعادة — طلب المالك",
    });

    /* the RAW token is returned exactly once (43-char base64url) */
    expect(typeof minted.token).toBe("string");
    expect(minted.token.length).toBeGreaterThanOrEqual(40);
    expect(minted.targetType).toBe("subscriber");
    expect(minted.targetId).toBe(subscriberId);

    /* the stored row carries ONLY the sha256 of the raw token */
    const row = await db.emailRevealToken.findUnique({
      where: { tokenHash: sha256Hex(minted.token) },
    });
    expect(row).toBeTruthy();
    expect(row?.tokenHash).not.toBe(minted.token);
    expect(row?.tokenHash).toMatch(/^[0-9a-f]{64}$/);
    expect(row?.reason).toBe("اختبار الاستعادة — طلب المالك");
    expect(row?.usedAt).toBeNull();
    expect(row?.createdById).toBe(superActor.id);
    /* TTL = 15 minutes (±30s clock slack) */
    const ttlMs = minted.expiresAt.length > 0
      ? Date.parse(minted.expiresAt) - Date.now()
      : 0;
    expect(ttlMs).toBeGreaterThan(14.5 * 60 * 1000);
    expect(ttlMs).toBeLessThanOrEqual(15 * 60 * 1000 + 30_000);

    rawToken = minted.token;
    tokenRowId = row?.id ?? "";
  });

  test("2. CONSUME ONCE — the email matches the sealed original; the row is stamped", async () => {
    const result = await service.consumeRevealToken(superActor, { token: rawToken });

    /* the revealed address is EXACTLY the sealed original */
    expect(result.email).toBe(SUB_EMAIL);
    expect(result.targetType).toBe("subscriber");
    expect(result.targetId).toBe(subscriberId);
    expect(result.mintedBy).toBe(superActor.name);
    expect(result.reason).toBe("اختبار الاستعادة — طلب المالك");
    expect(Date.parse(result.revealedAt)).toBeGreaterThan(Date.now() - 60_000);

    /* the token row records the claim — but NEVER the email (test 8) */
    const row = await db.emailRevealToken.findUnique({ where: { id: tokenRowId } });
    expect(row?.usedAt).toBeTruthy();
    expect(row?.usedByName).toBe(superActor.name);
    expect(JSON.stringify(row)).not.toContain(SUB_EMAIL);
  });

  test("3. CONSUME AGAIN — 410 REVEAL_REUSED (the CAS single-use claim)", async () => {
    await expectHttpError(
      service.consumeRevealToken(superActor, { token: rawToken }),
      410,
      "REVEAL_REUSED"
    );
  });

  test("4. EXPIRED TOKEN — expiresAt pushed past → 410 REVEAL_EXPIRED", async () => {
    const minted = await service.mintRevealToken(superActor, {
      targetType: "subscriber",
      targetId: subscriberId,
      reason: "expired probe",
    });
    await db.emailRevealToken.update({
      where: { tokenHash: sha256Hex(minted.token) },
      data: { expiresAt: new Date(Date.now() - 1000) },
    });
    await expectHttpError(
      service.consumeRevealToken(superActor, { token: minted.token }),
      410,
      "REVEAL_EXPIRED"
    );
  });

  test("5. NON-SUPER ACTOR — moderator mint + consume → 403", async () => {
    await expectHttpError(
      service.mintRevealToken(moderatorActor, {
        targetType: "subscriber",
        targetId: subscriberId,
        reason: "moderator attempt",
      }),
      403,
      "ADMIN_FORBIDDEN_ROLE"
    );
    await expectHttpError(
      service.consumeRevealToken(moderatorActor, { token: "x".repeat(43) }),
      403,
      "ADMIN_FORBIDDEN_ROLE"
    );
    /* nothing was minted by the moderator */
    const rows = await db.emailRevealToken.findMany({
      where: { createdById: moderatorActor.id },
    });
    expect(rows.length).toBe(0);
  });

  test("6. MISSING REASON — 400 REASON_REQUIRED (service law + zod schema)", async () => {
    await expectHttpError(
      service.mintRevealToken(superActor, {
        targetType: "subscriber",
        targetId: subscriberId,
        reason: "   ",
      }),
      400,
      "REASON_REQUIRED"
    );
    /* the route-boundary schema rejects it too */
    const parsed = service.revealMintSchema.safeParse({
      targetType: "subscriber",
      targetId: subscriberId,
      reason: "",
    });
    expect(parsed.success).toBe(false);
    /* unknown target family + over-long reason are rejected as well */
    expect(
      service.revealMintSchema.safeParse({
        targetType: "instance",
        targetId: "x",
        reason: "y",
      }).success
    ).toBe(false);
    expect(
      service.revealMintSchema.safeParse({
        targetType: "subscriber",
        targetId: subscriberId,
        reason: "x".repeat(201),
      }).success
    ).toBe(false);
  });

  test("7. AUDIT MASKING — mint + consume rows exist; the plaintext appears NOWHERE", async () => {
    const minted = await service.mintRevealToken(superActor, {
      targetType: "siteCustomer",
      targetId: customerId,
      instanceId,
      reason: "audit-masking probe",
    });
    const consumed = await service.consumeRevealToken(superActor, { token: minted.token });
    expect(consumed.email).toBe(CUSTOMER_EMAIL);

    const rows = await db.auditLog.findMany({
      where: { actorId: superActor.id, action: { in: ["admin.email-reveal-mint", "admin.email-reveal-consume"] } },
      orderBy: { createdAt: "asc" },
    });
    /* this scenario's pair (siteCustomer mint + consume) */
    const mintRows = rows.filter(
      (r) => r.action === "admin.email-reveal-mint" && r.targetLabel?.startsWith("siteCustomer")
    );
    const consumeRows = rows.filter(
      (r) => r.action === "admin.email-reveal-consume" && r.metaJson?.includes(`"targetId":"${customerId}"`)
    );
    expect(mintRows.length).toBeGreaterThanOrEqual(1);
    expect(consumeRows.length).toBe(1);

    for (const row of [...mintRows, ...consumeRows]) {
      /* the plaintext email NEVER reaches the trail (meta or label) */
      expect(row.metaJson ?? "").not.toContain(CUSTOMER_EMAIL);
      expect(row.targetLabel ?? "").not.toContain(CUSTOMER_EMAIL);
    }
    /* the consume label is exactly the MASK (maskEmail's first-char form) */
    const consumeRow = consumeRows[0];
    expect(consumeRow?.targetLabel).toBe(audit.maskEmail(CUSTOMER_EMAIL));
    expect(consumeRow?.targetLabel).not.toBe(CUSTOMER_EMAIL);
    /* the mint meta carries the mandatory justification + tenant linkage */
    const mintRow = mintRows[0];
    expect(mintRow?.metaJson).toContain("audit-masking probe");
    expect(mintRow?.metaJson).toContain(`"instance":"${instanceId}"`);
    expect(consumeRow?.metaJson).toContain(`"mintedBy":"${superActor.name}"`);
  });

  test("8. NO PLAINTEXT AT REST — the token row (all fields) never stores the email", async () => {
    const minted = await service.mintRevealToken(superActor, {
      targetType: "ticketRequester",
      targetId: ticketId,
      instanceId,
      reason: "at-rest probe",
    });
    const result = await service.consumeRevealToken(superActor, { token: minted.token });
    expect(result.email).toBe(TICKET_EMAIL);

    const row = await db.emailRevealToken.findUnique({
      where: { tokenHash: sha256Hex(minted.token) },
    });
    expect(row).toBeTruthy();
    expect(JSON.stringify(row)).not.toContain(TICKET_EMAIL);
    /* every individual text field is email-free */
    for (const value of [
      row?.id,
      row?.createdById,
      row?.createdByName,
      row?.targetType,
      row?.targetId,
      row?.instanceId,
      row?.tokenHash,
      row?.reason,
      row?.usedByName,
    ]) {
      expect(String(value ?? "")).not.toContain(TICKET_EMAIL);
    }
  });

  test("9. UNKNOWN TOKEN — 404 REVEAL_NOT_FOUND", async () => {
    await expectHttpError(
      service.consumeRevealToken(superActor, { token: `unknown-${RUN}-${"a".repeat(24)}` }),
      404,
      "REVEAL_NOT_FOUND"
    );
  });

  test("10. DEAD TARGET — mint for a nonexistent row → 404 TARGET_NOT_FOUND", async () => {
    await expectHttpError(
      service.mintRevealToken(superActor, {
        targetType: "subscriber",
        targetId: "clunknown0000000000000000",
        reason: "dead target probe",
      }),
      404,
      "TARGET_NOT_FOUND"
    );
  });
});

/* ------------------------------------------------------------------ */
/* the five target resolvers                                           */
/* ------------------------------------------------------------------ */

describe("ROUND 166/167 — the five sealed-mailbox resolvers", () => {
  test("11. subscriber / admin / siteCustomer / ticketRequester each reveal the right column; instanceId scopes the tenant families", async () => {
    /* subscriber */
    const sub = await service.mintRevealToken(superActor, {
      targetType: "subscriber",
      targetId: subscriberId,
      reason: "resolver: subscriber",
    });
    expect((await service.consumeRevealToken(superActor, { token: sub.token })).email).toBe(SUB_EMAIL);

    /* admin — the moderator's own sealed column (a platform row) */
    const adminReveal = await service.mintRevealToken(superActor, {
      targetType: "admin",
      targetId: moderatorRowId,
      reason: "resolver: admin",
    });
    expect((await service.consumeRevealToken(superActor, { token: adminReveal.token })).email).toBe(ADMIN_EMAIL);

    /* siteCustomer — scoped by instanceId */
    const customer = await service.mintRevealToken(superActor, {
      targetType: "siteCustomer",
      targetId: customerId,
      instanceId,
      reason: "resolver: siteCustomer",
    });
    expect((await service.consumeRevealToken(superActor, { token: customer.token })).email).toBe(CUSTOMER_EMAIL);

    /* ticketRequester — scoped by instanceId */
    const ticket = await service.mintRevealToken(superActor, {
      targetType: "ticketRequester",
      targetId: ticketId,
      instanceId,
      reason: "resolver: ticketRequester",
    });
    expect((await service.consumeRevealToken(superActor, { token: ticket.token })).email).toBe(TICKET_EMAIL);

    /* WRONG tenant scope on a tenant family → the row does not resolve */
    await expectHttpError(
      service.mintRevealToken(superActor, {
        targetType: "siteCustomer",
        targetId: customerId,
        instanceId: "clwrongtenant00000000000000",
        reason: "resolver: wrong scope",
      }),
      404,
      "TARGET_NOT_FOUND"
    );
  });

  /* ROUND 167 — the FIFTH family: an Enterprise quote lead's sealed
   * address. The quote pipeline is platform-level, so the resolver
   * ignores the optional instanceId (the subscriber/admin law) — a
   * stale/wrong scope must NOT hide the row. */
  test("11b. quote — resolves the EnterpriseQuote envelope by id alone (instanceId ignored)", async () => {
    const minted = await service.mintRevealToken(superActor, {
      targetType: "quote",
      targetId: quoteRowId,
      reason: "resolver: enterprise quote lead",
    });
    expect(minted.targetType).toBe("quote");
    const consumed = await service.consumeRevealToken(superActor, { token: minted.token });
    expect(consumed.email).toBe(QUOTE_EMAIL);
    expect(consumed.targetType).toBe("quote");
    expect(consumed.targetId).toBe(quoteRowId);

    /* the platform-level law: a WRONG instanceId still resolves (ignored),
     * and a dead quote id never mints */
    const scoped = await service.mintRevealToken(superActor, {
      targetType: "quote",
      targetId: quoteRowId,
      instanceId: "clwrongtenant00000000000000",
      reason: "resolver: quote ignores scope",
    });
    expect((await service.consumeRevealToken(superActor, { token: scoped.token })).email).toBe(QUOTE_EMAIL);
    await expectHttpError(
      service.mintRevealToken(superActor, {
        targetType: "quote",
        targetId: "clunknownquote0000000000000",
        reason: "resolver: dead quote",
      }),
      404,
      "TARGET_NOT_FOUND"
    );
  });
});

/* ------------------------------------------------------------------ */
/* the security trail (unconditional despite the business toggle)      */
/* ------------------------------------------------------------------ */

describe("ROUND 166 — the reveal rides the SECURITY trail", () => {
  test("12. audit rows are written with the business auditLog toggle OFF", async () => {
    /* the fixture set platformSetting.auditLog = false BEFORE any audit
     * write (see beforeAll) — business rows would be skipped; the reveal
     * rows must still exist (SECURITY_ACTIONS, unconditional trail). */
    const setting = await db.platformSetting.findUnique({ where: { id: "global" } });
    expect(setting?.auditLog).toBe(false);

    const minted = await service.mintRevealToken(superActor, {
      targetType: "subscriber",
      targetId: subscriberId,
      reason: "security-trail probe",
    });
    await service.consumeRevealToken(superActor, { token: minted.token });

    const rows = await db.auditLog.findMany({
      where: { actorId: superActor.id, action: "admin.email-reveal-consume" },
    });
    const fresh = rows.filter((r) => r.metaJson?.includes("security-trail probe"));
    expect(fresh.length).toBe(1);
  });
});
