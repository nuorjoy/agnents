/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — same-origin guard for mutating requests
 * (src/lib/server/origin-guard.ts).
 *
 * Task-2 fix under test: a mutating request that carries a SESSION COOKIE
 * but NEITHER Origin NOR Referer used to pass — an ambient-credential
 * mutation with no declared origin. It must now 403. Cookieless curl-style
 * requests keep working (nothing to CSRF).
 *
 * Pure unit tests — Requests are constructed locally.
 */
import { describe, test, expect } from "bun:test";
import { originViolation, isMutatingMethod } from "@/lib/server/origin-guard";

const HOST = "localhost:3000";

function req(method: string, headers: Record<string, string>): Request {
  return new Request(`http://${HOST}/api/probe`, { method, headers });
}

describe("origin-guard — mutating methods", () => {
  test("isMutatingMethod: POST/PUT/PATCH/DELETE mutate; GET/HEAD/OPTIONS do not", () => {
    for (const method of ["POST", "PUT", "PATCH", "DELETE"]) {
      expect(isMutatingMethod(method)).toBe(true);
    }
    for (const method of ["GET", "HEAD", "OPTIONS"]) {
      expect(isMutatingMethod(method)).toBe(false);
    }
  });
});

describe("origin-guard — Origin header paths", () => {
  test("POST with Origin matching the served host → passes (null)", () => {
    expect(originViolation(req("POST", { host: HOST, origin: `http://${HOST}` }))).toBeNull();
  });

  test("POST with Origin on a DIFFERENT host → 403", () => {
    const violation = originViolation(
      req("POST", { host: HOST, origin: "http://evil.example" })
    );
    expect(violation).not.toBeNull();
    expect(violation instanceof Response).toBe(true);
    expect(violation?.status).toBe(403);
  });

  test("POST with Origin \"null\" (sandboxed iframe / stripped) → 403", () => {
    const violation = originViolation(req("POST", { host: HOST, origin: "null" }));
    expect(violation?.status).toBe(403);
  });
});

describe("origin-guard — Referer fallback paths", () => {
  test("no Origin, Referer matching → passes (null)", () => {
    expect(
      originViolation(req("POST", { host: HOST, referer: `http://${HOST}/dashboard` }))
    ).toBeNull();
  });

  test("no Origin, Referer MISMATCHED → 403", () => {
    const violation = originViolation(
      req("POST", { host: HOST, referer: "http://evil.example/attack" })
    );
    expect(violation?.status).toBe(403);
  });
});

describe("origin-guard — NEITHER Origin nor Referer (the Task-2 fix)", () => {
  test("no Origin, no Referer, NO cookie → passes (curl / server-to-server path)", () => {
    expect(originViolation(req("POST", { "content-type": "application/json" }))).toBeNull();
  });

  test("no Origin, no Referer, session cookie present → 403 (strict for ambient credentials)", () => {
    const violation = originViolation(
      req("POST", { cookie: "ashrilogic-admin-session=abc" })
    );
    expect(violation?.status).toBe(403);
  });

  test("same for the workspace and customer session cookies", () => {
    for (const cookie of [
      "ashrilogic-instance-session=xyz",
      "ashrilogic-store-session=xyz",
    ]) {
      expect(originViolation(req("POST", { cookie }))?.status).toBe(403);
    }
  });

  test("no Origin, no Referer, UNRELATED cookie only → passes", () => {
    expect(originViolation(req("POST", { cookie: "foo=bar" }))).toBeNull();
  });
});

describe("origin-guard — read-only exemption + strict opt-in", () => {
  test("GET with a CROSS-ORIGIN Origin → passes (read-only requests are exempt)", () => {
    expect(
      originViolation(req("GET", { host: HOST, origin: "http://evil.example" }))
    ).toBeNull();
  });

  test("opts.requireOrigin: true with no headers → 403 even without a cookie", () => {
    const violation = originViolation(req("POST", {}), { requireOrigin: true });
    expect(violation?.status).toBe(403);
  });
});

describe("origin-guard — ROUND 43 reverse-proxy correctness", () => {
  test("Origin matching a trusted X-Forwarded-Host hop → passes (preview/re-hosting proxy)", () => {
    expect(
      originViolation(
        req("POST", {
          host: HOST,
          "x-forwarded-host": "app.preview.example",
          origin: "https://app.preview.example",
        })
      )
    ).toBeNull();
  });

  test("Origin matching ANY hop of a multi-hop X-Forwarded-Host chain → passes", () => {
    expect(
      originViolation(
        req("POST", {
          host: HOST,
          "x-forwarded-host": "outer.preview.example, inner.preview.example",
          origin: "https://inner.preview.example",
        })
      )
    ).toBeNull();
  });

  test("Referer matching a trusted X-Forwarded-Host hop → passes", () => {
    expect(
      originViolation(
        req("POST", {
          host: HOST,
          "x-forwarded-host": "app.preview.example",
          referer: "https://app.preview.example/login",
        })
      )
    ).toBeNull();
  });

  test("Origin mismatch + Sec-Fetch-Site: same-origin (browser-certified) → passes", () => {
    expect(
      originViolation(
        req("POST", {
          host: HOST,
          origin: "https://app.preview.example",
          "sec-fetch-site": "same-origin",
        })
      )
    ).toBeNull();
  });

  test("Origin mismatch + Sec-Fetch-Site: cross-site → still 403 (real CSRF attempt)", () => {
    const violation = originViolation(
      req("POST", {
        host: HOST,
        origin: "https://evil.example",
        "sec-fetch-site": "cross-site",
      })
    );
    expect(violation?.status).toBe(403);
  });

  test("Origin mismatch + Sec-Fetch-Site: same-site → still 403 (subdomain attack)", () => {
    const violation = originViolation(
      req("POST", {
        host: HOST,
        origin: "https://evil.example",
        "sec-fetch-site": "same-site",
      })
    );
    expect(violation?.status).toBe(403);
  });

  test("Origin mismatch + NO Sec-Fetch-Site → still 403 (pure host-mismatch path)", () => {
    // A browser page can never contribute a custom X-Forwarded-Host to a
    // cross-site request (CORS preflight wall) — the plain mismatch case
    // must therefore stay rejected when no browser certification exists.
    expect(
      originViolation(req("POST", { host: HOST, origin: "https://evil.example" }))?.status
    ).toBe(403);
  });

  test("Origin mismatch + Sec-Fetch-Site: none → still 403 (opaque/sandboxed context)", () => {
    const violation = originViolation(
      req("POST", {
        host: HOST,
        origin: "null",
        "sec-fetch-site": "none",
      })
    );
    expect(violation?.status).toBe(403);
  });

  test("host comparison is case-insensitive", () => {
    expect(
      originViolation(
        req("POST", { host: "App.Preview.Example", origin: "https://app.preview.example" })
      )
    ).toBeNull();
  });
});
