/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — AUDIT-CHAIN ANCHORED PRUNING (ROUND 96).
 *
 * Proves the retention sweep can now prune CHAINED audit rows beyond the
 * retention window WITHOUT breaking tamper-evidence:
 *  - the anchor (hash of the LAST pruned row) resolves the oldest retained
 *    row's backlink — no orphan, chain healthy;
 *  - removing the anchor row itself (or anything below it) is DETECTED as
 *    an anchor mismatch;
 *  - a pruned chain verified WITHOUT the anchor reports the orphan (the
 *    pre-ROUND-96 behavior — the anchor is what makes pruning safe);
 *  - the real DB flow works end to end: seed old chained rows beyond the
 *    window + fresh rows, one logAudit trigger, sweep prunes + anchors,
 *    verification stays healthy.
 */
import { beforeAll, describe, expect, test } from "bun:test";
import { getTestDb, type TestDb } from "./test-setup";
import {
  computeChainHash,
  verifyChainHashes,
  type ChainRow,
} from "@/lib/server/audit-chain";

let db: TestDb;

beforeAll(async () => {
  db = await getTestDb();
  await db.auditLog.deleteMany();
  await db.auditChainAnchor.deleteMany();
});

function makeRow(over: Partial<ChainRow> = {}): ChainRow {
  return {
    id: crypto.randomUUID(),
    actorType: "admin",
    actorId: null,
    actorName: "t***@test.local",
    action: "moduleRecord.create",
    targetLabel: null,
    metaJson: null,
    createdAt: new Date(),
    prevChainHash: null,
    chainHash: null,
    ...over,
  };
}

/** Chain a sequence of rows (each row's hash covers its predecessor). */
function buildChain(count: number, prefix: string, createdAt: Date): ChainRow[] {
  const rows: ChainRow[] = [];
  let prev: string | null = null;
  for (let i = 0; i < count; i++) {
    const r = makeRow({ action: `${prefix}${i}`, createdAt });
    const chainHash = computeChainHash({
      prevChainHash: prev,
      actorType: r.actorType,
      actorId: r.actorId,
      actorName: r.actorName,
      action: r.action,
      targetLabel: r.targetLabel,
      metaJson: r.metaJson,
      createdAtISO: r.createdAt.toISOString(),
    });
    r.prevChainHash = prev;
    r.chainHash = chainHash;
    prev = chainHash;
    rows.push(r);
  }
  return rows;
}

describe("audit chain anchor — pure verification semantics", () => {
  /** Chain `kept` onto `pruned` (relink EVERY kept row — the pruned segment
   *  is gone, so every kept hash must be recomputed over the new links). */
  function buildPrunedScenario(keptCount: number, prefix: string): { pruned: ChainRow[]; kept: ChainRow[] } {
    const pruned = buildChain(3, `${prefix}-pruned`, new Date());
    const kept = buildChain(keptCount, `${prefix}-kept`, new Date(Date.now() + 1000));
    let prev: string | null = pruned[2].chainHash as string;
    for (const r of kept) {
      r.prevChainHash = prev;
      r.chainHash = computeChainHash({
        prevChainHash: prev,
        actorType: r.actorType,
        actorId: r.actorId,
        actorName: r.actorName,
        action: r.action,
        targetLabel: r.targetLabel,
        metaJson: r.metaJson,
        createdAtISO: r.createdAt.toISOString(),
      });
      prev = r.chainHash as string;
    }
    return { pruned, kept };
  }

  test("pruned chain + anchor verifies HEALTHY (the round-96 goal)", () => {
    const { pruned, kept } = buildPrunedScenario(2, "a");

    const anchor = { prevHash: pruned[2].chainHash as string };
    const v = verifyChainHashes(kept, anchor);
    expect(v.healthy).toBe(true);
    expect(v.orphans).toHaveLength(0);
    expect(v.anchorMismatch).toBe(false);
    expect(v.chainedRows).toBe(2);
  });

  test("the SAME pruned chain WITHOUT the anchor reports the orphan (old behavior)", () => {
    const { kept } = buildPrunedScenario(2, "b");

    const v = verifyChainHashes(kept, null);
    expect(v.healthy).toBe(false);
    expect(v.orphans).toHaveLength(1); // the boundary backlink dangles
  });

  test("anchor + removal of the OLDEST RETAINED row → ANCHOR MISMATCH detected", () => {
    const { pruned, kept } = buildPrunedScenario(3, "c");

    const anchor = { prevHash: pruned[2].chainHash as string };
    // tampering: the boundary row itself is removed
    const afterRemoval = kept.slice(1);
    const v = verifyChainHashes(afterRemoval, anchor);
    expect(v.healthy).toBe(false);
    expect(v.anchorMismatch).toBe(true);
    // AND its successor's backlink now dangles too
    expect(v.orphans).toHaveLength(1);
  });

  test("mid-chain deletion ABOVE the boundary → orphan (passive deletion, unchanged detection)", () => {
    const { pruned, kept } = buildPrunedScenario(3, "d");

    const anchor = { prevHash: pruned[2].chainHash as string };
    // tampering: the SECOND kept row is removed — its successor still points
    // at the deleted row's hash (no re-chaining / laundering by the attacker)
    const afterDeletion = [kept[0], kept[2]];
    const v = verifyChainHashes(afterDeletion, anchor);
    expect(v.healthy).toBe(false);
    expect(v.orphans).toHaveLength(1); // successor of the deleted mid row
    expect(v.anchorMismatch).toBe(false); // boundary itself intact
  });
});

describe("audit chain anchor — real retention sweep (DB)", () => {
  test("logAudit trigger prunes beyond-window chained rows + anchors + stays healthy", async () => {
    await db.auditLog.deleteMany();
    await db.auditChainAnchor.deleteMany();

    /* 1-day retention; backup scheduler OFF (no snapshots from the sweep) */
    await db.platformSetting.upsert({
      where: { id: "global" },
      create: { id: "global", dataRetention: 1, autoBackup: false },
      update: { dataRetention: 1, autoBackup: false },
    });

    /* old segment: 3 chained rows 10 days beyond the 1-day window (distinct
       timestamps so retention ordering is deterministic) */
    const tenDaysAgo = Date.now() - 10 * 86_400_000;
    const oldRows: ChainRow[] = [];
    let oldPrev: string | null = null;
    for (let i = 0; i < 3; i++) {
      const r = makeRow({ action: `sweepold${i}`, createdAt: new Date(tenDaysAgo + i) });
      r.prevChainHash = oldPrev;
      r.chainHash = computeChainHash({
        prevChainHash: oldPrev,
        actorType: r.actorType,
        actorId: r.actorId,
        actorName: r.actorName,
        action: r.action,
        targetLabel: r.targetLabel,
        metaJson: r.metaJson,
        createdAtISO: r.createdAt.toISOString(),
      });
      oldPrev = r.chainHash;
      oldRows.push(r);
    }
    for (const r of oldRows) {
      await db.auditLog.create({
        data: {
          id: r.id,
          actorType: r.actorType,
          actorId: r.actorId,
          actorName: r.actorName,
          action: r.action,
          targetLabel: r.targetLabel,
          metaJson: r.metaJson,
          createdAt: r.createdAt,
          prevChainHash: r.prevChainHash,
          chainHash: r.chainHash,
        },
      });
    }

    /* fresh segment: 2 chained rows, chained onto the old segment (distinct
       timestamps — the retention sweep and the verifier both order by
       createdAt, id) */
    const nowMs = Date.now();
    const fresh: ChainRow[] = [];
    let freshPrev: string | null = oldRows[2].chainHash;
    for (let i = 0; i < 2; i++) {
      const r = makeRow({ action: `sweepnew${i}`, createdAt: new Date(nowMs + i) });
      r.prevChainHash = freshPrev;
      r.chainHash = computeChainHash({
        prevChainHash: freshPrev,
        actorType: r.actorType,
        actorId: r.actorId,
        actorName: r.actorName,
        action: r.action,
        targetLabel: r.targetLabel,
        metaJson: r.metaJson,
        createdAtISO: r.createdAt.toISOString(),
      });
      freshPrev = r.chainHash;
      fresh.push(r);
    }
    for (const r of fresh) {
      await db.auditLog.create({
        data: {
          id: r.id,
          actorType: r.actorType,
          actorId: r.actorId,
          actorName: r.actorName,
          action: r.action,
          targetLabel: r.targetLabel,
          metaJson: r.metaJson,
          createdAt: r.createdAt,
          prevChainHash: r.prevChainHash,
          chainHash: r.chainHash,
        },
      });
    }

    /* one audited business write triggers the sweep (business action so the
       retention window applies; audit toggle ON) */
    const { logAudit } = await import("@/lib/server/audit");
    await logAudit({
      actorType: "admin",
      actorName: "t***@test.local",
      action: "moduleRecord.update",
      targetLabel: "sweep trigger",
      meta: { probe: "anchor-sweep" },
    });
    /* logAudit is fire-and-forget internally but awaits the row write; give
       the void sweep a beat to land */
    await new Promise((resolve) => setTimeout(resolve, 300));

    /* the old segment is GONE */
    for (const r of oldRows) {
      expect(await db.auditLog.findUnique({ where: { id: r.id } })).toBeNull();
    }
    /* the fresh segment + trigger row survive */
    expect(await db.auditLog.findUnique({ where: { id: fresh[0].id } })).not.toBeNull();
    expect(await db.auditLog.findUnique({ where: { id: fresh[1].id } })).not.toBeNull();

    /* the anchor records the LAST pruned row's hash */
    const anchor = await db.auditChainAnchor.findUnique({ where: { id: "global" } });
    expect(anchor).not.toBeNull();
    expect(anchor?.anchorPrevHash).toBe(oldRows[2].chainHash as string);
    expect(anchor?.anchorRowId).toBe(fresh[0].id);

    /* full verification with the anchor: HEALTHY */
    const remaining = await db.auditLog.findMany({
      orderBy: [{ createdAt: "asc" }, { id: "asc" }],
    });
    const v = verifyChainHashes(
      remaining.map((r) => ({ ...r, createdAt: new Date(r.createdAt) })),
      { prevHash: anchor?.anchorPrevHash as string }
    );
    expect(v.healthy).toBe(true);
    expect(v.chainedRows).toBe(3);
    expect(v.tampered).toHaveLength(0);
  });
});
