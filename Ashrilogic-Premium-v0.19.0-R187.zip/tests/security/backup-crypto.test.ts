/// <reference types="bun-types" />
/**
 * Ashrilogic — ROUND 137 security regression: BACKUP ARTIFACT
 * CONFIDENTIALITY (Phase 2, finding 5).
 *
 * Integrity is not confidentiality: through R136 the hash-verified
 * snapshot pipeline shipped the database copy itself as PLAINTEXT to the
 * off-site bucket and the mirror volume. The ASHBC1 envelope (envelope
 * encryption, purpose-separated master key) is proven here:
 *
 *  1. ROUND-TRIP — encrypt → decrypt returns the exact plaintext;
 *     legacy plaintext buffers are detected (not envelopes);
 *  2. TAMPER — a flipped ciphertext byte fails GCM authentication
 *     (auth-failed); a corrupted header is malformed; NEVER a partial
 *     plaintext;
 *  3. KEY SEPARATION — the app data key (ASHRILOGIC_DATA_KEY) cannot
 *     open backup envelopes;
 *  4. ROTATION — envelopes wrapped by the PREVIOUS key decrypt during
 *     the rotation window; unknown keyIds fail closed (unknown-key);
 *  5. PRODUCTION POSTURE — without ASHRILOGIC_BACKUP_KEY the resolution
 *     reports unavailable (the remote/mirror copies are refused); with
 *     the key provisioned it resolves (dev accepts the documented demo
 *     fallback);
 *  6. LOCAL AT-REST — ASHRILOGIC_BACKUP_ENCRYPT_LOCAL=1 seals the
 *     snapshot's database member; the manifest records the flag while
 *     the plaintext digest/size stay the integrity artifact;
 *  7. SNAPSHOT HEALTH — an encrypted member without a key reports
 *     DATABASE_ENCRYPTED_NO_KEY (visible, never silently ok); with the
 *     key it verifies end-to-end.
 */
import { afterAll, beforeAll, describe, expect, test } from "bun:test";
import { existsSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createHash } from "node:crypto";
import { getTestDb, ensureDemoEnv } from "./test-setup";

ensureDemoEnv();

let crypto: typeof import("@/lib/server/backup-crypto");
let platformBackup: typeof import("@/lib/server/platform-backup");
let snapshotHealth: typeof import("@/lib/server/snapshot-health");
let db: Awaited<ReturnType<typeof getTestDb>>;

const TMP = mkdtempSync(join(tmpdir(), "ashrilogic-backup-crypto-"));
const sha256 = (b: Buffer): string => createHash("sha256").update(b).digest("hex");

/* an arbitrary plaintext standing in for a database artifact — flavored
 * with the pg_dump custom-format magic so the fixture mirrors what the
 * snapshot member actually looks like in the PostgreSQL era (the crypto
 * battery is format-agnostic: only the BYTES matter) */
const PLAIN = Buffer.from(
  "PGDMP" + "\u0000\u0003" + "x".repeat(4096) + Math.random().toString(36)
);

beforeAll(async () => {
  db = await getTestDb();
  crypto = await import("@/lib/server/backup-crypto");
  platformBackup = await import("@/lib/server/platform-backup");
  snapshotHealth = await import("@/lib/server/snapshot-health");
});

afterAll(() => {
  delete process.env.ASHRILOGIC_BACKUP_KEY;
  delete process.env.ASHRILOGIC_BACKUP_KEY_PREVIOUS;
  delete process.env.ASHRILOGIC_BACKUP_ENCRYPT_LOCAL;
  delete process.env.ASHRILOGIC_STORAGE_DIR;
  rmSync(TMP, { recursive: true, force: true });
});

function provisionedKey(): { setEnv: () => void } {
  /* hex 32B — a strong, provisioned-style key for the pure-crypto cases */
  const key = "a".repeat(64);
  return {
    setEnv: () => {
      process.env.ASHRILOGIC_BACKUP_KEY = key;
    },
  };
}

describe("ROUND 137 — backup envelope round-trip + tamper", () => {
  const key = provisionedKey();

  beforeAll(() => {
    key.setEnv();
  });

  test("encrypt → decrypt returns the EXACT plaintext; the envelope is not the plaintext", () => {
    const masters = crypto.resolveBackupMasterKeys();
    expect(masters.available).toBe(true);
    if (!masters.available) throw new Error("unavailable");
    const envelope = crypto.encryptBackupArtifact(PLAIN, masters.active, "database");
    expect(crypto.isBackupEnvelope(envelope)).toBe(true);
    expect(envelope.subarray(0, 6).toString("utf8")).toBe("ASHBC1");
    expect(envelope.includes(PLAIN)).toBe(false); /* the bytes are sealed */
    const opened = crypto.decryptBackupArtifact(envelope, { active: masters.active });
    expect(opened.ok).toBe(true);
    if (opened.ok) expect(opened.plain.equals(PLAIN)).toBe(true);
  });

  test("legacy plaintext buffers are NOT envelopes (backward-compat detector)", () => {
    expect(crypto.isBackupEnvelope(PLAIN)).toBe(false);
    expect(crypto.isBackupEnvelope(Buffer.alloc(0))).toBe(false);
  });

  test("a flipped ciphertext byte FAILS authentication — never a partial plaintext", () => {
    const masters = crypto.resolveBackupMasterKeys();
    if (!masters.available) throw new Error("unavailable");
    const envelope = crypto.encryptBackupArtifact(PLAIN, masters.active, "database");
    envelope[envelope.length - 1] ^= 0x01; /* tamper the LAST ciphertext byte */
    const opened = crypto.decryptBackupArtifact(envelope, { active: masters.active });
    expect(opened.ok).toBe(false);
    if (!opened.ok) expect(opened.reason).toBe("auth-failed");
  });

  test("a corrupted header is malformed (no crash, no guess)", () => {
    const masters = crypto.resolveBackupMasterKeys();
    if (!masters.available) throw new Error("unavailable");
    const envelope = crypto.encryptBackupArtifact(PLAIN, masters.active, "database");
    const truncated = envelope.subarray(0, 10); /* cut inside the header */
    const opened = crypto.decryptBackupArtifact(truncated, { active: masters.active });
    expect(opened.ok).toBe(false);
    if (!opened.ok) expect(opened.reason).toBe("malformed");
  });

  test("the app DATA key cannot open backup envelopes (purpose separation)", () => {
    const masters = crypto.resolveBackupMasterKeys();
    if (!masters.available) throw new Error("unavailable");
    const envelope = crypto.encryptBackupArtifact(PLAIN, masters.active, "database");
    /* a DIFFERENT key — e.g. the field-encryption root — must fail */
    const foreign = {
      key: Buffer.from("b".repeat(32), "utf8"),
      keyId: "",
    };
    foreign.keyId = createHash("sha256").update(foreign.key).digest("hex").slice(0, 16);
    const opened = crypto.decryptBackupArtifact(envelope, { active: foreign });
    expect(opened.ok).toBe(false);
    if (!opened.ok) expect(opened.reason).toBe("unknown-key");
  });
});

describe("ROUND 137 — key rotation window", () => {
  test("envelopes under the PREVIOUS key decrypt during the window; unknown keyIds fail closed", () => {
    const oldKeyHex = "c".repeat(64);
    const newKeyHex = "d".repeat(64);
    process.env.ASHRILOGIC_BACKUP_KEY = newKeyHex;
    process.env.ASHRILOGIC_BACKUP_KEY_PREVIOUS = oldKeyHex;
    const masters = crypto.resolveBackupMasterKeys();
    expect(masters.available).toBe(true);
    if (!masters.available) throw new Error("unavailable");
    expect(masters.previous).toHaveLength(1);

    /* an envelope wrapped by the OLD (now previous) key */
    const oldEnvelope = crypto.encryptBackupArtifact(PLAIN, masters.previous[0]!, "database");
    const opened = crypto.decryptBackupArtifact(oldEnvelope, {
      active: masters.active,
      previous: masters.previous,
    });
    expect(opened.ok).toBe(true);
    if (opened.ok) expect(opened.plain.equals(PLAIN)).toBe(true);

    /* after the window closes (previous dropped), the same envelope fails
     * closed with unknown-key — never a guess */
    const closed = crypto.decryptBackupArtifact(oldEnvelope, { active: masters.active });
    expect(closed.ok).toBe(false);
    if (!closed.ok) expect(closed.reason).toBe("unknown-key");

    /* NEW envelopes wrap with the ACTIVE key */
    const fresh = crypto.encryptBackupArtifact(PLAIN, masters.active, "database");
    const openedFresh = crypto.decryptBackupArtifact(fresh, {
      active: masters.active,
      previous: masters.previous,
    });
    expect(openedFresh.ok).toBe(true);
  });
});

describe("ROUND 137 — production key posture", () => {
  test("PRODUCTION without ASHRILOGIC_BACKUP_KEY: resolution reports unavailable (the copy boundary fails closed)", () => {
    delete process.env.ASHRILOGIC_BACKUP_KEY;
    delete process.env.ASHRILOGIC_BACKUP_KEY_PREVIOUS;
    const saved = process.env.NODE_ENV;
    (process.env as { NODE_ENV?: string }).NODE_ENV = "production";
    try {
      const masters = crypto.resolveBackupMasterKeys();
      expect(masters.available).toBe(false);
    } finally {
      (process.env as { NODE_ENV?: string }).NODE_ENV = saved;
    }
  });

  test("PRODUCTION WITH the key: resolution succeeds (the copies proceed encrypted)", () => {
    provisionedKey().setEnv();
    const saved = process.env.NODE_ENV;
    (process.env as { NODE_ENV?: string }).NODE_ENV = "production";
    try {
      const masters = crypto.resolveBackupMasterKeys();
      expect(masters.available).toBe(true);
    } finally {
      (process.env as { NODE_ENV?: string }).NODE_ENV = saved;
    }
  });

  test("dev without the key: the DOCUMENTED demo fallback (the battery stays exercisable)", () => {
    delete process.env.ASHRILOGIC_BACKUP_KEY;
    const saved = process.env.NODE_ENV;
    (process.env as { NODE_ENV?: string }).NODE_ENV = "development";
    try {
      const masters = crypto.resolveBackupMasterKeys();
      expect(masters.available).toBe(true);
      if (masters.available) expect(masters.demoMaterial).toBe(true);
    } finally {
      (process.env as { NODE_ENV?: string }).NODE_ENV = saved;
    }
  });
});

describe("ROUND 137 — local at-rest encryption + snapshot health", () => {
  test("ASHRILOGIC_BACKUP_ENCRYPT_LOCAL=1 seals the local member; the manifest records the flag + plaintext digest", async () => {
    const root = mkdtempSync(join(TMP, "local-enc-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root;
    provisionedKey().setEnv();
    process.env.ASHRILOGIC_BACKUP_ENCRYPT_LOCAL = "1";

    const result = await platformBackup.runPlatformBackup();
    expect(result).not.toBeNull();
    const snapshotName = result!.split(/[/\\]/).pop()!;
    const dbPath = join(root, "backups", snapshotName, "database.dump");

    /* the local member is now an ENVELOPE */
    const localBytes = readFileSync(dbPath);
    expect(crypto.isBackupEnvelope(localBytes)).toBe(true);

    /* the manifest carries the flag; databaseSha256 is the PLAINTEXT digest */
    const manifest = JSON.parse(
      readFileSync(join(root, "backups", snapshotName, "manifest.json"), "utf8")
    ) as { databaseEncrypted?: boolean; databaseSha256?: string };
    expect(manifest.databaseEncrypted).toBe(true);
    const masters = crypto.resolveBackupMasterKeys();
    if (!masters.available) throw new Error("unavailable");
    const opened = crypto.decryptBackupArtifact(localBytes, {
      active: masters.active,
      previous: masters.previous,
    });
    expect(opened.ok).toBe(true);
    if (opened.ok) expect(sha256(opened.plain)).toBe(manifest.databaseSha256 ?? "");

    /* SNAPSHOT HEALTH verifies the encrypted member end-to-end */
    snapshotHealth.clearSnapshotHealthCache();
    const health = await snapshotHealth.verifyLatestSnapshotHealth({ force: true });
    expect(health.snapshot).toBe(snapshotName);
    expect(health.issues).not.toContain("DATABASE_ENCRYPTED_NO_KEY");
    expect(health.issues).not.toContain("DATABASE_DIGEST_MISMATCH");
    expect(health.issues).not.toContain("DATABASE_CORRUPT");

    delete process.env.ASHRILOGIC_BACKUP_ENCRYPT_LOCAL;
  });

  test("an encrypted member WITHOUT a key reports DATABASE_ENCRYPTED_NO_KEY (visible, never silently ok)", async () => {
    const root = mkdtempSync(join(TMP, "nokey-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root;
    provisionedKey().setEnv();
    process.env.ASHRILOGIC_BACKUP_ENCRYPT_LOCAL = "1";
    const result = await platformBackup.runPlatformBackup();
    expect(result).not.toBeNull();

    /* the key vanishes (rotation loss / misprovisioned host) — under a
     * PRODUCTION posture, where no demo fallback exists */
    delete process.env.ASHRILOGIC_BACKUP_KEY;
    const saved = process.env.NODE_ENV;
    (process.env as { NODE_ENV?: string }).NODE_ENV = "production";
    try {
      snapshotHealth.clearSnapshotHealthCache();
      const health = await snapshotHealth.verifyLatestSnapshotHealth({ force: true });
      expect(health.ok).toBe(false);
      expect(health.issues).toContain("DATABASE_ENCRYPTED_NO_KEY");
    } finally {
      (process.env as { NODE_ENV?: string }).NODE_ENV = saved;
    }

    /* the key returns → health heals */
    provisionedKey().setEnv();
    snapshotHealth.clearSnapshotHealthCache();
    const healed = await snapshotHealth.verifyLatestSnapshotHealth({ force: true });
    expect(healed.ok).toBe(true);
    delete process.env.ASHRILOGIC_BACKUP_ENCRYPT_LOCAL;
  });

  test("a LEGACY plaintext snapshot still verifies (backward compatibility)", async () => {
    const root = mkdtempSync(join(TMP, "legacy-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root;
    delete process.env.ASHRILOGIC_BACKUP_ENCRYPT_LOCAL;
    const result = await platformBackup.runPlatformBackup();
    expect(result).not.toBeNull();
    const snapshotName = result!.split(/[/\\]/).pop()!;
    expect(crypto.isBackupEnvelope(readFileSync(join(root, "backups", snapshotName, "database.dump")))).toBe(false);
    snapshotHealth.clearSnapshotHealthCache();
    const health = await snapshotHealth.verifyLatestSnapshotHealth({ force: true });
    expect(health.ok).toBe(true);
  });
});
