/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 171: the storage-quota write gate is
 * race-free under concurrency.
 *
 * The historical gate (check-then-act against a ≤60s-stale cached
 * snapshot) allowed N concurrent writers to ALL pass before any row
 * landed — collectively exceeding the tenant's plan allowance. The fix
 * (src/lib/server/usage.ts withStorageQuotaWrite) serializes every gated
 * write behind a per-tenant pg_advisory_xact_lock, recomputes the FRESH
 * ground-truth usage inside the transaction, and commits the check + the
 * write atomically.
 *
 * This suite proves the invariant the owner demanded: concurrent writes
 * can NEVER exceed the quota —
 *   1. 8 simultaneous writers each carrying a ~256KB payload against a
 *      1 MB allowance: the accepted set's total bytes stays ≤ the
 *      allowance, and at least one writer is rejected with the 403
 *      STORAGE_QUOTA_EXCEEDED envelope.
 *   2. The DB row count equals the accepted-write count (no phantom
 *      rows from rolled-back writers).
 *   3. The quota envelope stays byte-identical to the historical 403
 *      contract (code + status).
 */
import { describe, beforeAll, afterAll, test, expect } from "bun:test";
import { getTestDb, ensureDemoEnv, type TestDb } from "./test-setup";

ensureDemoEnv();

const RUN = `quota-race-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

let db: TestDb;
let instanceId: string;
/** the workspace's own pre-record footprint (Instance row JSON bytes) */
let baselineBytes = 0;

/** ~256KB of realistic dataJson payload per write. */
function payloadOf(seed: number): string[] {
  const cell = `quota-race-payload-${seed}-`.padEnd(64, "x");
  return Array.from({ length: 4 }, () => cell.repeat(1000)); // 4 × ~64KB
}

beforeAll(async () => {
  db = await getTestDb();

  // A 1 MB-allowance package + an ACTIVE (non-trial) workspace on it.
  const pkg = await db.package.create({
    data: {
      nameAr: `اختبار الحصة ${RUN}`,
      nameEn: `Quota Race ${RUN}`,
      descAr: "اختبار سباق الحصة",
      descEn: "quota race",
      maxStorageMb: 1,
      maxUsers: 5,
      maxModules: 10,
      active: true,
    },
  });
  instanceId = (
    await db.instance.create({
      data: {
        systemId: "hospital-management",
        orgJson: JSON.stringify({
          name: `Org-${RUN}`,
          country: "SA",
          currency: "SAR",
          timezone: "Asia/Riyadh",
          address: "برج الاختبار",
        }),
        adminJson: JSON.stringify({
          name: `Admin-${RUN}`,
          email: `${RUN}@quota.test`,
        }),
        prefsJson: JSON.stringify({ lang: "ar", theme: "light" }),
        modulesJson: JSON.stringify(["patients"]),
        demo: false,
        packageId: pkg.id,
        planActivatedAt: new Date(),
        planCycle: "monthly",
        /* no trial clock → the package quota (1 MB) is the allowance */
        trialEndsAt: null,
      },
    })
  ).id;

  const { computeWorkspaceUsage, __clearUsageCacheForTests } = await import(
    "@/lib/server/usage"
  );
  __clearUsageCacheForTests();
  baselineBytes = (await computeWorkspaceUsage(instanceId, 1)).totalBytes;
});

afterAll(async () => {
  if (!db) return;
  await db.moduleRecord.deleteMany({ where: { instanceId } }).catch(() => undefined);
  await db.instance.deleteMany({ where: { id: instanceId } }).catch(() => undefined);
  await db.package
    .deleteMany({ where: { nameEn: `Quota Race ${RUN}` } })
    .catch(() => undefined);
  await db.$disconnect().catch(() => undefined);
});

describe("ROUND 171 — storage-quota write gate under concurrency", () => {
  test("5 concurrent writers cannot collectively exceed a 1 MB allowance", async () => {
    const { withStorageQuotaWrite } = await import("@/lib/server/usage");

    const WRITERS = 5;
    const PAYLOAD_BYTES = Buffer.byteLength(JSON.stringify(payloadOf(0)), "utf8");

    /* Fire 8 gated writes SIMULTANEOUSLY — every one of them passed the
       historical stale-snapshot gate (the exact TOCTOU shape). */
    type Outcome = { kind: "accepted" | "rejected" | "threw" };
    const outcomes: Outcome[] = Array.from({ length: WRITERS }, () => ({
      kind: "threw" as const,
    }));
    await Promise.all(
      Array.from({ length: WRITERS }, (_, i) =>
        (async () => {
          try {
            const gated = await withStorageQuotaWrite(
              instanceId,
              { incomingBytes: Buffer.byteLength(JSON.stringify(payloadOf(i)), "utf8") },
              (tx) =>
                tx.moduleRecord.create({
                  data: {
                    instanceId,
                    moduleId: "patients",
                    dataJson: JSON.stringify(payloadOf(i)),
                    statusKey: "",
                  },
                })
            );
            outcomes[i] = gated.ok ? { kind: "accepted" } : { kind: "rejected" };
          } catch (e) {
            outcomes[i] = { kind: "threw" };
            if (process.env.QUOTA_RACE_DEBUG) {
              console.log(`writer ${i} threw:`, String((e as Error)?.message).slice(0, 400));
            }
          }
        })()
      )
    );

    const accepted = outcomes.filter((o) => o.kind === "accepted");
    const rejected = outcomes.filter((o) => o.kind === "rejected");
    const threw = outcomes.filter((o) => o.kind === "threw");
    expect(accepted.length + rejected.length + threw.length).toBe(WRITERS);
    /* no writer may crash — a failure must be the 403 envelope */
    expect(threw).toEqual([]);

    /* THE INVARIANT: accepted bytes ≤ the 1 MB allowance */
    const acceptedBytes = accepted.length * PAYLOAD_BYTES;
    expect(acceptedBytes).toBeLessThanOrEqual(1 * 1024 * 1024);
    /* and the boundary is tight: with ~256KB payloads and a 1MB quota the
       gate must have admitted at most 4 writers — and rejected the rest */
    expect(accepted.length).toBeLessThanOrEqual(4);
    expect(rejected.length).toBeGreaterThanOrEqual(1);

    /* the DB carries exactly the accepted rows (rolled-back writers left
       nothing behind) */
    const rows = await db.moduleRecord.count({ where: { instanceId } });
    expect(rows).toBe(accepted.length);

    /* fresh ground truth matches the accepted bytes + the workspace's own
       pre-record footprint (the Instance row JSON) */
    const { computeWorkspaceUsage, __clearUsageCacheForTests } = await import(
      "@/lib/server/usage"
    );
    __clearUsageCacheForTests();
    const usage = await computeWorkspaceUsage(instanceId, 1);
    expect(usage.totalBytes).toBe(baselineBytes + acceptedBytes);
    expect(usage.totalBytes).toBeLessThanOrEqual(1 * 1024 * 1024);
  });

  test("the rejection is the byte-identical historical 403 envelope", async () => {
    const { withStorageQuotaWrite, computeWorkspaceUsage } = await import("@/lib/server/usage");
    /* the previous test filled the allowance (or nearly) — a payload that
       provably cannot fit must 403 with the contract envelope */
    const usage = await computeWorkspaceUsage(instanceId, 1);
    const huge = Math.max(
      2 * 1024 * 1024,
      1 * 1024 * 1024 - usage.totalBytes + 64 * 1024
    );
    const gated = await withStorageQuotaWrite(
      instanceId,
      { incomingBytes: huge },
      (tx) =>
        tx.moduleRecord.create({
          data: { instanceId, moduleId: "patients", dataJson: "{}", statusKey: "" },
        })
    );
    expect(gated.ok).toBe(false);
    if (!gated.ok) {
      expect(gated.response.status).toBe(403);
      const body = (await gated.response.json()) as { error: string; code: string };
      expect(body.code).toBe("STORAGE_QUOTA_EXCEEDED");
      expect(body.error).toContain("Storage quota exceeded");
      expect(body.error).toContain("1 MB");
    }
  });

  test("unlimited-quota workspaces skip the gate and write directly", async () => {
    const { withStorageQuotaWrite } = await import("@/lib/server/usage");
    /* an instance with NO package and NO trial clock → unlimited */
    const freeId = (
      await db.instance.create({
        data: {
          systemId: "hospital-management",
          orgJson: JSON.stringify({ name: `Free-${RUN}`, country: "SA" }),
          adminJson: JSON.stringify({ name: "a", email: `${RUN}-free@t.dev` }),
          prefsJson: JSON.stringify({ lang: "ar" }),
          modulesJson: JSON.stringify(["patients"]),
          demo: false,
        },
      })
    ).id;
    try {
      const gated = await withStorageQuotaWrite(
        freeId,
        { incomingBytes: 5 * 1024 * 1024 },
        (tx) =>
          tx.moduleRecord.create({
            data: {
              instanceId: freeId,
              moduleId: "patients",
              dataJson: JSON.stringify(payloadOf(99)),
              statusKey: "",
            },
          })
      );
      expect(gated.ok).toBe(true);
      expect(
        await db.moduleRecord.count({ where: { instanceId: freeId } })
      ).toBe(1);
    } finally {
      await db.moduleRecord.deleteMany({ where: { instanceId: freeId } });
      await db.instance.deleteMany({ where: { id: freeId } });
    }
  });
});
