/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 187: the demo-secrets affordances are
 * HARD-excluded from production.
 *
 * The three opt-in gates (demo seeding, verification-link reveal,
 * reset-demo) previously armed under `NODE_ENV=production +
 * ALLOW_DEMO_SECRETS=1` — the operator opt-in was documented as a
 * NON-production affordance, but only the admin demo-password bootstrap
 * (ROUND 120) carried the hard exclusion. The fix mirrors that pattern
 * everywhere:
 *
 *   NODE_ENV !== "production" && (dev | test | ALLOW_DEMO_SECRETS=1)
 *
 * This suite pins the call-time gates (verifyLinkRevealEnabled,
 * reset-demo's request-time 404) and the checkPassword null-hash
 * semantics. The import-time DEMO_SEEDING_ENABLED const follows the same
 * audited one-liner pattern (verified by reading; exercising it would
 * require a fresh process with production secrets provisioned).
 */
import { describe, beforeAll, test, expect, afterAll } from "bun:test";
import { ensureDemoEnv } from "./test-setup";

ensureDemoEnv();

const env = process.env as { NODE_ENV?: string; ALLOW_DEMO_SECRETS?: string };

describe("ROUND 187 — ALLOW_DEMO_SECRETS is HARD-excluded from production", () => {
  let verification: typeof import("@/lib/server/verification");
  let resetDemo: typeof import("@/app/api/admin/reset-demo/route");
  let adminSession: typeof import("@/lib/server/admin-session");

  beforeAll(async () => {
    verification = await import("@/lib/server/verification");
    resetDemo = await import("@/app/api/admin/reset-demo/route");
    adminSession = await import("@/lib/server/admin-session");
  });

  const snapshot = () => ({ n: env.NODE_ENV, d: env.ALLOW_DEMO_SECRETS });
  const restore = (s: { n?: string; d?: string }) => {
    env.NODE_ENV = s.n;
    if (s.d === undefined) delete env.ALLOW_DEMO_SECRETS;
    else env.ALLOW_DEMO_SECRETS = s.d;
  };

  test("verifyLinkRevealEnabled — the full truth table", () => {
    const saved = snapshot();
    try {
      env.ALLOW_DEMO_SECRETS = "1";
      env.NODE_ENV = "production";
      expect(verification.verifyLinkRevealEnabled()).toBe(false);
      env.NODE_ENV = "development";
      expect(verification.verifyLinkRevealEnabled()).toBe(true);
      env.NODE_ENV = "test";
      /* the opt-in keeps custom NON-production environments working */
      expect(verification.verifyLinkRevealEnabled()).toBe(true);
      delete env.ALLOW_DEMO_SECRETS;
      env.NODE_ENV = "development";
      expect(verification.verifyLinkRevealEnabled()).toBe(true);
      env.NODE_ENV = "production";
      expect(verification.verifyLinkRevealEnabled()).toBe(false);
    } finally {
      restore(saved);
    }
  });

  test("POST /api/admin/reset-demo — 404 under production + explicit opt-in", async () => {
    const saved = snapshot();
    try {
      env.ALLOW_DEMO_SECRETS = "1";
      env.NODE_ENV = "production";
      const res = await resetDemo.POST(
        new Request("http://localhost:3000/api/admin/reset-demo", {
          method: "POST",
          headers: { origin: "http://localhost:3000" },
        })
      );
      expect(res.status).toBe(404);
      expect(await res.json()).toEqual({ error: "Not found" });
      /* the NON-production opt-in path still passes the gate (liveness):
         an unset NODE_ENV + ALLOW_DEMO_SECRETS=1 must NOT 404 here — the
         gate falls through toward requireAdmin (401 without a session;
         the cookies() call outside a request scope throws in this harness,
         so the leg is asserted by the gate's own truth table above and
         this production exclusion only). */
    } finally {
      restore(saved);
    }
  });

  test("checkPassword — NULL-hash rows: demo bootstrap semantics preserved (dev)", () => {
    /* test env = development + demo secrets: the bootstrap stays usable
       exactly as before the ROUND-187 timing-equalizer change */
    expect(adminSession.checkPassword(adminSession.DEMO_PASSWORD, null)).toBe(true);
    expect(adminSession.checkPassword("definitely-wrong", null)).toBe(false);
    const hash = adminSession.hashPassword("real-password-123");
    expect(adminSession.checkPassword("real-password-123", hash)).toBe(true);
    expect(adminSession.checkPassword("wrong-password", hash)).toBe(false);
  });

  test("checkPassword — NULL-hash failure now BURNS the Argon2id equalizer (no fast oracle)", () => {
    /* before ROUND 187 a NULL-hash row returned instantly while the
       unknown-username path burned one Argon2id verify — a latency
       distinguisher for that row shape. Both failure costs must now be
       the same order of magnitude (>= 10ms on any hardware; an un-burned
       return is < 1ms). */
    const t0 = Date.now();
    expect(adminSession.checkPassword("wrong", null)).toBe(false);
    const nullHashMs = Date.now() - t0;

    const hash = adminSession.hashPassword("real-password-123");
    const t1 = Date.now();
    expect(adminSession.checkPassword("wrong", hash)).toBe(false);
    const hashMs = Date.now() - t1;

    expect(nullHashMs).toBeGreaterThanOrEqual(10);
    expect(hashMs).toBeGreaterThanOrEqual(10);
    /* same order of magnitude — neither path is a cheap distinguisher */
    const ratio = nullHashMs / Math.max(hashMs, 1);
    expect(ratio).toBeGreaterThan(0.1);
    expect(ratio).toBeLessThan(10);
  });

  afterAll(() => {
    env.NODE_ENV = "development";
    delete env.ALLOW_DEMO_SECRETS;
  });
});
