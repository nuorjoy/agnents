/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 120 P1 HARDENING.
 *
 *  1. CARD BRAND (mada): mada's BIN range OVERLAPS visa's (^4) and
 *     mastercard's (5xx) — the mada check MUST run first. The pre-120
 *     order classified 440647…/440795…/457992…/458039… as visa (dead mada
 *     branch for 4 BINs).
 *  2. EXPIRY: DYNAMIC bounds — the current two-digit year is the floor
 *     (cards expiring this year need a future month), current+15 the
 *     ceiling; no hardcoded 45 forever.
 *  3. GUEST CHECKOUT: no Argon2id burn — guest rows carry passwordHash
 *     NULL (checkCustomerPassword fails closed; the register upgrade
 *     sets the real hash).
 *  4. VAULT: decryptFieldTyped discriminates missing/empty/legacy/
 *     decrypted/corrupt + corruption telemetry; the hash path is
 *     backpressure-gated (sustained flood → shed, not starve).
 */

import { describe, expect, test } from "bun:test";
import {
  detectCardBrand,
  expiryIsFuture,
  paymentMethodSchema,
} from "@/lib/server/customer-account";
import { checkCustomerPassword } from "@/lib/server/customer-session";
import {
  decryptFieldTyped,
  encryptField,
  hashPasswordArgon2id,
  __resetAuthWorkWindowForTests,
  __saturateAuthWorkForTests,
  __resetVaultCorruptionForTests,
  vaultCorruptionCount,
} from "@/lib/server/crypto-vault";

describe("ROUND 120 — card brand: mada runs BEFORE visa/mastercard (BIN overlap)", () => {
  test("4-prefixed mada BINs classify as mada (pre-120: visa — dead branch)", () => {
    expect(detectCardBrand("4406471234567890")).toBe("mada");
    expect(detectCardBrand("4407951234567890")).toBe("mada");
    expect(detectCardBrand("4579921234567890")).toBe("mada");
    expect(detectCardBrand("4580391234567890")).toBe("mada");
  });
  test("5-prefixed mada BINs classify as mada (pre-120: mastercard)", () => {
    expect(detectCardBrand("5043001234567890")).toBe("mada");
    expect(detectCardBrand("5641821234567890")).toBe("mada");
    expect(detectCardBrand("5888451234567890")).toBe("mada");
    expect(detectCardBrand("9682012345678901")).toBe("mada");
  });
  test("non-mada prefixes keep their brands", () => {
    expect(detectCardBrand("4111111111111111")).toBe("visa");
    expect(detectCardBrand("5500001234567890")).toBe("mastercard");
    expect(detectCardBrand("2221001234567890")).toBe("mastercard");
    expect(detectCardBrand("34712345678901")).toBe("amex");
    expect(detectCardBrand("6011001234567890")).toBe("card");
  });
});

describe("ROUND 120 — dynamic expiry bounds", () => {
  test("the year floor follows the clock (no hardcoded 45 ceiling forever)", () => {
    const thisYear = new Date().getUTCFullYear() % 100;
    const horizon = (new Date().getUTCFullYear() + 15) % 100;
    /* this year passes (month checked separately) */
    expect(paymentMethodSchema.safeParse({
      number: "4111111111111111", holder: "A B",
      expMonth: 12, expYear: thisYear, isDefault: false,
    }).success).toBe(true);
    /* a 15-year horizon card passes */
    expect(paymentMethodSchema.safeParse({
      number: "4111111111111111", holder: "A B",
      expMonth: 6, expYear: horizon, isDefault: false,
    }).success).toBe(true);
    /* beyond the horizon refuses (whatever the actual year is) */
    const beyond = (new Date().getUTCFullYear() + 20) % 100;
    expect(paymentMethodSchema.safeParse({
      number: "4111111111111111", holder: "A B",
      expMonth: 6, expYear: beyond, isDefault: false,
    }).success).toBe(false);
  });

  test("expiryIsFuture: the current-year month boundary", () => {
    const now = new Date();
    const thisYear2d = now.getUTCFullYear() % 100;
    /* next month of this year is future */
    const nextMonth = (now.getUTCMonth() + 1) % 12 + 1;
    expect(expiryIsFuture(thisYear2d, nextMonth, now)).toBe(true);
    /* JANUARY of this year is past (unless it IS January) */
    if (now.getUTCMonth() > 0) {
      expect(expiryIsFuture(thisYear2d, 1, now)).toBe(false);
    }
    /* a far future year/month is future */
    expect(expiryIsFuture((now.getUTCFullYear() + 5) % 100, 1, now)).toBe(true);
  });
});

describe("ROUND 120 — guest checkout: no Argon2id burn", () => {
  test("checkCustomerPassword fails CLOSED on a null hash (guests never log in)", () => {
    const verdict = checkCustomerPassword("anything", null);
    expect(verdict.ok).toBe(false);
    expect(verdict.upgraded).toBe(false);
    expect(verdict.hash).toBeNull();
  });
  test("hashPasswordArgon2id still produces real credentials for ACTUAL registrations", () => {
    const hash = hashPasswordArgon2id("a-real-password-123");
    expect(hash.startsWith("$argon2id")).toBe(true);
  });
});

describe("ROUND 120 — vault: typed decrypt + corruption telemetry", () => {
  test("decryptFieldTyped discriminates every outcome kind", () => {
    __resetVaultCorruptionForTests();
    expect(decryptFieldTyped(undefined).kind).toBe("missing");
    expect(decryptFieldTyped(null).kind).toBe("missing");
    expect(decryptFieldTyped("").kind).toBe("empty");
    expect(decryptFieldTyped("plain-legacy-value").kind).toBe("legacy-plaintext");
    const sealed = encryptField("secret-data");
    expect(sealed).toMatch(/^enc:v1:/);
    const ok = decryptFieldTyped(sealed);
    expect(ok.kind).toBe("decrypted");
    expect(ok.value).toBe("secret-data");
  });

  test("tampered ciphertext → corrupt (NOT silent empty) + telemetry counted", () => {
    __resetVaultCorruptionForTests();
    const sealed = encryptField("secret-data")!;
    /* flip a byte in the ciphertext tail */
    const tampered = sealed.slice(0, -4) + (sealed.endsWith("AAAA") ? "BBBB" : "AAAA");
    const outcome = decryptFieldTyped(tampered);
    expect(outcome.kind).toBe("corrupt");
    expect(vaultCorruptionCount()).toBe(1);
    /* truncated envelope shape → corrupt too */
    const truncated = sealed.slice(0, sealed.length - 8);
    expect(decryptFieldTyped(truncated).kind).toBe("corrupt");
    expect(vaultCorruptionCount()).toBe(2);
  });

  test("the HASH path is backpressure-gated (flood → shed, not starve)", () => {
    __resetAuthWorkWindowForTests();
    /* saturate the window with cheap injected stamps (the gate reads the
     * window DEPTH — 20 within 10s; the real KDF cost is irrelevant to
     * the gate's arithmetic) */
    __saturateAuthWorkForTests(20);
    /* the 21st hash within the window is shed with the typed error */
    expect(() => hashPasswordArgon2id("flood-attempt")).toThrow(/AUTH_WORK_SATURATED/);
    __resetAuthWorkWindowForTests();
    /* after the reset the gate re-opens */
    expect(hashPasswordArgon2id("normal-again").startsWith("$argon2id")).toBe(true);
  });
});
