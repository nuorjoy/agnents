/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — coupon validation + discount math + tracking-code
 * normalization (src/lib/server/coupons.ts, ROUND 50).
 *
 * Pins under test:
 *  - the discount is always computed in INTEGER MINOR UNITS and can never
 *    exceed the subtotal (a malformed/oversized coupon yields 0, never a
 *    negative payable);
 *  - percentage discounts round UP (merchant never over-refunds rounding);
 *  - every redemption rule (active / window / usage cap / minimum subtotal)
 *    is enforced by evaluateCoupon with machine-readable reasons;
 *  - coupon codes normalize deterministically (case/separators stripped)
 *    and reject structural garbage;
 *  - tracking-phone normalization collapses the common Saudi formats
 *    (05… / 9665… / +9665…) onto ONE index value.
 */
import { describe, test, expect } from "bun:test";
import type { StoreCoupon } from "@prisma/client";
import {
  couponDiscountFor,
  evaluateCoupon,
  generateTrackingCode,
  isValidCouponCode,
  normalizeCouponCode,
  normalizePhoneForIndex,
  TRACKING_CODE_LENGTH,
} from "@/lib/server/coupons";

function fakeCoupon(overrides: Partial<StoreCoupon> = {}): StoreCoupon {
  return {
    id: "c1",
    instanceId: "i1",
    code: "SALE20",
    kind: "percent",
    value: 20,
    minSubtotal: null,
    maxUses: null,
    usedCount: 0,
    startsAt: null,
    expiresAt: null,
    active: true,
    createdAt: new Date(),
    updatedAt: new Date(),
    ...overrides,
  } as StoreCoupon;
}

describe("coupons — code normalization", () => {
  test("strips separators and uppercases", () => {
    expect(normalizeCouponCode(" sale-20 ")).toBe("SALE20");
    expect(normalizeCouponCode("Sale_20")).toBe("SALE20");
    expect(normalizeCouponCode("ramadan.2026")).toBe("RAMADAN2026");
  });

  test("structural validity bounds", () => {
    expect(isValidCouponCode("SALE20")).toBe(true);
    expect(isValidCouponCode("AB")).toBe(false); // too short
    expect(isValidCouponCode("A".repeat(25))).toBe(false); // too long
    expect(isValidCouponCode("SALE 20")).toBe(false); // space survives normalization? no — but raw input here
  });
});

describe("coupons — discount math (minor units)", () => {
  test("percent: ceil rounding, clamped to the subtotal", () => {
    expect(couponDiscountFor({ kind: "percent", value: 20 }, 10_000)).toBe(2_000);
    expect(couponDiscountFor({ kind: "percent", value: 33 }, 100)).toBe(33); // 33 exact
    expect(couponDiscountFor({ kind: "percent", value: 15 }, 999)).toBe(150); // 149.85 → 150 (ceil)
    expect(couponDiscountFor({ kind: "percent", value: 99 }, 10_000)).toBe(9_900);
    expect(couponDiscountFor({ kind: "percent", value: 100 }, 10_000)).toBe(0); // >99 rejected
    expect(couponDiscountFor({ kind: "percent", value: 0 }, 10_000)).toBe(0);
    expect(couponDiscountFor({ kind: "percent", value: -5 }, 10_000)).toBe(0);
  });

  test("fixed: the declared minor amount, clamped to the subtotal", () => {
    expect(couponDiscountFor({ kind: "fixed", value: 2_500 }, 10_000)).toBe(2_500);
    expect(couponDiscountFor({ kind: "fixed", value: 50_000 }, 10_000)).toBe(10_000); // clamped
    expect(couponDiscountFor({ kind: "fixed", value: 0 }, 10_000)).toBe(0);
  });

  test("malformed kinds / non-integer values yield zero", () => {
    expect(couponDiscountFor({ kind: "bogo", value: 50 }, 10_000)).toBe(0);
    expect(couponDiscountFor({ kind: "percent", value: 20.5 }, 10_000)).toBe(0);
    expect(couponDiscountFor({ kind: "fixed", value: 20_000_000_000 }, 10_000)).toBe(0);
  });

  test("non-positive / non-integer subtotals yield zero", () => {
    expect(couponDiscountFor({ kind: "percent", value: 20 }, 0)).toBe(0);
    expect(couponDiscountFor({ kind: "percent", value: 20 }, -100)).toBe(0);
    expect(couponDiscountFor({ kind: "percent", value: 20 }, 1000.5)).toBe(0);
  });
});

describe("coupons — evaluateCoupon rules", () => {
  const now = new Date("2026-01-15T12:00:00Z");

  test("missing row → notFound", () => {
    expect(evaluateCoupon(null, 10_000, now)).toEqual({ ok: false, reason: "notFound" });
  });

  test("inactive → inactive", () => {
    expect(evaluateCoupon(fakeCoupon({ active: false }), 10_000, now)).toEqual({
      ok: false,
      reason: "inactive",
    });
  });

  test("before startsAt / after expiresAt → window", () => {
    expect(
      evaluateCoupon(fakeCoupon({ startsAt: new Date("2026-02-01T00:00:00Z") }), 10_000, now)
    ).toEqual({ ok: false, reason: "window" });
    expect(
      evaluateCoupon(fakeCoupon({ expiresAt: new Date("2026-01-01T00:00:00Z") }), 10_000, now)
    ).toEqual({ ok: false, reason: "window" });
  });

  test("usage cap reached → exhausted", () => {
    expect(evaluateCoupon(fakeCoupon({ maxUses: 5, usedCount: 5 }), 10_000, now)).toEqual({
      ok: false,
      reason: "exhausted",
    });
    expect(evaluateCoupon(fakeCoupon({ maxUses: 5, usedCount: 4 }), 10_000, now).ok).toBe(true);
  });

  test("below the minimum subtotal → minSubtotal", () => {
    expect(evaluateCoupon(fakeCoupon({ minSubtotal: 5_000 }), 4_999, now)).toEqual({
      ok: false,
      reason: "minSubtotal",
    });
    expect(evaluateCoupon(fakeCoupon({ minSubtotal: 5_000 }), 5_000, now).ok).toBe(true);
  });

  test("healthy coupon → discount in minor units", () => {
    const verdict = evaluateCoupon(fakeCoupon({ kind: "percent", value: 25 }), 12_345, now);
    expect(verdict.ok).toBe(true);
    if (verdict.ok) expect(verdict.discountMinor).toBe(3_087); // ceil(12345*0.25)
  });

  test("zero-value degenerate coupon never applies (zero subtotal → inactive)", () => {
    expect(evaluateCoupon(fakeCoupon({ kind: "fixed", value: 1 }), 0, now)).toEqual({
      ok: false,
      reason: "inactive",
    });
  });
});

describe("coupons — tracking codes", () => {
  test("generated codes are the right length + alphabet", () => {
    for (let i = 0; i < 50; i++) {
      const code = generateTrackingCode();
      expect(code).toHaveLength(TRACKING_CODE_LENGTH);
      expect(/^[ABCDEFGHJKMNPQRSTUVWXYZ23456789]+$/.test(code)).toBe(true);
    }
  });

  test("phone normalization collapses the Saudi formats onto one index", () => {
    expect(normalizePhoneForIndex("0551234567")).toBe("551234567");
    expect(normalizePhoneForIndex("966551234567")).toBe("551234567");
    expect(normalizePhoneForIndex("+966 55 123 4567")).toBe("551234567");
  });

  test("short phones keep their digits; garbage is stripped", () => {
    expect(normalizePhoneForIndex("12345")).toBe("12345");
    expect(normalizePhoneForIndex("+--..")).toBe("");
  });
});
