/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — coupon PATCH lost-update guard
 * (src/lib/server/coupon-patch.ts, ROUND 112; closes the reliability
 * audit 2-c LOW finding).
 *
 * Proves the transactional merge engine:
 *  - CONCURRENT disjoint owner edits ALL survive (the headline property):
 *    the old route read the row BEFORE the transaction and re-wrote every
 *    field from that stale snapshot — concurrent editor B's {value} patch
 *    silently reverted editor A's freshly committed maxUses/minSubtotal/
 *    active. The merge base is now read INSIDE the write transaction, so
 *    under the platform's serialized single writer every competing PATCH
 *    (or a guest order's coupon CAS) serializes entirely before or after
 *    THIS read→merge→write;
 *  - validations run against the CURRENT row (a kind flip to percent
 *    rejects a value that is out of percent bounds in the CURRENT state);
 *  - the 404 tenant-scoping semantics and the redemption-window rules;
 *  - the actCouponUpdated activity trail lands with every applied patch;
 *  - the schema refuses an empty patch ("nothing to update").
 */
import { beforeAll, describe, expect, test } from "bun:test";
import { getTestDb, type TestDb } from "./test-setup";

let db: TestDb;
let couponPatch: typeof import("@/lib/server/coupon-patch");

const NOW = new Date("2026-09-18T10:00:00Z");

async function seedInstance(id: string): Promise<void> {
  await db.instance.create({
    data: {
      id,
      systemId: "store-retail",
      orgJson: JSON.stringify({ name: `Coupon Patch Test ${id}` }),
      adminJson: JSON.stringify({ name: "Owner", email: `owner-${id}@example.com` }),
      prefsJson: JSON.stringify({ lang: "ar" }),
      modulesJson: JSON.stringify(["store"]),
      createdAt: NOW,
    },
  });
}

async function seedCoupon(
  instanceId: string,
  id: string,
  overrides: Record<string, unknown> = {}
): Promise<string> {
  await db.storeCoupon.create({
    data: {
      id,
      instanceId,
      code: id.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 24) || "PATCHTEST",
      kind: "percent",
      value: 20,
      active: true,
      createdAt: NOW,
      ...overrides,
    },
  });
  return id;
}

beforeAll(async () => {
  db = await getTestDb();
  couponPatch = await import("@/lib/server/coupon-patch");
  await db.storeCoupon.deleteMany({ where: { instanceId: { startsWith: "coupon-patch-inst" } } });
  await db.activity.deleteMany({ where: { instanceId: { startsWith: "coupon-patch-inst" } } });
  await db.instance.deleteMany({ where: { id: { startsWith: "coupon-patch-inst" } } });
});

describe("coupon patch — the lost-update guard (concurrent disjoint edits)", () => {
  test("six CONCURRENT disjoint patches all survive (old code reverted them)", async () => {
    const inst = "coupon-patch-inst-concurrent";
    await seedInstance(inst);
    const cid = await seedCoupon(inst, "coupon-patch-c-concurrent");

    const startsAt = "2026-09-20T00:00:00.000Z";
    const expiresAt = "2026-09-30T00:00:00.000Z";

    /* All six fired in the same tick — every one merges from whatever the
     * CURRENT committed row is when ITS transaction opens. The old
     * read-before-transaction shape merged from a pre-state snapshot, so
     * the last writer reverted everything it did not itself carry. */
    const results = await Promise.all([
      couponPatch.applyCouponPatch(inst, cid, { maxUses: 50 }),
      couponPatch.applyCouponPatch(inst, cid, { minSubtotal: 1000 }),
      couponPatch.applyCouponPatch(inst, cid, { active: false }),
      couponPatch.applyCouponPatch(inst, cid, { value: 25 }),
      couponPatch.applyCouponPatch(inst, cid, { kind: "fixed" }),
      couponPatch.applyCouponPatch(inst, cid, { startsAt, expiresAt }),
    ]);
    for (const r of results) {
      expect(r.ok).toBe(true);
    }

    const row = await db.storeCoupon.findUnique({ where: { id: cid } });
    expect(row).not.toBeNull();
    /* EVERY disjoint field survived — the property the old code could not
     * guarantee (it kept only the last writer's contributions). */
    expect(row!.maxUses).toBe(50);
    expect(row!.minSubtotal).toBe(1000);
    expect(row!.active).toBe(false);
    expect(row!.value).toBe(25);
    expect(row!.kind).toBe("fixed");
    expect(row!.startsAt?.toISOString()).toBe(startsAt);
    expect(row!.expiresAt?.toISOString()).toBe(expiresAt);
    /* usedCount is never touched by owner PATCHes (order CAS owns it) */
    expect(row!.usedCount).toBe(0);
  });

  test("a concurrent patch never clobbers a mid-flight redemption increment", async () => {
    const inst = "coupon-patch-inst-cas";
    await seedInstance(inst);
    const cid = await seedCoupon(inst, "coupon-patch-c-cas", { maxUses: 10 });

    /* simulate the order-placement CAS committing between two owner edits */
    await db.storeCoupon.update({
      where: { id: cid },
      data: { usedCount: { increment: 1 } },
    });
    const r = await couponPatch.applyCouponPatch(inst, cid, { value: 30 });
    expect(r.ok).toBe(true);
    const row = await db.storeCoupon.findUnique({ where: { id: cid } });
    expect(row!.usedCount).toBe(1);
    expect(row!.value).toBe(30);
  });
});

describe("coupon patch — semantics preserved from the old route", () => {
  test("unknown coupon id → mapped 404; other tenant's coupon → mapped 404", async () => {
    const a = "coupon-patch-inst-scope-a";
    const b = "coupon-patch-inst-scope-b";
    await seedInstance(a);
    await seedInstance(b);
    const cid = await seedCoupon(a, "coupon-patch-c-scope");

    const missing = await couponPatch.applyCouponPatch(a, "coupon-patch-c-missing", { value: 10 });
    expect(missing.ok).toBe(false);
    if (!missing.ok) expect(missing.status).toBe(404);

    /* cross-tenant id: scoped lookup → plain 404, never a write */
    const cross = await couponPatch.applyCouponPatch(b, cid, { value: 10 });
    expect(cross.ok).toBe(false);
    if (!cross.ok) expect(cross.status).toBe(404);
    const row = await db.storeCoupon.findUnique({ where: { id: cid } });
    expect(row!.value).toBe(20); /* untouched */
  });

  test("validation sees the CURRENT merged state, not a stale snapshot", async () => {
    const inst = "coupon-patch-inst-validation";
    await seedInstance(inst);
    /* fixed coupon carrying a value far outside percent bounds */
    const cid = await seedCoupon(inst, "coupon-patch-c-validation", {
      kind: "fixed",
      value: 2000,
    });

    /* kind flip to percent merges with the CURRENT value=2000 → rejected */
    const rejected = await couponPatch.applyCouponPatch(inst, cid, { kind: "percent" });
    expect(rejected.ok).toBe(false);
    if (!rejected.ok) expect(rejected.status).toBe(400);

    /* bring the value into percent bounds FIRST, then flip — accepted */
    const fixed = await couponPatch.applyCouponPatch(inst, cid, { value: 25 });
    expect(fixed.ok).toBe(true);
    const flipped = await couponPatch.applyCouponPatch(inst, cid, { kind: "percent" });
    expect(flipped.ok).toBe(true);
    const row = await db.storeCoupon.findUnique({ where: { id: cid } });
    expect(row!.kind).toBe("percent");
    expect(row!.value).toBe(25);
  });

  test("redemption window must start before it ends; null clears a bound", async () => {
    const inst = "coupon-patch-inst-window";
    await seedInstance(inst);
    const cid = await seedCoupon(inst, "coupon-patch-c-window");

    const bad = await couponPatch.applyCouponPatch(inst, cid, {
      startsAt: "2026-10-02T00:00:00.000Z",
      expiresAt: "2026-10-01T00:00:00.000Z",
    });
    expect(bad.ok).toBe(false);
    if (!bad.ok) expect(bad.status).toBe(400);

    const good = await couponPatch.applyCouponPatch(inst, cid, {
      startsAt: "2026-10-01T00:00:00.000Z",
      expiresAt: "2026-10-02T00:00:00.000Z",
    });
    expect(good.ok).toBe(true);
    const cleared = await couponPatch.applyCouponPatch(inst, cid, { expiresAt: null });
    expect(cleared.ok).toBe(true);
    const row = await db.storeCoupon.findUnique({ where: { id: cid } });
    expect(row!.startsAt?.toISOString()).toBe("2026-10-01T00:00:00.000Z");
    expect(row!.expiresAt).toBeNull();
  });

  test("every applied patch lands an actCouponUpdated activity row", async () => {
    const inst = "coupon-patch-inst-activity";
    await seedInstance(inst);
    const cid = await seedCoupon(inst, "coupon-patch-c-activity");
    await db.activity.deleteMany({ where: { instanceId: inst } });

    const r = await couponPatch.applyCouponPatch(inst, cid, { active: false });
    expect(r.ok).toBe(true);
    const acts = await db.activity.findMany({ where: { instanceId: inst } });
    expect(acts.length).toBe(1);
    expect(acts[0].kind).toBe("actCouponUpdated");
    const meta = JSON.parse(acts[0].metaJson!) as { code: string; active: boolean };
    expect(meta.code).toBe("COUPONPATCHCACTIVITY");
    expect(meta.active).toBe(false);
  });

  test("the schema refuses an empty patch (nothing to update)", () => {
    const parsed = couponPatch.couponPatchSchema.safeParse({});
    expect(parsed.success).toBe(false);
  });
});
