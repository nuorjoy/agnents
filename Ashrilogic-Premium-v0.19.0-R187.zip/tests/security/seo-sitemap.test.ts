/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — SEO correctness battery.
 *
 * Pins the four SEO fixes that machine-readable surfaces depend on:
 *
 *  1. SITEMAP SHARDING: the single-file sitemap's design ceiling was
 *     50,107 URLs — over the sitemap-protocol 50,000-URL single-file limit.
 *     The sharded generator (src/lib/server/sitemap-plan.ts +
 *     src/app/sitemap.ts) must keep EVERY shard ≤ 25,000 URLs at every
 *     row-count boundary, lose no URLs, and never emit a storefront URL
 *     for a tenant whose entitlement lacks the store feature.
 *  2. TRIAL-DAYS SINGLE SOURCE: TRIAL_DAYS (14) is the only trial length
 *     the platform may advertise. llms.txt historically said "7 days" —
 *     this test re-reads the file so the stale number cannot return.
 *  3. LANGUAGE-CLAIM HONESTY: only ar/en/hi carry full dictionaries; no
 *     user-facing or machine-readable string may claim 11 "fully
 *     translated"/"fully multilingual" languages.
 *  4. FAQ SCHEMA BOUND: FAQPage JSON-LD is emitted only by the landing
 *     FAQ section (FaqPageJsonLd) — never by the root StructuredData —
 *     and its Q7 mirrors the visible passkey question (the historical
 *     drift).
 */
import { describe, test, expect } from "bun:test";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import {
  SITEMAP_MAX_URLS_PER_SHARD,
  SITES_TAKE_CAP,
  BLOG_TAKE_CAP,
  coreUrlCount,
  shardCountFor,
  planShards,
  chunkUrls,
  shardUrls,
} from "@/lib/server/sitemap-plan";
import { SYSTEMS } from "@/data/catalog";
import { SITE_URL } from "@/lib/site-url";

const REPO_ROOT = join(import.meta.dir, "..", "..");

/* ------------------------------------------------------------------ */
/* 1. Sitemap sharding boundary behavior                                */
/* ------------------------------------------------------------------ */

describe("sitemap sharding — protocol limits", () => {
  test("per-shard budget is ≤ 50% of the 50,000-URL protocol ceiling", () => {
    expect(SITEMAP_MAX_URLS_PER_SHARD).toBeLessThanOrEqual(25_000);
    expect(SITEMAP_MAX_URLS_PER_SHARD).toBeGreaterThan(0);
  });

  test("shardCountFor boundary behavior", () => {
    expect(shardCountFor(0)).toBe(0);
    expect(shardCountFor(1)).toBe(1);
    expect(shardCountFor(SITEMAP_MAX_URLS_PER_SHARD)).toBe(1);
    expect(shardCountFor(SITEMAP_MAX_URLS_PER_SHARD + 1)).toBe(2);
    expect(shardCountFor(SITEMAP_MAX_URLS_PER_SHARD * 2)).toBe(2);
    expect(shardCountFor(SITEMAP_MAX_URLS_PER_SHARD * 2 + 1)).toBe(3);
  });

  test("chunkUrls loses no entries and never exceeds the per-shard budget", () => {
    const entries = Array.from({ length: SITEMAP_MAX_URLS_PER_SHARD + 7 }, (_, i) => i);
    const chunks = chunkUrls(entries);
    expect(chunks).toHaveLength(2);
    expect(chunks[0]).toHaveLength(SITEMAP_MAX_URLS_PER_SHARD);
    expect(chunks[1]).toHaveLength(7);
    expect(chunks.flat()).toEqual(entries);
    for (const chunk of chunks) {
      expect(chunk.length).toBeLessThanOrEqual(50_000);
    }
  });

  test("the historical worst case (50,107 URLs) shards into files that are ALL under the 50k limit", () => {
    /* 5 static + 102 systems + 20k sites × 2 URLs + 10k blog posts = 50,107
     * — the exact production row-count ceiling that broke the single-file
     * generator. */
    const siteUrlTotal = SITES_TAKE_CAP * 2;
    const blogUrlTotal = BLOG_TAKE_CAP;
    expect(5 + SYSTEMS.length + siteUrlTotal + blogUrlTotal).toBe(50_107);

    const plan = planShards(siteUrlTotal, blogUrlTotal);
    const siteChunks = chunkUrls(Array.from({ length: siteUrlTotal }, (_, i) => i));
    const blogChunks = chunkUrls(Array.from({ length: blogUrlTotal }, (_, i) => i));
    for (const chunk of [...siteChunks, ...blogChunks]) {
      expect(chunk.length).toBeLessThanOrEqual(50_000);
      expect(chunk.length).toBeLessThanOrEqual(SITEMAP_MAX_URLS_PER_SHARD);
    }
    /* core shard: 5 + 102 = 107 — always under the limit by construction */
    expect(coreUrlCount()).toBe(107);
    /* ids are unique, contiguous from 0, and cover every shard */
    expect(new Set(plan.ids).size).toBe(plan.ids.length);
    expect(plan.ids[0]).toBe(0);
    expect(plan.ids).toEqual([...plan.ids].sort((a, b) => a - b));
    expect(plan.siteShards.length + plan.blogShards.length + 1).toBe(plan.ids.length);
  });

  test("empty dynamic sources degrade to the core-only plan (valid, never broken)", () => {
    const plan = planShards(0, 0);
    expect(plan.ids).toEqual([0]);
    expect(shardUrls(plan, SITE_URL)).toEqual([`${SITE_URL}/sitemap/0.xml`]);
  });

  test("core shard URLs are unique (no duplicate sitemap entries)", () => {
    const urls = [
      `${SITE_URL}/`,
      `${SITE_URL}/compare`,
      `${SITE_URL}/blog`,
      `${SITE_URL}/privacy`,
      `${SITE_URL}/terms`,
      ...SYSTEMS.map((s) => `${SITE_URL}/systems/${s.id}`),
    ];
    expect(new Set(urls).size).toBe(urls.length);
    expect(urls.length).toBe(coreUrlCount());
  });

  test("catalog invariants the sitemap relies on", () => {
    expect(SYSTEMS).toHaveLength(102);
    expect(new Set(SYSTEMS.map((s) => s.id)).size).toBe(102);
  });
});

/* ------------------------------------------------------------------ */
/* 2. TRIAL_DAYS single source of truth                                 */
/* ------------------------------------------------------------------ */

describe("TRIAL_DAYS — single source of truth", () => {
  test("the constant is 14 (the provisioned source of truth)", async () => {
    const mod = await import("@/lib/server/entitlement");
    expect((mod as { TRIAL_DAYS: number }).TRIAL_DAYS).toBe(14);
  });

  test("llms.txt advertises the same trial length as the constant", async () => {
    const { TRIAL_DAYS } = await import("@/lib/server/entitlement");
    const llms = readFileSync(join(REPO_ROOT, "public/llms.txt"), "utf-8");
    /* every "N-day trial" / "Trial: N days" phrasing must carry the
       constant's value — the historical file said 7. */
    const dayPatterns = [...llms.matchAll(/(\d+)[- ]day|Trial:\s*(\d+)\s*days/g)];
    expect(dayPatterns.length).toBeGreaterThan(0);
    for (const m of dayPatterns) {
      const claimed = Number(m[1] ?? m[2]);
      expect(claimed).toBe(TRIAL_DAYS);
    }
  });

  test("the archived trial backfill derives its window from the constant, not a literal", () => {
    const src = readFileSync(
      join(REPO_ROOT, "scripts/archive/backfill-trial.ts"),
      "utf-8"
    );
    expect(src).toContain("TRIAL_DAYS");
    expect(src).not.toMatch(/TRIAL_MS\s*=\s*7\s*\*/);
  });
});

/* ------------------------------------------------------------------ */
/* 3. Language-claim honesty (3 full dictionaries, 8 English-fallback)  */
/* ------------------------------------------------------------------ */

describe("language claims — only ar/en/hi are fully translated", () => {
  const FORBIDDEN_PATTERNS: [string, RegExp][] = [
    ["landing dictionary", /11 لغة[^"”]*ترجمة كاملة|fully multilingual \(11|fully translated \(11|11-भाषा/],
  ];

  test("landing/marketing dictionaries never claim 11 fully-translated languages", () => {
    const files = [
      "src/lib/i18n/domains/landing.ts",
      "src/lib/i18n/domains/auth.ts",
      "src/lib/structured-data.ts",
      "public/llms.txt",
    ];
    for (const f of files) {
      const content = readFileSync(join(REPO_ROOT, f), "utf-8");
      for (const [label, pattern] of FORBIDDEN_PATTERNS) {
        expect(`${f} (${label})`, pattern.test(content) ? `matches ${pattern}` : "").toBe(
          `${f} (${label})`
        );
      }
    }
  });

  test("llms.txt language fact matches the translated registry", () => {
    const llms = readFileSync(join(REPO_ROOT, "public/llms.txt"), "utf-8");
    expect(llms).toContain("Languages: Arabic (primary, full RTL), English, Hindi");
  });
});

/* ------------------------------------------------------------------ */
/* 4. FAQ schema binding                                                */
/* ------------------------------------------------------------------ */

describe("FAQPage JSON-LD binding", () => {
  test("root StructuredData no longer ships FAQPage (markup/content mismatch fix)", () => {
    const root = readFileSync(
      join(REPO_ROOT, "src/components/structured-data.tsx"),
      "utf-8"
    );
    /* exactly ONE FAQPage block may exist in the module — inside
       FaqPageJsonLd; the root component's section must not construct it. */
    expect(root.match(/"@type": "FAQPage"/g)?.length ?? 0).toBe(1);
    const body = root
      .split("export function StructuredData()")[1]
      .split("export function FaqPageJsonLd")[0];
    expect(body).not.toContain('"@type": "FAQPage"');
    expect(body).not.toContain("FAQS");
  });

  test("the FAQ schema is rendered by the FAQ section (the visible surface)", () => {
    const faqSection = readFileSync(
      join(REPO_ROOT, "src/components/landing/faq-section.tsx"),
      "utf-8"
    );
    expect(faqSection).toContain("FaqPageJsonLd");
  });

  test("JSON-LD Q7 mirrors the visible passkey question (drift pin)", async () => {
    const { FAQS } = (await import("@/lib/structured-data")) as {
      FAQS: { q: string; a: string }[];
    };
    expect(FAQS).toHaveLength(8);
    expect(FAQS[6].q).toBe("Can I sign in to my account without a password?");
    expect(FAQS[6].a).toContain("passkey");
    /* the isolation answer that previously drifted into Q7 is gone */
    expect(FAQS[6].a).not.toContain("isolated from other organizations");
  });

  test("no route metadata declares same-URL hreflang alternates (P2-2 policy)", async () => {
    /* enumerate every page.tsx under src/app and assert no `languages:`
       alternates block remains (the product has no locale-prefixed routes). */
    const { readdirSync, statSync } = await import("node:fs");
    const collect = (dir: string): string[] => {
      const out: string[] = [];
      for (const name of readdirSync(dir)) {
        const full = join(dir, name);
        if (statSync(full).isDirectory()) out.push(...collect(full));
        else if (name === "page.tsx") out.push(full);
      }
      return out;
    };
    const pages = collect(join(REPO_ROOT, "src/app"));
    const offenders = pages.filter((f) =>
      /languages:\s*\{/.test(readFileSync(f, "utf-8"))
    );
    expect(offenders).toEqual([]);
  });
});
