/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 138: the shared SECURE PASSWORD GENERATOR.
 *
 * Owner directive: the registration wizard (admin-step.tsx) minted tenant
 * admin passwords from Math.random (≈ 933,120 possibilities ≈ 20 bits —
 * crackable in seconds) and the Super Admin subscriber sheet drew its
 * first 4 characters from Math.random in a FIXED class order without
 * shuffling. Both now delegate to ONE shared generator built on
 * crypto.getRandomValues with REJECTION SAMPLING.
 *
 * This suite pins the contract at every seam:
 *   1. FORMAT — length, charset (unambiguous pool only), every character
 *      class present, PASSWORD_RE satisfied;
 *   2. ENTROPY — 12-char draws from the 59-char pool must observe enough
 *      distinct passwords / positional diversity that the old ~20-bit
 *      recipes cannot pass (order-of-magnitude above the legacy space);
 *   3. SHUFFLE — the guaranteed class characters never sit at fixed
 *      positions 0–3 (the old fixed-order defect);
 *   4. UNIFORMITY — rejection sampling keeps the per-character
 *      distribution statistically flat (chi-square-free bucket check at
 *      a generous tolerance);
 *   5. FAIL-CLOSED — invalid arguments throw; a missing CSPRNG throws
 *      (never a Math.random degradation);
 *   6. SOURCE CONTRACT — the generator's body contains no Math.random,
 *      and the two migrated call sites import the shared module (no
 *      local generator survivors).
 */
import { describe, test, expect } from "bun:test";
import { readFileSync } from "node:fs";
import { join } from "node:path";

const { generateSecurePassword, cryptoRandomInt } = await import("@/lib/password");
const { PASSWORD_RE } = await import("@/lib/validation");

const UPPER = "ABCDEFGHJKLMNPQRSTUVWXYZ";
const LOWER = "abcdefghijkmnopqrstuvwxyz";
const DIGITS = "23456789";
const SYMBOLS = "!@#$%&*";
const POOL = UPPER + LOWER + DIGITS + SYMBOLS;
/* The generator's ambiguity exclusions: uppercase I / O, lowercase l,
 * digits 0 / 1 (the classic transcription-ambiguous set). Lowercase
 * i / o keep their dots/shape and stay in the pool by design. */
const AMBIGUOUS = "IOl01";

const SAMPLES = 2_000;

describe("ROUND 138 — shared secure password generator (format contract)", () => {
  test("default length is 12 and every draw only uses the unambiguous pool", () => {
    for (let i = 0; i < 500; i++) {
      const pw = generateSecurePassword();
      expect(pw.length).toBe(12);
      for (const ch of pw) {
        expect(POOL.includes(ch)).toBe(true);
        expect(AMBIGUOUS.includes(ch)).toBe(false);
      }
    }
  });

  test("every draw contains ALL four character classes", () => {
    for (let i = 0; i < 500; i++) {
      const pw = generateSecurePassword();
      expect(/[A-Z]/.test(pw)).toBe(true);
      expect(/[a-z]/.test(pw)).toBe(true);
      expect(/[0-9]/.test(pw)).toBe(true);
      expect(new RegExp(`[${SYMBOLS.replace(/[!@#$%&*]/g, "\\$&")}]`).test(pw)).toBe(true);
    }
  });

  test("every draw satisfies PASSWORD_RE (the submit-time gate)", () => {
    for (let i = 0; i < 500; i++) {
      expect(PASSWORD_RE.test(generateSecurePassword())).toBe(true);
    }
  });

  test("custom lengths are honored (4 = the class minimum, 24, 64)", () => {
    expect(generateSecurePassword(4).length).toBe(4);
    expect(generateSecurePassword(24).length).toBe(24);
    expect(generateSecurePassword(64).length).toBe(64);
  });

  test("invalid lengths throw (fail closed, no silent clamping)", () => {
    expect(() => generateSecurePassword(3)).toThrow();
    expect(() => generateSecurePassword(0)).toThrow();
    expect(() => generateSecurePassword(-1)).toThrow();
    expect(() => generateSecurePassword(12.5)).toThrow();
    expect(() => generateSecurePassword(129)).toThrow();
  });
});

describe("ROUND 138 — entropy + shuffle (the legacy defects cannot recur)", () => {
  test(`the observable password space vastly exceeds the legacy ~20-bit recipe`, () => {
    const seen = new Set<string>();
    for (let i = 0; i < SAMPLES; i++) seen.add(generateSecurePassword());
    /* The old Math.random recipe could produce at most 933,120 distinct
     * passwords; in 2,000 draws it would collide heavily (birthday bound
     * ≈ 1,216 draws for a 50% collision). The shared generator's 2^70.5
     * space makes 2,000 draws all-but-certainly unique. */
    expect(seen.size).toBe(SAMPLES);
  });

  test("the guaranteed class characters never sit at fixed positions 0–3", () => {
    /* The old subscriber-governance defect: position 0 always upper, 1
     * always lower, 2 always digit, 3 always symbol. Across many draws
     * every position must host every class (shuffle is real). */
    const classAt = (ch: string): "u" | "l" | "d" | "s" =>
      UPPER.includes(ch) ? "u" : LOWER.includes(ch) ? "l" : DIGITS.includes(ch) ? "d" : "s";
    const positions = [0, 1, 2, 3];
    const observed = new Map<number, Set<string>>();
    for (const p of positions) observed.set(p, new Set());
    for (let i = 0; i < SAMPLES; i++) {
      const pw = generateSecurePassword();
      for (const p of positions) observed.get(p)!.add(classAt(pw[p]!));
    }
    for (const p of positions) {
      expect(observed.get(p)!.size).toBe(4); /* every class appears at every position */
    }
  });

  test("positional diversity: position 0 is not a fixed class or fixed character", () => {
    const firstChars = new Set<string>();
    for (let i = 0; i < SAMPLES; i++) firstChars.add(generateSecurePassword()[0]!);
    /* Position 0 across 2,000 draws must span many distinct characters
     * (a fixed-prefix generator would emit 1; a 24-char upper-only start
     * would cap at 24 — demand clearly more than a single class). */
    expect(firstChars.size).toBeGreaterThan(30);
  });
});

describe("ROUND 138 — cryptoRandomInt (rejection sampling, uniformity)", () => {
  test("bounds: 0 ≤ result < max for a spread of moduli", () => {
    for (const max of [2, 3, 7, 24, 59, 256, 1000, 65536, 2 ** 31]) {
      for (let i = 0; i < 200; i++) {
        const v = cryptoRandomInt(max);
        expect(Number.isInteger(v)).toBe(true);
        expect(v).toBeGreaterThanOrEqual(0);
        expect(v).toBeLessThan(max);
      }
    }
  });

  test("max=1 always returns 0", () => {
    for (let i = 0; i < 50; i++) expect(cryptoRandomInt(1)).toBe(0);
  });

  test("invalid max throws", () => {
    expect(() => cryptoRandomInt(0)).toThrow();
    expect(() => cryptoRandomInt(-5)).toThrow();
    expect(() => cryptoRandomInt(1.5)).toThrow();
  });

  test("distribution is statistically flat (bucket check, generous tolerance)", () => {
    /* 59 buckets × 5,900 draws → expected 100 per bucket (σ ≈ 9.8). The
     * 0.5×–1.5× window is a >5σ envelope on BOTH sides: with 59 buckets
     * the joint false-failure probability drops below ~1e-5 per run —
     * the check catches a degenerate generator (stuck values, half-empty
     * buckets) without flaking on legitimate CSPRNG tails. */
    const N = 59;
    const draws = 5_900;
    const buckets = new Array<number>(N).fill(0);
    for (let i = 0; i < draws; i++) buckets[cryptoRandomInt(N)]!++;
    const expected = draws / N;
    for (const count of buckets) {
      expect(count).toBeGreaterThan(expected * 0.5);
      expect(count).toBeLessThan(expected * 1.5);
    }
  });

  test("fails closed when the CSPRNG is unavailable (never Math.random)", () => {
    const realCrypto = globalThis.crypto;
    Object.defineProperty(globalThis, "crypto", {
      configurable: true,
      value: { getRandomValues: undefined },
    });
    try {
      expect(() => cryptoRandomInt(10)).toThrow();
      expect(() => generateSecurePassword()).toThrow();
    } finally {
      Object.defineProperty(globalThis, "crypto", {
        configurable: true,
        value: realCrypto,
      });
    }
  });
});

describe("ROUND 138 — source contract (no Math.random survivors)", () => {
  const projectRoot = join(import.meta.dir, "..", "..");

  test("src/lib/password.ts contains no Math.random CALL", () => {
    const src = readFileSync(join(projectRoot, "src/lib/password.ts"), "utf8");
    expect(src.includes("Math.random(")).toBe(false);
  });

  test("the wizard admin-step delegates to the shared generator (no local recipe)", () => {
    const src = readFileSync(
      join(projectRoot, "src/components/wizard/steps/admin-step.tsx"),
      "utf8"
    );
    expect(src).toContain('from "@/lib/password"');
    expect(src.includes("Math.random(")).toBe(false);
  });

  test("the subscriber governance sheet delegates to the shared generator", () => {
    const src = readFileSync(
      join(projectRoot, "src/components/admin/subscriber-governance.tsx"),
      "utf8"
    );
    expect(src).toContain('from "@/lib/password"');
    expect(src.includes("Math.random(")).toBe(false);
  });
});
