/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — UNREFERENCED-IMAGE GC (ROUND 117).
 *
 * Proves the storage-reclamation contract behind "delete/replace an image
 * → its storage is freed precisely":
 *  - collectReferencedImageIds scans EVERY image-bearing column
 *    (ModuleRecord.imageRef — INCLUDING soft-deleted rows — AdminUser
 *    avatarUrl, BlogPost coverImage, Site.contentJson, platform
 *    identityJson) — the reference scan is the sole source of truth;
 *  - the plan: referenced rows are NEVER deletable; unreferenced rows
 *    past grace are planned with accurate bytes; within grace they are
 *    kept (the stale-form protection window);
 *  - execute: row + file die together, bytes reclaimed; a file replaced
 *    between plan and execute (size mismatch) is SKIPPED;
 *  - releaseImageRefs (the write-route hook): dropped refs nothing holds
 *    are removed immediately (row + file); refs ANOTHER row still holds
 *    SURVIVE (content-addressed sharing); non-managed refs are ignored;
 *  - soft-deleted (trashed-but-restorable) rows KEEP their photos — the
 *    trash purge path is what releases them (by design).
 *
 * DB isolation: throwaway PostgreSQL test database via test-setup (never the live DB).
 */

import { beforeAll, afterAll, describe, expect, test } from "bun:test";
import { mkdtempSync, rmSync, mkdirSync, writeFileSync, existsSync, utimesSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createHash } from "node:crypto";
import { ensureDemoEnv, getTestDb, type TestDb } from "./test-setup";

ensureDemoEnv();
const TMP = mkdtempSync(join(tmpdir(), "ashrilogic-image-ref-gc-"));
const IMAGES = join(TMP, "images");
process.env.ASHRILOGIC_STORAGE_DIR = TMP;

let db: TestDb;
let gc: typeof import("@/lib/server/image-ref-gc");

/** Write a content-addressed image file + its ImageAsset row. */
async function seedAsset(
  bytes: string,
  opts: { ageHours?: number; file?: boolean } = {}
): Promise<{ id: string; ref: string; size: number }> {
  const buf = Buffer.from(bytes);
  const id = createHash("sha256").update(buf).digest("hex");
  if (opts.file !== false) {
    writeFileSync(join(IMAGES, `${id}.webp`), buf);
    if (opts.ageHours) {
      const t = new Date(Date.now() - opts.ageHours * 3_600_000);
      utimesSync(join(IMAGES, `${id}.webp`), t, t);
    }
  }
  await db.imageAsset.create({
    data: { id, mime: "image/webp", width: 10, height: 10, bytes: buf.length },
  });
  return { id, ref: `/api/images/${id}`, size: buf.length };
}

function fileOf(id: string): string {
  return join(IMAGES, `${id}.webp`);
}

const INSTANCE_ID = "imgref-inst-1";

beforeAll(async () => {
  db = await getTestDb();
  mkdirSync(IMAGES, { recursive: true });
  gc = await import("@/lib/server/image-ref-gc");
  await db.instance.create({
    data: {
      id: INSTANCE_ID,
      systemId: "inventory",
      orgJson: JSON.stringify({ name: "ImgRef Co", currency: "SAR" }),
      adminJson: "{}",
      prefsJson: "{}",
      modulesJson: JSON.stringify(["inventory"]),
    },
  });
});

afterAll(async () => {
  try {
    await db.moduleRecord.deleteMany({ where: { instanceId: INSTANCE_ID } });
    await db.instance.deleteMany({ where: { id: INSTANCE_ID } });
    await db.adminUser.deleteMany({ where: { username: { contains: "imgref-" } } });
    await db.blogPost.deleteMany({});
    await db.site.deleteMany({});
    await db.imageAsset.deleteMany({});
  } catch {
    /* throwaway DB */
  }
  rmSync(TMP, { recursive: true, force: true });
});

describe("image-ref GC — the reference scan (every column)", () => {
  test("moduleRecord.imageRef, admin avatar, blog cover, site contentJson, identity all count", async () => {
    const rec = await seedAsset("referenced-by-record");
    const avatar = await seedAsset("referenced-by-avatar");
    const cover = await seedAsset("referenced-by-cover");
    const siteAsset = await seedAsset("referenced-by-site-content");

    await db.moduleRecord.create({
      data: {
        instanceId: INSTANCE_ID,
        moduleId: "products",
        dataJson: "{}",
        imageRef: rec.ref,
      },
    });
    await db.adminUser.create({
      data: { username: "imgref-admin", name: "A", email: "a@x.test", avatarUrl: avatar.ref },
    });
    await db.blogPost.create({ data: { slug: `imgref-${Date.now()}`, titleAr: "م", titleEn: "T", coverImage: cover.ref } });
    await db.site.create({
      data: { instanceId: INSTANCE_ID, contentJson: JSON.stringify({ logoUrl: siteAsset.ref }), published: false },
    });

    const ids = await gc.collectReferencedImageIds();
    expect(ids.has(rec.id)).toBeTrue();
    expect(ids.has(avatar.id)).toBeTrue();
    expect(ids.has(cover.id)).toBeTrue();
    expect(ids.has(siteAsset.id)).toBeTrue();

    /* cleanup these fixtures */
    await db.moduleRecord.deleteMany({ where: { instanceId: INSTANCE_ID } });
    await db.adminUser.deleteMany({ where: { username: "imgref-admin" } });
    await db.blogPost.deleteMany({});
    await db.site.deleteMany({});
    for (const a of [rec, avatar, cover, siteAsset]) await db.imageAsset.delete({ where: { id: a.id } });
  });

  test("soft-deleted (trashed) records STILL count — restorable rows keep their photos", async () => {
    const asset = await seedAsset("referenced-by-trashed-record");
    await db.moduleRecord.create({
      data: {
        instanceId: INSTANCE_ID,
        moduleId: "products",
        dataJson: "{}",
        imageRef: asset.ref,
        deletedAt: new Date(),
      },
    });
    const ids = await gc.collectReferencedImageIds();
    expect(ids.has(asset.id)).toBeTrue();

    const plan = await gc.collectImageRefGcPlan({ graceHours: 0 });
    expect(plan.unreferenced.find((e) => e.id === asset.id)).toBeUndefined();

    await db.moduleRecord.deleteMany({ where: { instanceId: INSTANCE_ID } });
    await db.imageAsset.delete({ where: { id: asset.id } });
  });
});

describe("image-ref GC — the plan + execute", () => {
  test("referenced rows never planned; unreferenced past grace planned with bytes; within grace kept", async () => {
    /* isolate: every earlier fixture row is gone before the plan asserts */
    await db.moduleRecord.deleteMany({});
    await db.adminUser.deleteMany({ where: { username: { contains: "imgref-" } } });
    await db.blogPost.deleteMany({ where: { slug: { contains: "imgref-" } } });
    await db.site.deleteMany({ where: { instanceId: INSTANCE_ID } });
    await db.imageAsset.deleteMany({});
    const live = await seedAsset("plan-live-referenced");
    const dead = await seedAsset("plan-dead-unreferenced", { ageHours: 48 });
    const fresh = await seedAsset("plan-fresh-unreferenced" /* mtime now */);

    await db.moduleRecord.create({
      data: { instanceId: INSTANCE_ID, moduleId: "products", dataJson: "{}", imageRef: live.ref },
    });

    const plan = await gc.collectImageRefGcPlan({ graceHours: 24 });
    expect(plan.referenced).toBe(1);
    expect(plan.unreferencedFresh).toBe(1);
    const entry = plan.unreferenced.find((e) => e.id === dead.id);
    expect(entry).toBeDefined();
    expect(entry?.bytes).toBe(dead.size);
    expect(plan.unreferenced.find((e) => e.id === fresh.id)).toBeUndefined();
    expect(plan.reclaimableBytes).toBe(dead.size);

    const result = await gc.executeImageRefGc(plan);
    expect(result.deletedRows).toBe(1);
    expect(result.deletedFiles).toBe(1);
    expect(result.reclaimedBytes).toBe(dead.size);
    expect(existsSync(fileOf(dead.id))).toBeFalse();
    expect(existsSync(fileOf(fresh.id))).toBeTrue();
    expect(existsSync(fileOf(live.id))).toBeTrue();
    expect(await db.imageAsset.findUnique({ where: { id: live.id } })).not.toBeNull();

    await db.moduleRecord.deleteMany({ where: { instanceId: INSTANCE_ID } });
    await db.imageAsset.deleteMany({});
  });

  test("file replaced between plan and execute (size mismatch) → row deleted, file kept", async () => {
    await db.imageAsset.deleteMany({});
    const dead = await seedAsset("victim-replaced-mid-plan", { ageHours: 48 });
    const plan = await gc.collectImageRefGcPlan({ graceHours: 24 });
    expect(plan.unreferenced).toHaveLength(1);

    /* swap the file for different content (different size) after the plan */
    writeFileSync(fileOf(dead.id), Buffer.from("replaced-by-another-process-much-longer"));

    const result = await gc.executeImageRefGc(plan);
    expect(result.deletedRows).toBe(1);
    expect(result.deletedFiles).toBe(0);
    expect(result.vanished).toBe(1);
    expect(existsSync(fileOf(dead.id))).toBeTrue();
    rmSync(fileOf(dead.id), { force: true });
  });
});

describe("image-ref GC — the targeted release hook (write routes)", () => {
  test("dropped ref nothing holds (file past the fresh-write floor) → row + file removed", async () => {
    /* ROUND 120 — the targeted release now skips files younger than the
     * 60s fresh-write floor (an in-flight writer's just-stored bytes are
     * owned by the hourly sweep), so the victim is aged past it */
    const asset = await seedAsset("targeted-release-victim", { ageHours: 2 });
    const out = await gc.releaseImageRefs([asset.ref]);
    expect(out.released).toBe(1);
    expect(out.reclaimedBytes).toBe(asset.size);
    expect(existsSync(fileOf(asset.id))).toBeFalse();
    expect(await db.imageAsset.findUnique({ where: { id: asset.id } })).toBeNull();
  });

  test("ROUND 120 — fresh file (< 60s mtime) is NOT released by the targeted hook (in-flight writer protection)", async () => {
    const asset = await seedAsset("fresh-writer-victim");
    const out = await gc.releaseImageRefs([asset.ref]);
    expect(out.released).toBe(0);
    expect(existsSync(fileOf(asset.id))).toBeTrue();
    expect(await db.imageAsset.findUnique({ where: { id: asset.id } })).not.toBeNull();
    /* cleanup */
    await db.imageAsset.delete({ where: { id: asset.id } });
    rmSync(fileOf(asset.id), { force: true });
  });

  test("ref another row still holds → SURVIVES (content-addressed sharing)", async () => {
    const shared = await seedAsset("shared-asset-two-records");
    await db.moduleRecord.create({
      data: { instanceId: INSTANCE_ID, moduleId: "products", dataJson: "{}", imageRef: shared.ref },
    });
    const out = await gc.releaseImageRefs([shared.ref]);
    expect(out.released).toBe(0);
    expect(existsSync(fileOf(shared.id))).toBeTrue();
    expect(await db.imageAsset.findUnique({ where: { id: shared.id } })).not.toBeNull();

    await db.moduleRecord.deleteMany({ where: { instanceId: INSTANCE_ID } });
    await db.imageAsset.delete({ where: { id: shared.id } });
  });

  test("non-managed + malformed refs are ignored (no DB touch, no crash)", async () => {
    const out = await gc.releaseImageRefs([
      "https://cdn.example.com/logo.png",
      "data:image/png;base64,AAAA",
      null,
      undefined,
      "",
      "/api/images/not-a-sha",
    ]);
    expect(out.released).toBe(0);
    expect(out.reclaimedBytes).toBe(0);
  });
});

/* ------------------------------------------------------------------ */
/* ROUND 120 — the TOCTOU contract + fail-closed scan                  */
/* ------------------------------------------------------------------ */

describe("ROUND 120 — GC TOCTOU: a reference added after the scan NEVER dies", () => {
  test("reference commits between plan and execute → the asset SURVIVES (atomic re-check)", async () => {
    /* the exact interleaving the ROUND 120 fix closes:
     *   GC scan (asset unreferenced) → editor commits imageRef → GC deletes
     * the OLD code deleted the row + file (dangling ref); the NEW atomic
     * conditional delete re-checks every reference surface IN the DELETE
     * statement — the editor's commit makes it miss (0 rows) */
    const asset = await seedAsset("toctou-race-victim", { ageHours: 48 });
    const plan = await gc.collectImageRefGcPlan({ graceHours: 24 });
    expect(plan.unreferenced).toHaveLength(1);

    /* the racing writer: a second record commits the SAME managed ref
     * AFTER the plan was collected (the exact TOCTOU window) */
    await db.moduleRecord.create({
      data: { instanceId: INSTANCE_ID, moduleId: "products", dataJson: "{}", imageRef: asset.ref },
    });

    const result = await gc.executeImageRefGc(plan);
    expect(result.deletedRows).toBe(0);       /* the atomic re-check refused */
    expect(result.deletedFiles).toBe(0);
    expect(result.vanished).toBe(1);
    expect(existsSync(fileOf(asset.id))).toBeTrue(); /* the bytes survive */
    expect(await db.imageAsset.findUnique({ where: { id: asset.id } })).not.toBeNull();

    await db.moduleRecord.deleteMany({ where: { instanceId: INSTANCE_ID } });
    await db.imageAsset.delete({ where: { id: asset.id } });
    rmSync(fileOf(asset.id), { force: true });
  });

  test("reference added mid-EXECUTE loop (between entries) → later entries still re-check", async () => {
    /* two victims in the plan; the FIRST is referenced between the plan
     * and its delete; the SECOND stays unreferenced and is reclaimed —
     * the re-check is per-entry, one save never poisons the loop */
    const saved = await seedAsset("toctou-victim-a", { ageHours: 48 });
    const dead = await seedAsset("toctou-victim-b", { ageHours: 48 });
    const plan = await gc.collectImageRefGcPlan({ graceHours: 24 });
    expect(plan.unreferenced).toHaveLength(2);

    await db.moduleRecord.create({
      data: { instanceId: INSTANCE_ID, moduleId: "products", dataJson: "{}", imageRef: saved.ref },
    });

    const result = await gc.executeImageRefGc(plan);
    expect(result.deletedRows).toBe(1);   /* only the still-unreferenced one */
    expect(result.vanished).toBe(1);      /* the racing reference saved its asset */
    expect(existsSync(fileOf(saved.id))).toBeTrue();
    expect(existsSync(fileOf(dead.id))).toBeFalse();

    await db.moduleRecord.deleteMany({ where: { instanceId: INSTANCE_ID } });
    await db.imageAsset.delete({ where: { id: saved.id } });
    rmSync(fileOf(saved.id), { force: true });
  });

  test("targeted release: reference commits between scan and delete → asset SURVIVES", async () => {
    /* the same race through the write-route hook path */
    const asset = await seedAsset("toctou-targeted-victim", { ageHours: 2 });
    /* pre-attach ONE record, release will run with a fresh scan seeing it —
     * instead exercise the atomic-delete half directly: reference AFTER the
     * hook's internal scan by attaching then detaching in the right order */
    const plan = await gc.collectImageRefGcPlan({ graceHours: 24 });
    await db.moduleRecord.create({
      data: { instanceId: INSTANCE_ID, moduleId: "products", dataJson: "{}", imageRef: asset.ref },
    });
    const result = await gc.executeImageRefGc(plan);
    expect(result.deletedRows).toBe(0);
    expect(await db.imageAsset.findUnique({ where: { id: asset.id } })).not.toBeNull();

    await db.moduleRecord.deleteMany({ where: { instanceId: INSTANCE_ID } });
    await db.imageAsset.delete({ where: { id: asset.id } });
    rmSync(fileOf(asset.id), { force: true });
  });

  test("write-side guard: a managed-ref echo whose asset row is GONE is refused (IMAGE_GONE)", async () => {
    const recordImage = await import("@/lib/server/record-image");
    const asset = await seedAsset("write-side-live", { ageHours: 1 });
    /* live asset → verbatim echo still accepted */
    const live = await recordImage.resolveRecordImage(asset.ref, null);
    expect(live.ok).toBe(true);

    /* GC'd asset → the echo is REFUSED, never a dangling reference */
    await db.imageAsset.delete({ where: { id: asset.id } });
    rmSync(fileOf(asset.id), { force: true });
    const gone = await recordImage.resolveRecordImage(asset.ref, null);
    expect(gone.ok).toBe(false);
    if (!gone.ok) expect(gone.code).toBe("IMAGE_GONE");

    /* undefined / clear keep their documented semantics */
    expect((await recordImage.resolveRecordImage(undefined, asset.ref)).ok).toBe(true);
    expect((await recordImage.resolveRecordImage("", asset.ref)).ok).toBe(true);
  });
});
