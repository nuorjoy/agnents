/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — WALLET CAS (ROUND 121).
 *
 * THE BUG: the customer JSON wallets (addressesJson / paymentMethodsJson)
 * were read-modify-write — requireCustomer reads the row, the mutation
 * computes the next list in memory, an UNCONDITIONAL update persists it.
 * Two devices editing the same wallet both compute from the same base and
 * the second write SILENTLY DISCARDS the first (lost update). R120 closed
 * only POST /payment-methods, and its retry re-read the row but still
 * wrote the ORIGINAL-base value — the concurrent change was lost even
 * inside the retry.
 *
 * THE FIX: writeCustomerWalletCas (customer-account.ts) — a CAS write
 * (UPDATE … WHERE id = ? AND <column> = <as-read>) with ONE bounded retry
 * that RECOMPUTES the mutation against the fresh row, so a concurrent
 * change SURVIVES and the caller's intent is re-applied on top of it.
 *
 * This suite drives the REAL helper against the REAL test database:
 *  1. the happy path persists and returns the fresh row;
 *  2. THE LOST-UPDATE REGRESSION: a concurrent writer's address/card is
 *     still present after our CAS write lands (pre-121: gone);
 *  3. GONE: the target item vanishing under us surfaces as {code:"GONE"}
 *     (→ the routes' 404), never a silent no-op write;
 *  4. CAP: a fresh-full wallet surfaces as {code:"CAP"} (→ the 409s);
 *  5. a STILL-live race (the row keeps changing) resolves as a clean
 *     {code:"CONFLICT"} after the single bounded retry — never a
 *     last-write-win and never an unbounded spin.
 */

import { beforeAll, afterAll, describe, expect, test } from "bun:test";
import { ensureDemoEnv, getTestDb, type TestDb } from "./test-setup";

/* CANONICAL ISOLATION PATTERN (test-setup's contract): every module that
 * transitively binds `@/lib/db` is imported DYNAMICALLY in beforeAll —
 * AFTER ensureDemoEnv() redirected DATABASE_URL to the throwaway test db.
 * A static import would hoist ABOVE the env override and bind the Prisma
 * singleton to the live DATABASE_URL (the dev server's PostgreSQL
 * database). customer-account → @/lib/db is exactly such a module. */
ensureDemoEnv();

const INSTANCE = "wallet-cas-instance";
const CUSTOMER = "wallet-cas-customer";

let db: TestDb;
let account: typeof import("@/lib/server/customer-account");
let MAX_ADDRESSES: number;
let MAX_PAYMENT_METHODS: number;

beforeAll(async () => {
  db = await getTestDb();
  account = await import("@/lib/server/customer-account");
  MAX_ADDRESSES = account.MAX_ADDRESSES;
  MAX_PAYMENT_METHODS = account.MAX_PAYMENT_METHODS;
  await db.instance.deleteMany({ where: { id: INSTANCE } });
  await db.instance.create({
    data: {
      id: INSTANCE,
      systemId: "products",
      orgJson: JSON.stringify({ name: "Wallet CAS", currency: "SAR" }),
      adminJson: "{}",
      prefsJson: "{}",
      modulesJson: "[]",
    },
  });
});

afterAll(async () => {
  await db.siteCustomer.deleteMany({ where: { id: CUSTOMER } });
  await db.instance.deleteMany({ where: { id: INSTANCE } });
});

/** Fresh customer row with the given wallets. */
async function freshCustomer(
  addresses: unknown[],
  methods: unknown[] = []
): Promise<void> {
  await db.siteCustomer.deleteMany({ where: { id: CUSTOMER } });
  await db.siteCustomer.create({
    data: {
      id: CUSTOMER,
      instanceId: INSTANCE,
      name: "CAS Tester",
      email: "",
      passwordHash: "",
      addressesJson: JSON.stringify(addresses),
      paymentMethodsJson: JSON.stringify(methods),
    },
  });
}

const ADDR = (n: number, extra: Record<string, unknown> = {}) => ({
  id: `addr-${n}`,
  label: `Home ${n}`,
  fullName: "CAS Tester",
  phone: "0551234567",
  city: "الرياض",
  district: "النرجس",
  street: `شارع ${n}`,
  building: `مبنى ${n}`,
  floor: "2",
  apartment: "5",
  notes: "",
  isDefault: n === 1,
  ...extra,
});

/** Full valid address input (the addressSchema shape minus id). */
const ADDR_INPUT = (label: string, city: string) => ({
  label,
  fullName: "CAS Tester",
  phone: "0551234567",
  city,
  district: "حي",
  street: "شارع",
  building: "مبنى",
  floor: "1",
  apartment: "1",
  notes: "",
  isDefault: false,
});

describe("ROUND 121 — wallet CAS (addresses)", () => {
  test("happy path: the write lands, the row refreshes, defaults normalize", async () => {
    await freshCustomer([ADDR(1)]);
    const base = await db.siteCustomer.findUniqueOrThrow({ where: { id: CUSTOMER } });
    const outcome = await account.writeCustomerWalletCas(
      base,
      "addressesJson",
      (row) => {
        const r = account.withAddress(row, ADDR_INPUT("Work", "جدة"));
        return r.error === "CAP" ? { error: "CAP" } : { value: JSON.stringify(r.addresses) };
      }
    );
    expect(outcome.ok).toBe(true);
    const stored = account.readAddresses(
      await db.siteCustomer.findUniqueOrThrow({ where: { id: CUSTOMER } })
    );
    expect(stored).toHaveLength(2);
    expect(stored.filter((a) => a.isDefault)).toHaveLength(1);
  });

  test("THE LOST-UPDATE REGRESSION: a concurrent writer's address SURVIVES our write", async () => {
    await freshCustomer([ADDR(1)]);
    const base = await db.siteCustomer.findUniqueOrThrow({ where: { id: CUSTOMER } });

    /* a concurrent device adds an address between our read and our write */
    const concurrent = account.withAddress(base, ADDR_INPUT("Concurrent", "الدمام"));
    await db.siteCustomer.update({
      where: { id: CUSTOMER },
      data: { addressesJson: JSON.stringify(concurrent.addresses) },
    });

    /* OUR write — computed from the STALE base; pre-121 this would have
     * unconditionally overwritten the concurrent address (lost update) */
    const outcome = await account.writeCustomerWalletCas(
      base,
      "addressesJson",
      (row) => {
        const r = account.withAddress(row, ADDR_INPUT("Ours", "مكة"));
        return r.error === "CAP" ? { error: "CAP" } : { value: JSON.stringify(r.addresses) };
      }
    );
    expect(outcome.ok).toBe(true);

    const stored = account.readAddresses(
      await db.siteCustomer.findUniqueOrThrow({ where: { id: CUSTOMER } })
    );
    const labels = stored.map((a) => a.label);
    /* BOTH the concurrent writer's address AND ours are present — the
     * defining property of the fix (pre-121: "Concurrent" was gone) */
    expect(labels).toContain("Concurrent");
    expect(labels).toContain("Ours");
    expect(stored).toHaveLength(3);
  });

  test("GONE: the target address vanishing under us surfaces as {code:'GONE'} — no silent no-op", async () => {
    await freshCustomer([ADDR(1), ADDR(2)]);
    const base = await db.siteCustomer.findUniqueOrThrow({ where: { id: CUSTOMER } });

    /* concurrent device removes addr-2 (our patch target) */
    const concurrent = account.withoutAddress(base, "addr-2");
    expect(concurrent).not.toBeNull();
    await db.siteCustomer.update({
      where: { id: CUSTOMER },
      data: { addressesJson: JSON.stringify(concurrent) },
    });

    const outcome = await account.writeCustomerWalletCas(
      base,
      "addressesJson",
      (row) => {
        const next = account.patchAddress(row, "addr-2", { label: "Renamed" });
        return next ? { value: JSON.stringify(next) } : { error: "GONE" };
      }
    );
    expect(outcome).toEqual({ ok: false, code: "GONE" });
    /* and NOTHING was written after the GONE surfaced */
    const stored = account.readAddresses(
      await db.siteCustomer.findUniqueOrThrow({ where: { id: CUSTOMER } })
    );
    expect(stored).toHaveLength(1);
  });

  test("CAP: a fresh-full address book surfaces as {code:'CAP'} on the retry", async () => {
    await freshCustomer(
      Array.from({ length: MAX_ADDRESSES }, (_, i) => ADDR(i + 1))
    );
    const base = await db.siteCustomer.findUniqueOrThrow({ where: { id: CUSTOMER } });
    /* the book is ALREADY full for the base row — the first recompute
     * rejects it without a single write attempt */
    const outcome = await account.writeCustomerWalletCas(
      base,
      "addressesJson",
      (row) => {
        const r = account.withAddress(row, ADDR_INPUT("Overflow", "أبها"));
        return r.error === "CAP" ? { error: "CAP" } : { value: JSON.stringify(r.addresses) };
      }
    );
    expect(outcome).toEqual({ ok: false, code: "CAP" });
    const stored = account.readAddresses(
      await db.siteCustomer.findUniqueOrThrow({ where: { id: CUSTOMER } })
    );
    expect(stored).toHaveLength(MAX_ADDRESSES);
  });

  test("CONFLICT: a still-live race resolves cleanly after the single bounded retry — never a last-write-win", async () => {
    await freshCustomer([ADDR(1)]);
    const base = await db.siteCustomer.findUniqueOrThrow({ where: { id: CUSTOMER } });

    /* the row keeps changing under us: every recompute ALSO mutates the
     * row (a hostile stand-in for continuous concurrent writers), so both
     * CAS attempts miss and the helper must stop at a clean conflict */
    let calls = 0;
    const outcome = await account.writeCustomerWalletCas(
      base,
      "addressesJson",
      async (row) => {
        calls++;
        if (calls >= 1) {
          const churn = account.withAddress(row, ADDR_INPUT(`Churn ${calls}`, "تبوك"));
          await db.siteCustomer.update({
            where: { id: CUSTOMER },
            data: { addressesJson: JSON.stringify(churn.addresses) },
          });
        }
        const r = account.withAddress(row, ADDR_INPUT("Ours", "حائل"));
        return r.error === "CAP" ? { error: "CAP" } : { value: JSON.stringify(r.addresses) };
      }
    );
    expect(outcome).toEqual({ ok: false, code: "CONFLICT" });
    expect(calls).toBe(2); /* exactly one bounded retry — no spin */
  });
});

describe("ROUND 121 — wallet CAS (payment methods)", () => {
  const CARD = {
    number: "4111111111111111",
    holder: "AHMED ALI",
    expMonth: 12,
    expYear: new Date().getFullYear() + 2,
    isDefault: false,
  };

  test("THE R120 RETRY FLAW: a concurrent wallet change SURVIVES our retry (pre-121 retry dropped it)", async () => {
    await freshCustomer([], [
      {
        id: "pm-1",
        brand: "visa",
        last4: "4242",
        expMonth: 12,
        expYear: new Date().getFullYear() + 1,
        holder: "AHMED ALI",
        isDefault: true,
      },
    ]);
    const base = await db.siteCustomer.findUniqueOrThrow({ where: { id: CUSTOMER } });

    /* a concurrent device adds a card between our read and our write */
    const concurrent = account.withPaymentMethod(base, {
      number: "5500001234567890",
      holder: "AHMED ALI",
      expMonth: 11,
      expYear: new Date().getFullYear() + 1,
      isDefault: false,
    });
    await db.siteCustomer.update({
      where: { id: CUSTOMER },
      data: { paymentMethodsJson: JSON.stringify(concurrent.methods) },
    });

    const outcome = await account.writeCustomerWalletCas(
      base,
      "paymentMethodsJson",
      (row) => {
        const r = account.withPaymentMethod(row, CARD);
        return r.error === "CAP" ? { error: "CAP" } : { value: JSON.stringify(r.methods) };
      }
    );
    expect(outcome.ok).toBe(true);

    const stored = account.readPaymentMethods(
      await db.siteCustomer.findUniqueOrThrow({ where: { id: CUSTOMER } })
    );
    /* the concurrent card SURVIVED our retry (the R120 retry wrote the
     * ORIGINAL-base list — the concurrent card was dropped) */
    expect(stored.map((m) => m.last4)).toContain("7890");
    expect(stored.map((m) => m.last4)).toContain("1111");
    expect(stored).toHaveLength(3);
  });

  test("GONE: removing a card that vanished concurrently surfaces as {code:'GONE'}", async () => {
    await freshCustomer([], [
      {
        id: "pm-1",
        brand: "visa",
        last4: "4242",
        expMonth: 12,
        expYear: new Date().getFullYear() + 1,
        holder: "AHMED ALI",
        isDefault: true,
      },
      {
        id: "pm-2",
        brand: "mada",
        last4: "7890",
        expMonth: 11,
        expYear: new Date().getFullYear() + 1,
        holder: "AHMED ALI",
        isDefault: false,
      },
    ]);
    const base = await db.siteCustomer.findUniqueOrThrow({ where: { id: CUSTOMER } });

    /* concurrent device removes pm-2 (our delete target) */
    const concurrent = account.withoutPaymentMethod(base, "pm-2");
    expect(concurrent).not.toBeNull();
    await db.siteCustomer.update({
      where: { id: CUSTOMER },
      data: { paymentMethodsJson: JSON.stringify(concurrent) },
    });

    const outcome = await account.writeCustomerWalletCas(
      base,
      "paymentMethodsJson",
      (row) => {
        const next = account.withoutPaymentMethod(row, "pm-2");
        return next ? { value: JSON.stringify(next) } : { error: "GONE" };
      }
    );
    expect(outcome).toEqual({ ok: false, code: "GONE" });
    const stored = account.readPaymentMethods(
      await db.siteCustomer.findUniqueOrThrow({ where: { id: CUSTOMER } })
    );
    expect(stored).toHaveLength(1);
  });

  test("CAP: a fresh-full wallet surfaces as {code:'CAP'}", async () => {
    const full = Array.from({ length: MAX_PAYMENT_METHODS }, (_, i) => ({
      id: `pm-${i + 1}`,
      brand: "visa",
      last4: `111${i}`,
      expMonth: 12,
      expYear: new Date().getFullYear() + 1,
      holder: "AHMED ALI",
      isDefault: i === 0,
    }));
    await freshCustomer([], full);
    const base = await db.siteCustomer.findUniqueOrThrow({ where: { id: CUSTOMER } });
    const outcome = await account.writeCustomerWalletCas(
      base,
      "paymentMethodsJson",
      (row) => {
        const r = account.withPaymentMethod(row, CARD);
        return r.error === "CAP" ? { error: "CAP" } : { value: JSON.stringify(r.methods) };
      }
    );
    expect(outcome).toEqual({ ok: false, code: "CAP" });
    const stored = account.readPaymentMethods(
      await db.siteCustomer.findUniqueOrThrow({ where: { id: CUSTOMER } })
    );
    expect(stored).toHaveLength(MAX_PAYMENT_METHODS);
  });
});
