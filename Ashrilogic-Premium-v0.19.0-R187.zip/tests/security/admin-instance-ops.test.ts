/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 136: the Super-Admin STRICT INSTANCE
 * CONNECTION (owner directive #3 — «في جميع الأنظمة الـ100 متصلة بلوحة
 * تحكم الـ Super Admin بطريقة احترافية وقوية وصارمة»).
 *
 * Three surfaces, all offline against the throwaway test database with the
 * REAL imported route handlers (next/headers mocked at the module boundary
 * so the admin session cookie is controllable per test — the
 * tenant-uniqueness idiom):
 *
 *  1. GET /api/admin/instances/[id]/ops (the STRONG telemetry drilldown):
 *     unauthenticated 401 · non-super admin 403 · super 200 with the EXACT
 *     key envelope (instance/health/store/site/webhooks/shifts/audit —
 *     no PII keys like email/phone anywhere in the payload) · unknown id
 *     404 · the aggregates are real (sessions, members, products, low
 *     stock, orders, revenue, shifts, webhooks, audit linkage).
 *
 *  2. POST /api/admin/instances/[id]/sessions/revoke-all (the STRICT
 *     lever): super 200 {revoked} with the workspace sessionVersion BUMPED
 *     + exactly the live sessions destroyed (pre-revoked and expired rows
 *     never count; another tenant's sessions are untouched) · non-super
 *     403 without any mutation.
 *
 *  3. GET /api/admin/audit?instanceId=… (the per-instance filter):
 *     workspace-actor rows for instance A vs B are partitioned correctly
 *     (filter returns ONLY A's) · the ROUND 136 meta.instance-stamped
 *     platform rows (admin.instanceOps) join A's filtered trail ·
 *     unauthenticated 401.
 */
import { describe, test, expect, beforeAll, afterAll, mock } from "bun:test";
import { getTestDb, resetRateTable, type TestDb, ensureDemoEnv } from "./test-setup";

ensureDemoEnv();

/* Mock BEFORE any dynamic import of the routes (admin-session resolves the
 * admin cookie through next/headers). The jar is controllable per test:
 * empty = unauthenticated; a crafted admin-session cookie = signed in. */
const cookieJar = new Map<string, string>();
mock.module("next/headers", () => ({
  cookies: async () => ({
    get: (name: string) =>
      cookieJar.has(name) ? { name, value: cookieJar.get(name) as string } : undefined,
    set: (name: string, value: string) => {
      cookieJar.set(name, value);
    },
    delete: (name: string) => {
      cookieJar.delete(name);
    },
  }),
  headers: async () => ({ get: () => undefined }),
  draftMode: async () => ({ isEnabled: () => false }),
}));

const HOST = "localhost:3000";
const RUN = Math.random().toString(36).slice(2, 8);
function freshEmail(tag: string): string {
  return `${tag}-${RUN}-${Math.random().toString(36).slice(2, 7)}@ops.test`;
}
/** a random never-before-used phone (deep-uniqueness law — R134-E) */
function freshPhone(): string {
  return `+96656${String(Math.floor(Math.random() * 1e8)).padStart(8, "0")}`;
}

let db: TestDb;
let opsRoute: typeof import("@/app/api/admin/instances/[id]/ops/route");
let revokeRoute: typeof import("@/app/api/admin/instances/[id]/sessions/revoke-all/route");
let auditRoute: typeof import("@/app/api/admin/audit/route");
let audit: typeof import("@/lib/server/audit");
let mapper: typeof import("@/lib/server/instance-mapper");
let tokens: typeof import("@/lib/server/tokens");
let sessions: typeof import("@/lib/server/sessions");
let cookieNames: typeof import("@/lib/server/cookie-names");

/* ------------------------------------------------------------------ */
/* fixtures                                                            */
/* ------------------------------------------------------------------ */

const SUPER_ID = `adm-super-${RUN}`;
const STAFF_ID = `adm-staff-${RUN}`;

const createdInstanceIds: string[] = [];
const createdAdminIds: string[] = [SUPER_ID, STAFF_ID];

async function makeInstance(opts: {
  id: string;
  systemId: string;
  modules: string[];
  orgName: string;
}): Promise<string> {
  const sealed = mapper.sealAdminSection({
    name: "مالك",
    email: freshEmail("owner"),
    role: "owner",
    twoFA: false,
  });
  await db.instance.create({
    data: {
      id: opts.id,
      systemId: opts.systemId,
      orgJson: JSON.stringify({
        name: opts.orgName,
        country: "SA",
        currency: "SAR",
        timezone: "Asia/Riyadh",
        address: "برج الاختبار",
        phone: freshPhone(),
      }),
      adminJson: sealed.adminJson,
      adminEmailIndex: sealed.adminEmailIndex,
      prefsJson: JSON.stringify({ lang: "ar", theme: "light", notif: true, backup: true, audit: true, demo: false }),
      modulesJson: JSON.stringify(opts.modules),
    },
  });
  createdInstanceIds.push(opts.id);
  return opts.id;
}

let idA = "";
let idB = "";

beforeAll(async () => {
  db = await getTestDb();
  opsRoute = await import("@/app/api/admin/instances/[id]/ops/route");
  revokeRoute = await import("@/app/api/admin/instances/[id]/sessions/revoke-all/route");
  auditRoute = await import("@/app/api/admin/audit/route");
  audit = await import("@/lib/server/audit");
  mapper = await import("@/lib/server/instance-mapper");
  tokens = await import("@/lib/server/tokens");
  sessions = await import("@/lib/server/sessions");
  cookieNames = await import("@/lib/server/cookie-names");

  await resetRateTable(db);

  /* two platform admins: the super (owns the levers) + a managing-tier
   * staff admin (must be refused — the routes are SUPER-ONLY) */
  await db.adminUser.create({
    data: {
      id: SUPER_ID,
      username: `super-${RUN}`,
      name: "Super Admin",
      email: freshEmail("super"),
      role: "super",
      active: true,
    },
  });
  await db.adminUser.create({
    data: {
      id: STAFF_ID,
      username: `staff-${RUN}`,
      name: "Staff Admin",
      email: freshEmail("staff"),
      role: "admin",
      active: true,
    },
  });

  /* two tenants: A = the supermarket (products catalog), B = restaurant */
  idA = await makeInstance({
    id: `inst-a-${RUN}`,
    systemId: "supermarket-grocery",
    modules: ["products"],
    orgName: `سوبرماركت الاختبار ${RUN}`,
  });
  idB = await makeInstance({
    id: `inst-b-${RUN}`,
    systemId: "restaurant-management",
    modules: ["menu"],
    orgName: `مطعم الاختبار ${RUN}`,
  });

  /* A's real telemetry posture: activity, members, site, customer, an
   * order, catalog rows, shifts, webhook endpoints + deliveries */
  await db.activity.create({ data: { instanceId: idA, kind: "actCreated" } });
  await db.teamMember.create({
    data: { instanceId: idA, name: "كاشير", email: freshEmail("member") },
  });
  await db.site.create({ data: { instanceId: idA, published: true, views: 42 } });
  const customer = await db.siteCustomer.create({
    data: { instanceId: idA, name: "عميل", email: freshEmail("shopper") },
  });
  await db.siteOrder.create({
    data: {
      instanceId: idA,
      customerId: customer.id,
      itemsJson: JSON.stringify([]),
      total: 15000,
      status: "completed",
      currency: "SAR",
    },
  });
  /* sellable catalog (products module columns: name/…/stock/price at
   * indexes 0/3/4 — the admin/stores resolution law) */
  await db.moduleRecord.create({
    data: { instanceId: idA, moduleId: "products", dataJson: JSON.stringify(["حليب", "طازج", "ألبان", "10", "6.5"]) },
  });
  await db.moduleRecord.create({
    data: { instanceId: idA, moduleId: "products", dataJson: JSON.stringify(["خبز", "", "مخبوزات", "3", "2"]) },
  });
  await db.shift.create({
    data: { instanceId: idA, code: `SHF-A-${RUN}`, openedBy: "مالك", status: "closed", closedAt: new Date() },
  });
  await db.webhookEndpoint.create({
    data: { instanceId: idA, url: "https://hooks.example.test/a", secret: "s".repeat(64) },
  });
  await db.webhookEndpoint.create({
    data: { instanceId: idA, url: "https://hooks.example.test/off", secret: "s".repeat(64), active: false },
  });
  const liveEndpoint = await db.webhookEndpoint.findFirstOrThrow({
    where: { instanceId: idA, active: true },
  });
  await db.webhookDelivery.create({
    data: { endpointId: liveEndpoint.id, instanceId: idA, event: "order.placed", payloadJson: "{}", status: "failed", createdAt: new Date(Date.now() - 60 * 60 * 1000) },
  });
  await db.webhookDelivery.create({
    data: { endpointId: liveEndpoint.id, instanceId: idA, event: "order.placed", payloadJson: "{}", status: "failed", createdAt: new Date(Date.now() - 40 * 24 * 60 * 60 * 1000) },
  });

  /* sessions: 3 LIVE for A (+1 already revoked +1 expired — neither may
   * count), 1 live for B (must survive A's revocation) */
  for (let i = 0; i < 3; i++) {
    await db.sessionRecord.create({
      data: {
        id: `jti-live-${RUN}-${i}`,
        scope: "instance",
        subjectId: idA,
        expiresAt: new Date(Date.now() + 60 * 60 * 1000),
      },
    });
  }
  await db.sessionRecord.create({
    data: {
      id: `jti-revoked-${RUN}`,
      scope: "instance",
      subjectId: idA,
      expiresAt: new Date(Date.now() + 60 * 60 * 1000),
      revokedAt: new Date(Date.now() - 60_000),
    },
  });
  await db.sessionRecord.create({
    data: {
      id: `jti-expired-${RUN}`,
      scope: "instance",
      subjectId: idA,
      expiresAt: new Date(Date.now() - 60_000),
    },
  });
  await db.sessionRecord.create({
    data: {
      id: `jti-b-live-${RUN}`,
      scope: "instance",
      subjectId: idB,
      expiresAt: new Date(Date.now() + 60 * 60 * 1000),
    },
  });

  /* audit trail linkage: workspace-actor rows for A (2) and B (1) */
  await audit.logAudit({ actorType: "instance", actorId: idA, actorName: "workspace", action: "instance.update", targetLabel: "A-row-1" });
  await audit.logAudit({ actorType: "instance", actorId: idA, actorName: "workspace", action: "instance.password", targetLabel: "A-row-2" });
  await audit.logAudit({ actorType: "instance", actorId: idB, actorName: "workspace", action: "instance.update", targetLabel: "B-row-1" });
});

afterAll(async () => {
  cookieJar.clear();
  try {
    await db.sessionRecord.deleteMany({ where: { subjectId: { in: [...createdInstanceIds, ...createdAdminIds] } } });
    await db.instance.deleteMany({ where: { id: { in: createdInstanceIds } } });
    await db.adminUser.deleteMany({ where: { id: { in: createdAdminIds } } });
  } catch {
    /* throwaway database — best-effort cleanup only */
  }
  /* drain the route's fire-and-safe background work (logAudit nudges the
   * backup scheduler; the audit writes settle) BEFORE disconnecting */
  await new Promise((resolve) => setTimeout(resolve, 600));
  await db.$disconnect();
});

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

/** Craft a real admin session cookie (token + registry row) into the jar.
 *  Each sign-in mints a FRESH jti — repeated sign-ins as the same admin
 *  never collide on the registry's unique id. */
let signInSeq = 0;
async function signInAs(adminId: string): Promise<void> {
  signInSeq += 1;
  const jti = `jti-admin-${RUN}-${signInSeq}`;
  const { token, expiresAt } = tokens.issueToken("admin", adminId, 60 * 60 * 1000, 0, jti);
  await sessions.recordSession({ scope: "admin", subjectId: adminId, jti, expiresAt });
  cookieJar.set(cookieNames.ADMIN_COOKIE_NAME, token);
}

function getOps(id: string): Promise<Response> {
  return opsRoute.GET(new Request(`http://${HOST}/api/admin/instances/${id}/ops`), {
    params: Promise.resolve({ id }),
  });
}

function postRevoke(id: string): Promise<Response> {
  return revokeRoute.POST(
    new Request(`http://${HOST}/api/admin/instances/${id}/sessions/revoke-all`, {
      method: "POST",
      headers: { "content-type": "application/json", host: HOST, origin: `http://${HOST}` },
      body: "{}",
    }),
    { params: Promise.resolve({ id }) }
  );
}

function getAudit(instanceId?: string, limit?: number): Promise<Response> {
  const search = new URLSearchParams();
  if (instanceId) search.set("instanceId", instanceId);
  if (limit) search.set("limit", String(limit));
  const qs = search.toString();
  return auditRoute.GET(new Request(`http://${HOST}/api/admin/audit${qs ? `?${qs}` : ""}`));
}

/* ------------------------------------------------------------------ */
/* 1 — GET /api/admin/instances/[id]/ops                               */
/* ------------------------------------------------------------------ */

describe("GET /api/admin/instances/[id]/ops — the strong telemetry drilldown", () => {
  test("unauthenticated → 401 (no existence oracle beyond the envelope)", async () => {
    cookieJar.clear();
    const res = await getOps(idA);
    expect(res.status).toBe(401);
    const body = (await res.json()) as { error?: string };
    expect(body.error).toBe("Authentication required");
  });

  test("non-super admin → 403 (super-only posture)", async () => {
    await signInAs(STAFF_ID);
    const res = await getOps(idA);
    expect(res.status).toBe(403);
    const body = (await res.json()) as { error?: string };
    expect(body.error).toBe("This action requires one of: super");
    cookieJar.clear();
  });

  test("super → 200 with the EXACT top-level envelope and ZERO PII keys", async () => {
    await signInAs(SUPER_ID);
    const res = await getOps(idA);
    expect(res.status).toBe(200);
    const body = (await res.json()) as Record<string, unknown>;
    /* the additive, documented envelope — ids/counts/ages ONLY */
    expect(Object.keys(body).sort()).toEqual([
      "audit",
      "generatedAt",
      "health",
      "instance",
      "shifts",
      "site",
      "store",
      "webhooks",
    ]);
    /* the redaction contract: no raw (or masked) email/phone anywhere */
    const serialized = JSON.stringify(body);
    expect(serialized).not.toContain("email");
    expect(serialized).not.toContain("phone");
    /* the drilldown itself wrote an admin.instanceOps audit row with the
     * meta.instance stamp — the filter test below relies on it */
    cookieJar.clear();
  });

  test("super → real aggregates (sessions, members, catalog, orders, revenue, site, webhooks, shifts, audit)", async () => {
    await signInAs(SUPER_ID);
    const res = await getOps(idA);
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      instance: { id: string; name: string; systemId: string; entitlement: { state: string } };
      health: { activeSessions: number; membersCount: number; modulesEnabled: number; lastActivityAt: string | null; storageUsedBytes: number };
      store: { moduleId: string | null; productsCount: number; lowStockCount: number; ordersCount: number; revenue: { currency: string; value: number } | null };
      site: { live: boolean; views: number; customersCount: number; inquiriesCount: number };
      webhooks: { activeEndpoints: number; failedDeliveries24h: number };
      shifts: { openCount: number; lastClosedAt: string | null };
      audit: { total: number };
    };

    expect(body.instance.id).toBe(idA);
    expect(body.instance.systemId).toBe("supermarket-grocery");
    expect(body.instance.name).toContain(RUN);
    /* no package + no trial clock (direct fixture) → platform-managed active */
    expect(body.instance.entitlement.state).toBe("active");

    /* 3 live sessions (revoked + expired rows never count) */
    expect(body.health.activeSessions).toBe(3);
    expect(body.health.membersCount).toBe(1);
    expect(body.health.modulesEnabled).toBe(1);
    expect(body.health.lastActivityAt).not.toBeNull();
    expect(body.health.storageUsedBytes).toBeGreaterThan(0);

    /* the supermarket's products catalog: 2 sellable rows, 1 low-stock */
    expect(body.store.moduleId).toBe("products");
    expect(body.store.productsCount).toBe(2);
    expect(body.store.lowStockCount).toBe(1);
    expect(body.store.ordersCount).toBe(1);
    /* completed revenue 15000 minor units → 150 major, org currency SAR */
    expect(body.store.revenue).toEqual({ currency: "SAR", value: 150 });

    expect(body.site.live).toBe(true);
    expect(body.site.views).toBe(42);
    expect(body.site.customersCount).toBe(1);

    /* 1 active endpoint (the inactive one never counts) · exactly the
     * 24h failed delivery (the 40-day-old one never counts) */
    expect(body.webhooks.activeEndpoints).toBe(1);
    expect(body.webhooks.failedDeliveries24h).toBe(1);

    expect(body.shifts.openCount).toBe(0);
    expect(body.shifts.lastClosedAt).not.toBeNull();

    /* A's audit linkage: 2 workspace rows + the drilldown rows above */
    expect(body.audit.total).toBeGreaterThanOrEqual(3);
    cookieJar.clear();
  });

  test("unknown instance id → 404", async () => {
    await signInAs(SUPER_ID);
    const res = await getOps("no-such-instance-id");
    expect(res.status).toBe(404);
    const body = (await res.json()) as { error?: string };
    expect(body.error).toBe("Instance not found");
    cookieJar.clear();
  });
});

/* ------------------------------------------------------------------ */
/* 2 — POST /api/admin/instances/[id]/sessions/revoke-all              */
/* ------------------------------------------------------------------ */

describe("POST /api/admin/instances/[id]/sessions/revoke-all — the strict lever", () => {
  test("unauthenticated → 401", async () => {
    cookieJar.clear();
    const res = await postRevoke(idA);
    expect(res.status).toBe(401);
  });

  test("non-super admin → 403 WITHOUT any mutation (sessions + epoch intact)", async () => {
    await signInAs(STAFF_ID);
    const before = await db.instance.findUnique({ where: { id: idA }, select: { sessionVersion: true } });
    const res = await postRevoke(idA);
    expect(res.status).toBe(403);
    const liveA = await db.sessionRecord.count({
      where: { scope: "instance", subjectId: idA, revokedAt: null, expiresAt: { gt: new Date() } },
    });
    expect(liveA).toBe(3);
    const after = await db.instance.findUnique({ where: { id: idA }, select: { sessionVersion: true } });
    expect(after?.sessionVersion).toBe(before?.sessionVersion ?? 0);
    cookieJar.clear();
  });

  test("super → 200 { revoked: 3 } · epoch BUMPED · exactly the live rows destroyed · tenant B untouched", async () => {
    await signInAs(SUPER_ID);
    const res = await postRevoke(idA);
    expect(res.status).toBe(200);
    const body = (await res.json()) as { revoked?: number };
    /* 3 live sessions for A — the pre-revoked + expired rows never count */
    expect(body.revoked).toBe(3);

    /* the epoch bumped: every outstanding token dies on its next request */
    const row = await db.instance.findUnique({ where: { id: idA }, select: { sessionVersion: true } });
    expect(row?.sessionVersion).toBe(1);

    /* every live A session is now stamped revoked */
    const stillLiveA = await db.sessionRecord.count({
      where: { scope: "instance", subjectId: idA, revokedAt: null, expiresAt: { gt: new Date() } },
    });
    expect(stillLiveA).toBe(0);

    /* tenant B's live session SURVIVED (the lever is scoped to ONE system) */
    const liveB = await db.sessionRecord.findUnique({ where: { id: `jti-b-live-${RUN}` } });
    expect(liveB?.revokedAt).toBeNull();

    /* the security audit row landed with the meta.instance stamp */
    const trailRow = await db.auditLog.findFirst({
      where: { action: "admin.instanceSessionsRevoke", actorId: SUPER_ID },
      orderBy: { createdAt: "desc" },
    });
    expect(trailRow).toBeTruthy();
    expect(trailRow?.metaJson).toContain(`"instance":"${idA}"`);
    expect(trailRow?.metaJson).toContain('"revoked":"3"');
    cookieJar.clear();
  });

  test("second run on a quiet workspace → { revoked: 0 } (idempotent, honest)", async () => {
    await signInAs(SUPER_ID);
    const res = await postRevoke(idA);
    expect(res.status).toBe(200);
    const body = (await res.json()) as { revoked?: number };
    expect(body.revoked).toBe(0);
    cookieJar.clear();
  });
});

/* ------------------------------------------------------------------ */
/* 3 — GET /api/admin/audit?instanceId=…                               */
/* ------------------------------------------------------------------ */

describe("GET /api/admin/audit?instanceId= — the per-instance filter", () => {
  test("unauthenticated → 401", async () => {
    cookieJar.clear();
    const res = await getAudit(idA);
    expect(res.status).toBe(401);
  });

  test("super · filter by instance A → ONLY A's rows (workspace-actor linkage)", async () => {
    await signInAs(SUPER_ID);
    const res = await getAudit(idA);
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      entries: { id: string; actorType: string; actorId: string | null; action: string; meta?: Record<string, string> }[];
      total: number;
    };
    expect(body.total).toBeGreaterThanOrEqual(2);
    expect(body.entries.length).toBeGreaterThanOrEqual(2);
    /* every row is linked to A — either by the workspace actor id or by
     * the ROUND 136 meta.instance stamp (the platform-actor rows) */
    for (const entry of body.entries) {
      const linked = entry.actorId === idA || entry.meta?.instance === idA;
      expect(linked).toBeTrue();
      expect(entry.actorId).not.toBe(idB);
    }
    /* B's row is NOT in A's window (partition proof — ids, not actions) */
    expect(JSON.stringify(body)).not.toContain(idB);
    cookieJar.clear();
  });

  test("super · filter by instance B → the B partition only", async () => {
    await signInAs(SUPER_ID);
    const res = await getAudit(idB, 100);
    expect(res.status).toBe(200);
    const body = (await res.json()) as { entries: { actorId: string | null }[]; total: number };
    expect(body.total).toBe(1);
    expect(body.entries).toHaveLength(1);
    expect(body.entries[0]?.actorId).toBe(idB);
    cookieJar.clear();
  });

  test("super · the meta.instance-stamped platform rows (admin.instanceOps) join the filtered trail", async () => {
    await signInAs(SUPER_ID);
    /* fire a fresh drilldown (writes an admin.instanceOps row stamped for A) */
    const ops = await getOps(idA);
    expect(ops.status).toBe(200);
    const res = await getAudit(idA, 100);
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      entries: { action: string; actorId: string | null; meta?: Record<string, string> }[];
    };
    const stamped = body.entries.find((e) => e.action === "admin.instanceOps");
    expect(stamped).toBeTruthy();
    expect(stamped?.actorId).toBe(SUPER_ID);
    expect(stamped?.meta?.instance).toBe(idA);
    cookieJar.clear();
  });

  test("super · no filter → the unfiltered trail still lists every actor", async () => {
    await signInAs(SUPER_ID);
    const res = await getAudit(undefined, 100);
    expect(res.status).toBe(200);
    const body = (await res.json()) as { entries: { actorId: string | null }[]; total: number };
    const actorIds = new Set(body.entries.map((e) => e.actorId));
    expect(actorIds.has(idA)).toBeTrue();
    expect(actorIds.has(idB)).toBeTrue();
    cookieJar.clear();
  });
});
