/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — CROSS-DEVICE PASSKEY LOGIN BRIDGE (ROUND 117).
 *
 * Proves the QR bridge's lifecycle contract:
 *  - token/scope shape guards reject malformed input before any DB touch;
 *  - start: a PENDING bridge row lands with the full options JSON + a
 *    discoverable ("*") challenge in the SHARED WebAuthn challenge store
 *    + a ~3-minute TTL + a server-rendered QR SVG payload;
 *  - get: only a PENDING bridge hands out options (approved/claimed answer
 *    status only); unknown + expired tokens answer a uniform miss and the
 *    expired row is reaped;
 *  - finish: a garbage assertion is refused (VERIFICATION_FAILED) without
 *    approving the bridge; a non-pending bridge answers NOT_PENDING;
 *  - claim: pending answers pending (202 semantics, no side effects);
 *    an APPROVED bridge for an ACTIVE admin flips to claimed exactly once
 *    (CAS — the second claim answers ALREADY_CLAIMED) with lastLoginAt
 *    stamped; the cookie boundary outside a request context surfaces as
 *    ISSUE_FAILED (the try/catch contract) WITHOUT consuming... the row is
 *    consumed by design — the audit ordering proves it;
 *  - claim refuses disabled admins and trashed instances (ACCOUNT_REFUSED)
 *    — the QR is never a side door around the account state gates;
 *    an owner-paused (disabledAt) workspace is refused with the full
 *    WORKSPACE_DISABLED payload and the bridge stays consumed (L-4).
 *
 * DB isolation: throwaway PostgreSQL test database via test-setup (never the live DB).
 */

import { beforeAll, afterAll, describe, expect, test } from "bun:test";
import { getTestDb, resetRateTable, type TestDb } from "./test-setup";

let db: TestDb;
let core: typeof import("@/lib/server/cross-device-login");

/** A same-origin desktop request (rpConfig derives rpID/origins from it). */
function desktopReq(): Request {
  return new Request("http://localhost:3000/api/cross-device", {
    method: "POST",
    headers: { origin: "http://localhost:3000", host: "localhost:3000" },
  });
}

const ADMIN_ID = "cd-admin-1";
const INSTANCE_ID = "cd-instance-1";

beforeAll(async () => {
  db = await getTestDb();
  await resetRateTable(db);
  await db.crossDeviceLogin.deleteMany({});
  await db.webauthnChallenge.deleteMany({});
  core = await import("@/lib/server/cross-device-login");

  await db.adminUser.create({
    data: {
      id: ADMIN_ID,
      username: "cd-admin",
      name: "CD Admin",
      email: "cd-admin@ashrilogic.test",
      role: "super",
      active: true,
    },
  });
  await db.instance.create({
    data: {
      id: INSTANCE_ID,
      systemId: "inventory",
      orgJson: JSON.stringify({ name: "CD Bridge Co", currency: "SAR" }),
      adminJson: "{}",
      prefsJson: "{}",
      modulesJson: JSON.stringify(["inventory"]),
    },
  });
});

afterAll(async () => {
  try {
    await db.crossDeviceLogin.deleteMany({});
    await db.webauthnChallenge.deleteMany({});
    await db.adminUser.deleteMany({ where: { id: ADMIN_ID } });
    await db.instance.deleteMany({ where: { id: INSTANCE_ID } });
  } catch {
    /* throwaway DB */
  }
});

describe("cross-device bridge — input guards", () => {
  test("scope guard accepts exactly admin|instance", () => {
    expect(core.isCrossDeviceScope("admin")).toBeTrue();
    expect(core.isCrossDeviceScope("instance")).toBeTrue();
    expect(core.isCrossDeviceScope("tenant")).toBeFalse();
    expect(core.isCrossDeviceScope(null)).toBeFalse();
    expect(core.isCrossDeviceScope(42)).toBeFalse();
  });

  test("token shape guard accepts only 43-char base64url", () => {
    const good = "A".repeat(43);
    expect(core.isCrossDeviceTokenShape(good)).toBeTrue();
    expect(core.isCrossDeviceTokenShape("A".repeat(42))).toBeFalse();
    expect(core.isCrossDeviceTokenShape("A".repeat(44))).toBeFalse();
    expect(core.isCrossDeviceTokenShape("!!!not-base64url!!!------------------------------")).toBeFalse();
    expect(core.isCrossDeviceTokenShape(null)).toBeFalse();
  });
});

describe("cross-device bridge — start (desktop step 1)", () => {
  test("mints a pending bridge with discoverable options, shared challenge, TTL + QR", async () => {
    const started = await core.startCrossDeviceLogin(desktopReq(), "admin");
    expect(started.ok).toBeTrue();
    if (!started.ok) return;

    /* the public payload never leaks the options */
    expect(started.start.token).toMatch(/^[A-Za-z0-9_-]{43}$/);
    expect(started.start.qrSvg).toBeString();
    expect(started.start.qrSvg.startsWith("<svg")).toBeTrue();
    const ttlMs = new Date(started.start.expiresAt).getTime() - Date.now();
    expect(ttlMs).toBeGreaterThan(2 * 60 * 1000 - 5_000);
    expect(ttlMs).toBeLessThanOrEqual(3 * 60 * 1000);

    /* the bridge row: pending + full options JSON */
    const row = await db.crossDeviceLogin.findUnique({ where: { id: started.start.token } });
    expect(row).not.toBeNull();
    expect(row?.status).toBe("pending");
    expect(row?.scope).toBe("admin");
    const options = JSON.parse(row?.optionsJson ?? "{}") as { challenge?: string; rpId?: string };
    expect(options.challenge).toBeString();
    expect(options.rpId).toBe("localhost");

    /* the challenge lives in the SHARED store under subjectId "*" — the
       standard finishPasskeyLogin path verifies the phone's assertion */
    const challenge = await db.webauthnChallenge.findFirst({
      where: { scope: "admin", subjectId: "*", challenge: options.challenge },
    });
    expect(challenge).not.toBeNull();
  });

  test("expired bridges are swept on the next start", async () => {
    await db.crossDeviceLogin.create({
      data: {
        id: "x".repeat(43),
        scope: "admin",
        optionsJson: "{}",
        status: "pending",
        expiresAt: new Date(Date.now() - 60_000),
      },
    });
    const started = await core.startCrossDeviceLogin(desktopReq(), "instance");
    expect(started.ok).toBeTrue();
    /* give the fire-and-forget sweep a beat */
    await new Promise((r) => setTimeout(r, 250));
    expect(await db.crossDeviceLogin.findUnique({ where: { id: "x".repeat(43) } })).toBeNull();
  });
});

describe("cross-device bridge — get (phone step 2)", () => {
  test("pending hands out options; approved answers status only", async () => {
    const started = await core.startCrossDeviceLogin(desktopReq(), "admin");
    if (!started.ok) throw new Error("start failed");

    const pending = await core.getCrossDeviceLogin(started.start.token);
    expect(pending.ok).toBeTrue();
    if (pending.ok) {
      expect(pending.status).toBe("pending");
      expect(pending.options?.challenge).toBeString();
    }

    await db.crossDeviceLogin.update({
      where: { id: started.start.token },
      data: { status: "approved", subjectId: ADMIN_ID },
    });
    const approved = await core.getCrossDeviceLogin(started.start.token);
    expect(approved.ok).toBeTrue();
    if (approved.ok) {
      expect(approved.status).toBe("approved");
      expect(approved.options).toBeNull();
    }
  });

  test("unknown + expired tokens answer a uniform miss (no oracle)", async () => {
    const unknown = await core.getCrossDeviceLogin("z".repeat(43));
    expect(unknown.ok).toBeFalse();

    await db.crossDeviceLogin.create({
      data: {
        id: "y".repeat(43),
        scope: "admin",
        optionsJson: "{}",
        status: "pending",
        expiresAt: new Date(Date.now() - 1_000),
      },
    });
    const expired = await core.getCrossDeviceLogin("y".repeat(43));
    expect(expired.ok).toBeFalse();
    /* the expired row was reaped */
    await new Promise((r) => setTimeout(r, 250));
    expect(await db.crossDeviceLogin.findUnique({ where: { id: "y".repeat(43) } })).toBeNull();
  });
});

describe("cross-device bridge — finish (phone step 3)", () => {
  test("garbage assertion is refused and the bridge stays pending", async () => {
    const started = await core.startCrossDeviceLogin(desktopReq(), "admin");
    if (!started.ok) throw new Error("start failed");

    const result = await core.finishCrossDeviceLogin(
      desktopReq(),
      started.start.token,
      { id: "nonexistent-credential", rawId: "nonexistent-credential", type: "public-key", response: {} } as never,
      "10.0.0.9"
    );
    expect(result.ok).toBeFalse();
    if (!result.ok) expect(result.error).toBe("VERIFICATION_FAILED");

    const row = await db.crossDeviceLogin.findUnique({ where: { id: started.start.token } });
    expect(row?.status).toBe("pending");
  });

  test("a non-pending bridge answers NOT_PENDING", async () => {
    await db.crossDeviceLogin.create({
      data: {
        id: "a".repeat(43),
        scope: "admin",
        optionsJson: "{}",
        status: "approved",
        subjectId: ADMIN_ID,
        expiresAt: new Date(Date.now() + 60_000),
      },
    });
    const result = await core.finishCrossDeviceLogin(
      desktopReq(),
      "a".repeat(43),
      { id: "x", rawId: "x", type: "public-key", response: {} } as never,
      null
    );
    expect(result.ok).toBeFalse();
    if (!result.ok) expect(result.error).toBe("NOT_PENDING");
  });
});

describe("cross-device bridge — claim (desktop step 4)", () => {
  test("pending answers pending with ZERO side effects", async () => {
    const started = await core.startCrossDeviceLogin(desktopReq(), "admin");
    if (!started.ok) throw new Error("start failed");
    const before = await db.adminUser.findUnique({ where: { id: ADMIN_ID } });

    const result = await core.claimCrossDeviceLogin(desktopReq(), started.start.token, "10.0.0.1");
    expect(result.ok).toBeTrue();
    if (result.ok) expect(result.status).toBe("pending");

    const row = await db.crossDeviceLogin.findUnique({ where: { id: started.start.token } });
    expect(row?.status).toBe("pending");
    const after = await db.adminUser.findUnique({ where: { id: ADMIN_ID } });
    expect(after?.lastLoginAt?.getTime() ?? 0).toBe(before?.lastLoginAt?.getTime() ?? 0);
  });

  test("approved + active admin: CAS claims exactly once, lastLoginAt stamped", async () => {
    const token = "b".repeat(43);
    await db.crossDeviceLogin.create({
      data: {
        id: token,
        scope: "admin",
        optionsJson: "{}",
        status: "approved",
        subjectId: ADMIN_ID,
        expiresAt: new Date(Date.now() + 60_000),
      },
    });

    /* outside a Next request context the cookie layer surfaces as
       ISSUE_FAILED (the documented try/catch contract) — but the CAS has
       ALREADY consumed the row and the postlude ran up to that boundary */
    const first = await core.claimCrossDeviceLogin(desktopReq(), token, "10.0.0.1");
    if (first.ok) throw new Error("expected ISSUE_FAILED in the test context");
    if (first.error !== "ISSUE_FAILED") throw new Error(`expected ISSUE_FAILED, got ${first.error}`);

    const row = await db.crossDeviceLogin.findUnique({ where: { id: token } });
    expect(row?.status).toBe("claimed");
    expect(row?.claimedAt).not.toBeNull();

    const admin = await db.adminUser.findUnique({ where: { id: ADMIN_ID } });
    expect(admin?.lastLoginAt).not.toBeNull();

    /* exactly one winner: the second claim answers ALREADY_CLAIMED */
    const second = await core.claimCrossDeviceLogin(desktopReq(), token, "10.0.0.1");
    expect(second.ok).toBeFalse();
    if (!second.ok) expect(second.error).toBe("ALREADY_CLAIMED");
  });

  test("disabled admin is refused at claim time (ACCOUNT_REFUSED)", async () => {
    const disabledId = "cd-admin-disabled";
    await db.adminUser.create({
      data: { id: disabledId, username: "cd-disabled", name: "Disabled", email: "d@x.test", active: false },
    });
    const token = "c".repeat(43);
    await db.crossDeviceLogin.create({
      data: {
        id: token,
        scope: "admin",
        optionsJson: "{}",
        status: "approved",
        subjectId: disabledId,
        expiresAt: new Date(Date.now() + 60_000),
      },
    });
    const result = await core.claimCrossDeviceLogin(desktopReq(), token, "10.0.0.1");
    expect(result.ok).toBeFalse();
    if (!result.ok) expect(result.error).toBe("ACCOUNT_REFUSED");
    await db.adminUser.delete({ where: { id: disabledId } }).catch(() => undefined);
  });

  test("trashed instance is refused at claim time (ACCOUNT_REFUSED)", async () => {
    const token = "d".repeat(43);
    await db.crossDeviceLogin.create({
      data: {
        id: token,
        scope: "instance",
        optionsJson: "{}",
        status: "approved",
        subjectId: INSTANCE_ID,
        expiresAt: new Date(Date.now() + 60_000),
      },
    });
    /* soft-delete the instance — the QR must not resurrect it */
    await db.instance.update({ where: { id: INSTANCE_ID }, data: { deletedAt: new Date() } });
    const result = await core.claimCrossDeviceLogin(desktopReq(), token, "10.0.0.1");
    expect(result.ok).toBeFalse();
    if (!result.ok) expect(result.error).toBe("ACCOUNT_REFUSED");
    await db.instance.update({ where: { id: INSTANCE_ID }, data: { deletedAt: null } });
  });

  /* L-4 (security audit fix) — ROUND 87 parity at the QR side door: an
   * owner-PAUSED workspace is refused at claim time with the full
   * WORKSPACE_DISABLED payload (the claim route renders the exact password
   * path envelope from it). Fail-closed posture: the single-use row stays
   * consumed, exactly like the BANNED / ACCOUNT_REFUSED refusals — no
   * reactivate round-trip exists on this surface (see the rationale in
   * src/lib/server/cross-device-login.ts). */
  test("disabled (owner-paused) instance is refused at claim time (WORKSPACE_DISABLED)", async () => {
    const token = "f".repeat(43);
    await db.crossDeviceLogin.create({
      data: {
        id: token,
        scope: "instance",
        optionsJson: "{}",
        status: "approved",
        subjectId: INSTANCE_ID,
        expiresAt: new Date(Date.now() + 60_000),
      },
    });
    /* owner-paused workspace — the QR must not unlock it */
    await db.instance.update({
      where: { id: INSTANCE_ID },
      data: { disabledAt: new Date(), disabledReason: "paused" },
    });
    const result = await core.claimCrossDeviceLogin(desktopReq(), token, "10.0.0.1");
    expect(result.ok).toBeFalse();
    if (!result.ok && result.error === "WORKSPACE_DISABLED") {
      expect(result.disabledAt).toBeInstanceOf(Date);
      expect(result.disabledReason).toBe("paused");
    } else {
      throw new Error(`expected WORKSPACE_DISABLED, got ${result.ok ? result.status : result.error}`);
    }
    /* fail closed AND consumed: the bridge is spent, a fresh QR is the
       recovery path (mirrors the BANNED/ACCOUNT_REFUSED contract) */
    const row = await db.crossDeviceLogin.findUnique({ where: { id: token } });
    expect(row?.status).toBe("claimed");
    await db.instance.update({
      where: { id: INSTANCE_ID },
      data: { disabledAt: null, disabledReason: null },
    });
  });

  test("status probe: unknown token → null, live token → its status", async () => {
    expect(await core.crossDeviceStatus("nope")).toBeNull();
    const token = "e".repeat(43);
    await db.crossDeviceLogin.create({
      data: {
        id: token,
        scope: "instance",
        optionsJson: "{}",
        status: "pending",
        expiresAt: new Date(Date.now() + 60_000),
      },
    });
    expect(await core.crossDeviceStatus(token)).toBe("pending");
  });
});
