/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 187: mail settings reject header-hostile
 * bytes at the boundary.
 *
 * `fromName` and `replyTo` previously accepted any trimmed string — both
 * flow into SMTP headers verbatim (`from: "Name <addr>"`, `replyTo`).
 * Nodemailer mime-encodes display names (CRLF neutralized downstream),
 * but the store should never carry header-hostile bytes, and `replyTo`
 * had no email-shape check at all.
 *
 * The schema now rejects control characters (CRLF/header shaping) on both
 * fields and requires an email shape for a non-empty replyTo (empty
 * string stays legal — it clears the header).
 */
import { describe, beforeAll, test, expect } from "bun:test";
import { ensureDemoEnv } from "./test-setup";

ensureDemoEnv();

describe("ROUND 187 — mail settings boundary validation", () => {
  let schema: typeof import("@/app/api/admin/mail/route")["mailSettingsUpdateSchema"];

  beforeAll(async () => {
    ({ mailSettingsUpdateSchema: schema } = await import("@/app/api/admin/mail/route"));
  });

  test("fromName — clean display names accepted", () => {
    expect(schema.safeParse({ fromName: "Ashrilogic Team" }).success).toBe(true);
    expect(schema.safeParse({ fromName: "نور الدين عثمان" }).success).toBe(true);
    expect(schema.safeParse({ fromName: "" }).success).toBe(true);
    expect(schema.safeParse({}).success).toBe(true);
  });

  test("fromName — CRLF / control characters refused", () => {
    expect(schema.safeParse({ fromName: "Team\r\nBcc: victim@x.io" }).success).toBe(false);
    expect(schema.safeParse({ fromName: "Team\nSubject: x" }).success).toBe(false);
    expect(schema.safeParse({ fromName: "Tab\tName" }).success).toBe(false);
    expect(schema.safeParse({ fromName: "Bad\u0000Name" }).success).toBe(false);
    expect(schema.safeParse({ fromName: "Del\u007fete" }).success).toBe(false);
  });

  test("replyTo — empty clears, valid email accepted, garbage refused", () => {
    expect(schema.safeParse({ replyTo: "" }).success).toBe(true);
    expect(schema.safeParse({ replyTo: "support@ashrilogic.com" }).success).toBe(true);
    expect(schema.safeParse({}).success).toBe(true);
    expect(schema.safeParse({ replyTo: "not-an-email" }).success).toBe(false);
    expect(schema.safeParse({ replyTo: "a@b@c" }).success).toBe(false);
    expect(schema.safeParse({ replyTo: "support@ashrilogic.com\r\nBcc: x@y.io" }).success).toBe(false);
    expect(schema.safeParse({ replyTo: " support@ashrilogic.com " }).success).toBe(true);
  });

  test("the other fields keep their historical contract (regression net)", () => {
    expect(schema.safeParse({ port: 0 }).success).toBe(false);
    expect(schema.safeParse({ port: 65_536 }).success).toBe(false);
    expect(schema.safeParse({ port: 587 }).success).toBe(true);
    expect(schema.safeParse({ fromEmail: "not-an-email" }).success).toBe(false);
    expect(schema.safeParse({ fromEmail: "billing@ashrilogic.com" }).success).toBe(true);
    expect(schema.safeParse({ timeoutMs: 1_000 }).success).toBe(false);
    expect(schema.safeParse({ timeoutMs: 5_000 }).success).toBe(true);
  });
});
