/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 126 (LIVE): the migrated store routes —
 * byte-level HTTP compatibility proof for the third route→controller→
 * service→repository decomposition (the public storefront surface).
 *
 * Everything the legacy inline handlers guaranteed must hold EXACTLY
 * through the new delegation chain:
 *   - GET  /api/sites/[id]/store        → 200, products + facets; 404
 *                                         "Store not available" for unknown
 *                                         ids; ?q=/?category= server-side
 *   - POST /api/sites/[id]/store/coupon → the legacy verdict mapping
 *                                         (404 NOTFOUND / 409 codes), the
 *                                         full success shape, "Invalid
 *                                         coupon request" 400, bounded
 *                                         reader envelopes, origin guard
 *                                         FIRST (403 cross-origin)
 *   - GET  /api/sites/[id]/store/reviews → 400 recordId required, 400
 *                                         BAD_CURSOR, 200 page+summary
 *   - POST /api/sites/[id]/store/reviews → 201 create / 200 update (the
 *                                         blind-index upsert), "Invalid
 *                                         review" 400
 *   - NEW capability (additive, asserted): x-request-id on every response
 *
 * This suite runs in the battery's LIVE phase (fresh dev server) — it is
 * on the BUILTIN_LIVE list, so an unreachable server is INCONCLUSIVE,
 * never a phantom PASS.
 */
import { describe, test, expect, beforeAll, afterAll } from "bun:test";
import { ensureDemoEnv, resolveServerDatabaseUrl } from "./test-setup";
import { PrismaClient } from "@prisma/client";

ensureDemoEnv();

const BASE = "http://localhost:3000";
const RUN = Math.random().toString(36).slice(2, 8);
const XFF_IP = `198.18.${(RUN.charCodeAt(2) % 200) + 10}.${(RUN.charCodeAt(3) % 200) + 10}`;
const JSON_HEADERS: Record<string, string> = {
  "content-type": "application/json",
  origin: BASE,
  referer: `${BASE}/`,
};

/* the DEV SERVER's PostgreSQL database (was file:db/custom.db) — resolved
 * lazily so a skipped run (server down) never needs it; see
 * test-setup.resolveServerDatabaseUrl() */
let serverDb: PrismaClient | null = null;
function db(): PrismaClient {
  serverDb ??= new PrismaClient({ datasourceUrl: resolveServerDatabaseUrl() });
  return serverDb;
}

/** The demo storefront host — DISCOVERED, never hard-coded: a PUBLISHED
 *  site on a live (non-trashed, unexpired-trial or active-plan) workspace
 *  whose catalog module is pharmacy. Survives demo-db re-seeds. */
let STORE_HOST = "";

async function jfetch(path: string, method: string, body?: string, extra?: Record<string, string>): Promise<Response> {
  return fetch(`${BASE}${path}`, {
    method,
    headers: {
      "content-type": "application/json",
      "x-forwarded-for": XFF_IP,
      ...(method === "GET" ? {} : JSON_HEADERS),
      ...extra,
    },
    body,
    signal: AbortSignal.timeout(20_000),
  });
}

/* 20s per live test — cold Turbopack compilation of a route chain on the
 * battery's FRESH server can exceed bun's 5s default (ROUND 124); this
 * matches the 20s jfetch abort budget + compile margin, mirroring the
 * other live suites. */
function liveTest(name: string, fn: () => Promise<void>): void {
  test(name, fn, 25_000);
}

describe("ROUND 126 — store routes (live, migrated to the domain)", () => {
  /* the run's coupon (created in the demo db, removed in afterAll) */
  const couponCode = `LIVE${RUN.slice(0, 4).toUpperCase()}BR`;
  let couponId = "";
  let recordId = "";
  let reviewId = "";

  beforeAll(async () => {
    const probe = await fetch(`${BASE}/api/status`, { signal: AbortSignal.timeout(10_000) });
    expect(probe.ok).toBe(true);

    /* discover the live published pharmacy storefront host */
    const candidates = await db().site.findMany({
      where: { published: true, instance: { deletedAt: null } },
      select: { instanceId: true, instance: { select: { modulesJson: true, trialEndsAt: true, packageId: true } } },
      take: 40,
    });
    const host = candidates.find((s) => {
      if (!s.instance.modulesJson.includes("pharmacy")) return false;
      const trialEnd = s.instance.trialEndsAt;
      const live = s.instance.packageId != null || (trialEnd != null && trialEnd.getTime() > Date.now());
      return live;
    });
    expect(host, "no published live pharmacy storefront in the demo db — re-seed it").toBeTruthy();
    STORE_HOST = host!.instanceId;

    /* mint this run's percent coupon on the discovered host */
    const coupon = await db().storeCoupon.create({
      data: { instanceId: STORE_HOST, code: couponCode, kind: "percent", value: 10, active: true },
    });
    couponId = coupon.id;
  });

  afterAll(async () => {
    if (couponId) {
      await db().storeCoupon.deleteMany({ where: { id: couponId } }).catch(() => undefined);
    }
    if (reviewId) {
      await db().siteReview.deleteMany({ where: { id: reviewId } }).catch(() => undefined);
    }
    await serverDb?.$disconnect();
  });

  liveTest("public catalog: 200 with products, categories, counts + x-request-id", async () => {
    const res = await jfetch(`/api/sites/${STORE_HOST}/store`, "GET");
    expect(res.status).toBe(200);
    expect(res.headers.get("x-request-id")).toBeTruthy();
    const catalog = (await res.json()) as {
      available: boolean;
      moduleId: string | null;
      currency: string;
      products: { recordId: string; name: string; category: string; price: number }[];
      categories: string[];
      categoryCounts: Record<string, number>;
    };
    expect(catalog.available).toBe(true);
    expect(catalog.moduleId).toBe("pharmacy");
    expect(catalog.products.length).toBeGreaterThan(0);
    expect(catalog.categories.length).toBeGreaterThan(0);
    /* the facet counts sum to the unfiltered catalog size (every counted
     * row is a served product — never more, never fewer) */
    const counted = Object.values(catalog.categoryCounts).reduce((a, b) => a + b, 0);
    expect(counted).toBeLessThanOrEqual(catalog.products.length);
    expect(counted).toBeGreaterThan(0);
    recordId = catalog.products[0]!.recordId;
  });

  liveTest("server-side filters: ?category= narrows; counts stay unfiltered", async () => {
    const all = (await (await jfetch(`/api/sites/${STORE_HOST}/store`, "GET")).json()) as {
      products: { category: string }[];
      categories: string[];
    };
    const cat = all.categories[0]!;
    const res = await jfetch(`/api/sites/${STORE_HOST}/store?category=${encodeURIComponent(cat)}`, "GET");
    const filtered = (await res.json()) as { products: { category: string }[] };
    expect(res.status).toBe(200);
    expect(filtered.products.length).toBeLessThanOrEqual(all.products.length);
    expect(filtered.products.every((p) => p.category === cat)).toBe(true);
  });

  liveTest("unknown instance → the exact legacy 404 envelope", async () => {
    const res = await jfetch(`/api/sites/nonexistent-${RUN}/store`, "GET");
    expect(res.status).toBe(404);
    expect(((await res.json()) as { error?: string }).error).toBe("Store not available");
  });

  liveTest("coupon: the full success shape through the domain chain", async () => {
    const res = await jfetch(
      `/api/sites/${STORE_HOST}/store/coupon`,
      "POST",
      JSON.stringify({ code: couponCode, subtotal: 5_000 })
    );
    expect(res.status).toBe(200);
    expect(res.headers.get("x-request-id")).toBeTruthy();
    const verdict = (await res.json()) as {
      code: string;
      kind: string;
      value: number;
      discountMinor: number;
      minSubtotal: number | null;
    };
    expect(verdict.code).toBe(couponCode);
    expect(verdict.kind).toBe("percent");
    expect(verdict.value).toBe(10);
    expect(verdict.discountMinor).toBe(500);
    expect(verdict.minSubtotal).toBeNull();
  });

  liveTest("coupon: unknown code → 404 Coupon not applicable + NOTFOUND code", async () => {
    const res = await jfetch(
      `/api/sites/${STORE_HOST}/store/coupon`,
      "POST",
      JSON.stringify({ code: "DOES-NOT-EXIST", subtotal: 5_000 })
    );
    expect(res.status).toBe(404);
    const body = (await res.json()) as { error?: string; code?: string };
    expect(body.error).toBe("Coupon not applicable");
    expect(body.code).toBe("NOTFOUND");
  });

  liveTest("coupon: invalid payload → the legacy custom 400 (NOT zodError)", async () => {
    const res = await jfetch(
      `/api/sites/${STORE_HOST}/store/coupon`,
      "POST",
      JSON.stringify({ code: "x" })
    );
    expect(res.status).toBe(400);
    expect(((await res.json()) as { error?: string }).error).toBe("Invalid coupon request");
  });

  liveTest("coupon: malformed JSON → 400 'Invalid JSON body' (bounded reader preserved)", async () => {
    const res = await jfetch(`/api/sites/${STORE_HOST}/store/coupon`, "POST", "{not json");
    expect(res.status).toBe(400);
    expect(((await res.json()) as { error?: string }).error).toBe("Invalid JSON body");
  });

  liveTest("coupon: cross-origin mutation → 403 BEFORE any body parse (guard order preserved)", async () => {
    const res = await jfetch(
      `/api/sites/${STORE_HOST}/store/coupon`,
      "POST",
      JSON.stringify({ code: couponCode, subtotal: 1 }),
      { origin: "https://evil.example" }
    );
    expect(res.status).toBe(403);
    expect(((await res.json()) as { error?: string }).error).toBe("Cross-origin request rejected");
  });

  liveTest("reviews: missing recordId → the exact 400", async () => {
    const res = await jfetch(`/api/sites/${STORE_HOST}/store/reviews`, "GET");
    expect(res.status).toBe(400);
    expect(((await res.json()) as { error?: string }).error).toBe("A product (recordId) is required");
  });

  liveTest("reviews: a real product's page — 200 {reviews, nextCursor, summary}", async () => {
    const res = await jfetch(`/api/sites/${STORE_HOST}/store/reviews?recordId=${recordId}`, "GET");
    expect(res.status).toBe(200);
    expect(res.headers.get("x-request-id")).toBeTruthy();
    const page = (await res.json()) as {
      reviews: { id: string; rating: number; name: string }[];
      nextCursor: string | null;
      summary: { avg: number | null; count: number; dist: number[] };
    };
    expect(Array.isArray(page.reviews)).toBe(true);
    expect(page.summary.dist).toHaveLength(5);
  });

  liveTest("reviews: malformed cursor → loud 400 BAD_CURSOR (never page one)", async () => {
    const res = await jfetch(
      `/api/sites/${STORE_HOST}/store/reviews?recordId=${recordId}&cursor=${encodeURIComponent("!!!garbage!!!")}`,
      "GET"
    );
    expect(res.status).toBe(400);
    const body = (await res.json()) as { error?: string; code?: string };
    expect(body.error).toBe("Invalid pagination cursor");
    expect(body.code).toBe("BAD_CURSOR");
  });

  liveTest("reviews: guest submit → 201 create; same-source re-submit → 200 update", async () => {
    const name = `QA Guest ${RUN}`;
    const first = await jfetch(
      `/api/sites/${STORE_HOST}/store/reviews`,
      "POST",
      JSON.stringify({ recordId, rating: 5, name, body: "تجربة حية" })
    );
    expect(first.status).toBe(201);
    const created = (await first.json()) as { review: { id: string; rating: number }; updated: boolean };
    expect(created.updated).toBe(false);
    expect(created.review.rating).toBe(5);
    reviewId = created.review.id;

    /* same source IP + same product → the upsert path */
    const second = await jfetch(
      `/api/sites/${STORE_HOST}/store/reviews`,
      "POST",
      JSON.stringify({ recordId, rating: 4, name, body: "تحديث" })
    );
    expect(second.status).toBe(200);
    const updated = (await second.json()) as { review: { id: string; rating: number }; updated: boolean };
    expect(updated.updated).toBe(true);
    expect(updated.review.id).toBe(reviewId);
    expect(updated.review.rating).toBe(4);
  });

  liveTest("reviews: invalid payload → the legacy custom 400 (NOT zodError)", async () => {
    const res = await jfetch(
      `/api/sites/${STORE_HOST}/store/reviews`,
      "POST",
      JSON.stringify({ recordId, rating: 0, name: "x" })
    );
    expect(res.status).toBe(400);
    expect(((await res.json()) as { error?: string }).error).toBe("Invalid review");
  });
});
