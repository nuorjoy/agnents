/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — KEY-ROTATION RE-SEAL RUNBOOK (ROUND 96).
 *
 * End-to-end subprocess test of scripts/re-seal-secrets.ts against a
 * DEDICATED throwaway PostgreSQL fixture database (ashrilogic_reseal_test,
 * derived from TEST_DATABASE_URL's server — never the live dev database,
 * never the shared security-test database):
 *
 *  - seed every sealed-field family (direct columns, nested-JSON envelopes,
 *    blind indexes, a chained audit trail) under the DEMO key;
 *  - run the script with OLD=demo, NEW=<test key> → exit 0;
 *  - verify INDEPENDENTLY (local HKDF + AES-GCM, not the script's own
 *    self-report): every envelope opens with the NEW key and decrypts to
 *    the exact seeded plaintext; every blind index matches its recomputed
 *    value; the audit chain links + hash coverage hold under the NEW key;
 *  - the wrong-old-key runbook aborts with exit 1 (nothing changed);
 *  - a second run with the same keys is a NO-OP resume (everything already
 *    new-key — zero re-seals, zero failures);
 *  - the script's pre-reseal platform snapshot (pg_dump, the PG-native
 *    rollback artifact) lands in a throwaway storage root, never the real
 *    storage/ tree.
 */
import { afterAll, beforeAll, describe, expect, test } from "bun:test";
import { execSync } from "node:child_process";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createDecipheriv, createHmac, hkdfSync } from "node:crypto";
import type { PrismaClient } from "@prisma/client";
import { ensureDemoEnv, REPO_ROOT, TEST_DATABASE_URL } from "./test-setup";

ensureDemoEnv();

/** the dedicated fixture database on the TEST server — same host/port/
 *  credentials as TEST_DATABASE_URL, database name swapped. */
const RESEAL_DB_NAME = "ashrilogic_reseal_test";
const FIXTURE_URL = (() => {
  const url = new URL(TEST_DATABASE_URL);
  url.pathname = `/${RESEAL_DB_NAME}`;
  return url.toString();
})();
/** throwaway storage root for the script's pre-reseal platform snapshots
 *  (the old run wrote db/pre-reseal-*.db files; the PG-native script takes
 *  a pg_dump snapshot under ASHRILOGIC_STORAGE_DIR instead). */
const FIXTURE_STORAGE = mkdtempSync(join(tmpdir(), "ashrilogic-reseal-storage-"));
/** the demo key crypto-vault falls back to in tests (min 16 chars) */
const DEMO_KEY = "ashrilogic-demo-field-encryption-key-rotate-me";
const NEW_KEY = "test-rotation-new-key-material-32ch!!";

/* local new-key crypto — independent of the script's implementation */
const NEW_AES = Buffer.from(
  hkdfSync("sha256", Buffer.from(NEW_KEY, "utf8"), Buffer.alloc(0), "ashrilogic/field-aes-256-gcm/v1", 32)
);
const NEW_INDEX = Buffer.from(
  hkdfSync("sha256", Buffer.from(NEW_KEY, "utf8"), Buffer.alloc(0), "ashrilogic/blind-index-hmac/v1", 32)
);
const NEW_CHAIN = Buffer.from(
  hkdfSync("sha256", Buffer.from(NEW_KEY, "utf8"), Buffer.alloc(0), "ashrilogic/audit-chain-hmac/v1", 32)
);

function newDecrypt(envelope: string): string {
  const parts = envelope.slice("enc:v1:".length).split(":");
  const decipher = createDecipheriv("aes-256-gcm", NEW_AES, Buffer.from(parts[0], "base64"));
  decipher.setAuthTag(Buffer.from(parts[1], "base64"));
  return Buffer.concat([decipher.update(Buffer.from(parts[2], "base64")), decipher.final()]).toString("utf8");
}
function newBlindIndex(value: string): string {
  return createHmac("sha256", NEW_INDEX).update(value.trim().toLowerCase(), "utf8").digest("hex");
}
function newChainHash(input: (string | null)[]): string {
  return createHmac("sha256", NEW_CHAIN).update(JSON.stringify(input), "utf8").digest("hex");
}

/** a THIRD key — seals an envelope NO runbook key can open (models the
 *  live-DB finding: cells sealed under a lost pre-extraction key). */
const LOST_AES = Buffer.from(
  hkdfSync("sha256", Buffer.from("a-lost-third-key-16chars-min!!", "utf8"), Buffer.alloc(0), "ashrilogic/field-aes-256-gcm/v1", 32)
);
let lostKeyEnvelope: string;

let vault: typeof import("@/lib/server/crypto-vault");
let auditChain: typeof import("@/lib/server/audit-chain");

const SEED = {
  customerEmail: "guest1@elite-hospital.example",
  customerPhone: "+966501234567",
  teamEmail: "doctor@elite-hospital.example",
  teamProfile: JSON.stringify({ phone: "+966500000000", jobTitle: "consultant" }),
  adminEmail: "admin@ashrilogic.example",
  adminAddress: "Khartoum — Sudan",
  subscriberEmail: "news@reader.example",
  ticketEmail: "patient@ask.example",
  totpSecret: "JBSWY3DPEHPK3PXPTESTSECRET32",
  instanceAdminEmail: "owner@workspace.example",
  aiApiKey: "sk-rotation-test-1234567890abcdef",
  newsletterEmail: "digest@platform.example",
};

/** run the script as a subprocess (own env binding) and return exit + output.
 *  DATABASE_URL must be passed EXPLICITLY — the test process restores its
 *  own env after seeding, and Bun's child processes auto-load .env, so an
 *  inherited value could point the script at the WRONG database. The
 *  storage root is pinned to the fixture's throwaway dir so the script's
 *  pre-reseal platform snapshots never touch the real storage/ tree. */
async function runScript(extraArgs: string[], env: Record<string, string>): Promise<{ code: number; out: string }> {
  const proc = Bun.spawn(["bun", "scripts/re-seal-secrets.ts", "--force", ...extraArgs], {
    cwd: REPO_ROOT,
    env: {
      ...process.env,
      DATABASE_URL: FIXTURE_URL,
      ASHRILOGIC_STORAGE_DIR: FIXTURE_STORAGE,
      ...env,
    },
    stdout: "pipe",
    stderr: "pipe",
  });
  const out = await new Response(proc.stdout).text();
  const err = await new Response(proc.stderr).text();
  const code = await proc.exited;
  return { code, out: out + err };
}

beforeAll(async () => {
  /* fresh fixture database: drop + recreate (WITH (FORCE) also evicts any
   * connection a previously interrupted run left open), then push the
   * schema. The fixture shares the TEST server — a dedicated DATABASE,
   * the same isolation contract the old db/reseal-test.db file had. */
  const { Client } = await import("pg");
  const adminUrl = new URL(TEST_DATABASE_URL);
  adminUrl.pathname = "/postgres";
  const admin = new Client({ connectionString: adminUrl.toString() });
  await admin.connect();
  try {
    await admin.query(`DROP DATABASE IF EXISTS "${RESEAL_DB_NAME}" WITH (FORCE)`);
    await admin.query(`CREATE DATABASE "${RESEAL_DB_NAME}"`);
  } finally {
    await admin.end();
  }
  execSync("bunx prisma db push --skip-generate --schema prisma/schema.prisma", {
    cwd: REPO_ROOT,
    stdio: "pipe",
    env: { ...process.env, DATABASE_URL: FIXTURE_URL },
  });

  /* vault (demo key) + a client bound EXPLICITLY to the FIXTURE — Prisma
     resolves env("DATABASE_URL") LAZILY (at query time), so constructor-time
     env mutation is NOT enough; datasourceUrl pins the client for life. */
  vault = await import("@/lib/server/crypto-vault");
  auditChain = await import("@/lib/server/audit-chain");
  const { PrismaClient } = await import("@prisma/client");
  const db = new PrismaClient({ datasourceUrl: FIXTURE_URL });

  /* ---- seed every sealed-field family (demo key) ---- */
  await db.platformSetting.create({
    data: {
      id: "global",
      autoBackup: false, /* never nudge a snapshot from this fixture */
      aiJson: JSON.stringify({ enabled: true, model: "gpt-test", monthlyQuota: 10, usedThisMonth: 0, usedMonthKey: "2026-09", keySealed: vault.encryptField(SEED.aiApiKey) }),
      newsletterEmailsJson: JSON.stringify([{ email: vault.encryptField(SEED.newsletterEmail), label: "digest" }]),
    },
  } as never);

  await db.instance.create({
    data: {
      id: "re-seal-instance",
      systemId: "ws-reseal",
      orgJson: "{}",
      adminJson: JSON.stringify({ name: "Owner", email: vault.encryptField(SEED.instanceAdminEmail) }),
      prefsJson: "{}",
      modulesJson: "[]",
    },
  } as never);

  await db.siteCustomer.create({
    data: {
      instanceId: "re-seal-instance",
      name: "Guest One",
      email: vault.encryptField(SEED.customerEmail) ?? "",
      emailIndex: vault.blindIndex(SEED.customerEmail),
      phone: vault.encryptField(SEED.customerPhone),
      passwordHash: "$argon2id$v=1$m=19456,t=2,p=1$c2VlZA$c2VlZA",
    },
  } as never);

  await db.teamMember.create({
    data: {
      instanceId: "re-seal-instance",
      name: "Dr. Someone",
      email: vault.encryptField(SEED.teamEmail) ?? "",
      profileJson: vault.encryptField(SEED.teamProfile),
    },
  } as never);

  await db.adminUser.create({
    data: {
      username: "reseal.admin",
      name: "Reseal Admin",
      email: vault.encryptField(SEED.adminEmail) ?? "",
      emailIndex: vault.blindIndex(SEED.adminEmail),
      address: vault.encryptField(SEED.adminAddress),
    },
  } as never);

  await db.subscriber.create({
    data: {
      email: vault.encryptField(SEED.subscriberEmail) ?? "",
      emailIndex: vault.blindIndex(SEED.subscriberEmail),
    },
  } as never);

  await db.supportTicket.create({
    data: {
      subject: "re-seal probe",
      message: "probe",
      requesterName: "Patient",
      requesterEmail: vault.encryptField(SEED.ticketEmail) ?? "",
      requesterEmailIndex: vault.blindIndex(SEED.ticketEmail),
    },
  } as never);

  await db.mfaSecret.create({
    data: {
      scope: "admin",
      subjectId: "re-seal-admin",
      secretSealed: vault.encryptField(SEED.totpSecret) ?? "",
    },
  } as never);

  /* chained audit rows (demo chain key via the shared module) */
  let prev: string | null = null;
  for (const action of ["moduleRecord.create", "moduleRecord.update", "instance.update"]) {
    const createdAt = new Date();
    const chainHash = auditChain.computeChainHash({
      prevChainHash: prev,
      actorType: "admin",
      actorId: null,
      actorName: "t***@test.local",
      action,
      targetLabel: null,
      metaJson: null,
      createdAtISO: createdAt.toISOString(),
    });
    await (db as unknown as { auditLog: { create(args: unknown): Promise<unknown> } }).auditLog.create({
      data: {
        actorType: "admin",
        actorId: null,
        actorName: "t***@test.local",
        action,
        targetLabel: null,
        metaJson: null,
        createdAt,
        prevChainHash: prev,
        chainHash,
      },
    });
    prev = chainHash;
  }

  await db.$disconnect();
});

afterAll(async () => {
  /* drop the fixture database + remove the throwaway snapshot storage the
   * script's runs produced (the whole root is ours — created fresh this
   * run, so every snapshot inside it is a test artifact) */
  rmSync(FIXTURE_STORAGE, { recursive: true, force: true });
  try {
    const { Client } = await import("pg");
    const adminUrl = new URL(TEST_DATABASE_URL);
    adminUrl.pathname = "/postgres";
    const admin = new Client({ connectionString: adminUrl.toString() });
    await admin.connect();
    try {
      await admin.query(`DROP DATABASE IF EXISTS "${RESEAL_DB_NAME}" WITH (FORCE)`);
    } finally {
      await admin.end();
    }
  } catch (error) {
    console.error("[re-seal] fixture database drop failed (next run drops+recreates it):", error);
  }
});

/** re-open the fixture-bound client — pinned via datasourceUrl (Prisma
 *  resolves env URLs lazily, so explicit pinning is the ONLY reliable way). */
async function openFixture(): Promise<PrismaClient> {
  const { PrismaClient } = await import("@prisma/client");
  return new PrismaClient({ datasourceUrl: FIXTURE_URL });
}

describe("re-seal runbook — end to end", () => {
  test("WRONG old key → abort exit 1, nothing changed", async () => {
    const before = await openFixture();
    const beforeCustomer = await before.siteCustomer.findFirst({});
    await before.$disconnect();

    const run = await runScript([], {
      ASHRILOGIC_OLD_DATA_KEY: "definitely-not-the-old-key-16",
      ASHRILOGIC_DATA_KEY: NEW_KEY,
    });
    expect(run.code).toBe(1);
    /* the chain pre-check fires first under a wrong key (every row's hash
       mismatches) — either abort message means NOTHING was changed */
    expect(run.out).toMatch(/ABORT|re-seal failed/);

    const after = await openFixture();
    const afterCustomer = await after.siteCustomer.findFirst({});
    await after.$disconnect();
    /* the seeded envelope is UNCHANGED (still the demo-key envelope) */
    expect((afterCustomer as { email?: string })?.email).toBe((beforeCustomer as { email?: string })?.email);
  });

  test("execute with the correct old key → exit 0", async () => {
    const run = await runScript(["--execute"], {
      ASHRILOGIC_OLD_DATA_KEY: DEMO_KEY,
      ASHRILOGIC_DATA_KEY: NEW_KEY,
    });
    expect(run.code).toBe(0);
    expect(run.out).toContain("ROTATION COMPLETE");
  });

  test("every envelope opens with the NEW key and decrypts to the seeded plaintext", async () => {
    const db = await openFixture();

    const customer = (await db.siteCustomer.findFirst({})) as { email: string; phone: string; emailIndex: string };
    expect(customer.email).not.toBe(vault.encryptField(SEED.customerEmail)); /* fresh envelope */
    expect(newDecrypt(customer.email)).toBe(SEED.customerEmail);
    expect(newDecrypt(customer.phone)).toBe(SEED.customerPhone);
    expect(customer.emailIndex).toBe(newBlindIndex(SEED.customerEmail));

    const member = (await db.teamMember.findFirst({})) as { email: string; profileJson: string };
    expect(newDecrypt(member.email)).toBe(SEED.teamEmail);
    expect(newDecrypt(member.profileJson)).toBe(SEED.teamProfile);

    const admin = (await db.adminUser.findFirst({})) as { email: string; address: string; emailIndex: string };
    expect(newDecrypt(admin.email)).toBe(SEED.adminEmail);
    expect(newDecrypt(admin.address)).toBe(SEED.adminAddress);
    expect(admin.emailIndex).toBe(newBlindIndex(SEED.adminEmail));

    const subscriber = (await db.subscriber.findFirst({})) as { email: string; emailIndex: string };
    expect(newDecrypt(subscriber.email)).toBe(SEED.subscriberEmail);
    expect(subscriber.emailIndex).toBe(newBlindIndex(SEED.subscriberEmail));

    const ticket = (await db.supportTicket.findFirst({})) as { requesterEmail: string; requesterEmailIndex: string };
    expect(newDecrypt(ticket.requesterEmail)).toBe(SEED.ticketEmail);
    expect(ticket.requesterEmailIndex).toBe(newBlindIndex(SEED.ticketEmail));

    const mfa = (await db.mfaSecret.findFirst({})) as { secretSealed: string };
    expect(newDecrypt(mfa.secretSealed)).toBe(SEED.totpSecret);

    await db.$disconnect();
  });

  test("nested-JSON envelopes (adminJson / aiJson / newsletterEmails) re-sealed in place", async () => {
    const db = await openFixture();

    const instance = (await db.instance.findFirst({})) as { adminJson: string; adminEmailIndex: string };
    const adminJson = JSON.parse(instance.adminJson) as { name: string; email: string };
    expect(adminJson.name).toBe("Owner"); /* non-sealed content untouched */
    expect(newDecrypt(adminJson.email)).toBe(SEED.instanceAdminEmail);
    expect(instance.adminEmailIndex).toBe(newBlindIndex(SEED.instanceAdminEmail));

    const settings = (await db.platformSetting.findUnique({ where: { id: "global" } })) as { aiJson: string; newsletterEmailsJson: string };
    const ai = JSON.parse(settings.aiJson) as { enabled: boolean; keySealed: string };
    expect(ai.enabled).toBe(true);
    expect(newDecrypt(ai.keySealed)).toBe(SEED.aiApiKey);
    const news = JSON.parse(settings.newsletterEmailsJson) as Array<{ email: string; label: string }>;
    expect(news[0].label).toBe("digest");
    expect(newDecrypt(news[0].email)).toBe(SEED.newsletterEmail);

    await db.$disconnect();
  });

  test("the audit chain re-keys under the NEW chain key and stays link-consistent", async () => {
    const db = await openFixture();
    const rows = (await db.auditLog.findMany({ orderBy: [{ createdAt: "asc" }, { id: "asc" }] })) as Array<{
      actorType: string;
      actorId: string | null;
      actorName: string;
      action: string;
      targetLabel: string | null;
      metaJson: string | null;
      createdAt: Date;
      prevChainHash: string | null;
      chainHash: string | null;
    }>;
    await db.$disconnect();

    expect(rows.length).toBeGreaterThanOrEqual(3); /* seeded + the reseal audit row */
    let prev: string | null = null;
    for (const r of rows) {
      expect(r.prevChainHash).toBe(prev); /* links preserved through the re-key */
      const recomputed = newChainHash([
        r.prevChainHash,
        r.actorType,
        r.actorId,
        r.actorName,
        r.action,
        r.targetLabel,
        r.metaJson,
        new Date(r.createdAt).toISOString(),
      ]);
      expect(r.chainHash).toBe(recomputed); /* new-key coverage */
      prev = r.chainHash;
    }
    /* the rotation's own audit row is the new head */
    expect(rows[rows.length - 1].action).toBe("system.reseal");
  });

  test("re-running with the same keys is a NO-OP resume (already new-key)", async () => {
    const run = await runScript(["--execute"], {
      ASHRILOGIC_OLD_DATA_KEY: DEMO_KEY,
      ASHRILOGIC_DATA_KEY: NEW_KEY,
    });
    expect(run.code).toBe(0);
    /* every envelope already opens with the NEW key → re-seal count is 0 */
    expect(run.out).toMatch(/re-seal=0/);
    expect(run.out).not.toContain("FAILURES=");

    const db = await openFixture();
    const customer = (await db.siteCustomer.findFirst({})) as { email: string };
    expect(newDecrypt(customer.email)).toBe(SEED.customerEmail); /* still intact */
    await db.$disconnect();
  });

  test("--skip-unopenable: a lost-key cell ABORTS by default, rotates around it with the flag", async () => {
    /* seed a customer whose phone is sealed under a LOST third key and whose
       email is sealed with the CURRENT key (NEW_KEY — the fixture state after
       the earlier rotations); models the live-DB finding of cells sealed
       under a lost pre-extraction key */
    const { createCipheriv, randomBytes } = await import("node:crypto");
    const sealWith = (key: Buffer, plaintext: string): string => {
      const iv = randomBytes(12);
      const cipher = createCipheriv("aes-256-gcm", key, iv);
      const ct = Buffer.concat([cipher.update(Buffer.from(plaintext, "utf8")), cipher.final()]);
      return `enc:v1:${iv.toString("base64")}:${cipher.getAuthTag().toString("base64")}:${ct.toString("base64")}`;
    };
    lostKeyEnvelope = sealWith(LOST_AES, "+966509999999");
    const seed = await openFixture();
    await seed.siteCustomer.create({
      data: {
        instanceId: "re-seal-instance",
        name: "Guest Two lost-key",
        email: sealWith(NEW_AES, "guest2@elite-hospital.example"),
        emailIndex: newBlindIndex("guest2@elite-hospital.example"),
        phone: lostKeyEnvelope,
        passwordHash: "$argon2id$v=1$m=19456,t=2,p=1$c2VlZA$c2VlZA",
      },
    });
    await seed.$disconnect();

    /* the fixture is already rotated to NEW_KEY by the earlier tests — chain
       the next rotation from there (OLD = NEW_KEY) */
    const blocked = await runScript(["--execute"], {
      ASHRILOGIC_OLD_DATA_KEY: NEW_KEY,
      ASHRILOGIC_DATA_KEY: "another-new-key-for-skip-test-32ch!!",
    });
    expect(blocked.code).toBe(1);
    expect(blocked.out).toContain("ABORT");

    /* with the flag: the cell stays VERBATIM, everything else rotates */
    const run = await runScript(["--execute", "--skip-unopenable"], {
      ASHRILOGIC_OLD_DATA_KEY: NEW_KEY,
      ASHRILOGIC_DATA_KEY: "another-new-key-for-skip-test-32ch!!",
    });
    expect(run.code).toBe(0);
    expect(run.out).toContain("ROTATION COMPLETE");
    expect(run.out).toContain("--skip-unopenable: 1 envelope");

    const db = await openFixture();
    const customers = (await db.siteCustomer.findMany({
      orderBy: { name: "asc" },
    })) as Array<{ name: string; phone: string }>;
    const lost = customers.find((c) => c.name.includes("lost-key"));
    expect(lost?.phone).toBe(lostKeyEnvelope); /* VERBATIM — not re-sealed, not wiped */
    await db.$disconnect();
  });
});
