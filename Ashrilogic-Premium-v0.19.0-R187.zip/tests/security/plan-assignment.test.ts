/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 46 (F-6): admin plan assignment while the
 * browser ALSO holds the workspace's own session cookie.
 *
 * The bug: requireInstanceAccess resolves the workspace session FIRST, so
 * an operator who had signed into the tenant dashboard (to inspect it) and
 * then returned to the control panel got
 *   403 "Plan changes are managed by the platform — request an upgrade
 *   instead" (PACKAGE_ADMIN_ONLY)
 * on every plan assignment — the workspace-session shadowed the admin
 * session even though a valid managing-admin cookie was present.
 *
 * The fix: when the PATCH carries a packageId and the resolved actor is a
 * workspace session, the route re-checks for a valid managing-admin
 * (super/admin) session; if present the change is admin-authorized (and
 * the audit re-attributes to that admin), otherwise the 403 stands.
 *
 * This suite proves BOTH sides on the live dev server:
 *   1. workspace owner alone           → 403 PACKAGE_ADMIN_ONLY (invariant)
 *   2. workspace owner + admin cookie  → 200, plan assigned (the fix)
 *   3. the activity trail records the change with the BILINGUAL plan meta
 *   4. the assignment honors a real package id (404 for unknown ids)
 *
 * Plus a unit check of the ROUND 46 session UA breakdown (browser/os/kind)
 * that enriches the active-sessions cards.
 */
import { describe, test, expect, beforeAll, afterAll } from "bun:test";
import { join } from "node:path";
import { REPO_ROOT, ensureDemoEnv, loginDemoAdmin } from "./test-setup";

ensureDemoEnv();

const BASE = "http://localhost:3000";
const RUN = Math.random().toString(36).slice(2, 8);
/* ROUND 134 — deep tenant-uniqueness gate: RUN-derived org phone (the old
 * constant +966500000000 collides with soft-deleted probe rows from prior
 * runs — the deep scan deliberately includes trashed rows). */
function runPhoneDigits(seed: string): string {
  let h = 0;
  for (const ch of seed) h = (h * 31 + ch.charCodeAt(0)) % 100000;
  return String(h % 100000).padStart(5, "0");
}
const ORG_PHONE = `+9665${runPhoneDigits(RUN)}`;
const XFF_IP = `198.18.${RUN.length}.${(RUN.charCodeAt(0) % 200) + 10}`;
const JSON_HEADERS: Record<string, string> = {
  "content-type": "application/json",
  origin: BASE,
  referer: `${BASE}/`,
};

/* ------------------------------ cookie jar ------------------------------ */

class CookieJar {
  private cookies = new Map<string, string>();
  setFrom(res: Response): void {
    const lines: string[] =
      typeof res.headers.getSetCookie === "function" ? res.headers.getSetCookie() : [];
    if (lines.length === 0) {
      const single = res.headers.get("set-cookie");
      if (single) lines.push(single);
    }
    for (const line of lines) {
      const [pair] = line.split(";");
      const eq = pair.indexOf("=");
      if (eq > 0) this.cookies.set(pair.slice(0, eq).trim(), pair.slice(eq + 1).trim());
    }
  }
  header(): string {
    return [...this.cookies.entries()].map(([k, v]) => `${k}=${v}`).join("; ");
  }
}

async function jfetch(path: string, jar: CookieJar, method: string, body?: string): Promise<Response> {
  const cookie = jar.header();
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      "content-type": "application/json",
      "x-forwarded-for": XFF_IP,
      ...(cookie ? { cookie } : {}),
      ...(method === "GET" ? {} : JSON_HEADERS),
    },
    body,
    signal: AbortSignal.timeout(15_000),
  });
  jar.setFrom(res);
  return res;
}

/* -------------------------------- suite -------------------------------- */

describe("ROUND 46 — plan assignment (F-6)", () => {
  let instanceId = "";
  let starterId = "";
  let proId = "";
  const jar = new CookieJar();

  beforeAll(async () => {
    /* provision a fresh workspace (owner session cookie set) */
    const res = await jfetch(
      "/api/instances",
      jar,
      "POST",
      JSON.stringify({
        systemId: "pharmacy-management",
        org: {
          name: `مختبر الباقات ${RUN}`,
          country: "SA",
          currency: "SAR",
          timezone: "Asia/Riyadh",
          phone: ORG_PHONE,
          address: "عنوان الاختبار",
        },
        admin: {
          name: `مالك ${RUN}`,
          email: `plan-owner-${RUN}@ashrilogic.test`,
          role: "owner",
          password: `plan-owner-${RUN}-pass`,
          twoFA: false,
        },
        prefs: {
          lang: "ar",
          theme: "light",
          notif: true,
          backup: true,
          audit: true,
          demo: false,
        },
        modules: ["pharmacy", "inventory"],
      })
    );
    if (res.status !== 201) throw new Error(`provision failed: ${res.status}`);
    const data = (await res.json()) as { id: string };
    instanceId = data.id;
  });

  afterAll(async () => {
    if (!instanceId) return;
    /* admin cookie may or may not be set — try with whatever the jar has */
    await jfetch(`/api/instances/${instanceId}`, jar, "DELETE").catch(() => undefined);
  });

  /* ROUND 124 — explicit 20s timeout per live test: the battery runs this
     suite against a FRESH server, and the FIRST requests cold-compile their
     route chains (measured ~5s+ on /api/instances) — bun's 5s default
     contradicted the suite's own 15s fetch budget (jfetch AbortSignal) and
     flaked the first test. 20s = the fetch budget + cold-compile margin. */
  test("workspace owner alone CANNOT self-assign a plan (invariant)", async () => {
    const pkgs = (await (
      await jfetch("/api/admin/packages", jar, "GET")
    ).json()) as unknown;
    /* admin cookie absent → 401 for the admin route; get ids via the public list instead */
    const pub = (await (await fetch(`${BASE}/api/packages`)).json()) as {
      id: string;
      nameEn: string;
    }[];
    starterId = pub.find((p) => p.nameEn === "Starter")?.id ?? pub[0]?.id ?? "";
    proId = pub.find((p) => p.nameEn === "Professional")?.id ?? pub[1]?.id ?? "";
    expect(starterId).toBeTruthy();
    expect(proId).toBeTruthy();
    void pkgs;

    const res = await jfetch(
      `/api/instances/${instanceId}`,
      jar,
      "PATCH",
      JSON.stringify({ packageId: proId })
    );
    expect(res.status).toBe(403);
    const body = (await res.json()) as { code?: string };
    expect(body.code).toBe("PACKAGE_ADMIN_ONLY");
  }, 20_000);

  test("owner + managing-admin cookie CAN assign the plan (the F-6 fix)", async () => {
    /* sign in as the platform admin IN THE SAME JAR — the browser now holds
       BOTH the workspace session and the admin session (the bug scenario).
       ROUND 124 — loginDemoAdmin tries every documented demo password (the
       delivered DB is bootstrapped with a different secret than seed-demo). */
    const login = await loginDemoAdmin(jfetch, jar);
    expect(login.status).toBe(200);
    expect(jar.header()).toContain("ashrilogic-admin-session=");

    const res = await jfetch(
      `/api/instances/${instanceId}`,
      jar,
      "PATCH",
      JSON.stringify({ packageId: proId })
    );
    expect(res.status).toBe(200);
    const body = (await res.json()) as { packageId: string | null };
    expect(body.packageId).toBe(proId);
  }, 20_000);

  test("activity meta carries the BILINGUAL plan identity (F-7)", async () => {
    const res = await jfetch(`/api/instances/${instanceId}`, jar, "GET");
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      instance: { activities: { kind: string; meta?: Record<string, string> }[] };
    };
    const change = body.instance.activities.find(
      (a) => a.kind === "actSettingsUpdated" && a.meta && "package" in a.meta
    );
    expect(change).toBeTruthy();
    expect(change!.meta!.package).toBe("Professional");
    expect(change!.meta!.packageAr).toBe("الباقة الاحترافية");
  }, 20_000);

  test("unknown plan id → 404 PACKAGE_NOT_FOUND (admin still present)", async () => {
    const res = await jfetch(
      `/api/instances/${instanceId}`,
      jar,
      "PATCH",
      JSON.stringify({ packageId: "cmu0nonexistent0000000000000" })
    );
    expect(res.status).toBe(404);
    const body = (await res.json()) as { code?: string };
    expect(body.code).toBe("PACKAGE_NOT_FOUND");
  }, 20_000);

  test("cleanup — delete the probe workspace (admin cookie present)", async () => {
    const res = await jfetch(`/api/instances/${instanceId}`, jar, "DELETE");
    expect(res.status).toBe(200);
    instanceId = "";
  }, 20_000);
});

/* ------------------------ unit — session UA breakdown ------------------------ */

describe("ROUND 46 — uaBreakdown (session device detail)", () => {
  test("desktop Chrome on Windows", async () => {
    const { uaBreakdown } = await import("@/lib/server/sessions");
    const parts = uaBreakdown(
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    );
    expect(parts.browser).toBe("Chrome");
    expect(parts.os).toBe("Windows");
    expect(parts.kind).toBe("desktop");
  });

  test("iPhone Safari → mobile", async () => {
    const { uaBreakdown } = await import("@/lib/server/sessions");
    const parts = uaBreakdown(
      "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"
    );
    expect(parts.kind).toBe("mobile");
  });

  test("Android tablet (no Mobile token) → tablet", async () => {
    const { uaBreakdown } = await import("@/lib/server/sessions");
    const parts = uaBreakdown(
      "Mozilla/5.0 (Linux; Android 13; SM-X710) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    );
    expect(parts.kind).toBe("tablet");
  });

  test("native app UA → app kind", async () => {
    const { uaBreakdown } = await import("@/lib/server/sessions");
    const parts = uaBreakdown("AshrilogicApp/1.2.3 okhttp/4.12");
    expect(parts.kind).toBe("app");
  });

  test("null UA → unknown", async () => {
    const { uaBreakdown } = await import("@/lib/server/sessions");
    expect(uaBreakdown(null).kind).toBe("unknown");
  });
});

/* keep REPO_ROOT referenced for path-import parity with the suite */
void join(REPO_ROOT, "package.json");
