/// <reference types="bun-types" />
/**
 * Ashrilogic — ROUND 137 security regression: the MFA FAIL-CLOSED matrix
 * + the SECURITY-POLICY/SSETTINGS boundary split.
 *
 * Phase 2 findings 2 + 3:
 *   • MFA policy reads used to fail OPEN (catch → "policy disabled") —
 *     a DB hiccup silently disarmed the 2FA gate for sensitive admin
 *     mutations. The policy read is now tri-state; `unknown` REFUSES
 *     non-allowlisted mutations with 403 MFA_POLICY_UNAVAILABLE.
 *   • /api/admin/settings used to be wholly MFA-exempt (the 2FA toggle
 *     lived there); the exemption is now the NARROW
 *     /api/admin/security-policy route (super-only, strict audit), and
 *     the general settings surface enforces MFA like everything else.
 *
 * The matrix under test (policy on/off/unknown × enrolled/not ×
 * mutation/GET/allowlisted-path) plus the route split behavior — all
 * against the throwaway test DB (never the live dev database).
 */
import { describe, test, expect, beforeAll, afterAll, mock } from "bun:test";
import { ensureDemoEnv, getTestDb, resetRateTable } from "./test-setup";

ensureDemoEnv();

/* Mock next/headers BEFORE importing any route/admin-session (the cookie
 * resolution runs through it). Same pattern as admin-instance-ops.test.ts. */
const cookieJar = new Map<string, string>();
mock.module("next/headers", () => ({
  cookies: async () => ({
    get: (name: string) =>
      cookieJar.has(name) ? { name, value: cookieJar.get(name) as string } : undefined,
    set: (name: string, value: string) => {
      cookieJar.set(name, value);
    },
    delete: (name: string) => {
      cookieJar.delete(name);
    },
  }),
  headers: async () => ({ get: () => undefined }),
  draftMode: async () => ({ isEnabled: () => false }),
}));

const HOST = "localhost:3000";
const RUN = Math.random().toString(36).slice(2, 8);

let db: Awaited<ReturnType<typeof getTestDb>>;
let adminSession: typeof import("@/lib/server/admin-session");
let settingsRoute: typeof import("@/app/api/admin/settings/route");
let policyRoute: typeof import("@/app/api/admin/security-policy/route");
let audit: typeof import("@/lib/server/audit");
let tokens: typeof import("@/lib/server/tokens");
let sessions: typeof import("@/lib/server/sessions");
let cookieNames: typeof import("@/lib/server/cookie-names");

const SUPER_ID = `adm-super-${RUN}`;
const PLAIN_ID = `adm-plain-${RUN}`;

/** a mutation Request through the SETTINGS surface (same-origin headers). */
function patchSettings(body: unknown): Promise<Response> {
  return settingsRoute.PATCH(
    new Request(`http://${HOST}/api/admin/settings`, {
      method: "PATCH",
      headers: {
        "content-type": "application/json",
        host: HOST,
        origin: `http://${HOST}`,
        cookie: [...cookieJar.entries()].map(([k, v]) => `${k}=${v}`).join("; "),
      },
      body: JSON.stringify(body),
    })
  );
}

/** a mutation Request through the SECURITY-POLICY surface. */
function patchPolicy(body: unknown): Promise<Response> {
  return policyRoute.PATCH(
    new Request(`http://${HOST}/api/admin/security-policy`, {
      method: "PATCH",
      headers: {
        "content-type": "application/json",
        host: HOST,
        origin: `http://${HOST}`,
        cookie: [...cookieJar.entries()].map(([k, v]) => `${k}=${v}`).join("; "),
      },
      body: JSON.stringify(body),
    })
  );
}

let signInSeq = 0;
async function signInAs(adminId: string): Promise<void> {
  signInSeq += 1;
  const jti = `jti-mfa-${RUN}-${signInSeq}`;
  const { token, expiresAt } = tokens.issueToken("admin", adminId, 60 * 60 * 1000, 0, jti);
  await sessions.recordSession({ scope: "admin", subjectId: adminId, jti, expiresAt });
  cookieNames; /* keep the import shape stable */
  cookieJar.set("ashrilogic-admin-session", token);
}

async function setPolicy(twoFARequired: boolean): Promise<void> {
  await db.platformSetting.upsert({
    where: { id: "global" },
    create: { id: "global", twoFARequired },
    update: { twoFARequired },
  });
  adminSession.__resetMfaCachesForTests();
}

beforeAll(async () => {
  db = await getTestDb();
  await resetRateTable(db);
  adminSession = await import("@/lib/server/admin-session");
  settingsRoute = await import("@/app/api/admin/settings/route");
  policyRoute = await import("@/app/api/admin/security-policy/route");
  audit = await import("@/lib/server/audit");
  tokens = await import("@/lib/server/tokens");
  sessions = await import("@/lib/server/sessions");
  cookieNames = await import("@/lib/server/cookie-names");

  await db.adminUser.create({
    data: {
      id: SUPER_ID,
      username: `super-${RUN}`,
      name: "Super Admin",
      email: `super-${RUN}@mfa.test`,
      role: "super",
      active: true,
    },
  });
  await db.adminUser.create({
    data: {
      id: PLAIN_ID,
      username: `plain-${RUN}`,
      name: "Plain Admin",
      email: `plain-${RUN}@mfa.test`,
      role: "admin",
      active: true,
    },
  });
  await setPolicy(false);
});

afterAll(async () => {
  try {
    await db.adminUser.deleteMany({ where: { id: { in: [SUPER_ID, PLAIN_ID] } } });
    await db.platformSetting.deleteMany({});
    await db.auditLog.deleteMany({});
  } catch {
    /* throwaway DB */
  }
});

/* ------------------------------------------------------------------ */
/* 1 — the FAIL-CLOSED matrix                                          */
/* ------------------------------------------------------------------ */

describe("ROUND 137 — MFA fail-closed matrix", () => {
  test("policy ON + NOT enrolled: the settings mutation is refused (MFA_ENROLLMENT_REQUIRED)", async () => {
    await signInAs(SUPER_ID);
    await setPolicy(true);
    const res = await patchSettings({ siteNameAr: "منصة" });
    expect(res.status).toBe(403);
    const body = (await res.json()) as { code?: string };
    expect(body.code).toBe("MFA_ENROLLMENT_REQUIRED");
  });

  test("policy ON + TOTP enrolled: the mutation passes", async () => {
    const { startMfaEnrollment, confirmMfaEnrollment, totpCode } = await import("@/lib/server/mfa");
    const started = await startMfaEnrollment("admin", SUPER_ID, "super@test");
    if (!("secret" in started)) throw new Error("enrollment start failed");
    const confirmed = await confirmMfaEnrollment("admin", SUPER_ID, totpCode(started.secret));
    expect(confirmed.ok).toBeTrue();
    adminSession.__resetMfaCachesForTests();
    const res = await patchSettings({ siteNameAr: "منصة" });
    expect(res.status).not.toBe(403);
    await db.mfaSecret.deleteMany({ where: { subjectId: SUPER_ID } });
    adminSession.__resetMfaCachesForTests();
  });

  test("policy ON + passkey enrolled: the mutation passes", async () => {
    await db.webauthnCredential.create({
      data: {
        id: `cred-${RUN}`,
        scope: "admin",
        subjectId: SUPER_ID,
        publicKey: "x",
      },
    });
    adminSession.__resetMfaCachesForTests();
    const res = await patchSettings({ siteNameAr: "منصة" });
    expect(res.status).not.toBe(403);
    await db.webauthnCredential.deleteMany({ where: { subjectId: SUPER_ID } });
    adminSession.__resetMfaCachesForTests();
  });

  test("policy OFF + NOT enrolled: the mutation passes", async () => {
    await setPolicy(false);
    const res = await patchSettings({ siteNameAr: "منصة" });
    expect(res.status).not.toBe(403);
  });

  test("DB read failure (policy UNKNOWN) + NOT enrolled: the mutation FAILS CLOSED (MFA_POLICY_UNAVAILABLE)", async () => {
    await setPolicy(true);
    /* break the policy read the way a store outage would: the delegate
     * throws; readMfaPolicy must answer `unknown`, never `off` */
    const original = db.platformSetting.findUnique;
    (db.platformSetting as unknown as { findUnique: unknown }).findUnique =
      mock(() => Promise.reject(new Error("simulated store outage")));
    adminSession.__resetMfaCachesForTests();
    try {
      const res = await patchSettings({ siteNameAr: "منصة" });
      expect(res.status).toBe(403);
      const body = (await res.json()) as { code?: string };
      expect(body.code).toBe("MFA_POLICY_UNAVAILABLE");
    } finally {
      (db.platformSetting as unknown as { findUnique: unknown }).findUnique = original;
      adminSession.__resetMfaCachesForTests();
    }
  });

  test("policy UNKNOWN + enrolled: the mutation passes (enrollment satisfies either policy value)", async () => {
    const { startMfaEnrollment, confirmMfaEnrollment, totpCode } = await import("@/lib/server/mfa");
    const started = await startMfaEnrollment("admin", SUPER_ID, "super@test");
    if (!("secret" in started)) throw new Error("enrollment start failed");
    const confirmed = await confirmMfaEnrollment("admin", SUPER_ID, totpCode(started.secret));
    expect(confirmed.ok).toBeTrue();
    const original = db.platformSetting.findUnique;
    (db.platformSetting as unknown as { findUnique: unknown }).findUnique =
      mock(() => Promise.reject(new Error("simulated store outage")));
    adminSession.__resetMfaCachesForTests();
    try {
      const res = await patchSettings({ siteNameAr: "منصة" });
      expect(res.status).not.toBe(403);
    } finally {
      (db.platformSetting as unknown as { findUnique: unknown }).findUnique = original;
      await db.mfaSecret.deleteMany({ where: { subjectId: SUPER_ID } });
      adminSession.__resetMfaCachesForTests();
    }
  });

  test("the allowlisted security-policy route stays reachable under policy ON + NOT enrolled (the break-glass)", async () => {
    await setPolicy(true);
    const res = await patchPolicy({ twoFARequired: false });
    expect(res.status).toBe(200);
    const body = (await res.json()) as { twoFARequired?: boolean };
    expect(body.twoFARequired).toBe(false);
    await setPolicy(false);
  });

  test("GET handlers (no Request) are never gated by the MFA matrix", async () => {
    await setPolicy(true);
    const res = await settingsRoute.GET();
    expect(res.status).toBe(200);
    await setPolicy(false);
  });
});

/* ------------------------------------------------------------------ */
/* 2 — the security-policy / settings boundary                         */
/* ------------------------------------------------------------------ */

describe("ROUND 137 — security-policy route split", () => {
  beforeAll(async () => {
    await setPolicy(false);
  });

  test("the security-policy PATCH is SUPER-ONLY: a plain admin is refused", async () => {
    await signInAs(PLAIN_ID);
    const res = await patchPolicy({ twoFARequired: true });
    expect(res.status).toBe(403);
  });

  test("the security-policy PATCH accepts ONLY the allowlisted field", async () => {
    await signInAs(SUPER_ID);
    const res = await patchPolicy({ twoFARequired: true, siteNameAr: "hijack" });
    /* the whole payload is refused — no silent field stripping */
    expect(res.status).toBe(400);
  });

  test("the 2FA toggle through the SECURITY-POLICY route writes, audits strictly, and takes effect", async () => {
    await signInAs(SUPER_ID);
    const before = await db.auditLog.count({ where: { action: "security-policy.update" } });
    const res = await patchPolicy({ twoFARequired: true });
    expect(res.status).toBe(200);
    const row = await db.platformSetting.findUnique({ where: { id: "global" } });
    expect(row?.twoFARequired).toBe(true);
    const after = await db.auditLog.count({ where: { action: "security-policy.update" } });
    expect(after).toBe(before + 1);
    await setPolicy(false);
  });

  test("the SETTINGS schema no longer accepts twoFARequired (the capability is closed there)", async () => {
    await signInAs(SUPER_ID);
    const res = await patchSettings({ twoFARequired: true, siteNameAr: "اسم" });
    expect(res.status).not.toBe(403); /* authorized + policy off */
    expect(res.status).not.toBe(400); /* and NOT schema-refused: the field is simply STRIPPED */
    const row = await db.platformSetting.findUnique({ where: { id: "global" } });
    expect(row?.twoFARequired).toBe(false); /* the smuggled toggle did NOT land */
  });
});
