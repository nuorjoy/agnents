/**
 * Ashrilogic — ROUND 146: a comment-aware source scanner for the STATIC
 * security coverage gates.
 *
 * THE GAP THIS CLOSES: instance-route-coverage / mutation-coverage match
 * their guard patterns over RAW source text — a guard call that is COMMENTED
 * OUT (the classic "temporarily disabled during debugging, never restored"
 * regression) still satisfied the gate. The LIVE suites would catch it at
 * runtime, but the offline battery is the first line of defense.
 *
 * stripComments() removes line and block comments while PRESERVING string
 * and template-literal contents (a double-slash inside "https://…" is not
 * a comment) and tracking template `${…}` interpolations as code. The
 * output keeps the original line structure, so pattern matching stays
 * position-stable.
 *
 * KNOWN RESIDUAL (documented): a regex literal containing an unescaped
 * double-slash (only legal inside a character class) can consume the rest
 * of its line as a phantom comment — the fail-open direction for that one
 * line, strictly narrower than the raw-text status quo. No such regex
 * exists in the current corpus.
 */

/** Remove comments from TypeScript source, preserving strings/templates. */
export function stripComments(source: string): string {
  let out = "";
  let i = 0;
  const n = source.length;

  type State = "code" | "line" | "block" | "squote" | "dquote" | "tpl";
  let state: State = "code";
  /** brace depth per open template interpolation (${ … }); empty → not
   *  inside any interpolation. */
  const tplStack: number[] = [];

  while (i < n) {
    const c = source[i];
    const next = i + 1 < n ? source[i + 1] : "";

    switch (state) {
      case "code":
        if (c === "/" && next === "/") {
          state = "line";
          out += "  "; /* keep column drift minimal on the same line */
          i += 2;
          continue;
        }
        if (c === "/" && next === "*") {
          state = "block";
          out += " ";
          i += 2;
          continue;
        }
        if (c === "'") {
          state = "squote";
          out += c;
          i++;
          continue;
        }
        if (c === '"') {
          state = "dquote";
          out += c;
          i++;
          continue;
        }
        if (c === "`") {
          state = "tpl";
          out += c;
          i++;
          continue;
        }
        if (c === "$" && next === "{") {
          /* entering a template interpolation — it IS code */
          tplStack.push(0);
          out += "${";
          i += 2;
          continue;
        }
        if (c === "{") {
          if (tplStack.length > 0) tplStack[tplStack.length - 1]! += 1;
          out += c;
          i++;
          continue;
        }
        if (c === "}") {
          if (tplStack.length > 0) {
            const depth = tplStack[tplStack.length - 1]!;
            if (depth > 0) {
              tplStack[tplStack.length - 1]! -= 1;
            } else {
              tplStack.pop();
              state = "tpl"; /* the interpolation closed — back to literal */
            }
          }
          out += c;
          i++;
          continue;
        }
        out += c;
        i++;
        continue;

      case "line":
        if (c === "\n") {
          state = "code";
          out += "\n";
        }
        i++;
        continue;

      case "block":
        if (c === "*" && next === "/") {
          state = "code";
          out += " ";
          i += 2;
          continue;
        }
        if (c === "\n") out += "\n"; /* preserve line alignment */
        i++;
        continue;

      case "squote":
        out += c;
        if (c === "\\") {
          out += next;
          i += 2;
          continue;
        }
        if (c === "'" || c === "\n") state = "code"; /* unterminated guard */
        i++;
        continue;

      case "dquote":
        out += c;
        if (c === "\\") {
          out += next;
          i += 2;
          continue;
        }
        if (c === '"' || c === "\n") state = "code";
        i++;
        continue;

      case "tpl":
        out += c;
        if (c === "\\") {
          out += next;
          i += 2;
          continue;
        }
        if (c === "`") {
          state = "code";
          i++;
          continue;
        }
        i++;
        continue;
    }
  }
  return out;
}
