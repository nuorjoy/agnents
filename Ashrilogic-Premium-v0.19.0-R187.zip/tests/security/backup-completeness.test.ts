/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — BACKUP/RESTORE COMPLETENESS (envelope v2).
 *
 * Proves the tenant backup is a COMPLETE reconstruction artifact:
 *  - every business field rides the envelope (customer saved addresses +
 *    payment-method display metadata, order status-history timelines,
 *    customer/order timestamps, sealed team profiles, reviews, coupons);
 *  - referenced images travel as VERIFIED BYTES (SHA-256 at build AND
 *    restore) — a missing asset is counted (meta.imagesMissing > 0), never
 *    silently dropped, and the file is then NOT fully valid;
 *  - a restore round-trip preserves every one of those fields bit-exactly;
 *  - tampered image bytes abort the restore with NOTHING changed;
 *  - v1 envelopes (no v2 sections) still verify + restore with the legacy
 *    semantics (reviews/coupons untouched);
 *  - the build-side size ceiling fails loudly (BackupTooLargeError), never
 *    silently truncates.
 */

import { describe, expect, test, beforeAll, afterAll } from "bun:test";
import { mkdtempSync, rmSync, existsSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createHash, randomBytes } from "node:crypto";
import {
  ensureDemoEnv,
  getTestDb,
  type TestDb,
} from "./test-setup";
import { encryptField } from "@/lib/server/crypto-vault";

ensureDemoEnv();
/* isolated storage for image files + migration artifacts */
const TMP_STORAGE = mkdtempSync(join(tmpdir(), "ashrilogic-backup-test-"));
process.env.ASHRILOGIC_STORAGE_DIR = TMP_STORAGE;

let db: TestDb;
let backup: typeof import("@/lib/server/backup");
let imageStore: typeof import("@/lib/server/image-store");

const NOW = new Date();
const iso = (d: Date) => d.toISOString();

beforeAll(async () => {
  db = await getTestDb();
  backup = await import("@/lib/server/backup");
  imageStore = await import("@/lib/server/image-store");
});

afterAll(() => {
  rmSync(TMP_STORAGE, { recursive: true, force: true });
});

async function seedTenant(): Promise<string> {
  const instance = await db.instance.create({
    data: {
      id: "backup-test-instance",
      systemId: "clinic-dental",
      orgJson: JSON.stringify({ name: "Backup Test Clinic" }),
      adminJson: JSON.stringify({ name: "Owner", email: "owner@example.com" }),
      prefsJson: JSON.stringify({ lang: "ar" }),
      modulesJson: JSON.stringify(["inventory"]),
      createdAt: NOW,
    },
  });
  const site = await db.site.create({
    data: {
      id: "backup-test-site",
      instanceId: instance.id,
      published: true,
      theme: "aurora",
      views: 42,
      contentJson: JSON.stringify({ logoUrl: "" }),
      createdAt: NOW,
      updatedAt: NOW,
    },
  });
  void site;
  const customer = await db.siteCustomer.create({
    data: {
      id: "backup-test-customer",
      instanceId: instance.id,
      name: "Test Customer",
      /* real AES-256-GCM envelope — the fixture mirrors production rows so
         the key-compatibility gate is exercised against genuine sealed data */
      email: encryptField("cust@example.com")!,
      emailIndex: "idx-customer",
      phone: encryptField("+249900000000")!,
      passwordHash: "x",
      status: "active",
      emailVerifiedAt: NOW,
      lastLoginAt: NOW,
      addressesJson: JSON.stringify([
        { id: "addr1", label: "home", city: "Khartoum", isDefault: true },
      ]),
      paymentMethodsJson: JSON.stringify([
        { id: "pm1", brand: "visa", last4: "4242", expMonth: 12, expYear: 2030 },
      ]),
      createdAt: NOW,
      updatedAt: NOW,
    },
  });
  await db.siteOrder.create({
    data: {
      id: "backup-test-order",
      instanceId: instance.id,
      customerId: customer.id,
      itemsJson: JSON.stringify([{ recordId: "r1", name: "Item", price: 1000, qty: 2 }]),
      total: 2000,
      currency: "SAR",
      status: "confirmed",
      note: "leave at door",
      statusNote: "called",
      discount: 200,
      couponCode: "SAVE10",
      code: "A1B2C3",
      phoneIndex: "phone-idx",
      statusHistoryJson: JSON.stringify([
        { status: "pending", at: iso(NOW) },
        { status: "confirmed", note: "ok", at: iso(NOW) },
      ]),
      createdAt: NOW,
      updatedAt: NOW,
    },
  });
  await db.teamMember.create({
    data: {
      id: "backup-test-member",
      instanceId: instance.id,
      name: "Team Member",
      email: encryptField("member@example.com")!,
      role: "manager",
      profileJson: "enc:v1:fake-envelope",
      createdAt: NOW,
    },
  });
  await db.siteReview.create({
    data: {
      id: "backup-test-review",
      instanceId: instance.id,
      recordId: "r1",
      rating: 5,
      name: "Reviewer",
      body: "great",
      hidden: false,
      authorIndex: "author-idx",
      createdAt: NOW,
      updatedAt: NOW,
    },
  });
  await db.storeCoupon.create({
    data: {
      id: "backup-test-coupon",
      instanceId: instance.id,
      code: "SAVE10",
      kind: "percent",
      value: 10,
      minSubtotal: 500,
      maxUses: 100,
      usedCount: 3,
      active: true,
      createdAt: NOW,
      updatedAt: NOW,
    },
  });
  await db.moduleRecord.create({
    data: {
      id: "backup-test-record",
      instanceId: instance.id,
      moduleId: "inventory",
      dataJson: JSON.stringify(["Item", "", "10", "1000"]),
      statusKey: "in-stock",
      createdAt: NOW,
      updatedAt: NOW,
    },
  });
  return instance.id;
}

describe("backup envelope v2 — completeness", () => {
  test("every business field rides the envelope", async () => {
    const instanceId = await seedTenant();
    const envelope = await backup.buildInstanceBackup(instanceId);
    expect(envelope).not.toBeNull();
    const s = envelope!.sections;

    /* customer business fields */
    const c = s.customers[0]!;
    expect(c.addresses).toEqual([
      { id: "addr1", label: "home", city: "Khartoum", isDefault: true },
    ]);
    expect(c.paymentMethods).toEqual([
      { id: "pm1", brand: "visa", last4: "4242", expMonth: 12, expYear: 2030 },
    ]);
    expect(c.lastLoginAt).toBe(iso(NOW));
    expect(c.updatedAt).toBe(iso(NOW));

    /* order status history + timestamps */
    const o = s.orders[0]!;
    expect(o.statusHistory).toEqual([
      { status: "pending", at: iso(NOW) },
      { status: "confirmed", note: "ok", at: iso(NOW) },
    ]);
    expect(o.updatedAt).toBe(iso(NOW));
    expect(o.discountMinor).toBe(200);
    expect(o.couponCode).toBe("SAVE10");

    /* sealed team profile envelope */
    expect(s.team[0]!.profile).toBe("enc:v1:fake-envelope");

    /* reviews + coupons */
    expect(s.reviews).toHaveLength(1);
    expect(s.reviews![0]!.recordId).toBe("r1");
    expect(s.coupons).toHaveLength(1);
    expect(s.coupons![0]!.usedCount).toBe(3);

    /* meta accounting */
    expect(envelope!.meta.version).toBe(2);
    expect(envelope!.meta.imagesCount).toBe(0);
    expect(envelope!.meta.imagesMissing).toBe(0);
  });

  test("referenced images travel as verified bytes", async () => {
    const instanceId = "backup-test-instance";
    const bytes = randomBytes(2048);
    const stored = await imageStore.storeImageBuffer(bytes, {
      mime: "image/webp",
      width: 64,
      height: 64,
    });
    await db.moduleRecord.update({
      where: { id: "backup-test-record" },
      data: { imageRef: stored.url },
    });

    const envelope = await backup.buildInstanceBackup(instanceId);
    const entry = envelope!.sections.images?.[0];
    expect(entry).toBeDefined();
    expect(entry!.id).toBe(stored.id);
    expect(entry!.missing).toBeUndefined();
    expect(Buffer.from(entry!.dataBase64!, "base64").equals(bytes)).toBe(true);
    expect(envelope!.meta.imagesCount).toBe(1);
    expect(envelope!.meta.imagesMissing).toBe(0);
  });

  test("a missing image asset is COUNTED, never hidden", async () => {
    const instanceId = "backup-test-instance";
    /* point the record at a hash that has no file */
    const fakeHash = createHash("sha256").update("no-such-bytes").digest("hex");
    await db.moduleRecord.update({
      where: { id: "backup-test-record" },
      data: { imageRef: `/api/images/${fakeHash}` },
    });
    const envelope = await backup.buildInstanceBackup(instanceId);
    expect(envelope!.meta.imagesMissing).toBe(1);
    const entry = envelope!.sections.images?.find((i) => i.id === fakeHash);
    expect(entry?.missing).toBe(true);
    expect(entry?.dataBase64).toBeUndefined();

    /* verify reports ok:true but with the missing count surfaced */
    const verified = await backup.verifyInstanceBackup(instanceId, envelope);
    expect(verified.ok).toBe(true);
    expect(verified.meta?.imagesMissing).toBe(1);
  });

  test("restore round-trip preserves every v2 business field", async () => {
    const instanceId = "backup-test-instance";
    /* restore the good state (image ref still points at missing hash — counted) */
    const envelope = await backup.buildInstanceBackup(instanceId);

    /* mutate the live tenant so the restore actually changes state */
    await db.siteCustomer.update({
      where: { id: "backup-test-customer" },
      data: { addressesJson: null, paymentMethodsJson: null, name: "Wiped" },
    });
    await db.siteOrder.update({
      where: { id: "backup-test-order" },
      data: { statusHistoryJson: null, updatedAt: NOW },
    });
    await db.teamMember.update({
      where: { id: "backup-test-member" },
      data: { profileJson: null },
    });
    await db.siteReview.deleteMany({ where: { instanceId } });
    await db.storeCoupon.deleteMany({ where: { instanceId } });

    const result = await backup.restoreInstanceBackup(instanceId, envelope, {
      actorType: "instance",
      actorName: "test",
    });
    expect(result.ok).toBe(true);

    const customer = await db.siteCustomer.findUnique({
      where: { id: "backup-test-customer" },
    });
    expect(JSON.parse(customer!.addressesJson!)).toEqual([
      { id: "addr1", label: "home", city: "Khartoum", isDefault: true },
    ]);
    expect(JSON.parse(customer!.paymentMethodsJson!)[0].last4).toBe("4242");
    expect(customer!.name).toBe("Test Customer");
    expect(customer!.lastLoginAt?.getTime()).toBe(NOW.getTime());

    const order = await db.siteOrder.findUnique({
      where: { id: "backup-test-order" },
    });
    expect(JSON.parse(order!.statusHistoryJson!)).toHaveLength(2);
    expect(order!.updatedAt.getTime()).toBe(NOW.getTime());

    const member = await db.teamMember.findUnique({
      where: { id: "backup-test-member" },
    });
    expect(member!.profileJson).toBe("enc:v1:fake-envelope");

    expect(await db.siteReview.count({ where: { instanceId } })).toBe(1);
    expect(await db.storeCoupon.count({ where: { instanceId } })).toBe(1);
    const coupon = await db.storeCoupon.findFirst({ where: { instanceId } });
    expect(coupon!.usedCount).toBe(3);
  });

  test("tampered image bytes abort the restore with NOTHING changed", async () => {
    const instanceId = "backup-test-instance";
    const bytes = randomBytes(1024);
    const stored = await imageStore.storeImageBuffer(bytes, {
      mime: "image/webp",
    });
    await db.moduleRecord.update({
      where: { id: "backup-test-record" },
      data: { imageRef: stored.url },
    });
    const envelope = await backup.buildInstanceBackup(instanceId);

    /* corrupt the embedded bytes while keeping the envelope self-consistent
       (recompute the checksum — the image gate must catch it regardless) */
    envelope!.sections.images![0]!.dataBase64 = randomBytes(1024).toString("base64");
    const { createHash: ch } = await import("node:crypto");
    const canonical = JSON.stringify(envelope!.sections);
    envelope!.meta.checksum = ch("sha256").update(canonical, "utf8").digest("hex");

    const before = await db.moduleRecord.count({ where: { instanceId } });
    const result = await backup.restoreInstanceBackup(instanceId, envelope, {
      actorType: "instance",
      actorName: "test",
    });
    expect(result.ok).toBe(false);
    expect((result as { reason: string }).reason).toBe("image-checksum");
    /* nothing changed */
    expect(await db.moduleRecord.count({ where: { instanceId } })).toBe(before);
  });

  test("v1 envelopes (no v2 sections) still verify + restore (legacy semantics)", async () => {
    const instanceId = "backup-test-instance";
    const envelope = await backup.buildInstanceBackup(instanceId);
    /* strip v2 sections → a v1-shaped file */
    const v1 = {
      meta: { ...envelope!.meta, version: 1 },
      sections: {
        instance: envelope!.sections.instance,
        moduleRecords: envelope!.sections.moduleRecords,
        site: envelope!.sections.site,
        customers: envelope!.sections.customers.map((c) => ({
          id: c.id, emailSealed: c.emailSealed, name: c.name, phone: c.phone,
          status: c.status, emailVerifiedAt: c.emailVerifiedAt, createdAt: c.createdAt,
        })),
        orders: envelope!.sections.orders.map((o) => ({
          id: o.id, customerId: o.customerId, items: o.items, totalMinor: o.totalMinor,
          currency: o.currency, status: o.status, note: o.note, statusNote: o.statusNote,
          createdAt: o.createdAt,
        })),
        team: envelope!.sections.team.map((m) => ({
          id: m.id, name: m.name, emailSealed: m.emailSealed, role: m.role,
          createdAt: m.createdAt,
        })),
        activities: envelope!.sections.activities,
      },
    };
    const { createHash: ch } = await import("node:crypto");
    v1.meta.checksum = ch("sha256")
      .update(JSON.stringify(v1.sections), "utf8")
      .digest("hex");

    const verified = await backup.verifyInstanceBackup(instanceId, v1);
    expect(verified.ok).toBe(true);

    /* v1 restore keeps reviews/coupons untouched (legacy semantics) */
    const reviewCount = await db.siteReview.count({ where: { instanceId } });
    const result = await backup.restoreInstanceBackup(instanceId, v1, {
      actorType: "instance",
      actorName: "test",
    });
    expect(result.ok).toBe(true);
    expect(await db.siteReview.count({ where: { instanceId } })).toBe(reviewCount);
  });

  test("sealed envelopes the running key cannot open HALT the restore (key-rotation gate)", async () => {
    const instanceId = "backup-test-instance";
    const envelope = await backup.buildInstanceBackup(instanceId);

    /* simulate a backup produced under a DIFFERENT ASHRILOGIC_DATA_KEY:
       a well-formed enc:v1: envelope whose GCM tag cannot verify under the
       running vault key (tampered ciphertext = same auth failure shape) */
    const bad = envelope!.sections.customers[0]!.emailSealed;
    envelope!.sections.customers[0]!.emailSealed = bad.slice(0, -8) + "AAAAAAAA";
    const { createHash: ch } = await import("node:crypto");
    envelope!.meta.checksum = ch("sha256")
      .update(JSON.stringify(envelope!.sections), "utf8")
      .digest("hex");

    /* the file still VERIFIES (checksum is over the envelope, not the key) —
       the gate is restore-side by design */
    expect((await backup.verifyInstanceBackup(instanceId, envelope)).ok).toBe(true);

    const before = await db.siteCustomer.findUnique({
      where: { id: "backup-test-customer" },
    });
    const result = await backup.restoreInstanceBackup(instanceId, envelope, {
      actorType: "instance",
      actorName: "test",
    });
    expect(result.ok).toBe(false);
    expect((result as { reason: string }).reason).toBe("sealed-key-mismatch");

    /* nothing changed — the halt happened BEFORE any row was touched */
    const after = await db.siteCustomer.findUnique({
      where: { id: "backup-test-customer" },
    });
    expect(after!.name).toBe(before!.name);
    expect(await db.siteReview.count({ where: { instanceId } })).toBe(1);
    expect(await db.storeCoupon.count({ where: { instanceId } })).toBe(1);
  });
});

void existsSync;
