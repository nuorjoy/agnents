/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — PRECISE BLOG VIEW COUNTER (المدونة الرسمية).
 *
 * THE BUG (pre-fix): GET /api/blog/[slug] incremented BlogPost.views on
 * EVERY non-bot read — a plain fire-and-forget `views: { increment: 1 }`.
 * The reader's TanStack revalidation fires on every mount (no staleTime),
 * so one visitor refreshing the article (or a scripted loop with a
 * browser UA) inflated the PUBLIC counter without bound: refresh 100× →
 * +100 views. Nothing deduplicated, nothing rate-limited the bump, and a
 * crash between the ledger-less writes left no state to reconcile.
 *
 * THE FIX (src/lib/server/blog-views.ts): a BlogViewEvent ledger row per
 * (post, visitor, UTC day) inserted IN THE SAME TRANSACTION as the views
 * increment — the composite unique key is the exactly-once guarantee:
 *   1. first read of a post by a visitor TODAY counts (+1);
 *   2. every repeat read by the SAME visitor TODAY is a no-op ("duplicate"
 *      — the transaction rolls back on the unique violation, increment
 *      included);
 *   3. a DIFFERENT visitor TODAY counts;
 *   4. the same visitor TOMORROW counts again (UTC-day bucket rollover);
 *   5. CONCURRENT double-clicks (N parallel bumps, same key) land exactly
 *      ONE increment — the race the unique index closes (the pre-fix
 *      check-then-act era had no barrier at all);
 *   6. the per-IP bump budget throttles flood attempts ("throttled");
 *   7. the ROUTE (GET /api/blog/[slug]) keeps its exact response contract,
 *      skips bot user agents, skips seed-fallback articles, and never
 *      fails the article read because of the counter.
 *
 * DB isolation: throwaway PostgreSQL test database via test-setup (never
 * the live DB). The engine and the REAL route handler are both driven
 * directly (dynamic imports AFTER ensureDemoEnv() rebound DATABASE_URL).
 */
import { beforeAll, afterAll, describe, expect, test } from "bun:test";
import { ensureDemoEnv, getTestDb, resetRateTable, type TestDb } from "./test-setup";

/* CANONICAL ISOLATION PATTERN (test-setup's contract): every module that
 * transitively binds `@/lib/db` is imported DYNAMICALLY in beforeAll —
 * AFTER ensureDemoEnv() redirected DATABASE_URL to the throwaway test db.
 * A static import would hoist ABOVE the env override and bind the Prisma
 * singleton to the live DATABASE_URL. */
ensureDemoEnv();

const RUN = Math.random().toString(36).slice(2, 8);
const POST_ID = `blog-views-post-${RUN}`;
const POST_SLUG = `blog-views-${RUN}`;

let db: TestDb;
let views: typeof import("@/lib/server/blog-views");
let feed: typeof import("@/lib/server/blog-feed");
let route: typeof import("@/app/api/blog/[slug]/route");

const BROWSER_UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";
const BOT_UA = "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)";

/** A request as the route sees it — distinct x-forwarded-for per visitor
 *  (the rightmost XFF hop is the client IP in the dev "always" mode). */
function articleReq(slug: string, ip: string, ua: string = BROWSER_UA): Request {
  return new Request(`http://localhost:3000/api/blog/${slug}`, {
    headers: { "user-agent": ua, "x-forwarded-for": ip },
  });
}

async function viewsOf(postId: string): Promise<number> {
  const row = await db.blogPost.findUnique({ where: { id: postId }, select: { views: true } });
  return row?.views ?? -1;
}

/** Let any detached post-response bump from a previous test finish landing
 *  before a delta assertion reads its baseline (deterministic baselines). */
async function settle(ms = 500): Promise<void> {
  await new Promise((r) => setTimeout(r, ms));
}

/** Poll until the detached post-response bump lands (the route schedules
 *  it fire-and-forget — deterministic wait for the regression asserts). */
async function untilViews(postId: string, expected: number, timeoutMs = 4000): Promise<number> {
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    const current = await viewsOf(postId);
    if (current === expected) return current;
    if (Date.now() > deadline) return current;
    await new Promise((r) => setTimeout(r, 25));
  }
}

beforeAll(async () => {
  db = await getTestDb();
  views = await import("@/lib/server/blog-views");
  feed = await import("@/lib/server/blog-feed");
  route = await import("@/app/api/blog/[slug]/route");

  /* one PUBLISHED article — the exact row the public route serves */
  await db.blogPost.deleteMany({ where: { id: POST_ID } });
  await db.blogPost.create({
    data: {
      id: POST_ID,
      slug: POST_SLUG,
      titleAr: "عدّاد المشاهدات الدقيق",
      titleEn: "The precise views counter",
      excerptAr: "اختبار انحدار",
      excerptEn: "regression",
      contentAr: "المحتوى",
      contentEn: "body",
      tagsJson: JSON.stringify(["growth"]),
      status: "published",
      publishedAt: new Date(),
      views: 0,
    },
  });
  /* every fresh reader IP below is unique per run — no limiter carryover */
  await resetRateTable(db);
});

afterAll(async () => {
  try {
    await db.blogViewEvent.deleteMany({ where: { postId: POST_ID } });
    await db.blogPost.deleteMany({ where: { id: POST_ID } });
  } catch {
    /* throwaway DB */
  }
});

describe("blog-views engine — exactly-once per (post, visitor, UTC day)", () => {
  test("first read by a visitor today COUNTS (+1)", async () => {
    const outcome = await views.recordBlogPostView(articleReq(POST_SLUG, "198.51.100.10"), POST_ID);
    expect(outcome).toBe("counted");
    expect(await viewsOf(POST_ID)).toBe(1);
  });

  test("repeat reads by the SAME visitor today are no-ops", async () => {
    for (let i = 0; i < 5; i++) {
      const outcome = await views.recordBlogPostView(articleReq(POST_SLUG, "198.51.100.10"), POST_ID);
      expect(outcome).toBe("duplicate");
    }
    expect(await viewsOf(POST_ID)).toBe(1);
  });

  test("a DIFFERENT visitor today counts (+1)", async () => {
    const outcome = await views.recordBlogPostView(articleReq(POST_SLUG, "198.51.100.11"), POST_ID);
    expect(outcome).toBe("counted");
    expect(await viewsOf(POST_ID)).toBe(2);
  });

  test("the same visitor TOMORROW counts again (UTC-day rollover)", async () => {
    const day = views.blogViewDay(new Date(Date.now() + 26 * 60 * 60 * 1000));
    const outcome = await views.bumpBlogPostViewOnce(POST_ID, "visitor-tomorrow", day);
    expect(outcome).toBe("counted");
    expect(await viewsOf(POST_ID)).toBe(3);
  });

  test("RACE: N concurrent bumps from one visitor land exactly ONE increment", async () => {
    /* a fresh visitor + fresh day bucket so the ledger is empty for the key */
    const raceDay = views.blogViewDay(new Date(Date.now() + 48 * 60 * 60 * 1000));
    const before = await viewsOf(POST_ID);
    const outcomes = await Promise.all(
      Array.from({ length: 8 }, () =>
        views.bumpBlogPostViewOnce(POST_ID, "visitor-race", raceDay)
      )
    );
    /* exactly one "counted"; the other 7 are unique-violation rollbacks */
    expect(outcomes.filter((o) => o === "counted").length).toBe(1);
    expect(outcomes.filter((o) => o === "duplicate").length).toBe(7);
    expect(await viewsOf(POST_ID)).toBe(before + 1);
  });

  test("per-IP bump budget throttles floods (fail-open for the article)", async () => {
    /* fresh rate table + a dedicated flood IP: the rule allows 90 bump
     * attempts per 10 minutes — the 91st from the same IP is throttled */
    await resetRateTable(db);
    let last = "";
    for (let i = 0; i < views.BLOG_VIEW_RULE.limit + 1; i++) {
      last = await views.recordBlogPostView(articleReq(POST_SLUG, "203.0.113.99"), POST_ID);
    }
    expect(last).toBe("throttled");
  });

  test("the day bucket is deterministic UTC midnight", () => {
    const a = views.blogViewDay(new Date("2026-10-02T09:41:23.987Z"));
    const b = views.blogViewDay(new Date("2026-10-02T23:59:59.999Z"));
    expect(a.getTime()).toBe(Date.UTC(2026, 9, 2));
    expect(a.getTime()).toBe(b.getTime());
  });

  test("visitor keys are blind indexes — stable per IP, never the raw IP", () => {
    const k1 = views.blogVisitorKey(articleReq(POST_SLUG, "198.51.100.10"));
    const k2 = views.blogVisitorKey(articleReq(POST_SLUG, "198.51.100.10"));
    const k3 = views.blogVisitorKey(articleReq(POST_SLUG, "198.51.100.12"));
    expect(k1).toBe(k2);
    expect(k1).not.toBe(k3);
    expect(k1).toMatch(/^[0-9a-f]{64}$/);
    expect(k1.includes("198.51.100.10")).toBe(false);
  });
});

describe("GET /api/blog/[slug] — route integration (contract preserved)", () => {
  test("serves the article with the SAME response shape", async () => {
    const res = await route.GET(articleReq(POST_SLUG, "198.51.100.20"), {
      params: Promise.resolve({ slug: POST_SLUG }),
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as Record<string, unknown>;
    expect(body.id).toBe(POST_ID);
    expect(typeof body.views).toBe("number");
    expect(Array.isArray(body.related)).toBe(true);
    expect(body.prev === null || typeof body.prev === "object").toBe(true);
    expect(body.next === null || typeof body.next === "object").toBe(true);
    /* the route-internal fromDb flag must never leak into the payload */
    expect("fromDb" in body).toBe(false);
  });

  test("a human read counts exactly once — the refresh storm lands +1", async () => {
    await settle(); /* prior detached bumps must land before the baseline */
    await resetRateTable(db);
    const before = await viewsOf(POST_ID);
    for (let i = 0; i < 4; i++) {
      const res = await route.GET(articleReq(POST_SLUG, "198.51.100.30"), {
        params: Promise.resolve({ slug: POST_SLUG }),
      });
      expect(res.status).toBe(200);
    }
    /* exactly ONE increment for the whole storm — never +4 */
    expect(await untilViews(POST_ID, before + 1)).toBe(before + 1);
    expect(await viewsOf(POST_ID)).toBe(before + 1);
  }, 15_000);

  test("BOT user agents never count", async () => {
    await settle();
    const before = await viewsOf(POST_ID);
    for (let i = 0; i < 3; i++) {
      const res = await route.GET(articleReq(POST_SLUG, "198.51.100.40", BOT_UA), {
        params: Promise.resolve({ slug: POST_SLUG }),
      });
      expect(res.status).toBe(200);
    }
    await settle(200);
    expect(await viewsOf(POST_ID)).toBe(before);
  }, 15_000);

  test("unknown slug → HTTP 404 (drafts/missing never serve, never count)", async () => {
    const res = await route.GET(articleReq("no-such-slug", "198.51.100.50"), {
      params: Promise.resolve({ slug: "no-such-slug" }),
    });
    expect(res.status).toBe(404);
  });

  test("seed-fallback article (no DB row) serves WITHOUT counting", async () => {
    /* empty published set → loadBlogArticle falls back to the seed posts;
     * fromDb=false means the counter never fires for a seed slug */
    await settle();
    const viewsBeforeDelete = await viewsOf(POST_ID);
    const rowsBefore = await db.blogViewEvent.count();
    await db.blogPost.deleteMany({ where: { id: POST_ID } });
    try {
      const seedSlug = (await import("@/lib/server/blog-seed")).BLOG_SEED_POSTS[0]?.slug ?? "";
      expect(seedSlug).not.toBe("");
      const res = await route.GET(articleReq(seedSlug, "198.51.100.60"), {
        params: Promise.resolve({ slug: seedSlug }),
      });
      expect(res.status).toBe(200);
      const body = (await res.json()) as { id?: string };
      expect(body.id).not.toBe("");
      await settle(200);
      /* NO new ledger rows were created — a seed read counts nothing */
      const rowsAfter = await db.blogViewEvent.count();
      expect(rowsAfter).toBe(rowsBefore);
    } finally {
      await db.blogPost.create({
        data: {
          id: POST_ID,
          slug: POST_SLUG,
          titleAr: "عدّاد المشاهدات الدقيق",
          titleEn: "The precise views counter",
          excerptAr: "اختبار انحدار",
          excerptEn: "regression",
          contentAr: "المحتوى",
          contentEn: "body",
          tagsJson: JSON.stringify(["growth"]),
          status: "published",
          publishedAt: new Date(),
          views: Math.max(0, viewsBeforeDelete),
        },
      });
    }
  }, 15_000);

  test("looksLikeBot — the ambient-crawler guard stays intact", () => {
    expect(feed.looksLikeBot(BROWSER_UA)).toBe(false);
    expect(feed.looksLikeBot(BOT_UA)).toBe(true);
    expect(feed.looksLikeBot("curl/8.0")).toBe(true);
    expect(feed.looksLikeBot(null)).toBe(true);
  });
});
