/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — RECEIPT LINK TOKENS (ROUND 119).
 *
 * Proves the standalone receipt link's capability semantics:
 *  - issue → verify round-trip (claims + binding);
 *  - a token scoped to site A never verifies against site B's page (the
 *    page's instanceId check is the second half — verifyReceiptToken
 *    returns the claims, the PAGE compares);
 *  - expiry: a TTL of 0 is expired the moment it exists; a long TTL lives;
 *  - tampering: a rewritten payload (orderId swapped) breaks the MAC; a
 *    rewritten MAC breaks verification; garbage input (not even a token
 *    shape) is refused without throwing;
 *  - the token is a DIFFERENT keyed primitive: a session token (admin
 *    scope, signed under ADMIN_SESSION_SECRET) never verifies here, and
 *    vice versa — purpose separation in practice.
 */
import { beforeAll, describe, expect, test } from "bun:test";
import { ensureDemoEnv, getTestDb, type TestDb } from "./test-setup";

let db: TestDb;

beforeAll(async () => {
  db = await getTestDb();
  await db.siteOrder.deleteMany({});
  await db.instance.deleteMany({});
});

async function mod() {
  ensureDemoEnv();
  return import("@/lib/server/receipt-token");
}

describe("receipt link tokens — capability semantics", () => {
  test("issue → verify round-trip returns the exact claims", async () => {
    const m = await mod();
    const token = m.issueReceiptToken("inst-a", "order-1");
    expect(typeof token).toBe("string");
    expect(token.length).toBeGreaterThan(40);
    const claims = m.verifyReceiptToken(token);
    expect(claims).not.toBeNull();
    expect(claims?.instanceId).toBe("inst-a");
    expect(claims?.orderId).toBe("order-1");
  });

  test("cross-site binding: the claims carry the site — a foreign page refuses", async () => {
    const m = await mod();
    const token = m.issueReceiptToken("inst-a", "order-1");
    const claims = m.verifyReceiptToken(token);
    /* the page's own gate: claims.instanceId MUST equal the route id */
    expect(claims?.instanceId === "inst-b").toBe(false);
  });

  test("expiry: ttl 0 is dead on arrival; the default 30d lives", async () => {
    const m = await mod();
    const dead = m.issueReceiptToken("inst-a", "order-1", 0);
    expect(m.verifyReceiptToken(dead)).toBeNull();

    const alive = m.issueReceiptToken("inst-a", "order-1", 60_000);
    expect(m.verifyReceiptToken(alive)).not.toBeNull();

    /* the default TTL is the documented 30 days */
    expect(m.RECEIPT_TOKEN_TTL_MS).toBe(30 * 24 * 60 * 60 * 1000);
  });

  test("tampered payload (orderId swapped) breaks the MAC", async () => {
    const m = await mod();
    const token = m.issueReceiptToken("inst-a", "order-1");
    const [body, mac] = token.split(".");
    /* decode → rewrite orderId → re-encode with the ORIGINAL mac */
    const payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8")) as Record<string, unknown>;
    payload.orderId = "order-2";
    const forgedBody = Buffer.from(JSON.stringify(payload)).toString("base64url");
    expect(m.verifyReceiptToken(`${forgedBody}.${mac}`)).toBeNull();
  });

  test("tampered MAC is refused", async () => {
    const m = await mod();
    const token = m.issueReceiptToken("inst-a", "order-1");
    const [body] = token.split(".");
    const forgedMac = Buffer.from("0".repeat(32)).toString("base64url");
    expect(m.verifyReceiptToken(`${body}.${forgedMac}`)).toBeNull();
  });

  test("garbage inputs are refused without throwing", async () => {
    const m = await mod();
    for (const garbage of ["", "   ", "not-a-token", "a.b", "....", "x".repeat(600), null, undefined, 42, {}]) {
      expect(m.verifyReceiptToken(garbage)).toBeNull();
    }
  });

  test("purpose separation: session tokens never verify as receipt links", async () => {
    const m = await mod();
    ensureDemoEnv();
    const { issueToken } = await import("@/lib/server/tokens");
    /* an admin session token signed under ADMIN_SESSION_SECRET (demo
       constant in tests — a DIFFERENT key stream than the HKDF receipt
       key even on the same data key) */
    const session = issueToken("admin", "some-admin-id", 60_000);
    expect(m.verifyReceiptToken(session.token)).toBeNull();

    /* and the reverse: a receipt token is not a session token */
    const { verifyToken } = await import("@/lib/server/tokens");
    const receipt = m.issueReceiptToken("inst-a", "order-1");
    expect(verifyToken(receipt, "admin")).toBeNull();
    expect(verifyToken(receipt, "customer")).toBeNull();
  });

  test("two tokens for different orders are distinct and both verify", async () => {
    const m = await mod();
    const t1 = m.issueReceiptToken("inst-a", "order-1");
    const t2 = m.issueReceiptToken("inst-a", "order-2");
    expect(t1).not.toBe(t2);
    expect(m.verifyReceiptToken(t1)?.orderId).toBe("order-1");
    expect(m.verifyReceiptToken(t2)?.orderId).toBe("order-2");
  });
});
