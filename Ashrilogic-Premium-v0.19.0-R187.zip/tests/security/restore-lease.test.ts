/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — RESTORE LEASE + MAINTENANCE WINDOW (ROUND 96).
 *
 * Proves the cross-process restore machinery:
 *  - acquire/release semantics: one holder at a time; a second acquirer is
 *    refused; release only ever drops the OWN lease;
 *  - stale-lease takeover: an EXPIRED lease (crashed worker) is taken over
 *    by the next acquirer, and mid-flight checks treat it as absent;
 *  - the maintenance window: tenant-scoped MUTATING requests get a 503
 *    MAINTENANCE + Retry-After while the lease is live; GETs pass;
 *  - the restore engine itself: a held lease makes restoreInstanceBackup
 *    fail fast with RESTORE_IN_PROGRESS BEFORE touching the envelope.
 */
import { beforeAll, describe, expect, test } from "bun:test";
import { getTestDb, type TestDb } from "./test-setup";
import type { RestoreLeaseToken } from "@/lib/server/maintenance";

let db: TestDb;
let maintenance: typeof import("@/lib/server/maintenance");
let backup: typeof import("@/lib/server/backup");

beforeAll(async () => {
  db = await getTestDb();
  await db.restoreLease.deleteMany();
  maintenance = await import("@/lib/server/maintenance");
  backup = await import("@/lib/server/backup");
});

const TENANT = "lease-test-tenant";

describe("restore lease — acquire / release / takeover", () => {
  test("first acquire wins; a concurrent acquirer is refused", async () => {
    const first = await maintenance.acquireRestoreLease(TENANT);
    expect(first).not.toBeNull();
    const second = await maintenance.acquireRestoreLease(TENANT);
    expect(second).toBeNull();
    /* the maintenance window is live while the lease holds */
    expect(await maintenance.isRestoreInFlight(TENANT)).toBe(true);
    await maintenance.releaseRestoreLease(first as RestoreLeaseToken);
  });

  test("release never drops ANOTHER holder's lease (WHERE holder = self)", async () => {
    const a = await maintenance.acquireRestoreLease(TENANT);
    expect(a).not.toBeNull();
    /* a forged token pretending to be another worker must not release it */
    await maintenance.releaseRestoreLease({ instanceId: TENANT, holder: "not-the-holder" });
    expect(await maintenance.isRestoreInFlight(TENANT)).toBe(true);
    await maintenance.releaseRestoreLease(a as RestoreLeaseToken);
    expect(await maintenance.isRestoreInFlight(TENANT)).toBe(false);
  });

  test("an EXPIRED lease is taken over by the next acquirer (crashed worker recovery)", async () => {
    /* seed a stale lease that expired a minute ago */
    await db.restoreLease.create({
      data: {
        instanceId: TENANT,
        holder: "dead-worker",
        acquiredAt: new Date(Date.now() - 20 * 60_000),
        expiresAt: new Date(Date.now() - 60_000),
      },
    });
    /* mid-flight checks treat the expired lease as ABSENT (tenant not wedged) */
    expect(await maintenance.isRestoreInFlight(TENANT)).toBe(false);
    /* the next acquirer takes it over */
    const takeover = await maintenance.acquireRestoreLease(TENANT);
    expect(takeover).not.toBeNull();
    expect(await maintenance.isRestoreInFlight(TENANT)).toBe(true);
    await maintenance.releaseRestoreLease(takeout(takeover));
  });

  test("a LIVE foreign lease cannot be taken over even under expiry pressure", async () => {
    const a = await maintenance.acquireRestoreLease(TENANT);
    expect(a).not.toBeNull();
    const b = await maintenance.acquireRestoreLease(TENANT);
    expect(b).toBeNull();
    await maintenance.releaseRestoreLease(takeout(a));
  });
});

function takeout<T>(value: T | null): T {
  if (value === null) throw new Error("lease unexpectedly null");
  return value;
}

describe("maintenance window — mutating surfaces", () => {
  test("POST while a restore is in flight → 503 MAINTENANCE + Retry-After", async () => {
    const lease = await maintenance.acquireRestoreLease(TENANT);
    expect(lease).not.toBeNull();

    const post = new Request("http://localhost:3000/api/probe", { method: "POST" });
    const block = await maintenance.maintenanceBlock(TENANT, post);
    expect(block).not.toBeNull();
    expect(block?.status).toBe(503);
    expect(block?.headers.get("Retry-After")).toBe("30");
    const body = (await block?.json()) as { code?: string; error?: string };
    expect(body.code).toBe("MAINTENANCE");
    expect(typeof body.error).toBe("string");

    await maintenance.releaseRestoreLease(takeout(lease));
  });

  test("GET passes even while the lease is live (MVCC snapshot reads)", async () => {
    const lease = await maintenance.acquireRestoreLease(TENANT);
    expect(lease).not.toBeNull();

    const get = new Request("http://localhost:3000/api/probe", { method: "GET" });
    expect(await maintenance.maintenanceBlock(TENANT, get)).toBeNull();

    await maintenance.releaseRestoreLease(takeout(lease));
  });

  test("no lease → mutations pass (zero-cost when idle)", async () => {
    const post = new Request("http://localhost:3000/api/probe", { method: "PATCH" });
    expect(await maintenance.maintenanceBlock(TENANT, post)).toBeNull();
  });

  test("other tenants are unaffected (per-tenant scoping)", async () => {
    const lease = await maintenance.acquireRestoreLease(TENANT);
    expect(lease).not.toBeNull();

    const otherPost = new Request("http://localhost:3000/api/probe", { method: "POST" });
    expect(await maintenance.maintenanceBlock("a-different-tenant", otherPost)).toBeNull();

    await maintenance.releaseRestoreLease(takeout(lease));
  });
});

describe("restore engine — lease integration", () => {
  test("a held lease makes restoreInstanceBackup fail fast BEFORE touching the envelope", async () => {
    const lease = await maintenance.acquireRestoreLease(TENANT);
    expect(lease).not.toBeNull();

    /* a garbage envelope must NOT even be parsed — the lease check fires
       first, so the reason is the contention, never the envelope */
    const result = await backup.restoreInstanceBackup(TENANT, { garbage: true }, {
      actorType: "admin",
      actorName: "probe",
    });
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.reason).toBe("restore-in-progress");

    await maintenance.releaseRestoreLease(takeout(lease));

    /* with the lease free, the SAME garbage envelope goes down the normal
       verification path (a file failure, never contention) */
    const after = await backup.restoreInstanceBackup(TENANT, { garbage: true }, {
      actorType: "admin",
      actorName: "probe",
    });
    expect(after.ok).toBe(false);
    if (!after.ok) expect(after.reason).not.toBe("restore-in-progress");
  });
});
