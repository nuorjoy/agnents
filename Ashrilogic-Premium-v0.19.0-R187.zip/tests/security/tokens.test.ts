/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — session token HMAC layer (src/lib/server/tokens.ts).
 *
 * Regressions covered (Task 2 fixes):
 *  1. production mode FAILS FAST without a >= 32 char ADMIN_SESSION_SECRET
 *     (previously it silently signed with a public demo constant);
 *  2. a token forged with the OLD PUBLIC source constant
 *     ("ashrilogic-v2-demo-session-secret", pre-fix hardcoded secret) is
 *     REJECTED — source-code knowledge must not yield session forgery;
 *  3. pre-rollover tokens verify ONLY when the operator explicitly
 *     provisions LEGACY_SESSION_SECRET (env), and never without it;
 *  4. scope binding, expiry, malformed-input hardening, roundtrip fidelity.
 *
 * Module state is load-time (secrets bind at import), so production-mode
 * cases run in SUBPROCESSES (`bun -e`) with their own environment.
 */
import { describe, test, expect, beforeAll } from "bun:test";
import { createHmac } from "node:crypto";
import { spawnSync } from "node:child_process";
import { join } from "node:path";
import { ensureDemoEnv, REPO_ROOT } from "./test-setup";

type TokensModule = typeof import("@/lib/server/tokens");
let tokens: TokensModule;

const TOKENS_PATH = join(REPO_ROOT, "src", "lib", "server", "tokens.ts");

/** The pre-fix hardcoded secret — public source knowledge an attacker has. */
const OLD_PUBLIC_SECRET = "ashrilogic-v2-demo-session-secret";
/** The documented DEV fallback (sandbox only — see tokens.ts). */
const DEV_FALLBACK_SECRET = "ashrilogic-demo-session-secret";

const STRONG_CURRENT = "current-signing-secret-aaaaaaaaaaaaaaaaaaaaaaaaa"; // 44 chars
const STRONG_LEGACY = "legacy-rollover-secret-bbbbbbbbbbbbbbbbbbbbbbbbbb"; // 47 chars

/** Craft a `body.mac` token exactly like the module does — attacker-style. */
function craft(secret: string, payload: Record<string, unknown>): string {
  const body = Buffer.from(JSON.stringify(payload), "utf8").toString("base64url");
  const mac = createHmac("sha256", secret).update(body).digest("base64url");
  return `${body}.${mac}`;
}

/** Child env: clean base (no provisioned secrets) + explicit overrides. */
type ChildEnv = { NODE_ENV: "development" | "production" | "test" } & Record<string, string>;

function childEnv(overrides: ChildEnv): NodeJS.ProcessEnv {
  const base: Record<string, string> = {};
  for (const [key, value] of Object.entries(process.env)) {
    if (typeof value === "string") base[key] = value;
  }
  delete base.ADMIN_SESSION_SECRET;
  delete base.LEGACY_SESSION_SECRET;
  delete base.ASHRILOGIC_DATA_KEY;
  return { ...base, ...overrides };
}

interface ChildResult {
  status: number | null;
  stdout: string;
  stderr: string;
}

function runBun(script: string, env: NodeJS.ProcessEnv): ChildResult {
  const child = spawnSync(process.execPath, ["-e", script], {
    encoding: "utf8",
    env,
    cwd: REPO_ROOT,
    timeout: 60_000,
  });
  return { status: child.status, stdout: child.stdout ?? "", stderr: child.stderr ?? "" };
}

beforeAll(async () => {
  // dev mode, demo fallback secret active, no legacy secret provisioned
  ensureDemoEnv();
  tokens = await import("@/lib/server/tokens");
});

describe("tokens — production secret fail-fast (subprocess)", () => {
  test("production with NO ADMIN_SESSION_SECRET exits non-zero with the fail-fast error", () => {
    /* bun auto-loads .env in the subprocess; an explicit EMPTY value (which
       real env vars win over) pins the "unprovisioned" case deterministically. */
    const result = runBun(
      `await import(${JSON.stringify(TOKENS_PATH)}); console.log("LOADED")`,
      childEnv({ NODE_ENV: "production", ADMIN_SESSION_SECRET: "" })
    );
    expect(result.status).not.toBe(0);
    expect(result.status).not.toBe(null);
    expect(result.stderr).toContain("ADMIN_SESSION_SECRET");
    expect(result.stdout).not.toContain("LOADED");
  });

  test("production with a SHORT (< 32 chars) secret exits non-zero too", () => {
    const result = runBun(
      `await import(${JSON.stringify(TOKENS_PATH)}); console.log("LOADED")`,
      childEnv({ NODE_ENV: "production", ADMIN_SESSION_SECRET: "short-secret-1234567890" }) // 24 chars
    );
    expect(result.status).not.toBe(0);
    expect(result.stderr).toContain("ADMIN_SESSION_SECRET");
  });

  test("production with a >= 32 char secret loads, signs and verifies fine", () => {
    const script = `
      const mod = await import(${JSON.stringify(TOKENS_PATH)});
      const { token } = mod.issueToken("admin", "prod-sub", 60000, 4);
      const payload = mod.verifyToken(token, "admin");
      if (!payload || payload.sub !== "prod-sub" || payload.ver !== 4) {
        console.error("ROUNDTRIP_FAILED");
        process.exit(3);
      }
      console.log("LOADED_AND_SIGNS");
    `;
    const result = runBun(
      script,
      childEnv({ NODE_ENV: "production", ADMIN_SESSION_SECRET: STRONG_CURRENT })
    );
    expect(result.status).toBe(0);
    expect(result.stdout).toContain("LOADED_AND_SIGNS");
  });
});

describe("tokens — legacy secret migration window (subprocess)", () => {
  // One script: craft a token signed with the LEGACY secret (pre-rollover)
  // plus a token signed with the CURRENT secret, then report verification.
  const rolloverScript = `
    const { createHmac } = await import("node:crypto");
    const LEGACY = ${JSON.stringify(STRONG_LEGACY)};
    const CURRENT = ${JSON.stringify(STRONG_CURRENT)};
    function craft(secret, payload) {
      const body = Buffer.from(JSON.stringify(payload), "utf8").toString("base64url");
      return body + "." + createHmac("sha256", secret).update(body).digest("base64url");
    }
    const legacyToken = craft(LEGACY, { scope: "admin", sub: "legacy-rollover-sub", ver: 3, exp: Date.now() + 60000 });
    const currentToken = craft(CURRENT, { scope: "admin", sub: "current-sub", ver: 0, exp: Date.now() + 60000 });
    const mod = await import(${JSON.stringify(TOKENS_PATH)});
    const legacy = mod.verifyToken(legacyToken, "admin");
    const current = mod.verifyToken(currentToken, "admin");
    console.log(JSON.stringify({
      legacySub: legacy ? legacy.sub : null,
      currentSub: current ? current.sub : null,
    }));
  `;

  test("explicit LEGACY_SESSION_SECRET accepts pre-rollover tokens (verification only)", () => {
    const result = runBun(
      rolloverScript,
      childEnv({
        NODE_ENV: "production",
        ADMIN_SESSION_SECRET: STRONG_CURRENT,
        LEGACY_SESSION_SECRET: STRONG_LEGACY,
      })
    );
    expect(result.status).toBe(0);
    const report = JSON.parse(result.stdout.trim()) as { legacySub: string | null; currentSub: string | null };
    expect(report.legacySub).toBe("legacy-rollover-sub");
    expect(report.currentSub).toBe("current-sub");
  });

  test("the SAME pre-rollover token is null WITHOUT the legacy env (no source constants honored)", () => {
    const result = runBun(
      rolloverScript,
      childEnv({ NODE_ENV: "production", ADMIN_SESSION_SECRET: STRONG_CURRENT })
    );
    expect(result.status).toBe(0);
    const report = JSON.parse(result.stdout.trim()) as { legacySub: string | null; currentSub: string | null };
    expect(report.legacySub).toBeNull();
    expect(report.currentSub).toBe("current-sub");
  });
});

describe("tokens — forgery with public/source constants (in-process, dev)", () => {
  test("forged token signed with the OLD public source constant is REJECTED", () => {
    const forged = craft(OLD_PUBLIC_SECRET, {
      scope: "admin",
      sub: "attacker",
      ver: 0,
      exp: Date.now() + 60_000,
    });
    expect(tokens.verifyToken(forged, "admin")).toBeNull();
  });

  test("documented dev-only fallback: the demo secret DOES verify in development", () => {
    // This suite runs in dev mode with ADMIN_SESSION_SECRET unset — the
    // fallback is the active signer. Documents that acceptance of the
    // demo secret is confined to non-production, env-secret-unset runs
    // (production fail-fast is proven by the subprocess tests above).
    const devToken = craft(DEV_FALLBACK_SECRET, {
      scope: "admin",
      sub: "dev-user",
      ver: 0,
      exp: Date.now() + 60_000,
    });
    const payload = tokens.verifyToken(devToken, "admin");
    expect(payload).not.toBeNull();
    expect(payload?.sub).toBe("dev-user");
  });
});

describe("tokens — scope binding, expiry, malformed input", () => {
  test("wrong scope: an instance token cannot verify as admin", () => {
    const { token } = tokens.issueToken("instance", "inst-1", 60_000, 0);
    expect(tokens.verifyToken(token, "admin")).toBeNull();
    // and it DOES verify on its own surface
    expect(tokens.verifyToken(token, "instance")?.sub).toBe("inst-1");
  });

  test("expired token is rejected", () => {
    const { token } = tokens.issueToken("admin", "expired-sub", -60_000, 0);
    expect(tokens.verifyToken(token, "admin")).toBeNull();
    // hand-crafted, correctly signed, exp in the past → also null
    const past = craft(DEV_FALLBACK_SECRET, {
      scope: "admin",
      sub: "expired-sub",
      ver: 0,
      exp: Date.now() - 1000,
    });
    expect(tokens.verifyToken(past, "admin")).toBeNull();
  });

  test("malformed / hostile inputs return null (never throw)", () => {
    const goodBody = Buffer.from(
      JSON.stringify({ scope: "admin", sub: "x", ver: 0, exp: Date.now() + 60_000 }),
      "utf8"
    ).toString("base64url");
    const goodMac = createHmac("sha256", DEV_FALLBACK_SECRET).update(goodBody).digest("base64url");
    const notJsonBody = Buffer.from("definitely not json", "utf8").toString("base64url");
    const notJsonMac = createHmac("sha256", DEV_FALLBACK_SECRET).update(notJsonBody).digest("base64url");

    const hostile: (string | undefined)[] = [
      undefined,
      "",
      "   ",
      "abc", // no dot
      "a.b", // body not decodable JSON
      ".", // dot at 0
      "x.", // empty mac
      ".y", // dot at 0 again
      `${goodBody}.${goodMac.slice(0, goodMac.length - 2)}`, // truncated mac
      `${notJsonBody}.${notJsonMac}`, // valid MAC over non-JSON body
      craft(DEV_FALLBACK_SECRET, { scope: "admin", ver: 0, exp: Date.now() + 60_000 }), // missing sub
      craft(DEV_FALLBACK_SECRET, { scope: "admin", sub: "x", ver: 0, exp: "not-a-number" }), // exp wrong type
      craft(DEV_FALLBACK_SECRET, { scope: "viewer", sub: "x", ver: 0, exp: Date.now() + 60_000 }), // unknown scope value
    ];
    for (const input of hostile) {
      expect(tokens.verifyToken(input, "admin")).toBeNull();
    }
  });

  test("valid roundtrip preserves the payload (scope/sub/ver)", () => {
    const { token, expiresAt } = tokens.issueToken("admin", "sub-42", 60_000, 7);
    const payload = tokens.verifyToken(token, "admin");
    expect(payload).not.toBeNull();
    expect(payload?.scope).toBe("admin");
    expect(payload?.sub).toBe("sub-42");
    expect(payload?.ver).toBe(7);
    expect(payload?.exp).toBeGreaterThan(Date.now());
    expect(expiresAt.getTime()).toBe(payload?.exp ?? 0);
  });

  test("ver field is optional — defaults to 0 at issuance, tolerated absent on verify", () => {
    // issuance default
    const { token } = tokens.issueToken("admin", "ver-default", 60_000);
    expect(tokens.verifyToken(token, "admin")?.ver).toBe(0);
    // hand-crafted payload WITHOUT ver still verifies (backward compatibility)
    const noVer = craft(DEV_FALLBACK_SECRET, {
      scope: "admin",
      sub: "no-ver",
      exp: Date.now() + 60_000,
    });
    const payload = tokens.verifyToken(noVer, "admin");
    expect(payload).not.toBeNull();
    expect(payload?.ver).toBeUndefined();
  });
});
