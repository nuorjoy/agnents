/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — RECEIPT QR + EMAIL RECEIPT LINK (ROUND 121).
 *
 * Proves the two new receipt-link surfaces:
 *
 *  1. GET /api/sites/[id]/receipt-qr — the server-minted QR endpoint:
 *     a VALID, THIS-site token mints an SVG (private cache — the URL is a
 *     bearer capability); garbage / expired / CROSS-SITE tokens are plain
 *     404s (the endpoint can never mint a QR for arbitrary URLs or for
 *     another site's orders).
 *
 *  2. The order-status EMAIL template — the receiptUrl line is purely
 *     ADDITIVE: absent receiptUrl renders byte-identical to the classic
 *     notice (no receipt artifacts); present receiptUrl adds the text
 *     line + the HTML secondary link carrying the exact encoded URL.
 *
 * DB isolation: throwaway PostgreSQL test database via test-setup (rate-limit table only).
 */

import { beforeAll, describe, expect, test } from "bun:test";
import { ensureDemoEnv, getTestDb, resetRateTable, type TestDb } from "./test-setup";
import { issueReceiptToken, verifyReceiptToken } from "@/lib/server/receipt-token";
import {
  orderStatusSubject,
  renderOrderStatusHtml,
  renderOrderStatusText,
  type OrderStatusMailInput,
} from "@/lib/server/mail/templates/order-status";

/* CANONICAL ISOLATION PATTERN (test-setup's contract): the receipt-qr
 * ROUTE transitively binds `@/lib/db` (rate limiting) — it is imported
 * DYNAMICALLY in beforeAll, AFTER ensureDemoEnv() redirected DATABASE_URL
 * to the throwaway test db. receipt-token and the mail template are pure
 * (no db binding) — static imports are safe for them. */
ensureDemoEnv();

let db: TestDb;
let route: typeof import("@/app/api/sites/[id]/receipt-qr/route");

const SITE = "receipt-qr-site";

beforeAll(async () => {
  db = await getTestDb();
  route = (await import("@/app/api/sites/[id]/receipt-qr/route")) as typeof route;
  await resetRateTable(db);
});

function qrRequest(id: string, token: string): Request {
  return new Request(
    `http://localhost:3000/api/sites/${id}/receipt-qr?token=${encodeURIComponent(token)}`,
    { headers: { "x-forwarded-host": "localhost:3000" } }
  );
}

const ctx = (id: string) => ({ params: Promise.resolve({ id }) });

describe("ROUND 121 — receipt QR endpoint (bearer-capability gate)", () => {
  test("a VALID this-site token mints a private-cached SVG QR", async () => {
    const token = issueReceiptToken(SITE, "order-1");
    const res = await route.GET(qrRequest(SITE, token), ctx(SITE));
    expect(res.status).toBe(200);
    expect(res.headers.get("content-type")).toBe("image/svg+xml; charset=utf-8");
    expect(res.headers.get("cache-control")).toBe("private, max-age=300");
    const body = await res.text();
    expect(body.startsWith("<svg")).toBe(true);
  });

  test("a garbage token is a plain 404 (no oracle)", async () => {
    const res = await route.GET(qrRequest(SITE, "not-a-token"), ctx(SITE));
    expect(res.status).toBe(404);
  });

  test("an EXPIRED token is a plain 404", async () => {
    const token = issueReceiptToken(SITE, "order-1", -1);
    expect(verifyReceiptToken(token)).toBeNull(); /* the primitive agrees */
    const res = await route.GET(qrRequest(SITE, token), ctx(SITE));
    expect(res.status).toBe(404);
  });

  test("a CROSS-SITE token (minted for another instance) is a plain 404 — the QR never crosses sites", async () => {
    const token = issueReceiptToken("another-site", "order-1");
    const res = await route.GET(qrRequest(SITE, token), ctx(SITE));
    expect(res.status).toBe(404);
  });

  test("the minted QR encodes the RECEIPT PAGE url with the exact token", async () => {
    /* decode the QR payload by re-deriving what the endpoint encodes: the
     * SVG path modules are not decodable offline — instead assert the
     * deterministic URL builder through the endpoint's observable contract
     * (a second mint of the SAME token produces a stable SVG — the QR is
     * a pure function of the URL) */
    const token = issueReceiptToken(SITE, "order-2");
    const a = await route.GET(qrRequest(SITE, token), ctx(SITE));
    const b = await route.GET(qrRequest(SITE, token), ctx(SITE));
    const [sa, sb] = await Promise.all([a.text(), b.text()]);
    expect(sa.startsWith("<svg")).toBe(true);
    expect(sa).toBe(sb); /* stable for the same input URL */
  });
});

describe("ROUND 121 — order-status email: the receiptUrl line is purely additive", () => {
  const base: OrderStatusMailInput = {
    customerName: "Guest",
    trackingCode: "JEP6HK",
    status: "confirmed",
    note: null,
    orgName: "متجر",
    totalFormatted: "229.42 SAR",
    lang: "ar",
    trackingUrl: "http://localhost:3000/sites/x/store#tracking",
  };

  test("ABSENT receiptUrl — the text body carries no receipt artifacts (byte-identical contract)", () => {
    const text = renderOrderStatusText(base);
    expect(text).not.toContain("receipt");
    expect(text).not.toContain("فاتورة");
    expect(text).toContain("تتبع طلبك مباشرة");
    const html = renderOrderStatusHtml(base);
    expect(html).not.toContain("receipt?token=");
    expect(html).toContain("#tracking");
  });

  test("PRESENT receiptUrl — the text body gains the receipt line with the exact URL", () => {
    const token = issueReceiptToken(SITE, "order-9");
    const receiptUrl = `http://localhost:3000/sites/${SITE}/receipt?token=${encodeURIComponent(token)}`;
    const text = renderOrderStatusText({ ...base, receiptUrl });
    expect(text).toContain(receiptUrl);
    expect(text).toContain("فاتورة طلبك");
  });

  test("PRESENT receiptUrl — the HTML gains the secondary link (href exact, mail-client-safe)", () => {
    const token = issueReceiptToken(SITE, "order-9");
    const receiptUrl = `http://localhost:3000/sites/${SITE}/receipt?token=${encodeURIComponent(token)}`;
    const html = renderOrderStatusHtml({ ...base, lang: "en", receiptUrl });
    expect(html).toContain(`href="${receiptUrl}"`);
    expect(html).toContain("View your receipt");
    /* the track button still leads */
    expect(html).toContain("#tracking");
  });

  test("the subject line is unchanged by receiptUrl (no information leak in the envelope)", () => {
    const withUrl: OrderStatusMailInput = { ...base, receiptUrl: "http://x/receipt?token=t" };
    expect(orderStatusSubject(withUrl)).toBe(orderStatusSubject(base));
  });
});
