/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 126: the store domain service + repository
 * (src/server/domains/store) — the third route→controller→service→
 * repository decomposition (after packages R124 and plan-orders R125).
 *
 * Provable against the throwaway database with NO server, NO HTTP, NO
 * session machinery:
 *  - the public catalog flow (published-site + entitlement gate, the
 *    column-narrowed live-instance probe, derived products with rating
 *    aggregates, server-side search/category filtering, per-category
 *    counts over the UNFILTERED catalog, the unavailable-store
 *    200-with-empty-products legacy shape);
 *  - the coupon validation flow (verdict → status/code mapping, the
 *    minor-units guard, trashed coupons never validate);
 *  - the reviews flow (visible-only keyset pages + rating summary, the
 *    one-review-per-visitor blind-index upsert that never resets the
 *    moderation state, sellable-target-only submissions);
 *  - every gate 404 ("Store not available" — the exact envelope the four
 *    legacy handlers shared).
 *
 * The byte-level HTTP compatibility of the three migrated routes is proven
 * live by store-routes (the BUILTIN_LIVE suite this round adds).
 */
import { describe, test, expect, beforeAll, afterAll } from "bun:test";
import { getTestDb, type TestDb } from "./test-setup";

let db: TestDb;
let service: typeof import("@/server/domains/store/service");
let repository: typeof import("@/server/domains/store/repository");
let HttpError: typeof import("@/lib/server/route").HttpError;
let blindIndex: typeof import("@/lib/server/crypto-vault").blindIndex;

const RUN = Math.random().toString(36).slice(2, 8);

/** Assert a promise rejects with the EXACT legacy HttpError shape. */
async function expectHttpError(
  promise: Promise<unknown>,
  status: number,
  message: string,
  code?: string
): Promise<void> {
  let caught: unknown;
  try {
    await promise;
  } catch (e) {
    caught = e;
  }
  expect(caught).toBeInstanceOf(HttpError);
  const err = caught as InstanceType<typeof HttpError>;
  expect(err.status).toBe(status);
  expect(err.message).toBe(message);
  expect(err.code).toBe(code);
}

/** Minimal Instance row factory (the sealed-JSON columns the domain reads). */
function instanceJson(modules: string[]): {
  systemId: string;
  orgJson: string;
  adminJson: string;
  prefsJson: string;
  modulesJson: string;
  trialEndsAt: Date;
} {
  return {
    systemId: "pharmacy-management",
    orgJson: JSON.stringify({ name: `صيدلية ${RUN}`, country: "SA", currency: "SAR" }),
    adminJson: JSON.stringify({ name: "مالك", email: `owner-${RUN}@example.com`, role: "owner" }),
    prefsJson: JSON.stringify({ lang: "ar", theme: "light", notif: true, backup: true, audit: true, demo: false }),
    modulesJson: JSON.stringify(modules),
    trialEndsAt: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), /* live trial */
  };
}

/** pharmacy preset cell layout: [name, category, ?, ?, stock, price]. */
function productCells(name: string, category: string, stock: string, price: string): string {
  return JSON.stringify([name, category, "", "", stock, price]);
}

/* fixtures: A = the live happy-path store; B = locked trial; C = no Site;
 * D = unpublished site; E = trashed instance; F = live but no catalog module */
let A = "";
let B = "";
let C = "";
let D = "";
let E = "";
let F = "";
let p1 = "";
let p2 = "";
let pBlocked = "";
const reviewIds: string[] = [];
const couponCodes: string[] = [];
const GUEST_IP = `198.51.100.${(RUN.charCodeAt(0) % 200) + 10}`;

beforeAll(async () => {
  db = await getTestDb();
  service = await import("@/server/domains/store/service");
  repository = await import("@/server/domains/store/repository");
  ({ HttpError } = await import("@/lib/server/route"));
  ({ blindIndex } = await import("@/lib/server/crypto-vault"));

  /* A — live trial, pharmacy module, published site, products, coupons,
   * reviews (visible + hidden + trashed). */
  const a = await db.instance.create({ data: instanceJson(["pharmacy"]) });
  A = a.id;
  await db.site.create({ data: { instanceId: A, published: true } });

  const r1 = await db.moduleRecord.create({
    data: { instanceId: A, moduleId: "pharmacy", dataJson: productCells("بنادول", "مسكنات", "10", "25.00"), featured: true },
  });
  const r2 = await db.moduleRecord.create({
    data: { instanceId: A, moduleId: "pharmacy", dataJson: productCells("فيتامين ج", "مكملات", "5", "40.00") },
  });
  p1 = r1.id;
  p2 = r2.id;
  const blocked = await db.moduleRecord.create({
    data: { instanceId: A, moduleId: "pharmacy", dataJson: productCells("كريم مرطب", "عناية", "7", "60.00"), statusKey: "expired" },
  });
  pBlocked = blocked.id;
  /* an out-of-stock row — never sellable, never reviewable */
  await db.moduleRecord.create({
    data: { instanceId: A, moduleId: "pharmacy", dataJson: productCells("شراب سعال", "مسكنات", "0", "15.00") },
  });

  /* reviews on p1: two visible, one hidden (moderation), one trashed */
  const rv1 = await db.siteReview.create({
    data: { instanceId: A, recordId: p1, rating: 5, name: `زائر أ ${RUN}`, body: "ممتاز" },
  });
  const rv2 = await db.siteReview.create({
    data: { instanceId: A, recordId: p1, rating: 3, name: `زائر ب ${RUN}` },
  });
  reviewIds.push(rv1.id, rv2.id);
  const rvHidden = await db.siteReview.create({
    data: { instanceId: A, recordId: p1, rating: 1, name: `مخفي ${RUN}`, hidden: true },
  });
  reviewIds.push(rvHidden.id);
  const rvTrashed = await db.siteReview.create({
    data: { instanceId: A, recordId: p1, rating: 4, name: `محذوف ${RUN}`, deletedAt: new Date() },
  });
  reviewIds.push(rvTrashed.id);

  /* coupons: live percent, exhausted, min-subtotal, inactive */
  const liveCoupon = await db.storeCoupon.create({
    data: { instanceId: A, code: `LIVE${RUN.slice(0, 4).toUpperCase()}`, kind: "percent", value: 10, active: true },
  });
  const usedUp = await db.storeCoupon.create({
    data: { instanceId: A, code: `USED${RUN.slice(0, 4).toUpperCase()}`, kind: "percent", value: 10, active: true, maxUses: 2, usedCount: 2 },
  });
  const minBig = await db.storeCoupon.create({
    data: { instanceId: A, code: `MINB${RUN.slice(0, 4).toUpperCase()}`, kind: "percent", value: 10, active: true, minSubtotal: 100_000 },
  });
  const offCode = await db.storeCoupon.create({
    data: { instanceId: A, code: `OFFC${RUN.slice(0, 4).toUpperCase()}`, kind: "percent", value: 10, active: false },
  });
  couponCodes.push(liveCoupon.code, usedUp.code, minBig.code, offCode.code);

  /* B — locked trial (expired), published site */
  const bData = instanceJson(["pharmacy"]);
  bData.trialEndsAt = new Date(Date.now() - 24 * 60 * 60 * 1000);
  const b = await db.instance.create({ data: bData });
  B = b.id;
  await db.site.create({ data: { instanceId: B, published: true } });

  /* C — live trial, NO Site row at all */
  const c = await db.instance.create({ data: instanceJson(["pharmacy"]) });
  C = c.id;

  /* D — live trial, unpublished site */
  const d = await db.instance.create({ data: instanceJson(["pharmacy"]) });
  D = d.id;
  await db.site.create({ data: { instanceId: D, published: false } });

  /* E — TRASHED instance with a published site (ROUND 87 — the storefront
   * is GONE even though the site row says published) */
  const eData = instanceJson(["pharmacy"]);
  const e = await db.instance.create({ data: { ...eData, deletedAt: new Date() } });
  E = e.id;
  await db.site.create({ data: { instanceId: E, published: true } });

  /* F — live trial, published site, but NO catalog module */
  const f = await db.instance.create({ data: instanceJson(["crm"]) });
  F = f.id;
  await db.site.create({ data: { instanceId: F, published: true } });
});

afterAll(async () => {
  /* cascade: instances take their sites/records/coupons/reviews with them */
  await db.instance
    .deleteMany({ where: { id: { in: [A, B, C, D, E, F] } } })
    .catch(() => undefined);
});

describe("ROUND 126 — store service: catalog (unit, throwaway db)", () => {
  test("happy path: derived products, rating aggregates, categories + counts", async () => {
    const catalog = await service.getCatalog(A, { q: "", category: "" });
    expect(catalog.available).toBe(true);
    expect(catalog.moduleId).toBe("pharmacy");
    expect(catalog.currency).toBe("SAR");
    /* sellable rows only: p1 (featured), p2; blocked/out-of-stock excluded */
    expect(catalog.products).toHaveLength(2);
    /* featured-first ordering (p1 is featured) */
    expect(catalog.products[0]!.recordId).toBe(p1);
    expect(catalog.products.map((p) => p.name).sort()).toEqual(["فيتامين ج", "بنادول"].sort());
    /* rating aggregates: p1 has 2 VISIBLE reviews (5★ + 3★) → avg 4, count 2 */
    expect(catalog.products[0]!.ratingCount).toBe(2);
    expect(catalog.products[0]!.ratingAvg).toBe(4);
    expect(catalog.products[1]!.ratingCount).toBe(0);
    expect(catalog.products[1]!.ratingAvg).toBeNull();
    /* categories: sorted unique over the unfiltered catalog */
    expect(catalog.categories).toEqual(["مسكنات", "مكملات"]);
    expect(catalog.categoryCounts).toEqual({ "مسكنات": 1, "مكملات": 1 });
  });

  test("search (?q=) matches name and category; counts stay over the UNFILTERED catalog", async () => {
    const byName = await service.getCatalog(A, { q: "بنادول", category: "" });
    expect(byName.products).toHaveLength(1);
    expect(byName.products[0]!.recordId).toBe(p1);
    /* the counts never change with the active filter (ROUND 51) */
    expect(byName.categoryCounts).toEqual({ "مسكنات": 1, "مكملات": 1 });

    const byCategory = await service.getCatalog(A, { q: "", category: "مكملات" });
    expect(byCategory.products).toHaveLength(1);
    expect(byCategory.products[0]!.recordId).toBe(p2);
    expect(byCategory.categoryCounts).toEqual({ "مسكنات": 1, "مكملات": 1 });

    const miss = await service.getCatalog(A, { q: "لا-شيء", category: "" });
    expect(miss.products).toHaveLength(0);
  });

  test("unavailable store (no catalog module): the legacy 200-with-empty-products shape", async () => {
    const catalog = await service.getCatalog(F, { q: "", category: "" });
    expect(catalog.available).toBe(false);
    expect(catalog.moduleId).toBeNull();
    expect(catalog.products).toEqual([]);
    /* the legacy shape NEVER carried categories/categoryCounts here */
    expect(catalog.categories).toBeUndefined();
    expect(catalog.categoryCounts).toBeUndefined();
  });

  test("locked trial (expired) → the exact 404 Store not available", async () => {
    await expectHttpError(service.getCatalog(B, { q: "", category: "" }), 404, "Store not available");
    await expectHttpError(service.validateCoupon(B, { code: "ANYCODE", subtotal: 1000 }), 404, "Store not available");
    await expectHttpError(service.listReviews(B, p1, null, 10), 404, "Store not available");
  });

  test("no Site row / unpublished site → the exact 404", async () => {
    await expectHttpError(service.getCatalog(C, { q: "", category: "" }), 404, "Store not available");
    await expectHttpError(service.getCatalog(D, { q: "", category: "" }), 404, "Store not available");
  });

  test("trashed instance (published site!) → the storefront is GONE (ROUND 87)", async () => {
    await expectHttpError(service.getCatalog(E, { q: "", category: "" }), 404, "Store not available");
    await expectHttpError(
      service.submitReview(E, { recordId: p1, rating: 5, name: `زائر ${RUN}`, body: null }, GUEST_IP),
      404,
      "Store not available"
    );
  });
});

describe("ROUND 126 — store service: coupon validation (unit, throwaway db)", () => {
  test("live percent coupon: the full legacy response shape", async () => {
    const verdict = await service.validateCoupon(A, {
      code: couponCodes[0]!,
      subtotal: 5_000, /* 50.00 SAR in minor units */
    });
    expect(verdict).toEqual({
      code: couponCodes[0],
      kind: "percent",
      value: 10,
      discountMinor: 500, /* ceil(10% of 5000) */
      minSubtotal: null,
    });
  });

  test("unknown code → 404 with the NOTFOUND machine code", async () => {
    await expectHttpError(
      service.validateCoupon(A, { code: "DOESNOTEXIST", subtotal: 5_000 }),
      404,
      "Coupon not applicable",
      "NOTFOUND"
    );
  });

  test("exhausted (usedCount >= maxUses) → 409 EXHAUSTED", async () => {
    await expectHttpError(
      service.validateCoupon(A, { code: couponCodes[1]!, subtotal: 5_000 }),
      409,
      "Coupon not applicable",
      "EXHAUSTED"
    );
  });

  test("below minSubtotal → 409 MINSUBTOTAL", async () => {
    await expectHttpError(
      service.validateCoupon(A, { code: couponCodes[2]!, subtotal: 1_000 }),
      409,
      "Coupon not applicable",
      "MINSUBTOTAL"
    );
  });

  test("inactive coupon → 409 INACTIVE", async () => {
    await expectHttpError(
      service.validateCoupon(A, { code: couponCodes[3]!, subtotal: 5_000 }),
      409,
      "Coupon not applicable",
      "INACTIVE"
    );
  });

  test("a TRASHED coupon never validates (ROUND 87 — the filter is the hard guarantee)", async () => {
    const trashedCode = `TRSH${RUN.slice(0, 4).toUpperCase()}`;
    await db.storeCoupon.create({
      data: { instanceId: A, code: trashedCode, kind: "percent", value: 10, active: true, deletedAt: new Date() },
    });
    couponCodes.push(trashedCode);
    await expectHttpError(
      service.validateCoupon(A, { code: trashedCode, subtotal: 5_000 }),
      404,
      "Coupon not applicable",
      "NOTFOUND"
    );
  });
});

describe("ROUND 126 — store service: reviews (unit, throwaway db)", () => {
  test("listReviews: visible-only page + the recomputed summary", async () => {
    const page = await service.listReviews(A, p1, null, 10);
    /* two visible rows (hidden + trashed excluded) */
    expect(page.reviews).toHaveLength(2);
    expect(page.reviews.every((r) => r.rating >= 1 && r.rating <= 5)).toBe(true);
    /* public DTO never carries authorIndex/hidden */
    for (const r of page.reviews) {
      expect(Object.keys(r).sort()).toEqual(["body", "createdAt", "id", "name", "rating", "recordId"]);
    }
    /* newest first (rv2 created after rv1) */
    expect(page.reviews[0]!.id).not.toBe(page.reviews[1]!.id);
    /* summary: avg of 5+3 = 4.0, count 2, dist[5★]=1, dist[3★]=1 */
    expect(page.summary.count).toBe(2);
    expect(page.summary.avg).toBe(4);
    expect(page.summary.dist).toEqual([1, 0, 1, 0, 0]);
    expect(page.nextCursor).toBeNull(); /* fewer rows than the limit */
  });

  test("listReviews: the keyset limit slices the page and mints a cursor", async () => {
    const page = await service.listReviews(A, p1, null, 1);
    expect(page.reviews).toHaveLength(1);
    expect(page.nextCursor).toBeTruthy();
    /* resuming AFTER the terminal row yields the remaining visible row */
    const { decodeKeyset } = await import("@/lib/server/keyset");
    const resumed = await service.listReviews(A, p1, decodeKeyset(page.nextCursor), 10);
    expect(resumed.reviews).toHaveLength(1);
    expect(resumed.nextCursor).toBeNull();
  });

  test("submitReview: creates the guest row (blind IP index, DTO projection)", async () => {
    const result = await service.submitReview(
      A,
      { recordId: p2, rating: 4, name: `ضيف ${RUN}`, body: "تجربة جيدة" },
      GUEST_IP
    );
    expect(result.updated).toBe(false);
    expect(result.review.rating).toBe(4);
    expect(result.review.name).toBe(`ضيف ${RUN}`);
    /* the row is keyed by the blind index of the client IP (never raw PII) */
    const row = await db.siteReview.findUnique({
      where: {
        instanceId_recordId_authorIndex: {
          instanceId: A,
          recordId: p2,
          authorIndex: blindIndex(GUEST_IP)!,
        },
      },
    });
    expect(row).toBeTruthy();
    expect(row!.body).toBe("تجربة جيدة");
    reviewIds.push(result.review.id);
  });

  test("submitReview: re-submission from the SAME IP UPDATES, never resets moderation", async () => {
    /* the owner hides the existing review (moderation) */
    await db.siteReview.update({
      where: { id: reviewIds[reviewIds.length - 1] },
      data: { hidden: true },
    });
    const result = await service.submitReview(
      A,
      { recordId: p2, rating: 2, name: `ضيف ${RUN}`, body: null },
      GUEST_IP
    );
    expect(result.updated).toBe(true);
    expect(result.review.rating).toBe(2);
    /* the moderation state survived the re-submission */
    const row = await db.siteReview.findUniqueOrThrow({ where: { id: result.review.id } });
    expect(row.hidden).toBe(true);
  });

  test("submitReview: an UNSELLABLE target (blocked status) is not reviewable", async () => {
    await expectHttpError(
      service.submitReview(A, { recordId: pBlocked, rating: 5, name: `ضيف ${RUN}`, body: null }, GUEST_IP),
      404,
      "Product not found"
    );
  });
});

describe("ROUND 126 — store repository (unit, throwaway db)", () => {
  test("findSiteGate: the exact gate shape; null for instanceless ids", async () => {
    const gate = await repository.findSiteGate(A);
    expect(gate?.published).toBe(true);
    expect(gate?.instance.packageId).toBeNull();
    expect(gate?.instance.trialEndsAt).toBeTruthy();
    expect(await repository.findSiteGate(C)).toBeNull();
  });

  test("findLiveInstance: trashed rows are invisible", async () => {
    expect((await repository.findLiveInstance(A))?.id).toBe(A);
    expect(await repository.findLiveInstance(E)).toBeNull();
  });

  test("findLiveCoupon: unique (instance, code) probe; trashed rows miss", async () => {
    const found = await repository.findLiveCoupon(A, couponCodes[0]!);
    expect(found?.active).toBe(true);
    expect(await repository.findLiveCoupon(A, "DOESNOTEXIST")).toBeNull();
  });

  test("listVisibleReviewsPage: newest-first total order; hidden/trashed excluded", async () => {
    const rows = await repository.listVisibleReviewsPage(A, p1, null, 10);
    expect(rows).toHaveLength(2);
    for (let i = 1; i < rows.length; i++) {
      expect(rows[i - 1]!.createdAt.getTime()).toBeGreaterThanOrEqual(rows[i]!.createdAt.getTime());
    }
  });

  test("findLiveAuthorReview: the blind-index upsert probe (live rows only)", async () => {
    const idx = blindIndex(GUEST_IP)!;
    const found = await repository.findLiveAuthorReview(A, p2, idx);
    expect(found?.recordId).toBe(p2);
    expect(await repository.findLiveAuthorReview(A, p1, idx)).toBeNull();
  });
});
