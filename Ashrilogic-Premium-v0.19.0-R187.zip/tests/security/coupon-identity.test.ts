/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — COUPON IDENTITY INTEGRITY (ROUND 120).
 *
 * The exact business scenario the spec demands:
 *   old coupon deleted (trashed) → NEW coupon created with the SAME code
 *   → the OLD order cancelled → the NEW coupon's usedCount must NOT move
 *   (and the old coupon's quota is the one restored).
 *
 * Plus the placement-side ledger contract:
 *  - orders that redeem a coupon store couponId + the CouponRedemption
 *    ledger row (unique per order) written in the same transaction;
 *  - orders carry per-line OrderReservation rows (moduleId + stockColumn
 *    the placement used — the module-drift-proof release);
 *  - the repair sweep re-drives cancelled-but-uncompensated orders and
 *    lands compensatedAt only on full resolution;
 *  - the reservation ledger drives the release column even when the
 *    instance's CURRENT module set no longer matches (module drift).
 *
 * DB isolation: throwaway PostgreSQL test database via test-setup (never the live DB).
 */

import { beforeAll, afterAll, describe, expect, test } from "bun:test";
import { ensureDemoEnv, getTestDb, type TestDb } from "./test-setup";

ensureDemoEnv();

let db: TestDb;
let lifecycle: typeof import("@/lib/server/order-lifecycle");
let compensation: typeof import("@/lib/server/order-compensation");

const INSTANCE = "coupon-identity-instance";

/* the store module shape the placement/compensation math assumes:
 * products module — name 0, category 2, stock 3, price 4 (minor units) */
const MODULES = JSON.stringify(["products"]);
const dataJsonOf = (cells: string[]) => JSON.stringify(cells);

/** seed a store record row with the products-module column layout. */
async function seedRecord(id: string, cells: string[]): Promise<string> {
  await db.moduleRecord.deleteMany({ where: { id } });
  await db.moduleRecord.create({
    data: {
      id,
      instanceId: INSTANCE,
      moduleId: "products",
      dataJson: dataJsonOf(cells),
      statusKey: "",
    },
  });
  return id;
}

async function seedCoupon(
  id: string,
  code: string,
  usedCount = 0
): Promise<string> {
  await db.storeCoupon.deleteMany({ where: { id } });
  await db.storeCoupon.create({
    data: {
      id,
      instanceId: INSTANCE,
      code,
      kind: "percent",
      value: 10,
      usedCount,
      active: true,
    },
  });
  return id;
}

async function seedOrder(
  id: string,
  opts: {
    items: Array<{ recordId: string; qty: number }>;
    couponCode?: string | null;
    couponId?: string | null;
    status?: string;
    compensatedAt?: Date | null;
  }
): Promise<string> {
  await db.siteOrder.deleteMany({ where: { id } });
  await db.orderReservation.deleteMany({ where: { orderId: id } });
  await db.couponRedemption.deleteMany({ where: { orderId: id } });
  await db.siteOrder.create({
    data: {
      id,
      instanceId: INSTANCE,
      customerId: "coupon-identity-customer",
      itemsJson: JSON.stringify({
        v: 2,
        items: opts.items.map((it) => ({
          recordId: it.recordId,
          name: "Item",
          price: 1000,
          qty: it.qty,
        })),
      }),
      total: 9000,
      discount: 1000,
      couponCode: opts.couponCode ?? null,
      couponId: opts.couponId ?? null,
      status: opts.status ?? "pending",
      ...(opts.compensatedAt !== undefined ? { compensatedAt: opts.compensatedAt } : {}),
    },
  });
  /* the placement-time ledgers (what the route now writes) */
  await db.orderReservation.createMany({
    data: opts.items.map((it) => ({
      orderId: id,
      instanceId: INSTANCE,
      recordId: it.recordId,
      moduleId: "products",
      stockColumn: 3,
      qty: it.qty,
      state: "reserved",
    })),
  });
  if (opts.couponId) {
    await db.couponRedemption.create({
      data: {
        orderId: id,
        instanceId: INSTANCE,
        couponId: opts.couponId,
        code: opts.couponCode ?? "",
      },
    });
  }
  return id;
}

beforeAll(async () => {
  db = await getTestDb();
  lifecycle = await import("@/lib/server/order-lifecycle");
  compensation = await import("@/lib/server/order-compensation");

  await db.instance.deleteMany({ where: { id: INSTANCE } });
  await db.instance.create({
    data: {
      id: INSTANCE,
      systemId: "products",
      orgJson: JSON.stringify({ name: "Coupon Identity", currency: "SAR" }),
      adminJson: "{}",
      prefsJson: "{}",
      modulesJson: MODULES,
    },
  });
  await db.siteCustomer.deleteMany({ where: { id: "coupon-identity-customer" } });
  await db.siteCustomer.create({
    data: {
      id: "coupon-identity-customer",
      instanceId: INSTANCE,
      name: "Guest",
      email: "",
      passwordHash: "",
    },
  });
});

afterAll(async () => {
  try {
    await db.instance.deleteMany({ where: { id: INSTANCE } });
    await db.siteCustomer.deleteMany({ where: { id: "coupon-identity-customer" } });
    await db.siteOrder.deleteMany({ where: { instanceId: INSTANCE } });
    await db.orderReservation.deleteMany({ where: { instanceId: INSTANCE } });
    await db.couponRedemption.deleteMany({ where: { instanceId: INSTANCE } });
    await db.storeCoupon.deleteMany({ where: { instanceId: INSTANCE } });
    await db.moduleRecord.deleteMany({ where: { instanceId: INSTANCE } });
  } catch {
    /* best-effort cleanup */
  }
});

describe("ROUND 120 — coupon identity: code reuse can never steal quota", () => {
  test("old coupon trashed → new coupon SAME CODE → old order cancelled → the NEW coupon is untouched", async () => {
    /* create the OLD coupon first, trash it (code mangled by the trash
     * engine), THEN create the NEW one carrying the same code — the
     * documented code-reuse sequence (unique(instanceId, code) allows it
     * only because the old row is trashed+mangled) */
    const oldCoupon = await seedCoupon("c-old", "SALEX", 1); /* placement consumed one use */
    await seedRecord("rec-ci-1", ["Item", "", "cat", "10", "1000"]); /* stock cell 3 = 10 */
    await db.storeCoupon.update({
      where: { id: oldCoupon },
      data: { deletedAt: new Date(), code: "DEL-c-old" },
    });
    const newCoupon = await seedCoupon("c-new", "SALEX");

    /* the OLD order redeemed the OLD coupon (couponId + ledger) */
    await seedOrder("o-identity-1", {
      items: [{ recordId: "rec-ci-1", qty: 2 }],
      couponCode: "SALEX",
      couponId: oldCoupon,
    });

    /* the NEW coupon accrues a legitimate use of its own */
    await db.storeCoupon.update({ where: { id: newCoupon }, data: { usedCount: 3 } });

    /* cancel the old order */
    const outcome = await lifecycle.compensateOrderReservations({
      id: "o-identity-1",
      instanceId: INSTANCE,
      itemsJson: JSON.stringify({
        v: 2,
        items: [{ recordId: "rec-ci-1", name: "Item", price: 1000, qty: 2 }],
      }),
      couponCode: "SALEX",
      couponId: oldCoupon,
    });

    /* the release targeted the OLD coupon's identity (trashed row: the
     * ledger flips; the floor holds) — the NEW coupon is untouched */
    expect(outcome.releasedCouponUse).toBe(true);
    const after = await db.storeCoupon.findUniqueOrThrow({ where: { id: newCoupon } });
    expect(after.usedCount).toBe(3); /* NOT decremented — the spec's exact demand */
    const ledger = await db.couponRedemption.findUniqueOrThrow({
      where: { orderId: "o-identity-1" },
    });
    expect(ledger.releasedAt).not.toBeNull();
  });

  test("legacy order (no couponId, no ledger) → code-path release hits ONLY live coupons", async () => {
    await seedCoupon("c-legacy", "LEGACY5", 1); /* placement consumed one use */
    await seedRecord("rec-ci-2", ["Item", "", "cat", "8", "1000"]);
    await db.orderReservation.deleteMany({ where: { orderId: "o-legacy" } });
    await db.couponRedemption.deleteMany({ where: { orderId: "o-legacy" } });
    await seedOrder("o-legacy", {
      items: [{ recordId: "rec-ci-2", qty: 1 }],
      couponCode: "LEGACY5",
      couponId: null,
    });
    /* legacy release path: live coupon by code */
    const outcome = await lifecycle.compensateOrderReservations({
      id: "o-legacy",
      instanceId: INSTANCE,
      itemsJson: JSON.stringify({
        v: 2,
        items: [{ recordId: "rec-ci-2", name: "Item", price: 1000, qty: 1 }],
      }),
      couponCode: "LEGACY5",
      couponId: null,
    });
    expect(outcome.releasedCouponUse).toBe(true);
    const row = await db.storeCoupon.findUniqueOrThrow({ where: { id: "c-legacy" } });
    expect(row.usedCount).toBe(0); /* floor held at 0 (was 0) — never negative */
  });

  test("idempotent re-run: a released order's compensation is a no-op (ledger state)", async () => {
    await seedRecord("rec-ci-3", ["Item", "", "cat", "5", "1000"]);
    const coupon = await seedCoupon("c-idem", "IDEM1", 1); /* placement consumed one use */
    await seedOrder("o-idem", {
      items: [{ recordId: "rec-ci-3", qty: 1 }],
      couponCode: "IDEM1",
      couponId: coupon,
    });
    /* first run releases */
    const first = await lifecycle.compensateOrderReservations({
      id: "o-idem",
      instanceId: INSTANCE,
      itemsJson: JSON.stringify({
        v: 2,
        items: [{ recordId: "rec-ci-3", name: "Item", price: 1000, qty: 1 }],
      }),
      couponCode: "IDEM1",
      couponId: coupon,
    });
    expect(first.releasedStockUnits).toBe(1);
    /* the reservation row flipped */
    const res = await db.orderReservation.findUniqueOrThrow({
      where: { orderId_recordId: { orderId: "o-idem", recordId: "rec-ci-3" } },
    });
    expect(res.state).toBe("released");

    /* second run (the repair sweep's re-drive): everything already
     * released — resolved, zero new units, zero new decrement */
    const before = (await db.storeCoupon.findUniqueOrThrow({ where: { id: coupon } })).usedCount;
    const second = await lifecycle.compensateOrderReservations({
      id: "o-idem",
      instanceId: INSTANCE,
      itemsJson: JSON.stringify({
        v: 2,
        items: [{ recordId: "rec-ci-3", name: "Item", price: 1000, qty: 1 }],
      }),
      couponCode: "IDEM1",
      couponId: coupon,
    });
    expect(second.releasedStockUnits).toBe(0);
    expect(second.resolved).toBe(true);
    const after = (await db.storeCoupon.findUniqueOrThrow({ where: { id: coupon } })).usedCount;
    expect(after).toBe(before); /* no double decrement */
    const stockAfter = await db.moduleRecord.findUniqueOrThrow({ where: { id: "rec-ci-3" } });
    expect(JSON.parse(stockAfter.dataJson)[3]).toBe("6"); /* 5 + 1 released once — never twice */
  });
});

describe("ROUND 120 — module-drift-proof release (reservation column)", () => {
  test("the release writes the cell the PLACEMENT wrote, not the instance's current mapping", async () => {
    await seedRecord("rec-drift", ["Item", "", "cat", "12", "1000"]);
    /* seedOrder writes the reservation ledger row (moduleId + stockColumn 3
     * — exactly what the placement route persists) */
    await db.orderReservation.deleteMany({ where: { orderId: "o-drift" } });
    await db.couponRedemption.deleteMany({ where: { orderId: "o-drift" } });
    await seedOrder("o-drift", {
      items: [{ recordId: "rec-drift", qty: 3 }],
    });
    /* DRIFT: the instance's module priority now resolves a DIFFERENT
     * store module (pharmacy: stock 4) — the legacy path would write the
     * wrong cell; the reservation wins */
    await db.instance.update({
      where: { id: INSTANCE },
      data: { modulesJson: JSON.stringify(["pharmacy", "products"]) },
    });
    try {
      const outcome = await lifecycle.compensateOrderReservations({
        id: "o-drift",
        instanceId: INSTANCE,
        itemsJson: JSON.stringify({
          v: 2,
          items: [{ recordId: "rec-drift", name: "Item", price: 1000, qty: 3 }],
        }),
        couponCode: null,
        couponId: null,
      });
      expect(outcome.releasedStockUnits).toBe(3);
      const row = await db.moduleRecord.findUniqueOrThrow({ where: { id: "rec-drift" } });
      const cells = JSON.parse(row.dataJson) as string[];
      expect(cells[3]).toBe("15"); /* stock cell (3) restored: 12 + 3 */
      expect(cells[4]).toBe("1000"); /* price cell (4) UNTOUCHED */
    } finally {
      await db.instance.update({
        where: { id: INSTANCE },
        data: { modulesJson: MODULES },
      });
    }
  });
});

describe("ROUND 120 — the durable repair sweep", () => {
  test("cancelled + uncompensated + past grace → the sweep releases and lands compensatedAt", async () => {
    await seedRecord("rec-sweep", ["Item", "", "cat", "4", "1000"]);
    const coupon = await seedCoupon("c-sweep", "SWEEP1", 1); /* placement consumed one use */
    /* a crash between the cancel CAS and the release left this order:
     * cancelled, compensatedAt NULL, reservations still 'reserved' */
    await seedOrder("o-sweep-1", {
      items: [{ recordId: "rec-sweep", qty: 2 }],
      couponCode: "SWEEP1",
      couponId: coupon,
      status: "cancelled",
      compensatedAt: null,
    });
    /* force the crash-window timestamps PAST raw SQL: Prisma's @updatedAt
     * auto-stamps create/update, so the sweep's pickup grace must be
     * back-dated explicitly (PostgreSQL dialect: quoted identifiers, $n
     * binds, native Date parameters) */
    await db.$executeRawUnsafe(
      'UPDATE "SiteOrder" SET "createdAt" = $1, "updatedAt" = $2 WHERE "id" = $3',
      new Date(Date.now() - 3_600_000),
      new Date(Date.now() - 3_600_000),
      "o-sweep-1"
    );

    const outcome = await compensation.sweepOrderCompensation(new Date());
    expect(outcome.scanned).toBeGreaterThan(0);
    expect(outcome.resolved).toBeGreaterThan(0);

    const order = await db.siteOrder.findUniqueOrThrow({ where: { id: "o-sweep-1" } });
    expect(order.compensatedAt).not.toBeNull();
    const row = await db.moduleRecord.findUniqueOrThrow({ where: { id: "rec-sweep" } });
    expect(JSON.parse(row.dataJson)[3]).toBe("6"); /* 4 + 2 released */
    const res = await db.orderReservation.findUniqueOrThrow({
      where: { orderId_recordId: { orderId: "o-sweep-1", recordId: "rec-sweep" } },
    });
    expect(res.state).toBe("released");
    const ledger = await db.couponRedemption.findUniqueOrThrow({
      where: { orderId: "o-sweep-1" },
    });
    expect(ledger.releasedAt).not.toBeNull();

    /* a clean sweep is a no-op */
    const again = await compensation.sweepOrderCompensation(new Date());
    expect(again.resolved).toBe(0);
    expect(again.scanned).toBe(0);
  });

  test("fresh cancels (inside the pickup grace) and trashed orders are NOT swept", async () => {
    await seedRecord("rec-sweep-2", ["Item", "", "cat", "9", "1000"]);
    await seedRecord("rec-sweep-3", ["Item", "", "cat", "9", "1000"]);
    /* fresh cancel — the in-request compensation's window */
    await seedOrder("o-sweep-fresh", {
      items: [{ recordId: "rec-sweep-2", qty: 1 }],
      status: "cancelled",
      compensatedAt: null,
    });
    /* trashed cancel — reservations are kept by the business rule */
    await seedOrder("o-sweep-trashed", {
      items: [{ recordId: "rec-sweep-3", qty: 1 }],
      status: "cancelled",
      compensatedAt: null,
    });
    await db.$executeRawUnsafe(
      'UPDATE "SiteOrder" SET "updatedAt" = $1 WHERE "id" = $2',
      new Date(Date.now() - 3_600_000),
      "o-sweep-trashed"
    );
    await db.siteOrder.update({
      where: { id: "o-sweep-trashed" },
      data: { deletedAt: new Date() },
    });

    const outcome = await compensation.sweepOrderCompensation(new Date());
    expect(outcome.scanned).toBe(0); /* neither qualifies */
    const fresh = await db.siteOrder.findUniqueOrThrow({ where: { id: "o-sweep-fresh" } });
    expect(fresh.compensatedAt).toBeNull();
    const trashed = await db.moduleRecord.findUniqueOrThrow({ where: { id: "rec-sweep-3" } });
    expect(JSON.parse(trashed.dataJson)[3]).toBe("9"); /* untouched */
  });
});
