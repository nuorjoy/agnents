/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — PLATFORM BACKUP OFF-SITE OBJECT-STORE COPY
 * (ROUND 123) + the mirror filename fix.
 *
 * The R123 lift: when the object-storage driver is S3, every completed
 * platform snapshot additionally uploads its irreplaceable bytes (the
 * database copy + the manifest) to the bucket under
 * `backups/<snapshot>/`, READS BOTH BACK and sha256/byte-verifies them,
 * and prunes remote snapshot prefixes beyond the retention window.
 *
 * Proves (against a local S3-shaped server, same discipline as
 * object-store.test.ts — the SigV4 wire contract itself is proven there):
 *  1. A REAL snapshot run (pg_dump of the fixture database) with the s3
 *     driver produces the LOCAL snapshot AND uploads database.dump +
 *     manifest.json with EXACTLY the local bytes; no off-site failure
 *     is logged.
 *  2. REMOTE RETENTION — with 15 pre-seeded stale snapshot prefixes in
 *     the bucket, the run keeps the newest MAX_BACKUPS (14) names: the
 *     oldest two are deleted object-by-object, everything newer + the
 *     fresh one survives.
 *  3. LOCAL DRIVER NO-OP — with the local driver the bucket receives
 *     nothing (the local snapshot already is the DR artifact).
 *  4. THE CORRUPTION GUARD — a server that silently alters the stored
 *     database bytes (bit-rot on read-back) makes the copy FAIL LOUDLY
 *     (logged), the corrupt remote artifact is DELETED, and the local
 *     snapshot stands intact.
 *  5. THE MIRROR FILENAME FIX — mirrorSnapshot(dir, "database.dump")
 *     mirrors the PostgreSQL dump member (the former hard-coded
 *     database.db made every pg_dump snapshot's mirror useless).
 */

import { afterAll, beforeAll, describe, expect, test } from "bun:test";
import { mkdtempSync, rmSync, existsSync, readFileSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createHash } from "node:crypto";
import { getTestDb, ensureDemoEnv } from "./test-setup";
import { __resetObjectStorageForTests } from "@/lib/server/storage/object-store";
import {
  decryptBackupArtifact,
  isBackupEnvelope,
  resolveBackupMasterKeys,
} from "@/lib/server/backup-crypto";

ensureDemoEnv();

let platformBackup: typeof import("@/lib/server/platform-backup");

const TMP = mkdtempSync(join(tmpdir(), "ashrilogic-backup-offsite-"));

beforeAll(async () => {
  /* binds the prisma singleton to the throwaway test DB (the isolation
   * canary) — runPlatformBackup's pg_dump runs against it */
  await getTestDb();
  platformBackup = await import("@/lib/server/platform-backup");
});

afterAll(() => {
  delete process.env.ASHRILOGIC_STORAGE_DIR;
  delete process.env.ASHRILOGIC_STORAGE_DRIVER;
  delete process.env.S3_ENDPOINT;
  delete process.env.S3_BUCKET;
  delete process.env.S3_REGION;
  delete process.env.S3_ACCESS_KEY_ID;
  delete process.env.S3_SECRET_ACCESS_KEY;
  delete process.env.S3_KEY_PREFIX;
  delete process.env.ASHRILOGIC_BACKUP_MIRROR_DIR;
  rmSync(TMP, { recursive: true, force: true });
});

/* ------------------- the local S3-shaped server ------------------- */

let server: ReturnType<typeof Bun.serve> | null = null;
const objects = new Map<string, Buffer>();
/** when set, GETs of keys containing this marker return CORRUPTED bytes —
 *  simulates bit-rot between PUT and the read-back verification */
let corruptMarker: string | null = null;

const sha256 = (b: Buffer): string => createHash("sha256").update(b).digest("hex");

beforeAll(() => {
  objects.clear();
  corruptMarker = null;
  server = Bun.serve({
    port: 0,
    hostname: "127.0.0.1",
    async fetch(req) {
      const url = new URL(req.url);
      const path = decodeURIComponent(url.pathname);
      const bucketPath = "/offsite-test-bucket";
      if (!path.startsWith(bucketPath)) return new Response("no such bucket", { status: 404 });
      const key = path.slice(bucketPath.length + 1);
      /* ListObjectsV2 lands on the bare bucket path (empty key) — route it
       * BEFORE the key-prefix guard (the query carries the real prefix) */
      if ((req.method === "GET" && key === "") || key === "/") {
        const prefix = url.searchParams.get("prefix") ?? "";
        const all = [...objects.keys()].filter((k) => k.startsWith(prefix)).sort();
        const contents = all
          .map((k) => `<Contents><Key>${k}</Key><Size>${objects.get(k)!.length}</Size>` +
          `<LastModified>${new Date().toISOString()}</LastModified></Contents>`)
          .join("");
        return new Response(
          `<?xml version="1.0"?><ListBucketResult>${contents}<IsTruncated>false</IsTruncated></ListBucketResult>`,
          { status: 200, headers: { "content-type": "application/xml" } }
        );
      }
      if (!key.startsWith("ashrilogic/test/")) {
        return new Response("outside prefix", { status: 404 });
      }
      if (!(req.headers.get("authorization") ?? "").startsWith("AWS4-HMAC-SHA256")) {
        return new Response("unsigned", { status: 403 });
      }
      if (req.method === "PUT") {
        objects.set(key, Buffer.from(await req.arrayBuffer()));
        return new Response(null, { status: 200 });
      }
      if (req.method === "GET") {
        const obj = objects.get(key);
        if (obj === undefined) return new Response(null, { status: 404 });
        const body =
          corruptMarker !== null && key.includes(corruptMarker)
            ? Buffer.concat([obj.subarray(0, Math.max(0, obj.length - 1)), Buffer.from("X")])
            : obj;
        return new Response(new Uint8Array(body), {
          status: 200,
          headers: { "content-length": String(body.length) },
        });
      }
      if (req.method === "HEAD") {
        const obj = objects.get(key);
        if (obj === undefined) return new Response(null, { status: 404 });
        return new Response(null, {
          status: 200,
          headers: { "content-length": String(obj.length) },
        });
      }
      if (req.method === "DELETE") {
        if (!objects.delete(key)) return new Response(null, { status: 404 });
        return new Response(null, { status: 204 });
      }
      return new Response("unsupported", { status: 405 });
    },
  });
});

afterAll(() => {
  server?.stop(true);
});

/** async spy wrapper: runPlatformBackup's failure path logs via console.error */
async function withOffsiteErrorCapture<T>(fn: () => Promise<T>): Promise<{ result: T; errors: string[] }> {
  const errors: string[] = [];
  const original = console.error;
  console.error = (...args: unknown[]) => {
    const line = args.map((a) => (typeof a === "string" ? a : String(a))).join(" ");
    if (line.includes("[platform-backup] off-site")) errors.push(line);
  };
  try {
    const result = await fn();
    return { result, errors };
  } finally {
    console.error = original;
  }
}

function bindS3Driver(): void {
  process.env.ASHRILOGIC_STORAGE_DRIVER = "s3";
  process.env.S3_ENDPOINT = server!.url.toString().replace(/\/$/, "");
  process.env.S3_BUCKET = "offsite-test-bucket";
  process.env.S3_REGION = "test-region";
  process.env.S3_ACCESS_KEY_ID = "TESTKEY";
  process.env.S3_SECRET_ACCESS_KEY = "AWS4TESTSECRET";
  process.env.S3_KEY_PREFIX = "ashrilogic/test";
  __resetObjectStorageForTests();
}

function bindLocalDriver(root: string): void {
  delete process.env.ASHRILOGIC_STORAGE_DRIVER;
  delete process.env.S3_ENDPOINT;
  process.env.ASHRILOGIC_STORAGE_DIR = root;
  __resetObjectStorageForTests();
}

const bucketKeys = (): string[] => [...objects.keys()].sort();

/* ------------------------------ the suite ------------------------------ */

describe("ROUND 123 — platform backup off-site object-store copy", () => {
  test("a real snapshot with the s3 driver uploads database + manifest as ENCRYPTED envelopes (ROUND 137)", async () => {
    const root = mkdtempSync(join(TMP, "s3-run-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root; /* the LOCAL artifact root stays */
    bindS3Driver();
    objects.clear();

    const { result, errors } = await withOffsiteErrorCapture(() => platformBackup.runPlatformBackup());
    expect(result).not.toBeNull();
    expect(errors).toEqual([]); /* the happy path logs NOTHING off-site-failure */

    /* the LOCAL snapshot stands (the primary DR artifact) */
    const snapshotName = result!.split(/[/\\]/).pop()!;
    expect(existsSync(join(root, "backups", snapshotName, "database.dump"))).toBe(true);
    expect(existsSync(join(root, "backups", snapshotName, "manifest.json"))).toBe(true);

    /* ROUND 137 — the bucket holds ASHBC1 ENVELOPES that decrypt back to
     * the LOCAL plaintext bytes: the database member and the manifest
     * never leave the host unencrypted */
    const keys = resolveBackupMasterKeys();
    expect(keys.available).toBe(true);
    if (!keys.available) throw new Error("backup master key unavailable");
    const dbKey = `ashrilogic/test/backups/${snapshotName}/database.dump`;
    const manifestKey = `ashrilogic/test/backups/${snapshotName}/manifest.json`;
    expect(objects.has(dbKey)).toBe(true);
    expect(objects.has(manifestKey)).toBe(true);

    const remoteDb = objects.get(dbKey)!;
    expect(isBackupEnvelope(remoteDb)).toBe(true); /* NEVER plaintext */
    const openedDb = decryptBackupArtifact(remoteDb, { active: keys.active, previous: keys.previous });
    expect(openedDb.ok).toBe(true);
    if (openedDb.ok) {
      expect(sha256(openedDb.plain)).toBe(
        sha256(readFileSync(join(root, "backups", snapshotName, "database.dump")))
      );
    }

    const remoteManifest = objects.get(manifestKey)!;
    expect(isBackupEnvelope(remoteManifest)).toBe(true); /* the manifest too */
    const openedManifest = decryptBackupArtifact(remoteManifest, {
      active: keys.active,
      previous: keys.previous,
    });
    expect(openedManifest.ok).toBe(true);
    if (openedManifest.ok) {
      expect(openedManifest.plain.toString("utf8")).toBe(
        readFileSync(join(root, "backups", snapshotName, "manifest.json"), "utf8")
      );
    }

    /* no stray uploads beyond the two members (images are NOT re-uploaded —
       they already live in the bucket's images/ namespace) */
    const backupKeys = bucketKeys().filter((k) => k.includes("/backups/"));
    expect(backupKeys).toHaveLength(2);
  });

  test("remote retention prunes the oldest snapshot names beyond MAX_BACKUPS", async () => {
    const root = mkdtempSync(join(TMP, "retention-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root;
    bindS3Driver();
    objects.clear();

    /* 15 stale snapshot prefixes — 01..15 by construction ascending */
    for (let i = 1; i <= 15; i++) {
      const stamp = `2000-01-01T00-${String(i).padStart(2, "0")}-00`;
      objects.set(
        `ashrilogic/test/backups/ashrilogic-${stamp}/database.dump`,
        Buffer.from(`stale-${i}`)
      );
    }

    const { result, errors } = await withOffsiteErrorCapture(() => platformBackup.runPlatformBackup());
    expect(result).not.toBeNull();
    expect(errors).toEqual([]);

    const stamps = new Set(
      bucketKeys()
        .map((k) => /^ashrilogic\/test\/backups\/(ashrilogic-\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2})\//.exec(k)?.[1])
        .filter((s): s is string => Boolean(s))
    );
    /* 15 stale + 1 fresh = 16 → keep the newest 14 → the two OLDEST stale
       stamps (00-01, 00-02) are pruned; the fresh one always survives */
    expect(stamps.has("ashrilogic-2000-01-01T00-01-00")).toBe(false);
    expect(stamps.has("ashrilogic-2000-01-01T00-02-00")).toBe(false);
    expect(stamps.has("ashrilogic-2000-01-01T00-03-00")).toBe(true);
    expect(stamps.has("ashrilogic-2000-01-01T00-15-00")).toBe(true);
    expect(stamps.size).toBe(14);
  });

  test("the local driver uploads NOTHING (the snapshot is the local DR artifact)", async () => {
    const root = mkdtempSync(join(TMP, "local-run-"));
    bindLocalDriver(root);
    const before = objects.size;

    const result = await platformBackup.runPlatformBackup();
    expect(result).not.toBeNull();
    const snapshotName = result!.split(/[/\\]/).pop()!;
    expect(existsSync(join(root, "backups", snapshotName, "database.dump"))).toBe(true);

    /* the bucket is untouched by the local run */
    expect(objects.size).toBe(before);
  });

  test("read-back corruption fails loudly, deletes the bad artifact, keeps the local snapshot", async () => {
    const root = mkdtempSync(join(TMP, "corrupt-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root;
    bindS3Driver();
    objects.clear();
    corruptMarker = "/backups/"; /* every database read-back is corrupted */

    try {
      const { result, errors } = await withOffsiteErrorCapture(() =>
        platformBackup.runPlatformBackup()
      );
      /* the LOCAL snapshot completed regardless (best-effort contract) */
      expect(result).not.toBeNull();
      const snapshotName = result!.split(/[/\\]/).pop()!;
      expect(existsSync(join(root, "backups", snapshotName, "database.dump"))).toBe(true);

      /* the off-site copy failed LOUDLY — the encrypted read-back
         verification refused the corrupted envelope */
      expect(errors.length).toBeGreaterThanOrEqual(1);
      expect(errors.join("\n")).toMatch(/read-back verification failed/);

      /* the corrupt remote artifact was DELETED (never left behind as a
         false DR copy) — no database.dump keys remain in the bucket */
      const dbKeys = bucketKeys().filter(
        (k) => k.includes("/backups/") && k.endsWith("database.dump")
      );
      expect(dbKeys).toHaveLength(0);
    } finally {
      corruptMarker = null;
    }
  });
});

describe("ROUND 123/137 — mirrorSnapshot (PostgreSQL dumps mirror correctly, ENCRYPTED)", () => {
  test("mirrorSnapshot(dir, \"database.dump\") mirrors the dump member as a VERIFIED envelope", () => {
    const snapshotDir = mkdtempSync(join(TMP, "pg-snapshot-"));
    const mirrorRoot = mkdtempSync(join(TMP, "pg-mirror-"));
    const snapshotBase = snapshotDir.split(/[/\\]/).pop()!;
    writeFileSync(join(snapshotDir, "database.dump"), Buffer.from("PGDMP-custom-format-bytes"));
    writeFileSync(join(snapshotDir, "manifest.json"), JSON.stringify({ database: "database.dump" }));

    process.env.ASHRILOGIC_BACKUP_MIRROR_DIR = mirrorRoot;
    try {
      platformBackup.mirrorSnapshot(snapshotDir, "database.dump");
      /* the mirror dir is named after the SNAPSHOT DIR (its basename) */
      const mirroredDir = join(mirrorRoot, "backups", snapshotBase);
      const mirroredDump = join(mirroredDir, "database.dump");
      expect(existsSync(mirroredDump)).toBe(true);
      /* ROUND 137 — the mirror copy is an ASHBC1 envelope that decrypts
         back to the source plaintext (never a plaintext mirror) */
      const mirrored = readFileSync(mirroredDump);
      expect(isBackupEnvelope(mirrored)).toBe(true);
      const keys = resolveBackupMasterKeys();
      expect(keys.available).toBe(true);
      if (!keys.available) throw new Error("backup master key unavailable");
      const opened = decryptBackupArtifact(mirrored, { active: keys.active, previous: keys.previous });
      expect(opened.ok).toBe(true);
      if (opened.ok) expect(opened.plain.toString("utf8")).toBe("PGDMP-custom-format-bytes");
      /* the mirrored manifest is an envelope too */
      expect(isBackupEnvelope(readFileSync(join(mirroredDir, "manifest.json")))).toBe(true);
      /* the pre-fix behavior would have looked for database.db and failed
         loudly — the dump member mirrors and verifies now */
    } finally {
      delete process.env.ASHRILOGIC_BACKUP_MIRROR_DIR;
    }
  });
});
