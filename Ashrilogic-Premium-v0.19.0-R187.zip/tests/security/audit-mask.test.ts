/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — audit-trail email masking (maskEmail in
 * src/lib/server/audit.ts).
 *
 * Task-2 fix under test: audit rows never carry raw emails — maskEmail
 * keeps at most the first character of the local part plus the domain,
 * and control characters are stripped first (log-injection defense).
 *
 * audit.ts imports @/lib/db at module top, so the module is imported
 * dynamically AFTER the demo env is bound (maskEmail itself never queries
 * the database).
 */
import { describe, test, expect, beforeAll } from "bun:test";
import { ensureDemoEnv } from "./test-setup";

type AuditModule = typeof import("@/lib/server/audit");
let audit: AuditModule;

beforeAll(async () => {
  ensureDemoEnv();
  audit = await import("@/lib/server/audit");
});

describe("audit — maskEmail", () => {
  test("typical email: keeps the first local character + the domain", () => {
    expect(audit.maskEmail("sarah@elite-hospital.com")).toBe("s***@elite-hospital.com");
  });

  test("single-character local part still masks: \"a@x.com\" → \"a***@x.com\"", () => {
    expect(audit.maskEmail("a@x.com")).toBe("a***@x.com");
  });

  test("local-part head is lower-cased; the domain is untouched", () => {
    expect(audit.maskEmail("Sarah@Elite-Hospital.COM")).toBe("s***@Elite-Hospital.COM");
  });

  test("empty / null / undefined → \"\"", () => {
    expect(audit.maskEmail("")).toBe("");
    expect(audit.maskEmail(null)).toBe("");
    expect(audit.maskEmail(undefined)).toBe("");
  });

  test("non-email values collapse to \"***\" (no PII, no structure leak)", () => {
    expect(audit.maskEmail("not-an-email")).toBe("***");
    expect(audit.maskEmail("@nodomain")).toBe("***"); // empty local part
    expect(audit.maskEmail("nolocal@")).toBe("***"); // empty domain
    expect(audit.maskEmail("   ")).toBe("***"); // truthy whitespace → masked shape
  });

  test("control-character injection (log forging) is sanitized", () => {
    const masked = audit.maskEmail("sar\r\nAH@x.com");
    // no CR/LF (or any control char) can survive into the audit trail
    expect(masked).not.toMatch(/[\u0000-\u001f\u007f]/);
    expect(masked).toBe("s***@x.com");
  });

  test("output is length-capped (120) even for pathological input", () => {
    const longDomain = `${"a".repeat(300)}.com`;
    expect(audit.maskEmail(`x@${longDomain}`).length).toBeLessThanOrEqual(120);
  });
});
