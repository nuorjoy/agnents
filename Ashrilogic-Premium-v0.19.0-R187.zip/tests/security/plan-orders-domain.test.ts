/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 125: the plan-orders domain service +
 * repository (src/server/domains/plan-orders) — the second
 * route→controller→service→repository decomposition (after packages,
 * ROUND 124).
 *
 * Provable against the throwaway database with NO server, NO HTTP, NO
 * session machinery:
 *  - console listing enrichment (orgName from sealed orgJson, the
 *    corrupt-JSON and missing-instance fallbacks, the status filter)
 *  - the tenant create flow (audit row with the legacy meta; the pending
 *    swap through the shared transition core)
 *  - the admin confirm flow (the ACTIVATION event: package assigned +
 *    activation stamps + the instance.planActivate audit with
 *    activated:"true"; the 404 ORDER_NOT_FOUND envelope)
 *  - the tenant cancel flow (ownership cross-check → the plain legacy 404
 *    WITHOUT a code; the by:"tenant" audit)
 *
 * The byte-level HTTP compatibility of the four migrated routes is proven
 * live by trial-entitlement (the confirmation/cancellation/integrity
 * lifecycle) — no plan-order HTTP surface changed shape this round.
 */
import { describe, test, expect, beforeAll, afterAll } from "bun:test";
import { getTestDb, type TestDb } from "./test-setup";

let db: TestDb;
let service: typeof import("@/server/domains/plan-orders/service");
let repository: typeof import("@/server/domains/plan-orders/repository");
let HttpError: typeof import("@/lib/server/route").HttpError;

const RUN = Math.random().toString(36).slice(2, 8);
const ADMIN_ACTOR = { id: `admin-${RUN}`, name: `QA Admin ${RUN}` };
const TENANT_PRINCIPAL = { kind: "session", actorId: `owner-${RUN}`, actorName: `owner-${RUN}@example.com` };

/** Minimal live Instance row (the sealed-JSON columns the domain reads). */
function instanceJson(name: string): { systemId: string; orgJson: string; adminJson: string; prefsJson: string; modulesJson: string } {
  return {
    systemId: "hospital-management",
    orgJson: JSON.stringify({ name, country: "SA", currency: "SAR" }),
    adminJson: JSON.stringify({ name: "مالك", email: `owner-${RUN}@example.com`, role: "owner" }),
    prefsJson: JSON.stringify({ lang: "ar", theme: "light", notif: true, backup: true, audit: true, demo: false }),
    modulesJson: JSON.stringify(["pharmacy"]),
  };
}

/** Assert a promise rejects with the EXACT legacy HttpError shape. */
async function expectHttpError(promise: Promise<unknown>, status: number, message: string, code?: string): Promise<void> {
  let caught: unknown;
  try {
    await promise;
  } catch (e) {
    caught = e;
  }
  expect(caught).toBeInstanceOf(HttpError);
  const err = caught as InstanceType<typeof HttpError>;
  expect(err.status).toBe(status);
  expect(err.message).toBe(message);
  expect(err.code).toBe(code);
}

let instanceA = "";
let instanceB = "";
let packageId = "";
const createdOrderIds: string[] = [];

beforeAll(async () => {
  db = await getTestDb();
  service = await import("@/server/domains/plan-orders/service");
  repository = await import("@/server/domains/plan-orders/repository");
  ({ HttpError } = await import("@/lib/server/route"));

  /* one package (seedAdminDefaults guarantees the trio exists) + two live
   * workspaces: A carries a sane orgJson, B a CORRUPT one (fallback path) */
  await (await import("@/lib/server/admin-mapper")).seedAdminDefaults(db);
  const pkg = await db.package.findFirstOrThrow({ where: { active: true }, orderBy: { sortOrder: "asc" } });
  packageId = pkg.id;

  const a = await db.instance.create({ data: { ...instanceJson(`مستشفى أ ${RUN}`) } });
  instanceA = a.id;
  const b = await db.instance.create({
    data: { ...instanceJson("will-be-corrupt"), orgJson: "{corrupt json" },
  });
  instanceB = b.id;
});

afterAll(async () => {
  if (createdOrderIds.length > 0) {
    await db.planOrder.deleteMany({ where: { id: { in: createdOrderIds } } }).catch(() => undefined);
  }
  await db.instance.deleteMany({ where: { id: { in: [instanceA, instanceB] } } }).catch(() => undefined);
});

describe("ROUND 125 — plan-orders service (unit, throwaway db)", () => {
  test("listConsole: orgName from sealed orgJson; corrupt JSON falls back to systemId", async () => {
    const { order } = await service.createOwn(instanceA, { packageId, cycle: "monthly", methodId: "pm_default_bank" }, TENANT_PRINCIPAL);
    createdOrderIds.push(order.id);

    const console_ = await service.listConsole();
    const mine = console_.find((o) => o.id === order.id);
    expect(mine).toBeTruthy();
    expect(mine!.orgName).toBe(`مستشفى أ ${RUN}`);
    expect(mine!.systemId).toBe("hospital-management");
  });

  test("listOwn: newest first; the pending order is visible to its workspace", async () => {
    const own = await service.listOwn(instanceA);
    expect(own.length).toBeGreaterThanOrEqual(1);
    expect(own.some((o) => o.id === createdOrderIds[0])).toBe(true);
    /* newest-first ordering */
    for (let i = 1; i < own.length; i++) {
      expect(own[i - 1].createdAt >= own[i].createdAt).toBe(true);
    }
  });

  test("createOwn: audit row lands with the legacy meta (planOrderCreate)", async () => {
    const audit = await db.auditLog.findFirst({
      where: { action: "instance.planOrderCreate", actorId: TENANT_PRINCIPAL.actorId },
      orderBy: { createdAt: "desc" },
    });
    expect(audit).toBeTruthy();
    const meta = audit && audit.metaJson ? (JSON.parse(audit.metaJson) as Record<string, string>) : {};
    expect(meta.cycle).toBe("monthly");
    expect(meta.methodLabel).toBeTruthy();
    expect(meta.amount).toBeTruthy();
  });

  test("createOwn: the pending swap — a second request cancels the first (one live request)", async () => {
    const first = await service.listOwn(instanceA);
    const pendingBefore = first.filter((o) => o.status === "pending").length;

    const { order } = await service.createOwn(instanceA, { packageId, cycle: "yearly", methodId: "pm_default_bank" }, TENANT_PRINCIPAL);
    createdOrderIds.push(order.id);

    const after = await service.listOwn(instanceA);
    const pendingAfter = after.filter((o) => o.status === "pending");
    /* exactly the SAME live-request count as before — never two pending */
    expect(pendingAfter.length).toBe(pendingBefore);
    /* and the live one is the NEW order */
    expect(pendingAfter[0].id).toBe(order.id);
  });

  test("createOwn: unknown package → the legacy 404 PACKAGE_NOT_FOUND envelope", async () => {
    await expectHttpError(
      service.createOwn(instanceA, { packageId: "nonexistent-pkg", cycle: "monthly", methodId: "pm_default_bank" }, TENANT_PRINCIPAL),
      404,
      "Package not found",
      "PACKAGE_NOT_FOUND"
    );
  });

  test("confirmOrCancel: unknown order → the exact legacy 404 with ORDER_NOT_FOUND", async () => {
    await expectHttpError(service.confirmOrCancel("nonexistent-order", "paid", ADMIN_ACTOR), 404, "Order not found", "ORDER_NOT_FOUND");
  });

  test("confirmOrCancel paid: the ACTIVATION event — package assigned, stamps set, audit instance.planActivate", async () => {
    const pending = (await service.listOwn(instanceA)).find((o) => o.status === "pending");
    expect(pending).toBeTruthy();

    const result = await service.confirmOrCancel(pending!.id, "paid", ADMIN_ACTOR);
    expect(result.order.status).toBe("paid");
    /* the activation stamp on the returned instance DTO (entitlement mirror) */
    expect(result.instance.packageId).toBe(packageId);
    expect(result.instance.entitlement.planActivatedAt).toBeTruthy();
    expect(result.instance.entitlement.planCycle).toBe("yearly");

    /* the db row itself */
    const row = await db.instance.findUnique({ where: { id: instanceA } });
    expect(row?.packageId).toBe(packageId);
    expect(row?.planActivatedAt).toBeTruthy();
    expect(row?.planCycle).toBe("yearly");

    const audit = await db.auditLog.findFirst({
      where: { action: "instance.planActivate", actorId: ADMIN_ACTOR.id, targetLabel: { contains: result.order.reference } },
      orderBy: { createdAt: "desc" },
    });
    expect(audit).toBeTruthy();
    const meta = audit && audit.metaJson ? (JSON.parse(audit.metaJson) as Record<string, string>) : {};
    expect(meta.activated).toBe("true");
    expect(meta.instance).toBe(instanceA);
    expect(meta.cycle).toBe("yearly");
  });

  test("confirmOrCancel paid on an ALREADY-PAID order → the transition core refuses (409, no crash)", async () => {
    const paid = (await service.listOwn(instanceA)).find((o) => o.status === "paid");
    expect(paid).toBeTruthy();
    await expectHttpError(service.confirmOrCancel(paid!.id, "paid", ADMIN_ACTOR), 409, "Order is already paid", "ORDER_NOT_PENDING");
  });

  test("cancelOwn: cross-tenant order id → the plain legacy 404 WITHOUT a code", async () => {
    /* an order owned by A, "cancelled" through B's session */
    const own = await service.listOwn(instanceA);
    const anyOrder = own[0];
    await expectHttpError(service.cancelOwn(instanceB, anyOrder.id, TENANT_PRINCIPAL), 404, "Order not found", undefined);
  });

  test("cancelOwn: the happy path — pending → cancelled with the by:tenant audit", async () => {
    const { order } = await service.createOwn(instanceA, { packageId, cycle: "monthly", methodId: "pm_default_bank" }, TENANT_PRINCIPAL);
    createdOrderIds.push(order.id);

    const cancelled = await service.cancelOwn(instanceA, order.id, TENANT_PRINCIPAL);
    expect(cancelled.status).toBe("cancelled");

    const audit = await db.auditLog.findFirst({
      where: { action: "instance.planOrderCancel", actorId: TENANT_PRINCIPAL.actorId, targetLabel: { contains: order.reference } },
      orderBy: { createdAt: "desc" },
    });
    expect(audit).toBeTruthy();
    const meta = audit && audit.metaJson ? (JSON.parse(audit.metaJson) as Record<string, string>) : {};
    expect(meta.by).toBe("tenant");
  });

  test("createOwn: a TRASHED workspace never mints orders (404 Instance not found)", async () => {
    const trashed = await db.instance.create({
      data: { ...instanceJson(`محذوف ${RUN}`), deletedAt: new Date() },
    });
    try {
      await expectHttpError(
        service.createOwn(trashed.id, { packageId, cycle: "monthly", methodId: "pm_default_bank" }, TENANT_PRINCIPAL),
        404,
        "Instance not found",
        undefined
      );
    } finally {
      await db.instance.delete({ where: { id: trashed.id } }).catch(() => undefined);
    }
  });
});

describe("ROUND 125 — plan-orders repository (unit, throwaway db)", () => {
  test("listForConsole: the status filter narrows to exactly that status", async () => {
    const pending = await repository.listForConsole("pending");
    expect(pending.every((o) => o.status === "pending")).toBe(true);
    const paid = await repository.listForConsole("paid");
    expect(paid.every((o) => o.status === "paid")).toBe(true);
  });

  test("findLiveInstance excludes trashed rows; findOrderInstanceRef is the ownership probe", async () => {
    const live = await repository.findLiveInstance(instanceA);
    expect(live?.id).toBe(instanceA);

    const own = await service.listOwn(instanceA);
    const ref = await repository.findOrderInstanceRef(own[0].id);
    expect(ref?.instanceId).toBe(instanceA);
    expect(await repository.findOrderInstanceRef("nonexistent")).toBeNull();
  });
});
