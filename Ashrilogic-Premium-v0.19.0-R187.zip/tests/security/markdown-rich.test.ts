/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — the ROUND 129 safe-markdown extensions
 * (src/lib/markdown.ts): inline images + icon badges.
 *
 * The renderer's XSS contract is "escape everything FIRST, then convert a
 * fixed token set" — these tests pin the two new conversions against that
 * contract: only validated image sources leave the renderer as <img>, only
 * whitelisted icon keys leave as <svg>, everything hostile renders as
 * literal text. Also pins the image-before-link ordering and the
 * code-segment guard for icon tokens.
 */
import { describe, test, expect } from "bun:test";
import { renderMarkdown, MD_ICON_KEYS } from "@/lib/markdown";

describe("markdown ROUND 129 — inline images", () => {
  test("https image renders a lazy <img> with escaped alt", () => {
    const html = renderMarkdown("![لقطة الشاشة](https://cdn.example.com/a.png)");
    expect(html).toContain('<img src="https://cdn.example.com/a.png"');
    expect(html).toContain('alt="لقطة الشاشة"');
    expect(html).toContain('loading="lazy"');
  });

  test("managed /api/images/<id> refs render (the upload pipeline's refs)", () => {
    const html = renderMarkdown("![img](/api/images/cmabc123)");
    expect(html).toContain('<img src="/api/images/cmabc123"');
  });

  test("javascript: image src NEVER becomes an <img> (XSS blocked)", () => {
    const html = renderMarkdown("![x](javascript:alert(1))");
    expect(html).not.toContain("<img");
    expect(html).toContain("javascript:alert(1)"); // literal text
  });

  test("data: URLs stay literal (bodies are stored text, not payloads)", () => {
    const html = renderMarkdown("![x](data:image/png;base64,AAAA)");
    expect(html).not.toContain("<img");
  });

  test("managed refs with query/fragment are refused (exact shape only)", () => {
    expect(renderMarkdown("![x](/api/images/abc?next=1)")).not.toContain("<img");
    expect(renderMarkdown("![x](/api/images/abc#f)")).not.toContain("<img");
    expect(renderMarkdown("![x](/api/images/)")).not.toContain("<img");
  });

  test("a quote in the image URL cannot break out of the src attribute", () => {
    /* escapeHtml runs BEFORE token work, so a literal \" in the URL is an
     * &quot; entity by the time the attribute is written — the entity cannot
     * terminate the attribute, which is the security property under test. */
    const html = renderMarkdown('![x](https://a.com/b"c)');
    expect(html).toContain('src="https://a.com/b&quot;c"');
    expect(html).not.toContain('src="https://a.com/b"c"');
  });

  test("images are consumed BEFORE links (the ![…] form is not half-converted)", () => {
    const html = renderMarkdown("![alt](https://a.com/x.png)");
    expect(html).toContain("<img");
    expect(html).not.toContain("<a ");
  });
});

describe("markdown ROUND 129 — inline icon badges", () => {
  test(":rocket: renders a self-contained inline <svg>", () => {
    const html = renderMarkdown("اطلاق :rocket: الآن");
    expect(html).toContain("<svg");
    expect(html).toContain('aria-label="rocket"');
    expect(html).toContain("</svg>");
    expect(html).not.toContain(":rocket:");
  });

  test("the full whitelist is renderable and closed (24 keys)", () => {
    expect(MD_ICON_KEYS.length).toBe(25);
    for (const key of MD_ICON_KEYS) {
      const html = renderMarkdown(`:${key}:`);
      expect(html).toContain("<svg");
    }
  });

  test("unknown icon keys stay literal text", () => {
    const html = renderMarkdown(":not-an-icon: and :definitely-fake-thing:");
    expect(html).not.toContain("<svg");
    expect(html).toContain(":not-an-icon:");
  });

  test("icon tokens INSIDE code spans stay literal (docs show the token)", () => {
    const html = renderMarkdown("`:rocket:`");
    expect(html).toContain("<code>:rocket:</code>");
    expect(html).not.toContain("<svg");
  });

  test("icons inside list items render (block contexts keep inline icons)", () => {
    const html = renderMarkdown("- مهمة :check: منجزة");
    expect(html).toContain("<li>");
    expect(html).toContain("<svg");
  });
});

describe("markdown ROUND 129 — links under the new pipeline", () => {
  test("plain links still render with the hardening attributes", () => {
    const html = renderMarkdown("راجع [التوثيق](https://docs.example.com)");
    expect(html).toContain('<a href="https://docs.example.com"');
    expect(html).toContain('rel="noopener noreferrer nofollow"');
    expect(html).toContain('target="_blank"');
  });

  test("a quote inside a link URL is escaped into the attribute", () => {
    /* same entity contract as images: pre-escaped &quot; cannot terminate
     * the href attribute. */
    const html = renderMarkdown('[x](https://a.com/b"c)');
    expect(html).toContain('href="https://a.com/b&quot;c"');
    expect(html).not.toContain('href="https://a.com/b"c"');
  });
});
