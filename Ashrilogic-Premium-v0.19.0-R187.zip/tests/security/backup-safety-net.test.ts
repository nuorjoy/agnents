/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — PLATFORM BACKUP ZERO-TRAFFIC SAFETY NET (ROUND 112;
 * closes reliability audit 2-b's "opportunistic only — no traffic = no
 * backups, silent" gap).
 *
 * Proves the scheduled-backup decision logic in platform-backup.ts:
 *  - freshness is measured from the NEWEST SNAPSHOT ON DISK, not process
 *    memory: a fresh snapshot suppresses the scheduler (a restart no
 *    longer re-fires immediately — restart-happy environments stop
 *    snapshotting on every boot);
 *  - a MISSING or STALE snapshot (older than the configured interval)
 *    triggers a REAL snapshot: pg_dump custom-format archive (database.dump)
 *    + manifest with a databaseSha256 that matches the produced bytes and
 *    databaseFormat "pg_dump-custom";
 *  - autoBackup=false suppresses everything even with no snapshot;
 *  - the opportunistic nudge path (audited mutations) and the safety-net
 *    ticker share the same evaluation — one is exercised here, the
 *    boot-registration is verified via the dev server log.
 *
 * The ticker itself (startBackupSafetyNet, 15-min setInterval) is not
 * instantiated inside the test process — its registration is verified in
 * dev.log ("[instrumentation] platform backup safety-net registered").
 */
import { beforeAll, afterAll, describe, expect, test } from "bun:test";
import { mkdtempSync, rmSync, mkdirSync, existsSync, readdirSync, readFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createHash } from "node:crypto";
import { getTestDb, ensureDemoEnv, type TestDb } from "./test-setup";

ensureDemoEnv();

let db: TestDb;
let platformBackup: typeof import("@/lib/server/platform-backup");

/** each case gets its own throwaway storage root — the REAL storage/ tree
 *  (and the live snapshots inside it) is never touched */
const TMP = mkdtempSync(join(tmpdir(), "ashrilogic-backup-safety-net-"));

/** snapshot directory name for a given age (the module's own stamp shape) */
function snapshotName(ageMs: number): string {
  return `ashrilogic-${new Date(Date.now() - ageMs).toISOString().replace(/[:.]/g, "-").slice(0, 19)}`;
}

/** reset the module's process-wide scheduler state so each evaluation in
 *  this process passes the hourly wakeup gate (a fresh server process
 *  starts with lastCheck=0 — this reproduces exactly that) */
function resetScheduler(): void {
  const state = (globalThis as Record<string, unknown>).__ashrilogicBackupScheduler as
    | { lastCheck: number; running: boolean }
    | undefined;
  if (state) {
    state.lastCheck = 0;
    state.running = false;
  }
}

function snapshotDirs(root: string): string[] {
  const dir = join(root, "backups");
  if (!existsSync(dir)) return [];
  return readdirSync(dir).filter((f) => /^ashrilogic-\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}$/.test(f));
}

beforeAll(async () => {
  db = await getTestDb();
  platformBackup = await import("@/lib/server/platform-backup");
  await db.platformSetting.deleteMany({});
  await db.platformSetting.create({ data: { id: "global", autoBackup: true, backupFreq: "daily" } });
});

afterAll(async () => {
  await db.platformSetting.deleteMany({});
  rmSync(TMP, { recursive: true, force: true });
});

describe("backup safety net — disk-based freshness gate", () => {
  test("a FRESH snapshot on disk suppresses the scheduler (restart parity)", async () => {
    const root = mkdtempSync(join(TMP, "fresh-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root;
    try {
      /* a snapshot created "now" (empty dir is enough — the gate only
       * reads the NAME's timestamp, never the contents) */
      mkdirSync(join(root, "backups", snapshotName(0)), { recursive: true });

      resetScheduler();
      await platformBackup.maybeRunScheduledBackup();

      expect(snapshotDirs(root).length).toBe(1); /* nothing new created */
    } finally {
      delete process.env.ASHRILOGIC_STORAGE_DIR;
      rmSync(root, { recursive: true, force: true });
    }
  });

  test("NO snapshot at all → a REAL one is produced (zero-traffic gap closed)", async () => {
    const root = mkdtempSync(join(TMP, "missing-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root;
    try {
      resetScheduler();
      await platformBackup.maybeRunScheduledBackup();

      const dirs = snapshotDirs(root);
      expect(dirs.length).toBe(1);
      const snapDir = join(root, "backups", dirs[0]);

      /* database.dump is a REAL pg_dump custom-format snapshot of the
       * fixture database — verified end-to-end through the snapshot-health
       * battery exported for exactly this purpose (digest + PGDMP magic +
       * pg_restore --list), not re-implemented here */
      const dumpPath = join(snapDir, "database.dump");
      expect(existsSync(dumpPath)).toBe(true);

      /* manifest parses; its databaseSha256 matches the actual bytes and
       * the member is declared as a pg_dump custom-format archive (the
       * PG-era manifest carries no rowCounts — counts live in the archive
       * itself and in snapshot-health's verification) */
      const manifest = JSON.parse(readFileSync(join(snapDir, "manifest.json"), "utf8")) as {
        database: string;
        databaseFormat: string;
        databaseSha256: string;
        databaseBytes: number;
      };
      expect(manifest.database).toBe("database.dump");
      expect(manifest.databaseFormat).toBe("pg_dump-custom");
      const digest = createHash("sha256").update(readFileSync(dumpPath)).digest("hex");
      expect(manifest.databaseSha256).toBe(digest);
      expect(manifest.databaseBytes).toBeGreaterThan(0);

      /* the snapshot-health verify battery over the produced artifact:
       * ok:true with no DATABASE_* issue (pg_restore absent degrades to an
       * advisory only — asserted through ok, which advisory issues keep
       * true) */
      const snapshotHealth = await import("@/lib/server/snapshot-health");
      snapshotHealth.clearSnapshotHealthCache();
      const verdict = await snapshotHealth.verifyLatestSnapshotHealth({ force: true });
      expect(verdict.ok).toBe(true);
      expect(verdict.issues).not.toContain("DATABASE_MISSING");
      expect(verdict.issues).not.toContain("DATABASE_CORRUPT");
      expect(verdict.issues).not.toContain("DATABASE_DIGEST_MISMATCH");
    } finally {
      delete process.env.ASHRILOGIC_STORAGE_DIR;
      rmSync(root, { recursive: true, force: true });
    }
  });

  test("autoBackup=false suppresses even with no snapshot on disk", async () => {
    const root = mkdtempSync(join(TMP, "disabled-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root;
    try {
      await db.platformSetting.update({ where: { id: "global" }, data: { autoBackup: false } });
      resetScheduler();
      await platformBackup.maybeRunScheduledBackup();
      expect(snapshotDirs(root).length).toBe(0);

      /* restore for later cases */
      await db.platformSetting.update({ where: { id: "global" }, data: { autoBackup: true } });
    } finally {
      delete process.env.ASHRILOGIC_STORAGE_DIR;
      rmSync(root, { recursive: true, force: true });
    }
  });

  test("a snapshot OLDER than the interval → due again (sustained quiet periods keep snapshotting)", async () => {
    const root = mkdtempSync(join(TMP, "stale-"));
    process.env.ASHRILOGIC_STORAGE_DIR = root;
    try {
      /* pre-existing snapshot 2 days old (daily interval → stale) */
      mkdirSync(join(root, "backups", snapshotName(2 * 24 * 3_600_000)), { recursive: true });

      resetScheduler();
      await platformBackup.maybeRunScheduledBackup();

      const dirs = snapshotDirs(root);
      expect(dirs.length).toBe(2);
      /* the NEW snapshot is the newest by name */
      dirs.sort();
      expect(dirs[1] > dirs[0]).toBe(true);
      expect(existsSync(join(root, "backups", dirs[1], "database.dump"))).toBe(true);
    } finally {
      delete process.env.ASHRILOGIC_STORAGE_DIR;
      rmSync(root, { recursive: true, force: true });
    }
  });
});
