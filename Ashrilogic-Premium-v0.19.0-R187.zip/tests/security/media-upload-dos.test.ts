/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 146: the multipart upload DoS closure
 * (src/app/api/instances/[id]/store/media/route.ts + readRawBody in
 * src/lib/server/http.ts).
 *
 * THE HOLE THIS PINS SHUT: the video leg used to trust the DECLARED
 * Content-Length and then call req.formData() — which buffers the ENTIRE
 * body in memory before any route-level size check can run. A chunked or
 * Content-Length-less request (curl stdin uploads) bypassed the declared
 * check entirely; oversized NON-file fields were equally unbounded; the
 * per-file 10 MB check only ran AFTER full buffering. An authenticated
 * workspace member could OOM the Node process with one multi-GB chunked
 * body.
 *
 * THE FIX UNDER TEST: the raw bytes flow through the chunk-capped stream
 * reader (readRawBody, FORM_CAP) BEFORE parsing; the multipart parser runs
 * on a synthesized Request over the bounded buffer; multiple `video`
 * parts are refused loudly (was silent first-wins).
 *
 * The owner's 10 mandated cases, mapped:
 *   1.  valid 10 MB            → "a valid 10 MB video parses" (10 MB +
 *      multipart overhead < FORM_CAP = 10 MB + 512 KB)
 *   2.  10 MB + overhead       → same test asserts the overhead math
 *   3.  oversized Content-Length → "declared CL over FORM_CAP → 413 up front"
 *   4.  chunked oversized body → "streamed body over FORM_CAP → 413 (no CL)"
 *   5.  missing Content-Length → same as 4 (the stream cap, not the
 *      declared header, is the law)
 *   6.  oversized non-video part → "an 11 MB TEXT field → 413 at the cap"
 *   7.  malformed multipart    → "garbage body → formData() throws → 400"
 *   8.  multiple video parts   → "two video parts are visible to getAll and
 *      refused by the route law"
 *   9.  invalid MIME           → "declared mime is cross-checked" (storeValidatedVideo)
 *   10. invalid magic bytes    → "wrong magic bytes rejected" (storeValidatedVideo)
 *
 * Cases 9/10 exercise the SAME storeValidatedVideo gate the route calls
 * after parsing — the validator suite pins it end-to-end; here the exact
 * rejection surfaces are asserted so the chain (cap → parse → validate)
 * has every link covered offline.
 */
import { describe, test, expect } from "bun:test";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { readRawBody } from "@/lib/server/http";
import {
  storeValidatedVideo,
  VideoValidationError,
} from "@/lib/server/media-store";

const REPO_ROOT = join(import.meta.dir, "..", "..");
const ROUTE_PATH = join(
  REPO_ROOT,
  "src/app/api/instances/[id]/store/media/route.ts"
);

/** the route's exact ceiling — re-derived (not imported: the route exports
 *  only its POST handler; duplicating the arithmetic keeps the test honest
 *  about the contract, and a drift is caught by the source pin below). */
const VIDEO_MAX = 10 * 1024 * 1024;
const FORM_CAP = VIDEO_MAX + 512 * 1024;

function multipartRequest(
  parts: Array<{ name: string; filename?: string; type?: string; bytes: Uint8Array }>,
  opts: { omitContentLength?: boolean; declaredContentLength?: string } = {}
): Request {
  const boundary = "----ashrilogic-test-boundary-9271";
  const segments: Uint8Array[] = [];
  const push = (s: string) => segments.push(new TextEncoder().encode(s));
  for (const part of parts) {
    push(`--${boundary}\r\n`);
    push(
      part.filename !== undefined
        ? `Content-Disposition: form-data; name="${part.name}"; filename="${part.filename}"\r\n`
        : `Content-Disposition: form-data; name="${part.name}"\r\n`
    );
    if (part.type) push(`Content-Type: ${part.type}\r\n`);
    push("\r\n");
    segments.push(part.bytes);
    push("\r\n");
  }
  push(`--${boundary}--\r\n`);
  const body = new Uint8Array(segments.reduce((n, s) => n + s.length, 0));
  let offset = 0;
  for (const s of segments) {
    body.set(s, offset);
    offset += s.length;
  }
  const headers: Record<string, string> = {
    "content-type": `multipart/form-data; boundary=${boundary}`,
  };
  if (opts.declaredContentLength !== undefined) {
    headers["content-length"] = opts.declaredContentLength;
  }
  const req = new Request("http://localhost:3000/api/instances/x/store/media", {
    method: "POST",
    headers,
    body,
  });
  if (opts.omitContentLength) {
    /* simulate a chunked transfer: no Content-Length reaches the handler */
    req.headers.delete("content-length");
  }
  return req;
}

/** a minimal structurally-valid MP4 head (ftyp box) for validator probes. */
function mp4Head(tail = 512): Uint8Array {
  const bytes = new Uint8Array(12 + tail);
  bytes.set([0x00, 0x00, 0x00, 0x18], 0); // box size
  bytes.set(new TextEncoder().encode("ftyp"), 4);
  bytes.set(new TextEncoder().encode("isom"), 8); // major brand
  return bytes;
}

describe("media-upload-dos — readRawBody (the real cap)", () => {
  test("declared Content-Length over FORM_CAP → 413 up front, body never read", async () => {
    const result = await readRawBody(
      multipartRequest(
        [{ name: "video", filename: "a.mp4", type: "video/mp4", bytes: mp4Head() }],
        { declaredContentLength: String(FORM_CAP + 1) }
      ),
      FORM_CAP
    );
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.response.status).toBe(413);
      const body = (await result.response.json()) as { error?: string };
      expect(body.error).toBe("Request body too large");
    }
  });

  test("chunked-style oversized body (NO Content-Length) → 413 at the stream cap", async () => {
    /* 11 MB of body with the header stripped — the exact curl-stdin shape
     * that used to bypass the declared-length check entirely. */
    const result = await readRawBody(
      multipartRequest(
        [{ name: "video", filename: "a.mp4", type: "video/mp4", bytes: new Uint8Array(11 * 1024 * 1024) }],
        { omitContentLength: true }
      ),
      FORM_CAP
    );
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.response.status).toBe(413);
    }
  });

  test("binary fidelity — random bytes round-trip byte-for-byte", async () => {
    const payload = new Uint8Array(64 * 1024);
    for (let i = 0; i < payload.length; i++) payload[i] = (i * 7 + 13) & 0xff;
    const result = await readRawBody(
      multipartRequest([{ name: "video", filename: "a.mp4", type: "video/mp4", bytes: payload }]),
      FORM_CAP
    );
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.bytes.length).toBeGreaterThan(payload.length); // multipart envelope included
      expect(result.bytes.includes(Buffer.from(payload))).toBe(true);
    }
  });

  test("body exactly at the cap boundary is still read; one byte over is refused", async () => {
    const atCap = await readRawBody(
      multipartRequest([{ name: "video", filename: "a.mp4", type: "video/mp4", bytes: new Uint8Array(FORM_CAP - 400) }]),
      FORM_CAP
    );
    expect(atCap.ok).toBe(true);
    const overCap = await readRawBody(
      multipartRequest(
        [{ name: "video", filename: "a.mp4", type: "video/mp4", bytes: new Uint8Array(FORM_CAP) }],
        { omitContentLength: true }
      ),
      FORM_CAP
    );
    expect(overCap.ok).toBe(false);
    if (!overCap.ok) expect(overCap.response.status).toBe(413);
  });
});

describe("media-upload-dos — bounded multipart parsing (the route's exact idiom)", () => {
  test("a valid 10 MB video + multipart overhead parses under FORM_CAP (cases 1+2)", async () => {
    const video = new Uint8Array(VIDEO_MAX); // 10 MB — the honest maximum
    video.set([0x00, 0x00, 0x00, 0x18], 0);
    video.set(new TextEncoder().encode("ftyp"), 4);
    const raw = await readRawBody(
      multipartRequest([{ name: "video", filename: "clip.mp4", type: "video/mp4", bytes: video }]),
      FORM_CAP
    );
    expect(raw.ok).toBe(true); // 10 MB + ~180 B envelope < 10.5 MB cap
    if (!raw.ok) return;

    const formReq = new Request("http://localhost:3000/api/instances/x/store/media", {
      method: "POST",
      headers: { "content-type": "multipart/form-data; boundary=----ashrilogic-test-boundary-9271" },
      body: new Uint8Array(raw.bytes),
    });
    const form = await formReq.formData();
    const candidates = form.getAll("video");
    expect(candidates.length).toBe(1);
    const file = candidates[0];
    expect(file instanceof File).toBe(true);
    if (file instanceof File) {
      expect(file.size).toBe(VIDEO_MAX);
      expect(file.type).toBe("video/mp4");
      expect(file.name).toBe("clip.mp4");
    }
  });

  test("an 11 MB TEXT field (oversized non-video part) → 413 at the cap, never parsed (case 6)", async () => {
    const result = await readRawBody(
      multipartRequest([{ name: "note", bytes: new TextEncoder().encode("x".repeat(11 * 1024 * 1024)) }]),
      FORM_CAP
    );
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.response.status).toBe(413);
  });

  test("malformed multipart body → formData() throws → the route's 400 envelope (case 7)", async () => {
    const raw = await readRawBody(
      multipartRequest([{ name: "video", filename: "a.mp4", type: "video/mp4", bytes: mp4Head() }]),
      FORM_CAP
    );
    expect(raw.ok).toBe(true);
    if (!raw.ok) return;
    const garbage = Buffer.from("this is not multipart at all -- --\r\n\r\n");
    const formReq = new Request("http://localhost:3000/api/instances/x/store/media", {
      method: "POST",
      headers: { "content-type": "multipart/form-data; boundary=----nonexistent-boundary" },
      body: new Uint8Array(garbage),
    });
    await expect(formReq.formData()).rejects.toThrow();
  });

  test("multiple video parts are visible to getAll — the route refuses them (case 8)", async () => {
    const raw = await readRawBody(
      multipartRequest([
        { name: "video", filename: "a.mp4", type: "video/mp4", bytes: mp4Head() },
        { name: "video", filename: "b.mp4", type: "video/mp4", bytes: mp4Head() },
      ]),
      FORM_CAP
    );
    expect(raw.ok).toBe(true);
    if (!raw.ok) return;
    const formReq = new Request("http://localhost:3000/api/instances/x/store/media", {
      method: "POST",
      headers: { "content-type": "multipart/form-data; boundary=----ashrilogic-test-boundary-9271" },
      body: new Uint8Array(raw.bytes),
    });
    const form = await formReq.formData();
    expect(form.getAll("video").length).toBe(2);
    /* the route's law: >1 → 400 "Only one video file is allowed per upload" */
    const routeSource = readFileSync(ROUTE_PATH, "utf8");
    expect(routeSource).toContain('getAll("video")');
    expect(routeSource).toContain("Only one video file is allowed per upload");
  });

  test("invalid declared MIME + wrong magic bytes rejected by the validator (cases 9+10)", async () => {
    const mp4 = mp4Head();
    /* HTML labeled as video/mp4 — declared mime is cross-checked against the
     * derived family from the ACTUAL bytes. */
    await expect(
      storeValidatedVideo(Buffer.from(new TextEncoder().encode("<html><body>nope</body></html>")), {
        declaredMime: "video/mp4",
      })
    ).rejects.toBeInstanceOf(VideoValidationError);
    /* real MP4 magic but a text/plain declaration — the cross-check fires. */
    await expect(storeValidatedVideo(Buffer.from(mp4), { declaredMime: "text/plain" })).rejects.toBeInstanceOf(
      VideoValidationError
    );
    /* the honest pairing still passes the validator's gates. */
    const stored = await storeValidatedVideo(Buffer.from(mp4), { declaredMime: "video/mp4" });
    expect(stored.url).toMatch(/^\/api\/videos\/[a-f0-9]{64}$/);
  });
});

describe("media-upload-dos — route wiring (source-order pins, house style)", () => {
  const source = readFileSync(ROUTE_PATH, "utf8");

  test("the video leg reads the capped RAW body BEFORE any formData() call", () => {
    const rawCall = source.indexOf("readRawBody(req, FORM_CAP)");
    const formDataCall = source.indexOf("formReq.formData()");
    expect(rawCall).toBeGreaterThan(-1);
    expect(formDataCall).toBeGreaterThan(rawCall);
    /* the original unbounded call is gone — req.formData() on the REQUEST
     * object is the vulnerability; only the synthesized bounded one exists. */
    expect(source).not.toContain("await req.formData()");
  });

  test("the route keeps the honest fast path: declared Content-Length over FORM_CAP → 413 pre-read", () => {
    /* the synthesized-request branch carries the 413 mapping for the
     * readRawBody refusal (the video-specific message, same status). */
    expect(source).toMatch(/readRawBody\(req, FORM_CAP\)/);
    expect(source.indexOf("Video size exceeds the allowed 10 MB limit")).toBeGreaterThan(-1);
  });

  test("the JSON (photo) leg still flows through the bounded readJson with its own cap", () => {
    expect(source).toContain("readJson(req, JSON_BODY_CAP)");
  });

  test("FORM_CAP still covers the honest maximum (10 MB + envelope overhead)", () => {
    /* 512 KB of allowance for the multipart envelope over a 10 MB file. */
    expect(source).toContain("10 * 1024 * 1024 + 512 * 1024");
  });
});
