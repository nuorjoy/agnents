/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 136: module allowlist grandfathering.
 *
 * The strict module control round surfaced a REAL data-vs-catalog drift bug:
 * instances provisioned in earlier eras can carry ENABLED modules that are no
 * longer members of their system's catalog (e.g. the flagship hospital
 * carries `billing`, which the hospital catalog has never shipped). The
 * ROUND-36 replacement-list allowlist rejected ANY list containing such a
 * module — bricking every module edit (and the new super-admin module grid)
 * with 400 "Unknown module for this system".
 *
 * The fix (PATCH /api/instances/[id]): a replacement list is valid iff every
 * member is either in the system catalog OR already enabled on the instance
 * (legacy grandfathering). The strict invariant — a NEW unknown id may NEVER
 * enter the list — is preserved and asserted here.
 *
 * Matrix (offline, real exported handler, next/headers mocked at the module
 * boundary — the tenant-uniqueness idiom):
 *   1. NEW unknown id in the replacement list → 400 (strict invariant).
 *   2. A LEGACY enabled module (outside the catalog) in the list → 200
 *      (grandfathered; the row keeps it enabled).
 *   3. Catalog-only replacement → 200 (normal path never regressed).
 */
import { describe, test, expect, beforeAll, afterAll, mock } from "bun:test";
import { getTestDb, ensureDemoEnv, type TestDb } from "./test-setup";

ensureDemoEnv();

/* Mock BEFORE any dynamic import of the route (instance-session reads
 * cookies through next/headers). The jar carries the crafted owner session. */
const cookieJar = new Map<string, string>();
mock.module("next/headers", () => ({
  cookies: async () => ({
    get: (name: string) =>
      cookieJar.has(name) ? { name, value: cookieJar.get(name) as string } : undefined,
    set: (name: string, value: string) => {
      cookieJar.set(name, value);
    },
    delete: (name: string) => {
      cookieJar.delete(name);
    },
  }),
  headers: async () => ({ get: () => undefined }),
  draftMode: async () => ({ isEnabled: () => false }),
}));

const RUN = `r136mods-${Date.now().toString(36)}`;
const HOST = "test.local";
let db: TestDb;
let instanceId = "";
let patch: typeof import("../../src/app/api/instances/[id]/route").PATCH;

beforeAll(async () => {
  db = await getTestDb();
  const tokens = await import("../../src/lib/server/tokens");
  const cookieNames = await import("../../src/lib/server/cookie-names");
  const { sealAdminSection } = await import("../../src/lib/server/instance-mapper");
  patch = (await import("../../src/app/api/instances/[id]/route")).PATCH;

  /* an instance of a system whose catalog NEVER shipped `billing` */
  const sealed = sealAdminSection({ name: "مالك", email: `${RUN}@grandfather.test`, role: "owner", twoFA: false });
  const row = await db.instance.create({
    data: {
      systemId: "hospital-management",
      orgJson: JSON.stringify({
        name: `Org-${RUN}`,
        country: "SA",
        currency: "SAR",
        timezone: "Asia/Riyadh",
        address: "برج الاختبار",
        phone: `+9665${Date.now().toString().slice(-9)}`,
      }),
      adminJson: sealed.adminJson,
      adminEmailIndex: sealed.adminEmailIndex,
      prefsJson: JSON.stringify({ lang: "ar", theme: "light", notif: true, backup: true, audit: true, demo: false }),
      /* the legacy drift: `billing` enabled but outside the hospital catalog */
      modulesJson: JSON.stringify(["patients", "appointments", "billing"]),
      demo: false,
      deletedAt: null,
    },
  });
  instanceId = row.id;

  /* craft the owner's workspace session exactly like a real sign-in */
  const sessions = await import("../../src/lib/server/sessions");
  const jti = `jti-${RUN}`;
  const { token, expiresAt } = tokens.issueToken("instance", instanceId, 60 * 60 * 1000, 0, jti);
  await sessions.recordSession({ scope: "instance", subjectId: instanceId, jti, expiresAt });
  cookieJar.set(cookieNames.INSTANCE_COOKIE_NAME, token);
});

afterAll(async () => {
  /* full cascade cleanup — the throwaway DB, but leave it spotless anyway */
  await db.sessionRecord.deleteMany({ where: { subjectId: instanceId } }).catch(() => undefined);
  await db.instance.deleteMany({ where: { id: instanceId } }).catch(() => undefined);
  await new Promise((resolve) => setTimeout(resolve, 600));
  await db.$disconnect();
});

async function patchModules(modules: string[]): Promise<Response> {
  return patch(
    new Request(`http://${HOST}/api/instances/${instanceId}`, {
      method: "PATCH",
      headers: {
        "content-type": "application/json",
        host: HOST,
        origin: `http://${HOST}`,
        "sec-fetch-site": "same-origin",
      },
      body: JSON.stringify({ modules }),
    }),
    { params: Promise.resolve({ id: instanceId }) }
  );
}

describe("ROUND 136 — module allowlist grandfathering (PATCH /api/instances/[id])", () => {
  test("a NEW unknown module id is STILL rejected (strict invariant intact)", async () => {
    const res = await patchModules(["patients", "evil-module", "billing"]);
    expect(res.status).toBe(400);
    const body = (await res.json()) as { error?: string };
    expect(body.error).toContain("evil-module");
  });

  test("a LEGACY enabled module outside the catalog is grandfathered → 200", async () => {
    const res = await patchModules(["patients", "appointments", "billing"]);
    expect(res.status).toBe(200);
    const body = (await res.json()) as { modules?: string[] };
    expect(body.modules).toContain("billing");
  });

  /* R163 — the strict e-store ⇄ catalog coupling changed this showcase
   * instance's contract: it has NO package and NO trial clock (platform-
   * managed, every feature ON), so the store is effectively ON and the
   * health catalog forces products+inventory (see store-module-gate.test.ts
   * for the full matrix). The normal path keeps working as long as the
   * forced pair rides along — a list that drops it is refused (409). */
  test("catalog-only replacement still works (normal path, R163 forced pair kept)", async () => {
    const res = await patchModules(["patients", "products", "inventory"]);
    expect(res.status).toBe(200);
    const body = (await res.json()) as { modules?: string[] };
    expect(body.modules).toEqual(["patients", "products", "inventory"]);
  });
});

