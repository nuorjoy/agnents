/// <reference types="bun-types" />
/**
 * SECURITY/POLICY REGRESSION — ROUND 134: the ID DISPLAY POLICY.
 *
 * The owner's directive is explicit:
 *   «في جميع الأنظمة: اجعل جميع الـIDs تحمل الأرقام (1,2,3,4,5,6,7,8,9,0)
 *    بدلاً عن الأرقام (١،٢،٣،٤،٥،٦،٧،٨،٩،٠) بدقة عالية جداً»
 *
 * The policy split (R133 money policy stays, IDs flipped to Western):
 *   • fmtId(code, ANY lang) → the code VERBATIM (canonical ASCII digits);
 *   • ID cells render dir={idDir} — always "ltr";
 *   • fmtNum / fmtMoneyCell KEEP the Arabic-Indic RTL policy for money and
 *     quantity stat cells (unchanged by this directive — that was a
 *     different, still-standing R133 instruction).
 *
 * This suite pins all three halves at the exact seams:
 *   1. UNIT — the formatting functions themselves (every locale);
 *   2. SOURCE CONTRACT — fmtId's body must contain NO digit-rewrite (a
 *      regression that reintroduces toArabicDigits inside fmtId fails
 *      here, not in a screenshot review);
 *   3. CALL-SITE CONTRACT — no component renders an ID through
 *      toArabicDigits directly (the fmtId choke point is the only legal
 *      path; the single remaining toArabicDigits consumer is the
 *      date-cell fallback inside record-detail-sheet, which is NOT an ID).
 */
import { describe, test, expect } from "bun:test";
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";

const { fmtId, fmtNum, fmtMoneyCell, numDir, idDir, toArabicDigits } = await import("@/lib/utils");

const CODES = [
  "SHF-00000002",
  "POS-00061028",
  "EXP-00039001",
  "MRN-00010240",
  "INV-2026-0001",
  "A-07",
  "2026-001",
];

describe("ROUND 134 — ID display policy (Western digits, every locale)", () => {
  test("fmtId passes every identifier VERBATIM for ar / en / hi", () => {
    for (const code of CODES) {
      expect(fmtId(code, "ar")).toBe(code);
      expect(fmtId(code, "en")).toBe(code);
      expect(fmtId(code, "hi")).toBe(code);
    }
  });

  test("fmtId never emits Arabic-Indic digits", () => {
    for (const code of CODES) {
      for (const lang of ["ar", "en", "hi"] as const) {
        const out = fmtId(code, lang);
        expect(out).not.toMatch(/[٠-٩]/);
      }
    }
  });

  test("idDir is LTR (the ID cell direction, every locale)", () => {
    expect(idDir).toBe("ltr");
  });

  test("the R133 Arabic-Indic MONEY/quantity policy is intact (the split)", () => {
    /* money + counts still localize: Arabic-Indic for ar, Latin for others */
    expect(fmtNum(1234, "ar")).toMatch(/[٠-٩]/);
    expect(fmtNum(1234, "en")).toBe("1,234");
    expect(fmtMoneyCell(411.15, "ar")).toMatch(/[٠-٩]/);
    expect(numDir("ar")).toBe("rtl");
    expect(numDir("en")).toBe("ltr");
    /* toArabicDigits itself keeps working (date-cell fallback consumer) */
    expect(toArabicDigits("2026-05-12")).toBe("٢٠٢٦-٠٥-١٢");
  });
});

describe("ROUND 134 — ID policy source contracts", () => {
  const REPO_ROOT = join(import.meta.dir, "..", "..");
  const UTILS = readFileSync(join(REPO_ROOT, "src/lib/utils.ts"), "utf8");

  test("fmtId's body contains no digit rewrite (toArabicDigits stays outside)", () => {
    const body = UTILS.slice(UTILS.indexOf("export function fmtId"));
    const bodyOnly = body.slice(0, body.indexOf("}") + 1);
    expect(bodyOnly).not.toContain("toArabicDigits");
    expect(bodyOnly).not.toContain("ARABIC_DIGITS");
    expect(bodyOnly).not.toMatch(/replace\(/);
  });

  test("no component renders IDs through toArabicDigits directly (fmtId is the choke point)", () => {
    const offenders: string[] = [];
    const walk = (dir: string): void => {
      for (const entry of readdirSync(dir)) {
        const path = join(dir, entry);
        if (statSync(path).isDirectory()) {
          walk(path);
        } else if (entry.endsWith(".tsx") || entry.endsWith(".ts")) {
          const src = readFileSync(path, "utf8");
          if (src.includes("toArabicDigits(")) {
            offenders.push(path.replace(join(REPO_ROOT, "src") + "/", ""));
          }
        }
      }
    };
    walk(join(REPO_ROOT, "src"));
    /* the only legal consumers: the definition itself (lib/utils.ts), the
     * date-cell fallback in the record detail sheet (a DATE, not an
     * identifier — the R133 policy keeps dates), and the documented
     * NON-ID text converters — the business PROFILE sheets' arNumIfAR
     * (profile summary text, not table/print IDs — ROUND 160's profile
     * sheets; the R162 battery caught the allowlist drifting) and
     * module-data's file-size formatter (KB/MB labels).
     * ROUND 145: offenders are SORTED before comparison — readdirSync
     * order is filesystem-dependent (mtime-sensitive), and the policy is
     * about WHICH files may consume toArabicDigits, never their walk
     * order. The literal is already alphabetical. */
    expect(offenders.slice().sort()).toEqual([
      "components/dashboard/views/business/certificate-profile-sheet.tsx",
      "components/dashboard/views/business/parent-profile-sheet.tsx",
      /* ROUND 166: the resident profile sheet joins the family — the same
       * arNumIfAR profile-summary-text pattern as its siblings. */
      "components/dashboard/views/business/record-detail-sheet.tsx",
      "components/dashboard/views/business/resident-profile-sheet.tsx",
      "components/dashboard/views/business/staff-profile-sheet.tsx",
      "components/dashboard/views/business/teacher-profile-sheet.tsx",
      "lib/module-data.ts",
      "lib/utils.ts",
    ]);
  });
});
