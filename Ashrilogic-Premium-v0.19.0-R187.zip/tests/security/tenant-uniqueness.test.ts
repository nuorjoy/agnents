/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 134-E: deep tenant identity uniqueness.
 *
 * The owner's directive: «قم بالتحقق بطريقة عميقة جداً من أي مستأجر جديد
 * يريد استخدام النظام انه (البريد الإلكتروني، رقم الهاتف) غير مستخدم
 * سابقاً» — a NEW tenant's email AND phone must both be verifiably
 * never-used-before, DEEP (live + soft-deleted + demo rows).
 *
 * Three levels, all offline against the throwaway test database:
 *
 *  1. ENGINE (src/lib/server/tenant-uniqueness.ts):
 *     - normalizePhoneDeep — the pure comparison key (punctuation folding,
 *       Arabic-Indic digits → Western, one leading "00" dropped, last-9
 *       truncation, short-number passthrough, garbage → "");
 *     - deepCheckTenantIdentity — the blind-index email path (case drift),
 *       the bounded legacy NULL-index decrypt fallback, the orgJson phone
 *       path (malformed JSON tolerated), and the DEEP property itself:
 *       soft-deleted (trashed) AND demo rows still collide.
 *
 *  2. AVAILABILITY ROUTE (POST /api/instances/check-availability), unit
 *     level — the REAL exported handler invoked with synthetic Requests:
 *     the boolean-only envelope (exactly {emailFree, phoneUsed}), the
 *     origin guard, the zod stage (at least one field / email shape),
 *     malformed JSON, and the durable 30/10min per-IP limiter (429 +
 *     Retry-After on the 31st).
 *
 *  3. PROVISIONING GUARD (POST /api/instances), unit level — the REAL
 *     exported handler with next/headers MOCKED at the module boundary
 *     (the orders-domain idiom): the 409 machine-code envelopes
 *     (EMAIL_ALREADY_USED / PHONE_ALREADY_USED), the "no row was created"
 *     property, the anti-bypass property (a body-crafted `ownerVerified:
 *     true` cannot exempt — the session is the only truth), the ROUND-82
 *     owner-reuse exemption (a VALID crafted instance session + the same
 *     email → 201, today's behavior preserved), and the fresh-signup
 *     happy path (unique identity → 201).
 */
import { describe, test, expect, beforeAll, beforeEach, afterAll, mock } from "bun:test";
import { getTestDb, resetRateTable, type TestDb, ensureDemoEnv } from "./test-setup";

ensureDemoEnv();

/* Mock BEFORE any dynamic import of the routes (instance-session reads
 * cookies through next/headers). The jar is controllable per test: empty =
 * the anonymous fresh flow; a crafted instance-session cookie = the
 * ROUND-82 owner-reuse flow. */
const cookieJar = new Map<string, string>();
mock.module("next/headers", () => ({
  cookies: async () => ({
    get: (name: string) =>
      cookieJar.has(name) ? { name, value: cookieJar.get(name) as string } : undefined,
    set: (name: string, value: string) => {
      cookieJar.set(name, value);
    },
    delete: (name: string) => {
      cookieJar.delete(name);
    },
  }),
  headers: async () => ({ get: () => undefined }),
  draftMode: async () => ({ isEnabled: () => false }),
}));

const HOST = "localhost:3000";
const RUN = Math.random().toString(36).slice(2, 8);
/** unique per-file XFF pool so per-IP limiters never cross-contaminate */
let ipSeq = 0;
function nextIp(): string {
  ipSeq += 1;
  return `198.51.100.${(ipSeq % 250) + 1}`;
}
/** a random never-before-used phone (13 digits, distinct last-9) */
function freshPhone(): string {
  return `+96655${String(Math.floor(Math.random() * 1e8)).padStart(8, "0")}`;
}
function freshEmail(tag: string): string {
  return `${tag}-${RUN}-${Math.random().toString(36).slice(2, 7)}@dup.test`;
}

let db: TestDb;
let engine: typeof import("@/lib/server/tenant-uniqueness");
let mapper: typeof import("@/lib/server/instance-mapper");
let instancesRoute: typeof import("@/app/api/instances/route");
let availabilityRoute: typeof import("@/app/api/instances/check-availability/route");
let tokens: typeof import("@/lib/server/tokens");
let sessions: typeof import("@/lib/server/sessions");
let catalog: typeof import("@/data/catalog");
let cookieNames: typeof import("@/lib/server/cookie-names");

/* ------------------------------------------------------------------ */
/* fixture rows (sealed exactly like the provisioning route)          */
/* ------------------------------------------------------------------ */

const createdIds: string[] = [];

async function makeInstance(opts: {
  email: string;
  phone: string;
  legacy?: boolean;
  trashed?: boolean;
  demo?: boolean;
  orgJson?: string;
}): Promise<string> {
  let adminJson: string;
  let adminEmailIndex: string | null;
  if (opts.legacy) {
    /* pre-round-35 shape: plaintext email, no blind index */
    adminJson = JSON.stringify({ name: "مالك قديم", email: opts.email, role: "owner", twoFA: false });
    adminEmailIndex = null;
  } else {
    const sealed = mapper.sealAdminSection({ name: "مالك", email: opts.email, role: "owner", twoFA: false });
    adminJson = sealed.adminJson;
    adminEmailIndex = sealed.adminEmailIndex;
  }
  const row = await db.instance.create({
    data: {
      systemId: "hospital-management",
      orgJson:
        opts.orgJson ??
        JSON.stringify({
          name: `Org-${RUN}`,
          country: "SA",
          currency: "SAR",
          timezone: "Asia/Riyadh",
          address: "برج الاختبار",
          phone: opts.phone,
        }),
      adminJson,
      adminEmailIndex,
      prefsJson: JSON.stringify({ lang: "ar", theme: "light", notif: true, backup: true, audit: true, demo: false }),
      modulesJson: JSON.stringify(["patients"]),
      demo: opts.demo ?? false,
      deletedAt: opts.trashed ? new Date() : null,
    },
  });
  createdIds.push(row.id);
  return row.id;
}

/** A — live row, sealed email + spaced phone */
const A_EMAIL = `alpha-${RUN}@dup.test`;
const A_PHONE = "+966 50 111 2222";
/** B — SOFT-DELETED row (the DEEP property: still owns its identity) */
const B_EMAIL = `beta-${RUN}@dup.test`;
const B_PHONE = "+971501112233";
/** C — legacy NULL-index row + Arabic-Indic stored phone + demo flag */
const C_EMAIL = `legacy-${RUN}@dup.test`;
const C_PHONE = "٠٥٠١٢٣٤٥٦٧"; /* 0501234567 in Arabic-Indic digits */

let idA = "";
let idB = "";
let idC = "";

beforeAll(async () => {
  db = await getTestDb();
  engine = await import("@/lib/server/tenant-uniqueness");
  mapper = await import("@/lib/server/instance-mapper");
  instancesRoute = await import("@/app/api/instances/route");
  availabilityRoute = await import("@/app/api/instances/check-availability/route");
  tokens = await import("@/lib/server/tokens");
  sessions = await import("@/lib/server/sessions");
  catalog = await import("@/data/catalog");
  cookieNames = await import("@/lib/server/cookie-names");

  idA = await makeInstance({ email: A_EMAIL, phone: A_PHONE });
  idB = await makeInstance({ email: B_EMAIL, phone: B_PHONE, trashed: true });
  idC = await makeInstance({ email: C_EMAIL, phone: C_PHONE, legacy: true, demo: true });
  /* D — malformed orgJson must never break the scan */
  await makeInstance({ email: freshEmail("broken"), phone: "", orgJson: "{not-json" });
});

beforeEach(async () => {
  /* fresh limiter windows per test (guards + probes both burn slots) */
  await resetRateTable(db);
});

afterAll(async () => {
  cookieJar.clear();
  if (createdIds.length > 0) {
    await db.sessionRecord.deleteMany({ where: { subjectId: { in: createdIds } } }).catch(() => undefined);
    await db.instance.deleteMany({ where: { id: { in: createdIds } } }).catch(() => undefined);
  }
  await resetRateTable(db);
  /* drain the route's fire-and-safe background work (notifyEvent's mail
   * outbox settle) BEFORE disconnecting the engine — a mid-write
   * disconnect is console noise at best, a flaky stderr blast at worst */
  await new Promise((resolve) => setTimeout(resolve, 600));
  await db.$disconnect();
});

/* ------------------------------------------------------------------ */
/* 1 — the pure phone comparison key                                   */
/* ------------------------------------------------------------------ */

describe("normalizePhoneDeep — the deep comparison key", () => {
  test("punctuation, spacing, +/00 prefixes and Arabic-Indic digits all fold to ONE key", () => {
    const variants = [
      "+966 50 123 4567",
      "+966-501-234567",
      "00966501234567",
      "(966) 501 234567",
      "+٩٦٦٥٠١٢٣٤٥٦٧", /* fully Arabic-Indic */
      "٠٥٠١۲۳۴۵۶۷", /* Eastern Arabic-Indic local format (۰-۹) */
    ];
    const keys = new Set(variants.map((v) => engine.normalizePhoneDeep(v)));
    expect(keys.size).toBe(1);
    expect([...keys][0]).toBe("501234567");
  });

  test("the comparison key is the LAST 9 DIGITS for long numbers", () => {
    expect(engine.normalizePhoneDeep("+966500000001")).toBe("500000001");
    expect(engine.normalizePhoneDeep("966114800088")).toBe("114800088");
  });

  test("short numbers (<9 digits) compare verbatim — no truncation", () => {
    expect(engine.normalizePhoneDeep("911")).toBe("911");
    expect(engine.normalizePhoneDeep("12345678")).toBe("12345678");
    expect(engine.normalizePhoneDeep("+966 911")).toBe("966911");
  });

  test("garbage and empty inputs degrade to \"\" (never throw)", () => {
    expect(engine.normalizePhoneDeep("")).toBe("");
    expect(engine.normalizePhoneDeep("+++")).toBe("");
    expect(engine.normalizePhoneDeep("+()")).toBe("");
    expect(engine.normalizePhoneDeep("not a phone")).toBe("");
  });
});

/* ------------------------------------------------------------------ */
/* 2 — the deep scan engine                                            */
/* ------------------------------------------------------------------ */

describe("deepCheckTenantIdentity — deep email + phone scan", () => {
  test("EMAIL: blind-index match survives case drift", async () => {
    const res = await engine.deepCheckTenantIdentity(db, { email: `ALPHA-${RUN.toUpperCase()}@DUP.TEST` });
    expect(res.emailUsedBy).toBe(idA);
    expect(res.phoneUsedBy).toBeNull();
  });

  test("EMAIL: a fresh address is free (emailUsedBy null)", async () => {
    const res = await engine.deepCheckTenantIdentity(db, { email: freshEmail("engine") });
    expect(res.emailUsedBy).toBeNull();
  });

  test("PHONE: punctuation drift still collides with the stored org phone", async () => {
    const res = await engine.deepCheckTenantIdentity(db, { phone: "+966501112222" });
    expect(res.phoneUsedBy).toBe(idA);
  });

  test("DEEP: a SOFT-DELETED (trashed) row still owns its email AND phone", async () => {
    const byEmail = await engine.deepCheckTenantIdentity(db, { email: B_EMAIL });
    expect(byEmail.emailUsedBy).toBe(idB);
    const byPhone = await engine.deepCheckTenantIdentity(db, { phone: B_PHONE });
    expect(byPhone.phoneUsedBy).toBe(idB);
  });

  test("DEEP: a DEMO row still owns its identity", async () => {
    const res = await engine.deepCheckTenantIdentity(db, { email: C_EMAIL });
    expect(res.emailUsedBy).toBe(idC);
  });

  test("LEGACY: a NULL-adminEmailIndex row is matched via the sealed-email fallback", async () => {
    const res = await engine.deepCheckTenantIdentity(db, { email: C_EMAIL.toUpperCase() });
    expect(res.emailUsedBy).toBe(idC);
  });

  test("PHONE: an Arabic-Indic STORED phone collides with a Western probe", async () => {
    /* stored ٠٥٠١٢٣٤٥٦٧ (0501234567) vs probed +966 50 123 4567 */
    const res = await engine.deepCheckTenantIdentity(db, { phone: "+966 50 123 4567" });
    expect(res.phoneUsedBy).toBe(idC);
  });

  test("both sides free at once + malformed orgJson rows never break the scan", async () => {
    const res = await engine.deepCheckTenantIdentity(db, {
      email: freshEmail("both-free"),
      phone: freshPhone(),
    });
    expect(res.emailUsedBy).toBeNull();
    expect(res.phoneUsedBy).toBeNull();
  });

  test("empty input short-circuits without touching the table", async () => {
    const res = await engine.deepCheckTenantIdentity(db, {});
    expect(res.emailUsedBy).toBeNull();
    expect(res.phoneUsedBy).toBeNull();
  });

  test("the machine-code wire constants are the documented ones", () => {
    expect(engine.TENANT_EMAIL_USED).toBe("EMAIL_ALREADY_USED");
    expect(engine.TENANT_PHONE_USED).toBe("PHONE_ALREADY_USED");
  });
});

/* ------------------------------------------------------------------ */
/* 3 — POST /api/instances/check-availability (the real handler)       */
/* ------------------------------------------------------------------ */

function postAvailability(body: unknown, headers: Record<string, string> = {}): Promise<Response> {
  return availabilityRoute.POST(
    new Request(`http://${HOST}/api/instances/check-availability`, {
      method: "POST",
      body: typeof body === "string" ? body : JSON.stringify(body),
      headers: { "content-type": "application/json", host: HOST, ...headers },
    })
  );
}

describe("POST /api/instances/check-availability — the public probe", () => {
  test("fresh identity → 200 with EXACTLY { emailFree: true, phoneUsed: false }", async () => {
    const res = await postAvailability({ email: freshEmail("probe"), phone: freshPhone() });
    expect(res.status).toBe(200);
    const body = (await res.json()) as Record<string, unknown>;
    expect(Object.keys(body).sort()).toEqual(["emailFree", "phoneUsed"]);
    expect(body.emailFree).toBe(true);
    expect(body.phoneUsed).toBe(false);
  });

  test("a registered email → emailFree false (deep verdict, no ids echoed)", async () => {
    const res = await postAvailability({ email: A_EMAIL });
    expect(res.status).toBe(200);
    const body = (await res.json()) as Record<string, unknown>;
    expect(body.emailFree).toBe(false);
    /* booleans ONLY — never the colliding row */
    expect(JSON.stringify(body)).not.toContain(idA);
  });

  test("a phone owned by a TRASHED instance → phoneUsed true (deep semantics)", async () => {
    const res = await postAvailability({ phone: B_PHONE });
    expect(res.status).toBe(200);
    const body = (await res.json()) as { phoneUsed?: boolean };
    expect(body.phoneUsed).toBe(true);
  });

  test("phone-only probe → the neutral emailFree: true side", async () => {
    const res = await postAvailability({ phone: freshPhone() });
    expect(res.status).toBe(200);
    const body = (await res.json()) as { emailFree?: boolean; phoneUsed?: boolean };
    expect(body.emailFree).toBe(true);
    expect(body.phoneUsed).toBe(false);
  });

  test("neither field → 400 (at least one required)", async () => {
    const res = await postAvailability({});
    expect(res.status).toBe(400);
  });

  test("malformed email shape → 400", async () => {
    const res = await postAvailability({ email: "not-an-email" });
    expect(res.status).toBe(400);
  });

  test("malformed JSON body → 400", async () => {
    const res = await postAvailability("{broken");
    expect(res.status).toBe(400);
  });

  test("cross-origin POST → 403 before anything else", async () => {
    const res = await postAvailability({ email: freshEmail("origin") }, { origin: "http://evil.example" });
    expect(res.status).toBe(403);
    const body = (await res.json()) as { error?: string };
    expect(body.error).toBe("Cross-origin request rejected");
  });

  test("durable per-IP limiter: the 31st probe inside 10 minutes → 429 + Retry-After", async () => {
    const ip = "203.0.113.77";
    for (let i = 0; i < 30; i++) {
      const res = await postAvailability({ email: freshEmail(`flood${i}`) }, { "x-forwarded-for": ip });
      expect(res.status).toBe(200);
    }
    const refused = await postAvailability({ email: freshEmail("over") }, { "x-forwarded-for": ip });
    expect(refused.status).toBe(429);
    expect(refused.headers.get("retry-after")).toBeTruthy();
    /* another IP is unaffected — the limit is per-IP, not global */
    const other = await postAvailability({ email: freshEmail("otherip") }, { "x-forwarded-for": "203.0.113.78" });
    expect(other.status).toBe(200);
  });
});

/* ------------------------------------------------------------------ */
/* 4 — POST /api/instances (the provisioning guard, real handler)      */
/* ------------------------------------------------------------------ */

function instancePayload(overrides: { email?: string; phone?: string; extra?: Record<string, unknown> }): string {
  const systemId = "hospital-management";
  const mods = catalog.systemMods(catalog.SYSTEM_MAP[systemId]).slice(0, 2);
  return JSON.stringify({
    systemId,
    org: {
      name: `مؤسسة ${RUN}`,
      country: "SA",
      currency: "SAR",
      timezone: "Asia/Riyadh",
      address: "برج التسجيل",
      phone: overrides.phone ?? freshPhone(),
    },
    admin: {
      name: "مالك الاختبار",
      email: overrides.email ?? freshEmail("owner"),
      role: "owner",
      twoFA: false,
      password: "correct signup horse 7",
    },
    prefs: { lang: "ar", theme: "light", notif: true, backup: true, audit: true, demo: false },
    modules: mods,
    ...(overrides.extra ?? {}),
  });
}

function postInstance(body: string): Promise<Response> {
  return instancesRoute.POST(
    new Request(`http://${HOST}/api/instances`, {
      method: "POST",
      body,
      headers: {
        "content-type": "application/json",
        host: HOST,
        origin: `http://${HOST}`,
        "x-forwarded-for": nextIp(),
      },
    })
  );
}

describe("POST /api/instances — the deep duplicate guard", () => {
  test("duplicate EMAIL → 409 EMAIL_ALREADY_USED, no row created", async () => {
    const before = await db.instance.count();
    const res = await postInstance(instancePayload({ email: A_EMAIL }));
    expect(res.status).toBe(409);
    const body = (await res.json()) as { error?: string; code?: string };
    expect(body.code).toBe("EMAIL_ALREADY_USED");
    expect(body.error).toBe("This email is already registered in the platform");
    expect(await db.instance.count()).toBe(before);
  });

  test("duplicate PHONE (owned by a TRASHED row) → 409 PHONE_ALREADY_USED", async () => {
    const res = await postInstance(instancePayload({ phone: B_PHONE }));
    expect(res.status).toBe(409);
    const body = (await res.json()) as { error?: string; code?: string };
    expect(body.code).toBe("PHONE_ALREADY_USED");
    expect(body.error).toBe("This phone number is already registered in the platform");
  });

  test("legacy NULL-index email + Arabic-Indic phone collisions are caught too", async () => {
    const byEmail = await postInstance(instancePayload({ email: C_EMAIL }));
    expect(byEmail.status).toBe(409);
    const byPhone = await postInstance(instancePayload({ phone: "+٩٦٦٥٠ ١٢٣ ٤٥٦٧" }));
    expect(byPhone.status).toBe(409);
  });

  test("ANTI-BYPASS: a body-crafted ownerVerified:true cannot exempt without a session", async () => {
    const res = await postInstance(
      instancePayload({ email: A_EMAIL, extra: { ownerVerified: true } })
    );
    expect(res.status).toBe(409);
    const body = (await res.json()) as { code?: string };
    expect(body.code).toBe("EMAIL_ALREADY_USED");
  });

  test("fresh unique identity → 201 (the guard never over-blocks)", async () => {
    const res = await postInstance(instancePayload({ email: freshEmail("fresh"), phone: freshPhone() }));
    expect(res.status).toBe(201);
    const created = (await res.json()) as { id?: string };
    expect(created.id).toBeTruthy();
    createdIds.push(created.id as string);
  });

  test("ROUND-82 reuse exemption: a VALID owner session + the SAME email → 201", async () => {
    const reuseEmail = freshEmail("reuse-owner");
    const ownerId = await makeInstance({ email: reuseEmail, phone: freshPhone() });
    /* craft the owner's workspace session exactly like a real sign-in */
    const { token, expiresAt } = tokens.issueToken("instance", ownerId, 60 * 60 * 1000, 0, `jti-${RUN}-reuse`);
    await sessions.recordSession({ scope: "instance", subjectId: ownerId, jti: `jti-${RUN}-reuse`, expiresAt });
    cookieJar.set(cookieNames.INSTANCE_COOKIE_NAME, token);

    /* same email — and even a phone ALREADY registered elsewhere: the
     * reuse flow is exempt from BOTH deep checks (today's behavior). */
    const res = await postInstance(instancePayload({ email: reuseEmail, phone: B_PHONE }));
    expect(res.status).toBe(201);
    const created = (await res.json()) as { id?: string };
    expect(created.id).toBeTruthy();
    expect(created.id).not.toBe(ownerId);
    createdIds.push(created.id as string);
    cookieJar.clear();
  });
});
