/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 165: the durable campaign dispatch lifecycle
 * (src/server/domains/campaigns + the mail-service dispatch primitives).
 *
 * THE BUG THIS PINSHUTS: the historical send path counted the whole
 * audience (subscriber.count()) but delivered to findMany({ take: 5000 })
 * — a SILENT TRUNCATION above 5,000 subscribers — and stamped the
 * campaign "sent" inside the HTTP request before any delivery outcome
 * existed.
 *
 * Provable against the throwaway database with NO server, NO HTTP:
 *  1. THE CLAIM — draft → "sending" (CAS): exactly one claimer wins, the
 *     loser gets the historical 409 envelope; the audience + sender are
 *     snapshotted; no delivery happens in the claim.
 *  2. NO TRUNCATION — keyset cursor pagination enumerates the FULL
 *     audience across sweeps at ANY list size (7 subscribers, batch of 2:
 *     four sweeps, 7 per-recipient rows — nothing dropped, nothing
 *     duplicated).
 *  3. CRASH-RESUME IDEMPOTENCE — re-running the enqueue phase from the
 *     persisted cursor never duplicates a per-recipient row (unique
 *     idempotency keys arbitrate).
 *  4. PER-RECIPIENT DELIVERY — every pending row is driven in place
 *     through the spool transport (retry/backoff pipeline, stable
 *     Message-ID, terminal settle).
 *  5. THE COMPLETION GATE — "sent" is stamped ONLY when the audience is
 *     exhausted AND zero rows are pending; delivered/failed counts and
 *     both audit rows (campaign.send + campaign.dispatch-completed) land.
 *  6. THE LIFECYCLE GUARDS — edit works on a draft, 409s on sending/sent;
 *     delete 409s on a mid-flight "sending" campaign; invalid addresses
 *     are skipped (never silently truncated); an exhausted row
 *     dead-letters after the retry budget.
 */
import { describe, test, expect, beforeAll, beforeEach, afterAll } from "bun:test";
import { mkdtempSync, rmSync, readdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { getTestDb, ensureDemoEnv, type TestDb } from "./test-setup";
import { encryptField } from "@/lib/server/crypto-vault";
import { __resetObjectStorageForTests } from "@/lib/server/storage/object-store";

let db: TestDb;
let service: typeof import("@/server/domains/campaigns/service");
let repo: typeof import("@/server/domains/campaigns/repository");
let HttpError: typeof import("@/lib/server/route").HttpError;

const RUN = Math.random().toString(36).slice(2, 8);
const ACTOR = { id: `admin-${RUN}`, username: `qa-admin-${RUN}` };
const TMP = mkdtempSync(join(tmpdir(), "ashrilogic-campaign-"));

beforeAll(async () => {
  process.env.ASHRILOGIC_STORAGE_DIR = TMP; /* spool artifacts into tmp */
  /* the object-store factory memoizes per process — a prior suite in the
   * same process (e.g. the provisioning-guard test's notifyEvent mail)
   * may have baked the DEFAULT storage root; reset so the spool follows TMP */
  __resetObjectStorageForTests();
  db = await getTestDb();
  service = await import("@/server/domains/campaigns/service");
  repo = await import("@/server/domains/campaigns/repository");
  const route = await import("@/lib/server/route");
  HttpError = route.HttpError;
});

afterAll(() => {
  rmSync(TMP, { recursive: true, force: true });
});

/* The dispatcher drives EVERY "sending" campaign in the database — the
 * suites below assert ABSOLUTE audience counts, so each test starts from
 * a clean campaign/subscriber/ledger state. */
beforeEach(async () => {
  if (!db) return;
  await db.emailLog.deleteMany({ where: { type: "campaign" } });
  await db.newsletterCampaign.deleteMany({});
  await db.subscriber.deleteMany({});
});

async function expectHttpError(promise: Promise<unknown>, status: number, message: string): Promise<void> {
  let caught: unknown;
  try {
    await promise;
  } catch (e) {
    caught = e;
  }
  expect(caught).toBeInstanceOf(HttpError);
  const err = caught as InstanceType<typeof HttpError>;
  expect(err.status).toBe(status);
  expect(err.message).toBe(message);
}

/** Seed one audience subscriber (sealed email, unique per run+index). */
async function seedSubscriber(index: number, email?: string): Promise<string> {
  const row = await db.subscriber.create({
    data: {
      email: encryptField(email ?? `sub-${RUN}-${index}@example.com`) ?? "",
      emailIndex: `idx-${RUN}-${index}`,
      status: index % 5 === 0 ? "restricted" : "active",
    },
    select: { id: true },
  });
  return row.id;
}

async function createDraft(subject: string): Promise<string> {
  const dto = await service.createDraft({ subject, body: `${subject} — body long enough for the schema.` }, ACTOR);
  expect(dto.status).toBe("draft");
  return dto.id;
}

describe("campaign durable dispatch — the claim", () => {
  test("draft → sending via CAS; the second claimer gets the historical 409; missing → 404", async () => {
    const id = await createDraft(`claim ${RUN}`);
    await seedSubscriber(1);
    await seedSubscriber(2);

    const claimed = await service.claimCampaign(id, ACTOR);
    expect(claimed.status).toBe("sending");
    expect(claimed.sentAt).toBeNull();
    expect(claimed.recipients).toBe(2); /* audience snapshot at claim */

    await expectHttpError(service.claimCampaign(id, ACTOR), 409, "CAMPAIGN_ALREADY_SENT");
    await expectHttpError(service.claimCampaign(`missing-${RUN}`, ACTOR), 404, "Campaign not found");
  });

  test("edit works on a draft; 409 on sending and sent; delete 409 on sending", async () => {
    const draftId = await createDraft(`edit ${RUN}`);
    const edited = await service.editDraft(draftId, { subject: `edited ${RUN}`, body: `${RUN} edited body long enough.` }, ACTOR);
    expect(edited.subject).toBe(`edited ${RUN}`);

    const sendingId = await createDraft(`sending-guard ${RUN}`);
    await service.claimCampaign(sendingId, ACTOR);
    await expectHttpError(
      service.editDraft(sendingId, { subject: "x".repeat(5), body: "y".repeat(12) }, ACTOR),
      409,
      "CAMPAIGN_ALREADY_SENT"
    );
    await expectHttpError(service.removeCampaign(sendingId, ACTOR), 409, "CAMPAIGN_DISPATCH_IN_PROGRESS");
  });
});

describe("campaign durable dispatch — enqueue, delivery, completion", () => {
  test("NO truncation: 7 subscribers at batch 2 → 7 unique per-recipient rows across sweeps", async () => {
    const id = await createDraft(`full-cycle ${RUN}`);
    const ids: string[] = [];
    for (let i = 0; i < 7; i += 1) ids.push(await seedSubscriber(i));
    await service.claimCampaign(id, ACTOR);

    /* sweeps with a TINY batch — the cursor does the rest across ticks */
    const opts = { enqueueBatch: 2, deliveryBatch: 3 };
    for (let tick = 0; tick < 12; tick += 1) {
      await service.sweepCampaignDispatch(opts);
      const row = await db.newsletterCampaign.findUnique({ where: { id } });
      if (row?.status === "sent") break;
    }

    const final = await db.newsletterCampaign.findUniqueOrThrow({ where: { id } });
    expect(final.status).toBe("sent");
    expect(final.sentAt).not.toBeNull();
    expect(final.recipients).toBe(7);
    expect(final.dispatchEnqueueDone).toBe(true);
    expect(final.dispatchEnqueued).toBe(7);

    /* the per-recipient ledger: 7 rows, ALL terminal, one per subscriber */
    const ledger = await db.emailLog.findMany({
      where: { type: "campaign", idempotencyKey: { startsWith: `campaign:${id}:` } },
    });
    expect(ledger.length).toBe(7);
    expect(ledger.every((r) => r.status === "sent")).toBe(true);
    expect(ledger.every((r) => r.bodyJson === null && r.messageId != null)).toBe(true);
    const keys = new Set(ledger.map((r) => r.idempotencyKey));
    expect(keys.size).toBe(7);
    for (const sid of ids) expect(keys.has(`campaign:${id}:${sid}`)).toBe(true);

    /* delivered count stamped on the campaign row */
    expect(final.delivered).toBe(7);
    expect(final.failed).toBe(0);

    /* both audit rows: the operator's send + the dispatcher's completion
     * (audits are awaited by the service — query by action + subject) */
    const subject = `full-cycle ${RUN}`.slice(0, 60);
    const actions = await db.auditLog.findMany({
      where: {
        action: { in: ["campaign.send", "campaign.dispatch-completed"] },
        targetLabel: subject,
      },
      select: { action: true, metaJson: true },
    });
    const sendRow = actions.find((a) => a.action === "campaign.send");
    const completeRow = actions.find((a) => a.action === "campaign.dispatch-completed");
    expect(sendRow).toBeTruthy();
    expect(completeRow).toBeTruthy();
    expect(completeRow?.metaJson).toContain("\"delivered\":\"7\"");

    /* spool artifacts: 7 .eml files hit the (tmp) object store */
    const outbox = readdirSync(join(TMP, "outbox")).filter((f) => f.endsWith(".eml"));
    expect(outbox.length).toBe(7);

    /* idempotent completion: another sweep on a completed campaign is a no-op */
    const outcomes = await service.sweepCampaignDispatch(opts);
    expect(outcomes.length).toBe(0); /* no "sending" campaigns left to drive */
  });

  test("crash-resume: re-running the enqueue phase never duplicates rows", async () => {
    const id = await createDraft(`resume ${RUN}`);
    for (let i = 0; i < 3; i += 1) await seedSubscriber(100 + i);
    await service.claimCampaign(id, ACTOR);

    /* one partial sweep (enqueue only happens for the first batch) */
    await service.sweepCampaignDispatch({ enqueueBatch: 1, deliveryBatch: 0 });
    const afterFirst = await db.emailLog.count({
      where: { type: "campaign", idempotencyKey: { startsWith: `campaign:${id}:` } },
    });
    expect(afterFirst).toBe(1);

    /* "crash" — drive the remaining phases repeatedly; unique keys arbitrate */
    for (let tick = 0; tick < 12; tick += 1) {
      await service.sweepCampaignDispatch({ enqueueBatch: 1, deliveryBatch: 2 });
      const row = await db.newsletterCampaign.findUnique({ where: { id } });
      if (row?.status === "sent") break;
    }
    const total = await db.emailLog.count({
      where: { type: "campaign", idempotencyKey: { startsWith: `campaign:${id}:` } },
    });
    expect(total).toBe(3); /* exactly one row per subscriber — no duplicates */
    const final = await db.newsletterCampaign.findUniqueOrThrow({ where: { id } });
    expect(final.status).toBe("sent");
  });

  test("invalid addresses are skipped (never silently truncated); exhausted rows dead-letter", async () => {
    const id = await createDraft(`edge ${RUN}`);
    await seedSubscriber(200, "not-an-email"); /* sealed garbage: decrypts, fails validation */
    const valid = await seedSubscriber(201, `valid-${RUN}@example.com`);
    await service.claimCampaign(id, ACTOR);

    for (let tick = 0; tick < 12; tick += 1) {
      await service.sweepCampaignDispatch({ enqueueBatch: 5, deliveryBatch: 5 });
      const row = await db.newsletterCampaign.findUnique({ where: { id } });
      if (row?.status === "sent") break;
    }
    const final = await db.newsletterCampaign.findUniqueOrThrow({ where: { id } });
    expect(final.status).toBe("sent");
    expect(final.recipients).toBe(2); /* audience snapshot counted both */
    expect(final.dispatchEnqueued).toBe(1); /* only the valid address was enqueued */
    expect(final.delivered).toBe(1);

    const ledger = await db.emailLog.findMany({
      where: { type: "campaign", idempotencyKey: { startsWith: `campaign:${id}:` } },
      select: { idempotencyKey: true },
    });
    expect(ledger.length).toBe(1);
    expect(ledger[0]?.idempotencyKey).toBe(`campaign:${id}:${valid}`);

    /* dead-letter: a pending row past the retry budget settles failed.
     * (fresh subscriber state — the audience is the WHOLE subscriber
     * table, so the earlier phase's subscribers are cleared first) */
    await db.subscriber.deleteMany({});
    const deadId = await createDraft(`dead ${RUN}`);
    await seedSubscriber(300, `dead-${RUN}@example.com`);
    await service.claimCampaign(deadId, ACTOR);
    await service.sweepCampaignDispatch({ enqueueBatch: 5, deliveryBatch: 0 }); /* enqueue only */
    const pending = await db.emailLog.findFirst({
      where: { type: "campaign", status: "pending", idempotencyKey: { startsWith: `campaign:${deadId}:` } },
      select: { id: true },
    });
    expect(pending).toBeTruthy();
    await db.emailLog.update({ where: { id: pending!.id }, data: { attempts: 5 } });
    await service.sweepCampaignDispatch({ enqueueBatch: 5, deliveryBatch: 5 });
    const deadRow = await db.emailLog.findUniqueOrThrow({ where: { id: pending!.id } });
    expect(deadRow.status).toBe("failed");
    expect(deadRow.error).toContain("dead-letter");
    const deadFinal = await db.newsletterCampaign.findUniqueOrThrow({ where: { id: deadId } });
    expect(deadFinal.status).toBe("sent"); /* completion is honest: all-terminal ≠ all-delivered */
    expect(deadFinal.failed).toBe(1);
    expect(deadFinal.delivered).toBe(0);
  });
});
