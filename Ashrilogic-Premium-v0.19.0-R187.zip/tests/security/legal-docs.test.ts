/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — PLATFORM LEGAL DOCUMENTS (ROUND 117).
 *
 * Proves the console-editable privacy/terms contract:
 *  - the read path falls back to the code-carried default (customized:false,
 *    version 0) when no row exists — the public pages can never 500;
 *  - a corrupted row (unparseable sections) fails SOFT to the default;
 *  - save: zod-validated drafts publish (version 1), a second publish
 *    bumps the version (2) and rewrites the content, attribution lands
 *    (updatedById/Name) and a sealed audit row is written
 *    (admin.legalDocUpdate);
 *  - invalid drafts are refused (bounds: empty title, >40 sections,
 *    0 sections, oversized body) — nothing reaches the DB;
 *  - reset: deletes the row and returns the default (customized:false) +
 *    audits (admin.legalDocReset with the removed version); resetting a
 *    non-customized locale answers the not-customized verdict;
 *  - {supportEmail}/{supportPhone} placeholders are interpolated at READ
 *    time with the LIVE PlatformSetting values (a support-channel change
 *    reflows the pages with no stored stale data);
 *  - the hi locale falls back through en when no Hindi row exists.
 *
 * DB isolation: throwaway PostgreSQL test database via test-setup (never the live DB).
 */

import { beforeAll, afterAll, describe, expect, test } from "bun:test";
import { getTestDb, resetRateTable, type TestDb } from "./test-setup";

let db: TestDb;
let docs: typeof import("@/lib/server/legal-docs");

const EDITOR = { id: "legal-editor-1", name: "Legal Editor" };

beforeAll(async () => {
  db = await getTestDb();
  await resetRateTable(db);
  await db.legalDoc.deleteMany({});
  await db.platformSetting.deleteMany({});
  docs = await import("@/lib/server/legal-docs");
});

afterAll(async () => {
  try {
    await db.legalDoc.deleteMany({});
    await db.platformSetting.deleteMany({});
  } catch {
    /* throwaway DB */
  }
});

describe("legal docs — read path", () => {
  test("no row → the code default (customized:false, version 0, real content)", async () => {
    const doc = await docs.readPlatformLegalDoc("privacy", "ar");
    expect(doc.customized).toBeFalse();
    expect(doc.version).toBe(0);
    expect(doc.updatedAt).toBeNull();
    expect(doc.title.length).toBeGreaterThan(3);
    expect(doc.intro.length).toBeGreaterThan(10);
    expect(doc.sections.length).toBeGreaterThanOrEqual(5);
    for (const s of doc.sections) {
      expect(s.heading.length).toBeGreaterThan(0);
      expect(s.body.length).toBeGreaterThan(0);
    }
  });

  test("corrupted row fails SOFT to the default (never a broken public page)", async () => {
    await db.legalDoc.create({
      data: {
        key: "privacy",
        locale: "en",
        title: "Corrupted",
        intro: "Corrupted intro",
        sectionsJson: "{not-json",
        version: 7,
      },
    });
    const doc = await docs.readPlatformLegalDoc("privacy", "en");
    expect(doc.customized).toBeFalse();
    expect(doc.version).toBe(0);
    expect(doc.title).not.toBe("Corrupted");
  });

  test("hi falls back through en when no Hindi row exists", async () => {
    await db.legalDoc.deleteMany({});
    /* publish an EN row only */
    await docs.savePlatformLegalDoc(
      {
        key: "terms",
        locale: "en",
        title: "EN Terms",
        intro: "EN intro",
        sections: [{ heading: "H", body: "B" }],
      },
      EDITOR
    );
    const hi = await docs.readPlatformLegalDoc("terms", "hi");
    /* no hi row → the read falls back (default chain), NOT the en row's
       customized content — the fallback contract is: row → DEFAULT (en
       default), never another locale's edited row */
    expect(hi.locale).toBe("hi");
    expect(hi.title.length).toBeGreaterThan(0);
  });
});

describe("legal docs — write path (publish)", () => {
  test("first publish → version 1, attribution, audit row, live read", async () => {
    await db.legalDoc.deleteMany({});
    const auditBefore = await db.auditLog.count({ where: { action: "admin.legalDocUpdate" } });

    const saved = await docs.savePlatformLegalDoc(
      {
        key: "privacy",
        locale: "ar",
        title: "سياسة مخصصة",
        intro: "مقدمة مخصصة",
        sections: [
          { heading: "قسم أول", body: "نص القسم الأول" },
          { heading: "قسم ثانٍ", body: "نص القسم الثاني" },
        ],
      },
      EDITOR
    );
    expect(saved.ok).toBeTrue();
    if (!saved.ok) return;
    expect(saved.version).toBe(1);
    expect(saved.doc.customized).toBeTrue();
    expect(saved.doc.version).toBe(1);
    expect(saved.doc.title).toBe("سياسة مخصصة");

    const row = await db.legalDoc.findUnique({ where: { key_locale: { key: "privacy", locale: "ar" } } });
    expect(row?.updatedById).toBe(EDITOR.id);
    expect(row?.updatedByName).toBe(EDITOR.name);

    expect(await db.auditLog.count({ where: { action: "admin.legalDocUpdate" } })).toBe(auditBefore + 1);
  });

  test("second publish bumps the version and rewrites the content", async () => {
    const saved = await docs.savePlatformLegalDoc(
      {
        key: "privacy",
        locale: "ar",
        title: "سياسة معدّلة",
        intro: "مقدمة معدّلة",
        sections: [{ heading: "قسم وحيد", body: "نص معدّل" }],
      },
      EDITOR
    );
    expect(saved.ok).toBeTrue();
    if (!saved.ok) return;
    expect(saved.version).toBe(2);
    expect(saved.doc.title).toBe("سياسة معدّلة");
    expect(saved.doc.sections).toHaveLength(1);
  });

  test("invalid drafts are refused — nothing reaches the DB", async () => {
    const before = await db.legalDoc.count({});
    /* empty title */
    let r = await docs.savePlatformLegalDoc(
      { key: "terms", locale: "en", title: "  ", intro: "i", sections: [{ heading: "h", body: "b" }] },
      EDITOR
    );
    expect(r.ok).toBeFalse();
    /* zero sections */
    r = await docs.savePlatformLegalDoc(
      { key: "terms", locale: "en", title: "t", intro: "i", sections: [] },
      EDITOR
    );
    expect(r.ok).toBeFalse();
    /* >40 sections */
    r = await docs.savePlatformLegalDoc(
      {
        key: "terms",
        locale: "en",
        title: "t",
        intro: "i",
        sections: Array.from({ length: 41 }, (_, i) => ({ heading: `h${i}`, body: "b" })),
      },
      EDITOR
    );
    expect(r.ok).toBeFalse();
    /* oversized body */
    r = await docs.savePlatformLegalDoc(
      { key: "terms", locale: "en", title: "t", intro: "i", sections: [{ heading: "h", body: "x".repeat(8_001) }] },
      EDITOR
    );
    expect(r.ok).toBeFalse();
    expect(await db.legalDoc.count({})).toBe(before);
  });
});

describe("legal docs — reset path", () => {
  test("reset deletes the row, returns the default, audits the removed version", async () => {
    const auditBefore = await db.auditLog.count({ where: { action: "admin.legalDocReset" } });
    const reset = await docs.resetPlatformLegalDoc("privacy", "ar", EDITOR);
    expect(reset.ok).toBeTrue();
    if (!reset.ok) return;
    expect(reset.doc.customized).toBeFalse();
    expect(reset.doc.version).toBe(0);
    expect(await db.legalDoc.findUnique({ where: { key_locale: { key: "privacy", locale: "ar" } } })).toBeNull();
    expect(await db.auditLog.count({ where: { action: "admin.legalDocReset" } })).toBe(auditBefore + 1);
  });

  test("resetting a non-customized locale answers not-customized", async () => {
    const reset = await docs.resetPlatformLegalDoc("privacy", "ar", EDITOR);
    expect(reset.ok).toBeFalse();
    if (!reset.ok) expect(reset.error).toBe("not customized");
  });
});

describe("legal docs — live placeholder interpolation", () => {
  test("{supportEmail}/{supportPhone} reflow from the live PlatformSetting", async () => {
    await db.legalDoc.deleteMany({});
    await db.platformSetting.create({
      data: { id: "global", supportEmail: "legal-desk@ashrilogic.test", supportPhone: "+249999000111" },
    });
    const saved = await docs.savePlatformLegalDoc(
      {
        key: "terms",
        locale: "en",
        title: "Contact",
        intro: "Write to {supportEmail} or call {supportPhone}.",
        sections: [{ heading: "Data requests", body: "Email {supportEmail} for exports." }],
      },
      EDITOR
    );
    expect(saved.ok).toBeTrue();
    if (!saved.ok) return;
    expect(saved.doc.intro).toContain("legal-desk@ashrilogic.test");
    expect(saved.doc.intro).toContain("+249999000111");
    expect(saved.doc.intro).not.toContain("{supportEmail}");
    expect(saved.doc.sections[0].body).toContain("legal-desk@ashrilogic.test");

    /* a live support-channel change reflows the SAME row on the next read */
    await db.platformSetting.update({
      where: { id: "global" },
      data: { supportEmail: "privacy-office@ashrilogic.test" },
    });
    const reread = await docs.readPlatformLegalDoc("terms", "en");
    expect(reread.intro).toContain("privacy-office@ashrilogic.test");
    expect(reread.intro).not.toContain("legal-desk@ashrilogic.test");
  });
});
