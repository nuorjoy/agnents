/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 124: the packages domain service +
 * repository (src/server/domains/packages) — the pilot of the
 * route→controller→service→repository decomposition.
 *
 * The value of the decomposition is exactly this suite: the business
 * rules (single-popular-plan swap, default seeding, 404 policy, audit
 * attribution with the LEGACY meta shapes) are now provable against a
 * throwaway database with NO server, NO HTTP, NO session machinery —
 * while the byte-level HTTP compatibility of the migrated routes is
 * proven separately (packages-routes.test.ts, live).
 */
import { describe, test, expect, beforeAll, afterAll } from "bun:test";
import { getTestDb, type TestDb } from "./test-setup";

let db: TestDb;
let service: typeof import("@/server/domains/packages/service");
let repository: typeof import("@/server/domains/packages/repository");
let HttpError: typeof import("@/lib/server/route").HttpError;

const ACTOR = { id: "test-actor-r124", username: "qa-r124" };
const RUN = Math.random().toString(36).slice(2, 8);

function validPayload(suffix: string, overrides: Record<string, unknown> = {}) {
  return {
    nameAr: `باقة اختبار ${suffix}`,
    nameEn: `QA Plan ${suffix}`,
    descAr: "وصف اختبار لباقة",
    descEn: "QA test plan description",
    priceMonthly: 199,
    priceYearly: 1990,
    currency: "SAR",
    features: ["ميزة أولى", "ميزة ثانية", "ميزة ثالثة"],
    featuresEn: ["First feature", "Second feature", "Third feature"],
    maxUsers: 10,
    maxModules: 20,
    maxStorageMb: 1024,
    /* ROUND 167 — the new quota family columns ride the payload too */
    maxSystems: 2,
    customPricing: false,
    discountPct: 0,
    yearlyDiscountPct: 0,
    capabilities: ["publicWebsite", "store"],
    popular: false,
    active: true,
    sortOrder: 50,
    ...overrides,
  };
}

const created: string[] = [];

/** Assert a promise rejects with the EXACT legacy 404 domain error. */
async function expectLegacy404(promise: Promise<unknown>): Promise<void> {
  let caught: unknown;
  try {
    await promise;
  } catch (e) {
    caught = e;
  }
  expect(caught).toBeInstanceOf(HttpError);
  const err = caught as InstanceType<typeof HttpError>;
  expect(err.status).toBe(404);
  expect(err.message).toBe("Package not found");
}

beforeAll(async () => {
  db = await getTestDb();
  service = await import("@/server/domains/packages/service");
  repository = await import("@/server/domains/packages/repository");
  ({ HttpError } = await import("@/lib/server/route"));
});

afterAll(async () => {
  /* the throwaway db is recreated per run — explicit cleanup anyway so a
   * future reuse of the file never inherits this suite's rows */
  if (created.length > 0) {
    await db.package.deleteMany({ where: { id: { in: created } } }).catch(() => undefined);
  }
});

describe("ROUND 124 — packages service (unit, throwaway db)", () => {
  test("listAdmin seeds the default trio on an empty table (idempotent self-heal)", async () => {
    const rows = await service.listAdmin();
    expect(rows.length).toBeGreaterThanOrEqual(3);
    const names = rows.map((r) => r.nameEn);
    expect(names).toContain("Starter");
    expect(names).toContain("Professional");
  });

  test("listPublic returns ONLY active plans (inactive ones are excluded)", async () => {
    const hidden = await service.create(validPayload(`${RUN}-hidden`, { active: false }), ACTOR);
    created.push(hidden.id);
    const pub = await service.listPublic();
    expect(pub.length).toBeGreaterThan(0);
    expect(pub.every((r) => r.active)).toBe(true);
    expect(pub.some((r) => r.id === hidden.id)).toBe(false);
    const admin = await service.listAdmin();
    expect(admin.some((r) => r.id === hidden.id)).toBe(true);
    expect(admin.length).toBeGreaterThanOrEqual(pub.length);
  });

  test("create: the row lands with JSON columns encoded; audit meta reads the CREATED row", async () => {
    const row = await service.create(validPayload(RUN), ACTOR);
    created.push(row.id);
    expect(row.nameEn).toBe(`QA Plan ${RUN}`);
    expect(JSON.parse(row.featuresJson)).toEqual(["ميزة أولى", "ميزة ثانية", "ميزة ثالثة"]);
    expect(JSON.parse(row.capabilitiesJson ?? "[]")).toEqual(["publicWebsite", "store"]);

    const audit = await db.auditLog.findFirst({
      where: { action: "package.create", actorId: ACTOR.id, targetLabel: row.nameEn },
      orderBy: { createdAt: "desc" },
    });
    expect(audit).toBeTruthy();
    const meta = audit && audit.metaJson ? (JSON.parse(audit.metaJson) as Record<string, string>) : {};
    expect(meta.priceMonthly).toBe("199");
  });

  test("create popular:true swaps the flag off every other plan (single featured plan)", async () => {
    const first = await service.create(validPayload(`${RUN}-a`, { popular: true }), ACTOR);
    created.push(first.id);
    const second = await service.create(validPayload(`${RUN}-b`, { popular: true }), ACTOR);
    created.push(second.id);

    const afterFirst = await repository.findById(first.id);
    const afterSecond = await repository.findById(second.id);
    expect(afterFirst?.popular).toBe(false);
    expect(afterSecond?.popular).toBe(true);
    /* exactly ONE popular plan across the whole catalog */
    const popularCount = await db.package.count({ where: { popular: true } });
    expect(popularCount).toBe(1);
  });

  test("update: unknown id → the exact legacy 404 envelope", async () => {
    await expectLegacy404(service.update("nonexistent-id", { priceMonthly: 5 }, ACTOR));
  });

  test("update: partial patch touches ONLY the present fields", async () => {
    const row = await service.create(validPayload(`${RUN}-c`), ACTOR);
    created.push(row.id);
    const updated = await service.update(row.id, { priceMonthly: 249, discountPct: 10 }, ACTOR);
    expect(updated.priceMonthly).toBe(249);
    expect(updated.discountPct).toBe(10);
    /* untouched fields survive the partial patch */
    expect(updated.nameEn).toBe(`QA Plan ${RUN}-c`);
    expect(JSON.parse(updated.featuresJson)).toHaveLength(3);

    const audit = await db.auditLog.findFirst({
      where: { action: "package.update", actorId: ACTOR.id, targetLabel: updated.nameEn },
      orderBy: { createdAt: "desc" },
    });
    expect(audit).toBeTruthy();
    const meta = audit && audit.metaJson ? (JSON.parse(audit.metaJson) as Record<string, string>) : {};
    /* the legacy asymmetry: update meta reads the INPUT patch */
    expect(meta.priceMonthly).toBe("249");
    expect(meta.discountPct).toBe("10");
    expect(meta.active).toBeUndefined();
  });

  test("update popular:true clears the flag from every OTHER plan (transactional swap)", async () => {
    const a = await service.create(validPayload(`${RUN}-d`, { popular: true }), ACTOR);
    created.push(a.id);
    const b = await service.create(validPayload(`${RUN}-e`), ACTOR);
    created.push(b.id);

    const updated = await service.update(b.id, { popular: true }, ACTOR);
    expect(updated.popular).toBe(true);
    const aRow = await repository.findById(a.id);
    expect(aRow?.popular).toBe(false);
    expect(await db.package.count({ where: { popular: true } })).toBe(1);
  });

  test("remove: unknown id → 404; existing id → row gone + audit labeled", async () => {
    await expectLegacy404(service.remove("nonexistent-id", ACTOR));

    const row = await service.create(validPayload(`${RUN}-f`), ACTOR);
    await service.remove(row.id, ACTOR);
    const gone = await repository.findById(row.id);
    expect(gone).toBeNull();

    const audit = await db.auditLog.findFirst({
      where: { action: "package.delete", actorId: ACTOR.id, targetLabel: row.nameEn },
      orderBy: { createdAt: "desc" },
    });
    expect(audit).toBeTruthy();
  });
});

describe("ROUND 124 — packages repository (unit, throwaway db)", () => {
  test("listAll is ordered by sortOrder, then createdAt, then id", async () => {
    const rows = await repository.listAll();
    expect(rows.length).toBeGreaterThan(1);
    for (let i = 1; i < rows.length; i++) {
      const prev = rows[i - 1];
      const cur = rows[i];
      const orderOk =
        prev.sortOrder < cur.sortOrder ||
        (prev.sortOrder === cur.sortOrder &&
          (prev.createdAt.getTime() < cur.createdAt.getTime() ||
            (prev.createdAt.getTime() === cur.createdAt.getTime() && prev.id < cur.id)));
      expect(orderOk).toBe(true);
    }
  });

  test("findBriefById returns exactly the delete-audit projection", async () => {
    const row = await service.create(validPayload(`${RUN}-g`), ACTOR);
    created.push(row.id);
    const brief = await repository.findBriefById(row.id);
    expect(brief).toEqual({ id: row.id, nameEn: row.nameEn });
  });
});
