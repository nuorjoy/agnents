/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — featured & sale pricing on module records (ROUND 52).
 *
 * Pins under test:
 *  - the `featured`/`salePrice` write fields accept only their exact shapes
 *    (boolean / positive-integer-minor-units-or-null) — floats, negatives,
 *    zero, overflow, strings and arrays are refused by zod (422 before any
 *    handler runs);
 *  - toSiteProduct derives the sale price STRICTLY below the regular price
 *    (a stale/equal/zero sale degrades to "no sale" — merchant data can never
 *    raise a price or free an item through the sale column);
 *  - effectivePriceMinor mirrors the same verdict for order placement (what
 *    the storefront shows is what the guest is charged);
 *  - featured rows sort FIRST and the sort is stable.
 */
import { describe, test, expect } from "bun:test";
import type { ModuleRecord } from "@prisma/client";
import {
  moduleRecordUpdateSchema,
} from "@/lib/server/module-record-mapper";
import {
  toSiteProduct,
  effectivePriceMinor,
} from "@/lib/server/store-mapper";

function fakeRecord(overrides: Partial<ModuleRecord> = {}): ModuleRecord {
  /* inventory column layout: { name:0, category:2, stock:3, price:4 } */
  return {
    id: "r1",
    instanceId: "i1",
    moduleId: "inventory",
    dataJson: JSON.stringify(["جهاز قياس", "", "أجهزة", "12", "450.00"]),
    statusKey: "",
    imageRef: null,
    featured: false,
    salePrice: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    ...overrides,
  } as ModuleRecord;
}

describe("featured & sale — write schema shapes", () => {
  test("featured accepts true/false", () => {
    expect(moduleRecordUpdateSchema.safeParse({ featured: true }).success).toBe(true);
    expect(moduleRecordUpdateSchema.safeParse({ featured: false }).success).toBe(true);
  });

  test("salePrice accepts positive integers and null (minor units)", () => {
    expect(moduleRecordUpdateSchema.safeParse({ salePrice: 39900 }).success).toBe(true);
    expect(moduleRecordUpdateSchema.safeParse({ salePrice: null }).success).toBe(true);
  });

  test("salePrice rejects zero, negatives, floats, overflow, strings", () => {
    expect(moduleRecordUpdateSchema.safeParse({ salePrice: 0 }).success).toBe(false);
    expect(moduleRecordUpdateSchema.safeParse({ salePrice: -100 }).success).toBe(false);
    expect(moduleRecordUpdateSchema.safeParse({ salePrice: 39.5 }).success).toBe(false);
    expect(moduleRecordUpdateSchema.safeParse({ salePrice: 3_000_000_000 }).success).toBe(false);
    expect(moduleRecordUpdateSchema.safeParse({ salePrice: "39900" }).success).toBe(false);
  });

  test("featured rejects non-booleans", () => {
    expect(moduleRecordUpdateSchema.safeParse({ featured: "yes" }).success).toBe(false);
    expect(moduleRecordUpdateSchema.safeParse({ featured: 1 }).success).toBe(false);
    expect(moduleRecordUpdateSchema.safeParse({ featured: null }).success).toBe(false);
  });

  test("merch-only PATCH satisfies the at-least-one-field refine", () => {
    expect(moduleRecordUpdateSchema.safeParse({ featured: true }).success).toBe(true);
    expect(moduleRecordUpdateSchema.safeParse({ salePrice: 100 }).success).toBe(true);
  });
});

describe("toSiteProduct — sale derivation (defensive)", () => {
  test("a valid sale (below the regular price) surfaces in display units", () => {
    const p = toSiteProduct("inventory", fakeRecord({ salePrice: 35000 }));
    expect(p.salePrice).toBe(350);
    expect(p.price).toBe(450);
    expect(p.featured).toBe(false);
  });

  test("featured flag surfaces", () => {
    const p = toSiteProduct("inventory", fakeRecord({ featured: true }));
    expect(p.featured).toBe(true);
  });

  test("a sale EQUAL to the regular price degrades to no sale", () => {
    const p = toSiteProduct("inventory", fakeRecord({ salePrice: 45000 }));
    expect(p.salePrice).toBeNull();
  });

  test("a sale ABOVE the regular price degrades to no sale", () => {
    const p = toSiteProduct("inventory", fakeRecord({ salePrice: 50000 }));
    expect(p.salePrice).toBeNull();
  });

  test("zero and negative sale values degrade to no sale", () => {
    expect(toSiteProduct("inventory", fakeRecord({ salePrice: 0 })).salePrice).toBeNull();
    expect(toSiteProduct("inventory", fakeRecord({ salePrice: -100 })).salePrice).toBeNull();
  });

  test("null sale stays null", () => {
    expect(toSiteProduct("inventory", fakeRecord({ salePrice: null })).salePrice).toBeNull();
  });
});

describe("effectivePriceMinor — the charged price (placement mirror)", () => {
  test("a valid sale is the charged price (minor units)", () => {
    expect(effectivePriceMinor(fakeRecord({ salePrice: 35000 }), "inventory")).toBe(35000);
  });

  test("no sale charges the regular price parsed from the money cell", () => {
    expect(effectivePriceMinor(fakeRecord(), "inventory")).toBe(45000);
  });

  test("an invalid sale (equal/above/zero) falls back to the regular price", () => {
    expect(effectivePriceMinor(fakeRecord({ salePrice: 45000 }), "inventory")).toBe(45000);
    expect(effectivePriceMinor(fakeRecord({ salePrice: 60000 }), "inventory")).toBe(45000);
    expect(effectivePriceMinor(fakeRecord({ salePrice: 0 }), "inventory")).toBe(45000);
  });

  test("the display verdict and the charge verdict AGREE (no drift window)", () => {
    for (const sale of [1, 100, 44999, 45000, 45001]) {
      const shown = toSiteProduct("inventory", fakeRecord({ salePrice: sale }));
      const charged = effectivePriceMinor(fakeRecord({ salePrice: sale }), "inventory");
      const shownEffective = shown.salePrice != null ? Math.round(shown.salePrice * 100) : charged;
      expect(shownEffective).toBe(charged);
    }
  });
});
