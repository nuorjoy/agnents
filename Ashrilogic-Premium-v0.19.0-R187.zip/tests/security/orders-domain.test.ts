/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 128: the orders domain
 * (src/server/domains/orders — the fourth route decomposition, after
 * packages/plan-orders/store).
 *
 * The guest-checkout surface (order placement + tracking) is the biggest
 * business-critical public mutation, so its CONTRACT gets both levels:
 *
 *  1. CONTROLLER level (in-process, the REAL exported handlers invoked
 *     with synthetic Requests): every guard stage's EXACT envelope —
 *     the origin 403, the body-stage 400s (the legacy custom strings),
 *     the maintenance-window 503, the 429 with its Retry-After /
 *     X-RateLimit headers, and the afterBody positioning proof (invalid
 *     bodies never burn throttle hits). The idempotency replay is proven
 *     end-to-end through the raw-response passthrough (200 +
 *     `idempotency-replayed: true`, byte-identical stored DTO; key reuse
 *     with a different payload → 422 KEY_REUSED).
 *  2. SERVICE level: the placement business rules — find-or-create guest
 *     contacts, the banned-contact 403, the merged-line quantity ceiling,
 *     ITEM_GONE / STOCK 409s, the store-stop 404s (unpublished / locked
 *     trial / trashed workspace), coupon application + the silent
 *     downgrade of an exhausted code, the stock CAS decrement + the
 *     ROUND-120 ledgers (OrderReservation / CouponRedemption), and the
 *     tracking contract (code + phone blind index, no existence oracle).
 *
 * next/headers is MOCKED at the module boundary (an empty cookie store —
 * the GUEST flow; the signed-in shopper path is proven live by the
 * tenant-isolation customer-account slices, which drive the real cookie
 * scope through the running server).
 */
import { describe, test, expect, beforeAll, afterAll, mock } from "bun:test";
import { getTestDb, type TestDb, ensureDemoEnv } from "./test-setup";

ensureDemoEnv();

/* Mock BEFORE any dynamic import of the domain (customer-session reads
 * cookies through next/headers; an empty store = the guest flow). */
mock.module("next/headers", () => ({
  cookies: async () => ({
    get: () => undefined,
    set: () => undefined,
    delete: () => undefined,
  }),
  headers: async () => ({ get: () => undefined }),
  draftMode: async () => ({ isEnabled: () => false }),
}));

let db: TestDb;
let controller: typeof import("@/server/domains/orders/controller");
let service: typeof import("@/server/domains/orders/service");
let HttpError: typeof import("@/lib/server/route").HttpError;

const HOST = "localhost:3000";
const RUN = Math.random().toString(36).slice(2, 8);
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/* fixture ids */
let A = ""; /* live trial, published, products + coupons + banned contact */
let B = ""; /* locked trial (store stopped) */
let M = ""; /* maintenance window (restore lease in flight) */
let E = ""; /* trashed workspace */
let p1 = ""; /* stock 10 @ 25.00 */
let p2 = ""; /* stock 5 @ 40.00 */
let LIVE_CODE = "";
let EXH_CODE = "";
const GUEST_EMAIL = `guest-${RUN}@example.com`;
const BANNED_EMAIL = `banned-${RUN}@example.com`;
const PHONE = "0551234567";

/* per-group throttle isolation (the key embeds the XFF-derived IP) */
const IP_CTRL = "203.0.113.10";
const IP_THROTTLE = "203.0.113.11";
const IP_IDEM = "203.0.113.12";

beforeAll(async () => {
  db = await getTestDb();
  controller = await import("@/server/domains/orders/controller");
  service = await import("@/server/domains/orders/service");
  ({ HttpError } = await import("@/lib/server/route"));

  const instanceData = (modules: string[], extra: Record<string, unknown> = {}) => ({
    systemId: "pharmacy-management",
    orgJson: JSON.stringify({ name: `صيدلية ${RUN}`, country: "SA", currency: "SAR" }),
    adminJson: JSON.stringify({ name: "مالك", email: `owner-${RUN}@example.com`, role: "owner" }),
    prefsJson: JSON.stringify({ lang: "ar", theme: "light", notif: true, backup: true, audit: true, demo: false }),
    modulesJson: JSON.stringify(modules),
    trialEndsAt: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
    ...extra,
  });

  /* A — the live happy-path store */
  const a = await db.instance.create({ data: instanceData(["pharmacy"]) });
  A = a.id;
  await db.site.create({ data: { instanceId: A, published: true } });
  const r1 = await db.moduleRecord.create({
    data: { instanceId: A, moduleId: "pharmacy", dataJson: JSON.stringify(["بنادول", "مسكنات", "", "", "50", "25.00"]) },
  });
  const r2 = await db.moduleRecord.create({
    data: { instanceId: A, moduleId: "pharmacy", dataJson: JSON.stringify(["فيتامين ج", "مكملات", "", "", "5", "40.00"]) },
  });
  p1 = r1.id;
  p2 = r2.id;
  LIVE_CODE = `LIVE${RUN.slice(0, 4).toUpperCase()}`;
  EXH_CODE = `EXH${RUN.slice(0, 4).toUpperCase()}`;
  await db.storeCoupon.create({
    data: { instanceId: A, code: LIVE_CODE, kind: "percent", value: 10, active: true },
  });
  await db.storeCoupon.create({
    data: { instanceId: A, code: EXH_CODE, kind: "percent", value: 10, active: true, maxUses: 1, usedCount: 1 },
  });
  /* a banned contact — the owner's ban survives the guest flow */
  await db.siteCustomer.create({
    data: { instanceId: A, name: "محظور", email: "", emailIndex: null, passwordHash: null, status: "banned" },
  });
  /* the banned row is findable by email index (the blind index of the
   * normalized email) — pre-compute it the way resolveGuestCustomer does */
  const { blindIndex } = await import("@/lib/server/crypto-vault");
  const bannedIdx = blindIndex(BANNED_EMAIL);
  if (bannedIdx) {
    await db.siteCustomer.update({
      where: { id: (await db.siteCustomer.findFirst({ where: { instanceId: A, status: "banned" } }))!.id },
      data: { emailIndex: bannedIdx },
    });
  }

  /* B — locked trial (store stopped) */
  const b = await db.instance.create({
    data: instanceData(["pharmacy"], { trialEndsAt: new Date(Date.now() - 24 * 60 * 60 * 1000) }),
  });
  B = b.id;
  await db.site.create({ data: { instanceId: B, published: true } });

  /* M — live store under an in-flight restore lease */
  const m = await db.instance.create({ data: instanceData(["pharmacy"]) });
  M = m.id;
  await db.site.create({ data: { instanceId: M, published: true } });
  await db.restoreLease.create({
    data: { instanceId: M, holder: `test-${RUN}`, acquiredAt: new Date(), expiresAt: new Date(Date.now() + 10 * 60 * 1000) },
  });

  /* E — trashed workspace (accepts no orders) */
  const e = await db.instance.create({
    data: instanceData(["pharmacy"], { deletedAt: new Date() }),
  });
  E = e.id;
  await db.site.create({ data: { instanceId: E, published: true } });
});

afterAll(async () => {
  for (const id of [A, B, M, E]) {
    if (!id) continue;
    await db.couponRedemption.deleteMany({ where: { instanceId: id } }).catch(() => undefined);
    await db.orderReservation.deleteMany({ where: { instanceId: id } }).catch(() => undefined);
    await db.siteOrder.deleteMany({ where: { instanceId: id } }).catch(() => undefined);
    await db.orderIdempotency.deleteMany({ where: { instanceId: id } }).catch(() => undefined);
    await db.storeCoupon.deleteMany({ where: { instanceId: id } }).catch(() => undefined);
    await db.siteCustomer.deleteMany({ where: { instanceId: id } }).catch(() => undefined);
    await db.moduleRecord.deleteMany({ where: { instanceId: id } }).catch(() => undefined);
    await db.site.deleteMany({ where: { instanceId: id } }).catch(() => undefined);
    await db.restoreLease.deleteMany({ where: { instanceId: id } }).catch(() => undefined);
    await db.instance.deleteMany({ where: { id } }).catch(() => undefined);
  }
});

/* ----------------------------- helpers ------------------------------- */

function placePost(
  siteId: string,
  payload: unknown,
  headers: Record<string, string> = {}
): Request {
  return new Request(`http://${HOST}/api/sites/${siteId}/orders`, {
    method: "POST",
    body: typeof payload === "string" ? payload : JSON.stringify(payload),
    headers: { "content-type": "application/json", host: HOST, ...headers },
  });
}

function trackPost(siteId: string, payload: unknown, headers: Record<string, string> = {}): Request {
  return new Request(`http://${HOST}/api/sites/${siteId}/orders/track`, {
    method: "POST",
    body: JSON.stringify(payload),
    headers: { "content-type": "application/json", host: HOST, ...headers },
  });
}

const segment = (id: string) => ({ params: Promise.resolve({ id }) });
const sameOrigin = { origin: `http://${HOST}` };
const crossOrigin = { origin: "http://evil.example" };
const withIp = (ip: string) => ({ "x-forwarded-for": ip });

const validPayload = (recordId: string, qty = 1, extra: Record<string, unknown> = {}) => ({
  items: [{ recordId, qty }],
  customer: { name: "زائر اختبار", phone: PHONE, email: GUEST_EMAIL },
  ...extra,
});

/** Assert a promise rejects with the EXACT legacy HttpError shape. */
async function expectHttpError(
  promise: Promise<unknown>,
  status: number,
  message: string,
  code?: string
): Promise<void> {
  let caught: unknown;
  try {
    await promise;
  } catch (e) {
    caught = e;
  }
  expect(caught).toBeInstanceOf(HttpError);
  const err = caught as InstanceType<typeof HttpError>;
  expect(err.status).toBe(status);
  expect(err.message).toBe(message);
  expect(err.code).toBe(code);
}

/* ----------------- CONTROLLER — the guard envelopes ------------------ */

describe("ROUND 128 — orders controller: origin stage (byte-compatible 403)", () => {
  test("placement: cross-origin POST → 403 'Cross-origin request rejected' + x-request-id", async () => {
    const res = await controller.orderPlace(
      placePost(A, validPayload(p1), crossOrigin),
      segment(A)
    );
    expect(res.status).toBe(403);
    expect(((await res.json()) as { error?: string }).error).toBe("Cross-origin request rejected");
    expect(res.headers.get("x-request-id")).toMatch(UUID_RE);
  });

  test("track: cross-origin POST → the same 403 envelope", async () => {
    const res = await controller.orderTrack(
      trackPost(A, { code: "ABCDEFG", phone: PHONE }, crossOrigin),
      segment(A)
    );
    expect(res.status).toBe(403);
    expect(((await res.json()) as { error?: string }).error).toBe("Cross-origin request rejected");
  });
});

describe("ROUND 128 — orders controller: body stage (the legacy 400 envelopes)", () => {
  test("placement: empty body → 400 'Request body is required'", async () => {
    const res = await controller.orderPlace(placePost(A, "", sameOrigin), segment(A));
    expect(res.status).toBe(400);
    expect(((await res.json()) as { error?: string }).error).toBe("Request body is required");
  });

  test("placement: malformed JSON → 400 'Invalid JSON body'", async () => {
    const res = await controller.orderPlace(placePost(A, "{nope", sameOrigin), segment(A));
    expect(res.status).toBe(400);
    expect(((await res.json()) as { error?: string }).error).toBe("Invalid JSON body");
  });

  test("placement: schema mismatch → the legacy custom 400 (never zodError)", async () => {
    const res = await controller.orderPlace(
      placePost(A, { items: [], customer: { name: "x" } }, sameOrigin),
      segment(A)
    );
    expect(res.status).toBe(400);
    expect(((await res.json()) as { error?: string }).error).toBe(
      "Order must hold 1–20 items with quantities 1–99 and guest contact details"
    );
  });

  test("track: schema mismatch → the legacy custom 400", async () => {
    const res = await controller.orderTrack(
      trackPost(A, { code: "AB" }, sameOrigin),
      segment(A)
    );
    expect(res.status).toBe(400);
    expect(((await res.json()) as { error?: string }).error).toBe(
      "Enter your tracking code and the phone number you ordered with"
    );
  });
});

describe("ROUND 128 — orders controller: maintenance stage (the ROUND-96 window)", () => {
  test("placement on a mid-restore workspace → 503 MAINTENANCE + Retry-After 30 (even with a valid body)", async () => {
    const res = await controller.orderPlace(
      placePost(M, validPayload(p1), sameOrigin),
      segment(M)
    );
    expect(res.status).toBe(503);
    const body = (await res.json()) as { error?: string; code?: string };
    expect(body.code).toBe("MAINTENANCE");
    expect(body.error).toContain("being restored from a backup");
    expect(res.headers.get("Retry-After")).toBe("30");
  });
});

describe("ROUND 128 — orders controller: throttle stage (afterBody semantics)", () => {
  test("INVALID bodies never burn placement hits — 12 rejects, then the 13th VALID request still places", async () => {
    /* a dedicated live store for this group (stock is consumed by the
     * final valid placement) */
    const site = await db.instance.create({
      data: {
        systemId: "pharmacy-management",
        orgJson: JSON.stringify({ name: `ت ${RUN}`, currency: "SAR" }),
        adminJson: "{}",
        prefsJson: "{}",
        modulesJson: JSON.stringify(["pharmacy"]),
        trialEndsAt: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
      },
    });
    await db.site.create({ data: { instanceId: site.id, published: true } });
    const rec = await db.moduleRecord.create({
      data: { instanceId: site.id, moduleId: "pharmacy", dataJson: JSON.stringify(["دواء", "عام", "", "", "50", "10.00"]) },
    });
    try {
      for (let i = 0; i < 12; i++) {
        const res = await controller.orderPlace(
          placePost(site.id, { items: [], customer: { name: "x" } }, { ...sameOrigin, ...withIp(IP_CTRL) }),
          segment(site.id)
        );
        expect(res.status).toBe(400); /* never a 429 — the hit was not burned */
      }
      const ok = await controller.orderPlace(
        placePost(site.id, validPayload(rec.id), { ...sameOrigin, ...withIp(IP_CTRL) }),
        segment(site.id)
      );
      expect(ok.status).toBe(201); /* still inside the 10/10min window */
    } finally {
      await db.orderReservation.deleteMany({ where: { instanceId: site.id } }).catch(() => undefined);
      await db.siteOrder.deleteMany({ where: { instanceId: site.id } }).catch(() => undefined);
      await db.siteCustomer.deleteMany({ where: { instanceId: site.id } }).catch(() => undefined);
      await db.moduleRecord.deleteMany({ where: { instanceId: site.id } }).catch(() => undefined);
      await db.site.deleteMany({ where: { instanceId: site.id } }).catch(() => undefined);
      await db.instance.deleteMany({ where: { id: site.id } }).catch(() => undefined);
    }
  });

  test("over the 10-orders window → 429 with the legacy body + Retry-After/X-RateLimit headers", async () => {
    const site = await db.instance.create({
      data: {
        systemId: "pharmacy-management",
        orgJson: JSON.stringify({ name: `ت2 ${RUN}`, currency: "SAR" }),
        adminJson: "{}",
        prefsJson: "{}",
        modulesJson: JSON.stringify(["pharmacy"]),
        trialEndsAt: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
      },
    });
    await db.site.create({ data: { instanceId: site.id, published: true } });
    const rec = await db.moduleRecord.create({
      data: { instanceId: site.id, moduleId: "pharmacy", dataJson: JSON.stringify(["دواء", "عام", "", "", "500", "2.00"]) },
    });
    try {
      for (let i = 0; i < 10; i++) {
        const res = await controller.orderPlace(
          placePost(site.id, validPayload(rec.id), { ...sameOrigin, ...withIp(IP_THROTTLE) }),
          segment(site.id)
        );
        expect(res.status).toBe(201);
      }
      const blocked = await controller.orderPlace(
        placePost(site.id, validPayload(rec.id), { ...sameOrigin, ...withIp(IP_THROTTLE) }),
        segment(site.id)
      );
      expect(blocked.status).toBe(429);
      const body = (await blocked.json()) as { error?: string; code?: string };
      expect(body.error).toBe("Too many orders — please wait a moment");
      expect(body.code).toBe("RATE");
      expect(blocked.headers.get("Retry-After")).toBe("600");
      expect(blocked.headers.get("X-RateLimit-Limit")).toBe("10");
      expect(blocked.headers.get("X-RateLimit-Window-Seconds")).toBe("600");
      expect(blocked.headers.get("x-request-id")).toMatch(UUID_RE);
    } finally {
      await db.orderReservation.deleteMany({ where: { instanceId: site.id } }).catch(() => undefined);
      await db.siteOrder.deleteMany({ where: { instanceId: site.id } }).catch(() => undefined);
      await db.orderIdempotency.deleteMany({ where: { instanceId: site.id } }).catch(() => undefined);
      await db.siteCustomer.deleteMany({ where: { instanceId: site.id } }).catch(() => undefined);
      await db.moduleRecord.deleteMany({ where: { instanceId: site.id } }).catch(() => undefined);
      await db.site.deleteMany({ where: { instanceId: site.id } }).catch(() => undefined);
      await db.instance.deleteMany({ where: { id: site.id } }).catch(() => undefined);
    }
  });
});

describe("ROUND 128 — orders controller: idempotent placement end-to-end", () => {
  test("same key + same payload → 201 then the byte-identical replay (200 + idempotency-replayed)", async () => {
    const key = `idem-${RUN}`;
    const payload = validPayload(p1, 1, { note: "retry me" });
    const first = await controller.orderPlace(
      placePost(A, payload, { ...sameOrigin, ...withIp(IP_IDEM), "idempotency-key": key }),
      segment(A)
    );
    expect(first.status).toBe(201);
    const firstBody = (await first.json()) as { id?: string; code?: string };
    expect(firstBody.id).toBeTruthy();

    const second = await controller.orderPlace(
      placePost(A, payload, { ...sameOrigin, ...withIp(IP_IDEM), "idempotency-key": key }),
      segment(A)
    );
    expect(second.status).toBe(200);
    expect(second.headers.get("idempotency-replayed")).toBe("true");
    const secondBody = (await second.json()) as { id?: string; code?: string };
    expect(secondBody.id).toBe(firstBody.id);
    expect(secondBody.code).toBe(firstBody.code);
    /* exactly one order row behind the two responses */
    const orders = await db.siteOrder.findMany({
      where: { instanceId: A, note: "retry me" },
    });
    expect(orders.length).toBe(1);
  });

  test("same key + a DIFFERENT payload → 422 KEY_REUSED", async () => {
    const key = `reuse-${RUN}`;
    const first = await controller.orderPlace(
      placePost(A, validPayload(p1, 1), { ...sameOrigin, ...withIp(IP_IDEM), "idempotency-key": key }),
      segment(A)
    );
    expect(first.status).toBe(201);
    const res = await controller.orderPlace(
      placePost(A, validPayload(p2, 1), { ...sameOrigin, ...withIp(IP_IDEM), "idempotency-key": key }),
      segment(A)
    );
    expect(res.status).toBe(422);
    const body = (await res.json()) as { error?: string; code?: string };
    expect(body.error).toBe("This Idempotency-Key was already used with a different request");
    expect(body.code).toBe("KEY_REUSED");
  });
});

/* ----------------- SERVICE — the placement rules --------------------- */

describe("ROUND 128 — orders service: guest placement", () => {
  test("happy path: contact find-or-create, minor-unit pricing, stock CAS, the R120 ledgers", async () => {
    const before = await db.moduleRecord.findUnique({ where: { id: p1 } });
    const stockBefore = Number(JSON.parse(before!.dataJson)[4]);
    const outcome = await service.placeOrder(A, validPayload(p1, 2), null);
    expect(outcome.kind).toBe("placed");
    if (outcome.kind !== "placed") return;
    const dto = outcome.dto;
    expect(dto.status).toBe("pending");
    expect(dto.code).toMatch(/^[A-Z0-9]{6}$/);
    expect(dto.items.length).toBe(1);
    expect(dto.items[0].price).toBe(25);
    expect(dto.items[0].qty).toBe(2);
    expect(dto.total).toBe(50);
    expect(dto.statusHistory[0]?.status).toBe("pending");
    /* the stock CAS decrement landed (assert the DELTA — other tests in
     * this file also place against p1) */
    const after = await db.moduleRecord.findUnique({ where: { id: p1 } });
    expect(Number(JSON.parse(after!.dataJson)[4])).toBe(stockBefore - 2);
    /* the OrderReservation ledger rows (one per line, state reserved) */
    const reservations = await db.orderReservation.findMany({
      where: { orderId: dto.id, recordId: p1 },
    });
    expect(reservations.length).toBe(1);
    expect(reservations[0].qty).toBe(2);
    expect(reservations[0].state).toBe("reserved");
    /* the second placement with the SAME email reuses the contact row */
    const outcome2 = await service.placeOrder(A, validPayload(p1, 1), null);
    expect(outcome2.kind).toBe("placed");
    const customers = await db.siteCustomer.findMany({
      where: { instanceId: A, name: "زائر اختبار" },
    });
    expect(customers.length).toBe(1);
  });

  test("banned contact → 403 'This contact cannot place orders'", async () => {
    await expectHttpError(
      service.placeOrder(
        A,
        { items: [{ recordId: p1, qty: 1 }], customer: { name: "محظور", email: BANNED_EMAIL } },
        null
      ),
      403,
      "This contact cannot place orders"
    );
  });

  test("merged-line quantity ceiling (60 + 60) → 400 QTY", async () => {
    await expectHttpError(
      service.placeOrder(
        A,
        {
          items: [
            { recordId: p1, qty: 60 },
            { recordId: p1, qty: 60 },
          ],
          customer: { name: "زائر اختبار", phone: PHONE },
        },
        null
      ),
      400,
      "Quantity per item is limited to 99",
      "QTY"
    );
  });

  test("unknown record → 409 ITEM_GONE", async () => {
    await expectHttpError(
      service.placeOrder(
        A,
        { items: [{ recordId: "does-not-exist", qty: 1 }], customer: { name: "زائر اختبار" } },
        null
      ),
      409,
      "One of the items is no longer available",
      "ITEM_GONE"
    );
  });

  test("insufficient stock → 409 STOCK with the exact remaining count", async () => {
    await expectHttpError(
      service.placeOrder(
        A,
        { items: [{ recordId: p2, qty: 6 }], customer: { name: "زائر اختبار" } },
        null
      ),
      409,
      "Only 5 × فيتامين ج left in stock",
      "STOCK"
    );
  });

  test("store-stop gates: unpublished site, locked trial, trashed workspace → 404 'Store not available'", async () => {
    /* unpublished: a fresh site row on a live instance */
    const site = await db.instance.create({
      data: {
        systemId: "pharmacy-management",
        orgJson: JSON.stringify({ name: `غ ${RUN}`, currency: "SAR" }),
        adminJson: "{}",
        prefsJson: "{}",
        modulesJson: JSON.stringify(["pharmacy"]),
        trialEndsAt: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
      },
    });
    await db.site.create({ data: { instanceId: site.id, published: false } });
    const payload = { items: [{ recordId: p1, qty: 1 }], customer: { name: "زائر" } };
    await expectHttpError(service.placeOrder(site.id, payload, null), 404, "Store not available");
    await expectHttpError(
      service.placeOrder(B, { items: [{ recordId: p1, qty: 1 }], customer: { name: "زائر" } }, null),
      404,
      "Store not available"
    );
    await expectHttpError(
      service.placeOrder(E, { items: [{ recordId: p1, qty: 1 }], customer: { name: "زائر" } }, null),
      404,
      "Store not available"
    );
    await db.site.deleteMany({ where: { instanceId: site.id } }).catch(() => undefined);
    await db.instance.deleteMany({ where: { id: site.id } }).catch(() => undefined);
  });
});

describe("ROUND 128 — orders service: coupon redemption", () => {
  test("a live percent coupon applies + writes the CouponRedemption ledger", async () => {
    const outcome = await service.placeOrder(
      A,
      validPayload(p1, 1, { couponCode: LIVE_CODE }),
      null
    );
    expect(outcome.kind).toBe("placed");
    if (outcome.kind !== "placed") return;
    /* 10% of 25.00 = 2.50 off */
    expect(outcome.dto.discount).toBe(2.5);
    expect(outcome.dto.total).toBe(22.5);
    expect(outcome.dto.couponCode).toBe(LIVE_CODE);
    const redemption = await db.couponRedemption.findFirst({
      where: { orderId: outcome.dto.id },
    });
    expect(redemption?.code).toBe(LIVE_CODE);
    const coupon = await db.storeCoupon.findFirst({ where: { instanceId: A, code: LIVE_CODE } });
    expect(coupon?.usedCount).toBe(1);
  });

  test("an exhausted coupon silently downgrades (order places, no discount, no ledger row)", async () => {
    const outcome = await service.placeOrder(
      A,
      validPayload(p1, 1, { couponCode: EXH_CODE }),
      null
    );
    expect(outcome.kind).toBe("placed");
    if (outcome.kind !== "placed") return;
    expect(outcome.dto.discount).toBe(0);
    expect(outcome.dto.couponCode).toBeNull();
    const redemption = await db.couponRedemption.findFirst({
      where: { orderId: outcome.dto.id },
    });
    expect(redemption).toBeNull();
  });
});

/* ----------------- SERVICE — the tracking contract ------------------ */

describe("ROUND 128 — orders service: tracking", () => {
  let placedCode = "";

  beforeAll(async () => {
    const outcome = await service.placeOrder(
      A,
      { items: [{ recordId: p1, qty: 1 }], customer: { name: "متتبع", phone: PHONE } },
      null
    );
    if (outcome.kind === "placed") placedCode = outcome.dto.code ?? "";
  });

  test("code + matching phone → the guest projection + the receipt token", async () => {
    const payload = await service.trackOrder(A, { code: placedCode, phone: PHONE });
    expect(payload.code).toBe(placedCode);
    expect(payload.status).toBe("pending");
    expect(typeof payload.receiptToken).toBe("string");
    expect((payload.receiptToken as string).length).toBeGreaterThan(10);
    /* no PII in the projection */
    const json = JSON.stringify(payload);
    expect(json).not.toContain("زائر");
    expect(json).not.toContain("customer");
  });

  test("valid code + WRONG phone → plain 404 (no existence oracle)", async () => {
    await expectHttpError(
      service.trackOrder(A, { code: placedCode, phone: "0500000000" }),
      404,
      "Order not found"
    );
  });

  test("unknown code → the same plain 404", async () => {
    await expectHttpError(
      service.trackOrder(A, { code: "ZZZZZZ", phone: PHONE }),
      404,
      "Order not found"
    );
  });

  test("stopped store → 404 'Store not available' (nothing is trackable while locked)", async () => {
    await expectHttpError(
      service.trackOrder(B, { code: placedCode, phone: PHONE }),
      404,
      "Store not available"
    );
  });
});
