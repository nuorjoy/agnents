/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — TENANT ISOLATION (round 41, task 5).
 *
 * Proves that no data ever leaks between two provisioned workspaces
 * (tenants) across every surface the platform exposes:
 *
 *   المخزون        module records (inventory workspaces)
 *   الفواتير       storefront orders
 *   العملاء        site customers (+ their PII: email / phone)
 *   الإعدادات      site content + workspace settings
 *   الموقع العام   public website (store, rendered page, contact)
 *   المراسلات      activity feed, team members, support tickets
 *   PII            sealed-at-rest envelopes + blind indexes
 *
 * Two layers, following the suite's established conventions:
 *
 *  UNIT (throwaway PostgreSQL test database via getTestDb()): seed two tenants
 *  directly through Prisma + the real server mappers (sealAdminSection,
 *  encryptField, blindIndex), then assert every repo-level read helper and
 *  every route-shaped query is instance-scoped — tenant B's tables hold
 *  ZERO rows that match tenant A's ids, and vice versa.
 *
 *  LIVE (dev server :3000, dev DB — cleanup discipline like
 *  email-verification.test.ts): provision tenants A and B through the REAL
 *  API, publish their sites, seed inventory/members, register + verify +
 *  log in customers on both sites, place orders — then attack:
 *    • A's owner cookie against every B instance route → 401/403, never
 *      B's data (reads AND writes, incl. sub-resource PATCH/DELETE);
 *    • anonymous requests → 401 everywhere;
 *    • customer-of-A cookie against B's site routes → 401 / own data only;
 *    • PII: A's customer list never contains B's customers; admin surfaces
 *      refuse instance/customer cookies; public bodies never carry sealed
 *      ciphertext ("enc:v1:") or customer emails/phones;
 *    • origin-guard regressions (cookie mutation without Origin → 403);
 *    • count-based leak detection (B's table counts identical after five
 *      mutations on A);
 *    • exports: A's export carries zero B strings and vice versa.
 *
 *  Every row / outbox file / rate-limit key this run induces is removed
 *  again in afterAll. AuditLog rows are APPEND-ONLY and deliberately left
 *  in place (deleting mid-chain would break the tamper-evidence chain —
 *  see the Task 9 housekeeping precedent in the worklog).
 *
 *  RATE-LIMIT HYGIENE: every request carries a per-run random
 *  x-forwarded-for IP (TEST-NET-2) so this suite's limiter keys can never
 *  collide with parallel agents or with earlier runs; those keys (plus the
 *  blind-indexed per-email keys) are purged in cleanup.
 *
 *  SLICED EXECUTION (the sandbox OOM ceiling — .zscripts/test-battery.sh):
 *  one dev-server lifetime cannot load every route this suite touches
 *  (next-server grows to ~3.0-3.5GB and the kernel kills it around test
 *  15, measured ROUND 104+; zero isolation-logic failures — every post-kill
 *  error is a connection refusal). TENANT_ISOLATION_SLICE=N runs ONE slice
 *  of the live suite against a FRESH server:
 *    slice 1  — provisioning wave (+ DB layer)
 *    slice 2  — owner reads (L12/L13)
 *    slice 3  — cross-tenant reads (core) + mirror
 *    slice 4  — cross-tenant reads (people+export) + anonymous (people)
 *    slice 5  — anonymous (core) + PII scoping (must precede slice 8!)
 *    slice 6  — cross-tenant mutations (collections) + count leak detection
 *    slice 7  — cross-tenant mutations (sub-resource PATCH/DELETE)
 *    slice 8  — guest-era cross-site (legitimately adds A's email under B)
 *    slice 9  — public storefronts + rendered pages
 *    slice 10 — contact inquiry + origin guard + exports
 *    99     — cleanup phase (rows + rate keys + outbox + stale sweep)
 *  The provisioning wave runs EXACTLY ONCE (slice 1); slices 2-10 REJOIN
 *  its tenants by blind index + fresh logins and re-derive the seeded row
 *  ids from the dev DB. Every slice ends with its own PII/ciphertext sweep
 *  of the bodies it captured (the full-mode global sweep spans one process
 *  only, so each slice sweeps its own corpus). Each slice's afterAll
 *  purges ONLY rate keys (fresh limiter window per slice; rows persist for
 *  the rejoin slices); the cleanup phase owns row deletion and also sweeps
 *  rows from ANY interrupted battery. TENANT_ISOLATION_RUN_ID /
 *  TENANT_ISOLATION_XFF are set by the battery so all phases share
 *  identities and rate keys (defaults keep direct solo runs randomized).
 *  Unset/0 = legacy single-process run, byte-for-byte the old behavior.
 *
 *  CONCURRENT-AGENT SAFETY (measured ROUND 105): parallel review sessions
 *  share this machine, port 3000 and the dev DB. The battery therefore
 *  uses a NON-NUMERIC run id (its rows are invisible to an older
 *  concurrent session's numeric stale sweep), and this suite's own numeric
 *  stale sweep only matches rows created > 30 minutes ago — a concurrent
 *  battery's fresh rows are never swept mid-run.
 */
import { describe, test, expect, beforeAll, afterAll } from "bun:test";
import { existsSync, readdirSync, readFileSync, unlinkSync } from "node:fs";
import { join } from "node:path";
import type { Client } from "pg";
import { REPO_ROOT, ensureDemoEnv, getTestDb, serverPg, closeServerPg } from "./test-setup";

/* env control — BEFORE the first dynamic import of any env-binding module */
ensureDemoEnv();

const BASE = "http://localhost:3000";
const DEV_OUTBOX = join(REPO_ROOT, "storage", "outbox");
const FETCH_TIMEOUT_MS = 30_000;

/* ---------------------------------------------------------------------- */
/* sliced-execution control (see the header + .zscripts/test-battery.sh)    */
/* ---------------------------------------------------------------------- */
const SLICE_COUNT = 10;
const SLICE_CLEANUP = 99;
/** slice tag for tests that run ONLY in the legacy full run (their corpus
 *  spans the whole single process — e.g. the global body sweep). */
const FULL_ONLY = SLICE_COUNT + 1;
const SLICE = Number(process.env.TENANT_ISOLATION_SLICE ?? "0");
if (!Number.isInteger(SLICE) || SLICE < 0 || (SLICE > SLICE_COUNT && SLICE !== SLICE_CLEANUP)) {
  throw new Error(
    `[tenant-isolation] TENANT_ISOLATION_SLICE must be 0 (full run), 1..${SLICE_COUNT} (slice), ` +
      `or ${SLICE_CLEANUP} (cleanup) — got "${process.env.TENANT_ISOLATION_SLICE}"`
  );
}

/* ---------------------------------------------------------------------- */
/* per-run randomized identities (dedupe, rate keys, leak markers)         */
/* ---------------------------------------------------------------------- */
const RUN = process.env.TENANT_ISOLATION_RUN_ID ?? `${Date.now()}-${Math.floor(Math.random() * 1e6)}`;
/** TEST-NET-2 address — unique per run by default; the battery pins ONE
 *  shared address across all slices so the cleanup phase can purge every
 *  rate-limit key this battery occupied. */
const XFF_IP =
  process.env.TENANT_ISOLATION_XFF ?? `198.51.100.${Math.floor(Math.random() * 254) + 1}`;
const ORG_A = `TenantAlpha-${RUN}`;
const ORG_B = `TenantBeta-${RUN}`;
const EMAIL_A = `owner-a-${RUN}@example.com`;
const EMAIL_B = `owner-b-${RUN}@example.com`;
const OWNER_PASSWORD = "correct horse isolation 7";
const PROD_A = `AlphaProbe-${RUN}`;
const PROD_B = `BetaProbe-${RUN}`;
const CUST_A_EMAIL = `customer-a-${RUN}@example.com`;
const CUST_B_EMAIL = `customer-b-${RUN}@example.com`;
const CUST_PASSWORD = "customer isolation pass 9";
/** deterministic per-RUN phone digits — every slice process re-derives the
 *  SAME phone (process-random values broke the PII assertions across
 *  slices: slice 1's checkout stored one number, slice 8's process
 *  generated another). Same +1XX2555XXXX shape as before. */
function runPhoneDigits(seed: string): string {
  let h = 0;
  for (const ch of seed) h = (h * 31 + ch.charCodeAt(0)) % 100000;
  return String(h % 10000).padStart(4, "0");
}
const CUST_A_PHONE = `+1212555${runPhoneDigits(`${RUN}a`)}`;
const CUST_B_PHONE = `+1312555${runPhoneDigits(`${RUN}b`)}`;
const CUST_A_NAME = "عميل ألف";
const CUST_B_NAME = "عميل باء";
const MEMBER_A_NAME = "عضو ألف";
const MEMBER_B_NAME = "عضو باء";
const MEMBER_A_EMAIL = `member-a-${RUN}@example.com`;
const MEMBER_B_EMAIL = `member-b-${RUN}@example.com`;
const CONTACT_B_EMAIL = `contact-b-${RUN}@example.com`;
const VAULT_MARKER = "enc:v1:";

/** modules enabled on both test instances (pharmacy = the storefront module) */
const MODULES = ["patients", "appointments", "pharmacy", "invoices", "reports"];

function instancePayload(org: string, email: string, adminName: string) {
  return {
    systemId: "hospital-management",
    org: {
      name: org,
      country: "SA",
      currency: "SAR",
      timezone: "Asia/Riyadh",
      address: `${org} Tower`,
      /* ROUND 134 — the deep tenant-uniqueness gate (phone scanned across
       * trashed + demo rows too) makes a CONSTANT org phone a cross-run /
       * cross-tenant 409; derive it per-run like the emails (the shared
       * runPhoneDigits helper). */
      phone: `+9665${runPhoneDigits(`${RUN}-${org}`)}`,
    },
    admin: { name: adminName, email, role: "owner" as const, twoFA: false, password: OWNER_PASSWORD },
    prefs: {
      lang: "ar" as const,
      theme: "light" as const,
      notif: true,
      backup: true,
      audit: true,
      demo: false,
    },
    modules: MODULES,
  };
}

function siteContentPayload(org: string, contactEmail: string) {
  return {
    tagline: `${org} tagline`,
    heroTitle: org,
    heroDesc: `${org} hero description for isolation testing`,
    aboutTitle: "من نحن",
    about: `${org} about text`,
    services: [{ icon: "stethoscope", title: `${org} service`, desc: `${org} service description` }],
    contactEmail,
    contactPhone: "+966500000009",
    contactAddress: `${org} address`,
    logoUrl: "",
    socialLinks: [],
    workingHours: "24/7",
  };
}

/** a valid pharmacy module-record (7 preset cols: drug, category, batch,
 *  expiry, stock, price, status) — sellable through the storefront.
 * ROUND 134 fix: the BATCH is the pharmacy preset's id-column and the
 * R132 unique-ID law (409 RECORD_CODE_COLLISION on a duplicate id cell)
 * made the historical FIXED "B-900001" collide whenever the suite created
 * a SECOND product (slice 6's `${PROD_A}-2`) — the batch now derives
 * deterministically from the product name so every probe row stays unique
 * (the storefront sale paths key on the NAME, not the batch — verified:
 * no other consumer reads the batch value). */
function batchFor(name: string): string {
  let h = 0;
  for (const ch of name) h = (h * 31 + ch.charCodeAt(0)) % 1_000_000;
  return `B-9${String(h).padStart(5, "0")}`;
}
function pharmacyProductPayload(name: string) {
  return {
    moduleId: "pharmacy",
    values: [name, "فئة العزل", batchFor(name), "2027-12-31", "50", "12.50", "instock"],
    statusKey: "instock",
  };
}

/* ---------------------------------------------------------------------- */
/* tiny cookie jar (the live flows need four independent sessions)         */
/* ---------------------------------------------------------------------- */
class CookieJar {
  private cookies = new Map<string, string>();

  setFrom(res: Response): void {
    const lines: string[] =
      typeof res.headers.getSetCookie === "function" ? res.headers.getSetCookie() : [];
    if (lines.length === 0) {
      const single = res.headers.get("set-cookie");
      if (single) lines.push(single);
    }
    for (const line of lines) {
      const [pair] = line.split(";");
      const eq = pair.indexOf("=");
      if (eq > 0) this.cookies.set(pair.slice(0, eq).trim(), pair.slice(eq + 1).trim());
    }
  }

  header(): string {
    return [...this.cookies.entries()].map(([k, v]) => `${k}=${v}`).join("; ");
  }
}

/* response bodies captured for the final PII / ciphertext sweep */
const allBodies: string[] = [];
const publicBodies: string[] = [];

interface JFetchOpts {
  method?: string;
  jar?: CookieJar;
  headers?: Record<string, string>;
  body?: string;
  /** opt-in: this response is served to an anonymous visitor */
  publicBody?: boolean;
}

/** fetch with a hard timeout + jar + the run's XFF rate-key IP + capture. */
async function jfetch(path: string, opts: JFetchOpts = {}): Promise<Response> {
  const headers: Record<string, string> = {
    "x-forwarded-for": XFF_IP,
    ...(opts.headers ?? {}),
  };
  if (opts.jar) {
    const cookie = opts.jar.header();
    if (cookie) headers.cookie = cookie;
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
  try {
    const res = await fetch(`${BASE}${path}`, {
      method: opts.method ?? "GET",
      headers,
      body: opts.body,
      signal: controller.signal,
    });
    try {
      const text = (await res.clone().text()).slice(0, 200_000);
      allBodies.push(text);
      if (opts.publicBody) publicBodies.push(text);
    } catch {
      /* unreadable body — nothing to sweep */
    }
    return res;
  } finally {
    clearTimeout(timer);
  }
}

async function serverReachable(): Promise<boolean> {
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 2000);
    try {
      const res = await fetch(`${BASE}/api/status`, { signal: controller.signal });
      return res.ok;
    } finally {
      clearTimeout(timer);
    }
  } catch {
    return false;
  }
}

/** slice tag for the provisioning wave — it IS slice 1's chunk (slices 2-6
 *  never re-provision: they REJOIN via the beforeAll below — blind-index
 *  lookups + fresh logins + re-derived row ids). */
const PROVISION = 1;

/** live-server test with an extended timeout (cold route compiles).
 *  Sliced mode registers ONLY the current slice's chunk (the provisioning
 *  wave carries slice tag 1) — bun reports exactly what ran, nothing
 *  "(skip)"-masked (the battery classifies skip lines as INFRA;
 *  unregistration keeps slice output honest). */
function liveTest(slice: number, name: string, fn: () => Promise<void>): void {
  if (SLICE === SLICE_CLEANUP) return; // cleanup phase registers no live tests
  if (SLICE !== 0 && slice !== SLICE) return;
  test(name, fn, 60_000);
}

/* ---------------------------------------------------------------------- */
/* read-only helpers over the dev server's PostgreSQL database (never      */
/* writes outside afterAll) — the old direct db/custom.db file opens        */
/* ---------------------------------------------------------------------- */

const COUNTABLE_TABLES = new Set([
  "Instance",
  "Site",
  "SiteCustomer",
  "SiteOrder",
  "ModuleRecord",
  "TeamMember",
  "Activity",
  "SupportTicket",
]);

async function devCount(table: string, instanceId: string): Promise<number> {
  if (!COUNTABLE_TABLES.has(table)) throw new Error(`unsafe table name: ${table}`);
  const pg = await serverPg();
  /* COUNT(*)::int — pg returns bigint as a JS string; the fixture compares numbers */
  const result = await pg.query<{ c: number }>(
    `SELECT COUNT(*)::int AS c FROM "${table}" WHERE "instanceId" = $1`,
    [instanceId]
  );
  return result.rows[0]?.c ?? 0;
}

async function devOne<T>(sql: string, ...params: (string | number | null)[]): Promise<T | null> {
  const pg = await serverPg();
  const result = await pg.query(sql, params);
  return (result.rows[0] as T | undefined) ?? null;
}

/** ROUND 44 — the verification-token extractor was removed together with the
 * customer signup/verification feature (member login deleted from the public
 * websites). The outbox cleanup below still uses the fs helpers directly. */

/* ====================================================================== */
/* PART A — DB LAYER (throwaway test DB)                                   */
/* ====================================================================== */
/* the DB-layer suite is offline + cheap but runs its own throwaway-DB
 * setup — keep it in the full run and slice 1 only (slices 2+ stay lean;
 * a describe.skip would print "(skip)" lines and misclassify the battery) */
const maybeDbLayerDescribe: (name: string, fn: () => void) => void =
  SLICE === 0 || SLICE === 1 ? describe : () => undefined;
maybeDbLayerDescribe("tenant isolation — DB layer (throwaway test DB)", () => {
  interface DbLayerCtx {
    db: Awaited<ReturnType<typeof getTestDb>> | null;
    A: string;
    B: string;
    recordAId: string;
    custAId: string;
    orderAId: string;
    siteAId: string;
    memberAId: string;
    activityAId: string;
    ticketAId: string;
    emailA: string;
    emailB: string;
    custAEmail: string;
    custAPhone: string;
    orgA: string;
    orgB: string;
  }
  const ctx: DbLayerCtx = {
    db: null,
    A: "",
    B: "",
    recordAId: "",
    custAId: "",
    orderAId: "",
    siteAId: "",
    memberAId: "",
    activityAId: "",
    ticketAId: "",
    emailA: `db-owner-a-${RUN}@example.com`,
    emailB: `db-owner-b-${RUN}@example.com`,
    custAEmail: `db-customer-a-${RUN}@example.com`,
    custAPhone: "+15550001234",
    orgA: `DbTenantAlpha-${RUN}`,
    orgB: `DbTenantBeta-${RUN}`,
  };

  beforeAll(
    async () => {
    const db = await getTestDb();
    ctx.db = db;
    const { sealAdminSection } = await import("@/lib/server/instance-mapper");
    const { encryptField, blindIndex } = await import("@/lib/server/crypto-vault");

    /* tenant A — sealed admin identity exactly like the provisioning route */
    const sealedA = sealAdminSection({
      name: "مالك ألف",
      email: ctx.emailA,
      role: "owner",
      twoFA: false,
    });
    const A = await db.instance.create({
      data: {
        systemId: "hospital-management",
        orgJson: JSON.stringify({
          name: ctx.orgA,
          country: "SA",
          currency: "SAR",
          timezone: "Asia/Riyadh",
          address: "Alpha Tower",
          phone: "+966500000001",
        }),
        adminJson: sealedA.adminJson,
        adminEmailIndex: sealedA.adminEmailIndex,
        prefsJson: JSON.stringify({
          lang: "ar",
          theme: "light",
          notif: true,
          backup: true,
          audit: true,
          demo: false,
        }),
        modulesJson: JSON.stringify(MODULES),
      },
    });
    ctx.A = A.id;

    /* tenant B — same shape, different identity */
    const sealedB = sealAdminSection({
      name: "مالك باء",
      email: ctx.emailB,
      role: "owner",
      twoFA: false,
    });
    const B = await db.instance.create({
      data: {
        systemId: "hospital-management",
        orgJson: JSON.stringify({
          name: ctx.orgB,
          country: "AE",
          currency: "AED",
          timezone: "Asia/Dubai",
          address: "Beta Tower",
          phone: "+971500000002",
        }),
        adminJson: sealedB.adminJson,
        adminEmailIndex: sealedB.adminEmailIndex,
        prefsJson: JSON.stringify({
          lang: "en",
          theme: "dark",
          notif: true,
          backup: true,
          audit: true,
          demo: false,
        }),
        modulesJson: JSON.stringify(MODULES),
      },
    });
    ctx.B = B.id;

    /* data ONLY on tenant A — every family the platform persists */
    const recordA = await db.moduleRecord.create({
      data: {
        instanceId: A.id,
        moduleId: "pharmacy",
        dataJson: JSON.stringify([
          `DbAlphaProbe-${RUN}`,
          "فئة ألف",
          "B-777001",
          "2027-05-05",
          "40",
          "18.25",
          "instock",
        ]),
        statusKey: "instock",
      },
    });
    ctx.recordAId = recordA.id;

    const custA = await db.siteCustomer.create({
      data: {
        instanceId: A.id,
        name: "عميل ألف",
        email: encryptField(ctx.custAEmail) ?? "",
        emailIndex: blindIndex(ctx.custAEmail) ?? "",
        phone: encryptField(ctx.custAPhone) ?? null,
        passwordHash: "$argon2id$v=1$m=19456,t=2,p=1$c2VlZA$c2VlZA",
      },
    });
    ctx.custAId = custA.id;

    const orderA = await db.siteOrder.create({
      data: {
        instanceId: A.id,
        customerId: custA.id,
        itemsJson: JSON.stringify({
          v: 2,
          items: [{ recordId: recordA.id, name: `DbAlphaProbe-${RUN}`, price: 1825, qty: 1 }],
        }),
        total: 1825,
        currency: "SAR",
        status: "pending",
      },
    });
    ctx.orderAId = orderA.id;

    const siteA = await db.site.create({
      data: {
        instanceId: A.id,
        published: true,
        theme: "aurora",
        views: 0,
        contentJson: JSON.stringify(siteContentPayload(ctx.orgA, `db-contact-a-${RUN}@example.com`)),
      },
    });
    ctx.siteAId = siteA.id;

    const memberA = await db.teamMember.create({
      data: {
        instanceId: A.id,
        name: "عضو ألف",
        email: encryptField(`db-member-a-${RUN}@example.com`) ?? "",
        role: "staff",
      },
    });
    ctx.memberAId = memberA.id;

    const activityA = await db.activity.create({
      data: { instanceId: A.id, kind: "actDataImported", metaJson: JSON.stringify({ source: "isolation" }) },
    });
    ctx.activityAId = activityA.id;

    const ticketA = await db.supportTicket.create({
      data: {
        subject: `استفسار عزل ألف ${RUN}`,
        message: "رسالة اختبار العزل",
        requesterName: "عميل ألف",
        requesterEmail: encryptField(ctx.custAEmail) ?? "",
        requesterEmailIndex: blindIndex(ctx.custAEmail) ?? "",
        category: "general",
        priority: "medium",
        status: "open",
        instanceId: A.id,
        source: "public",
      },
    });
    ctx.ticketAId = ticketA.id;
  }, 60_000);

  afterAll(async () => {
    const db = ctx.db;
    if (!db || !ctx.A || !ctx.B) return;
    try {
      await db.supportTicket.deleteMany({ where: { instanceId: { in: [ctx.A, ctx.B] } } });
      await db.instance.deleteMany({ where: { id: { in: [ctx.A, ctx.B] } } });
      /* explicit fallbacks — no-ops when the FK cascade already fired */
      await db.siteOrder.deleteMany({ where: { instanceId: { in: [ctx.A, ctx.B] } } });
      await db.siteCustomer.deleteMany({ where: { instanceId: { in: [ctx.A, ctx.B] } } });
      await db.moduleRecord.deleteMany({ where: { instanceId: { in: [ctx.A, ctx.B] } } });
      await db.activity.deleteMany({ where: { instanceId: { in: [ctx.A, ctx.B] } } });
      await db.teamMember.deleteMany({ where: { instanceId: { in: [ctx.A, ctx.B] } } });
      await db.site.deleteMany({ where: { instanceId: { in: [ctx.A, ctx.B] } } });
      /* leftover verification — every seeded row must be gone */
      const counts: [string, Promise<number>][] = [
        ["SupportTicket", db.supportTicket.count({ where: { instanceId: { in: [ctx.A, ctx.B] } } })],
        ["SiteOrder", db.siteOrder.count({ where: { instanceId: { in: [ctx.A, ctx.B] } } })],
        ["SiteCustomer", db.siteCustomer.count({ where: { instanceId: { in: [ctx.A, ctx.B] } } })],
        ["ModuleRecord", db.moduleRecord.count({ where: { instanceId: { in: [ctx.A, ctx.B] } } })],
        ["Activity", db.activity.count({ where: { instanceId: { in: [ctx.A, ctx.B] } } })],
        ["TeamMember", db.teamMember.count({ where: { instanceId: { in: [ctx.A, ctx.B] } } })],
        ["Site", db.site.count({ where: { instanceId: { in: [ctx.A, ctx.B] } } })],
        ["Instance", db.instance.count({ where: { id: { in: [ctx.A, ctx.B] } } })],
      ];
      for (const [table, count] of counts) {
        const left = await count;
        if (left > 0) console.error(`[tenant-isolation] DB-layer cleanup leftover in ${table}: ${left}`);
      }
    } catch (error) {
      console.error("[tenant-isolation] DB-layer cleanup failed:", error);
    }
    },
    120_000
  );

  test("المخزون — module records: A's rows resolve only under A's scope; every B-scoped query is empty", async () => {
    const db = ctx.db!;
    const aRows = await db.moduleRecord.findMany({ where: { instanceId: ctx.A, moduleId: "pharmacy" } });
    expect(aRows.length).toBe(1);
    expect(aRows[0].dataJson).toContain(`DbAlphaProbe-${RUN}`);

    /* the exact query shapes the routes use (where: { instanceId, moduleId }) */
    expect(await db.moduleRecord.findMany({ where: { instanceId: ctx.B, moduleId: "pharmacy" } })).toEqual([]);
    expect(await db.moduleRecord.count({ where: { instanceId: ctx.B } })).toBe(0);

    /* sub-resource guard predicate (module-records/[recordId] routes) */
    expect(await db.moduleRecord.findFirst({ where: { id: ctx.recordAId, instanceId: ctx.B } })).toBeNull();
    expect(await db.moduleRecord.findUnique({ where: { id: ctx.recordAId } })).not.toBeNull();
  });

  test("storefront helper loadStoreProducts: A's instance sees its product; B's instance sees nothing", async () => {
    const db = ctx.db!;
    const { loadStoreProducts } = await import("@/lib/server/store-mapper");
    const rowA = await db.instance.findUnique({ where: { id: ctx.A } });
    const rowB = await db.instance.findUnique({ where: { id: ctx.B } });
    if (!rowA || !rowB) throw new Error("seeded instances missing");

    const productsA = await loadStoreProducts(rowA);
    expect(productsA.length).toBe(1);
    expect(productsA[0].name).toBe(`DbAlphaProbe-${RUN}`);
    expect(productsA[0].price).toBe(18.25);

    const productsB = await loadStoreProducts(rowB);
    expect(productsB).toEqual([]);
  });

  test("الموقع الإلكتروني — site row exists for A only; readSiteContent round-trips A's content", async () => {
    const db = ctx.db!;
    const { readSiteContent, toSiteDTO } = await import("@/lib/server/site-mapper");

    const siteA = await db.site.findUnique({ where: { instanceId: ctx.A } });
    expect(siteA).not.toBeNull();
    const siteB = await db.site.findUnique({ where: { instanceId: ctx.B } });
    expect(siteB).toBeNull(); // the orders/customers routes' 404 path for B

    if (!siteA) throw new Error("site A missing");
    const content = readSiteContent(siteA.contentJson);
    expect(content.heroTitle).toBe(ctx.orgA);
    expect(toSiteDTO(siteA).instanceId).toBe(ctx.A);
    expect(readSiteContent(siteA.contentJson).contactEmail).toBe(`db-contact-a-${RUN}@example.com`);
  });

  test("العملاء + PII — the customer login lookup finds A's row under A and null under B; PII sealed at rest", async () => {
    const db = ctx.db!;
    const { blindIndex, decryptField, isSealedField } = await import("@/lib/server/crypto-vault");
    const idx = blindIndex(ctx.custAEmail) as string;

    /* the exact login/dedupe query shape (instanceId AND emailIndex) */
    const underA = await db.siteCustomer.findFirst({ where: { instanceId: ctx.A, emailIndex: idx } });
    expect(underA).not.toBeNull();
    const underB = await db.siteCustomer.findFirst({ where: { instanceId: ctx.B, emailIndex: idx } });
    expect(underB).toBeNull(); // same email cannot resolve on tenant B
    expect(await db.siteCustomer.count({ where: { instanceId: ctx.B } })).toBe(0);

    /* PII at rest: AES-256-GCM envelopes + keyed blind index, never plaintext */
    if (!underA) throw new Error("customer A missing");
    expect(isSealedField(underA.email)).toBe(true);
    expect(underA.email.startsWith(VAULT_MARKER)).toBe(true);
    expect(underA.email).not.toContain(ctx.custAEmail);
    expect(isSealedField(underA.phone)).toBe(true);
    expect(underA.phone ?? "").not.toContain(ctx.custAPhone);
    expect(underA.emailIndex).toMatch(/^[0-9a-f]{64}$/);
    expect(underA.emailIndex).not.toBe(ctx.custAEmail);
    expect(decryptField(underA.email)).toBe(ctx.custAEmail);
    expect(decryptField(underA.phone)).toBe(ctx.custAPhone);
  });

  test("الفواتير — orders: A's order resolves under A's scope only; the customer-scoped B query is empty", async () => {
    const db = ctx.db!;

    const aOrders = await db.siteOrder.findMany({ where: { instanceId: ctx.A } });
    expect(aOrders.length).toBe(1);
    expect(aOrders[0].id).toBe(ctx.orderAId);

    /* the owner-queue query shape (where: { instanceId }) */
    expect(await db.siteOrder.findMany({ where: { instanceId: ctx.B } })).toEqual([]);

    /* the customer-facing query shape (where: { instanceId, customerId }) */
    expect(
      await db.siteOrder.findMany({ where: { instanceId: ctx.B, customerId: ctx.custAId } })
    ).toEqual([]);

    /* the order-PATCH guard predicate (existing.instanceId !== id → 404) */
    const existing = await db.siteOrder.findUnique({ where: { id: ctx.orderAId } });
    expect(existing).not.toBeNull();
    expect(existing!.instanceId !== ctx.B).toBe(true);
    expect(await db.siteOrder.findFirst({ where: { id: ctx.orderAId, instanceId: ctx.B } })).toBeNull();
  });

  test("المراسلات — team members + activity feed: B-scoped counts are zero; the member guard is AND-scoped", async () => {
    const db = ctx.db!;

    const aMembers = await db.teamMember.findMany({ where: { instanceId: ctx.A } });
    expect(aMembers.length).toBe(1);
    expect(aMembers[0].name).toBe("عضو ألف");
    expect(await db.teamMember.count({ where: { instanceId: ctx.B } })).toBe(0);

    /* the member-DELETE guard predicate (findFirst id AND instanceId) */
    expect(await db.teamMember.findFirst({ where: { id: ctx.memberAId, instanceId: ctx.B } })).toBeNull();

    const aActivities = await db.activity.findMany({ where: { instanceId: ctx.A } });
    expect(aActivities.length).toBe(1);
    expect(aActivities[0].id).toBe(ctx.activityAId);
    expect(await db.activity.count({ where: { instanceId: ctx.B } })).toBe(0);
  });

  test("المراسلات — public tickets: linked to A only; B's inquiry aggregation finds none", async () => {
    const db = ctx.db!;
    const { blindIndex } = await import("@/lib/server/crypto-vault");
    const idx = blindIndex(ctx.custAEmail) as string;

    const aTickets = await db.supportTicket.findMany({ where: { instanceId: ctx.A, source: "public" } });
    expect(aTickets.length).toBe(1);
    expect(aTickets[0].id).toBe(ctx.ticketAId);

    expect(await db.supportTicket.findMany({ where: { instanceId: ctx.B } })).toEqual([]);

    /* the inquiry-count aggregation from the site-customers route */
    const grouped = await db.supportTicket.groupBy({
      by: ["requesterEmailIndex"],
      where: { instanceId: ctx.B, source: "public" },
      _count: { _all: true },
    });
    expect(grouped).toEqual([]);
    expect(
      await db.supportTicket.count({ where: { instanceId: ctx.B, requesterEmailIndex: idx } })
    ).toBe(0);
  });

  test("workspace identity — sealed adminJson holds no plaintext; the login candidate query is email-scoped", async () => {
    const db = ctx.db!;
    const { blindIndex } = await import("@/lib/server/crypto-vault");
    const { readAdminEmail } = await import("@/lib/server/instance-mapper");

    const A = await db.instance.findUnique({ where: { id: ctx.A } });
    const B = await db.instance.findUnique({ where: { id: ctx.B } });
    if (!A || !B) throw new Error("seeded instances missing");

    /* PII at rest: the login email lives ONLY as a sealed envelope */
    expect(A.adminJson).toContain(VAULT_MARKER);
    expect(A.adminJson).not.toContain(ctx.emailA);
    expect(readAdminEmail(A.adminJson)).toBe(ctx.emailA);

    /* the login route's candidate resolution (where: { adminEmailIndex }) */
    const idxA = blindIndex(ctx.emailA) as string;
    const candidatesForA = await db.instance.findMany({ where: { adminEmailIndex: idxA } });
    expect(candidatesForA.map((row) => row.id)).toEqual([ctx.A]);

    /* A's email never resolves B — and B's own email resolves only B */
    expect(
      await db.instance.findFirst({ where: { id: ctx.B, adminEmailIndex: idxA } })
    ).toBeNull();
    const idxB = blindIndex(ctx.emailB) as string;
    expect(
      (await db.instance.findMany({ where: { adminEmailIndex: idxB } })).map((row) => row.id)
    ).toEqual([ctx.B]);
  });
});

/* ====================================================================== */
/* live-suite shared state — MODULE scope (hoisted out of the describe so  */
/* the cleanup engine can read the ids whether they came from THIS        */
/* process's tests (full run / slice 1) or were re-derived from the dev DB */
/* (rejoin slices / the cleanup phase).                                    */
/* ====================================================================== */
let A = "";
let B = "";
let recordAId = "";
let recordBId = "";
let memberIdB = "";
let orderIdA = "";
let orderIdB = "";
let custAId = "";
let custBId = "";

/* ====================================================================== */
/* cleanup engine (shared by the full-run afterAll + the cleanup phase)    */
/* ====================================================================== */

/** purge every rate-limit key this run's identities can occupy (the shared
 *  XFF IP + the blind-indexed emails + the per-customer site-order keys) —
 *  slices call this after EVERY slice so each starts with a fresh limiter
 *  window (the login limit is 8/10min per email across all rejoin slices). */
async function purgeRunRateKeys(
  pg: Client,
  blindIndex: (value: string | null | undefined) => string | null | undefined
): Promise<void> {
  await pg.query('DELETE FROM "RateLimitHit" WHERE "key" LIKE \'%\' || $1 || \'%\'', [XFF_IP]);
  for (const email of [EMAIL_A, EMAIL_B, CUST_A_EMAIL, CUST_B_EMAIL]) {
    const idx = blindIndex(email) as string;
    for (const key of [`inst-create-email:${idx}`, `inst-login-email:${idx}`, `cust-login-email:${idx}`]) {
      await pg.query('DELETE FROM "RateLimitHit" WHERE "key" = $1', [key]);
    }
  }
  if (A && custAId) await pg.query('DELETE FROM "RateLimitHit" WHERE "key" = $1', [`site-order:${A}:${custAId}`]);
  if (B && custBId) await pg.query('DELETE FROM "RateLimitHit" WHERE "key" = $1', [`site-order:${B}:${custBId}`]);
}

/** delete one instance's suite rows (SupportTicket first, then the Instance
 *  row, then the explicit cascade fallbacks — the original afterAll order).
 *  PostgreSQL enforces the FK cascades natively — no PRAGMA needed. */
async function deleteInstanceRows(pg: Client, instanceId: string): Promise<void> {
  await pg.query('DELETE FROM "SupportTicket" WHERE "instanceId" = $1', [instanceId]);
  await pg.query('DELETE FROM "Instance" WHERE "id" = $1', [instanceId]);
  /* explicit fallbacks — no-ops when the FK cascade already fired */
  for (const table of ["SiteOrder", "SiteCustomer", "ModuleRecord", "Activity", "TeamMember", "Site"]) {
    await pg.query(`DELETE FROM "${table}" WHERE "instanceId" = $1`, [instanceId]);
  }
}

/** the full cleanup: outbox .eml + this run's rows + rate keys. Lenient by
 *  default (the legacy afterAll contract: leftovers are logged, never
 *  fatal); strict mode (the cleanup phase) FAILS on leftovers + errors. */
async function cleanupRun(strict = false): Promise<void> {
  try {
    /* 1) outbox .eml files this run's registrations induced */
    if (existsSync(DEV_OUTBOX)) {
      for (const file of readdirSync(DEV_OUTBOX)) {
        if (!file.endsWith(".eml")) continue;
        try {
          const content = readFileSync(join(DEV_OUTBOX, file), "utf8");
          if (content.includes(CUST_A_EMAIL) || content.includes(CUST_B_EMAIL)) {
            unlinkSync(join(DEV_OUTBOX, file));
          }
        } catch {
          /* raced away — nothing to remove */
        }
      }
    }

    /* 2) dev-DB rows (AuditLog is APPEND-ONLY — deliberately untouched) */
    const { blindIndex } = await import("@/lib/server/crypto-vault");
    const pg = await serverPg();
    try {
      if (A) await deleteInstanceRows(pg, A);
      if (B) await deleteInstanceRows(pg, B);

      /* 3) rate-limit keys: this run's identities */
      await purgeRunRateKeys(pg, blindIndex);

      /* leftover verification — must be pristine */
      for (const table of [...COUNTABLE_TABLES]) {
        const inList = table === "Instance" ? "id" : "instanceId";
        const result = await pg.query<{ c: number }>(
          `SELECT COUNT(*)::int AS c FROM "${table}" WHERE "${inList}" IN ($1, $2)`,
          [A || "_none_", B || "_none_"]
        );
        const left = result.rows[0]?.c ?? 0;
        if (left > 0) {
          const message = `[tenant-isolation] live cleanup leftover in ${table}: ${left}`;
          if (strict) throw new Error(message);
          console.error(message);
        }
      }
    } finally {
      await closeServerPg();
    }
  } catch (error) {
    if (strict) throw error;
    console.error("[tenant-isolation] live cleanup failed:", error);
  }
}

/** rate-key-only cleanup for slice processes — rows persist for the rejoin
 *  slices; the cleanup phase (TENANT_ISOLATION_SLICE=99) owns deletion. */
async function purgeRunKeysOnly(): Promise<void> {
  try {
    const { blindIndex } = await import("@/lib/server/crypto-vault");
    const pg = await serverPg();
    try {
      await purgeRunRateKeys(pg, blindIndex);
    } finally {
      await closeServerPg();
    }
  } catch (error) {
    console.error("[tenant-isolation] slice rate-key cleanup failed:", error);
  }
}

/* ====================================================================== */
/* PART B–E — LIVE DEV SERVER (:3000, dev DB)                              */
/* ====================================================================== */
const live = await serverReachable();
const maybeDescribe = live ? describe : describe.skip;
if (!live) {
  console.log(
    "[tenant-isolation] dev server not reachable on :3000 — skipping the live suite (CI never fails for a down server)"
  );
}

/* sliced mode: an explicit reachability gate OUTSIDE the maybeDescribe skip
 * path — a down server must FAIL this slice loudly (the battery then
 * classifies it INFRA via the server-down probe), never silently "pass" on
 * an empty registration */
if (SLICE >= 1 && SLICE <= SLICE_COUNT) {
  test(`slice ${SLICE}: dev server reachable on :3000`, async () => {
    if (!(await serverReachable())) {
      throw new Error(
        `[tenant-isolation] slice ${SLICE} requires the dev server on :3000 — start it (bash .zscripts/dev.sh) or run via .zscripts/test-battery.sh`
      );
    }
  });
}

maybeDescribe("tenant isolation — live dev server (:3000)", () => {
  const jarA = new CookieJar();
  const jarB = new CookieJar();
  const jarCustA = new CookieJar();
  const jarCustB = new CookieJar();

  /* A/B/recordAId/… live at module scope (see the shared-state block above) */

  const JSON_HEADERS = { "content-type": "application/json", origin: BASE };

  /* ---------------- sliced mode: REJOIN slice 1's tenants ----------------
   * slices 2+ run in a FRESH process against slice 1's persisted rows:
   * resolve both instances by blind index, mint fresh owner sessions, and
   * re-derive every seeded row id (all markers are RUN-unique). */
  if (SLICE >= 2 && SLICE <= SLICE_COUNT) {
    beforeAll(async () => {
      const { blindIndex } = await import("@/lib/server/crypto-vault");
      A =
        (
          await devOne<{ id: string }>(
            'SELECT "id" FROM "Instance" WHERE "adminEmailIndex" = $1',
            blindIndex(EMAIL_A) as string
          )
        )?.id ?? "";
      B =
        (
          await devOne<{ id: string }>(
            'SELECT "id" FROM "Instance" WHERE "adminEmailIndex" = $1',
            blindIndex(EMAIL_B) as string
          )
        )?.id ?? "";
      if (!A || !B) {
        throw new Error(
          `[tenant-isolation] slice ${SLICE} cannot rejoin run ${RUN} — slice 1 (provisioning) must pass first`
        );
      }

      /* fresh owner sessions (login is the only session-minting path) */
      for (const [email, jar] of [
        [EMAIL_A, jarA],
        [EMAIL_B, jarB],
      ] as const) {
        const res = await jfetch("/api/instances/auth/login", {
          method: "POST",
          headers: JSON_HEADERS,
          body: JSON.stringify({ email, password: OWNER_PASSWORD }),
        });
        if (res.status !== 200) {
          throw new Error(`[tenant-isolation] slice ${SLICE} rejoin login failed (${email}): ${res.status}`);
        }
        jar.setFrom(res);
      }

      /* re-derive the seeded row ids (every marker is RUN-unique) */
      recordAId =
        (
          await devOne<{ id: string }>(
            'SELECT "id" FROM "ModuleRecord" WHERE "instanceId" = $1 AND "dataJson" LIKE $2',
            A,
            `%${PROD_A}%`
          )
        )?.id ?? "";
      recordBId =
        (
          await devOne<{ id: string }>(
            'SELECT "id" FROM "ModuleRecord" WHERE "instanceId" = $1 AND "dataJson" LIKE $2',
            B,
            `%${PROD_B}%`
          )
        )?.id ?? "";
      memberIdB =
        (
          await devOne<{ id: string }>(
            'SELECT "id" FROM "TeamMember" WHERE "instanceId" = $1 AND "name" = $2',
            B,
            MEMBER_B_NAME
          )
        )?.id ?? "";
      orderIdA =
        (
          await devOne<{ id: string }>(
            'SELECT "id" FROM "SiteOrder" WHERE "instanceId" = $1 ORDER BY "createdAt" ASC LIMIT 1',
            A
          )
        )?.id ?? "";
      orderIdB =
        (
          await devOne<{ id: string }>(
            'SELECT "id" FROM "SiteOrder" WHERE "instanceId" = $1 ORDER BY "createdAt" ASC LIMIT 1',
            B
          )
        )?.id ?? "";
      custAId =
        (
          await devOne<{ id: string }>(
            'SELECT "id" FROM "SiteCustomer" WHERE "instanceId" = $1 AND "emailIndex" = $2',
            A,
            blindIndex(CUST_A_EMAIL) as string
          )
        )?.id ?? "";
      custBId =
        (
          await devOne<{ id: string }>(
            'SELECT "id" FROM "SiteCustomer" WHERE "instanceId" = $1 AND "emailIndex" = $2',
            B,
            blindIndex(CUST_B_EMAIL) as string
          )
        )?.id ?? "";
      for (const [label, value] of [
        ["A", A],
        ["B", B],
        ["recordAId", recordAId],
        ["recordBId", recordBId],
        ["memberIdB", memberIdB],
        ["orderIdA", orderIdA],
        ["orderIdB", orderIdB],
        ["custAId", custAId],
        ["custBId", custBId],
      ] as const) {
        if (!value) {
          throw new Error(`[tenant-isolation] slice ${SLICE} rejoin could not re-derive ${label} for run ${RUN}`);
        }
      }
    }, 60_000);
  }

  /* ------------------------------ seed -------------------------------- */

  liveTest(PROVISION, "provision tenant A through the real API → 201 + owner session cookie", async () => {
    const res = await jfetch("/api/instances", {
      method: "POST",
      headers: JSON_HEADERS,
      body: JSON.stringify(instancePayload(ORG_A, EMAIL_A, "مالك ألف")),
    });
    expect(res.status).toBe(201);
    const body = (await res.json()) as { id?: string; org?: { name?: string }; demo?: boolean };
    expect(body.id).toBeTruthy();
    expect(body.org?.name).toBe(ORG_A);
    expect(body.demo).toBe(false);
    A = body.id as string;
    jarA.setFrom(res); // provisioning signs the owner in immediately
    expect(jarA.header()).toContain("ashrilogic-instance-session=");
  });

  liveTest(PROVISION, "provision tenant B through the real API → 201 + owner session cookie", async () => {
    const res = await jfetch("/api/instances", {
      method: "POST",
      headers: JSON_HEADERS,
      body: JSON.stringify(instancePayload(ORG_B, EMAIL_B, "مالك باء")),
    });
    expect(res.status).toBe(201);
    const body = (await res.json()) as { id?: string; org?: { name?: string } };
    expect(body.id).toBeTruthy();
    expect(body.org?.name).toBe(ORG_B);
    B = body.id as string;
    expect(B).not.toBe(A);
    jarB.setFrom(res);
    expect(jarB.header()).toContain("ashrilogic-instance-session=");
  });

  liveTest(PROVISION, "workspace login as A's owner (blind-index resolution) → 200 + fresh session cookie", async () => {
    const res = await jfetch("/api/instances/auth/login", {
      method: "POST",
      headers: JSON_HEADERS,
      body: JSON.stringify({ email: EMAIL_A, password: OWNER_PASSWORD }),
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as { ok?: boolean; owned?: number; instance?: { id?: string } };
    expect(body.ok).toBe(true);
    expect(body.instance?.id).toBe(A);
    expect(body.owned).toBe(1); // A's email owns exactly one workspace: A
    jarA.setFrom(res);
    expect(jarA.header()).toContain("ashrilogic-instance-session=");
  });

  liveTest(PROVISION, "workspace login as B's owner → 200 + fresh session cookie", async () => {
    const res = await jfetch("/api/instances/auth/login", {
      method: "POST",
      headers: JSON_HEADERS,
      body: JSON.stringify({ email: EMAIL_B, password: OWNER_PASSWORD }),
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as { ok?: boolean; owned?: number; instance?: { id?: string } };
    expect(body.ok).toBe(true);
    expect(body.instance?.id).toBe(B);
    jarB.setFrom(res);
  });

  liveTest(PROVISION, "A publishes its website with distinctive content (draft GET → launch PUT)", async () => {
    const draft = await jfetch(`/api/instances/${A}/site`, { jar: jarA });
    expect(draft.status).toBe(200);
    expect(((await draft.json()) as { published?: boolean }).published).toBe(false);

    const res = await jfetch(`/api/instances/${A}/site`, {
      method: "PUT",
      jar: jarA,
      headers: JSON_HEADERS,
      body: JSON.stringify({
        published: true,
        content: siteContentPayload(ORG_A, `contact-a-${RUN}@example.com`),
      }),
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as { published?: boolean; content?: { heroTitle?: string } };
    expect(body.published).toBe(true);
    expect(body.content?.heroTitle).toBe(ORG_A);
  });

  liveTest(PROVISION, "B publishes its website with distinctive content", async () => {
    const draft = await jfetch(`/api/instances/${B}/site`, { jar: jarB });
    expect(draft.status).toBe(200);

    const res = await jfetch(`/api/instances/${B}/site`, {
      method: "PUT",
      jar: jarB,
      headers: JSON_HEADERS,
      body: JSON.stringify({
        published: true,
        content: siteContentPayload(ORG_B, `contact-b-${RUN}@example.com`),
      }),
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as { published?: boolean; content?: { heroTitle?: string } };
    expect(body.published).toBe(true);
    expect(body.content?.heroTitle).toBe(ORG_B);
  });

  liveTest(PROVISION, "A seeds its workspace: pharmacy product + team member + activity", async () => {
    const rec = await jfetch(`/api/instances/${A}/module-records`, {
      method: "POST",
      jar: jarA,
      headers: JSON_HEADERS,
      body: JSON.stringify(pharmacyProductPayload(PROD_A)),
    });
    expect(rec.status).toBe(201);
    recordAId = ((await rec.json()) as { id?: string }).id ?? "";
    expect(recordAId).toBeTruthy();

    const member = await jfetch(`/api/instances/${A}/members`, {
      method: "POST",
      jar: jarA,
      headers: JSON_HEADERS,
      body: JSON.stringify({ name: MEMBER_A_NAME, email: MEMBER_A_EMAIL, role: "staff" }),
    });
    expect(member.status).toBe(201);

    const activity = await jfetch(`/api/instances/${A}/activities`, {
      method: "POST",
      jar: jarA,
      headers: JSON_HEADERS,
      body: JSON.stringify({ kind: "actDataImported", meta: { source: "isolation-seed" } }),
    });
    expect(activity.status).toBe(201);
  });

  liveTest(PROVISION, "B seeds its workspace: pharmacy product + team member", async () => {
    const rec = await jfetch(`/api/instances/${B}/module-records`, {
      method: "POST",
      jar: jarB,
      headers: JSON_HEADERS,
      body: JSON.stringify(pharmacyProductPayload(PROD_B)),
    });
    expect(rec.status).toBe(201);
    recordBId = ((await rec.json()) as { id?: string }).id ?? "";
    expect(recordBId).toBeTruthy();

    const member = await jfetch(`/api/instances/${B}/members`, {
      method: "POST",
      jar: jarB,
      headers: JSON_HEADERS,
      body: JSON.stringify({ name: MEMBER_B_NAME, email: MEMBER_B_EMAIL, role: "staff" }),
    });
    expect(member.status).toBe(201);
    memberIdB = ((await member.json()) as { id?: string }).id ?? "";
    expect(memberIdB).toBeTruthy();
  });

  liveTest(PROVISION, "guest checkout on A's public site → 201; find-or-created sealed contact row; NO session cookie (member login removed)", async () => {
    const order = await jfetch(`/api/sites/${A}/orders`, {
      method: "POST",
      headers: JSON_HEADERS,
      body: JSON.stringify({
        items: [{ recordId: recordAId, qty: 2 }],
        note: "أمر عزل ألف",
        customer: { name: CUST_A_NAME, email: CUST_A_EMAIL, phone: CUST_A_PHONE },
      }),
    });
    expect(order.status).toBe(201);
    const body = (await order.json()) as { id?: string; total?: number; status?: string };
    orderIdA = body.id ?? "";
    expect(orderIdA).toBeTruthy();
    expect(body.status).toBe("pending");
    expect(body.total).toBe(25); // 12.50 × 2 — server-derived price

    /* ROUND 44 — the member-login process is GONE: no customer session
       cookie is EVER set by the storefront (guest checkout only) */
    jarCustA.setFrom(order);
    expect(jarCustA.header()).not.toContain("ashrilogic-site-customer=");

    /* find-or-create: the contact row resolved under A's blind index with a
       sealed email + an ACCOUNT-LESS row — ROUND 120 replaced the former
       random Argon2id credential with passwordHash NULL (the random secret
       was unusable by design: guests never log in, and burning a full KDF
       per checkout was pure event-loop cost; checkCustomerPassword fails
       CLOSED on null, and the register upgrade path sets the real hash) */
    const { blindIndex, decryptField } = await import("@/lib/server/crypto-vault");
    const row = await devOne<{ id: string; email: string; passwordHash: string | null }>(
      'SELECT "id", "email", "passwordHash" FROM "SiteCustomer" WHERE "instanceId" = $1 AND "emailIndex" = $2',
      A,
      blindIndex(CUST_A_EMAIL) as string
    );
    expect(row).not.toBeNull();
    custAId = row?.id ?? "";
    expect(decryptField(row!.email)).toBe(CUST_A_EMAIL);
    expect(row!.passwordHash).toBeNull();
  });

  liveTest(PROVISION, "guest checkout on B's public site → 201; B gets its own contact row", async () => {
    const order = await jfetch(`/api/sites/${B}/orders`, {
      method: "POST",
      headers: JSON_HEADERS,
      body: JSON.stringify({
        items: [{ recordId: recordBId, qty: 1 }],
        customer: { name: CUST_B_NAME, email: CUST_B_EMAIL, phone: CUST_B_PHONE },
      }),
    });
    expect(order.status).toBe(201);
    orderIdB = ((await order.json()) as { id?: string }).id ?? "";
    expect(orderIdB).toBeTruthy();
    expect(orderIdB).not.toBe(orderIdA);

    /* no session cookie here either */
    jarCustB.setFrom(order);
    expect(jarCustB.header()).not.toContain("ashrilogic-site-customer=");

    const { blindIndex } = await import("@/lib/server/crypto-vault");
    const row = await devOne<{ id: string }>(
      'SELECT "id" FROM "SiteCustomer" WHERE "instanceId" = $1 AND "emailIndex" = $2',
      B,
      blindIndex(CUST_B_EMAIL) as string
    );
    expect(row).not.toBeNull();
    custBId = row?.id ?? "";
  });

  liveTest(PROVISION, "guest dedupe: a second order with the same email REUSES the contact row (no duplicates)", async () => {
    const before = await devCount("SiteCustomer", A);
    const again = await jfetch(`/api/sites/${A}/orders`, {
      method: "POST",
      headers: JSON_HEADERS,
      body: JSON.stringify({
        items: [{ recordId: recordAId, qty: 1 }],
        customer: { name: CUST_A_NAME, email: CUST_A_EMAIL },
      }),
    });
    expect(again.status).toBe(201);
    /* same [instanceId, emailIndex] → the existing row was reused */
    expect(await devCount("SiteCustomer", A)).toBe(before);
  });

  /* --------------------- positive reads (own data) --------------------- */

  liveTest(2, "owner A reads every surface → 200 with A's data and ZERO B data", async () => {
    const inst = await jfetch(`/api/instances/${A}`, { jar: jarA });
    expect(inst.status).toBe(200);
    const instBody = (await inst.json()) as { instance?: { org?: { name?: string } } };
    expect(instBody.instance?.org?.name).toBe(ORG_A);
    expect(JSON.stringify(instBody)).not.toContain(ORG_B);

    const recs = await jfetch(`/api/instances/${A}/module-records?moduleId=pharmacy`, { jar: jarA });
    expect(recs.status).toBe(200);
    const recsBody = (await recs.json()) as { records?: { id?: string; values?: string[] }[] };
    expect(recsBody.records?.length).toBeGreaterThanOrEqual(1);
    expect(recsBody.records?.some((r) => r.id === recordAId)).toBe(true);
    const recsText = JSON.stringify(recsBody);
    expect(recsText).toContain(PROD_A);
    expect(recsText).not.toContain(PROD_B);
    expect(recsText).not.toContain(recordBId);

    const orders = await jfetch(`/api/instances/${A}/orders`, { jar: jarA });
    expect(orders.status).toBe(200);
    const ordersBody = (await orders.json()) as {
      orders?: { id?: string; customerName?: string; status?: string }[];
    };
    expect(ordersBody.orders?.some((o) => o.id === orderIdA)).toBe(true);
    expect(ordersBody.orders?.some((o) => o.customerName === CUST_A_NAME)).toBe(true);
    const ordersText = JSON.stringify(ordersBody);
    expect(ordersText).not.toContain(orderIdB);
    expect(ordersText).not.toContain(CUST_B_NAME);
    expect(ordersText).not.toContain(CUST_B_EMAIL);

    const site = await jfetch(`/api/instances/${A}/site`, { jar: jarA });
    expect(site.status).toBe(200);
    const siteBody = (await site.json()) as { content?: { heroTitle?: string }; published?: boolean };
    expect(siteBody.content?.heroTitle).toBe(ORG_A);
    expect(siteBody.published).toBe(true);

    const members = await jfetch(`/api/instances/${A}/members`, { jar: jarA });
    expect(members.status).toBe(200);
    const membersBody = (await members.json()) as { name?: string; email?: string }[];
    expect(membersBody.some((m) => m.name === MEMBER_A_NAME && m.email === MEMBER_A_EMAIL)).toBe(true);
    expect(JSON.stringify(membersBody)).not.toContain(MEMBER_B_NAME);
    expect(JSON.stringify(membersBody)).not.toContain(MEMBER_B_EMAIL);

    /* activities: every returned row id must belong to A's instance ONLY
       (ROUND 57 — the feed is paginated: {activities, nextCursor, total}) */
    const acts = await jfetch(`/api/instances/${A}/activities?limit=100`, { jar: jarA });
    expect(acts.status).toBe(200);
    const actsBody = (await acts.json()) as { activities?: { id?: string }[]; nextCursor?: string | null };
    expect((actsBody.activities ?? []).length).toBeGreaterThanOrEqual(1);
    const aIds = new Set(
      (
        await devOne<{ ids: string | null }>(
          `SELECT string_agg("id", ',') AS ids FROM "Activity" WHERE "instanceId" = $1`,
          A
        )
      )?.ids?.split(",") ?? []
    );
    const bIds = new Set(
      (
        await devOne<{ ids: string | null }>(
          `SELECT string_agg("id", ',') AS ids FROM "Activity" WHERE "instanceId" = $1`,
          B
        )
      )?.ids?.split(",") ?? []
    );
    for (const row of actsBody.activities ?? []) {
      expect(aIds.has(row.id as string)).toBe(true);
      expect(bIds.has(row.id as string)).toBe(false);
    }
  });

  liveTest(2, "owner B reads every surface → 200 with B's data and ZERO A data", async () => {
    const inst = await jfetch(`/api/instances/${B}`, { jar: jarB });
    expect(inst.status).toBe(200);
    const instBody = (await inst.json()) as { instance?: { org?: { name?: string } } };
    expect(instBody.instance?.org?.name).toBe(ORG_B);

    const recs = await jfetch(`/api/instances/${B}/module-records?moduleId=pharmacy`, { jar: jarB });
    expect(recs.status).toBe(200);
    const recsText = JSON.stringify(await recs.json());
    expect(recsText).toContain(PROD_B);
    expect(recsText).not.toContain(PROD_A);

    const orders = await jfetch(`/api/instances/${B}/orders`, { jar: jarB });
    expect(orders.status).toBe(200);
    const ordersText = JSON.stringify(await orders.json());
    expect(ordersText).toContain(orderIdB);
    expect(ordersText).not.toContain(orderIdA);
    expect(ordersText).not.toContain(CUST_A_NAME);

    const members = await jfetch(`/api/instances/${B}/members`, { jar: jarB });
    expect(members.status).toBe(200);
    const membersText = JSON.stringify(await members.json());
    expect(membersText).toContain(MEMBER_B_NAME);
    expect(membersText).not.toContain(MEMBER_A_NAME);

    const acts = await jfetch(`/api/instances/${B}/activities?limit=100`, { jar: jarB });
    expect(acts.status).toBe(200);
    const actsBody = (await acts.json()) as { activities?: { id?: string }[] };
    const bIds = new Set(
      (
        await devOne<{ ids: string | null }>(
          `SELECT string_agg("id", ',') AS ids FROM "Activity" WHERE "instanceId" = $1`,
          B
        )
      )?.ids?.split(",") ?? []
    );
    for (const row of actsBody.activities ?? []) {
      expect(bIds.has(row.id as string)).toBe(true);
    }
  });

  /* -------------------- THE CRITICAL cross-tenant -------------------- */

  /* ROUND 105 — the original single 8-surface test spanned 9 route files
   * (OOM death mid-compile on this sandbox); split into two halves across
   * slices 3-4, same assertions per path. Combined coverage is identical. */
  const expectCrossTenantReadRejected = async (paths: string[]) => {
    for (const path of paths) {
      const res = await jfetch(path, { jar: jarA });
      expect([401, 403]).toContain(res.status);
      expect(res.status).not.toBe(200);
      const text = await res.text();
      expect(text).not.toContain(ORG_B);
      expect(text).not.toContain(PROD_B);
      expect(text).not.toContain(orderIdB);
      expect(text).not.toContain(CUST_B_EMAIL);
      expect(text).not.toContain(MEMBER_B_EMAIL);
    }
  };

  liveTest(3, "CROSS-TENANT reads (core surfaces): A's owner cookie on B's instance routes → 401 everywhere, never B data", async () => {
    await expectCrossTenantReadRejected([
      `/api/instances/${B}`,
      `/api/instances/${B}/module-records?moduleId=pharmacy`,
      `/api/instances/${B}/orders`,
      `/api/instances/${B}/site`,
    ]);
  });

  liveTest(4, "CROSS-TENANT reads (people + export): A's owner cookie on B's instance routes → 401 everywhere, never B data", async () => {
    await expectCrossTenantReadRejected([
      `/api/instances/${B}/site/customers`,
      `/api/instances/${B}/members`,
      `/api/instances/${B}/activities?limit=50`,
      `/api/instances/${B}/export?type=summary&format=json`,
    ]);
  });

  /* ROUND 105 — the original single 10-attempt test spanned 9 route files
   * and OOM-killed the server mid-attack (the [customerId] compile was the
   * measured death point). Split into two halves across slices 3-4; every
   * attempt is REJECTED (401/403) so the DB state is unchanged between the
   * halves — each half captures its own "before" and runs the FULL
   * byte-identical verification. Combined coverage = the original test. */
  const crossTenantBefore = async () => ({
    records: await devCount("ModuleRecord", B),
    members: await devCount("TeamMember", B),
    activities: await devCount("Activity", B),
    site: await devOne<{ published: boolean; contentJson: string }>(
      'SELECT "published", "contentJson" FROM "Site" WHERE "instanceId" = $1',
      B
    ),
    order: await devOne<{ status: string }>('SELECT "status" FROM "SiteOrder" WHERE "id" = $1', orderIdB),
    customer: await devOne<{ status: string }>('SELECT "status" FROM "SiteCustomer" WHERE "id" = $1', custBId),
    memberRow: await devOne<{ id: string }>('SELECT "id" FROM "TeamMember" WHERE "id" = $1', memberIdB),
    recordRow: await devOne<{ id: string }>('SELECT "id" FROM "ModuleRecord" WHERE "id" = $1', recordBId),
  });
  const expectCrossTenantPreconditions = (before: Awaited<ReturnType<typeof crossTenantBefore>>) => {
    expect(before.site?.published).toBe(true);
    expect(before.order?.status).toBe("pending");
    expect(before.customer?.status).toBe("active");
  };
  const expectAllRejected = async (attempts: { path: string; method: string; body?: string }[]) => {
    for (const attempt of attempts) {
      const res = await jfetch(attempt.path, {
        method: attempt.method,
        jar: jarA,
        headers: JSON_HEADERS,
        body: attempt.body,
      });
      expect([401, 403]).toContain(res.status);
      expect(res.status).not.toBe(200);
      expect(await res.text()).not.toContain(ORG_B);
    }
  };
  /* B's rows are untouched — no phantom writes, no status flips */
  const expectBTenantUntouched = async (before: Awaited<ReturnType<typeof crossTenantBefore>>) => {
    expect(await devCount("ModuleRecord", B)).toBe(before.records);
    expect(await devCount("TeamMember", B)).toBe(before.members);
    expect(await devCount("Activity", B)).toBe(before.activities);
    const afterSite = await devOne<{ published: boolean; contentJson: string }>(
      'SELECT "published", "contentJson" FROM "Site" WHERE "instanceId" = $1',
      B
    );
    expect(afterSite?.published).toBe(true);
    expect(afterSite?.contentJson).toBe(before.site?.contentJson);
    expect(
      (await devOne<{ status: string }>('SELECT "status" FROM "SiteOrder" WHERE "id" = $1', orderIdB))?.status
    ).toBe("pending");
    expect(
      (await devOne<{ status: string }>('SELECT "status" FROM "SiteCustomer" WHERE "id" = $1', custBId))?.status
    ).toBe("active");
    expect(await devOne<{ id: string }>('SELECT "id" FROM "TeamMember" WHERE "id" = $1', memberIdB)).not.toBeNull();
    expect(await devOne<{ id: string }>('SELECT "id" FROM "ModuleRecord" WHERE "id" = $1', recordBId)).not.toBeNull();
  };

  liveTest(6, "CROSS-TENANT mutations (collections): A's owner cookie on B's write routes → 401; B's rows byte-identical", async () => {
    const before = await crossTenantBefore();
    expectCrossTenantPreconditions(before);

    await expectAllRejected([
      {
        path: `/api/instances/${B}/module-records`,
        method: "POST",
        body: JSON.stringify(pharmacyProductPayload("InfiltratorProbe")),
      },
      {
        path: `/api/instances/${B}/members`,
        method: "POST",
        body: JSON.stringify({ name: "متسلل", email: `infiltrator-${RUN}@example.com`, role: "staff" }),
      },
      {
        path: `/api/instances/${B}/activities`,
        method: "POST",
        body: JSON.stringify({ kind: "actDataImported", meta: { source: "cross-tenant" } }),
      },
      {
        path: `/api/instances/${B}/tickets`,
        method: "POST",
        body: JSON.stringify({
          packageId: "probe-package",
          subject: "محاولة عابرة للمستأجرين",
          message: "رسالة اختبار العزل عبر المستأجرين",
        }),
      },
      { path: `/api/instances/${B}/site`, method: "PUT", body: JSON.stringify({ published: false }) },
    ]);

    await expectBTenantUntouched(before);
  });

  liveTest(7, "CROSS-TENANT mutations (sub-resources): A's owner cookie on B's PATCH/DELETE routes → 401; B's rows byte-identical", async () => {
    const before = await crossTenantBefore();
    expectCrossTenantPreconditions(before);

    await expectAllRejected([
      {
        path: `/api/instances/${B}/site/customers/${custBId}`,
        method: "PATCH",
        body: JSON.stringify({ status: "banned" }),
      },
      {
        path: `/api/instances/${B}/orders/${orderIdB}`,
        method: "PATCH",
        body: JSON.stringify({ status: "cancelled" }),
      },
      { path: `/api/instances/${B}/members/${memberIdB}`, method: "DELETE" },
      { path: `/api/instances/${B}/module-records/${recordBId}`, method: "DELETE" },
      {
        path: `/api/instances/${B}/module-records/${recordBId}`,
        method: "PATCH",
        body: JSON.stringify({ statusKey: "out" }),
      },
    ]);

    await expectBTenantUntouched(before);
  });

  liveTest(3, "cross-tenant mirror: B's owner cookie on A's routes → 401 (symmetry)", async () => {
    for (const path of [
      `/api/instances/${A}`,
      `/api/instances/${A}/orders`,
      `/api/instances/${A}/site/customers`,
      `/api/instances/${A}/module-records?moduleId=pharmacy`,
      `/api/instances/${A}/export?type=summary&format=json`,
    ]) {
      const res = await jfetch(path, { jar: jarB });
      expect([401, 403]).toContain(res.status);
      expect(res.status).not.toBe(200);
      expect(await res.text()).not.toContain(ORG_A);
    }

    const recordsBefore = await devCount("ModuleRecord", A);
    const res = await jfetch(`/api/instances/${A}/module-records`, {
      method: "POST",
      jar: jarB,
      headers: JSON_HEADERS,
      body: JSON.stringify(pharmacyProductPayload("ReverseProbe")),
    });
    expect(res.status).toBe(401);
    expect(await devCount("ModuleRecord", A)).toBe(recordsBefore);
  });

  /* ROUND 105 — split like the cross-tenant reads above (9 route files in
   * one lifetime OOM-killed the server); same assertions per path. */
  liveTest(5, "anonymous (no cookie): core instance surfaces → 401", async () => {
    for (const path of [
      `/api/instances/${B}`,
      `/api/instances/${B}/module-records?moduleId=pharmacy`,
      `/api/instances/${B}/orders`,
      `/api/instances/${B}/site`,
    ]) {
      const res = await jfetch(path, { publicBody: true });
      expect(res.status).toBe(401);
      expect(await res.text()).not.toContain(ORG_B);
    }
  });

  liveTest(4, "anonymous (no cookie): people surfaces + export → 401; anonymous mutations rejected", async () => {
    for (const path of [
      `/api/instances/${B}/site/customers`,
      `/api/instances/${B}/members`,
      `/api/instances/${B}/activities?limit=50`,
      `/api/instances/${B}/export?type=summary&format=json`,
    ]) {
      const res = await jfetch(path, { publicBody: true });
      expect(res.status).toBe(401);
      expect(await res.text()).not.toContain(ORG_B);
    }

    /* a valid mutation with Origin but NO cookie is still unauthorized */
    const post = await jfetch(`/api/instances/${B}/module-records`, {
      method: "POST",
      headers: JSON_HEADERS,
      body: JSON.stringify(pharmacyProductPayload("AnonymousProbe")),
      publicBody: true,
    });
    expect(post.status).toBe(401);

    /* ROUND 44 — storefront checkout is GUEST checkout (public by design):
       an order WITHOUT guest contact details is rejected with a clean 400 —
       never a 500, and B's data never leaks. */
    const orderNoContact = await jfetch(`/api/sites/${B}/orders`, {
      method: "POST",
      headers: JSON_HEADERS,
      body: JSON.stringify({ items: [{ recordId: recordBId, qty: 1 }] }),
      publicBody: true,
    });
    expect(orderNoContact.status).toBe(400);
    expect(await orderNoContact.text()).not.toContain(ORG_B);
  });

  /* ----------------------------- PII ----------------------------- */

  /* slice 5 — MUST run before L20 (guest-era cross-site): L18 asserts B's
   * customer list does NOT contain A's email yet; L20's cross-site checkout
   * on B legitimately adds it afterward (the original suite's order). */
  liveTest(5, "PII scoping: each owner sees ONLY its own site customers; admin surfaces refuse instance/customer cookies", async () => {
    const listA = await jfetch(`/api/instances/${A}/site/customers`, { jar: jarA });
    expect(listA.status).toBe(200);
    const textA = await listA.text();
    expect(textA).toContain(CUST_A_EMAIL);
    expect(textA).toContain(CUST_A_PHONE); // owner's own tenant PII — allowed
    expect(textA).not.toContain(CUST_B_EMAIL);
    expect(textA).not.toContain(CUST_B_PHONE);

    const listB = await jfetch(`/api/instances/${B}/site/customers`, { jar: jarB });
    expect(listB.status).toBe(200);
    const textB = await listB.text();
    expect(textB).toContain(CUST_B_EMAIL);
    expect(textB).not.toContain(CUST_A_EMAIL);
    expect(textB).not.toContain(CUST_A_PHONE);

    /* admin-only surfaces: instance cookies are NOT admin sessions (customer
       sessions no longer exist — the jar is cookieless by construction) */
    for (const [label, jar] of [
      ["instance cookie", jarA] as const,
      ["cookieless (customer sessions removed)", jarCustA] as const,
    ]) {
      const sites = await jfetch("/api/admin/sites", { jar });
      expect(sites.status).toBe(401);
      const sitesText = await sites.text();
      expect(sitesText).not.toContain(ORG_A);
      expect(sitesText).not.toContain(ORG_B);
      const audit = await jfetch("/api/admin/audit", { jar });
      expect(audit.status).toBe(401);
      void label;
    }

    /* signed-in directory: the owner's own workspaces ONLY (no other tenant) */
    const directory = await jfetch("/api/instances", { jar: jarA });
    expect(directory.status).toBe(200);
    const rows = (await directory.json()) as { id?: string; admin?: { email?: string } }[];
    expect(Array.isArray(rows)).toBe(true);
    expect(rows.some((r) => r.id === A)).toBe(true);
    expect(rows.some((r) => r.id === B)).toBe(false);
    for (const row of rows) {
      expect(row.admin?.email).toBe(EMAIL_A); // never another tenant's identity
    }
  });

  /* ------------------------ public site routes ------------------------ */

  liveTest(9, "public storefronts + rendered pages are tenant-scoped; anonymous /me → 401", async () => {
    const storeA = await jfetch(`/api/sites/${A}/store`, { publicBody: true });
    expect(storeA.status).toBe(200);
    const storeAText = await storeA.text();
    expect(storeAText).toContain(PROD_A);
    expect(storeAText).not.toContain(PROD_B);
    expect(storeAText).not.toContain(recordBId);

    const storeB = await jfetch(`/api/sites/${B}/store`, { publicBody: true });
    expect(storeB.status).toBe(200);
    const storeBText = await storeB.text();
    expect(storeBText).toContain(PROD_B);
    expect(storeBText).not.toContain(PROD_A);

    /* the rendered public site pages (server components) */
    const pageA = await jfetch(`/sites/${A}`, { publicBody: true });
    expect(pageA.status).toBe(200);
    const pageAText = await pageA.text();
    expect(pageAText).toContain(ORG_A);
    expect(pageAText).not.toContain(ORG_B);

    const pageB = await jfetch(`/sites/${B}`, { publicBody: true });
    expect(pageB.status).toBe(200);
    const pageBText = await pageB.text();
    expect(pageBText).toContain(ORG_B);
    expect(pageBText).not.toContain(ORG_A);

    /* ROUND 44 — the member-login process was removed: the customer auth
       endpoints no longer exist (404), and no customer PII is exposed */
    const me = await jfetch(`/api/sites/${A}/customers/me`, { publicBody: true });
    expect(me.status).toBe(404);
    expect(await me.text()).not.toContain(CUST_A_EMAIL);

    const loginGone = await jfetch(`/api/sites/${A}/customers/login`, {
      method: "POST",
      headers: JSON_HEADERS,
      body: JSON.stringify({ email: CUST_A_EMAIL, password: CUST_PASSWORD }),
      publicBody: true,
    });
    expect(loginGone.status).toBe(404);
    const registerGone = await jfetch(`/api/sites/${A}/customers`, {
      method: "POST",
      headers: JSON_HEADERS,
      body: JSON.stringify({ name: CUST_A_NAME, email: `x-${RUN}@example.com`, password: CUST_PASSWORD }),
      publicBody: true,
    });
    expect(registerGone.status).toBe(404);
  });

  /* --------------------- guest-era cross-site --------------------- */

  liveTest(8, "guest-era cross-site: same email on B creates B's OWN contact row; A's rows untouched (tenant-scoped dedupe)", async () => {
    const aRowsBefore = await devCount("SiteCustomer", A);
    const aOrdersBefore = await devCount("SiteOrder", A);

    /* guest checkout on B with A's contact email — public by design, but the
       contact row lands under B's OWN [instanceId, emailIndex] scope */
    const cross = await jfetch(`/api/sites/${B}/orders`, {
      method: "POST",
      headers: JSON_HEADERS,
      body: JSON.stringify({
        items: [{ recordId: recordBId, qty: 1 }],
        customer: { name: "عميل ألف على موقع باء", email: CUST_A_EMAIL },
      }),
      publicBody: true,
    });
    expect(cross.status).toBe(201);

    const { blindIndex } = await import("@/lib/server/crypto-vault");
    const underB = await devOne<{ id: string }>(
      'SELECT "id" FROM "SiteCustomer" WHERE "instanceId" = $1 AND "emailIndex" = $2',
      B,
      blindIndex(CUST_A_EMAIL) as string
    );
    expect(underB).not.toBeNull();
    expect(underB!.id).not.toBe(custAId); // a SEPARATE row — never A's
    expect(await devCount("SiteCustomer", A)).toBe(aRowsBefore); // A untouched
    expect(await devCount("SiteOrder", A)).toBe(aOrdersBefore);
  });

  liveTest(10, "contact inquiry (المراسلات) lands ONLY on B's inbox — A is untouched", async () => {
    const ticketsABefore = await devCount("SupportTicket", A);
    const res = await jfetch(`/api/sites/${B}/contact`, {
      method: "POST",
      headers: JSON_HEADERS,
      /* the contact endpoint is anonymous by design — its response joins
       * the public-PII sweep corpus (sliced + full mode alike) */
      publicBody: true,
      body: JSON.stringify({
        name: "زائر باء",
        email: CONTACT_B_EMAIL,
        message: "استفسار اختبار العزل العام",
      }),
    });
    expect(res.status).toBe(201);
    const body = (await res.json()) as { instanceId?: string };
    expect(body.instanceId).toBe(B);

    const row = await devOne<{ instanceId: string }>(
      'SELECT "instanceId" FROM "SupportTicket" WHERE "requesterEmailIndex" = $1 AND "instanceId" = $2',
      (await import("@/lib/server/crypto-vault")).blindIndex(CONTACT_B_EMAIL) as string,
      B
    );
    expect(row?.instanceId).toBe(B);
    expect(await devCount("SupportTicket", A)).toBe(ticketsABefore);
  });

  /* ------------------- origin-guard regressions ------------------- */

  liveTest(10, "origin guard: cookie mutations without Origin → 403; cross-origin Origin → 403", async () => {
    const recordsBefore = await devCount("ModuleRecord", A);

    const noOrigin = await jfetch(`/api/instances/${A}/module-records`, {
      method: "POST",
      jar: jarA,
      headers: { "content-type": "application/json" }, // NO Origin / Referer
      body: JSON.stringify(pharmacyProductPayload("NoOriginProbe")),
    });
    expect(noOrigin.status).toBe(403);
    const noOriginBody = (await noOrigin.json()) as { error?: string };
    expect(noOriginBody.error).toBe("Origin header required for authenticated requests");
    expect(await devCount("ModuleRecord", A)).toBe(recordsBefore);

    const siteBefore = await devOne<{ published: boolean }>(
      'SELECT "published" FROM "Site" WHERE "instanceId" = $1',
      B
    );
    const siteNoOrigin = await jfetch(`/api/instances/${B}/site`, {
      method: "PUT",
      jar: jarB,
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ published: false }),
    });
    expect(siteNoOrigin.status).toBe(403);
    expect(
      (
        await devOne<{ published: boolean }>('SELECT "published" FROM "Site" WHERE "instanceId" = $1', B)
      )?.published
    ).toBe(siteBefore?.published);

    const orderNoOrigin = await jfetch(`/api/sites/${B}/orders`, {
      method: "POST",
      jar: jarB, /* ROUND 44 — an INSTANCE session cookie is an ambient
                    credential: a mutation without Origin is 403 (customer
                    sessions no longer exist to test) */
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ items: [{ recordId: recordBId, qty: 1 }] }),
    });
    expect(orderNoOrigin.status).toBe(403);

    const crossOrigin = await jfetch(`/api/instances/${A}/module-records`, {
      method: "POST",
      jar: jarA,
      headers: { "content-type": "application/json", origin: "http://evil.example" },
      body: JSON.stringify(pharmacyProductPayload("EvilProbe")),
    });
    expect(crossOrigin.status).toBe(403);
    const crossBody = (await crossOrigin.json()) as { error?: string };
    expect(crossBody.error).toBe("Cross-origin request rejected");
    expect(await devCount("ModuleRecord", A)).toBe(recordsBefore);
  });

  /* ---------------- count-based leak detection ---------------- */

  liveTest(6, "count-based leak detection: B's counts IDENTICAL after five mutations on A", async () => {
    const before = {
      records: await devCount("ModuleRecord", B),
      orders: await devCount("SiteOrder", B),
      customers: await devCount("SiteCustomer", B),
      members: await devCount("TeamMember", B),
      activities: await devCount("Activity", B),
    };

    /* mutation 1 — a second inventory row on A */
    const m1 = await jfetch(`/api/instances/${A}/module-records`, {
      method: "POST",
      jar: jarA,
      headers: JSON_HEADERS,
      body: JSON.stringify(pharmacyProductPayload(`${PROD_A}-2`)),
    });
    expect(m1.status).toBe(201);

    /* mutation 2 — a manual activity entry on A */
    const m2 = await jfetch(`/api/instances/${A}/activities`, {
      method: "POST",
      jar: jarA,
      headers: JSON_HEADERS,
      body: JSON.stringify({ kind: "actReportGenerated", meta: { report: "isolation" } }),
    });
    expect(m2.status).toBe(201);

    /* mutation 3 — a second team member on A */
    const m3 = await jfetch(`/api/instances/${A}/members`, {
      method: "POST",
      jar: jarA,
      headers: JSON_HEADERS,
      body: JSON.stringify({
        name: "عضو ألف الثاني",
        email: `member-a2-${RUN}@example.com`,
        role: "viewer",
      }),
    });
    expect(m3.status).toBe(201);

    /* mutation 4 — site content update on A */
    const m4 = await jfetch(`/api/instances/${A}/site`, {
      method: "PUT",
      jar: jarA,
      headers: JSON_HEADERS,
      body: JSON.stringify({
        published: true,
        content: {
          ...siteContentPayload(ORG_A, `contact-a-${RUN}@example.com`),
          heroDesc: `${ORG_A} UPDATED hero description`,
        },
      }),
    });
    expect(m4.status).toBe(200);

    /* mutation 5 — order lifecycle advance on A */
    const m5 = await jfetch(`/api/instances/${A}/orders/${orderIdA}`, {
      method: "PATCH",
      jar: jarA,
      headers: JSON_HEADERS,
      body: JSON.stringify({ status: "confirmed", statusNote: "تم التأكيد" }),
    });
    expect(m5.status).toBe(200);

    /* positive control — the five mutations really landed on A */
    expect(await devCount("ModuleRecord", A)).toBeGreaterThanOrEqual(2);
    expect(
      (await devOne<{ status: string }>('SELECT "status" FROM "SiteOrder" WHERE "id" = $1', orderIdA))?.status
    ).toBe("confirmed");

    /* B is untouched, row for row */
    expect(await devCount("ModuleRecord", B)).toBe(before.records);
    expect(await devCount("SiteOrder", B)).toBe(before.orders);
    expect(await devCount("SiteCustomer", B)).toBe(before.customers);
    expect(await devCount("TeamMember", B)).toBe(before.members);
    expect(await devCount("Activity", B)).toBe(before.activities);
  });

  /* ------------------------- exports ------------------------- */

  liveTest(10, "exports: A's exports carry ZERO B strings; B's exports carry ZERO A strings", async () => {
    const summaryA = await jfetch(`/api/instances/${A}/export?type=summary&format=json`, {
      jar: jarA,
    });
    expect(summaryA.status).toBe(200);
    const summaryAText = await summaryA.text();
    expect(summaryAText).toContain(ORG_A);
    expect(summaryAText).toContain(EMAIL_A); // own decrypted admin email
    expect(summaryAText).not.toContain(ORG_B);
    expect(summaryAText).not.toContain(EMAIL_B);
    expect(summaryAText).not.toContain(B);
    expect(summaryAText).not.toContain(CUST_B_EMAIL);
    expect(summaryAText).not.toContain(MEMBER_B_EMAIL);

    const membersCsvA = await jfetch(`/api/instances/${A}/export?type=members&format=csv`, {
      jar: jarA,
    });
    expect(membersCsvA.status).toBe(200);
    const membersCsvAText = await membersCsvA.text();
    expect(membersCsvAText).toContain(MEMBER_A_EMAIL);
    expect(membersCsvAText).not.toContain(MEMBER_B_EMAIL);
    expect(membersCsvAText).not.toContain(ORG_B);

    const summaryB = await jfetch(`/api/instances/${B}/export?type=summary&format=json`, {
      jar: jarB,
    });
    expect(summaryB.status).toBe(200);
    const summaryBText = await summaryB.text();
    expect(summaryBText).toContain(ORG_B);
    expect(summaryBText).toContain(EMAIL_B);
    expect(summaryBText).not.toContain(ORG_A);
    expect(summaryBText).not.toContain(EMAIL_A);
    expect(summaryBText).not.toContain(A);
    expect(summaryBText).not.toContain(CUST_A_EMAIL);
    expect(summaryBText).not.toContain(MEMBER_A_EMAIL);
  });

  /* ------------------- global PII sweep ------------------- */

  liveTest(FULL_ONLY, "global sweep: no vault ciphertext in ANY response; no customer PII in any PUBLIC response", async () => {
    /* the capture must have covered real material — not a silent no-op */
    expect(allBodies.length).toBeGreaterThanOrEqual(40);
    expect(publicBodies.length).toBeGreaterThanOrEqual(10);

    for (const text of allBodies) {
      expect(text).not.toContain(VAULT_MARKER); // sealed envelopes never leak raw
    }
    for (const text of publicBodies) {
      expect(text).not.toContain(CUST_A_EMAIL);
      expect(text).not.toContain(CUST_B_EMAIL);
      expect(text).not.toContain(CUST_A_PHONE);
      expect(text).not.toContain(CUST_B_PHONE);
      expect(text).not.toContain(EMAIL_A); // workspace owner identities
      expect(text).not.toContain(EMAIL_B);
    }
  });

  /* ------------- per-slice PII/ciphertext sweep (sliced mode) -------------
   * the full-mode global sweep spans ONE process; in sliced mode every
   * slice sweeps the bodies IT captured — the no-leak guarantee survives
   * the process split (floors: per-slice capture minimums, verified by
   * hand-count — provisioning 16 + the chunk's requests) */
  if (SLICE >= 1 && SLICE <= SLICE_COUNT) {
    test(`slice ${SLICE} sweep: no vault ciphertext in captured responses; no customer PII in public captures`, async () => {
      /* per-slice capture minimums (hand-counted: rejoin 2 logins + the
       * chunk's requests; slice 1 = provisioning 16 + reads 11) */
      const MIN_ALL: Record<number, number> = { 1: 14, 2: 11, 3: 8, 4: 8, 5: 8, 6: 8, 7: 6, 8: 3, 9: 8, 10: 8 };
      const MIN_PUBLIC: Record<number, number> = { 4: 5, 5: 4, 8: 1, 9: 5, 10: 1 };
      const minAll = MIN_ALL[SLICE] ?? 8;
      const minPublic = MIN_PUBLIC[SLICE] ?? 0;
      expect(allBodies.length).toBeGreaterThanOrEqual(minAll);
      if (minPublic > 0) expect(publicBodies.length).toBeGreaterThanOrEqual(minPublic);

      for (const text of allBodies) {
        expect(text).not.toContain(VAULT_MARKER); // sealed envelopes never leak raw
      }
      for (const text of publicBodies) {
        expect(text).not.toContain(CUST_A_EMAIL);
        expect(text).not.toContain(CUST_B_EMAIL);
        expect(text).not.toContain(CUST_A_PHONE);
        expect(text).not.toContain(CUST_B_PHONE);
        expect(text).not.toContain(EMAIL_A); // workspace owner identities
        expect(text).not.toContain(EMAIL_B);
      }
    });
  }

  /* ---------------------------- cleanup ---------------------------- */

  afterAll(async () => {
    if (!live) return;
    if (SLICE === 0) {
      /* legacy full run — the original contract: outbox + rows + rate keys */
      await cleanupRun();
    } else if (SLICE >= 1 && SLICE <= SLICE_COUNT) {
      /* sliced mode: rows PERSIST for the rejoin slices — purge only the
       * rate keys (fresh limiter window per slice); the cleanup phase
       * (TENANT_ISOLATION_SLICE=99) owns row deletion */
      await purgeRunKeysOnly();
    }
  });
});

/* ====================================================================== */
/* CLEANUP PHASE (TENANT_ISOLATION_SLICE=99) — server-independent          */
/* ====================================================================== */
if (SLICE === SLICE_CLEANUP) {
  test("cleanup phase — purge this run's rows + keys + outbox; stale-sweep interrupted runs", async () => {
    /* re-derive this run's ids (this process ran no tests) through a direct
     * connection to the dev server's database — server-independent, and
     * PostgreSQL MVCC means the connection always sees committed state
     * (the SQLite-era WAL-recovery caveat for write-capable opens is
     * obsolete). */
    const { blindIndex } = await import("@/lib/server/crypto-vault");
    const probe = await serverPg();
    try {
      const idxA = blindIndex(EMAIL_A) as string;
      const idxB = blindIndex(EMAIL_B) as string;
      A =
        (
          (await probe.query<{ id: string }>('SELECT "id" FROM "Instance" WHERE "adminEmailIndex" = $1', [idxA]))
            .rows[0] as { id: string } | undefined
        )?.id ?? "";
      B =
        (
          (await probe.query<{ id: string }>('SELECT "id" FROM "Instance" WHERE "adminEmailIndex" = $1', [idxB]))
            .rows[0] as { id: string } | undefined
        )?.id ?? "";
      if (A) {
        custAId =
          (
            (
              await probe.query<{ id: string }>(
                'SELECT "id" FROM "SiteCustomer" WHERE "instanceId" = $1 AND "emailIndex" = $2',
                [A, blindIndex(CUST_A_EMAIL) as string]
              )
            ).rows[0] as { id: string } | undefined
          )?.id ?? "";
      }
      if (B) {
        custBId =
          (
            (
              await probe.query<{ id: string }>(
                'SELECT "id" FROM "SiteCustomer" WHERE "instanceId" = $1 AND "emailIndex" = $2',
                [B, blindIndex(CUST_B_EMAIL) as string]
              )
            ).rows[0] as { id: string } | undefined
          )?.id ?? "";
      }
    } finally {
      await closeServerPg();
    }

    /* 1) this run's rows + rate keys + outbox (strict: leftovers FAIL the
     *    phase so the battery surfaces them; idempotent no-ops when the
     *    run never provisioned — the battery ALWAYS runs this phase) */
    await cleanupRun(true);

    /* 2) STALE SWEEP — isolation instances from THIS run (exact org-name
     *    match — catches duplicate pairs from any partially provisioned
     *    attempt, whatever the RUN id shape) and from OLD interrupted
     *    batteries (numeric Tenant(Alpha|Beta)-<ms>-<rand> shape, created
     *    > 30 min ago — the age gate keeps a CONCURRENT battery's fresh
     *    rows safe: measured ROUND 105, a parallel review session's
     *    cleanup swept THIS run's rows mid-slice and poisoned a 404 FAIL) */
    const sweep = await serverPg();
    try {
      const result = await sweep.query<{ id: string; orgJson: string; createdAt: Date }>(
        'SELECT "id", "orgJson", "createdAt" FROM "Instance"'
      );
      const staleIds: string[] = [];
      for (const row of result.rows) {
        try {
          const name = (JSON.parse(row.orgJson) as { name?: string }).name ?? "";
          const oldEnough = Date.now() - row.createdAt.getTime() > 30 * 60 * 1000;
          /* numeric ids = older batteries; ti- ids = this protocol's own
           * failed slice-1 attempts (the retry regenerates the run id) */
          const suiteShaped =
            /^Tenant(Alpha|Beta)-\d+-\d+$/.test(name) || /^Tenant(Alpha|Beta)-ti-\d+-\d+$/.test(name);
          if (name === ORG_A || name === ORG_B || (suiteShaped && oldEnough)) {
            staleIds.push(row.id);
          }
        } catch {
          /* unparsable org JSON — never this suite's rows */
        }
      }
      for (const id of staleIds) await deleteInstanceRows(sweep, id);
      for (const id of staleIds) {
        for (const table of [...COUNTABLE_TABLES]) {
          const inList = table === "Instance" ? "id" : "instanceId";
          const left =
            (await sweep.query<{ c: number }>(`SELECT COUNT(*)::int AS c FROM "${table}" WHERE "${inList}" = $1`, [id]))
              .rows[0]?.c ?? 0;
          if (left > 0) throw new Error(`[tenant-isolation] stale-sweep leftover in ${table} (${id}): ${left}`);
        }
      }
      if (staleIds.length > 0) {
        console.log(`[tenant-isolation] stale sweep removed ${staleIds.length} isolation instance(s)`);
      }
    } finally {
      await closeServerPg();
    }

    /* 3) outbox .eml files carrying the suite's per-run email shape
     *    (<marker>-<13-digit ms>-<random>@example.com) — heals interrupted
     *    runs whose exact emails nobody can reconstruct anymore */
    if (existsSync(DEV_OUTBOX)) {
      for (const file of readdirSync(DEV_OUTBOX)) {
        if (!file.endsWith(".eml")) continue;
        try {
          const content = readFileSync(join(DEV_OUTBOX, file), "utf8");
          if (/-\d{13}-\d{1,7}@example\.com/.test(content)) unlinkSync(join(DEV_OUTBOX, file));
        } catch {
          /* raced away — nothing to remove */
        }
      }
    }
  }, 60_000);
}
