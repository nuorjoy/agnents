/// <reference types="bun-types" />
/**
 * Ashrilogic — health probe tests (ROUND 113; PostgreSQL-only since the
 * cutover — the migration state machine is gone and readyz is back to a
 * pure bounded DB ping).
 *
 * Exercised OFFLINE by importing the route handlers directly against the
 * isolated throwaway test database (the live dev database is never read):
 *
 *  - /api/healthz: 200 + ok:true + no-store on a healthy DB.
 *  - /api/readyz: 200 + ok:true + no-store on the steady state (the
 *    readiness verdict is a trivial bounded DB ping — no migration phase,
 *    no backup-freshness input by design).
 */

import { describe, test, expect, beforeAll, afterAll } from "bun:test";
import { ensureDemoEnv, getTestDb } from "./test-setup";

ensureDemoEnv();

let db: Awaited<ReturnType<typeof getTestDb>>;
let healthz: typeof import("@/app/api/healthz/route");
let readyz: typeof import("@/app/api/readyz/route");

beforeAll(async () => {
  db = await getTestDb();
  // seed the platform settings row the ping can find (any row works)
  await db.platformSetting.upsert({
    where: { id: "global" },
    update: {},
    create: { id: "global" },
  });
  healthz = await import("@/app/api/healthz/route");
  readyz = await import("@/app/api/readyz/route");
});

afterAll(async () => {
  try {
    await db.platformSetting.deleteMany({});
  } catch {
    /* throwaway test database — reset anyway on the next process */
  }
});

describe("GET /api/healthz", () => {
  test("healthy DB → 200 ok:true, no-store, sub-second", async () => {
    const response = await healthz.GET();
    expect(response.status).toBe(200);
    expect(response.headers.get("cache-control")).toBe("no-store");
    const body = (await response.json()) as { ok: boolean; elapsedMs: number };
    expect(body.ok).toBe(true);
    expect(body.elapsedMs).toBeLessThan(2000);
  });
});

describe("GET /api/readyz", () => {
  test("healthy DB → 200 ready, no-store, sub-second (pure bounded ping)", async () => {
    const response = await readyz.GET();
    expect(response.status).toBe(200);
    expect(response.headers.get("cache-control")).toBe("no-store");
    const body = (await response.json()) as { ok: boolean; reason?: string; elapsedMs: number };
    expect(body.ok).toBe(true);
    expect(body.reason).toBeUndefined(); /* no failure reason on the steady state */
    expect(body.elapsedMs).toBeLessThan(2000);
  });
});
