/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 127: the declarative guard plan
 * (src/lib/server/route.ts runGuardPlan).
 *
 * The guard plan is the seam every DECLARATIVELY-guarded route handler
 * goes through (the three decomposed domains — packages, plan-orders,
 * store — declare their guard surface in the routeHandler config), so its
 * CONTRACT is the contract: each stage must render the EXACT envelope the
 * legacy hand-rolled call produced, in the EXACT historical order, with
 * the correlation id attached to every short-circuit.
 *
 * Unit level — handlers are wrapped inline and invoked with synthetic
 * Requests (origin/maintenance/throttle/body stages + ordering + the
 * loud-error paths). The admin/tenant SESSION stages resolve cookies
 * through next/headers (a request scope only the live server provides),
 * so their envelopes are proven by the LIVE suites instead:
 * packages-routes (admin roles + origin + 401/403), plan-assignment and
 * trial-entitlement (the manualRoles ADMIN_FORBIDDEN_ROLE envelope + the
 * admin-keyed throttle), store-routes (origin-first on both public
 * mutations).
 */
import { describe, test, expect, beforeAll, afterAll } from "bun:test";
import { getTestDb, type TestDb, ensureDemoEnv } from "./test-setup";

ensureDemoEnv();

let db: TestDb;
let routeHandler: typeof import("@/lib/server/route").routeHandler;
let ctxBody: typeof import("@/lib/server/route").ctxBody;
let ctxAdmin: typeof import("@/lib/server/route").ctxAdmin;
let ctxTenant: typeof import("@/lib/server/route").ctxTenant;
let codeSchema: import("zod").ZodType<{ code: string }>;

const HOST = "localhost:3000";
const RUN = Math.random().toString(36).slice(2, 8);
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

beforeAll(async () => {
  db = await getTestDb();
  ({ routeHandler, ctxBody, ctxAdmin, ctxTenant } = await import("@/lib/server/route"));
  const { z } = await import("zod");
  codeSchema = z.object({ code: z.string().min(3) });
});

afterAll(async () => {
  await db.restoreLease.deleteMany({ where: { instanceId: { contains: RUN } } }).catch(() => undefined);
});

function post(body: string, headers: Record<string, string> = {}): Request {
  return new Request(`http://${HOST}/api/probe`, {
    method: "POST",
    body,
    headers: { "content-type": "application/json", host: HOST, ...headers },
  });
}

function get(headers: Record<string, string> = {}): Request {
  return new Request(`http://${HOST}/api/probe`, { method: "GET", headers: { host: HOST, ...headers } });
}

function segment(id: string): { params: Promise<{ id: string }> } {
  return { params: Promise.resolve({ id }) };
}

const ok = () => Response.json({ ok: true }) as import("next/server").NextResponse;

describe("ROUND 127 — declarative origin stage (byte-compatible 403)", () => {
  test("cross-origin POST → 403 'Cross-origin request rejected' + x-request-id", async () => {
    const handler = routeHandler(
      "submit review",
      { origin: true },
      async () => ok()
    );
    const res = await handler(post("{}", { origin: "http://evil.example" }));
    expect(res.status).toBe(403);
    expect(((await res.json()) as { error?: string }).error).toBe("Cross-origin request rejected");
    expect(res.headers.get("x-request-id")).toMatch(UUID_RE);
  });

  test("same-origin POST passes through to the handler", async () => {
    const handler = routeHandler(
      "submit review",
      { origin: true },
      async () => ok()
    );
    const res = await handler(post("{}", { origin: `http://${HOST}` }));
    expect(res.status).toBe(200);
    expect(((await res.json()) as { ok?: boolean }).ok).toBe(true);
  });

  test("origin runs BEFORE the throttle (cross-origin + exhausted key → 403, not 429)", async () => {
    const rule = { limit: 1, windowMs: 60_000 };
    const key = `origin-order-${RUN}`;
    const handler = routeHandler(
      "submit review",
      {
        origin: true,
        rateLimit: { key: () => key, rule, body: { error: "Too many" } },
      },
      async () => ok()
    );
    /* burn the single throttle slot with a SAME-ORIGIN call */
    const first = await handler(post("{}", { origin: `http://${HOST}` }));
    expect(first.status).toBe(200);
    /* cross-origin + over-limit → the origin gate answers FIRST */
    const res = await handler(post("{}", { origin: "http://evil.example" }));
    expect(res.status).toBe(403);
    expect(((await res.json()) as { error?: string }).error).toBe("Cross-origin request rejected");
  });
});

describe("ROUND 127 — declarative throttle stage (the 429 envelope)", () => {
  test("over-limit → the custom legacy body + Retry-After/X-RateLimit headers + x-request-id", async () => {
    const rule = { limit: 1, windowMs: 60_000 };
    const key = `throttle-envelope-${RUN}`;
    const handler = routeHandler(
      "validate the coupon",
      {
        rateLimit: {
          key: () => key,
          rule,
          body: { error: "Too many attempts — please wait", code: "RATE" },
        },
      },
      async () => ok()
    );
    const first = await handler(post("{}"));
    expect(first.status).toBe(200);
    const res = await handler(post("{}"));
    expect(res.status).toBe(429);
    const body = (await res.json()) as { error?: string; code?: string };
    expect(body.error).toBe("Too many attempts — please wait");
    expect(body.code).toBe("RATE");
    expect(res.headers.get("Retry-After")).toBe("60");
    expect(res.headers.get("X-RateLimit-Limit")).toBe("1");
    expect(res.headers.get("X-RateLimit-Window-Seconds")).toBe("60");
    expect(res.headers.get("x-request-id")).toMatch(UUID_RE);
  });

  test("the key builder receives the client IP and the awaited route segments", async () => {
    let seen: { ip: string; id: string } | null = null;
    const handler = routeHandler(
      "submit review",
      {
        rateLimit: {
          key: (parts) => {
            seen = { ip: parts.ip, id: String(parts.params.id) };
            return `key-parts-${RUN}`;
          },
          rule: { limit: 5, windowMs: 60_000 },
          body: { error: "Too many" },
        },
      },
      async (_ctx, _seg: { params: Promise<{ id: string }> }) => ok()
    );
    const res = await handler(post("{}", { "x-forwarded-for": "203.0.113.9" }), segment(`site-${RUN}`));
    expect(res.status).toBe(200);
    expect(seen).not.toBeNull();
    expect(seen!.ip).toBe("203.0.113.9");
    expect(seen!.id).toBe(`site-${RUN}`);
  });

  test("adminId() without an admin stage → the loud 500 envelope", async () => {
    const handler = routeHandler(
      "update plan order",
      {
        rateLimit: {
          key: (parts) => `broken-${parts.adminId()}:${parts.ip}`,
          rule: { limit: 5, windowMs: 60_000 },
          body: { error: "Too many" },
        },
      },
      async () => ok()
    );
    const res = await handler(post("{}"));
    expect(res.status).toBe(500);
    expect(((await res.json()) as { error?: string }).error).toBe("Failed to update plan order");
  });
});

describe("ROUND 127 — body-stage positioning (the two historical semantics)", () => {

  test("rateLimit.afterBody (coupon semantics): an INVALID body → 400, and it burns NO throttle hit", async () => {
    const key = `after-body-${RUN}`;
    const handler = routeHandler(
      "validate the coupon",
      {
        body: { schema: codeSchema, invalid: { error: "Invalid coupon request" } },
        rateLimit: {
          key: () => key,
          rule: { limit: 1, windowMs: 60_000 },
          body: { error: "Too many attempts — please wait", code: "RATE" },
          afterBody: true,
        },
      },
      async () => ok()
    );
    /* 1 — a VALID body consumes the single slot */
    const first = await handler(post(JSON.stringify({ code: "SAVE10" })));
    expect(first.status).toBe(200);
    /* 2 — an INVALID body → the body stage answers BEFORE the throttle */
    const invalid = await handler(post(JSON.stringify({ code: "x" })));
    expect(invalid.status).toBe(400);
    expect(((await invalid.json()) as { error?: string }).error).toBe("Invalid coupon request");
    /* 3 — a VALID body now → 429: the ONLY hit ever burned was call 1's
     *     (the invalid call 2 never reached the throttle) */
    const res = await handler(post(JSON.stringify({ code: "SAVE10" })));
    expect(res.status).toBe(429);
  });

  test("default position (reviews semantics): the throttle answers BEFORE the body", async () => {
    const key = `before-body-${RUN}`;
    const handler = routeHandler(
      "submit review",
      {
        rateLimit: {
          key: () => key,
          rule: { limit: 1, windowMs: 60_000 },
          body: { error: "Too many reviews" },
        },
        body: { schema: codeSchema, invalid: { error: "Invalid review" } },
      },
      async () => ok()
    );
    const first = await handler(post(JSON.stringify({ code: "abc" })));
    expect(first.status).toBe(200);
    /* over-limit + invalid body → 429, NOT the 400 the body would give */
    const res = await handler(post(JSON.stringify({ code: "x" })));
    expect(res.status).toBe(429);
    expect(((await res.json()) as { error?: string }).error).toBe("Too many reviews");
  });

  test("a valid body lands on ctxBody typed; ctx.params carries the segments", async () => {
    let seenCode = "";
    let seenId = "";
    const handler = routeHandler(
      "submit review",
      { body: { schema: codeSchema, invalid: { error: "Invalid review" } } },
      async (ctx, _seg: { params: Promise<{ id: string }> }) => {
        seenCode = ctxBody<typeof codeSchema._output>(ctx).code;
        seenId = String(ctx.params?.id ?? "");
        return ok();
      }
    );
    const res = await handler(
      post(JSON.stringify({ code: "SAVE10" })),
      segment(`site-${RUN}`)
    );
    expect(res.status).toBe(200);
    expect(seenCode).toBe("SAVE10");
    expect(seenId).toBe(`site-${RUN}`);
  });

  test("the custom invalid envelope carries its code when declared", async () => {
    const { z } = await import("zod");
    const numberSchema = z.object({ n: z.number() });
    const handler = routeHandler(
      "submit review",
      { body: { schema: numberSchema, invalid: { error: "Invalid shape", code: "BAD_SHAPE" } } },
      async () => ok()
    );
    const res = await handler(post(JSON.stringify({ n: "not-a-number" })));
    expect(res.status).toBe(400);
    const body = (await res.json()) as { error?: string; code?: string };
    expect(body.error).toBe("Invalid shape");
    expect(body.code).toBe("BAD_SHAPE");
  });

  test("empty body through the body stage → the bounded-reader 400 envelope", async () => {
    const handler = routeHandler(
      "submit review",
      { body: { schema: codeSchema, invalid: { error: "Invalid review" } } },
      async () => ok()
    );
    const res = await handler(post(""));
    expect(res.status).toBe(400);
    expect(((await res.json()) as { error?: string }).error).toBe("Request body is required");
  });
});

describe("ROUND 127 — declarative maintenance stage (the 503 window)", () => {
  test("restore lease in flight → 503 MAINTENANCE with the exact legacy envelope", async () => {
    const instanceId = `maint-live-${RUN}`;
    await db.restoreLease.create({
      data: {
        instanceId,
        holder: `test-${RUN}`,
        acquiredAt: new Date(),
        expiresAt: new Date(Date.now() + 60_000),
      },
    });
    const handler = routeHandler(
      "submit review",
      { maintenance: true },
      async (_ctx, _seg: { params: Promise<{ id: string }> }) => ok()
    );
    const res = await handler(post("{}"), segment(instanceId));
    expect(res.status).toBe(503);
    const body = (await res.json()) as { error?: string; code?: string };
    expect(body.error).toBe(
      "This workspace is being restored from a backup right now — changes are unavailable for a few moments. Please retry shortly."
    );
    expect(body.code).toBe("MAINTENANCE");
    expect(res.headers.get("Retry-After")).toBe("30");
    expect(res.headers.get("x-request-id")).toMatch(UUID_RE);
  });

  test("GET passes the maintenance stage (read-only methods always pass)", async () => {
    const instanceId = `maint-get-${RUN}`;
    await db.restoreLease.create({
      data: {
        instanceId,
        holder: `test-${RUN}`,
        acquiredAt: new Date(),
        expiresAt: new Date(Date.now() + 60_000),
      },
    });
    const handler = routeHandler(
      "load reviews",
      { maintenance: true },
      async (_ctx, _seg: { params: Promise<{ id: string }> }) => ok()
    );
    const res = await handler(get(), segment(instanceId));
    expect(res.status).toBe(200);
  });

  test("maintenance stage without an [id] segment → the loud 500 envelope", async () => {
    const handler = routeHandler(
      "submit review",
      { maintenance: true },
      async () => ok()
    );
    const res = await handler(post("{}"));
    expect(res.status).toBe(500);
    expect(((await res.json()) as { error?: string }).error).toBe("Failed to submit review");
  });
});

describe("ROUND 127 — the context accessors (loud programming errors)", () => {
  test("ctxAdmin without an admin stage → 500 'Failed to <label>'", async () => {
    const handler = routeHandler(
      "create package",
      {},
      async (ctx) => {
        ctxAdmin(ctx);
        return ok();
      }
    );
    const res = await handler(post("{}"));
    expect(res.status).toBe(500);
    expect(((await res.json()) as { error?: string }).error).toBe("Failed to create package");
  });

  test("ctxTenant without a tenant stage → 500 'Failed to <label>'", async () => {
    const handler = routeHandler(
      "create plan order",
      {},
      async (ctx) => {
        ctxTenant(ctx);
        return ok();
      }
    );
    const res = await handler(post("{}"));
    expect(res.status).toBe(500);
    expect(((await res.json()) as { error?: string }).error).toBe("Failed to create plan order");
  });

  test("ctxBody without a body stage → 500 'Failed to <label>'", async () => {
    const handler = routeHandler(
      "submit review",
      {},
      async (ctx) => {
        ctxBody(ctx);
        return ok();
      }
    );
    const res = await handler(post("{}"));
    expect(res.status).toBe(500);
    expect(((await res.json()) as { error?: string }).error).toBe("Failed to submit review");
  });
});

describe("ROUND 127 — legacy 2-arg form still works unchanged", () => {
  test("a guard-less legacy handler behaves exactly as ROUND 124 specified", async () => {
    const handler = routeHandler("list packages", async () => {
      return Response.json({ rows: [1, 2, 3] }) as import("next/server").NextResponse;
    });
    const res = await handler(get());
    expect(res.status).toBe(200);
    expect(((await res.json()) as { rows?: number[] }).rows).toEqual([1, 2, 3]);
    expect(res.headers.get("x-request-id")).toMatch(UUID_RE);
  });
});
