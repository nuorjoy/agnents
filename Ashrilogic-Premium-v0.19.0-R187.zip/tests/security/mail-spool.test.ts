/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — MAIL SPOOL THROUGH THE OBJECT STORE (ROUND 123).
 *
 * The dev-spool mail transport (the .eml artifacts under storage/outbox)
 * was lifted onto the object storage adapter: every send writes through
 * the ACTIVE driver (local FS by default; any S3-compatible engine when
 * ASHRILOGIC_STORAGE_DRIVER=s3).
 *
 * Proves:
 *  1. LOCAL DRIVER PARITY — the .eml artifact lands at the historical
 *     location (ASHRILOGIC_STORAGE_DIR/outbox/<stamp>_<recipient>.eml)
 *     with the exact RFC-5322 bytes (headers, multipart when HTML),
 *     messageId = the artifact filename, and the header-injection strip
 *     (CRLF in an admin-authored subject can never smuggle headers).
 *  2. VERIFY() — the driver-aware probe: put + delete a real object
 *     through the ACTIVE store, no probe residue left behind, ok:false
 *     when the store refuses writes (an unwritable root).
 *  3. THE S3 PATH — with the s3 driver pointed at a local S3-shaped
 *     server, send() lands the artifact in the BUCKET under
 *     outbox/<name>.eml (the exact bytes, request signed), and verify()
 *     probes + removes its object remotely. The full SigV4 wire contract
 *     is proven in object-store.test.ts; this server checks the
 *     Authorization header's presence/shape and records the wire hits.
 *  4. THE ERROR CONTRACT — an adapter failure maps to { ok:false } (the
 *     send path never throws at the caller; the service layer settles
 *     the row accordingly).
 *
 * No DB needed — the spool is pure storage.
 */

import { afterAll, beforeAll, describe, expect, test } from "bun:test";
import { mkdtempSync, rmSync, existsSync, readdirSync, readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { ensureDemoEnv } from "./test-setup";

ensureDemoEnv();

/* storage modules are pure (fs only) — static import is safe; the factory
 * memo is reset around each env mutation below */
import {
  objectStorage,
  __resetObjectStorageForTests,
} from "@/lib/server/storage/object-store";
import { createSpoolProvider } from "@/lib/server/mail/providers/spool";

const TMP = mkdtempSync(join(tmpdir(), "ashrilogic-mail-spool-"));

function outboxFiles(root: string): string[] {
  const dir = join(root, "outbox");
  if (!existsSync(dir)) return [];
  return readdirSync(dir).sort();
}

/** bind the local driver to a fresh root via env (the spool resolves the
 *  store through the factory — same as production) */
async function bindLocal(root: string): Promise<void> {
  __resetObjectStorageForTests();
  delete process.env.ASHRILOGIC_STORAGE_DRIVER;
  process.env.ASHRILOGIC_STORAGE_DIR = root;
}

afterAll(() => {
  delete process.env.ASHRILOGIC_STORAGE_DIR;
  delete process.env.ASHRILOGIC_STORAGE_DRIVER;
  delete process.env.S3_ENDPOINT;
  delete process.env.S3_BUCKET;
  delete process.env.S3_ACCESS_KEY_ID;
  delete process.env.S3_SECRET_ACCESS_KEY;
  delete process.env.S3_REGION;
  __resetObjectStorageForTests();
  rmSync(TMP, { recursive: true, force: true });
});

/* ------------------------- 1 — local driver parity ----------------------- */

describe("ROUND 123 — mail spool on the LOCAL driver (behavior parity)", () => {
  test("send() lands the exact .eml artifact at the historical location; messageId = filename", async () => {
    const root = mkdtempSync(join(TMP, "local-"));
    await bindLocal(root);
    const spool = createSpoolProvider({
      from: "Ashrilogic <no-reply@ashrilogic.example>",
      replyTo: "support@ashrilogic.example",
    });

    const result = await spool.send({
      to: "guest.qa@example.com",
      subject: "مستشفى النخبة الطبي — Receipt",
      text: "شكراً لطلبكم — هذه تجربة العرض.",
    });
    expect(result.ok).toBe(true);
    const { messageId } = result;
    if (typeof messageId !== "string") throw new Error("spool send returned no messageId");
    expect(messageId).toMatch(/^\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}-\d{3}Z_guest\.qa@example\.com\.eml$/);

    const files = outboxFiles(root);
    expect(files).toHaveLength(1);
    expect(files[0]).toBe(messageId);

    /* the RFC-5322 shape: the essential headers, the sanitized subject,
       the UTF-8 text body, trailing CRLF */
    const eml = readFileSync(join(root, "outbox", files[0]), "utf8");
    expect(eml).toContain("From: Ashrilogic <no-reply@ashrilogic.example>");
    expect(eml).toContain("To: guest.qa@example.com");
    expect(eml).toContain("Reply-To: support@ashrilogic.example");
    expect(eml).toContain("Subject: مستشفى النخبة الطبي — Receipt");
    expect(eml).toContain("MIME-Version: 1.0");
    expect(eml).toContain('Content-Type: text/plain; charset="utf-8"');
    expect(eml).toContain("شكراً لطلبكم — هذه تجربة العرض.");
    expect(eml.endsWith("\r\n")).toBe(true);
    rmSync(root, { recursive: true, force: true });
  });

  test("HTML mail is multipart/alternative with a boundary; plain stays single-part", async () => {
    const root = mkdtempSync(join(TMP, "html-"));
    await bindLocal(root);
    const spool = createSpoolProvider({ from: "a@b.c", replyTo: null });

    await spool.send({
      to: "html@example.com",
      subject: "both parts",
      text: "plain body",
      html: "<p>html body</p>",
    });
    let files = outboxFiles(root);
    expect(files).toHaveLength(1);
    const html = readFileSync(join(root, "outbox", files[0]), "utf8");
    expect(html).toMatch(/^Content-Type: multipart\/alternative; boundary="----=_ashrilogic_[a-z0-9]+"$/m);
    expect(html).toContain("Content-Type: text/plain; charset=\"utf-8\"");
    expect(html).toContain("plain body");
    expect(html).toContain("Content-Type: text/html; charset=\"utf-8\"");
    expect(html).toContain("<p>html body</p>");

    await spool.send({ to: "plain@example.com", subject: "text only", text: "just text" });
    files = outboxFiles(root);
    expect(files).toHaveLength(2);
    const plain = readFileSync(join(root, "outbox", files[1]), "utf8");
    expect(plain).toContain('Content-Type: text/plain; charset="utf-8"');
    expect(plain).not.toContain("multipart");
    rmSync(root, { recursive: true, force: true });
  });

  test("a hostile subject cannot smuggle headers (CRLF + controls stripped)", async () => {
    const root = mkdtempSync(join(TMP, "inject-"));
    await bindLocal(root);
    const spool = createSpoolProvider({ from: "a@b.c", replyTo: null });

    await spool.send({
      to: "victim@example.com",
      subject: "ok\r\nBcc: attacker@evil.example\r\nX-Smuggled: yes",
      text: "body",
    });
    const files = outboxFiles(root);
    expect(files).toHaveLength(1);
    const eml = readFileSync(join(root, "outbox", files[0]), "utf8");
    /* the security property: no NEW header can be smuggled — the CRLF is
     * stripped, so the attacker text stays INSIDE the (single-line)
     * Subject value as inert data */
    expect(eml).not.toMatch(/^Bcc:/m);
    expect(eml).not.toMatch(/^X-Smuggled:/m);
    expect(eml).not.toMatch(/\r\nBcc:|\r\nX-Smuggled:/);
    /* the subject line itself stays ONE line (\r\n collapses to spaces —
       each control char is replaced by one space) */
    expect(eml).toMatch(/^Subject: ok +Bcc: attacker@evil\.example +X-Smuggled: yes\r?$/m);
    rmSync(root, { recursive: true, force: true });
  });

  test("verify() probes through the active store and leaves no residue", async () => {
    const root = mkdtempSync(join(TMP, "verify-"));
    await bindLocal(root);
    const spool = createSpoolProvider({ from: "a@b.c", replyTo: null });

    const before = await spool.verify();
    expect(before.ok).toBe(true);
    expect(before.detail).toBe("spool");
    expect(outboxFiles(root)).toHaveLength(0); /* probe cleaned up */

    /* an UNWRITABLE root (a FILE where the outbox dir would go) — the
       local put fails, verify reports ok:false with the error */
    const blocked = mkdtempSync(join(TMP, "blocked-"));
    const sentinel = join(blocked, "not-a-dir");
    writeFileSync(sentinel, "x");
    await bindLocal(join(sentinel, "child"));
    const failed = await spool.verify();
    expect(failed.ok).toBe(false);
    expect(failed.detail ?? "").toMatch(/not-a-dir|ENOTDIR|EEXIST|no such/i);

    /* and the error contract for send() too — { ok:false }, never a throw */
    const sent = await spool.send({ to: "x@y.z", subject: "s", text: "t" });
    expect(sent.ok).toBe(false);
    expect(sent.errorClass).toBe("unknown");
    rmSync(root, { recursive: true, force: true });
    rmSync(blocked, { recursive: true, force: true });
  });
});

/* ------------------------------ 3 — the S3 path --------------------------- */

describe("ROUND 123 — mail spool on the S3 driver (bucket-backed outbox)", () => {
  let server: ReturnType<typeof Bun.serve> | null = null;
  const objects = new Map<string, Buffer>();
  const wire = { puts: 0, deletes: 0 };

  beforeAll(() => {
    objects.clear();
    wire.puts = 0;
    wire.deletes = 0;
    server = Bun.serve({
      port: 0,
      hostname: "127.0.0.1",
      async fetch(req) {
        const url = new URL(req.url);
        const path = decodeURIComponent(url.pathname);
        const bucketPath = "/spool-test-bucket";
        if (!path.startsWith(bucketPath)) return new Response("no such bucket", { status: 404 });
        const key = path.slice(bucketPath.length + 1); /* strip "/bucket/" */
        if (!key.startsWith("ashrilogic/test/")) {
          return new Response("outside prefix", { status: 404 });
        }
        /* the wire contract is fully proven in object-store.test.ts; here
           the presence of the SigV4 scheme is the sanity bar */
        if (!(req.headers.get("authorization") ?? "").startsWith("AWS4-HMAC-SHA256")) {
          return new Response("unsigned", { status: 403 });
        }
        if (req.method === "PUT") {
          wire.puts++;
          objects.set(key, Buffer.from(await req.arrayBuffer()));
          return new Response(null, { status: 200 });
        }
        if (req.method === "GET") {
          const obj = objects.get(key);
          if (obj === undefined) return new Response(null, { status: 404 });
          return new Response(new Uint8Array(obj), {
            status: 200,
            headers: { "content-length": String(obj.length) },
          });
        }
        if (req.method === "HEAD") {
          if (!objects.has(key)) return new Response(null, { status: 404 });
          return new Response(null, {
            status: 200,
            headers: { "content-length": String(objects.get(key)!.length) },
          });
        }
        if (req.method === "DELETE") {
          wire.deletes++;
          if (!objects.delete(key)) return new Response(null, { status: 404 });
          return new Response(null, { status: 204 });
        }
        /* ListObjectsV2 */
        const prefix = url.searchParams.get("prefix") ?? "";
        const all = [...objects.keys()].filter((k) => k.startsWith(prefix)).sort();
        const contents = all
          .map((k) => `<Contents><Key>${k}</Key><Size>${objects.get(k)!.length}</Size>` +
          `<LastModified>${new Date().toISOString()}</LastModified></Contents>`)
          .join("");
        return new Response(
          `<?xml version="1.0"?><ListBucketResult>${contents}<IsTruncated>false</IsTruncated></ListBucketResult>`,
          { status: 200, headers: { "content-type": "application/xml" } }
        );
      },
    });

    __resetObjectStorageForTests();
    delete process.env.ASHRILOGIC_STORAGE_DIR;
    process.env.ASHRILOGIC_STORAGE_DRIVER = "s3";
    process.env.S3_ENDPOINT = server.url.toString().replace(/\/$/, "");
    process.env.S3_BUCKET = "spool-test-bucket";
    process.env.S3_REGION = "test-region";
    process.env.S3_ACCESS_KEY_ID = "TESTKEY";
    process.env.S3_SECRET_ACCESS_KEY = "AWS4TESTSECRET";
    process.env.S3_KEY_PREFIX = "ashrilogic/test";
  });

  afterAll(() => {
    server?.stop(true);
  });

  test("send() lands the .eml artifact in the BUCKET under outbox/<name>.eml", async () => {
    const spool = createSpoolProvider({
      from: "Ashrilogic <no-reply@ashrilogic.example>",
      replyTo: null,
    });
    const result = await spool.send({
      to: "s3.guest@example.com",
      subject: "bucket-backed spool",
      text: "the artifact lands in the object store",
    });
    expect(result.ok).toBe(true);
    expect(result.messageId).toMatch(/\.eml$/);

    const stored = [...objects.keys()].filter((k) => k.includes(result.messageId!));
    expect(stored).toHaveLength(1);
    const bytes = objects.get(stored[0])!;
    const eml = bytes.toString("utf8");
    expect(stored[0]).toBe(`ashrilogic/test/outbox/${result.messageId}`);
    expect(eml).toContain("From: Ashrilogic <no-reply@ashrilogic.example>");
    expect(eml).toContain("To: s3.guest@example.com");
    expect(eml).toContain("Subject: bucket-backed spool");
    expect(eml).toContain("the artifact lands in the object store");
  });

  test("verify() probes the REMOTE store (put + delete on the wire)", async () => {
    const spool = createSpoolProvider({ from: "a@b.c", replyTo: null });
    const before = await spool.verify();
    expect(before.ok).toBe(true);
    expect(before.detail).toBe("spool");
    /* the probe put + delete hit the S3-shaped server (not the local FS),
       and no probe object remains */
    expect(wire.puts).toBeGreaterThanOrEqual(1);
    expect(wire.deletes).toBeGreaterThanOrEqual(1);
    expect([...objects.keys()].some((k) => k.includes(".probe-"))).toBe(false);
  });
});
