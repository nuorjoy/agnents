/// <reference types="bun-types" />
/**
 * SECURITY/RELIABILITY REGRESSION — CHUNKED RETENTION PRUNING + ORDER
 * IDEMPOTENCY RETENTION SWEEP (QA round 2).
 *
 * 1. CHUNKED PRUNE: the audit retention sweep must delete every row the
 *    unbounded version deleted (chunked ≠ lossy) — a seeded population
 *    spanning multiple chunks (chunk size is internal) is fully swept,
 *    and rows INSIDE the retention window survive untouched.
 *
 * 2. IDEMPOTENCY SWEEP: completed guard rows beyond the 24h replay window
 *    and stale in-flight holders are dead weight the sweep removes; fresh
 *    completed rows survive (their replay window is still open).
 */

import { beforeAll, afterAll, describe, expect, test } from "bun:test";
import { getTestDb, ensureDemoEnv } from "./test-setup";

ensureDemoEnv();

let db: Awaited<ReturnType<typeof getTestDb>>;
let auditMod: typeof import("@/lib/server/audit");

beforeAll(async () => {
  db = await getTestDb();
  auditMod = await import("@/lib/server/audit");
  await db.auditLog.deleteMany();
  await db.orderIdempotency.deleteMany();
});

afterAll(async () => {
  await db.auditLog.deleteMany();
  await db.orderIdempotency.deleteMany();
  await db.$disconnect();
});

describe("chunked audit retention prune", () => {
  test("sweeps the full retention window in bounded chunks — nothing survives beyond it, nothing inside is lost", async () => {
    const OLD = 200 * 86_400_000; /* 200 days old — beyond any default window */
    const FRESH = 60 * 1000; /* 1 minute old — inside the window */

    /* seed 1,200 old business rows (forces MULTIPLE internal chunks) +
       5 fresh rows + 2 old SECURITY rows (subject to the longer floor) */
    const oldRows = Array.from({ length: 1200 }, (_, i) => ({
      actorType: "admin",
      actorId: "seed",
      actorName: "seed",
      action: `moduleRecord.seed.${i}`,
      targetLabel: null,
      metaJson: null,
      chainHash: null, /* unchained legacy rows — the unbounded sweep path */
      createdAt: new Date(Date.now() - OLD - i * 1000),
    }));
    await db.auditLog.createMany({ data: oldRows });
    await db.auditLog.createMany({
      data: [
        {
          actorType: "admin",
          actorId: "keep",
          actorName: "keep",
          action: "instance.update",
          chainHash: null,
          createdAt: new Date(Date.now() - FRESH),
        },
        {
          actorType: "admin",
          actorId: "keep2",
          actorName: "keep2",
          action: "instance.update",
          chainHash: null,
          createdAt: new Date(Date.now() - FRESH * 2),
        },
      ],
    });

    const totalBefore = await db.auditLog.count();
    expect(totalBefore).toBe(1202);

    /* the sweep runs through logAudit's opportunistic path — force it by
       resetting the module's cadence state via a fresh audit write with a
       very old data-retention setting (0 disables; the default 90 days
       covers our 200-day-old rows) */
    await db.platformSetting.upsert({
      where: { id: "global" },
      update: { auditLog: true, dataRetention: 90 },
      create: { id: "global", auditLog: true, dataRetention: 90 },
    });

    /* logAudit triggers pruneIfNeeded — but its 10-min cadence guard means
       a prior test's sweep could block this one. Drive it deterministically
       instead: call logAudit (its prune is fire-and-forget) and POLL until
       the old rows are gone (bounded wait). */
    await auditMod.logAudit({
      actorType: "admin",
      actorId: "qa",
      actorName: "qa",
      action: "instance.update",
      targetLabel: "qa-round-2",
    });

    let swept = false;
    for (let i = 0; i < 40; i++) {
      await new Promise((r) => setTimeout(r, 250));
      const remainingOld = await db.auditLog.count({
        where: { actorId: "seed" },
      });
      if (remainingOld === 0) {
        swept = true;
        break;
      }
    }
    expect(swept).toBe(true);

    /* the fresh rows SURVIVED (inside the window) */
    const kept = await db.auditLog.count({
      where: { actorId: { in: ["keep", "keep2"] } },
    });
    expect(kept).toBe(2);

    /* the QA-trigger row (just written, chained) survived too */
    const qaRow = await db.auditLog.findFirst({
      where: { actorId: "qa" },
    });
    expect(qaRow).not.toBeNull();
    expect(qaRow?.chainHash).not.toBeNull();
  });
});

describe("order idempotency retention sweep", () => {
  test("expired completed guards and stale in-flight holders are swept; fresh records survive", async () => {
    const DAY = 86_400_000;
    /* completed beyond the 24h window → dead */
    await db.orderIdempotency.create({
      data: {
        key: "sweep-old-completed",
        instanceId: "sweep-test",
        requestHash: "a".repeat(64),
        status: "completed",
        completedAt: new Date(Date.now() - 2 * DAY),
      },
    });
    /* stale in-flight (crashed holder) → dead */
    await db.orderIdempotency.create({
      data: {
        key: "sweep-stale-flight",
        instanceId: "sweep-test",
        requestHash: "b".repeat(64),
        status: "in_flight",
        createdAt: new Date(Date.now() - 10 * DAY),
      },
    });
    /* fresh completed (replay window open) → SURVIVES */
    await db.orderIdempotency.create({
      data: {
        key: "sweep-fresh-completed",
        instanceId: "sweep-test",
        requestHash: "c".repeat(64),
        status: "completed",
        completedAt: new Date(),
      },
    });
    /* fresh in-flight (twin still running) → SURVIVES */
    await db.orderIdempotency.create({
      data: {
        key: "sweep-fresh-flight",
        instanceId: "sweep-test",
        requestHash: "d".repeat(64),
        status: "in_flight",
        createdAt: new Date(),
      },
    });

    /* the sweep predicate, exercised directly (the route fires it
       opportunistically; the predicate is the contract) */
    const now = Date.now();
    const completedCutoff = new Date(now - 24 * 60 * 60 * 1000);
    const staleCutoff = new Date(now - 2 * 60 * 60 * 1000);
    const removed = await db.orderIdempotency.deleteMany({
      where: {
        OR: [
          { status: "completed", completedAt: { lt: completedCutoff } },
          { status: "in_flight", createdAt: { lt: staleCutoff } },
        ],
      },
    });
    expect(removed.count).toBe(2);

    const survivors = await db.orderIdempotency.findMany({
      where: { instanceId: "sweep-test" },
    });
    expect(survivors.map((r) => r.key).sort()).toEqual([
      "sweep-fresh-completed",
      "sweep-fresh-flight",
    ]);
  });
});
