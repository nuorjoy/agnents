/// <reference types="bun-types" />
/**
 * OWNER-DIRECTIVE REGRESSION — ROUND 138: invoice stamp/signature gating.
 *
 * «في جميع الأنظمة الـ100 لا تظهر (الختم، التوقيع) في الفواتير إذا كان
 * فارغاً واختبره انه يعمل باحترافية دون مشاكل» — when the workspace
 * carries no stamp/signature, the invoice paper must render NEITHER the
 * image block NOR the label/underline ceremony.
 *
 * Seams pinned here:
 *   1. UNIT — hasInvoiceAsset: the canonical empty ("" / null / undefined),
 *      whitespace, and payload-less data: URLs all gate OUT; real data
 *      URLs and http(s) URLs gate IN;
 *   2. SOURCE CONTRACT — ReceiptPaper gates BOTH the wrapper ceremony and
 *      each individual block through hasInvoiceAsset (a regression that
 *      goes back to raw truthiness fails here, not in a screenshot);
 *   3. SOURCE CONTRACT — no other component re-implements the gate with
 *      raw truthiness on signatureUrl/stampUrl.
 */
import { describe, test, expect } from "bun:test";
import { readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";

const { hasInvoiceAsset } = await import("@/lib/invoice-assets");

const PROJECT = join(import.meta.dir, "..", "..");
const SRC = join(PROJECT, "src");

describe("ROUND 138 — hasInvoiceAsset (the stamp/signature gating predicate)", () => {
  test("the canonical empties gate OUT (never render)", () => {
    expect(hasInvoiceAsset("")).toBe(false);
    expect(hasInvoiceAsset(" ")).toBe(false);
    expect(hasInvoiceAsset("   ")).toBe(false);
    expect(hasInvoiceAsset(null)).toBe(false);
    expect(hasInvoiceAsset(undefined)).toBe(false);
  });

  test("payload-less data: URLs gate OUT (they render as BROKEN images)", () => {
    expect(hasInvoiceAsset("data:")).toBe(false);
    expect(hasInvoiceAsset("data:image/png")).toBe(false);
    expect(hasInvoiceAsset("data:image/png;base64,")).toBe(false);
    expect(hasInvoiceAsset("data:,")).toBe(false);
    expect(hasInvoiceAsset(" data:image/png;base64, ")).toBe(false);
  });

  test("real payloads gate IN", () => {
    expect(hasInvoiceAsset("data:image/png;base64,iVBORw0KGgo=")).toBe(true);
    expect(hasInvoiceAsset("data:image/svg+xml,%3Csvg%3E%3C%2Fsvg%3E")).toBe(true);
    expect(hasInvoiceAsset("https://cdn.example.com/stamp.png")).toBe(true);
    expect(hasInvoiceAsset(" http://localhost:3000/sig.png ")).toBe(true);
  });
});

describe("ROUND 138 — ReceiptPaper source contract (the single gate)", () => {
  test("order-receipt.tsx gates the ceremony AND both blocks through hasInvoiceAsset", () => {
    const src = readFileSync(join(SRC, "components/site/order-receipt.tsx"), "utf8");
    expect(src).toContain('hasInvoiceAsset(identity.signatureUrl) || hasInvoiceAsset(identity.stampUrl)');
    expect(src).toContain('import { hasInvoiceAsset } from "@/lib/invoice-assets"');
    /* the raw-truthiness gates must be gone */
    expect(src).not.toContain("{identity.signatureUrl || identity.stampUrl ?");
    expect(src).not.toContain("{identity.signatureUrl ?");
    expect(src).not.toContain("{identity.stampUrl ?");
  });

  test("no component re-implements the gate with raw truthiness on the asset URLs", () => {
    /* The defect shape is a JSX render gate on the RAW asset value:
     *   {identity.signatureUrl ? (…)}            — single-asset gate
     *   {identity.signatureUrl || identity.stampUrl ? (…)}  — ceremony gate
     * Legitimate prop passes (`signatureUrl={… ?? ""}`), API coercions and
     * equality checks (`=== ""`) must NOT match — hence the lookaheads that
     * refuse `??` and `?.`. */
    const GATE_RE =
      /\{\s*[\w.]+\.(?:signatureUrl|stampUrl)(?:\s*\|\|\s*[\w.]+\.(?:signatureUrl|stampUrl))?\s*\?(?![?.])/;
    const offenders: string[] = [];
    const walk = (dir: string) => {
      for (const entry of readdirSync(dir, { withFileTypes: true })) {
        const p = join(dir, entry.name);
        if (entry.isDirectory()) {
          if (entry.name === "generated" || entry.name === "pg-client") continue;
          walk(p);
        } else if (/\.(tsx|ts)$/.test(entry.name)) {
          const src = readFileSync(p, "utf8");
          if (GATE_RE.test(src)) offenders.push(p);
        }
      }
    };
    walk(SRC);
    expect(offenders).toEqual([]);
  });
});
