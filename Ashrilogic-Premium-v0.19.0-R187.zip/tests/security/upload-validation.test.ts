/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — server-side image upload validation
 * (src/lib/server/upload-validation.ts).
 *
 * Task-2 fix under test: NOTHING about the client's claim is trusted —
 * declared MIME, base64 content, dimensions and size are all re-checked
 * against the buffer's actual magic bytes, and the image is re-encoded to
 * clean WebP before persistence (strips EXIF, embedded payloads, polyglots).
 *
 * Verified behaviors: valid PNG → re-encoded webp data URL; HTML/text
 * payloads labeled as images → rejected; SVG → rejected (script-capable
 * format); dimension caps (decompression-bomb guard); oversize input.
 *
 * NOTE (documented behavior, reported as a hardening observation): a GIF
 * buffer labeled image/png is NOT rejected outright — the actual-format
 * check only enforces "is one of the allowed raster families". The GIF is
 * re-encoded to WebP and the original bytes never survive, so the security
 * boundary (only sanitized, re-encoded bytes are persisted) holds; strict
 * declared-MIME === actual-format matching would be tighter defense-in-depth.
 */
import { describe, test, expect, beforeAll } from "bun:test";
import sharp from "sharp";
import {
  validateImageDataUrl,
  ImageValidationError,
} from "@/lib/server/upload-validation";

/** Real 1×1 PNG (solid dark red), verified decodable by sharp. */
const PNG_1x1_B64 =
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAACXBIWXMAAAPoAAAD6AG1e1JrAAAADElEQVR4nGM4IWcDAALUASNyYth2AAAAAElFTkSuQmCC";

/** Real 1×1 GIF (starts with the "GIF89a" magic). */
const GIF_1x1_B64 =
  "R0lGODlhAQABAIAAAExpcQrIPCH5BAUAAAAALAAAAAABAAEAAAICTAEAOw==";

function dataUrl(mime: string, bytes: string): string {
  return `data:${mime};base64,${bytes}`;
}

function b64(text: string): string {
  return Buffer.from(text, "utf8").toString("base64");
}

/** wide PNG (5000×100 — over the 4096 dimension cap, tiny file). */
let widePngUrl: string;
/** 2.5 MB of random bytes preceded by a genuine PNG magic header. */
let oversizePngUrl: string;

beforeAll(async () => {
  const wide = await sharp({
    create: { width: 5000, height: 100, channels: 3, background: { r: 0, g: 80, b: 160 } },
  })
    .png()
    .toBuffer();
  widePngUrl = dataUrl("image/png", wide.toString("base64"));

  const pngMagic = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  const bomb = Buffer.concat([pngMagic, Buffer.alloc(2.5 * 1024 * 1024, 0x41)]);
  oversizePngUrl = dataUrl("image/png", bomb.toString("base64"));
});

async function expectRejected(input: string, message?: string): Promise<void> {
  try {
    const out = await validateImageDataUrl(input);
    throw new Error(`expected ImageValidationError, got output: ${out.slice(0, 40)}...`);
  } catch (error) {
    expect(error).toBeInstanceOf(ImageValidationError);
    if (message) {
      expect((error as Error).message).toBe(message);
    }
  }
}

describe("upload-validation — the happy path re-encodes", () => {
  test("valid 1×1 PNG resolves to a re-encoded webp data URL", async () => {
    const out = await validateImageDataUrl(dataUrl("image/png", PNG_1x1_B64));
    expect(out.startsWith("data:image/webp;base64,")).toBe(true);
    // the ORIGINAL bytes must not survive — only the sanitized re-encode
    expect(out.includes(PNG_1x1_B64)).toBe(false);
  });

  test("valid JPEG-labeled and WebP-labeled inputs also re-encode to webp", async () => {
    const jpeg = await sharp({
      create: { width: 8, height: 8, channels: 3, background: { r: 255, g: 255, b: 0 } },
    })
      .jpeg()
      .toBuffer();
    const out = await validateImageDataUrl(dataUrl("image/jpeg", jpeg.toString("base64")));
    expect(out.startsWith("data:image/webp;base64,")).toBe(true);
  });
});

describe("upload-validation — hostile payloads are rejected", () => {
  test("HTML payload labeled image/png → ImageValidationError (magic bytes)", async () => {
    await expectRejected(
      dataUrl("image/png", b64("<html><body><script>alert('xss')</script></body></html>")),
      "File content is not a valid image"
    );
  });

  test("SVG bytes labeled image/png (spoofed magic) → rejected", async () => {
    await expectRejected(
      dataUrl(
        "image/png",
        b64('<svg xmlns="http://www.w3.org/2000/svg" onload="alert(1)"><script>alert(2)</script></svg>')
      ),
      "File content is not a valid image"
    );
  });

  test("SVG data URL (honest label) → \"SVG images are not supported\"", async () => {
    await expectRejected(
      dataUrl("image/svg+xml", b64('<svg xmlns="http://www.w3.org/2000/svg"></svg>')),
      "SVG images are not supported"
    );
  });

  test("non-data-URL input and unsupported declared MIME → rejected", async () => {
    await expectRejected("http://evil.example/payload.png", "Unsupported image format");
    await expectRejected(
      dataUrl("video/mp4", b64("anything")),
      "Unsupported image format"
    );
  });

  test("corrupt base64 body with a valid PNG magic prefix → rejected", async () => {
    // decodes to something with the PNG magic but garbage beyond it
    const garbage = Buffer.concat([
      Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
      Buffer.alloc(64, 0xff),
    ]);
    await expectRejected(dataUrl("image/png", garbage.toString("base64")));
  });
});

describe("upload-validation — declared-MIME vs actual-format (allowed families)", () => {
  test("GIF labeled image/png is NORMALIZED, never reflected: output is clean WebP", async () => {
    // See the file header note: the actual-format check enforces membership
    // in the allowed raster families, not declared==actual. The security
    // property asserted here: the persisted value is a re-encoded WebP that
    // contains NONE of the original GIF bytes.
    const out = await validateImageDataUrl(dataUrl("image/png", GIF_1x1_B64));
    expect(out.startsWith("data:image/webp;base64,")).toBe(true);
    expect(out.includes(GIF_1x1_B64)).toBe(false);
    // sanity: the same GIF with an HONEST label behaves identically
    const honest = await validateImageDataUrl(dataUrl("image/gif", GIF_1x1_B64));
    expect(honest.startsWith("data:image/webp;base64,")).toBe(true);
  });
});

describe("upload-validation — decompression-bomb and size caps", () => {
  test("5000×100 PNG exceeds the dimension limit before pixel decode", async () => {
    await expectRejected(widePngUrl, "Image dimensions exceed the allowed limit");
  });

  test("oversize input (> 2 MB) with a genuine PNG magic header → rejected", async () => {
    await expectRejected(oversizePngUrl, "Image exceeds the allowed size");
  });

  test("tightened maxOutputBytes cap fires on the re-encode (1 byte allows nothing)", async () => {
    // the re-encoded WebP of even a 1×1 PNG is always > 1 byte — proves the
    // output-size cap is enforced on the PERSISTED value, not the input
    try {
      await validateImageDataUrl(dataUrl("image/png", PNG_1x1_B64), { maxOutputBytes: 1 });
      throw new Error("expected ImageValidationError for maxOutputBytes=1");
    } catch (error) {
      expect(error).toBeInstanceOf(ImageValidationError);
      expect((error as Error).message).toBe("Image exceeds the allowed size after compression");
    }
  });
});
