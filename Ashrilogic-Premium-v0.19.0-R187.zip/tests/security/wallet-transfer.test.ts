/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 145 (Task 145-fix-sec): the inter-wallet
 * TRANSFER hardening battery.
 *
 * The R145 security audit findings this suite pins:
 *  1. SOURCE-ORDER — the transfer controller's non-bypassable gate order
 *     (OWNER_ONLY 403 → PIN_NOT_SET 428 → the Argon2id PIN verify → the
 *     SHARED fail-closed `pin-fail:${id}` budget on a wrong PIN → the
 *     server-side amount parse → the atomic engine);
 *  2. THE ENGINE — self-transfer / unknown-number / trashed-receiver /
 *     bounds rejections, the zero-sum atomic commit (BOTH ledger rows +
 *     BOTH activity rows inside ONE $transaction, one shared reference),
 *     and the ROUND-145 receiver RE-RESOLUTION inside that transaction
 *     (a receiver trashed between the pre-check read and the commit must
 *     never be credited — applyWalletDeltaTx matches by id only);
 *  3. THE LOOKUP LEAK — WalletLookupDTO carries IDENTITY ONLY: no
 *     walletMinor anywhere (runtime-proven against the real engine, and
 *     pinned in the server DTO, the client types.ts DTO, and the dialog
 *     source which must never render it);
 *  4. THE SHARED PIN BUDGET — one secret (shiftCodeHash), ONE fail-closed
 *     `pin-fail:${id}` 6/10min budget across BOTH surfaces (the transfer
 *     controller AND the shift-open route — the fail-open action throttle
 *     stays separate), the admin per-ACCOUNT login throttle (the
 *     instance-login twin's idiom), the declarative failClosed throttle
 *     option on routeHandler, the P2034 deadlock → WALLET_CONFLICT
 *     mapping, the CSPRNG wallet-number allocation, and the loyalty
 *     resync permission riding the session guard.
 *
 * Style: the wallet-cas.test.ts discipline — the ENGINE tests drive the
 * REAL module against the REAL throwaway test database (dynamic import
 * AFTER ensureDemoEnv redirected DATABASE_URL); the guard/order/shape
 * contracts are pinned with source-pattern assertions (the
 * mutation-coverage / route-guards discipline). Fully offline,
 * deterministic.
 */

import { beforeAll, afterAll, describe, expect, test } from "bun:test";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { ensureDemoEnv, getTestDb, type TestDb } from "./test-setup";

/* CANONICAL ISOLATION PATTERN (test-setup's contract): every module that
 * transitively binds `@/lib/db` is imported DYNAMICALLY in beforeAll —
 * AFTER ensureDemoEnv() redirected DATABASE_URL to the throwaway test db.
 * Reading SOURCE files is a pure fs read — it loads no modules, so the
 * fixtures below may sit at module scope. */
ensureDemoEnv();

/* ------------------------------------------------------------------ */
/* source fixtures (pure reads — no module loading)                    */
/* ------------------------------------------------------------------ */

const REPO_ROOT = join(import.meta.dir, "..", "..");
const read = (rel: string): string => readFileSync(join(REPO_ROOT, rel), "utf8");

const walletSrc = read("src/lib/server/wallet.ts");
const controllerSrc = read("src/server/domains/wallet/controller.ts");
const shiftsSrc = read("src/app/api/instances/[id]/shifts/route.ts");
const adminLoginSrc = read("src/app/api/admin/login/route.ts");
const wrapperSrc = read("src/lib/server/route.ts");
const loyaltySrc = read("src/app/api/instances/[id]/loyalty/resync/route.ts");
const widgetsSrc = read("src/components/dashboard/wallet-widgets.tsx");
const typesSrc = read("src/lib/types.ts");

/** The span of one export inside a source file (from its marker to the
 *  next export or EOF) — the unit the ORDER assertions reason about.
 *  Pure: a missing marker yields "" (tests fail loudly on the follow-up
 *  containment assertions). */
function spanOf(src: string, marker: string): string {
  const start = src.indexOf(marker);
  if (start === -1) return "";
  const rest = src.slice(start + marker.length);
  const next = rest.search(/\nexport (const|async function|function|interface|type) /);
  return next === -1 ? src.slice(start) : src.slice(start, start + marker.length + next);
}

/** The body of one exported interface (marker → its closing line). */
function interfaceSpan(src: string, name: string): string {
  const start = src.indexOf(`export interface ${name}`);
  if (start === -1) return "";
  const end = src.indexOf("\n}", start);
  return end === -1 ? "" : src.slice(start, end + 2);
}

/** indexOf that FAILS the test when the needle is absent — an order
 *  assertion against a missing marker is meaningless. */
function at(src: string, needle: string): number {
  const idx = src.indexOf(needle);
  expect(idx).toBeGreaterThan(-1);
  return idx;
}

/* ------------------------------------------------------------------ */
/* db fixtures (the throwaway test database)                            */
/* ------------------------------------------------------------------ */

const SENDER = "wtr-145-sender";
const RECEIVER = "wtr-145-receiver";
const TRASHED = "wtr-145-trashed";
const SENDER_ORG = "مرسل الاختبار";
const RECEIVER_ORG = "مستقبِل الاختبار";
const SENDER_NO = 10_000_145;
const RECEIVER_NO = 10_000_146;
const TRASHED_NO = 10_000_147;
/** An 8-digit number guaranteed unallocated in the throwaway db. */
const UNKNOWN_NO = 12_345_678;

let db: TestDb;
let wallet: typeof import("@/lib/server/wallet");

async function seedInstance(
  id: string,
  systemId: string,
  orgName: string,
  walletNo: number,
  walletMinor: number,
  trashed = false
): Promise<void> {
  await db.instance.deleteMany({ where: { id } });
  await db.instance.create({
    data: {
      id,
      systemId,
      orgJson: JSON.stringify({ name: orgName, currency: "SAR" }),
      adminJson: "{}",
      prefsJson: "{}",
      modulesJson: "[]",
      walletNo,
      walletMinor,
      ...(trashed ? { deletedAt: new Date() } : {}),
    },
  });
}

beforeAll(async () => {
  db = await getTestDb();
  wallet = await import("@/lib/server/wallet");
  await seedInstance(SENDER, "products", SENDER_ORG, SENDER_NO, 100_000);
  await seedInstance(RECEIVER, "services", RECEIVER_ORG, RECEIVER_NO, 0);
  await seedInstance(TRASHED, "products", "محذوفة", TRASHED_NO, 5_000, true);
});

afterAll(async () => {
  /* the ledger/activity rows cascade with their instances */
  await db.instance.deleteMany({ where: { id: { in: [SENDER, RECEIVER, TRASHED] } } });
});

/* ------------------------------------------------------------------ */
/* 1 — the controller's non-bypassable transfer gate order             */
/* ------------------------------------------------------------------ */

describe("ROUND 145 — the transfer controller's gate order (source)", () => {
  const span = spanOf(controllerSrc, "export const tenantTransferCreate");

  test("OWNER_ONLY (403) → PIN_NOT_SET (428) → Argon2id PIN verify → amount parse → the engine", () => {
    expect(span.length).toBeGreaterThan(0);
    expect(at(span, "OWNER_ONLY")).toBeLessThan(at(span, "PIN_NOT_SET"));
    expect(at(span, "PIN_NOT_SET")).toBeLessThan(at(span, "verifyPasswordArgon2id("));
    expect(at(span, "verifyPasswordArgon2id(")).toBeLessThan(at(span, "parseAmountInputToMinor("));
    expect(at(span, "parseAmountInputToMinor(")).toBeLessThan(at(span, "transferWalletFunds("));
    expect(span).toContain("{ status: 403 }");
    expect(span).toContain("{ status: 428 }");
  });

  test("a WRONG PIN burns the SHARED fail-closed `pin-fail:${id}` budget BEFORE the 401", () => {
    const pinVerify = at(span, "verifyPasswordArgon2id(");
    const shared = span.search(
      /rateLimited\(`pin-fail:\$\{id\}`,\s*PIN_FAIL_RULE,\s*\{ failClosed: true \}\)/
    );
    expect(shared).toBeGreaterThan(-1);
    expect(pinVerify).toBeLessThan(shared);
    expect(shared).toBeLessThan(at(span, "PIN_INVALID"));
    /* the rule itself: 6 wrong PINs / 10 min, declared once and shared */
    expect(controllerSrc).toMatch(/PIN_FAIL_RULE = \{ limit: 6, windowMs: 10 \* 60 \* 1000 \}/);
    /* the old per-surface key is gone — one secret, ONE budget */
    expect(controllerSrc).not.toContain("wallet-pin:");
  });

  test("the transfer throttle plan is declared fail-closed (a limiter outage refuses money movement)", () => {
    expect(span).toMatch(/failClosed: true/);
  });
});

/* ------------------------------------------------------------------ */
/* 2 — the engine: source contract (in-tx receiver + zero-sum + P2034)  */
/* ------------------------------------------------------------------ */

describe("ROUND 145 — the engine's atomic shape (source)", () => {
  const engine = spanOf(walletSrc, "export async function transferWalletFunds");

  /** The $transaction callback body — from the interactive-transaction
   *  open to the transfer's own catch (the only `catch (error)` in the
   *  engine; the org-name fallback uses a bare `catch`). */
  function txBody(): string {
    const open = at(engine, "db.$transaction(async (tx) => {");
    const close = engine.indexOf("} catch (error) {", open);
    expect(close).toBeGreaterThan(open);
    return engine.slice(open, close);
  }

  test("the receiver is RE-RESOLVED inside the $transaction callback (FIX: no credit onto a concurrently trashed wallet)", () => {
    const body = txBody();
    expect(body).toContain("tx.instance.findFirst");
    expect(body).toContain("walletNo: toWalletNo");
    expect(body).toContain("deletedAt: null");
    expect(body).toContain("WALLET_NOT_FOUND");
    /* the credit CAS targets the FRESH row's id */
    expect(body).toContain("applyWalletDeltaTx(tx, receiverTx.id");
  });

  test("zero-sum: BOTH ledger deltas run inside that ONE transaction", () => {
    const body = txBody();
    expect((body.match(/applyWalletDeltaTx\(tx,/g) ?? []).length).toBe(2);
  });

  test("a P2034 write conflict maps to the WALLET_CONFLICT contract, never a generic 500", () => {
    expect(walletSrc).toContain('const PRISMA_TX_WRITE_CONFLICT = "P2034"');
    const catchIdx = at(engine, "} catch (error) {");
    const conflict = engine.search(/isTransactionWriteConflict\(error\)/);
    expect(conflict).toBeGreaterThan(catchIdx);
    const mapped = engine.indexOf('code: "WALLET_CONFLICT"', conflict);
    expect(mapped).toBeGreaterThan(-1);
    expect(conflict).toBeLessThan(mapped);
    expect(mapped).toBeLessThan(engine.indexOf("console.error", catchIdx));
  });

  test("wallet numbers come from the CSPRNG (crypto.randomInt), never Math.random", () => {
    const rng = walletSrc.slice(at(walletSrc, "function randomWalletNo"));
    const body = rng.slice(0, rng.indexOf("\n}"));
    expect(body).toContain("randomInt(WALLET_NO_MIN, WALLET_NO_MAX + 1)");
    expect(body).not.toContain("Math.random");
    expect(walletSrc).toMatch(/import \{[^}]*\brandomInt\b[^}]*\} from "node:crypto"/);
  });
});

/* ------------------------------------------------------------------ */
/* 3 — the engine: unit contract against the real throwaway db          */
/* ------------------------------------------------------------------ */

describe("ROUND 145 — transferWalletFunds (the REAL engine, throwaway db)", () => {
  test("self-transfer → WALLET_SELF (422)", async () => {
    const result = await wallet.transferWalletFunds({
      fromInstanceId: SENDER,
      toWalletNo: SENDER_NO,
      amountMinor: 500,
      note: "",
      actorName: "battery",
    });
    expect(result).toMatchObject({ ok: false, status: 422, code: "WALLET_SELF" });
  });

  test("an unknown wallet number → WALLET_NOT_FOUND (404); a TRASHED receiver is equally gone", async () => {
    const unknown = await wallet.transferWalletFunds({
      fromInstanceId: SENDER,
      toWalletNo: UNKNOWN_NO,
      amountMinor: 500,
      note: "",
      actorName: "battery",
    });
    expect(unknown).toMatchObject({ ok: false, status: 404, code: "WALLET_NOT_FOUND" });
    const trashed = await wallet.transferWalletFunds({
      fromInstanceId: SENDER,
      toWalletNo: TRASHED_NO,
      amountMinor: 500,
      note: "",
      actorName: "battery",
    });
    expect(trashed).toMatchObject({ ok: false, status: 404, code: "WALLET_NOT_FOUND" });
  });

  test("the amount bounds (1..10,000 SAR in minor units) are enforced", async () => {
    expect(wallet.MIN_TRANSFER_MINOR).toBe(100);
    expect(wallet.MAX_TRANSFER_MINOR).toBe(1_000_000);
    const zero = await wallet.transferWalletFunds({
      fromInstanceId: SENDER,
      toWalletNo: RECEIVER_NO,
      amountMinor: 0,
      note: "",
      actorName: "battery",
    });
    expect(zero).toMatchObject({ ok: false, status: 422, code: "TRANSFER_AMOUNT" });
    const negative = await wallet.transferWalletFunds({
      fromInstanceId: SENDER,
      toWalletNo: RECEIVER_NO,
      amountMinor: -500,
      note: "",
      actorName: "battery",
    });
    expect(negative).toMatchObject({ ok: false, status: 422, code: "TRANSFER_AMOUNT" });
    const below = await wallet.transferWalletFunds({
      fromInstanceId: SENDER,
      toWalletNo: RECEIVER_NO,
      amountMinor: wallet.MIN_TRANSFER_MINOR - 1,
      note: "",
      actorName: "battery",
    });
    expect(below).toMatchObject({ ok: false, status: 422, code: "TRANSFER_MIN" });
    const above = await wallet.transferWalletFunds({
      fromInstanceId: SENDER,
      toWalletNo: RECEIVER_NO,
      amountMinor: wallet.MAX_TRANSFER_MINOR + 1,
      note: "",
      actorName: "battery",
    });
    expect(above).toMatchObject({ ok: false, status: 422, code: "TRANSFER_MAX" });
  });

  test("the happy path commits ONE zero-sum transfer: both balances, two ledger rows sharing one reference + linkId, two activity rows", async () => {
    /* fresh, order-independent fixtures */
    await db.walletTxn.deleteMany({ where: { instanceId: { in: [SENDER, RECEIVER] } } });
    await db.activity.deleteMany({ where: { instanceId: { in: [SENDER, RECEIVER] } } });
    await db.instance.update({ where: { id: SENDER }, data: { walletMinor: 100_000 } });
    await db.instance.update({ where: { id: RECEIVER }, data: { walletMinor: 0 } });

    const result = await wallet.transferWalletFunds({
      fromInstanceId: SENDER,
      toWalletNo: RECEIVER_NO,
      amountMinor: 25_000,
      note: "ROUND 145 battery",
      actorName: "battery@ashrilogic.test",
    });
    expect(result.ok).toBe(true);
    if (!result.ok) throw new Error("the transfer was expected to succeed");
    const { receipt } = result;
    expect(receipt.amountMinor).toBe(25_000);
    expect(receipt.senderBalanceAfterMinor).toBe(75_000);
    expect(receipt.receiverBalanceAfterMinor).toBe(25_000);
    expect(receipt.reference).toMatch(/^TRF-/);
    /* FIX 3 — the receipt's receiver copy carries NO lookup balance either */
    expect("walletMinor" in receipt.receiver).toBe(false);

    const [senderRow, receiverRow] = await Promise.all([
      db.instance.findUniqueOrThrow({ where: { id: SENDER }, select: { walletMinor: true } }),
      db.instance.findUniqueOrThrow({ where: { id: RECEIVER }, select: { walletMinor: true } }),
    ]);
    expect(senderRow.walletMinor).toBe(75_000);
    expect(receiverRow.walletMinor).toBe(25_000);
    /* the zero-sum law: money moved, never minted nor destroyed */
    expect(senderRow.walletMinor + receiverRow.walletMinor).toBe(100_000);

    const ledger = await db.walletTxn.findMany({
      where: { reference: receipt.reference },
      orderBy: { amountMinor: "asc" },
    });
    expect(ledger).toHaveLength(2);
    expect(ledger.map((row) => row.kind)).toEqual(["transfer", "transfer"]);
    expect(ledger.map((row) => row.amountMinor)).toEqual([-25_000, 25_000]);
    /* one shared linkId joins the two rows of the SAME transfer */
    expect(new Set(ledger.map((row) => row.linkId)).size).toBe(1);
    expect(ledger[0]?.instanceId).toBe(SENDER);
    expect(ledger[0]?.balanceAfterMinor).toBe(75_000);
    expect(ledger[1]?.instanceId).toBe(RECEIVER);
    expect(ledger[1]?.balanceAfterMinor).toBe(25_000);

    const activities = await db.activity.findMany({
      where: { kind: "actWalletTransfer", instanceId: { in: [SENDER, RECEIVER] } },
    });
    expect(activities).toHaveLength(2);
    expect(activities.map((row) => row.instanceId).sort()).toEqual([RECEIVER, SENDER]);
    const outMeta = JSON.parse(
      activities.find((row) => row.instanceId === SENDER)?.metaJson ?? "{}"
    ) as Record<string, unknown>;
    expect(outMeta).toMatchObject({
      direction: "out",
      to: RECEIVER_ORG,
      walletNo: RECEIVER_NO,
      reference: receipt.reference,
    });
    const inMeta = JSON.parse(
      activities.find((row) => row.instanceId === RECEIVER)?.metaJson ?? "{}"
    ) as Record<string, unknown>;
    expect(inMeta).toMatchObject({ direction: "in", from: "battery@ashrilogic.test" });
  });

  test("INSUFFICIENT_FUNDS fails closed — the failed debit commits NOTHING (all-or-nothing)", async () => {
    await db.instance.update({ where: { id: SENDER }, data: { walletMinor: 0 } });
    const receiverBefore = (
      await db.instance.findUniqueOrThrow({ where: { id: RECEIVER }, select: { walletMinor: true } })
    ).walletMinor;
    const txnsBefore = await db.walletTxn.count({ where: { instanceId: RECEIVER } });

    const result = await wallet.transferWalletFunds({
      fromInstanceId: SENDER,
      toWalletNo: RECEIVER_NO,
      amountMinor: 500,
      note: "",
      actorName: "battery",
    });
    expect(result).toMatchObject({ ok: false, status: 409, code: "INSUFFICIENT_FUNDS" });
    expect(await db.walletTxn.count({ where: { instanceId: RECEIVER } })).toBe(txnsBefore);
    expect(
      (await db.instance.findUniqueOrThrow({ where: { id: RECEIVER }, select: { walletMinor: true } }))
        .walletMinor
    ).toBe(receiverBefore);
  });
});

/* ------------------------------------------------------------------ */
/* 4 — the lookup DTO: no receiver balance, anywhere                    */
/* ------------------------------------------------------------------ */

describe("ROUND 145 — the receiver lookup leaks NO balance (identity only)", () => {
  test("a resolved receiver carries exactly { walletNo, orgName, systemId, demo } — never walletMinor", async () => {
    const result = await wallet.lookupWalletByNo(RECEIVER_NO, SENDER);
    expect(result.ok).toBe(true);
    if (!result.ok) throw new Error("the lookup was expected to resolve");
    expect(Object.keys(result.receiver).sort()).toEqual(["demo", "orgName", "systemId", "walletNo"]);
    expect("walletMinor" in result.receiver).toBe(false);
    expect(result.receiver.orgName).toBe(RECEIVER_ORG);
    expect(result.receiver.systemId).toBe("services");
    expect(result.receiver.demo).toBe(false);
    expect(result.receiver.walletNo).toBe(RECEIVER_NO);
  });

  test("self lookup → WALLET_SELF; unknown + trashed numbers → WALLET_NOT_FOUND", async () => {
    expect(await wallet.lookupWalletByNo(SENDER_NO, SENDER)).toMatchObject({
      ok: false,
      code: "WALLET_SELF",
    });
    expect(await wallet.lookupWalletByNo(UNKNOWN_NO, SENDER)).toMatchObject({
      ok: false,
      code: "WALLET_NOT_FOUND",
    });
    expect(await wallet.lookupWalletByNo(TRASHED_NO, SENDER)).toMatchObject({
      ok: false,
      code: "WALLET_NOT_FOUND",
    });
  });

  test("the DTO type surfaces pin the identity-only shape (server engine + client types + the dialog)", () => {
    const serverDto = interfaceSpan(walletSrc, "WalletLookupDTO");
    expect(serverDto.length).toBeGreaterThan(0);
    expect(serverDto).toContain("walletNo: number");
    expect(serverDto).toContain("orgName: string");
    expect(serverDto).toContain("systemId: string");
    expect(serverDto).toContain("demo: boolean");
    expect(serverDto).not.toContain("Minor");

    const clientDto = interfaceSpan(typesSrc, "WalletLookupDTO");
    expect(clientDto.length).toBeGreaterThan(0);
    expect(clientDto).toContain("walletNo: number");
    expect(clientDto).toContain("demo: boolean");
    expect(clientDto).not.toContain("Minor");

    /* the transfer dialog never rendered the removed field (R144 already
     * rendered org + system + number only — pinned so it stays that way) */
    expect(widgetsSrc).not.toMatch(/receiver\.walletMinor/);
    expect(widgetsSrc).not.toMatch(/receiverWalletMinor/);
  });
});

/* ------------------------------------------------------------------ */
/* 5 — the shared PIN budget + the sibling hardening (source)           */
/* ------------------------------------------------------------------ */

describe("ROUND 145 — the SHARED pin-fail budget on the shift-open surface", () => {
  test("the wrong-code branch burns `pin-fail:${id}` fail-closed at 6/10min — the SAME key + rule the transfer controller burns", () => {
    expect(shiftsSrc).toMatch(/PIN_FAIL_RULE = \{ limit: 6, windowMs: 10 \* 60 \* 1000 \}/);
    const shared = shiftsSrc.search(
      /rateLimited\(`pin-fail:\$\{id\}`,\s*PIN_FAIL_RULE,\s*\{ failClosed: true \}\)/
    );
    expect(shared).toBeGreaterThan(-1);
    const wrongCode = at(shiftsSrc, "verifyPasswordArgon2id(");
    expect(wrongCode).toBeLessThan(shared);
    expect(shared).toBeLessThan(at(shiftsSrc, "SHIFT_CODE_INVALID"));
  });

  test("the shift-open ACTION throttle stays separate (fail-open, its own key)", () => {
    expect(shiftsSrc).toMatch(/rateLimited\(`shift-open:\$\{id\}`,\s*SHIFT_CODE_RULE\)/);
  });

  test("the 429 envelope mirrors the controller's pin-fail response", () => {
    expect(shiftsSrc).toContain('"Too many incorrect PIN attempts — try again later"');
    expect(controllerSrc).toContain('"Too many incorrect PIN attempts — try again later"');
  });
});

describe("ROUND 145 — the admin per-ACCOUNT login throttle", () => {
  test("an account-only `admin-login-user:` rule (8/10min, fail-closed) is applied alongside the ip rules", () => {
    expect(adminLoginSrc).toMatch(/LOGIN_USER_RULE = \{ limit: 8, windowMs: 10 \* 60 \* 1000 \}/);
    /* ROUND 146 — the account key is BLIND-INDEXED (email-shaped handles
     * never persist as plaintext PII in the durable limiter/backup): the
     * pattern pins the accountKey variable + its blindIndex derivation. */
    const userRule = adminLoginSrc.search(
      /rateLimited\(`admin-login-user:\$\{accountKey\}`,\s*LOGIN_USER_RULE,\s*\{ failClosed: true \}\)/
    );
    expect(userRule).toBeGreaterThan(-1);
    expect(adminLoginSrc).toMatch(/const accountKey = blindIndex\(username\.trim\(\)\) \?\? ""/);
    /* both prior rules remain applied (the ip aggregate + ip+accountKey) */
    expect(adminLoginSrc).toContain("admin-login-ip:");
    expect(adminLoginSrc).toContain("admin-login:");
    /* it answers AFTER the existing checks — the instance twin's order */
    expect(adminLoginSrc.indexOf("admin-login-ip:")).toBeLessThan(userRule);
  });

  test("the 429 mapping mirrors the instance login twin's account-scoped message", () => {
    expect(adminLoginSrc).toContain('"Too many sign-in attempts for this account, please try again later"');
  });
});

describe("ROUND 145 — the declarative failClosed throttle option + the loyalty guard", () => {
  test("ThrottlePlan declares failClosed and runGuardPlan threads it into rateLimited", () => {
    const plan = interfaceSpan(wrapperSrc, "ThrottlePlan");
    expect(plan.length).toBeGreaterThan(0);
    expect(plan).toMatch(/failClosed\?: boolean/);
    expect(wrapperSrc).toContain(
      "rateLimited(key, plan.rateLimit.rule, { failClosed: plan.rateLimit.failClosed })"
    );
  });

  test("the loyalty resync permission rides the session guard (the inline assert call is gone)", () => {
    expect(loyaltySrc).toMatch(/requireInstanceAccess\(id, req, \{ permission: "modules\.edit" \}\)/);
    /* no inline permission assert CALL remains (the ROUND-145 comment may
     * still NAME the helper it replaced — documentation, not a call) */
    expect(loyaltySrc).not.toMatch(/await assertInstancePermission\(/);
  });
});
