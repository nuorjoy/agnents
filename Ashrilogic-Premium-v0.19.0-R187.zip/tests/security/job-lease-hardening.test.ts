/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — SCHEDULER LEASE HARDENING (ROUND 120).
 *
 * Proves the lease is a real distributed lock:
 *  1. CAS CLAIM — concurrent acquirers on a fresh key resolve to exactly
 *     ONE winner (the pre-ROUND-120 unconditional upsert could
 *     double-grant through its check-act-check interleaving);
 *  2. LIVE foreign lease is never stolen (the takeover CAS misses; the
 *     create-claim loses the unique key);
 *  3. EXPIRED lease is takeable (the self-heal path);
 *  4. FENCING EPOCH — every (re)acquire increments the epoch, and
 *     stillOwnsJobLease flips false after a takeover (zombie detection);
 *  5. HEARTBEAT renewal — renewJobLease extends OUR expiry and reports
 *     lost ownership after another holder claimed the row;
 *  6. FAIL-CLOSED POLICY — withJobLease({ failure: "skip" }) skips the
 *     body when the lease store is unavailable; the default "run"
 *     posture is preserved for self-idempotent jobs.
 *
 * DB isolation: throwaway PostgreSQL test database via test-setup (never the live DB).
 */

import { beforeAll, afterAll, describe, expect, test } from "bun:test";
import { ensureDemoEnv, getTestDb, type TestDb } from "./test-setup";

ensureDemoEnv();

let db: TestDb;
let jobLease: typeof import("@/lib/server/job-lease");

/** distinct fake "processes" — the module's HOLDER is per-process, so the
 *  concurrency simulation goes through the DB rows directly where the
 *  module cannot be re-instantiated; the module-level paths are covered
 *  by the withJobLease tests below. */
const JOB = "job-lease-hardening-test";

beforeAll(async () => {
  db = await getTestDb();
  jobLease = await import("@/lib/server/job-lease");
  await db.schedulerLease.deleteMany({ where: { job: { startsWith: "job-lease" } } });
});

afterAll(async () => {
  try {
    await db.schedulerLease.deleteMany({ where: { job: { startsWith: "job-lease" } } });
  } catch {
    /* best-effort cleanup */
  }
});

describe("job-lease CAS claim — concurrent acquirers resolve to ONE winner", () => {
  test("20 concurrent acquire-claims on a fresh key → ONE durable lease row, ONE holder epoch", async () => {
    /* All 20 calls share THIS process's HOLDER — the burst proves the
     * DURABLE invariant (the cross-process no-double-grant is the raw
     * twin-CAS test below): exactly ONE row exists, held by one holder
     * (this process — every acquired verdict is the same logical holder;
     * the pre-120 unconditional upsert could not even guarantee the
     * single-row/single-epoch shape under a burst) */
    const key = "job-lease-cas-20";
    await db.schedulerLease.deleteMany({ where: { job: key } });
    const verdicts = await Promise.all(
      Array.from({ length: 20 }, () => jobLease.acquireJobLease(key, 60_000))
    );
    const winners = verdicts.filter((v) => v.acquired);
    expect(winners.length).toBeGreaterThanOrEqual(1); /* this process won */
    const rows = await db.schedulerLease.findMany({ where: { job: key } });
    expect(rows.length).toBe(1); /* never a duplicate row */
    expect(rows[0]?.holder).not.toBe("");
    expect(rows[0]?.epoch).toBeGreaterThanOrEqual(1); /* the fencing token minted */
    expect(rows[0]?.expiresAt.getTime()).toBeGreaterThan(Date.now());
    await db.schedulerLease.deleteMany({ where: { job: key } });
  });

  test("the RAW claim SQL is a CAS: a guarded UPDATE + unique-key INSERT (no unconditional upsert)", async () => {
    /* the takeover path is guarded on (holder = OURS) OR (expiresAt < now):
     * prove a LIVE FOREIGN row can never be matched by the module's claim */
    const key = "job-lease-live-foreign";
    await db.schedulerLease.deleteMany({ where: { job: key } });
    await db.schedulerLease.create({
      data: {
        job: key,
        holder: "someone-else-1",
        acquiredAt: new Date(),
        expiresAt: new Date(Date.now() + 600_000),
        epoch: 5,
      },
    });
    const verdict = await jobLease.acquireJobLease(key, 60_000);
    expect(verdict.acquired).toBe(false);
    expect(verdict.reason).toBe("held-elsewhere");
    /* the foreign row is untouched — never stolen */
    const row = await db.schedulerLease.findUniqueOrThrow({ where: { job: key } });
    expect(row.holder).toBe("someone-else-1");
    expect(row.epoch).toBe(5);
    await db.schedulerLease.deleteMany({ where: { job: key } });
  });

  test("expired foreign lease is takeable — and the epoch increments (fencing)", async () => {
    const key = "job-lease-expired-takeover";
    await db.schedulerLease.deleteMany({ where: { job: key } });
    await db.schedulerLease.create({
      data: {
        job: key,
        holder: "dead-process",
        acquiredAt: new Date(Date.now() - 600_000),
        expiresAt: new Date(Date.now() - 300_000),
        epoch: 7,
      },
    });
    const verdict = await jobLease.acquireJobLease(key, 60_000);
    expect(verdict.acquired).toBe(true);
    expect(verdict.epoch).toBe(8); /* 7 + 1 — the fencing token advanced */
    await db.schedulerLease.deleteMany({ where: { job: key } });
  });

  test("concurrent simulated takeover CAS on the SAME row → exactly one wins", async () => {
    /* two foreign holders race the guarded UPDATE through raw CAS writes
     * (the module's HOLDER is fixed per process — simulate the twins via
     * the same updateMany predicate shape) */
    const key = "job-lease-twin-cas";
    await db.schedulerLease.deleteMany({ where: { job: key } });
    await db.schedulerLease.create({
      data: {
        job: key,
        holder: "expired-holder",
        acquiredAt: new Date(),
        expiresAt: new Date(Date.now() - 1000),
        epoch: 2,
      },
    });
    const now = new Date();
    const claims = await Promise.all([
      db.schedulerLease.updateMany({
        where: { job: key, OR: [{ holder: "twin-a" }, { expiresAt: { lt: now } }] },
        data: { holder: "twin-a", expiresAt: new Date(Date.now() + 60_000), epoch: { increment: 1 } },
      }),
      db.schedulerLease.updateMany({
        where: { job: key, OR: [{ holder: "twin-b" }, { expiresAt: { lt: now } }] },
        data: { holder: "twin-b", expiresAt: new Date(Date.now() + 60_000), epoch: { increment: 1 } },
      }),
    ]);
    /* PostgreSQL READ COMMITTED: the second UPDATE blocks on the first
     * twin's row lock, then RE-EVALUATES its predicate (EvalPlanQual) —
     * the first twin's write flipped expiresAt to the future, so the
     * second twin's predicate misses. Exactly one claim survives, the
     * same single-winner invariant the SQLite-era sequential
     * serialization guaranteed. */
    expect(claims[0].count + claims[1].count).toBe(1);
    const row = await db.schedulerLease.findUniqueOrThrow({ where: { job: key } });
    expect(["twin-a", "twin-b"]).toContain(row.holder);
    expect(row.epoch).toBe(3);
    await db.schedulerLease.deleteMany({ where: { job: key } });
  });
});

describe("job-lease heartbeat + ownership probes", () => {
  test("renewJobLease extends OUR expiry; reports LOST after a foreign takeover", async () => {
    const key = "job-lease-renew";
    await db.schedulerLease.deleteMany({ where: { job: key } });
    const acquired = await jobLease.acquireJobLease(key, 60_000);
    expect(acquired.acquired).toBe(true);

    /* our heartbeat extends the expiry */
    const renewed = await jobLease.renewJobLease(key, 60_000);
    expect(renewed).toBe(true);
    const row = await db.schedulerLease.findUniqueOrThrow({ where: { job: key } });
    expect(row.expiresAt.getTime()).toBeGreaterThan(Date.now() + 30_000);

    /* a takeover (our lease expired; another process claimed it) →
     * renewal reports lost, stillMine flips false — the zombie detects */
    await db.schedulerLease.update({
      where: { job: key },
      data: { holder: "new-owner", expiresAt: new Date(Date.now() + 60_000) },
    });
    expect(await jobLease.renewJobLease(key, 60_000)).toBe(false);
    expect(await jobLease.stillOwnsJobLease(key)).toBe(false);
    await db.schedulerLease.deleteMany({ where: { job: key } });
  });

  test("stillOwnsJobLease is true while we hold the row", async () => {
    const key = "job-lease-stillmine";
    await db.schedulerLease.deleteMany({ where: { job: key } });
    const acquired = await jobLease.acquireJobLease(key, 60_000);
    expect(acquired.acquired).toBe(true);
    expect(await jobLease.stillOwnsJobLease(key)).toBe(true);
    expect(await jobLease.stillOwnsJobLease("never-acquired-job")).toBe(false);
    await db.schedulerLease.deleteMany({ where: { job: key } });
  });
});

describe("withJobLease — the failure policy", () => {
  /* Simulating the lease-store outage: RENAME the table out of the way
   * instead of the old SQLite DROP+re-CREATE — every lease query then
   * throws (table does not exist) and the ORIGINAL table (columns, types,
   * indexes — provider-native under PostgreSQL) returns byte-identical
   * when renamed back. A hand-written CREATE TABLE would drift from the
   * Prisma schema's column types; the rename cannot. */
  const hideLeaseTable = () =>
    db.$executeRawUnsafe('ALTER TABLE "SchedulerLease" RENAME TO "SchedulerLease_outage_sim"');
  const restoreLeaseTable = () =>
    db.$executeRawUnsafe('ALTER TABLE "SchedulerLease_outage_sim" RENAME TO "SchedulerLease"');

  test("default posture: the body runs even when the lease store is degraded (legacy availability)", async () => {
    /* simulate the store outage by hiding the table: every lease query throws */
    const key = "job-lease-outage";
    await db.schedulerLease.deleteMany({ where: { job: key } });
    await hideLeaseTable();
    let ran = false;
    let out: string | undefined;
    try {
      out = await jobLease.withJobLease(key, 60_000, async () => {
        ran = true;
        return "ran";
      });
    } finally {
      /* restore the table for the rest of the battery */
      await restoreLeaseTable();
    }
    expect(ran).toBe(true);
    expect(out).toBe("ran");
  });

  test("failure: skip — a lease-store outage SKIPS the tick (fail closed for destructive jobs)", async () => {
    const key = "job-lease-outage-skip";
    await db.schedulerLease.deleteMany({ where: { job: key } });
    await hideLeaseTable();
    let ran = false;
    let out: string | undefined;
    try {
      out = await jobLease.withJobLease(
        key,
        60_000,
        async () => {
          ran = true;
          return "ran";
        },
        { failure: "skip" }
      );
    } finally {
      await restoreLeaseTable();
    }
    expect(ran).toBe(false);
    expect(out).toBeUndefined();
  });

  test("the body receives the stillMine probe; a healthy tick keeps its lease", async () => {
    const key = "job-lease-probe";
    await db.schedulerLease.deleteMany({ where: { job: key } });
    let probed = false;
    await jobLease.withJobLease(key, 60_000, async (lease) => {
      if (lease) probed = await lease.stillMine();
    });
    expect(probed).toBe(true);
    /* the lease is released after the body */
    expect(await db.schedulerLease.findUnique({ where: { job: key } })).toBeNull();
  });
});
