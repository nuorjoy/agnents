/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 134: INSTANCE-ROUTE GUARD COVERAGE.
 *
 * The owner's directive: «راجع العزل وتأكد أن العزل يعمل في كافة الأنظمة
 * ولا يمكن تسريب معلومات المستأجرين او التلاعب بها بشكل صارم ودقيق» +
 * «راجع عدم تسريب الـAPIs بين المستأجرين بدقة واختبرها».
 *
 * The /api/instances/[id]/** surface is THE tenant boundary: every route
 * file under it must resolve the caller's right to THAT instance through
 * requireInstanceAccess (the session-bound + admin-tier guard in
 * src/lib/server/instance-session.ts) — either by calling it directly or by
 * delegating to a domain controller whose routeHandler declares the
 * `tenant:` guard stage (which internally calls the same guard).
 *
 * Allowlist — documented, individually justified exemptions:
 *   • auth/login (POST+DELETE) + auth/passkey — self-authenticating
 *     ceremonies: they PROVE identity (password / WebAuthn assertion) and
 *     issue or clear the session themselves; there is no prior session to
 *     require (the login flow scopes every candidate lookup to the target
 *     instance id — instanceLoginByEmail is instance-scoped).
 *   • favicon.png — a public per-instance image route (zero business data;
 *     the same image a published site would serve).
 *
 * A new tenant route that forgets the guard fails this test at battery
 * time — the "developer must remember" failure mode is structurally
 * eliminated, mirroring mutation-coverage.test.ts for reads AND writes.
 *
 * Complementary LIVE proof: tests/security/tenant-isolation.test.ts (the
 * round-41 cross-tenant attack matrix) + the ROUND 134
 * tenant-isolation-modern live suite (webhooks/shifts/coupons/module-
 * records sub-resources/orders/backup/export surfaces).
 */
import { describe, expect, test } from "bun:test";
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { stripComments } from "./code-only";

const REPO_ROOT = join(import.meta.dir, "..", "..");
const INSTANCE_DIR = join(REPO_ROOT, "src/app/api/instances");

/** routes that legitimately resolve identity WITHOUT requireInstanceAccess */
const ALLOWLIST = new Set([
  /* self-authenticating ceremonies (password / WebAuthn proof) */
  "src/app/api/instances/[id]/auth/login/route.ts",
  "src/app/api/instances/[id]/auth/passkey/route.ts",
  /* ROUND 146 — the comment-aware scanner exposed this route's only guard
   * evidence as a docstring mention: it actually uses resolveInstanceSession
   * (the same resolver requireInstanceAccess itself calls) — a PRE-AUTH
   * silent restore probe in the login-ceremony family. It scopes by
   * sessionState.instanceId !== id and reads only the session's own
   * workspace admin email (trashed rows read as signed out). */
  "src/app/api/instances/[id]/auth/session/route.ts",
  /* public per-instance static image (no business data) */
  "src/app/api/instances/[id]/favicon.png/route.ts",
]);

/** domain controllers a route may delegate to (the routeHandler tenant
 * stage calls requireInstanceAccess internally) */
const DOMAIN_CONTROLLERS = [
  "src/server/domains/plan-orders/controller.ts",
];

function* walkRoutes(dir: string): Generator<string> {
  for (const entry of readdirSync(dir)) {
    const path = join(dir, entry);
    if (statSync(path).isDirectory()) {
      yield* walkRoutes(path);
    } else if (entry === "route.ts") {
      yield path;
    }
  }
}

/** a route's effective guard surface: its own source + any domain
 * controller it delegates to (import-path resolution like
 * mutation-coverage). ROUND 146 — comments are STRIPPED first: a guard
 * that exists only in a comment (the classic commented-out-during-debug
 * regression) no longer satisfies the gate. */
function guardSurface(routeSource: string): string {
  const sources = [routeSource];
  const importRe = /from\s+"(@\/server\/domains\/[^"]+)"/g;
  for (const match of routeSource.matchAll(importRe)) {
    const rel = match[1].replace("@/", "src/");
    for (const candidate of [`${rel}.ts`, join(rel, "controller.ts")]) {
      const path = join(REPO_ROOT, candidate);
      try {
        sources.push(readFileSync(path, "utf8"));
        break;
      } catch {
        /* try the next shape */
      }
    }
  }
  return sources.map(stripComments).join("\n");
}

describe("tenant isolation — instance-route guard coverage", () => {
  test("every /api/instances/[id]/** route resolves the tenant guard (or is a documented exemption)", () => {
    const unguarded: string[] = [];
    let total = 0;

    for (const routePath of walkRoutes(INSTANCE_DIR)) {
      /* only the [id]-scoped subtree — the collection routes
       * (/api/instances, /api/instances/mine, /api/instances/auth/*)
       * authenticate differently by design (provisioning / own-list /
       * login ceremonies) and are NOT per-tenant surfaces. */
      const rel = relative(REPO_ROOT, routePath).replace(/\\/g, "/");
      if (!rel.includes("/instances/[id]/")) continue;
      total += 1;
      if (ALLOWLIST.has(rel)) continue;

      const surface = guardSurface(readFileSync(routePath, "utf8"));
      /* ROUND 146 — TWO legitimate guard idioms (matched against
       * COMMENT-STRIPPED code — a commented-out guard no longer passes):
       *   1. direct: the surface literally calls requireInstanceAccess;
       *   2. declarative: the surface declares a routeHandler `tenant:` plan
       *      (the domain-controller delegation — wallet/addon-orders/
       *      plan-orders). The tenant stage inside src/lib/server/route.ts
       *      provably resolves requireInstanceAccess — that invariant is
       *      pinned by the "declarative delegation" test below, which is
       *      what makes this proxy sound instead of hopeful. */
      const guarded =
        surface.includes("requireInstanceAccess") || /tenant:\s*\{/.test(surface);
      if (!guarded) {
        unguarded.push(rel);
      }
    }

    expect(total).toBeGreaterThan(30); /* the surface is real and walked */
    expect(unguarded).toEqual([]);
  });

  test("the plan-orders delegation is genuine (its controller really guards)", () => {
    /* ROUND 146 — comment-aware: the controller proves its DELEGATION FORM
     * (tenant plans on every tenant-facing handler); the translation of
     * `tenant:` into the real requireInstanceAccess call is proven against
     * the WRAPPER by the soundness test below (the controller's own comment
     * mentioning the guard is no longer counted as evidence — that is the
     * point of the scanner). */
    const controller = stripComments(readFileSync(join(REPO_ROOT, DOMAIN_CONTROLLERS[0]), "utf8"));
    expect(controller).toMatch(/tenant:\s*\{/);
    /* resolveInstanceSession is not a substitute — the controller must not
     * fake guardship with a weaker resolver */
    expect(controller).not.toContain("resolveInstanceSession");
  });

  test("ROUND 146 — the comment-stripping gate: a commented-out guard does NOT satisfy coverage (scanner proof)", () => {
    /* the exact regression this round closes: a guard commented out during
     * debugging used to keep the raw-text gate green. */
    const commentedOut = `
      // const guard = await requireInstanceAccess(id, req);
      /* requireInstanceAccess(id, req) — disabled while debugging */
      const x = 1;
    `;
    expect(stripComments(commentedOut)).not.toContain("requireInstanceAccess");
    const real = `
      const guard = await requireInstanceAccess(id, req);
    `;
    expect(stripComments(real)).toContain("requireInstanceAccess");
    /* strings and template interpolations are PRESERVED — a URL with // is
     * not a comment, and code inside \${…} still counts as code. */
    const strings = `
      const url = "https://example.com/x"; // real comment
      const msg = \`doc \${tenant ? "tenant:" : ""} end\`;
    `;
    const stripped = stripComments(strings);
    expect(stripped).toContain("https://example.com/x");
    expect(stripped).not.toContain("real comment");
    expect(stripped).toContain('tenant ? "tenant:" : ""');
  });

  test("ROUND 145 — every declarative tenant plan is backed by the real guard (the proxy is sound)", () => {
    /* the routeHandler wrapper's tenant stage MUST resolve
     * requireInstanceAccess — this is the invariant that lets the walker
     * accept `tenant: {` as proof of guarding. If someone ever rewires
     * the tenant stage to a weaker check, THIS test fails first. */
    const wrapper = readFileSync(join(REPO_ROOT, "src/lib/server/route.ts"), "utf8");
    expect(wrapper).toContain("requireInstanceAccess");
    /* the tenant stage's executor actually calls it (comment map at the
     * plan type + the stage executor, within a bounded span) */
    expect(wrapper).toMatch(/tenant[\s\S]{0,2000}requireInstanceAccess/);
    /* and every domain controller that a route can delegate to declares
     * its tenant plans (no half-delegated controller) */
    for (const controllerPath of [
      ...DOMAIN_CONTROLLERS,
      "src/server/domains/wallet/controller.ts",
      "src/server/domains/addon-orders/controller.ts",
    ]) {
      const src = readFileSync(join(REPO_ROOT, controllerPath), "utf8");
      expect(src).toMatch(/tenant:\s*\{/);
    }
  });

  test("ROUND 134 — the shift system is module-gated end-to-end (the toggle is the law's switch)", () => {
    const gate = readFileSync(join(REPO_ROOT, "src/lib/server/shift-gate.ts"), "utf8");
    /* the module check exists and fail-closes */
    expect(gate).toContain("instanceShiftsEnabled");
    /* every gate function consults it BEFORE deciding */
    expect(gate).toMatch(/shiftGateResponse[\s\S]{0,400}instanceShiftsEnabled/);
    expect(gate).toMatch(/requireOpenShift[\s\S]{0,400}instanceShiftsEnabled/);
    expect(gate).toMatch(/shiftOpenBlockResponse[\s\S]{0,400}instanceShiftsEnabled/);
    /* the mutating shift routes refuse while the module is off */
    const openRoute = readFileSync(
      join(REPO_ROOT, "src/app/api/instances/[id]/shifts/route.ts"),
      "utf8"
    );
    expect(openRoute).toContain("SHIFTS_MODULE_DISABLED");
    expect(openRoute).toContain("moduleDisabled");
  });

  test("ROUND 134 — the shifts + expenses modules exist in EVERY system's catalog", async () => {
    const { SYSTEMS, systemMods, MODULE_MAP } = await import("@/data/catalog");
    expect(MODULE_MAP.shifts).toBeTruthy();
    expect(MODULE_MAP.expenses).toBeTruthy();
    for (const system of SYSTEMS) {
      const mods = systemMods(system);
      expect(mods).toContain("shifts");
      expect(mods).toContain("expenses");
    }
    /* all 102 systems present — ROUND 144 added SGCMS (#101), ROUND 153
     * added SAMS (#102, student housing). Each system-addition round
     * must bump this pin (the R145 audit caught the same 100→101 drift —
     * the R162 battery caught 101→102). */
    expect(SYSTEMS.length).toBe(102);
  });
});
