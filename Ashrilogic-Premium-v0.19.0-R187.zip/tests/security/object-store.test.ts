/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — OBJECT STORAGE ADAPTER (ROUND 122).
 *
 * The adapter that stands between the image store (uploads, serving,
 * GC, backup envelopes, DR snapshots) and where the bytes actually live
 * (local FS by default; any S3-compatible engine when configured).
 *
 * Proves:
 *  1. LOCAL DRIVER CONTRACT — put/get round-trip, idempotent put,
 *     get-miss → null, delete existed/gone, list prefix isolation, and
 *     the key-shape guard (no traversal).
 *  2. FACTORY — env-driven selection (local default; s3 resolves the
 *     driver; a misconfigured s3 fails fast with the missing-variable
 *     list; an unknown driver is refused).
 *  3. SigV4 WIRE FORMAT — the signed request's structural contract
 *     (Authorization shape, credential scope, signed headers, payload
 *     hash = sha256(body), path-style URL with encoded key segments)
 *     AND the signature itself, re-derived INDEPENDENTLY inside the
 *     verifier below from the spec formulas (not from the client's code).
 *  4. THE S3 DRIVER against a REAL local HTTP server speaking the S3
 *     REST shape (PUT/GET/HEAD/DELETE/ListObjectsV2, XML bodies,
 *     continuation tokens, 404s): the full put → list → stat → get →
 *     delete → miss round trip, key-prefix mapping, and the bounded GET
 *     cache (a second get() never hits the wire).
 *
 * HONEST SCOPE: this verifies the client against an in-process S3-shaped
 * server (with independent signature verification). Real-endpoint
 * verification (MinIO/R2/AWS) is the documented ops runbook step
 * (README.md — production notes); nothing here claims it.
 *
 * No DB needed — the adapter is pure storage (test-setup env only for
 * consistency with the suite's isolation discipline).
 */

import { afterAll, beforeAll, describe, expect, test } from "bun:test";
import { createHash, createHmac } from "node:crypto";
import { mkdtempSync, rmSync, existsSync, readdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { ensureDemoEnv } from "./test-setup";

ensureDemoEnv();

/* pure modules — safe to import statically (no db binding):
 * object-store imports local-driver (fs only) + types; s3-driver imports
 * node:crypto only. */
import {
  assertValidKey,
  objectStorage,
  s3ConfigFromEnv,
  __resetObjectStorageForTests,
  type S3ObjectStorageConfig,
} from "@/lib/server/storage/object-store";
import { createLocalObjectStorage } from "@/lib/server/storage/local-driver";
import { createS3ObjectStorage, signS3Request } from "@/lib/server/storage/s3-driver";

const TMP = mkdtempSync(join(tmpdir(), "ashrilogic-object-store-"));

afterAll(() => {
  rmSync(TMP, { recursive: true, force: true });
});

/* ------------------------------ 1 — local driver ------------------------- */

describe("ROUND 122 — local object storage driver", () => {
  test("put/get round-trip, idempotent re-put, delete existed/gone, list isolation", async () => {
    const root = join(TMP, "local-a");
    const store = createLocalObjectStorage(root);

    const a = Buffer.from("image-a-bytes");
    const b = Buffer.from("image-b-bytes");
    await store.put("images/aa.webp", a);
    await store.put("images/bb.webp", b);
    await store.put("backups/some.db", Buffer.from("not-an-image"));

    expect((await store.get("images/aa.webp"))?.toString()).toBe("image-a-bytes");
    expect(await store.get("images/missing.webp")).toBeNull();

    /* idempotent re-put keeps the bytes */
    await store.put("images/aa.webp", a);
    expect((await store.get("images/aa.webp"))?.toString()).toBe("image-a-bytes");

    const st = await store.stat("images/bb.webp");
    expect(st).not.toBeNull();
    expect(st!.bytes).toBe(b.length);
    expect(st!.key).toBe("images/bb.webp");
    expect(st!.lastModified).toBeGreaterThan(0);
    expect(await store.stat("images/nope.webp")).toBeNull();

    /* list is prefix-scoped and ascending */
    const listed = await store.list("images/");
    expect(listed.map((e) => e.key)).toEqual(["images/aa.webp", "images/bb.webp"]);
    expect(await store.list("backups/")).toHaveLength(1);

    /* delete: existed → true; gone → false */
    expect(await store.delete("images/aa.webp")).toBe(true);
    expect(await store.delete("images/aa.webp")).toBe(false);
    expect(await store.get("images/aa.webp")).toBeNull();
  });

  test("range reads load only the requested byte window", async () => {
    const root = join(TMP, "local-range");
    const store = createLocalObjectStorage(root);
    const bytes = Buffer.from("0123456789abcdef");
    await store.put("media/video.bin", bytes);

    const hit = await store.getRange("media/video.bin", 4, 7);
    expect(hit?.buffer.toString()).toBe("4567");
    expect(hit?.totalBytes).toBe(bytes.length);
    expect(await store.getRange("media/video.bin", 99, 100)).toBeNull();
  });

  test("production S3 endpoints require HTTPS", () => {
    (process.env as { NODE_ENV?: string }).NODE_ENV = "production";
    process.env.S3_ENDPOINT = "http://127.0.0.1:9000";
    process.env.S3_BUCKET = "test";
    process.env.S3_ACCESS_KEY_ID = "key";
    process.env.S3_SECRET_ACCESS_KEY = "secret";
    expect(() => s3ConfigFromEnv()).toThrow(/HTTPS in production/i);
    (process.env as { NODE_ENV?: string }).NODE_ENV = "development";
    delete process.env.S3_ENDPOINT;
    delete process.env.S3_BUCKET;
    delete process.env.S3_ACCESS_KEY_ID;
    delete process.env.S3_SECRET_ACCESS_KEY;
  });

  test("keys are shape-guarded (traversal/absolute/backslash rejected)", () => {
    for (const bad of [
      "../etc/passwd",
      "/abs/path",
      "a\\b",
      "a//b",
      "a/./b",
      "a/../b",
      "",
    ]) {
      expect(() => assertValidKey(bad)).toThrow(/invalid object key/i);
    }
    expect(() => assertValidKey("images/ok.webp")).not.toThrow();
    const store = createLocalObjectStorage(join(TMP, "local-b"));
    /* the driver enforces the same guard on every op */
    expect(store.put("../escape" as never, Buffer.from("x"))).rejects.toThrow(/invalid object key/i);
  });

  test("put keeps the atomic tmp+rename discipline (no tmp residue, no partial finals)", async () => {
    const root = join(TMP, "local-c");
    const store = createLocalObjectStorage(root);
    await store.put("images/cc.webp", Buffer.from("cc"));
    const names = readdirSync(join(root, "images"));
    expect(names).toEqual(["cc.webp"]); /* no .tmp-* left behind */
    expect(existsSync(join(root, "images", "cc.webp"))).toBe(true);
  });
});

/* ------------------------------ 2 — factory ------------------------------ */

describe("ROUND 122 — objectStorage() factory (env-driven)", () => {
  test("default: local driver (no env set)", async () => {
    __resetObjectStorageForTests();
    delete process.env.ASHRILOGIC_STORAGE_DRIVER;
    const store = await objectStorage();
    expect(store.driver).toBe("local");
  });

  test("driver=s3 resolves the S3 driver (config-only, no network yet)", async () => {
    __resetObjectStorageForTests();
    process.env.ASHRILOGIC_STORAGE_DRIVER = "s3";
    process.env.S3_ENDPOINT = "http://localhost:1"; /* never dialed (ROUND 146: endpoint IP-literal hygiene — use a name, not a literal) */
    process.env.S3_BUCKET = "test-bucket";
    process.env.S3_ACCESS_KEY_ID = "testkey";
    process.env.S3_SECRET_ACCESS_KEY = "testsecret";
    try {
      const store = await objectStorage();
      expect(store.driver).toBe("s3");
    } finally {
      delete process.env.ASHRILOGIC_STORAGE_DRIVER;
      delete process.env.S3_ENDPOINT;
      delete process.env.S3_BUCKET;
      delete process.env.S3_ACCESS_KEY_ID;
      delete process.env.S3_SECRET_ACCESS_KEY;
      __resetObjectStorageForTests();
    }
  });

  test("driver=s3 with an incomplete config fails fast naming the missing vars", async () => {
    __resetObjectStorageForTests();
    process.env.ASHRILOGIC_STORAGE_DRIVER = "s3";
    delete process.env.S3_ENDPOINT;
    delete process.env.S3_BUCKET;
    process.env.S3_ACCESS_KEY_ID = "k";
    delete process.env.S3_SECRET_ACCESS_KEY;
    try {
      await expect(objectStorage()).rejects.toThrow(
        /ASHRILOGIC_STORAGE_DRIVER=s3 but required env missing: S3_ENDPOINT, S3_BUCKET, S3_SECRET_ACCESS_KEY/
      );
    } finally {
      delete process.env.ASHRILOGIC_STORAGE_DRIVER;
      delete process.env.S3_ACCESS_KEY_ID;
      __resetObjectStorageForTests();
    }
  });

  test("an unknown driver value is refused", async () => {
    __resetObjectStorageForTests();
    process.env.ASHRILOGIC_STORAGE_DRIVER = "gcs";
    try {
      await expect(objectStorage()).rejects.toThrow(/must be "local" or "s3"/);
    } finally {
      delete process.env.ASHRILOGIC_STORAGE_DRIVER;
      __resetObjectStorageForTests();
    }
  });
});

/* --------------------------- 3+4 — the S3 side --------------------------- */

/** Independent, spec-derived SigV4 verifier for the fake server (the
 *  formulas written out here per the AWS SigV4 spec — NOT the client's
 *  helpers, so a canonicalization regression fails the wire test). */
function verifySigV4(
  req: Request,
  body: Buffer,
  cfg: { region: string; bucket: string; secretAccessKey: string }
): boolean {
  const auth = req.headers.get("authorization") ?? "";
  const m = auth.match(
    /^AWS4-HMAC-SHA256 Credential=([^/]+)\/(\d{8})\/([^/]+)\/([^/]+)\/aws4_request, SignedHeaders=([^,]+), Signature=([a-f0-9]{64})$/
  );
  if (!m) return false;
  const [, , dateStamp, region, service, signedHeaders, signature] = m;
  if (region !== cfg.region || service !== "s3") return false;

  const url = new URL(req.url);
  const canonicalUri = url.pathname || "/";
  const canonicalQuery = [...url.searchParams.entries()]
    .map(([k, v]) => [k, v] as const)
    .sort(([a], [b]) => (a < b ? -1 : 1))
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
    .join("&");

  const headers = signedHeaders.split(";");
  const canonicalHeaders = headers
    .map((h) => `${h}:${(req.headers.get(h) ?? "").trim()}\n`)
    .join("");

  const payloadHash = req.headers.get("x-amz-content-sha256") ?? "";
  if (payloadHash !== createHash("sha256").update(body).digest("hex")) return false;

  const canonicalRequest = [
    req.method,
    canonicalUri,
    canonicalQuery,
    canonicalHeaders,
    signedHeaders,
    payloadHash,
  ].join("\n");

  const xAmzDate = req.headers.get("x-amz-date") ?? "";
  if (xAmzDate.slice(0, 8) !== dateStamp) return false;

  const stringToSign = [
    "AWS4-HMAC-SHA256",
    xAmzDate,
    `${dateStamp}/${region}/s3/aws4_request`,
    createHash("sha256").update(canonicalRequest).digest("hex"),
  ].join("\n");

  /* per spec: HMAC("AWS4" + secretAccessKey, dateStamp) — the prefix is
     part of the key derivation, not of the configured secret */
  const kDate = createHmac("sha256", `AWS4${cfg.secretAccessKey}`).update(dateStamp).digest();
  const kRegion = createHmac("sha256", kDate).update(region).digest();
  const kService = createHmac("sha256", kRegion).update("s3").digest();
  const kSigning = createHmac("sha256", kService).update("aws4_request").digest();
  const expected = createHmac("sha256", kSigning).update(stringToSign).digest("hex");
  return expected === signature;
}

describe("ROUND 122 — S3 driver (against a local S3-shaped server)", () => {
  let server: ReturnType<typeof Bun.serve> | null = null;
  let cfg: S3ObjectStorageConfig;
  const objects = new Map<string, Buffer>();
  const objectTimes = new Map<string, number>();
  const wire = { gets: 0, puts: 0, deletes: 0, lists: 0, heads: 0 };

  beforeAll(() => {
    const PREFIX = "ashrilogic/test";
    server = Bun.serve({
      port: 0,
      hostname: "127.0.0.1",
      async fetch(req) {
        const url = new URL(req.url);
        const path = decodeURIComponent(url.pathname);
        const bucketPath = `/${"test-bucket"}`;
        if (!path.startsWith(bucketPath)) {
          return new Response("no such bucket", { status: 404 });
        }
        const rel = path.slice(bucketPath.length); /* "/<key>" or "" */

        /* every request must be correctly signed (independent verifier) */
        const body = Buffer.from(await req.arrayBuffer());
        if (
          !verifySigV4(req, body, {
            region: "test-region",
            bucket: "test-bucket",
            secretAccessKey: "AWS4TESTSECRET",
          })
        ) {
          return new Response("signature mismatch", { status: 403 });
        }

        /* ListObjectsV2 (query on the bare bucket) */
        if (rel === "" || rel === "/") {
          wire.lists++;
          const prefix = url.searchParams.get("prefix") ?? "";
          const token = url.searchParams.get("continuation-token");
          const all = [...objects.keys()].filter((k) => k.startsWith(prefix)).sort();
          const PAGE = 2;
          /* the token is OPAQUE to the client; this fake encodes "the last
             key of the previous page" — the next page resumes strictly
             after it (indexOf+1, never findIndex '>' — equal keys must not
             loop) */
          const idx = token === null ? 0 : all.indexOf(token) + 1;
          const page = all.slice(idx, idx + PAGE);
          const truncated = idx + PAGE < all.length;
          const contents = page
            .map(
              (k) =>
                `<Contents><Key>${k
                  .replace(/&/g, "&amp;")
                  .replace(/</g, "&lt;")}</Key><Size>${objects.get(k)!.length}</Size>` +
                `<LastModified>${new Date(objectTimes.get(k)!).toISOString()}</LastModified></Contents>`
            )
            .join("");
          const next = truncated ? page[page.length - 1] : null; /* token = the
             last key of THIS page (opaque to the client); the next call
             resumes strictly after it */
          return new Response(
            `<?xml version="1.0"?><ListBucketResult>${contents}` +
              `<IsTruncated>${truncated}</IsTruncated>` +
              (next ? `<NextContinuationToken>${next}</NextContinuationToken>` : "") +
              `</ListBucketResult>`,
            { status: 200, headers: { "content-type": "application/xml" } }
          );
        }

        /* the object namespace: "/<prefix>/<key>" — strip our test prefix */
        const stripPrefix = `${PREFIX}/`;
        const fullKey = rel.slice(1);
        if (!fullKey.startsWith(stripPrefix)) {
          /* a key outside the configured prefix is a client bug */
          return new Response("outside prefix", { status: 404 });
        }

        if (req.method === "PUT") {
          wire.puts++;
          objects.set(fullKey, body);
          objectTimes.set(fullKey, Date.now());
          return new Response(null, { status: 200 });
        }
        if (req.method === "GET") {
          wire.gets++;
          const obj = objects.get(fullKey);
          if (obj === undefined) return new Response(null, { status: 404 });
          return new Response(new Uint8Array(obj), {
            status: 200,
            headers: {
              "content-length": String(obj.length),
              "last-modified": new Date(objectTimes.get(fullKey)!).toUTCString(),
            },
          });
        }
        if (req.method === "HEAD") {
          wire.heads++;
          const obj = objects.get(fullKey);
          if (obj === undefined) return new Response(null, { status: 404 });
          return new Response(null, {
            status: 200,
            headers: {
              "content-length": String(obj.length),
              "last-modified": new Date(objectTimes.get(fullKey)!).toUTCString(),
            },
          });
        }
        if (req.method === "DELETE") {
          wire.deletes++;
          if (!objects.delete(fullKey)) return new Response(null, { status: 404 });
          objectTimes.delete(fullKey);
          return new Response(null, { status: 204 });
        }
        return new Response("unsupported", { status: 405 });
      },
    });

    cfg = {
      endpoint: server.url.toString().replace(/\/$/, ""),
      bucket: "test-bucket",
      region: "test-region",
      accessKeyId: "TESTKEY",
      secretAccessKey: "AWS4TESTSECRET",
      keyPrefix: "ashrilogic/test",
    };
  });

  afterAll(() => {
    server?.stop(true);
  });

  test("signS3Request: structural contract (Authorization shape, scope, payload hash, path-style URL)", () => {
    const body = Buffer.from("payload-bytes-123");
    const signed = signS3Request(cfg, {
      method: "PUT",
      key: "images/abc.webp",
      body,
      now: new Date("2026-09-20T10:00:00Z"),
    });
    /* path-style URL with the encoded key under the bucket + prefix */
    expect(signed.url).toBe(`${cfg.endpoint}/test-bucket/ashrilogic/test/images/abc.webp`);
    /* signed headers exactly the three, lowercase, ordered */
    expect(signed.headers.authorization).toMatch(
      /^AWS4-HMAC-SHA256 Credential=TESTKEY\/20260920\/test-region\/s3\/aws4_request, SignedHeaders=host;x-amz-content-sha256;x-amz-date, Signature=[a-f0-9]{64}$/
    );
    expect(signed.headers["x-amz-content-sha256"]).toBe(
      createHash("sha256").update(body).digest("hex")
    );
    expect(signed.headers["x-amz-date"]).toBe("20260920T100000Z");
    expect(signed.headers["content-length"]).toBe(String(body.length));
  });

  test("signS3Request: signature derives from the spec chain (independent re-derivation)", () => {
    const body = Buffer.from("");
    const now = new Date("2026-09-20T10:00:00Z");
    const signed = signS3Request(cfg, { method: "GET", key: "images/x.webp", body, now });
    /* the independent verifier over the SIGNED REQUEST's own fields —
     * the URL, headers, and method exactly as they will hit the wire */
    const fakeReq = new Request(signed.url, {
      method: "GET",
      headers: signed.headers,
    });
    expect(
      verifySigV4(fakeReq, body, {
        region: cfg.region,
        bucket: cfg.bucket,
        secretAccessKey: cfg.secretAccessKey,
      })
    ).toBe(true);
  });

  test("full round trip: put → list (paginated, prefix-mapped) → stat → get → delete → miss", async () => {
    const store = createS3ObjectStorage(cfg);

    const a = Buffer.from("object-a");
    const b = Buffer.from("object-b");
    const c = Buffer.from("object-c-longer");
    await store.put("images/aa.webp", a);
    await store.put("images/bb.webp", b);
    await store.put("images/cc.webp", c);

    /* list: the fake server paginates at 2 — the driver must follow the
       continuation tokens (3 lists expected: 2 pages + final) */
    const listed = await store.list("images/");
    expect(listed.map((e) => e.key)).toEqual(["images/aa.webp", "images/bb.webp", "images/cc.webp"]);
    expect(listed.map((e) => e.bytes)).toEqual([a.length, b.length, c.length]);
    expect(listed.every((e) => e.lastModified > 0)).toBe(true);
    expect(wire.lists).toBeGreaterThanOrEqual(2);

    /* stat */
    const st = await store.stat("images/bb.webp");
    expect(st).not.toBeNull();
    expect(st!.bytes).toBe(b.length);

    /* get round-trip */
    expect((await store.get("images/cc.webp"))?.toString()).toBe("object-c-longer");
    expect(await store.get("images/nothere.webp")).toBeNull();

    /* every request the driver made was signature-verified by the server
       (a single bad signature would have 403'd the op above) */
    expect(wire.puts).toBe(3);

    /* delete → then miss */
    expect(await store.delete("images/bb.webp")).toBe(true);
    expect(await store.delete("images/bb.webp")).toBe(false);
    expect(await store.stat("images/bb.webp")).toBeNull();
  });

  test("the bounded GET cache: a second get() never hits the wire", async () => {
    const store = createS3ObjectStorage(cfg);
    await store.put("images/cached.webp", Buffer.from("cached-bytes"));
    const before = wire.gets;
    expect((await store.get("images/cached.webp"))?.toString()).toBe("cached-bytes");
    const mid = wire.gets;
    expect(mid).toBe(before + 1);
    /* second get — served from the LRU (immutable, content-addressed) */
    expect((await store.get("images/cached.webp"))?.toString()).toBe("cached-bytes");
    expect(wire.gets).toBe(mid);
    /* after deletion the cached entry is gone → miss (and the server 404) */
    await store.delete("images/cached.webp");
    expect(await store.get("images/cached.webp")).toBeNull();
    await store.put("images/cached.webp", Buffer.from("cached-bytes"));
    expect((await store.get("images/cached.webp"))?.toString()).toBe("cached-bytes");
  });
});

/* -------------------- ROUND 146 — endpoint SSRF hygiene -------------------- */

describe("ROUND 146 — S3 endpoint IP-literal hygiene (the PRODUCTION posture)", () => {
  const REQUIRED = {
    S3_BUCKET: "test",
    S3_ACCESS_KEY_ID: "key",
    S3_SECRET_ACCESS_KEY: "secret",
  };
  const clear = () => {
    delete process.env.S3_ENDPOINT;
    for (const k of Object.keys(REQUIRED)) delete process.env[k];
  };

  test("production refuses private/loopback/metadata IP-literal endpoints (config mistakes / SSRF posture)", () => {
    (process.env as { NODE_ENV?: string }).NODE_ENV = "production";
    try {
      for (const bad of [
        "https://127.0.0.1:9000",
        "https://10.0.0.5",
        "https://169.254.169.254", // cloud metadata
        "https://192.168.1.10:8443",
        "https://172.16.0.1",
        "https://[::1]:9000",
        "https://[::ffff:169.254.169.254]",
      ]) {
        process.env.S3_ENDPOINT = bad;
        Object.assign(process.env, REQUIRED);
        expect(() => s3ConfigFromEnv(), bad).toThrow(/private\/loopback\/link-local IP literal/);
      }
    } finally {
      clear();
      (process.env as { NODE_ENV?: string }).NODE_ENV = "development";
    }
  });

  test("development keeps loopback endpoints legal (the documented local-MinIO pattern — the battery's S3 harness binds 127.0.0.1)", () => {
    (process.env as { NODE_ENV?: string }).NODE_ENV = "development";
    try {
      for (const good of [
        "https://s3.amazonaws.com",
        "https://8.8.8.8",
        "http://localhost:9000",
        "http://127.0.0.1:9000", /* the offline battery's own S3-shaped server */
        "https://[64:ff9b::8.8.8.8]",
      ]) {
        process.env.S3_ENDPOINT = good;
        Object.assign(process.env, REQUIRED);
        expect(() => s3ConfigFromEnv(), good).not.toThrow();
      }
    } finally {
      clear();
    }
  });
});
