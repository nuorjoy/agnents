/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 47 → ROUND 79: the 14-Day Full-Access
 * trial + hard lockdown + the tamper-proof plan-order payment flow + the
 * paid-term expiry + the per-plan feature map.
 *
 * Proven on the live dev server, end-to-end:
 *
 *   1. UNIT  — computeEntitlement: active (plan / no clock), trial window
 *      math, locked after expiry.
 *   2. PROVISIONING — a fresh workspace is stamped with a 14-day trial and
 *      NO package (state "trial" in the created DTO).
 *   3. LOCKDOWN — with the trial expired (forced in the DB): business APIs
 *      refuse with 403 TRIAL_EXPIRED; the billing/plan-order surface keeps
 *      working; the PUBLIC SITE serves the stopped screen and the store
 *      API 404s.
 *   4. TAMPER-PROOF ORDERS — creating an order: the amount is recomputed
 *      server-side from the LIVE package price (a forged amount in the
 *      body is ignored — the field is not even accepted), the reference
 *      matches the ASH-XXXX-XXXX-XXXX shape, and the row is sealed with an
 *      HMAC integrity hash. Tampering the stored amount in the DB makes the
 *      admin confirmation REFUSE with 409 ORDER_INTEGRITY.
 *   5. ACTIVATION — admin confirming the (untampered) order marks it paid,
 *      assigns the plan to the instance (monthly cycle stamped), restores
 *      the business APIs and the public site instantly.
 */
import { describe, test, expect, beforeAll, afterAll } from "bun:test";
import { computeEntitlement, TRIAL_DAYS } from "@/lib/server/entitlement";
import { ensureDemoEnv, loginDemoAdmin, resolveServerDatabaseUrl } from "./test-setup";
import { PrismaClient } from "@prisma/client";

ensureDemoEnv();

const BASE = "http://localhost:3000";
const RUN = Math.random().toString(36).slice(2, 8);
/* ROUND 134 — deep tenant-uniqueness gate: RUN-derived org phone (the old
 * constant +966500000000 collided with plan-assignment's soft-deleted probe
 * rows from prior runs — the deep scan deliberately includes trashed rows). */
function runPhoneDigits(seed: string): string {
  let h = 0;
  for (const ch of seed) h = (h * 31 + ch.charCodeAt(0)) % 100000;
  return String(h % 100000).padStart(5, "0");
}
const ORG_PHONE = `+9665${runPhoneDigits(RUN)}`;
const XFF_IP = `198.18.${(RUN.charCodeAt(0) % 200) + 10}.${(RUN.charCodeAt(1) % 200) + 10}`;
const JSON_HEADERS: Record<string, string> = {
  "content-type": "application/json",
  origin: BASE,
  referer: `${BASE}/`,
  "x-forwarded-for": XFF_IP,
};

/* the DEV SERVER's PostgreSQL database (was file:db/custom.db) — resolved
 * lazily so a skipped run (server down) never needs it; see
 * test-setup.resolveServerDatabaseUrl() */
let serverDb: PrismaClient | null = null;
function db(): PrismaClient {
  serverDb ??= new PrismaClient({ datasourceUrl: resolveServerDatabaseUrl() });
  return serverDb;
}

/* ------------------------------ cookie jar ------------------------------ */

class CookieJar {
  private cookies = new Map<string, string>();
  setFrom(res: Response): void {
    const lines: string[] =
      typeof res.headers.getSetCookie === "function" ? res.headers.getSetCookie() : [];
    if (lines.length === 0) {
      const single = res.headers.get("set-cookie");
      if (single) lines.push(single);
    }
    for (const line of lines) {
      const [pair] = line.split(";");
      const eq = pair.indexOf("=");
      if (eq > 0) this.cookies.set(pair.slice(0, eq).trim(), pair.slice(eq + 1).trim());
    }
  }
  header(): string {
    return [...this.cookies.entries()].map(([k, v]) => `${k}=${v}`).join("; ");
  }
}

async function jfetch(path: string, jar: CookieJar, method: string, body?: string): Promise<Response> {
  const cookie = jar.header();
  return fetch(`${BASE}${path}`, {
    method,
    headers: {
      "content-type": "application/json",
      ...(cookie ? { cookie } : {}),
      ...(method === "GET" ? {} : JSON_HEADERS),
    },
    body,
    signal: AbortSignal.timeout(15_000),
  }).then((res) => {
    jar.setFrom(res);
    return res;
  });
}

/* --------------------------------- suite -------------------------------- */

describe("ROUND 47 — trial entitlement (unit)", () => {
  test("plan assigned → active regardless of the clock", () => {
    const ent = computeEntitlement({
      packageId: "pkg_1",
      trialEndsAt: new Date(Date.now() - 1000),
      planActivatedAt: new Date(),
      planCycle: "monthly",
    });
    expect(ent.state).toBe("active");
  });

  test("no clock → active (grandfathered)", () => {
    expect(computeEntitlement({ packageId: null, trialEndsAt: null }).state).toBe("active");
  });

  test("inside the window → trial with day/hour countdown", () => {
    /* 3 days minus 30 minutes → floor is deterministically 2 days */
    const ent = computeEntitlement({
      packageId: null,
      trialEndsAt: new Date(Date.now() + 3 * 864e5 - 1800_000),
    });
    expect(ent.state).toBe("trial");
    expect(ent.trialDaysLeft).toBe(2);
    expect(ent.trialHoursLeft).toBe(71);
  });

  test("past the window without a plan → locked", () => {
    const ent = computeEntitlement({ packageId: null, trialEndsAt: new Date(Date.now() - 60_000) });
    expect(ent.state).toBe("locked");
  });

  test("TRIAL_DAYS is exactly 14 (ROUND 79 Full-Access window)", () => {
    expect(TRIAL_DAYS).toBe(14);
  });

  test("ROUND 79 — plan term expiry locks with reason \"plan\"", () => {
    const ent = computeEntitlement({
      packageId: "pkg_1",
      trialEndsAt: null,
      planExpiresAt: new Date(Date.now() - 60_000),
    });
    expect(ent.state).toBe("locked");
    expect(ent.lockReason).toBe("plan");
  });

  test("ROUND 79 — plan term in the future stays active with planDaysLeft", () => {
    const ent = computeEntitlement({
      packageId: "pkg_1",
      trialEndsAt: null,
      planExpiresAt: new Date(Date.now() + 5 * 864e5),
    });
    expect(ent.state).toBe("active");
    expect(ent.planDaysLeft).toBe(5);
    expect(ent.lockReason).toBeNull();
  });

  test("ROUND 79 — features: trial / no-package rows are FULL-ACCESS; plan rows follow capabilities ± overrides", () => {
    /* trial → every catalog feature ON */
    const trialEnt = computeEntitlement({
      packageId: null,
      trialEndsAt: new Date(Date.now() + 5 * 864e5),
    });
    expect(Object.values(trialEnt.features).every((v) => v === true)).toBe(true);

    /* no package, no clock (platform showcase) → every feature ON */
    const showcase = computeEntitlement({ packageId: null, trialEndsAt: null });
    expect(Object.values(showcase.features).every((v) => v === true)).toBe(true);

    /* plan row: capabilities decide; an override false beats everything,
       an override true grants even below tier */
    const planEnt = computeEntitlement({
      packageId: "pkg_1",
      trialEndsAt: null,
      featureOverridesJson: JSON.stringify({ publicWebsite: true, store: false }),
      package: { capabilitiesJson: JSON.stringify(["store", "reviews"]), nameAr: "الباقة الأساسية", nameEn: "Starter" },
    });
    expect(planEnt.features.publicWebsite).toBe(true); /* override grant */
    expect(planEnt.features.store).toBe(false); /* override revoke beats the plan */
    expect(planEnt.features.reviews).toBe(true); /* from capabilities */
    expect(planEnt.features.aiInsights).toBe(false); /* outside the plan */
  });

  test("ROUND 79 — locked workspaces resolve every feature OFF", () => {
    const ent = computeEntitlement({ packageId: null, trialEndsAt: new Date(Date.now() - 60_000) });
    expect(ent.state).toBe("locked");
    expect(Object.values(ent.features).every((v) => v === false)).toBe(true);
  });
});

/** live-server test with an extended timeout (cold route compiles in dev
 *  mode take 5s+ — bun's default 5s test/hook timeout aborted this whole
 *  file on a cold provisioning request; ROUND 105 fix, mirrors the
 *  tenant-isolation liveTest pattern). */
function liveTest(name: string, fn: () => Promise<void>): void {
  test(name, fn, 60_000);
}

describe("ROUND 47 — trial lockdown + plan orders (live)", () => {
  let instanceId = "";
  let starterId = "";
  const jar = new CookieJar();

  /* 60s hook timeout: the provisioning request rides a possibly-COLD dev
     route (first compile after a server restart measured 5.1s — over the
     5s default that aborted this whole file in ROUND 105 testing) */
  beforeAll(async () => {
    const res = await jfetch(
      "/api/instances",
      jar,
      "POST",
      JSON.stringify({
        systemId: "pharmacy-management",
        org: {
          name: `مختبر التجربة ${RUN}`,
          country: "SA",
          currency: "SAR",
          timezone: "Asia/Riyadh",
          phone: ORG_PHONE,
          address: "عنوان الاختبار",
        },
        admin: {
          name: `مالك ${RUN}`,
          email: `trial-owner-${RUN}@ashrilogic.test`,
          role: "owner",
          password: `trial-owner-${RUN}-pass`,
          twoFA: false,
        },
        prefs: { lang: "ar", theme: "light", notif: true, backup: true, audit: true, demo: false },
        modules: ["pharmacy", "inventory"],
      })
    );
    if (res.status !== 201) throw new Error(`provision failed: ${res.status}`);
    const data = (await res.json()) as { id: string; entitlement: { state: string; trialEndsAt: string } };
    instanceId = data.id;
    expect(data.entitlement.state).toBe("trial");

    const pub = (await (await fetch(`${BASE}/api/packages`)).json()) as { id: string }[];
    starterId = pub[0]?.id ?? "";
    expect(starterId).toBeTruthy();

    /* publish a public site so the stop/restore path is exercised */
    await jfetch(
      `/api/instances/${instanceId}/site`,
      jar,
      "PUT",
      JSON.stringify({
        published: true,
        theme: "aurora",
        content: {
          heroTitle: `موقع ${RUN}`,
          tagline: "تجربة الإيقاف والاستئناف",
          heroDesc: "",
          aboutTitle: "عن",
          about: "",
          services: [],
          contactEmail: "",
          contactPhone: "",
          contactAddress: "",
          logoUrl: "",
          socialLinks: [],
          workingHours: "",
        },
      })
    );
  }, 60_000);

  afterAll(async () => {
    if (instanceId) {
      await db().planOrder.deleteMany({ where: { instanceId } });
      await db().instance.delete({ where: { id: instanceId } }).catch(() => undefined);
      await db().rateLimitHit.deleteMany({ where: { key: { contains: instanceId } } });
    }
    await serverDb?.$disconnect();
  }, 60_000);

  liveTest("fresh workspace runs on the 14-day Full-Access trial with NO package", async () => {
    const row = await db().instance.findUnique({
      where: { id: instanceId },
      select: { packageId: true, trialEndsAt: true, createdAt: true },
    });
    expect(row?.packageId).toBeNull();
    expect(row?.trialEndsAt).toBeTruthy();
    const days = (row!.trialEndsAt!.getTime() - row!.createdAt.getTime()) / 864e5;
    expect(Math.round(days)).toBe(14);
  });

  liveTest("trial workspace: business APIs work", async () => {
    const res = await jfetch(
      `/api/instances/${instanceId}/module-records?moduleId=pharmacy`,
      jar,
      "GET"
    );
    expect(res.status).toBe(200);
  });

  liveTest("expired trial: business APIs refuse with 403 TRIAL_EXPIRED", async () => {
    await db().instance.update({
      where: { id: instanceId },
      data: { trialEndsAt: new Date(Date.now() - 3600_000) },
    });
    const res = await jfetch(
      `/api/instances/${instanceId}/module-records?moduleId=pharmacy`,
      jar,
      "GET"
    );
    expect(res.status).toBe(403);
    const body = (await res.json()) as { code?: string };
    expect(body.code).toBe("TRIAL_EXPIRED");
  });

  liveTest("expired trial: plan orders stay reachable (billing surface)", async () => {
    const res = await jfetch(`/api/instances/${instanceId}/plan-orders`, jar, "GET");
    expect(res.status).toBe(200);
  });

  liveTest("expired trial: public site serves the STOPPED screen + store 404", async () => {
    const page = await fetch(`${BASE}/sites/${instanceId}`);
    expect(page.status).toBe(200);
    const html = await page.text();
    expect(html).toContain("هذا الموقع متوقف مؤقتاً");

    const store = await fetch(`${BASE}/api/sites/${instanceId}/store`);
    expect(store.status).toBe(404);
  });

  liveTest("order creation: server-side amount + ASH reference + integrity seal", async () => {
    /* a forged amount in the body is silently ignored (not part of the schema) */
    const res = await jfetch(
      `/api/instances/${instanceId}/plan-orders`,
      jar,
      "POST",
      /* ROUND 48 — methodId references the console-managed dynamic list;
         a forged amount in the body is silently ignored (not in the schema) */
      JSON.stringify({ packageId: starterId, cycle: "monthly", methodId: "pm_default_bank", amount: 1 })
    );
    expect(res.status).toBe(201);
    const body = (await res.json()) as {
      order: { reference: string; amount: number; integrityVerified: boolean; status: string };
      instructions: { lines: string[] };
    };
    expect(body.order.reference).toMatch(/^ASH-[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/);
    expect(body.order.integrityVerified).toBe(true);
    expect(body.order.status).toBe("pending");
    expect(body.instructions.lines.length).toBeGreaterThan(0);

    /* ROUND 79 → ROUND 80 — the amount is the LIVE discounted price computed
       server-side (monthly cycle → discountPct; yearly → the dedicated
       annual pct). The forged `amount: 1` in the body is ignored. */
    const pkg = await db().package.findUnique({
      where: { id: starterId },
      select: { priceMonthly: true, discountPct: true, yearlyDiscountPct: true },
    });
    expect(pkg).toBeTruthy();
    const expectedAmount = Math.max(0, Math.round((pkg!.priceMonthly * (100 - (pkg!.discountPct ?? 0))) / 100));
    expect(body.order.amount).toBe(expectedAmount);
    /* the forged amount never leaks into the order */
    expect(body.order.amount).not.toBe(1);
  });

  liveTest("tampered order row: admin confirmation refuses with 409 ORDER_INTEGRITY", async () => {
    const adminJar = new CookieJar();
    /* ROUND 124 — candidate-based demo-admin login (seed vs bootstrapped DB) */
    const login = await loginDemoAdmin(jfetch, adminJar);
    expect(login.status).toBe(200);

    const order = await db().planOrder.findFirst({ where: { instanceId }, orderBy: { createdAt: "desc" } });
    expect(order).toBeTruthy();
    /* DB-only tampering: change the stored amount (hash stays stale) */
    await db().planOrder.update({ where: { id: order!.id }, data: { amount: 1 } });

    const res = await jfetch(
      `/api/admin/plan-orders/${order!.id}`,
      adminJar,
      "PATCH",
      JSON.stringify({ action: "paid" })
    );
    expect(res.status).toBe(409);
    const body = (await res.json()) as { code?: string };
    expect(body.code).toBe("ORDER_INTEGRITY");

    /* restore the true amount so the next test can confirm the real order */
    await db().planOrder.update({ where: { id: order!.id }, data: { amount: order!.amount } });
  });

  liveTest("admin confirmation activates the plan + restores access and the site", async () => {
    const adminJar = new CookieJar();
    /* ROUND 124 — candidate-based demo-admin login (seed vs bootstrapped DB) */
    const login = await loginDemoAdmin(jfetch, adminJar);
    expect(login.status).toBe(200);

    const order = await db().planOrder.findFirst({ where: { instanceId }, orderBy: { createdAt: "desc" } });
    const res = await jfetch(
      `/api/admin/plan-orders/${order!.id}`,
      adminJar,
      "PATCH",
      JSON.stringify({ action: "paid" })
    );
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      order: { status: string; effectiveStatus: string };
      instance: { packageId: string | null; entitlement: { state: string; planCycle: string | null } };
    };
    expect(body.order.status).toBe("paid");
    expect(body.instance.packageId).toBe(starterId);
    expect(body.instance.entitlement.state).toBe("active");
    expect(body.instance.entitlement.planCycle).toBe("monthly");

    /* business surface restored for the tenant */
    const records = await jfetch(
      `/api/instances/${instanceId}/module-records?moduleId=pharmacy`,
      jar,
      "GET"
    );
    expect(records.status).toBe(200);

    /* public site: the trial-stop screen is gone. ROUND 79 — the test
     * workspace activated the STARTER plan, which does not include the
     * public-website feature, so the page now renders the premium
     * PLAN-GATE hold screen (different copy) instead of the trial-stop
     * screen — the workspace itself is active and its business APIs work. */
    const page = await fetch(`${BASE}/sites/${instanceId}`);
    const html = await page.text();
    expect(html).not.toContain("هذا الموقع متوقف مؤقتاً");
    expect(html).toContain("هذا الموقع غير متاح في الباقة الحالية");
    /* ROUND 79 — the STARTER plan has no store feature: the public store
     * API stays 404 exactly as the plan gating demands (an Enterprise
     * activation — or a platform feature grant — would open it). */
    const store = await fetch(`${BASE}/api/sites/${instanceId}/store`);
    expect(store.status).toBe(404);
  });

  liveTest("tenant cannot confirm or forge transitions on their own order", async () => {
    /* tenant creates another order then tries the admin action verb */
    const res = await jfetch(
      `/api/instances/${instanceId}/plan-orders`,
      jar,
      "POST",
      JSON.stringify({ packageId: starterId, cycle: "monthly", methodId: "pm_default_wallet" })
    );
    expect(res.status).toBe(201);
    const body = (await res.json()) as { order: { id: string } };

    /* the ADMIN action route requires an admin session — the workspace jar has none */
    const hijack = await jfetch(
      `/api/admin/plan-orders/${body.order.id}`,
      jar,
      "PATCH",
      JSON.stringify({ action: "paid" })
    );
    expect(hijack.status).toBe(401);

    /* tenant CAN cancel their own pending order */
    const cancel = await jfetch(
      `/api/instances/${instanceId}/plan-orders/${body.order.id}`,
      jar,
      "PATCH",
      JSON.stringify({ action: "cancel" })
    );
    expect(cancel.status).toBe(200);
    const cancelled = (await cancel.json()) as { status: string };
    expect(cancelled.status).toBe("cancelled");
  });
});
