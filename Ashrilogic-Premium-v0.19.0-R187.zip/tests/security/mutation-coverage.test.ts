/// <reference types="bun-types" />
/**
 * Ashrilogic — mutation-security coverage regression test (Phase 10).
 *
 * Prevents security regressions when new API routes are added: EVERY
 * route.ts with a mutating handler (POST/PUT/PATCH/DELETE) must go
 * through one of the trusted guards:
 *   - originViolation directly (public mutations — the documented
 *     exemption list), or
 *   - a session guard that runs it internally: requireAdmin /
 *     requireInstanceAccess / requireCustomer with the Request passed.
 *
 * A new mutating route that forgets ALL of these fails this test — the
 * "developer must remember" failure mode is structurally eliminated.
 */

import { describe, expect, test } from "bun:test";
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { stripComments } from "./code-only";

const REPO_ROOT = join(import.meta.dir, "..", "..");
const API_DIR = join(REPO_ROOT, "src", "app", "api");

/** Guard references that satisfy the mutation-security contract.
 *  ROUND 127 — the guard may ALSO be declared in the route wrapper's
 *  guard-plan config (routeHandler(label, { origin: true, admin: {...},
 *  tenant: {...} }, …)): the wrapper translates each stage into the REAL
 *  guard call, so the stage markers are guard evidence of equal standing
 *  with the literal call sites. The markers are deliberately narrow —
 *  `origin: true` and an admin/tenant plan carrying at least one of its
 *  stage-specific keys — so an unrelated `admin: {` DTO property cannot
 *  satisfy the contract by accident. */
const GUARD_PATTERNS = [
  /originViolation/,
  /requireAdmin\s*\(/,
  /requireInstanceAccess\s*\(/,
  /requireCustomer\s*\(/,
  /requireMutationContext/,
  /* the ROUND 127 declarative stages (route.ts runGuardPlan) */
  /\borigin:\s*true\b/,
  /\badmin:\s*\{[^}]*\b(roles|withRequest|manualRoles)\b/,
  /\btenant:\s*\{[^}]*\b(permission|withRequest)\b/,
];

/** Public mutation routes — documented exemptions (mutation-context.ts). */
const EXEMPTIONS = new Set([
  "src/app/api/sites/[id]/orders/route.ts",
  "src/app/api/sites/[id]/contact/route.ts",
  "src/app/api/sites/[id]/visit/route.ts",
  "src/app/api/sites/[id]/store/reviews/route.ts",
  "src/app/api/sites/[id]/store/coupon/route.ts",
  "src/app/api/sites/[id]/account/login/route.ts",
  "src/app/api/sites/[id]/account/register/route.ts",
  "src/app/api/sites/[id]/account/forgot/route.ts",
  "src/app/api/sites/[id]/account/reset/route.ts",
  "src/app/api/sites/[id]/account/verify/resend/route.ts",
  "src/app/api/sites/[id]/account/logout/route.ts",
  "src/app/api/subscribe/route.ts",
  "src/app/api/support/route.ts",
]);

function* walkRoutes(dir: string): Generator<string> {
  for (const entry of readdirSync(dir)) {
    const path = join(dir, entry);
    if (statSync(path).isDirectory()) {
      yield* walkRoutes(path);
    } else if (entry === "route.ts") {
      yield path;
    }
  }
}

/** ROUND 126 — domain-decomposed routes re-export their handlers from a
 *  controller (src/server/domains/<domain>/controller.ts); the guard text
 *  lives THERE. Resolve every `@/server/domains/...` import in a route file
 *  to its on-disk path so guard checks can follow the delegation (the route
 *  file itself may carry none of the guard symbols). */
function domainControllerSources(routeSource: string): string[] {
  const sources: string[] = [];
  const importRe = /from\s+"(@\/server\/domains\/[^"]+)"/g;
  for (const match of routeSource.matchAll(importRe)) {
    const rel = match[1].replace("@/", "src/");
    for (const candidate of [`${rel}.ts`, join(rel, "controller.ts")]) {
      const path = join(REPO_ROOT, candidate);
      try {
        sources.push(readFileSync(path, "utf8"));
        break; /* first existing candidate wins (module or its controller) */
      } catch {
        /* try the next shape */
      }
    }
  }
  return sources;
}

/** A route's effective guard surface: its own source PLUS every domain
 *  controller it delegates to (ROUND 126 — the delegation chains of the
 *  packages / plan-orders / store domains). ROUND 146 — comments are
 *  STRIPPED first: guard evidence must live in executable code, not in a
 *  comment (the commented-out-guard regression the raw-text gate missed). */
function guardSurface(routeSource: string): string {
  return [routeSource, ...domainControllerSources(routeSource)]
    .map(stripComments)
    .join("\n");
}

describe("mutation-security coverage — no unguarded mutating routes", () => {
  test("every mutating handler is guarded (session guard or documented exemption)", () => {
    const unguarded: string[] = [];
    let mutatingRoutes = 0;

    for (const routePath of walkRoutes(API_DIR)) {
      const rel = relative(REPO_ROOT, routePath).replace(/\\/g, "/");
      const source = readFileSync(routePath, "utf8");
      /* ROUND 126 — a mutating handler is either the classic inline
       * `export async function POST` OR a domain delegation
       * `export const POST = <controller fn>`; both must be guarded. */
      const hasMutatingHandler =
        /export\s+async\s+function\s+(POST|PUT|PATCH|DELETE)\b/.test(source) ||
        /export\s+const\s+(POST|PUT|PATCH|DELETE)\s*=/.test(source);
      if (!hasMutatingHandler) continue;
      mutatingRoutes++;
      const guarded = GUARD_PATTERNS.some((p) => p.test(guardSurface(source)));
      if (!guarded && !EXEMPTIONS.has(rel)) {
        unguarded.push(rel);
      }
    }

    expect(mutatingRoutes).toBeGreaterThan(60); /* the known route population */
    expect(unguarded).toEqual([]);
  });

  test("documented public-mutation exemptions still call originViolation", () => {
    for (const rel of EXEMPTIONS) {
      const path = join(REPO_ROOT, rel);
      let source: string;
      try {
        source = readFileSync(path, "utf8");
      } catch {
        continue; /* route removed — the exemption list is advisory */
      }
      /* ROUND 126 — the guard may live in the delegated domain controller;
       * ROUND 127 — it may be declared as the wrapper's origin stage
       *       (translated into originViolation by runGuardPlan);
       * ROUND 146 — comments are stripped first (commented-out guards do
       *       not keep an exemption honest). */
      const surface = guardSurface(source);
      expect(
        /originViolation/.test(surface) || /\borigin:\s*true\b/.test(surface),
        `${rel} is on the public-mutation exemption list but no longer calls originViolation`
      ).toBe(true);
    }
  });

  test("ROUND 146 — the comment-stripping gate: commented-out guard evidence does not pass (scanner proof)", () => {
    /* a commented-out origin guard must NOT satisfy the mutation gate —
     * the exact regression class this round closes. */
    const commentedOut = `
      // const violation = originViolation(req);
      /* origin: true — disabled while debugging */
      export async function POST(req: Request) { return NextResponse.json({}); }
    `;
    const surface = stripComments(commentedOut);
    expect(GUARD_PATTERNS.some((p) => p.test(surface))).toBe(false);
    /* the live form still passes */
    const live = `
      const violation = originViolation(req);
    `;
    expect(GUARD_PATTERNS.some((p) => p.test(stripComments(live)))).toBe(true);
  });
});
