/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 124 (LIVE): the migrated packages routes —
 * byte-level HTTP compatibility proof for the first route→controller→
 * service→repository decomposition.
 *
 * Everything the legacy inline handlers guaranteed must hold EXACTLY
 * through the new delegation chain:
 *   - public GET /api/packages          → 200, active-only, seeded trio
 *   - GET  /api/admin/packages          → 401 unauthenticated, 200 + full
 *                                         catalog with the admin session
 *   - POST /api/admin/packages          → 201 + DTO; the popular flag
 *                                         swaps transactionally; invalid
 *                                         payloads get the legacy zod 400
 *   - PATCH /api/admin/packages/[id]    → 200 + DTO; 404 "Package not
 *                                         found" for unknown ids
 *   - DELETE /api/admin/packages/[id]   → { ok: true }; 404 on repeats
 *   - audit rows land with the legacy actions (package.create/update/delete)
 *   - NEW capability (additive, asserted): x-request-id on every response
 *
 * This suite runs in the battery's LIVE phase (fresh dev server) — it is
 * on the BUILTIN_LIVE list, so an unreachable server is INCONCLUSIVE,
 * never a phantom PASS.
 */
import { describe, test, expect, beforeAll, afterAll } from "bun:test";
import { ensureDemoEnv, loginDemoAdmin, resolveServerDatabaseUrl } from "./test-setup";
import { PrismaClient } from "@prisma/client";

ensureDemoEnv();

const BASE = "http://localhost:3000";
const RUN = Math.random().toString(36).slice(2, 8);
const XFF_IP = `198.18.${(RUN.charCodeAt(0) % 200) + 10}.${(RUN.charCodeAt(1) % 200) + 10}`;
const JSON_HEADERS: Record<string, string> = {
  "content-type": "application/json",
  origin: BASE,
  referer: `${BASE}/`,
};

/* the DEV SERVER's PostgreSQL database (was file:db/custom.db) — resolved
 * lazily so a skipped run (server down) never needs it; see
 * test-setup.resolveServerDatabaseUrl() */
let serverDb: PrismaClient | null = null;
function db(): PrismaClient {
  serverDb ??= new PrismaClient({ datasourceUrl: resolveServerDatabaseUrl() });
  return serverDb;
}

/* ------------------------------ cookie jar ------------------------------ */

class CookieJar {
  private cookies = new Map<string, string>();
  setFrom(res: Response): void {
    const lines: string[] =
      typeof res.headers.getSetCookie === "function" ? res.headers.getSetCookie() : [];
    if (lines.length === 0) {
      const single = res.headers.get("set-cookie");
      if (single) lines.push(single);
    }
    for (const line of lines) {
      const [pair] = line.split(";");
      const eq = pair.indexOf("=");
      if (eq > 0) this.cookies.set(pair.slice(0, eq).trim(), pair.slice(eq + 1).trim());
    }
  }
  header(): string {
    return [...this.cookies.entries()].map(([k, v]) => `${k}=${v}`).join("; ");
  }
}

async function jfetch(path: string, jar: CookieJar, method: string, body?: string): Promise<Response> {
  const cookie = jar.header();
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      "content-type": "application/json",
      "x-forwarded-for": XFF_IP,
      ...(cookie ? { cookie } : {}),
      ...(method === "GET" ? {} : JSON_HEADERS),
    },
    body,
    signal: AbortSignal.timeout(15_000),
  });
  jar.setFrom(res);
  return res;
}


/* 20s per live test — cold Turbopack compilation of a route chain on the
 * battery's FRESH server can exceed bun's 5s default (measured on
 * /api/instances in plan-assignment, ROUND 124); this matches the 15s
 * jfetch abort budget + compile margin, mirroring the other live suites. */
function liveTest(name: string, fn: () => Promise<void>): void {
  test(name, fn, 20_000);
}

/* -------------------------------- suite -------------------------------- */

describe("ROUND 124 — packages routes (live, migrated to the domain)", () => {
  const anonJar = new CookieJar();
  const adminJar = new CookieJar();
  const createdIds: string[] = [];
  let priorPopularId: string | null = null;

  beforeAll(async () => {
    /* the live demo server must be up (the battery guarantees it in the
     * live phase; a local solo run needs `bun run dev` first) */
    const probe = await fetch(`${BASE}/api/packages`, { signal: AbortSignal.timeout(10_000) });
    expect(probe.ok).toBe(true);

    const login = await loginDemoAdmin(jfetch, adminJar);
    expect(login.status).toBe(200);
  });

  afterAll(async () => {
    /* demo-DB hygiene: remove ONLY this run's plans (nameEn carries RUN) */
    if (createdIds.length > 0) {
      await db().package.deleteMany({ where: { id: { in: createdIds } } }).catch(() => undefined);
    }
    await serverDb?.$disconnect();
  });

  liveTest("public pricing feed: active-only, seeded trio present, x-request-id attached", async () => {
    const res = await jfetch("/api/packages", anonJar, "GET");
    expect(res.status).toBe(200);
    const plans = (await res.json()) as { nameEn: string; active: boolean }[];
    expect(plans.length).toBeGreaterThan(0);
    expect(plans.every((p) => p.active)).toBe(true);
    expect(plans.some((p) => p.nameEn === "Starter")).toBe(true);
    /* ROUND 124 — the wrapper's correlation id (additive capability) */
    expect(res.headers.get("x-request-id")).toBeTruthy();
  });

  liveTest("admin catalog: 401 unauthenticated, 200 with the admin session (full list)", async () => {
    const denied = await jfetch("/api/admin/packages", anonJar, "GET");
    expect(denied.status).toBe(401);

    const res = await jfetch("/api/admin/packages", adminJar, "GET");
    expect(res.status).toBe(200);
    const plans = (await res.json()) as { id: string; active: boolean; popular: boolean }[];
    expect(plans.length).toBeGreaterThanOrEqual(3);
    /* admin sees inactive plans too (the public feed filters them) */
    const publicRes = await jfetch("/api/packages", anonJar, "GET");
    const pub = (await publicRes.json()) as unknown[];
    expect(plans.length).toBeGreaterThanOrEqual(pub.length);
    priorPopularId = plans.find((p) => p.popular)?.id ?? null;
  });

  liveTest("create: 201 + DTO, and popular:true demotes the previous featured plan", async () => {
    const payload = {
      nameAr: `باقة اختبار ${RUN}`,
      nameEn: `QA Live Plan ${RUN}`,
      descAr: "وصف اختبار",
      descEn: "QA live description",
      priceMonthly: 299,
      priceYearly: 2990,
      currency: "SAR",
      features: ["ميزة أولى", "ميزة ثانية", "ميزة ثالثة"],
      featuresEn: ["First", "Second", "Third"],
      maxUsers: 15,
      maxModules: 25,
      maxStorageMb: 2048,
      discountPct: 5,
      yearlyDiscountPct: 10,
      capabilities: ["publicWebsite", "backup"],
      popular: true,
      active: true,
      sortOrder: 60,
    };
    const res = await jfetch("/api/admin/packages", adminJar, "POST", JSON.stringify(payload));
    expect(res.status).toBe(201);
    const dto = (await res.json()) as {
      id: string;
      nameEn: string;
      popular: boolean;
      discountPct: number;
    };
    expect(dto.nameEn).toBe(`QA Live Plan ${RUN}`);
    expect(dto.popular).toBe(true);
    createdIds.push(dto.id);

    /* the single-popular invariant now points at the new plan */
    const after = (await (await jfetch("/api/admin/packages", adminJar, "GET")).json()) as {
      id: string;
      popular: boolean;
    }[];
    expect(after.filter((p) => p.popular)).toHaveLength(1);
    expect(after.find((p) => p.id === dto.id)?.popular).toBe(true);
    if (priorPopularId) {
      expect(after.find((p) => p.id === priorPopularId)?.popular).toBe(false);
    }
  });

  liveTest("create: invalid payload → the legacy zod 400 envelope (not a 500)", async () => {
    const res = await jfetch(
      "/api/admin/packages",
      adminJar,
      "POST",
      JSON.stringify({ nameAr: "x", bogus: true })
    );
    expect(res.status).toBe(400);
    const body = (await res.json()) as { error?: string };
    expect(body.error).toBeTruthy();
    expect(body.error!.startsWith("Validation failed — ")).toBe(true);
  });

  liveTest("create: malformed JSON body → 400 'Invalid JSON body' (bounded reader preserved)", async () => {
    const res = await jfetch("/api/admin/packages", adminJar, "POST", "{not json");
    expect(res.status).toBe(400);
    expect(((await res.json()) as { error?: string }).error).toBe("Invalid JSON body");
  });

  liveTest("create: unauthenticated → 401 (guard order preserved: auth before body)", async () => {
    const res = await jfetch("/api/admin/packages", anonJar, "POST", JSON.stringify({ x: 1 }));
    expect(res.status).toBe(401);
  });

  liveTest("patch: 200 + partial fields; unknown id → the exact legacy 404", async () => {
    const id = createdIds[0];
    const res = await jfetch(
      `/api/admin/packages/${id}`,
      adminJar,
      "PATCH",
      JSON.stringify({ priceMonthly: 349 })
    );
    expect(res.status).toBe(200);
    const dto = (await res.json()) as { priceMonthly: number; nameEn: string };
    expect(dto.priceMonthly).toBe(349);
    expect(dto.nameEn).toBe(`QA Live Plan ${RUN}`);

    const missing = await jfetch(
      "/api/admin/packages/nonexistent-id",
      adminJar,
      "PATCH",
      JSON.stringify({ priceMonthly: 1 })
    );
    expect(missing.status).toBe(404);
    expect(((await missing.json()) as { error?: string }).error).toBe("Package not found");
  });

  liveTest("delete: { ok: true }; repeat delete → the exact legacy 404", async () => {
    const id = createdIds[0];
    const res = await jfetch(`/api/admin/packages/${id}`, adminJar, "DELETE");
    expect(res.status).toBe(200);
    expect(((await res.json()) as { ok?: boolean }).ok).toBe(true);
    /* keep createdIds (the afterAll deleteMany tolerates already-deleted) */
    const repeat = await jfetch(`/api/admin/packages/${id}`, adminJar, "DELETE");
    expect(repeat.status).toBe(404);
    expect(((await repeat.json()) as { error?: string }).error).toBe("Package not found");
  });

  liveTest("audit trail carries the legacy package.* actions for this run", async () => {
    const rows = await db().auditLog.findMany({
      where: { action: { in: ["package.create", "package.update", "package.delete"] } },
      orderBy: { createdAt: "desc" },
      take: 30,
    });
    const actions = new Set(rows.map((r) => r.action));
    expect(actions.has("package.create")).toBe(true);
    expect(actions.has("package.update")).toBe(true);
    expect(actions.has("package.delete")).toBe(true);
    /* this run's create is attributed with the QA target label */
    const mine = rows.find((r) => r.targetLabel === `QA Live Plan ${RUN}`);
    expect(mine).toBeTruthy();
  });
});
