/**
 * Audit-chain regression tests (round 38 tamper-evidence).
 *
 * Proves: chained writes link correctly, content edits are DETECTED, row
 * deletions are DETECTED (orphan links), forks are DETECTED, gaps are
 * visible-but-healthy, and hash computation is deterministic + sensitive
 * to every covered field.
 */
import { beforeAll, describe, expect, test } from "bun:test";
import { getTestDb } from "./test-setup";
import { computeChainHash, verifyChainHashes, type ChainRow } from "@/lib/server/audit-chain";

describe("audit chain — hash computation", () => {
  const base = {
    prevChainHash: null,
    actorType: "admin",
    actorId: "abc",
    actorName: "k***@ashrilogic.com",
    action: "admin.login",
    targetLabel: null,
    metaJson: null,
    createdAtISO: "2026-01-01T00:00:00.000Z",
  };

  test("deterministic — same input, same hash", () => {
    expect(computeChainHash(base)).toBe(computeChainHash({ ...base }));
  });

  test("64-char hex output", () => {
    expect(computeChainHash(base)).toMatch(/^[0-9a-f]{64}$/);
  });

  test("sensitive to EVERY covered field (nulls, content, prev, timestamp)", () => {
    const h = computeChainHash(base);
    const variants: Parameters<typeof computeChainHash>[0][] = [
      { ...base, prevChainHash: "deadbeef" },
      { ...base, actorType: "instance" },
      { ...base, actorId: null },
      { ...base, actorName: "x***@ashrilogic.com" },
      { ...base, action: "admin.loginFailed" },
      { ...base, targetLabel: "Noor Schools" },
      { ...base, metaJson: '{"k":"v"}' },
      { ...base, createdAtISO: "2026-01-01T00:00:00.001Z" },
    ];
    for (const v of variants) {
      expect(computeChainHash(v)).not.toBe(h);
    }
  });
});

describe("audit chain — verify core", () => {
  beforeAll(async () => {
    const db = await getTestDb();
    await db.auditLog.deleteMany();
  });

  function makeRow(over: Partial<ChainRow> = {}): ChainRow {
    return {
      id: crypto.randomUUID(),
      actorType: "admin",
      actorId: null,
      actorName: "t***@test.local",
      action: "admin.login",
      targetLabel: null,
      metaJson: null,
      createdAt: new Date(),
      prevChainHash: null,
      chainHash: null,
      ...over,
    };
  }

  /** Build a correctly-chained sequence (each row's hash covers its prev). */
  function buildChain(count: number, prefix = "ev"): ChainRow[] {
    const rows: ChainRow[] = [];
    let prev: string | null = null;
    for (let i = 0; i < count; i++) {
      const r = makeRow({ action: `${prefix}${i}` });
      const chainHash = computeChainHash({
        prevChainHash: prev,
        actorType: r.actorType,
        actorId: r.actorId,
        actorName: r.actorName,
        action: r.action,
        targetLabel: r.targetLabel,
        metaJson: r.metaJson,
        createdAtISO: r.createdAt.toISOString(),
      });
      r.prevChainHash = prev;
      r.chainHash = chainHash;
      prev = chainHash;
      rows.push(r);
    }
    return rows;
  }

  test("a correctly chained sequence verifies healthy with exactly one head", () => {
    const v = verifyChainHashes(buildChain(3));
    expect(v.healthy).toBe(true);
    expect(v.heads).toBe(1);
    expect(v.chainedRows).toBe(3);
    expect(v.gapRows).toBe(0);
  });

  test("TAMPERING: editing a row's content after write is detected", () => {
    const rows = buildChain(3, "tamper");
    rows[1].actorName = "EDITED-AFTER-WRITE";
    const v = verifyChainHashes(rows);
    expect(v.healthy).toBe(false);
    expect(v.tampered).toHaveLength(1);
    expect(v.tampered[0].action).toBe("tamper1");
  });

  test("DELETION: removing a middle row orphans its successor", () => {
    const rows = buildChain(3, "del");
    const afterDeletion = [rows[0], rows[2]]; // rows[1] deleted
    const v = verifyChainHashes(afterDeletion);
    expect(v.healthy).toBe(false);
    expect(v.orphans).toHaveLength(1);
    expect(v.orphans[0].action).toBe("del2");
  });

  test("FORK: two rows claiming the same predecessor are detected", () => {
    const [genesis, a, b] = buildChain(3, "fork");
    // attacker/author splices BOTH a and b onto genesis
    a.prevChainHash = genesis.chainHash;
    a.chainHash = computeChainHash({
      prevChainHash: genesis.chainHash,
      actorType: a.actorType,
      actorId: a.actorId,
      actorName: a.actorName,
      action: a.action,
      targetLabel: a.targetLabel,
      metaJson: a.metaJson,
      createdAtISO: a.createdAt.toISOString(),
    });
    b.prevChainHash = genesis.chainHash;
    b.chainHash = computeChainHash({
      prevChainHash: genesis.chainHash,
      actorType: b.actorType,
      actorId: b.actorId,
      actorName: b.actorName,
      action: b.action,
      targetLabel: b.targetLabel,
      metaJson: b.metaJson,
      createdAtISO: b.createdAt.toISOString(),
    });
    const v = verifyChainHashes([genesis, a, b]);
    expect(v.healthy).toBe(false);
    expect(v.forks.length).toBeGreaterThanOrEqual(2);
  });

  test("GAPS: NULL-hash rows are visible but do not fail the chain", () => {
    const gap = makeRow({ action: "legacy.event" }); // chainHash stays null
    const v = verifyChainHashes([gap]);
    expect(v.gapRows).toBe(1);
    expect(v.healthy).toBe(true);
  });
});

describe("audit chain — logAudit end-to-end (isolated test DB)", () => {
  test("logAudit writes chained rows and the stored chain verifies healthy", async () => {
    const db = await getTestDb();
    await db.auditLog.deleteMany();
    const { logAudit } = await import("@/lib/server/audit");
    await logAudit({ actorType: "public", actorName: "e***@test.local", action: "customer.login" });
    await logAudit({ actorType: "admin", actorName: "a***@test.local", action: "admin.login" });
    // logAudit is fire-and-forget — give the writes a moment to land
    await new Promise((r) => setTimeout(r, 500));
    const rows = (await db.auditLog.findMany({
      orderBy: [{ createdAt: "asc" }, { id: "asc" }],
    })) as ChainRow[];
    expect(rows.length).toBeGreaterThanOrEqual(2);
    for (const r of rows) {
      expect(r.chainHash).toMatch(/^[0-9a-f]{64}$/);
    }
    const v = verifyChainHashes(rows);
    expect(v.healthy).toBe(true);
    expect(v.chainedRows).toBe(rows.length);
    expect(v.heads).toBe(1);
  });
});
