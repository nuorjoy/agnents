/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — integer minor-unit money utilities
 * (src/lib/server/money.ts).
 *
 * Task-2 fix under test: monetary values are persisted as INTEGER MINOR
 * UNITS — float arithmetic must never touch stored money. These tests pin
 * the conversion boundary (display ↔ minor), the raw-text parsing gate and
 * the storable-range validator.
 */
import { describe, test, expect } from "bun:test";
import {
  toMinorUnits,
  toDisplayUnits,
  parsePriceCellToMinor,
  isValidMinorUnits,
  MAX_MINOR_UNITS,
} from "@/lib/server/money";

describe("money — display → minor units", () => {
  test("toMinorUnits converts exactly (no float truncation)", () => {
    expect(toMinorUnits(59.97)).toBe(5997);
    expect(toMinorUnits(199)).toBe(19900);
    expect(toMinorUnits(0)).toBe(0);
    expect(toMinorUnits(1.05)).toBe(105);
    expect(toMinorUnits(12.5)).toBe(1250);
  });

  test("non-positive / non-finite inputs clamp to 0", () => {
    expect(toMinorUnits(-5)).toBe(0);
    expect(toMinorUnits(-0.01)).toBe(0);
    expect(toMinorUnits(Number.NaN)).toBe(0);
    expect(toMinorUnits(Number.POSITIVE_INFINITY)).toBe(0);
    expect(toMinorUnits(Number.NEGATIVE_INFINITY)).toBe(0);
  });
});

describe("money — minor → display units", () => {
  test("toDisplayUnits converts exactly", () => {
    expect(toDisplayUnits(5997)).toBe(59.97);
    expect(toDisplayUnits(19900)).toBe(199);
    expect(toDisplayUnits(0)).toBe(0);
    expect(toDisplayUnits(105)).toBe(1.05);
  });

  test("roundtrip minor → display → minor is lossless", () => {
    for (const minor of [0, 1, 105, 5997, 19900, 123456, MAX_MINOR_UNITS]) {
      expect(toMinorUnits(toDisplayUnits(minor))).toBe(minor);
    }
    expect(toDisplayUnits(toMinorUnits(59.97))).toBe(59.97);
  });
});

describe("money — raw text parsing (the only place text becomes money)", () => {
  test("parsePriceCellToMinor handles plain, comma-grouped and decimal text", () => {
    expect(parsePriceCellToMinor("59.97")).toBe(5997);
    expect(parsePriceCellToMinor("1,200")).toBe(120000);
    expect(parsePriceCellToMinor("12.5")).toBe(1250);
    expect(parsePriceCellToMinor(" 199 ")).toBe(19900);
    expect(parsePriceCellToMinor("1 199.50")).toBe(119950);
  });

  test("garbage and empty text become 0 — never NaN, never negative", () => {
    expect(parsePriceCellToMinor("abc")).toBe(0);
    expect(parsePriceCellToMinor("")).toBe(0);
    expect(parsePriceCellToMinor(undefined)).toBe(0);
    expect(parsePriceCellToMinor("--")).toBe(0);
    expect(parsePriceCellToMinor("-50")).toBe(0);
    // a hyphen anywhere makes the stripped residue negative → clamped to 0
    expect(parsePriceCellToMinor("not-a-price 99")).toBe(0);
    // digits embedded in garbage survive the strip → parsed
    expect(parsePriceCellToMinor("qty: 99")).toBe(9900);
    expect(parsePriceCellToMinor("abc99def")).toBe(9900);
  });
});

describe("money — storable-range validation", () => {
  test("valid: integers from 0 up to the 2e9 platform ceiling (MAX_MINOR_UNITS)", () => {
    expect(isValidMinorUnits(0)).toBe(true);
    expect(isValidMinorUnits(1)).toBe(true);
    expect(isValidMinorUnits(5997)).toBe(true);
    expect(isValidMinorUnits(MAX_MINOR_UNITS)).toBe(true);
    expect(isValidMinorUnits(2_000_000_000)).toBe(true);
  });

  test("invalid: negatives, floats, overflow, NaN, Infinity", () => {
    expect(isValidMinorUnits(-1)).toBe(false);
    expect(isValidMinorUnits(-0.01)).toBe(false);
    expect(isValidMinorUnits(1.5)).toBe(false);
    expect(isValidMinorUnits(MAX_MINOR_UNITS + 1)).toBe(false);
    expect(isValidMinorUnits(2_000_000_001)).toBe(false);
    expect(isValidMinorUnits(Number.NaN)).toBe(false);
    expect(isValidMinorUnits(Number.POSITIVE_INFINITY)).toBe(false);
  });
});
