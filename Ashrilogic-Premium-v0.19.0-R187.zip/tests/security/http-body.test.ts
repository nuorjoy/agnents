/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — bounded request-body reading
 * (src/lib/server/http.ts).
 *
 * Task-2 fix under test: handlers no longer call the unbounded req.json().
 * readJson enforces a declared Content-Length cap AND a chunk-by-chunk
 * stream cap (chunked encodings cannot lie past it), degrading to clean
 * 400/413 NextResponses instead of throwing or over-reading.
 */
import { describe, test, expect } from "bun:test";
import { readJson } from "@/lib/server/http";

function post(body: BodyInit, headers: Record<string, string> = {}): Request {
  return new Request("http://localhost:3000/api/probe", {
    method: "POST",
    headers: { "content-type": "application/json", ...headers },
    body,
  });
}

describe("http-body — readJson", () => {
  test("valid JSON body → ok:true with the parsed data", async () => {
    const result = await readJson(post(JSON.stringify({ username: "sara.ops", n: 3 })));
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.data).toEqual({ username: "sara.ops", n: 3 });
    }
  });

  test("malformed JSON body → ok:false with a 400 response", async () => {
    const result = await readJson(post("{"));
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.response.status).toBe(400);
      const body = (await result.response.json()) as { error?: string };
      expect(body.error).toBe("Invalid JSON body");
    }
  });

  test("empty body → ok:false with a 400 (\"Request body is required\")", async () => {
    const result = await readJson(post(""));
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.response.status).toBe(400);
    }
  });

  test("streamed body OVER the cap (2 × 600KB chunks, 1MB cap) → ok:false with 413", async () => {
    const chunk = new Uint8Array(600 * 1024); // 600 KB of zeros
    const stream = new ReadableStream<Uint8Array>({
      start(controller) {
        controller.enqueue(chunk);
        controller.enqueue(chunk); // 1.2 MB total — past the 1 MB cap
        controller.close();
      },
    });
    const result = await readJson(post(stream), 1024 * 1024);
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.response.status).toBe(413);
      const body = (await result.response.json()) as { error?: string };
      expect(body.error).toBe("Request body too large");
    }
  });

  test("declared Content-Length over the cap is refused WITHOUT reading the body", async () => {
    // a 100-byte actual body lying with a 100MB Content-Length → 413 up front
    const result = await readJson(
      post("x".repeat(100), { "content-length": String(100 * 1024 * 1024) }),
      1024 * 1024
    );
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.response.status).toBe(413);
    }
  });

  test("body exactly at the cap boundary is still read", async () => {
    const payload = JSON.stringify({ pad: "x".repeat(1024 * 1024 - 20) });
    const result = await readJson(post(payload), 1024 * 1024 + 256);
    expect(result.ok).toBe(true);
  });
});
