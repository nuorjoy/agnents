/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — AUDIT-CHAIN HEAD ANCHOR (ROUND 118).
 *
 * Proves the external head anchor does what the in-DB chain cannot:
 *  - the MAC seal: append → read-back round-trip; a tampered payload
 *    line (any field changed) fails verification; a forged MAC fails;
 *  - verdict matrix: ok (chain grew past the pinned head), ok (quiet
 *    chain re-anchored at the same head), truncated (the pinned head row
 *    deleted while the anchor is inside every retention window — the
 *    tail-deletion attack the chain alone could never see), tampered
 *    (the pinned row's stored hash rewritten), stale (anchor older than
 *    the safety-net horizon), unanchored (chain without any anchor),
 *    no-chain (fresh install), tail-corrupt (partial last line is
 *    skipped, the last VERIFIABLE line still anchors).
 */
import { beforeAll, afterAll, describe, expect, test } from "bun:test";
import { mkdtempSync, rmSync, writeFileSync, appendFileSync, existsSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { getTestDb, ensureDemoEnv, type TestDb } from "./test-setup";

let db: TestDb;
const TMP = mkdtempSync(join(tmpdir(), "ashrilogic-audit-anchor-"));
const ANCHOR_FILE = join(TMP, "anchors.jsonl");

beforeAll(async () => {
  db = await getTestDb();
  /* route the anchor module at the throwaway file BEFORE importing it */
  process.env.ASHRILOGIC_AUDIT_ANCHOR_FILE = ANCHOR_FILE;
  await db.auditLog.deleteMany({});
  await db.schedulerLease.deleteMany({});
});

afterAll(() => {
  rmSync(TMP, { recursive: true, force: true });
});

/* The module under test (imported AFTER env routing — same discipline as
 * the other DB-bound test suites). */
async function mod() {
  ensureDemoEnv();
  process.env.ASHRILOGIC_AUDIT_ANCHOR_FILE = ANCHOR_FILE;
  return import("@/lib/server/audit-anchor");
}

/** Insert one chained audit row (links onto the given prev hash). */
/** monotonic seeding clock: strictly increasing per-row timestamps (the
 *  head query breaks createdAt ties by id DESC — same-ms siblings made
 *  the "latest row" non-deterministic under fast seeding) */
let seedClock = 0;
async function seedChainedRow(
  action: string,
  prev: string | null
): Promise<{ id: string; chainHash: string }> {
  const { computeChainHash } = await import("@/lib/server/audit-chain");
  const id = crypto.randomUUID();
  seedClock += 1;
  const createdAt = new Date(Date.now() + seedClock * 1000);
  const chainHash = computeChainHash({
    prevChainHash: prev,
    actorType: "admin",
    actorId: null,
    actorName: "t***@test.local",
    action,
    targetLabel: null,
    metaJson: null,
    createdAtISO: createdAt.toISOString(),
  });
  await db.auditLog.create({
    data: {
      id,
      actorType: "admin",
      actorId: null,
      actorName: "t***@test.local",
      action,
      targetLabel: null,
      metaJson: null,
      createdAt,
      prevChainHash: prev,
      chainHash,
    },
  });
  return { id, chainHash };
}

describe("audit head anchor — MAC seal + file round-trip", () => {
  test("append → read-back returns the exact payload (verifiable line)", async () => {
    await db.auditLog.deleteMany({});
    const head = await seedChainedRow("a1", null);

    const m = await mod();
    const result = await m.appendHeadAnchor("manual");
    expect(result.ok).toBe(true);
    if (!result.ok) return;

    const read = await m.readLatestHeadAnchor();
    expect(read.unreadable).toBe(false);
    expect(read.tailCorrupt).toBe(false);
    expect(read.anchor).not.toBeNull();
    expect(read.anchor?.headRowId).toBe(head.id);
    expect(read.anchor?.headHash).toBe(head.chainHash);
    expect(read.anchor?.totalRows).toBe(1);
    expect(read.anchor?.chainedRows).toBe(1);
    expect(read.anchor?.trigger).toBe("manual");
  });

  test("a SECOND append supersedes the first (latest line wins)", async () => {
    const m = await mod();
    await seedChainedRow("a2", (await m.getChainHead())?.headHash ?? null);
    await m.appendHeadAnchor("auto");

    const read = await m.readLatestHeadAnchor();
    expect(read.anchor?.trigger).toBe("auto");
    expect(read.anchor?.totalRows).toBe(2);
  });

  test("tampering a payload field breaks verification (the seal catches it)", async () => {
    const m = await mod();
    const before = await m.readLatestHeadAnchor();
    expect(before.anchor).not.toBeNull();

    /* rewrite the file with the totalRows inflated — the MAC no longer
     * matches the payload */
    const lines = (await Bun.file(ANCHOR_FILE).text()).split("\n").filter(Boolean);
    const last = JSON.parse(lines[lines.length - 1]) as Record<string, unknown>;
    last.totalRows = 999;
    lines[lines.length - 1] = JSON.stringify(last);
    writeFileSync(ANCHOR_FILE, `${lines.join("\n")}\n`);

    const read = await m.readLatestHeadAnchor();
    /* the tampered line cannot be verified; no earlier line remains valid
     * here (both were superseded single-line anchors — only the last is
     * expected to verify) */
    expect(read.anchor === null || read.anchor?.totalRows !== 999).toBe(true);
  });
});

describe("audit head anchor — verdict matrix", () => {
  test("ok: chain grew past the pinned head (normal operation)", async () => {
    await db.auditLog.deleteMany({});
    const head1 = await seedChainedRow("v1", null);
    const m = await mod();
    await m.appendHeadAnchor("manual");
    /* two more rows arrive after the anchor, chained properly */
    const head2 = await seedChainedRow("v2", head1.chainHash);
    const head3 = await seedChainedRow("v3", head2.chainHash);

    const verdict = await m.verifyHeadAnchor();
    expect(verdict.status).toBe("ok");
    expect(verdict.anchoredRowPresent).toBe(true);
    expect(verdict.rowsSinceAnchor).toBeGreaterThanOrEqual(2);
    expect(verdict.head?.headRowId).toBe(head3.id);
  });

  test("truncated: the pinned head row is deleted (the tail-deletion attack)", async () => {
    await db.auditLog.deleteMany({});
    const head = await seedChainedRow("t1", null);
    const m = await mod();
    await m.appendHeadAnchor("manual");

    /* the attacker (DB-only compromise) deletes the newest rows */
    await db.auditLog.delete({ where: { id: head.id } });

    /* chain empty + anchor exists → truncated (the anchored chain is gone) */
    const empty = await m.verifyHeadAnchor();
    expect(empty.status).toBe("truncated");

    /* restore a chain: an OLDER row only (prev-link severed) — still a
     * fresh anchor whose pinned row is missing → truncated */
    await seedChainedRow("t2", null);
    const partial = await m.verifyHeadAnchor();
    expect(partial.status).toBe("truncated");
    expect(partial.anchoredRowPresent).toBe(false);
  });

  test("tampered: the pinned row exists but its hash was rewritten", async () => {
    await db.auditLog.deleteMany({});
    const head = await seedChainedRow("x1", null);
    const m = await mod();
    await m.appendHeadAnchor("manual");

    /* the attacker rewrites the row's stored hash (laundering attempt) */
    await db.auditLog.update({
      where: { id: head.id },
      data: { chainHash: "f".repeat(64) },
    });

    const verdict = await m.verifyHeadAnchor();
    expect(verdict.status).toBe("tampered");
    expect(verdict.anchoredRowPresent).toBe(true);
  });

  test("stale: the anchor is older than the safety-net horizon", async () => {
    await db.auditLog.deleteMany({});
    const head = await seedChainedRow("s1", null);
    const m = await mod();
    await m.appendHeadAnchor("manual");

    /* age the only anchor line past ANCHOR_STALE_MS by rewriting its
     * anchoredAt — the MAC is recomputed for the new timestamp (a valid,
     * simply OLD seal — exactly what a stalled scheduler produces) */
    const { computeAnchorMac, canonicalAnchorJson } = await mod();
    const read = await m.readLatestHeadAnchor();
    expect(read.anchor).not.toBeNull();
    const old = new Date(Date.now() - (m.ANCHOR_STALE_MS + 60_000)).toISOString();
    const payload = {
      v: 1 as const,
      trigger: "auto" as const,
      anchoredAt: old,
      headRowId: read.anchor!.headRowId,
      headHash: read.anchor!.headHash,
      totalRows: read.anchor!.totalRows,
      chainedRows: read.anchor!.chainedRows,
    };
    writeFileSync(
      ANCHOR_FILE,
      `${JSON.stringify({ ...payload, mac: computeAnchorMac(canonicalAnchorJson(payload)) })}\n`
    );

    const verdict = await m.verifyHeadAnchor();
    expect(verdict.status).toBe("stale");
    expect(verdict.anchoredRowPresent).toBe(true);
    expect(verdict.anchorAgeMs).not.toBeNull();
    expect(verdict.anchorAgeMs as number).toBeGreaterThan(m.ANCHOR_STALE_MS);
  });

  test("unanchored: a live chain with no anchor file at all", async () => {
    await db.auditLog.deleteMany({});
    await seedChainedRow("u1", null);
    rmSync(ANCHOR_FILE, { force: true });

    const m = await mod();
    const verdict = await m.verifyHeadAnchor();
    expect(verdict.status).toBe("unanchored");
    expect(verdict.anchor).toBeNull();
  });

  test("no-chain: fresh install (no rows, no anchor)", async () => {
    await db.auditLog.deleteMany({});
    rmSync(ANCHOR_FILE, { force: true });

    const m = await mod();
    const verdict = await m.verifyHeadAnchor();
    expect(verdict.status).toBe("no-chain");
    expect(verdict.head).toBeNull();
  });

  test("tailCorrupt: a partial last line is skipped; the last good anchor still adjudicates", async () => {
    await db.auditLog.deleteMany({});
    const head = await seedChainedRow("c1", null);
    const m = await mod();
    await m.appendHeadAnchor("manual");
    /* simulate a crash mid-append: a truncated JSON fragment */
    appendFileSync(ANCHOR_FILE, '{"v":1,"trigger":"auto","anchoredAt":"2026-');

    const read = await m.readLatestHeadAnchor();
    expect(read.tailCorrupt).toBe(true);
    expect(read.anchor).not.toBeNull();
    expect(read.anchor?.headRowId).toBe(head.id);

    const verdict = await m.verifyHeadAnchor();
    expect(verdict.status).toBe("ok");
    expect(verdict.tailCorrupt).toBe(true);
  });

  test("appendHeadAnchor refuses cleanly on a chainless DB", async () => {
    await db.auditLog.deleteMany({});
    const m = await mod();
    const result = await m.appendHeadAnchor("manual");
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error).toContain("no chained rows");
  });
});

describe("audit head anchor — journal export (ROUND 119)", () => {
  test("the raw journal round-trips with the true line count", async () => {
    await db.auditLog.deleteMany({});
    await seedChainedRow("e1", null);
    /* fresh journal: earlier describes in this run appended their own
       lines — the export reads the FILE, so start it empty */
    writeFileSync(ANCHOR_FILE, "");
    const m = await mod();
    await m.appendHeadAnchor("manual");
    await m.appendHeadAnchor("auto");

    const exported = await m.readAnchorJournalForExport();
    expect(exported).not.toBeNull();
    expect(exported?.lines).toBe(2);
    /* the export IS the raw file (including the trailing newline) */
    const raw = await Bun.file(ANCHOR_FILE).text();
    expect(exported?.text).toBe(raw);
    /* both sealed lines are present verbatim */
    expect(exported?.text).toContain('"trigger":"manual"');
    expect(exported?.text).toContain('"trigger":"auto"');
  });

  test("no journal file → null (the route answers 404)", async () => {
    rmSync(ANCHOR_FILE, { force: true });
    const m = await mod();
    expect(await m.readAnchorJournalForExport()).toBeNull();
  });

  test("a partial tail line still exports (forensic value over prettiness)", async () => {
    await db.auditLog.deleteMany({});
    await seedChainedRow("e2", null);
    writeFileSync(ANCHOR_FILE, "");
    const m = await mod();
    await m.appendHeadAnchor("manual");
    appendFileSync(ANCHOR_FILE, '{"v":1,"trigger":"auto","anchoredAt":"2026-');

    const exported = await m.readAnchorJournalForExport();
    expect(exported).not.toBeNull();
    /* the partial line counts as a line — the operator sees exactly what
     * sits on disk (the VERDICT layer separately reports tailCorrupt) */
    expect(exported?.lines).toBe(2);
    expect(exported?.text.endsWith('{"v":1,"trigger":"auto","anchoredAt":"2026-')).toBe(true);
  });
});
