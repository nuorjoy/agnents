/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — product media gallery + storefront visibility (ROUND 140).
 *
 * Pins under test:
 *  - the `gallery` / `videos` / `storeVisible` fields on module-record write
 *    bodies: managed refs ONLY (no data-URLs, no cross-origin URLs, no bare
 *    hex), array caps (6 photos / 2 videos), booleans for the checkmark;
 *  - the VIDEO magic-byte gate: MP4 (ftyp), QuickTime (ftyp qt + legacy atom
 *    headers), WebM (EBML) pass; HTML/SVG/short/garbage buffers are refused;
 *    the 10 MB cap and the declared-mime cross-check hold;
 *  - resolveRecordGallery / resolveRecordVideos: undefined keeps, [] clears,
 *    LIVE asset rows pass verbatim, GC'd rows are refused (IMAGE_GONE /
 *    VIDEO_GONE — the ROUND 120 TOCTOU contract extended to both families),
 *    duplicates dedupe, over-cap lists are rejected;
 *  - the catalog derivation: toSiteProduct exposes the ordered gallery
 *    (cover first) + the videos + the checkmark, and loadStoreProducts
 *    (the PUBLIC catalog) never lists a hidden product.
 *
 * CANONICAL IMPORT DISCIPLINE: every module that transitively binds
 * `@/lib/db` is imported DYNAMICALLY inside the tests — AFTER ensureDemoEnv()
 * has set the isolated DATABASE_URL (see the test-setup canary's guidance).
 */
import { describe, test, expect, beforeAll } from "bun:test";
import { ensureDemoEnv, getTestDb, type TestDb } from "./test-setup";

ensureDemoEnv();

const HEX64 = "a".repeat(64);
const HEX64_B = "b".repeat(64);
const MANAGED_IMG = `/api/images/${HEX64}`;
const MANAGED_IMG_B = `/api/images/${HEX64_B}`;
const MANAGED_VID = `/api/videos/${HEX64}`;
const MANAGED_VID_B = `/api/videos/${HEX64_B}`;
const GHOST_IMG = `/api/images/${"c".repeat(64)}`;
const GHOST_VID = `/api/videos/${"c".repeat(64)}`;
const PNG_DATA_URL = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==";

/* the dynamically-imported surfaces, resolved lazily per describe */
type Mapper = typeof import("@/lib/server/module-record-mapper");
type RecordMedia = typeof import("@/lib/server/record-media");
type MediaStore = typeof import("@/lib/server/media-store");
type StoreMapper = typeof import("@/lib/server/store-mapper");

let __db: TestDb | null = null;
async function testDb(): Promise<TestDb> {
  if (!__db) __db = await getTestDb();
  return __db;
}

/* ---------------------- write-schema shapes ---------------------- */

describe("product media — write-schema accepted shapes", () => {
  let mapper: Mapper;
  beforeAll(async () => {
    await testDb();
    mapper = await import("@/lib/server/module-record-mapper");
  });

  test("gallery of managed refs (≤6) passes the update schema", () => {
    const refs = Array.from({ length: 6 }, (_, i) => `/api/images/${HEX64.slice(0, 63)}${i}`);
    const parsed = mapper.moduleRecordUpdateSchema.safeParse({ gallery: refs });
    expect(parsed.success).toBe(true);
  });

  test("empty gallery (explicit clear) + empty videos pass", () => {
    const parsed = mapper.moduleRecordUpdateSchema.safeParse({ gallery: [], videos: [] });
    expect(parsed.success).toBe(true);
  });

  test("videos of managed /api/videos refs (≤2) pass", () => {
    const parsed = mapper.moduleRecordUpdateSchema.safeParse({
      videos: [MANAGED_VID, MANAGED_VID_B],
    });
    expect(parsed.success).toBe(true);
  });

  test("storeVisible boolean passes alone (the checkmark PATCH)", () => {
    const parsed = mapper.moduleRecordUpdateSchema.safeParse({ storeVisible: false });
    expect(parsed.success).toBe(true);
    if (parsed.success) expect(parsed.data.storeVisible).toBe(false);
  });

  test("create schema accepts gallery + videos + storeVisible together", () => {
    const parsed = mapper.moduleRecordCreateSchema.safeParse({
      moduleId: "products",
      values: ["جهاز قياس", "أجهزة", "12", "349.00"],
      statusKey: "instock",
      gallery: [MANAGED_IMG],
      videos: [MANAGED_VID],
      storeVisible: true,
    });
    expect(parsed.success).toBe(true);
  });
});

describe("product media — write-schema rejected shapes (422 surface)", () => {
  let mapper: Mapper;
  beforeAll(async () => {
    await testDb();
    mapper = await import("@/lib/server/module-record-mapper");
  });

  const badGallery = (gallery: unknown) =>
    mapper.moduleRecordUpdateSchema.safeParse({ gallery }).success === false;
  const badVideos = (videos: unknown) =>
    mapper.moduleRecordUpdateSchema.safeParse({ videos }).success === false;

  test("gallery with 7 entries exceeds the 6-photo cap", () => {
    const refs = Array.from({ length: 7 }, (_, i) => `/api/images/${HEX64.slice(0, 63)}${i}`);
    expect(badGallery(refs)).toBe(true);
  });

  test("videos with 3 entries exceeds the 2-clip cap", () => {
    const refs = Array.from({ length: 3 }, (_, i) => `/api/videos/${HEX64.slice(0, 63)}${i}`);
    expect(badVideos(refs)).toBe(true);
  });

  test("data-URLs are NEVER accepted inside gallery (managed refs only)", () => {
    expect(badGallery([PNG_DATA_URL])).toBe(true);
  });

  test("cross-origin URLs / paths / javascript: URIs inside gallery", () => {
    expect(badGallery(["https://evil.example/x.png"])).toBe(true);
    expect(badGallery(["/etc/passwd"])).toBe(true);
    expect(badGallery(["javascript:alert(1)"])).toBe(true);
  });

  test("image refs are not accepted as videos (and vice versa)", () => {
    expect(badVideos([MANAGED_IMG])).toBe(true);
    expect(badGallery([MANAGED_VID])).toBe(true);
  });

  test("uppercase / short / garbage hex ids", () => {
    expect(badGallery([`/api/images/${"A".repeat(64)}`])).toBe(true);
    expect(badVideos([`/api/videos/${"a".repeat(32)}`])).toBe(true);
    expect(badVideos(["/api/videos/nothex"])).toBe(true);
  });

  test("storeVisible must be a boolean (not 0/1/'yes')", () => {
    expect(mapper.moduleRecordUpdateSchema.safeParse({ storeVisible: 1 }).success).toBe(false);
    expect(mapper.moduleRecordUpdateSchema.safeParse({ storeVisible: "true" }).success).toBe(false);
  });
});

/* ---------------------- the video magic-byte gate ---------------------- */

/** minimal MP4: size(4) + 'ftyp' + brand 'isom' */
const MP4_BYTES = Buffer.from([
  0, 0, 0, 24, 0x66, 0x74, 0x79, 0x70, 0x69, 0x73, 0x6f, 0x6d,
  0, 0, 2, 0, 0x69, 0x73, 0x6f, 0x6d, 0x6d, 0x70, 0x34, 0x31,
]);
/** QuickTime flavor: 'ftyp' + 'qt  ' brand */
const MOV_BYTES = Buffer.from([
  0, 0, 0, 20, 0x66, 0x74, 0x79, 0x70, 0x71, 0x74, 0x20, 0x20,
  0, 0, 0, 0, 0, 0, 0, 0,
]);
/** WebM: EBML magic */
const WEBM_BYTES = Buffer.from([0x1a, 0x45, 0xdf, 0xa3, 0x93, 0x42, 0x82, 0x88]);

describe("product media — video magic-byte gate", () => {
  let media: MediaStore;
  beforeAll(async () => {
    await testDb();
    media = await import("@/lib/server/media-store");
  });

  test("MP4 ftyp buffer family = mp4", () => {
    expect(media.videoFamilyOf(MP4_BYTES)).toBe("mp4");
  });

  test("QuickTime ftyp-qt buffer family = quicktime", () => {
    expect(media.videoFamilyOf(MOV_BYTES)).toBe("quicktime");
  });

  test("WebM EBML buffer family = webm", () => {
    expect(media.videoFamilyOf(WEBM_BYTES)).toBe("webm");
  });

  test("legacy QuickTime atom headers (wide/free/moov) read as quicktime", () => {
    expect(media.videoFamilyOf(Buffer.from("wide" + "\0".repeat(8)))).toBe("quicktime");
    expect(media.videoFamilyOf(Buffer.from("moov" + "\0".repeat(8)))).toBe("quicktime");
  });

  test("HTML / SVG / script payloads are NOT videos", () => {
    expect(media.videoFamilyOf(Buffer.from("<html><script>alert(1)</script>"))).toBeNull();
    expect(media.videoFamilyOf(Buffer.from("<svg onload=alert(1)>"))).toBeNull();
    expect(media.videoFamilyOf(Buffer.from("GIF89a-not-a-video"))).toBeNull();
    expect(media.videoFamilyOf(Buffer.from("\0\0\0"))).toBeNull();
  });

  test("validateVideoBuffer accepts the three families with matching mimes", () => {
    expect(media.validateVideoBuffer(MP4_BYTES, { declaredMime: "video/mp4" })).toBe("mp4");
    expect(media.validateVideoBuffer(MOV_BYTES, { declaredMime: "video/quicktime" })).toBe("quicktime");
    expect(media.validateVideoBuffer(WEBM_BYTES, { declaredMime: "video/webm" })).toBe("webm");
  });

  test("a declared mime that contradicts the bytes is refused", () => {
    let threw = false;
    try {
      media.validateVideoBuffer(MP4_BYTES, { declaredMime: "video/webm" });
    } catch (error) {
      threw = error instanceof media.VideoValidationError;
    }
    expect(threw).toBe(true);
  });

  test("an HTML buffer labeled video/mp4 is refused regardless of the label", () => {
    let threw = false;
    try {
      media.validateVideoBuffer(Buffer.from("<html>evil</html>"), { declaredMime: "video/mp4" });
    } catch (error) {
      threw = error instanceof media.VideoValidationError;
    }
    expect(threw).toBe(true);
  });

  test("the 10 MB cap is enforced on the raw buffer", () => {
    const huge = Buffer.concat([
      MP4_BYTES,
      Buffer.alloc(media.PRODUCT_VIDEO_MAX_BYTES + 1, 0),
    ]);
    let threw = false;
    try {
      media.validateVideoBuffer(huge, { declaredMime: "video/mp4" });
    } catch (error) {
      threw = error instanceof media.VideoValidationError;
    }
    expect(threw).toBe(true);
  });

  test("the managed video ref shape guard", () => {
    expect(media.isManagedVideoRef(MANAGED_VID)).toBe(true);
    expect(media.isManagedVideoRef(MANAGED_IMG)).toBe(false);
    expect(media.isManagedVideoRef("/api/videos/" + "A".repeat(64))).toBe(false);
    expect(media.isManagedVideoRef("https://evil.example/v.mp4")).toBe(false);
  });
});

/* --------------- resolver semantics (DB-backed fixtures) --------------- */

async function seedAssets(media: MediaStore): Promise<void> {
  const db = await testDb();
  await db.imageAsset.deleteMany({ where: { id: { in: [HEX64, HEX64_B] } } });
  await db.imageAsset.create({
    data: { id: HEX64, mime: "image/webp", width: 1, height: 1, bytes: 1 },
  });
  await db.imageAsset.create({
    data: { id: HEX64_B, mime: "image/webp", width: 1, height: 1, bytes: 1 },
  });
  await db.mediaAsset.deleteMany({ where: { id: { in: [HEX64, HEX64_B] } } });
  await db.mediaAsset.create({ data: { id: HEX64, mime: "video/mp4", bytes: MP4_BYTES.length } });
  await db.mediaAsset.create({ data: { id: HEX64_B, mime: "video/webm", bytes: WEBM_BYTES.length } });
  /* reference media so tree-shaking never drops the import */
  expect(media.PRODUCT_VIDEO_MAX_BYTES).toBeGreaterThan(0);
}

async function cleanupAssets(): Promise<void> {
  const db = await testDb();
  await db.imageAsset.deleteMany({ where: { id: { in: [HEX64, HEX64_B] } } });
  await db.mediaAsset.deleteMany({ where: { id: { in: [HEX64, HEX64_B] } } });
}

describe("product media — gallery resolver semantics", () => {
  let rm: RecordMedia;
  let media: MediaStore;
  beforeAll(async () => {
    await testDb();
    rm = await import("@/lib/server/record-media");
    media = await import("@/lib/server/media-store");
  });

  test("undefined keeps the stored cover + extras (no change)", async () => {
    const r = await rm.resolveRecordGallery(undefined, MANAGED_IMG, JSON.stringify([MANAGED_IMG_B]));
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.changed).toBe(false);
      expect(r.data.kind).toBe("none");
    }
  });

  test("[] clears the whole gallery (cover + extras)", async () => {
    const r = await rm.resolveRecordGallery([], MANAGED_IMG, JSON.stringify([MANAGED_IMG_B]));
    expect(r.ok).toBe(true);
    if (r.ok && r.data.kind === "gallery") {
      expect(r.data.imageRef).toBeNull();
      expect(r.data.galleryJson).toBeNull();
      expect(r.droppedImages).toEqual([MANAGED_IMG_B, MANAGED_IMG]);
      expect(r.changed).toBe(true);
    } else {
      throw new Error("expected a gallery patch");
    }
  });

  test("a live-asset gallery maps refs[0] → cover, rest → galleryJson", async () => {
    await seedAssets(media);
    const r = await rm.resolveRecordGallery([MANAGED_IMG_B, MANAGED_IMG], null, null);
    expect(r.ok).toBe(true);
    if (r.ok && r.data.kind === "gallery") {
      expect(r.data.imageRef).toBe(MANAGED_IMG_B);
      expect(JSON.parse(r.data.galleryJson ?? "[]")).toEqual([MANAGED_IMG]);
    } else {
      throw new Error("expected a gallery patch");
    }
    await cleanupAssets();
  });

  test("a GC'd (ghost) asset echo is refused — IMAGE_GONE, never a dangling ref", async () => {
    const r = await rm.resolveRecordGallery([GHOST_IMG], null, null);
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.code).toBe("IMAGE_GONE");
  });

  test("duplicate refs dedupe preserving order", async () => {
    await seedAssets(media);
    const r = await rm.resolveRecordGallery([MANAGED_IMG, MANAGED_IMG, MANAGED_IMG_B], null, null);
    expect(r.ok).toBe(true);
    if (r.ok && r.data.kind === "gallery") {
      expect(r.data.imageRef).toBe(MANAGED_IMG);
      expect(JSON.parse(r.data.galleryJson ?? "[]")).toEqual([MANAGED_IMG_B]);
    } else {
      throw new Error("expected a gallery patch");
    }
    await cleanupAssets();
  });
});

describe("product media — videos resolver semantics", () => {
  let rm: RecordMedia;
  let media: MediaStore;
  beforeAll(async () => {
    await testDb();
    rm = await import("@/lib/server/record-media");
    media = await import("@/lib/server/media-store");
  });

  test("undefined keeps the stored clips (no change)", async () => {
    const r = await rm.resolveRecordVideos(undefined, JSON.stringify([MANAGED_VID]));
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.changed).toBe(false);
      expect(r.data.kind).toBe("none");
    }
  });

  test("[] clears the clips", async () => {
    const r = await rm.resolveRecordVideos([], JSON.stringify([MANAGED_VID]));
    expect(r.ok).toBe(true);
    if (r.ok && r.data.kind === "videos") {
      expect(r.data.videosJson).toBeNull();
      expect(r.droppedVideos).toEqual([MANAGED_VID]);
    } else {
      throw new Error("expected a videos patch");
    }
  });

  test("live-asset clips persist in order", async () => {
    await seedAssets(media);
    const r = await rm.resolveRecordVideos([MANAGED_VID_B, MANAGED_VID], null);
    expect(r.ok).toBe(true);
    if (r.ok && r.data.kind === "videos") {
      expect(JSON.parse(r.data.videosJson ?? "[]")).toEqual([MANAGED_VID_B, MANAGED_VID]);
    } else {
      throw new Error("expected a videos patch");
    }
    await cleanupAssets();
  });

  test("a GC'd (ghost) video echo is refused — VIDEO_GONE", async () => {
    const r = await rm.resolveRecordVideos([GHOST_VID], null);
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.code).toBe("VIDEO_GONE");
  });
});

/* --------------- catalog derivation + the visibility checkmark --------------- */

/** a minimal products-module record row (ModuleRecord-shaped). */
function recordRow(overrides: Record<string, unknown> = {}) {
  return {
    id: "rec_" + Math.random().toString(36).slice(2, 10),
    instanceId: "inst-test-media",
    moduleId: "products",
    dataJson: JSON.stringify(["جهاز قياس الضغط", "أجهزة طبية", "12", "8", "349.00"]),
    statusKey: "instock",
    shiftId: null,
    metaJson: null,
    imageRef: null,
    featured: false,
    salePrice: null,
    saleEndsAt: null,
    galleryJson: null,
    videosJson: null,
    storeVisible: true,
    deletedAt: null,
    deletedById: null,
    deletedByName: null,
    deleteReason: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    ...overrides,
  };
}

describe("product media — catalog derivation (toSiteProduct)", () => {
  let sm: StoreMapper;
  beforeAll(async () => {
    await testDb();
    sm = await import("@/lib/server/store-mapper");
  });

  test("the DTO gallery is [cover, ...extras] in order; videos + checkmark ride along", () => {
    const row = recordRow({
      imageRef: MANAGED_IMG,
      galleryJson: JSON.stringify([MANAGED_IMG_B]),
      videosJson: JSON.stringify([MANAGED_VID]),
      storeVisible: false,
    });
    const dto = sm.toSiteProduct("products", row as never);
    expect(dto.gallery).toEqual([MANAGED_IMG, MANAGED_IMG_B]);
    expect(dto.videos).toEqual([MANAGED_VID]);
    expect(dto.storeVisible).toBe(false);
  });

  test("a malformed galleryJson degrades to the cover only (fail-soft)", () => {
    const row = recordRow({ imageRef: MANAGED_IMG, galleryJson: "{not json" });
    const dto = sm.toSiteProduct("products", row as never);
    expect(dto.gallery).toEqual([MANAGED_IMG]);
    expect(dto.videos).toEqual([]);
  });

  test("garbage refs inside the stored arrays are shape-guarded away", () => {
    const row = recordRow({
      imageRef: "https://evil.example/x.png",
      galleryJson: JSON.stringify(["javascript:alert(1)", MANAGED_IMG_B]),
      videosJson: JSON.stringify(["/api/videos/nothex", MANAGED_VID]),
    });
    const dto = sm.toSiteProduct("products", row as never);
    expect(dto.gallery).toEqual([MANAGED_IMG_B]);
    expect(dto.videos).toEqual([MANAGED_VID]);
  });
});

describe("product media — the PUBLIC catalog honors the visibility checkmark", () => {
  const INSTANCE_ID = "inst-test-media-vis";
  const instance = {
    id: INSTANCE_ID,
    modulesJson: JSON.stringify(["products"]),
  };
  let sm: StoreMapper;
  beforeAll(async () => {
    await testDb();
    sm = await import("@/lib/server/store-mapper");
  });

  test("loadStoreProducts lists the visible product and NEVER the hidden one", async () => {
    const db = await testDb();
    await db.moduleRecord.deleteMany({ where: { instanceId: INSTANCE_ID } });
    await db.instance.deleteMany({ where: { id: INSTANCE_ID } });
    await db.instance.create({
      data: {
        id: INSTANCE_ID,
        systemId: "products",
        orgJson: "{}",
        adminJson: "{}",
        prefsJson: "{}",
        modulesJson: JSON.stringify(["products"]),
      },
    });
    const hidden = await db.moduleRecord.create({
      data: {
        instanceId: INSTANCE_ID,
        moduleId: "products",
        dataJson: JSON.stringify(["منتج مخفي", "أجهزة", "5", "10", "59.00"]),
        statusKey: "instock",
        storeVisible: false,
      },
    });
    const visible = await db.moduleRecord.create({
      data: {
        instanceId: INSTANCE_ID,
        moduleId: "products",
        dataJson: JSON.stringify(["منتج ظاهر", "أجهزة", "5", "10", "49.00"]),
        statusKey: "instock",
        storeVisible: true,
      },
    });

    const products = await sm.loadStoreProducts(instance as never);
    const ids = products.map((p) => p.recordId);
    expect(ids).toContain(visible.id);
    expect(ids).not.toContain(hidden.id);
    expect(products.length).toBe(1);
    expect(products[0]?.storeVisible).toBe(true);

    await db.moduleRecord.deleteMany({ where: { instanceId: INSTANCE_ID } });
    await db.instance.deleteMany({ where: { id: INSTANCE_ID } });
  });
});
