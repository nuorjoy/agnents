/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — the production proxy-trust configuration gate and
 * the conditional-mode trust anchor (src/lib/server/rate-limit.ts).
 *
 * Covers the P1-9 hardening:
 *  1. Production REFUSES to boot on an implicit TRUST_PROXY_MODE default
 *     (fail-closed configuration — the "always" default is only sound
 *     behind an overwrite-mode proxy).
 *  2. "conditional" mode no longer anchors trust on the client-settable
 *     x-real-ip (the historical circular trust: a spoofed x-real-ip
 *     matching TRUSTED_EDGE_IPS made the whole XFF chain trusted). Trust
 *     now requires the platform edge header (x-vercel-forwarded-for).
 *  3. Explicit production modes pass the gate.
 *  4. Development keeps the historical default behavior (XFF trusted).
 */
import { describe, test, expect, beforeAll, afterEach } from "bun:test";
import { ensureDemoEnv } from "./test-setup";

type RLModule = typeof import("@/lib/server/rate-limit");
let rl: RLModule;

beforeAll(async () => {
  ensureDemoEnv();
  rl = await import("@/lib/server/rate-limit");
});

const REAL_NODE_ENV = process.env.NODE_ENV;
const REAL_MODE = process.env.TRUST_PROXY_MODE;

afterEach(() => {
  (process.env as { NODE_ENV?: string }).NODE_ENV = REAL_NODE_ENV;
  if (REAL_MODE === undefined) delete process.env.TRUST_PROXY_MODE;
  else process.env.TRUST_PROXY_MODE = REAL_MODE;
});

function requestWith(headers: Record<string, string>): Request {
  return new Request("https://app.example/api/probe", {
    method: "POST",
    headers,
  });
}

describe("proxy-trust production gate — fail-closed configuration", () => {
  test("production + unset TRUST_PROXY_MODE THROWS (no implicit trust default)", () => {
    (process.env as { NODE_ENV?: string }).NODE_ENV = "production";
    delete process.env.TRUST_PROXY_MODE;
    expect(() => rl.assertExplicitProxyTrustMode()).toThrow(/TRUST_PROXY_MODE must be set explicitly/i);
  });

  test("production + unrecognized mode THROWS", () => {
    (process.env as { NODE_ENV?: string }).NODE_ENV = "production";
    process.env.TRUST_PROXY_MODE = "sometimes";
    expect(() => rl.assertExplicitProxyTrustMode()).toThrow(/Refusing to boot/i);
  });

  test("production + each explicit valid mode passes the gate", () => {
    (process.env as { NODE_ENV?: string }).NODE_ENV = "production";
    for (const mode of ["always", "conditional", "never"]) {
      process.env.TRUST_PROXY_MODE = mode;
      expect(() => rl.assertExplicitProxyTrustMode()).not.toThrow();
    }
  });

  test("development passes without an explicit mode (sandbox gateway posture)", () => {
    (process.env as { NODE_ENV?: string }).NODE_ENV = "development";
    delete process.env.TRUST_PROXY_MODE;
    expect(() => rl.assertExplicitProxyTrustMode()).not.toThrow();
  });
});

describe("conditional mode — no circular trust on client-settable headers", () => {
  test("a spoofed x-real-ip matching TRUSTED_EDGE_IPS does NOT unlock XFF trust", () => {
    process.env.TRUST_PROXY_MODE = "conditional";
    process.env.TRUSTED_EDGE_IPS = "10.0.0.7";
    /* the historical bug: this forged header pair made the request
     * "trusted" and used the attacker's XFF value verbatim */
    const ip = rl.clientIp(
      requestWith({
        "x-real-ip": "10.0.0.7", // spoofed to match the allowlist
        "x-forwarded-for": "1.2.3.4", // the forged hop the attacker wants counted
      })
    );
    expect(ip).toBe("untrusted"); // fail-closed: no platform edge header present
  });

  test("the platform edge header (x-vercel-forwarded-for) unlocks XFF trust", () => {
    process.env.TRUST_PROXY_MODE = "conditional";
    const ip = rl.clientIp(
      requestWith({
        "x-vercel-forwarded-for": "203.0.113.9",
        "x-forwarded-for": "198.51.100.24",
      })
    );
    expect(ip).toBe("198.51.100.24");
  });

  test("\"always\" mode keeps the historical rightmost-XFF behavior", () => {
    process.env.TRUST_PROXY_MODE = "always";
    const ip = rl.clientIp(
      requestWith({ "x-forwarded-for": "spoofed.hop, 198.51.100.7" })
    );
    expect(ip).toBe("198.51.100.7");
  });
});
