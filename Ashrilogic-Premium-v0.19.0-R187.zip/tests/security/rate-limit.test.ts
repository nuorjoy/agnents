/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — durable rate limiter (src/lib/server/rate-limit.ts).
 *
 * THE headline regression: the pre-fix implementation did count-then-insert,
 * so N concurrent requests could ALL observe "under the limit" before any
 * hit landed (TOCTOU bypass). The fix is ONE atomic guarded INSERT — this
 * suite fires 20 CONCURRENT checks at a 5-limit key and demands EXACTLY 5
 * admissions.
 *
 * Also covers: sliding-window expiry, failClosed posture when the durable
 * store breaks (security endpoints refuse; default callers fail open via
 * the local fallback and NEVER throw), store recovery, and the rightmost-XFF
 * client-IP policy.
 *
 * Runs against the ISOLATED throwaway test database — the live dev
 * database is never touched.
 */
import { describe, test, expect, beforeAll, beforeEach, afterAll } from "bun:test";
import { randomUUID } from "node:crypto";
import { getTestDb, resetRateTable, type TestDb } from "./test-setup";

type RateLimitModule = typeof import("@/lib/server/rate-limit");
let rl: RateLimitModule;
let db: TestDb;

const RULE = { limit: 5, windowMs: 60_000 };

beforeAll(async () => {
  // binds env + imports @/lib/db against the test database FIRST,
  // then the limiter (which imports the client itself)
  db = await getTestDb();
  rl = await import("@/lib/server/rate-limit");
});

beforeEach(async () => {
  await resetRateTable(db);
});

afterAll(async () => {
  await resetRateTable(db);
  await db.$disconnect();
});

describe("rate-limit — atomicity (count-then-insert TOCTOU regression)", () => {
  test("20 CONCURRENT checks on a 5-limit key admit EXACTLY 5", async () => {
    const key = `atomic:${randomUUID()}`;
    const checks = await Promise.all(
      Array.from({ length: 20 }, () => rl.rateLimited(key, RULE))
    );
    const admitted = checks.filter((refused) => !refused).length;
    const refused = checks.filter((refused) => refused).length;
    expect(admitted).toBe(5);
    expect(refused).toBe(15);
    // refused requests perform NO write — flooding never grows the table
    const rows = await db.rateLimitHit.count({ where: { key } });
    expect(rows).toBe(5);
  });

  test("sequential boundary — the request after the limit is refused", async () => {
    const key = `seq:${randomUUID()}`;
    for (let i = 0; i < RULE.limit; i++) {
      expect(await rl.rateLimited(key, RULE)).toBe(false);
    }
    expect(await rl.rateLimited(key, RULE)).toBe(true);
  });
});

describe("rate-limit — sliding window expiry", () => {
  test("hits older than the window stop counting — the key is allowed again", async () => {
    const key = `expired:${randomUUID()}`;
    const staleTimestamp = new Date(Date.now() - 120_000); // 2 minutes ago
    for (let i = 0; i < RULE.limit; i++) {
      await db.rateLimitHit.create({ data: { key, at: staleTimestamp } });
    }
    // all 5 hits are outside the 60s window → the next check is admitted
    expect(await rl.rateLimited(key, RULE)).toBe(false);
    // exactly one NEW hit landed; the stale rows are logically pruned
    const rows = await db.rateLimitHit.count({ where: { key } });
    expect(rows).toBe(RULE.limit + 1);
  });
});

describe("rate-limit — failure posture when the durable store breaks", () => {
  test("failClosed REFUSES; default fails open via the local fallback and NEVER throws", async () => {
    /* simulate the broken store by RENAMING the table out of the way —
     * every limiter query then throws, and the ORIGINAL provider-native
     * table (columns, types, the key+at index) returns intact when named
     * back (a hand-written CREATE TABLE would drift from the Prisma
     * schema's PostgreSQL column types — the old SQLite-era DDL did) */
    await db.$executeRawUnsafe('ALTER TABLE "RateLimitHit" RENAME TO "RateLimitHit_outage_sim"');
    try {
      // security endpoint posture: the store is gone → refuse
      expect(await rl.rateLimited(`failclosed:${randomUUID()}`, RULE, { failClosed: true })).toBe(true);

      // default posture: no throw, a boolean from the local fallback
      // (fresh key → under the limit → allowed)
      const open = await rl.rateLimited(`failopen:${randomUUID()}`, RULE);
      expect(typeof open).toBe("boolean");
      expect(open).toBe(false);
    } finally {
      // restore the real table so later tests keep a live store
      await db.$executeRawUnsafe('ALTER TABLE "RateLimitHit_outage_sim" RENAME TO "RateLimitHit"');
    }

    // the limiter is fully functional again after recovery
    const key = `recovered:${randomUUID()}`;
    expect(await rl.rateLimited(key, { limit: 1, windowMs: 60_000 })).toBe(false);
    expect(await rl.rateLimited(key, { limit: 1, windowMs: 60_000 })).toBe(true);
  });
});

describe("rate-limit — clientIp (rightmost XFF policy)", () => {
  function requestWith(headers: Record<string, string>): Request {
    return new Request("http://localhost:3000/api/probe", { headers });
  }

  test("uses the RIGHTMOST x-forwarded-for hop (spoofed hops are leftmost)", () => {
    expect(
      rl.clientIp(requestWith({ "x-forwarded-for": "1.1.1.1, 2.2.2.2, 3.3.3.3" }))
    ).toBe("3.3.3.3");
    expect(
      rl.clientIp(requestWith({ "x-forwarded-for": "spoofed-hop, real-client" }))
    ).toBe("real-client");
  });

  test("falls back to x-real-ip, then to \"local\"", () => {
    expect(rl.clientIp(requestWith({ "x-real-ip": "9.9.9.9" }))).toBe("9.9.9.9");
    expect(rl.clientIp(requestWith({}))).toBe("local");
  });
});

describe("rate-limit — 429 builder (ROUND 113: RFC 6585 Retry-After)", () => {
  test("tooManyRequests carries the rule's window as Retry-After + X-RateLimit headers", async () => {
    const response = rl.tooManyRequests(RULE, { error: "Too many attempts" });
    expect(response.status).toBe(429);
    expect(response.headers.get("retry-after")).toBe("60");
    expect(response.headers.get("x-ratelimit-limit")).toBe("5");
    expect(response.headers.get("x-ratelimit-window-seconds")).toBe("60");
    const body = (await response.json()) as { error: string };
    expect(body.error).toBe("Too many attempts");
  });

  test("window seconds are CEILED (sub-minute windows never round to zero)", () => {
    const response = rl.tooManyRequests({ limit: 3, windowMs: 30_000 });
    expect(response.headers.get("retry-after")).toBe("30");
    const odd = rl.tooManyRequests({ limit: 3, windowMs: 45_500 });
    expect(odd.headers.get("retry-after")).toBe("46");
  });
});
