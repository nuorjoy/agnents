/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — IMAGE-STORE ORPHAN GC (ROUND 105).
 *
 * Proves the GC engine + CLI delete EXACTLY what the safety model allows:
 *  - referenced files (ImageAsset row present) are NEVER deleted;
 *  - orphans (managed file, no row) past the grace window are planned and
 *    deleted, bytes reclaimed accurately;
 *  - orphans WITHIN the grace window are kept (in-flight-upload protection);
 *  - a custom --grace-hours reclassifies the same files (the flag works);
 *  - stale .webp.tmp-* scratch files are deleted; fresh ones kept;
 *  - foreign filenames are counted and NEVER touched;
 *  - rows missing their file are reported only (GC never creates files);
 *  - a file replaced between plan and execute (size mismatch) is SKIPPED;
 *  - the CLI: dry-run deletes nothing and writes no audit row; --execute
 *    deletes orphans + temps, reclaims bytes, and writes a system.gc
 *    SECURITY audit row.
 */

import { describe, expect, test, beforeAll, afterAll } from "bun:test";
import { mkdtempSync, rmSync, mkdirSync, writeFileSync, existsSync, utimesSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createHash } from "node:crypto";
import { ensureDemoEnv, getTestDb, type TestDb } from "./test-setup";

ensureDemoEnv();
const TMP = mkdtempSync(join(tmpdir(), "ashrilogic-image-gc-"));
const IMAGES = join(TMP, "images");
process.env.ASHRILOGIC_STORAGE_DIR = TMP;

let db: TestDb;
let gc: typeof import("@/lib/server/image-gc");

/** Write a content-addressed image file (+ optionally its row). */
async function seedImage(
  name: "kept" | "orphan" | "fresh" | "foreign" | "missing-row",
  bytes: string,
  opts: { row?: boolean; ageHours?: number } = {}
): Promise<{ file: string; sha: string; size: number }> {
  const buf = Buffer.from(bytes);
  const sha = createHash("sha256").update(buf).digest("hex");
  const file = `${sha}.webp`;
  if (name !== "missing-row") {
    writeFileSync(join(IMAGES, file), buf);
    if (opts.ageHours) {
      const t = new Date(Date.now() - opts.ageHours * 3_600_000);
      utimesSync(join(IMAGES, file), t, t);
    }
  }
  if (opts.row && name !== "orphan" && name !== "fresh") {
    await db.imageAsset.create({
      data: { id: sha, mime: "image/webp", width: 10, height: 10, bytes: buf.length },
    });
  }
  return { file, sha, size: buf.length };
}

function seedTempFile(hex: string, bytes: string, ageHours?: number): { file: string; size: number } {
  const buf = Buffer.from(bytes);
  const file = `${createHash("sha256").update(buf).digest("hex")}.webp.tmp-${hex}`;
  writeFileSync(join(IMAGES, file), buf);
  if (ageHours) {
    const t = new Date(Date.now() - ageHours * 3_600_000);
    utimesSync(join(IMAGES, file), t, t);
  }
  return { file, size: buf.length };
}

beforeAll(async () => {
  db = await getTestDb();
  mkdirSync(IMAGES, { recursive: true });
  gc = await import("@/lib/server/image-gc");
});

afterAll(() => {
  rmSync(TMP, { recursive: true, force: true });
});

describe("image GC — engine", () => {
  test("referenced files are never planned or deleted", async () => {
    const kept = await seedImage("kept", "referenced-image-bytes", { row: true });
    const plan = await gc.collectImageGcPlan({ graceHours: 24 });
    expect(plan.rows).toBe(1);
    expect(plan.orphans).toHaveLength(0);
    expect(plan.rowsMissingFile).toBe(0);
    const result = await gc.executeImageGc(plan);
    expect(result.deletedOrphans).toBe(0);
    expect(result.reclaimedBytes).toBe(0);
    expect(existsSync(join(IMAGES, kept.file))).toBe(true);
  });

  test("orphan past grace → planned + deleted, bytes reclaimed", async () => {
    const orphan = await seedImage("orphan", "orphaned-image-bytes", { ageHours: 48 });
    const plan = await gc.collectImageGcPlan({ graceHours: 24 });
    const entry = plan.orphans.find((o) => o.file === orphan.file);
    expect(entry).toBeDefined();
    expect(entry?.bytes).toBe(orphan.size);
    const result = await gc.executeImageGc(plan);
    expect(result.deletedOrphans).toBe(1);
    expect(result.reclaimedBytes).toBe(orphan.size);
    expect(existsSync(join(IMAGES, orphan.file))).toBe(false);
  });

  test("orphan within grace → kept; custom grace reclassifies it", async () => {
    const fresh = await seedImage("fresh", "fresh-orphan-bytes"); /* mtime = now */
    let plan = await gc.collectImageGcPlan({ graceHours: 24 });
    expect(plan.orphans).toHaveLength(0);
    expect(plan.orphansFresh).toBe(1);
    let result = await gc.executeImageGc(plan);
    expect(result.deletedOrphans).toBe(0);
    expect(existsSync(join(IMAGES, fresh.file))).toBe(true);

    /* grace 0 → the same file becomes deletable (the flag flows through) */
    plan = await gc.collectImageGcPlan({ graceHours: 0 });
    expect(plan.orphans).toHaveLength(1);
    result = await gc.executeImageGc(plan);
    expect(result.deletedOrphans).toBe(1);
    expect(existsSync(join(IMAGES, fresh.file))).toBe(false);
  });

  test("stale temp deleted, fresh temp kept, foreign file never touched", async () => {
    const staleTemp = seedTempFile("aabbccdd0011", "stale-temp-bytes", 48);
    const freshTemp = seedTempFile("aabbccdd0022", "fresh-temp-bytes");
    writeFileSync(join(IMAGES, "operator-note.txt"), "not managed");

    const plan = await gc.collectImageGcPlan({ graceHours: 24 });
    expect(plan.tempStale.map((t) => t.file)).toContain(staleTemp.file);
    expect(plan.tempFresh).toBe(1);
    expect(plan.foreign).toBe(1);

    const result = await gc.executeImageGc(plan);
    expect(result.deletedTemp).toBe(1);
    expect(result.reclaimedBytes).toBe(staleTemp.size);
    expect(existsSync(join(IMAGES, staleTemp.file))).toBe(false);
    expect(existsSync(join(IMAGES, freshTemp.file))).toBe(true);
    expect(existsSync(join(IMAGES, "operator-note.txt"))).toBe(true);
  });

  test("row without file → reported only; GC never creates files", async () => {
    const ghost = createHash("sha256").update("ghost").digest("hex");
    await db.imageAsset.create({
      data: { id: ghost, mime: "image/webp", width: 5, height: 5, bytes: 6 },
    });
    const plan = await gc.collectImageGcPlan({ graceHours: 0 });
    expect(plan.rowsMissingFile).toBe(1);
    const before = existsSync(join(IMAGES, `${ghost}.webp`));
    await gc.executeImageGc(plan);
    expect(existsSync(join(IMAGES, `${ghost}.webp`))).toBe(before); /* still absent */
    await db.imageAsset.delete({ where: { id: ghost } });
  });

  test("file replaced between plan and execute (size mismatch) → skipped", async () => {
    const victim = await seedImage("orphan", "original-orphan", { ageHours: 48 });
    const plan = await gc.collectImageGcPlan({ graceHours: 24 });
    expect(plan.orphans).toHaveLength(1);

    /* swap the file for a DIFFERENT size after the plan was collected */
    writeFileSync(join(IMAGES, victim.file), Buffer.from("replaced-by-another-process-longer"));

    const result = await gc.executeImageGc(plan);
    expect(result.deletedOrphans).toBe(0);
    expect(result.vanished).toBe(1);
    expect(existsSync(join(IMAGES, victim.file))).toBe(true);
    rmSync(join(IMAGES, victim.file), { force: true });
  });
});

describe("image GC — CLI subprocess", () => {
  async function runCli(extraArgs: string[]): Promise<{ exit: number; out: string }> {
    const proc = Bun.spawn({
      cmd: ["bun", "scripts/gc-images.ts", ...extraArgs],
      cwd: import.meta.dir + "/../..",
      env: { ...process.env },
      stdout: "pipe",
      stderr: "pipe",
    });
    const [exit, out, err] = await Promise.all([
      proc.exited,
      new Response(proc.stdout).text(),
      new Response(proc.stderr).text(),
    ]);
    if (exit !== 0) console.error("CLI stderr:", err);
    return { exit: exit ?? -1, out };
  }

  test("dry-run deletes nothing and writes no audit row", async () => {
    const orphan = await seedImage("orphan", "cli-dryrun-orphan", { ageHours: 48 });
    const auditBefore = await db.auditLog.count({ where: { action: "system.gc" } });

    const { exit, out } = await runCli([]);
    expect(exit).toBe(0);
    expect(out).toContain("DRY-RUN");
    expect(out).toContain("ORPHANS (deletable):      1");
    expect(existsSync(join(IMAGES, orphan.file))).toBe(true);
    expect(await db.auditLog.count({ where: { action: "system.gc" } })).toBe(auditBefore);

    /* cleanup for the next test */
    rmSync(join(IMAGES, orphan.file), { force: true });
  });

  test("--execute deletes orphans + temps, reclaims bytes, writes system.gc audit row", async () => {
    const orphan = await seedImage("orphan", "cli-execute-orphan", { ageHours: 48 });
    const temp = seedTempFile("aabbccdd0033", "cli-execute-temp", 48);
    const kept = await seedImage("kept", "cli-execute-kept", { row: true, ageHours: 48 });

    const { exit, out } = await runCli(["--execute", "--grace-hours", "24"]);
    expect(exit).toBe(0);
    expect(out).toContain("EXECUTE: deleted 1 orphan(s) + 1 temp file(s)");
    expect(out).toContain("audit row written (system.gc");
    expect(existsSync(join(IMAGES, orphan.file))).toBe(false);
    expect(existsSync(join(IMAGES, temp.file))).toBe(false);
    expect(existsSync(join(IMAGES, kept.file))).toBe(true);

    /* the SECURITY audit row landed with the exact accounting */
    const rows = await db.auditLog.findMany({
      where: { action: "system.gc" },
      orderBy: { createdAt: "desc" },
      take: 1,
    });
    expect(rows).toHaveLength(1);
    const meta = JSON.parse(rows[0].metaJson ?? "{}") as Record<string, string>;
    expect(meta.deletedOrphans).toBe("1");
    expect(meta.deletedTemp).toBe("1");
    expect(meta.graceHours).toBe("24");
    expect(Number(meta.reclaimedBytes)).toBe(orphan.size + temp.size);
  });
});
