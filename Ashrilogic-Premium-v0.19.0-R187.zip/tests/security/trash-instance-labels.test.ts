/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — audit finding F-08 (trash listing N+1):
 * listTrash used to resolve instance labels with ONE
 * db.instance.findUnique PER DISTINCT tenant id (memoized per call), i.e.
 * D sequential queries for D tenants — worst case the Super Admin
 * platform-wide console (every tenant with trashed rows, no instanceId
 * filter).
 *
 * The fix batches the labels: the six tenant-entity loads run FIRST, their
 * DISTINCT instanceIds are collected, ONE
 * db.instance.findMany({ where: { id: { in: [...] } } }) resolves them into
 * a Map (the per-call memoization), and the row-mapping loops read it
 * synchronously. This suite pins BOTH halves on the throwaway test DB:
 *
 *  1. CORRECTNESS — every trashed row still carries its resolved instance
 *     label (org name; the id-prefix fallback when the org carries no name
 *     — byte-for-byte the old per-row fallback), the label still feeds the
 *     search filter, and entity/tenant filters + stats keep their shape.
 *
 *  2. THE FIX ITSELF — instrumented delegate counting: a tenant listing
 *     performs ZERO db.instance.findUnique calls (the dead N+1 path) and
 *     EXACTLY ONE instance read (the batch).
 */
import { describe, test, expect, beforeAll, afterAll } from "bun:test";
import { getTestDb, ensureDemoEnv, type TestDb } from "./test-setup";

ensureDemoEnv();

const RUN = Math.random().toString(36).slice(2, 8);

let db: TestDb;
let trash: typeof import("@/lib/server/trash");

/* three tenants: A + B carry org names; C's orgJson has NO name → its rows
 * must fall back to the id prefix (the old per-row fallback branch) */
const idA = `inst-trash-a-${RUN}`;
const idB = `inst-trash-b-${RUN}`;
const idC = `inst-trash-c-${RUN}`;
const labelA = `متجر الألف ${RUN}`;
const labelB = `مخبز الباء ${RUN}`;
const prefixC = idC.slice(0, 8);
const createdInstanceIds = [idA, idB, idC];
const trashedRowIds: string[] = [];
let liveRowId = "";

async function makeInstance(id: string, orgJson: string): Promise<void> {
  await db.instance.create({
    data: {
      id,
      systemId: `trash-sys-${id}`,
      orgJson,
      adminJson: JSON.stringify({ name: "مالك", email: `owner-${id}@trash.test`, role: "owner", twoFA: false }),
      prefsJson: JSON.stringify({ lang: "ar", theme: "light", notif: true, backup: true, audit: true, demo: false }),
      modulesJson: JSON.stringify(["products"]),
    },
  });
}

beforeAll(async () => {
  db = await getTestDb();
  trash = await import("@/lib/server/trash");

  await makeInstance(idA, JSON.stringify({ name: labelA, country: "SA", currency: "SAR", timezone: "Asia/Riyadh" }));
  await makeInstance(idB, JSON.stringify({ name: labelB, country: "SA", currency: "SAR", timezone: "Asia/Riyadh" }));
  await makeInstance(idC, JSON.stringify({ country: "SA" }));

  /* 5 trashed rows across the tenants (3 entity kinds) + one LIVE row that
   * must never list (the soft-delete law) */
  const m1 = await db.teamMember.create({
    data: { instanceId: idA, name: `كاشير أ ${RUN}`, email: `m1-${RUN}@trash.test`, deletedAt: new Date(Date.now() - 86_400_000) },
  });
  const m2 = await db.teamMember.create({
    data: { instanceId: idA, name: `كاشير أ٢ ${RUN}`, email: `m2-${RUN}@trash.test`, deletedAt: new Date() },
  });
  const m3 = await db.teamMember.create({
    data: { instanceId: idC, name: `كاشير ج ${RUN}`, email: `m3-${RUN}@trash.test`, deletedAt: new Date() },
  });
  const c1 = await db.siteCustomer.create({
    data: { instanceId: idB, name: `عميل ${RUN}`, email: `c1-${RUN}@trash.test`, deletedAt: new Date() },
  });
  const r1 = await db.moduleRecord.create({
    data: { instanceId: idB, moduleId: "products", dataJson: JSON.stringify(["حليب", "", "ألبان", "10", "6.5"]), deletedAt: new Date() },
  });
  const live = await db.teamMember.create({
    data: { instanceId: idA, name: `عضو حي ${RUN}`, email: `live-${RUN}@trash.test` },
  });
  trashedRowIds.push(m1.id, m2.id, m3.id, c1.id, r1.id);
  liveRowId = live.id;
});

afterAll(async () => {
  try {
    /* deleting the instances cascades their tenant rows (onDelete: Cascade) */
    await db.instance.deleteMany({ where: { id: { in: createdInstanceIds } } });
  } catch {
    /* throwaway database — best-effort cleanup only */
  }
  await db.$disconnect();
});

/* ------------------------------------------------------------------ */
/* 1 — correctness: the labels resolve exactly as before               */
/* ------------------------------------------------------------------ */

describe("listTrash instance labels (F-08 batched resolution)", () => {
  test("platform-wide listing (worst case): every tenant row carries its resolved label", async () => {
    const result = await trash.listTrash({ includePlatformEntities: true });
    const trashed = result.items.filter((it) => trashedRowIds.includes(it.id));
    expect(trashed).toHaveLength(5);
    /* the LIVE row never lists (soft-delete law) */
    expect(result.items.some((it) => it.id === liveRowId)).toBe(false);
    for (const it of trashed) {
      if (it.instanceId === idA) expect(it.instanceLabel).toBe(labelA);
      else if (it.instanceId === idB) expect(it.instanceLabel).toBe(labelB);
      else if (it.instanceId === idC) expect(it.instanceLabel).toBe(prefixC);
      else throw new Error(`unexpected instanceId on trashed row: ${it.instanceId}`);
    }
    /* stats keep their shape over the FULL (un-paginated) set */
    expect(result.stats.total).toBe(5);
    expect(result.stats.byEntity.teamMember).toBe(3);
    expect(result.stats.byEntity.siteCustomer).toBe(1);
    expect(result.stats.byEntity.moduleRecord).toBe(1);
    expect(result.stats.byEntity.instance).toBe(0);
    expect(result.stats.byEntity.adminUser).toBe(0);
  });

  test("search still consumes the resolved instanceLabel (the hay includes it)", async () => {
    const result = await trash.listTrash({ search: labelB });
    expect(result.items).toHaveLength(2);
    for (const it of result.items) {
      expect(it.instanceId).toBe(idB);
      expect(it.instanceLabel).toBe(labelB);
    }
  });

  test("entity + tenant filters keep the labels correct (scoped listing)", async () => {
    const result = await trash.listTrash({ entity: "teamMember", instanceId: idA });
    expect(result.items).toHaveLength(2);
    for (const it of result.items) {
      expect(it.instanceId).toBe(idA);
      expect(it.instanceLabel).toBe(labelA);
    }
    expect(result.stats.total).toBe(2);
    expect(result.stats.byEntity.teamMember).toBe(2);
  });
});

/* ------------------------------------------------------------------ */
/* 2 — the fix itself: the per-row lookup path is dead                 */
/* ------------------------------------------------------------------ */

describe("listTrash label batching (F-08 N+1 regression guard)", () => {
  test("a tenant listing reads instances exactly ONCE and never findUnique-per-row", async () => {
    const delegate = db.instance;
    const origFindUnique = delegate.findUnique.bind(delegate);
    const origFindMany = delegate.findMany.bind(delegate);
    let findUniqueCalls = 0;
    let findManyCalls = 0;
    /* test-local instrumentation: the delegate methods are writable own
     * properties (probed) — wrap, count, and restore in the finally block */
    delegate.findUnique = ((args: Parameters<typeof origFindUnique>[number]) => {
      findUniqueCalls += 1;
      return origFindUnique(args);
    }) as unknown as typeof delegate.findUnique;
    delegate.findMany = ((args: Parameters<typeof origFindMany>[number]) => {
      findManyCalls += 1;
      return origFindMany(args);
    }) as unknown as typeof delegate.findMany;
    try {
      const result = await trash.listTrash({});
      expect(findUniqueCalls).toBe(0); /* the N+1 path must never return */
      expect(findManyCalls).toBe(1); /* exactly ONE batched label query */
      /* and the batch still resolved every label */
      const trashed = result.items.filter((it) => trashedRowIds.includes(it.id));
      expect(trashed).toHaveLength(5);
      for (const it of trashed) expect(typeof it.instanceLabel).toBe("string");
    } finally {
      delegate.findUnique = origFindUnique as unknown as typeof delegate.findUnique;
      delegate.findMany = origFindMany as unknown as typeof delegate.findMany;
    }
  });
});
