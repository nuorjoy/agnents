/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — the centralized secret minimum-length policy
 * (src/lib/server/runtime-guard.ts).
 *
 * Covers the P0 policy-unification fix: every env-bound secret resolves
 * through loadSecret(), and the platform-wide floor
 * (MIN_PROVISIONED_SECRET_LENGTH = 32) is enforced IN THE LOADER so no
 * service can quietly accept a weaker provisioned key than another (the
 * historical 16/32 split — tokens.ts 32 vs crypto-vault/wallet/audit/
 * receipt/plan-orders 16 — is closed).
 *
 * Verbatim behaviors pinned:
 *  1. A spec declaring minLen < 32 is a LOUD programming error (throw).
 *  2. A provisioned value shorter than the spec floor is NOT accepted —
 *     the loader falls through to the environment policy instead.
 *  3. Production mode + weak/missing provisioned secret FAILS FAST.
 *  4. The exported floor is exactly 32 (the .env.example contract).
 */
import { describe, test, expect, beforeAll, afterEach } from "bun:test";
import { ensureDemoEnv } from "./test-setup";

type GuardModule = typeof import("@/lib/server/runtime-guard");
let guard: GuardModule;

beforeAll(async () => {
  ensureDemoEnv();
  guard = await import("@/lib/server/runtime-guard");
});

const REAL_NODE_ENV = process.env.NODE_ENV;

afterEach(() => {
  (process.env as { NODE_ENV?: string }).NODE_ENV = REAL_NODE_ENV;
  delete process.env.ASHRILOGIC_DATA_KEY;
  delete process.env.ADMIN_SESSION_SECRET;
  delete process.env.ALLOW_DEMO_SECRETS;
});

describe("runtime-guard — centralized minimum-length policy", () => {
  test("MIN_PROVISIONED_SECRET_LENGTH is 32 (the documented .env.example contract)", () => {
    expect(guard.MIN_PROVISIONED_SECRET_LENGTH).toBe(32);
  });

  test("a spec below the platform floor is a loud programming error", () => {
    expect(() =>
      guard.loadSecret({
        envVar: "ASHRILOGIC_DATA_KEY",
        minLen: 16,
        demoValue: "demo-value-irrelevant-here",
        label: "test spec",
      })
    ).toThrow(/below the platform-wide secret floor/i);
  });

  test("a 16-char provisioned secret is NOT accepted as sufficient (dev falls to demo)", () => {
    (process.env as { NODE_ENV?: string }).NODE_ENV = "development";
    process.env.ASHRILOGIC_DATA_KEY = "x".repeat(16); // the historical weak length
    const resolved = guard.loadSecret({
      envVar: "ASHRILOGIC_DATA_KEY",
      minLen: guard.MIN_PROVISIONED_SECRET_LENGTH,
      demoValue: "ashrilogic-demo-field-encryption-key-rotate-me",
      label: "field-encryption root key",
    });
    /* the weak value must be rejected — the demo constant wins instead */
    expect(resolved).toBe("ashrilogic-demo-field-encryption-key-rotate-me");
  });

  test("a 32-char provisioned secret IS accepted", () => {
    (process.env as { NODE_ENV?: string }).NODE_ENV = "development";
    const strong = "a".repeat(32);
    process.env.ASHRILOGIC_DATA_KEY = strong;
    const resolved = guard.loadSecret({
      envVar: "ASHRILOGIC_DATA_KEY",
      minLen: guard.MIN_PROVISIONED_SECRET_LENGTH,
      demoValue: "ashrilogic-demo-field-encryption-key-rotate-me",
      label: "field-encryption root key",
    });
    expect(resolved).toBe(strong);
  });

  test("production + a 16-char provisioned secret FAILS FAST (no demo fallback)", () => {
    (process.env as { NODE_ENV?: string }).NODE_ENV = "production";
    process.env.ASHRILOGIC_DATA_KEY = "x".repeat(16);
    expect(() =>
      guard.loadSecret({
        envVar: "ASHRILOGIC_DATA_KEY",
        minLen: guard.MIN_PROVISIONED_SECRET_LENGTH,
        demoValue: "ashrilogic-demo-field-encryption-key-rotate-me",
        label: "field-encryption root key",
      })
    ).toThrow(/ASHRILOGIC_DATA_KEY is required in production/i);
  });

  test("production + missing secret FAILS FAST with the documented contract", () => {
    (process.env as { NODE_ENV?: string }).NODE_ENV = "production";
    expect(() =>
      guard.loadSecret({
        envVar: "ASHRILOGIC_DATA_KEY",
        minLen: guard.MIN_PROVISIONED_SECRET_LENGTH,
        demoValue: "ashrilogic-demo-field-encryption-key-rotate-me",
        label: "field-encryption root key",
      })
    ).toThrow(/32\+, see \.env\.example/);
  });
});
