/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 187: shift open/close are race-free.
 *
 * The historical endpoints were check-then-act:
 *   - OPEN: getOpenShift miss → create — two terminals opening
 *     simultaneously BOTH created an open shift (Shift has no unique
 *     index on [instanceId,status]);
 *   - CLOSE: a plain db.shift.update — concurrent closes BOTH landed
 *     (last-write-wins on countedCash/variance, duplicated shiftClose
 *     audit rows).
 *
 * The fix (the R171 / wallet-CAS patterns):
 *   - OPEN runs inside ONE advisory-locked transaction
 *     (`pg_advisory_xact_lock(shift-open:<instanceId>)` + fresh
 *     open-check + create);
 *   - CLOSE is a status-predicated updateMany — only the FIRST
 *     open→closed flip commits; the loser sees count 0 → 409
 *     SHIFT_ALREADY_CLOSED.
 */
import { describe, beforeAll, afterAll, test, expect } from "bun:test";
import { getTestDb, ensureDemoEnv, type TestDb } from "./test-setup";

ensureDemoEnv();

const RUN = `shift-race-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

let db: TestDb;
let rateLimit: typeof import("@/lib/server/rate-limit");
let shiftGate: typeof import("@/lib/server/shift-gate");

type Tx = Parameters<Parameters<TestDb["$transaction"]>[0]>[0];

beforeAll(async () => {
  db = await getTestDb();
  rateLimit = await import("@/lib/server/rate-limit");
  shiftGate = await import("@/lib/server/shift-gate");
});

afterAll(async () => {
  await db.instance.deleteMany({ where: { systemId: "pos", orgJson: { startsWith: `{"name":"ShiftRace-${RUN}` } } });
});

describe("ROUND 187 — shift open race (advisory-locked critical section)", () => {
  test("6 concurrent opens → exactly ONE open shift", async () => {
    const instanceId = (
      await db.instance.create({
        data: {
          systemId: "pos",
          orgJson: JSON.stringify({ name: `ShiftRace-${RUN}`, currency: "SAR" }),
          adminJson: JSON.stringify({ name: `Admin-${RUN}`, email: `${RUN}@shift.test` }),
          adminEmailIndex: `${RUN}-idx`,
          prefsJson: JSON.stringify({ lang: "ar" }),
          modulesJson: JSON.stringify(["pos"]),
        },
        select: { id: true },
      })
    ).id;

    /* the route's exact critical section */
    const openOnce = async (): Promise<"created" | "conflict" | "error"> => {
      try {
        const row = await db.$transaction(
          async (tx: Tx) => {
            await tx.$executeRaw`SELECT pg_advisory_xact_lock(${rateLimit.advisoryLockKey(
              `shift-open:${instanceId}`
            )})`;
            const existing = await tx.shift.findFirst({
              where: { instanceId, status: "open" },
              orderBy: { openedAt: "desc" },
            });
            if (existing) return { conflict: existing };
            return {
              created: await tx.shift.create({
                data: {
                  instanceId,
                  code: await shiftGate.nextShiftCode(instanceId, tx),
                  openedBy: `Admin-${RUN}`,
                  openingCash: 0,
                  status: "open",
                },
                select: { id: true },
              }),
            };
          },
          { timeout: 15_000, maxWait: 15_000 }
        );
        return "conflict" in row ? "conflict" : "created";
      } catch {
        return "error";
      }
    };

    const results = await Promise.all(Array.from({ length: 6 }, () => openOnce()));
    const created = results.filter((r) => r === "created").length;
    const conflicts = results.filter((r) => r === "conflict").length;
    expect(results.filter((r) => r === "error")).toEqual([]);
    expect(created).toBe(1);
    expect(conflicts).toBe(5);

    /* the serialized shift-code allocation also held: N creates → N distinct codes */
    const all = await db.shift.findMany({ where: { instanceId }, select: { code: true, status: true } });
    expect(all.length).toBe(1);
    expect(all[0].status).toBe("open");
    const codes = new Set(all.map((s) => s.code));
    expect(codes.size).toBe(all.length);
  });
});

describe("ROUND 187 — shift close race (status-predicated CAS)", () => {
  test("2 concurrent closes → exactly ONE flips open→closed, the loser sees count 0", async () => {
    const instanceId = (
      await db.instance.create({
        data: {
          systemId: "pos",
          orgJson: JSON.stringify({ name: `ShiftRace-Close-${RUN}`, currency: "SAR" }),
          adminJson: JSON.stringify({ name: `Admin-${RUN}`, email: `close-${RUN}@shift.test` }),
          adminEmailIndex: `close-${RUN}-idx`,
          prefsJson: JSON.stringify({ lang: "ar" }),
          modulesJson: JSON.stringify(["pos"]),
        },
        select: { id: true },
      })
    ).id;
    const shift = await db.shift.create({
      data: {
        instanceId,
        code: "SHR-CLOSE-RACE-1",
        openedBy: `Admin-${RUN}`,
        openingCash: 0,
        status: "open",
      },
      select: { id: true },
    });

    /* the route's exact CAS */
    const closeOnce = async () =>
      db.shift.updateMany({
        where: { id: shift.id, status: "open" },
        data: {
          status: "closed",
          closedAt: new Date(),
          closedBy: `Admin-${RUN}`,
          countedCash: 100,
          expectedCash: 100,
          variance: 0,
          salesCount: 0,
          salesTotal: 0,
          discountTotal: 0,
          cashTotal: 0,
          cardTotal: 0,
        },
      });

    const [a, b] = await Promise.all([closeOnce(), closeOnce()]);
    const flipped = [a, b].filter((r) => r.count === 1).length;
    const rejected = [a, b].filter((r) => r.count === 0).length;
    expect(flipped).toBe(1);
    expect(rejected).toBe(1);

    const row = await db.shift.findUnique({ where: { id: shift.id } });
    expect(row?.status).toBe("closed");
    expect(row?.countedCash).toBe(100);
  });

  test("a close against an ALREADY-CLOSED shift sees count 0 (the 409 leg)", async () => {
    const instanceId = (
      await db.instance.create({
        data: {
          systemId: "pos",
          orgJson: JSON.stringify({ name: `ShiftRace-Seq-${RUN}`, currency: "SAR" }),
          adminJson: JSON.stringify({ name: `Admin-${RUN}`, email: `seq-${RUN}@shift.test` }),
          adminEmailIndex: `seq-${RUN}-idx`,
          prefsJson: JSON.stringify({ lang: "ar" }),
          modulesJson: JSON.stringify(["pos"]),
        },
        select: { id: true },
      })
    ).id;
    const shift = await db.shift.create({
      data: { instanceId, code: "SHR-SEQ-1", openedBy: "x", openingCash: 0, status: "closed" },
      select: { id: true },
    });
    const late = await db.shift.updateMany({
      where: { id: shift.id, status: "open" },
      data: { status: "closed", countedCash: 5 },
    });
    expect(late.count).toBe(0);
    const row = await db.shift.findUnique({ where: { id: shift.id } });
    expect(row?.countedCash).toBeNull();
  });
});
