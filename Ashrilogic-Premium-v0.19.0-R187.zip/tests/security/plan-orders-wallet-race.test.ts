/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — ROUND 162: the wallet-checkout ORDER_NOT_PENDING→paid
 * race guard (src/server/domains/plan-orders/service.ts).
 *
 * The instant wallet checkout is a compensating saga: debit → confirm. When
 * the confirm step loses the status flip to a CONCURRENT admin confirmation
 * (ORDER_NOT_PENDING while the row is PAID and the plan ACTIVATED), the old
 * code refunded the debit anyway — an activated plan granted for free. The
 * R162 guard probes the order's terminal state and accepts the raced PAID
 * outcome instead of compensating.
 *
 * Deterministic simulation: `@/lib/server/plan-orders` is module-mocked so
 * `confirmPlanOrderPaid` FIRST performs the real transition (the concurrent
 * admin's flip — full activation through the production code path) and THEN
 * returns the loser's observation (`ok: false, ORDER_NOT_PENDING`) — exactly
 * the interleaving the millisecond-scale race produces live. A mode switch
 * also exercises the OTHER arm: a non-race confirm failure (ORDER_EXPIRED)
 * must still refund + cancel exactly as before.
 */
import { mock, describe, test, expect, beforeAll, afterAll } from "bun:test";
import { ensureDemoEnv, getTestDb, type TestDb } from "./test-setup";

/* Bind the throwaway DB BEFORE any db-binding module imports (the isolation
 * canary contract from test-setup). */
ensureDemoEnv();

const realPlanOrders = await import("@/lib/server/plan-orders");
/* capture the ORIGINAL binding BEFORE the mock — mock.module mutates the
 * module namespace in place, so the spread alone would recurse. */
const realConfirmPlanOrderPaid = realPlanOrders.confirmPlanOrderPaid;

/** race=true → the concurrent admin wins the flip, our call observes 409;
 *  race=false → a plain non-race failure (ORDER_EXPIRED) to prove the
 *  compensating branch still refunds. */
let raceMode = true;

/* The race mock: the concurrent admin's confirm lands FIRST (the real
 * transition — flip + activation + activity), then our call observes the
 * loser's 409. */
mock.module("@/lib/server/plan-orders", () => ({
  ...realPlanOrders,
  confirmPlanOrderPaid: async (orderId: string) => {
    if (raceMode) {
      const actual = await realConfirmPlanOrderPaid(orderId);
      if (actual.ok) {
        return {
          ok: false as const,
          status: 409,
          error: "Order is no longer pending — refresh and try again",
          code: "ORDER_NOT_PENDING",
        };
      }
      return actual;
    }
    return {
      ok: false as const,
      status: 409,
      error: "Order has expired — create a new activation request",
      code: "ORDER_EXPIRED",
    };
  },
}));

let db: TestDb;
let service: typeof import("@/server/domains/plan-orders/service");
let HttpError: typeof import("@/lib/server/route").HttpError;

const RUN = Math.random().toString(36).slice(2, 8);
const TENANT_PRINCIPAL = {
  kind: "session" as const,
  actorId: `owner-${RUN}`,
  actorName: `owner-${RUN}@example.com`,
};

let instanceId = "";
let packageId = "";
const START_BALANCE_MINOR = 50_000_00;
const createdOrderIds: string[] = [];

beforeAll(async () => {
  db = await getTestDb();
  /* service imports AFTER the mock — its confirmPlanOrderPaid binding is
   * the race mock. */
  service = await import("@/server/domains/plan-orders/service");
  ({ HttpError } = await import("@/lib/server/route"));

  await (await import("@/lib/server/admin-mapper")).seedAdminDefaults(db);
  const pkg = await db.package.findFirstOrThrow({ where: { active: true }, orderBy: { sortOrder: "asc" } });
  packageId = pkg.id;

  const instance = await db.instance.create({
    data: {
      systemId: "hospital-management",
      orgJson: JSON.stringify({ name: `سباق المحفظة ${RUN}`, country: "SA", currency: "SAR" }),
      adminJson: JSON.stringify({ name: "مالك", email: `owner-${RUN}@example.com`, role: "owner" }),
      prefsJson: JSON.stringify({ lang: "ar", theme: "light", notif: true, backup: true, audit: true, demo: false }),
      modulesJson: JSON.stringify(["pharmacy"]),
      walletMinor: START_BALANCE_MINOR,
    },
  });
  instanceId = instance.id;
});

afterAll(async () => {
  if (createdOrderIds.length > 0) {
    await db.walletTxn.deleteMany({ where: { linkId: { in: createdOrderIds } } }).catch(() => undefined);
    await db.planOrder.deleteMany({ where: { id: { in: createdOrderIds } } }).catch(() => undefined);
  }
  await db.instance.deleteMany({ where: { id: instanceId } }).catch(() => undefined);
});

describe("ROUND 162 — wallet checkout ORDER_NOT_PENDING→paid race (deterministic)", () => {
  test("a concurrently-confirmed order is NOT refunded: one debit, zero refunds, plan activated, saga succeeds", async () => {
    const result = await service.createOwn(
      instanceId,
      { packageId, cycle: "monthly", methodId: "pm_default_bank", payWith: "wallet" },
      TENANT_PRINCIPAL
    );
    createdOrderIds.push(result.order.id);

    /* the authoritative charge: the order row's own amount snapshot —
     * ROUND 166: PlanOrder.amount is INTEGER MINOR UNITS (the money.ts
     * contract); no conversion — the wallet debits it directly. */
    const orderRow = await db.planOrder.findUnique({ where: { id: result.order.id } });
    expect(orderRow).toBeTruthy();
    const amountMinor = orderRow?.amount ?? 0;

    /* the saga answered SUCCESS (not the 409 the old code threw) */
    expect(result.walletPaid).toBe(true);
    expect(result.order.status).toBe("paid");
    /* the balance mirrors the debit with NO compensating refund */
    expect(result.balanceAfterMinor).toBe(START_BALANCE_MINOR - amountMinor);

    /* the DB rows: order paid via the wallet-checkout method, plan activated */
    expect(orderRow?.status).toBe("paid");
    expect(orderRow?.methodId).toBe("ashrilogic-wallet");

    const instanceRow = await db.instance.findUnique({ where: { id: instanceId } });
    expect(instanceRow?.packageId).toBe(packageId);
    expect(instanceRow?.planActivatedAt).toBeTruthy();
    expect(instanceRow?.walletMinor).toBe(START_BALANCE_MINOR - amountMinor);

    /* the ledger: EXACTLY ONE txn for this order (the debit) — a refund
     * credit would be the double-benefit bug */
    const txns = await db.walletTxn.findMany({ where: { linkId: result.order.id } });
    expect(txns.length).toBe(1);
    expect(txns[0]?.amountMinor).toBe(-amountMinor);

    /* the success tail ran: the wallet-debit activity + the audit row */
    const activity = await db.activity.findFirst({
      where: { instanceId, kind: "actWalletDebit" },
      orderBy: { createdAt: "desc" },
    });
    expect(activity).toBeTruthy();

    const audit = await db.auditLog.findFirst({
      where: { action: "instance.planOrderCreate", actorId: TENANT_PRINCIPAL.actorId },
      orderBy: { createdAt: "desc" },
    });
    expect(audit).toBeTruthy();
    const meta = audit?.metaJson ? (JSON.parse(audit.metaJson) as Record<string, string>) : {};
    expect(meta.walletPaid).toBe("instant");
    expect(meta.activated).toBe("true");
  });

  test("a NON-race confirm failure still compensates: refund + cancel + the legacy error", async () => {
    raceMode = false;

    const balanceBefore = (await db.instance.findUniqueOrThrow({ where: { id: instanceId } })).walletMinor;

    let caught: unknown;
    try {
      await service.createOwn(
        instanceId,
        { packageId, cycle: "monthly", methodId: "pm_default_bank", payWith: "wallet" },
        TENANT_PRINCIPAL
      );
    } catch (e) {
      caught = e;
    }

    /* the legacy failure envelope propagates */
    expect(caught).toBeInstanceOf(HttpError);
    const err = caught as InstanceType<typeof HttpError>;
    expect(err.status).toBe(409);
    expect(err.code).toBe("ORDER_EXPIRED");

    /* the compensating law held: the wallet is WHOLE again and the order
     * was cancelled by the saga (not left pending) */
    const balanceAfter = (await db.instance.findUniqueOrThrow({ where: { id: instanceId } })).walletMinor;
    expect(balanceAfter).toBe(balanceBefore);

    const latest = await db.planOrder.findFirst({
      where: { instanceId },
      orderBy: { createdAt: "desc" },
    });
    expect(latest).toBeTruthy();
    createdOrderIds.push(latest!.id);
    expect(latest?.status).toBe("cancelled");

    /* the ledger: debit + matching refund (zero-sum pair) for this order */
    const txns = await db.walletTxn.findMany({
      where: { linkId: latest!.id },
      orderBy: { createdAt: "asc" },
    });
    expect(txns.length).toBe(2);
    expect(txns[0]!.amountMinor).toBeLessThan(0);
    expect(txns[1]!.amountMinor).toBe(-txns[0]!.amountMinor);
  });
});
