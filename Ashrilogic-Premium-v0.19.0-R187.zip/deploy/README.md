# Ashrilogic — deployment configuration

| File | Purpose |
| --- | --- |
| `Caddyfile.production` | The PRODUCTION edge gateway: one fixed upstream (`localhost:3000`), TLS automation for the filled-in domain, the shared hardening headers, the aligned request-size ceiling. **Contains none of the sandbox dynamic-port plumbing.** |
| (repo root) `../Caddyfile` | The SANDBOX gateway (dev machines + the managed preview) — includes the `XTransformPort` dynamic localhost port proxying that auxiliary mini-services rely on. **Never deploy this file to production.** |

## Which file where

- **Production / staging**: `caddy run --config deploy/Caddyfile.production`
  (fill in the real domain first; Caddy obtains and renews the certificate).
- **Local development / sandbox preview**: `caddy run --config Caddyfile` (the
  repo root file, port `:81` with the sandbox-only transform-port handler).

## Enforcement

`.zscripts/check-caddy-security.sh` fails when any PRODUCTION-shaped Caddy
config reintroduces client-controlled port proxying, and its `--strict` mode
(used by CI and the release packager) additionally REQUIRES that
`deploy/Caddyfile.production` exists — a missing production configuration is
a release blocker, never a "SKIPPED".

## Hardening notes carried by both files

- Forwarded headers are stamped in OVERWRITE mode — `X-Forwarded-For`,
  `X-Forwarded-Host`, `X-Forwarded-Proto` and `X-Real-IP` can never be
  forged by the client (the app's origin-guard and per-IP rate limiting
  depend on them).
- Baseline security headers are stamped at the edge as defense-in-depth;
  the full nonce-based CSP is owned by the app layer (`src/proxy.ts`).
- The request-body ceiling follows the layer-alignment rule:
  edge 26MB ≥ Next proxy hop 26MB ≥ restore route envelope 25MB.
