/**
 * Ashrilogic — ROUND 165 one-off backfill: workspace org-phone index.
 *
 * Backfills Instance.orgPhoneIndex (the normalizePhoneDeep comparison key
 * of the orgJson org.phone) for every row where it is NULL, so the signup
 * deep-uniqueness check (tenant-uniqueness.ts) resolves phone collisions
 * through an INDEXED point lookup instead of the bounded legacy orgJson
 * fallback scan.
 *
 * Idempotent: rows with a non-null orgPhoneIndex are skipped. Rows whose
 * orgJson carries no phone (or is corrupt) are indexed as NULL (they own
 * no phone identity — a phone collision with them is impossible by
 * definition).
 *
 * Usage: bun run scripts/backfill-org-phone-index.ts
 */
import { PrismaClient } from "@prisma/client";
import { normalizePhoneDeep } from "../src/lib/server/tenant-uniqueness";

const db = new PrismaClient();

async function main() {
  const rows = await db.instance.findMany({
    select: { id: true, orgJson: true, orgPhoneIndex: true },
    where: { orgPhoneIndex: null },
  });
  let updated = 0;
  for (const row of rows) {
    let phone = "";
    try {
      const org = JSON.parse(row.orgJson ?? "{}") as { phone?: unknown };
      phone = typeof org.phone === "string" ? org.phone : "";
    } catch {
      /* corrupt orgJson — owns no phone identity */
    }
    const key = normalizePhoneDeep(phone);
    await db.instance.update({
      where: { id: row.id },
      data: { orgPhoneIndex: key === "" ? null : key },
    });
    updated += 1;
  }
  console.log(`orgPhoneIndex backfill complete: ${updated}/${rows.length} rows updated`);
}

main()
  .catch((error) => {
    console.error("backfill failed:", error);
    process.exitCode = 1;
  })
  .finally(() => db.$disconnect());
