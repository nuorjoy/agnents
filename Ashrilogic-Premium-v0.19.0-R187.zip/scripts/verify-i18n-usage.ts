#!/usr/bin/env bun
/**
 * Ashrilogic — ROUND 145 (145-fix-qual) — scripts/verify-i18n-usage.ts
 *
 * Report-only DEAD-KEY detector for the typed AR/EN/HI dictionary.
 * Advisory tool: ALWAYS exits 0 — it never fails a build; the lead reads
 * the grouped report and decides on pruning.
 *
 * HOW IT WORKS (single pass, no per-key rg):
 *   1. Compose the AR dictionary keys by importing the domain modules
 *      directly (the exact fragments src/lib/i18n/index.ts spreads — the
 *      composer types I18nKey from AR, so AR is the source of truth).
 *   2. Walk src/ for every .ts/.tsx file EXCLUDING:
 *        - src/lib/i18n/**  (the dictionaries themselves),
 *        - src/generated/** (the Prisma runtime — no i18n keys, huge files).
 *      From each file extract every string literal (double-quoted,
 *      single-quoted, and interpolation-free backticks) with one regex.
 *   3. A dictionary key counts as USED iff it appears as a WHOLE WORD
 *      inside any extracted literal (token-split comparison): the literal
 *      "reportsActivitiesDesc" does NOT count as usage of the distinct key
 *      "reportsActivities", while t("reportsActivities"),
 *      labelKey: "reportsActivities" and composite literals containing it
 *      as a token all do.
 *   4. DYNAMIC-PREFIX WHITELIST — keys constructed at runtime
 *      (t(`prefix${...}`) style). Audited by grep before writing this
 *      script: the codebase contains ZERO template-literal t() calls; every
 *      key is a full literal either at the t() call site or inside a typed
 *      registry that stores full literals (FEATURE_META / FEATURE_GROUPS /
 *      BENEFIT_LIBRARY / ACT_STYLE / ROLE_NAME_I18N / PERM_LABEL_I18N /
 *      METHOD_KIND_META / ACTION_META / CODE_KEYS … — all matched
 *      naturally by the literal scan). The whitelist is therefore EMPTY
 *      today and is printed with the report; if a future round introduces
 *      dynamic keys, add their prefixes below so they are never reported
 *      dead.
 *   5. Print: totals, the whitelist, and the likely-dead keys grouped by
 *      family prefix (first token before the first uppercase run), sorted
 *      by size — the biggest families first.
 */

/* Step 4 — dynamic-key prefixes (see header). Empty by audit. */
const DYNAMIC_KEY_PREFIXES: readonly string[] = [];

/* ------------------------------------------------------------------ */
/* 1 — the AR dictionary keys (the composer's source of truth)         */
/* ------------------------------------------------------------------ */
import { landing } from "../src/lib/i18n/domains/landing";
import { auth } from "../src/lib/i18n/domains/auth";
import { wizard } from "../src/lib/i18n/domains/wizard";
import { dashboard } from "../src/lib/i18n/domains/dashboard";
import { site } from "../src/lib/i18n/domains/site";
import { admin } from "../src/lib/i18n/domains/admin";
import { store } from "../src/lib/i18n/domains/store";
import { inventory } from "../src/lib/i18n/domains/inventory";
import { features } from "../src/lib/i18n/domains/features";
import { business } from "../src/lib/i18n/domains/business";
import { common } from "../src/lib/i18n/domains/common";

const AR = {
  ...landing.ar,
  ...auth.ar,
  ...wizard.ar,
  ...dashboard.ar,
  ...site.ar,
  ...admin.ar,
  ...store.ar,
  ...inventory.ar,
  ...features.ar,
  ...business.ar,
  ...common.ar,
} as Record<string, string>;

const allKeys = Object.keys(AR);

/* ------------------------------------------------------------------ */
/* 2 — walk src/ and harvest every string literal                      */
/* ------------------------------------------------------------------ */
const ROOT = new URL("..", import.meta.url).pathname; /* repo root */
const SRC = `${ROOT}src`;

/** Every string literal found, split into word tokens, all in ONE set.
 * A token is [A-Za-z0-9_]+ — exactly the alphabet i18n keys use. */
const usedTokens = new Set<string>();
/** files scanned + literals harvested (for the report line). */
let filesScanned = 0;
let literalsHarvested = 0;

/** double / single / interpolation-free backtick literals (non-greedy). */
const LITERAL_RE = /"([^"\\\n]*(?:\\.[^"\\\n]*)*)"|'([^'\\\n]*(?:\\.[^'\\\n]*)*)'|`([^`\\$]*(?:\\.[^`\\$]*)*)`/g;
const TOKEN_RE = /[A-Za-z0-9_]+/g;

/** Deterministic directory walk (Bun's readdir with recursive is fine,
 * but an explicit queue keeps the exclusion logic obvious). */
async function walk(dir: string): Promise<string[]> {
  const out: string[] = [];
  const entries = await Array.fromAsync(new Bun.Glob("**/*.{ts,tsx}").scan({ cwd: dir }));
  for (const rel of entries) out.push(`${dir}/${rel}`);
  return out;
}

const files = (await walk(SRC)).filter(
  (f) => !f.includes("/lib/i18n/") && !f.includes("/generated/")
);

for (const file of files) {
  const text = await Bun.file(file).text();
  filesScanned += 1;
  for (const match of text.matchAll(LITERAL_RE)) {
    const raw = match[1] ?? match[2] ?? match[3] ?? "";
    if (!raw) continue;
    literalsHarvested += 1;
    for (const token of raw.matchAll(TOKEN_RE)) {
      usedTokens.add(token[0]);
    }
  }
}

/* ------------------------------------------------------------------ */
/* 3 — classify every dictionary key                                   */
/* ------------------------------------------------------------------ */
const dynamic = (key: string): boolean =>
  DYNAMIC_KEY_PREFIXES.some((p) => key.startsWith(p));

const usedKeys = allKeys.filter((k) => usedTokens.has(k) || dynamic(k));
const deadKeys = allKeys.filter((k) => !usedTokens.has(k) && !dynamic(k));

/** family = the leading lowercase run of the key (wtrPinInvalid → "wtr"). */
function familyOf(key: string): string {
  const m = key.match(/^[a-z]+/);
  if (!m) return key; /* fully uppercase / numeric oddities — own family */
  return m[0];
}
const families = new Map<string, string[]>();
for (const key of deadKeys) {
  const fam = familyOf(key);
  const bucket = families.get(fam);
  if (bucket) bucket.push(key);
  else families.set(fam, [key]);
}
const ranked = [...families.entries()].sort((a, b) => b[1].length - a[1].length);

/* ------------------------------------------------------------------ */
/* 4 — the report                                                      */
/* ------------------------------------------------------------------ */
const pct = (n: number, d: number): string => `${d === 0 ? 0 : Math.round((n / d) * 100)}%`;

console.log("── verify-i18n-usage (ROUND 145 · 145-fix-qual · advisory) ──");
console.log(`dictionary keys (AR, the composer's source of truth): ${allKeys.length}`);
console.log(`src files scanned (excl. src/lib/i18n/** + src/generated/**): ${filesScanned}`);
console.log(`string literals harvested: ${literalsHarvested}`);
console.log(`keys with usage: ${usedKeys.length} (${pct(usedKeys.length, allKeys.length)})`);
console.log(`likely-dead keys: ${deadKeys.length} (${pct(deadKeys.length, allKeys.length)})`);
console.log(
  `dynamic-prefix whitelist: ${
    DYNAMIC_KEY_PREFIXES.length === 0
      ? "(empty — grep audit found zero template-literal t() constructions; every key is a full literal at the call site or inside a typed registry)"
      : DYNAMIC_KEY_PREFIXES.join(", ")
  }`
);
console.log("");
console.log("── likely-dead keys grouped by family prefix (largest first) ──");
for (const [fam, keys] of ranked) {
  console.log(`  ${fam}* — ${keys.length}`);
  const shown = keys.slice(0, 6);
  for (const key of shown) console.log(`      ${key}`);
  if (keys.length > shown.length) console.log(`      … +${keys.length - shown.length} more`);
}
if (deadKeys.length === 0) {
  console.log("  (none — every dictionary key has a literal consumer)");
}

/* Advisory tool: ALWAYS exit 0 (the lead decides on pruning). */
process.exit(0);
