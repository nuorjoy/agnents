// Ashrilogic — ROUND 53 demo order seeding (one-off, idempotent).
//
// Backfills realistic storefront orders for every SHOWCASE instance that has
// a store (a catalog module + site customers), so the new best-sellers
// analytics card, the E-Store KPI strip and the order queue all render with
// meaningful demo data out of the box.
//
//   DATABASE_URL="file:/absolute/path/to/db/custom.db" \
//     bun scripts/seed-demo-orders.ts
//
// Rules:
//  - skips any instance that already has orders (safe to re-run);
//  - prices are read from the records' REAL money cells (minor units via
//    the same parser the storefront uses) and stored as v2 snapshots;
//  - ROUND 54: each item carries the record's managed imageRef when one is
//    attached (the placement route does the same at order time) so the demo
//    guest-tracking timeline renders with photos out of the box;
//  - stock is NOT consumed (this is demo history, not live traffic);
//  - statuses weighted toward completed, spread across the last ~45 days.

import { PrismaClient } from "@prisma/client";
import { storeModuleId, storeColumnsFor, parseRecordValues } from "@/lib/server/store-mapper";
import { parsePriceCellToMinor } from "@/lib/server/money";
import { generateTrackingCode } from "@/lib/server/coupons";
import { snapshotImage } from "@/lib/server/order-snapshot";

const db = new PrismaClient();

/* deterministic PRNG so re-seeding a fresh db yields the same showcase */
function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const STATUS_PLAN: string[] = [
  "completed", "completed", "completed", "completed", "completed", "completed",
  "completed", "completed", "confirmed", "preparing",
  "pending", "pending", "ready", "cancelled",
];

const NOTES: string[] = [
  "", "", "", "يرجى الاتصال قبل التوصيل", "بدون ملاحظات", "التوصيل مساءً إن أمكن", "",
];

async function main(): Promise<void> {
  const url = process.env.DATABASE_URL ?? "(default)";
  console.log(`seeding demo orders → ${url}`);

  const instances = await db.instance.findMany({
    select: {
      id: true,
      modulesJson: true,
      demo: true,
      site: { select: { published: true } },
      customers: { select: { id: true, name: true } },
    },
  });

  let seeded = 0;
  for (const inst of instances) {
    /* showcase instances with a published site + a catalog module only */
    const moduleId = storeModuleId(inst);
    if (!inst.demo || !inst.site?.published || !moduleId) continue;
    if (inst.customers.length === 0) continue;

    const existing = await db.siteOrder.count({ where: { instanceId: inst.id } });
    if (existing > 0) {
      console.log(`- ${inst.id}: ${existing} order(s) already present — skipped`);
      continue;
    }

    const records = await db.moduleRecord.findMany({
      where: { instanceId: inst.id, moduleId },
      take: 60,
    });
    const sellable = records
      .map((r) => {
        const cols = storeColumnsFor(moduleId);
        const values = parseRecordValues(r.dataJson);
        const price = parsePriceCellToMinor(values[cols.price] ?? "");
        const name = (values[cols.name] ?? "").trim();
        /* ROUND 54 — carry the managed photo into the snapshot (validated by
           the shared shape guard; a malformed stored ref degrades to none) */
        const image = snapshotImage(r.imageRef);
        return price > 0 && name
          ? image
            ? { recordId: r.id, name, price, image }
            : { recordId: r.id, name, price }
          : null;
      })
      .filter(
        (x): x is { recordId: string; name: string; price: number; image?: string } => x !== null
      );
    if (sellable.length < 3) {
      console.log(`- ${inst.id}: only ${sellable.length} sellable rows — skipped`);
      continue;
    }

    const rng = mulberry32(
      [...inst.id].reduce((h, c) => Math.imul(h, 31) + c.charCodeAt(0) | 0, 7)
    );
    const now = Date.now();
    const usedCodes = new Set<string>();
    const ordersToCreate = 8 + Math.floor(rng() * 7); // 8..14 per store

    for (let i = 0; i < ordersToCreate; i++) {
      const itemCount = 1 + Math.floor(rng() * 3); // 1..3 lines
      const picked = new Map<
        string,
        { recordId: string; name: string; price: number; qty: number; image?: string }
      >();
      while (picked.size < Math.min(itemCount, sellable.length)) {
        const p = sellable[Math.floor(rng() * sellable.length)];
        if (!picked.has(p.recordId)) {
          picked.set(p.recordId, { ...p, qty: 1 + Math.floor(rng() * 3) });
        }
      }
      const items = [...picked.values()];
      const totalMinor = items.reduce((sum, it) => sum + it.price * it.qty, 0);
      /* backdate: 0..45 days ago, older orders skew completed */
      const ageDays = Math.floor(rng() * 45);
      const createdAt = new Date(now - ageDays * 86_400_000 - Math.floor(rng() * 20) * 3_600_000);
      const status =
        ageDays > 6
          ? (rng() < 0.12 ? "cancelled" : "completed")
          : STATUS_PLAN[Math.floor(rng() * STATUS_PLAN.length)];
      const customer = inst.customers[Math.floor(rng() * inst.customers.length)];
      let code = generateTrackingCode();
      while (usedCodes.has(code)) code = generateTrackingCode();
      usedCodes.add(code);

      await db.siteOrder.create({
        data: {
          instanceId: inst.id,
          customerId: customer.id,
          code,
          itemsJson: JSON.stringify({
            v: 2,
            items: items.map((it) =>
              it.image
                ? { recordId: it.recordId, name: it.name, price: it.price, qty: it.qty, image: it.image }
                : { recordId: it.recordId, name: it.name, price: it.price, qty: it.qty }
            ),
          }),
          total: totalMinor,
          discount: 0,
          currency: "SAR",
          status,
          note: NOTES[Math.floor(rng() * NOTES.length)] || null,
          createdAt,
          updatedAt: createdAt,
        },
      });
      seeded += 1;
    }
    console.log(`- ${inst.id}: seeded ${ordersToCreate} orders`);
  }

  console.log(`done — ${seeded} demo order(s) created`);
}

main()
  .catch((err) => {
    console.error(err);
    process.exitCode = 1;
  })
  .finally(() => db.$disconnect());
