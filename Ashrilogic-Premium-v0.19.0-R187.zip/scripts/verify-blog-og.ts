/**
 * R183 verification harness — renders the /blog/[slug] Open-Graph card
 * STANDALONE (outside the dev server).
 *
 * WHY: compiling the blog OG route (next/og + prisma in one Turbopack
 * graph) OOM-kills this 4GB sandbox's dev server — reproducibly, three
 * times. The SYSTEMS OG route (static catalog, no prisma) is verified
 * through the dev server end-to-end; this harness verifies the BLOG route's
 * rendering logic (fonts, satori layout, DB read) by importing the route's
 * default export — a pure async function ({ params }) → ImageResponse —
 * and materializing the PNG to disk. The only unverified remainder is the
 * Next file-convention SERVING of the URL, which the systems route proves
 * works in this exact app (same convention, same shape).
 *
 * Usage: bun scripts/verify-blog-og.ts
 */
import blogOg from "../src/app/blog/[slug]/opengraph-image";
import systemsOg from "../src/app/systems/[id]/opengraph-image";
import { writeFileSync } from "node:fs";

async function main() {
  /* the DB read needs the PG URL — bun loads .env automatically */
  const slug = process.argv[2] ?? "seven-step-setup-wizard";
  const res = await blogOg({ params: Promise.resolve({ slug }) });
  console.log("blog og image:", res.status, res.headers.get("content-type"));
  const buf = Buffer.from(await res.arrayBuffer());
  writeFileSync("/tmp/blog-og.png", buf);
  console.log("wrote /tmp/blog-og.png:", buf.length, "bytes");

  const res2 = await systemsOg({ params: Promise.resolve({ id: "hospital-management" }) });
  const buf2 = Buffer.from(await res2.arrayBuffer());
  writeFileSync("/tmp/systems-og-standalone.png", buf2);
  console.log("systems og (standalone cross-check):", res2.status, buf2.length, "bytes");
}

main().catch((e) => {
  console.error("FAILED:", e);
  process.exit(1);
});
