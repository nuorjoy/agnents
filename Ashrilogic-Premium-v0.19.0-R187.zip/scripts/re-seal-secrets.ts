// Ashrilogic — ASHRILOGIC_DATA_KEY rotation re-seal runbook (ROUND 96).
//
// WHY THIS EXISTS: every sensitive field (customer/team/admin emails, phones,
// addresses, TOTP secrets, AI provider keys) is sealed with AES-256-GCM
// derived from ASHRILOGIC_DATA_KEY; lookups use HMAC blind indexes derived
// from the SAME root; the audit-trail hash chain derives from it too. After
// a key rotation the stored envelopes cannot be opened (GCM auth fails →
// decryptField returns "" → logins break, indexes collide), and the audit
// chain stops verifying. The restore engine detects the mismatch
// (BACKUP_KEY_MISMATCH) but there was NO recovery path — this script is it.
//
// PROTOCOL (data-safety lock):
//   1. PREFLIGHT   — both keys present + distinct + ≥16 chars, app STOPPED
//                    (port probe — a live process holds pooled database
//                    connections open), and the database answers a
//                    trivial query (SELECT 1).
//   2. BACKUP      — a platform snapshot via runPlatformBackup() (pg_dump
//                    custom format under storage/backups/
//                    ashrilogic-<stamp>/) — the same verified artifact the
//                    scheduler produces; a FAILED snapshot ABORTS the run
//                    (no rollback artifact = no rotation).
//   3. SCAN        — read-only pass: every sealed envelope MUST decrypt
//                    with the OLD key (or the NEW key — the script is
//                    RESUMABLE after a crash mid-rotation). A single envelope
//                    that opens with NEITHER = wrong old key or corruption →
//                    abort with NOTHING changed.
//   4. CHAIN CHECK — the audit chain must be structurally healthy under the
//                    OLD key BEFORE re-keying (re-chaining a tampered chain
//                    would launder exactly the tamper it exists to surface).
//   5. --execute   — re-seal every envelope (old→new), recompute every
//                    blind index with the NEW index key, then re-chain the
//                    audit trail with the NEW chain key (links preserved,
//                    gap rows chained — the documented post-rotation repair).
//   6. VERIFY      — every envelope opens with the NEW key; every index
//                    column matches its recomputed value; the audit chain
//                    verifies healthy.
//   7. AUDIT       — a system.reseal row (SECURITY action, unconditional)
//                    records counts, key fingerprints and the backup path.
//
// USAGE:
//   ASHRILOGIC_OLD_DATA_KEY='<old>' ASHRILOGIC_DATA_KEY='<new>' \
//     bun scripts/re-seal-secrets.ts              # dry-run: scan + plan only
//   ASHRILOGIC_OLD_DATA_KEY='<old>' ASHRILOGIC_DATA_KEY='<new>' \
//     bun scripts/re-seal-secrets.ts --execute    # land the rotation
//
// ROLLBACK (any failure, or a bad rotation): stop the app, then
//   bun scripts/platform-restore.ts --restore ashrilogic-<stamp> --confirm
// (the pre-reseal snapshot above) and restart with the OLD key. The
// pre-reseal snapshot is never deleted here.
//
// NOTE — restore leases: harmless expired RestoreLease leftovers are cleared
// at the end of a successful run.

import { createDecipheriv, createHmac, createHash, hkdfSync, randomUUID } from "node:crypto";
import { PrismaClient } from "@prisma/client";

const args = process.argv.slice(2);
const EXECUTE = args.includes("--execute");
const FORCE = args.includes("--force");
/* Proceed DESPITE envelopes that open with neither key (pre-rotation legacy
 * cells sealed under a lost key): they are left VERBATIM (still unopenable),
 * counted, and listed in the audit row. Without this flag such cells ABORT
 * the rotation — the safe default (they may indicate corruption). */
const SKIP_UNOPENABLE = args.includes("--skip-unopenable");

/* ------------------------------ old-key crypto ---------------------------- */

const OLD_SECRET = process.env.ASHRILOGIC_OLD_DATA_KEY ?? "";
const NEW_SECRET = process.env.ASHRILOGIC_DATA_KEY ?? "";

const VAULT_MARKER = "enc:v1:";
const INFO_AES = "ashrilogic/field-aes-256-gcm/v1";
const INFO_CHAIN = "ashrilogic/audit-chain-hmac/v1";

function deriveKey(secret: string, info: string): Buffer {
  return Buffer.from(
    hkdfSync("sha256", Buffer.from(secret, "utf8"), Buffer.alloc(0), info, 32)
  );
}

const OLD_AES = deriveKey(OLD_SECRET, INFO_AES);
const OLD_CHAIN = deriveKey(OLD_SECRET, INFO_CHAIN);

/** Decrypt a sealed envelope with an explicit key. THROWS on GCM auth
 *  failure — the wrong-key/corruption detector (the production decryptField
 *  degrades to "" instead; here the distinction is the abort signal). */
function decryptWithKey(aesKey: Buffer, envelope: string): string {
  const parts = envelope.slice(VAULT_MARKER.length).split(":");
  if (parts.length !== 3) throw new Error("malformed envelope (not 3 segments)");
  const [ivB64, tagB64, ctB64] = parts;
  const decipher = createDecipheriv("aes-256-gcm", aesKey, Buffer.from(ivB64, "base64"));
  decipher.setAuthTag(Buffer.from(tagB64, "base64"));
  const pt = Buffer.concat([decipher.update(Buffer.from(ctB64, "base64")), decipher.final()]);
  return pt.toString("utf8");
}

function isSealed(value: unknown): value is string {
  return typeof value === "string" && value.startsWith(VAULT_MARKER);
}

/** Old-key chain hash — identical canonicalization to audit-chain.ts. */
function oldChainHash(input: {
  prevChainHash: string | null;
  actorType: string;
  actorId: string | null;
  actorName: string;
  action: string;
  targetLabel: string | null;
  metaJson: string | null;
  createdAtISO: string;
}): string {
  const canonical = JSON.stringify([
    input.prevChainHash,
    input.actorType,
    input.actorId,
    input.actorName,
    input.action,
    input.targetLabel,
    input.metaJson,
    input.createdAtISO,
  ]);
  return createHmac("sha256", OLD_CHAIN).update(canonical, "utf8").digest("hex");
}

function fingerprint(secret: string): string {
  return createHash("sha256").update(secret, "utf8").digest("hex").slice(0, 12);
}

/* ------------------------------ new-key vault ----------------------------- */
/* Bound to ASHRILOGIC_DATA_KEY (the NEW key) at import time — the script
 * requires it set in the shell BEFORE it starts, exactly like the production
 * process binds it at boot. decryptField returns "" on auth failure (it never
 * throws) and sealed envelopes never hold empty plaintext, so "" is the
 * new-key failure signal here. */

const vault = await import("@/lib/server/crypto-vault");
const auditChain = await import("@/lib/server/audit-chain");
const platformBackup = await import("@/lib/server/platform-backup");

/* ------------------------------ table plan -------------------------------- */

/** One table's sealed-field topology. */
interface TablePlan {
  model:
    | "siteCustomer"
    | "teamMember"
    | "adminUser"
    | "subscriber"
    | "supportTicket"
    | "mfaSecret"
    | "webhookEndpoint"
    | "instance"
    | "platformSetting";
  label: string;
  /** whole-value sealed columns (the entire cell is one envelope) */
  sealed: string[];
  /** JSON columns that EMBED sealed strings (deep walk, re-seal in place) */
  nestedJson: string[];
  /** index column → source column (dotted = nested) whose DECRYPTED
   *  plaintext feeds the NEW-key blind index */
  indexes: Record<string, string>;
}

const PLANS: TablePlan[] = [
  {
    model: "siteCustomer",
    label: "SiteCustomer",
    sealed: ["email", "phone"],
    nestedJson: [],
    indexes: { emailIndex: "email" },
  },
  {
    model: "teamMember",
    label: "TeamMember",
    sealed: ["email", "profileJson"],
    nestedJson: [],
    indexes: {},
  },
  {
    model: "adminUser",
    label: "AdminUser",
    sealed: ["email", "address"],
    nestedJson: [],
    indexes: { emailIndex: "email" },
  },
  {
    model: "subscriber",
    label: "Subscriber",
    sealed: ["email"],
    nestedJson: [],
    indexes: { emailIndex: "email" },
  },
  {
    model: "supportTicket",
    label: "SupportTicket",
    sealed: ["requesterEmail"],
    nestedJson: [],
    indexes: { requesterEmailIndex: "requesterEmail" },
  },
  {
    model: "mfaSecret",
    label: "MfaSecret",
    sealed: ["secretSealed"],
    nestedJson: [],
    indexes: {},
  },
  {
    /* ROUND 162 — webhook endpoint signing secrets are vault-sealed at
     * rest; a key rotation must re-seal them or every endpoint's
     * signatures stop verifying. */
    model: "webhookEndpoint",
    label: "WebhookEndpoint",
    sealed: ["secret"],
    nestedJson: [],
    indexes: {},
  },
  {
    model: "instance",
    label: "Instance",
    sealed: [],
    /* adminJson embeds the sealed admin email as { email: "enc:v1:…" } */
    nestedJson: ["adminJson"],
    indexes: { adminEmailIndex: "adminJson.email" },
  },
  {
    model: "platformSetting",
    label: "PlatformSetting",
    sealed: [],
    /* aiJson embeds { keySealed: "enc:v1:…" }; newsletterEmailsJson embeds
     * [{ email: "enc:v1:…" }]; smtpJson embeds { passwordSealed: "enc:v1:…" }
     * (ROUND 162 — previously missed: a rotation would have left the mail
     * password unopenable) */
    nestedJson: ["aiJson", "newsletterEmailsJson", "smtpJson"],
    indexes: {},
  },
];

/** every column a plan touches + the row id (update WHERE). */
function planColumns(plan: TablePlan): string[] {
  const cols = ["id", ...plan.sealed, ...plan.nestedJson, ...Object.keys(plan.indexes)];
  for (const src of Object.values(plan.indexes)) cols.push(src.split(".")[0]);
  return cols.filter((c, i, arr) => arr.indexOf(c) === i);
}

/** minimal delegate surface the generic loop needs (prisma typing is far
 *  richer; this keeps the plan loop table-agnostic). */
interface Delegate {
  findMany(args: { select: Record<string, boolean> }): Promise<Record<string, unknown>[]>;
  update(args: { where: { id: string }; data: Record<string, unknown> }): Promise<unknown>;
}

/* ------------------------------ JSON walkers ------------------------------ */

type Json = string | number | boolean | null | Json[] | { [k: string]: Json };

interface WalkOutcome {
  changed: boolean;
  /** sealed strings re-sealed old→new this pass (plaintexts retained for
   *  index feeds when relevant) */
  oldPlaintexts: string[];
  /** sealed strings that already open with the NEW key (resume case) */
  alreadyNew: number;
  /** sealed strings that open with NEITHER key — fatal */
  failures: number;
}

/** Re-seal every sealed string inside a parsed JSON tree (mutates). */
function walkAndReseal(node: Json, out: WalkOutcome, encryptNew: (pt: string) => string): void {
  if (Array.isArray(node)) {
    for (const item of node) walkAndReseal(item, out, encryptNew);
    return;
  }
  if (node !== null && typeof node === "object") {
    for (const key of Object.keys(node)) {
      const value = node[key];
      if (typeof value === "string") {
        if (!isSealed(value)) continue;
        try {
          const plaintext = decryptWithKey(OLD_AES, value);
          node[key] = encryptNew(plaintext) as Json;
          out.oldPlaintexts.push(plaintext);
          out.changed = true;
        } catch {
          if (vault.decryptField(value) === "") out.failures += 1;
          else out.alreadyNew += 1;
        }
      } else {
        walkAndReseal(value, out, encryptNew);
      }
    }
  }
}

/** Non-mutating post-check: counts envelopes that do NOT open with the NEW
 *  key (missed by the execute pass — old-key leftovers or neither-key). */
function walkVerify(node: Json, out: { bad: number }): void {
  if (Array.isArray(node)) {
    for (const item of node) walkVerify(item, out);
    return;
  }
  if (node !== null && typeof node === "object") {
    for (const key of Object.keys(node)) {
      const value = node[key];
      if (typeof value === "string") {
        if (isSealed(value) && vault.decryptField(value) === "") out.bad += 1;
      } else {
        walkVerify(value, out);
      }
    }
  }
}

/* --------------------------------- main ----------------------------------- */

const db = new PrismaClient();
const RUN_ID = randomUUID().slice(0, 8);

interface ScanCounts {
  rows: number;
  sealedCells: number;
  resealed: number;
  alreadyNew: number;
  legacy: number;
  failures: number;
  indexUpdates: number;
  parseFailures: number;
}

function freshCounts(): ScanCounts {
  return { rows: 0, sealedCells: 0, resealed: 0, alreadyNew: 0, legacy: 0, failures: 0, indexUpdates: 0, parseFailures: 0 };
}

async function appIsRunning(): Promise<boolean> {
  try {
    const res = await fetch("http://localhost:3000/api/status", {
      signal: AbortSignal.timeout(1500),
    });
    return res.ok;
  } catch {
    return false;
  }
}

/** Resolve an index source ("email" | "adminJson.email") to plaintext with
 *  old-then-new key precedence. Dotted paths JSON-parse the raw column first
 *  (nested sources live inside JSON-string columns). Null = absent or
 *  unreadable (skip). */
function resolveSourcePlaintext(row: Record<string, unknown>, spec: string): string | null {
  const path = spec.split(".");
  let cursor: unknown = row[path[0]];
  for (let i = 1; i < path.length; i++) {
    if (typeof cursor === "string") {
      try {
        cursor = JSON.parse(cursor) as unknown;
      } catch {
        return null;
      }
    }
    if (cursor === null || typeof cursor !== "object") return null;
    cursor = (cursor as Record<string, unknown>)[path[i]];
  }
  if (typeof cursor !== "string" || cursor === "") return null;
  if (!isSealed(cursor)) return cursor; // legacy plaintext
  try {
    return decryptWithKey(OLD_AES, cursor);
  } catch {
    const withNew = vault.decryptField(cursor);
    return withNew === "" ? null : (withNew as string);
  }
}

async function main(): Promise<void> {
  console.log(`re-seal run ${RUN_ID} — ${EXECUTE ? "EXECUTE (writes enabled)" : "DRY-RUN (scan only)"}`);

  /* ---------------- preflight ---------------- */
  if (OLD_SECRET.length < 16 || NEW_SECRET.length < 16) {
    throw new Error(
      "both ASHRILOGIC_OLD_DATA_KEY (the previous key) and ASHRILOGIC_DATA_KEY (the new key) must be set (min 16 chars)"
    );
  }
  if (OLD_SECRET === NEW_SECRET) {
    throw new Error("the old and new keys are identical — nothing to rotate");
  }
  console.log(`  old key fingerprint: ${fingerprint(OLD_SECRET)}…`);
  console.log(`  new key fingerprint: ${fingerprint(NEW_SECRET)}…`);

  if (!FORCE && (await appIsRunning())) {
    throw new Error(
      "the app appears to be RUNNING on :3000 — stop it first (a live process holds pooled database connections open). Use --force to override (NOT recommended)."
    );
  }

  /* database health gate — a trivial query proves the connection + the
   * engine answer before anything is written (a wedged/unreachable
   * database must abort the rotation, not surface mid-write) */
  await db.$queryRaw`SELECT 1`;
  console.log("  preflight: database reachable, app stopped");

  /* ---------------- backup (platform snapshot) ----------------
   * runPlatformBackup() lands a pg_dump custom-format archive under
   * storage/backups/ashrilogic-<stamp>/ — the same verified artifact the
   * scheduled backup produces, restorable by scripts/platform-restore.ts.
   * FAIL-CLOSED: no rollback artifact = no rotation (the snapshot is taken
   * for the dry run too — the pre-existing contract). */
  const snapshotDir = await platformBackup.runPlatformBackup();
  if (!snapshotDir) {
    throw new Error(
      "the pre-reseal platform snapshot FAILED (see the snapshot dir's FAILED.txt marker / server logs) — refusing to rotate without a rollback artifact"
    );
  }
  console.log(`  backup snapshot: ${snapshotDir}`);

  /* ---------------- audit chain pre-check (old OR new key) ---------------- */
  const chainRows = await db.auditLog.findMany({
    orderBy: [{ createdAt: "asc" }, { id: "asc" }],
  });
  const chained = chainRows.filter((r) => r.chainHash !== null);
  const chainTampered: string[] = [];
  let oldKeyChained = 0;
  for (const r of chained) {
    const input = {
      prevChainHash: r.prevChainHash,
      actorType: r.actorType,
      actorId: r.actorId,
      actorName: r.actorName,
      action: r.action,
      targetLabel: r.targetLabel,
      metaJson: r.metaJson,
      createdAtISO: r.createdAt.toISOString(),
    };
    if (oldChainHash(input) === r.chainHash) {
      oldKeyChained += 1;
      continue;
    }
    /* not the old key — already re-keyed by a previous (or crashed) run? */
    if (auditChain.computeChainHash(input) !== r.chainHash) chainTampered.push(r.id);
  }
  const chainByHash = new Set(chained.map((r) => r.chainHash as string));
  const chainOrphans = chained.filter(
    (r) => r.prevChainHash !== null && !chainByHash.has(r.prevChainHash)
  );
  if (chainTampered.length > 0 || chainOrphans.length > 0) {
    throw new Error(
      `audit chain is NOT healthy under EITHER key (${chainTampered.length} tampered, ` +
        `${chainOrphans.length} orphan) — re-chaining would launder tampering. ` +
        "Run scripts/verify-audit-chain.ts and investigate first."
    );
  }
  console.log(
    `  chain pre-check: ${chainRows.length} row(s), ${chained.length} chained — ` +
      (oldKeyChained === chained.length
        ? "healthy under the OLD key"
        : oldKeyChained === 0
          ? "already re-keyed (previous run)"
          : `mixed (${oldKeyChained} old-key, ${chained.length - oldKeyChained} new-key — crash resume)`)
  );

  /* ---------------- scan + (optional) execute ---------------- */
  const counts = new Map<string, ScanCounts>();
  const failures: Array<{ table: string; id: string; column: string }> = [];

  for (const plan of PLANS) {
    const c = freshCounts();
    counts.set(plan.label, c);
    const delegate = db[plan.model] as unknown as Delegate;
    const rows = await delegate.findMany({
      select: Object.fromEntries(planColumns(plan).map((col) => [col, true])),
    });
    for (const row of rows) {
      c.rows += 1;
      const updates: Record<string, unknown> = {};

      /* whole-value sealed columns */
      for (const col of plan.sealed) {
        const raw = row[col];
        if (raw === null || raw === undefined || raw === "") continue;
        if (!isSealed(raw)) {
          c.legacy += 1;
          continue;
        }
        c.sealedCells += 1;
        try {
          const plaintext = decryptWithKey(OLD_AES, raw);
          updates[col] = vault.encryptField(plaintext);
          c.resealed += 1;
        } catch {
          if (vault.decryptField(raw) === "") {
            c.failures += 1;
            failures.push({ table: plan.label, id: String(row.id), column: col });
            /* --skip-unopenable: leave the cell verbatim (unopenable),
               never re-seal garbage */
          } else {
            c.alreadyNew += 1; // resume case — already re-sealed
          }
        }
      }

      /* nested-JSON columns */
      for (const col of plan.nestedJson) {
        const raw = row[col];
        if (typeof raw !== "string" || raw === "") continue;
        let parsed: Json;
        try {
          parsed = JSON.parse(raw) as Json;
        } catch {
          c.parseFailures += 1; // keep raw verbatim (same tolerance as backup.ts)
          continue;
        }
        const out: WalkOutcome = { changed: false, oldPlaintexts: [], alreadyNew: 0, failures: 0 };
        walkAndReseal(parsed, out, (pt) => vault.encryptField(pt) ?? "");
        c.sealedCells += out.oldPlaintexts.length + out.alreadyNew + out.failures;
        c.resealed += out.oldPlaintexts.length;
        c.alreadyNew += out.alreadyNew;
        c.failures += out.failures;
        if (out.failures > 0) {
          failures.push({ table: plan.label, id: String(row.id), column: col });
        }
        if (out.changed) updates[col] = JSON.stringify(parsed);
      }

      /* index columns — recomputed with the NEW index key */
      for (const [indexCol, sourceSpec] of Object.entries(plan.indexes)) {
        const plaintext = resolveSourcePlaintext(row, sourceSpec);
        if (plaintext === null) continue;
        const newIndex = vault.blindIndex(plaintext);
        if (newIndex !== null && row[indexCol] !== newIndex) {
          updates[indexCol] = newIndex;
          c.indexUpdates += 1;
        }
      }

      if (EXECUTE && Object.keys(updates).length > 0) {
        await delegate.update({ where: { id: String(row.id) }, data: updates });
      }
    }
  }

  /* ---------------- report ---------------- */
  console.log("\n  scan results:");
  let totalFailures = 0;
  for (const [label, c] of counts) {
    console.log(
      `    ${label.padEnd(20)} rows=${c.rows} sealed=${c.sealedCells} → re-seal=${c.resealed}` +
        ` alreadyNew=${c.alreadyNew} legacy=${c.legacy} indexes=${c.indexUpdates}` +
        `${c.parseFailures > 0 ? ` parseFailures=${c.parseFailures}` : ""}${c.failures > 0 ? ` FAILURES=${c.failures}` : ""}`
    );
    totalFailures += c.failures;
  }
  if (totalFailures > 0) {
    if (!SKIP_UNOPENABLE) {
      console.error(
        `\nABORT — ${totalFailures} sealed envelope(s) open with NEITHER key (wrong ASHRILOGIC_OLD_DATA_KEY or corruption). NOTHING was changed. First failures:`
      );
      for (const f of failures.slice(0, 10)) console.error(`    ${f.table}.${f.column} (id ${f.id})`);
      console.error(
        "  If these are known-unrecoverable legacy cells (sealed under a lost pre-rotation key), re-run with --skip-unopenable to rotate around them (they stay verbatim + are audited)."
      );
      process.exitCode = 1;
      return;
    }
    console.warn(
      `\n  --skip-unopenable: ${totalFailures} envelope(s) open with NEITHER key — left VERBATIM (still unopenable), audited below:`
    );
    for (const f of failures.slice(0, 20)) console.warn(`    ${f.table}.${f.column} (id ${f.id})`);
  }

  if (!EXECUTE) {
    console.log("\nDRY-RUN complete — nothing written. Re-run with --execute to land the rotation.");
    return;
  }

  /* ---------------- audit-chain re-key (NEW chain key) ---------------- */
  /* Ordered walk: every row gets prevChainHash = the NEW hash of its
   * predecessor, its own chainHash recomputed with the NEW key. Gap rows
   * (NULL hashes) are chained in creation order — the documented
   * post-rotation repair. The pre-rotation anchor is DELETED: it points at
   * an old-key hash of a pruned row that no longer participates in the
   * re-keyed chain (the re-chained chain starts at the oldest retained row
   * with prevChainHash = null — a fresh genesis). */
  let prev: string | null = null;
  let reChained = 0;
  for (const r of chainRows) {
    const chainHash = auditChain.computeChainHash({
      prevChainHash: prev,
      actorType: r.actorType,
      actorId: r.actorId,
      actorName: r.actorName,
      action: r.action,
      targetLabel: r.targetLabel,
      metaJson: r.metaJson,
      createdAtISO: r.createdAt.toISOString(),
    });
    if (r.prevChainHash !== prev || r.chainHash !== chainHash) {
      await db.auditLog.update({
        where: { id: r.id },
        data: { prevChainHash: prev, chainHash },
      });
      reChained += 1;
    }
    prev = chainHash;
  }
  await db.auditChainAnchor.deleteMany({});
  console.log(`  audit chain re-keyed: ${reChained} row(s) updated, anchor cleared (fresh genesis)`);

  /* ---------------- final verification ---------------- */
  /* cells recorded as unopenable (--skip-unopenable) are EXEMPT: they stay
   * verbatim by design and would (correctly) fail the new-key check. */
  const skippedCells = new Set(failures.map((f) => `${f.table}|${f.id}|${f.column}`));
  const verifyFailures: string[] = [];
  for (const plan of PLANS) {
    const delegate = db[plan.model] as unknown as Delegate;
    const rows = await delegate.findMany({
      select: Object.fromEntries(planColumns(plan).map((col) => [col, true])),
    });
    for (const row of rows) {
      /* whole-value sealed columns: must open with the NEW key */
      for (const col of plan.sealed) {
        const raw = row[col];
        if (skippedCells.has(`${plan.label}|${String(row.id)}|${col}`)) continue;
        if (isSealed(raw) && vault.decryptField(raw) === "") {
          verifyFailures.push(`${plan.label}.${col} id=${String(row.id)} — new-key decrypt failed`);
        }
      }
      /* nested JSON: every embedded envelope must open with the NEW key */
      for (const col of plan.nestedJson) {
        if (skippedCells.has(`${plan.label}|${String(row.id)}|${col}`)) continue;
        const raw = row[col];
        if (typeof raw !== "string" || raw === "") continue;
        try {
          const parsed = JSON.parse(raw) as Json;
          const out = { bad: 0 };
          walkVerify(parsed, out);
          if (out.bad > 0) {
            verifyFailures.push(`${plan.label}.${col} id=${String(row.id)} — ${out.bad} envelope(s) not new-key`);
          }
        } catch {
          /* parse failure carried over from before the rotation — tolerated */
        }
      }
      /* index columns: stored value must equal the recomputed one */
      for (const [indexCol, sourceSpec] of Object.entries(plan.indexes)) {
        const plaintext = resolveSourcePlaintext(row, sourceSpec);
        if (plaintext === null) continue;
        const expected = vault.blindIndex(plaintext);
        if (expected !== null && row[indexCol] !== expected) {
          verifyFailures.push(`${plan.label}.${indexCol} id=${String(row.id)} — index mismatch`);
        }
      }
    }
  }
  const finalChain = await db.auditLog.findMany({ orderBy: [{ createdAt: "asc" }, { id: "asc" }] });
  const chainResult = auditChain.verifyChainHashes(finalChain);
  if (!chainResult.healthy) {
    verifyFailures.push(
      `audit chain: ${chainResult.tampered.length} tampered, ${chainResult.orphans.length} orphan, ${chainResult.forks.length} fork`
    );
  }
  if (verifyFailures.length > 0) {
    console.error(`\nVERIFY FAILED — ${verifyFailures.length} problem(s). ROLLBACK NOW:`);
    console.error(
      `  bun scripts/platform-restore.ts --restore ${snapshotDir.split(/[/\\]/).pop()} --confirm`
    );
    for (const f of verifyFailures.slice(0, 10)) console.error(`    ${f}`);
    process.exitCode = 1;
    return;
  }
  console.log("  verification: every envelope opens with the new key · indexes consistent · chain healthy");

  /* ---------------- audit row (system.reseal — SECURITY action) ---------------- */
  const totals = freshCounts();
  for (const c of counts.values()) {
    totals.sealedCells += c.sealedCells;
    totals.resealed += c.resealed;
    totals.alreadyNew += c.alreadyNew;
    totals.indexUpdates += c.indexUpdates;
    totals.parseFailures += c.parseFailures;
    totals.failures += c.failures;
  }
  const { logAudit } = await import("@/lib/server/audit");
  await logAudit({
    actorType: "system",
    actorName: "key-rotation",
    action: "system.reseal",
    targetLabel: "ASHRILOGIC_DATA_KEY rotation",
    meta: {
      runId: RUN_ID,
      oldKeyFingerprint: fingerprint(OLD_SECRET),
      newKeyFingerprint: fingerprint(NEW_SECRET),
      envelopes: String(totals.sealedCells),
      resealed: String(totals.resealed),
      alreadyNew: String(totals.alreadyNew),
      indexes: String(totals.indexUpdates),
      chainRowsRekeyed: String(reChained),
      skippedUnopenable: String(totals.failures),
      backupPath: snapshotDir,
    },
  });

  /* housekeeping: stale expired restore leases — clear */
  await db.restoreLease.deleteMany({ where: { expiresAt: { lt: new Date() } } });

  console.log("\nROTATION COMPLETE.");
  console.log(`  rollback snapshot retained at: ${snapshotDir}`);
  console.log("  keep BOTH keys until you have confirmed the platform works with the new one.");
}

main()
  .then(() => db.$disconnect())
  .catch(async (error) => {
    console.error("re-seal failed:", error instanceof Error ? error.message : error);
    await db.$disconnect();
    process.exit(1);
  });
