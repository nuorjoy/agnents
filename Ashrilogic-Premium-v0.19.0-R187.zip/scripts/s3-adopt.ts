/**
 * Ashrilogic — ROUND 122 — ADOPT the local images namespace into the
 * configured S3-compatible object store (MinIO / R2 / AWS S3 / Garage).
 *
 * One-shot, idempotent, verified:
 *   - lists the LOCAL images/ files (content-addressed <sha256>.webp —
 *     the transient .tmp-* writes are skipped);
 *   - PUTs each through the S3 driver (SigV4, signed payload);
 *   - re-reads it back and re-hashes — a mismatch ABORTS the run loudly
 *     (never "copied" without proof; the content-addressed names make
 *     this verification exact);
 *   - already-present identical objects are skipped (stat first — the
 *     run is resumable and cheap to re-run).
 *
 * Usage:
 *   ASHRILOGIC_STORAGE_DRIVER=s3 S3_... bun scripts/s3-adopt.ts --dry-run
 *   ASHRILOGIC_STORAGE_DRIVER=s3 S3_... bun scripts/s3-adopt.ts
 *
 * Notes:
 *   - the DB rows (ImageAsset) are untouched — they are the metadata for
 *     BOTH drivers; only the bytes move;
 *   - run it with the app STOPPED or quiesced for uploads (a storeImage
 *     racing the adopt is harmless — the next run copies the new file —
 *     but a clean cutover window is the documented procedure);
 *   - after adoption, keep the local files until you trust the new store
 *     (the local copy is a valid fallback: unset the driver to go back).
 */

import { createHash } from "node:crypto";
import { existsSync, readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";

/* the LOCAL source root — resolved the same way as local-driver.ts */
function repoRoot(): string {
  let dir = process.cwd();
  for (let i = 0; i < 6; i++) {
    if (existsSync(join(dir, "package.json")) && existsSync(join(dir, "prisma"))) return dir;
    const parent = join(dir, "..");
    if (parent === dir) break;
    dir = parent;
  }
  return process.cwd();
}

const DRY_RUN = process.argv.includes("--dry-run");

async function main(): Promise<void> {
  if (process.env.ASHRILOGIC_STORAGE_DRIVER !== "s3") {
    console.error(
      "Refusing to run: ASHRILOGIC_STORAGE_DRIVER is not \"s3\". " +
        "Set the S3_* variables and ASHRILOGIC_STORAGE_DRIVER=s3 so the adopt " +
        "target is explicit (see .env.example)."
    );
    process.exit(2);
  }

  /* the S3 driver factory validates the config (fail-fast with the
   * missing-variable list) */
  const { objectStorage } = await import("../src/lib/server/storage/object-store");
  const store = await objectStorage();
  if (store.driver !== "s3") {
    console.error("objectStorage() resolved a non-S3 driver — refusing.");
    process.exit(2);
  }

  const root = process.env.ASHRILOGIC_STORAGE_DIR ?? join(repoRoot(), "storage");
  const imagesDir = join(root, "images");
  if (!existsSync(imagesDir)) {
    console.log(`no local images directory at ${imagesDir} — nothing to adopt.`);
    return;
  }

  const files = readdirSync(imagesDir)
    .filter((f) => /^[a-f0-9]{64}\.webp$/.test(f))
    .sort();
  console.log(`local content-addressed images: ${files.length}`);

  let copied = 0;
  let present = 0;
  let verified = 0;
  const failures: string[] = [];

  for (const f of files) {
    const key = `images/${f}`;
    const existing = await store.stat(key);
    if (existing !== null) {
      present++;
      continue;
    }
    if (DRY_RUN) {
      copied++;
      continue;
    }
    const bytes = readFileSync(join(imagesDir, f));
    await store.put(key, bytes);
    /* the proof: re-read through the driver and re-hash */
    const back = await store.get(key);
    const digest = back !== null ? createHash("sha256").update(back).digest("hex") : null;
    if (back === null || digest !== f.replace(/\.webp$/, "")) {
      failures.push(f);
      console.error(`  ✗ ${f}: read-back verification FAILED (got ${digest?.slice(0, 12) ?? "null"}…)`);
      continue;
    }
    verified++;
    copied++;
  }

  console.log(
    DRY_RUN
      ? `dry run — would copy ${copied}, already present ${present}`
      : `done — copied ${copied} (verified read-back ${verified}), already present ${present}`
  );
  if (failures.length > 0) {
    console.error(`\nABORT: ${failures.length} object(s) failed read-back verification:`);
    for (const f of failures) console.error(`  - ${f}`);
    process.exit(1);
  }
}

void main().catch((error) => {
  console.error(error instanceof Error ? error.message : error);
  process.exit(1);
});
