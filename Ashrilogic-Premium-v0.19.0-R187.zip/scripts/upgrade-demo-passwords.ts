/** Round-35 one-off: upgrade remaining demo-password SHA-256 digests to Argon2id. */
import { createHash } from "node:crypto";
import { PrismaClient } from "@prisma/client";
import { hashPasswordArgon2id, isLegacyPasswordHash } from "../src/lib/server/crypto-vault";

const db = new PrismaClient();
const DEMO = "ashrilogic2024";
const demoLegacy = createHash("sha256").update(DEMO, "utf8").digest("hex");

async function main() {
  const cust = await db.siteCustomer.findMany({ select: { id: true, passwordHash: true } });
  let n = 0;
  for (const c of cust) {
    if (isLegacyPasswordHash(c.passwordHash) && c.passwordHash === demoLegacy) {
      await db.siteCustomer.update({ where: { id: c.id }, data: { passwordHash: hashPasswordArgon2id(DEMO) } });
      n++;
    }
  }
  console.log(`SiteCustomer passwords upgraded: ${n}/${cust.length}`);

  const inst = await db.instance.findMany({ select: { id: true, passwordHash: true } });
  n = 0;
  for (const i of inst) {
    if (i.passwordHash && isLegacyPasswordHash(i.passwordHash) && i.passwordHash === demoLegacy) {
      await db.instance.update({ where: { id: i.id }, data: { passwordHash: hashPasswordArgon2id(DEMO) } });
      n++;
    }
  }
  console.log(`Instance passwords upgraded: ${n}/${inst.length}`);
}
main().finally(() => db.$disconnect());
