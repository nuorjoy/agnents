// Ashrilogic — ROUND 171 one-shot codeKey backfill.
//
// Populates ModuleRecord.codeKey for every LIVE row from its dataJson +
// the module preset's id column (the DB-enforced unique-code law's key).
// Trashed rows stay NULL by design (the trash engine nulls the key on
// soft-delete; restore re-derives it).
//
// LEGACY DUPLICATES: rows whose (instanceId, moduleId, codeKey) group has
// more than one member are REPORTED and left NULL — the unique index stays
// satisfiable; those legacy codes remain unprotected until the operator
// resolves them (the report lists every duplicate group). Idempotent: rows
// that already carry a codeKey are skipped.
//
// Usage:
//   DATABASE_URL="postgresql://…" bun scripts/backfill-record-codekey.ts [--apply]
// Without --apply the script is a DRY RUN (report only).

import { PrismaClient } from "@prisma/client";
import { modulePreset } from "../src/lib/module-data";
import { deriveRecordCodeKey } from "../src/lib/record-code";

const db = new PrismaClient();
const APPLY = process.argv.includes("--apply");

interface Planned {
  id: string;
  instanceId: string;
  moduleId: string;
  codeKey: string;
}

async function main(): Promise<void> {
  const url = (process.env.DATABASE_URL ?? "(default)").replace(/\/\/[^@]*@/, "//***@");
  console.log(`${APPLY ? "APPLYING" : "DRY RUN (use --apply to write)"} ModuleRecord.codeKey backfill → ${url}`);

  const instances = await db.instance.findMany({ select: { id: true, systemId: true } });
  const systemOf = new Map(instances.map((i) => [i.id, i.systemId]));

  /* pass 1 — walk every live row lacking a codeKey, derive its key */
  const planned: Planned[] = [];
  let scanned = 0;
  let noIdColumn = 0;
  let emptyCode = 0;
  let parseFailures = 0;

  const PAGE = 1000;
  let cursor: string | null = null;
  for (;;) {
    const rows: {
      id: string;
      instanceId: string;
      moduleId: string;
      dataJson: string;
    }[] = await db.moduleRecord.findMany({
      where: { deletedAt: null, codeKey: null },
      select: { id: true, instanceId: true, moduleId: true, dataJson: true },
      ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
      orderBy: { id: "asc" },
      take: PAGE,
    });
    if (rows.length === 0) break;
    cursor = rows[rows.length - 1].id;

    for (const row of rows) {
      scanned += 1;
      let values: string[];
      try {
        const parsed = JSON.parse(row.dataJson) as unknown;
        if (!Array.isArray(parsed)) throw new Error("not an array");
        values = parsed as string[];
      } catch {
        parseFailures += 1;
        continue;
      }
      const preset = modulePreset(row.moduleId, systemOf.get(row.instanceId));
      const idIndex = preset.cols.findIndex((c) => c.kind === "id");
      if (idIndex < 0) {
        noIdColumn += 1;
        continue;
      }
      const key = deriveRecordCodeKey(values, idIndex);
      if (key === null) {
        emptyCode += 1;
        continue;
      }
      planned.push({ id: row.id, instanceId: row.instanceId, moduleId: row.moduleId, codeKey: key });
    }
  }

  /* pass 2 — duplicate groups keep ALL their rows NULL (the constraint
   * stays satisfiable; the operator resolves legacy duplicates manually) */
  const groups = new Map<string, Planned[]>();
  for (const p of planned) {
    const k = `${p.instanceId}|${p.moduleId}|${p.codeKey}`;
    const arr = groups.get(k) ?? [];
    arr.push(p);
    groups.set(k, arr);
  }
  const conflicts: Planned[] = [];
  const safe: Planned[] = [];
  for (const [composite, members] of groups) {
    if (members.length > 1) {
      const [instanceId, moduleId, codeKey] = composite.split("|");
      console.warn(
        `DUPLICATE CODE (left NULL — resolve manually): instance=${instanceId} module=${moduleId} code="${codeKey}" rows=${members.length}`
      );
      conflicts.push(...members);
    } else {
      safe.push(...members);
    }
  }

  console.log(
    `scanned ${scanned} · backfillable ${safe.length} · duplicate-rows(left NULL) ${conflicts.length} · no-id-column ${noIdColumn} · empty-code ${emptyCode} · parse-failures ${parseFailures}`
  );

  if (!APPLY) {
    console.log("dry run complete — no rows written");
    return;
  }

  /* pass 3 — write per row (bounded, idempotent: only NULL keys on live
   * rows are ever written) */
  let written = 0;
  for (const p of safe) {
    try {
      await db.$executeRawUnsafe(
        `UPDATE "ModuleRecord" SET "codeKey" = $1 WHERE "id" = $2 AND "codeKey" IS NULL AND "deletedAt" IS NULL`,
        p.codeKey,
        p.id
      );
      written += 1;
    } catch (err) {
      console.error(`failed row ${p.id}:`, err instanceof Error ? err.message : err);
    }
  }
  console.log(`backfilled ${written} row(s)`);
}

main()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
