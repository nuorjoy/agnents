#!/usr/bin/env bun
/**
 * Ashrilogic — one-time SQLite → PostgreSQL data importer.
 *
 * PURPOSE: migrate the DATA of a legacy SQLite deployment (the pre-cutover
 * architecture) into the platform's PostgreSQL database. PostgreSQL is the
 * only engine; this tool exists exactly once per deployment and never
 * touches the application runtime.
 *
 * CONTRACT (operator runbook):
 *   1. The PostgreSQL schema must ALREADY exist — `bun run db:deploy`
 *      (prisma migrate deploy) against the target DATABASE_URL. The
 *      importer verifies every source table exists in the target and
 *      aborts otherwise (it never creates or mutates schema).
 *   2. The legacy SQLite file is opened READ-ONLY — the source is never
 *      modified and remains the rollback artifact. Stop the application
 *      (and any writer) before exporting; a hot -wal sidecar is detected
 *      and warned about.
 *   3. The target must be EMPTY (every business table 0 rows) unless
 *      --truncate is passed explicitly, which wipes the target business
 *      tables in FK-reverse order inside ONE transaction first. The
 *      destructive path is opt-in, loud, and still guarded.
 *   4. Data transfer is per-table transactional: a failure aborts the
 *      whole import (non-zero exit) — partial imports are never silently
 *      presented as success. Rows that cannot be type-converted are
 *      collected, reported with table+id+reason, and FAIL the import
 *      (no silent drops, ever).
 *   5. Validation runs after the copy: per-table row counts, orphan
 *      checks for every foreign key, and the critical-record invariants
 *      (admin accounts, platform settings). Every discrepancy is
 *      reported; any discrepancy fails the import.
 *
 * TYPE CONVERSION (SQLite loose typing → PostgreSQL strict):
 *   Prisma's SQLite driver stores DateTime as ms-since-epoch integers and
 *   Boolean as 0/1 integers. The target column types (from the PG
 *   catalog) drive conversion:
 *     boolean   ← 0/1 (number), true/false, "0"/"1"/"true"/"false"
 *     timestamp ← ms-epoch number, or ISO string (defensive: never
 *                 written by Prisma, accepted for hand-maintained files)
 *     int/bigint← integer (NaN/Infinity rejected)
 *     text      ← string (numbers stringified only for legacy tolerance)
 *
 * CONTROLLER TABLES: MigrationEvent, MigrationEventSeal, MigrationState,
 * MigrationProbe (the deleted SQLite→PG cutover control plane) are skipped
 * by design — they were migration infrastructure, never application data.
 *
 * USAGE:
 *   DATABASE_URL='postgresql://…' \
 *   LEGACY_SQLITE_PATH='./db/custom.db' \
 *   bun run migrate:sqlite [--truncate] [--batch-size 500] [--dry-run]
 *
 * EXIT CODES: 0 success · 1 validation/transfer failure · 2 configuration
 * error (source missing, schema absent, target non-empty).
 */

import { existsSync } from "node:fs";
import { resolve } from "node:path";
import pg from "pg";

/* ---------------------------------------------------------------- options */

const args = process.argv.slice(2);
const DRY_RUN = args.includes("--dry-run");
const TRUNCATE = args.includes("--truncate");
const BATCH_SIZE = (() => {
  const i = args.indexOf("--batch-size");
  const v = i >= 0 ? Number(args[i + 1]) : 500;
  return Number.isInteger(v) && v > 0 && v <= 5000 ? v : 500;
})();

/** Legacy cutover control-plane tables — never application data. */
const CONTROLLER_TABLES = new Set([
  "MigrationEvent",
  "MigrationEventSeal",
  "MigrationState",
  "MigrationProbe",
]);

/** Prisma's migration bookkeeping — never application data; it legitimately
 *  holds rows after `migrate deploy` and must not fail the emptiness gate. */
const PRISMA_INTERNAL = new Set(["_prisma_migrations"]);

interface ImportReport {
  table: string;
  sourceRows: number;
  copiedRows: number;
  skippedColumns: string[];
}

const reports: ImportReport[] = [];
const unmigratable: Array<{ table: string; id: string; column: string; reason: string }> = [];

function fail(code: number, message: string): never {
  console.error(`\n[migrate:sqlite] FATAL: ${message}`);
  process.exit(code);
}

/* ------------------------------------------------------------- source side */

const LEGACY_PATH = (process.env.LEGACY_SQLITE_PATH ?? "./db/custom.db").trim();
const legacyFile = resolve(LEGACY_PATH);
if (!existsSync(legacyFile)) {
  fail(2, `legacy SQLite file not found: ${legacyFile} (set LEGACY_SQLITE_PATH)`);
}
for (const sidecar of [`${legacyFile}-wal`, `${legacyFile}-shm`]) {
  if (existsSync(sidecar)) {
    console.warn(
      `[migrate:sqlite] WARNING: ${sidecar} exists beside the source. A hot WAL may hold committed data this READ-ONLY open cannot see. Stop every writer, let it checkpoint (or copy all three files atomically), then re-run.`
    );
  }
}

const { Database } = await import("bun:sqlite");
const sqlite = new Database(legacyFile, { readonly: true, create: false });

interface SqliteTable {
  name: string;
}
const sourceTables = (
  sqlite
    .query("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
    .all() as SqliteTable[]
).map((t) => t.name);

/* ------------------------------------------------------------- target side */

const DATABASE_URL = (process.env.DATABASE_URL ?? "").trim();
if (!/^postgres(ql)?:\/\//i.test(DATABASE_URL)) {
  fail(2, 'DATABASE_URL must be a PostgreSQL connection string ("postgresql://…")');
}
const client = new pg.Client({ connectionString: DATABASE_URL });
await client.connect();

interface PgColumn {
  column_name: string;
  data_type: string; // information_schema type name
}
interface PgTable {
  table_name: string;
}

/** Target column metadata: table → ordered columns. */
async function targetColumns(): Promise<Map<string, PgColumn[]>> {
  const res = await client.query<{ table_name: string; column_name: string; data_type: string }>(
    `SELECT table_name, column_name, data_type
       FROM information_schema.columns
      WHERE table_schema = 'public'
      ORDER BY table_name, ordinal_position`
  );
  const map = new Map<string, PgColumn[]>();
  for (const row of res.rows) {
    const list = map.get(row.table_name) ?? [];
    list.push(row);
    map.set(row.table_name, list);
  }
  return map;
}

/** Foreign-key edges (target catalog) for the copy ordering + validation.
 *  regclass::text quotes mixed-case identifiers ("Instance") — the
 *  quotes are stripped so edges carry plain table names. */
async function targetForeignKeys(): Promise<Array<{ src: string; column: string; ref: string }>> {
  const res = await client.query<{ src: string; column: string; ref: string }>(
    `SELECT trim(both '"' from conrelid::regclass::text) AS src,
           a.attname AS column,
           trim(both '"' from confrelid::regclass::text) AS ref
       FROM pg_constraint c
       JOIN unnest(c.conkey) WITH ORDINALITY AS k(attnum, ord) ON TRUE
       JOIN pg_attribute a ON a.attrelid = c.conrelid AND a.attnum = k.attnum
      WHERE c.contype = 'f' AND connamespace = 'public'::regnamespace
      ORDER BY src, k.ord`
  );
  return res.rows;
}

/** Topological table order (parents before children); cycles abort loudly. */
function topoSort(tables: string[], fks: Array<{ src: string; ref: string }>): string[] {
  const present = new Set(tables);
  const deps = new Map<string, Set<string>>();
  for (const t of tables) deps.set(t, new Set());
  for (const { src, ref } of fks) {
    if (present.has(src) && present.has(ref) && src !== ref) deps.get(src)!.add(ref);
  }
  const ordered: string[] = [];
  const done = new Set<string>();
  let progressed = true;
  while (ordered.length < tables.length && progressed) {
    progressed = false;
    for (const t of tables) {
      if (done.has(t)) continue;
      const pending = [...deps.get(t)!].filter((d) => !done.has(d));
      if (pending.length === 0) {
        ordered.push(t);
        done.add(t);
        progressed = true;
      }
    }
  }
  if (ordered.length < tables.length) {
    const cycle = tables.filter((t) => !done.has(t));
    fail(1, `foreign-key cycle detected among tables: ${cycle.join(", ")} — refusing to guess an order`);
  }
  return ordered;
}

const columnsByTable = await targetColumns();

/* --------------------------------------------------------- preflight gates */

const applicable = sourceTables.filter((t) => !CONTROLLER_TABLES.has(t));
const missingInTarget = applicable.filter((t) => !columnsByTable.has(t));
if (missingInTarget.length > 0) {
  fail(
    2,
    `target schema is missing tables present in the source: ${missingInTarget.join(", ")}. Run \`bun run db:deploy\` against the target first (prisma migrate deploy).`
  );
}
console.log(
  `[migrate:sqlite] source: ${applicable.length} application tables (${sourceTables.length - applicable.length} controller/internal tables skipped)`
);

const businessTargets = [...columnsByTable.keys()].filter(
  (t) => !PRISMA_INTERNAL.has(t)
);
const nonEmpty: string[] = [];
for (const t of businessTargets) {
  const { rows } = await client.query<{ n: string }>(`SELECT COUNT(*)::text AS n FROM "${t}"`);
  if (rows[0].n !== "0") nonEmpty.push(`${t}(${rows[0].n})`);
}
if (nonEmpty.length > 0 && !TRUNCATE) {
  fail(
    2,
    `target is not empty: ${nonEmpty.join(", ")}. Refusing to mix imports. Wipe the target (prisma migrate reset) or re-run with --truncate to clear business tables first (destructive, opt-in).`
  );
}

/* ----------------------------------------------------------- type plumbing */

type SqliteValue = string | number | bigint | Uint8Array | null;

/** Discriminated conversion failure — recorded, never silently dropped. */
class CellConversionError extends Error {}

/** Convert one SQLite cell to the PostgreSQL parameter for the target
 *  type. Throws CellConversionError on any value that cannot be
 *  represented — the caller records it and fails the import. */
function convert(
  table: string,
  column: string,
  pgType: string,
  value: SqliteValue,
  rowId: string
): string | number | boolean | Date | null {
  if (value === null || value === undefined) return null;
  const t = pgType.toLowerCase();
  /* explicit never annotation — required for the never-returning-call
   * control-flow narrowing below (TS only honors calls whose declaration
   * carries the annotation) */
  const bad: (reason: string) => never = (reason) => {
    unmigratable.push({ table, id: rowId, column, reason });
    throw new CellConversionError(`${table}[id=${rowId}].${column}: ${reason}`);
  };
  if (t === "boolean") {
    if (typeof value === "boolean") return value;
    if (typeof value === "number") {
      if (value === 0) return false;
      if (value === 1) return true;
      bad(`boolean column holds ${value}`);
    }
    if (value === "0" || value === "false") return false;
    if (value === "1" || value === "true") return true;
    bad(`boolean column holds "${String(value)}"`);
  }
  if (t.includes("timestamp")) {
    let ms: number | null = null;
    if (typeof value === "number" && Number.isFinite(value)) ms = value;
    else if (typeof value === "bigint") ms = Number(value);
    else if (typeof value === "string") {
      if (/^-?\d+$/.test(value)) ms = Number(value);
      else {
        const parsed = Date.parse(value);
        if (!Number.isNaN(parsed)) ms = parsed;
      }
    }
    if (ms === null || Number.isNaN(new Date(ms).getTime())) {
      bad(`timestamp column holds "${String(value)}"`);
    }
    return new Date(ms as number);
  }
  if (t === "smallint" || t === "integer" || t === "bigint" || t === "numeric") {
    const n =
      typeof value === "number"
        ? value
        : typeof value === "bigint"
          ? Number(value)
          : typeof value === "string" && /^-?\d+(\.\d+)?$/.test(value)
            ? Number(value)
            : NaN;
    if (!Number.isFinite(n)) bad(`integer column holds "${String(value)}"`);
    return n;
  }
  /* text and everything else */
  if (typeof value === "string") return value;
  if (typeof value === "number" || typeof value === "bigint") return String(value);
  bad("unsupported binary value in text column");
}

/* ------------------------------------------------------------ the transfer */

const fks = await targetForeignKeys();
const order = topoSort(businessTargets, fks);
const BATCH = BATCH_SIZE;

async function copyTable(table: string): Promise<void> {
  const targetCols = columnsByTable.get(table)!;
  const targetColNames = targetCols.map((c) => c.column_name);
  const typeByName = new Map(targetCols.map((c) => [c.column_name, c.data_type]));

  const tableInfo = sqlite.query(`PRAGMA table_info("${table}")`).all() as Array<{ name: string }>;
  const sourceColNames = tableInfo.map((c) => c.name);
  const shared = targetColNames.filter((c) => sourceColNames.includes(c));
  const skippedColumns = targetColNames.filter((c) => !sourceColNames.includes(c));
  if (shared.length === 0) {
    reports.push({ table, sourceRows: 0, copiedRows: 0, skippedColumns });
    return;
  }

  const sourceRows = (
    sqlite.query(`SELECT COUNT(*) AS n FROM "${table}"`).get() as { n: number }
  ).n;
  if (sourceRows === 0) {
    reports.push({ table, sourceRows: 0, copiedRows: 0, skippedColumns });
    return;
  }

  const idColumn = sourceColNames.includes("id") ? "id" : sourceColNames[0];
  const stmt = sqlite.query(`SELECT ${shared.map((c) => `"${c}"`).join(", ")} FROM "${table}"`);
  const colList = shared.map((c) => `"${c}"`).join(", ");

  /** Multi-row INSERT for a batch: placeholders are laid out PER ROW —
   *  VALUES ($1..$k), ($k+1..$2k), … — matching the flattened args. */
  const insertSql = (rows: number): string => {
    const k = shared.length;
    const tuples: string[] = [];
    for (let r = 0; r < rows; r++) {
      tuples.push(`(${shared.map((_, i) => `$${r * k + i + 1}`).join(", ")})`);
    }
    return `INSERT INTO "${table}" (${colList}) VALUES ${tuples.join(", ")}`;
  };

  let copied = 0;
  if (!DRY_RUN) {
    await client.query("BEGIN");
    try {
      const batch: unknown[][] = [];
      const flush = async (): Promise<void> => {
        if (batch.length === 0) return;
        const args: unknown[] = [];
        for (const row of batch) args.push(...row);
        await client.query(insertSql(batch.length), args);
        copied += batch.length;
        batch.length = 0;
      };
      for (const raw of stmt.iterate() as IterableIterator<Record<string, SqliteValue>>) {
        const rowId = String(raw[idColumn] ?? "?");
        const params: Array<string | number | boolean | Date | null> = [];
        let broken = false;
        for (const col of shared) {
          try {
            params.push(convert(table, col, typeByName.get(col) ?? "text", raw[col] ?? null, rowId));
          } catch (error) {
            if (error instanceof CellConversionError) {
              broken = true;
              break;
            }
            throw error;
          }
        }
        if (broken) continue;
        batch.push(params);
        if (batch.length >= BATCH) await flush();
      }
      await flush();
      await client.query("COMMIT");
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    }
  } else {
    for (const raw of stmt.iterate() as IterableIterator<Record<string, SqliteValue>>) {
      const rowId = String(raw[idColumn] ?? "?");
      let broken = false;
      for (const col of shared) {
        try {
          convert(table, col, typeByName.get(col) ?? "text", raw[col] ?? null, rowId);
        } catch (error) {
          if (error instanceof CellConversionError) {
            broken = true;
            break;
          }
          throw error;
        }
      }
      if (!broken) copied += 1;
    }
  }
  reports.push({ table, sourceRows, copiedRows: copied, skippedColumns });
}

/* ------------------------------------------------------- truncate (opt-in) */

if (TRUNCATE && !DRY_RUN) {
  const reverse = [...order].reverse();
  await client.query("BEGIN");
  try {
    await client.query("SET LOCAL session_replication_role = replica");
    for (const t of reverse) {
      await client.query(`DELETE FROM "${t}"`);
    }
    await client.query("COMMIT");
    console.log(`[migrate:sqlite] --truncate: cleared ${reverse.length} target tables`);
  } catch (error) {
    await client.query("ROLLBACK");
    fail(1, `truncate failed: ${(error as Error).message}`);
  }
}

/* ----------------------------------------------------------------- execute */

console.log(
  `[migrate:sqlite] ${DRY_RUN ? "DRY RUN — validating conversions only, no writes" : `copying in FK order (batch ${BATCH})`}`
);
const failed: string[] = [];
for (const table of order) {
  if (!applicable.includes(table)) {
    /* table exists only in the target schema — nothing to import */
    reports.push({ table, sourceRows: 0, copiedRows: 0, skippedColumns: [] });
    continue;
  }
  try {
    await copyTable(table);
  } catch (error) {
    failed.push(`${table}: ${(error as Error).message}`);
  }
}

/* -------------------------------------------------------------- validation */

let validationFailures = 0;
console.log("\n=== VALIDATION ===");
if (unmigratable.length > 0) {
  validationFailures += unmigratable.length;
  console.error(`UNMIGRATABLE ROWS (${unmigratable.length}) — NOTHING was silently dropped:`);
  for (const u of unmigratable.slice(0, 50)) {
    console.error(`  ${u.table}[id=${u.id}].${u.column}: ${u.reason}`);
  }
  if (unmigratable.length > 50) console.error(`  … and ${unmigratable.length - 50} more`);
}
if (failed.length > 0) {
  console.error(`TRANSFER FAILURES (${failed.length}):`);
  for (const f of failed) console.error(`  ${f}`);
}

for (const r of reports) {
  const mark = r.sourceRows === r.copiedRows ? "OK " : "!! ";
  if (mark === "!! ") validationFailures++;
  console.log(
    `${mark}${r.table}: source=${r.sourceRows} copied=${r.copiedRows}${r.skippedColumns.length ? ` (newer target-only columns defaulted: ${r.skippedColumns.join(",")})` : ""}`
  );
}

if (!DRY_RUN) {
  /* orphan checks — every FK edge in the target */
  for (const { src, column, ref } of fks) {
    const { rows } = await client.query<{ n: string }>(
      `SELECT COUNT(*)::text AS n FROM "${src}" s
        LEFT JOIN "${ref}" r ON r."id" = s."${column}"
       WHERE s."${column}" IS NOT NULL AND r."id" IS NULL`
    );
    if (rows[0].n !== "0") {
      validationFailures++;
      console.error(`!! ORPHANS: ${src}.${column} → ${ref}: ${rows[0].n} dangling references`);
    }
  }
  /* critical records */
  const { rows: adminRows } = await client.query<{ n: string }>(`SELECT COUNT(*)::text AS n FROM "AdminUser"`);
  const { rows: settingRows } = await client.query<{ n: string }>(`SELECT COUNT(*)::text AS n FROM "PlatformSetting"`);
  const sourceAdmins = (sqlite.query(`SELECT COUNT(*) AS n FROM "AdminUser"`).get() as { n: number }).n;
  const sourceSettings = (sqlite.query(`SELECT COUNT(*) AS n FROM "PlatformSetting"`).get() as { n: number }).n;
  console.log(
    `CRITICAL: AdminUser target=${adminRows[0].n} source=${sourceAdmins} · PlatformSetting target=${settingRows[0].n} source=${sourceSettings}`
  );
  if (adminRows[0].n !== String(sourceAdmins) || settingRows[0].n !== String(sourceSettings)) {
    validationFailures++;
    console.error("!! CRITICAL RECORD COUNT MISMATCH — admin accounts / platform settings did not migrate 1:1");
  }
}

await client.end();
sqlite.close();

if (failed.length > 0 || validationFailures > 0) {
  fail(
    1,
    `${failed.length} transfer failure(s), ${validationFailures} validation failure(s) — target may be PARTIAL; inspect the report above, fix the source, truncate the target, and re-run`
  );
}
console.log(
  `\n[migrate:sqlite] ${DRY_RUN ? "dry run" : "import"} COMPLETE — all tables validated OK. The legacy SQLite file was never modified.`
);
