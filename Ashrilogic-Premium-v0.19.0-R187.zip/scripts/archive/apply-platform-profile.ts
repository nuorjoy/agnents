/**
 * One-off migration: apply the round-41 platform profile updates to the
 * LIVE dev database (matching the updated seed constants):
 *
 *  1. Super admin ("admin") identity — نورالدين عثمان, 1994-05-21, male,
 *     Khartoum — Sudan (address sealed at rest like every admin address).
 *  2. PlatformSetting — dedicated support/WhatsApp phone +249912179779 and
 *     the social-links state reset so only X / Facebook / Instagram /
 *     WhatsApp are visible by default (the rest require manual enabling).
 *
 * Idempotent: safe to re-run.
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main(): Promise<void> {
  const { encryptField } = await import("@/lib/server/crypto-vault");

  /* 1 — super admin profile */
  const admin = await db.adminUser.findUnique({ where: { username: "admin" } });
  if (!admin) {
    console.log("no 'admin' row found — nothing to update (fresh DB will seed the new profile)");
  } else {
    await db.adminUser.update({
      where: { id: admin.id },
      data: {
        name: "نورالدين عثمان",
        gender: "male",
        birthDate: new Date("1994-05-21T00:00:00Z"),
        address: encryptField("الخرطوم — السودان") ?? null,
      },
    });
    console.log("super admin profile updated → نورالدين عثمان · 1994-05-21 · male · الخرطوم — السودان");
  }

  /* 2 — platform settings (phone + social defaults) */
  const settings = await db.platformSetting.findFirst();
  if (settings) {
    await db.platformSetting.update({
      where: { id: settings.id },
      data: {
        supportPhone: "+249912179779",
        /* empty string = "use the canonical defaults" → only the 4 primary
           networks visible; the rest need manual enabling from the panel */
        socialJson: "",
      },
    });
    console.log("platform settings updated → phone +249912179779 · social links reset to defaults");
  } else {
    console.log("no PlatformSetting row — defaults apply on first seed");
  }
}

main()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
