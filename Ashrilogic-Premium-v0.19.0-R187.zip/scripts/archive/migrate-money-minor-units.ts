// Ashrilogic — one-shot money migration: SiteOrder rows → integer minor units.
//
// Pre-round-37 rows stored `total` as a (truncated) display-unit float inside
// the Int column and itemsJson as a bare array of display floats. This script
// rewrites every legacy row to the v2 snapshot shape ({ v: 2, items: [...] }
// with integer minor-unit prices) and recomputes `total` in minor units from
// the item snapshot (falling back to total × 100 for malformed snapshots).
//
// Idempotent: v2 rows are detected and skipped, so re-running is safe.
// Run once during deployment: `bun scripts/migrate-money-minor-units.ts`

import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const MINOR_PER_MAJOR = 100;

interface LegacyItem {
  recordId?: unknown;
  name?: unknown;
  price?: unknown;
  qty?: unknown;
}

async function main(): Promise<void> {
  const rows = await db.siteOrder.findMany({
    select: { id: true, itemsJson: true, total: true },
  });
  let migrated = 0;
  let skipped = 0;
  let repairedTotal = 0;

  for (const row of rows) {
    let parsed: unknown;
    try {
      parsed = JSON.parse(row.itemsJson ?? "[]");
    } catch {
      parsed = null;
    }
    // v2 rows are already in minor units — nothing to do
    if (
      parsed &&
      typeof parsed === "object" &&
      !Array.isArray(parsed) &&
      (parsed as { v?: unknown }).v === 2
    ) {
      skipped++;
      continue;
    }

    let totalMinor: number;
    const items: { recordId: string; name: string; price: number; qty: number }[] = [];
    if (Array.isArray(parsed)) {
      for (const it of parsed as LegacyItem[]) {
        if (
          it &&
          typeof it.recordId === "string" &&
          typeof it.name === "string" &&
          typeof it.price === "number" &&
          typeof it.qty === "number"
        ) {
          items.push({
            recordId: it.recordId,
            name: it.name,
            price: Math.round(it.price * MINOR_PER_MAJOR),
            qty: it.qty,
          });
        }
      }
    }
    if (items.length > 0) {
      totalMinor = items.reduce((sum, it) => sum + it.price * it.qty, 0);
    } else {
      // malformed snapshot — salvage from the stored (truncated) total
      totalMinor = Math.round(row.total * MINOR_PER_MAJOR);
      repairedTotal++;
    }

    await db.siteOrder.update({
      where: { id: row.id },
      data: {
        itemsJson: JSON.stringify({ v: 2, items }),
        total: totalMinor,
      },
    });
    migrated++;
  }

  console.log(
    `money migration complete: ${migrated} row(s) migrated, ${skipped} already v2` +
      (repairedTotal ? `, ${repairedTotal} repaired from stored total` : "")
  );
}

main()
  .then(() => db.$disconnect())
  .catch(async (error) => {
    console.error("money migration failed:", error);
    await db.$disconnect();
    process.exit(1);
  });
