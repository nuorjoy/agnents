# One-shot data migrations from previous Ashrilogic generations.
#
# Every script here is IDEMPOTENT and was ALREADY APPLIED to the shipped
# databases (db/custom.db carries their effects). They are retained for
# archaeological/audit purposes only — running them again is a no-op, but
# they are NOT part of any workflow and are excluded from package.json.
#
# For live operations see:
#   scripts/pg-migrate.ts      — SQLite → PostgreSQL migration controller
#   scripts/platform-restore.ts — platform snapshot recovery
#   scripts/verify-audit-chain.ts — audit tamper-evidence verifier
#   scripts/migrate-images.ts moved back to scripts/ — the security suite
#     (tests/security/image-store.test.ts) imports it as a live dependency
