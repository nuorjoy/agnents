// Ashrilogic — one-shot instance PII backfill.
//
// Seals the workspace login email inside Instance.adminJson (AES-256-GCM
// envelope) and backfills the HMAC blind index (adminEmailIndex) for every
// legacy row — plaintext rows converge to the sealed-at-rest form while the
// read path keeps working for both shapes (decryptField passes legacy
// plaintext through).
//
// Idempotent: rows whose adminJson email already carries the enc:v1: marker
// (or whose index already matches) are skipped.
// Run once during deployment: `bun scripts/backfill-instance-pii.ts`

import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main(): Promise<void> {
  const { encryptField, blindIndex, isSealedField } = await import(
    "@/lib/server/crypto-vault"
  );

  const rows = await db.instance.findMany({
    select: { id: true, adminJson: true, adminEmailIndex: true },
  });
  let sealed = 0;
  let indexed = 0;
  let skipped = 0;

  for (const row of rows) {
    let admin: { name?: string; email?: string; role?: string; twoFA?: boolean } = {};
    try {
      admin = JSON.parse(row.adminJson ?? "{}");
    } catch {
      /* corrupt adminJson — nothing to seal */
    }
    const email = (admin.email ?? "").trim().toLowerCase();
    const updates: { adminJson?: string; adminEmailIndex?: string } = {};

    if (email && !isSealedField(email)) {
      updates.adminJson = JSON.stringify({ ...admin, email: encryptField(email) ?? "" });
    }
    const expectedIndex = email ? (blindIndex(email) ?? "") : "";
    if (expectedIndex && row.adminEmailIndex !== expectedIndex) {
      updates.adminEmailIndex = expectedIndex;
    }

    if (Object.keys(updates).length === 0) {
      skipped++;
      continue;
    }
    await db.instance.update({ where: { id: row.id }, data: updates });
    if (updates.adminJson) sealed++;
    if (updates.adminEmailIndex) indexed++;
  }

  console.log(
    `instance PII backfill complete: ${sealed} email(s) sealed, ${indexed} index(es) backfilled, ${skipped} row(s) already current`
  );
}

main()
  .then(() => db.$disconnect())
  .catch(async (error) => {
    console.error("instance PII backfill failed:", error);
    await db.$disconnect();
    process.exit(1);
  });
