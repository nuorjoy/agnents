/**
 * Ashrilogic — round-36 one-off backfill: workspace admin-email blind index.
 *
 * Backfills Instance.adminEmailIndex (HMAC-SHA256 blind index of the
 * lower-cased adminJson email) for every row where it is NULL, so the
 * server-side login resolver (/api/instances/auth/login) and the
 * authenticated my-systems listing (/api/instances/mine) can look workspaces
 * up by owner email without ever exposing the instance directory publicly.
 *
 * Idempotent: rows with a non-null adminEmailIndex are skipped.
 *
 * Usage: bun run scripts/backfill-admin-email-index.ts
 */
import { PrismaClient } from "@prisma/client";
import { blindIndex } from "../src/lib/server/crypto-vault";

const db = new PrismaClient();

async function main() {
  const rows = await db.instance.findMany({
    select: { id: true, adminJson: true, adminEmailIndex: true },
  });
  let updated = 0;
  for (const row of rows) {
    if (row.adminEmailIndex) continue;
    let email = "";
    try {
      const admin = JSON.parse(row.adminJson ?? "{}") as { email?: string };
      email = (admin.email ?? "").trim().toLowerCase();
    } catch {
      /* corrupt adminJson — indexed as empty */
    }
    await db.instance.update({
      where: { id: row.id },
      data: { adminEmailIndex: blindIndex(email) ?? "" },
    });
    updated += 1;
  }
  console.log(`adminEmailIndex backfill complete: ${updated}/${rows.length} rows updated`);
}

main()
  .catch((error) => {
    console.error("backfill failed:", error);
    process.exitCode = 1;
  })
  .finally(() => db.$disconnect());
