// Ashrilogic — ROUND 54 order-snapshot image backfill (one-off, idempotent).
//
// Existing v2 order snapshots (created before round 54) carry no `image`
// field — the guest-tracking timeline and the owner order queue therefore
// render the themed initial tile for them. This script walks every v2
// snapshot, resolves each item's CURRENT record imageRef (validated by the
// shared managed-ref shape guard) and stamps it into the stored snapshot —
// historic orders become visual retroactively.
//
//   DATABASE_URL="file:/absolute/path/to/db/custom.db" \
//     bun scripts/backfill-order-images.ts
//
// Rules:
//  - v1 legacy rows are left untouched (their shape stays display-floats);
//  - malformed snapshots are skipped (the parser's empty-items verdict);
//  - items whose record no longer exists / has no photo keep no image;
//  - re-running is a no-op once every snapshot is stamped.

import { PrismaClient } from "@prisma/client";
import { parseOrderSnapshot, snapshotImage, type SnapshotItem } from "@/lib/server/order-snapshot";

const db = new PrismaClient();

async function main(): Promise<void> {
  const url = process.env.DATABASE_URL ?? "(default)";
  console.log(`backfilling order-item images → ${url}`);

  const orders = await db.siteOrder.findMany({
    select: { id: true, itemsJson: true, instanceId: true },
  });

  /* record imageRefs keyed per instance (records are instance-scoped) */
  const refCache = new Map<string, string>();
  async function imageOf(instanceId: string, recordId: string): Promise<string | undefined> {
    const key = `${instanceId}:${recordId}`;
    const cached = refCache.get(key);
    if (cached !== undefined) return cached || undefined;
    const record = await db.moduleRecord.findUnique({
      where: { id: recordId },
      select: { instanceId: true, imageRef: true },
    });
    /* only a record belonging to the SAME instance may stamp the snapshot
       (cross-instance recordId reuse can never leak another store's photo) */
    const ok = record && record.instanceId === instanceId ? snapshotImage(record.imageRef) : undefined;
    refCache.set(key, ok ?? "");
    return ok;
  }

  let updated = 0;
  let scanned = 0;
  for (const order of orders) {
    const parsed = parseOrderSnapshot(order.itemsJson);
    if (parsed.legacy) continue; // v1 rows keep their historical shape
    scanned += 1;

    let dirty = false;
    const items: SnapshotItem[] = [];
    for (const it of parsed.items) {
      if (it.image) {
        items.push(it);
        continue;
      }
      const image = await imageOf(order.instanceId, it.recordId);
      if (image) {
        items.push({ ...it, image });
        dirty = true;
      } else {
        items.push(it);
      }
    }
    if (!dirty) continue;

    await db.siteOrder.update({
      where: { id: order.id },
      data: { itemsJson: JSON.stringify({ v: 2, items }) },
    });
    updated += 1;
  }

  console.log(`done — ${scanned} v2 snapshot(s) scanned, ${updated} updated`);
}

main()
  .catch((err) => {
    console.error(err);
    process.exitCode = 1;
  })
  .finally(() => db.$disconnect());
