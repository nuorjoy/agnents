/**
 * Ashrilogic — round-35 one-off backfill: seal sensitive fields at rest.
 *
 * Runs the field-level encryption migration over every existing row:
 *  - SiteCustomer.email → AES-256-GCM envelope + emailIndex blind index
 *  - SiteCustomer.phone → envelope
 *  - Subscriber.email → envelope + emailIndex
 *  - AdminUser.email → envelope + emailIndex; AdminUser.address → envelope
 *  - TeamMember.email → envelope
 *  - SupportTicket.requesterEmail → envelope + requesterEmailIndex
 *  - Passwords: legacy SHA-256 digests OF THE DOCUMENTED DEMO PASSWORD are
 *    upgraded to Argon2id directly; any other legacy digest stays and
 *    upgrades itself transparently on that account's next login.
 *
 * Idempotent: already-sealed values (enc:v1: marker) and existing blind
 * indexes are skipped, so re-running is a no-op.
 *
 * Usage: bun run scripts/backfill-encryption.ts
 */
import { createHash } from "node:crypto";
import { PrismaClient } from "@prisma/client";
import {
  blindIndex,
  encryptField,
  isSealedField,
  hashPasswordArgon2id,
  isLegacyPasswordHash,
} from "../src/lib/server/crypto-vault";

const db = new PrismaClient();
const DEMO_PASSWORD = "ashrilogic2024";
const demoLegacyHash = createHash("sha256").update(DEMO_PASSWORD, "utf8").digest("hex");

async function main() {
  console.log("→ round-35 encryption backfill starting…");

  /* ------------------------------ SiteCustomer ---------------------------- */
  const customers = await db.siteCustomer.findMany({
    select: { id: true, email: true, phone: true, emailIndex: true },
  });
  let n = 0;
  for (const c of customers) {
    const data: Record<string, string | null> = {};
    if (!isSealedField(c.email)) {
      const plain = c.email;
      data.email = encryptField(plain) ?? "";
      if (!c.emailIndex) data.emailIndex = blindIndex(plain) ?? "";
    }
    if (c.phone && !isSealedField(c.phone)) {
      data.phone = encryptField(c.phone) ?? null;
    }
    if (Object.keys(data).length > 0) {
      await db.siteCustomer.update({ where: { id: c.id }, data });
      n++;
    }
  }
  console.log(`  SiteCustomer: ${n}/${customers.length} rows sealed`);

  /* ------------------------------ Subscriber ------------------------------ */
  const subscribers = await db.subscriber.findMany({
    select: { id: true, email: true, emailIndex: true },
  });
  n = 0;
  for (const s of subscribers) {
    if (isSealedField(s.email)) continue;
    const plain = s.email;
    await db.subscriber.update({
      where: { id: s.id },
      data: {
        email: encryptField(plain) ?? "",
        ...(s.emailIndex ? {} : { emailIndex: blindIndex(plain) ?? "" }),
      },
    });
    n++;
  }
  console.log(`  Subscriber: ${n}/${subscribers.length} rows sealed`);

  /* ------------------------------ AdminUser ------------------------------- */
  const admins = await db.adminUser.findMany({
    select: { id: true, email: true, address: true, emailIndex: true, passwordHash: true },
  });
  n = 0;
  let pw = 0;
  for (const a of admins) {
    const data: Record<string, string | null> = {};
    if (!isSealedField(a.email)) {
      const plain = a.email;
      data.email = encryptField(plain) ?? "";
      if (!a.emailIndex) data.emailIndex = blindIndex(plain) ?? "";
    }
    if (a.address && !isSealedField(a.address)) {
      data.address = encryptField(a.address) ?? null;
    }
    /* demo-password rows upgrade immediately; custom ones wait for login */
    if (isLegacyPasswordHash(a.passwordHash) && a.passwordHash === demoLegacyHash) {
      data.passwordHash = hashPasswordArgon2id(DEMO_PASSWORD);
      pw++;
    }
    if (Object.keys(data).length > 0) {
      await db.adminUser.update({ where: { id: a.id }, data });
      n++;
    }
  }
  console.log(`  AdminUser: ${n}/${admins.length} rows sealed (${pw} demo passwords upgraded to Argon2id)`);

  /* ------------------------------ TeamMember ------------------------------ */
  const members = await db.teamMember.findMany({ select: { id: true, email: true } });
  n = 0;
  for (const m of members) {
    if (isSealedField(m.email)) continue;
    await db.teamMember.update({
      where: { id: m.id },
      data: { email: encryptField(m.email) ?? "" },
    });
    n++;
  }
  console.log(`  TeamMember: ${n}/${members.length} rows sealed`);

  /* ----------------------------- SupportTicket ---------------------------- */
  const tickets = await db.supportTicket.findMany({
    select: { id: true, requesterEmail: true, requesterEmailIndex: true },
  });
  n = 0;
  for (const t of tickets) {
    if (isSealedField(t.requesterEmail)) continue;
    const plain = t.requesterEmail;
    await db.supportTicket.update({
      where: { id: t.id },
      data: {
        requesterEmail: encryptField(plain) ?? "",
        ...(t.requesterEmailIndex ? {} : { requesterEmailIndex: blindIndex(plain) ?? "" }),
      },
    });
    n++;
  }
  console.log(`  SupportTicket: ${n}/${tickets.length} rows sealed`);

  console.log("✓ backfill complete — all sensitive fields are sealed at rest.");
}

main()
  .catch((error) => {
    console.error("backfill failed:", error);
    process.exitCode = 1;
  })
  .finally(() => db.$disconnect());
