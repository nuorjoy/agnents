// Ashrilogic — ROUND 50 one-shot order-tracking backfill.
//
// Converges every existing SiteOrder row onto the tracking model:
//
//   1. `code`   — a short 6-char tracking code (unambiguous alphabet),
//                 unique per workspace, generated with collision retry.
//   2. `phoneIndex` — the keyed HMAC blind index of the guest phone at
//                 placement, recomputed from the SEALED customer phone via
//                 the vault (last-9-digits normalization, identical to the
//                 placement path). Orders whose customer has no phone stay
//                 untrackable (phoneIndex NULL) — by design.
//
// Idempotent: rows that already carry a code are skipped.
// Run once during deployment: `bun scripts/backfill-order-codes.ts`

import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

/** unambiguous alphabet — mirrors src/lib/server/coupons.ts */
const ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";

function randomCode(): string {
  const bytes = new Uint32Array(6);
  crypto.getRandomValues(bytes);
  let out = "";
  for (let i = 0; i < 6; i++) out += ALPHABET[bytes[i]! % ALPHABET.length];
  return out;
}

/** last-9-digits normalization — mirrors normalizePhoneForIndex */
function normalizePhone(raw: string): string {
  const digits = raw.replace(/\D+/g, "");
  return digits.length > 9 ? digits.slice(-9) : digits;
}

async function main(): Promise<void> {
  const { blindIndex, decryptField } = await import("@/lib/server/crypto-vault");

  const pending = await db.siteOrder.findMany({
    where: { code: null },
    select: { id: true, instanceId: true, customerId: true },
    orderBy: { createdAt: "asc" },
  });
  console.log(`orders without a tracking code: ${pending.length}`);

  if (pending.length === 0) {
    console.log("nothing to backfill — every order already trackable");
    return;
  }

  /* cache decrypted customer phones (sealed column — decrypt once) */
  const customerIds = [...new Set(pending.map((o) => o.customerId))];
  const customers = await db.siteCustomer.findMany({
    where: { id: { in: customerIds } },
    select: { id: true, phone: true },
  });
  const phoneById = new Map<string, string | null>();
  for (const c of customers) {
    phoneById.set(c.id, c.phone ? (decryptField(c.phone) ?? null) : null);
  }

  /* existing codes per instance (collision avoidance) */
  const taken = new Set<string>();
  const existing = await db.siteOrder.findMany({
    where: { code: { not: null } },
    select: { instanceId: true, code: true },
  });
  for (const row of existing) taken.add(`${row.instanceId}:${row.code}`);

  let updated = 0;
  let trackable = 0;
  for (const order of pending) {
    let code = randomCode();
    while (taken.has(`${order.instanceId}:${code}`)) code = randomCode();
    taken.add(`${order.instanceId}:${code}`);

    const phone = phoneById.get(order.customerId) ?? null;
    const phoneIdx = phone ? (blindIndex(normalizePhone(phone)) ?? null) : null;

    await db.siteOrder.update({
      where: { id: order.id },
      data: { code, phoneIndex: phoneIdx },
    });
    updated++;
    if (phoneIdx) trackable++;
  }

  console.log(`backfilled ${updated} orders (${trackable} trackable with a phone index)`);
}

main()
  .catch((error) => {
    console.error("backfill failed:", error);
    process.exitCode = 1;
  })
  .finally(() => db.$disconnect());
