// Ashrilogic — unopenable sealed-cell diagnostic (ROUND 104, backlog #3 tooling).
//
// WHY THIS EXISTS: the live-DB dry-run before the key-rotation runbook
// (worklog Task 6) surfaced 12 sealed cells (demo AdminUser emails/addresses,
// SupportTicket requester emails) that authenticate under NO known key —
// sealed pre-extraction under a key that was lost. They fail-soft to "" in
// production, and the re-seal runbook refuses rotation around them unless
// --skip-unopenable is passed. Their disposition was left to the platform
// owner — this script gives the owner the exact, current list whenever they
// want to triage (re-enter the data or clear the cells) so a future REAL
// key rotation needs no escape hatch.
//
// STRICTLY READ-ONLY: SELECT/findMany only — no writes, no leases, no
// VACUUM, no locks. Safe to run while the app is serving (consistent
// snapshot reads). Contrast with re-seal-secrets.ts, which WRITES and
// therefore demands the app stopped + a pre-reseal backup.
//
// WHAT IT REPORTS, per sealed cell that carries the enc:v1: marker:
//   • model + row id + column (or nested JSON path) — never plaintext
//     (there is none to print: the cell does not open);
//   • which keys were tried: the running ASHRILOGIC_DATA_KEY (via the
//     production vault module — identical binding) and, when
//     ASHRILOGIC_OLD_DATA_KEY is set in the shell, that old key too;
//   • a triage recommendation (re-enter the value through its owning
//     surface, or clear the cell) referencing the runbook.
//
// EXIT CODE: 0 always — this is a diagnostic, not a gate. The count is
// printed prominently; operators grep it.
//
// Usage:
//   bun scripts/report-unopenable.ts
//   ASHRILOGIC_OLD_DATA_KEY='<previous key>' bun scripts/report-unopenable.ts

import { createDecipheriv, createHash, hkdfSync } from "node:crypto";
import { db } from "@/lib/db";

/* Read-only diagnostic — the same local-demo env binding the re-seal runbook
 * uses: demo key material is LEGITIMATE for inspection (nothing is written),
 * and the runtime-guard refuses to bind it outside development/test. */
if (!process.env.NODE_ENV) {
  (process.env as { NODE_ENV?: string }).NODE_ENV = "development";
}

const VAULT_MARKER = "enc:v1:";
const INFO_AES = "ashrilogic/field-aes-256-gcm/v1";

/* ------------------------------ key material ------------------------------- */

const OLD_SECRET = process.env.ASHRILOGIC_OLD_DATA_KEY?.trim() ?? "";

function deriveKey(secret: string, info: string): Buffer {
  return Buffer.from(
    hkdfSync("sha256", Buffer.from(secret, "utf8"), Buffer.alloc(0), info, 32)
  );
}

const OLD_AES = OLD_SECRET ? deriveKey(OLD_SECRET, INFO_AES) : null;

function fingerprint(secret: string): string {
  return createHash("sha256").update(secret, "utf8").digest("hex").slice(0, 12);
}

/** Decrypt with an explicit key. THROWS on GCM auth failure — identical
 *  semantics to the re-seal runbook's detector. */
function decryptWithKey(aesKey: Buffer, envelope: string): string {
  const parts = envelope.slice(VAULT_MARKER.length).split(":");
  if (parts.length !== 3) throw new Error("malformed envelope (not 3 segments)");
  const [ivB64, tagB64, ctB64] = parts;
  const decipher = createDecipheriv("aes-256-gcm", aesKey, Buffer.from(ivB64, "base64"));
  decipher.setAuthTag(Buffer.from(tagB64, "base64"));
  const pt = Buffer.concat([decipher.update(Buffer.from(ctB64, "base64")), decipher.final()]);
  return pt.toString("utf8");
}

function isSealed(value: unknown): value is string {
  return typeof value === "string" && value.startsWith(VAULT_MARKER);
}

/* The production vault for the CURRENT key — binds ASHRILOGIC_DATA_KEY (or
 * the documented demo fallback) exactly like the running app process.
 * decryptField returns "" on GCM auth failure, and sealed envelopes never
 * hold empty plaintext (the runbook's documented failure signal). */
const vault = await import("@/lib/server/crypto-vault");

/* ------------------------------ table plan --------------------------------- */
/* Mirrors the re-seal runbook's PLANS topology (single source of truth for
 * what is sealed lives there; any future sealed column must be added to
 * BOTH — the runbook's preflight cross-checks this report at rotation time). */

interface TablePlan {
  model:
    | "siteCustomer"
    | "teamMember"
    | "adminUser"
    | "subscriber"
    | "supportTicket"
    | "mfaSecret"
    | "webhookEndpoint"
    | "instance"
    | "platformSetting";
  label: string;
  /** whole-value sealed columns */
  sealed: string[];
  /** JSON columns that EMBED sealed strings (deep walk) */
  nestedJson: string[];
}

const PLANS: TablePlan[] = [
  { model: "siteCustomer", label: "SiteCustomer", sealed: ["email", "phone"], nestedJson: [] },
  { model: "teamMember", label: "TeamMember", sealed: ["email", "profileJson"], nestedJson: [] },
  { model: "adminUser", label: "AdminUser", sealed: ["email", "address"], nestedJson: [] },
  { model: "subscriber", label: "Subscriber", sealed: ["email"], nestedJson: [] },
  { model: "supportTicket", label: "SupportTicket", sealed: ["requesterEmail"], nestedJson: [] },
  { model: "mfaSecret", label: "MfaSecret", sealed: ["secretSealed"], nestedJson: [] },
  { model: "webhookEndpoint", label: "WebhookEndpoint", sealed: ["secret"], nestedJson: [] },
  { model: "instance", label: "Instance", sealed: [], nestedJson: ["adminJson"] },
  {
    model: "platformSetting",
    label: "PlatformSetting",
    sealed: [],
    /* smtpJson embeds { passwordSealed: "enc:v1:…" } (ROUND 162 coverage
     * fix — mirrors the re-seal runbook) */
    nestedJson: ["aiJson", "newsletterEmailsJson", "smtpJson"],
  },
];

interface Delegate {
  findMany(args: { select: Record<string, boolean> }): Promise<Record<string, unknown>[]>;
}

/* ------------------------------- findings ---------------------------------- */

interface Finding {
  model: string;
  rowId: string;
  field: string; /* column name or column + JSON path */
}

/** Classify one sealed envelope: "current" | "old" | "unopenable". */
function classify(envelope: string): "current" | "old" | "unopenable" {
  /* current key first — the healthy path (production vault semantics) */
  try {
    if (vault.decryptField(envelope) !== "") return "current";
  } catch {
    /* vault never throws for auth failures, but a malformed envelope must
       not abort the scan */
  }
  /* old key (optional) — rotation-pending cells open here */
  if (OLD_AES) {
    try {
      decryptWithKey(OLD_AES, envelope);
      return "old";
    } catch {
      /* fall through */
    }
  }
  return "unopenable";
}

/** Deep-walk a parsed JSON tree for sealed strings. */
function walk(
  node: unknown,
  path: string,
  out: Array<{ path: string; value: string }>
): void {
  if (isSealed(node)) {
    out.push({ path, value: node });
    return;
  }
  if (Array.isArray(node)) {
    node.forEach((item, i) => walk(item, `${path}[${i}]`, out));
    return;
  }
  if (node && typeof node === "object") {
    for (const [k, v] of Object.entries(node as Record<string, unknown>)) {
      walk(v, path ? `${path}.${k}` : k, out);
    }
  }
}

async function main(): Promise<void> {
  const started = Date.now();

  console.log("Ashrilogic — unopenable sealed-cell report (READ-ONLY)");
  console.log("======================================================");
  /* the current key material: ASHRILOGIC_DATA_KEY or the vault's documented
     demo fallback (same binding the production process uses) */
  const currentSecret =
    process.env.ASHRILOGIC_DATA_KEY?.trim() ||
    "ashrilogic-demo-field-encryption-key-rotate-me";
  console.log(`current key: ${fingerprint(currentSecret)} (SHA-256/12)${process.env.ASHRILOGIC_DATA_KEY ? "" : " — DEMO fallback"}`);
  console.log(
    OLD_SECRET
      ? `old key:     ${fingerprint(OLD_SECRET)} (SHA-256/12) — rotation-pending cells will be distinguished`
      : "old key:     (none — set ASHRILOGIC_OLD_DATA_KEY to distinguish rotation-pending cells)"
  );
  console.log("");

  const unopenable: Finding[] = [];
  const pendingOld: Finding[] = [];
  let scannedEnvelopes = 0;

  for (const plan of PLANS) {
    const delegate = (db as unknown as Record<string, Delegate>)[plan.model];
    const cols = new Set(["id", ...plan.sealed, ...plan.nestedJson]);
    const rows = await delegate.findMany({
      select: Object.fromEntries([...cols].map((c) => [c, true])),
    });

    const modelUnopenable: Finding[] = [];
    const modelOld: Finding[] = [];

    for (const row of rows) {
      const rowId = String(row.id);

      for (const col of plan.sealed) {
        const value = row[col];
        if (!isSealed(value)) continue;
        scannedEnvelopes++;
        const verdict = classify(value);
        if (verdict === "unopenable") modelUnopenable.push({ model: plan.label, rowId, field: col });
        else if (verdict === "old") modelOld.push({ model: plan.label, rowId, field: col });
      }

      for (const col of plan.nestedJson) {
        const raw = row[col];
        if (typeof raw !== "string" || raw.length === 0) continue;
        let parsed: unknown;
        try {
          parsed = JSON.parse(raw);
        } catch {
          continue; /* not JSON — not this report's concern */
        }
        const sealedStrings: Array<{ path: string; value: string }> = [];
        walk(parsed, "", sealedStrings);
        for (const s of sealedStrings) {
          scannedEnvelopes++;
          const verdict = classify(s.value);
          const field = s.path ? `${col}.${s.path}` : col;
          if (verdict === "unopenable") modelUnopenable.push({ model: plan.label, rowId, field });
          else if (verdict === "old") modelOld.push({ model: plan.label, rowId, field });
        }
      }
    }

    const total = rows.length;
    console.log(
      `${plan.label.padEnd(16)} rows: ${String(total).padStart(4)}  unopenable: ${modelUnopenable.length}${modelOld.length ? `  opens-with-OLD-only: ${modelOld.length}` : ""}`
    );
    for (const f of modelUnopenable) console.log(`    ✗ ${plan.label} ${f.rowId} · ${f.field}`);
    unopenable.push(...modelUnopenable);
    pendingOld.push(...modelOld);
  }

  console.log("");
  console.log("------------------------------------------------------");
  console.log(`envelopes scanned: ${scannedEnvelopes}`);
  console.log(`UNOPENABLE cells:  ${unopenable.length}`);
  if (pendingOld.length) {
    console.log(`rotation-pending (old-key-only) cells: ${pendingOld.length}`);
  }
  if (unopenable.length === 0) {
    console.log("");
    console.log("✓ every sealed envelope opens with the running key —");
    console.log("  a real key rotation needs no --skip-unopenable escape hatch.");
  } else {
    console.log("");
    console.log("TRIAGE GUIDANCE (disposition belongs to the platform owner):");
    console.log("  • re-enter the value through its owning surface (admin profile,");
    console.log("    ticket contact, member invite) — the new value seals with the");
    console.log("    running key and the cell becomes healthy, OR");
    console.log("  • clear the cell (set it NULL/empty) when the plaintext is");
    console.log("    unrecoverable and the row is disposable.");
    console.log("  Until then, re-seal-secrets.ts refuses rotation around these cells");
    console.log("  unless --skip-unopenable is passed (they stay verbatim).");
  }
  console.log("");
  console.log(`completed in ${Date.now() - started}ms · READ-ONLY — nothing was modified`);
}

try {
  await main();
} finally {
  await db.$disconnect();
}
