/**
 * ROUND 55 — Passkey E2E driver: attaches a WebAuthn VIRTUAL authenticator
 * to the agent-browser Chromium via CDP, then orchestrates the full
 * register → logout → passkey-first-login ceremony on the ADMIN panel.
 *
 * Usage: bun run scripts/e2e-passkey.ts <ws-url>
 */
const WS_URL = process.argv[2];
if (!WS_URL) {
  console.error("usage: bun run scripts/e2e-passkey.ts <cdp-ws-url>");
  process.exit(1);
}

let seq = 0;
const pending = new Map<number, { resolve: (v: unknown) => void; reject: (e: Error) => void }>();

function connect(url: string): Promise<WebSocket> {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(url);
    ws.onopen = () => resolve(ws);
    ws.onerror = () => reject(new Error("ws connect failed: " + url));
  });
}

function call<T = unknown>(
  ws: WebSocket,
  method: string,
  params: Record<string, unknown> = {},
  sessionId?: string
): Promise<T> {
  const id = ++seq;
  return new Promise<T>((resolve, reject) => {
    pending.set(id, { resolve: resolve as (v: unknown) => void, reject });
    const msg: Record<string, unknown> = { id, method, params };
    if (sessionId) msg.sessionId = sessionId;
    ws.send(JSON.stringify(msg));
    setTimeout(() => {
      if (pending.has(id)) {
        pending.delete(id);
        reject(new Error("cdp timeout: " + method));
      }
    }, 15_000);
  });
}

async function main() {
  /* 1 — browser-level websocket: find the page target */
  const browserWs = await connect(WS_URL);
  browserWs.onmessage = (ev: MessageEvent) => {
    try {
      const msg = JSON.parse(String(ev.data)) as { id?: number; result?: unknown; error?: { message: string } };
      if (msg.id && pending.has(msg.id)) {
        const p = pending.get(msg.id)!;
        pending.delete(msg.id);
        if (msg.error) p.reject(new Error(msg.error.message));
        else p.resolve(msg.result);
      }
    } catch { /* ignore events */ }
  };

  const { targetInfos } = await call<{ targetInfos: { targetId: string; url: string; type: string }[] }>(
    browserWs, "Target.getTargets"
  );
  const page = targetInfos.find((t) => t.type === "page" && t.url.includes("localhost:3000"));
  if (!page) throw new Error("no localhost:3000 page target — open the app first");
  console.log("PAGE target:", page.url);

  /* 2 — attach to the page and switch the session to it */
  const { sessionId } = await call<{ sessionId: string }>(browserWs, "Target.attachToTarget", {
    targetId: page.targetId, flatten: true,
  });
  const flatCall = <T = unknown>(method: string, params: Record<string, unknown> = {}) =>
    call<T>(browserWs, method, { ...params, sessionId });

  /* 3 — enable WebAuthn + create the virtual authenticator (session-scoped) */
  await call(browserWs, "WebAuthn.enable", {}, sessionId);
  const { authenticatorId } = await call<{ authenticatorId: string }>(
    browserWs, "WebAuthn.addVirtualAuthenticator", {
      options: {
        protocol: "ctap2",
        transport: "internal",
        hasResidentKey: true,
        hasUserVerification: true,
        isUserVerified: true,
        automaticWebAuthn: true,
      },
    },
    sessionId
  );
  console.log("VIRTUAL AUTHENTICATOR attached:", authenticatorId);

  /* 4 — probe WebAuthn availability inside the page */
  const probe = await call<{ result: { value: unknown } }>(
    browserWs,
    "Runtime.evaluate",
    {
      expression:
        "typeof PublicKeyCredential !== 'undefined' && await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable()",
      awaitPromise: true,
      returnByValue: true,
    },
    sessionId
  );
  console.log("platform authenticator available:", probe.result.value);
  console.log("DRIVER READY — holding the virtual authenticator for 10 minutes");
  /* keep the CDP session (and the virtual authenticator) alive while the
     caller drives the UI through agent-browser's own CDP connection */
  await new Promise((r) => setTimeout(r, 10 * 60 * 1000));
  process.exit(0);
}

main().catch((e: Error) => {
  console.error("E2E-DRIVER-FAIL:", e.message);
  process.exit(1);
});

export {};
