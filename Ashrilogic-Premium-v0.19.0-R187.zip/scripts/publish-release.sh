#!/usr/bin/env bash
# Ashrilogic — ONE-COMMAND GITHUB PUBLISH (ROUND 168).
#
# Pushes the committed main branch to nuorjoy/Ashrilogic (authored as
# nuorjoy <nuooro@gmail.com> — the owner's account, exactly as directed)
# and cuts the GitHub Release with the professional bilingual notes.
# The push itself triggers the vercel[bot] auto-deployment (the documented
# pipeline: push to main → Production).
#
# REQUIRED ENVIRONMENT (never committed — pass per invocation):
#   GITHUB_TOKEN   a GitHub PAT with repo scope for nuorjoy/Ashrilogic
#
# Usage:
#   GITHUB_TOKEN=ghp_… bash scripts/publish-release.sh v0.18.0 R168
#
# The commit is ALREADY in local main (ROUND 168 — 19c3076). This script
# never amends or rewrites history; it only publishes what exists.

set -euo pipefail

die() { echo "PUBLISH ABORTED: $*" >&2; exit 1; }
log() { echo "▸ $*"; }

: "${GITHUB_TOKEN:?GITHUB_TOKEN is required (a PAT with repo scope)}"
TAG_VERSION="${1:?usage: publish-release.sh <version> <round> (e.g. v0.18.0 R168)}"
ROUND="${2:?usage: publish-release.sh <version> <round> (e.g. v0.18.0 R168)}"
REPO="nuorjoy/Ashrilogic"
BRANCH="main"
API="https://api.github.com"
AUTH=(-H "Authorization: Bearer ${GITHUB_TOKEN}" -H "Accept: application/vnd.github+json" -H "X-GitHub-Api-Version: 2022-11-28")

cd "$(cd "$(dirname "$0")/.." && pwd)"

# 0. the identity contract (the owner's directive)
GIT_NAME="$(git config user.name)"
GIT_EMAIL="$(git config user.email)"
[ "$GIT_NAME" = "nuorjoy" ] && [ "$GIT_EMAIL" = "nuooro@gmail.com" ] \
  || die "git identity is '$GIT_NAME <$GIT_EMAIL>' — expected nuorjoy <nuooro@gmail.com> (the vercel[bot] commit verification requires the team member identity)"

# 1. push main (triggers the Vercel production deployment)
log "pushing $BRANCH → $REPO (vercel[bot] auto-deploys on success)"
if ! git push "https://x-access-token:${GITHUB_TOKEN}@github.com/${REPO}.git" "$BRANCH"; then
  die "git push failed — check the token's repo scope and branch protection"
fi
SHA="$(git rev-parse HEAD)"
log "pushed $SHA"

# 2. the release notes (bundled file — kept in sync with the round)
NOTES_FILE="docs/releases/${TAG_VERSION}.md"
[ -f "$NOTES_FILE" ] || die "release notes missing: $NOTES_FILE"

# 3. create (or update) the GitHub Release with the ZIP asset
ZIP="public/downloads/Ashrilogic-Premium-${TAG_VERSION#v}-${ROUND}.zip"
[ -f "$ZIP" ] || die "release asset missing: $ZIP"
log "creating GitHub release ${TAG_VERSION}-${ROUND}"
RELEASE_BODY="$(cat "$NOTES_FILE")"
CREATE_JSON=$(jq -n \
  --arg tag "${TAG_VERSION}-${ROUND}" \
  --arg target "$SHA" \
  --arg name "Ashrilogic ${TAG_VERSION} · ${ROUND}" \
  --arg body "$RELEASE_BODY" \
  '{tag_name: $tag, target_commitish: $target, name: $name, body: $body, draft: false, prerelease: false}')
RESP=$(curl -s -w "\n%{http_code}" -X POST "${API}/repos/${REPO}/releases" "${AUTH[@]}" -d "$CREATE_JSON")
CODE="$(tail -1 <<< "$RESP")"
BODY_JSON="$(head -n -1 <<< "$RESP")"
if [ "$CODE" != "201" ] && [ "$CODE" != "422" ]; then
  die "release creation failed (HTTP $CODE): $(head -c 400 <<< "$BODY_JSON")"
fi
RELEASE_ID="$(jq -r '.id // empty' <<< "$BODY_JSON")"
if [ -z "$RELEASE_ID" ]; then
  # 422 → the tag already exists: fetch that release instead
  RELEASE_ID="$(curl -s "${API}/repos/${REPO}/releases/tags/${TAG_VERSION}-${ROUND}" "${AUTH[@]}" | jq -r '.id // empty')"
fi
[ -n "$RELEASE_ID" ] || die "could not resolve the release id"

# 4. upload the ZIP asset (replace when it already exists)
ASSET_URL="${API}/repos/${REPO}/releases/${RELEASE_ID}/assets?name=$(basename "$ZIP")"
EXISTING="$(curl -s "${API}/repos/${REPO}/releases/${RELEASE_ID}/assets" "${AUTH[@]}" | jq -r --arg n "$(basename "$ZIP")" '.[] | select(.name == $n) | .id' | head -1)"
if [ -n "$EXISTING" ]; then
  log "replacing the existing asset $(basename "$ZIP")"
  curl -s -X DELETE "${API}/repos/${REPO}/releases/assets/${EXISTING}" "${AUTH[@]}" >/dev/null || true
fi
log "uploading $(basename "$ZIP") ($(du -h "$ZIP" | cut -f1))"
UP_CODE="$(curl -s -o /dev/null -w "%{http_code}" -X POST "$ASSET_URL" \
  -H "Authorization: Bearer ${GITHUB_TOKEN}" -H "Content-Type: application/zip" \
  --data-binary "@$ZIP")"
[ "$UP_CODE" = "201" ] || die "asset upload failed (HTTP $UP_CODE)"

log "PUBLISHED: https://github.com/${REPO}/releases/tag/${TAG_VERSION}-${ROUND}"
log "Vercel production deploy is now building from ${SHA:0:8} — watch the deployment at the repo's Deployments tab."
