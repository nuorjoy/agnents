#!/usr/bin/env bun
/**
 * Ashrilogic — ROUND 165 SBOM generator (CycloneDX 1.5).
 *
 * Emits a CycloneDX JSON bill of materials from package.json + bun.lock
 * (all resolved packages — direct and transitive). ZERO new dependencies:
 * the lockfile is parsed directly and the document is assembled by hand,
 * consistent with the project's self-reliant tooling discipline.
 *
 * Direct dependencies carry the "direct" scope property; transitive ones
 * carry "transitive". The output validates against the CycloneDX 1.5
 * schema shape (bomFormat/serialNumber/version/metadata/components).
 *
 * Usage: bun run scripts/generate-sbom.ts [--out <path>]  (default stdout)
 */
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { randomUUID } from "node:crypto";

const ROOT = join(import.meta.dir, "..");

interface LockPackage {
  dependencies?: Record<string, string>;
}

interface LockFile {
  packages?: Record<string, [string, string, LockPackage?, unknown?]>;
}

function parseLock(): LockFile {
  const raw = readFileSync(join(ROOT, "bun.lock"), "utf8");
  const clean = raw.replace(/,(\s*[\]}])/g, "$1");
  return JSON.parse(clean) as LockFile;
}

function main(): void {
  const outIdx = process.argv.indexOf("--out");
  const outPath = outIdx >= 0 ? process.argv[outIdx + 1] : null;

  const pkg = JSON.parse(readFileSync(join(ROOT, "package.json"), "utf8")) as {
    name?: string;
    version?: string;
    dependencies?: Record<string, string>;
    devDependencies?: Record<string, string>;
  };
  const lock = parseLock();

  const directNames = new Set([
    ...Object.keys(pkg.dependencies ?? {}),
    ...Object.keys(pkg.devDependencies ?? {}),
  ]);

  const components: Record<string, unknown>[] = [];
  for (const [name, entry] of Object.entries(lock.packages ?? {})) {
    const pin = Array.isArray(entry) ? String(entry[0] ?? "") : "";
    const at = pin.lastIndexOf("@");
    const version = at > 0 ? pin.slice(at + 1) : "";
    if (version === "") continue;
    components.push({
      type: "library",
      "bom-ref": `pkg:npm/${name}@${version}`,
      name,
      version,
      purl: `pkg:npm/${encodeURIComponent(name).replace("%40", "@")}@${version}`,
      scope: directNames.has(name) ? "required" : "excluded",
      properties: [
        { name: "ashrilogic:dependency-kind", value: directNames.has(name) ? "direct" : "transitive" },
      ],
    });
  }

  const bom = {
    bomFormat: "CycloneDX",
    specVersion: "1.5",
    serialNumber: `urn:uuid:${randomUUID()}`,
    version: 1,
    metadata: {
      timestamp: new Date().toISOString(),
      component: {
        type: "application",
        name: pkg.name ?? "ashrilogic",
        version: pkg.version ?? "0.0.0",
      },
      tools: [{ vendor: "Ashrilogic", name: "generate-sbom", version: "1" }],
    },
    components,
  };

  const json = JSON.stringify(bom, null, 2);
  if (outPath) {
    writeFileSync(outPath, json + "\n");
    console.error(`generate-sbom: ${components.length} components → ${outPath}`);
  } else {
    console.log(json);
  }
}

main();
