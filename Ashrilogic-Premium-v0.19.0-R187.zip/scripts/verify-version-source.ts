// Ashrilogic — version single-source guard (CI/lint-time).
//
// CONTRACT:
//   1. package.json is the only place a semver literal may define the app
//      version. src/lib/version.ts re-exports it (APP_VERSION).
//   2. i18n dictionary VALUES must not DISPLAY a release version next to a
//      version word ("الإصدار 0.15.0" drifted two minors behind 0.16.0
//      once). Dictionaries carry the localized WORD only; the number is
//      always APP_VERSION at render time. Input placeholders ("e.g. 1.0.0")
//      and IP examples are not release displays and stay legal.
//   3. Version-word keys (v3Badge…) exist once per translated locale in the
//      dashboard domain (ar/en/hi).
//   4. No source string literal is EXACTLY a semver (optionally with a
//      -R### release tag) — that shape is the footer-drift smell. Known
//      IPv4 literals (127.0.0.1, 0.0.0.0, 192.168.…) are exempt.
//
// Exit codes: 0 = clean, 1 = violations found (printed).

import { readFileSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";

const ROOT = join(import.meta.dir, "..");
const SEMVER = /\d+\.\d+\.\d+/;
const VERSION_WORD = /(الإصدار|الاصدار|version|वर्ज़न)/i;
const EXAMPLE_MARKER = /(?:مثال|مثلاً|e\.g\.|example|जैसे|उदाहरण)/i;
const KEY_VERSIONISH = /(version|ver$|badge|إصدار|اصدار)/i;
const IP_LITERAL = /^(?:\d{1,3}\.){3}\d{1,3}$/;
const EXACT_SEMVER = /^\d+\.\d+\.\d+(?:-[A-Za-z0-9]+)?$/;

interface Violation {
  file: string;
  line: number;
  detail: string;
}

const violations: Violation[] = [];

function readLines(rel: string): string[] {
  return readFileSync(join(ROOT, rel), "utf8").split("\n");
}

/* 1. package.json parses and carries a plain semver version. */
const pkg = JSON.parse(readFileSync(join(ROOT, "package.json"), "utf8")) as {
  version?: string;
};
if (!EXACT_SEMVER.test(pkg.version ?? "")) {
  violations.push({
    file: "package.json",
    line: 0,
    detail: `package.json version is not a plain semver literal: ${String(pkg.version)}`,
  });
}

/* 2. version.ts re-exports exactly that literal. */
const versionSrc = readLines("src/lib/version.ts").join("\n");
if (!versionSrc.includes('from "../../package.json"')) {
  violations.push({
    file: "src/lib/version.ts",
    line: 0,
    detail: "version.ts must import the version from package.json (single source)",
  });
}

/* 3. Dictionary scan + v3Badge per-locale completeness. */
const dictDir = join(ROOT, "src/lib/i18n/domains");
for (const name of readdirSync(dictDir)) {
  if (!name.endsWith(".ts")) continue;
  const rel = `src/lib/i18n/domains/${name}`;
  const lines = readLines(rel);
  lines.forEach((line, i) => {
    const trimmed = line.trim();
    if (trimmed.startsWith("*") || trimmed.startsWith("//") || trimmed.startsWith("/*")) return;
    const colon = line.indexOf(":");
    if (colon === -1) return;
    const key = trimmed.split(":")[0]?.trim() ?? "";
    const valuePart = line.slice(colon + 1);
    const semverMatch = valuePart.match(SEMVER);
    if (!semverMatch) return;
    if (EXAMPLE_MARKER.test(valuePart)) return; // input placeholders, not release displays
    const idx = semverMatch.index ?? 0;
    const around = valuePart.slice(Math.max(0, idx - 24), idx + semverMatch[0].length + 8);
    const keyish = KEY_VERSIONISH.test(key);
    const wordish = VERSION_WORD.test(around);
    const isIpExample = IP_LITERAL.test(semverMatch[0]) && /(?:مثال|e\.g\.|example|IP)/i.test(valuePart);
    if ((keyish || wordish) && !isIpExample) {
      violations.push({
        file: rel,
        line: i + 1,
        detail: `release version displayed in dictionary value (word-only + APP_VERSION at render): ${trimmed.slice(0, 90)}`,
      });
    }
  });
  const hits = lines.filter((l) => l.trim().startsWith("v3Badge:"));
  const expected = /dashboard\.ts/.test(rel) ? 3 : 0; // ar/en/hi blocks
  if (hits.length !== expected) {
    violations.push({
      file: rel,
      line: 0,
      detail: `expected ${expected} v3Badge declarations (one per locale), found ${hits.length}`,
    });
  }
}

/* 4. Source scan: exact semver string literals (the drift shape). */
function walk(dir: string): string[] {
  const out: string[] = [];
  for (const entry of readdirSync(dir)) {
    if (entry === "node_modules" || entry === ".next" || entry === ".git") continue;
    const p = join(dir, entry);
    if (statSync(p).isDirectory()) out.push(...walk(p));
    else if (/\.(ts|tsx)$/.test(entry)) out.push(p);
  }
  return out;
}
const QUOTED_SEMVER = /(["'`])(\d+\.\d+\.\d+(?:-[A-Za-z0-9]+)?)\1/g;
for (const file of walk(join(ROOT, "src"))) {
  const rel = file.slice(ROOT.length + 1);
  if (rel === "lib/version.ts") continue;
  if (rel.startsWith("lib/i18n/domains/")) continue; // rule 3 owns dictionaries
  const src = readFileSync(file, "utf8");
  const lines = src.split("\n");
  lines.forEach((line, i) => {
    const codeLine = line.trim();
    if (codeLine.startsWith("*") || codeLine.startsWith("/*") || codeLine.startsWith("//")) return;
    const code = line.replace(/\/\/.*$/, "");
    QUOTED_SEMVER.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = QUOTED_SEMVER.exec(code)) !== null) {
      if (IP_LITERAL.test(m[2])) continue; // 127.0.0.1 etc.
      violations.push({
        file: rel,
        line: i + 1,
        detail: `exact semver string literal (use APP_VERSION from lib/version): ${m[2]}`,
      });
    }
  });
}

if (violations.length > 0) {
  console.error(`verify-version-source: ${violations.length} violation(s)`);
  for (const v of violations) {
    console.error(`  ${v.file}:${v.line || "?"} — ${v.detail}`);
  }
  process.exit(1);
}
console.log(`verify-version-source: clean (app version ${pkg.version})`);
