// Ashrilogic — one-shot image storage migration (ROUND 40 / task 8-a).
//
// Converts inline base64 data-URL images — site logos inside
// Site.contentJson.logoUrl and admin avatars in AdminUser.avatarUrl — into
// content-addressed files under storage/images/<sha256>.webp, leaving the
// short reference "/api/images/<sha256>" in the rows instead of megabytes
// of base64 (see src/lib/server/image-store.ts).
//
// Every migrated data-URL runs through the FULL upload-validation pipeline
// (magic bytes, dimension/pixel/bomb caps, sharp re-encode to clean WebP)
// with the SAME policy opts as the live routes:
//   • site logos:  maxInputBytes 3 MB / maxOutputBytes 700 KB
//   • avatars:     maxOutputBytes 400 KB
// A row whose image fails validation is SKIPPED (counted) — the run NEVER
// fails because of one hostile/legacy row.
//
// Idempotent: rows already holding a managed ref (or no data-URL) are
// skipped; re-runs make zero changes. ADDITIVE only — nothing is deleted.
//
// Usage:
//   bun run migrate:images              # migrate the configured DB
//   bun run migrate:images -- --dry     # report only, zero writes

import type { PrismaClient } from "@prisma/client";

export interface ImageMigrationResult {
  /** site rows whose logoUrl was converted (or would be, with --dry) */
  sites: number;
  /** admin rows whose avatarUrl was converted (or would be, with --dry) */
  admins: number;
  /** rows skipped: already migrated / no inline image / failed validation */
  skipped: number;
}

/** Same policy the live write routes enforce. */
const LOGO_OPTS = { maxInputBytes: 3 * 1024 * 1024, maxOutputBytes: 700 * 1024 };
const AVATAR_OPTS = { maxOutputBytes: 400 * 1024 };

/**
 * Core migration (exported for tests/security — pass a throwaway Prisma
 * client bound to the isolated test DB). With `dry` it validates and
 * reports but writes NEITHER rows NOR files.
 */
export async function migrateImages(
  db: PrismaClient,
  opts: { dry?: boolean } = {}
): Promise<ImageMigrationResult> {
  /* dynamic import AFTER env binding — the image-store's Prisma client and
   * this function's `db` argument must agree (same module registry) */
  const { storeImageDataUrl } = await import("@/lib/server/image-store");
  const { validateImageDataUrlBuffer } = await import(
    "@/lib/server/upload-validation"
  );

  const dry = opts.dry === true;
  let sites = 0;
  let admins = 0;
  let skipped = 0;

  /* ---- Site.contentJson.logoUrl ---------------------------------- */
  const siteRows = await db.site.findMany({
    select: { id: true, contentJson: true },
  });
  for (const row of siteRows) {
    let content: Record<string, unknown>;
    try {
      content = JSON.parse(row.contentJson ?? "{}") as Record<string, unknown>;
    } catch {
      /* corrupt contentJson — leave the row untouched */
      skipped++;
      continue;
    }
    const logoUrl = content.logoUrl;
    if (typeof logoUrl !== "string" || !logoUrl.startsWith("data:")) {
      continue; // "" / managed ref / absent — already migrated or no image
    }
    try {
      if (dry) {
        await validateImageDataUrlBuffer(logoUrl, LOGO_OPTS);
      } else {
        const stored = await storeImageDataUrl(logoUrl, LOGO_OPTS);
        /* re-serialize the parsed object (same serialization the write
         * route uses: JSON.stringify of the parsed content) with ONLY the
         * logoUrl field replaced — everything else is preserved */
        await db.site.update({
          where: { id: row.id },
          data: { contentJson: JSON.stringify({ ...content, logoUrl: stored.url }) },
        });
      }
      sites++;
    } catch {
      /* validation failure — SKIP the row, never fail the whole run */
      skipped++;
    }
  }

  /* ---- AdminUser.avatarUrl --------------------------------------- */
  const adminRows = await db.adminUser.findMany({
    select: { id: true, avatarUrl: true },
  });
  for (const row of adminRows) {
    const avatarUrl = row.avatarUrl;
    if (typeof avatarUrl !== "string" || !avatarUrl.startsWith("data:")) {
      continue; // null / "" / managed ref — already migrated or no image
    }
    try {
      if (dry) {
        await validateImageDataUrlBuffer(avatarUrl, AVATAR_OPTS);
      } else {
        const stored = await storeImageDataUrl(avatarUrl, AVATAR_OPTS);
        await db.adminUser.update({
          where: { id: row.id },
          data: { avatarUrl: stored.url },
        });
      }
      admins++;
    } catch {
      skipped++;
    }
  }

  return { sites, admins, skipped };
}

async function main(): Promise<void> {
  const dry = process.argv.includes("--dry");
  const { db } = await import("@/lib/db");
  const result = await migrateImages(db, { dry });
  console.log(
    `image storage migration ${dry ? "DRY RUN (no changes written)" : "complete"}: ` +
      `${result.sites} site logo(s) migrated, ${result.admins} admin avatar(s) migrated, ` +
      `${result.skipped} row(s) skipped (already migrated / no inline image / validation failure)`
  );
  await db.$disconnect();
}

/* run as CLI only — importing this module (tests) must stay side-effect free */
if (import.meta.main) {
  main().catch(async (error) => {
    console.error("image storage migration failed:", error);
    process.exit(1);
  });
}
