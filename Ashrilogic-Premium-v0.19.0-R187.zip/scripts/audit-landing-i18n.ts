/**
 * ROUND 174 (hydration integrity) — one-shot auditor.
 *
 * Scans every file of the landing SSR/hydration tree for i18n key usages
 * (t("k"), label("k"), i18nT(lang, "k"), t(lang, "k")) and reports every key
 * that is NOT resolvable by the STATIC fragment (landing + common + features).
 *
 * The i18n registry contract (src/lib/i18n/registry.ts header): any key the
 * landing SSR tree evaluates MUST live in the static fragment, otherwise the
 * client renders the raw key at hydration while the server (whose module
 * registry may hold the app fragment registered by other routes) renders the
 * translated value → hydration mismatch. (Exactly the favAdd / wzSummaryUnit
 * bug reported in the browser console.)
 *
 * Run: bun scripts/audit-landing-i18n.ts
 */
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";

import { landing } from "../src/lib/i18n/domains/landing";
import { common } from "../src/lib/i18n/domains/common";
import { features } from "../src/lib/i18n/domains/features";
import { auth } from "../src/lib/i18n/domains/auth";
import { wizard } from "../src/lib/i18n/domains/wizard";
import { dashboard } from "../src/lib/i18n/domains/dashboard";
import { site } from "../src/lib/i18n/domains/site";
import { admin } from "../src/lib/i18n/domains/admin";
import { store } from "../src/lib/i18n/domains/store";
import { inventory } from "../src/lib/i18n/domains/inventory";
import { business } from "../src/lib/i18n/domains/business";

const STATIC_KEYS = new Set<string>([
  ...Object.keys(landing.ar),
  ...Object.keys(common.ar),
  ...Object.keys(features.ar),
]);
// EN/hi-only keys are not a thing (same key sets), but guard anyway:
for (const d of [landing, common, features]) {
  for (const key of Object.keys(d.en)) STATIC_KEYS.add(key);
  for (const key of Object.keys(d.hi)) STATIC_KEYS.add(key);
}

/** Heavy-domain lookup: key → { lang: value } + which domain defines it. */
const HEAVY: Record<string, { ar: string; en: string; hi: string; domain: string }> = {};
const DOMAIN_MODULES: Record<string, { ar: Record<string, string>; en: Record<string, string>; hi: Record<string, string> }> = {
  auth, wizard, dashboard, site, admin, store, inventory, business,
};
for (const [name, mod] of Object.entries(DOMAIN_MODULES)) {
  for (const key of Object.keys(mod.ar)) {
    HEAVY[key] = { ar: mod.ar[key], en: mod.en[key], hi: mod.hi[key], domain: name };
  }
}

/** t("k") · label("k") · i18nT("k") · i18nT(lang, "k") · t(lang, "k") · translate("k")
 *  R182: useDocumentTitle("k", …) added — the systems-detail tab title
 *  (docTitleSystemDetail) escaped every earlier audit because this regex
 *  only watched t/label/i18nT/translate calls; the hook resolves the key
 *  through the SAME registry so its keys obey the identical static-fragment
 *  contract (a heavy-domain key renders as the raw key after hydration). */
const CALL_RE = /\b(?:t|label|i18nT|translate|useDocumentTitle)\s*\(\s*(?:[A-Za-z_$][\w$]*\s*,\s*)?["']([A-Za-z0-9_]+)["']/g;

/* R183 — CONDITIONAL-KEY useDocumentTitle calls: `useDocumentTitle(cond
 * ? "a" : "b", …)` has no literal first argument and spans multiple lines,
 * so the line regex above misses BOTH branches (the R183 data-aware
 * article-title fix introduced the first such call). This pass extracts
 * each useDocumentTitle(…) call SPAN (balanced parens across lines) and
 * collects every key-shaped string literal inside — both branches of a
 * ternary, any future array/map indirection. Errs toward flagging: a
 * non-key quoted literal inside a span is reported as unknown (a false
 * alarm is safer than a silent miss). */
const UDT_SPAN_RE = /\buseDocumentTitle\s*\(/g;
const SPAN_STR_RE = /["']([A-Za-z0-9_]+)["']/g;

function scanDocumentTitleSpans(
  src: string,
  file: string,
  seenInFile: Set<string>,
  used: Set<string>,
  missing: Map<string, Hit[]>,
): void {
  let um: RegExpExecArray | null;
  UDT_SPAN_RE.lastIndex = 0;
  while ((um = UDT_SPAN_RE.exec(src))) {
    let depth = 1;
    let j = um.index + um[0].length;
    while (j < src.length && depth > 0) {
      const ch = src[j];
      if (ch === "(") depth++;
      else if (ch === ")") depth--;
      j++;
    }
    const span = src.slice(um.index, j);
    const line = src.slice(0, um.index).split("\n").length;
    SPAN_STR_RE.lastIndex = 0;
    let sm: RegExpExecArray | null;
    while ((sm = SPAN_STR_RE.exec(span))) {
      const key = sm[1];
      /* lang codes appear inside call spans (lang === "ar" ternaries in the
       * vars argument) — never i18n keys themselves; exempt them instead of
       * carrying a standing false alarm. */
      if (key === "ar" || key === "en" || key === "hi") continue;
      const dedupe = `${file}:${key}`;
      if (seenInFile.has(dedupe)) continue;
      seenInFile.add(dedupe);
      used.add(key);
      if (STATIC_KEYS.has(key)) continue;
      const hit: Hit = { key, file: file.replace("/home/z/my-project/", ""), line };
      if (HEAVY[key]) hit.heavy = HEAVY[key];
      const list = missing.get(key) ?? [];
      list.push(hit);
      missing.set(key, list);
    }
  }
}

/** Files that participate in the landing SSR tree or hydrate with it. */
const ROOTS = [
  "/home/z/my-project/src/app/page.tsx",
  "/home/z/my-project/src/app/layout.tsx",
  "/home/z/my-project/src/components/landing",
  "/home/z/my-project/src/components/skip-link.tsx",
];

function walk(p: string, out: string[] = []): string[] {
  const st = statSync(p);
  if (st.isDirectory()) {
    for (const e of readdirSync(p)) walk(join(p, e), out);
  } else if (/\.(tsx|ts)$/.test(p)) {
    out.push(p);
  }
  return out;
}

const files = ROOTS.flatMap((r) => (statSync(r, { throwIfNoEntry: false }) ? walk(r) : []));

type Hit = { key: string; file: string; line: number; heavy?: { ar: string; en: string; hi: string; domain: string } };
const missing = new Map<string, Hit[]>();
const used = new Set<string>();

for (const file of files) {
  const src = readFileSync(file, "utf8");
  const lines = src.split("\n");
  const seenInFile = new Set<string>();
  for (let i = 0; i < lines.length; i++) {
    CALL_RE.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = CALL_RE.exec(lines[i]))) {
      const key = m[1];
      seenInFile.add(`${file}:${key}`);
      used.add(key);
      if (STATIC_KEYS.has(key)) continue;
      const hit: Hit = { key, file: file.replace("/home/z/my-project/", ""), line: i + 1 };
      if (HEAVY[key]) hit.heavy = HEAVY[key];
      const list = missing.get(key) ?? [];
      list.push(hit);
      missing.set(key, list);
    }
  }
  scanDocumentTitleSpans(src, file, seenInFile, used, missing);
}

console.log(`Scanned ${files.length} files · ${used.size} distinct keys · ${missing.size} NOT in static fragment\n`);
for (const [key, hits] of [...missing.entries()].sort()) {
  const h = hits[0].heavy;
  const where = h ? `${h.domain}.ts` : "NOWHERE (unknown key!)";
  const en = h ? JSON.stringify(h.en) : "—";
  console.log(`· ${key}  [${where}]  en=${en}`);
  for (const hit of hits.slice(0, 3)) console.log(`    ${hit.file}:${hit.line}`);
}

/* ROUND 175 — COLLISION audit: a static-fragment key that a heavy domain
 * ALSO defines with a DIFFERENT value is a silent-overwrite hazard (the
 * app fragment's Object.assign replaces the landing value once it loads —
 * exactly the blogSearchPh admin-vs-public collision). Identical values
 * are the documented R172b "byte-identical copy" pattern (safe). */
function buildStaticMap(): Record<string, { ar: string; en: string; hi: string }> {
  const map: Record<string, { ar: string; en: string; hi: string }> = {};
  const STATIC_DOMAINS: { ar: Record<string, string>; en: Record<string, string>; hi: Record<string, string> }[] = [landing, common, features];
  for (const d of STATIC_DOMAINS) {
    for (const key of Object.keys(d.ar)) map[key] ??= { ar: d.ar[key], en: d.en[key], hi: d.hi[key] };
  }
  return map;
}
const STATIC_MAP = buildStaticMap();

const collisions: string[] = [];
for (const [key, heavy] of Object.entries(HEAVY)) {
  if (!(key in STATIC_MAP)) continue;
  for (const lang of ["ar", "en", "hi"] as const) {
    if (STATIC_MAP[key][lang] !== heavy[lang]) {
      collisions.push(`${key}.${lang}: landing=${JSON.stringify(STATIC_MAP[key][lang])} vs ${heavy.domain}=${JSON.stringify(heavy[lang])}`);
      break;
    }
  }
}
if (collisions.length > 0) {
  console.log(`\n⚠ COLLIDING KEYS (heavy domain overwrites the landing value — rename!): ${collisions.length}`);
  for (const c of collisions) console.log(`  · ${c}`);
} else {
  console.log(`\nCollision audit: CLEAN (every shared key is byte-identical across domains)`);
}
