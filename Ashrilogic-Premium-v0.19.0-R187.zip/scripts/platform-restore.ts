// Ashrilogic — platform-snapshot recovery tool.
//
// The platform backup (src/lib/server/platform-backup.ts) writes verified
// snapshot directories under storage/backups/:
//
//   ashrilogic-<stamp>/database.dump      pg_dump custom-format PostgreSQL
//                                         archive (manifest databaseFormat
//                                         "pg_dump-custom")
//   ashrilogic-<stamp>/database.db        LEGACY SQLite snapshot (pre-cutover
//                                         artifacts — still verifiable DR
//                                         files on disk)
//   ashrilogic-<stamp>/images/<sha>.webp  the actual image bytes
//   ashrilogic-<stamp>/manifest.json      per-file SHA-256 (+ row counts on
//                                         legacy snapshots)
//
// Recovery is an EXPLICIT, VERIFIED operator flow — never an automatic swap:
//
//   bun scripts/platform-restore.ts --list
//   bun scripts/platform-restore.ts --verify
//   bun scripts/platform-restore.ts --verify ashrilogic-2026-01-01T00-00-00
//   bun scripts/platform-restore.ts --restore ashrilogic-2026-01-01T00-00-00 --confirm
//
// Safety contract (data-safety lock):
//  - --restore ALWAYS runs the full verification battery first; any failure
//    aborts with NOTHING changed (format battery, every image digest).
//  - The app must be STOPPED (the script probes the local status endpoint
//    and OS-level listeners — a live process holds the database objects
//    being replaced).
//  - PostgreSQL restores run `pg_restore --clean --if-exists` with the
//    connection parameters from DATABASE_URL passed via ENVIRONMENT
//    (never argv — credentials stay off the process table), PRECEDED by a
//    pg_dump aside of the current database under
//    storage/backups/_pre-restore-<stamp>/ (manifest-carrying, restorable
//    by this same script) — the current state is never destroyed without a
//    rollback artifact, and a failed aside ABORTS the restore (fail-closed).
//  - After the restore the tool reconnects and verifies a core table
//    answers (SELECT COUNT(*) FROM "Instance").
//  - LEGACY SQLite snapshots are REFUSED on restore (the platform runs
//    PostgreSQL — there is no file to swap); their data is imported once
//    via `LEGACY_SQLITE_PATH=… bun run migrate:sqlite`.
//  - Restored images are content-addressed: existing identical files are
//    skipped, nothing is ever overwritten.

import { createHash } from "node:crypto";
import {
  copyFileSync,
  existsSync,
  mkdirSync,
  mkdtempSync,
  readdirSync,
  readFileSync,
  rmSync,
  statSync,
  writeFileSync,
} from "node:fs";
import { dirname, join } from "node:path";
import { tmpdir } from "node:os";
import {
  decryptBackupArtifact,
  isBackupEnvelope,
  resolveBackupMasterKeys,
} from "../src/lib/server/backup-crypto";

const args = process.argv.slice(2);
const MODE = args[0] ?? "--list";
const FLAG_CONFIRM = args.includes("--confirm");
/* the snapshot NAME is the first non-flag argument (the mode is always a
 * dashed flag — see the usage line). The former [1] index never resolved:
 * named selection silently fell back to the newest snapshot, which would
 * have made the rollback instructions below restore the WRONG directory. */
const positional = args.filter((a) => !a.startsWith("--"))[0];

function repoRoot(): string {
  let dir = process.cwd();
  for (let i = 0; i < 6; i++) {
    if (existsSync(join(dir, "package.json")) && existsSync(join(dir, "prisma"))) return dir;
    const parent = dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return process.cwd();
}

const ROOT = repoRoot();
/* CANONICAL storage root — the SAME resolver the application uses
 * (image-store.ts / platform-backup.ts): ASHRILOGIC_STORAGE_DIR when set,
 * else <repo>/storage. The CLI and the app must agree on where snapshots
 * and image bytes live — a hardcoded path breaks custom-volume and
 * container deployments where the storage root is moved. */
const STORAGE_DIR = process.env.ASHRILOGIC_STORAGE_DIR
  ? (process.env.ASHRILOGIC_STORAGE_DIR.startsWith("/")
      ? process.env.ASHRILOGIC_STORAGE_DIR
      : join(ROOT, process.env.ASHRILOGIC_STORAGE_DIR))
  : join(ROOT, "storage");
const BACKUPS_DIR = join(STORAGE_DIR, "backups");
const IMAGES_DIR = join(STORAGE_DIR, "images");

interface Manifest {
  createdAt: string;
  database: string;
  /* PostgreSQL snapshots carry "pg_dump-custom" — dispatches verification
   * and restore to the pg_dump custom-format paths. Legacy manifests lack
   * the field (SQLite database.db member). */
  databaseFormat?: string;
  images: Array<{ file: string; sha256: string; bytes: number; verified: boolean }>;
  rowCounts?: Record<string, number>;
  imagesUnverified?: number;
  /* ROUND 137 — the database member is an ASHBC1 envelope (local at-rest
   * encryption); databaseSha256 stays the PLAINTEXT digest. */
  databaseEncrypted?: boolean;
  databaseSha256?: string;
  databaseBytes?: number;
}

/* ------------------------------------------------------------------ *
 * ROUND 137 — encrypted-member support                                 *
 * ------------------------------------------------------------------ */

/** The snapshot's database member as PLAINTEXT bytes: legacy snapshots
 *  pass through untouched; ASHBC1 envelopes decrypt with the provisioned
 *  master keys (active + rotation window). Returns null when the member
 *  is encrypted but cannot be opened (no key / tampered / unknown keyId)
 *  — every caller fails CLOSED on null. */
function readSnapshotDatabasePlain(dir: string, databaseFile: string): Buffer | null {
  const raw = readFileSync(join(dir, databaseFile));
  if (!isBackupEnvelope(raw)) return raw;
  const keys = resolveBackupMasterKeys();
  if (!keys.available) return null;
  const opened = decryptBackupArtifact(raw, { active: keys.active, previous: keys.previous });
  return opened.ok ? opened.plain : null;
}

/** Write decrypted bytes into a PRIVATE temp dir for the SQLite battery
 *  (integrity_check + row counts). Returns the temp dir (caller removes)
 *  or null when the plaintext is already on disk. */
function stagePlainForVerification(
  dir: string,
  databaseFile: string
): { tempDir: string; plainPath: string } | null {
  const raw = readFileSync(join(dir, databaseFile));
  if (!isBackupEnvelope(raw)) return null;
  const plain = readSnapshotDatabasePlain(dir, databaseFile);
  if (plain === null) return null;
  const tempDir = mkdtempSync(join(tmpdir(), "ash-restore-verify-"));
  const plainPath = join(tempDir, databaseFile);
  writeFileSync(plainPath, plain);
  return { tempDir, plainPath };
}

function listSnapshots(): string[] {
  if (!existsSync(BACKUPS_DIR)) return [];
  return readdirSync(BACKUPS_DIR)
    .filter((f) => statSync(join(BACKUPS_DIR, f)).isDirectory())
    .filter((f) => /^ashrilogic-/.test(f))
    .sort()
    .reverse();
}

/** Candidate app ports — the managed default plus any PORT override. */
function candidatePorts(): number[] {
  const ports = [3000];
  const envPort = Number(process.env.PORT);
  if (Number.isFinite(envPort) && envPort > 0 && !ports.includes(envPort)) {
    ports.unshift(envPort);
  }
  return ports;
}

async function appIsRunning(): Promise<boolean> {
  /* A HEALTH ENDPOINT ALONE IS NOT SUFFICIENT EVIDENCE (restore-safety):
   * the app may run on an alternate port, behind a reverse proxy, or in a
   * container. The check is layered: HTTP probe on every candidate port →
   * OS-level listener scan (/proc/net/tcp). ANY positive signal refuses
   * the restore. */
  for (const port of candidatePorts()) {
    try {
      const res = await fetch(`http://localhost:${port}/api/status`, {
        signal: AbortSignal.timeout(1500),
      });
      if (res.ok) return true;
    } catch {
      /* port closed — next candidate */
    }
  }
  if (osListenersActive()) return true;
  return false;
}

/** Linux /proc/net/tcp listener scan for the candidate ports. */
function osListenersActive(): boolean {
  try {
    const read = readFileSync;
    const wanted = new Set(candidatePorts().map((p) => p.toString(16).toUpperCase().padStart(4, "0")));
    for (const path of ["/proc/net/tcp", "/proc/net/tcp6"]) {
      let text: string;
      try {
        text = read(path, "utf8");
      } catch {
        continue; /* not Linux / not available — other signals decide */
      }
      for (const line of text.split("\n").slice(1)) {
        const parts = line.trim().split(/\s+/);
        if (parts.length < 4) continue;
        const [localAddr, state] = [parts[1]!, parts[3]!];
        if (state !== "0A") continue; /* LISTEN only */
        const portHex = localAddr.split(":")[1] ?? "";
        if (wanted.has(portHex.toUpperCase())) return true;
      }
    }
  } catch {
    /* unavailable — other signals decide */
  }
  return false;
}

/** Spawn a PostgreSQL client binary with a FIXED argument vector and
 *  env-based connection parameters (never argv — credentials stay off the
 *  process table; no shell involved). Resolves the exit code (-1 when the
 *  binary cannot be spawned) plus BOUNDED stderr for the operator-facing
 *  failure paths. */
async function spawnPgTool(
  binary: "pg_dump" | "pg_restore",
  args: string[],
  env: NodeJS.ProcessEnv
): Promise<{ code: number; stderr: string }> {
  const { spawn } = await import("node:child_process");
  return new Promise((resolve) => {
    const child = spawn(binary, args, { env, stdio: ["ignore", "ignore", "pipe"] });
    let stderr = "";
    child.stderr?.on("data", (chunk: Buffer) => {
      stderr += chunk.toString("utf8");
      if (stderr.length > 4000) stderr = stderr.slice(0, 4000); /* bounded */
    });
    child.on("error", () => resolve({ code: -1, stderr }));
    child.on("close", (code) => resolve({ code: code ?? -1, stderr }));
  });
}

/** pg_dump custom-format magic — the first 5 bytes of every custom
 *  archive, independent of PostgreSQL version. */
const PGDMP_MAGIC = "PGDMP";

/** Full verification battery over one snapshot directory. Format-aware:
 *  PostgreSQL snapshots (database.dump) verify through the pg_dump
 *  custom-format magic + `pg_restore --list` + the manifest digest;
 *  LEGACY SQLite snapshots (database.db) keep the physical
 *  integrity_check + row-count battery. */
async function verifySnapshot(
  dir: string
): Promise<{ ok: boolean; errors: string[]; format: "pg" | "sqlite-legacy" | null }> {
  const errors: string[] = [];

  let manifest: Manifest | null = null;
  const manifestFile = join(dir, "manifest.json");
  if (!existsSync(manifestFile)) {
    errors.push("manifest.json missing");
  } else {
    try {
      manifest = JSON.parse(readFileSync(manifestFile, "utf8")) as Manifest;
    } catch {
      errors.push("manifest.json is not valid JSON");
    }
  }

  /* the manifest's databaseFormat is the authority; member file presence
   * is the fallback dispatch (a PostgreSQL snapshot is database.dump) */
  const isPg =
    manifest?.databaseFormat === "pg_dump-custom" || existsSync(join(dir, "database.dump"));
  const databaseFile = isPg ? "database.dump" : "database.db";
  const dbFile = join(dir, databaseFile);
  if (!existsSync(dbFile)) errors.push(`${databaseFile} missing`);

  if (isPg) {
    /* PostgreSQL battery — ROUND 137: encrypted members are DECRYPTED
     * first (fail closed when the key is missing or the envelope is
     * tampered); the digest check runs over the PLAINTEXT. */
    if (existsSync(dbFile)) {
      const raw = readFileSync(dbFile);
      let plain: Buffer | null;
      if (isBackupEnvelope(raw)) {
        plain = readSnapshotDatabasePlain(dir, databaseFile);
        if (plain === null) {
          errors.push(
            `${databaseFile} is an ENCRYPTED envelope that cannot be opened — provision ASHRILOGIC_BACKUP_KEY (or the rotation key) and retry`
          );
        }
      } else {
        plain = raw;
      }
      if (plain !== null) {
        if (manifest && typeof manifest.databaseSha256 === "string") {
          const digest = createHash("sha256").update(plain).digest("hex");
          if (digest !== manifest.databaseSha256) {
            errors.push(`${databaseFile} plaintext digest mismatch (manifest tampered)`);
          }
        }
        if (plain.length < 5 || plain.subarray(0, 5).toString("latin1") !== PGDMP_MAGIC) {
          errors.push(`${databaseFile} is not a pg_dump custom-format archive (bad magic)`);
        } else {
          /* pg_restore --list parses the archive's catalog — through a
           * private temp copy when the member is an envelope. Unlike the
           * PUBLIC /api/status health check (advisory there), a missing
           * pg_restore FAILS here: the restore itself requires the binary. */
          let listPath = dbFile;
          let tempDir: string | null = null;
          if (isBackupEnvelope(raw)) {
            tempDir = mkdtempSync(join(tmpdir(), "ash-restore-verify-"));
            listPath = join(tempDir, databaseFile);
            writeFileSync(listPath, plain);
          }
          try {
            const list = await spawnPgTool("pg_restore", ["--list", listPath], process.env);
            if (list.code === -1) {
              errors.push(
                "pg_restore is not on PATH — the archive catalog cannot be verified (the restore itself requires the binary)"
              );
            } else if (list.code !== 0) {
              errors.push(`pg_restore --list failed (exit ${list.code}) — the archive catalog does not parse`);
            }
          } finally {
            if (tempDir !== null) rmSync(tempDir, { recursive: true, force: true });
          }
        }
      }
    }
  } else if (existsSync(dbFile)) {
    /* LEGACY SQLite battery — physical integrity check on a READ-ONLY
     * connection. ROUND 137 — encrypted members are DECRYPTED first (fail
     * closed when the key is missing or the envelope is tampered) and
     * verified through a private temp copy; the digest check runs over the
     * PLAINTEXT. */
    let staged: { tempDir: string; plainPath: string } | null = null;
    const rawHead = readFileSync(dbFile);
    if (isBackupEnvelope(rawHead)) {
      staged = stagePlainForVerification(dir, databaseFile);
      if (staged === null) {
        errors.push(
          `${databaseFile} is an ENCRYPTED envelope that cannot be opened — provision ASHRILOGIC_BACKUP_KEY (or the rotation key) and retry`
        );
      } else if (manifest && typeof manifest.databaseSha256 === "string") {
        const digest = createHash("sha256").update(readFileSync(staged.plainPath)).digest("hex");
        if (digest !== manifest.databaseSha256) {
          errors.push("database plaintext digest mismatch (manifest tampered)");
        }
      }
    } else if (manifest && typeof manifest.databaseSha256 === "string") {
      const digest = createHash("sha256").update(rawHead).digest("hex");
      if (digest !== manifest.databaseSha256) {
        errors.push(`${databaseFile} digest mismatch (manifest tampered)`);
      }
    }
    if (staged !== null) {
      const { Database } = await import("bun:sqlite");
      try {
        const db = new Database(staged.plainPath, { readonly: true });
        const row = db.query("PRAGMA integrity_check").get() as { integrity_check: string } | undefined;
        if (!row || row.integrity_check !== "ok") {
          errors.push(`integrity_check: ${row?.integrity_check ?? "no result"}`);
        }
        if (manifest?.rowCounts) {
          const tables: Record<string, string> = {
            instances: "Instance",
            moduleRecords: "ModuleRecord",
            customers: "SiteCustomer",
            orders: "SiteOrder",
            reviews: "SiteReview",
            coupons: "StoreCoupon",
            imageAssets: "ImageAsset",
            auditLogs: "AuditLog",
          };
          for (const [key, table] of Object.entries(tables)) {
            const expected = manifest.rowCounts[key];
            if (expected === undefined) continue;
            try {
              const actual = (db.query(`SELECT COUNT(*) AS c FROM "${table}"`).get() as { c: number }).c;
              if (actual !== expected) {
                errors.push(`row-count drift ${table}: manifest=${expected} snapshot=${actual}`);
              }
            } catch {
              errors.push(`table ${table} missing from snapshot`);
            }
          }
        }
        db.close();
      } catch (e) {
        errors.push(`cannot open the (decrypted) ${databaseFile}: ${e instanceof Error ? e.message : String(e)}`);
      } finally {
        rmSync(staged.tempDir, { recursive: true, force: true });
      }
    }
  }

  /* every manifest image must exist in the snapshot and re-hash to its digest */
  if (manifest) {
    for (const img of manifest.images) {
      const file = join(dir, "images", img.file);
      if (!existsSync(file)) {
        errors.push(`image ${img.file} missing from snapshot`);
        continue;
      }
      const digest = createHash("sha256").update(readFileSync(file)).digest("hex");
      if (digest !== img.sha256) {
        errors.push(`image ${img.file} digest mismatch (manifest tampered)`);
      } else if (digest !== img.file.replace(/\.webp$/, "")) {
        errors.push(`image ${img.file} corrupt (bytes do not hash to their name)`);
      }
    }
    if ((manifest.imagesUnverified ?? 0) > 0) {
      errors.push(`manifest recorded ${manifest.imagesUnverified} unverified image(s) at BACKUP time`);
    }
  }

  return {
    ok: errors.length === 0,
    errors,
    format: manifest === null ? null : isPg ? "pg" : "sqlite-legacy",
  };
}

/** PostgreSQL restore: `pg_restore --clean --if-exists` into the DATABASE_URL
 *  database. Connection parameters are passed via ENVIRONMENT parsed from
 *  DATABASE_URL — exactly the backup path's env-building pattern
 *  (src/lib/server/platform-backup.ts): the password never appears in argv.
 *  The CURRENT database is dumped aside FIRST (fail-closed: no rollback
 *  artifact = no restore), and the restore is verified afterwards by
 *  reconnecting and counting a core table. Returns the aside snapshot NAME
 *  (restorable by this same script) for the rollback instructions. */
async function restorePostgresSnapshot(dir: string): Promise<string> {
  const dsn = (process.env.DATABASE_URL ?? "").trim();
  if (!/^postgres(ql)?:\/\//i.test(dsn)) {
    console.error("DATABASE_URL is not a PostgreSQL connection string — nothing to restore into");
    process.exit(1);
  }
  let url: URL;
  try {
    url = new URL(dsn);
  } catch {
    console.error("DATABASE_URL is unparseable — nothing to restore into");
    process.exit(1);
  }
  const env: NodeJS.ProcessEnv = {
    ...process.env,
    PGHOST: url.hostname,
    PGPORT: url.port || "5432",
    PGUSER: decodeURIComponent(url.username || ""),
    PGPASSWORD: decodeURIComponent(url.password || ""),
    PGDATABASE: (url.pathname || "/").replace(/^\//, ""),
    PGSSLMODE: (url.searchParams.get("sslmode") ?? "prefer"),
  };
  /* neutralize any inherited PGSERVICE by DELETION, never an empty string
   * (libpq treats PGSERVICE="" as a service-name lookup and the tool fails
   * with `definition of service "" not found`) — same as platform-backup */
  delete env.PGSERVICE;
  const databaseName = (url.pathname || "/").replace(/^\//, "");

  /* the verified snapshot's database member — an ENCRYPTED member is
   * decrypted to a PRIVATE temp file (pg_restore reads a path, not bytes;
   * the verification battery above already proved the envelope opens) */
  const memberFile = "database.dump";
  let dumpPath = join(dir, memberFile);
  let stagedTempDir: string | null = null;
  const rawMember = readFileSync(dumpPath);
  if (isBackupEnvelope(rawMember)) {
    const plain = readSnapshotDatabasePlain(dir, memberFile);
    if (plain === null) {
      console.error(
        "the snapshot's encrypted database cannot be opened — provision ASHRILOGIC_BACKUP_KEY (or the rotation key) and re-run --verify"
      );
      process.exit(1);
    }
    stagedTempDir = mkdtempSync(join(tmpdir(), "ash-restore-"));
    dumpPath = join(stagedTempDir, memberFile);
    writeFileSync(dumpPath, plain);
  }

  /* the _pre-restore- prefix keeps the aside OUT of the snapshot retention
   * sweep, the --list output and the /api/status health pick (all three
   * match ^ashrilogic-); the manifest makes it directly restorable by this
   * same script as the rollback artifact. It is never deleted here. */
  const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const asideName = `_pre-restore-${stamp}`;
  const asideDir = join(BACKUPS_DIR, asideName);

  try {
    /* 1. preserve the CURRENT live state — a pg_dump custom-format aside.
     *    FAIL-CLOSED: if the aside cannot be taken, nothing is restored. */
    mkdirSync(asideDir, { recursive: true });
    const asideDump = join(asideDir, memberFile);
    const aside = await spawnPgTool("pg_dump", ["--format=custom", "--file", asideDump], env);
    if (aside.code !== 0 || !existsSync(asideDump)) {
      console.error(
        `preserving the current database FAILED (pg_dump exit ${aside.code}) — restore aborted, NOTHING changed`
      );
      if (aside.stderr.trim()) console.error(`  pg_dump: ${aside.stderr.trim().slice(0, 400)}`);
      process.exit(1);
    }
    writeFileSync(
      join(asideDir, "manifest.json"),
      JSON.stringify(
        {
          createdAt: new Date().toISOString(),
          database: memberFile,
          databaseFormat: "pg_dump-custom",
          databaseSha256: createHash("sha256").update(readFileSync(asideDump)).digest("hex"),
          databaseBytes: statSync(asideDump).size,
          images: [],
          imagesUnverified: 0,
        },
        null,
        2
      ),
      "utf8"
    );
    console.log(`current database preserved at ${asideDir} (restorable rollback artifact)`);

    /* 2. the DB-level restore — REPLACES the former SQLite file swap */
    console.log(`restoring into PostgreSQL database "${databaseName}" …`);
    const restore = await spawnPgTool(
      "pg_restore",
      ["--clean", "--if-exists", "--dbname", databaseName, dumpPath],
      env
    );
    if (restore.code !== 0) {
      console.error(`pg_restore FAILED (exit ${restore.code}) — the database may be PARTIALLY restored.`);
      if (restore.stderr.trim()) console.error(`  pg_restore: ${restore.stderr.trim().slice(0, 2000)}`);
      console.error(`  rollback: bun scripts/platform-restore.ts --restore ${asideName} --confirm`);
      process.exit(1);
    }

    /* 3. verify by RECONNECTING and counting a core table — schema + data
     *    answered a real query through the application's own client */
    const { PrismaClient } = await import("@prisma/client");
    const prisma = new PrismaClient();
    try {
      const rows = await prisma.$queryRaw<
        Array<{ count: number }>
      >`SELECT COUNT(*)::int AS count FROM "Instance"`;
      console.log(`post-restore check: "Instance" reachable — ${rows[0]?.count ?? 0} row(s)`);
    } catch (error) {
      console.error(
        `post-restore check FAILED ("Instance" not queryable): ${
          error instanceof Error ? error.message : String(error)
        }`
      );
      console.error(`  rollback: bun scripts/platform-restore.ts --restore ${asideName} --confirm`);
      process.exit(1);
    } finally {
      await prisma.$disconnect();
    }
  } finally {
    if (stagedTempDir !== null) rmSync(stagedTempDir, { recursive: true, force: true });
  }
  return asideName;
}

async function main(): Promise<void> {
  if (MODE === "--list") {
    const snaps = listSnapshots();
    if (snaps.length === 0) {
      console.log("no platform snapshots in storage/backups");
      return;
    }
    console.log("platform snapshots (newest first):");
    for (const s of snaps) {
      const m = existsSync(join(BACKUPS_DIR, s, "manifest.json"))
        ? (JSON.parse(readFileSync(join(BACKUPS_DIR, s, "manifest.json"), "utf8")) as Manifest)
        : null;
      const imgs = m ? `${m.images.length} image(s)` : "manifest missing";
      const fmt = m?.databaseFormat === "pg_dump-custom" ? "postgresql" : "sqlite (legacy)";
      const rows = m?.rowCounts
        ? `${(m.rowCounts.instances ?? 0)} instances · ${(m.rowCounts.moduleRecords ?? 0)} records`
        : "";
      console.log(`  ${s}  [${fmt}]  ${imgs}  ${rows}`);
    }
    return;
  }

  if (MODE === "--verify" || MODE === "--restore") {
    const snaps = listSnapshots();
    const target = positional ?? snaps[0];
    if (!target) {
      console.error("no snapshots available");
      process.exit(1);
    }
    const dir = join(BACKUPS_DIR, target);
    if (!existsSync(dir)) {
      console.error(`snapshot not found: ${target}`);
      process.exit(1);
    }

    console.log(`verifying ${target} …`);
    const verdict = await verifySnapshot(dir);
    for (const e of verdict.errors) console.error(`  ✗ ${e}`);
    if (!verdict.ok) {
      console.error("verification FAILED — snapshot is NOT safe to restore");
      process.exit(1);
    }
    if (verdict.format === "pg") {
      console.log("  ✓ pg_dump archive verified (magic + pg_restore --list + manifest digest)");
    } else {
      console.log("  ✓ database integrity ok");
      console.log("  ✓ row counts match the manifest");
    }
    console.log("  ✓ every image digest verified");
    if (MODE === "--verify") {
      if (verdict.format === "sqlite-legacy") {
        console.log("");
        console.log("NOTE: LEGACY SQLite snapshot — verified as a DR artifact, but the platform now");
        console.log("runs PostgreSQL and cannot restore it. One-time data import instead:");
        console.log(`  LEGACY_SQLITE_PATH=${join(dir, "database.db")} bun run migrate:sqlite`);
      }
      console.log("verification PASSED");
      return;
    }

    /* ---- --restore: explicit, confirmed, app stopped ---- */
    if (!FLAG_CONFIRM) {
      console.error("refusing to restore without --confirm (this REPLACES the live database contents)");
      process.exit(1);
    }
    if (await appIsRunning()) {
      console.error(
        "the application is RUNNING on localhost:3000 — stop it first (its connections hold the database objects being replaced)"
      );
      process.exit(1);
    }
    if (verdict.format !== "pg") {
      console.error(
        "REFUSED: this is a LEGACY SQLite snapshot and the platform now runs PostgreSQL — there is no file to swap against a PostgreSQL deployment."
      );
      console.error("To import the snapshot's data one time:");
      console.error(`  LEGACY_SQLITE_PATH=${join(dir, "database.db")} bun run migrate:sqlite`);
      process.exit(1);
    }

    const asideName = await restorePostgresSnapshot(dir);

    /* images: content-addressed — only add what is missing, never overwrite */
    const snapImages = join(dir, "images");
    if (existsSync(snapImages)) {
      mkdirSync(IMAGES_DIR, { recursive: true });
      let copied = 0;
      for (const f of readdirSync(snapImages)) {
        const dst = join(IMAGES_DIR, f);
        if (!existsSync(dst)) {
          copyFileSync(join(snapImages, f), dst);
          copied++;
        }
      }
      console.log(`images: ${copied} copied, ${readdirSync(snapImages).length - copied} already present`);
    }

    console.log("\nrestore complete. next steps:");
    console.log("  1. start the application");
    console.log("  2. GET /api/status — must report ok");
    console.log("  3. bun run verify:audit — chain must verify");
    console.log(
      `  4. rollback (if needed): bun scripts/platform-restore.ts --restore ${asideName} --confirm`
    );
    return;
  }

  console.error("usage: bun scripts/platform-restore.ts [--list | --verify [snapshot] | --restore <snapshot> --confirm]");
  process.exit(1);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
