// Ashrilogic — tenant backup DR import CLI (create-from-backup, ROUND 97).
//
// WHY THIS EXISTS: the tenant backup envelope is a complete reconstruction
// artifact, but the dashboard restore path requires the Instance row to
// still EXIST and to match the file's instanceId (the ownership gate). When
// the instance row — or the whole database — is lost, that path is
// unreachable: the file could not be restored anywhere. This script is the
// platform-side recovery path: it re-creates the tenant from the file, with
// a fresh owner credential (the file deliberately carries none) and a fresh
// trial, then runs the battle-tested restore engine over the new shell.
//
// PROTOCOL (data-safety lock — same shape as the re-seal runbook):
//   1. PREFLIGHT (always)   — file readable + ≤ 25 MB, envelope standalone
//                              verification (format/version/SHA-256/deep
//                              shape), target id FREE, systemId in catalog,
//                              app RUNNING is allowed for the DRY-RUN (pure
//                              reads) but REQUIRED to be stopped for
//                              --confirm (a live process holds pooled
//                              database connections).
//   2. BACKUP (--confirm)   — a platform snapshot via runPlatformBackup()
//                              (pg_dump custom format under
//                              storage/backups/ashrilogic-<stamp>/) — the
//                              same verified artifact the scheduler
//                              produces; a FAILED snapshot ABORTS the
//                              import (no rollback artifact = no writes).
//   3. IMPORT  (--confirm)  — src/lib/server/backup-import.ts: gates →
//                              shell row (same instance id, fresh sealed
//                              owner identity, fresh trial) → restore engine
//                              → compensating rollback on any failure →
//                              post-verify + instance.import audit row.
//   4. REPORT               — counts, images outcome, bootstrap login,
//                              rollback instructions.
//
// USAGE:
//   bun scripts/import-backup.ts <backup.json> \
//     --email owner@example.com --gen                # DRY-RUN (safe, read-only)
//   bun scripts/import-backup.ts <backup.json> \
//     --email owner@example.com --gen --confirm      # execute (app must be STOPPED)
//
//   --email <addr>     bootstrap owner login email (REQUIRED)
//   --password <pw>    bootstrap password (≥ 12 chars) — or --
//   --gen              generate a strong random bootstrap password
//   --name <name>      owner display name (default: "<org> — Owner")
//   --package <id>     assign a package (default: fresh 14-day trial)
//   --confirm          EXECUTE (default: dry-run, no writes)
//   --force            execute even if the app appears to be running (NOT
//                      recommended — the live process holds pooled
//                      database connections)
//
// NEXT STEPS AFTER A SUCCESSFUL IMPORT:
//   1. Start the app (bash .zscripts/dev.sh in this sandbox).
//   2. The owner logs in at the workspace login with the bootstrap email +
//      the generated password, then changes it immediately (password change
//      rotates sessionVersion — old epochs die).
//   3. Customers re-establish their own passwords through the owner (the
//      restore engine assigns every customer an unusable credential by
//      design — a backup file must never yield working customer logins).
//   4. The owner re-completes the profile gate (ownerProfileJson does not
//      travel in the file) and re-activates a plan when ready (entitlement
//      levers never travel in the file).
//
// ROLLBACK (any failure, or a bad import): stop the app, then
//   bun scripts/platform-restore.ts --restore ashrilogic-<stamp> --confirm
// (the pre-import snapshot above) and restart. The pre-import snapshot is
// never deleted by this script.
//
// NOTE — image bytes: content-addressed files are copied idempotently by
// the restore engine (never overwrites; additive orphans on failure).

import { randomBytes } from "node:crypto";
import { existsSync, statSync } from "node:fs";
import { readFile } from "node:fs/promises";
import { argv, exit } from "node:process";
import { basename, join } from "node:path";

const args = argv.slice(2);

/* ---------- argument parsing ---------- */

function argValue(name: string): string | undefined {
  const i = args.indexOf(name);
  if (i === -1) return undefined;
  const v = args[i + 1];
  if (!v || v.startsWith("--")) return undefined;
  return v;
}

const HELP = args.includes("--help") || args.includes("-h");
const CONFIRM = args.includes("--confirm");
const FORCE = args.includes("--force");
const GEN_PASSWORD = args.includes("--gen");
const FILE = args.find((a) => !a.startsWith("--") && !a.startsWith("-"));
const EMAIL = argValue("--email");
const PASSWORD = argValue("--password");
const NAME = argValue("--name");
const PACKAGE_ID = argValue("--package");

if (HELP) {
  console.log(`Ashrilogic — tenant backup DR import (create-from-backup)

USAGE:
  bun scripts/import-backup.ts <backup.json> --email <owner email> --gen            # dry-run
  bun scripts/import-backup.ts <backup.json> --email <owner email> --gen --confirm  # execute

OPTIONS:
  --email <addr>    bootstrap owner login email (REQUIRED)
  --password <pw>   bootstrap password (>= 12 chars) — or --gen for a random one
  --gen             generate a strong random bootstrap password
  --name <name>     owner display name (default: "<org> — Owner")
  --package <id>    assign a package (default: fresh 14-day trial)
  --confirm         execute the import (default: dry-run, read-only)
  --force           execute even if the app appears to be running (NOT recommended)`);
  exit(0);
}

if (!FILE) {
  console.error("ERROR: a backup file path is required (see --help).");
  exit(1);
}
if (!existsSync(FILE)) {
  console.error(`ERROR: backup file not found: ${FILE}`);
  exit(1);
}
if (!EMAIL) {
  console.error("ERROR: --email <owner email> is required (the bootstrap login identity).");
  exit(1);
}
if (!PASSWORD && !GEN_PASSWORD) {
  console.error("ERROR: provide --password <pw> (>= 12 chars) or --gen for a random one.");
  exit(1);
}
if (PASSWORD && GEN_PASSWORD) {
  console.error("ERROR: pass either --password or --gen, not both.");
  exit(1);
}

/* the restore upload route caps the envelope at 25 MB end-to-end — the
   CLI holds the exact same ceiling so an importable file is always a
   restorable file */
const MAX_FILE_BYTES = 25 * 1024 * 1024;
const size = statSync(FILE).size;
if (size > MAX_FILE_BYTES) {
  console.error(`ERROR: backup file is ${size} bytes — above the 25 MB envelope ceiling.`);
  exit(1);
}

const BOOTSTRAP_PASSWORD = PASSWORD ?? randomBytes(24).toString("base64url");

/* ---------- app-running probe (write path only) ---------- */

async function appIsRunning(): Promise<boolean> {
  try {
    const res = await fetch("http://localhost:3000/api/status", {
      signal: AbortSignal.timeout(1500),
    });
    return res.ok;
  } catch {
    return false;
  }
}

/* ---------- main ---------- */

async function main(
  file: string,
  email: string,
  password: string,
  name: string | undefined,
  packageId: string | undefined
): Promise<void> {
  const { verifyBackupEnvelope } = await import("@/lib/server/backup");
  const { importInstanceBackup } = await import("@/lib/server/backup-import");
  const { SYSTEM_MAP } = await import("@/data/catalog");
  const { db } = await import("@/lib/db");

  console.log("Ashrilogic — tenant backup DR import (create-from-backup)");
  console.log(`  file: ${file} (${size} bytes)`);

  /* ---- 1. standalone envelope verification ---- */
  let envelope: unknown;
  try {
    envelope = JSON.parse(await readFile(file, "utf8"));
  } catch (error) {
    console.error(`ERROR: the file is not valid JSON: ${(error as Error).message}`);
    exit(1);
  }
  const verified = await verifyBackupEnvelope(envelope);
  if (!verified.ok) {
    console.error(
      `ERROR: envelope verification failed (${verified.reason}) — the file is corrupt, edited, or not an Ashrilogic backup.`
    );
    exit(1);
  }
  const { meta, sections } = verified;
  console.log("  envelope: VERIFIED (checksum + deep shape)");
  console.log(
    `  tenant: ${meta.orgName || meta.systemName} · system ${meta.systemId} · id ${meta.instanceId}`
  );
  console.log(
    `  payload: ${meta.totalRecords} records · ${sections.moduleRecords.length} module records · ${sections.customers.length} customers · ${sections.orders.length} orders · ${sections.team.length} team · ${sections.reviews?.length ?? 0} reviews · ${sections.coupons?.length ?? 0} coupons · ${meta.imagesCount} images (${meta.imagesMissing} missing)`
  );

  /* ---- target gates (read-only) ---- */
  const system = SYSTEM_MAP[sections.instance.systemId];
  if (!system) {
    console.error(`ERROR: unknown systemId "${sections.instance.systemId}" — not in the catalog.`);
    exit(1);
  }
  const existing = await db.instance.findUnique({
    where: { id: meta.instanceId },
    select: { id: true },
  });
  if (existing) {
    console.error(
      `ERROR: instance ${meta.instanceId} ALREADY EXISTS — this is the in-place case: use the\n  dashboard restore endpoint (PUT /api/instances/${meta.instanceId}/restore) instead.`
    );
    exit(1);
  }

  if (!CONFIRM) {
    /* ---- dry-run: plan + exit ---- */
    console.log("");
    console.log("DRY-RUN PLAN (no writes performed):");
    console.log(`  create Instance ${meta.instanceId} (system ${sections.instance.systemId}, same id — /sites/<id> URLs stay stable)`);
    console.log(`  bootstrap owner: ${EMAIL}${NAME ? ` (${NAME})` : ""}${PACKAGE_ID ? ` · package ${PACKAGE_ID}` : " · fresh 14-day trial"}`);
    console.log(`  then the restore engine lands all ${meta.totalRecords} records + ${meta.imagesCount} image assets`);
    console.log("");
    console.log("Run again with --confirm to execute (the app must be STOPPED first).");
    return;
  }

  /* ---- write path: app must be stopped ---- */
  if (!FORCE && (await appIsRunning())) {
    console.error(
      "ERROR: the app appears to be RUNNING on :3000 — stop it first (a live process holds\n  pooled database connections open). Use --force to override (NOT recommended)."
    );
    exit(1);
  }

  /* ---- 2. pre-import safety snapshot (platform pg_dump backup) ----
   * runPlatformBackup() lands a pg_dump custom-format archive under
   * storage/backups/ashrilogic-<stamp>/ with a hash-verified manifest —
   * the same artifact the scheduled backup produces, restorable by
   * scripts/platform-restore.ts. FAIL-CLOSED: without a rollback artifact
   * the import never starts. */
  const { runPlatformBackup } = await import("@/lib/server/platform-backup");
  const snapshotDir = await runPlatformBackup();
  if (!snapshotDir) {
    console.error(
      "ERROR: the pre-import platform snapshot FAILED (see the snapshot dir's FAILED.txt marker / server logs) — refusing to import without a rollback artifact."
    );
    exit(1);
  }
  let snapshotDigest = "";
  try {
    const manifest = JSON.parse(await readFile(join(snapshotDir, "manifest.json"), "utf8")) as {
      database?: string;
      databaseSha256?: string;
    };
    if (typeof manifest.databaseSha256 === "string") {
      snapshotDigest = ` · ${manifest.database ?? "database.dump"} sha256 ${manifest.databaseSha256.slice(0, 16)}…`;
    }
  } catch {
    /* informational only — the snapshot already recorded its own integrity */
  }
  console.log(`  pre-import snapshot: ${snapshotDir}${snapshotDigest}`);

  /* ---- 3. import ---- */
  console.log("");
  console.log("Importing…");
  const result = await importInstanceBackup(envelope, {
    ownerEmail: email,
    ownerName: name,
    ownerPassword: password,
    packageId: packageId ?? null,
    actor: { actorType: "admin", actorName: "import-backup CLI" },
  });

  if (!result.ok) {
    console.error(`\nIMPORT FAILED (${result.reason}).`);
    console.error(
      "Any partial write was compensated (the shell row is removed; the restore engine is\nfully transactional). Roll the database back if it was touched:"
    );
    console.error(`  bun scripts/platform-restore.ts --restore ${basename(snapshotDir)} --confirm`);
    exit(1);
  }

  /* ---- 4. report ---- */
  console.log("\nIMPORT SUCCEEDED");
  console.log(`  instance: ${result.instanceId}`);
  console.log(`  restored: ${result.restored} records`);
  console.log(`  images:   ${result.imagesRestored} restored, ${result.imagesMissing} missing-at-build`);
  console.log(`  audit:    instance.import row recorded (file digest ${result.backupChecksum.slice(0, 16)}…)`);
  console.log("");
  console.log("NEXT STEPS:");
  console.log(`  1. Start the app, then log in as the workspace owner:`);
  console.log(`       email:    ${result.bootstrapEmail}`);
  if (GEN_PASSWORD) {
    console.log(`       password: ${password}`);
    console.log(`     (generated — store it securely; it is NOT printed again)`);
  } else {
    console.log(`       password: (the --password you provided)`);
  }
  console.log("  2. Change the owner password immediately after first login.");
  console.log("  3. Customers re-establish passwords through the owner (restore-engine policy).");
  console.log("  4. Re-complete the owner profile gate and re-activate a plan when ready.");
  console.log("");
  console.log(`ROLLBACK (if this import was a mistake): stop the app, then`);
  console.log(`  bun scripts/platform-restore.ts --restore ${basename(snapshotDir)} --confirm`);
}

main(FILE, EMAIL, BOOTSTRAP_PASSWORD, NAME, PACKAGE_ID).catch((error) => {
  console.error("import-backup failed:", error instanceof Error ? error.message : error);
  exit(1);
});
