/**
 * Ashrilogic — ROUND 113 codemod: Retry-After on every rate-limit 429.
 *
 * Rewrites the mechanical pattern in every API route:
 *
 *   if (await rateLimited(<key>, RULE [, opts])) {
 *     return NextResponse.json(
 *       { error: "...", ... },
 *       { status: 429 }
 *     );
 *   }
 *
 * into:
 *
 *   if (await rateLimited(<key>, RULE [, opts])) {
 *     return tooManyRequests(RULE, { error: "...", ... });
 *   }
 *
 * The RULE source text (2nd argument of the nearest rateLimited() call)
 * is carried into the helper call, so the headers always reflect the
 * actual rule (inline object literals included). The route's NextResponse
 * import stays (routes use it elsewhere); `tooManyRequests` is added to
 * the existing rate-limit import.
 *
 * Safety rails: only rewrites a 429 that (a) sits within 12 lines after a
 * rateLimited() guard and (b) parses as a balanced single NextResponse.json
 * call whose body is an object literal. tsc --noEmit + the full battery
 * re-verify the mechanical result.
 */
import { readFileSync, writeFileSync, readdirSync, statSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const API_ROOT = join(ROOT, "src", "app", "api");

function walk(dir: string): string[] {
  const out: string[] = [];
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    if (statSync(full).isDirectory()) out.push(...walk(full));
    else if (entry === "route.ts") out.push(full);
  }
  return out;
}

/** 2nd top-level argument of `rateLimited(...)` (balanced-bracket scan).
 *  Anchors on the rateLimited( paren itself — the line may carry other
 *  parens before it ("if (await ..."). */
function ruleArgOf(callText: string): string | null {
  const fn = callText.indexOf("rateLimited");
  if (fn < 0) return null;
  const open = callText.indexOf("(", fn);
  if (open < 0) return null;
  let depth = 0;
  let argIndex = 0;
  let argStart = -1;
  for (let i = open; i < callText.length && i < open + 2000; i++) {
    const ch = callText[i];
    if (ch === "(" || ch === "[" || ch === "{") {
      depth++;
      continue;
    }
    if (ch === ")" || ch === "]" || ch === "}") {
      depth--;
      if (depth === 0) {
        if (argIndex === 1 && argStart >= 0) return callText.slice(argStart, i).trim();
        return null;
      }
      continue;
    }
    if (ch === "," && depth === 1) {
      if (argIndex === 0) {
        argIndex = 1;
        argStart = i + 1;
      } else {
        return callText.slice(argStart, i).trim();
      }
    }
  }
  return null;
}

function collapse(text: string): string {
  return text.replace(/\s*\n\s*/g, " ").replace(/\s{2,}/g, " ").trim();
}

let filesChanged = 0;
let sitesRewritten = 0;
const manualReview: string[] = [];

for (const file of walk(API_ROOT)) {
  const source = readFileSync(file, "utf8");
  if (!source.includes("status: 429")) continue;
  if (!source.includes("rateLimited(")) {
    manualReview.push(file.replace(ROOT + "/", ""));
    continue; // 429 without a limiter — flag for manual review
  }

  const lines = source.split("\n");
  let changed = false;
  let pendingRule: string | null = null;
  let linesSinceGuard = 999;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.includes("rateLimited(")) {
      // capture the FULL call text (may span lines) then extract its rule
      const joined: string[] = [];
      let depth = 0;
      let balanced = false;
      for (let j = i; j < lines.length && j <= i + 8; j++) {
        joined.push(lines[j]);
        for (const ch of lines[j]) {
          if (ch === "(") depth++;
          else if (ch === ")") depth--;
        }
        if (depth <= 0) {
          balanced = true;
          break;
        }
      }
      if (!balanced) {
        pendingRule = null;
        linesSinceGuard = 999;
        continue;
      }
      pendingRule = ruleArgOf(joined.join("\n"));
      linesSinceGuard = 0;
      continue;
    }
    linesSinceGuard++;
    if (linesSinceGuard > 12) {
      pendingRule = null;
      continue;
    }
    if (!line.includes("status: 429")) continue;

    if (pendingRule == null) continue;

    // locate the nearest "NextResponse.json(" scanning back (≤12 lines)
    let start = -1;
    for (let k = i; k >= Math.max(0, i - 12); k--) {
      if (lines[k].includes("NextResponse.json(")) {
        start = k;
        break;
      }
    }
    if (start < 0) continue;

    // collect the full call text until brackets balance (≤20 lines)
    const block: string[] = [];
    let depth = 0;
    let end = -1;
    for (let k = start; k < Math.min(lines.length, start + 20); k++) {
      block.push(lines[k]);
      for (const ch of lines[k]) {
        if (ch === "(" || ch === "[" || ch === "{") depth++;
        else if (ch === ")" || ch === "]" || ch === "}") depth--;
      }
      if (depth <= 0) {
        end = k;
        break;
      }
    }
    if (end < 0) continue;

    const blockText = block.join("\n");
    const bodyMatch = blockText.match(
      /NextResponse\.json\(\s*([\s\S]*?),\s*\{\s*status:\s*429\s*\}\s*\)\s*;?\s*$/
    );
    if (!bodyMatch) continue;
    const bodyText = collapse(bodyMatch[1]);
    if (!(bodyText.startsWith("{") && bodyText.endsWith("}"))) continue; // safety: object literals only

    const indentMatch = /^\s*/.exec(lines[start]);
    const indent = indentMatch ? indentMatch[0] : "";
    const replacement = `${indent}return tooManyRequests(${collapse(pendingRule)}, ${bodyText});`;

    lines.splice(start, end - start + 1, replacement);
    changed = true;
    sitesRewritten++;
    i = start; // resync after the splice
    pendingRule = null;
    linesSinceGuard = 999;
  }

  if (changed) {
    let next = lines.join("\n");
    if (next.includes("tooManyRequests(")) {
      const importRe = /import\s*\{([^}]*)\}\s*from\s*"@\/lib\/server\/rate-limit"/;
      if (importRe.test(next)) {
        next = next.replace(importRe, (m, names: string) =>
          names.includes("tooManyRequests")
            ? m
            : `import {${names.trim()}, tooManyRequests } from "@/lib/server/rate-limit"`
        );
      } else {
        const firstImportEnd = next.indexOf("\n", next.indexOf("import "));
        next =
          next.slice(0, firstImportEnd + 1) +
          'import { tooManyRequests } from "@/lib/server/rate-limit";\n' +
          next.slice(firstImportEnd + 1);
      }
    }
    writeFileSync(file, next);
    filesChanged++;
    console.log(`rewrote: ${file.replace(ROOT + "/", "")}`);
  }
}

console.log(`\ncodemod done: ${sitesRewritten} sites across ${filesChanged} files`);
if (manualReview.length > 0) {
  console.log("MANUAL REVIEW (429 without rateLimited):");
  for (const f of manualReview) console.log("  - " + f);
}
