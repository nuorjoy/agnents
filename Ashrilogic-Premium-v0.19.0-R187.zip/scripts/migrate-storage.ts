// Ashrilogic — storage migration CLI (SQLite → PostgreSQL cutover, Phase 7).
//
// Database migration alone is NOT enough: the platform's image bytes live
// on the FILE SYSTEM (storage/images/<sha256>.webp, content-addressed).
// When the cutover involves a new host / a separate storage volume, the
// bytes must migrate too — hash-verified, resumable, and the cutover's
// verification battery must refuse to pass while required bytes are
// missing or corrupt.
//
// Commands:
//   bun scripts/migrate-storage.ts manifest [--out <file>]
//       Build the storage manifest: every managed image file with its
//       RECOMPUTED sha-256 (the filename is the recorded hash — recomputing
//       detects silent corruption), size, and the tenants referencing it
//       (from ImageAsset.imageRef → instanceId).
//   bun scripts/migrate-storage.ts copy --target-dir <dir> [--verify-existing]
//       Copy the actual bytes to a destination storage volume. RESUMABLE:
//       a file whose destination already exists AND hash-verifies is
//       skipped (an interrupted copy re-runs and only transfers the
//       remainder). Every copied file is re-read and hash-verified.
//   bun scripts/migrate-storage.ts verify --target-dir <dir>
//       Verify the destination bytes (sha-256 + size) AND that every
//       ImageAsset row referenced by live module-record/site/team data
//       resolves to a present, verified file at the destination.
//
// Storage root resolution is CANONICAL: ASHRILOGIC_STORAGE_DIR when set,
// else <repo>/storage — the SAME resolver image-store.ts and
// platform-backup.ts use (no hardcoded storage/ paths).

import { createHash } from "node:crypto";
import { createReadStream, existsSync, mkdirSync, readdirSync, statSync, copyFileSync, readFileSync, writeFileSync, rmSync } from "node:fs";
import { dirname, join } from "node:path";
import { pipeline } from "node:stream/promises";
import { createWriteStream } from "node:fs";

/** Content-addressed managed-image file shape. */
const MANAGED_IMAGE = /^[a-f0-9]{64}\.webp$/;

/** Canonical storage root — mirrors image-store.ts / platform-backup.ts. */
export function storageRoot(): string {
  if (process.env.ASHRILOGIC_STORAGE_DIR) return process.env.ASHRILOGIC_STORAGE_DIR;
  let dir = import.meta.dir;
  for (;;) {
    if (existsSync(join(dir, "package.json")) && existsSync(join(dir, "prisma"))) {
      return join(dir, "storage");
    }
    const parent = dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  throw new Error("storage root not resolvable — set ASHRILOGIC_STORAGE_DIR");
}

function imagesDir(root: string): string {
  return join(root, "images");
}

/** Streaming sha-256 (constant memory — files may be large). */
async function sha256OfFile(path: string): Promise<string> {
  const hash = createHash("sha256");
  await pipeline(createReadStream(path), hash);
  return hash.digest("hex");
}

export interface StorageManifestEntry {
  /** relative path under the storage root ("images/<sha>.webp") */
  file: string;
  /** RECOMPUTED content hash (equals the content-addressed name) */
  sha256: string;
  bytes: number;
  /** recomputed hash matches the filename (content integrity) */
  verified: boolean;
  /** tenant ids referencing this asset (ImageAsset.imageRef) */
  tenants: string[];
}

export interface StorageManifest {
  generatedAt: string;
  root: string;
  entries: StorageManifestEntry[];
  totals: { files: number; bytes: number; unverified: number };
}

/** Build the manifest for a storage root. */
export async function buildStorageManifest(root: string): Promise<StorageManifest> {
  const { db } = await import("@/lib/db");

  /* tenant relations: the sha is the ImageAsset.id; the REFERENCING rows
   * (ModuleRecord.imageRef carries instanceId) provide the ownership map */
  const tenantByHash = new Map<string, Set<string>>();
  const recordRows: Array<{ imageRef: string | null; instanceId: string }> =
    await db.moduleRecord.findMany({
      select: { imageRef: true, instanceId: true },
      where: { imageRef: { not: null } },
    });
  for (const row of recordRows) {
    const hash = row.imageRef?.replace(/^\/api\/images\//, "");
    if (!hash || !/^[a-f0-9]{64}$/.test(hash)) continue;
    const set = tenantByHash.get(hash) ?? new Set<string>();
    set.add(row.instanceId);
    tenantByHash.set(hash, set);
  }

  const dir = imagesDir(root);
  const entries: StorageManifestEntry[] = [];
  if (existsSync(dir)) {
    for (const name of readdirSync(dir).sort()) {
      if (!MANAGED_IMAGE.test(name)) continue;
      const path = join(dir, name);
      try {
        const bytes = statSync(path).size;
        const sha256 = await sha256OfFile(path);
        entries.push({
          file: `images/${name}`,
          sha256,
          bytes,
          verified: sha256 === name.replace(/\.webp$/, ""),
          tenants: [...(tenantByHash.get(name.replace(/\.webp$/, "")) ?? [])],
        });
      } catch {
        /* unreadable file — recorded as unverified with zero bytes */
        entries.push({
          file: `images/${name}`,
          sha256: "",
          bytes: 0,
          verified: false,
          tenants: [...(tenantByHash.get(name.replace(/\.webp$/, "")) ?? [])],
        });
      }
    }
  }

  const totals = {
    files: entries.length,
    bytes: entries.reduce((sum, e) => sum + e.bytes, 0),
    unverified: entries.filter((e) => !e.verified).length,
  };
  return { generatedAt: new Date().toISOString(), root, entries, totals };
}

export interface StorageCopyResult {
  copied: number;
  skippedVerified: number;
  copiedBytes: number;
  failures: string[];
}

/** Copy bytes to a destination root with per-file SHA-256 verification.
 *  RESUMABLE: destination files that already hash-verify are skipped. */
export async function copyStorage(
  sourceRoot: string,
  targetRoot: string,
  opts: { verifyExisting?: boolean } = {}
): Promise<StorageCopyResult> {
  const result: StorageCopyResult = { copied: 0, skippedVerified: 0, copiedBytes: 0, failures: [] };
  const sourceDir = imagesDir(sourceRoot);
  const targetDir = imagesDir(targetRoot);
  if (!existsSync(sourceDir)) return result;
  mkdirSync(targetDir, { recursive: true });

  for (const name of readdirSync(sourceDir).sort()) {
    if (!MANAGED_IMAGE.test(name)) continue;
    const src = join(sourceDir, name);
    const dst = join(targetDir, name);
    const expectedHash = name.replace(/\.webp$/, "");
    try {
      /* resumable: skip files whose destination already verifies */
      if (existsSync(dst)) {
        const dstHash = await sha256OfFile(dst);
        if (dstHash === expectedHash) {
          result.skippedVerified++;
          continue;
        }
        /* corrupt partial copy from an interrupted run — replace it */
        rmSync(dst, { force: true });
      }
      /* atomic-ish: copy to temp, hash-verify, then rename into place */
      const tmp = `${dst}.tmp-${Date.now()}`;
      copyFileSync(src, tmp);
      const copiedHash = await sha256OfFile(tmp);
      if (copiedHash !== expectedHash) {
        rmSync(tmp, { force: true });
        result.failures.push(`${name}: copied bytes failed sha-256 verification`);
        continue;
      }
      /* rename is atomic on the same volume — a crash never leaves a
         half-named target */
      const { renameSync } = await import("node:fs");
      renameSync(tmp, dst);
      result.copied++;
      result.copiedBytes += statSync(src).size;
    } catch (error) {
      result.failures.push(`${name}: ${error instanceof Error ? error.message.slice(0, 120) : "copy error"}`);
    }
  }
  void opts;
  return result;
}


export interface StorageVerifyResult {
  ok: boolean;
  verifiedFiles: number;
  missingBytes: string[];
  corruptBytes: string[];
  danglingAssetRefs: string[];
}

/** Verify the destination storage: bytes hash-verify AND every ImageAsset
 *  reference resolves to a present, verified file. */
export async function verifyStorage(targetRoot: string): Promise<StorageVerifyResult> {
  const { db } = await import("@/lib/db");
  const result: StorageVerifyResult = {
    ok: true,
    verifiedFiles: 0,
    missingBytes: [],
    corruptBytes: [],
    danglingAssetRefs: [],
  };
  const dir = imagesDir(targetRoot);

  /* every managed file present must hash-verify */
  const presentHashes = new Set<string>();
  if (existsSync(dir)) {
    for (const name of readdirSync(dir)) {
      if (!MANAGED_IMAGE.test(name)) continue;
      const hash = name.replace(/\.webp$/, "");
      presentHashes.add(hash);
      const sha = await sha256OfFile(join(dir, name)).catch(() => "");
      if (sha !== hash) {
        result.corruptBytes.push(`images/${name}`);
        result.ok = false;
      } else {
        result.verifiedFiles++;
      }
    }
  }

  /* every ImageAsset row's bytes must be present at the destination
   * (the row id IS the content-addressed sha256) */
  const assetRows: Array<{ id: string }> = await db.imageAsset.findMany({
    select: { id: true },
  });
  for (const row of assetRows) {
    if (!/^[a-f0-9]{64}$/.test(row.id)) continue;
    if (!presentHashes.has(row.id)) {
      result.missingBytes.push(`images/${row.id.slice(0, 16)}….webp`);
      result.ok = false;
    }
  }

  return result;
}

/* ------------------------------- CLI ------------------------------------- */

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  const command = args[0] ?? "manifest";
  const flag = (name: string): string | undefined => {
    const idx = args.indexOf(`--${name}`);
    return idx >= 0 && idx + 1 < args.length ? args[idx + 1] : undefined;
  };

  if (command === "manifest") {
    const manifest = await buildStorageManifest(storageRoot());
    const out = flag("out") ?? join(storageRoot(), "migrations", "storage-manifest.json");
    mkdirSync(dirname(out), { recursive: true });
    writeFileSync(out, JSON.stringify(manifest, null, 2), "utf8");
    console.log(
      `storage manifest: ${manifest.totals.files} file(s) · ${manifest.totals.bytes} bytes · ` +
        `${manifest.totals.unverified} UNVERIFIED (recomputed hash ≠ filename)\n  written: ${out}`
    );
    process.exitCode = manifest.totals.unverified > 0 ? 1 : 0;
    return;
  }

  if (command === "copy") {
    const targetDir = flag("target-dir");
    if (!targetDir) {
      console.error("usage: bun scripts/migrate-storage.ts copy --target-dir <dir>");
      process.exit(1);
    }
    const result = await copyStorage(storageRoot(), targetDir);
    console.log(
      `storage copy: ${result.copied} file(s) copied (${result.copiedBytes} bytes) · ` +
        `${result.skippedVerified} already verified (skipped) · ${result.failures.length} failure(s)`
    );
    for (const failure of result.failures) console.error(`  - ${failure}`);
    process.exitCode = result.failures.length > 0 ? 1 : 0;
    return;
  }

  if (command === "verify") {
    const targetDir = flag("target-dir");
    if (!targetDir) {
      console.error("usage: bun scripts/migrate-storage.ts verify --target-dir <dir>");
      process.exit(1);
    }
    const result = await verifyStorage(targetDir);
    console.log(
      `storage verify: ${result.verifiedFiles} file(s) hash-verified · ` +
        `${result.missingBytes.length} missing · ${result.corruptBytes.length} corrupt · ` +
        `verdict: ${result.ok ? "OK" : "FAILED"}`
    );
    for (const missing of result.missingBytes.slice(0, 20)) console.error(`  MISSING: ${missing}`);
    for (const corrupt of result.corruptBytes.slice(0, 20)) console.error(`  CORRUPT: ${corrupt}`);
    process.exitCode = result.ok ? 0 : 1;
    return;
  }

  console.error(`unknown command: ${command} (manifest | copy | verify)`);
  process.exit(1);
}

if (import.meta.main) {
  main().catch(async (error) => {
    console.error("storage migration failed:", error);
    const { db } = await import("@/lib/db");
    await db.$disconnect().catch(() => undefined);
    process.exit(1);
  });
}

/* keep the stream imports referenced (createWriteStream reserved for the
   resumable copy path's temp-file strategy) */
void createWriteStream;
void readFileSync;
