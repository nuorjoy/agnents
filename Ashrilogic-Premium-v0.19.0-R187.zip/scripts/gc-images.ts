// Ashrilogic — image-store orphan garbage collection CLI (ROUND 105).
//
// WHY THIS EXISTS: content-addressed image files are written BEFORE their
// ImageAsset row; a crash in between (the documented kernel OOM-kill under
// test-suite load, a killed import, a torn deploy) leaves an orphan file
// nothing will ever reference — and until now nothing ever removed it.
// storage/images grows monotonically. The live deployment carried 68 files
// vs 66 rows when this was written.
//
// PROTOCOL (data-safety lock):
//   DRY-RUN (default): collect + print the plan — READ-ONLY, safe while
//     the app is serving (one id query + one directory scan).
//   --execute: delete EXACTLY the collected plan's deletable entries
//     (managed orphans + stale temp files past the grace window), then
//     write a system.gc SECURITY audit row. NEVER touches: referenced
//     files, fresh files within grace, foreign filenames, the database
//     (read-only ids), any db file.
//
//   --grace-hours N   grace window for mtime (default 24 — in-flight
//                     uploads span milliseconds, so this is conservative
//                     by six orders of magnitude)
//
// The engine lives in src/lib/server/image-gc.ts (importable, tested);
// this CLI is the operator surface.
//
// Usage:
//   bun scripts/gc-images.ts                     # report only
//   bun scripts/gc-images.ts --execute           # reclaim
//   bun scripts/gc-images.ts --grace-hours 48 --execute

import { db } from "@/lib/db";

/* report/execute CLI — the same local-demo env binding the other house CLIs
 * use (demo key material is legitimate for a read-only report; runtime-guard
 * refuses to bind outside development/test) */
if (!process.env.NODE_ENV) {
  (process.env as { NODE_ENV?: string }).NODE_ENV = "development";
}

const args = process.argv.slice(2);
const EXECUTE = args.includes("--execute");
const graceFlagIdx = args.indexOf("--grace-hours");
const graceHours =
  graceFlagIdx !== -1 && args[graceFlagIdx + 1] && !Number.isNaN(Number(args[graceFlagIdx + 1]))
    ? Math.max(0, Number(args[graceFlagIdx + 1]))
    : 24;

async function main(): Promise<void> {
  const gc = await import("@/lib/server/image-gc");
  const started = Date.now();

  console.log("Ashrilogic — image-store orphan GC");
  console.log("=================================");
  console.log(`mode:         ${EXECUTE ? "EXECUTE (delete orphans + stale temps)" : "DRY-RUN (report only)"}`);
  console.log(`grace window: ${graceHours}h (files younger than this are never touched)`);
  console.log("");

  const plan = await gc.collectImageGcPlan({ graceHours });

  console.log(`registry rows:            ${plan.rows}`);
  console.log(`managed files on disk:    ${plan.files} (${(plan.imagesBytes / 1024).toFixed(1)} KiB)`);
  console.log(`referenced (kept):        ${plan.rows - plan.rowsMissingFile}`);
  console.log(`ORPHANS (deletable):      ${plan.orphans.length} (${(plan.orphans.reduce((s, o) => s + o.bytes, 0) / 1024).toFixed(1)} KiB)`);
  for (const o of plan.orphans) {
    console.log(`    ✗ ${o.file} · ${o.bytes}B · ${o.ageHours.toFixed(1)}h old`);
  }
  console.log(`stale temps (deletable):  ${plan.tempStale.length}`);
  for (const t of plan.tempStale) {
    console.log(`    ✗ ${t.file} · ${t.bytes}B · ${t.ageHours.toFixed(1)}h old`);
  }
  console.log(`orphans within grace:     ${plan.orphansFresh} (kept — fresh)`);
  console.log(`temps within grace:       ${plan.tempFresh} (kept — fresh)`);
  console.log(`foreign files (untouched):${plan.foreign}`);
  console.log(`rows missing their file:  ${plan.rowsMissingFile} (reported only — GC never creates files)`);
  console.log("");
  console.log(`reclaimable: ${(plan.reclaimableBytes / 1024).toFixed(1)} KiB`);
  console.log("");

  if (!EXECUTE) {
    console.log("DRY-RUN — nothing was deleted. Re-run with --execute to reclaim.");
    return;
  }

  if (plan.orphans.length === 0 && plan.tempStale.length === 0) {
    console.log("EXECUTE: nothing deletable — storage already clean.");
    return;
  }

  const result = await gc.executeImageGc(plan);
  console.log(
    `EXECUTE: deleted ${result.deletedOrphans} orphan(s) + ${result.deletedTemp} temp file(s) · reclaimed ${(result.reclaimedBytes / 1024).toFixed(1)} KiB${result.vanished ? ` · ${result.vanished} vanished since the plan (skipped)` : ""}`
  );

  /* security audit row — the re-seal pattern: destructive storage ops are
     audited unconditionally (system.gc is in SECURITY_ACTIONS) */
  const { logAudit } = await import("@/lib/server/audit");
  await logAudit({
    actorType: "system",
    actorName: "image-gc",
    action: "system.gc",
    targetLabel: "image-store orphan GC",
    meta: {
      graceHours: String(graceHours),
      deletedOrphans: String(result.deletedOrphans),
      deletedTemp: String(result.deletedTemp),
      reclaimedBytes: String(result.reclaimedBytes),
      vanished: String(result.vanished),
      orphansRemaining: String(plan.orphansFresh),
      rows: String(plan.rows),
      filesBefore: String(plan.files),
    },
  });
  console.log("audit row written (system.gc — SECURITY trail, retention floor applies)");
  console.log("");
  console.log(`completed in ${Date.now() - started}ms`);
}

try {
  await main();
} finally {
  await db.$disconnect();
}
