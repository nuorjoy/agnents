// Ashrilogic — audit-trail chain verifier (round 38 tamper-evidence).
//
// Thin CLI wrapper around the shared verification core
// (src/lib/server/audit-chain.ts — also covered by tests/security).
//
//   tampered:  row content changed after write (hash mismatch)
//   orphan:    prevChainHash points at a row that no longer exists
//              (predecessor deleted or corrupted)
//   fork:      multiple rows share one prevChainHash (race or splice)
//   gaps:      rows with NULL hashes — visible pre-chain history, never a
//              silent success
//
// Exit 0 = chain healthy (gaps allowed); exit 1 = tampering detected.
//
// `--repair` re-chains gap rows in creation order — use it ONCE after
// migrating a pre-chain database or after an ASHRILOGIC_DATA_KEY rotation.
// NEVER use --repair to "resolve" tampered/orphan/fork findings —
// re-chaining would launder exactly the tamper this tool exists to surface.

import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const repair = process.argv.includes("--repair");

interface Row {
  id: string;
  actorType: string;
  actorId: string | null;
  actorName: string;
  action: string;
  targetLabel: string | null;
  metaJson: string | null;
  createdAt: Date;
  prevChainHash: string | null;
  chainHash: string | null;
}

async function main(): Promise<void> {
  const { computeChainHash, verifyChainHashes } = await import(
    "@/lib/server/audit-chain"
  );

  const rows = (await db.auditLog.findMany({
    orderBy: [{ createdAt: "asc" }, { id: "asc" }],
  })) as Row[];

  if (rows.length === 0) {
    console.log("audit chain: no rows — nothing to verify.");
    return;
  }

  /* ROUND 96 — the recorded trust boundary (set by the retention sweeper
   * when it prunes chained rows): when present, verification resolves the
   * oldest retained row's backlink through it and requires the retained
   * chain to descend from it. */
  const anchorRow = await db.auditChainAnchor.findUnique({ where: { id: "global" } });
  const anchor = anchorRow ? { prevHash: anchorRow.anchorPrevHash } : null;

  const result = verifyChainHashes(rows, anchor);

  console.log(
    `audit chain: ${result.totalRows} row(s) · ${result.chainedRows} chained · ` +
      `${result.gapRows} gap(s) · head(s): ${result.heads}` +
      (anchor ? ` · anchored: yes (${anchor.prevHash.slice(0, 12)}…)` : " · anchored: no")
  );
  if (result.gapRows > 0 && !repair) {
    console.log(`  gaps: NULL-hash rows (pre-chain history — run --repair to chain them)`);
  }
  for (const t of result.tampered.slice(0, 10)) {
    console.log(`  TAMPERED: ${t.id} (${t.action} @ ${t.createdAt.toISOString()}) — content changed after write`);
  }
  for (const o of result.orphans.slice(0, 10)) {
    console.log(`  ORPHAN: ${o.id} (${o.action}) — predecessor missing (deleted or corrupted)`);
  }
  for (const f of result.forks.slice(0, 10)) {
    console.log(`  FORK: ${f.id} (${f.action}) — shares prevChainHash with another row`);
  }
  if (result.anchorMismatch) {
    console.log(
      `  ANCHOR MISMATCH: the oldest retained chained row does not descend from the recorded anchor — rows were removed below the trust boundary outside the retention sweep`
    );
  }

  const canRepair = result.gapRows > 0 && result.healthy;
  if (repair && canRepair) {
    const chained = rows.filter((r) => r.chainHash !== null);
    const gaps = rows.filter((r) => r.chainHash === null);
    let prev = chained.length > 0 ? (chained[chained.length - 1].chainHash as string) : null;
    for (const g of gaps) {
      const chainHash = computeChainHash({
        prevChainHash: prev,
        actorType: g.actorType,
        actorId: g.actorId,
        actorName: g.actorName,
        action: g.action,
        targetLabel: g.targetLabel,
        metaJson: g.metaJson,
        createdAtISO: g.createdAt.toISOString(),
      });
      await db.auditLog.update({
        where: { id: g.id },
        data: { prevChainHash: prev, chainHash },
      });
      prev = chainHash;
    }
    console.log(`repaired: ${gaps.length} gap row(s) chained in creation order.`);
  } else if (repair && result.gapRows > 0) {
    console.log("repair SKIPPED — resolve tampered/orphan/fork findings first (re-chaining would launder them).");
  }

  if (!result.healthy) {
    const bad = result.tampered.length + result.orphans.length + result.forks.length;
    console.log(`RESULT: FAIL — ${bad} integrity violation(s). Investigate before any repair.`);
    process.exitCode = 1;
    return;
  }
  console.log("RESULT: PASS — chain integrity verified.");
}

main()
  .then(() => db.$disconnect())
  .catch(async (error) => {
    console.error("audit chain verification failed:", error);
    await db.$disconnect();
    process.exit(1);
  });
