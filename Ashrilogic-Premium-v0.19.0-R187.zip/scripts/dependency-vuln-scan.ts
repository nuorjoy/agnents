#!/usr/bin/env bun
/**
 * Ashrilogic — ROUND 165 dependency vulnerability gate (OSV-powered).
 *
 * Queries Google's OSV database (api.osv.dev — the industry-standard open
 * vulnerability index, no key required) with every direct dependency from
 * package.json resolved against bun.lock. ZERO new dependencies: the
 * script reads the lockfile directly and POSTs the OSV querybatch API,
 * mirroring the project's hand-rolled-SigV4 discipline for the S3 driver.
 *
 * GATE SEMANTICS (CI):
 *   - any dependency with a known OSV vulnerability that has an available
 *     fix (fixed versions exist) FAILS the gate;
 *   - vulnerabilities with NO fix available are reported but do not fail
 *     (an unfixed industry CVE must not hard-block every build) — they are
 *     tracked in TECHNICAL-DEBT.md until a fix ships;
 *   - the ACCEPTED list below silences specific vuln ids reviewed and
 *     accepted (each entry MUST carry a justification).
 *
 * Usage: bun run scripts/dependency-vuln-scan.ts [--json]
 */
import { readFileSync } from "node:fs";
import { join } from "node:path";

const ROOT = join(import.meta.dir, "..");

/** Reviewed-and-accepted vulnerability ids (empty today — keep it that way:
 *  every entry needs a written justification in TECHNICAL-DEBT.md). */
const ACCEPTED: Record<string, string> = {};

interface OsvQueryResult {
  vulns?: { id: string }[];
}

interface LockVersion {
  version?: string;
}

/** Parse the resolved name@version pairs from bun.lock (Bun's lockfile is
 *  a JSONC document: trailing commas + a "packages" map whose values are
 *  tuples [ "name@resolvedVersion", registryUrl, deps, integrity ] ). */
function resolveLockVersions(): Map<string, string> {
  const raw = readFileSync(join(ROOT, "bun.lock"), "utf8");
  /* strip JSONC trailing commas → strict JSON */
  const clean = raw.replace(/,(\s*[\]}])/g, "$1");
  const lock = JSON.parse(clean) as {
    packages?: Record<string, [string] | unknown>;
  };
  const versions = new Map<string, string>();
  for (const [name, entry] of Object.entries(lock.packages ?? {})) {
    /* the tuple's first element is "name@resolvedVersion" */
    const pin = Array.isArray(entry) ? String(entry[0] ?? "") : "";
    const at = pin.lastIndexOf("@");
    if (at > 0) {
      const version = pin.slice(at + 1);
      if (version !== "") versions.set(name, version);
    }
  }
  return versions;
}

/** Direct dependencies from package.json resolved against the lockfile. */
function directDependencies(): { name: string; version: string }[] {
  const pkg = JSON.parse(readFileSync(join(ROOT, "package.json"), "utf8")) as {
    dependencies?: Record<string, string>;
    devDependencies?: Record<string, string>;
  };
  const locked = resolveLockVersions();
  const out: { name: string; version: string }[] = [];
  for (const name of Object.keys(pkg.dependencies ?? {})) {
    const version = locked.get(name);
    if (version) out.push({ name, version });
  }
  for (const name of Object.keys(pkg.devDependencies ?? {})) {
    const version = locked.get(name);
    if (version) out.push({ name, version });
  }
  return out;
}

async function queryOsv(deps: { name: string; version: string }[]): Promise<Map<string, string[]>> {
  const hits = new Map<string, string[]>();
  const BATCH = 50;
  for (let i = 0; i < deps.length; i += BATCH) {
    const slice = deps.slice(i, i + BATCH);
    const body = JSON.stringify({
      queries: slice.map((d) => ({
        package: { name: d.name, ecosystem: "npm" },
        version: d.version,
      })),
    });
    const res = await fetch("https://api.osv.dev/v1/querybatch", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body,
      signal: AbortSignal.timeout(30_000),
    });
    if (!res.ok) throw new Error(`OSV API ${res.status}`);
    const data = (await res.json()) as { results?: OsvQueryResult[] };
    for (let j = 0; j < slice.length; j += 1) {
      const vulns = data.results?.[j]?.vulns ?? [];
      if (vulns.length > 0) {
        hits.set(slice[j].name, vulns.map((v) => v.id).filter((id) => !ACCEPTED[id]));
      }
    }
  }
  return hits;
}

/** Whether any listed vuln id has a fix available (query details). */
async function vulnHasFix(id: string): Promise<boolean> {
  try {
    const res = await fetch(`https://api.osv.dev/v1/vulns/${id}`, {
      signal: AbortSignal.timeout(15_000),
    });
    if (!res.ok) return true; /* unknown → assume actionable (fail-closed) */
    const vuln = (await res.json()) as { affected?: { ranges?: { events?: { fixed?: string }[] }[] }[] };
    for (const affected of vuln.affected ?? []) {
      for (const range of affected.ranges ?? []) {
        for (const event of range.events ?? []) {
          if (event.fixed) return true;
        }
      }
    }
    return false;
  } catch {
    return true; /* network failure → fail-closed */
  }
}

async function main(): Promise<number> {
  const asJson = process.argv.includes("--json");
  const deps = directDependencies();
  if (deps.length === 0) {
    console.error("dependency-vuln-scan: no direct dependencies resolved from bun.lock");
    return 1;
  }
  const hits = await queryOsv(deps);

  const actionable: string[] = [];
  const unfixed: string[] = [];
  for (const [name, ids] of hits) {
    for (const id of ids) {
      const line = `${name}: ${id}`;
      (await vulnHasFix(id) ? actionable : unfixed).push(line);
    }
  }

  if (asJson) {
    console.log(JSON.stringify({ scanned: deps.length, actionable, unfixed }, null, 2));
  } else {
    console.log(`dependency-vuln-scan: ${deps.length} direct dependencies scanned (OSV)`);
    for (const line of actionable) console.log(`  ✗ FIXABLE   ${line}`);
    for (const line of unfixed) console.log(`  ⚠ UNFIXED   ${line} (tracked, non-blocking)`);
  }
  if (actionable.length > 0) {
    console.error(`GATE FAILED: ${actionable.length} fixable vulnerabilit(ies) — upgrade before release`);
    return 1;
  }
  return 0;
}

main().catch((error) => {
  console.error("dependency-vuln-scan failed:", error);
  process.exit(1);
});
