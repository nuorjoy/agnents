/**
 * Ashrilogic — ROUND 172 — set KNOWN documented credentials.
 *
 * Rotates every platform-admin and workspace-owner login to a strong,
 * documented password (Argon2id, OWASP parameters via crypto-vault) so the
 * owner holds precise working credentials for the production deployment:
 *
 *   DATABASE_URL="<neon prod>" \
 *   INIT_ADMIN_PASSWORD='…' ADMIN_PASSWORDS='sara.ops:…,omar.mod:…,lina.view:…' \
 *   OWNER_PASSWORD_DEFAULT='…' OWNER_PASSWORDS='school-management:…,hotel-management:…' \
 *   bun scripts/set-known-credentials.ts [--include-admins] [--include-owners]
 *
 * Safety laws:
 *  - refuses weak passwords (≥12 chars, mixed classes — same bar as
 *    bootstrap-admin);
 *  - bumps sessionVersion on every rotation → ALL outstanding sessions for
 *    that subject die instantly (epoch invalidation, ROUND 36);
 *  - never logs the secrets to the database or any file — the table is
 *    printed ONCE to the operator's stdout;
 *  - idempotent: re-running re-hashes the same documented values.
 *
 * The owner-visible credential sheet (this exact table) is delivered in the
 * final report — never committed to the repository.
 */
import { PrismaClient } from "@prisma/client";
import { hashPasswordArgon2id } from "../src/lib/server/crypto-vault";
import { readAdminEmail } from "../src/lib/server/instance-mapper";

/* ----------------------- documented credential manifest ------------------ */

/**
 * Platform control-panel accounts (username → password).
 *
 * SECRETS NEVER LIVE IN THE REPO: passwords come from ENVIRONMENT
 * variables (OWNER_PASSWORDS as a `username:password,username:password`
 * list; INIT_ADMIN_PASSWORD for the super admin). The operator supplies
 * them at run time and receives the sheet on stdout — nothing here is a
 * default secret.
 */
function parseOwnerPasswordList(raw: string | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  if (!raw) return out;
  for (const pair of raw.split(",")) {
    const idx = pair.indexOf(":");
    if (idx <= 0) continue;
    const user = pair.slice(0, idx).trim();
    const pw = pair.slice(idx + 1).trim();
    if (user && pw) out[user] = pw;
  }
  return out;
}

const envAdminList = parseOwnerPasswordList(process.env.ADMIN_PASSWORDS);
const ADMIN_CREDENTIALS: Record<string, string> = {
  admin: process.env.INIT_ADMIN_PASSWORD ?? envAdminList["admin"] ?? "",
  "sara.ops": envAdminList["sara.ops"] ?? "",
  "omar.mod": envAdminList["omar.mod"] ?? "",
  "lina.view": envAdminList["lina.view"] ?? "",
};

/** Workspace owners by SYSTEM ID (catalog id — stable across re-seeds,
 *  unlike the row id). OWNER_PASSWORDS carries `systemId:password` pairs;
 *  OWNER_PASSWORD_DEFAULT applies to every system not listed. */
const envOwnerList = parseOwnerPasswordList(process.env.OWNER_PASSWORDS);
const OWNER_DEFAULT = process.env.OWNER_PASSWORD_DEFAULT ?? "";
const OWNER_SYSTEM_IDS = [
  "school-management",
  "restaurant-management",
  "hotel-management",
  "pharmacy-management",
  "dental-clinic",
  "hospital-management",
  "logistics-company",
];

/** Strong-password bar (bootstrap-admin parity). */
function isStrong(pw: string): boolean {
  return (
    pw.length >= 12 &&
    /[a-z]/.test(pw) &&
    /[A-Z]/.test(pw) &&
    /[0-9]/.test(pw) &&
    /[^A-Za-z0-9]/.test(pw)
  );
}

async function main(): Promise<void> {
  const db = new PrismaClient();
  const includeAdmins = process.argv.includes("--include-admins");
  const includeOwners = process.argv.includes("--include-owners");
  const includeAll = !includeAdmins && !includeOwners;

  const rows: Array<{ surface: string; account: string; login: string; password: string; note: string }> = [];

  try {
    if (includeAll || includeAdmins) {
      for (const [username, password] of Object.entries(ADMIN_CREDENTIALS)) {
        if (!password) {
          console.warn(`⚠ no password supplied for admin "${username}" (ADMIN_PASSWORDS / INIT_ADMIN_PASSWORD) — skipped`);
          continue;
        }
        if (!isStrong(password)) throw new Error(`weak password for admin "${username}"`);
        const row = await db.adminUser.findUnique({ where: { username } });
        if (!row) {
          console.warn(`⚠ admin "${username}" not found — skipped`);
          continue;
        }
        await db.adminUser.update({
          where: { id: row.id },
          data: {
            passwordHash: hashPasswordArgon2id(password),
            /* epoch bump — every outstanding admin session dies now */
            sessionVersion: { increment: 1 },
          },
        });
        rows.push({
          surface: "لوحة Super Admin (/admin/login)",
          account: `${row.name} · ${row.role}`,
          login: username,
          password,
          note: "قُدِّرت بكلمة مرور جديدة — كل الجلسات القديمة أُبطلت",
        });
        console.log(`✓ admin "${username}" rotated`);
      }
    }

    if (includeAll || includeOwners) {
      const instances = await db.instance.findMany({
        where: { deletedAt: null },
        select: { id: true, systemId: true, adminJson: true, sessionVersion: true },
      });
      for (const inst of instances) {
        const password = envOwnerList[inst.systemId] ?? OWNER_DEFAULT;
        if (!password) {
          console.warn(`⚠ no password supplied for systemId "${inst.systemId}" (OWNER_PASSWORDS / OWNER_PASSWORD_DEFAULT) — skipped`);
          continue;
        }
        if (!isStrong(password)) throw new Error(`weak password for owner "${inst.systemId}"`);
        /* the login email is SEALED at rest (AES-256-GCM) — decrypt for the
           operator sheet only (never persisted anywhere) */
        const email = readAdminEmail(inst.adminJson);
        let admin: { name?: string } = {};
        try {
          admin = JSON.parse(inst.adminJson ?? "{}");
        } catch {
          /* keep empty */
        }
        if (!email) {
          console.warn(`⚠ instance ${inst.id} carries no readable admin email — skipped`);
          continue;
        }
        await db.instance.update({
          where: { id: inst.id },
          data: {
            passwordHash: hashPasswordArgon2id(password),
            sessionVersion: { increment: 1 },
          },
        });
        rows.push({
          surface: "نظام المستأجر (/login)",
          account: `${admin.name ?? "مالك النظام"} · ${inst.systemId}`,
          login: email,
          password,
          note: "الدخول ببريد مالك النظام",
        });
        console.log(`✓ owner "${inst.systemId}" (${email}) rotated`);
      }
    }

    console.log("\n================= بيانات الدخول الموثقة =================");
    for (const r of rows) {
      console.log(`\n• ${r.surface}`);
      console.log(`  الحساب: ${r.account}`);
      console.log(`  اسم الدخول: ${r.login}`);
      console.log(`  كلمة المرور: ${r.password}`);
      if (r.note) console.log(`  ملاحظة: ${r.note}`);
    }
    console.log("\n(لا تُخزَّن هذه الجداول في أي ملف — القناة فقط)");
  } finally {
    await db.$disconnect();
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
