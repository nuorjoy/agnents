// Ashrilogic — ROUND 166 one-off SAMS module backfill (التسكين + المرافق والخدمات + الحضور والغياب).
//
// The owner's directive: the Student Accommodation system (إدارة السكن
// الطلابي, system 102) gains three dedicated premium modules —
//   • التسكين (roomAssignments) — bed-level student housing, term-scoped;
//   • المرافق والخدمات (facilities) — dorm facilities & services;
//   • الحضور والغياب (attendance) — the dedicated 8-state attendance
//     console (movements + policy + allowances + QR).
//
// The catalog resolver covers NEW instances immediately (the wizard draft
// starts from systemMods). EXISTING student-accommodation instances keep
// their persisted modulesJson — this script appends ALL THREE modules (enabled,
// in catalog display order relative to their neighbors) so every live SAMS
// workspace surfaces them in the الوحدات control right away. Instances of
// any OTHER system are untouched.
//
// Idempotent: re-running changes nothing once the modules are present.
// No data migration, no schema change — modulesJson only.
//
// Usage:
//   DATABASE_URL="postgresql://…" bun scripts/backfill-r166-sams-modules.ts

import { PrismaClient } from "@prisma/client";
import { SYSTEM_MAP, systemMods } from "@/data/catalog";

async function main(): Promise<void> {
  const db = new PrismaClient();
  try {
    const url = process.env.DATABASE_URL ?? "(default)";
    console.log(`R166 SAMS module backfill → ${url}`);

    const instances = await db.instance.findMany({
      where: { deletedAt: null, systemId: "student-accommodation" },
      select: { id: true, systemId: true, modulesJson: true },
    });

    let assigned = 0;
    let faciliated = 0;
    let attended = 0;
    let untouched = 0;

    for (const row of instances) {
      let modules: string[] = [];
      try {
        const parsed = JSON.parse(row.modulesJson ?? "[]") as unknown;
        if (Array.isArray(parsed)) modules = parsed.map((m) => String(m));
      } catch {
        modules = [];
      }
      const catalog = systemMods(SYSTEM_MAP[row.systemId]);
      const next = modules.slice();
      let changed = false;

      // Insert each missing module at its CATALOG position so the module
      // grid order stays canonical (dormRooms → roomAssignments →
      // residents → leases → facilities → maintenance → security →
      // attendance → payments…).
      const PLAN: Array<{ mod: string; anchor: string }> = [
        { mod: "roomAssignments", anchor: "residents" },
        { mod: "facilities", anchor: "maintenance" },
        { mod: "attendance", anchor: "payments" },
      ];
      for (const { mod, anchor } of PLAN) {
        if (!catalog.includes(mod) || next.includes(mod)) continue;
        const anchorIdx = next.indexOf(anchor);
        if (anchorIdx === -1) next.push(mod);
        else next.splice(anchorIdx, 0, mod);
        if (mod === "roomAssignments") assigned += 1;
        else if (mod === "facilities") faciliated += 1;
        else attended += 1;
        changed = true;
      }

      if (changed) {
        await db.instance.update({
          where: { id: row.id },
          data: { modulesJson: JSON.stringify(next) },
        });
      } else {
        untouched += 1;
      }
    }

    console.log(
      `backfill complete: ${instances.length} SAMS instance(s) · +التسكين on ${assigned} · +المرافق والخدمات on ${faciliated} · +الحضور والغياب on ${attended} · ${untouched} already aligned`
    );
  } finally {
    await db.$disconnect();
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
