// Ashrilogic — ROUND 134 one-off module backfill (الورديات + المصروفات).
//
// The owner's directives:
//   «في جميع الأنظمة الـ100 عند (الوحدات) أضف (الورديات) يمكن تفعيله او
//    ايقافه نفس طريقة تحكم الوحدات»  →  the "shifts" module became a
//   first-class toggleable module appended to EVERY system's catalog
//   (src/data/catalog.ts systemMods()).
//   «إذا هناك نظام وحداته لا يحتوي على (المصروفات) قم بإضافة»  →  the
//   "expenses" module is likewise universal (only the finance category
//   curated it natively before).
//
// The RESOLVER change covers NEW instances immediately (the wizard draft
// starts from systemMods). EXISTING instances keep their persisted
// modulesJson — this script appends BOTH modules (when the instance's
// system offers them, which after R134 is always) so:
//   • الورديات stays ENABLED by default → the R133 strict shift law keeps
//     enforcing on every existing workspace, and the owner can now turn it
//     OFF per-instance from the الوحدات control (the whole point);
//   • المصروفات lands ENABLED → the premium expenses workspace (the
//     curated EXP preset) is immediately usable in every system.
//
// Idempotent: re-running changes nothing once the modules are present.
// No data migration, no schema change — modulesJson only.
//
// Usage:
//   DATABASE_URL="file:/absolute/path/to/db/custom.db" \
//     bun scripts/backfill-r134-modules.ts

import { PrismaClient } from "@prisma/client";
import { SYSTEM_MAP, systemMods } from "@/data/catalog";

async function main(): Promise<void> {
  const db = new PrismaClient();
  try {
    const url = process.env.DATABASE_URL ?? "(default)";
    console.log(`R134 module backfill → ${url}`);

    const instances = await db.instance.findMany({
      where: { deletedAt: null },
      select: { id: true, systemId: true, modulesJson: true },
    });

    let shifted = 0;
    let expensed = 0;
    let untouched = 0;

    for (const row of instances) {
      let modules: string[] = [];
      try {
        const parsed = JSON.parse(row.modulesJson ?? "[]") as unknown;
        if (Array.isArray(parsed)) modules = parsed.map((m) => String(m));
      } catch {
        modules = [];
      }
      const catalog = new Set(systemMods(SYSTEM_MAP[row.systemId]));
      const next = modules.slice();
      let changed = false;

      if (catalog.has("shifts") && !next.includes("shifts")) {
        next.push("shifts");
        shifted += 1;
        changed = true;
      }
      if (catalog.has("expenses") && !next.includes("expenses")) {
        next.push("expenses");
        expensed += 1;
        changed = true;
      }

      if (changed) {
        await db.instance.update({
          where: { id: row.id },
          data: { modulesJson: JSON.stringify(next) },
        });
      } else {
        untouched += 1;
      }
    }

    console.log(
      `backfill complete: ${instances.length} live instance(s) · +shifts on ${shifted} · +expenses on ${expensed} · ${untouched} already aligned`
    );
  } finally {
    await db.$disconnect();
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
