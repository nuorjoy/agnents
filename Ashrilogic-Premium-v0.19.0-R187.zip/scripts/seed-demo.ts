// Ashrilogic — one-off fresh-database demo seeding.
//
// Prepares a PRISTINE demo database (admin account, platform settings,
// packages, backdated showcase subscribers, module records, sites) without
// running the dev server — used to ship a ready-to-run snapshot:
//
//   DATABASE_URL="file:/absolute/path/to/db/ashrilogic.db" \
//     bun scripts/seed-demo.ts
//
// Idempotent and safe to re-run (same guards the app uses at runtime).
// Demo content only materializes when NODE_ENV is not "production".

import { PrismaClient } from "@prisma/client";
import { seedAdminDefaults, seedDemoInstances } from "@/lib/server/admin-mapper";

async function main(): Promise<void> {
  const db = new PrismaClient();
  try {
    const url = process.env.DATABASE_URL ?? "(default)";
    console.log(`seeding demo content → ${url}`);
    await seedAdminDefaults(db);
    await seedDemoInstances(db);
    const [admins, instances, packages, sites] = await Promise.all([
      db.adminUser.count(),
      db.instance.count(),
      db.package.count(),
      db.site.count(),
    ]);
    console.log(
      `seeded: ${admins} admin(s) · ${instances} instance(s) · ${packages} package(s) · ${sites} site(s)`
    );
  } finally {
    await db.$disconnect();
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
