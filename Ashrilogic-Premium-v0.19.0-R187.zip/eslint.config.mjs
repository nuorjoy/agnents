import nextCoreWebVitals from "eslint-config-next/core-web-vitals";
import nextTypescript from "eslint-config-next/typescript";
import { dirname, resolve as pathResolve } from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

/**
 * Ashrilogic — ESLint flat config (security pass 3-d: gradual rule
 * restoration). Baseline = eslint-config-next (core-web-vitals + typescript,
 * i.e. the Next.js default: react + react-hooks + @next/next + jsx-a11y +
 * import + typescript-eslint/recommended). Every override below was measured
 * against the codebase before being restored; a rule stays OFF only where
 * re-enabling it produces > 20 violations (justified inline).
 */

/* ------------------------------------------------------------------ */
/* ROUND 162+ — architecture-enforcement plugin (the P2-4 ratchet).     */
/*                                                                    */
/* Two boundary rules, both structural:                                */
/*  1. no-db-in-route-handler — an API route.ts may not import the     */
/*     Prisma client directly: persistence belongs behind a domain     */
/*     repository/service (src/server/domains/*) or a lib/server       */
/*     service. The rule matches EVERY import form that reaches the    */
/*     module — static import, dynamic import(), require(), re-export  */
/*     (export … from / export * from) — and resolves BOTH the @/      */
/*     alias and RELATIVE paths, so the boundary cannot be sidestepped */
/*     by rewriting `import { db } from "@/lib/db"` into              */
/*     `await import("@/lib/db")` or `../../lib/db`. The frozen        */
/*     legacy set below is grandfathered (the P1-2 migration wave      */
/*     shrinks this list); entries are NEVER added — a new route       */
/*     importing db in ANY form fails lint and must go through the     */
/*     domain architecture.                                           */
/*  2. no-server-only-in-client — a "use client" file may not import   */
/*     @/lib/db or @/lib/server/** (server-only infrastructure: node   */
/*     built-ins, DB handles, sealed secrets) through any of the same */
/*     import forms. Current violations: 0.                           */
const LEGACY_DB_ROUTES = new Set([
  "src/app/api/admin/activities/route.ts",
  "src/app/api/admin/admins/[id]/route.ts",
  "src/app/api/admin/admins/route.ts",
  "src/app/api/admin/audit/route.ts",
  "src/app/api/admin/blog/[id]/route.ts",
  "src/app/api/admin/blog/route.ts",
  "src/app/api/admin/instances/[id]/ops/route.ts",
  "src/app/api/admin/instances/[id]/sessions/revoke-all/route.ts",
  "src/app/api/admin/login/mfa/route.ts",
  "src/app/api/admin/login/route.ts",
  "src/app/api/admin/logout/route.ts",
  "src/app/api/admin/mail/logs/route.ts",
  "src/app/api/admin/me/password/route.ts",
  "src/app/api/admin/newsletter/route.ts",
  "src/app/api/admin/notifications/route.ts",
  "src/app/api/admin/ops/route.ts",
  "src/app/api/admin/partners/[id]/route.ts",
  "src/app/api/admin/partners/route.ts",
  "src/app/api/admin/passkey-login/route.ts",
  "src/app/api/admin/reset-demo/route.ts",
  "src/app/api/admin/security-policy/route.ts",
  "src/app/api/admin/settings/route.ts",
  "src/app/api/admin/sites/[id]/customers/[customerId]/route.ts",
  "src/app/api/admin/sites/[id]/customers/route.ts",
  "src/app/api/admin/sites/[id]/inquiries/[ticketId]/route.ts",
  "src/app/api/admin/sites/[id]/inquiries/route.ts",
  "src/app/api/admin/sites/[id]/route.ts",
  "src/app/api/admin/sites/route.ts",
  "src/app/api/admin/sites/trends/route.ts",
  "src/app/api/admin/stores/route.ts",
  "src/app/api/admin/subscribers/[id]/route.ts",
  "src/app/api/admin/tickets/[id]/route.ts",
  "src/app/api/admin/tickets/route.ts",
  "src/app/api/blog/[slug]/route.ts",
  "src/app/api/blog/route.ts",
  "src/app/api/healthz/route.ts",
  "src/app/api/identity/route.ts",
  "src/app/api/instances/[id]/activities/route.ts",
  "src/app/api/instances/[id]/ai/insights/route.ts",
  "src/app/api/instances/[id]/auth/login/route.ts",
  "src/app/api/instances/[id]/auth/passkey/route.ts",
  "src/app/api/instances/[id]/auth/session/route.ts",
  "src/app/api/instances/[id]/export/route.ts",
  "src/app/api/instances/[id]/favicon.png/route.ts",
  "src/app/api/instances/[id]/loyalty/resync/route.ts",
  "src/app/api/instances/[id]/members/[memberId]/route.ts",
  "src/app/api/instances/[id]/members/route.ts",
  "src/app/api/instances/[id]/module-records/[recordId]/route.ts",
  "src/app/api/instances/[id]/module-records/route.ts",
  "src/app/api/instances/[id]/orders/[orderId]/route.ts",
  "src/app/api/instances/[id]/orders/route.ts",
  "src/app/api/instances/[id]/owner-profile/route.ts",
  "src/app/api/instances/[id]/route.ts",
  "src/app/api/instances/[id]/self-disable/route.ts",
  "src/app/api/instances/[id]/shifts/close/route.ts",
  "src/app/api/instances/[id]/shifts/code/route.ts",
  "src/app/api/instances/[id]/shifts/route.ts",
  "src/app/api/instances/[id]/site/customers/[customerId]/route.ts",
  "src/app/api/instances/[id]/site/customers/route.ts",
  "src/app/api/instances/[id]/site/inquiries/[ticketId]/route.ts",
  "src/app/api/instances/[id]/site/inquiries/route.ts",
  "src/app/api/instances/[id]/site/route.ts",
  "src/app/api/instances/[id]/site/translate/route.ts",
  "src/app/api/instances/[id]/store/coupons/[couponId]/route.ts",
  "src/app/api/instances/[id]/store/coupons/route.ts",
  "src/app/api/instances/[id]/store/media/route.ts",
  "src/app/api/instances/[id]/store/reviews/[reviewId]/route.ts",
  "src/app/api/instances/[id]/store/reviews/route.ts",
  "src/app/api/instances/[id]/store/route.ts",
  "src/app/api/instances/[id]/tickets/route.ts",
  "src/app/api/instances/[id]/usage/route.ts",
  "src/app/api/instances/[id]/webhooks/[webhookId]/route.ts",
  "src/app/api/instances/[id]/webhooks/route.ts",
  "src/app/api/instances/auth/login/mfa/route.ts",
  "src/app/api/instances/auth/login/route.ts",
  "src/app/api/instances/auth/passkey-login/route.ts",
  "src/app/api/instances/check-availability/route.ts",
  "src/app/api/instances/mine/route.ts",
  "src/app/api/instances/mine/verify-password/route.ts",
  "src/app/api/instances/route.ts",
  "src/app/api/partners/route.ts",
  "src/app/api/readyz/route.ts",
  "src/app/api/sites/[id]/account/avatar/route.ts",
  "src/app/api/sites/[id]/account/check-username/route.ts",
  "src/app/api/sites/[id]/account/forgot/route.ts",
  "src/app/api/sites/[id]/account/inquiries/route.ts",
  "src/app/api/sites/[id]/account/login/route.ts",
  "src/app/api/sites/[id]/account/orders/route.ts",
  "src/app/api/sites/[id]/account/register/route.ts",
  "src/app/api/sites/[id]/account/reset/route.ts",
  "src/app/api/sites/[id]/account/route.ts",
  "src/app/api/sites/[id]/account/verify/route.ts",
  "src/app/api/sites/[id]/contact/route.ts",
  "src/app/api/sites/[id]/store-qr/route.ts",
  "src/app/api/sites/[id]/visit/route.ts",
  "src/app/api/status/route.ts",
  "src/app/api/subscribe/route.ts",
  "src/app/api/support/route.ts",
  "src/app/api/testimonials/route.ts"
]);

/* ---------------- module-source resolution (bypass-proof) ------------- */
/* The bundler resolves three textual shapes onto one module: the "@/" alias
 * (tsconfig paths), relative specifiers, and (exotic) absolute-from-root.
 * The boundary rules resolve each import form through THIS one function so
 * switching `from "@/lib/db"` to `from "../../lib/db"` cannot dodge them. */

function toPosix(p) {
  return p.replace(/\\/g, "/");
}

/** Resolve an import specifier against the importing file the way the
 *  bundler would; returns a POSIX absolute module path WITHOUT extension,
 *  or null for bare package specifiers (never ours). */
function resolveModuleSource(source, filename) {
  if (typeof source !== "string" || source.length === 0) return null;
  let base = null;
  if (source.startsWith("@/")) {
    base = pathResolve(__dirname, "src", source.slice(2));
  } else if (source.startsWith("./") || source.startsWith("../")) {
    base = pathResolve(dirname(filename), source);
  } else if (source.startsWith("/src/")) {
    base = pathResolve(__dirname, source.slice(1));
  } else {
    return null; // bare specifier (node_modules package)
  }
  return toPosix(base);
}

/** True when the resolved module path IS src/lib/db (src/lib/db.ts or
 *  src/lib/db/index.ts). */
function isDbModulePath(resolved) {
  return resolved !== null && /\/src\/lib\/db(\/index)?$/.test(resolved);
}

/** True when the resolved module path lives under src/lib/server/. */
function isServerModulePath(resolved) {
  return resolved !== null && /\/src\/lib\/server(\/|$)/.test(resolved);
}

/* The literal specifier of an import-ish node, covering EVERY syntactic
 * form the language offers for reaching another module:
 *   ImportDeclaration / ExportNamedDeclaration(source) / ExportAllDeclaration
 *     → node.source.value
 *   ImportExpression (`await import("…")`) → node.source.value
 *   CallExpression with callee `import` (older ASTs) → arguments[0]
 *   CallExpression with callee `require("…")` (CommonJS) → arguments[0]  */
function specifierOf(node) {
  if (!node) return null;
  if (node.type === "ImportDeclaration" || node.type === "ExportNamedDeclaration" || node.type === "ExportAllDeclaration") {
    return node.source ? node.source.value : null;
  }
  if (node.type === "ImportExpression") {
    return node.source && node.source.type === "Literal" ? node.source.value : null;
  }
  if (node.type === "CallExpression") {
    const callee = node.callee;
    const isImportCall = callee && callee.type === "Import";
    const isRequireCall = callee && callee.type === "Identifier" && callee.name === "require";
    if (!isImportCall && !isRequireCall) return null;
    const arg = node.arguments && node.arguments[0];
    return arg && arg.type === "Literal" ? arg.value : null;
  }
  return null;
}

/** The shared visitor builder: reports every node whose import specifier
 *  resolves into the forbidden module set. `forbidden(resolved)` decides
 *  which boundaries this rule enforces. */
function importBoundaryVisitor(context, forbidden) {
  const filename = (context.filename ?? "").replace(/\\/g, "/");
  const check = (node) => {
    const spec = specifierOf(node);
    if (typeof spec !== "string") return;
    const resolved = resolveModuleSource(spec, filename);
    if (forbidden(resolved)) {
      context.report({ node, messageId: "forbiddenImport", data: { source: spec } });
    }
  };
  return {
    ImportDeclaration: check,
    ImportExpression: check,
    ExportNamedDeclaration: check,
    ExportAllDeclaration: check,
    CallExpression: check,
  };
}

const architecturePlugin = {
  rules: {
    "no-db-in-route-handler": {
      meta: {
        type: "problem",
        docs: { description: "API route handlers must not import the Prisma client directly in ANY form (static, dynamic, require, re-export, alias or relative) — use a domain repository/service" },
        schema: [],
        messages: {
          forbiddenImport:
            "route.ts reaches @/lib/db via \"{{source}}\" — persistence belongs in a domain repository/service (src/server/domains/*). New routes must not be added to the legacy allowlist in eslint.config.mjs.",
        },
      },
      create(context) {
        const filename = (context.filename ?? "").replace(/\\/g, "/");
        const match = filename.match(/(src\/app\/api\/.*\/route\.tsx?)$/);
        if (!match) return {};
        if (LEGACY_DB_ROUTES.has(match[1])) return {};
        return importBoundaryVisitor(context, isDbModulePath);
      },
    },
    "no-server-only-in-client": {
      meta: {
        type: "problem",
        docs: { description: '"use client" modules must not import server-only infrastructure (@/lib/db, @/lib/server/**) in ANY import form' },
        schema: [],
        messages: {
          forbiddenImport:
            '"use client" file imports "{{source}}" — server-only infrastructure must never enter the client bundle.',
        },
      },
      create(context) {
        const source = context.sourceCode;
        const program = source.ast;
        const first = program?.body?.[0];
        const isDirective = (stmt, value) =>
          stmt?.type === "ExpressionStatement" &&
          stmt?.expression?.type === "Literal" &&
          stmt?.expression?.value === value;
        /* the directive prologue: "use client" as the first statement
           (a leading comment is legal, a leading statement is not) */
        const isClient =
          isDirective(first, "use client") ||
          isDirective(program?.body?.[1], "use client") && program?.body?.[0]?.type === "ExpressionStatement";
        if (!isClient) return {};
        return importBoundaryVisitor(context, (resolved) =>
          isDbModulePath(resolved) || isServerModulePath(resolved)
        );
      },
    },
  },
};

const eslintConfig = [...nextCoreWebVitals, ...nextTypescript, {
  rules: {
    /* ---------- correctness rules — restored as ERRORS (0 hits each) ---------- */
    "no-unreachable": "error",
    "no-redeclare": "error",
    "no-debugger": "error",
    "no-empty": "error",
    "no-irregular-whitespace": "error",
    "no-case-declarations": "error",
    "no-fallthrough": "error",
    "no-useless-escape": "error",
    "prefer-const": "error",

    /* ---------- TypeScript (flat config uses the typescript-eslint plugin) ---------- */
    // Re-enabled as WARN per the restoration plan; 0 hits today — any future
    // `any` surfaces as a visible warning, never silently.
    "@typescript-eslint/no-explicit-any": "warn",
    // WARN + conventional ignore patterns (22 hits, mostly destructure tails /
    // opened-then-narrowed vars — visible debt, no mechanical mass-fix).
    "@typescript-eslint/no-unused-vars": [
      "warn",
      { argsIgnorePattern: "^_", varsIgnorePattern: "^_" },
    ],
    // Restored to the typescript-eslint recommended baseline (0 hits).
    "@typescript-eslint/ban-ts-comment": "error",
    "@typescript-eslint/prefer-as-const": "error",
    // 6 hits — removing non-null assertions is a typing refactor, not a
    // mechanical fix; surfaced as warnings instead of errors.
    "@typescript-eslint/no-non-null-assertion": "warn",

    /* ---------- React / react-hooks (Next.js default severities) ---------- */
    "react-hooks/rules-of-hooks": "error",
    "react-hooks/exhaustive-deps": "warn",
    // react-hooks v7 recommended preset ships this at ERROR; 4 latent hits whose
    // fixes are render-purity refactors (out of this batch's mechanical scope)
    // — downgraded to WARN so they are tracked, not ignored.
    "react-hooks/purity": "warn",
    // Restored to the react recommended baseline (0 hits each).
    "react/no-unescaped-entities": "error",
    "react/display-name": "error",

    /* ---------- Next.js ---------- */
    // Restored to the @next/next baseline at WARN (~89 <img> hits — the raw
    // <img> inventory is dominated by deliberate classifications: dynamic
    // data-URL avatars, managed /api/images refs, print-only receipts, the
    // cropper canvas source and QR codes — all documented in ROUND 59/129
    // and none safely migratable to next/image under the UI lock; kept
    // visible as debt).
    "@next/next/no-img-element": "warn",
    // ROUND 173 — the App Router migration converted every public-surface
    // internal <a> to <Link> (66 sites, 20 files). The rule itself only
    // detects pages/-directory routes (this repo is App-Router-only, so it
    // never fires — verified with a probe file); kept at WARN to surface
    // any future internal raw anchor regressions if a pages/ dir ever
    // returns.
    "@next/next/no-html-link-for-pages": "warn",

    /* ---------- deliberately OFF (> 20 violations — documented) ---------- */
    // OFF — 117 hits: intentional console logging across API routes + scripts.
    "no-console": "off",
    // OFF — 130 hits, ALL in .ts/.tsx: the core rule cannot parse TypeScript
    // (reports type imports / narrowed vars as unused). The typed variant
    // above governs TS files; this core rule stays off.
    "no-unused-vars": "off",
    // OFF — 49 hits, all in tailwind.config.ts (tab/space indentation mix);
    // a cosmetic re-indent of one vendored config is deferred, not forced.
    "no-mixed-spaces-and-tabs": "off",
    // OFF (redundant line): eslint-config-next itself disables prop-types for
    // TypeScript projects — TS types replace runtime propTypes.
    "react/prop-types": "off",
    // NOTE: no-undef lives in the JS-only block below (it is TypeScript-hostile:
    // 62 type-position false positives — `React`, `RequestInit` — in .ts/.tsx,
    // where `tsc --noEmit` already governs undefined identifiers).
    // NOTE: "@typescript-eslint/no-unused-disable-directive" (removed) — rule
    // does not exist in typescript-eslint v8; the line was dead config.
    // NOTE: "react-compiler/react-compiler" (removed) — the react-compiler
    // plugin is not registered by eslint-config-next; the line was dead config.
  },
}, {
  /* ROUND 162 — architecture enforcement (see the plugin block above) */
  plugins: { "ashrilogic-arch": architecturePlugin },
  rules: {
    "ashrilogic-arch/no-db-in-route-handler": "error",
    "ashrilogic-arch/no-server-only-in-client": "error",
  },
}, {
  // Plain-JavaScript block: `no-undef` restored as an ERROR where it is
  // meaningful (0 hits). .ts/.tsx files are exempt — TypeScript's compiler
  // checks undefined identifiers, and the core rule false-positives on TS
  // type positions (UMD/ambient type names like `React` / `RequestInit`).
  files: ["**/*.{js,cjs,mjs,jsx}"],
  rules: {
    "no-undef": "error",
  },
}, {
  // src/generated/** — GENERATED code (the PostgreSQL Prisma client's JS
  // output): machine-written, regenerated by `db:generate`, never hand-
  // edited; linting generated artifacts measures the generator, not the
  // codebase (the 5k+ errors it introduced were all require-style imports
  // in the generated runtime — intentional in that context).
  ignores: ["node_modules/**", ".next/**", "out/**", "build/**", "next-env.d.ts", "examples/**", "skills", "upload/**", "tool-results/**", "db/**", "storage/**", "scripts/archive/**", "src/generated/**"]
}];

export default eslintConfig;
