#!/bin/bash
# ROUND 170 (ops) — detached dev-server starter.
#
# WHY THIS EXISTS: the package.json "dev" script pipes output through
# `| tee dev.log`. When the calling shell session is reaped, tee dies and
# the next log write from next-server hits a broken pipe (SIGPIPE/EPIPE)
# and kills the server minutes later — observed as the dev server dying
# ~10-40s after every tool command that started it. This starter runs the
# SAME command but redirects stdout/stderr straight into dev.log (a file
# descriptor, immune to session teardown) and exec's next directly, so the
# surviving process owns its log fd. Started via:
#   setsid nohup bash .zscripts/dev-detached.sh >/dev/null 2>&1 &
set -euo pipefail
cd "$(dirname "$0")/.."

set -a
source .env 2>/dev/null || true
set +a
export NODE_OPTIONS=--max-old-space-size=2048

exec node node_modules/next/dist/bin/next dev -p 3000 > dev.log 2>&1
