#!/bin/bash
# Ashrilogic — Caddy security regression gate (Phase 11 / ROUND 137 hardened).
#
# FAILS when a PRODUCTION Caddy configuration reintroduces arbitrary
# client-controlled localhost port proxying (the XTransformPort class:
#   query XTransformPort=*
#   reverse_proxy localhost:{query.XTransformPort}
# ). That pattern is sandbox-only plumbing; shipping it to production is
# an SSRF-class hole (any request can reach internal loopback services).
#
# Files checked: every Caddyfile under deploy/ EXCLUDING files whose name
# contains "sandbox" or "dev" (the documented development configs). The
# repo-root Caddyfile is the SANDBOX gateway (XTransformPort is its
# documented mechanism) and is explicitly exempt — it must simply never
# be deployed as production.
#
# ROUND 137 — STRICT MODE (--strict, used by CI + the release packager):
# "SKIPPED" is NOT a valid production security result. In strict mode a
# MISSING deploy/Caddyfile.production FAILS the gate; the default (dev
# battery) keeps the informational skip so an un-provisioned checkout
# still runs the offline battery.
#
# Usage: bash .zscripts/check-caddy-security.sh [--strict]
#        exit 1 = regression / (strict) missing production config

set -uo pipefail
PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_DIR"

STRICT=0
for arg in "$@"; do
  case "$arg" in
    --strict) STRICT=1 ;;
    *) echo "unknown flag: $arg (supported: --strict)"; exit 2 ;;
  esac
done

shopt -s globstar nullglob

FAILED=0
CHECKED=0

for f in deploy/Caddyfile* Caddyfile*; do
  [ -f "$f" ] || continue
  case "$(basename "$f")" in
    *sandbox*|*dev*|Caddyfile.sandbox|Caddyfile.dev) continue ;;
  esac
  # the repo-root Caddyfile is the SANDBOX gateway (XTransformPort is its
  # documented mechanism); production never ships it.
  if [ "$(dirname "$f")" = "." ] && [ ! -f deploy/PRODUCTION_INCLUDES_ROOT ] ; then
    if [ "$(basename "$f")" = "Caddyfile" ]; then continue; fi
  fi
  CHECKED=$((CHECKED + 1))
  if grep -qE 'reverse_proxy[[:space:]]+localhost:\{query\.' "$f"; then
    echo "SECURITY REGRESSION: $f proxies to a client-controlled localhost port"
    FAILED=1
  fi
  if grep -qE 'query[[:space:]]+XTransformPort' "$f" && grep -q 'reverse_proxy' "$f"; then
    echo "SECURITY REGRESSION: $f routes on the sandbox XTransformPort query parameter"
    FAILED=1
  fi
done

if [ "$CHECKED" -eq 0 ]; then
  if [ "$STRICT" -eq 1 ]; then
    echo "check-caddy-security: FAILED — no production Caddy configuration found (deploy/Caddyfile.production is REQUIRED in strict mode; a missing production config is a release blocker, never a SKIPPED)"
    exit 1
  fi
  echo "check-caddy-security: no production Caddy configurations found (deploy/Caddyfile.production expected) — SKIPPED (non-strict; pass --strict in CI/release to make this a failure)"
  exit 0
fi

if [ "$STRICT" -eq 1 ] && [ ! -f deploy/Caddyfile.production ]; then
  echo "check-caddy-security: FAILED — strict mode requires deploy/Caddyfile.production"
  FAILED=1
fi

if [ "$FAILED" -ne 0 ]; then
  echo "check-caddy-security: FAILED — dynamic localhost proxying found in production config(s) and/or the production config is missing"
  exit 1
fi

echo "check-caddy-security: OK — $CHECKED production config(s) contain no client-controlled port proxying"
exit 0
