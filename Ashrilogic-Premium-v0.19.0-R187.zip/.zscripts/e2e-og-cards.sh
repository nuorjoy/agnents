#!/bin/bash
# ROUND 184 (QA guard, R183 rec a) — DYNAMIC OG-CARD sweep.
#
# The R183 headline feature (per-system + per-article branded social cards)
# is invisible to every console-only sweep: the cards are binary PNGs. This
# guard verifies the card PIPELINE end-to-end:
#
#   1. /systems/<id>/opengraph-image (via the dev server — static catalog,
#      no prisma; safe to compile in the 4GB sandbox):
#        - HTTP 200, PNG magic bytes, exact 1200×630 IHDR dimensions
#        - TWO different category slugs render DIFFERENT bytes (per-content
#          cards, not one static image)
#        - the /systems/<id> PAGE's og:image meta references the dynamic
#          opengraph-image URL (the R183 metadata wiring)
#   2. /blog/<slug>/opengraph-image (via scripts/verify-blog-og.ts — the
#      STANDALONE harness that imports the route module directly). Why not
#      HTTP: compiling prisma+satori in one fresh Turbopack graph OOM-kills
#      the 4GB dev sandbox (reproducible, R183); the harness renders the
#      IDENTICAL route code with the identical fonts + DB read. The harness
#      needs the REAL DATABASE_URL (the sandbox shell exports a file:…
#      override — read it from .env like every local tool).
#
# Usage:  bash .zscripts/e2e-og-cards.sh
# Exit 0 = all assertions passed; exit 1 = any failure (prints which).

set -uo pipefail
cd "$(dirname "$0")/.."

BASE="http://localhost:3000"
PASS=0
FAIL=0

ok()   { PASS=$((PASS + 1)); echo "  ✓ $1"; }
fail() { FAIL=$((FAIL + 1)); echo "  ✗ FAIL: $1"; }

step() { echo "== $1"; }

# PNG dimensions from the IHDR chunk (bytes 16-24, big-endian).
png_dims() {
  python3 -c "
import struct, sys
with open('$1','rb') as f: d = f.read(33)
if d[:8] != b'\x89PNG\r\n\x1a\n':
    print('NOT_PNG'); raise SystemExit
w, h = struct.unpack('>II', d[16:24])
print(f'{w}x{h}')"
}

# ---- prerequisite: server up ------------------------------------------------
step "server reachable"
if curl -s -o /dev/null --max-time 10 "$BASE/robots.txt"; then
  ok "server answers"
else
  echo "dev server not reachable on $BASE — start it first (bash .zscripts/dev-detached.sh)"
  echo "RESULT: 0 passed, 1 failed"
  exit 1
fi

# ---- 1. systems OG cards (HTTP) ---------------------------------------------
for SLUG in hospital-management school-management; do
  step "systems OG card: $SLUG"
  OUT="/tmp/og-sys-$SLUG.png"
  CODE=$(curl -s -m 120 -o "$OUT" -w "%{http_code}" "$BASE/systems/$SLUG/opengraph-image")
  if [ "$CODE" = "200" ]; then
    ok "HTTP 200"
  else
    fail "HTTP $CODE (expected 200)"
    continue
  fi
  DIMS=$(png_dims "$OUT" 2>/dev/null || echo "NOT_PNG")
  if [ "$DIMS" = "1200x630" ]; then
    ok "PNG 1200×630"
  else
    fail "card is '$DIMS' (expected 1200x630 PNG)"
  fi
  SIZE=$(stat -c%s "$OUT" 2>/dev/null || echo 0)
  if [ "$SIZE" -gt 10000 ]; then
    ok "size ${SIZE}B (>10KB — real content, not an error stub)"
  else
    fail "size ${SIZE}B too small"
  fi

  # page wiring: og:image meta must reference the DYNAMIC card URL
  step "systems page og:image wiring: $SLUG"
  META=$(curl -s -m 120 "$BASE/systems/$SLUG" | grep -oE '<meta property="og:image" content="[^"]*"' | head -1)
  if printf '%s' "$META" | grep -q "opengraph-image"; then
    ok "og:image → dynamic card"
  else
    fail "og:image not the dynamic card (got: ${META:-none})"
  fi
done

# distinct bytes: different categories → different accent gradients
step "per-content cards differ"
if cmp -s /tmp/og-sys-hospital-management.png /tmp/og-sys-school-management.png; then
  fail "both system cards are byte-identical — static card, not per-content"
else
  ok "health vs education cards are byte-distinct"
fi

# ---- 2. blog OG card (standalone harness — see header) ----------------------
step "blog OG card via standalone harness"
BLOG_SLUG=$(curl -s --max-time 15 "$BASE/api/blog?pageSize=1" | python3 -c "
import json,sys
try:
    d=json.load(sys.stdin)
    rows=d.get('rows') or d.get('posts') or []
    print(rows[0]['slug'] if rows else '')
except Exception:
    print('')" 2>/dev/null)
if [ -n "$BLOG_SLUG" ]; then
  PGURL=$(grep "^DATABASE_URL" .env | head -1 | cut -d= -f2-)
  if env DATABASE_URL="$PGURL" bun scripts/verify-blog-og.ts "$BLOG_SLUG" >/tmp/og-harness.log 2>&1; then
    ok "harness rendered /blog/$BLOG_SLUG card (see /tmp/og-harness.log)"
    DIMS=$(png_dims /tmp/blog-og.png 2>/dev/null || echo "NOT_PNG")
    if [ "$DIMS" = "1200x630" ]; then
      ok "blog card PNG 1200×630"
    else
      fail "blog card is '$DIMS'"
    fi
    if cmp -s /tmp/blog-og.png /tmp/og-sys-hospital-management.png; then
      fail "blog card byte-identical to a system card"
    else
      ok "blog card is content-distinct from system cards"
    fi
  else
    fail "standalone harness failed (first lines): $(head -3 /tmp/og-harness.log | tr '\n' ' ')"
  fi
else
  echo "== blog OG — SKIPPED (API returned no posts; is the seed present?)"
fi

echo ""
echo "RESULT: ${PASS} passed, ${FAIL} failed"
[ "$FAIL" -eq 0 ] || exit 1
exit 0
