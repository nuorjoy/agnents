/**
 * Ashrilogic — ROUND 166 (Task 6-b) VERIFICATION ONLY (throwaway):
 * seed a synthetic student-accommodation instance into the DEV database
 * so the attendance workspace can be exercised end-to-end (login session
 * → curl the 7 attendance routes → browser mount of the console).
 *
 * Credentials (known, dev-only):
 *   email:    owner-att-6b@example.com
 *   password: att-demo-pass-2024
 *
 * Self-documenting: run with the dev DATABASE_URL; deletes any prior
 * row with the same admin email first (idempotent re-runs).
 */
import { PrismaClient } from "@prisma/client";
import { blindIndex, hashPasswordArgon2id } from "@/lib/server/crypto-vault";

const EMAIL = "owner-att-6b@example.com";
const PASSWORD = "att-demo-pass-2024";

const RESIDENTS: [string, string, string, string][] = [
  ["RES-01000001", "سلطان العتيبي", "RM-101", "مبنى أ"],
  ["RES-01000002", "خالد المطيري", "RM-102", "مبنى أ"],
  ["RES-01000003", "عبدالله القحطاني", "RM-103", "مبنى أ"],
  ["RES-01000004", "فيصل الدوسري", "RM-201", "مبنى ب"],
  ["RES-01000005", "محمد الشمري", "RM-202", "مبنى ب"],
  ["RES-01000006", "ريان الغامدي", "RM-203", "مبنى ب"],
];

async function main(): Promise<void> {
  const db = new PrismaClient();
  try {
    const emailIndex = blindIndex(EMAIL) ?? "";
    await db.instance.deleteMany({ where: { adminEmailIndex: emailIndex } });

    const instance = await db.instance.create({
      data: {
        systemId: "student-accommodation",
        orgJson: JSON.stringify({ name: "سكن الحضور التجريبي", country: "SA", currency: "SAR" }),
        adminJson: JSON.stringify({ name: "مالك السكن", email: EMAIL, role: "owner" }),
        prefsJson: JSON.stringify({ lang: "ar", theme: "light", notif: true, backup: true, audit: true, demo: false }),
        modulesJson: JSON.stringify([
          "dormBuildings",
          "dormRooms",
          "roomAssignments",
          "residents",
          "leases",
          "facilities",
          "maintenance",
          "security",
          "attendance",
          "payments",
          "staff",
          "reports",
          "invoices",
        ]),
        adminEmailIndex: emailIndex,
        passwordHash: hashPasswordArgon2id(PASSWORD),
        sessionVersion: 0,
      },
      select: { id: true },
    });

    for (const [code, name, room, building] of RESIDENTS) {
      await db.moduleRecord.create({
        data: {
          instanceId: instance.id,
          moduleId: "residents",
          dataJson: JSON.stringify([
            code,
            name,
            `2024${Math.random().toString().slice(2, 8)}`,
            "جامعة الملك سعود",
            "كلية الحاسب",
            room,
            building,
            "2026-01-01",
            "2026-12-31",
            "1200.00",
            "0500000001",
            "active",
          ]),
          statusKey: "active",
        },
      });
    }

    console.log(`SEEDED instance=${instance.id} email=${EMAIL} residents=${RESIDENTS.length}`);
  } finally {
    await db.$disconnect();
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
