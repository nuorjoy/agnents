/**
 * Task 10-b2 — VERIFICATION PROBE (run-once, self-cleaning).
 *
 *   1. Promotions: create → public list (active window) → ctaHref open-
 *      redirect rejected → deactivate → public list empty → delete.
 *   2. Tenant messaging: synthetic instance carrying the Starter package
 *      → segmented campaign draft (audience "tenants:plan:<starter>",
 *      kind "offer", {{name}}/{{org}}/{{plan}} tokens) → claim → one
 *      dispatcher sweep → EmailLog pending/spool row for the instance
 *      owner with the tokens SUBSTITUTED → campaign completion evidence.
 *
 * Cleanup: campaign row + its EmailLog rows (idempotency-key prefix) +
 * the synthetic instance (cascade) — database returns to pre-probe state.
 */
import { PrismaClient } from "@prisma/client";
import {
  promotionCreateSchema,
  create as createPromotion,
  update as updatePromotion,
  listPublic,
  remove as removePromotion,
} from "@/server/domains/promotions/service";
import {
  createDraft,
  claimCampaign,
  sweepCampaignDispatch,
} from "@/server/domains/campaigns/service";

const db = new PrismaClient();

function assert(cond: boolean, label: string): void {
  if (!cond) {
    console.error(`FAIL — ${label}`);
    process.exitCode = 1;
  } else {
    console.log(`PASS — ${label}`);
  }
}

const actor = { id: "probe-super", username: "probe" };

try {
  /* ---------------- 1 — promotions ---------------- */
  const now = Date.now();
  const bad = promotionCreateSchema.safeParse({
    titleAr: "عرض الجمعة البيضاء",
    titleEn: "Black Friday",
    theme: "black-friday",
    ctaHref: "http://evil.example.com",
    startsAt: new Date(now - 60_000),
    endsAt: new Date(now + 86_400_000),
  });
  assert(!bad.success, "open-redirect ctaHref (http://) rejected by the zod boundary");

  const created = await createPromotion(
    {
      titleAr: "عرض الجمعة البيضاء",
      titleEn: "Black Friday",
      messageAr: "خصومات تصل إلى ٤٠٪ على الباقات",
      messageEn: "Up to 40% off all plans",
      theme: "black-friday",
      badgeAr: "خصم ٤٠٪",
      badgeEn: "40% OFF",
      discountPct: 40,
      ctaTextAr: "استعرض الباقات",
      ctaTextEn: "Browse plans",
      ctaHref: "/compare",
      startsAt: new Date(now - 60_000),
      endsAt: new Date(now + 86_400_000),
      active: true,
      sortOrder: 0,
    },
    actor
  );
  assert(created.theme === "black-friday" && created.discountPct === 40, "promotion created (black-friday, 40%)");

  const pub = await listPublic();
  assert(pub.some((p) => p.id === created.id), "ACTIVE window promotion appears in the public list");
  assert(
    pub.find((p) => p.id === created.id)!.ctaHref === "/compare",
    "public projection carries the in-app CTA href"
  );

  await updatePromotion(created.id, { active: false }, actor);
  const pubAfter = await listPublic();
  assert(!pubAfter.some((p) => p.id === created.id), "deactivated promotion leaves the public list");

  await removePromotion(created.id, actor);
  const gone = await db.promotion.findUnique({ where: { id: created.id } });
  assert(gone === null, "promotion deleted");

  /* ---------------- 2 — tenant messaging ---------------- */
  const starter = await db.package.findFirst({ where: { nameEn: "Starter" } });
  const probe = await db.instance.create({
    data: {
      systemId: "ZZ-10B2-PROBE",
      orgJson: JSON.stringify({ name: "مؤسسة الاستكشاف" }),
      adminJson: JSON.stringify({ name: "خالد التجريبي", role: "owner", email: "probe-10b2@example.com" }),
      prefsJson: "{}",
      modulesJson: "[]",
      walletMinor: 100,
      packageId: starter!.id,
      demo: true,
    },
  });

  const draft = await createDraft(
    {
      subject: "عرض خاص لمشتركي الباقة الأساسية",
      body: "مرحباً {{name}} — بما أن مؤسستك {{org}} على خطة {{plan}}، لديك عرض حصري اليوم.",
      audience: `tenants:plan:${starter!.id}`,
      kind: "offer",
    },
    actor
  );
  assert(draft.audience === `tenants:plan:${starter!.id}` && draft.kind === "offer", "segmented draft created (audience + kind persisted)");

  const claimed = await claimCampaign(draft.id, actor);
  assert(claimed.status === "sending", "claim transitions the draft to sending (CAS won)");

  /* enqueue-only sweep — the pending row keeps its full envelope (the
     delivery phase settles the row and drops bodyJson, so token evidence
     is asserted on the pending row; the debug run proved delivery too) */
  const outcomes = await sweepCampaignDispatch({ enqueueBatch: 50, deliveryBatch: 0 });
  const mine = outcomes.find((o) => o.campaignId === draft.id);
  assert(mine !== undefined && mine.enqueued >= 1, `dispatcher enqueued the tenant recipient (got ${mine?.enqueued ?? 0})`);

  const logRow = await db.emailLog.findUnique({
    where: { idempotencyKey: `campaign:${draft.id}:${probe.id}` },
  });
  assert(logRow !== null, "EmailLog row exists for the tenant recipient (idempotency key law)");
  assert(logRow!.recipient === "probe-10b2@example.com", `recipient = the sealed adminJson owner mailbox (got ${logRow!.recipient})`);

  const envelope = JSON.parse(logRow!.bodyJson ?? "{}") as { text?: string; subject?: string };
  const text = envelope.text ?? "";
  assert(
    text.includes("خالد التجريبي") && text.includes("مؤسسة الاستكشاف"),
    `{{name}} + {{org}} tokens SUBSTITUTED in the rendered body (text: ${text.slice(0, 120)})`
  );
  assert(!text.includes("{{"), "no unsubstituted tokens remain in the body");
  assert(text.includes("الأساسية"), `{{plan}} token substituted with the package label (text contains it)`);
  assert(
    logRow!.status === "pending",
    `enqueue produced a pending EmailLog row (${logRow!.status}) — delivery phase settles bodyJson away, verified separately`
  );

  /* cleanup: EmailLog rows are NOT instance-cascaded — delete by key prefix */
  await db.emailLog.deleteMany({ where: { idempotencyKey: { startsWith: `campaign:${draft.id}:` } } });
  await db.newsletterCampaign.delete({ where: { id: draft.id } });
  await db.instance.delete({ where: { id: probe.id } });
  const leftoverLogs = await db.emailLog.count({ where: { idempotencyKey: { startsWith: `campaign:${draft.id}:` } } });
  assert(leftoverLogs === 0, "probe EmailLog rows cleaned");
} finally {
  await db.$disconnect();
}
