/**
 * Task 10-b1 — VERIFICATION PROBE (run-once, self-cleaning).
 *
 * End-to-end trace on the REAL domain cores:
 *   1. executeGrant (target=all) credits every live instance's wallet
 *      through the CAS engine — WalletTxn kind "grant", balanceAfterMinor
 *      chain, activity row actWalletGrant.
 *   2. Welcome bonus: enable the setting, pay a synthetic FIRST plan order
 *      through the tenant wallet checkout (createOwn payWith=wallet — the
 *      full create→debit→confirm→activate flow) → bonus credited ONCE
 *      (reference "welcome-bonus") + activity row; a second paid order does
 *      NOT re-credit (idempotency).
 *   3. Plan-targeted grant: only instances whose CURRENT package matches
 *      are credited (the synthetic instance that bought Starter IS, the
 *      package-less one is NOT).
 *   4. nameEn create-schema roundtrip (accept + empty→null).
 *
 * Synthetic instances (demo:true, "ZZ-10B1-PROBE") are hard-DELETED at the
 * end — every dependent row cascades; the welcome-bonus setting is restored.
 */
import { PrismaClient } from "@prisma/client";
import { executeGrant } from "@/server/domains/wallet-grants/service";
import { createOwn } from "@/server/domains/plan-orders/service";
import { readWalletBalance } from "@/lib/server/wallet";
import { adminUserCreateSchema } from "@/lib/server/admin-mapper";

const db = new PrismaClient();

function assert(cond: boolean, label: string): void {
  if (!cond) {
    console.error(`FAIL — ${label}`);
    process.exitCode = 1;
  } else {
    console.log(`PASS — ${label}`);
  }
}

const mkInstance = (walletMinor: number, email: string) =>
  db.instance.create({
    data: {
      systemId: "ZZ-10B1-PROBE",
      orgJson: JSON.stringify({ name: "10b1 Probe" }),
      adminJson: JSON.stringify({ name: "Probe", role: "owner", email }),
      prefsJson: "{}",
      modulesJson: "[]",
      walletMinor,
      demo: true,
    },
  });

const principal = { kind: "owner", actorName: "probe-10b1@example.com" };
const a = await mkInstance(2_000, "probe-10b1-a@example.com");
const b = await mkInstance(1_000, "probe-10b1-b@example.com");

try {
  /* ---------------- 1 — wallet grant (target=all) ---------------- */
  const grantAmount = 250; // $2.50 minor
  const result = await executeGrant(
    { target: "all", amountMinor: grantAmount, note: "" },
    { id: "probe-super", name: "probe@ashrilogic.test" }
  );
  assert(result.credited >= 2, `grant credited ≥ 2 live instances (got ${result.credited})`);
  assert(result.amountMinor === grantAmount, `grant carries the exact minor amount (${result.amountMinor})`);

  const balA0 = await readWalletBalance(a.id);
  const balB0 = await readWalletBalance(b.id);
  assert(balA0 === 2_250, `instance A balance 2000 → 2250 (+250 minor; got ${balA0})`);
  assert(balB0 === 1_250, `instance B balance 1000 → 1250 (+250 minor; got ${balB0})`);

  const txA = await db.walletTxn.findFirst({
    where: { instanceId: a.id, kind: "grant", amountMinor: grantAmount },
    orderBy: { createdAt: "desc" },
  });
  assert(txA !== null, "WalletTxn kind=grant row exists with the ledger reference");
  assert(txA!.balanceAfterMinor === 2_250, "ledger chain link (balanceAfterMinor) is exact");
  assert(txA!.actorType === "admin", "grant row carries actorType=admin");
  const actA = await db.activity.findFirst({ where: { instanceId: a.id, kind: "actWalletGrant" } });
  assert(actA !== null, "activity row actWalletGrant delivered to the tenant feed");

  /* ---------------- 2 — welcome bonus one-shot ---------------- */
  const settingRow = await db.platformSetting.findFirst();
  const priorJson = settingRow?.welcomeBonusJson ?? "";
  await db.platformSetting.update({
    where: { id: settingRow!.id },
    data: {
      welcomeBonusJson: JSON.stringify({
        enabled: true,
        amountMinor: 500,
        messageAr: "أهلاً بك في أشرِيلوجيك — هدية ترحيبية.",
        messageEn: "Welcome to Ashrilogic — a welcome gift.",
      }),
    },
  });

  const starter = await db.package.findFirst({ where: { nameEn: "Starter" } });
  /* FIRST paid order — the full tenant wallet checkout (debit + confirm +
     activate + welcome bonus trigger inside createOwn). */
  await createOwn(a.id, { packageId: starter!.id, cycle: "monthly", methodId: "", payWith: "wallet" }, principal);
  const balAfterFirst = await readWalletBalance(a.id);
  assert(
    balAfterFirst === 2_250 - 999 + 500,
    `first paid order: 2250 − 999 (order) + 500 (bonus) = 1751 (got ${balAfterFirst})`
  );
  const welcomeTxn = await db.walletTxn.findFirst({
    where: { instanceId: a.id, reference: "welcome-bonus" },
  });
  assert(welcomeTxn !== null && welcomeTxn!.amountMinor === 500, "welcome-bonus ledger row exists (amount 500)");
  const welcomeAct = await db.activity.findFirst({ where: { instanceId: a.id, kind: "actWalletWelcome" } });
  assert(welcomeAct !== null, "actWalletWelcome activity row delivered");

  /* SECOND paid order — NO second bonus (reference dedupe) */
  await createOwn(a.id, { packageId: starter!.id, cycle: "monthly", methodId: "", payWith: "wallet" }, principal);
  const welcomeCount = await db.walletTxn.count({
    where: { instanceId: a.id, reference: "welcome-bonus" },
  });
  assert(welcomeCount === 1, `welcome bonus fired exactly ONCE across two paid orders (count ${welcomeCount})`);
  const balAfterSecond = await readWalletBalance(a.id);
  assert(balAfterSecond === 1_751 - 999, `second paid order debits only 999 (got ${balAfterSecond})`);

  /* restore the setting */
  await db.platformSetting.update({
    where: { id: settingRow!.id },
    data: { welcomeBonusJson: priorJson },
  });

  /* ---------------- 3 — plan-targeted grant ---------------- */
  /* instance A now carries the Starter package; instance B has none. */
  const planResult = await executeGrant(
    { target: "plan", packageId: starter!.id, amountMinor: 100, note: "plan probe" },
    { id: "probe-super", name: "probe@ashrilogic.test" }
  );
  assert(planResult.credited >= 1, `plan-targeted grant credits the Starter audience (got ${planResult.credited})`);
  const balBAfter = await readWalletBalance(b.id);
  assert(balBAfter === 1_250, `package-less instance B untouched by the plan grant (got ${balBAfter})`);
  const txAPlan = await db.walletTxn.findFirst({
    where: { instanceId: a.id, kind: "grant", amountMinor: 100 },
  });
  assert(txAPlan !== null, "plan grant credited instance A (its current package matches)");

  /* ---------------- 4 — nameEn roundtrip ---------------- */
  const parsed = adminUserCreateSchema.safeParse({
    username: "probe_ne_admin",
    name: "اسم عربي",
    nameEn: "Arabic Name",
    email: "probe-ne@ashrilogic.test",
    role: "admin",
    active: true,
  });
  assert(parsed.success && parsed.data!.nameEn === "Arabic Name", "admin create schema accepts nameEn");
  const cleared = adminUserCreateSchema.safeParse({
    username: "probe_ne_admin",
    name: "اسم عربي",
    nameEn: "",
    email: "probe-ne@ashrilogic.test",
    role: "admin",
    active: true,
  });
  assert(cleared.success && cleared.data!.nameEn === null, "empty nameEn normalizes to null (single-field behavior)");
} finally {
  await db.instance.deleteMany({ where: { systemId: "ZZ-10B1-PROBE" } });
  await db.$disconnect();
}
