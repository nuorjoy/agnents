#!/bin/bash
# ROUND 178 (QA guard) — e2e regression for the SHAREABLE URL-state
# contracts on the public marketing surfaces:
#
#   1. /blog?tag=…     (R175/R177) — tag chip click mirrors into ?tag=,
#       a deep link lands with that chip ACTIVE, and a reload keeps it.
#   2. /blog?q=…       (R175/R177) — a committed (debounced) search term
#       mirrors into ?q=.
#   3. /systems?cat=…  (R176)      — the systems library category chips
#       mirror into ?cat=.
#   4. /blog — the R174 hydration regression condition is covered as a
#      side effect: every step re-renders /blog from a cold navigation.
#
# Runs against the LOCAL dev server (http://localhost:3000 — start it
# first). Uses agent-browser (headless) so the FULL client stack runs:
# replaceState mirroring, chip aria-pressed state, React hydration.
#
# Usage:  bash .zscripts/e2e-url-state.sh
# Exit 0 = all assertions passed; exit 1 = any failure (prints which).

set -uo pipefail
cd "$(dirname "$0")/.."

BASE="http://localhost:3000"
PASS=0
FAIL=0
CURRENT=""

ok()   { PASS=$((PASS + 1)); echo "  ✓ $1"; }
fail() { FAIL=$((FAIL + 1)); echo "  ✗ FAIL: $1 (step: ${CURRENT:-setup})"; }

step() { CURRENT="$1"; echo "== $1"; }

# get current URL's search params as JSON-ish text
url_query() {
  agent-browser eval "window.location.search" 2>/dev/null | tail -1
}

# ---- prerequisite: server up ------------------------------------------------
step "server reachable"
if curl -s -o /dev/null --max-time 10 "$BASE/blog"; then
  ok "GET /blog answers"
else
  fail "dev server not reachable on $BASE — start it first (bash .zscripts/dev-detached.sh)"
  echo "RESULT: ${PASS} passed, ${FAIL} failed"
  exit 1
fi

# ---- 1. blog tag chip click → ?tag= ----------------------------------------
step "/blog tag chip click mirrors ?tag="
agent-browser open "$BASE/blog" >/dev/null 2>&1
sleep 2
TAG_CLICKED=$(agent-browser eval "
(function(){
  const chips = Array.from(document.querySelectorAll('main button[aria-pressed]'));
  const tagChip = chips.find(b => (b.getAttribute('aria-label') || '').startsWith('#'));
  if (!tagChip) return 'NO_CHIP';
  tagChip.click();
  return tagChip.getAttribute('aria-label').split(' ')[0].replace('#','');
})()" 2>/dev/null | tail -1 | tr -d '"')
sleep 1
Q=$(url_query)
if [ "$TAG_CLICKED" != "NO_CHIP" ] && echo "$Q" | grep -q "tag=${TAG_CLICKED}"; then
  ok "chip click → ?tag=${TAG_CLICKED}"
else
  fail "chip click did not mirror ?tag= (chip=${TAG_CLICKED}, url=${Q})"
fi

# ---- 2. blog deep link ?tag= lands with chip ACTIVE + survives reload ------
step "/blog?tag= deep link + reload persistence"
agent-browser open "$BASE/blog?tag=${TAG_CLICKED}" >/dev/null 2>&1
sleep 2
PRESSED=$(agent-browser eval "
(function(){
  const active = document.querySelector('main button[aria-pressed=\"true\"]');
  return active ? (active.getAttribute('aria-label') || active.textContent || '').trim().split(' ')[0] : 'NONE';
})()" 2>/dev/null | tail -1 | tr -d '"')
if [ "$PRESSED" = "#${TAG_CLICKED}" ]; then
  ok "deep link activates #${TAG_CLICKED}"
else
  fail "deep link did not activate the chip (pressed=${PRESSED})"
fi
agent-browser reload >/dev/null 2>&1
sleep 2
PRESSED2=$(agent-browser eval "
(function(){
  const active = document.querySelector('main button[aria-pressed=\"true\"]');
  return active ? (active.getAttribute('aria-label') || active.textContent || '').trim().split(' ')[0] : 'NONE';
})()" 2>/dev/null | tail -1 | tr -d '"')
if [ "$PRESSED2" = "#${TAG_CLICKED}" ]; then
  ok "reload keeps the chip active"
else
  fail "reload lost the active chip (pressed=${PRESSED2})"
fi

# ---- 3. blog search → ?q= (debounced commit) --------------------------------
step "/blog committed search mirrors ?q="
agent-browser open "$BASE/blog" >/dev/null 2>&1
sleep 2
agent-browser eval "
(function(){
  const input = document.querySelector('main input[type=\"search\"]');
  if (!input) return 'NO_INPUT';
  const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
  setter.call(input, 'wizard');
  input.dispatchEvent(new Event('input', { bubbles: true }));
  return 'TYPED';
})()" >/dev/null 2>&1
sleep 1 # debounce 300ms + fetch
Q=$(url_query)
if echo "$Q" | grep -q "q=wizard"; then
  ok "committed search → ?q=wizard"
else
  fail "search term not mirrored (url=${Q})"
fi

# ---- 4. landing systems-library ?cat= ----------------------------------------
# (the systems LIBRARY lives on the landing page "/" — /systems is only
#  the detail route /systems/[id]; the ?cat= contract is the library's)
step "landing systems-library chip mirrors ?cat="
agent-browser open "$BASE/" >/dev/null 2>&1
sleep 3
CAT=$(agent-browser eval "
(function(){
  /* the category group is the one with MANY chips (the favorites strip
     renders first in the DOM but only ever holds 1-2 buttons) */
  const groups = Array.from(document.querySelectorAll('[role=\"group\"]'));
  const group = groups.sort((a, b) => b.querySelectorAll('button').length - a.querySelectorAll('button').length)[0];
  if (!group) return 'NO_GROUP';
  /* the row leads with the \"favorites\" and \"all\" pseudo-categories —
     the LAST non-pressed chip is always a REAL category id */
  const notPressed = Array.from(group.querySelectorAll('button')).filter(b => b.getAttribute('aria-pressed') === 'false');
  const chip = notPressed[notPressed.length - 1];
  if (!chip) return 'NO_CHIP';
  chip.click();
  return (chip.textContent || '').trim().split('\\n')[0].trim();
})()" 2>/dev/null | tail -1 | tr -d '"')
sleep 1
Q=$(url_query)
if [ -n "$Q" ] && echo "$Q" | grep -q "cat="; then
  ok "category chip click → ${Q}"
else
  fail "category click did not mirror ?cat= (cat=${CAT}, url=${Q})"
fi

# ---- 4b. deep-link seed + reset-sticks (R184 snap-back guard) ----------------
# The R176 deep-link seed used to re-assert the ?cat= category after a
# visitor RESET the filter to "all" (the effect re-ran on every activeCat
# change — reset was functionally broken for deep-link arrivals). This
# pins the fixed contract: deep link lands the category, then "all" STAYS.
step "deep-link ?cat= seeds once; reset sticks"
agent-browser open "$BASE/?cat=health" >/dev/null 2>&1
sleep 3
SEEDED=$(agent-browser eval "
(function(){
  const active = Array.from(document.querySelectorAll('main section#systems button[aria-pressed]'))
    .filter(b => b.getAttribute('aria-pressed') === 'true')
    .map(b => (b.textContent || '').trim().slice(0, 6));
  return active.join(',');
})()" 2>/dev/null | tail -1 | tr -d '"')
if printf '%s' "$SEEDED" | grep -q "الصحة"; then
  ok "deep link /?cat=health lands the health chip"
else
  fail "deep link did not seed the category (active=${SEEDED:-none})"
fi
RESET=$(agent-browser eval "
(function(){
  const chips = Array.from(document.querySelectorAll('main section#systems button[aria-pressed]'));
  const all = chips.find(b => /جميع الأنظمة/.test(b.textContent || ''));
  if (!all) return 'NO_ALL_CHIP';
  all.click();
  return 'CLICKED';
})()" 2>/dev/null | tail -1 | tr -d '"')
sleep 1.5
AFTER=$(agent-browser eval "
(function(){
  const active = Array.from(document.querySelectorAll('main section#systems button[aria-pressed]'))
    .filter(b => b.getAttribute('aria-pressed') === 'true')
    .map(b => (b.textContent || '').trim().slice(0, 8));
  return 'URL=' + window.location.search + ' ACTIVE=' + active.join(',');
})()" 2>/dev/null | tail -1 | tr -d '"')
if printf '%s' "$AFTER" | grep -q "جميع"; then
  ok "reset to all STICKS (no seed snap-back)"
else
  fail "filter snapped back after reset (${AFTER})"
fi

# ---- 5. console hygiene on /blog (R174 regression guard) --------------------
step "/blog console hygiene"
agent-browser console --clear >/dev/null 2>&1
agent-browser errors --clear >/dev/null 2>&1
agent-browser open "$BASE/blog" >/dev/null 2>&1
sleep 3
CONSOLE_ERRS=$(agent-browser console 2>&1 | grep -ciE "\[error\]" || true)
PAGE_ERRS=$(agent-browser errors 2>&1 | grep -vc "^✗\|^\s*$" || true)
if [ "${CONSOLE_ERRS:-0}" -eq 0 ] && [ "${PAGE_ERRS:-0}" -eq 0 ]; then
  ok "zero console/page errors on /blog"
else
  fail "console errors: ${CONSOLE_ERRS}, page errors: ${PAGE_ERRS}"
fi

agent-browser close >/dev/null 2>&1 || true

echo "RESULT: ${PASS} passed, ${FAIL} failed"
[ "$FAIL" -eq 0 ]
