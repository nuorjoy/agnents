#!/bin/bash
# Ashrilogic — RELEASE PACKAGER + ARTIFACT SCANNER (ROUND 137, Phase 10).
#
# Production source/release artifacts MUST NOT contain runtime data.
# This script builds the delivery ZIP from an explicit SOURCE ALLOWLIST
# (anything not listed never ships) and then SCANS the staged tree — the
# build FAILS when runtime/private artifacts are found:
#
#   REFUSED:  .env / .env.* · local databases (db/*.db, WAL/SHM) ·
#             storage/ (backups, images, outbox spool .eml, migrations) ·
#             data/ (audit anchors) · logs (*.log) · node_modules · .next ·
#             public/downloads/*.zip (prior deliveries) · .git ·
#             tool-results · .tmp-scripts · any *.eml anywhere
#
# The release ALWAYS runs the Caddy security gate in --strict mode (a
# missing production Caddy config is a release blocker — never SKIPPED).
#
# Usage:  bash .zscripts/package-release.sh <tag>
# Output: public/downloads/Ashrilogic-Premium-v<version>-<tag>.zip
#         (served by /downloads/<file> and /api/download)
#
# ROUND 146 — the tag argument is now REQUIRED. The old default ("R137" —
# stale since R138) silently mislabeled any tagless invocation: a bare
# `bash .zscripts/package-release.sh` produced
# Ashrilogic-Premium-v0.15.0-R137.zip while the tree was at R145. A hard
# usage failure is the root-cause fix — a release artifact can never again
# carry a round number nobody chose deliberately.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_DIR"

TAG="${1:-}"
if [ -z "$TAG" ]; then
  echo "RELEASE ABORTED: the release tag is REQUIRED." >&2
  echo "Usage: bash .zscripts/package-release.sh <tag>   (e.g. R146)" >&2
  echo "The tag names the artifact Ashrilogic-Premium-v<version>-<tag>.zip and" >&2
  echo "must be chosen deliberately — a stale default once shipped a mislabeled" >&2
  echo "round (ROUND 146 finding)." >&2
  exit 2
fi
if ! printf '%s' "$TAG" | grep -Eq '^[A-Za-z0-9][A-Za-z0-9._-]*$'; then
  echo "RELEASE ABORTED: the tag must be alphanumeric/dot/dash (got: $TAG)" >&2
  exit 2
fi
VERSION="$(node -e "console.log(require('./package.json').version)" 2>/dev/null || bun -e "console.log(require('./package.json').version)")"
ARCHIVE_NAME="Ashrilogic-Premium-v${VERSION}-${TAG}.zip"
STAGING="$(mktemp -d /tmp/ashrilogic-release-XXXXXX)"
OUT_DIR="public/downloads"

# ---------------------------------------------------------------- cleanup
trap 'rm -rf "$STAGING"' EXIT

# ------------------------------------------------- 1. the Caddy gate (strict)
echo "==> caddy security gate (strict — production config is REQUIRED)"
bash .zscripts/check-caddy-security.sh --strict

# ------------------------------------------------- 2. stage from the allowlist
# EVERYTHING the release may contain, explicitly. Nothing else ships.
ALLOWLIST=(
  "src"
  "prisma"
  "scripts"
  "tests"
  "mini-services"
  "deploy"
  "public"
  ".zscripts"
  "agent-ctx"
  "examples"
  "AGENTS.md"
  # ROUND 145 — LICENSE (the bilingual proprietary EULA, §3.3 attribution
  # protection) was MISSING from every prior release zip — the allowlist
  # never listed it. Same round: .github (CI gates ship with the product)
  # and the corrected hardening report join the manifest.
  "LICENSE"
  ".github"
  "Caddyfile"            # the SANDBOX gateway — documented as such, never deployed as production
  "README.md"
  # ROUND 165 — the canonical engineering documentation set ships with the
  # product (docs/engineering/* + the ADRs + the deployment guide).
  "DEPLOYMENT.md"
  "docs"
  ".env.example"
  ".gitignore"
  "bun.lock"
  "components.json"
  "eslint.config.mjs"
  "next.config.ts"
  "package.json"
  "postcss.config.mjs"
  "tailwind.config.ts"
  "tsconfig.json"
)

echo "==> staging the source allowlist"
for entry in "${ALLOWLIST[@]}"; do
  if [ -e "$entry" ]; then
    mkdir -p "$STAGING/$(dirname "$entry")"
    cp -a "$entry" "$STAGING/$entry"
  else
    if [ "$entry" = ".env.example" ]; then
      echo "RELEASE PACKAGING FAILURE: required $entry is missing"
      exit 1
    fi
    echo "   (optional entry absent, skipped: $entry)"
  fi
done

# a prior delivery archive sitting in public/downloads must never nest
# into the next release (excluded here; the scanner below still verifies)
rm -rf "$STAGING/public/downloads"

# runtime/dev debris that may sit inside allowlisted trees (mini-service
# installs, tool logs, pid files) is PRUNED from staging — the scanner
# below then verifies nothing of the class survived anywhere
find "$STAGING" -type d -name node_modules -prune -exec rm -rf {} + 2>/dev/null || true
find "$STAGING" -type f \( -name "*.log" -o -name "dev.pid" -o -name "*.lockb" \) -delete 2>/dev/null || true

# ---------------------------------------------------------------- 3. scanner
echo "==> scanning the staged release for runtime/private artifacts"
FAILED=0

scan_fail() {
  echo "RELEASE ARTIFACT SCAN FAILURE: $1"
  FAILED=1
}

# .env files (the template .env.example is the ONLY permitted env file)
if find "$STAGING" -name ".env" -o -name ".env.*" | grep -v "\.env\.example$" | grep -q .; then
  scan_fail ".env / .env.* files found (only .env.example may ship)"
fi

# local databases + WAL/SHM sidecars
if find "$STAGING" -path "*/db/*" \( -name "*.db" -o -name "*.db-wal" -o -name "*.db-shm" \) | grep -q .; then
  scan_fail "local database files found under db/ (provision at deploy time; see README.md)"
fi

# runtime storage (backups / images / mail spool / migration snapshots)
if [ -d "$STAGING/storage" ]; then
  scan_fail "runtime storage/ directory found (backups, images, .eml spool, migration snapshots)"
fi

# runtime data (audit anchor journal)
if [ -d "$STAGING/data" ]; then
  scan_fail "runtime data/ directory found (audit anchors)"
fi

# logs of any kind
if find "$STAGING" -name "*.log" | grep -q .; then
  scan_fail "log files found"
fi

# stray .eml anywhere (mail spool artifacts)
if find "$STAGING" -name "*.eml" | grep -q .; then
  scan_fail ".eml mail-spool artifacts found"
fi

# build output / dependencies / VCS
for dir in node_modules .next .git tool-results .tmp-scripts; do
  if find "$STAGING" -type d -name "$dir" | grep -q .; then
    scan_fail "build/VCS/scratch directory found: $dir"
  fi
done

# prior delivery archives must never nest
if find "$STAGING" -path "*/downloads/*" -name "*.zip" | grep -q .; then
  scan_fail "prior delivery archives found under public/downloads/"
fi

# obvious secret-shaped files
if find "$STAGING" \( -name "*.pem" -o -name "*.key" -o -name "id_rsa*" -o -name "*.p12" -o -name "*.kdbx" \) | grep -q .; then
  scan_fail "credential-shaped files found (*.pem/*.key/id_rsa/*.p12/*.kdbx)"
fi

if [ "$FAILED" -ne 0 ]; then
  echo "release packaging ABORTED — the artifact scanner refused the staged tree"
  exit 1
fi
echo "    clean — no runtime data, no secrets, no build output"

# ---------------------------------------------------------------- 4. the zip
mkdir -p "$OUT_DIR"
rm -f "$OUT_DIR/$ARCHIVE_NAME"
(cd "$STAGING" && zip -q -r -X "$PROJECT_DIR/$OUT_DIR/$ARCHIVE_NAME" .)

if [ ! -f "$OUT_DIR/$ARCHIVE_NAME" ]; then
  echo "release packaging FAILED — the archive was not produced"
  exit 1
fi

echo "==> release packaged: $OUT_DIR/$ARCHIVE_NAME ($(du -h "$OUT_DIR/$ARCHIVE_NAME" | cut -f1))"
echo "    served at /downloads/$ARCHIVE_NAME and /api/download?file=$ARCHIVE_NAME"
