#!/bin/bash
# ROUND 183 (QA guard, R182 rec a) — public-route TAB-TITLE sweep.
#
# The R182 catch (docTitleSystemDetail rendered as the RAW KEY after
# hydration) and the R183 catch (every blog article's tab collapsed to the
# generic "مقال · Ashrilogic" post-hydration) are the same CLASS of defect:
# the client-side useDocumentTitle hook resolves a key the static i18n
# fragment doesn't carry (raw key) or resolves a generic key where the SSR
# metadata had a specific one. Console-only sweeps structurally CANNOT see
# either — document.title must be read AFTER hydration.
#
# This guard visits every public route with the full client stack running
# (agent-browser) and asserts, per route:
#   1. document.title is non-empty after hydration + settle time
#   2. it is NOT a raw i18n key (single camelCase/snake token, no separator)
#   3. it carries the brand separator "·" (the root layout template appends
#      " · أشرِيلوجيك" to every public page title)
#   4. zero uncaught page errors on the route
#
# Routes covered: / · /blog · a real article slug (fetched live from the
# API so the guard never rots with seed data) · /systems/<id> (a live slug
# from the static catalog) · /compare · /privacy · /terms · /login.
#
# Usage:  bash .zscripts/e2e-title-sweep.sh
# Exit 0 = all assertions passed; exit 1 = any failure (prints which).

set -uo pipefail
cd "$(dirname "$0")/.."

BASE="http://localhost:3000"
PASS=0
FAIL=0

ok()   { PASS=$((PASS + 1)); echo "  ✓ $1"; }
fail() { FAIL=$((FAIL + 1)); echo "  ✗ FAIL: $1"; }

step() { echo "== $1"; }

# ---- prerequisite: server up ------------------------------------------------
step "server reachable"
if curl -s -o /dev/null --max-time 10 "$BASE/blog"; then
  ok "GET /blog answers"
else
  echo "dev server not reachable on $BASE — start it first (bash .zscripts/dev-detached.sh)"
  echo "RESULT: 0 passed, 1 failed"
  exit 1
fi

# ---- resolve LIVE slugs (never rot with seed data) --------------------------
# Also captures the article's REAL titles — the R183 guard: the article tab
# title must CONTAIN one of them (the R183 bug: every article's tab collapsed
# to the generic "مقال · Ashrilogic" post-hydration while SSR had the
# specific one — a separator check alone cannot catch that).
BLOG_SLUG_JSON=$(curl -s --max-time 15 "$BASE/api/blog?pageSize=1" | python3 -c "
import json,sys
try:
    d=json.load(sys.stdin)
    posts=d.get('rows') or d.get('posts') or []
    p=posts[0] if posts else None
    print(json.dumps({'slug': p['slug'], 'ar': p.get('titleAr',''), 'en': p.get('titleEn','')}) if p else '{}')
except Exception:
    print('{}')" 2>/dev/null)
BLOG_SLUG=$(printf '%s' "$BLOG_SLUG_JSON" | python3 -c "import json,sys; print(json.load(sys.stdin).get('slug',''))" 2>/dev/null)
BLOG_TITLE_AR=$(printf '%s' "$BLOG_SLUG_JSON" | python3 -c "import json,sys; print(json.load(sys.stdin).get('ar',''))" 2>/dev/null)
BLOG_TITLE_EN=$(printf '%s' "$BLOG_SLUG_JSON" | python3 -c "import json,sys; print(json.load(sys.stdin).get('en',''))" 2>/dev/null)

SYSTEM_SLUG=$(curl -s --max-time 15 "$BASE/systems/hospital-management" -o /dev/null -w "%{http_code}" 2>/dev/null)
SYSTEM_PATH=""
if [ "$SYSTEM_SLUG" = "200" ]; then SYSTEM_PATH="/systems/hospital-management"; fi

# ---- the sweep --------------------------------------------------------------
# assert_title <path> <allow-generic-override: 0|1>
#   raw-key regex: a title that is ONE bare identifier token (camelCase or
#   snake_case), no spaces, no separator — how a missed i18n key renders.
sweep_route() {
  local route="$1"
  step "$route"
  agent-browser open "$BASE$route" >/dev/null 2>&1
  sleep 2.5

  TITLE=$(agent-browser eval "document.title" 2>/dev/null | tail -1 | sed 's/^"//;s/"$//')
  ERRORS=$(agent-browser errors 2>/dev/null | grep -c . || true)

  if [ -z "$TITLE" ] || [ "$TITLE" = "null" ] || [ "$TITLE" = "undefined" ]; then
    fail "document.title is EMPTY after hydration ($route)"
    return
  fi
  ok "title: $TITLE"

  # 1) raw i18n key = a single camelCase token without spaces/separator
  if printf '%s' "$TITLE" | grep -qE '^[A-Za-z][A-Za-z0-9_]*$'; then
    fail "document.title looks like a RAW I18N KEY: '$TITLE' ($route)"
    return
  fi
  ok "not a raw key"

  # 2) every public page title carries the brand separator — "·" on
  #    subpages, or the em-dash form on the home page's brand title
  if ! printf '%s' "$TITLE" | grep -qE '·|—'; then
    fail "document.title missing the brand separator ('·' or '—'): '$TITLE' ($route)"
    return
  fi
  ok "brand separator present"

  # 3) page errors
  if [ "$ERRORS" -gt 0 ]; then
    fail "$ERRORS uncaught page error(s) on $route"
    return
  fi
  ok "no page errors"

  # 4) R183 guard: on the article route the tab title must carry the REAL
  #    article title (catches the generic-title regression class). The
  #    session's language cookie decides WHICH localized title renders, so
  #    either the AR or the EN title satisfies the assertion.
  if [ -n "${EXPECT_AR:-}" ] || [ -n "${EXPECT_EN:-}" ]; then
    if { [ -n "${EXPECT_AR:-}" ] && printf '%s' "$TITLE" | grep -qF "$EXPECT_AR"; } \
       || { [ -n "${EXPECT_EN:-}" ] && printf '%s' "$TITLE" | grep -qF "$EXPECT_EN"; }; then
      ok "carries the specific article title"
    else
      fail "article tab title is GENERIC (neither '$EXPECT_AR' nor '$EXPECT_EN'): '$TITLE'"
    fi
  fi
}

sweep_route "/"
sweep_route "/blog"
if [ -n "$BLOG_SLUG" ]; then
  # the language cookie decides WHICH localized title renders — export
  # both for the article assertion inside sweep_route
  EXPECT_AR="${BLOG_TITLE_AR:-}"
  EXPECT_EN="${BLOG_TITLE_EN:-}"
  export EXPECT_AR EXPECT_EN
  sweep_route "/blog/$BLOG_SLUG"
  unset EXPECT_AR EXPECT_EN
else
  echo "== /blog/<slug> — SKIPPED (API returned no posts; is the seed present?)"
fi
if [ -n "$SYSTEM_PATH" ]; then
  sweep_route "$SYSTEM_PATH"
else
  echo "== /systems/<id> — SKIPPED (hospital-management did not answer 200)"
fi
sweep_route "/compare"
sweep_route "/privacy"
sweep_route "/terms"
sweep_route "/login"

echo ""
echo "RESULT: ${PASS} passed, ${FAIL} failed"
[ "$FAIL" -eq 0 ] || exit 1
exit 0
