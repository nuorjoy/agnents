#!/bin/bash
#
# Ashrilogic — OOM-aware security test battery (ROUND 104, backlog #4).
#
# WHY THIS EXISTS: the sandbox ceiling (4GB) cannot hold next-server under
# the full live tenant-isolation suite — dev-mode Turbopack compilation of
# every route the suite touches grows next-server to ~2.5-3GB RSS on its
# own (measured ROUND 104; NODE_OPTIONS heap caps do NOT constrain it —
# the growth is external/turbopack memory, not V8 old-space), and the
# kernel OOM-kills the server mid-suite. Every failure after the kill is a
# connection refusal — ZERO isolation-logic failures (verified across
# Tasks 6/7/104 via dev.log: correct 401s until the kill). The documented
# protocol until now was MANUAL: run live suites solo, judge single-run
# results, restart the server when it dies. This script automates exactly
# that protocol — unattended, classified, honest.
#
# PROTOCOL
#   Phase 1 (offline): every tests/security/*.test.ts EXCEPT the live
#     suites, one bun test process per file (the established solo pattern —
#     shared-rate-limit contamination between suites is impossible).
#   Phase 2 (live): for each live suite —
#       a. free headroom: close the agent-browser session (~1GB of chrome
#          renderers — the difference between dying at test 14 vs test 23);
#       b. STOP any running dev server and start a FRESH one (standard
#          turbopack + 2048MB heap, same NODE_OPTIONS as package.json dev)
#          so the suite begins from the smallest possible server footprint;
#       c. run `bun test --smol <suite>` (--smol: Bun's low-memory mode —
#          measured ~104MB peak for the tenant-isolation runner);
#       d. CLASSIFY the single run:
#            PASS    exit 0, no skipped tests
#            INFRA   server died mid-suite (probe fails after) OR live
#                    tests skipped (server unreachable at start) → restart
#                    the server and retry, max LIVE_ATTEMPTS total;
#            FAIL    suite failed while the server stayed alive — real
#                    logic/regression failure, never retried away.
#     tenant-isolation runs SLICED (ROUND 105): no single server lifetime
#     can host the whole live suite, so the battery runs it as 10 sequential
#     slices (TENANT_ISOLATION_SLICE=1..10), each on a FRESH server: slice 1
#     provisions both tenants; slices 2-10 REJOIN them by blind index +
#     fresh logins (the suite's own machinery — see its header). Every
#     slice gets the same PASS/INFRA/FAIL classification; the suite verdict
#     aggregates them. A server-INDEPENDENT cleanup phase
#     (TENANT_ISOLATION_SLICE=99) ALWAYS runs afterwards — it deletes the
#     run's rows + rate keys + outbox files and STALE-SWEEPS rows from any
#     interrupted battery (org names matching the suite's exact
#     Tenant(Alpha|Beta)-<ms>-<rand> shape).
#   Phase 3 (restore): stop the battery server and bring the environment
#     back to its managed state via .zscripts/dev.sh (the documented
#     recovery path), verified ready before the script exits.
#
# VERDICT CODES (exit status)
#   0  every suite PASS
#   1  one or more REAL failures (server alive, assertions failed)
#   2  one or more suites INCONCLUSIVE after retries (server OOM-died on
#      every attempt; zero-logic-failure evidence NOT established — rerun
#      later or on a bigger box; see the per-suite attempt log above)
#
# USAGE
#   bash .zscripts/test-battery.sh                 # full battery
#   LIVE_SUITES="trial-entitlement" bash .zscripts/test-battery.sh
#   OFFLINE_ONLY=1 bash .zscripts/test-battery.sh  # skip the live phase
#
# CROSS-SESSION LOCK: /tmp/ashrilogic-battery.lock (flock, auto-released on
# process death). A second battery started while one runs EXITS 0 with a
# SKIP notice — concurrent batteries kill each other's fresh servers.
# BATTERY_SKIP_LOCK=1 bypasses (diagnostics only).
#
# The battery NEVER touches the live databases: offline suites run against
# the throwaway TEST_DATABASE_URL fixture (force-reset per process), the
# live suites provision + clean the dev server's database with the
# documented cleanup discipline.

set -uo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_DIR"

# ---------------------------------------------------------------- config ---

# the DOCUMENTED live-API suites — always excluded from the offline phase
# (they REQUIRE a fresh, managed server lifecycle; LIVE_SUITES below can
# only ever NARROW the live phase, never reclassify these as offline)
# ROUND 88 — plan-assignment and http-routes JOINED the live list: both are
# live-API suites (provision + login against :3000; http-routes even labels
# itself "LIVE-SERVER route tests"). Running them in the OFFLINE phase made
# their verdict depend on whether the managed server HAPPENED to be up:
# plan-assignment failed with ConnectionRefused the moment it wasn't, while
# http-routes silently describe.skip'd its whole live block and reported a
# phantom PASS (0 pass / 8 skip). In the live phase both get the honest
# fresh-server lifecycle + the PASS-requires-zero-skips classification.
# ROUND 124 — packages-routes JOINED the live list: it exercises the
# migrated packages routes end-to-end (auth guards, popular swap, 404s,
# zod envelopes, audit rows) against the demo DB, so it needs the same
# fresh-server lifecycle as the other live-API suites.
# ROUND 126 — store-routes JOINED the live list: it exercises the migrated
# public storefront routes end-to-end (catalog + facets, coupon verdict
# mapping, guest review upsert, guard order, x-request-id) against the
# demo DB, so it needs the same fresh-server lifecycle as the other
# live-API suites.
BUILTIN_LIVE="tenant-isolation tenant-isolation-modern trial-entitlement plan-assignment http-routes packages-routes store-routes"
LIVE_SUITES="${LIVE_SUITES:-$BUILTIN_LIVE}"
LIVE_ATTEMPTS="${LIVE_ATTEMPTS:-2}"
OFFLINE_ONLY="${OFFLINE_ONLY:-0}"
SERVER_WAIT_SECS="${SERVER_WAIT_SECS:-180}"
# sliced-protocol knobs (see run_tenant_isolation_sliced): young servers
# taking test load are reaped by the sandbox watchdog — idle through the
# grace window first; and one server lifetime hosts at most this many
# slices (route/RSS budget — measured safe at ~16 routes / ~2GB)
TENANT_SETTLE_SECS="${TENANT_SETTLE_SECS:-75}"
TENANT_RESTART_EVERY="${TENANT_RESTART_EVERY:-3}"
# the sliced runner carries the watchdog-kill risk on EVERY slice — give it
# one more retry than the generic suites (measured: a concurrent review
# session's server cycles can kill two attempts in a row)
TENANT_SLICE_ATTEMPTS="${TENANT_SLICE_ATTEMPTS:-3}"

PASS_LIST=()
FAIL_LIST=()
INCONCLUSIVE_LIST=()

# --------------------------------------------------------- cross-session lock
# ROUND 112 (Task 11 backlog #4): two batteries must never interleave. A
# concurrent review session running its own battery cycles servers under
# THIS battery's slices (phantom INFRA verdicts) and its cleanup phases
# race the live suites' rows. flock is advisory and AUTO-RELEASES when the
# holding process dies — no stale-lock recovery path is ever needed.
# Contention is a SKIP, not a failure: the other battery is already doing
# this round's QA work. Override with BATTERY_SKIP_LOCK=1 (diagnostics
# only — never in unattended runs).
BATTERY_LOCK_FILE="${BATTERY_LOCK_FILE:-/tmp/ashrilogic-battery.lock}"
if [ "${BATTERY_SKIP_LOCK:-0}" != "1" ] && command -v flock >/dev/null 2>&1; then
  # append-mode open: must NOT truncate while another holder owns the file
  exec 9>>"$BATTERY_LOCK_FILE"
  if ! flock -n 9; then
    holder="$(tail -n 1 "$BATTERY_LOCK_FILE" 2>/dev/null || true)"
    echo "[battery $(date '+%H:%M:%S')] SKIP — another battery holds $BATTERY_LOCK_FILE (holder: ${holder:-unknown})."
    echo "[battery $(date '+%H:%M:%S')] Concurrent batteries kill each other's fresh servers (phantom INFRA); this round's QA is served by the running battery."
    exit 0
  fi
  printf 'battery pid %s started %s\n' "$$" "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" >"$BATTERY_LOCK_FILE"
fi

# -------------------------------------------------------------- helpers -----

log()  { printf '[battery %s] %s\n' "$(date '+%H:%M:%S')" "$*"; }

probe_server() {
  curl -s -o /dev/null -w "%{http_code}" --max-time 5 http://localhost:3000/api/status 2>/dev/null
}

wait_server() {
  local deadline=$((SECONDS + SERVER_WAIT_SECS))
  while [ "$SECONDS" -lt "$deadline" ]; do
    if [ "$(probe_server)" = "200" ]; then return 0; fi
    sleep 4
  done
  return 1
}

stop_server() {
  pkill -f "next dev -p 3000" 2>/dev/null
  pkill -f "next-server" 2>/dev/null
  pkill -f "pool_entry" 2>/dev/null
  pkill -f "bun run dev" 2>/dev/null
  local waited=0
  while [ "$(probe_server)" != "000" ] && [ "$waited" -lt 15 ]; do
    sleep 1; waited=$((waited + 1))
  done
  sleep 1
}

# SURVIVOR PATH (measured 2026-09-18): servers started any other way —
# directly via `next dev`, or via a bare `bun run dev` — are reaped by the
# sandbox's process-tree killer within ~15-60s under test load (silent
# whole-tree SIGKILLs: no kernel OOM trace, no crash output, the wrapper
# script dies with its children — batteries 3+4 and multiple direct
# probes). dev.sh-started servers SURVIVE (validated: slice 1 provisioning
# + slice 2 rejoin back-to-back against one dev.sh server, plus every
# Phase-3 restore staying up for minutes). The battery must go through
# .zscripts/dev.sh — the documented recovery path — for EVERY fresh start.
# `exec 9>&-` — the nohup'd server must NOT inherit the battery-lock fd:
# a long-lived child holding fd 9 keeps the flock forever (measured: the
# Phase-3-restored dev server pinned the lock and every later battery
# SKIPped). Same guard in restore_managed_server below.
start_fresh_server() {
  stop_server
  ( exec 9>&-; nohup bash .zscripts/dev.sh > /tmp/battery-devsh-start.log 2>&1 & )
  wait_server
}

# preserve the CURRENT dev.log as per-phase crash evidence before the next
# server start truncates it (bun run dev pipes through tee into dev.log)
snapshot_server_log() {
  local label="${1:-generic}"
  cp -f dev.log "/tmp/battery-server-${label}.log" 2>/dev/null || true
}

# idle through the sandbox's startup grace window: servers younger than
# ~60s that take test load (compile-burst slowness) get reaped by the
# sandbox watchdog — whole-tree SIGKILLs with no kernel trace (measured
# across batteries 2-5; settled servers survive — validated by slice 1 +
# slice 2 + slices 3-4 running back-to-back against settled servers).
# Probes only; if the server dies mid-settle, restart and settle again.
settle_server() {
  local deadline=$((SECONDS + TENANT_SETTLE_SECS))
  while [ "$SECONDS" -lt "$deadline" ]; do
    sleep 10
    if [ "$(probe_server)" != "200" ]; then
      log "live:tenant-isolation — server died during settle; restarting"
      if ! start_fresh_server; then return 1; fi
      deadline=$((SECONDS + TENANT_SETTLE_SECS))
    fi
  done
  return 0
}

restore_managed_server() {
  stop_server
  ( exec 9>&-; nohup bash .zscripts/dev.sh > /tmp/dev-restart.log 2>&1 & )
  if wait_server; then
    log "managed dev server restored via .zscripts/dev.sh"
  else
    log "WARNING: managed dev server did not come back — start it manually: cd $PROJECT_DIR && (nohup bash .zscripts/dev.sh > /tmp/dev-restart.log 2>&1 &)"
  fi
}

# tenant-isolation, SLICED (ROUND 105, backlog #4): one server lifetime
# cannot host the whole live suite (next-server OOM-kills around test 15 —
# see the header of tests/security/tenant-isolation.test.ts). Each slice
# gets a FRESH server; slices 2+ rejoin slice 1's tenants; a server-less
# cleanup phase ALWAYS runs afterwards. Slice count is owned by the test
# file (SLICE_COUNT=10) — keep in sync.
run_tenant_isolation_sliced() {
  local file="tests/security/tenant-isolation.test.ts"
  local run_id xff slice attempt bun_exit server_after skipped slice_done verdict attempt_log
  # NON-NUMERIC prefix (CONCURRENT-AGENT SAFETY, measured ROUND 105): a
  # parallel review session's cleanup stale-sweeps instances whose org name
  # matches the numeric Tenant(Alpha|Beta)-<ms>-<rand> shape — a numeric run
  # id here got THIS battery's rows swept mid-slice (404 FAIL). The ti-
  # prefix keeps this run invisible to that sweep; this suite's own sweep is
  # age-gated (30 min) for the same reason.
  run_id="ti-$(date +%s%3N)-$RANDOM"
  xff="198.51.100.$(( (RANDOM % 254) + 1 ))" # TEST-NET-2 — shared by all phases so the cleanup can purge every key
  verdict=""
  attempt_log=""

  local restart_needed=1
  for slice in 1 2 3 4 5 6 7 8 9 10; do
    # one server lifetime hosts at most TENANT_RESTART_EVERY slices
    # (measured: ~16 routes / ~2GB is safe; ~20+ routes / 2.5GB dies)
    if [ "$slice" -gt 1 ] && [ $(( (slice - 1) % TENANT_RESTART_EVERY )) -eq 0 ]; then
      restart_needed=1
    fi
    slice_done=0
    attempt=1
    while [ "$attempt" -le "$TENANT_SLICE_ATTEMPTS" ]; do
      if [ "$restart_needed" = "1" ]; then
        log "live:tenant-isolation — slice $slice/10 attempt $attempt/$TENANT_SLICE_ATTEMPTS: FRESH server + ${TENANT_SETTLE_SECS}s settle"
        if start_fresh_server && settle_server; then
          restart_needed=0
        else
          attempt_log="$attempt_log [slice $slice attempt $attempt: server failed to start/settle]"
          attempt=$((attempt + 1))
          continue
        fi
      fi
      # slice 1 retries need a FRESH identity — a partially provisioned
      # attempt would 409 EMAIL_TAKEN; the cleanup phase's stale sweep
      # (org-name pattern) heals the abandoned rows
      if [ "$slice" = "1" ] && [ "$attempt" -gt "1" ]; then
        run_id="ti-$(date +%s%3N)-$RANDOM"
        log "live:tenant-isolation — slice 1 retry: fresh run identity $run_id"
      fi
      TENANT_ISOLATION_SLICE="$slice" TENANT_ISOLATION_RUN_ID="$run_id" TENANT_ISOLATION_XFF="$xff" \
        bun test --smol "$file" > /tmp/battery-tenant-isolation-slice"$slice".log 2>&1
      bun_exit=$?
      snapshot_server_log "tenant-slice${slice}-a${attempt}"
      server_after="$(probe_server)"
      skipped="$(grep -c '(skip)' /tmp/battery-tenant-isolation-slice"$slice".log || true)"

      if [ "$bun_exit" = "0" ] && [ "$skipped" = "0" ]; then
        attempt_log="$attempt_log [slice $slice: PASS]"
        slice_done=1
        break
      fi

      if [ "$server_after" != "200" ]; then
        attempt_log="$attempt_log [slice $slice attempt $attempt: INFRA — server down after run (exit $bun_exit, $skipped skipped)]"
        restart_needed=1
      elif [ "$skipped" != "0" ]; then
        attempt_log="$attempt_log [slice $slice attempt $attempt: INFRA — live tests skipped (server unreachable at start)]"
        restart_needed=1
      else
        attempt_log="$attempt_log [slice $slice attempt $attempt: FAIL — server alive, assertions failed (exit $bun_exit)]"
        verdict="FAIL"
        break
      fi
      attempt=$((attempt + 1))
    done

    if [ "$verdict" = "FAIL" ]; then break; fi
    if [ "$slice_done" != "1" ]; then verdict="INCONCLUSIVE"; break; fi
  done
  if [ -z "$verdict" ]; then verdict="PASS"; fi

  # cleanup phase — ALWAYS (even after FAIL/INCONCLUSIVE), server-independent
  # (pure DB + fs; the stopped server avoids racing the app's own writes)
  stop_server
  log "live:tenant-isolation — cleanup phase (rows + rate keys + outbox + stale sweep)"
  if TENANT_ISOLATION_SLICE=99 TENANT_ISOLATION_RUN_ID="$run_id" TENANT_ISOLATION_XFF="$xff" \
     bun test --smol "$file" > /tmp/battery-tenant-isolation-cleanup.log 2>&1; then
    attempt_log="$attempt_log [cleanup: OK]"
  else
    attempt_log="$attempt_log [cleanup: FAILED — see /tmp/battery-tenant-isolation-cleanup.log; the next battery run's stale sweep retries]"
    log "WARNING: live:tenant-isolation cleanup phase failed (leftover rows will be retried by the next run's stale sweep)"
  fi

  log "live:tenant-isolation verdict: $verdict$attempt_log"
  case "$verdict" in
    PASS) PASS_LIST+=("live:tenant-isolation") ;;
    FAIL) FAIL_LIST+=("live:tenant-isolation"); tail -n 25 /tmp/battery-tenant-isolation-slice*.log 2>/dev/null | tail -n 25 ;;
    *)    INCONCLUSIVE_LIST+=("live:tenant-isolation") ;;
  esac
}

# ------------------------------------------------------------- preflight ----

# PostgreSQL preflight (the engine is PostgreSQL-only since the cutover):
# the offline suites reset TEST_DATABASE_URL on every process, so a dead
# server would otherwise surface as 70+ suites full of connection errors.
# Fail fast with ONE clear message instead. pg_isready when available
# (it ships with a local PostgreSQL install), else a tiny bun probe with
# the pg package (already a dependency).
preflight_pg() {
  local url="${TEST_DATABASE_URL:-postgresql://postgres@localhost:5433/ashrilogic_security_test}"
  case "$url" in
    postgres://*|postgresql://*) ;;
    *)
      log "FAIL  preflight:pg — TEST_DATABASE_URL is not a PostgreSQL connection string: $url"
      return 1
      ;;
  esac

  local hostport host port
  hostport="$(bun -e "const u=new URL(process.argv[1]);console.log((u.hostname||'localhost')+' '+(u.port||'5432'))" "$url" 2>/dev/null)" || {
    log "FAIL  preflight:pg — cannot parse TEST_DATABASE_URL: $url"
    return 1
  }
  host="${hostport% *}"; port="${hostport#* }"

  if command -v pg_isready >/dev/null 2>&1; then
    if ! pg_isready -h "$host" -p "$port" >/dev/null 2>&1; then
      log "FAIL  preflight:pg — PostgreSQL at $host:$port does not answer (pg_isready). Start the server (e.g. source /home/z/pg-local/pg-env.sh) or point TEST_DATABASE_URL at a reachable one."
      return 1
    fi
  else
    if ! bun -e "const {Client}=require('pg');const c=new Client({connectionString:process.argv[1]});c.connect().then(()=>c.query('SELECT 1')).then(()=>c.end()).then(()=>process.exit(0)).catch(()=>process.exit(1));process.on('unhandledRejection',()=>process.exit(1))" "$url"; then
      log "FAIL  preflight:pg — cannot connect to $url (SELECT 1 failed). Start PostgreSQL or point TEST_DATABASE_URL at a reachable server."
      return 1
    fi
  fi

  # The live phase additionally provisions against the DEV SERVER's
  # database — inherited DATABASE_URL must be a PostgreSQL URL when set
  # (a leftover file: URL would crash dev.sh's db:push mid-battery).
  if [ "$OFFLINE_ONLY" != "1" ] && [ -n "${DATABASE_URL:-}" ]; then
    case "$DATABASE_URL" in
      postgres://*|postgresql://*) ;;
      *)
        log "FAIL  preflight:pg — DATABASE_URL (the live-phase dev database) is not a PostgreSQL connection string: $DATABASE_URL"
        return 1
        ;;
    esac
  fi

  log "PASS  preflight:pg — $host:$port answers (test database: $url)"
  return 0
}

if ! preflight_pg; then
  FAIL_LIST+=("preflight:pg")
  echo ""
  echo "==================== SECURITY BATTERY SUMMARY ===================="
  echo "  FAIL           preflight:pg (see the message above)"
  echo "=================================================================="
  exit 1
fi

# --------------------------------------------------------- phase 1: offline --

log "PHASE 1 — offline suites (one bun test process per file)"

# ROUND 65 (hardening gates): the offline phase opens with the STATIC
# Caddy production-config security regression check (client-controlled
# port proxying must never ship). The former schema-parity gate is gone —
# the platform is single-provider (prisma/schema.prisma, PostgreSQL).
if bash .zscripts/check-caddy-security.sh > /tmp/battery-caddy-security.log 2>&1; then
  PASS_LIST+=("static:caddy-security")
  log "PASS  static:caddy-security"
else
  FAIL_LIST+=("static:caddy-security")
  log "FAIL  static:caddy-security (log: /tmp/battery-caddy-security.log)"
  tail -5 /tmp/battery-caddy-security.log
fi

for f in tests/security/*.test.ts; do
  base="$(basename "$f" .test.ts)"
  skip=0
  for live in $BUILTIN_LIVE $LIVE_SUITES; do
    [ "$base" = "$live" ] && skip=1
  done
  [ "$skip" = "1" ] && continue

  if bun test "$f" > /tmp/battery-"$base".log 2>&1; then
    PASS_LIST+=("offline:$base")
    log "PASS  offline:$base"
  else
    FAIL_LIST+=("offline:$base")
    log "FAIL  offline:$base (log: /tmp/battery-$base.log)"
    tail -5 /tmp/battery-"$base".log
  fi
done

log "PHASE 1 done: ${#PASS_LIST[@]} pass, ${#FAIL_LIST[@]} fail (offline)"

# ------------------------------------------------------------ phase 2: live --

if [ "$OFFLINE_ONLY" != "1" ]; then
  log "PHASE 2 — live-API suites (fresh server per suite, --smol, classified retries)"

  # free ~1GB of chrome renderers — measured headroom difference on the
  # 4GB ceiling (best-effort: no agent-browser installed → continue anyway)
  if command -v agent-browser >/dev/null 2>&1; then
    agent-browser close --all >/dev/null 2>&1 || true
    log "agent-browser sessions closed (headroom freed)"
  fi

  for suite in $LIVE_SUITES; do
    file="tests/security/$suite.test.ts"
    if [ ! -f "$file" ]; then
      log "SKIP  live:$suite — $file not found"
      continue
    fi

    # the OOM-bound suite runs as sequential slices on fresh servers
    if [ "$suite" = "tenant-isolation" ]; then
      run_tenant_isolation_sliced
      continue
    fi

    verdict="INCONCLUSIVE"
    attempt_log=""

    attempt=1
    while [ "$attempt" -le "$LIVE_ATTEMPTS" ]; do
      log "live:$suite — attempt $attempt/$LIVE_ATTEMPTS: starting FRESH server"
      if ! start_fresh_server; then
        attempt_log="$attempt_log [attempt $attempt: server failed to start]"
        attempt=$((attempt + 1))
        continue
      fi

      bun test --smol "$file" > /tmp/battery-"$suite".log 2>&1
      bun_exit=$?
      snapshot_server_log "live-$suite-a${attempt}"

      server_after="$(probe_server)"
      skipped="$(grep -c '(skip)' /tmp/battery-"$suite".log || true)"

      if [ "$bun_exit" = "0" ] && [ "$skipped" = "0" ]; then
        verdict="PASS"
        attempt_log="$attempt_log [attempt $attempt: PASS]"
        break
      fi

      if [ "$server_after" != "200" ]; then
        # server died mid-suite (or never came up) — infrastructure, not logic
        attempt_log="$attempt_log [attempt $attempt: INFRA — server down after run (exit $bun_exit, $skipped skipped)]"
      elif [ "$skipped" != "0" ]; then
        # server was unreachable at suite start despite the fresh-start
        # verification — the suite skipped its live block; not a pass
        attempt_log="$attempt_log [attempt $attempt: INFRA — live tests skipped (server unreachable at start)]"
      else
        # server stayed alive through the failures — REAL failure
        verdict="FAIL"
        attempt_log="$attempt_log [attempt $attempt: FAIL — server alive, assertions failed (exit $bun_exit)]"
        break
      fi

      attempt=$((attempt + 1))
    done

    log "live:$suite verdict: $verdict$attempt_log"
    case "$verdict" in
      PASS)           PASS_LIST+=("live:$suite") ;;
      FAIL)           FAIL_LIST+=("live:$suite"); tail -15 /tmp/battery-"$suite".log ;;
      *)              INCONCLUSIVE_LIST+=("live:$suite") ;;
    esac
  done
else
  log "PHASE 2 skipped (OFFLINE_ONLY=1)"
fi

# ------------------------------------------------- phase 2.5: UI e2e guard --
# ROUND 179 (R178 rec c) — the shareable-URL-state contracts (?tag= / ?q=
# on /blog, ?cat= on the landing systems library) are now a STANDING
# pre-release gate: a real agent-browser session drives the full client
# stack (hydration, replaceState mirroring, chip aria-pressed state).
# Runs AFTER the live-API suites (they free the ~1GB of chrome headroom
# on purpose) against whatever server is still up — a fresh one is
# started if the last live suite's server died. A failed guard is a REAL
# FAIL (never INFRA — the script itself verifies reachability first).
# E2E_URL_STATE=0 skips (diagnostics only).
if [ "${E2E_URL_STATE:-1}" = "1" ] && command -v agent-browser >/dev/null 2>&1; then
  log "PHASE 2.5 — UI e2e URL-state regression (agent-browser)"
  if [ "$(probe_server)" != "200" ]; then
    log "ui:e2e-url-state — server down; starting a fresh one"
    start_fresh_server || true
  fi
  if bash .zscripts/e2e-url-state.sh > /tmp/battery-e2e-url-state.log 2>&1; then
    PASS_LIST+=("ui:e2e-url-state")
    log "PASS  ui:e2e-url-state ($(grep -o 'RESULT: [0-9]* passed, [0-9]* failed' /tmp/battery-e2e-url-state.log | tail -1))"
  else
    FAIL_LIST+=("ui:e2e-url-state")
    log "FAIL  ui:e2e-url-state (log: /tmp/battery-e2e-url-state.log)"
    tail -8 /tmp/battery-e2e-url-state.log
  fi
  # never leave chrome renderers pinned through the restore phase
  agent-browser close --all >/dev/null 2>&1 || true
else
  log "PHASE 2.5 skipped (E2E_URL_STATE=0 or agent-browser missing)"
fi

# --------------------------------------------------------- phase 3: restore --

log "PHASE 3 — restoring the managed dev server"
restore_managed_server

# ---------------------------------------------------------------- summary ----

echo ""
echo "==================== SECURITY BATTERY SUMMARY ===================="
for s in "${PASS_LIST[@]:-}";         do [ -n "$s" ] && echo "  PASS           $s"; done
for s in "${FAIL_LIST[@]:-}";         do [ -n "$s" ] && echo "  FAIL           $s"; done
for s in "${INCONCLUSIVE_LIST[@]:-}"; do [ -n "$s" ] && echo "  INCONCLUSIVE   $s (environment-killed on every attempt — watchdog/OOM, not a logic-failure verdict; rerun later)"; done
echo "=================================================================="
echo "pass: ${#PASS_LIST[@]}   fail: ${#FAIL_LIST[@]}   inconclusive: ${#INCONCLUSIVE_LIST[@]}"

if [ "${#FAIL_LIST[@]}" -gt 0 ]; then
  exit 1
fi
if [ "${#INCONCLUSIVE_LIST[@]}" -gt 0 ]; then
  exit 2
fi
exit 0
