/**
 * Task 5-a — VERIFICATION PROBE (run-once, self-cleaning).
 *
 * End-to-end wallet-checkout UNIT trace on the REAL domain cores:
 *   packages (minor) → createPlanOrder amount = discountedPrice(minor)
 *   → payOrderFromWallet debits the order's OWN amount (no ×100)
 *   → refundWalletDebit compensates → cancelPlanOrder.
 *
 * Uses a synthetic instance (demo:true, "ZZ-UNIT-PROBE") that is
 * hard-DELETED at the end — PlanOrder/WalletTxn cascade with it, so the
 * database returns to its exact pre-probe state.
 */
import { PrismaClient } from "@prisma/client";
import {
  cancelPlanOrder,
  createPlanOrder,
  WALLET_CHECKOUT_METHOD_ID,
} from "@/lib/server/plan-orders";
import {
  payOrderFromWallet,
  readWalletBalance,
  refundWalletDebit,
} from "@/lib/server/wallet";
import { cycleDiscountPct, discountedPrice } from "@/lib/plan-features";

const db = new PrismaClient();

function assert(cond: boolean, label: string): void {
  if (!cond) {
    console.error(`FAIL — ${label}`);
    process.exitCode = 1;
  } else {
    console.log(`PASS — ${label}`);
  }
}

const SEED_MINOR = 5000; // synthetic wallet balance (minor units)

const probe = await db.instance.create({
  data: {
    systemId: "ZZ-UNIT-PROBE",
    orgJson: JSON.stringify({ name: "Unit Probe" }),
    adminJson: JSON.stringify({ name: "Probe", role: "owner", email: "" }),
    prefsJson: "{}",
    modulesJson: "[]",
    walletMinor: SEED_MINOR,
    demo: true,
  },
});

try {
  const starter = await db.package.findFirst({ where: { nameEn: "Starter" } });
  assert(starter !== null, "Starter package row exists");
  assert(
    starter!.priceMonthly === 999 && starter!.priceYearly === 9590 && starter!.currency === "USD",
    `Starter carries minor-unit USD prices (999 / 9590, got ${starter!.priceMonthly} / ${starter!.priceYearly} ${starter!.currency})`
  );

  /* 1 — the server pricing law on the LIVE row (monthly: pct=0 → identity) */
  const monthlyPct = cycleDiscountPct(
    { discountPct: starter!.discountPct ?? 0, yearlyDiscountPct: starter!.yearlyDiscountPct ?? 0 },
    "monthly"
  );
  const yearlyPct = cycleDiscountPct(
    { discountPct: starter!.discountPct ?? 0, yearlyDiscountPct: starter!.yearlyDiscountPct ?? 0 },
    "yearly"
  );
  assert(monthlyPct === 0, "monthly promotion is 0 (the listed price IS the price)");
  assert(
    discountedPrice(starter!.priceMonthly, monthlyPct) === 999,
    "discountedPrice(999, 0) === 999 — the $9.99 anchor, integer minor units"
  );
  assert(
    discountedPrice(starter!.priceYearly, yearlyPct) === 7672,
    `yearly order amount = discountedPrice(9590, 20) = ${discountedPrice(starter!.priceYearly, yearlyPct)} (ROUND 80 law, unchanged)`
  );

  /* 2 — REAL order mint (the same createPlanOrder the checkout service calls) */
  const created = await createPlanOrder(
    probe,
    starter!.id,
    "monthly",
    WALLET_CHECKOUT_METHOD_ID
  );
  assert(created.ok, "createPlanOrder ok (wallet pseudo-method resolves without the console list)");
  const order = created.ok ? created.order : null;

  /* 3 — the wallet debits the order's OWN amount — exactly what
     plan-orders/service.ts:164 does post-ROUND 166 (`const amountMinor =
     result.order.amount` — toMinorUnits REMOVED) */
  const amountMinor = order!.amount;
  assert(
    amountMinor === 999,
    `PlanOrder.amount on the REAL row is ${amountMinor} (minor) — what the wallet will debit`
  );
  const pay = await payOrderFromWallet({
    instanceId: probe.id,
    amountMinor,
    linkId: order!.id,
    reference: order!.reference,
    note: "unit probe — minor-unit debit",
  });
  assert(pay.ok, "payOrderFromWallet ok (CAS debit)");
  assert(
    pay.ok && pay.balanceAfterMinor === SEED_MINOR - 999,
    `balance after debit = ${pay.ok ? pay.balanceAfterMinor : "?"} (5000 − 999, single ÷ nothing — NO 100× overcharge)`
  );

  /* 4 — compensating refund restores the exact minor figure */
  await refundWalletDebit({
    instanceId: probe.id,
    amountMinor,
    linkId: order!.id,
    reference: order!.reference,
    note: "unit probe — refund",
  });
  const restored = await readWalletBalance(probe.id);
  assert(restored === SEED_MINOR, `wallet restored to ${restored} (net-zero probe)`);

  /* 5 — cancel the pending order (HMAC re-verified — proves the seal still
     matches the minor-unit amount) */
  const cancelled = await cancelPlanOrder(order!.id);
  assert(cancelled.ok, "cancelPlanOrder ok (integrity HMAC valid over the minor-unit amount)");
} finally {
  /* cleanup — cascade removes the probe's PlanOrder + WalletTxn rows */
  await db.instance.delete({ where: { id: probe.id } });
  const leftoverOrders = await db.planOrder.count();
  const leftoverTxns = await db.walletTxn.count();
  const leftoverInstances = await db.instance.count();
  console.log(
    `CLEANUP — instances: ${leftoverInstances}, planOrders: ${leftoverOrders}, walletTxns: ${leftoverTxns} (all pre-probe values restored)`
  );
  await db.$disconnect();
}
