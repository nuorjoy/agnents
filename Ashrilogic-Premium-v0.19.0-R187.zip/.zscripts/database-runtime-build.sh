#!/bin/bash

set -euo pipefail

# Ashrilogic — runtime database provisioning step for the packaged build.
#
# PostgreSQL-only since the cutover: the runtime database is an EXTERNAL
# PostgreSQL service, and no database artifact ships inside the build.
# This script's former purpose (copying the seeded SQLite file db/custom.db
# into the build output and pushing the schema into the copy) is obsolete —
# it is kept as a documented no-op so build.sh's pipeline is unchanged.
#
# PROVISIONING CONTRACT (operator, at deploy time — NOT build time):
#   1. Provide DATABASE_URL — a PostgreSQL connection string
#      ("postgresql://…"). start.sh refuses to boot without it.
#   2. Apply the versioned migrations against that database:
#        bunx prisma migrate deploy
#      (run from the deployed package on the target host; the build machine
#      must never touch the production database).
#   3. Seed/bootstrap as needed (scripts/bootstrap-admin.ts, seed scripts).
#
# Exits 0 — there is nothing to build here anymore.

echo "🗄️  Runtime database: external PostgreSQL (DATABASE_URL) — nothing to package."
echo "    Provision at deploy time: DATABASE_URL=… bunx prisma migrate deploy"

exit 0
