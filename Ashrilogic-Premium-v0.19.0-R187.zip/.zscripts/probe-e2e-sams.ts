/* ROUND 168 — SAMS deep E2E simulation (the owner-directed test):
 * dormFacilities (المرافق والخدمات) · dormAttendance (الحضور والغياب) ·
 * dormPlacement (التسكين) — plus the fixed security/maintenance modules —
 * all through the REAL public APIs, including the shift law (records refuse
 * writes until a shift opens), real-record CRUD, attendance movements/policy/
 * QR, and cross-tenant isolation probes. Self-cleaning. */
const BASE = "http://localhost:3000";
const AR = (s: string) => s;

let pass = 0;
let fail = 0;
const failures: string[] = [];
function check(name: string, ok: boolean, extra = "") {
  if (ok) { pass++; console.log(`  ✓ ${name}${extra ? " — " + extra : ""}`); }
  else { fail++; failures.push(name); console.log(`  ✗ ${name}${extra ? " — " + extra : ""}`); }
}

interface Sim { instanceId: string; email: string; password: string; cookie: string }

async function api(sim: Sim | null, path: string, init?: RequestInit): Promise<{ status: number; body: any; cookie?: string }> {
  const headers: Record<string, string> = { "content-type": "application/json", origin: BASE };
  if (sim?.cookie) headers.cookie = sim.cookie;
  const res = await fetch(`${BASE}${path}`, { ...init, headers });
  let body: any = null;
  try { body = await res.json(); } catch { /* text */ }
  return { status: res.status, body };
}

async function login(instanceId: string, email: string, password: string): Promise<string | undefined> {
  const res = await fetch(`${BASE}/api/instances/auth/login`, {
    method: "POST",
    headers: { "content-type": "application/json", origin: BASE },
    body: JSON.stringify({ instanceId, email, password }),
  });
  const sc = res.headers.getSetCookie?.() ?? [];
  return sc.find((c) => c.startsWith("ashrilogic-instance-session"))?.split(";")[0];
}

/* ---------------- create the SAMS sim instance ---------------- */
async function createInstance(tag: string): Promise<Sim> {
  const email = `sams-e2e-${tag}+${Date.now()}@ashrilogic.test`;
  const password = "Sams-E2E-2026-Pass";
  const phone = `+24991${String(1000000 + Math.floor(Math.random() * 8999999))}`;
  const res = await fetch(`${BASE}/api/instances`, {
    method: "POST",
    headers: { "content-type": "application/json", origin: BASE },
    body: JSON.stringify({
      systemId: "student-accommodation",
      org: { name: `سكن اختبار ${tag}`, country: "SA", currency: "SAR", timezone: "Africa/Khartoum", address: "الحرم", phone },
      admin: { name: "مدير الاختبار", email, role: "owner", twoFA: false, password },
      prefs: { lang: "ar", theme: "dark", notif: true, backup: true, audit: true, demo: true },
      modules: ["dormBuildings", "dormRooms", "roomAssignments", "residents", "leases", "facilities", "maintenance", "security", "attendance", "payments", "staff", "reports", "invoices", "shifts", "expenses"],
    }),
  });
  const body = await res.json();
  if (res.status !== 201) throw new Error("create failed: " + JSON.stringify(body).slice(0, 300));
  const cookie = await login(body.id, email, password);
  return { instanceId: body.id, email, password, cookie: cookie ?? "" };
}

const sim = await createInstance("main");
console.log(`\n== SAMS E2E instance ${sim.instanceId} ==`);

/* ---------------- THE SHIFT LAW ---------------- */
console.log("\n[1] دوام shift law gates business writes");
// a record write BEFORE any shift → must be refused 403 SHIFT_REQUIRED
const early = await api(sim, `/api/instances/${sim.instanceId}/module-records`, {
  method: "POST",
  body: JSON.stringify({ moduleId: "facilities", values: ["FAC-00090001", "مغسلة تجريبية", "مبنى أ", "٢٤ ساعة", "20", "50.00", "available"], statusKey: "available" }),
});
check("record write refused before open shift", early.status === 403 && /SHIFT_REQUIRED|shift/i.test(JSON.stringify(early.body)), `status ${early.status}`);

// define the secret shift code (requires the workspace password) — PUT
const codeSet = await api(sim, `/api/instances/${sim.instanceId}/shifts/code`, {
  method: "PUT",
  body: JSON.stringify({ currentPassword: sim.password, newCode: "246810", length: 6 }),
});
check("secret shift code defined", codeSet.status === 200 || codeSet.status === 201, `status ${codeSet.status} ${JSON.stringify(codeSet.body).slice(0, 120)}`);

// open the shift with the secret code
const open = await api(sim, `/api/instances/${sim.instanceId}/shifts`, {
  method: "POST",
  body: JSON.stringify({ code: "246810", openingCash: 250 }),
});
check("shift OPENED with secret code", open.status === 201 || open.status === 200, `status ${open.status} ${JSON.stringify(open.body).slice(0, 120)}`);

/* ---------------- dormFacilities (المرافق والخدمات) ---------------- */
console.log("\n[2] dormFacilities — المرافق والخدمات real-record lifecycle");
const facCreate = await api(sim, `/api/instances/${sim.instanceId}/module-records`, {
  method: "POST",
  body: JSON.stringify({ moduleId: "facilities", values: ["FAC-00090001", "مغسلة تجريبية", "مبنى أ", "٢٤ ساعة", "20", "50.00", "available"], statusKey: "available" }),
});
check("facility record created", facCreate.status === 201, `status ${facCreate.status} ${JSON.stringify(facCreate.body).slice(0, 140)}`);
const facId: string | undefined = facCreate.body?.record?.id ?? facCreate.body?.id;

const facList = await api(sim, `/api/instances/${sim.instanceId}/module-records?moduleId=facilities`);
const facRow = (facList.body?.records ?? []).find((r: any) => (r.values ?? []).includes("مغسلة تجريبية"));
check("facility record readable (values + status persisted)", !!facRow && facRow.statusKey === "available");

if (facId) {
  const facUpdate = await api(sim, `/api/instances/${sim.instanceId}/module-records/${facId}`, {
    method: "PATCH",
    body: JSON.stringify({ statusKey: "maintenance", values: ["FAC-00090001", "مغسلة تجريبية", "مبنى أ", "٢٤ ساعة", "20", "50.00", "maintenance"] }),
  });
  check("facility record updated (status→maintenance)", facUpdate.status === 200, `status ${facUpdate.status}`);
  const badStatus = await api(sim, `/api/instances/${sim.instanceId}/module-records/${facId}`, {
    method: "PATCH",
    body: JSON.stringify({ statusKey: "not-a-real-status" }),
  });
  check("unknown status rejected (preset contract)", badStatus.status === 400, `status ${badStatus.status}`);
}

/* ---------------- dormPlacement (التسكين) ---------------- */
console.log("\n[3] dormPlacement — التسكين real-record lifecycle");
const asnCreate = await api(sim, `/api/instances/${sim.instanceId}/module-records`, {
  method: "POST",
  body: JSON.stringify({ moduleId: "roomAssignments", values: ["ASN-00070001", "طالب التسكين التجريبي", "2024112233", "RM-00002004", "مبنى ب", "2", "2026-09-28", "الفصل الأول 2026", "housed"], statusKey: "housed" }),
});
check("assignment record created", asnCreate.status === 201, `status ${asnCreate.status}`);
const asnList = await api(sim, `/api/instances/${sim.instanceId}/module-records?moduleId=roomAssignments`);
check("assignment record readable", (asnList.body?.records ?? []).some((r: any) => (r.values ?? [])[1] === "طالب التسكين التجريبي"));

/* ---------------- the fixed modules' server contracts ---------------- */
console.log("\n[4] الأمن والحراسة + الصيانة (السكن) server contracts");
const secCreate = await api(sim, `/api/instances/${sim.instanceId}/module-records`, {
  method: "POST",
  body: JSON.stringify({ moduleId: "security", values: ["SEC-00061001", "جولة حراسة", "مبنى أ — البوابة الرئيسية", "حارس التجربة", "ليلية", "2026-09-30", "تسجيل في سجل الأمن", "resolved"], statusKey: "resolved" }),
});
check("security record accepted against the NEW preset", secCreate.status === 201, `status ${secCreate.status} ${JSON.stringify(secCreate.body).slice(0, 120)}`);
const mntCreate = await api(sim, `/api/instances/${sim.instanceId}/module-records`, {
  method: "POST",
  body: JSON.stringify({ moduleId: "maintenance", values: ["MNT-00057001", "مصعد مبنى ج", "إصلاح عاجل", "فني التجربة", "4", "880.00", "2026-09-30", "inprogress"], statusKey: "inprogress" }),
});
check("dorm-maintenance record accepted", mntCreate.status === 201, `status ${mntCreate.status}`);

/* ---------------- dormAttendance (الحضور والغياب) ---------------- */
console.log("\n[5] dormAttendance — الحضور والغياب console");
const polGet = await api(sim, `/api/instances/${sim.instanceId}/attendance/policy`);
check("policy readable (authenticated workspace)", polGet.status === 200, `status ${polGet.status}`);

// seed a resident roster row (attendance derives states from residents module)
const resCreate = await api(sim, `/api/instances/${sim.instanceId}/module-records`, {
  method: "POST",
  body: JSON.stringify({
    moduleId: "residents",
    values: ["RES-00003001", "طالب الحضور التجريبي", "2024555666", "جامعة الملك سعود", "كلية الحاسب", "RM-00002004", "مبنى ب", "2026-08-01", "2027-06-30", "1500.00", "+249912345678", "active"],
    statusKey: "active",
  }),
});
check("resident (roster) row created", resCreate.status === 201, `status ${resCreate.status}`);

const roster = await api(sim, `/api/instances/${sim.instanceId}/attendance/roster`);
check("roster projects the resident row", (roster.body?.rows ?? []).some?.((e: any) => (e.name ?? "").includes("طالب الحضور")), JSON.stringify(roster.body).slice(0, 200));

// movements: IN then OUT for the resident (roster code RES-00003001)
const mvIn = await api(sim, `/api/instances/${sim.instanceId}/attendance/movements`, {
  method: "POST",
  body: JSON.stringify({ studentCode: "RES-00003001", direction: "in" }),
});
check("IN movement accepted", mvIn.status === 201 || mvIn.status === 200, `status ${mvIn.status} ${JSON.stringify(mvIn.body).slice(0, 140)}`);
const mvOut = await api(sim, `/api/instances/${sim.instanceId}/attendance/movements`, {
  method: "POST",
  body: JSON.stringify({ studentCode: "RES-00003001", direction: "out" }),
});
check("OUT movement accepted", mvOut.status === 201 || mvOut.status === 200, `status ${mvOut.status}`);

// two-shift policy (the دوام feature) — morning + evening
const polPut = await api(sim, `/api/instances/${sim.instanceId}/attendance/policy`, {
  method: "PUT",
  body: JSON.stringify({
    dayStartMin: 480,
    dayEndMin: 900,
    graceMin: 10,
    absenceEvalMin: 1380,
    requireReview: true,
    shifts: [
      { type: "morning", startMin: 480, endMin: 900, graceMin: 10 },
      { type: "evening", startMin: 930, endMin: 1320, graceMin: 15 },
    ],
  }),
});
check("two-shift policy saved (الصباحي + المسائي)", polPut.status === 200, `status ${polPut.status} ${JSON.stringify(polPut.body).slice(0, 200)}`);

const polGet2 = await api(sim, `/api/instances/${sim.instanceId}/attendance/policy`);
const shifts = polGet2.body?.policy?.shifts ?? polGet2.body?.shifts ?? [];
check("policy round-trips both shifts", Array.isArray(shifts) && shifts.length === 2, JSON.stringify(shifts).slice(0, 120));

// overlapping shifts must be rejected
const polOverlap = await api(sim, `/api/instances/${sim.instanceId}/attendance/policy`, {
  method: "PUT",
  body: JSON.stringify({
    dayStartMin: 480,
    dayEndMin: 900,
    graceMin: 10,
    absenceEvalMin: 1260,
    requireReview: true,
    shifts: [
      { type: "morning", startMin: 480, endMin: 900, graceMin: 10 },
      { type: "partial", startMin: 800, endMin: 1200, graceMin: 10, partialHours: 4 },
    ],
  }),
});
check("overlapping shifts rejected 400", polOverlap.status === 400, `status ${polOverlap.status}`);

// QR: mint + redeem round-trip for the resident
const qr = await api(sim, `/api/instances/${sim.instanceId}/attendance/qr`, {
  method: "POST",
  body: JSON.stringify({ studentCode: "RES-00003001", direction: "in", gateLabel: "البوابة الرئيسية" }),
});
check("gate QR minted", qr.status === 200 || qr.status === 201, `status ${qr.status} ${JSON.stringify(qr.body).slice(0, 120)}`);
const qrToken = qr.body?.token ?? qr.body?.qr?.token;
if (qrToken) {
  const redeem = await api(sim, `/api/instances/${sim.instanceId}/attendance/qr/redeem`, {
    method: "POST",
    body: JSON.stringify({ token: qrToken }),
  });
  check("gate QR redeemed (movement recorded)", redeem.status === 200 || redeem.status === 201, `status ${redeem.status} ${JSON.stringify(redeem.body).slice(0, 120)}`);
  const redeem2 = await api(sim, `/api/instances/${sim.instanceId}/attendance/qr/redeem`, {
    method: "POST",
    body: JSON.stringify({ token: qrToken }),
  });
  check("QR single-use enforced (second redeem refused)", redeem2.status >= 400, `status ${redeem2.status}`);
} else {
  check("gate QR token present", false, JSON.stringify(qr.body).slice(0, 160));
}

/* ---------------- tenant isolation ---------------- */
console.log("\n[6] cross-tenant isolation (no leaks)");
const other = await createInstance("other");
check("second (foreign) workspace created", !!other.cookie);

// foreign session cannot read the sim's records
const foreignRead = await api(other, `/api/instances/${sim.instanceId}/module-records?moduleId=facilities`);
check("foreign session cannot list sim's records", foreignRead.status === 401 || foreignRead.status === 403, `status ${foreignRead.status}`);

// foreign session cannot patch a sim record
const foreignPatch = await api(other, `/api/instances/${sim.instanceId}/module-records/${facId ?? "x"}`, {
  method: "PATCH",
  body: JSON.stringify({ statusKey: "closed" }),
});
check("foreign session cannot patch sim's record", foreignPatch.status === 401 || foreignPatch.status === 403 || foreignPatch.status === 404, `status ${foreignPatch.status}`);

// foreign session cannot read the sim's attendance policy
const foreignPol = await api(other, `/api/instances/${sim.instanceId}/attendance/policy`);
check("foreign session cannot read sim's attendance policy", foreignPol.status === 401 || foreignPol.status === 403, `status ${foreignPol.status}`);

// anonymous cannot read anything
const anon = await api(null, `/api/instances/${sim.instanceId}/module-records?moduleId=facilities`);
check("anonymous cannot read sim's records", anon.status === 401 || anon.status === 403, `status ${anon.status}`);

// record-ID collision across tenants is ALLOWED per-tenant namespace? verify codes are scoped:
// the foreign workspace ALSO obeys the shift law — open its own shift first
// (correct per-workspace semantics), then create the same-coded facility row
const otherCode = await api(other, `/api/instances/${other.instanceId}/shifts/code`, {
  method: "PUT",
  body: JSON.stringify({ currentPassword: other.password, newCode: "135790", length: 6 }),
});
const otherOpen = await api(other, `/api/instances/${other.instanceId}/shifts`, {
  method: "POST",
  body: JSON.stringify({ code: "135790", openingCash: 0 }),
});
check("foreign workspace shift law independent (own code + own open)", otherCode.status === 200 && (otherOpen.status === 200 || otherOpen.status === 201), `code ${otherCode.status} open ${otherOpen.status}`);
const otherFac = await api(other, `/api/instances/${other.instanceId}/module-records`, {
  method: "POST",
  body: JSON.stringify({ moduleId: "facilities", values: ["FAC-00090001", "منشأة الغير", "مبنى س", "٩ ص - ٥ م", "5", "10.00", "available"], statusKey: "available" }),
});
check("same code allowed in ANOTHER tenant (per-workspace namespace — correct isolation semantics)", otherFac.status === 201, `status ${otherFac.status}`);

// the SAME code in the SAME tenant must collide 409
const dup = await api(sim, `/api/instances/${sim.instanceId}/module-records`, {
  method: "POST",
  body: JSON.stringify({ moduleId: "facilities", values: ["FAC-00090001", "منشأة مكررة", "مبنى أ", "٢٤ ساعة", "1", "1.00", "available"], statusKey: "available" }),
});
check("duplicate code inside the SAME tenant rejected 409", dup.status === 409, `status ${dup.status}`);

/* ---------------- cleanup (self-cleaning) ---------------- */
console.log("\n[7] cleanup");
const clean = await (async () => {
  const { db } = await import("../src/lib/db").catch(() => ({ db: null as any }));
  if (!db) return "skipped (no direct db)";
  await db.instance.delete({ where: { id: sim.instanceId } }).catch(() => {});
  await db.instance.delete({ where: { id: other.instanceId } }).catch(() => {});
  return "deleted both sim instances";
})();
console.log("  cleanup:", clean);

console.log(`\n== RESULT: ${pass} pass / ${fail} fail ==`);
if (failures.length) { console.log("FAILURES:", failures.join(" · ")); process.exit(1); }
