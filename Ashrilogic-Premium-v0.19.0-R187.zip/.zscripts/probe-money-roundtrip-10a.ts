/* 10-a MoneyInput dev-server round-trip probe: PATCH a package with the
 * minor units MoneyInput produces for "10.9" (1090) → the persisted row and
 * the public feed carry 1090 (fmtPlanPrice prints 10.90) → restore 999. */
import { db } from "@/lib/db";
import { issueSessionToken } from "@/lib/server/admin-session";

const admin = await db.adminUser.findFirst({ where: { role: "super", deletedAt: null } });
if (!admin) throw new Error("no super admin row");
const { token } = issueSessionToken(admin.id, admin.sessionVersion ?? 0);

const base = "http://localhost:3000";
const headers = { "Content-Type": "application/json", cookie: `ashrilogic-admin-session=${token}`, origin: base };

/* the Starter row (converged id resolved live) */
const starter = await db.package.findFirst({ where: { nameEn: "Starter" }, select: { id: true, priceMonthly: true, priceYearly: true } });
if (!starter) throw new Error("Starter row missing");
const before = { priceMonthly: starter.priceMonthly, priceYearly: starter.priceYearly };

/* PATCH with exactly what the MoneyInput form submits for "10.9" / "103.90" */
const patch = await fetch(`${base}/api/admin/packages/${starter.id}`, {
  method: "PATCH",
  headers,
  body: JSON.stringify({ priceMonthly: 1090, priceYearly: 10390 }),
});
const patched = (await patch.json()) as { priceMonthly: number; priceYearly: number };
console.log("PATCH", patch.status, { priceMonthly: patched.priceMonthly, priceYearly: patched.priceYearly });

/* the public feed prints it via fmtPlanPrice (10.90) */
const feed = await fetch(`${base}/api/packages`);
const tiers = (await feed.json()) as Array<{ nameEn: string; priceMonthly: number }>;
const starterFeed = tiers.find((t) => t.nameEn === "Starter");
console.log("FEED", feed.status, { starterMonthly: starterFeed?.priceMonthly });

/* restore the shipped structure (the converge seed would too) */
const restore = await fetch(`${base}/api/admin/packages/${starter.id}`, {
  method: "PATCH",
  headers,
  body: JSON.stringify({ priceMonthly: before.priceMonthly, priceYearly: before.priceYearly }),
});
const restored = (await restore.json()) as { priceMonthly: number; priceYearly: number };
console.log("RESTORE", restore.status, { priceMonthly: restored.priceMonthly, priceYearly: restored.priceYearly });
await db.$disconnect();
console.log("PROBE DONE");
