import { db } from "@/lib/db";
import { blindIndex } from "@/lib/server/crypto-vault";
const idx = blindIndex("probe-10a@example.com") ?? "";
const rows = await db.enterpriseQuote.findMany({ where: { emailIndex: idx }, select: { id: true } });
for (const r of rows) {
  await db.auditLog.deleteMany({ where: { actorId: r.id, action: "platform.quoteCreate" } }).catch(() => undefined);
  await db.enterpriseQuote.delete({ where: { id: r.id } }).catch(() => undefined);
}
console.log("cleaned leftover probe rows:", rows.length);
await db.$disconnect();
