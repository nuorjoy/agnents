/* 7-a throwaway probe: verify the reveal API end-to-end over HTTP with a
   session cookie minted server-side (no credential guessing). */
import { db } from "@/lib/db";
import { issueSessionToken } from "@/lib/server/admin-session";
import { encryptField, blindIndex } from "@/lib/server/crypto-vault";

const admin = await db.adminUser.findFirst({ where: { role: "super", deletedAt: null } });
if (!admin) throw new Error("no super admin row");
const { token } = issueSessionToken(admin.id, admin.sessionVersion ?? 0);

const RUN = Math.random().toString(36).slice(2, 8);
const email = `probe-${RUN}@example.com`;
const sub = await db.subscriber.create({
  data: { email: encryptField(email) ?? "", emailIndex: blindIndex(email) ?? "" },
});

const base = "http://localhost:3000";
const jar: string[] = [];
const jfetch = async (method: string, body: unknown) => {
  const res = await fetch(`${base}/api/admin/email-reveal`, {
    method,
    headers: { "Content-Type": "application/json", cookie: `ashrilogic-admin-session=${token}`, origin: base, "x-forwarded-for": `9.9.9.${RUN.length}` },
    body: JSON.stringify(body),
  });
  const setCookie = res.headers.getSetCookie?.() ?? [];
  for (const c of setCookie) jar.push(c.split(";")[0]);
  return { status: res.status, body: (await res.json().catch(() => ({}))) as Record<string, unknown> };
};

const mint = await jfetch("POST", { targetType: "subscriber", targetId: sub.id, reason: "probe: end-to-end" });
console.log("MINT", mint.status, { token: (mint.body.token as string | undefined)?.slice(0, 8) + "…", expiresAt: mint.body.expiresAt });
const consume = await jfetch("PUT", { token: mint.body.token });
console.log("CONSUME", consume.status, { email: consume.body.email, mintedBy: consume.body.mintedBy });
const replay = await jfetch("PUT", { token: mint.body.token });
console.log("REPLAY", replay.status, replay.body);
const badReason = await jfetch("POST", { targetType: "subscriber", targetId: sub.id, reason: "" });
console.log("BAD_REASON", badReason.status, badReason.body);

await db.subscriber.delete({ where: { id: sub.id } }).catch(() => undefined);
await db.emailRevealToken.deleteMany({ where: { createdById: admin.id, reason: "probe: end-to-end" } }).catch(() => undefined);
await db.auditLog.deleteMany({ where: { actorId: admin.id, action: { in: ["admin.email-reveal-mint", "admin.email-reveal-consume"] } } }).catch(() => undefined);
console.log("PROBE DONE (self-cleaned)");
