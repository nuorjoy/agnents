/* SAMS simulation — creates a real student-accommodation workspace through
 * the PUBLIC wizard API (the exact user path), then walks every module
 * surface, capturing the session for browser simulation. */
const BASE = "http://localhost:3000";
const EMAIL = `sams-audit+${Date.now()}@ashrilogic.test`;
const PASSWORD = "Sams-Audit-2026-Pass";

const res = await fetch(`${BASE}/api/instances`, {
  method: "POST",
  headers: { "content-type": "application/json", origin: BASE },
  body: JSON.stringify({
    systemId: "student-accommodation",
    org: {
      name: "سكن جامعة النور — اختبار",
      country: "SA",
      currency: "SAR",
      timezone: "Africa/Khartoum",
      address: "الحرم الجامعي",
      phone: "+249912345678",
    },
    admin: {
      name: "مدير السكن",
      email: EMAIL,
      role: "owner",
      twoFA: false,
      password: PASSWORD,
    },
    prefs: { lang: "ar", theme: "dark", notif: true, backup: true, audit: true, demo: true },
    modules: [
      "dormBuildings", "dormRooms", "roomAssignments", "residents", "leases",
      "facilities", "maintenance", "security", "attendance", "payments",
      "staff", "reports", "invoices", "shifts", "expenses",
    ],
  }),
});
const setCookie = res.headers.getSetCookie?.() ?? [];
const body = await res.json();
console.log("STATUS:", res.status);
console.log("COOKIE:", setCookie.find((c) => c.startsWith("ashri_session")) ? "session captured" : "NO SESSION COOKIE");
if (res.status >= 400) {
  console.log("BODY:", JSON.stringify(body).slice(0, 800));
  process.exit(1);
}
console.log("INSTANCE ID:", body.instance?.id ?? body.id);
console.log("EMAIL:", EMAIL);
// stash for the browser step
await Bun.write(".zscripts/sams-sim.json", JSON.stringify({
  instanceId: body.instance?.id ?? body.id,
  email: EMAIL,
  password: PASSWORD,
  cookie: setCookie.find((c) => c.startsWith("ashri_session")),
}, null, 2));
console.log("saved .zscripts/sams-sim.json");
