/* SAMS module audit — prints, per module of the student-accommodation system:
 *  - the preset's column labels (ar/en) + status labels
 *  - 2 sample demo rows in BOTH languages
 *  - the bizConfig KPI labels + form section titles + form field coverage
 *  - flags: MISSING preset (generic fallback), untranslated cells (English
 *    letters inside the ar dataset / Arabic inside the en dataset) */
import { buildModuleDataset, modulePreset, codePrefixFor } from "../src/lib/module-data";
import { bizConfig } from "../src/components/dashboard/views/business/business-config";
import { SYSTEMS, MODULES } from "../src/data/catalog";

const sams = SYSTEMS.find((s) => s.id === "student-accommodation");
if (!sams) throw new Error("student-accommodation system missing");
console.log("SYSTEM:", sams.nameAr, "|", sams.nameEn, "| modules:", sams.mods.join(", "));

const AR_RE = /[\u0600-\u06FF]/;
const EN_RE = /[A-Za-z]/;

for (const mod of sams.mods) {
  const meta = MODULES.find((m) => m.id === mod);
  console.log("\n=========================================================");
  console.log(`MODULE ${mod} — ${meta?.nameAr ?? "(NO CATALOG NAME)"} / ${meta?.nameEn ?? "(no en)"}`);
  const preset = modulePreset(mod);
  const isGeneric = !preset ? true : false;
  if (isGeneric) console.log("  !! NO DEDICATED PRESET — generic fallback dataset");
  const cols = preset.cols.map((c) => `${c.key}[${c.ar}|${c.en}]`).join(" · ");
  console.log("  cols:", cols);
  console.log("  statuses:", preset.statuses.map((s) => `${s.key}[${s.ar}|${s.en}]`).join(" · "));
  console.log("  codePrefix:", codePrefixFor(mod));
  for (const lang of ["ar", "en"] as const) {
    const ds = buildModuleDataset("audit-instance", mod, lang, "SAR", "student-accommodation");
    const rows = ds.rows.slice(0, 2).map((r) => r.values.join(" | "));
    console.log(`  ${lang.toUpperCase()} rows[0..1]:`);
    rows.forEach((r) => console.log(`     ${r}`));
    const cells = ds.rows.flatMap((r) => r.values);
    if (lang === "ar") {
      const latinish = cells.filter((c) => EN_RE.test(c) && !/^[A-Z]{2,4}-\d+$/.test(c));
      const uniq = [...new Set(latinish)];
      if (uniq.length) console.log(`     ~ latin-ish cells in AR dataset (${uniq.length} uniq): ${uniq.slice(0, 8).join(" ; ")}`);
    } else {
      const arabish = cells.filter((c) => AR_RE.test(c));
      const uniq = [...new Set(arabish)];
      if (uniq.length) console.log(`     ~ ARABIC cells leaked into EN dataset (${uniq.length} uniq): ${uniq.slice(0, 8).join(" ; ")}`);
    }
  }
  const cfg = bizConfig(mod);
  const kpiLabels = cfg.kpis.map((k) => `${k.labelKey ?? ""}${k.labelAr ?? ""}/${k.labelEn ?? ""}`).join(" · ");
  console.log("  KPIs:", kpiLabels);
  console.log("  form sections:", cfg.form.map((s) => `${s.titleKey ?? ""}${s.titleAr ?? ""}/${s.titleEn ?? ""}(${s.fields.length}f)`).join(" · "));
  console.log("  displayCols:", cfg.displayCols.join(","));
}
