import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const rows = await db.package.findMany({
  orderBy: { sortOrder: "asc" },
  select: { nameEn: true, active: true, popular: true, priceMonthly: true, customPricing: true, maxSystems: true },
});
console.log(JSON.stringify(rows, null, 1));
await db.$disconnect();
