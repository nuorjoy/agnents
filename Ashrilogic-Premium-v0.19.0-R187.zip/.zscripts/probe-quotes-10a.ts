/* 10-a throwaway probe: the طلبات المؤسسات pipeline end-to-end over HTTP —
 * list (masked), PATCH transitions with stamps, illegal-transition 400,
 * adminNotes, the quote-target reveal lever, and the audit trail — then
 * self-cleans every row it created. */
import { db } from "@/lib/db";
import { issueSessionToken } from "@/lib/server/admin-session";

const admin = await db.adminUser.findFirst({ where: { role: "super", deletedAt: null } });
if (!admin) throw new Error("no super admin row");
const { token } = issueSessionToken(admin.id, admin.sessionVersion ?? 0);

const RUN = Math.random().toString(36).slice(2, 8);
const base = "http://localhost:3000";
const cookie = `ashrilogic-admin-session=${token}`;
const headers = { "Content-Type": "application/json", cookie, origin: base };

/* one fresh public lead through the REAL public endpoint */
const email = `probe-10a-${RUN}@example.com`;
const submit = await fetch(`${base}/api/enterprise-quotes`, {
  method: "POST",
  headers: { "Content-Type": "application/json", origin: base },
  body: JSON.stringify({
    name: `مسبار المؤسسات ${RUN}`,
    email,
    company: "Probe Corp",
    teamSize: "51-200",
    systemsCount: 25,
    notes: "probe lead",
  }),
});
console.log("SUBMIT", submit.status, await submit.json());

/* find the row (the feed is keyset; a fresh DB has few rows) */
const list = await fetch(`${base}/api/admin/enterprise-quotes?limit=100`, { headers });
const listBody = (await list.json()) as { rows: Array<{ id: string; emailMasked: string; status: string; adminNotes: string; contactedAt: string | null; quotedAt: string | null; closedAt: string | null }> };
console.log("LIST", list.status, "rows:", listBody.rows.length, "masked-sample:", listBody.rows[0]?.emailMasked);
const target = listBody.rows.find((r) => r.emailMasked.startsWith("p") && r.emailMasked.includes("example.com"));
if (!target) throw new Error("probe row not found in the inbox");

const patch = async (body: Record<string, unknown>) => {
  const res = await fetch(`${base}/api/admin/enterprise-quotes`, { method: "PATCH", headers, body: JSON.stringify(body) });
  return { status: res.status, body: (await res.json().catch(() => ({}))) as Record<string, unknown> };
};

/* legal ladder: new → contacted → quoted → won (stamps land on entry) */
const c1 = await patch({ id: target.id, status: "contacted" });
console.log("→contacted", c1.status, { contactedAt: c1.body.contactedAt });
const c2 = await patch({ id: target.id, status: "quoted", adminNotes: "working note from probe" });
console.log("→quoted", c2.status, { quotedAt: c2.body.quotedAt, notes: c2.body.adminNotes });
const c3 = await patch({ id: target.id, status: "won" });
console.log("→won", c3.status, { closedAt: c3.body.closedAt, status: c3.body.status });

/* terminal rows never reopen + skipped stages are refused */
const reopen = await patch({ id: target.id, status: "contacted" });
console.log("REOPEN(won→contacted)", reopen.status, reopen.body.code ?? reopen.body.error);
const skip = await patch({ id: target.id, status: "won" });
console.log("SKIP-LEGAL(won→won same)", skip.status);

/* unknown id → 404 */
const dead = await patch({ id: "clunknownquote0000000000000", status: "contacted" });
console.log("DEAD-ID", dead.status, dead.body.code ?? dead.body.error);

/* the quote-target reveal lever (super-only, one-time) */
const mint = await fetch(`${base}/api/admin/email-reveal`, {
  method: "POST",
  headers,
  body: JSON.stringify({ targetType: "quote", targetId: target.id, reason: "probe: quote reveal" }),
});
const mintBody = (await mint.json().catch(() => ({}))) as { token?: string };
const consume = await fetch(`${base}/api/admin/email-reveal`, {
  method: "PUT",
  headers,
  body: JSON.stringify({ token: mintBody.token }),
});
const consumeBody = (await consume.json().catch(() => ({}))) as { email?: string };
console.log("REVEAL", mint.status, consume.status, { email: consumeBody.email, matches: consumeBody.email === email });

/* the audit trail for the whole pipeline */
const audits = await db.auditLog.findMany({
  where: { actorId: admin.id, action: { in: ["platform.quoteStatus"] } },
  orderBy: { createdAt: "desc" },
  take: 10,
});
console.log("AUDIT platform.quoteStatus rows:", audits.length, "first meta:", audits[0]?.metaJson?.slice(0, 120));
const publicAudit = await db.auditLog.findFirst({ where: { action: "platform.quoteCreate" }, orderBy: { createdAt: "desc" } });
console.log("AUDIT platform.quoteCreate exists:", publicAudit !== null, "label:", publicAudit?.targetLabel);

/* self-clean: the probe row + its trail */
await db.emailRevealToken.deleteMany({ where: { createdById: admin.id, reason: "probe: quote reveal" } }).catch(() => undefined);
await db.auditLog.deleteMany({
  where: {
    OR: [
      { actorId: admin.id, action: "platform.quoteStatus" },
      { action: "platform.quoteCreate", actorId: target.id },
      { actorId: admin.id, action: { in: ["admin.email-reveal-mint", "admin.email-reveal-consume"] }, metaJson: { contains: "probe: quote reveal" } },
    ],
  },
}).catch(() => undefined);
await db.enterpriseQuote.deleteMany({ where: { emailIndex: null } }).catch(() => undefined);
await db.enterpriseQuote.delete({ where: { id: target.id } }).catch(() => undefined);
console.log("PROBE DONE (self-cleaned)");
