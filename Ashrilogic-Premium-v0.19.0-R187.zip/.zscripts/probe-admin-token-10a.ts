import { db } from "@/lib/db";
import { issueSessionToken } from "@/lib/server/admin-session";
const admin = await db.adminUser.findFirst({ where: { role: "super", deletedAt: null } });
if (!admin) throw new Error("no super admin row");
const { token } = issueSessionToken(admin.id, admin.sessionVersion ?? 0);
console.log(token);
await db.$disconnect();
