/* 10-a MoneyInput parser probe: comma, Arabic-Indic digits + U+066B decimal,
 * ≤2 decimals, third-dot rejection, bounds. */
import { moneyDisplayToMinor } from "@/components/ui/money-input";
const cases: Array<[string, number | null, string]> = [
  ["9.99", 999, "plain decimal"],
  ["9,99", 999, "comma → dot"],
  ["٩٫٩٩", 999, "Arabic-Indic + U+066B"],
  ["٩.٩٩", 999, "Arabic-Indic + ASCII dot"],
  ["12.5", 1250, "one decimal"],
  ["12.555", 1255, "third decimal digit truncated"],
  ["10", 1000, "integer"],
  ["", null, "empty"],
  [".", null, "lone dot"],
  ["1.2.3", 123, "second dot dropped (index law: 1.23)"],
  ["abc", null, "garbage"],
  ["٠", 0, "zero Arabic-Indic"],
];
let pass = 0;
for (const [input, expected, label] of cases) {
  const got = moneyDisplayToMinor(input);
  const ok = got === expected;
  if (ok) pass += 1;
  console.log(`${ok ? "PASS" : "FAIL"} ${label}: "${input}" → ${got} (expected ${expected})`);
}
console.log(`money parser: ${pass}/${cases.length}`);
