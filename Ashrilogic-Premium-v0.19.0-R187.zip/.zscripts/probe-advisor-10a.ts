/* 10-a engine probe: recommendPlan both arms + every reasoning metric.
 * Pure function — synthetic tiers (the shipped feed's quotas are deliberately
 * tight, so the FIT arm needs a synthetic professional tier with real
 * storage). Run: bun .zscripts/probe-advisor-10a.ts */
import { recommendPlan } from "@/lib/price-advisor";

const tiers = [
  { id: "starter", nameAr: "الأساسية", nameEn: "Starter", priceMonthly: 999, priceYearly: 9590, currency: "USD", maxUsers: 1, maxModules: 5, maxStorageMb: 128, maxSystems: 1, customPricing: false, popular: false, sortOrder: 1 },
  { id: "professional", nameAr: "الاحترافية", nameEn: "Professional", priceMonthly: 2499, priceYearly: 23990, currency: "USD", maxUsers: 5, maxModules: 30, maxStorageMb: 51200, maxSystems: 3, customPricing: false, popular: true, sortOrder: 2 },
  { id: "enterprise", nameAr: "المؤسسات", nameEn: "Enterprise", priceMonthly: 0, priceYearly: 0, currency: "USD", maxUsers: 100, maxModules: 200, maxStorageMb: 51200, maxSystems: 0, customPricing: true, popular: false, sortOrder: 3 },
];

/* 1. FIT arm — professional satisfies every dimension */
const fit = recommendPlan(tiers, { users: 3, modules: 12, systems: 2, storageGb: 10, budgetMonthly: 30 });
console.log("FIT:", JSON.stringify({
  kind: fit.kind,
  plan: fit.kind === "fit" ? fit.plan.nameEn : null,
  monthlyMinor: fit.kind === "fit" ? fit.monthlyMinor : null,
  yearlyMinor: fit.kind === "fit" ? fit.yearlyMinor : null,
  costPerUserMinor: fit.kind === "fit" ? fit.costPerUserMinor : null,
  yearlySavingPct: fit.kind === "fit" ? fit.yearlySavingPct : null,
  runnerUp: fit.kind === "fit" ? fit.runnerUp?.nameEn ?? null : null,
  overBudgetMinor: fit.kind === "fit" ? fit.overBudgetMinor : null,
  dims: fit.kind === "fit" ? fit.dimensions.map((d) => `${d.key}:${d.quota}${d.unlimited ? "(∞)" : ""}~${d.needed}+${d.headroomPct}%${d.fits ? "✓" : "✗"}`) : null,
}, null, 1));

/* 1b. budget within — overBudget 0 */
const within = recommendPlan(tiers, { users: 3, modules: 12, systems: 2, storageGb: 10, budgetMonthly: 24.99 });
console.log("WITHIN-BUDGET overBudgetMinor:", within.kind === "fit" ? within.overBudgetMinor : null);

/* 2. cheapest-wins: starter fits a minimal need */
const tiny = recommendPlan(tiers, { users: 1, modules: 3, systems: 1, storageGb: 0.125 });
console.log("TINY →", tiny.kind === "fit" ? tiny.plan.nameEn : "enterprise");

/* 3. ENTERPRISE arm — the LIVE feed (512 MB professional) with a 5 GB need */
const liveTiers = tiers.map((t) => (t.id === "professional" ? { ...t, maxStorageMb: 512 } : t));
const ent = recommendPlan(liveTiers, { users: 5, modules: 10, systems: 1, storageGb: 5 });
console.log("ENTERPRISE:", JSON.stringify({
  kind: ent.kind,
  enterprise: ent.kind === "enterprise" ? ent.enterprise?.nameEn ?? null : null,
  reasons: ent.kind === "enterprise" ? ent.reasons : null,
  cheapestRejected: ent.kind === "enterprise" ? ent.cheapestRejected?.nameEn ?? null : null,
}, null, 1));

/* 4. unlimited-systems dimension (custom tier only) */
const noFit = recommendPlan(liveTiers, { users: 8, modules: 40, systems: 5, storageGb: 1 });
console.log("NO-FIT systems>3 reasons:", noFit.kind === "enterprise" ? noFit.reasons.map((r) => r.key) : null);

/* 5. determinism: same inputs, same verdict (×3) */
const a = JSON.stringify(recommendPlan(liveTiers, { users: 4, modules: 9, systems: 1, storageGb: 2 }));
const b = JSON.stringify(recommendPlan(liveTiers, { users: 4, modules: 9, systems: 1, storageGb: 2 }));
const c = JSON.stringify(recommendPlan(liveTiers, { users: 4, modules: 9, systems: 1, storageGb: 2 }));
console.log("DETERMINISTIC:", a === b && b === c);
console.log("PROBE DONE");
