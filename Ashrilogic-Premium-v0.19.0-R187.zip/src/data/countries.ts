/**
 * Ashrilogic — shared country & timezone catalog (V2, verbatim).
 *
 * ROUND 84 (owner profile gate) — extracted VERBATIM from
 * src/components/wizard/wizard-shared.tsx, which now re-exports this module:
 * the list must be importable from SERVER code too (the strict
 * /api/instances/[id]/owner-profile route validates nationality against the
 * exact same codes), and a "use client" module's exports are opaque client
 * references on the server. Single source of truth — never duplicate this
 * list; import it from here (server) or from wizard-shared (client).
 *
 * Round 34 added the regional set the owner asked for: Sudan, South Sudan,
 * Ethiopia, Chad, Singapore, France, Germany, Spain, Brazil, Libya, Yemen,
 * Syria, Lebanon (verified ISO codes and currencies). Names stay bilingual
 * like the original list.
 *
 * ROUND 85 — the institution-data (بيانات المؤسسة) catalog grows by the
 * owner's requested set: Mauritania, Eritrea, Georgia, Cyprus, Greece,
 * Portugal, Colombia, Argentina, Switzerland, Sweden, Croatia (Brazil was
 * already present). Verified ISO 3166-1 alpha-2 codes, ISO 4217 currencies
 * and ITU dial codes; each also gained its IANA timezone below.
 *
 * ROUND 84 (84-CONTACT) — every entry now also carries its ITU dial code
 * ("+966" style, with the leading plus) for the unified PremiumPhoneInput.
 * The field is ADDITIVE: existing consumers (country selects, currency
 * autofill, the nationality zod enum) read code/name/currency and are
 * untouched. The single exception is "EU" — a currency union, not one
 * dialing region — so its dial is "" and dial-code consumers filter it out.
 */

export interface CountryOption {
  code: string;
  name: string;
  currency: string;
  /** ITU dial code incl. the leading "+" ("" when the entry spans several
   *  dialing regions — only the EU pseudo-entry today). */
  dial: string;
}

export const COUNTRIES: CountryOption[] = [
  /* العرب / Arab region */
  { code: "SA", name: "السعودية / Saudi Arabia", currency: "SAR", dial: "+966" },
  { code: "AE", name: "الإمارات / UAE", currency: "AED", dial: "+971" },
  { code: "EG", name: "مصر / Egypt", currency: "EGP", dial: "+20" },
  { code: "MA", name: "المغرب / Morocco", currency: "MAD", dial: "+212" },
  { code: "DZ", name: "الجزائر / Algeria", currency: "DZD", dial: "+213" },
  { code: "TN", name: "تونس / Tunisia", currency: "TND", dial: "+216" },
  { code: "JO", name: "الأردن / Jordan", currency: "JOD", dial: "+962" },
  { code: "KW", name: "الكويت / Kuwait", currency: "KWD", dial: "+965" },
  { code: "QA", name: "قطر / Qatar", currency: "QAR", dial: "+974" },
  { code: "BH", name: "البحرين / Bahrain", currency: "BHD", dial: "+973" },
  { code: "OM", name: "عمان / Oman", currency: "OMR", dial: "+968" },
  { code: "IQ", name: "العراق / Iraq", currency: "IQD", dial: "+964" },
  { code: "LY", name: "ليبيا / Libya", currency: "LYD", dial: "+218" },
  { code: "SY", name: "سوريا / Syria", currency: "SYP", dial: "+963" },
  { code: "LB", name: "لبنان / Lebanon", currency: "LBP", dial: "+961" },
  { code: "YE", name: "اليمن / Yemen", currency: "YER", dial: "+967" },
  { code: "SD", name: "السودان / Sudan", currency: "SDG", dial: "+249" },
  { code: "SS", name: "جنوب السودان / South Sudan", currency: "SSP", dial: "+211" },
  /* أمريكا الشمالية / North America */
  { code: "US", name: "USA / الولايات المتحدة", currency: "USD", dial: "+1" },
  { code: "CA", name: "كندا / Canada", currency: "CAD", dial: "+1" },
  /* أمريكا اللاتينية / Latin America */
  { code: "BR", name: "البرازيل / Brazil", currency: "BRL", dial: "+55" },
  { code: "MX", name: "المكسيك / Mexico", currency: "MXN", dial: "+52" },
  { code: "CO", name: "كولومبيا / Colombia", currency: "COP", dial: "+57" },
  { code: "AR", name: "الأرجنتين / Argentina", currency: "ARS", dial: "+54" },
  /* أوروبا / Europe */
  { code: "GB", name: "UK / المملكة المتحدة", currency: "GBP", dial: "+44" },
  { code: "EU", name: "EU / الاتحاد الأوروبي", currency: "EUR", dial: "" },
  { code: "FR", name: "فرنسا / France", currency: "EUR", dial: "+33" },
  { code: "DE", name: "ألمانيا / Germany", currency: "EUR", dial: "+49" },
  { code: "ES", name: "إسبانيا / Spain", currency: "EUR", dial: "+34" },
  { code: "IT", name: "إيطاليا / Italy", currency: "EUR", dial: "+39" },
  { code: "NL", name: "هولندا / Netherlands", currency: "EUR", dial: "+31" },
  { code: "GR", name: "اليونان / Greece", currency: "EUR", dial: "+30" },
  { code: "PT", name: "البرتغال / Portugal", currency: "EUR", dial: "+351" },
  { code: "CY", name: "قبرص / Cyprus", currency: "EUR", dial: "+357" },
  { code: "GE", name: "جورجيا / Georgia", currency: "GEL", dial: "+995" },
  { code: "CH", name: "سويسرا / Switzerland", currency: "CHF", dial: "+41" },
  { code: "SE", name: "السويد / Sweden", currency: "SEK", dial: "+46" },
  { code: "HR", name: "كرواتيا / Croatia", currency: "EUR", dial: "+385" },
  /* آسيا / Asia */
  { code: "TR", name: "تركيا / Turkey", currency: "TRY", dial: "+90" },
  { code: "CN", name: "الصين / China", currency: "CNY", dial: "+86" },
  { code: "JP", name: "اليابان / Japan", currency: "JPY", dial: "+81" },
  { code: "KR", name: "كوريا / South Korea", currency: "KRW", dial: "+82" },
  { code: "IN", name: "الهند / India", currency: "INR", dial: "+91" },
  { code: "PK", name: "باكستان / Pakistan", currency: "PKR", dial: "+92" },
  { code: "SG", name: "سنغافورة / Singapore", currency: "SGD", dial: "+65" },
  /* أفريقيا / Africa */
  { code: "ET", name: "إثيوبيا / Ethiopia", currency: "ETB", dial: "+251" },
  { code: "TD", name: "تشاد / Chad", currency: "XAF", dial: "+235" },
  { code: "MR", name: "موريتانيا / Mauritania", currency: "MRU", dial: "+222" },
  { code: "ER", name: "إريتريا / Eritrea", currency: "ERN", dial: "+291" },
];

export const TIMEZONES = [
  /* العرب / Arab region */
  "Asia/Riyadh",
  "Asia/Dubai",
  "Africa/Cairo",
  "Africa/Casablanca",
  "Africa/Algiers",
  "Africa/Tunis",
  "Asia/Amman",
  "Asia/Kuwait",
  "Asia/Qatar",
  "Asia/Bahrain",
  "Asia/Muscat",
  "Asia/Baghdad",
  "Africa/Tripoli",
  "Asia/Damascus",
  "Asia/Beirut",
  "Asia/Aden",
  "Africa/Khartoum",
  "Africa/Juba",
  /* أمريكا الشمالية / North America */
  "America/New_York",
  "America/Toronto",
  /* أمريكا اللاتينية / Latin America */
  "America/Sao_Paulo",
  "America/Mexico_City",
  "America/Bogota",
  "America/Argentina/Buenos_Aires",
  /* أوروبا / Europe */
  "Europe/London",
  "Europe/Paris",
  "Europe/Berlin",
  "Europe/Madrid",
  "Europe/Rome",
  "Europe/Amsterdam",
  "Europe/Athens",
  "Europe/Lisbon",
  "Europe/Zurich",
  "Europe/Stockholm",
  "Europe/Zagreb",
  "Asia/Nicosia",
  "Asia/Tbilisi",
  /* آسيا / Asia */
  "Europe/Istanbul",
  "Asia/Shanghai",
  "Asia/Tokyo",
  "Asia/Seoul",
  "Asia/Kolkata",
  "Asia/Karachi",
  "Asia/Singapore",
  /* أفريقيا / Africa */
  "Africa/Addis_Ababa",
  "Africa/Ndjamena",
  "Africa/Nouakchott",
  "Africa/Asmara",
];
