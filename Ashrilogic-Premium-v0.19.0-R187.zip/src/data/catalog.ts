/**
 * Ashrilogic — Static catalog.
 * Faithfully extracted from the V2 single-file app
 * (upload/deepseek_html_20260910_e7d027.html → CATS / M / SYSTEMS).
 * All Arabic + English text is kept EXACTLY as in the source.
 * Font Awesome icons were semantically mapped to lucide-react icon names
 * (resolved through src/lib/icons.ts).
 */
import type { Catalog, Category, Lang, ModuleDef, SystemDef } from "@/lib/types";

/* ============================================================
   CATEGORIES (16 — "all" is a UI pseudo-category, not part of data)
============================================================ */
/* ROUND 147 — كل فئة تحمل "inventory" تحمل أيضًا "products" (توجيه المالك: الأنظمة ذات المخزون تبيع منتجات — يربطها المتجر عبر STORE_MODULE_PRIORITY). */
export const CATEGORIES: Category[] = [
  { id: "health", nameAr: "الصحة والرعاية الطبية", nameEn: "Healthcare", icon: "heart-pulse", c1: "#f43f5e", c2: "#be185d", mods: ["patients", "appointments", "prescriptions", "lab", "radiology", "ehr", "beds", "operations", "emergency", "insurance", "invoices", "products", "inventory", "staff", "reports", "telemedicine", "pharmacy"] },
  { id: "education", nameAr: "التعليم والتدريب", nameEn: "Education", icon: "graduation-cap", c1: "#6366f1", c2: "#7c3aed", mods: ["students", "teachers", "courses", "grades", "attendance", "fees", "exams", "timetable", "parents", "transport", "library", "cafeteria", "staff", "reports", "elearning", "certificates"] },
  { id: "retail", nameAr: "التجارة والتجزئة", nameEn: "Retail & Commerce", icon: "store", c1: "#f59e0b", c2: "#ea580c", mods: ["products", "pos", "inventory", "customers", "suppliers", "invoices", "purchases", "promotions", "loyalty", "returns", "reports", "branches", "pricing", "stocktake"] },
  { id: "hospitality", nameAr: "المطاعم والضيافة", nameEn: "Restaurants & Hospitality", icon: "utensils", c1: "#ef4444", c2: "#b91c1c", mods: ["reservations", "rooms", "menu", "orders", "kitchen", "tables", "delivery", "events", "staff", "products", "inventory", "invoices", "reports", "reviews", "housekeeping"] },
  { id: "services", nameAr: "الخدمات والحجوزات", nameEn: "Services & Booking", icon: "concierge-bell", c1: "#06b6d4", c2: "#2563eb", mods: ["bookings", "services", "customers", "staff", "invoices", "payments", "reports", "subscriptions", "commissions", "scheduling", "contracts", "reminders"] },
  { id: "finance", nameAr: "المالية والمحاسبة", nameEn: "Finance & Accounting", icon: "coins", c1: "#10b981", c2: "#0d9488", mods: ["invoices", "payments", "accounting", "customers", "reports", "documents", "taxes", "reconciliation", "expenses", "payroll", "bankfeeds", "quotations"] },
  { id: "logistics", nameAr: "النقل واللوجستيات", nameEn: "Transport & Logistics", icon: "truck", c1: "#0ea5e9", c2: "#4f46e5", mods: ["shipments", "tracking", "fleet", "drivers", "invoices", "products", "inventory", "reports", "routes", "warehouses", "deliveries", "customs", "documents"] },
  { id: "agriculture", nameAr: "الزراعة والثروة الحيوانية", nameEn: "Agriculture", icon: "sprout", c1: "#84cc16", c2: "#16a34a", mods: ["production", "products", "inventory", "tasks", "assets", "reports", "staff", "feeding", "animalhealth", "breeding", "harvest", "sales", "irrigation"] },
  { id: "industry", nameAr: "الصناعة والهندسة", nameEn: "Industry & Engineering", icon: "factory", c1: "#475569", c2: "#1e293b", mods: ["projects", "tasks", "assets", "maintenance", "products", "inventory", "reports", "staff", "resources", "drawings", "safety", "quality", "contracts"] },
  { id: "media", nameAr: "التسويق والإعلام", nameEn: "Marketing & Media", icon: "megaphone", c1: "#d946ef", c2: "#9333ea", mods: ["campaigns", "leads", "customers", "projects", "reports", "documents", "content", "publishing", "analytics", "billing", "creative", "distribution"] },
  { id: "hr", nameAr: "الموارد البشرية", nameEn: "Human Resources", icon: "user-cog", c1: "#8b5cf6", c2: "#6d28d9", mods: ["staff", "attendance", "payroll", "leaves", "recruitment", "training", "reports", "performance", "benefits", "contracts", "onboarding", "timeclock"] },
  { id: "fun", nameAr: "الترفيه والألعاب", nameEn: "Entertainment", icon: "gamepad-2", c1: "#ec4899", c2: "#e11d48", mods: ["bookings", "members", "subscriptions", "pos", "products", "inventory", "reports", "tournaments", "equipment", "sessions", "loyalty"] },
  { id: "legal", nameAr: "القانوني والمهني", nameEn: "Legal & Professional", icon: "scale", c1: "#64748b", c2: "#334155", mods: ["cases", "documents", "clients", "appointments", "invoices", "reports", "hearings", "contracts", "billing", "timetracking", "deadlines"] },
  { id: "nonprofit", nameAr: "الجمعيات والمنظمات", nameEn: "Nonprofit", icon: "heart-handshake", c1: "#14b8a6", c2: "#0f766e", mods: ["donations", "members", "events", "documents", "reports", "volunteers", "projects", "beneficiaries", "fundraising", "communications"] },
  { id: "general", nameAr: "خدمات عامة وحرفية", nameEn: "General Services", icon: "wrench", c1: "#0891b2", c2: "#155e75", mods: ["jobs", "products", "inventory", "customers", "invoices", "reports", "staff", "appointments", "commissions", "warranty", "tracking"] },
  /* ROUND 144 — فئة الأمن والحراسة (SGCMS): إدارة شركات الأمن والحراسة —
   * الحراس والدوريات والبلاغات والتراخيص والتدريب والعتاد. */
  { id: "security", nameAr: "الأمن والحراسة", nameEn: "Security & Protection", icon: "shield", c1: "#b45309", c2: "#7c2d12", mods: ["guards", "patrols", "incidents", "branches", "training", "licenses", "equipment", "attendance", "payroll", "staff", "contracts", "customers", "invoices", "reports", "assets"] },
];

/* ============================================================
   MODULES (144 — key → module definition)
============================================================ */
export const MODULES: ModuleDef[] = [
  { id: "patients", nameAr: "المرضى", nameEn: "Patients", icon: "user-round" },
  { id: "appointments", nameAr: "المواعيد", nameEn: "Appointments", icon: "calendar-check" },
  { id: "prescriptions", nameAr: "الوصفات", nameEn: "Prescriptions", icon: "pill" },
  { id: "lab", nameAr: "المختبر", nameEn: "Laboratory", icon: "flask-conical" },
  { id: "radiology", nameAr: "الأشعة", nameEn: "Radiology", icon: "scan" },
  { id: "ehr", nameAr: "الملف الطبي", nameEn: "EHR", icon: "file-heart" },
  { id: "beds", nameAr: "الأسرّة", nameEn: "Beds", icon: "bed-double" },
  { id: "operations", nameAr: "العمليات", nameEn: "Operations", icon: "syringe" },
  { id: "emergency", nameAr: "الطوارئ", nameEn: "Emergency", icon: "ambulance" },
  { id: "insurance", nameAr: "التأمين", nameEn: "Insurance", icon: "shield-check" },
  { id: "telemedicine", nameAr: "الطب عن بُعد", nameEn: "Telemedicine", icon: "video" },
  { id: "pharmacy", nameAr: "الصيدلية", nameEn: "Pharmacy", icon: "pill-bottle" },
  { id: "students", nameAr: "الطلاب", nameEn: "Students", icon: "graduation-cap" },
  { id: "teachers", nameAr: "المعلمون", nameEn: "Teachers", icon: "presentation" },
  { id: "courses", nameAr: "المقررات", nameEn: "Courses", icon: "book-open" },
  { id: "grades", nameAr: "الدرجات", nameEn: "Grades", icon: "award" },
  { id: "attendance", nameAr: "الحضور", nameEn: "Attendance", icon: "clipboard-list" },
  { id: "fees", nameAr: "الرسوم", nameEn: "Fees", icon: "receipt" },
  { id: "exams", nameAr: "الامتحانات", nameEn: "Exams", icon: "file-pen" },
  { id: "timetable", nameAr: "الجداول", nameEn: "Timetable", icon: "grid-3x3" },
  { id: "parents", nameAr: "أولياء الأمور", nameEn: "Parents", icon: "house" },
  /* ROUND 149 — الكليات: flagship module for university-management (النظام 14). */
  { id: "colleges", nameAr: "الكليات", nameEn: "Colleges", icon: "building" },
  { id: "transport", nameAr: "النقل", nameEn: "Transport", icon: "bus" },
  { id: "library", nameAr: "المكتبة", nameEn: "Library", icon: "book-marked" },
  { id: "cafeteria", nameAr: "المقصف", nameEn: "Cafeteria", icon: "utensils" },
  { id: "elearning", nameAr: "التعلم الإلكتروني", nameEn: "E-Learning", icon: "laptop" },
  { id: "certificates", nameAr: "الشهادات", nameEn: "Certificates", icon: "badge-check" },
  { id: "products", nameAr: "المنتجات", nameEn: "Products", icon: "package" },
  { id: "pos", nameAr: "نقاط البيع", nameEn: "POS", icon: "calculator" },
  { id: "inventory", nameAr: "المخزون", nameEn: "Inventory", icon: "boxes" },
  { id: "customers", nameAr: "العملاء", nameEn: "Customers", icon: "user-round" },
  { id: "suppliers", nameAr: "الموردون", nameEn: "Suppliers", icon: "truck" },
  { id: "invoices", nameAr: "الفواتير", nameEn: "Invoices", icon: "receipt" },
  { id: "purchases", nameAr: "المشتريات", nameEn: "Purchases", icon: "shopping-cart" },
  { id: "promotions", nameAr: "العروض", nameEn: "Promotions", icon: "tags" },
  { id: "loyalty", nameAr: "الولاء", nameEn: "Loyalty", icon: "heart" },
  { id: "returns", nameAr: "المرتجعات", nameEn: "Returns", icon: "rotate-ccw" },
  { id: "reports", nameAr: "التقارير", nameEn: "Reports", icon: "chart-pie" },
  { id: "branches", nameAr: "الفروع", nameEn: "Branches", icon: "network" },
  { id: "barcode", nameAr: "الباركود", nameEn: "Barcode", icon: "barcode" }, /* ROUND 132: retired as a STANDALONE module (the owner's directive — barcode lives INSIDE products/POS/inventory now); the definition stays for legacy row lookups only */
  { id: "pricing", nameAr: "التسعير", nameEn: "Pricing", icon: "dollar-sign" },
  { id: "stocktake", nameAr: "الجرد", nameEn: "Stocktake", icon: "clipboard-check" },
  { id: "reservations", nameAr: "الحجوزات", nameEn: "Reservations", icon: "calendar-days" },
  /* ROUND 168 — الغرف (hospitality): the hotel/restaurant guest-room register
     (5 hospitality systems curate the id; the entry closes the raw-id leak —
     the SAMS dorm rooms stay the separate dormRooms module). */
  { id: "rooms", nameAr: "الغرف", nameEn: "Rooms", icon: "door-open" },
  { id: "menu", nameAr: "قائمة الطعام", nameEn: "Menu", icon: "book-open" },
  { id: "orders", nameAr: "الطلبات", nameEn: "Orders", icon: "receipt" },
  { id: "kitchen", nameAr: "المطبخ", nameEn: "Kitchen", icon: "flame" },
  { id: "tables", nameAr: "الطاولات", nameEn: "Tables", icon: "armchair" },
  { id: "delivery", nameAr: "التوصيل", nameEn: "Delivery", icon: "bike" },
  { id: "events", nameAr: "المناسبات", nameEn: "Events", icon: "party-popper" },
  { id: "staff", nameAr: "الموظفون", nameEn: "Staff", icon: "users" },
  { id: "reviews", nameAr: "التقييمات", nameEn: "Reviews", icon: "star" },
  { id: "housekeeping", nameAr: "التدبير المنزلي", nameEn: "Housekeeping", icon: "brush" },
  { id: "bookings", nameAr: "الحجوزات", nameEn: "Bookings", icon: "calendar-check" },
  { id: "services", nameAr: "الخدمات", nameEn: "Services", icon: "concierge-bell" },
  { id: "payments", nameAr: "المدفوعات", nameEn: "Payments", icon: "credit-card" },
  { id: "subscriptions", nameAr: "الاشتراكات", nameEn: "Subscriptions", icon: "repeat" },
  { id: "commissions", nameAr: "العمولات", nameEn: "Commissions", icon: "percent" },
  { id: "scheduling", nameAr: "الجدولة", nameEn: "Scheduling", icon: "clock" },
  { id: "contracts", nameAr: "العقود", nameEn: "Contracts", icon: "file-pen" },
  { id: "reminders", nameAr: "التذكيرات", nameEn: "Reminders", icon: "bell" },
  { id: "accounting", nameAr: "المحاسبة", nameEn: "Accounting", icon: "calculator" },
  { id: "documents", nameAr: "المستندات", nameEn: "Documents", icon: "folder-open" },
  { id: "taxes", nameAr: "الضرائب", nameEn: "Taxes", icon: "percent" },
  { id: "reconciliation", nameAr: "التسويات", nameEn: "Reconciliation", icon: "scale" },
  { id: "expenses", nameAr: "المصروفات", nameEn: "Expenses", icon: "banknote" },
  { id: "payroll", nameAr: "الرواتب", nameEn: "Payroll", icon: "wallet" },
  { id: "bankfeeds", nameAr: "البنوك", nameEn: "Bank Feeds", icon: "landmark" },
  { id: "quotations", nameAr: "عروض الأسعار", nameEn: "Quotations", icon: "file-text" },
  { id: "shipments", nameAr: "الشحنات", nameEn: "Shipments", icon: "package" },
  { id: "tracking", nameAr: "التتبع", nameEn: "Tracking", icon: "locate-fixed" },
  { id: "fleet", nameAr: "الأسطول", nameEn: "Fleet", icon: "truck" },
  { id: "drivers", nameAr: "السائقون", nameEn: "Drivers", icon: "id-card" },
  { id: "routes", nameAr: "المسارات", nameEn: "Routes", icon: "route" },
  { id: "warehouses", nameAr: "المخازن", nameEn: "Warehouses", icon: "warehouse" },
  { id: "deliveries", nameAr: "التسليمات", nameEn: "Deliveries", icon: "truck" },
  { id: "customs", nameAr: "الجمارك", nameEn: "Customs", icon: "globe" },
  { id: "production", nameAr: "الإنتاج", nameEn: "Production", icon: "cog" },
  { id: "tasks", nameAr: "المهام", nameEn: "Tasks", icon: "list-checks" },
  { id: "assets", nameAr: "الأصول", nameEn: "Assets", icon: "building" },
  { id: "feeding", nameAr: "التغذية", nameEn: "Feeding", icon: "wheat" },
  { id: "animalhealth", nameAr: "صحة الحيوان", nameEn: "Animal Health", icon: "heart-pulse" },
  { id: "breeding", nameAr: "التكاثر", nameEn: "Breeding", icon: "heart" },
  { id: "harvest", nameAr: "الحصاد", nameEn: "Harvest", icon: "wheat" },
  { id: "sales", nameAr: "المبيعات", nameEn: "Sales", icon: "tag" },
  { id: "irrigation", nameAr: "الري", nameEn: "Irrigation", icon: "droplets" },
  { id: "projects", nameAr: "المشاريع", nameEn: "Projects", icon: "folder-kanban" },
  { id: "maintenance", nameAr: "الصيانة", nameEn: "Maintenance", icon: "wrench" },
  { id: "resources", nameAr: "الموارد", nameEn: "Resources", icon: "cuboid" },
  { id: "drawings", nameAr: "المخططات", nameEn: "Drawings", icon: "drafting-compass" },
  { id: "safety", nameAr: "السلامة", nameEn: "Safety", icon: "hard-hat" },
  { id: "quality", nameAr: "الجودة", nameEn: "Quality", icon: "clipboard-check" },
  { id: "campaigns", nameAr: "الحملات", nameEn: "Campaigns", icon: "megaphone" },
  { id: "leads", nameAr: "العملاء المحتملون", nameEn: "Leads", icon: "funnel" },
  { id: "content", nameAr: "المحتوى", nameEn: "Content", icon: "feather" },
  { id: "publishing", nameAr: "النشر", nameEn: "Publishing", icon: "newspaper" },
  { id: "analytics", nameAr: "التحليلات", nameEn: "Analytics", icon: "chart-line" },
  { id: "billing", nameAr: "الفوترة", nameEn: "Billing", icon: "file-text" },
  { id: "creative", nameAr: "الإبداع", nameEn: "Creative", icon: "palette" },
  { id: "distribution", nameAr: "التوزيع", nameEn: "Distribution", icon: "share-2" },
  { id: "leaves", nameAr: "الإجازات", nameEn: "Leaves", icon: "plane" },
  { id: "recruitment", nameAr: "التوظيف", nameEn: "Recruitment", icon: "user-plus" },
  { id: "training", nameAr: "التدريب", nameEn: "Training", icon: "graduation-cap" },
  { id: "performance", nameAr: "الأداء", nameEn: "Performance", icon: "gauge" },
  { id: "benefits", nameAr: "المزايا", nameEn: "Benefits", icon: "hand-coins" },
  { id: "onboarding", nameAr: "التهيئة", nameEn: "Onboarding", icon: "user-check" },
  { id: "timeclock", nameAr: "ساعة الدوام", nameEn: "Time Clock", icon: "clock" },
  { id: "members", nameAr: "الأعضاء", nameEn: "Members", icon: "id-card" },
  { id: "tournaments", nameAr: "البطولات", nameEn: "Tournaments", icon: "trophy" },
  { id: "equipment", nameAr: "الأجهزة والمعدات", nameEn: "Equipment", icon: "wrench" },
  { id: "sessions", nameAr: "الجلسات", nameEn: "Sessions", icon: "timer" },
  { id: "cases", nameAr: "القضايا", nameEn: "Cases", icon: "gavel" },
  { id: "clients", nameAr: "العملاء", nameEn: "Clients", icon: "handshake" },
  { id: "hearings", nameAr: "الجلسات", nameEn: "Hearings", icon: "landmark" },
  { id: "timetracking", nameAr: "تتبع الوقت", nameEn: "Time Tracking", icon: "clock" },
  { id: "deadlines", nameAr: "المواعيد النهائية", nameEn: "Deadlines", icon: "hourglass" },
  { id: "donations", nameAr: "التبرعات", nameEn: "Donations", icon: "heart-handshake" },
  { id: "volunteers", nameAr: "المتطوعون", nameEn: "Volunteers", icon: "users-round" },
  { id: "beneficiaries", nameAr: "المستفيدون", nameEn: "Beneficiaries", icon: "users" },
  { id: "fundraising", nameAr: "جمع التبرعات", nameEn: "Fundraising", icon: "target" },
  { id: "communications", nameAr: "التواصل", nameEn: "Communications", icon: "messages-square" },
  { id: "jobs", nameAr: "الأعمال", nameEn: "Jobs", icon: "wrench" },
  { id: "warranty", nameAr: "الضمان", nameEn: "Warranty", icon: "shield-check" },

  /* ---- ROUND 144: security & guard company (SGCMS) specialization ---- */
  { id: "guards", nameAr: "الحراس", nameEn: "Guards", icon: "shield-user" },
  { id: "patrols", nameAr: "الدوريات", nameEn: "Patrols", icon: "route" },
  { id: "incidents", nameAr: "البلاغات والحالات", nameEn: "Incidents", icon: "siren" },
  { id: "licenses", nameAr: "التراخيص والتصاريح", nameEn: "Licenses & Permits", icon: "stamp" },

  /* ---- round 29: gym / barbershop / driving-school specialization ----
     (equipment already exists above — renamed to الأجهزة والمعدات.) */
  { id: "coaches", nameAr: "المدربون", nameEn: "Coaches", icon: "medal" },
  { id: "classes", nameAr: "الحصص التدريبية", nameEn: "Training Classes", icon: "calendar-clock" },
  { id: "workouts", nameAr: "برامج التمرين", nameEn: "Workout Programs", icon: "dumbbell" },
  { id: "measurements", nameAr: "القياسات الجسدية", nameEn: "Body Measurements", icon: "ruler" },
  { id: "nutrition", nameAr: "الخطط الغذائية", nameEn: "Nutrition Plans", icon: "utensils" },
  { id: "lockers", nameAr: "الخزائن", nameEn: "Lockers", icon: "lock" },
  { id: "queue", nameAr: "قائمة الانتظار", nameEn: "Waiting Queue", icon: "timer" },
  { id: "vehicles", nameAr: "المركبات", nameEn: "Vehicles", icon: "car" },
  { id: "lessons", nameAr: "دروس التدريب", nameEn: "Training Lessons", icon: "graduation-cap" },
  { id: "memberships", nameAr: "عضويات العملاء", nameEn: "Client Memberships", icon: "badge-check" },

  /* ---- ROUND 134 — نظام الورديات as a first-class TOGGLEABLE module ----
     The owner's directive: «في جميع الأنظمة الـ100 عند (الوحدات) أضف
     (الورديات) يمكن تفعيله او ايقافه نفس طريقة تحكم الوحدات». The
     definition lives here (icon + bilingual name); systemMods() appends it
     to EVERY system's effective module list so the الوحدات control renders
     the toggle in all 102 systems. While enabled, the R133 strict shift law
     applies (server-enforced gate + sign-out lock + secret-code open);
     while disabled the whole shift surface stands down. */
  { id: "shifts", nameAr: "الورديات", nameEn: "Shifts", icon: "clock" },

  /* ROUND 153 — SAMS modules (Student Accommodation Management) */
  { id: "dormBuildings", nameAr: "المباني", nameEn: "Buildings", icon: "building-2" },
  { id: "dormRooms", nameAr: "الغرف", nameEn: "Rooms", icon: "door-open" },
  /* ROUND 166 — التسكين: the dedicated housing/assignment module (bed-level
     allocation of students into rooms, academic-term scoped) — the premium
     SAMS refinement requested by the owner. */
  { id: "roomAssignments", nameAr: "التسكين", nameEn: "Room Assignment", icon: "bed-double" },
  { id: "residents", nameAr: "الساكنون", nameEn: "Residents", icon: "users" },
  { id: "leases", nameAr: "عقود الإيجار", nameEn: "Leases", icon: "file-text" },
  /* ROUND 166 — المرافق والخدمات: dorm facilities & services (laundry,
     gym, cafeteria, internet, cleaning…) with hours, fees and upkeep. */
  { id: "facilities", nameAr: "المرافق والخدمات", nameEn: "Facilities & Services", icon: "concierge-bell" },
  /* ROUND 168 — الأمن والحراسة: the SAMS dorm-security register (patrol
     rounds, visitor passes, curfew violations, gate logs). SAMS-EXCLUSIVE
     module id — the security CATEGORY keeps its own guards/patrols/incidents
     modules; this entry exists so the workspace never renders the raw id
     (the untranslated-module defect this round closes). */
  { id: "security", nameAr: "الأمن والحراسة", nameEn: "Security & Guarding", icon: "shield" },
];

/* ============================================================
   SYSTEMS (100 — code 1..100 in original order)
============================================================ */
export const SYSTEMS: SystemDef[] = [
  /* ============ HEALTH (11) ============ */
  { id: "hospital-management", code: 1, nameAr: "إدارة المستشفيات", nameEn: "Hospital Management", c: "health", icon: "hospital", descAr: "منظومة طبية شاملة: ملف إلكتروني موحّد، إدارة الأقسام والأسرّة، غرف عمليات، طوارئ، صيدلية داخلية، ومخزون طبي وفق معايير JCI.", descEn: "Comprehensive clinical suite: unified EHR, department & bed management, OR scheduling, emergency, in-house pharmacy and JCI-aligned medical inventory." },
  { id: "clinic-medical-center", code: 2, nameAr: "إدارة العيادات والمراكز الطبية", nameEn: "Clinic & Medical Center", c: "health", icon: "stethoscope", descAr: "مواعيد ذكية بلا تعارض، ملف طبي إلكتروني، وصفات دوائية، فواتير تأمين، واستشارات طب عن بُعد، وتحليلات أداء الأطباء.", descEn: "Conflict-free scheduling, EHR, e-prescriptions, insurance billing, telemedicine consultations and physician performance analytics." },
  { id: "pharmacy-management", code: 3, nameAr: "إدارة الصيدليات", nameEn: "Pharmacy Management", c: "health", icon: "pill-bottle", descAr: "تحكم لحظي بالمخزون، تتبع تواريخ الصلاحية، وصفات إلكترونية، قراءة باركود فائقة السرعة، وتنبيهات ذكية للنواقص.", descEn: "Real-time stock control, expiry tracking, e-prescriptions, high-speed barcode scanning and intelligent low-stock alerts." },
  { id: "diagnostic-imaging-center", code: 4, nameAr: "مركز التشخيص والتصوير الطبي", nameEn: "Diagnostic & Imaging Center", c: "health", icon: "flask-conical", descAr: "مختبرات + أشعة في منظومة واحدة: تسجيل العينات، ربط الأجهزة، صور DICOM، تحقق مزدوج، تقارير معتمدة، وأرشفة سحابية.", descEn: "Unified lab + imaging suite: sample intake, device integration, DICOM imaging, dual validation, accredited reports and cloud archiving." },
  { id: "home-healthcare", code: 5, nameAr: "الرعاية الصحية المنزلية", nameEn: "Home Healthcare", c: "health", icon: "house-plus", descAr: "جدولة الزيارات الميدانية، تتبع فرق التمريض، خرائط الطريق، توثيق رقمي في الموقع، وفوترة آلية.", descEn: "Field visit scheduling, nursing team tracking, route maps, on-site digital documentation and automated billing." },
  { id: "health-insurance", code: 6, nameAr: "التأمين الصحي", nameEn: "Health Insurance", c: "health", icon: "shield-check", descAr: "إدارة الوثائق والمطالبات، شبكات مقدمي الخدمة، الموافقات المسبقة، التسويات الدورية، وتقارير اكتوارية.", descEn: "Policy and claims management, provider networks, pre-authorizations, periodic reconciliations and actuarial analytics." },
  { id: "dental-clinic", code: 7, nameAr: "عيادة الأسنان", nameEn: "Dental Clinic", c: "health", icon: "smile", descAr: "مخطط سني تفاعلي، خطط علاجية متعددة المراحل، تذكير آلي، أقساط مرنة، ومتابعة ما بعد العلاج.", descEn: "Interactive dental charting, multi-phase treatment plans, automated reminders, flexible installments and post-op follow-up." },
  { id: "physiotherapy-rehab", code: 8, nameAr: "العلاج الطبيعي والتأهيل", nameEn: "Physiotherapy & Rehab", c: "health", icon: "footprints", descAr: "برامج تأهيلية مخصصة، تتبع تقدم المريض بالقياسات، مكتبة تمارين مرئية، وجدولة جلسات متكررة.", descEn: "Tailored rehab programs, measurable progress tracking, visual exercise library and recurring session scheduling." },
  { id: "veterinary-clinic", code: 9, nameAr: "العيادات البيطرية", nameEn: "Veterinary Clinic", c: "health", icon: "paw-print", descAr: "ملفات الحيوانات، سجل التحصينات، جدولة العمليات، تذكيرات دورية، وإدارة المخزون البيطري.", descEn: "Pet records, vaccination history, surgery scheduling, periodic reminders and veterinary medical inventory." },
  { id: "surgery-aesthetic-center", code: 10, nameAr: "مركز الجراحة والتجميل", nameEn: "Surgery & Aesthetic Center", c: "health", icon: "syringe", descAr: "جدولة العمليات، ملفات ما قبل الجراحة، غرف التعافي، متابعة ما بعد العملية، وإدارة المواد.", descEn: "Surgery scheduling, pre-op files, recovery rooms, post-op follow-up and materials management." },
  { id: "chronic-care-center", code: 11, nameAr: "مركز إدارة الأمراض المزمنة", nameEn: "Chronic Care Center", c: "health", icon: "heart-pulse", descAr: "متابعة دورية للمرضى المزمنين، خطط علاجية طويلة الأجل، تذكيرات بالأدوية، وتقارير تقدم.", descEn: "Periodic chronic patient follow-up, long-term treatment plans, medication reminders and progress reports." },

  /* ============ EDUCATION (8) ============ */
  { id: "school-management", code: 12, nameAr: "إدارة المدارس", nameEn: "School Management", c: "education", icon: "school", descAr: "منظومة تعليمية متكاملة: التسجيل، الشعب، الدرجات، الجداول الذكية، حضور تلقائي، رسوم دراسية، وتقارير أولياء الأمور.", descEn: "Full academic suite: enrollment, classes, grades, smart timetables, automated attendance, tuition and parent reports." },
  { id: "kindergarten", code: 13, nameAr: "رياض الأطفال", nameEn: "Kindergarten", c: "education", icon: "shapes", descAr: "تسجيل الأطفال، حضور بالباركود، أنشطة يومية مصوّرة، تغذية، تقارير تطور، وتواصل لحظي مع الأهل.", descEn: "Child enrollment, barcode attendance, visual daily activities, nutrition, development reports and real-time parent communication." },
  /* ROUND 149 — university-management carries an EXPLICIT `mods` override so the الکليات (colleges) module leads the module list (the system description promises «إدارة الكليات والأقسام» — the catalog now delivers that flagship module first). Other education systems keep inheriting the category-level `mods` set. */
  { id: "university-management", code: 14, nameAr: "إدارة الجامعات", nameEn: "University Management", c: "education", icon: "landmark", descAr: "إدارة الكليات والأقسام، تسجيل المقررات، الساعات المعتمدة، جداول الأساتذة، الرسوم، وشؤون التخرج.", descEn: "Faculty and department management, course registration, credit hours, professor schedules, tuition and graduation affairs.", mods: ["colleges", "students", "teachers", "courses", "grades", "attendance", "fees", "exams", "timetable", "parents", "transport", "library", "cafeteria", "staff", "reports", "elearning", "certificates"] },
  { id: "institute-training-center", code: 15, nameAr: "المعاهد ومراكز التدريب", nameEn: "Institute & Training Center", c: "education", icon: "presentation", descAr: "دورات احترافية، مدربون معتمدون، قاعات ذكية، شهادات موثّقة، اختبارات تقييمية، وتقارير أداء.", descEn: "Professional courses, certified trainers, smart classrooms, verifiable certificates, assessments and trainee analytics." },
  { id: "e-learning-lms", code: 16, nameAr: "التعليم الإلكتروني LMS", nameEn: "E-Learning LMS", c: "education", icon: "laptop", descAr: "مقررات رقمية تفاعلية، بث مباشر، اختبارات ذكية بتصحيح فوري، تتبع تقدم الطلاب، وشهادات رقمية.", descEn: "Interactive digital courses, live streaming, auto-graded quizzes, progress tracking and verifiable digital certificates." },
  { id: "library-management", code: 17, nameAr: "إدارة المكتبات", nameEn: "Library Management", c: "education", icon: "book-marked", descAr: "فهرسة إلكترونية متقدمة، إعارة وإرجاع بالباركود، غرامات تلقائية، بحث ذكي، وتقارير استخدام.", descEn: "Advanced e-cataloging, barcode lending & returns, automated fines, smart search and usage analytics." },
  { id: "student-transport", code: 18, nameAr: "النقل المدرسي", nameEn: "Student Transport", c: "education", icon: "bus", descAr: "تتبع حافلات مباشر GPS، مسارات محسّنة، تسجيل صعود ونزول الطلاب، إشعارات لأولياء الأمور، وتقارير سلامة.", descEn: "Live GPS bus tracking, optimized routes, student boarding check-in/out, parent notifications and safety reports." },
  { id: "exam-certification", code: 19, nameAr: "مركز الامتحانات والشهادات", nameEn: "Exam & Certification", c: "education", icon: "file-pen", descAr: "جدولة امتحانات، توزيع قاعات ذكي، مراقبة إلكترونية، تصحيح آلي ويدوي، وإصدار شهادات بالتحقق الرقمي.", descEn: "Exam scheduling, smart hall allocation, e-proctoring, auto & manual grading, and digitally verifiable certification." },
  /* round 29 — new system (code 50 freed by the printing merge) */
  { id: "driving-school", code: 50, nameAr: "مدرسة تعليم القيادة", nameEn: "Driving School", c: "education", icon: "car", descAr: "طلاب ومدرّبون، مركبات مدرّسة بصيانة وتتبع، حجز دروس عملية ونظرية، اختبارات وشهادات، باقات ساعات، وتقارير نجاح.", descEn: "Students and instructors, training vehicles with maintenance and tracking, practical and theory lesson booking, tests and certificates, hour packages, and success-rate reports.", mods: ["students", "teachers", "vehicles", "lessons", "exams", "certificates", "attendance", "subscriptions", "invoices", "payments", "reports"] },

  /* ============ RETAIL (14) ============ */
  { id: "supermarket-grocery", code: 20, nameAr: "السوبر ماركت والبقالة", nameEn: "Supermarket & Grocery", c: "retail", icon: "shopping-cart", descAr: "نقاط بيع فائقة السرعة، باركود متعدد، عروض ذكية، إدارة موردين، جرد لحظي، وتقارير ربحية لكل فرع.", descEn: "Ultra-fast POS, multi-barcode, smart promotions, supplier management, real-time stocktake and per-branch profitability." },
  { id: "clothing-fashion", code: 21, nameAr: "الملابس والأزياء", nameEn: "Clothing & Fashion", c: "retail", icon: "shirt", descAr: "مقاسات وألوان وباركود موحّد، إدارة فروع متعددة، برامج ولاء، عروض موسمية، وتحليلات اتجاهات.", descEn: "Unified size/color barcode, multi-branch management, loyalty programs, seasonal offers and trend analytics." },
  { id: "jewelry-gold", code: 22, nameAr: "المجوهرات والذهب", nameEn: "Jewelry & Gold", c: "retail", icon: "gem", descAr: "تتبع الأوزان والعيارات بدقة، جرد عالي الدقة، تسعير لحظي بأسعار الذهب، فواتير قانونية، وشهادات أصالة.", descEn: "Precise weight & karat tracking, high-accuracy stocktake, live gold-price pricing, legal invoices and authenticity certificates." },
  { id: "gifts-flowers", code: 23, nameAr: "الهدايا والزهور", nameEn: "Gifts & Flowers", c: "retail", icon: "gift", descAr: "باقات وتغليف مخصص، عروض مناسبات، طلبات بالجملة، جدولة توصيل، وتتبع لحظي للتوفر.", descEn: "Custom bouquets & wrapping, occasion offers, bulk orders, delivery scheduling and real-time availability tracking." },
  { id: "perfumes-cosmetics", code: 24, nameAr: "العطور ومستحضرات التجميل", nameEn: "Perfumes & Cosmetics", c: "retail", icon: "spray-can", descAr: "تركيزات وأحجام وعينات، تتبع صلاحية دقيق، برامج علامات تجارية، توصيات ذكية، وإدارة ولاء.", descEn: "Concentrations, sizes & samples, precise expiry tracking, brand programs, smart recommendations and loyalty." },
  { id: "optics-watches", code: 25, nameAr: "النظارات والساعات", nameEn: "Optics & Watches", c: "retail", icon: "glasses", descAr: "وصفات طبية رقمية، قياسات دقيقة، ضمان وصيانة، تذكير دوري بالفحص، وتحليلات عملاء.", descEn: "Digital prescriptions, precise measurements, warranty & service, periodic exam reminders and customer analytics." },
  { id: "bakery-pastry", code: 26, nameAr: "المخبوزات والحلويات", nameEn: "Bakery & Pastry", c: "retail", icon: "croissant", descAr: "خطة إنتاج يومية، وصفات وتكاليف دقيقة، إدارة الطلبات المسبقة، بيع مباشر، وتحليلات الهدر.", descEn: "Daily production plan, precise recipes & costs, pre-orders, direct selling and waste analytics." },
  { id: "phones-electronics", code: 27, nameAr: "الهواتف والإلكترونيات", nameEn: "Phones & Electronics", c: "retail", icon: "smartphone", descAr: "تتبع IMEI، ضمان إلكتروني، صيانة مرتبطة بالفاتورة، بيع بالتقسيط، وإدارة موردين متعددين.", descEn: "IMEI tracking, e-warranty, invoice-linked service, installment sales and multi-supplier management." },
  { id: "furniture-decor", code: 28, nameAr: "الأثاث والديكور", nameEn: "Furniture & Decor", c: "retail", icon: "sofa", descAr: "صالة عرض رقمية، طلبات مخصصة، جدولة توصيل وتركيب، ضمان طويل الأجل، وتحليلات مبيعات.", descEn: "Digital showroom, custom orders, delivery & assembly scheduling, extended warranty and sales analytics." },
  { id: "building-materials", code: 29, nameAr: "مواد البناء", nameEn: "Building Materials", c: "retail", icon: "brick-wall", descAr: "أصناف ثقيلة بأسعار متدرجة، عروض كميات، توصيل للموقع، حساب تكاليف مشاريع، وفواتير ضريبية.", descEn: "Heavy items with tiered pricing, volume quotes, on-site delivery, project cost tracking and tax invoices." },
  { id: "toy-store", code: 30, nameAr: "متجر الألعاب", nameEn: "Toy Store", c: "retail", icon: "gamepad-2", descAr: "تصنيف حسب الفئة العمرية، عروض موسمية ذكية، حزم هدايا، إدارة مخزون موسمي، وتحليلات ذوق.", descEn: "Age-group categories, smart seasonal offers, gift bundles, seasonal stock planning and preference analytics." },
  { id: "pet-store-supplies", code: 31, nameAr: "متجر الحيوانات الأليفة", nameEn: "Pet Store & Supplies", c: "retail", icon: "dog", descAr: "إدارة الحيوانات والمستلزمات، تتبع التحصينات، خدمات العناية، تذكيرات دورية، وبرامج ولاء.", descEn: "Pet & supply management, vaccination tracking, grooming services, periodic reminders and loyalty programs." },
  { id: "commercial-bookstore", code: 32, nameAr: "المكتبة التجارية", nameEn: "Commercial Bookstore", c: "retail", icon: "book", descAr: "عناوين وناشرون وتصنيفات، عروض فروع، اشتراكات قراءة، طلبات خاصة، وتحليلات الأكثر مبيعاً.", descEn: "Titles, publishers & categories, branch offers, reading subscriptions, special orders and best-seller analytics." },
  { id: "office-furniture-store", code: 33, nameAr: "متجر الأثاث المكتبي", nameEn: "Office Furniture Store", c: "retail", icon: "armchair", descAr: "أثاث مكتبي للشركات، عروض B2B، طلبات بالجملة، عقد صيانة، وتحليلات مؤسسية.", descEn: "Corporate office furniture, B2B offers, bulk orders, maintenance contracts and enterprise analytics." },

  /* ============ HOSPITALITY (5) ============ */
  { id: "restaurant-management", code: 34, nameAr: "إدارة المطاعم", nameEn: "Restaurant Management", c: "hospitality", icon: "utensils", descAr: "قائمة رقمية، إدارة طاولات، شاشة مطبخ KDS، طلبات صالة وتوصيل، وتقارير أداء يومية.", descEn: "Digital menu, table management, KDS kitchen display, dine-in & delivery orders and daily performance reports." },
  { id: "cafe-coffee-shop", code: 35, nameAr: "الكافيهات", nameEn: "Cafe & Coffee Shop", c: "hospitality", icon: "coffee", descAr: "قائمة مشروبات ذكية، واجهة باريستا محترفة، اشتراكات قهوة، طلبات سريعة، وبرامج ولاء مميزة.", descEn: "Smart beverage menu, professional barista workflow, coffee subscriptions, quick orders and premium loyalty programs." },
  { id: "catering-services", code: 36, nameAr: "خدمات التموين", nameEn: "Catering Services", c: "hospitality", icon: "utensils-crossed", descAr: "إدارة المناسبات الكبرى، قوائم مخصصة، فرق ميدانية، جدولة توصيل، وفوترة مشاريع.", descEn: "Large event management, custom menus, field teams, delivery scheduling and project-based billing." },
  { id: "hotel-management", code: 37, nameAr: "إدارة الفنادق", nameEn: "Hotel Management", c: "hospitality", icon: "hotel", descAr: "حجز غرف ذكي، تسجيل وصول ومغادرة سريع، تدبير منزلي، خدمات الغرف، وتحليلات إشغال لحظية.", descEn: "Smart room booking, express check-in/out, housekeeping, room service and live occupancy analytics." },
  { id: "resorts-vacation", code: 38, nameAr: "المنتجعات", nameEn: "Resorts & Vacation", c: "hospitality", icon: "umbrella", descAr: "وحدات وباقات، أنشطة ترفيهية، حجوزات موسمية، إدارة مطاعم ومسابح، وتحليلات الإيرادات.", descEn: "Units & packages, recreational activities, seasonal bookings, restaurant & pool management and revenue analytics." },

  /* ============ SERVICES (15) ============ */
  { id: "beauty-wellness-center", code: 39, nameAr: "مركز التجميل والعناية", nameEn: "Beauty & Wellness Center", c: "services", icon: "flower-2", descAr: "حجز مواعيد، خدمات متعددة، فريق محترف، عمولات دقيقة، جلسات سبا، باقات عناية، وبرامج ولاء.", descEn: "Smart bookings, multi-service menu, professional team, precise commissions, spa sessions, wellness packages and loyalty." },
  { id: "real-estate", code: 40, nameAr: "إدارة العقارات", nameEn: "Real Estate", c: "services", icon: "building", descAr: "وحدات وعقود، تحصيل إيجارات، صيانة، تسويق عقاري، وتقارير محفظة دقيقة.", descEn: "Units & contracts, rent collection, maintenance, property marketing and precise portfolio analytics." },
  { id: "events-weddings", code: 41, nameAr: "تنظيم الفعاليات والأعراس", nameEn: "Events & Weddings", c: "services", icon: "wine", descAr: "حجز قاعات، باقات مناسبات وأعراس، تنسيق موردين، ميزانيات، مهام فريق، وفوترة مشاريع.", descEn: "Venue booking, event & wedding packages, vendor coordination, budgets, team tasks and project billing." },
  { id: "cleaning-services", code: 42, nameAr: "شركات التنظيف", nameEn: "Cleaning Services", c: "services", icon: "spray-can", descAr: "عقود دورية، فرق ميدانية، جداول زمنية، تتبع المواد، وتقارير تشغيلية شاملة.", descEn: "Recurring contracts, field teams, time schedules, material tracking and comprehensive operational reports." },
  { id: "laundry-services", code: 43, nameAr: "المغاسل", nameEn: "Laundry Services", c: "services", icon: "droplets", descAr: "طلبات بالباركود، تتبع حالة الجاهزية، اشتراكات شهرية، توصيل واستلام، وتقارير أداء.", descEn: "Barcode orders, readiness tracking, monthly subscriptions, pickup & delivery and performance reports." },
  { id: "car-wash", code: 44, nameAr: "غسيل السيارات", nameEn: "Car Wash", c: "services", icon: "car", descAr: "طلبات سريعة، باقات متنوعة، فريق ميداني، اشتراكات دورية، وتحليلات الإيرادات.", descEn: "Quick orders, varied packages, field team, recurring subscriptions and revenue analytics." },
  { id: "subscription-management", code: 45, nameAr: "إدارة الاشتراكات", nameEn: "Subscription Management", c: "services", icon: "repeat", descAr: "باقات مرنة، تجديد تلقائي، تنبيهات ذكية، فواتير دورية، وتحليلات الاحتفاظ بالعملاء.", descEn: "Flexible plans, auto-renewal, smart alerts, recurring invoices and customer retention analytics." },
  { id: "travel-tourism", code: 46, nameAr: "وكالة السفر والسياحة", nameEn: "Travel & Tourism", c: "services", icon: "plane", descAr: "باقات سياحية، حجوزات طيران وفنادق، تأشيرات، ملفات عملاء، وتحليلات أداء المبيعات.", descEn: "Tour packages, flight & hotel bookings, visas, client files and sales performance analytics." },
  { id: "gym-fitness", code: 47, nameAr: "الصالات الرياضية", nameEn: "Gym & Fitness", c: "services", icon: "dumbbell", descAr: "إدارة متكاملة لصالة رفع الأثقال واللياقة: أعضاء واشتراكات، مدربون محترفون، جدول حصص، برامج تمرين فردية، أجهزة وصيانة، قياسات جسدية وخطط غذائية، خزائن، وتحليلات تجديد دقيقة.", descEn: "Complete management for weight-training and fitness gyms: members and subscriptions, professional coaches, class schedules, individual workout programs, equipment and maintenance, body measurements and nutrition plans, lockers, and precise renewal analytics.", mods: ["members", "subscriptions", "coaches", "classes", "workouts", "equipment", "measurements", "nutrition", "lockers", "attendance", "invoices", "payments", "reports"] },
  /* round 29 — the duplicate home-services entry was merged into
     general-home-services; the freed code 48 now carries the barbershop. */
  { id: "barbershop-management", code: 48, nameAr: "صالون الحلاقة الرجالي", nameEn: "Barbershop & Grooming", c: "services", icon: "scissors", descAr: "كراسي وحجز مواعيد، قائمة انتظار فورية للزوار، حلاقون بتصنيفات وتقييمات، عضويات وباقات، منتجات عناية، وفوترة سريعة.", descEn: "Chairs and appointment booking, a live walk-in waiting queue, barbers with specialties and ratings, memberships and packages, care products, and fast billing.", mods: ["services", "bookings", "queue", "customers", "staff", "memberships", "products", "loyalty", "invoices", "payments", "reports"] },
  { id: "photography-studio", code: 49, nameAr: "استوديو التصوير", nameEn: "Photography Studio", c: "services", icon: "camera", descAr: "حجز جلسات، إدارة معدات، معاينة وتعديل، تسليم رقمي، وفوترة إبداعية.", descEn: "Session booking, equipment management, preview & editing, digital delivery and creative billing." },
  /* round 29 — the duplicate shop-level printing entry was merged into
     printing-press; its freed code 50 was reused by the driving school. */
  { id: "general-home-services", code: 51, nameAr: "الخدمات المنزلية المتنوعة", nameEn: "General Home Services", c: "services", icon: "house", descAr: "منصة واحدة لكل الخدمات المنزلية: عقود صيانة وطلبات فورية، فنيون معتمدون بتصنيفات متعددة، جدولة ذكية بموقع العميل، ضمان على الأعمال، وفوترة إلكترونية شفافة.", descEn: "One platform for every home service: contract maintenance and on-demand requests, certified multi-trade technicians, smart scheduling by customer location, workmanship warranty, and transparent e-billing." },
  { id: "elderly-care", code: 52, nameAr: "رعاية المسنين", nameEn: "Elderly Care", c: "services", icon: "person-standing", descAr: "رعاية منزلية ومركزية، خطط رعاية فردية، مراقبة صحية، تواصل مع الأهل، وتقارير دورية.", descEn: "Home & residential care, individual care plans, health monitoring, family communication and periodic reports." },
  { id: "auto-detailing-center", code: 53, nameAr: "مركز العناية بالسيارات", nameEn: "Auto Detailing Center", c: "services", icon: "car-front", descAr: "باقات عناية شاملة، تلميع وحماية، جدولة مواعيد، فريق محترف، وتقارير أداء.", descEn: "Comprehensive care packages, polish & protection, appointment scheduling, expert team and performance analytics." },

  /* ============ FINANCE (5) ============ */
  { id: "financial-services-exchange", code: 54, nameAr: "الخدمات المالية والصرافة", nameEn: "Financial Services & Exchange", c: "finance", icon: "banknote-arrow-up", descAr: "حوالات فورية، عملات متعددة، أسعار صرف لحظية، عمولات دقيقة، وتقارير الأرصدة والحدود.", descEn: "Instant transfers, multi-currency, live exchange rates, precise commissions and balance & limit analytics." },
  { id: "pos-system", code: 55, nameAr: "نظام نقاط البيع POS", nameEn: "POS System", c: "finance", icon: "calculator", descAr: "بيع فائق السرعة، باركود، طرق دفع متعددة، ورديات، وتحليلات فورية للكاشير.", descEn: "Ultra-fast selling, barcode, multiple payment methods, shifts and instant cashier analytics." },
  { id: "invoicing-tax", code: 56, nameAr: "نظام الفواتير والضرائب", nameEn: "Invoicing & Tax", c: "finance", icon: "receipt", descAr: "فواتير ضريبية متوافقة، عروض أسعار، مرتجعات، تقارير ضريبية، وتكامل مع المنصات الحكومية.", descEn: "Compliant tax invoices, quotations, returns, tax reports and government platform integration." },
  { id: "general-accounting", code: 57, nameAr: "المحاسبة العامة", nameEn: "General Accounting", c: "finance", icon: "calculator", descAr: "دليل حسابات مرن، قيود مزدوجة، ميزانيات، تحليل مالي، وتقارير الأرباح والخسائر.", descEn: "Flexible chart of accounts, double-entry, balance sheets, financial analysis and P&L reports." },
  { id: "financial-audit", code: 58, nameAr: "التدقيق المالي", nameEn: "Financial Audit", c: "finance", icon: "search-check", descAr: "تدقيق داخلي، نقاط رقابية، تقارير امتثال، وتتبع الملاحظات.", descEn: "Internal audit, control points, compliance reports and finding tracking." },

  /* ============ LOGISTICS (7) ============ */
  { id: "warehouse-management", code: 59, nameAr: "إدارة المخازن", nameEn: "Warehouse Management", c: "logistics", icon: "warehouse", descAr: "مواقع تخزين، دفعات وتواريخ، جرد ذكي، تحويلات بينية، وتحليلات حركة المخزون.", descEn: "Storage locations, batches & dates, smart stocktake, transfers and inventory movement analytics." },
  { id: "import-export", code: 60, nameAr: "الاستيراد والتصدير", nameEn: "Import & Export", c: "logistics", icon: "ship", descAr: "شحنات دولية، شهادات جمركية، مستندات، تتبع حاويات، وتحليلات تكاليف الاستيراد.", descEn: "International shipments, customs certificates, documents, container tracking and import cost analytics." },
  { id: "logistics-company", code: 61, nameAr: "الشركة اللوجستية", nameEn: "Logistics Company", c: "logistics", icon: "truck", descAr: "إدارة طلبات الشحن، تتبع مباشر، مناديب، تسليم موقّع، وتحليلات أداء الأسطول.", descEn: "Shipment order management, live tracking, couriers, signed delivery and fleet performance analytics." },
  { id: "car-showroom", code: 62, nameAr: "معارض السيارات", nameEn: "Car Showroom", c: "logistics", icon: "car", descAr: "مخزون موديلات، فحص فني، عقود بيع، أقساط مرنة، وتحليلات دوران المخزون.", descEn: "Model inventory, technical inspection, sales contracts, flexible installments and stock turnover analytics." },
  { id: "car-rental", code: 63, nameAr: "تأجير السيارات", nameEn: "Car Rental", c: "logistics", icon: "key", descAr: "أسطول متكامل، عقود إيجار، تسليم واستلام رقمي، تأمين، وتحليلات الإشغال.", descEn: "Complete fleet, rental contracts, digital handover, insurance and utilization analytics." },
  { id: "fleet-management", code: 64, nameAr: "إدارة الأسطول", nameEn: "Fleet Management", c: "logistics", icon: "truck", descAr: "مركبات وسائقون، استهلاك وقود، صيانة وقائية، مسارات محسّنة، وتحليلات التكلفة.", descEn: "Vehicles & drivers, fuel consumption, preventive maintenance, optimized routes and cost analytics." },
  { id: "courier-service", code: 65, nameAr: "خدمات التوصيل السريع", nameEn: "Courier Service", c: "logistics", icon: "bike", descAr: "طلبات فورية، تتبع لحظي، مناديب، تسليم بالباركود، وتحليلات زمن التسليم.", descEn: "Instant orders, live tracking, couriers, barcode-verified delivery and delivery-time analytics." },

  /* ============ AGRICULTURE (5) ============ */
  { id: "farm-management", code: 66, nameAr: "إدارة المزارع", nameEn: "Farm Management", c: "agriculture", icon: "sprout", descAr: "محاصيل ودورات زراعية، إنتاج، تغذية، عمال ميدانيون، وتكاليف دقيقة.", descEn: "Crops & cycles, production, feeding, field workers and precise cost analytics." },
  { id: "poultry-farm", code: 67, nameAr: "مزارع الدواجن", nameEn: "Poultry Farm", c: "agriculture", icon: "drumstick", descAr: "إدارة الأفواج، تغذية آلية، صحة الطيور، إنتاج البيض، وتحليلات الأمراض.", descEn: "Flock management, automated feeding, bird health, egg production and disease analytics." },
  { id: "dairy-farm", code: 68, nameAr: "مزارع الألبان", nameEn: "Dairy Farm", c: "agriculture", icon: "beef", descAr: "إدارة القطعان، حلب آلي، إنتاج الحليب، صحة الحيوان، وتحليلات الجودة.", descEn: "Herd management, automated milking, milk production, animal health and quality analytics." },
  { id: "fish-farm", code: 69, nameAr: "المزارع السمكية", nameEn: "Fish Farm", c: "agriculture", icon: "fish", descAr: "أحواض، تغذية، نمو، حصاد، جودة المياه، وتحليلات الإنتاج.", descEn: "Ponds, feeding, growth, harvest, water quality and production analytics." },
  { id: "greenhouse", code: 70, nameAr: "البيوت المحمية", nameEn: "Greenhouse", c: "agriculture", icon: "leaf", descAr: "بيوت ذكية، تحكم مناخي، ري آلي، محاصيل، وتحليلات الإنتاج.", descEn: "Smart houses, climate control, automated irrigation, crops and production analytics." },

  /* ============ INDUSTRY (5) ============ */
  { id: "engineering-company", code: 71, nameAr: "الشركات الهندسية", nameEn: "Engineering Company", c: "industry", icon: "drafting-compass", descAr: "مشاريع هندسية، مخططات، أوامر عمل، مستخلصات، وتقارير الإنجاز.", descEn: "Engineering projects, drawings, work orders, progress certificates and completion analytics." },
  { id: "handicrafts", code: 72, nameAr: "الصناعات اليدوية", nameEn: "Handicrafts", c: "industry", icon: "hand-heart", descAr: "منتجات حرفية، مواد خام، ورش، تكاليف، وطلبات مخصصة.", descEn: "Artisan products, raw materials, workshops, costs and custom orders." },
  { id: "construction", code: 73, nameAr: "المقاولات والبناء", nameEn: "Construction", c: "industry", icon: "hard-hat", descAr: "مشاريع إنشائية، مراحل، مقاولون، مواد، سلامة، وتحليلات الإنجاز.", descEn: "Construction projects, phases, subcontractors, materials, safety and progress analytics." },
  { id: "factory-manufacturing", code: 74, nameAr: "المصانع والإنتاج", nameEn: "Factory & Manufacturing", c: "industry", icon: "factory", descAr: "خطوط إنتاج، مواد خام، جودة، صيانة، وتحليلات الكفاءة.", descEn: "Production lines, raw materials, quality, maintenance and efficiency analytics." },
  { id: "printing-press", code: 75, nameAr: "إدارة المطابع", nameEn: "Printing Press", c: "industry", icon: "printer", descAr: "إدارة متكاملة لدور الطباعة والمطابع: طلبات متنوعة من التصميم للتسليم، أنواع الورق والأحبار، أسعار آلية، جدولة ماكينات وورديات، تسليم ومتابعة، وفوترة وتحليلات أداء مفصلة.", descEn: "Complete management for print shops and presses: end-to-end orders from design to delivery, paper & ink types, automatic pricing, machine & shift scheduling, delivery tracking, and detailed billing and performance analytics." },

  /* ============ MEDIA (4) ============ */
  { id: "marketing-advertising-agency", code: 76, nameAr: "وكالة التسويق والإعلان", nameEn: "Marketing & Advertising Agency", c: "media", icon: "megaphone", descAr: "حملات إعلانية، تسويق رقمي، عملاء، ميزانيات، فريق إبداعي، وقياس ROI.", descEn: "Ad campaigns, digital marketing, clients, budgets, creative team and ROI measurement." },
  { id: "live-streaming", code: 77, nameAr: "البث المباشر", nameEn: "Live Streaming", c: "media", icon: "radio-tower", descAr: "بثوث مباشرة، مشاهدون، اشتراكات، تفاعل، وتحليلات المشاهدات.", descEn: "Live streams, viewers, subscriptions, engagement and view analytics." },
  { id: "media-production-studio", code: 78, nameAr: "استوديو الإنتاج الإعلامي", nameEn: "Media Production Studio", c: "media", icon: "film", descAr: "تسجيل صوتي وفيديو، جلسات، معدات، مونتاج، ميزانيات إنتاج، وتوزيع.", descEn: "Audio & video recording, sessions, equipment, editing, production budgets and distribution." },
  { id: "social-media-management", code: 79, nameAr: "إدارة السوشيال ميديا", nameEn: "Social Media Management", c: "media", icon: "hash", descAr: "جدولة منشورات، إدارة منصات، محتوى إبداعي، تفاعل، وتحليلات أداء.", descEn: "Post scheduling, platform management, creative content, engagement and performance analytics." },

  /* ============ HR (4) ============ */
  { id: "hr-management", code: 80, nameAr: "إدارة الموارد البشرية", nameEn: "HR Management", c: "hr", icon: "user-cog", descAr: "موظفون، حضور، توظيف، رواتب، إجازات، تقييم أداء، وتقارير شاملة.", descEn: "Employees, attendance, recruitment, payroll, leaves, performance reviews and comprehensive analytics." },
  { id: "performance-management", code: 81, nameAr: "إدارة الأداء والتقييم", nameEn: "Performance Management", c: "hr", icon: "gauge", descAr: "أهداف KPIs، تقييمات دورية، تغذية راجعة 360°، وتقارير تطوير.", descEn: "KPI goals, periodic reviews, 360° feedback and development reports." },
  { id: "corporate-training", code: 82, nameAr: "التدريب المؤسسي", nameEn: "Corporate Training", c: "hr", icon: "graduation-cap", descAr: "برامج تدريبية، مسارات تعلم، شهادات داخلية، وتقارير مشاركة.", descEn: "Training programs, learning paths, internal certificates and participation analytics." },
  { id: "payroll-compensation", code: 83, nameAr: "الرواتب والأجور", nameEn: "Payroll & Compensation", c: "hr", icon: "wallet", descAr: "حساب رواتب دقيق، خصومات ومكافآت، ضرائب، تحويلات بنكية، وتقارير.", descEn: "Accurate payroll, deductions & bonuses, taxes, bank transfers and reports." },

  /* ============ FUN (5) ============ */
  { id: "gaming-center", code: 84, nameAr: "مركز الألعاب الإلكترونية", nameEn: "Gaming Center", c: "fun", icon: "monitor", descAr: "أجهزة، جلسات، اشتراكات، بوفيه، ومسابقات.", descEn: "Devices, sessions, subscriptions, buffet and tournaments." },
  { id: "bowling-alley", code: 85, nameAr: "صالة البولينغ", nameEn: "Bowling Alley", c: "fun", icon: "circle-dot", descAr: "مسارات، حجوزات، اشتراكات، بطولات، وتقارير.", descEn: "Lanes, bookings, subscriptions, tournaments and analytics." },
  { id: "kids-play-area", code: 86, nameAr: "مناطق ألعاب الأطفال", nameEn: "Kids Play Area", c: "fun", icon: "baby", descAr: "حجوزات، أعضاء، باقات، سلامة، وتقارير.", descEn: "Bookings, members, packages, safety and analytics." },
  { id: "cinema", code: 87, nameAr: "السينما", nameEn: "Cinema", c: "fun", icon: "film", descAr: "أفلام، قاعات، تذاكر، بوفيه، وتحليلات الحضور.", descEn: "Movies, halls, tickets, buffet and attendance analytics." },
  { id: "escape-rooms", code: 88, nameAr: "غرف الهروب", nameEn: "Escape Rooms", c: "fun", icon: "door-closed", descAr: "غرف، سيناريوهات، حجوزات، فرق، وتقارير.", descEn: "Rooms, scenarios, bookings, teams and analytics." },

  /* ============ LEGAL (4) ============ */
  { id: "law-firm", code: 89, nameAr: "المكاتب القانونية", nameEn: "Law Firm", c: "legal", icon: "scale", descAr: "قضايا، موكلون، جلسات، مستندات، وفوترة قانونية.", descEn: "Cases, clients, hearings, documents and legal billing." },
  { id: "professional-consulting", code: 90, nameAr: "الاستشارات المهنية", nameEn: "Professional Consulting", c: "legal", icon: "message-circle", descAr: "عملاء، استشارات، ساعات، عقود، وفوترة.", descEn: "Clients, consultations, hours, contracts and billing." },
  { id: "translation-services", code: 91, nameAr: "الترجمة المعتمدة", nameEn: "Translation Services", c: "legal", icon: "languages", descAr: "طلبات، لغات، مترجمون، تسليم، وفوترة.", descEn: "Orders, languages, translators, delivery and billing." },
  { id: "notary-services", code: 92, nameAr: "التوثيق والكاتب العدل", nameEn: "Notary Services", c: "legal", icon: "stamp", descAr: "معاملات، وثائق، أرشفة، وتحليلات.", descEn: "Transactions, documents, archiving and analytics." },

  /* ============ NONPROFIT (3) ============ */
  { id: "charity-management", code: 93, nameAr: "الجمعيات الخيرية", nameEn: "Charity Management", c: "nonprofit", icon: "heart-handshake", descAr: "متبرعون، تبرعات، مشاريع، مستفيدون، وتحليلات الأثر.", descEn: "Donors, donations, projects, beneficiaries and impact analytics." },
  { id: "mosque-management", code: 94, nameAr: "إدارة المساجد", nameEn: "Mosque Management", c: "nonprofit", icon: "moon-star", descAr: "مواعيد، دروس، تبرعات، صيانة، ومناسبات.", descEn: "Schedules, lessons, donations, maintenance and events." },
  { id: "sports-club", code: 95, nameAr: "الأندية الرياضية", nameEn: "Sports Club", c: "nonprofit", icon: "volleyball", descAr: "فرق ومباريات، منشآت وملاعب، اشتراكات أعضاء، حجوزات مرافق، بطولات دورية، وتقارير أداء.", descEn: "Teams and matches, facilities and fields, member subscriptions, facility bookings, seasonal tournaments, and performance reports." },

  /* ============ GENERAL (5) ============ */
  { id: "car-repair-workshop", code: 96, nameAr: "ورش إصلاح السيارات", nameEn: "Car Repair Workshop", c: "general", icon: "wrench", descAr: "طلبات، فحص، قطع، فنيون، وفوترة.", descEn: "Orders, inspection, parts, technicians and billing." },
  { id: "tailoring-fashion", code: 97, nameAr: "الخياطة والأزياء", nameEn: "Tailoring & Fashion", c: "general", icon: "scissors", descAr: "طلبات، قياسات، تسليم، عملاء، وفوترة.", descEn: "Orders, measurements, delivery, clients and billing." },
  { id: "mobile-repair", code: 98, nameAr: "إصلاح الجوالات", nameEn: "Mobile Repair", c: "general", icon: "smartphone", descAr: "طلبات، أجهزة، قطع، فنيون، وضمان.", descEn: "Orders, devices, parts, technicians and warranty." },
  { id: "computer-repair", code: 99, nameAr: "إصلاح الحاسبات", nameEn: "Computer Repair", c: "general", icon: "laptop", descAr: "طلبات، أجهزة، صيانة، ضمان، وفوترة.", descEn: "Orders, devices, maintenance, warranty and billing." },
  { id: "home-appliances-repair", code: 100, nameAr: "إصلاح الأجهزة المنزلية", nameEn: "Home Appliances Repair", c: "general", icon: "plug", descAr: "طلبات، أجهزة، قطع، فنيون، وضمان.", descEn: "Orders, appliances, parts, technicians and warranty." },

  /* ============================================================
     ROUND 144 — نظام رقم 101: إدارة شركات الأمن والحراسة SGCMS
     (Security & Guard Company Management System) — فئة الأمن
     والحراسة المستقلة: حراس، دوريات، بيانات وحالات، تراخيص، تدريب،
     عتاد، حضور ورواتب، عقود عملاء، فروع/مواقع، أصول، وفوترة.
  ============================================================ */
  {
    id: "security-guard-company",
    code: 101,
    nameAr: "إدارة شركات الأمن والحراسة",
    nameEn: "Security & Guard Company Management",
    c: "security",
    icon: "shield",
    descAr: "إدارة شاملة لشركات الأمن والحراسة: قاعدة حراس كاملة بتراخيص سلاح وتصاريح العمل، جدولة دوريات ومواقع متقدمة، بيانات وحالات لحظية مع أولويات ومتابعة، تدريب وشهادات، عتاد وأسلحة ومركبات، حضور وورديات ورواتب، عقود عملاء وفروع، وفوترة دقيقة.",
    descEn: "Complete management for security & guard companies: full guard roster with firearm licenses and work permits, advanced patrol and site scheduling, real-time incidents with priorities and follow-up, training and certifications, equipment and vehicles, attendance, shifts and payroll, client contracts and branches, and precise billing.",
    mods: ["guards", "patrols", "incidents", "branches", "training", "licenses", "equipment", "attendance", "payroll", "staff", "contracts", "customers", "invoices", "reports", "assets"],
  },

  /* ============================================================
     ROUND 153 — نظام رقم 102: إدارة السكن الطلابي SAMS
     (Student Accommodation Management System) — فئة التعليم
     والتدريب: مبانٍ وغرف ومرافق، تسكين الطلاب، عقود إيجار،
     صيانة، أمن، حضور، وجدولة، مدفوعات وفوترة، تقارير إشغال.
  ============================================================ */
  {
    id: "student-accommodation",
    code: 102,
    nameAr: "إدارة السكن الطلابي",
    nameEn: "Student Accommodation Management",
    c: "education",
    icon: "building-2",
    descAr: "إدارة شاملة للسكن الطلابي: مبانٍ وغرف ومرافق، تسكين الطلاب حسب الجامعة والكلية والتخصص، عقود السكن، صيانة وأعطال، أمن وحضور، جدولة ومدفوعات، وتقارير إشغال لحظية.",
    descEn: "Complete student accommodation management: buildings, rooms and facilities, student housing by university/college/major, residence contracts, maintenance and faults, security and attendance, scheduling and payments, and real-time occupancy analytics.",
    mods: ["dormBuildings", "dormRooms", "roomAssignments", "residents", "leases", "facilities", "maintenance", "security", "attendance", "payments", "staff", "reports", "invoices"],
  },
];

/* ============================================================
   AGGREGATE + LOOKUPS
============================================================ */
export const CATALOG: Catalog = {
  categories: CATEGORIES,
  modules: MODULES,
  systems: SYSTEMS,
};

export const CATEGORY_MAP: Record<string, Category> = Object.fromEntries(
  CATEGORIES.map((c) => [c.id, c])
);

export const MODULE_MAP: Record<string, ModuleDef> = Object.fromEntries(
  MODULES.map((m) => [m.id, m])
);

export const SYSTEM_MAP: Record<string, SystemDef> = Object.fromEntries(
  SYSTEMS.map((s) => [s.id, s])
);

/* ROUND 85 — systemCodeLabel() ("SYS-001"…) REMOVED as dead code: it had
 * zero importers after the SYS-xxx codes were hidden from every user
 * surface (the /api/catalog route also strips the numeric field from the
 * public response — codes remain internal-only). */

/**
 * Round 29 — resolve the effective module list for a system.
 * Specialized systems carry their own `mods` override (gyms, barbershops,
 * driving schools); every other system falls back to its category's set.
 *
 * ROUND 134 — TWO universal modules are appended to EVERY system's list:
 *   • "shifts" (الورديات) — the owner's directive: a toggleable module in
 *     the الوحدات control of all 102 systems. Enabled → the strict R133
 *     shift law (server gate + sign-out lock + secret-code open); disabled
 *     → the whole shift surface stands down.
 *   • "expenses" (المصروفات) — the owner's directive: «إذا هناك نظام
 *     وحداته لا يحتوي على (المصروفات) قم بإضافة» — only the finance
 *     category curates it natively; the resolver guarantees every other
 *     system carries it too (the curated EXP preset + code prefix already
 *     exist in module-presets/hospitality-services-finance.ts).
 * Appending in the RESOLVER (not the category arrays) keeps the curated
 * sector sets byte-identical while every system still exposes both
 * toggles. Existing instances are backfilled by
 * scripts/backfill-r134-modules.ts; new instances select both by default
 * (buildSystemDraft starts from systemMods).
 */
export function systemMods(system: SystemDef | undefined): string[] {
  const base = system?.mods ?? (system ? CATEGORY_MAP[system.c]?.mods ?? [] : []);
  const withShifts = base.includes("shifts") ? base : [...base, "shifts"];
  return withShifts.includes("expenses") ? withShifts : [...withShifts, "expenses"];
}

/* ============================================================
   ROUND 64 — per-system module LABEL overrides
   Sector-correct vocabulary: the same module id can carry a
   domain-specific name inside a specific system (the generic
   "Staff / الموظفون" module is the "Medical Staff / الكوادر
   الطبية" inside the hospital management system). The catalog
   stays single-sourced; only the DISPLAY name is overridden.
============================================================ */
export const MODULE_LABEL_OVERRIDES: Record<
  string,
  Record<string, { nameAr: string; nameEn: string }>
> = {
  "hospital-management": {
    staff: { nameAr: "الكوادر الطبية", nameEn: "Medical Staff" },
  },
  /* ROUND 166 — SAMS sector vocabulary (السكن الطلابي): the occupants are
     STUDENTS (الطلاب), not generic residents, and the contracts are
     residence contracts (عقود السكن) — the owner's exact wording. */
  "student-accommodation": {
    residents: { nameAr: "الطلاب", nameEn: "Students" },
    leases: { nameAr: "عقود السكن", nameEn: "Residence Contracts" },
    /* ROUND 166 — الحضور والغياب: the dedicated 8-state attendance
       console (movements + policy + allowances + QR) lives here. */
    attendance: { nameAr: "الحضور والغياب", nameEn: "Attendance & Absence" },
  },
};

/**
 * ROUND 64 — resolve a module's display name IN THE CONTEXT of a system:
 * per-system override → catalog default → raw moduleId fallback. This is
 * the single source of truth every module-name surface should call
 * (modules grid, module workspace header, sidebar chip, doc title).
 */
export function moduleDisplayName(
  moduleId: string,
  systemId: string | undefined | null,
  lang: Lang
): string {
  const override = systemId ? MODULE_LABEL_OVERRIDES[systemId]?.[moduleId] : undefined;
  if (override) return lang === "ar" ? override.nameAr : override.nameEn;
  const m = MODULE_MAP[moduleId];
  return m ? (lang === "ar" ? m.nameAr : m.nameEn) : moduleId;
}

/* ============================================================
   ROUND 67 — UNIFIED team display name: "فريق الإدارة".
   The user mandate is explicit: the page that carries the system's
   admins AND its owner is titled "فريق الإدارة / Management Team"
   in EVERY system, across all sectors — the ROUND 65 sector
   vocabulary (الكوادر الطبية / الهيئة الإدارية / فريق العمل)
   is retired. The resolver shape (per-system override map kept for
   future flexibility) is preserved so a later round can re-introduce
   vocabulary surgically without touching any consumer.
============================================================ */
const TEAM_CATEGORY_LABELS: Record<string, { nameAr: string; nameEn: string }> = {};

/** System-specific team overrides take precedence over the category default. */
const TEAM_LABEL_OVERRIDES: Record<string, { nameAr: string; nameEn: string }> = {};

/**
 * ROUND 67 — resolve the TEAM page title in the context of a system:
 * per-system override → sector category label → the unified
 * "فريق الإدارة / Management Team" default (now the effective name for
 * every system). Single source of truth for the sidebar nav item, team
 * view heading, profile dialog subtitle and the browser tab title.
 */
export function teamDisplayName(
  systemId: string | undefined | null,
  lang: Lang
): string {
  const sys = systemId ? SYSTEM_MAP[systemId] : undefined;
  if (sys) {
    const cat = TEAM_CATEGORY_LABELS[sys.c];
    if (cat) return lang === "ar" ? cat.nameAr : cat.nameEn;
    const override = systemId ? TEAM_LABEL_OVERRIDES[systemId] : undefined;
    if (override) return lang === "ar" ? override.nameAr : override.nameEn;
  }
  return lang === "ar" ? "فريق الإدارة" : "Management Team";
}
