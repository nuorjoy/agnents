"use client";

import { useT } from "@/lib/i18n";

/**
 * Skip-to-content link — the first focusable element of every app shell
 * (WCAG 2.4.1 bypass block). Visually hidden until keyboard focus, then
 * pinned above the page as a high-contrast brand pill.
 */
export function SkipLink({ target = "main-content" }: { target?: string }) {
  const { t } = useT();
  return (
    <a
      href={`#${target}`}
      className="sr-only focus:not-sr-only focus:absolute focus:z-[100] focus:m-2 focus:rounded-md focus:bg-primary focus:px-4 focus:py-2 focus:text-[13px] focus:font-extrabold focus:text-primary-foreground focus:shadow-lift focus:outline-none"
    >
      {t("skipToContent")}
    </a>
  );
}

export default SkipLink;
