"use client";

import { useEffect, useRef, useState } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ThemeProvider } from "next-themes";
import { DirectionProvider } from "@radix-ui/react-direction";
import { useAppStore } from "@/lib/store";
import { dirFor, LANG_COOKIE } from "@/lib/locales";

/**
 * React Query + next-themes providers.
 * Also syncs <html lang/dir> with the persisted app language (RTL/LTR —
 * Arabic renders RTL, every other locale LTR, see src/lib/locales.ts).
 *
 * `nonce` comes from the CSP middleware (per-request) so next-themes'
 * pre-paint no-flash script stays executable under the nonce-based CSP.
 *
 * ROUND 170 (performance) - MotionConfig REMOVED from the root: importing
 * any framer-motion symbol here dragged the full animation engine
 * (~56KB gzip) into EVERY route's critical path, including the public
 * landing which no longer animates with framer at all. The
 * reducedMotion="user" contract is preserved per-surface instead: each
 * framer-animated surface root (dashboard-app, wizard-overlay,
 * error-shell, platform-legal-view, instance-login-gate, store surfaces)
 * wraps its own tree with <MotionConfig reducedMotion="user"> - those
 * roots already ship the framer engine in their chunks, so the guarantee
 * costs zero extra bytes. The global CSS kill-switch covers CSS animations.
 * — the global CSS kill-switch only covers CSS animations.
 *
 * ROUND 55 — DirectionProvider: Radix portals (Select / DropdownMenu /
 * Popover / …) render into document.body and DO NOT inherit the <html dir>
 * attribute — without an explicit direction context every portal defaulted
 * to LTR, so Arabic dropdown lists (e.g. the support form's request-type)
 * rendered left-aligned. Wrapping the tree with the live app direction makes
 * every portal RTL-aware globally (items right-aligned, checkmarks on the
 * correct side, popper flips).
 */
export function AppProviders({
  children,
  nonce,
}: {
  children: React.ReactNode;
  nonce?: string;
}) {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            staleTime: 30_000,
            retry: 1,
            refetchOnWindowFocus: false,
          },
        },
      })
  );

  const lang = useAppStore((s) => s.lang);
  const appliedRef = useRef<string | null>(null);

  useEffect(() => {
    if (appliedRef.current === lang) return;
    appliedRef.current = lang;
    const root = document.documentElement;
    root.lang = lang;
    root.dir = dirFor(lang);
    /* ROUND 185 — one-time cookie re-sync: a visitor whose persisted
     * language predates the ashrlc-lang cookie (or whose last switch went
     * through a pre-R185 path that didn't write it) still gets an
     * Arabic-first server render on every load. After hydration the store
     * holds the truth — mirror it back into the cookie so the NEXT load's
     * SSR (RSC shell, html lang/dir, fonts, metadata titles) speaks the
     * user's language from the first byte. Runs once per language change
     * (guarded by appliedRef), best-effort like every cookie write. */
    try {
      const match = document.cookie
        .split("; ")
        .find((row) => row.startsWith(`${LANG_COOKIE}=`));
      const cookieLang = match ? match.slice(LANG_COOKIE.length + 1) : "";
      if (cookieLang !== lang) {
        document.cookie = `${LANG_COOKIE}=${lang}; path=/; max-age=${60 * 60 * 24 * 365}; samesite=lax`;
      }
    } catch {
      /* storage unavailable — the sync is best-effort */
    }
  }, [lang]);

  /* live direction — consumed by every Radix PORTAL surface */
  const dir = dirFor(lang);

  return (
    <QueryClientProvider client={queryClient}>
      <DirectionProvider dir={dir}>
        <ThemeProvider
            attribute="class"
            defaultTheme="dark"
            enableSystem
            disableTransitionOnChange
            storageKey="ashrilogic-v3-theme"
            nonce={nonce}
          >
            {children}
        </ThemeProvider>
      </DirectionProvider>
    </QueryClientProvider>
  );
}
