"use client";

/**
 * ROUND 84 (84-CONTACT) — the PREMIUM unified contact inputs.
 *
 * One shared visual + behavioral language for every phone / email field
 * across ALL systems (wizard org step, admin account, owner login, the
 * workspace sign-in gate, the settings org card and the storefront
 * customer account):
 *
 *  - PremiumPhoneInput — INTERNATIONAL LAYOUT (ROUND 89): the composite
 *    is ALWAYS a left-to-right field — the country dial-code selector is
 *    pinned at the physical FAR LEFT (أقصى اليسار), the LTR national
 *    number island flows to its right, and the live emerald verdict
 *    parks at the field's physical far right. This is the universal
 *    phone-number convention (+966 5X XXX XXXX reads left→right) and it
 *    holds in BOTH UI directions — an Arabic RTL form still shows the
 *    dial code at the far left, exactly like the world's phone UIs
 *    (WhatsApp/Apple/Google contact fields). The parent owns ONE
 *    canonical `+{dial}{national}` string (E.164-ish, trunk zeros
 *    stripped); incoming canonical values are split back into dial +
 *    national for display. Digits-only sanitization, live verdict +
 *    rose shake/message, canonical preview under the field.
 *  - PremiumEmailInput — gradient mail tile + LTR `email` input with
 *    whitespace-stripping + lowercase normalization (Arabic keyboards),
 *    a debounced EMAIL_RE verdict, and a `locked` mode (owner-account reuse)
 *    that renders the emerald lock chip.
 *
 * ROUND 85 — OVERLAP FIX (kept): the number island is a TRUE LTR
 * sub-island (dir="ltr") even inside the RTL composite, so the trailing
 * verdict icon (inset-inline-end) sits at the SAME physical edge the
 * input's pe-* padding reserves — the ✓ «تم التحقق» mark can never
 * overlap the typed number/email in either direction.
 *
 * Design language: the wizard's premium field vocabulary (WZ_INPUT /
 * WZ_LABEL in wizard-shared.tsx) — h-11 rounded-xl, border-slate-200 /
 * dark:white/10, ring-4 ring-brand-500/15 focus, font-semibold, ≥44px touch
 * targets (the h-11 composite exactly matches every sibling WZ_INPUT /
 * login / gate / store field height for a pixel-even form rhythm),
 * RTL-native with an LTR island for the address/number itself.
 */

import { useEffect, useId, useState, type ReactNode, type Ref } from "react";
import { motion, useAnimationControls } from "framer-motion";
import { COUNTRIES } from "@/data/countries";
import { EMAIL_RE } from "@/lib/validation";
import { useT, type I18nKey } from "@/lib/i18n";
import { cn, grad } from "@/lib/utils";
import { CatIcon } from "@/components/icon";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
} from "@/components/ui/select";

/* ------------------------------------------------------------------ */
/* shared vocabulary                                                   */
/* ------------------------------------------------------------------ */

/** Field label — the exact WZ_LABEL treatment (11.5px extrabold slate). */
const PC_LABEL = "mb-1.5 block text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300";

/** Countries that actually carry a dial code (the EU pseudo-entry is a
 *  currency union, not one dialing region → excluded from the selector). */
const DIAL_COUNTRIES = COUNTRIES.filter((c) => c.dial !== "");

/** Default selection — السعودية (+966), the platform's home market. */
const DEFAULT_DIAL_CODE = "SA";

/** Shared props — drop-in compatible with the existing field call sites. */
export interface PremiumContactFieldProps {
  id?: string;
  /** Label i18n key (rendered by the component with the label row below). */
  label: I18nKey;
  value: string;
  onChange: (value: string) => void;
  required?: boolean;
  /** Parent-side failure flag (e.g. the wizard shell's field error). */
  invalid?: boolean;
  disabled?: boolean;
  readOnly?: boolean;
  /** Helper text i18n key rendered under the field (over the component default). */
  hint?: I18nKey;
  autoComplete?: string;
  /** Placeholder i18n key (defaults to the premium contact placeholder). */
  placeholder?: I18nKey;
  /** Focus orchestration for parents (login/gate focus flows). */
  inputRef?: Ref<HTMLInputElement>;
  autoFocus?: boolean;
}

/** The adornment tile — brand gradient + subtle inner sheen, clipped by the
 *  field container's rounded corners. */
function AdornmentTile({ icon, gradient }: { icon: string; gradient: string }) {
  return (
    <span
      aria-hidden="true"
      className="relative grid w-11 shrink-0 place-items-center text-white"
      style={{ backgroundImage: gradient }}
    >
      {/* inner gradient sheen */}
      <span className="pointer-events-none absolute inset-0 bg-linear-to-b from-white/25 via-white/5 to-transparent" />
      <span className="pointer-events-none absolute inset-0 ring-1 ring-inset ring-white/25" />
      <CatIcon name={icon} className="relative h-[15px] w-[15px]" />
    </span>
  );
}

/** Label row: label + required star, or the emerald locked chip when the
 *  field is locked (owner-account reuse — the admin-step convention). */
function FieldLabel({
  htmlFor,
  labelKey,
  required,
  locked,
  lockedChip,
}: {
  htmlFor: string;
  labelKey: I18nKey;
  required?: boolean;
  locked?: boolean;
  lockedChip?: I18nKey;
}) {
  const { t } = useT();
  return (
    <Label htmlFor={htmlFor} className={PC_LABEL}>
      {t(labelKey)}
      {locked && lockedChip ? (
        <span className="ms-1.5 inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-1.5 py-px text-[9.5px] font-extrabold text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-300">
          <CatIcon name="lock" className="h-2.5 w-2.5" />
          {t(lockedChip)}
        </span>
      ) : required ? (
        <span className="ms-1 text-rose-500">*</span>
      ) : null}
    </Label>
  );
}

/** Rose, role=alert inline message (aria-describedby target). */
function FieldError({ id, children }: { id: string; children: ReactNode }) {
  return (
    <p
      id={id}
      role="alert"
      className="mt-1.5 flex items-center gap-1.5 text-[11px] font-bold leading-relaxed text-rose-500 dark:text-rose-400"
    >
      <CatIcon name="circle-alert" className="h-3.5 w-3.5 shrink-0" />
      {children}
    </p>
  );
}

/** Inner input class — strips the base Input chrome; the CONTAINER owns the
 *  border / focus ring so the whole composite field glows as one unit. */
const PC_INNER_INPUT =
  "h-full w-full border-0 bg-transparent px-3.5 text-start text-[13px] font-semibold text-slate-800 shadow-none outline-none " +
  "placeholder:font-normal placeholder:text-slate-400 dark:bg-transparent dark:text-slate-100 dark:placeholder:text-slate-500 " +
  "focus-visible:border-0 focus-visible:ring-0 focus-visible:shadow-none aria-invalid:border-0 aria-invalid:ring-0";

/** The composite container — WZ_INPUT's premium anatomy (h-11, the exact
 * height of every sibling wizard/login/gate/store field) with a unified
 * focus ring (focus-within) and valid/invalid repaints. */
function pcContainer(valid: boolean, showError: boolean, inert: boolean): string {
  return cn(
    "relative flex h-11 items-stretch overflow-hidden rounded-xl border transition-all duration-200",
    "border-slate-200 bg-white dark:border-white/10 dark:bg-ink-900/60",
    "focus-within:border-brand-400 focus-within:shadow-lg focus-within:shadow-brand-500/15",
    valid && !showError && !inert && "border-emerald-400/80 dark:border-emerald-400/50",
    valid && !showError && !inert && "ring-2 ring-emerald-500/20 focus-within:ring-4 focus-within:ring-brand-500/15",
    showError && "border-rose-400 ring-2 ring-rose-500/20 focus-within:border-rose-400 focus-within:ring-4 focus-within:ring-rose-500/20",
    !valid && !showError && "focus-within:ring-4 focus-within:ring-brand-500/15",
    inert && "cursor-not-allowed opacity-60 dark:bg-white/[0.03]"
  );
}

/* ------------------------------------------------------------------ */
/* phone helpers                                                       */
/* ------------------------------------------------------------------ */

/**
 * Split an incoming phone value into catalog dial info + national digits.
 * Accepts canonical `+{dial}{national}` (auto-matching the prefix), raw
 * `+…` strings and legacy local numbers (no dial info → code: null).
 */
function parsePhone(raw: string): { code: string | null; national: string } {
  const trimmed = (raw ?? "").trim();
  if (!trimmed) return { code: null, national: "" };
  const digits = trimmed.replace(/\D/g, "");
  if (!digits) return { code: null, national: "" };
  if (trimmed.startsWith("+")) {
    /* longest-prefix match — 3-digit codes (+966) before 2 (+20) before 1 (+1) */
    for (let len = 3; len >= 1; len--) {
      const hit = DIAL_COUNTRIES.find((c) => c.dial === `+${digits.slice(0, len)}`);
      if (hit && digits.length > len) return { code: hit.code, national: digits.slice(len) };
    }
    /* a "+"-prefixed number matching no catalog dial: keep every digit in
     * the national part so nothing is silently lost */
    return { code: null, national: digits };
  }
  /* legacy local format (e.g. 0501234567) — no dial info carried */
  return { code: null, national: digits };
}

/** Canonical output: `+{dial}{national}` with trunk zeros stripped (the
 *  E.164 convention — 0501234567 under +966 becomes +966501234567). */
function toCanonical(dial: string, national: string): string {
  const nat = national.replace(/^0+/, "");
  return nat ? `${dial}${nat}` : "";
}

/** Group national digits for the readable preview (3-3-… from the right). */
function groupDigits(digits: string): string {
  if (digits.length <= 3) return digits;
  const parts: string[] = [];
  for (let i = digits.length; i > 0; i -= 3) parts.unshift(digits.slice(Math.max(0, i - 3), i));
  return parts.join(" ");
}

/* ------------------------------------------------------------------ */
/* PremiumPhoneInput                                                   */
/* ------------------------------------------------------------------ */

export interface PremiumPhoneInputProps extends PremiumContactFieldProps {
  /** Placeholder override for the national input (default: pciPhonePh). */
  placeholder?: I18nKey;
  /** Helper text override (default: pciPhoneHint / live canonical preview). */
  hint?: I18nKey;
}

export function PremiumPhoneInput({
  id,
  label,
  value,
  onChange,
  required,
  invalid,
  disabled,
  readOnly,
  hint,
  autoComplete = "tel-national",
  placeholder,
  inputRef,
}: PremiumPhoneInputProps) {
  const { t } = useT();
  const rid = useId();
  const fieldId = id ?? `pc-phone-${rid}`;
  const hintId = `${fieldId}-hint`;
  const errId = `${fieldId}-err`;

  /* dial selection: internal state so an empty field still remembers the
   * user's dial choice; synced from the value whenever it carries one */
  const parsed = parsePhone(value);
  const [dialCode, setDialCode] = useState<string>(parsed.code ?? DEFAULT_DIAL_CODE);
  const [prevValue, setPrevValue] = useState(value);
  if (value !== prevValue) {
    setPrevValue(value);
    if (parsed.code) setDialCode(parsed.code);
  }

  const dial = COUNTRIES.find((c) => c.code === dialCode)?.dial ?? "+966";
  const national = parsed.national;
  const nationalEmit = national.replace(/^0+/, "");

  /* validity: dial selected (always — default SA) + 7–12 national digits */
  const valid = nationalEmit.length >= 7 && nationalEmit.length <= 12;
  const empty = national === "";
  const [touched, setTouched] = useState(false);
  const showError = (touched || !!invalid) && !valid && !(empty && !required);

  /* rose shake when the error state appears */
  const controls = useAnimationControls();
  useEffect(() => {
    if (showError) controls.start({ x: [0, -8, 8, -6, 6, -3, 0] }, { duration: 0.45 });
  }, [showError, controls]);

  const inert = !!disabled || !!readOnly;

  const onNationalChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const digits = e.target.value.replace(/\D/g, "").slice(0, 15);
    onChange(toCanonical(dial, digits));
  };

  const onDialChange = (code: string) => {
    const next = COUNTRIES.find((c) => c.code === code)?.dial;
    if (!next) return;
    setDialCode(code);
    onChange(toCanonical(next, national));
  };

  const errMsg = empty ? t("pciPhoneRequired") : t("pciPhoneInvalid");
  const canonicalPreview = nationalEmit ? `${dial} ${groupDigits(nationalEmit)}` : "";

  return (
    <div className="w-full">
      <FieldLabel htmlFor={fieldId} labelKey={label} required={required} />

      <motion.div animate={controls}>
        {/* ROUND 89 — INTERNATIONAL LAYOUT (owner directive: the country
            dial codes must sit at the FAR LEFT, precisely and
            professionally): the composite is a TRUE LTR field in BOTH UI
            languages — the dial-code selector is the first physical
            element (far left), the divider, then the national-number
            island; the verdict keeps the far-right end-2.5 slot inside
            the island's pe-8 padding, so the ROUND-85 overlap can never
            return. Arabic forms keep their RTL labels/hints (rendered
            OUTSIDE this container) — only the number field itself
            follows the international left→right phone convention. */}
        <div dir="ltr" className={pcContainer(valid, showError, inert)}>
          {/* the dial-code selector — premium gradient trigger */}
          <Select value={dialCode} onValueChange={onDialChange} disabled={inert}>
            <SelectTrigger
              aria-label={t("pciDialLabel")}
              title={t("pciDialLabel")}
              className="relative h-full w-[5.25rem] shrink-0 justify-center gap-1 rounded-none border-0 bg-transparent px-2 text-[13px] font-extrabold text-white shadow-none outline-none transition-[filter] hover:brightness-110 focus-visible:ring-0 focus-visible:shadow-none disabled:cursor-not-allowed disabled:opacity-100 dark:bg-transparent [&_svg:not([class*='text-'])]:text-white/80"
              style={{ backgroundImage: grad("#6d5dfb", "#06b6d4") }}
            >
              {/* inner gradient sheen + inset ring (the AdornmentTile anatomy) */}
              <span
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-linear-to-b from-white/25 via-white/5 to-transparent"
              />
              <span
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 ring-1 ring-inset ring-white/25"
              />
              <span dir="ltr" className="relative tabular-nums">
                {dial}
              </span>
            </SelectTrigger>
            <SelectContent className="max-h-72 min-w-[15rem]">
              <SelectGroup>
                {DIAL_COUNTRIES.map((c) => (
                  <SelectItem key={c.code} value={c.code} className="py-2 text-[12.5px]">
                    <span dir="ltr" className="font-extrabold tabular-nums text-brand-600 dark:text-brand-300">
                      {c.dial}
                    </span>
                    <span className="truncate text-slate-500 dark:text-slate-400">{c.name}</span>
                  </SelectItem>
                ))}
              </SelectGroup>
            </SelectContent>
          </Select>

          <span aria-hidden="true" className="w-px shrink-0 bg-slate-200 dark:bg-white/10" />

          {/* the national number — LTR text flowing straight after the dial;
            an LTR sub-island in BOTH directions so digits and the verdict
            always share one physical frame */}
          <div dir="ltr" className="relative flex min-w-0 flex-1 items-center">
            <Input
              ref={inputRef}
              id={fieldId}
              type="tel"
              dir="ltr"
              inputMode="tel"
              lang="en"
              value={national}
              onChange={onNationalChange}
              onBlur={() => setTouched(true)}
              placeholder={t(placeholder ?? "pciPhonePh")}
              maxLength={15}
              autoComplete={autoComplete}
              disabled={disabled}
              readOnly={readOnly}
              aria-readonly={readOnly || undefined}
              aria-invalid={showError || invalid || undefined}
              aria-describedby={showError ? errId : hintId}
              className={cn(PC_INNER_INPUT, "pe-8", inert && "cursor-not-allowed")}
            />
            {/* live validity verdict */}
            {valid && !showError ? (
              <span
                role="status"
                aria-label={t("pciPhoneValid")}
                title={t("pciPhoneValid")}
                className="pointer-events-none absolute end-2.5 grid h-5 w-5 place-items-center text-emerald-500"
              >
                <CatIcon name="circle-check" className="h-[15px] w-[15px]" />
              </span>
            ) : null}
          </div>
        </div>
      </motion.div>

      {/* helper row: error > canonical preview > default hint */}
      {showError ? (
        <FieldError id={errId}>{errMsg}</FieldError>
      ) : canonicalPreview ? (
        <p id={hintId} className="mt-1.5 flex items-center gap-1.5 text-[11px] font-semibold text-slate-500 dark:text-slate-400">
          <CatIcon name="globe" className="h-3 w-3 shrink-0 text-brand-500" />
          <span dir="ltr" className="tabular-nums">
            {t("pciPhonePreview", { value: canonicalPreview })}
          </span>
        </p>
      ) : (
        <p id={hintId} className="mt-1.5 text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
          {t(hint ?? "pciPhoneHint")}
        </p>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* PremiumEmailInput                                                   */
/* ------------------------------------------------------------------ */

export interface PremiumEmailInputProps extends PremiumContactFieldProps {
  /** Reuse/owner-account mode: read-only field + emerald lock chip. */
  locked?: boolean;
  /** Chip label key rendered beside the field label when locked. */
  lockedChip?: I18nKey;
}

export function PremiumEmailInput({
  id,
  label,
  value,
  onChange,
  required,
  invalid,
  disabled,
  readOnly,
  locked,
  lockedChip,
  hint,
  autoComplete = "email",
  placeholder,
  inputRef,
  autoFocus,
}: PremiumEmailInputProps) {
  const { t } = useT();
  const rid = useId();
  const fieldId = id ?? `pc-email-${rid}`;
  const hintId = `${fieldId}-hint`;
  const errId = `${fieldId}-err`;

  /* debounced live verdict — typing never flickers rose mid-correction */
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const timer = window.setTimeout(() => setDebounced(value), 320);
    return () => window.clearTimeout(timer);
  }, [value]);
  const valid = EMAIL_RE.test(debounced);
  const empty = value === "";

  const [touched, setTouched] = useState(false);
  const showError = (touched || !!invalid) && !valid && !(empty && !required);

  const controls = useAnimationControls();
  useEffect(() => {
    if (showError) controls.start({ x: [0, -8, 8, -6, 6, -3, 0] }, { duration: 0.45 });
  }, [showError, controls]);

  const inert = !!disabled || !!readOnly || !!locked;

  /* Arabic keyboards can't produce "@" reliably and phones love to
   * autocapitalize — normalize to the canonical email form as typed:
   * lowercase + whitespace stripped, nothing else touched */
  const onEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onChange(e.target.value.replace(/\s+/g, "").toLowerCase());
  };

  const errMsg = empty ? t("pciEmailRequired") : t("pciEmailInvalid");

  return (
    <div className="w-full">
      <FieldLabel htmlFor={fieldId} labelKey={label} required={required} locked={locked} lockedChip={lockedChip} />

      <motion.div animate={controls}>
        {/* ROUND 85 — LTR island: mail tile at the far LEFT, the LTR email
            input, and the verdict/lock at the FAR RIGHT under the input's
            pe-9 reserved space (overlap eliminated). */}
        <div dir="ltr" className={pcContainer(valid, showError, inert)}>
          <AdornmentTile icon="mail" gradient={grad("#10b981", "#0e7490")} />

          <div className="relative flex min-w-0 flex-1 items-center">
            <Input
              ref={inputRef}
              id={fieldId}
              type="email"
              dir="ltr"
              inputMode="email"
              lang="en"
              value={value}
              onChange={onEmailChange}
              onBlur={() => setTouched(true)}
              placeholder={t(placeholder ?? "pciEmailPh")}
              maxLength={160}
              autoComplete={autoComplete}
              autoFocus={autoFocus}
              disabled={disabled}
              readOnly={readOnly || locked}
              aria-readonly={readOnly || locked || undefined}
              aria-invalid={showError || invalid || undefined}
              aria-describedby={showError ? errId : hint ? hintId : undefined}
              className={cn(PC_INNER_INPUT, "pe-9", locked && "font-bold text-slate-500 dark:text-slate-300", inert && "cursor-not-allowed")}
            />
            {/* trailing verdict / lock */}
            {locked ? (
              <span
                aria-hidden="true"
                className="pointer-events-none absolute end-3 grid h-5 w-5 place-items-center text-emerald-500"
              >
                <CatIcon name="lock" className="h-[14px] w-[14px]" />
              </span>
            ) : valid && !showError ? (
              <span
                role="status"
                aria-label={t("pciEmailValid")}
                title={t("pciEmailValid")}
                className="pointer-events-none absolute end-3 grid h-5 w-5 place-items-center text-emerald-500"
              >
                <CatIcon name="circle-check" className="h-[15px] w-[15px]" />
              </span>
            ) : null}
          </div>
        </div>
      </motion.div>

      {showError ? (
        <FieldError id={errId}>{errMsg}</FieldError>
      ) : hint ? (
        <p id={hintId} className="mt-1.5 flex items-center gap-1.5 text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
          <CatIcon name="mail" className="h-3 w-3 shrink-0 text-brand-500" />
          {t(hint)}
        </p>
      ) : null}
    </div>
  );
}
