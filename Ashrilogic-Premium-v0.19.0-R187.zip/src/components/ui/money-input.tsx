"use client";

/**
 * ROUND 167 — MoneyInput: decimal price entry in MAJOR units, exposing the
 * integer MINOR value (the money.ts contract).
 *
 * A controlled STRING input designed for the plan/add-on price fields:
 *  - accepts decimals typed as "9.99" or "9,99" (comma → dot);
 *  - accepts ARABIC-INDIC / EASTERN / DEVANAGARI / FULLWIDTH digits
 *    (the ROUND 46 international digit law — same table as the security
 *    cards' OTP normalizer, kept local so this primitive stays
 *    dependency-light for every consumer);
 *  - enforces ≤2 decimal places and a single separator LIVE (a third
 *    decimal digit is simply not accepted);
 *  - clamps into [min, max] MAJOR units on blur;
 *  - renders a formatted helper under the field — fmtPlanPrice of the
 *    current value (÷100, 2 decimals, Western digits) + the currency — so
 *    the operator sees the exact receipt figure while typing.
 *
 * The parent owns the display string (exactly like the previous plain
 * number fields) and receives the parsed integer minor units through
 * onValueMinor on every change — no ÷100/×100 arithmetic at the call sites.
 */
import { useId } from "react";
import { useT } from "@/lib/i18n";
import { fmtPlanPrice } from "@/lib/format";
import { CatIcon } from "@/components/icon";
import { cn } from "@/lib/utils";

/* ROUND 46 — the international digit table (security-cards' OTP law):
 * Arabic-Indic, Eastern Arabic-Indic, Devanagari and fullwidth digits all
 * map to ASCII 0-9 so an Arabic/Hindi keyboard still prices in cents. The
 * DECIMAL SEPARATORS join the table (U+066B ٫ + fullwidth ．) — without
 * them "٩٫٩٩" would strip its separator and parse as 999 dollars. */
const DIGIT_TRANSLATION: Record<string, string> = {
  "٠": "0", "١": "1", "٢": "2", "٣": "3", "٤": "4", "٥": "5", "٦": "6", "٧": "7", "٨": "8", "٩": "9",
  "۰": "0", "۱": "1", "۲": "2", "۳": "3", "۴": "4", "۵": "5", "۶": "6", "۷": "7", "۸": "8", "۹": "9",
  "०": "0", "१": "1", "२": "2", "३": "3", "४": "4", "५": "5", "६": "6", "७": "7", "८": "8", "९": "9",
  "０": "0", "１": "1", "２": "2", "３": "3", "４": "4", "５": "5", "６": "6", "７": "7", "８": "8", "９": "9",
  "٫": ".", "．": ".",
};

function normalizeDigits(raw: string): string {
  return raw.replace(/[٠-٩۰-९０-９٫．]/g, (ch) => DIGIT_TRANSLATION[ch] ?? ch);
}

/** Sane default bounds in MAJOR units (the admin price fields' family). */
const DEFAULT_MIN_MAJOR = 0;
const DEFAULT_MAX_MAJOR = 1_000_000;

/**
 * Parse one money display string into integer MINOR units.
 * Pure + total: "" / garbage → null (the caller decides the fallback);
 * "9.99" / "9,99" / "٩٫٩٩"-digits → 999.
 */
export function moneyDisplayToMinor(display: string): number | null {
  let s = normalizeDigits(display).replace(/,/g, ".");
  /* keep digits + the FIRST dot only */
  const firstDot = s.indexOf(".");
  s = s.replace(/\./g, (ch, index: number) => (index === firstDot ? ch : ""));
  s = s.replace(/[^0-9.]/g, "");
  if (s === "" || s === ".") return null;
  /* at most two decimal places — the money contract */
  const dot = s.indexOf(".");
  if (dot >= 0) s = s.slice(0, dot + 3);
  const major = Number.parseFloat(s);
  if (!Number.isFinite(major)) return null;
  return Math.round(major * 100);
}

export interface MoneyInputProps {
  /** the display string in MAJOR units ("9.99") — controlled by the parent */
  value: string;
  /** the (normalized) display string on every keystroke */
  onChange: (next: string) => void;
  /** the parsed integer MINOR units on every change (null-when-unparseable
   *  never fires here: partial input degrades to the typed prefix) */
  onValueMinor: (minor: number) => void;
  /** currency label rendered in the helper (e.g. "USD") */
  currency?: string;
  /** MAJOR-unit bounds (clamped on blur + min/max attrs) */
  minMajor?: number;
  maxMajor?: number;
  disabled?: boolean;
  invalid?: boolean;
  id?: string;
  /** a11y label when no visible <Label htmlFor> wraps the field */
  ariaLabel?: string;
  className?: string;
  /** compact variant for dense rows (the add-on ladder) */
  compact?: boolean;
}

export function MoneyInput({
  value,
  onChange,
  onValueMinor,
  currency,
  minMajor = DEFAULT_MIN_MAJOR,
  maxMajor = DEFAULT_MAX_MAJOR,
  disabled,
  invalid,
  id,
  ariaLabel,
  className,
  compact,
}: MoneyInputProps) {
  const { t } = useT();
  const autoId = useId();
  const fieldId = id ?? `money-${autoId}`;

  /* normalize the incoming keystroke: international digits → ASCII,
   * comma → dot, at most one dot, at most two decimals. */
  const handle = (raw: string) => {
    let next = normalizeDigits(raw).replace(/,/g, ".");
    const firstDot = next.indexOf(".");
    next = next.replace(/\./g, (ch, index: number) => (index === firstDot ? ch : ""));
    next = next.replace(/[^0-9.]/g, "");
    const dot = next.indexOf(".");
    if (dot >= 0) next = next.slice(0, dot + 3);
    /* a lone trailing dot is kept for typing ("9." is a valid waypoint) */
    onChange(next);
    const minor = moneyDisplayToMinor(next);
    onValueMinor(minor ?? 0);
  };

  /* blur: clamp into the bounds, drop a lone dot, re-parse */
  const blur = () => {
    const minor = moneyDisplayToMinor(value);
    if (minor === null) {
      onChange(String(minMajor));
      onValueMinor(Math.round(minMajor * 100));
      return;
    }
    const clamped = Math.min(Math.round(maxMajor * 100), Math.max(Math.round(minMajor * 100), minor));
    const display = String(clamped / 100);
    onChange(display);
    onValueMinor(clamped);
  };

  const minor = moneyDisplayToMinor(value) ?? 0;

  return (
    <div className={cn("w-full", className)}>
      <div className="relative">
        <input
          id={fieldId}
          type="text"
          inputMode="decimal"
          dir="ltr"
          autoComplete="off"
          data-1p-ignore
          aria-label={ariaLabel}
          aria-invalid={invalid || undefined}
          disabled={disabled}
          value={value}
          onChange={(e) => handle(e.target.value)}
          onBlur={blur}
          className={cn(
            "w-full rounded-xl border bg-slate-50/80 px-3.5 text-end font-extrabold tabular-nums text-slate-800 shadow-none outline-none transition focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 disabled:opacity-60 dark:bg-white/[0.04] dark:text-slate-100",
            compact ? "h-9 text-[12px]" : "h-11 text-[13px]",
            invalid
              ? "border-rose-300 focus:border-rose-400 focus:ring-4 focus:ring-rose-500/15 dark:border-rose-500/40"
              : "border-slate-200 focus:border-brand-400 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10"
          )}
        />
        {currency ? (
          <span
            className="pointer-events-none absolute inset-y-0 end-3 flex items-center text-[10px] font-bold text-slate-400 dark:text-slate-500"
            aria-hidden="true"
          >
            {currency}
          </span>
        ) : null}
      </div>
      {/* the formatted helper — the exact receipt figure (fmtPlanPrice ÷100,
          2 decimals, Western digits in every locale) */}
      <p
        className={cn(
          "mt-1 flex items-center justify-end gap-1 text-[10.5px] font-bold tabular-nums text-slate-400 dark:text-slate-500",
          compact && "mt-0.5 text-[9.5px]"
        )}
        dir="ltr"
      >
        <CatIcon name="banknote" className="h-3 w-3 shrink-0" aria-hidden="true" />
        {fmtPlanPrice(minor)}
        {currency ? ` ${currency}` : ""}
        <span className="sr-only">{t("moneyHelperSr")}</span>
      </p>
    </div>
  );
}

export default MoneyInput;
