"use client";

/**
 * Ashrilogic — premium live clock & date widget.
 *
 * A direction-safe, locale-aware (AR/EN) ticking clock rendered as a glassy
 * pill. Used across the platform (dashboard topbar, system select screen,
 * landing systems section) so every surface shares the same premium time
 * language: gradient clock tile, tabular-nums digits and a localized full
 * date.
 *
 * The tile icon and the status dot reflect the TIME OF DAY (morning /
 * afternoon / evening / night) — the dot is intentionally static (no pulse)
 * and its color changes with the period instead of animating every second.
 *
 * `timezone` (IANA, from the workspace org prefs) drives the displayed time
 * so the dashboard always shows the organization's local time — not the
 * visitor's device time. Falls back to the device timezone.
 */
import { useEffect, useMemo, useState } from "react";
import { useT, type I18nKey } from "@/lib/i18n";
import { intlLocale } from "@/lib/locales";
import { CatIcon } from "@/components/icon";
import { cn } from "@/lib/utils";

interface LiveClockProps {
  /** compact pill for topbars; wide chip for section headers */
  variant?: "topbar" | "chip";
  /** IANA timezone (e.g. "Asia/Riyadh"); defaults to the device timezone */
  timezone?: string;
  /** gradient colors for the clock tile (defaults to brand) */
  c1?: string;
  c2?: string;
  className?: string;
  /** hide the date line (topbar shows time+date inline instead) */
  hideDate?: boolean;
}

/** One of the four daily periods the clock visuals resolve to. */
type DayPeriod = "morning" | "day" | "evening" | "night";

interface PeriodStyle {
  icon: string;
  dot: string;
  labelKey: I18nKey;
}

const PERIOD_STYLES: Record<DayPeriod, PeriodStyle> = {
  morning: { icon: "sunrise", dot: "#f59e0b", labelKey: "clockMorning" },
  day: { icon: "sun", dot: "#10b981", labelKey: "clockDay" },
  evening: { icon: "sunset", dot: "#f43f5e", labelKey: "clockEvening" },
  night: { icon: "moon", dot: "#64748b", labelKey: "clockNight" },
};

/* Local hour (device) — the period is a visual nicety, so the org timezone
   would be ideal, but extracting it from Intl requires formatting first. */
function hourOf(date: Date): number {
  return date.getHours();
}

export function periodOf(date: Date): DayPeriod {
  const h = hourOf(date);
  if (h >= 5 && h < 12) return "morning";
  if (h >= 12 && h < 17) return "day";
  if (h >= 17 && h < 21) return "evening";
  return "night";
}

/** Period visuals for a given moment (stable per period — no animation). */
export function periodStyle(date: Date | null): PeriodStyle {
  return PERIOD_STYLES[date ? periodOf(date) : "day"];
}

/**
 * SSR-safe ticking clock. Returns `null` until the component mounts so the
 * server HTML and the first client render are identical (a placeholder is
 * shown) — rendering a real time during SSR would guarantee a hydration
 * mismatch because the client hydrates milliseconds later.
 *
 * ROUND 168 — document-visibility pause: while the tab is hidden the
 * interval (and the leading rAF tick) is CLEARED — zero timer work while
 * backgrounded; returning to visibility resyncs the time immediately and
 * restores the interval. The SSR-safe placeholder contract and the hook's
 * signature are unchanged (every LiveClock consumer keeps its behavior).
 */
function useNow(intervalMs = 1000): Date | null {
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    const tick = () => setNow(new Date());
    let raf = 0;
    let id = 0;
    const start = () => {
      /* first tick on the next frame (async — never a synchronous setState) */
      raf = window.requestAnimationFrame(tick);
      id = window.setInterval(tick, intervalMs);
    };
    const stop = () => {
      if (raf) window.cancelAnimationFrame(raf);
      if (id) window.clearInterval(id);
      raf = 0;
      id = 0;
    };
    const onVisibility = () => {
      if (document.visibilityState === "visible") {
        tick(); /* resync the shown time instantly */
        if (id === 0) start();
      } else {
        stop();
      }
    };
    if (document.visibilityState !== "hidden") start();
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      document.removeEventListener("visibilitychange", onVisibility);
      stop();
    };
  }, [intervalMs]);
  return now;
}

export function LiveClock({
  variant = "topbar",
  timezone,
  c1 = "#6d5dfb",
  c2 = "#d946ef",
  className,
  hideDate = false,
}: LiveClockProps) {
  const { t, lang } = useT();
  const now = useNow();

  const safeTz = useMemo(() => {
    if (!timezone) return undefined;
    try {
      new Intl.DateTimeFormat("en-US", { timeZone: timezone });
      return timezone;
    } catch {
      return undefined;
    }
  }, [timezone]);

  const locale = intlLocale(lang);

  /* Pre-mount (SSR + first client paint): stable tabular placeholder that
     keeps the exact same box size as the rendered digits — no layout shift,
     no hydration mismatch. */
  const time =
    now === null
      ? "--:--:--"
      : new Intl.DateTimeFormat(locale, {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
          hour12: true,
          ...(safeTz ? { timeZone: safeTz } : {}),
        }).format(now);

  const date =
    now === null
      ? "…"
      : new Intl.DateTimeFormat(locale, {
          weekday: "long",
          day: "numeric",
          month: "long",
          year: "numeric",
          ...(safeTz ? { timeZone: safeTz } : {}),
        }).format(now);

  /* period visuals — static dot (never pulses), recolored by time of day */
  const period = periodStyle(now);
  const periodLabel = now === null ? "" : t(period.labelKey);

  if (variant === "topbar") {
    /* ROUND 158 — the period icon is a SEPARATE sibling next to the clock,
     * NOT embedded inside it. The user directive: «فصل الأيقونة عن الساعة
     * تماماً لتكون موجودة لصقها فقط لكن غير مدمجة داخل الساعة». */
    return (
      <div className={cn("flex items-center gap-1.5", className)}>
        <span
          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
          style={{ backgroundImage: `linear-gradient(135deg, ${c1}, ${c2})` }}
          aria-hidden="true"
          title={now === null ? undefined : periodLabel}
        >
          <CatIcon name={period.icon} className="h-[14px] w-[14px]" />
        </span>
        <div
          role="timer"
          aria-label={now === null ? t("clockNow") : `${time} — ${date} — ${periodLabel}`}
          title={
            now === null
              ? t("clockNow")
              : safeTz
                ? `${t("clockNow")} · ${safeTz} · ${periodLabel}`
                : `${t("clockNow")} · ${periodLabel}`
          }
          className="group flex h-9 select-none items-center gap-2 rounded-xl border border-slate-200 bg-slate-50/70 px-3 transition hover:border-brand-300 hover:bg-white dark:border-white/10 dark:bg-white/[0.04] dark:hover:border-brand-500/40 dark:hover:bg-white/[0.07]"
        >
          <span className="flex min-w-0 items-center gap-1.5" dir="ltr">
            <span className="text-[12.5px] font-extrabold tabular-nums tracking-tight text-slate-800 dark:text-slate-100" style={{ minWidth: "78px", textAlign: "center" }}>
              {time}
            </span>
            <span
              className="h-1.5 w-1.5 shrink-0 rounded-full transition-colors duration-700"
              style={{ backgroundColor: period.dot }}
              aria-hidden="true"
            />
          </span>
          {!hideDate ? (
            <span className="hidden min-w-0 truncate border-s border-slate-200 ps-2 text-[11px] font-bold text-slate-500 dark:border-white/10 dark:text-slate-400 lg:block">
              {date}
            </span>
          ) : null}
        </div>
      </div>
    );
  }

  /* chip — wider section-header presentation */
  return (
    <div
      role="timer"
      aria-label={now === null ? t("clockNow") : `${time} — ${date} — ${periodLabel}`}
      className={cn(
        "inline-flex select-none items-center gap-2.5 rounded-2xl border border-slate-200/80 bg-white/80 px-3.5 py-2 shadow-soft backdrop-blur-sm dark:border-white/10 dark:bg-white/[0.04]",
        className
      )}
    >
      <span
        className="grid h-8 w-8 shrink-0 place-items-center rounded-xl text-white shadow-md"
        style={{ backgroundImage: `linear-gradient(135deg, ${c1}, ${c2})` }}
        aria-hidden="true"
      >
        <CatIcon name={period.icon} className="h-[13px] w-[13px]" />
      </span>
      <div className="min-w-0 leading-tight">
        <p className="flex items-center gap-1.5 text-[14px] font-extrabold tabular-nums tracking-tight text-slate-900 dark:text-white" dir="ltr" style={{ minWidth: "92px" }}>
          {time}
          <span
            className="h-1.5 w-1.5 rounded-full transition-colors duration-700"
            style={{ backgroundColor: period.dot }}
            aria-hidden="true"
          />
        </p>
        {!hideDate ? (
          <p className="mt-0.5 truncate text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
            {date}
            {safeTz ? <span className="mx-1 text-slate-300 dark:text-slate-600">·</span> : null}
            {safeTz ? <span dir="ltr">{safeTz}</span> : null}
          </p>
        ) : null}
      </div>
    </div>
  );
}

export default LiveClock;
