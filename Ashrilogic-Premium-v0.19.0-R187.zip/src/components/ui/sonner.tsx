"use client"

import { useEffect, useState } from "react"
import { useTheme } from "next-themes"
import { Toaster as Sonner, ToasterProps } from "sonner"
import { useAppStore } from "@/lib/store"

/**
 * Global toast surface — premium glass treatment docked at the TOP of the
 * viewport, 76px below the sticky dashboard topbar so it never covers it.
 * RTL-aware: toasts dock to the reading-start corner of the active language
 * (top-left for Arabic, top-right for English). Rich variants
 * (success/error/warning/info) keep their sonner color accents.
 */
const Toaster = ({ ...props }: ToasterProps) => {
  const { theme, resolvedTheme } = useTheme()
  const lang = useAppStore((s) => s.lang)
  const rtl = lang === "ar"

  /* The toaster mounts outside the theme provider, so next-themes gives no
     value here — track the class next-themes applies to <html> instead
     (reactive via MutationObserver so live toggles re-skin open toasts). */
  const [htmlTheme, setHtmlTheme] = useState<"light" | "dark" | null>(null)
  useEffect(() => {
    const root = document.documentElement
    const sync = () => setHtmlTheme(root.classList.contains("dark") ? "dark" : "light")
    sync()
    const observer = new MutationObserver(sync)
    observer.observe(root, { attributes: true, attributeFilter: ["class"] })
    return () => observer.disconnect()
  }, [])

  return (
    <Sonner
      theme={(htmlTheme ?? resolvedTheme ?? theme ?? "system") as ToasterProps["theme"]}
      position={rtl ? "top-left" : "top-right"}
      dir={rtl ? "rtl" : "ltr"}
      offset="76px"
      gap={10}
      duration={4000}
      richColors
      closeButton
      className="toaster group"
      style={
        {
          /* Glassy surface for default toasts — resolved theme-aware via the
             document palette (light ≈ white/95, dark ≈ ink-900/95). Rich
             variants keep their own accent variables untouched. */
          "--normal-bg": "color-mix(in srgb, var(--popover) 95%, transparent)",
          "--normal-text": "var(--popover-foreground)",
          "--normal-border": "color-mix(in srgb, var(--border) 85%, transparent)",
          "--border-radius": "1rem",
        } as React.CSSProperties
      }
      toastOptions={{
        classNames: {
          /* Shape + elevation for every toast (sonner ships unlayered styles,
             so the trailing "!" important modifiers are required to win). */
          toast:
            "rounded-2xl! border! backdrop-blur-xl shadow-[0_18px_50px_-12px_rgba(15,23,42,0.25)]! dark:shadow-[0_18px_50px_-12px_rgba(0,0,0,0.6)]!",
          title: "font-bold!",
        },
      }}
      {...props}
    />
  )
}

export { Toaster }
