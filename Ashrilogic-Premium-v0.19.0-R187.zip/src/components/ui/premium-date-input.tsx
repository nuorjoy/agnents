"use client";

/**
 * Ashrilogic — PremiumDateInput (ROUND 149 / TASK F, rebuilt ROUND 163).
 *
 * The owner's directives:
 *   R149: «في جميع الأنظمة قمّ بإعادة تطوير حقول التاريخ ويجب ان يدعم
 *    الترتيب والتنسيق العربي من اليمين إلى اليسار بدقة طور من واجهة
 *    (التقويم) واجعله premium»
 *   R163: the calendar affordance must sit INSIDE the field at the FAR
 *    RIGHT when the UI language is Arabic — pixel-precise, mirrored to
 *    the far LEFT in English. Logical `start` utilities deliver that:
 *    start-0 is the physical RIGHT edge under dir="rtl" and the physical
 *    LEFT edge under dir="ltr".
 *
 * The native <input type="date"> is the most reliable cross-browser date
 * picker, but it ships an English-only calendar UI with no Arabic month
 * names and no RTL awareness. This component ENHANCES the native input
 * rather than replacing it (no third-party picker dependency):
 *
 *   - the native calendar-indicator is hidden (opacity-0) and stretched
 *     over the WHOLE field (inset-0, covering the start icon area too),
 *     so a click anywhere on the input still opens the native picker;
 *   - the visible affordance is a premium brand-gradient tile pinned at
 *     the inline-START edge (far right in Arabic / far left in English)
 *     — the AdornmentTile anatomy from premium-contact.tsx (gradient +
 *     inner sheen + inset hairline ring), hover-brighten, active-press
 *     and a focus-visible ring — triggering showPicker() on modern
 *     browsers with a focus() fallback elsewhere;
 *   - the clear (X) button sits at the inline-END edge, opposite the
 *     calendar tile, and emits a synthetic native-shaped ChangeEvent
 *     (target.value = "") so existing onChange handlers are untouched;
 *   - an Arabic-formatted display string renders BELOW the input via
 *     Intl.DateTimeFormat("ar-SA-u-ca-gregory", …) — Gregorian calendar
 *     with Arabic month names + Arabic-Indic digits (plus the local
 *     time for the datetime-local flavor);
 *   - the wrapper is dir="rtl" for Arabic and dir="ltr" for English so
 *     the layout flows the right way;
 *   - text padding is tuned so the value never sits under either
 *     affordance in BOTH directions: ps-11 (44px clears the 32px start
 *     tile + its 10px margin) and pe-9 (36px clears the end X button);
 *   - two rhythms: size="md" (h-10, the compact dialog fields) and
 *     size="lg" (h-11 with the WZ_INPUT focus anatomy, for the wizard
 *     vocabulary forms). type="date" (default) or "datetime-local".
 *
 * The component is forwardRef'd and accepts every prop a native date
 * <input> accepts (value, onChange, name, id, min, max, disabled,
 * readOnly, …). The onChange contract is preserved byte-for-byte (a real
 * React.ChangeEvent<HTMLInputElement> with target.value = the ISO
 * yyyy-mm-dd / yyyy-mm-ddThh:mm string the native picker emits) so
 * existing handlers do not need to change.
 */
import { forwardRef, useRef, type ChangeEvent, type InputHTMLAttributes, type ReactNode } from "react";
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { cn, grad } from "@/lib/utils";

export interface PremiumDateInputProps
  extends Omit<InputHTMLAttributes<HTMLInputElement>, "onChange" | "type" | "size"> {
  /** the small icon + label rendered above the input (optional). */
  label?: ReactNode;
  /** show the Arabic-formatted display string below the input (default true).
   *  Set false when the parent already shows its own localized date hint. */
  showArabicDisplay?: boolean;
  /** the controlled value (ISO yyyy-mm-dd, or yyyy-mm-ddThh:mm for the
   *  datetime-local flavor). */
  value?: string;
  /** the standard React change handler. Receives a synthetic event with
   *  target.value = "" (cleared) or the new ISO date string. */
  onChange?: (e: ChangeEvent<HTMLInputElement>) => void;
  /** the wrapper div's className (the input + buttons ride inside it). */
  wrapperClassName?: string;
  /** extra className applied to the native input on top of the premium base. */
  inputClassName?: string;
  /** native input flavor — plain dates (default) or local date-times. */
  type?: "date" | "datetime-local";
  /** field rhythm — h-10 (default, compact dialogs) or h-11 (WZ_INPUT-height
   *  forms). */
  size?: "md" | "lg";
}

/**
 * Render the Arabic long-form date string for a given ISO value, using
 * the Gregorian calendar + Arabic locale (so 2026-03-12 →
 * «الخميس، ١٢ مارس ٢٠٢٦»; the datetime flavor appends the local time).
 * Returns "" on parse failure or empty input.
 */
function formatArabicDate(iso: string, withTime: boolean): string {
  if (!iso || typeof iso !== "string") return "";
  try {
    const d = new Date(iso.length === 10 ? `${iso}T00:00:00` : iso);
    if (Number.isNaN(d.getTime())) return "";
    return new Intl.DateTimeFormat("ar-SA-u-ca-gregory", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
      ...(withTime ? { hour: "2-digit", minute: "2-digit" } : {}),
    }).format(d);
  } catch {
    return "";
  }
}

export const PremiumDateInput = forwardRef<HTMLInputElement, PremiumDateInputProps>(
  (
    {
      label,
      showArabicDisplay = true,
      className,
      wrapperClassName,
      inputClassName,
      type = "date",
      size = "md",
      value,
      onChange,
      disabled,
      id,
      ...props
    },
    ref,
  ) => {
    const { lang } = useT();
    const innerRef = useRef<HTMLInputElement | null>(null);

    /* Merge the forwarded ref + the inner ref so we can call showPicker()
     * on the actual DOM node (modern browsers — Chrome 95+, Edge 95+,
     * Safari 17+, Firefox 101+). Falls back silently elsewhere (the
     * calendar indicator still works on click). */
    const setRef = (el: HTMLInputElement | null) => {
      innerRef.current = el;
      if (typeof ref === "function") ref(el);
      else if (ref) {
        (ref as React.MutableRefObject<HTMLInputElement | null>).current = el;
      }
    };

    const withTime = type === "datetime-local";
    const arabicDisplay = showArabicDisplay ? formatArabicDate(value ?? "", withTime) : "";

    const openCalendar = () => {
      const el = innerRef.current;
      if (!el) return;
      /* showPicker() throws on unsupported browsers / untrusted contexts;
       * fall back to a synthetic focus() so the calendar indicator still
       * opens the picker in those environments. */
      try {
        if (typeof el.showPicker === "function") {
          el.showPicker();
          return;
        }
      } catch {
        /* ignore — fall through to focus */
      }
      el.focus();
    };

    const clearValue = () => {
      /* Synthesize a real ChangeEvent so existing onChange handlers
       * (setVal / setValue) receive the same shape they'd get from the
       * native picker. value="" is what the native picker also emits
       * when the user clears the input. */
      const synthetic = {
        target: { value: "" },
        currentTarget: { value: "" },
      } as ChangeEvent<HTMLInputElement>;
      onChange?.(synthetic);
    };

    const hasValue = typeof value === "string" && value.length > 0;

    return (
      <div className={cn("space-y-1.5", wrapperClassName)} dir={lang === "ar" ? "rtl" : "ltr"}>
        {label ? (
          <label
            htmlFor={id}
            className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
          >
            {label}
          </label>
        ) : null}
        <div className="relative">
          <input
            ref={setRef}
            id={id}
            type={type}
            value={value ?? ""}
            onChange={onChange}
            disabled={disabled}
            className={cn(
              /* ps-11 (44px) clears the 32px start-anchored calendar tile +
               * its ms-2.5 margin; pe-9 (36px) clears the end-anchored clear
               * button — the value never rides under either affordance in
               * either direction. */
              "w-full rounded-xl border border-slate-200 bg-white ps-11 pe-9 font-semibold text-start text-slate-700 transition focus:border-brand-400 focus:outline-none",
              size === "lg"
                ? "h-11 text-[13px] focus:ring-4 focus:ring-brand-500/15 focus:shadow-lg focus:shadow-brand-500/15"
                : "h-10 text-[12.5px] focus:ring-2 focus:ring-brand-500/20",
              "dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200",
              /* hide the native calendar indicator — our own brand gradient
               * tile opens the same picker via showPicker(); the indicator
               * overlay is stretched over the WHOLE field (inset-0, covering
               * the start icon area) so any click on the input body still
               * opens the native picker. */
              "[&::-webkit-calendar-picker-indicator]:opacity-0 [&::-webkit-calendar-picker-indicator]:absolute [&::-webkit-calendar-picker-indicator]:inset-0 [&::-webkit-calendar-picker-indicator]:h-full [&::-webkit-calendar-picker-indicator]:w-full [&::-webkit-calendar-picker-indicator]:cursor-pointer",
              "disabled:cursor-not-allowed disabled:opacity-60 read-only:cursor-not-allowed read-only:bg-slate-50 read-only:text-slate-500 dark:read-only:bg-white/[0.04] dark:read-only:text-slate-400",
              className,
              inputClassName,
            )}
            style={{ colorScheme: "light dark" }}
            {...props}
          />
          {/* R163 — the calendar affordance at the inline-START edge:
           * FAR RIGHT in Arabic (dir="rtl"), FAR LEFT in English. The
           * premium brand-gradient tile uses the AdornmentTile anatomy
           * (gradient + inner sheen + inset hairline ring) so the field
           * speaks the same icon language as the composite contact
           * fields; it is keyboard-focusable (focus-visible ring) and
           * opens the SAME native picker via showPicker(). */}
          <button
            type="button"
            onClick={openCalendar}
            title={lang === "ar" ? "فتح التقويم" : "Open calendar"}
            aria-label={lang === "ar" ? "فتح التقويم" : "Open calendar"}
            className="absolute inset-y-0 start-0 ms-2.5 my-auto grid h-8 w-8 place-items-center rounded-lg text-white shadow-sm transition-all duration-200 hover:brightness-110 active:scale-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-500/60 disabled:pointer-events-none disabled:opacity-60"
            disabled={disabled}
            style={{ backgroundImage: grad("#6d5dfb", "#06b6d4") }}
          >
            {/* inner gradient sheen */}
            <span
              aria-hidden="true"
              className="pointer-events-none absolute inset-0 rounded-lg bg-linear-to-b from-white/25 via-white/5 to-transparent"
            />
            {/* inset hairline ring */}
            <span
              aria-hidden="true"
              className="pointer-events-none absolute inset-0 rounded-lg ring-1 ring-inset ring-white/25"
            />
            <CatIcon name="calendar" className="relative h-4 w-4" />
          </button>
          {/* the clear (X) button rides the inline-END edge, opposite the
           * calendar tile — rose hover (the dismiss vocabulary of
           * premium-close.tsx) and a synthetic native clear event. */}
          {hasValue ? (
            <button
              type="button"
              tabIndex={-1}
              onClick={clearValue}
              aria-label={lang === "ar" ? "مسح التاريخ" : "Clear date"}
              title={lang === "ar" ? "مسح التاريخ" : "Clear date"}
              className="absolute inset-y-0 end-0 me-2 my-auto grid h-7 w-7 place-items-center rounded-lg text-slate-400 transition hover:bg-rose-50 hover:text-rose-500 active:scale-90 disabled:pointer-events-none disabled:opacity-60 dark:hover:bg-rose-500/15 dark:hover:text-rose-300"
              disabled={disabled}
            >
              <CatIcon name="x" className="h-3.5 w-3.5" />
            </button>
          ) : null}
        </div>
        {arabicDisplay ? (
          <p
            dir="rtl"
            className="flex items-start gap-1 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500"
          >
            <CatIcon name="calendar" className="mt-0.5 h-3 w-3 shrink-0" aria-hidden="true" />
            {arabicDisplay}
          </p>
        ) : null}
      </div>
    );
  },
);

PremiumDateInput.displayName = "PremiumDateInput";
