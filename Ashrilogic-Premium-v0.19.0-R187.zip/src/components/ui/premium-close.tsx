"use client";

/**
 * Ashrilogic — the ONE premium close (X) affordance.
 *
 * Every dismissible surface in the product (Radix dialogs, sheets, the
 * workspace sign-in gate, the system picker…) renders this exact button so
 * the mark stays pixel-identical everywhere:
 *  - circular glass pill with a hairline border
 *  - the glyph rotates 90° toward the hover state
 *  - hover turns destructive (rose) since "close" is a dismiss action
 *  - logical `end` positioning → mirrors correctly in RTL
 */
import { XIcon } from "lucide-react";

import { cn } from "@/lib/utils";

/** Shared classes for the close trigger itself (positioning stays at the call site). */
export const PREMIUM_CLOSE_CLASS =
  "group grid h-8 w-8 shrink-0 place-items-center rounded-full border border-slate-200/90 bg-white/80 text-slate-500 shadow-sm backdrop-blur-sm transition-all duration-200 hover:border-rose-300 hover:bg-rose-50 hover:text-rose-500 hover:shadow-md hover:shadow-rose-500/15 active:scale-90 focus-visible:ring-2 focus-visible:ring-rose-400/40 focus-visible:outline-none disabled:pointer-events-none dark:border-white/15 dark:bg-white/[0.06] dark:text-slate-400 dark:hover:border-rose-400/50 dark:hover:bg-rose-500/15 dark:hover:text-rose-300 dark:hover:shadow-rose-500/10";

/** Shared classes for the X glyph (rotate-on-hover micro-interaction). */
export const PREMIUM_CLOSE_ICON_CLASS =
  "h-[15px] w-[15px] transition-transform duration-300 ease-[cubic-bezier(0.34,1.4,0.64,1)] group-hover:rotate-90";

export function PremiumClose({
  className,
  label,
  iconClassName,
  ...props
}: React.ComponentProps<"button"> & {
  /** localized accessible name (defaults to a neutral "Close") */
  label?: string;
  iconClassName?: string;
}) {
  return (
    <button
      type="button"
      aria-label={label ?? "Close"}
      className={cn(PREMIUM_CLOSE_CLASS, className)}
      {...props}
    >
      <XIcon className={cn(PREMIUM_CLOSE_ICON_CLASS, iconClassName)} />
    </button>
  );
}
