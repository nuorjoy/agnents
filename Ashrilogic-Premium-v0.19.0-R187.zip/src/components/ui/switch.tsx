"use client"

import * as React from "react"
import * as SwitchPrimitive from "@radix-ui/react-switch"
import { CheckIcon, XIcon } from "lucide-react"

import { cn } from "@/lib/utils"

/**
 * Ashrilogic — unified premium switch.
 *
 * Design contract (identical in the wizard, dashboard, systems and admin
 * panel, in BOTH directions):
 *  - Track 44×24 with an inset shadow when OFF (clearly "off") and a
 *    glowing gradient when ON (clearly "on").
 *  - A ✓ glyph appears at the vacated edge when ON and an ✕ at the opposite
 *    edge when OFF, so both states read unambiguously.
 *  - The thumb travels by animating `inset-inline-start` (NOT a transform),
 *    which is direction-aware: it slides toward the end in LTR and toward
 *    the end in RTL without ever leaving the track.
 */
export type SwitchTone = "brand" | "success" | "warn" | "danger"

const TONE_TRACK: Record<SwitchTone, string> = {
  brand:
    "data-[state=checked]:bg-linear-to-r data-[state=checked]:from-brand-500 data-[state=checked]:to-fuchsia-500 data-[state=checked]:shadow-[0_6px_18px_-6px_rgba(139,92,246,0.55)]",
  success:
    "data-[state=checked]:bg-linear-to-r data-[state=checked]:from-emerald-500 data-[state=checked]:to-teal-400 data-[state=checked]:shadow-[0_6px_18px_-6px_rgba(16,185,129,0.55)]",
  warn:
    "data-[state=checked]:bg-linear-to-r data-[state=checked]:from-amber-400 data-[state=checked]:to-orange-500 data-[state=checked]:shadow-[0_6px_18px_-6px_rgba(245,158,11,0.55)]",
  danger:
    "data-[state=checked]:bg-linear-to-r data-[state=checked]:from-rose-500 data-[state=checked]:to-red-500 data-[state=checked]:shadow-[0_6px_18px_-6px_rgba(244,63,94,0.55)]",
}

function Switch({
  className,
  tone = "brand",
  ...props
}: React.ComponentProps<typeof SwitchPrimitive.Root> & {
  /** gradient family used for the ON state */
  tone?: SwitchTone
}) {
  return (
    <SwitchPrimitive.Root
      data-slot="switch"
      data-tone={tone}
      className={cn(
        "group relative inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full outline-none transition-[background-color,box-shadow] duration-300",
        "focus-visible:ring-[3px] focus-visible:ring-ring/40 focus-visible:ring-offset-2 focus-visible:ring-offset-background",
        "disabled:cursor-not-allowed disabled:opacity-50",
        /* OFF — muted track with an inner well shadow */
        "data-[state=unchecked]:bg-slate-200 data-[state=unchecked]:shadow-[inset_0_2px_4px_rgba(100,116,139,0.35)] dark:data-[state=unchecked]:bg-slate-600/70 dark:data-[state=unchecked]:shadow-[inset_0_2px_5px_rgba(0,0,0,0.5)]",
        TONE_TRACK[tone],
        className
      )}
      {...props}
    >
      {/* ✓ revealed at the start edge when ON */}
      <span
        data-slot="switch-on-icon"
        aria-hidden="true"
        className="pointer-events-none absolute inset-y-0 start-[5px] grid place-items-center"
      >
        <CheckIcon className="h-[11px] w-[11px] text-white opacity-0 transition-opacity duration-300 group-data-[state=checked]:opacity-100" strokeWidth={3.5} />
      </span>
      {/* ✕ revealed at the end edge when OFF */}
      <span
        data-slot="switch-off-icon"
        aria-hidden="true"
        className="pointer-events-none absolute inset-y-0 end-[6px] grid place-items-center"
      >
        <XIcon className="h-[10px] w-[10px] text-slate-400 opacity-0 transition-opacity duration-300 group-data-[state=unchecked]:opacity-100 dark:text-slate-400/80" strokeWidth={3} />
      </span>

      <SwitchPrimitive.Thumb
        data-slot="switch-thumb"
        className={cn(
          "pointer-events-none absolute top-[3px] start-[3px] grid size-[18px] place-items-center rounded-full bg-white",
          "shadow-[0_2px_6px_rgba(15,23,42,0.35)] ring-1 ring-black/[0.06]",
          "transition-[inset-inline-start] duration-300 ease-[cubic-bezier(0.34,1.4,0.64,1)]",
          /* direction-aware travel — never leaves the track */
          "data-[state=checked]:start-[calc(100%-21px)]",
          "group-focus-visible:ring-[3px] group-focus-visible:ring-ring/40"
        )}
      />
    </SwitchPrimitive.Root>
  )
}

export { Switch }
