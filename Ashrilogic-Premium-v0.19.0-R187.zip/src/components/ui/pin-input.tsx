"use client";

/**
 * Ashrilogic — PREMIUM PIN pad (R163 rebuild of the ROUND-159 segmented
 * input — the owner's directive: «احذف حقول الـPin code تماماً من الجذور
 * ثم قم بإعادة تطويره بطريقة بسيطة ومتقدمة وPremium»).
 *
 * Simple, advanced, premium — with the SAME public contract (props, i18n
 * keys, backend flows untouched: shift-open code + wallet-transfer proof):
 *  - One hidden authority input (mobile numeric keyboard, paste, SR)
 *  - A unified glass pad: segmented cells in one refined container with a
 *    gradient hairline, focus-within glow and a micro progress bar
 *  - Masked dots with a ghost show/hide lever
 *  - Arabic-Indic digits normalized on arrival
 *  - Enter submits at minLength; backspace semantics stay native
 *  - Error: rose cells + the ROUND-141 `.pin-shake` keyframes (finally
 *    wired — they were dead CSS since the R159 rewrite)
 *  - LTR direction (PINs are always entered left-to-right)
 */
import { useId, useRef, useState, type ClipboardEvent, type KeyboardEvent } from "react";
import { CatIcon } from "@/components/icon";
import { cn } from "@/lib/utils";
import { useT } from "@/lib/i18n";

/** Fold Arabic-Indic ٠-٩ + Extended ۰-۹ digits to ASCII (keep digits only). */
function normalizePinDigits(raw: string): string {
  let out = "";
  for (const ch of raw) {
    const code = ch.codePointAt(0) ?? 0;
    if (ch >= "0" && ch <= "9") out += ch;
    else if (code >= 0x0660 && code <= 0x0669) out += String(code - 0x0660);
    else if (code >= 0x06f0 && code <= 0x06f9) out += String(code - 0x06f0);
  }
  return out;
}

export function PinInput({
  value,
  onChange,
  maxLength = 8,
  minLength = 4,
  error = false,
  onEnter,
  autoFocus = true,
  disabled = false,
  label,
}: {
  value: string;
  onChange: (next: string) => void;
  maxLength?: number;
  minLength?: number;
  error?: boolean;
  onEnter?: () => void;
  autoFocus?: boolean;
  disabled?: boolean;
  label?: string;
}) {
  const { t } = useT();
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [visible, setVisible] = useState(false);
  const inputId = useId();

  /* cells grow with input but always show at least minLength cells.
   * The +1 gives one empty cell ahead of the cursor so the user sees
   * where the next digit will land. */
  const cells = Math.min(maxLength, Math.max(minLength, value.length + 1));
  /* entry progress toward the minimum — the micro bar under the cells */
  const progress = Math.min(1, value.length / minLength);

  const commit = (next: string) => {
    const clean = normalizePinDigits(next).slice(0, maxLength);
    if (clean !== value) onChange(clean);
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      e.preventDefault();
      if (value.length >= minLength) onEnter?.();
      return;
    }
  };

  const handlePaste = (e: ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    commit(e.clipboardData.getData("text"));
  };

  return (
    <div
      className="relative flex flex-col items-center gap-2"
      onClick={() => !disabled && inputRef.current?.focus()}
      role="presentation"
    >
      {/* hidden authority input — LTR always (PINs are numeric, no RTL needed) */}
      <input
        id={inputId}
        ref={inputRef}
        value={value}
        onChange={(e) => commit(e.target.value)}
        onKeyDown={handleKeyDown}
        onPaste={handlePaste}
        inputMode="numeric"
        autoComplete="off"
        autoFocus={autoFocus}
        disabled={disabled}
        aria-label={label ?? t("shiftSecretCode")}
        aria-invalid={error || undefined}
        dir="ltr"
        className="absolute inset-0 z-0 h-full w-full cursor-text opacity-0"
        style={{ fontSize: 16 }}
      />

      {/* ——— the R163 PIN pad: one premium glass container ——— */}
      <div
        className={cn(
          "pointer-events-none relative z-[1] w-full rounded-2xl border bg-white/80 p-2.5 shadow-sm transition-all duration-200",
          "focus-within:border-brand-400 focus-within:shadow-[0_0_0_4px_rgba(109,93,251,0.14),0_10px_28px_-14px_rgba(109,93,251,0.5)]",
          "dark:bg-white/[0.045]",
          error
            ? "border-rose-300 dark:border-rose-500/50"
            : "border-slate-200/90 dark:border-white/10",
          disabled && "opacity-60"
        )}
      >
        {/* the gradient hairline accent along the top edge (subtle premium cue) */}
        <span
          aria-hidden="true"
          className={cn(
            "absolute inset-x-6 top-0 h-px rounded-full",
            error
              ? "bg-linear-to-l from-rose-400/0 via-rose-400 to-rose-400/0"
              : "bg-linear-to-l from-emerald-400/0 via-emerald-400 to-emerald-400/0"
          )}
        />

        {/* cells row — LTR, no reverse. Filled digits only where they
            exist; the active cell (next to type) carries the pulse. */}
        <div key={error ? "err" : "ok"} className={cn("flex justify-center gap-1.5", error && "pin-shake")}>
          {Array.from({ length: cells }).map((_c, i) => {
            const filled = i < value.length;
            const active = i === value.length;
            return (
              <span
                key={i}
                aria-hidden="true"
                className={cn(
                  "grid h-12 min-w-0 flex-1 select-none place-items-center rounded-xl border-2 text-[17px] font-extrabold tabular-nums transition-all duration-150 sm:flex-none sm:w-10",
                  error
                    ? "border-rose-400 bg-rose-50/60 text-rose-600 dark:border-rose-500/60 dark:bg-rose-500/10 dark:text-rose-300"
                    : filled
                      ? "border-emerald-500/70 bg-emerald-50/70 text-slate-800 dark:border-emerald-500/50 dark:bg-emerald-500/10 dark:text-white"
                      : active
                        ? "border-emerald-400/80 bg-white shadow-[0_0_0_4px_rgba(16,185,129,0.12)] dark:bg-white/[0.04]"
                        : "border-slate-200 bg-slate-50/60 dark:border-white/10 dark:bg-white/[0.03]"
                )}
              >
                {filled ? (
                  visible ? (
                    <span dir="ltr" className="font-display tracking-widest">
                      {value[i]}
                    </span>
                  ) : (
                    <span className="block h-2.5 w-2.5 rounded-full bg-linear-to-b from-slate-600 to-slate-800 dark:from-slate-200 dark:to-slate-400" />
                  )
                ) : active ? (
                  <span className="block h-2 w-2 animate-pulse rounded-full bg-emerald-500" />
                ) : null}
              </span>
            );
          })}
        </div>

        {/* the micro progress bar — entry progress toward the minimum */}
        <div className="mt-2 flex items-center gap-2 px-1" aria-hidden="true">
          <div className="h-[3px] min-w-0 flex-1 overflow-hidden rounded-full bg-slate-100 dark:bg-white/[0.06]">
            <div
              className={cn(
                "h-full rounded-full transition-all duration-300",
                error
                  ? "bg-linear-to-l from-rose-500 to-rose-400"
                  : "bg-linear-to-l from-emerald-600 to-teal-400"
              )}
              style={{ width: `${Math.round(progress * 100)}%` }}
            />
          </div>
          <span
            dir="ltr"
            className={cn(
              "shrink-0 text-[9.5px] font-black tabular-nums",
              error ? "text-rose-500 dark:text-rose-300" : "text-slate-400 dark:text-slate-500"
            )}
          >
            {value.length}/{minLength}
          </span>
        </div>
      </div>

      {/* the show/hide lever — a ghost pill under the pad */}
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          setVisible((v) => !v);
        }}
        className="relative z-[2] inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10.5px] font-bold text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-white/5 dark:hover:text-slate-300"
      >
        <CatIcon name={visible ? "eye-off" : "eye"} className="h-3 w-3" />
        {t(visible ? "pinHide" : "pinShow")}
      </button>
    </div>
  );
}
