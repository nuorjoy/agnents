"use client";

/**
 * Ashrilogic — ROUND 87 (identity) client bridge.
 *
 * Mounted ONCE in the root layout (inside the provider tree). It fetches the
 * PUBLIC platform identity feed (`GET /api/identity`) and applies the pieces
 * that are DOCUMENT-LEVEL concerns to the live DOM:
 *
 *   • primaryColor → the root `--primary` custom property PLUS the full
 *     `--brand-*` ramp derived through `accentVars()` — the platform's
 *     canonical single-accent mechanism (globals.css maps every
 *     `--color-brand-*` utility and the `.brand-scope` token re-resolution
 *     to these vars), so the platform brand actually sticks on every
 *     surface that follows the brand.
 *   • radius        → the root `--radius` custom property (px).
 *   • faviconUrl    → an idempotent `<link rel="icon" id="identity-favicon">`.
 *   • primaryColor  → also an idempotent `<meta name="theme-color">`.
 *
 * accentColor / fonts / gradient / defaultTheme are intentionally NOT
 * document-level: they are consumed by other components through the same
 * query (`usePlatformIdentity`) — e.g. gradient headers pair primaryColor
 * with accentColor. When `identity` is null/empty the bridge does NOTHING:
 * the platform defaults (globals.css) stay untouched — zero visual drift.
 *
 * Rendering: none — this component returns null for its whole lifetime.
 */

import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { accentVars } from "@/lib/surface-styling";
import type { PlatformIdentityDTO } from "@/lib/types";

/** The public /api/identity payload. */
export interface PublicIdentityFeed {
  identity: PlatformIdentityDTO | null;
  siteNameAr: string;
  siteNameEn: string;
}

async function fetchPublicIdentity(): Promise<PublicIdentityFeed> {
  const res = await fetch("/api/identity");
  if (!res.ok) throw new Error(`/api/identity failed with ${res.status}`);
  return (await res.json()) as PublicIdentityFeed;
}

/** The shared query key — the admin settings console invalidates it after
 *  every identity save so the bridge converges immediately. */
export const IDENTITY_QUERY_KEY = ["platform-identity"] as const;

/**
 * The shared platform-identity query (5-minute stale window, one retry).
 * Other components (landing header, font/theme consumers) import THIS hook
 * so every surface reads the identity from the same cache entry.
 */
export function usePlatformIdentity() {
  return useQuery({
    queryKey: IDENTITY_QUERY_KEY,
    queryFn: fetchPublicIdentity,
    staleTime: 300_000,
    retry: 1,
  });
}

const HEX_RE = /^#[0-9a-fA-F]{6}$/;

export function IdentityBridge() {
  const { data } = usePlatformIdentity();
  const identity = data?.identity ?? null;

  /* App-lifetime application — no cleanup (the overrides are deliberately
     permanent for the session; a refetch only refines them). */
  useEffect(() => {
    if (!identity) return;
    const root = document.documentElement;

    if (identity.primaryColor && HEX_RE.test(identity.primaryColor)) {
      /* the REAL primary tokens (globals.css): `--primary` (drives every
         bg-primary/text-primary/ring utility through @theme inline) and the
         `--brand-*` ramp (drives brand-* utilities + .brand-scope). */
      root.style.setProperty("--primary", identity.primaryColor);
      const ramp = accentVars(identity.primaryColor) as unknown as Record<string, string>;
      for (const [name, value] of Object.entries(ramp)) {
        root.style.setProperty(name, value);
      }
      /* idempotent theme-color meta (own id — never touches the SSR ones) */
      let themeMeta = document.getElementById("identity-theme-color");
      if (!themeMeta) {
        themeMeta = document.createElement("meta");
        themeMeta.id = "identity-theme-color";
        themeMeta.setAttribute("name", "theme-color");
        document.head.appendChild(themeMeta);
      }
      themeMeta.setAttribute("content", identity.primaryColor);
    }

    if (typeof identity.radius === "number") {
      root.style.setProperty("--radius", `${identity.radius}px`);
    }

    if (identity.faviconUrl) {
      /* idempotent favicon link — replacing an existing platform favicon
         link would fight Next's metadata; appending our own tagged link is
         the standard dynamic-favicon approach. */
      let link = document.getElementById("identity-favicon") as HTMLLinkElement | null;
      if (!link) {
        link = document.createElement("link");
        link.id = "identity-favicon";
        link.rel = "icon";
        document.head.appendChild(link);
      }
      link.href = identity.faviconUrl;
    }
  }, [identity]);

  return null;
}

export default IdentityBridge;
