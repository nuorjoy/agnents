"use client";

/**
 * Ashrilogic — premium presence dot (ROUND 172).
 *
 * The one online/offline indicator every presence surface renders: emerald
 * (green) core with a soft glow ring + a subtle pulsing halo while ONLINE,
 * a static rose (red) core while OFFLINE — no indigo/blue, RTL-agnostic,
 * dark/light-token aware. Visual DNA mirrors the console's live-status dot
 * idiom (layered ring + shadow) so it reads as native anywhere it lands.
 *
 * Accessibility: the wrapper is a polite live region (role="status") whose
 * sr-only text carries the full localized detail — «متصل الآن» / «غير متصل —
 * آخر ظهور: منذ ٥ دقائق» / «غير متصل — لم يتصل بعد» — so state flips are
 * perceived without sight; the visual dot itself is aria-hidden. The pulsing
 * halo is disabled under prefers-reduced-motion (globals.css guard).
 *
 * The relative «آخر ظهور» label uses Intl.RelativeTimeFormat (browser
 * built-in — zero bundle cost for the landing page) with the app's own
 * intlLocale registry, so Arabic renders «منذ ٥ دقائق» natively. An optional
 * `now` (the snapshot's serverTime) keeps labels skew-free against a wrong
 * local clock; `label` overrides the tooltip/sr-only text for team-level
 * pills where the person-level «آخر ظهور» vocabulary does not apply.
 */
import { useT } from "@/lib/i18n";
import { intlLocale } from "@/lib/locales";
import type { Lang, PresenceDTO } from "@/lib/types";
import { cn } from "@/lib/utils";

export interface PresenceDotProps {
  /** live presence projection; null/undefined renders nothing (no guess) */
  presence?: PresenceDTO | null;
  /** core size — ~8/10/12px with proportional glow rings */
  size?: "sm" | "md" | "lg";
  /** render the short status word next to the dot (default: dot only) */
  showLabel?: boolean;
  className?: string;
  /** ISO reference "now" (the snapshot's serverTime) — skew-free relative
   *  «آخر ظهور» labels; omitted/null → the local clock (good enough) */
  now?: string | null;
  /** optional override for the title/sr-only text (team-level pills) */
  label?: string;
}

/** minutes/hours/days relative label — locale-aware, zero bundle cost. */
function presenceRelative(date: string, lang: Lang, now?: string | null): string {
  const then = new Date(date).getTime();
  if (Number.isNaN(then)) return "";
  const baseRaw = now ? new Date(now).getTime() : Date.now();
  const base = Number.isNaN(baseRaw) ? Date.now() : baseRaw;
  const diffSec = Math.round((then - base) / 1000);

  const rtf = new Intl.RelativeTimeFormat(intlLocale(lang), { numeric: "auto" });
  if (Math.abs(diffSec) < 60) return rtf.format(diffSec, "second");
  const diffMin = Math.round(diffSec / 60);
  if (Math.abs(diffMin) < 60) return rtf.format(diffMin, "minute");
  const diffHour = Math.round(diffSec / 3600);
  if (Math.abs(diffHour) < 24) return rtf.format(diffHour, "hour");
  return rtf.format(Math.round(diffSec / 86_400), "day");
}

export function PresenceDot({
  presence,
  size = "sm",
  showLabel = false,
  className,
  now,
  label,
}: PresenceDotProps) {
  const { t, lang } = useT();

  /* no data yet (first heartbeat in flight / DTO row without presence) —
   * render nothing rather than guessing a state */
  if (!presence) return null;

  const online = presence.online;
  const relative = online ? "" : presence.lastSeenAt ? presenceRelative(presence.lastSeenAt, lang, now) : "";
  const detail =
    label ??
    (online
      ? t("presenceOnline")
      : presence.lastSeenAt
        ? `${t("presenceOffline")} — ${t("presenceLastSeen")}: ${relative}`
        : `${t("presenceOffline")} — ${t("presenceNeverSeen")}`);

  const core = size === "lg" ? "h-3 w-3" : size === "md" ? "h-2.5 w-2.5" : "h-2 w-2";

  return (
    <span
      role="status"
      title={detail}
      className={cn("relative inline-flex shrink-0 items-center", showLabel && "gap-1.5", className)}
    >
      <span aria-hidden="true" className={cn("relative inline-flex", core)}>
        {/* ONLINE halo — the presence-pulse keyframe (globals.css) scales +
            fades this ring; prefers-reduced-motion disables it in CSS. */}
        {online ? <span className="animate-presence-pulse absolute inset-0 rounded-full bg-emerald-400/50" /> : null}
        {/* core — layered finish: solid core + soft spread ring + glow shadow */}
        <span
          className={cn(
            "relative h-full w-full rounded-full ring-2",
            online
              ? "bg-emerald-500 ring-emerald-500/25 shadow-[0_0_8px_rgba(16,185,129,0.6)] dark:bg-emerald-400 dark:shadow-[0_0_8px_rgba(52,211,153,0.45)]"
              : "bg-rose-500 ring-rose-500/20 shadow-[0_0_6px_rgba(244,63,94,0.35)] dark:bg-rose-400 dark:shadow-[0_0_6px_rgba(251,113,133,0.3)]"
          )}
        />
      </span>
      {/* accessible detail — updates on every heartbeat flip (live region) */}
      <span className="sr-only">{detail}</span>
      {showLabel ? (
        <span className="text-[11px] font-extrabold">{online ? t("presenceOnline") : t("presenceOffline")}</span>
      ) : null}
    </span>
  );
}

export default PresenceDot;
