"use client";

import type { ReactNode } from "react";
import { CatIcon } from "@/components/icon";
import { IconTile } from "@/components/dashboard/dash-shared";
import { useCountUp } from "@/hooks/use-count-up";
import { useT } from "@/lib/i18n";
import type { Lang } from "@/lib/types";
import { cn, fmtNum, grad, labelTrack } from "@/lib/utils";

/**
 * Ashrilogic — the ONE KPI stat card.
 *
 * Consolidates the near-identical gradient-tile stat cards that had
 * accumulated per-view copies (admin sites/support/packages/admins/overview,
 * analytics). All variants share the same DNA: glass-card + card-in stagger
 * (`--i`), gradient IconTile, uppercase label, display value. The shared
 * component keeps every option the copies had:
 *
 *  - `value` (ReactNode)  for pre-rendered strings/chips
 *  - `numeric`            for animated count-up values (tabular-nums)
 *  - `sub`                secondary line under the value
 *  - `lang`               Arabic letter-spacing suppression on the label
 *  - `accent`             hover gradient sweep on the top edge
 *  - `ltrValue`           force LTR on the value (phone numbers, currencies)
 *  - `size`               "lg" (default) icon tile or "sm" compact stat
 */

export interface KpiCardProps {
  label: string;
  value?: ReactNode;
  /** numeric value — renders with the count-up animation + tabular-nums */
  numeric?: number;
  sub?: ReactNode;
  icon: string;
  c1: string;
  c2: string;
  index?: number;
  lang?: Lang;
  /** hover gradient sweep on the top edge (admin-sites variant) */
  accent?: boolean;
  /** render the value inside dir="ltr" (numbers/currencies) */
  ltrValue?: boolean;
  /** compact layout with a small icon tile (analytics variant) */
  size?: "sm" | "lg";
  /** count-up duration for numeric values (ms) */
  duration?: number;
}

export function KpiCard({
  label,
  value,
  numeric,
  sub,
  icon,
  c1,
  c2,
  index = 0,
  lang,
  accent = false,
  ltrValue = false,
  size = "lg",
  duration = 1100,
}: KpiCardProps) {
  const { lang: ctxLang } = useT();
  const effectiveLang = lang ?? ctxLang;
  const { ref: countRef, value: anim } = useCountUp(numeric ?? 0, duration);
  const isNumeric = numeric !== undefined;

  const valueNode = isNumeric ? <span ref={countRef}>{fmtNum(anim, effectiveLang)}</span> : value;

  return (
    <article
      className={cn(
        "glass-card card-in rounded-3xl p-4 transition-shadow duration-300 hover:shadow-lift sm:p-5",
        accent && "group relative overflow-hidden transition-all duration-300 hover:-translate-y-0.5"
      )}
      style={{ "--i": index } as React.CSSProperties}
    >
      {accent ? (
        <span
          className="absolute inset-x-0 top-0 h-1 origin-center scale-x-0 transition-transform duration-300 group-hover:scale-x-100"
          style={{ backgroundImage: grad(c1, c2, 90) }}
          aria-hidden="true"
        />
      ) : null}
      {size === "sm" ? (
        <>
          <div className="flex items-center gap-3">
            <IconTile icon={icon} c1={c1} c2={c2} size="sm" />
            <p className="min-w-0 flex-1 truncate text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              {label}
            </p>
          </div>
          <p className="mt-2 font-display text-xl font-extrabold text-slate-900 dark:text-white">{valueNode}</p>
          {sub ? <p className="mt-0.5 text-[11px] font-bold text-slate-400 dark:text-slate-500">{sub}</p> : null}
        </>
      ) : (
        <>
          <div className="flex items-center gap-3">
            <IconTile icon={icon} c1={c1} c2={c2} size="lg" />
            <div className="min-w-0 flex-1">
              <p
                className={cn(
                  "truncate text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500",
                  lang ? labelTrack(effectiveLang) : "tracking-wider"
                )}
              >
                {label}
              </p>
              <p
                dir={ltrValue ? "ltr" : undefined}
                className={cn(
                  "mt-0.5 font-display text-3xl font-extrabold text-slate-900 dark:text-white",
                  isNumeric && "tabular-nums",
                  ltrValue && "text-start"
                )}
              >
                {valueNode}
              </p>
            </div>
          </div>
          {sub ? (
            <p className="mt-2.5 flex items-center gap-1.5 text-[11px] font-bold text-slate-400 dark:text-slate-500">
              <CatIcon name="trending-up" className="h-3 w-3 text-emerald-500" />
              {sub}
            </p>
          ) : null}
        </>
      )}
    </article>
  );
}
