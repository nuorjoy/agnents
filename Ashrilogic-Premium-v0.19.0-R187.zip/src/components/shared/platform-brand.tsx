"use client";

/**
 * Ashrilogic — platform brand consumers (identity completion).
 *
 * ROUND 87 shipped the identity console (logos / colors / fonts / radius /
 * favicon) and the document-level bridge (colors + favicon + radius). These
 * helpers close the remaining loop documented in the console's own copy:
 *
 *   idCardLogo     — «يظهر في ترويسة الموقع الرسمي وتذييله وواجهات المنصة»
 *   idCardLogoMini — «شريط جانبي للوحات التحكم والأماكن الضيقة»
 *
 * DESIGN CONTRACT (the visual lock):
 *   While the identity feed has NO logo (or is still loading / failed) every
 *   consumer below renders the SHIPPED markup — the gradient tile + Latin
 *   wordmark — byte-for-byte. The uploaded logo only ever APPEARS once the
 *   admin has actually set one, exactly like the color bridge only overrides
 *   --primary when primaryColor is set. No logo uploaded → zero visual drift.
 *
 *   Cross-fallback: a surface asking for «main» accepts the mini logo when
 *   only that one exists (and vice-versa) — a half-configured identity still
 *   brands every surface instead of showing a lone default tile.
 *
 * RENDERING RULES (house pattern, dashboard sidebar precedent):
 *   the logo lives in the tile's exact footprint on a white padded stage with
 *   a hairline border + the tile's shadow, `object-contain`, decorative
 *   (alt="" + aria-hidden) because the wordmark text sits right beside it.
 */

import type { ReactNode } from "react";
import { usePlatformIdentity } from "@/components/shared/identity-bridge";
import { cn } from "@/lib/utils";

/** The shipped Latin wordmark — also the feed's default siteNameEn. */
export const PLATFORM_WORDMARK = "Ashrilogic";

/** Resolves an identity logo for one of the two documented slots. */
export function usePlatformLogo(variant: "main" | "mini"): string | null {
  const { data } = usePlatformIdentity();
  const identity = data?.identity ?? null;
  if (!identity) return null;
  if (variant === "main") {
    return identity.logoUrl || identity.logoMiniUrl || null;
  }
  return identity.logoMiniUrl || identity.logoUrl || null;
}

/** The platform wordmark — `siteNameEn` when the feed renamed it, the shipped
 *  Latin mark otherwise (identical bytes for the default feed). */
export function usePlatformWordmark(): string {
  const { data } = usePlatformIdentity();
  return data?.siteNameEn || PLATFORM_WORDMARK;
}

/** The logo stage: the tile footprint with a white padded surface so both
 *  transparent and full-bleed logos read cleanly in light AND dark themes. */
const LOGO_STAGE =
  "grid shrink-0 place-items-center overflow-hidden border border-slate-200/80 bg-white shadow-lg dark:border-white/10 dark:bg-white/90";

/**
 * Drop-in brand tile. Renders the uploaded logo inside the tile's footprint,
 * or `fallback` — the EXACT shipped tile JSX — when no logo is configured
 * (feed loading, failed open, or simply never set). The consumer keeps its
 * own sizing classes via `className` so the footprint never shifts.
 */
export function PlatformBrandTile({
  variant,
  className,
  fallback,
}: {
  /** main logo slot vs the mini logo for tight spaces */
  variant: "main" | "mini";
  /** sizing/rounding classes for the logo stage (match the fallback tile) */
  className: string;
  /** the shipped gradient tile — rendered verbatim when no logo exists */
  fallback: ReactNode;
}) {
  const logo = usePlatformLogo(variant);
  if (!logo) return <>{fallback}</>;
  return (
    <span className={cn(LOGO_STAGE, className)} aria-hidden="true">
      {/* eslint-disable-next-line @next/next/no-img-element -- identity data-URL or managed /api/images ref (ROUND 87 console output); next/image optimization does not apply */}
      <img src={logo} alt="" className="h-full w-full object-contain p-1" />
    </span>
  );
}
