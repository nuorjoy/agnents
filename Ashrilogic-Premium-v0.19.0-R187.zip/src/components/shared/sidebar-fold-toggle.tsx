"use client";

/**
 * Ashrilogic — ROUND 164: the PREMIUM sidebar (طي / فتح) toggle.
 *
 * One shared control for BOTH rails (the workspace dashboard sidebar and the
 * Super Admin console sidebar). It replaces the old pin/unpin lock button
 * with a precise, professional fold/open affordance:
 *
 * • The button always shows the ACTION it will perform — «طي» (fold) while
 *   the rail is open/pinned, «فتح» (open) while it is folded/unpinned —
 *   in the label (when the rail is expanded) and in the aria-label/tooltip.
 * • The color encodes the SAME action with a buttery 500ms gradient
 *   crossfade: RED (rose → red) = the rail will fold, GREEN (emerald →
 *   teal) = the rail will open. No hard color jump is ever visible.
 * • The double-chevron icon morphs direction with the same eased timing:
 *   folding points INTO the rail (toward the start edge), opening points
 *   OUT into the content. Rotation classes keep this correct in both RTL
 *   (Arabic) and LTR locales.
 * • The pill reveals its label with a max-width + opacity transition, so
 *   the circle ⇄ pill morph animates smoothly alongside the rail's own
 *   w-16 ⇄ w-64 transition. When the rail is icon-only the toggle renders
 *   a compact circle with the full action in its tooltip + aria-label.
 *
 * The underlying behavior is unchanged and still persisted by
 * `useSidebarPin` (localStorage): pinned = committed full-width rail,
 * unpinned = icon rail that re-expands on hover. This control only gives
 * that existing law its precise, color-morphing premium affordance.
 */
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { cn } from "@/lib/utils";

export function SidebarFoldToggle({
  isPinned,
  onToggle,
  collapsed,
  className,
}: {
  /** committed rail state: pinned = full-width open rail, unpinned = icon rail */
  isPinned: boolean;
  onToggle: () => void;
  /** the rail is currently icon-only — render the compact circular variant */
  collapsed?: boolean;
  className?: string;
}) {
  const { t } = useT();
  /* the action the next click performs: a pinned (open) rail folds; an
   * unpinned (folded) rail opens. RED = fold · GREEN = open. */
  const folding = isPinned;

  return (
    <button
      type="button"
      onClick={onToggle}
      aria-pressed={isPinned}
      aria-label={folding ? t("sideFoldAria") : t("sideOpenAria")}
      title={folding ? t("sideFoldHint") : t("sideOpenHint")}
      className={cn(
        "relative isolate flex h-8 shrink-0 items-center overflow-hidden rounded-full text-white outline-none",
        "transition-[width,box-shadow,transform,filter] duration-500 ease-out",
        collapsed ? "w-8" : "w-auto px-3",
        "hover:brightness-110 active:scale-90 active:duration-150",
        "focus-visible:ring-2 focus-visible:ring-brand-400 focus-visible:ring-offset-2 focus-visible:ring-offset-white dark:focus-visible:ring-offset-ink-950",
        folding
          ? "shadow-[0_6px_18px_-6px_rgba(244,63,94,0.65)] hover:shadow-[0_8px_22px_-6px_rgba(244,63,94,0.75)]"
          : "shadow-[0_6px_18px_-6px_rgba(16,185,129,0.65)] hover:shadow-[0_8px_22px_-6px_rgba(16,185,129,0.75)]",
        className
      )}
    >
      {/* color-morph layers — the RED fold gradient and the GREEN open
          gradient crossfade in place; the gradient is never swapped cold. */}
      <span
        aria-hidden="true"
        className={cn(
          "absolute inset-0 -z-10 bg-linear-to-br from-rose-500 via-red-500 to-rose-600 transition-opacity duration-500 ease-out",
          folding ? "opacity-100" : "opacity-0"
        )}
      />
      <span
        aria-hidden="true"
        className={cn(
          "absolute inset-0 -z-10 bg-linear-to-br from-emerald-400 via-emerald-500 to-teal-600 transition-opacity duration-500 ease-out",
          folding ? "opacity-0" : "opacity-100"
        )}
      />
      {/* the premium gloss — a soft top sheen that survives both gradients */}
      <span
        aria-hidden="true"
        className="absolute inset-x-0 top-0 -z-10 h-1/2 bg-linear-to-b from-white/20 to-transparent"
      />

      <span className={cn("flex h-full items-center", collapsed ? "w-full justify-center" : "gap-1.5")}>
        <CatIcon
          name="chevrons-right"
          className={cn(
            "h-[13px] w-[13px] shrink-0 transition-transform duration-500 ease-out",
            /* fold: the chevrons point INTO the rail (toward the start
             * edge — left in LTR, right in RTL); open: they point OUT into
             * the content (end edge). */
            folding ? "ltr:rotate-180 rtl:rotate-0" : "ltr:rotate-0 rtl:rotate-180"
          )}
        />
        {/* the action label — reveals with a max-width + opacity transition
            so the circle ⇄ pill morph animates in sync with the rail. */}
        <span
          className={cn(
            "overflow-hidden whitespace-nowrap text-[10px] font-extrabold leading-none tracking-wide transition-all duration-300 ease-out",
            collapsed ? "max-w-0 opacity-0" : "max-w-24 opacity-100"
          )}
        >
          {folding ? t("sideFoldLabel") : t("sideOpenLabel")}
        </span>
      </span>
    </button>
  );
}
