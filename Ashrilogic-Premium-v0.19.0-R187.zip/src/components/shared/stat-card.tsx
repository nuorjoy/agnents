"use client";

/**
 * Ashrilogic — بطاقة الإحصائيات الموحدة (THE unified stat card) — ROUND 136.
 *
 * ONE component unifies every KPI/stat card idiom that had accumulated
 * across the workspace + module surfaces:
 *
 *  · size="golden" — byte-faithful to the business-suite KPI strip the
 *    owner loves (نقاط البيع / المنتجات / كل الوحدات): compact glass card,
 *    corner radial aura, inline label icon, 17px tabular value, tone-
 *    colored hover underline (emerald up / rose down).
 *  · size="lg"     — the tall premium card (customers / team / trash /
 *    activity / overview / inventory): gradient top hairline, gradient
 *    IconTile, 3xl display value, optional delta chip + sparkline slot +
 *    chip slot + loading skeleton.
 *  · size="sm"     — the compact stat (analytics): small IconTile inline
 *    with the label, 1xl value.
 *
 * Cross-cutting features (union of ALL prior local copies):
 *  · `numeric`  → animated count-up (useCountUp, reduced-motion safe)
 *  · `tone`     → bottom hover accent line
 *  · `delta`    → emerald/rose percentage chip
 *  · `spark`    → sparkline node slot (dir-locked ltr)
 *  · `chip`     → inline chip row under the value
 *  · `loading`  → skeleton shimmer for the value
 *  · `onClick`  → drill-down: the card becomes a real <button>
 *  · `ltrValue` → force dir="ltr" (phone-number-like values)
 *
 * Numeral policy (R135 decision #3, preserved): stats/money render with
 * `numDir(lang)` + `tabular-nums` (Arabic-Indic RTL numerals for ar);
 * pure IDs always render Western through the caller's fmtId/idDir.
 */
import type { ReactNode } from "react";
import { CatIcon } from "@/components/icon";
import { IconTile } from "@/components/dashboard/dash-shared";
import { useCountUp } from "@/hooks/use-count-up";
import { useT } from "@/lib/i18n";
import type { Lang } from "@/lib/types";
import { cn, fmtNum, grad, hexAlpha, labelTrack, numDir } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";

export type StatTone = "up" | "down" | "flat";
export type StatSize = "golden" | "lg" | "sm";

export interface StatCardProps {
  label: string;
  /** pre-rendered value (string / ReactNode) */
  value?: ReactNode;
  /** numeric value — renders with the count-up animation + tabular-nums */
  numeric?: number;
  /** secondary line under the value */
  sub?: ReactNode;
  icon: string;
  c1: string;
  c2: string;
  index?: number;
  lang?: Lang;
  size?: StatSize;
  /** bottom hover accent line (emerald for up, rose for down) */
  tone?: StatTone;
  /** percentage chip (emerald ≥0 / rose <0) — lg & sm sizes */
  delta?: number;
  /** custom node rendered in place of the computed delta chip */
  deltaChip?: ReactNode;
  /** inline chip row under the value (trash-view pattern) */
  chip?: ReactNode;
  /** sparkline node slot (overview pattern) — lg size */
  spark?: ReactNode;
  /** skeleton shimmer over the value while data loads */
  loading?: boolean;
  /** label-valued KPI: renders text-xl + line-clamp-2 instead of 3xl */
  small?: boolean;
  /** hover gradient sweep on the top edge (admin-sites pattern) */
  accent?: boolean;
  /** render the value inside dir="ltr" (phones, latin currency strings) */
  ltrValue?: boolean;
  /** when set the card becomes a button (drill-down) */
  onClick?: () => void;
  /** accessible hint (button title) */
  hint?: string;
  /** count-up duration for numeric values (ms) */
  duration?: number;
  className?: string;
  "aria-label"?: string;
}

const TONE_LINE: Record<StatTone, string> = {
  up: "bg-emerald-500",
  down: "bg-rose-500",
  flat: "bg-transparent",
};

export function StatCard({
  label,
  value,
  numeric,
  sub,
  icon,
  c1,
  c2,
  index = 0,
  lang,
  size = "lg",
  tone,
  delta,
  deltaChip,
  chip,
  spark,
  loading = false,
  small = false,
  accent = false,
  ltrValue = false,
  onClick,
  hint,
  duration = 1100,
  className,
  "aria-label": ariaLabel,
}: StatCardProps) {
  const { lang: ctxLang } = useT();
  const effectiveLang = lang ?? ctxLang;
  const { ref: countRef, value: anim } = useCountUp(numeric ?? 0, duration);
  const isNumeric = numeric !== undefined;

  const valueDir = ltrValue ? "ltr" : numDir(effectiveLang);
  const valueNode = isNumeric ? <span ref={countRef}>{fmtNum(anim, effectiveLang)}</span> : value;

  /* ---------- shared chrome ---------- */
  const toneLine = tone ? (
    <span
      className={cn(
        "absolute bottom-0 inset-x-0 h-0.5 origin-start scale-x-0 transition-transform duration-500 group-hover:scale-x-100",
        TONE_LINE[tone],
      )}
      aria-hidden="true"
    />
  ) : null;

  const shell = cn(
    "glass-card card-in group relative overflow-hidden",
    size === "golden" ? "rounded-2xl p-3.5" : size === "sm" ? "rounded-2xl p-4" : "rounded-3xl p-4 transition-shadow duration-300 hover:shadow-lift sm:p-5",
    onClick && "cursor-pointer text-start transition active:scale-[0.99] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500/60",
    className,
  );

  const body =
    size === "golden" ? (
      <>
        {/* corner radial aura — the golden signature */}
        <span
          className="pointer-events-none absolute -end-10 -top-10 h-24 w-24 rounded-full opacity-60"
          style={{ background: `radial-gradient(circle, ${hexAlpha(c1, 0.22)}, transparent 70%)` }}
          aria-hidden="true"
        />
        <p
          className={cn(
            "flex items-center gap-1.5 text-[10.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500",
            labelTrack(effectiveLang),
          )}
        >
          <CatIcon name={icon} className="h-3.5 w-3.5 shrink-0 text-slate-400" />
          {label}
        </p>
        {loading ? (
          <Skeleton className="mt-2 h-5 w-20" />
        ) : (
          <p
            dir={valueDir}
            className={cn("mt-1.5 truncate font-display text-[17px] font-extrabold text-slate-900 dark:text-white", isNumeric && "tabular-nums")}
          >
            {valueNode}
          </p>
        )}
        {sub && !loading ? (
          <p className="mt-0.5 truncate text-[10.5px] font-bold text-slate-400 dark:text-slate-500" dir="auto">
            {sub}
          </p>
        ) : null}
        {chip && !loading ? <div className="mt-1">{chip}</div> : null}
        {toneLine}
      </>
    ) : size === "sm" ? (
      <>
        {accent ? (
          <span
            className="absolute inset-x-0 top-0 h-1 origin-center scale-x-0 transition-transform duration-300 group-hover:scale-x-100"
            style={{ backgroundImage: grad(c1, c2, 90) }}
            aria-hidden="true"
          />
        ) : null}
        <div className="flex items-center gap-3">
          <IconTile icon={icon} c1={c1} c2={c2} size="sm" />
          <p className={cn("min-w-0 flex-1 truncate text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(effectiveLang))}>
            {label}
          </p>
        </div>
        {loading ? (
          <Skeleton className="mt-2.5 h-6 w-16" />
        ) : (
          <p dir={valueDir} className={cn("mt-2 font-display text-xl font-extrabold text-slate-900 dark:text-white", isNumeric && "tabular-nums")}>
            {valueNode}
          </p>
        )}
        {renderDelta()}
        {sub && !loading ? <p className="mt-0.5 text-[11px] font-bold text-slate-400 dark:text-slate-500">{sub}</p> : null}
        {chip && !loading ? <div className="mt-1">{chip}</div> : null}
        {toneLine}
      </>
    ) : (
      <>
        {/* gradient top hairline — brightens on hover */}
        <span
          className="pointer-events-none absolute inset-x-0 top-0 h-[2px] opacity-50 transition-opacity duration-300 group-hover:opacity-100"
          style={{ backgroundImage: grad(c1, c2, 90) }}
          aria-hidden="true"
        />
        {accent ? (
          <span
            className="pointer-events-none absolute inset-x-0 top-0 h-1 origin-center scale-x-0 transition-transform duration-300 group-hover:scale-x-100"
            style={{ backgroundImage: grad(c1, c2, 90) }}
            aria-hidden="true"
          />
        ) : null}
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className={cn("truncate text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(effectiveLang))}>{label}</p>
            {loading ? (
              <Skeleton className="mt-2.5 h-8 w-16" />
            ) : (
              <p
                dir={valueDir}
                className={cn(
                  "mt-1.5 text-start font-display font-extrabold text-slate-900 dark:text-white",
                  small ? "line-clamp-2 text-xl leading-snug" : isNumeric ? "text-3xl tabular-nums" : "text-3xl",
                )}
              >
                {valueNode}
              </p>
            )}
            {deltaChip && !loading ? <div className="mt-2">{deltaChip}</div> : null}
            {!deltaChip ? renderDelta() : null}
            {chip && !loading ? chip : null}
            {sub && !loading ? (
              <p className="mt-2 truncate text-[10.5px] font-bold leading-relaxed text-slate-400 dark:text-slate-500">{sub}</p>
            ) : null}
          </div>
          <IconTile icon={icon} c1={c1} c2={c2} size="lg" />
        </div>
        {spark && !loading ? (
          <div dir="ltr" className="mt-2 h-9 w-full">
            {spark}
          </div>
        ) : null}
        {toneLine}
      </>
    );

  function renderDelta() {
    if (loading || delta === undefined) return null;
    const up = delta >= 0;
    const deltaChipNode = (
      <span
        className={cn(
          "mt-2 inline-flex cursor-default items-center gap-1 rounded-full px-2 py-0.5 text-[10.5px] font-extrabold transition-transform duration-200 hover:scale-105 active:scale-95",
          up
            ? "bg-emerald-50 text-emerald-600 hover:shadow-md hover:shadow-emerald-500/20 dark:bg-emerald-500/10 dark:text-emerald-400"
            : "bg-rose-50 text-rose-600 hover:shadow-md hover:shadow-rose-500/20 dark:bg-rose-500/10 dark:text-rose-400",
        )}
      >
        <CatIcon name={up ? "trending-up" : "trending-down"} className="h-[10px] w-[10px]" />
        <span dir={valueDir}>
          {up ? "+" : ""}
          {fmtNum(Number(delta.toFixed(1)), effectiveLang)}%
        </span>
      </span>
    );
    return <div className="mt-0.5">{deltaChipNode}</div>;
  }

  const style = { "--i": index } as React.CSSProperties;

  if (onClick) {
    return (
      <button type="button" onClick={onClick} title={hint} aria-label={ariaLabel ?? label} className={shell} style={style}>
        {body}
      </button>
    );
  }
  return (
    <article aria-label={ariaLabel ?? label} className={shell} style={style}>
      {body}
    </article>
  );
}
