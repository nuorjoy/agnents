"use client";

/**
 * Ashrilogic — ROUND 82 (batch-5 ⑤): the REBUILT system-owner sign-in page.
 *
 * The old split-panel login was deleted and replaced by a luxurious,
 * animation-first experience:
 *
 *  - an aurora canvas: three slowly-drifting radial glows (brand · fuchsia ·
 *    cyan) + a fine grid veil, rendered behind everything,
 *  - a floating showcase column (desktop): the logo medallion with its
 *    breathing pulse ring, gradient headline, live clock, animated stat
 *    tiles and floating category glass-chips that bob on independent
 *    springs,
 *  - a glass credential card with a gradient hairline, staggered entrance,
 *    icon inputs with focus glow, a shimmer-sweep submit and the premium
 *    passkey medallion (the secure sign-in card),
 *  - the FULL feature set preserved verbatim: email-first server-side
 *    workspace resolution (no enumeration), TOTP/backup MFA challenge,
 *    MFA passkey completion, passkey-first usernameless sign-in, the
 *    forgot-password ticket flow with its reference id, AR/EN/HI with RTL,
 *    light/dark, and the same landing contract (success → «أنظمتك المنشأة»
 *    with the workspace highlighted).
 *
 * ROUND 83 — the page is now GENUINELY THEME-AWARE: the old build hardcoded
 * the dark palette (a local `dark` class froze every color), so the header
 * theme toggle changed nothing visually. All surfaces now draw from the
 * .login-scope design tokens (globals.css) which carry a light aurora palette
 * and the original dark one — the toggle flips the whole experience, while
 * the orbs / gradient CTAs keep the brand identity in both themes. Also:
 * double-submit guards on the forms and the desktop-hidden brand link no
 * longer traps keyboard focus (lg:hidden instead of lg:invisible).
 */
import { createContext, useContext, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMutation } from "@tanstack/react-query";
import { useDocumentTitle } from "@/hooks/use-document-title";
import { motion, useReducedMotion, type Variants } from "framer-motion";
import { useTheme } from "next-themes";
import { toast } from "sonner";
import type { InstanceDTO } from "@/lib/types";
import { useT } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import {
  ApiError,
  instanceLoginByEmail,
  instanceMfaLogin,
  instancePasskeyLogin,
  submitPublicTicket,
  type InstanceMfaChallenge,
} from "@/lib/api-client";
import { PasskeyLoginBlock } from "@/components/auth/passkey-login-block";
import { CrossDevicePasskeyDialog } from "@/components/auth/cross-device-passkey-dialog";
import { CrossDeviceCompleteCard } from "@/components/auth/cross-device-complete-card";
import { CatIcon } from "@/components/icon";
import { LangMenu } from "@/components/lang-menu";
import { PlatformBrandTile } from "@/components/shared/platform-brand";
import { cn, grad } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PremiumEmailInput } from "@/components/ui/premium-contact";
import { OtpInput, normalizeDigits } from "@/components/security/security-cards";
import { Label } from "@/components/ui/label";
import { LiveClock } from "@/components/ui/live-clock";
import { EMAIL_RE } from "@/lib/validation";

import "@/lib/i18n/fragments/app";
type Mode = "signin" | "forgot" | "sent";

/* -------------------------------------------------- motion language ---- */

const stagger: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.07, delayChildren: 0.05 } },
};

const rise: Variants = {
  hidden: { opacity: 0, y: 18, filter: "blur(6px)" },
  show: {
    opacity: 1,
    y: 0,
    filter: "blur(0px)",
    transition: { duration: 0.55, ease: [0.22, 1, 0.36, 1] },
  },
};

const pop: Variants = {
  hidden: { opacity: 0, scale: 0.85 },
  show: { opacity: 1, scale: 1, transition: { type: "spring", stiffness: 260, damping: 22 } },
};

/* -------------------------------------------------- motion budget -------
 *
 * ROUND 168 — the login canvas carried ~18 INFINITE framer loops (4 aurora
 * orbs at blur-3xl, chip bobbing, pulse rings, rotating stat icons, the
 * shimmer sweep) + a 1s LiveClock interval. On low-memory Android that is
 * a GPU/memory furnace; a native autofill/save-password dialog toggling
 * focus+visibility on top of it was enough to kill Chrome's renderer (the
 * owner's white "Can't open this page" report = the tab's renderer died,
 * auto-reloaded, died again).
 *
 * The budget law (consumed by every loop below through context):
 *  - `reduced` — prefers-reduced-motion: every decorative infinite loop is
 *    skipped entirely (elements unmount) and entrances render instantly;
 *    a CSS net in globals.css additionally forces the entrance-hidden SSR
 *    markup visible, so the form survives even a JS crash.
 *  - `visible` — document visibilitychange: hidden tabs stop every loop
 *    (a static settle or unmount — zero rAF/GPU work while backgrounded).
 *  - `desktop` — lg+ viewport: the showcase column is display:none on
 *    mobile, so its loops never spin there; the aurora renders a 2-orb
 *    blur-2xl diet instead of the 4-orb blur-3xl desktop canvas.
 *
 * HYDRATION LAW: the first render (server + client hydration) carries the
 * DEFAULT budget (nothing reduced, visible, desktop) — framer's
 * useReducedMotion reads matchMedia synchronously during the first client
 * render, so it is masked behind a mounted flag; the real values apply
 * AFTER mount as an ordinary re-render. The SSR HTML and the hydration
 * tree are therefore byte-identical (no structural mismatch).
 * --------------------------------------------------------------------- */

interface MotionBudget {
  reduced: boolean;
  visible: boolean;
  desktop: boolean;
}

const MotionBudgetContext = createContext<MotionBudget>({
  reduced: false,
  visible: true,
  desktop: true,
});

function useMotionBudget(): MotionBudget {
  const [mounted, setMounted] = useState(false);
  const [docVisible, setDocVisible] = useState(true);
  const [desktop, setDesktop] = useState(true);
  const prefersReduced = useReducedMotion() ?? false;

  useEffect(() => {
    /* the real budget applies AFTER hydration: the first render (server and
       client) carries the default budget so the two trees match — framer's
       useReducedMotion reads matchMedia synchronously during the first
       client render, so the mounted flag defers it to an ordinary
       post-hydration update (the HeaderControls sync() idiom). */
    const markMounted = () => setMounted(true);
    markMounted();
    const onVisibility = () => setDocVisible(document.visibilityState === "visible");
    document.addEventListener("visibilitychange", onVisibility);
    /* Tailwind's lg breakpoint (64rem) decides the aurora diet + whether
       the display:none showcase column is allowed to spin its loops. */
    const mq = window.matchMedia("(min-width: 1024px)");
    const syncViewport = () => setDesktop(mq.matches);
    syncViewport();
    mq.addEventListener("change", syncViewport);
    return () => {
      document.removeEventListener("visibilitychange", onVisibility);
      mq.removeEventListener("change", syncViewport);
    };
  }, []);

  return {
    reduced: mounted && prefersReduced,
    visible: docVisible,
    desktop,
  };
}

/* one drifting aurora glow — `diet` swaps blur-3xl for the cheaper
   blur-2xl on <lg viewports; when the budget is spent the loop settles
   to its rest pose (a one-shot tween, never an infinite one) */
function AuroraOrb({
  className,
  color,
  duration = 26,
  drift = 60,
  diet = false,
}: {
  className?: string;
  color: string;
  duration?: number;
  drift?: number;
  diet?: boolean;
}) {
  const { reduced, visible } = useContext(MotionBudgetContext);
  const looping = !reduced && visible;
  return (
    <motion.span
      aria-hidden="true"
      className={`pointer-events-none absolute rounded-full ${diet ? "blur-2xl" : "blur-3xl"} ${className ?? ""}`}
      style={{ background: `radial-gradient(circle, ${color}, transparent 70%)` }}
      animate={
        looping
          ? { x: [0, drift, -drift / 2, 0], y: [0, -drift / 2, drift / 3, 0], scale: [1, 1.12, 0.94, 1] }
          : { x: 0, y: 0, scale: 1 }
      }
      transition={
        looping
          ? { duration, repeat: Infinity, ease: "easeInOut" }
          : { duration: 0.4, ease: "easeOut" }
      }
    />
  );
}

/* floating category glass-chip (showcase column) — the bobbing inner span
   spins ONLY while the budget allows it (not reduced, document visible,
   desktop: the column is display:none on mobile, so its loops must not
   tick there either); without budget it settles flat (no infinite loop) */
function FloatChip({
  icon,
  c1,
  c2,
  label,
  delay,
}: {
  icon: string;
  c1: string;
  c2: string;
  label: string;
  delay: number;
}) {
  const { reduced, visible, desktop } = useContext(MotionBudgetContext);
  const bobbing = !reduced && visible && desktop;
  return (
    <motion.span
      aria-hidden="true"
      className="inline-flex items-center gap-2 rounded-2xl border border-[var(--lg-line)] bg-[var(--lg-chip)] px-3.5 py-2 backdrop-blur-md"
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={
        reduced
          ? { duration: 0 }
          : { delay, type: "spring", stiffness: 180, damping: 18 }
      }
    >
      <motion.span
        animate={bobbing ? { y: [0, -4, 0] } : { y: 0 }}
        transition={
          bobbing
            ? { duration: 3.2, repeat: Infinity, ease: "easeInOut", delay }
            : { duration: 0.3, ease: "easeOut" }
        }
        className="flex items-center gap-2"
      >
        <span
          className="grid h-6 w-6 place-items-center rounded-lg text-white"
          style={{ backgroundImage: grad(c1, c2) }}
        >
          <CatIcon name={icon} className="h-[11px] w-[11px]" />
        </span>
        <span className="text-[11px] font-bold text-[var(--lg-muted)]">{label}</span>
      </motion.span>
    </motion.span>
  );
}

/* the shimmer sweep on the submit button — the sweeping bar itself
   UNMOUNTS when the budget is spent (reduced motion / hidden document):
   zero compositor work, and a clean `initial` restart when it returns */
function ShimmerSweep() {
  const { reduced, visible } = useContext(MotionBudgetContext);
  const sweeping = !reduced && visible;
  return (
    <motion.span
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 overflow-hidden rounded-[inherit]"
    >
      {sweeping ? (
        <motion.span
          className="absolute top-0 h-full w-1/3 bg-white/25 blur-md"
          initial={{ x: "-150%", skewX: -18 }}
          animate={{ x: "320%" }}
          transition={{ duration: 1.4, repeat: Infinity, repeatDelay: 2.6, ease: "easeInOut" }}
          style={{ rotate: "0deg" }}
        />
      ) : null}
    </motion.span>
  );
}

/* -------------------------------------------------- controls ---------- */

function HeaderControls() {
  const { t } = useT();
  const { setTheme } = useTheme();
  /* ROUND 83 — the toggle now actually flips the page: the login scope
     follows the global theme (class strategy). The sun/moon ICONS are
     CSS-driven (dark:/light: visibility) because `resolvedTheme` is
     undefined during SSR — deriving DOM output from it (an icon pick or
     aria-pressed) makes the server HTML differ from the first client
     render = a React hydration error. CSS icons paint correctly the
     instant next-themes stamps <html class> and never mismatch; the
     pressed state tracks the SAME class reactively (the sonner.tsx
     MutationObserver idiom) instead of derived-from-undefined state. */
  const [htmlDark, setHtmlDark] = useState(false);
  useEffect(() => {
    const root = document.documentElement;
    const sync = () => setHtmlDark(root.classList.contains("dark"));
    sync();
    const observer = new MutationObserver(sync);
    observer.observe(root, { attributes: true, attributeFilter: ["class"] });
    return () => observer.disconnect();
  }, []);
  return (
    <div className="flex items-center gap-1.5">
      <LangMenu />
      <button
        type="button"
        aria-label={t("ariaTheme")}
        title={t("ariaTheme")}
        aria-pressed={htmlDark}
        onClick={() => setTheme(htmlDark ? "light" : "dark")}
        className="grid h-10 w-10 place-items-center rounded-xl border border-[var(--lg-line)] bg-[var(--lg-chip)] text-[var(--lg-faint)] backdrop-blur-md transition hover:border-brand-400/60 hover:text-[var(--lg-fg)] active:scale-95"
      >
        <CatIcon name="sun" className="hidden h-[15px] w-[15px] dark:block" />
        <CatIcon name="moon" className="block h-[15px] w-[15px] dark:hidden" />
      </button>
    </div>
  );
}

/* -------------------------------------------------- showcase column -- */

function ShowcaseColumn() {
  const { t } = useT();
  /* ROUND 168 — the showcase column's decorative loops (medallion pulse
     ring, rotating stat icons, the chips' bobbing inside FloatChip) run
     ONLY while the motion budget allows it: this whole column is
     display:none below lg, so its loops must never tick on mobile. */
  const { reduced, visible, desktop } = useContext(MotionBudgetContext);
  const looping = !reduced && visible && desktop;
  const stats = [
    { value: "١٠٠", label: t("loginStatSystems"), icon: "boxes", c1: "#6d5dfb", c2: "#d946ef" },
    { value: "١٥", label: t("loginStatCats"), icon: "chart-pie", c1: "#0ea5e9", c2: "#22d3ee" },
    { value: "١١", label: t("loginStatLangs"), icon: "languages", c1: "#f59e0b", c2: "#f97316" },
  ];
  const chips = [
    { icon: "heart-pulse", c1: "#f43f5e", c2: "#be185d", label: t("loginChipHealth") },
    { icon: "graduation-cap", c1: "#6366f1", c2: "#7c3aed", label: t("loginChipEdu") },
    { icon: "store", c1: "#f59e0b", c2: "#ea580c", label: t("loginChipRetail") },
    { icon: "utensils", c1: "#ef4444", c2: "#b91c1c", label: t("loginChipFood") },
  ];

  return (
    <aside
      className="relative hidden w-[46%] flex-col justify-between overflow-hidden p-10 lg:flex xl:p-14"
      aria-hidden="true"
    >
      {/* brand */}
      <motion.div
        variants={stagger}
        initial="hidden"
        animate="show"
        className="relative flex items-center gap-3"
      >
        <motion.span
          variants={pop}
          className="relative grid h-12 w-12 place-items-center rounded-2xl bg-linear-to-br from-brand-500 via-fuchsia-500 to-cyan-400 text-white shadow-xl shadow-brand-500/40"
        >
          <CatIcon name="boxes" className="h-[17px] w-[17px]" />
          {looping ? (
            <motion.span
              className="absolute inset-0 rounded-2xl border border-white/40"
              animate={{ scale: [1, 1.28, 1], opacity: [0.6, 0, 0.6] }}
              transition={{ duration: 3.4, repeat: Infinity, ease: "easeInOut" }}
            />
          ) : null}
        </motion.span>
        <motion.div variants={rise} className="leading-none">
          <span className="block font-display text-[20px] font-extrabold tracking-tight text-[var(--lg-fg)]">
            Ashrilogic
          </span>
          <span className="mt-1 block text-[10.5px] font-semibold tracking-wide text-[var(--lg-faint)]">
            {t("brandTagline")}
          </span>
        </motion.div>
      </motion.div>

      {/* story */}
      <motion.div variants={stagger} initial="hidden" animate="show" className="relative max-w-xl">
        <motion.h2
          variants={rise}
          className="font-display text-[36px] font-extrabold leading-[1.12] text-[var(--lg-fg)] xl:text-[44px]"
        >
          {t("loginPageWelcome")}
          <span className="mt-2 block bg-linear-to-l from-[var(--lg-fg-grad-from)] via-[var(--lg-fg-grad-via)] to-[var(--lg-fg-grad-to)] bg-clip-text text-transparent">
            {t("loginVisualTitle")}
          </span>
        </motion.h2>

        <motion.p
          variants={rise}
          className="mt-5 max-w-[42ch] text-[13.5px] font-semibold leading-relaxed text-[var(--lg-muted)]"
        >
          {t("loginVisualDesc")}
        </motion.p>

        {/* floating category chips */}
        <div className="mt-7 flex flex-wrap gap-2.5">
          {chips.map((c, i) => (
            <FloatChip key={c.icon} icon={c.icon} c1={c.c1} c2={c.c2} label={c.label} delay={0.5 + i * 0.14} />
          ))}
        </div>

        <motion.div variants={rise} className="mt-7 inline-flex">
          <LiveClock variant="chip" c1="#6d5dfb" c2="#d946ef" className="scale-95" />
        </motion.div>
      </motion.div>

      {/* stats + quote */}
      <motion.div variants={stagger} initial="hidden" animate="show" className="relative space-y-4">
        <div className="grid grid-cols-3 gap-3">
          {stats.map((s, i) => (
            <motion.div
              key={s.label}
              variants={rise}
              whileHover={{ y: -4 }}
              className="rounded-2xl border border-[var(--lg-line)] bg-[var(--lg-chip)] p-3.5 backdrop-blur-md"
            >
              <motion.span
                className="grid h-7 w-7 place-items-center rounded-lg text-white"
                style={{ backgroundImage: `linear-gradient(135deg, ${s.c1}, ${s.c2})` }}
                animate={looping ? { rotate: [0, 2, -2, 0] } : { rotate: 0 }}
                transition={
                  looping
                    ? { duration: 5, repeat: Infinity, delay: i * 0.7 }
                    : { duration: 0.3, ease: "easeOut" }
                }
              >
                <CatIcon name={s.icon} className="h-[11px] w-[11px]" />
              </motion.span>
              <p className="mt-2.5 font-display text-[22px] font-extrabold tabular-nums text-[var(--lg-fg)]">
                {s.value}
              </p>
              <p className="mt-0.5 text-[10px] font-bold text-[var(--lg-faint)]">{s.label}</p>
            </motion.div>
          ))}
        </div>

        <motion.figure
          variants={rise}
          className="rounded-2xl border border-[var(--lg-line)] bg-[var(--lg-chip)] p-4 backdrop-blur-md"
        >
          <CatIcon name="quote" className="h-4 w-4 text-brand-500/70 dark:text-brand-300/70" />
          <blockquote className="mt-2 text-[12.5px] font-semibold leading-relaxed text-[var(--lg-muted)]">
            {t("loginPageWelcomeSub")}
          </blockquote>
          <figcaption className="mt-2.5 flex items-center gap-2 text-[10.5px] font-bold text-[var(--lg-faint)]">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
            Ashrilogic — {t("selectSessionChip")}
          </figcaption>
        </motion.figure>
      </motion.div>
    </aside>
  );
}

/* -------------------------------------------------- the page ---------- */

export function LoginPageView() {
  const { t, lang } = useT();
  useDocumentTitle("docTitleLogin");
  const router = useRouter();
  const setView = useAppStore((s) => s.setView);
  const setCurrentInstance = useAppStore((s) => s.setCurrentInstance);
  const setSelectHighlightId = useAppStore((s) => s.setSelectHighlightId);
  const setSelectOwnerEmail = useAppStore((s) => s.setSelectOwnerEmail);

  const [mode, setMode] = useState<Mode>("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [visible, setVisible] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [shake, setShake] = useState(0);
  /* ROUND 168 — the page-wide motion budget (reduced-motion / document
   * visibility / lg viewport): every infinite loop below consumes it. */
  const motionBudget = useMotionBudget();
  const cardLooping = motionBudget.visible && !motionBudget.reduced;
  /* ROUND 87 (owner self-disable) — the workspace answered WORKSPACE_DISABLED:
   * a dedicated reactivate panel replaces the plain error (the password is
   * kept typed so re-activation is ONE deliberate click). */
  const [disabledInfo, setDisabledInfo] = useState<{ at: string; reason: string | null } | null>(null);
  const [sentId, setSentId] = useState<string | null>(null);
  const emailRef = useRef<HTMLInputElement>(null);

  /* ROUND 45 — workspace two-factor challenge state (password verified,
   * session withheld until the code / passkey verifies) */
  const [mfa, setMfa] = useState<InstanceMfaChallenge | null>(null);
  const [mfaCode, setMfaCode] = useState("");
  /* ROUND 46 — backup-code mode for the challenge + 6-digit validity */
  const [backupMode, setBackupMode] = useState(false);

  /* ROUND 117 — cross-device passkey login: the desktop dialog (QR) + the
   * phone completion card (?cd=<token> opened from the QR scan). */
  const [crossOpen, setCrossOpen] = useState(false);
  const [phoneCd, setPhoneCd] = useState<string | null>(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const cd = params.get("cd");
    /* eslint-disable-next-line react-hooks/set-state-in-effect --
       ROUND 117: one-shot URL truth at mount — the QR hands ?cd=<token>
       to this page. The state flips ONCE (null → token) and never again,
       so the cascading-render hazard this rule guards against cannot
       occur; deriving in render instead would mismatch SSR hydration. */
    if (cd && /^[A-Za-z0-9_-]{43}$/.test(cd)) setPhoneCd(cd);
  }, []);

  /* ROUND 46 — backup-code mode for the challenge + 6-digit validity */
  const codeValid = backupMode
    ? mfaCode.trim().length >= 4
    : normalizeDigits(mfaCode).replace(/\D/g, "").length === 6;

  /* focus the first control when the mode flips (also on mount) */
  useEffect(() => {
    if (mode === "sent") return;
    emailRef.current?.focus();
  }, [mode]);

  /* shared success contract: land on «أنظمتك المنشأة» */
  const landOnSelect = (instance: InstanceDTO) => {
    toast.success(t("gateWelcomeToast"));
    setSelectOwnerEmail(instance.admin.email || null);
    setSelectHighlightId(instance.id);
    setCurrentInstance(instance.id);
    setView("select");
    router.push("/");
  };

  /* ------------------------------------------------------------------ */
  /* sign-in: single server-side call — the API resolves the workspace   */
  /* by email (blind index), verifies the password and opens the session */
  /* ------------------------------------------------------------------ */
  const login = useMutation({
    mutationFn: async () => {
      return instanceLoginByEmail({ email: email.trim(), password });
    },
    onSuccess: (result) => {
      if ("mfaRequired" in result) {
        /* password OK — the workspace's second factor is required */
        setMfa(result);
        setMfaCode("");
        setError(null);
        return;
      }
      const { owned } = result;
      landOnSelect(result.instance);
      if (owned > 1) {
        /* several workspaces share this email — point it out gently */
        toast.info(t("loginMultiOwned", { count: owned }));
      }
    },
    onError: (e: Error) => {
      if (e instanceof ApiError && e.code === "WORKSPACE_DISABLED") {
        /* ROUND 87 — paused workspace: keep the typed password and surface
           the reactivate panel (reason + timestamp + one-click proof). */
        setError(null);
        setDisabledInfo({
          at: new Date().toISOString(),
          reason: null,
        });
        return;
      }
      const msg =
        e instanceof ApiError && e.status === 401
          ? t("loginErrBadCreds")
          : e.message || t("errorText");
      setError(msg);
      setShake((s) => s + 1);
      setPassword("");
    },
  });

  /* ROUND 87 — re-activation: the same login call with reactivate: true;
   * the route verified the password, cleared the pause and audited
   * instance.selfEnable before minting the session. */
  const reactivate = useMutation({
    mutationFn: async () => {
      return instanceLoginByEmail({ email: email.trim(), password, reactivate: true });
    },
    onSuccess: (result) => {
      if ("mfaRequired" in result) {
        setMfa(result);
        setMfaCode("");
        setDisabledInfo(null);
        return;
      }
      setDisabledInfo(null);
      const { owned } = result;
      landOnSelect(result.instance);
      if (owned > 1) {
        toast.info(t("loginMultiOwned", { count: owned }));
      }
      toast.success(t("reactivateSuccessToast"));
    },
    onError: (e: Error) => {
      const msg =
        e instanceof ApiError && e.status === 401
          ? t("loginErrBadCreds")
          : e.message || t("errorText");
      setError(msg);
      setShake((s) => s + 1);
      setPassword("");
      setDisabledInfo(null);
    },
  });

  /* ROUND 45 — finish the workspace login with the TOTP / backup code */
  const mfaVerify = useMutation({
    mutationFn: () => instanceMfaLogin(mfa!.ticket, mfaCode.trim()),
    onSuccess: ({ instance }) => landOnSelect(instance),
    onError: (e: Error) => {
      const msg = e instanceof ApiError && e.status === 401 ? t("mfaBadCode") : e.message || t("errorText");
      setError(msg);
      setShake((s) => s + 1);
    },
  });

  /* ROUND 45 — finish with the workspace passkey (browser ceremony) */
  const mfaPasskey = useMutation({
    mutationFn: async () => {
      const { startAuthentication } = await import("@simplewebauthn/browser");
      const startRes = await fetch(
        `/api/instances/${encodeURIComponent(mfa!.instanceId)}/auth/passkey`,
        {
          method: "POST",
          credentials: "same-origin",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ step: "start", ticket: mfa!.ticket }),
        }
      );
      if (!startRes.ok) {
        const data = (await startRes.json().catch(() => ({}))) as { error?: string };
        throw new Error(data.error ?? "Passkey sign-in failed");
      }
      const { options } = (await startRes.json()) as {
        options: Parameters<typeof startAuthentication>[0]["optionsJSON"];
      };
      const assertion = await startAuthentication({ optionsJSON: options });
      const finishRes = await fetch(
        `/api/instances/${encodeURIComponent(mfa!.instanceId)}/auth/passkey`,
        {
          method: "POST",
          credentials: "same-origin",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ step: "finish", ticket: mfa!.ticket, response: assertion }),
        }
      );
      if (!finishRes.ok) {
        const data = (await finishRes.json().catch(() => ({}))) as { error?: string };
        throw new Error(data.error ?? "Passkey verification failed");
      }
      return (await finishRes.json()) as { ok: boolean; instance: InstanceDTO };
    },
    onSuccess: ({ instance }) => landOnSelect(instance),
    onError: (e: Error) => {
      if (e.name === "NotAllowedError") {
        /* ROUND 55 — iframe-aware hint: embedded previews block the WebAuthn
           ceremony; guide the user to a standalone window */
        const embedded =
          typeof window !== "undefined" && window.self !== window.top;
        toast.info(embedded ? t("secPasskeyIframeHint") : t("secPasskeyCancelled"));
        return;
      }
      setError(e.message || t("errorText"));
      setShake((s) => s + 1);
    },
  });

  /* ROUND 56 — PASSKEY-FIRST sign-in for system owners (usernameless,
   * workspace-scoped discoverable ceremony — no password at all). */
  const passkeyFirst = useMutation({
    mutationFn: () => instancePasskeyLogin(),
    onSuccess: ({ instance }) => landOnSelect(instance),
    onError: (e: Error) => {
      if (e.name === "NotAllowedError") {
        const embedded =
          typeof window !== "undefined" && window.self !== window.top;
        toast.info(embedded ? t("secPasskeyIframeHint") : t("secPasskeyCancelled"));
        return;
      }
      if (e instanceof ApiError && e.status === 400) {
        /* no workspace passkey enrolled yet — point to the password path */
        toast.info(t("loginPasskeyErrNoKeys"));
        return;
      }
      setError(e.message || t("errorText"));
      setShake((s) => s + 1);
    },
  });

  /* ------------------------------------------------------------------ */
  /* forgot password → real support ticket (org-name resolution happens */
  /* server-side in /api/support — nothing about the email is revealed)  */
  /* ------------------------------------------------------------------ */
  const forgot = useMutation({
    mutationFn: async () => {
      return submitPublicTicket({
        name: email.trim(),
        email: email.trim(),
        category: "technical",
        subject: t("gateForgotSubject"),
        message: t("gateForgotMessage", { email: email.trim(), name: email.trim() }),
      });
    },
    onSuccess: (ticket) => {
      setSentId(ticket.id);
      setError(null);
      setMode("sent");
    },
    onError: (e: Error) => {
      setError(e.message || t("errorText"));
      setShake((s) => s + 1);
    },
  });

  const busy = login.isPending || forgot.isPending || reactivate.isPending;

  const switchMode = (next: Mode) => {
    setError(null);
    setShake(0);
    setMode(next);
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    /* ROUND 83 — double-submit guard: Enter inside a text input re-fires the
       form while the mutation is already in flight; the button alone was not
       enough. */
    if (busy) return;
    if (!email.trim() || !password) {
      setError(t("gateErrEmpty"));
      setShake((s) => s + 1);
      return;
    }
    login.mutate();
  };

  const submitForgot = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (busy) return;
    if (!EMAIL_RE.test(email.trim())) {
      setError(t("gateForgotErrEmail"));
      setShake((s) => s + 1);
      return;
    }
    forgot.mutate();
  };

  /* the showcase darkens when a challenge is up (focus the card) */
  const challengeUp = mode === "signin" && !!mfa;

  /* ROUND 117 — the QR opened THIS page on the phone: the completion card
   * replaces the whole experience (one focused action). */
  if (phoneCd) return <CrossDeviceCompleteCard token={phoneCd} />;

  return (
    <MotionBudgetContext.Provider value={motionBudget}>
    {/* ROUND 83 — the login is a LUXURY CANVAS IN BOTH THEMES: the .login-scope
     * design tokens (globals.css) repaint every surface with the global
     * theme, so the header toggle genuinely flips the experience. The child
     * theme-aware components (inputs, passkey block, OTP cells, LangMenu)
     * follow <html class> natively. */}
    <div className="login-scope relative flex min-h-screen overflow-hidden bg-[var(--lg-canvas)] text-[var(--lg-fg)]">
      {/* ============================ aurora canvas ============================ */}
      <div className="pointer-events-none absolute inset-0" aria-hidden="true">
        {/* ROUND 168 — MOBILE ORB DIET: the 4-orb blur-3xl canvas renders on
            lg+ only (it enriches the desktop); below lg a 2-orb blur-2xl
            aurora keeps the identity at a fraction of the GPU cost. The
            first render (SSR + hydration) always draws the desktop canvas —
            the diet applies after mount, so the HTML matches. */}
        {motionBudget.desktop ? (
          <>
            <AuroraOrb className="-top-32 start-[-8rem] h-[26rem] w-[26rem]" color="rgba(109,93,251,0.32)" duration={26} drift={70} />
            <AuroraOrb className="bottom-[-10rem] start-[28%] h-[30rem] w-[30rem]" color="rgba(217,70,239,0.20)" duration={32} drift={90} />
            <AuroraOrb className="top-[12%] end-[-9rem] h-[28rem] w-[28rem]" color="rgba(6,182,212,0.20)" duration={29} drift={80} />
            <AuroraOrb className="bottom-[18%] end-[16%] h-[20rem] w-[20rem]" color="rgba(16,185,129,0.12)" duration={36} drift={50} />
          </>
        ) : (
          <>
            <AuroraOrb className="-top-24 start-[-6rem] h-[22rem] w-[22rem]" color="rgba(109,93,251,0.32)" duration={26} drift={60} diet />
            <AuroraOrb className="bottom-[-8rem] end-[-6rem] h-[24rem] w-[24rem]" color="rgba(217,70,239,0.20)" duration={32} drift={70} diet />
          </>
        )}
        {/* fine grid veil */}
        <div
          className="absolute inset-0 opacity-[0.16]"
          style={{
            backgroundImage:
              "linear-gradient(var(--lg-veil) 1px, transparent 1px), linear-gradient(90deg, var(--lg-veil) 1px, transparent 1px)",
            backgroundSize: "44px 44px",
          }}
        />
        {/* focus dim when the MFA challenge is up — ROUND 168: a plain CSS
            opacity transition (no framer MotionValue ticking on this layer,
            and no inline style attr that could ever be mistaken for an
            entrance-hidden element by the reduced-motion net). */}
        <div
          aria-hidden="true"
          className={cn(
            "absolute inset-0 bg-[var(--lg-dim)] transition-opacity duration-500",
            challengeUp ? "opacity-[0.55]" : "opacity-0",
          )}
        />
      </div>

      <ShowcaseColumn />

      {/* ============================ form column ============================ */}
      <div className="relative flex min-w-0 flex-1 flex-col">
        {/* top row: brand (mobile) + controls — lg:justify-end keeps the
            controls at the trailing edge on desktop where the brand link is
            display:none (the old lg:invisible kept it tabbable = focus trap) */}
        <div className="flex items-center justify-between gap-3 px-5 py-5 sm:px-8 lg:justify-end">
          <Link href="/" className="flex items-center gap-2.5 lg:hidden" aria-label="Ashrilogic">
            <PlatformBrandTile
              variant="mini"
              className="h-10 w-10 rounded-xl shadow-brand-500/40"
              fallback={
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-linear-to-br from-brand-500 via-fuchsia-500 to-cyan-400 text-white shadow-lg shadow-brand-500/40">
                  <CatIcon name="boxes" className="h-[15px] w-[15px]" />
                </span>
              }
            />
            <span className="font-display text-[16px] font-extrabold tracking-tight text-[var(--lg-fg)]">
              Ashrilogic
            </span>
          </Link>
          <HeaderControls />
        </div>

        {/* the glass card */}
        <div className="flex flex-1 items-center justify-center px-5 py-8 sm:px-8">
          <motion.div
            key={`${mode}-${shake}`}
            variants={stagger}
            initial="hidden"
            animate="show"
            className={cn(
              "relative w-full max-w-[430px] rounded-[26px] p-[1.5px] shadow-2xl",
              shake > 0 && "gate-shake"
            )}
            style={{ backgroundImage: "linear-gradient(135deg, rgba(109,93,251,0.65), rgba(6,182,212,0.35), rgba(217,70,239,0.5))" }}
          >
            <div className="relative overflow-hidden rounded-[24.5px] border border-[var(--lg-line)] bg-[var(--lg-card)] p-7 backdrop-blur-2xl sm:p-8">
              {/* inner top glow */}
              <span
                className="pointer-events-none absolute inset-x-10 -top-24 h-40 rounded-full blur-3xl"
                style={{ background: "radial-gradient(circle, rgba(109,93,251,0.28), transparent 70%)" }}
                aria-hidden="true"
              />

              {mode === "sent" ? (
                /* ---------------- recovery sent ---------------- */
                <div className="relative text-center">
                  <motion.div
                    initial={{ scale: 0.3, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ type: "spring", stiffness: 300, damping: 20 }}
                    className="mx-auto grid h-16 w-16 place-items-center rounded-2xl border border-emerald-500/40 bg-emerald-500/10 text-emerald-600 dark:border-emerald-400/40 dark:text-emerald-400"
                  >
                    <CatIcon name="circle-check" className="h-8 w-8" />
                  </motion.div>
                  <motion.h1
                    variants={rise}
                    className="mt-5 font-display text-[19px] font-extrabold text-[var(--lg-fg)]"
                  >
                    {t("gateForgotSentTitle")}
                  </motion.h1>
                  <motion.p
                    variants={rise}
                    className="mx-auto mt-2 max-w-[36ch] text-[12.5px] font-semibold leading-relaxed text-[var(--lg-faint)]"
                  >
                    {t("gateForgotSentDesc")}
                  </motion.p>
                  {sentId ? (
                    <motion.div
                      variants={rise}
                      dir="ltr"
                      className="mx-auto mt-4 inline-flex max-w-full items-center gap-2.5 rounded-xl border border-[var(--lg-line)] bg-[var(--lg-chip)] px-3.5 py-2"
                    >
                      <span className="shrink-0 text-[10.5px] font-bold uppercase tracking-wide text-[var(--lg-faint)]">
                        {t("gateForgotSentRef")}
                      </span>
                      <span className="truncate font-mono text-[11.5px] font-bold tracking-[0.08em] text-[var(--lg-fg)]">
                        {sentId.slice(0, 8).toUpperCase()}
                      </span>
                    </motion.div>
                  ) : null}
                  <motion.div variants={rise}>
                    <Button
                      variant="outline"
                      onClick={() => switchMode("signin")}
                      className="mt-6 h-11 w-full rounded-xl border-[var(--lg-line)] bg-[var(--lg-chip)] text-[13px] font-extrabold text-[var(--lg-muted)] transition hover:border-brand-400/60 hover:text-[var(--lg-fg)] active:scale-95"
                    >
                      <CatIcon name="arrow-left" className="h-4 w-4 rtl:rotate-180" />
                      {t("gateForgotBack")}
                    </Button>
                  </motion.div>
                </div>
              ) : (
                <>
                  {/* header */}
                  <motion.div variants={rise} className="relative flex items-center gap-3.5">
                    <span
                      className={cn(
                        "relative grid h-[54px] w-[54px] shrink-0 place-items-center rounded-2xl text-white shadow-lg",
                        challengeUp
                          ? "bg-linear-to-br from-emerald-500 to-emerald-600 shadow-emerald-500/30"
                          : "bg-linear-to-br from-brand-500 via-fuchsia-500 to-cyan-400 shadow-brand-500/30"
                      )}
                    >
                      <CatIcon
                        name={mode === "forgot" ? "key-round" : "shield-check"}
                        className="h-5 w-5"
                      />
                      {cardLooping ? (
                        <motion.span
                          className="absolute inset-0 rounded-2xl border border-white/30"
                          animate={{ scale: [1, 1.22, 1], opacity: [0.55, 0, 0.55] }}
                          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                        />
                      ) : null}
                    </span>
                    <div className="min-w-0 flex-1">
                      <h1 className="font-display text-[18px] font-extrabold text-[var(--lg-fg)]">
                        {mode === "forgot"
                          ? t("gateForgotTitle")
                          : mfa
                            ? t("mfaLoginTitle")
                            : t("loginPageTitle")}
                      </h1>
                      <p className="mt-0.5 text-[11.5px] font-bold text-[var(--lg-faint)]">
                        {mode === "forgot"
                          ? t("gateForgotDesc")
                          : mfa
                            ? mfa.orgName || t("mfaLoginDesc")
                            : t("loginPageDesc")}
                      </p>
                    </div>
                  </motion.div>

                  {/* error banner */}
                  {error ? (
                    <motion.div
                      role="alert"
                      initial={{ opacity: 0, y: -6 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="relative mt-4 flex items-center gap-2.5 rounded-2xl border border-rose-200 bg-rose-50/90 px-3.5 py-2.5 dark:border-rose-500/30 dark:bg-rose-500/10"
                    >
                      <CatIcon name="circle-alert" className="h-4 w-4 shrink-0 text-rose-500 dark:text-rose-400" />
                      <p className="min-w-0 text-[12px] font-bold text-rose-600 dark:text-rose-300">{error}</p>
                    </motion.div>
                  ) : null}

                  {mode === "signin" && mfa ? (
                    /* ------------------ ROUND 45 — 2FA step ------------------ */
                    <motion.form
                      variants={rise}
                      onSubmit={(e) => {
                        e.preventDefault();
                        if (codeValid) mfaVerify.mutate();
                      }}
                      className="relative mt-5 space-y-4"
                    >
                      <div>
                        {backupMode ? (
                          <>
                            <Label
                              htmlFor="login-mfa-backup"
                              className="text-[11.5px] font-extrabold text-[var(--lg-muted)]"
                            >
                              {t("mfaLoginCodeLabel")}
                            </Label>
                            <Input
                              id="login-mfa-backup"
                              dir="ltr"
                              autoFocus
                              value={mfaCode}
                              onChange={(e) => setMfaCode(normalizeDigits(e.target.value.trim()).slice(0, 12))}
                              placeholder="XXXX-XXXX"
                              disabled={mfaVerify.isPending || mfaPasskey.isPending}
                              aria-invalid={!!error}
                              className="mt-1.5 h-11 rounded-xl border-[var(--lg-line)] bg-[var(--lg-input-bg)] text-center font-black tracking-[0.2em] text-[var(--lg-fg)] placeholder:text-[var(--lg-placeholder)] focus-visible:ring-brand-500/40"
                            />
                          </>
                        ) : (
                          <>
                            <Label
                              htmlFor="login-otp-0"
                              className="flex items-center justify-center gap-1.5 text-[11.5px] font-extrabold text-[var(--lg-muted)]"
                            >
                              <CatIcon name="shield-check" className="h-3.5 w-3.5 text-emerald-400" />
                              {t("mfaLoginCodeLabel")}
                            </Label>
                            <div className="mt-2">
                              <OtpInput
                                idPrefix="login-otp"
                                value={mfaCode}
                                onChange={setMfaCode}
                                disabled={mfaVerify.isPending || mfaPasskey.isPending}
                                invalid={!!error}
                                autoFocus
                                onComplete={() => mfaVerify.mutate()}
                                onEnter={() => mfaVerify.mutate()}
                              />
                            </div>
                          </>
                        )}
                        <button
                          type="button"
                          onClick={() => {
                            setBackupMode((v) => !v);
                            setMfaCode("");
                            setError(null);
                          }}
                          className="mx-auto mt-2.5 flex items-center gap-1.5 text-[10.5px] font-bold text-[var(--lg-faint)] transition hover:text-brand-600 dark:hover:text-brand-300"
                        >
                          <CatIcon name={backupMode ? "hash" : "key-round"} className="h-3 w-3" />
                          {t(backupMode ? "mfaLoginUseCode" : "mfaLoginBackupHint")}
                        </button>
                      </div>

                      <Button
                        type="submit"
                        disabled={mfaVerify.isPending || mfaPasskey.isPending || !codeValid}
                        className="relative h-11 w-full overflow-hidden rounded-xl bg-linear-to-l from-emerald-600 to-emerald-500 text-[13px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
                      >
                        {mfaVerify.isPending ? (
                          <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                        ) : (
                          <CatIcon name="shield-check" className="h-4 w-4" />
                        )}
                        {t("mfaLoginSubmit")}
                      </Button>

                      {mfa.passkeys ? (
                        <div className="pt-1">
                          <div className="flex items-center gap-3" aria-hidden="true">
                            <span className="h-px flex-1 bg-[var(--lg-line)]" />
                            <span className="text-[10.5px] font-extrabold uppercase tracking-wider text-[var(--lg-faint)]">
                              {t("loginOr")}
                            </span>
                            <span className="h-px flex-1 bg-[var(--lg-line)]" />
                          </div>
                          <button
                            type="button"
                            onClick={() => mfaPasskey.mutate()}
                            disabled={mfaVerify.isPending || mfaPasskey.isPending}
                            className="group mt-3 flex h-12 w-full items-center gap-3 rounded-xl border border-[var(--lg-line)] bg-[var(--lg-chip)] px-3.5 text-start transition-all duration-200 hover:border-brand-400/50 hover:bg-[var(--lg-accent-soft)] active:scale-[0.98] disabled:cursor-progress disabled:opacity-70"
                          >
                            <span
                              className="relative grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md shadow-brand-500/25"
                              style={{ backgroundImage: grad("#6d5dfb", "#06b6d4") }}
                              aria-hidden="true"
                            >
                              <CatIcon
                                name={mfaPasskey.isPending ? "refresh-cw" : "fingerprint"}
                                className={
                                  mfaPasskey.isPending
                                    ? "h-4 w-4 animate-spin"
                                    : "h-[17px] w-[17px] transition-transform duration-200 group-hover:scale-110"
                                }
                              />
                              {!mfaPasskey.isPending ? (
                                <span
                                  className="absolute inset-0 animate-ping rounded-xl bg-brand-500/20"
                                  style={{ animationDuration: "2.4s" }}
                                />
                              ) : null}
                            </span>
                            <span className="min-w-0 flex-1">
                              <span className="block truncate text-[13px] font-extrabold text-[var(--lg-fg)]">
                                {t("loginPasskeyTitle")}
                              </span>
                              <span className="block truncate text-[10.5px] font-semibold text-[var(--lg-faint)]">
                                {mfaPasskey.isPending ? t("secPasskeyWorking") : t("loginPasskeySub")}
                              </span>
                            </span>
                            <CatIcon
                              name="chevron-right"
                              className="h-4 w-4 shrink-0 text-[var(--lg-faint)] rtl:rotate-180"
                            />
                          </button>
                        </div>
                      ) : null}

                      <button
                        type="button"
                        onClick={() => {
                          setMfa(null);
                          setMfaCode("");
                          setError(null);
                        }}
                        className="mx-auto flex items-center gap-1.5 text-[11.5px] font-bold text-[var(--lg-faint)] transition hover:text-[var(--lg-muted)]"
                      >
                        <CatIcon name="arrow-left" className="h-3.5 w-3.5 rtl:rotate-180" />
                        {t("mfaLoginBack")}
                      </button>
                    </motion.form>
                  ) : mode === "signin" && disabledInfo ? (
                    /* --------- ROUND 87 — paused-workspace reactivate -------- */
                    <motion.div variants={rise} className="relative mt-5">
                      <div className="rounded-2xl border border-amber-300/60 bg-amber-50/80 p-5 text-center dark:border-amber-400/20 dark:bg-amber-400/[0.07]">
                        <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-linear-to-br from-amber-400 to-orange-500 text-white shadow-lg shadow-amber-500/30">
                          <CatIcon name="pause" className="h-6 w-6" />
                        </span>
                        <h3 className="mt-4 font-display text-[17px] font-extrabold text-slate-900 dark:text-white">
                          {t("reactivateTitle")}
                        </h3>
                        <p className="mt-2 text-[12.5px] font-semibold leading-relaxed text-amber-700 dark:text-amber-300/90">
                          {t("reactivateDesc")}
                        </p>
                        <p className="mt-1 text-[11px] font-bold text-[var(--lg-faint)]" dir="ltr">
                          {email}
                        </p>
                        <Button
                          type="button"
                          onClick={() => reactivate.mutate()}
                          disabled={reactivate.isPending}
                          className="mt-5 h-11 w-full rounded-xl bg-linear-to-l from-emerald-600 to-emerald-500 text-[13px] font-extrabold text-white shadow-lg shadow-emerald-500/30 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
                        >
                          {reactivate.isPending ? (
                            <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                          ) : (
                            <CatIcon name="play" className="h-4 w-4" />
                          )}
                          {t("reactivateAction")}
                        </Button>
                        <button
                          type="button"
                          onClick={() => setDisabledInfo(null)}
                          disabled={reactivate.isPending}
                          className="mt-3 cursor-pointer text-[11px] font-bold text-[var(--lg-muted)] underline underline-offset-4 transition hover:text-[var(--lg-fg)]"
                        >
                          {t("reactivateBack")}
                        </button>
                      </div>
                    </motion.div>
                  ) : mode === "signin" ? (
                    /* ------------------ credentials ------------------ */
                    <motion.form variants={rise} onSubmit={submit} className="relative mt-5 space-y-4">
                      <PremiumEmailInput
                        id="login-email"
                        label="gateEmail"
                        value={email}
                        onChange={setEmail}
                        required
                        placeholder="wzAdminEmailPh"
                        autoComplete="email"
                        inputRef={emailRef}
                        autoFocus
                        invalid={!!error || undefined}
                        disabled={login.isPending}
                      />

                      <div>
                        <div className="flex items-center justify-between">
                          <Label
                            htmlFor="login-password"
                            className="text-[11.5px] font-extrabold text-[var(--lg-muted)]"
                          >
                            {t("wzPwLabel")}
                          </Label>
                          <button
                            type="button"
                            onClick={() => switchMode("forgot")}
                            disabled={login.isPending}
                            className="cursor-pointer text-[10.5px] font-bold text-brand-600 transition hover:text-brand-700 disabled:opacity-50 dark:text-brand-300 dark:hover:text-brand-200"
                          >
                            {t("gateForgotPw")}
                          </button>
                        </div>
                        <div className="relative mt-1.5">
                          <CatIcon
                            name="key-round"
                            className="pointer-events-none absolute start-3.5 top-1/2 h-[15px] w-[15px] -translate-y-1/2 text-[var(--lg-faint)]"
                          />
                          <Input
                            id="login-password"
                            type={visible ? "text" : "password"}
                            dir="ltr"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="••••••••"
                            autoComplete="current-password"
                            aria-invalid={!!error}
                            disabled={login.isPending}
                            className="h-11 rounded-xl border-[var(--lg-line)] bg-[var(--lg-input-bg)] ps-10 pe-11 text-start text-[13px] font-semibold text-[var(--lg-fg)] placeholder:text-[var(--lg-placeholder)] transition focus:border-brand-400/60 focus-visible:shadow-lg focus-visible:shadow-brand-500/20 focus-visible:ring-4 focus-visible:ring-brand-500/20"
                          />
                          <button
                            type="button"
                            onClick={() => setVisible((v) => !v)}
                            aria-label={t(visible ? "wzPwHide" : "wzPwShow")}
                            className="absolute inset-y-0 end-0 me-2.5 grid h-7 w-7 place-items-center rounded-lg text-[var(--lg-faint)] transition hover:bg-[var(--lg-chip-strong)] hover:text-[var(--lg-muted)]"
                          >
                            <CatIcon name={visible ? "eye-off" : "eye"} className="h-[14px] w-[14px]" />
                          </button>
                        </div>
                      </div>

                      {/* the shimmer submit */}
                      <Button
                        type="submit"
                        disabled={login.isPending}
                        className="relative h-11 w-full overflow-hidden rounded-xl bg-linear-to-l from-brand-600 via-fuchsia-500 to-brand-500 text-[13px] font-extrabold text-white shadow-lg shadow-brand-500/30 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
                      >
                        {!login.isPending ? <ShimmerSweep /> : null}
                        {login.isPending ? (
                          <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                        ) : (
                          <CatIcon name="log-in" className="h-4 w-4 rtl:rotate-180" />
                        )}
                        {t("loginPageTitle")}
                      </Button>

                      {/* ROUND 56→117 — passkey-first entry (usernameless;
                          the button opens the cross-device dialog: native
                          ceremony + QR for the phone/tablet that holds the
                          key) */}
                      <PasskeyLoginBlock
                        onTrigger={() => setCrossOpen(true)}
                        pending={passkeyFirst.isPending}
                        disabled={login.isPending}
                      />

                      <div className="flex flex-wrap items-center justify-between gap-2 pt-0.5">
                        <p className="text-[11.5px] font-bold text-[var(--lg-faint)]">
                          {t("gateNoAccount")}
                          <Link
                            href="/#systems"
                            className="ms-1.5 text-brand-600 transition hover:text-brand-700 dark:text-brand-300 dark:hover:text-brand-200"
                          >
                            {t("gateNoAccountCta")}
                          </Link>
                        </p>
                      </div>
                    </motion.form>
                  ) : (
                    /* ------------------ forgot ------------------ */
                    <motion.form variants={rise} onSubmit={submitForgot} className="relative mt-5 space-y-4">
                      <PremiumEmailInput
                        id="login-forgot-email"
                        label="gateForgotEmailLabel"
                        value={email}
                        onChange={setEmail}
                        required
                        placeholder="wzAdminEmailPh"
                        autoComplete="email"
                        inputRef={emailRef}
                        invalid={!!error || undefined}
                        disabled={forgot.isPending}
                      />

                      <Button
                        type="submit"
                        disabled={forgot.isPending}
                        className="relative h-11 w-full overflow-hidden rounded-xl bg-linear-to-l from-brand-600 to-brand-500 text-[13px] font-extrabold text-white shadow-lg shadow-brand-500/30 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
                      >
                        {!forgot.isPending ? <ShimmerSweep /> : null}
                        {forgot.isPending ? (
                          <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                        ) : (
                          <CatIcon name="key-round" className="h-4 w-4" />
                        )}
                        {t("gateForgotSend")}
                      </Button>

                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => switchMode("signin")}
                        disabled={forgot.isPending}
                        className="h-11 w-full rounded-xl border-[var(--lg-line)] bg-[var(--lg-chip)] text-[13px] font-extrabold text-[var(--lg-muted)] transition hover:border-brand-400/60 hover:text-[var(--lg-fg)] active:scale-95"
                      >
                        <CatIcon name="arrow-left" className="h-4 w-4 rtl:rotate-180" />
                        {t("gateForgotBack")}
                      </Button>
                    </motion.form>
                  )}

                  {/* secure note */}
                  <motion.p
                    variants={rise}
                    className="mt-4 flex items-center justify-center gap-1.5 text-center text-[10.5px] font-semibold text-[var(--lg-faint)]"
                  >
                    <CatIcon name="shield-check" className="h-3 w-3 shrink-0 text-emerald-500 dark:text-emerald-400" />
                    {t("gateSecureNote")}
                  </motion.p>
                </>
              )}
            </div>
          </motion.div>
        </div>

        {/* footer */}
        <footer className="safe-bottom border-t border-[var(--lg-line)] px-5 py-3.5 sm:px-8">
          <p className="flex flex-wrap items-center justify-between gap-2 text-[10.5px] font-semibold text-[var(--lg-faint)]">
            <Link
              href="/"
              className="inline-flex items-center gap-1.5 transition hover:text-brand-600 hover:underline dark:hover:text-brand-300"
            >
              <CatIcon name="arrow-left" className="h-3 w-3 rtl:rotate-180" />
              {t("loginBackSite")}
            </Link>
            <span className="inline-flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" aria-hidden="true" />
              Ashrilogic — {t("dashSecuredSession")}
            </span>
          </p>
        </footer>
      </div>

      {/* ROUND 117 — the cross-device passkey dialog (native path + QR) */}
      <CrossDevicePasskeyDialog
        scope="instance"
        open={crossOpen}
        onClose={() => setCrossOpen(false)}
        onNative={() => passkeyFirst.mutate()}
        nativePending={passkeyFirst.isPending}
        onClaimed={(claim) => {
          if (claim.instance) landOnSelect(claim.instance);
        }}
      />
    </div>
    </MotionBudgetContext.Provider>
  );
}

export default LoginPageView;
