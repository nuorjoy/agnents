"use client";

/**
 * Ashrilogic — ROUND 117 — the PHONE side of the cross-device passkey
 * login (what the QR opens).
 *
 * Rendered by the login pages when the URL carries ?cd=<token> (the
 * desktop's bridge). The card:
 *
 *  1. fetches the bridge state (GET /api/cross-device/<token>) — a miss
 *     answers the invalid/expired state (uniform, no oracle);
 *  2. offers ONE action: «تأكيد بمفتاح المرور» — the native browser
 *     ceremony ON THIS DEVICE with the bridge's own options (the passkey
 *     may live here: platform authenticator, synced keychain, or the
 *     OS's own cross-device sheet);
 *  3. submits the assertion (POST …/finish); the server verifies it
 *     against the bridge's challenge and flips the bridge to approved —
 *     the DESKTOP claims the session on its next poll (no session is
 *     issued here, the cookie lands on the desktop that started the QR);
 *  4. the success state tells the user to return to their other device.
 *
 * If the bridge was already approved (the phone re-opens the link), the
 * card shows the confirmed state read-only.
 *
 * The visual language mirrors the login surfaces: glass card, gradient
 * medallion, RTL/LTR, dark/light.
 */
import { useCallback, useEffect, useState } from "react";
import { motion } from "framer-motion";
import type { PublicKeyCredentialRequestOptionsJSON } from "@simplewebauthn/server";
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { grad } from "@/lib/utils";
import { Button } from "@/components/ui/button";

type PhoneState = "loading" | "ready" | "working" | "done" | "invalid" | "failed";

interface BridgeInfo {
  scope: "admin" | "instance";
  status: string;
  options: PublicKeyCredentialRequestOptionsJSON | null;
}

export function CrossDeviceCompleteCard({ token }: { token: string }) {
  const { t } = useT();
  const [state, setState] = useState<PhoneState>("loading");
  const [bridge, setBridge] = useState<BridgeInfo | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(`/api/cross-device/${encodeURIComponent(token)}`, {
          credentials: "same-origin",
          headers: { "Content-Type": "application/json" },
        });
        if (!res.ok) {
          if (!cancelled) setState("invalid");
          return;
        }
        const data = (await res.json()) as BridgeInfo;
        if (cancelled) return;
        if (data.status !== "pending" || !data.options) {
          /* approved or already claimed → the confirmed state */
          setBridge(data);
          setState("done");
          return;
        }
        setBridge(data);
        setState("ready");
      } catch {
        if (!cancelled) setState("invalid");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [token]);

  const confirm = useCallback(async () => {
    if (!bridge?.options || state === "working") return;
    setState("working");
    try {
      const { startAuthentication } = await import("@simplewebauthn/browser");
      const assertion = await startAuthentication({ optionsJSON: bridge.options });
      const res = await fetch(`/api/cross-device/${encodeURIComponent(token)}/finish`, {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ response: assertion }),
      });
      if (res.ok) {
        setState("done");
        return;
      }
      setState("failed");
    } catch (e) {
      if (e instanceof Error && e.name === "NotAllowedError") {
        /* the user dismissed the ceremony — back to ready (no error) */
        setState("ready");
        return;
      }
      setState("failed");
    }
  }, [bridge, state, token]);

  const icon =
    state === "done"
      ? "shield-check"
      : state === "invalid"
        ? "circle-alert"
        : state === "working"
          ? "refresh-cw"
          : "fingerprint";
  const medallion =
    state === "done"
      ? grad("#10b981", "#059669")
      : state === "invalid" || state === "failed"
        ? grad("#f43f5e", "#fb7185")
        : grad("#6d5dfb", "#06b6d4");

  return (
    <div className="relative flex min-h-screen items-center justify-center px-4 py-12">
      <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden />
      <motion.div
        initial={{ opacity: 0, y: 16, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        className="w-full max-w-sm"
      >
        <div className="glass-card card-in relative rounded-3xl p-6 sm:p-8">
          <div className="flex flex-col items-center text-center">
            <span
              className="grid h-16 w-16 place-items-center rounded-2xl text-white shadow-lg shadow-brand-500/30"
              style={{ backgroundImage: medallion }}
              aria-hidden="true"
            >
              <CatIcon
                name={icon}
                className={state === "working" ? "h-7 w-7 animate-spin" : "h-7 w-7"}
              />
            </span>
            <h1 className="mt-5 font-display text-2xl font-extrabold text-slate-900 dark:text-white">
              {state === "done" ? t("cdClaimed") : state === "invalid" ? t("cdPhoneInvalid") : t("cdPhoneTitle")}
            </h1>
            {(state === "ready" || state === "working" || state === "failed") && (
              <p className="mt-1.5 max-w-xs text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
                {t("cdPhoneDesc")}
              </p>
            )}
          </div>

          {state === "loading" ? (
            <div className="mt-7 grid place-items-center py-4">
              <CatIcon name="refresh-cw" className="h-5 w-5 animate-spin text-brand-400" />
            </div>
          ) : state === "done" ? (
            <div className="mt-7 space-y-3 text-center">
              <div className="flex items-center justify-center gap-2">
                <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-[11px] font-bold text-emerald-600 dark:border-emerald-500/25 dark:bg-emerald-500/10 dark:text-emerald-300">
                  <CatIcon name="check" className="h-3 w-3" />
                  {t("cdPhoneStatusApproved")}
                </span>
              </div>
              <p className="text-[12.5px] font-bold text-emerald-700 dark:text-emerald-300">{t("cdPhoneDone")}</p>
              <p className="text-[11px] font-semibold text-slate-400 dark:text-slate-500">{t("cdPhoneDoneSub")}</p>
            </div>
          ) : state === "invalid" ? (
            <div className="mt-7 rounded-2xl border border-rose-200 bg-rose-50/90 px-4 py-4 text-center dark:border-rose-500/25 dark:bg-rose-500/10">
              <p className="text-[12px] font-bold leading-relaxed text-rose-600 dark:text-rose-300">
                {t("cdPhoneInvalid")}
              </p>
            </div>
          ) : (
            <div className="mt-7 space-y-3">
              {state === "failed" ? (
                <motion.p
                  initial={{ opacity: 0, y: -6 }}
                  animate={{ opacity: 1, y: 0 }}
                  role="alert"
                  className="flex items-center gap-2 rounded-xl border border-rose-200 bg-rose-50/90 px-3.5 py-2.5 text-[12px] font-bold text-rose-600 dark:border-rose-500/25 dark:bg-rose-500/10 dark:text-rose-300"
                >
                  <CatIcon name="circle-alert" className="h-4 w-4 shrink-0" />
                  <span className="min-w-0 flex-1">{t("cdPhoneFailed")}</span>
                </motion.p>
              ) : null}
              <Button
                type="button"
                onClick={() => void confirm()}
                disabled={state === "working"}
                className="h-11 w-full rounded-xl bg-linear-to-l from-brand-600 via-fuchsia-500 to-cyan-400 px-5 text-[13px] font-extrabold text-white shadow-lg shadow-brand-500/30 transition hover:brightness-110 active:scale-95 disabled:opacity-70"
              >
                {state === "working" ? (
                  <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                ) : (
                  <CatIcon name="fingerprint" className="h-4 w-4" />
                )}
                {state === "working" ? t("cdPhoneWorking") : t("cdPhoneBtn")}
              </Button>
              <p className="text-center text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                {t("adminLoginSecureNote")}
              </p>
            </div>
          )}
        </div>

        <p className="mt-4 flex items-center justify-center gap-1.5 text-center text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
          <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-linear-to-l from-brand-500 to-cyan-400" aria-hidden="true" />
          {t("adminLoginCredit")}
        </p>
      </motion.div>
    </div>
  );
}
