"use client";

/**
 * Ashrilogic — post-login system selection screen («أنظمتك المنشأة»).
 *
 * Replaces the old "sign in → jump straight into the dashboard" jump: after a
 * successful workspace sign-in (or when returning via my-systems), the user
 * lands on this dedicated Premium page to pick WHICH of their provisioned
 * systems to use. Cards mirror the live instance list; the workspace that was
 * just signed into is highlighted with a "ready to enter" ring.
 *
 * ROUND 144 (owner directive: «عند أنظمتك المنشأة قم بإعادة تطويرها كاملاً
 * واظهر في بطاقة النظام تفاصيل متقدمة ودقيقة جداً وحقيقية وبطريقة Premium»)
 * — every card now surfaces the REAL server-enriched tenant facts in a clear
 * four-zone interior: (1) identity (icon tile · system name · org · live
 * entitlement status chip), (2) a REAL-DATA metrics strip — the wallet's
 * unique 8-digit transfer number (copyable), the live minor-unit balance, the
 * live team-member count, the provisioned modules count — with a skeleton
 * pulse while the enriched fields are still in flight, (3) the meta row (plan
 * chip · published-site chip · created · last activity), (4) actions. Above
 * the grid a KPI strip aggregates the SAME live numbers (systems · published
 * sites · wallets total · team members) with a local count-up hook.
 *
 * Opening a card re-uses the same session-probe contract as my-systems:
 * an authenticated workspace enters directly, otherwise the sign-in gate
 * verifies first. "Sign out" clears every workspace session this user owns.
 */
import { useCallback, useMemo, useState, type ReactNode } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import { ar as arLocale, enUS } from "date-fns/locale";
import { toast } from "sonner";
import { useCountUp } from "@/hooks/use-count-up";
import { CATEGORY_MAP, SYSTEM_MAP } from "@/data/catalog";
import type {
  EntitlementInfoDTO,
  InstanceDTO,
  Lang,
  PackageSummaryDTO,
} from "@/lib/types";
import { useT } from "@/lib/i18n";
import type { I18nKey } from "@/lib/i18n";
import { intlLocale } from "@/lib/locales";
import { nf } from "@/lib/format";
import { useAppStore } from "@/lib/store";
import {
  ApiError,
  fetchInstanceSession,
  fetchInstances,
  fetchMyInstances,
  instanceLogout,
} from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, grad, hexAlpha } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { LiveClock } from "@/components/ui/live-clock";
import { NewSystemChooser } from "@/components/auth/new-system-chooser";
import {
  InstanceLoginGate,
  type GateIntent,
  type GateTarget,
} from "@/components/auth/instance-login-gate";
import { PlatformBrandTile, usePlatformWordmark } from "@/components/shared/platform-brand";

import "@/lib/i18n/fragments/app";
const FALLBACK = { icon: "boxes", c1: "#6d5dfb", c2: "#0ea5e9" } as const;

/** Translator shape accepted by the local resolvers (useT's t). */
type Translate = (key: I18nKey, vars?: Record<string, string | number>) => string;

function toGateTarget(instance: InstanceDTO): GateTarget {
  return {
    id: instance.id,
    name: instance.org.name,
    systemId: instance.systemId,
    emailHint: instance.admin?.email || undefined,
  };
}

/* ------------------------- entitlement status chip ------------------------- */

type EntChipTone = "amber" | "emerald" | "rose" | "slate";

interface EntChip {
  icon: string;
  tone: EntChipTone;
  text: string;
}

const ENT_CHIP_CLS: Record<EntChipTone, string> = {
  amber:
    "border-amber-300/70 bg-amber-100 text-amber-700 dark:border-amber-500/30 dark:bg-amber-500/15 dark:text-amber-300",
  emerald:
    "border-emerald-300/70 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:bg-emerald-500/10 dark:text-emerald-300",
  rose:
    "border-rose-300/70 bg-rose-100 text-rose-600 dark:border-rose-500/30 dark:bg-rose-500/15 dark:text-rose-300",
  slate:
    "border-slate-300/70 bg-slate-100 text-slate-500 dark:border-white/15 dark:bg-white/[0.06] dark:text-slate-400",
};

/** localized short date (fail-soft → null) for the active-until chip */
function localizedDate(iso: string, lang: Lang): string | null {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return null;
  try {
    return new Intl.DateTimeFormat(intlLocale(lang), {
      year: "numeric",
      month: "short",
      day: "numeric",
    }).format(d);
  } catch {
    return null;
  }
}

/**
 * ROUND 144 — the server-computed subscription state as ONE honest chip:
 * trial → the live countdown (whole days; precise hours inside the final
 * day) · active → the paid term's end date (or the plain active label for
 * unlimited / platform-managed rows) · locked → expired · active with no
 * package → «بدون باقة». REAL data only — every value comes from
 * EntitlementInfoDTO + the eager package summary, never a client-side guess.
 */
function entitlementChip(
  ent: EntitlementInfoDTO | undefined,
  pkg: PackageSummaryDTO | null | undefined,
  lang: Lang,
  t: Translate,
  fmt: (n: number) => string,
): EntChip | null {
  if (!ent) return null;
  if (ent.state === "trial") {
    const days = ent.trialDaysLeft ?? 0;
    if (days >= 1) {
      return { icon: "clock", tone: "amber", text: t("selectCardTrialLeft", { days: fmt(days) }) };
    }
    const hours = ent.trialHoursLeft ?? 0;
    if (hours >= 1) {
      return { icon: "clock", tone: "amber", text: t("trialHoursLeft", { hours: fmt(hours) }) };
    }
    return { icon: "clock", tone: "amber", text: t("selectCardTrialLeft", { days: fmt(0) }) };
  }
  if (ent.state === "locked") {
    return { icon: "lock", tone: "rose", text: t("selectCardExpired") };
  }
  /* active */
  if (!pkg) {
    return { icon: "package-open", tone: "slate", text: t("selectCardNoPlan") };
  }
  if (ent.planExpiresAt) {
    const date = localizedDate(ent.planExpiresAt, lang);
    if (date) {
      return { icon: "check", tone: "emerald", text: t("selectCardActiveUntil", { date }) };
    }
  }
  return { icon: "check", tone: "emerald", text: t("wsStatusActive") };
}

/* ---------------------- metric / KPI tint vocabulary ---------------------- */

const TINT = {
  brand: "bg-brand-500/10 text-brand-600 dark:bg-brand-500/15 dark:text-brand-300",
  emerald: "bg-emerald-500/10 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400",
  amber: "bg-amber-500/10 text-amber-600 dark:bg-amber-500/15 dark:text-amber-400",
  teal: "bg-teal-500/10 text-teal-600 dark:bg-teal-500/15 dark:text-teal-400",
  fuchsia: "bg-fuchsia-500/10 text-fuchsia-600 dark:bg-fuchsia-500/15 dark:text-fuchsia-400",
} as const;

/**
 * ROUND 144 — the compact stat cell of the card metrics strip: a tiny tinted
 * icon square + a truncating label, then the value row (fixed 24px so every
 * cell in the grid shares the exact same rhythm — zero overlap by
 * construction). `skeleton` pulses while the enriched field is still in
 * flight (progressive arrival from the mine listing).
 */
function MetricCell({
  icon,
  tint,
  label,
  skeleton,
  children,
}: {
  icon: string;
  tint: string;
  label: string;
  skeleton: boolean;
  children: ReactNode;
}) {
  return (
    <div className="min-w-0 rounded-xl border border-slate-200/70 bg-slate-50/60 p-2.5 dark:border-white/[0.07] dark:bg-white/[0.03]">
      <div className="flex min-w-0 items-center gap-1.5">
        <span className={cn("grid h-6 w-6 shrink-0 place-items-center rounded-lg", tint)}>
          <CatIcon name={icon} className="h-3 w-3" />
        </span>
        <span className="min-w-0 truncate text-[10px] font-bold text-slate-400 dark:text-slate-500">
          {label}
        </span>
      </div>
      <div className="mt-1.5 flex h-6 min-w-0 items-center">
        {skeleton ? <Skeleton className="h-4 w-4/5 rounded-md" /> : children}
      </div>
    </div>
  );
}

/** ROUND 144 — one KPI tile above the grid (same card vocabulary). */
function KpiTile({
  icon,
  tint,
  label,
  value,
}: {
  icon: string;
  tint: string;
  label: string;
  value: ReactNode;
}) {
  return (
    <div className="card-in min-w-0 rounded-2xl border border-slate-200/80 bg-white/70 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
      <div className="flex min-w-0 items-center gap-2.5">
        <span className={cn("grid h-9 w-9 shrink-0 place-items-center rounded-xl", tint)}>
          <CatIcon name={icon} className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="min-w-0 truncate text-[10px] font-bold text-slate-400 dark:text-slate-500">
            {label}
          </p>
          <p
            dir="ltr"
            className="mt-1 flex min-w-0 items-baseline gap-1 font-display text-[17px] font-extrabold leading-none tabular-nums text-slate-900 dark:text-white"
          >
            {value}
          </p>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------ select card --------- */

function SelectCard({
  instance,
  highlight,
  isCurrent,
  onOpen,
}: {
  instance: InstanceDTO;
  highlight: boolean;
  isCurrent: boolean;
  onOpen: (instance: InstanceDTO) => void;
}) {
  const { t, lang } = useT();

  const system = SYSTEM_MAP[instance.systemId];
  const cat = system ? CATEGORY_MAP[system.c] : undefined;
  const icon = system?.icon ?? FALLBACK.icon;
  const c1 = cat?.c1 ?? FALLBACK.c1;
  const c2 = cat?.c2 ?? FALLBACK.c2;
  const name = system ? (lang === "ar" ? system.nameAr : system.nameEn) : instance.systemId;
  const siteLive = instance.site?.published === true;
  const fmt = (n: number) => nf(lang, n);

  /* ROUND 144 — the REAL enriched facts (progressive: the authenticated mine
   * listing delivers them; `undefined` = not yet arrived → skeleton pulse,
   * `null` = loaded-and-absent → the honest em dash). */
  const walletNo = instance.walletNo;
  const walletMinor = instance.walletMinor;
  const memberCount = instance.memberCount;
  const ent = entitlementChip(instance.entitlement, instance.package, lang, t, fmt);

  const relLocale = lang === "ar" ? arLocale : enUS;
  const createdRel = formatDistanceToNow(new Date(instance.createdAt), {
    addSuffix: true,
    locale: relLocale,
  });
  /* the newest activity stamp (server order — newest first) → «آخر نشاط» */
  const lastAct = instance.activities[0];
  const lastActAt = lastAct ? new Date(lastAct.createdAt) : null;
  const lastSeenRel =
    lastActAt && !Number.isNaN(lastActAt.getTime())
      ? formatDistanceToNow(lastActAt, { addSuffix: true, locale: relLocale })
      : null;

  /* one tap copies the wallet's unique transfer number (bank-grade pattern:
   * promise dual-callback, never a silent failure) */
  const copyWalletNo = useCallback(() => {
    const no = instance.walletNo;
    if (no == null) return;
    void navigator.clipboard?.writeText(String(no)).then(
      () => toast.success(t("walletNoCopied")),
      () => toast.error(t("errorText")),
    );
  }, [instance.walletNo, t]);

  return (
    <article
      className={`card-in group relative flex flex-col overflow-hidden rounded-3xl border bg-white p-5 transition-all duration-300 hover:-translate-y-1 hover:shadow-lift dark:bg-white/[0.035] ${
        highlight
          ? "border-brand-400/80 shadow-lift shadow-brand-500/20 ring-2 ring-brand-400/40 dark:border-brand-500/50 dark:ring-brand-500/30"
          : "border-slate-200/80 shadow-soft hover:border-transparent dark:border-white/10"
      }`}
    >
      <span
        className="absolute inset-x-0 top-0 h-1 origin-center scale-x-0 transition-transform duration-300 group-hover:scale-x-100"
        style={{ backgroundImage: grad(c1, c2, 90) }}
        aria-hidden="true"
      />

      {/* ZONE 1 — identity: icon tile · system name · org · live status chips */}
      <div className="flex items-start gap-3">
        <span
          className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
          style={{
            backgroundImage: grad(c1, c2),
            boxShadow: `0 10px 24px -10px ${hexAlpha(c1, 0.8)}`,
          }}
        >
          <CatIcon name={icon} className="h-[17px] w-[17px]" />
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex min-w-0 items-center gap-2">
            <h3 className="min-w-0 truncate font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
              {name}
            </h3>
            {highlight ? (
              <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-brand-300/70 bg-brand-500/10 px-2.5 py-1 text-[10px] font-extrabold text-brand-600 dark:border-brand-500/40 dark:text-brand-300">
                <CatIcon name="log-in" className="h-[10px] w-[10px]" />
                {t("selectReadyChip")}
              </span>
            ) : isCurrent ? (
              <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-emerald-300/70 bg-emerald-500/10 px-2.5 py-1 text-[10px] font-extrabold text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300">
                <CatIcon name="check" className="h-[10px] w-[10px]" />
                {t("selectCurrentChip")}
              </span>
            ) : null}
          </div>
          <p className="mt-0.5 truncate text-[12px] text-slate-500 dark:text-slate-400">
            {instance.org.name}
          </p>
          {ent || instance.demo ? (
            <div className="mt-2 flex flex-wrap items-center gap-1.5">
              {ent ? (
                <span
                  className={cn(
                    "inline-flex min-w-0 items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-extrabold",
                    ENT_CHIP_CLS[ent.tone],
                  )}
                >
                  <CatIcon name={ent.icon} className="h-[9px] w-[9px] shrink-0" />
                  <span className="min-w-0 truncate">{ent.text}</span>
                </span>
              ) : null}
              {instance.demo ? (
                <span className="inline-flex min-w-0 items-center gap-1.5 rounded-full border border-slate-300/70 bg-slate-100 px-2.5 py-0.5 text-[10px] font-extrabold text-slate-500 dark:border-white/15 dark:bg-white/[0.06] dark:text-slate-400">
                  <CatIcon name="flask-conical" className="h-[9px] w-[9px] shrink-0" />
                  <span className="min-w-0 truncate">{t("adminDemoBadge")}</span>
                </span>
              ) : null}
            </div>
          ) : null}
        </div>
      </div>

      {/* ZONE 2 — REAL data: the enriched tenant facts
       * (2×2 grid — the overlap-proof split at the preserved card widths) */}
      <div className="mt-4 grid grid-cols-2 gap-2">
        {/* the wallet's unique 8-digit transfer number — LTR mono, copyable */}
        <MetricCell
          icon="wallet"
          tint={TINT.brand}
          label={t("selectCardWalletNo")}
          skeleton={walletNo === undefined}
        >
          <div className="flex min-w-0 items-center gap-1">
            <span
              dir="ltr"
              title={walletNo == null ? undefined : String(walletNo)}
              className="min-w-0 truncate rounded-md border border-slate-200 bg-white px-1.5 py-0.5 font-mono text-[12px] font-extrabold tabular-nums tracking-[0.06em] text-slate-900 dark:border-white/10 dark:bg-white/[0.05] dark:text-white"
            >
              {walletNo == null ? "—" : String(walletNo)}
            </span>
            {walletNo != null ? (
              <button
                type="button"
                onClick={copyWalletNo}
                aria-label={`${t("selectCardWalletNo")} ${String(walletNo)}`}
                title={`${t("selectCardWalletNo")} ${String(walletNo)}`}
                className="grid h-6 w-6 shrink-0 place-items-center rounded-md border border-slate-200 bg-white text-slate-400 transition hover:border-brand-300 hover:text-brand-600 active:scale-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400/70 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-500 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
              >
                <CatIcon name="copy" className="h-3 w-3" />
              </button>
            ) : null}
          </div>
        </MetricCell>

        {/* the live wallet balance (minor → major at the display boundary) */}
        <MetricCell
          icon="gem"
          tint={TINT.emerald}
          label={t("selectCardBalance")}
          skeleton={walletMinor === undefined}
        >
          <p
            dir="ltr"
            className="flex min-w-0 items-baseline gap-1 font-display text-[13.5px] font-extrabold leading-none tabular-nums text-slate-900 dark:text-white"
          >
            <span className="min-w-0 truncate">{fmt(Math.round(walletMinor ?? 0) / 100)}</span>
            <span className="shrink-0 text-[9.5px] font-bold text-slate-400 dark:text-slate-500">
              SAR
            </span>
          </p>
        </MetricCell>

        {/* the live team-member count */}
        <MetricCell
          icon="users"
          tint={TINT.teal}
          label={t("selectCardMembers")}
          skeleton={memberCount === undefined}
        >
          <p
            dir="ltr"
            className="truncate font-display text-[13.5px] font-extrabold leading-none tabular-nums text-slate-900 dark:text-white"
          >
            {fmt(memberCount ?? 0)}
          </p>
        </MetricCell>

        {/* provisioned modules (always present on the base DTO) */}
        <div className="flex min-w-0 items-center gap-2 rounded-xl border border-slate-200/70 bg-slate-50/60 p-2.5 dark:border-white/[0.07] dark:bg-white/[0.03]">
          <span className={cn("grid h-6 w-6 shrink-0 place-items-center rounded-lg", TINT.amber)}>
            <CatIcon name="cubes" className="h-3 w-3" />
          </span>
          <span className="min-w-0 truncate text-[12px] font-extrabold tabular-nums text-slate-900 dark:text-white">
            {t("selectModulesChip", { count: fmt(instance.modules.length) })}
          </span>
        </div>
      </div>

      {/* ZONE 3 — meta: plan · published site · created · last activity */}
      <div className="mt-3.5 flex flex-wrap items-center gap-x-3 gap-y-1.5 text-[11px] font-bold text-slate-400 dark:text-slate-500">
        {instance.package ? (
          <span className="inline-flex min-w-0 items-center gap-1.5 rounded-full border border-amber-300/70 bg-amber-100 px-2.5 py-0.5 text-[10px] font-extrabold text-amber-700 dark:border-amber-500/30 dark:bg-amber-500/15 dark:text-amber-300">
            <CatIcon name="crown" className="h-[9px] w-[9px] shrink-0" />
            <span className="min-w-0 truncate">
              {lang === "ar" ? instance.package.nameAr : instance.package.nameEn}
            </span>
          </span>
        ) : null}
        {siteLive ? (
          <span className="inline-flex min-w-0 items-center gap-1.5 rounded-full border border-emerald-300/70 bg-emerald-500/10 px-2.5 py-0.5 text-[10px] font-extrabold text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300">
            <CatIcon name="globe" className="h-[9px] w-[9px] shrink-0" />
            <span className="min-w-0 truncate">
              {t("selectSiteLive", { views: fmt(instance.site?.views ?? 0) })}
            </span>
          </span>
        ) : null}
        <span className="inline-flex min-w-0 items-center gap-1.5">
          <CatIcon name="calendar" className="h-[10px] w-[10px] shrink-0" />
          <span className="min-w-0 truncate">{createdRel}</span>
        </span>
        {lastSeenRel ? (
          <span className="inline-flex min-w-0 items-center gap-1.5">
            <CatIcon name="clock" className="h-[10px] w-[10px] shrink-0" />
            <span className="min-w-0 truncate">{`${t("selectCardLastSeen")} · ${lastSeenRel}`}</span>
          </span>
        ) : null}
      </div>

      {/* keep every card's actions row bottom-aligned across the grid row */}
      <span className="min-h-4 flex-1" aria-hidden="true" />

      {/* ZONE 4 — actions */}
      <div className="flex items-center gap-2 border-t border-dashed border-slate-200 pt-3.5 dark:border-white/10">
        <Button
          size="sm"
          onClick={() => onOpen(instance)}
          className="h-9 flex-1 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 text-[12px] font-bold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 dark:from-brand-500 dark:to-brand-400"
        >
          <CatIcon name="rocket" className="h-[12px] w-[12px]" />
          {t("selectEnter")}
        </Button>

        {siteLive ? (
          <Button
            variant="outline"
            size="icon"
            asChild
            aria-label={t("selectSiteVisit")}
            title={t("selectSiteVisit")}
            className="h-9 w-9 rounded-xl border-emerald-300/60 text-emerald-600 transition hover:bg-emerald-50 hover:text-emerald-700 dark:border-emerald-500/40 dark:text-emerald-400 dark:hover:bg-emerald-500/10"
          >
            <a href={`/sites/${instance.id}`} target="_blank" rel="noopener noreferrer">
              <CatIcon name="external-link" className="h-4 w-4" />
            </a>
          </Button>
        ) : null}
      </div>
    </article>
  );
}

/* ------------------------------------------------ screen -------------- */

export function SystemSelectScreen() {
  const { t, lang } = useT();
  const wordmark = usePlatformWordmark();
  const queryClient = useQueryClient();
  const setView = useAppStore((s) => s.setView);
  const setCurrentInstance = useAppStore((s) => s.setCurrentInstance);
  const currentInstanceId = useAppStore((s) => s.currentInstanceId);
  const highlightId = useAppStore((s) => s.selectHighlightId);
  const setSelectHighlightId = useAppStore((s) => s.setSelectHighlightId);
  const ownerEmail = useAppStore((s) => s.selectOwnerEmail);
  const setSelectOwnerEmail = useAppStore((s) => s.setSelectOwnerEmail);
  const backToLanding = useAppStore((s) => s.exitToLanding);

  const [gate, setGate] = useState<{ intent: GateIntent; target: GateTarget } | null>(null);
  /* ROUND 82 (batch-5 ②) — the «إنشاء نظام جديد» chooser: creating another
   * system happens right HERE (no logout-shaped detour to the landing); the
   * wizard opens with the owner-reuse context armed so the new system joins
   * the SAME account (same email + current password). */
  const [chooserOpen, setChooserOpen] = useState(false);

  /* ROUND 36 — the owner-scoped listing comes from the authenticated
     /api/instances/mine endpoint (server filters by the signed-in owner).
     Anonymous visitors (no session) fall back to the public showcase
     projection — anonymous cards carry no admin identity, so the email
     filter no longer applies client-side at all. */
  const query = useQuery({
    queryKey: ["instances", "mine"],
    queryFn: async () => {
      try {
        return await fetchMyInstances();
      } catch (e) {
        if (e instanceof ApiError && e.status === 401) {
          return fetchInstances();
        }
        throw e;
      }
    },
  });

  /* ONLY the signed-in owner's systems belong here — REAL DATA, never a
   * guess. ROUND 141 (directive ㉙): when the store carries an owner email
   * (fresh from login) the email filter must match the authenticated
   * server-scoped list; an EMPTY match renders the honest signed-out empty
   * state — the screen must NEVER pad «أنظمتك المنشأة» with unrelated
   * public showcase rows (the old fallback guessed and showed other
   * people's systems as "yours"). Anonymous browsing (no owner context)
   * keeps the public showcase projection. */
  const own = useMemo(() => {
    const list = query.data ?? [];
    if (!ownerEmail) return list.filter((i) => !i.demo);
    const needle = ownerEmail.trim().toLowerCase();
    const matched = list.filter(
      (i) => (i.admin?.email ?? "").trim().toLowerCase() === needle
    );
    return matched;
  }, [query.data, ownerEmail]);
  /* true when an owner context exists but the authenticated listing came
   * back empty or fell back to the anonymous public projection — the
   * honest state asks for a sign-in instead of guessing. */
  const ownerContextStranded = !!ownerEmail && own.length === 0;

  /* ROUND 144 — the KPI strip aggregates the SAME live enriched numbers the
   * cards render (systems · published sites · wallets total · team members).
   * The count-up rides the MINOR wallet units and rounds once at the display
   * boundary (the money law). */
  const publishedCount = useMemo(
    () => own.filter((i) => i.site?.published === true).length,
    [own],
  );
  const membersTotal = useMemo(
    () => own.reduce((acc, i) => acc + (i.memberCount ?? 0), 0),
    [own],
  );
  const walletMinorTotal = useMemo(
    () => own.reduce((acc, i) => acc + (typeof i.walletMinor === "number" ? i.walletMinor : 0), 0),
    [own],
  );
  /* ROUND 145 (145-fix-qual) — the KPI-strip count-ups now ride the SHARED
   * hook (src/hooks/use-count-up.ts — the one 5 other files use) instead of
   * the ROUND-144 local twin: same 900ms premium count-up to the same final
   * numbers, now with the shared hook's easeOutExpo curve + integer stepping
   * + IntersectionObserver gating (the strip renders only once the enriched
   * data is in, so visibility IS data-readiness here). The wallet-minor
   * value stays integer and rounds to major units exactly once at the
   * display boundary (the money law). */
  const { ref: systemsRef, value: systemsAnim } = useCountUp(own.length, 900);
  const { ref: sitesRef, value: sitesAnim } = useCountUp(publishedCount, 900);
  const { ref: membersRef, value: membersAnim } = useCountUp(membersTotal, 900);
  const { ref: walletRef, value: walletMinorAnim } = useCountUp(walletMinorTotal, 900);
  const fmt = (n: number) => nf(lang, n);

  /* ROUND 36 — manual refresh with a spinning premium button (invalidates
     the my-systems listing + every cached instance query). */
  const [refreshing, setRefreshing] = useState(false);
  const manualRefresh = async () => {
    if (refreshing) return;
    setRefreshing(true);
    try {
      await queryClient.invalidateQueries({ queryKey: ["instances"] });
      await queryClient.invalidateQueries({ queryKey: ["instance"] });
      toast.success(t("dashRefreshDone"));
    } catch {
      toast.error(t("errorText"));
    } finally {
      setRefreshing(false);
    }
  };

  /* the signed-in owner identity for the wizard prefill (name + email of
   * the first own system's admin section) */
  const ownerIdentity = useMemo(() => {
    const first = own.find((i) => i.admin?.email);
    if (!first?.admin?.email) return null;
    return { name: first.admin.name || "", email: first.admin.email };
  }, [own]);
  const open = useCallback(
    async (instance: InstanceDTO) => {
      try {
        const session = await fetchInstanceSession(instance.id);
        if (session.authenticated) {
          setCurrentInstance(instance.id);
          setView("dashboard");
          return;
        }
      } catch {
        // probe failure → the gate surfaces real server errors
      }
      setGate({ intent: "open", target: toGateTarget(instance) });
    },
    [setCurrentInstance, setView]
  );

  /* sign out clears every workspace session this user owns (best effort) */
  const signOut = useMutation({
    mutationFn: async () => {
      await Promise.allSettled(own.map((instance) => instanceLogout(instance.id)));
    },
    onSuccess: () => {
      setSelectHighlightId(null);
      setSelectOwnerEmail(null);
      queryClient.invalidateQueries({ queryKey: ["instances"] });
      queryClient.invalidateQueries({ queryKey: ["instance"] });
      toast.success(t("selectSignOutDone"));
      backToLanding();
    },
  });

  return (
    <div className="relative flex min-h-screen flex-col bg-background">
      <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden="true" />

      {/* header */}
      <header className="border-b border-slate-200/70 bg-white/70 backdrop-blur-md dark:border-white/[0.07] dark:bg-white/[0.02]">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-3 px-4 sm:px-6">
          <PlatformBrandTile
            variant="mini"
            className="h-9 w-9 rounded-xl shadow-brand-500/25"
            fallback={
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-linear-to-br from-brand-500 via-fuchsia-500 to-cyan-400 text-white shadow-lg shadow-brand-500/25">
                <CatIcon name="boxes" className="h-[14px] w-[14px]" />
              </span>
            }
          />
          <div className="min-w-0">
            <p className="font-display text-[15px] font-extrabold leading-tight text-slate-900 dark:text-white">
              <span className="text-gradient">{wordmark}</span>
            </p>
            <p className="hidden text-[10.5px] font-bold text-slate-400 dark:text-slate-500 sm:block">
              {t("selectBadge")}
            </p>
          </div>

          <div className="ms-auto flex items-center gap-2">
            {/* live clock + localized date */}
            <span className="hidden sm:block">
              <LiveClock variant="topbar" className="h-9" />
            </span>
            <span className="hidden items-center gap-1.5 rounded-full border border-emerald-300/60 bg-emerald-500/10 px-3 py-1.5 text-[10.5px] font-extrabold text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300 sm:inline-flex">
              <CatIcon name="shield-check" className="h-[11px] w-[11px]" />
              {t("selectSessionChip")}
            </span>
            {/* ROUND 36 — premium manual refresh */}
            <button
              type="button"
              onClick={manualRefresh}
              disabled={refreshing || query.isFetching}
              aria-label={t("dashRefresh")}
              title={t("dashRefresh")}
              className="group relative grid h-9 w-9 place-items-center overflow-hidden rounded-xl border border-slate-200 text-slate-500 transition-all duration-200 hover:border-brand-300 hover:text-brand-600 active:scale-90 disabled:opacity-60 dark:border-white/10 dark:text-slate-400 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
            >
              <span
                className="absolute inset-0 scale-0 rounded-xl bg-brand-50 opacity-0 transition-all duration-200 group-hover:scale-100 group-hover:opacity-100 dark:bg-brand-500/10"
                aria-hidden="true"
              />
              <CatIcon
                name="refresh-cw"
                className={cn(
                  "relative h-[14px] w-[14px]",
                  (refreshing || query.isFetching) && "animate-spin"
                )}
              />
            </button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => signOut.mutate()}
              disabled={signOut.isPending}
              className="h-9 gap-2 rounded-xl px-3 text-[12px] font-bold text-slate-500 transition hover:bg-red-50 hover:text-red-600 dark:text-slate-400 dark:hover:bg-red-500/10"
            >
              {signOut.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="log-out" className="h-4 w-4" />
              )}
              <span className="hidden sm:inline">{t("selectSignOut")}</span>
            </Button>
          </div>
        </div>
      </header>

      {/* body */}
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-10 sm:px-6 lg:py-14">
        <div className="mx-auto max-w-2xl text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3.5 py-1.5 text-[11px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
            <CatIcon name="server" className="h-[11px] w-[11px] text-emerald-500" />
            {t("selectBadge")}
          </span>
          <h1 className="mt-5 font-display text-[28px] font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-4xl">
            {t("selectTitle")}
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-[14px] leading-relaxed text-slate-600 dark:text-slate-400 sm:text-[15px]">
            {t("selectDesc", { count: own.length })}
          </p>
        </div>

        <div className="mt-10">
          {query.isPending ? (
            <div aria-busy="true" aria-label={t("selectLoadingSystems")}>
              <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
                {[0, 1, 2, 3].map((i) => (
                  <div
                    key={i}
                    className="rounded-2xl border border-slate-200/80 bg-white/70 p-3.5 dark:border-white/10 dark:bg-white/[0.03]"
                  >
                    <div className="flex items-center gap-2.5">
                      <Skeleton className="h-9 w-9 rounded-xl" />
                      <div className="flex-1 space-y-2">
                        <Skeleton className="h-3 w-2/3" />
                        <Skeleton className="h-4 w-1/2" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {[0, 1, 2].map((i) => (
                  <div
                    key={i}
                    className="rounded-3xl border border-slate-200/80 bg-white/70 p-5 dark:border-white/10 dark:bg-white/[0.03]"
                  >
                    <div className="flex items-center gap-3">
                      <Skeleton className="h-12 w-12 rounded-2xl" />
                      <div className="flex-1 space-y-2">
                        <Skeleton className="h-4 w-2/3" />
                        <Skeleton className="h-3 w-1/2" />
                      </div>
                    </div>
                    <div className="mt-4 grid grid-cols-2 gap-2">
                      {[0, 1, 2, 3].map((j) => (
                        <Skeleton key={j} className="h-16 rounded-xl" />
                      ))}
                    </div>
                    <Skeleton className="mt-3.5 h-3 w-3/4" />
                    <Skeleton className="mt-4 h-9 w-full rounded-xl" />
                  </div>
                ))}
              </div>
            </div>
          ) : query.isError ? (
            <div className="mx-auto max-w-md rounded-3xl border border-dashed border-slate-300 bg-white/70 p-8 text-center dark:border-white/10 dark:bg-white/[0.03]">
              <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-rose-50 text-rose-500 dark:bg-rose-500/10 dark:text-rose-400">
                <CatIcon name="triangle-alert" className="h-6 w-6" />
              </div>
              <h3 className="mt-4 font-display text-lg font-extrabold">{t("errorText")}</h3>
              <Button
                variant="outline"
                onClick={() => query.refetch()}
                className="mt-4 h-10 rounded-xl px-5 text-[13px] font-bold"
              >
                <CatIcon name="refresh-cw" className="h-4 w-4" />
                {t("retryText")}
              </Button>
            </div>
          ) : own.length === 0 ? (
            <div className="mx-auto max-w-md rounded-3xl border-2 border-dashed border-slate-300 bg-white/70 p-10 text-center dark:border-white/10 dark:bg-white/[0.02]">
              <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
                <CatIcon name={ownerContextStranded ? "lock" : "package-open"} className="h-7 w-7" />
              </div>
              <h3 className="mt-5 font-display text-lg font-extrabold">
                {t(ownerContextStranded ? "selectStrandedTitle" : "selectEmptyTitle")}
              </h3>
              <p className="mt-2 text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
                {ownerContextStranded
                  ? t("selectStrandedDesc", { email: ownerEmail })
                  : t("selectEmptyDesc")}
              </p>
              <div className="mt-5 flex flex-wrap items-center justify-center gap-2.5">
                {ownerContextStranded ? (
                  <Button
                    onClick={backToLanding}
                    className="h-11 gap-2 rounded-2xl bg-linear-to-l from-brand-600 to-brand-500 px-5 text-[13px] font-bold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
                  >
                    <CatIcon name="log-in" className="h-[12px] w-[12px]" />
                    {t("selectStrandedSignIn")}
                  </Button>
                ) : (
                  <Button
                    onClick={backToLanding}
                    className="mt-0 h-11 gap-2 rounded-2xl bg-linear-to-l from-brand-600 to-brand-500 px-5 text-[13px] font-bold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
                  >
                    <CatIcon name="rocket" className="h-[12px] w-[12px]" />
                    {t("startNow")}
                  </Button>
                )}
              </div>
            </div>
          ) : (
            <>
              {/* ROUND 144 — the premium KPI strip: the SAME live numbers the
               * cards render, aggregated across every owned system. */}
              <section aria-label={t("selectStatsTitle")}>
                <p className="flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                  <span
                    className="inline-block h-1 w-6 shrink-0 rounded-full"
                    style={{ backgroundImage: grad("#6d5dfb", "#db2777", 90) }}
                    aria-hidden="true"
                  />
                  <span className="min-w-0 truncate">{t("selectStatsTitle")}</span>
                </p>
                <div className="mt-3 grid grid-cols-2 gap-3 lg:grid-cols-4">
                  <KpiTile
                    icon="server"
                    tint={TINT.emerald}
                    label={t("selectStatsSystems")}
                    value={<span ref={systemsRef} className="min-w-0 truncate">{fmt(systemsAnim)}</span>}
                  />
                  <KpiTile
                    icon="globe"
                    tint={TINT.fuchsia}
                    label={t("selectStatsSites")}
                    value={<span ref={sitesRef} className="min-w-0 truncate">{fmt(sitesAnim)}</span>}
                  />
                  <KpiTile
                    icon="wallet"
                    tint={TINT.amber}
                    label={t("selectStatsWallet")}
                    value={
                      <>
                        <span ref={walletRef} className="min-w-0 truncate">
                          {fmt(Math.round(walletMinorAnim) / 100)}
                        </span>
                        <span className="shrink-0 text-[9.5px] font-bold text-slate-400 dark:text-slate-500">
                          SAR
                        </span>
                      </>
                    }
                  />
                  <KpiTile
                    icon="users"
                    tint={TINT.teal}
                    label={t("selectStatsMembers")}
                    value={<span ref={membersRef} className="min-w-0 truncate">{fmt(membersAnim)}</span>}
                  />
                </div>
              </section>

              <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {own.map((instance) => (
                  <SelectCard
                    key={instance.id}
                    instance={instance}
                    highlight={highlightId === instance.id}
                    isCurrent={currentInstanceId === instance.id}
                    onOpen={open}
                  />
                ))}
              </div>
            </>
          )}
        </div>

        {/* ROUND 82 — create another system WITHOUT leaving this screen:
         * the chooser dialog opens in place; the owner stays signed in and
         * every new system lands on the SAME account. */}
        <div className="mt-10 flex flex-wrap items-center justify-center gap-2.5">
          <Button
            onClick={() => setChooserOpen(true)}
            className="h-10 gap-2 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-4 text-[12.5px] font-bold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
          >
            <CatIcon name="plus" className="h-4 w-4" />
            {t("selectCreateNew")}
          </Button>
        </div>
      </main>

      {/* footer */}
      <footer className="safe-bottom border-t border-slate-200/70 bg-white/60 py-4 backdrop-blur-sm dark:border-white/[0.07] dark:bg-white/[0.02]">
        <p className="flex items-center justify-center gap-2 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
          <CatIcon name="shield-check" className="h-3 w-3 text-emerald-500" />
          {t("gateSecureNote")}
        </p>
      </footer>

      {/* ROUND 82 — the new-system chooser (same account, no sign-out) */}
      <NewSystemChooser
        open={chooserOpen}
        onOpenChange={setChooserOpen}
        owner={ownerIdentity}
      />

      {/* per-instance verification gate (when a chosen system has no session) */}
      {gate ? (
        <InstanceLoginGate
          target={gate.target}
          intent={gate.intent}
          onClose={() => setGate(null)}
          onNavigateToCreate={() => {
            /* "don't have an account" → back to the landing, scroll the library */
            setGate(null);
            backToLanding();
            setTimeout(
              () =>
                document
                  .getElementById("systems")
                  ?.scrollIntoView({ behavior: "smooth", block: "start" }),
              80
            );
          }}
          onSuccess={() => {
            setSelectHighlightId(gate.target.id);
            setCurrentInstance(gate.target.id);
            setGate(null);
            setView("dashboard");
          }}
        />
      ) : null}
    </div>
  );
}

export default SystemSelectScreen;
