"use client";

/**
 * Ashrilogic — ROUND 57 — shared PREMIUM passkey-first sign-in block.
 *
 * One implementation backs BOTH passwordless entry surfaces:
 *  - the CONTROL PANEL login card (/admin/login — admin scope)
 *  - the SYSTEM OWNERS login page (/login — workspace scope)
 *
 * Composition:
 *  1. an "or" divider,
 *  2. the branded full-width passkey button (animated fingerprint medallion,
 *     title + sub, chevron) — clicking it runs the browser ceremony via the
 *     caller's onTrigger.
 *
 * ROUND 57 — the cross-device sign-in QR was REMOVED from the login
 * interfaces by explicit product decision: the passkey entry stays clean
 * and focused on the native browser ceremony (the platform authenticator
 * already offers its own cross-device flow when needed).
 *
 * Fully AR/EN (RTL/LTR), dark/light aware.
 */
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { cn, grad } from "@/lib/utils";

export interface PasskeyLoginBlockProps {
  /** runs the WebAuthn ceremony (startAuthentication → verify) */
  onTrigger: () => void;
  /** true while the ceremony is in flight (spins the medallion) */
  pending: boolean;
  /** disables the whole block (e.g. while the password step is pending) */
  disabled?: boolean;
  /** tighter vertical rhythm when hosted inside a denser card */
  compact?: boolean;
}

export function PasskeyLoginBlock({
  onTrigger,
  pending,
  disabled = false,
  compact = false,
}: PasskeyLoginBlockProps) {
  const { t } = useT();

  return (
    <div className={cn("pt-1", compact && "pt-0.5")}>
      {/* divider */}
      <div className="flex items-center gap-3" aria-hidden="true">
        <span className="h-px flex-1 bg-slate-200 dark:bg-white/10" />
        <span className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
          {t("loginOr")}
        </span>
        <span className="h-px flex-1 bg-slate-200 dark:bg-white/10" />
      </div>

      {/* the premium passkey button */}
      <button
        type="button"
        onClick={onTrigger}
        disabled={pending || disabled}
        className="group mt-3 flex h-12 w-full items-center gap-3 rounded-xl border border-slate-200 bg-white/80 px-3.5 text-start transition-all duration-200 hover:border-brand-300 hover:bg-brand-50/40 hover:shadow-lg hover:shadow-brand-500/10 active:scale-[0.98] disabled:cursor-progress disabled:opacity-70 dark:border-white/10 dark:bg-white/[0.04] dark:hover:border-brand-500/40 dark:hover:bg-brand-500/10"
      >
        <span
          className="relative grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md shadow-brand-500/25"
          style={{ backgroundImage: grad("#6d5dfb", "#06b6d4") }}
          aria-hidden="true"
        >
          <CatIcon
            name={pending ? "refresh-cw" : "fingerprint"}
            className={
              pending
                ? "h-4 w-4 animate-spin"
                : "h-[17px] w-[17px] transition-transform duration-200 group-hover:scale-110"
            }
          />
          {!pending ? (
            <span
              className="absolute inset-0 animate-ping rounded-xl bg-brand-500/20"
              style={{ animationDuration: "2.4s" }}
            />
          ) : null}
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
            {t("loginPasskeyTitle")}
          </span>
          <span className="block truncate text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
            {pending ? t("secPasskeyWorking") : t("loginPasskeySub")}
          </span>
        </span>
        <CatIcon
          name="chevron-right"
          className="h-4 w-4 shrink-0 text-slate-300 rtl:rotate-180 dark:text-slate-600"
        />
      </button>
    </div>
  );
}
