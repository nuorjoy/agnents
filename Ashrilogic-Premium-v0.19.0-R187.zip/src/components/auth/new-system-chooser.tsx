"use client";

/**
 * Ashrilogic — ROUND 82 (batch-5 ②): the «إنشاء نظام جديد» chooser on the
 * «أنظمتك المنشأة» (system select) screen.
 *
 * The old flow dumped the signed-in owner back onto the public landing to
 * hunt for the library — which felt like a logout. This dialog keeps the
 * owner ON their systems screen: pick the next system right here, and the
 * wizard opens with the owner-reuse context armed (same email + current
 * password → every system managed from ONE account).
 *
 * Premium presentation: category filter chips (gradient tiles like the
 * library), a compact searchable 100-system grid, favorite pins preserved
 * from the landing library, and keyboard-friendly focus handling. Fully
 * AR/EN (RTL/LTR) + dark/light aware.
 */
import { useMemo, useState } from "react";
import { useTheme } from "next-themes";
import { CATEGORIES, SYSTEMS } from "@/data/catalog";
import type { SystemDef } from "@/lib/types";
import { useT, type I18nKey } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import { buildSystemDraft } from "@/components/landing/systems-library";
import { CatIcon } from "@/components/icon";
import { cn, grad, hexAlpha, normalizeSearch } from "@/lib/utils";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";

/* ------------------------------------------------ chooser card -------- */

function ChooserCard({
  system,
  c1,
  c2,
  onStart,
}: {
  system: SystemDef;
  c1: string;
  c2: string;
  onStart: (system: SystemDef) => void;
}) {
  const { t, lang } = useT();
  const name = lang === "ar" ? system.nameAr : system.nameEn;
  return (
    <button
      type="button"
      onClick={() => onStart(system)}
      aria-label={`${name} — ${t("sysSetupLaunch")}`}
      className="card-in group relative flex w-full flex-col overflow-hidden rounded-2xl border border-slate-200/80 bg-white p-3.5 text-start outline-none transition-all duration-300 hover:-translate-y-1 hover:border-transparent hover:shadow-lift focus-visible:ring-4 focus-visible:ring-brand-500/20 active:scale-[0.98] dark:border-white/10 dark:bg-white/[0.035] dark:hover:bg-white/[0.06]"
    >
      <span
        className="absolute inset-x-0 top-0 h-0.5 origin-center scale-x-0 transition-transform duration-200 ease-out group-hover:scale-x-100"
        style={{ backgroundImage: grad(c1, c2, 90) }}
        aria-hidden="true"
      />
      <div className="flex items-center gap-2.5">
        <span
          className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-md transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3"
          style={{
            backgroundImage: grad(c1, c2),
            boxShadow: `0 8px 18px -8px ${hexAlpha(c1, 0.8)}`,
          }}
        >
          <CatIcon name={system.icon} className="h-[15px] w-[15px]" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
            {name}
          </p>
          {/* ROUND 85 — internal SYS-xxx codes are hidden from every user
              surface; the sector label carries the sub-line instead */}
          <p className="truncate text-[10px] font-bold text-slate-400 dark:text-slate-500">
            {(() => {
              const cat = CATEGORIES.find((c) => c.id === system.c);
              return cat ? (lang === "ar" ? cat.nameAr : cat.nameEn) : "";
            })()}
          </p>
        </div>
        <span className="grid h-6 w-6 shrink-0 place-items-center rounded-lg bg-slate-100 text-slate-400 transition-all duration-200 group-hover:bg-brand-500 group-hover:text-white dark:bg-white/[0.06] dark:text-slate-500">
          <CatIcon name="plus" className="h-3 w-3" />
        </span>
      </div>
    </button>
  );
}

/* ------------------------------------------------ the chooser --------- */

export function NewSystemChooser({
  open,
  onOpenChange,
  owner,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** the signed-in owner arming the wizard reuse context */
  owner: { name: string; email: string } | null;
}) {
  const { t, lang } = useT();
  const { resolvedTheme } = useTheme();
  const startWizard = useAppStore((s) => s.startWizard);
  const setWizardOwner = useAppStore((s) => s.setWizardOwner);
  const favorites = useAppStore((s) => s.favorites);

  const [category, setCategory] = useState<string>("all");
  const [search, setSearch] = useState("");

  /* pinned favorites float to the top of the grid */
  const visible = useMemo(() => {
    const q = normalizeSearch(search.trim());
    const list = SYSTEMS.filter((s) => {
      if (category !== "all" && s.c !== category) return false;
      if (!q) return true;
      const haystack = normalizeSearch(
        [lang === "ar" ? s.nameAr : s.nameEn, s.nameEn, s.id].join(" ")
      );
      return haystack.includes(q);
    });
    return [...list].sort((a, b) => {
      const fa = favorites.includes(a.id) ? 0 : 1;
      const fb = favorites.includes(b.id) ? 0 : 1;
      return fa - fb || a.code - b.code;
    });
  }, [category, search, lang, favorites]);

  const start = (system: SystemDef) => {
    /* arm the owner-reuse context — the wizard's admin step prefills the
     * same account and verifies the CURRENT password server-side */
    setWizardOwner(owner);
    startWizard(buildSystemDraft(system, lang, resolvedTheme === "dark" ? "dark" : "light"));
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        dir={lang === "ar" ? "rtl" : "ltr"}
        className="max-h-[88vh] gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-3xl"
      >
        <DialogHeader className="border-b border-slate-200/70 bg-slate-50/70 px-5 pb-4 pt-5 dark:border-white/10 dark:bg-white/[0.03] sm:px-6">
          <DialogTitle className="flex items-center gap-2.5 text-start font-display text-[16px] font-extrabold text-slate-900 dark:text-white">
            <span
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-linear-to-br from-brand-500 via-fuchsia-500 to-cyan-400 text-white shadow-lg shadow-brand-500/25"
              aria-hidden="true"
            >
              <CatIcon name="plus" className="h-4 w-4" />
            </span>
            {t("chooserTitle")}
          </DialogTitle>
          <DialogDescription className="mt-1 text-start text-[12px] leading-relaxed text-slate-500 dark:text-slate-400">
            {owner ? t("chooserDescOwner", { email: owner.email }) : t("chooserDesc")}
          </DialogDescription>

          {/* owner chip — the account the new system will join */}
          {owner ? (
            <div className="mt-3 flex items-center gap-2.5 rounded-2xl border border-emerald-300/60 bg-emerald-500/[0.07] px-3.5 py-2.5 dark:border-emerald-500/30 dark:bg-emerald-500/10">
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-linear-to-br from-emerald-500 to-teal-600 text-white shadow-md" aria-hidden="true">
                <CatIcon name="circle-check" className="h-4 w-4" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-[11.5px] font-extrabold text-emerald-700 dark:text-emerald-300">
                  {t("chooserSameAccountTitle")}
                </p>
                <p dir="ltr" className="truncate text-[10.5px] font-bold text-emerald-600/90 dark:text-emerald-400/90">
                  {owner.email}
                </p>
              </div>
              <span className="shrink-0 rounded-full border border-emerald-300/70 bg-white/70 px-2 py-0.5 text-[9.5px] font-extrabold text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300">
                {t("chooserStaySignedIn")}
              </span>
            </div>
          ) : null}

          {/* search */}
          <div className="relative mt-3.5">
            <CatIcon
              name="search"
              className="pointer-events-none absolute start-3.5 top-1/2 h-[13px] w-[13px] -translate-y-1/2 text-slate-400"
            />
            <Input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t("chooserSearchPh")}
              aria-label={t("chooserSearchPh")}
              className="h-10 rounded-xl border-slate-200 bg-white/90 ps-10 pe-3 text-[12.5px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:focus:bg-white/[0.07]"
            />
          </div>

          {/* category chips */}
          <div className="mt-3 flex flex-wrap gap-1.5" role="tablist" aria-label={t("chooserCatsLabel")}>
            <button
              type="button"
              role="tab"
              aria-selected={category === "all"}
              onClick={() => setCategory("all")}
              className={cn(
                "inline-flex h-8 items-center gap-1.5 rounded-xl px-3 text-[11px] font-extrabold transition active:scale-95",
                category === "all"
                  ? "bg-linear-to-r from-brand-600 to-brand-500 text-white shadow-lg shadow-brand-500/25"
                  : "border border-slate-200 bg-white/70 text-slate-500 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:text-brand-300"
              )}
            >
              <CatIcon name="layout-grid" className="h-3 w-3" />
              {t("catAll")}
            </button>
            {CATEGORIES.map((cat) => {
              const active = category === cat.id;
              return (
                <button
                  key={cat.id}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => setCategory(cat.id)}
                  className={cn(
                    "inline-flex h-8 items-center gap-1.5 rounded-xl px-3 text-[11px] font-extrabold transition active:scale-95",
                    active
                      ? "text-white shadow-lg"
                      : "border border-slate-200 bg-white/70 text-slate-500 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:text-brand-300"
                  )}
                  style={active ? { backgroundImage: grad(cat.c1, cat.c2) } : undefined}
                >
                  <CatIcon name={cat.icon} className="h-3 w-3" />
                  <span className="hidden sm:inline">{lang === "ar" ? cat.nameAr : cat.nameEn}</span>
                </button>
              );
            })}
          </div>
        </DialogHeader>

        {/* the grid */}
        <div className="nice-scroll max-h-[52vh] overflow-y-auto px-5 py-4 sm:px-6">
          <div className="mb-3 flex items-center gap-2 text-[10.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
            <CatIcon name="cubes" className="h-3 w-3" />
            <span className="tabular-nums">{t("chooserCount", { n: visible.length })}</span>
            <span className="h-px flex-1 bg-slate-200/70 dark:bg-white/[0.07]" aria-hidden="true" />
          </div>
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
            {visible.length === 0 ? (
              <div className="col-span-full py-10 text-center">
                <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5">
                  <CatIcon name="search-x" className="h-5 w-5" />
                </span>
                <p className="mt-3 text-[12.5px] font-bold text-slate-500 dark:text-slate-400">
                  {t("dashSearchNoResults")}
                </p>
              </div>
            ) : (
              visible.map((system) => {
                const cat = CATEGORIES.find((c) => c.id === system.c);
                return (
                  <ChooserCard
                    key={system.id}
                    system={system}
                    c1={cat?.c1 ?? "#6d5dfb"}
                    c2={cat?.c2 ?? "#0ea5e9"}
                    onStart={start}
                  />
                );
              })
            )}
          </div>
        </div>

        {/* footer hint */}
        <div className="safe-bottom border-t border-slate-200/70 bg-slate-50/70 px-5 py-3 dark:border-white/10 dark:bg-white/[0.03] sm:px-6">
          <p className="flex items-center justify-center gap-1.5 text-center text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
            <CatIcon name="shield-check" className="h-3 w-3 shrink-0 text-emerald-500" />
            {owner ? t("chooserSecureReuse") : t("gateSecureNote")}
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default NewSystemChooser;
