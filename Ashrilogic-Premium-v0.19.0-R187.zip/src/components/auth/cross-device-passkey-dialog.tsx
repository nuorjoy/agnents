"use client";

/**
 * Ashrilogic — ROUND 117 — the DESKTOP side of the cross-device passkey
 * login (the QR bridge).
 *
 * The dialog backs BOTH passkey-first login surfaces (the control-panel
 * card /admin/login and the owners page /login — scope "admin" /
 * "instance"). Composition, premium by construction:
 *
 *  1. the header: gradient fingerprint medallion + title/description;
 *  2. the native path — «الدخول من هذا الجهاز» — the caller's existing
 *     ceremony runner (onNative), exactly as the login button ran before;
 *  3. the QR panel — the server-rendered violet QR (SVG markup straight
 *     from /api/cross-device/start, never a client-side re-encode) on a
 *     white tile with corner marks + scan instructions + live TTL
 *     countdown + the waiting pulse; a refresh action re-mints the
 *     bridge when the 3-minute window lapses;
 *  4. the poller — POST …/claim every 1.5s; when the phone approves, the
 *     server issues the real HTTP-only session cookie to THIS request
 *     and the claim body (admin DTO / instance DTO) is handed to the
 *     caller's onClaimed — which lands the app exactly where the native
 *     path lands (identical post-login behavior);
 *  5. failure states: start failure (offline/limiter) → inline error +
 *     retry; NOT_ALLOWED native ceremony inside an embedded preview →
 *     the caller keeps its iframe-aware hint (handled by onNative's
 *     owner, the dialog only surfaces the error).
 *
 * RTL/LTR aware, dark/light aware, keyboard accessible (the Dialog
 * primitive), countdown aria-live off (visual only).
 */
import { useCallback, useEffect, useRef, useState } from "react";
import type { AdminUserDTO, InstanceDTO } from "@/lib/types";
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { grad } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

/** What /api/cross-device/start hands back. */
interface CrossDeviceStart {
  token: string;
  qrSvg: string;
  expiresAt: string;
}

/** The claim response — the scope decides which payload rides along. */
export interface CrossDeviceClaim {
  status: "claimed";
  admin?: AdminUserDTO;
  instance?: InstanceDTO;
}

export interface CrossDevicePasskeyDialogProps {
  /** which login surface opened the dialog */
  scope: "admin" | "instance";
  open: boolean;
  onClose: () => void;
  /** the caller's EXISTING native ceremony runner (same-device path) */
  onNative: () => void;
  /** true while the caller's native ceremony is in flight */
  nativePending: boolean;
  /** the claim landed — the caller applies the DTO (setUser/landOnSelect) */
  onClaimed: (claim: CrossDeviceClaim) => void;
}

const POLL_INTERVAL_MS = 1500;

export function CrossDevicePasskeyDialog({
  scope,
  open,
  onClose,
  onNative,
  nativePending,
  onClaimed,
}: CrossDevicePasskeyDialogProps) {
  const { t } = useT();
  const [start, setStart] = useState<CrossDeviceStart | null>(null);
  const [startError, setStartError] = useState<string | null>(null);
  const [secondsLeft, setSecondsLeft] = useState<number | null>(null);
  const [claimed, setClaimed] = useState(false);
  const pollAbort = useRef<AbortController | null>(null);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);

  /* ---------------- start / refresh the bridge ---------------- */
  const mintBridge = useCallback(async () => {
    setStartError(null);
    setStart(null);
    setClaimed(false);
    pollAbort.current?.abort();
    try {
      const res = await fetch("/api/cross-device", {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scope }),
      });
      if (!res.ok) {
        const data = (await res.json().catch(() => ({}))) as { error?: string };
        throw new Error(data.error ?? t("cdFailed"));
      }
      const data = (await res.json()) as CrossDeviceStart;
      setStart(data);
      setSecondsLeft(Math.max(0, Math.round((new Date(data.expiresAt).getTime() - Date.now()) / 1000)));
    } catch (e) {
      setStartError(e instanceof Error && e.message ? e.message : t("cdFailed"));
    }
  }, [scope, t]);

  /* open → mint; close → abort everything */
  useEffect(() => {
    if (open) void mintBridge();
    return () => {
      pollAbort.current?.abort();
    };
  }, [open, mintBridge]);

  /* the countdown */
  useEffect(() => {
    if (!start || claimed) return;
    countdownRef.current = setInterval(() => {
      setSecondsLeft((s) => {
        if (s === null) return null;
        if (s <= 1) {
          if (countdownRef.current) clearInterval(countdownRef.current);
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => {
      if (countdownRef.current) clearInterval(countdownRef.current);
    };
  }, [start, claimed]);

  /* ---------------- the claim poller ---------------- */
  useEffect(() => {
    if (!open || !start || claimed) return;
    const controller = new AbortController();
    pollAbort.current = controller;
    let stopped = false;

    const poll = async () => {
      if (stopped || controller.signal.aborted) return;
      try {
        const res = await fetch(`/api/cross-device/${encodeURIComponent(start.token)}/claim`, {
          method: "POST",
          credentials: "same-origin",
          headers: { "Content-Type": "application/json" },
          signal: controller.signal,
        });
        if (res.status === 202) return; // still pending
        if (res.ok) {
          const data = (await res.json()) as CrossDeviceClaim;
          if (data.status === "claimed") {
            stopped = true;
            setClaimed(true);
            onClaimed(data);
            return;
          }
        }
        /* 404 (expired+reaped) / 409 (already claimed by another tab) —
         * stop polling quietly; the countdown UI explains the expiry */
        if (res.status === 404 || res.status === 409) stopped = true;
      } catch {
        /* network hiccup — the next tick retries */
      }
    };

    const timer = setInterval(() => void poll(), POLL_INTERVAL_MS);
    void poll(); // immediate first probe
    return () => {
      stopped = true;
      clearInterval(timer);
      controller.abort();
    };
  }, [open, start, claimed, onClaimed]);

  const expired = start !== null && secondsLeft === 0 && !claimed;

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md" dir="auto">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <span
              className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-white shadow-lg shadow-brand-500/30"
              style={{ backgroundImage: grad("#6d5dfb", "#06b6d4") }}
              aria-hidden="true"
            >
              <CatIcon
                name={claimed ? "shield-check" : nativePending ? "refresh-cw" : "fingerprint"}
                className={nativePending && !claimed ? "h-5 w-5 animate-spin" : "h-5 w-5"}
              />
            </span>
            <div className="min-w-0">
              <DialogTitle className="text-start font-display text-[16px] font-extrabold text-slate-900 dark:text-white">
                {claimed ? t("cdClaimed") : t("cdDialogTitle")}
              </DialogTitle>
              <DialogDescription className="mt-0.5 text-start text-[12px] leading-relaxed text-slate-500 dark:text-slate-400">
                {t("cdDialogDesc")}
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        {claimed ? (
          /* ------------------------- the success state ------------------------- */
          <div className="flex flex-col items-center gap-2 rounded-2xl border border-emerald-200 bg-emerald-50/80 px-4 py-6 text-center dark:border-emerald-500/25 dark:bg-emerald-500/10">
            <span className="relative grid h-14 w-14 place-items-center rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-300">
              <CatIcon name="shield-check" className="h-7 w-7" />
              <span className="absolute inset-0 animate-ping rounded-full bg-emerald-500/15" style={{ animationDuration: "2s" }} />
            </span>
            <p className="text-[13px] font-extrabold text-emerald-700 dark:text-emerald-300">{t("cdClaimed")}</p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* ---------------- the same-device path ---------------- */}
            <button
              type="button"
              onClick={onNative}
              disabled={nativePending}
              className="group flex h-12 w-full items-center gap-3 rounded-xl border border-slate-200 bg-white/80 px-3.5 text-start transition-all duration-200 hover:border-brand-300 hover:bg-brand-50/40 hover:shadow-lg hover:shadow-brand-500/10 active:scale-[0.98] disabled:cursor-progress disabled:opacity-70 dark:border-white/10 dark:bg-white/[0.04] dark:hover:border-brand-500/40 dark:hover:bg-brand-500/10"
            >
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md shadow-brand-500/25"
                style={{ backgroundImage: grad("#6d5dfb", "#06b6d4") }}
                aria-hidden="true"
              >
                <CatIcon
                  name={nativePending ? "refresh-cw" : "scan-face"}
                  className={nativePending ? "h-4 w-4 animate-spin" : "h-[17px] w-[17px] transition-transform duration-200 group-hover:scale-110"}
                />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
                  {t("cdThisDevice")}
                </span>
                <span className="block truncate text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                  {nativePending ? t("cdNativePending") : t("cdThisDeviceSub")}
                </span>
              </span>
              <CatIcon name="chevron-right" className="h-4 w-4 shrink-0 text-slate-300 rtl:rotate-180 dark:text-slate-600" />
            </button>

            {/* the OR divider */}
            <div className="flex items-center gap-3" aria-hidden="true">
              <span className="h-px flex-1 bg-slate-200 dark:bg-white/10" />
              <span className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                {t("loginOr")}
              </span>
              <span className="h-px flex-1 bg-slate-200 dark:bg-white/10" />
            </div>

            {/* ---------------- the QR panel ---------------- */}
            {startError ? (
              <div className="flex flex-col items-center gap-3 rounded-2xl border border-rose-200 bg-rose-50/90 px-4 py-6 text-center dark:border-rose-500/25 dark:bg-rose-500/10">
                <CatIcon name="triangle-alert" className="h-6 w-6 text-rose-500" />
                <p className="text-[12px] font-bold text-rose-600 dark:text-rose-300">{startError}</p>
                <Button type="button" onClick={() => void mintBridge()} className="h-9 rounded-xl px-4 text-[12px] font-extrabold">
                  {t("cdRefresh")}
                </Button>
              </div>
            ) : !start ? (
              /* minting skeleton */
              <div className="grid place-items-center rounded-2xl border border-slate-200 bg-slate-50/80 px-4 py-10 dark:border-white/10 dark:bg-white/[0.03]">
                <CatIcon name="refresh-cw" className="h-5 w-5 animate-spin text-brand-400" />
              </div>
            ) : (
              <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-4 dark:border-white/10 dark:bg-white/[0.03]">
                <div className="flex flex-col items-center gap-2 text-center">
                  <p className="text-[12.5px] font-extrabold text-slate-700 dark:text-slate-200">
                    {expired ? t("cdExpired") : t("cdScanTitle")}
                  </p>
                  {!expired ? (
                    <p className="max-w-[300px] text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                      {t("cdScanSub")}
                    </p>
                  ) : null}
                </div>

                {/* the QR tile — white background keeps the violet code
                    scannable in BOTH light and dark themes */}
                <div className="relative mx-auto mt-3 grid h-[196px] w-[196px] place-items-center overflow-hidden rounded-xl bg-white shadow-inner shadow-slate-900/5 ring-1 ring-slate-900/10">
                  {expired ? (
                    <div className="absolute inset-0 z-10 grid place-items-center bg-white/90 backdrop-blur-[2px]">
                      <Button
                        type="button"
                        onClick={() => void mintBridge()}
                        className="h-9 gap-2 rounded-xl px-4 text-[12px] font-extrabold"
                      >
                        <CatIcon name="qr-code" className="h-4 w-4" />
                        {t("cdRefresh")}
                      </Button>
                    </div>
                  ) : null}
                  {start.qrSvg ? (
                    <div
                      className="h-[176px] w-[176px] [&>svg]:h-full [&>svg]:w-full"
                      aria-label={t("cdScanTitle")}
                      role="img"
                      dangerouslySetInnerHTML={{ __html: start.qrSvg }}
                    />
                  ) : null}
                  {/* corner marks — the premium scan frame */}
                  <span className="pointer-events-none absolute start-1.5 top-1.5 h-5 w-5 rounded-tl-md border-s-2 border-t-2 border-brand-500/50" aria-hidden="true" />
                  <span className="pointer-events-none absolute end-1.5 top-1.5 h-5 w-5 rounded-tr-md border-e-2 border-t-2 border-brand-500/50" aria-hidden="true" />
                  <span className="pointer-events-none absolute bottom-1.5 start-1.5 h-5 w-5 rounded-bl-md border-b-2 border-s-2 border-brand-500/50" aria-hidden="true" />
                  <span className="pointer-events-none absolute bottom-1.5 end-1.5 h-5 w-5 rounded-br-md border-b-2 border-e-2 border-brand-500/50" aria-hidden="true" />
                  {/* the waiting pulse — proves the poller is live */}
                  {!expired ? (
                    <span
                      className="pointer-events-none absolute inset-0 animate-ping rounded-xl bg-brand-400/5"
                      style={{ animationDuration: "2.6s" }}
                      aria-hidden="true"
                    />
                  ) : null}
                </div>

                {/* the waiting line + countdown */}
                <div className="mt-3 flex items-center justify-center gap-2">
                  {expired ? (
                    <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-200 bg-amber-50 px-3 py-1 text-[11px] font-bold text-amber-600 dark:border-amber-500/25 dark:bg-amber-500/10 dark:text-amber-300">
                      <CatIcon name="clock" className="h-3 w-3" />
                      {t("cdExpired")}
                    </span>
                  ) : (
                    <>
                      <CatIcon name="refresh-cw" className="h-3 w-3 animate-spin text-brand-400" />
                      <span className="text-[11.5px] font-bold text-slate-500 dark:text-slate-400">
                        {secondsLeft !== null ? t("cdExpiresIn", { s: String(secondsLeft) }) : t("cdWaitingTitle")}
                      </span>
                    </>
                  )}
                </div>
                <p className="mt-1.5 text-center text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                  {t("cdWaitingSub")}
                </p>
              </div>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
