"use client";

/**
 * Ashrilogic — 401 (unauthorized) view.
 *
 * Client component consumed by the server-side `src/app/unauthorized.tsx`
 * wrapper. Renders the giant "401" gradient number, the localized title
 * and description, a "Back to home" action, plus the support card.
 */
import { ErrorShell } from "@/components/error-pages/error-shell";
import { CatIcon } from "@/components/icon";
import { Button } from "@/components/ui/button";
import { useT } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";

export function UnauthorizedView() {
  const { t, lang } = useT();
  const exitToLanding = useAppStore((s) => s.exitToLanding);

  return (
    <ErrorShell
      code="401"
      icon="lock"
      title={t("err401Title")}
      desc={t("err401Desc")}
      role="alert"
      ariaLabel={t("err401Title")}
    >
      <Button
        type="button"
        onClick={exitToLanding}
        className="inline-flex items-center gap-2 rounded-xl bg-linear-to-br from-brand-500 via-fuchsia-500 to-cyan-400 px-5 py-2.5 text-[13px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
      >
        <CatIcon name={lang === "ar" ? "arrow-left" : "arrow-right"} className="h-4 w-4" />
        {t("errGoHome")}
      </Button>
    </ErrorShell>
  );
}
