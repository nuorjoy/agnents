"use client";

/**
 * Ashrilogic — shared layout for the 404 / 401 / 500 error pages.
 *
 * Renders the decorative mesh background, the floating gradient code number,
 * the icon badge, the title/description, the action buttons (passed as
 * children) and the glass support card (SupportChannels + SocialLinks).
 *
 * Kept as a single client component so the three error routes stay
 * visually consistent and any future tweak lands in one place.
 */
import type { ReactNode } from "react";
import { MotionConfig, motion } from "framer-motion";
import { CatIcon } from "@/components/icon";
import { SocialLinks, SupportChannels } from "@/components/social-links";
import { useT } from "@/lib/i18n";

export interface ErrorShellProps {
  /** the big gradient number — 404 / 401 / 500 */
  code: string;
  /** kebab-case lucide icon name for the badge above the number */
  icon: string;
  /** localized heading */
  title: string;
  /** localized description paragraph */
  desc: string;
  /** action buttons row */
  children?: ReactNode;
  /** optional extra block rendered between the actions and the support card
   *  (used by the 500 page to surface the trace id chip) */
  afterActions?: ReactNode;
  /** ARIA role for the outer region (e.g. "alert" for runtime errors) */
  role?: string;
  /** ARIA label for the outer region */
  ariaLabel?: string;
}

export function ErrorShell({
  code,
  icon,
  title,
  desc,
  children,
  afterActions,
  role,
  ariaLabel,
}: ErrorShellProps) {
  const { t } = useT();

  return (
    <MotionConfig reducedMotion="user">
    <div
      className="relative flex min-h-screen flex-col items-center justify-center px-4 py-14 sm:px-6"
      role={role}
      aria-label={ariaLabel}
    >
      {/* decorative mesh background */}
      <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden />

      <div className="w-full max-w-2xl text-center">
        {/* icon badge */}
        <motion.div
          initial={{ opacity: 0, scale: 0.7 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
          className="mx-auto mb-6 grid h-16 w-16 place-items-center rounded-2xl bg-linear-to-br from-brand-500 via-fuchsia-500 to-cyan-400 text-white shadow-lg shadow-brand-500/30"
        >
          <CatIcon name={icon} className="h-7 w-7" />
        </motion.div>

        {/* big gradient number — floats gently */}
        <motion.h1
          aria-hidden="true"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: [0, -8, 0] }}
          transition={{
            opacity: { duration: 0.5 },
            y: { duration: 3.4, repeat: Infinity, ease: "easeInOut" },
          }}
          className="bg-clip-text text-transparent bg-linear-to-br from-brand-500 via-fuchsia-500 to-cyan-400 font-display text-[120px] font-extrabold leading-none tracking-tight sm:text-[180px]"
        >
          {code}
        </motion.h1>

        <h2 className="mt-3 font-display text-2xl font-extrabold text-slate-800 dark:text-slate-100 sm:text-3xl">
          {title}
        </h2>
        <p className="mx-auto mt-3 max-w-md text-[14px] leading-relaxed text-slate-500 dark:text-slate-400 sm:text-[15px]">
          {desc}
        </p>

        {children && (
          <div className="mt-7 flex flex-wrap items-center justify-center gap-2.5">
            {children}
          </div>
        )}

        {afterActions}

        {/* support section */}
        <section
          aria-label={t("errSupportTitle")}
          className="mt-12 rounded-3xl border border-slate-200/80 bg-white/70 p-6 backdrop-blur-sm dark:border-white/10 dark:bg-white/[0.03] sm:p-8"
        >
          <div>
            <h3 className="font-display text-lg font-extrabold text-slate-800 dark:text-slate-100">
              {t("errSupportTitle")}
            </h3>
            <p className="mx-auto mt-1.5 max-w-md text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("errSupportDesc")}
            </p>
          </div>
          <div className="mt-5">
            <SupportChannels />
          </div>
          <div className="mt-4">
            <SocialLinks variant="labeled" />
          </div>
        </section>
      </div>
    </div>
    </MotionConfig>
  );
}
