"use client";

/**
 * Ashrilogic — ROUND 45/46 — Premium security cards (2FA · Passkeys · Sessions).
 *
 * One shared implementation backs BOTH surfaces:
 *  - the CONTROL PANEL settings (scope "admin" — the signed-in admin account)
 *  - the TENANT workspace settings (scope "instance" — the workspace account)
 *
 * Three cards:
 *  1. TwoFactorCard — TOTP enrollment (PREMIUM emerald QR + 6-box OTP input
 *     with paste support and international digit normalization + one-time
 *     backup codes), code-gated disable, backup regeneration.
 *  2. PasskeysCard — WebAuthn/Passkey registration (browser prompt), a
 *     cross-device violet QR (scan with a phone to enroll there), list,
 *     removal. The private key never leaves the user's authenticator; the
 *     server stores only public keys (never serialized to the client).
 *  3. SessionsCard — active sessions with device kind/browser/OS chips, IP
 *     copy, first-seen/last-active/expiry detail, per-device sign-out,
 *     "sign out everywhere else" and a confirmed "sign out EVERYWHERE".
 *
 * All texts flow through the i18n dictionary (ar/en/hi parity).
 */
import { useEffect, useMemo, useRef, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { startAuthentication, startRegistration } from "@simplewebauthn/browser";
import { useT } from "@/lib/i18n";
import type { I18nKey } from "@/lib/i18n";
import type {
  MfaSetupDTO,
  MfaStatusDTO,
  SessionInfoDTO,
  WebauthnCredentialDTO,
} from "@/lib/types";
import { ApiError } from "@/lib/api-client";
import {
  confirmAdminMfaSetup,
  confirmInstanceMfaSetup,
  fetchAdminMfaStatus,
  fetchAdminPasskeys,
  fetchAdminSessions,
  fetchInstanceMfaStatus,
  fetchInstancePasskeys,
  fetchInstanceSessions,
  manageAdminMfa,
  manageInstanceMfa,
  removeAdminPasskey,
  removeInstancePasskey,
  revokeAdminSession,
  revokeInstanceSession,
  revokeOtherAdminSessions,
  revokeOtherInstanceSessions,
  signOutEverywhereAdmin,
  signOutEverywhereInstance,
  startAdminMfaSetup,
  startInstanceMfaSetup,
  finishAdminPasskey,
  finishInstancePasskey,
  /* ROUND 158 — platform IP banlist */
  fetchBannedIps,
  banIp,
  unbanIp,
  type BannedIpDTO,
} from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, grad } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { DashCard, IconTile } from "@/components/dashboard/dash-shared";

/** Which account surface the cards operate on. */
export type SecurityScope =
  | { kind: "admin" }
  | { kind: "instance"; instanceId: string };

/* --------------------------- tiny shared pieces -------------------------- */

function CopyChip({ value, label, title }: { value: string; label?: string; title?: string }) {
  const { t } = useT();
  return (
    <button
      type="button"
      onClick={() => {
        void navigator.clipboard.writeText(value).then(() => toast.success(t("secCopied")));
      }}
      title={title ?? t("secCopyTip")}
      className="group inline-flex max-w-full items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-1 font-mono text-[11.5px] font-bold text-slate-700 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-200 dark:hover:text-brand-300"
    >
      <span className="truncate" dir="ltr">
        {label || value}
      </span>
      <CatIcon name="copy" className="h-3 w-3 shrink-0 opacity-50 transition group-hover:opacity-100" />
      <span className="sr-only">{title ?? t("secCopyTip")}</span>
    </button>
  );
}

/** relative, localized "x minutes ago" for session rows */
function relTime(iso: string, lang: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.max(0, Math.round(diffMs / 60_000));
  const locale = lang === "ar" ? "ar-EG" : "en-US";
  const rtf = new Intl.RelativeTimeFormat(locale, { numeric: "auto" });
  if (mins < 1) return rtf.format(0, "minute");
  if (mins < 60) return rtf.format(-mins, "minute");
  const hours = Math.round(mins / 60);
  if (hours < 24) return rtf.format(-hours, "hour");
  return rtf.format(-Math.round(hours / 24), "day");
}

/**
 * ROUND 46 — INTERNATIONAL DIGIT NORMALIZATION.
 * Arabic-Indic (٠١٢٣٤٥٦٧٨٩), Eastern Arabic-Indic (۰۱۲۳۴۵۶۷۸۹), Devanagari
 * (०१२३४५६७८९) and fullwidth digits all map to ASCII 0-9, so a user typing
 * with an Arabic/Hindi keyboard still produces a code every authenticator
 * and every API accepts — the "international number format" rule.
 */
const DIGIT_TRANSLATION: Record<string, string> = {
  "٠": "0", "١": "1", "٢": "2", "٣": "3", "٤": "4", "٥": "5", "٦": "6", "٧": "7", "٨": "8", "٩": "9",
  "۰": "0", "۱": "1", "۲": "2", "۳": "3", "۴": "4", "۵": "5", "۶": "6", "۷": "7", "۸": "8", "۹": "9",
  "०": "0", "१": "1", "२": "2", "३": "3", "४": "4", "५": "5", "६": "6", "७": "7", "८": "8", "९": "9",
  "０": "0", "１": "1", "２": "2", "３": "3", "４": "4", "５": "5", "６": "6", "７": "7", "８": "8", "９": "9",
};
export function normalizeDigits(raw: string): string {
  return raw.replace(/[٠-٩۰-९０-９]/g, (ch) => DIGIT_TRANSLATION[ch] ?? ch);
}

/* ====================== ROUND 46 — premium OTP input ====================== */

/**
 * Six boxed digit inputs with production-grade behavior:
 *  - PASTE: a pasted code (with or without spaces/separators) spreads across
 *    the boxes and reports completeness via onPasteComplete.
 *  - INTERNATIONAL: Arabic-Indic/Eastern/Devanagari/fullwidth digits are
 *    normalized to ASCII as they are typed or pasted.
 *  - KEYBOARD: auto-advance on digit, backspace hops back, arrow keys move,
 *    Home/End jump; inputMode numeric keeps phone keypads numeric.
 *  - ROUND 168 — ANTI-AUTOFILL (the owner's directive: «عند الـ(Pin Code)
 *    اجعل حقول الإدخال نظيفة دون وجود اي ادخال مسبقاً هناك نقطة تظهر داخل
 *    حقل الإدخال احذفه»): the stray dot + pre-fill inside the first box was
 *    Chrome injecting the SAVED PASSWORD / autofill strong-password into an
 *    unnamed heuristic-friendly field. Every box is now armored:
 *      · autoComplete: box 0 = "one-time-code" (the OTP contract, kept),
 *        boxes 1-5 = "new-password" — Chrome never saved-password-fills a
 *        new-password field ("off" is simply ignored by Chrome);
 *      · explicit name={otp-box-N} (unnamed inputs invite heuristic fills);
 *      · autoCorrect/autoCapitalize off + spellCheck={false} (IME hygiene);
 *      · dir="ltr" PER INPUT — typing always starts left-to-right box 1→6
 *        regardless of the page locale (the global-direction law);
 *      · NO placeholder attribute, and the controlled value stays "" on
 *        mount — the boxes render genuinely clean.
 */
export function OtpInput({
  value,
  onChange,
  onComplete,
  onEnter,
  disabled,
  autoFocus,
  invalid,
  idPrefix = "otp",
}: {
  value: string;
  onChange: (next: string) => void;
  /** fires whenever the 6 digits become complete (typing or paste) */
  onComplete?: (code: string) => void;
  /** Enter key pressed with a complete code */
  onEnter?: (code: string) => void;
  disabled?: boolean;
  autoFocus?: boolean;
  invalid?: boolean;
  idPrefix?: string;
}) {
  const { t } = useT();
  const refs = useRef<(HTMLInputElement | null)[]>([]);
  const boxes = useMemo(() => Array.from({ length: 6 }, (_, i) => value[i] ?? ""), [value]);

  useEffect(() => {
    if (autoFocus) refs.current[0]?.focus();
  }, [autoFocus]);

  /** distribute a raw pasted string across the boxes */
  const ingest = (raw: string, from: number, focusEnd = true) => {
    const digits = normalizeDigits(raw).replace(/\D/g, "");
    if (!digits) return 0;
    const next = (value.slice(0, from) + digits).slice(0, 6).padEnd(Math.min(6, from + digits.length), value.slice(from + digits.length));
    const filled = Math.min(6, from + digits.length);
    const merged = (next.slice(0, from) + digits + value.slice(filled)).slice(0, 6);
    const clean = merged.replace(/\s/g, "").slice(0, 6);
    onChange(clean);
    if (focusEnd && clean.length === 6) {
      refs.current[5]?.blur();
      onComplete?.(clean);
    } else if (focusEnd) {
      refs.current[Math.min(5, filled)]?.focus();
    }
    return Math.min(digits.length, 6 - from);
  };

  return (
    <div
      role="group"
      aria-label={t("otpAriaLabel")}
      className="flex items-center justify-center gap-1.5 sm:gap-2"
      dir="ltr"
      onPaste={(e) => {
        e.preventDefault();
        const text = e.clipboardData.getData("text");
        const accepted = ingest(text, 0);
        if (text.replace(/\D/g, "").length >= 6) toast.success(t("otpPasteOk"));
        else if (accepted > 0) toast.info(t("otpPastePartial", { n: String(accepted) }));
      }}
    >
      {boxes.map((digit, i) => (
        <input
          key={i}
          ref={(el) => {
            refs.current[i] = el;
          }}
          id={`${idPrefix}-${i}`}
          name={`otp-box-${i}`}
          type="text"
          inputMode="numeric"
          autoComplete={i === 0 ? "one-time-code" : "new-password"}
          autoCorrect="off"
          autoCapitalize="off"
          spellCheck={false}
          dir="ltr"
          maxLength={1}
          disabled={disabled}
          aria-invalid={invalid || undefined}
          value={digit}
          onChange={(e) => {
            const raw = e.target.value;
            if (raw.length <= 1) {
              const d = normalizeDigits(raw).replace(/\D/g, "");
              const next = value.split("");
              next[i] = d;
              const clean = next.join("").slice(0, 6);
              // typing over a filled box advances; empty box keeps length
              onChange(clean);
              if (d && i < 5) refs.current[i + 1]?.focus();
              if (clean.replace(/\s/g, "").length === 6 && d) onComplete?.(clean);
            } else {
              /* typed/pasted straight into one box (Android IMEs) */
              ingest(raw, i);
            }
          }}
          onKeyDown={(e) => {
            if (e.key === "Backspace" && !boxes[i] && i > 0) {
              e.preventDefault();
              const next = value.split("");
              next[i - 1] = "";
              onChange(next.join("").slice(0, 6));
              refs.current[i - 1]?.focus();
            } else if (e.key === "ArrowLeft" && i > 0) {
              e.preventDefault();
              refs.current[i - 1]?.focus();
            } else if (e.key === "ArrowRight" && i < 5) {
              e.preventDefault();
              refs.current[i + 1]?.focus();
            } else if (e.key === "Home" && i !== 0) {
              e.preventDefault();
              refs.current[0]?.focus();
            } else if (e.key === "End" && i !== 5) {
              e.preventDefault();
              refs.current[5]?.focus();
            } else if (e.key === "Enter" && value.replace(/\s/g, "").length === 6) {
              e.preventDefault();
              onEnter?.(value);
            }
          }}
          className={cn(
            "h-12 w-10 rounded-xl border-2 bg-white text-center font-display text-[20px] font-black text-slate-800 shadow-sm outline-none transition-all sm:h-13 sm:w-11",
            "focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/20 focus:shadow-lg focus:shadow-emerald-500/10",
            invalid
              ? "border-rose-300 dark:border-rose-500/50"
              : digit
                ? "border-emerald-400/80 dark:border-emerald-500/50"
                : "border-slate-200 dark:border-white/15",
            disabled && "opacity-60",
            "dark:bg-white/[0.05] dark:text-slate-100"
          )}
        />
      ))}
    </div>
  );
}

/* ===================== ROUND 46 — premium QR frame ======================= */

/**
 * Premium QR presentation: gradient ring + corner accents + a centered brand
 * badge. The QR itself is rendered server-side at error-correction level H
 * (30% redundancy) so the small center badge never breaks a scan.
 * ROUND 56 — exported for reuse by the passkey LOGIN QR dialog.
 */
export function PremiumQr({
  svg,
  c1,
  c2,
  icon,
  aria,
  size = "lg",
}: {
  svg: string;
  c1: string;
  c2: string;
  icon: string;
  aria: string;
  size?: "lg" | "md";
}) {
  return (
    <span
      className="relative inline-grid shrink-0 place-items-center rounded-[22px] p-[3px] shadow-xl"
      style={{ backgroundImage: grad(c1, c2) }}
      aria-label={aria}
      role="img"
    >
      {/* corner accents */}
      <span
        className="pointer-events-none absolute -start-1 -top-1 h-4 w-4 rounded-tl-[10px] border-s-2 border-t-2"
        style={{ borderColor: c1 }}
        aria-hidden="true"
      />
      <span
        className="pointer-events-none absolute -end-1 -top-1 h-4 w-4 rounded-tr-[10px] border-e-2 border-t-2"
        style={{ borderColor: c2 }}
        aria-hidden="true"
      />
      <span
        className="pointer-events-none absolute -bottom-1 -start-1 h-4 w-4 rounded-bl-[10px] border-b-2 border-s-2"
        style={{ borderColor: c2 }}
        aria-hidden="true"
      />
      <span
        className="pointer-events-none absolute -bottom-1 -end-1 h-4 w-4 rounded-br-[10px] border-b-2 border-e-2"
        style={{ borderColor: c1 }}
        aria-hidden="true"
      />
      <span
        className={cn(
          "grid place-items-center overflow-hidden rounded-[19px] bg-white p-2",
          size === "lg" ? "h-40 w-40" : "h-32 w-32"
        )}
      >
        <span
          className="h-full w-full [&>svg]:h-full [&>svg]:w-full"
          dangerouslySetInnerHTML={{ __html: svg }}
        />
      </span>
      {/* centered brand badge — covered by ECC level H */}
      <span
        className="absolute grid h-10 w-10 place-items-center rounded-xl text-white shadow-lg ring-4 ring-white"
        style={{ backgroundImage: grad(c1, c2) }}
        aria-hidden="true"
      >
        <CatIcon name={icon} className="h-[15px] w-[15px]" />
      </span>
    </span>
  );
}

/* ============================== 2FA card ================================ */

export function TwoFactorCard({ scope }: { scope: SecurityScope }) {
  const { t, lang } = useT();
  const isInstance = scope.kind === "instance";
  const statusKey = ["mfa-status", scope.kind, "instanceId" in scope ? scope.instanceId : null];

  const statusQuery = useQuery({
    queryKey: statusKey,
    queryFn: () =>
      isInstance ? fetchInstanceMfaStatus(scope.instanceId) : fetchAdminMfaStatus(),
  });

  /* enrollment dialog state */
  const [setupOpen, setSetupOpen] = useState(false);
  const [setup, setSetup] = useState<MfaSetupDTO | null>(null);
  const [setupCode, setSetupCode] = useState("");
  const [backupCodes, setBackupCodes] = useState<string[] | null>(null);
  const [disableOpen, setDisableOpen] = useState(false);
  const [manageCode, setManageCode] = useState("");
  const [regenOpen, setRegenOpen] = useState(false);

  const refresh = () => {
    void statusQuery.refetch();
  };

  const startSetup = useMutation({
    mutationFn: () =>
      isInstance ? startInstanceMfaSetup(scope.instanceId) : startAdminMfaSetup(),
    onSuccess: (data) => {
      setSetup(data);
      setSetupCode("");
      setBackupCodes(null);
      setSetupOpen(true);
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  const confirmSetup = useMutation({
    mutationFn: (code: string) =>
      isInstance
        ? confirmInstanceMfaSetup(scope.instanceId, code)
        : confirmAdminMfaSetup(code),
    onSuccess: (data) => {
      setBackupCodes(data.backupCodes);
      setSetupCode("");
      refresh();
      toast.success(t("sec2faEnabledToast"));
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  const disable = useMutation({
    mutationFn: () =>
      isInstance
        ? manageInstanceMfa(scope.instanceId, "disable", manageCode.trim())
        : manageAdminMfa("disable", manageCode.trim()),
    onSuccess: () => {
      setDisableOpen(false);
      setManageCode("");
      refresh();
      toast.success(t("sec2faDisabledToast"));
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  const regen = useMutation({
    mutationFn: () =>
      isInstance
        ? manageInstanceMfa(scope.instanceId, "regenerate-backups", manageCode.trim())
        : manageAdminMfa("regenerate-backups", manageCode.trim()),
    onSuccess: (data) => {
      setRegenOpen(false);
      setManageCode("");
      setBackupCodes(data.backupCodes ?? []);
      setSetup(null);
      setSetupOpen(true);
      refresh();
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  const status: MfaStatusDTO | undefined = statusQuery.data;
  const codeReady = normalizeDigits(setupCode).replace(/\D/g, "").length === 6;

  return (
    <DashCard title={t("sec2faTitle")} icon="shield-check">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0 max-w-xl space-y-2.5">
          <p className="text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
            {t("sec2faDesc")}
          </p>
          <div className="flex flex-wrap items-center gap-2">
            <span
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[11px] font-extrabold",
                status?.enabled
                  ? "border-emerald-300/70 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
                  : "border-slate-300/70 bg-slate-500/10 text-slate-500 dark:border-white/10 dark:text-slate-400"
              )}
            >
              <span
                className={cn(
                  "h-1.5 w-1.5 rounded-full",
                  status?.enabled ? "animate-pulse bg-emerald-500" : "bg-slate-400"
                )}
                aria-hidden="true"
              />
              {t(status?.enabled ? "sec2faOn" : "sec2faOff")}
            </span>
            {status?.enabled ? (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-3 py-1 text-[10.5px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300">
                <CatIcon name="key-round" className="h-3 w-3" />
                {t("secBackupsLeft", { n: String(status.backupCodesLeft) })}
              </span>
            ) : null}
          </div>
        </div>

        <div className="flex shrink-0 flex-wrap items-center gap-2">
          {status?.enabled ? (
            <>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => {
                  setManageCode("");
                  setRegenOpen(true);
                }}
                className="h-9 gap-1.5 rounded-xl px-3.5 text-[11.5px] font-bold"
              >
                <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
                {t("secRegenBackups")}
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => {
                  setManageCode("");
                  setDisableOpen(true);
                }}
                className="h-9 gap-1.5 rounded-xl px-3.5 text-[11.5px] font-bold text-rose-500 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-500/10"
              >
                <CatIcon name="shield-off" className="h-3.5 w-3.5" />
                {t("sec2faDisable")}
              </Button>
            </>
          ) : (
            <Button
              type="button"
              size="sm"
              onClick={() => startSetup.mutate()}
              disabled={startSetup.isPending}
              className="h-9 gap-1.5 rounded-xl px-4 text-[11.5px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:brightness-110"
              style={{ backgroundImage: grad("#10b981", "#059669") }}
            >
              <CatIcon
                name={startSetup.isPending ? "refresh-cw" : "shield-plus"}
                className={cn("h-3.5 w-3.5", startSetup.isPending && "animate-spin")}
              />
              {t("sec2faEnable")}
            </Button>
          )}
        </div>
      </div>

      {/* ------------------------- enrollment dialog ------------------------- */}
      <Dialog open={setupOpen} onOpenChange={(open) => !open && setSetupOpen(false)}>
        <DialogContent className="max-w-lg gap-0 p-0" dir={lang === "ar" ? "rtl" : "ltr"}>
          <DialogHeader className="border-b border-slate-200/70 px-5 py-4 dark:border-white/[0.07]">
            <DialogTitle className="flex items-center gap-2 text-[14px] font-extrabold text-slate-900 dark:text-white">
              <IconTile icon="shield-check" c1="#10b981" c2="#059669" />
              {t(backupCodes ? "secBackupsTitle" : "sec2faSetupTitle")}
            </DialogTitle>
            <DialogDescription className="text-[11.5px] leading-relaxed text-slate-500 dark:text-slate-400">
              {backupCodes ? t("secBackupsDesc") : t("sec2faSetupDesc")}
            </DialogDescription>
          </DialogHeader>

          {backupCodes ? (
            <div className="space-y-4 px-5 py-5">
              <div className="grid grid-cols-2 gap-2" dir="ltr">
                {backupCodes.map((code) => (
                  <CopyChip key={code} value={code} label={code} />
                ))}
              </div>
              <div className="flex items-start gap-2.5 rounded-2xl border border-amber-300/60 bg-amber-500/10 p-3 dark:border-amber-500/20">
                <CatIcon name="triangle-alert" className="mt-0.5 h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400" />
                <p className="text-[11px] leading-relaxed text-amber-700 dark:text-amber-300">
                  {t("secBackupsWarning")}
                </p>
              </div>
              <Button
                type="button"
                onClick={() => {
                  setSetupOpen(false);
                  setBackupCodes(null);
                  setSetup(null);
                }}
                className="h-10 w-full rounded-xl text-[12.5px] font-extrabold text-white shadow-lg shadow-emerald-500/25"
                style={{ backgroundImage: grad("#10b981", "#059669") }}
              >
                <CatIcon name="check" className="h-4 w-4" />
                {t("secBackupsDone")}
              </Button>
            </div>
          ) : setup ? (
            <div className="space-y-4 px-5 py-5">
              <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-start">
                {/* premium emerald QR with centered badge */}
                <PremiumQr
                  svg={setup.qrSvg}
                  c1="#10b981"
                  c2="#047857"
                  icon="shield-check"
                  aria={t("secQrAria")}
                />
                <div className="min-w-0 flex-1 space-y-2.5">
                  <p className="text-[12px] leading-relaxed text-slate-600 dark:text-slate-300">
                    {t("secScanHint")}
                  </p>
                  <p className="text-[10.5px] font-bold leading-relaxed text-emerald-600 dark:text-emerald-400">
                    {t("secQrPremiumHint")}
                  </p>
                  <div className="space-y-1.5">
                    <p className="text-[10.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                      {t("secManualKey")}
                    </p>
                    <CopyChip value={setup.secret} label={setup.secret} />
                  </div>
                </div>
              </div>

              {/* ROUND 46 — six boxed OTP inputs: paste + international digits */}
              <div className="space-y-2">
                <Label htmlFor="otp-0" className="flex items-center justify-between text-[12px] font-bold">
                  <span>
                    {t("secCodeLabel")} <span className="text-rose-500">*</span>
                  </span>
                  <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500">
                    {t("otpAriaLabel")}
                  </span>
                </Label>
                <OtpInput
                  idPrefix="otp"
                  value={setupCode}
                  onChange={setSetupCode}
                  disabled={confirmSetup.isPending}
                  invalid={confirmSetup.isError}
                  onComplete={(code) => confirmSetup.mutate(code)}
                  onEnter={(code) => confirmSetup.mutate(code)}
                  autoFocus
                />
              </div>
              <Button
                type="button"
                disabled={!codeReady || confirmSetup.isPending}
                onClick={() => confirmSetup.mutate(normalizeDigits(setupCode))}
                className="h-10 w-full rounded-xl text-[12.5px] font-extrabold text-white shadow-lg shadow-emerald-500/25 disabled:opacity-50"
                style={{ backgroundImage: grad("#10b981", "#059669") }}
              >
                <CatIcon
                  name={confirmSetup.isPending ? "refresh-cw" : "shield-check"}
                  className={cn("h-4 w-4", confirmSetup.isPending && "animate-spin")}
                />
                {t("sec2faConfirm")}
              </Button>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>

      {/* --------------------------- disable dialog --------------------------- */}
      <Dialog open={disableOpen} onOpenChange={setDisableOpen}>
        <DialogContent className="max-w-sm gap-0 p-0" dir={lang === "ar" ? "rtl" : "ltr"}>
          <DialogHeader className="border-b border-slate-200/70 px-5 py-4 dark:border-white/[0.07]">
            <DialogTitle className="flex items-center gap-2 text-[14px] font-extrabold text-slate-900 dark:text-white">
              <IconTile icon="shield-off" c1="#f43f5e" c2="#e11d48" />
              {t("sec2faDisable")}
            </DialogTitle>
            <DialogDescription className="text-[11.5px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("sec2faDisableDesc")}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3.5 px-5 py-5">
            <div className="space-y-1.5">
              <Label htmlFor="sec-disable-code" className="text-[12px] font-bold">
                {t("secCodeLabel")} <span className="text-rose-500">*</span>
              </Label>
              <Input
                id="sec-disable-code"
                dir="ltr"
                value={manageCode}
                onChange={(e) => setManageCode(normalizeDigits(e.target.value.trim()).slice(0, 20))}
                placeholder="123456 / ABCD-1234"
                className="h-10 rounded-xl text-center font-bold tracking-wider"
              />
            </div>
            <Button
              type="button"
              disabled={manageCode.length < 4 || disable.isPending}
              onClick={() => disable.mutate()}
              className="h-10 w-full rounded-xl text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 disabled:opacity-50"
              style={{ backgroundImage: grad("#f43f5e", "#e11d48") }}
            >
              <CatIcon name={disable.isPending ? "refresh-cw" : "shield-off"} className={cn("h-4 w-4", disable.isPending && "animate-spin")} />
              {t("sec2faDisableConfirm")}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* -------------------------- regenerate dialog -------------------------- */}
      <Dialog open={regenOpen} onOpenChange={setRegenOpen}>
        <DialogContent className="max-w-sm gap-0 p-0" dir={lang === "ar" ? "rtl" : "ltr"}>
          <DialogHeader className="border-b border-slate-200/70 px-5 py-4 dark:border-white/[0.07]">
            <DialogTitle className="flex items-center gap-2 text-[14px] font-extrabold text-slate-900 dark:text-white">
              <IconTile icon="refresh-cw" c1="#f59e0b" c2="#ea580c" />
              {t("secRegenBackups")}
            </DialogTitle>
            <DialogDescription className="text-[11.5px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("secRegenDesc")}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3.5 px-5 py-5">
            <div className="space-y-1.5">
              <Label htmlFor="sec-regen-code" className="text-[12px] font-bold">
                {t("secCodeLabel")} <span className="text-rose-500">*</span>
              </Label>
              <Input
                id="sec-regen-code"
                dir="ltr"
                value={manageCode}
                onChange={(e) => setManageCode(normalizeDigits(e.target.value.trim()).slice(0, 20))}
                placeholder="123456"
                className="h-10 rounded-xl text-center font-bold tracking-wider"
              />
            </div>
            <Button
              type="button"
              disabled={manageCode.length < 4 || regen.isPending}
              onClick={() => regen.mutate()}
              className="h-10 w-full rounded-xl text-[12.5px] font-extrabold text-white shadow-lg shadow-amber-500/25 disabled:opacity-50"
              style={{ backgroundImage: grad("#f59e0b", "#ea580c") }}
            >
              <CatIcon name={regen.isPending ? "refresh-cw" : "key-round"} className={cn("h-4 w-4", regen.isPending && "animate-spin")} />
              {t("secRegenConfirm")}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </DashCard>
  );
}

/* ============================ passkeys card ============================= */

export function PasskeysCard({ scope }: { scope: SecurityScope }) {
  const { t, lang } = useT();
  const isInstance = scope.kind === "instance";
  const listKey = ["passkeys", scope.kind, "instanceId" in scope ? scope.instanceId : null];

  const listQuery = useQuery({
    queryKey: listKey,
    queryFn: () =>
      isInstance ? fetchInstancePasskeys(scope.instanceId) : fetchAdminPasskeys(),
  });

  const [addOpen, setAddOpen] = useState(false);
  const [name, setName] = useState("");
  const [registering, setRegistering] = useState(false);
  /* ROUND 46 — cross-device QR fetched when the dialog opens */
  const [crossQr, setCrossQr] = useState<string | null>(null);

  const credentials: WebauthnCredentialDTO[] = listQuery.data?.credentials ?? [];

  const refresh = () => {
    void listQuery.refetch();
  };

  /* fetch the cross-device QR (server validates the URL is same-origin) */
  useEffect(() => {
    if (!addOpen) {
      setCrossQr(null);
      return;
    }
    let cancelled = false;
    void (async () => {
      try {
        const res = await fetch(
          isInstance
            ? `/api/instances/${encodeURIComponent(scope.instanceId)}/passkeys`
            : "/api/admin/passkeys",
          {
            method: "POST",
            credentials: "same-origin",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ returnTo: window.location.pathname }),
          }
        );
        if (!res.ok) return;
        const data = (await res.json()) as { crossDeviceQr?: string };
        if (!cancelled && typeof data.crossDeviceQr === "string") setCrossQr(data.crossDeviceQr);
      } catch {
        /* the QR is an enhancement — ignore failures */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [addOpen, isInstance, scope]);

  /** the whole browser ceremony: options → prompt → verify → persist */
  const register = async () => {
    if (registering) return;
    const label = name.trim() || t("secPasskeyDefaultName");
    setRegistering(true);
    try {
      /* STEP 1 — creation options from the server */
      const optionsRes = await fetch(
        isInstance
          ? `/api/instances/${encodeURIComponent(scope.instanceId)}/passkeys`
          : "/api/admin/passkeys",
        {
          method: "POST",
          credentials: "same-origin",
          headers: { "Content-Type": "application/json" },
          body: "{}",
        }
      );
      if (!optionsRes.ok) {
        const data = (await optionsRes.json().catch(() => ({}))) as { error?: string };
        throw new Error(data.error ?? "Failed to start");
      }
      const { options } = (await optionsRes.json()) as {
        options: Parameters<typeof startRegistration>[0]["optionsJSON"];
      };

      /* STEP 2 — the browser ceremony (Touch ID / Windows Hello / key) */
      const attestation = await startRegistration({ optionsJSON: options });

      /* STEP 3 — server verifies + persists the public key */
      if (isInstance) {
        await finishInstancePasskey(scope.instanceId, label, attestation);
      } else {
        await finishAdminPasskey(label, attestation);
      }
      toast.success(t("secPasskeyAdded"));
      setAddOpen(false);
      setName("");
      refresh();
    } catch (error) {
      const message =
        error instanceof Error && error.name === "NotAllowedError"
          ? t("secPasskeyCancelled")
          : error instanceof Error || error instanceof ApiError
            ? error.message
            : t("errorText");
      toast.error(message);
    } finally {
      setRegistering(false);
    }
  };

  const remove = useMutation({
    mutationFn: (credentialId: string) =>
      isInstance
        ? removeInstancePasskey(scope.instanceId, credentialId)
        : removeAdminPasskey(credentialId),
    onSuccess: () => {
      toast.success(t("secPasskeyRemoved"));
      refresh();
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  return (
    <DashCard title={t("secPasskeysTitle")} icon="fingerprint">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0 max-w-xl space-y-2.5">
          <p className="text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
            {t("secPasskeysDesc")}
          </p>
          {credentials.length > 0 ? (
            <ul className="space-y-2">
              {credentials.map((cred) => (
                <li
                  key={cred.id}
                  className="flex items-center gap-3 rounded-2xl border border-slate-200/80 bg-slate-50/40 p-3 dark:border-white/10 dark:bg-white/[0.02]"
                >
                  <span
                    className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
                    style={{ backgroundImage: grad("#6d5dfb", "#a855f7") }}
                  >
                    <CatIcon name="fingerprint" className="h-[13px] w-[13px]" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                      {cred.name}
                      {cred.backedUp ? (
                        <span className="ms-2 inline-flex items-center gap-1 rounded-full bg-cyan-500/10 px-1.5 py-px text-[11px] font-extrabold text-cyan-600 dark:text-cyan-300">
                          <CatIcon name="cloud" className="h-2.5 w-2.5" />
                          {t("secPasskeySynced")}
                        </span>
                      ) : null}
                    </p>
                    <p className="truncate text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                      {t("secPasskeyLastUsed", {
                        when: cred.lastUsedAt ? relTime(cred.lastUsedAt, lang) : t("secNever"),
                      })}
                    </p>
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => remove.mutate(cred.id)}
                    disabled={remove.isPending}
                    aria-label={t("secPasskeyRemove")}
                    className="h-8 w-8 shrink-0 rounded-lg p-0 text-slate-400 transition hover:bg-rose-50 hover:text-rose-500 dark:hover:bg-rose-500/10"
                  >
                    <CatIcon name="trash" className="h-3.5 w-3.5" />
                  </Button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="flex items-center gap-2 rounded-2xl border border-dashed border-slate-300/70 p-3 text-[11.5px] font-semibold text-slate-400 dark:border-white/10 dark:text-slate-500">
              <CatIcon name="info" className="h-3.5 w-3.5 shrink-0" />
              {t("secPasskeysEmpty")}
            </p>
          )}
        </div>
        <Button
          type="button"
          size="sm"
          onClick={() => setAddOpen(true)}
          className="h-9 shrink-0 gap-1.5 rounded-xl px-4 text-[11.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110"
          style={{ backgroundImage: grad("#6d5dfb", "#a855f7") }}
        >
          <CatIcon name="plus" className="h-3.5 w-3.5" />
          {t("secPasskeyAdd")}
        </Button>
      </div>

      <Dialog open={addOpen} onOpenChange={(open) => !registering && setAddOpen(open)}>
        <DialogContent className="max-w-md gap-0 p-0" dir={lang === "ar" ? "rtl" : "ltr"}>
          <DialogHeader className="border-b border-slate-200/70 px-5 py-4 dark:border-white/[0.07]">
            <DialogTitle className="flex items-center gap-2 text-[14px] font-extrabold text-slate-900 dark:text-white">
              <IconTile icon="fingerprint" c1="#6d5dfb" c2="#a855f7" />
              {t("secPasskeyAdd")}
            </DialogTitle>
            <DialogDescription className="text-[11.5px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("secPasskeyAddDesc")}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 px-5 py-5">
            <div className="space-y-1.5">
              <Label htmlFor="sec-passkey-name" className="text-[12px] font-bold">
                {t("secPasskeyName")}
              </Label>
              <Input
                id="sec-passkey-name"
                value={name}
                onChange={(e) => setName(e.target.value.slice(0, 60))}
                placeholder={t("secPasskeyNamePh")}
                className="h-10 rounded-xl"
              />
            </div>
            <Button
              type="button"
              disabled={registering}
              onClick={() => void register()}
              className="h-10 w-full rounded-xl text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 disabled:opacity-60"
              style={{ backgroundImage: grad("#6d5dfb", "#a855f7") }}
            >
              <CatIcon
                name={registering ? "refresh-cw" : "fingerprint"}
                className={cn("h-4 w-4", registering && "animate-spin")}
              />
              {t(registering ? "secPasskeyWorking" : "secPasskeyThisDevice")}
            </Button>

            {/* ROUND 46 — cross-device enrollment QR (premium violet) */}
            {crossQr ? (
              <div className="space-y-3 rounded-2xl border border-violet-200/70 bg-linear-to-b from-violet-50/80 to-fuchsia-50/50 p-4 dark:border-violet-500/20 dark:from-violet-500/10 dark:to-fuchsia-500/5">
                <div className="flex flex-col items-center gap-3.5 sm:flex-row">
                  <PremiumQr
                    svg={crossQr}
                    c1="#6d5dfb"
                    c2="#9333ea"
                    icon="fingerprint"
                    aria={t("secPasskeyQrTitle")}
                    size="md"
                  />
                  <div className="min-w-0 flex-1 space-y-1.5 text-center sm:text-start">
                    <p className="flex items-center justify-center gap-1.5 text-[12px] font-extrabold text-violet-700 dark:text-violet-300 sm:justify-start">
                      <CatIcon name="scan-line" className="h-3.5 w-3.5 shrink-0" />
                      {t("secPasskeyQrTitle")}
                    </p>
                    <p className="text-[11px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                      {t("secPasskeyQrDesc")}
                    </p>
                  </div>
                </div>
                <p className="flex items-start gap-1.5 text-[10px] font-bold leading-relaxed text-slate-400 dark:text-slate-500">
                  <CatIcon name="lock" className="mt-px h-3 w-3 shrink-0" />
                  {t("secPasskeyQrNote")}
                </p>
              </div>
            ) : null}
          </div>
        </DialogContent>
      </Dialog>
    </DashCard>
  );
}

/* ============================ sessions card ============================= */

/** device-kind icon + gradient */
function sessionKindStyle(kind: string): { icon: string; c1: string; c2: string } {
  switch (kind) {
    case "mobile":
      return { icon: "smartphone", c1: "#8b5cf6", c2: "#7c3aed" };
    case "tablet":
      return { icon: "tablet", c1: "#06b6d4", c2: "#0891b2" };
    case "app":
      return { icon: "smartphone", c1: "#f59e0b", c2: "#ea580c" };
    case "desktop":
      return { icon: "monitor", c1: "#64748b", c2: "#475569" };
    default:
      return { icon: "monitor", c1: "#64748b", c2: "#475569" };
  }
}

function kindLabel(kind: string): I18nKey {
  switch (kind) {
    case "mobile":
      return "secDeviceKindMobile";
    case "tablet":
      return "secDeviceKindTablet";
    case "app":
      return "secDeviceKindApp";
    case "desktop":
      return "secDeviceKindDesktop";
    default:
      return "secDeviceKindUnknown";
  }
}

/** "expires in Xh Ym" (live countdown-free, computed once per render) */
function expiresIn(iso: string, t: (key: I18nKey, vars?: Record<string, string | number>) => string): string {
  const ms = new Date(iso).getTime() - Date.now();
  if (ms <= 0) return t("secSessionMinutes", { n: 0 });
  const mins = Math.round(ms / 60_000);
  const hours = Math.floor(mins / 60);
  const rem = mins % 60;
  if (hours <= 0) return t("secSessionMinutes", { n: mins });
  if (rem === 0) return t("secSessionHours", { n: hours });
  return `${t("secSessionHours", { n: hours })} ${t("secSessionMinutes", { n: rem })}`;
}

export function SessionsCard({ scope }: { scope: SecurityScope }) {
  const { t, lang } = useT();
  const isInstance = scope.kind === "instance";

  const sessionsQuery = useQuery({
    queryKey: ["sessions", scope.kind, "instanceId" in scope ? scope.instanceId : null],
    queryFn: () =>
      isInstance ? fetchInstanceSessions(scope.instanceId) : fetchAdminSessions(),
    refetchInterval: 60_000,
  });

  const sessions: SessionInfoDTO[] = sessionsQuery.data?.sessions ?? [];
  const currentJti = sessionsQuery.data?.currentJti ?? null;
  const [confirmAllOpen, setConfirmAllOpen] = useState(false);
  const [leaving, setLeaving] = useState(false);

  const revokeOne = useMutation({
    mutationFn: (jti: string) =>
      isInstance ? revokeInstanceSession(scope.instanceId, jti) : revokeAdminSession(jti),
    onSuccess: () => {
      toast.success(t("secSessionRevoked"));
      void sessionsQuery.refetch();
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  const revokeOthers = useMutation({
    mutationFn: () =>
      isInstance
        ? revokeOtherInstanceSessions(scope.instanceId)
        : revokeOtherAdminSessions(),
    onSuccess: (data) => {
      toast.success(t("secSessionsRevokedAll", { n: String(data.revoked) }));
      void sessionsQuery.refetch();
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  /** ROUND 46 — sign out EVERYWHERE (this device included) → back to login */
  const signOutEverywhere = useMutation({
    mutationFn: () =>
      isInstance
        ? signOutEverywhereInstance(scope.instanceId)
        : signOutEverywhereAdmin(),
    onSuccess: (data) => {
      setConfirmAllOpen(false);
      setLeaving(true);
      toast.success(t("secSignOutEverywhereDone", { n: String(data.revoked) }));
      window.setTimeout(() => window.location.reload(), 900);
    },
    onError: (error: Error) => {
      setLeaving(false);
      toast.error(`${t("errorText")}: ${error.message}`);
    },
  });

  /* current session first, then most-recently-active */
  const ordered = [...sessions].sort((a, b) => {
    if (a.id === currentJti) return -1;
    if (b.id === currentJti) return 1;
    return new Date(b.lastSeenAt).getTime() - new Date(a.lastSeenAt).getTime();
  });

  return (
    <DashCard title={t("secSessionsTitle")} icon="monitor-smartphone">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0 space-y-2">
          <p className="max-w-xl text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
            {t("secSessionsDesc")}
          </p>
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-brand-200/70 bg-brand-500/10 px-3 py-1 text-[11px] font-extrabold text-brand-600 dark:border-brand-500/30 dark:text-brand-300">
              <CatIcon name="monitor-smartphone" className="h-3 w-3" />
              {t("secSessionsCount", { n: String(sessions.length) })}
            </span>
            <button
              type="button"
              onClick={() => void sessionsQuery.refetch()}
              aria-label={t("secSessionsRefresh")}
              title={t("secSessionsRefresh")}
              className="inline-flex h-7 w-7 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-400 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:hover:text-brand-300"
            >
              <CatIcon
                name="refresh-cw"
                className={cn("h-3.5 w-3.5", sessionsQuery.isFetching && "animate-spin")}
              />
            </button>
          </div>
        </div>
        <div className="flex shrink-0 flex-wrap items-center gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => revokeOthers.mutate()}
            disabled={revokeOthers.isPending || sessions.length <= 1}
            className="h-9 gap-1.5 rounded-xl px-3.5 text-[11.5px] font-bold text-rose-500 transition hover:bg-rose-50 hover:text-rose-600 disabled:opacity-50 dark:hover:bg-rose-500/10"
          >
            <CatIcon
              name={revokeOthers.isPending ? "refresh-cw" : "log-out"}
              className={cn("h-3.5 w-3.5", revokeOthers.isPending && "animate-spin")}
            />
            {t("secRevokeOthers")}
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setConfirmAllOpen(true)}
            disabled={sessions.length === 0 || leaving}
            className="h-9 gap-1.5 rounded-xl border-rose-200 px-3.5 text-[11.5px] font-extrabold text-rose-600 transition hover:bg-rose-50 hover:text-rose-700 disabled:opacity-50 dark:border-rose-500/30 dark:text-rose-400 dark:hover:bg-rose-500/10"
          >
            <CatIcon name="power" className="h-3.5 w-3.5" />
            {t("secSignOutEverywhere")}
          </Button>
        </div>
      </div>

      <ul className="mt-3 space-y-2">
        {ordered.map((session) => {
          const isCurrent = session.id === currentJti;
          const kind = sessionKindStyle(session.kind);
          return (
            <li
              key={session.id}
              className={cn(
                "rounded-2xl border p-3.5 transition",
                isCurrent
                  ? "border-emerald-300/70 bg-emerald-500/[0.06] dark:border-emerald-500/30"
                  : "border-slate-200/80 bg-slate-50/40 dark:border-white/10 dark:bg-white/[0.02]"
              )}
            >
              <div className="flex flex-wrap items-center gap-3">
                <span
                  className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-md"
                  style={{
                    backgroundImage: isCurrent
                      ? grad("#10b981", "#059669")
                      : grad(kind.c1, kind.c2),
                  }}
                >
                  <CatIcon
                    name={isCurrent ? "monitor-check" : kind.icon}
                    className="h-[15px] w-[15px]"
                  />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="flex flex-wrap items-center gap-2 text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                    <span dir="auto">{session.device}</span>
                    {isCurrent ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2 py-px text-[11px] font-extrabold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
                        <span
                          className="h-1 w-1 animate-pulse rounded-full bg-emerald-500"
                          aria-hidden="true"
                        />
                        {t("secThisDevice")}
                      </span>
                    ) : null}
                    <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-px text-[11px] font-extrabold text-slate-500 dark:bg-white/10 dark:text-slate-400">
                      <CatIcon name={kind.icon} className="h-2.5 w-2.5" />
                      {t(kindLabel(session.kind))}
                    </span>
                  </p>
                  {/* detail line: browser · OS · IP (copyable) */}
                  <div className="mt-1 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500" dir="ltr">
                    {session.browser ? (
                      <span className="inline-flex items-center gap-1">
                        <CatIcon name="globe" className="h-3 w-3" />
                        {session.browser}
                      </span>
                    ) : null}
                    {session.os ? (
                      <span className="inline-flex items-center gap-1">
                        <CatIcon name="cpu" className="h-3 w-3" />
                        {session.os}
                      </span>
                    ) : null}
                    {session.ip ? (
                      <CopyChip value={session.ip} label={session.ip} title={t("secCopyIp")} />
                    ) : (
                      <span className="font-mono">—</span>
                    )}
                  </div>
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => revokeOne.mutate(session.id)}
                  disabled={revokeOne.isPending || leaving}
                  className="h-8 shrink-0 gap-1.5 rounded-lg px-2.5 text-[10.5px] font-bold text-slate-500 transition hover:bg-rose-50 hover:text-rose-500 dark:hover:bg-rose-500/10"
                >
                  <CatIcon name="log-out" className="h-3 w-3" />
                  {t("secSignOutDevice")}
                </Button>
              </div>
              {/* meta line: first seen · last active · expires in */}
              <div className="mt-2.5 flex flex-wrap items-center gap-x-4 gap-y-1 border-t border-slate-200/70 pt-2.5 text-[10px] font-bold text-slate-400 dark:border-white/[0.06] dark:text-slate-500">
                <span className="inline-flex items-center gap-1">
                  <CatIcon name="calendar-clock" className="h-3 w-3" />
                  {t("secFirstSeen")}: {relTime(session.createdAt, lang)}
                </span>
                <span className="inline-flex items-center gap-1">
                  <CatIcon name="activity" className="h-3 w-3" />
                  {t("secLastActive", { when: relTime(session.lastSeenAt, lang) })}
                </span>
                <span className="inline-flex items-center gap-1">
                  <CatIcon name="timer" className="h-3 w-3" />
                  {t("secExpiresIn")}: {expiresIn(session.expiresAt, t)}
                </span>
              </div>
            </li>
          );
        })}
        {sessionsQuery.isLoading ? (
          <li className="rounded-2xl border border-dashed border-slate-300/70 p-4 text-center text-[11.5px] font-semibold text-slate-400 dark:border-white/10 dark:text-slate-500">
            {t("secSessionsLoading")}
          </li>
        ) : null}
        {!sessionsQuery.isLoading && sessions.length === 0 ? (
          <li className="rounded-2xl border border-dashed border-slate-300/70 p-4 text-center text-[11.5px] font-semibold text-slate-400 dark:border-white/10 dark:text-slate-500">
            {t("secSessionsEmpty")}
          </li>
        ) : null}
      </ul>

      {/* ROUND 46 — sign-out-everywhere confirmation */}
      <AlertDialog open={confirmAllOpen} onOpenChange={setConfirmAllOpen}>
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"}>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-[14px] font-extrabold">
              <IconTile icon="power-off" c1="#f43f5e" c2="#e11d48" />
              {t("secSignOutEverywhere")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[12px] leading-relaxed">
              {t("secSignOutEverywhereDesc")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="gap-2">
            <AlertDialogCancel className="h-9 rounded-xl px-4 text-[12px] font-bold">
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                signOutEverywhere.mutate();
              }}
              disabled={signOutEverywhere.isPending}
              className="h-9 rounded-xl bg-linear-to-r from-rose-500 to-rose-600 px-4 text-[12px] font-extrabold text-white shadow-lg shadow-rose-500/25 hover:brightness-110"
            >
              <CatIcon
                name={signOutEverywhere.isPending ? "refresh-cw" : "power-off"}
                className={cn("h-3.5 w-3.5", signOutEverywhere.isPending && "animate-spin")}
              />
              {t("secSignOutEverywhereConfirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashCard>
  );
}

/* ========================================================================== */
/* ROUND 158 (security) — BannedIpsCard — the platform-wide IP banlist        */
/* ========================================================================== */

/** A simple IPv4 / IPv6 shape validator (loose — the server normalizes
 *  definitively). Rejects empty + obviously-malformed inputs before the
 *  network round-trip. */
function looksLikeIp(value: string): boolean {
  const v = value.trim();
  if (!v || v.length > 64) return false;
  /* IPv4 dotted quad */
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(v)) return true;
  /* IPv6 (loose — colons + hex digits, optional bracketed form) */
  const bare = v.startsWith("[") && v.endsWith("]") ? v.slice(1, -1) : v;
  return /^[0-9a-fA-F:]+$/.test(bare) && bare.includes(":");
}

/** Friendly "added N ago" chip — empty when the legacy shape lacked it. */
function addedAgo(addedAt: string, lang: ReturnType<typeof useT>["lang"]): string | null {
  if (!addedAt) return null;
  try {
    /* validate the timestamp parses; relTime handles the formatting */
    const ts = new Date(addedAt).getTime();
    if (!Number.isFinite(ts)) return null;
    return relTime(addedAt, lang);
  } catch {
    return null;
  }
}

export function BannedIpsCard() {
  const { t, lang } = useT();
  const [ipInput, setIpInput] = useState("");
  const [noteInput, setNoteInput] = useState("");

  const listQuery = useQuery({
    queryKey: ["banned-ips"],
    queryFn: fetchBannedIps,
    refetchInterval: 60_000,
  });

  const ips: BannedIpDTO[] = listQuery.data?.ips ?? [];

  const addMutation = useMutation({
    mutationFn: ({ ip, note }: { ip: string; note?: string }) => banIp(ip, note),
    onSuccess: () => {
      toast.success(t("ipBanAdded"));
      setIpInput("");
      setNoteInput("");
      void listQuery.refetch();
    },
    onError: (error: Error) => {
      const msg = error instanceof ApiError ? error.message : t("ipBanInvalid");
      toast.error(msg);
    },
  });

  const removeMutation = useMutation({
    mutationFn: (ip: string) => unbanIp(ip),
    onSuccess: () => {
      toast.success(t("ipBanRemoved"));
      void listQuery.refetch();
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  const onAdd = () => {
    const ip = ipInput.trim();
    if (!looksLikeIp(ip)) {
      toast.error(t("ipBanInvalid"));
      return;
    }
    addMutation.mutate({ ip, note: noteInput.trim() || undefined });
  };

  return (
    <DashCard title={t("ipBanCardTitle")} icon="shield-alert">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0 space-y-2">
          <p className="max-w-2xl text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
            {t("ipBanCardDesc")}
          </p>
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-rose-200/70 bg-rose-500/10 px-3 py-1 text-[11px] font-extrabold text-rose-600 dark:border-rose-500/30 dark:text-rose-300">
              <CatIcon name="ban" className="h-3 w-3" />
              {t("ipBanCount", { n: ips.length })}
            </span>
            <button
              type="button"
              onClick={() => void listQuery.refetch()}
              aria-label={t("ipBanRefresh")}
              title={t("ipBanRefresh")}
              className="inline-flex h-7 w-7 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-400 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:hover:text-brand-300"
            >
              <CatIcon
                name="refresh-cw"
                className={cn("h-3.5 w-3.5", listQuery.isFetching && "animate-spin")}
              />
            </button>
          </div>
        </div>
      </div>

      {/* add form */}
      <div className="mt-3 flex flex-col gap-2 rounded-2xl border border-slate-200/80 bg-slate-50/50 p-3 dark:border-white/10 dark:bg-white/[0.02] sm:flex-row sm:items-center">
        <Input
          type="text"
          value={ipInput}
          onChange={(e) => setIpInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !addMutation.isPending) onAdd();
          }}
          placeholder={t("ipBanInputPh")}
          dir="ltr"
          className="h-10 flex-1 rounded-xl border-slate-200 bg-white px-3 text-[12.5px] font-mono font-semibold text-slate-800 placeholder:font-sans placeholder:font-normal placeholder:text-slate-400 focus:border-brand-400 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100"
          maxLength={64}
        />
        <Input
          type="text"
          value={noteInput}
          onChange={(e) => setNoteInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !addMutation.isPending) onAdd();
          }}
          placeholder={t("ipBanNotePh")}
          className="h-10 flex-1 rounded-xl border-slate-200 bg-white px-3 text-[12.5px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 focus:border-brand-400 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100"
          maxLength={120}
        />
        <Button
          type="button"
          onClick={onAdd}
          disabled={addMutation.isPending || !ipInput.trim()}
          className="h-10 shrink-0 gap-1.5 rounded-xl bg-linear-to-r from-rose-500 to-rose-600 px-4 text-[12px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:brightness-110 disabled:opacity-50"
        >
          <CatIcon
            name={addMutation.isPending ? "refresh-cw" : "ban"}
            className={cn("h-3.5 w-3.5", addMutation.isPending && "animate-spin")}
          />
          {t("ipBanAddBtn")}
        </Button>
      </div>

      {/* list */}
      <ul className="mt-3 space-y-2">
        {ips.map((entry) => {
          const ago = addedAgo(entry.addedAt, lang);
          return (
            <li
              key={entry.ip}
              className="flex flex-wrap items-center gap-3 rounded-2xl border border-slate-200/80 bg-slate-50/40 p-3 dark:border-white/10 dark:bg-white/[0.02]"
            >
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
                style={{ backgroundImage: grad("#f43f5e", "#e11d48") }}
                aria-hidden="true"
              >
                <CatIcon name="ban" className="h-3.5 w-3.5" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="flex flex-wrap items-center gap-2 text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                  <CopyChip value={entry.ip} label={entry.ip} title={t("secCopyIp")} />
                  {ago ? (
                    <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-px text-[10.5px] font-bold text-slate-500 dark:bg-white/10 dark:text-slate-400">
                      <CatIcon name="calendar-clock" className="h-2.5 w-2.5" />
                      {ago}
                    </span>
                  ) : null}
                </p>
                {entry.note ? (
                  <p className="mt-1 truncate text-[10.5px] font-semibold text-slate-500 dark:text-slate-400" dir="auto">
                    {t("ipBanNoteLabel")}: {entry.note}
                  </p>
                ) : null}
              </div>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => removeMutation.mutate(entry.ip)}
                disabled={removeMutation.isPending}
                className="h-8 shrink-0 gap-1.5 rounded-lg px-2.5 text-[10.5px] font-bold text-slate-500 transition hover:bg-emerald-50 hover:text-emerald-600 dark:hover:bg-emerald-500/10"
              >
                <CatIcon name="badge-check" className="h-3 w-3" />
                {t("ipBanRemove")}
              </Button>
            </li>
          );
        })}
        {listQuery.isLoading ? (
          <li className="rounded-2xl border border-dashed border-slate-300/70 p-4 text-center text-[11.5px] font-semibold text-slate-400 dark:border-white/10 dark:text-slate-500">
            {t("ipBanLoading")}
          </li>
        ) : null}
        {!listQuery.isLoading && ips.length === 0 ? (
          <li className="rounded-2xl border border-dashed border-slate-300/70 p-4 text-center text-[11.5px] font-semibold text-slate-400 dark:border-white/10 dark:text-slate-500">
            {t("ipBanEmpty")}
          </li>
        ) : null}
      </ul>
    </DashCard>
  );
}
