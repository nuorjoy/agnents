"use client";

/**
 * Ashrilogic — 10-language switcher (round 34).
 *
 * Same visual identity as the previous AR/EN toggle (globe icon tile +
 * compact label in the same bordered rounded-xl button), now opening the
 * full locale menu instead of flipping between two languages.
 *
 * - `ar` + `en` are complete dictionaries; the other 8 locales show a
 *   subtle "soon" chip — their interface falls back to English until the
 *   dictionary lands (direction, fonts and date/number formatting already
 *   follow the picked locale).
 * - `onPick` fires after a language is selected (e.g. to close a parent
 *   mobile sheet).
 */
import { toast } from "sonner";
import { useT } from "@/lib/i18n";
import { LOCALES, TRANSLATED_LANGS, localeShortLabel } from "@/lib/locales";
import { useRouter } from "next/navigation";
import { useAppStore } from "@/lib/store";
import { CatIcon } from "@/components/icon";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn, grad } from "@/lib/utils";

/** Leading icon-tile palette cycled per row — matches the plan/feature tiles. */
const TILE_STYLES = [
  { c1: "#6d5dfb", c2: "#8b5cf6" },
  { c1: "#06b6d4", c2: "#0891b2" },
  { c1: "#d946ef", c2: "#c026d3" },
  { c1: "#f59e0b", c2: "#ea580c" },
  { c1: "#10b981", c2: "#059669" },
] as const;

export function LangMenu({ onPick, className }: { onPick?: () => void; className?: string }) {
  const { t, lang } = useT();
  const setLang = useAppStore((s) => s.setLang);
  const router = useRouter();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-label={t("ariaLang")}
          title={t("ariaLang")}
          className={cn(
            "flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-2.5 text-slate-600 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:bg-white/5 dark:text-slate-300",
            className
          )}
        >
          <CatIcon name="globe" className="h-[13px] w-[13px]" />
          <span className="min-w-6 text-center text-[11px] font-extrabold tracking-wide">
            {localeShortLabel(lang)}
          </span>
          <CatIcon name="chevron-down" className="h-[9px] w-[9px] opacity-60" />
        </button>
      </DropdownMenuTrigger>

      <DropdownMenuContent align="end" className="w-64 rounded-2xl p-1.5">
        <DropdownMenuLabel className="px-2.5 pb-1.5 pt-1 text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
          {t("langMenuTitle")}
        </DropdownMenuLabel>

        <div className="nice-scroll max-h-80 overflow-y-auto" role="listbox" aria-label={t("langMenuTitle")}>
          {LOCALES.map((loc, i) => {
            const active = loc.code === lang;
            const translated = (TRANSLATED_LANGS as readonly string[]).includes(loc.code);
            const tile = TILE_STYLES[i % TILE_STYLES.length];
            return (
              <DropdownMenuItem
                key={loc.code}
                role="option"
                aria-selected={active}
                onClick={() => {
                  if (loc.code === lang) return;
                  /* ROUND 185 — setLang is now the single funnel: it flips
                   * the store (every client island re-renders instantly)
                   * AND mirrors the choice into the `ashrlc-lang` cookie,
                   * so the next server render (this refresh, any reload)
                   * speaks the new language from the first byte. The
                   * router.refresh() re-renders the RSC shell in the same
                   * beat. */
                  setLang(loc.code);
                  toast.success(t("langMenuToast", { lang: loc.native }));
                  onPick?.();
                  router.refresh();
                }}
                className={cn(
                  "group gap-2.5 rounded-xl px-2 py-2 outline-none",
                  active && "bg-brand-50 dark:bg-brand-500/10"
                )}
              >
                <span
                  className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-[11px] font-extrabold text-white shadow-sm"
                  style={{ backgroundImage: grad(tile.c1, tile.c2) }}
                  aria-hidden="true"
                >
                  {loc.short}
                </span>
                <span className="flex min-w-0 flex-1 flex-col">
                  <span className="truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
                    {loc.native}
                  </span>
                  <span className="truncate text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                    {loc.english}
                  </span>
                </span>
                {!translated ? (
                  <span className="shrink-0 rounded-full bg-amber-100 px-1.5 py-px text-[11px] font-extrabold text-amber-700 dark:bg-amber-500/15 dark:text-amber-300">
                    {t("langMenuSoon")}
                  </span>
                ) : null}
                {active ? (
                  <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400">
                    <CatIcon name="check" className="h-3 w-3" />
                  </span>
                ) : null}
              </DropdownMenuItem>
            );
          })}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export default LangMenu;
