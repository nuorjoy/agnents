import type { CSSProperties, ReactNode } from "react";
import { createElement } from "react";
import { getIcon } from "@/lib/icons";
import { cn } from "@/lib/utils";

export interface CatIconProps {
  /** kebab-case lucide icon name (as referenced in the catalog / UI vocabulary) */
  name: string;
  className?: string;
  style?: CSSProperties;
}

/**
 * Renders any catalog/UI icon from its kebab-case name.
 * Falls back to the Boxes icon when the name is unknown.
 *
 * The icon element is created via `createElement` with the stable lucide
 * component resolved from the registry (module-level constants), so no
 * component is ever re-created during render.
 */
export function CatIcon({ name, className, style }: CatIconProps): ReactNode {
  return createElement(getIcon(name), {
    className: cn("h-4 w-4", className),
    style,
    "aria-hidden": true,
  });
}
