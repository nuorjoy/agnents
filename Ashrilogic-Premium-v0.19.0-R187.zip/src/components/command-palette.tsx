"use client";

/**
 * Ashrilogic — global command palette (⌘K / Ctrl+K, ⌘J / Ctrl+J).
 *
 * Premium Linear/Vercel-style palette available on the landing page AND
 * inside the dashboard (rendered once in the app shell). Contents:
 *   1. Systems   — Arabic-aware fuzzy search over the 100 catalog systems
 *                  (shares the exact matcher with the landing search box via
 *                  src/lib/search.ts) → launches the setup wizard.
 *   2. Navigation — landing anchors (smooth-scroll) / the 8 dashboard views.
 *   3. Actions   — theme toggle, language toggle, add team member (dashboard).
 *
 * Guarded: never opens while the setup-wizard overlay is on screen.
 */

import { useCallback, useEffect, useMemo, useState } from "react";
import { useTheme } from "next-themes";
import { toast } from "sonner";
import { CATEGORY_MAP, SYSTEMS } from "@/data/catalog";
import { useT, type I18nKey } from "@/lib/i18n";
import { localeNativeLabel, nextLocale } from "@/lib/locales";
import { useAppStore } from "@/lib/store";
import type { DashView, Lang, SystemDef, WizardDraft } from "@/lib/types";
import { arabicMatches, buildSearchEntry, type SearchEntry } from "@/lib/search";
import { CatIcon } from "@/components/icon";
import { grad } from "@/lib/utils";
import { buildSystemDraft } from "@/components/landing/systems-library";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandShortcut,
} from "@/components/ui/command";

import "@/lib/i18n/fragments/app";
/* how many systems to render: a few for an empty query, more once filtering */
const SYSTEMS_EMPTY = 6;
const SYSTEMS_QUERY = 12;

/* delay before running a selected action so the dialog finishes its close
   animation (scroll unlock / focus return) first */
const RUN_DELAY_MS = 240;

/* polished item treatment: hover wash + selected ring + gradient inset bar
   on the inline-start side (RTL-safe via logical inset) */
const CP_ITEM =
  "relative rounded-xl py-2.5 outline-none transition-colors duration-150 " +
  "hover:bg-slate-100 dark:hover:bg-white/[0.05] " +
  "data-[selected=true]:bg-slate-100 data-[selected=true]:ring-1 data-[selected=true]:ring-brand-500/25 " +
  "dark:data-[selected=true]:bg-white/[0.06] " +
  "before:absolute before:inset-y-1.5 before:start-1.5 before:w-[3px] before:rounded-full " +
  "before:bg-linear-to-b before:from-brand-500 before:to-fuchsia-500 before:opacity-0 " +
  "before:transition-opacity before:duration-150 hover:before:opacity-100 " +
  "data-[selected=true]:before:opacity-100";

/* ------------------------------------------------ nav definitions ---- */

const LANDING_NAV: { anchor: string; labelKey: I18nKey; icon: string }[] = [
  { anchor: "#systems", labelKey: "navSystems", icon: "layers" },
  { anchor: "#sectors", labelKey: "navSectors", icon: "compass" },
  { anchor: "#features", labelKey: "navFeatures", icon: "zap" },
  { anchor: "#download", labelKey: "navDownload", icon: "download" },
];

const DASH_NAV: { id: DashView; labelKey: I18nKey; icon: string }[] = [
  { id: "overview", labelKey: "dashOverview", icon: "gauge" },
  { id: "analytics", labelKey: "dashAnalytics", icon: "chart-line" },
  { id: "modules", labelKey: "dashModules", icon: "cubes" },
  { id: "notifications", labelKey: "dashNotifications", icon: "bell" },
  { id: "activity", labelKey: "dashActivity", icon: "clock-rotate-left" },
  { id: "website", labelKey: "dashWebsite", icon: "globe" },
  { id: "store", labelKey: "dashStore", icon: "store" },
  { id: "team", labelKey: "dashTeam", icon: "users" },
  { id: "settings", labelKey: "dashSettings", icon: "sliders" },
  { id: "billing", labelKey: "dashBilling", icon: "credit-card" },
];

interface NavItem {
  id: string;
  label: string;
  icon: string;
  action: () => void;
}

interface QuickAction {
  id: string;
  label: string;
  icon: string;
  action: () => void;
}

/* ================================================================ ---- */

export function CommandPalette() {
  const { t, lang } = useT();
  const view = useAppStore((s) => s.view);
  const setDashView = useAppStore((s) => s.setDashView);
  const setLang = useAppStore((s) => s.setLang);
  const startWizard = useAppStore((s) => s.startWizard);
  const paletteOpen = useAppStore((s) => s.paletteOpen);
  const setPaletteOpen = useAppStore((s) => s.setPaletteOpen);
  const { resolvedTheme, setTheme } = useTheme();

  const [query, setQuery] = useState("");
  const inDashboard = view === "dashboard";

  /* ---- global shortcut: ⌘K / Ctrl+K + secondary ⌘J / Ctrl+J ---------- */
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      // never steal keys from the setup-wizard overlay
      if (view === "wizard") return;
      // plain typing (no ctrl/meta) must never open the palette
      if (e.altKey || !(e.ctrlKey || e.metaKey)) return;
      const key = e.key.toLowerCase();
      if (key !== "k" && key !== "j") return;
      e.preventDefault();
      setPaletteOpen(true);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [view, setPaletteOpen]);

  /* safety: if the wizard opens while the palette is somehow open, close it */
  useEffect(() => {
    if (view === "wizard" && paletteOpen) setPaletteOpen(false);
  }, [view, paletteOpen, setPaletteOpen]);

  const handleOpenChange = useCallback(
    (next: boolean) => {
      setPaletteOpen(next);
      if (!next) setQuery("");
    },
    [setPaletteOpen]
  );

  /* close the dialog, wait out the close animation, then run the action */
  const run = useCallback(
    (action: () => void) => {
      setPaletteOpen(false);
      setQuery("");
      setTimeout(action, RUN_DELAY_MS);
    },
    [setPaletteOpen]
  );

  /* ---- shared Arabic-aware search index over the 102 systems --------- */
  const searchIndex = useMemo(() => {
    const map = new Map<string, SearchEntry>();
    for (const s of SYSTEMS) {
      const cat = CATEGORY_MAP[s.c];
      map.set(
        s.id,
        buildSearchEntry(
          `${s.nameAr} ${s.nameEn} ${s.descAr} ${s.descEn} ${cat.nameAr} ${cat.nameEn} ${s.id}`
        )
      );
    }
    return map;
  }, []);

  const systems = useMemo(() => {
    const q = query.trim();
    if (!q) {
      return {
        list: SYSTEMS.slice(0, SYSTEMS_EMPTY),
        hidden: SYSTEMS.length - SYSTEMS_EMPTY,
      };
    }
    const matched = SYSTEMS.filter((s) => {
      const entry = searchIndex.get(s.id);
      return entry ? arabicMatches(entry, q) : false;
    });
    return {
      list: matched.slice(0, SYSTEMS_QUERY),
      hidden: matched.length - Math.min(matched.length, SYSTEMS_QUERY),
    };
  }, [query, searchIndex]);

  /* ---- navigation group (context-aware) ------------------------------ */
  const navItems = useMemo<NavItem[]>(() => {
    if (inDashboard) {
      return DASH_NAV.map((n) => ({
        id: n.id,
        label: t(n.labelKey),
        icon: n.icon,
        action: () => setDashView(n.id),
      }));
    }
    return LANDING_NAV.map((n) => ({
      id: n.anchor,
      label: t(n.labelKey),
      icon: n.icon,
      action: () =>
        document
          .querySelector(n.anchor)
          ?.scrollIntoView({ behavior: "smooth", block: "start" }),
    }));
  }, [inDashboard, t, setDashView]);

  const visibleNav = useMemo(() => {
    const q = query.trim();
    if (!q) return navItems;
    return navItems.filter((n) => arabicMatches(n.label, q));
  }, [query, navItems]);

  /* ---- quick actions group ------------------------------------------- */
  const quickActions = useMemo<QuickAction[]>(() => {
    const actions: QuickAction[] = [
      {
        id: "theme",
        label: t("cpTheme"),
        icon: resolvedTheme === "dark" ? "sun" : "moon",
        action: () => setTheme(resolvedTheme === "dark" ? "light" : "dark"),
      },
      {
        id: "lang",
        label: t("cpLang"),
        icon: "globe",
        action: () => {
          const next: Lang = nextLocale(lang);
          setLang(next);
          toast.success(localeNativeLabel(next));
        },
      },
    ];
    if (inDashboard) {
      actions.push({
        id: "add-member",
        label: t("cpAddMember"),
        icon: "user-plus",
        action: () => {
          setDashView("team");
          setTimeout(() => document.getElementById("team-add-name")?.focus(), 200);
        },
      });
    }
    return actions;
  }, [inDashboard, lang, resolvedTheme, setLang, setTheme, t, setDashView]);

  const visibleActions = useMemo(() => {
    const q = query.trim();
    if (!q) return quickActions;
    return quickActions.filter((a) => arabicMatches(a.label, q));
  }, [query, quickActions]);

  /* ---- system selection → wizard (from landing OR dashboard) --------- */
  const selectSystem = useCallback(
    (system: SystemDef) => {
      const theme: "light" | "dark" = resolvedTheme === "light" ? "light" : "dark";
      const draft: WizardDraft = buildSystemDraft(system, lang, theme);
      // startWizard switches the view (dashboard → landing + wizard overlay)
      run(() => startWizard(draft));
    },
    [lang, resolvedTheme, run, startWizard]
  );

  const systemsHeading = (
    <span className="text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500">
      {t("cpSystems")}
    </span>
  );
  const navHeading = (
    <span className="text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500">
      {t("cpNavigation")}
    </span>
  );
  const actionsHeading = (
    <span className="text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500">
      {t("cpActions")}
    </span>
  );

  return (
    <CommandDialog
      open={paletteOpen}
      onOpenChange={handleOpenChange}
      title={t("cpOpenHint")}
      description={t("cpSearchPh")}
      showCloseButton={false}
      commandProps={{ shouldFilter: false }}
      className="top-[12%] translate-y-0 rounded-2xl border-slate-200/80 bg-popover/95 shadow-lift backdrop-blur-2xl sm:max-w-xl dark:border-white/10 dark:bg-[#0a0f1c]/90"
    >
      <CommandInput
        value={query}
        onValueChange={setQuery}
        placeholder={t("cpSearchPh")}
        className="text-[13px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 dark:text-slate-100 dark:placeholder:text-slate-500"
      />

      <CommandList className="max-h-[min(56vh,420px)] py-2">
        <CommandEmpty className="py-8 text-[12.5px] font-semibold text-slate-400 dark:text-slate-500">
          {t("cpNoResults")}
        </CommandEmpty>

        {/* systems */}
        {systems.list.length > 0 ? (
          <CommandGroup heading={systemsHeading}>
            {systems.list.map((s) => {
              const cat = CATEGORY_MAP[s.c];
              const name = lang === "ar" ? s.nameAr : s.nameEn;
              const catName = lang === "ar" ? cat.nameAr : cat.nameEn;
              return (
                <CommandItem
                  key={s.id}
                  value={s.id}
                  onSelect={() => selectSystem(s)}
                  className={CP_ITEM}
                >
                  <span
                    className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white"
                    style={{ backgroundImage: grad(cat.c1, cat.c2) }}
                    aria-hidden="true"
                  >
                    <CatIcon name={s.icon} className="h-[13px] w-[13px]" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[12.5px] font-bold text-slate-800 dark:text-slate-100">
                      {name}
                    </span>
                    <span className="block truncate text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                      {catName}
                    </span>
                  </span>
                  <CommandShortcut className="kbd ml-auto inline-flex text-[10px]">
                    {t("cpStartSystem")}
                  </CommandShortcut>
                </CommandItem>
              );
            })}
            {systems.hidden > 0 ? (
              <p className="px-3 py-2 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                {t("cpMoreSystems", { n: systems.hidden })}
              </p>
            ) : null}
          </CommandGroup>
        ) : null}

        {/* navigation */}
        {visibleNav.length > 0 ? (
          <CommandGroup heading={navHeading}>
            {visibleNav.map((n) => (
              <CommandItem
                key={n.id}
                value={n.id}
                onSelect={() => run(n.action)}
                className={CP_ITEM}
              >
                <CatIcon name={n.icon} className="h-4 w-4 text-brand-500" />
                <span className="text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                  {n.label}
                </span>
                <CommandShortcut className="kbd ml-auto inline-flex text-[10px]">
                  {t("cpQuickNav")}
                </CommandShortcut>
              </CommandItem>
            ))}
          </CommandGroup>
        ) : null}

        {/* quick actions */}
        {visibleActions.length > 0 ? (
          <CommandGroup heading={actionsHeading}>
            {visibleActions.map((a) => (
              <CommandItem
                key={a.id}
                value={a.id}
                onSelect={() => run(a.action)}
                className={CP_ITEM}
              >
                <CatIcon name={a.icon} className="h-4 w-4 text-brand-500" />
                <span className="text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                  {a.label}
                </span>
              </CommandItem>
            ))}
          </CommandGroup>
        ) : null}
      </CommandList>

      {/* footer: current view context + keyboard hint */}
      <div className="flex items-center justify-between gap-2 border-t border-slate-200/70 px-3 py-2 dark:border-white/10">
        <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-[10px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-400">
          <CatIcon
            name={inDashboard ? "gauge" : "house"}
            className="h-[10px] w-[10px] text-brand-500"
          />
          {inDashboard ? t("cpCtxDashboard") : t("cpCtxLanding")}
        </span>
        <span className="text-[10px] font-semibold text-slate-400 dark:text-slate-500">
          {t("cpKeysHint")}
        </span>
      </div>
    </CommandDialog>
  );
}

export default CommandPalette;
