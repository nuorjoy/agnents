"use client";

/**
 * Dashboard — ProfileDialog (opened from the topbar admin icon → الملف الشخصي).
 *
 * ROUND 144 — PERSONAL-DATA-ONLY REBUILD (owner directives):
 *   «البروفايل يعرض بيانات المالك الشخصية فقط» + إصلاح حالة المصادقة
 *   الثنائية الحقيقية + وضع التعديل الاحترافي.
 *
 *   1. Hero banner     — accent gradient + radial aura blobs + top sheen; the
 *                        avatar stack (gradient ring around the shared
 *                        AvatarPicker photo pipeline + online emerald dot) and
 *                        the identity column (name / LTR-isolated email /
 *                        verified · role · 2FA chips). The system badge card,
 *                        the team-members tile and the modules tile are GONE —
 *                        personal data only.
 *   2. Live stat strip — member-since + last-login (the exact actLogin
 *                        pattern) — the only two PERSONAL timeline facts.
 *   3. بيانات الحساب   — name + email definition cells (org/plan removed).
 *   4. البيانات الشخصية — the 6 owner-profile fields (phone / birthDate + age
 *                        chip / nationality / jobTitle / gender / address)
 *                        with honest «—» placeholders, a slim completion
 *                        meter + one-line hint, and the تعديل البيانات
 *                        slim gradient row that reveals the edit form.
 *   5. المحفظة         — WalletCard + top-up & ledger dialogs (unchanged).
 *
 * REAL 2FA (critical fix): the stored admin.twoFA flag is a stale wizard-time
 * value — the chip now renders `enabled` from the LIVE
 * ["instance-mfa", id] query (fetchInstanceMfaStatus) and is FAIL-CLOSED:
 * pending or errored renders the OFF state, never the stale flag.
 *
 * EDIT MODE: read-only by default; «تعديل البيانات» reveals the professional
 * form (inner-component remount pattern — form state lives inside
 * DialogContent so Radix re-seeds it fresh on every open). Save is diff-based
 * and split per concern, fail-soft per call:
 *   (a) name/email dirty → PATCH updateInstance({ admin })  (existing flow)
 *   (b) any personal field dirty → PUT saveOwnerProfile(complete merged
 *       payload — every field required, exactly like the strict gate)
 * Both run in parallel when both are dirty; each failure gets its own toast.
 *
 * RTL LAW: logical utilities ONLY (ps/pe/ms/me/text-start/start/end — zero
 * left/right); grids flow RTL natively; latin values (email / phone) are
 * isolated inside dir="ltr" spans while their BLOCKS stay anchored to the
 * inline-start edge; numerals ride tabular-nums.
 *
 * LIVE DATA: every open refetches the shared ["instance", id] record (the
 * same key the shell owns) plus the ["instance-mfa", id] truth query and the
 * ["wallet", id] query (SHARED with WalletCard → zero duplicate fetches).
 */
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { COUNTRIES } from "@/data/countries";
import { useT, type I18nKey } from "@/lib/i18n";
import type { InstanceDTO, MemberGender, OwnerProfile, OwnerProfilePayload } from "@/lib/types";
import {
  fetchInstance,
  fetchInstanceMfaStatus,
  fetchWallet,
  saveOwnerProfile,
  updateInstance,
} from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, hexAlpha } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { WZ_INPUT, WZ_LABEL } from "@/components/wizard/wizard-shared";
import { PremiumDateInput } from "@/components/ui/premium-date-input";
import { dateOnly, fullDate, relativeTime } from "@/components/dashboard/dash-shared";
import { useAccentPair } from "@/components/dashboard/accent-context";
import { AvatarPicker } from "@/components/dashboard/avatar-picker";
import {
  WalletCard,
  WalletLedgerDialog,
  WalletTopupDialog,
} from "@/components/dashboard/wallet-widgets";
import { EMAIL_RE } from "@/lib/validation";

/* ------------------------------------------------------------------ */
/* Validation — mirrors the strict owner-profile server contract 1:1    */
/* (same idioms as owner-profile-gate.tsx; the server always wins).    */
/* ------------------------------------------------------------------ */

const PHONE_RE = /^\+?[0-9]{8,15}$/;
const YEAR_MS = 365.2425 * 24 * 60 * 60 * 1000;
const MIN_AGE_YEARS = 13;
const MAX_AGE_YEARS = 120;
const COUNTRY_CODES = new Set(COUNTRIES.map((c) => c.code));
const BIRTH_RE = /^\d{4}-\d{2}-\d{2}$/;

const isoDay = (d: Date) => d.toISOString().slice(0, 10);
/** newest allowed birth day = exactly 13 years ago; oldest = 120 years ago */
const MAX_BIRTH_DAY = isoDay(new Date(Date.now() - MIN_AGE_YEARS * YEAR_MS));
const MIN_BIRTH_DAY = isoDay(new Date(Date.now() - MAX_AGE_YEARS * YEAR_MS));

function validBirthDate(v: string): boolean {
  if (!BIRTH_RE.test(v)) return false;
  const t = Date.parse(`${v}T00:00:00Z`);
  if (Number.isNaN(t) || t >= Date.now()) return false;
  const ageYears = (Date.now() - t) / YEAR_MS;
  return ageYears >= MIN_AGE_YEARS && ageYears <= MAX_AGE_YEARS;
}

/** whole years since a yyyy-mm-dd birth date (null when unparseable/absurd) */
function ageYearsOf(v: string): number | null {
  if (!BIRTH_RE.test(v)) return null;
  const t = Date.parse(`${v}T00:00:00Z`);
  if (Number.isNaN(t) || t >= Date.now()) return null;
  const age = Math.floor((Date.now() - t) / YEAR_MS);
  return age >= 0 && age <= MAX_AGE_YEARS ? age : null;
}

/* The six personal fields the completion meter scores (presence, not
 * validity — an honest «how much of the profile is filled in» signal). */
const PERSONAL_KEYS = ["phone", "birthDate", "nationality", "jobTitle", "gender", "address"] as const;
type PersonalKey = (typeof PERSONAL_KEYS)[number];

function personalPresence(p: OwnerProfile): Record<PersonalKey, boolean> {
  return {
    phone: p.phone.trim().length > 0,
    birthDate: BIRTH_RE.test(p.birthDate),
    nationality: COUNTRY_CODES.has(p.nationality),
    jobTitle: p.jobTitle.trim().length > 0,
    gender: p.gender === "male" || p.gender === "female",
    address: p.address.trim().length > 0,
  };
}

/* ------------------------------------------------------------------ */
/* Edit-form plumbing                                                   */
/* ------------------------------------------------------------------ */

type FieldKey =
  | "name"
  | "email"
  | "phone"
  | "birthDate"
  | "gender"
  | "nationality"
  | "jobTitle"
  | "address";
type FieldErrors = Partial<Record<FieldKey, true>>;

/** bilingual inline verdict per field (every key exists AR/EN/HI) */
const ERROR_KEYS: Record<FieldKey, I18nKey> = {
  name: "profileNameShort",
  email: "profileEmailInvalid",
  phone: "opgErrPhone",
  birthDate: "opgErrBirthDate",
  gender: "opgErrGender",
  nationality: "opgErrNationality",
  jobTitle: "opgErrJobTitle",
  address: "opgErrAddress",
};

/** fail-soft outcome of ONE save call (admin PATCH / personal PUT) */
type SaveOutcome = { kind: "admin" | "personal"; ok: boolean; message?: string };

/** wraps a call so a rejection becomes a typed outcome instead of a throw */
const settle = (kind: SaveOutcome["kind"], run: Promise<unknown>): Promise<SaveOutcome> =>
  run.then(
    () => ({ kind, ok: true }),
    (e: unknown) => ({ kind, ok: false, message: e instanceof Error ? e.message : String(e) })
  );

/* ------------------------------------------------------------------ */
/* File-local premium atoms (dialog vocabulary — calm, dense, RTL-safe) */
/* ------------------------------------------------------------------ */

/**
 * Section-header law: a tiny gradient bar + a bold, perfectly start-aligned
 * title, with an optional live chip pinned to the inline-end (ms-auto —
 * logical property, so it lands on the far edge in Arabic and English alike).
 */
function SectionHeader({
  id,
  title,
  c1,
  c2,
  end,
}: {
  id: string;
  title: string;
  c1: string;
  c2: string;
  end?: React.ReactNode;
}) {
  return (
    <div className="flex items-center gap-2.5">
      <span
        aria-hidden="true"
        className="h-4 w-1 shrink-0 rounded-full"
        style={{ backgroundImage: grad(c1, c2) }}
      />
      <h3
        id={id}
        className="min-w-0 truncate text-start font-display text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100"
      >
        {title}
      </h3>
      {end ? (
        <span className="ms-auto flex min-w-0 items-center gap-1.5">{end}</span>
      ) : null}
    </div>
  );
}

/** Tiny pulsing dot — the «live query loading» affordance. */
function PulseDot({ className }: { className?: string }) {
  return (
    <span
      aria-hidden="true"
      className={cn("h-1.5 w-1.5 shrink-0 animate-pulse rounded-full bg-slate-400 dark:bg-slate-500", className)}
    />
  );
}

/**
 * KPI tile — tinted icon square + value + micro-label, everything start-aligned
 * (the column inherits the dialog direction; the value row is a flex so single
 * children anchor to the inline-start edge).
 */
function StatTile({
  icon,
  label,
  tint,
  loading = false,
  title,
  value,
}: {
  icon: string;
  label: string;
  tint: string;
  loading?: boolean;
  title?: string;
  value: React.ReactNode;
}) {
  return (
    <div
      className="flex items-center gap-2.5 rounded-xl border border-slate-200/70 bg-white/80 px-2.5 py-2 dark:border-white/10 dark:bg-white/[0.04]"
      title={title}
    >
      <span
        aria-hidden="true"
        className="grid h-7 w-7 shrink-0 place-items-center rounded-lg"
        style={{ background: hexAlpha(tint, 0.1), color: tint }}
      >
        <CatIcon name={icon} className="h-3.5 w-3.5" />
      </span>
      <div className="min-w-0 text-start">
        <p className="flex min-h-[18px] items-center gap-1.5 text-[12.5px] font-extrabold leading-tight text-slate-800 dark:text-slate-100">
          {loading ? (
            <PulseDot />
          ) : (
            <span className="min-w-0 truncate tabular-nums">{value}</span>
          )}
        </p>
        <p className="mt-0.5 truncate text-start text-[9.5px] font-bold uppercase tracking-wide text-slate-400 dark:text-slate-500">
          {label}
        </p>
      </div>
    </div>
  );
}

/**
 * Definition-grid cell — icon tile + micro-label + bold value. The value
 * arrives as a node so each cell can isolate latin content (email / phone)
 * inside a dir="ltr" span while the block itself stays start-anchored.
 */
function DefCell({
  icon,
  tint,
  label,
  title,
  value,
}: {
  icon: string;
  tint: string;
  label: string;
  title?: string;
  value: React.ReactNode;
}) {
  return (
    <div
      className="flex items-center gap-2.5 rounded-xl border border-slate-200/80 bg-slate-50/60 p-3 dark:border-white/10 dark:bg-white/[0.03]"
      title={title}
    >
      <span
        aria-hidden="true"
        className="grid h-8 w-8 shrink-0 place-items-center rounded-lg"
        style={{ background: hexAlpha(tint, 0.1), color: tint }}
      >
        <CatIcon name={icon} className="h-4 w-4" />
      </span>
      <div className="min-w-0 text-start">
        <p className="text-[10px] font-bold uppercase tracking-wide text-slate-400 dark:text-slate-500">
          {label}
        </p>
        <div className="mt-0.5 min-w-0">{value}</div>
      </div>
    </div>
  );
}

/** honest placeholder for a missing personal value */
function EmptyValue() {
  return (
    <p className="truncate text-start text-[12.5px] font-bold text-slate-400 dark:text-slate-500">—</p>
  );
}

/** inline bilingual validation row (the gate's FieldError idiom) */
function FieldErrorRow({ id, message }: { id: string; message: string }) {
  return (
    <p
      id={id}
      role="alert"
      className="mt-1.5 flex items-center gap-1.5 text-start text-[11px] font-bold text-rose-500 dark:text-rose-400"
    >
      <CatIcon name="circle-alert" className="h-3 w-3 shrink-0" />
      {message}
    </p>
  );
}

/* ------------------------------------------------------------------ */
/* The dialog                                                           */
/* ------------------------------------------------------------------ */

export function ProfileDialog({
  open,
  onOpenChange,
  instance,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  instance: InstanceDTO;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();

  /* ROUND 143 — the EFFECTIVE accent pair (owner-picked dashTheme wins over
     the category identity); provided once at the dashboard shell root. */
  const { c1, c2 } = useAccentPair();

  /* the wallet surfaces (balance card + the two dialogs riding along) */
  const [topupOpen, setTopupOpen] = useState(false);
  const [ledgerOpen, setLedgerOpen] = useState(false);

  /* ROUND 144 — edit mode: read-only grids by default, «تعديل البيانات»
     reveals the professional form. Reset when the dialog closes so every
     open starts read-only. */
  const [editing, setEditing] = useState(false);

  const rtl = lang === "ar";

  /* ---------------------------------------------------------------- *
   * LIVE data — every open refetches the shared record (["instance", id]
   * — the same key the shell owns, so the hero always renders the
   * freshest identity) plus the REAL MFA truth query and the wallet
   * (["wallet", id] is SHARED with WalletCard → no duplicate fetches).
   * ---------------------------------------------------------------- */
  const instanceQuery = useQuery({
    queryKey: ["instance", instance.id],
    queryFn: () => fetchInstance(instance.id),
    enabled: open,
    staleTime: 0,
    retry: 0,
  });
  const live = instanceQuery.data?.instance ?? instance;

  /* REAL 2FA state (critical ROUND 144 fix): the stored admin.twoFA flag is
   * a stale wizard-time value that lies; /mfa/setup is the live truth.
   * FAIL-CLOSED — pending or errored renders the OFF state, never a stale
   * optimistic one. */
  const mfaQuery = useQuery({
    queryKey: ["instance-mfa", instance.id],
    queryFn: () => fetchInstanceMfaStatus(instance.id),
    enabled: open,
    staleTime: 0,
    retry: 0,
  });
  const mfaEnabled = mfaQuery.data?.enabled === true;

  const walletQuery = useQuery({
    queryKey: ["wallet", instance.id],
    queryFn: () => fetchWallet(instance.id),
    enabled: open,
    staleTime: 15_000,
    retry: 0,
  });
  const wallet = walletQuery.data ?? null;

  /* last sign-in — the exact topbar pattern: filter the activity feed for
     actLogin rows and take the most recent one. */
  const lastLogin = useMemo(() => {
    const logins = live.activities.filter((a) => a.kind === "actLogin");
    return logins.length > 0 ? logins[logins.length - 1].createdAt : null;
  }, [live.activities]);

  /* ROUND 144 — the owner's PERSONAL profile (ownerProfileJson projection). */
  const profile = live.ownerProfile?.profile ?? null;
  const country = useMemo(
    () => (profile ? COUNTRIES.find((c) => c.code === profile.nationality) : undefined),
    [profile]
  );
  const ageYears = useMemo(() => (profile ? ageYearsOf(profile.birthDate) : null), [profile]);
  const presence = useMemo(() => (profile ? personalPresence(profile) : null), [profile]);
  const completionPct = useMemo(() => {
    if (!presence) return 0;
    const done = PERSONAL_KEYS.reduce((acc, k) => acc + (presence[k] ? 1 : 0), 0);
    return Math.round((done / PERSONAL_KEYS.length) * 100);
  }, [presence]);

  const photo = live.admin.avatarUrl ?? null;

  /* ------------------ profile photo machinery (preserved) ------------------
   * The pick→validate→crop pipeline lives in the SHARED AvatarPicker (the
   * same primitive every team-member surface uses). This dialog only owns
   * the persistence: crop-applied data-URL → PATCH admin.avatarUrl. */
  const savePhoto = useMutation({
    mutationFn: (avatarUrl: string | null) => updateInstance(instance.id, { admin: { avatarUrl } }),
    onSuccess: (_data, avatarUrl) => {
      toast.success(t(avatarUrl ? "profilePhotoSaved" : "profilePhotoRemoved"));
      queryClient.invalidateQueries({ queryKey: ["instance", instance.id] });
      queryClient.invalidateQueries({ queryKey: ["instances"] });
    },
    onError: (err: Error) => toast.error(`${t("errorText")}: ${err.message}`),
  });

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        if (!next) setEditing(false);
        onOpenChange(next);
      }}
    >
      <DialogContent
        dir={rtl ? "rtl" : "ltr"}
        className="flex max-h-[85vh] flex-col gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-lg"
      >
        {/* accessible title/description — the hero carries the visible identity */}
        <DialogHeader className="sr-only">
          <DialogTitle>{t("profilePremiumTitle")}</DialogTitle>
          <DialogDescription>{t("profilePremiumDesc")}</DialogDescription>
        </DialogHeader>

        {/* ── 1 · HERO BANNER — personal identity only (no system badge) ── */}
        <div
          className="relative shrink-0 overflow-hidden rounded-t-[23px] border-b border-slate-200/70 dark:border-white/10"
          style={{
            backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.15)}, ${hexAlpha(c2, 0.15)})`,
          }}
        >
          {/* radial aura blobs + subtle top sheen (logical insets only) */}
          <span
            aria-hidden="true"
            className="absolute -top-14 -end-10 h-32 w-32 rounded-full"
            style={{ background: `radial-gradient(circle, ${hexAlpha(c1, 0.28)}, transparent 70%)` }}
          />
          <span
            aria-hidden="true"
            className="absolute -bottom-16 -start-8 h-36 w-36 rounded-full"
            style={{ background: `radial-gradient(circle, ${hexAlpha(c2, 0.22)}, transparent 70%)` }}
          />
          <span
            aria-hidden="true"
            className="absolute inset-x-0 top-0 h-12 bg-gradient-to-b from-white/25 to-transparent dark:from-white/[0.06]"
          />

          {/* pe-14 keeps the identity column clear of the dialog close button */}
          <div className="relative flex flex-wrap items-start gap-4 p-5 pb-4 pe-14">
            {/* avatar stack — gradient ring around the shared picker; the
                picker's own camera badge owns the bottom-end corner, so the
                online emerald dot rides the bottom-START corner */}
            <div className="relative shrink-0">
              <span
                aria-hidden="true"
                className="block rounded-full p-[3px] shadow-lg"
                style={{ backgroundImage: grad(c1, c2), boxShadow: `0 12px 28px -12px ${hexAlpha(c1, 0.55)}` }}
              >
                <AvatarPicker
                  avatarUrl={photo}
                  name={live.admin.name}
                  c1={c1}
                  c2={c2}
                  size="lg"
                  ring={false}
                  disabled={savePhoto.isPending}
                  onPick={(dataUrl) => savePhoto.mutate(dataUrl)}
                  onRemove={() => savePhoto.mutate(null)}
                />
              </span>
              <span
                aria-hidden="true"
                className="absolute -bottom-1 -start-1 grid h-5 w-5 place-items-center rounded-full bg-emerald-500 shadow-md shadow-emerald-500/40 ring-4 ring-white dark:ring-[#0b0f19]"
              >
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-100/90" />
              </span>
            </div>

            {/* identity column — name / LTR-isolated email / status chips */}
            <div className="relative min-w-0 flex-1">
              <p className="truncate text-start font-display text-[19px] font-extrabold leading-tight text-slate-900 dark:text-white">
                {live.admin.name}
              </p>
              {/* flex row (RTL-aware) anchors the LTR email to the
                  inline-start edge while its glyphs stay in latin order */}
              <p className="mt-0.5 flex min-w-0 items-center">
                <span
                  dir="ltr"
                  className="min-w-0 truncate text-[12px] font-semibold text-slate-500 dark:text-slate-400"
                >
                  {live.admin.email}
                </span>
              </p>

              <div className="mt-2 flex flex-wrap items-center gap-1.5">
                {/* verified — emerald glass */}
                <span className="inline-flex items-center gap-1 rounded-full border border-emerald-200/80 bg-emerald-50/80 px-2 py-0.5 text-[10.5px] font-extrabold text-emerald-700 backdrop-blur-sm dark:border-emerald-500/25 dark:bg-emerald-500/10 dark:text-emerald-300">
                  <CatIcon name="badge-check" className="h-3 w-3" />
                  {t("profileVerifiedLabel")}
                </span>

                {/* role — owner (crown, amber) / manager (shield-user, brand) */}
                <span
                  className={cn(
                    "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10.5px] font-extrabold",
                    live.admin.role === "owner"
                      ? "border-amber-200/80 bg-amber-50/90 text-amber-700 dark:border-amber-500/25 dark:bg-amber-500/10 dark:text-amber-300"
                      : "border-brand-200/80 bg-brand-50/90 text-brand-700 dark:border-brand-500/25 dark:bg-brand-500/10 dark:text-brand-300"
                  )}
                >
                  <CatIcon
                    name={live.admin.role === "owner" ? "crown" : "shield-user"}
                    className="h-3 w-3"
                  />
                  {live.admin.role === "owner" ? t("wzAdminRoleOwner") : t("wzAdminRoleManager")}
                </span>

                {/* 2FA state — the LIVE MFA truth, fail-closed (pending or
                    errored renders OFF; the stored flag is never trusted) */}
                <span
                  className={cn(
                    "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10.5px] font-extrabold",
                    mfaEnabled
                      ? "border-emerald-200/80 bg-emerald-50/80 text-emerald-700 backdrop-blur-sm dark:border-emerald-500/25 dark:bg-emerald-500/10 dark:text-emerald-300"
                      : "border-amber-200/80 bg-amber-50/90 text-amber-700 dark:border-amber-500/25 dark:bg-amber-500/10 dark:text-amber-300"
                  )}
                >
                  <CatIcon
                    name={mfaEnabled ? "shield-check" : "circle-alert"}
                    className="h-3 w-3"
                  />
                  {t("profile2faLabel")} · {t(mfaEnabled ? "userSheetOn" : "userSheetOff")}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* ── 2 · LIVE STAT STRIP — the two PERSONAL timeline facts ───── */}
        <div
          className="card-in grid shrink-0 grid-cols-2 gap-2 border-b border-slate-200/70 bg-slate-50/60 p-3 dark:border-white/10 dark:bg-white/[0.02]"
          style={{ "--i": 1 } as React.CSSProperties}
        >
          <StatTile
            icon="calendar"
            tint={c1}
            label={t("profileSinceLabel")}
            title={fullDate(live.createdAt, lang)}
            value={relativeTime(live.createdAt, lang)}
          />
          <StatTile
            icon="clock"
            tint={c2}
            label={t("profileLastLoginLabel")}
            title={lastLogin ? fullDate(lastLogin, lang) : undefined}
            value={lastLogin ? relativeTime(lastLogin, lang) : "—"}
          />
        </div>

        {/* ── 3 · 4 · 5 · scrollable body ─────────────────────────────── */}
        <div className="nice-scroll min-h-0 flex-1 space-y-5 overflow-y-auto p-4 sm:p-5">
          {editing ? (
            /* 5 · تعديل البيانات — the professional form (inner remount
               pattern: mounted inside DialogContent, fresh seeds on every
               reveal) replaces the read-only grids while active */
            <ProfileEditForm
              instance={live}
              c1={c1}
              c2={c2}
              onDone={() => setEditing(false)}
            />
          ) : (
            <>
              {/* 3 · بيانات الحساب — name + email (personal data only) */}
              <section
                className="card-in space-y-2.5"
                style={{ "--i": 2 } as React.CSSProperties}
                aria-labelledby="pd-account"
              >
                <SectionHeader id="pd-account" title={t("profileAccountSection")} c1={c1} c2={c2} />
                <div className="grid gap-2.5 sm:grid-cols-2">
                  <DefCell
                    icon="user-round"
                    tint={c1}
                    label={t("profileNameLabel")}
                    title={live.admin.name}
                    value={
                      <p className="truncate text-start text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                        {live.admin.name}
                      </p>
                    }
                  />
                  <DefCell
                    icon="mail"
                    tint={c2}
                    label={t("profileEmailLabel")}
                    title={live.admin.email}
                    value={
                      <p className="flex min-w-0 items-center">
                        <span
                          dir="ltr"
                          className="min-w-0 truncate text-[12.5px] font-bold text-slate-700 dark:text-slate-200"
                        >
                          {live.admin.email}
                        </span>
                      </p>
                    }
                  />
                </div>
              </section>

              {/* 4 · البيانات الشخصية — the owner-profile fields */}
              <section
                className="card-in space-y-2.5"
                style={{ "--i": 3 } as React.CSSProperties}
                aria-labelledby="pd-personal"
              >
                <SectionHeader
                  id="pd-personal"
                  title={t("profilePersonalSection")}
                  c1={c1}
                  c2={c2}
                  end={
                    /* the personal-completion chip — % of the 6 fields present */
                    <span
                      aria-label={`${t("profilePersonalCompletion")}: ${completionPct}%`}
                      className="inline-flex min-w-0 items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/80 px-2 py-0.5 text-[10.5px] font-extrabold text-slate-600 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-300"
                    >
                      <CatIcon
                        name="sparkles"
                        className="h-3 w-3 shrink-0"
                        style={{ color: c1 }}
                      />
                      <span className="hidden truncate sm:inline">{t("profilePersonalCompletion")}</span>
                      <span dir="ltr" className="shrink-0 tabular-nums">
                        {fmtNum(completionPct, lang)}%
                      </span>
                    </span>
                  }
                />

                {/* one-line hint under the section header */}
                <p className="flex items-start gap-1.5 text-start text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                  <CatIcon name="info" className="mt-px h-3 w-3 shrink-0" />
                  <span className="min-w-0">{t("profilePersonalHint")}</span>
                </p>

                {/* slim personal-completion meter */}
                <div
                  role="progressbar"
                  aria-label={t("profilePersonalCompletion")}
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-valuenow={completionPct}
                  className="h-1.5 w-full overflow-hidden rounded-full bg-slate-200/80 dark:bg-white/10"
                >
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{ width: `${completionPct}%`, backgroundImage: grad(c1, c2) }}
                  />
                </div>

                {/* the read-only personal grid — honest «—» when missing */}
                <div className="grid gap-2.5 sm:grid-cols-2">
                  {/* phone — LTR-isolated (international format) */}
                  <DefCell
                    icon="phone"
                    tint={c1}
                    label={t("profilePhoneLabel")}
                    title={profile?.phone || undefined}
                    value={
                      profile?.phone ? (
                        <p className="flex min-w-0 items-center">
                          <span
                            dir="ltr"
                            className="min-w-0 truncate text-[12.5px] font-bold tabular-nums text-slate-700 dark:text-slate-200"
                          >
                            {profile.phone}
                          </span>
                        </p>
                      ) : (
                        <EmptyValue />
                      )
                    }
                  />

                  {/* birth date — date-only rendering + the age chip */}
                  <DefCell
                    icon="calendar"
                    tint={c2}
                    label={t("profileBirthLabel")}
                    title={profile?.birthDate || undefined}
                    value={
                      profile && BIRTH_RE.test(profile.birthDate) ? (
                        <p className="flex min-w-0 flex-wrap items-center gap-1.5">
                          <span className="min-w-0 truncate text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                            {dateOnly(profile.birthDate, lang)}
                          </span>
                          {ageYears !== null ? (
                            <span
                              className="inline-flex shrink-0 items-center rounded-full px-1.5 py-px text-[9.5px] font-extrabold"
                              style={{ background: hexAlpha(c1, 0.1), color: c1 }}
                            >
                              {t("profileAgeYears", { age: fmtNum(ageYears, lang) })}
                            </span>
                          ) : null}
                        </p>
                      ) : (
                        <EmptyValue />
                      )
                    }
                  />

                  {/* nationality — resolved through the shared COUNTRIES catalog */}
                  <DefCell
                    icon="flag"
                    tint={c1}
                    label={t("profileNationalityLabel")}
                    title={country?.name}
                    value={
                      country ? (
                        <p className="truncate text-start text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                          {country.name}
                        </p>
                      ) : (
                        <EmptyValue />
                      )
                    }
                  />

                  {/* job title */}
                  <DefCell
                    icon="briefcase"
                    tint={c2}
                    label={t("profileJobLabel")}
                    title={profile?.jobTitle || undefined}
                    value={
                      profile?.jobTitle ? (
                        <p className="truncate text-start text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                          {profile.jobTitle}
                        </p>
                      ) : (
                        <EmptyValue />
                      )
                    }
                  />

                  {/* gender */}
                  <DefCell
                    icon="users"
                    tint={c1}
                    label={t("profileGenderLabel")}
                    value={
                      profile?.gender === "male" || profile?.gender === "female" ? (
                        <p className="truncate text-start text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                          {t(profile.gender === "male" ? "staffGenderMale" : "staffGenderFemale")}
                        </p>
                      ) : (
                        <EmptyValue />
                      )
                    }
                  />

                  {/* address — the widest personal fact, full-width cell */}
                  <DefCell
                    icon="map-pin"
                    tint={c2}
                    label={t("profileAddressLabel")}
                    title={profile?.address || undefined}
                    value={
                      profile?.address ? (
                        <p className="truncate text-start text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                          {profile.address}
                        </p>
                      ) : (
                        <EmptyValue />
                      )
                    }
                  />
                </div>

                {/* slim gradient row — reveals the professional edit form */}
                <Button
                  type="button"
                  onClick={() => setEditing(true)}
                  className="h-10 w-full rounded-xl text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.98]"
                  style={{
                    backgroundImage: grad(c1, c2),
                    boxShadow: `0 10px 24px -10px ${hexAlpha(c1, 0.55)}`,
                  }}
                >
                  <CatIcon name="pencil" className="h-3.5 w-3.5" />
                  {t("profileEditOpenBtn")}
                </Button>
              </section>
            </>
          )}

          {/* 5 · المحفظة — the premium balance card + its live header chip */}
          <section
            className="card-in space-y-2.5"
            style={{ "--i": editing ? 3 : 4 } as React.CSSProperties}
            aria-labelledby="pd-wallet"
          >
            <SectionHeader
              id="pd-wallet"
              title={t("profileWalletSection")}
              c1={c1}
              c2={c2}
              end={
                walletQuery.isPending ? (
                  <span className="inline-flex items-center rounded-full border border-emerald-200/70 bg-emerald-50/80 px-2 py-0.5 dark:border-emerald-500/25 dark:bg-emerald-500/10">
                    <PulseDot className="bg-emerald-500 dark:bg-emerald-400" />
                  </span>
                ) : (
                  <span
                    aria-label={t("profileWalletBalance")}
                    className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200/70 bg-emerald-50/80 px-2 py-0.5 text-[10.5px] font-extrabold text-emerald-700 dark:border-emerald-500/25 dark:bg-emerald-500/10 dark:text-emerald-300"
                  >
                    <CatIcon name="wallet" className="h-3 w-3" />
                    <span dir="ltr" className="tabular-nums">
                      {walletQuery.isError
                        ? "—"
                        : `${fmtNum(wallet ? Math.round(wallet.balanceMinor) / 100 : 0, lang)} ${
                            live.org.currency || "SAR"
                          }`}
                    </span>
                  </span>
                )
              }
            />
            <WalletCard
              instance={instance}
              onTopup={() => setTopupOpen(true)}
              onLedger={() => setLedgerOpen(true)}
            />
          </section>
        </div>

        {/* ── footer — the tiny security line + the platform mark ─────── */}
        <footer className="flex shrink-0 items-center justify-between gap-2 border-t border-slate-200/70 bg-slate-50/60 px-4 py-2.5 dark:border-white/10 dark:bg-white/[0.02]">
          <p className="flex min-w-0 items-center gap-1.5 text-[10px] font-bold text-slate-400 dark:text-slate-500">
            <CatIcon name="shield-check" className="h-3 w-3 shrink-0" />
            <span className="truncate">{t("dashSecuredSession")}</span>
          </p>
          <span
            dir="ltr"
            className="shrink-0 font-display text-[10px] font-extrabold tracking-wide text-slate-300 dark:text-slate-600"
          >
            Ashrilogic
          </span>
        </footer>
      </DialogContent>

      {/* the wallet dialogs — mounted beside the profile dialog so their
          skeletons layer over it cleanly (unchanged mounting pattern) */}
      <WalletTopupDialog open={topupOpen} onOpenChange={setTopupOpen} instance={instance} />
      <WalletLedgerDialog open={ledgerOpen} onOpenChange={setLedgerOpen} instance={instance} />
    </Dialog>
  );
}

/* ------------------------------------------------------------------ */
/* The professional edit form (inner-component remount pattern)         */
/* ------------------------------------------------------------------ */

/**
 * ROUND 144 — the edit-mode form. Mounted inside DialogContent only while
 * `editing` is true, so it seeds fresh from the live instance every time it
 * is revealed (and Radix re-seeds the whole dialog on every open).
 *
 * Save is diff-based and split per concern, fail-soft per call:
 *  (a) name/email dirty → PATCH updateInstance({ admin }) — the existing
 *      settings-view path;
 *  (b) ANY personal field dirty → PUT saveOwnerProfile with the COMPLETE
 *      merged payload (all six fields required, exactly the strict gate
 *      contract). Both run in parallel when both are dirty; each failure
 *      surfaces its own toast while the successful calls still invalidate
 *      and refresh. Full success flips back to read-only with fresh data.
 */
function ProfileEditForm({
  instance,
  c1,
  c2,
  onDone,
}: {
  instance: InstanceDTO;
  c1: string;
  c2: string;
  onDone: () => void;
}) {
  const { t } = useT();
  const queryClient = useQueryClient();

  const stored = instance.ownerProfile?.profile ?? undefined;

  const [name, setName] = useState(instance.admin.name);
  const [email, setEmail] = useState(instance.admin.email);
  const [gender, setGender] = useState<MemberGender | "">(stored?.gender ?? "");
  const [birthDate, setBirthDate] = useState(stored?.birthDate ?? "");
  const [nationality, setNationality] = useState(stored?.nationality ?? "");
  const [jobTitle, setJobTitle] = useState(stored?.jobTitle ?? "");
  const [phone, setPhone] = useState(stored?.phone ?? "");
  const [address, setAddress] = useState(stored?.address ?? "");
  const [errors, setErrors] = useState<FieldErrors>({});

  const clearError = (k: FieldKey) => {
    setErrors((prev) => {
      if (!prev[k]) return prev;
      const next = { ...prev };
      delete next[k];
      return next;
    });
  };

  /* diff against the mounted snapshot — only what actually changed is sent */
  const nameDirty = name.trim() !== instance.admin.name;
  const emailDirty = email.trim() !== instance.admin.email;
  const adminDirty = nameDirty || emailDirty;
  const personalDirty =
    gender !== (stored?.gender ?? "") ||
    birthDate.trim() !== (stored?.birthDate ?? "") ||
    nationality !== (stored?.nationality ?? "") ||
    jobTitle.trim() !== (stored?.jobTitle ?? "") ||
    phone.trim() !== (stored?.phone ?? "") ||
    address.trim() !== (stored?.address ?? "");
  const dirty = adminDirty || personalDirty;

  const save = useMutation({
    mutationFn: async (): Promise<SaveOutcome[]> => {
      const calls: { kind: SaveOutcome["kind"]; run: Promise<unknown> }[] = [];
      if (adminDirty) {
        const admin: { name?: string; email?: string } = {};
        if (nameDirty) admin.name = name.trim();
        if (emailDirty) admin.email = email.trim();
        calls.push({ kind: "admin", run: updateInstance(instance.id, { admin }) });
      }
      if (personalDirty) {
        /* the COMPLETE merged profile — every field is required by the
           strict server contract (zod mirrors the gate 1:1) */
        const payload: OwnerProfilePayload = {
          gender: gender as MemberGender,
          birthDate: birthDate.trim(),
          address: address.trim(),
          nationality,
          jobTitle: jobTitle.trim(),
          phone: phone.trim(),
        };
        calls.push({ kind: "personal", run: saveOwnerProfile(instance.id, payload) });
      }
      return Promise.all(calls.map((c) => settle(c.kind, c.run)));
    },
    onSuccess: (outcomes) => {
      const adminOk = outcomes.some((o) => o.kind === "admin" && o.ok);
      const personalOk = outcomes.some((o) => o.kind === "personal" && o.ok);
      /* fail-soft per call — every failure gets its own toast */
      outcomes
        .filter((o) => !o.ok)
        .forEach((o) => toast.error(`${t("errorText")}: ${o.message ?? t("errorText")}`));

      if (!adminOk && !personalOk) return; /* nothing landed — stay editing */
      void queryClient.invalidateQueries({ queryKey: ["instance", instance.id] });
      void queryClient.invalidateQueries({ queryKey: ["instances"] });
      /* flip back to read-only ONLY on full success so a failed half can
         be retried without losing the user's edits */
      if (outcomes.every((o) => o.ok)) {
        toast.success(t(personalOk ? "profilePersonalSaved" : "profileChangesSaved"));
        onDone();
      }
    },
    onError: (err: Error) => toast.error(`${t("errorText")}: ${err.message}`),
  });

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (save.isPending) return;

    /* the platform demands the owner's personal data with full precision —
       every field validates (the same rules the server enforces) */
    const next: FieldErrors = {};
    if (name.trim().length < 2) next.name = true;
    if (!EMAIL_RE.test(email.trim())) next.email = true;
    if (gender !== "male" && gender !== "female") next.gender = true;
    if (!validBirthDate(birthDate)) next.birthDate = true;
    if (!COUNTRY_CODES.has(nationality)) next.nationality = true;
    const job = jobTitle.trim();
    if (job.length < 2 || job.length > 80) next.jobTitle = true;
    const addr = address.trim();
    if (addr.length < 10 || addr.length > 220) next.address = true;
    if (!PHONE_RE.test(phone.trim())) next.phone = true;

    setErrors(next);
    if (Object.keys(next).length > 0) return;
    if (!dirty) {
      toast.info(t("settingsNoChanges"));
      return;
    }
    save.mutate();
  };

  const invalid = (k: FieldKey) => errors[k] === true;
  const errClass = (k: FieldKey) =>
    invalid(k) ? "border-rose-400 focus-visible:ring-rose-500/20" : undefined;
  const errId = (k: FieldKey) => `pf-${k}-err`;

  return (
    <section
      className="card-in space-y-3.5"
      style={{ "--i": 2 } as React.CSSProperties}
      aria-labelledby="pd-edit"
    >
      <SectionHeader
        id="pd-edit"
        title={t("profileEditTitle")}
        c1={c1}
        c2={c2}
        end={
          dirty ? (
            <span className="inline-flex items-center gap-1 rounded-full bg-brand-100 px-1.5 py-px text-[10.5px] font-extrabold text-brand-700 dark:bg-brand-500/15 dark:text-brand-300">
              <span
                aria-hidden="true"
                className="h-1 w-1 animate-pulse rounded-full bg-brand-500 dark:bg-brand-300"
              />
              {t("profileUnsaved")}
            </span>
          ) : null
        }
      />

      {/* noValidate — the custom bilingual validation below replaces the
          browser's default (invisible in headless, English-only) messages. */}
      <form onSubmit={onSubmit} noValidate className="space-y-3.5">
        <div className="grid gap-3.5 sm:grid-cols-2">
          {/* name */}
          <div>
            <Label htmlFor="pf-name" className={WZ_LABEL}>
              {t("profileNameLabel")} <span className="text-rose-500" aria-hidden="true">*</span>
            </Label>
            <Input
              id="pf-name"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                clearError("name");
              }}
              placeholder={t("profileNamePh")}
              autoComplete="name"
              aria-invalid={invalid("name") || undefined}
              aria-describedby={invalid("name") ? errId("name") : undefined}
              className={cn(WZ_INPUT, errClass("name"))}
            />
            {invalid("name") ? <FieldErrorRow id={errId("name")} message={t(ERROR_KEYS.name)} /> : null}
          </div>

          {/* email */}
          <div>
            <Label htmlFor="pf-email" className={WZ_LABEL}>
              {t("profileEmailLabel")} <span className="text-rose-500" aria-hidden="true">*</span>
            </Label>
            <Input
              id="pf-email"
              type="email"
              dir="ltr"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                clearError("email");
              }}
              placeholder="name@company.com"
              autoComplete="email"
              aria-invalid={invalid("email") || undefined}
              aria-describedby={invalid("email") ? errId("email") : undefined}
              className={cn(WZ_INPUT, "text-start", errClass("email"))}
            />
            {invalid("email") ? <FieldErrorRow id={errId("email")} message={t(ERROR_KEYS.email)} /> : null}
          </div>

          {/* phone — LTR-isolated international format */}
          <div>
            <Label htmlFor="pf-phone" className={WZ_LABEL}>
              {t("profilePhoneLabel")} <span className="text-rose-500" aria-hidden="true">*</span>
            </Label>
            <Input
              id="pf-phone"
              type="tel"
              dir="ltr"
              inputMode="tel"
              value={phone}
              onChange={(e) => {
                setPhone(e.target.value);
                clearError("phone");
              }}
              placeholder={t("profilePhonePh")}
              autoComplete="tel"
              aria-invalid={invalid("phone") || undefined}
              aria-describedby={invalid("phone") ? errId("phone") : undefined}
              className={cn(WZ_INPUT, "text-start", errClass("phone"))}
            />
            {invalid("phone") ? <FieldErrorRow id={errId("phone")} message={t(ERROR_KEYS.phone)} /> : null}
          </div>

          {/* birth date — the strict 13–120 window */}
          <div>
            <Label htmlFor="pf-birth" className={WZ_LABEL}>
              {t("profileBirthLabel")} <span className="text-rose-500" aria-hidden="true">*</span>
            </Label>
            {/* R163 — the shared premium date field (WZ rhythm): brand
                calendar tile at the field's far right in Arabic, clear-X +
                Arabic long-form hint built in; the strict 13–120 window is
                preserved via the native min/max attributes. */}
            <PremiumDateInput
              id="pf-birth"
              size="lg"
              value={birthDate}
              min={MIN_BIRTH_DAY}
              max={MAX_BIRTH_DAY}
              onChange={(e) => {
                setBirthDate(e.target.value);
                clearError("birthDate");
              }}
              aria-invalid={invalid("birthDate") || undefined}
              aria-describedby={invalid("birthDate") ? errId("birthDate") : undefined}
              inputClassName={errClass("birthDate")}
            />
            <p className="mt-1 text-[10px] font-semibold text-slate-400 dark:text-slate-500">
              {t("opgBirthDateHint")}
            </p>
            {invalid("birthDate") ? (
              <FieldErrorRow id={errId("birthDate")} message={t(ERROR_KEYS.birthDate)} />
            ) : null}
          </div>

          {/* gender — segmented select over the two enum values */}
          <div>
            <Label htmlFor="pf-gender" className={WZ_LABEL}>
              {t("profileGenderLabel")} <span className="text-rose-500" aria-hidden="true">*</span>
            </Label>
            <Select
              value={gender}
              onValueChange={(v) => {
                setGender(v === "female" ? "female" : "male");
                clearError("gender");
              }}
            >
              <SelectTrigger
                id="pf-gender"
                className={cn(WZ_INPUT, errClass("gender"))}
                aria-invalid={invalid("gender") || undefined}
                aria-describedby={invalid("gender") ? errId("gender") : undefined}
              >
                <SelectValue placeholder={t("profileGenderLabel")} />
              </SelectTrigger>
              <SelectContent className="max-h-72">
                <SelectGroup>
                  <SelectItem value="male">{t("staffGenderMale")}</SelectItem>
                  <SelectItem value="female">{t("staffGenderFemale")}</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
            {invalid("gender") ? (
              <FieldErrorRow id={errId("gender")} message={t(ERROR_KEYS.gender)} />
            ) : null}
          </div>

          {/* nationality — the shared COUNTRIES catalog */}
          <div>
            <Label htmlFor="pf-nationality" className={WZ_LABEL}>
              {t("profileNationalityLabel")} <span className="text-rose-500" aria-hidden="true">*</span>
            </Label>
            <Select
              value={nationality}
              onValueChange={(v) => {
                setNationality(v);
                clearError("nationality");
              }}
            >
              <SelectTrigger
                id="pf-nationality"
                className={cn(WZ_INPUT, errClass("nationality"))}
                aria-invalid={invalid("nationality") || undefined}
                aria-describedby={invalid("nationality") ? errId("nationality") : undefined}
              >
                <SelectValue placeholder={t("opgNationalityPh")} />
              </SelectTrigger>
              <SelectContent className="max-h-72">
                <SelectGroup>
                  {COUNTRIES.map((country) => (
                    <SelectItem key={country.code} value={country.code}>
                      {country.name}
                    </SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
            {invalid("nationality") ? (
              <FieldErrorRow id={errId("nationality")} message={t(ERROR_KEYS.nationality)} />
            ) : null}
          </div>

          {/* job title */}
          <div>
            <Label htmlFor="pf-job" className={WZ_LABEL}>
              {t("profileJobLabel")} <span className="text-rose-500" aria-hidden="true">*</span>
            </Label>
            <Input
              id="pf-job"
              value={jobTitle}
              onChange={(e) => {
                setJobTitle(e.target.value);
                clearError("jobTitle");
              }}
              placeholder={t("opgJobTitlePh")}
              autoComplete="organization-title"
              aria-invalid={invalid("jobTitle") || undefined}
              aria-describedby={invalid("jobTitle") ? errId("jobTitle") : undefined}
              className={cn(WZ_INPUT, errClass("jobTitle"))}
            />
            {invalid("jobTitle") ? (
              <FieldErrorRow id={errId("jobTitle")} message={t(ERROR_KEYS.jobTitle)} />
            ) : null}
          </div>

          {/* address — the widest fact, full-width textarea */}
          <div className="sm:col-span-2">
            <Label htmlFor="pf-address" className={WZ_LABEL}>
              {t("profileAddressLabel")} <span className="text-rose-500" aria-hidden="true">*</span>
            </Label>
            <Textarea
              id="pf-address"
              value={address}
              onChange={(e) => {
                setAddress(e.target.value);
                clearError("address");
              }}
              placeholder={t("opgAddressPh")}
              autoComplete="street-address"
              rows={2}
              aria-invalid={invalid("address") || undefined}
              aria-describedby={invalid("address") ? errId("address") : undefined}
              className={cn(
                "field-sizing-normal min-h-[76px] w-full resize-none rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-[13px] font-semibold text-slate-800 transition placeholder:font-normal placeholder:text-slate-400",
                "focus:border-brand-400 focus:outline-none focus:ring-4 focus:ring-brand-500/15",
                "dark:border-white/10 dark:bg-ink-900/60 dark:text-slate-100 dark:placeholder:text-slate-500",
                "aria-invalid:border-rose-400 aria-invalid:ring-2 aria-invalid:ring-rose-500/20"
              )}
            />
            {invalid("address") ? (
              <FieldErrorRow id={errId("address")} message={t(ERROR_KEYS.address)} />
            ) : null}
          </div>
        </div>

        {/* save (accent gradient) + cancel — returns to read-only */}
        <div className="flex flex-wrap items-center gap-2.5">
          <Button
            type="submit"
            disabled={save.isPending || !dirty}
            className="h-11 min-w-0 flex-1 rounded-xl text-[13px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.98] disabled:opacity-60"
            style={{ backgroundImage: grad(c1, c2), boxShadow: `0 14px 30px -12px ${hexAlpha(c1, 0.6)}` }}
          >
            {save.isPending ? (
              <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
            ) : (
              <CatIcon name="save" className="h-4 w-4" />
            )}
            {t("profileSaveChanges")}
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={onDone}
            disabled={save.isPending}
            className="h-11 shrink-0 rounded-xl border-slate-200 bg-white px-4 text-[13px] font-extrabold text-slate-600 shadow-xs transition hover:bg-slate-50 active:scale-[0.98] dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:bg-white/[0.08]"
          >
            <CatIcon name="x" className="h-4 w-4" />
            {t("profileEditCloseBtn")}
          </Button>
        </div>
      </form>
    </section>
  );
}
