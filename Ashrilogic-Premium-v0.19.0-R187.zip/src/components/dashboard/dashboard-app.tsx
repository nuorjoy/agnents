"use client";

/**
 * Ashrilogic — executive dashboard shell.
 * Real data only: the instance (org/admin/prefs/modules), deterministic
 * stats and team members come from GET /api/instances/[id] via react-query.
 * Reload-safe: the store persists view + currentInstanceId. A 401 (expired
 * workspace session) renders the inline re-auth gate instead of an error.
 *
 * ROUND 47 — trial entitlement: while the workspace is inside the TRIAL_DAYS free
 * trial everything works; once it expires with no activated plan the shell
 * hard-restricts the tenant to the SUBSCRIPTION view (the server refuses
 * every business API with 403 TRIAL_EXPIRED — this client gate mirrors it
 * for UX so locked surfaces are never even rendered).
 */
import { useEffect, useState } from "react";
import { MotionConfig } from "framer-motion";
import dynamic from "next/dynamic";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useT } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import { can, VIEW_PERMISSION, type WorkspaceRole } from "@/lib/permissions";
import { PERM_LABEL_I18N, ROLE_NAME_I18N } from "@/components/dashboard/views/roles-permissions-tab";
import { fetchInstance, ApiError } from "@/lib/api-client";
import { APP_VERSION } from "@/lib/version";
import { CatIcon } from "@/components/icon";
import { dashVars, fontVars } from "@/lib/surface-styling";
import { cn, grad } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { InstanceLoginGate } from "@/components/auth/instance-login-gate";
import { Sidebar } from "@/components/dashboard/sidebar";
import { useSidebarPin, DASHBOARD_SIDEBAR_PIN_KEY } from "@/hooks/use-sidebar-pin";
import { InstancePresenceProvider } from "@/components/dashboard/instance-presence-provider";
import { Topbar } from "@/components/dashboard/topbar";
import { OverviewView } from "@/components/dashboard/views/overview-view";
import { AccentProvider, resolveAccentPair } from "@/components/dashboard/accent-context";
import { FeatureGate } from "@/components/dashboard/feature-gate";
import { OwnerProfileGate } from "@/components/dashboard/owner-profile-gate";
import { ShiftStatusBar } from "@/components/dashboard/shift/shift-status-bar";
import { SkipLink } from "@/components/skip-link";
import { useBrandFavicon } from "@/hooks/use-brand-favicon";
import { NotificationSoundPlayer } from "@/components/notification-sound-player";

import "@/lib/i18n/fragments/app";
/* ROUND 42 — performance: every dashboard view except the default
   (overview) is split into its own chunk and fetched on demand. The heavy
   analytics bundle (recharts), the module workspace, the website builder,
   the settings/backup console etc. no longer ship with the first dashboard
   load — the shell + overview stay instant, the rest streams in while the
   premium skeleton below keeps the layout perfectly stable. */
function ViewSkeleton() {
  return (
    <div aria-busy="true" aria-label="Loading view" className="space-y-4">
      <div className="flex items-center gap-3">
        <Skeleton className="h-10 w-10 rounded-2xl" />
        <div className="flex-1 space-y-2">
          <Skeleton className="h-5 w-56 rounded-lg" />
          <Skeleton className="h-3 w-80 rounded-lg" />
        </div>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-28 w-full rounded-2xl" />
        ))}
      </div>
      <Skeleton className="h-72 w-full rounded-2xl" />
    </div>
  );
}

const AnalyticsView = dynamic(
  () => import("@/components/dashboard/views/analytics-view").then((m) => m.AnalyticsView),
  { ssr: false, loading: ViewSkeleton }
);
const ModulesView = dynamic(
  () => import("@/components/dashboard/views/modules-view").then((m) => m.ModulesView),
  { ssr: false, loading: ViewSkeleton }
);
const NotificationsView = dynamic(
  () => import("@/components/dashboard/views/notifications-view").then((m) => m.NotificationsView),
  { ssr: false, loading: ViewSkeleton }
);
const ActivityView = dynamic(
  () => import("@/components/dashboard/views/activity-view").then((m) => m.ActivityView),
  { ssr: false, loading: ViewSkeleton }
);
const WebsiteView = dynamic(
  () => import("@/components/dashboard/views/website-view").then((m) => m.WebsiteView),
  { ssr: false, loading: ViewSkeleton }
);
const StoreView = dynamic(
  () => import("@/components/dashboard/views/store-view").then((m) => m.StoreView),
  { ssr: false, loading: ViewSkeleton }
);
/* ROUND 114 — the order-event webhook console (integrations surface). */
const WebhooksView = dynamic(
  () => import("@/components/dashboard/views/webhooks-view").then((m) => m.WebhooksView),
  { ssr: false, loading: ViewSkeleton }
);
const CustomersView = dynamic(
  () => import("@/components/dashboard/views/customers-view").then((m) => m.CustomersView),
  { ssr: false, loading: ViewSkeleton }
);
const TeamView = dynamic(
  () => import("@/components/dashboard/views/team-view").then((m) => m.TeamView),
  { ssr: false, loading: ViewSkeleton }
);
const SettingsView = dynamic(
  () => import("@/components/dashboard/views/settings-view").then((m) => m.SettingsView),
  { ssr: false, loading: ViewSkeleton }
);
/* ROUND 87 — the workspace trash (سلة المحذوفات) */
const TrashView = dynamic(
  () => import("@/components/dashboard/views/trash-view").then((m) => m.TrashView),
  { ssr: false, loading: ViewSkeleton }
);
/* ROUND 141 — متجر الإضافات (lazily imported like every sibling view). */
const AddonsView = dynamic(
  () => import("@/components/dashboard/views/addons-view").then((m) => m.AddonsView),
  { ssr: false, loading: ViewSkeleton }
);
const BillingView = dynamic(
  () => import("@/components/dashboard/views/billing-view").then((m) => m.BillingView),
  { ssr: false, loading: ViewSkeleton }
);
const ModuleWorkspace = dynamic(
  () => import("@/components/dashboard/views/module-workspace").then((m) => m.ModuleWorkspace),
  { ssr: false, loading: ViewSkeleton }
);

function DashSkeleton() {
  /* mirror the sidebar's pinned state so the loading skeleton's reserved
   * aside width matches the live shell — no layout shift on first paint
   * when the user has previously unpinned the rail. */
  const { isPinned } = useSidebarPin(DASHBOARD_SIDEBAR_PIN_KEY);
  return (
    <div className="min-h-screen" aria-busy="true" aria-label="Loading">
      <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden="true" />
      <div className="flex min-h-screen">
        {/* sidebar skeleton */}
        <aside className={cn("fixed inset-y-0 start-0 hidden flex-col border-e border-slate-200/70 bg-white/95 p-4 transition-all duration-300 ease-in-out dark:border-white/[0.07] dark:bg-ink-950/95 lg:flex", isPinned ? "w-64" : "w-16")}>
          <div className={cn("flex items-center", isPinned ? "gap-2.5" : "justify-center")}>
            <Skeleton className="h-9 w-9 shrink-0 rounded-xl" />
            {isPinned ? (
              <div className="flex-1 space-y-1.5">
                <Skeleton className="h-3.5 w-32" />
                <Skeleton className="h-2.5 w-24" />
              </div>
            ) : null}
          </div>
          <div className="mt-6 space-y-2">
            {Array.from({ length: 10 }).map((_, i) => (
              <Skeleton key={i} className="h-9 w-full rounded-xl" />
            ))}
          </div>
          <Skeleton className="mt-auto h-14 w-full rounded-xl" />
        </aside>

        <div className={cn("flex min-w-0 flex-1 flex-col transition-all duration-300 ease-in-out", isPinned ? "lg:ps-64" : "lg:ps-16")}>
          <div className="flex h-16 items-center gap-3 border-b border-slate-200/70 px-4 sm:px-6 lg:px-8 dark:border-white/[0.07]">
            <Skeleton className="h-10 w-10 rounded-xl lg:hidden" />
            <Skeleton className="hidden h-10 w-72 rounded-xl sm:block" />
            <div className="ms-auto flex gap-1.5">
              <Skeleton className="h-10 w-24 rounded-xl" />
              <Skeleton className="h-10 w-10 rounded-xl" />
              <Skeleton className="h-10 w-10 rounded-xl" />
            </div>
          </div>
          <main className="flex-1 space-y-4 px-4 py-6 sm:px-6 lg:px-8">
            <Skeleton className="h-8 w-56 rounded-xl" />
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-36 rounded-3xl" />
              ))}
            </div>
            <div className="grid gap-4 lg:grid-cols-3">
              <Skeleton className="h-72 rounded-3xl lg:col-span-2" />
              <Skeleton className="h-72 rounded-3xl" />
            </div>
            <div className="grid gap-4 lg:grid-cols-3">
              <Skeleton className="h-64 rounded-3xl" />
              <Skeleton className="h-64 rounded-3xl" />
              <Skeleton className="h-64 rounded-3xl" />
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}

export function DashboardApp() {
  const { t } = useT();
  const id = useAppStore((s) => s.currentInstanceId);
  const dashView = useAppStore((s) => s.dashView);
  const exitToLanding = useAppStore((s) => s.exitToLanding);
  const setView = useAppStore((s) => s.setView);
  /* ROUND 78 — the strict-RBAC preview lens ("view as role") */
  const rolePreview = useAppStore((s) => s.rolePreview);
  const setRolePreview = useAppStore((s) => s.setRolePreview);
  const queryClient = useQueryClient();
  /* premium desktop auto-collapse — the rail's pinned state is owned here
   * so the main content's padding can react to it (hover is local to the
   * Sidebar component — only the pin flip shifts the main content). */
  const sidebarPin = useSidebarPin(id ?? undefined);
  const [sidebarHovered, setSidebarHovered] = useState(false);
  const sidebarExpanded = sidebarPin.isPinned || sidebarHovered;

  useEffect(() => {
    if (!id) exitToLanding();
  }, [id, exitToLanding]);

  const query = useQuery({
    queryKey: ["instance", id],
    queryFn: () => fetchInstance(id as string),
    enabled: !!id,
    retry: 1,
  });

  /* ROUND 67 — the workspace identity as a circular browser-tab favicon:
     server-composed from the brand logo (gradient ring badge) or the
     platform mark while no logo is stored; the logo reference doubles as
     a cache-buster so uploads swap the tab icon immediately. */
  useBrandFavicon(id, query.data?.instance.site?.logoUrl || undefined);

  /* ROUND 47 — entitlement mirror (server-computed on every read); the hook
     pair lives ABOVE the early returns so hook order is render-stable. A
     locked workspace is corrected to the subscription view (the render
     guard further down never mounts a locked surface even for one frame). */
  const setDashView = useAppStore((s) => s.setDashView);
  const lockedEarly = query.data?.instance.entitlement?.state === "locked";
  useEffect(() => {
    /* ROUND 141 — the Add-ons Store joins billing as a locked-live surface. */
    if (lockedEarly && dashView !== "billing" && dashView !== "addons") setDashView("billing");
  }, [lockedEarly, dashView, setDashView]);

  if (!id) return null;

  if (query.isPending) {
    return <DashSkeleton />;
  }

  /* Expired workspace session → inline re-auth gate (no context loss). */
  if (query.isError && query.error instanceof ApiError && query.error.status === 401) {
    return (
      <div className="grid min-h-screen place-items-center bg-background p-6">
        <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden="true" />
        <InstanceLoginGate
          target={{ id, name: "", systemId: "" }}
          intent="reauth"
          onClose={() => {
            queryClient.removeQueries({ queryKey: ["instance", id] });
            exitToLanding();
          }}
          onSuccess={() => {
            query.refetch();
          }}
        />
      </div>
    );
  }

  if (query.isError || !query.data) {
    return (
      <div className="grid min-h-screen place-items-center bg-background p-6">
        <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden="true" />
        <div className="w-full max-w-md rounded-3xl border border-slate-200 bg-white p-8 text-center shadow-lift dark:border-white/10 dark:bg-ink-900">
          <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-rose-50 text-rose-500 dark:bg-rose-500/10 dark:text-rose-400">
            <CatIcon name="triangle-alert" className="h-6 w-6" />
          </div>
          <h1 className="mt-4 font-display text-lg font-extrabold text-slate-900 dark:text-white">
            {t("dashInstanceMissing")}
          </h1>
          <p className="mt-1 text-[12.5px] text-slate-500 dark:text-slate-400">
            {query.error instanceof Error ? query.error.message : t("errorText")}
          </p>
          <div className="mt-5 flex justify-center gap-2">
            <Button
              variant="outline"
              onClick={() => query.refetch()}
              className="h-10 rounded-xl px-5 text-[12.5px] font-bold"
            >
              <CatIcon name="refresh-cw" className="h-4 w-4" />
              {t("retryText")}
            </Button>
            <Button
              onClick={() => {
                queryClient.invalidateQueries({ queryKey: ["instances"] });
                setView("select");
              }}
              className="h-10 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-5 text-[12.5px] font-bold text-white shadow-lg shadow-brand-500/25 hover:brightness-110"
            >
              <CatIcon name="layers" className="h-4 w-4" />
              {t("dashGoSelect")}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const { instance, stats, members } = query.data;
  /* ROUND 143 — the shell-wide effective accent (owner directive: a custom
   * theme recolors the ENTIRE system, not just brand-* utilities). */
  const accent = resolveAccentPair(instance);

  /* ROUND 47 — authoritative render guard: a locked workspace renders the
     subscription view ONLY (server APIs refuse everything else anyway). */
  const locked = instance.entitlement?.state === "locked";
  const activeView = locked ? "billing" : dashView;

  /* ROUND 78 — strict-RBAC preview lens: when the owner previews a member
   * role, views whose permission the role lacks render the premium lock
   * screen instead (client-side lens ONLY — the owner's session keeps its
   * full server mandate; this is an experience preview, clearly labeled). */
  const previewRole: WorkspaceRole | null = rolePreview === "off" ? null : rolePreview;
  const viewPerm = VIEW_PERMISSION[activeView];
  const viewLocked =
    previewRole !== null && viewPerm !== undefined && !can(previewRole, viewPerm);

  /* ROUND 84 (84-PROFILE) — STRICT owner-profile completion gate: right
   * after a system is created (or whenever the profile is still incomplete)
   * the platform demands the owner's personal data before the workspace
   * unlocks. Rendered as a SIBLING overlay (z-[110]) over the shell — it
   * has NO dismiss affordance and the server re-validates every field.
   * NEVER mounted for LOCKED workspaces (the billing/renewal view must
   * stay reachable — renewal comes first; the gate re-opens afterwards)
   * and never on the 401 re-auth path (this point is post-auth by
   * construction). */
  const profileGateOpen = !locked && instance.ownerProfile?.completed !== true;

  /* ROUND 86 — the workspace's OWN styling scope: the owner-picked accent
       (dashTheme → the full 11-step brand ramp) and font (dashFont) inject
       on the shell root, so EVERY brand-* utility, primary button, focus
       ring and sidebar tint across all dashboard views follows the system's
       independent identity (Settings → الألوان والخطوط → النظام).
       ROUND 143 — the AccentProvider additionally drives EVERY gradient
       tile in the shell from the same owner accent: picking a theme now
       recolors the ENTIRE system (topbar, sidebar, buttons, rings, footer)
       — not just the brand-* utilities. */
  return (
    <MotionConfig reducedMotion="user">
    <AccentProvider instance={instance}>
    {/* ROUND 172 — the workspace presence heartbeat (45s, visibility-paused,
        silent): the call itself touches the workspace session, and its
        snapshot feeds the owner gold card + the topbar support indicator. */}
    <InstancePresenceProvider instanceId={id}>
    {/* ROUND 173 — the calm notification chime moved HERE from the root
        providers: it only has a purpose on authenticated surfaces (the
        dashboard's activities/notification feeds), and the public landing
        no longer downloads or mounts its listeners at all. Behavior on
        the dashboard is unchanged (same hook, same query-cache source). */}
    <NotificationSoundPlayer />
    <div
      className="brand-scope surface-font-scope min-h-screen bg-background"
      style={{
        ...dashVars(instance.site?.dashTheme),
        ...fontVars(instance.site?.dashFont),
      }}
    >
      <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden="true" />

      <div className="flex min-h-screen">
        <SkipLink />

        <Sidebar instance={instance} isPinned={sidebarPin.isPinned} onTogglePin={sidebarPin.toggle} isHovered={sidebarHovered} onHoverChange={setSidebarHovered} />

        <div className={cn("flex min-w-0 flex-1 flex-col transition-all duration-300 ease-in-out", sidebarExpanded ? "lg:ps-64" : "lg:ps-16")}>
          <Topbar instance={instance} />

          {/* ROUND 133 — نظام الورديات: the GLOBAL shift-status bar — the
              strict shift law's always-on face. Sits under the Topbar on
              EVERY view (same rhythm as the preview banner below); never
              mounts under the owner-profile completion overlay (nothing is
              operable there anyway) and renders nothing while the shared
              ["shifts", id] query loads. */}
          {!profileGateOpen ? <ShiftStatusBar instance={instance} /> : null}

          {/* ROUND 78 — preview-lens banner: the owner is browsing through a
              member role's permissions — slim, unmistakable, one-tap exit. */}
          {previewRole ? (
            <div className="mx-4 mt-4 flex flex-wrap items-center gap-2.5 rounded-2xl border border-violet-300/60 bg-linear-to-l from-violet-50/90 to-fuchsia-50/50 px-3.5 py-2.5 dark:border-violet-500/25 dark:from-violet-500/10 dark:to-fuchsia-500/5 sm:mx-6 lg:mx-8">
              <span
                className="grid h-8 w-8 shrink-0 place-items-center rounded-xl text-white shadow-md"
                style={{ backgroundImage: grad("#8b5cf6", "#d946ef") }}
                aria-hidden="true"
              >
                <CatIcon name="eye" className="h-4 w-4" />
              </span>
              <p className="min-w-0 flex-1 text-[11.5px] font-extrabold text-violet-800 dark:text-violet-200">
                {t("teamPreviewActive")} — {t(ROLE_NAME_I18N[previewRole])}
              </p>
              <Button
                type="button"
                onClick={() => setRolePreview("off")}
                className="h-8 shrink-0 rounded-lg border border-violet-300/70 bg-white/80 px-3 text-[11px] font-extrabold text-violet-700 transition hover:bg-white dark:border-violet-500/30 dark:bg-white/[0.07] dark:text-violet-300 dark:hover:bg-white/[0.12]"
              >
                <CatIcon name="x" className="h-3.5 w-3.5" />
                {t("teamPreviewExit")}
              </Button>
            </div>
          ) : null}

          <main id="main-content" className="flex-1 px-4 py-6 sm:px-6 lg:px-8">
            <div key={activeView} className="step-in">
              {viewLocked ? (
                /* ROUND 78 — the strict-RBAC lock screen: the previewed role
                   lacks this view's permission. */
                <div className="grid min-h-[52vh] place-items-center">
                  <div className="glass-card card-in max-w-md rounded-3xl p-8 text-center">
                    <span
                      className="mx-auto grid h-16 w-16 place-items-center rounded-2xl text-white shadow-xl"
                      style={{ backgroundImage: grad("#f43f5e", "#e11d48"), boxShadow: "0 12px 30px -10px #e11d4866" }}
                      aria-hidden="true"
                    >
                      <CatIcon name="lock" className="h-7 w-7" />
                    </span>
                    <h3 className="mt-5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
                      {t("teamPreviewLockedTitle")}
                    </h3>
                    <p className="mt-2 text-[12.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                      {t("teamPreviewLockedDesc", {
                        role: t(ROLE_NAME_I18N[previewRole as WorkspaceRole]),
                        perm: viewPerm ? t(PERM_LABEL_I18N[viewPerm]) : "",
                      })}
                    </p>
                    <Button
                      type="button"
                      onClick={() => setRolePreview("off")}
                      className="mt-5 h-11 rounded-xl bg-linear-to-l from-violet-600 to-fuchsia-500 px-6 text-[12.5px] font-extrabold text-white shadow-lg shadow-violet-500/25 transition hover:brightness-110 active:scale-95"
                    >
                      <CatIcon name="unlock" className="h-4 w-4" />
                      {t("teamPreviewExit")}
                    </Button>
                  </div>
                </div>
              ) : activeView === "overview" ? (
                <OverviewView instance={instance} stats={stats} members={members} />
              ) : null}
              {activeView === "analytics" ? <AnalyticsView instance={instance} stats={stats} /> : null}
              {activeView === "modules" ? <ModulesView instance={instance} /> : null}
              {activeView === "module" ? <ModuleWorkspace instance={instance} /> : null}
              {activeView === "notifications" ? <NotificationsView instance={instance} /> : null}
              {activeView === "activity" ? <ActivityView instance={instance} /> : null}
              {/* ROUND 79 — plan-based feature gates: publicWebsite is
                  Enterprise-exclusive; a plan without the capability gets the
                  premium lock screen (upgrade CTA → billing). Gates only ever
                  render while active/trial — a locked workspace is forced to
                  the billing view above, so they never block renewal. */}
              {activeView === "website" ? (
                <FeatureGate feature="publicWebsite" instance={instance}>
                  <WebsiteView instance={instance} />
                </FeatureGate>
              ) : null}
              {activeView === "store" ? (
                <FeatureGate feature="store" instance={instance}>
                  <StoreView instance={instance} />
                </FeatureGate>
              ) : null}
              {/* ROUND 114 — webhook destinations: same plan capability as the
                  E-Store itself (order events only exist with a storefront). */}
              {activeView === "webhooks" ? (
                <FeatureGate feature="store" instance={instance}>
                  <WebhooksView instance={instance} />
                </FeatureGate>
              ) : null}
              {activeView === "customers" ? <CustomersView instance={instance} /> : null}
              {activeView === "team" ? <TeamView instance={instance} members={members} /> : null}
              {activeView === "trash" ? <TrashView instance={instance} /> : null}
              {activeView === "settings" ? <SettingsView instance={instance} /> : null}
              {activeView === "billing" ? <BillingView instance={instance} members={members} /> : null}
              {/* ROUND 141 — متجر الإضافات: buy features outside the
                  subscription package. NOT trial-gated and NOT feature-gated
                  (a locked workspace may still buy add-ons — the same law as
                  billing, its natural upsell neighbor). */}
              {activeView === "addons" ? <AddonsView instance={instance} /> : null}
            </div>
          </main>

          <footer className="safe-bottom border-t border-slate-200/70 px-4 py-3 sm:px-6 lg:px-8 dark:border-white/[0.07]">
            <p className="flex flex-wrap items-center justify-between gap-2 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
              <span className="flex items-center gap-1.5">
                <span
                  className="grid h-4 w-4 place-items-center rounded text-white"
                  style={{ backgroundImage: grad(accent.c1, accent.c2) }}
                  aria-hidden="true"
                >
                  <CatIcon name="boxes" className="h-[8px] w-[8px]" />
                </span>
                Ashrilogic — {t("v3Badge")} {APP_VERSION}
              </span>
              <span className="flex items-center gap-2">
                <span className="inline-flex items-center gap-1 text-emerald-500">
                  <CatIcon name="shield-check" className="h-3 w-3" />
                  {t("dashSecuredSession")}
                </span>
                <span>{instance.org.name}</span>
              </span>
            </p>
          </footer>
        </div>
      </div>

      {/* ROUND 84 — the STRICT owner-profile gate overlays the whole shell
          (fixed z-[110]) until the owner completes their personal profile
          server-side; on success the instance query invalidates and the
          dashboard unlocks in place. */}
      {profileGateOpen ? <OwnerProfileGate instance={instance} /> : null}
    </div>
    </InstancePresenceProvider>
    </AccentProvider>
    </MotionConfig>
  );
}

export default DashboardApp;
