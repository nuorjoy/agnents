"use client";

/**
 * Ashrilogic — dashboard shared bits:
 * activity-kind visual map, view headings, small UI atoms and
 * locale-aware time helpers (date-fns with the Arabic locale).
 */
import { formatDistanceToNow } from "date-fns";
import { ar as arLocale, enUS } from "date-fns/locale";
import type { ActivityKind, Lang } from "@/lib/types";
import { intlLocale } from "@/lib/locales";
import { CatIcon } from "@/components/icon";
import { grad } from "@/lib/utils";
import { cn } from "@/lib/utils";

/* ---------------- activity kinds → icon + gradient ---------------- */

export const ACT_STYLE: Record<ActivityKind, { icon: string; c1: string; c2: string }> = {
  actCreated: { icon: "sparkles", c1: "#6d5dfb", c2: "#8b5cf6" },
  actLogin: { icon: "key-round", c1: "#10b981", c2: "#059669" },
  actBackup: { icon: "cloud-upload", c1: "#06b6d4", c2: "#0891b2" },
  actModuleEnabled: { icon: "plus", c1: "#f59e0b", c2: "#d97706" },
  actModuleDisabled: { icon: "circle-x", c1: "#f59e0b", c2: "#d97706" },
  actUserAdded: { icon: "user-plus", c1: "#8b5cf6", c2: "#7c3aed" },
  actUserRemoved: { icon: "user-minus", c1: "#8b5cf6", c2: "#7c3aed" },
  actSettingsUpdated: { icon: "sliders", c1: "#d946ef", c2: "#c026d3" },
  actDataImported: { icon: "file-import", c1: "#0ea5e9", c2: "#0284c7" },
  actReportGenerated: { icon: "file-text", c1: "#a855f7", c2: "#9333ea" },
  actReportExported: { icon: "file-output", c1: "#0ea5e9", c2: "#0369a1" },
  actInvoiceCreated: { icon: "receipt", c1: "#10b981", c2: "#047857" },
  actCouponCreated: { icon: "ticket-percent", c1: "#f59e0b", c2: "#d97706" },
  actSiteLaunched: { icon: "rocket", c1: "#6d5dfb", c2: "#ec4899" },
  actExit: { icon: "log-out", c1: "#64748b", c2: "#475569" },
  actTrashed: { icon: "trash-2", c1: "#f43f5e", c2: "#e11d48" },
  actRestored: { icon: "archive-restore", c1: "#10b981", c2: "#059669" },
  actPurged: { icon: "flame", c1: "#f43f5e", c2: "#be123c" },
  /* ROUND 141 (owner notifications) — storefront/public-site customer
   * events + the wallet's money events (the zero-delay bell kinds). */
  actOrderReceived: { icon: "shopping-bag", c1: "#10b981", c2: "#047857" },
  actReviewReceived: { icon: "star", c1: "#f59e0b", c2: "#d97706" },
  actInquiryReceived: { icon: "message-circle", c1: "#0ea5e9", c2: "#0284c7" },
  actWalletTopup: { icon: "wallet", c1: "#059669", c2: "#0f766e" },
  actWalletDebit: { icon: "arrow-up-from-line", c1: "#8b5cf6", c2: "#7c3aed" },
  /* ROUND 144 — inter-wallet transfer (the shared TRF reference joins the
   * sender's out-row and the receiver's in-row). */
  actWalletTransfer: { icon: "arrow-left-right", c1: "#0ea5e9", c2: "#0284c7" },
  /* ROUND 168 (منح المحفظة) — grant credits: the Super-Admin bulk goodwill
   * credit + the new-subscriber welcome gift (money-event rows on the
   * owner's bell). */
  actWalletGrant: { icon: "gift", c1: "#059669", c2: "#10b981" },
  actWalletWelcome: { icon: "party-popper", c1: "#f59e0b", c2: "#fbbf24" },
};

/* ---------------- gradient icon tile ---------------- */

export function IconTile({
  icon,
  c1,
  c2,
  size = "md",
  className,
}: {
  icon: string;
  c1: string;
  c2: string;
  size?: "sm" | "md" | "lg";
  className?: string;
}) {
  const dims =
    size === "lg" ? "h-14 w-14 rounded-2xl" : size === "sm" ? "h-8 w-8 rounded-lg" : "h-10 w-10 rounded-xl";
  return (
    <span
      className={cn("grid shrink-0 place-items-center text-white", dims, className)}
      style={{ backgroundImage: grad(c1, c2) }}
    >
      <CatIcon name={icon} className={size === "lg" ? "h-5 w-5" : size === "sm" ? "h-[11px] w-[11px]" : "h-[13px] w-[13px]"} />
    </span>
  );
}

/* ---------------- view heading ---------------- */

export function ViewHeading({ title, desc }: { title: string; desc: string }) {
  return (
    <div className="mb-6">
      <h1 className="font-display text-2xl font-extrabold text-slate-900 dark:text-white">{title}</h1>
      <p className="mt-1 text-[13px] text-slate-500 dark:text-slate-400">{desc}</p>
    </div>
  );
}

/* ---------------- time helpers ---------------- */

export function relativeTime(date: string | Date, lang: Lang): string {
  return formatDistanceToNow(new Date(date), { addSuffix: true, locale: lang === "ar" ? arLocale : enUS });
}

/** ROUND 80 — the bare distance WITHOUT the «منذ» suffix, for lines that
 *  already carry their own «مشترك منذ …» lead-in (avoids منذ منذ). */
export function relativeDistance(date: string | Date, lang: Lang): string {
  return formatDistanceToNow(new Date(date), { addSuffix: false, locale: lang === "ar" ? arLocale : enUS });
}

export function fullDate(date: string | Date, lang: Lang): string {
  return new Intl.DateTimeFormat(intlLocale(lang), {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(date));
}

/**
 * Locale-aware DATE-ONLY formatting (no clock time). Used for intrinsic
 * dates — birth dates, anniversary lines — where a wall-clock time is
 * meaningless noise ("١٥ يونيو ١٩٩٠" never carries "٠٤:٣٠ م").
 * Arabic-Indic digits flow natively RTL; no dir isolation needed.
 */
export function dateOnly(date: string | Date, lang: Lang): string {
  const value = typeof date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(date) ? new Date(`${date}T00:00:00`) : new Date(date);
  if (Number.isNaN(value.getTime())) return "—";
  return new Intl.DateTimeFormat(intlLocale(lang), {
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(value);
}

/* ---------------- section card ---------------- */

export function DashCard({
  title,
  icon,
  action,
  children,
  className,
}: {
  title?: string;
  icon?: string;
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section
      className={cn(
        "glass-card card-in rounded-3xl p-4 sm:p-5",
        className
      )}
      style={{ animationDelay: `calc(var(--i, 0) * 45ms)` }}
    >
      {title ? (
        <header className="mb-4 flex items-center justify-between gap-3">
          <h2 className="flex items-center gap-2.5 font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
            {icon ? <CatIcon name={icon} className="h-4 w-4 text-brand-500" /> : null}
            {title}
          </h2>
          {action}
        </header>
      ) : null}
      {children}
    </section>
  );
}

/* ---------------- RTL-safe progress bar (CSS width, not translateX) ---------------- */

export function MeterBar({ value, color }: { value: number; color: string }) {
  return (
    <div
      className="h-2 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-white/10"
      role="progressbar"
      aria-valuenow={Math.round(value)}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <div
        className="h-full rounded-full transition-all duration-700"
        style={{ width: `${Math.max(0, Math.min(100, value))}%`, background: color }}
      />
    </div>
  );
}

/* ---------------- recharts shared tooltip style ---------------- */

export const CHART_TOOLTIP_STYLE = {
  background: "var(--popover)",
  border: "1px solid var(--border)",
  borderRadius: "14px",
  color: "var(--popover-foreground)",
  fontSize: "12px",
  padding: "10px 12px",
  backdropFilter: "blur(12px)",
  WebkitBackdropFilter: "blur(12px)",
  boxShadow: "0 16px 40px -18px rgba(15,23,42,0.45)",
} as const;
