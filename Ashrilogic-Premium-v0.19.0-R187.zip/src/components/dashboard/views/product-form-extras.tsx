"use client";

/**
 * Ashrilogic — ROUND 141: the premium PRODUCT EXTRAS inside the add/edit
 * record dialog of the store's catalog module (المنتجات — whichever module
 * feeds the e-store: products / pharmacy / menu / inventory).
 *
 * The owner's directives:
 *  • «اضف زر switch on/off إذا يريد اضافة صور للمنتجات» — a precise,
 *    Premium on/off switch that reveals the photo picker INSIDE the
 *    add-product form (up to 6 photos, ≤8 MB each, per-pick canvas
 *    compression — the server re-encode stays the single authority).
 *  • «عند اضافة منتج طور متغيرات بطريقة احترافية وPremium» — the variants
 *    builder (متغيرات المنتج): up to 20 rows, each an optional price
 *    OVERRIDE (display units) + optional stock carve-out + optional SKU;
 *    unique names enforced live; the storefront + order placement charge
 *    the variant's price when one is set.
 *
 * Both sections ride the SAME write path as the media console: the photos
 * upload through /store/media (managed refs), then the gallery array +
 * the variants array travel with the record create/patch.
 */
import { useRef } from "react";
import { toast } from "sonner";
import { useT, type I18nKey } from "@/lib/i18n";
import type { ProductVariantDTO } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { cn, grad } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";

/** the owner's directive — the hard caps this picker enforces client-side */
export const MAX_GALLERY = 6;
const MAX_IMAGE_INPUT = 8 * 1024 * 1024;
const PHOTO_MIME_RE = /^image\/(png|jpe?g|webp|gif)$/;

/** accepted upload types (the server re-encodes to clean WebP) */
export const PRODUCT_VARIANTS_MAX = 20;

/* ------------------------------------------------------------------ */
/* the photo picker (directive B — the on/off switch + the picker)      */
/* ------------------------------------------------------------------ */

/**
 * Read a picked photo into a compact 4:3 landscape JPEG data-URL (cover
 * crop, 1280×960 target with a quality ladder) — the SAME pipeline the
 * R140 media console uses; the SERVER re-encode stays the authority.
 */
async function imageFromFile(file: File): Promise<string> {
  if (!PHOTO_MIME_RE.test(file.type)) throw new Error("bad-type");
  if (file.size > MAX_IMAGE_INPUT) throw new Error("too-large");

  const objectUrl = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error("corrupt"));
      image.src = objectUrl;
    });
    const srcW = img.naturalWidth;
    const srcH = img.naturalHeight;
    if (!srcW || !srcH) throw new Error("corrupt");

    const targetW = 1280;
    const targetH = 960;
    const scale = Math.max(targetW / srcW, targetH / srcH);
    const drawW = Math.round(srcW * scale);
    const drawH = Math.round(srcH * scale);
    const offsetX = Math.round((targetW - drawW) / 2);
    const offsetY = Math.round((targetH - drawH) / 2);

    for (const quality of [0.88, 0.8, 0.7, 0.58]) {
      const canvas = document.createElement("canvas");
      canvas.width = targetW;
      canvas.height = targetH;
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("corrupt");
      ctx.imageSmoothingQuality = "high";
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, targetW, targetH);
      ctx.drawImage(img, offsetX, offsetY, drawW, drawH);
      const dataUrl = canvas.toDataURL("image/jpeg", quality);
      if (dataUrl.length * 0.75 <= 1_300_000) return dataUrl;
    }
    return await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () =>
        typeof reader.result === "string" ? resolve(reader.result) : reject(new Error("corrupt"));
      reader.onerror = () => reject(new Error("corrupt"));
      reader.readAsDataURL(file);
    });
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}

export interface ProductMediaPickerValue {
  /** the switch state — when OFF the product keeps whatever the console set */
  enabled: boolean;
  /** the CURRENT full ordered gallery: managed refs (kept) + pending
   *  data-URLs (about to upload, rendered as previews) */
  items: { ref: string; pending: boolean }[];
}

export function ProductMediaPickerSection({
  value,
  onChange,
  c1,
  c2,
}: {
  value: ProductMediaPickerValue;
  onChange: (next: ProductMediaPickerValue) => void;
  c1: string;
  c2: string;
}) {
  const { t } = useT();
  const fileRef = useRef<HTMLInputElement | null>(null);

  const kept = value.items.filter((i) => !i.pending).length;

  const pickFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const room = MAX_GALLERY - value.items.length;
    if (room <= 0) {
      toast.error(t("pfeMediaCap", { n: String(MAX_GALLERY) }));
      return;
    }
    const chosen = Array.from(files).slice(0, room);
    const skipped = Array.from(files).length - chosen.length;
    const next = [...value.items];
    let failed = 0;
    for (const file of chosen) {
      try {
        const dataUrl = await imageFromFile(file);
        next.push({ ref: dataUrl, pending: true });
      } catch (error) {
        failed += 1;
        const reason = error instanceof Error ? error.message : "corrupt";
        toast.error(
          reason === "too-large"
            ? t("pfePhotoTooLarge", { mb: "8" })
            : reason === "bad-type"
              ? t("pfePhotoBadType")
              : t("errorText")
        );
      }
    }
    onChange({ ...value, items: next });
    if (skipped > 0) {
      toast(t("pfeMediaCap", { n: String(MAX_GALLERY) }));
    }
    if (failed === 0 && chosen.length > 0) {
      toast.success(t("pfePhotoAdded", { n: String(chosen.length) }));
    }
  };

  const removeAt = (index: number) => {
    onChange({ ...value, items: value.items.filter((_i, ix) => ix !== index) });
  };

  const makeCover = (index: number) => {
    if (index === 0) return;
    const next = [...value.items];
    const [item] = next.splice(index, 1);
    next.unshift(item);
    onChange({ ...value, items: next });
  };

  return (
    <section className="rounded-2xl border border-slate-200/80 bg-slate-50/50 p-3.5 dark:border-white/10 dark:bg-white/[0.02]">
      {/* the section header — THE premium on/off switch (directive B) */}
      <div className="flex items-center gap-3">
        <span
          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
          style={{ backgroundImage: grad(c1, c2) }}
          aria-hidden="true"
        >
          <CatIcon name="image" className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
            {t("pfeMediaTitle")}
          </p>
          <p className="mt-0.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("pfeMediaDesc")}
          </p>
        </div>
        <Switch
          checked={value.enabled}
          onCheckedChange={(on) => {
            if (on && value.items.length === 0) {
              onChange({ enabled: true, items: value.items });
            } else if (!on) {
              /* flipping OFF keeps the picks in state (switching back on
               * restores them); a save with OFF simply does not touch media. */
              onChange({ enabled: false, items: value.items });
            } else {
              onChange({ ...value, enabled: true });
            }
          }}
          aria-label={t("pfeMediaTitle")}
        />
      </div>

      {/* the picker — revealed by the switch */}
      {value.enabled ? (
        <div className="mt-3 space-y-2.5 border-t border-dashed border-slate-200/80 pt-3 dark:border-white/10">
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
            {value.items.map((item, index) => (
              <figure
                key={`${item.ref.slice(0, 24)}-${index}`}
                className="group relative aspect-[4/3] overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-white/10"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={item.ref}
                  alt={index === 0 ? t("pfeCoverAlt") : ""}
                  className="h-full w-full object-cover"
                />
                {index === 0 ? (
                  <figcaption className="absolute inset-x-0 bottom-0 bg-linear-to-t from-slate-950/80 to-transparent px-1.5 pb-1 pt-4 text-[8.5px] font-extrabold text-white">
                    {t("pfeCoverBadge")}
                  </figcaption>
                ) : null}
                {/* hover actions: make-cover + remove */}
                <div className="absolute inset-0 flex items-center justify-center gap-1.5 bg-slate-950/45 opacity-0 transition group-hover:opacity-100 focus-within:opacity-100">
                  {index > 0 ? (
                    <button
                      type="button"
                      aria-label={t("pfeMakeCoverAria")}
                      title={t("pfeMakeCoverAria")}
                      onClick={() => makeCover(index)}
                      className="grid h-7 w-7 place-items-center rounded-lg bg-white/20 text-white backdrop-blur-sm transition hover:bg-white/35 active:scale-90"
                    >
                      <CatIcon name="badge-check" className="h-3.5 w-3.5" />
                    </button>
                  ) : null}
                  <button
                    type="button"
                    aria-label={t("pfeRemovePhotoAria")}
                    title={t("pfeRemovePhotoAria")}
                    onClick={() => removeAt(index)}
                    className="grid h-7 w-7 place-items-center rounded-lg bg-rose-500/85 text-white backdrop-blur-sm transition hover:bg-rose-500 active:scale-90"
                  >
                    <CatIcon name="trash-2" className="h-3.5 w-3.5" />
                  </button>
                </div>
              </figure>
            ))}

            {/* the add tile */}
            {value.items.length < MAX_GALLERY ? (
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                className="grid aspect-[4/3] place-items-center rounded-xl border-2 border-dashed border-slate-300 text-slate-400 transition hover:border-violet-400 hover:text-violet-500 active:scale-95 dark:border-white/15 dark:text-slate-500 dark:hover:border-violet-500/50 dark:hover:text-violet-300"
              >
                <span className="flex flex-col items-center gap-1">
                  <CatIcon name="image-plus" className="h-5 w-5" />
                  <span dir="ltr" className="text-[9px] font-extrabold tabular-nums">
                    {value.items.length}/{MAX_GALLERY}
                  </span>
                </span>
              </button>
            ) : null}
          </div>

          <p className="flex items-center gap-1.5 text-[10px] font-semibold text-slate-400 dark:text-slate-500">
            <CatIcon name="info" className="h-3 w-3 shrink-0" />
            {t("pfeMediaHint", { kept: String(kept), n: String(value.items.length) })}
          </p>

          <input
            ref={fileRef}
            type="file"
            accept="image/png,image/jpeg,image/webp,image/gif"
            multiple
            hidden
            onChange={(e) => {
              void pickFiles(e.target.files);
              e.target.value = "";
            }}
          />
        </div>
      ) : (
        <p className="mt-2.5 flex items-center gap-1.5 border-t border-dashed border-slate-200/80 pt-2.5 text-[10px] font-semibold text-slate-400 dark:border-white/10 dark:text-slate-500">
          <CatIcon name="image-off" className="h-3 w-3 shrink-0" />
          {value.items.length > 0
            ? t("pfeMediaOffWithPicks", { n: String(value.items.length) })
            : t("pfeMediaOff")}
        </p>
      )}
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* the variants builder (directive I — متغيرات المنتج)                 */
/* ------------------------------------------------------------------ */

export interface VariantRow {
  id: string;
  name: string;
  price: string;
  stock: string;
  sku: string;
}

export interface VariantsBuilderValue {
  enabled: boolean;
  rows: VariantRow[];
}

let variantRowSeq = 0;
function newVariantRow(): VariantRow {
  variantRowSeq += 1;
  return { id: `vr-${Date.now().toString(36)}-${variantRowSeq}`, name: "", price: "", stock: "", sku: "" };
}

/** Convert DTO rows → builder rows (the initial value for an edit). */
export function variantRowsFromDTO(variants: ProductVariantDTO[]): VariantRow[] {
  return variants.map((v, i) => ({
    id: v.id || `vv-${i}`,
    name: v.name,
    price: v.price != null ? String(v.price) : "",
    stock: v.stock != null ? String(v.stock) : "",
    sku: v.sku ?? "",
  }));
}

/** Convert builder rows → the API wire shape (invalid rows are excluded;
 *  duplicate names null the whole list — the dialog blocks the save). */
export function variantRowsToWire(
  rows: VariantRow[]
): { variants: { id?: string; name: string; price?: number; stock?: number; sku?: string }[]; error?: string } {
  const seen = new Set<string>();
  const out: { id?: string; name: string; price?: number; stock?: number; sku?: string }[] = [];
  for (const row of rows) {
    const name = row.name.trim().replace(/\s+/g, " ");
    if (name.length === 0) continue;
    const key = name.toLocaleLowerCase("ar");
    if (seen.has(key)) {
      return { variants: [], error: t0("pfeVariantDup", { name }) };
    }
    seen.add(key);
    const price = row.price.trim() === "" ? undefined : Number(row.price);
    if (price !== undefined && (!Number.isFinite(price) || price < 0)) {
      return { variants: [], error: t0("pfeVariantBadPrice", { name }) };
    }
    const stock = row.stock.trim() === "" ? undefined : Number(row.stock);
    if (stock !== undefined && (!Number.isInteger(stock) || stock < 0)) {
      return { variants: [], error: t0("pfeVariantBadStock", { name }) };
    }
    const sku = row.sku.trim() || undefined;
    out.push({
      id: row.id.startsWith("vr-") ? undefined : row.id,
      name,
      ...(price !== undefined ? { price } : {}),
      ...(stock !== undefined ? { stock } : {}),
      ...(sku !== undefined ? { sku } : {}),
    });
  }
  if (out.length > PRODUCT_VARIANTS_MAX) {
    return { variants: [], error: t0("pfeVariantCap", { n: String(PRODUCT_VARIANTS_MAX) }) };
  }
  return { variants: out };
}

/* a tiny module-level t() accessor for the pure converters above (they run
 * outside the component tree — the dialog passes the real translate for
 * rendering, these only need the error strings). */
let t0: (key: I18nKey, vars?: Record<string, string | number>) => string = (key) => String(key);
export function registerVariantTranslator(
  fn: (key: I18nKey, vars?: Record<string, string | number>) => string
): void {
  t0 = fn as typeof t0;
}

export function VariantsBuilderSection({
  value,
  onChange,
  currency,
  c1,
  c2,
}: {
  value: VariantsBuilderValue;
  onChange: (next: VariantsBuilderValue) => void;
  currency: string;
  c1: string;
  c2: string;
}) {
  const { t } = useT();
  registerVariantTranslator(t as unknown as typeof t0);

  const addRow = () => {
    if (value.rows.length >= PRODUCT_VARIANTS_MAX) {
      toast.error(t("pfeVariantCap", { n: String(PRODUCT_VARIANTS_MAX) }));
      return;
    }
    onChange({ ...value, rows: [...value.rows, newVariantRow()] });
  };

  const patchRow = (id: string, patch: Partial<VariantRow>) => {
    onChange({ ...value, rows: value.rows.map((r) => (r.id === id ? { ...r, ...patch } : r)) });
  };

  const removeRow = (id: string) => {
    onChange({ ...value, rows: value.rows.filter((r) => r.id !== id) });
  };

  /* live duplicate-name lint (visual hint on the second occurrence) */
  const nameCounts = new Map<string, number>();
  for (const row of value.rows) {
    const key = row.name.trim().toLocaleLowerCase("ar");
    if (key) nameCounts.set(key, (nameCounts.get(key) ?? 0) + 1);
  }
  const filled = value.rows.filter((r) => r.name.trim() !== "").length;

  return (
    <section className="rounded-2xl border border-slate-200/80 bg-slate-50/50 p-3.5 dark:border-white/10 dark:bg-white/[0.02]">
      {/* the section header + the on/off switch */}
      <div className="flex items-center gap-3">
        <span
          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
          style={{ backgroundImage: grad(c1, c2) }}
          aria-hidden="true"
        >
          <CatIcon name="layers" className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
            {t("pfeVariantsTitle")}
          </p>
          <p className="mt-0.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("pfeVariantsDesc")}
          </p>
        </div>
        <Switch
          checked={value.enabled}
          onCheckedChange={(on) => {
            if (on && value.rows.length === 0) {
              onChange({ enabled: true, rows: [newVariantRow()] });
            } else {
              onChange({ ...value, enabled: on });
            }
          }}
          aria-label={t("pfeVariantsTitle")}
        />
      </div>

      {/* the builder — revealed by the switch */}
      {value.enabled ? (
        <div className="mt-3 space-y-2 border-t border-dashed border-slate-200/80 pt-3 dark:border-white/10">
          {value.rows.length === 0 ? (
            <button
              type="button"
              onClick={addRow}
              className="grid w-full place-items-center gap-1.5 rounded-xl border-2 border-dashed border-slate-300 py-4 text-slate-400 transition hover:border-violet-400 hover:text-violet-500 active:scale-[0.99] dark:border-white/15 dark:text-slate-500 dark:hover:border-violet-500/50 dark:hover:text-violet-300"
            >
              <CatIcon name="plus" className="h-4 w-4" />
              <span className="text-[11px] font-extrabold">{t("pfeVariantAddFirst")}</span>
            </button>
          ) : (
            <>
              <div className="hidden gap-2 px-1 sm:grid sm:grid-cols-[minmax(0,1.5fr)_minmax(0,0.9fr)_minmax(0,0.7fr)_minmax(0,1fr)_auto]">
                <p className="text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400">{t("pfeVariantName")}</p>
                <p className="text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400">
                  {t("pfeVariantPrice")} <span dir="ltr" className="font-bold">({currency})</span>
                </p>
                <p className="text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400">{t("pfeVariantStock")}</p>
                <p className="text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400">{t("pfeVariantSku")}</p>
                <span className="w-8" aria-hidden="true" />
              </div>
              <div className="max-h-64 space-y-1.5 overflow-y-auto pe-0.5 nice-scroll">
                {value.rows.map((row, index) => {
                  const dup =
                    row.name.trim() !== "" &&
                    (nameCounts.get(row.name.trim().toLocaleLowerCase("ar")) ?? 0) > 1;
                  return (
                    <div
                      key={row.id}
                      className="grid gap-1.5 rounded-xl border border-slate-200/80 bg-white/80 p-2 dark:border-white/10 dark:bg-white/[0.04] sm:grid-cols-[minmax(0,1.5fr)_minmax(0,0.9fr)_minmax(0,0.7fr)_minmax(0,1fr)_auto] sm:items-center sm:gap-2 sm:border-transparent sm:bg-transparent sm:p-0"
                    >
                      <div className="relative">
                        <span className="pointer-events-none absolute start-2 top-1/2 -translate-y-1/2 font-mono text-[9.5px] font-extrabold text-slate-300 dark:text-slate-600" dir="ltr">
                          {String(index + 1).padStart(2, "0")}
                        </span>
                        <Input
                          value={row.name}
                          onChange={(e) => patchRow(row.id, { name: e.target.value })}
                          placeholder={t("pfeVariantNamePh")}
                          maxLength={80}
                          aria-invalid={dup || undefined}
                          className={cn(
                            "h-9 rounded-xl ps-7 text-[12px] font-semibold",
                            dup && "border-rose-400 focus-visible:ring-rose-400/30"
                          )}
                        />
                      </div>
                      <Input
                        value={row.price}
                        onChange={(e) => patchRow(row.id, { price: e.target.value })}
                        placeholder={t("pfeVariantPricePh")}
                        type="number"
                        min={0}
                        step="0.01"
                        dir="ltr"
                        className="h-9 rounded-xl text-end text-[12px] font-semibold tabular-nums"
                      />
                      <Input
                        value={row.stock}
                        onChange={(e) => patchRow(row.id, { stock: e.target.value })}
                        placeholder={t("pfeVariantStockPh")}
                        type="number"
                        min={0}
                        step="1"
                        dir="ltr"
                        className="h-9 rounded-xl text-end text-[12px] font-semibold tabular-nums"
                      />
                      <Input
                        value={row.sku}
                        onChange={(e) => patchRow(row.id, { sku: e.target.value })}
                        placeholder={t("pfeVariantSkuPh")}
                        maxLength={40}
                        dir="ltr"
                        className="h-9 rounded-xl text-start font-mono text-[11px] font-semibold"
                      />
                      <button
                        type="button"
                        aria-label={t("pfeRemoveVariantAria")}
                        title={t("pfeRemoveVariantAria")}
                        onClick={() => removeRow(row.id)}
                        className="grid h-9 w-8 place-items-center rounded-lg text-slate-400 transition hover:bg-rose-500/10 hover:text-rose-500 active:scale-90 dark:text-slate-500"
                      >
                        <CatIcon name="trash-2" className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  );
                })}
              </div>
              <div className="flex flex-wrap items-center justify-between gap-2 pt-0.5">
                <p className="flex items-center gap-1.5 text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                  <CatIcon name="info" className="h-3 w-3 shrink-0" />
                  {t("pfeVariantsHint")}
                </p>
                <Button
                  type="button"
                  variant="outline"
                  onClick={addRow}
                  className="h-8 gap-1.5 rounded-lg px-3 text-[10.5px] font-extrabold"
                >
                  <CatIcon name="plus" className="h-3 w-3" />
                  {t("pfeVariantAddBtn")}
                  <span dir="ltr" className="tabular-nums opacity-70">
                    {filled}/{PRODUCT_VARIANTS_MAX}
                  </span>
                </Button>
              </div>
            </>
          )}
        </div>
      ) : (
        <p className="mt-2.5 flex items-center gap-1.5 border-t border-dashed border-slate-200/80 pt-2.5 text-[10px] font-semibold text-slate-400 dark:border-white/10 dark:text-slate-500">
          <CatIcon name="layers" className="h-3 w-3 shrink-0" />
          {filled > 0
            ? t("pfeVariantsOffWithRows", { n: String(filled) })
            : t("pfeVariantsOff")}
        </p>
      )}
    </section>
  );
}
