"use client";

/**
 * Ashrilogic — dashboard WEBHOOKS view (ROUND 114).
 *
 * The owner-facing management console for the ROUND 113 order-event webhook
 * system (تكاملات الطلبات). The API surface (GET/POST/PATCH/DELETE
 * /api/instances/[id]/webhooks) existed since ROUND 113 — this panel makes
 * it operable from the workspace:
 *
 *  - a KPI strip over the endpoint fleet (active destinations, delivered
 *    events, covered event types, latest delivery),
 *  - the merchant integration guide (signature scheme, headers, the
 *    at-least-once + backoff contract receivers must expect),
 *  - the endpoint console: per-destination cards with event badges,
 *    delivery stats, live/paused state, secret hint, pause/resume,
 *    secret rotation and soft delete,
 *  - create dialog (url + events + label) whose success path reveals the
 *    signing secret EXACTLY ONCE with a copy affordance (Stripe
 *    convention — the server never returns it again),
 *  - rotate flow with the same one-time reveal.
 *
 * ZERO existing visual surfaces were touched: this is a purely additive
 * view registered in the sidebar's management section.
 *
 * ROUND 136 — the KPI strip upgraded to the unified premium StatCard.
 * ROUND 139 — the strip now renders THE golden inventory-page card law
 * (size="golden" inside the exact inventory grid grid-cols-2 → md:grid-cols-3
 * → xl:grid-cols-5), expanded 4 → 5 KPIs: the PAUSED cohort is promoted to
 * its own headline card (sub-line: soft-deleted count) so the golden
 * 5-column grid fills exactly — the R136-A inventory pattern.
 */

import { useMemo, useState } from "react";
import { useInfiniteQuery, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import type { InstanceDTO } from "@/lib/types";
import { useT, type I18nKey } from "@/lib/i18n";
import {
  createInstanceWebhook,
  deleteInstanceWebhook,
  fetchInstanceWebhooks,
  fetchWebhookDeliveries,
  redeliverWebhookDelivery as redeliverWebhookDeliveryApi,
  updateInstanceWebhook,
  type WebhookDeliveryDTO,
  type WebhookEndpointDTO,
} from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, grad } from "@/lib/utils";
import { StatCard } from "@/components/shared/stat-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { DashCard, ViewHeading, fullDate, relativeTime } from "@/components/dashboard/dash-shared";
import { nf } from "./store/shared";

/* ---------------------------------------------------- constants ----- */

/** The ROUND 113 event catalog — presentation metadata per event type.
 *  The identifiers themselves (order.placed …) are the protocol contract
 *  and render RAW in font-mono — like coupon codes, they are code, not
 *  prose; only the hint line below each checkbox is localized. */
const EVENT_META: Record<string, { icon: string; c1: string; c2: string; hintKey: I18nKey }> = {
  "order.placed": { icon: "package-plus", c1: "#6d5dfb", c2: "#0ea5e9", hintKey: "whEventHintPlaced" },
  "order.status_changed": { icon: "refresh-cw", c1: "#f59e0b", c2: "#d97706", hintKey: "whEventHintStatus" },
  "order.cancelled": { icon: "circle-x", c1: "#f43f5e", c2: "#e11d48", hintKey: "whEventHintCancelled" },
};

const ALL_EVENTS = Object.keys(EVENT_META);

/** destination-state chip metadata */
const ENDPOINT_STATE_META = {
  live: {
    icon: "circle-check",
    chip: "border-emerald-300/60 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300",
  },
  paused: {
    icon: "power",
    chip: "border-slate-300/60 bg-slate-500/10 text-slate-500 dark:border-white/10 dark:text-slate-400",
  },
  deleted: {
    icon: "trash-2",
    chip: "border-rose-300/60 bg-rose-500/10 text-rose-600 dark:border-rose-500/40 dark:text-rose-300",
  },
} as const;

/** One event-type badge with its per-event gradient icon. */
function EventBadge({ event }: { event: string }) {
  const meta = EVENT_META[event];
  if (!meta) return null;
  return (
    <span
      className="inline-flex max-w-full items-center gap-1.5 rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-[10px] font-extrabold text-slate-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
      dir="ltr"
    >
      <span
        className="grid h-3.5 w-3.5 shrink-0 place-items-center rounded-full text-white"
        style={{ backgroundImage: grad(meta.c1, meta.c2) }}
        aria-hidden="true"
      >
        <CatIcon name={meta.icon} className="h-[7px] w-[7px]" />
      </span>
      <span className="truncate font-mono">{event}</span>
    </span>
  );
}

/** One destination row — url, state, events, delivery stats, actions. */
function EndpointRow({
  endpoint,
  busy,
  onToggle,
  onRotate,
  onDelete,
  onHistory,
}: {
  endpoint: WebhookEndpointDTO;
  busy: boolean;
  onToggle: (e: WebhookEndpointDTO) => void;
  onRotate: (e: WebhookEndpointDTO) => void;
  onDelete: (e: WebhookEndpointDTO) => void;
  /** ROUND 115 — open the delivery-history drill-down */
  onHistory: (e: WebhookEndpointDTO) => void;
}) {
  const { t, lang } = useT();
  const state = endpoint.deleted ? "deleted" : endpoint.active ? "live" : "paused";
  const meta = ENDPOINT_STATE_META[state];

  return (
    <li
      className={cn(
        /* ROUND 136 — light polish: one consistent hover lift across the
           endpoint rows (state borders deepen on hover instead of being
           washed out by a generic slate hover). */
        "rounded-2xl border border-slate-200 bg-white p-3.5 transition hover:border-slate-300 hover:shadow-sm dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-white/25",
        state === "live" &&
          "border-emerald-300/50 hover:border-emerald-400/60 dark:border-emerald-500/30 dark:hover:border-emerald-500/50",
        state === "deleted" && "opacity-70"
      )}
    >
      {/* url + state + actions */}
      <div className="flex flex-wrap items-center gap-2.5">
        <span
          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
          style={{ backgroundImage: grad("#0ea5e9", "#6d5dfb") }}
          aria-hidden="true"
        >
          <CatIcon name="webhook" className="h-4 w-4" />
        </span>
        <code
          dir="ltr"
          title={endpoint.url}
          className="min-w-0 max-w-full flex-1 truncate rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-[11.5px] font-bold text-sky-700 dark:border-white/10 dark:bg-white/[0.05] dark:text-sky-300"
        >
          {endpoint.url}
        </code>
        <span
          className={cn(
            "inline-flex shrink-0 items-center gap-1 rounded-full border px-2.5 py-1 text-[10px] font-extrabold",
            meta.chip
          )}
        >
          <CatIcon name={meta.icon} className="h-3 w-3" />
          {state === "live" ? t("whStateLive") : state === "paused" ? t("whStatePaused") : t("whStateDeleted")}
        </span>

        <span className="flex shrink-0 items-center gap-1.5">
          {/* ROUND 115 — delivery history drill-down (read-only: also
              available for soft-deleted endpoints — history is audit
              material, exactly like the API contract) */}
          <button
            type="button"
            onClick={() => onHistory(endpoint)}
            title={t("whHistoryBtn")}
            aria-label={t("whHistoryBtn")}
            className="grid h-9 w-9 place-items-center rounded-xl border border-slate-200 text-slate-400 transition hover:border-sky-300 hover:text-sky-600 active:scale-95 dark:border-white/10 dark:hover:border-sky-500/40 dark:hover:text-sky-300"
          >
            <CatIcon name="clock-rotate-left" className="h-4 w-4" />
          </button>
          {!endpoint.deleted ? (
            <>
            {/* pause / resume */}
            <button
              type="button"
              disabled={busy}
              onClick={() => onToggle(endpoint)}
              title={endpoint.active ? t("whPauseBtn") : t("whResumeBtn")}
              aria-label={endpoint.active ? t("whPauseBtn") : t("whResumeBtn")}
              className={cn(
                "grid h-9 w-9 place-items-center rounded-xl border transition active:scale-95 disabled:opacity-50",
                endpoint.active
                  ? "border-emerald-300/60 bg-emerald-500/10 text-emerald-600 hover:bg-emerald-500/20 dark:border-emerald-500/40 dark:text-emerald-300"
                  : "border-slate-200 bg-slate-50 text-slate-400 hover:text-emerald-600 dark:border-white/10 dark:bg-white/[0.04] dark:hover:text-emerald-300"
              )}
            >
              <CatIcon name="power" className="h-4 w-4" />
            </button>
            {/* rotate secret */}
            <button
              type="button"
              disabled={busy}
              onClick={() => onRotate(endpoint)}
              title={t("whRotateBtn")}
              aria-label={t("whRotateBtn")}
              className="grid h-9 w-9 place-items-center rounded-xl border border-slate-200 text-slate-400 transition hover:border-amber-300 hover:text-amber-500 active:scale-95 disabled:opacity-50 dark:border-white/10 dark:hover:border-amber-500/40 dark:hover:text-amber-300"
            >
              <CatIcon name="key-round" className="h-4 w-4" />
            </button>
            {/* soft delete */}
            <button
              type="button"
              disabled={busy}
              onClick={() => onDelete(endpoint)}
              title={t("whDeleteBtn")}
              aria-label={t("whDeleteBtn")}
              className="grid h-9 w-9 place-items-center rounded-xl border border-slate-200 text-slate-400 transition hover:border-rose-300 hover:text-rose-500 active:scale-95 disabled:opacity-50 dark:border-white/10 dark:hover:border-rose-500/40 dark:hover:text-rose-300"
            >
              <CatIcon name="trash-2" className="h-4 w-4" />
            </button>
            </>
          ) : null}
        </span>
      </div>

      {/* description + events + stats rail */}
      <div className="mt-2.5 space-y-2">
        {endpoint.description ? (
          <p className="text-[11.5px] font-bold text-slate-500 dark:text-slate-400">
            {endpoint.description}
          </p>
        ) : null}
        <div className="flex flex-wrap items-center gap-1.5">
          {endpoint.events.map((ev) => (
            <EventBadge key={ev} event={ev} />
          ))}
        </div>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[11px] font-bold text-slate-500 dark:text-slate-400">
          <span className="inline-flex items-center gap-1.5">
            <CatIcon name="send" className="h-3.5 w-3.5 text-brand-500" />
            {t("whStatDeliveries", { n: nf(lang, endpoint.deliveries ?? 0) })}
          </span>
          <span className="inline-flex items-center gap-1.5">
            <CatIcon name="clock-rotate-left" className="h-3.5 w-3.5 text-slate-400" />
            {endpoint.lastDeliveryAt
              ? t("whStatLast", { when: relativeTime(endpoint.lastDeliveryAt, lang) })
              : t("whStatNever")}
          </span>
          <span className="inline-flex items-center gap-1.5" dir="ltr">
            <CatIcon name="key-round" className="h-3.5 w-3.5 text-slate-400" />
            <span className="font-mono">••••{endpoint.secretHint}</span>
          </span>
        </div>
      </div>
    </li>
  );
}

/** The one-time secret reveal dialog (create + rotate share it): monospace
 *  secret on a copyable slab with an explicit «shown once» warning. */
function SecretRevealDialog({
  secret,
  onClose,
}: {
  secret: string | null;
  onClose: () => void;
}) {
  const { t, lang } = useT();
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(secret ?? "");
      setCopied(true);
      toast.success(t("whSecretCopied"));
      setTimeout(() => setCopied(false), 1800);
    } catch {
      toast.error(t("whCopyFailed"));
    }
  };

  return (
    <Dialog open={secret !== null} onOpenChange={(open) => (!open ? onClose() : undefined)}>
      <DialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
            <span
              className="grid h-10 w-10 place-items-center rounded-2xl text-white shadow-lg"
              style={{ backgroundImage: grad("#10b981", "#059669") }}
            >
              <CatIcon name="key-round" className="h-5 w-5" />
            </span>
            {t("whSecretTitle")}
          </DialogTitle>
          <DialogDescription className="pt-1 text-[12.5px] leading-relaxed">
            {t("whSecretDesc")}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div className="rounded-2xl border border-amber-300/60 bg-amber-500/10 px-3.5 py-2.5 dark:border-amber-500/40 dark:bg-amber-500/10">
            <p className="flex items-start gap-2 text-[11.5px] font-extrabold leading-relaxed text-amber-700 dark:text-amber-300">
              <CatIcon name="triangle-alert" className="mt-0.5 h-4 w-4 shrink-0" />
              {t("whSecretWarning")}
            </p>
          </div>
          <button
            type="button"
            onClick={() => void copy()}
            title={t("whSecretCopy")}
            dir="ltr"
            className="group flex w-full items-center gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-3.5 py-3 text-start transition hover:border-brand-300 hover:bg-white dark:border-white/10 dark:bg-white/[0.05] dark:hover:border-brand-500/40 dark:hover:bg-white/[0.08]"
          >
            <code className="min-w-0 flex-1 truncate font-mono text-[13px] font-black tracking-wide text-slate-800 dark:text-slate-100">
              {secret}
            </code>
            <span
              className={cn(
                "grid h-9 w-9 shrink-0 place-items-center rounded-xl border transition active:scale-95",
                copied
                  ? "border-emerald-300/60 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
                  : "border-slate-200 bg-white text-slate-400 group-hover:text-brand-500 dark:border-white/10 dark:bg-white/[0.06]"
              )}
            >
              <CatIcon name={copied ? "check" : "copy"} className="h-4 w-4" />
            </span>
          </button>
        </div>

        <DialogFooter className="gap-2">
          <Button
            type="button"
            onClick={onClose}
            className="h-10 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-[0.98]"
          >
            {t("whSecretDone")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ------------------------------------------- ROUND 115: history ----- */

/** delivery-state chip metadata */
const DELIVERY_STATE_META = {
  succeeded: {
    icon: "circle-check",
    chip: "border-emerald-300/60 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300",
  },
  pending: {
    icon: "hourglass",
    chip: "border-sky-300/60 bg-sky-500/10 text-sky-600 dark:border-sky-500/40 dark:text-sky-300",
  },
  /* ROUND 137 — the atomic-claim in-flight state: a dispatcher holds the
   * lease RIGHT NOW (same chip language, its own label). API-contract
   * accommodation for the new backend state — no visual redesign. */
  processing: {
    icon: "send",
    chip: "border-violet-300/60 bg-violet-500/10 text-violet-600 dark:border-violet-500/40 dark:text-violet-300",
  },
  failed: {
    icon: "triangle-alert",
    chip: "border-amber-300/60 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300",
  },
  exhausted: {
    icon: "circle-x",
    chip: "border-rose-300/60 bg-rose-500/10 text-rose-600 dark:border-rose-500/40 dark:text-rose-300",
  },
} as const;

const DELIVERY_STATE_KEY: Record<string, I18nKey> = {
  succeeded: "whDelivSucceeded",
  pending: "whDelivPending",
  processing: "whDelivProcessing",
  failed: "whDelivFailed",
  exhausted: "whDelivExhausted",
};

/** One delivery row in the history dialog — status chip, event badge,
 *  attempts, response status, error class, timeline, expandable payload.
 *  ROUND 116: failed/exhausted rows on a live endpoint carry a manual
 *  REDELIVER action (owner recovery), and manually redelivered rows show
 *  a lineage badge tying them to the original attempt. */
function DeliveryRow({
  delivery,
  canRedeliver,
  onRedeliver,
}: {
  delivery: WebhookDeliveryDTO;
  /** failed/exhausted row on an ACTIVE, non-deleted endpoint */
  canRedeliver: boolean;
  onRedeliver: (delivery: WebhookDeliveryDTO) => void;
}) {
  const { t, lang } = useT();
  const [payloadOpen, setPayloadOpen] = useState(false);
  const meta =
    DELIVERY_STATE_META[delivery.status as keyof typeof DELIVERY_STATE_META] ??
    DELIVERY_STATE_META.pending;
  const eventMeta = EVENT_META[delivery.event];

  return (
    <li className="rounded-2xl border border-slate-200 bg-white p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
      {/* status + event + lineage + timeline */}
      <div className="flex flex-wrap items-center gap-2.5">
        <span
          className={cn(
            "inline-flex shrink-0 items-center gap-1 rounded-full border px-2.5 py-1 text-[10px] font-extrabold",
            meta.chip
          )}
        >
          <CatIcon name={meta.icon} className="h-3 w-3" />
          {t(DELIVERY_STATE_KEY[delivery.status] ?? "whDelivPending")}
        </span>
        {eventMeta ? (
          <span
            className="inline-flex min-w-0 items-center gap-1.5 rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-[10px] font-extrabold text-slate-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
            dir="ltr"
          >
            <span
              className="grid h-3.5 w-3.5 shrink-0 place-items-center rounded-full text-white"
              style={{ backgroundImage: grad(eventMeta.c1, eventMeta.c2) }}
              aria-hidden="true"
            >
              <CatIcon name={eventMeta.icon} className="h-[7px] w-[7px]" />
            </span>
            <span className="truncate font-mono">{delivery.event}</span>
          </span>
        ) : null}
        {/* ROUND 116 — manual-redelivery lineage badge (violet = operator
            action, distinct from the four transport states) */}
        {delivery.redeliveredFrom ? (
          <span
            title={t("whRedelivBadgeNote")}
            className="inline-flex shrink-0 items-center gap-1 rounded-full border border-violet-300/60 bg-violet-500/10 px-2.5 py-1 text-[10px] font-extrabold text-violet-600 dark:border-violet-500/40 dark:text-violet-300"
          >
            <CatIcon name="rotate-ccw" className="h-3 w-3" />
            {t("whRedelivBadge")}
          </span>
        ) : null}
        <span className="ms-auto shrink-0 text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
          {fullDate(delivery.createdAt, lang)}
        </span>
      </div>

      {/* attempts + response + error rail */}
      <div className="mt-2.5 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[11px] font-bold text-slate-500 dark:text-slate-400">
        <span className="inline-flex items-center gap-1.5" dir="ltr">
          <CatIcon name="repeat" className="h-3.5 w-3.5 text-slate-400" />
          {t("whHistoryAttempts", { n: nf(lang, delivery.attempts) })}
        </span>
        {delivery.responseStatus != null ? (
          <span
            dir="ltr"
            className={cn(
              "inline-flex items-center gap-1.5 rounded-lg px-1.5 py-0.5 font-mono",
              delivery.responseStatus >= 200 && delivery.responseStatus < 300
                ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-300"
                : "bg-rose-500/10 text-rose-600 dark:text-rose-300"
            )}
          >
            <CatIcon name="file-output" className="h-3.5 w-3.5" />
            {delivery.responseStatus}
          </span>
        ) : null}
        {delivery.error ? (
          <span
            dir="ltr"
            className="inline-flex items-center gap-1.5 rounded-lg bg-amber-500/10 px-1.5 py-0.5 font-mono text-amber-600 dark:text-amber-300"
            title={t("whHistoryErrorNote")}
          >
            <CatIcon name="triangle-alert" className="h-3.5 w-3.5" />
            {delivery.error}
          </span>
        ) : null}
        {delivery.nextAttemptAt ? (
          <span className="inline-flex items-center gap-1.5">
            <CatIcon name="timer" className="h-3.5 w-3.5 text-sky-400" />
            {t("whHistoryNext", { when: relativeTime(delivery.nextAttemptAt, lang) })}
          </span>
        ) : null}
      </div>

      {/* payload toggle + manual redelivery action */}
      <div className="mt-2.5 flex flex-wrap items-center gap-3">
        <button
          type="button"
          onClick={() => setPayloadOpen((v) => !v)}
          aria-expanded={payloadOpen}
          className="inline-flex items-center gap-1.5 rounded-lg text-[10.5px] font-extrabold text-slate-400 transition hover:text-brand-500 dark:text-slate-500 dark:hover:text-brand-300"
        >
          <CatIcon
            name="chevron-down"
            className={cn("h-3 w-3 transition-transform", payloadOpen && "rotate-180")}
          />
          {t("whHistoryPayload")}
        </button>
        {canRedeliver ? (
          <button
            type="button"
            onClick={() => onRedeliver(delivery)}
            title={t("whRedeliverNote")}
            className="ms-auto inline-flex items-center gap-1.5 rounded-full border border-amber-300/60 bg-amber-500/10 px-3 py-1 text-[10.5px] font-extrabold text-amber-600 transition hover:border-rose-300/70 hover:bg-linear-to-l hover:from-amber-500/15 hover:to-rose-500/15 hover:text-rose-600 active:scale-[0.97] dark:border-amber-500/40 dark:text-amber-300 dark:hover:border-rose-500/50 dark:hover:text-rose-300"
          >
            <CatIcon name="rotate-ccw" className="h-3 w-3" />
            {t("whRedeliverBtn")}
          </button>
        ) : null}
      </div>
      {payloadOpen ? (
        <pre
          dir="ltr"
          className="mt-1.5 max-h-48 overflow-auto rounded-xl border border-slate-200 bg-white px-3 py-2 font-mono text-[10px] leading-relaxed text-slate-700 dark:border-white/10 dark:bg-[#0b1220] dark:text-slate-300"
        >
          {delivery.payload}
        </pre>
      ) : null}
    </li>
  );
}

/** ROUND 115 — the per-endpoint delivery-history dialog (keyset-paginated
 *  infinite list, newest first; the endpoint's own URL rides the title).
 *  ROUND 116 — failed/exhausted rows gain a manual REDELIVER action: a
 *  confirm step, then the feed refetches and the fresh pending row (with
 *  its manual-redelivery lineage badge) lands on top. */
function DeliveryHistoryDialog({
  instanceId,
  endpoint,
  onClose,
}: {
  instanceId: string;
  endpoint: WebhookEndpointDTO | null;
  onClose: () => void;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();

  /* ROUND 116 — the delivery awaiting redelivery confirmation */
  const [redeliverTarget, setRedeliverTarget] = useState<WebhookDeliveryDTO | null>(null);

  const feed = useInfiniteQuery({
    queryKey: ["webhook-deliveries", instanceId, endpoint?.id],
    queryFn: ({ pageParam }) =>
      fetchWebhookDeliveries(instanceId, endpoint!.id, { limit: 10, cursor: pageParam }),
    initialPageParam: null as string | null,
    getNextPageParam: (lastPage) => lastPage.nextCursor,
    enabled: endpoint !== null,
    staleTime: 15_000,
    retry: 0,
  });

  const deliveries = useMemo(
    () => feed.data?.pages.flatMap((p) => p.deliveries) ?? [],
    [feed.data]
  );

  /* ROUND 116 — manual redelivery (owner recovery action). The confirm
   * dialog explains the at-least-once semantics BEFORE anything fires. */
  const redeliver = useMutation({
    mutationFn: (d: WebhookDeliveryDTO) =>
      redeliverWebhookDeliveryApi(instanceId, endpoint!.id, d.id),
    onSuccess: () => {
      setRedeliverTarget(null);
      /* the fresh pending row lands on top; endpoints stats (delivery
       * counts) ride the same invalidate */
      void queryClient.invalidateQueries({ queryKey: ["webhook-deliveries", instanceId] });
      void queryClient.invalidateQueries({ queryKey: ["instance-webhooks", instanceId] });
      toast.success(t("whRedeliverDone"));
    },
    onError: (e: Error) => toast.error(e.message || t("whRedeliverFailed")),
  });

  /* only failed/exhausted rows on a LIVE (active, non-deleted) endpoint
   * offer the action — pending rows are already in flight, succeeded rows
   * were delivered, and paused/deleted endpoints never dispatch */
  const redeliverable =
    endpoint != null && !endpoint.deleted && endpoint.active;
  const canRedeliver = (d: WebhookDeliveryDTO) =>
    redeliverable && (d.status === "failed" || d.status === "exhausted");

  return (
    <Dialog open={endpoint !== null} onOpenChange={(open) => (!open ? onClose() : undefined)}>
      <DialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
            <span
              className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
              style={{ backgroundImage: grad("#0ea5e9", "#6d5dfb") }}
            >
              <CatIcon name="clock-rotate-left" className="h-5 w-5" />
            </span>
            {t("whHistoryTitle")}
          </DialogTitle>
          <DialogDescription className="pt-1 text-[12.5px] leading-relaxed">
            {endpoint ? (
              <code
                dir="ltr"
                className="block max-w-full truncate rounded-lg border border-slate-200 bg-slate-50 px-2 py-1 font-mono text-[11px] font-bold text-sky-700 dark:border-white/10 dark:bg-white/[0.05] dark:text-sky-300"
              >
                {endpoint.url}
              </code>
            ) : null}
          </DialogDescription>
        </DialogHeader>

        <div className="max-h-[55vh] space-y-2.5 overflow-y-auto pe-1">
          {feed.isPending ? (
            <div className="space-y-2.5">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-24 w-full rounded-2xl" />
              ))}
            </div>
          ) : feed.isError ? (
            <div className="rounded-2xl border border-rose-300/60 bg-rose-500/10 p-6 text-center dark:border-rose-500/40 dark:bg-rose-500/10">
              <p className="text-[12px] font-extrabold text-rose-700 dark:text-rose-300">
                {feed.error instanceof Error ? feed.error.message : t("whHistoryFailed")}
              </p>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => void feed.refetch()}
                className="mt-3 h-9 gap-2 rounded-xl text-[12px] font-bold"
              >
                <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
                {t("retryText")}
              </Button>
            </div>
          ) : deliveries.length === 0 ? (
            <div className="rounded-2xl border-2 border-dashed border-slate-200 p-8 text-center dark:border-white/10">
              <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-sky-500/10 text-sky-500">
                <CatIcon name="clock-rotate-left" className="h-6 w-6" />
              </div>
              <h4 className="mt-3 font-display text-[14px] font-extrabold text-slate-900 dark:text-white">
                {t("whHistoryEmpty")}
              </h4>
              <p className="mx-auto mt-1 max-w-sm text-[12px] leading-relaxed text-slate-500 dark:text-slate-400">
                {t("whHistoryEmptyDesc")}
              </p>
            </div>
          ) : (
            <>
              <ul className="space-y-2.5">
                {deliveries.map((d) => (
                  <DeliveryRow
                    key={d.id}
                    delivery={d}
                    canRedeliver={canRedeliver(d)}
                    onRedeliver={setRedeliverTarget}
                  />
                ))}
              </ul>
              {feed.hasNextPage ? (
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => void feed.fetchNextPage()}
                  disabled={feed.isFetchingNextPage}
                  className="h-10 w-full gap-2 rounded-xl text-[12px] font-bold"
                >
                  <CatIcon
                    name="refresh-cw"
                    className={cn("h-3.5 w-3.5", feed.isFetchingNextPage && "animate-spin")}
                  />
                  {t("whHistoryMore")}
                </Button>
              ) : (
                <p className="py-1 text-center text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                  {t("whHistoryEnd")}
                </p>
              )}
            </>
          )}
        </div>

        {/* ROUND 118 — the endpoint's LIVE BACKLOG footer: the queue depth
            (pending + failed-inside-backoff deliveries the dispatcher still
            owes this endpoint), page-independent — it rides every page of
            the history feed so the owner always sees the real backlog */}
        {feed.data?.pages.length ? (
          <div
            className={cn(
              "mt-1 flex items-center justify-between gap-2 rounded-2xl border px-3.5 py-2.5",
              (feed.data.pages[feed.data.pages.length - 1].liveBacklog ?? 0) > 0
                ? "border-amber-300/60 bg-amber-500/10 dark:border-amber-500/40 dark:bg-amber-500/10"
                : "border-emerald-300/60 bg-emerald-500/[0.07] dark:border-emerald-500/40 dark:bg-emerald-500/10"
            )}
          >
            <span className="flex min-w-0 items-center gap-2 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
              <CatIcon
                name={
                  (feed.data.pages[feed.data.pages.length - 1].liveBacklog ?? 0) > 0
                    ? "hourglass"
                    : "circle-check"
                }
                className={cn(
                  "h-4 w-4 shrink-0",
                  (feed.data.pages[feed.data.pages.length - 1].liveBacklog ?? 0) > 0
                    ? "text-amber-500"
                    : "text-emerald-500"
                )}
              />
              {t("whBacklogLabel")}
            </span>
            <span
              dir="ltr"
              className={cn(
                "shrink-0 rounded-lg px-2 py-0.5 font-mono text-[12px] font-extrabold tabular-nums",
                (feed.data.pages[feed.data.pages.length - 1].liveBacklog ?? 0) > 0
                  ? "bg-amber-500/15 text-amber-600 dark:text-amber-300"
                  : "bg-emerald-500/10 text-emerald-600 dark:text-emerald-300"
              )}
            >
              {feed.data.pages[feed.data.pages.length - 1].liveBacklog ?? 0}
            </span>
          </div>
        ) : null}

        {/* ROUND 116 — manual redelivery confirm (inside the history dialog:
            the context — event, attempts, error class — stays visible while
            the owner decides; the description states the at-least-once
            contract explicitly so the action is never mistaken for a
            first-time send) */}
        <AlertDialog
          open={redeliverTarget !== null}
          onOpenChange={(open) => (!open ? setRedeliverTarget(null) : undefined)}
        >
          <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"}>
            <AlertDialogHeader>
              <AlertDialogTitle className="flex items-center gap-2.5 font-display text-base font-extrabold">
                <span
                  className="grid h-9 w-9 place-items-center rounded-xl text-white shadow-md"
                  style={{ backgroundImage: grad("#f59e0b", "#f43f5e") }}
                >
                  <CatIcon name="rotate-ccw" className="h-4 w-4" />
                </span>
                {t("whRedeliverTitle")}
              </AlertDialogTitle>
              <AlertDialogDescription className="text-[12.5px] leading-relaxed">
                {t("whRedeliverDesc")}
                {redeliverTarget ? (
                  <span
                    dir="ltr"
                    className="mt-2 flex flex-wrap items-center gap-2 text-[11px] font-bold text-slate-500 dark:text-slate-400"
                  >
                    <span className="inline-flex items-center gap-1.5 rounded-lg bg-slate-100 px-2 py-1 font-mono dark:bg-white/[0.06]">
                      <CatIcon name={EVENT_META[redeliverTarget.event]?.icon ?? "bell"} className="h-3 w-3" />
                      {redeliverTarget.event}
                    </span>
                    <span className="inline-flex items-center gap-1.5 rounded-lg bg-slate-100 px-2 py-1 font-mono dark:bg-white/[0.06]">
                      <CatIcon name="repeat" className="h-3 w-3" />
                      {redeliverTarget.attempts}
                    </span>
                    {redeliverTarget.error ? (
                      <span className="inline-flex items-center gap-1.5 rounded-lg bg-amber-500/10 px-2 py-1 font-mono text-amber-600 dark:text-amber-300">
                        <CatIcon name="triangle-alert" className="h-3 w-3" />
                        {redeliverTarget.error}
                      </span>
                    ) : null}
                  </span>
                ) : null}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter className="gap-2">
              <AlertDialogCancel className="h-10 rounded-xl px-4 text-[12.5px] font-bold">
                {t("dlgCancel")}
              </AlertDialogCancel>
              <AlertDialogAction
                onClick={() => redeliverTarget && redeliver.mutate(redeliverTarget)}
                disabled={redeliver.isPending}
                className="h-10 rounded-xl bg-linear-to-l from-amber-500 to-rose-500 px-4 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110"
              >
                {redeliver.isPending ? (
                  <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                ) : (
                  <CatIcon name="rotate-ccw" className="h-4 w-4" />
                )}
                {t("whRedeliverConfirm")}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </DialogContent>
    </Dialog>
  );
}

/* ------------------------------------------------------- the view ----- */

export function WebhooksView({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();

  const [createOpen, setCreateOpen] = useState(false);
  const [rotateTarget, setRotateTarget] = useState<WebhookEndpointDTO | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<WebhookEndpointDTO | null>(null);
  /* ROUND 115 — the delivery-history drill-down target */
  const [historyTarget, setHistoryTarget] = useState<WebhookEndpointDTO | null>(null);
  const [revealedSecret, setRevealedSecret] = useState<string | null>(null);

  /* create-dialog form state */
  const [url, setUrl] = useState("");
  const [label, setLabel] = useState("");
  const [pickedEvents, setPickedEvents] = useState<string[]>(["order.placed"]);

  const webhooksQuery = useQuery({
    queryKey: ["instance-webhooks", instance.id],
    queryFn: () => fetchInstanceWebhooks(instance.id),
    staleTime: 20_000,
    retry: 0,
  });

  const invalidate = () =>
    queryClient.invalidateQueries({ queryKey: ["instance-webhooks", instance.id] });

  const create = useMutation({
    mutationFn: () =>
      createInstanceWebhook(instance.id, {
        url: url.trim(),
        events: pickedEvents,
        ...(label.trim() ? { description: label.trim() } : {}),
      }),
    onSuccess: (created) => {
      invalidate();
      setCreateOpen(false);
      setUrl("");
      setLabel("");
      setPickedEvents(["order.placed"]);
      /* the ONLY moment the full secret ever appears */
      setRevealedSecret(created.secret);
      toast.success(t("whCreateOk"));
    },
    onError: (e: Error) => toast.error(e.message || t("whCreateFail")),
  });

  const toggle = useMutation({
    mutationFn: (e: WebhookEndpointDTO) =>
      updateInstanceWebhook(instance.id, e.id, { active: !e.active }),
    onSuccess: (_data, e) => {
      invalidate();
      toast.success(e.active ? t("whPausedOk") : t("whResumedOk"));
    },
    onError: (e: Error) => toast.error(e.message || t("errorText")),
  });

  const rotate = useMutation({
    mutationFn: (e: WebhookEndpointDTO) =>
      updateInstanceWebhook(instance.id, e.id, { rotate: true }),
    onSuccess: (updated) => {
      invalidate();
      setRotateTarget(null);
      if (updated.secret) setRevealedSecret(updated.secret);
      toast.success(t("whRotateOk"));
    },
    onError: (e: Error) => toast.error(e.message || t("errorText")),
  });

  const remove = useMutation({
    mutationFn: (e: WebhookEndpointDTO) => deleteInstanceWebhook(instance.id, e.id),
    onSuccess: () => {
      invalidate();
      setDeleteTarget(null);
      toast.success(t("whDeleteOk"));
    },
    onError: (e: Error) => toast.error(e.message || t("errorText")),
  });

  const endpoints = useMemo(() => webhooksQuery.data ?? [], [webhooksQuery.data]);
  const busy = create.isPending || toggle.isPending || rotate.isPending || remove.isPending;

  /* KPI aggregates over the loaded fleet */
  const stats = useMemo(() => {
    const live = endpoints.filter((e) => !e.deleted && e.active);
    /* ROUND 139 — the paused + soft-deleted cohorts feed the new golden KPIs */
    const paused = endpoints.filter((e) => !e.deleted && !e.active);
    const deleted = endpoints.filter((e) => e.deleted);
    const deliveries = endpoints.reduce((sum, e) => sum + (e.deliveries ?? 0), 0);
    const covered = new Set(live.flatMap((e) => e.events));
    const last = endpoints
      .map((e) => e.lastDeliveryAt)
      .filter((x): x is string => x != null)
      .sort()
      .at(-1);
    return {
      live: live.length,
      paused: paused.length,
      deleted: deleted.length,
      deliveries,
      covered: covered.size,
      last: last ?? null,
    };
  }, [endpoints]);

  const submitCreate = () => {
    if (!/^https?:\/\/.+\..+/.test(url.trim()) && !/^http:\/\/(localhost|127\.0\.0\.1|\[::1\])(:\d+)?(\/|$)/.test(url.trim())) {
      toast.error(t("whUrlInvalid"));
      return;
    }
    if (pickedEvents.length === 0) {
      toast.error(t("whEventsMin"));
      return;
    }
    create.mutate();
  };

  const toggleEvent = (event: string) => {
    setPickedEvents((prev) =>
      prev.includes(event) ? prev.filter((e) => e !== event) : [...prev, event]
    );
  };

  return (
    <div className="space-y-5">
      <ViewHeading title={t("dashWebhooks")} desc={t("dashWebhooksDesc")} />

      {/* KPI strip — ROUND 139: THE golden inventory-page cards
          (grid-cols-2 → md:grid-cols-3 → xl:grid-cols-5; count-up
          numerals, skeleton while the fleet loads, rose tone when the
          whole fleet sits paused, last delivery as a relative-time
          value with the exact timestamp underneath). */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        <StatCard
          size="golden"
          label={t("whKpiLive")}
          numeric={stats.live}
          sub={t("whKpiLiveSub", { n: nf(lang, endpoints.length) })}
          icon="webhook"
          c1="#8b5cf6"
          c2="#7c3aed"
          index={0}
          lang={lang}
          tone={stats.live > 0 ? "up" : endpoints.length > 0 ? "down" : undefined}
          loading={webhooksQuery.isPending}
        />
        <StatCard
          size="golden"
          label={t("whKpiDeliveries")}
          numeric={stats.deliveries}
          sub={t("whKpiDeliveriesSub", { n: nf(lang, stats.live) })}
          icon="send"
          c1="#10b981"
          c2="#059669"
          index={1}
          lang={lang}
          loading={webhooksQuery.isPending}
        />
        <StatCard
          size="golden"
          label={t("whKpiCovered")}
          numeric={stats.covered}
          sub={t("whKpiCoveredSub", { n: nf(lang, ALL_EVENTS.length) })}
          icon="bell"
          c1="#f59e0b"
          c2="#d97706"
          index={2}
          lang={lang}
          tone={stats.covered >= ALL_EVENTS.length ? "up" : undefined}
          loading={webhooksQuery.isPending}
        />
        <StatCard
          size="golden"
          label={t("whKpiPaused")}
          numeric={stats.paused}
          sub={t("whKpiPausedSub", { n: nf(lang, stats.deleted) })}
          icon="power"
          c1="#06b6d4"
          c2="#0891b2"
          index={3}
          lang={lang}
          tone={stats.paused > 0 ? "down" : undefined}
          loading={webhooksQuery.isPending}
        />
        <StatCard
          size="golden"
          label={t("whKpiLast")}
          value={stats.last ? relativeTime(stats.last, lang) : t("whStatNever")}
          sub={stats.last ? fullDate(stats.last, lang) : null}
          icon="clock-rotate-left"
          c1="#f43f5e"
          c2="#e11d48"
          index={4}
          lang={lang}
          loading={webhooksQuery.isPending}
        />
      </div>

      {/* merchant integration guide — how receivers verify + what to expect */}
      <DashCard title={t("whGuideTitle")} icon="shield-check">
        <div className="grid gap-3 lg:grid-cols-3">
          {/* signature verification */}
          <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
            <p className="flex items-center gap-2 text-[12px] font-extrabold text-slate-800 dark:text-slate-100">
              <span
                className="grid h-7 w-7 place-items-center rounded-lg text-white"
                style={{ backgroundImage: grad("#10b981", "#059669") }}
                aria-hidden="true"
              >
                <CatIcon name="shield-check" className="h-3.5 w-3.5" />
              </span>
              {t("whGuideVerifyTitle")}
            </p>
            <p className="mt-2 text-[11px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
              {t("whGuideVerifyDesc")}
            </p>
            <code
              dir="ltr"
              className="mt-2.5 block overflow-x-auto rounded-xl border border-slate-200 bg-white px-3 py-2 font-mono text-[10.5px] font-bold text-slate-700 dark:border-white/10 dark:bg-[#0b1220] dark:text-emerald-300"
            >
              {"HMAC_SHA256(secret, timestamp + \".\" + body)"}
            </code>
          </div>
          {/* delivery headers */}
          <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
            <p className="flex items-center gap-2 text-[12px] font-extrabold text-slate-800 dark:text-slate-100">
              <span
                className="grid h-7 w-7 place-items-center rounded-lg text-white"
                style={{ backgroundImage: grad("#6d5dfb", "#0ea5e9") }}
                aria-hidden="true"
              >
                <CatIcon name="braces" className="h-3.5 w-3.5" />
              </span>
              {t("whGuideHeadersTitle")}
            </p>
            <p className="mt-2 text-[11px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
              {t("whGuideHeadersDesc")}
            </p>
            <div dir="ltr" className="mt-2.5 space-y-1.5">
              <code
                className="block overflow-x-auto rounded-lg border border-slate-200 bg-white px-3 py-1.5 font-mono text-[10.5px] font-bold text-slate-700 dark:border-white/10 dark:bg-[#0b1220] dark:text-sky-300"
              >
                x-ashrilogic-event: order.placed
              </code>
              <code
                className="block overflow-x-auto rounded-lg border border-slate-200 bg-white px-3 py-1.5 font-mono text-[10.5px] font-bold text-slate-700 dark:border-white/10 dark:bg-[#0b1220] dark:text-sky-300"
              >
                x-ashrilogic-signature: t=…,v1=…
              </code>
            </div>
            <p className="mt-2 text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
              {t("whGuideSigFormat")}
            </p>
          </div>
          {/* retry contract */}
          <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
            <p className="flex items-center gap-2 text-[12px] font-extrabold text-slate-800 dark:text-slate-100">
              <span
                className="grid h-7 w-7 place-items-center rounded-lg text-white"
                style={{ backgroundImage: grad("#f59e0b", "#d97706") }}
                aria-hidden="true"
              >
                <CatIcon name="timer" className="h-3.5 w-3.5" />
              </span>
              {t("whGuideRetryTitle")}
            </p>
            <p className="mt-2 text-[11px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
              {t("whGuideRetryDesc")}
            </p>
            <div dir="ltr" className="mt-2.5 flex flex-wrap gap-1.5">
              {["1m", "5m", "30m", "2h"].map((step, i) => (
                <span
                  key={step}
                  className="rounded-full border border-slate-200 bg-white px-2.5 py-1 font-mono text-[10.5px] font-extrabold text-slate-600 dark:border-white/10 dark:bg-[#0b1220] dark:text-amber-300"
                >
                  {i === 0 ? "try" : `retry ${i}`} → {step}
                </span>
              ))}
            </div>
            <p className="mt-2 text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
              {t("whGuideRetryNote")}
            </p>
          </div>
        </div>
      </DashCard>

      {/* the endpoint console */}
      <DashCard title={t("whEndpointsTitle")} icon="webhook">
        <div className="space-y-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <p className="max-w-xl text-[11.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {t("whEndpointsDesc")}
            </p>
            <Button
              type="button"
              onClick={() => setCreateOpen(true)}
              className="h-9 shrink-0 gap-1.5 rounded-xl px-4 text-[12px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.98]"
              style={{
                backgroundImage: grad("#0ea5e9", "#6d5dfb"),
                boxShadow: "0 10px 22px -10px rgba(14, 165, 233, 0.75)",
              }}
            >
              <CatIcon name="plus" className="h-3.5 w-3.5" />
              {t("whAddBtn")}
            </Button>
          </div>

          {webhooksQuery.isPending ? (
            <div className="space-y-2.5">
              {Array.from({ length: 2 }).map((_, i) => (
                <Skeleton key={i} className="h-28 w-full rounded-2xl" />
              ))}
            </div>
          ) : webhooksQuery.isError ? (
            <div className="rounded-2xl border border-rose-300/60 bg-rose-500/10 p-6 text-center dark:border-rose-500/40 dark:bg-rose-500/10">
              <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-rose-500/15 text-rose-500">
                <CatIcon name="triangle-alert" className="h-6 w-6" />
              </div>
              <h4 className="mt-3 font-display text-[14px] font-extrabold text-slate-900 dark:text-white">
                {t("whLoadFailed")}
              </h4>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => void webhooksQuery.refetch()}
                className="mt-4 h-9 gap-2 rounded-xl text-[12px] font-bold"
              >
                <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
                {t("retryText")}
              </Button>
            </div>
          ) : endpoints.length === 0 ? (
            <div className="rounded-2xl border-2 border-dashed border-slate-200 p-8 text-center dark:border-white/10">
              <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-sky-500/10 text-sky-500">
                <CatIcon name="webhook" className="h-6 w-6" />
              </div>
              <h4 className="mt-3 font-display text-[14px] font-extrabold text-slate-900 dark:text-white">
                {t("whEmptyTitle")}
              </h4>
              <p className="mx-auto mt-1 max-w-sm text-[12px] leading-relaxed text-slate-500 dark:text-slate-400">
                {t("whEmptyDesc")}
              </p>
              <Button
                type="button"
                onClick={() => setCreateOpen(true)}
                className="mt-5 h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.98]"
                style={{
                  backgroundImage: grad("#0ea5e9", "#6d5dfb"),
                  boxShadow: "0 12px 26px -10px rgba(14, 165, 233, 0.75)",
                }}
              >
                <CatIcon name="plus" className="h-4 w-4" />
                {t("whAddBtn")}
              </Button>
            </div>
          ) : (
            <ul className="space-y-2.5">
              {endpoints.map((endpoint) => (
                <EndpointRow
                  key={endpoint.id}
                  endpoint={endpoint}
                  busy={busy}
                  onToggle={(e) => toggle.mutate(e)}
                  onRotate={(e) => setRotateTarget(e)}
                  onDelete={(e) => setDeleteTarget(e)}
                  onHistory={(e) => setHistoryTarget(e)}
                />
              ))}
            </ul>
          )}
        </div>
      </DashCard>

      {/* ------------------------------ create dialog ------------------ */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-10 w-10 place-items-center rounded-2xl text-white shadow-lg"
                style={{ backgroundImage: grad("#0ea5e9", "#6d5dfb") }}
              >
                <CatIcon name="webhook" className="h-5 w-5" />
              </span>
              {t("whCreateTitle")}
            </DialogTitle>
            <DialogDescription className="pt-1 text-[12.5px] leading-relaxed">
              {t("whCreateDesc")}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="wh-url" className="text-[12px] font-extrabold">
                {t("whUrlLabel")}
              </Label>
              <Input
                id="wh-url"
                dir="ltr"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://api.example.com/hooks/ashrilogic"
                className="h-10 rounded-xl font-mono text-[12.5px]"
                autoComplete="off"
              />
              <p className="text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                {t("whUrlHint")}
              </p>
            </div>

            <div className="space-y-1.5">
              <Label className="text-[12px] font-extrabold">{t("whEventsLabel")}</Label>
              <div className="space-y-1.5">
                {ALL_EVENTS.map((event) => {
                  const meta = EVENT_META[event];
                  const picked = pickedEvents.includes(event);
                  return (
                    <button
                      key={event}
                      type="button"
                      onClick={() => toggleEvent(event)}
                      aria-pressed={picked}
                      className={cn(
                        "flex w-full items-center gap-3 rounded-xl border px-3 py-2.5 text-start transition active:scale-[0.99]",
                        picked
                          ? "border-brand-300 bg-brand-500/10 dark:border-brand-500/40 dark:bg-brand-500/10"
                          : "border-slate-200 bg-white hover:border-brand-200 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-brand-500/30"
                      )}
                    >
                      <span
                        className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white"
                        style={{ backgroundImage: grad(meta.c1, meta.c2) }}
                        aria-hidden="true"
                      >
                        <CatIcon name={meta.icon} className="h-3.5 w-3.5" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block font-mono text-[12px] font-extrabold text-slate-800 dark:text-slate-100" dir="ltr">
                          {event}
                        </span>
                        <span className="block text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                          {t(meta.hintKey)}
                        </span>
                      </span>
                      <span
                        className={cn(
                          "grid h-5 w-5 shrink-0 place-items-center rounded-md border transition",
                          picked
                            ? "border-brand-500 bg-brand-500 text-white"
                            : "border-slate-300 bg-white text-transparent dark:border-white/20 dark:bg-white/[0.04]"
                        )}
                        aria-hidden="true"
                      >
                        <CatIcon name="check" className="h-3 w-3" />
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="wh-label" className="text-[12px] font-extrabold">
                {t("whLabelLabel")}
              </Label>
              <Input
                id="wh-label"
                value={label}
                onChange={(e) => setLabel(e.target.value)}
                placeholder={t("whLabelPh")}
                maxLength={120}
                className="h-10 rounded-xl text-[12.5px]"
              />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setCreateOpen(false)}
              className="h-10 rounded-xl px-5 text-[12.5px] font-bold"
            >
              {t("dlgCancel")}
            </Button>
            <Button
              type="button"
              onClick={submitCreate}
              disabled={create.isPending || url.trim().length < 8 || pickedEvents.length === 0}
              className="h-10 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.98]"
              style={{
                backgroundImage: grad("#0ea5e9", "#6d5dfb"),
                boxShadow: "0 12px 26px -10px rgba(14, 165, 233, 0.75)",
              }}
            >
              {create.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="plus" className="h-4 w-4" />
              )}
              {t("whCreateConfirm")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ------------------------------ rotate confirm ------------------ */}
      <AlertDialog open={rotateTarget !== null} onOpenChange={(open) => (!open ? setRotateTarget(null) : undefined)}>
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"}>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-base font-extrabold">
              <span
                className="grid h-9 w-9 place-items-center rounded-xl text-white shadow-md"
                style={{ backgroundImage: grad("#f59e0b", "#d97706") }}
              >
                <CatIcon name="key-round" className="h-4 w-4" />
              </span>
              {t("whRotateTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[12.5px] leading-relaxed">
              {t("whRotateDesc")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="gap-2">
            <AlertDialogCancel className="h-10 rounded-xl px-4 text-[12.5px] font-bold">
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => rotateTarget && rotate.mutate(rotateTarget)}
              disabled={rotate.isPending}
              className="h-10 rounded-xl bg-linear-to-l from-amber-500 to-orange-500 px-4 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110"
            >
              {t("whRotateConfirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ------------------------------ delete confirm ------------------ */}
      <AlertDialog open={deleteTarget !== null} onOpenChange={(open) => (!open ? setDeleteTarget(null) : undefined)}>
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"}>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-base font-extrabold">
              <span
                className="grid h-9 w-9 place-items-center rounded-xl text-white shadow-md"
                style={{ backgroundImage: grad("#f43f5e", "#e11d48") }}
              >
                <CatIcon name="trash-2" className="h-4 w-4" />
              </span>
              {t("whDeleteTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[12.5px] leading-relaxed">
              {t("whDeleteDesc")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="gap-2">
            <AlertDialogCancel className="h-10 rounded-xl px-4 text-[12.5px] font-bold">
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteTarget && remove.mutate(deleteTarget)}
              disabled={remove.isPending}
              className="h-10 rounded-xl bg-linear-to-l from-rose-500 to-red-500 px-4 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110"
            >
              {t("whDeleteConfirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* the one-time secret reveal (create + rotate converge here) */}
      <SecretRevealDialog secret={revealedSecret} onClose={() => setRevealedSecret(null)} />

      {/* ROUND 115 — the per-endpoint delivery-history drill-down */}
      <DeliveryHistoryDialog
        instanceId={instance.id}
        endpoint={historyTarget}
        onClose={() => setHistoryTarget(null)}
      />
    </div>
  );
}
