"use client";

/**
 * Dashboard — analytics view (Task 3-c · ROUND 143 premium rebuild).
 *
 * «قم بتطوير صفحة (التحليلات) بطريقة احترافية ومتكاملة مع تفاصيل دقيقة جداً»
 *
 * The view is rebuilt as a full analytical surface, replicated across all
 * 102 systems:
 *
 *  · KPI strip 1 — the 12-month revenue law (total / average / best month /
 *    users / uptime) on THE golden StatCard, upgraded with the live MoM
 *    growth chip (anGrowthLabel) driven by the accent pair.
 *  · KPI strip 2 — orders-driven KPIs (count / avg order / paid rate /
 *    completion rate / revenue-per-user) computed client-side from the live
 *    orders feed (["instance-orders"]).
 *  · Range selector (7 / 30 / 90 / all) — filters every orders-derived
 *    surface; the 12-month revenue series stays all-time (labeled).
 *  · ComposedChart — revenue area (accent gradient) + 3-month moving
 *    average (dashed) + growth-streak & least-squares next-month forecast
 *    chips.
 *  · 14-day orders histogram + customers panel (unique / new-this-week /
 *    top-3 by orders & spend).
 *  · Twin donuts — revenue distribution + orders by status (center totals).
 *  · Top-5 products with rank tiles & share meters, team-activity role
 *    bars + newest member, module-usage chip cloud.
 *  · Wallet totals (in / out / movements), best & quietest weekday, and the
 *    peak-hour card with a 24-slot hourly pulse strip.
 *
 * All numerals follow the locale policy (fmtNum + numDir), charts live in
 * dir="ltr" wrappers, and every slate tone carries a dark: variant.
 */
import { useMemo, useState } from "react";
import type { CSSProperties, ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Area,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ComposedChart,
  Line,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { MODULE_MAP } from "@/data/catalog";
import { useT, type I18nKey } from "@/lib/i18n";
import { intlLocale } from "@/lib/locales";
import { fetchInstanceOrders, fetchMembers, fetchModuleRecords, fetchWallet } from "@/lib/api-client";
import { buildModuleDataset, type ModuleDataset } from "@/lib/module-data";
import type { InstanceDTO, InstanceStats, Lang, SiteOrderStatus, TeamMemberDTO, WalletTxnDTO } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { cn, fmtMoneyCell, fmtNum, grad, hexAlpha, initial, labelTrack, numDir } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import {
  CHART_TOOLTIP_STYLE,
  DashCard,
  IconTile,
  MeterBar,
  ViewHeading,
  relativeTime,
} from "@/components/dashboard/dash-shared";
import { useAccentPair } from "@/components/dashboard/accent-context";
import { AiInsightsPanel } from "@/components/dashboard/views/ai-insights-panel";
import { StatCard } from "@/components/shared/stat-card";

/* ------------------------------------------------------------------ */
/* vocabulary — statuses, roles, ranges                                */
/* ------------------------------------------------------------------ */

/** Donut slice / legend row shape (status aggregates). */
interface DonutEntry {
  key: string;
  label: string;
  value: number;
  color: string;
}

/** One aggregated product line (name × qty × revenue). */
interface ProductLine {
  name: string;
  qty: number;
  revenue: number;
}

/** One aggregated storefront customer. */
interface CustomerLine {
  name: string;
  orders: number;
  spend: number;
}

/** One 14-day histogram bucket. */
interface DayBucket {
  key: string;
  /** short axis tick (localized day-of-month) */
  label: string;
  /** full localized date for the tooltip */
  full: string;
  orders: number;
  revenue: number;
  isToday: boolean;
}

type RangeKey = "7" | "30" | "90" | "all";
type MemberRole = "manager" | "staff" | "viewer";

const ORDER_STATUSES: readonly SiteOrderStatus[] = [
  "pending",
  "confirmed",
  "preparing",
  "ready",
  "completed",
  "cancelled",
];

/** ROUND 143 law — the fixed status palette (spec colors). */
const STATUS_COLORS: Record<SiteOrderStatus, string> = {
  pending: "#f59e0b",
  confirmed: "#10b981",
  preparing: "#06b6d4",
  ready: "#8b5cf6",
  completed: "#059669",
  cancelled: "#94a3b8",
};

const STATUS_LABEL_KEY: Record<SiteOrderStatus, I18nKey> = {
  pending: "ordStatusPending",
  confirmed: "ordStatusConfirmed",
  preparing: "ordStatusPreparing",
  ready: "ordStatusReady",
  completed: "ordStatusCompleted",
  cancelled: "ordStatusCancelled",
};

const ROLE_KEY: Record<MemberRole, I18nKey> = {
  manager: "roleManager",
  staff: "roleStaff",
  viewer: "roleViewer",
};

const ROLE_GRADIENTS: Record<MemberRole, [string, string]> = {
  manager: ["#8b5cf6", "#7c3aed"],
  staff: ["#06b6d4", "#0891b2"],
  viewer: ["#94a3b8", "#64748b"],
};

const RANGES: { key: RangeKey; labelKey: I18nKey; days: number }[] = [
  { key: "7", labelKey: "anRange7", days: 7 },
  { key: "30", labelKey: "anRange30", days: 30 },
  { key: "90", labelKey: "anRange90", days: 90 },
  { key: "all", labelKey: "anRangeAll", days: 0 },
];

/** localized module name with a safe fallback to the raw key */
function moduleName(id: string, lang: Lang): string {
  const m = MODULE_MAP[id];
  return m ? (lang === "ar" ? m.nameAr : m.nameEn) : id;
}

/** local calendar date key (YYYY-MM-DD) for day bucketing */
function dateKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

/** zero-padded 2-digit hour */
function pad2(n: number): string {
  return String(n).padStart(2, "0");
}

/* ------------------------------------------------------------------ */
/* view                                                                */
/* ------------------------------------------------------------------ */

export function AnalyticsView({ instance, stats }: { instance: InstanceDTO; stats: InstanceStats }) {
  const { t, lang } = useT();
  const { c1, c2 } = useAccentPair();
  const [range, setRange] = useState<RangeKey>("all");

  const rangeDays = RANGES.find((r) => r.key === range)?.days ?? 0;
  const currency = stats.currency ?? "$";
  const gradId = `an-rev-${instance.id}`;

  /* 12-month series money: the showcase tier keeps the legacy $ shape,
   * the real tier carries the store's own currency (ROUND 61 law). */
  const money = (v: number): string =>
    stats.demo ? `$${fmtNum(v, lang)}` : `${fmtNum(v, lang)} ${currency}`.trim();

  /* ---------------- live feeds (staleTime 30s, deduped keys) -------- */

  const ordersQuery = useQuery({
    queryKey: ["instance-orders", instance.id],
    queryFn: () => fetchInstanceOrders(instance.id, { limit: 100 }),
    staleTime: 30_000,
    retry: 1,
  });
  const membersQuery = useQuery({
    queryKey: ["instance-members", instance.id],
    queryFn: () => fetchMembers(instance.id),
    staleTime: 30_000,
    retry: 1,
  });
  const walletQuery = useQuery({
    queryKey: ["wallet", instance.id],
    queryFn: () => fetchWallet(instance.id),
    staleTime: 30_000,
    retry: 1,
  });

  const orders = useMemo(() => ordersQuery.data?.orders ?? [], [ordersQuery.data]);
  const members = useMemo(() => membersQuery.data ?? [], [membersQuery.data]);
  const hasOrders = ordersQuery.isSuccess && orders.length > 0;
  const orderCur = orders[0]?.currency ?? currency;

  /* ---------------- model 1 — the 12-month revenue law -------------- */

  const revenueModel = useMemo(() => {
    const pts = stats.revenue;
    const values = pts.map((p) => p.value);
    const n = values.length;
    const sum = values.reduce((s, v) => s + v, 0);
    const avg = n > 0 ? sum / n : 0;
    const bestIdx = values.length > 0 ? values.indexOf(Math.max(...values)) : -1;
    const best = bestIdx >= 0 ? pts[bestIdx] : undefined;

    /* MoM growth — null when the previous month is zero (honesty law) */
    const last = n > 0 ? values[n - 1] : 0;
    const prev = n > 1 ? values[n - 2] : 0;
    const mom = prev > 0 ? ((last - prev) / prev) * 100 : null;

    /* consecutive-month growth streak (tail-anchored) */
    let streak = 0;
    for (let i = n - 1; i > 0; i -= 1) {
      if ((values[i] ?? 0) > (values[i - 1] ?? 0)) streak += 1;
      else break;
    }

    /* next-month forecast — least-squares linear regression over the 12 pts */
    let forecast = last;
    if (n >= 2) {
      const sx = ((n - 1) * n) / 2;
      const sy = sum;
      let sxx = 0;
      let sxy = 0;
      values.forEach((y, i) => {
        sxx += i * i;
        sxy += i * y;
      });
      const denom = n * sxx - sx * sx;
      const slope = denom !== 0 ? (n * sxy - sx * sy) / denom : 0;
      const intercept = denom !== 0 ? (sy - slope * sx) / n : sy / n;
      forecast = Math.max(0, intercept + slope * n);
    }

    /* chart series — revenue + 3-month moving average (null-padded head) */
    const chartData = pts.map((p, i) => ({
      label: p.label,
      value: p.value,
      ma: i >= 2 ? ((values[i - 2] ?? 0) + (values[i - 1] ?? 0) + (values[i] ?? 0)) / 3 : null,
    }));

    return { sum, avg, best, mom, streak, forecast, chartData };
  }, [stats.revenue]);

  /* ---------------- model 2 — orders analytics (range-filtered) ----- */

  const inRangeOrders = useMemo(() => {
    if (rangeDays === 0) return orders;
    const cutoff = Date.now() - rangeDays * 86_400_000;
    return orders.filter((o) => new Date(o.createdAt).getTime() >= cutoff);
  }, [orders, rangeDays]);

  const ordersModel = useMemo(() => {
    const total = inRangeOrders.length;
    const cancelled = inRangeOrders.filter((o) => o.status === "cancelled").length;
    const pending = inRangeOrders.filter((o) => o.status === "pending").length;
    const completed = inRangeOrders.filter((o) => o.status === "completed").length;
    const revenue = inRangeOrders.reduce((s, o) => s + (o.status === "cancelled" ? 0 : o.total), 0);

    /* revenue & counts per status (donuts + legends) */
    const statusRev: DonutEntry[] = [];
    const statusCounts: DonutEntry[] = [];
    for (const st of ORDER_STATUSES) {
      const group = inRangeOrders.filter((o) => o.status === st);
      if (group.length === 0) continue;
      statusRev.push({
        key: st,
        label: t(STATUS_LABEL_KEY[st]),
        value: Math.round(group.reduce((s, o) => s + o.total, 0)),
        color: STATUS_COLORS[st],
      });
      statusCounts.push({ key: st, label: t(STATUS_LABEL_KEY[st]), value: group.length, color: STATUS_COLORS[st] });
    }
    const grossValue = statusRev.reduce((s, e) => s + e.value, 0);

    /* 14-day histogram — a FIXED recent-pulse window over the full feed */
    const dayFmt = new Intl.DateTimeFormat(intlLocale(lang), { day: "numeric" });
    const fullFmt = new Intl.DateTimeFormat(intlLocale(lang), { day: "numeric", month: "long" });
    const dayBuckets: DayBucket[] = [];
    const bucketIndex = new Map<string, number>();
    for (let i = 13; i >= 0; i -= 1) {
      const d = new Date();
      d.setHours(0, 0, 0, 0);
      d.setDate(d.getDate() - i);
      const bucket: DayBucket = {
        key: dateKey(d),
        label: dayFmt.format(d),
        full: fullFmt.format(d),
        orders: 0,
        revenue: 0,
        isToday: i === 0,
      };
      bucketIndex.set(bucket.key, dayBuckets.length);
      dayBuckets.push(bucket);
    }
    for (const o of orders) {
      const idx = bucketIndex.get(dateKey(new Date(o.createdAt)));
      if (idx === undefined) continue;
      const bucket = dayBuckets[idx];
      bucket.orders += 1;
      if (o.status !== "cancelled") bucket.revenue += o.total;
    }
    const histOrders = dayBuckets.reduce((s, b) => s + b.orders, 0);
    const histRevenue = dayBuckets.reduce((s, b) => s + b.revenue, 0);

    /* top products — items aggregated across non-cancelled orders */
    const prodMap = new Map<string, ProductLine>();
    for (const o of inRangeOrders) {
      if (o.status === "cancelled") continue;
      for (const item of o.items) {
        const name = item.name.trim() || "—";
        const line = prodMap.get(name) ?? { name, qty: 0, revenue: 0 };
        line.qty += item.qty;
        line.revenue += item.price * item.qty;
        prodMap.set(name, line);
      }
    }
    const topProducts = [...prodMap.values()].sort((a, b) => b.revenue - a.revenue).slice(0, 5);

    /* customers — unique names, new-this-week, top-3 by orders & spend */
    const custMap = new Map<string, { name: string; orders: number; spend: number; firstAt: number }>();
    for (const o of inRangeOrders) {
      if (o.status === "cancelled") continue;
      const name = (o.customerName ?? "").trim() || "—";
      const at = new Date(o.createdAt).getTime();
      const line = custMap.get(name) ?? { name, orders: 0, spend: 0, firstAt: at };
      line.orders += 1;
      line.spend += o.total;
      line.firstAt = Math.min(line.firstAt, at);
      custMap.set(name, line);
    }
    const uniqueCustomers = custMap.size;
    const weekAgo = Date.now() - 7 * 86_400_000;
    const newThisWeek = [...custMap.values()].filter((c) => c.firstAt >= weekAgo).length;
    const topCustomers: CustomerLine[] = [...custMap.values()]
      .sort((a, b) => b.orders - a.orders || b.spend - a.spend)
      .slice(0, 3);

    /* peak hour — mode of createdAt hours + the 24-slot distribution */
    const hourCounts = new Array<number>(24).fill(0);
    for (const o of inRangeOrders) hourCounts[new Date(o.createdAt).getHours()] += 1;
    let peakHour = -1;
    let peakCount = 0;
    for (let h = 0; h < 24; h += 1) {
      const cnt = hourCounts[h] ?? 0;
      if (cnt > peakCount) {
        peakCount = cnt;
        peakHour = h;
      }
    }

    /* best & quietest weekday by order count */
    const dowCounts = new Array<number>(7).fill(0);
    for (const o of inRangeOrders) dowCounts[new Date(o.createdAt).getDay()] += 1;
    let bestDow = -1;
    let bestDowCount = -1;
    let worstDow = -1;
    let worstDowCount = Number.POSITIVE_INFINITY;
    for (let d = 0; d < 7; d += 1) {
      const cnt = dowCounts[d] ?? 0;
      if (cnt > bestDowCount) {
        bestDowCount = cnt;
        bestDow = d;
      }
      if (cnt < worstDowCount) {
        worstDowCount = cnt;
        worstDow = d;
      }
    }

    /* avg orders/day — window days, or the live span when "all" */
    let earliest = Number.POSITIVE_INFINITY;
    for (const o of inRangeOrders) earliest = Math.min(earliest, new Date(o.createdAt).getTime());
    const span =
      rangeDays > 0
        ? rangeDays
        : Math.max(1, Math.ceil((Date.now() - (earliest === Number.POSITIVE_INFINITY ? Date.now() : earliest)) / 86_400_000));
    const avgPerDay = total / span;

    return {
      total,
      revenue,
      avgOrder: total > 0 ? revenue / total : 0,
      paidRate: total > 0 ? ((total - cancelled - pending) / total) * 100 : 0,
      completionRate: total > 0 ? (completed / total) * 100 : 0,
      avgPerDay,
      statusRev,
      statusCounts,
      grossValue,
      dayBuckets,
      histOrders,
      histRevenue,
      topProducts,
      uniqueCustomers,
      newThisWeek,
      topCustomers,
      hourCounts,
      peakHour,
      peakCount,
      bestDow,
      bestDowCount,
      worstDow,
      worstDowCount,
    };
  }, [inRangeOrders, orders, rangeDays, t, lang]);

  /* ---------------- model 3 — team ---------------------------------- */

  const teamModel = useMemo(() => {
    const byRole: Record<MemberRole, number> = { manager: 0, staff: 0, viewer: 0 };
    for (const m of members) {
      if (m.role === "manager" || m.role === "staff" || m.role === "viewer") byRole[m.role] += 1;
    }
    let newest: TeamMemberDTO | null = null;
    for (const m of members) {
      if (!newest || new Date(m.createdAt) > new Date(newest.createdAt)) newest = m;
    }
    return { byRole, total: members.length, newest };
  }, [members]);

  /* ---------------- model 4 — wallet -------------------------------- */

  const walletModel = useMemo(() => {
    const txns: WalletTxnDTO[] = walletQuery.data?.txns ?? [];
    let inMinor = 0;
    let outMinor = 0;
    for (const tx of txns) {
      if (tx.amountMinor > 0) inMinor += tx.amountMinor;
      else outMinor += -tx.amountMinor;
    }
    return {
      balanceMinor: walletQuery.data?.balanceMinor ?? 0,
      totalInMinor: inMinor,
      totalOutMinor: outMinor,
      txnCount: txns.length,
    };
  }, [walletQuery.data]);

  /* ---------------- model 5 — expense analytics (TASK H, R150) -------
   * The expenses module is universal (every system carries it via
   * systemMods()), so this query is safe on every workspace. */

  const expensesQuery = useQuery({
    queryKey: ["module-records", instance.id, "expenses"],
    queryFn: () => fetchModuleRecords(instance.id, "expenses"),
    staleTime: 30_000,
    retry: 0,
  });

  /* The deterministic DEMO dataset — matches what the module workspace
   * renders on its «العرض التوضيحي» tab. When real rows exist they
   * TAKE OVER (no double-count); otherwise the demo set drives the
   * analytics (the page-level provenance chip already labels the
   * whole view as «أرقام عرض توضيحي»). */
  const demoExpenses = useMemo(
    () => buildModuleDataset(instance.id, "expenses", lang, stats.currency ?? "$", instance.systemId),
    [instance.id, instance.systemId, lang, stats.currency],
  ) as ModuleDataset;

  const expenseModel = useMemo(() => {
    /* the grossAmount/netAmount/category/vendor/revenueSource cols live
     * at fixed indices in the new expenses preset (TASK G); resolve them
     * by key so a future preset reshuffle stays safe. */
    const cols = demoExpenses.cols;
    const idxOf = (key: string): number => cols.findIndex((c) => c.key === key);
    const iGross = idxOf("grossAmount");
    const iCat = idxOf("category");
    const iExp = idxOf("expense");
    const iVendor = idxOf("vendor");
    const iSrc = idxOf("revenueSource");

    /* If the preset lacks grossAmount (e.g. a third-party override),
     * bail out with an empty model — the UI renders the empty state. */
    if (iGross < 0) {
      return {
        ready: false as const,
        rows: [] as { label: string; vendor: string; source: string; amount: number; category: string }[],
        total: 0,
        byCategory: [] as { label: string; value: number; share: number }[],
        revenue: revenueModel.sum,
        netIncome: revenueModel.sum,
        ratio: 0,
      };
    }

    const realRows = expensesQuery.data ?? [];
    /* ROUND 166 — DEMO LIFECYCLE: the deterministic showcase rows drive the
     * model ONLY while prefs.demo is enabled; retired → real rows alone
     * (totals zero out and the documented empty states take over). */
    const demoEnabled = instance.prefs.demo !== false;
    const source = realRows.length > 0 ? "real" : demoEnabled ? "demo" : "none";

    /* the value cell on every row (grossAmount for real + demo). Real
     * rows have `values` aligned to the preset's cols (validated at
     * POST/PATCH time server-side). */
    const expanded = (realRows.length > 0 ? realRows : demoEnabled ? demoExpenses.rows : []).map((r) => {
      const amount = Number(r.values[iGross] ?? 0) || 0;
      return {
        label: iExp >= 0 ? (r.values[iExp] ?? "").trim() || "—" : "—",
        vendor: iVendor >= 0 ? (r.values[iVendor] ?? "").trim() || "—" : "—",
        source: iSrc >= 0 ? (r.values[iSrc] ?? "").trim() || "—" : "—",
        category: iCat >= 0 ? (r.values[iCat] ?? "").trim() || "—" : "—",
        amount,
      };
    });

    const total = expanded.reduce((s, r) => s + r.amount, 0);

    /* breakdown by category — sorted desc by amount */
    const catMap = new Map<string, number>();
    for (const r of expanded) {
      catMap.set(r.category, (catMap.get(r.category) ?? 0) + r.amount);
    }
    const byCategory = [...catMap.entries()]
      .map(([label, value]) => ({
        label,
        value: Math.round(value * 100) / 100,
        share: total > 0 ? Math.round((value / total) * 1000) / 10 : 0,
      }))
      .sort((a, b) => b.value - a.value);

    const revenue = revenueModel.sum;
    const netIncome = revenue - total;
    const ratio = revenue > 0 ? (total / revenue) * 100 : 0;

    return {
      ready: true as const,
      source,
      rows: expanded,
      total,
      byCategory,
      revenue,
      netIncome,
      ratio,
    };
    /* instance.prefs.demo rides along: toggling «بيانات تجريبية» in
       settings refetches the instance and re-derives the model. */
  }, [demoExpenses, expensesQuery.data, revenueModel.sum, instance.prefs.demo]);

  /* ---------------- small view helpers ------------------------------ */

  const pctText = (v: number): string =>
    `${fmtNum(Math.round(v * 10) / 10, lang)}${lang === "ar" ? "٪" : "%"}`;

  const dowName = (d: number): string => {
    if (d < 0) return "—";
    try {
      /* 2024-01-07 is a Sunday — index 0 of the JS week */
      return new Intl.DateTimeFormat(intlLocale(lang), { weekday: "long" }).format(new Date(2024, 0, 7 + d));
    } catch {
      return "—";
    }
  };

  const hourLabel =
    ordersModel.peakHour >= 0
      ? `${pad2(ordersModel.peakHour)}:00 – ${pad2((ordersModel.peakHour + 1) % 24)}:00`
      : "—";

  const emptyState = (icon: string, text: string): ReactNode => (
    <div className="rounded-2xl border-2 border-dashed border-slate-200 p-8 text-center dark:border-white/10">
      <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
        <CatIcon name={icon} className="h-6 w-6" />
      </span>
      <p className="mx-auto mt-3 max-w-sm text-[12.5px] font-bold leading-relaxed text-slate-500 dark:text-slate-400">
        {text}
      </p>
    </div>
  );

  const errorState = (icon: string): ReactNode => (
    <div className="rounded-2xl border-2 border-dashed border-rose-200 p-8 text-center dark:border-rose-500/25">
      <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-rose-500/10 text-rose-500 dark:text-rose-300">
        <CatIcon name={icon} className="h-6 w-6" />
      </span>
      <p className="mt-3 text-[12.5px] font-bold text-rose-600 dark:text-rose-300">{t("errorText")}</p>
    </div>
  );

  const stagger = (i: number): CSSProperties => ({ "--i": i }) as CSSProperties;

  /* ---------------- provenance chip ---------------------------------- */

  const provenanceChip = (
    <span
      title={stats.demo ? t("anDemoNote") : t("anRealNote")}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10.5px] font-extrabold",
        stats.demo
          ? "border-amber-300/70 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:bg-amber-500/10 dark:text-amber-300"
          : "border-emerald-300/70 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:bg-emerald-500/10 dark:text-emerald-300",
      )}
    >
      <CatIcon name={stats.demo ? "eye" : "circle-check"} className="h-3 w-3 shrink-0" />
      <span className="truncate">{stats.demo ? t("anDemoNote") : t("anRealNote")}</span>
    </span>
  );

  /* ---------------- KPI 1 — MoM growth chip -------------------------- */

  const mom = revenueModel.mom;
  const growthChip =
    mom === null ? null : (
      <span
        title={`${t("anGrowthLabel")} — ${mom >= 0 ? t("anGrowthUp") : t("anGrowthDown")}`}
        className={cn(
          "inline-flex w-fit cursor-default items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-extrabold transition-transform duration-200 hover:scale-105 active:scale-95",
          mom >= 0
            ? "bg-emerald-500/10 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-300"
            : "bg-rose-500/10 text-rose-600 dark:bg-rose-500/10 dark:text-rose-300",
        )}
      >
        <CatIcon name={mom >= 0 ? "trending-up" : "trending-down"} className="h-[10px] w-[10px] shrink-0" />
        <span dir={numDir(lang)} className="tabular-nums">
          {mom >= 0 ? "+" : "−"}
          {fmtNum(Math.abs(Math.round(mom * 10) / 10), lang)}
          {lang === "ar" ? "٪" : "%"}
        </span>
      </span>
    );

  /* ---------------- shared legend row (donuts) ----------------------- */

  const legendRows = (entries: DonutEntry[], total: number, format: (v: number) => string): ReactNode => (
    <ul className="mt-3 max-h-44 space-y-1.5 overflow-y-auto pe-1 nice-scroll">
      {entries.map((e) => (
        <li key={e.key} className="flex items-center gap-2.5 rounded-xl p-1 transition hover:bg-slate-50 dark:hover:bg-white/5">
          <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: e.color }} aria-hidden="true" />
          <span className="min-w-0 flex-1 truncate text-[11.5px] font-bold text-slate-600 dark:text-slate-300">
            {e.label}
          </span>
          <span dir={numDir(lang)} className="shrink-0 tabular-nums text-[11px] font-extrabold text-slate-700 dark:text-slate-200">
            {format(e.value)}
          </span>
          <span dir={numDir(lang)} className="shrink-0 tabular-nums text-[10px] font-bold text-slate-400 dark:text-slate-500">
            {pctText(total > 0 ? (e.value / total) * 100 : 0)}
          </span>
        </li>
      ))}
    </ul>
  );

  /* ================================================================ */

  return (
    <div className="space-y-5">
      {/* heading + data-provenance chip (honesty law) */}
      <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2">
        <ViewHeading title={t("dashAnalyticsTitle")} desc={t("dashAnalyticsDesc")} />
        <span className="mt-1.5 shrink-0">{provenanceChip}</span>
      </div>

      {/* premium AI insights (deep analysis of this workspace) */}
      <AiInsightsPanel instanceId={instance.id} />

      {/* range selector — filters the orders-derived surfaces; the 12-month
          revenue series is labeled as always-all-time on its card */}
      <div className="card-in flex flex-wrap items-center justify-between gap-3" style={stagger(1)}>
        <div
          role="group"
          aria-label={t("anChartOrders")}
          className="inline-flex h-10 items-center gap-1 rounded-xl border border-slate-200 bg-white/70 p-1 dark:border-white/10 dark:bg-white/[0.04]"
        >
          {RANGES.map((r) => {
            const active = range === r.key;
            return (
              <button
                key={r.key}
                type="button"
                aria-pressed={active}
                onClick={() => setRange(r.key)}
                className={cn(
                  "h-8 rounded-lg px-3 text-[12px] font-extrabold transition-all duration-200 active:scale-95",
                  active
                    ? "text-white shadow-md"
                    : "text-slate-500 hover:bg-slate-100 hover:text-slate-700 dark:text-slate-400 dark:hover:bg-white/10 dark:hover:text-slate-200",
                )}
                style={active ? { backgroundImage: grad(c1, c2) } : undefined}
              >
                {t(r.labelKey)}
              </button>
            );
          })}
        </div>
        <span className="inline-flex items-center gap-1.5 text-[11px] font-bold text-slate-400 dark:text-slate-500">
          <CatIcon name="calendar" className="h-3.5 w-3.5 shrink-0" />
          {t("anMonthlyRevenue")} · {t("anRangeAll")}
        </span>
      </div>

      {/* KPI micro-header */}
      <div className="card-in flex items-center gap-2.5" style={stagger(2)}>
        <span
          className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-white"
          style={{ backgroundImage: grad(c1, c2) }}
          aria-hidden="true"
        >
          <CatIcon name="chart-line" className="h-3.5 w-3.5" />
        </span>
        <h2 className={cn("text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
          {t("anInsightTitle")}
        </h2>
      </div>

      {/* KPI strip 1 — the golden 12-month revenue law */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5" style={stagger(2)}>
        <StatCard
          size="golden"
          label={t("anTotalRevenue")}
          value={money(revenueModel.sum)}
          chip={growthChip}
          tone={mom === null ? undefined : mom >= 0 ? "up" : "down"}
          icon="wallet"
          c1={c1}
          c2={c2}
          index={0}
        />
        <StatCard
          size="golden"
          label={t("anAvgMonthly")}
          value={money(Math.round(revenueModel.avg))}
          icon="target"
          c1="#10b981"
          c2="#047857"
          index={1}
        />
        <StatCard
          size="golden"
          label={t("anBestMonth")}
          value={money(revenueModel.best?.value ?? 0)}
          sub={revenueModel.best?.label}
          icon="trending-up"
          c1="#f59e0b"
          c2="#d97706"
          index={2}
        />
        <StatCard
          size="golden"
          label={t("dashKpiUsers")}
          value={fmtNum(stats.users, lang)}
          sub={
            ordersQuery.isSuccess && ordersModel.uniqueCustomers > 0
              ? `${fmtNum(ordersModel.uniqueCustomers, lang)} · ${t("anChartCustomers")}`
              : undefined
          }
          icon="users"
          c1="#8b5cf6"
          c2="#7c3aed"
          index={3}
        />
        <StatCard
          size="golden"
          label={t("dashKpiUptime")}
          value={`${fmtNum(stats.uptime, lang)}%`}
          icon="shield-check"
          c1="#06b6d4"
          c2="#0891b2"
          index={4}
          ltrValue
        />
      </div>

      {/* KPI strip 2 — orders-driven (only while loading or with orders) */}
      {(ordersQuery.isPending || hasOrders) && (
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5" style={stagger(3)}>
          <StatCard
            size="golden"
            label={t("anOrdersKpi")}
            numeric={ordersQuery.isPending ? undefined : ordersModel.total}
            loading={ordersQuery.isPending}
            sub={
              ordersQuery.isPending
                ? undefined
                : `${fmtNum(Math.round(ordersModel.avgPerDay * 10) / 10, lang)} / ${lang === "ar" ? "يوم" : "day"}`
            }
            tone="up"
            icon="shopping-bag"
            c1="#f59e0b"
            c2="#d97706"
            index={0}
          />
          <StatCard
            size="golden"
            label={t("anAvgOrder")}
            loading={ordersQuery.isPending}
            value={
              ordersQuery.isPending ? undefined : (
                <span dir={numDir(lang)} className="tabular-nums">
                  {fmtMoneyCell(Math.round(ordersModel.avgOrder * 100) / 100, lang, orderCur)}
                </span>
              )
            }
            icon="receipt"
            c1="#10b981"
            c2="#047857"
            index={1}
          />
          <StatCard
            size="golden"
            label={t("anPaidRate")}
            loading={ordersQuery.isPending}
            value={ordersQuery.isPending ? undefined : pctText(ordersModel.paidRate)}
            tone={ordersModel.paidRate >= 50 ? "up" : "down"}
            icon="percent"
            c1="#06b6d4"
            c2="#0891b2"
            index={2}
            ltrValue
          />
          <StatCard
            size="golden"
            label={t("anCompletionRate")}
            loading={ordersQuery.isPending}
            value={ordersQuery.isPending ? undefined : pctText(ordersModel.completionRate)}
            tone={ordersModel.completionRate >= 50 ? "up" : "down"}
            icon="zap"
            c1="#8b5cf6"
            c2="#7c3aed"
            index={3}
            ltrValue
          />
          <StatCard
            size="golden"
            label={t("anRevenuePerUser")}
            loading={ordersQuery.isPending}
            value={
              ordersQuery.isPending ? undefined : (
                <span dir={numDir(lang)} className="tabular-nums">
                  {money(Math.round(stats.users > 0 ? revenueModel.sum / stats.users : 0))}
                </span>
              )
            }
            icon="coins"
            c1="#d946ef"
            c2="#c026d3"
            index={4}
          />
        </div>
      )}

      {/* main chart — revenue area + 3-month moving average + streak &
          next-month least-squares forecast chips */}
      <div style={stagger(4)}>
        <DashCard
          title={t("anMonthlyRevenue")}
          icon="chart-column"
          action={
            <div className="flex flex-wrap items-center justify-end gap-1.5">
              <span
                title={t("anStreakLabel")}
                className="inline-flex items-center gap-1 rounded-full border border-emerald-200/70 bg-emerald-500/10 px-2.5 py-1 text-[10.5px] font-extrabold text-emerald-600 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300"
              >
                <CatIcon name="trending-up" className="h-3 w-3 shrink-0" />
                {t("anStreakLabel")}
                <span dir={numDir(lang)} className="tabular-nums">
                  {fmtNum(revenueModel.streak, lang)}
                </span>
              </span>
              <span
                title={t("anForecastNext")}
                className="inline-flex items-center gap-1 rounded-full border border-amber-200/70 bg-amber-500/10 px-2.5 py-1 text-[10.5px] font-extrabold text-amber-600 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-300"
              >
                <CatIcon name="sparkles" className="h-3 w-3 shrink-0" />
                {t("anForecastNext")}
                <span dir={numDir(lang)} className="tabular-nums">
                  {money(Math.round(revenueModel.forecast))}
                </span>
              </span>
            </div>
          }
        >
          {/* custom series legend — area / dashed MA */}
          <div className="mb-3 flex flex-wrap items-center gap-x-4 gap-y-1.5">
            <span className="inline-flex items-center gap-1.5 text-[11px] font-bold text-slate-500 dark:text-slate-400">
              <span className="h-2.5 w-2.5 rounded-full" style={{ background: c1 }} aria-hidden="true" />
              {t("anChartRevenue")}
            </span>
            <span className="inline-flex items-center gap-1.5 text-[11px] font-bold text-slate-500 dark:text-slate-400">
              <span
                className="h-0 w-5 rounded-full border-t-2 border-dashed"
                style={{ borderColor: "#d946ef" }}
                aria-hidden="true"
              />
              {t("anRevenueTrend")}
            </span>
          </div>
          <div dir="ltr" className="h-[320px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={revenueModel.chartData} margin={{ top: 12, right: 8, bottom: 0, left: 0 }}>
                <defs>
                  <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={c1} stopOpacity={0.18} />
                    <stop offset="100%" stopColor={c1} stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 6" stroke="rgba(148,163,184,0.25)" vertical={false} />
                <XAxis
                  dataKey="label"
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontSize: 10, fill: "currentColor" }}
                  className="text-slate-400"
                  interval="preserveStartEnd"
                />
                <YAxis
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontSize: 10, fill: "currentColor" }}
                  className="text-slate-400"
                  tickFormatter={(v: number) => `${Math.round(v / 1000)}k`}
                  width={34}
                />
                <Tooltip
                  contentStyle={CHART_TOOLTIP_STYLE}
                  cursor={{ stroke: "rgba(148,163,184,0.35)" }}
                  formatter={(value, name) => [
                    money(Number(value)),
                    String(name) === "ma" ? t("anRevenueTrend") : t("dashKpiRevenue"),
                  ]}
                />
                <Area
                  type="monotone"
                  dataKey="value"
                  stroke={c1}
                  strokeWidth={2.5}
                  fill={`url(#${gradId})`}
                  activeDot={{ r: 4, fill: c1 }}
                />
                <Line
                  type="monotone"
                  dataKey="ma"
                  stroke="#d946ef"
                  strokeWidth={2}
                  strokeDasharray="6 6"
                  dot={false}
                  connectNulls={false}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </DashCard>
      </div>

      {/* 14-day orders histogram + the customers panel */}
      <div className="grid gap-4 lg:grid-cols-3" style={stagger(5)}>
        <DashCard
          title={t("anChartOrders")}
          icon="chart-column"
          className="lg:col-span-2"
          action={
            ordersQuery.isError ? (
              <span className="inline-flex items-center gap-1 rounded-full bg-rose-500/10 px-2.5 py-1 text-[10.5px] font-extrabold text-rose-600 dark:text-rose-300">
                <CatIcon name="info" className="h-3 w-3 shrink-0" />
                {t("errorText")}
              </span>
            ) : null
          }
        >
          {ordersQuery.isPending ? (
            <Skeleton className="h-72 w-full rounded-2xl" />
          ) : ordersQuery.isError ? (
            errorState("shopping-bag")
          ) : orders.length === 0 ? (
            emptyState("shopping-bag", t("anNoOrderData"))
          ) : (
            <>
              <div dir="ltr" className="h-[240px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={ordersModel.dayBuckets} margin={{ top: 12, right: 8, bottom: 0, left: 0 }}>
                    <CartesianGrid strokeDasharray="3 6" stroke="rgba(148,163,184,0.25)" vertical={false} />
                    <XAxis
                      dataKey="label"
                      tickLine={false}
                      axisLine={false}
                      tick={{ fontSize: 9.5, fill: "currentColor" }}
                      className="text-slate-400"
                      interval={0}
                    />
                    <YAxis
                      tickLine={false}
                      axisLine={false}
                      tick={{ fontSize: 10, fill: "currentColor" }}
                      className="text-slate-400"
                      allowDecimals={false}
                      width={28}
                    />
                    <Tooltip
                      contentStyle={CHART_TOOLTIP_STYLE}
                      cursor={{ fill: "rgba(148,163,184,0.12)" }}
                      labelFormatter={(label: string, payload: Array<{ payload?: { full?: string } }>) =>
                        payload[0]?.payload?.full ?? label
                      }
                      formatter={(value, _name, item) => {
                        const rev = Math.round(Number(item?.payload?.revenue ?? 0));
                        return [
                          `${fmtNum(Number(value), lang)} · ${fmtMoneyCell(rev, lang, orderCur)}`,
                          t("anChartOrders"),
                        ];
                      }}
                    />
                    <Bar dataKey="orders" radius={[6, 6, 0, 0]} maxBarSize={26}>
                      {ordersModel.dayBuckets.map((b) => (
                        <Cell key={b.key} fill={b.isToday ? c1 : hexAlpha("#10b981", 0.72)} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
              {/* window footer — 14-day totals */}
              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-xl bg-slate-50/80 px-3.5 py-2.5 dark:bg-white/[0.03]">
                <span className="inline-flex items-center gap-1.5 text-[11px] font-bold text-slate-500 dark:text-slate-400">
                  <CatIcon name="shopping-bag" className="h-3.5 w-3.5 shrink-0 text-slate-400" />
                  {t("anChartOrders")}: {fmtNum(ordersModel.histOrders, lang)}
                </span>
                <span dir={numDir(lang)} className="font-display text-[13px] font-black tabular-nums text-slate-900 dark:text-white">
                  {fmtMoneyCell(Math.round(ordersModel.histRevenue), lang, orderCur)}
                </span>
              </div>
            </>
          )}
        </DashCard>

        {/* customers — unique actives, new this week, top-3 */}
        <DashCard title={t("anChartCustomers")} icon="user-round">
          {ordersQuery.isPending ? (
            <Skeleton className="h-72 w-full rounded-2xl" />
          ) : ordersQuery.isError ? (
            errorState("user-round")
          ) : ordersModel.uniqueCustomers === 0 ? (
            emptyState("user-round", t("anNoOrderData"))
          ) : (
            <>
              <div className="flex items-center justify-between gap-3 rounded-2xl border border-slate-200/80 bg-white/60 p-3 dark:border-white/10 dark:bg-white/[0.03]">
                <div className="min-w-0">
                  <p
                    className={cn(
                      "text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500",
                      labelTrack(lang),
                    )}
                  >
                    {t("anActiveUsers")}
                  </p>
                  <p dir={numDir(lang)} className="mt-0.5 font-display text-2xl font-black tabular-nums text-slate-900 dark:text-white">
                    {fmtNum(ordersModel.uniqueCustomers, lang)}
                  </p>
                </div>
                {ordersModel.newThisWeek > 0 ? (
                  <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-emerald-500/10 px-2.5 py-1 text-[10.5px] font-extrabold text-emerald-600 dark:text-emerald-300">
                    <CatIcon name="sparkles" className="h-3 w-3 shrink-0" />
                    <span dir={numDir(lang)} className="tabular-nums">
                      +{fmtNum(ordersModel.newThisWeek, lang)}
                    </span>
                    {lang === "ar" ? "هذا الأسبوع" : "this week"}
                  </span>
                ) : null}
              </div>
              <ul className="mt-3 space-y-2">
                {ordersModel.topCustomers.map((cst, i) => (
                  <li key={`${cst.name}-${i}`} className="flex items-center gap-3">
                    <span
                      className="grid h-6 w-6 shrink-0 place-items-center rounded-lg text-[10.5px] font-extrabold text-white tabular-nums"
                      style={{ backgroundImage: grad(c1, c2), opacity: 1 - Math.min(i, 2) * 0.15 }}
                      aria-label={`#${i + 1}`}
                    >
                      {fmtNum(i + 1, lang)}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[12px] font-bold text-slate-700 dark:text-slate-200" title={cst.name}>
                        {cst.name}
                      </p>
                      <p dir={numDir(lang)} className="truncate text-[10.5px] font-bold tabular-nums text-slate-400 dark:text-slate-500">
                        {t("anChartOrders")}: {fmtNum(cst.orders, lang)} · {fmtMoneyCell(Math.round(cst.spend), lang, orderCur)}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            </>
          )}
        </DashCard>
      </div>

      {/* TASK H (R150) — the expense-analytics cluster (3 KPI cards +
          breakdown bars + top-5 list). The owner's directive:
          «في جميع الأنظمة عند صفحة (التحليلات) اضف المزيد من التكامل
          مع الأنظمة بدقة واضف تفاصيل المصروفات اليه باحترافية». */}
      <div className="card-in flex items-center gap-2.5" style={stagger(6)}>
        <span
          className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-white"
          style={{ backgroundImage: grad(c1, c2) }}
          aria-hidden="true"
        >
          <CatIcon name="banknote" className="h-3.5 w-3.5" />
        </span>
        <h2 className={cn("text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
          {t("analyticsExpensesTitle")}
        </h2>
        <span className="ms-auto truncate text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
          {t("analyticsExpensesDesc")}
        </span>
      </div>

      {/* KPI strip — Total Expenses · Net Income · Expense-to-Revenue Ratio */}
      <div className="grid grid-cols-1 gap-3 md:grid-cols-3" style={stagger(6)}>
        <StatCard
          size="golden"
          label={t("analyticsTotalExpenses")}
          value={
            <span dir={numDir(lang)} className="tabular-nums">
              {fmtMoneyCell(Math.round(expenseModel.total), lang, orderCur)}
            </span>
          }
          sub={t("analyticsTotalExpensesSub")}
          icon="banknote"
          c1="#f43f5e"
          c2="#be185d"
          index={0}
          ltrValue
        />
        <StatCard
          size="golden"
          label={t("analyticsNetIncome")}
          value={
            <span dir={numDir(lang)} className="tabular-nums">
              {fmtMoneyCell(Math.round(expenseModel.netIncome), lang, orderCur)}
            </span>
          }
          sub={t("analyticsNetIncomeSub")}
          tone={expenseModel.netIncome >= 0 ? "up" : "down"}
          icon={expenseModel.netIncome >= 0 ? "trending-up" : "trending-down"}
          c1={expenseModel.netIncome >= 0 ? "#10b981" : "#f43f5e"}
          c2={expenseModel.netIncome >= 0 ? "#047857" : "#be185d"}
          index={1}
          ltrValue
        />
        <StatCard
          size="golden"
          label={t("analyticsExpenseRatio")}
          value={
            <span dir={numDir(lang)} className="tabular-nums">
              {fmtNum(Math.round(expenseModel.ratio * 10) / 10, lang)}
              {lang === "ar" ? "٪" : "%"}
            </span>
          }
          sub={t("analyticsExpenseRatioSub")}
          tone={expenseModel.ratio <= 60 ? "up" : "down"}
          icon="scale"
          c1="#8b5cf6"
          c2="#7c3aed"
          index={2}
          ltrValue
        />
      </div>

      {/* Expense Breakdown by category + Top Expenses list */}
      <div className="grid gap-4 lg:grid-cols-3" style={stagger(6)}>
        <DashCard
          title={t("analyticsExpenseBreakdown")}
          icon="chart-pie"
          action={
            <span className="rounded-full border border-slate-200 bg-slate-50 px-2.5 py-0.5 text-[10.5px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
              {t("bizByValue")}
            </span>
          }
          className="lg:col-span-2"
        >
          {expenseModel.byCategory.length === 0 ? (
            <p className="py-6 text-center text-[12px] font-semibold text-slate-400">{t("analyticsExpenseNoData")}</p>
          ) : (
            <div className="space-y-3">
              {expenseModel.byCategory.slice(0, 8).map((entry, i) => {
                const width = expenseModel.total > 0 ? Math.max(4, Math.round((entry.value / expenseModel.total) * 100)) : 0;
                return (
                  <div key={`${entry.label}-${i}`} className="group">
                    <div className="mb-1 flex items-baseline justify-between gap-3">
                      <span className="min-w-0 truncate text-[12px] font-bold text-slate-700 dark:text-slate-200">{entry.label}</span>
                      <span dir={numDir(lang)} className="shrink-0 tabular-nums text-[11.5px] font-extrabold text-slate-500 dark:text-slate-400">
                        {fmtMoneyCell(entry.value, lang, orderCur)}
                        <span className="ms-1.5 text-slate-400">({fmtNum(entry.share, lang)}{lang === "ar" ? "٪" : "%"})</span>
                      </span>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-slate-100 dark:bg-white/10">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${width}%`,
                          backgroundImage: i === 0 ? grad(c1, c2) : grad(hexAlpha(c1, 0.75), hexAlpha(c2, 0.75)),
                          opacity: 1 - Math.min(i, 5) * 0.11,
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </DashCard>

        <DashCard title={t("analyticsTopExpenses")} icon="trophy">
          {expenseModel.rows.length === 0 ? (
            <p className="py-4 text-center text-[12px] font-semibold text-slate-400">{t("analyticsExpenseNoData")}</p>
          ) : (
            <div className="space-y-2.5">
              {[...expenseModel.rows]
                .sort((a, b) => b.amount - a.amount)
                .slice(0, 5)
                .map((row, i) => {
                  const max = expenseModel.rows[0] ? Math.max(...expenseModel.rows.map((r) => r.amount)) : 1;
                  const width = max > 0 ? Math.max(6, Math.round((row.amount / max) * 100)) : 0;
                  return (
                    <div key={`${row.label}-${i}`} className="flex items-center gap-3">
                      <span
                        className="grid h-6 w-6 shrink-0 place-items-center rounded-lg text-[10.5px] font-extrabold text-white tabular-nums"
                        style={{ backgroundImage: grad(c1, c2), opacity: 1 - Math.min(i, 4) * 0.15 }}
                        aria-label={`#${i + 1}`}
                      >
                        {fmtNum(i + 1, lang)}
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-baseline justify-between gap-2">
                          <p className="min-w-0 truncate text-[11.5px] font-bold text-slate-700 dark:text-slate-200" title={row.label}>
                            {row.label}
                          </p>
                          <span dir={numDir(lang)} className="shrink-0 text-[10.5px] font-extrabold tabular-nums text-slate-500 dark:text-slate-400">
                            {fmtMoneyCell(Math.round(row.amount), lang, orderCur)}
                          </span>
                        </div>
                        <p dir={numDir(lang)} className="truncate text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                          {row.vendor} · {row.source}
                        </p>
                        <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-slate-100 dark:bg-white/10">
                          <div className="h-full rounded-full" style={{ width: `${width}%`, backgroundImage: grad(c1, c2), opacity: 0.85 }} />
                        </div>
                      </div>
                    </div>
                  );
                })}
            </div>
          )}
        </DashCard>
      </div>

      {/* Revenue vs Expenses comparison strip — the donut-style dual bar */}
      <DashCard title={t("analyticsRevenueVsExpenses")} icon="scale" >
        {expenseModel.total === 0 ? (
          <p className="py-4 text-center text-[12px] font-semibold text-slate-400">{t("analyticsExpenseNoData")}</p>
        ) : (
          <div className="space-y-3">
            {/* the dual horizontal split: revenue (emerald) · expenses (rose) */}
            <div
              className="flex h-9 w-full overflow-hidden rounded-2xl"
              role="img"
              aria-label={`${t("analyticsRevenueVsExpenses")}: ${fmtNum(expenseModel.revenue > 0 ? 100 - expenseModel.ratio : 0, lang)}${lang === "ar" ? "٪" : "%"} / ${fmtNum(expenseModel.ratio, lang)}${lang === "ar" ? "٪" : "%"}`}
            >
              <div
                className="flex items-center justify-center"
                style={{
                  width: `${Math.max(0, Math.min(100, 100 - expenseModel.ratio))}%`,
                  backgroundImage: grad("#10b981", "#047857"),
                }}
              >
                <span dir={numDir(lang)} className="text-[11px] font-black tabular-nums text-white">
                  {fmtNum(Math.round((100 - expenseModel.ratio) * 10) / 10, lang)}{lang === "ar" ? "٪" : "%"}
                </span>
              </div>
              <div
                className="flex items-center justify-center"
                style={{
                  width: `${Math.max(0, Math.min(100, expenseModel.ratio))}%`,
                  backgroundImage: grad("#f43f5e", "#be185d"),
                }}
              >
                <span dir={numDir(lang)} className="text-[11px] font-black tabular-nums text-white">
                  {fmtNum(Math.round(expenseModel.ratio * 10) / 10, lang)}{lang === "ar" ? "٪" : "%"}
                </span>
              </div>
            </div>
            {/* legend rows */}
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-xl border border-slate-100 bg-white/60 p-2.5 dark:border-white/[0.06] dark:bg-white/[0.03]">
                <p className={cn("text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                  {t("dashKpiRevenue")}
                </p>
                <p dir={numDir(lang)} className="mt-0.5 font-display text-[14px] font-black tabular-nums text-emerald-600 dark:text-emerald-400">
                  {fmtMoneyCell(Math.round(expenseModel.revenue), lang, orderCur)}
                </p>
              </div>
              <div className="rounded-xl border border-slate-100 bg-white/60 p-2.5 dark:border-white/[0.06] dark:bg-white/[0.03]">
                <p className={cn("text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                  {t("analyticsTotalExpenses")}
                </p>
                <p dir={numDir(lang)} className="mt-0.5 font-display text-[14px] font-black tabular-nums text-rose-600 dark:text-rose-400">
                  {fmtMoneyCell(Math.round(expenseModel.total), lang, orderCur)}
                </p>
              </div>
            </div>
            {/* net income footer */}
            <div className="flex items-center justify-between rounded-xl bg-slate-50/80 px-3.5 py-2.5 dark:bg-white/[0.03]">
              <span className="inline-flex items-center gap-1.5 text-[11px] font-bold text-slate-500 dark:text-slate-400">
                <CatIcon name={expenseModel.netIncome >= 0 ? "trending-up" : "trending-down"} className="h-3.5 w-3.5 shrink-0 text-slate-400" />
                {t("analyticsNetIncome")}
              </span>
              <span
                dir={numDir(lang)}
                className={cn(
                  "font-display text-[13px] font-black tabular-nums",
                  expenseModel.netIncome >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-rose-600 dark:text-rose-400",
                )}
              >
                {fmtMoneyCell(Math.round(expenseModel.netIncome), lang, orderCur)}
              </span>
            </div>
          </div>
        )}
      </DashCard>

      {/* twin donuts — revenue distribution + orders by status */}
      <div className="grid gap-4 lg:grid-cols-2" style={stagger(8)}>
        <DashCard title={t("anRevenueDistribution")} icon="chart-pie">
          {ordersQuery.isPending ? (
            <Skeleton className="h-72 w-full rounded-2xl" />
          ) : ordersQuery.isError || ordersModel.statusRev.length === 0 ? (
            emptyState("chart-pie", t("anNoOrderData"))
          ) : (
            <>
              <div dir="ltr" className="relative h-52 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={ordersModel.statusRev}
                      dataKey="value"
                      nameKey="label"
                      innerRadius="62%"
                      outerRadius="85%"
                      paddingAngle={3}
                      strokeWidth={0}
                    >
                      {ordersModel.statusRev.map((e) => (
                        <Cell key={e.key} fill={e.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={CHART_TOOLTIP_STYLE}
                      formatter={(value) => [fmtMoneyCell(Number(value), lang, orderCur), ""]}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <div className="pointer-events-none absolute inset-0 grid place-items-center">
                  <div className="text-center">
                    <p dir={numDir(lang)} className="font-display text-lg font-black tabular-nums text-slate-900 dark:text-white">
                      {fmtMoneyCell(ordersModel.grossValue, lang, orderCur)}
                    </p>
                    <p className={cn("mt-0.5 text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {t("anChartRevenue")}
                    </p>
                  </div>
                </div>
              </div>
              {legendRows(ordersModel.statusRev, ordersModel.grossValue, (v) => fmtMoneyCell(v, lang, orderCur))}
            </>
          )}
        </DashCard>

        <DashCard title={t("anOrdersByStatus")} icon="chart-pie">
          {ordersQuery.isPending ? (
            <Skeleton className="h-72 w-full rounded-2xl" />
          ) : ordersQuery.isError || ordersModel.statusCounts.length === 0 ? (
            emptyState("chart-pie", t("anNoOrderData"))
          ) : (
            <>
              <div dir="ltr" className="relative h-52 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={ordersModel.statusCounts}
                      dataKey="value"
                      nameKey="label"
                      innerRadius="62%"
                      outerRadius="85%"
                      paddingAngle={3}
                      strokeWidth={0}
                    >
                      {ordersModel.statusCounts.map((e) => (
                        <Cell key={e.key} fill={e.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={CHART_TOOLTIP_STYLE}
                      formatter={(value) => [fmtNum(Number(value), lang), ""]}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <div className="pointer-events-none absolute inset-0 grid place-items-center">
                  <div className="text-center">
                    <p dir={numDir(lang)} className="font-display text-lg font-black tabular-nums text-slate-900 dark:text-white">
                      {fmtNum(ordersModel.total, lang)}
                    </p>
                    <p className={cn("mt-0.5 text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {t("anChartOrders")}
                    </p>
                  </div>
                </div>
              </div>
              {legendRows(ordersModel.statusCounts, ordersModel.total, (v) => fmtNum(v, lang))}
            </>
          )}
        </DashCard>
      </div>

      {/* top products · team activity · module usage */}
      <div className="grid gap-4 lg:grid-cols-3" style={stagger(8)}>
        <DashCard title={t("anTopProducts")} icon="shopping-bag">
          {ordersQuery.isPending ? (
            <div className="space-y-2.5">
              {[0, 1, 2, 3, 4].map((i) => (
                <Skeleton key={i} className="h-12 w-full rounded-2xl" />
              ))}
            </div>
          ) : !hasOrders || ordersModel.topProducts.length === 0 ? (
            emptyState("boxes", t("anNoOrderData"))
          ) : (
            <div className="space-y-2.5">
              {ordersModel.topProducts.map((line, i) => {
                const max = ordersModel.topProducts[0]?.revenue ?? 1;
                const share = max > 0 ? Math.max(6, Math.round((line.revenue / max) * 100)) : 0;
                return (
                  <div key={`${line.name}-${i}`} className="flex items-center gap-3">
                    <span
                      className="grid h-7 w-7 shrink-0 place-items-center rounded-lg font-display text-[12px] font-black text-white tabular-nums"
                      style={{ backgroundImage: grad(c1, c2), opacity: 1 - Math.min(i, 4) * 0.15 }}
                      aria-label={`#${i + 1}`}
                    >
                      {fmtNum(i + 1, lang)}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-baseline justify-between gap-2">
                        <p className="min-w-0 truncate text-[12px] font-bold text-slate-700 dark:text-slate-200" title={line.name}>
                          {line.name}
                        </p>
                        <span dir={numDir(lang)} className="shrink-0 text-[11px] font-extrabold tabular-nums text-emerald-600 dark:text-emerald-400">
                          {fmtMoneyCell(Math.round(line.revenue), lang, orderCur)}
                        </span>
                      </div>
                      <div className="mt-1.5 flex items-center gap-2">
                        <MeterBar value={share} color={grad(c1, c2)} />
                        <span dir={numDir(lang)} className="shrink-0 text-[10px] font-extrabold tabular-nums text-slate-400 dark:text-slate-500">
                          ×{fmtNum(line.qty, lang)}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
              <div className="flex items-center justify-between rounded-xl bg-slate-50/80 px-3.5 py-2.5 dark:bg-white/[0.03]">
                <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400">{t("anChartOrders")}</span>
                <span dir={numDir(lang)} className="font-display text-[13px] font-black tabular-nums text-slate-900 dark:text-white">
                  {fmtMoneyCell(Math.round(ordersModel.revenue), lang, orderCur)}
                </span>
              </div>
            </div>
          )}
        </DashCard>

        <DashCard
          title={t("anTeamActivity")}
          icon="users"
          action={
            membersQuery.isSuccess ? (
              <span dir={numDir(lang)} className="rounded-full border border-slate-200 bg-slate-50 px-2.5 py-0.5 text-[10.5px] font-extrabold tabular-nums text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
                {fmtNum(teamModel.total, lang)}
              </span>
            ) : null
          }
        >
          {membersQuery.isPending ? (
            <div className="space-y-3">
              {[0, 1, 2].map((i) => (
                <Skeleton key={i} className="h-9 w-full rounded-xl" />
              ))}
            </div>
          ) : membersQuery.isError ? (
            errorState("users")
          ) : teamModel.total === 0 ? (
            <div className="rounded-2xl border-2 border-dashed border-slate-200 p-8 text-center dark:border-white/10">
              <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
                <CatIcon name="user-round" className="h-6 w-6" />
              </span>
            </div>
          ) : (
            <div className="space-y-3">
              {(Object.keys(ROLE_KEY) as MemberRole[]).map((role) => {
                const count = teamModel.byRole[role];
                const [rc1, rc2] = ROLE_GRADIENTS[role];
                return (
                  <div key={role}>
                    <div className="mb-1 flex items-baseline justify-between gap-3">
                      <span className="min-w-0 truncate text-[11.5px] font-bold text-slate-700 dark:text-slate-200">
                        {t(ROLE_KEY[role])}
                      </span>
                      <span dir={numDir(lang)} className="shrink-0 tabular-nums text-[11px] font-extrabold text-slate-500 dark:text-slate-400">
                        {fmtNum(count, lang)}
                        <span className="ms-1.5 text-slate-400">{pctText(teamModel.total > 0 ? (count / teamModel.total) * 100 : 0)}</span>
                      </span>
                    </div>
                    <MeterBar value={teamModel.total > 0 ? (count / teamModel.total) * 100 : 0} color={grad(rc1, rc2)} />
                  </div>
                );
              })}
              {teamModel.newest ? (
                <>
                  <div className="border-t border-dashed border-slate-200 dark:border-white/10" aria-hidden="true" />
                  <div className="flex items-center gap-3 rounded-xl border border-slate-100 bg-white/60 p-2.5 dark:border-white/[0.06] dark:bg-white/[0.03]">
                    <span
                      className="grid h-9 w-9 shrink-0 place-items-center rounded-xl font-display text-[13px] font-black text-white"
                      style={{ backgroundImage: grad(c1, c2) }}
                      aria-hidden="true"
                    >
                      {initial(teamModel.newest.name)}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[12px] font-bold text-slate-700 dark:text-slate-200" title={teamModel.newest.name}>
                        {teamModel.newest.name}
                      </p>
                      <p className="truncate text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                        {t(ROLE_KEY[teamModel.newest.role as MemberRole] ?? "roleStaff")} · {relativeTime(teamModel.newest.createdAt, lang)}
                      </p>
                    </div>
                  </div>
                </>
              ) : null}
            </div>
          )}
        </DashCard>

        <DashCard title={t("anModuleUsage")} icon="boxes">
          <div className="flex items-baseline gap-2">
            <p dir={numDir(lang)} className="font-display text-3xl font-black tabular-nums text-slate-900 dark:text-white">
              {fmtNum(instance.modules.length, lang)}
            </p>
            <p dir={numDir(lang)} className="text-[11px] font-bold tabular-nums text-slate-400 dark:text-slate-500">
              / {fmtNum(Object.keys(MODULE_MAP).length, lang)}
            </p>
          </div>
          <div className="mt-2.5">
            <MeterBar value={(instance.modules.length / Math.max(1, Object.keys(MODULE_MAP).length)) * 100} color={grad(c1, c2)} />
          </div>
          <div className="mt-4 flex flex-wrap gap-1.5">
            {instance.modules.slice(0, 10).map((m) => (
              <span
                key={m}
                className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-[10.5px] font-bold text-slate-600 transition hover:border-slate-300 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:border-white/20"
                title={moduleName(m, lang)}
              >
                <CatIcon name={MODULE_MAP[m]?.icon ?? "cubes"} className="h-3 w-3 shrink-0 text-slate-400" />
                <span className="max-w-28 truncate">{moduleName(m, lang)}</span>
              </span>
            ))}
          </div>
        </DashCard>
      </div>

      {/* wallet totals · best & quietest day · peak hour */}
      <div className="grid gap-4 lg:grid-cols-3" style={stagger(9)}>
        <DashCard title={t("walletBalanceNow")} icon="wallet">
          {walletQuery.isPending ? (
            <div className="space-y-3">
              <Skeleton className="h-16 w-full rounded-2xl" />
              {[0, 1, 2].map((i) => (
                <Skeleton key={i} className="h-11 w-full rounded-xl" />
              ))}
            </div>
          ) : walletQuery.isError ? (
            errorState("wallet")
          ) : (
            <>
              <div
                className="relative overflow-hidden rounded-2xl border border-emerald-200/60 p-3.5 dark:border-emerald-500/20"
                style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha("#059669", 0.1)}, ${hexAlpha("#0f766e", 0.06)})` }}
              >
                <span
                  className="absolute -end-8 -top-10 h-24 w-24 rounded-full"
                  style={{ background: `radial-gradient(circle, ${hexAlpha("#059669", 0.25)}, transparent 70%)` }}
                  aria-hidden="true"
                />
                <div className="relative flex items-center gap-3">
                  <IconTile icon="wallet" c1="#059669" c2="#0f766e" />
                  <div className="min-w-0">
                    <p className={cn("text-[10px] font-extrabold uppercase text-emerald-600 dark:text-emerald-400", labelTrack(lang))}>
                      {t("walletBalanceNow")}
                    </p>
                    <p dir="ltr" className="mt-0.5 truncate font-display text-xl font-black tabular-nums text-slate-900 dark:text-white">
                      {fmtNum(walletModel.balanceMinor / 100, lang)} SAR
                    </p>
                  </div>
                </div>
              </div>
              <ul className="mt-3 space-y-1.5">
                <li className="flex items-center gap-2.5 rounded-xl border border-slate-100 bg-white/60 p-2.5 dark:border-white/[0.06] dark:bg-white/[0.03]">
                  <IconTile icon="trending-up" c1="#10b981" c2="#047857" size="sm" />
                  <span className="min-w-0 flex-1 truncate text-[11.5px] font-bold text-slate-600 dark:text-slate-300">
                    {t("walletTotalIn")}
                  </span>
                  <span dir="ltr" className="shrink-0 font-display text-[12.5px] font-black tabular-nums text-emerald-600 dark:text-emerald-400">
                    +{fmtNum(walletModel.totalInMinor / 100, lang)} SAR
                  </span>
                </li>
                <li className="flex items-center gap-2.5 rounded-xl border border-slate-100 bg-white/60 p-2.5 dark:border-white/[0.06] dark:bg-white/[0.03]">
                  <IconTile icon="trending-down" c1="#f43f5e" c2="#e11d48" size="sm" />
                  <span className="min-w-0 flex-1 truncate text-[11.5px] font-bold text-slate-600 dark:text-slate-300">
                    {t("walletTotalOut")}
                  </span>
                  <span dir="ltr" className="shrink-0 font-display text-[12.5px] font-black tabular-nums text-rose-600 dark:text-rose-400">
                    −{fmtNum(walletModel.totalOutMinor / 100, lang)} SAR
                  </span>
                </li>
                <li className="flex items-center gap-2.5 rounded-xl border border-slate-100 bg-white/60 p-2.5 dark:border-white/[0.06] dark:bg-white/[0.03]">
                  <IconTile icon="receipt" c1="#64748b" c2="#475569" size="sm" />
                  <span className="min-w-0 flex-1 truncate text-[11.5px] font-bold text-slate-600 dark:text-slate-300">
                    {t("walletTxnCount")}
                  </span>
                  <span dir={numDir(lang)} className="shrink-0 font-display text-[12.5px] font-black tabular-nums text-slate-700 dark:text-slate-200">
                    {fmtNum(walletModel.txnCount, lang)}
                  </span>
                </li>
              </ul>
            </>
          )}
        </DashCard>

        {/* best & quietest weekday — labeled rows (trophy / moon) */}
        <DashCard>
          {ordersQuery.isPending ? (
            <div className="space-y-3">
              {[0, 1].map((i) => (
                <Skeleton key={i} className="h-14 w-full rounded-2xl" />
              ))}
            </div>
          ) : ordersQuery.isError || ordersModel.total === 0 ? (
            emptyState("calendar", t("anNoOrderData"))
          ) : (
            <div className="space-y-2.5">
              <div className="flex items-center gap-3 rounded-2xl border border-slate-100 bg-white/60 p-3 dark:border-white/[0.06] dark:bg-white/[0.03]">
                <IconTile icon="trophy" c1="#f59e0b" c2="#d97706" size="sm" />
                <div className="min-w-0 flex-1">
                  <p className={cn("text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                    {t("anBestDay")}
                  </p>
                  <p className="truncate font-display text-[13.5px] font-extrabold text-slate-900 dark:text-white">
                    {dowName(ordersModel.bestDow)}
                  </p>
                </div>
                <span dir={numDir(lang)} className="shrink-0 rounded-lg bg-amber-500/10 px-2 py-1 font-display text-[12px] font-black tabular-nums text-amber-600 dark:text-amber-300">
                  {fmtNum(ordersModel.bestDowCount, lang)}
                </span>
              </div>
              <div className="flex items-center gap-3 rounded-2xl border border-slate-100 bg-white/60 p-3 dark:border-white/[0.06] dark:bg-white/[0.03]">
                <IconTile icon="moon" c1="#94a3b8" c2="#64748b" size="sm" />
                <div className="min-w-0 flex-1">
                  <p className={cn("text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                    {t("anWorstDay")}
                  </p>
                  <p className="truncate font-display text-[13.5px] font-extrabold text-slate-900 dark:text-white">
                    {dowName(ordersModel.worstDow)}
                  </p>
                </div>
                <span dir={numDir(lang)} className="shrink-0 rounded-lg bg-slate-500/10 px-2 py-1 font-display text-[12px] font-black tabular-nums text-slate-500 dark:text-slate-400">
                  {fmtNum(ordersModel.worstDowCount, lang)}
                </span>
              </div>
              <p className="px-1 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                {t("anChartOrders")}: {fmtNum(ordersModel.total, lang)} · {t(rangeDays === 0 ? "anRangeAll" : rangeDays === 7 ? "anRange7" : rangeDays === 30 ? "anRange30" : "anRange90")}
              </p>
            </div>
          )}
        </DashCard>

        {/* peak hour + the 24-slot hourly pulse strip */}
        <DashCard title={t("anPeakHour")} icon="activity">
          {ordersQuery.isPending ? (
            <Skeleton className="h-24 w-full rounded-2xl" />
          ) : !hasOrders || ordersModel.peakHour < 0 ? (
            emptyState("clock", t("anNoOrderData"))
          ) : (
            <>
              <div className="flex items-center gap-3">
                <IconTile icon="clock" c1={c1} c2={c2} />
                <div className="min-w-0">
                  <p dir="ltr" className="font-display text-xl font-black tabular-nums text-slate-900 dark:text-white">
                    {hourLabel}
                  </p>
                  <p dir={numDir(lang)} className="mt-0.5 text-[11px] font-bold tabular-nums text-slate-400 dark:text-slate-500">
                    {t("anChartOrders")}: {fmtNum(ordersModel.peakCount, lang)} ·{" "}
                    {pctText(ordersModel.total > 0 ? (ordersModel.peakCount / ordersModel.total) * 100 : 0)}
                  </p>
                </div>
              </div>
              <div className="mt-3" dir="ltr">
                <div
                  className="flex h-12 items-stretch gap-[3px]"
                  role="img"
                  aria-label={`${t("anPeakHour")}: ${hourLabel}`}
                >
                  {ordersModel.hourCounts.map((n, h) => (
                    <span key={h} className="flex min-w-0 flex-1 items-end" title={`${pad2(h)}:00 · ${fmtNum(n, lang)}`}>
                      <span
                        className="w-full rounded-[2px] transition-all duration-500"
                        style={{
                          height:
                            ordersModel.peakCount > 0
                              ? `${Math.max(6, Math.round((n / ordersModel.peakCount) * 100))}%`
                              : "8%",
                          background: h === ordersModel.peakHour ? c1 : hexAlpha("#94a3b8", 0.4),
                        }}
                      />
                    </span>
                  ))}
                </div>
                <div className="mt-1 flex justify-between text-[8.5px] font-extrabold text-slate-300 dark:text-slate-600">
                  <span>00:00</span>
                  <span>06:00</span>
                  <span>12:00</span>
                  <span>18:00</span>
                  <span>23:00</span>
                </div>
              </div>
            </>
          )}
        </DashCard>
      </div>

      {/* footer note — provenance reminder */}
      <div
        className="card-in flex flex-wrap items-center gap-3 rounded-2xl border border-dashed border-slate-200 bg-white/50 p-3.5 dark:border-white/10 dark:bg-white/[0.02]"
        style={stagger(10)}
      >
        <CatIcon name="info" className="h-4 w-4 shrink-0 text-slate-400" />
        <p className="min-w-0 flex-1 text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
          {stats.demo ? t("anDemoNote") : t("anRealNote")}
        </p>
        <span
          role="img"
          aria-label={stats.demo ? t("anDemoNote") : t("anRealNote")}
          title={stats.demo ? t("anDemoNote") : t("anRealNote")}
          className={cn(
            "grid h-8 w-8 shrink-0 place-items-center rounded-full border",
            stats.demo
              ? "border-amber-300/70 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300"
              : "border-emerald-300/70 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300",
          )}
        >
          <CatIcon name={stats.demo ? "eye" : "circle-check"} className="h-4 w-4" />
        </span>
      </div>
    </div>
  );
}
