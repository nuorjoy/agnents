"use client";

/**
 * Dashboard — team view (premium). ROUND 78 — the page is now TABBED:
 *  - «الفريق» (roster): role KPIs, the team-pulse card, the premium
 *    add-member CTA and the roster — debounced search + role filter, a
 *    desktop table and mobile member cards with avatars, job titles,
 *    copy-email, resend-invite, edit and remove actions.
 *  - «الأدوار والصلاحيات» (roles & permissions): the strict RBAC matrix
 *    from src/lib/permissions.ts — role cards with live member counts +
 *    the 14×4 permission matrix + the role-preview lens arm buttons
 *    (RolesPermissionsTab).
 *
 * ROUND 78 — member profiles were DELETED and REBUILT: every member row
 * and the pinned system-owner card now open the NEW premium
 * MemberProfileSheet (a full-height side sheet sliding from the reading
 * edge, with the engine-driven effective-permissions panel) — the old
 * centered TeamProfileDialog is gone. Its remove action still delegates
 * to this view's AlertDialog flow; its edit action opens TeamMemberDialog
 * (which itself gained a live permission preview under the role select).
 * Mutations invalidate the ["instance", id] query (members ride along).
 *
 * ROUND 65 — sector-aware heading (teamDisplayName — superseded in ROUND
 * 145 by the REAL organization name); the system owner pinned above the
 * roster as a gold card.
 *
 * ROUND 136 — the role-KPI strip migrated onto the unified StatCard.
 * ROUND 139 — the strip now renders THE golden inventory-page card law
 * (size="golden" inside the exact inventory grid grid-cols-2 → md:grid-cols-3
 * → xl:grid-cols-5), expanded 4 → 5 KPIs: the 30-day join cadence is promoted
 * from the total's sub-line to its own headline card (the R136-A inventory
 * pattern — the promoted number keeps its trace in the sibling sub-line:
 * the total now carries the role breakdown m/s/v). Members arrive resolved
 * via props (dashboard-app guards the query), so the cards carry no in-view
 * loading state.
 */
import { useEffect, useMemo, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { useT, type I18nKey } from "@/lib/i18n";
import type { InstanceDTO, TeamMemberDTO } from "@/lib/types";
import { intlLocale } from "@/lib/locales";
import { removeMember } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, copyText, fmtNum, grad, initial, normalizeSearch } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { DashCard, ViewHeading, dateOnly, relativeTime } from "@/components/dashboard/dash-shared";
import { useInstancePresence } from "@/components/dashboard/instance-presence-provider";
import { PresenceDot } from "@/components/shared/presence-dot";
import { StatCard } from "@/components/shared/stat-card";
import { MemberProfileSheet } from "@/components/dashboard/views/member-profile-sheet";
import { RolesPermissionsTab } from "@/components/dashboard/views/roles-permissions-tab";
import { TeamMemberDialog } from "@/components/dashboard/views/team-member-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

type Role = TeamMemberDTO["role"];
type RoleFilter = "all" | Role;

const ROLE_KEYS: Record<Role, I18nKey> = {
  manager: "roleManager",
  staff: "roleStaff",
  viewer: "roleViewer",
};

const ROLE_BADGE: Record<Role, string> = {
  manager: "bg-brand-500/15 text-brand-600 hover:bg-brand-500/15 dark:text-brand-300",
  staff: "bg-amber-500/15 text-amber-600 hover:bg-amber-500/15 dark:text-amber-400",
  viewer: "bg-slate-500/15 text-slate-600 hover:bg-slate-500/15 dark:text-slate-300",
};

/** per-role avatar gradients */
const ROLE_GRAD: Record<Role, { c1: string; c2: string }> = {
  manager: { c1: "#8b5cf6", c2: "#6d28d9" },
  staff: { c1: "#06b6d4", c2: "#0891b2" },
  viewer: { c1: "#64748b", c2: "#475569" },
};

/** members within this window are flagged as "recently joined" */
const NEW_MEMBER_DAYS = 14;

const isNewMember = (m: TeamMemberDTO): boolean =>
  Date.now() - new Date(m.createdAt).getTime() < NEW_MEMBER_DAYS * 86_400_000;

/* ---------------- row kebab actions ---------------- */

function MemberActions({
  onProfile,
  onEdit,
  onCopy,
  onResend,
  onRemove,
}: {
  onProfile: () => void;
  onEdit: () => void;
  onCopy: () => void;
  onResend: () => void;
  onRemove: () => void;
}) {
  const { t } = useT();
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-label={t("teamColActions")}
          className="grid h-9 w-9 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
        >
          <CatIcon name="ellipsis-vertical" className="h-[14px] w-[14px]" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-52">
        {/* ROUND 65 — profile view is the primary action */}
        <DropdownMenuItem onClick={onProfile}>
          <CatIcon name="id-card" className="h-4 w-4" />
          {t("teamProfileView")}
        </DropdownMenuItem>
        {/* ROUND 68 — extended edit (photo, phone, job title, birth date…) */}
        <DropdownMenuItem onClick={onEdit}>
          <CatIcon name="pencil" className="h-4 w-4" />
          {t("teamEditAction")}
        </DropdownMenuItem>
        <DropdownMenuItem onClick={onResend}>
          <CatIcon name="telegram" className="h-4 w-4" />
          {t("teamResendInvite")}
        </DropdownMenuItem>
        <DropdownMenuItem onClick={onCopy}>
          <CatIcon name="copy" className="h-4 w-4" />
          {t("teamCopyEmail")}
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem
          onClick={onRemove}
          className="text-rose-600 focus:text-rose-600 dark:text-rose-400 dark:focus:text-rose-400"
        >
          <CatIcon name="user-minus" className="h-4 w-4" />
          {t("teamRemoveTitle")}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

/* ---------------- ROUND 71 — team pulse card ---------------- */

/** SVG completeness gauge — emerald→cyan arc on a hairline track,
 *  animated stroke so the ring fills on mount (premium detail). */
function PulseRing({ pct, label }: { pct: number; label: string }) {
  const R = 26;
  const C = 2 * Math.PI * R;
  return (
    <div className="relative grid h-[76px] w-[76px] shrink-0 place-items-center">
      <svg viewBox="0 0 64 64" className="h-full w-full -rotate-90" aria-hidden="true">
        <circle cx="32" cy="32" r={R} fill="none" strokeWidth="6" className="stroke-slate-100 dark:stroke-white/10" />
        <circle
          cx="32"
          cy="32"
          r={R}
          fill="none"
          strokeWidth="6"
          strokeLinecap="round"
          stroke="url(#teamPulseRingGrad)"
          strokeDasharray={C}
          strokeDashoffset={C * (1 - pct)}
          className="transition-[stroke-dashoffset] duration-700 ease-out"
        />
        <defs>
          <linearGradient id="teamPulseRingGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#10b981" />
            <stop offset="100%" stopColor="#06b6d4" />
          </linearGradient>
        </defs>
      </svg>
      <span className="absolute text-[13.5px] font-extrabold tabular-nums text-slate-800 dark:text-white">
        {label}
      </span>
    </div>
  );
}

/** نبض الفريق — live vitals card: join cadence (6-month histogram +
 *  30/90-day chips) beside profile completeness (progress ring + per-field
 *  bars). Derived entirely from the loaded roster — no extra requests. */
function TeamPulse({ members }: { members: TeamMemberDTO[] }) {
  const { t, lang } = useT();

  /* join cadence: 6 calendar-month buckets (oldest → current month) +
   * rolling 30/90-day counters. Month labels locale-aware. */
  const joins = useMemo(() => {
    const now = new Date();
    const counts = new Array<number>(6).fill(0);
    let d30 = 0;
    let d90 = 0;
    const monthFmt = new Intl.DateTimeFormat(intlLocale(lang), { month: "short" });
    const labels: string[] = [];
    for (let i = 5; i >= 0; i--) {
      labels.push(monthFmt.format(new Date(now.getFullYear(), now.getMonth() - i, 1)));
    }
    for (const m of members) {
      const at = new Date(m.createdAt);
      if (!Number.isNaN(at.getTime())) {
        const monthsAgo = (now.getFullYear() - at.getFullYear()) * 12 + (now.getMonth() - at.getMonth());
        if (monthsAgo >= 0 && monthsAgo < 6) counts[5 - monthsAgo] += 1;
        const days = (now.getTime() - at.getTime()) / 86_400_000;
        if (days <= 30) d30 += 1;
        if (days <= 90) d90 += 1;
      }
    }
    return { counts, labels, d30, d90 };
  }, [members, lang]);

  /* profile completeness across the four extended-profile fields. */
  const completeness = useMemo(() => {
    const fields = [
      { label: t("teamFieldPhone"), filled: members.filter((m) => m.phone.trim() !== "").length, icon: "phone", c1: "#0ea5e9", c2: "#0284c7" },
      { label: t("teamFieldJobTitle"), filled: members.filter((m) => m.jobTitle.trim() !== "").length, icon: "briefcase-business", c1: "#f59e0b", c2: "#d97706" },
      { label: t("teamFieldAvatar"), filled: members.filter((m) => m.avatarUrl !== "").length, icon: "user-round", c1: "#8b5cf6", c2: "#7c3aed" },
      { label: t("teamFieldBirthDate"), filled: members.filter((m) => m.birthDate !== "").length, icon: "cake", c1: "#10b981", c2: "#059669" },
    ];
    const totalSlots = members.length * fields.length;
    const filled = fields.reduce((acc, f) => acc + f.filled, 0);
    return { fields, pct: totalSlots > 0 ? filled / totalSlots : 0, totalSlots, filled };
  }, [members, t]);

  const maxJoins = Math.max(...joins.counts, 1);
  const peakJoin = joins.counts.indexOf(Math.max(...joins.counts));
  const pctLabel = `${fmtNum(Math.round(completeness.pct * 100), lang)}٪`;

  return (
    <DashCard title={t("teamPulse")} icon="heart-pulse">
      <p className="-mt-2 mb-3 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
        {t("teamPulseDesc")}
      </p>
      <div className="grid gap-5 lg:grid-cols-2 lg:gap-6">
        {/* join cadence half */}
        <div className="flex flex-col">
          <h3 className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
            {t("teamJoinsCadence")}
          </h3>
          <p className="mt-0.5 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
            {t("teamJoinsCadenceDesc")}
          </p>
          <div className="mt-3 flex flex-1 items-end gap-2" role="img" aria-label={t("teamJoinsCadenceDesc")}>
            {joins.counts.map((count, i) => {
              const isCurrent = i === joins.counts.length - 1;
              const isPeak = i === peakJoin && count > 0;
              const ratio = count / maxJoins;
              return (
                <div key={i} className="group/jm flex min-w-0 flex-1 flex-col items-center gap-1.5">
                  <span
                    className={cn(
                      "text-[9px] font-extrabold tabular-nums transition-opacity",
                      isPeak ? "text-amber-600 dark:text-amber-400" : "text-slate-300 opacity-0 dark:text-slate-600"
                    )}
                  >
                    {fmtNum(count, lang)}
                  </span>
                  <span
                    className={cn(
                      "w-full max-w-[34px] rounded-t-md transition-all duration-300 group-hover/jm:brightness-110",
                      count === 0 && "bg-slate-100 dark:bg-white/[0.06]",
                      isCurrent && count > 0 && "ring-1 ring-brand-400/50"
                    )}
                    style={
                      count > 0
                        ? {
                            height: `${Math.max(ratio * 52, 6)}px`,
                            backgroundImage: isCurrent
                              ? grad("#6d5dfb", "#a855f7")
                              : grad("#0d9488", "#2dd4bf"),
                          }
                        : { height: "6px" }
                    }
                    title={`${joins.labels[i]} · ${fmtNum(count, lang)}`}
                    aria-hidden="true"
                  />
                  <span className="truncate text-[8.5px] font-bold text-slate-400 dark:text-slate-500" dir="auto">
                    {joins.labels[i]}
                  </span>
                </div>
              );
            })}
          </div>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-brand-200/70 bg-brand-500/10 px-2.5 py-1 text-[10.5px] font-extrabold text-brand-700 dark:border-brand-500/25 dark:bg-brand-500/15 dark:text-brand-300">
              <CatIcon name="calendar-check" className="h-3 w-3" />
              {t("teamJoined30", { count: fmtNum(joins.d30, lang) })}
            </span>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-200/70 bg-amber-500/10 px-2.5 py-1 text-[10.5px] font-extrabold text-amber-700 dark:border-amber-500/25 dark:bg-amber-500/15 dark:text-amber-300">
              <CatIcon name="history" className="h-3 w-3" />
              {t("teamJoined90", { count: fmtNum(joins.d90, lang) })}
            </span>
          </div>
        </div>

        {/* hairline divider on lg+ */}
        <span className="hidden lg:block lg:w-px lg:self-stretch lg:bg-slate-100 dark:lg:bg-white/[0.06]" aria-hidden="true" />

        {/* profile completeness half */}
        <div className="flex flex-col">
          <h3 className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
            {t("teamProfileCompleteness")}
          </h3>
          <p className="mt-0.5 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
            {t("teamProfileDesc")}
          </p>
          <div className="mt-3 flex items-center gap-4">
            <PulseRing pct={completeness.pct} label={pctLabel} />
            <ul className="min-w-0 flex-1 space-y-2">
              {completeness.fields.map((f) => {
                const share = members.length > 0 ? f.filled / members.length : 0;
                return (
                  <li key={f.label} className="flex items-center gap-2.5">
                    <span
                      className="grid h-6 w-6 shrink-0 place-items-center rounded-lg text-white shadow-sm"
                      style={{ backgroundImage: grad(f.c1, f.c2) }}
                      aria-hidden="true"
                    >
                      <CatIcon name={f.icon} className="h-3 w-3" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex items-baseline justify-between gap-2">
                        <span className="truncate text-[11px] font-extrabold text-slate-600 dark:text-slate-300">
                          {f.label}
                        </span>
                        <span className="shrink-0 text-[10.5px] font-extrabold tabular-nums text-slate-400 dark:text-slate-500">
                          {fmtNum(f.filled, lang)}/{fmtNum(members.length, lang)}
                        </span>
                      </span>
                      <span className="mt-1 block h-1.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/[0.06]">
                        <span
                          className="block h-full rounded-full transition-[width] duration-500 ease-out"
                          style={{ width: `${Math.max(share * 100, 3)}%`, backgroundImage: grad(f.c1, f.c2) }}
                          aria-hidden="true"
                        />
                      </span>
                    </span>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      </div>
    </DashCard>
  );
}

/* ---------------- view ---------------- */

export function TeamView({ instance, members }: { instance: InstanceDTO; members: TeamMemberDTO[] }) {
  const { t, lang } = useT();
  /* ROUND 172 — the owner IS this signed-in session: the heartbeat's own
   * presence projection (45s cadence) drives the gold card's live dot. */
  const { me: ownerPresence, serverTime: presenceNow } = useInstancePresence();
  const queryClient = useQueryClient();
  const queryKey = ["instance", instance.id] as const;

  /* ROUND 78 — the active team-page tab (roster | roles) */
  const [teamTab, setTeamTab] = useState<"roster" | "roles">("roster");

  /* ROUND 68 — add/edit member dialog subject: null = closed,
     { member: null } = ADD, { member } = EDIT */
  const [memberDialog, setMemberDialog] = useState<{ member: TeamMemberDTO | null } | null>(null);
  const openAddDialog = () => setMemberDialog({ member: null });
  const openEditDialog = (member: TeamMemberDTO) => setMemberDialog({ member });

  /* roster toolbar */
  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  const [roleFilter, setRoleFilter] = useState<RoleFilter>("all");

  /* remove-member confirmation */
  const [pendingRemove, setPendingRemove] = useState<TeamMemberDTO | null>(null);

  /* ROUND 65/68 — profile dialog subject: the member is held by ID and
     RESOLVED from the live members array, so every mutation that lands
     (avatar change, field edit from the extended dialog) re-renders the
     open profile instantly — no stale-snapshot reopen needed. The system
     owner rides a separate boolean (not in the members array). */
  const [profileMemberId, setProfileMemberId] = useState<string | null>(null);
  const [profileOwner, setProfileOwner] = useState(false);
  const profileMember = members.find((m) => m.id === profileMemberId) ?? null;

  const openMemberProfile = (member: TeamMemberDTO) => {
    setProfileMemberId(member.id);
    setProfileOwner(false);
  };
  const openOwnerProfile = () => {
    setProfileMemberId(null);
    setProfileOwner(true);
  };
  const closeProfile = () => {
    setProfileMemberId(null);
    setProfileOwner(false);
  };
  /* the dialog's remove action hands off to the roster's confirm flow */
  const requestRemove = (member: TeamMemberDTO) => {
    closeProfile();
    setPendingRemove(member);
  };
  /* ROUND 68 — the profile's edit action swaps to the extended dialog */
  const requestEdit = (member: TeamMemberDTO) => {
    closeProfile();
    openEditDialog(member);
  };

  useEffect(() => {
    const h = window.setTimeout(() => setDebounced(normalizeSearch(search.trim())), 150);
    return () => window.clearTimeout(h);
  }, [search]);

  const remove = useMutation({
    mutationFn: (memberId: string) => removeMember(instance.id, memberId),
    onSuccess: () => {
      toast.success(t("teamRemoved"));
      setPendingRemove(null);
      queryClient.invalidateQueries({ queryKey });
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  /* KPI counts by role + the 30-day join cohort feeding the total sub-line */
  const counts = useMemo(() => {
    const now = new Date();
    return {
      total: members.length,
      managers: members.filter((m) => m.role === "manager").length,
      staff: members.filter((m) => m.role === "staff").length,
      viewers: members.filter((m) => m.role === "viewer").length,
      joined30: members.filter((m) => now.getTime() - new Date(m.createdAt).getTime() <= 30 * 86_400_000).length,
    };
  }, [members]);
  /** KPI sub-line share: part of whole as a whole percentage (0 when empty). */
  const sharePct = (part: number, whole: number) => (whole > 0 ? Math.round((part / whole) * 100) : 0);

  const filtered = useMemo(
    () =>
      members.filter((m) => {
        if (roleFilter !== "all" && m.role !== roleFilter) return false;
        if (!debounced) return true;
        return normalizeSearch(`${m.name} ${m.email}`).includes(debounced);
      }),
    [members, roleFilter, debounced]
  );

  const copyEmail = (member: TeamMemberDTO) => {
    copyText(member.email).then(
      () => toast.success(t("teamEmailCopied")),
      () => toast.error(t("errorText"))
    );
  };

  /* ROUND 65 — owner email copy (same toast pattern as the roster) */
  const copyOwnerEmail = () => {
    copyText(instance.admin.email).then(
      () => toast.success(t("teamEmailCopied")),
      () => toast.error(t("errorText"))
    );
  };

  /* demo action — confirms the invite flow without an email backend */
  const resendInvite = () => toast.success(t("teamInviteSent"));

  const filtersActive = debounced.length > 0 || roleFilter !== "all";
  const clearFilters = () => {
    setSearch("");
    setRoleFilter("all");
  };

  return (
    <div className="space-y-5">
      {/* ROUND 144 (owner directive) — the heading now carries the REAL
          organization name («فريق الإدارة — اسم المؤسسة») instead of the
          system-category label. The ViewHeading h1 is a block element so a
          long org name wraps gracefully (no overlap, no clipping). */}
      <ViewHeading title={`${t("dashTeamTitle")} — ${instance.org.name}`} desc={t("dashTeamDesc")} />

      {/* ROUND 78 — the page is TABBED: الفريق (roster) + الأدوار والصلاحيات */}
      <Tabs value={teamTab} onValueChange={(v) => setTeamTab(v as "roster" | "roles")}>
        <TabsList className="h-12 w-full max-w-md rounded-2xl bg-slate-100/80 p-1.5 dark:bg-white/[0.05]">
          <TabsTrigger
            value="roster"
            className="h-full flex-1 rounded-xl text-[12px] font-extrabold data-[state=active]:bg-white data-[state=active]:text-slate-900 data-[state=active]:shadow-md dark:data-[state=active]:bg-white/[0.09] dark:data-[state=active]:text-white"
          >
            <CatIcon name="users" className="h-4 w-4" />
            {t("teamTabRoster")}
            <Badge variant="secondary" className="ms-1 rounded-full px-1.5 py-0 text-[10px] font-extrabold tabular-nums">
              {fmtNum(members.length + 1, lang)}
            </Badge>
          </TabsTrigger>
          <TabsTrigger
            value="roles"
            className="h-full flex-1 rounded-xl text-[12px] font-extrabold data-[state=active]:bg-white data-[state=active]:text-slate-900 data-[state=active]:shadow-md dark:data-[state=active]:bg-white/[0.09] dark:data-[state=active]:text-white"
          >
            <CatIcon name="shield-check" className="h-4 w-4" />
            {t("teamTabRoles")}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="roster" className="mt-5 space-y-5">

      {/* ROUND 139 — KPI strip on THE golden inventory-page cards
          (grid-cols-2 → md:grid-cols-3 → xl:grid-cols-5): role counts as
          count-up numerals + context sub-lines (role breakdown on the total,
          share-of-team on the role cards, share-of-team on the joins card).
          Gradients follow the round palette (emerald / violet / amber / sky /
          cyan — no indigo). */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        <StatCard
          size="golden"
          label={t("teamKpiTotal")}
          numeric={counts.total}
          sub={t("teamKpiTotalSub", {
            m: fmtNum(counts.managers, lang),
            s: fmtNum(counts.staff, lang),
            v: fmtNum(counts.viewers, lang),
          })}
          icon="users"
          c1="#10b981"
          c2="#059669"
          index={0}
          tone="up"
        />
        <StatCard
          size="golden"
          label={t("teamKpiManagers")}
          numeric={counts.managers}
          sub={t("teamKpiRoleSub", { pct: fmtNum(sharePct(counts.managers, counts.total), lang) })}
          icon="shield-check"
          c1="#8b5cf6"
          c2="#7c3aed"
          index={1}
        />
        <StatCard
          size="golden"
          label={t("teamKpiStaff")}
          numeric={counts.staff}
          sub={t("teamKpiRoleSub", { pct: fmtNum(sharePct(counts.staff, counts.total), lang) })}
          icon="zap-fast"
          c1="#f59e0b"
          c2="#d97706"
          index={2}
        />
        <StatCard
          size="golden"
          label={t("teamKpiViewers")}
          numeric={counts.viewers}
          sub={t("teamKpiRoleSub", { pct: fmtNum(sharePct(counts.viewers, counts.total), lang) })}
          icon="circle-check"
          c1="#0ea5e9"
          c2="#0284c7"
          index={3}
        />
        <StatCard
          size="golden"
          label={t("teamKpiJoins")}
          numeric={counts.joined30}
          sub={t("teamKpiRoleSub", { pct: fmtNum(sharePct(counts.joined30, counts.total), lang) })}
          icon="user-plus"
          c1="#06b6d4"
          c2="#0891b2"
          index={4}
          tone="up"
        />
      </div>

      {/* ROUND 71 — team pulse: join cadence + profile completeness */}
      {members.length > 0 ? <TeamPulse members={members} /> : null}

      {/* ROUND 68 — add-member CTA card: the full intake (photo, phone, job
          title, birth date, gender…) now lives in the premium TeamMemberDialog */}
      <DashCard title={t("teamAddTitle")} icon="user-plus">
        <div className="flex flex-wrap items-center gap-4">
          <span
            className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-white shadow-lg shadow-brand-500/25"
            style={{ backgroundImage: "linear-gradient(135deg,#6d5dfb,#d946ef)" }}
            aria-hidden="true"
          >
            <CatIcon name="user-round-plus" className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
              {t("teamAddCtaTitle")}
            </p>
            <p className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11.5px] font-semibold text-slate-500 dark:text-slate-400">
              <span className="inline-flex items-center gap-1">
                <CatIcon name="camera" className="h-3 w-3 text-slate-400" />
                {t("teamFieldAvatar")}
              </span>
              <span className="inline-flex items-center gap-1">
                <CatIcon name="phone" className="h-3 w-3 text-slate-400" />
                {t("teamFieldPhone")}
              </span>
              <span className="inline-flex items-center gap-1">
                <CatIcon name="briefcase-business" className="h-3 w-3 text-slate-400" />
                {t("teamFieldJobTitle")}
              </span>
              <span className="inline-flex items-center gap-1">
                <CatIcon name="cake" className="h-3 w-3 text-slate-400" />
                {t("teamFieldBirthDate")}
              </span>
              <span className="inline-flex items-center gap-1">
                <CatIcon name="venus" className="h-3 w-3 text-slate-400" />
                {t("teamFieldGender")}
              </span>
            </p>
          </div>
          <Button
            type="button"
            id="team-add-member-btn"
            onClick={openAddDialog}
            className="h-11 shrink-0 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
          >
            <CatIcon name="user-plus" className="h-4 w-4" />
            {t("teamAddBtn")}
          </Button>
        </div>
      </DashCard>

      {/* roster */}
      <DashCard title={t("teamRoster")} icon="users">
        {/* toolbar: debounced search + role filter + count */}
        <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="relative min-w-0 flex-1">
            <CatIcon
              name="search"
              className="pointer-events-none absolute start-3.5 top-1/2 h-[13px] w-[13px] -translate-y-1/2 text-slate-400"
            />
            <Input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t("teamSearchPh")}
              aria-label={t("teamSearchPh")}
              className="h-11 rounded-xl border-slate-200 bg-slate-50/80 ps-10 pe-10 text-[12.5px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:placeholder:text-slate-500 dark:focus:bg-white/[0.07]"
            />
            {search ? (
              <button
                type="button"
                onClick={() => setSearch("")}
                aria-label={t("teamClearSearch")}
                title={t("teamClearSearch")}
                className="absolute end-2.5 top-1/2 grid h-7 w-7 -translate-y-1/2 place-items-center rounded-full text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-white/10 dark:hover:text-slate-300"
              >
                <CatIcon name="x" className="h-3.5 w-3.5" />
              </button>
            ) : null}
          </div>

          <div className="flex items-center gap-2">
            <Select value={roleFilter} onValueChange={(v) => setRoleFilter(v as RoleFilter)}>
              <SelectTrigger
                aria-label={t("teamRole")}
                className="h-11 w-full rounded-xl border-slate-200 bg-slate-50/80 px-3.5 text-[12.5px] font-semibold text-slate-800 transition hover:border-brand-300 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:hover:border-brand-500/40 sm:w-44"
              >
                <span className="flex min-w-0 items-center gap-2">
                  <CatIcon name="filter" className="h-3.5 w-3.5 shrink-0 text-slate-400" />
                  <SelectValue />
                </span>
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectItem value="all">{t("teamFilterAll")}</SelectItem>
                  {(Object.keys(ROLE_KEYS) as Role[]).map((r) => (
                    <SelectItem key={r} value={r}>
                      {t(ROLE_KEYS[r])}
                    </SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
            <Badge
              variant="secondary"
              className="shrink-0 rounded-full px-3 py-1.5 text-[11px] font-extrabold tabular-nums text-slate-600 dark:text-slate-300"
            >
              {fmtNum(filtered.length, lang)} / {fmtNum(members.length, lang)}
            </Badge>
          </div>
        </div>

        {/* ROUND 65 — the system owner pinned as the first team entry: one
            responsive gold card above BOTH layouts (desktop table + mobile
            cards). The whole card opens the owner profile dialog. */}
        <div
          onClick={openOwnerProfile}
          className="group mb-4 cursor-pointer rounded-2xl border border-amber-300/60 bg-linear-to-l from-amber-50/80 to-orange-50/40 p-4 transition-shadow duration-300 hover:shadow-lift dark:border-amber-500/25 dark:from-amber-500/10 dark:to-orange-500/5"
        >
          <div className="flex flex-wrap items-center gap-3.5">
            {instance.admin.avatarUrl ? (
              // eslint-disable-next-line @next/next/no-img-element -- sealed admin data-URL avatar (workspace's own admin record); next/image optimization does not apply
              <img
                src={instance.admin.avatarUrl}
                alt=""
                className="h-12 w-12 shrink-0 rounded-full object-cover ring-2 ring-amber-300/60 dark:ring-amber-500/30"
              />
            ) : (
              <span
                aria-hidden="true"
                className="grid h-12 w-12 shrink-0 place-items-center rounded-full text-[18px] font-extrabold text-white"
                style={{ backgroundImage: grad("#f59e0b", "#d97706") }}
              >
                {initial(instance.admin.name)}
              </span>
            )}
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-1.5">
                <p className="truncate font-display text-[14px] font-extrabold text-slate-900 transition group-hover:text-amber-700 dark:text-white dark:group-hover:text-amber-400">
                  {instance.admin.name}
                </p>
                {/* ROUND 172 — the owner's own live session (heartbeat «me») */}
                <PresenceDot presence={ownerPresence} now={presenceNow} />
                <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-amber-500/15 px-2 py-0.5 text-[10.5px] font-extrabold text-amber-600 dark:text-amber-400">
                  <CatIcon name="crown" className="h-3 w-3" />
                  {t("teamOwnerBadge")}
                </span>
                <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-amber-300/70 px-2 py-0.5 text-[10.5px] font-extrabold text-amber-700 dark:border-amber-500/40 dark:text-amber-400">
                  <CatIcon name="shield-check" className="h-3 w-3" />
                  {t("teamOwnerPermsAll")}
                </span>
              </div>
              <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1">
                <span className="inline-flex min-w-0 items-center gap-1.5">
                  <span
                    dir="ltr"
                    className={cn(
                      "max-w-[220px] truncate text-[12px] font-semibold tabular-nums text-slate-500 dark:text-slate-400",
                      lang === "ar" ? "text-end" : "text-start"
                    )}
                  >
                    {instance.admin.email}
                  </span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      copyOwnerEmail();
                    }}
                    aria-label={t("teamCopyEmail")}
                    title={t("teamCopyEmail")}
                    className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-slate-400 transition hover:bg-amber-100 hover:text-amber-600 dark:hover:bg-amber-500/15 dark:hover:text-amber-400"
                  >
                    <CatIcon name="copy" className="h-3 w-3" />
                  </button>
                </span>
                <span className="inline-flex shrink-0 items-center gap-1.5 text-[11px] font-bold text-slate-400 dark:text-slate-500">
                  <CatIcon name="calendar" className="h-3 w-3 shrink-0" />
                  {t("teamOwnerSince", { date: dateOnly(instance.createdAt, lang) })}
                </span>
              </div>
            </div>
            <Button
              type="button"
              onClick={openOwnerProfile}
              className="h-10 shrink-0 rounded-xl bg-linear-to-l from-amber-500 to-orange-500 px-4 text-[12.5px] font-extrabold text-white shadow-lg shadow-amber-500/25 transition hover:brightness-110 active:scale-95"
            >
              <CatIcon name="id-card" className="h-4 w-4" />
              {t("teamProfileView")}
            </Button>
          </div>
        </div>

        {members.length === 0 ? (
          <div className="py-12 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
              <CatIcon name="users" className="h-6 w-6" />
            </div>
            <h3 className="mt-4 font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
              {t("teamEmpty")}
            </h3>
            <p className="mx-auto mt-1 max-w-sm text-[12.5px] text-slate-500 dark:text-slate-400">
              {t("teamEmptyDesc")}
            </p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="py-12 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
              <CatIcon name="search" className="h-6 w-6" />
            </div>
            <h3 className="mt-4 font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
              {t("teamEmpty")}
            </h3>
            <p className="mx-auto mt-1 max-w-sm text-[12.5px] text-slate-500 dark:text-slate-400">
              {t("dashSearchNoResults")}
            </p>
            {filtersActive ? (
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={clearFilters}
                className="mt-3 h-9 gap-1.5 rounded-lg px-3 text-[11.5px] font-bold text-brand-600 hover:text-brand-700 dark:text-brand-300"
              >
                <CatIcon name="x" className="h-3.5 w-3.5" />
                {t("teamClearSearch")}
              </Button>
            ) : null}
          </div>
        ) : (
          <>
            {/* desktop table */}
            <div className="hidden overflow-x-auto md:block">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-200/70 dark:border-white/10">
                    <TableHead className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                      {t("teamColMember")}
                    </TableHead>
                    <TableHead className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                      {t("teamEmail")}
                    </TableHead>
                    <TableHead className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                      {t("teamRole")}
                    </TableHead>
                    <TableHead className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                      {t("teamColStatus")}
                    </TableHead>
                    <TableHead className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                      {t("teamColJoined")}
                    </TableHead>
                    <TableHead className="text-end text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                      {t("teamColActions")}
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((member) => {
                    const g = ROLE_GRAD[member.role];
                    const isNew = isNewMember(member);
                    return (
                      <TableRow key={member.id}>
                        <TableCell>
                          <div className="flex items-center gap-2.5">
                            {member.avatarUrl ? (
                              // eslint-disable-next-line @next/next/no-img-element -- sealed member data-URL avatar (cropper output); next/image optimization does not apply
                              <img
                                src={member.avatarUrl}
                                alt=""
                                className="h-9 w-9 shrink-0 rounded-full object-cover"
                              />
                            ) : (
                              <span
                                className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-[12px] font-extrabold text-white"
                                style={{ backgroundImage: grad(g.c1, g.c2) }}
                                aria-hidden="true"
                              >
                                {initial(member.name)}
                              </span>
                            )}
                            <div className="min-w-0">
                              <p className="flex flex-wrap items-center gap-1.5 text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                                {/* ROUND 65 — the name opens the profile dialog */}
                                <button
                                  type="button"
                                  onClick={() => openMemberProfile(member)}
                                  title={t("teamProfileView")}
                                  className="cursor-pointer truncate text-start transition hover:text-brand-600 dark:hover:text-brand-300"
                                >
                                  {member.name}
                                </button>
                                {isNew ? (
                                  <span className="inline-flex shrink-0 rounded-full bg-brand-500/10 px-1.5 py-0.5 text-[11px] font-extrabold text-brand-600 dark:bg-brand-500/15 dark:text-brand-300">
                                    {t("teamStatusNew")}
                                  </span>
                                ) : null}
                              </p>
                              {/* Task 2-b — second-language name (bilingual
                                  teams): muted auto-dir secondary line */}
                              {member.nameAlt ? (
                                <p className="mt-0.5 truncate text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                                  <span dir="auto">{member.nameAlt}</span>
                                </p>
                              ) : null}
                              {member.jobTitle ? (
                                <p className="mt-0.5 flex items-center gap-1 truncate text-[11px] font-semibold text-slate-400 dark:text-slate-500">
                                  <CatIcon name="briefcase-business" className="h-3 w-3 shrink-0" />
                                  <span className="truncate">{member.jobTitle}</span>
                                </p>
                              ) : null}
                              {member.jobTitleAlt ? (
                                <p className="mt-0.5 truncate text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                                  <span dir="auto">{member.jobTitleAlt}</span>
                                </p>
                              ) : null}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="inline-flex items-center gap-1.5">
                            <span
                              dir="ltr"
                              className={cn(
                                "max-w-[220px] truncate text-[12px] font-semibold tabular-nums text-slate-500 dark:text-slate-400",
                                lang === "ar" ? "text-end" : "text-start"
                              )}
                            >
                              {member.email}
                            </span>
                            <button
                              type="button"
                              onClick={() => copyEmail(member)}
                              aria-label={t("teamCopyEmail")}
                              title={t("teamCopyEmail")}
                              className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-brand-600 dark:hover:bg-white/10 dark:hover:text-brand-300"
                            >
                              <CatIcon name="copy" className="h-3 w-3" />
                            </button>
                          </span>
                        </TableCell>
                        <TableCell>
                          <Badge className={`${ROLE_BADGE[member.role]} text-[10.5px]`}>
                            {t(ROLE_KEYS[member.role])}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <span className="inline-flex items-center gap-1.5 text-[11.5px] font-bold text-slate-500 dark:text-slate-400">
                            <span
                              className={cn("h-1.5 w-1.5 rounded-full", isNew ? "bg-brand-500" : "bg-emerald-500")}
                              aria-hidden="true"
                            />
                            {isNew ? t("teamStatusNew") : t("teamStatusActive")}
                          </span>
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <p className="text-[11.5px] font-bold text-slate-600 dark:text-slate-300">
                            {dateOnly(member.createdAt, lang)}
                          </p>
                          <p className="text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                            {relativeTime(member.createdAt, lang)}
                          </p>
                        </TableCell>
                        <TableCell className="text-end">
                          <div className="inline-flex">
                            <MemberActions
                              onProfile={() => openMemberProfile(member)}
                              onEdit={() => openEditDialog(member)}
                              onCopy={() => copyEmail(member)}
                              onResend={resendInvite}
                              onRemove={() => setPendingRemove(member)}
                            />
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>

            {/* mobile member cards */}
            <ul className="space-y-3 md:hidden">
              {filtered.map((member) => {
                const g = ROLE_GRAD[member.role];
                const isNew = isNewMember(member);
                return (
                  <li
                    key={member.id}
                    className="rounded-2xl border border-slate-200/80 bg-white/80 p-4 dark:border-white/[0.07] dark:bg-white/[0.03]"
                  >
                    {/* ROUND 65 — the avatar/name area opens the profile dialog */}
                    <button
                      type="button"
                      onClick={() => openMemberProfile(member)}
                      title={t("teamProfileView")}
                      className="flex min-w-0 cursor-pointer items-start gap-3 rounded-xl p-1 text-start transition hover:bg-slate-50/80 dark:hover:bg-white/[0.04]"
                    >
                      {member.avatarUrl ? (
                        // eslint-disable-next-line @next/next/no-img-element -- sealed member data-URL avatar (cropper output); next/image optimization does not apply
                        <img
                          src={member.avatarUrl}
                          alt=""
                          className="h-11 w-11 shrink-0 rounded-full object-cover"
                        />
                      ) : (
                        <span
                          className="grid h-11 w-11 shrink-0 place-items-center rounded-full text-[13px] font-extrabold text-white"
                          style={{ backgroundImage: grad(g.c1, g.c2) }}
                          aria-hidden="true"
                        >
                          {initial(member.name)}
                        </span>
                      )}
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <p className="min-w-0 truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
                            {member.name}
                          </p>
                          <Badge className={`${ROLE_BADGE[member.role]} shrink-0 text-[10.5px]`}>
                            {t(ROLE_KEYS[member.role])}
                          </Badge>
                        </div>
                        {/* Task 2-b — second-language name (bilingual teams):
                            muted auto-dir secondary line under the primary */}
                        {member.nameAlt ? (
                          <p className="mt-0.5 truncate text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                            <span dir="auto">{member.nameAlt}</span>
                          </p>
                        ) : null}
                        {member.jobTitle ? (
                          <p className="mt-0.5 flex items-center gap-1 truncate text-[11px] font-semibold text-slate-400 dark:text-slate-500">
                            <CatIcon name="briefcase-business" className="h-3 w-3 shrink-0" />
                            <span className="truncate">{member.jobTitle}</span>
                          </p>
                        ) : null}
                        {member.jobTitleAlt ? (
                          <p className="mt-0.5 truncate text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                            <span dir="auto">{member.jobTitleAlt}</span>
                          </p>
                        ) : null}
                        <p
                          dir="ltr"
                          className={cn(
                            "mt-0.5 truncate text-[11.5px] font-semibold tabular-nums text-slate-500 dark:text-slate-400",
                            lang === "ar" ? "text-end" : "text-start"
                          )}
                        >
                          {member.email}
                        </p>
                        <span className="mt-1.5 inline-flex items-center gap-1.5 text-[11px] font-bold text-slate-500 dark:text-slate-400">
                          <span
                            className={cn("h-1.5 w-1.5 rounded-full", isNew ? "bg-brand-500" : "bg-emerald-500")}
                            aria-hidden="true"
                          />
                          {isNew ? t("teamStatusNew") : t("teamStatusActive")}
                        </span>
                      </div>
                    </button>
                    <div className="mt-3 flex items-center justify-between gap-2 border-t border-slate-100 pt-3 dark:border-white/[0.06]">
                      <p className="min-w-0 truncate text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                        {t("teamColJoined")}: {dateOnly(member.createdAt, lang)}
                      </p>
                      <div className="flex shrink-0 items-center gap-1.5">
                        <button
                          type="button"
                          onClick={resendInvite}
                          aria-label={t("teamResendInvite")}
                          title={t("teamResendInvite")}
                          className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 text-slate-500 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:text-slate-300 dark:hover:border-brand-500/40"
                        >
                          <CatIcon name="telegram" className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => copyEmail(member)}
                          aria-label={t("teamCopyEmail")}
                          title={t("teamCopyEmail")}
                          className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 text-slate-500 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:text-slate-300 dark:hover:border-brand-500/40"
                        >
                          <CatIcon name="copy" className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setPendingRemove(member)}
                          aria-label={t("teamRemoveTitle")}
                          title={t("teamRemoveTitle")}
                          className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 text-slate-400 transition hover:border-rose-300 hover:bg-rose-50 hover:text-rose-500 dark:border-white/10 dark:hover:border-rose-500/40 dark:hover:bg-rose-500/10 dark:hover:text-rose-400"
                        >
                          <CatIcon name="user-minus" className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          </>
        )}
      </DashCard>
        </TabsContent>

        {/* ROUND 78 — الأدوار والصلاحيات: the strict RBAC matrix tab */}
        <TabsContent value="roles" className="mt-5">
          <RolesPermissionsTab members={members} />
        </TabsContent>
      </Tabs>

      {/* remove-member confirmation */}
      <AlertDialog open={pendingRemove !== null} onOpenChange={(o) => !o && setPendingRemove(null)}>
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display text-lg font-extrabold text-slate-900 dark:text-white">
              {t("teamRemoveTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] text-slate-500 dark:text-slate-400">
              {pendingRemove ? `${t("teamRemoveMsg")} — ${pendingRemove.name}` : t("teamRemoveMsg")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={remove.isPending} className="h-10 rounded-xl px-5 text-[12.5px] font-bold">
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => pendingRemove && remove.mutate(pendingRemove.id)}
              disabled={remove.isPending}
              className="h-10 rounded-xl bg-rose-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60"
            >
              {remove.isPending ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : null}
              {t("dlgDelete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ROUND 78 — the REBUILT premium member / owner profile: a full-height
          side sheet (sliding from the reading edge) carrying the engine-driven
          effective-permissions panel. Single instance; subject carried by the
          profileMember / profileOwner state pair. */}
      <MemberProfileSheet
        open={profileMember !== null || profileOwner}
        onOpenChange={(o) => !o && closeProfile()}
        member={profileMember}
        owner={
          profileOwner
            ? {
                name: instance.admin.name,
                email: instance.admin.email,
                avatarUrl: instance.admin.avatarUrl ?? null,
                joinedAt: instance.createdAt,
              }
            : null
        }
        instance={instance}
        onRequestRemove={requestRemove}
        onRequestEdit={requestEdit}
      />

      {/* ROUND 68 — extended add / edit member dialog (photo, phone, job
          title, birth date, gender). key remounts fresh state per subject. */}
      {memberDialog ? (
        <TeamMemberDialog
          key={memberDialog.member?.id ?? "new"}
          open
          onOpenChange={(o) => !o && setMemberDialog(null)}
          instance={instance}
          member={memberDialog.member}
        />
      ) : null}
    </div>
  );
}
