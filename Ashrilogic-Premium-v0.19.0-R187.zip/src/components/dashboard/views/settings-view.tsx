"use client";

/**
 * Dashboard — settings view: org form, preferences (lang/theme apply LIVE)
 * and a modules shortcut. Save computes a diff and PATCHes the instance.
 */
import { useEffect, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useTheme } from "next-themes";
import { toast } from "sonner";
import { SYSTEM_MAP } from "@/data/catalog";
import { SITE_THEMES, siteTheme, categoryTheme } from "@/lib/site-themes";
import {
  DASH_THEMES,
  SURFACE_FONTS,
} from "@/lib/surface-styling";
import { useT } from "@/lib/i18n";
import type { I18nKey } from "@/lib/i18n";
import { LOCALES } from "@/lib/locales";
import { useAppStore } from "@/lib/store";
import type {
  BackupVerifyDTO,
  InstanceDTO,
  Lang,
  OrgInfo,
  PrefsInfo,
  SiteContent,
  SitePayload,
  WorkspaceUsageDTO,
} from "@/lib/types";
import {
  ApiError,
  deleteInstance,
  disableOwnWorkspace,
  downloadInstanceBackup,
  fetchInstanceUsage,
  fetchSite,
  instanceExportUrl,
  restoreInstanceBackup,
  updateInstance,
  updateSite,
  verifyInstanceBackup,
} from "@/lib/api-client";
import { analyzeImage, formatBytes, ImageAnalysisError } from "@/lib/image-tools";
import { DEFAULT_INVOICE_PREFIX, formatInvoiceCode } from "@/lib/record-code";
import { apiErrorText } from "@/lib/api-errors";
import { CatIcon } from "@/components/icon";
import { useAccentPair } from "@/components/dashboard/accent-context";
import { cn, fmtNum, grad } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Skeleton } from "@/components/ui/skeleton";
import { PremiumPhoneInput } from "@/components/ui/premium-contact";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { DashCard, IconTile, ViewHeading } from "@/components/dashboard/dash-shared";
import { FeatureGate } from "@/components/dashboard/feature-gate";
import { trialCountdownText } from "@/components/dashboard/smart-countdown";
import { COUNTRIES, TIMEZONES, WZ_INPUT, WZ_LABEL } from "@/components/wizard/wizard-shared";
import {
  PasskeysCard,
  SessionsCard,
  TwoFactorCard,
} from "@/components/security/security-cards";

const PREF_TOGGLES = [
  { key: "notif", icon: "bell", title: "wzPrefsNotif", desc: "wzPrefsNotifDesc", c1: "#f59e0b", c2: "#ea580c" },
  { key: "backup", icon: "cloud-upload", title: "wzPrefsBackup", desc: "wzPrefsBackupDesc", c1: "#06b6d4", c2: "#0e7490" },
  { key: "audit", icon: "clipboard-list", title: "wzPrefsAudit", desc: "wzPrefsAuditDesc", c1: "#8b5cf6", c2: "#7c3aed" },
  { key: "demo", icon: "flask", title: "wzPrefsDemo", desc: "wzPrefsDemoDesc", c1: "#ec4899", c2: "#db2777" },
] as const;

/** Password strength for the rotation card (same scoring as the wizard). */
function pwScore(password: string): number {
  if (!password) return 0;
  let score = 0;
  if (password.length >= 8) score += 1;
  if (password.length >= 10) score += 1;
  const classes = [/[a-z]/, /[A-Z]/, /[0-9]/, /[^a-zA-Z0-9]/].filter((re) => re.test(password)).length;
  if (classes >= 2) score += 1;
  if (classes >= 3 || password.length >= 14) score += 1;
  return Math.min(4, score);
}

const PW_COLORS = ["#94a3b8", "#f43f5e", "#f97316", "#eab308", "#10b981"];

/* ---------------- ROUND 41 (task 4) — backup & restore ---------------- */

const BK_INCLUDES = ["bkInc1", "bkInc2", "bkInc3", "bkInc4", "bkInc5"] as const;

/** matches the server's 25 MB restore-body ceiling (envelope + JSON framing) */
const BK_FILE_MAX_BYTES = 25_000_000;

/** Localized date for file/backup metadata rows. */
function bkDate(value: string | number, lang: Lang): string {
  return new Date(value).toLocaleString(lang === "ar" ? "ar-EG" : "en-US", {
    dateStyle: "medium",
    timeStyle: "short",
  });
}

/**
 * Backup & restore section (round 41). Two cards: download a complete
 * SHA-256-sealed snapshot, or upload a backup file — verified server-side
 * (integrity + ownership) before the transactional restore lands.
 */
function BackupRestoreSection({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const inputRef = useRef<HTMLInputElement | null>(null);

  const [backing, setBacking] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [verifying, setVerifying] = useState(false);
  const [verify, setVerify] = useState<BackupVerifyDTO | null>(null);
  const [restoring, setRestoring] = useState(false);

  const onBackup = async () => {
    setBacking(true);
    try {
      await downloadInstanceBackup(instance.id);
      toast.success(t("bkBackupDone"));
    } catch (error) {
      toast.error(`${t("errorText")}: ${(error as Error).message}`);
    } finally {
      setBacking(false);
    }
  };

  const onFile = (chosen: File | null) => {
    setVerify(null);
    setFile(chosen);
    if (!chosen) return;
    if (
      (!chosen.name.toLowerCase().endsWith(".json") && chosen.type !== "application/json") ||
      chosen.size > BK_FILE_MAX_BYTES
    ) {
      setVerify({ ok: false, meta: null, reason: "format" });
      return;
    }
    setVerifying(true);
    verifyInstanceBackup(instance.id, chosen)
      .then((result) => setVerify(result))
      .catch(() => setVerify({ ok: false, meta: null, reason: "format" }))
      .finally(() => setVerifying(false));
  };

  const onRestore = async () => {
    if (!file || !verify?.ok) return;
    setRestoring(true);
    try {
      /* pre-restore safety snapshot: the CURRENT workspace state is downloaded
         automatically before anything changes — the user always holds a file of
         the world they are about to leave (best-effort; the server-side single
         transaction remains the hard all-or-nothing guarantee either way) */
      try {
        await downloadInstanceBackup(instance.id);
      } catch {
        /* rate-limited or transient — integrity is still transactional */
      }
      await restoreInstanceBackup(instance.id, file);
      toast.success(t("bkRestoreDone"));
      /* a restore replaces the whole workspace — reload so every cached view
         (modules, records, site, customers, orders, team) reflects it */
      window.setTimeout(() => window.location.reload(), 800);
    } catch (error) {
      const code = error instanceof ApiError ? error.code : undefined;
      if (code === "BACKUP_WRONG_SYSTEM") toast.error(t("bkWrongSystem"));
      else if (code === "BACKUP_INVALID") toast.error(t("bkInvalidFile"));
      else toast.error(`${t("errorText")}: ${(error as Error).message}`);
      setRestoring(false);
    }
  };

  const meta = verify?.ok ? (verify.meta ?? null) : null;

  return (
    <DashCard title={t("bkTitle")} icon="database-backup">
      <p className="mb-4 max-w-2xl text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
        {t("bkDesc")}
      </p>

      <div className="grid items-start gap-4 lg:grid-cols-2">
        {/* ---------------- backup card ---------------- */}
        <div className="flex flex-col rounded-2xl border border-slate-200/80 bg-slate-50/40 p-4 dark:border-white/10 dark:bg-white/[0.02]">
          <div className="flex items-center gap-3">
            <IconTile icon="cloud-upload" c1="#06b6d4" c2="#0e7490" />
            <div className="min-w-0">
              <p className="text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
                {t("bkBackupCard")}
              </p>
              <p className="mt-0.5 text-[11.5px] leading-relaxed text-slate-500 dark:text-slate-400">
                {t("bkBackupDesc")}
              </p>
            </div>
          </div>

          <div className="mt-3.5 rounded-2xl border border-slate-200/80 bg-white/60 p-3 dark:border-white/10 dark:bg-white/[0.03]">
            <p className="text-[10.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
              {t("bkIncludes")}
            </p>
            <ul className="mt-2 space-y-1.5">
              {BK_INCLUDES.map((key) => (
                <li key={key} className="flex items-start gap-1.5 text-[11.5px] font-semibold text-slate-600 dark:text-slate-300">
                  <CatIcon name="check" className="mt-0.5 h-3 w-3 shrink-0 text-emerald-500" />
                  {t(key)}
                </li>
              ))}
            </ul>
          </div>

          <Button
            type="button"
            onClick={onBackup}
            disabled={backing}
            className="mt-4 h-10 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-cyan-500/25 transition hover:brightness-110 disabled:opacity-60"
            style={{ backgroundImage: grad("#06b6d4", "#0e7490") }}
          >
            <CatIcon
              name={backing ? "refresh-cw" : "cloud-upload"}
              className={cn("h-4 w-4", backing && "animate-spin")}
            />
            {t(backing ? "bkBackingUp" : "bkBackupBtn")}
          </Button>
        </div>

        {/* ---------------- restore card ---------------- */}
        <div className="flex flex-col rounded-2xl border border-slate-200/80 bg-slate-50/40 p-4 dark:border-white/10 dark:bg-white/[0.02]">
          <div className="flex items-center gap-3">
            <IconTile icon="clock-rotate-left" c1="#10b981" c2="#059669" />
            <div className="min-w-0">
              <p className="text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
                {t("bkRestoreCard")}
              </p>
              <p className="mt-0.5 text-[11.5px] leading-relaxed text-slate-500 dark:text-slate-400">
                {t("bkRestoreDesc")}
              </p>
            </div>
          </div>

          {/* dropzone */}
          <div
            role="button"
            tabIndex={0}
            aria-label={t("bkDropTitle")}
            onClick={() => inputRef.current?.click()}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                inputRef.current?.click();
              }
            }}
            onDragOver={(e) => {
              e.preventDefault();
              setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragging(false);
              onFile(e.dataTransfer.files?.[0] ?? null);
            }}
            className={cn(
              "mt-3.5 flex cursor-pointer flex-col items-center justify-center gap-1.5 rounded-2xl border-2 border-dashed p-6 text-center outline-none transition-colors",
              dragging
                ? "border-emerald-400 bg-emerald-500/10"
                : "border-slate-300 bg-white/60 hover:border-emerald-300 hover:bg-emerald-500/5 dark:border-white/15 dark:bg-white/[0.03] dark:hover:border-emerald-500/40"
            )}
          >
            <CatIcon
              name="cloud-upload"
              className={cn("h-6 w-6 transition-colors", dragging ? "text-emerald-500" : "text-slate-400 dark:text-slate-500")}
            />
            <p className="text-[12px] font-bold text-slate-600 dark:text-slate-300">{t("bkDropTitle")}</p>
            <p className="text-[11px] font-semibold text-slate-400 dark:text-slate-500">{t("bkDropOr")}</p>
            <input
              ref={inputRef}
              type="file"
              accept=".json,application/json"
              className="hidden"
              onChange={(e) => {
                onFile(e.target.files?.[0] ?? null);
                e.target.value = "";
              }}
            />
          </div>

          {/* uploaded-file verification panel */}
          {file ? (
            <div className="mt-3 rounded-2xl border border-slate-200/80 bg-white/60 p-3 dark:border-white/10 dark:bg-white/[0.03]">
              <p className="flex items-center gap-2 text-[12px] font-bold text-slate-700 dark:text-slate-200">
                <CatIcon name="file-text" className="h-4 w-4 shrink-0 text-brand-500" />
                <span dir="ltr" className="truncate">
                  {file.name}
                </span>
              </p>
              <p className="mt-1 text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                {t("bkFileMeta", { size: formatBytes(file.size, lang), date: bkDate(file.lastModified, lang) })}
              </p>

              {verifying ? (
                <p className="mt-2.5 flex items-center gap-2 text-[11.5px] font-bold text-slate-500 dark:text-slate-400">
                  <CatIcon name="refresh-cw" className="h-3.5 w-3.5 animate-spin" />
                  {t("bkVerifyBtn")}…
                </p>
              ) : meta ? (
                <>
                  <p className="mt-2.5 inline-flex items-center gap-1.5 rounded-full bg-emerald-100 px-2.5 py-1 text-[10.5px] font-extrabold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
                    <CatIcon name="shield-check" className="h-3 w-3" />
                    {t("bkChecksumOk")}
                  </p>
                  <dl className="mt-2 space-y-1.5">
                    <div className="flex items-center justify-between gap-2 text-[11.5px]">
                      <dt className="font-bold text-slate-500 dark:text-slate-400">{t("bkVersion")}</dt>
                      <dd dir="ltr" className="font-bold tabular-nums text-slate-700 dark:text-slate-200">
                        {meta.version}
                      </dd>
                    </div>
                    <div className="flex items-center justify-between gap-2 text-[11.5px]">
                      <dt className="font-bold text-slate-500 dark:text-slate-400">{t("bkRows")}</dt>
                      {/* localized count (Arabic-Indic in AR) — label inline-start, value inline-end */}
                      <dd className="font-bold tabular-nums text-slate-700 dark:text-slate-200">
                        {fmtNum(meta.totalRecords, lang)}
                      </dd>
                    </div>
                    <div className="flex items-center justify-between gap-2 text-[11.5px]">
                      <dt className="font-bold text-slate-500 dark:text-slate-400">{t("bkCreated")}</dt>
                      <dd className="font-bold text-slate-700 dark:text-slate-200">{bkDate(meta.createdAt, lang)}</dd>
                    </div>
                    <div className="flex items-center justify-between gap-2 text-[11.5px]">
                      <dt className="font-bold text-slate-500 dark:text-slate-400">{t("bkChecksum")}</dt>
                      <dd
                        dir="ltr"
                        title={meta.checksum}
                        className="max-w-[60%] truncate rounded-lg bg-slate-100 px-2 py-0.5 font-mono text-[10px] font-semibold text-slate-600 dark:bg-white/10 dark:text-slate-300"
                      >
                        {meta.checksum.slice(0, 16)}…
                      </dd>
                    </div>
                  </dl>
                </>
              ) : verify && !verify.ok ? (
                <p
                  className={cn(
                    "mt-2.5 flex items-start gap-1.5 rounded-xl px-2.5 py-2 text-[11px] font-bold",
                    verify.reason === "wrong-system"
                      ? "bg-amber-500/10 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300"
                      : "bg-rose-500/10 text-rose-600 dark:bg-rose-500/15 dark:text-rose-300"
                  )}
                >
                  <CatIcon
                    name={verify.reason === "wrong-system" ? "circle-alert" : "circle-x"}
                    className="mt-0.5 h-3.5 w-3.5 shrink-0"
                  />
                  {t(verify.reason === "wrong-system" ? "bkWrongSystem" : "bkInvalidFile")}
                </p>
              ) : null}
            </div>
          ) : null}

          {/* safety note */}
          <div className="mt-3 flex items-start gap-2.5 rounded-2xl border border-amber-300/60 bg-amber-500/10 p-3 dark:border-amber-500/20 dark:bg-amber-500/10">
            <CatIcon name="shield-check" className="mt-0.5 h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400" />
            <div className="min-w-0">
              <p className="text-[11.5px] font-extrabold text-amber-800 dark:text-amber-300">{t("bkSafetyTitle")}</p>
              <p className="mt-0.5 text-[11px] leading-relaxed text-amber-700/90 dark:text-amber-300/80">
                {t("bkSafetyDesc")}
              </p>
            </div>
          </div>

          <Button
            type="button"
            onClick={onRestore}
            disabled={!file || !verify?.ok || restoring}
            className="mt-4 h-10 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:brightness-110 disabled:opacity-50"
            style={{ backgroundImage: grad("#f43f5e", "#e11d48") }}
          >
            <CatIcon
              name={restoring ? "refresh-cw" : "clock-rotate-left"}
              className={cn("h-4 w-4", restoring && "animate-spin")}
            />
            {t(restoring ? "bkRestoring" : "bkRestoreBtn")}
          </Button>
        </div>
      </div>
    </DashCard>
  );
}

/* ================================================================== */
/* ROUND 45 — Brand identity (moved here from the website editor): the  */
/* org logo is a WORKSPACE-level asset managed from Settings and shown  */
/* across the dashboard header, the public website, the e-store and the */
/* browser favicon. Storage stays the site content (managed refs,       */
/* server-validated); saving writes ONLY the logoUrl field.             */
/* ================================================================== */

/** Premium logo uploader with real ANALYSIS before approval (moved from
 *  the website view — round 29 design, preserved exactly). */
function LogoUploader({
  value,
  onChange,
}: {
  value: string;
  onChange: (dataUrl: string) => void;
}) {
  const { t, lang } = useT();
  const inputRef = useRef<HTMLInputElement>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [analysis, setAnalysis] = useState<string | null>(null);

  const process = async (file: File | undefined | null) => {
    if (!file || analyzing) return;
    setAnalyzing(true);
    try {
      const result = await analyzeImage(file, {
        outputSize: 320,
        outputSizeSmall: 192,
        targetBytes: 420 * 1024,
      });
      onChange(result.dataUrl);
      setAnalysis(
        t("siteLogoAnalyzed", {
          dims: `${fmtNum(result.srcWidth, lang)}×${fmtNum(result.srcHeight, lang)}`,
          size: formatBytes(result.originalBytes, lang),
          out: formatBytes(result.outBytes, lang),
        })
      );
      if (!result.square) toast.info(t("siteLogoSquareHint"));
    } catch (error) {
      const code = error instanceof ImageAnalysisError ? error.code : "corrupt";
      const key: I18nKey =
        code === "bad-type"
          ? "siteLogoBadType"
          : code === "too-large"
            ? "siteLogoTooLarge"
            : code === "tiny"
              ? "siteLogoTiny"
              : "siteLogoCorrupt";
      toast.error(t(key));
    } finally {
      setAnalyzing(false);
    }
  };

  const pick = () => inputRef.current?.click();

  const drop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) void process(file);
  };

  return (
    <div className="space-y-3">
      <input
        ref={inputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp,image/gif"
        className="hidden"
        onChange={(e) => {
          void process(e.target.files?.[0]);
          e.target.value = "";
        }}
      />

      {value ? (
        <div className="flex flex-wrap items-center gap-4 rounded-2xl border border-slate-200 bg-slate-50/60 p-4 dark:border-white/10 dark:bg-white/[0.03]">
          <span
            className="grid h-16 w-16 shrink-0 place-items-center overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-white/10 dark:bg-white/[0.06]"
            aria-label={t("siteLogoSiteNote")}
          >
            <img src={value} alt="" className="h-full w-full object-contain p-1.5" />
          </span>
          <div className="min-w-0 flex-1 space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-2.5 py-1 text-[10.5px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-300">
                <span className="grid h-4 w-4 place-items-center overflow-hidden rounded-sm">
                  <img src={value} alt="" className="h-4 w-4 object-contain" />
                </span>
                {t("brandFavicon")}
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-2.5 py-1 text-[10.5px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-300">
                <span className="grid h-4 w-4 place-items-center overflow-hidden rounded-sm">
                  <img src={value} alt="" className="h-3.5 w-3.5 object-contain" />
                </span>
                {t("brandInSite")}
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-2.5 py-1 text-[10.5px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-300">
                <span className="grid h-4 w-4 place-items-center overflow-hidden rounded-sm">
                  <img src={value} alt="" className="h-3 w-3 object-contain" />
                </span>
                <span className="truncate">{t("brandInStore")}</span>
              </span>
            </div>
            {analysis ? (
              <p className="text-[10.5px] font-bold leading-relaxed text-emerald-600 dark:text-emerald-400">
                <CatIcon name="badge-check" className="me-1 inline h-3 w-3 align-[-2px]" />
                {analysis}
              </p>
            ) : null}
          </div>
          <div className="flex items-center gap-1.5">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={pick}
              disabled={analyzing}
              className="h-8 gap-1.5 rounded-xl px-3 text-[11.5px] font-bold"
            >
              <CatIcon name="upload" className="h-3.5 w-3.5" />
              {t("siteLogoChange")}
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => {
                onChange("");
                setAnalysis(null);
              }}
              className="h-8 gap-1.5 rounded-xl px-3 text-[11.5px] font-bold text-rose-500 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-500/10"
            >
              <CatIcon name="trash" className="h-3.5 w-3.5" />
              {t("siteLogoRemove")}
            </Button>
          </div>
        </div>
      ) : (
        <button
          type="button"
          onClick={pick}
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={drop}
          className={cn(
            "flex w-full flex-col items-center gap-2 rounded-2xl border-2 border-dashed p-7 text-center transition",
            dragOver
              ? "border-brand-400 bg-brand-50/60 dark:border-brand-500/50 dark:bg-brand-500/10"
              : "border-slate-200 bg-slate-50/40 hover:border-brand-300 hover:bg-brand-50/30 dark:border-white/10 dark:bg-white/[0.02] dark:hover:border-brand-500/40"
          )}
        >
          <span
            className={cn(
              "grid h-11 w-11 place-items-center rounded-2xl text-white shadow-lg transition",
              analyzing && "animate-pulse"
            )}
            style={{ backgroundImage: "linear-gradient(135deg,#6d5dfb,#a855f7)" }}
            aria-hidden="true"
          >
            <CatIcon name={analyzing ? "refresh-cw" : "image-plus"} className={cn("h-5 w-5", analyzing && "animate-spin")} />
          </span>
          <span className="text-[12.5px] font-extrabold text-slate-600 dark:text-slate-300">
            {analyzing ? t("siteLogoAnalyzing") : t("siteLogoTitle")}
          </span>
          <span className="max-w-xs text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("siteLogoDropHint")}
          </span>
        </button>
      )}

      <p className="text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
        {t("siteLogoHint")}
      </p>
    </div>
  );
}

/** The brand identity card: uploader + appears-in badges + instant save. */
function BrandIdentityCard({ instance }: { instance: InstanceDTO }) {
  const { t } = useT();
  const queryClient = useQueryClient();

  const siteQuery = useQuery({
    queryKey: ["site", instance.id],
    queryFn: () => fetchSite(instance.id),
    staleTime: 30_000,
  });

  const saveLogo = useMutation({
    mutationFn: (logoUrl: string) => {
      const site = siteQuery.data;
      if (!site) throw new Error("Site not loaded yet");
      /* ROUND 87 — PATCH-ONLY payload: exactly the field this card owns.
       * The server merge-keeps every absent field, so a stale snapshot of
       * the rest of the content can never revert another surface's choices
       * (the root cause of the owner's "saved but not applied" report). */
      return updateSite(instance.id, { content: { logoUrl } });
    },
    onSuccess: (_data, logoUrl) => {
      toast.success(t(logoUrl ? "brandSavedToast" : "brandRemovedToast"));
      void queryClient.invalidateQueries({ queryKey: ["site", instance.id] });
      /* the instance DTO's site summary carries the logo → refetch so the
       * dashboard header + every consumer updates immediately */
      void queryClient.invalidateQueries({ queryKey: ["instance", instance.id] });
      void queryClient.invalidateQueries({ queryKey: ["instances"] });
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  const logoUrl = siteQuery.data?.content.logoUrl ?? "";

  return (
    <DashCard title={t("brandTitle")} icon="sparkles">
      <div className="space-y-4">
        <p className="max-w-2xl text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
          {t("brandDesc")}
        </p>

        <LogoUploader value={logoUrl} onChange={(next) => saveLogo.mutate(next)} />

        {/* ROUND 67 — live browser-tab preview: a miniature tab strip showing
            exactly how the identity renders in the browser — the CIRCULAR
            favicon composed server-side (/favicon.png) + the org name. The
            rev parameter re-fetches the moment the logo changes. */}
        <div className="rounded-2xl border border-slate-200 bg-slate-50/60 p-4 dark:border-white/10 dark:bg-white/[0.03]">
          <p className="flex items-center gap-1.5 text-[11px] font-extrabold text-slate-500 dark:text-slate-400">
            <CatIcon name="eye" className="h-3.5 w-3.5" />
            {t("brandFaviconPreview")}
          </p>
          {/* mini browser chrome */}
          <div className="mt-3 overflow-hidden rounded-xl border border-slate-200 bg-slate-100 dark:border-white/10 dark:bg-ink-950">
            <div className="flex items-end gap-1 px-2 pt-2" dir="ltr">
              <div className="flex min-w-0 max-w-[220px] items-center gap-2 rounded-t-lg border-b-0 border border-slate-200 bg-white px-3 py-1.5 dark:border-white/10 dark:bg-ink-900">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={`/api/instances/${instance.id}/favicon.png?rev=${encodeURIComponent(logoUrl || "none")}`}
                  alt=""
                  className="h-4 w-4 shrink-0 rounded-full object-contain"
                />
                <span className="min-w-0 truncate text-[11px] font-bold text-slate-700 dark:text-slate-200">
                  {instance.org.name || "Ashrilogic"}
                </span>
                <CatIcon name="x" className="h-3 w-3 shrink-0 text-slate-300 dark:text-slate-600" />
              </div>
              <span className="grid h-7 w-7 shrink-0 place-items-center rounded-t-lg text-slate-400">
                <CatIcon name="plus" className="h-3.5 w-3.5" />
              </span>
            </div>
            <div className="h-9 border-t border-slate-200 bg-white dark:border-white/10 dark:bg-ink-900">
              <div className="mx-auto mt-1.5 h-1.5 w-1/2 rounded-full bg-slate-100 dark:bg-white/10" />
            </div>
          </div>
          <p className="mt-2.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("brandFaviconPreviewHint")}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {(["brandInDash", "brandInSite", "brandInStore", "brandFavicon"] as const).map((key, i) => (
            <span
              key={key}
              className="inline-flex items-center gap-1.5 rounded-full border border-brand-300/60 bg-brand-500/[0.07] px-3 py-1 text-[10.5px] font-extrabold text-brand-600 dark:border-brand-500/40 dark:bg-brand-500/10 dark:text-brand-300"
            >
              <CatIcon
                name={i === 0 ? "gauge" : i === 1 ? "globe" : i === 2 ? "store" : "bookmark"}
                className="h-3 w-3"
              />
              {t(key)}
            </span>
          ))}
          <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-300/60 bg-emerald-500/[0.08] px-3 py-1 text-[10.5px] font-extrabold text-emerald-600 dark:border-emerald-500/40 dark:bg-emerald-500/10 dark:text-emerald-300">
            <CatIcon name="shield-check" className="h-3 w-3" />
            {t("brandIsolated")}
          </span>
        </div>

        {saveLogo.isPending ? (
          <p className="flex items-center gap-2 text-[11px] font-bold text-brand-600 dark:text-brand-300">
            <CatIcon name="refresh-cw" className="h-3.5 w-3.5 animate-spin" />
            {t("siteLogoAnalyzing")}
          </p>
        ) : null}
      </div>
    </DashCard>
  );
}

/* ================================================================== */
/* ROUND 67 — invoice signature & stamp branding. Two premium upload  */
/* fields (official signature + official stamp) with per-asset size   */
/* adjustment sliders and a LIVE invoice-footer preview — everything  */
/* renders on every printed document across all systems.             */
/* ================================================================== */

/** One invoice asset field: upload (validated client-side through the same
 *  analyzeImage pipeline as the logo), preview tile, scale slider and
 *  remove — saving persists the managed ref + scale together.
 *
 *  ROUND 86 (directive ⑤) — THE SCALE SLIDER LATENCY FIX: the slider used to
 *  fire a full-content server PATCH on EVERY intermediate drag tick, and its
 *  value was bound to the SERVER state (which only landed after the network
 *  round-trip) — the thumb visibly lagged/snapped-back mid-drag. Now the
 *  parent (InvoiceBrandingCard) holds a LIVED scale: onValueChange updates
 *  it instantly (pure local state — the thumb, the tile and the footer
 *  preview all follow in the same frame), and onValueCommit — which Radix
 *  fires on POINTER RELEASE / keyboard commit — performs exactly ONE save. */
function InvoiceAssetField({
  label,
  icon,
  c1,
  c2,
  value,
  scale,
  onPick,
  onScale,
  onScaleLive,
  onRemove,
  busy,
}: {
  label: string;
  icon: string;
  c1: string;
  c2: string;
  value: string;
  scale: number;
  onPick: (file: File) => void;
  onScale: (next: number) => void;
  onScaleLive: (next: number) => void;
  onRemove: () => void;
  busy: boolean;
}) {
  const { t, lang } = useT();
  const inputRef = useRef<HTMLInputElement>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [dragOver, setDragOver] = useState(false);

  const process = async (file: File | undefined | null) => {
    if (!file) return;
    setAnalyzing(true);
    onPick(file);
    /* the parent controls the actual analyze+save; mirror its pending state
       for the duration of the local animation */
    window.setTimeout(() => setAnalyzing(false), 350);
  };

  const pct = Math.round(scale * 100);

  return (
    <div className="rounded-2xl border border-slate-200 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]">
      <input
        ref={inputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp,image/gif"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) void process(f);
          e.target.value = "";
        }}
      />

      <div className="flex items-center gap-2.5">
        <span
          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg"
          style={{ backgroundImage: `linear-gradient(135deg,${c1},${c2})` }}
          aria-hidden="true"
        >
          <CatIcon name={icon} className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">{label}</p>
          <p className="mt-0.5 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
            {t("invUploadHint")}
          </p>
        </div>
        {value ? (
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={onRemove}
            className="h-8 gap-1.5 rounded-xl px-3 text-[11.5px] font-bold text-rose-500 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-500/10"
          >
            <CatIcon name="trash" className="h-3.5 w-3.5" />
            {t("siteLogoRemove")}
          </Button>
        ) : null}
      </div>

      {value ? (
        <div className="mt-3 flex items-center gap-4">
          {/* the asset tile — rendered exactly like the invoice footer will
              print it (object-contain, scale applied to the height) */}
          <div className="grid h-20 w-28 shrink-0 place-items-center overflow-hidden rounded-xl border border-dashed border-slate-300 bg-white dark:border-white/20 dark:bg-white/[0.04]">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={value}
              alt=""
              className="max-h-full max-w-full object-contain"
              style={{ transform: `scale(${scale})` }}
            />
          </div>
          {/* scale slider — ROUND 86: live local drag, ONE save on release */}
          <div className="min-w-0 flex-1">
            <div className="flex items-center justify-between gap-2">
              <Label className="text-[10.5px] font-extrabold text-slate-500 dark:text-slate-400">
                {t("invScale")}
              </Label>
              <span
                dir="ltr"
                className="rounded-full bg-slate-100 px-2 py-0.5 text-[10.5px] font-extrabold tabular-nums text-slate-600 dark:bg-white/10 dark:text-slate-300"
              >
                {fmtNum(pct, lang)}%
              </span>
            </div>
            <Slider
              dir="ltr"
              value={[scale]}
              min={0.4}
              max={2.4}
              step={0.05}
              onValueChange={(v) => onScaleLive(v[0] ?? 1)}
              onValueCommit={(v) => onScale(v[0] ?? 1)}
              className="mt-2"
              aria-label={t("invScale")}
            />
            <p className="mt-1.5 text-[10px] font-semibold text-slate-400 dark:text-slate-500">
              {t("invScaleHint")}
            </p>
          </div>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          disabled={analyzing || busy}
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            const f = e.dataTransfer.files?.[0];
            if (f) void process(f);
          }}
          className={cn(
            "mt-3 flex w-full flex-col items-center gap-1.5 rounded-2xl border-2 border-dashed px-4 py-6 text-center transition disabled:opacity-60",
            dragOver
              ? "border-brand-400 bg-brand-50/60 dark:border-brand-500/50 dark:bg-brand-500/10"
              : "border-slate-200 bg-slate-50/40 hover:border-brand-300 hover:bg-brand-50/30 dark:border-white/10 dark:bg-white/[0.02] dark:hover:border-brand-500/40"
          )}
        >
          <span
            className={cn("grid h-9 w-9 place-items-center rounded-xl text-white shadow-lg", (analyzing || busy) && "animate-pulse")}
            style={{ backgroundImage: `linear-gradient(135deg,${c1},${c2})` }}
            aria-hidden="true"
          >
            <CatIcon
              name={analyzing || busy ? "refresh-cw" : "upload"}
              className={cn("h-4 w-4", (analyzing || busy) && "animate-spin")}
            />
          </span>
          <span className="text-[12px] font-extrabold text-slate-600 dark:text-slate-300">
            {analyzing || busy ? t("siteLogoAnalyzing") : t("siteLogoTitle")}
          </span>
        </button>
      )}
    </div>
  );
}

/** ROUND 68 — invoice-code PREFIX field: owner-configured prefix with a
 *  live numbering preview ({PREFIX}-{year}-0000001). Remounts (key = stored
 *  value) after each save so the draft reseeds from the persisted state. */
function InvoicePrefixField({
  value,
  onSave,
  busy,
}: {
  value: string;
  onSave: (prefix: string) => void;
  busy: boolean;
}) {
  const { t } = useT();
  const [draft, setDraft] = useState(value);

  const normalized = draft.trim().toUpperCase().slice(0, 12);
  const valid = /^[A-Z0-9-]*$/.test(normalized);
  const dirty = normalized !== value;

  return (
    <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 dark:border-white/10 dark:bg-white/[0.03]">
      <p className="flex flex-wrap items-center gap-2 text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
        <span
          className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-white"
          style={{ backgroundImage: "linear-gradient(135deg,#6d5dfb,#d946ef)" }}
          aria-hidden="true"
        >
          <CatIcon name="hash" className="h-3.5 w-3.5" />
        </span>
        {t("invPrefixTitle")}
      </p>
      <p className="mt-1.5 max-w-xl text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
        {t("invPrefixDesc")}
      </p>

      <div className="mt-3 flex flex-wrap items-end gap-3">
        <div className="min-w-[180px] flex-1">
          <Label htmlFor="inv-prefix-input" className={WZ_LABEL}>
            {t("invPrefixLabel")}
          </Label>
          <Input
            id="inv-prefix-input"
            dir="ltr"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && valid && dirty) onSave(normalized);
            }}
            placeholder={t("invPrefixPh")}
            maxLength={12}
            className={`${WZ_INPUT} font-mono uppercase tracking-wider text-start ${!valid ? "border-rose-400 focus-visible:ring-rose-500/20" : ""}`}
            aria-invalid={!valid || undefined}
            autoComplete="off"
            spellCheck={false}
          />
          {!valid ? (
            <p className="mt-1.5 flex items-center gap-1.5 text-[11px] font-bold text-rose-500 dark:text-rose-400">
              <CatIcon name="circle-alert" className="h-3 w-3" />
              {t("invPrefixErr")}
            </p>
          ) : null}
        </div>

        {/* live numbering preview */}
        <div className="min-w-0 flex items-center gap-2.5 rounded-xl border border-slate-200 bg-slate-50/80 px-3.5 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
          <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            {t("invPrefixPreview")}
          </span>
          <span
            dir="ltr"
            className="rounded-lg bg-white px-2.5 py-1 font-mono text-[12px] font-bold text-slate-700 shadow-sm dark:bg-[#0b1220] dark:text-slate-200"
          >
            {formatInvoiceCode(normalized || DEFAULT_INVOICE_PREFIX, 1)}
          </span>
        </div>

        <Button
          type="button"
          disabled={busy || !valid || !dirty}
          onClick={() => onSave(normalized)}
          className="h-11 shrink-0 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
        >
          {busy ? (
            <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
          ) : (
            <CatIcon name="check" className="h-4 w-4" />
          )}
          {t("profileSave")}
        </Button>
      </div>
    </div>
  );
}

/** The invoice branding card: signature + stamp fields, scale sliders, the
 *  ROUND 68 invoice-code PREFIX field and a live footer preview mirroring
 *  the printed document. ROUND 86 (directive ⑤): the scales are LIFTED here
 *  as live local state — the slider follows the drag instantly and exactly
 *  ONE server save happens on release (see InvoiceAssetField). */
function InvoiceBrandingCard({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();

  const siteQuery = useQuery({
    queryKey: ["site", instance.id],
    queryFn: () => fetchSite(instance.id),
    staleTime: 30_000,
  });

  /* ROUND 86 — the LIVE scales: local overrides while the owner drags (or
   * until the saved value lands); `null` = trust the server value. */
  const [liveScales, setLiveScales] = useState<{ sig?: number; stamp?: number }>({});

  const saveAssets = useMutation({
    mutationFn: async (patch: {
      signatureUrl?: string;
      stampUrl?: string;
      signatureScale?: number;
      stampScale?: number;
      invoicePrefix?: string;
    }) => {
      const site = siteQuery.data;
      if (!site) throw new Error("Site not loaded yet");
      /* ROUND 87 — PATCH-ONLY payload: exactly the fields this card owns
         (present keys only). The server merge-keeps every absent field, so
         a stale snapshot can never revert another surface's choices. */
      const content: Partial<SiteContent> = {};
      if (patch.signatureUrl !== undefined) content.signatureUrl = patch.signatureUrl;
      if (patch.stampUrl !== undefined) content.stampUrl = patch.stampUrl;
      if (patch.signatureScale !== undefined) content.signatureScale = patch.signatureScale;
      if (patch.stampScale !== undefined) content.stampScale = patch.stampScale;
      if (patch.invoicePrefix !== undefined) content.invoicePrefix = patch.invoicePrefix;
      return updateSite(instance.id, { content });
    },
    onSuccess: (_data, patch) => {
      toast.success(
        patch.invoicePrefix !== undefined
          ? t("invPrefixSavedToast")
          : "signatureUrl" in patch && patch.signatureUrl === ""
            ? t("invRemovedToast")
            : t("invSavedToast")
      );
      /* the saved value is now authoritative — drop the live overrides so
         the fields re-bind to the server state */
      setLiveScales({});
      void queryClient.invalidateQueries({ queryKey: ["site", instance.id] });
      void queryClient.invalidateQueries({ queryKey: ["instance", instance.id] });
    },
    onError: (error: Error) => {
      /* the save failed — fall back to the last PERSISTED scales */
      setLiveScales({});
      toast.error(`${t("errorText")}: ${error.message}`);
    },
  });

  /** analyze the picked file client-side, then persist the data-URL (the
   *  server re-validates + stores it as a managed image ref). */
  const pick = async (field: "signatureUrl" | "stampUrl", file: File) => {
    try {
      const result = await analyzeImage(file, {
        outputSize: 384,
        outputSizeSmall: 224,
        targetBytes: 380 * 1024,
      });
      if (field === "signatureUrl") saveAssets.mutate({ signatureUrl: result.dataUrl });
      else saveAssets.mutate({ stampUrl: result.dataUrl });
    } catch (error) {
      const code = error instanceof ImageAnalysisError ? error.code : "corrupt";
      const key: I18nKey =
        code === "bad-type"
          ? "siteLogoBadType"
          : code === "too-large"
            ? "siteLogoTooLarge"
            : code === "tiny"
              ? "siteLogoTiny"
              : "siteLogoCorrupt";
      toast.error(t(key));
    }
  };

  const content = siteQuery.data?.content;
  const signatureUrl = content?.signatureUrl ?? "";
  const stampUrl = content?.stampUrl ?? "";
  /* ROUND 86 — live scales win while dragging (instant preview in the tile,
   * the slider thumb AND the footer mirror); the server value re-binds after
   * the save lands. */
  const signatureScale = liveScales.sig ?? content?.signatureScale ?? 1;
  const stampScale = liveScales.stamp ?? content?.stampScale ?? 1;

  return (
    <DashCard title={t("invTitle")} icon="stamp">
      <div className="space-y-4">
        <p className="max-w-2xl text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
          {t("invDesc")}
        </p>

        {/* ROUND 68 — invoice-code prefix ("" = module default INV) */}
        {siteQuery.isPending ? (
          <Skeleton className="h-32 rounded-2xl" />
        ) : (
          <InvoicePrefixField
            key={content?.invoicePrefix ?? ""}
            value={content?.invoicePrefix ?? ""}
            busy={saveAssets.isPending}
            onSave={(prefix) => saveAssets.mutate({ invoicePrefix: prefix })}
          />
        )}

        {siteQuery.isPending ? (
          <div className="grid gap-4 sm:grid-cols-2">
            <Skeleton className="h-40 rounded-2xl" />
            <Skeleton className="h-40 rounded-2xl" />
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2">
            <InvoiceAssetField
              label={t("invSignatureTitle")}
              icon="pen-line"
              c1="#6d5dfb"
              c2="#8b5cf6"
              value={signatureUrl}
              scale={signatureScale}
              onPick={(f) => void pick("signatureUrl", f)}
              onScale={(s) => saveAssets.mutate({ signatureScale: s })}
              onScaleLive={(s) => setLiveScales((v) => ({ ...v, sig: s }))}
              onRemove={() => saveAssets.mutate({ signatureUrl: "" })}
              busy={saveAssets.isPending}
            />
            <InvoiceAssetField
              label={t("invStampTitle")}
              icon="stamp"
              c1="#d946ef"
              c2="#f43f5e"
              value={stampUrl}
              scale={stampScale}
              onPick={(f) => void pick("stampUrl", f)}
              onScale={(s) => saveAssets.mutate({ stampScale: s })}
              onScaleLive={(s) => setLiveScales((v) => ({ ...v, stamp: s }))}
              onRemove={() => saveAssets.mutate({ stampUrl: "" })}
              busy={saveAssets.isPending}
            />
          </div>
        )}

        {/* live invoice-footer preview — mirrors the printed document's
            signature row exactly (same composition + scales) */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/[0.03]">
          <p className="flex items-center gap-1.5 text-[11px] font-extrabold text-slate-500 dark:text-slate-400">
            <CatIcon name="eye" className="h-3.5 w-3.5" />
            {t("invPreviewTitle")}
          </p>
          <div className="mt-3 rounded-xl border border-slate-200 bg-white p-5 dark:border-white/10" dir={lang === "ar" ? "rtl" : "ltr"}>
            <div className="flex items-end justify-between gap-8">
              <div className="min-w-0 flex-1 text-center">
                {signatureUrl ? (
                  <div className="grid h-20 place-items-center">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={signatureUrl}
                      alt=""
                      className="max-h-full max-w-[180px] object-contain"
                      style={{ transform: `scale(${signatureScale})` }}
                    />
                  </div>
                ) : (
                  <div className="h-20" />
                )}
                <p className="mt-1 text-[10.5px] font-extrabold text-slate-500">
                  {t("printSignatureLabel")}
                </p>
                <div className="mx-auto mt-2 h-px w-40 bg-slate-300 dark:bg-white/20" aria-hidden="true" />
              </div>
              <div className="min-w-0 flex-1 text-center">
                {stampUrl ? (
                  <div className="grid h-20 place-items-center">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={stampUrl}
                      alt=""
                      className="max-h-full max-w-[180px] object-contain"
                      style={{ transform: `scale(${stampScale})` }}
                    />
                  </div>
                ) : (
                  <div className="grid h-20 place-items-center">
                    <span className="grid h-16 w-16 place-items-center rounded-full border-2 border-dashed border-slate-200 text-slate-300 dark:border-white/15 dark:text-slate-600">
                      <CatIcon name="stamp" className="h-6 w-6" />
                    </span>
                  </div>
                )}
                <p className="mt-1 text-[10.5px] font-extrabold text-slate-500">
                  {t("printStampLabel")}
                </p>
                <div className="mx-auto mt-2 h-px w-40 bg-slate-300 dark:bg-white/20" aria-hidden="true" />
              </div>
            </div>
          </div>
          <p className="mt-2.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("invPreviewNote")}
          </p>
        </div>

        {saveAssets.isPending ? (
          <p className="flex items-center gap-2 text-[11px] font-bold text-brand-600 dark:text-brand-300">
            <CatIcon name="refresh-cw" className="h-3.5 w-3.5 animate-spin" />
            {t("siteLogoAnalyzing")}
          </p>
        ) : null}
      </div>
    </DashCard>
  );
}

/* ================================================================== */
/* ROUND 86 — الألوان والخطوط (colors & fonts tab, directives ②+③)     */
/* The owner demanded SEPARATE color & font control per surface:       */
/*   • الموقع العام    — Site.theme (migrated from the website editor)  */
/*                      + content.siteFont                              */
/*   • المتجر الإلكتروني — content.storeTheme ("" = follow the site)     */
/*                      + content.storeFont                             */
/*   • النظام (لوحة التحكم) — content.dashTheme + content.dashFont     */
/* Every pick saves INSTANTLY (one mutation, merge-keep server-side)   */
/* and applies live across the surfaces.                               */
/* ================================================================== */

/** One gradient theme swatch — ROUND 88 REDESIGN: every swatch is now a
 *  LABELED COLUMN (gradient tile + its name in a fixed slot beneath it),
 *  replacing the round-86 floating text badge that rendered «زمردي -
 *  مطابق لنظامك» OUTSIDE the 44px tile and OVERLAPPED the rows below it
 *  (the owner-reported تداخل نصوص). The "matched your system" hint is a
 *  tiny star pin INSIDE the tile's corner + the full sentence in the
 *  tooltip; the selected swatch keeps its ring + check; the "follow the
 *  website" option keeps its dashed link tile + its own label. Nothing
 *  is absolutely positioned outside the column — overlap is structurally
 *  impossible now, in RTL and LTR alike. */
function StyleSwatch({
  active,
  c1,
  c2,
  title,
  label,
  matched,
  follow,
  onClick,
  disabled,
  ariaLabel,
}: {
  active: boolean;
  c1: string;
  c2: string;
  title: string;
  /** short name rendered UNDER the tile (theme label / follow hint) */
  label: string;
  matched?: boolean;
  follow?: boolean;
  onClick: () => void;
  disabled?: boolean;
  ariaLabel: string;
}) {
  return (
    <div className="flex w-14 shrink-0 flex-col items-center gap-1.5">
      <button
        type="button"
        onClick={onClick}
        disabled={disabled}
        aria-pressed={active}
        aria-label={ariaLabel}
        title={title}
        className={cn(
          "group relative h-11 w-11 rounded-2xl transition disabled:opacity-60",
          active
            ? "ring-2 ring-brand-500 ring-offset-2 ring-offset-white dark:ring-offset-ink-950"
            : "hover:scale-105",
        )}
        style={
          follow
            ? undefined
            : { backgroundImage: `linear-gradient(135deg,${c1},${c2})` }
        }
      >
        {follow ? (
          /* the "follow the website" option — a dashed link tile tinted with
             the SITE's current gradient (what the store will actually show) */
          <span
            className="grid h-full w-full place-items-center rounded-2xl border-2 border-dashed border-slate-300 dark:border-white/25"
            style={{ backgroundImage: `linear-gradient(135deg,${c1}22,${c2}22)` }}
          >
            <CatIcon name="link" className="h-4 w-4 text-slate-500 dark:text-slate-300" />
          </span>
        ) : null}
        {active && !follow ? (
          <CatIcon name="check" className="mx-auto h-4 w-4 text-white" />
        ) : null}
        {/* matched-your-system pin — a tiny star chip clipped INSIDE the
            tile's top corner: informative, premium, zero overflow */}
        {matched ? (
          <span
            aria-hidden="true"
            className="absolute top-1 end-1 grid h-4 w-4 place-items-center rounded-full bg-white/90 shadow-sm backdrop-blur dark:bg-ink-900/90"
          >
            <CatIcon name="star" className="h-2.5 w-2.5 fill-brand-500 text-brand-500" />
          </span>
        ) : null}
      </button>
      <span
        className="max-w-full truncate text-[10px] font-extrabold leading-none text-slate-500 dark:text-slate-400"
        title={title}
      >
        {label}
      </span>
    </div>
  );
}

/** One font option card — renders its OWN font stack so the preview IS the
 *  choice (name + bilingual sample line in that typeface). */
function FontChoice({
  active,
  label,
  sample,
  stack,
  onClick,
  disabled,
}: {
  active: boolean;
  label: string;
  sample: string;
  /** the stack this option renders in; undefined = platform default */
  stack?: string;
  onClick: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-pressed={active}
      className={cn(
        "group flex flex-col items-start gap-1 rounded-2xl border p-3 text-start transition disabled:opacity-60",
        active
          ? "border-brand-400 bg-brand-50/60 shadow-md shadow-brand-500/10 dark:border-brand-500/50 dark:bg-brand-500/10"
          : "border-slate-200 bg-white/60 hover:border-brand-300 hover:bg-brand-50/30 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-brand-500/40 dark:hover:bg-white/[0.06]"
      )}
      style={stack ? { fontFamily: stack } : undefined}
    >
      <span className="flex w-full items-center justify-between gap-2">
        <span className="text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
          {label}
        </span>
        {active ? (
          <CatIcon name="check" className="h-3.5 w-3.5 shrink-0 text-brand-600 dark:text-brand-300" />
        ) : null}
      </span>
      <span
        dir="auto"
        className="line-clamp-1 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500"
      >
        {sample}
      </span>
    </button>
  );
}

/** One surface section inside the colors & fonts tab (theme swatches +
 *  font choices + a hint line). */
function StyleSurfaceSection({
  icon,
  c1,
  c2,
  title,
  desc,
  children,
  pending,
}: {
  icon: string;
  c1: string;
  c2: string;
  title: string;
  desc: string;
  children: React.ReactNode;
  pending?: boolean;
}) {
  return (
    <section className="relative overflow-hidden rounded-3xl border border-slate-200 bg-white/70 p-5 shadow-soft dark:border-white/10 dark:bg-white/[0.03]">
      <span
        aria-hidden="true"
        className="pointer-events-none absolute -top-12 -start-12 h-32 w-32 rounded-full blur-2xl"
        style={{ backgroundColor: c1, opacity: 0.14 }}
      />
      <div className="relative">
        <div className="flex items-start gap-3">
          <span
            className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
            style={{ backgroundImage: `linear-gradient(135deg,${c1},${c2})` }}
            aria-hidden="true"
          >
            <CatIcon name={icon} className="h-[17px] w-[17px]" />
          </span>
          <div className="min-w-0">
            <h3 className="font-display text-[14px] font-extrabold text-slate-900 dark:text-white">
              {title}
            </h3>
            <p className="mt-0.5 text-[11px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
              {desc}
            </p>
          </div>
          {pending ? (
            <CatIcon
              name="refresh-cw"
              className="ms-auto h-4 w-4 shrink-0 animate-spin text-brand-500"
            />
          ) : null}
        </div>
        <div className="mt-4 space-y-4">{children}</div>
      </div>
    </section>
  );
}

/** Section label (theme / font) rendered between the control rows. */
function StyleControlLabel({ children }: { children: React.ReactNode }) {
  return (
    <p className="text-[10.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
      {children}
    </p>
  );
}

/** ROUND 86 — the WHOLE colors & fonts tab: three independent surface
 *  sections, every pick saving instantly. */
function ColorsFontsCard({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();

  const siteQuery = useQuery({
    queryKey: ["site", instance.id],
    queryFn: () => fetchSite(instance.id),
    staleTime: 30_000,
  });

  /* the theme that MATCHES this workspace's system sector (picker badge) */
  const matchedTheme = categoryTheme(SYSTEM_MAP[instance.systemId]?.c);

  const saveStyle = useMutation({
    mutationFn: async (patch: {
      theme?: string;
      storeTheme?: string;
      siteFont?: string;
      storeFont?: string;
      dashTheme?: string;
      dashFont?: string;
    }) => {
      const site = siteQuery.data;
      if (!site) throw new Error("Site not loaded yet");
      const payload: SitePayload = {};
      if (patch.theme !== undefined) payload.theme = patch.theme;
      /* ROUND 87 — PATCH-ONLY content: exactly the styling keys this card
         owns, ABSENT keys dropped (undefined values are stripped so the
         server merge-keeps their stored values). A stale snapshot of the
         rest of the content can never revert another surface's choices —
         the root cause of the "تم الحفظ لكنه لا يُطبَّق" report. */
      const contentPatch: Record<string, string> = {};
      if (patch.storeTheme !== undefined) contentPatch.storeTheme = patch.storeTheme;
      if (patch.siteFont !== undefined) contentPatch.siteFont = patch.siteFont;
      if (patch.storeFont !== undefined) contentPatch.storeFont = patch.storeFont;
      if (patch.dashTheme !== undefined) contentPatch.dashTheme = patch.dashTheme;
      if (patch.dashFont !== undefined) contentPatch.dashFont = patch.dashFont;
      if (Object.keys(contentPatch).length > 0) {
        payload.content = contentPatch as unknown as SiteContent;
      }
      return updateSite(instance.id, payload);
    },
    onSuccess: () => {
      toast.success(t("cfsSavedToast"));
      /* ["instance"] too — the dashboard shell + store projections re-read
         the accent/font choices from the instance summary */
      void queryClient.invalidateQueries({ queryKey: ["site", instance.id] });
      void queryClient.invalidateQueries({ queryKey: ["instance", instance.id] });
    },
    onError: (error: Error) => toast.error(`${t("cfsSaveErr")}: ${error.message}`),
  });

  if (siteQuery.isPending || !siteQuery.data) {
    return (
      <div className="grid gap-4 lg:grid-cols-3">
        <Skeleton className="h-72 rounded-3xl" />
        <Skeleton className="h-72 rounded-3xl" />
        <Skeleton className="h-72 rounded-3xl" />
      </div>
    );
  }

  const site = siteQuery.data;
  const siteThemeKey = site.theme;
  const siteFont = site.content.siteFont ?? "";
  const storeThemeKey = site.content.storeTheme ?? "";
  const storeFont = site.content.storeFont ?? "";
  const dashThemeKey = site.content.dashTheme ?? "";
  const dashFont = site.content.dashFont ?? "";
  const busy = saveStyle.isPending;
  const cur = siteTheme(siteThemeKey);

  return (
    <div className="space-y-4">
      {/* the tab's own heading strip */}
      <div className="relative overflow-hidden rounded-3xl border border-slate-200 bg-linear-to-l from-brand-50/80 via-fuchsia-50/40 to-transparent p-5 dark:border-white/10 dark:from-brand-500/10 dark:via-fuchsia-500/5 dark:to-transparent">
        <div className="flex items-start gap-3.5">
          <span
            className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
            style={{ backgroundImage: grad("#6d5dfb", "#d946ef") }}
            aria-hidden="true"
          >
            <CatIcon name="palette" className="h-5 w-5" />
          </span>
          <div className="min-w-0">
            <h2 className="font-display text-[15.5px] font-extrabold text-slate-900 dark:text-white">
              {t("cfsTitle")}
            </h2>
            <p className="mt-0.5 max-w-2xl text-[12px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
              {t("cfsDesc")}
            </p>
          </div>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        {/* ---------------- الموقع العام (public website) ---------------- */}
        <StyleSurfaceSection
          icon="globe"
          c1={cur.c1}
          c2={cur.c2}
          title={t("cfsSiteTitle")}
          desc={t("cfsSiteDesc")}
          pending={busy}
        >
          <div>
            <StyleControlLabel>{t("cfsThemeLabel")}</StyleControlLabel>
            <div className="mt-2 flex flex-wrap gap-1.5 gap-y-3">
              {SITE_THEMES.map((swatch) => (
                <StyleSwatch
                  key={swatch.key}
                  active={siteThemeKey === swatch.key}
                  c1={swatch.c1}
                  c2={swatch.c2}
                  label={lang === "ar" ? swatch.labelAr : swatch.labelEn}
                  title={
                    (lang === "ar" ? swatch.labelAr : swatch.labelEn) +
                    (matchedTheme === swatch.key ? ` · ${t("siteThemeMatched")}` : "")
                  }
                  matched={matchedTheme === swatch.key}
                  ariaLabel={
                    (lang === "ar" ? swatch.labelAr : swatch.labelEn) +
                    (matchedTheme === swatch.key ? ` · ${t("siteThemeMatched")}` : "")
                  }
                  onClick={() => saveStyle.mutate({ theme: swatch.key })}
                  disabled={busy}
                />
              ))}
            </div>
            {matchedTheme ? (
              <p className="mt-2.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                <span className="inline-flex items-center gap-1 rounded-full bg-brand-500/10 px-2 py-0.5 text-brand-600 dark:bg-brand-500/15 dark:text-brand-300">
                  <CatIcon name="star" className="h-2.5 w-2.5 fill-current" />
                  {lang === "ar" ? siteTheme(matchedTheme).labelAr : siteTheme(matchedTheme).labelEn} · {t("siteThemeMatched")}
                </span>
              </p>
            ) : null}
            <p className="mt-1.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {t("siteThemeHint")}
            </p>
          </div>
          <div>
            <StyleControlLabel>{t("cfsFontLabel")}</StyleControlLabel>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <FontChoice
                active={siteFont === ""}
                label={t("cfsFontDefault")}
                sample={t("cfsFontSample")}
                onClick={() => saveStyle.mutate({ siteFont: "" })}
                disabled={busy}
              />
              {SURFACE_FONTS.map((font) => (
                <FontChoice
                  key={font.key}
                  active={siteFont === font.key}
                  label={lang === "ar" ? font.labelAr : font.labelEn}
                  sample={t("cfsFontSample")}
                  stack={font.sans}
                  onClick={() => saveStyle.mutate({ siteFont: font.key })}
                  disabled={busy}
                />
              ))}
            </div>
          </div>
        </StyleSurfaceSection>

        {/* ---------------- المتجر الإلكتروني (e-store) ---------------- */}
        <StyleSurfaceSection
          icon="shopping-bag"
          c1={(storeThemeKey ? siteTheme(storeThemeKey).c1 : cur.c1)}
          c2={(storeThemeKey ? siteTheme(storeThemeKey).c2 : cur.c2)}
          title={t("cfsStoreTitle")}
          desc={t("cfsStoreDesc")}
          pending={busy}
        >
          <div>
            <StyleControlLabel>{t("cfsThemeLabel")}</StyleControlLabel>
            <div className="mt-2 flex flex-wrap gap-1.5 gap-y-3">
              <StyleSwatch
                active={storeThemeKey === ""}
                c1={cur.c1}
                c2={cur.c2}
                label={t("cfsThemeFollow")}
                title={t("cfsThemeFollow")}
                follow
                ariaLabel={t("cfsThemeFollow")}
                onClick={() => saveStyle.mutate({ storeTheme: "" })}
                disabled={busy}
              />
              {SITE_THEMES.map((swatch) => (
                <StyleSwatch
                  key={swatch.key}
                  active={storeThemeKey === swatch.key}
                  c1={swatch.c1}
                  c2={swatch.c2}
                  label={lang === "ar" ? swatch.labelAr : swatch.labelEn}
                  title={lang === "ar" ? swatch.labelAr : swatch.labelEn}
                  ariaLabel={lang === "ar" ? swatch.labelAr : swatch.labelEn}
                  onClick={() => saveStyle.mutate({ storeTheme: swatch.key })}
                  disabled={busy}
                />
              ))}
            </div>
            <p className="mt-2.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {storeThemeKey === "" ? t("cfsThemeFollow") : null}
            </p>
          </div>
          <div>
            <StyleControlLabel>{t("cfsFontLabel")}</StyleControlLabel>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <FontChoice
                active={storeFont === ""}
                label={t("cfsFontDefault")}
                sample={t("cfsFontSample")}
                onClick={() => saveStyle.mutate({ storeFont: "" })}
                disabled={busy}
              />
              {SURFACE_FONTS.map((font) => (
                <FontChoice
                  key={font.key}
                  active={storeFont === font.key}
                  label={lang === "ar" ? font.labelAr : font.labelEn}
                  sample={t("cfsFontSample")}
                  stack={font.sans}
                  onClick={() => saveStyle.mutate({ storeFont: font.key })}
                  disabled={busy}
                />
              ))}
            </div>
          </div>
        </StyleSurfaceSection>

        {/* ---------------- النظام (dashboard / console) ---------------- */}
        <StyleSurfaceSection
          icon="layout-dashboard"
          c1={dashThemeKey ? (DASH_THEMES.find((d) => d.key === dashThemeKey)?.c1 ?? "#6d5dfb") : "#6d5dfb"}
          c2={dashThemeKey ? (DASH_THEMES.find((d) => d.key === dashThemeKey)?.c2 ?? "#5b45e8") : "#5b45e8"}
          title={t("cfsSystemTitle")}
          desc={t("cfsSystemDesc")}
          pending={busy}
        >
          <div>
            <StyleControlLabel>{t("cfsThemeLabel")}</StyleControlLabel>
            <div className="mt-2 flex flex-wrap gap-1.5 gap-y-3">
              {DASH_THEMES.map((d) => (
                <StyleSwatch
                  key={d.key}
                  active={(dashThemeKey || "violet") === d.key}
                  c1={d.c1}
                  c2={d.c2}
                  label={lang === "ar" ? d.labelAr : d.labelEn}
                  title={lang === "ar" ? d.labelAr : d.labelEn}
                  ariaLabel={lang === "ar" ? d.labelAr : d.labelEn}
                  onClick={() => saveStyle.mutate({ dashTheme: d.key })}
                  disabled={busy}
                />
              ))}
            </div>
          </div>
          <div>
            <StyleControlLabel>{t("cfsFontLabel")}</StyleControlLabel>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <FontChoice
                active={dashFont === ""}
                label={t("cfsFontDefault")}
                sample={t("cfsFontSample")}
                onClick={() => saveStyle.mutate({ dashFont: "" })}
                disabled={busy}
              />
              {SURFACE_FONTS.map((font) => (
                <FontChoice
                  key={font.key}
                  active={dashFont === font.key}
                  label={lang === "ar" ? font.labelAr : font.labelEn}
                  sample={t("cfsFontSample")}
                  stack={font.sans}
                  onClick={() => saveStyle.mutate({ dashFont: font.key })}
                  disabled={busy}
                />
              ))}
            </div>
          </div>
        </StyleSurfaceSection>
      </div>
    </div>
  );
}

/* ================================================================== */
/* ROUND 86 (directive ④) — التفضيلات: لغات الزوار                    */
/* The owner picks EXACTLY which languages the public website and the  */
/* e-store offer their visitors (content.siteLangs / content.store-    */
/* Langs — the surface headers' language switchers obey the set).      */
/* ================================================================== */

/** Localized "N languages enabled" with proper Arabic plural rules
 *  (1 لغة / لغتان / ٣–١٠ لغات / ١١+ لغة). */
function langsCountLabel(n: number, lang: Lang, t: ReturnType<typeof useT>["t"]): string {
  if (lang === "ar") {
    if (n === 1) return t("prefsLangsCountSingular");
    if (n === 2) return t("prefsLangsCountDual");
    if (n >= 3 && n <= 10) return t("prefsLangsCountPlural", { n: fmtNum(n, lang) });
    return t("prefsLangsCountEleven", { n: fmtNum(n, lang) });
  }
  return n === 1
    ? t("prefsLangsCountSingular")
    : t("prefsLangsCountPlural", { n: fmtNum(n, lang) });
}

/** One surface's language chip row (toggle = instant save; the last
 *  enabled language can never be turned off). */
function LangsSurfaceRow({
  title,
  icon,
  c1,
  c2,
  langs,
  onToggle,
  onReset,
  busy,
  t,
  lang,
}: {
  title: string;
  icon: string;
  c1: string;
  c2: string;
  langs: string[];
  onToggle: (code: string) => void;
  onReset: () => void;
  busy: boolean;
  t: ReturnType<typeof useT>["t"];
  lang: Lang;
}) {
  const count = langsCountLabel(langs.length, lang, t);
  return (
    <div className="rounded-2xl border border-slate-200 bg-white/70 p-4 dark:border-white/10 dark:bg-white/[0.03]">
      <div className="flex flex-wrap items-center gap-2.5">
        <span
          className="grid h-8 w-8 shrink-0 place-items-center rounded-xl text-white shadow-md"
          style={{ backgroundImage: `linear-gradient(135deg,${c1},${c2})` }}
          aria-hidden="true"
        >
          <CatIcon name={icon} className="h-3.5 w-3.5" />
        </span>
        <p className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">{title}</p>
        <span
          dir={lang === "ar" ? "rtl" : "ltr"}
          className="ms-auto rounded-full bg-brand-50 px-2.5 py-0.5 text-[10.5px] font-extrabold text-brand-700 dark:bg-brand-500/15 dark:text-brand-300"
        >
          {count}
        </span>
        <button
          type="button"
          onClick={onReset}
          disabled={busy}
          className="rounded-lg px-2 py-1 text-[10.5px] font-extrabold text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 disabled:opacity-50 dark:hover:bg-white/10 dark:hover:text-slate-300"
        >
          {t("prefsLangsReset")}
        </button>
      </div>
      <div className="mt-3 flex flex-wrap gap-1.5">
        {LOCALES.map((loc) => {
          const on = langs.includes(loc.code);
          const isLast = on && langs.length === 1;
          return (
            <button
              key={loc.code}
              type="button"
              onClick={() => onToggle(loc.code)}
              disabled={busy || isLast}
              aria-pressed={on}
              title={`${loc.native}${isLast ? ` — ${t("prefsLangsMinHint")}` : ""}`}
              className={cn(
                "inline-flex min-h-9 items-center gap-1.5 rounded-xl border px-2.5 text-[11px] font-extrabold transition disabled:cursor-not-allowed",
                on
                  ? "border-brand-400 bg-brand-50 text-brand-700 shadow-sm dark:border-brand-500/50 dark:bg-brand-500/15 dark:text-brand-300"
                  : "border-slate-200 bg-white text-slate-500 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400 dark:hover:border-brand-500/40 dark:hover:text-brand-300",
                isLast && "opacity-60"
              )}
            >
              <span className="text-[9px] font-black uppercase opacity-70">{loc.short}</span>
              {loc.native}
            </button>
          );
        })}
      </div>
      <p className="mt-2.5 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
        {t("prefsLangsMinHint")}
      </p>
    </div>
  );
}

/** ROUND 86 directive ④ — the visitor-languages card (settings → prefs). */
function VisitorLangsCard({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();

  const siteQuery = useQuery({
    queryKey: ["site", instance.id],
    queryFn: () => fetchSite(instance.id),
    staleTime: 30_000,
  });

  const saveLangs = useMutation({
    mutationFn: async (patch: { siteLangs?: string[]; storeLangs?: string[] }) => {
      const site = siteQuery.data;
      if (!site) throw new Error("Site not loaded yet");
      /* ROUND 87 — PATCH-ONLY payload: exactly the arrays this card owns. */
      const content: Partial<SiteContent> = {};
      if (patch.siteLangs !== undefined) content.siteLangs = patch.siteLangs;
      if (patch.storeLangs !== undefined) content.storeLangs = patch.storeLangs;
      return updateSite(instance.id, { content });
    },
    onSuccess: () => {
      toast.success(t("prefsLangsSavedToast"));
      void queryClient.invalidateQueries({ queryKey: ["site", instance.id] });
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  if (siteQuery.isPending || !siteQuery.data) {
    return (
      <div className="grid gap-4 lg:grid-cols-2">
        <Skeleton className="h-44 rounded-2xl" />
        <Skeleton className="h-44 rounded-2xl" />
      </div>
    );
  }

  const siteLangs = siteQuery.data.content.siteLangs ?? ["ar", "en"];
  const storeLangs = siteQuery.data.content.storeLangs ?? ["ar", "en"];
  const busy = saveLangs.isPending;

  /** toggle one code: removing the LAST language of a surface is refused
   *  (the switcher needs at least one) — the guard lives here so both rows
   *  share the exact rule. */
  const toggle = (current: string[], code: string): string[] | null => {
    if (current.includes(code)) {
      if (current.length <= 1) return null;
      return current.filter((c) => c !== code);
    }
    return [...current, code];
  };

  return (
    <DashCard title={t("prefsLangsTitle")} icon="languages">
      <div className="space-y-4">
        <p className="max-w-3xl text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
          {t("prefsLangsDesc")}
        </p>
        <div className="grid gap-4 lg:grid-cols-2">
          <LangsSurfaceRow
            title={t("prefsLangsSite")}
            icon="globe"
            c1="#6d5dfb"
            c2="#0ea5e9"
            langs={siteLangs}
            busy={busy}
            t={t}
            lang={lang}
            onToggle={(code) => {
              const next = toggle(siteLangs, code);
              if (next) saveLangs.mutate({ siteLangs: next });
            }}
            onReset={() => saveLangs.mutate({ siteLangs: ["ar", "en"] })}
          />
          <LangsSurfaceRow
            title={t("prefsLangsStore")}
            icon="shopping-bag"
            c1="#d946ef"
            c2="#f43f5e"
            langs={storeLangs}
            busy={busy}
            t={t}
            lang={lang}
            onToggle={(code) => {
              const next = toggle(storeLangs, code);
              if (next) saveLangs.mutate({ storeLangs: next });
            }}
            onReset={() => saveLangs.mutate({ storeLangs: ["ar", "en"] })}
          />
        </div>
      </div>
    </DashCard>
  );
}

/* ------------------------------------------------------------------ */
/* ROUND 47 — Premium workspace overview + REAL server-computed        */
/* storage card (together they replace the round-46 identity card)     */
/* ------------------------------------------------------------------ */

/** Shared premium trigger style for the round-47 settings tabs. */
const TAB_TRIGGER_CLS =
  "h-9 flex-none gap-1.5 rounded-xl px-3.5 text-[12px] font-extrabold text-slate-500 transition data-[state=active]:bg-linear-to-br data-[state=active]:from-brand-500 data-[state=active]:to-fuchsia-500 data-[state=active]:text-white data-[state=active]:shadow-lg dark:text-slate-400 dark:data-[state=active]:text-white";

/** Exact date+time label (workspace creation, storage computed-at). */
function wsDateTime(value: string, lang: Lang): string {
  return new Intl.DateTimeFormat(lang === "ar" ? "ar-EG" : "en-GB", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(value));
}

/** formatBytes rounds sub-KB values up to 1 — for an honest zero-byte
 *  storage cell we render an explicit localized zero instead. */
function fmtBytesOrZero(bytes: number, lang: Lang): string {
  return bytes > 0 ? formatBytes(bytes, lang) : fmtNum(0, lang);
}

const WS_STATUS = {
  active: { key: "wsStatusActive", dot: "#34d399" },
  trial: { key: "wsStatusTrial", dot: "#fbbf24" },
  locked: { key: "wsStatusLocked", dot: "#fb7185" },
} as const;

/** Premium workspace overview: hero identity strip in the EFFECTIVE
 *  workspace accent (ROUND 143 — an owner-picked theme recolors the ENTIRE
 *  system, this card included), server-computed entitlement status + trial
 *  clock, precise facts grid and a security/trust footer (round 47). */
function WorkspaceOverviewCard({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const sys = SYSTEM_MAP[instance.systemId];
  /* ROUND 143 — the shell-wide effective accent (owner theme > category). */
  const { c1, c2 } = useAccentPair();
  const pkg = instance.package ?? null;
  const ent = instance.entitlement;

  const createdMs = new Date(instance.createdAt).getTime();
  const daysSinceCreated = Math.max(0, Math.floor((Date.now() - createdMs) / 86_400_000));

  /* trial clock: consumed share of the createdAt → trialEndsAt window */
  const trialPct =
    ent.state === "trial" && ent.trialEndsAt
      ? Math.max(
          0,
          Math.min(
            100,
            ((Date.now() - createdMs) / Math.max(1, new Date(ent.trialEndsAt).getTime() - createdMs)) * 100,
          ),
        )
      : null;

  const status = WS_STATUS[ent.state];

  return (
    <DashCard title={t("wsInfoTitle")} icon="fingerprint">
      <p className="text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">{t("wsInfoDesc")}</p>

      {/* hero strip — workspace identity in its system colors */}
      <div className="relative mt-4 overflow-hidden rounded-2xl p-5" style={{ backgroundImage: grad(c1, c2) }}>
        <div
          className="pointer-events-none absolute -top-12 -end-12 h-36 w-36 rounded-full bg-white/15 blur-2xl"
          aria-hidden="true"
        />
        <div className="relative flex flex-wrap items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="flex min-w-0 items-center gap-2.5 font-display text-[15px] font-extrabold text-white">
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-white/20 backdrop-blur">
                <CatIcon name={sys?.icon ?? "boxes"} className="h-4 w-4" />
              </span>
              <span className="truncate">{instance.org.name}</span>
            </p>
            <p className="mt-1.5 truncate text-[11.5px] font-bold text-white/75">
              {sys ? (lang === "ar" ? sys.nameAr : sys.nameEn) : instance.systemId}
            </p>
          </div>
          <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-white/20 px-3 py-1 text-[10.5px] font-extrabold text-white backdrop-blur">
            <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: status.dot }} />
            {t(status.key)}
          </span>
        </div>

        {trialPct !== null ? (
          <div className="relative mt-4">
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/25">
              <div
                className="h-full rounded-full bg-white transition-all duration-700"
                style={{ width: `${trialPct}%` }}
              />
            </div>
            <p className="mt-1.5 text-[10.5px] font-extrabold text-white/85">
              {/* ROUND 79 — W5: the smart Arabic countdown (dual forms) */}
              {trialCountdownText(ent, lang, t) ?? t("trialFullAccessShort")}
            </p>
          </div>
        ) : null}
      </div>

      {/* facts grid */}
      <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-2xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
          <p className="text-[11px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
            {t("wsInstanceId")}
          </p>
          <button
            type="button"
            onClick={() => {
              void navigator.clipboard
                .writeText(instance.id)
                .then(() => toast.success(t("secCopied")))
                .catch(() => toast.error(t("errGenericAction")));
            }}
            title={t("secCopyTip")}
            className="mt-0.5 flex w-full items-center justify-start gap-1.5 font-mono text-[11.5px] font-extrabold text-brand-600 transition hover:text-brand-500 dark:text-brand-300"
          >
            {/* LTR island: dir + text-start live on the VALUE, while the button
                keeps the surrounding flow — in AR the id block anchors at the
                inline-start (right edge, under its Arabic label) and the copy
                icon trails at the inline-end; in EN it anchors left. Same
                treatment English names get in Arabic-first apps. */}
            <span dir="ltr" className="truncate text-start">
              {instance.id}
            </span>
            <CatIcon name="copy" className="h-3 w-3 shrink-0 opacity-60" />
          </button>
        </div>

        <div className="rounded-2xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
          <p className="text-[11px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
            {t("wsCreated")}
          </p>
          <p className="mt-0.5 flex items-center gap-1.5 text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
            <CatIcon name="calendar-days" className="h-3 w-3 shrink-0 text-brand-500" />
            <span className="truncate">{wsDateTime(instance.createdAt, lang)}</span>
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
          <p className="text-[11px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
            {t("wsAge")}
          </p>
          <p className="mt-0.5 flex items-center gap-1.5 text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
            <CatIcon name="clock-rotate-left" className="h-3 w-3 shrink-0 text-brand-500" />
            {t("wsAgeDays", { days: fmtNum(daysSinceCreated, lang) })}
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
          <p className="text-[11px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
            {t("planCurrent")}
          </p>
          <p className="mt-0.5 truncate text-[12px] font-extrabold text-amber-600 dark:text-amber-400">
            {pkg ? (lang === "ar" ? pkg.nameAr : pkg.nameEn) : t("adminSubsNoPkg")}
          </p>
          {ent.planActivatedAt || ent.planCycle ? (
            <div className="mt-1.5 flex flex-wrap gap-1">
              {ent.planActivatedAt ? (
                <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/10 px-2 py-0.5 text-[11px] font-extrabold text-amber-700 dark:bg-amber-500/15 dark:text-amber-300">
                  {t("wsPlanSince")}{" "}
                  {new Date(ent.planActivatedAt).toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB", {
                    dateStyle: "medium",
                  })}
                </span>
              ) : null}
              {ent.planCycle ? (
                <span className="inline-flex items-center gap-1 rounded-full bg-slate-500/10 px-2 py-0.5 text-[11px] font-extrabold text-slate-600 dark:bg-white/10 dark:text-slate-300">
                  {t(ent.planCycle === "monthly" ? "wsCycleMonthly" : "wsCycleYearly")}
                </span>
              ) : null}
            </div>
          ) : null}
        </div>

        <div className="rounded-2xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
          <p className="text-[11px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
            {t("wsModulesUsed")}
          </p>
          <p className="mt-0.5 flex items-center gap-1.5 text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
            <CatIcon name="cubes" className="h-3 w-3 shrink-0 text-violet-500" />
            {fmtNum(instance.modules.length, lang)}
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
          <p className="text-[11px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
            {t("wsSiteStatus")}
          </p>
          <div className="mt-1">
            {instance.site ? (
              instance.site.published ? (
                <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2.5 py-1 text-[10px] font-extrabold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
                  <CatIcon name="globe" className="h-3 w-3" />
                  {t("wsSitePublished")}
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-extrabold text-slate-500 dark:bg-white/10 dark:text-slate-400">
                  <CatIcon name="globe" className="h-3 w-3" />
                  {t("wsSiteDraft")}
                </span>
              )
            ) : (
              <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-extrabold text-slate-500 dark:bg-white/10 dark:text-slate-400">
                <CatIcon name="globe" className="h-3 w-3" />
                {t("wsSiteNone")}
              </span>
            )}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
          <p className="text-[11px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
            {t("wsStoreStatus")}
          </p>
          <div className="mt-1">
            {instance.site ? (
              <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2.5 py-1 text-[10px] font-extrabold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
                <CatIcon name="store" className="h-3 w-3" />
                {t("wsSitePublished")}
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-extrabold text-slate-500 dark:bg-white/10 dark:text-slate-400">
                <CatIcon name="store" className="h-3 w-3" />
                {t("wsSiteNone")}
              </span>
            )}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
          <p className="text-[11px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
            {t("wsSessionPolicy")}
          </p>
          <p className="mt-0.5 flex items-center gap-1.5 text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
            <CatIcon name="timer" className="h-3 w-3 shrink-0 text-emerald-500" />
            {t("wsSessionPolicyVal")}
          </p>
        </div>
      </div>

      {/* security / trust footer */}
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-300/60 bg-emerald-500/[0.08] px-3 py-1 text-[10.5px] font-extrabold text-emerald-600 dark:border-emerald-500/40 dark:bg-emerald-500/10 dark:text-emerald-300">
          <CatIcon name="shield" className="h-3 w-3" />
          {t("wsDataIsolation")}
        </span>
        <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/70 px-3 py-1 text-[10.5px] font-extrabold text-slate-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300">
          <CatIcon name="server" className="h-3 w-3 text-brand-500" />
          {t("wsRegion")}
        </span>
        <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/70 px-3 py-1 text-[10.5px] font-extrabold text-slate-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300">
          <CatIcon name="timer" className="h-3 w-3 text-emerald-500" />
          {t("wsSessionPolicyVal")}
        </span>
      </div>
    </DashCard>
  );
}

/* ================================================================== */
/* ROUND 88 — the DATA-tab workspace identity panel                     */
/* (premium rebuild of the removed round-25 «معلومات مساحة العمل»)     */
/* ================================================================== */

/**
 * The owner's directive: in Settings → البيانات والنسخ, the old plain
 * «معلومات مساحة العمل» block had to be DELETED entirely and redeveloped
 * attractively & premium. This panel is that rebuild: an identity card in
 * the workspace's own sector colors — gradient top rail, fingerprint
 * header tile, org+system identity line, and three precise fact chips
 * (copyable workspace ID with live copied feedback, localized creation
 * date, live modules count) plus the mobile-companion note as a designed
 * footer chip. Distinct from the Workspace tab's overview card (that one
 * carries entitlement/trial state; this one is the DATA tab's compact
 * identity companion).
 */
function WorkspaceFactsPanel({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const sys = SYSTEM_MAP[instance.systemId];
  /* ROUND 143 — the shell-wide effective accent (owner theme > category). */
  const { c1, c2 } = useAccentPair();

  /* copied feedback with an auto-reset timer (icon + emerald flash) */
  const [copied, setCopied] = useState(false);
  const copiedTimer = useRef<number | null>(null);
  useEffect(() => {
    return () => {
      if (copiedTimer.current !== null) window.clearTimeout(copiedTimer.current);
    };
  }, []);

  const copyId = () => {
    void navigator.clipboard
      .writeText(instance.id)
      .then(() => {
        toast.success(t("secCopied"));
        setCopied(true);
        if (copiedTimer.current !== null) window.clearTimeout(copiedTimer.current);
        copiedTimer.current = window.setTimeout(() => setCopied(false), 1_800);
      })
      .catch(() => toast.error(t("errGenericAction")));
  };

  return (
    <div className="relative overflow-hidden rounded-2xl border border-slate-200/80 dark:border-white/10">
      {/* gradient top rail + corner wash in the system's sector colors */}
      <span
        aria-hidden="true"
        className="absolute inset-x-0 top-0 h-1"
        style={{ backgroundImage: grad(c1, c2) }}
      />
      <span
        aria-hidden="true"
        className="pointer-events-none absolute -top-10 -end-10 h-28 w-28 rounded-full blur-2xl"
        style={{ backgroundColor: c1, opacity: 0.12 }}
      />
      <div className="relative p-4">
        {/* header — fingerprint tile + title + org/system identity */}
        <div className="flex items-start gap-3">
          <span
            className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg"
            style={{ backgroundImage: grad(c1, c2) }}
            aria-hidden="true"
          >
            <CatIcon name="fingerprint" className="h-4 w-4" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
              {t("settingsFactsTitle")}
            </p>
            <p className="mt-0.5 flex min-w-0 items-center gap-1.5 text-[11px] font-bold text-slate-500 dark:text-slate-400">
              <CatIcon name={sys?.icon ?? "boxes"} className="h-3 w-3 shrink-0" style={{ color: c1 }} />
              <span className="truncate">{instance.org.name}</span>
              <span aria-hidden="true" className="shrink-0 opacity-40">·</span>
              <span className="truncate">{sys ? (lang === "ar" ? sys.nameAr : sys.nameEn) : instance.systemId}</span>
            </p>
          </div>
        </div>

        {/* fact chips — copyable ID, creation date, modules count */}
        <div className="mt-3.5 grid gap-2">
          <button
            type="button"
            onClick={copyId}
            title={t("secCopyTip")}
            className="group flex items-center justify-between gap-2 rounded-xl border border-slate-200/70 bg-slate-50/60 px-3 py-2 text-start transition hover:border-brand-300 hover:bg-brand-50/40 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-brand-500/40 dark:hover:bg-brand-500/10"
          >
            <span className="min-w-0">
              <span className="block text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                {t("wsInstanceId")}
              </span>
              <span dir="ltr" className="mt-0.5 block truncate font-mono text-[11.5px] font-extrabold text-brand-600 dark:text-brand-300">
                {instance.id}
              </span>
            </span>
            <span
              className={cn(
                "grid h-7 w-7 shrink-0 place-items-center rounded-lg transition",
                copied
                  ? "bg-emerald-500/15 text-emerald-500"
                  : "bg-slate-200/70 text-slate-400 group-hover:text-brand-500 dark:bg-white/10 dark:text-slate-400",
              )}
              aria-hidden="true"
            >
              <CatIcon name={copied ? "check" : "copy"} className="h-3.5 w-3.5" />
            </span>
          </button>

          <div className="grid grid-cols-2 gap-2">
            <div className="rounded-xl border border-slate-200/70 bg-slate-50/60 px-3 py-2 dark:border-white/10 dark:bg-white/[0.03]">
              <span className="block text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                {t("wsCreated")}
              </span>
              <span className="mt-0.5 flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200">
                <CatIcon name="calendar-days" className="h-3 w-3 shrink-0 text-brand-500" />
                <span className="truncate">
                  {new Date(instance.createdAt).toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB", { dateStyle: "medium" })}
                </span>
              </span>
            </div>
            <div className="rounded-xl border border-slate-200/70 bg-slate-50/60 px-3 py-2 dark:border-white/10 dark:bg-white/[0.03]">
              <span className="block text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                {t("userSheetModulesCount")}
              </span>
              <span className="mt-0.5 flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200">
                <CatIcon name="cubes" className="h-3 w-3 shrink-0 text-violet-500" />
                {fmtNum(instance.modules.length, lang)}
              </span>
            </div>
          </div>
        </div>

        {/* mobile companion — designed footer chip */}
        <p className="mt-3 flex items-center gap-1.5 rounded-xl bg-amber-500/10 px-2.5 py-2 text-[10.5px] font-bold text-amber-700 dark:text-amber-300">
          <CatIcon name="smartphone" className="h-3.5 w-3.5 shrink-0" />
          {t("mobileAppTitle")}: {t("mobileAppBadge")}
        </p>
      </div>
    </div>
  );
}

/** breakdown metadata: localized label + icon tile per server-computed key */
const STORAGE_BD = {
  core: { label: "storageBdCore", icon: "cpu", c1: "#64748b", c2: "#475569" },
  records: { label: "storageBdRecords", icon: "layers", c1: "#8b5cf6", c2: "#7c3aed" },
  site: { label: "storageBdSite", icon: "globe", c1: "#0ea5e9", c2: "#0284c7" },
  customers: { label: "storageBdCustomers", icon: "users", c1: "#14b8a6", c2: "#0d9488" },
  orders: { label: "storageBdOrders", icon: "shopping-cart", c1: "#f59e0b", c2: "#d97706" },
  team: { label: "storageBdTeam", icon: "users-round", c1: "#6366f1", c2: "#4f46e5" },
  activities: { label: "storageBdActivities", icon: "activity", c1: "#f43f5e", c2: "#e11d48" },
  images: { label: "storageBdImages", icon: "image", c1: "#d946ef", c2: "#c026d3" },
} as const satisfies Record<
  WorkspaceUsageDTO["breakdown"][number]["key"],
  { label: I18nKey; icon: string; c1: string; c2: string }
>;

/** REAL storage card — every byte is measured by the server
 *  (/api/instances/[id]/usage, round 47) and simply rendered here:
 *  tamper-proof by construction. Auxiliary data → hides silently on error. */
function StorageCard({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();

  const usageQuery = useQuery({
    queryKey: ["instance-usage", instance.id],
    queryFn: () => fetchInstanceUsage(instance.id),
  });

  /* usage is auxiliary — a failed fetch hides the card, never blocks settings */
  if (usageQuery.isError) return null;

  const usage = usageQuery.data;

  return (
    <DashCard title={t("storageCardTitle")} icon="database">
      {usage ? (
        <div className="space-y-4">
          {/* meter: used of quota + premium progress bar */}
          <div>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
                {t("storageUsedOf", {
                  used: fmtBytesOrZero(usage.totalBytes, lang),
                  quota:
                    usage.quotaBytes === null ? t("storageUnlimited") : formatBytes(usage.quotaBytes, lang),
                })}
              </p>
              {usage.pct !== null ? (
                <span
                  className={cn(
                    "inline-flex shrink-0 items-center gap-1 rounded-full px-2.5 py-1 text-[10.5px] font-extrabold",
                    usage.pct >= 90
                      ? "bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300"
                      : usage.pct >= 70
                        ? "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300"
                        : "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300",
                  )}
                >
                  <CatIcon name="hard-drive" className="h-3 w-3" />
                  {fmtNum(usage.pct, lang)}
                  {lang === "ar" ? "٪" : "%"}
                </span>
              ) : null}
            </div>
            <div
              className="mt-2.5 h-3 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-white/10"
              role="progressbar"
              aria-valuenow={usage.pct === null ? undefined : Math.round(usage.pct)}
              aria-valuemin={0}
              aria-valuemax={100}
            >
              <div
                className="h-full rounded-full transition-all duration-700"
                style={{
                  width: `${usage.pct === null ? 4 : Math.max(0, Math.min(100, usage.pct))}%`,
                  backgroundImage:
                    usage.pct === null
                      ? grad("#10b981", "#059669")
                      : usage.pct >= 90
                        ? grad("#f43f5e", "#e11d48")
                        : usage.pct >= 70
                          ? grad("#f59e0b", "#d97706")
                          : grad("#10b981", "#059669"),
                }}
              />
            </div>
          </div>

          {/* breakdown grid */}
          <div>
            <p className="mb-2.5 text-[10.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
              {t("storageBreakdownTitle")}
            </p>
            <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
              {usage.breakdown.map((item) => {
                const meta = STORAGE_BD[item.key];
                return (
                  <div
                    key={item.key}
                    className="rounded-2xl border border-slate-200/70 bg-white/70 p-3 transition hover:border-brand-300/60 dark:border-white/10 dark:bg-white/[0.04] dark:hover:border-brand-500/30"
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className="grid h-6 w-6 shrink-0 place-items-center rounded-lg text-white"
                        style={{ backgroundImage: grad(meta.c1, meta.c2) }}
                      >
                        <CatIcon name={meta.icon} className="h-3 w-3" />
                      </span>
                      <p className="truncate text-[11px] font-extrabold text-slate-700 dark:text-slate-200">
                        {t(meta.label)}
                      </p>
                    </div>
                    <p className="mt-2 text-[12.5px] font-extrabold tabular-nums text-slate-800 dark:text-slate-100">
                      {fmtBytesOrZero(item.bytes, lang)}
                    </p>
                    {item.rows !== null && item.rows > 0 ? (
                      <p className="mt-0.5 text-[10px] font-bold text-slate-400 dark:text-slate-500">
                        {t("storageRowsCount", { count: fmtNum(item.rows, lang) })}
                      </p>
                    ) : null}
                  </div>
                );
              })}
            </div>
          </div>

          {/* footer: trust note + freshness + plan quota */}
          <div className="flex flex-col gap-2.5">
            <div className="flex items-start gap-2.5 rounded-2xl border border-emerald-300/60 bg-emerald-500/[0.07] p-3 dark:border-emerald-500/25 dark:bg-emerald-500/10">
              <CatIcon name="shield-check" className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
              <p className="text-[11px] font-bold leading-relaxed text-emerald-700 dark:text-emerald-300">
                {t("storageTrustNote")}
              </p>
            </div>
            <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-1.5 text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
              <span className="inline-flex items-center gap-1.5">
                <CatIcon name="refresh-cw" className="h-3 w-3" />
                {t("storageComputedAt", { time: wsDateTime(usage.computedAt, lang) })}
              </span>
              {usage.quotaBytes !== null ? (
                <span className="inline-flex items-center gap-1.5">
                  <CatIcon name="badge-check" className="h-3 w-3 text-brand-500" />
                  {t("storagePlanQuotaNote", { quota: formatBytes(usage.quotaBytes, lang) })}
                </span>
              ) : null}
            </div>
          </div>
        </div>
      ) : (
        /* loading skeleton — mirrors the loaded card's shape */
        <div className="space-y-4">
          <div className="flex items-center justify-between gap-3">
            <Skeleton className="h-5 w-44 rounded-lg" />
            <Skeleton className="h-6 w-14 rounded-full" />
          </div>
          <Skeleton className="h-3 w-full rounded-full" />
          <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <Skeleton key={i} className="h-[5.25rem] w-full rounded-2xl" />
            ))}
          </div>
          <Skeleton className="h-14 w-full rounded-2xl" />
        </div>
      )}
    </DashCard>
  );
}

export function SettingsView({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const setLang = useAppStore((s) => s.setLang);
  const setDashView = useAppStore((s) => s.setDashView);
  const { setTheme } = useTheme();
  const queryClient = useQueryClient();

  const [org, setOrg] = useState<OrgInfo>(instance.org);
  const [prefs, setPrefs] = useState<PrefsInfo>(instance.prefs);
  const [saving, setSaving] = useState(false);
  /* workspace password rotation — the current secret must accompany the
   * new one (server rejects the rotation without proof-of-knowledge). */
  const [pwCurrent, setPwCurrent] = useState("");
  const [pwNext, setPwNext] = useState("");
  const [pwConfirm, setPwConfirm] = useState("");
  const [pwVisible, setPwVisible] = useState(false);

  /* ROUND 87 (account lifecycle) — the owner's danger zone: self-disable
   * (pause, password-proven) + self-delete (soft-delete into the platform
   * trash, password-proven). Both end signed-out on the landing page. */
  const [disableOpen, setDisableOpen] = useState(false);
  const [disablePw, setDisablePw] = useState("");
  const [disableReason, setDisableReason] = useState("");
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deletePw, setDeletePw] = useState("");
  const [deleteTyped, setDeleteTyped] = useState("");
  const exitToLanding = useAppStore((s) => s.exitToLanding);

  const rotatePassword = useMutation({
    mutationFn: () =>
      updateInstance(instance.id, {
        admin: { password: pwNext },
        currentPassword: pwCurrent,
      }),
    onSuccess: () => {
      toast.success(t("settingsPwDone"));
      setPwCurrent("");
      setPwNext("");
      setPwConfirm("");
      queryClient.invalidateQueries({ queryKey: ["instance", instance.id] });
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${apiErrorText(error, t)}`),
  });

  /* ROUND 87 — owner self-disable: total pause (sessions revoked, login
   * refuses, public surfaces hold) with password proof; re-activation is
   * one password proof at the login step. */
  const disableAccount = useMutation({
    mutationFn: () =>
      disableOwnWorkspace(instance.id, {
        password: disablePw,
        ...(disableReason.trim() ? { reason: disableReason.trim() } : {}),
      }),
    onSuccess: () => {
      toast.success(t("ownerDisableSuccess"));
      setDisableOpen(false);
      queryClient.removeQueries({ queryKey: ["instance", instance.id] });
      queryClient.invalidateQueries({ queryKey: ["instances"] });
      exitToLanding();
    },
    onError: (error: Error) => {
      if (error instanceof ApiError && error.code === "PASSWORD_PROOF") {
        toast.error(t("ownerDisableErrPw"));
      } else {
        toast.error(`${t("errorText")}: ${apiErrorText(error, t)}`);
      }
    },
  });

  /* ROUND 87 — owner self-delete: the whole account moves to the platform
   * trash (restorable for the retention window, purge destroys it). */
  const deleteAccount = useMutation({
    mutationFn: () =>
      deleteInstance(instance.id, { password: deletePw }),
    onSuccess: () => {
      toast.success(t("ownerDeleteSuccess"));
      setDeleteOpen(false);
      queryClient.removeQueries({ queryKey: ["instance", instance.id] });
      queryClient.invalidateQueries({ queryKey: ["instances"] });
      exitToLanding();
    },
    onError: (error: Error) => {
      if (error instanceof ApiError && error.code === "PASSWORD_PROOF_REQUIRED") {
        toast.error(t("ownerDisableErrPw"));
      } else {
        toast.error(`${t("errorText")}: ${apiErrorText(error, t)}`);
      }
    },
  });

  const pwS = pwScore(pwNext);
  const pwValid = pwCurrent.length > 0 && pwNext.length >= 8 && pwNext === pwConfirm;

  const system = SYSTEM_MAP[instance.systemId];
  /* ROUND 143 — the shell-wide effective accent (owner theme > category):
   * the save button + every brand tile on THIS page follow the picked
   * theme — the whole system recolors together. */
  const { c1, c2 } = useAccentPair();

  const save = useMutation({
    mutationFn: () => {
      // diff — only send what actually changed
      const orgDiff: Partial<OrgInfo> = {};
      if (org.name !== instance.org.name) orgDiff.name = org.name;
      if (org.country !== instance.org.country) orgDiff.country = org.country;
      if (org.currency !== instance.org.currency) orgDiff.currency = org.currency;
      if (org.timezone !== instance.org.timezone) orgDiff.timezone = org.timezone;
      if (org.address !== instance.org.address) orgDiff.address = org.address;
      if (org.phone !== instance.org.phone) orgDiff.phone = org.phone;

      const prefsDiff: Partial<PrefsInfo> = {};
      if (prefs.lang !== instance.prefs.lang) prefsDiff.lang = prefs.lang;
      if (prefs.theme !== instance.prefs.theme) prefsDiff.theme = prefs.theme;
      if (prefs.notif !== instance.prefs.notif) prefsDiff.notif = prefs.notif;
      if (prefs.backup !== instance.prefs.backup) prefsDiff.backup = prefs.backup;
      if (prefs.audit !== instance.prefs.audit) prefsDiff.audit = prefs.audit;
      if (prefs.demo !== instance.prefs.demo) prefsDiff.demo = prefs.demo;

      const payload: Parameters<typeof updateInstance>[1] = {};
      if (Object.keys(orgDiff).length > 0) payload.org = orgDiff;
      if (Object.keys(prefsDiff).length > 0) payload.prefs = prefsDiff;
      if (Object.keys(payload).length === 0) return Promise.resolve(null);
      setSaving(true);
      return updateInstance(instance.id, payload);
    },
    onSuccess: (data) => {
      if (data === null) {
        toast.info(t("settingsNoChanges"));
        return;
      }
      toast.success(t("settingsSaved"));
      queryClient.invalidateQueries({ queryKey: ["instance", instance.id] });
      queryClient.invalidateQueries({ queryKey: ["instances"] });
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
    onSettled: () => setSaving(false),
  });

  const onCountryChange = (country: string) => {
    const cur = COUNTRIES.find((c) => c.code === country)?.currency;
    setOrg((o) => ({ ...o, country, ...(cur ? { currency: cur } : {}) }));
  };

  const onLangChange = (value: string) => {
    const lang = value as Lang;
    setPrefs((p) => ({ ...p, lang }));
    setLang(lang); // live flip
  };

  const onThemeChange = (value: string) => {
    const theme = value as PrefsInfo["theme"];
    setPrefs((p) => ({ ...p, theme }));
    setTheme(theme === "auto" ? "system" : theme); // live preview
  };

  return (
    <div className="space-y-5">
      <ViewHeading title={t("dashSettingsTitle")} desc={t("dashSettingsDesc")} />

      <form
        onSubmit={(e) => {
          e.preventDefault();
          save.mutate();
        }}
        className="space-y-5"
      >
        {/* ROUND 47 — professional settings tabs. Every editable card's draft
            (org / prefs / password) lives in view-level state, so switching
            tabs never loses unsaved input; one save button after the tabs
            covers every tab. */}
        {/* Radix renders its Tabs root div as dir="ltr" by default — without
            this explicit dir the ENTIRE tab area (all 5 panels: tab order,
            flex rows, grids, text-start) lays out left-to-right even when the
            page is Arabic. Same pattern the app uses on DialogContent. (The
            nested Selects need their own dir — Radix Tabs does not propagate
            a DirectionContext to children.) */}
        <Tabs
          defaultValue="workspace"
          dir={lang === "ar" ? "rtl" : "ltr"}
          className="gap-4 sm:gap-5"
        >
          <TabsList className="flex h-auto w-full max-w-full justify-start gap-1.5 overflow-x-auto rounded-2xl border border-slate-200/80 bg-white/70 p-1.5 dark:border-white/10 dark:bg-white/[0.04] sm:w-fit sm:justify-center">
            <TabsTrigger value="workspace" className={TAB_TRIGGER_CLS}>
              <CatIcon name="gauge" className="size-3.5" />
              {t("settingsTabWorkspace")}
            </TabsTrigger>
            <TabsTrigger value="brand" className={TAB_TRIGGER_CLS}>
              <CatIcon name="sparkles" className="size-3.5" />
              {t("settingsTabBrand")}
            </TabsTrigger>
            {/* ROUND 86 — الألوان والخطوط: per-surface colors & fonts */}
            <TabsTrigger value="style" className={TAB_TRIGGER_CLS}>
              <CatIcon name="palette" className="size-3.5" />
              {t("cfsTab")}
            </TabsTrigger>
            <TabsTrigger value="prefs" className={TAB_TRIGGER_CLS}>
              <CatIcon name="sliders" className="size-3.5" />
              {t("settingsTabPrefs")}
            </TabsTrigger>
            <TabsTrigger value="security" className={TAB_TRIGGER_CLS}>
              <CatIcon name="shield" className="size-3.5" />
              {t("settingsTabSecurity")}
            </TabsTrigger>
            <TabsTrigger value="data" className={TAB_TRIGGER_CLS}>
              <CatIcon name="database" className="size-3.5" />
              {t("settingsTabData")}
            </TabsTrigger>
          </TabsList>

          {/* ---- tab 1 · workspace: overview + storage + org data ---- */}
          <TabsContent value="workspace" className="space-y-5">
            <WorkspaceOverviewCard instance={instance} />
            <StorageCard instance={instance} />

            {/* org */}
            <DashCard title={t("settingsOrgSection")} icon="building">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <Label htmlFor="set-org-name" className={WZ_LABEL}>
                    {t("wzOrgName")} <span className="text-rose-500">*</span>
                  </Label>
                  <Input
                    id="set-org-name"
                    value={org.name}
                    onChange={(e) => setOrg((o) => ({ ...o, name: e.target.value }))}
                    placeholder={t("wzOrgNamePh")}
                    className={WZ_INPUT}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="set-org-country" className={WZ_LABEL}>
                    {t("wzOrgCountry")}
                  </Label>
                  {/* dir on Select: Radix defaults the dropdown content to
                      ltr — Arabic option labels must anchor from the right */}
                  <Select
                    value={org.country}
                    onValueChange={onCountryChange}
                    dir={lang === "ar" ? "rtl" : "ltr"}
                  >
                    <SelectTrigger id="set-org-country" className={WZ_INPUT}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="max-h-72">
                      <SelectGroup>
                        {COUNTRIES.map((c) => (
                          <SelectItem key={c.code} value={c.code}>
                            {c.name}
                          </SelectItem>
                        ))}
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="set-org-currency" className={WZ_LABEL}>
                    {t("wzOrgCurrency")}
                  </Label>
                  <Input
                    id="set-org-currency"
                    value={org.currency}
                    onChange={(e) => setOrg((o) => ({ ...o, currency: e.target.value }))}
                    className={WZ_INPUT}
                  />
                </div>
                <div className="sm:col-span-2">
                  <Label htmlFor="set-org-timezone" className={WZ_LABEL}>
                    {t("wzOrgTimezone")}
                  </Label>
                  <Select
                    value={org.timezone}
                    onValueChange={(tz) => setOrg((o) => ({ ...o, timezone: tz }))}
                    dir={lang === "ar" ? "rtl" : "ltr"}
                  >
                    <SelectTrigger id="set-org-timezone" className={WZ_INPUT}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="max-h-72">
                      <SelectGroup>
                        {TIMEZONES.map((tz) => (
                          <SelectItem key={tz} value={tz}>
                            {tz}
                          </SelectItem>
                        ))}
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                </div>
                <div className="sm:col-span-2">
                  <Label htmlFor="set-org-address" className={WZ_LABEL}>
                    {t("wzOrgAddress")}
                  </Label>
                  <Input
                    id="set-org-address"
                    value={org.address}
                    onChange={(e) => setOrg((o) => ({ ...o, address: e.target.value }))}
                    placeholder={t("wzOrgAddressPh")}
                    className={WZ_INPUT}
                  />
                </div>
                <div className="sm:col-span-2">
                  {/* ROUND 88 — the org contact phone is now the PREMIUM
                      direction-aware composite (owner directive: «رقم
                      التواصل يدعم العربية من اليمين إلى اليسار بالكامل»):
                      in Arabic the country dial-code selector sits at the
                      reading start (visual RIGHT) with an LTR number island
                      after it; in LTR it keeps the international layout. The
                      parent form keeps ONE canonical +{dial}{national}
                      value — the same contract the wizard's org step uses. */}
                  <PremiumPhoneInput
                    id="set-org-phone"
                    label="wzOrgPhone"
                    value={org.phone}
                    onChange={(phone) => setOrg((o) => ({ ...o, phone }))}
                    autoComplete="tel"
                  />
                </div>
              </div>
            </DashCard>
          </TabsContent>

          {/* ---- tab 2 · identity & brand ---- */}
          <TabsContent value="brand" className="space-y-5">
            {/* ROUND 45 — brand identity (moved from the website editor) */}
            <BrandIdentityCard instance={instance} />
            {/* ROUND 67 — invoice signature & stamp branding */}
            <InvoiceBrandingCard instance={instance} />
          </TabsContent>

          {/* ---- ROUND 86 — tab 3 · الألوان والخطوط (colors & fonts) ---- */}
          <TabsContent value="style" className="space-y-5">
            <ColorsFontsCard instance={instance} />
          </TabsContent>

          {/* ---- tab 4 · preferences ---- */}
          <TabsContent value="prefs" className="space-y-5">
            {/* ROUND 86 (directive ④) — لغات الزوار: precisely which
                languages the site/store offer their visitors */}
            <VisitorLangsCard instance={instance} />

            {/* prefs */}
            <DashCard title={t("settingsPrefsSection")} icon="sliders">
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="set-prefs-lang" className={WZ_LABEL}>
                    {t("wzPrefsLang")}
                  </Label>
                  <Select
                    value={prefs.lang}
                    onValueChange={onLangChange}
                    dir={lang === "ar" ? "rtl" : "ltr"}
                  >
                    <SelectTrigger id="set-prefs-lang" className={WZ_INPUT}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectGroup>
                        {/* ROUND 55 — ALL 11 platform languages selectable (the
                            wizard's prefs step uses the same registry) */}
                        {LOCALES.map((loc) => (
                          <SelectItem key={loc.code} value={loc.code} className="text-[12.5px] font-bold">
                            <span className="flex items-center gap-2">
                              <span
                                className={cn(
                                  "text-[10px] font-extrabold uppercase",
                                  lang === loc.code
                                    ? "text-brand-600 dark:text-brand-300"
                                    : "text-slate-400 dark:text-slate-500"
                                )}
                              >
                                {loc.short}
                              </span>
                              {loc.native}
                            </span>
                          </SelectItem>
                        ))}
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="set-prefs-theme" className={WZ_LABEL}>
                    {t("wzPrefsTheme")}
                  </Label>
                  <Select
                    value={prefs.theme}
                    onValueChange={onThemeChange}
                    dir={lang === "ar" ? "rtl" : "ltr"}
                  >
                    <SelectTrigger id="set-prefs-theme" className={WZ_INPUT}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectGroup>
                        <SelectItem value="light">{t("wzPrefsThemeLight")}</SelectItem>
                        <SelectItem value="dark">{t("wzPrefsThemeDark")}</SelectItem>
                        <SelectItem value="auto">{t("wzPrefsThemeAuto")}</SelectItem>
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                </div>

                <div className="sm:col-span-2">
                  <div className="grid gap-2.5 sm:grid-cols-2">
                    {PREF_TOGGLES.map((row) => {
                      const on = prefs[row.key];
                      return (
                        <div
                          key={row.key}
                          className="flex items-center justify-between gap-3 rounded-2xl border border-slate-200 p-3.5 dark:border-white/10"
                        >
                          <div className="flex min-w-0 items-center gap-3">
                            <span
                              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white"
                              style={{ backgroundImage: on ? grad(row.c1, row.c2) : "linear-gradient(135deg,#cbd5e1,#94a3b8)" }}
                            >
                              <CatIcon name={row.icon} className="h-[12px] w-[12px]" />
                            </span>
                            <div className="min-w-0">
                              <p className="truncate text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                                {t(row.title)}
                              </p>
                              <p className="truncate text-[11px] text-slate-500 dark:text-slate-400">{t(row.desc)}</p>
                            </div>
                          </div>
                          <Switch
                            checked={on}
                            onCheckedChange={(v) => setPrefs((p) => ({ ...p, [row.key]: v }))}
                            aria-label={t(row.title)}
                          />
                        </div>
                      );
                    })}
                  </div>
                </div>

              </div>
            </DashCard>

            {/* modules shortcut */}
            <DashCard title={t("settingsModulesSection")} icon="cubes">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <p className="max-w-xl text-[12.5px] text-slate-500 dark:text-slate-400">
                  {t("settingsModulesHint")}
                </p>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setDashView("modules")}
                  className="h-10 rounded-xl px-4 text-[12.5px] font-bold hover:border-brand-300 hover:text-brand-600"
                >
                  <CatIcon name="cubes" className="h-4 w-4" />
                  {t("dashModulesTitle")}
                </Button>
              </div>
            </DashCard>
          </TabsContent>

          {/* ---- tab 4 · security ---- */}
          <TabsContent value="security" className="space-y-5">
            {/* security — workspace password rotation */}
            <DashCard title={t("settingsPwSection")} icon="key-round">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <Label className={WZ_LABEL}>{t("gateEmail")}</Label>
                  <div className="flex h-11 items-center gap-2 rounded-xl border border-slate-200 bg-slate-50/60 px-3 dark:border-white/10 dark:bg-white/[0.03]">
                    <CatIcon name="mail" className="h-4 w-4 shrink-0 text-brand-500" />
                    <span dir="ltr" className="truncate text-[13px] font-bold text-slate-700 dark:text-slate-200">
                      {instance.admin.email || "—"}
                    </span>
                    <span className="ms-auto inline-flex shrink-0 items-center gap-1 rounded-full bg-emerald-100 px-2 py-0.5 text-[11px] font-extrabold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
                      <CatIcon name="shield-check" className="h-2.5 w-2.5" />
                      {t("settingsPwAccount")}
                    </span>
                  </div>
                </div>

                <div className="sm:col-span-2">
                  <Label htmlFor="set-pw-current" className={WZ_LABEL}>
                    {t("settingsPwCurrent")} <span className="text-rose-500">*</span>
                  </Label>
                  <div className="relative" dir="ltr">
                    <Input
                      id="set-pw-current"
                      type={pwVisible ? "text" : "password"}
                      dir="ltr"
                      value={pwCurrent}
                      onChange={(e) => setPwCurrent(e.target.value)}
                      placeholder="••••••••"
                      autoComplete="current-password"
                      disabled={rotatePassword.isPending}
                      className={`${WZ_INPUT} pe-11 text-start`}
                    />
                    <button
                      type="button"
                      onClick={() => setPwVisible((v) => !v)}
                      aria-label={t(pwVisible ? "wzPwHide" : "wzPwShow")}
                      className="absolute inset-y-0 end-0 me-2.5 grid h-7 w-7 place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-white/10 dark:hover:text-slate-200"
                    >
                      <CatIcon name={pwVisible ? "eye-off" : "eye"} className="h-[14px] w-[14px]" />
                    </button>
                  </div>
                </div>

                <div>
                  <Label htmlFor="set-pw-next" className={WZ_LABEL}>
                    {t("settingsPwNew")} <span className="text-rose-500">*</span>
                  </Label>
                  {/* LTR island: the wrapper carries dir="ltr" so the input's
                      pe-11 and the reveal button's end-0/me-2.5 resolve against
                      the SAME direction — toggle at the island's end edge, value
                      from the island's start edge. Without it, AR resolves
                      pe-11 against the input (right) but end-0 against the RTL
                      wrapper (left) and the eye lands on the text. */}
                  <div className="relative" dir="ltr">
                    <Input
                      id="set-pw-next"
                      type={pwVisible ? "text" : "password"}
                      dir="ltr"
                      value={pwNext}
                      onChange={(e) => setPwNext(e.target.value)}
                      placeholder="••••••••"
                      autoComplete="new-password"
                      disabled={rotatePassword.isPending}
                      className={`${WZ_INPUT} pe-11 text-start`}
                    />
                    <button
                      type="button"
                      onClick={() => setPwVisible((v) => !v)}
                      aria-label={t(pwVisible ? "wzPwHide" : "wzPwShow")}
                      className="absolute inset-y-0 end-0 me-2.5 grid h-7 w-7 place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-white/10 dark:hover:text-slate-200"
                    >
                      <CatIcon name={pwVisible ? "eye-off" : "eye"} className="h-[14px] w-[14px]" />
                    </button>
                  </div>
                </div>
                <div>
                  <Label htmlFor="set-pw-confirm" className={WZ_LABEL}>
                    {t("wzPwConfirm")} <span className="text-rose-500">*</span>
                  </Label>
                  <Input
                    id="set-pw-confirm"
                    type={pwVisible ? "text" : "password"}
                    dir="ltr"
                    value={pwConfirm}
                    onChange={(e) => setPwConfirm(e.target.value)}
                    placeholder="••••••••"
                    autoComplete="new-password"
                    disabled={rotatePassword.isPending}
                    aria-invalid={pwConfirm.length > 0 && pwConfirm !== pwNext || undefined}
                    className={`${WZ_INPUT} text-start ${pwConfirm.length > 0 && pwConfirm !== pwNext ? "border-rose-400 focus-visible:ring-rose-400" : ""}`}
                  />
                </div>

                <div className="sm:col-span-2 flex flex-wrap items-center gap-3">
                  <div className="flex flex-1 gap-1.5" aria-hidden="true">
                    {[0, 1, 2, 3].map((i) => (
                      <span
                        key={i}
                        className="h-1.5 flex-1 rounded-full transition-all duration-300"
                        style={{ backgroundColor: i < pwS ? PW_COLORS[pwS] : "rgba(148,163,184,0.25)" }}
                      />
                    ))}
                  </div>
                  <Button
                    type="button"
                    disabled={!pwValid || rotatePassword.isPending}
                    onClick={() => rotatePassword.mutate()}
                    className="h-10 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 disabled:opacity-50"
                    style={{ backgroundImage: grad("#10b981", "#0e7490") }}
                  >
                    {rotatePassword.isPending ? (
                      <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                    ) : (
                      <CatIcon name="key-round" className="h-4 w-4" />
                    )}
                    {t("settingsPwSave")}
                  </Button>
                </div>
                <p className="sm:col-span-2 text-[11px] font-semibold text-slate-400 dark:text-slate-500">
                  {t("settingsPwHint")}
                </p>
              </div>
            </DashCard>

            {/* ROUND 45 — real security: workspace 2FA · passkeys · active sessions */}
            <TwoFactorCard scope={{ kind: "instance", instanceId: instance.id }} />
            <PasskeysCard scope={{ kind: "instance", instanceId: instance.id }} />
            <SessionsCard scope={{ kind: "instance", instanceId: instance.id }} />

            {/* ROUND 87 (account lifecycle) — the owner's danger zone:
                تعطيل الحساب (pause) + حذف الحساب (soft-delete to trash),
                both password-proven with strict confirmation ceremonies. */}
            <DashCard title={t("dangerZoneTitle")} icon="alert-triangle">
              <p className="text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                {t("dangerZoneDesc")}
              </p>

              <div className="mt-4 grid gap-4 lg:grid-cols-2">
                {/* تعطيل الحساب — reversible pause */}
                <div className="rounded-2xl border border-amber-300/70 bg-amber-50/60 p-4 dark:border-amber-400/25 dark:bg-amber-400/[0.06]">
                  <div className="flex items-start gap-3">
                    <span
                      className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-lg"
                      style={{ backgroundImage: grad("#f59e0b", "#f97316") }}
                    >
                      <CatIcon name="pause" className="h-4.5 w-4.5" />
                    </span>
                    <div className="min-w-0">
                      <h4 className="font-display text-[13.5px] font-extrabold text-slate-900 dark:text-white">
                        {t("ownerDisableTitle")}
                      </h4>
                      <p className="mt-1 text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                        {t("ownerDisableDesc")}
                      </p>
                    </div>
                  </div>
                  <Button
                    type="button"
                    onClick={() => {
                      setDisablePw("");
                      setDisableReason("");
                      setDisableOpen(true);
                    }}
                    className="mt-4 h-10 w-full rounded-xl bg-linear-to-l from-amber-500 to-orange-500 text-[12.5px] font-extrabold text-white shadow-lg shadow-amber-500/25 transition hover:brightness-110 active:scale-95"
                  >
                    <CatIcon name="pause" className="h-4 w-4" />
                    {t("ownerDisableBtn")}
                  </Button>
                </div>

                {/* حذف الحساب — soft-delete to platform trash */}
                <div className="rounded-2xl border border-rose-300/70 bg-rose-50/60 p-4 dark:border-rose-400/25 dark:bg-rose-400/[0.06]">
                  <div className="flex items-start gap-3">
                    <span
                      className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-lg"
                      style={{ backgroundImage: grad("#f43f5e", "#be123c") }}
                    >
                      <CatIcon name="trash-2" className="h-4.5 w-4.5" />
                    </span>
                    <div className="min-w-0">
                      <h4 className="font-display text-[13.5px] font-extrabold text-slate-900 dark:text-white">
                        {t("ownerDeleteTitle")}
                      </h4>
                      <p className="mt-1 text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                        {t("ownerDeleteDesc", { n: 30 })}
                      </p>
                    </div>
                  </div>
                  <Button
                    type="button"
                    onClick={() => {
                      setDeletePw("");
                      setDeleteTyped("");
                      setDeleteOpen(true);
                    }}
                    className="mt-4 h-10 w-full rounded-xl bg-linear-to-l from-rose-600 to-rose-500 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:brightness-110 active:scale-95"
                  >
                    <CatIcon name="trash-2" className="h-4 w-4" />
                    {t("ownerDeleteBtn")}
                  </Button>
                </div>
              </div>
            </DashCard>
          </TabsContent>

          {/* ---- tab 5 · data & backup ---- */}
          <TabsContent value="data" className="space-y-5">
            {/* data management + workspace facts (round 25) */}
            <DashCard title={t("settingsDataSection")} icon="database">
              <div className="grid gap-3 lg:grid-cols-2">
                {/* data export — ROUND 79: plan gate (compact inline banner
                    replaces the buttons when dataExport is outside the plan) */}
                <FeatureGate feature="dataExport" instance={instance} compact>
                  <div className="rounded-2xl border border-slate-200/80 bg-slate-50/40 p-4 dark:border-white/10 dark:bg-white/[0.02]">
                    <p className="flex items-center gap-2 text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                      <CatIcon name="download" className="h-4 w-4 text-emerald-500" />
                      {t("settingsDataExportTitle")}
                    </p>
                    <p className="mt-1 text-[11.5px] leading-relaxed text-slate-500 dark:text-slate-400">
                      {t("settingsDataExportDesc")}
                    </p>
                    <div className="mt-3 flex flex-wrap gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => window.open(instanceExportUrl(instance.id, "summary"), "_blank", "noopener,noreferrer")}
                        className="h-9 gap-2 rounded-xl px-3.5 text-[11.5px] font-bold hover:border-emerald-300 hover:text-emerald-600"
                      >
                        <CatIcon name="file-text" className="h-3.5 w-3.5" />
                        {t("settingsExportSummary")}
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => window.open(instanceExportUrl(instance.id, "activities"), "_blank", "noopener,noreferrer")}
                        className="h-9 gap-2 rounded-xl px-3.5 text-[11.5px] font-bold hover:border-emerald-300 hover:text-emerald-600"
                      >
                        <CatIcon name="database" className="h-3.5 w-3.5" />
                        {t("settingsExportFull")}
                      </Button>
                    </div>
                  </div>
                </FeatureGate>

                {/* ROUND 88 — workspace identity: the round-25 plain facts
                    <dl> block is DELETED (owner directive: «احذفها تمام ثم
                    طورها بطريقة جذابة وPremium») — replaced by the designed
                    identity panel (gradient rail + fact chips + copyable ID) */}
                <WorkspaceFactsPanel instance={instance} />
              </div>
            </DashCard>

            {/* ROUND 41 (task 4) — backup & restore (its buttons are standalone
                actions and it holds no nested <form>, so it safely renders
                inside the outer settings form). ROUND 79 — plan gate: the
                whole section renders the compact premium lock banner when
                backup is outside the plan. */}
            <FeatureGate feature="backup" instance={instance} compact>
              <BackupRestoreSection instance={instance} />
            </FeatureGate>
          </TabsContent>
        </Tabs>

        {/* save */}
        <div className="flex justify-end">
          <Button
            type="submit"
            disabled={saving}
            className="h-11 rounded-xl px-6 text-[13px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
            style={{ backgroundImage: grad(c1, c2) }}
          >
            {saving ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : <CatIcon name="check" className="h-4 w-4" />}
            {t("settingsSave")}
          </Button>
        </div>
      </form>

      {/* ROUND 87 (account lifecycle) — the danger-zone confirmation dialogs */}
      <AlertDialog open={disableOpen} onOpenChange={(open) => !disableAccount.isPending && setDisableOpen(open)}>
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="max-w-md rounded-3xl border-border/60 bg-background/95 p-6 backdrop-blur-xl">
          <AlertDialogHeader>
            <div className="flex items-start gap-3">
              <span
                className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
                style={{ backgroundImage: grad("#f59e0b", "#f97316") }}
              >
                <CatIcon name="pause" className="h-5 w-5" />
              </span>
              <div className="min-w-0">
                <AlertDialogTitle className="text-start font-display text-[16px] font-extrabold leading-snug">
                  {t("ownerDisableTitle")}
                </AlertDialogTitle>
                <AlertDialogDescription className="text-start text-[12px] font-semibold leading-relaxed">
                  {t("ownerDisableDesc")}
                </AlertDialogDescription>
              </div>
            </div>
          </AlertDialogHeader>

          <div className="space-y-3">
            <div>
              <Label htmlFor="danger-disable-pw" className={WZ_LABEL}>
                {t("ownerDisablePwLabel")} <span className="text-rose-500">*</span>
              </Label>
              <Input
                id="danger-disable-pw"
                type="password"
                dir="ltr"
                value={disablePw}
                onChange={(e) => setDisablePw(e.target.value)}
                placeholder="••••••••"
                autoComplete="current-password"
                disabled={disableAccount.isPending}
                className={`${WZ_INPUT} text-start`}
              />
            </div>
            <div>
              <Label htmlFor="danger-disable-reason" className={WZ_LABEL}>
                {t("ownerDisableReasonLabel")}
              </Label>
              <Input
                id="danger-disable-reason"
                type="text"
                value={disableReason}
                onChange={(e) => setDisableReason(e.target.value)}
                maxLength={200}
                disabled={disableAccount.isPending}
                className={`${WZ_INPUT} text-start`}
              />
            </div>
          </div>

          <AlertDialogFooter className="mt-2 gap-2">
            <AlertDialogCancel disabled={disableAccount.isPending} className="h-10 rounded-xl px-4 text-[12.5px] font-extrabold">
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              disabled={disablePw.length === 0 || disableAccount.isPending}
              onClick={(e) => {
                e.preventDefault();
                disableAccount.mutate();
              }}
              className="h-10 rounded-xl bg-linear-to-l from-amber-500 to-orange-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-amber-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-50"
            >
              {disableAccount.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="pause" className="h-4 w-4" />
              )}
              {t("ownerDisableConfirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={deleteOpen} onOpenChange={(open) => !deleteAccount.isPending && setDeleteOpen(open)}>
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="max-w-md rounded-3xl border-border/60 bg-background/95 p-6 backdrop-blur-xl">
          <AlertDialogHeader>
            <div className="flex items-start gap-3">
              <span
                className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
                style={{ backgroundImage: grad("#f43f5e", "#be123c") }}
              >
                <CatIcon name="trash-2" className="h-5 w-5" />
              </span>
              <div className="min-w-0">
                <AlertDialogTitle className="text-start font-display text-[16px] font-extrabold leading-snug">
                  {t("ownerDeleteTitle")}
                </AlertDialogTitle>
                <AlertDialogDescription className="text-start text-[12px] font-semibold leading-relaxed">
                  {t("ownerDeleteDesc", { n: 30 })}
                </AlertDialogDescription>
              </div>
            </div>
          </AlertDialogHeader>

          <div className="space-y-3">
            <div>
              <Label htmlFor="danger-delete-pw" className={WZ_LABEL}>
                {t("ownerDeletePwLabel")} <span className="text-rose-500">*</span>
              </Label>
              <Input
                id="danger-delete-pw"
                type="password"
                dir="ltr"
                value={deletePw}
                onChange={(e) => setDeletePw(e.target.value)}
                placeholder="••••••••"
                autoComplete="current-password"
                disabled={deleteAccount.isPending}
                className={`${WZ_INPUT} text-start`}
              />
            </div>
            <div>
              <Label htmlFor="danger-delete-typed" className={WZ_LABEL}>
                {t("trashConfirmType", { word: t("trashConfirmWord") })} <span className="text-rose-500">*</span>
              </Label>
              <Input
                id="danger-delete-typed"
                type="text"
                dir="auto"
                value={deleteTyped}
                onChange={(e) => setDeleteTyped(e.target.value)}
                disabled={deleteAccount.isPending}
                aria-invalid={deleteTyped.length > 0 && deleteTyped !== t("trashConfirmWord") || undefined}
                className={`${WZ_INPUT} text-center font-extrabold tracking-wide ${deleteTyped.length > 0 && deleteTyped !== t("trashConfirmWord") ? "border-rose-400 focus-visible:ring-rose-400" : ""}`}
              />
            </div>
          </div>

          <AlertDialogFooter className="mt-2 gap-2">
            <AlertDialogCancel disabled={deleteAccount.isPending} className="h-10 rounded-xl px-4 text-[12.5px] font-extrabold">
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              disabled={deletePw.length === 0 || deleteTyped !== t("trashConfirmWord") || deleteAccount.isPending}
              onClick={(e) => {
                e.preventDefault();
                deleteAccount.mutate();
              }}
              className="h-10 rounded-xl bg-linear-to-l from-rose-600 to-rose-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-50"
            >
              {deleteAccount.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="trash-2" className="h-4 w-4" />
              )}
              {t("ownerDeleteConfirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
