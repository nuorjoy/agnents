"use client";

/**
 * Ashrilogic — ROUND 134: the الورديات MODULE WORKSPACE.
 *
 * The owner's directive: «في جميع الأنظمة الـ100 عند (الوحدات) أضف
 * (الورديات) يمكن تفعيله او ايقافه نفس طريقة تحكم الوحدات». Clicking the
 * ENABLED الورديات card in the الوحدات control lands HERE — the full-page
 * premium surface for the strict shift system, powered by REAL Shift rows
 * (the same ["shifts", id] cache the global status bar, the topbar logout
 * gate and the business-suite mutation gates feed from):
 *
 *   • KPI strip — live shift state (open / locked), recorded shifts count,
 *     total sales across all closed shifts, net cumulative drawer variance;
 *   • the CURRENT shift card — emerald live strip: Western-digit SHF code
 *     (the R134 ID policy), ticking elapsed, live aggregates (sales count,
 *     total, cash vs card, discount) + close / secret-code actions;
 *   • the closed-shift history — the same premium reconciliation cards the
 *     history dialog renders (code, variance pill, duration, opener/closer,
 *     sales stats, closing note).
 *
 * While the module is DISABLED the workspace renders the amber stand-down
 * notice (the server answers moduleDisabled + no state). All numerals follow
 * the split policy: IDs in Western digits + dir={idDir} (R134), money and
 * quantities in Arabic-Indic + dir={numDir(lang)} (R133).
 */
import { useEffect, useState } from "react";
import { useT } from "@/lib/i18n";
import type { InstanceDTO } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { cn, fmtId, fmtMoneyCell, fmtNum, grad, idDir, numDir } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { DashCard, ViewHeading, fullDate } from "@/components/dashboard/dash-shared";
import { shiftElapsedLabel, useShift } from "@/components/dashboard/shift/use-shift";
import {
  ShiftCloseDialog,
  ShiftCodeDialog,
  ShiftDetailsDialog,
  ShiftHistoryRow,
  ShiftOpenDialog,
} from "@/components/dashboard/shift/shift-dialogs";

type ShiftDialogKind = "open" | "close" | "code" | "details" | null;

/* ------------------------------------------------------------------ */
/* KPI card (compact — matches the workspace strip conventions)        */
/* ------------------------------------------------------------------ */

function WsKpi({
  icon,
  label,
  value,
  sub,
  dir,
  tone,
  c1,
  c2,
}: {
  icon: string;
  label: string;
  value: string;
  sub?: string;
  dir?: "ltr" | "rtl";
  tone?: "open" | "locked" | "flat" | "up" | "down";
  c1: string;
  c2: string;
}) {
  const toneText =
    tone === "open"
      ? "text-emerald-600 dark:text-emerald-400"
      : tone === "locked"
        ? "text-rose-600 dark:text-rose-400"
        : tone === "up"
          ? "text-emerald-600 dark:text-emerald-400"
          : tone === "down"
            ? "text-rose-600 dark:text-rose-400"
            : "text-slate-800 dark:text-slate-100";
  return (
    <div className="rounded-2xl border border-slate-200/80 bg-white/70 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
      <div className="flex items-center gap-2.5">
        <span
          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
          style={{ backgroundImage: grad(c1, c2) }}
          aria-hidden="true"
        >
          <CatIcon name={icon} className="h-4 w-4" />
        </span>
        <div className="min-w-0">
          <p className="truncate text-[10px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">{label}</p>
          <p dir={dir} className={cn("mt-0.5 truncate font-display text-[17px] font-extrabold tabular-nums", toneText)}>
            {value}
          </p>
          {sub ? <p className="truncate text-[10px] font-bold text-slate-400 dark:text-slate-500">{sub}</p> : null}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* the workspace                                                       */
/* ------------------------------------------------------------------ */

export function ShiftsWorkspace({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const shiftsEnabled = instance.modules.includes("shifts");
  const { data, isPending } = useShift(instance.id, shiftsEnabled);
  const [dialog, setDialog] = useState<ShiftDialogKind>(null);
  /* the elapsed re-render tick (open shift only, 30s) */
  const [, setNowTick] = useState(0);

  const current = data?.current ?? null;
  const history = data?.history ?? [];
  const currency = instance.org.currency;
  const rtl = lang === "ar";

  /* LIVE elapsed timer — only while a shift is open. */
  const openedAt = current?.openedAt;
  useEffect(() => {
    if (!openedAt) return;
    const timer = window.setInterval(() => setNowTick(Date.now()), 30_000);
    return () => window.clearInterval(timer);
  }, [openedAt]);

  const closeDialog = () => setDialog(null);

  /* derived KPI values (closed history — the current shift's live numbers
   * render on its own card, not double-counted here) */
  const totalHistorySales = history.reduce((sum, h) => sum + h.aggregates.salesTotal, 0);
  const totalHistoryCount = history.reduce((sum, h) => sum + h.aggregates.salesCount, 0);
  const netVariance = history.reduce((sum, h) => sum + (h.variance ?? 0), 0);

  const title = lang === "ar" ? "الورديات" : "Shifts";

  /* ---------------- module disabled → the stand-down notice ---------------- */
  if (!shiftsEnabled || data?.moduleDisabled) {
    return (
      <div className="space-y-5">
        <ViewHeading title={title} desc={t("shiftWsDesc")} />
        <div
          dir={rtl ? "rtl" : "ltr"}
          className="flex items-center gap-3 rounded-2xl border border-amber-300/60 bg-linear-to-l from-amber-50/90 to-orange-50/50 px-4 py-3 dark:border-amber-500/25 dark:from-amber-500/10 dark:to-orange-500/5"
          role="status"
        >
          <span
            className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-md"
            style={{ backgroundImage: grad("#f59e0b", "#ea580c") }}
            aria-hidden="true"
          >
            <CatIcon name="power" className="h-5 w-5" />
          </span>
          <p className="min-w-0 flex-1 text-[12px] font-extrabold text-amber-800 dark:text-amber-200">{t("shiftWsModuleOff")}</p>
        </div>
      </div>
    );
  }

  /* ---------------- the live workspace ---------------- */
  return (
    <div className="space-y-5">
      <ViewHeading title={title} desc={t("shiftWsDesc")} />

      {/* KPI strip */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <WsKpi
          icon={current ? "door-open" : "lock"}
          label={t("shiftWsKpiState")}
          value={current ? t("shiftWsKpiStateOpen") : t("shiftWsKpiStateLocked")}
          sub={current ? t("shiftBarOpenSince", { time: shiftElapsedLabel(lang, current.openedAt) }) : t("shiftBarLockedHint")}
          tone={current ? "open" : "locked"}
          c1={current ? "#10b981" : "#f43f5e"}
          c2={current ? "#059669" : "#e11d48"}
        />
        <WsKpi
          icon="clock-rotate-left"
          label={t("shiftWsKpiCount")}
          value={fmtNum(history.length + (current ? 1 : 0), lang)}
          sub={`${t("shiftAggSales")} ${fmtNum(totalHistoryCount, lang)}`}
          dir={numDir(lang)}
          c1="#6366f1"
          c2="#8b5cf6"
        />
        <WsKpi
          icon="coins"
          label={t("shiftWsKpiTotal")}
          value={fmtMoneyCell(totalHistorySales, lang, currency)}
          sub={t("shiftWsHistoryTitle")}
          dir={numDir(lang)}
          c1="#0ea5e9"
          c2="#0369a1"
        />
        <WsKpi
          icon="scale"
          label={t("shiftWsKpiVariance")}
          value={fmtMoneyCell(netVariance, lang, currency)}
          sub={netVariance === 0 ? t("shiftVarianceOk") : netVariance > 0 ? t("shiftVarianceOver") : t("shiftVarianceShort")}
          dir={numDir(lang)}
          tone={netVariance === 0 ? "flat" : netVariance > 0 ? "up" : "down"}
          c1="#14b8a6"
          c2="#0d9488"
        />
      </div>

      {/* the current shift card (or the locked state) */}
      <DashCard title={t("shiftWsOpenNow")} icon="timer">
        {isPending && !data ? (
          <div className="flex h-24 items-center justify-center text-[12px] font-bold text-slate-400">…</div>
        ) : current ? (
          <div
            dir={rtl ? "rtl" : "ltr"}
            className="rounded-2xl border border-emerald-300/60 bg-linear-to-l from-emerald-50/90 to-teal-50/50 p-4 dark:border-emerald-500/25 dark:from-emerald-500/10 dark:to-teal-500/5"
          >
            <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
              {/* live pulse + code chip (R134: Western digits, LTR) */}
              <span className="relative flex h-2.5 w-2.5 shrink-0" aria-hidden="true">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-500" />
              </span>
              <span
                dir={idDir}
                className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200/80 bg-white/85 px-3 py-1 font-mono text-[11.5px] font-extrabold text-emerald-700 dark:border-emerald-500/25 dark:bg-white/[0.06] dark:text-emerald-300"
              >
                <CatIcon name="hash" className="h-3 w-3" aria-hidden="true" />
                {fmtId(current.code, lang)}
              </span>
              <span className="inline-flex shrink-0 items-center gap-1.5 text-[11px] font-bold text-emerald-700/90 dark:text-emerald-300/80">
                <CatIcon name="user-round" className="h-3.5 w-3.5" aria-hidden="true" />
                {t("shiftOpenedBy")} <span className="font-extrabold text-emerald-800 dark:text-emerald-200">{current.openedBy}</span>
                <span className="text-slate-400 dark:text-slate-500">· {fullDate(current.openedAt, lang)}</span>
              </span>
              <span className="ms-auto flex shrink-0 flex-wrap items-center gap-1.5">
                {/* ROUND 138 — the premium DETAILS lever on the live card
                    (opening float + the full readout while the drawer runs). */}
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => setDialog("details")}
                  className="h-9 gap-1.5 rounded-lg px-2.5 text-[11.5px] font-bold text-emerald-700/90 transition hover:bg-emerald-50 hover:text-emerald-800 active:scale-95 dark:text-emerald-300/80 dark:hover:bg-emerald-500/10"
                >
                  <CatIcon name="eye" className="h-4 w-4" />
                  {t("shiftDetailsBtn")}
                </Button>
                <Button
                  type="button"
                  onClick={() => setDialog("close")}
                  className="h-9 gap-1.5 rounded-lg border border-emerald-300/80 bg-white/85 px-3.5 text-[11.5px] font-extrabold text-emerald-700 transition hover:bg-emerald-50 active:scale-95 dark:border-emerald-500/30 dark:bg-white/[0.07] dark:text-emerald-300 dark:hover:bg-white/[0.12]"
                >
                  <CatIcon name="door-closed" className="h-4 w-4" />
                  {t("shiftWsCloseBtn")}
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => setDialog("code")}
                  className="h-9 gap-1.5 rounded-lg px-2.5 text-[11.5px] font-bold text-emerald-700/90 transition hover:bg-emerald-50 hover:text-emerald-800 active:scale-95 dark:text-emerald-300/80 dark:hover:bg-emerald-500/10"
                >
                  <CatIcon name="key-round" className="h-4 w-4" />
                  {t("shiftWsCodeBtn")}
                </Button>
              </span>
            </div>

            {/* live aggregates grid */}
            <div className="mt-3 grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-4">
              {[
                { icon: "receipt", label: t("shiftAggSales"), value: fmtNum(current.aggregates.salesCount, lang) },
                { icon: "coins", label: t("shiftAggTotal"), value: fmtMoneyCell(current.aggregates.salesTotal, lang, currency), strong: true },
                { icon: "banknote", label: t("shiftAggCash"), value: fmtMoneyCell(current.aggregates.cashTotal, lang, currency) },
                { icon: "credit-card", label: t("shiftAggCard"), value: fmtMoneyCell(current.aggregates.cardTotal, lang, currency) },
              ].map((cell) => (
                <div
                  key={cell.label}
                  className="rounded-xl border border-emerald-200/60 bg-white/70 px-3 py-2 dark:border-emerald-500/15 dark:bg-white/[0.04]"
                >
                  <p className="flex items-center gap-1 text-[9.5px] font-extrabold uppercase tracking-wide text-emerald-600/80 dark:text-emerald-300/70">
                    <CatIcon name={cell.icon} className="h-2.5 w-2.5" aria-hidden="true" />
                    {cell.label}
                  </p>
                  <p
                    dir={numDir(lang)}
                    className={cn(
                      "mt-1 truncate tabular-nums",
                      cell.strong
                        ? "text-[14px] font-extrabold text-emerald-700 dark:text-emerald-300"
                        : "text-[12.5px] font-extrabold text-emerald-800/90 dark:text-emerald-200/90"
                    )}
                  >
                    {cell.value}
                  </p>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div
            dir={rtl ? "rtl" : "ltr"}
            className="flex flex-wrap items-center gap-x-3 gap-y-2 rounded-2xl border border-rose-300/60 bg-linear-to-l from-rose-50/90 to-orange-50/50 p-4 dark:border-rose-500/25 dark:from-rose-500/10 dark:to-orange-500/5"
          >
            <span
              className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-md"
              style={{ backgroundImage: grad("#f43f5e", "#e11d48") }}
              aria-hidden="true"
            >
              <CatIcon name="lock" className="h-5 w-5" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-[12.5px] font-extrabold text-rose-700 dark:text-rose-300">{t("shiftWsOpenNowEmpty")}</p>
              <p className="mt-0.5 text-[10.5px] font-semibold leading-snug text-rose-500/90 dark:text-rose-300/70">{t("shiftBarLockedHint")}</p>
            </div>
            <Button
              type="button"
              onClick={() => setDialog("open")}
              className="h-9 shrink-0 gap-1.5 rounded-lg bg-linear-to-l from-rose-500 to-orange-500 px-4 text-[11.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:brightness-110 active:scale-95"
            >
              <CatIcon name="unlock" className="h-4 w-4" />
              {t("shiftWsOpenBtn")}
            </Button>
          </div>
        )}
      </DashCard>

      {/* closed-shift history — the REAL rows (same premium cards) */}
      <DashCard title={t("shiftWsHistoryTitle")} icon="clock-rotate-left">
        {history.length === 0 ? (
          <div className="flex h-24 flex-col items-center justify-center gap-1.5 text-center">
            <CatIcon name="history" className="h-6 w-6 text-slate-300 dark:text-slate-600" aria-hidden="true" />
            <p className="text-[12px] font-bold text-slate-400 dark:text-slate-500">{t("shiftHistoryEmpty")}</p>
          </div>
        ) : (
          <div className="nice-scroll grid max-h-96 gap-2.5 overflow-y-auto pr-1">
            {history.map((shift) => (
              <ShiftHistoryRow key={shift.id} shift={shift} lang={lang} currency={currency} />
            ))}
          </div>
        )}
      </DashCard>

      {/* the shared dialogs (mutations invalidate ["shifts", id] → this
       * workspace + the global bar + every gate flips in the same tick) */}
      <ShiftOpenDialog open={dialog === "open"} onOpenChange={closeDialog} instance={instance} />
      <ShiftCloseDialog open={dialog === "close"} onOpenChange={closeDialog} instance={instance} />
      <ShiftCodeDialog open={dialog === "code"} onOpenChange={closeDialog} instance={instance} />
      {/* ROUND 138 — the live current shift's premium details sheet */}
      {current ? (
        <ShiftDetailsDialog
          shift={current}
          lang={lang}
          currency={currency}
          open={dialog === "details"}
          onOpenChange={closeDialog}
        />
      ) : null}
    </div>
  );
}

export function ShiftsWorkspaceSkeleton() {
  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} className="h-[72px] animate-pulse rounded-2xl bg-slate-100 dark:bg-white/5" />
      ))}
    </div>
  );
}

export default ShiftsWorkspace;
