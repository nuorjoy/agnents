"use client";

/**
 * Dashboard — overview view: KPI cards (real stats + sparklines), revenue
 * area chart, tasks donut, quick actions, active modules, recent activity,
 * system health and the getting-started checklist.
 *
 * ROUND 136 — the KPI cards migrated onto the unified StatCard; the local
 * KpiCard copy was deleted.
 * ROUND 139 — the strip now renders THE golden inventory-page card law
 * (size="golden" inside the exact inventory grid grid-cols-2 → md:grid-cols-3
 * → xl:grid-cols-5), expanded 4 → 5 KPIs: the ACTIVE-MODULES count is promoted
 * to its own headline card (sub-line: the catalog size) so the golden 5-column
 * grid fills exactly. The MoM revenue delta folds into the golden sub-line
 * (up/down tone carries its color); the lg-only sparkline slot is retired by
 * the golden law — the full trend keeps its dedicated RevenueChart below.
 */
import dynamic from "next/dynamic";
import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { MODULE_MAP } from "@/data/catalog";
import { useT } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import type { InstanceDTO, InstanceStats, Lang, TeamMemberDTO } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { cn, fmtMoneyCell, fmtNum, grad, numDir } from "@/lib/utils";
import { fmtPlanPrice } from "@/lib/format";
import { StatCard } from "@/components/shared/stat-card";
import { Button } from "@/components/ui/button";
import { ACT_STYLE, DashCard, IconTile, MeterBar, relativeTime } from "@/components/dashboard/dash-shared";
import { useAccentPair } from "@/components/dashboard/accent-context";
import { trialCountdownText } from "@/components/dashboard/smart-countdown";
import { fetchModuleRecords } from "@/lib/api-client";
import { buildModuleDataset, type ModuleDataset } from "@/lib/module-data";

/* recharts subtree — lazy chunk: KPI cards and text stay eager, the chart
   SVG machinery streams in on demand (container heights are reserved by the
   eager wrappers, so the placeholders never shift layout). */
function ChartLoading() {
  return (
    <div
      className="h-full w-full animate-pulse rounded-2xl bg-slate-100/70 dark:bg-white/[0.04]"
      aria-hidden="true"
    />
  );
}

const RevenueChart = dynamic(() => import("./overview-charts").then((m) => m.RevenueChart), {
  ssr: false,
  loading: ChartLoading,
});

/* ---------------- round 29 — quick-action tile vocabulary ---------------- */

/** flagship modules get their own fixed icon + gradient */
const QA_PRIORITY: { id: string; icon: string; c1: string; c2: string }[] = [
  { id: "patients", icon: "heart-pulse", c1: "#f43f5e", c2: "#be185d" },
  { id: "invoices", icon: "receipt", c1: "#f59e0b", c2: "#ea580c" },
  { id: "staff", icon: "user-tie", c1: "#06b6d4", c2: "#0891b2" },
  { id: "customers", icon: "users-round", c1: "#10b981", c2: "#059669" },
  { id: "members", icon: "id-card", c1: "#6d5dfb", c2: "#a855f7" },
  { id: "products", icon: "package-open", c1: "#d946ef", c2: "#c026d3" },
  { id: "students", icon: "graduation-cap", c1: "#6366f1", c2: "#7c3aed" },
  { id: "queue", icon: "timer", c1: "#f97316", c2: "#ea580c" },
];

/** module tiles shown before the fixed website / site-customers utility tiles */
const QA_MAX_TILES = 6;

/** localized module name with a safe fallback to the raw key */
function moduleName(id: string, lang: Lang): string {
  const m = MODULE_MAP[id];
  return m ? (lang === "ar" ? m.nameAr : m.nameEn) : id;
}

/* ---------------- view ---------------- */

export function OverviewView({
  instance,
  stats,
  members,
}: {
  instance: InstanceDTO;
  stats: InstanceStats;
  members: TeamMemberDTO[];
}) {
  const { t, lang } = useT();
  const setDashView = useAppStore((s) => s.setDashView);
  const setActiveModuleId = useAppStore((s) => s.setActiveModuleId);

  /* ROUND 143 — the shell-wide effective accent: an owner-picked theme
   * recolors the overview KPIs/charts together with the whole system. */
  const { c1, c2 } = useAccentPair();

  const last = stats.revenue[stats.revenue.length - 1]?.value ?? 0;
  const prev = stats.revenue[stats.revenue.length - 2]?.value ?? last;
  const delta = prev > 0 ? ((last - prev) / prev) * 100 : 0;

  /* TASK K (R150) — Net Income: revenue − total expenses. The expenses
   * module is universal (every system carries it), so this is safe on
   * every workspace. We mirror the analytics-view pattern: real rows
   * via fetchModuleRecords take over when present; otherwise the
   * deterministic demo dataset (buildModuleDataset, matches the module
   * workspace's «العرض التوضيحي» tab) drives the total. */
  const currency = stats.currency ?? (stats.demo ? "$" : "");
  const expensesQuery = useQuery({
    queryKey: ["module-records", instance.id, "expenses"],
    queryFn: () => fetchModuleRecords(instance.id, "expenses"),
    staleTime: 30_000,
    retry: 0,
  });
  /* ROUND 166 — DEMO LIFECYCLE: the deterministic expenses showcase backs
   * the net-income card ONLY while prefs.demo is enabled; retired → the
   * card reflects the tenant's real rows alone (the honest zero). The
   * preset is still built (cheap, deterministic) because REAL rows are
   * validated against its column layout — only the demo ROWS retire. */
  const demoEnabled = instance.prefs.demo !== false;
  const demoExpenses = useMemo(
    () => buildModuleDataset(instance.id, "expenses", lang, currency, instance.systemId) as ModuleDataset,
    [instance.id, instance.systemId, lang, currency],
  );
  const totalExpenses = useMemo(() => {
    const cols = demoExpenses.cols;
    const iGross = cols.findIndex((c) => c.key === "grossAmount");
    if (iGross < 0) return 0;
    const realRows = expensesQuery.data ?? [];
    const rows = realRows.length > 0 ? realRows : demoEnabled ? demoExpenses.rows : [];
    let sum = 0;
    for (const r of rows) sum += Number(r.values[iGross] ?? 0) || 0;
    return sum;
  }, [demoExpenses, expensesQuery.data, demoEnabled]);

  /* The 12-month revenue SUM (the analytics view's revenueModel.sum);
   * on the overview we approximate with `last` (the most recent month)
   * × 12 to align with the KPI strip's «الإيرادات الشهرية» framing —
   * but we also compute the actual sum so net income is honest. */
  const revenueSum = useMemo(
    () => stats.revenue.reduce((s, p) => s + (p.value ?? 0), 0),
    [stats.revenue],
  );
  const netIncome = revenueSum - totalExpenses;
  const expenseRatio = revenueSum > 0 ? (totalExpenses / revenueSum) * 100 : 0;

  /* TASK K (R150) — System Health indicator: traffic-light derived
   * from today's activity + uptime. GREEN when active and high uptime;
   * YELLOW when activity is low OR uptime dips; RED when nothing is
   * happening OR uptime is poor. */
  const health = useMemo(() => {
    const act = stats.activityToday ?? 0;
    const up = stats.uptime ?? 0;
    if (act === 0 || up < 95) {
      return {
        tone: "down" as const,
        color: "#f43f5e",
        color2: "#be185d",
        icon: "circle-x",
        labelKey: "dashSystemHealthDown" as const,
        descKey: "dashSystemHealthDownDesc" as const,
      };
    }
    if (act < 5 || up < 99) {
      return {
        tone: "warn" as const,
        color: "#f59e0b",
        color2: "#d97706",
        icon: "triangle-alert",
        labelKey: "dashSystemHealthWarn" as const,
        descKey: "dashSystemHealthWarnDesc" as const,
      };
    }
    return {
      tone: "good" as const,
      color: "#10b981",
      color2: "#047857",
      icon: "circle-check",
      labelKey: "dashSystemHealthGood" as const,
      descKey: "dashSystemHealthGoodDesc" as const,
    };
  }, [stats.activityToday, stats.uptime]);

  /* ROUND 141 (㉚) — the REAL subscription strip's live state (the
   * entitlement mirror + the smart Arabic trial countdown, same source
   * as the sidebar chips). */
  const entitlement = instance.entitlement;
  const trialCountdown = trialCountdownText(entitlement, lang, t) ?? "";

  /* open a module workspace straight from the overview */
  const openModule = (moduleId: string) => {
    setActiveModuleId(moduleId);
    setDashView("module");
  };

  /* round 29 — premium quick-action tiles derived from the ENABLED modules:
   * flagship modules first (fixed icon + gradient), then the remaining slots
   * filled from other enabled modules (module icon + the category gradient),
   * plus two fixed utility tiles (website · site customers) at the end. */
  const quickTiles: {
    key: string;
    icon: string;
    c1: string;
    c2: string;
    label: string;
    onClick: () => void;
  }[] = [];
  {
    const picked: string[] = [];
    for (const flagship of QA_PRIORITY) {
      if (picked.length >= QA_MAX_TILES) break;
      if (!instance.modules.includes(flagship.id)) continue;
      picked.push(flagship.id);
      quickTiles.push({
        key: `mod-${flagship.id}`,
        icon: flagship.icon,
        c1: flagship.c1,
        c2: flagship.c2,
        label: moduleName(flagship.id, lang),
        onClick: () => openModule(flagship.id),
      });
    }
    for (const key of instance.modules) {
      if (picked.length >= QA_MAX_TILES) break;
      if (picked.includes(key)) continue;
      picked.push(key);
      quickTiles.push({
        key: `mod-${key}`,
        icon: MODULE_MAP[key]?.icon ?? "cubes",
        c1,
        c2,
        label: moduleName(key, lang),
        onClick: () => openModule(key),
      });
    }
  }
  quickTiles.push(
    {
      key: "view-website",
      icon: "globe",
      c1: "#0ea5e9",
      c2: "#0369a1",
      label: t("dashWebsite"),
      onClick: () => setDashView("website"),
    },
    {
      key: "view-customers",
      icon: "users-round",
      c1: "#6d5dfb",
      c2: "#a855f7",
      label: t("dashCustomers"),
      onClick: () => setDashView("customers"),
    }
  );

  return (
    <div className="space-y-5">
      {/* welcome header + ROUND 61 (H-8) data-provenance badge */}
      <div>
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5">
          <h1 className="font-display text-2xl font-extrabold text-slate-900 dark:text-white">
            {instance.admin.name.trim()
              ? `${t("dashWelcomeBack")}${lang === "ar" ? "، " : ", "}${instance.admin.name}`
              : t("dashWelcomeBack")}
          </h1>
          {/* honest KPI provenance: demo numbers until the store takes real
           * orders, real aggregates afterwards (stats.demo from the API) */}
          {stats.demo ? (
            <span
              title={t("kpiDemoBadgeTitle")}
              className="inline-flex items-center gap-1.5 rounded-full border border-amber-300/70 bg-amber-500/10 px-2.5 py-1 text-[10.5px] font-extrabold text-amber-600 dark:border-amber-500/40 dark:bg-amber-500/10 dark:text-amber-300"
            >
              <CatIcon name="eye" className="h-3 w-3" />
              {t("kpiDemoBadge")}
            </span>
          ) : (
            <span
              title={t("kpiRealBadgeTitle")}
              className="inline-flex items-center gap-1.5 rounded-full border border-emerald-300/70 bg-emerald-500/10 px-2.5 py-1 text-[10.5px] font-extrabold text-emerald-600 dark:border-emerald-500/40 dark:bg-emerald-500/10 dark:text-emerald-300"
            >
              <CatIcon name="circle-check" className="h-3 w-3" />
              {t("kpiRealBadge")}
            </span>
          )}
        </div>
        <p className="mt-1 text-[13px] text-slate-500 dark:text-slate-400">{t("dashSystemReady")}</p>
      </div>

      {/* KPI cards — ROUND 139: THE golden inventory-page cards
          (grid-cols-2 → md:grid-cols-3 → xl:grid-cols-5) */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        <StatCard
          size="golden"
          label={t("dashKpiRevenue")}
          /* ROUND 61 (H-8) — real revenue carries the store's own currency
           * (SAR/AED/…); the showcase tier keeps the legacy $ shape */
          value={
            stats.demo
              ? `$${fmtNum(last, lang)}`
              : `${fmtNum(last, lang)} ${stats.currency ?? ""}`.trim()
          }
          sub={t("dashKpiRevenueSub", {
            delta: `${delta >= 0 ? "+" : "−"}${fmtNum(Math.abs(delta), lang)}${lang === "ar" ? "٪" : "%"}`,
          })}
          tone={delta >= 0 ? "up" : "down"}
          icon="wallet"
          c1={c1}
          c2={c2}
          index={0}
        />
        <StatCard
          size="golden"
          label={t("dashKpiActivity")}
          value={fmtNum(stats.activityToday, lang)}
          icon="bolt"
          c1="#f59e0b"
          c2="#d97706"
          index={1}
        />
        <StatCard
          size="golden"
          label={t("dashKpiUsers")}
          value={fmtNum(stats.users, lang)}
          icon="users"
          c1="#10b981"
          c2="#047857"
          index={2}
        />
        <StatCard
          size="golden"
          label={t("dashKpiUptime")}
          value={`${fmtNum(stats.uptime, lang)}%`}
          icon="shield-check"
          c1="#06b6d4"
          c2="#0891b2"
          index={3}
        />
        <StatCard
          size="golden"
          label={t("dashKpiModules")}
          value={fmtNum(instance.modules.length, lang)}
          sub={t("dashKpiModulesSub", { total: fmtNum(Object.keys(MODULE_MAP).length, lang) })}
          icon="grid-3x3"
          c1="#8b5cf6"
          c2="#7c3aed"
          index={4}
          tone="up"
        />
      </div>

      {/* TASK K (R150) — Net Income + System Health strip (2 cards).
          The owner's directive: «في جميع الأنظمة عند صفحة (نظرة عامة)
          تاكد أنها متكاملة وتلبي احتياجات المستخدم بصورة احترافية». */}
      <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
        {/* Net Income — revenue after expenses, with up/down tone */}
        <StatCard
          size="golden"
          label={netIncome >= 0 ? t("dashKpiNetIncome") : t("dashKpiNetIncomeLoss")}
          value={
            <span dir={numDir(lang)} className="tabular-nums">
              {stats.demo
                ? `$${fmtNum(Math.round(netIncome), lang)}`
                : fmtMoneyCell(Math.round(netIncome), lang, currency || undefined)}
            </span>
          }
          sub={netIncome >= 0 ? t("dashKpiNetIncomeSub") : t("dashKpiNetIncomeLossSub")}
          tone={netIncome >= 0 ? "up" : "down"}
          icon={netIncome >= 0 ? "trending-up" : "trending-down"}
          c1={netIncome >= 0 ? "#10b981" : "#f43f5e"}
          c2={netIncome >= 0 ? "#047857" : "#be185d"}
          index={0}
          ltrValue
        />
        {/* System Health — traffic-light pill + the 4-stat readout */}
        <DashCard title={t("dashSystemHealth")} icon="heart-pulse">
          <div className="space-y-3">
            <div className="flex items-center gap-3 rounded-2xl border border-slate-200/80 bg-white/60 p-3 dark:border-white/10 dark:bg-white/[0.03]">
              <IconTile icon={health.icon} c1={health.color} c2={health.color2} />
              <div className="min-w-0 flex-1">
                <p className={cn("text-[10px] font-extrabold uppercase", labelTrackClass(lang))} style={{ color: health.color }}>
                  {t(health.labelKey)}
                </p>
                <p className="mt-0.5 truncate text-[12px] font-bold text-slate-700 dark:text-slate-200">
                  {t(health.descKey)}
                </p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              <div className="rounded-xl border border-slate-100 bg-white/60 p-2.5 dark:border-white/[0.06] dark:bg-white/[0.03]">
                <p className={cn("text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrackClass(lang))}>
                  {t("dashSystemHealthActivity")}
                </p>
                <p dir={numDir(lang)} className="mt-0.5 font-display text-[15px] font-black tabular-nums text-slate-900 dark:text-white">
                  {fmtNum(stats.activityToday, lang)}
                </p>
              </div>
              <div className="rounded-xl border border-slate-100 bg-white/60 p-2.5 dark:border-white/[0.06] dark:bg-white/[0.03]">
                <p className={cn("text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrackClass(lang))}>
                  {t("dashSystemHealthUptime")}
                </p>
                <p dir={numDir(lang)} className="mt-0.5 font-display text-[15px] font-black tabular-nums text-slate-900 dark:text-white">
                  {fmtNum(stats.uptime, lang)}{lang === "ar" ? "٪" : "%"}
                </p>
              </div>
              <div className="rounded-xl border border-slate-100 bg-white/60 p-2.5 dark:border-white/[0.06] dark:bg-white/[0.03]">
                <p className={cn("text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrackClass(lang))}>
                  {t("dashSystemHealthUsers")}
                </p>
                <p dir={numDir(lang)} className="mt-0.5 font-display text-[15px] font-black tabular-nums text-slate-900 dark:text-white">
                  {fmtNum(stats.users, lang)}
                </p>
              </div>
              <div className="rounded-xl border border-slate-100 bg-white/60 p-2.5 dark:border-white/[0.06] dark:bg-white/[0.03]">
                <p className={cn("text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrackClass(lang))}>
                  {t("dashSystemHealthModules")}
                </p>
                <p dir={numDir(lang)} className="mt-0.5 font-display text-[15px] font-black tabular-nums text-slate-900 dark:text-white">
                  {fmtNum(instance.modules.length, lang)}
                </p>
              </div>
            </div>
            {/* expense-to-revenue ratio meter */}
            <div className="rounded-xl bg-slate-50/80 p-2.5 dark:bg-white/[0.03]">
              <div className="mb-1 flex items-baseline justify-between gap-2">
                <span className="text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
                  {t("analyticsExpenseRatio")}
                </span>
                <span dir={numDir(lang)} className="shrink-0 text-[10.5px] font-extrabold tabular-nums text-slate-500 dark:text-slate-400">
                  {fmtNum(Math.round(expenseRatio * 10) / 10, lang)}{lang === "ar" ? "٪" : "%"}
                </span>
              </div>
              <MeterBar value={Math.min(100, expenseRatio)} color={grad("#f43f5e", "#be185d")} />
            </div>
          </div>
        </DashCard>
      </div>

      {/* quick actions — premium module tiles (round 29) */}
      <div className="card-in" style={{ "--i": 4 } as React.CSSProperties}>
        <div className="mb-3 flex items-center gap-2.5">
          <span
            className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg"
            style={{ backgroundImage: grad(c1, c2) }}
            aria-hidden="true"
          >
            <CatIcon name="zap" className="h-[14px] w-[14px]" />
          </span>
          <div className="min-w-0">
            <h2 className="font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
              {t("dashQuickActions")}
            </h2>
            <p className="truncate text-[11.5px] font-semibold text-slate-400 dark:text-slate-500">
              {t("dashQuickActionsDesc")}
            </p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-6">
          {quickTiles.map((tile) => (
            <button
              key={tile.key}
              type="button"
              onClick={tile.onClick}
              className="group relative flex flex-col items-start gap-3 overflow-hidden rounded-2xl border border-slate-200/80 bg-white/70 p-3.5 text-start transition-all duration-300 hover:-translate-y-1 hover:border-transparent hover:shadow-lift active:scale-95 dark:border-white/10 dark:bg-white/[0.03]"
            >
              {/* gradient hairline — brightens on hover */}
              <span
                className="pointer-events-none absolute inset-x-0 top-0 h-[2px] opacity-40 transition-opacity duration-300 group-hover:opacity-100"
                style={{ backgroundImage: grad(tile.c1, tile.c2, 90) }}
                aria-hidden="true"
              />
              <span
                className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white transition-transform duration-300 group-hover:scale-110"
                style={{
                  backgroundImage: grad(tile.c1, tile.c2),
                  boxShadow: `0 10px 22px -10px ${tile.c1}b3`,
                }}
                aria-hidden="true"
              >
                <CatIcon name={tile.icon} className="h-[15px] w-[15px]" />
              </span>
              <span className="w-full truncate text-[12px] font-extrabold text-slate-700 transition-colors group-hover:text-slate-900 dark:text-slate-200 dark:group-hover:text-white">
                {tile.label}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* charts + recent activity — ROUND 141 (㉚): the REAL pair. The fake
          "estimated" tasks donut is retired (honesty law) and the recent
          activity card rides BESIDE the revenue chart. */}
      <div className="grid gap-4 lg:grid-cols-3">
        <DashCard title={t("dashRevenueChart")} icon="chart-column" className="lg:col-span-2">
          <div dir="ltr" className="h-[260px] w-full">
            <RevenueChart data={stats.revenue} color={c1} gradientId={`rev-${instance.id}`} />
          </div>
        </DashCard>

        <DashCard
          title={t("dashRecentActivity")}
          icon="clock-rotate-left"
          action={
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setDashView("activity")}
              className="h-7 rounded-lg px-2 text-[11px] font-bold text-brand-600 hover:text-brand-700 dark:text-brand-300"
            >
              {t("dashViewAll")}
            </Button>
          }
        >
          <ul className="max-h-[260px] space-y-1 overflow-y-auto pe-1 [contain:content] nice-scroll">
            {instance.activities.length === 0 ? (
              <li className="py-8 text-center text-[12px] font-semibold text-slate-400 dark:text-slate-500">
                {t("dashEmptyState")}
              </li>
            ) : (
              instance.activities.slice(0, 6).map((a) => {
                const style = ACT_STYLE[a.kind] ?? ACT_STYLE.actSettingsUpdated;
                return (
                  <li key={a.id} className="flex items-center gap-3 rounded-xl p-2 transition hover:bg-slate-50 dark:hover:bg-white/5">
                    <span
                      className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-white"
                      style={{ backgroundImage: grad(style.c1, style.c2) }}
                      aria-hidden="true"
                    >
                      <CatIcon name={style.icon} className="h-[10px] w-[10px]" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[12px] font-bold text-slate-700 dark:text-slate-200">{t(a.kind)}</p>
                      {a.meta ? (
                        <p className="truncate text-[10px] text-slate-400 dark:text-slate-500">
                          {Object.values(a.meta).join(" · ")}
                        </p>
                      ) : null}
                    </div>
                    <span className="shrink-0 text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                      {relativeTime(a.createdAt, lang)}
                    </span>
                  </li>
                );
              })
            )}
          </ul>
        </DashCard>
      </div>

      {/* ROUND 141 (㉚) — the REAL subscription strip (replaces the four
          fake/dupe rows: workspace tools, active modules, system health,
          getting started, top modules, mobile teaser). Plan identity, the
          live term countdown, and ONE renew CTA — real data only. */}
      <div className="glass-card card-in relative overflow-hidden rounded-3xl p-4" style={{ "--i": 4 } as React.CSSProperties}>
        <div
          className="pointer-events-none absolute -end-12 -top-12 h-40 w-40 rounded-full"
          style={{ background: "radial-gradient(circle, rgba(109,93,251,0.16), transparent 70%)" }}
          aria-hidden="true"
        />
        <div className="relative flex flex-wrap items-center gap-3">
          <span
            className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
            style={{ backgroundImage: grad(c1, c2) }}
            aria-hidden="true"
          >
            <CatIcon name="gem" className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="flex flex-wrap items-center gap-2">
              <span className="text-[13.5px] font-extrabold text-slate-900 dark:text-white">
                {instance.package
                  ? lang === "ar"
                    ? instance.package.nameAr
                    : instance.package.nameEn
                  : t("trialBadge")}
              </span>
              {entitlement?.state === "trial" && entitlement.trialDaysLeft !== null ? (
                <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/15 px-2.5 py-0.5 text-[10.5px] font-extrabold text-amber-600 dark:text-amber-300">
                  <CatIcon name="hourglass" className="h-2.5 w-2.5" />
                  {trialCountdown}
                </span>
              ) : entitlement?.state === "locked" ? (
                <span className="inline-flex items-center gap-1 rounded-full bg-rose-500/15 px-2.5 py-0.5 text-[10.5px] font-extrabold text-rose-600 dark:text-rose-300">
                  <CatIcon name="lock" className="h-2.5 w-2.5" />
                  {t("lockedTitle")}
                </span>
              ) : entitlement?.planDaysLeft !== null && entitlement?.planDaysLeft !== undefined ? (
                <span
                  className={cn(
                    "inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[10.5px] font-extrabold",
                    entitlement.planDaysLeft <= 7
                      ? "bg-amber-500/15 text-amber-600 dark:text-amber-300"
                      : "bg-emerald-500/15 text-emerald-600 dark:text-emerald-300"
                  )}
                >
                  <CatIcon name="calendar-days" className="h-2.5 w-2.5" />
                  {t("dashPlanDaysLeft", { n: fmtNum(entitlement.planDaysLeft, lang) })}
                </span>
              ) : null}
            </p>
            <p className="mt-0.5 truncate text-[11.5px] font-semibold text-slate-400 dark:text-slate-500">
              {instance.package
                ? t("dashPlanPriceSub", {
                    /* ROUND 166 — prices are integer MINOR units (fmtPlanPrice ÷100) */
                    price: fmtPlanPrice(
                      entitlement?.planCycle === "yearly"
                        ? (instance.package.priceYearly ?? instance.package.priceMonthly)
                        : instance.package.priceMonthly
                    ),
                    currency: instance.package.currency,
                  })
                : t("dashPlanNoneSub")}
            </p>
          </div>
          <Button
            type="button"
            onClick={() => setDashView("billing")}
            className="h-10 shrink-0 gap-2 rounded-xl bg-linear-to-l from-brand-600 to-fuchsia-500 px-4 text-[12px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
          >
            <CatIcon name="credit-card" className="h-4 w-4" />
            {entitlement?.state === "locked" ? t("renewCta") : t("dashManageBilling")}
          </Button>
        </div>
      </div>
    </div>
  );
}

/* TASK K (R150) — small label-tracking helper scoped to this file so
   the System Health card's uppercase labels stay RTL-correct without
   importing the global `labelTrack` util (the overview already relied
   on inline classes via `cn(...)` elsewhere). */
function labelTrackClass(lang: Lang): string {
  return lang === "ar" ? "tracking-normal" : "tracking-wider";
}
