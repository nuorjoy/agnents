"use client";

/**
 * Dashboard — billing view (ROUND 48 dynamic payment methods).
 *
 * ROUND 147 — the plan ladder drives the CTAs: an active workspace on the
 * TOP public plan gets the positive crown card (no CTA at all), a lower
 * active tier gets the precise «ترقية الباقة» card, and the no-package
 * hero (any state) asks to ACTIVATE («فعّل خطتك الآن»). The usage card
 * also gained a REAL server-measured storage meter (usage endpoint —
 * auxiliary data, hides silently on error).
 *
 * Server-computed truth drives the whole page: `instance.entitlement` is
 * never derived client-side. Three states render three crowns —
 *  · "trial"  → amber trial banner (progress + countdown) above the strip;
 *  · "locked" → premium rose hero (billing-only access) with the big
 *               activation CTA — the page a locked tenant lands on;
 *  · "active" → the round-46 status strip + live plan hero, unchanged.
 *
 * The ActivationDialog is the ROUND 48 flow: choose plan + cycle → pick a
 * payment method from the CONSOLE-MANAGED dynamic list (GET plan-methods
 * serves the ACTIVE, tenant-safe subset — banks / wallets / PayPal /
 * Stripe are added from the console settings without touching code; the
 * receiving details are revealed ONLY on the server-built invoice) → the
 * server snapshots the invoice. Orders reference a method by its console
 * id (`methodId`) and carry the server-stored `methodLabel` snapshot; the
 * kind metadata (icon / gradient / i18n) resolves via METHOD_KIND_META.
 * Money is ALWAYS server-computed (createPlanOrder sends
 * packageId/cycle/methodId only) and every order row carries the server's
 * HMAC integrity verdict. Below everything, PlanOrdersCard lists the
 * workspace's activation & payment requests (pending orders cancellable)
 * for ALL states — locked tenants land here to follow their pending
 * payment.
 */
import { useMemo, useState, type Dispatch, type SetStateAction } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CATEGORY_MAP, SYSTEM_MAP, systemMods } from "@/data/catalog";
import { useT, type I18nKey } from "@/lib/i18n";
import type {
  InstanceDTO,
  Lang,
  PackageSummaryDTO,
  PaymentInstructionsDTO,
  PaymentMethod,
  PlanCycle,
  PlanOrderDTO,
  TeamMemberDTO,
} from "@/lib/types";
import {
  cancelPlanOrder,
  createPlanOrder,
  fetchActivities,
  fetchInstanceUsage,
  fetchPlanMethods,
  fetchPlanOrders,
  fetchPublicPackages,
  fetchWallet,
} from "@/lib/api-client";
import { WALLET_CHECKOUT_METHOD_ID } from "@/lib/types";
import { WalletCheckoutOption } from "@/components/dashboard/wallet-widgets";
import { apiErrorText } from "@/lib/api-errors";
import { formatBytes } from "@/lib/image-tools";
import { intlLocale } from "@/lib/locales";
import { cycleDiscountPct, discountedPrice, effectiveYearlyPct } from "@/lib/plan-features";
import { fmtPlanPrice } from "@/lib/format";
import { CatIcon } from "@/components/icon";
import { cn, copyText, fmtNum, grad, labelTrack } from "@/lib/utils";
import {
  planTermDaysText,
  planTermTone,
  trialCountdownText,
  trialCountdownTone,
  type PlanTermTone,
} from "@/components/dashboard/smart-countdown";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DashCard,
  IconTile,
  MeterBar,
  ViewHeading,
  fullDate,
  relativeTime,
  relativeDistance,
} from "@/components/dashboard/dash-shared";

/** Icon + gradient palette cycled per plan index (matches the pricing section). */
const PLAN_STYLES = [
  { icon: "rocket", c1: "#06b6d4", c2: "#0891b2" },
  { icon: "sparkles", c1: "#6d5dfb", c2: "#d946ef" },
  { icon: "building", c1: "#f59e0b", c2: "#ea580c" },
  { icon: "gem", c1: "#10b981", c2: "#059669" },
] as const;

/** Practical "unlimited" threshold used by the seeded plans. */
const UNLIMITED = 999;

/** ROUND 48 — per-KIND icon + gradient identity. The concrete methods are
 *  a dynamic console-managed list; this maps each PaymentMethod KIND
 *  (bank / wallet / paypal / stripe) to its visual identity and i18n keys —
 *  the console-defined label rides on top of the kind metadata. */
const METHOD_KIND_META: Record<
  PaymentMethod,
  { icon: string; c1: string; c2: string; labelKey: I18nKey; descKey: I18nKey }
> = {
  bank: { icon: "landmark", c1: "#0ea5e9", c2: "#0369a1", labelKey: "payMethodBank", descKey: "payMethodBankDesc" },
  wallet: { icon: "wallet", c1: "#f59e0b", c2: "#d97706", labelKey: "payMethodWallet", descKey: "payMethodWalletDesc" },
  paypal: { icon: "at-sign", c1: "#06b6d4", c2: "#0891b2", labelKey: "payMethodPaypal", descKey: "payMethodPaypalDesc" },
  stripe: { icon: "credit-card", c1: "#8b5cf6", c2: "#7c3aed", labelKey: "payMethodStripe", descKey: "payMethodStripeDesc" },
};

/** Per-entitlement-state identity for the status strip (ROUND 47). */
const STRIP_STYLE = {
  active: { pill: "billingStatusActive", icon: "badge-check", c1: "#10b981", c2: "#047857", tone: "emerald" },
  trial: { pill: "trialBadge", icon: "clock", c1: "#f59e0b", c2: "#d97706", tone: "amber" },
  locked: { pill: "wsStatusLocked", icon: "lock", c1: "#f43f5e", c2: "#e11d48", tone: "rose" },
} as const;

/** Pill / shell tints per strip tone. */
const PILL_TONE: Record<(typeof STRIP_STYLE)[keyof typeof STRIP_STYLE]["tone"], string> = {
  emerald: "border-emerald-300/70 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300",
  amber: "border-amber-300/70 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300",
  rose: "border-rose-300/70 bg-rose-500/10 text-rose-600 dark:border-rose-500/40 dark:text-rose-300",
};
const SHELL_TONE: Record<(typeof STRIP_STYLE)[keyof typeof STRIP_STYLE]["tone"], string> = {
  emerald: "border-emerald-200/60 dark:border-emerald-500/20",
  amber: "border-amber-200/60 dark:border-amber-500/20",
  rose: "border-rose-200/60 dark:border-rose-500/20",
};

/* ------------------------------------------------------------------ */
/* ROUND 47 — activation dialog state machine                          */
/* ------------------------------------------------------------------ */

type ActivationStep = "choose" | "pay" | "invoice";

/** Activation dialog state — closing always resets to the initial shape
 *  (the created order + instructions ride along for the invoice step). */
interface ActivationState {
  open: boolean;
  step: ActivationStep;
  packageId?: string;
  cycle: PlanCycle;
  /** ROUND 48 — the console-defined payment method id (dynamic list). */
  methodId?: string;
  order?: PlanOrderDTO;
  instructions?: PaymentInstructionsDTO;
}

const ACTIVATION_INITIAL: ActivationState = { open: false, step: "choose", cycle: "monthly" };

/** Meter gradient by utilization: identity hue → amber ≥70% → rose ≥90%. */
function meterColor(pct: number, base: string): string {
  if (pct >= 90) return "linear-gradient(90deg,#f43f5e,#e11d48)";
  if (pct >= 70) return "linear-gradient(90deg,#f59e0b,#d97706)";
  return base;
}

/** ROUND 147 — formatBytes rounds sub-KB values up to 1 KB; an honest
 *  zero-byte total stays «0» (mirrors settings-view's same-law helper). */
function fmtBytesOrZero(bytes: number, lang: Lang): string {
  return bytes > 0 ? formatBytes(bytes, lang) : fmtNum(0, lang);
}

/** Wall-clock read once per mount — keeps render idempotent for the
 *  react-compiler purity rule (the trial bar needs no live ticking; the
 *  entitlement query refresh re-mounts it anyway). */
function useMountedNow(): number {
  const [nowMs] = useState(() => Date.now());
  return nowMs;
}

/* ROUND 79 — the 14-Day Full-Access window fallback (mirrors the server's
 * TRIAL_DAYS = 14 in src/lib/server/entitlement.ts; that module is
 * server-only and cannot be imported into a client component). */
const TRIAL_WINDOW_DAYS = 14;

/* ------------------------------------------------------------------ */
/* ROUND 79 — paid-term pill tints (emerald >7d → amber ≤7d → rose ≤2d) */
/* ------------------------------------------------------------------ */

const TERM_PILL_TONE: Record<PlanTermTone, string> = {
  emerald: "border-emerald-300/70 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300",
  amber: "border-amber-300/70 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300",
  rose: "border-rose-300/70 bg-rose-500/10 text-rose-600 dark:border-rose-500/40 dark:text-rose-300",
};

/** Shared cancel-a-pending-order mutation (invoice step + orders card). */
function useCancelPlanOrder(instanceId: string, onDone?: () => void) {
  const { t } = useT();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (orderId: string) => cancelPlanOrder(instanceId, orderId),
    onSuccess: (order: PlanOrderDTO) => {
      toast.success(
        order.effectiveStatus === "cancelled" ? t("adminPOCancelled") : t("orderStatusCancelled"),
      );
      void queryClient.invalidateQueries({ queryKey: ["plan-orders", instanceId] });
      void queryClient.invalidateQueries({ queryKey: ["instance", instanceId] });
      void queryClient.invalidateQueries({ queryKey: ["instances"] });
      onDone?.();
    },
    onError: (error: unknown) => toast.error(apiErrorText(error, t)),
  });
}

/** Copy-to-clipboard with the standard toast feedback. */
function useCopyRef() {
  const { t } = useT();
  return (reference: string) => {
    copyText(reference)
      .then(() => toast.success(t("secCopied")))
      .catch(() => toast.error(t("errGenericAction")));
  };
}

/* ------------------------------------------------------------------ */
/* ROUND 47 — trial banner + locked hero                               */
/* ------------------------------------------------------------------ */

/** Amber trial banner: the «14-Day Full Access» positioning — progress +
 *  smart Arabic countdown + activation CTA (state==="trial"). ROUND 79 —
 *  the countdown chip turns rose (+ pulse) at ≤2 days, stronger in the
 *  last day's hours. */
function TrialBanner({
  instance,
  onActivate,
}: {
  instance: InstanceDTO;
  onActivate: () => void;
}) {
  const { t, lang } = useT();
  const ent = instance.entitlement;

  /* consumed share of the createdAt → trialEndsAt window (14-Day Full-Access
   * window; TRIAL_WINDOW_DAYS fallback when the stamp is missing); the clock
   * is read once per mount so the render stays idempotent */
  const nowMs = useMountedNow();
  const createdMs = new Date(instance.createdAt).getTime();
  const endsMs = ent.trialEndsAt
    ? new Date(ent.trialEndsAt).getTime()
    : createdMs + TRIAL_WINDOW_DAYS * 86_400_000;
  const pct = Math.max(0, Math.min(100, ((nowMs - createdMs) / Math.max(1, endsMs - createdMs)) * 100));
  /* ROUND 79 — the smart countdown (dual forms) + urgency tone */
  const urgency = trialCountdownTone(ent);
  const countdown = trialCountdownText(ent, lang, t);
  const urgent = urgency !== "amber";

  return (
    <section
      className="card-in relative overflow-hidden rounded-3xl p-5 text-white shadow-lift"
      style={{ backgroundImage: grad("#f59e0b", "#ea580c", 120) }}
      aria-label={t("featTrialFullAccess")}
    >
      {/* ambient premium pattern (mirrors the plan hero) */}
      <div className="pointer-events-none absolute -end-10 -top-12 h-36 w-36 rounded-full bg-white/15" aria-hidden="true" />
      <div className="pointer-events-none absolute -bottom-14 -start-8 h-32 w-32 rounded-full border-[12px] border-white/10" aria-hidden="true" />
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.14]"
        style={{
          backgroundImage: "radial-gradient(circle at 1px 1px, rgba(255,255,255,0.9) 1px, transparent 0)",
          backgroundSize: "22px 22px",
        }}
        aria-hidden="true"
      />

      <div className="relative flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex min-w-0 items-start gap-3.5">
          <span className="relative grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-white/20 backdrop-blur">
            <CatIcon name="clock" className="h-5 w-5" />
            <span className="absolute -end-0.5 -top-0.5 flex h-3 w-3" aria-hidden="true">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-white/70" />
              <span className="relative inline-flex h-3 w-3 animate-pulse rounded-full border-2 border-amber-500 bg-white" />
            </span>
          </span>
          <div className="min-w-0">
            <h2 className="font-display text-[16px] font-extrabold leading-snug">
              {t("featTrialFullAccess")}
            </h2>
            <p className="mt-1 max-w-xl text-[12px] font-semibold leading-relaxed text-white/85">
              {t("featTrialFullAccessDesc")}
            </p>
          </div>
        </div>
        <Button
          type="button"
          onClick={onActivate}
          className="h-10 shrink-0 gap-2 rounded-xl bg-white px-5 text-[12.5px] font-extrabold text-amber-600 shadow-lg transition hover:bg-white/90 active:scale-95"
        >
          <CatIcon name="sparkles" className="h-4 w-4" />
          {t("trialActivateNow")}
        </Button>
      </div>

      {/* progress + countdown chips */}
      <div className="relative mt-4 grid gap-3.5 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center">
        <div>
          <div className="mb-1.5 flex items-center justify-between gap-3">
            <span className={cn("text-[10px] font-extrabold uppercase text-white/85", labelTrack(lang))}>
              {t("trialProgressLabel")}
            </span>
            <span dir="ltr" className="text-[10.5px] font-extrabold tabular-nums text-white/70">
              {fmtNum(Math.round(pct), lang)}
              {lang === "ar" ? "٪" : "%"}
            </span>
          </div>
          <div
            className="h-2.5 w-full overflow-hidden rounded-full bg-white/25"
            role="progressbar"
            aria-label={t("trialProgressLabel")}
            aria-valuenow={Math.round(pct)}
            aria-valuemin={0}
            aria-valuemax={100}
          >
            <div
              className="h-full rounded-full transition-all duration-700"
              style={{ width: `${pct}%`, backgroundImage: "linear-gradient(90deg,#fde68a,#fbbf24)" }}
            />
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {countdown ? (
            <span
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[11px] font-extrabold backdrop-blur",
                urgent ? "bg-rose-950/30 ring-1 ring-inset ring-rose-200/40 animate-pulse" : "bg-white/20",
              )}
            >
              <CatIcon name="hourglass" className="h-3.5 w-3.5" />
              {countdown}
            </span>
          ) : null}
          {ent.trialEndsAt ? (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-white/20 px-3 py-1.5 text-[11px] font-extrabold backdrop-blur">
              <CatIcon name="calendar" className="h-3.5 w-3.5" />
              {t("trialEndsOn", { date: fullDate(ent.trialEndsAt, lang) })}
            </span>
          ) : null}
        </div>
      </div>
    </section>
  );
}

/** Premium hero for a locked (billing-only) workspace — the page crown.
 *  ROUND 79 — forked by lockReason: an expired TRIAL keeps the rose
 *  activation hero («انتهت فترة الوصول الكامل»); an expired PAID term
 *  renders the rose→violet renewal hero with the expired term date + the
 *  data-safety assurance line. */
function LockedHero({ instance, onActivate }: { instance: InstanceDTO; onActivate: () => void }) {
  const { t, lang } = useT();
  const ent = instance.entitlement;
  const planExpired = ent.lockReason === "plan";
  const endsAt = ent.planExpiresAt;

  return (
    <section
      className="card-in relative overflow-hidden rounded-3xl p-6 text-white shadow-lift sm:p-8"
      style={{ backgroundImage: planExpired ? grad("#f43f5e", "#8b5cf6", 120) : grad("#f43f5e", "#e11d48", 120) }}
      aria-label={planExpired ? t("lockedPlanTitle") : t("lockedTrialTitle")}
    >
      {/* ambient premium pattern (mirrors the plan hero) */}
      <div className="pointer-events-none absolute -end-12 -top-14 h-44 w-44 rounded-full bg-white/15" aria-hidden="true" />
      <div className="pointer-events-none absolute -bottom-16 -start-10 h-40 w-40 rounded-full border-[14px] border-white/10" aria-hidden="true" />
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.16]"
        style={{
          backgroundImage: "radial-gradient(circle at 1px 1px, rgba(255,255,255,0.9) 1px, transparent 0)",
          backgroundSize: "22px 22px",
        }}
        aria-hidden="true"
      />

      <div className="relative flex flex-col items-start gap-5 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex min-w-0 items-start gap-4">
          <span className="grid h-14 w-14 shrink-0 place-items-center rounded-3xl bg-white/20 backdrop-blur">
            <CatIcon name={planExpired ? "calendar-range" : "lock"} className="h-6 w-6" />
          </span>
          <div className="min-w-0">
            <h2 className="font-display text-xl font-extrabold leading-snug sm:text-[26px]">
              {planExpired ? t("lockedPlanTitle") : t("lockedTrialTitle")}
            </h2>
            <p className="mt-2 max-w-lg text-[12.5px] font-semibold leading-relaxed text-white/85">
              {planExpired ? t("lockedPlanDesc") : t("lockedDesc")}
            </p>
            {/* ROUND 79 — the expired term's date (plan lock only) */}
            {planExpired && endsAt ? (
              <span className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-white/20 px-3 py-1 text-[10.5px] font-extrabold backdrop-blur">
                <CatIcon name="calendar" className="h-3 w-3" />
                {t("planExpiredDate", { date: fullDate(endsAt, lang) })}
              </span>
            ) : null}
            <span className={cn("inline-flex items-center gap-1.5 rounded-full bg-white/20 px-3 py-1 text-[10.5px] font-extrabold backdrop-blur", planExpired && endsAt ? "mt-2" : "mt-3")}>
              <CatIcon name="shield-alert" className="h-3 w-3" />
              {t("lockedOnlyBilling")}
            </span>
            {/* ROUND 79 — data-safety assurance (plan lock only) */}
            {planExpired ? (
              <p className="mt-2.5 flex items-center gap-1.5 text-[11px] font-bold text-white/90">
                <CatIcon name="shield-check" className="h-3.5 w-3.5 shrink-0" />
                {t("planExpiredDataSafe")}
              </p>
            ) : null}
          </div>
        </div>
        <Button
          type="button"
          onClick={onActivate}
          className={cn(
            "h-11 shrink-0 gap-2 rounded-xl bg-white px-6 text-[13px] font-extrabold shadow-lg transition hover:bg-white/90 active:scale-95",
            planExpired ? "text-violet-700" : "text-rose-600",
          )}
        >
          <CatIcon name={planExpired ? "refresh-cw" : "sparkles"} className="h-4 w-4" />
          {planExpired ? t("renewCta") : t("trialActivateNow")}
        </Button>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* ROUND 46/47 — subscription status strip (state-aware)               */
/* ------------------------------------------------------------------ */

/** Professional status bar: live state pill, tier ladder, quick facts.
 *  ROUND 79 — adds the paid-term chip («ينتهي الاشتراك: {date} · بقيت …»
 *  with emerald→amber→rose tones, or «غير محدود — إدارة المنصة» for
 *  platform-managed rows) and shows the DISCOUNTED effective price. */
function SubscriptionStatusStrip({
  instance,
  pkg,
}: {
  instance: InstanceDTO;
  pkg: PackageSummaryDTO | null;
}) {
  const { t, lang } = useT();
  const ent = instance.entitlement;
  const style = STRIP_STYLE[ent.state];
  const countdown = ent.state === "trial" ? trialCountdownText(ent, lang, t) : null;

  /* ROUND 79 — paid-term chip data (active rows only) */
  const showTerm = ent.state === "active" && pkg != null;
  const termTone = planTermTone(ent);
  const termDays = showTerm ? planTermDaysText(ent, lang, t) : null;

  /* tier ladder — public active plans ordered by price, current marked */
  const packagesQuery = useQuery({
    queryKey: ["public-packages"],
    queryFn: fetchPublicPackages,
    staleTime: 60_000,
  });
  const ladder = useMemo(() => {
    const plans = [...(packagesQuery.data ?? [])].sort((a, b) => a.priceMonthly - b.priceMonthly);
    const currentIdx = pkg ? plans.findIndex((p) => p.id === pkg.id) : -1;
    return { plans, currentIdx };
  }, [packagesQuery.data, pkg]);

  const created = new Date(instance.createdAt);
  const sinceLabel = new Intl.DateTimeFormat(intlLocale(lang), {
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(created);

  /* billing cycle follows the server-computed purchased cycle — ROUND 79 →
   * ROUND 80: the shown price is the DISCOUNTED effective price under the
   * cycle's OWN promotion (monthly pct / dedicated annual pct) */
  const cycleLabel = ent.planCycle === "yearly" ? t("planCycleYearly") : t("billingCycleMonthly");
  const cyclePrice = pkg
    ? discountedPrice(
        ent.planCycle === "yearly" ? pkg.priceYearly : pkg.priceMonthly,
        cycleDiscountPct(pkg, ent.planCycle ?? "monthly"),
      )
    : null;

  return (
    <section
      className={cn(
        "card-in relative overflow-hidden rounded-3xl border bg-white/70 p-5 shadow-sm dark:bg-white/[0.03]",
        SHELL_TONE[style.tone],
      )}
      aria-label={t("planCurrent")}
    >
      {/* ambient premium tint */}
      <span
        className="pointer-events-none absolute inset-0 opacity-[0.07] dark:opacity-[0.12]"
        style={{ backgroundImage: `linear-gradient(135deg, ${style.c1}, ${style.c2})` }}
        aria-hidden="true"
      />

      <div className="relative flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        {/* status identity */}
        <div className="flex min-w-0 items-center gap-3.5">
          <span
            className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
            style={{
              backgroundImage: grad(style.c1, style.c2),
              boxShadow: `0 10px 24px -8px ${style.c1}66`,
            }}
            aria-hidden="true"
          >
            <CatIcon name={style.icon} className="h-5 w-5" />
          </span>
          <div className="min-w-0">
            <p className="flex flex-wrap items-center gap-2">
              <span
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[11px] font-extrabold",
                  PILL_TONE[style.tone],
                )}
              >
                <span
                  className="h-1.5 w-1.5 animate-pulse rounded-full"
                  style={{ backgroundColor: style.c1 }}
                  aria-hidden="true"
                />
                {t(style.pill)}
                {countdown ? (
                  <>
                    <span className="opacity-40" aria-hidden="true">·</span>
                    <span className="font-bold">{countdown}</span>
                  </>
                ) : null}
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white/80 px-3 py-1 text-[10.5px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-300">
                <CatIcon name="shield-check" className="h-3 w-3" />
                {t("billingStatusManaged")}
              </span>
              {/* ROUND 79 — paid-term chip: stamped date + smart countdown
                  (emerald >7d → amber ≤7d → rose ≤2d), or the unlimited
                  platform-managed note when no term is stamped */}
              {showTerm ? (
                ent.planExpiresAt ? (
                  <span
                    className={cn(
                      "inline-flex flex-wrap items-center gap-1.5 rounded-full border px-3 py-1 text-[10.5px] font-extrabold",
                      TERM_PILL_TONE[termTone],
                    )}
                  >
                    <CatIcon name="calendar-days" className="h-3 w-3 shrink-0" />
                    <span className="min-w-0">
                      {t("planTermEndsOn", { date: fullDate(ent.planExpiresAt, lang) })}
                      {termDays ? (
                        <>
                          {" "}
                          <span className="opacity-40" aria-hidden="true">·</span> {termDays}
                        </>
                      ) : null}
                    </span>
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-300/70 bg-emerald-500/10 px-3 py-1 text-[10.5px] font-extrabold text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300">
                    <CatIcon name="badge-check" className="h-3 w-3" />
                    {t("planTermUnlimited")}
                  </span>
                )
              ) : null}
            </p>
            <p className="mt-1.5 truncate font-display text-[16px] font-extrabold text-slate-900 dark:text-white">
              {pkg ? (lang === "ar" ? pkg.nameAr : pkg.nameEn) : t("billingNoPlan")}
            </p>
          </div>
        </div>

        {/* quick facts */}
        <dl className="grid flex-1 grid-cols-2 gap-2.5 sm:grid-cols-4 lg:max-w-2xl">
          <div className="rounded-2xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
            <dt className={cn("text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
              {t("billingSince")}
            </dt>
            <dd className="mt-0.5 truncate text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200">
              {/* ROUND 80 — the value is the DATE itself; the label above
                  already reads «مشترك منذ» (was منذ منذ duplication) */}
              {sinceLabel}
            </dd>
          </div>
          <div className="rounded-2xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
            <dt className={cn("text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
              {t("billingCycle")}
            </dt>
            <dd className="mt-0.5 truncate text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200">
              {pkg ? (
                <>
                  {/* ROUND 166 — prices are integer MINOR units (fmtPlanPrice ÷100) */}
                  {cycleLabel} · {fmtPlanPrice(cyclePrice ?? 0)} {pkg.currency}
                </>
              ) : (
                "—"
              )}
            </dd>
          </div>
          <div className="rounded-2xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
            <dt className={cn("text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
              {t("billingLimitUsers")}
            </dt>
            <dd className="mt-0.5 truncate text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200">
              {pkg ? (pkg.maxUsers >= UNLIMITED ? t("billingUnlimited") : fmtNum(pkg.maxUsers, lang)) : "—"}
            </dd>
          </div>
          <div className="rounded-2xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
            <dt className={cn("text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
              {t("billingLimitModules")}
            </dt>
            <dd className="mt-0.5 truncate text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200">
              {pkg ? (pkg.maxModules >= UNLIMITED ? t("billingUnlimited") : fmtNum(pkg.maxModules, lang)) : "—"}
            </dd>
          </div>
        </dl>
      </div>

      {/* tier ladder — ordered public plans with the current tier highlighted */}
      {ladder.plans.length > 1 ? (
        <div className="relative mt-4 flex flex-wrap items-center gap-2 border-t border-slate-200/70 pt-3.5 dark:border-white/10">
          <span className={cn("inline-flex shrink-0 items-center gap-1.5 text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
            <CatIcon name="trending-up" className="h-3 w-3" />
            {t("billingTierLadder")}
          </span>
          <ol className="flex min-w-0 flex-1 flex-wrap items-center gap-1.5">
            {ladder.plans.map((plan, i) => {
              const isCurrent = i === ladder.currentIdx;
              const passed = ladder.currentIdx >= 0 && i < ladder.currentIdx;
              return (
                <li key={plan.id} className="flex items-center gap-1.5">
                  <span
                    className={
                      "inline-flex max-w-[160px] items-center gap-1 rounded-full px-2.5 py-1 text-[10.5px] font-extrabold transition " +
                      (isCurrent
                        ? "bg-linear-to-r from-emerald-500 to-emerald-600 text-white shadow-md shadow-emerald-500/25"
                        : passed
                          ? "border border-emerald-200 bg-emerald-50/70 text-emerald-600 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300"
                          : "border border-slate-200 bg-white/80 text-slate-400 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-500")
                    }
                    title={t("billingTierOf", { n: String(i + 1), total: String(ladder.plans.length) })}
                  >
                    {isCurrent ? <CatIcon name="crown" className="h-3 w-3 shrink-0" /> : null}
                    <span className="truncate">{lang === "ar" ? plan.nameAr : plan.nameEn}</span>
                  </span>
                  {i < ladder.plans.length - 1 ? (
                    <CatIcon name="chevron-left" className="h-3 w-3 shrink-0 text-slate-300 rtl:rotate-0 ltr:rotate-180 dark:text-slate-600" aria-hidden="true" />
                  ) : null}
                </li>
              );
            })}
          </ol>
          {ladder.currentIdx >= 0 ? (
            <span className="ms-auto hidden shrink-0 text-[10px] font-extrabold text-slate-400 dark:text-slate-500 sm:inline">
              {t("billingTierOf", { n: String(ladder.currentIdx + 1), total: String(ladder.plans.length) })}
            </span>
          ) : null}
        </div>
      ) : null}
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* ROUND 46 — plan benefits + last change (F-5)                        */
/* ------------------------------------------------------------------ */

function PlanBenefitsCard({ pkg }: { pkg: PackageSummaryDTO | null }) {
  const { t, lang } = useT();
  /* the summary lacks the feature bullets — resolve the full public plan */
  const packagesQuery = useQuery({
    queryKey: ["public-packages"],
    queryFn: fetchPublicPackages,
    staleTime: 60_000,
  });
  const full = pkg ? (packagesQuery.data ?? []).find((p) => p.id === pkg.id) ?? null : null;
  const features = full ? (lang === "ar" ? full.features : full.featuresEn.length > 0 ? full.featuresEn : full.features) : [];
  return (
    <DashCard title={t("billingFeatures")} icon="list-checks">
      {features.length > 0 ? (
        <ul className="grid gap-2 sm:grid-cols-2">
          {features.slice(0, 12).map((feature) => (
            <li
              key={feature}
              className="flex items-start gap-2 rounded-xl border border-slate-200/70 bg-white/60 px-2.5 py-2 text-[11.5px] font-bold leading-relaxed text-slate-600 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-300"
            >
              <CatIcon name="circle-check" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-500" />
              <span className="min-w-0">{feature}</span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-[12px] font-semibold text-slate-400 dark:text-slate-500">
          {t("billingNoPlanDesc")}
        </p>
      )}
    </DashCard>
  );
}

function LastPlanChangeCard({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const activitiesQuery = useQuery({
    queryKey: ["activities", instance.id, 100],
    queryFn: () => fetchActivities(instance.id, 100),
  });
  const planChanges = useMemo(
    () =>
      (activitiesQuery.data ?? []).filter(
        (ev) => ev.kind === "actSettingsUpdated" && ev.meta && "package" in ev.meta
      ),
    [activitiesQuery.data]
  );
  const last = planChanges[0];
  const planName = last?.meta
    ? lang === "ar"
      ? (last.meta.packageAr ?? last.meta.package ?? "—")
      : (last.meta.package ?? last.meta.packageAr ?? "—")
    : "—";

  return (
    <DashCard title={t("billingLastChange")} icon="history">
      {activitiesQuery.isPending ? (
        <Skeleton className="h-10 w-full rounded-xl" />
      ) : last ? (
        <div className="space-y-2.5">
          <div className="flex items-center gap-3 rounded-2xl border border-amber-200/70 bg-linear-to-l from-amber-50/80 to-orange-50/50 p-3 dark:border-amber-500/20 dark:from-amber-500/10 dark:to-orange-500/5">
            <span
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
              style={{ backgroundImage: grad("#f59e0b", "#d97706") }}
              aria-hidden="true"
            >
              <CatIcon name="crown" className="h-4 w-4" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                {planName}
              </p>
              <p className="text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                {fullDate(last.createdAt, lang)} · {relativeTime(last.createdAt, lang)}
              </p>
            </div>
          </div>
          <p className="flex items-start gap-1.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            <CatIcon name="info" className="mt-px h-3 w-3 shrink-0" />
            {t("billingReqHistory")}
          </p>
        </div>
      ) : (
        <p className="text-[12px] font-semibold text-slate-400 dark:text-slate-500">
          {t("billingNoChanges")}
        </p>
      )}
    </DashCard>
  );
}

/* ------------------------------------------------------------------ */
/* ROUND 47 — effective-status chip (mirrors the console view)         */
/* ------------------------------------------------------------------ */

function OrderStatusChip({ status }: { status: PlanOrderDTO["effectiveStatus"] }) {
  const { t } = useT();
  if (status === "pending") {
    return (
      <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-amber-300/70 bg-amber-500/10 px-2.5 py-1 text-[10px] font-extrabold text-amber-600 dark:border-amber-500/40 dark:text-amber-300">
        <span className="relative flex h-2 w-2" aria-hidden="true">
          <span className="absolute inset-0 animate-ping rounded-full bg-amber-500/50" />
          <span className="relative m-auto h-1.5 w-1.5 rounded-full bg-amber-500" />
        </span>
        {t("orderStatusPending")}
      </span>
    );
  }
  if (status === "paid") {
    return (
      <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-emerald-300/70 bg-emerald-500/10 px-2.5 py-1 text-[10px] font-extrabold text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300">
        <CatIcon name="badge-check" className="h-3 w-3" />
        {t("orderStatusPaid")}
      </span>
    );
  }
  if (status === "cancelled") {
    return (
      <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-slate-300/70 bg-slate-500/10 px-2.5 py-1 text-[10px] font-extrabold text-slate-400 dark:border-white/10 dark:text-slate-500">
        <CatIcon name="circle-x" className="h-3 w-3" />
        {t("orderStatusCancelled")}
      </span>
    );
  }
  return (
    <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-rose-300/70 bg-rose-500/10 px-2.5 py-1 text-[10px] font-extrabold text-rose-600 dark:border-rose-500/40 dark:text-rose-300">
      <CatIcon name="clock" className="h-3 w-3" />
      {t("orderStatusExpired")}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* ROUND 47/48 — activation dialog (choose → pay → invoice; the pay    */
/* step lists the console-managed dynamic payment methods)             */
/* ------------------------------------------------------------------ */

/** Step-indicator chip: active = brand gradient, done = emerald check. */
function StepChip({
  label,
  icon,
  status,
  onClick,
}: {
  label: string;
  icon: string;
  status: "active" | "done" | "todo";
  onClick?: () => void;
}) {
  const classes = cn(
    "inline-flex min-w-0 flex-1 items-center justify-center gap-1.5 rounded-full px-3 py-1.5 text-[11px] font-extrabold transition",
    status === "active"
      ? "bg-linear-to-r from-brand-600 to-brand-500 text-white shadow-md shadow-brand-500/25"
      : status === "done"
        ? "border border-emerald-300/70 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
        : "border border-slate-200 bg-white/70 text-slate-400 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-500",
    onClick ? "cursor-pointer active:scale-95" : "",
  );
  const inner = (
    <>
      <CatIcon name={status === "done" ? "check" : icon} className="h-3 w-3 shrink-0" />
      <span className="truncate">{label}</span>
    </>
  );
  if (onClick) {
    return (
      <button type="button" onClick={onClick} className={classes}>
        {inner}
      </button>
    );
  }
  return <span className={classes}>{inner}</span>;
}

/** Selection radio dot used by the plan + method rows. */
function SelectDot({ selected }: { selected: boolean }) {
  return (
    <span
      className={cn(
        "grid h-5 w-5 shrink-0 place-items-center rounded-full border-2 transition",
        selected ? "border-brand-500 bg-brand-500 text-white" : "border-slate-300 dark:border-white/20",
      )}
      aria-hidden="true"
    >
      {selected ? <CatIcon name="check" className="h-3 w-3" /> : null}
    </span>
  );
}

function ActivationDialog({
  state,
  setState,
  instance,
}: {
  state: ActivationState;
  setState: Dispatch<SetStateAction<ActivationState>>;
  instance: InstanceDTO;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const copyRef = useCopyRef();

  const packagesQuery = useQuery({
    queryKey: ["public-packages"],
    queryFn: fetchPublicPackages,
    enabled: state.open,
    staleTime: 30_000,
  });
  const packages = packagesQuery.data ?? [];
  /* ROUND 167 — custom-pricing tiers (Enterprise) are QUOTE-ONLY: they
   *  carry no purchasable amount, so the checkout ladder never offers
   *  them (the server rejects such orders with CUSTOM_PRICING anyway —
   *  this keeps the picker honest about what a receipt would say). */
  const purchasable = packages.filter((p) => !p.customPricing);
  const selectedIdx = state.packageId ? packages.findIndex((p) => p.id === state.packageId) : -1;
  const selectedPlan = selectedIdx >= 0 ? packages[selectedIdx] : null;
  const selectedStyle = PLAN_STYLES[(selectedIdx + PLAN_STYLES.length) % PLAN_STYLES.length];
  const currentId = instance.package?.id ?? null;
  const order = state.order ?? null;
  /* kind meta for the order's method (bank fallback covers legacy rows) */
  const orderMethod = order ? METHOD_KIND_META[order.method] ?? METHOD_KIND_META.bank : null;

  /* ROUND 48 — the console-managed ACTIVE payment methods (tenant-safe
   * subset: id + kind + label; fetched only while the pay step is shown) */
  const methodsQuery = useQuery({
    queryKey: ["plan-methods", instance.id],
    queryFn: () => fetchPlanMethods(instance.id),
    enabled: state.open && state.step === "pay",
    staleTime: 30_000,
  });
  const methods = methodsQuery.data ?? [];

  /* ROUND 141 — the live wallet projection (the INSTANT checkout option).
   *  Rides the same pay-step lifecycle as the methods list. */
  const walletQuery = useQuery({
    queryKey: ["wallet", instance.id],
    queryFn: () => fetchWallet(instance.id),
    enabled: state.open && state.step === "pay",
    staleTime: 20_000,
  });
  const wallet = walletQuery.data ?? null;
  const walletSelected = state.methodId === WALLET_CHECKOUT_METHOD_ID;

  /* ROUND 79 → ROUND 80 — amount for the selected plan + cycle: the
   * DISCOUNTED live price under the cycle's OWN promotion (the server
   * recomputes the very same discounted amount on create — money is never
   * taken from the client) */
  const previewAmount = selectedPlan
    ? discountedPrice(
        state.cycle === "yearly" ? selectedPlan.priceYearly : selectedPlan.priceMonthly,
        cycleDiscountPct(selectedPlan, state.cycle),
      )
    : null;
  const previewBase = selectedPlan
    ? state.cycle === "yearly"
      ? selectedPlan.priceYearly
      : selectedPlan.priceMonthly
    : null;
  /* ROUND 166 — prices are integer MINOR units already: the wallet balance
   * compares DIRECTLY against the preview amount (no ×100 conversion). */
  const walletSufficient =
    !!wallet && !!previewAmount && wallet.balanceMinor >= previewAmount;

  const createOrder = useMutation({
    mutationFn: () => {
      const packageId = state.packageId;
      const methodId = state.methodId;
      if (!packageId || !methodId) {
        return Promise.reject(new Error(t("errorText")));
      }
      /* ROUND 141 — the wallet pseudo-method pays INSTANTLY (debits the
       * balance, confirms + activates in one server flow). */
      const payWithWallet = methodId === WALLET_CHECKOUT_METHOD_ID;
      return createPlanOrder(instance.id, {
        packageId,
        cycle: state.cycle,
        methodId,
        ...(payWithWallet ? { payWith: "wallet" as const } : {}),
      });
    },
    onSuccess: (result) => {
      if ("walletPaid" in result) {
        /* the INSTANT wallet outcome — no invoice step, the plan is live */
        toast.success(t("walletCheckoutPaidPlan"));
        setState(ACTIVATION_INITIAL);
        void queryClient.invalidateQueries({ queryKey: ["plan-orders", instance.id] });
        void queryClient.invalidateQueries({ queryKey: ["instance", instance.id] });
        void queryClient.invalidateQueries({ queryKey: ["instances"] });
        void queryClient.invalidateQueries({ queryKey: ["wallet", instance.id] });
        void queryClient.invalidateQueries({ queryKey: ["public-packages"] });
        return;
      }
      setState((s) => ({ ...s, step: "invoice", order: result.order, instructions: result.instructions }));
      toast.success(t("payOrderCreated"));
      /* the new entitlement + orders flow in immediately */
      void queryClient.invalidateQueries({ queryKey: ["plan-orders", instance.id] });
      void queryClient.invalidateQueries({ queryKey: ["instance", instance.id] });
      void queryClient.invalidateQueries({ queryKey: ["instances"] });
    },
    onError: (error: unknown) => toast.error(apiErrorText(error, t)),
  });

  const cancelOrder = useCancelPlanOrder(instance.id, () => setState(ACTIVATION_INITIAL));

  return (
    <Dialog open={state.open} onOpenChange={(o) => !o && setState(ACTIVATION_INITIAL)}>
      <DialogContent
        dir={lang === "ar" ? "rtl" : "ltr"}
        className="max-h-[85vh] gap-0 overflow-y-auto rounded-3xl p-0 sm:max-w-lg"
      >
        <DialogHeader className="border-b border-slate-200/70 p-5 dark:border-white/10">
          <DialogTitle className="flex items-center gap-2.5 font-display text-[17px] font-extrabold text-slate-900 dark:text-white">
            <span
              className="grid h-9 w-9 place-items-center rounded-xl text-white shadow-lg"
              style={{ backgroundImage: grad("#6d5dfb", "#d946ef") }}
              aria-hidden="true"
            >
              <CatIcon name={state.step === "invoice" ? "file-check" : "sparkles"} className="h-[15px] w-[15px]" />
            </span>
            {state.step === "invoice" ? t("payInvoiceTitle") : t("planActivateTitle")}
          </DialogTitle>
          <DialogDescription className="ps-[46px] text-[12.5px]">
            {state.step === "invoice" ? t("payAwaitingConfirm") : t("planActivateDesc")}
          </DialogDescription>
        </DialogHeader>

        {/* step indicator */}
        <div className="flex items-center gap-2 border-b border-slate-200/70 px-5 py-3.5 dark:border-white/10">
          <StepChip
            label={t("planStepChoose")}
            icon="list-checks"
            status={state.step === "choose" ? "active" : "done"}
            /* the choose chip doubles as the back button while paying */
            onClick={
              state.step === "pay" && !createOrder.isPending
                ? () => setState((s) => ({ ...s, step: "choose" }))
                : undefined
            }
          />
          <span
            className={cn(
              "h-0.5 flex-1 rounded-full transition-colors",
              state.step === "choose" ? "bg-slate-200 dark:bg-white/10" : "bg-linear-to-r from-brand-500 to-fuchsia-500",
            )}
            aria-hidden="true"
          />
          <StepChip
            label={t("planStepPay")}
            icon="wallet"
            status={state.step === "choose" ? "todo" : state.step === "pay" ? "active" : "done"}
          />
        </div>

        {/* ---------------- STEP 1 — choose plan ---------------- */}
        {state.step === "choose" ? (
          <>
            <div className="space-y-3 p-5">
              {packagesQuery.isPending ? (
                [0, 1, 2].map((i) => (
                  <div
                    key={i}
                    className="flex items-center gap-3 rounded-2xl border border-slate-200/80 p-3.5 dark:border-white/10"
                  >
                    <Skeleton className="h-10 w-10 rounded-xl" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 w-1/3" />
                      <Skeleton className="h-3 w-2/3" />
                    </div>
                    <Skeleton className="h-5 w-5 rounded-full" />
                  </div>
                ))
              ) : packagesQuery.isError ? (
                <div className="rounded-2xl border border-dashed border-red-300 bg-red-50/60 p-5 text-center dark:border-red-500/30 dark:bg-red-500/5">
                  <p className="text-[12.5px] font-bold text-red-600 dark:text-red-400">
                    {packagesQuery.error instanceof Error ? packagesQuery.error.message : t("errorText")}
                  </p>
                  <Button
                    variant="outline"
                    onClick={() => void packagesQuery.refetch()}
                    className="mt-3 h-9 rounded-xl px-4 text-[12px] font-bold"
                  >
                    <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
                    {t("retryText")}
                  </Button>
                </div>
              ) : purchasable.length === 0 ? (
                <p className="rounded-2xl border border-dashed border-slate-300 p-5 text-center text-[12.5px] font-semibold text-slate-400 dark:border-white/10 dark:text-slate-500">
                  {t("billingNoPackages")}
                </p>
              ) : (
                purchasable.map((pkg, i) => {
                  const style = PLAN_STYLES[i % PLAN_STYLES.length];
                  const isCurrent = pkg.id === currentId;
                  const isSelected = pkg.id === state.packageId && !isCurrent;
                  /* ROUND 79 → ROUND 80 — live discount PER CYCLE: crossed-out
                   * base + discounted price + savings chip; the yearly-save chip
                   * computes off the DISCOUNTED prices consistently (server
                   * money law) with each cycle's own promotion */
                  const pct = cycleDiscountPct(pkg, state.cycle);
                  const hasDiscount = pct > 0;
                  const basePrice = state.cycle === "yearly" ? pkg.priceYearly : pkg.priceMonthly;
                  const effPrice = discountedPrice(basePrice, pct);
                  const yearlyPct =
                    pkg.priceMonthly > 0
                      ? Math.max(
                          0,
                          Math.round(
                            (1 -
                              discountedPrice(pkg.priceYearly, effectiveYearlyPct(pkg)) /
                                (discountedPrice(pkg.priceMonthly, pkg.discountPct) * 12)) *
                              100,
                          ),
                        )
                      : 0;
                  return (
                    <button
                      type="button"
                      key={pkg.id}
                      disabled={isCurrent}
                      aria-pressed={isSelected}
                      onClick={() => setState((s) => ({ ...s, packageId: pkg.id }))}
                      className={cn(
                        "flex w-full flex-wrap items-center gap-3 rounded-2xl border p-3.5 text-start transition-all duration-200",
                        isSelected
                          ? "border-brand-500 bg-brand-50/60 ring-2 ring-brand-500/60 dark:border-brand-500/60 dark:bg-brand-500/[0.08]"
                          : isCurrent
                            ? "cursor-not-allowed border-slate-200/80 bg-slate-50/60 opacity-70 dark:border-white/10 dark:bg-white/[0.02]"
                            : "border-slate-200/80 bg-white/60 hover:border-brand-300/70 hover:bg-brand-50/40 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-brand-500/30 dark:hover:bg-brand-500/[0.05]",
                      )}
                    >
                      <span
                        className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-md"
                        style={{ backgroundImage: grad(style.c1, style.c2) }}
                        aria-hidden="true"
                      >
                        <CatIcon name={style.icon} className="h-[14px] w-[14px]" />
                      </span>
                      {/* Arabic plan name + limits anchored at the inline-start
                          (the far right in RTL) — the price block sits opposite */}
                      <span className="min-w-0 flex-1">
                        <span className="flex flex-wrap items-center gap-2">
                          <span className="truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
                            {lang === "ar" ? pkg.nameAr : pkg.nameEn}
                          </span>
                          {isCurrent ? (
                            <Badge className="gap-1 rounded-full border-amber-300/70 bg-amber-100 px-2.5 py-0.5 text-[10px] font-extrabold text-amber-700 hover:bg-amber-100 dark:border-amber-500/30 dark:bg-amber-500/15 dark:text-amber-300">
                              <CatIcon name="crown" className="h-[10px] w-[10px]" />
                              {t("billingCurrentBadge")}
                            </Badge>
                          ) : null}
                          {hasDiscount ? (
                            <Badge className="gap-1 rounded-full border-fuchsia-300/70 bg-fuchsia-100 px-2.5 py-0.5 text-[10px] font-extrabold text-fuchsia-700 hover:bg-fuchsia-100 dark:border-fuchsia-500/30 dark:bg-fuchsia-500/15 dark:text-fuchsia-300">
                              <CatIcon name="ticket-percent" className="h-[10px] w-[10px]" />
                              {t("priceDiscountBadge")}
                            </Badge>
                          ) : null}
                        </span>
                        <span className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] font-semibold text-slate-400 dark:text-slate-500">
                          <span className="inline-flex items-center gap-1">
                            <CatIcon name="users" className="h-[10px] w-[10px]" />
                            {pkg.maxUsers >= UNLIMITED ? t("billingUnlimited") : fmtNum(pkg.maxUsers, lang)}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span className="inline-flex items-center gap-1">
                            <CatIcon name="cubes" className="h-[10px] w-[10px]" />
                            {pkg.maxModules >= UNLIMITED ? t("billingUnlimited") : fmtNum(pkg.maxModules, lang)}
                          </span>
                        </span>
                      </span>
                      {/* price + yearly-save chip anchored at the inline-end so
                          the Arabic-first row reads name (far right) → amount.
                          ROUND 79 — discounted rows show the crossed-out base
                          above the bold emerald effective price + «وفّر {pct}٪» */}
                      <span className="flex shrink-0 flex-col items-end gap-1">
                        {hasDiscount ? (
                          <span
                            dir="ltr"
                            className="text-start text-[10.5px] font-bold tabular-nums text-slate-400 line-through decoration-slate-400/70 decoration-2 dark:text-slate-500"
                          >
                            {fmtPlanPrice(basePrice)} {pkg.currency}
                          </span>
                        ) : null}
                        <span
                          dir="ltr"
                          className={cn(
                            "text-start text-[12.5px] font-extrabold tabular-nums",
                            hasDiscount
                              ? "text-emerald-600 dark:text-emerald-300"
                              : "text-slate-800 dark:text-slate-100",
                          )}
                        >
                          {fmtPlanPrice(effPrice)} {pkg.currency}
                          <span className="ms-1 text-[10px] font-bold text-slate-400 dark:text-slate-500">
                            {state.cycle === "yearly" ? t("planPerYear") : t("planPerMonth")}
                          </span>
                        </span>
                        {hasDiscount ? (
                          <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-px text-[11px] font-extrabold text-emerald-600 dark:text-emerald-300">
                            <CatIcon name="hand-coins" className="h-2.5 w-2.5" />
                            {t("priceSavePct", { pct: fmtNum(pct, lang) })}
                          </span>
                        ) : null}
                        {state.cycle === "yearly" && yearlyPct > 0 ? (
                          <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-px text-[11px] font-extrabold text-emerald-600 dark:text-emerald-300">
                            <CatIcon name="hand-coins" className="h-2.5 w-2.5" />
                            {t("planYearlySave", { pct: fmtNum(yearlyPct, lang) })}
                          </span>
                        ) : null}
                      </span>
                      <SelectDot selected={isSelected} />
                    </button>
                  );
                })
              )}
            </div>

            {/* billing-cycle segmented control */}
            <div className="px-5 pb-2">
              <div className="grid grid-cols-2 gap-1.5 rounded-2xl border border-slate-200/80 bg-slate-100/70 p-1.5 dark:border-white/10 dark:bg-white/[0.04]">
                {(["monthly", "yearly"] as const).map((cycle) => (
                  <button
                    key={cycle}
                    type="button"
                    aria-pressed={state.cycle === cycle}
                    onClick={() => setState((s) => ({ ...s, cycle }))}
                    className={cn(
                      "inline-flex items-center justify-center gap-1.5 rounded-xl px-3 py-2 text-[12px] font-extrabold transition active:scale-95",
                      state.cycle === cycle
                        ? "bg-linear-to-r from-brand-600 to-brand-500 text-white shadow-md shadow-brand-500/25"
                        : "text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200",
                    )}
                  >
                    <CatIcon name={cycle === "yearly" ? "calendar-range" : "calendar-days"} className="h-3.5 w-3.5" />
                    {t(cycle === "yearly" ? "planCycleYearly" : "planCycleMonthly")}
                  </button>
                ))}
              </div>
            </div>

            {/* footer: primary action anchored at the reading start (the far
                right in Arabic) + amount preview at the inline-end */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200/70 p-5 dark:border-white/10">
              <Button
                type="button"
                disabled={!selectedPlan}
                onClick={() => setState((s) => ({ ...s, step: "pay" }))}
                className="h-10 gap-2 rounded-xl bg-linear-to-l from-brand-600 to-fuchsia-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-fuchsia-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-50"
              >
                <CatIcon name="trending-up" className="h-4 w-4" />
                {t("planActivateTitle")}
              </Button>
              <div className="flex min-w-0 flex-col items-end">
                <p className={cn("text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                  {t("payAmountDue")}
                </p>
                <p dir="ltr" className="mt-0.5 text-start font-display text-[20px] font-extrabold tabular-nums text-slate-900 dark:text-white">
                  {selectedPlan && previewAmount != null ? (
                    <>
                      {previewBase != null && previewBase !== previewAmount ? (
                        <span className="me-1.5 text-[12px] font-bold text-slate-400 line-through decoration-slate-400/70 dark:text-slate-500">
                          {fmtPlanPrice(previewBase)} {selectedPlan.currency}
                        </span>
                      ) : null}
                      {fmtPlanPrice(previewAmount)}{" "}
                      <span className="text-[11px] font-bold text-slate-400">{selectedPlan.currency}</span>
                      <span className="ms-1 text-[11px] font-bold text-slate-400">
                        {state.cycle === "yearly" ? t("planPerYear") : t("planPerMonth")}
                      </span>
                    </>
                  ) : (
                    "—"
                  )}
                </p>
                {selectedPlan && cycleDiscountPct(selectedPlan, state.cycle) > 0 ? (
                  <span className="mt-0.5 inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-px text-[10.5px] font-extrabold text-emerald-600 dark:text-emerald-300">
                    <CatIcon name="hand-coins" className="h-2.5 w-2.5" />
                    {t("priceSavePct", { pct: fmtNum(cycleDiscountPct(selectedPlan, state.cycle), lang) })}
                  </span>
                ) : null}
              </div>
            </div>
          </>
        ) : null}

        {/* ---------------- STEP 2 — payment method ---------------- */}
        {state.step === "pay" ? (
          <>
            <div className="space-y-3 p-5">
              {/* chosen plan summary strip */}
              {selectedPlan ? (
                <div className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-brand-200/70 bg-brand-50/50 p-3 dark:border-brand-500/20 dark:bg-brand-500/[0.06]">
                  <p className="flex min-w-0 items-center gap-2 text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                    <span
                      className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-white"
                      style={{ backgroundImage: grad(selectedStyle.c1, selectedStyle.c2) }}
                      aria-hidden="true"
                    >
                      <CatIcon name={selectedStyle.icon} className="h-3 w-3" />
                    </span>
                    <span className="truncate">{lang === "ar" ? selectedPlan.nameAr : selectedPlan.nameEn}</span>
                    <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-brand-500/10 px-2 py-px text-[11px] font-extrabold text-brand-600 dark:text-brand-300">
                      <CatIcon name={state.cycle === "yearly" ? "calendar-range" : "calendar-days"} className="h-2.5 w-2.5" />
                      {t(state.cycle === "yearly" ? "planCycleYearly" : "planCycleMonthly")}
                    </span>
                  </p>
                  {/* ROUND 79 — chosen-plan amount: crossed-out base + the
                      discounted live price the server will charge */}
                  <div className="flex min-w-0 flex-col items-end gap-0.5">
                    {previewBase != null && previewAmount != null && previewBase !== previewAmount ? (
                      <span
                        dir="ltr"
                        className="text-start text-[10.5px] font-bold tabular-nums text-slate-400 line-through decoration-slate-400/70 dark:text-slate-500"
                      >
                        {fmtPlanPrice(previewBase)} {selectedPlan.currency}
                      </span>
                    ) : null}
                    <p dir="ltr" className="text-start font-display text-[15px] font-extrabold tabular-nums text-brand-600 dark:text-brand-300">
                      {fmtPlanPrice(previewAmount ?? 0)} {selectedPlan.currency}
                      <span className="ms-1 text-[10px] font-bold opacity-75">
                        {state.cycle === "yearly" ? t("planPerYear") : t("planPerMonth")}
                      </span>
                    </p>
                    {cycleDiscountPct(selectedPlan, state.cycle) > 0 ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-px text-[10.5px] font-extrabold text-emerald-600 dark:text-emerald-300">
                        <CatIcon name="hand-coins" className="h-2.5 w-2.5" />
                        {t("priceSavePct", { pct: fmtNum(cycleDiscountPct(selectedPlan, state.cycle), lang) })}
                      </span>
                    ) : null}
                  </div>
                </div>
              ) : null}

              <p className="text-[12.5px] font-extrabold text-slate-700 dark:text-slate-200">
                {t("planMethodTitle")}
              </p>

              {/* ROUND 141 — the wallet INSTANT checkout card rides FIRST */}
              {walletQuery.isPending ? (
                <Skeleton className="h-[68px] w-full rounded-2xl" />
              ) : (
                <WalletCheckoutOption
                  wallet={wallet}
                  /* ROUND 166 — previewAmount is already MINOR units */
                  amountMinor={previewAmount ?? 0}
                  selected={walletSelected}
                  onSelect={() =>
                    setState((s) => ({ ...s, methodId: WALLET_CHECKOUT_METHOD_ID }))
                  }
                  pending={createOrder.isPending && walletSelected}
                />
              )}

              {methodsQuery.isPending ? (
                [0, 1, 2].map((i) => (
                  <div
                    key={i}
                    className="flex items-center gap-3 rounded-2xl border border-slate-200/80 p-3.5 dark:border-white/10"
                  >
                    <Skeleton className="h-10 w-10 rounded-xl" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 w-2/5" />
                      <Skeleton className="h-3 w-3/5" />
                    </div>
                    <Skeleton className="h-5 w-5 rounded-full" />
                  </div>
                ))
              ) : methodsQuery.isError ? (
                <div className="rounded-2xl border border-dashed border-red-300 bg-red-50/60 p-5 text-center dark:border-red-500/30 dark:bg-red-500/5">
                  <p className="text-[12.5px] font-bold text-red-600 dark:text-red-400">
                    {methodsQuery.error instanceof Error ? methodsQuery.error.message : t("errorText")}
                  </p>
                  <Button
                    variant="outline"
                    onClick={() => void methodsQuery.refetch()}
                    className="mt-3 h-9 rounded-xl px-4 text-[12px] font-bold"
                  >
                    <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
                    {t("retryText")}
                  </Button>
                </div>
              ) : methods.length === 0 ? (
                <div className="flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-slate-300 bg-white/50 p-6 text-center dark:border-white/10 dark:bg-white/[0.02]">
                  <span className="grid h-12 w-12 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
                    <CatIcon name="wallet" className="h-5 w-5" />
                  </span>
                  <p className="mt-3 text-[12.5px] font-bold text-slate-500 dark:text-slate-400">
                    {t("payMethodsEmpty")}
                  </p>
                </div>
              ) : (
                methods.map((m) => {
                  const meta = METHOD_KIND_META[m.kind] ?? METHOD_KIND_META.bank;
                  const isSelected = state.methodId === m.id;
                  return (
                    <button
                      type="button"
                      key={m.id}
                      aria-pressed={isSelected}
                      onClick={() => setState((s) => ({ ...s, methodId: m.id }))}
                      className={cn(
                        "flex w-full items-center gap-3 rounded-2xl border p-3.5 text-start transition-all duration-200",
                        isSelected
                          ? "border-brand-500 bg-brand-50/60 ring-2 ring-brand-500/60 dark:border-brand-500/60 dark:bg-brand-500/[0.08]"
                          : "border-slate-200/80 bg-white/60 hover:border-brand-300/70 hover:bg-brand-50/40 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-brand-500/30 dark:hover:bg-brand-500/[0.05]",
                      )}
                    >
                      <span
                        className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-md"
                        style={{ backgroundImage: grad(meta.c1, meta.c2) }}
                        aria-hidden="true"
                      >
                        <CatIcon name={meta.icon} className="h-[15px] w-[15px]" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
                          {m.label}
                        </span>
                        <span className="mt-0.5 flex flex-wrap items-center gap-1.5">
                          <span
                            className="inline-flex shrink-0 items-center gap-1 rounded-full px-2 py-px text-[11px] font-extrabold"
                            style={{ color: meta.c2, backgroundColor: `${meta.c1}1f` }}
                          >
                            <CatIcon name={meta.icon} className="h-2.5 w-2.5" />
                            {t(meta.labelKey)}
                          </span>
                          <span className="min-w-0 truncate text-[11px] font-semibold text-slate-400 dark:text-slate-500">
                            {t(meta.descKey)}
                          </span>
                        </span>
                      </span>
                      <SelectDot selected={isSelected} />
                    </button>
                  );
                })
              )}
            </div>

            <div className="border-t border-slate-200/70 p-5 dark:border-white/10">
              <Button
                type="button"
                disabled={
                  !state.methodId ||
                  createOrder.isPending ||
                  (walletSelected && !walletSufficient)
                }
                onClick={() => createOrder.mutate()}
                className={cn(
                  "h-11 w-full gap-2 rounded-xl px-5 text-[13px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:opacity-50",
                  walletSelected
                    ? "bg-linear-to-l from-emerald-600 to-teal-500 shadow-emerald-500/25"
                    : "bg-linear-to-l from-brand-600 to-fuchsia-500 shadow-fuchsia-500/25"
                )}
              >
                {createOrder.isPending ? (
                  <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                ) : (
                  <CatIcon name={walletSelected ? "zap" : "lock"} className="h-4 w-4" />
                )}
                {walletSelected ? t("payWalletCta") : t("payCreateOrder")}
              </Button>
            </div>
          </>
        ) : null}

        {/* ---------------- STEP 3 — invoice ---------------- */}
        {state.step === "invoice" && order && state.instructions ? (
          <>
            <div className="space-y-3.5 p-5">
              {/* plan + cycle + method identity */}
              <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-slate-200/80 bg-white/70 p-3.5 dark:border-white/10 dark:bg-white/[0.04]">
                <IconTile icon={orderMethod?.icon ?? "receipt"} c1={orderMethod?.c1 ?? "#6d5dfb"} c2={orderMethod?.c2 ?? "#d946ef"} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13.5px] font-extrabold text-slate-800 dark:text-slate-100">
                    {lang === "ar" ? order.packageNameAr : order.packageName}
                  </p>
                  <p className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                    <span className="inline-flex items-center gap-1 rounded-full bg-brand-500/10 px-2 py-px text-[11px] font-extrabold text-brand-600 dark:text-brand-300">
                      <CatIcon name={order.cycle === "yearly" ? "calendar-range" : "calendar-days"} className="h-2.5 w-2.5" />
                      {t(order.cycle === "yearly" ? "planCycleYearly" : "planCycleMonthly")}
                    </span>
                    <span
                      className="inline-flex items-center gap-1 rounded-full px-2 py-px text-[11px] font-extrabold"
                      style={{ color: orderMethod?.c2 ?? "#6d5dfb", backgroundColor: `${orderMethod?.c1 ?? "#6d5dfb"}1f` }}
                    >
                      <CatIcon name={orderMethod?.icon ?? "credit-card"} className="h-2.5 w-2.5" />
                      {order.methodLabel || t(orderMethod?.labelKey ?? "payMethodBank")}
                    </span>
                    {order.integrityVerified ? (
                      <span
                        title={t("orderIntegrityOk")}
                        className="inline-flex items-center gap-1 rounded-full border border-emerald-300/60 bg-emerald-500/[0.08] px-2 py-px text-[11px] font-extrabold text-emerald-600 dark:border-emerald-500/30 dark:text-emerald-300"
                      >
                        <CatIcon name="shield-check" className="h-2.5 w-2.5" />
                        {t("orderIntegrityOk")}
                      </span>
                    ) : null}
                  </p>
                </div>
              </div>

              {/* amount due */}
              <div className="rounded-2xl border border-brand-200/70 bg-linear-to-l from-brand-50/80 to-fuchsia-50/50 p-4 text-center dark:border-brand-500/20 dark:from-brand-500/10 dark:to-fuchsia-500/5">
                <p className={cn("text-[11px] font-extrabold uppercase text-brand-500/80 dark:text-brand-300/70", labelTrack(lang))}>
                  {t("payAmountDue")}
                </p>
                <p dir="ltr" className="mt-1 font-display text-[30px] font-extrabold tabular-nums leading-none text-slate-900 dark:text-white">
                  {fmtPlanPrice(order.amount)}{" "}
                  <span className="text-[13px] font-bold text-slate-400">{order.currency}</span>
                </p>
              </div>

              {/* reference block */}
              <div className="rounded-2xl border border-dashed border-brand-300/70 bg-brand-50/40 p-3.5 dark:border-brand-500/30 dark:bg-brand-500/[0.05]">
                <p className={cn("text-[11px] font-extrabold uppercase text-brand-600/80 dark:text-brand-300/70", labelTrack(lang))}>
                  {t("payReference")}
                </p>
                <div className="mt-1.5 flex items-center gap-2">
                  <code
                    dir="ltr"
                    className="min-w-0 flex-1 truncate rounded-xl border border-slate-200/80 bg-white px-3 py-2 font-mono text-[14px] font-extrabold tracking-wider text-slate-800 dark:border-white/10 dark:bg-white/[0.06] dark:text-slate-100"
                  >
                    {order.reference}
                  </code>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => copyRef(order.reference)}
                    title={t("payCopyRef")}
                    className="h-10 shrink-0 gap-1.5 rounded-xl px-3 text-[11px] font-extrabold"
                  >
                    <CatIcon name="copy" className="h-3.5 w-3.5" />
                    <span className="hidden sm:inline">{t("payCopyRef")}</span>
                  </Button>
                </div>
                <p className="mt-2 flex items-start gap-1.5 text-[10.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                  <CatIcon name="info" className="mt-px h-3 w-3 shrink-0" />
                  {t("payReferenceHint")}
                </p>
              </div>

              {/* server-built payment instructions */}
              <div>
                <p className="mb-2 flex items-center gap-1.5 text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
                  <CatIcon name="file-check" className="h-3.5 w-3.5 text-brand-500" />
                  {t("payInstructionsTitle")}
                </p>
                <ol className="space-y-2">
                  {state.instructions.lines.map((line, i) => (
                    <li
                      key={i}
                      className="flex items-start gap-2 rounded-xl border border-slate-200/70 bg-white/60 px-3 py-2.5 text-[12px] font-semibold leading-relaxed text-slate-600 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-300"
                    >
                      <CatIcon name="circle-check" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-500" />
                      <span className="min-w-0">{line}</span>
                    </li>
                  ))}
                </ol>
              </div>

              {/* validity window */}
              <p className="flex items-center gap-1.5 text-[11.5px] font-bold text-slate-500 dark:text-slate-400">
                <CatIcon name="calendar" className="h-3.5 w-3.5 shrink-0 text-slate-400" />
                {t("payValidUntil", { date: fullDate(order.expiresAt, lang) })}
              </p>

              {/* security note — emerald shield tint */}
              <div className="flex items-start gap-2.5 rounded-xl border border-emerald-200/70 bg-emerald-50/70 p-3 dark:border-emerald-500/20 dark:bg-emerald-500/[0.07]">
                <CatIcon name="shield-check" className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-300" />
                <p className="text-[11px] font-bold leading-relaxed text-emerald-700 dark:text-emerald-300">
                  {t("paySecurityNote")}
                </p>
              </div>

              {/* awaiting confirmation — amber pulse */}
              <div className="flex items-center gap-2.5 rounded-xl border border-amber-300/70 bg-linear-to-l from-amber-50/90 to-orange-50/60 p-3 dark:border-amber-500/25 dark:from-amber-500/10 dark:to-orange-500/5">
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-amber-500/15 text-amber-600 dark:text-amber-300">
                  <CatIcon name="hourglass" className="h-4 w-4 animate-pulse" />
                </span>
                <p className="text-[11.5px] font-bold leading-relaxed text-amber-700 dark:text-amber-300">
                  {t("payAwaitingConfirm")}
                </p>
              </div>
            </div>

            <div className="border-t border-slate-200/70 p-5 dark:border-white/10">
              <Button
                type="button"
                variant="outline"
                disabled={cancelOrder.isPending}
                onClick={() => cancelOrder.mutate(order.id)}
                className="h-10 w-full gap-2 rounded-xl border-rose-200 px-5 text-[12px] font-bold text-rose-600 transition hover:border-rose-300 hover:bg-rose-50/60 hover:text-rose-700 active:scale-95 disabled:opacity-50 dark:border-rose-500/30 dark:text-rose-300 dark:hover:border-rose-400/50 dark:hover:bg-rose-500/10"
              >
                {cancelOrder.isPending ? (
                  <CatIcon name="refresh-cw" className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <CatIcon name="circle-x" className="h-3.5 w-3.5" />
                )}
                {t("payCancelOrder")}
              </Button>
            </div>
          </>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}

/* ------------------------------------------------------------------ */
/* ROUND 47 — activation & payment requests card (all states)          */
/* ------------------------------------------------------------------ */

function PlanOrdersCard({
  instance,
  onActivate,
}: {
  instance: InstanceDTO;
  onActivate: () => void;
}) {
  const { t, lang } = useT();
  const copyRef = useCopyRef();
  const cancelOrder = useCancelPlanOrder(instance.id);

  const ordersQuery = useQuery({
    queryKey: ["plan-orders", instance.id],
    queryFn: () => fetchPlanOrders(instance.id),
  });
  const orders = useMemo(
    () => [...(ordersQuery.data ?? [])].sort((a, b) => b.createdAt.localeCompare(a.createdAt)),
    [ordersQuery.data],
  );

  return (
    <DashCard
      title={t("ordersCardTitle")}
      icon="receipt"
      action={
        ordersQuery.data ? (
          <button
            type="button"
            onClick={() => void ordersQuery.refetch()}
            title={t("retryText")}
            aria-label={t("retryText")}
            className="grid h-8 w-8 place-items-center rounded-xl border border-slate-200/80 bg-white/70 text-slate-400 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-500 dark:hover:text-brand-300"
          >
            <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
          </button>
        ) : null
      }
    >
      <p className="mb-4 text-[12px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
        {t("ordersCardDesc")}
      </p>

      {ordersQuery.isPending ? (
        <div className="space-y-3">
          {[0, 1].map((i) => (
            <Skeleton key={i} className="h-[86px] w-full rounded-2xl" />
          ))}
        </div>
      ) : ordersQuery.isError ? (
        <div className="rounded-2xl border border-dashed border-red-300 bg-red-50/60 p-5 text-center dark:border-red-500/30 dark:bg-red-500/5">
          <p className="text-[12.5px] font-bold text-red-600 dark:text-red-400">
            {ordersQuery.error instanceof Error ? ordersQuery.error.message : t("errorText")}
          </p>
          <Button
            variant="outline"
            onClick={() => void ordersQuery.refetch()}
            className="mt-3 h-9 rounded-xl px-4 text-[12px] font-bold"
          >
            <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
            {t("retryText")}
          </Button>
        </div>
      ) : orders.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-slate-300 bg-white/50 p-6 text-center dark:border-white/10 dark:bg-white/[0.02]">
          <span className="grid h-12 w-12 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
            <CatIcon name="receipt" className="h-5 w-5" />
          </span>
          <p className="mt-3 text-[12.5px] font-bold text-slate-500 dark:text-slate-400">
            {t("orderNoRecords")}
          </p>
          {/* ROUND 147 — the empty-state «فعّل خطتك الآن» CTA appears ONLY
           * when NO package is active (trial / no-plan / locked-trial). An
           * owner WITH a plan — including the TOP plan — sees the plain
           * empty state: the owner's directive forbids activate/upgrade CTAs
           * once the highest plan is reached, and an active plan of any tier
           * needs no activation nudge here. */}
          {instance.package == null ? (
            <Button
              type="button"
              onClick={onActivate}
              className="mt-4 h-9 gap-1.5 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-4 text-[11.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
            >
              <CatIcon name="sparkles" className="h-3.5 w-3.5" />
              {t("trialActivateNow")}
            </Button>
          ) : null}
        </div>
      ) : (
        <ul className="space-y-3">
          {orders.map((order) => {
            const method = METHOD_KIND_META[order.method] ?? METHOD_KIND_META.bank;
            const planName = lang === "ar" ? order.packageNameAr : order.packageName;
            const cancelling = cancelOrder.isPending && cancelOrder.variables === order.id;
            return (
              <li
                key={order.id}
                className="flex flex-wrap items-center gap-3 rounded-2xl border border-slate-200/80 bg-white/60 p-3.5 transition hover:border-brand-300/60 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-brand-500/30"
              >
                <IconTile icon={method.icon} c1={method.c1} c2={method.c2} />

                <div className="min-w-0 flex-1">
                  <p className="flex flex-wrap items-center gap-2">
                    <span className="truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
                      {planName}
                    </span>
                    <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-brand-500/10 px-2 py-px text-[11px] font-extrabold text-brand-600 dark:text-brand-300">
                      <CatIcon name={order.cycle === "yearly" ? "calendar-range" : "calendar-days"} className="h-2.5 w-2.5" />
                      {t(order.cycle === "yearly" ? "planCycleYearly" : "planCycleMonthly")}
                    </span>
                    <span
                      className="inline-flex shrink-0 items-center gap-1 rounded-full px-2 py-px text-[11px] font-extrabold"
                      style={{ color: method.c2, backgroundColor: `${method.c1}1f` }}
                    >
                      <CatIcon name={method.icon} className="h-2.5 w-2.5" />
                      {order.methodLabel || t(method.labelKey)}
                    </span>
                  </p>
                  <p className="mt-1 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                    <span className="inline-flex items-center gap-1">
                      <CatIcon name="calendar" className="h-3 w-3" />
                      {fullDate(order.createdAt, lang)}
                    </span>
                    <button
                      type="button"
                      onClick={() => copyRef(order.reference)}
                      title={t("secCopyTip")}
                      aria-label={`${t("payReference")}: ${order.reference}`}
                      className="inline-flex items-center gap-1 rounded-full border border-slate-200 bg-slate-50 px-2 py-px text-[11px] font-extrabold text-slate-500 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-400 dark:hover:text-brand-300"
                    >
                      <span dir="ltr" className="font-mono tracking-wide">{order.reference}</span>
                      <CatIcon name="copy" className="h-2.5 w-2.5" />
                    </button>
                    {order.integrityVerified ? (
                      <span
                        title={t("orderIntegrityOk")}
                        className="inline-flex items-center gap-1 rounded-full border border-emerald-300/60 bg-emerald-500/[0.08] px-2 py-px text-[11px] font-extrabold text-emerald-600 dark:border-emerald-500/30 dark:text-emerald-300"
                      >
                        <CatIcon name="shield-check" className="h-2.5 w-2.5" />
                        {t("orderIntegrityOk")}
                      </span>
                    ) : null}
                  </p>
                </div>

                <div className="flex min-w-0 flex-col items-end gap-1.5">
                  <p dir="ltr" className="text-start font-display text-[15px] font-extrabold tabular-nums text-slate-800 dark:text-slate-100">
                    {fmtPlanPrice(order.amount)}{" "}
                    <span className="text-[11px] font-bold text-slate-400">{order.currency}</span>
                  </p>
                  <OrderStatusChip status={order.effectiveStatus} />
                  {order.effectiveStatus === "paid" && order.paidAt ? (
                    <span className="text-[11px] font-bold text-emerald-600/80 dark:text-emerald-400/80">
                      {fullDate(order.paidAt, lang)}
                    </span>
                  ) : null}
                  {order.effectiveStatus === "pending" ? (
                    <Button
                      type="button"
                      variant="outline"
                      disabled={cancelOrder.isPending}
                      onClick={() => cancelOrder.mutate(order.id)}
                      className="h-7 gap-1 rounded-lg border-rose-200 px-2.5 text-[10px] font-bold text-rose-600 transition hover:border-rose-300 hover:text-rose-700 active:scale-95 disabled:opacity-50 dark:border-rose-500/30 dark:text-rose-300"
                    >
                      {cancelling ? (
                        <CatIcon name="refresh-cw" className="h-2.5 w-2.5 animate-spin" />
                      ) : (
                        <CatIcon name="circle-x" className="h-2.5 w-2.5" />
                      )}
                      {t("payCancelOrder")}
                    </Button>
                  ) : null}
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </DashCard>
  );
}

/* ------------------------------------------------------------------ */
/* Billing view                                                        */
/* ------------------------------------------------------------------ */

export function BillingView({ instance, members }: { instance: InstanceDTO; members: TeamMemberDTO[] }) {
  const { t, lang } = useT();
  const [activation, setActivation] = useState<ActivationState>(ACTIVATION_INITIAL);
  const ent = instance.entitlement;

  const openActivation = () => setActivation({ ...ACTIVATION_INITIAL, open: true });

  const system = SYSTEM_MAP[instance.systemId];
  const cat = system ? CATEGORY_MAP[system.c] : undefined;
  const c1 = cat?.c1 ?? "#6d5dfb";
  const c2 = cat?.c2 ?? "#0ea5e9";
  /* round 29 — the module ceiling falls back to the system's effective
     module list (specialized systems carry their own). */
  const sysTotal = systemMods(system).length;

  const pkg = instance.package ?? null;

  /* ROUND 79 → ROUND 80 — live discount on the CURRENT plan, PER CYCLE
   * (monthly promotion + dedicated annual promotion); the yearly-saving
   * percentage computes off the DISCOUNTED prices with each cycle's own pct */
  const pkgDiscount = pkg?.discountPct ?? 0;
  const pkgYearlyDiscount = pkg ? effectiveYearlyPct(pkg) : 0;
  const monthlyEff = pkg ? discountedPrice(pkg.priceMonthly, pkgDiscount) : 0;
  const yearlyEff = pkg ? discountedPrice(pkg.priceYearly, pkgYearlyDiscount) : 0;

  const activitiesQuery = useQuery({
    queryKey: ["activities", instance.id, 100],
    queryFn: () => fetchActivities(instance.id, 100),
  });

  /* ROUND 147 — REAL storage meter data: server-measured bytes from the
   * usage endpoint (the SAME ["instance-usage", id] cache entry the
   * settings StorageCard shares). Auxiliary data — an error hides the
   * meter silently and never blocks the billing page. */
  const storageUsageQuery = useQuery({
    queryKey: ["instance-usage", instance.id],
    queryFn: () => fetchInstanceUsage(instance.id),
  });
  const storageUsage = storageUsageQuery.isError ? null : (storageUsageQuery.data ?? null);

  /* ROUND 147 — plan ladder computed ONCE for the whole view, on the PUBLIC
   * catalog's own order (GET /api/packages = sortOrder ascending = the tier
   * ladder). currentIdx is -1 BOTH for "no package" and for "package missing
   * from the active catalog" — neither shape counts as the top tier. The
   * query key is the SAME ["public-packages"] entry the status strip /
   * benefits card / activation dialog already share, so this adds a dedup'd
   * observer, not a new request. */
  const packagesQuery = useQuery({
    queryKey: ["public-packages"],
    queryFn: fetchPublicPackages,
    staleTime: 60_000,
  });
  const planLadder = useMemo(() => {
    const plans = packagesQuery.data ?? [];
    const currentIdx = plans.findIndex((p) => p.id === pkg?.id);
    return { plans, currentIdx };
  }, [packagesQuery.data, pkg]);

  /* ROUND 147 — CTA truth table (the owner's exact rules): an ACTIVE
   * workspace on the LAST rung gets the positive crown card (NO CTA at
   * all — no upgrade, no activate); an ACTIVE workspace on a lower rung
   * gets the precise «ترقية الباقة» card; every other shape (no package /
   * retired package / trial / locked) keeps today's generic card — the
   * locked heroes keep their renewal/activation CTA untouched. */
  const isTopPlan =
    ent.state === "active" &&
    planLadder.currentIdx >= 0 &&
    planLadder.currentIdx === planLadder.plans.length - 1;
  const hasUpgradePath =
    ent.state === "active" &&
    planLadder.currentIdx >= 0 &&
    planLadder.currentIdx < planLadder.plans.length - 1;

  /* Real plan limits (fallback to the system's module total / generous
   * defaults when no plan is assigned yet). */
  const modulesTotal = pkg ? (pkg.maxModules >= UNLIMITED ? UNLIMITED : pkg.maxModules) : Math.max(1, sysTotal);
  const usersTotal = pkg ? (pkg.maxUsers >= UNLIMITED ? UNLIMITED : pkg.maxUsers) : 10;
  const activitiesUsed = activitiesQuery.data?.length ?? 0;

  const usage = [
    {
      label: t("dashActiveModules"),
      used: instance.modules.length,
      total: modulesTotal,
      unlimited: modulesTotal >= UNLIMITED,
      base: grad(c1, c2),
    },
    {
      label: t("memberCount"),
      used: members.length,
      total: usersTotal,
      unlimited: usersTotal >= UNLIMITED,
      base: "linear-gradient(90deg,#10b981,#047857)",
    },
    {
      label: t("activityCount"),
      used: activitiesUsed,
      total: 100,
      unlimited: false,
      base: "linear-gradient(90deg,#06b6d4,#0891b2)",
    },
  ];

  const yearlySave = pkg && pkg.priceMonthly > 0
    ? Math.max(
        0,
        Math.round(
          (1 -
            discountedPrice(pkg.priceYearly, effectiveYearlyPct(pkg)) /
              (discountedPrice(pkg.priceMonthly, pkgDiscount) * 12)) *
            100,
        ),
      )
    : 0;

  /* ROUND 79 — renewal nudge: the paid term ends within 7 days (amber
   * banner above the cards with the renewal CTA — same activation dialog
   * flow; choosing any plan + paying = renewal) */
  const renewNudge =
    ent.state === "active" &&
    ent.planExpiresAt != null &&
    (ent.planDaysLeft ?? 0) > 0 &&
    (ent.planDaysLeft ?? 0) <= 7;

  return (
    <div className="space-y-5">
      <ViewHeading title={t("dashBillingTitle")} desc={t("dashBillingDesc")} />

      {/* ROUND 47 → ROUND 79 — locked hero, forked by lockReason (expired
          trial keeps the activation hero; expired paid term gets the
          rose→violet renewal hero with the term date + data assurance) */}
      {ent.state === "locked" ? <LockedHero instance={instance} onActivate={openActivation} /> : null}

      {/* ROUND 47 — trial banner (free window countdown) */}
      {ent.state === "trial" ? <TrialBanner instance={instance} onActivate={openActivation} /> : null}

      {/* ROUND 46/47 — professional subscription status bar (state-aware) */}
      <SubscriptionStatusStrip instance={instance} pkg={pkg} />

      {/* ROUND 79 — renewal nudge: the paid term ends within 7 days */}
      {renewNudge ? (
        <div
          role="status"
          className="card-in flex flex-col gap-3 rounded-2xl border border-amber-300/60 bg-linear-to-l from-amber-50/90 to-orange-50/60 p-4 shadow-sm sm:flex-row sm:items-center sm:gap-4 dark:border-amber-500/40 dark:from-amber-500/[0.13] dark:to-orange-500/[0.13]"
        >
          <span
            className="relative grid h-11 w-11 shrink-0 place-items-center rounded-2xl border border-amber-300/70 bg-amber-500/15 text-amber-600 dark:border-amber-500/40 dark:bg-amber-500/20 dark:text-amber-300"
            aria-hidden="true"
          >
            <CatIcon name="calendar-range" className="h-5 w-5" />
            <span className="absolute -end-1 -top-1 h-3 w-3 animate-pulse rounded-full bg-amber-500 ring-2 ring-white dark:ring-slate-950" />
          </span>
          <p className="min-w-0 flex-1 text-[13px] font-bold leading-relaxed text-amber-800 dark:text-amber-200">
            {t("renewNudge")}
          </p>
          <Button
            type="button"
            onClick={openActivation}
            className="h-11 shrink-0 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-amber-500/25 transition hover:brightness-110 active:scale-95"
            style={{ backgroundImage: grad("#f59e0b", "#d97706") }}
          >
            <CatIcon name="refresh-cw" className="h-4 w-4" />
            {t("renewCta")}
          </Button>
        </div>
      ) : null}

      <div className="grid gap-4 lg:grid-cols-2">
        {/* current plan (live) */}
        {pkg ? (
          <section
            className="card-in relative overflow-hidden rounded-3xl p-6 text-white shadow-lift"
            style={{ backgroundImage: grad(c1, c2, 120) }}
          >
            <div
              className="pointer-events-none absolute -end-10 -top-10 h-40 w-40 rounded-full bg-white/15"
              aria-hidden="true"
            />
            <div
              className="pointer-events-none absolute -bottom-14 -start-8 h-36 w-36 rounded-full border-[14px] border-white/10"
              aria-hidden="true"
            />
            <div
              className="pointer-events-none absolute inset-0 opacity-[0.16]"
              style={{
                backgroundImage: "radial-gradient(circle at 1px 1px, rgba(255,255,255,0.9) 1px, transparent 0)",
                backgroundSize: "22px 22px",
              }}
              aria-hidden="true"
            />

            <div className="relative flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <span className="grid h-12 w-12 place-items-center rounded-2xl bg-white/20 backdrop-blur">
                  <CatIcon name="crown" className="h-5 w-5" />
                </span>
                <div>
                  <p className="text-[11px] font-extrabold uppercase tracking-wider opacity-80">
                    {t("planCurrent")}
                  </p>
                  <h2 className="font-display text-2xl font-extrabold">
                    {lang === "ar" ? pkg.nameAr : pkg.nameEn}
                  </h2>
                </div>
              </div>
              <div className="flex shrink-0 flex-col items-end gap-1.5">
                {pkg.popular ? (
                  <Badge className="gap-1.5 border-white/30 bg-white/20 text-[11px] text-white hover:bg-white/20">
                    <CatIcon name="star" className="h-[11px] w-[11px]" />
                    {t("pricePopular")}
                  </Badge>
                ) : (
                  <Badge className="border-white/30 bg-white/20 text-[11px] text-white hover:bg-white/20">
                    Ashrilogic
                  </Badge>
                )}
                {/* ROUND 79 — live discount badge */}
                {pkgDiscount > 0 ? (
                  <Badge className="gap-1.5 border-white/40 bg-white/30 text-[11px] text-white hover:bg-white/30">
                    <CatIcon name="ticket-percent" className="h-[11px] w-[11px]" />
                    {t("priceDiscountBadge")} · {fmtNum(pkgDiscount, lang)}{lang === "ar" ? "٪" : "%"}
                  </Badge>
                ) : null}
              </div>
            </div>

            <p className="relative mt-3 max-w-md text-[13px] font-semibold leading-relaxed text-white/85">
              {lang === "ar" ? pkg.descAr : pkg.descEn}
            </p>

            {/* price block — ROUND 79 → ROUND 80: per-cycle crossed-out base +
                discounted price + per-cycle «وفّر {pct}٪» chips (monthly pct +
                the dedicated annual pct) */}
            <div className="relative mt-5 flex flex-wrap items-end gap-x-5 gap-y-2">
              {pkgDiscount > 0 ? (
                <span
                  dir="ltr"
                  className="font-display text-[17px] font-bold leading-none text-white/55 line-through decoration-white/70 decoration-2"
                >
                  {fmtPlanPrice(pkg.priceMonthly)} {pkg.currency}
                </span>
              ) : null}
              <p className="font-display text-[34px] font-extrabold leading-none" dir="ltr">
                {fmtPlanPrice(monthlyEff)}
                <span className="ms-1.5 align-middle text-[13px] font-bold opacity-90">
                  {pkg.currency}
                </span>
              </p>
              <span className="pb-1 text-[12px] font-bold opacity-80">{t("billingPerMonth")}</span>
              <span className="pb-1 text-[12px] font-semibold opacity-75" dir="ltr">
                · {t("billingYearlyPrice")}:{" "}
                {pkgYearlyDiscount > 0 ? (
                  <span className="line-through decoration-white/70">{fmtPlanPrice(pkg.priceYearly)}</span>
                ) : null}{" "}
                {fmtPlanPrice(yearlyEff)} {pkg.currency}
              </span>
              {pkgDiscount > 0 ? (
                <span className="mb-0.5 inline-flex items-center gap-1 rounded-full bg-white/20 px-2.5 py-1 text-[10.5px] font-extrabold backdrop-blur">
                  <CatIcon name="hand-coins" className="h-[11px] w-[11px]" />
                  {t("priceSavePct", { pct: fmtNum(pkgDiscount, lang) })}
                </span>
              ) : null}
              {pkgYearlyDiscount > pkgDiscount ? (
                <span className="mb-0.5 inline-flex items-center gap-1 rounded-full bg-white/20 px-2.5 py-1 text-[10.5px] font-extrabold backdrop-blur">
                  <CatIcon name="calendar-range" className="h-[11px] w-[11px]" />
                  {t("billingSaveYearly", { pct: fmtNum(pkgYearlyDiscount, lang) })}
                </span>
              ) : null}
              {yearlySave > 0 ? (
                <span className="mb-0.5 inline-flex items-center gap-1 rounded-full bg-white/20 px-2.5 py-1 text-[10.5px] font-extrabold backdrop-blur">
                  <CatIcon name="hand-coins" className="h-[11px] w-[11px]" />
                  {t("planYearlySave", { pct: fmtNum(yearlySave, lang) })}
                </span>
              ) : null}
            </div>

            {/* limits + since */}
            <div className="relative mt-5 flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-3 py-1.5 text-[11px] font-bold backdrop-blur">
                <CatIcon name="users" className="h-[11px] w-[11px]" />
                {t("billingLimitUsers")}:{" "}
                {pkg.maxUsers >= UNLIMITED ? t("billingUnlimited") : fmtNum(pkg.maxUsers, lang)}
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-3 py-1.5 text-[11px] font-bold backdrop-blur">
                <CatIcon name="cubes" className="h-[11px] w-[11px]" />
                {t("billingLimitModules")}:{" "}
                {pkg.maxModules >= UNLIMITED ? t("billingUnlimited") : fmtNum(pkg.maxModules, lang)}
              </span>
            </div>

            <p className="relative mt-5 flex items-center gap-1.5 border-t border-white/20 pt-3.5 text-[11px] font-semibold text-white/75">
              <CatIcon name="calendar" className="h-[11px] w-[11px]" />
              {t("billingSince")} {relativeDistance(instance.createdAt, lang)}
            </p>
          </section>
        ) : (
          /* no plan assigned */
          <section className="card-in relative flex flex-col items-center justify-center overflow-hidden rounded-3xl border-2 border-dashed border-slate-300 bg-white/60 p-8 text-center dark:border-white/10 dark:bg-white/[0.02]">
            <div
              className="pointer-events-none absolute inset-0 opacity-40 dark:opacity-20"
              style={{
                backgroundImage: "radial-gradient(circle at 1px 1px, rgba(109,93,251,0.18) 1px, transparent 0)",
                backgroundSize: "20px 20px",
              }}
              aria-hidden="true"
            />
            <span className="relative grid h-16 w-16 place-items-center rounded-3xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
              <CatIcon name="crown" className="h-7 w-7" />
            </span>
            <h2 className="relative mt-4 font-display text-lg font-extrabold text-slate-800 dark:text-slate-100">
              {t("billingNoPlan")}
            </h2>
            <p className="relative mt-2 max-w-sm text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("billingNoPlanDesc")}
            </p>
            <Button
              type="button"
              onClick={openActivation}
              className="relative mt-5 h-10 gap-2 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
            >
              <CatIcon name="sparkles" className="h-4 w-4" />
              {/* ROUND 147 — no-package hero (any state): the owner's rule is
                  the ACTION verb «فعّل خطتك الآن», not a passive «view plans»
                  (the activation dialog still opens exactly as before). */}
              {t("trialActivateNow")}
            </Button>
          </section>
        )}

        <div className="space-y-4">
          {/* usage */}
          <DashCard title={t("billingUsage")} icon="chart-column">
            <ul className="space-y-4">
              {usage.map((u) => {
                const pct = Math.min(100, (u.used / Math.max(1, u.total)) * 100);
                return (
                  <li key={u.label}>
                    <div className="mb-1.5 flex items-center justify-between text-[12px] font-bold">
                      <span className="text-slate-700 dark:text-slate-200">{u.label}</span>
                      <span className="text-slate-400 dark:text-slate-500">
                        {activitiesQuery.isPending && u.label === t("activityCount") ? (
                          <Skeleton className="inline-block h-3 w-10 align-middle" />
                        ) : (
                          t("billingOf", {
                            used: fmtNum(u.used, lang),
                            total: u.unlimited ? t("billingUnlimited") : fmtNum(u.total, lang),
                          })
                        )}
                      </span>
                    </div>
                    <MeterBar
                      value={u.unlimited ? 100 : pct}
                      color={u.unlimited ? "linear-gradient(90deg,#94a3b8,#cbd5e1)" : meterColor(pct, u.base)}
                    />
                    {u.unlimited ? (
                      <span className="mt-1 inline-flex items-center gap-1 text-[10px] font-bold text-slate-400 dark:text-slate-500">
                        <CatIcon name="badge-check" className="h-[10px] w-[10px]" />
                        {t("billingUnlimited")}
                      </span>
                    ) : null}
                  </li>
                );
              })}

              {/* ROUND 147 — REAL storage meter: every byte is measured by
                  the server (usage endpoint) and simply rendered here —
                  used-of-quota + tone chip (≥90 rose · ≥70 amber · else
                  emerald, the settings StorageCard thresholds) + a slim
                  progress bar with the same aria pattern. quotaBytes null =
                  unlimited → the chip hides and the bar keeps its emerald
                  "unlimited" hint (4% width). Auxiliary data → hidden
                  silently on error / while pending. */}
              {storageUsage ? (
                <li>
                  <div className="mb-1.5 flex flex-wrap items-center justify-between gap-2 text-[12px] font-bold">
                    <span className="text-slate-700 dark:text-slate-200">{t("storageCardTitle")}</span>
                    <span className="flex flex-wrap items-center gap-2">
                      {storageUsage.pct !== null ? (
                        <span
                          className={cn(
                            "inline-flex shrink-0 items-center gap-1 rounded-full px-2 py-px text-[10px] font-extrabold",
                            storageUsage.pct >= 90
                              ? "bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300"
                              : storageUsage.pct >= 70
                                ? "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300"
                                : "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300",
                          )}
                        >
                          <CatIcon name="hard-drive" className="h-2.5 w-2.5" />
                          {fmtNum(storageUsage.pct, lang)}
                          {lang === "ar" ? "٪" : "%"}
                        </span>
                      ) : null}
                      <span className="text-slate-400 dark:text-slate-500">
                        {t("storageUsedOf", {
                          used: fmtBytesOrZero(storageUsage.totalBytes, lang),
                          quota:
                            storageUsage.quotaBytes === null
                              ? t("storageUnlimited")
                              : formatBytes(storageUsage.quotaBytes, lang),
                        })}
                      </span>
                    </span>
                  </div>
                  <div
                    className="h-2 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-white/10"
                    role="progressbar"
                    aria-label={t("storageCardTitle")}
                    aria-valuenow={storageUsage.pct === null ? undefined : Math.round(storageUsage.pct)}
                    aria-valuemin={0}
                    aria-valuemax={100}
                  >
                    <div
                      className="h-full rounded-full transition-all duration-700"
                      style={{
                        width: `${storageUsage.pct === null ? 4 : Math.max(0, Math.min(100, storageUsage.pct))}%`,
                        backgroundImage:
                          storageUsage.pct === null
                            ? grad("#10b981", "#059669")
                            : storageUsage.pct >= 90
                              ? grad("#f43f5e", "#e11d48")
                              : storageUsage.pct >= 70
                                ? grad("#f59e0b", "#d97706")
                                : grad("#10b981", "#059669"),
                      }}
                    />
                  </div>
                </li>
              ) : null}
            </ul>
          </DashCard>

          {/* upgrade — ROUND 147 CTA truth table (owner's exact rules):
              • NO package at all → the card does NOT render: nothing to
                upgrade FROM — the trial banner / no-plan hero carry the ONE
                activation CTA («فعّل خطتك الآن»), never a competing upgrade
                pitch.
              • active + top rung → the positive crown card (NO CTA at all).
              • every other shape WITH a package (active lower rung /
                retired package / locked-plan-expired) → the upgrade card
                («ترقية الباقة» on a lower rung; the generic title
                otherwise). Same DashCard shell for visual consistency. */}
          {pkg != null ? (
            isTopPlan ? (
            <DashCard title={t("billingTopPlan")} icon="crown">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <p className="max-w-sm text-[12.5px] text-slate-500 dark:text-slate-400">
                  {t("billingTopPlanDesc")}
                </p>
                <Badge className="gap-1.5 rounded-full border-amber-300/70 bg-amber-100 px-3 py-1 text-[11px] font-extrabold text-amber-700 hover:bg-amber-100 dark:border-amber-500/30 dark:bg-amber-500/15 dark:text-amber-300">
                  <CatIcon name="crown" className="h-3 w-3" />
                  {t("billingTopPlanBadge")}
                </Badge>
              </div>
            </DashCard>
          ) : (
            <DashCard
              title={hasUpgradePath ? t("billingUpgradeTitle") : t("billingUpgrade")}
              icon="trending-up"
            >
              <div className="flex flex-wrap items-center justify-between gap-3">
                <p className="max-w-sm text-[12.5px] text-slate-500 dark:text-slate-400">
                  {hasUpgradePath
                    ? t("billingUpgradeDesc")
                    : pkg
                      ? lang === "ar"
                        ? pkg.descAr
                        : pkg.descEn
                      : t("billingNoPlanDesc")}
                </p>
                <Button
                  type="button"
                  onClick={openActivation}
                  className="h-10 gap-2 rounded-xl bg-linear-to-l from-brand-600 to-fuchsia-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-fuchsia-500/25 transition hover:brightness-110 active:scale-95"
                >
                  <CatIcon name="trending-up" className="h-4 w-4" />
                  {hasUpgradePath ? t("billingUpgradeTitle") : t("billingUpgrade")}
                </Button>
              </div>
            </DashCard>
          )
          ) : null}
        </div>
      </div>

      {/* ROUND 46 — plan benefits + last plan change (F-5) */}
      <div className="grid gap-4 lg:grid-cols-2">
        <PlanBenefitsCard pkg={pkg} />
        <LastPlanChangeCard instance={instance} />
      </div>

      {/* ROUND 47 — activation & payment requests (rendered for ALL states —
          locked tenants land here to follow their pending payment) */}
      <PlanOrdersCard instance={instance} onActivate={openActivation} />

      <p className="flex items-center justify-center gap-2 rounded-2xl border border-dashed border-slate-300 py-3 text-[11.5px] font-semibold text-slate-400 dark:border-white/10 dark:text-slate-500">
        <CatIcon name="info" className="h-3.5 w-3.5" />
        {t("billingDemoNote")}
      </p>

      <ActivationDialog state={activation} setState={setActivation} instance={instance} />
    </div>
  );
}
