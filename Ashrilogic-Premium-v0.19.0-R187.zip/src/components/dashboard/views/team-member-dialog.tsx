"use client";

/**
 * ROUND 68 — premium team-member ADD / EDIT dialog (فريق الإدارة).
 *
 * One dialog, two modes:
 *  - ADD: the full extended intake — photo (UNIFIED AvatarPicker, the same
 *    pipeline as the owner's avatar), name, email, the second-language
 *    identity lines (R163: lifted ABOVE the phone), phone, role, job title,
 *    birth date, gender → POST
 *    /members with the extended payload.
 *  - EDIT: prefilled + diff-gated PATCH /members?memberId=X (only the
 *    changed fields travel; clearing an optional field sends null).
 *
 * Task 2-b — «بيانات العضو بلغة ثانية»: nameAlt / jobTitleAlt ride the
 * sealed profileJson envelope. The fields are direction-aware: an Arabic
 * UI presents them as ENGLISH fields (dir="ltr"), a non-Arabic UI presents
 * them as ARABIC fields (dir="rtl") — the second language is always the
 * UI's opposite, placeholders/labels included.
 *
 * Sections carry the wizard's WZ_LABEL/WZ_INPUT vocabulary; the footer uses
 * the standard gradient save button. Parent remounts it with a `key` per
 * subject so state resets cleanly.
 */
import { useState, type FormEvent } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { useT, type I18nKey } from "@/lib/i18n";
import type { InstanceDTO, MemberGender, TeamMemberDTO, UpdateTeamMemberPayload } from "@/lib/types";
import { addMember, updateMember } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, hexAlpha } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { WZ_INPUT, WZ_LABEL } from "@/components/wizard/wizard-shared";
import { PremiumDateInput } from "@/components/ui/premium-date-input";
import { AvatarPicker } from "@/components/dashboard/avatar-picker";
import { EMAIL_RE, PHONE_RE } from "@/lib/validation";
import { PERMISSION_IDS, PERMISSION_META, permissionsOf, permissionStats } from "@/lib/permissions";

type Role = "manager" | "staff" | "viewer";

/* ROUND 78 — permission-id → label key (mirrors the engine catalog). */
const PERM_LABEL_KEYS: Record<(typeof PERMISSION_IDS)[number], I18nKey> = {
  "overview.view": "permOverviewView",
  "activity.view": "permActivityView",
  "exports.run": "permExportsRun",
  "modules.view": "permModulesView",
  "modules.edit": "permModulesEdit",
  "inventory.manage": "permInventoryManage",
  "orders.manage": "permOrdersManage",
  "support.manage": "permSupportManage",
  "customers.view": "permCustomersView",
  "team.view": "permTeamView",
  "team.manage": "permTeamManage",
  "website.manage": "permWebsiteManage",
  "billing.manage": "permBillingManage",
  "settings.manage": "permSettingsManage",
};

const ROLE_KEYS: Record<Role, I18nKey> = {
  manager: "roleManager",
  staff: "roleStaff",
  viewer: "roleViewer",
};

const ROLE_GRAD: Record<Role, { c1: string; c2: string }> = {
  manager: { c1: "#8b5cf6", c2: "#6d28d9" },
  staff: { c1: "#06b6d4", c2: "#0891b2" },
  viewer: { c1: "#64748b", c2: "#475569" },
};


function SectionLabel({ icon, children }: { icon: string; children: React.ReactNode }) {
  return (
    <p className="mb-3 flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
      <CatIcon name={icon} className="h-3 w-3" />
      {children}
    </p>
  );
}

export function TeamMemberDialog({
  open,
  onOpenChange,
  instance,
  member,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  instance: InstanceDTO;
  /** null → ADD mode; a member → EDIT mode */
  member: TeamMemberDTO | null;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const queryKey = ["instance", instance.id] as const;

  const edit = member !== null;
  const g = ROLE_GRAD[(member?.role ?? "staff") as Role];

  /* ---------------- form state (parent remounts per subject) ---------------- */
  const [avatar, setAvatar] = useState(member?.avatarUrl ?? "");
  const [name, setName] = useState(member?.name ?? "");
  const [email, setEmail] = useState(member?.email ?? "");
  const [phone, setPhone] = useState(member?.phone ?? "");
  const [role, setRole] = useState<Role>((member?.role ?? "staff") as Role);
  const [jobTitle, setJobTitle] = useState(member?.jobTitle ?? "");
  /* Task 2-b — second-language identity lines (UI-ar → English, else Arabic) */
  const [nameAlt, setNameAlt] = useState(member?.nameAlt ?? "");
  const [jobTitleAlt, setJobTitleAlt] = useState(member?.jobTitleAlt ?? "");
  const [birthDate, setBirthDate] = useState(member?.birthDate ?? "");
  const [gender, setGender] = useState<MemberGender | "">((member?.gender ?? "") as MemberGender | "");
  const [invalid, setInvalid] = useState<{ name?: boolean; email?: boolean; phone?: boolean }>({});

  const phoneDirty = phone.trim() !== (member?.phone ?? "");
  const anyDirty =
    avatar !== (member?.avatarUrl ?? "") ||
    name.trim() !== (member?.name ?? "") ||
    email.trim() !== (member?.email ?? "") ||
    phoneDirty ||
    role !== (member?.role ?? "staff") ||
    jobTitle.trim() !== (member?.jobTitle ?? "") ||
    birthDate !== (member?.birthDate ?? "") ||
    gender !== (member?.gender ?? "") ||
    nameAlt.trim() !== (member?.nameAlt ?? "") ||
    jobTitleAlt.trim() !== (member?.jobTitleAlt ?? "");

  /* ---------------- mutations ---------------- */
  const add = useMutation({
    mutationFn: () =>
      addMember(instance.id, {
        name: name.trim(),
        email: email.trim(),
        role,
        ...(phone.trim() ? { phone: phone.trim() } : {}),
        ...(jobTitle.trim() ? { jobTitle: jobTitle.trim() } : {}),
        ...(birthDate ? { birthDate } : {}),
        ...(gender ? { gender } : {}),
        ...(avatar ? { avatarUrl: avatar } : {}),
        ...(nameAlt.trim() ? { nameAlt: nameAlt.trim() } : {}),
        ...(jobTitleAlt.trim() ? { jobTitleAlt: jobTitleAlt.trim() } : {}),
      }),
    onSuccess: () => {
      toast.success(t("teamAdded"));
      void queryClient.invalidateQueries({ queryKey });
      onOpenChange(false);
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  const update = useMutation({
    mutationFn: () => {
      const target = member;
      if (!target) throw new Error("No member selected");
      const patch: UpdateTeamMemberPayload = {};
      if (avatar !== target.avatarUrl) patch.avatarUrl = avatar || null;
      if (name.trim() !== target.name) patch.name = name.trim();
      if (email.trim() !== target.email) patch.email = email.trim();
      if (phone.trim() !== target.phone) patch.phone = phone.trim() || null;
      if (role !== target.role) patch.role = role;
      if (jobTitle.trim() !== target.jobTitle) patch.jobTitle = jobTitle.trim() || null;
      if (birthDate !== target.birthDate) patch.birthDate = birthDate || null;
      if (gender !== target.gender) patch.gender = (gender || null) as MemberGender | null;
      if (nameAlt.trim() !== target.nameAlt) patch.nameAlt = nameAlt.trim() || null;
      if (jobTitleAlt.trim() !== target.jobTitleAlt) patch.jobTitleAlt = jobTitleAlt.trim() || null;
      return updateMember(instance.id, target.id, patch);
    },
    onSuccess: () => {
      toast.success(t("teamUpdatedToast"));
      void queryClient.invalidateQueries({ queryKey });
      onOpenChange(false);
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const nameOk = name.trim().length > 0;
    const emailOk = EMAIL_RE.test(email.trim());
    const phoneOk = phone.trim() === "" || PHONE_RE.test(phone.trim());
    setInvalid({ name: !nameOk, email: !emailOk, phone: !phoneOk });
    if (!nameOk || !emailOk || !phoneOk) {
      toast.error(t("teamInvalid"));
      return;
    }
    if (edit && !anyDirty) {
      toast.info(t("settingsNoChanges"));
      return;
    }
    if (edit) update.mutate();
    else add.mutate();
  };

  const saving = add.isPending || update.isPending;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        dir={lang === "ar" ? "rtl" : "ltr"}
        className="flex max-h-[88vh] flex-col gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-lg"
      >
        {/* gradient header strip */}
        <div
          className="relative flex shrink-0 items-center gap-3.5 overflow-hidden border-b border-slate-200/70 px-5 py-4 dark:border-white/10"
          style={{
            backgroundImage: `linear-gradient(135deg, ${hexAlpha(g.c1, 0.16)}, ${hexAlpha(g.c2, 0.16)})`,
          }}
        >
          <span
            aria-hidden="true"
            className="absolute -end-8 -top-14 h-28 w-28 rounded-full"
            style={{ background: `radial-gradient(circle, ${hexAlpha(g.c1, 0.3)}, transparent 70%)` }}
          />
          <span
            className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
            style={{ backgroundImage: grad(g.c1, g.c2) }}
            aria-hidden="true"
          >
            <CatIcon name={edit ? "pencil" : "user-plus"} className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <DialogTitle className="truncate font-display text-[15px] font-extrabold leading-tight text-slate-900 dark:text-white">
              {edit ? t("teamEditDialogTitle") : t("teamAddDialogTitle")}
            </DialogTitle>
            <DialogDescription className="mt-0.5 truncate text-[11.5px] font-semibold text-slate-500 dark:text-slate-400">
              {edit
                ? t("teamEditDialogDesc", { name: member?.name ?? "" })
                : t("teamAddDialogDesc")}
            </DialogDescription>
          </div>
        </div>

        <form onSubmit={submit} noValidate className="flex min-h-0 flex-1 flex-col">
          <div className="nice-scroll min-h-0 flex-1 space-y-5 overflow-y-auto px-5 py-4">
            {/* ——— identity: avatar + name + email + phone ——— */}
            <section>
              <SectionLabel icon="id-card">{t("teamSectionIdentity")}</SectionLabel>
              <div className="mb-4 flex flex-wrap items-center gap-4 rounded-2xl border border-slate-200/80 bg-slate-50/60 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
                <AvatarPicker
                  avatarUrl={avatar}
                  name={name.trim() || t("teamFieldAvatar")}
                  c1={g.c1}
                  c2={g.c2}
                  size="lg"
                  disabled={saving}
                  onPick={(dataUrl) => setAvatar(dataUrl)}
                  onRemove={avatar ? () => setAvatar("") : undefined}
                />
                <div className="min-w-0 flex-1">
                  <p className="text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
                    {t("teamFieldAvatar")}
                  </p>
                  <p className="mt-0.5 flex items-start gap-1.5 text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                    <CatIcon name="badge-check" className="mt-0.5 h-3 w-3 shrink-0 text-emerald-500" />
                    {t("teamAvatarHint")}
                  </p>
                </div>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <Label htmlFor="tm-name" className={WZ_LABEL}>
                    {t("teamName")} <span className="text-rose-500">*</span>
                  </Label>
                  <Input
                    id="tm-name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={t("teamNamePh")}
                    className={cn(WZ_INPUT, invalid.name && "border-rose-400 focus-visible:ring-rose-500/20")}
                    aria-invalid={invalid.name || undefined}
                    autoComplete="off"
                  />
                </div>
                <div>
                  <Label htmlFor="tm-email" className={WZ_LABEL}>
                    {t("teamEmail")} <span className="text-rose-500">*</span>
                  </Label>
                  <Input
                    id="tm-email"
                    type="email"
                    dir="ltr"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder={t("teamEmailPh")}
                    className={cn(WZ_INPUT, lang === "ar" ? "text-end" : "text-start", invalid.email && "border-rose-400 focus-visible:ring-rose-500/20")}
                    aria-invalid={invalid.email || undefined}
                    autoComplete="off"
                  />
                </div>
                {/* R163 — second-language identity lines (bilingual teams):
                    lifted to the TOP of the identity grid so they sit directly
                    ABOVE the phone row, per the owner's directive. They are
                    direction-aware — an Arabic UI enters ENGLISH values
                    (dir="ltr", English placeholders), any other UI enters
                    ARABIC values (dir="rtl", Arabic placeholders). */}
                <div className="sm:col-span-2">
                  <p className="mb-2.5 flex items-center gap-1.5 text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                    <CatIcon name="languages" className="h-3 w-3 shrink-0" aria-hidden="true" />
                    <span className="truncate">{t("teamSectionAltLang")}</span>
                    <span className="min-w-0 flex-1 border-t border-dashed border-slate-200 dark:border-white/10" aria-hidden="true" />
                  </p>
                  <p className="mb-2.5 text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                    {t("teamAltLangHint")}
                  </p>
                </div>
                <div>
                  <Label htmlFor="tm-name-alt" className={WZ_LABEL}>
                    {t("teamFieldNameAlt")}
                  </Label>
                  <Input
                    id="tm-name-alt"
                    dir={lang === "ar" ? "ltr" : "rtl"}
                    lang={lang === "ar" ? "en" : "ar"}
                    value={nameAlt}
                    onChange={(e) => setNameAlt(e.target.value)}
                    placeholder={t("teamFieldNameAltPh")}
                    className={cn(WZ_INPUT, "text-start")}
                    autoComplete="off"
                  />
                </div>
                <div>
                  <Label htmlFor="tm-job-alt" className={WZ_LABEL}>
                    {t("teamFieldJobTitleAlt")}
                  </Label>
                  <Input
                    id="tm-job-alt"
                    dir={lang === "ar" ? "ltr" : "rtl"}
                    lang={lang === "ar" ? "en" : "ar"}
                    value={jobTitleAlt}
                    onChange={(e) => setJobTitleAlt(e.target.value)}
                    placeholder={t("teamFieldJobTitleAltPh")}
                    className={cn(WZ_INPUT, "text-start")}
                    autoComplete="off"
                  />
                </div>
                <div className="sm:col-span-2">
                  <Label htmlFor="tm-phone" className={WZ_LABEL}>
                    {t("teamFieldPhone")}
                  </Label>
                  {/* ROUND 69 — phone field with FULL Arabic RTL support: the
                      Arabic placeholder (٠٥٥ ١٢٣ ٤٥٦٧) reads right-to-left and
                      aligns to the reading edge; typed digit runs render as a
                      single block in both directions. English keeps LTR. */}
                  <Input
                    id="tm-phone"
                    type="tel"
                    inputMode="tel"
                    dir={lang === "ar" ? "rtl" : "ltr"}
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder={t("teamFieldPhonePh")}
                    className={cn(WZ_INPUT, "text-start", invalid.phone && "border-rose-400 focus-visible:ring-rose-500/20")}
                    aria-invalid={invalid.phone || undefined}
                    autoComplete="off"
                  />
                  {invalid.phone ? (
                    <p className="mt-1.5 flex items-center gap-1.5 text-[11px] font-bold text-rose-500 dark:text-rose-400">
                      <CatIcon name="circle-alert" className="h-3 w-3" />
                      {t("teamErrPhone")}
                    </p>
                  ) : null}
                </div>
              </div>
            </section>

            {/* ——— role & position ——— */}
            <section>
              <SectionLabel icon="briefcase-business">{t("teamSectionRole")}</SectionLabel>
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <Label htmlFor="tm-role" className={WZ_LABEL}>
                    {t("teamRole")}
                  </Label>
                  <Select value={role} onValueChange={(v) => setRole(v as Role)}>
                    <SelectTrigger id="tm-role" className={WZ_INPUT}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectGroup>
                        {(Object.keys(ROLE_KEYS) as Role[]).map((r) => (
                          <SelectItem key={r} value={r}>
                            {t(ROLE_KEYS[r])}
                          </SelectItem>
                        ))}
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                  {/* ROUND 78 — live strict-RBAC preview under the role select:
                      the granted/total counter + the role's permission chips
                      (the SAME matrix the server enforces — permissions.ts). */}
                  <div className="mt-2.5 rounded-2xl border border-slate-200/80 bg-slate-50/70 p-2.5 dark:border-white/10 dark:bg-white/[0.03]">
                    <p className="flex items-center justify-between gap-2 text-[10.5px] font-extrabold text-slate-500 dark:text-slate-400">
                      <span className="flex min-w-0 items-center gap-1.5">
                        <CatIcon name="shield-check" className="h-3.5 w-3.5 shrink-0 text-emerald-500" />
                        <span className="truncate">{t("profPermsTitle")}</span>
                      </span>
                      <span className="shrink-0 rounded-full bg-emerald-100 px-2 py-0.5 tabular-nums text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
                        {t("teamPermCount", {
                          granted: fmtNum(permissionStats(role).granted, lang),
                          total: fmtNum(permissionStats(role).total, lang),
                        })}
                      </span>
                    </p>
                    <div className="mt-1.5 flex flex-wrap gap-1.5">
                      {PERMISSION_IDS.filter((p) => permissionsOf(role).includes(p))
                        .slice(0, 6)
                        .map((p) => (
                          <span
                            key={p}
                            className="inline-flex items-center gap-1 rounded-full border border-emerald-200/80 bg-white/80 px-1.5 py-0.5 text-[9px] font-extrabold text-emerald-700 dark:border-emerald-500/25 dark:bg-white/[0.05] dark:text-emerald-300"
                          >
                            <CatIcon name={PERMISSION_META[p].icon} className="h-2.5 w-2.5 shrink-0" />
                            {t(PERM_LABEL_KEYS[p])}
                          </span>
                        ))}
                      {permissionStats(role).granted > 6 ? (
                        <span className="inline-flex items-center rounded-full bg-emerald-100 px-1.5 py-0.5 text-[9px] font-extrabold tabular-nums text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
                          +{fmtNum(permissionStats(role).granted - 6, lang)}
                        </span>
                      ) : null}
                    </div>
                  </div>
                </div>
                <div>
                  <Label htmlFor="tm-job" className={WZ_LABEL}>
                    {t("teamFieldJobTitle")}
                  </Label>
                  <Input
                    id="tm-job"
                    value={jobTitle}
                    onChange={(e) => setJobTitle(e.target.value)}
                    placeholder={t("teamFieldJobTitlePh")}
                    className={WZ_INPUT}
                    autoComplete="off"
                  />
                </div>
              </div>
            </section>

            {/* ——— personal details ——— */}
            <section>
              <SectionLabel icon="cake">{t("teamSectionPersonal")}</SectionLabel>
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <Label htmlFor="tm-birth" className={WZ_LABEL}>
                    {t("teamFieldBirthDate")}
                  </Label>
                  {/* R163 — the shared premium date field (WZ rhythm): brand
                      calendar tile at the field's far right in Arabic, clear-X
                      + Arabic long-form hint built in. */}
                  <PremiumDateInput
                    id="tm-birth"
                    size="lg"
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    min="1900-01-01"
                    max="2100-12-31"
                  />
                </div>
                <div>
                  <Label htmlFor="tm-gender" className={WZ_LABEL}>
                    {t("teamFieldGender")}
                  </Label>
                  <Select
                    value={gender === "" ? "__none__" : gender}
                    onValueChange={(v) => setGender(v === "__none__" ? "" : (v as MemberGender))}
                  >
                    <SelectTrigger id="tm-gender" className={WZ_INPUT}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectGroup>
                        <SelectItem value="__none__">
                          <span className="flex items-center gap-2 text-slate-400">
                            <span className="h-2 w-2 rounded-full bg-slate-300 dark:bg-slate-600" aria-hidden="true" />
                            {t("teamUnsetInfo")}
                          </span>
                        </SelectItem>
                        <SelectItem value="male">{t("teamGenderMale")}</SelectItem>
                        <SelectItem value="female">{t("teamGenderFemale")}</SelectItem>
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </section>
          </div>

          {/* footer */}
          <div className="flex shrink-0 items-center justify-end gap-2.5 border-t border-slate-200/70 px-5 py-3.5 dark:border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={saving}
              className="h-10 rounded-xl px-4 text-[12.5px] font-bold hover:border-slate-300 hover:bg-slate-100 dark:hover:border-white/20 dark:hover:bg-white/5"
            >
              {t("modRecCancelBtn")}
            </Button>
            <Button
              type="submit"
              disabled={saving || (edit && !anyDirty)}
              className="h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:opacity-60"
              style={{ backgroundImage: grad(g.c1, g.c2) }}
            >
              {saving ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name={edit ? "check" : "user-plus"} className="h-4 w-4" />
              )}
              {edit ? t("profileSave") : t("teamAddBtn")}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default TeamMemberDialog;
