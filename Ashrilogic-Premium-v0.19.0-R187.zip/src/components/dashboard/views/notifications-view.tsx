"use client";

/**
 * Dashboard — Notifications view (ROUND 143 → ROUND 144): the specialized,
 * premium notification center that replaces the old «التقارير» page across
 * all 102 systems. ONE unified feed merges every BUSINESS notification
 * family the platform emits — member signups, storefront orders, payments,
 * subscription renewals, package purchases, add-ons store purchases and
 * wallet movements (top-ups, debits and inter-wallet transfers) — into a
 * single grouped, searchable, expandable timeline:
 *
 * ROUND 144 (owner directive: «صفحة الإشعارات لا يجب أن يكون فيه إشعارات
 * النظام أبداً») — SYSTEM notifications are REMOVED ENTIRELY: the activities
 * feed is filtered to business kinds BEFORE merging, counting or announcing
 * (actCreated / actLogin / actBackup / actSettingsUpdated / actDataImported /
 * actReportGenerated / actReportExported / actSiteLaunched / actExit /
 * actTrashed / actRestored / actPurged / actModuleEnabled / actModuleDisabled
 * and every other non-business kind NEVER becomes a notification), the system
 * source pill is gone, and every KPI counts ONLY the surviving merged list.
 *
 *  · KPI strip  — total / unread / today / last-7-days golden StatCards.
 *  · Toolbar    — source filter chips (semantic per-source gradients) +
 *                 Arabic-safe search + mark-all-read + client-side CSV.
 *  · Timeline   — Today / Yesterday / This week / Earlier groups of
 *                 expandable premium cards (rich collapsed summaries,
 *                 full detail grids + deep-links when open), sticky group
 *                 headers inside a bounded live scroll area.
 *
 * Unread semantics ride the SAME localStorage mark the topbar bell uses
 * (`ashrilogic-notif-read-<instanceId>`) — marking all read here silences
 * the bell too. The activities feed is keyset-paginated (load-more) with a
 * 20-second live poll; the money/entitlement sources poll at 30s staleTime.
 */
import { Fragment, useEffect, useMemo, useRef, useState } from "react";
import type { CSSProperties, ReactNode } from "react";
import { useInfiniteQuery, useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { useT, type I18nKey } from "@/lib/i18n";
import type {
  ActivityDTO,
  ActivityKind,
  AddonOrderDTO,
  DashView,
  InstanceDTO,
  Lang,
  PlanOrderDTO,
  SiteOrderAdminDTO,
  WalletTopupDTO,
  WalletTxnDTO,
} from "@/lib/types";
import {
  fetchActivitiesPage,
  fetchAddonCatalog,
  fetchInstanceOrders,
  fetchPlanOrders,
  fetchWallet,
} from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, hexAlpha, labelTrack, normalizeSearch } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { StatCard } from "@/components/shared/stat-card";
import {
  ACT_STYLE,
  DashCard,
  ViewHeading,
  fullDate,
  relativeTime,
} from "@/components/dashboard/dash-shared";
import { useAccentPair } from "@/components/dashboard/accent-context";
import { useAppStore } from "@/lib/store";

/* ================================================================== */
/* Unified notification model                                          */
/* ================================================================== */

type NotifSource =
  | "members"
  | "orders"
  | "payments"
  | "renewals"
  | "packages"
  | "addons"
  | "wallet";

/** Superset status vocabulary: the payment lifecycle (pending/paid/cancelled/
 *  expired) + the storefront order queue statuses (confirmed/preparing/
 *  ready/completed). */
type NotifStatus =
  | "pending"
  | "paid"
  | "cancelled"
  | "expired"
  | "confirmed"
  | "preparing"
  | "ready"
  | "completed";

type NotifCycle = "monthly" | "yearly";

/** Deep-link targets (dashboard views reachable from a notification). */
type NotifViewTarget = Extract<DashView, "store" | "billing" | "addons" | "team">;

interface UnifiedNotif {
  key: string;
  source: NotifSource;
  icon: string;
  c1: string;
  c2: string;
  titleKey: I18nKey;
  amountMajor?: number;
  currency?: string;
  /** wallet-kind only: true = credit (emerald), false = debit (rose) */
  credit?: boolean;
  customerName?: string;
  orderCode?: string | null;
  itemsCount?: number;
  pkgName?: string;
  cycle?: NotifCycle;
  featuresCount?: number;
  reference?: string;
  methodLabel?: string;
  status?: NotifStatus;
  note?: string;
  createdAt: string;
  view?: NotifViewTarget;
  /** activity-derived rows render t(kind) as the bold title and the source
   *  label as a small category chip (non-activity titles ARE the source). */
  fromActivity?: boolean;
  /** actWalletTransfer only: the inter-wallet direction + counterparty
   *  (out → to org + walletNo, in → from actor). */
  transfer?: {
    direction: "in" | "out";
    org?: string;
    actor?: string;
    walletNo?: string;
  };
}

/* ---------------- per-source semantic tile styles ---------------- */

const SOURCE_META: Record<
  NotifSource,
  { icon: string; c1: string; c2: string; filterKey: I18nKey; sourceKey: I18nKey }
> = {
  members: { icon: "users", c1: "#8b5cf6", c2: "#7c3aed", filterKey: "notifFilterMembers", sourceKey: "notifSourceMembers" },
  orders: { icon: "shopping-bag", c1: "#10b981", c2: "#047857", filterKey: "notifFilterOrders", sourceKey: "notifSourceOrders" },
  payments: { icon: "credit-card", c1: "#06b6d4", c2: "#0891b2", filterKey: "notifFilterPayments", sourceKey: "notifSourcePayments" },
  renewals: { icon: "refresh-cw", c1: "#f59e0b", c2: "#d97706", filterKey: "notifFilterRenewals", sourceKey: "notifSourceRenewals" },
  packages: { icon: "crown", c1: "#d946ef", c2: "#c026d3", filterKey: "notifFilterPackages", sourceKey: "notifSourcePackages" },
  addons: { icon: "puzzle", c1: "#0ea5e9", c2: "#0284c7", filterKey: "notifFilterAddons", sourceKey: "notifSourceAddons" },
  wallet: { icon: "wallet", c1: "#059669", c2: "#0f766e", filterKey: "notifFilterWallet", sourceKey: "notifSourceWallet" },
};

const SOURCES: NotifSource[] = [
  "members",
  "orders",
  "payments",
  "renewals",
  "packages",
  "addons",
  "wallet",
];

/* ---------------- status + cycle + deep-link vocabularies ---------------- */

const STATUS_META: Record<NotifStatus, { labelKey: I18nKey; className: string }> = {
  pending: { labelKey: "notifStatusPending", className: "bg-amber-50 text-amber-600 dark:bg-amber-500/10 dark:text-amber-400" },
  paid: { labelKey: "notifStatusPaid", className: "bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400" },
  completed: { labelKey: "ordStatusCompleted", className: "bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400" },
  confirmed: { labelKey: "ordStatusConfirmed", className: "bg-cyan-50 text-cyan-600 dark:bg-cyan-500/10 dark:text-cyan-400" },
  preparing: { labelKey: "ordStatusPreparing", className: "bg-violet-50 text-violet-600 dark:bg-violet-500/10 dark:text-violet-400" },
  ready: { labelKey: "ordStatusReady", className: "bg-teal-50 text-teal-600 dark:bg-teal-500/10 dark:text-teal-400" },
  cancelled: { labelKey: "notifStatusCancelled", className: "bg-slate-100 text-slate-500 dark:bg-white/10 dark:text-slate-400" },
  expired: { labelKey: "notifStatusExpired", className: "bg-rose-50 text-rose-600 dark:bg-rose-500/10 dark:text-rose-400" },
};

const CYCLE_KEY: Record<NotifCycle, I18nKey> = {
  monthly: "notifPkgCycleMonthly",
  yearly: "notifPkgCycleYearly",
};

const VIEW_KEY: Record<NotifViewTarget, I18nKey> = {
  store: "notifViewOrder",
  billing: "notifViewBilling",
  addons: "notifViewAddons",
  team: "notifViewTeam",
};

const VIEW_ICON: Record<NotifViewTarget, string> = {
  store: "shopping-bag",
  billing: "credit-card",
  addons: "puzzle",
  team: "users",
};

/* ---------------- timeline groups ---------------- */

type GroupKey = "today" | "yesterday" | "thisWeek" | "earlier";

const GROUP_LABEL: Record<GroupKey, I18nKey> = {
  today: "notifGroupToday",
  yesterday: "notifGroupYesterday",
  thisWeek: "notifGroupThisWeek",
  earlier: "notifGroupEarlier",
};

function dayGroup(iso: string): GroupKey {
  const at = new Date(iso);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  const weekAgo = new Date(today);
  weekAgo.setDate(today.getDate() - 6);
  if (at >= today) return "today";
  if (at >= yesterday) return "yesterday";
  if (at >= weekAgo) return "thisWeek";
  return "earlier";
}

/* ---------------- activity-kind classification ---------------- */

/** ROUND 144 — the ONLY activity kinds that become notifications are the
 *  BUSINESS families (members / orders / payments / wallet). Every other
 *  kind is system noise and returns null — those rows are dropped before
 *  merging, counting, filtering or announcing. The Notifications page
 * NEVER contains system notifications. */
function sourceForKind(kind: ActivityKind): NotifSource | null {
  switch (kind) {
    case "actUserAdded":
    case "actUserRemoved":
      return "members";
    case "actOrderReceived":
    case "actReviewReceived":
    case "actInquiryReceived":
      return "orders";
    case "actInvoiceCreated":
    case "actCouponCreated":
      return "payments";
    /* ROUND 168 (منح المحفظة) — grant credits join the wallet family: the
     * Super-Admin bulk goodwill credit + the new-subscriber welcome gift. */
    case "actWalletTopup":
    case "actWalletDebit":
    case "actWalletTransfer":
    case "actWalletGrant":
    case "actWalletWelcome":
      return "wallet";
    default:
      return null;
  }
}

function viewForKind(kind: ActivityKind): NotifViewTarget | undefined {
  switch (kind) {
    case "actUserAdded":
      return "team";
    case "actOrderReceived":
      return "store";
    default:
      return undefined;
  }
}

/* ---------------- source mappers (DTO → UnifiedNotif) ---------------- */

/** meta values are strings — parse defensively, never leak NaN. */
function toNumber(v: string | undefined): number | undefined {
  if (v === undefined || v === "") return undefined;
  const n = Number(v);
  return Number.isFinite(n) ? n : undefined;
}

function activityNotif(a: ActivityDTO, lang: Lang): UnifiedNotif | null {
  /* ROUND 144 — the business-kind gate: system-ish activities never
   * become notifications (they are dropped right here). */
  const source = sourceForKind(a.kind);
  if (source === null) return null;
  const style = ACT_STYLE[a.kind];
  const meta = a.meta ?? {};
  const walletEvent =
    a.kind === "actWalletTopup" || a.kind === "actWalletDebit";
  /* ROUND 168 — grant kinds are CREDITS (emerald money tint) whose meta
   * carries the note (the admin's grant note / the bilingual welcome
   * message) for the expanded detail panel. */
  const grantEvent = a.kind === "actWalletGrant" || a.kind === "actWalletWelcome";
  /* ROUND 144 — inter-wallet transfer: the meta carries the direction +
   * counterparty (out → { amount, currency, direction:"out", reference,
   * to: org, walletNo }, in → { amount, currency, direction:"in",
   * reference, from: actor, note }). */
  const transfer =
    a.kind === "actWalletTransfer"
      ? {
          direction: meta.direction === "in" ? ("in" as const) : ("out" as const),
          org: meta.to,
          actor: meta.from,
          walletNo: meta.walletNo,
        }
      : undefined;
  const pkgName =
    meta.plan ??
    (lang === "ar" ? meta.packageAr || meta.package : meta.package);
  return {
    key: `activity-${a.id}`,
    source,
    /* activity-derived rows keep their ACT_STYLE tile identity; only the
     * SOURCE classification is unified (the mandate's override rule). */
    icon: style.icon,
    c1: style.c1,
    c2: style.c2,
    titleKey: a.kind,
    amountMajor: toNumber(meta.total) ?? toNumber(meta.amount),
    currency: meta.currency,
    credit: transfer
      ? transfer.direction === "in"
      : walletEvent
        ? a.kind === "actWalletTopup"
        : grantEvent
          ? true
          : undefined,
    transfer,
    customerName: meta.name,
    orderCode: meta.code ?? null,
    itemsCount: toNumber(meta.items),
    pkgName,
    cycle: meta.cycle === "monthly" || meta.cycle === "yearly" ? meta.cycle : undefined,
    reference: meta.reference,
    note: transfer || grantEvent ? meta.note || undefined : undefined,
    createdAt: a.createdAt,
    view: viewForKind(a.kind),
    fromActivity: true,
  };
}

function siteOrderNotif(o: SiteOrderAdminDTO): UnifiedNotif {
  const meta = SOURCE_META.orders;
  return {
    key: `order-${o.id}`,
    source: "orders",
    icon: meta.icon,
    c1: meta.c1,
    c2: meta.c2,
    titleKey: meta.sourceKey,
    amountMajor: o.total,
    currency: o.currency,
    customerName: o.customerName,
    orderCode: o.code,
    itemsCount: o.items.length,
    status: o.status,
    note: o.note ?? undefined,
    createdAt: o.createdAt,
    view: "store",
  };
}

function planOrderNotif(p: PlanOrderDTO, isRenewal: boolean, lang: Lang): UnifiedNotif {
  const meta = SOURCE_META[isRenewal ? "renewals" : "packages"];
  return {
    key: `plan-${p.id}`,
    source: isRenewal ? "renewals" : "packages",
    icon: meta.icon,
    c1: meta.c1,
    c2: meta.c2,
    titleKey: meta.sourceKey,
    /* ROUND 166 — PlanOrder.amount is integer MINOR units → ÷100 at the
     *  display boundary only (the walletTxnNotif idiom) */
    amountMajor: p.amount / 100,
    currency: p.currency,
    pkgName: lang === "ar" && p.packageNameAr ? p.packageNameAr : p.packageName,
    cycle: p.cycle,
    reference: p.reference,
    methodLabel: p.methodLabel,
    status: p.effectiveStatus,
    createdAt: p.createdAt,
    view: "billing",
  };
}

function addonOrderNotif(a: AddonOrderDTO): UnifiedNotif {
  const meta = SOURCE_META.addons;
  return {
    key: `addon-${a.id}`,
    source: "addons",
    icon: meta.icon,
    c1: meta.c1,
    c2: meta.c2,
    titleKey: meta.sourceKey,
    /* ROUND 166 — AddonOrder.amount is integer MINOR units → ÷100 */
    amountMajor: a.amount / 100,
    currency: a.currency,
    featuresCount: a.features.length,
    cycle: a.cycle,
    reference: a.reference,
    methodLabel: a.methodLabel,
    status: a.effectiveStatus,
    createdAt: a.createdAt,
    view: "addons",
  };
}

function walletTxnNotif(tx: WalletTxnDTO): UnifiedNotif {
  const meta = SOURCE_META.wallet;
  return {
    key: `wtxn-${tx.id}`,
    source: "wallet",
    icon: meta.icon,
    c1: meta.c1,
    c2: meta.c2,
    titleKey: meta.sourceKey,
    /* minor → major at the display boundary only */
    amountMajor: Math.abs(Math.round(tx.amountMinor)) / 100,
    currency: "SAR",
    credit: tx.amountMinor > 0,
    reference: tx.reference,
    note: tx.note || undefined,
    createdAt: tx.createdAt,
  };
}

function walletTopupNotif(tp: WalletTopupDTO): UnifiedNotif {
  const meta = SOURCE_META.wallet;
  return {
    key: `wtop-${tp.id}`,
    source: "wallet",
    icon: meta.icon,
    c1: meta.c1,
    c2: meta.c2,
    titleKey: meta.sourceKey,
    amountMajor: Math.round(tp.amountMinor) / 100,
    currency: tp.currency,
    credit: true,
    reference: tp.reference,
    methodLabel: tp.methodLabel,
    status: tp.effectiveStatus,
    createdAt: tp.createdAt,
  };
}

/* ================================================================== */
/* Money text (dir-locked latin currency, wallet credit/debit tinting) */
/* ================================================================== */

function MoneyText({ n, lang }: { n: UnifiedNotif; lang: Lang }) {
  if (n.amountMajor === undefined) return null;
  const tint =
    n.source === "wallet"
      ? n.credit === true
        ? "text-emerald-600 dark:text-emerald-400"
        : n.credit === false
          ? "text-rose-600 dark:text-rose-400"
          : ""
      : "";
  const sign = n.source === "wallet" ? (n.credit === true ? "+" : n.credit === false ? "−" : "") : "";
  return (
    <span dir="ltr" className={cn("tabular-nums font-extrabold", tint)}>
      {sign}
      {fmtNum(n.amountMajor, lang)} {n.currency}
    </span>
  );
}

/* ================================================================== */
/* One expandable notification card                                    */
/* ================================================================== */

function NotifRow({
  n,
  index,
  open,
  unread,
  onToggle,
  lang,
  t,
  onGo,
}: {
  n: UnifiedNotif;
  index: number;
  open: boolean;
  unread: boolean;
  onToggle: () => void;
  lang: Lang;
  t: (key: I18nKey, vars?: Record<string, string | number>) => string;
  onGo: (view: NotifViewTarget) => void;
}) {
  const src = SOURCE_META[n.source];

  /* collapsed rich summary — dot-joined text segments, then chips.
   * ROUND 144 — transfer rows lead with the direction chip + the
   * counterparty (t("notifTransferTo", { org }) on out / t("notifTransferFrom",
   * { actor }) on in) before the dir-locked money + reference. */
  const segments: ReactNode[] = [];
  if (n.transfer) {
    const isIn = n.transfer.direction === "in";
    segments.push(
      <span
        key="tdir"
        className={cn(
          "inline-flex shrink-0 items-center rounded-full px-2 py-px text-[9.5px] font-extrabold",
          isIn
            ? "bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400"
            : "bg-rose-50 text-rose-600 dark:bg-rose-500/10 dark:text-rose-400",
        )}
      >
        {isIn ? t("notifTransferIn") : t("notifTransferOut")}
      </span>,
    );
    if (isIn && n.transfer.actor) {
      segments.push(
        <span key="tfrom" dir="auto" className="max-w-[150px] truncate">
          {t("notifTransferFrom", { actor: n.transfer.actor })}
        </span>,
      );
    }
    if (!isIn && n.transfer.org) {
      segments.push(
        <span key="tto" dir="auto" className="max-w-[150px] truncate">
          {t("notifTransferTo", { org: n.transfer.org })}
        </span>,
      );
    }
    if (!isIn && n.transfer.walletNo) {
      segments.push(
        <span key="twno" dir="ltr" className="font-mono text-[9px] text-slate-400 dark:text-slate-500">
          {n.transfer.walletNo}
        </span>,
      );
    }
  }
  if (n.amountMajor !== undefined) segments.push(<MoneyText key="money" n={n} lang={lang} />);
  if (n.customerName) {
    segments.push(
      <span key="cust" dir="auto" className="max-w-[150px] truncate">
        {n.customerName}
      </span>,
    );
  }
  if (n.pkgName) {
    segments.push(
      <span key="pkg" dir="auto" className="max-w-[150px] truncate">
        {n.pkgName}
      </span>,
    );
  }
  if (n.itemsCount !== undefined) {
    segments.push(
      <span key="items" dir="ltr" className="tabular-nums">
        × {fmtNum(n.itemsCount, lang)}
      </span>,
    );
  }
  if (n.featuresCount !== undefined) {
    segments.push(
      <span key="feats" dir="ltr" className="tabular-nums">
        × {fmtNum(n.featuresCount, lang)}
      </span>,
    );
  }
  if (n.reference) {
    segments.push(
      <span key="ref" dir="ltr" className="font-mono text-[9px] text-slate-400 dark:text-slate-500">
        {n.reference}
      </span>,
    );
  }

  /* expanded detail grid cell */
  const field = (labelKey: I18nKey, value: ReactNode) => (
    <div className="min-w-0">
      <dt className={cn("text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
        {t(labelKey)}
      </dt>
      <dd className="mt-0.5 truncate text-[12px] font-bold text-slate-700 dark:text-slate-200">{value}</dd>
    </div>
  );

  return (
    <li className="card-in" style={{ "--i": Math.min(index, 14) } as CSSProperties}>
      <div
        className={cn(
          "rounded-2xl transition-colors duration-200",
          open ? "bg-slate-50 dark:bg-white/[0.04]" : "hover:bg-slate-50 dark:hover:bg-white/5",
        )}
      >
        {/* collapsed row — a real button (keyboard-accessible expansion) */}
        <button
          type="button"
          onClick={onToggle}
          aria-expanded={open}
          aria-label={`${t(n.titleKey)}${n.customerName ? ` — ${n.customerName}` : ""}`}
          className="flex w-full items-center gap-3 rounded-2xl p-3 text-start transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-500/60"
        >
          <span
            className="relative grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-sm"
            style={{ backgroundImage: grad(n.c1, n.c2) }}
          >
            <CatIcon name={n.icon} className="h-[13px] w-[13px]" />
            {unread ? (
              <span
                className="absolute -end-0.5 -top-0.5 h-2.5 w-2.5 rounded-full bg-brand-500 ring-2 ring-white dark:ring-[#101828]"
                aria-hidden="true"
              />
            ) : null}
          </span>

          <span className="min-w-0 flex-1">
            <span className="flex flex-wrap items-center gap-1.5">
              <span className="truncate text-[12.5px] font-bold text-slate-800 dark:text-slate-100">
                {t(n.titleKey)}
              </span>
              {n.fromActivity ? (
                <span
                  className="inline-flex shrink-0 items-center rounded-full px-2 py-px text-[9px] font-extrabold"
                  style={{ backgroundColor: hexAlpha(src.c1, 0.12), color: src.c1 }}
                >
                  {t(src.sourceKey)}
                </span>
              ) : null}
            </span>
            {segments.length > 0 || n.cycle || n.status ? (
              <span className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-[10.5px] font-semibold text-slate-500 dark:text-slate-400">
                {segments.map((seg, i) => (
                  <Fragment key={i}>
                    {i > 0 ? (
                      <span aria-hidden="true" className="text-slate-300 dark:text-slate-600">
                        ·
                      </span>
                    ) : null}
                    {seg}
                  </Fragment>
                ))}
                {n.cycle ? (
                  <span className="inline-flex items-center rounded-full border border-slate-200 bg-slate-50 px-2 py-px text-[9.5px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-400">
                    {t(CYCLE_KEY[n.cycle])}
                  </span>
                ) : null}
                {n.status ? (
                  <span
                    className={cn(
                      "inline-flex items-center rounded-full px-2 py-px text-[9.5px] font-extrabold",
                      STATUS_META[n.status].className,
                    )}
                  >
                    {t(STATUS_META[n.status].labelKey)}
                  </span>
                ) : null}
              </span>
            ) : null}
          </span>

          <span className="flex shrink-0 items-center gap-1.5 self-start pt-0.5">
            <span className="whitespace-nowrap text-[10px] font-bold text-slate-400 dark:text-slate-500">
              {relativeTime(n.createdAt, lang)}
            </span>
            <CatIcon
              name="chevron-down"
              className={cn("h-3.5 w-3.5 shrink-0 text-slate-400 transition-transform duration-300", open && "rotate-180")}
            />
          </span>
        </button>

        {/* expanded panel — full detail grid + note + deep-link */}
        {open ? (
          <div className="border-t border-dashed border-slate-200 px-3 pb-3.5 pt-3 dark:border-white/10">
            <dl className="grid grid-cols-2 gap-x-4 gap-y-3">
              {n.orderCode
                ? field(
                    "notifOrderCode",
                    <span dir="ltr" className="font-mono">
                      {n.orderCode}
                    </span>,
                  )
                : null}
              {n.customerName
                ? field(
                    "notifOrderCustomer",
                    <span dir="auto" className="truncate">
                      {n.customerName}
                    </span>,
                  )
                : null}
              {n.itemsCount !== undefined
                ? field(
                    "notifOrderItems",
                    <span dir="ltr" className="tabular-nums">
                      × {fmtNum(n.itemsCount, lang)}
                    </span>,
                  )
                : null}
              {n.featuresCount !== undefined
                ? field(
                    "notifOrderItems",
                    <span dir="ltr" className="tabular-nums">
                      × {fmtNum(n.featuresCount, lang)}
                    </span>,
                  )
                : null}
              {n.amountMajor !== undefined
                ? field(n.source === "orders" ? "notifOrderTotal" : "notifAmountLabel", <MoneyText n={n} lang={lang} />)
                : null}
              {n.pkgName
                ? field(
                    "metaKeyPackage",
                    <span className="flex min-w-0 items-center gap-1.5">
                      <span dir="auto" className="truncate">
                        {n.pkgName}
                      </span>
                      {n.cycle ? (
                        <span className="inline-flex shrink-0 items-center rounded-full border border-slate-200 bg-slate-50 px-2 py-px text-[9px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-400">
                          {t(CYCLE_KEY[n.cycle])}
                        </span>
                      ) : null}
                    </span>,
                  )
                : null}
              {n.methodLabel
                ? field(
                    "notifMethodLabel",
                    <span dir="auto" className="truncate">
                      {n.methodLabel}
                    </span>,
                  )
                : null}
              {n.reference
                ? field(
                    "payReference",
                    <span dir="ltr" className="font-mono">
                      {n.reference}
                    </span>,
                  )
                : null}
            </dl>

            {n.note ? (
              <p
                className="mt-3 rounded-xl bg-slate-50 px-3 py-2 text-[11px] font-semibold leading-relaxed text-slate-500 dark:bg-white/5 dark:text-slate-400"
                dir="auto"
              >
                {n.note}
              </p>
            ) : null}

            <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
              <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                {fullDate(n.createdAt, lang)}
              </p>
              {(() => {
                /* capture the narrowed value — TS cannot narrow a mutable
                   property across the callback boundary */
                const view = n.view;
                if (!view) return null;
                return (
                  <Button
                    type="button"
                    onClick={() => onGo(view)}
                    className="h-9 gap-1.5 rounded-xl px-4 text-[11.5px] font-extrabold"
                  >
                    <CatIcon name={VIEW_ICON[view]} className="h-3.5 w-3.5" />
                    {t(VIEW_KEY[view])}
                  </Button>
                );
              })()}
            </div>
          </div>
        ) : null}
      </div>
    </li>
  );
}

/* ================================================================== */
/* View                                                                */
/* ================================================================== */

const PAGE_SIZE = 20;
const READ_PREFIX = "ashrilogic-notif-read-";

export function NotificationsView({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const { c1, c2 } = useAccentPair();
  const setDashView = useAppStore((s) => s.setDashView);

  const [search, setSearch] = useState("");
  const [sourceFilter, setSourceFilter] = useState<NotifSource | "all">("all");
  const [openKeys, setOpenKeys] = useState<Set<string>>(new Set());

  /* Unread mark — the SAME key family the topbar bell writes
   * (marking all read here silences the bell as well). */
  const readKey = `${READ_PREFIX}${instance.id}`;
  const [lastRead, setLastRead] = useState<number>(() => {
    if (typeof window === "undefined") return 0;
    const stored = Number(localStorage.getItem(readKey) ?? "0");
    return Number.isFinite(stored) && stored > 0 ? stored : 0;
  });

  /* ---------------- data queries ---------------- */

  /* activities — keyset-paginated live feed (20s poll) */
  const feed = useInfiniteQuery({
    queryKey: ["activities-feed", instance.id, "notifications", PAGE_SIZE],
    queryFn: ({ pageParam }) =>
      fetchActivitiesPage(instance.id, { limit: PAGE_SIZE, cursor: pageParam }),
    initialPageParam: null as string | null,
    getNextPageParam: (lastPage) => lastPage.nextCursor,
    staleTime: 20_000,
    refetchInterval: 20_000,
    retry: 0,
  });

  const ordersQuery = useQuery({
    queryKey: ["orders", instance.id, "notifications"],
    queryFn: () => fetchInstanceOrders(instance.id, { limit: 12 }),
    staleTime: 30_000,
    retry: 0,
  });

  const planQuery = useQuery({
    queryKey: ["plan-orders", instance.id],
    queryFn: () => fetchPlanOrders(instance.id),
    staleTime: 30_000,
    retry: 0,
  });

  const addonQuery = useQuery({
    queryKey: ["addon-catalog", instance.id],
    queryFn: () => fetchAddonCatalog(instance.id),
    staleTime: 30_000,
    retry: 0,
  });

  const walletQuery = useQuery({
    queryKey: ["wallet", instance.id],
    queryFn: () => fetchWallet(instance.id),
    staleTime: 30_000,
    retry: 0,
  });

  const activities = useMemo(
    () => feed.data?.pages.flatMap((p) => p.activities) ?? [],
    [feed.data],
  );
  const serverTotal = feed.data?.pages[0]?.total ?? 0;

  /* ROUND 144 — the activities feed may carry system rows (logins, backups,
   * settings, reports, trash…): those NEVER become notifications. The feed
   * is filtered to business kinds BEFORE merging / counting / announcing —
   * every KPI and the live-arrival toast see only the surviving rows. */
  const businessActivities = useMemo(
    () => activities.filter((a) => sourceForKind(a.kind) !== null),
    [activities],
  );

  /* ---------------- unified merge (deduped by key, newest first) ---------------- */

  const merged = useMemo<UnifiedNotif[]>(() => {
    const byKey = new Map<string, UnifiedNotif>();

    for (const a of businessActivities) {
      const n = activityNotif(a, lang);
      if (n) byKey.set(n.key, n);
    }

    for (const o of ordersQuery.data?.orders ?? []) byKey.set(`order-${o.id}`, siteOrderNotif(o));

    /* plan orders: oldest-first pass — the FIRST paid order per package is
     * the purchase, every subsequent paid order the renewal; pending /
     * cancelled requests classify as purchase attempts. */
    const plans = [...(planQuery.data ?? [])].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    const paidSeen = new Set<string>();
    for (const p of plans) {
      const isRenewal = p.status === "paid" && paidSeen.has(p.packageId);
      if (p.status === "paid") paidSeen.add(p.packageId);
      byKey.set(`plan-${p.id}`, planOrderNotif(p, isRenewal, lang));
    }

    for (const a of addonQuery.data?.orders ?? []) byKey.set(`addon-${a.id}`, addonOrderNotif(a));

    for (const tx of walletQuery.data?.txns ?? []) byKey.set(`wtxn-${tx.id}`, walletTxnNotif(tx));

    /* only the LIVE pending top-up requests are actionable notifications */
    for (const tp of walletQuery.data?.topups ?? []) {
      if (tp.effectiveStatus === "pending") byKey.set(`wtop-${tp.id}`, walletTopupNotif(tp));
    }

    return [...byKey.values()].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }, [businessActivities, ordersQuery.data, planQuery.data, addonQuery.data, walletQuery.data, lang]);

  /* ---------------- KPI stats (over the merged feed) ---------------- */

  const stats = useMemo(() => {
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const weekStart = Date.now() - 7 * 86_400_000;
    let today = 0;
    let week = 0;
    let unread = 0;
    for (const n of merged) {
      const ts = new Date(n.createdAt).getTime();
      if (ts >= todayStart.getTime()) today += 1;
      if (ts >= weekStart) week += 1;
      if (ts > lastRead) unread += 1;
    }
    return { today, week, unread };
  }, [merged, lastRead]);

  const sourceCounts = useMemo(() => {
    const counts = new Map<NotifSource, number>();
    for (const n of merged) counts.set(n.source, (counts.get(n.source) ?? 0) + 1);
    return counts;
  }, [merged]);

  /* ---------------- toolbar filtering ---------------- */

  const q = normalizeSearch(search.trim());
  const visible = useMemo(() => {
    let list = merged;
    if (sourceFilter !== "all") list = list.filter((n) => n.source === sourceFilter);
    if (q) {
      list = list.filter((n) =>
        normalizeSearch(
          [
            t(n.titleKey),
            t(SOURCE_META[n.source].sourceKey),
            n.customerName ?? "",
            n.reference ?? "",
            n.pkgName ?? "",
            n.note ?? "",
            n.orderCode ?? "",
            n.transfer?.org ?? "",
            n.transfer?.actor ?? "",
          ].join(" "),
        ).includes(q),
      );
    }
    return list;
  }, [merged, sourceFilter, q, t]);

  /* ---------------- timeline groups ---------------- */

  const groups = useMemo(() => {
    const buckets: Record<GroupKey, UnifiedNotif[]> = { today: [], yesterday: [], thisWeek: [], earlier: [] };
    for (const n of visible) buckets[dayGroup(n.createdAt)].push(n);
    return (["today", "yesterday", "thisWeek", "earlier"] as const)
      .filter((key) => buckets[key].length > 0)
      .map((key) => ({ key, label: t(GROUP_LABEL[key]), items: buckets[key] }));
  }, [visible, t]);

  /* ---------------- live toast on new arrivals ---------------- */

  /* ROUND 144 — the baseline follows the BUSINESS feed only: a system
   * activity arriving must never announce "new notifications". */
  const newestActivityId = businessActivities.length > 0 ? businessActivities[0].id : null;
  const baseline = useRef<string | null>(null);
  useEffect(() => {
    const signature = newestActivityId ? `${instance.id}:${newestActivityId}` : null;
    if (signature === null) return;
    if (baseline.current === null) {
      baseline.current = signature;
      return;
    }
    if (signature !== baseline.current) {
      baseline.current = signature;
      toast(t("notifNewToast"));
    }
  }, [newestActivityId, instance.id, t]);

  /* ---------------- actions ---------------- */

  const toggleOpen = (key: string) => {
    setOpenKeys((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const markAllRead = () => {
    const now = Date.now();
    try {
      localStorage.setItem(readKey, String(now));
    } catch {
      /* private mode — the in-memory mark still applies for this session */
    }
    setLastRead(now);
    toast.success(t("notifReadAll"));
  };

  /* client-side CSV of the VISIBLE items (BOM + RFC-style quoting) */
  const exportCsv = () => {
    if (visible.length === 0) return;
    const esc = (v: unknown) => {
      const s = String(v ?? "");
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const rows = [
      ["time", "source", "title", "amount", "currency", "status", "reference"],
      ...visible.map((n) => [
        n.createdAt,
        n.source,
        t(n.titleKey),
        n.amountMajor !== undefined ? String(n.amountMajor) : "",
        n.currency ?? "",
        n.status !== undefined ? t(STATUS_META[n.status].labelKey) : "",
        n.reference ?? "",
      ]),
    ];
    const csv = rows.map((r) => r.map(esc).join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `notifications-${instance.id.slice(0, 8)}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success(t("adminExportDone"));
  };

  const go = (view: NotifViewTarget) => setDashView(view);

  const anyPending =
    feed.isPending ||
    ordersQuery.isPending ||
    planQuery.isPending ||
    addonQuery.isPending ||
    walletQuery.isPending;

  /* ---------------- render ---------------- */

  return (
    <div className="space-y-5">
      {/* heading + LIVE pulsing badge */}
      <div className="relative">
        <ViewHeading title={t("dashNotificationsTitle")} desc={t("dashNotificationsDesc")} />
        <span
          title={t("notifLiveOn")}
          className="absolute end-0 top-0 inline-flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-2.5 py-1 text-[10px] font-extrabold text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400"
        >
          <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-500" aria-hidden="true" />
          {t("notifLiveBadge")}
        </span>
      </div>

      {/* KPI strip — golden inventory-page cards. ROUND 144 — every count
          (total / unread / today / last-7) is computed over the merged
          BUSINESS-only list: the raw server total (which includes system
          rows) is never displayed as the notifications total. */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-4">
        <StatCard
          size="golden"
          label={t("notifKpiTotal")}
          value={feed.isError ? "—" : undefined}
          numeric={feed.isError ? undefined : merged.length}
          icon="bell"
          c1={c1}
          c2={c2}
          index={0}
          loading={merged.length === 0 && anyPending}
        />
        <StatCard
          size="golden"
          label={t("notifKpiUnread")}
          value={feed.isError ? "—" : undefined}
          numeric={feed.isError ? undefined : stats.unread}
          icon="inbox"
          c1="#f59e0b"
          c2="#d97706"
          index={1}
          loading={merged.length === 0 && anyPending}
        />
        <StatCard
          size="golden"
          label={t("notifKpiToday")}
          value={feed.isError ? "—" : undefined}
          numeric={feed.isError ? undefined : stats.today}
          icon="calendar"
          c1="#10b981"
          c2="#047857"
          index={2}
          tone={stats.today > 0 ? "up" : "flat"}
          loading={merged.length === 0 && anyPending}
        />
        <StatCard
          size="golden"
          label={t("notifKpiLast7")}
          value={feed.isError ? "—" : undefined}
          numeric={feed.isError ? undefined : stats.week}
          icon="clock-rotate-left"
          c1="#06b6d4"
          c2="#0891b2"
          index={3}
          loading={merged.length === 0 && anyPending}
        />
      </div>

      {/* toolbar — source chips + search + mark-all-read + CSV export */}
      <div className="glass-card card-in rounded-3xl p-4 sm:p-5">
        <div
          className="nice-scroll -mx-1 flex items-center gap-2 overflow-x-auto px-1 pb-1"
          role="group"
          aria-label={t("dashNotificationsTitle")}
        >
          <button
            type="button"
            aria-pressed={sourceFilter === "all"}
            onClick={() => setSourceFilter("all")}
            className={cn(
              "inline-flex shrink-0 items-center gap-1.5 rounded-full border px-3.5 py-2 text-[11px] font-extrabold transition active:scale-95",
              sourceFilter === "all"
                ? "border-transparent text-white shadow-md"
                : "border-slate-200 bg-white/70 text-slate-600 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:text-brand-300",
            )}
            style={sourceFilter === "all" ? { backgroundImage: grad(c1, c2) } : undefined}
          >
            <CatIcon name="bell" className="h-3 w-3" />
            {t("notifFilterAll")}
            <span
              className={cn(
                "rounded-full px-1.5 py-px text-[9.5px] font-extrabold tabular-nums",
                sourceFilter === "all" ? "bg-white/25 text-white" : "bg-slate-100 text-slate-500 dark:bg-white/10 dark:text-slate-400",
              )}
            >
              {fmtNum(merged.length, lang)}
            </span>
          </button>
          {SOURCES.map((source) => {
            const meta = SOURCE_META[source];
            const active = sourceFilter === source;
            return (
              <button
                key={source}
                type="button"
                aria-pressed={active}
                onClick={() => setSourceFilter(active ? "all" : source)}
                className={cn(
                  "inline-flex shrink-0 items-center gap-1.5 rounded-full border px-3.5 py-2 text-[11px] font-extrabold transition active:scale-95",
                  active
                    ? "border-transparent text-white shadow-md"
                    : "border-slate-200 bg-white/70 text-slate-600 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:text-brand-300",
                )}
                style={active ? { backgroundImage: grad(meta.c1, meta.c2) } : undefined}
              >
                <CatIcon name={meta.icon} className="h-3 w-3" />
                {t(meta.filterKey)}
                <span
                  className={cn(
                    "rounded-full px-1.5 py-px text-[9.5px] font-extrabold tabular-nums",
                    active ? "bg-white/25 text-white" : "bg-slate-100 text-slate-500 dark:bg-white/10 dark:text-slate-400",
                  )}
                >
                  {fmtNum(sourceCounts.get(source) ?? 0, lang)}
                </span>
              </button>
            );
          })}
        </div>

        <div className="mt-3 flex flex-col gap-2.5 sm:flex-row sm:items-center">
          <div className="relative min-w-0 flex-1">
            <CatIcon
              name="search"
              className="pointer-events-none absolute start-3.5 top-1/2 h-[13px] w-[13px] -translate-y-1/2 text-slate-400"
            />
            <Input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t("notifSearchPh")}
              aria-label={t("notifSearchPh")}
              className="h-10 rounded-xl border-slate-200 bg-slate-50/80 ps-10 pe-3 text-[12.5px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:placeholder:text-slate-500 dark:focus:bg-white/[0.07]"
            />
          </div>

          <div className="flex shrink-0 items-center gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={markAllRead}
              disabled={stats.unread === 0}
              aria-label={t("notifMarkAllRead")}
              title={t("notifMarkAllRead")}
              className="h-10 flex-1 gap-2 rounded-xl border-slate-200 bg-white px-4 text-[12px] font-extrabold text-slate-700 shadow-none transition hover:border-brand-300 hover:text-brand-600 active:scale-95 disabled:opacity-40 sm:flex-none dark:border-white/10 dark:bg-transparent dark:text-slate-200 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
            >
              <CatIcon name="check-check" className="h-4 w-4" />
              <span className="hidden sm:inline">{t("notifMarkAllRead")}</span>
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={exportCsv}
              disabled={visible.length === 0}
              aria-label={t("notifExportCsv")}
              title={t("notifExportCsv")}
              className="h-10 flex-1 gap-2 rounded-xl border-slate-200 bg-white px-4 text-[12px] font-extrabold text-slate-700 shadow-none transition hover:border-brand-300 hover:text-brand-600 active:scale-95 disabled:opacity-40 sm:flex-none dark:border-white/10 dark:bg-transparent dark:text-slate-200 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
            >
              <CatIcon name="download" className="h-4 w-4" />
              <span className="hidden sm:inline">{t("notifExportCsv")}</span>
            </Button>
          </div>
        </div>
      </div>

      {/* grouped timeline feed */}
      <DashCard>
        {/* live count announcement for assistive tech */}
        <p className="sr-only" aria-live="polite">
          {t("notifKpiTotal")}: {fmtNum(visible.length, lang)}
        </p>

        {merged.length === 0 && anyPending ? (
          <div className="space-y-1.5" aria-hidden="true">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3 rounded-2xl p-3">
                <Skeleton className="h-10 w-10 rounded-xl" />
                <div className="flex-1 space-y-1.5">
                  <Skeleton className="h-3.5 w-44" />
                  <Skeleton className="h-2.5 w-28" />
                </div>
                <Skeleton className="h-2.5 w-16" />
              </div>
            ))}
          </div>
        ) : feed.isError && merged.length === 0 ? (
          <div className="py-10 text-center">
            <p className="text-[13px] font-bold text-rose-600 dark:text-rose-400">{t("errorText")}</p>
            <Button
              variant="outline"
              onClick={() => void feed.refetch()}
              className="mt-3 h-10 rounded-xl px-5 text-[12.5px] font-bold"
            >
              <CatIcon name="refresh-cw" className="h-4 w-4" />
              {t("retryText")}
            </Button>
          </div>
        ) : merged.length === 0 ? (
          <div className="py-12 text-center">
            <span
              className="mx-auto grid h-14 w-14 place-items-center rounded-2xl text-white shadow-lg"
              style={{ backgroundImage: grad(c1, c2) }}
            >
              <CatIcon name="inbox" className="h-6 w-6" />
            </span>
            <h3 className="mt-4 font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
              {t("notifEmptyTitle")}
            </h3>
            <p className="mx-auto mt-1 max-w-sm text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("notifEmptyDesc")}
            </p>
          </div>
        ) : visible.length === 0 ? (
          <div className="py-10 text-center">
            <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
              <CatIcon name="search" className="h-5 w-5" />
            </div>
            <p className="mt-3 text-[12.5px] font-bold text-slate-500 dark:text-slate-400">
              {t("notifEmptyFilter")}
            </p>
          </div>
        ) : (
          <div
            className="nice-scroll max-h-96 overflow-y-auto pe-1 [contain:content]"
            role="log"
            aria-label={t("dashNotificationsTitle")}
          >
            {groups.map((group) => (
              <section key={group.key} aria-label={group.label}>
                {/* sticky group header */}
                <div className="sticky top-0 z-20 flex items-center gap-2 bg-white/85 px-1 py-2 backdrop-blur-sm dark:bg-[#101828]/90">
                  <h3
                    className={cn(
                      "text-[10.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500",
                      labelTrack(lang),
                    )}
                  >
                    {group.label}
                  </h3>
                  <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-extrabold tabular-nums text-slate-500 dark:bg-white/10 dark:text-slate-400">
                    {fmtNum(group.items.length, lang)}
                  </span>
                  <span className="h-px flex-1 bg-slate-100 dark:bg-white/[0.06]" aria-hidden="true" />
                </div>

                <ol className="space-y-1.5 pb-2">
                  {group.items.map((n, i) => (
                    <NotifRow
                      key={n.key}
                      n={n}
                      index={i}
                      open={openKeys.has(n.key)}
                      unread={new Date(n.createdAt).getTime() > lastRead}
                      onToggle={() => toggleOpen(n.key)}
                      lang={lang}
                      t={t}
                      onGo={go}
                    />
                  ))}
                </ol>
              </section>
            ))}

            {/* keyset load-more (stable under concurrent inserts) */}
            {feed.hasNextPage ? (
              <div className="flex flex-col items-center gap-2 border-t border-dashed border-slate-200 pb-1 pt-4 dark:border-white/10">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => void feed.fetchNextPage()}
                  disabled={feed.isFetchingNextPage}
                  className="h-10 gap-2 rounded-xl border-slate-200 bg-white px-6 text-[12.5px] font-extrabold text-slate-600 shadow-none transition hover:border-brand-300 hover:text-brand-600 active:scale-95 disabled:opacity-60 dark:border-white/10 dark:bg-transparent dark:text-slate-200 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
                >
                  <CatIcon
                    name="chevron-down"
                    className={cn("h-4 w-4 transition-transform", feed.isFetchingNextPage && "animate-bounce")}
                  />
                  {feed.isFetchingNextPage ? t("actLoadingMore") : t("notifLoadMore")}
                </Button>
                <p className="text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                  {t("actLoadedHint", {
                    loaded: fmtNum(activities.length, lang),
                    total: fmtNum(serverTotal, lang),
                  })}
                </p>
              </div>
            ) : (
              <div className="flex items-center justify-center gap-2 border-t border-dashed border-slate-200 pt-3 dark:border-white/10">
                <span className="h-1.5 w-1.5 rounded-full bg-slate-300 dark:bg-white/20" aria-hidden="true" />
                <p className="text-[10.5px] font-extrabold text-slate-400 dark:text-slate-500">
                  {t("actEndOfFeed")}
                </p>
                <span className="h-1.5 w-1.5 rounded-full bg-slate-300 dark:bg-white/20" aria-hidden="true" />
              </div>
            )}
          </div>
        )}
      </DashCard>
    </div>
  );
}
