"use client";

/**
 * ROUND 78 — the NEW premium member / system-owner PROFILE.
 *
 * The product owner ordered the OLD profile dialogs deleted and a brand-new
 * professional, attractive, Premium profile built in their place. This is
 * that rebuild: the previous TeamProfileDialog (centered dialog, ROUND 69)
 * is gone; profiles now open as a full-height SIDE SHEET sliding from the
 * reading-flow END edge (left in RTL Arabic, right in LTR) — the WhatsApp
 * Business / Linear detail-panel pattern, which reads far more premium on
 * a roster surface and keeps the roster visible behind it.
 *
 * Design language (all NEW artwork, same platform vocabulary):
 *  - a tall role-gradient COVER with layered radial light accents, a soft
 *    diagonal hairline texture and a large faded role-icon watermark —
 *    plus the live status chip (owner / new / active) with a soft pulse;
 *  - a triple-ringed overlapping avatar (the member's photo, changeable
 *    in place through the UNIFIED AvatarPicker pipeline → PATCH member);
 *  - identity block: name, role badge (gold crown for the owner), job
 *    title chip, LTR email, DATE-ONLY localized "member since" line;
 *  - a PERMISSION SUMMARY BAR — granted/total ring + the role's headline
 *    permission chips: the sheet is wired to the REAL permission engine
 *    (src/lib/permissions.ts — the same matrix the server enforces);
 *  - contact card (email + phone inset rows with copy actions);
 *  - personal details grid (birth DATE-ONLY + computed age, gender glyph,
 *    joined date + relative stamp) as gradient-icon tiles;
 *  - EFFECTIVE PERMISSIONS — the full 14-permission catalog grouped by
 *    domain (insights / operations / people / governance), every row a
 *    granted-check or denied-lock chip with its one-line description;
 *  - sticky quick-action footer: edit details, copy email, resend invite,
 *    remove (delegates to the roster's AlertDialog flow).
 *
 * RTL LAW: Arabic text and Arabic-Indic dates flow natively RTL; only
 * genuinely Latin payloads (email, phone digits) stay LTR and align to
 * the reading edge. Anti-overlap: identity rows are flex-wrap shrink-0
 * chip + min-w-0 truncate text.
 */
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { SYSTEM_MAP, teamDisplayName } from "@/data/catalog";
import { useT, type I18nKey } from "@/lib/i18n";
import type { InstanceDTO, TeamMemberDTO } from "@/lib/types";
import { updateMember } from "@/lib/api-client";
import {
  PERMISSION_GROUPS,
  PERMISSION_IDS,
  PERMISSION_META,
  permissionsOf,
  permissionStats,
  type MemberRole,
  type PermissionId,
  type WorkspaceRole,
} from "@/lib/permissions";
import { CatIcon } from "@/components/icon";
import { cn, copyText, fmtNum, grad, initial } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { dateOnly, relativeTime } from "@/components/dashboard/dash-shared";
import { AvatarPicker } from "@/components/dashboard/avatar-picker";

/** owner subject handed in by the team view (instance.admin + createdAt) */
export type TeamOwnerProfile = {
  name: string;
  email: string;
  avatarUrl?: string | null;
  joinedAt: string;
};

const ROLE_KEYS: Record<MemberRole, I18nKey> = {
  manager: "roleManager",
  staff: "roleStaff",
  viewer: "roleViewer",
};

const ROLE_BADGE: Record<MemberRole, string> = {
  manager: "bg-brand-500/15 text-brand-600 hover:bg-brand-500/15 dark:text-brand-300",
  staff: "bg-amber-500/15 text-amber-600 hover:bg-amber-500/15 dark:text-amber-400",
  viewer: "bg-slate-500/15 text-slate-600 hover:bg-slate-500/15 dark:text-slate-300",
};

/** per-role avatar + cover gradients (owner = royal gold) */
const ROLE_GRAD: Record<MemberRole, { c1: string; c2: string }> = {
  manager: { c1: "#8b5cf6", c2: "#6d28d9" },
  staff: { c1: "#06b6d4", c2: "#0891b2" },
  viewer: { c1: "#64748b", c2: "#475569" },
};
const OWNER_GRAD = { c1: "#f59e0b", c2: "#d97706" };

/* ROUND 78 — permission i18n wiring (labels + one-line descriptions) */
const PERM_LABEL: Record<PermissionId, I18nKey> = {
  "overview.view": "permOverviewView",
  "activity.view": "permActivityView",
  "exports.run": "permExportsRun",
  "modules.view": "permModulesView",
  "modules.edit": "permModulesEdit",
  "inventory.manage": "permInventoryManage",
  "orders.manage": "permOrdersManage",
  "support.manage": "permSupportManage",
  "customers.view": "permCustomersView",
  "team.view": "permTeamView",
  "team.manage": "permTeamManage",
  "website.manage": "permWebsiteManage",
  "billing.manage": "permBillingManage",
  "settings.manage": "permSettingsManage",
};
const PERM_DESC: Record<PermissionId, I18nKey> = {
  "overview.view": "permDescOverviewView",
  "activity.view": "permDescActivityView",
  "exports.run": "permDescExportsRun",
  "modules.view": "permDescModulesView",
  "modules.edit": "permDescModulesEdit",
  "inventory.manage": "permDescInventoryManage",
  "orders.manage": "permDescOrdersManage",
  "support.manage": "permDescSupportManage",
  "customers.view": "permDescCustomersView",
  "team.view": "permDescTeamView",
  "team.manage": "permDescTeamManage",
  "website.manage": "permDescWebsiteManage",
  "billing.manage": "permDescBillingManage",
  "settings.manage": "permDescSettingsManage",
};
const GROUP_LABEL: Record<(typeof PERMISSION_GROUPS)[number], I18nKey> = {
  insights: "permGroupInsights",
  operations: "permGroupOperations",
  people: "permGroupPeople",
  governance: "permGroupGovernance",
};
const GROUP_ICON: Record<(typeof PERMISSION_GROUPS)[number], string> = {
  insights: "chart-line",
  operations: "cubes",
  people: "users-round",
  governance: "shield-check",
};

/** Age (whole years) from a birth date — null when missing/invalid. */
function computeAge(birthDate: string): number | null {
  if (!birthDate) return null;
  const birth = new Date(`${birthDate}T00:00:00`);
  if (Number.isNaN(birth.getTime())) return null;
  return Math.floor((Date.now() - birth.getTime()) / (365.2425 * 86_400_000));
}

/* ---------------- granted / denied chips (engine-driven) ---------------- */

function PermChip({ ok, size = "md" }: { ok: boolean; size?: "sm" | "md" }) {
  return (
    <span
      aria-hidden="true"
      className={cn(
        "grid shrink-0 place-items-center rounded-full transition-transform",
        size === "md" ? "h-7 w-7" : "h-5 w-5",
        ok
          ? "bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400"
          : "bg-slate-100 text-slate-300 dark:bg-white/5 dark:text-slate-600"
      )}
    >
      <CatIcon name={ok ? "check" : "lock"} className={size === "md" ? "h-4 w-4" : "h-3 w-3"} />
    </span>
  );
}

/** granted-share ring — the permission summary bar's gauge. */
function PermRing({ pct, label }: { pct: number; label: string }) {
  const R = 20;
  const C = 2 * Math.PI * R;
  return (
    <div className="relative grid h-14 w-14 shrink-0 place-items-center">
      <svg viewBox="0 0 48 48" className="h-full w-full -rotate-90" aria-hidden="true">
        <circle cx="24" cy="24" r={R} fill="none" strokeWidth="5" className="stroke-slate-100 dark:stroke-white/10" />
        <circle
          cx="24"
          cy="24"
          r={R}
          fill="none"
          strokeWidth="5"
          strokeLinecap="round"
          stroke="url(#profPermRingGrad)"
          strokeDasharray={C}
          strokeDashoffset={C * (1 - pct)}
          className="transition-[stroke-dashoffset] duration-700 ease-out"
        />
        <defs>
          <linearGradient id="profPermRingGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#10b981" />
            <stop offset="100%" stopColor="#14b8a6" />
          </linearGradient>
        </defs>
      </svg>
      <span className="absolute text-[10.5px] font-extrabold tabular-nums text-slate-800 dark:text-white">
        {label}
      </span>
    </div>
  );
}

/** One contact row — truncate + shrink-0 copy button can never overlap. */
function ContactRow({
  icon,
  iconTone,
  label,
  value,
  dirLtr,
  onCopy,
  copyLabel,
  lang,
}: {
  icon: string;
  iconTone: string;
  label: string;
  value: string;
  dirLtr: boolean;
  onCopy?: () => void;
  copyLabel: string;
  lang: string;
}) {
  return (
    <div className="flex items-center gap-2.5 rounded-xl px-2 py-2 transition-colors hover:bg-slate-100/70 dark:hover:bg-white/[0.05]">
      <span className={cn("grid h-8 w-8 shrink-0 place-items-center rounded-lg", iconTone)} aria-hidden="true">
        <CatIcon name={icon} className="h-4 w-4" />
      </span>
      <span className="w-16 shrink-0 text-[11px] font-extrabold text-slate-400 dark:text-slate-500">{label}</span>
      <p
        dir={dirLtr ? "ltr" : undefined}
        className={cn(
          "min-w-0 flex-1 truncate text-[12.5px] font-bold text-slate-700 dark:text-slate-200",
          dirLtr && (lang === "ar" ? "text-end" : "text-start")
        )}
        title={value}
      >
        {value}
      </p>
      {onCopy ? (
        <button
          type="button"
          onClick={onCopy}
          aria-label={copyLabel}
          title={copyLabel}
          className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-brand-300 hover:bg-brand-50 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:bg-brand-500/10 dark:hover:text-brand-300"
        >
          <CatIcon name="copy" className="h-3.5 w-3.5" />
        </button>
      ) : null}
    </div>
  );
}

/** One personal-details tile — gradient icon chip + DATE-ONLY value. */
function DetailTile({
  icon,
  c1,
  c2,
  label,
  children,
}: {
  icon: string;
  c1: string;
  c2: string;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="min-w-0 rounded-2xl border border-slate-200/80 bg-slate-50/60 p-3 transition-colors hover:border-slate-300/80 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-white/20">
      <p className="flex items-center gap-1.5 text-[11px] font-extrabold text-slate-400 dark:text-slate-500">
        <span
          className="grid h-5 w-5 shrink-0 place-items-center rounded-md text-white"
          style={{ backgroundImage: grad(c1, c2) }}
          aria-hidden="true"
        >
          <CatIcon name={icon} className="h-3 w-3" />
        </span>
        {label}
      </p>
      {children}
    </div>
  );
}

/* ------------------------------- sheet ------------------------------- */

export function MemberProfileSheet({
  open,
  onOpenChange,
  member,
  owner,
  instance,
  onRequestRemove,
  onRequestEdit,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  member: TeamMemberDTO | null;
  owner: TeamOwnerProfile | null;
  instance: InstanceDTO;
  /** members only — delegates to the roster's existing remove confirmation */
  onRequestRemove?: (member: TeamMemberDTO) => void;
  /** members only — opens the extended add/edit dialog prefilled */
  onRequestEdit?: (member: TeamMemberDTO) => void;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();

  /* direct member-photo change (UNIFIED AvatarPicker → PATCH) */
  const saveAvatar = useMutation({
    mutationFn: (avatarUrl: string | null) => {
      const target = member;
      if (!target) throw new Error("No member selected");
      return updateMember(instance.id, target.id, { avatarUrl });
    },
    onSuccess: (_data, avatarUrl) => {
      toast.success(t(avatarUrl ? "teamAvatarSavedToast" : "teamAvatarRemovedToast"));
      void queryClient.invalidateQueries({ queryKey: ["instance", instance.id] });
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  /* normalize the two subjects into one shape (member wins when both set) */
  const subject = member
    ? {
        kind: "member" as const,
        name: member.name,
        email: member.email,
        avatarUrl: member.avatarUrl,
        phone: member.phone,
        jobTitle: member.jobTitle,
        birthDate: member.birthDate,
        gender: member.gender,
        /* Task 2-b — second-language identity lines (owner subject → "") */
        nameAlt: member.nameAlt,
        jobTitleAlt: member.jobTitleAlt,
        joinedAt: member.createdAt,
        role: member.role as WorkspaceRole,
        member,
        isNew: Date.now() - new Date(member.createdAt).getTime() < 14 * 86_400_000,
      }
    : owner
      ? {
          kind: "owner" as const,
          name: owner.name,
          email: owner.email,
          avatarUrl: owner.avatarUrl ?? "",
          phone: "",
          jobTitle: "",
          nameAlt: "",
          jobTitleAlt: "",
          birthDate: "",
          gender: "" as const,
          joinedAt: owner.joinedAt,
          role: "owner" as const,
          member: null,
          isNew: false,
        }
      : null;

  if (!subject) return null;

  const isOwner = subject.kind === "owner";
  const g = isOwner ? OWNER_GRAD : ROLE_GRAD[subject.role as MemberRole];
  const granted = permissionsOf(subject.role);
  const grantedSet = new Set<PermissionId>(granted);
  const stats = permissionStats(subject.role);
  const pctLabel = `${fmtNum(Math.round((stats.granted / stats.total) * 100), lang)}٪`;

  const system = SYSTEM_MAP[instance.systemId];
  const systemName = system ? (lang === "ar" ? system.nameAr : system.nameEn) : instance.systemId;
  const teamLabel = teamDisplayName(instance.systemId, lang);

  const copyEmail = () => {
    copyText(subject.email).then(
      () => toast.success(t("teamEmailCopied")),
      () => toast.error(t("errorText"))
    );
  };

  const copyPhone = () => {
    if (!subject.phone) return;
    copyText(subject.phone).then(
      () => toast.success(t("teamPhoneCopied")),
      () => toast.error(t("errorText"))
    );
  };

  /* demo action — mirrors the roster's resend affordance */
  const resendInvite = () => toast.success(t("teamInviteSent"));

  const age = computeAge(subject.birthDate);

  /* role watermark icon for the cover */
  const roleIcon = isOwner ? "crown" : subject.role === "manager" ? "shield-check" : subject.role === "staff" ? "zap-fast" : "circle-check";

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        dir={lang === "ar" ? "rtl" : "ltr"}
        /* slide from the reading-flow END edge: left in Arabic, right in LTR */
        side={lang === "ar" ? "left" : "right"}
        className="flex w-full flex-col gap-0 overflow-hidden border-slate-200/80 bg-white p-0 shadow-2xl dark:border-white/10 dark:bg-[#0b1120] sm:max-w-md"
      >
        {/* ——— COVER ——— role gradient, layered light, hairline texture,
            giant faded role watermark + live status + system chips */}
        <div
          className="relative h-36 shrink-0 overflow-hidden"
          style={{ backgroundImage: grad(g.c1, g.c2) }}
        >
          {/* soft diagonal hairline texture */}
          <span
            aria-hidden="true"
            className="absolute inset-0 opacity-[0.16]"
            style={{
              backgroundImage:
                "repeating-linear-gradient(115deg, rgba(255,255,255,.5) 0 1px, transparent 1px 14px)",
            }}
          />
          {/* layered radial light accents */}
          <span
            aria-hidden="true"
            className="absolute -end-10 -top-16 h-36 w-36 rounded-full"
            style={{ background: "radial-gradient(circle, rgba(255,255,255,0.35), transparent 70%)" }}
          />
          <span
            aria-hidden="true"
            className="absolute -bottom-20 -start-8 h-40 w-40 rounded-full"
            style={{ background: "radial-gradient(circle, rgba(255,255,255,0.22), transparent 70%)" }}
          />
          {/* giant faded role watermark */}
          <CatIcon
            name={roleIcon}
            className="absolute -bottom-6 end-5 h-28 w-28 text-white/15"
            aria-hidden="true"
          />
          {/* team/system chip */}
          <span className="absolute start-4 top-3 inline-flex min-w-0 items-center gap-1.5 rounded-full border border-white/30 bg-black/25 px-2.5 py-1 text-[10.5px] font-extrabold text-white backdrop-blur-sm">
            <CatIcon name={isOwner ? "crown" : "shield-check"} className="h-3 w-3 shrink-0" />
            <span className="max-w-[220px] truncate">
              {teamLabel} · {systemName}
            </span>
          </span>
          {/* live status chip */}
          <span className="absolute end-4 top-3 inline-flex shrink-0 items-center gap-1.5 rounded-full border border-white/30 bg-black/25 px-2.5 py-1 text-[10.5px] font-extrabold text-white backdrop-blur-sm">
            <span className="relative flex h-1.5 w-1.5" aria-hidden="true">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-white opacity-60" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-white" />
            </span>
            {isOwner ? t("teamStatusChipOwner") : subject.isNew ? t("teamStatusChipNew") : t("teamStatusChipActive")}
          </span>
        </div>

        <SheetHeader className="space-y-0 text-start">
          {/* ——— identity strip ——— triple-ringed avatar overlapping the cover */}
          <div className="relative z-10 -mt-12 flex shrink-0 items-end gap-3.5 px-5">
            {subject.member ? (
              <span
                className="relative shrink-0 rounded-full ring-4 ring-white dark:ring-[#0b1120]"
                style={{ backgroundImage: grad(g.c1, g.c2) }}
              >
                <AvatarPicker
                  avatarUrl={subject.avatarUrl}
                  name={subject.name}
                  c1={g.c1}
                  c2={g.c2}
                  size="lg"
                  disabled={saveAvatar.isPending}
                  onPick={(dataUrl) => saveAvatar.mutate(dataUrl)}
                  onRemove={subject.avatarUrl ? () => saveAvatar.mutate(null) : undefined}
                />
              </span>
            ) : subject.avatarUrl ? (
              // eslint-disable-next-line @next/next/no-img-element -- sealed admin data-URL avatar (workspace's own admin record); next/image optimization does not apply
              <img
                src={subject.avatarUrl}
                alt=""
                className="h-20 w-20 shrink-0 rounded-full object-cover ring-4 ring-white dark:ring-[#0b1120]"
              />
            ) : (
              <span
                aria-hidden="true"
                className="grid h-20 w-20 shrink-0 place-items-center rounded-full text-[26px] font-extrabold text-white ring-4 ring-white dark:ring-[#0b1120]"
                style={{ backgroundImage: grad(g.c1, g.c2) }}
              >
                {initial(subject.name)}
              </span>
            )}
            <div className="min-w-0 flex-1 pb-1">
              <div className="flex flex-wrap items-center gap-2">
                <SheetTitle className="min-w-0 truncate font-display text-xl font-extrabold leading-tight text-slate-900 dark:text-white">
                  {subject.name}
                </SheetTitle>
                {isOwner ? (
                  <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-amber-500/15 px-2.5 py-0.5 text-[11px] font-extrabold text-amber-600 dark:text-amber-400">
                    <CatIcon name="crown" className="h-3 w-3" />
                    {t("teamOwnerBadge")}
                  </span>
                ) : (
                  <Badge className={`${ROLE_BADGE[subject.role as MemberRole]} shrink-0 text-[10.5px]`}>
                    {t(ROLE_KEYS[subject.role as MemberRole])}
                  </Badge>
                )}
                {subject.jobTitle ? (
                  <span className="inline-flex min-w-0 items-center gap-1 rounded-full border border-slate-200 bg-slate-50 px-2 py-0.5 text-[10.5px] font-extrabold text-slate-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300">
                    <CatIcon name="briefcase-business" className="h-3 w-3 shrink-0 text-slate-400" />
                    <span className="max-w-[130px] truncate">{subject.jobTitle}</span>
                  </span>
                ) : null}
              </div>
              {/* Task 2-b — second-language identity lines (bilingual teams):
                  muted auto-dir secondary lines under the primary values */}
              {subject.nameAlt ? (
                <p className="mt-0.5 truncate text-[12px] font-semibold text-slate-400 dark:text-slate-500">
                  <span dir="auto">{subject.nameAlt}</span>
                </p>
              ) : null}
              {subject.jobTitleAlt ? (
                <p className="mt-0.5 truncate text-[11px] font-semibold text-slate-400 dark:text-slate-500">
                  <span dir="auto">{subject.jobTitleAlt}</span>
                </p>
              ) : null}
              <SheetDescription className="mt-0.5 truncate text-[11.5px] font-semibold text-slate-500 dark:text-slate-400">
                {teamLabel} · <span dir="ltr">{subject.email}</span>
              </SheetDescription>
              {/* DATE-ONLY "since" line — anniversary dates never carry a clock */}
              <p className="mt-1 inline-flex items-center gap-1.5 text-[11px] font-bold text-slate-400 dark:text-slate-500">
                <CatIcon name="calendar" className="h-3 w-3 shrink-0" />
                {t(isOwner ? "teamOwnerSince" : "teamMemberSince", {
                  date: dateOnly(subject.joinedAt, lang),
                })}
              </p>
            </div>
          </div>
        </SheetHeader>

        {/* ——— permission summary bar ——— engine-driven gauge + headline chips */}
        <div className="mx-5 mt-4 flex shrink-0 items-center gap-3 rounded-2xl border border-emerald-200/70 bg-emerald-50/50 p-3 dark:border-emerald-500/20 dark:bg-emerald-500/[0.07]">
          <PermRing pct={stats.granted / stats.total} label={pctLabel} />
          <div className="min-w-0 flex-1">
            <p className="text-[12px] font-extrabold text-slate-800 dark:text-slate-100">
              {t("profPermsTitle")}
              <span className="ms-1.5 font-bold text-emerald-600 dark:text-emerald-400">
                {t("teamPermCount", {
                  granted: fmtNum(stats.granted, lang),
                  total: fmtNum(stats.total, lang),
                })}
              </span>
            </p>
            <p className="mt-0.5 truncate text-[10.5px] font-semibold text-slate-500 dark:text-slate-400">
              {t("profPermsDesc")}
            </p>
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              {granted.slice(0, 3).map((p) => (
                <span
                  key={p}
                  className="inline-flex items-center gap-1 rounded-full border border-emerald-200/80 bg-white/80 px-2 py-0.5 text-[9.5px] font-extrabold text-emerald-700 dark:border-emerald-500/25 dark:bg-white/[0.05] dark:text-emerald-300"
                >
                  <CatIcon name={PERMISSION_META[p].icon} className="h-2.5 w-2.5 shrink-0" />
                  {t(PERM_LABEL[p])}
                </span>
              ))}
              {stats.granted > 3 ? (
                <span className="inline-flex items-center rounded-full bg-emerald-100 px-2 py-0.5 text-[9.5px] font-extrabold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
                  +{fmtNum(stats.granted - 3, lang)}
                </span>
              ) : null}
            </div>
          </div>
        </div>

        {/* ——— scrollable body ——— */}
        <div className="nice-scroll min-h-0 flex-1 space-y-4 overflow-y-auto px-5 pb-4 pt-3">
          {/* contact card */}
          <section className="rounded-2xl border border-slate-200/80 bg-white/80 p-2 dark:border-white/10 dark:bg-white/[0.03]">
            <p className="px-2 pb-1 pt-1 text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              {t("profContactTitle")}
            </p>
            <ContactRow
              icon="at-sign"
              iconTone="bg-sky-500/10 text-sky-600 dark:bg-sky-500/15 dark:text-sky-400"
              label={t("teamEmail")}
              value={subject.email}
              dirLtr
              onCopy={copyEmail}
              copyLabel={t("teamCopyEmail")}
              lang={lang}
            />
            <ContactRow
              icon="phone"
              iconTone="bg-brand-500/10 text-brand-600 dark:bg-brand-500/15 dark:text-brand-300"
              label={t("teamFieldPhone")}
              value={subject.phone || "—"}
              dirLtr={subject.phone !== ""}
              onCopy={subject.phone ? copyPhone : undefined}
              copyLabel={t("teamCopyEmail")}
              lang={lang}
            />
          </section>

          {/* personal details grid */}
          <section>
            <p className="px-1 pb-2 text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              {t("profPersonalTitle")}
            </p>
            <div className="grid grid-cols-2 gap-2.5">
              <DetailTile icon="cake" c1="#10b981" c2="#059669" label={t("teamFieldBirthDate")}>
                {subject.birthDate ? (
                  <p className="mt-1 flex flex-wrap items-baseline gap-1.5">
                    <span className="text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                      {dateOnly(subject.birthDate, lang)}
                    </span>
                    {age !== null ? (
                      <span className="rounded-full bg-emerald-500/10 px-1.5 py-0.5 text-[10px] font-extrabold text-emerald-600 dark:text-emerald-400">
                        {t("teamAgeYears", { n: fmtNum(age, lang) })}
                      </span>
                    ) : null}
                  </p>
                ) : (
                  <p className="mt-1 text-[12px] font-semibold text-slate-300 dark:text-slate-600">—</p>
                )}
              </DetailTile>
              <DetailTile
                icon={subject.gender === "female" ? "venus" : "mars"}
                c1={subject.gender === "female" ? "#ec4899" : "#0ea5e9"}
                c2={subject.gender === "female" ? "#be185d" : "#0369a1"}
                label={t("teamFieldGender")}
              >
                <p className="mt-1 text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                  {subject.gender === "male"
                    ? t("teamGenderMale")
                    : subject.gender === "female"
                      ? t("teamGenderFemale")
                      : "—"}
                </p>
              </DetailTile>
              <DetailTile icon="calendar" c1="#8b5cf6" c2="#6d28d9" label={t("teamColJoined")}>
                <p className="mt-1 text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                  {dateOnly(subject.joinedAt, lang)}
                </p>
                <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                  {relativeTime(subject.joinedAt, lang)}
                </p>
              </DetailTile>
              <DetailTile icon="id-card" c1="#f59e0b" c2="#d97706" label={t("teamRole")}>
                <p className="mt-1 text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                  {isOwner ? t("teamOwnerBadge") : t(ROLE_KEYS[subject.role as MemberRole])}
                </p>
              </DetailTile>
            </div>
          </section>

          {/* ——— effective permissions ——— the full catalog, grouped */}
          <section>
            <p className="px-1 pb-2 text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              {t("profPermsTitle")}
            </p>
            <div className="space-y-2.5">
              {PERMISSION_GROUPS.map((group) => {
                const groupPerms = PERMISSION_IDS.filter((p) => PERMISSION_META[p].group === group);
                const groupGranted = groupPerms.filter((p) => grantedSet.has(p)).length;
                return (
                  <div
                    key={group}
                    className="overflow-hidden rounded-2xl border border-slate-200/80 bg-white/80 dark:border-white/10 dark:bg-white/[0.03]"
                  >
                    {/* group header */}
                    <div className="flex items-center justify-between gap-2 border-b border-slate-100 px-3 py-2 dark:border-white/[0.06]">
                      <span className="flex min-w-0 items-center gap-2 text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200">
                        <CatIcon name={GROUP_ICON[group]} className="h-3.5 w-3.5 shrink-0 text-brand-500" />
                        {t(GROUP_LABEL[group])}
                      </span>
                      <span className="shrink-0 rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-extrabold tabular-nums text-slate-500 dark:bg-white/[0.06] dark:text-slate-400">
                        {fmtNum(groupGranted, lang)}/{fmtNum(groupPerms.length, lang)}
                      </span>
                    </div>
                    {/* permission rows */}
                    <ul className="divide-y divide-slate-100 dark:divide-white/[0.05]">
                      {groupPerms.map((p) => {
                        const ok = grantedSet.has(p);
                        const meta = PERMISSION_META[p];
                        return (
                          <li
                            key={p}
                            className={cn(
                              "flex items-center gap-2.5 px-3 py-2 transition-colors",
                              ok ? "bg-emerald-50/40 dark:bg-emerald-500/[0.05]" : "opacity-70"
                            )}
                          >
                            <PermChip ok={ok} />
                            <span className="min-w-0 flex-1">
                              <span className="flex items-baseline justify-between gap-2">
                                <span className="truncate text-[12px] font-bold text-slate-700 dark:text-slate-200">
                                  {t(PERM_LABEL[p])}
                                </span>
                                <span
                                  className={cn(
                                    "shrink-0 text-[9.5px] font-extrabold",
                                    ok ? "text-emerald-600 dark:text-emerald-400" : "text-slate-400 dark:text-slate-500"
                                  )}
                                >
                                  {t(ok ? "teamPermGranted" : "teamPermDenied")}
                                </span>
                              </span>
                              <span className="mt-0.5 flex items-center gap-1.5">
                                <span
                                  className="grid h-4 w-4 shrink-0 place-items-center rounded text-white"
                                  style={{ backgroundImage: grad(meta.c1, meta.c2) }}
                                  aria-hidden="true"
                                >
                                  <CatIcon name={meta.icon} className="h-2.5 w-2.5" />
                                </span>
                                <span className="truncate text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                                  {t(PERM_DESC[p])}
                                </span>
                              </span>
                            </span>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                );
              })}
            </div>
          </section>
        </div>

        {/* ——— sticky quick actions footer ——— */}
        <div className="shrink-0 border-t border-slate-200/80 bg-white/95 p-3 backdrop-blur dark:border-white/10 dark:bg-[#0b1120]/95">
          <div className="flex items-center gap-2">
            <p className="me-auto hidden shrink-0 text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500 sm:block">
              {t("profActionsTitle")}
            </p>
            {subject.member ? (
              <>
                <Button
                  type="button"
                  onClick={() => onRequestEdit?.(subject.member as TeamMemberDTO)}
                  className="h-10 flex-1 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-4 text-[12px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
                >
                  <CatIcon name="pencil" className="h-4 w-4" />
                  {t("teamEditAction")}
                </Button>
                <button
                  type="button"
                  onClick={resendInvite}
                  aria-label={t("teamResendInvite")}
                  title={t("teamResendInvite")}
                  className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-slate-200 text-slate-500 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:text-slate-300 dark:hover:border-brand-500/40"
                >
                  <CatIcon name="telegram" className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  onClick={() => onRequestRemove?.(subject.member as TeamMemberDTO)}
                  aria-label={t("teamRemoveTitle")}
                  title={t("teamRemoveTitle")}
                  className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-slate-200 text-slate-400 transition hover:border-rose-300 hover:bg-rose-50 hover:text-rose-500 dark:border-white/10 dark:hover:border-rose-500/40 dark:hover:bg-rose-500/10 dark:hover:text-rose-400"
                >
                  <CatIcon name="user-minus" className="h-4 w-4" />
                </button>
              </>
            ) : (
              <Button
                type="button"
                onClick={copyEmail}
                className="h-10 flex-1 rounded-xl bg-linear-to-l from-amber-500 to-orange-500 px-4 text-[12px] font-extrabold text-white shadow-lg shadow-amber-500/25 transition hover:brightness-110 active:scale-95"
              >
                <CatIcon name="copy" className="h-4 w-4" />
                {t("teamCopyEmail")}
              </Button>
            )}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
