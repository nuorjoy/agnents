"use client";

/**
 * ROUND 78 — «الأدوار والصلاحيات» (Roles & Permissions) tab of the
 * فريق الإدارة page — the premium face of the strict RBAC engine.
 *
 * The product owner demanded a professional, Premium roles/permissions tab
 * inside the team page of EVERY system. This tab renders the LIVE matrix
 * from src/lib/permissions.ts (the single source of truth the SERVER
 * enforces on every /api/instances/[id]/* route) — never a hand-written
 * copy, so what the owner reads here is exactly what the server applies.
 *
 * Composition:
 *  - a server-enforcement banner (emerald, shield, pulse dot);
 *  - four ROLE CARDS (owner gold · manager violet · staff cyan · viewer
 *    slate): description, a granted/total permission progress bar, the
 *    live member count riding the roster, and a «معاينة كـ …» button that
 *    arms the dashboard-wide role-preview lens (the owner literally
 *    experiences the role's strictness — locked views carry the premium
 *    lock screen wired in dashboard-app);
 *  - the full MATRIX: 14 permissions × 4 roles, grouped by domain
 *    (insights / operations / people / governance) with group header rows,
 *    a description per permission, and granted-check / denied-lock chips;
 *  - the platform-tier note (Super Admin tiering on tenant surfaces).
 *
 * Exports PERM_LABEL_I18N / ROLE_NAME_I18N for the dashboard-app lock
 * screen (single i18n wiring across surfaces).
 */
import { Fragment } from "react";
import { useT, type I18nKey } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import type { TeamMemberDTO } from "@/lib/types";
import {
  PERMISSION_GROUPS,
  PERMISSION_IDS,
  PERMISSION_META,
  ROLE_MATRIX,
  WORKSPACE_ROLES,
  permissionStats,
  type PermissionId,
  type WorkspaceRole,
} from "@/lib/permissions";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { DashCard } from "@/components/dashboard/dash-shared";

/* ------------- i18n wiring (shared with the dashboard lock screen) ------------- */

export const PERM_LABEL_I18N: Record<PermissionId, I18nKey> = {
  "overview.view": "permOverviewView",
  "activity.view": "permActivityView",
  "exports.run": "permExportsRun",
  "modules.view": "permModulesView",
  "modules.edit": "permModulesEdit",
  "inventory.manage": "permInventoryManage",
  "orders.manage": "permOrdersManage",
  "support.manage": "permSupportManage",
  "customers.view": "permCustomersView",
  "team.view": "permTeamView",
  "team.manage": "permTeamManage",
  "website.manage": "permWebsiteManage",
  "billing.manage": "permBillingManage",
  "settings.manage": "permSettingsManage",
};

export const ROLE_NAME_I18N: Record<WorkspaceRole, I18nKey> = {
  owner: "teamOwnerBadge",
  manager: "roleManager",
  staff: "roleStaff",
  viewer: "roleViewer",
};

const PERM_DESC: Record<PermissionId, I18nKey> = {
  "overview.view": "permDescOverviewView",
  "activity.view": "permDescActivityView",
  "exports.run": "permDescExportsRun",
  "modules.view": "permDescModulesView",
  "modules.edit": "permDescModulesEdit",
  "inventory.manage": "permDescInventoryManage",
  "orders.manage": "permDescOrdersManage",
  "support.manage": "permDescSupportManage",
  "customers.view": "permDescCustomersView",
  "team.view": "permDescTeamView",
  "team.manage": "permDescTeamManage",
  "website.manage": "permDescWebsiteManage",
  "billing.manage": "permDescBillingManage",
  "settings.manage": "permDescSettingsManage",
};

const GROUP_LABEL: Record<(typeof PERMISSION_GROUPS)[number], I18nKey> = {
  insights: "permGroupInsights",
  operations: "permGroupOperations",
  people: "permGroupPeople",
  governance: "permGroupGovernance",
};
const GROUP_ICON: Record<(typeof PERMISSION_GROUPS)[number], string> = {
  insights: "chart-line",
  operations: "cubes",
  people: "users-round",
  governance: "shield-check",
};

/* role identity (owner = royal gold — the matrix keeps the same accent) */
const ROLE_VISUAL: Record<WorkspaceRole, { c1: string; c2: string; icon: string; desc: I18nKey }> = {
  owner: { c1: "#f59e0b", c2: "#d97706", icon: "crown", desc: "teamRoleDescOwner" },
  manager: { c1: "#8b5cf6", c2: "#6d28d9", icon: "shield-check", desc: "teamRoleDescManager" },
  staff: { c1: "#06b6d4", c2: "#0891b2", icon: "zap-fast", desc: "teamRoleDescStaff" },
  viewer: { c1: "#64748b", c2: "#475569", icon: "circle-check", desc: "teamRoleDescViewer" },
};

/* ------------------------------ role card ------------------------------ */

function RoleCard({
  role,
  memberCount,
  onPreview,
  isPreviewing,
}: {
  role: WorkspaceRole;
  memberCount: number;
  onPreview: (role: WorkspaceRole) => void;
  isPreviewing: boolean;
}) {
  const { t, lang } = useT();
  const v = ROLE_VISUAL[role];
  const stats = permissionStats(role);
  const pct = Math.round((stats.granted / stats.total) * 100);
  const isOwner = role === "owner";

  return (
    <article
      className={cn(
        "glass-card card-in group relative overflow-hidden rounded-3xl p-4 transition-shadow duration-300 hover:shadow-lift sm:p-5",
        isPreviewing && "ring-2 ring-brand-400/60"
      )}
    >
      {/* gradient hairline */}
      <span
        className="pointer-events-none absolute inset-x-0 top-0 h-[2px] opacity-60 transition-opacity duration-300 group-hover:opacity-100"
        style={{ backgroundImage: grad(v.c1, v.c2, 90) }}
        aria-hidden="true"
      />
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2.5">
            <span
              className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
              style={{ backgroundImage: grad(v.c1, v.c2), boxShadow: `0 8px 20px -8px ${v.c2}66` }}
              aria-hidden="true"
            >
              <CatIcon name={v.icon} className="h-5 w-5" />
            </span>
            <div className="min-w-0">
              <p className="truncate font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                {t(ROLE_NAME_I18N[role])}
              </p>
              <p className="mt-0.5 text-[10.5px] font-extrabold text-slate-400 dark:text-slate-500">
                {t("teamPermCount", { granted: fmtNum(stats.granted, lang), total: fmtNum(stats.total, lang) })}
              </p>
            </div>
          </div>
          <p className="mt-2.5 line-clamp-2 min-h-[30px] text-[11px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
            {t(v.desc)}
          </p>
        </div>
        {/* member count badge */}
        <span
          className={cn(
            "inline-flex shrink-0 items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-extrabold",
            isOwner
              ? "bg-amber-500/15 text-amber-600 dark:text-amber-400"
              : "bg-slate-100 text-slate-500 dark:bg-white/[0.06] dark:text-slate-400"
          )}
        >
          <CatIcon name="users" className="h-3 w-3" />
          {fmtNum(memberCount, lang)}
        </span>
      </div>

      {/* permission progress bar */}
      <div className="mt-3">
        <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/[0.07]">
          <div
            className="h-full rounded-full transition-[width] duration-700 ease-out"
            style={{ width: `${pct}%`, backgroundImage: grad(v.c1, v.c2) }}
          />
        </div>
      </div>

      {/* preview arm / owner marker */}
      {isOwner ? (
        <p className="mt-3 inline-flex items-center gap-1.5 rounded-full border border-amber-300/60 bg-amber-50 px-2.5 py-1 text-[10px] font-extrabold text-amber-700 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-400">
          <CatIcon name="crown" className="h-3 w-3" />
          {t("teamOwnerPermsAll")}
        </p>
      ) : (
        <Button
          type="button"
          variant="outline"
          onClick={() => onPreview(role)}
          className={cn(
            "mt-3 h-9 w-full rounded-xl border-slate-200 px-3 text-[11px] font-extrabold text-slate-600 transition hover:border-brand-300 hover:bg-brand-50 hover:text-brand-600 dark:border-white/10 dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:bg-brand-500/10 dark:hover:text-brand-300",
            isPreviewing && "border-brand-400 bg-brand-50 text-brand-600 dark:bg-brand-500/15 dark:text-brand-300"
          )}
        >
          <CatIcon name="eye" className={isPreviewing ? "h-3.5 w-3.5" : "hidden"} />
          {isPreviewing ? t("teamPreviewExit") : t("teamPreviewAs", { role: t(ROLE_NAME_I18N[role]) })}
        </Button>
      )}
    </article>
  );
}

/* ------------------------------ matrix chip ------------------------------ */

function MatrixChip({ ok }: { ok: boolean }) {
  return (
    <span
      className={cn(
        "grid h-6 w-6 place-items-center rounded-full",
        ok
          ? "bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400"
          : "bg-slate-100 text-slate-300 dark:bg-white/5 dark:text-slate-600"
      )}
      role="img"
      aria-label={ok ? "granted" : "denied"}
    >
      <CatIcon name={ok ? "check" : "x"} className="h-3.5 w-3.5" />
    </span>
  );
}

/* --------------------------------- tab --------------------------------- */

export function RolesPermissionsTab({ members }: { members: TeamMemberDTO[] }) {
  const { t, lang } = useT();
  const rolePreview = useAppStore((s) => s.rolePreview);
  const setRolePreview = useAppStore((s) => s.setRolePreview);

  /* live member counts per role (owner = the workspace account itself) */
  const counts: Record<WorkspaceRole, number> = {
    owner: 1,
    manager: members.filter((m) => m.role === "manager").length,
    staff: members.filter((m) => m.role === "staff").length,
    viewer: members.filter((m) => m.role === "viewer").length,
  };

  const onPreview = (role: WorkspaceRole) => {
    if (role === "owner") return;
    setRolePreview(rolePreview === role ? "off" : role);
  };

  return (
    <div className="space-y-5">
      {/* server-enforcement banner */}
      <div className="relative overflow-hidden rounded-3xl border border-emerald-300/60 bg-linear-to-l from-emerald-50/90 to-teal-50/50 p-4 dark:border-emerald-500/25 dark:from-emerald-500/10 dark:to-teal-500/5 sm:p-5">
        <span
          aria-hidden="true"
          className="absolute -end-10 -top-12 h-32 w-32 rounded-full"
          style={{ background: "radial-gradient(circle, rgba(16,185,129,0.18), transparent 70%)" }}
        />
        <div className="flex flex-wrap items-center gap-3.5">
          <span
            className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-white shadow-lg shadow-emerald-500/25"
            style={{ backgroundImage: grad("#10b981", "#0d9488") }}
            aria-hidden="true"
          >
            <CatIcon name="shield-check" className="h-5.5 w-5.5" />
          </span>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <p className="font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                {t("teamTabRoles")}
              </p>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-300/70 bg-white/80 px-2.5 py-0.5 text-[10.5px] font-extrabold text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300">
                <span className="relative flex h-1.5 w-1.5" aria-hidden="true">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-500 opacity-60" />
                  <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-500" />
                </span>
                {t("teamRolesEnforced")}
              </span>
            </div>
            <p className="mt-1 max-w-2xl text-[11.5px] font-semibold leading-relaxed text-slate-600 dark:text-slate-400">
              {t("teamRolesEnforcedDesc")}
            </p>
          </div>
        </div>
      </div>

      {/* role cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {WORKSPACE_ROLES.map((role) => (
          <RoleCard
            key={role}
            role={role}
            memberCount={counts[role]}
            onPreview={onPreview}
            isPreviewing={rolePreview === role}
          />
        ))}
      </div>

      {/* the strict matrix */}
      <DashCard title={t("teamTabRoles")} icon="shield-check">
        <div className="overflow-x-auto">
          <Table className="min-w-[620px]">
            <TableHeader>
              <TableRow className="border-slate-200/70 dark:border-white/10">
                <TableHead className="w-[46%] text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  {t("teamMatrixColPerm")}
                </TableHead>
                {WORKSPACE_ROLES.map((role) => {
                  const v = ROLE_VISUAL[role];
                  return (
                    <TableHead key={role} className="text-center text-[11px] font-extrabold text-slate-400 dark:text-slate-500">
                      <span className="inline-flex items-center gap-1.5">
                        <span
                          className="grid h-4.5 w-4.5 place-items-center rounded-md text-white"
                          style={{ backgroundImage: grad(v.c1, v.c2) }}
                          aria-hidden="true"
                        >
                          <CatIcon name={v.icon} className="h-2.5 w-2.5" />
                        </span>
                        <span className="hidden whitespace-nowrap sm:inline">{t(ROLE_NAME_I18N[role])}</span>
                      </span>
                    </TableHead>
                  );
                })}
              </TableRow>
            </TableHeader>
            <TableBody>
              {PERMISSION_GROUPS.map((group) => {
                const groupPerms = PERMISSION_IDS.filter((p) => PERMISSION_META[p].group === group);
                return (
                  <Fragment key={group}>
                    {/* group header row */}
                    <TableRow className="bg-slate-50/80 hover:bg-slate-50/80 dark:bg-white/[0.03] dark:hover:bg-white/[0.03]">
                      <TableCell colSpan={5} className="py-2">
                        <span className="flex items-center gap-2 text-[11px] font-extrabold text-slate-500 dark:text-slate-300">
                          <CatIcon name={GROUP_ICON[group]} className="h-3.5 w-3.5 text-brand-500" />
                          {t(GROUP_LABEL[group])}
                          <span className="rounded-full bg-slate-100 px-1.5 py-0.5 text-[9.5px] font-extrabold tabular-nums text-slate-400 dark:bg-white/[0.06] dark:text-slate-500">
                            {fmtNum(groupPerms.length, lang)}
                          </span>
                          <span className="ms-1 h-px flex-1 bg-slate-200/70 dark:bg-white/[0.07]" aria-hidden="true" />
                        </span>
                      </TableCell>
                    </TableRow>
                    {/* permission rows */}
                    {groupPerms.map((p) => {
                      const meta = PERMISSION_META[p];
                      return (
                        <TableRow key={p}>
                          <TableCell>
                            <div className="flex items-center gap-2.5">
                              <span
                                className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-white shadow-sm"
                                style={{ backgroundImage: grad(meta.c1, meta.c2) }}
                                aria-hidden="true"
                              >
                                <CatIcon name={meta.icon} className="h-3.5 w-3.5" />
                              </span>
                              <div className="min-w-0">
                                <p className="truncate text-[12px] font-bold text-slate-700 dark:text-slate-200">
                                  {t(PERM_LABEL_I18N[p])}
                                </p>
                                <p className="truncate text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                                  {t(PERM_DESC[p])}
                                </p>
                              </div>
                            </div>
                          </TableCell>
                          {WORKSPACE_ROLES.map((role) => (
                            <TableCell key={role} className="text-center">
                              <MatrixChip ok={ROLE_MATRIX[role].includes(p)} />
                            </TableCell>
                          ))}
                        </TableRow>
                      );
                    })}
                  </Fragment>
                );
              })}
            </TableBody>
          </Table>
        </div>

        {/* platform-tier note */}
        <div className="mt-4 flex items-start gap-2.5 rounded-2xl border border-slate-200/80 bg-slate-50/60 p-3 dark:border-white/10 dark:bg-white/[0.03]">
          <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-slate-100 text-slate-500 dark:bg-white/[0.06] dark:text-slate-400" aria-hidden="true">
            <CatIcon name="fingerprint" className="h-4 w-4" />
          </span>
          <p className="text-[11px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
            {t("teamRolesTierNote")}
          </p>
        </div>
      </DashCard>
    </div>
  );
}
