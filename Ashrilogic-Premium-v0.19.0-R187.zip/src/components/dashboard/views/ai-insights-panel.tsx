"use client";

/**
 * Dashboard — Premium AI Insights panel (ROUND 41).
 *
 * One card, available in EVERY system dashboard (analytics view + module
 * workspaces), that runs a deep AI analysis of the workspace's own data:
 * sales trend, product growth, selling seasons, most-requested items,
 * recommendations and risks — answered by the LLM in Arabic.
 *
 * States: probing → disabled (master switch off / quota out) | idle →
 * running (shimmer) → result | error (retry) | empty (no data yet).
 * All copy comes from the aiPanel / aiKpi … i18n keys (AR + EN); the card
 * follows the dashboard's premium language: glass card, gradient icon
 * tiles (grad()), logical RTL-safe properties, framer-motion reveals.
 */
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useT } from "@/lib/i18n";
import { ApiError, fetchAiStatus, fetchInstance, requestAiInsights } from "@/lib/api-client";
import type { AiInsightsDTO } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { fmtNum, grad, hexAlpha } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { IconTile, fullDate } from "@/components/dashboard/dash-shared";
import { FeatureGate } from "@/components/dashboard/feature-gate";

/* ---------------- palette ---------------- */

const BRAND = { c1: "#6d5dfb", c2: "#d946ef" } as const;

/* ---------------- small building blocks ---------------- */

/** One qualitative KPI tile (gradient icon + title + desc + optional count). */
function KpiTile({
  icon,
  c1,
  c2,
  title,
  desc,
  count,
  index,
}: {
  icon: string;
  c1: string;
  c2: string;
  title: string;
  desc: string;
  count: number | null;
  index: number;
}) {
  return (
    <article
      className="glass-card card-in group relative overflow-hidden rounded-3xl p-4 transition-shadow duration-300 hover:shadow-lift"
      style={{ "--i": index } as React.CSSProperties}
    >
      <span
        className="pointer-events-none absolute inset-x-0 top-0 h-[2px] opacity-50 transition-opacity duration-300 group-hover:opacity-100"
        style={{ backgroundImage: grad(c1, c2, 90) }}
        aria-hidden="true"
      />
      <div className="flex items-center gap-3">
        <IconTile icon={icon} c1={c1} c2={c2} size="sm" />
        <p className="min-w-0 flex-1 truncate text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
          {title}
        </p>
        {count !== null ? (
          <span className="shrink-0 font-display text-lg font-extrabold text-slate-900 dark:text-white">
            {fmtNum(count)}
          </span>
        ) : null}
      </div>
      <p className="mt-2 text-[11px] font-bold leading-relaxed text-slate-400 dark:text-slate-500">{desc}</p>
    </article>
  );
}

/** Bulleted insight list — icon tone per section (RTL-safe leading icon). */
function InsightList({
  items,
  icon,
  c1,
  c2,
  numbered,
}: {
  items: string[];
  icon: string;
  c1: string;
  c2: string;
  numbered?: boolean;
}) {
  return (
    <ul className="space-y-2">
      {items.map((item, i) => (
        <li
          key={`${i}-${item.slice(0, 24)}`}
          className="flex items-start gap-2.5 rounded-2xl border border-slate-100 bg-white/60 p-2.5 text-[12.5px] font-semibold leading-relaxed text-slate-700 transition hover:border-slate-200 dark:border-white/[0.06] dark:bg-white/[0.03] dark:text-slate-200"
        >
          {numbered ? (
            <span
              className="grid h-6 w-6 shrink-0 place-items-center rounded-lg text-[11px] font-extrabold text-white"
              style={{ backgroundImage: grad(c1, c2) }}
            >
              {i + 1}
            </span>
          ) : (
            <span
              className="grid h-6 w-6 shrink-0 place-items-center rounded-lg text-white"
              style={{ backgroundImage: grad(c1, c2) }}
            >
              <CatIcon name={icon} className="h-[11px] w-[11px]" />
            </span>
          )}
          <span className="min-w-0">{item}</span>
        </li>
      ))}
    </ul>
  );
}

/** Labeled section block inside the result. */
function Section({
  icon,
  title,
  c1,
  c2,
  children,
}: {
  icon: string;
  title: string;
  c1: string;
  c2: string;
  children: React.ReactNode;
}) {
  return (
    <section className="space-y-2.5">
      <h3 className="flex items-center gap-2 font-display text-[13.5px] font-extrabold text-slate-900 dark:text-white">
        <IconTile icon={icon} c1={c1} c2={c2} size="sm" />
        {title}
      </h3>
      {children}
    </section>
  );
}

/* ---------------- the panel ---------------- */

type Probe = "loading" | "disabled" | "ready";
type Phase = "idle" | "running" | "result" | "error" | "empty";

export function AiInsightsPanel({ instanceId, moduleId }: { instanceId: string; moduleId?: string }) {
  const { t, lang } = useT();

  const [probe, setProbe] = useState<Probe>("loading");
  const [phase, setPhase] = useState<Phase>("idle");
  const [result, setResult] = useState<AiInsightsDTO | null>(null);
  const [errMsg, setErrMsg] = useState("");

  /* ROUND 79 — plan gate: this panel is embedded in several views that only
   * pass instanceId, so it subscribes to the SAME ["instance", id] query the
   * dashboard shell maintains (react-query dedupes — no extra network call
   * in the dashboard context). While the feature is off the panel renders
   * the compact premium lock banner INSTEAD of the insights content. */
  const instanceQuery = useQuery({
    queryKey: ["instance", instanceId],
    queryFn: () => fetchInstance(instanceId),
    staleTime: 30_000,
    retry: 1,
  });
  const gatedInstance = instanceQuery.data?.instance;

  /* availability probe — { enabled } (404-free). A network failure renders
     the disabled card: never a broken surface in the dashboard. */
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await fetchAiStatus(instanceId);
        if (!cancelled) setProbe(data.enabled ? "ready" : "disabled");
      } catch {
        if (!cancelled) setProbe("disabled");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [instanceId]);

  /* ROUND 79 — plan gate (AFTER every hook so the render stays stable):
     while aiInsights is outside the plan the compact premium lock banner
     renders INSTEAD of the insights content. */
  if (gatedInstance && gatedInstance.entitlement?.features?.aiInsights === false) {
    return <FeatureGate feature="aiInsights" instance={gatedInstance} compact />;
  }

  const run = async () => {
    if (phase === "running") return;
    setPhase("running");
    try {
      /* round 41 — the analysis content follows the requester's UI language
         (ar/en/hi get native-language analyses; other locales → English). */
      const analysisLang: "ar" | "en" | "hi" = lang === "ar" || lang === "hi" ? lang : "en";
      const data = await requestAiInsights(instanceId, {
        ...(moduleId ? { scope: moduleId } : {}),
        lang: analysisLang,
      });
      setResult(data);
      setPhase("result");
    } catch (error) {
      const api = error as ApiError;
      if (api && typeof api === "object" && api.code === "AI_EMPTY") {
        setPhase("empty");
        return;
      }
      setPhase("error");
      /* ROUND 81 — the verification refusal carries its own localized
         message (the engine REFUSED an unverifiable analysis — retry). */
      const message =
        api && typeof api === "object" && api.code === "AI_VERIFICATION"
          ? t("errAI_VERIFICATION")
          : error instanceof Error
            ? error.message
            : "";
      setErrMsg(message);
      toast.error(message || t("aiErrorTitle"));
    }
  };

  /* ---------------- header (shared by every state) ---------------- */
  const header = (
    <header className="flex flex-wrap items-start gap-3">
      <span
        className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
        style={{ backgroundImage: grad(BRAND.c1, BRAND.c2), boxShadow: `0 14px 30px -12px ${hexAlpha(BRAND.c1, 0.8)}` }}
      >
        <CatIcon name="brain" className="h-5 w-5" />
      </span>
      <div className="min-w-0 flex-1">
        <h2 className="flex flex-wrap items-center gap-2 font-display text-lg font-extrabold text-slate-900 dark:text-white">
          {t("aiPanelTitle")}
          <Badge className="gap-1 rounded-full bg-fuchsia-500/15 px-2.5 py-0.5 text-[10px] font-extrabold text-fuchsia-600 hover:bg-fuchsia-500/15 dark:text-fuchsia-300">
            <CatIcon name="wand-sparkles" className="h-3 w-3" />
            {t("aiPanelBadge")}
          </Badge>
        </h2>
        <p className="mt-0.5 text-[12px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
          {moduleId ? t("aiScopeModule") : t("aiScopeAll")}
        </p>
      </div>
      {probe === "ready" && result ? (
        <div className="flex flex-wrap items-center gap-1.5">
          <Badge className="gap-1 rounded-full bg-slate-500/10 px-2.5 py-0.5 text-[10px] font-bold text-slate-500 dark:text-slate-400">
            <CatIcon name="database" className="h-3 w-3" />
            {t("aiMetaRows", { n: result.rowsAnalyzed, m: result.itemsConsidered })}
          </Badge>
          <Badge className="gap-1 rounded-full bg-emerald-500/15 px-2.5 py-0.5 text-[10px] font-bold text-emerald-600 dark:text-emerald-300">
            <CatIcon name="shield-check" className="h-3 w-3" />
            {t("aiConfidence")}: {fmtNum(result.confidence, lang)}%
          </Badge>
          {/* ROUND 81 — the server-verified grounding badge: every item claim
              was cross-checked against the tenant's REAL data before display. */}
          {result.verification?.verified ? (
            <Badge
              title={t("aiVerifiedHint")}
              className="gap-1 rounded-full bg-linear-to-r from-emerald-500/20 to-cyan-500/15 px-2.5 py-0.5 text-[10px] font-extrabold text-emerald-700 hover:from-emerald-500/20 hover:to-cyan-500/15 dark:text-emerald-300"
            >
              <CatIcon name="badge-check" className="h-3 w-3" />
              {t("aiVerified")} · {t("aiGrounding", { pct: fmtNum(result.verification.groundingPct, lang) })}
            </Badge>
          ) : null}
        </div>
      ) : null}
    </header>
  );

  /* ---------------- probing skeleton ---------------- */
  if (probe === "loading") {
    return (
      <section className="glass-card card-in rounded-3xl p-4 sm:p-6">
        {header}
        <div className="mt-5 space-y-3">
          <Skeleton className="h-11 w-56 rounded-xl" />
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[0, 1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-24 rounded-3xl" />
            ))}
          </div>
        </div>
      </section>
    );
  }

  /* ---------------- disabled ---------------- */
  if (probe === "disabled") {
    return (
      <section className="glass-card card-in rounded-3xl p-4 sm:p-6">
        {header}
        <div className="mt-5 flex flex-wrap items-center gap-4 rounded-2xl border border-slate-200 bg-slate-50/60 p-4 dark:border-white/10 dark:bg-white/[0.03]">
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-slate-200 text-slate-500 dark:bg-white/10 dark:text-slate-400">
            <CatIcon name="lock" className="h-5 w-5" />
          </span>
          <div className="min-w-0">
            <p className="font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("aiDisabledTitle")}
            </p>
            <p className="mt-0.5 text-[12px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {t("aiDisabledDesc")}
            </p>
          </div>
        </div>
      </section>
    );
  }

  /* ---------------- ready: idle / running / result / error / empty -------- */
  return (
    <section className="glass-card card-in relative overflow-hidden rounded-3xl p-4 sm:p-6">
      <span
        className="pointer-events-none absolute inset-x-0 top-0 h-[2px] opacity-60"
        style={{ backgroundImage: grad(BRAND.c1, BRAND.c2, 90) }}
        aria-hidden="true"
      />
      {header}

      {phase === "idle" ? (
        <div className="mt-5 space-y-4">
          <p className="max-w-2xl text-[12.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
            {t("aiPanelDesc")}
          </p>
          <Button
            type="button"
            onClick={run}
            className="h-11 gap-2 rounded-xl px-6 text-[13px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95"
            style={{ backgroundImage: grad(BRAND.c1, BRAND.c2) }}
          >
            <CatIcon name="sparkles" className="h-4 w-4" />
            {t("aiRunBtn")}
          </Button>
        </div>
      ) : null}

      {phase === "running" ? (
        <div className="mt-5 space-y-4">
          <div className="relative overflow-hidden rounded-2xl border border-slate-200 bg-slate-50/60 p-4 dark:border-white/10 dark:bg-white/[0.03]">
            <motion.span
              className="absolute inset-0 -translate-x-full bg-linear-to-r from-transparent via-white/50 to-transparent dark:via-white/10"
              animate={{ x: ["-100%", "100%"] }}
              transition={{ duration: 1.6, repeat: Infinity, ease: "linear" }}
              aria-hidden="true"
            />
            <div className="relative flex items-center gap-3">
              <motion.span
                animate={{ rotate: [0, 12, -12, 0], scale: [1, 1.12, 1] }}
                transition={{ duration: 1.4, repeat: Infinity, ease: "easeInOut" }}
                className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
                style={{ backgroundImage: grad(BRAND.c1, BRAND.c2) }}
              >
                <CatIcon name="sparkles" className="h-5 w-5" />
              </motion.span>
              <div className="min-w-0">
                <p className="font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
                  {t("aiRunning")}
                </p>
                <div className="mt-2 flex items-center gap-1.5">
                  {[0, 1, 2].map((i) => (
                    <motion.span
                      key={i}
                      className="h-1.5 w-1.5 rounded-full bg-fuchsia-400"
                      animate={{ opacity: [0.25, 1, 0.25] }}
                      transition={{ duration: 1.1, repeat: Infinity, delay: i * 0.18 }}
                      aria-hidden="true"
                    />
                  ))}
                </div>
              </div>
              <Loader2 className="ms-auto h-5 w-5 shrink-0 animate-spin text-fuchsia-500" />
            </div>
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[0, 1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-24 rounded-3xl" />
            ))}
          </div>
        </div>
      ) : null}

      {phase === "empty" ? (
        <div className="mt-5 flex flex-wrap items-center gap-4 rounded-2xl border border-slate-200 bg-slate-50/60 p-4 dark:border-white/10 dark:bg-white/[0.03]">
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-amber-500/15 text-amber-500 dark:text-amber-300">
            <CatIcon name="inbox" className="h-5 w-5" />
          </span>
          <div className="min-w-0">
            <p className="font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("aiEmptyTitle")}
            </p>
            <p className="mt-0.5 text-[12px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {t("aiEmptyDesc")}
            </p>
          </div>
        </div>
      ) : null}

      {phase === "error" ? (
        <div className="mt-5 space-y-4">
          <div className="flex flex-wrap items-center gap-4 rounded-2xl border border-rose-200/70 bg-rose-500/[0.06] p-4 dark:border-rose-500/25 dark:bg-rose-500/10">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-rose-500/15 text-rose-500 dark:text-rose-300">
              <CatIcon name="circle-alert" className="h-5 w-5" />
            </span>
            <div className="min-w-0">
              <p className="font-display text-[14px] font-extrabold text-rose-600 dark:text-rose-300">
                {t("aiErrorTitle")}
              </p>
              {errMsg ? (
                <p className="mt-0.5 max-w-lg text-[12px] font-semibold leading-relaxed text-rose-500/90 dark:text-rose-300/80">
                  {errMsg}
                </p>
              ) : null}
            </div>
            <Button
              type="button"
              variant="outline"
              onClick={run}
              className="ms-auto h-10 gap-2 rounded-xl border-rose-200 px-4 text-[12px] font-bold text-rose-600 transition hover:border-rose-300 hover:text-rose-700 active:scale-95 dark:border-rose-500/30 dark:text-rose-300"
            >
              <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
              {t("aiRetry")}
            </Button>
          </div>
        </div>
      ) : null}

      {phase === "result" && result ? (
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, ease: "easeOut" }}
          className="mt-5 space-y-5"
        >
          {/* run headline + last-run chip */}
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]">
            <div className="min-w-0">
              <p className="font-display text-[15px] font-extrabold leading-snug text-slate-900 dark:text-white">
                {result.title}
              </p>
              <p className="mt-1 flex items-center gap-1.5 text-[11px] font-bold text-slate-400 dark:text-slate-500">
                <CatIcon name="clock" className="h-3 w-3" />
                {t("aiLastRun")}: {fullDate(result.generatedAt, lang)}
              </p>
            </div>
            <Button
              type="button"
              variant="outline"
              onClick={run}
              className="h-10 gap-2 rounded-xl border-slate-200 px-4 text-[12px] font-bold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:text-slate-300 dark:hover:border-brand-500/40"
            >
              <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
              {t("aiRerun")}
            </Button>
          </div>

          {/* KPI row */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <KpiTile
              icon="trending-up"
              c1="#10b981"
              c2="#047857"
              title={t("aiKpiSalesT")}
              desc={t("aiKpiSalesD")}
              count={null}
              index={0}
            />
            <KpiTile
              icon="sprout"
              c1="#06b6d4"
              c2="#0891b2"
              title={t("aiKpiProductsT")}
              desc={t("aiKpiProductsD")}
              count={result.productGrowth.length}
              index={1}
            />
            <KpiTile
              icon="calendar-range"
              c1="#f59e0b"
              c2="#d97706"
              title={t("aiKpiSeasonsT")}
              desc={t("aiKpiSeasonsD")}
              count={result.seasons.length}
              index={2}
            />
            <KpiTile
              icon="flame"
              c1="#d946ef"
              c2="#c026d3"
              title={t("aiKpiTopT")}
              desc={t("aiKpiTopD")}
              count={result.topItems.length}
              index={3}
            />
          </div>

          {/* executive summary + sales trend */}
          <Section icon="file-text" title={t("aiSummaryT")} c1="#6d5dfb" c2="#8b5cf6">
            <p className="rounded-2xl border border-slate-100 bg-white/60 p-4 text-[13px] font-semibold leading-loose text-slate-700 dark:border-white/[0.06] dark:bg-white/[0.03] dark:text-slate-200">
              {result.summary}
            </p>
            <div className="rounded-2xl border border-emerald-200/60 bg-emerald-500/[0.05] p-4 dark:border-emerald-500/20 dark:bg-emerald-500/10">
              <p className="flex items-start gap-2 text-[12.5px] font-semibold leading-relaxed text-emerald-700 dark:text-emerald-300">
                <CatIcon name="trending-up" className="mt-0.5 h-4 w-4 shrink-0" />
                <span className="min-w-0">
                  <span className="block text-[11px] font-extrabold uppercase tracking-wider text-emerald-500 dark:text-emerald-400">
                    {t("aiKpiSalesT")}
                  </span>
                  {result.salesTrend}
                </span>
              </p>
            </div>
          </Section>

          {/* product growth */}
          {result.productGrowth.length > 0 ? (
            <Section icon="sprout" title={t("aiProductsT")} c1="#06b6d4" c2="#0891b2">
              <InsightList items={result.productGrowth} icon="sprout" c1="#06b6d4" c2="#0891b2" />
            </Section>
          ) : null}

          {/* seasons */}
          {result.seasons.length > 0 ? (
            <Section icon="calendar-range" title={t("aiSeasonsT")} c1="#f59e0b" c2="#d97706">
              <InsightList items={result.seasons} icon="calendar-range" c1="#f59e0b" c2="#d97706" />
            </Section>
          ) : null}

          {/* top items — ranked */}
          {result.topItems.length > 0 ? (
            <Section icon="flame" title={t("aiTopT")} c1="#d946ef" c2="#c026d3">
              <InsightList items={result.topItems} icon="flame" c1="#d946ef" c2="#c026d3" numbered />
            </Section>
          ) : null}

          {/* recommendations */}
          {result.recommendations.length > 0 ? (
            <Section icon="lightbulb" title={t("aiRecsT")} c1="#6d5dfb" c2="#8b5cf6">
              <InsightList items={result.recommendations} icon="lightbulb" c1="#6d5dfb" c2="#8b5cf6" />
            </Section>
          ) : null}

          {/* risks */}
          {result.risks.length > 0 ? (
            <Section icon="triangle-alert" title={t("aiRisksT")} c1="#f59e0b" c2="#d97706">
              <ul className="space-y-2">
                {result.risks.map((item, i) => (
                  <li
                    key={`${i}-${item.slice(0, 24)}`}
                    className="flex items-start gap-2.5 rounded-2xl border border-amber-200/60 bg-amber-500/[0.05] p-2.5 text-[12.5px] font-semibold leading-relaxed text-amber-700 dark:border-amber-500/20 dark:bg-amber-500/10 dark:text-amber-300"
                  >
                    <span className="grid h-6 w-6 shrink-0 place-items-center rounded-lg bg-linear-to-br from-amber-400 to-orange-500 text-white">
                      <CatIcon name="triangle-alert" className="h-[11px] w-[11px]" />
                    </span>
                    <span className="min-w-0">{item}</span>
                  </li>
                ))}
              </ul>
            </Section>
          ) : null}

          {/* footer chip */}
          <footer className="flex items-center justify-between gap-3 border-t border-dashed border-slate-200 pt-3 dark:border-white/10">
            <Badge className="gap-1.5 rounded-full bg-fuchsia-500/10 px-3 py-1 text-[10.5px] font-bold text-fuchsia-600 hover:bg-fuchsia-500/10 dark:text-fuchsia-300">
              <CatIcon name="wand-sparkles" className="h-3 w-3" />
              {t("aiPoweredBy")}
            </Badge>
            <span className="text-[10.5px] font-bold text-slate-300 dark:text-slate-600" aria-hidden="true">
              ● ● ●
            </span>
          </footer>
        </motion.div>
      ) : null}
    </section>
  );
}

export default AiInsightsPanel;
