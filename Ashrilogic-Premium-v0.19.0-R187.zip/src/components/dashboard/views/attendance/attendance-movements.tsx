"use client";

/**
 * Ashrilogic — ROUND 166 (Task 6-b): tab 2 of the attendance workspace —
 * سجل الحركات (the movements log).
 *
 * The keyset-paginated feed (GET movements?cursor= — newest first): each
 * row carries the server-stamped time, the student, the direction icon
 * (log-in emerald / log-out rose), the method badge (يدوي / QR), the
 * recorder's name and the student's derived state for that movement's
 * day. "المزيد" walks the nextCursor; direction + method filter chips
 * narrow the loaded pages client-side.
 */
import { useMemo, useState } from "react";
import { useInfiniteQuery } from "@tanstack/react-query";
import { useT } from "@/lib/i18n";
import type { InstanceDTO, Lang } from "@/lib/types";
import type { AttendanceMovementDTO } from "@/lib/types";
import { fetchAttendanceMovements } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, idDir } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { DashCard, fullDate } from "@/components/dashboard/dash-shared";
import { AttStatePill } from "./attendance-shared";

type DirFilter = "all" | "in" | "out";
type MethodFilter = "all" | "manual" | "qr";

/** one feed row — the premium card strip (not a table: a live log reads
 *  better as rows). */
function MovementRow({ row, lang }: { row: AttendanceMovementDTO; lang: Lang }) {
  const { t } = useT();
  const isIn = row.direction === "in";
  return (
    <div
      className={cn(
        "flex flex-wrap items-center gap-x-3 gap-y-1.5 rounded-xl border p-2.5 transition-colors",
        isIn
          ? "border-emerald-200/70 bg-emerald-50/40 dark:border-emerald-500/15 dark:bg-emerald-500/[0.05]"
          : "border-rose-200/70 bg-rose-50/40 dark:border-rose-500/15 dark:bg-rose-500/[0.05]"
      )}
    >
      {/* direction tile */}
      <span
        aria-hidden="true"
        className={cn(
          "grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md",
          isIn ? "bg-linear-to-br from-emerald-500 to-emerald-600" : "bg-linear-to-br from-rose-500 to-rose-600"
        )}
      >
        <CatIcon name={isIn ? "log-in" : "log-out"} className="h-4 w-4" />
      </span>

      {/* student + time */}
      <span className="min-w-0 flex-1">
        <span className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
          <span className="truncate text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
            {row.studentName}
          </span>
          <span
            dir={idDir}
            className="shrink-0 rounded-full border border-slate-200 bg-white/80 px-2 py-0.5 font-mono text-[9.5px] font-extrabold tabular-nums text-slate-500 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-300"
          >
            {row.studentCode}
          </span>
        </span>
        <span dir="auto" className="mt-0.5 block truncate text-[10.5px] font-bold tabular-nums text-slate-400 dark:text-slate-500">
          {fullDate(row.occurredAt, lang)}
          {" · "}
          {t("attwsMovBy", { name: row.recordedByName })}
        </span>
      </span>

      {/* state + method + direction labels */}
      <span className="flex shrink-0 flex-wrap items-center gap-1.5">
        {row.state ? <AttStatePill state={row.state} compact /> : null}
        <span
          dir="auto"
          className={cn(
            "inline-flex shrink-0 items-center gap-1 rounded-full px-2 py-0.5 text-[9.5px] font-extrabold",
            isIn
              ? "bg-emerald-500/12 text-emerald-700 dark:text-emerald-300"
              : "bg-rose-500/12 text-rose-700 dark:text-rose-300"
          )}
        >
          <CatIcon name={isIn ? "log-in" : "log-out"} className="h-2.5 w-2.5" aria-hidden="true" />
          {isIn ? t("attwsDirIn") : t("attwsDirOut")}
        </span>
        <span
          dir="auto"
          className="inline-flex shrink-0 items-center gap-1 rounded-full bg-slate-500/10 px-2 py-0.5 text-[9.5px] font-extrabold text-slate-600 dark:text-slate-300"
        >
          <CatIcon name={row.method === "qr" ? "qr-code" : "pencil"} className="h-2.5 w-2.5" aria-hidden="true" />
          {row.method === "qr" ? t("attwsMethodQr") : t("attwsMethodManual")}
        </span>
      </span>
    </div>
  );
}

export function AttendanceMovementsTab({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const [dirFilter, setDirFilter] = useState<DirFilter>("all");
  const [methodFilter, setMethodFilter] = useState<MethodFilter>("all");

  const feed = useInfiniteQuery({
    queryKey: ["attendance-movements", instance.id],
    queryFn: ({ pageParam }) =>
      fetchAttendanceMovements(instance.id, pageParam as string | null),
    initialPageParam: null as string | null,
    getNextPageParam: (lastPage) => lastPage.nextCursor ?? undefined,
    staleTime: 30_000,
    retry: 0,
  });

  const rows = useMemo(
    () => feed.data?.pages.flatMap((p) => p.movements) ?? [],
    [feed.data]
  );

  const filtered = useMemo(
    () =>
      rows.filter(
        (r) =>
          (dirFilter === "all" || r.direction === dirFilter) &&
          (methodFilter === "all" || r.method === methodFilter)
      ),
    [rows, dirFilter, methodFilter]
  );

  const dirChips: { id: DirFilter; label: string }[] = [
    { id: "all", label: t("attwsMovAll") },
    { id: "in", label: t("attwsDirIn") },
    { id: "out", label: t("attwsDirOut") },
  ];
  const methodChips: { id: MethodFilter; label: string }[] = [
    { id: "all", label: t("attwsMovAll") },
    { id: "manual", label: t("attwsMethodManual") },
    { id: "qr", label: t("attwsMethodQr") },
  ];

  return (
    <DashCard
      title={t("attwsMovTitle")}
      icon="clock-rotate-left"
      action={
        <span dir={idDir} className="rounded-full border border-slate-200 bg-slate-50 px-2.5 py-0.5 text-[10.5px] font-extrabold tabular-nums text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
          {fmtNum(filtered.length, lang)}
        </span>
      }
    >
      {/* filter chips — direction + method */}
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <div
          role="group"
          aria-label={t("attwsDirIn")}
          className="flex items-center rounded-full border border-slate-200 bg-slate-50 p-0.5 dark:border-white/10 dark:bg-white/[0.04]"
        >
          {dirChips.map((chip) => (
            <button
              key={`dir-${chip.id}`}
              type="button"
              aria-pressed={dirFilter === chip.id}
              onClick={() => setDirFilter(chip.id)}
              className={cn(
                "inline-flex min-h-[32px] items-center gap-1 rounded-full px-3 text-[11px] font-extrabold transition",
                dirFilter === chip.id
                  ? "bg-white text-slate-800 shadow-sm dark:bg-white/[0.12] dark:text-white"
                  : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white"
              )}
            >
              {chip.id !== "all" ? (
                <CatIcon
                  name={chip.id === "in" ? "log-in" : "log-out"}
                  className={cn("h-3 w-3", chip.id === "in" ? "text-emerald-500" : "text-rose-500")}
                  aria-hidden="true"
                />
              ) : null}
              {chip.label}
            </button>
          ))}
        </div>
        <div
          role="group"
          aria-label={t("attwsMethodManual")}
          className="flex items-center rounded-full border border-slate-200 bg-slate-50 p-0.5 dark:border-white/10 dark:bg-white/[0.04]"
        >
          {methodChips.map((chip) => (
            <button
              key={`method-${chip.id}`}
              type="button"
              aria-pressed={methodFilter === chip.id}
              onClick={() => setMethodFilter(chip.id)}
              className={cn(
                "inline-flex min-h-[32px] items-center gap-1 rounded-full px-3 text-[11px] font-extrabold transition",
                methodFilter === chip.id
                  ? "bg-white text-slate-800 shadow-sm dark:bg-white/[0.12] dark:text-white"
                  : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white"
              )}
            >
              {chip.id !== "all" ? (
                <CatIcon
                  name={chip.id === "qr" ? "qr-code" : "pencil"}
                  className="h-3 w-3 text-brand-500"
                  aria-hidden="true"
                />
              ) : null}
              {chip.label}
            </button>
          ))}
        </div>
        <Button
          type="button"
          variant="ghost"
          onClick={() => void feed.refetch()}
          disabled={feed.isFetching}
          className="ms-auto h-9 gap-1.5 rounded-xl px-2.5 text-[11px] font-bold text-slate-500 dark:text-slate-400"
        >
          <CatIcon
            name="refresh-cw"
            className={cn("h-3.5 w-3.5", feed.isFetching && "animate-spin")}
            aria-hidden="true"
          />
          {t("attwsRefresh")}
        </Button>
      </div>

      {feed.isError && rows.length === 0 ? (
        <div className="flex min-h-24 flex-col items-center justify-center gap-2 text-center">
          <CatIcon name="circle-alert" className="h-6 w-6 text-rose-400" aria-hidden="true" />
          <p className="text-[12px] font-bold text-slate-500 dark:text-slate-400">{t("attwsLoadErr")}</p>
          <Button
            type="button"
            variant="outline"
            onClick={() => void feed.refetch()}
            className="h-9 rounded-xl px-3 text-[11.5px] font-bold"
          >
            {t("attwsRefresh")}
          </Button>
        </div>
      ) : feed.isPending && rows.length === 0 ? (
        <div className="space-y-2">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="h-[62px] animate-pulse rounded-xl bg-slate-100 dark:bg-white/5" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex h-28 flex-col items-center justify-center gap-1.5 text-center">
          <CatIcon name="history" className="h-6 w-6 text-slate-300 dark:text-slate-600" aria-hidden="true" />
          <p className="text-[12.5px] font-extrabold text-slate-500 dark:text-slate-400">{t("attwsMovEmpty")}</p>
          <p className="max-w-sm text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("attwsMovEmptyHint")}
          </p>
        </div>
      ) : (
        <div className="nice-scroll grid max-h-[560px] gap-2 overflow-y-auto pe-1">
          {filtered.map((row) => (
            <MovementRow key={row.id} row={row} lang={lang} />
          ))}
        </div>
      )}

      {/* the keyset "load more" */}
      {feed.hasNextPage ? (
        <div className="mt-3 flex justify-center">
          <Button
            type="button"
            variant="outline"
            onClick={() => void feed.fetchNextPage()}
            disabled={feed.isFetchingNextPage}
            className="h-10 gap-2 rounded-xl px-5 text-[12px] font-extrabold"
          >
            {feed.isFetchingNextPage ? (
              <CatIcon name="refresh-cw" className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
            ) : (
              <CatIcon name="clock-rotate-left" className="h-3.5 w-3.5" aria-hidden="true" />
            )}
            {t("attwsMovMore")}
          </Button>
        </div>
      ) : null}
    </DashCard>
  );
}
