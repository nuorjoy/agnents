"use client";

/**
 * Ashrilogic — ROUND 167 (Task 10-d, دوام): tab 4 of the attendance
 * workspace — السياسة — is now the SHIFT-SCHEDULE manager.
 *
 * TWO MODES, one form:
 *   • NO shifts configured → the LEGACY single-window editor (the exact
 *     pre-167 surface: بداية/نهاية اليوم + السماحية + التقييم + المراجعة)
 *     plus the «تخصيص الدوام» CTA that converts the window into the first
 *     shift card;
 *   • ONE or more shifts → the دوام manager: one card per shift — type
 *     chips (صباحي/مسائي/جزئي with sunrise/sunset/clock icons), start +
 *     end time inputs, its own grace stepper + chips, and for PARTIAL
 *     shifts the «ساعات الدوام الجزئي» stepper (1..12h) with the live
 *     required-coverage hint. Add (max 3) / remove (the last remove
 *     returns to the single-window editor, seeded from that card).
 *
 * The FIRST shift binds the legacy columns invisibly (dayStart = first
 * start, dayEnd = last end, grace = first grace — the server stamps them
 * for every other reader). The live 24-hour timeline renders every window
 * as a labeled gradient segment in its type's color family (morning amber,
 * evening violet, partial teal) + per-shift grace ticks + the eval marker;
 * the معاينة strip is shift-aware. Validation mirrors the server zod
 * inline (start<end per card, NO overlap across cards, eval ≥ last end)
 * BEFORE any submit; the save button is disabled while unchanged/invalid.
 */

import { useState, type FormEvent, type ReactNode } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { useT } from "@/lib/i18n";
import type { I18nKey } from "@/lib/i18n";
import type { InstanceDTO, Lang } from "@/lib/types";
import type { AttendancePolicyDTO, AttendanceShiftDTO } from "@/lib/types";
import {
  ApiError,
  fetchAttendancePolicy,
  updateAttendancePolicy,
} from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, idDir } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { DashCard } from "@/components/dashboard/dash-shared";
import {
  ATT_SHIFT_META,
  ATT_SHIFT_TYPES,
  attErrorKey,
  hhmm,
  parseHhmm,
  type AttShiftType,
} from "./attendance-shared";

const ATT_C = ["#6366f1", "#7c3aed"] as const;

/** quick grace presets (minutes). */
const GRACE_CHIPS: readonly number[] = [5, 10, 15, 30];

/** max دوام windows (the server zod's .max(3)). */
const MAX_SHIFTS = 3;

/** default partial-shift coverage (hours) for a freshly-typed card. */
const DEFAULT_PARTIAL_HOURS = 4;

/**
 * Fresh-card seeds — disjoint by construction so a stock add never starts
 * red (the first card converts from the legacy window instead of a seed).
 */
const SHIFT_SEEDS: readonly { type: AttShiftType; start: string; end: string }[] =
  [
    { type: "morning", start: "08:00", end: "15:00" },
    { type: "evening", start: "15:30", end: "22:00" },
    { type: "partial", start: "05:00", end: "07:30" },
  ];

/** one editable دوام card (HH:MM strings bind the time inputs). */
interface ShiftDraft {
  type: AttShiftType;
  start: string;
  end: string;
  graceMin: number;
  partialHours: number;
}

/* ------------------------------------------------------------------ */
/* shared field atoms                                                  */
/* ------------------------------------------------------------------ */

const TIME_INPUT_CLASS =
  "h-10 w-36 rounded-xl border border-slate-200 bg-slate-50/80 px-3 text-center text-[13px] font-extrabold tabular-nums text-slate-800 outline-none transition focus-visible:border-brand-400 focus-visible:ring-[3px] focus-visible:ring-brand-400/30 dark:border-white/10 dark:bg-white/[0.05] dark:text-white";

/** one labeled settings row (the premium settings-form idiom). */
function PolicyRow({
  icon,
  label,
  hint,
  error,
  children,
}: {
  icon: string;
  label: string;
  hint: string;
  error?: string | null;
  children: ReactNode;
}) {
  return (
    <div
      className={cn(
        "rounded-2xl border bg-white/60 p-3.5 dark:bg-white/[0.03]",
        error
          ? "border-rose-300/70 dark:border-rose-500/30"
          : "border-slate-200/80 dark:border-white/10"
      )}
    >
      <div className="flex flex-wrap items-start gap-x-4 gap-y-3">
        <span
          aria-hidden="true"
          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
          style={{ backgroundImage: grad(ATT_C[0], ATT_C[1]) }}
        >
          <CatIcon name={icon} className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <p dir="auto" className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
            {label}
          </p>
          <p dir="auto" className="mt-0.5 max-w-md text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {hint}
          </p>
        </div>
        <div className="shrink-0">{children}</div>
      </div>
      {error ? (
        <p role="alert" dir="auto" className="mt-2.5 rounded-lg bg-rose-500/10 px-2.5 py-1.5 text-[11px] font-extrabold text-rose-600 dark:text-rose-300">
          {error}
        </p>
      ) : null}
    </div>
  );
}

/** the −/+ stepper + quick chips (grace minutes — shared by the legacy
 * row and every shift card). */
function GraceControl({
  value,
  onChange,
  unitLabel,
  lang,
}: {
  value: number;
  onChange: (next: number) => void;
  /** the minutes word («دقيقة») — labels the stepper + its aria buttons. */
  unitLabel: string;
  lang: Lang;
}) {
  return (
    <div className="flex flex-wrap items-center justify-end gap-2">
      <div className="flex items-center rounded-xl border border-slate-200 bg-slate-50/80 dark:border-white/10 dark:bg-white/[0.05]">
        <Button
          type="button"
          aria-label={`- ${unitLabel}`}
          onClick={() => onChange(Math.max(0, value - 5))}
          className="h-10 w-10 rounded-none rounded-s-xl text-slate-500 transition hover:text-slate-800 active:scale-95 dark:hover:text-white"
        >
          <CatIcon name="minus" className="h-3.5 w-3.5" aria-hidden="true" />
        </Button>
        <span dir={idDir} className="w-16 text-center font-display text-[14px] font-extrabold tabular-nums text-slate-800 dark:text-white">
          {fmtNum(value, lang)}
        </span>
        <Button
          type="button"
          aria-label={`+ ${unitLabel}`}
          onClick={() => onChange(Math.min(240, value + 5))}
          className="h-10 w-10 rounded-none rounded-e-xl text-slate-500 transition hover:text-slate-800 active:scale-95 dark:hover:text-white"
        >
          <CatIcon name="plus" className="h-3.5 w-3.5" aria-hidden="true" />
        </Button>
      </div>
      <span dir="auto" className="text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
        {unitLabel}
      </span>
      <div className="flex items-center gap-1">
        {GRACE_CHIPS.map((chip) => (
          <button
            key={chip}
            type="button"
            onClick={() => onChange(chip)}
            className={cn(
              "inline-flex h-8 min-w-[34px] items-center justify-center rounded-full border px-2 text-[10.5px] font-extrabold tabular-nums transition",
              value === chip
                ? "border-transparent bg-linear-to-r from-indigo-500 to-violet-500 text-white shadow-md"
                : "border-slate-200 bg-white/80 text-slate-500 hover:border-slate-300 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-400"
            )}
          >
            {fmtNum(chip, lang)}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* the 24-hour visual timeline (multi-segment)                         */
/* ------------------------------------------------------------------ */

/** One rendered window — a shift segment or the legacy day window. */
interface TlSegment {
  startMin: number;
  endMin: number;
  graceMin: number;
  colors: readonly [string, string];
  /** the legend chip's name («الصباحي» / «اليوم»). */
  label: string;
}

function PolicyTimeline({
  segments,
  evalMin,
  lang,
  labels,
}: {
  segments: readonly TlSegment[];
  evalMin: number;
  lang: Lang;
  labels: { grace: string; eval: string };
}) {
  const pct = (min: number) => `${((Math.max(0, Math.min(1440, min)) / 1440) * 100).toFixed(3)}%`;
  /* the effective day window: first segment's start → last segment's end. */
  const ordered = [...segments].sort((a, b) => a.startMin - b.startMin);
  const windowStart = ordered.length > 0 ? ordered[0].startMin : 480;
  const windowEnd =
    ordered.length > 0 ? ordered[ordered.length - 1].endMin : 1080;

  return (
    <div dir="ltr" className="rounded-2xl border border-slate-200/80 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]">
      {/* the bar itself — CSS gradients + positioned markers (no libs) */}
      <div className="relative h-12">
        {/* hour ticks */}
        {[0, 6, 12, 18, 24].map((h) => (
          <span
            key={h}
            aria-hidden="true"
            className="absolute top-1 h-2 w-px bg-slate-300 dark:bg-slate-600"
            style={{ insetInlineStart: `${(h / 24) * 100}%` }}
          />
        ))}
        {/* the track */}
        <div className="absolute inset-x-0 top-4 h-3.5 rounded-full bg-slate-200 shadow-[inset_0_1px_3px_rgba(100,116,139,0.35)] dark:bg-white/10" />
        {/* every window as its own gradient segment (start-order) */}
        {ordered.map((seg, i) => (
          <div
            key={`${i}-${seg.startMin}-${seg.endMin}`}
            className="absolute top-4 h-3.5 rounded-full shadow-md"
            style={{
              insetInlineStart: pct(seg.startMin),
              width: `max(0px, calc(${pct(seg.endMin)} - ${pct(seg.startMin)}))`,
              backgroundImage: `linear-gradient(90deg, ${seg.colors[0]}, ${seg.colors[1]})`,
            }}
          />
        ))}
        {/* the grace ticks (amber) — one per window, clamped inside it */}
        {ordered.map((seg, i) => {
          const graceLeft = Math.max(
            seg.startMin,
            Math.min(seg.startMin + seg.graceMin, seg.endMin)
          );
          return (
            <div
              key={`g-${i}-${seg.startMin}`}
              className="absolute top-[7px] h-[22px] w-[3px] rounded-full bg-amber-500 shadow-sm ring-2 ring-white dark:ring-[#0b1220]"
              style={{ insetInlineStart: pct(graceLeft) }}
              aria-hidden="true"
            />
          );
        })}
        {/* the eval marker (violet, after the window) */}
        <div
          className="absolute top-[7px] h-[22px] w-[3px] rounded-full bg-violet-500 shadow-sm ring-2 ring-white dark:ring-[#0b1220]"
          style={{ insetInlineStart: pct(evalMin) }}
          aria-hidden="true"
        />
        {/* marker time labels (above the bar, LTR scale) */}
        <span
          className="absolute top-0 -translate-x-1/2 whitespace-nowrap rounded-full bg-white/90 px-1.5 text-[9.5px] font-extrabold tabular-nums text-slate-500 shadow-sm dark:bg-white/[0.08] dark:text-slate-300"
          style={{ insetInlineStart: pct(windowStart) }}
          dir={idDir}
        >
          {hhmm(windowStart)}
        </span>
        {ordered.map((seg, i) => {
          const graceLeft = Math.max(
            seg.startMin,
            Math.min(seg.startMin + seg.graceMin, seg.endMin)
          );
          return (
            <span
              key={`gl-${i}-${seg.startMin}`}
              className="absolute top-0 -translate-x-1/2 whitespace-nowrap rounded-full bg-amber-500/15 px-1.5 text-[9.5px] font-extrabold tabular-nums text-amber-700 dark:text-amber-300"
              style={{ insetInlineStart: pct(graceLeft) }}
              dir={idDir}
            >
              +{fmtNum(seg.graceMin, lang)}
            </span>
          );
        })}
        <span
          className="absolute top-0 -translate-x-1/2 whitespace-nowrap rounded-full bg-white/90 px-1.5 text-[9.5px] font-extrabold tabular-nums text-slate-500 shadow-sm dark:bg-white/[0.08] dark:text-slate-300"
          style={{ insetInlineStart: pct(windowEnd) }}
          dir={idDir}
        >
          {hhmm(windowEnd)}
        </span>
        <span
          className="absolute top-0 -translate-x-1/2 whitespace-nowrap rounded-full bg-violet-500/15 px-1.5 text-[9.5px] font-extrabold tabular-nums text-violet-700 dark:text-violet-300"
          style={{ insetInlineStart: pct(evalMin) }}
          dir={idDir}
        >
          {hhmm(evalMin)}
        </span>
        {/* the hour scale labels below */}
        {["00:00", "06:00", "12:00", "18:00", "24:00"].map((label, i) => (
          <span
            key={label}
            className="absolute bottom-0 -translate-x-1/2 text-[9px] font-extrabold tabular-nums text-slate-400 dark:text-slate-500"
            style={{ insetInlineStart: `${(i / 4) * 100}%` }}
            dir={idDir}
          >
            {label}
          </span>
        ))}
      </div>

      {/* the legend chips — one per window (+ the grace/eval keys) */}
      <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1.5">
        {ordered.map((seg, i) => (
          <span
            key={`lg-${i}-${seg.startMin}`}
            dir="auto"
            className="inline-flex items-center gap-1.5 text-[10.5px] font-extrabold text-slate-600 dark:text-slate-300"
          >
            <span
              className="h-2.5 w-2.5 rounded-full"
              style={{
                backgroundImage: `linear-gradient(135deg, ${seg.colors[0]}, ${seg.colors[1]})`,
              }}
              aria-hidden="true"
            />
            {seg.label} {hhmm(seg.startMin)}–{hhmm(seg.endMin)}
            <span className="font-bold text-amber-700 dark:text-amber-300">
              +{fmtNum(seg.graceMin, lang)}
            </span>
          </span>
        ))}
        <span dir="auto" className="inline-flex items-center gap-1.5 text-[10.5px] font-extrabold text-amber-700 dark:text-amber-300">
          <span className="h-2.5 w-2.5 rounded-full bg-amber-500" aria-hidden="true" />
          {labels.grace}
        </span>
        <span dir="auto" className="inline-flex items-center gap-1.5 text-[10.5px] font-extrabold text-violet-700 dark:text-violet-300">
          <span className="h-2.5 w-2.5 rounded-full bg-violet-500" aria-hidden="true" />
          {labels.eval}
        </span>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* one دوام shift card                                                 */
/* ------------------------------------------------------------------ */

function ShiftCard({
  draft,
  onChange,
  onRemove,
  error,
  lang,
  t,
}: {
  draft: ShiftDraft;
  onChange: (next: ShiftDraft) => void;
  onRemove: () => void;
  error: string | null;
  lang: Lang;
  t: (key: I18nKey, vars?: Record<string, string | number>) => string;
}) {
  const meta = ATT_SHIFT_META[draft.type];
  const startMin = parseHhmm(draft.start);
  const endMin = parseHhmm(draft.end);
  const coverageFrom = startMin ?? 0;
  /* the required-coverage window rides the shift's start and never reads
   * past its end — the hours live INSIDE the window («ساعات داخل النافذة»). */
  const coverageTo = Math.min(
    coverageFrom + draft.partialHours * 60,
    endMin ?? 1439
  );

  return (
    <div
      className={cn(
        "rounded-2xl border bg-white/60 p-3.5 transition dark:bg-white/[0.03]",
        error
          ? "border-rose-300/70 dark:border-rose-500/30"
          : "border-slate-200/80 dark:border-white/10"
      )}
    >
      {/* header — the type chip trio + the remove button */}
      <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
        <span
          aria-hidden="true"
          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
          style={{ backgroundImage: grad(meta.colors[0], meta.colors[1]) }}
        >
          <CatIcon name={meta.icon} className="h-4 w-4" />
        </span>
        <div
          role="radiogroup"
          aria-label={t("attwsShiftsSection")}
          className="flex min-w-0 flex-1 flex-wrap items-center gap-1.5"
        >
          {ATT_SHIFT_TYPES.map((type) => {
            const active = draft.type === type;
            const typeMeta = ATT_SHIFT_META[type];
            return (
              <button
                key={type}
                type="button"
                role="radio"
                aria-checked={active}
                onClick={() => onChange({ ...draft, type })}
                className={cn(
                  "inline-flex h-9 items-center gap-1.5 rounded-full border px-3 text-[11.5px] font-extrabold transition active:scale-95",
                  active
                    ? typeMeta.chip
                    : "border-slate-200 bg-white/80 text-slate-500 hover:border-slate-300 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-400"
                )}
              >
                <CatIcon name={typeMeta.icon} className="h-3.5 w-3.5" aria-hidden="true" />
                {t(typeMeta.key)}
              </button>
            );
          })}
        </div>
        <Button
          type="button"
          variant="outline"
          onClick={onRemove}
          aria-label={t("attwsShiftRemove")}
          title={t("attwsShiftRemove")}
          className="h-9 gap-1.5 rounded-xl px-2.5 text-[11px] font-bold text-slate-500 hover:border-rose-300 hover:text-rose-600 dark:hover:border-rose-500/40 dark:hover:text-rose-300"
        >
          <CatIcon name="trash-2" className="h-3.5 w-3.5" aria-hidden="true" />
          <span dir="auto" className="hidden sm:inline">{t("attwsShiftRemove")}</span>
        </Button>
      </div>

      {/* body — the window + the grace */}
      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        <label className="flex items-center justify-between gap-3 rounded-xl border border-slate-200/80 bg-slate-50/50 px-3 py-2 dark:border-white/10 dark:bg-white/[0.02]">
          <span dir="auto" className="text-[11px] font-extrabold text-slate-600 dark:text-slate-300">
            {t("attwsShiftStart")}
          </span>
          <input
            type="time"
            dir="ltr"
            value={draft.start}
            onChange={(e) => onChange({ ...draft, start: e.target.value })}
            aria-label={t("attwsShiftStart")}
            className={cn(TIME_INPUT_CLASS, "h-9 w-32 border-0 bg-transparent dark:bg-transparent")}
          />
        </label>
        <label className="flex items-center justify-between gap-3 rounded-xl border border-slate-200/80 bg-slate-50/50 px-3 py-2 dark:border-white/10 dark:bg-white/[0.02]">
          <span dir="auto" className="text-[11px] font-extrabold text-slate-600 dark:text-slate-300">
            {t("attwsShiftEnd")}
          </span>
          <input
            type="time"
            dir="ltr"
            value={draft.end}
            onChange={(e) => onChange({ ...draft, end: e.target.value })}
            aria-label={t("attwsShiftEnd")}
            className={cn(TIME_INPUT_CLASS, "h-9 w-32 border-0 bg-transparent dark:bg-transparent")}
          />
        </label>
      </div>
      <div className="mt-3">
        <p dir="auto" className="mb-1.5 text-[11px] font-extrabold text-slate-600 dark:text-slate-300">
          {t("attwsShiftGrace")}
        </p>
        <GraceControl
          value={draft.graceMin}
          onChange={(graceMin) => onChange({ ...draft, graceMin })}
          unitLabel={t("attwsPolicyMinutes")}
          lang={lang}
        />
      </div>

      {/* PARTIAL — the precise hours stepper + the coverage hint */}
      {draft.type === "partial" ? (
        <div className="mt-3 rounded-xl border border-teal-500/25 bg-teal-500/[0.06] p-3 dark:border-teal-500/20 dark:bg-teal-500/[0.05]">
          <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-2.5">
            <div className="min-w-0">
              <p dir="auto" className="text-[11.5px] font-extrabold text-teal-700 dark:text-teal-300">
                {t("attwsShiftHours")}
              </p>
              <p dir="auto" className="mt-0.5 text-[10.5px] font-semibold leading-relaxed text-teal-600/90 dark:text-teal-300/70">
                {t("attwsShiftHoursHint", { hours: fmtNum(draft.partialHours, lang) })}
              </p>
            </div>
            <div className="flex items-center rounded-xl border border-teal-500/30 bg-white/70 dark:border-teal-500/25 dark:bg-white/[0.05]">
              <Button
                type="button"
                aria-label={`- ${t("attwsShiftHourUnit")}`}
                onClick={() =>
                  onChange({ ...draft, partialHours: Math.max(1, draft.partialHours - 1) })
                }
                className="h-10 w-10 rounded-none rounded-s-xl text-teal-600 transition hover:text-teal-800 active:scale-95 dark:text-teal-300 dark:hover:text-teal-100"
              >
                <CatIcon name="minus" className="h-3.5 w-3.5" aria-hidden="true" />
              </Button>
              <span dir={idDir} className="w-16 text-center font-display text-[14px] font-extrabold tabular-nums text-teal-700 dark:text-teal-200">
                {fmtNum(draft.partialHours, lang)}
              </span>
              <Button
                type="button"
                aria-label={`+ ${t("attwsShiftHourUnit")}`}
                onClick={() =>
                  onChange({ ...draft, partialHours: Math.min(12, draft.partialHours + 1) })
                }
                className="h-10 w-10 rounded-none rounded-e-xl text-teal-600 transition hover:text-teal-800 active:scale-95 dark:text-teal-300 dark:hover:text-teal-100"
              >
                <CatIcon name="plus" className="h-3.5 w-3.5" aria-hidden="true" />
              </Button>
            </div>
          </div>
          <p dir="auto" className="mt-2.5 flex items-center gap-1.5 text-[10.5px] font-bold text-teal-700 dark:text-teal-300/90">
            <CatIcon name="calendar-clock" className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
            {t("attwsShiftCoverage", { from: hhmm(coverageFrom), to: hhmm(coverageTo) })}
          </p>
        </div>
      ) : null}

      {error ? (
        <p role="alert" dir="auto" className="mt-2.5 rounded-lg bg-rose-500/10 px-2.5 py-1.5 text-[11px] font-extrabold text-rose-600 dark:text-rose-300">
          {error}
        </p>
      ) : null}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* the form (fresh-mounted per policy revision via key={updatedAt})    */
/* ------------------------------------------------------------------ */

function PolicyForm({
  instance,
  policy,
}: {
  instance: InstanceDTO;
  policy: AttendancePolicyDTO;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();

  /* the form state — HH:MM strings for the time inputs, minutes for the
   * steppers, the bool for the review toggle, and the دوام cards. */
  const [legacyStart, setLegacyStart] = useState(hhmm(policy.dayStartMin));
  const [legacyEnd, setLegacyEnd] = useState(hhmm(policy.dayEndMin));
  const [graceMin, setGraceMin] = useState(policy.graceMin);
  const [evalTime, setEvalTime] = useState(hhmm(policy.absenceEvalMin));
  const [requireReview, setRequireReview] = useState(policy.requireReview);
  const [shifts, setShifts] = useState<ShiftDraft[]>(() =>
    policy.shifts.map((s) => ({
      type: s.type,
      start: hhmm(s.startMin),
      end: hhmm(s.endMin),
      graceMin: s.graceMin,
      partialHours: s.partialHours ?? DEFAULT_PARTIAL_HOURS,
    }))
  );

  const legacyStartMin = parseHhmm(legacyStart) ?? policy.dayStartMin;
  const legacyEndMin = parseHhmm(legacyEnd) ?? policy.dayEndMin;
  const evalMin = parseHhmm(evalTime) ?? policy.absenceEvalMin;

  /* per-card parses: null (a cleared time input) is INVALID, never a
   * silent fallback — the card says so inline. */
  const cardStarts = shifts.map((s) => parseHhmm(s.start));
  const cardEnds = shifts.map((s) => parseHhmm(s.end));
  const cardWindowErrors = shifts.map((_, i) => {
    const start = cardStarts[i];
    const end = cardEnds[i];
    return start === null || end === null || start >= end;
  });

  /* overlap — mirrors the server's SHIFTS_OVERLAP law on the start-sorted
   * valid cards (an invalid card blocks save on its own error). */
  const overlapErrors = shifts.map(() => false);
  const validSorted = shifts
    .map((draft, i) => ({
      draft,
      i,
      startMin: cardStarts[i] ?? -1,
      endMin: cardEnds[i] ?? -1,
    }))
    .filter((c) => c.startMin >= 0 && c.endMin >= 0)
    .sort((a, b) => a.startMin - b.startMin);
  for (let k = 1; k < validSorted.length; k += 1) {
    if (validSorted[k - 1].endMin > validSorted[k].startMin) {
      overlapErrors[validSorted[k].i] = true;
    }
  }

  const cardError = (i: number): string | null => {
    if (cardWindowErrors[i]) return t("attwsShiftErrWindow");
    if (overlapErrors[i]) return t("attwsShiftErrOverlap");
    return null;
  };

  /* the payload's shift list — start-sorted, partialHours on partials ONLY
   * (the server zod rejects it anywhere else). */
  const payloadShifts: AttendanceShiftDTO[] = validSorted.map((c) => ({
    type: c.draft.type,
    startMin: c.startMin,
    endMin: c.endMin,
    graceMin: c.draft.graceMin,
    ...(c.draft.type === "partial" ? { partialHours: c.draft.partialHours } : {}),
  }));

  /* THE LEGACY BINDING — with shifts the first/last window drives the
   * legacy columns (invisible to the user; the server stamps the same
   * values). Without shifts the user's own window fields persist. */
  const inShiftMode = payloadShifts.length > 0;
  const dayStartMin = inShiftMode ? payloadShifts[0].startMin : legacyStartMin;
  const dayEndMin = inShiftMode
    ? payloadShifts[payloadShifts.length - 1].endMin
    : legacyEndMin;
  const payloadGrace = inShiftMode ? payloadShifts[0].graceMin : graceMin;

  /* validation mirrors the server zod cross-field law — inline,
   * bilingual, BEFORE any submit. */
  const windowError =
    !inShiftMode && legacyStartMin >= legacyEndMin ? t("attwsPolicyErrWindow") : null;
  const shiftErrors = shifts.map((_, i) => cardError(i));
  const evalError =
    !windowError && evalMin < dayEndMin ? t("attwsPolicyErrEval") : null;
  const invalid =
    windowError !== null || evalError !== null || shiftErrors.some((e) => e !== null);

  const changed =
    JSON.stringify(payloadShifts) !== JSON.stringify(policy.shifts) ||
    dayStartMin !== policy.dayStartMin ||
    dayEndMin !== policy.dayEndMin ||
    payloadGrace !== policy.graceMin ||
    evalMin !== policy.absenceEvalMin ||
    requireReview !== policy.requireReview;

  const saveMutation = useMutation({
    mutationFn: () =>
      updateAttendancePolicy(instance.id, {
        dayStartMin,
        dayEndMin,
        graceMin: payloadGrace,
        absenceEvalMin: evalMin,
        requireReview,
        /* always EXPLICIT — [] is the deliberate return to the single
         * window; undefined would keep the stored schedule. */
        shifts: payloadShifts,
      }),
    onSuccess: () => {
      toast.success(t("attwsPolicySavedToast"));
    },
    onError: (error: Error) => {
      const key = attErrorKey(error);
      toast.error(
        key ? t(key) : error instanceof ApiError ? error.message : t("attwsErrGeneric")
      );
    },
    onSettled: () => {
      /* the policy re-derives EVERYTHING — board, feed, allowances */
      void queryClient.invalidateQueries({ queryKey: ["attendance-policy", instance.id] });
      void queryClient.invalidateQueries({ queryKey: ["attendance-roster", instance.id] });
      void queryClient.invalidateQueries({ queryKey: ["attendance-movements", instance.id] });
    },
  });

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (invalid || !changed) return;
    saveMutation.mutate();
  };

  /* the دوام mode transitions */
  const customize = () => {
    const seedType: AttShiftType = legacyStartMin < 720 ? "morning" : "evening";
    setShifts([
      {
        type: seedType,
        start: legacyStart,
        end: legacyEnd,
        graceMin,
        partialHours: DEFAULT_PARTIAL_HOURS,
      },
    ]);
  };
  const addShift = () => {
    if (shifts.length >= MAX_SHIFTS) return;
    const seed =
      SHIFT_SEEDS[shifts.length] ?? SHIFT_SEEDS[SHIFT_SEEDS.length - 1] ?? {
        type: "morning",
        start: "08:00",
        end: "15:00",
      };
    setShifts((prev) => [
      ...prev,
      { ...seed, graceMin: 10, partialHours: DEFAULT_PARTIAL_HOURS },
    ]);
  };
  const removeShift = (index: number) => {
    const target = shifts[index];
    if (shifts.length <= 1 && target) {
      /* removing the LAST card returns to the single-window editor,
         seeded from that card's own values. */
      const start = parseHhmm(target.start);
      const end = parseHhmm(target.end);
      if (start !== null) setLegacyStart(hhmm(start));
      if (end !== null) setLegacyEnd(hhmm(end));
      setGraceMin(target.graceMin);
      setShifts([]);
      return;
    }
    setShifts((prev) => prev.filter((_, i) => i !== index));
  };

  /* the policy-level rows — shared verbatim by both modes (the eval time
   * input + the review Switch) so their markup lives in exactly one place. */
  const evalRow = (
    <PolicyRow
      icon="calendar-clock"
      label={t("attwsPolicyEval")}
      hint={t("attwsPolicyEvalHint")}
      error={evalError}
    >
      <input
        type="time"
        dir="ltr"
        value={evalTime}
        onChange={(e) => setEvalTime(e.target.value)}
        aria-label={t("attwsPolicyEval")}
        className={TIME_INPUT_CLASS}
      />
    </PolicyRow>
  );
  const reviewRow = (
    <PolicyRow
      icon="shield-check"
      label={t("attwsPolicyRequireReview")}
      hint={t("attwsPolicyRequireReviewHint")}
    >
      <div className="flex items-center gap-2.5">
        <Label htmlFor="attws-require-review" className="sr-only">
          {t("attwsPolicyRequireReview")}
        </Label>
        <Switch
          id="attws-require-review"
          tone="brand"
          checked={requireReview}
          onCheckedChange={setRequireReview}
        />
      </div>
    </PolicyRow>
  );

  /* the timeline's segments — the legacy window, or one gradient segment
   * per دوام in its type's color family (start-sorted by the renderer). */
  const timelineSegments: readonly TlSegment[] =
    payloadShifts.length > 0
      ? payloadShifts.map((s) => ({
          startMin: s.startMin,
          endMin: s.endMin,
          graceMin: s.graceMin,
          colors: ATT_SHIFT_META[s.type].colors,
          label: t(ATT_SHIFT_META[s.type].key),
        }))
      : [
          {
            startMin: dayStartMin,
            endMin: dayEndMin,
            graceMin: payloadGrace,
            colors: ATT_C,
            label: t("attwsPolicyTlDay"),
          },
        ];

  /* the معاينة strip — shift-aware copy in shift mode (the FIRST window
   * is the primary دوام; multi-window schedules add the gap law line). */
  const firstShift = payloadShifts[0] ?? null;
  const firstGraceEdge = firstShift
    ? Math.min(1439, firstShift.startMin + firstShift.graceMin)
    : Math.min(1439, dayStartMin + payloadGrace);

  return (
    <form onSubmit={submit} noValidate className="space-y-4">
      {/* the live 24h timeline — the centerpiece */}
      <div className="space-y-2">
        <p dir="auto" className="flex items-center gap-2 text-[11px] font-extrabold uppercase text-slate-500 dark:text-slate-400">
          <CatIcon name="clock-rotate-left" className="h-3.5 w-3.5 text-brand-500" aria-hidden="true" />
          {t("attwsPolicyTimeline")}
        </p>
        <PolicyTimeline
          segments={timelineSegments}
          evalMin={evalMin}
          lang={lang}
          labels={{
            grace: t("attwsPolicyTlGrace"),
            eval: t("attwsPolicyTlEval"),
          }}
        />
      </div>

      {inShiftMode ? (
        /* ---------------------- the دوام manager ---------------------- */
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5">
            <p dir="auto" className="flex items-center gap-2 text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
              <CatIcon name="layers" className="h-4 w-4 text-brand-500" aria-hidden="true" />
              {t("attwsShiftsSection")}
            </p>
            <p dir="auto" className="text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
              {t("attwsShiftsSectionHint")}
            </p>
            <span className="ms-auto" />
            {shifts.length < MAX_SHIFTS ? (
              <Button
                type="button"
                variant="outline"
                onClick={addShift}
                className="h-9 gap-1.5 rounded-xl px-3 text-[11.5px] font-extrabold text-brand-600 hover:border-brand-300 dark:text-brand-300 dark:hover:border-brand-500/40"
              >
                <CatIcon name="plus" className="h-3.5 w-3.5" aria-hidden="true" />
                {t("attwsShiftAdd")}
              </Button>
            ) : (
              <span dir="auto" className="text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                {t("attwsShiftsMax")}
              </span>
            )}
          </div>
          {shifts.map((draft, i) => (
            <ShiftCard
              key={`shift-${i}`}
              draft={draft}
              onChange={(next) =>
                setShifts((prev) => prev.map((s, k) => (k === i ? next : s)))
              }
              onRemove={() => removeShift(i)}
              error={shiftErrors[i] ?? null}
              lang={lang}
              t={t}
            />
          ))}
        </div>
      ) : (
        /* ---------------- the legacy single-window editor ---------------- */
        <div className="grid gap-3 lg:grid-cols-2">
          <PolicyRow
            icon="sun-medium"
            label={t("attwsPolicyDayStart")}
            hint={t("attwsPolicyDayStartHint")}
            error={windowError}
          >
            <input
              type="time"
              dir="ltr"
              value={legacyStart}
              onChange={(e) => setLegacyStart(e.target.value)}
              aria-label={t("attwsPolicyDayStart")}
              className={TIME_INPUT_CLASS}
            />
          </PolicyRow>
          <PolicyRow
            icon="moon"
            label={t("attwsPolicyDayEnd")}
            hint={t("attwsPolicyDayEndHint")}
            error={windowError}
          >
            <input
              type="time"
              dir="ltr"
              value={legacyEnd}
              onChange={(e) => setLegacyEnd(e.target.value)}
              aria-label={t("attwsPolicyDayEnd")}
              className={TIME_INPUT_CLASS}
            />
          </PolicyRow>
          <PolicyRow
            icon="hourglass"
            label={t("attwsPolicyGrace")}
            hint={t("attwsPolicyGraceHint")}
          >
            <GraceControl
              value={graceMin}
              onChange={setGraceMin}
              unitLabel={t("attwsPolicyMinutes")}
              lang={lang}
            />
          </PolicyRow>
          {evalRow}
        </div>
      )}

      {/* the policy-level rows — in shift mode the eval + review ride their
       * own grid under the cards; in legacy mode the eval already sits in
       * the window grid and the review toggle keeps its full-width row. */}
      {inShiftMode ? (
        <div className="grid gap-3 lg:grid-cols-2">
          {evalRow}
          {reviewRow}
        </div>
      ) : (
        reviewRow
      )}

      {/* the single-window → دوام upgrade CTA (legacy mode only) */}
      {!inShiftMode ? (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white/40 p-3.5 dark:border-white/15 dark:bg-white/[0.02]">
          <div className="flex flex-wrap items-center gap-x-4 gap-y-3">
            <span
              aria-hidden="true"
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
              style={{ backgroundImage: grad(ATT_SHIFT_META.morning.colors[0], ATT_SHIFT_META.evening.colors[1]) }}
            >
              <CatIcon name="sunrise" className="h-4 w-4" />
            </span>
            <div className="min-w-0 flex-1">
              <p dir="auto" className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                {t("attwsShiftCustomize")}
              </p>
              <p dir="auto" className="mt-0.5 max-w-md text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                {t("attwsShiftCustomizeHint")}
              </p>
            </div>
            <Button
              type="button"
              onClick={customize}
              className="h-10 gap-2 rounded-xl px-4 text-[12px] font-extrabold text-white shadow-md transition hover:brightness-110 active:scale-95"
              style={{ backgroundImage: grad(ATT_SHIFT_META.morning.colors[0], ATT_SHIFT_META.evening.colors[1]) }}
            >
              <CatIcon name="sliders" className="h-3.5 w-3.5" aria-hidden="true" />
              {t("attwsShiftCustomize")}
            </Button>
          </div>
        </div>
      ) : null}

      {/* the معاينة strip — recomputes live from the CURRENT form values */}
      <div className="rounded-2xl border border-slate-200/80 bg-linear-to-l from-indigo-50/70 to-violet-50/40 p-3.5 dark:border-white/10 dark:from-indigo-500/[0.07] dark:to-violet-500/[0.04]">
        <p dir="auto" className="flex items-center gap-2 text-[11px] font-extrabold uppercase text-slate-500 dark:text-slate-400">
          <CatIcon name="eye" className="h-3.5 w-3.5 text-brand-500" aria-hidden="true" />
          {t("attwsPolicyPreview")}
        </p>
        <div
          className={cn(
            "mt-2 grid gap-1.5",
            inShiftMode && payloadShifts.length > 1
              ? "sm:grid-cols-2 lg:grid-cols-4"
              : "sm:grid-cols-3"
          )}
        >
          {inShiftMode && firstShift ? (
            <>
              <p dir="auto" className="flex items-start gap-1.5 text-[11.5px] font-bold leading-relaxed text-emerald-700 dark:text-emerald-300">
                <CatIcon name="circle-check" className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                {t("attwsPolicyPreviewPresentShift", {
                  time: hhmm(firstGraceEdge),
                  shift: t(ATT_SHIFT_META[firstShift.type].key),
                })}
              </p>
              <p dir="auto" className="flex items-start gap-1.5 text-[11.5px] font-bold leading-relaxed text-amber-700 dark:text-amber-300">
                <CatIcon name="clock" className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                {t("attwsPolicyPreviewLateShift", {
                  time: hhmm(firstGraceEdge),
                  shift: t(ATT_SHIFT_META[firstShift.type].key),
                })}
              </p>
              {payloadShifts.length > 1 ? (
                <p dir="auto" className="flex items-start gap-1.5 text-[11.5px] font-bold leading-relaxed text-sky-700 dark:text-sky-300">
                  <CatIcon name="arrow-left-right" className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                  {t("attwsPolicyPreviewGap")}
                </p>
              ) : null}
            </>
          ) : (
            <>
              <p dir="auto" className="flex items-start gap-1.5 text-[11.5px] font-bold leading-relaxed text-emerald-700 dark:text-emerald-300">
                <CatIcon name="circle-check" className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                {t("attwsPolicyPreviewPresent", { time: hhmm(firstGraceEdge) })}
              </p>
              <p dir="auto" className="flex items-start gap-1.5 text-[11.5px] font-bold leading-relaxed text-amber-700 dark:text-amber-300">
                <CatIcon name="clock" className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                {t("attwsPolicyPreviewLate", { time: hhmm(firstGraceEdge) })}
              </p>
            </>
          )}
          <p dir="auto" className="flex items-start gap-1.5 text-[11.5px] font-bold leading-relaxed text-violet-700 dark:text-violet-300">
            <CatIcon name="calendar-clock" className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" />
            {t("attwsPolicyPreviewEval", { time: hhmm(evalMin) })}
          </p>
        </div>
      </div>

      {/* save — disabled while unchanged or invalid */}
      <div className="flex items-center justify-end gap-3">
        <Button
          type="submit"
          disabled={!changed || invalid || saveMutation.isPending}
          className="h-11 gap-2 rounded-xl px-6 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:pointer-events-none disabled:opacity-40"
          style={{ backgroundImage: grad(ATT_C[0], ATT_C[1]) }}
        >
          {saveMutation.isPending ? (
            <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" aria-hidden="true" />
          ) : (
            <CatIcon name="save" className="h-4 w-4" aria-hidden="true" />
          )}
          {t("attwsPolicySave")}
        </Button>
      </div>
    </form>
  );
}

/* ------------------------------------------------------------------ */
/* the tab shell                                                       */
/* ------------------------------------------------------------------ */

export function AttendancePolicyTab({ instance }: { instance: InstanceDTO }) {
  const { t } = useT();

  const policyQuery = useQuery({
    queryKey: ["attendance-policy", instance.id],
    queryFn: () => fetchAttendancePolicy(instance.id),
    staleTime: 30_000,
    retry: 0,
  });
  const policy = policyQuery.data ?? null;

  return (
    <DashCard title={t("attwsPolicyTitle")} icon="sliders">
      <p dir="auto" className="mb-4 text-[11.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
        {t("attwsPolicyDesc")}
      </p>

      {policyQuery.isError && !policy ? (
        <div className="flex min-h-24 flex-col items-center justify-center gap-2 text-center">
          <CatIcon name="circle-alert" className="h-6 w-6 text-rose-400" aria-hidden="true" />
          <p className="text-[12px] font-bold text-slate-500 dark:text-slate-400">{t("attwsLoadErr")}</p>
          <Button
            type="button"
            variant="outline"
            onClick={() => void policyQuery.refetch()}
            className="h-9 rounded-xl px-3 text-[11.5px] font-bold"
          >
            {t("attwsRefresh")}
          </Button>
        </div>
      ) : policyQuery.isPending && !policy ? (
        <div className="space-y-3">
          <div className="h-28 animate-pulse rounded-2xl bg-slate-100 dark:bg-white/5" />
          <div className="grid gap-3 lg:grid-cols-2">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-20 animate-pulse rounded-2xl bg-slate-100 dark:bg-white/5" />
            ))}
          </div>
        </div>
      ) : policy ? (
        /* keyed by updatedAt — every save is a FRESH form mount (the
         * server's new values seed the state, no stale sync effects). */
        <PolicyForm key={policy.updatedAt} instance={instance} policy={policy} />
      ) : null}
    </DashCard>
  );
}
