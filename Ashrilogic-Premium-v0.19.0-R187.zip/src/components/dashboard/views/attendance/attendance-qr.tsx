"use client";

/**
 * Ashrilogic — ROUND 166 (Task 6-b): tab 5 of the attendance workspace —
 * رمز QR (the gate movement QR).
 *
 * The mint form: the searchable student picker (the shared roster cache),
 * the direction toggle (دخول/خروج), the optional gate label (≤40) and the
 * TTL chips (60/120/300 ثانية — the server clamps 30..300). On mint the
 * QR renders LARGE inside a premium card with a live countdown ring to
 * expiry; the raw token sits below (mono, copyable) and «محاكاة المسح»
 * POSTs qr/redeem — exercising the full kiosk loop from the console:
 * success shows the recorded movement toast, 410s surface the
 * expired/reused errors. A 3-step explainer closes the tab.
 *
 * The QR itself is generated CLIENT-SIDE with the isomorphic `qrcode`
 * package (dynamic import — the browser build renders to a canvas
 * data-URL); the token remains single-use and sha256-hashed server-side.
 */
import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { useT } from "@/lib/i18n";
import type { InstanceDTO } from "@/lib/types";
import type { AttendanceQrMintDTO } from "@/lib/types";
import {
  ApiError,
  fetchAttendanceRoster,
  mintAttendanceQr,
  redeemAttendanceQr,
} from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, idDir } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DashCard } from "@/components/dashboard/dash-shared";
import { AttStudentPicker, attErrorKey } from "./attendance-shared";

const ATT_C = ["#6366f1", "#7c3aed"] as const;

/** TTL presets (seconds) — the server clamps 30..300. */
const TTL_CHIPS: readonly number[] = [60, 120, 300];

/* ------------------------------------------------------------------ */
/* the countdown ring (SVG, CSS transition — restrained motion)        */
/* ------------------------------------------------------------------ */

function CountdownRing({
  secondsLeft,
  totalSeconds,
}: {
  secondsLeft: number;
  totalSeconds: number;
}) {
  const expired = secondsLeft <= 0;
  const ratio = Math.max(0, Math.min(1, totalSeconds > 0 ? secondsLeft / totalSeconds : 0));
  /* r=20 → circumference 125.66 */
  const C = 2 * Math.PI * 20;
  return (
    <svg viewBox="0 0 48 48" className="h-12 w-12 shrink-0" role="presentation" aria-hidden="true">
      <circle cx="24" cy="24" r="20" fill="none" strokeWidth="4" className="stroke-slate-200 dark:stroke-white/10" />
      <circle
        cx="24"
        cy="24"
        r="20"
        fill="none"
        strokeWidth="4"
        strokeLinecap="round"
        className={cn(
          "transition-[stroke-dashoffset] duration-1000 ease-linear",
          expired ? "stroke-rose-500" : ratio > 0.35 ? "stroke-emerald-500" : "stroke-amber-500"
        )}
        strokeDasharray={C}
        strokeDashoffset={C * (1 - ratio)}
        transform="rotate(-90 24 24)"
      />
      <text
        x="24"
        y="24"
        textAnchor="middle"
        dominantBaseline="central"
        className={cn(
          "fill-slate-700 text-[13px] font-extrabold tabular-nums dark:fill-slate-200",
          expired && "fill-rose-500 dark:fill-rose-400"
        )}
      >
        {expired ? "0" : String(Math.min(999, secondsLeft))}
      </text>
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/* the minted QR card                                                  */
/* ------------------------------------------------------------------ */

function MintedQrCard({
  instance,
  mint,
  ttlSeconds,
}: {
  instance: InstanceDTO;
  mint: AttendanceQrMintDTO;
  ttlSeconds: number;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const [dataUrl, setDataUrl] = useState<string | null>(null);
  const [qrError, setQrError] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(() =>
    Math.max(0, Math.ceil((new Date(mint.expiresAt).getTime() - Date.now()) / 1000))
  );
  const [consumed, setConsumed] = useState(false);

  /* render the QR client-side (isomorphic qrcode — browser canvas build) */
  useEffect(() => {
    let alive = true;
    setQrError(false);
    setDataUrl(null);
    void (async () => {
      try {
        const mod = await import("qrcode");
        const render = mod.toDataURL ?? mod.default.toDataURL;
        const url = await render(mint.qrPayload, {
          width: 512,
          margin: 2,
          color: { dark: "#312e81", light: "#ffffff" },
          errorCorrectionLevel: "M",
        });
        if (alive) setDataUrl(url);
      } catch {
        if (alive) setQrError(true);
      }
    })();
    return () => {
      alive = false;
    };
  }, [mint.qrPayload]);

  /* the live countdown (1s tick; stops at zero) */
  useEffect(() => {
    const id = window.setInterval(() => {
      setSecondsLeft(Math.max(0, Math.ceil((new Date(mint.expiresAt).getTime() - Date.now()) / 1000)));
    }, 1000);
    return () => window.clearInterval(id);
  }, [mint.expiresAt]);

  const expired = secondsLeft <= 0;

  const redeemMutation = useMutation({
    mutationFn: () => redeemAttendanceQr(instance.id, mint.token),
    onSuccess: (result) => {
      setConsumed(true);
      toast.success(
        t("attwsQrRedeemOk", {
          name: result.movement.studentName,
          dir: result.movement.direction === "in" ? t("attwsDirIn") : t("attwsDirOut"),
        })
      );
    },
    onError: (error: Error) => {
      const key = attErrorKey(error);
      toast.error(
        key ? t(key) : error instanceof ApiError ? error.message : t("attwsErrGeneric")
      );
      /* a 410/404 means the token is dead for good — mark consumed */
      if (error instanceof ApiError && (error.status === 410 || error.status === 404)) {
        setConsumed(true);
      }
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: ["attendance-roster", instance.id] });
      void queryClient.invalidateQueries({ queryKey: ["attendance-movements", instance.id] });
    },
  });

  const copyToken = async () => {
    try {
      await navigator.clipboard.writeText(mint.token);
      toast.success(t("attwsQrCopied"));
    } catch {
      toast.error(t("attwsErrGeneric"));
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.97 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.25 }}
      className={cn(
        "rounded-2xl border p-4",
        consumed
          ? "border-emerald-300/70 bg-emerald-50/50 dark:border-emerald-500/25 dark:bg-emerald-500/[0.06]"
          : expired
            ? "border-rose-300/70 bg-rose-50/40 dark:border-rose-500/25 dark:bg-rose-500/[0.05]"
            : "border-slate-200/80 bg-white/70 dark:border-white/10 dark:bg-white/[0.03]"
      )}
    >
      <div className="flex flex-wrap items-center gap-3">
        <CountdownRing secondsLeft={secondsLeft} totalSeconds={ttlSeconds} />
        <div className="min-w-0 flex-1">
          <p dir="auto" className="text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
            {consumed
              ? t("attwsQrConsumed")
              : expired
                ? t("attwsQrExpired")
                : t("attwsQrExpiresIn", { sec: fmtNum(secondsLeft, lang) })}
          </p>
          <p dir="auto" className="mt-0.5 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
            {t("attwsQrScanPrompt")}
          </p>
        </div>
      </div>

      {/* the QR — LARGE (256px), white quiet-zone card */}
      <div className="mt-3 flex justify-center">
        <div className="rounded-2xl bg-white p-3 shadow-lg ring-1 ring-slate-900/5 dark:ring-white/10">
          {dataUrl ? (
            <img src={dataUrl} alt={t("attwsQrTitle")} width={256} height={256} className={cn("h-64 w-64", (expired || consumed) && "opacity-40 grayscale")} />
          ) : qrError ? (
            <div className="grid h-64 w-64 place-items-center text-center">
              <div className="space-y-1.5">
                <CatIcon name="qr-code" className="mx-auto h-8 w-8 text-slate-300" aria-hidden="true" />
                <p className="text-[11px] font-bold text-slate-400">{t("attwsLoadErr")}</p>
              </div>
            </div>
          ) : (
            <div className="grid h-64 w-64 place-items-center">
              <CatIcon name="refresh-cw" className="h-6 w-6 animate-spin text-slate-300" aria-hidden="true" />
            </div>
          )}
        </div>
      </div>

      {/* the raw token (mono, copyable) */}
      <div className="mt-3 flex items-center gap-2">
        <span dir="auto" className="shrink-0 text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500">
          {t("attwsQrToken")}
        </span>
        <code
          dir={idDir}
          title={mint.token}
          className="min-w-0 flex-1 truncate rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-[10.5px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-300"
        >
          {mint.token}
        </code>
        <Button
          type="button"
          variant="outline"
          onClick={() => void copyToken()}
          className="h-9 shrink-0 gap-1.5 rounded-lg px-2.5 text-[11px] font-bold"
        >
          <CatIcon name="copy" className="h-3.5 w-3.5" aria-hidden="true" />
          {t("attwsQrCopy")}
        </Button>
      </div>

      {/* simulate the gate scan — the kiosk loop from the console */}
      <div className="mt-3 flex justify-center">
        <Button
          type="button"
          onClick={() => redeemMutation.mutate()}
          disabled={expired || consumed || redeemMutation.isPending}
          className="h-11 gap-2 rounded-xl px-6 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:pointer-events-none disabled:opacity-40"
          style={{ backgroundImage: grad(ATT_C[0], ATT_C[1]) }}
        >
          {redeemMutation.isPending ? (
            <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" aria-hidden="true" />
          ) : (
            <CatIcon name="scan-line" className="h-4 w-4" aria-hidden="true" />
          )}
          {t("attwsQrSimulate")}
        </Button>
      </div>
    </motion.div>
  );
}

/* ------------------------------------------------------------------ */
/* the tab                                                             */
/* ------------------------------------------------------------------ */

export function AttendanceQrTab({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();

  /* the shared roster cache (deduped with the today board) */
  const rosterQuery = useQuery({
    queryKey: ["attendance-roster", instance.id],
    queryFn: () => fetchAttendanceRoster(instance.id),
    staleTime: 30_000,
    retry: 0,
  });
  const rows = useMemo(() => rosterQuery.data?.rows ?? [], [rosterQuery.data]);

  const [studentCode, setStudentCode] = useState<string | null>(null);
  const [direction, setDirection] = useState<"in" | "out">("in");
  const [gateLabel, setGateLabel] = useState("");
  const [ttl, setTtl] = useState(120);
  const [mint, setMint] = useState<AttendanceQrMintDTO | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  const selected = useMemo(
    () => rows.find((r) => r.studentCode === studentCode) ?? null,
    [rows, studentCode]
  );

  const mintMutation = useMutation({
    mutationFn: (payload: {
      studentCode: string;
      direction: "in" | "out";
      gateLabel?: string;
      ttlSeconds?: number;
    }) => mintAttendanceQr(instance.id, payload),
    onSuccess: (data) => {
      setMint(data);
      setFormError(null);
    },
    onError: (error: Error) => {
      const key = attErrorKey(error);
      toast.error(
        key ? t(key) : error instanceof ApiError ? error.message : t("attwsErrGeneric")
      );
    },
  });

  const mintNow = () => {
    if (!studentCode) {
      setFormError(t("attwsAllowErrStudent"));
      return;
    }
    setFormError(null);
    mintMutation.mutate({
      studentCode,
      direction,
      ...(gateLabel.trim() ? { gateLabel: gateLabel.trim().slice(0, 40) } : {}),
      ttlSeconds: ttl,
    });
  };

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      {/* ---------------- the mint form ---------------- */}
      <DashCard title={t("attwsQrTitle")} icon="qr-code">
        <p dir="auto" className="mb-4 text-[11.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
          {t("attwsQrDesc")}
        </p>

        <div className="space-y-4">
          {/* student picker */}
          <div className="space-y-1.5">
            <Label className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
              <CatIcon name="user-round" className="h-3 w-3 text-brand-500" aria-hidden="true" />
              {t("attwsStudent")}
            </Label>
            <AttStudentPicker
              rows={rows}
              value={studentCode}
              onChange={setStudentCode}
              searchPhKey="attwsAllowSearchPh"
              pickLabelKey="attwsAllowPickStudent"
              emptyKey="attwsEmptyFiltered"
              c1={ATT_C[0]}
              c2={ATT_C[1]}
            />
            {selected ? (
              <p dir="auto" className="text-[10.5px] font-bold text-emerald-600 dark:text-emerald-400">
                {selected.name} · {selected.room}
              </p>
            ) : null}
          </div>

          {/* direction toggle */}
          <div className="space-y-1.5">
            <Label className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
              <CatIcon name="log-in" className="h-3 w-3 text-brand-500" aria-hidden="true" />
              {t("attwsQrDirection")}
            </Label>
            <div
              role="group"
              aria-label={t("attwsQrDirection")}
              className="grid grid-cols-2 gap-1 rounded-xl border border-slate-200 bg-slate-50 p-1 dark:border-white/10 dark:bg-white/[0.04]"
            >
              {(["in", "out"] as const).map((dir) => {
                const active = direction === dir;
                return (
                  <button
                    key={dir}
                    type="button"
                    aria-pressed={active}
                    onClick={() => setDirection(dir)}
                    className={cn(
                      "flex h-11 items-center justify-center gap-1.5 rounded-lg text-[12px] font-extrabold transition",
                      active
                        ? dir === "in"
                          ? "bg-linear-to-r from-emerald-500 to-emerald-600 text-white shadow-md"
                          : "bg-linear-to-r from-rose-500 to-rose-600 text-white shadow-md"
                        : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white"
                    )}
                  >
                    <CatIcon name={dir === "in" ? "log-in" : "log-out"} className="h-3.5 w-3.5" aria-hidden="true" />
                    {dir === "in" ? t("attwsDirIn") : t("attwsDirOut")}
                  </button>
                );
              })}
            </div>
          </div>

          {/* gate label */}
          <div className="space-y-1.5">
            <Label
              htmlFor="attws-qr-gate"
              className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
            >
              <CatIcon name="door-open" className="h-3 w-3 text-brand-500" aria-hidden="true" />
              {t("attwsQrGate")}
            </Label>
            <Input
              id="attws-qr-gate"
              type="text"
              value={gateLabel}
              maxLength={40}
              onChange={(e) => setGateLabel(e.target.value)}
              placeholder={t("attwsQrGatePh")}
              className="h-10 rounded-xl text-[12.5px] font-semibold"
            />
          </div>

          {/* TTL chips */}
          <div className="space-y-1.5">
            <Label className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
              <CatIcon name="timer" className="h-3 w-3 text-brand-500" aria-hidden="true" />
              {t("attwsQrTtl")}
            </Label>
            <div className="flex items-center gap-2">
              {TTL_CHIPS.map((chip) => (
                <button
                  key={chip}
                  type="button"
                  aria-pressed={ttl === chip}
                  onClick={() => setTtl(chip)}
                  className={cn(
                    "inline-flex h-11 min-w-[64px] items-center justify-center gap-1 rounded-xl border px-3 text-[12px] font-extrabold tabular-nums transition",
                    ttl === chip
                      ? "border-transparent bg-linear-to-r from-indigo-500 to-violet-500 text-white shadow-md"
                      : "border-slate-200 bg-white/80 text-slate-500 hover:border-slate-300 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-400"
                  )}
                >
                  {fmtNum(chip, lang)}
                  <span className="text-[9.5px] font-bold opacity-80">{t("attwsQrSeconds")}</span>
                </button>
              ))}
            </div>
          </div>

          {formError ? (
            <p role="alert" className="rounded-xl bg-rose-500/10 px-3 py-2 text-[11.5px] font-extrabold text-rose-600 dark:text-rose-300">
              {formError}
            </p>
          ) : null}

          <Button
            type="button"
            onClick={mintNow}
            disabled={mintMutation.isPending}
            className="h-11 w-full gap-2 rounded-xl text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95"
            style={{ backgroundImage: grad(ATT_C[0], ATT_C[1]) }}
          >
            {mintMutation.isPending ? (
              <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" aria-hidden="true" />
            ) : (
              <CatIcon name="qr-code" className="h-4 w-4" aria-hidden="true" />
            )}
            {t("attwsQrMint")}
          </Button>
        </div>
      </DashCard>

      {/* ---------------- the minted QR + the explainer ---------------- */}
      <div className="space-y-4">
        <DashCard title={t("attwsQrTitle")} icon="scan-line">
          {mint ? (
            <MintedQrCard instance={instance} mint={mint} ttlSeconds={ttl} />
          ) : (
            <div className="flex h-64 flex-col items-center justify-center gap-2 text-center">
              <CatIcon name="qr-code" className="h-10 w-10 text-slate-300 dark:text-slate-600" aria-hidden="true" />
              <p dir="auto" className="max-w-xs text-[11.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                {t("attwsQrDesc")}
              </p>
            </div>
          )}
        </DashCard>

        {/* كيف يعمل — the 3-step explainer */}
        <DashCard title={t("attwsQrHowTitle")} icon="info">
          <ol className="space-y-2.5">
            {[
              { key: "attwsQrHow1" as const, icon: "user-check" },
              { key: "attwsQrHow2" as const, icon: "qr-code" },
              { key: "attwsQrHow3" as const, icon: "scan-line" },
            ].map((step, i) => (
              <li key={step.key} className="flex items-start gap-2.5">
                <span
                  aria-hidden="true"
                  className="grid h-6 w-6 shrink-0 place-items-center rounded-full text-[10px] font-extrabold text-white"
                  style={{ backgroundImage: grad(ATT_C[0], ATT_C[1]) }}
                >
                  {fmtNum(i + 1, lang)}
                </span>
                <span dir="auto" className="flex items-start gap-1.5 pt-0.5 text-[11.5px] font-bold leading-relaxed text-slate-600 dark:text-slate-300">
                  <CatIcon name={step.icon} className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand-500" aria-hidden="true" />
                  {t(step.key)}
                </span>
              </li>
            ))}
          </ol>
        </DashCard>
      </div>
    </div>
  );
}
