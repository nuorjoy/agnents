"use client";

/**
 * Ashrilogic — ROUND 166 (Task 6-b): tab 3 of the attendance workspace —
 * الأذونات والإجازات (allowances & leaves).
 *
 * The active + upcoming windows (GET allowances — soonest first): each
 * row carries the student, the kind pill (excused/authorized/leave/
 * outside — color-coded), the window, the note and a delete action with
 * an AlertDialog confirm. "إضافة إذن" opens the premium dialog: the
 * searchable student picker (the shared roster cache), the kind select,
 * the start/end datetime inputs (PremiumDateInput) and the note — POST
 * with an optimistic list update + bilingual code toasts.
 */
import { useMemo, useState, type FormEvent } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { useT } from "@/lib/i18n";
import type { InstanceDTO } from "@/lib/types";
import type { AttendanceAllowanceDTO } from "@/lib/types";
import {
  ApiError,
  createAttendanceAllowance,
  deleteAttendanceAllowance,
  fetchAttendanceAllowances,
  fetchAttendanceRoster,
} from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, grad, idDir } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { PremiumDateInput } from "@/components/ui/premium-date-input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { DashCard, fullDate } from "@/components/dashboard/dash-shared";
import {
  ATT_KINDS,
  ATT_KIND_META,
  ATT_TONE_DOT,
  type AttAllowanceKind,
  AttStudentPicker,
  attErrorKey,
} from "./attendance-shared";

const ATT_C = ["#6366f1", "#7c3aed"] as const;

/* local tone styles for kind pills (mirror the state pill grammar) */
const ATT_TONE_STYLE: Record<string, string> = {
  emerald: "bg-emerald-500/12 text-emerald-700 dark:text-emerald-300",
  amber: "bg-amber-500/12 text-amber-700 dark:text-amber-300",
  rose: "bg-rose-500/12 text-rose-700 dark:text-rose-300",
  sky: "bg-sky-500/12 text-sky-700 dark:text-sky-300",
  violet: "bg-violet-500/12 text-violet-700 dark:text-violet-300",
  teal: "bg-teal-500/12 text-teal-700 dark:text-teal-300",
  slate: "bg-slate-500/12 text-slate-600 dark:text-slate-300",
};

/* ------------------------------------------------------------------ */
/* the add-allowance dialog                                            */
/* ------------------------------------------------------------------ */

/** local "yyyy-mm-ddThh:mm" for datetime-local defaults (now + hours). */
function localDateTime(offsetHours = 0): string {
  const d = new Date(Date.now() + offsetHours * 3_600_000);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function AttDialogHeader({
  title,
  desc,
}: {
  title: string;
  desc: string;
}) {
  return (
    <DialogHeader className="space-y-0 border-b border-slate-200/70 bg-linear-to-l from-indigo-50/90 to-violet-50/60 px-5 py-4 dark:border-white/10 dark:from-indigo-500/10 dark:to-violet-500/5">
      <DialogTitle className="flex items-center gap-2.5 font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
        <span
          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
          style={{ backgroundImage: grad(ATT_C[0], ATT_C[1]) }}
          aria-hidden="true"
        >
          <CatIcon name="file-check" className="h-4 w-4" />
        </span>
        {title}
      </DialogTitle>
      <DialogDescription className="ps-12 text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
        {desc}
      </DialogDescription>
    </DialogHeader>
  );
}

/** Has this allowance's window started? (module-level — reads the clock
 *  outside the component body, the resident-sheet leaseFacts idiom). */
function allowanceStarted(startsAt: string): boolean {
  const startMs = new Date(startsAt).getTime();
  return Number.isFinite(startMs) && startMs <= Date.now();
}

function AddAllowanceDialog({
  instance,
  open,
  onOpenChange,
}: {
  instance: InstanceDTO;
  open: boolean;
  onOpenChange: (o: boolean) => void;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();

  /* the shared roster cache (deduped with the today board's entry) */
  const rosterQuery = useQuery({
    queryKey: ["attendance-roster", instance.id],
    queryFn: () => fetchAttendanceRoster(instance.id),
    staleTime: 30_000,
    retry: 0,
  });
  const rows = rosterQuery.data?.rows ?? [];

  const [studentCode, setStudentCode] = useState<string | null>(null);
  const [kind, setKind] = useState<AttAllowanceKind>("excused");
  const [startsAt, setStartsAt] = useState(localDateTime(0));
  const [endsAt, setEndsAt] = useState(localDateTime(2));
  const [note, setNote] = useState("");
  const [formError, setFormError] = useState<string | null>(null);

  const reset = () => {
    setStudentCode(null);
    setKind("excused");
    setStartsAt(localDateTime(0));
    setEndsAt(localDateTime(2));
    setNote("");
    setFormError(null);
  };

  const createMutation = useMutation({
    mutationFn: (payload: {
      studentCode: string;
      kind: AttAllowanceKind;
      startsAt: string;
      endsAt: string;
      note?: string;
    }) => createAttendanceAllowance(instance.id, payload),
    onMutate: async (payload) => {
      await queryClient.cancelQueries({ queryKey: ["attendance-allowances", instance.id] });
      const prev = queryClient.getQueryData<{ allowances: AttendanceAllowanceDTO[] }>([
        "attendance-allowances",
        instance.id,
      ]);
      if (prev) {
        /* optimistic front-insert (the server orders soonest-first; a
         * just-created window is at or near the front) */
        const optimistic: AttendanceAllowanceDTO = {
          id: `optimistic-${Date.now()}`,
          studentCode: payload.studentCode,
          studentName:
            rows.find((r) => r.studentCode === payload.studentCode)?.name ?? payload.studentCode,
          kind: payload.kind,
          startsAt: new Date(payload.startsAt).toISOString(),
          endsAt: new Date(payload.endsAt).toISOString(),
          note: payload.note ?? null,
          createdByName: "…",
          createdAt: new Date().toISOString(),
        };
        queryClient.setQueryData(["attendance-allowances", instance.id], {
          allowances: [optimistic, ...prev.allowances],
        });
      }
      return { prev };
    },
    onError: (error: Error, _payload, ctx) => {
      if (ctx?.prev) {
        queryClient.setQueryData(["attendance-allowances", instance.id], ctx.prev);
      }
      const key = attErrorKey(error);
      toast.error(
        key ? t(key) : error instanceof ApiError ? error.message : t("attwsErrGeneric")
      );
    },
    onSuccess: () => {
      toast.success(t("attwsAllowSavedToast"));
      reset();
      onOpenChange(false);
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: ["attendance-allowances", instance.id] });
      void queryClient.invalidateQueries({ queryKey: ["attendance-roster", instance.id] });
    },
  });

  const submit = (e: FormEvent) => {
    e.preventDefault();
    /* client-side validation mirroring the server zod (inline, bilingual) */
    if (!studentCode) {
      setFormError(t("attwsAllowErrStudent"));
      return;
    }
    const start = new Date(startsAt).getTime();
    const end = new Date(endsAt).getTime();
    if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) {
      setFormError(t("attwsAllowErrWindow"));
      return;
    }
    setFormError(null);
    createMutation.mutate({
      studentCode,
      kind,
      startsAt: new Date(startsAt).toISOString(),
      endsAt: new Date(endsAt).toISOString(),
      ...(note.trim() ? { note: note.trim().slice(0, 200) } : {}),
    });
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) reset(); onOpenChange(o); }}>
      <DialogContent
        dir={lang === "ar" ? "rtl" : "ltr"}
        className="flex max-h-[85vh] flex-col gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-lg"
      >
        <AttDialogHeader title={t("attwsAllowAdd")} desc={t("attwsAllowEmptyHint")} />
        <form onSubmit={submit} noValidate className="flex min-h-0 flex-1 flex-col">
          <div className="nice-scroll min-h-0 flex-1 space-y-4 overflow-y-auto px-5 py-4">
            {/* student picker */}
            <div className="space-y-1.5">
              <Label className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                <CatIcon name="user-round" className="h-3 w-3 text-brand-500" aria-hidden="true" />
                {t("attwsStudent")}
              </Label>
              <AttStudentPicker
                rows={rows}
                value={studentCode}
                onChange={setStudentCode}
                searchPhKey="attwsAllowSearchPh"
                pickLabelKey="attwsAllowPickStudent"
                emptyKey="attwsEmptyFiltered"
                c1={ATT_C[0]}
                c2={ATT_C[1]}
              />
            </div>

            {/* kind */}
            <div className="space-y-1.5">
              <Label className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                <CatIcon name="badge-check" className="h-3 w-3 text-brand-500" aria-hidden="true" />
                {t("attwsAllowKind")}
              </Label>
              <Select value={kind} onValueChange={(v) => setKind(v as AttAllowanceKind)}>
                <SelectTrigger className="h-10 rounded-xl text-[12.5px] font-semibold">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ATT_KINDS.map((k) => {
                    const meta = ATT_KIND_META[k];
                    return (
                      <SelectItem key={k} value={k}>
                        <span className="flex items-center gap-2">
                          <span className={cn("h-2 w-2 rounded-full", ATT_TONE_DOT[meta.tone])} aria-hidden="true" />
                          {t(meta.key)}
                        </span>
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>

            {/* window */}
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                  <CatIcon name="calendar-clock" className="h-3 w-3 text-brand-500" aria-hidden="true" />
                  {t("attwsAllowStart")}
                </Label>
                <PremiumDateInput type="datetime-local" value={startsAt} onChange={(e) => setStartsAt(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                  <CatIcon name="calendar-clock" className="h-3 w-3 text-brand-500" aria-hidden="true" />
                  {t("attwsAllowEnd")}
                </Label>
                <PremiumDateInput type="datetime-local" value={endsAt} onChange={(e) => setEndsAt(e.target.value)} />
              </div>
            </div>

            {/* note */}
            <div className="space-y-1.5">
              <Label
                htmlFor="attws-allow-note"
                className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
              >
                <CatIcon name="pencil" className="h-3 w-3 text-brand-500" aria-hidden="true" />
                {t("attwsAllowNote")}
              </Label>
              <Textarea
                id="attws-allow-note"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                maxLength={200}
                rows={2}
                placeholder={t("attwsAllowNotePh")}
                className="rounded-xl text-[12.5px] font-semibold"
              />
            </div>

            {formError ? (
              <p role="alert" className="rounded-xl bg-rose-500/10 px-3 py-2 text-[11.5px] font-extrabold text-rose-600 dark:text-rose-300">
                {formError}
              </p>
            ) : null}
          </div>

          <DialogFooter className="border-t border-slate-200/70 bg-slate-50/60 px-5 py-3.5 dark:border-white/10 dark:bg-white/[0.02]">
            <Button
              type="button"
              variant="outline"
              onClick={() => { reset(); onOpenChange(false); }}
              className="h-10 rounded-xl px-4 text-[12.5px] font-extrabold"
            >
              {t("bizCancel")}
            </Button>
            <Button
              type="submit"
              disabled={createMutation.isPending}
              className="h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95"
              style={{ backgroundImage: grad(ATT_C[0], ATT_C[1]) }}
            >
              {createMutation.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" aria-hidden="true" />
              ) : (
                <CatIcon name="check" className="h-4 w-4" aria-hidden="true" />
              )}
              {t("attwsAllowAdd")}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

/* ------------------------------------------------------------------ */
/* the list                                                            */
/* ------------------------------------------------------------------ */

export function AttendanceAllowancesTab({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const listQuery = useQuery({
    queryKey: ["attendance-allowances", instance.id],
    queryFn: () => fetchAttendanceAllowances(instance.id),
    staleTime: 30_000,
    retry: 0,
  });
  const allowances = useMemo(
    () => listQuery.data?.allowances ?? [],
    [listQuery.data]
  );
  const deleteTarget = useMemo(
    () => allowances.find((a) => a.id === deleteId) ?? null,
    [allowances, deleteId]
  );

  const deleteMutation = useMutation({
    mutationFn: (allowanceId: string) => deleteAttendanceAllowance(instance.id, allowanceId),
    onMutate: async (allowanceId) => {
      await queryClient.cancelQueries({ queryKey: ["attendance-allowances", instance.id] });
      const prev = queryClient.getQueryData<{ allowances: AttendanceAllowanceDTO[] }>([
        "attendance-allowances",
        instance.id,
      ]);
      if (prev) {
        queryClient.setQueryData(["attendance-allowances", instance.id], {
          allowances: prev.allowances.filter((a) => a.id !== allowanceId),
        });
      }
      return { prev };
    },
    onError: (error: Error, _id, ctx) => {
      if (ctx?.prev) {
        queryClient.setQueryData(["attendance-allowances", instance.id], ctx.prev);
      }
      const key = attErrorKey(error);
      toast.error(
        key ? t(key) : error instanceof ApiError ? error.message : t("attwsErrGeneric")
      );
    },
    onSuccess: () => {
      toast.success(t("attwsAllowDeletedToast"));
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: ["attendance-allowances", instance.id] });
      void queryClient.invalidateQueries({ queryKey: ["attendance-roster", instance.id] });
    },
  });

  return (
    <DashCard
      title={t("attwsAllowTitle")}
      icon="file-check"
      action={
        <Button
          type="button"
          onClick={() => setDialogOpen(true)}
          className="h-9 gap-1.5 rounded-xl px-3.5 text-[11.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95"
          style={{ backgroundImage: grad(ATT_C[0], ATT_C[1]) }}
        >
          <CatIcon name="plus" className="h-3.5 w-3.5" aria-hidden="true" />
          {t("attwsAllowAdd")}
        </Button>
      }
    >
      {listQuery.isError && allowances.length === 0 ? (
        <div className="flex min-h-24 flex-col items-center justify-center gap-2 text-center">
          <CatIcon name="circle-alert" className="h-6 w-6 text-rose-400" aria-hidden="true" />
          <p className="text-[12px] font-bold text-slate-500 dark:text-slate-400">{t("attwsLoadErr")}</p>
          <Button
            type="button"
            variant="outline"
            onClick={() => void listQuery.refetch()}
            className="h-9 rounded-xl px-3 text-[11.5px] font-bold"
          >
            {t("attwsRefresh")}
          </Button>
        </div>
      ) : listQuery.isPending && allowances.length === 0 ? (
        <div className="space-y-2">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-[76px] animate-pulse rounded-xl bg-slate-100 dark:bg-white/5" />
          ))}
        </div>
      ) : allowances.length === 0 ? (
        <div className="flex h-32 flex-col items-center justify-center gap-1.5 text-center">
          <CatIcon name="inbox" className="h-6 w-6 text-slate-300 dark:text-slate-600" aria-hidden="true" />
          <p className="text-[12.5px] font-extrabold text-slate-500 dark:text-slate-400">{t("attwsAllowEmpty")}</p>
          <p className="max-w-sm text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("attwsAllowEmptyHint")}
          </p>
        </div>
      ) : (
        <div className="nice-scroll grid max-h-[560px] gap-2 overflow-y-auto pe-1">
          {allowances.map((row) => {
            const meta = ATT_KIND_META[row.kind] ?? ATT_KIND_META.excused;
            const active = allowanceStarted(row.startsAt);
            return (
              <div
                key={row.id}
                className="flex flex-wrap items-center gap-x-3 gap-y-1.5 rounded-xl border border-slate-200/80 bg-white/60 p-2.5 dark:border-white/10 dark:bg-white/[0.03]"
              >
                {/* kind tile */}
                <span
                  aria-hidden="true"
                  className={cn(
                    "grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md",
                    row.kind === "leave"
                      ? "bg-linear-to-br from-teal-500 to-teal-600"
                      : row.kind === "outside"
                        ? "bg-linear-to-br from-sky-500 to-sky-600"
                        : row.kind === "authorized"
                          ? "bg-linear-to-br from-violet-500 to-violet-600"
                          : "bg-linear-to-br from-slate-400 to-slate-500"
                  )}
                >
                  <CatIcon name={meta.icon} className="h-4 w-4" />
                </span>

                {/* student + window */}
                <span className="min-w-0 flex-1">
                  <span className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
                    <span className="truncate text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                      {row.studentName}
                    </span>
                    <span
                      dir={idDir}
                      className="shrink-0 rounded-full border border-slate-200 bg-white/80 px-2 py-0.5 font-mono text-[9.5px] font-extrabold tabular-nums text-slate-500 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-300"
                    >
                      {row.studentCode}
                    </span>
                  </span>
                  <span dir="auto" className="mt-0.5 block truncate text-[10.5px] font-bold tabular-nums text-slate-400 dark:text-slate-500">
                    {fullDate(row.startsAt, lang)} → {fullDate(row.endsAt, lang)}
                  </span>
                  {row.note ? (
                    <span dir="auto" className="mt-0.5 block truncate text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                      {row.note}
                    </span>
                  ) : null}
                </span>

                {/* kind pill + status pill + delete */}
                <span className="flex shrink-0 flex-wrap items-center gap-1.5">
                  <span
                    dir="auto"
                    className={cn(
                      "inline-flex shrink-0 items-center gap-1.5 rounded-full px-2.5 py-1 text-[10.5px] font-extrabold",
                      ATT_TONE_STYLE[meta.tone] ?? ATT_TONE_STYLE.slate
                    )}
                  >
                    <span className={cn("h-1.5 w-1.5 rounded-full", ATT_TONE_DOT[meta.tone])} aria-hidden="true" />
                    {t(meta.key)}
                  </span>
                  <span
                    dir="auto"
                    className={cn(
                      "inline-flex shrink-0 items-center gap-1 rounded-full px-2 py-0.5 text-[9.5px] font-extrabold",
                      active
                        ? "bg-emerald-500/12 text-emerald-700 dark:text-emerald-300"
                        : "bg-amber-500/12 text-amber-700 dark:text-amber-300"
                    )}
                  >
                    <CatIcon name={active ? "circle-check" : "calendar-clock"} className="h-2.5 w-2.5" aria-hidden="true" />
                    {active ? t("attwsAllowActive") : t("attwsAllowUpcoming")}
                  </span>
                  <span dir="auto" className="hidden text-[10px] font-bold text-slate-400 dark:text-slate-500 sm:inline">
                    {t("attwsMovBy", { name: row.createdByName })}
                  </span>
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={() => setDeleteId(row.id)}
                    aria-label={t("attwsAllowDelete")}
                    className="h-9 w-9 shrink-0 rounded-lg text-slate-400 transition hover:bg-rose-50 hover:text-rose-600 active:scale-95 dark:hover:bg-rose-500/10"
                  >
                    <CatIcon name="trash-2" className="h-4 w-4" aria-hidden="true" />
                  </Button>
                </span>
              </div>
            );
          })}
        </div>
      )}

      {/* the delete confirm */}
      <AlertDialog open={deleteId !== null} onOpenChange={(o) => { if (!o) setDeleteId(null); }}>
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"}>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("attwsAllowDeleteTitle")}</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteTarget
                ? `${deleteTarget.studentName} · ${fullDate(deleteTarget.startsAt, lang)} → ${fullDate(deleteTarget.endsAt, lang)} — ${t("attwsAllowDeleteMsg")}`
                : t("attwsAllowDeleteMsg")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-4 font-extrabold">{t("bizCancel")}</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (deleteId) deleteMutation.mutate(deleteId);
                setDeleteId(null);
              }}
              className="h-10 gap-1.5 rounded-xl bg-linear-to-r from-rose-500 to-red-500 px-5 font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:brightness-110 active:scale-95"
            >
              <CatIcon name="trash-2" className="h-4 w-4" aria-hidden="true" />
              {t("attwsAllowDelete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* the add dialog */}
      <AddAllowanceDialog instance={instance} open={dialogOpen} onOpenChange={setDialogOpen} />
    </DashCard>
  );
}
