"use client";

/**
 * Ashrilogic — ROUND 166 (Task 6-b): shared atoms of the الحضور والغياب
 * attendance workspace (student-accommodation console).
 *
 * Everything the five tabs agree on lives here so the per-tab files stay
 * lean: the 8-state tone registry (colors per the task spec), the
 * allowance-kind registry, HH:MM helpers (Western digits — the ROUND 134
 * ID policy: times read left-to-right in every locale), the bilingual
 * ApiError→i18n resolver, the state pill, and the student picker shared
 * by the allowance dialog and the QR mint form.
 */
import { useMemo, useState } from "react";
import type { I18nKey } from "@/lib/i18n";
import { useT } from "@/lib/i18n";
import type { Lang } from "@/lib/types";
import type {
  AttendancePolicyDTO,
  AttendanceRosterRowDTO,
  AttendanceStateKey,
} from "@/lib/types";
import { ApiError } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, idDir } from "@/lib/utils";
import { Input } from "@/components/ui/input";

/* ------------------------------------------------------------------ */
/* the 8-state registry (display order + tones + i18n keys)            */
/* ------------------------------------------------------------------ */

export const ATT_STATE_ORDER: readonly AttendanceStateKey[] = [
  "present",
  "late",
  "absent_pending_review",
  "absent",
  "excused_absence",
  "authorized_absence",
  "on_leave",
  "outside_with_permission",
];

/** tone → pill classes (the workspace's own map — adds teal for إجازة). */
const ATT_TONE_STYLE: Record<string, string> = {
  emerald: "bg-emerald-500/12 text-emerald-700 dark:text-emerald-300",
  amber: "bg-amber-500/12 text-amber-700 dark:text-amber-300",
  rose: "bg-rose-500/12 text-rose-700 dark:text-rose-300",
  sky: "bg-sky-500/12 text-sky-700 dark:text-sky-300",
  violet: "bg-violet-500/12 text-violet-700 dark:text-violet-300",
  teal: "bg-teal-500/12 text-teal-700 dark:text-teal-300",
  slate: "bg-slate-500/12 text-slate-600 dark:text-slate-300",
};

const ATT_TONE_DOT: Record<string, string> = {
  emerald: "bg-emerald-500",
  amber: "bg-amber-500",
  rose: "bg-rose-500",
  sky: "bg-sky-500",
  violet: "bg-violet-500",
  teal: "bg-teal-500",
  slate: "bg-slate-400",
};

export { ATT_TONE_DOT };

/** tone → chip hover ring (the state-count chips on the today board). */
export const ATT_TONE_RING: Record<string, string> = {
  emerald: "hover:border-emerald-300 dark:hover:border-emerald-500/40",
  amber: "hover:border-amber-300 dark:hover:border-amber-500/40",
  rose: "hover:border-rose-300 dark:hover:border-rose-500/40",
  sky: "hover:border-sky-300 dark:hover:border-sky-500/40",
  violet: "hover:border-violet-300 dark:hover:border-violet-500/40",
  teal: "hover:border-teal-300 dark:hover:border-teal-500/40",
  slate: "hover:border-slate-300 dark:hover:border-slate-500/40",
};

interface AttStateMeta {
  key: I18nKey;
  tone: string;
}

export const ATT_STATE_META: Record<AttendanceStateKey, AttStateMeta> = {
  present: { key: "attwsStatePresent", tone: "emerald" },
  late: { key: "attwsStateLate", tone: "amber" },
  absent_pending_review: { key: "attwsStateAbsentPending", tone: "sky" },
  absent: { key: "attwsStateAbsent", tone: "rose" },
  excused_absence: { key: "attwsStateExcused", tone: "slate" },
  authorized_absence: { key: "attwsStateAuthorized", tone: "violet" },
  on_leave: { key: "attwsStateOnLeave", tone: "teal" },
  outside_with_permission: { key: "attwsStateOutside", tone: "sky" },
};

/* ------------------------------------------------------------------ */
/* the allowance-kind registry                                          */
/* ------------------------------------------------------------------ */

export type AttAllowanceKind = "excused" | "authorized" | "leave" | "outside";

export const ATT_KINDS: readonly AttAllowanceKind[] = [
  "excused",
  "authorized",
  "leave",
  "outside",
];

export const ATT_KIND_META: Record<AttAllowanceKind, { key: I18nKey; tone: string; icon: string }> = {
  excused: { key: "attwsKindExcused", tone: "slate", icon: "file-check" },
  authorized: { key: "attwsKindAuthorized", tone: "violet", icon: "badge-check" },
  leave: { key: "attwsKindLeave", tone: "teal", icon: "calendar-check" },
  outside: { key: "attwsKindOutside", tone: "sky", icon: "door-open" },
};

/* ------------------------------------------------------------------ */
/* ROUND 167 (دوام) — the shift-type registry                           */
/* ------------------------------------------------------------------ */

export type AttShiftType = "morning" | "evening" | "partial";

export const ATT_SHIFT_TYPES: readonly AttShiftType[] = [
  "morning",
  "evening",
  "partial",
];

interface AttShiftMeta {
  key: I18nKey;
  /** the timeline segment's gradient pair (the type's color family). */
  colors: readonly [string, string];
  /** the header icon (sunrise / sunset / clock). */
  icon: string;
  /** tailwind text tone for chips + labels. */
  text: string;
  /** tailwind chip background for the selected type chip. */
  chip: string;
}

/** صباحي amber · مسائي violet · جزئي teal — the دوام color families. */
export const ATT_SHIFT_META: Record<AttShiftType, AttShiftMeta> = {
  morning: {
    key: "attwsShiftMorning",
    colors: ["#fbbf24", "#f59e0b"],
    icon: "sunrise",
    text: "text-amber-700 dark:text-amber-300",
    chip: "border-transparent bg-linear-to-r from-amber-400 to-amber-500 text-white shadow-md",
  },
  evening: {
    key: "attwsShiftEvening",
    colors: ["#8b5cf6", "#7c3aed"],
    icon: "sunset",
    text: "text-violet-700 dark:text-violet-300",
    chip: "border-transparent bg-linear-to-r from-violet-500 to-violet-600 text-white shadow-md",
  },
  partial: {
    key: "attwsShiftPartial",
    colors: ["#2dd4bf", "#0d9488"],
    icon: "clock",
    text: "text-teal-700 dark:text-teal-300",
    chip: "border-transparent bg-linear-to-r from-teal-400 to-teal-500 text-white shadow-md",
  },
};

/**
 * The policy-window summary line (the today-board header chip):
 * shift-aware when a دوام schedule is configured — «الصباحي 08:00–15:00 ·
 * المسائي 15:30–22:00» (windows in start order) — and the legacy
 * «08:00 → 18:00 · سماحية ١٠ د» single-window line otherwise.
 */
export function attPolicySummary(
  policy: AttendancePolicyDTO,
  lang: Lang,
  t: (key: I18nKey, vars?: Record<string, string | number>) => string
): string {
  const shifts = [...policy.shifts].sort((a, b) => a.startMin - b.startMin);
  if (shifts.length > 0) {
    return shifts
      .map((s) =>
        t("attwsPolicyShiftChip", {
          shift: t(ATT_SHIFT_META[s.type].key),
          start: hhmm(s.startMin),
          end: hhmm(s.endMin),
        })
      )
      .join(" · ");
  }
  return t("attwsPolicyWindow", {
    start: hhmm(policy.dayStartMin),
    end: hhmm(policy.dayEndMin),
    grace: fmtNum(policy.graceMin, lang),
  });
}

/* ------------------------------------------------------------------ */
/* time helpers — Western digits, LTR (the ROUND 134 ID/time policy)    */
/* ------------------------------------------------------------------ */

/** minutes-of-day (0..1439) → canonical "HH:MM" (Western digits). */
export function hhmm(min: number): string {
  const clamped = Math.max(0, Math.min(1439, Math.round(min)));
  return `${String(Math.floor(clamped / 60)).padStart(2, "0")}:${String(clamped % 60).padStart(2, "0")}`;
}

/** "HH:MM" (datetime-local / time input) → minutes-of-day (null if junk). */
export function parseHhmm(value: string): number | null {
  const m = /^(\d{1,2}):(\d{2})$/.exec(value.trim());
  if (!m) return null;
  const h = Number.parseInt(m[1], 10);
  const mm = Number.parseInt(m[2], 10);
  if (h < 0 || h > 23 || mm < 0 || mm > 59) return null;
  return h * 60 + mm;
}

/* ------------------------------------------------------------------ */
/* ApiError → bilingual i18n key                                       */
/* ------------------------------------------------------------------ */

/** Map a thrown ApiError's machine code onto the workspace's localized
 *  copy. Movement codes, allowance codes and QR codes all resolve; null
 *  means "no dedicated copy — fall back to the server message". */
export function attErrorKey(error: unknown): I18nKey | null {
  if (!(error instanceof ApiError) || !error.code) return null;
  switch (error.code) {
    case "STUDENT_NOT_FOUND":
      return "attwsErrStudentNotFound";
    case "DUPLICATE_CHECK_IN":
      return "attwsErrDuplicateIn";
    case "INVALID_CHECK_OUT":
      return "attwsErrInvalidOut";
    case "DUPLICATE_CHECK_OUT":
      return "attwsErrDuplicateOut";
    case "BAD_WINDOW":
      return "attwsAllowErrWindow";
    case "QR_EXPIRED":
      return "attwsQrErrExpired";
    case "QR_REUSED":
      return "attwsQrErrReused";
    case "QR_NOT_FOUND":
      return "attwsQrErrNotFound";
    default:
      return null;
  }
}

/* ------------------------------------------------------------------ */
/* the state pill (shared by the roster table + movements feed)        */
/* ------------------------------------------------------------------ */

export function AttStatePill({
  state,
  compact = false,
}: {
  state: AttendanceStateKey;
  compact?: boolean;
}) {
  const { t } = useT();
  const meta = ATT_STATE_META[state] ?? ATT_STATE_META.absent;
  return (
    <span
      dir="auto"
      className={cn(
        "inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full font-extrabold",
        compact ? "px-2 py-0.5 text-[9.5px]" : "px-2.5 py-1 text-[10.5px]",
        ATT_TONE_STYLE[meta.tone] ?? ATT_TONE_STYLE.slate
      )}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", ATT_TONE_DOT[meta.tone] ?? ATT_TONE_DOT.slate)} aria-hidden="true" />
      {t(meta.key)}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* the student picker (allowance dialog + QR mint form)                */
/* ------------------------------------------------------------------ */

/**
 * Searchable roster picker: a search field + a bounded, scrollable list
 * of residents (name + RES-code mono chip). Selecting a row highlights
 * it with the workspace gradient; 44px touch targets.
 */
export function AttStudentPicker({
  rows,
  value,
  onChange,
  searchPhKey,
  pickLabelKey,
  emptyKey,
  c1,
  c2,
}: {
  rows: AttendanceRosterRowDTO[];
  value: string | null;
  onChange: (code: string) => void;
  searchPhKey: I18nKey;
  pickLabelKey: I18nKey;
  emptyKey: I18nKey;
  c1: string;
  c2: string;
}) {
  const { t, lang } = useT();
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return rows.slice(0, 60);
    return rows
      .filter(
        (r) =>
          r.name.toLowerCase().includes(q) ||
          r.studentCode.toLowerCase().includes(q)
      )
      .slice(0, 60);
  }, [rows, query]);

  return (
    <div className="space-y-2">
      <div className="relative">
        <CatIcon
          name="search"
          className="pointer-events-none absolute start-3.5 top-1/2 h-[12px] w-[12px] -translate-y-1/2 text-slate-400"
        />
        <Input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t(searchPhKey)}
          aria-label={t(searchPhKey)}
          className="h-10 rounded-xl border-slate-200 bg-slate-50/80 ps-10 pe-3 text-[12.5px] font-semibold dark:border-white/10 dark:bg-white/[0.04]"
        />
      </div>
      <div
        role="listbox"
        aria-label={t(pickLabelKey)}
        className="nice-scroll max-h-56 space-y-1 overflow-y-auto rounded-xl border border-slate-200/80 bg-white/60 p-1.5 dark:border-white/10 dark:bg-white/[0.03]"
      >
        {filtered.length === 0 ? (
          <p className="px-3 py-6 text-center text-[11.5px] font-bold text-slate-400 dark:text-slate-500">
            {t(emptyKey)}
          </p>
        ) : (
          filtered.map((row) => {
            const selected = value === row.studentCode;
            return (
              <button
                key={row.studentCode}
                type="button"
                role="option"
                aria-selected={selected}
                onClick={() => onChange(row.studentCode)}
                className={cn(
                  "flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-start transition",
                  selected
                    ? "bg-linear-to-r from-slate-100 to-slate-50 shadow-sm ring-1 ring-slate-300/60 dark:from-white/[0.09] dark:to-white/[0.04] dark:ring-white/15"
                    : "hover:bg-slate-100/80 dark:hover:bg-white/[0.06]"
                )}
              >
                <span
                  aria-hidden="true"
                  className={cn(
                    "grid h-4 w-4 shrink-0 place-items-center rounded-full border-2 transition",
                    selected ? "border-transparent text-white" : "border-slate-300 dark:border-slate-600"
                  )}
                  style={selected ? { backgroundImage: `linear-gradient(135deg,${c1},${c2})` } : undefined}
                >
                  {selected ? <CatIcon name="check" className="h-2.5 w-2.5" /> : null}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
                    {row.name}
                  </span>
                  <span className="block truncate text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                    {row.room} · {row.building}
                  </span>
                </span>
                <span
                  dir={idDir}
                  className="shrink-0 rounded-full border border-slate-200 bg-white/80 px-2 py-0.5 font-mono text-[9.5px] font-extrabold tabular-nums text-slate-500 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-300"
                >
                  {row.studentCode}
                </span>
              </button>
            );
          })
        )}
      </div>
      {rows.length > 60 && query.trim() === "" ? (
        <p className="text-end text-[9.5px] font-bold text-slate-400 dark:text-slate-500" dir="auto">
          {fmtNum(rows.length, lang)}
        </p>
      ) : null}
    </div>
  );
}
