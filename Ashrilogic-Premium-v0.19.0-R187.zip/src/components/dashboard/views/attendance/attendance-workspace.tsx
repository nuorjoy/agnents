"use client";

/**
 * Ashrilogic — ROUND 166 (Task 6-b): the الحضور والغياب ATTENDANCE
 * WORKSPACE (student-accommodation / SAMS).
 *
 * The dedicated premium console behind the ENABLED الحضور والغياب module
 * card — five tabs over the REAL attendance API (the 6-a backend):
 *
 *   • لوحة اليوم  — the day board: live clock + policy window summary +
 *                   the 8 state-count chips (click = filter) + the roster
 *                   table with per-row check-in/out (optimistic + toast,
 *                   the alternation law mirrored client-side by disabling
 *                   the direction that would 409);
 *   • الحركات     — the keyset-paginated movements feed (المزيد) with
 *                   direction/method filter chips;
 *   • الأذونات    — allowances & leaves manager + the add dialog;
 *   • السياسة     — the flagship settings surface: the 24-hour visual
 *                   timeline (day window + grace + eval markers) and the
 *                   live impact preview;
 *   • رمز QR      — mint single-use gate tokens, render them large with a
 *                   countdown ring, and simulate the kiosk scan.
 *
 * Every state is DERIVED server-side (never persisted); this surface only
 * reads the projections and posts guarded mutations. Numerals follow the
 * split policy: RES codes + clock times in Western digits (dir={idDir}),
 * counts in locale digits. Reached ONLY for
 * instance.systemId === "student-accommodation" (module-workspace router).
 */
import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { useT } from "@/lib/i18n";
import type { InstanceDTO, Lang } from "@/lib/types";
import type {
  AttendanceRosterResponseDTO,
  AttendanceRosterRowDTO,
} from "@/lib/types";
import {
  ApiError,
  fetchAttendanceRoster,
  recordAttendanceMovement,
} from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, idDir } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DashCard, ViewHeading, dateOnly } from "@/components/dashboard/dash-shared";
import {
  ATT_STATE_META,
  ATT_STATE_ORDER,
  ATT_TONE_DOT,
  ATT_TONE_RING,
  AttStatePill,
  attErrorKey,
  attPolicySummary,
} from "./attendance-shared";
import { AttendanceMovementsTab } from "./attendance-movements";
import { AttendanceAllowancesTab } from "./attendance-allowances";
import { AttendancePolicyTab } from "./attendance-policy";
import { AttendanceQrTab } from "./attendance-qr";

/* the education-family brand gradient (SAMS is an education-category
 * system — matches the resident profile sheet + the campus family). */
const ATT_C = ["#6366f1", "#7c3aed"] as const;

type AttTab = "today" | "movements" | "allowances" | "policy" | "qr";

const ATT_TABS: { id: AttTab; icon: string; key: "attwsTabToday" | "attwsTabMovements" | "attwsTabAllowances" | "attwsTabPolicy" | "attwsTabQr" }[] = [
  { id: "today", icon: "clipboard-list", key: "attwsTabToday" },
  { id: "movements", icon: "clock-rotate-left", key: "attwsTabMovements" },
  { id: "allowances", icon: "file-check", key: "attwsTabAllowances" },
  { id: "policy", icon: "sliders", key: "attwsTabPolicy" },
  { id: "qr", icon: "qr-code", key: "attwsTabQr" },
];

/* ------------------------------------------------------------------ */
/* the live HH:MM clock — 30s tick, SSR-safe (placeholder until mount) */
/* ------------------------------------------------------------------ */

function LiveTime({ lang }: { lang: Lang }) {
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    const tick = () => setNow(new Date());
    tick();
    const id = window.setInterval(tick, 30_000);
    return () => window.clearInterval(id);
  }, []);
  const time =
    now === null
      ? "--:--"
      : new Intl.DateTimeFormat(lang === "ar" ? "ar-EG" : "en-GB", {
          hour: "2-digit",
          minute: "2-digit",
        }).format(now);
  return (
    <span
      dir={idDir}
      role="timer"
      className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white/80 px-3 py-1 text-[12px] font-extrabold tabular-nums text-slate-700 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-200"
    >
      <CatIcon name="timer" className="h-3 w-3 text-brand-500" aria-hidden="true" />
      {time}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* tab 1 — لوحة اليوم (the today board)                                */
/* ------------------------------------------------------------------ */

function TodayBoard({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const [query, setQuery] = useState("");
  const [stateFilter, setStateFilter] = useState<string | null>(null);

  const rosterQuery = useQuery({
    queryKey: ["attendance-roster", instance.id],
    queryFn: () => fetchAttendanceRoster(instance.id),
    staleTime: 30_000,
    retry: 0,
  });
  const data = rosterQuery.data ?? null;
  const rows = useMemo(() => data?.rows ?? [], [data]);
  const counts = data?.counts;

  /* invalidate the shared cache keys after any attendance mutation —
   * every tab + the movement feed re-derive in the same tick. */
  const invalidateAttendance = () => {
    void queryClient.invalidateQueries({ queryKey: ["attendance-roster", instance.id] });
    void queryClient.invalidateQueries({ queryKey: ["attendance-movements", instance.id] });
    void queryClient.invalidateQueries({ queryKey: ["attendance-allowances", instance.id] });
  };

  /* the manual movement — OPTIMISTIC: the row flips instantly and rolls
   * back on any failure (404/409), with the bilingual code toasts. */
  const moveMutation = useMutation({
    mutationFn: (payload: { row: AttendanceRosterRowDTO; direction: "in" | "out" }) =>
      recordAttendanceMovement(instance.id, {
        studentCode: payload.row.studentCode,
        direction: payload.direction,
      }),
    onMutate: async ({ row, direction }) => {
      await queryClient.cancelQueries({ queryKey: ["attendance-roster", instance.id] });
      const prev = queryClient.getQueryData<AttendanceRosterResponseDTO>([
        "attendance-roster",
        instance.id,
      ]);
      if (prev) {
        /* the in-branch mirrors the engine's present/late law client-side
         * (a best-effort approximation — the refetch lands the server truth
         * within the same tick); the out-branch keeps the state until the
         * server re-derives it. */
        const nowMin = new Date().getHours() * 60 + new Date().getMinutes();
        const dayStart = prev.policy.dayStartMin;
        const graceEdge = dayStart + prev.policy.graceMin;
        const optimisticIn =
          nowMin <= graceEdge
            ? { state: "present" as const, lateMinutes: null }
            : { state: "late" as const, lateMinutes: Math.max(0, nowMin - dayStart) };
        queryClient.setQueryData(["attendance-roster", instance.id], {
          ...prev,
          rows: prev.rows.map((r) =>
            r.studentCode === row.studentCode
              ? {
                  ...r,
                  lastDirection: direction,
                  lastMovementAt: new Date().toISOString(),
                  ...(direction === "in" ? optimisticIn : {}),
                }
              : r
          ),
        });
      }
      return { prev };
    },
    onError: (error: Error, _payload, ctx) => {
      if (ctx?.prev) {
        queryClient.setQueryData(["attendance-roster", instance.id], ctx.prev);
      }
      const key = attErrorKey(error);
      toast.error(
        key ? t(key) : error instanceof ApiError ? error.message : t("attwsErrGeneric")
      );
    },
    onSuccess: (_result, payload) => {
      toast.success(
        payload.direction === "in"
          ? t("attwsMoveInToast", { name: payload.row.name })
          : t("attwsMoveOutToast", { name: payload.row.name })
      );
    },
    onSettled: () => {
      invalidateAttendance();
    },
  });

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return rows.filter((r) => {
      if (stateFilter && r.state !== stateFilter) return false;
      if (!q) return true;
      return r.name.toLowerCase().includes(q) || r.studentCode.toLowerCase().includes(q);
    });
  }, [rows, query, stateFilter]);

  const policy = data?.policy;

  return (
    /* ROUND 166 — motion pass: same step-in entrance as the business
     * suite — the dedicated attendance console mounts identically. */
    <div className="step-in space-y-4">
      {/* ---------------- header strip: date + clock + policy window ---------------- */}
      <div className="glass-card card-in rounded-3xl p-4">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-2.5">
          <span className="inline-flex items-center gap-2 text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
            <span
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
              style={{ backgroundImage: grad(ATT_C[0], ATT_C[1]) }}
              aria-hidden="true"
            >
              <CatIcon name="calendar-days" className="h-4 w-4" />
            </span>
            {data ? dateOnly(data.date, lang) : "…"}
          </span>
          <LiveTime lang={lang} />
          {policy ? (
            <span
              dir="auto"
              className="inline-flex items-center gap-1.5 rounded-full bg-slate-500/10 px-3 py-1 text-[11px] font-bold text-slate-600 dark:text-slate-300"
            >
              <CatIcon name="clock-rotate-left" className="h-3 w-3 shrink-0" aria-hidden="true" />
              {/* ROUND 167 (دوام) — shift-aware: «الصباحي 08:00–15:00 · المسائي
                  15:30–22:00» when a schedule is configured, the legacy
                  single-window line otherwise (attPolicySummary). */}
              {attPolicySummary(policy, lang, t)}
            </span>
          ) : null}
          <span className="ms-auto flex items-center gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => void rosterQuery.refetch()}
              disabled={rosterQuery.isFetching}
              className="h-9 gap-1.5 rounded-xl px-3 text-[11.5px] font-bold"
            >
              <CatIcon
                name="refresh-cw"
                className={cn("h-3.5 w-3.5", rosterQuery.isFetching && "animate-spin")}
                aria-hidden="true"
              />
              {t("attwsRefresh")}
            </Button>
          </span>
        </div>

        {/* ---------------- the 8 state-count chips (click = filter) ---------------- */}
        <div className="mt-3.5 grid grid-cols-2 gap-2 sm:grid-cols-4 xl:grid-cols-8">
          <button
            type="button"
            aria-pressed={stateFilter === null}
            onClick={() => setStateFilter(null)}
            className={cn(
              "flex min-h-[44px] items-center gap-2 rounded-xl border px-2.5 py-2 text-start transition",
              stateFilter === null
                ? "border-brand-300 bg-brand-500/10 ring-1 ring-brand-400/40 dark:border-brand-500/40 dark:bg-brand-500/15"
                : "border-slate-200/80 bg-white/70 hover:border-slate-300 dark:border-white/10 dark:bg-white/[0.03]"
            )}
          >
            <span className="grid h-6 w-6 shrink-0 place-items-center rounded-lg bg-slate-500/15 text-slate-500 dark:text-slate-300" aria-hidden="true">
              <CatIcon name="list-checks" className="h-3 w-3" />
            </span>
            <span className="min-w-0">
              <span className="block truncate text-[10px] font-extrabold text-slate-500 dark:text-slate-400">{t("attwsFilterAll")}</span>
              <span dir={idDir} className="block font-display text-[15px] font-extrabold tabular-nums text-slate-800 dark:text-white">
                {fmtNum(rows.length, lang)}
              </span>
            </span>
          </button>
          {counts
            ? ATT_STATE_ORDER.map((state) => {
                const meta = ATT_STATE_META[state];
                const selected = stateFilter === state;
                const active = counts[state] > 0;
                return (
                  <motion.button
                    key={state}
                    type="button"
                    aria-pressed={selected}
                    whileHover={{ y: -1 }}
                    transition={{ duration: 0.15 }}
                    onClick={() => setStateFilter(selected ? null : state)}
                    className={cn(
                      "flex min-h-[44px] items-center gap-2 rounded-xl border px-2.5 py-2 text-start transition",
                      selected
                        ? "border-brand-300 bg-brand-500/10 ring-1 ring-brand-400/40 dark:border-brand-500/40 dark:bg-brand-500/15"
                        : cn(
                            "border-slate-200/80 bg-white/70 dark:border-white/10 dark:bg-white/[0.03]",
                            ATT_TONE_RING[meta.tone]
                          ),
                      !active && "opacity-70"
                    )}
                  >
                    <span
                      aria-hidden="true"
                      className={cn(
                        "h-2 w-2 shrink-0 rounded-full",
                        active
                          ? ATT_TONE_DOT[meta.tone] ?? "bg-slate-400"
                          : "bg-slate-300 dark:bg-slate-600"
                      )}
                    />
                    <span className="min-w-0">
                      <span className="block truncate text-[10px] font-extrabold text-slate-500 dark:text-slate-400">
                        {t(meta.key)}
                      </span>
                      <span dir={idDir} className="block font-display text-[15px] font-extrabold tabular-nums text-slate-800 dark:text-white">
                        {fmtNum(counts[state], lang)}
                      </span>
                    </span>
                  </motion.button>
                );
              })
            : null}
        </div>
      </div>

      {/* ---------------- the roster table ---------------- */}
      <DashCard
        title={t("attwsStudentsCount", { count: fmtNum(filtered.length, lang) })}
        icon="table"
        action={
          <span dir={idDir} className="rounded-full border border-slate-200 bg-slate-50 px-2.5 py-0.5 text-[10.5px] font-extrabold tabular-nums text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
            {fmtNum(filtered.length, lang)}/{fmtNum(rows.length, lang)}
          </span>
        }
      >
        {/* toolbar */}
        <div className="mb-4 flex flex-wrap items-center gap-2">
          <div className="relative min-w-0 flex-1 sm:max-w-xs">
            <CatIcon
              name="search"
              className="pointer-events-none absolute start-3.5 top-1/2 h-[12px] w-[12px] -translate-y-1/2 text-slate-400"
            />
            <Input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t("attwsSearchPh")}
              aria-label={t("attwsSearchPh")}
              className="h-10 rounded-xl border-slate-200 bg-slate-50/80 ps-10 pe-3 text-[12.5px] font-semibold dark:border-white/10 dark:bg-white/[0.04]"
            />
          </div>
        </div>

        {rosterQuery.isError && !data ? (
          <div className="flex min-h-24 flex-col items-center justify-center gap-2 text-center">
            <CatIcon name="circle-alert" className="h-6 w-6 text-rose-400" aria-hidden="true" />
            <p className="text-[12px] font-bold text-slate-500 dark:text-slate-400">{t("attwsLoadErr")}</p>
            <Button
              type="button"
              variant="outline"
              onClick={() => void rosterQuery.refetch()}
              className="h-9 rounded-xl px-3 text-[11.5px] font-bold"
            >
              {t("attwsRefresh")}
            </Button>
          </div>
        ) : rosterQuery.isPending && !data ? (
          <div className="nice-scroll grid max-h-[520px] gap-2 overflow-hidden">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="h-[60px] animate-pulse rounded-xl bg-slate-100 dark:bg-white/5" />
            ))}
          </div>
        ) : rows.length === 0 ? (
          <div className="flex h-32 flex-col items-center justify-center gap-1.5 text-center">
            <CatIcon name="inbox" className="h-6 w-6 text-slate-300 dark:text-slate-600" aria-hidden="true" />
            <p className="text-[12.5px] font-extrabold text-slate-500 dark:text-slate-400">{t("attwsEmptyRoster")}</p>
            <p className="max-w-sm text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {t("attwsEmptyRosterHint")}
            </p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex h-24 flex-col items-center justify-center gap-1.5 text-center">
            <CatIcon name="search" className="h-5 w-5 text-slate-300 dark:text-slate-600" aria-hidden="true" />
            <p className="text-[12px] font-bold text-slate-400 dark:text-slate-500">{t("attwsEmptyFiltered")}</p>
          </div>
        ) : (
          <div className="overflow-hidden rounded-2xl border border-slate-200/80 dark:border-white/10">
            <div className="max-h-[520px] overflow-auto nice-scroll">
              <table className="w-full min-w-[720px] border-collapse text-start">
                <thead className="sticky top-0 z-10">
                  <tr className="bg-slate-100/95 backdrop-blur dark:bg-[#0b1220]/95">
                    {[t("attwsColStudent"), t("attwsColRoom"), t("attwsColState"), t("attwsColLastMove"), t("attwsColActions")].map(
                      (label, i) => (
                        <th
                          key={label}
                          scope="col"
                          className={cn(
                            "whitespace-nowrap px-3.5 py-2.5 text-[10.5px] font-extrabold uppercase tracking-wide text-slate-500 dark:text-slate-400",
                            i === 4 ? "text-end" : "text-start"
                          )}
                        >
                          {label}
                        </th>
                      )
                    )}
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((row) => {
                    const busy =
                      moveMutation.isPending &&
                      moveMutation.variables?.row.studentCode === row.studentCode;
                    /* the alternation law mirrored client-side: the button
                     * the server would 409 is disabled (never a trap). */
                    const canIn = row.lastDirection !== "in";
                    const canOut = row.lastDirection === "in";
                    return (
                      <tr
                        key={row.studentCode}
                        className="border-t border-slate-100 transition-colors hover:bg-slate-50/80 dark:border-white/5 dark:hover:bg-white/[0.03]"
                      >
                        <td className="px-3.5 py-2.5">
                          <div className="flex items-center gap-2.5">
                            <span className="min-w-0">
                              <span className="block truncate text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                                {row.name}
                              </span>
                              <span
                                dir={idDir}
                                className="mt-0.5 inline-flex items-center gap-1 rounded-full border border-slate-200 bg-white/80 px-2 py-0.5 font-mono text-[9.5px] font-extrabold tabular-nums text-slate-500 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-300"
                              >
                                <CatIcon name="hash" className="h-2.5 w-2.5 text-slate-400" aria-hidden="true" />
                                {row.studentCode}
                              </span>
                            </span>
                          </div>
                        </td>
                        <td className="px-3.5 py-2.5">
                          <span className="block truncate text-[12px] font-bold text-slate-700 dark:text-slate-200">
                            {row.room}
                          </span>
                          <span className="block truncate text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                            {row.building}
                          </span>
                        </td>
                        <td className="px-3.5 py-2.5">
                          <div className="flex flex-col items-start gap-1">
                            <AttStatePill state={row.state} />
                            {row.lateMinutes !== null && row.lateMinutes > 0 ? (
                              <span dir="auto" className="rounded-full bg-amber-500/12 px-1.5 py-0.5 text-[9.5px] font-extrabold text-amber-700 dark:text-amber-300">
                                {t("attwsLateChip", { min: fmtNum(row.lateMinutes, lang) })}
                              </span>
                            ) : null}
                            {row.overdue ? (
                              <span dir="auto" className="rounded-full bg-rose-500/12 px-1.5 py-0.5 text-[9.5px] font-extrabold text-rose-700 dark:text-rose-300">
                                {t("attwsOverdueChip")}
                              </span>
                            ) : null}
                          </div>
                        </td>
                        <td className="px-3.5 py-2.5">
                          {row.lastMovementAt ? (
                            <span dir="auto" className="block whitespace-nowrap text-[11.5px] font-bold tabular-nums text-slate-600 dark:text-slate-300">
                              {new Intl.DateTimeFormat(lang === "ar" ? "ar-EG" : "en-GB", {
                                hour: "2-digit",
                                minute: "2-digit",
                              }).format(new Date(row.lastMovementAt))}
                              <span
                                className={cn(
                                  "ms-1.5 inline-block h-1.5 w-1.5 rounded-full align-middle",
                                  row.lastDirection === "in" ? "bg-emerald-500" : "bg-rose-500"
                                )}
                                aria-hidden="true"
                              />
                            </span>
                          ) : (
                            <span className="text-[11.5px] font-bold text-slate-300 dark:text-slate-600">—</span>
                          )}
                          {row.state === "outside_with_permission" && row.expectedReturnAt ? (
                            <span dir="auto" className="mt-0.5 block whitespace-nowrap text-[10px] font-bold text-sky-600 dark:text-sky-300">
                              {t("attwsExpectedShort", {
                                time: new Intl.DateTimeFormat(lang === "ar" ? "ar-EG" : "en-GB", {
                                  hour: "2-digit",
                                  minute: "2-digit",
                                }).format(new Date(row.expectedReturnAt)),
                              })}
                            </span>
                          ) : null}
                        </td>
                        <td className="px-3.5 py-2.5">
                          <div className="flex justify-end gap-1.5">
                            <Button
                              type="button"
                              disabled={busy || !canIn}
                              onClick={() => moveMutation.mutate({ row, direction: "in" })}
                              className="h-9 gap-1.5 rounded-lg border border-emerald-300/80 bg-white/85 px-2.5 text-[10.5px] font-extrabold text-emerald-700 transition hover:bg-emerald-50 active:scale-95 disabled:pointer-events-none disabled:opacity-40 dark:border-emerald-500/30 dark:bg-white/[0.07] dark:text-emerald-300 dark:hover:bg-white/[0.12]"
                            >
                              {busy ? (
                                <CatIcon name="refresh-cw" className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                              ) : (
                                <CatIcon name="log-in" className="h-3.5 w-3.5" aria-hidden="true" />
                              )}
                              {t("attwsCheckIn")}
                            </Button>
                            <Button
                              type="button"
                              disabled={busy || !canOut}
                              onClick={() => moveMutation.mutate({ row, direction: "out" })}
                              className="h-9 gap-1.5 rounded-lg border border-rose-300/80 bg-white/85 px-2.5 text-[10.5px] font-extrabold text-rose-700 transition hover:bg-rose-50 active:scale-95 disabled:pointer-events-none disabled:opacity-40 dark:border-rose-500/30 dark:bg-white/[0.07] dark:text-rose-300 dark:hover:bg-white/[0.12]"
                            >
                              <CatIcon name="log-out" className="h-3.5 w-3.5" aria-hidden="true" />
                              {t("attwsCheckOut")}
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </DashCard>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* the workspace shell                                                 */
/* ------------------------------------------------------------------ */

export function AttendanceWorkspace({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const [tab, setTab] = useState<AttTab>("today");
  const attendanceEnabled = instance.modules.includes("attendance");
  const rtl = lang === "ar";

  /* module disabled → the amber stand-down notice (ShiftsWorkspace law) */
  if (!attendanceEnabled) {
    return (
      <div className="space-y-5">
        <ViewHeading title={t("attwsTitle")} desc={t("attwsDesc")} />
        <div
          dir={rtl ? "rtl" : "ltr"}
          className="flex items-center gap-3 rounded-2xl border border-amber-300/60 bg-linear-to-l from-amber-50/90 to-orange-50/50 px-4 py-3 dark:border-amber-500/25 dark:from-amber-500/10 dark:to-orange-500/5"
          role="status"
        >
          <span
            className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-md"
            style={{ backgroundImage: grad("#f59e0b", "#ea580c") }}
            aria-hidden="true"
          >
            <CatIcon name="power" className="h-5 w-5" />
          </span>
          <p className="min-w-0 flex-1 text-[12px] font-extrabold text-amber-800 dark:text-amber-200">
            {t("attwsModuleOff")}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <ViewHeading title={t("attwsTitle")} desc={t("attwsDesc")} />

      <Tabs value={tab} onValueChange={(v) => setTab(v as AttTab)} className="gap-4">
        {/* the premium segmented tab bar — the gradient pill slides
         * (framer-motion layoutId, reduced-motion honored globally) */}
        <TabsList className="h-auto w-full justify-start gap-1 overflow-x-auto rounded-2xl border border-slate-200/80 bg-white/70 p-1 dark:border-white/10 dark:bg-white/[0.04]">
          {ATT_TABS.map((item) => {
            const active = tab === item.id;
            return (
              <TabsTrigger
                key={item.id}
                value={item.id}
                className="relative h-11 min-h-[44px] flex-none rounded-xl px-3.5 text-[12px] font-extrabold data-[state=active]:shadow-none"
              >
                {active ? (
                  <motion.span
                    layoutId="attws-tab-pill"
                    className="absolute inset-0 rounded-xl text-white shadow-md"
                    style={{ backgroundImage: grad(ATT_C[0], ATT_C[1]) }}
                    transition={{ type: "spring", stiffness: 420, damping: 34 }}
                    aria-hidden="true"
                  />
                ) : null}
                <span
                  className={cn(
                    "relative z-10 flex items-center gap-1.5 whitespace-nowrap transition-colors",
                    active
                      ? "text-white"
                      : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white"
                  )}
                >
                  <CatIcon name={item.icon} className="h-3.5 w-3.5" aria-hidden="true" />
                  {t(item.key)}
                </span>
              </TabsTrigger>
            );
          })}
        </TabsList>

        <TabsContent value="today">
          <TodayBoard instance={instance} />
        </TabsContent>
        <TabsContent value="movements">
          <AttendanceMovementsTab instance={instance} />
        </TabsContent>
        <TabsContent value="allowances">
          <AttendanceAllowancesTab instance={instance} />
        </TabsContent>
        <TabsContent value="policy">
          <AttendancePolicyTab instance={instance} />
        </TabsContent>
        <TabsContent value="qr">
          <AttendanceQrTab instance={instance} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default AttendanceWorkspace;
