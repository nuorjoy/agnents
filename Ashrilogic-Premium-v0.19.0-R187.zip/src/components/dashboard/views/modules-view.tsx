"use client";

/**
 * Dashboard — modules view: REAL enable/disable + one-click premium workspace.
 * Every toggle fires PATCH /api/instances/[id] with the next module list,
 * applies an optimistic cache update and toasts the result.
 *
 * ENABLED cards are clickable: clicking anywhere on the card (except the
 * switch) opens that module's premium detail workspace (dashView "module").
 * Disabled cards stay inert (grayscale, no pointer). The module-data strip
 * keeps its info role while the card itself navigates.
 *
 * ROUND 80 — premium-module plan gates: an ENABLED module whose id maps to
 * a catalog feature (MODULE_FEATURE_GATES — pos, barcode, loyalty, staff,
 * branches, insurance, telemedicine, subscriptions) renders in a violet
 * LOCKED state when the tenant's plan lacks the feature: the card click +
 * CTA route to the billing view (upgrade), the workspace never opens, and
 * the records API independently refuses with 403 FEATURE_NOT_IN_PLAN
 * (the client mirror never gates — it only mirrors). Trial / no-package /
 * override-ON workspaces see the cards exactly as before.
 */
import { useMemo, useState, type ReactNode } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CATEGORY_MAP, MODULE_MAP, SYSTEM_MAP, moduleDisplayName, systemMods } from "@/data/catalog";
import { useT } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import type { InstanceDTO } from "@/lib/types";
import { updateInstance } from "@/lib/api-client";
import { apiErrorText } from "@/lib/api-errors";
import { MODULE_FEATURE_GATES } from "@/lib/plan-features";
import { STORE_MODULE_PRIORITY } from "@/lib/store-modules";
import { CatIcon } from "@/components/icon";
import { cn, grad } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { DashCard, ViewHeading } from "@/components/dashboard/dash-shared";

type InstanceQueryData = {
  instance: InstanceDTO;
  stats: unknown;
  members: unknown;
};

/** One label/value cell of the module data strip. */
function DetailCell({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="min-w-0">
      <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500">{label}</p>
      <div className="mt-0.5 min-w-0 text-[11px] font-semibold text-slate-600 dark:text-slate-300">
        {children}
      </div>
    </div>
  );
}

export function ModulesView({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const setDashView = useAppStore((s) => s.setDashView);
  const setActiveModuleId = useAppStore((s) => s.setActiveModuleId);
  /** per-module activation timestamps recorded during this browser session */
  const [activationTimes, setActivationTimes] = useState<Record<string, number>>({});

  const system = SYSTEM_MAP[instance.systemId];
  const cat = system ? CATEGORY_MAP[system.c] : undefined;
  const c1 = cat?.c1 ?? "#6d5dfb";
  const c2 = cat?.c2 ?? "#0ea5e9";
  /* round 29 — the effective module list is the SYSTEM's (specialized
     systems override the category set). */
  const catMods = useMemo(() => systemMods(system), [system]);
  const queryKey = useMemo(() => ["instance", instance.id] as const, [instance.id]);

  const systemName = system ? (lang === "ar" ? system.nameAr : system.nameEn) : instance.systemId;
  const categoryName = cat ? (lang === "ar" ? cat.nameAr : cat.nameEn) : undefined;

  const toggle = useMutation({
    mutationFn: (vars: { moduleId: string; next: string[] }) =>
      updateInstance(instance.id, { modules: vars.next }),
    onMutate: async (vars) => {
      await queryClient.cancelQueries({ queryKey });
      const prev = queryClient.getQueryData<InstanceQueryData>(queryKey);
      queryClient.setQueryData<InstanceQueryData>(queryKey, (old) =>
        old ? { ...old, instance: { ...old.instance, modules: vars.next } } : old
      );
      return { prev, enabled: vars.next.includes(vars.moduleId) };
    },
    onError: (error: Error, _vars, ctx) => {
      if (ctx?.prev) queryClient.setQueryData(queryKey, ctx.prev);
      /* R163 — localized refusals (STORE_MODULE_REQUIRED …) instead of the
         raw English server string. */
      toast.error(apiErrorText(error, t));
    },
    onSuccess: (_data, vars, ctx) => {
      /* ROUND 64 — sector-correct module vocabulary (per-system override) */
      const name = moduleDisplayName(vars.moduleId, instance.systemId, lang);
      if (ctx?.enabled) {
        setActivationTimes((prev) => ({ ...prev, [vars.moduleId]: Date.now() }));
        toast.success(t("modToastOnTitle"), {
          description: categoryName
            ? `${t("modToastOnDesc", { name })} · ${categoryName}`
            : t("modToastOnDesc", { name }),
          icon: undefined,
        });
      } else {
        toast(t("modToastOffTitle"), { description: t("modToastOffDesc", { name }) });
      }
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey });
    },
  });

  const onToggle = (moduleId: string) => {
    const current = queryClient.getQueryData<InstanceQueryData>(queryKey)?.instance.modules ?? instance.modules;
    const next = current.includes(moduleId)
      ? current.filter((m) => m !== moduleId)
      : [...current, moduleId];
    toggle.mutate({ moduleId, next });
  };

  /* open the premium module workspace for an ENABLED module */
  const openModule = (moduleId: string) => {
    setActiveModuleId(moduleId);
    setDashView("module");
  };

  /* ROUND 80 — an enabled module whose plan-feature is OFF navigates to the
     billing view instead of the workspace (upgrade path). */
  const goBilling = () => setDashView("billing");

  /* client mirror of the plan-gate decision (server remains the authority) */
  const features = instance.entitlement?.features;
  /* R163 — strict e-store ⇄ catalog coupling (client mirror of the server
     laws in store-module-gate.ts): while the store feature is ON, every
     catalog-source module (products / inventory / pharmacy / menu) is
     REQUIRED — its switch locks ON and the card carries the amber chip.
     The server stays the authority (409 STORE_MODULE_REQUIRED). */
  const storeActive = features?.store === true;
  const storeRequired = (moduleId: string): boolean =>
    storeActive && STORE_MODULE_PRIORITY.includes(moduleId) && instance.modules.includes(moduleId);
  const modulePlanLocked = (moduleId: string): boolean => {
    const feature = MODULE_FEATURE_GATES[moduleId];
    return feature ? features?.[feature] === false : false;
  };

  return (
    <div className="space-y-5">
      <ViewHeading title={t("dashModulesTitle")} desc={t("dashModulesDesc")} />

      <DashCard title={t("dashModulesList")} icon="cubes">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <Badge className="bg-brand-500/15 text-[11px] text-brand-600 hover:bg-brand-500/15 dark:text-brand-300">
            {instance.modules.length} / {catMods.length} {t("wzModulesSelected")}
          </Badge>
          <p className="text-[11px] font-semibold text-slate-400 dark:text-slate-500">
            {t("modClickHint")}
          </p>
        </div>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {catMods.map((key, i) => {
            const m = MODULE_MAP[key];
            const enabled = instance.modules.includes(key);
            /* ROUND 80 — plan-gate: enabled + outside the plan → locked card */
            const planLocked = enabled && modulePlanLocked(key);
            /* ROUND 64 — sector-correct module vocabulary (per-system override) */
            const name = moduleDisplayName(key, instance.systemId, lang);
            const activatedAt = activationTimes[key];
            return (
              <div
                key={key}
                role={enabled ? "button" : undefined}
                tabIndex={enabled ? 0 : undefined}
                aria-label={
                  enabled
                    ? planLocked
                      ? t("modLockedAria", { name })
                      : t("modOpenAria", { name })
                    : undefined
                }
                onClick={
                  enabled
                    ? () => {
                        if (planLocked) goBilling();
                        else openModule(key);
                      }
                    : undefined
                }
                onKeyDown={
                  enabled
                    ? (e) => {
                        if (e.key === "Enter" || e.key === " ") {
                          e.preventDefault();
                          if (planLocked) goBilling();
                          else openModule(key);
                        }
                      }
                    : undefined
                }
                className={cn(
                  "rounded-2xl border p-3.5 transition",
                  planLocked
                    ? "cursor-pointer border-violet-400/70 bg-linear-to-br from-violet-50/70 to-fuchsia-50/40 outline-none hover:border-violet-500 hover:shadow-lift focus-visible:ring-4 focus-visible:ring-violet-500/20 active:scale-[0.99] dark:border-violet-500/40 dark:from-violet-500/10 dark:to-fuchsia-500/5 dark:hover:border-violet-500/70"
                    : enabled
                      ? "cursor-pointer border-brand-400/70 bg-brand-50/40 outline-none hover:border-brand-500 hover:shadow-lift focus-visible:ring-4 focus-visible:ring-brand-500/20 active:scale-[0.99] dark:border-brand-500/40 dark:bg-brand-500/10 dark:hover:border-brand-500/70"
                      : "border-slate-200 bg-white dark:border-white/10 dark:bg-white/[0.03]",
                  toggle.isPending && "opacity-90"
                )}
              >
                <div className="flex items-center gap-3">
                  <span
                    className={cn(
                      "grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white transition",
                      !enabled && "opacity-50 grayscale"
                    )}
                    style={{
                      backgroundImage: planLocked
                        ? "linear-gradient(135deg,#8b5cf6,#d946ef)"
                        : enabled
                          ? grad(c1, c2)
                          : "linear-gradient(135deg,#cbd5e1,#94a3b8)",
                    }}
                  >
                    <CatIcon name={m?.icon ?? "cubes"} className="h-[13px] w-[13px]" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12.5px] font-bold text-slate-700 dark:text-slate-200">{name}</p>
                    <p className="text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                      {planLocked ? (
                        <span className="inline-flex items-center gap-1 text-violet-600 dark:text-violet-300">
                          <CatIcon name="lock" className="h-3 w-3" />
                          {t("modLockedChip")}
                        </span>
                      ) : enabled ? (
                        <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                          <CatIcon name="circle-check" className="h-3 w-3" />
                          {t("dashEnabled")}
                          {storeRequired(key) ? (
                            <span className="ms-1.5 inline-flex items-center gap-1 rounded-full bg-amber-400/15 px-1.5 py-px text-[9.5px] font-extrabold text-amber-700 dark:bg-amber-400/10 dark:text-amber-300">
                              <CatIcon name="store" className="h-2.5 w-2.5 shrink-0" aria-hidden="true" />
                              {t("modStoreRequiredChip")}
                            </span>
                          ) : null}
                        </span>
                      ) : (
                        t("dashEmptyState")
                      )}
                    </p>
                  </div>
                  {planLocked ? (
                    <span
                      className="hidden shrink-0 items-center gap-1 rounded-full bg-violet-500/10 px-2 py-0.5 text-[11px] font-extrabold text-violet-600 dark:text-violet-300 sm:inline-flex"
                      aria-hidden="true"
                    >
                      <CatIcon name="trending-up" className="h-2.5 w-2.5" />
                      {t("modLockedCta")}
                    </span>
                  ) : enabled ? (
                    <span
                      className="hidden shrink-0 items-center gap-1 rounded-full bg-brand-500/10 px-2 py-0.5 text-[11px] font-extrabold text-brand-600 dark:text-brand-300 sm:inline-flex"
                      aria-hidden="true"
                    >
                      {t("modOpenChip")}
                      <CatIcon name="arrow-right" className="h-2.5 w-2.5 rtl:rotate-180" />
                    </span>
                  ) : null}
                  <Switch
                    checked={enabled}
                    onCheckedChange={() => onToggle(key)}
                    /* R163 — a catalog-source module is LOCKED ON while the
                       e-store runs (server refuses the drop with 409). */
                    disabled={toggle.isPending || storeRequired(key)}
                    aria-label={name}
                    /* stopPropagation so flipping the switch never navigates */
                    className="relative z-10"
                    onClick={(e) => e.stopPropagation()}
                  />
                </div>

                {planLocked ? (
                  <div className="step-in mt-3 border-t border-dashed border-violet-300/80 pt-2.5 dark:border-violet-500/25">
                    <p className="flex items-start gap-1.5 text-[11px] font-semibold leading-relaxed text-violet-700/90 dark:text-violet-300/90">
                      <CatIcon name="lock" className="mt-0.5 h-3 w-3 shrink-0" />
                      {t("modLockedNote")}
                    </p>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        goBilling();
                      }}
                      className="mt-2.5 flex h-8 w-full items-center justify-center gap-1.5 rounded-xl bg-linear-to-l from-violet-600 to-fuchsia-500 text-[11px] font-extrabold text-white shadow-md shadow-violet-500/25 transition hover:brightness-110 active:scale-[0.98]"
                    >
                      <CatIcon name="trending-up" className="h-[13px] w-[13px]" />
                      {t("modLockedCta")}
                    </button>
                  </div>
                ) : enabled ? (
                  <div className="step-in mt-3 border-t border-dashed border-slate-300/80 pt-2.5 dark:border-white/15">
                    <div className="flex items-center justify-between gap-2">
                      <span className="flex items-center gap-1.5">
                        <CatIcon name="info" className="h-3 w-3 text-brand-500 dark:text-brand-400" />
                        <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                          {t("modDetailsChip")}
                        </span>
                      </span>
                      <span className="inline-flex shrink-0 items-center rounded-full bg-slate-100 px-1.5 py-px text-[11px] font-bold text-slate-500 dark:bg-white/10 dark:text-slate-400">
                        {t("modIndexInSystem", { index: i + 1, total: catMods.length })}
                      </span>
                    </div>
                    <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-2">
                      <DetailCell label={t("modDetailsId")}>
                        <span
                          dir="ltr"
                          className="inline-block max-w-full truncate rounded bg-slate-100 px-1.5 py-px font-mono text-[10.5px] text-slate-600 dark:bg-white/10 dark:text-slate-300"
                        >
                          {key}
                        </span>
                      </DetailCell>
                      <DetailCell label={t("modDetailsSystem")}>
                        <p className="truncate">{systemName}</p>
                      </DetailCell>
                      <DetailCell label={t("modDetailsCategory")}>
                        <p className="truncate">{categoryName ?? "—"}</p>
                      </DetailCell>
                      <DetailCell label={t("modDetailsStatus")}>
                        <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 px-1.5 py-px text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                          <CatIcon name="check" className="h-2.5 w-2.5" />
                          {t("modDetailsActive")}
                        </span>
                      </DetailCell>
                      <div className="col-span-2">
                        <DetailCell label={t("modActivatedAt")}>
                          <p className="truncate tabular-nums">
                            {activatedAt
                              ? new Date(activatedAt).toLocaleTimeString(lang === "ar" ? "ar" : "en", {
                                  hour: "2-digit",
                                  minute: "2-digit",
                                })
                              : "—"}
                          </p>
                        </DetailCell>
                      </div>
                    </div>

                    {/* ROUND 36 — explicit "view data" action: jumps straight
                        into this module's record workspace (invoices /
                        patients / staff …). Card clicks keep the same target;
                        the button makes the affordance unmistakable. */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        openModule(key);
                      }}
                      title={t("modViewDataHint")}
                      className="mt-2.5 flex h-8 w-full items-center justify-center gap-1.5 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 text-[11px] font-extrabold text-white shadow-md shadow-brand-500/20 transition hover:brightness-110 active:scale-[0.98]"
                    >
                      <CatIcon name="table" className="h-[13px] w-[13px]" />
                      {t("modViewDataBtn")}
                      <CatIcon name="arrow-right" className="h-3 w-3 rtl:rotate-180" />
                    </button>
                  </div>
                ) : null}
              </div>
            );
          })}
        </div>
      </DashCard>
    </div>
  );
}

export function ModulesViewSkeleton() {
  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: 6 }).map((_, i) => (
        <Skeleton key={i} className="h-[72px] rounded-2xl" />
      ))}
    </div>
  );
}
