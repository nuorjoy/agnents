"use client";

/**
 * Ashrilogic — dashboard E-STORE view (round 44).
 *
 * The storefront was SEPARATED from the public-website view per the owner's
 * request: this page is the dedicated «المتجر الإلكتروني» surface —
 *
 *  - storefront status rail (live / draft / unavailable + visit link),
 *  - a KPI strip over the live order queue (total orders, total sales,
 *    open orders, listed products),
 *  - the store catalog card (product count + live categories, derived from
 *    the workspace's enabled catalog module),
 *  - the full order-management queue (status filters, expandable rows,
 *    lifecycle advance with owner notes) moved here verbatim from the
 *    former website view.
 *
 * Availability + product counts come from the OWNER-scoped
 * /api/instances/[id]/store endpoint (draft sites included); order data
 * rides the same ["instance-orders", id] query the queue uses, so the KPI
 * strip and the table share one cached fetch.
 *
 * ROUND 136 — the KPI strip upgraded to the unified premium StatCard.
 * ROUND 139 — the strip now renders THE golden inventory-page card law
 * (size="golden" inside the exact inventory grid grid-cols-2 → md:grid-cols-3
 * → xl:grid-cols-5), expanded 4 → 5 KPIs so the golden 5-column grid fills
 * exactly: the COMPLETED-orders cohort is promoted to its own headline card
 * (sub-line: cancelled count — the R136-A inventory pattern where the promoted
 * number keeps its trace in the sibling sub-lines).
 */

import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import type { InstanceDTO } from "@/lib/types";
import { useT } from "@/lib/i18n";
import { fetchInstanceOrders, fetchInstanceStoreStatus, updateInstance } from "@/lib/api-client";
import { apiErrorText } from "@/lib/api-errors";
import { useAppStore } from "@/lib/store";
import { SYSTEM_MAP, systemMods } from "@/data/catalog";
import { CatIcon } from "@/components/icon";
import { cn, fmtMoneyCell, grad } from "@/lib/utils";
import { StatCard } from "@/components/shared/stat-card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { DashCard, ViewHeading } from "@/components/dashboard/dash-shared";
import { FeatureGate } from "@/components/dashboard/feature-gate";
import { nf } from "./store/shared";
import { TopProductsPanel, SalesByDayPanel } from "./store/analytics";
import { ProductsPanel } from "./store/products-panel";
import { CouponsPanel } from "./store/coupons-panel";
import { ReviewsPanel } from "./store/reviews-panel";
import { SiteOrdersPanel } from "./store/orders-panel";

/* ------------------------------------------------ the E-Store page ----- */

export function StoreView({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const setDashView = useAppStore((s) => s.setDashView);
  const queryClient = useQueryClient();

  /* R163 — strict e-store ⇄ catalog coupling: one-click activation of the
     forced pair (products + inventory, catalog-permitting) from the
     unavailable-store guidance card. The SERVER unions the same pair on
     every write (LAW 3 in store-module-gate.ts) — this is the mirror. */
  const activateModules = useMutation({
    mutationFn: () => {
      const system = SYSTEM_MAP[instance.systemId];
      const catalog = system ? systemMods(system) : [];
      const forced = ["products", "inventory"].filter((m) => catalog.includes(m));
      return updateInstance(instance.id, {
        modules: Array.from(new Set([...instance.modules, ...forced])),
      });
    },
    onSuccess: () => {
      toast.success(t("estoreModulesActivated"));
      void queryClient.invalidateQueries({ queryKey: ["instance", instance.id] });
      void queryClient.invalidateQueries({ queryKey: ["instance-store", instance.id] });
    },
    onError: (error: Error) => toast.error(apiErrorText(error, t)),
  });

  /* owner-scoped storefront status — answers for DRAFT sites too */
  const storeQuery = useQuery({
    queryKey: ["instance-store", instance.id],
    queryFn: () => fetchInstanceStoreStatus(instance.id),
    staleTime: 30_000,
    retry: 0,
  });

  /* ROUND 57 — the page KPI strip rides a LIGHT counts-only page (limit 1)
   * whose aggregates are instance-wide SERVER truth: the totals no longer
   * shrink with any loaded window, and the fetch stays cheap. */
  const countsQuery = useQuery({
    queryKey: ["instance-orders-counts", instance.id],
    queryFn: () => fetchInstanceOrders(instance.id, { limit: 1 }),
    staleTime: 15_000,
    retry: 0,
  });

  const available = storeQuery.data?.available === true;
  const published = storeQuery.data?.published ?? false;
  const productCount = storeQuery.data?.productCount ?? 0;
  const categories = storeQuery.data?.categories ?? [];
  const currency = storeQuery.data?.currency ?? "SAR";

  /* ROUND 59 — low-stock surfacing: the SAME rule the storefront card
   * uses (statusKey "low" OR stock ≤ 10) over the owner store payload.
   * The dismiss is per-mount UI state — a fresh view/instance mount
   * re-arms the alert. */
  const [lowStockDismissed, setLowStockDismissed] = useState(false);
  const lowStock = useMemo(
    () =>
      (storeQuery.data?.products ?? []).filter(
        (p) => p.statusKey === "low" || p.stock <= 10
      ),
    [storeQuery.data]
  );
  /* the count is emphasized inline: interpolate a sentinel, then split
   * the localized message around it ({n} sits at a different position in
   * every dictionary, so a plain split keeps all three languages intact) */
  const lowStockParts = t("estoreLowStockBanner", { n: "\u0001" }).split("\u0001");

  const counts = countsQuery.data?.counts;
  const totalOrders = counts?.all ?? 0;
  /* open + pending = everything the owner still has to work */
  const openOrders = (counts?.open ?? 0) + (counts?.pending ?? 0);
  const totalSales = counts?.revenue ?? 0;
  /* ROUND 136 — average order value over the orders that actually
   * count: `revenue` is net of cancelled, so cancelled orders leave
   * the denominator too. Null (→ the explicit empty sub-line) while
   * there is not a single counted order. */
  const countedOrders = Math.max(0, totalOrders - (counts?.cancelled ?? 0));
  const avgOrderValue = countedOrders > 0 ? totalSales / countedOrders : null;

  /* ROUND 136 — KPI drill-down targets (the orders card → the live
   * order queue, the products card → the photos console; both panels
   * sit below, scroll-mt clears the sticky topbar). */
  const scrollToOrdersPanel = () =>
    document
      .getElementById("estore-orders-panel")
      ?.scrollIntoView({ behavior: "smooth" });
  const scrollToProductsPanel = () =>
    document
      .getElementById("estore-products-panel")
      ?.scrollIntoView({ behavior: "smooth" });

  if (storeQuery.isPending) {
    return (
      <div className="space-y-5">
        <ViewHeading title={t("dashStore")} desc={t("dashStoreDesc")} />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-24 w-full rounded-2xl" />
          ))}
        </div>
        <Skeleton className="h-64 w-full rounded-3xl" />
      </div>
    );
  }

  if (!available) {
    /* no catalog module enabled — the strict R163 auto-fix: when the
     system's catalog CARRIES the products/inventory modules, one click
     activates them (the server unions the forced pair into the persisted
     list — see store-module-gate.ts LAW 3); otherwise the professional
     guidance card routes to the modules console as before. */
    const system = SYSTEM_MAP[instance.systemId];
    const catalog = system ? systemMods(system) : [];
    const autoFix = ["products", "inventory"].filter((m) => catalog.includes(m));
    return (
      <div className="space-y-5">
        <ViewHeading title={t("dashStore")} desc={t("dashStoreDesc")} />
        <div className="mx-auto max-w-xl rounded-3xl border-2 border-dashed border-slate-200 bg-white/70 p-10 text-center dark:border-white/10 dark:bg-white/[0.02]">
          <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
            <CatIcon name="store" className="h-7 w-7" />
          </span>
          <h3 className="mt-4 font-display text-[17px] font-extrabold text-slate-900 dark:text-white">
            {t("estoreUnavailableTitle")}
          </h3>
          <p className="mx-auto mt-2 max-w-md text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
            {t("estoreUnavailableDesc")}
          </p>
          {autoFix.length > 0 ? (
            <Button
              type="button"
              onClick={() => activateModules.mutate()}
              disabled={activateModules.isPending}
              className="mt-6 h-11 gap-2 rounded-xl px-6 text-[13px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.99] disabled:opacity-60"
              style={{
                backgroundImage: grad("#6d5dfb", "#0ea5e9"),
                boxShadow: "0 12px 26px -10px rgba(109, 93, 251, 0.75)",
              }}
            >
              {activateModules.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" aria-hidden="true" />
              ) : (
                <CatIcon name="package-check" className="h-4 w-4" aria-hidden="true" />
              )}
              {t("estoreActivateModules")}
            </Button>
          ) : (
            <Button
              type="button"
              onClick={() => setDashView("modules")}
              className="mt-6 h-11 gap-2 rounded-xl px-6 text-[13px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.99]"
              style={{
                backgroundImage: grad("#6d5dfb", "#0ea5e9"),
                boxShadow: "0 12px 26px -10px rgba(109, 93, 251, 0.75)",
              }}
            >
              <CatIcon name="cubes" className="h-4 w-4" />
              {t("estoreOpenModules")}
            </Button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <ViewHeading title={t("dashStore")} desc={t("dashStoreDesc")} />

      {/* ROUND 59 — low-stock alert banner: amber attention card with a
          pulsing dot, the localized count emphasized, a CTA that
          smooth-scrolls to the products console, and a ghost dismiss on
          the inline-END side. Stacks under the heading on mobile. */}
      {lowStock.length > 0 && !lowStockDismissed ? (
        <div
          role="status"
          className="card-in flex flex-col gap-3 rounded-2xl border border-amber-300/60 bg-gradient-to-l from-amber-500/10 to-orange-500/10 p-4 shadow-sm sm:flex-row sm:items-center sm:gap-4 dark:border-amber-500/40 dark:from-amber-500/[0.13] dark:to-orange-500/[0.13]"
        >
          <div className="flex min-w-0 items-center gap-3">
            <span
              className="relative grid h-11 w-11 shrink-0 place-items-center rounded-2xl border border-amber-300/70 bg-amber-500/15 text-amber-600 dark:border-amber-500/40 dark:bg-amber-500/20 dark:text-amber-300"
              aria-hidden="true"
            >
              <CatIcon name="triangle-alert" className="h-5 w-5" />
              <span className="absolute -end-1 -top-1 h-3 w-3 animate-pulse rounded-full bg-amber-500 ring-2 ring-white dark:ring-slate-950" />
            </span>
            <p className="min-w-0 flex-1 text-[13px] font-bold leading-relaxed text-amber-800 dark:text-amber-200">
              {lowStockParts.length === 2 ? (
                <>
                  {lowStockParts[0]}
                  <strong className="font-extrabold tabular-nums text-amber-900 dark:text-amber-100">
                    {nf(lang, lowStock.length)}
                  </strong>
                  {lowStockParts[1]}
                </>
              ) : (
                t("estoreLowStockBanner", { n: nf(lang, lowStock.length) })
              )}
            </p>
          </div>
          <div className="flex shrink-0 items-center gap-2 sm:ms-auto">
            <Button
              type="button"
              onClick={() =>
                document
                  .getElementById("estore-products-panel")
                  ?.scrollIntoView({ behavior: "smooth" })
              }
              className="h-9 gap-1.5 rounded-xl px-4 text-[12px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.98]"
              style={{
                backgroundImage: grad("#f59e0b", "#d97706"),
                boxShadow: "0 12px 26px -10px rgba(245, 158, 11, 0.65)",
              }}
            >
              <CatIcon name="package" className="size-3.5" />
              {t("estoreLowStockCta")}
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              onClick={() => setLowStockDismissed(true)}
              aria-label={t("estoreLowStockDismiss")}
              title={t("estoreLowStockDismiss")}
              className="h-9 w-9 shrink-0 rounded-xl text-amber-700/70 hover:bg-amber-500/15 hover:text-amber-800 active:scale-95 dark:text-amber-300/70 dark:hover:bg-amber-500/15 dark:hover:text-amber-200"
            >
              <CatIcon name="x" />
            </Button>
          </div>
        </div>
      ) : null}

      {/* storefront KPI strip — ROUND 139: THE golden inventory-page cards
          (grid-cols-2 → md:grid-cols-3 → xl:grid-cols-5; count-up numerals,
          fmtMoneyCell money with the Arabic-Indic RTL policy, precision
          sub-lines, skeleton while the counts page loads, drill-down into
          the panels below). */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        <StatCard
          size="golden"
          label={t("estoreKpiOrders")}
          numeric={totalOrders}
          sub={t("estoreKpiOrdersSub", { n: nf(lang, openOrders) })}
          icon="package"
          c1="#8b5cf6"
          c2="#7c3aed"
          index={0}
          lang={lang}
          loading={countsQuery.isPending}
          onClick={scrollToOrdersPanel}
          hint={t("ordPanelTitle")}
        />
        <StatCard
          size="golden"
          label={t("estoreKpiRevenue")}
          value={fmtMoneyCell(totalSales, lang, currency)}
          sub={
            avgOrderValue !== null
              ? t("estoreKpiAvgOrder", { v: fmtMoneyCell(avgOrderValue, lang, currency) })
              : t("estoreKpiRevenueSubEmpty")
          }
          icon="banknote"
          c1="#10b981"
          c2="#059669"
          index={1}
          lang={lang}
          tone="up"
          loading={countsQuery.isPending}
        />
        <StatCard
          size="golden"
          label={t("estoreKpiPending")}
          numeric={openOrders}
          sub={t("estoreKpiOpenSub", {
            n: nf(lang, counts?.completed ?? 0),
            m: nf(lang, counts?.cancelled ?? 0),
          })}
          icon="hourglass"
          c1="#f59e0b"
          c2="#d97706"
          index={2}
          lang={lang}
          tone="up"
          loading={countsQuery.isPending}
        />
        <StatCard
          size="golden"
          label={t("estoreKpiCompleted")}
          numeric={counts?.completed ?? 0}
          sub={t("estoreKpiCompletedSub", { n: nf(lang, counts?.cancelled ?? 0) })}
          icon="circle-check"
          c1="#06b6d4"
          c2="#0891b2"
          index={3}
          lang={lang}
          tone="up"
          loading={countsQuery.isPending}
        />
        <StatCard
          size="golden"
          label={t("estoreKpiProducts")}
          numeric={productCount}
          sub={t("estoreKpiProductsSub", { n: nf(lang, categories.length) })}
          icon="shopping-bag"
          c1="#f43f5e"
          c2="#e11d48"
          index={4}
          lang={lang}
          onClick={scrollToProductsPanel}
          hint={t("estoreProductsTitle")}
        />
      </div>

      {/* status + catalog rail */}
      <div className="grid gap-4 lg:grid-cols-3">
        <DashCard title={t("estoreStatusTitle")} icon="store">
          <div className="space-y-3">
            {/* ROUND 45 — the workspace's brand identity crowns the e-store console */}
            {instance.site?.logoUrl ? (
              <span
                className="grid h-14 w-14 place-items-center overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-md dark:border-white/10 dark:bg-white/90"
                aria-hidden="true"
              >
                <img
                  src={instance.site.logoUrl}
                  alt=""
                  className="h-full w-full object-contain p-1.5"
                />
              </span>
            ) : null}
            <div
              className={cn(
                "flex items-center gap-2.5 rounded-xl border px-3.5 py-3",
                published
                  ? "border-emerald-300/60 bg-emerald-500/10 dark:border-emerald-500/40"
                  : "border-amber-300/60 bg-amber-500/10 dark:border-amber-500/40"
              )}
            >
              <span className={cn("h-2 w-2 shrink-0 rounded-full", published ? "animate-pulse bg-emerald-500" : "bg-amber-500")} />
              <p className={cn("text-[12.5px] font-extrabold", published ? "text-emerald-700 dark:text-emerald-300" : "text-amber-700 dark:text-amber-300")}>
                {published ? t("estoreStatusLive") : t("estoreStatusDraft")}
              </p>
            </div>
            <p className="text-[11.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {t("estoreCatalogDesc")}
            </p>
            {published ? (
              <Button
                variant="outline"
                size="sm"
                asChild
                className="h-9 w-full gap-2 rounded-xl text-[12px] font-bold"
              >
                <a href={`/sites/${instance.id}/store`} target="_blank" rel="noopener noreferrer">
                  <CatIcon name="external-link" className="h-3.5 w-3.5" />
                  {t("estoreVisit")}
                </a>
              </Button>
            ) : null}
          </div>
        </DashCard>

        <DashCard title={t("estoreCatalogTitle")} icon="shopping-bag" className="lg:col-span-2">
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="outline" className="gap-1.5 rounded-full px-3 py-1 text-[11px] font-extrabold">
                <CatIcon name="package" className="h-3 w-3 text-brand-500" />
                {t("estoreKpiProducts")}: {nf(lang, productCount)}
              </Badge>
              {categories.slice(0, 8).map((cat) => (
                <Badge
                  key={cat}
                  variant="outline"
                  className="max-w-40 truncate rounded-full px-3 py-1 text-[11px] font-bold text-slate-500 dark:text-slate-400"
                >
                  {cat}
                </Badge>
              ))}
              {categories.length > 8 ? (
                <span className="text-[11px] font-extrabold text-slate-400 dark:text-slate-500">
                  +{nf(lang, categories.length - 8)} {t("estoreCategories")}
                </span>
              ) : null}
            </div>
            <p className="text-[11.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {t("estoreCatalogDesc")}
            </p>
          </div>
        </DashCard>
      </div>

      {/* ROUND 53 — best-sellers analytics (client-side over the shared
       *  orders cache — ranked products, 7-day momentum, counted revenue) */}
      <TopProductsPanel instance={instance} />

      {/* ROUND 54 — sales-by-day mini-chart (14-day revenue bars, same
       *  cached orders feed; today highlighted with the brand gradient) */}
      <SalesByDayPanel instance={instance} />

      {/* ROUND 51 — product photos console (visual merchandising).
          ROUND 59: wrapped in an anchor target for the low-stock banner's
          smooth-scroll CTA (scroll-mt clears the sticky topbar). */}
      <div id="estore-products-panel" className="scroll-mt-24">
        <ProductsPanel instance={instance} />
      </div>

      {/* ROUND 50 — coupon console (promotions the guests redeem at checkout).
          ROUND 79 — plan gate: coupons outside the plan render the compact
          premium lock banner instead of the console. */}
      <FeatureGate feature="coupons" instance={instance} compact>
        <CouponsPanel instance={instance} />
      </FeatureGate>

      {/* ROUND 63 — review moderation console (what guests say about the
          products: hide/show/delete + the aggregate chips). ROUND 79 — plan
          gate: reviews outside the plan render the compact lock banner. */}
      <FeatureGate feature="reviews" instance={instance} compact>
        <ReviewsPanel instance={instance} />
      </FeatureGate>

      {/* order management — the owner's live order queue. ROUND 136:
          wrapped in an anchor target for the orders KPI's drill-down. */}
      <div id="estore-orders-panel" className="scroll-mt-24">
        <SiteOrdersPanel instance={instance} />
      </div>
    </div>
  );
}
