"use client";

/**
 * Ashrilogic — ROUND 74 — the owner's «إدارة استفسارات الموقع» triage dialog.
 *
 * Mounted by the customers view (and openable per-customer from the inquiry
 * chips): the full text of every public inquiry filed through the workspace's
 * website, with real triage — reply, status and priority on each thread.
 * The reply lands on the customer's unified account («استفساراتي» tab) and
 * re-badges their account button until they open it (replyUnread).
 *
 * ROUND 77 — variant="admin": the same dialog mounted by the SUPER ADMIN
 * sites-customers sheet (platform-side twin — admin API surface, admin
 * gradient, org-scoped title, site-customers invalidation). One component,
 * two consoles, the customer reads the same words either way.
 *
 * Design: the dashboard's premium vocabulary — gradient icon tiles, status
 * chips with the SUPPORT dictionary (customer and owner read the same
 * words), emerald reply cards, animated composer, skeletons, empty state.
 */
import { useEffect, useMemo, useState, type CSSProperties } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { useT } from "@/lib/i18n";
import type { I18nKey } from "@/lib/i18n";
import type { SiteInquiryTriageDTO } from "@/lib/types";
import {
  ApiError,
  fetchAdminSiteInquiries,
  fetchInstanceSiteInquiries,
  triageAdminSiteInquiry,
  triageInstanceSiteInquiry,
} from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, initial } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { fullDate, relativeTime } from "@/components/dashboard/dash-shared";

/* the SUPPORT dictionary — the exact chips the customer's own «استفساراتي»
 * tab paints, so both sides of the conversation read the same words. */
const STATUS_META: Record<string, { label: I18nKey; icon: string; chip: string }> = {
  open: {
    label: "supStatusOpen",
    icon: "inbox",
    chip: "border-amber-300/60 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300",
  },
  pending: {
    label: "supStatusPending",
    icon: "clock",
    chip: "border-sky-300/60 bg-sky-500/10 text-sky-600 dark:border-sky-500/40 dark:text-sky-300",
  },
  resolved: {
    label: "supStatusResolved",
    icon: "check",
    chip: "border-emerald-300/60 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300",
  },
  closed: {
    label: "supStatusClosed",
    icon: "archive",
    chip: "border-slate-300/60 bg-slate-500/10 text-slate-500 dark:border-white/15 dark:text-slate-400",
  },
};

const CATEGORY_KEY: Record<string, I18nKey> = {
  billing: "supCatBilling",
  technical: "supCatTechnical",
  general: "supCatGeneral",
  feature: "supCatFeature",
  urgent: "supPrioUrgent",
};

const PRIORITY_KEY: Record<string, I18nKey> = {
  low: "supPrioLow",
  medium: "supPrioMedium",
  high: "supPrioHigh",
  urgent: "supPrioUrgent",
};

const PRIORITY_CHIP: Record<string, string> = {
  low: "border-slate-300/60 bg-slate-500/10 text-slate-500 dark:border-white/15 dark:text-slate-400",
  medium: "border-sky-300/60 bg-sky-500/10 text-sky-600 dark:border-sky-500/40 dark:text-sky-300",
  high: "border-orange-300/60 bg-orange-500/10 text-orange-600 dark:border-orange-500/40 dark:text-orange-300",
  urgent: "border-rose-300/60 bg-rose-500/10 text-rose-600 dark:border-rose-500/40 dark:text-rose-300",
};

const STATUS_OPTIONS = ["open", "pending", "resolved", "closed"] as const;
const PRIORITY_OPTIONS = ["low", "medium", "high", "urgent"] as const;

const C1 = "#06b6d4";
const C2 = "#0891b2";

/* ---------------- one triage card (read + reply) ---------------- */

function TriageCard({
  inquiry,
  index,
  instanceId,
  variant,
  onReplied,
}: {
  inquiry: SiteInquiryTriageDTO;
  index: number;
  instanceId: string;
  variant: "owner" | "admin";
  onReplied: () => void;
}) {
  const { t, lang } = useT();
  const [expanded, setExpanded] = useState(false);
  const [replying, setReplying] = useState(false);
  const [reply, setReply] = useState("");
  const [status, setStatus] = useState<string>("");
  const [priority, setPriority] = useState<string>("");

  const meta = STATUS_META[inquiry.status] ?? STATUS_META.open;
  const catKey = CATEGORY_KEY[inquiry.category];
  const prioKey = PRIORITY_KEY[inquiry.priority];
  const hot = inquiry.priority === "high" || inquiry.priority === "urgent";
  const long = inquiry.message.length > 220;
  const hasReply = inquiry.reply != null && inquiry.reply.trim().length > 0;

  useEffect(() => {
    if (replying && reply === "") {
      setReply(inquiry.reply ?? "");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [replying]);

  const sendMutation = useMutation({
    mutationFn: () => {
      const payload: { reply?: string; status?: string; priority?: string } = {};
      if (reply.trim().length >= 2) payload.reply = reply.trim();
      if (status) payload.status = status;
      if (priority) payload.priority = priority;
      return variant === "admin"
        ? triageAdminSiteInquiry(instanceId, inquiry.id, payload)
        : triageInstanceSiteInquiry(instanceId, inquiry.id, payload);
    },
    onSuccess: () => {
      toast.success(t("siteInqSent"));
      setReplying(false);
      setReply("");
      setStatus("");
      setPriority("");
      onReplied();
    },
    onError: (error) => {
      toast.error(error instanceof ApiError ? error.message : t("errorText"));
    },
  });

  return (
    <li
      className="card-in rounded-2xl border border-slate-200 bg-white p-3.5 shadow-soft dark:border-white/10 dark:bg-white/[0.03]"
      style={{ "--i": Math.min(index, 6) } as CSSProperties}
    >
      {/* header: status + category + priority + updated */}
      <div className="flex flex-wrap items-center gap-1.5">
        <span
          className={cn(
            "inline-flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10.5px] font-extrabold",
            meta.chip
          )}
        >
          <span className="relative flex h-1.5 w-1.5 shrink-0" aria-hidden="true">
            {hot && inquiry.status !== "closed" && inquiry.status !== "resolved" ? (
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-current opacity-75" />
            ) : null}
            <span className="relative inline-flex h-1.5 w-1.5 shrink-0 rounded-full bg-current" />
          </span>
          <CatIcon name={meta.icon} className="h-3 w-3" />
          {t(meta.label)}
        </span>
        {catKey ? (
          <span
            className="inline-flex shrink-0 items-center rounded-full border px-2 py-0.5 text-[9.5px] font-extrabold"
            style={{
              borderColor: "rgba(6,182,212,0.3)",
              backgroundColor: "rgba(6,182,212,0.07)",
              color: C1,
            }}
          >
            {t(catKey)}
          </span>
        ) : null}
        {prioKey ? (
          <span
            className={cn(
              "inline-flex shrink-0 items-center gap-1 rounded-full border px-2 py-0.5 text-[9.5px] font-extrabold",
              PRIORITY_CHIP[inquiry.priority] ?? PRIORITY_CHIP.medium
            )}
          >
            <CatIcon name="flag" className="h-[9px] w-[9px]" />
            {t(prioKey)}
          </span>
        ) : null}
        <span
          className="ms-auto shrink-0 text-[10.5px] font-bold text-slate-400 dark:text-slate-500"
          title={fullDate(inquiry.updatedAt, lang)}
        >
          {relativeTime(inquiry.updatedAt, lang)}
        </span>
      </div>

      {/* subject + requester */}
      <div className="mt-2.5 flex items-start gap-2.5">
        <span
          className="grid h-8 w-8 shrink-0 place-items-center rounded-xl text-[11px] font-black text-white"
          style={{ backgroundImage: grad("#6d5dfb", "#4b35c9") }}
          aria-hidden="true"
        >
          {initial(inquiry.requesterName)}
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[12.5px] font-extrabold leading-relaxed text-slate-800 dark:text-slate-100">
            {inquiry.subject}
          </p>
          <p className="mt-0.5 truncate text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
            {t("siteInqFrom")}: <span className="font-extrabold text-slate-500 dark:text-slate-400">{inquiry.requesterName}</span>
            <span dir="ltr" className="ms-1.5 font-semibold">
              · {inquiry.requesterEmail}
            </span>
          </p>
        </div>
      </div>

      {/* the customer's message — clamped until expanded */}
      <p
        className={cn(
          "mt-2 whitespace-pre-line rounded-xl bg-slate-50 px-3 py-2.5 text-[12px] font-semibold leading-relaxed text-slate-600 dark:bg-white/[0.04] dark:text-slate-300",
          !expanded && long && "line-clamp-3"
        )}
      >
        {inquiry.message}
      </p>
      {long ? (
        <button
          type="button"
          onClick={() => setExpanded((v) => !v)}
          aria-expanded={expanded}
          className="mt-1 inline-flex h-7 items-center gap-1 rounded-lg px-1.5 text-[10.5px] font-extrabold text-cyan-600 transition hover:brightness-110 active:scale-95 dark:text-cyan-300"
        >
          <CatIcon
            name="chevron-down"
            className={cn("h-3 w-3 transition-transform", expanded && "rotate-180")}
          />
          {t(expanded ? "acctInqLess" : "acctInqMore")}
        </button>
      ) : null}

      {/* the current reply (if any) */}
      {hasReply && !replying ? (
        <div className="mt-2.5 rounded-xl border border-emerald-300/50 bg-gradient-to-l from-emerald-500/[0.08] to-teal-500/[0.06] px-3 py-2.5 dark:border-emerald-500/30 dark:from-emerald-500/[0.1] dark:to-teal-500/[0.08]">
          <p className="flex flex-wrap items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-wide text-emerald-600 dark:text-emerald-300">
            <CatIcon name="message-square" className="h-3 w-3 shrink-0" />
            {t("siteInqReplyLabel")}
            {inquiry.replyUnread ? (
              <span className="inline-flex items-center gap-1 rounded-full border border-amber-300/60 bg-amber-500/10 px-1.5 py-0.5 text-[9px] font-extrabold normal-case tracking-normal text-amber-600 dark:border-amber-500/40 dark:text-amber-300">
                <CatIcon name="eye-off" className="h-[9px] w-[9px]" />
                {t("siteInqUnread")}
              </span>
            ) : null}
          </p>
          <p className="mt-1 whitespace-pre-line text-[12px] font-semibold leading-relaxed text-emerald-800 dark:text-emerald-200">
            {inquiry.reply}
          </p>
          <button
            type="button"
            onClick={() => setReplying(true)}
            className="mt-1.5 inline-flex h-7 items-center gap-1 rounded-lg px-1.5 text-[10.5px] font-extrabold text-emerald-600 transition hover:brightness-110 active:scale-95 dark:text-emerald-300"
          >
            <CatIcon name="pencil" className="h-3 w-3" />
            {t("siteInqReplyEdit")}
          </button>
        </div>
      ) : null}

      {/* the composer */}
      {replying ? (
        <div className="mt-2.5 rounded-xl border border-cyan-300/50 bg-cyan-500/[0.04] p-3 dark:border-cyan-500/30 dark:bg-cyan-500/[0.06]">
          <label className="flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-wide text-cyan-700 dark:text-cyan-300">
            <CatIcon name="send" className="h-3 w-3 shrink-0" />
            {t("siteInqReplyLabel")}
          </label>
          <textarea
            value={reply}
            onChange={(e) => setReply(e.target.value)}
            rows={4}
            maxLength={5000}
            dir="auto"
            placeholder={t("siteInqReplyPh")}
            className="mt-2 w-full resize-none rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-[12px] font-semibold leading-relaxed text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-cyan-400 focus:ring-4 focus:ring-cyan-500/10 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200 dark:placeholder:text-slate-500"
          />
          <div className="mt-2 grid grid-cols-2 gap-2">
            <label className="block">
              <span className="text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                {t("siteInqStatus")}
              </span>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value)}
                className="mt-1 h-9 w-full rounded-xl border border-slate-200 bg-white px-2 text-[11px] font-bold text-slate-600 outline-none transition focus:border-cyan-400 focus:ring-4 focus:ring-cyan-500/10 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
              >
                <option value="">{t("siteInqKeepStatus")} — {t(meta.label)}</option>
                {STATUS_OPTIONS.map((option) => (
                  <option key={option} value={option}>
                    {t(STATUS_META[option].label)}
                  </option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                {t("siteInqPriority")}
              </span>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
                className="mt-1 h-9 w-full rounded-xl border border-slate-200 bg-white px-2 text-[11px] font-bold text-slate-600 outline-none transition focus:border-cyan-400 focus:ring-4 focus:ring-cyan-500/10 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
              >
                <option value="">{t("siteInqKeepPrio")} — {prioKey ? t(prioKey) : "—"}</option>
                {PRIORITY_OPTIONS.map((option) => (
                  <option key={option} value={option}>
                    {t(PRIORITY_KEY[option])}
                  </option>
                ))}
              </select>
            </label>
          </div>
          <div className="mt-2.5 flex items-center justify-between gap-2">
            <span dir="ltr" className="text-[9.5px] font-bold tabular-nums text-slate-400 dark:text-slate-500">
              {fmtNum(reply.length, lang)} / ٥٬٠٠٠
            </span>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => {
                  setReplying(false);
                  setReply("");
                  setStatus("");
                  setPriority("");
                }}
                disabled={sendMutation.isPending}
                className="inline-flex h-9 items-center rounded-xl border border-slate-200 px-3 text-[10.5px] font-extrabold text-slate-500 transition hover:bg-slate-50 active:scale-95 disabled:opacity-50 dark:border-white/10 dark:text-slate-400 dark:hover:bg-white/[0.06]"
              >
                {t("dlgCancel")}
              </button>
              <button
                type="button"
                onClick={() => sendMutation.mutate()}
                disabled={sendMutation.isPending || (reply.trim().length < 2 && !status && !priority)}
                className="inline-flex h-9 items-center gap-1.5 rounded-xl px-4 text-[10.5px] font-extrabold text-white shadow-sm transition hover:brightness-110 active:scale-95 disabled:opacity-50"
                style={{ backgroundImage: grad("#10b981", "#059669") }}
              >
                <CatIcon
                  name={sendMutation.isPending ? "refresh-cw" : "send"}
                  className={cn("h-3.5 w-3.5", sendMutation.isPending && "animate-spin")}
                />
                {t(sendMutation.isPending ? "siteInqSaving" : "siteInqSend")}
              </button>
            </div>
          </div>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => setReplying(true)}
          className="mt-2.5 inline-flex h-9 w-full items-center justify-center gap-1.5 rounded-xl border border-dashed border-cyan-300/60 text-[11px] font-extrabold text-cyan-600 transition hover:border-solid hover:bg-cyan-500/[0.06] active:scale-[0.99] dark:border-cyan-500/40 dark:text-cyan-300 dark:hover:bg-cyan-500/[0.08]"
        >
          <CatIcon name="send" className="h-3.5 w-3.5" />
          {t(hasReply ? "siteInqReplyEdit" : "siteInqSend")}
        </button>
      )}

      {/* dates footer */}
      <div className="mt-2.5 flex items-center justify-between gap-3 border-t border-dashed border-slate-200 pt-2.5 text-[10px] font-bold text-slate-400 dark:border-white/10 dark:text-slate-500">
        <span className="flex items-center gap-1">
          <CatIcon name="calendar" className="h-3 w-3 shrink-0" />
          {t("siteInqPlaced")}: {fullDate(inquiry.createdAt, lang)}
        </span>
        {inquiry.updatedAt !== inquiry.createdAt ? (
          <span className="flex items-center gap-1">
            <CatIcon name="refresh-cw" className="h-3 w-3 shrink-0" />
            {t("siteInqUpdated")}
          </span>
        ) : null}
      </div>
    </li>
  );
}

/* ---------------- the dialog ---------------- */

export function SiteInquiriesDialog({
  open,
  onOpenChange,
  instanceId,
  customer,
  variant = "owner",
  orgName,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  instanceId: string;
  /** null → ALL of the workspace's public inquiries; set → that customer's.
   * Structural { id, name } — accepts both the owner's SiteCustomerDTO and
   * the Super Admin's SiteCustomerAdminDTO. */
  customer: { id: string; name: string } | null;
  /** ROUND 77 — "admin" mounts this on the Super Admin sites-customers
   * sheet (admin API surface + admin gradient + org-scoped title). */
  variant?: "owner" | "admin";
  /** org display name — the admin title reads «استفسارات موقع {org}». */
  orgName?: string;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();

  const queryKey = useMemo(
    () => ["instance-site-inquiries", instanceId, customer?.id ?? "all"] as const,
    [instanceId, customer?.id]
  );

  const query = useQuery({
    queryKey,
    queryFn: () =>
      variant === "admin"
        ? fetchAdminSiteInquiries(instanceId, customer?.id)
        : fetchInstanceSiteInquiries(instanceId, customer?.id),
    enabled: open,
    staleTime: 10_000,
    retry: 1,
  });

  /* a reply landing in the triage inbox also refreshes the customers list
   * (the per-customer inquiry counts + this dialog's own rows). ROUND 77:
   * the admin variant invalidates the ADMIN sheets' caches instead. */
  const refreshAll = () => {
    void queryClient.invalidateQueries({ queryKey: queryKey.slice(0, 2) });
    if (variant === "admin") {
      void queryClient.invalidateQueries({ queryKey: ["site-customers", instanceId] });
      void queryClient.invalidateQueries({ queryKey: ["admin-sites"] });
    } else {
      void queryClient.invalidateQueries({ queryKey: ["instance-site-customers", instanceId] });
    }
  };

  const inquiries = query.data ?? [];
  const openCount = inquiries.filter((i) => i.status === "open" || i.status === "pending").length;
  const repliedCount = inquiries.filter((i) => i.reply != null && i.reply.trim().length > 0).length;

  /* ROUND 77 — the admin console's violet identity (mirrors the Super
   * Admin views) vs the workspace cyan — one glance tells the console. */
  const isAdmin = variant === "admin";
  const H1 = isAdmin ? "#8b5cf6" : C1;
  const H2 = isAdmin ? "#d946ef" : C2;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[88vh] gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-2xl">
        {/* gradient header */}
        <div
          className="relative shrink-0 overflow-hidden px-5 pb-4 pt-5 sm:px-6"
          style={{ backgroundImage: grad(H1, H2, 135) }}
        >
          <span
            className="pointer-events-none absolute -top-10 end-6 h-28 w-28 rounded-full bg-white/15 blur-2xl"
            aria-hidden="true"
          />
          <DialogHeader className="space-y-1.5">
            <DialogTitle className="flex items-center gap-2.5 text-start text-[15px] font-black leading-relaxed text-white">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-2xl bg-white/20 backdrop-blur">
                <CatIcon name="message-square" className="h-4 w-4" />
              </span>
              <span className="min-w-0">
                {isAdmin && !customer && orgName
                  ? t("siteInqAdminTitle", { org: orgName })
                  : customer
                    ? t("siteInqTitleFor", { name: customer.name })
                    : t("siteInqTitle")}
              </span>
            </DialogTitle>
            <DialogDescription className="truncate text-[10.5px] font-bold text-white/80">
              {t("siteInqDesc")}
            </DialogDescription>
          </DialogHeader>
          {/* count chips */}
          <div className="mt-3 flex flex-wrap items-center gap-1.5">
            <span className="inline-flex items-center gap-1 rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-extrabold text-white backdrop-blur">
              <CatIcon name="inbox" className="h-3 w-3" />
              {fmtNum(inquiries.length, lang)}
            </span>
            <span className="inline-flex items-center gap-1 rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-extrabold text-white backdrop-blur">
              <CatIcon name="clock" className="h-3 w-3" />
              {t("siteInqOpenCount")}: {fmtNum(openCount, lang)}
            </span>
            <span className="inline-flex items-center gap-1 rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-extrabold text-white backdrop-blur">
              <CatIcon name="check" className="h-3 w-3" />
              {t("siteInqRepliedCount")}: {fmtNum(repliedCount, lang)}
            </span>
          </div>
        </div>

        {/* body */}
        <div className="min-h-0 flex-1 overflow-y-auto px-4 py-4 sm:px-5">
          {query.isPending ? (
            <div className="space-y-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-44 rounded-2xl" />
              ))}
            </div>
          ) : query.isError ? (
            <div className="rounded-2xl border border-rose-300/60 bg-rose-500/10 p-5 text-center dark:border-rose-500/30">
              <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-rose-500/15 text-rose-500">
                <CatIcon name="circle-x" className="h-5 w-5" />
              </div>
              <p className="mt-3 text-[12.5px] font-bold leading-relaxed text-rose-600 dark:text-rose-300">
                {query.error instanceof ApiError ? query.error.message : t("errorText")}
              </p>
              <button
                type="button"
                onClick={() => void query.refetch()}
                className="mt-4 inline-flex h-10 items-center gap-1.5 rounded-xl border border-rose-300 bg-white px-4 text-[11.5px] font-extrabold text-rose-600 transition hover:bg-rose-50 active:scale-95 dark:border-rose-500/40 dark:bg-transparent dark:text-rose-300 dark:hover:bg-rose-500/10"
              >
                <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
                {t("errTryAgain")}
              </button>
            </div>
          ) : inquiries.length === 0 ? (
            <div className="flex flex-col items-center px-6 py-10 text-center">
              <div
                className="grid h-16 w-16 place-items-center rounded-3xl text-white"
                style={{ backgroundImage: grad(C1, C2) }}
              >
                <CatIcon name="inbox" className="h-7 w-7" />
              </div>
              <p className="mt-4 text-[13px] font-extrabold text-slate-700 dark:text-slate-200">
                {t("siteInqEmpty")}
              </p>
              <p className="mt-1 max-w-xs text-[11.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                {t("siteInqEmptyDesc")}
              </p>
            </div>
          ) : (
            <ul className="space-y-3">
              {inquiries.map((inquiry, index) => (
                <TriageCard
                  key={inquiry.id}
                  inquiry={inquiry}
                  index={index}
                  instanceId={instanceId}
                  variant={variant}
                  onReplied={refreshAll}
                />
              ))}
            </ul>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
