"use client";

import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import type { InstanceDTO, SiteProductDTO } from "@/lib/types";
import { useT } from "@/lib/i18n";
import { fetchInstanceStoreStatus } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { DashCard } from "@/components/dashboard/dash-shared";
import { nf } from "./shared";
import { ProductMediaDialog, ProductMediaRow } from "./photos-panel";
import { ProductSaleDialog } from "./sale-dialog";

/** ROUND 140 — the products + media console card (the owner's directive:
 *  6 photos ≤8 MB + 2 videos ≤10 MB per product + the storefront
 *  visibility checkmark — all managed from here, across all 102 systems). */
export function ProductsPanel({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<SiteProductDTO | null>(null);
  const [saleEditing, setSaleEditing] = useState<SiteProductDTO | null>(null);

  /* shares the StoreView query (react-query dedupes by key) */
  const storeQuery = useQuery({
    queryKey: ["instance-store", instance.id],
    queryFn: () => fetchInstanceStoreStatus(instance.id),
    staleTime: 30_000,
    retry: 0,
  });

  const products = useMemo(() => storeQuery.data?.products ?? [], [storeQuery.data]);
  const currency = storeQuery.data?.currency ?? "SAR";
  const withPhoto = products.filter((p) => (p.gallery?.length ?? 0) > 0).length;
  const withVideo = products.filter((p) => (p.videos?.length ?? 0) > 0).length;
  const hiddenCount = products.filter((p) => !p.storeVisible).length;
  const featuredCount = products.filter((p) => p.featured).length;
  const saleCount = products.filter((p) => p.salePrice != null).length;

  const q = search.trim().toLowerCase();
  const filtered = q
    ? products.filter(
        (p) => p.name.toLowerCase().includes(q) || p.category.toLowerCase().includes(q)
      )
    : products;

  return (
    <DashCard title={t("estoreProductsTitle")} icon="image">
      <div className="space-y-3">
        {/* coverage chips + search */}
        <div className="flex flex-col gap-2.5 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-wrap items-center gap-1.5">
            <Badge variant="outline" className="gap-1.5 self-start rounded-full px-3 py-1 text-[11px] font-extrabold">
              <CatIcon name="image" className="h-3 w-3 text-brand-500" />
              {t("estoreProductsCoverage", { n: nf(lang, withPhoto), total: nf(lang, products.length) })}
            </Badge>
            {withVideo > 0 ? (
              <Badge variant="outline" className="gap-1.5 self-start rounded-full border-sky-300/70 bg-sky-500/10 px-3 py-1 text-[11px] font-extrabold text-sky-600 dark:border-sky-500/40 dark:text-sky-300">
                <CatIcon name="film" className="h-3 w-3" />
                {t("estoreMediaVideosChip", { n: nf(lang, withVideo) })}
              </Badge>
            ) : null}
            {hiddenCount > 0 ? (
              <Badge variant="outline" className="gap-1.5 self-start rounded-full border-slate-300/70 bg-slate-500/10 px-3 py-1 text-[11px] font-extrabold text-slate-500 dark:border-white/10 dark:text-slate-400">
                <CatIcon name="eye-off" className="h-3 w-3" />
                {t("estoreHiddenBadge")}
              </Badge>
            ) : null}
            {featuredCount > 0 ? (
              <Badge variant="outline" className="gap-1.5 self-start rounded-full border-amber-300/70 bg-amber-500/10 px-3 py-1 text-[11px] font-extrabold text-amber-600 dark:border-amber-500/40 dark:text-amber-300">
                <CatIcon name="star" className="h-3 w-3 fill-current" />
                {nf(lang, featuredCount)}
              </Badge>
            ) : null}
            {saleCount > 0 ? (
              <Badge variant="outline" className="gap-1.5 self-start rounded-full border-rose-300/70 bg-rose-500/10 px-3 py-1 text-[11px] font-extrabold text-rose-600 dark:border-rose-500/40 dark:text-rose-300">
                <CatIcon name="percent" className="h-3 w-3" />
                {nf(lang, saleCount)}
              </Badge>
            ) : null}
          </div>
          <div className="relative w-full sm:max-w-64">
            <CatIcon
              name="search"
              className="pointer-events-none absolute start-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400"
            />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t("estoreProductsSearchPh")}
              aria-label={t("estoreProductsSearchPh")}
              maxLength={80}
              className="h-10 w-full rounded-xl border border-slate-200 bg-white ps-9 pe-3 text-[12px] font-semibold text-slate-800 outline-none transition placeholder:font-normal placeholder:text-slate-400 focus:border-brand-400 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100"
            />
          </div>
        </div>

        {/* product rows */}
        {storeQuery.isPending ? (
          <div className="grid gap-2 sm:grid-cols-2">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-[76px] rounded-2xl" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="rounded-2xl border-2 border-dashed border-slate-200 p-6 text-center dark:border-white/10">
            <p className="text-[12.5px] font-bold text-slate-500 dark:text-slate-400">
              {t("estoreProductsEmpty")}
            </p>
          </div>
        ) : (
          <div className="max-h-96 space-y-2 overflow-y-auto pe-1 [contain:content] [scrollbar-width:thin]">
            {filtered.map((product) => (
              <ProductMediaRow
                key={product.recordId}
                instance={instance}
                product={product}
                currency={currency}
                onEdit={setEditing}
                onSale={setSaleEditing}
              />
            ))}
          </div>
        )}

        <p className="text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
          {t("estoreProductsDesc")}
        </p>
      </div>

      <ProductMediaDialog
        open={editing !== null}
        product={editing}
        instance={instance}
        onClose={() => setEditing(null)}
      />

      <ProductSaleDialog
        open={saleEditing !== null}
        product={saleEditing}
        instance={instance}
        onClose={() => setSaleEditing(null)}
      />
    </DashCard>
  );
}
