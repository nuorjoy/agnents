"use client";

import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import type { InstanceDTO, SiteProductDTO } from "@/lib/types";
import { useT } from "@/lib/i18n";
import { updateModuleRecord } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PremiumDateInput } from "@/components/ui/premium-date-input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { nf, fmtOrderPrice } from "./shared";

/** ROUND 52 — sale-price editor dialog (display units in, minor units out). */
export function ProductSaleDialog({
  open,
  product,
  instance,
  onClose,
}: {
  open: boolean;
  product: SiteProductDTO | null;
  instance: InstanceDTO;
  onClose: () => void;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const [value, setValue] = useState("");
  const [endsAt, setEndsAt] = useState("");
  const [error, setError] = useState<string | null>(null);

  const close = () => {
    setValue("");
    setEndsAt("");
    setError(null);
    onClose();
  };

  /* ROUND 53 — the date input holds yyyy-mm-dd; the payload needs a full
   * UTC ISO timestamp. An empty field = open-ended sale (null). */
  const endIso = endsAt ? `${endsAt}T23:59:59.000Z` : null;
  const todayStr = new Date().toISOString().slice(0, 10);
  const maxStr = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);

  const save = useMutation({
    mutationFn: (payload: { salePrice: number | null; saleEndsAt?: string | null }) =>
      updateModuleRecord(instance.id, product!.recordId, payload),
    onSuccess: (_row, payload) => {
      toast.success(t(payload.salePrice === null ? "estoreSaleRemoved" : "estoreSaleSaved"));
      queryClient.invalidateQueries({ queryKey: ["instance-store", instance.id] });
      close();
    },
    onError: (e: Error) => {
      const code = (e as Error & { code?: string }).code;
      toast.error(
        code === "SALE_ABOVE_REGULAR"
          ? t("estoreSaleErr")
          : code === "SALE_END_OUT_OF_RANGE"
            ? t("estoreSaleEndErr")
            : e.message || t("errorText")
      );
    },
  });

  const submit = () => {
    if (!product) return;
    const raw = value.trim();
    if (!raw) return;
    const n = Number(raw);
    if (!Number.isFinite(n) || n <= 0 || n >= product.price) {
      setError(t("estoreSaleErr"));
      return;
    }
    save.mutate({ salePrice: Math.round(n * 100), saleEndsAt: endIso });
  };

  return (
    <Dialog open={open} onOpenChange={(next) => (next ? undefined : close())}>
      <DialogContent className="max-w-sm gap-0 rounded-3xl border-slate-200/90 bg-white p-6 dark:border-white/10 dark:bg-[#101319]">
        <DialogHeader className="text-start">
          <DialogTitle className="flex items-center gap-2 font-display text-[16px] font-extrabold">
            <span
              className="grid h-9 w-9 place-items-center rounded-xl text-white shadow-md"
              style={{ backgroundImage: "linear-gradient(135deg, #f43f5e, #f97316)" }}
            >
              <CatIcon name="percent" className="h-4.5 w-4.5" />
            </span>
            {t("estoreSaleTitle")}
          </DialogTitle>
          <DialogDescription className="pe-8 text-[12px] leading-relaxed">
            {product ? `${product.name} — ` : ""}
            {t("estoreSaleDesc")}
          </DialogDescription>
        </DialogHeader>

        <div className="mt-4 space-y-3">
          {/* the current regular price for context */}
          {product ? (
            <div className="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50/80 px-3.5 py-2.5 dark:border-white/10 dark:bg-white/[0.03]">
              <span className="text-[12px] font-bold text-slate-500 dark:text-slate-400">
                {t("estoreSaleCurrent", { price: fmtOrderPrice(lang, product.price, "") })}
              </span>
              {product.salePrice != null ? (
                <span dir="ltr" className="rounded-full bg-rose-500/10 px-2.5 py-0.5 text-[11px] font-extrabold text-rose-600 dark:text-rose-300">
                  {fmtOrderPrice(lang, product.salePrice, "")}
                </span>
              ) : null}
            </div>
          ) : null}

          <div className="space-y-1.5">
            <Label htmlFor="sale-price-input" className="text-[12px] font-bold">
              {t("estoreSaleLabel")}
            </Label>
            <Input
              id="sale-price-input"
              type="number"
              min={0.01}
              step={0.5}
              dir="ltr"
              value={value}
              onChange={(e) => {
                setValue(e.target.value);
                setError(null);
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter") submit();
              }}
              placeholder={t("estoreSalePh")}
              aria-invalid={error ? true : undefined}
              className="h-11 rounded-xl text-start font-display text-[15px] font-extrabold"
            />
            {error ? (
              <p role="alert" className="text-[11px] font-bold text-rose-600 dark:text-rose-300">
                {error}
              </p>
            ) : null}
          </div>

          {/* ROUND 53 — optional window-bound sale end date */}
          <div className="space-y-1.5">
            <Label htmlFor="sale-end-input" className="text-[12px] font-bold">
              {t("estoreSaleEndLabel")}
            </Label>
            {/* R163 — the shared premium date field (the sale dialog's
                h-11 rhythm): brand calendar tile at the field's far right in
                Arabic, clear-X + Arabic long-form hint built in. */}
            <PremiumDateInput
              id="sale-end-input"
              size="lg"
              min={todayStr}
              max={maxStr}
              value={endsAt}
              onChange={(e) => {
                setEndsAt(e.target.value);
                setError(null);
              }}
            />
            <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
              {[3, 7, 30].map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() =>
                    setEndsAt(
                      new Date(Date.now() + d * 24 * 60 * 60 * 1000).toISOString().slice(0, 10)
                    )
                  }
                  className={cn(
                    "rounded-full border px-2.5 py-1 text-[10.5px] font-extrabold transition active:scale-95",
                    endsAt === new Date(Date.now() + d * 24 * 60 * 60 * 1000).toISOString().slice(0, 10)
                      ? "border-rose-300 bg-rose-500/15 text-rose-600 dark:border-rose-500/40 dark:text-rose-300"
                      : "border-slate-200 text-slate-500 hover:border-rose-300 hover:text-rose-500 dark:border-white/10 dark:text-slate-400 dark:hover:border-rose-500/40"
                  )}
                >
                  +{nf(lang, d)} {d <= 7 ? t("estoreSaleEndDays") : t("estoreSaleEndDayWord")}
                </button>
              ))}
              {endsAt ? (
                <button
                  type="button"
                  onClick={() => setEndsAt("")}
                  className="rounded-full border border-slate-200 px-2.5 py-1 text-[10.5px] font-extrabold text-slate-500 transition hover:border-slate-300 hover:text-slate-700 active:scale-95 dark:border-white/10 dark:text-slate-400 dark:hover:text-slate-200"
                >
                  {t("estoreSaleEndOpen")}
                </button>
              ) : null}
            </div>
            <p className="text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {t("estoreSaleEndHint")}
            </p>
          </div>
        </div>

        <DialogFooter className="mt-5 gap-2">
          {product?.salePrice != null ? (
            <Button
              type="button"
              variant="outline"
              disabled={save.isPending}
              onClick={() => save.mutate({ salePrice: null, saleEndsAt: null })}
              className="h-10 gap-1.5 rounded-xl px-4 text-[12px] font-bold text-rose-600 hover:bg-rose-500/10 hover:text-rose-700 dark:text-rose-300"
            >
              <CatIcon name="x" className="h-3.5 w-3.5" />
              {t("estoreSaleClear")}
            </Button>
          ) : null}
          <div className="flex-1" />
          <Button type="button" variant="outline" onClick={close} className="h-10 rounded-xl px-4 text-[12px] font-bold">
            {t("dlgCancel")}
          </Button>
          <Button
            type="button"
            disabled={!value.trim() || save.isPending}
            onClick={submit}
            className="h-10 gap-1.5 rounded-xl px-5 text-[12px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:opacity-50"
            style={{
              backgroundImage: "linear-gradient(135deg, #f43f5e, #f97316)",
              boxShadow: "0 10px 22px -10px rgba(244, 63, 94, 0.65)",
            }}
          >
            {t("estoreSaleSet")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
