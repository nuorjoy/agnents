"use client";

import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import type { InstanceDTO, StoreCouponDTO } from "@/lib/types";
import { useT, type I18nKey } from "@/lib/i18n";
import {
  createInstanceCoupon,
  deleteInstanceCoupon,
  fetchInstanceCoupons,
  updateInstanceCoupon,
} from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, grad } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PremiumDateInput } from "@/components/ui/premium-date-input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { DashCard, fullDate } from "@/components/dashboard/dash-shared";
import { nf } from "./shared";

/* --------------------------------------------- coupons (ROUND 50) ----- */

/** lifecycle badge styling per derived state */
const COUPON_STATE_META: Record<StoreCouponDTO["state"], { icon: string; chip: string }> = {
  live: {
    icon: "circle-check",
    chip: "border-emerald-300/60 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300",
  },
  scheduled: {
    icon: "clock",
    chip: "border-sky-300/60 bg-sky-500/10 text-sky-600 dark:border-sky-500/40 dark:text-sky-300",
  },
  expired: {
    icon: "history",
    chip: "border-slate-300/60 bg-slate-500/10 text-slate-500 dark:border-white/10 dark:text-slate-400",
  },
  exhausted: {
    icon: "circle-x",
    chip: "border-amber-300/60 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300",
  },
  disabled: {
    icon: "power",
    chip: "border-slate-300/60 bg-slate-500/10 text-slate-500 dark:border-white/10 dark:text-slate-400",
  },
};

const COUPON_STATE_KEY: Record<StoreCouponDTO["state"], I18nKey> = {
  live: "couponStateLive",
  scheduled: "couponStateScheduled",
  expired: "couponStateExpired",
  exhausted: "couponStateExhausted",
  disabled: "couponStateDisabled",
};

/** random code for the "generate" button (same alphabet as the server). */
function randomCouponCode(): string {
  const alphabet = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
  const bytes = new Uint32Array(8);
  crypto.getRandomValues(bytes);
  let out = "";
  for (let i = 0; i < 8; i++) out += alphabet[bytes[i]! % alphabet.length];
  return out;
}

/** one coupon row — code, state, value, usage, window, actions. */
function CouponRow({
  coupon,
  currency,
  busy,
  onToggle,
  onDelete,
}: {
  coupon: StoreCouponDTO;
  currency: string;
  busy: boolean;
  onToggle: (c: StoreCouponDTO) => void;
  onDelete: (c: StoreCouponDTO) => void;
}) {
  const { t, lang } = useT();
  const meta = COUPON_STATE_META[coupon.state];

  return (
    <li
      className={cn(
        "rounded-2xl border border-slate-200 bg-white p-3.5 transition dark:border-white/10 dark:bg-white/[0.03]",
        coupon.state === "live" && "border-emerald-300/50 dark:border-emerald-500/30"
      )}
    >
      <div className="flex flex-wrap items-center gap-2.5">
        {/* code + state */}
        <code
          dir="ltr"
          className="rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-[13px] font-black tracking-wider text-slate-800 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-100"
        >
          {coupon.code}
        </code>
        <span
          className={cn(
            "inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[10px] font-extrabold",
            meta.chip
          )}
        >
          <CatIcon name={meta.icon} className="h-3 w-3" />
          {t(COUPON_STATE_KEY[coupon.state])}
        </span>

        <span className="ms-auto flex items-center gap-1.5">
          {/* actions: toggle + delete */}
          <button
            type="button"
            disabled={busy}
            onClick={() => onToggle(coupon)}
            title={coupon.active ? t("couponToggleOn") : t("couponToggleOff")}
            aria-label={coupon.active ? t("couponToggleOn") : t("couponToggleOff")}
            className={cn(
              "grid h-9 w-9 place-items-center rounded-xl border transition active:scale-95 disabled:opacity-50",
              coupon.active
                ? "border-emerald-300/60 bg-emerald-500/10 text-emerald-600 hover:bg-emerald-500/20 dark:border-emerald-500/40 dark:text-emerald-300"
                : "border-slate-200 bg-slate-50 text-slate-400 hover:text-emerald-600 dark:border-white/10 dark:bg-white/[0.04] dark:hover:text-emerald-300"
            )}
          >
            <CatIcon name="power" className="h-4 w-4" />
          </button>
          <button
            type="button"
            disabled={busy}
            onClick={() => onDelete(coupon)}
            title={t("couponDeleteBtn")}
            aria-label={t("couponDeleteBtn")}
            className="grid h-9 w-9 place-items-center rounded-xl border border-slate-200 text-slate-400 transition hover:border-rose-300 hover:text-rose-500 active:scale-95 disabled:opacity-50 dark:border-white/10 dark:hover:border-rose-500/40 dark:hover:text-rose-300"
          >
            <CatIcon name="trash-2" className="h-4 w-4" />
          </button>
        </span>
      </div>

      {/* value + usage + window rail */}
      <div className="mt-2.5 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[11px] font-bold text-slate-500 dark:text-slate-400">
        <span className="inline-flex items-center gap-1.5">
          <CatIcon name="ticket-percent" className="h-3.5 w-3.5 text-brand-500" />
          {coupon.kind === "percent"
            ? t("storeCouponPercentOff", { n: nf(lang, coupon.value) })
            : `${nf(lang, coupon.value / 100)} ${currency}`}
        </span>
        <span className="inline-flex items-center gap-1.5">
          <CatIcon name="repeat" className="h-3.5 w-3.5 text-slate-400" />
          {coupon.maxUses != null
            ? t("couponUsesCapped", { used: nf(lang, coupon.usedCount), max: nf(lang, coupon.maxUses) })
            : t("couponUsesOpen", { used: nf(lang, coupon.usedCount) })}
        </span>
        {coupon.minSubtotal != null ? (
          <span className="inline-flex items-center gap-1.5">
            <CatIcon name="banknote" className="h-3.5 w-3.5 text-slate-400" />
            {t("couponMinNote", { n: `${nf(lang, coupon.minSubtotal / 100)} ${currency}` })}
          </span>
        ) : null}
        <span className="inline-flex items-center gap-1.5">
          <CatIcon name="timer" className="h-3.5 w-3.5 text-slate-400" />
          {coupon.expiresAt ? fullDate(coupon.expiresAt, lang) : t("couponForever")}
        </span>
      </div>
    </li>
  );
}

/** ROUND 50 — the owner's coupon console: list + create dialog + actions. */
export function CouponsPanel({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const [createOpen, setCreateOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<StoreCouponDTO | null>(null);

  /* create-dialog form state */
  const [code, setCode] = useState("");
  const [kind, setKind] = useState<"percent" | "fixed">("percent");
  const [value, setValue] = useState("");
  const [minSubtotal, setMinSubtotal] = useState("");
  const [maxUses, setMaxUses] = useState("");
  const [expiresAt, setExpiresAt] = useState("");

  const couponsQuery = useQuery({
    queryKey: ["instance-coupons", instance.id],
    queryFn: () => fetchInstanceCoupons(instance.id),
    staleTime: 30_000,
    retry: 0,
  });

  const invalidate = () =>
    queryClient.invalidateQueries({ queryKey: ["instance-coupons", instance.id] });

  const create = useMutation({
    mutationFn: () =>
      createInstanceCoupon(instance.id, {
        code: code.trim().toUpperCase(),
        kind,
        value:
          kind === "percent"
            ? Math.round(Number(value) || 0)
            : Math.round((Number(value) || 0) * 100),
        ...(minSubtotal.trim() ? { minSubtotal: Math.round((Number(minSubtotal) || 0) * 100) } : {}),
        ...(maxUses.trim() ? { maxUses: Math.round(Number(maxUses) || 0) } : {}),
        ...(expiresAt ? { expiresAt: new Date(`${expiresAt}T23:59:59`).toISOString() } : {}),
      }),
    onSuccess: () => {
      invalidate();
      setCreateOpen(false);
      toast.success(t("couponCreateBtn"));
      setCode("");
      setValue("");
      setMinSubtotal("");
      setMaxUses("");
      setExpiresAt("");
    },
    onError: (e: Error) => toast.error(e.message || t("errorText")),
  });

  const toggle = useMutation({
    mutationFn: (c: StoreCouponDTO) => updateInstanceCoupon(instance.id, c.id, { active: !c.active }),
    onSuccess: invalidate,
    onError: (e: Error) => toast.error(e.message || t("errorText")),
  });

  const remove = useMutation({
    mutationFn: (c: StoreCouponDTO) => deleteInstanceCoupon(instance.id, c.id),
    onSuccess: () => {
      invalidate();
      setDeleteTarget(null);
      toast.success(t("couponDeleteBtn"));
    },
    onError: (e: Error) => toast.error(e.message || t("errorText")),
  });

  const coupons = couponsQuery.data?.coupons ?? [];
  const busy = create.isPending || toggle.isPending || remove.isPending;

  const submitCreate = () => {
    const v = Number(value);
    if (code.trim().length < 3) return;
    if (kind === "percent" ? !(v >= 1 && v <= 99) : !(v > 0)) return;
    create.mutate();
  };

  return (
    <DashCard title={t("estoreCouponsTitle")} icon="ticket-percent">
      <div className="space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <p className="max-w-xl text-[11.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("estoreCouponsDesc")}
          </p>
          <Button
            type="button"
            onClick={() => setCreateOpen(true)}
            className="h-9 shrink-0 gap-1.5 rounded-xl px-4 text-[12px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.98]"
            style={{
              backgroundImage: grad("#8b5cf6", "#ec4899"),
              boxShadow: "0 10px 22px -10px rgba(139, 92, 246, 0.75)",
            }}
          >
            <CatIcon name="plus" className="h-3.5 w-3.5" />
            {t("couponNewBtn")}
          </Button>
        </div>

        {couponsQuery.isPending ? (
          <div className="space-y-2.5">
            {Array.from({ length: 2 }).map((_, i) => (
              <Skeleton key={i} className="h-20 w-full rounded-2xl" />
            ))}
          </div>
        ) : coupons.length === 0 ? (
          <div className="rounded-2xl border-2 border-dashed border-slate-200 p-8 text-center dark:border-white/10">
            <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-violet-500/10 text-violet-500">
              <CatIcon name="ticket-percent" className="h-6 w-6" />
            </div>
            <h4 className="mt-3 font-display text-[14px] font-extrabold text-slate-900 dark:text-white">
              {t("couponEmptyTitle")}
            </h4>
            <p className="mx-auto mt-1 max-w-sm text-[12px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("couponEmptyDesc")}
            </p>
          </div>
        ) : (
          <ul className="space-y-2.5">
            {coupons.map((coupon) => (
              <CouponRow
                key={coupon.id}
                coupon={coupon}
                currency={instance.org?.currency || "SAR"}
                busy={busy}
                onToggle={(c) => toggle.mutate(c)}
                onDelete={(c) => setDeleteTarget(c)}
              />
            ))}
          </ul>
        )}
      </div>

      {/* ---------------------------- create dialog --------------------- */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-10 w-10 place-items-center rounded-2xl text-white shadow-lg"
                style={{ backgroundImage: grad("#8b5cf6", "#ec4899") }}
              >
                <CatIcon name="ticket-percent" className="h-5 w-5" />
              </span>
              {t("couponNewBtn")}
            </DialogTitle>
            <DialogDescription className="text-[12.5px] leading-relaxed">
              {t("estoreCouponsDesc")}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* code + generate */}
            <div className="space-y-1.5">
              <Label htmlFor="coupon-code" className="text-[12px] font-bold">
                {t("couponCodeLabel")}
              </Label>
              <div className="flex items-center gap-2">
                <Input
                  id="coupon-code"
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ""))}
                  placeholder={t("couponCodePh")}
                  maxLength={24}
                  dir="ltr"
                  className="h-11 rounded-xl text-start font-mono text-[13px] font-bold tracking-wider"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setCode(randomCouponCode())}
                  title={t("couponGenerate")}
                  className="h-11 shrink-0 gap-1.5 rounded-xl px-3.5 text-[12px] font-extrabold"
                >
                  <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">{t("couponGenerate")}</span>
                </Button>
              </div>
            </div>

            {/* kind segmented control */}
            <div className="space-y-1.5">
              <Label className="text-[12px] font-bold">{t("couponKindLabel")}</Label>
              <div className="grid grid-cols-2 gap-2">
                {(["percent", "fixed"] as const).map((k) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => {
                      setKind(k);
                      setValue("");
                    }}
                    aria-pressed={kind === k}
                    className={cn(
                      "h-11 rounded-xl border-2 text-[12.5px] font-extrabold transition active:scale-[0.98]",
                      kind === k
                        ? "border-violet-400 bg-violet-500/10 text-violet-600 dark:border-violet-500/60 dark:text-violet-300"
                        : "border-slate-200 bg-white text-slate-500 hover:border-slate-300 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-400"
                    )}
                  >
                    {t(k === "percent" ? "couponKindPercent" : "couponKindFixed")}
                  </button>
                ))}
              </div>
            </div>

            {/* value */}
            <div className="space-y-1.5">
              <Label htmlFor="coupon-value" className="text-[12px] font-bold">
                {t("couponValueLabel")}
                {kind === "fixed" ? ` (${instance.org?.currency || "SAR"})` : " (%)"}
              </Label>
              <Input
                id="coupon-value"
                type="number"
                min={1}
                max={kind === "percent" ? 99 : undefined}
                step={kind === "percent" ? 1 : 0.5}
                value={value}
                onChange={(e) => setValue(e.target.value)}
                placeholder={t(kind === "percent" ? "couponValuePercentPh" : "couponValueFixedPh")}
                dir="ltr"
                className="h-11 rounded-xl text-start"
              />
            </div>

            {/* min subtotal + max uses (two-up) */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="coupon-min" className="text-[11.5px] font-bold">
                  {t("couponMinSubtotalLabel")}
                </Label>
                <Input
                  id="coupon-min"
                  type="number"
                  min={0}
                  step={0.5}
                  value={minSubtotal}
                  onChange={(e) => setMinSubtotal(e.target.value)}
                  dir="ltr"
                  className="h-11 rounded-xl text-start"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="coupon-max" className="text-[11.5px] font-bold">
                  {t("couponMaxUsesLabel")}
                </Label>
                <Input
                  id="coupon-max"
                  type="number"
                  min={1}
                  step={1}
                  value={maxUses}
                  onChange={(e) => setMaxUses(e.target.value)}
                  placeholder={t("couponMaxUsesPh")}
                  dir="ltr"
                  className="h-11 rounded-xl text-start"
                />
              </div>
            </div>

            {/* expiry */}
            <div className="space-y-1.5">
              <Label htmlFor="coupon-exp" className="text-[12px] font-bold">
                {t("couponExpiresLabel")}
              </Label>
              {/* R163 — the shared premium date field (the coupon form's
                  h-11 rhythm): brand calendar tile at the field's far right
                  in Arabic, clear-X + Arabic long-form hint built in. */}
              <PremiumDateInput
                id="coupon-exp"
                size="lg"
                value={expiresAt}
                onChange={(e) => setExpiresAt(e.target.value)}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)} className="h-10 rounded-xl px-5 text-[12.5px] font-bold">
              {t("dlgCancel")}
            </Button>
            <Button
              type="button"
              onClick={submitCreate}
              disabled={create.isPending || code.trim().length < 3 || !value}
              className="h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.98]"
              style={{
                backgroundImage: grad("#8b5cf6", "#ec4899"),
                boxShadow: "0 10px 22px -10px rgba(139, 92, 246, 0.75)",
              }}
            >
              {create.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="check" className="h-4 w-4" />
              )}
              {create.isPending ? t("couponCreating") : t("couponCreateBtn")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ---------------------------- delete confirm -------------------- */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span className="grid h-10 w-10 place-items-center rounded-2xl bg-rose-500/10 text-rose-500">
                <CatIcon name="trash-2" className="h-5 w-5" />
              </span>
              {t("couponDeleteTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[12.5px] leading-relaxed">
              {t("couponDeleteDesc")}
              {deleteTarget ? (
                <span dir="ltr" className="mt-2 block font-mono text-[12px] font-black tracking-wider text-rose-500">
                  {deleteTarget.code}
                </span>
              ) : null}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold">
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteTarget && remove.mutate(deleteTarget)}
              disabled={remove.isPending}
              className="h-10 gap-2 rounded-xl bg-rose-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/30 transition hover:bg-rose-600"
            >
              {remove.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="trash-2" className="h-4 w-4" />
              )}
              {t("couponDeleteBtn")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashCard>
  );
}
