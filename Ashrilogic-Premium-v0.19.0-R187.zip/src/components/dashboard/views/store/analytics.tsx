"use client";

import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import type { InstanceDTO, SiteProductDTO } from "@/lib/types";
import { useT } from "@/lib/i18n";
import { intlLocale } from "@/lib/locales";
import { fetchInstanceOrders, fetchInstanceStoreStatus } from "@/lib/api-client";
import { aggregateDailySales, aggregateTopProducts, countedRevenue, salesMomentum } from "@/lib/store-analytics";
import type { DailySalesBucket } from "@/lib/store-analytics";
import { CatIcon } from "@/components/icon";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import { DashCard } from "@/components/dashboard/dash-shared";
import { nf, fmtOrderPrice } from "./shared";

/* ------------------------------------------------------------------ */
/* ROUND 53 — best-sellers analytics (client-side, zero new API)       */
/* ------------------------------------------------------------------ */

/** Rank medal chips — gold / silver / bronze gradients, neutral 4+. */
const RANK_STYLES: Array<{ chip: string; bar: string }> = [
  {
    chip: "bg-gradient-to-l from-amber-400 to-orange-500 text-white shadow-md shadow-amber-500/30",
    bar: "from-amber-400 to-orange-500",
  },
  {
    chip: "bg-gradient-to-l from-slate-300 to-slate-400 text-white shadow-md shadow-slate-400/30",
    bar: "from-slate-300 to-slate-400",
  },
  {
    chip: "bg-gradient-to-l from-orange-300 to-amber-600 text-white shadow-md shadow-orange-400/30",
    bar: "from-orange-300 to-amber-600",
  },
  {
    chip: "bg-slate-100 text-slate-500 dark:bg-white/10 dark:text-slate-300",
    bar: "from-brand-400 to-sky-400",
  },
  {
    chip: "bg-slate-100 text-slate-500 dark:bg-white/10 dark:text-slate-300",
    bar: "from-brand-400 to-sky-400",
  },
];

/**
 * ROUND 53 — the best-sellers card. Aggregates the SAME cached order feed
 * the queue renders (["instance-orders", id]) with pure helpers from
 * @/lib/store-analytics: ranked products by units sold, a 7-day momentum
 * chip and the counted revenue footer. Product rows reuse the owner
 * catalog's managed photos for instant recognition.
 */
export function TopProductsPanel({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();

  /* shares both StoreView queries (react-query key-level dedupe) */
  const storeQuery = useQuery({
    queryKey: ["instance-store", instance.id],
    queryFn: () => fetchInstanceStoreStatus(instance.id),
    staleTime: 30_000,
    retry: 0,
  });
  const ordersQuery = useQuery({
    queryKey: ["instance-orders", instance.id],
    queryFn: () => fetchInstanceOrders(instance.id, { limit: 200 }),
    staleTime: 15_000,
    retry: 0,
  });

  const currency = storeQuery.data?.currency ?? "SAR";
  const products = useMemo(() => storeQuery.data?.products ?? [], [storeQuery.data]);
  const orders = useMemo(() => ordersQuery.data?.orders ?? [], [ordersQuery.data]);

  const top = useMemo(() => aggregateTopProducts(orders, 5), [orders]);
  const momentum = useMemo(() => salesMomentum(orders), [orders]);
  const revenue = useMemo(() => countedRevenue(orders), [orders]);

  /* product identity map for thumbnails (photo or themed initial) */
  const byId = useMemo(() => {
    const m = new Map<string, SiteProductDTO>();
    for (const p of products) m.set(p.recordId, p);
    return m;
  }, [products]);

  const maxQty = top.length > 0 ? top[0].qty : 0;
  const trendUp = momentum.delta > 0.05;
  const trendDown = momentum.delta < -0.05;

  return (
    <DashCard
      title={t("estoreTopTitle")}
      icon="chart-column"
      action={
        momentum.last7 > 0 || momentum.prev7 > 0 ? (
          <span
            className={cn(
              "inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-extrabold",
              trendUp
                ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-300"
                : trendDown
                  ? "bg-rose-500/10 text-rose-600 dark:text-rose-300"
                  : "bg-slate-500/10 text-slate-500 dark:text-slate-400"
            )}
            title={t("estoreTopMomentumHint", { prev: nf(lang, momentum.prev7) })}
          >
            <CatIcon
              name={trendUp ? "trending-up" : trendDown ? "trending-down" : "trending-up"}
              className="h-3.5 w-3.5"
            />
            {t("estoreTopMomentum", { n: nf(lang, momentum.last7) })}
          </span>
        ) : null
      }
    >
      {ordersQuery.isPending ? (
        <div className="space-y-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-14 rounded-2xl" />
          ))}
        </div>
      ) : top.length === 0 ? (
        <div className="rounded-2xl border-2 border-dashed border-slate-200 p-8 text-center dark:border-white/10">
          <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
            <CatIcon name="chart-column" className="h-6 w-6" />
          </span>
          <p className="mt-3 text-[12.5px] font-bold text-slate-500 dark:text-slate-400">
            {t("estoreTopEmpty")}
          </p>
          <p className="mt-1 text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("estoreTopEmptyHint")}
          </p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {top.map((line, i) => {
            const product = byId.get(line.recordId);
            const rank = RANK_STYLES[i] ?? RANK_STYLES[4];
            const share = maxQty > 0 ? Math.max(6, Math.round((line.qty / maxQty) * 100)) : 0;
            return (
              <div
                key={line.recordId}
                className="group flex items-center gap-3 rounded-2xl border border-slate-200/80 bg-white p-2.5 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lift dark:border-white/10 dark:bg-white/[0.035]"
              >
                {/* rank medal */}
                <span
                  className={cn(
                    "grid h-8 w-8 shrink-0 place-items-center rounded-xl font-display text-[13px] font-black tabular-nums",
                    rank.chip
                  )}
                  aria-label={`#${i + 1}`}
                >
                  {nf(lang, i + 1)}
                </span>
                {/* thumbnail — managed photo or themed initial tile */}
                {product?.imageRef ? (
                  <span className="h-12 w-14 shrink-0 overflow-hidden rounded-xl border border-slate-200/80 dark:border-white/10">
                    <img
                      src={product.imageRef}
                      alt={line.name}
                      loading="lazy"
                      decoding="async"
                      className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
                    />
                  </span>
                ) : (
                  <span className="grid h-12 w-14 shrink-0 place-items-center rounded-xl border border-slate-200/80 bg-slate-50 font-display text-[16px] font-black text-slate-400 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-500">
                    {line.name.trim().charAt(0)}
                  </span>
                )}
                {/* name + relative bar */}
                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline justify-between gap-2">
                    <p className="truncate text-[12.5px] font-extrabold text-slate-900 dark:text-white" title={line.name}>
                      {line.name}
                    </p>
                    <span
                      dir="ltr"
                      className="shrink-0 font-display text-[12px] font-black tabular-nums text-emerald-600 dark:text-emerald-400"
                    >
                      {fmtOrderPrice(lang, line.revenue, currency)}
                    </span>
                  </div>
                  <div className="mt-1.5 flex items-center gap-2">
                    <div className="h-2 min-w-0 flex-1 overflow-hidden rounded-full bg-slate-100 dark:bg-white/[0.06]">
                      <div
                        className={cn("h-full rounded-full bg-gradient-to-l transition-all duration-500", rank.bar)}
                        style={{ width: `${share}%` }}
                        role="progressbar"
                        aria-valuenow={line.qty}
                        aria-valuemin={0}
                        aria-valuemax={maxQty}
                        aria-label={t("estoreTopQty")}
                      />
                    </div>
                    <span className="shrink-0 text-[10.5px] font-extrabold tabular-nums text-slate-500 dark:text-slate-400">
                      {t("estoreTopQtyChip", { n: nf(lang, line.qty), orders: nf(lang, line.orderCount) })}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
          {/* counted revenue footer */}
          <div className="flex items-center justify-between rounded-xl bg-slate-50/80 px-3.5 py-2.5 dark:bg-white/[0.03]">
            <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
              {t("estoreTopRevenueNote")}
            </span>
            <span
              dir="ltr"
              className="font-display text-[13px] font-black tabular-nums text-slate-900 dark:text-white"
            >
              {fmtOrderPrice(lang, revenue, currency)}
            </span>
          </div>
        </div>
      )}
    </DashCard>
  );
}

/* ------------------------------------------------ sales by day -------- */

/** bar palette per rank within the window (newest = brand, rest emerald) */
const DAILY_WINDOW_DAYS = 14;

/** ROUND 54 — 14-day sales bar chart riding the SAME cached orders feed
 *  (zero new API). Pure-CSS bars (no chart lib): each column is a day, the
 *  height is the revenue share of the window's max, and the tooltip carries
 *  the full date + order count + revenue. Today is highlighted with the
 *  brand gradient so the owner instantly reads "where am I". */
export function SalesByDayPanel({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();

  /* shares BOTH StoreView queries (react-query key-level dedupe — the store
   *  feed supplies the workspace currency, the orders feed the bars) */
  const storeQuery = useQuery({
    queryKey: ["instance-store", instance.id],
    queryFn: () => fetchInstanceStoreStatus(instance.id),
    staleTime: 30_000,
    retry: 0,
  });
  const ordersQuery = useQuery({
    queryKey: ["instance-orders", instance.id],
    queryFn: () => fetchInstanceOrders(instance.id, { limit: 200 }),
    staleTime: 15_000,
    retry: 0,
  });
  const orders = useMemo(() => ordersQuery.data?.orders ?? [], [ordersQuery.data]);
  const currency = storeQuery.data?.currency ?? "SAR";

  const buckets = useMemo(
    () => aggregateDailySales(orders, DAILY_WINDOW_DAYS),
    [orders]
  );

  const todayKey = useMemo(() => {
    const d = new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }, []);

  const maxRevenue = Math.max(...buckets.map((b) => b.revenue), 0);
  const windowRevenue = Math.round(buckets.reduce((s, b) => s + b.revenue, 0) * 100) / 100;
  const windowOrders = buckets.reduce((s, b) => s + b.orders, 0);
  const bestDay = buckets.reduce<DailySalesBucket | null>(
    (best, b) => (b.revenue > 0 && (!best || b.revenue > best.revenue) ? b : best),
    null
  );

  const fmtDay = (day: string) => {
    try {
      return new Intl.DateTimeFormat(intlLocale(lang), { day: "numeric", month: "short" }).format(
        new Date(`${day}T12:00:00`)
      );
    } catch {
      return day.slice(5);
    }
  };
  const weekday = (day: string) => {
    try {
      return new Intl.DateTimeFormat(intlLocale(lang), { weekday: "short" }).format(
        new Date(`${day}T12:00:00`)
      );
    } catch {
      return "";
    }
  };

  return (
    <DashCard
      title={t("estoreDailyTitle")}
      icon="calendar-days"
      action={
        windowOrders > 0 ? (
          <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2.5 py-1 text-[11px] font-extrabold text-emerald-600 dark:text-emerald-300">
            <CatIcon name="banknote" className="h-3.5 w-3.5" />
            {t("estoreDailyWindow", { n: nf(lang, windowOrders) })}
          </span>
        ) : null
      }
    >
      {ordersQuery.isPending ? (
        <Skeleton className="h-40 w-full rounded-2xl" />
      ) : bestDay === null ? (
        <div className="rounded-2xl border-2 border-dashed border-slate-200 p-8 text-center dark:border-white/10">
          <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
            <CatIcon name="calendar-days" className="h-6 w-6" />
          </span>
          <p className="mt-3 text-[12.5px] font-bold text-slate-500 dark:text-slate-400">
            {t("estoreDailyEmpty")}
          </p>
          <p className="mt-1 text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("estoreDailyEmptyHint", { n: nf(lang, DAILY_WINDOW_DAYS) })}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {/* the chart — one column per day, newest on the LEFT (RTL reading
              order: today is the first column the eye meets). The row does
              NOT set items-end: columns must STRETCH to the full h-36 so
              each bar's percentage height resolves against a definite
              containing height (items-end collapses columns to content
              height and the bars vanish). justify-end inside the column
              keeps every bar bottom-anchored. */}
          <div
            className="flex h-36 gap-1 sm:gap-1.5"
            role="img"
            aria-label={t("estoreDailyAria", {
              n: nf(lang, windowOrders),
              total: fmtOrderPrice(lang, windowRevenue, currency),
            })}
          >
            {[...buckets].reverse().map((b) => {
              const isToday = b.day === todayKey;
              const share = maxRevenue > 0 ? Math.max(6, Math.round((b.revenue / maxRevenue) * 100)) : 0;
              const height = b.revenue > 0 ? `${Math.max(8, share)}%` : "0%";
              return (
                <div
                  key={b.day}
                  className="group flex min-w-0 flex-1 flex-col items-center justify-end gap-1.5"
                  title={`${fmtDay(b.day)} · ${t("estoreDailyTipOrders", { n: nf(lang, b.orders) })} · ${fmtOrderPrice(lang, b.revenue, currency)}`}
                >
                  {/* per-day revenue value on hover (desktop) */}
                  <span
                    dir="ltr"
                    className={cn(
                      "pointer-events-none hidden whitespace-nowrap rounded-md px-1.5 py-0.5 text-[9.5px] font-black tabular-nums opacity-0 transition-opacity duration-200 group-hover:opacity-100 sm:block",
                      isToday
                        ? "bg-brand-500/15 text-brand-600 dark:text-brand-300"
                        : "bg-slate-100 text-slate-500 dark:bg-white/10 dark:text-slate-300"
                    )}
                  >
                    {b.revenue > 0 ? fmtOrderPrice(lang, b.revenue, currency) : "—"}
                  </span>
                  <span
                    className={cn(
                      "w-full max-w-8 rounded-t-lg transition-all duration-500 group-hover:brightness-110",
                      b.revenue === 0
                        ? "h-[3px] rounded bg-slate-200 dark:bg-white/10"
                        : isToday
                          ? "bg-gradient-to-t from-brand-500 to-brand-400 shadow-sm shadow-brand-500/40 ring-1 ring-brand-400/60"
                          : "bg-gradient-to-t from-emerald-600 to-emerald-400 group-hover:from-emerald-500 group-hover:to-emerald-300"
                    )}
                    style={b.revenue === 0 ? undefined : { height }}
                  />
                </div>
              );
            })}
          </div>

          {/* weekday labels — oldest → newest reading order per locale */}
          <div className="flex gap-1 border-t border-dashed border-slate-200 pt-2 dark:border-white/10 sm:gap-1.5">
            {[...buckets].reverse().map((b) => (
              <span
                key={b.day}
                className={cn(
                  "min-w-0 flex-1 truncate text-center text-[8.5px] font-extrabold leading-tight",
                  b.day === todayKey
                    ? "text-brand-600 dark:text-brand-300"
                    : "text-slate-400 dark:text-slate-500"
                )}
              >
                {weekday(b.day)}
              </span>
            ))}
          </div>

          {/* window footer: total + orders + best day */}
          <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-slate-50/80 px-3.5 py-2.5 dark:bg-white/[0.03]">
            <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
              {t("estoreDailyTotalNote", { n: nf(lang, DAILY_WINDOW_DAYS) })}
            </span>
            <span className="flex items-center gap-3">
              {bestDay ? (
                <span
                  title={fmtDay(bestDay.day)}
                  className="inline-flex items-center gap-1 text-[10.5px] font-extrabold text-amber-600 dark:text-amber-300"
                >
                  <CatIcon name="flame" className="h-3 w-3" />
                  {t("estoreDailyBest", { v: fmtOrderPrice(lang, bestDay.revenue, currency) })}
                </span>
              ) : null}
              <span
                dir="ltr"
                className="font-display text-[13px] font-black tabular-nums text-slate-900 dark:text-white"
              >
                {fmtOrderPrice(lang, windowRevenue, currency)}
              </span>
            </span>
          </div>
        </div>
      )}
    </DashCard>
  );
}
