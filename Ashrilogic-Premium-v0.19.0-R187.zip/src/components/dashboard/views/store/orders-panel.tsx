"use client";

import { Fragment, useMemo, useState } from "react";
import { useInfiniteQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import type { InstanceDTO, SiteOrderAdminDTO, SiteOrderStatus } from "@/lib/types";
import { useT, type I18nKey } from "@/lib/i18n";
import { intlLocale } from "@/lib/locales";
import { fetchInstanceOrders, updateInstanceOrder } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, grad } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DashCard, IconTile, relativeTime, fullDate } from "@/components/dashboard/dash-shared";
import { siteTheme } from "@/lib/site-themes";
import { OrderReceiptDialog } from "@/components/site/order-receipt";
import { nf, fmtOrderPrice } from "./shared";

/* ------------------------------------------------ store orders (round 36) */

/** order lifecycle: pending → confirmed → preparing → ready → completed
 *  (cancelled is reachable from any open state). */
const ORDER_FLOW: readonly SiteOrderStatus[] = [
  "pending",
  "confirmed",
  "preparing",
  "ready",
  "completed",
];

const ORDER_STATUS_META: Record<SiteOrderStatus, { icon: string; chip: string }> = {
  pending: {
    icon: "hourglass",
    chip: "border-amber-300/60 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300",
  },
  confirmed: {
    icon: "badge-check",
    chip: "border-sky-300/60 bg-sky-500/10 text-sky-600 dark:border-sky-500/40 dark:text-sky-300",
  },
  preparing: {
    icon: "package-open",
    chip: "border-violet-300/60 bg-violet-500/10 text-violet-600 dark:border-violet-500/40 dark:text-violet-300",
  },
  ready: {
    icon: "package-check",
    chip: "border-emerald-300/60 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300",
  },
  completed: {
    icon: "circle-check",
    chip: "border-emerald-300/60 bg-emerald-500/15 text-emerald-700 dark:border-emerald-500/40 dark:text-emerald-300",
  },
  cancelled: {
    icon: "circle-x",
    chip: "border-rose-300/60 bg-rose-500/10 text-rose-600 dark:border-rose-500/40 dark:text-rose-300",
  },
};

const ORDER_STATUS_KEY: Record<SiteOrderStatus, I18nKey> = {
  pending: "ordStatusPending",
  confirmed: "ordStatusConfirmed",
  preparing: "ordStatusPreparing",
  ready: "ordStatusReady",
  completed: "ordStatusCompleted",
  cancelled: "ordStatusCancelled",
};

const ORDER_FILTERS: readonly (SiteOrderStatus | "all")[] = [
  "all",
  "pending",
  "confirmed",
  "preparing",
  "ready",
  "completed",
  "cancelled",
];

function nextOrderStatus(status: SiteOrderStatus): SiteOrderStatus | null {
  const i = ORDER_FLOW.indexOf(status);
  if (i < 0 || i >= ORDER_FLOW.length - 1) return null;
  return ORDER_FLOW[i + 1] ?? null;
}

const isOrderOpen = (status: SiteOrderStatus) =>
  status !== "completed" && status !== "cancelled";

/** status chip (table rows + mobile cards). ROUND 56 — pending orders
 *  carry a pulsing "needs attention" dot so new orders never sit unseen. */
function OrderStatusBadge({ status }: { status: SiteOrderStatus }) {
  const { t } = useT();
  const meta = ORDER_STATUS_META[status];
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center gap-1 rounded-full border px-2.5 py-1 text-[10.5px] font-extrabold",
        meta.chip
      )}
    >
      {status === "pending" ? (
        <span className="relative flex h-2 w-2 shrink-0" aria-hidden="true">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-amber-400 opacity-75" />
          <span className="relative inline-flex h-2 w-2 rounded-full bg-amber-500" />
        </span>
      ) : (
        <CatIcon name={meta.icon} className="h-[11px] w-[11px]" />
      )}
      {t(ORDER_STATUS_KEY[status])}
    </span>
  );
}

/** order id chip — first 8 chars, uppercase (existing id-chip pattern).
 *  ROUND 50: when the order carries a tracking code it is shown INSTEAD of
 *  the internal id prefix — it is the reference the guest actually holds. */
function OrderIdChip({ id, code }: { id: string; code?: string | null }) {
  const { t } = useT();
  if (code) {
    return (
      <span
        title={t("ordTrackCode")}
        className="inline-flex shrink-0 items-center gap-1 rounded-lg border border-emerald-300/60 bg-emerald-500/10 px-2 py-1 font-mono text-[11px] font-extrabold tracking-wider text-emerald-700 dark:border-emerald-500/40 dark:text-emerald-300"
      >
        <CatIcon name="package-search" className="h-[11px] w-[11px]" />
        {code}
      </span>
    );
  }
  return (
    <code
      dir="ltr"
      className="rounded-lg bg-slate-100 px-2 py-1 font-mono text-[11px] font-extrabold tracking-wider text-slate-600 dark:bg-white/10 dark:text-slate-300"
    >
      #{id.slice(0, 8).toUpperCase()}
    </code>
  );
}

/** the expandable manage panel — items detail, customer note, the optional
 *  status-note input and the advance / cancel actions. Mounted per expanded
 *  row (or card), so the note state starts fresh on every expansion.
 *  ROUND 56 — also renders the order's persistent lifecycle trail (when each
 *  step happened) and the "notify customer by email" toggle.
 *  ROUND 62 — the owner can print the order as a receipt (invoice-grade:
 *  full line prices + the customer name — the fields the guest projection
 *  deliberately hides). */
function OrderManagePanel({
  order,
  instance,
  pending,
  onAdvance,
}: {
  order: SiteOrderAdminDTO;
  instance: InstanceDTO;
  pending: boolean;
  onAdvance: (status: SiteOrderStatus, statusNote?: string, notify?: boolean) => void;
}) {
  const { t, lang } = useT();
  const [note, setNote] = useState("");
  const [notify, setNotify] = useState(true);
  /* ROUND 62 — the printable receipt dialog over this order */
  const [receiptOpen, setReceiptOpen] = useState(false);
  const next = nextOrderStatus(order.status);
  const open = isOrderOpen(order.status);

  /* receipt letterhead identity: the site's theme colors + logo (when the
     route eagerly loaded the site summary), else the org initial tile */
  const theme = siteTheme(instance.site?.theme ?? "");

  /* compact per-event stamp for the trail */
  const fmtTrail = (iso: string) => {
    try {
      const d = new Date(iso);
      const sameDay = new Date().toDateString() === d.toDateString();
      return new Intl.DateTimeFormat(intlLocale(lang), {
        ...(sameDay ? {} : { day: "numeric", month: "short" }),
        hour: "2-digit",
        minute: "2-digit",
      }).format(d);
    } catch {
      return iso.slice(0, 16);
    }
  };

  return (
    <div className="space-y-3.5 rounded-2xl border border-slate-200/80 bg-slate-50/60 p-3.5 dark:border-white/10 dark:bg-white/[0.02]">
      {/* ROUND 62 — print receipt entry (works for open AND closed orders) */}
      <div className="flex items-center justify-end gap-2">
        <button
          type="button"
          onClick={() => setReceiptOpen(true)}
          title={t("rcptPrint")}
          aria-label={t("rcptPrint")}
          className="inline-flex h-8 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-[11px] font-extrabold text-slate-500 transition hover:border-slate-300 hover:text-slate-700 active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:border-white/25 dark:hover:text-white"
        >
          <CatIcon name="printer" className="h-3.5 w-3.5" />
          {t("rcptPrintShort")}
        </button>
      </div>

      {/* items detail */}
      <div>
        <p className="mb-2 text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
          {t("ordColItems")}
        </p>
        <ul className="space-y-1.5">
          {order.items.length === 0 ? (
            <li className="text-[11.5px] font-semibold text-slate-400 dark:text-slate-500">—</li>
          ) : (
            order.items.map((item) => (
              <li
                key={item.recordId}
                className="flex items-center gap-2.5 rounded-xl border border-slate-200/70 bg-white px-3 py-2 transition hover:border-slate-300/80 dark:border-white/[0.07] dark:bg-white/[0.03] dark:hover:border-white/15"
              >
                {/* ROUND 54 — placement-time product photo (snapshot); themed
                    initial tile for photo-less and legacy items */}
                {item.image ? (
                  <span className="h-9 w-9 shrink-0 overflow-hidden rounded-lg border border-slate-200/80 dark:border-white/10">
                    <img
                      src={item.image}
                      alt={item.name}
                      loading="lazy"
                      decoding="async"
                      className="h-full w-full object-cover"
                    />
                  </span>
                ) : (
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-slate-200/80 bg-slate-50 text-[12px] font-black text-slate-400 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-500">
                    {item.name.trim().charAt(0)}
                  </span>
                )}
                <span className="min-w-0 flex-1 truncate text-[12px] font-bold text-slate-700 dark:text-slate-200">
                  {item.name}
                </span>
                <span
                  dir="ltr"
                  className="shrink-0 text-[11.5px] font-semibold tabular-nums text-slate-500 dark:text-slate-400"
                >
                  ×{nf(lang, item.qty)} · {fmtOrderPrice(lang, item.price * item.qty, order.currency)}
                </span>
              </li>
            ))
          )}
        </ul>
      </div>

      {/* customer note (as placed) */}
      {order.note ? (
        <p className="flex items-start gap-1.5 rounded-xl bg-amber-500/10 px-3 py-2 text-[11.5px] leading-relaxed text-amber-700 dark:text-amber-300">
          <CatIcon name="notebook-pen" className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          <span>
            <span className="font-extrabold">{t("ordCustomerNote")}:</span> {order.note}
          </span>
        </p>
      ) : null}

      {/* current status note (shown to the customer on the site) */}
      {order.statusNote ? (
        <p className="flex items-start gap-1.5 rounded-xl bg-sky-500/10 px-3 py-2 text-[11.5px] leading-relaxed text-sky-700 dark:text-sky-300">
          <CatIcon name="message-circle" className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          <span>
            <span className="font-extrabold">{t("ordStatusNoteLabel")}:</span>{" "}
            {order.statusNote}
          </span>
        </p>
      ) : null}

      {/* ROUND 56 — the persistent lifecycle trail (when each step happened) */}
      {order.statusHistory.length > 0 ? (
        <div className="rounded-xl border border-slate-200/70 bg-white p-3 dark:border-white/[0.07] dark:bg-white/[0.03]">
          <p className="mb-2.5 flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            <CatIcon name="history" className="h-3 w-3" />
            {t("ordTrailTitle")}
          </p>
          <ol className="relative space-y-0 ps-1" dir="rtl">
            {/* newest first — the current step leads */}
            {[...order.statusHistory].reverse().map((ev, i, arr) => {
              const meta = ORDER_STATUS_META[ev.status];
              const isLatest = i === 0;
              return (
                <li key={`${ev.status}-${ev.at}-${i}`} className="relative flex gap-3 pb-3 last:pb-0">
                  {/* the connector line */}
                  {i < arr.length - 1 ? (
                    <span
                      className="absolute top-6 start-[13px] h-[calc(100%-16px)] w-px bg-slate-200 dark:bg-white/10"
                      aria-hidden="true"
                    />
                  ) : null}
                  <span
                    className={cn(
                      "relative z-10 grid h-7 w-7 shrink-0 place-items-center rounded-lg border",
                      isLatest ? cn("shadow-sm", meta.chip) : "border-slate-200 bg-slate-50 text-slate-400 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-500"
                    )}
                  >
                    <CatIcon name={meta.icon} className="h-3.5 w-3.5" />
                  </span>
                  <div className="min-w-0 flex-1 pt-0.5">
                    <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-0.5">
                      <p
                        className={cn(
                          "text-[11.5px] font-extrabold",
                          isLatest ? "text-slate-800 dark:text-slate-100" : "text-slate-500 dark:text-slate-400"
                        )}
                      >
                        {t(ORDER_STATUS_KEY[ev.status])}
                      </p>
                      <time
                        dir="ltr"
                        className="shrink-0 rounded-md bg-slate-100/80 px-1.5 py-px text-[9.5px] font-bold tabular-nums text-slate-500 dark:bg-white/[0.06] dark:text-slate-400"
                        dateTime={ev.at}
                      >
                        {fmtTrail(ev.at)}
                      </time>
                    </div>
                    {ev.note ? (
                      <p className="mt-1 rounded-lg bg-slate-50 px-2 py-1 text-[10.5px] font-semibold leading-relaxed text-slate-500 dark:bg-white/[0.03] dark:text-slate-400">
                        {ev.note}
                      </p>
                    ) : null}
                  </div>
                </li>
              );
            })}
          </ol>
        </div>
      ) : null}

      {open ? (
        <div className="space-y-2.5 border-t border-dashed border-slate-200 pt-3 dark:border-white/10">
          {/* optional status note — reaches the customer on the public site */}
          <div className="space-y-1.5">
            <Label htmlFor={`ord-note-${order.id}`} className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
              {t("ordNoteLabel")}
            </Label>
            <Input
              id={`ord-note-${order.id}`}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder={t("ordNotePh")}
              maxLength={300}
              className="h-9 rounded-xl text-[12.5px]"
            />
          </div>
          {/* ROUND 56 — email notice opt-out (default: send when the guest
              left an email; phone-only guests are silently skipped) */}
          <label
            htmlFor={`ord-notify-${order.id}`}
            className="flex cursor-pointer items-center justify-between gap-3 rounded-xl border border-slate-200/80 bg-white px-3 py-2.5 transition hover:border-brand-300/70 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-brand-500/40"
          >
            <span className="flex min-w-0 items-start gap-2">
              <CatIcon name="mail-check" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand-500 dark:text-brand-300" />
              <span className="min-w-0">
                <span className="block text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200">
                  {t("ordNotifyLabel")}
                </span>
                <span className="block text-[10px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                  {t("ordNotifyDesc")}
                </span>
              </span>
            </span>
            <input
              id={`ord-notify-${order.id}`}
              type="checkbox"
              role="switch"
              checked={notify}
              onChange={(e) => setNotify(e.target.checked)}
              className="h-4 w-7 shrink-0 cursor-pointer appearance-none rounded-full bg-slate-200 transition-colors before:block before:h-3.5 before:w-3.5 before:translate-x-0.5 before:rounded-full before:bg-white before:shadow before:transition-transform checked:bg-brand-500 checked:before:translate-x-[13px] rtl:before:translate-x-[13px] rtl:checked:before:translate-x-0.5 dark:bg-white/15"
            />
          </label>
          <div className="flex flex-wrap items-center gap-2">
            {next ? (
              <Button
                type="button"
                size="sm"
                onClick={() => onAdvance(next, note.trim() || undefined, notify)}
                disabled={pending}
                className="h-9 gap-1.5 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-4 text-[11.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-60 dark:from-brand-500 dark:to-brand-400"
              >
                {pending ? (
                  <CatIcon name="refresh-cw" className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <CatIcon name="arrow-right" className="h-3.5 w-3.5 rtl:rotate-180" />
                )}
                {t("ordAdvanceTo", { status: t(ORDER_STATUS_KEY[next]) })}
              </Button>
            ) : null}
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={() => onAdvance("cancelled", note.trim() || undefined, notify)}
              disabled={pending}
              className="h-9 gap-1.5 rounded-xl border-rose-200 px-4 text-[11.5px] font-extrabold text-rose-600 transition hover:bg-rose-50 hover:text-rose-700 active:scale-95 disabled:opacity-60 dark:border-rose-500/30 dark:text-rose-300 dark:hover:bg-rose-500/10 dark:hover:text-rose-200"
            >
              <CatIcon name="circle-x" className="h-3.5 w-3.5" />
              {t("ordCancelBtn")}
            </Button>
          </div>
        </div>
      ) : (
        <p className="flex items-center gap-1.5 text-[11px] font-extrabold text-slate-400 dark:text-slate-500">
          <CatIcon name="lock" className="h-3.5 w-3.5" />
          {t("ordClosedChip")}
        </p>
      )}

      {/* ROUND 62 — the printable receipt (owner projection: line prices +
          customer name). Mounted at panel level so it survives until the
          row itself collapses. */}
      <OrderReceiptDialog
        open={receiptOpen}
        onOpenChange={setReceiptOpen}
        identity={{
          orgName: instance.org.name,
          logoUrl: instance.site?.logoUrl || null,
          c1: theme.c1,
          c2: theme.c2,
          orgContact:
            [instance.org.phone, instance.org.address].filter(Boolean).join(" · ") || null,
          /* ROUND 67 — the workspace's uploaded invoice signature & stamp
             (owner projection prints them; the guest receipt never does) */
          signatureUrl: instance.site?.signatureUrl || null,
          stampUrl: instance.site?.stampUrl || null,
          signatureScale: instance.site?.signatureScale ?? 1,
          stampScale: instance.site?.stampScale ?? 1,
        }}
        data={{
          code: order.code ?? `#${order.id.slice(0, 8).toUpperCase()}`,
          items: order.items.map((it) => ({ name: it.name, qty: it.qty, unitPrice: it.price })),
          total: order.total,
          discount: order.discount,
          couponCode: order.couponCode,
          currency: order.currency,
          status: order.status,
          statusHistory: order.statusHistory,
          createdAt: order.createdAt,
          updatedAt: order.updatedAt,
          note: order.note,
          customerName: order.customerName,
        }}
      />
    </div>
  );
}

/** KPI cell (customers-view pattern). */
function OrderKpi({
  title,
  value,
  icon,
  c1,
  c2,
  index,
}: {
  title: string;
  value: string;
  icon: string;
  c1: string;
  c2: string;
  index: number;
}) {
  return (
    <article
      className="glass-card card-in group relative overflow-hidden rounded-3xl p-4 transition-shadow duration-300 hover:shadow-lift sm:p-5"
      style={{ "--i": index } as React.CSSProperties}
    >
      <span
        className="pointer-events-none absolute inset-x-0 top-0 h-[2px] opacity-50 transition-opacity duration-300 group-hover:opacity-100"
        style={{ backgroundImage: grad(c1, c2, 90) }}
        aria-hidden="true"
      />
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            {title}
          </p>
          <p dir="ltr" className="mt-1.5 text-start font-display text-3xl font-extrabold tabular-nums text-slate-900 dark:text-white">
            {value}
          </p>
        </div>
        <IconTile icon={icon} c1={c1} c2={c2} size="lg" />
      </div>
    </article>
  );
}

/** the orders management panel — the owner's storefront order queue.
 *  ROUND 57 — keyset-paginated (20/page, stable under concurrent
 *  placements): the status chips drive SERVER-side filtering, the KPI
 *  strip + chip counts come from the server's instance-wide aggregates
 *  (never bounded by the loaded page), and load-more appends pages. */
export function SiteOrdersPanel({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const [statusFilter, setStatusFilter] = useState<SiteOrderStatus | "all">("all");
  const [expandedId, setExpandedId] = useState<string | null>(null);

  /* keyset feed — the filter is part of the key so switching chips is a
   * fresh, cacheable first page (never a client-side subset). */
  const PAGE_SIZE = 20;
  const feed = useInfiniteQuery({
    queryKey: ["instance-orders-feed", instance.id, statusFilter, PAGE_SIZE],
    queryFn: ({ pageParam }) =>
      fetchInstanceOrders(instance.id, {
        limit: PAGE_SIZE,
        cursor: pageParam,
        ...(statusFilter !== "all" ? { status: statusFilter } : {}),
      }),
    initialPageParam: null as string | null,
    getNextPageParam: (lastPage) => lastPage.nextCursor,
    staleTime: 10_000,
    retry: 1,
  });
  const query = feed;

  const orders = useMemo(
    () => feed.data?.pages.flatMap((p) => p.orders) ?? [],
    [feed.data]
  );
  /* the page IS the filter — no client-side re-filtering (server truth) */
  const filtered = orders;

  /* instance-wide counts from the server (first page carries them) */
  const serverCounts = feed.data?.pages[0]?.counts;
  const byStatus = (s: SiteOrderStatus) => serverCounts?.byStatus[s] ?? 0;
  const counts = {
    all: serverCounts?.all ?? 0,
    pending: serverCounts?.pending ?? 0,
    open: serverCounts?.open ?? 0,
    completed: serverCounts?.completed ?? 0,
    cancelled: serverCounts?.cancelled ?? 0,
    byStatus,
  };

  /* status transitions invalidate EVERY orders surface: the paginated
   * feed (all its filter variants), the analytics window and the page KPI
   * counts query — prefix keys keep them all covered. */
  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["instance-orders-feed", instance.id] });
    queryClient.invalidateQueries({ queryKey: ["instance-orders", instance.id] });
    queryClient.invalidateQueries({ queryKey: ["instance-orders-counts", instance.id] });
  };

  const advance = useMutation({
    mutationFn: (v: {
      orderId: string;
      status: SiteOrderStatus;
      statusNote?: string;
      notify?: boolean;
    }) =>
      updateInstanceOrder(instance.id, v.orderId, {
        status: v.status,
        ...(v.statusNote !== undefined ? { statusNote: v.statusNote } : {}),
        ...(v.notify !== undefined ? { notify: v.notify } : {}),
      }),
    onSuccess: (data, v) => {
      /* ROUND 56 — confirm the dispatched email notice alongside the
         status change (guests without an email are silently skipped) */
      if (data.notified) {
        toast.success(t("ordUpdatedNotifiedToast", { status: t(ORDER_STATUS_KEY[v.status]) }));
      } else {
        toast.success(t("ordUpdatedToast", { status: t(ORDER_STATUS_KEY[v.status]) }));
      }
      setExpandedId(null);
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message || t("errorText")),
  });

  const advanceOf =
    (order: SiteOrderAdminDTO) =>
    (status: SiteOrderStatus, statusNote?: string, notify?: boolean) =>
      advance.mutate({ orderId: order.id, status, statusNote, notify });

  const chips: { key: SiteOrderStatus | "all"; label: string; count: number }[] =
    ORDER_FILTERS.map((key) => ({
      key,
      label: key === "all" ? t("ordFilterAll") : t(ORDER_STATUS_KEY[key]),
      count: key === "all" ? counts.all : counts.byStatus(key),
    }));

  /* ROUND 59 — orders export: a same-origin navigation download. The
   * route answers with Content-Disposition: attachment, so the workspace
   * session cookie rides the request AND the page never navigates away. */
  const exportOrders = (format: "csv" | "json") => {
    window.location.assign(
      `/api/instances/${instance.id}/export?type=orders&format=${format}`
    );
  };

  return (
    <div className="space-y-4">
      {/* KPI strip */}
      {query.isPending ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-3xl" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <OrderKpi title={t("ordKpiNew")} value={nf(lang, counts.pending)} icon="hourglass" c1="#f59e0b" c2="#d97706" index={0} />
          <OrderKpi title={t("ordKpiOpen")} value={nf(lang, counts.open)} icon="package-open" c1="#8b5cf6" c2="#7c3aed" index={1} />
          <OrderKpi title={t("ordKpiDone")} value={nf(lang, counts.completed)} icon="circle-check" c1="#10b981" c2="#059669" index={2} />
          <OrderKpi title={t("ordKpiCancelled")} value={nf(lang, counts.cancelled)} icon="circle-x" c1="#f43f5e" c2="#e11d48" index={3} />
        </div>
      )}

      {/* orders table */}
      <DashCard
        title={t("ordPanelTitle")}
        icon="shopping-cart"
        action={
          <Button
            variant="ghost"
            size="icon"
            onClick={() => query.refetch()}
            disabled={query.isFetching}
            aria-label={t("ordRefresh")}
            title={t("ordRefresh")}
            className="h-7 w-7 rounded-lg text-slate-400 hover:text-brand-600 dark:text-slate-500"
          >
            <CatIcon name="refresh-cw" className={cn("h-3.5 w-3.5", query.isFetching && "animate-spin")} />
          </Button>
        }
      >
        <p className="mb-4 text-[12px] leading-relaxed text-slate-500 dark:text-slate-400">
          {t("ordPanelDesc")}
        </p>

        {/* status filter chips */}
        <div className="mb-4 flex flex-wrap items-center gap-2">
          {chips.map((chip) => (
            <button
              key={chip.key}
              type="button"
              onClick={() => setStatusFilter(chip.key)}
              aria-pressed={statusFilter === chip.key}
              className={cn(
                "inline-flex h-10 items-center gap-1.5 rounded-full border px-4 text-[11.5px] font-extrabold transition active:scale-95 sm:h-9 sm:px-3.5",
                statusFilter === chip.key
                  ? chip.key === "cancelled"
                    ? "border-rose-300 bg-rose-500/10 text-rose-600 dark:border-rose-500/40 dark:text-rose-300"
                    : "border-brand-300 bg-brand-500/10 text-brand-600 dark:border-brand-500/40 dark:text-brand-300"
                  : "border-slate-200 bg-white/60 text-slate-500 hover:border-slate-300 hover:text-slate-700 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-400 dark:hover:text-slate-200"
              )}
            >
              {chip.label}
              <span
                dir="ltr"
                className="rounded-full bg-slate-100 px-1.5 py-px text-[10px] font-extrabold tabular-nums text-slate-500 dark:bg-white/10 dark:text-slate-400"
              >
                {nf(lang, chip.count)}
              </span>
            </button>
          ))}

          {/* ROUND 59 — orders export menu: rides the inline-END of the
              filter row (ms-auto + flex-wrap → wraps under the chips on
              narrow screens); the download is a same-origin cookie
              navigation, so no manual auth headers are needed */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                type="button"
                variant="outline"
                disabled={feed.isPending}
                aria-disabled={feed.isPending}
                title={feed.isPending ? t("loadingText") : t("estoreExportOrders")}
                className="ms-auto h-9 gap-1.5 rounded-xl border-slate-200 bg-white px-3.5 text-[12px] font-bold text-slate-600 shadow-none transition hover:border-brand-300 hover:text-brand-600 active:scale-95 disabled:pointer-events-auto disabled:opacity-50 dark:border-white/10 dark:bg-transparent dark:text-slate-200 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
              >
                <CatIcon name="download" className="size-3.5" />
                {t("estoreExportOrders")}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-64 rounded-2xl p-1.5">
              <DropdownMenuItem
                onClick={() => exportOrders("csv")}
                className="gap-2.5 rounded-xl px-2 py-2"
              >
                <span
                  className="grid h-7 w-7 shrink-0 place-items-center rounded-lg border border-emerald-300/60 bg-emerald-500/10 dark:border-emerald-500/40"
                  aria-hidden="true"
                >
                  <CatIcon name="table" className="size-3.5 text-emerald-600 dark:text-emerald-300" />
                </span>
                <span className="min-w-0 flex-1 truncate text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                  {t("estoreExportCsv")}
                </span>
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => exportOrders("json")}
                className="gap-2.5 rounded-xl px-2 py-2"
              >
                <span
                  className="grid h-7 w-7 shrink-0 place-items-center rounded-lg border border-sky-300/60 bg-sky-500/10 dark:border-sky-500/40"
                  aria-hidden="true"
                >
                  <CatIcon name="braces" className="size-3.5 text-sky-600 dark:text-sky-300" />
                </span>
                <span className="min-w-0 flex-1 truncate text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                  {t("estoreExportJson")}
                </span>
              </DropdownMenuItem>
              <DropdownMenuSeparator className="bg-slate-200/70 dark:bg-white/10" />
              <p className="px-2.5 pb-1 pt-1.5 text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                {t("estoreExportHint", { n: nf(lang, 5000) })}
              </p>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {query.isPending ? (
          /* skeletons — table shape on desktop, cards on mobile */
          <>
            <div className="hidden space-y-2 md:block">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-14 w-full rounded-xl" />
              ))}
            </div>
            <div className="space-y-2.5 md:hidden">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-28 w-full rounded-2xl" />
              ))}
            </div>
          </>
        ) : query.isError ? (
          <div className="py-12 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-rose-100 text-rose-500 dark:bg-rose-500/10 dark:text-rose-300">
              <CatIcon name="circle-alert" className="h-6 w-6" />
            </div>
            <p className="mt-3 font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("errorText")}
            </p>
            <button
              type="button"
              onClick={() => query.refetch()}
              className="mt-5 inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 px-5 text-[12.5px] font-bold transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10"
            >
              <CatIcon name="refresh-cw" className="h-4 w-4" />
              {t("retryText")}
            </button>
          </div>
        ) : orders.length === 0 && statusFilter === "all" ? (
          <div className="py-12 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
              <CatIcon name="shopping-cart" className="h-6 w-6" />
            </div>
            <h3 className="mt-4 font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
              {t("ordEmpty")}
            </h3>
            <p className="mx-auto mt-1 max-w-sm text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("ordEmptyDesc")}
            </p>
          </div>
        ) : orders.length === 0 ? (
          <div className="py-12 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
              <CatIcon name="filter" className="h-6 w-6" />
            </div>
            <h3 className="mt-4 font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
              {t("ordNoMatch")}
            </h3>
            <button
              type="button"
              onClick={() => setStatusFilter("all")}
              className="mt-4 inline-flex h-9 items-center gap-1.5 rounded-lg px-3 text-[11.5px] font-bold text-brand-600 transition hover:text-brand-700 active:scale-95 dark:text-brand-300"
            >
              <CatIcon name="x" className="h-3.5 w-3.5" />
              {t("ordFilterAll")}
            </button>
          </div>
        ) : (
          <>
            {/* desktop table */}
            <div className="nice-scroll hidden max-h-[34rem] overflow-y-auto [contain:content] md:block">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-200/70 dark:border-white/10">
                    {[
                      t("ordColCustomer"),
                      t("ordColItems"),
                      t("ordColTotal"),
                      t("ordColStatus"),
                      t("ordColPlaced"),
                    ].map((label) => (
                      <TableHead
                        key={label}
                        className={cn(
                          "whitespace-nowrap text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500",
                          lang === "ar" ? "tracking-normal" : "tracking-wider"
                        )}
                      >
                        {label}
                      </TableHead>
                    ))}
                    <TableHead className="text-end text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                      {t("ordColActions")}
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((order) => {
                    const qty = order.items.reduce((s, i) => s + i.qty, 0);
                    const expanded = expandedId === order.id;
                    return (
                      <Fragment key={order.id}>
                        <TableRow className="border-slate-200/60 dark:border-white/[0.07]">
                          {/* customer — gradient avatar + name */}
                          <TableCell>
                            <div className="flex items-center gap-2.5">
                              <span
                                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-[12px] font-extrabold text-white"
                                style={{ backgroundImage: grad("#6d5dfb", "#d946ef") }}
                                aria-hidden="true"
                              >
                                {(order.customerName || "؟").trim().charAt(0).toUpperCase()}
                              </span>
                              <div className="min-w-0">
                                <p className="flex items-center gap-1.5">
                                  <span className="max-w-[160px] truncate text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                                    {order.customerName}
                                  </span>
                                </p>
                                <p className="mt-0.5">
                                  <OrderIdChip id={order.id} code={order.code} />
                                </p>
                              </div>
                            </div>
                          </TableCell>
                          {/* items summary */}
                          <TableCell>
                            <p dir="ltr" className="whitespace-nowrap text-[12px] font-bold tabular-nums text-slate-600 dark:text-slate-300">
                              {nf(lang, order.items.length)} · {nf(lang, qty)}
                              <span className="ms-1 text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                                {t("ordPcsUnit")}
                              </span>
                            </p>
                          </TableCell>
                          {/* total */}
                          <TableCell>
                            <p dir="ltr" className="whitespace-nowrap text-[12.5px] font-extrabold tabular-nums text-slate-800 dark:text-slate-100">
                              {fmtOrderPrice(lang, order.total, order.currency)}
                            </p>
                          </TableCell>
                          {/* status */}
                          <TableCell>
                            <OrderStatusBadge status={order.status} />
                          </TableCell>
                          {/* placed */}
                          <TableCell>
                            <p
                              className="whitespace-nowrap text-[11.5px] font-semibold text-slate-500 dark:text-slate-400"
                              title={fullDate(order.createdAt, lang)}
                            >
                              {relativeTime(order.createdAt, lang)}
                            </p>
                          </TableCell>
                          {/* actions — expand */}
                          <TableCell className="text-end">
                            <button
                              type="button"
                              onClick={() => setExpandedId(expanded ? null : order.id)}
                              aria-expanded={expanded}
                              aria-label={t("ordDetails")}
                              title={t("ordDetails")}
                              disabled={advance.isPending}
                              className={cn(
                                "inline-flex h-8 items-center gap-1.5 rounded-xl border px-2.5 text-[10.5px] font-extrabold transition active:scale-95 disabled:opacity-50",
                                expanded
                                  ? "border-brand-300 bg-brand-500/10 text-brand-600 dark:border-brand-500/40 dark:text-brand-300"
                                  : "border-slate-200 text-slate-500 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:text-slate-400 dark:hover:text-brand-300"
                              )}
                            >
                              <CatIcon
                                name="chevron-down"
                                className={cn("h-3.5 w-3.5 transition-transform", expanded && "rotate-180")}
                              />
                              <span className="hidden xl:inline">{t("ordDetails")}</span>
                            </button>
                          </TableCell>
                        </TableRow>
                        {expanded ? (
                          <TableRow className="border-slate-200/60 dark:border-white/[0.07]">
                            <TableCell colSpan={6} className="bg-slate-50/40 dark:bg-white/[0.015]">
                              <div className="mx-auto max-w-2xl py-1">
                                <OrderManagePanel
                                  order={order}
                                  instance={instance}
                                  pending={advance.isPending && advance.variables?.orderId === order.id}
                                  onAdvance={advanceOf(order)}
                                />
                              </div>
                            </TableCell>
                          </TableRow>
                        ) : null}
                      </Fragment>
                    );
                  })}
                </TableBody>
              </Table>
            </div>

            {/* mobile cards */}
            <div className="nice-scroll max-h-[34rem] space-y-2.5 overflow-y-auto [contain:content] md:hidden">
              {filtered.map((order) => {
                    const qty = order.items.reduce((s, i) => s + i.qty, 0);
                    const expanded = expandedId === order.id;
                    return (
                      <article
                        key={order.id}
                        className="rounded-2xl border border-slate-200 bg-white p-3.5 dark:border-white/10 dark:bg-white/[0.03]"
                      >
                        <div className="flex items-center gap-2">
                          <OrderIdChip id={order.id} code={order.code} />
                          <OrderStatusBadge status={order.status} />
                          <span
                            className="ms-auto text-[10.5px] font-bold text-slate-400 dark:text-slate-500"
                            title={fullDate(order.createdAt, lang)}
                          >
                            {relativeTime(order.createdAt, lang)}
                          </span>
                        </div>
                        <div className="mt-2.5 flex items-center gap-2.5">
                          <span
                            className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-[12px] font-extrabold text-white"
                            style={{ backgroundImage: grad("#6d5dfb", "#d946ef") }}
                            aria-hidden="true"
                          >
                            {(order.customerName || "؟").trim().charAt(0).toUpperCase()}
                          </span>
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                              {order.customerName}
                            </p>
                            <p dir="ltr" className="text-[11px] font-semibold tabular-nums text-slate-500 dark:text-slate-400">
                              {nf(lang, order.items.length)} · {nf(lang, qty)} {t("ordPcsUnit")}
                            </p>
                          </div>
                          <p dir="ltr" className="shrink-0 text-[13px] font-extrabold tabular-nums text-slate-800 dark:text-slate-100">
                            {fmtOrderPrice(lang, order.total, order.currency)}
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => setExpandedId(expanded ? null : order.id)}
                          aria-expanded={expanded}
                          disabled={advance.isPending}
                          className={cn(
                            "mt-2.5 flex h-9 w-full items-center justify-center gap-1.5 rounded-xl border text-[11px] font-extrabold transition active:scale-95 disabled:opacity-50",
                            expanded
                              ? "border-brand-300 bg-brand-500/10 text-brand-600 dark:border-brand-500/40 dark:text-brand-300"
                              : "border-slate-200 text-slate-500 dark:border-white/10 dark:text-slate-400"
                          )}
                        >
                          <CatIcon
                            name="chevron-down"
                            className={cn("h-3.5 w-3.5 transition-transform", expanded && "rotate-180")}
                          />
                          {t("ordDetails")}
                        </button>
                        {expanded ? (
                          <div className="mt-2.5">
                            <OrderManagePanel
                              order={order}
                              instance={instance}
                              pending={advance.isPending && advance.variables?.orderId === order.id}
                              onAdvance={advanceOf(order)}
                            />
                          </div>
                        ) : null}
                      </article>
                    );
                  })}
            </div>

            {/* ROUND 57 — keyset load-more (shared by both layouts): pages
                are stable under concurrent placements — no skipped rows,
                no duplicates, no re-sorting. */}
            {feed.hasNextPage ? (
              <div className="mt-4 flex flex-col items-center gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => feed.fetchNextPage()}
                  disabled={feed.isFetchingNextPage}
                  className="h-10 gap-2 rounded-xl border-slate-200 bg-white px-6 text-[12.5px] font-extrabold text-slate-600 shadow-none transition hover:border-brand-300 hover:text-brand-600 active:scale-95 disabled:opacity-60 dark:border-white/10 dark:bg-transparent dark:text-slate-200 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
                >
                  <CatIcon
                    name="chevron-down"
                    className={cn("h-4 w-4 transition-transform", feed.isFetchingNextPage && "animate-bounce")}
                  />
                  {feed.isFetchingNextPage ? t("ordLoadingMore") : t("ordLoadMore")}
                </Button>
                <p className="text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                  {t("ordLoadedHint", {
                    loaded: nf(lang, orders.length),
                    total: nf(lang, statusFilter === "all" ? counts.all : counts.byStatus(statusFilter)),
                  })}
                </p>
              </div>
            ) : orders.length > 0 ? (
              <div className="mt-4 flex items-center justify-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-slate-300 dark:bg-white/20" aria-hidden="true" />
                <p className="text-[10.5px] font-extrabold text-slate-400 dark:text-slate-500">
                  {t("ordEndOfQueue")}
                </p>
                <span className="h-1.5 w-1.5 rounded-full bg-slate-300 dark:bg-white/20" aria-hidden="true" />
              </div>
            ) : null}
          </>
        )}
      </DashCard>
    </div>
  );
}
