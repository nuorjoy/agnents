"use client";

import type { Lang } from "@/lib/types";
import { fmtPrice } from "@/lib/format";

/* shared formatting moved to lib/format — re-exported for the existing
   dashboard imports (fmtOrderPrice keeps its name for call-site clarity). */
export { nf } from "@/lib/format";

export function fmtOrderPrice(lang: Lang, amount: number, currency: string): string {
  return fmtPrice(lang, amount, currency);
}
