"use client";

/**
 * ROUND 63 — the owner's REVIEW MODERATION console.
 *
 * Guest reviews land here for the store owner: a KPI chip strip over the
 * console-wide aggregates (total / average / hidden), the newest-first
 * moderation queue (keyset pages + load-more, the orders console's rhythm),
 * and per-row actions — hide/show (the public storefront + the aggregates
 * follow within one invalidate) and delete behind an AlertDialog confirm
 * (the coupon console's dialog, verbatim rhythm).
 *
 * Hidden rows dim to opacity-60 so the moderated state reads at a glance;
 * every mutation also invalidates ["instance-store"] because the product
 * rows' rating chips (photos console) ride that payload.
 */

import { useMemo, useState } from "react";
import { useInfiniteQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import type { InstanceDTO, OwnerReviewDTO } from "@/lib/types";
import { useT } from "@/lib/i18n";
import {
  deleteInstanceReview,
  fetchInstanceReviews,
  setInstanceReviewHidden,
} from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { DashCard, fullDate, relativeTime } from "@/components/dashboard/dash-shared";
import { nf } from "./shared";

/* --------------------------------------------- reviews (ROUND 63) ----- */

/**
 * Local 5-star display glyph row — amber filled up to round(value), slate
 * outline for the rest. Shared with the products console's rating chips.
 * Purely decorative (aria-hidden): callers carry the text alternative
 * (title attribute / sr-only span with "n/5").
 */
export function StarRating({
  value,
  className = "h-3.5 w-3.5",
}: {
  value: number;
  className?: string;
}) {
  const filled = Math.round(Math.max(0, Math.min(5, value)));
  return (
    <span className="inline-flex items-center gap-0.5" aria-hidden="true">
      {Array.from({ length: 5 }).map((_, i) => (
        <CatIcon
          key={i}
          name="star"
          className={cn(
            className,
            i < filled
              ? "fill-current text-amber-400 dark:text-amber-300"
              : "text-slate-300 dark:text-slate-600"
          )}
        />
      ))}
    </span>
  );
}

/** one moderation row — attribution, verdict, body, hide/show + delete. */
function ReviewRow({
  review,
  busy,
  onToggle,
  onDelete,
}: {
  review: OwnerReviewDTO;
  busy: boolean;
  onToggle: (r: OwnerReviewDTO) => void;
  onDelete: (r: OwnerReviewDTO) => void;
}) {
  const { t, lang } = useT();
  const hideLabel = t(review.hidden ? "estoreReviewShow" : "estoreReviewHide");

  return (
    <li
      className={cn(
        "rounded-2xl border border-slate-200 bg-white p-4 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lift dark:border-white/10 dark:bg-white/[0.035]",
        /* moderated rows dim — reads at a glance (smooth via transition-all) */
        review.hidden && "opacity-60"
      )}
    >
      {/* attribution + moderation badge + date */}
      <div className="flex flex-wrap items-center gap-2">
        <p className="min-w-0 truncate text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
          {t("estoreReviewOn", { name: review.productName || "—" })}
        </p>
        <span
          className={cn(
            "inline-flex shrink-0 items-center gap-1 rounded-full border px-2.5 py-0.5 text-[10px] font-extrabold transition-colors",
            review.hidden
              ? "border-amber-300/60 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300"
              : "border-emerald-300/60 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
          )}
        >
          <CatIcon name={review.hidden ? "eye-off" : "eye"} className="h-3 w-3" />
          {t(review.hidden ? "estoreReviewHiddenBadge" : "estoreReviewVisibleBadge")}
        </span>
        <span
          className="ms-auto shrink-0 text-[10.5px] font-bold text-slate-400 dark:text-slate-500"
          title={fullDate(review.createdAt, lang)}
        >
          {relativeTime(review.createdAt, lang)}
        </span>
      </div>

      {/* verdict + reviewer name */}
      <div className="mt-2 flex flex-wrap items-center gap-2.5">
        <span className="inline-flex items-center gap-1.5" title={`${nf(lang, review.rating)}/5`}>
          <StarRating value={review.rating} />
          <span className="sr-only">{nf(lang, review.rating)}/5</span>
        </span>
        <span className="text-[11.5px] font-semibold text-slate-500 dark:text-slate-400">
          {review.name || "—"}
        </span>
      </div>

      {/* body — "—" when the guest left stars only */}
      {review.body && review.body.trim() ? (
        <p className="mt-2 whitespace-pre-line text-[12.5px] leading-relaxed text-slate-600 dark:text-slate-300">
          {review.body}
        </p>
      ) : (
        <p className="mt-2 text-[12.5px] leading-relaxed text-slate-400 dark:text-slate-500">—</p>
      )}

      {/* moderation actions — ghost buttons with hover:bg states */}
      <div className="mt-3 flex flex-wrap items-center gap-1.5">
        <button
          type="button"
          disabled={busy}
          onClick={() => onToggle(review)}
          title={hideLabel}
          aria-label={`${hideLabel} — ${review.productName}`}
          className={cn(
            "inline-flex h-8 items-center gap-1.5 rounded-xl px-3 text-[11.5px] font-bold transition active:scale-95 disabled:opacity-50",
            review.hidden
              ? "text-slate-500 hover:bg-emerald-500/15 hover:text-emerald-700 dark:text-slate-400 dark:hover:bg-emerald-500/20 dark:hover:text-emerald-300"
              : "text-slate-500 hover:bg-amber-500/15 hover:text-amber-700 dark:text-slate-400 dark:hover:bg-amber-500/20 dark:hover:text-amber-300"
          )}
        >
          <CatIcon name={review.hidden ? "eye-off" : "eye"} className="h-3.5 w-3.5" />
          {hideLabel}
        </button>
        <button
          type="button"
          disabled={busy}
          onClick={() => onDelete(review)}
          title={t("estoreReviewDelete")}
          aria-label={`${t("estoreReviewDelete")} — ${review.productName}`}
          className="inline-flex h-8 items-center gap-1.5 rounded-xl px-3 text-[11.5px] font-bold text-slate-500 transition hover:bg-rose-500/10 hover:text-rose-600 active:scale-95 disabled:opacity-50 dark:text-slate-400 dark:hover:text-rose-300"
        >
          <CatIcon name="trash-2" className="h-3.5 w-3.5" />
          {t("estoreReviewDelete")}
        </button>
      </div>
    </li>
  );
}

/** ROUND 63 — the owner's review moderation console card. */
export function ReviewsPanel({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const [deleteTarget, setDeleteTarget] = useState<OwnerReviewDTO | null>(null);

  /* newest-first keyset pages (max 15/page server-side) + load-more —
   * the orders console's pagination idiom, same query-key conventions */
  const reviewsQuery = useInfiniteQuery({
    queryKey: ["instance-reviews", instance.id],
    queryFn: ({ pageParam }) => fetchInstanceReviews(instance.id, pageParam ?? undefined),
    initialPageParam: null as string | null,
    getNextPageParam: (lastPage) => lastPage.nextCursor,
    staleTime: 30_000,
    retry: 0,
  });

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["instance-reviews", instance.id] });
    /* the product rows' rating chips ride the store payload (aggregates shift
     * with every hide/show/delete) */
    queryClient.invalidateQueries({ queryKey: ["instance-store", instance.id] });
  };

  const setHidden = useMutation({
    mutationFn: (r: OwnerReviewDTO) => setInstanceReviewHidden(instance.id, r.id, !r.hidden),
    onSuccess: (_res, r) => {
      invalidate();
      toast.success(t(r.hidden ? "estoreReviewShowToast" : "estoreReviewHideToast"));
    },
    onError: (e: Error) => toast.error(e.message || t("errorText")),
  });

  const remove = useMutation({
    mutationFn: (r: OwnerReviewDTO) => deleteInstanceReview(instance.id, r.id),
    onSuccess: () => {
      invalidate();
      setDeleteTarget(null);
      toast.success(t("estoreReviewDeleteToast"));
    },
    onError: (e: Error) => toast.error(e.message || t("errorText")),
  });

  const reviews = useMemo(
    () => reviewsQuery.data?.pages.flatMap((p) => p.reviews) ?? [],
    [reviewsQuery.data]
  );
  /* console-wide aggregates ride every page — read them off the first */
  const agg = reviewsQuery.data?.pages[0];
  const total = agg?.total ?? 0;
  const hiddenCount = agg?.hiddenCount ?? 0;
  const avg = agg?.avg ?? null;
  const busy = setHidden.isPending || remove.isPending;

  return (
    <DashCard title={t("estoreReviewsTitle")} icon="star">
      <div className="space-y-3">
        <p className="max-w-xl text-[11.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
          {t("estoreReviewsDesc")}
        </p>

        {/* KPI chip strip (the e-store strip vocabulary) + moderation hint */}
        <div>
          <div className="flex flex-wrap items-center gap-1.5">
            <Badge
              variant="outline"
              className="gap-1.5 self-start rounded-full px-3 py-1 text-[11px] font-extrabold"
            >
              <CatIcon
                name="star"
                className="h-3 w-3 fill-current text-amber-500 dark:text-amber-300"
              />
              {t("estoreReviewsTotal")}: {nf(lang, total)}
            </Badge>
            <Badge
              variant="outline"
              className="gap-1.5 self-start rounded-full px-3 py-1 text-[11px] font-extrabold"
              title={t("estoreReviewsAvg")}
            >
              <StarRating value={avg ?? 0} className="h-2.5 w-2.5" />
              {t("estoreReviewsAvg")}:{" "}
              <span dir="ltr" className="tabular-nums">
                {nf(lang, avg ?? 0)}
              </span>
            </Badge>
            <Badge
              variant="outline"
              className={cn(
                "gap-1.5 self-start rounded-full px-3 py-1 text-[11px] font-extrabold",
                hiddenCount > 0
                  ? "border-amber-300/70 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300"
                  : "text-slate-500 dark:text-slate-400"
              )}
            >
              <CatIcon name="eye-off" className="h-3 w-3" />
              {t("estoreReviewsHiddenCount")}: {nf(lang, hiddenCount)}
            </Badge>
          </div>
          <p className="mt-1.5 text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("estoreReviewModerationHint")}
          </p>
        </div>

        {/* the moderation queue */}
        {reviewsQuery.isPending ? (
          <div className="space-y-2.5">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-32 w-full rounded-2xl" />
            ))}
          </div>
        ) : total === 0 && hiddenCount === 0 ? (
          <div className="rounded-2xl border-2 border-dashed border-slate-200 p-8 text-center dark:border-white/10">
            <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-amber-500/10 text-amber-500 dark:text-amber-300">
              <CatIcon name="star" className="h-6 w-6" />
            </div>
            <h4 className="mt-3 font-display text-[14px] font-extrabold text-slate-900 dark:text-white">
              {t("estoreReviewsEmptyTitle")}
            </h4>
            <p className="mx-auto mt-1 max-w-sm text-[12px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("estoreReviewsEmptyDesc")}
            </p>
          </div>
        ) : (
          <div className="space-y-2.5">
            <ul className="max-h-[28rem] space-y-2.5 overflow-y-auto pe-1 [contain:content] [scrollbar-width:thin]">
              {reviews.map((review) => (
                <ReviewRow
                  key={review.id}
                  review={review}
                  busy={busy}
                  onToggle={(r) => setHidden.mutate(r)}
                  onDelete={(r) => setDeleteTarget(r)}
                />
              ))}
            </ul>

            {/* load more — the orders console's centered ghost button */}
            {reviewsQuery.hasNextPage ? (
              <div className="flex justify-center pt-1">
                <button
                  type="button"
                  onClick={() => reviewsQuery.fetchNextPage()}
                  disabled={reviewsQuery.isFetchingNextPage}
                  className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-6 text-[12.5px] font-extrabold text-slate-600 shadow-none transition hover:border-brand-300 hover:text-brand-600 active:scale-95 disabled:opacity-60 dark:border-white/10 dark:bg-transparent dark:text-slate-200 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
                >
                  <CatIcon
                    name="chevron-down"
                    className={cn(
                      "h-4 w-4 transition-transform",
                      reviewsQuery.isFetchingNextPage && "animate-bounce"
                    )}
                  />
                  {t("reviewsLoadMore")}
                </button>
              </div>
            ) : null}
          </div>
        )}
      </div>

      {/* ---------------------------- delete confirm -------------------- */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span className="grid h-10 w-10 place-items-center rounded-2xl bg-rose-500/10 text-rose-500">
                <CatIcon name="trash-2" className="h-5 w-5" />
              </span>
              {t("estoreReviewDeleteTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[12.5px] leading-relaxed">
              {t("estoreReviewDeleteDesc")}
              {deleteTarget ? (
                <span className="mt-2 block text-[12px] font-black text-rose-500">
                  {t("estoreReviewOn", { name: deleteTarget.productName || "—" })} —{" "}
                  {deleteTarget.name || "—"}
                </span>
              ) : null}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold">
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteTarget && remove.mutate(deleteTarget)}
              disabled={remove.isPending}
              className="h-10 gap-2 rounded-xl bg-rose-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/30 transition hover:bg-rose-600"
            >
              {remove.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="trash-2" className="h-4 w-4" />
              )}
              {t("estoreReviewDelete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashCard>
  );
}
