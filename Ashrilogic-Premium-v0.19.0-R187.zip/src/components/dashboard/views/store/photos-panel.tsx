"use client";

import { useRef, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import type { InstanceDTO, SiteProductDTO } from "@/lib/types";
import { useT } from "@/lib/i18n";
import {
  updateModuleRecord,
  uploadStoreImage,
  uploadStoreVideo,
} from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, grad } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { nf, fmtOrderPrice } from "./shared";
import { StarRating } from "./reviews-panel";

/* ================================================================== */
/* ROUND 140 — product media console (the owner's directive: 6 photos  */
/* ≤8 MB each + 2 video clips ≤10 MB each per product, plus the        */
/* storefront visibility checkmark).                                   */
/* ================================================================== */

/** the owner's directive — the hard caps this console enforces client-side */
const MAX_GALLERY = 6;
const MAX_VIDEOS = 2;
const MAX_IMAGE_INPUT = 8 * 1024 * 1024;
const MAX_VIDEO_INPUT = 10 * 1024 * 1024;

/** accepted original upload types (the server re-encodes to clean WebP) */
const PHOTO_MIME_RE = /^image\/(png|jpe?g|webp|gif)$/;
/** accepted video types (the server verifies the bytes' magic signature) */
const VIDEO_MIME_RE = /^video\/(mp4|webm|quicktime|x-m4v|x-quicktime|mov)$/;

/**
 * Read a picked photo into a compact 4:3 landscape JPEG data-URL (cover crop,
 * 1280×960 target with a quality ladder). Keeps the upload fast while the
 * SERVER re-encode stays the single authority; when the ladder cannot get
 * under the payload target (a huge noisy original), the RAW file rides the
 * request instead (≤8 MB — the server pipeline handles it identically).
 */
async function productMediaImageFromFile(file: File): Promise<string> {
  if (!PHOTO_MIME_RE.test(file.type)) {
    throw new Error("bad-type");
  }
  if (file.size > MAX_IMAGE_INPUT) {
    throw new Error("too-large");
  }

  const objectUrl = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error("corrupt"));
      image.src = objectUrl;
    });
    const srcW = img.naturalWidth;
    const srcH = img.naturalHeight;
    if (!srcW || !srcH) throw new Error("corrupt");

    /* cover-crop the source to a 4:3 window, scaled to ≤ 1280×960 */
    const targetW = 1280;
    const targetH = 960;
    const scale = Math.max(targetW / srcW, targetH / srcH);
    const drawW = Math.round(srcW * scale);
    const drawH = Math.round(srcH * scale);
    const offsetX = Math.round((targetW - drawW) / 2);
    const offsetY = Math.round((targetH - drawH) / 2);

    for (const quality of [0.88, 0.8, 0.7, 0.58]) {
      const canvas = document.createElement("canvas");
      canvas.width = targetW;
      canvas.height = targetH;
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("corrupt");
      ctx.imageSmoothingQuality = "high";
      /* white matte under transparent sources (flattened to JPEG) */
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, targetW, targetH);
      ctx.drawImage(img, offsetX, offsetY, drawW, drawH);
      const dataUrl = canvas.toDataURL("image/jpeg", quality);
      /* payload ≈ 3/4 of the base64 length — stay under ~1.3 MB */
      if (dataUrl.length * 0.75 <= 1_300_000) return dataUrl;
    }
    /* the compressed form is still too heavy — send the RAW original (the
     * file already passed the 8 MB gate; the server re-encode is the
     * authority and caps the STORED output at 500 KB regardless). */
    return await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () =>
        typeof reader.result === "string" ? resolve(reader.result) : reject(new Error("corrupt"));
      reader.onerror = () => reject(new Error("corrupt"));
      reader.readAsDataURL(file);
    });
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}

/** The full ordered gallery of a product (cover first). */
function fullGalleryOf(product: SiteProductDTO): string[] {
  /* the DTO's gallery already carries [cover, ...extras] in order */
  return product.gallery ?? [];
}

/** One product row in the owner's media console. */
export function ProductMediaRow({
  instance,
  product,
  currency,
  onEdit,
  onSale,
}: {
  instance: InstanceDTO;
  product: SiteProductDTO;
  currency: string;
  onEdit: (product: SiteProductDTO) => void;
  onSale: (product: SiteProductDTO) => void;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();

  /* ROUND 140 — the storefront visibility checkmark (instant commit, the
   * same law as the featured star: one boolean, one PATCH, one toast). */
  const toggleVisible = useMutation({
    mutationFn: () =>
      updateModuleRecord(instance.id, product.recordId, {
        storeVisible: !product.storeVisible,
      }),
    onSuccess: () => {
      toast.success(t(product.storeVisible ? "estoreVisibleOff" : "estoreVisibleOn"));
      queryClient.invalidateQueries({ queryKey: ["instance-store", instance.id] });
    },
    onError: () => toast.error(t("errorText")),
  });

  /* ROUND 52 — featured toggle (star) */
  const toggleFeatured = useMutation({
    mutationFn: () =>
      updateModuleRecord(instance.id, product.recordId, { featured: !product.featured }),
    onSuccess: () => {
      toast.success(t(product.featured ? "estoreFeaturedOff" : "estoreFeaturedOn"));
      queryClient.invalidateQueries({ queryKey: ["instance-store", instance.id] });
    },
    onError: () => toast.error(t("errorText")),
  });

  const gallery = fullGalleryOf(product);
  const photoCount = gallery.length;
  const videoCount = product.videos?.length ?? 0;
  const hasPhoto = photoCount > 0;
  const onSalePrice = product.salePrice != null;
  /* the effective price the storefront charges / displays in the chip */
  const effective = onSalePrice ? (product.salePrice as number) : product.price;
  /* ROUND 53 — days left on the sale window (null = open-ended / none). */
  const saleDaysLeft = product.saleEndsAt
    ? Math.max(
        0,
        Math.ceil((new Date(product.saleEndsAt).getTime() - Date.now()) / 86_400_000)
      )
    : null;

  return (
    <div
      className={cn(
        "group flex items-center gap-2.5 rounded-2xl border bg-white p-2.5 shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lift dark:bg-white/[0.035]",
        !product.storeVisible
          ? "border-slate-300/70 bg-slate-50/70 opacity-80 dark:border-white/[0.07] dark:bg-white/[0.02]"
          : product.featured
            ? "border-amber-300/70 bg-amber-50/40 dark:border-amber-400/30 dark:bg-amber-400/[0.04]"
            : "border-slate-200/80 dark:border-white/10"
      )}
    >
      {/* ROUND 140 — the storefront visibility CHECKMARK (leads the row) */}
      <button
        type="button"
        onClick={() => toggleVisible.mutate()}
        disabled={toggleVisible.isPending}
        title={t("estoreVisibleToggle")}
        aria-label={t("estoreVisibleToggle")}
        aria-pressed={product.storeVisible}
        className={cn(
          "grid h-8 w-8 shrink-0 place-items-center rounded-lg transition active:scale-90 disabled:opacity-50",
          product.storeVisible
            ? "bg-emerald-500/15 text-emerald-600 hover:bg-emerald-500/25 dark:text-emerald-300"
            : "text-slate-300 hover:bg-slate-100 hover:text-emerald-500 dark:text-slate-600 dark:hover:bg-white/10 dark:hover:text-emerald-300"
        )}
      >
        <CatIcon
          name="circle-check"
          className={cn("h-4.5 w-4.5", product.storeVisible && "drop-shadow-sm")}
        />
      </button>
      {/* ROUND 52 — featured star toggle */}
      <button
        type="button"
        onClick={() => toggleFeatured.mutate()}
        disabled={toggleFeatured.isPending}
        title={t("estoreFeaturedToggle")}
        aria-label={t("estoreFeaturedToggle")}
        aria-pressed={product.featured}
        className={cn(
          "grid h-8 w-8 shrink-0 place-items-center rounded-lg transition active:scale-90 disabled:opacity-50",
          product.featured
            ? "bg-amber-400/20 text-amber-500 hover:bg-amber-400/30 dark:text-amber-300"
            : "text-slate-300 hover:bg-slate-100 hover:text-amber-400 dark:text-slate-600 dark:hover:bg-white/10 dark:hover:text-amber-300"
        )}
      >
        <CatIcon
          name="star"
          className={cn("h-4.5 w-4.5", product.featured && "fill-current drop-shadow-sm")}
        />
      </button>
      {/* thumbnail — the COVER (gallery[0]) or the dashed add tile */}
      {hasPhoto ? (
        <span className="relative h-14 w-[74px] shrink-0 overflow-hidden rounded-xl border border-slate-200/80 dark:border-white/10">
          <img
            src={gallery[0] ?? ""}
            alt={t("storePhotoAlt", { name: product.name })}
            loading="lazy"
            decoding="async"
            className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
          />
          {videoCount > 0 ? (
            <span
              title={t("estoreMediaVideosChip", { n: nf(lang, videoCount) })}
              className="absolute bottom-1 inline-flex items-center gap-0.5 rounded-full bg-black/65 px-1.5 py-0.5 text-[9px] font-black text-white backdrop-blur-sm start-1"
            >
              <CatIcon name="play" className="h-2.5 w-2.5 fill-current" />
              {nf(lang, videoCount)}
            </span>
          ) : null}
        </span>
      ) : (
        <button
          type="button"
          onClick={() => onEdit(product)}
          title={t("estoreMediaAddImage")}
          aria-label={t("estoreMediaAddImage")}
          className="grid h-14 w-[74px] shrink-0 place-items-center rounded-xl border-2 border-dashed border-slate-300 text-slate-400 transition hover:border-brand-400 hover:text-brand-500 dark:border-white/15 dark:text-slate-500 dark:hover:border-brand-500/50"
        >
          <CatIcon name="image-plus" className="h-5 w-5" />
        </button>
      )}

      {/* name + meta */}
      <div className="min-w-0 flex-1">
        <p
          className="truncate text-[12.5px] font-extrabold text-slate-900 dark:text-white"
          title={product.name}
        >
          {product.featured ? (
            <CatIcon name="star" className="me-1 inline h-3.5 w-3.5 fill-current text-amber-500 dark:text-amber-300" />
          ) : null}
          {product.name}
        </p>
        <div className="mt-1 flex flex-wrap items-center gap-1.5">
          {product.category ? (
            <span className="max-w-28 truncate rounded-full border border-slate-200 px-2 py-0.5 text-[10.5px] font-bold text-slate-500 dark:border-white/10 dark:text-slate-400">
              {product.category}
            </span>
          ) : null}
          {/* ROUND 140 — hidden-from-storefront badge (the checkmark's echo) */}
          {!product.storeVisible ? (
            <span className="inline-flex items-center gap-1 rounded-full bg-slate-500/10 px-2 py-0.5 text-[10.5px] font-extrabold text-slate-500 dark:text-slate-400">
              <CatIcon name="eye-off" className="h-3 w-3" />
              {t("estoreHiddenBadge")}
            </span>
          ) : null}
          {/* ROUND 140 — media chips (photos beyond the cover + videos) */}
          {photoCount > 1 ? (
            <span
              title={t("estoreMediaPhotosChip", { n: nf(lang, photoCount) })}
              className="inline-flex items-center gap-1 rounded-full bg-brand-500/10 px-2 py-0.5 text-[10.5px] font-extrabold text-brand-600 dark:text-brand-300"
            >
              <CatIcon name="camera" className="h-3 w-3" />
              {nf(lang, photoCount)}
            </span>
          ) : null}
          {videoCount > 0 ? (
            <span
              title={t("estoreMediaVideosChip", { n: nf(lang, videoCount) })}
              className="inline-flex items-center gap-1 rounded-full bg-sky-500/10 px-2 py-0.5 text-[10.5px] font-extrabold text-sky-600 dark:text-sky-300"
            >
              <CatIcon name="film" className="h-3 w-3" />
              {nf(lang, videoCount)}
            </span>
          ) : null}
          {/* ROUND 63 — live rating aggregate */}
          {product.ratingCount > 0 ? (
            <span
              title={`${nf(lang, product.ratingAvg ?? 0)}/5`}
              className="inline-flex items-center gap-1 rounded-full bg-amber-500/10 px-2 py-0.5 text-[10.5px] font-extrabold text-amber-600 dark:text-amber-300"
            >
              <StarRating value={product.ratingAvg ?? 0} className="h-2.5 w-2.5" />
              {t("estoreProductRatingChip", { n: nf(lang, product.ratingCount) })}
            </span>
          ) : null}
          {/* ROUND 52 — the effective price: struck regular + rose sale price */}
          <span
            dir="ltr"
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[10.5px] font-extrabold tabular-nums",
              onSalePrice
                ? "bg-rose-500/10 text-rose-600 dark:text-rose-300"
                : "bg-brand-500/10 text-brand-600 dark:text-brand-300"
            )}
          >
            {onSalePrice ? (
              <span className="text-[9.5px] font-bold text-slate-400 line-through dark:text-slate-500">
                {fmtOrderPrice(lang, product.price, currency)}
              </span>
            ) : null}
            {fmtOrderPrice(lang, effective, currency)}
          </span>
          {/* ROUND 53 — the sale window countdown chip */}
          {onSalePrice ? (
            <span
              title={t("estoreSaleEndLabel")}
              className={cn(
                "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10.5px] font-extrabold",
                saleDaysLeft != null && saleDaysLeft <= 3
                  ? "bg-rose-500/10 text-rose-600 dark:text-rose-300"
                  : "bg-slate-500/10 text-slate-500 dark:text-slate-400"
              )}
            >
              <CatIcon name="hourglass" className="h-3 w-3" />
              {saleDaysLeft == null
                ? t("estoreSaleEndOpen")
                : saleDaysLeft <= 0
                  ? t("estoreSaleEndsToday")
                  : t("estoreSaleEndsIn", { n: nf(lang, saleDaysLeft) })}
            </span>
          ) : null}
          <span
            className={cn(
              "rounded-full px-2 py-0.5 text-[10.5px] font-extrabold",
              product.stock > 10
                ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-300"
                : product.stock > 0
                  ? "bg-amber-500/10 text-amber-600 dark:text-amber-300"
                  : "bg-rose-500/10 text-rose-600 dark:text-rose-300"
            )}
          >
            {nf(lang, product.stock)}
          </span>
        </div>
      </div>

      {/* actions — icon buttons with tooltips (media / sale) */}
      <div className="flex shrink-0 items-center gap-1.5">
        <button
          type="button"
          onClick={() => onEdit(product)}
          title={t("estoreMediaEditBtn")}
          aria-label={t("estoreMediaEditBtn")}
          className={cn(
            "grid h-8 w-8 place-items-center rounded-lg transition active:scale-95",
            hasPhoto || videoCount > 0
              ? "bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-white/10 dark:text-slate-300 dark:hover:bg-white/20"
              : "bg-gradient-to-l from-brand-500 to-sky-500 text-white shadow-md hover:brightness-110"
          )}
        >
          <CatIcon name={hasPhoto || videoCount > 0 ? "pencil" : "image-plus"} className="h-4 w-4" />
        </button>
        {/* ROUND 52 — sale price editor */}
        <button
          type="button"
          onClick={() => onSale(product)}
          title={onSalePrice ? `${t("estoreSaleTitle")} — ${fmtOrderPrice(lang, effective, currency)}` : t("estoreSaleTitle")}
          aria-label={t("estoreSaleTitle")}
          aria-pressed={onSalePrice}
          className={cn(
            "grid h-8 w-8 place-items-center rounded-lg transition active:scale-95",
            onSalePrice
              ? "bg-rose-500/15 text-rose-600 hover:bg-rose-500/25 dark:text-rose-300"
              : "text-slate-400 hover:bg-slate-100 hover:text-rose-500 dark:text-slate-500 dark:hover:bg-white/10 dark:hover:text-rose-300"
          )}
        >
          <CatIcon name="percent" className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* the premium media manager dialog                                     */
/* ------------------------------------------------------------------ */

/**
 * ProductMediaDialog — the ROUND 140 premium console:
 *  · SECTION 1 — صور المنتج: a 3×2 tile grid, cover first, reorder arrows,
 *    remove, and a multi-pick add tile (≤6 total, 8 MB each; each pick is
 *    canvas-compressed → uploaded → a managed ref lands in local state);
 *  · SECTION 2 — مقاطع الفيديو: two slots with live <video> previews
 *    (≤2 total, 10 MB each);
 *  · SECTION 3 — علامة الظهور: the storefront visibility Switch
 *    (instant commit — one boolean PATCH, independent of the media save);
 *  · FOOTER — حفظ الوسائط commits gallery + videos in ONE PATCH.
 */
export function ProductMediaDialog({
  open,
  product,
  instance,
  onClose,
}: {
  open: boolean;
  product: SiteProductDTO | null;
  instance: InstanceDTO;
  onClose: () => void;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();

  /* ---- local editor state (resets per product via the previous-value
   *  pattern — the dialog stays mounted and swaps its product) ---- */
  const [gallery, setGallery] = useState<string[]>([]);
  const [videos, setVideos] = useState<string[]>([]);
  const [imgBusy, setImgBusy] = useState(false);
  const [vidBusy, setVidBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [prevId, setPrevId] = useState<string | null>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  /* per-product reset DURING render (React's documented previous-value
   * pattern). CAREFUL: both sides of the comparison must share the SAME
   * nullish semantics — `product?.recordId ?? null` — or the closed state
   * (undefined) never matches the initial null and the reset re-fires on
   * every render (infinite loop). */
  const currentId = product?.recordId ?? null;
  if (currentId !== prevId) {
    setPrevId(currentId);
    setGallery(product ? fullGalleryOf(product) : []);
    setVideos(product ? [...(product.videos ?? [])] : []);
    setError(null);
  }

  const initialGallery = product ? fullGalleryOf(product).join("\n") : "";
  const initialVideos = product ? (product.videos ?? []).join("\n") : "";
  const mediaDirty =
    gallery.join("\n") !== initialGallery || videos.join("\n") !== initialVideos;

  /** close + reset (also runs after a successful save). */
  const close = () => {
    setError(null);
    onClose();
  };

  /* ---- the visibility checkmark (instant commit — SECTION 3) ---- */
  const toggleVisible = useMutation({
    mutationFn: () =>
      updateModuleRecord(instance.id, product!.recordId, {
        storeVisible: !(product?.storeVisible ?? true),
      }),
    onSuccess: () => {
      toast.success(
        t(product?.storeVisible ? "estoreVisibleOff" : "estoreVisibleOn")
      );
      queryClient.invalidateQueries({ queryKey: ["instance-store", instance.id] });
    },
    onError: () => toast.error(t("errorText")),
  });

  /* ---- the media save (gallery + videos in ONE PATCH) ---- */
  const save = useMutation({
    mutationFn: () =>
      updateModuleRecord(instance.id, product!.recordId, {
        gallery,
        videos,
      }),
    onSuccess: () => {
      toast.success(t("estoreMediaSaved"));
      queryClient.invalidateQueries({ queryKey: ["instance-store", instance.id] });
      close();
    },
    onError: () => toast.error(t("errorText")),
  });

  /* ---- image picks: compress → upload → append (sequential, ordered) ---- */
  const pickImages = async (files: FileList | null | undefined) => {
    if (!product || !files || files.length === 0) return;
    setError(null);
    const room = MAX_GALLERY - gallery.length;
    if (room <= 0) {
      setError(t("estoreMediaImagesHint", { n: nf(lang, MAX_GALLERY) }));
      return;
    }
    const picks = Array.from(files).slice(0, room);
    setImgBusy(true);
    try {
      for (const file of picks) {
        try {
          const dataUrl = await productMediaImageFromFile(file);
          const stored = await uploadStoreImage(instance.id, dataUrl);
          setGallery((prev) =>
            prev.length >= MAX_GALLERY ? prev : [...prev, stored.url]
          );
        } catch (e) {
          const code = e instanceof Error ? e.message : "";
          if (code === "bad-type") setError(t("estoreMediaErrImageType"));
          else if (code === "too-large") setError(t("estoreMediaErrImageSize"));
          else setError(e instanceof Error ? e.message : t("errorText"));
        }
      }
    } finally {
      setImgBusy(false);
    }
  };

  /* ---- video picks: validate → upload → append ---- */
  const pickVideo = async (file: File | null | undefined) => {
    if (!product || !file) return;
    setError(null);
    if (videos.length >= MAX_VIDEOS) {
      setError(t("estoreMediaVideosHint"));
      return;
    }
    if (!VIDEO_MIME_RE.test(file.type)) {
      setError(t("estoreMediaErrVideoType"));
      return;
    }
    if (file.size > MAX_VIDEO_INPUT) {
      setError(t("estoreMediaErrVideoSize"));
      return;
    }
    setVidBusy(true);
    try {
      const stored = await uploadStoreVideo(instance.id, file);
      setVideos((prev) => (prev.length >= MAX_VIDEOS ? prev : [...prev, stored.url]));
    } catch (e) {
      setError(e instanceof Error ? e.message : t("errorText"));
    } finally {
      setVidBusy(false);
    }
  };

  /* ---- reorder helpers (cover = index 0) ---- */
  const moveImage = (from: number, to: number) => {
    setGallery((prev) => {
      if (to < 0 || to >= prev.length) return prev;
      const next = [...prev];
      const [moved] = next.splice(from, 1);
      next.splice(to, 0, moved as string);
      return next;
    });
  };

  const visible = product !== null;

  return (
    <Dialog open={open} onOpenChange={(next) => (next ? undefined : close())}>
      <DialogContent className="max-h-[90vh] max-w-lg gap-0 overflow-y-auto rounded-3xl border-slate-200/90 bg-white p-6 dark:border-white/10 dark:bg-[#101319]">
        <DialogHeader className="text-start">
          <DialogTitle className="flex items-center gap-2 font-display text-[16px] font-extrabold">
            <span
              className="grid h-9 w-9 place-items-center rounded-xl text-white shadow-md"
              style={{ backgroundImage: grad("#6d5dfb", "#0ea5e9") }}
            >
              <CatIcon name="image-plus" className="h-4.5 w-4.5" />
            </span>
            {t("estoreMediaTitle")}
          </DialogTitle>
          <DialogDescription className="pe-8 text-[12px] leading-relaxed">
            {product ? `${product.name} — ` : ""}
            {t("estoreMediaDesc", { n: nf(lang, MAX_GALLERY) })}
          </DialogDescription>
        </DialogHeader>

        {visible && product ? (
          <div className="mt-4 space-y-5">
            {/* ============ SECTION 1 — photos ============ */}
            <section aria-label={t("estoreMediaImagesSection")}>
              <div className="mb-2 flex items-center justify-between gap-2">
                <h4 className="flex items-center gap-1.5 text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                  <CatIcon name="camera" className="h-4 w-4 text-brand-500" />
                  {t("estoreMediaImagesSection")}
                  <span dir="ltr" className="rounded-full bg-slate-500/10 px-1.5 py-0.5 text-[10px] font-black tabular-nums text-slate-500 dark:text-slate-400">
                    {nf(lang, gallery.length)}/{nf(lang, MAX_GALLERY)}
                  </span>
                </h4>
              </div>

              <div className="grid grid-cols-3 gap-2.5">
                {gallery.map((ref, i) => (
                  <div
                    key={ref}
                    className={cn(
                      "group relative overflow-hidden rounded-2xl border transition",
                      i === 0
                        ? "border-brand-400/70 ring-2 ring-brand-500/20"
                        : "border-slate-200/80 dark:border-white/10"
                    )}
                  >
                    <img
                      src={ref}
                      alt={t("storePhotoAlt", { name: product.name })}
                      loading="lazy"
                      decoding="async"
                      className="aspect-[4/3] w-full object-cover"
                    />
                    {/* the cover badge */}
                    {i === 0 ? (
                      <span
                        className="absolute top-1.5 inline-flex items-center gap-1 rounded-full bg-gradient-to-l from-brand-500 to-sky-500 px-2 py-0.5 text-[9.5px] font-black text-white shadow-md start-1.5"
                      >
                        <CatIcon name="image" className="h-2.5 w-2.5" />
                        {t("estoreMediaCoverBadge")}
                      </span>
                    ) : null}
                    {/* hover controls: make-cover / order / remove */}
                    <div className="absolute inset-x-0 bottom-0 flex items-center justify-between gap-1 bg-gradient-to-t from-black/70 to-transparent p-1.5 pt-4 opacity-0 transition group-hover:opacity-100 focus-within:opacity-100">
                      <div className="flex items-center gap-1">
                        {i > 0 ? (
                          <button
                            type="button"
                            onClick={() => moveImage(i, i - 1)}
                            title={t("estoreMediaMovePrev")}
                            aria-label={t("estoreMediaMovePrev")}
                            className="grid h-6 w-6 place-items-center rounded-lg bg-white/90 text-slate-700 shadow-sm transition hover:bg-white active:scale-90"
                          >
                            {/* RTL: "earlier" moves visually start-ward */}
                            <CatIcon name="arrow-right" className="h-3.5 w-3.5" />
                          </button>
                        ) : null}
                        {i < gallery.length - 1 ? (
                          <button
                            type="button"
                            onClick={() => moveImage(i, i + 1)}
                            title={t("estoreMediaMoveNext")}
                            aria-label={t("estoreMediaMoveNext")}
                            className="grid h-6 w-6 place-items-center rounded-lg bg-white/90 text-slate-700 shadow-sm transition hover:bg-white active:scale-90"
                          >
                            <CatIcon name="arrow-left" className="h-3.5 w-3.5" />
                          </button>
                        ) : null}
                        {i > 0 ? (
                          <button
                            type="button"
                            onClick={() => moveImage(i, 0)}
                            title={t("estoreMediaMakeCover")}
                            aria-label={t("estoreMediaMakeCover")}
                            className="grid h-6 w-6 place-items-center rounded-lg bg-white/90 text-brand-600 shadow-sm transition hover:bg-white active:scale-90"
                          >
                            <CatIcon name="image" className="h-3.5 w-3.5" />
                          </button>
                        ) : null}
                      </div>
                      <button
                        type="button"
                        onClick={() => setGallery((prev) => prev.filter((r) => r !== ref))}
                        title={t("estoreMediaRemove")}
                        aria-label={t("estoreMediaRemove")}
                        className="grid h-6 w-6 place-items-center rounded-lg bg-rose-600 text-white shadow-sm transition hover:brightness-110 active:scale-90"
                      >
                        <CatIcon name="x" className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                ))}

                {/* the ADD tile (multi-pick, bounded by the remaining room) */}
                {gallery.length < MAX_GALLERY ? (
                  <button
                    type="button"
                    onClick={() => imageInputRef.current?.click()}
                    disabled={imgBusy}
                    className={cn(
                      "grid aspect-[4/3] w-full place-items-center rounded-2xl border-2 border-dashed border-slate-300 text-slate-400 transition hover:border-brand-400 hover:bg-brand-500/[0.04] hover:text-brand-500 disabled:opacity-60 dark:border-white/15 dark:text-slate-500 dark:hover:border-brand-500/50"
                    )}
                  >
                    {imgBusy ? (
                      <span className="flex flex-col items-center gap-1.5">
                        <CatIcon name="refresh-cw" className="h-5 w-5 animate-spin" />
                        <span className="text-[10px] font-extrabold text-slate-500 dark:text-slate-400">
                          {t("estoreMediaUploading")}
                        </span>
                      </span>
                    ) : (
                      <span className="flex flex-col items-center gap-1">
                        <CatIcon name="image-plus" className="h-5 w-5" />
                        <span className="text-[10px] font-extrabold">{t("estoreMediaAddImage")}</span>
                      </span>
                    )}
                  </button>
                ) : null}
              </div>
              <p className="mt-2 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                {t("estoreMediaImagesHint", { n: nf(lang, MAX_GALLERY) })}
              </p>
              <input
                ref={imageInputRef}
                type="file"
                accept="image/png,image/jpeg,image/webp,image/gif"
                multiple
                className="sr-only"
                onChange={(e) => {
                  void pickImages(e.target.files);
                  e.currentTarget.value = "";
                }}
              />
            </section>

            {/* ============ SECTION 2 — videos ============ */}
            <section aria-label={t("estoreMediaVideosSection")}>
              <div className="mb-2 flex items-center justify-between gap-2">
                <h4 className="flex items-center gap-1.5 text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                  <CatIcon name="film" className="h-4 w-4 text-sky-500" />
                  {t("estoreMediaVideosSection")}
                  <span dir="ltr" className="rounded-full bg-slate-500/10 px-1.5 py-0.5 text-[10px] font-black tabular-nums text-slate-500 dark:text-slate-400">
                    {nf(lang, videos.length)}/{nf(lang, MAX_VIDEOS)}
                  </span>
                </h4>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                {videos.map((ref) => (
                  <div
                    key={ref}
                    className="group relative overflow-hidden rounded-2xl border border-slate-200/80 dark:border-white/10"
                  >
                    {/* eslint-disable-next-line jsx-a11y/media-has-caption -- a product clip has no textual track; the aria-label carries the context */}
                    <video
                      src={ref}
                      controls
                      preload="metadata"
                      playsInline
                      aria-label={t("storeQvVideoLabel", { name: product.name })}
                      className="aspect-[4/3] w-full bg-slate-950 object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => setVideos((prev) => prev.filter((r) => r !== ref))}
                      title={t("estoreMediaRemove")}
                      aria-label={t("estoreMediaRemove")}
                      className="absolute top-1.5 grid h-6 w-6 place-items-center rounded-lg bg-rose-600 text-white opacity-0 shadow-sm transition hover:brightness-110 active:scale-90 group-hover:opacity-100 focus-visible:opacity-100 end-1.5"
                    >
                      <CatIcon name="x" className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}

                {videos.length < MAX_VIDEOS ? (
                  <button
                    type="button"
                    onClick={() => videoInputRef.current?.click()}
                    disabled={vidBusy}
                    className="grid aspect-[4/3] w-full place-items-center rounded-2xl border-2 border-dashed border-slate-300 text-slate-400 transition hover:border-sky-400 hover:bg-sky-500/[0.04] hover:text-sky-500 disabled:opacity-60 dark:border-white/15 dark:text-slate-500 dark:hover:border-sky-500/50"
                  >
                    {vidBusy ? (
                      <span className="flex flex-col items-center gap-1.5">
                        <CatIcon name="refresh-cw" className="h-5 w-5 animate-spin" />
                        <span className="text-[10px] font-extrabold text-slate-500 dark:text-slate-400">
                          {t("estoreMediaUploading")}
                        </span>
                      </span>
                    ) : (
                      <span className="flex flex-col items-center gap-1">
                        <CatIcon name="video" className="h-5 w-5" />
                        <span className="text-[10px] font-extrabold">{t("estoreMediaAddVideo")}</span>
                      </span>
                    )}
                  </button>
                ) : null}
              </div>
              <p className="mt-2 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                {t("estoreMediaVideosHint")}
              </p>
              <input
                ref={videoInputRef}
                type="file"
                accept="video/mp4,video/webm,video/quicktime,.mov,.mp4,.webm"
                className="sr-only"
                onChange={(e) => {
                  void pickVideo(e.target.files?.[0]);
                  e.currentTarget.value = "";
                }}
              />
            </section>

            {/* ============ SECTION 3 — the visibility checkmark ============ */}
            <section
              aria-label={t("estoreVisibleToggle")}
              className={cn(
                "flex items-start justify-between gap-3 rounded-2xl border p-3.5 transition",
                product.storeVisible
                  ? "border-emerald-300/60 bg-emerald-500/[0.05] dark:border-emerald-500/30 dark:bg-emerald-500/[0.06]"
                  : "border-slate-200 bg-slate-50 dark:border-white/10 dark:bg-white/[0.02]"
              )}
            >
              <div className="flex min-w-0 items-start gap-2.5">
                <span
                  className={cn(
                    "mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-xl transition",
                    product.storeVisible
                      ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-300"
                      : "bg-slate-500/10 text-slate-400"
                  )}
                >
                  <CatIcon name={product.storeVisible ? "circle-check" : "eye-off"} className="h-4.5 w-4.5" />
                </span>
                <div className="min-w-0">
                  <p className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                    {t("estoreVisibleToggle")}
                  </p>
                  <p className="mt-0.5 text-[11px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                    {t("estoreVisibleDesc")}
                  </p>
                </div>
              </div>
              <Switch
                checked={product.storeVisible}
                onCheckedChange={() => toggleVisible.mutate()}
                disabled={toggleVisible.isPending}
                aria-label={t("estoreVisibleToggle")}
                className="data-[state=checked]:bg-emerald-500"
              />
            </section>
          </div>
        ) : null}

        {error ? (
          <p role="alert" className="mt-3 rounded-xl bg-rose-500/10 px-3 py-2 text-[11.5px] font-bold text-rose-600 dark:text-rose-300">
            {error}
          </p>
        ) : null}

        <DialogFooter className="mt-5 gap-2">
          <Button type="button" variant="outline" onClick={close} className="h-10 rounded-xl px-4 text-[12px] font-bold">
            {t("dlgCancel")}
          </Button>
          <Button
            type="button"
            disabled={!mediaDirty || save.isPending}
            onClick={() => save.mutate()}
            className="h-10 gap-1.5 rounded-xl px-5 text-[12px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:opacity-50"
            style={{
              backgroundImage: grad("#6d5dfb", "#0ea5e9"),
              boxShadow: "0 10px 22px -10px rgba(109, 93, 251, 0.75)",
            }}
          >
            {save.isPending ? t("estoreMediaSave") + "…" : t("estoreMediaSave")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
