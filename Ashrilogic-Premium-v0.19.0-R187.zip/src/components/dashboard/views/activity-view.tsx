"use client";

/**
 * Dashboard — activity view (premium): a KPI strip (total / today / last
 * 7 days / most frequent kind), a search + kind-filter + CSV-export toolbar,
 * and a grouped vertical timeline (today / yesterday / earlier) of the
 * system events. ROUND 57 — the feed is KEYSET-PAGINATED (20 per page,
 * stable under concurrent writes) with a themed load-more control; the
 * "total" KPI is the server-wide count, not the loaded window.
 *
 * ROUND 136 — the KPI strip migrated onto the unified StatCard.
 * ROUND 139 — the strip now renders THE golden inventory-page card law
 * (size="golden" inside the exact inventory grid grid-cols-2 → md:grid-cols-3
 * → xl:grid-cols-5), expanded 4 → 5 KPIs: the THIS-MONTH calendar cohort joins
 * today/week so the golden 5-column grid fills exactly (the loaded window is
 * the honest denominator for every sub-line — the "total" headline stays the
 * server-wide count).
 */
import { useMemo, useState } from "react";
import { useInfiniteQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { useT, type I18nKey } from "@/lib/i18n";
import { t as tt } from "@/lib/i18n";
import type { ActivityDTO, ActivityKind, InstanceDTO, Lang } from "@/lib/types";
import { fetchActivitiesPage } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, normalizeSearch } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { StatCard } from "@/components/shared/stat-card";
import {
  ACT_STYLE,
  DashCard,
  ViewHeading,
  fullDate,
  relativeTime,
} from "@/components/dashboard/dash-shared";

/** Ordered activity kinds (ACT_STYLE keys double as i18n kind labels). */
const KINDS = Object.keys(ACT_STYLE) as ActivityKind[];

type KindFilter = "all" | ActivityKind;

type GroupKey = "today" | "yesterday" | "earlier";

const GROUP_LABEL: Record<GroupKey, I18nKey> = {
  today: "actGroupToday",
  yesterday: "actGroupYesterday",
  earlier: "actGroupEarlier",
};

/* ---------------- ROUND 70 — kind-mix strip (interactive analytics) ---------------- */

/** One kind row in the mix strip: icon tile + label + proportional bar.
 *  Clicking toggles the timeline's kind filter — a one-tap drill-down. */
function KindMixRow({
  kind,
  count,
  share,
  active,
  onClick,
  lang,
}: {
  kind: ActivityKind;
  count: number;
  share: number;
  active: boolean;
  onClick: () => void;
  lang: Lang;
}) {
  const style = ACT_STYLE[kind];
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "group/mix flex w-full items-center gap-3 rounded-xl px-2.5 py-2 text-start transition active:scale-[0.99]",
        active
          ? "bg-brand-500/10 ring-1 ring-brand-400/60 dark:bg-brand-500/15 dark:ring-brand-500/40"
          : "hover:bg-slate-100/70 dark:hover:bg-white/[0.05]"
      )}
    >
      <span
        className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-white shadow-sm transition-transform duration-200 group-hover/mix:scale-110"
        style={{ backgroundImage: grad(style.c1, style.c2) }}
        aria-hidden="true"
      >
        <CatIcon name={style.icon} className="h-3 w-3" />
      </span>
      <span className="min-w-0 flex-1">
        <span className="flex items-baseline justify-between gap-2">
          <span className="truncate text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200">
            {tt(lang, kind)}
          </span>
          <span className="shrink-0 text-[11px] font-extrabold tabular-nums text-slate-400 dark:text-slate-500">
            {fmtNum(count, lang)}
          </span>
        </span>
        <span className="mt-1.5 block h-1.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/[0.06]">
          <span
            className="block h-full rounded-full transition-[width] duration-500 ease-out"
            style={{ width: `${Math.max(share * 100, 3)}%`, backgroundImage: grad(style.c1, style.c2) }}
            aria-hidden="true"
          />
        </span>
      </span>
      {active ? (
        <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-brand-500/15 px-2 py-0.5 text-[9.5px] font-extrabold text-brand-600 dark:text-brand-300">
          <CatIcon name="check" className="h-2.5 w-2.5" />
        </span>
      ) : null}
    </button>
  );
}

/** 24-hour activity histogram — 12 two-hour buckets, gradient columns,
 *  peak bucket crowned + pulsing. Hour labels locale-aware (Arabic-Indic in AR). */
function HourHistogram({ events, lang }: { events: ActivityDTO[]; lang: Lang }) {
  const BUCKETS = 12;
  const bucketCounts = useMemo(() => {
    const arr = new Array<number>(BUCKETS).fill(0);
    for (const ev of events) {
      const h = new Date(ev.createdAt).getHours();
      arr[Math.floor(h / 2)] += 1;
    }
    return arr;
  }, [events]);
  const max = Math.max(...bucketCounts, 1);
  const peakIdx = bucketCounts.indexOf(Math.max(...bucketCounts));
  const hasData = events.length > 0;

  const hourLabel = (bucket: number) => {
    const h = bucket * 2;
    return `${fmtNum(h, lang)}–${fmtNum(h + 2, lang)}`;
  };

  if (!hasData) {
    return (
      <p className="py-6 text-center text-[11.5px] font-bold text-slate-400 dark:text-slate-500">
        {tt(lang, "actNoMixData")}
      </p>
    );
  }

  return (
    <div className="flex items-end gap-1.5 pt-1" role="img" aria-label={tt(lang, "actHotHoursDesc")}>
      {bucketCounts.map((count, i) => {
        const isPeak = i === peakIdx && count > 0;
        const ratio = count / max;
        return (
          <div key={i} className="group/hour flex min-w-0 flex-1 flex-col items-center gap-1.5">
            <span
              className={cn(
                "text-[9px] font-extrabold tabular-nums transition-opacity",
                isPeak ? "text-amber-600 dark:text-amber-400" : "text-slate-300 opacity-0 dark:text-slate-600"
              )}
            >
              {fmtNum(count, lang)}
            </span>
            <span
              className={cn(
                "w-full rounded-t-md transition-all duration-300 group-hover/hour:brightness-110",
                count === 0 && "bg-slate-100 dark:bg-white/[0.06]",
                isPeak && "animate-pulse"
              )}
              style={
                count > 0
                  ? {
                      height: `${Math.max(ratio * 56, 6)}px`,
                      backgroundImage: isPeak
                        ? grad("#f59e0b", "#d97706")
                        : grad("#6d5dfb", "#a855f7"),
                    }
                  : { height: "6px" }
              }
              title={`${hourLabel(i)} · ${fmtNum(count, lang)}`}
              aria-hidden="true"
            />
            <span className="text-[8.5px] font-bold tabular-nums text-slate-400 dark:text-slate-500" dir="ltr">
              {hourLabel(i)}
            </span>
          </div>
        );
      })}
    </div>
  );
}

/** Calendar-day bucket for the timeline groups. */
function dayBucket(iso: string): GroupKey {
  const at = new Date(iso);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  if (at >= today) return "today";
  if (at >= yesterday) return "yesterday";
  return "earlier";
}

/* ---------------- view ---------------- */

export function ActivityView({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();

  const [search, setSearch] = useState("");
  const [kindFilter, setKindFilter] = useState<KindFilter>("all");

  /* ROUND 57 — keyset pagination: pages are stable under concurrent
   * inserts (the cursor resumes strictly after the last seen row). The
   * server `total` powers the honest "total" KPI. */
  const PAGE_SIZE = 20;
  const feed = useInfiniteQuery({
    queryKey: ["activities-feed", instance.id, PAGE_SIZE],
    queryFn: ({ pageParam }) =>
      fetchActivitiesPage(instance.id, { limit: PAGE_SIZE, cursor: pageParam }),
    initialPageParam: null as string | null,
    getNextPageParam: (lastPage) => lastPage.nextCursor,
    staleTime: 15_000,
    retry: 0,
  });

  const query = feed;
  const events = useMemo(
    () => feed.data?.pages.flatMap((p) => p.activities) ?? [],
    [feed.data]
  );
  const serverTotal = feed.data?.pages[0]?.total ?? 0;

  /* KPI stats over the raw fetch — independent of the toolbar filters. */
  const stats = useMemo(() => {
    const list = events ?? [];
    const now = new Date();
    const todayStart = new Date(now);
    todayStart.setHours(0, 0, 0, 0);
    const weekStart = Date.now() - 7 * 86_400_000;
    /* ROUND 139 — the calendar-month cohort completes the golden time ladder */
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
    let today = 0;
    let week = 0;
    let month = 0;
    const counts = new Map<ActivityKind, number>();
    for (const ev of list) {
      const ts = new Date(ev.createdAt).getTime();
      if (ts >= todayStart.getTime()) today += 1;
      if (ts >= weekStart) week += 1;
      if (ts >= monthStart) month += 1;
      counts.set(ev.kind, (counts.get(ev.kind) ?? 0) + 1);
    }
    let peak: ActivityKind | null = null;
    let peakCount = 0;
    for (const [kind, count] of counts) {
      if (count > peakCount) {
        peak = kind;
        peakCount = count;
      }
    }
    return { total: list.length, today, week, month, peak, peakCount };
  }, [events]);

  /* Toolbar filtering: kind label + meta values (Arabic-safe normalization). */
  const normalizedQuery = normalizeSearch(search.trim());
  const filtered = useMemo(() => {
    let list = events ?? [];
    if (kindFilter !== "all") list = list.filter((ev) => ev.kind === kindFilter);
    if (normalizedQuery) {
      list = list.filter((ev) =>
        normalizeSearch([t(ev.kind), ...Object.values(ev.meta ?? {})].join(" ")).includes(normalizedQuery)
      );
    }
    return [...list].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }, [events, kindFilter, normalizedQuery, t]);

  /* Timeline groups (newest first) with their counts. */
  const groups = useMemo(() => {
    const buckets: Record<GroupKey, ActivityDTO[]> = { today: [], yesterday: [], earlier: [] };
    for (const ev of filtered) buckets[dayBucket(ev.createdAt)].push(ev);
    return (["today", "yesterday", "earlier"] as const)
      .filter((key) => buckets[key].length > 0)
      .map((key) => ({ key, label: t(GROUP_LABEL[key]), items: buckets[key] }));
  }, [filtered, t]);

  /* ROUND 70 — kind mix over the LOADED window (all kinds, independent of
   * the active filter) so the strip doubles as a live distribution snapshot;
   * clicking a row toggles the timeline's kind filter (drill-down). */
  const kindMix = useMemo(() => {
    const counts = new Map<ActivityKind, number>();
    for (const ev of events) counts.set(ev.kind, (counts.get(ev.kind) ?? 0) + 1);
    const total = events.length;
    return [...counts.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8)
      .map(([kind, count]) => ({ kind, count, share: total > 0 ? count / total : 0 }));
  }, [events]);

  const kindCount =
    kindFilter === "all" ? 0 : (events ?? []).filter((ev) => ev.kind === kindFilter).length;

  /* KPI strip renders through the unified StatCard: numeric count-up on
   * the three count KPIs (em-dash value only when the fetch failed),
   * small label-valued card for the peak kind.
   * ROUND 57 — the "total" KPI is the SERVER count (the loaded window
   * grows with load-more; the true total never shrinks with it). */

  /* Client-side CSV export of the filtered events (BOM + RFC-style quoting). */
  const exportCsv = () => {
    if (filtered.length === 0) return;
    const esc = (v: unknown) => {
      const s = String(v ?? "");
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const rows = [
      ["kind", "meta", "createdAt"],
      ...filtered.map((ev) => [
        ev.kind,
        ev.meta && Object.keys(ev.meta).length > 0 ? JSON.stringify(ev.meta) : "",
        ev.createdAt,
      ]),
    ];
    const csv = rows.map((r) => r.map(esc).join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "ashrilogic-activities.csv";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success(t("adminExportDone"));
  };

  return (
    <div className="space-y-5">
      <ViewHeading title={t("dashActivityTitle")} desc={t("dashActivityDesc")} />

      {/* KPI strip — ROUND 139: THE golden inventory-page cards
          (grid-cols-2 → md:grid-cols-3 → xl:grid-cols-5): numeric count-up
          on the count KPIs, emerald tone on "today" when it carries events. */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        <StatCard
          size="golden"
          label={t("actKpiTotal")}
          value={query.isError ? "—" : undefined}
          numeric={query.isError ? undefined : serverTotal}
          icon="activity"
          c1="#6d5dfb"
          c2="#8b5cf6"
          index={0}
          loading={query.isPending}
        />
        <StatCard
          size="golden"
          label={t("actKpiToday")}
          value={query.isError ? "—" : undefined}
          numeric={query.isError ? undefined : stats.today}
          icon="calendar-check"
          c1="#06b6d4"
          c2="#0891b2"
          index={1}
          tone={stats.today > 0 ? "up" : "flat"}
          loading={query.isPending}
        />
        <StatCard
          size="golden"
          label={t("actKpiWeek")}
          value={query.isError ? "—" : undefined}
          numeric={query.isError ? undefined : stats.week}
          icon="timer"
          c1="#d946ef"
          c2="#c026d3"
          index={2}
          loading={query.isPending}
        />
        <StatCard
          size="golden"
          label={t("actKpiMonth")}
          value={query.isError ? "—" : undefined}
          numeric={query.isError ? undefined : stats.month}
          sub={t("actKpiMonthSub", {
            pct: fmtNum(stats.total > 0 ? Math.round((stats.month / stats.total) * 100) : 0, lang),
          })}
          icon="calendar-days"
          c1="#10b981"
          c2="#059669"
          index={3}
          tone={stats.month > 0 ? "up" : undefined}
          loading={query.isPending}
        />
        <StatCard
          size="golden"
          label={t("actKpiPeak")}
          value={stats.peak ? t(stats.peak) : "—"}
          chip={
            stats.peak ? (
              <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2 py-0.5 text-[10.5px] font-extrabold text-amber-600 transition-transform duration-200 hover:scale-105 dark:bg-amber-500/10 dark:text-amber-400">
                × {fmtNum(stats.peakCount, lang)}
              </span>
            ) : null
          }
          icon="trending-up"
          c1="#f59e0b"
          c2="#d97706"
          index={4}
          loading={query.isPending}
        />
      </div>

      {/* ROUND 70 — analytics strip: interactive kind mix + peak-hours
          histogram, two premium cards side by side (stack on mobile). */}
      {query.isPending ? (
        <div className="grid gap-4 lg:grid-cols-2">
          <Skeleton className="h-64 rounded-3xl" />
          <Skeleton className="h-64 rounded-3xl" />
        </div>
      ) : !query.isError && events.length > 0 ? (
        <div className="grid gap-4 lg:grid-cols-2">
          <DashCard title={t("actMixTitle")} icon="chart-bar">
            <p className="-mt-2 mb-1 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
              {t("actMixDesc")}
            </p>
            <ul className="space-y-0.5">
              {kindMix.map(({ kind, count, share }) => (
                <li key={kind}>
                  <KindMixRow
                    kind={kind}
                    count={count}
                    share={share}
                    active={kindFilter === kind}
                    lang={lang}
                    onClick={() => setKindFilter(kindFilter === kind ? "all" : kind)}
                  />
                </li>
              ))}
            </ul>
          </DashCard>
          <DashCard title={t("actHotHours")} icon="clock">
            <p className="-mt-2 mb-2 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
              {t("actHotHoursDesc")}
            </p>
            <HourHistogram events={events} lang={lang} />
          </DashCard>
        </div>
      ) : null}

      {/* toolbar: search + kind filter + export */}
      <div className="glass-card card-in rounded-3xl p-4 sm:p-5">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
          <div className="relative min-w-0 flex-1">
            <CatIcon
              name="search"
              className="pointer-events-none absolute start-3.5 top-1/2 h-[13px] w-[13px] -translate-y-1/2 text-slate-400"
            />
            <Input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t("actSearchPh")}
              aria-label={t("actSearchPh")}
              className="h-11 rounded-xl border-slate-200 bg-slate-50/80 ps-10 pe-3 text-[12.5px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:placeholder:text-slate-500 dark:focus:bg-white/[0.07]"
            />
          </div>

          <Select value={kindFilter} onValueChange={(v) => setKindFilter(v as KindFilter)}>
            <SelectTrigger
              aria-label={t("actViewKind")}
              className="h-11 w-full rounded-xl border-slate-200 bg-slate-50/80 px-3.5 text-[12.5px] font-semibold text-slate-800 transition hover:border-brand-300 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:hover:border-brand-500/40 sm:w-56"
            >
              <span className="flex min-w-0 items-center gap-2">
                <CatIcon name="filter" className="h-3.5 w-3.5 shrink-0 text-slate-400" />
                <SelectValue />
              </span>
            </SelectTrigger>
            <SelectContent>
              <SelectGroup>
                <SelectItem value="all">{t("actFilterAll")}</SelectItem>
                {KINDS.map((kind) => (
                  <SelectItem key={kind} value={kind}>
                    {t(kind)}
                  </SelectItem>
                ))}
              </SelectGroup>
            </SelectContent>
          </Select>

          <Button
            type="button"
            variant="outline"
            onClick={exportCsv}
            disabled={filtered.length === 0}
            className="h-11 shrink-0 gap-2 rounded-xl border-slate-200 bg-white px-5 text-[12.5px] font-extrabold text-slate-700 shadow-none transition hover:border-brand-300 hover:text-brand-600 disabled:opacity-40 dark:border-white/10 dark:bg-transparent dark:text-slate-200 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
          >
            <CatIcon name="download" className="h-4 w-4" />
            {t("actExport")}
          </Button>
        </div>

        {/* active kind filter chip */}
        {kindFilter !== "all" ? (
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-brand-200 bg-brand-500/10 py-1 pe-1.5 ps-3 text-[11px] font-extrabold text-brand-700 dark:border-brand-500/30 dark:bg-brand-500/15 dark:text-brand-300">
              <CatIcon name="filter" className="h-3 w-3" />
              {t("actSelectedFilter")}: {t(kindFilter)}
              <span className="rounded-full bg-white/70 px-1.5 py-0.5 text-[10px] font-extrabold text-brand-600 dark:bg-white/10 dark:text-brand-300">
                {fmtNum(kindCount, lang)}
              </span>
              <button
                type="button"
                onClick={() => setKindFilter("all")}
                aria-label={t("actClearFilter")}
                title={t("actClearFilter")}
                className="grid h-6 w-6 place-items-center rounded-full text-brand-500 transition hover:bg-brand-500/20 hover:text-brand-700 dark:hover:text-brand-200"
              >
                <CatIcon name="x" className="h-3 w-3" />
              </button>
            </span>
          </div>
        ) : null}
      </div>

      {/* timeline */}
      <DashCard
        title={t("actTimeline")}
        icon="history"
        action={
          query.isError ? (
            <Button
              variant="outline"
              size="sm"
              onClick={() => query.refetch()}
              className="h-7 rounded-lg text-[11px] font-bold"
            >
              <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
              {t("retryText")}
            </Button>
          ) : !query.isPending && events && events.length > 0 ? (
            <Badge
              variant="secondary"
              className="rounded-full px-3 py-1 text-[11px] font-extrabold text-slate-600 dark:text-slate-300"
              title={t("actLoadedHint", { loaded: fmtNum(events.length, lang), total: fmtNum(serverTotal, lang) })}
            >
              {fmtNum(filtered.length, lang)} / {fmtNum(events.length, lang)}
            </Badge>
          ) : null
        }
      >
        {/* live count announcement for assistive tech */}
        <p className="sr-only" aria-live="polite">
          {t("actKpiTotal")}: {fmtNum(filtered.length, lang)}
        </p>

        {query.isPending ? (
          <div className="space-y-1" aria-hidden="true">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3 rounded-2xl p-3">
                <Skeleton className="h-10 w-10 rounded-xl" />
                <div className="flex-1 space-y-1.5">
                  <Skeleton className="h-3.5 w-44" />
                  <Skeleton className="h-2.5 w-28" />
                </div>
                <Skeleton className="h-2.5 w-20" />
              </div>
            ))}
          </div>
        ) : query.isError ? (
          <div className="py-10 text-center">
            <p className="text-[13px] font-bold text-rose-600 dark:text-rose-400">{t("errorText")}</p>
            <Button
              variant="outline"
              onClick={() => query.refetch()}
              className="mt-3 h-10 rounded-xl px-5 text-[12.5px] font-bold"
            >
              <CatIcon name="refresh-cw" className="h-4 w-4" />
              {t("retryText")}
            </Button>
          </div>
        ) : groups.length === 0 ? (
          <div className="py-12 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
              <CatIcon name="clock-rotate-left" className="h-6 w-6" />
            </div>
            <h3 className="mt-4 font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
              {t("actEmpty")}
            </h3>
            <p className="mx-auto mt-1 max-w-sm text-[12.5px] text-slate-500 dark:text-slate-400">
              {t("actEmptyDesc")}
            </p>
          </div>
        ) : (
          <div className="max-h-[600px] overflow-y-auto pe-1 [contain:content]" role="log" aria-label={t("actTimeline")}>
            {groups.map((group) => (
              <section key={group.key} aria-label={group.label}>
                {/* sticky group header */}
                <div className="sticky top-0 z-20 flex items-center gap-2 bg-white/85 px-1 py-2 backdrop-blur-sm dark:bg-[#101828]/90">
                  <h3 className="text-[10.5px] font-extrabold uppercase tracking-[0.12em] text-slate-400 dark:text-slate-500">
                    {group.label}
                  </h3>
                  <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-extrabold text-slate-500 dark:bg-white/10 dark:text-slate-400">
                    {fmtNum(group.items.length, lang)}
                  </span>
                  <span className="h-px flex-1 bg-slate-100 dark:bg-white/[0.06]" aria-hidden="true" />
                </div>

                <ol className="space-y-1 pb-2">
                  {group.items.map((ev, i) => {
                    const style = ACT_STYLE[ev.kind];
                    const last = i === group.items.length - 1;
                    return (
                      <li
                        key={ev.id}
                        className="relative flex gap-3 rounded-2xl p-3 transition hover:bg-slate-50 dark:hover:bg-white/5"
                      >
                        {/* vertical connector: this tile center → next tile center */}
                        {!last ? (
                          <span
                            aria-hidden="true"
                            className="absolute top-[32px] h-[calc(100%_+_4px)] w-0.5 bg-slate-200 start-[31px] dark:bg-white/10"
                          />
                        ) : null}
                        <span
                          className="relative grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white"
                          style={{ backgroundImage: grad(style.c1, style.c2) }}
                        >
                          <CatIcon name={style.icon} className="h-[13px] w-[13px]" />
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="text-[12.5px] font-bold text-slate-700 dark:text-slate-200">{t(ev.kind)}</p>
                          {ev.meta && Object.keys(ev.meta).length > 0 ? (
                            <div className="mt-1 flex flex-wrap gap-1.5">
                              {Object.entries(ev.meta).map(([k, v]) => {
                                /* ROUND 46 (F-7) — localized meta presentation:
                                   English keys become Arabic labels, and the
                                   bilingual plan identity picks the reader's
                                   language (package/packageAr pair). */
                                const metaKeys: Record<string, string> = {
                                  package: t("metaKeyPackage"),
                                  packageAr: t("metaKeyPackage"),
                                };
                                if (k === "packageAr" && lang === "en") return null;
                                if (k === "package" && lang === "ar" && ev.meta?.packageAr) return null;
                                const value =
                                  k === "package" && lang === "ar" && ev.meta?.packageAr
                                    ? ev.meta.packageAr
                                    : k === "packageAr" && lang === "en" && ev.meta?.package
                                      ? ev.meta.package
                                      : v;
                                return (
                                  <span
                                    key={k}
                                    className="rounded-full border border-slate-200 bg-slate-50 px-2 py-0.5 text-[10px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-400"
                                    dir="auto"
                                  >
                                    {metaKeys[k] ?? k}: {value}
                                  </span>
                                );
                              })}
                            </div>
                          ) : null}
                          <p
                            className="mt-1 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500"
                            dir="auto"
                          >
                            {fullDate(ev.createdAt, lang)} · {relativeTime(ev.createdAt, lang)}
                          </p>
                        </div>
                      </li>
                    );
                  })}
                </ol>
              </section>
            ))}

            {/* ROUND 57 — keyset load-more: stable under concurrent inserts */}
            {feed.hasNextPage ? (
              <div className="flex flex-col items-center gap-2 border-t border-dashed border-slate-200 pb-1 pt-4 dark:border-white/10">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => feed.fetchNextPage()}
                  disabled={feed.isFetchingNextPage}
                  className="h-10 gap-2 rounded-xl border-slate-200 bg-white px-6 text-[12.5px] font-extrabold text-slate-600 shadow-none transition hover:border-brand-300 hover:text-brand-600 active:scale-95 disabled:opacity-60 dark:border-white/10 dark:bg-transparent dark:text-slate-200 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
                >
                  <CatIcon
                    name="chevron-down"
                    className={cn("h-4 w-4 transition-transform", feed.isFetchingNextPage && "animate-bounce")}
                  />
                  {feed.isFetchingNextPage ? t("actLoadingMore") : t("actLoadMore")}
                </Button>
                <p className="text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                  {t("actLoadedHint", {
                    loaded: fmtNum(events.length, lang),
                    total: fmtNum(serverTotal, lang),
                  })}
                </p>
              </div>
            ) : events.length > 0 ? (
              <div className="flex items-center justify-center gap-2 border-t border-dashed border-slate-200 pt-3 dark:border-white/10">
                <span className="h-1.5 w-1.5 rounded-full bg-slate-300 dark:bg-white/20" aria-hidden="true" />
                <p className="text-[10.5px] font-extrabold text-slate-400 dark:text-slate-500">
                  {t("actEndOfFeed")}
                </p>
                <span className="h-1.5 w-1.5 rounded-full bg-slate-300 dark:bg-white/20" aria-hidden="true" />
              </div>
            ) : null}
          </div>
        )}
      </DashCard>
    </div>
  );
}
