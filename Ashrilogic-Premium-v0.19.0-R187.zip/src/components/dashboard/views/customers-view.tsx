"use client";

/**
 * Ashrilogic — dashboard "site customers" view (round 29).
 *
 * The owner's premium window onto the members registered through THEIR
 * public website: a 4-cell KPI strip (total / active / banned / inquiries),
 * a search box + status filter chips with counts, a premium desktop table
 * and mobile row cards (status-aware gradient avatars, LTR emails, phone +
 * inquiry chips, member-since / last-login with full-date tooltips) and real
 * moderation — ban / unban (cuts off live sessions server-side) and delete,
 * each behind a count-aware bilingual AlertDialog with an identity preview.
 * Arabic-first typography. When the instance has no website yet the view
 * degrades to a friendly pointer towards the website view.
 *
 * ROUND 136 — the KPI strip migrated onto the unified StatCard.
 * ROUND 139 — the strip now renders THE golden inventory-page card law
 * (size="golden" inside the exact inventory grid grid-cols-2 → md:grid-cols-3
 * → xl:grid-cols-5), expanded 4 → 5 KPIs: the UNVERIFIED cohort is promoted
 * to its own headline card (own drill-down into the unverified filter) so
 * the golden 5-column grid fills exactly — the R136-A inventory pattern.
 */
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { useT } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import type { InstanceDTO, SiteCustomerDTO } from "@/lib/types";
import {
  ApiError,
  deleteInstanceSiteCustomer,
  fetchInstanceSiteCustomers,
  setInstanceSiteCustomerStatus,
  verifyInstanceSiteCustomer,
} from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, copyText, fmtNum, grad, initial, labelTrack, normalizeSearch, numDir } from "@/lib/utils";
import { SiteInquiriesDialog } from "@/components/dashboard/views/site-inquiries-dialog";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { DashCard, ViewHeading, fullDate, relativeTime } from "@/components/dashboard/dash-shared";
import { StatCard } from "@/components/shared/stat-card";

type StatusFilter = "all" | "active" | "banned" | "unverified";

/* ---------------- status chip ---------------- */

function StatusChip({ banned }: { banned: boolean }) {
  const { t } = useT();
  return banned ? (
    <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-rose-300/60 bg-rose-500/10 px-2 py-0.5 text-[10px] font-extrabold text-rose-600 dark:border-rose-500/40 dark:text-rose-300">
      <CatIcon name="user-round-x" className="h-[9px] w-[9px]" />
      {t("siteCustStatusBanned")}
    </span>
  ) : (
    <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-emerald-300/60 bg-emerald-500/10 px-2 py-0.5 text-[10px] font-extrabold text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300">
      <CatIcon name="user-round-check" className="h-[9px] w-[9px]" />
      {t("siteCustStatusActive")}
    </span>
  );
}

/* ---------------- ROUND 75 — verification chip ---------------- */

/** The email's verification state on every customer row. VERIFIED renders
 *  as a static emerald chip; UNVERIFIED is an interactive amber button that
 *  opens the staff-assisted verify dialog (manual confirm / resend link) —
 *  the same clickable-chip pattern as the inquiries chip above. */
function VerifyChip({
  verified,
  onOpen,
}: {
  verified: boolean;
  onOpen?: () => void;
}) {
  const { t } = useT();
  if (verified) {
    return (
      <span
        title={t("siteCustVerifyHint")}
        className="inline-flex shrink-0 items-center gap-1 rounded-full border border-emerald-300/60 bg-emerald-500/10 px-2 py-0.5 text-[10px] font-extrabold text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
      >
        <CatIcon name="badge-check" className="h-[9px] w-[9px]" />
        {t("siteCustVerified")}
      </span>
    );
  }
  if (onOpen) {
    return (
      <button
        type="button"
        onClick={onOpen}
        title={t("siteCustVerifyBtnHint")}
        aria-label={`${t("siteCustVerifyBtnHint")} — ${t("siteCustUnverified")}`}
        className="inline-flex shrink-0 items-center gap-1 rounded-full border border-amber-300/70 bg-amber-500/10 px-2 py-0.5 text-[10px] font-extrabold text-amber-600 transition hover:bg-amber-500/20 hover:ring-2 hover:ring-amber-400/30 active:scale-95 dark:border-amber-500/40 dark:text-amber-300 dark:hover:bg-amber-500/25"
      >
        <CatIcon name="mail-warning" className="h-[9px] w-[9px]" />
        {t("siteCustUnverified")}
      </button>
    );
  }
  return (
    <span
      title={t("siteCustVerifyHint")}
      className="inline-flex shrink-0 items-center gap-1 rounded-full border border-amber-300/70 bg-amber-500/10 px-2 py-0.5 text-[10px] font-extrabold text-amber-600 dark:border-amber-500/40 dark:text-amber-300"
    >
      <CatIcon name="mail-warning" className="h-[9px] w-[9px]" />
      {t("siteCustUnverified")}
    </span>
  );
}

/* ---------------- inquiries chip ---------------- */

function InquiriesChip({
  count,
  onOpen,
}: {
  count: number;
  /** ROUND 74 — opens the triage dialog scoped to this customer. */
  onOpen?: () => void;
}) {
  const { t, lang } = useT();
  if (count <= 0) {
    return <span className="text-[11.5px] font-bold text-slate-300 dark:text-slate-600">—</span>;
  }
  if (onOpen) {
    return (
      <button
        type="button"
        onClick={onOpen}
        title={t("siteCustInquiriesHint")}
        aria-label={`${t("siteCustInquiriesHint")} — ${count}`}
        dir={numDir(lang)}
        className="inline-flex shrink-0 items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-extrabold tabular-nums text-slate-500 transition hover:bg-cyan-100 hover:text-cyan-700 active:scale-95 dark:bg-white/10 dark:text-slate-400 dark:hover:bg-cyan-500/20 dark:hover:text-cyan-300"
      >
        <CatIcon name="message-square" className="h-[9px] w-[9px]" />
        {fmtNum(count, lang)}
      </button>
    );
  }
  return (
    <span
      title={t("siteCustInquiriesHint")}
      dir={numDir(lang)}
      className="inline-flex shrink-0 items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-extrabold tabular-nums text-slate-500 dark:bg-white/10 dark:text-slate-400"
    >
      <CatIcon name="message-square" className="h-[9px] w-[9px]" />
      {fmtNum(count, lang)}
    </span>
  );
}

/* ---------------- row actions ---------------- */

function RowActions({
  customer,
  pending,
  onBanToggle,
  onDelete,
}: {
  customer: SiteCustomerDTO;
  pending: boolean;
  onBanToggle: (customer: SiteCustomerDTO) => void;
  onDelete: (customer: SiteCustomerDTO) => void;
}) {
  const { t } = useT();
  const banned = customer.status === "banned";
  return (
    <div className="inline-flex items-center gap-1.5">
      <button
        type="button"
        onClick={() => onBanToggle(customer)}
        disabled={pending}
        title={banned ? t("dcUnban") : t("dcBan")}
        className={cn(
          "inline-flex h-8 items-center gap-1.5 rounded-xl border px-2.5 text-[10.5px] font-extrabold transition active:scale-95 disabled:opacity-50",
          banned
            ? "border-emerald-200 bg-emerald-50 text-emerald-600 hover:bg-emerald-100 dark:border-emerald-500/25 dark:bg-emerald-500/10 dark:text-emerald-300 dark:hover:bg-emerald-500/20"
            : "border-rose-200 bg-rose-50 text-rose-600 hover:bg-rose-100 dark:border-rose-500/25 dark:bg-rose-500/10 dark:text-rose-300 dark:hover:bg-rose-500/20"
        )}
      >
        <CatIcon name={banned ? "user-round-check" : "user-round-x"} className="h-[12px] w-[12px]" />
        <span className="hidden xl:inline">{t(banned ? "dcUnban" : "dcBan")}</span>
      </button>
      <button
        type="button"
        onClick={() => onDelete(customer)}
        disabled={pending}
        title={t("dcDelete")}
        aria-label={`${t("dcDelete")} — ${customer.email}`}
        className="grid h-8 w-8 place-items-center rounded-xl border border-slate-200 text-slate-400 transition hover:border-rose-300 hover:text-rose-500 active:scale-95 disabled:opacity-50 dark:border-white/10 dark:text-slate-500 dark:hover:border-rose-500/40 dark:hover:text-rose-300"
      >
        <CatIcon name="trash-2" className="h-[12px] w-[12px]" />
      </button>
    </div>
  );
}

/* ---------------- view ---------------- */

export function CustomersView({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const setDashView = useAppStore((s) => s.setDashView);

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [pendingBan, setPendingBan] = useState<SiteCustomerDTO | null>(null);
  const [pendingDelete, setPendingDelete] = useState<SiteCustomerDTO | null>(null);
  /* ROUND 75 — staff-assisted email verification (confirm / re-dispatch) */
  const [pendingVerify, setPendingVerify] = useState<SiteCustomerDTO | null>(null);
  /* ROUND 74 — the triage dialog: `customer` null → ALL site inquiries,
     set → that customer's thread (opened from a row chip). */
  const [inqDialog, setInqDialog] = useState<{ open: boolean; customer: SiteCustomerDTO | null }>({
    open: false,
    customer: null,
  });

  const queryKey = ["instance-site-customers", instance.id] as const;
  const query = useQuery({
    queryKey,
    queryFn: () => fetchInstanceSiteCustomers(instance.id),
    staleTime: 10_000,
    retry: 1,
  });

  /* 404 from a loaded workspace = the instance has no website yet */
  const noSite = query.isError && query.error instanceof ApiError && query.error.status === 404;

  const customers = useMemo(() => query.data ?? [], [query.data]);
  /* ROUND 136 — verified / inquiry-thread cohorts feed the KPI sub-lines. */
  const counts = useMemo(
    () => ({
      total: customers.length,
      active: customers.filter((c) => c.status === "active").length,
      banned: customers.filter((c) => c.status === "banned").length,
      unverified: customers.filter((c) => !c.emailVerified).length,
      verified: customers.filter((c) => c.emailVerified).length,
      inquiryThreads: customers.filter((c) => c.inquiries > 0).length,
      inquiries: customers.reduce((sum, c) => sum + c.inquiries, 0),
    }),
    [customers]
  );
  /** KPI sub-line share: part of whole as a whole percentage (0 when empty). */
  const sharePct = (part: number, whole: number) => (whole > 0 ? Math.round((part / whole) * 100) : 0);

  const filtered = useMemo(() => {
    const q = normalizeSearch(search.trim());
    return customers.filter((c) => {
      if (statusFilter === "unverified" && c.emailVerified) return false;
      if (
        (statusFilter === "active" || statusFilter === "banned") &&
        c.status !== statusFilter
      )
        return false;
      if (!q) return true;
      return normalizeSearch(`${c.name} ${c.email} ${c.phone ?? ""}`).includes(q);
    });
  }, [customers, search, statusFilter]);

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey });
  };

  const banToggle = useMutation({
    mutationFn: (customer: SiteCustomerDTO) =>
      setInstanceSiteCustomerStatus(
        instance.id,
        customer.id,
        customer.status === "banned" ? "active" : "banned"
      ),
    onSuccess: (_data, customer) => {
      toast.success(
        t(customer.status === "banned" ? "dcUnbannedToast" : "dcBannedToast", { name: customer.name })
      );
      setPendingBan(null);
      invalidate();
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  const remove = useMutation({
    mutationFn: (customer: SiteCustomerDTO) => deleteInstanceSiteCustomer(instance.id, customer.id),
    onSuccess: (_data, customer) => {
      toast.success(t("dcDeletedToast", { name: customer.name }));
      setPendingDelete(null);
      invalidate();
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  /* ROUND 75 — staff-assisted verification: `verify` marks the address
   * confirmed on the customer's behalf (identity checked out-of-band);
   * `resendVerify` re-dispatches the single-use link through the mailer. */
  const verifyAction = useMutation({
    mutationFn: ({ customer, action }: { customer: SiteCustomerDTO; action: "verify" | "resendVerify" }) =>
      verifyInstanceSiteCustomer(instance.id, customer.id, action),
    onSuccess: (_data, { action }) => {
      toast.success(t(action === "verify" ? "siteCustVerifyDone" : "siteCustResendDone"));
      if (action === "verify") setPendingVerify(null);
      invalidate();
    },
    onError: (error: Error) => {
      const code = (error as { code?: string }).code;
      toast.error(
        code === "RESEND_COOLDOWN" ? t("acctVerifyWaitToast") : t("siteCustVerifyFail")
      );
    },
  });

  const pending = banToggle.isPending || remove.isPending || verifyAction.isPending;

  const copyEmail = (customer: SiteCustomerDTO) => {
    copyText(customer.email).then(
      () => toast.success(t("toastCopied")),
      () => toast.error(t("errorText"))
    );
  };

  const filtersActive = search.trim().length > 0 || statusFilter !== "all";
  const clearFilters = () => {
    setSearch("");
    setStatusFilter("all");
  };

  const chips: { key: StatusFilter; label: string; count: number }[] = [
    { key: "all", label: t("dcFilterAll"), count: counts.total },
    { key: "active", label: t("dcFilterActive"), count: counts.active },
    /* ROUND 75 — the unverified cohort is its own filter (amber accent) */
    { key: "unverified", label: t("siteCustFilterUnverified"), count: counts.unverified },
    { key: "banned", label: t("dcFilterBanned"), count: counts.banned },
  ];

  /* ---------------- no website yet ---------------- */

  if (noSite) {
    return (
      <div className="space-y-5">
        <ViewHeading title={t("dashCustomers")} desc={t("dashCustomersDesc")} />
        <div className="glass-card card-in rounded-3xl px-6 py-16 text-center">
          <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-brand-500/10 text-brand-500 dark:bg-brand-500/15 dark:text-brand-300">
            <CatIcon name="globe" className="h-7 w-7" />
          </div>
          <h2 className="mt-5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
            {t("dcNoSite")}
          </h2>
          <p className="mx-auto mt-1.5 max-w-sm text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
            {t("dcNoSiteDesc")}
          </p>
          <button
            type="button"
            onClick={() => setDashView("website")}
            className="mt-6 inline-flex h-11 items-center gap-2 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-6 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
          >
            <CatIcon name="globe" className="h-4 w-4" />
            {t("dcGoWebsite")}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <ViewHeading title={t("dashCustomers")} desc={t("dashCustomersDesc")} />

      {/* ROUND 139 — KPI strip on THE golden inventory-page cards
          (grid-cols-2 → md:grid-cols-3 → xl:grid-cols-5): count-up numerals
          + context sub-lines + skeleton-while-pending. The R74 drill-down is
          preserved on ALL five cards — total / active / banned / unverified
          set their status filter, inquiries opens the triage inbox. */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        <StatCard
          size="golden"
          label={t("dcKpiTotal")}
          numeric={counts.total}
          sub={t("siteCustKpiTotalSub", { pct: fmtNum(sharePct(counts.verified, counts.total), lang) })}
          icon="users-round"
          c1="#10b981"
          c2="#059669"
          index={0}
          tone="up"
          loading={query.isPending}
          onClick={() => setStatusFilter("all")}
          hint={t("siteCustKpiTotalHint")}
        />
        <StatCard
          size="golden"
          label={t("dcKpiActive")}
          numeric={counts.active}
          sub={t("siteCustKpiActiveSub", { pct: fmtNum(sharePct(counts.active, counts.total), lang) })}
          icon="user-round-check"
          c1="#0ea5e9"
          c2="#0284c7"
          index={1}
          tone="up"
          loading={query.isPending}
          onClick={() => setStatusFilter("active")}
          hint={t("siteCustKpiActiveHint")}
        />
        <StatCard
          size="golden"
          label={t("dcKpiBanned")}
          numeric={counts.banned}
          sub={t("siteCustKpiBannedSub")}
          icon="user-round-x"
          c1="#f43f5e"
          c2="#e11d48"
          index={2}
          tone="down"
          loading={query.isPending}
          onClick={() => setStatusFilter("banned")}
          hint={t("siteCustKpiBannedHint")}
        />
        <StatCard
          size="golden"
          label={t("dcKpiUnverified")}
          numeric={counts.unverified}
          sub={t("siteCustKpiActiveSub", { pct: fmtNum(sharePct(counts.unverified, counts.total), lang) })}
          icon="mail-warning"
          c1="#f59e0b"
          c2="#d97706"
          index={3}
          tone="down"
          loading={query.isPending}
          onClick={() => setStatusFilter("unverified")}
          hint={t("siteCustKpiUnverifiedHint")}
        />
        <StatCard
          size="golden"
          label={t("dcKpiInquiries")}
          numeric={counts.inquiries}
          sub={t("siteCustKpiInqSub", { count: fmtNum(counts.inquiryThreads, lang) })}
          icon="message-square"
          c1="#8b5cf6"
          c2="#7c3aed"
          index={4}
          loading={query.isPending}
          onClick={() => setInqDialog({ open: true, customer: null })}
          hint={t("siteInqOpenBtnHint")}
        />
      </div>

      {/* customers table */}
      <DashCard title={t("dashCustomers")} icon="users-round">
        {/* toolbar: search + status filter chips + count */}
        <div className="mb-4 flex flex-col gap-3">
          <div className="relative min-w-0 flex-1">
            <CatIcon
              name="search"
              className="pointer-events-none absolute start-3.5 top-1/2 h-[13px] w-[13px] -translate-y-1/2 text-slate-400"
            />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t("dcSearchPh")}
              aria-label={t("dcSearchPh")}
              className="h-11 w-full rounded-xl border border-slate-200 bg-slate-50/80 ps-10 pe-10 text-[12.5px] font-semibold text-slate-800 outline-none transition placeholder:font-normal placeholder:text-slate-400 focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:placeholder:text-slate-500 dark:focus:bg-white/[0.07]"
            />
            {search ? (
              <button
                type="button"
                onClick={() => setSearch("")}
                aria-label={t("dcSearchPh")}
                title={t("dcSearchPh")}
                className="absolute end-2.5 top-1/2 grid h-7 w-7 -translate-y-1/2 place-items-center rounded-full text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-white/10 dark:hover:text-slate-300"
              >
                <CatIcon name="x" className="h-3.5 w-3.5" />
              </button>
            ) : null}
          </div>

          {/* round 35 — mobile-first touch targets: 40px-tall chips on phones,
              back to the compact 36px rhythm from sm up */}
          <div className="flex flex-wrap items-center gap-2">
            {chips.map((chip) => (
              <button
                key={chip.key}
                type="button"
                onClick={() => setStatusFilter(chip.key)}
                aria-pressed={statusFilter === chip.key}
                className={cn(
                  "inline-flex h-10 items-center gap-1.5 rounded-full border px-4 text-[11.5px] font-extrabold transition active:scale-95 sm:h-9 sm:px-3.5",
                  statusFilter === chip.key
                    ? chip.key === "banned"
                      ? "border-rose-300 bg-rose-500/10 text-rose-600 dark:border-rose-500/40 dark:text-rose-300"
                      : chip.key === "unverified"
                        ? "border-amber-300 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300"
                        : "border-brand-300 bg-brand-500/10 text-brand-600 dark:border-brand-500/40 dark:text-brand-300"
                    : "border-slate-200 bg-white/60 text-slate-500 hover:border-slate-300 hover:text-slate-700 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-400 dark:hover:text-slate-200"
                )}
              >
                {chip.label}
                <span
                  dir={numDir(lang)}
                  className="rounded-full bg-slate-100 px-1.5 py-px text-[10px] font-extrabold tabular-nums text-slate-500 dark:bg-white/10 dark:text-slate-400"
                >
                  {fmtNum(chip.count, lang)}
                </span>
              </button>
            ))}
            {/* ROUND 74 — the triage inbox entry (all inquiries) */}
            <button
              type="button"
              onClick={() => setInqDialog({ open: true, customer: null })}
              title={t("siteInqOpenBtnHint")}
              className="ms-auto inline-flex h-10 items-center gap-1.5 rounded-full border border-cyan-300/70 bg-cyan-500/10 px-4 text-[11.5px] font-extrabold text-cyan-700 transition hover:bg-cyan-500/20 active:scale-95 sm:h-9 sm:px-3.5 dark:border-cyan-500/40 dark:bg-cyan-500/[0.12] dark:text-cyan-300 dark:hover:bg-cyan-500/25"
            >
              <CatIcon name="message-square" className="h-[13px] w-[13px]" />
              {t("siteInqOpenBtn")}
              {counts.inquiries > 0 ? (
                <span
                  dir={numDir(lang)}
                  className="rounded-full bg-cyan-500/20 px-1.5 py-px text-[10px] font-extrabold tabular-nums text-cyan-700 dark:text-cyan-200"
                >
                  {fmtNum(counts.inquiries, lang)}
                </span>
              ) : null}
            </button>
            {filtersActive ? (
              <span dir={numDir(lang)} className={cn("text-[10.5px] font-bold text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                {fmtNum(filtered.length, lang)} / {fmtNum(customers.length, lang)}
              </span>
            ) : null}
          </div>
        </div>

        {query.isPending ? (
          /* skeletons — table shape on desktop, cards on mobile */
          <>
            <div className="hidden space-y-2 md:block">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-14 w-full rounded-xl" />
              ))}
            </div>
            <div className="space-y-2.5 md:hidden">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-28 w-full rounded-2xl" />
              ))}
            </div>
          </>
        ) : query.isError ? (
          <div className="py-12 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-rose-100 text-rose-500 dark:bg-rose-500/10 dark:text-rose-300">
              <CatIcon name="circle-alert" className="h-6 w-6" />
            </div>
            <p className="mt-3 font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("errorText")}
            </p>
            <button
              type="button"
              onClick={() => query.refetch()}
              className="mt-5 inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 px-5 text-[12.5px] font-bold transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10"
            >
              <CatIcon name="refresh-cw" className="h-4 w-4" />
              {t("retryText")}
            </button>
          </div>
        ) : customers.length === 0 ? (
          <div className="py-12 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
              <CatIcon name="users-round" className="h-6 w-6" />
            </div>
            <h3 className="mt-4 font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
              {t("dcEmpty")}
            </h3>
            <p className="mx-auto mt-1 max-w-sm text-[12.5px] text-slate-500 dark:text-slate-400">
              {t("dcEmptyDesc")}
            </p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="py-12 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
              <CatIcon name="search" className="h-6 w-6" />
            </div>
            <h3 className="mt-4 font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
              {t("dcNoMatch")}
            </h3>
            {filtersActive ? (
              <button
                type="button"
                onClick={clearFilters}
                className="mt-4 inline-flex h-9 items-center gap-1.5 rounded-lg px-3 text-[11.5px] font-bold text-brand-600 transition hover:text-brand-700 active:scale-95 dark:text-brand-300"
              >
                <CatIcon name="x" className="h-3.5 w-3.5" />
                {t("dcFilterAll")}
              </button>
            ) : null}
          </div>
        ) : (
          <>
            {/* desktop table */}
            <div className="hidden overflow-x-auto md:block">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-200/70 dark:border-white/10">
                    {[
                      t("dcColName"),
                      t("dcColEmail"),
                      t("dcColPhone"),
                      t("dcColInquiries"),
                      t("dcColSince"),
                      t("dcColLastLogin"),
                    ].map((label) => (
                      <TableHead
                        key={label}
                        className={cn(
                          "whitespace-nowrap text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500",
                          labelTrack(lang)
                        )}
                      >
                        {label}
                      </TableHead>
                    ))}
                    <TableHead className="text-end text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                      {t("dcColActions")}
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((customer) => {
                    const banned = customer.status === "banned";
                    return (
                      <TableRow
                        key={customer.id}
                        className={cn(
                          "border-slate-200/60 dark:border-white/[0.07]",
                          banned && "bg-rose-50/40 hover:bg-rose-50/60 dark:bg-rose-500/[0.05] dark:hover:bg-rose-500/[0.08]"
                        )}
                      >
                        {/* customer — status-aware gradient avatar + name */}
                        <TableCell>
                          <div className="flex items-center gap-2.5">
                            <span
                              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-[12px] font-extrabold text-white"
                              style={{
                                backgroundImage: banned
                                  ? grad("#f43f5e", "#e11d48")
                                  : grad("#8b5cf6", "#d946ef"),
                              }}
                              aria-hidden="true"
                            >
                              {initial(customer.name)}
                            </span>
                            <div className="min-w-0">
                              <p className="flex items-center gap-1.5">
                                <span
                                  className={cn(
                                    "max-w-[180px] truncate text-[12.5px] font-bold text-slate-700 dark:text-slate-200",
                                    banned && "line-through decoration-rose-400/70 decoration-2"
                                  )}
                                >
                                  {customer.name}
                                </span>
                                <StatusChip banned={banned} />
                                {/* ROUND 75 — email verification state (amber
                                    opens the staff-assisted dialog) */}
                                <VerifyChip
                                  verified={customer.emailVerified}
                                  onOpen={
                                    customer.emailVerified
                                      ? undefined
                                      : () => setPendingVerify(customer)
                                  }
                                />
                              </p>
                            </div>
                          </div>
                        </TableCell>
                        {/* email — always LTR */}
                        <TableCell>
                          <span className="inline-flex items-center gap-1.5">
                            <span
                              dir="ltr"
                              className={cn(
                                "max-w-[220px] truncate text-[12px] font-semibold text-slate-500 dark:text-slate-400",
                                lang === "ar" ? "text-end" : "text-start"
                              )}
                            >
                              {customer.email}
                            </span>
                            <button
                              type="button"
                              onClick={() => copyEmail(customer)}
                              aria-label={t("teamCopyEmail")}
                              title={t("teamCopyEmail")}
                              className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-brand-600 dark:hover:bg-white/10 dark:hover:text-brand-300"
                            >
                              <CatIcon name="copy" className="h-3 w-3" />
                            </button>
                          </span>
                        </TableCell>
                        {/* phone */}
                        <TableCell>
                          {customer.phone ? (
                            <span
                              dir="ltr"
                              className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 text-[11px] font-bold text-slate-500 dark:bg-white/10 dark:text-slate-400"
                            >
                              <CatIcon name="phone" className="h-[9px] w-[9px]" />
                              {customer.phone}
                            </span>
                          ) : (
                            <span className="text-[11.5px] font-bold text-slate-300 dark:text-slate-600">—</span>
                          )}
                        </TableCell>
                        {/* inquiries */}
                        <TableCell>
                          <InquiriesChip
                            count={customer.inquiries}
                            onOpen={() => setInqDialog({ open: true, customer })}
                          />
                        </TableCell>
                        {/* member since */}
                        <TableCell className="whitespace-nowrap">
                          <span
                            title={fullDate(customer.createdAt, lang)}
                            className="text-[11.5px] font-bold text-slate-600 dark:text-slate-300"
                          >
                            {relativeTime(customer.createdAt, lang)}
                          </span>
                        </TableCell>
                        {/* last login */}
                        <TableCell className="whitespace-nowrap">
                          {customer.lastLoginAt ? (
                            <span
                              title={fullDate(customer.lastLoginAt, lang)}
                              className="text-[11.5px] font-bold text-slate-600 dark:text-slate-300"
                            >
                              {relativeTime(customer.lastLoginAt, lang)}
                            </span>
                          ) : (
                            <span className="text-[11px] font-semibold italic text-slate-400 dark:text-slate-500">
                              {t("dcNeverLogin")}
                            </span>
                          )}
                        </TableCell>
                        {/* actions */}
                        <TableCell className="text-end">
                          <RowActions
                            customer={customer}
                            pending={pending}
                            onBanToggle={setPendingBan}
                            onDelete={setPendingDelete}
                          />
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>

            {/* mobile row cards */}
            <ul className="space-y-2.5 md:hidden">
              {filtered.map((customer) => {
                const banned = customer.status === "banned";
                return (
                  <li
                    key={customer.id}
                    className={cn(
                      "rounded-2xl border p-3.5 transition",
                      banned
                        ? "border-rose-200/80 bg-rose-50/50 dark:border-rose-500/20 dark:bg-rose-500/[0.06]"
                        : "border-slate-200/70 bg-white/60 dark:border-white/[0.07] dark:bg-white/[0.03]"
                    )}
                  >
                    <div className="flex items-start gap-3">
                      {/* avatar tile — status-aware gradient */}
                      <span
                        className="grid h-10 w-10 shrink-0 place-items-center rounded-xl font-display text-[14px] font-extrabold text-white"
                        style={{
                          backgroundImage: banned
                            ? grad("#f43f5e", "#e11d48")
                            : grad("#8b5cf6", "#d946ef"),
                        }}
                        aria-hidden="true"
                      >
                        {initial(customer.name)}
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                          <p
                            className={cn(
                              "truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100",
                              banned && "line-through decoration-rose-400/70 decoration-2"
                            )}
                          >
                            {customer.name}
                          </p>
                          <StatusChip banned={banned} />
                          <VerifyChip
                            verified={customer.emailVerified}
                            onOpen={
                              customer.emailVerified
                                ? undefined
                                : () => setPendingVerify(customer)
                            }
                          />
                          <InquiriesChip
                            count={customer.inquiries}
                            onOpen={() => setInqDialog({ open: true, customer })}
                          />
                        </div>
                        <p
                          dir="ltr"
                          className={cn(
                            "mt-0.5 truncate text-[11.5px] font-semibold text-slate-500 dark:text-slate-400",
                            lang === "ar" ? "text-end" : "text-start"
                          )}
                        >
                          {customer.email}
                        </p>
                        <div className="mt-1.5 flex flex-wrap items-center gap-x-2.5 gap-y-0.5 text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                          {customer.phone ? (
                            <span dir="ltr" className="inline-flex items-center gap-1">
                              <CatIcon name="phone" className="h-[9px] w-[9px]" />
                              {customer.phone}
                            </span>
                          ) : null}
                          <span title={fullDate(customer.createdAt, lang)}>
                            {t("dcColSince")} {relativeTime(customer.createdAt, lang)}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span
                            title={customer.lastLoginAt ? fullDate(customer.lastLoginAt, lang) : t("dcNeverLogin")}
                            className={cn(!customer.lastLoginAt && "italic")}
                          >
                            {customer.lastLoginAt
                              ? `${t("dcColLastLogin")} ${relativeTime(customer.lastLoginAt, lang)}`
                              : t("dcNeverLogin")}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="mt-3 flex justify-end border-t border-slate-100 pt-3 dark:border-white/[0.06]">
                      <RowActions
                        customer={customer}
                        pending={pending}
                        onBanToggle={setPendingBan}
                        onDelete={setPendingDelete}
                      />
                    </div>
                  </li>
                );
              })}
            </ul>
          </>
        )}
      </DashCard>

      {/* ban / unban confirm */}
      <AlertDialog open={pendingBan !== null} onOpenChange={(o) => !o && setPendingBan(null)}>
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className={cn(
                  "grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg",
                  pendingBan?.status === "banned"
                    ? "bg-linear-to-br from-emerald-500 to-emerald-600 shadow-emerald-500/25"
                    : "bg-linear-to-br from-rose-500 to-rose-600 shadow-rose-500/25"
                )}
                aria-hidden="true"
              >
                <CatIcon
                  name={pendingBan?.status === "banned" ? "user-round-check" : "user-round-x"}
                  className="h-[15px] w-[15px]"
                />
              </span>
              {pendingBan?.status === "banned" ? t("dcUnban") : t("dcBanTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {pendingBan?.status === "banned"
                ? t("dcUnbanMsg", { name: pendingBan?.name ?? "" })
                : t("dcBanMsg", { name: pendingBan?.name ?? "" })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          {pendingBan ? (
            <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50/60 p-3 dark:border-white/15 dark:bg-white/[0.03]">
              <div className="flex items-center gap-2.5">
                <span
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-[12px] font-extrabold text-white"
                  style={{
                    backgroundImage:
                      pendingBan.status === "banned" ? grad("#10b981", "#059669") : grad("#8b5cf6", "#d946ef"),
                  }}
                  aria-hidden="true"
                >
                  {initial(pendingBan.name)}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[12.5px] font-extrabold text-slate-700 dark:text-slate-200">
                    {pendingBan.name}
                  </p>
                  <p dir="ltr" className="truncate text-end font-mono text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                    {pendingBan.email}
                  </p>
                </div>
                <InquiriesChip count={pendingBan.inquiries} />
              </div>
            </div>
          ) : null}
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={pending}>
              {t("dcCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => pendingBan && banToggle.mutate(pendingBan)}
              disabled={pending}
              className={cn(
                "h-10 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition active:scale-95 disabled:opacity-60",
                pendingBan?.status === "banned"
                  ? "bg-emerald-600 shadow-emerald-500/25 hover:bg-emerald-700"
                  : "bg-rose-600 shadow-rose-500/25 hover:bg-rose-700"
              )}
            >
              {banToggle.isPending ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : null}
              {t("dcConfirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* delete confirm */}
      <AlertDialog open={pendingDelete !== null} onOpenChange={(o) => !o && setPendingDelete(null)}>
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-linear-to-br from-slate-600 to-slate-700 text-white shadow-lg shadow-slate-500/25" aria-hidden="true">
                <CatIcon name="trash-2" className="h-[15px] w-[15px]" />
              </span>
              {t("dcDeleteTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("dcDeleteMsg", { name: pendingDelete?.name ?? "" })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          {pendingDelete ? (
            <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50/60 p-3 dark:border-white/15 dark:bg-white/[0.03]">
              <div className="flex items-center gap-2.5">
                <span
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-[12px] font-extrabold text-white"
                  style={{ backgroundImage: grad("#8b5cf6", "#d946ef") }}
                  aria-hidden="true"
                >
                  {initial(pendingDelete.name)}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[12.5px] font-extrabold text-slate-700 dark:text-slate-200">
                    {pendingDelete.name}
                  </p>
                  <p dir="ltr" className="truncate text-end font-mono text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                    {pendingDelete.email}
                  </p>
                </div>
                <InquiriesChip count={pendingDelete.inquiries} />
              </div>
            </div>
          ) : null}
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={pending}>
              {t("dcCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => pendingDelete && remove.mutate(pendingDelete)}
              disabled={pending}
              className="h-10 rounded-xl bg-rose-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60"
            >
              {remove.isPending ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : null}
              {t("dcDelete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ROUND 75 — staff-assisted email verification (two paths: re-dispatch
          the single-use link, or confirm manually when the identity was
          checked out-of-band — phone / in person) */}
      <AlertDialog open={pendingVerify !== null} onOpenChange={(o) => !o && setPendingVerify(null)}>
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-linear-to-br from-amber-500 to-orange-500 text-white shadow-lg shadow-amber-500/25"
                aria-hidden="true"
              >
                <CatIcon name="mail-warning" className="h-[15px] w-[15px]" />
              </span>
              {t("siteCustVerifyTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("siteCustVerifyDesc", { name: pendingVerify?.name ?? "" })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          {pendingVerify ? (
            <div className="rounded-xl border border-dashed border-amber-300 bg-amber-50/50 p-3 dark:border-amber-500/30 dark:bg-amber-500/[0.06]">
              <div className="flex items-center gap-2.5">
                <span
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-linear-to-br from-amber-400 to-orange-500 text-[12px] font-extrabold text-white"
                  aria-hidden="true"
                >
                  {initial(pendingVerify.name)}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[12.5px] font-extrabold text-slate-700 dark:text-slate-200">
                    {pendingVerify.name}
                  </p>
                  <p dir="ltr" className="truncate text-end font-mono text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                    {pendingVerify.email}
                  </p>
                </div>
                <VerifyChip verified={pendingVerify.emailVerified} />
              </div>
            </div>
          ) : null}
          <AlertDialogFooter className="flex-col gap-2 sm:flex-row sm:items-center">
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={pending}>
              {t("dcCancel")}
            </AlertDialogCancel>
            <div className="flex flex-1 flex-col-reverse gap-2 sm:flex-row sm:justify-end">
              {/* re-dispatch the single-use verification email (rotates the
                  token — the previous link dies instantly) */}
              <button
                type="button"
                onClick={() =>
                  pendingVerify &&
                  verifyAction.mutate({ customer: pendingVerify, action: "resendVerify" })
                }
                disabled={pending}
                className="inline-flex h-10 items-center justify-center gap-1.5 rounded-xl border border-amber-300 bg-amber-50 px-5 text-[12.5px] font-extrabold text-amber-700 shadow-sm transition hover:bg-amber-100 active:scale-95 disabled:opacity-60 dark:border-amber-500/40 dark:bg-amber-500/10 dark:text-amber-300 dark:hover:bg-amber-500/20"
              >
                <CatIcon name="send" className="h-4 w-4" />
                {t("siteCustVerifyResend")}
              </button>
              {/* confirm on the customer's behalf (identity verified via a
                  trusted channel — banks' in-person pattern) */}
              <button
                type="button"
                onClick={() =>
                  pendingVerify && verifyAction.mutate({ customer: pendingVerify, action: "verify" })
                }
                disabled={pending}
                className="inline-flex h-10 items-center justify-center gap-1.5 rounded-xl bg-linear-to-r from-amber-500 to-orange-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-amber-500/30 transition hover:brightness-105 active:scale-95 disabled:opacity-60"
              >
                <CatIcon
                  name={verifyAction.isPending ? "refresh-cw" : "badge-check"}
                  className={cn("h-4 w-4", verifyAction.isPending && "animate-spin")}
                />
                {t("siteCustVerifyManual")}
              </button>
            </div>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ROUND 74 — the owner's inquiry triage dialog (all / per-customer) */}
      <SiteInquiriesDialog
        open={inqDialog.open}
        onOpenChange={(open) => setInqDialog((prev) => ({ ...prev, open }))}
        instanceId={instance.id}
        customer={inqDialog.customer}
      />
    </div>
  );
}

export default CustomersView;
