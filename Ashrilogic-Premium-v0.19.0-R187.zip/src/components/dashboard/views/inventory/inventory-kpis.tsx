"use client";

/**
 * Ashrilogic — inventory KPI strip (ROUND 136 — the unified golden StatCard).
 *
 * المهمة (R136): «بطاقات إحصائيات المخزون = نفس البطاقات الموحدة المعتمدة
 * في نقاط البيع والمنتجات وباقي الوحدات» — this strip now renders THE
 * shared StatCard (src/components/shared/stat-card.tsx) at size="golden"
 * inside the exact business-suite grid (grid-cols-2 → md:grid-cols-3 →
 * xl:grid-cols-5), so the inventory page's stat cards are structurally
 * identical to every commerce module (POS / products / all 93 presets):
 * compact glass card, corner radial aura, inline label icon, 17px display
 * value, tone-colored hover underline.
 *
 * Five KPIs (expanded from four so the golden 5-column grid fills exactly):
 *   1. إجمالي الأصناف (SKUs)      — sub: units on hand
 *   2. إجمالي الوحدات (units)     — NEW headline KPI (it was previously
 *                                    buried in card 1's sub-line) — sub:
 *                                    avg units per item
 *   3. قيمة المخزون (Σ qty×unit)  — sub: avg unit cost (invMoney)
 *   4. أصناف منخفضة (amber, tone="down") — sub: % of all items
 *   5. أصناف نافدة (rose, tone="down")   — sub: % of all items
 *
 * Numerals (project law): stats/money through fmtNum / invMoney
 * (Arabic-Indic for ar); StatCard applies the value direction (numDir) +
 * tabular truncation. No IDs on this surface.
 * `loading` → the StatCard golden skeleton while the records query loads.
 */
import { StatCard, type StatTone } from "@/components/shared/stat-card";
import { useT } from "@/lib/i18n";
import type { InstanceDTO } from "@/lib/types";
import type { InvStats } from "@/lib/inventory-data";
import { fmtNum } from "@/lib/utils";
import { invMoney } from "./inv-shared";

type InvKpiKey =
  | "invKpiItems"
  | "invKpiUnits"
  | "invKpiValue"
  | "invKpiLow"
  | "invKpiOut";

interface InvKpi {
  key: InvKpiKey;
  value: string;
  sub: string;
  icon: string;
  c1: string;
  c2: string;
  tone?: StatTone;
}

export function InventoryKpis({
  stats,
  currency,
  loading = false,
}: {
  stats: InvStats;
  currency: InstanceDTO["org"]["currency"];
  /** true while the underlying module-records query is still loading */
  loading?: boolean;
}) {
  const { t, lang } = useT();

  /* avg units per item — the natural companion stat for the units KPI */
  const avgUnits = stats.skuCount > 0 ? Math.round(stats.totalUnits / stats.skuCount) : 0;

  const kpis: InvKpi[] = [
    {
      key: "invKpiItems",
      value: fmtNum(stats.skuCount, lang),
      sub: t("invKpiUnitsSub", { count: fmtNum(stats.totalUnits, lang) }),
      icon: "boxes",
      c1: "#6d5dfb",
      c2: "#a855f7",
    },
    {
      key: "invKpiUnits",
      value: fmtNum(stats.totalUnits, lang),
      sub: t("invKpiAvgUnitsSub", { avg: fmtNum(avgUnits, lang) }),
      icon: "layers",
      c1: "#10b981",
      c2: "#059669",
    },
    {
      key: "invKpiValue",
      value: invMoney(stats.totalValue, currency, lang),
      sub: t("invKpiAvgSub", { cost: invMoney(stats.avgUnitCost, currency, lang) }),
      icon: "wallet",
      c1: "#06b6d4",
      c2: "#0891b2",
    },
    {
      key: "invKpiLow",
      value: fmtNum(stats.lowCount, lang),
      sub: t("invKpiPctSub", { pct: fmtNum(stats.lowPct, lang) }),
      icon: "triangle-alert",
      c1: "#f59e0b",
      c2: "#d97706",
      tone: "down",
    },
    {
      key: "invKpiOut",
      value: fmtNum(stats.outCount, lang),
      sub: t("invKpiPctSub", { pct: fmtNum(stats.outPct, lang) }),
      icon: "package-open",
      c1: "#f43f5e",
      c2: "#e11d48",
      tone: "down",
    },
  ];

  return (
    <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
      {kpis.map((kpi, i) => (
        <StatCard
          key={kpi.key}
          size="golden"
          label={t(kpi.key)}
          value={kpi.value}
          sub={kpi.sub}
          icon={kpi.icon}
          c1={kpi.c1}
          c2={kpi.c2}
          tone={kpi.tone}
          index={i}
          loading={loading}
          aria-label={t(kpi.key)}
        />
      ))}
    </div>
  );
}
