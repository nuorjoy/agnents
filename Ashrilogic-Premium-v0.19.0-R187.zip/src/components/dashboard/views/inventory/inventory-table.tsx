"use client";

/**
 * Ashrilogic — inventory stock table (ROUND 78).
 *
 * The main premium table of the dedicated المخزون workspace:
 *   الصنف (+SKU chip — ROUND 133: Arabic-Indic digits + RTL for ar) ·
 *   الفئة (chip) · الكمية (+reorder-point health
 *   bar) · حد إعادة الطلب · تكلفة الوحدة · القيمة (bold) · الموقع ·
 *   المورد · الانتهاء (expiry chips) · الحالة (status pill) · actions
 *   (quick adjust / reorder / print / edit / delete).
 *
 * Mobile-first: phones render stacked label:value cards (no clipped
 * columns — same pattern as the generic workspace round 35); desktop
 * renders the wide table inside a horizontal-scroll shell.
 */
import { CatIcon } from "@/components/icon";
import { useT } from "@/lib/i18n";
import type { Lang } from "@/lib/types";
import type { ColDef, StatusDef } from "@/lib/module-data";
import type { InvItem } from "@/lib/inventory-data";
import { expiryInfo } from "@/lib/inventory-data";
import { cn, fmtId, fmtNum, idDir, numDir } from "@/lib/utils";
import { TONE_DOT, TONE_STYLE, invStatusLabel, qtyBarPct, qtyBarTone } from "./inv-shared";

export interface InventoryTableProps {
  /** the current page's rows (already filtered + sorted + paginated) */
  items: InvItem[];
  cols: ColDef[];
  statuses: StatusDef[];
  source: "demo" | "mine";
  reorderPendingId: string | null;
  onAdjust: (id: string) => void;
  onReorder: (id: string) => void;
  onEdit: (id: string) => void;
  onDelete: (id: string) => void;
  onPrint: (id: string) => void;
  /** ROUND 141 — the per-row «عرض المنتجات» action (opens the focused
   *  catalog viewer). */
  onViewProducts: (id: string) => void;
}

/* ---------------- small pieces ---------------- */

function SkuChip({ sku }: { sku: string }) {
  const { lang } = useT();
  if (!sku) return null;
  return (
    <span
      dir={idDir}
      className="mt-1 inline-flex items-center gap-1 rounded-full border border-slate-200 bg-slate-50 px-1.5 py-px font-mono text-[10px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-400"
    >
      <CatIcon name="scan-line" className="h-2.5 w-2.5" aria-hidden="true" />
      {fmtId(sku, lang)}
    </span>
  );
}

function CategoryChip({ category }: { category: string }) {
  return (
    <span className="inline-flex max-w-36 items-center truncate rounded-full bg-violet-500/10 px-2 py-0.5 text-[10.5px] font-bold text-violet-600 dark:text-violet-300">
      {category || "—"}
    </span>
  );
}

function StatusPill({
  item,
  statuses,
  lang,
}: {
  item: InvItem;
  statuses: StatusDef[];
  lang: Lang;
}) {
  const st = statuses.find((s) => s.key === item.statusKey);
  if (!st) return <span className="text-[11px] text-slate-400">—</span>;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2 py-0.5 text-[10.5px] font-extrabold",
        TONE_STYLE[st.tone]
      )}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", TONE_DOT[st.tone])} aria-hidden="true" />
      {invStatusLabel(st.key, statuses, lang)}
    </span>
  );
}

function ExpiryCell({ expiry }: { expiry: string }) {
  const { t, lang } = useT();
  const info = expiryInfo(expiry);
  if (info.state === "none") {
    return <span className="text-[11.5px] font-semibold text-slate-300 dark:text-slate-600">—</span>;
  }
  if (info.state === "expired") {
    return (
      <span className="inline-flex items-center gap-1 rounded-full bg-rose-500/12 px-2 py-0.5 text-[10px] font-extrabold text-rose-600 dark:text-rose-300">
        <CatIcon name="circle-x" className="h-3 w-3" aria-hidden="true" />
        {t("invExpiryExpired")}
      </span>
    );
  }
  if (info.state === "soon") {
    return (
      <span
        title={t("invExpiryIn", { days: fmtNum(info.days, lang) })}
        className="inline-flex items-center gap-1 rounded-full bg-amber-500/12 px-2 py-0.5 text-[10px] font-extrabold text-amber-600 dark:text-amber-300"
      >
        <CatIcon name="clock-rotate-left" className="h-3 w-3" aria-hidden="true" />
        {t("invExpiringSoon")}
      </span>
    );
  }
  return (
    <span dir="ltr" className="tabular-nums text-[11.5px] font-semibold text-slate-500 dark:text-slate-400">
      {expiry}
    </span>
  );
}

/** quantity + health bar against the reorder point */
function QtyCell({ item }: { item: InvItem }) {
  const { t, lang } = useT();
  const tone = qtyBarTone(item.qty, item.reorder);
  const pct = qtyBarPct(item.qty, item.reorder);
  return (
    <div className="flex flex-col items-end gap-1">
      <span dir={numDir(lang)} className={cn("font-extrabold tabular-nums", tone.text)}>
        {fmtNum(item.qty, lang)}
      </span>
      <div
        className="h-1.5 w-24 overflow-hidden rounded-full bg-slate-200/80 dark:bg-white/10"
        role="progressbar"
        aria-valuenow={item.qty}
        aria-valuemin={0}
        aria-valuemax={item.reorder * 2}
        aria-label={t("invQtyAria", { qty: fmtNum(item.qty, lang), reorder: fmtNum(item.reorder, lang) })}
      >
        <div
          className={cn("h-full rounded-full transition-all duration-500", tone.bar)}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

/* ---------------- the table ---------------- */

export function InventoryTable({
  items,
  cols,
  statuses,
  source,
  reorderPendingId,
  onAdjust,
  onReorder,
  onEdit,
  onDelete,
  onPrint,
  onViewProducts,
}: InventoryTableProps) {
  const { t, lang } = useT();

  const labelOf = (key: string): string => {
    const col = cols.find((c) => c.key === key);
    return col ? (lang === "ar" ? col.ar : col.en) : key;
  };

  const th = "whitespace-nowrap px-3.5 py-2.5 text-[10.5px] font-extrabold uppercase tracking-wide text-slate-500 dark:text-slate-400";
  const td = "whitespace-nowrap px-3.5 py-2.5 text-[12px] font-semibold text-slate-700 dark:text-slate-200";

  return (
    <>
      {/* ---------- desktop / tablet table (horizontal scroll shell) ---------- */}
      <div className="overflow-hidden rounded-2xl border border-slate-200/80 dark:border-white/10 md:block">
        <div className="max-h-[520px] overflow-auto nice-scroll">
          <table className="w-full min-w-[1080px] border-collapse text-start">
            <thead className="sticky top-0 z-10">
              <tr className="bg-slate-100/95 backdrop-blur dark:bg-[#0b1220]/95">
                <th scope="col" className={cn(th, "text-start")}>{labelOf("item")}</th>
                <th scope="col" className={cn(th, "text-start")}>{labelOf("category")}</th>
                <th scope="col" className={cn(th, "text-end")}>{labelOf("qty")}</th>
                <th scope="col" className={cn(th, "text-end")}>{labelOf("reorder")}</th>
                <th scope="col" className={cn(th, "text-end")}>{labelOf("unit")}</th>
                <th scope="col" className={cn(th, "text-end")}>{labelOf("total")}</th>
                <th scope="col" className={cn(th, "text-start")}>{labelOf("location")}</th>
                <th scope="col" className={cn(th, "text-start")}>{labelOf("supplier")}</th>
                <th scope="col" className={cn(th, "text-end")}>{labelOf("expiry")}</th>
                <th scope="col" className={cn(th, "text-start")}>{labelOf("status")}</th>
                <th scope="col" className={cn(th, "w-px text-end")}>{t("modRecActionsCol")}</th>
              </tr>
            </thead>
            <tbody>
              {items.map((it, idx) => (
                <tr
                  key={it.id}
                  className={cn(
                    "border-t border-slate-100 transition-colors dark:border-white/[0.06]",
                    idx % 2 === 1 && "bg-slate-50/50 dark:bg-white/[0.02]",
                    "hover:bg-brand-50/50 dark:hover:bg-brand-500/[0.06]"
                  )}
                >
                  {/* الصنف + SKU */}
                  <td className={cn(td, "max-w-56")}>
                    <div className="min-w-0">
                      <p className="truncate font-display text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                        {it.item || "—"}
                      </p>
                      <SkuChip sku={it.sku} />
                    </div>
                  </td>
                  {/* الفئة */}
                  <td className={td}>
                    <CategoryChip category={it.category} />
                  </td>
                  {/* الكمية + health bar */}
                  <td className={cn(td, "text-end")}>
                    <QtyCell item={it} />
                  </td>
                  {/* حد إعادة الطلب */}
                  <td className={cn(td, "text-end tabular-nums text-slate-500 dark:text-slate-400")}>
                    <span dir={numDir(lang)}>{fmtNum(it.reorder, lang)}</span>
                  </td>
                  {/* تكلفة الوحدة */}
                  <td className={cn(td, "text-end tabular-nums")}>
                    <span dir={numDir(lang)}>{fmtNum(it.unit, lang)}</span>
                  </td>
                  {/* القيمة */}
                  <td className={cn(td, "text-end font-extrabold tabular-nums text-slate-900 dark:text-white")}>
                    <span dir={numDir(lang)}>{fmtNum(it.total, lang)}</span>
                  </td>
                  {/* الموقع */}
                  <td className={cn(td, "max-w-36 text-slate-500 dark:text-slate-400")}>
                    <span className="inline-flex items-center gap-1 truncate">
                      <CatIcon name="map-pin" className="h-3 w-3 shrink-0 text-slate-400" aria-hidden="true" />
                      {it.location || "—"}
                    </span>
                  </td>
                  {/* المورد */}
                  <td className={cn(td, "max-w-40 text-slate-500 dark:text-slate-400")}>
                    <span className="inline-flex items-center gap-1 truncate">
                      <CatIcon name="truck" className="h-3 w-3 shrink-0 text-slate-400" aria-hidden="true" />
                      {it.supplier || "—"}
                    </span>
                  </td>
                  {/* الانتهاء */}
                  <td className={cn(td, "text-end")}>
                    <ExpiryCell expiry={it.expiry} />
                  </td>
                  {/* الحالة */}
                  <td className={td}>
                    <StatusPill item={it} statuses={statuses} lang={lang} />
                  </td>
                  {/* actions */}
                  <td className="whitespace-nowrap px-2.5 py-2 text-end">
                    <div className="flex items-center justify-end gap-1">
                      {/* ROUND 141 — «عرض المنتجات»: the focused catalog viewer */}
                      <button
                        type="button"
                        aria-label={t("invRowViewProducts")}
                        title={t("invRowViewProducts")}
                        onClick={() => onViewProducts(it.id)}
                        className="grid h-7 w-7 place-items-center rounded-lg text-slate-400 transition hover:bg-violet-500/10 hover:text-violet-600 active:scale-90 dark:text-slate-500 dark:hover:text-violet-300"
                      >
                        <CatIcon name="boxes" className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        aria-label={t("invRowAdjust")}
                        title={t("invRowAdjust")}
                        onClick={() => onAdjust(it.id)}
                        className="grid h-7 w-7 place-items-center rounded-lg text-slate-400 transition hover:bg-sky-500/10 hover:text-sky-600 active:scale-90 dark:text-slate-500 dark:hover:text-sky-300"
                      >
                        <CatIcon name="sliders" className="h-3.5 w-3.5" />
                      </button>
                      {it.statusKey !== "ordered" ? (
                        <button
                          type="button"
                          aria-label={t("invRowReorder")}
                          title={t("invRowReorder")}
                          disabled={reorderPendingId === it.id}
                          onClick={() => onReorder(it.id)}
                          className="grid h-7 w-7 place-items-center rounded-lg text-slate-400 transition hover:bg-emerald-500/10 hover:text-emerald-600 active:scale-90 disabled:opacity-40 dark:text-slate-500 dark:hover:text-emerald-300"
                        >
                          <CatIcon
                            name={reorderPendingId === it.id ? "refresh-cw" : "shopping-cart"}
                            className={cn("h-3.5 w-3.5", reorderPendingId === it.id && "animate-spin")}
                          />
                        </button>
                      ) : null}
                      <button
                        type="button"
                        aria-label={t("printAria")}
                        title={t("printAria")}
                        onClick={() => onPrint(it.id)}
                        className="grid h-7 w-7 place-items-center rounded-lg text-slate-400 transition hover:bg-brand-500/10 hover:text-brand-600 active:scale-90 dark:text-slate-500 dark:hover:text-brand-300"
                      >
                        <CatIcon name="printer" className="h-3.5 w-3.5" />
                      </button>
                      {source === "mine" ? (
                        <>
                          <button
                            type="button"
                            aria-label={t("modRecEditAria")}
                            title={t("modRecEditAria")}
                            onClick={() => onEdit(it.id)}
                            className="grid h-7 w-7 place-items-center rounded-lg text-slate-400 transition hover:bg-amber-500/10 hover:text-amber-600 active:scale-90 dark:text-slate-500 dark:hover:text-amber-400"
                          >
                            <CatIcon name="pencil" className="h-3.5 w-3.5" />
                          </button>
                          <button
                            type="button"
                            aria-label={t("modRecDeleteAria")}
                            title={t("modRecDeleteAria")}
                            onClick={() => onDelete(it.id)}
                            className="grid h-7 w-7 place-items-center rounded-lg text-slate-400 transition hover:bg-rose-500/10 hover:text-rose-600 active:scale-90 dark:text-slate-500 dark:hover:text-rose-400"
                          >
                            <CatIcon name="trash-2" className="h-3.5 w-3.5" />
                          </button>
                        </>
                      ) : null}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ---------- mobile-first stacked cards (phones) ---------- */}
      <div className="space-y-2.5 md:hidden">
        {items.map((it, idx) => {
          const rows: { label: string; node: React.ReactNode }[] = [
            {
              label: labelOf("qty"),
              node: (
                <span className="flex flex-col items-end gap-1">
                  <span dir={numDir(lang)} className={cn("tabular-nums font-extrabold", qtyBarTone(it.qty, it.reorder).text)}>
                    {fmtNum(it.qty, lang)}
                  </span>
                  <div className="h-1.5 w-24 overflow-hidden rounded-full bg-slate-200/80 dark:bg-white/10">
                    <div
                      className={cn("h-full rounded-full", qtyBarTone(it.qty, it.reorder).bar)}
                      style={{ width: `${qtyBarPct(it.qty, it.reorder)}%` }}
                    />
                  </div>
                </span>
              ),
            },
            {
              label: labelOf("reorder"),
              node: <span dir={numDir(lang)} className="tabular-nums">{fmtNum(it.reorder, lang)}</span>,
            },
            {
              label: labelOf("unit"),
              node: <span dir={numDir(lang)} className="tabular-nums">{fmtNum(it.unit, lang)}</span>,
            },
            {
              label: labelOf("total"),
              node: <span dir={numDir(lang)} className="tabular-nums font-extrabold text-slate-900 dark:text-white">{fmtNum(it.total, lang)}</span>,
            },
            {
              label: labelOf("location"),
              node: <span className="truncate">{it.location || "—"}</span>,
            },
            {
              label: labelOf("supplier"),
              node: <span className="truncate">{it.supplier || "—"}</span>,
            },
            {
              label: labelOf("expiry"),
              node: <ExpiryCell expiry={it.expiry} />,
            },
          ];
          return (
            <article
              key={it.id}
              className={cn(
                "rounded-2xl border p-3.5",
                idx % 2 === 1
                  ? "border-slate-200/80 bg-slate-50/60 dark:border-white/[0.07] dark:bg-white/[0.02]"
                  : "border-slate-200/80 bg-white/70 dark:border-white/[0.07] dark:bg-white/[0.03]"
              )}
            >
              <div className="flex items-start justify-between gap-2.5">
                <div className="min-w-0 flex-1">
                  <p className="truncate font-display text-[13.5px] font-extrabold text-slate-800 dark:text-slate-100">
                    {it.item || "—"}
                  </p>
                  <div className="mt-1 flex flex-wrap items-center gap-1.5">
                    <SkuChip sku={it.sku} />
                    <CategoryChip category={it.category} />
                  </div>
                </div>
                <StatusPill item={it} statuses={statuses} lang={lang} />
              </div>
              <dl className="mt-2.5 space-y-1.5 border-t border-dashed border-slate-200/80 pt-2.5 dark:border-white/10">
                {rows.map((r) => (
                  <div key={r.label} className="flex items-center justify-between gap-3">
                    <dt className="max-w-[45%] shrink-0 truncate text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                      {r.label}
                    </dt>
                    <dd className="min-w-0 flex-1 text-end text-[11.5px] font-semibold text-slate-700 dark:text-slate-200">
                      {r.node}
                    </dd>
                  </div>
                ))}
              </dl>
              {/* mobile actions — 44px touch targets */}
              <div className="mt-2.5 flex flex-wrap items-center justify-end gap-1.5 border-t border-dashed border-slate-200/80 pt-2.5 dark:border-white/10">
                {/* ROUND 141 — «عرض المنتجات»: the focused catalog viewer */}
                <button
                  type="button"
                  aria-label={t("invRowViewProducts")}
                  onClick={() => onViewProducts(it.id)}
                  className="grid h-11 w-11 place-items-center rounded-xl border border-slate-200 text-slate-500 transition hover:border-violet-300 hover:text-violet-600 active:scale-95 dark:border-white/10 dark:text-slate-400 dark:hover:border-violet-500/40 dark:hover:text-violet-300"
                >
                  <CatIcon name="boxes" className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  aria-label={t("invRowAdjust")}
                  onClick={() => onAdjust(it.id)}
                  className="grid h-11 w-11 place-items-center rounded-xl border border-slate-200 text-slate-500 transition hover:border-sky-300 hover:text-sky-600 active:scale-95 dark:border-white/10 dark:text-slate-400"
                >
                  <CatIcon name="sliders" className="h-4 w-4" />
                </button>
                {it.statusKey !== "ordered" ? (
                  <button
                    type="button"
                    aria-label={t("invRowReorder")}
                    disabled={reorderPendingId === it.id}
                    onClick={() => onReorder(it.id)}
                    className="grid h-11 w-11 place-items-center rounded-xl border border-slate-200 text-slate-500 transition hover:border-emerald-300 hover:text-emerald-600 active:scale-95 disabled:opacity-40 dark:border-white/10 dark:text-slate-400"
                  >
                    <CatIcon
                      name={reorderPendingId === it.id ? "refresh-cw" : "shopping-cart"}
                      className={cn("h-4 w-4", reorderPendingId === it.id && "animate-spin")}
                    />
                  </button>
                ) : null}
                <button
                  type="button"
                  aria-label={t("printAria")}
                  onClick={() => onPrint(it.id)}
                  className="grid h-11 w-11 place-items-center rounded-xl border border-slate-200 text-slate-500 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:text-slate-400 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
                >
                  <CatIcon name="printer" className="h-4 w-4" />
                </button>
                {source === "mine" ? (
                  <>
                    <button
                      type="button"
                      aria-label={t("modRecEditAria")}
                      onClick={() => onEdit(it.id)}
                      className="grid h-11 w-11 place-items-center rounded-xl border border-slate-200 text-slate-500 transition hover:border-amber-300 hover:text-amber-600 active:scale-95 dark:border-white/10 dark:text-slate-400"
                    >
                      <CatIcon name="pencil" className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      aria-label={t("modRecDeleteAria")}
                      onClick={() => onDelete(it.id)}
                      className="grid h-11 w-11 place-items-center rounded-xl border border-slate-200 text-slate-500 transition hover:border-rose-300 hover:text-rose-600 active:scale-95 dark:border-white/10 dark:text-slate-400"
                    >
                      <CatIcon name="trash-2" className="h-4 w-4" />
                    </button>
                  </>
                ) : null}
              </div>
            </article>
          );
        })}
      </div>
    </>
  );
}
