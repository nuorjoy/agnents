"use client";

/**
 * Ashrilogic — inventory «عرض المنتجات داخل المخزون» viewer (ROUND 131).
 *
 * The owner's directive: a professional button on the المخزون page that
 * opens EVERY product living inside the inventory. This premium dialog
 * renders the full catalog: search + location filter + the live summary
 * (items / units / displayed value) + one row per item with the stock
 * health bar (qty vs reorder), unit cost, line value, supplier, batch
 * expiry chips and the status pill. Data comes from the SAME inventory
 * dataset the table shows (demo | mine + session overrides) — nothing
 * new server-side, and the numbers always agree with the workspace.
 *
 * ROUND 133 (task R133-FE-A) — the premium detail upgrade «اجعل التفاصيل
 * التي تظهر احترافية وجذابة وPremium»: every product row is now an
 * expandable PASSPORT (click anywhere on the row) revealing a decorative
 * CSS barcode, a 4-stat numbers grid (unit cost / line value / qty /
 * reorder point) and the full meta rows (category / location / supplier /
 * batch expiry). All numbers + IDs render through the ROUND 133 helpers —
 * fmtNum / fmtMoneyCell / fmtId with dir={numDir(lang)} — so the Arabic
 * locale shows Arabic-Indic digits embedded RTL (the unified policy the
 * old ar-SA inline toLocaleString calls could not express).
 */
import { useMemo, useState } from "react";
import { useT } from "@/lib/i18n";
import type { InvItem } from "@/lib/inventory-data";
import type { Lang } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { cn, fmtId, fmtMoneyCell, fmtNum, grad, hexAlpha, idDir, normalizeSearch, numDir } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { BarcodeStrip } from "../business/record-detail-sheet";

const TONE_DOT: Record<string, string> = {
  emerald: "bg-emerald-500",
  amber: "bg-amber-500",
  rose: "bg-rose-500",
  sky: "bg-sky-500",
  violet: "bg-violet-500",
  slate: "bg-slate-400",
};

const TONE_STYLE: Record<string, string> = {
  emerald: "bg-emerald-500/12 text-emerald-700 dark:text-emerald-300",
  amber: "bg-amber-500/12 text-amber-700 dark:text-amber-300",
  rose: "bg-rose-500/12 text-rose-700 dark:text-rose-300",
  sky: "bg-sky-500/12 text-sky-700 dark:text-sky-300",
  violet: "bg-violet-500/12 text-violet-700 dark:text-violet-300",
  slate: "bg-slate-500/12 text-slate-600 dark:text-slate-300",
};

/** mini stat card of the expanded passport (icon + micro label + value). */
function ViewerStat({
  icon,
  label,
  value,
  dir,
  valueClass,
  lang,
}: {
  icon: string;
  label: string;
  value: string;
  dir: "rtl" | "ltr" | "auto";
  valueClass?: string;
  lang: Lang;
}) {
  return (
    <div className="min-w-0 rounded-2xl border border-black/5 bg-slate-50/60 p-2.5 dark:border-white/10 dark:bg-white/[0.03]">
      <p
        className={cn(
          "flex items-center gap-1.5 text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500",
          lang === "ar" ? "tracking-normal" : "tracking-wider"
        )}
        dir="auto"
      >
        <CatIcon name={icon} className="h-2.5 w-2.5 shrink-0" />
        <span className="truncate">{label}</span>
      </p>
      <p dir={dir} className={cn("mt-1 truncate font-display text-[14.5px] font-extrabold tabular-nums text-slate-800 dark:text-white", valueClass)}>
        {value}
      </p>
    </div>
  );
}

/** label + value meta row of the expanded passport. */
function ViewerMetaRow({ icon, label, value, dir, mono }: { icon: string; label: string; value: string; dir: "rtl" | "ltr" | "auto"; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-xl border border-black/5 bg-slate-50/60 px-3.5 py-2.5 dark:border-white/10 dark:bg-white/[0.03]">
      <span className="flex shrink-0 items-center gap-1.5 text-[11.5px] font-extrabold text-slate-400 dark:text-slate-500" dir="auto">
        <CatIcon name={icon} className="h-3.5 w-3.5 shrink-0" />
        {label}
      </span>
      {value ? (
        <span dir={dir} className={cn("min-w-0 truncate text-[12.5px] font-bold text-slate-700 dark:text-slate-200", mono && "font-mono tabular-nums")}>
          {value}
        </span>
      ) : (
        <span className="text-[12.5px] font-bold text-slate-400">—</span>
      )}
    </div>
  );
}

export function InventoryProductsViewer({
  open,
  onOpenChange,
  items,
  currency,
  c1,
  c2,
  statusLabels,
  focusItem,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  items: InvItem[];
  currency: string;
  c1: string;
  c2: string;
  /** statusKey → localized label */
  statusLabels: Record<string, { label: string; tone: string }>;
  /** ROUND 141 — the per-row «عرض المنتجات» entry: the viewer opens
   *  FOCUSED on this item (its search pre-filled + passport expanded). */
  focusItem?: InvItem | null;
}) {
  const { t, lang } = useT();
  const [query, setQuery] = useState("");
  const [locFilter, setLocFilter] = useState("all");
  /* the expanded product passport (one row open at a time) */
  const [expandedId, setExpandedId] = useState<string | null>(null);

  /* ROUND 141 — the focused entry: when the dialog opens carrying a focus
   *  item, its name pre-fills the search and its passport auto-expands
   *  (the previous-value pattern — no setState-in-effect). */
  const [prevFocus, setPrevFocus] = useState<string | null | undefined>(undefined);
  const focusId = focusItem?.id ?? null;
  if (prevFocus !== focusId) {
    setPrevFocus(focusId);
    if (focusId !== null) {
      setQuery(focusItem?.item ?? "");
      setLocFilter("all");
      setExpandedId(focusId);
    }
  }

  const locations = useMemo(
    () =>
      [...new Set(items.map((i) => i.location).filter(Boolean))].sort((a, b) =>
        a.localeCompare(b, lang === "ar" ? "ar" : "en")
      ),
    [items, lang]
  );

  const filtered = useMemo(() => {
    const q = normalizeSearch(query.trim());
    return items.filter((it) => {
      if (locFilter !== "all" && it.location !== locFilter) return false;
      if (!q) return true;
      return normalizeSearch(`${it.item} ${it.sku} ${it.category} ${it.supplier} ${it.location}`).includes(q);
    });
  }, [items, query, locFilter]);

  const summary = useMemo(() => {
    const units = filtered.reduce((s, i) => s + i.qty, 0);
    const value = filtered.reduce((s, i) => s + i.total, 0);
    return { count: filtered.length, units, value };
  }, [filtered]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        dir={lang === "ar" ? "rtl" : "ltr"}
        className="flex max-h-[90vh] w-[min(96vw,880px)] flex-col gap-0 overflow-hidden rounded-3xl p-0"
      >
        {/* gradient header */}
        <div
          className="relative flex shrink-0 items-center gap-3.5 overflow-hidden border-b border-slate-200/70 px-5 py-4 dark:border-white/10"
          style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.16)}, ${hexAlpha(c2, 0.16)})` }}
        >
          <span className="absolute -end-8 -top-14 h-28 w-28 rounded-full" style={{ background: `radial-gradient(circle, ${hexAlpha(c1, 0.3)}, transparent 70%)` }} aria-hidden="true" />
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg" style={{ backgroundImage: grad(c1, c2) }} aria-hidden="true">
            <CatIcon name="boxes" className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <DialogTitle className="truncate font-display text-[15px] font-extrabold leading-tight text-slate-900 dark:text-white">
              {t("invProductsTitle")}
            </DialogTitle>
            <DialogDescription className="mt-0.5 truncate text-[11.5px] font-semibold text-slate-500 dark:text-slate-400">
              {t("invProductsDesc")}
            </DialogDescription>
          </div>
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="h-9 rounded-xl border-slate-200 bg-white px-3.5 text-[12px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
          >
            <CatIcon name="x" className="h-4 w-4" />
            <span className="hidden sm:inline">{t("bizClose")}</span>
          </Button>
        </div>

        {/* summary strip + search + location filter */}
        <div className="shrink-0 space-y-3 border-b border-slate-200/70 px-5 py-3.5 dark:border-white/10">
          <div className="grid grid-cols-3 gap-2.5">
            <div className="rounded-2xl border border-slate-200/80 bg-slate-50/60 p-2.5 dark:border-white/10 dark:bg-white/[0.03]">
              <p className="text-[10px] font-extrabold uppercase tracking-wide text-slate-400">{t("invProductsItems")}</p>
              <p dir={numDir(lang)} className="mt-0.5 font-display text-[16px] font-extrabold tabular-nums text-slate-900 dark:text-white">{fmtNum(summary.count, lang)}</p>
            </div>
            <div className="rounded-2xl border border-slate-200/80 bg-slate-50/60 p-2.5 dark:border-white/10 dark:bg-white/[0.03]">
              <p className="text-[10px] font-extrabold uppercase tracking-wide text-slate-400">{t("invProductsUnits")}</p>
              <p dir={numDir(lang)} className="mt-0.5 font-display text-[16px] font-extrabold tabular-nums text-slate-900 dark:text-white">{fmtNum(summary.units, lang)}</p>
            </div>
            <div className="rounded-2xl border border-slate-200/80 bg-slate-50/60 p-2.5 dark:border-white/10 dark:bg-white/[0.03]">
              <p className="text-[10px] font-extrabold uppercase tracking-wide text-slate-400">{t("invProductsValue")}</p>
              <p dir={numDir(lang)} className="mt-0.5 truncate font-display text-[15px] font-extrabold tabular-nums text-emerald-600 dark:text-emerald-400">
                {fmtMoneyCell(summary.value, lang, currency)}
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative min-w-0 flex-1 sm:max-w-xs">
              <CatIcon name="search" className="pointer-events-none absolute start-3.5 top-1/2 h-[12px] w-[12px] -translate-y-1/2 text-slate-400" />
              <Input
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={t("invProductsSearchPh")}
                aria-label={t("invProductsSearchPh")}
                className="h-10 rounded-xl border-slate-200 bg-slate-50/80 ps-10 pe-3 text-[12.5px] font-semibold dark:border-white/10 dark:bg-white/[0.04]"
              />
            </div>
            <Select value={locFilter} onValueChange={setLocFilter}>
              <SelectTrigger className="h-10 w-auto min-w-36 rounded-xl text-[12.5px] font-semibold" aria-label={t("invProductsLocAll")}>
                <CatIcon name="map-pin" className="h-3.5 w-3.5 text-slate-400" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("invProductsLocAll")}</SelectItem>
                {locations.map((loc) => (
                  <SelectItem key={loc} value={loc}>{loc}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* the catalog */}
        <div className="nice-scroll min-h-0 flex-1 overflow-y-auto px-5 py-4">
          {filtered.length === 0 ? (
            <div className="py-10 text-center">
              <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5">
                <CatIcon name="search-x" className="h-6 w-6" />
              </span>
              <p className="mt-3 font-display text-[15px] font-extrabold text-slate-700 dark:text-slate-200">{t("bizEmptyNoMatch")}</p>
              <p className="mx-auto mt-1.5 max-w-md text-[12px] font-semibold text-slate-400 dark:text-slate-500">{t("bizEmptyNoMatchDesc")}</p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {filtered.map((it) => {
                const st = statusLabels[it.statusKey];
                const health = it.qty <= 0 ? "out" : it.qty <= it.reorder ? "low" : "ok";
                const barWidth = Math.min(100, Math.max(6, (it.qty / Math.max(1, it.reorder * 4)) * 100));
                const expanded = expandedId === it.id;
                return (
                  <article
                    key={it.id}
                    className={cn(
                      "rounded-2xl border transition dark:hover:border-white/20",
                      expanded
                        ? "border-slate-300 shadow-sm dark:border-white/20"
                        : "border-slate-200/80 hover:border-slate-300 hover:shadow-sm dark:border-white/10"
                    )}
                  >
                    {/* the clickable row — toggles the premium passport */}
                    <button
                      type="button"
                      onClick={() => setExpandedId(expanded ? null : it.id)}
                      aria-expanded={expanded}
                      aria-label={`${t("bizRowDetailTitle")} — ${it.item || "—"}`}
                      className="grid w-full cursor-pointer grid-cols-1 gap-3 rounded-2xl p-3.5 text-start transition sm:grid-cols-[minmax(0,1fr)_auto]"
                    >
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <p className="min-w-0 truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">{it.item || "—"}</p>
                          {it.sku ? (
                            <span
                              dir={idDir}
                              className="rounded-lg bg-slate-100 px-1.5 py-0.5 font-mono text-[10px] font-bold tabular-nums text-slate-500 dark:bg-white/10 dark:text-slate-400"
                            >
                              {fmtId(it.sku, lang)}
                            </span>
                          ) : null}
                          {st ? (
                            <span className={cn("inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[9.5px] font-extrabold", TONE_STYLE[st.tone] ?? TONE_STYLE.slate)}>
                              <span className={cn("h-1 w-1 rounded-full", TONE_DOT[st.tone] ?? TONE_DOT.slate)} aria-hidden="true" />
                              {st.label}
                            </span>
                          ) : null}
                          <span className="ms-auto shrink-0 text-slate-300 dark:text-slate-500" aria-hidden="true">
                            <CatIcon
                              name="chevron-down"
                              className={cn("h-3.5 w-3.5 transition-transform duration-300", expanded && "rotate-180")}
                            />
                          </span>
                        </div>
                        <p className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                          {it.category ? <span className="truncate">{it.category}</span> : null}
                          {it.location ? (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="inline-flex items-center gap-1 truncate">
                                <CatIcon name="map-pin" className="h-2.5 w-2.5" />
                                {it.location}
                              </span>
                            </>
                          ) : null}
                          {it.supplier ? (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="inline-flex items-center gap-1 truncate">
                                <CatIcon name="truck" className="h-2.5 w-2.5" />
                                {it.supplier}
                              </span>
                            </>
                          ) : null}
                          {it.expiry ? (
                            <>
                              <span aria-hidden="true">·</span>
                              <span dir={idDir} className="inline-flex items-center gap-1 font-mono tabular-nums">
                                <CatIcon name="calendar" className="h-2.5 w-2.5" />
                                {fmtId(it.expiry, lang)}
                              </span>
                            </>
                          ) : null}
                        </p>
                        {/* stock health bar */}
                        <div className="mt-2 flex items-center gap-2.5">
                          <div className="h-1.5 min-w-24 flex-1 overflow-hidden rounded-full bg-slate-100 dark:bg-white/10">
                            <div
                              className={cn("h-full rounded-full transition-all duration-500", health === "out" ? "bg-rose-500" : health === "low" ? "bg-amber-500" : "bg-emerald-500")}
                              style={{ width: `${barWidth}%` }}
                            />
                          </div>
                          <span
                            dir={numDir(lang)}
                            className={cn(
                              "shrink-0 text-[11px] font-extrabold tabular-nums",
                              health === "out" ? "text-rose-600 dark:text-rose-400" : health === "low" ? "text-amber-600 dark:text-amber-400" : "text-slate-600 dark:text-slate-300"
                            )}
                          >
                            {fmtNum(it.qty, lang)}
                            <span className="ms-1 text-[9px] font-bold text-slate-400">/ {it.reorder > 0 ? fmtNum(it.reorder, lang) : "—"}</span>
                          </span>
                        </div>
                      </div>
                      {/* value block */}
                      <div className="flex shrink-0 flex-row items-center justify-between gap-4 border-slate-100 sm:flex-col sm:items-end sm:justify-center sm:border-s sm:ps-4 dark:border-white/5">
                        <div className="sm:text-end">
                          <p className="text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400">{lang === "ar" ? "تكلفة الوحدة" : "Unit cost"}</p>
                          <p dir={numDir(lang)} className="text-[12px] font-bold tabular-nums text-slate-600 dark:text-slate-300">{fmtMoneyCell(it.unit, lang, currency)}</p>
                        </div>
                        <div className="sm:text-end">
                          <p className="text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400">{lang === "ar" ? "القيمة" : "Value"}</p>
                          <p dir={numDir(lang)} className="text-[13.5px] font-extrabold tabular-nums text-emerald-600 dark:text-emerald-400">{fmtMoneyCell(it.total, lang, currency)}</p>
                        </div>
                      </div>
                    </button>

                    {/* the premium expanded passport */}
                    {expanded ? (
                      <div className="animate-in fade-in-0 slide-in-from-bottom-1 duration-300 grid gap-3 border-t border-dashed border-slate-200 px-3.5 pb-3.5 pt-3 dark:border-white/10 lg:grid-cols-[minmax(0,250px)_minmax(0,1fr)]">
                        {/* decorative CSS barcode card */}
                        <div className="rounded-2xl border border-slate-200/80 bg-slate-50/60 px-4 py-3 dark:border-white/10 dark:bg-white/[0.03]">
                          <BarcodeStrip seed={it.sku || it.id} guards />
                          <p dir={idDir} className="mt-2 text-center font-mono text-[11px] font-bold tracking-[0.25em] tabular-nums text-slate-600 dark:text-slate-300">
                            {fmtId(it.sku || it.id, lang)}
                          </p>
                        </div>
                        {/* stats + meta */}
                        <div className="min-w-0 space-y-3">
                          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                            <ViewerStat icon="wallet" label={lang === "ar" ? "تكلفة الوحدة" : "Unit cost"} value={fmtMoneyCell(it.unit, lang, currency)} dir={numDir(lang)} lang={lang} />
                            <ViewerStat
                              icon="tag"
                              label={lang === "ar" ? "القيمة" : "Value"}
                              value={fmtMoneyCell(it.total, lang, currency)}
                              dir={numDir(lang)}
                              valueClass="text-emerald-600 dark:text-emerald-400"
                              lang={lang}
                            />
                            <ViewerStat
                              icon="boxes"
                              label={lang === "ar" ? "الكمية" : "Quantity"}
                              value={fmtNum(it.qty, lang)}
                              dir={numDir(lang)}
                              valueClass={health === "out" ? "text-rose-600 dark:text-rose-400" : health === "low" ? "text-amber-600 dark:text-amber-400" : undefined}
                              lang={lang}
                            />
                            <ViewerStat icon="package" label={lang === "ar" ? "حد إعادة الطلب" : "Reorder point"} value={it.reorder > 0 ? fmtNum(it.reorder, lang) : "—"} dir={numDir(lang)} lang={lang} />
                          </div>
                          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                            <ViewerMetaRow icon="tag" label={lang === "ar" ? "الفئة" : "Category"} value={it.category} dir="auto" />
                            <ViewerMetaRow icon="map-pin" label={lang === "ar" ? "الموقع" : "Location"} value={it.location} dir="auto" />
                            <ViewerMetaRow icon="truck" label={lang === "ar" ? "المورد" : "Supplier"} value={it.supplier} dir="auto" />
                            <ViewerMetaRow
                              icon="calendar"
                              label={lang === "ar" ? "تاريخ الصلاحية" : "Batch expiry"}
                              value={it.expiry ? fmtId(it.expiry, lang) : ""}
                              dir={idDir}
                              mono
                            />
                          </div>
                        </div>
                      </div>
                    ) : null}
                  </article>
                );
              })}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
