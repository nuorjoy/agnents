"use client";

/**
 * Ashrilogic — inventory alert thresholds panel (ROUND 78).
 *
 * «حدود التنبيه» — items at/below their reorder point (or fully out):
 * a summary chip strip (نافد / تحت الحد / قيد الطلب) then the critical
 * rows sorted by severity (out first, then the lowest qty-vs-point
 * ratio), each with an amber/rose treatment, a qty-vs-point mini bar,
 * the suggested order quantity and the one-tap «طلب شراء» affordance
 * (real rows → updateModuleRecord statusKey; demo rows → local state —
 * both wired by the parent workspace).
 */
import { CatIcon } from "@/components/icon";
import { DashCard } from "@/components/dashboard/dash-shared";
import { useT } from "@/lib/i18n";
import type { StatusDef } from "@/lib/module-data";
import { suggestedOrderQty, type InvItem } from "@/lib/inventory-data";
import { cn, fmtNum, grad } from "@/lib/utils";
import { TONE_DOT, TONE_STYLE, invStatusLabel, qtyBarPct, qtyBarTone } from "./inv-shared";

export function InventoryThresholds({
  items,
  statuses,
  reorderPendingId,
  onReorder,
}: {
  /** ALL items of the current source (alerts ignore table filters) */
  items: InvItem[];
  statuses: StatusDef[];
  reorderPendingId: string | null;
  onReorder: (id: string) => void;
}) {
  const { t, lang } = useT();

  /* alert rows: qty=0 OR qty ≤ reorder point, sorted by severity */
  const alerts = items
    .filter((it) => it.qty <= 0 || it.qty <= it.reorder)
    .sort((a, b) => {
      if (a.qty <= 0 !== (b.qty <= 0)) return a.qty <= 0 ? -1 : 1;
      const ra = a.qty / Math.max(1, a.reorder);
      const rb = b.qty / Math.max(1, b.reorder);
      return ra - rb;
    })
    .slice(0, 8);

  const outCount = items.filter((it) => it.qty <= 0).length;
  const lowCount = items.filter((it) => it.qty > 0 && it.qty <= it.reorder && it.statusKey !== "ordered").length;
  const orderedCount = items.filter((it) => it.statusKey === "ordered").length;

  const chips = [
    { key: "invThresholdsChipOut" as const, count: outCount, cls: "bg-rose-500/12 text-rose-600 dark:text-rose-300", dot: "bg-rose-500" },
    { key: "invThresholdsChipLow" as const, count: lowCount, cls: "bg-amber-500/12 text-amber-600 dark:text-amber-300", dot: "bg-amber-500" },
    { key: "invThresholdsChipOrdered" as const, count: orderedCount, cls: "bg-sky-500/12 text-sky-600 dark:text-sky-300", dot: "bg-sky-500" },
  ];

  return (
    <DashCard title={t("invThresholdsTitle")} icon="triangle-alert">
      <p className="mb-3 text-[11px] font-bold leading-relaxed text-slate-400 dark:text-slate-500">
        {t("invThresholdsDesc")}
      </p>

      {/* summary chip strip */}
      <div className="mb-3 flex flex-wrap items-center gap-1.5">
        {chips.map((chip) => (
          <span
            key={chip.key}
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10.5px] font-extrabold",
              chip.cls
            )}
          >
            <span className={cn("h-1.5 w-1.5 rounded-full", chip.dot)} aria-hidden="true" />
            {t(chip.key, { count: fmtNum(chip.count, lang) })}
          </span>
        ))}
      </div>

      {alerts.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-emerald-300/60 bg-emerald-50/40 p-5 text-center dark:border-emerald-500/20 dark:bg-emerald-500/[0.05]">
          <span className="mx-auto grid h-11 w-11 place-items-center rounded-2xl bg-linear-to-br from-emerald-500 to-emerald-600 text-white shadow-lg shadow-emerald-500/25">
            <CatIcon name="circle-check" className="h-5 w-5" />
          </span>
          <p className="mt-2 font-display text-[13.5px] font-extrabold text-emerald-700 dark:text-emerald-300">
            {t("invThresholdsEmpty")}
          </p>
          <p className="mx-auto mt-1 max-w-xs text-[11px] font-bold leading-relaxed text-emerald-600/80 dark:text-emerald-400/80">
            {t("invThresholdsEmptySub")}
          </p>
        </div>
      ) : (
        <ul className="max-h-96 space-y-2 overflow-y-auto nice-scroll pe-1" aria-label={t("invThresholdsTitle")}>
          {alerts.map((it) => {
            const isOut = it.qty <= 0;
            const tone = qtyBarTone(it.qty, it.reorder);
            const st = statuses.find((s) => s.key === it.statusKey);
            return (
              <li
                key={it.id}
                className={cn(
                  "flex flex-wrap items-center gap-x-3 gap-y-2 rounded-2xl border p-2.5",
                  isOut
                    ? "border-rose-300/60 bg-rose-50/40 dark:border-rose-500/20 dark:bg-rose-500/[0.06]"
                    : "border-amber-300/50 bg-amber-50/30 dark:border-amber-500/20 dark:bg-amber-500/[0.05]"
                )}
              >
                {/* severity tile */}
                <span
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
                  style={{
                    backgroundImage: isOut
                      ? "linear-gradient(135deg,#f43f5e,#e11d48)"
                      : "linear-gradient(135deg,#f59e0b,#d97706)",
                  }}
                  aria-hidden="true"
                >
                  <CatIcon name={isOut ? "package-open" : "triangle-alert"} className="h-4 w-4" />
                </span>

                {/* item + qty-vs-point */}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[12px] font-extrabold text-slate-800 dark:text-slate-100">
                    {it.item || "—"}
                  </p>
                  <div className="mt-1 flex items-center gap-2">
                    <div
                      className="h-1.5 max-w-28 flex-1 overflow-hidden rounded-full bg-slate-200/80 dark:bg-white/10"
                      role="progressbar"
                      aria-valuenow={it.qty}
                      aria-valuemin={0}
                      aria-valuemax={it.reorder * 2}
                      aria-label={t("invQtyAria", { qty: fmtNum(it.qty, lang), reorder: fmtNum(it.reorder, lang) })}
                    >
                      <div
                        className={cn("h-full rounded-full", tone.bar)}
                        style={{ width: `${qtyBarPct(it.qty, it.reorder)}%` }}
                      />
                    </div>
                    <span dir="ltr" className={cn("shrink-0 text-[10.5px] font-extrabold tabular-nums", tone.text)}>
                      {fmtNum(it.qty, lang)}/{fmtNum(it.reorder, lang)}
                    </span>
                  </div>
                </div>

                {/* status + suggested order qty */}
                <div className="flex shrink-0 flex-col items-end gap-1">
                  {st ? (
                    <span
                      className={cn(
                        "inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[10px] font-extrabold",
                        TONE_STYLE[st.tone]
                      )}
                    >
                      <span className={cn("h-1.5 w-1.5 rounded-full", TONE_DOT[st.tone])} aria-hidden="true" />
                      {invStatusLabel(st.key, statuses, lang)}
                    </span>
                  ) : null}
                  <span className="text-[9.5px] font-bold text-slate-400 dark:text-slate-500">
                    {t("invReorderSuggest", { qty: fmtNum(suggestedOrderQty(it), lang) })}
                  </span>
                </div>

                {/* one-tap reorder affordance */}
                {it.statusKey !== "ordered" ? (
                  <button
                    type="button"
                    onClick={() => onReorder(it.id)}
                    disabled={reorderPendingId === it.id}
                    className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-xl px-3 text-[11px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-50"
                    style={{ backgroundImage: grad("#10b981", "#047857") }}
                  >
                    <CatIcon
                      name={reorderPendingId === it.id ? "refresh-cw" : "shopping-cart"}
                      className={cn("h-3.5 w-3.5", reorderPendingId === it.id && "animate-spin")}
                    />
                    <span className="hidden sm:inline">{t("invRowReorder")}</span>
                  </button>
                ) : null}
              </li>
            );
          })}
        </ul>
      )}
    </DashCard>
  );
}
