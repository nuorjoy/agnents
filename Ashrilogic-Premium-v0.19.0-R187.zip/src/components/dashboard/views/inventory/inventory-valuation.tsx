"use client";

/**
 * Ashrilogic — inventory valuation card (ROUND 78).
 *
 * «تقييم المخزون» — precise aggregates computed from the CURRENT
 * FILTERED dataset (whatever search/status/category filters are active):
 *   - fact tiles: إجمالي الوحدات · متوسط تكلفة الوحدة · الصنف الأعلى قيمة
 *   - «الفئات حسب القيمة»: the top categories with mini gradient bars +
 *     share-percentage chips (remaining categories roll up into «فئات أخرى»)
 */
import { CatIcon } from "@/components/icon";
import { DashCard } from "@/components/dashboard/dash-shared";
import { useT } from "@/lib/i18n";
import type { InvStats } from "@/lib/inventory-data";
import { fmtNum, grad } from "@/lib/utils";
import { invMoney } from "./inv-shared";

/* distinct, non-blue category bar gradients (brand-safe palette) */
const CAT_GRADS = [
  ["#6d5dfb", "#a855f7"],
  ["#10b981", "#047857"],
  ["#f59e0b", "#d97706"],
  ["#06b6d4", "#0891b2"],
];

export function InventoryValuation({
  stats,
  currency,
}: {
  stats: InvStats;
  currency: string;
}) {
  const { t, lang } = useT();

  /* top 4 categories by value + the rest rolled up */
  const topCats = stats.cats.slice(0, 4);
  const rest = stats.cats.slice(4);
  const restValue = rest.reduce((s, c) => s + c.value, 0);
  const maxCat = Math.max(1, ...topCats.map((c) => c.value), restValue);
  const bars = [
    ...topCats.map((c) => ({ name: c.name, value: c.value, count: c.count })),
    ...(rest.length > 0 ? [{ name: t("invValuationOther"), value: restValue, count: rest.reduce((s, c) => s + c.count, 0) }] : []),
  ];

  const facts = [
    { icon: "cubes-stacked", label: t("invValuationUnits"), value: fmtNum(stats.totalUnits, lang) },
    { icon: "scale", label: t("invValuationAvg"), value: invMoney(stats.avgUnitCost, currency, lang) },
    {
      icon: "crown",
      label: t("invValuationTopItem"),
      value: stats.topItem ? stats.topItem.name : "—",
      sub: stats.topItem ? invMoney(stats.topItem.value, currency, lang) : undefined,
    },
  ];

  return (
    <DashCard title={t("invValuationTitle")} icon="sigma">
      <p className="mb-4 text-[11px] font-bold leading-relaxed text-slate-400 dark:text-slate-500">
        {t("invValuationDesc")}
      </p>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
        {/* fact tiles */}
        <ul className="grid gap-2.5 sm:grid-cols-3 lg:grid-cols-1">
          {facts.map((fact) => (
            <li
              key={fact.label}
              className="flex items-center gap-3 rounded-2xl border border-slate-200/70 p-2.5 dark:border-white/[0.07]"
            >
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-slate-100 text-slate-500 dark:bg-white/5 dark:text-slate-400">
                <CatIcon name={fact.icon} className="h-4 w-4" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                  {fact.label}
                </span>
                <span className="block truncate text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                  {fact.value}
                </span>
                {fact.sub ? (
                  <span dir="auto" className="block truncate text-[10px] font-bold text-slate-400 dark:text-slate-500">
                    {fact.sub}
                  </span>
                ) : null}
              </span>
            </li>
          ))}
        </ul>

        {/* categories by value */}
        <div>
          <p className="mb-2.5 flex items-center gap-1.5 text-[11px] font-extrabold text-slate-500 dark:text-slate-400">
            <CatIcon name="chart-column" className="h-3.5 w-3.5 text-brand-500" aria-hidden="true" />
            {t("invValuationCats")}
          </p>
          {bars.length === 0 ? (
            <p className="rounded-xl border border-dashed border-slate-200 p-4 text-center text-[11.5px] font-bold text-slate-400 dark:border-white/10 dark:text-slate-500">
              —
            </p>
          ) : (
            <ul className="space-y-2.5">
              {bars.map((bar, i) => {
                const pct = Math.round((bar.value / Math.max(1, stats.totalValue)) * 100);
                const [g1, g2] = CAT_GRADS[i % CAT_GRADS.length];
                return (
                  <li key={bar.name}>
                    <div className="mb-1 flex items-center justify-between gap-2 text-[11.5px] font-bold">
                      <span className="min-w-0 truncate text-slate-600 dark:text-slate-300" dir="auto">
                        {bar.name}
                        <span className="ms-1.5 text-[9.5px] font-semibold text-slate-400 dark:text-slate-500">
                          ({fmtNum(bar.count, lang)})
                        </span>
                      </span>
                      <span className="flex shrink-0 items-center gap-2">
                        <span className="text-[10px] font-extrabold text-slate-400 dark:text-slate-500">
                          {t("invValuationSharePct", { pct: fmtNum(pct, lang) })}
                        </span>
                        <span className="tabular-nums font-extrabold text-slate-700 dark:text-slate-200">
                          {invMoney(bar.value, currency, lang)}
                        </span>
                      </span>
                    </div>
                    <div className="h-2 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-white/10">
                      <div
                        className="h-full rounded-full transition-all duration-700"
                        style={{
                          width: `${Math.max(4, Math.round((bar.value / maxCat) * 100))}%`,
                          backgroundImage: grad(g1, g2, 90),
                        }}
                      />
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </div>
    </DashCard>
  );
}
