/**
 * Ashrilogic — inventory workspace shared bits (ROUND 78).
 *
 * Small, local helpers for the dedicated premium inventory workspace
 * (src/components/dashboard/views/inventory/*): the status tone maps
 * (same visual language as the generic module workspace), the status
 * label resolver, page size and a money formatter. Kept LOCAL to this
 * folder so the shared dashboard files stay untouched (parallel-agent
 * ownership contract).
 */
import type { Lang } from "@/lib/types";
import type { StatusDef, StatusTone } from "@/lib/module-data";
import { fmtNum } from "@/lib/utils";

/* status pill fills — mirrors the generic module workspace TONE_STYLE */
export const TONE_STYLE: Record<StatusTone, string> = {
  emerald: "bg-emerald-500/12 text-emerald-700 dark:text-emerald-300",
  amber: "bg-amber-500/12 text-amber-700 dark:text-amber-300",
  rose: "bg-rose-500/12 text-rose-700 dark:text-rose-300",
  sky: "bg-sky-500/12 text-sky-700 dark:text-sky-300",
  violet: "bg-violet-500/12 text-violet-700 dark:text-violet-300",
  slate: "bg-slate-500/12 text-slate-600 dark:text-slate-300",
};

/* status dots — mirrors the generic module workspace TONE_DOT */
export const TONE_DOT: Record<StatusTone, string> = {
  emerald: "bg-emerald-500",
  amber: "bg-amber-500",
  rose: "bg-rose-500",
  sky: "bg-sky-500",
  violet: "bg-violet-500",
  slate: "bg-slate-400",
};

/* inventory table page size — matches the generic workspace rhythm */
export const INV_PAGE_SIZE = 8;

/* movements panel: how many entries the feed shows */
export const INV_MOVES_COUNT = 9;

/**
 * Status label by key — rows only carry ar/en columns, so non-Arabic
 * locales (incl. Hindi) fall back to the ENGLISH label (same law as the
 * generic workspace statusLabel()).
 */
export function invStatusLabel(
  key: string,
  statuses: StatusDef[],
  lang: Lang
): string {
  const row = statuses.find((s) => s.key === key);
  if (!row) return key;
  return lang === "ar" ? row.ar : row.en;
}

/**
 * Money formatter — the workspace money idiom: locale-aware digits +
 * the org currency code, e.g. «٤٥٬٩٠٠ SAR» / «45,900 SAR».
 */
export function invMoney(value: number, currency: string, lang: Lang): string {
  return `${fmtNum(Math.round(value), lang)} ${currency}`;
}

/**
 * Quantity-bar tone: the health of an item against its reorder point.
 * Returns tailwind color pairs for the bar + the qty text.
 */
export function qtyBarTone(qty: number, reorder: number): { bar: string; text: string } {
  if (qty <= 0) return { bar: "bg-rose-500", text: "text-rose-600 dark:text-rose-400" };
  if (qty <= reorder) return { bar: "bg-amber-500", text: "text-amber-600 dark:text-amber-400" };
  return { bar: "bg-emerald-500", text: "text-emerald-600 dark:text-emerald-400" };
}

/** fill % of the qty bar (capped at 2× the reorder point = full bar) */
export function qtyBarPct(qty: number, reorder: number): number {
  const cap = Math.max(1, reorder * 2);
  return Math.max(qty <= 0 ? 4 : 6, Math.min(100, Math.round((qty / cap) * 100)));
}
