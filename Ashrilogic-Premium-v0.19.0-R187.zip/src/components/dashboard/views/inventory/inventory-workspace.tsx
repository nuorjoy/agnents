"use client";

/**
 * Ashrilogic — DEDICATED premium inventory workspace (ROUND 78).
 *
 * When the active module is «المخزون» (inventory), module-workspace.tsx
 * routes here instead of the generic module surface. Everything the
 * product owner asked for — «وحدة النظام (المخزون) بطريقة متكاملة
 * واحترافية واضافة جميع التفاصيل المهمة بدقّة» — lives on this page:
 *
 *   1. KPI strip — THE unified golden StatCards (ROUND 136): SKUs ·
 *      total units · stock value (Σ qty×unit) · low stock · out
 *   2. Premium stock table — item+SKU chip, category chip, qty with a
 *      reorder-point health bar, unit cost, value, location, supplier,
 *      expiry chips, status pill + full CRUD affordances (real rows:
 *      add / edit / delete / print / quick-adjust / reorder)
 *   3. «حركة المخزون» — movements panel (stable derived feed + LIVE
 *      client-logged feed from quick adjusts and qty edits)
 *   4. «حدود التنبيه» — reorder alert rows with the one-tap طلب شراء
 *   5. «تقييم المخزون» — valuation breakdown computed from the filtered set
 *
 * Data model is UNCHANGED: rows persist through the existing
 * module-records API (ModuleRecord.values aligned with the extended
 * inventory preset — see src/lib/inventory-data.ts). The demo | mine
 * tab pattern of the generic workspace is preserved (demo default,
 * real rows on «سجلاتي», local session overrides on demo rows).
 */
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CATEGORY_MAP, MODULE_MAP, SYSTEM_MAP, moduleDisplayName } from "@/data/catalog";
import { useT } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import type { InstanceDTO } from "@/lib/types";
import { buildModuleDataset, buildRecordsDataset, codePrefixFor } from "@/lib/module-data";
import {
  ApiError,
  createModuleRecord,
  deleteModuleRecord,
  fetchModuleRecords,
  fetchSite,
  updateModuleRecord,
} from "@/lib/api-client";
import { nextRecordCode } from "@/lib/record-code";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, hexAlpha, normalizeSearch } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { DashCard } from "@/components/dashboard/dash-shared";
import { AiInsightsPanel } from "@/components/dashboard/views/ai-insights-panel";
import { RecordPrintDialog, moneyColumnsTotalMinor, type PrintDoc } from "@/components/dashboard/views/record-print";
import {
  computeInvStats,
  deriveInvMovements,
  invColIndex,
  parseInvItem,
  statusForQty,
  type InvItem,
  type InvMove,
  type InvReasonKey,
} from "@/lib/inventory-data";
import { InventoryKpis } from "./inventory-kpis";
import { InventoryTable } from "./inventory-table";
import { InventoryMovements } from "./inventory-movements";
import { InventoryThresholds } from "./inventory-thresholds";
import { InventoryValuation } from "./inventory-valuation";
import { InvAdjustDialog, InvRecordDialog, type InvRecordDraft } from "./inventory-dialogs";
import { InventoryProductsViewer } from "./inventory-products-viewer";
import { INV_MOVES_COUNT, INV_PAGE_SIZE, TONE_DOT, invMoney } from "./inv-shared";
import { useShift } from "@/components/dashboard/shift/shift-status-bar";

/* the module this workspace is hard-wired to */
const MODULE_ID = "inventory";

type SortKey = "value" | "qtyDesc" | "qtyAsc" | "name";

export function InventoryWorkspace({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const setDashView = useAppStore((s) => s.setDashView);
  const setActiveModuleId = useAppStore((s) => s.setActiveModuleId);
  const queryClient = useQueryClient();

  /* ---------------- toolbar state ---------------- */
  const [source, setSource] = useState<"demo" | "mine">("demo");
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [sortKey, setSortKey] = useState<SortKey>("value");
  const [page, setPage] = useState(0);

  /* ---------------- real persisted rows (سجلاتي) ---------------- */
  const recordsQuery = useQuery({
    queryKey: ["module-records", instance.id, MODULE_ID],
    queryFn: () => fetchModuleRecords(instance.id, MODULE_ID),
    staleTime: 30_000,
    retry: 0,
  });
  const records = recordsQuery.data ?? [];

  /* the workspace brand (org logo + signature + stamp) — the same site
   * query the generic workspace uses, so record printing carries the
   * full professional letterhead (cached under the same key). */
  const siteQuery = useQuery({
    queryKey: ["site", instance.id],
    queryFn: () => fetchSite(instance.id),
    staleTime: 60_000,
    retry: 0,
  });

  /* ---------------- datasets (demo showcase vs real rows) ---------------- */
  /* ROUND 129 — systemId rides along: the inventory items/categories/
   *  suppliers/locations speak the system's own sector. */
  const demoData = useMemo(
    () => buildModuleDataset(instance.id, MODULE_ID, lang, instance.org.currency, instance.systemId),
    [instance.id, instance.org.currency, instance.systemId, lang]
  );
  const myData = useMemo(
    () => buildRecordsDataset(MODULE_ID, records, lang, instance.org.currency, instance.systemId),
    [records, lang, instance.org.currency, instance.systemId]
  );
  const data = source === "mine" ? myData : demoData;
  const currency = data.currency ?? instance.org.currency;
  const colIx = useMemo(() => invColIndex(data.cols), [data.cols]);

  /* ---------------- session-local state ----------------
   * demo overrides: quick-adjust / reorder on DEMO rows (local only);
   * liveMoves: the client-side movement feed logged by the owner's own
   * actions (quick adjust + qty edits on real rows);
   * productsViewer (ROUND 131): the «عرض المنتجات داخل المخزون» dialog. */
  const [demoOverrides, setDemoOverrides] = useState<Record<string, { qty?: number; statusKey?: string }>>({});
  const [liveMoves, setLiveMoves] = useState<InvMove[]>([]);
  const [productsViewerOpen, setProductsViewerOpen] = useState(false);
  /* ROUND 141 — the per-row «عرض المنتجات» action: the viewer opens
   * FOCUSED on the row's item (pre-filtered + passport expanded). */
  const [productsViewerFocus, setProductsViewerFocus] = useState<InvItem | null>(null);
  const pushLiveMove = (mv: InvMove) =>
    setLiveMoves((prev) => [mv, ...prev].slice(0, 12));

  /* ---------------- ROUND 141 — نظام الورديات client gate ----------------
   * The owner's directive: the inventory page's quick add must NOT let
   * anyone bypass the shift activation. The SERVER already refuses every
   * module-record write with 403 SHIFT_REQUIRED (the strict law — see
   * shift-gate.ts); this client gate makes the law VISIBLE: the add /
   * adjust / reorder / delete actions are intercepted BEFORE the request
   * (toast + no dialog), and the 403 race is intercepted in onError (the
   * shift cache resyncs so the global bar flips). Demo rows stay free
   * (session-local showcase data — no server write at all). */
  const shiftsEnabled = instance.modules.includes("shifts");
  const shiftQuery = useShift(instance.id, shiftsEnabled);
  const shiftBlocks = shiftsEnabled && shiftQuery.data?.current == null;
  const guardShift = (): boolean => {
    if (shiftBlocks) {
      toast.error(t("shiftGatedToast"));
      return false;
    }
    return true;
  };

  /* ---------------- parsed items (overrides applied) ---------------- */
  const items = useMemo(
    () =>
      data.rows.map((row) => {
        const base = parseInvItem(row.values, row.id, colIx);
        const ov = source === "demo" ? demoOverrides[row.id] : undefined;
        if (!ov) return base;
        const qty = ov.qty ?? base.qty;
        return {
          ...base,
          qty,
          total: Math.round(base.unit * qty * 100) / 100,
          statusKey: ov.statusKey ?? base.statusKey,
        };
      }),
    [data, colIx, demoOverrides, source]
  );
  const itemById = useMemo(() => new Map(items.map((i) => [i.id, i])), [items]);
  const rowById = useMemo(() => new Map(data.rows.map((r) => [r.id, r])), [data]);

  /* KPIs — the whole current source (filters do NOT shrink the KPIs) */
  const stats = useMemo(() => computeInvStats(items), [items]);

  /* ---------------- movement feed ----------------
   * derived entries: STABLE per (instance, source) — seeded on the raw
   * dataset so demo overrides never reshuffle the historical feed;
   * live entries (the owner's own actions) are prepended, freshest first. */
  const rawItems = useMemo(
    () => data.rows.map((row) => parseInvItem(row.values, row.id, colIx)),
    [data, colIx]
  );
  const derivedMoves = useMemo(
    () => deriveInvMovements(`${instance.id}:${MODULE_ID}:moves:${source}`, rawItems, INV_MOVES_COUNT),
    [instance.id, source, rawItems]
  );
  const moves = useMemo(() => {
    const merged = [...liveMoves, ...derivedMoves];
    merged.sort((a, b) => b.at - a.at);
    return merged.slice(0, INV_MOVES_COUNT);
  }, [liveMoves, derivedMoves]);
  const liveIds = useMemo(() => new Set(liveMoves.map((m) => m.id)), [liveMoves]);

  /* ---------------- filtering / sorting / pagination ---------------- */
  const categories = useMemo(
    () =>
      [...new Set(items.map((i) => i.category).filter(Boolean))].sort((a, b) =>
        a.localeCompare(b, lang === "ar" ? "ar" : "en")
      ),
    [items, lang]
  );

  const filtered = useMemo(() => {
    const q = normalizeSearch(query.trim());
    return items.filter((it) => {
      if (statusFilter !== "all" && it.statusKey !== statusFilter) return false;
      if (categoryFilter !== "all" && it.category !== categoryFilter) return false;
      if (!q) return true;
      const hay = normalizeSearch(`${it.item} ${it.sku} ${it.category} ${it.location} ${it.supplier}`);
      return hay.includes(q);
    });
  }, [items, query, statusFilter, categoryFilter]);

  const statusCounts = useMemo(() => {
    const m = new Map<string, number>();
    for (const it of items) m.set(it.statusKey, (m.get(it.statusKey) ?? 0) + 1);
    return m;
  }, [items]);

  const sorted = useMemo(() => {
    const arr = [...filtered];
    switch (sortKey) {
      case "qtyDesc":
        arr.sort((a, b) => b.qty - a.qty);
        break;
      case "qtyAsc":
        /* most critical first — zero stock on top */
        arr.sort((a, b) => a.qty - b.qty || b.total - a.total);
        break;
      case "name":
        arr.sort((a, b) => (a.item || "").localeCompare(b.item || "", lang === "ar" ? "ar" : "en"));
        break;
      default:
        arr.sort((a, b) => b.total - a.total);
    }
    return arr;
  }, [filtered, sortKey, lang]);

  const pages = Math.max(1, Math.ceil(sorted.length / INV_PAGE_SIZE));
  const safePage = Math.min(page, pages - 1);
  const pageItems = sorted.slice(safePage * INV_PAGE_SIZE, safePage * INV_PAGE_SIZE + INV_PAGE_SIZE);

  /* valuation — computed from the CURRENT FILTERED set (per the spec) */
  const valStats = useMemo(() => computeInvStats(sorted), [sorted]);

  /* ---------------- record-code machinery (same law as the generic) ------ */
  const idColIndex = data.cols.findIndex((c) => c.kind === "id");
  const allCodes = useMemo(() => {
    if (idColIndex < 0) return [] as string[];
    const codes: string[] = [];
    for (const row of demoData.rows) {
      const code = row.values[idColIndex];
      if (code) codes.push(code);
    }
    for (const row of records) {
      const code = row.values[idColIndex];
      if (code) codes.push(code);
    }
    return codes;
  }, [demoData, records, idColIndex]);
  const suggestedCode =
    idColIndex >= 0 ? nextRecordCode(codePrefixFor(MODULE_ID), allCodes) : null;

  /* ---------------- workspace identity ---------------- */
  const system = SYSTEM_MAP[instance.systemId];
  const cat = system ? CATEGORY_MAP[system.c] : undefined;
  const c1 = cat?.c1 ?? "#6d5dfb";
  const c2 = cat?.c2 ?? "#0ea5e9";
  const mod = MODULE_MAP[MODULE_ID];
  const moduleName = moduleDisplayName(MODULE_ID, instance.systemId, lang);
  const systemName = system ? (lang === "ar" ? system.nameAr : system.nameEn) : instance.systemId;
  const categoryName = cat ? (lang === "ar" ? cat.nameAr : cat.nameEn) : "";

  /* ---------------- dialogs state ---------------- */
  const [recordDialog, setRecordDialog] = useState<{ record: InvRecordDraft | null } | null>(null);
  const [adjustItem, setAdjustItem] = useState<InvItem | null>(null);
  const [pendingDelete, setPendingDelete] = useState<InvItem | null>(null);
  const [printDoc, setPrintDoc] = useState<PrintDoc | null>(null);

  /* ---------------- mutations ---------------- */
  const invalidateRecords = () => {
    void queryClient.invalidateQueries({ queryKey: ["module-records", instance.id, MODULE_ID] });
  };

  /* ROUND 141 — the shared 403 SHIFT_REQUIRED race interceptor: the
   * submit gate above can miss a just-closed shift; the server refusal
   * lands here instead — resync the shift cache (the global bar flips)
   * and speak the Arabic law instead of the raw English error. */
  const shiftRace = (e: Error): boolean => {
    if (e instanceof ApiError && e.status === 403 && (e.code === "SHIFT_REQUIRED" || e.message.includes("SHIFT_REQUIRED"))) {
      void queryClient.invalidateQueries({ queryKey: ["shifts", instance.id] });
      toast.error(t("shiftGatedTrySave"));
      return true;
    }
    return false;
  };

  /* add / edit a real record — an EDIT whose qty changed also logs a live
   * adjustment movement (previous → new qty, client-side) */
  const saveRecord = useMutation({
    mutationFn: (payload: {
      recordId: string | null;
      values: string[];
      statusKey: string;
      prevQty?: number;
      itemName?: string;
      sku?: string;
    }) =>
      payload.recordId
        ? updateModuleRecord(instance.id, payload.recordId, {
            values: payload.values,
            statusKey: payload.statusKey,
          })
        : createModuleRecord(instance.id, {
            moduleId: MODULE_ID,
            values: payload.values,
            statusKey: payload.statusKey,
          }),
    onSuccess: (_data, payload) => {
      invalidateRecords();
      setSource("mine");
      setRecordDialog(null);
      toast.success(payload.recordId ? t("modRecUpdated") : t("modRecSaved"));
      if (payload.recordId && payload.prevQty !== undefined && payload.itemName) {
        const newQty = Math.max(0, Math.round(Number(payload.values[colIx.qty]) || 0));
        if (newQty !== payload.prevQty) {
          pushLiveMove({
            id: `live-${payload.recordId}-${Date.now()}`,
            itemId: payload.recordId,
            item: payload.itemName,
            sku: payload.sku ?? "",
            dir: "adjust",
            delta: newQty - payload.prevQty,
            reasonKey: "invReasonCorrection",
            at: Date.now(),
          });
        }
      }
    },
    onError: (e: Error) => {
      /* 409 RECORD_CONFLICT — refresh so the owner sees the live stock */
      if (e instanceof ApiError && e.status === 409) invalidateRecords();
      if (shiftRace(e)) return;
      toast.error(e.message || t("modRecSaveErr"));
    },
  });

  const removeRecord = useMutation({
    mutationFn: (recordId: string) => deleteModuleRecord(instance.id, recordId),
    onSuccess: () => {
      invalidateRecords();
      setPendingDelete(null);
      toast.success(t("modRecDeleted"));
    },
    onError: (e: Error) => {
      if (shiftRace(e)) return;
      toast.error(e.message || t("modRecDeleteErr"));
    },
  });

  /* «طلب شراء» on a real row — statusKey-only partial update */
  const reorderRecord = useMutation({
    mutationFn: (payload: { recordId: string; name: string }) =>
      updateModuleRecord(instance.id, payload.recordId, { statusKey: "ordered" }),
    onSuccess: (_data, payload) => {
      invalidateRecords();
      toast.success(t("invReorderDone", { name: payload.name }));
    },
    onError: (e: Error) => {
      if (e instanceof ApiError && e.status === 409) invalidateRecords();
      if (shiftRace(e)) return;
      toast.error(e.message || t("modRecSaveErr"));
    },
  });

  /* quick stock adjust on a real row — values + statusKey, and the live
   * movement composed at submit time rides along to onSuccess */
  const adjustRecord = useMutation({
    mutationFn: (payload: {
      recordId: string;
      values: string[];
      statusKey: string;
      move: InvMove;
      newQty: number;
    }) =>
      updateModuleRecord(instance.id, payload.recordId, {
        values: payload.values,
        statusKey: payload.statusKey,
      }),
    onSuccess: (_data, payload) => {
      invalidateRecords();
      pushLiveMove(payload.move);
      setAdjustItem(null);
      toast.success(t("invAdjustSaved", { qty: fmtNum(payload.newQty, lang) }));
    },
    onError: (e: Error) => {
      if (e instanceof ApiError && e.status === 409) invalidateRecords();
      if (shiftRace(e)) return;
      toast.error(e.message || t("invAdjustErr"));
    },
  });

  /* ---------------- action handlers ---------------- */
  const backToModules = () => {
    setActiveModuleId(null);
    setDashView("modules");
  };

  const handleSaveRecord = (payload: { recordId: string | null; values: string[]; statusKey: string }) => {
    /* ROUND 141 — the shift law: real-row writes never leave the browser
     * while no shift is open (demo rows never reach this handler — the
     * demo tab's adds are session-local). */
    if (!guardShift()) return;
    const draft = recordDialog?.record ?? null;
    saveRecord.mutate({
      ...payload,
      prevQty: draft ? Math.max(0, Math.round(Number(draft.values[colIx.qty]) || 0)) : undefined,
      itemName: draft ? draft.values[colIx.item] : undefined,
      sku: draft ? draft.values[colIx.sku] : undefined,
    });
  };

  const applyReorder = (id: string) => {
    const it = itemById.get(id);
    if (!it) return;
    if (source === "mine") {
      /* ROUND 141 — the shift gate (real-row write). */
      if (!guardShift()) return;
      reorderRecord.mutate({ recordId: id, name: it.item || it.sku || "—" });
    } else {
      setDemoOverrides((prev) => ({
        ...prev,
        [id]: { ...prev[id], statusKey: "ordered" },
      }));
      toast.success(t("invReorderDone", { name: it.item || "—" }));
    }
  };

  const applyAdjust = (item: InvItem, dir: "in" | "out", amount: number, reasonKey: InvReasonKey) => {
    const row = rowById.get(item.id);
    if (!row) return;
    const newQty = Math.max(0, dir === "in" ? item.qty + amount : item.qty - amount);
    const newStatus = statusForQty(newQty, item.reorder, item.statusKey);
    const move: InvMove = {
      id: `live-${item.id}-${Date.now()}`,
      itemId: item.id,
      item: item.item,
      sku: item.sku,
      dir,
      delta: newQty - item.qty,
      reasonKey,
      at: Date.now(),
    };
    if (source === "demo") {
      setDemoOverrides((prev) => ({
        ...prev,
        [item.id]: { ...prev[item.id], qty: newQty, statusKey: newStatus },
      }));
      pushLiveMove(move);
      setAdjustItem(null);
      toast.success(t("invAdjustSaved", { qty: fmtNum(newQty, lang) }));
      return;
    }
    /* ROUND 141 — the shift gate (real-row write). */
    if (!guardShift()) return;
    const nextValues = row.values.map((v, i) => {
      if (i === colIx.qty) return String(newQty);
      if (i === colIx.total) return (item.unit * newQty).toFixed(2);
      if (i === colIx.status) return newStatus;
      return v;
    });
    adjustRecord.mutate({
      recordId: item.id,
      values: nextValues,
      statusKey: newStatus,
      move,
      newQty,
    });
  };

  /* professional record printing — the row feeds the formal document
   * preview (letterhead + field table + status stamp).
   * ROUND 141 (㉕) — the structured payment ledger + the money-column grand
   * total ride the doc (the settlement strip prints on the paper). */
  const buildPrintDoc = (row: { values: string[]; statusKey: string; payments?: import("@/lib/payment-methods").PaymentEntry[] }) => {
    const fields: PrintDoc["fields"] = [];
    data.cols.forEach((col, i) => {
      const value = row.values[i] ?? "";
      if (col.kind === "status") return; /* rendered as the stamp below */
      fields.push({
        label: lang === "ar" ? col.ar : col.en,
        value,
        kind: col.kind === "num" ? "num" : col.kind,
      });
    });
    const st = data.statuses.find((s) => s.key === row.statusKey);
    setPrintDoc({
      title: row.values[colIx.item] ?? "—",
      moduleName,
      fields,
      statusLabel: st ? (lang === "ar" ? st.ar : st.en) : null,
      payments: row.payments ?? [],
      totalMinor: moneyColumnsTotalMinor(data.cols, row.values),
    });
  };

  const printById = (id: string) => {
    const row = rowById.get(id);
    if (row) buildPrintDoc(row);
  };

  /* ROUND 141 — the shift-gated DIALOG OPENERS: on REAL rows the add /
   * edit / adjust / delete dialogs never even open while no shift is
   * live (the toast speaks the law immediately — the precise, visible
   * fix for the quick-add bypass the owner reported). Demo rows open
   * freely (session-local, no server write). */
  const openAddDialog = () => {
    if (source === "mine" && !guardShift()) return;
    setRecordDialog({ record: null });
  };

  const editById = (id: string) => {
    const row = rowById.get(id);
    if (!row) return;
    if (source === "mine" && !guardShift()) return;
    setRecordDialog({ record: { id: row.id, values: row.values, statusKey: row.statusKey } });
  };

  const deleteById = (id: string) => {
    if (source === "mine" && !guardShift()) return;
    setPendingDelete(itemById.get(id) ?? null);
  };

  const adjustById = (id: string) => {
    const it = itemById.get(id);
    if (!it) return;
    if (source === "mine" && !guardShift()) return;
    setAdjustItem(it);
  };

  /* ROUND 141 — the per-row «عرض المنتجات» action: open the catalog
   * viewer FOCUSED on this row's item (pre-filtered + passport expanded). */
  const viewProductsById = (id: string) => {
    const it = itemById.get(id);
    setProductsViewerFocus(it ?? null);
    setProductsViewerOpen(true);
  };

  /* ---------------- CSV export (client-side, real file) ----------------
   * exports the LIVE computed state (overrides included), aligned with
   * the full preset columns. */
  const exportCsv = () => {
    const header = data.cols.map((c) => (lang === "ar" ? c.ar : c.en)).join(",");
    const lines = sorted.map((it) => {
      const cells = data.cols.map((c) => {
        switch (c.key) {
          case "item":
            return it.item;
          case "sku":
            return it.sku;
          case "category":
            return it.category;
          case "qty":
            return String(it.qty);
          case "unit":
            return String(it.unit);
          case "total":
            return String(it.total);
          case "status":
            return it.statusKey;
          case "reorder":
            return String(it.reorder);
          case "location":
            return it.location;
          case "supplier":
            return it.supplier;
          case "expiry":
            return it.expiry;
          default:
            return "";
        }
      });
      return cells.map((v) => (v.includes(",") ? `"${v}"` : v)).join(",");
    });
    const csv = `\uFEFF${[header, ...lines].join("\n")}`;
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${instance.org.name}-${MODULE_ID}-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(t("modExportDone"), { description: `${sorted.length} ${t("modRowsUnit")}` });
  };

  const filtersActive =
    query.trim() !== "" || statusFilter !== "all" || categoryFilter !== "all";
  const resetFilters = () => {
    setQuery("");
    setStatusFilter("all");
    setCategoryFilter("all");
    setPage(0);
  };

  const reorderPendingId =
    source === "mine" && reorderRecord.isPending
      ? (reorderRecord.variables?.recordId ?? null)
      : null;

  const sortOptions: { key: SortKey; label: string }[] = [
    { key: "value", label: t("invSortValue") },
    { key: "qtyDesc", label: t("invSortQtyDesc") },
    { key: "qtyAsc", label: t("invSortQtyAsc") },
    { key: "name", label: t("invSortName") },
  ];

  /* ================================================================ */
  /* render                                                            */
  /* ================================================================ */
  return (
    <div className="space-y-5">
      {/* ---------------- header ---------------- */}
      <div className="glass-card card-in rounded-3xl p-4 sm:p-5">
        <div className="flex flex-wrap items-start gap-3">
          <button
            type="button"
            onClick={backToModules}
            aria-label={t("modBackToModules")}
            className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-slate-200 text-slate-500 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:text-slate-300"
          >
            <CatIcon name="arrow-right" className="h-4 w-4 rtl:rotate-180" />
          </button>

          <span
            className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
            style={{ backgroundImage: grad(c1, c2), boxShadow: `0 14px 30px -12px ${hexAlpha(c1, 0.8)}` }}
          >
            <CatIcon name={mod?.icon ?? "boxes"} className="h-6 w-6" />
          </span>

          <div className="min-w-0 flex-1">
            <h1 className="flex flex-wrap items-center gap-2 font-display text-2xl font-extrabold text-slate-900 dark:text-white">
              {moduleName}
              <Badge className="gap-1 bg-emerald-500/15 text-[10.5px] text-emerald-600 hover:bg-emerald-500/15 dark:text-emerald-400">
                <CatIcon name="circle-check" className="h-3 w-3" />
                {t("dashEnabled")}
              </Badge>
            </h1>
            <p className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-[12px] font-semibold text-slate-500 dark:text-slate-400">
              <span className="inline-flex items-center gap-1">
                <CatIcon name="warehouse" className="h-3.5 w-3.5" />
                {systemName}
              </span>
              {categoryName ? (
                <>
                  <span className="text-slate-300 dark:text-slate-600">·</span>
                  <span>{categoryName}</span>
                </>
              ) : null}
              <span className="text-slate-300 dark:text-slate-600">·</span>
              <span dir="ltr" className="font-mono text-[10.5px] text-slate-400 dark:text-slate-500">
                {MODULE_ID}
              </span>
              <span className="ms-1 inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white/70 px-2 py-0.5 text-[10px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300">
                <CatIcon name="building" className="h-3 w-3" />
                <span className="max-w-40 truncate">{instance.org.name}</span>
              </span>
              {/* live stock-value chip — the headline number, always visible */}
              <span className="inline-flex items-center gap-1.5 rounded-full bg-cyan-500/10 px-2.5 py-0.5 text-[10.5px] font-extrabold text-cyan-700 dark:text-cyan-300">
                <CatIcon name="wallet" className="h-3 w-3" />
                {invMoney(stats.totalValue, currency, lang)}
              </span>
            </p>
          </div>

          <div className="flex shrink-0 items-center gap-2">
            {/* ROUND 131 — «عرض المنتجات داخل المخزون»: the premium catalog
                viewer (full item list with values, locations, health bars) */}
            <Button
              type="button"
              onClick={() => setProductsViewerOpen(true)}
              className="h-10 gap-2 rounded-xl border border-slate-200 bg-white px-4 text-[12px] font-bold text-slate-700 shadow-sm transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200"
            >
              <CatIcon name="boxes" className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">{t("invViewProductsBtn")}</span>
            </Button>
            <Button
              type="button"
              onClick={exportCsv}
              className="h-10 gap-2 rounded-xl border border-slate-200 bg-white px-4 text-[12px] font-bold text-slate-700 shadow-sm transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200"
            >
              <CatIcon name="download" className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">{t("modExportCsv")}</span>
            </Button>
            <Button
              type="button"
              onClick={openAddDialog}
              className="h-10 gap-2 rounded-xl px-4 text-[12px] font-bold text-white shadow-lg transition hover:brightness-110 active:scale-95"
              style={{ backgroundImage: grad(c1, c2) }}
            >
              <CatIcon name="package-plus" className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">{t("modAddRecord")}</span>
            </Button>
          </div>
        </div>
      </div>

      {/* AI insights — the same panel the generic workspace mounts */}
      <AiInsightsPanel instanceId={instance.id} moduleId={MODULE_ID} />

      {/* ---------------- KPI strip (ROUND 136 — unified golden StatCards,
          identical to the POS/products business-suite idiom) ---------------- */}
      <InventoryKpis
        stats={stats}
        currency={currency}
        loading={source === "mine" && recordsQuery.isPending}
      />

      {/* ---------------- stock table ---------------- */}
      <DashCard
        title={t("invTableTitle")}
        icon="table"
        action={
          <span
            dir="ltr"
            className="rounded-full border border-slate-200 bg-slate-50 px-2.5 py-0.5 text-[10.5px] font-extrabold tabular-nums text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-300"
          >
            {fmtNum(sorted.length, lang)}/{fmtNum(items.length, lang)}
          </span>
        }
      >
        {/* toolbar: source tabs + search + status chips + category + sort */}
        <div className="mb-4 space-y-2.5">
          <div className="flex flex-wrap items-center gap-2">
            {/* data source: demo showcase vs MY persisted records */}
            <div
              role="tablist"
              aria-label={t("modRecSourceLabel")}
              className="flex items-center rounded-full border border-slate-200 bg-slate-50 p-0.5 dark:border-white/10 dark:bg-white/[0.04]"
            >
              {(["demo", "mine"] as const).map((tab) => (
                <button
                  key={tab}
                  type="button"
                  role="tab"
                  aria-selected={source === tab}
                  onClick={() => {
                    setSource(tab);
                    setPage(0);
                  }}
                  className={cn(
                    "inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-[11.5px] font-extrabold transition",
                    source === tab
                      ? "text-white shadow-md"
                      : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white"
                  )}
                  style={source === tab ? { backgroundImage: grad(c1, c2) } : undefined}
                >
                  <CatIcon name={tab === "demo" ? "flask-conical" : "database"} className="h-3 w-3" />
                  {tab === "demo" ? t("modRecTabDemo") : t("modRecTabMine")}
                  {tab === "mine" ? (
                    <span dir="ltr" className="rounded-full bg-white/25 px-1.5 text-[10px] tabular-nums">
                      {fmtNum(records.length, lang)}
                    </span>
                  ) : null}
                </button>
              ))}
            </div>

            {/* search — item / SKU / category / location / supplier */}
            <div className="relative min-w-0 flex-1 sm:max-w-xs">
              <CatIcon
                name="search"
                className="pointer-events-none absolute start-3.5 top-1/2 h-[12px] w-[12px] -translate-y-1/2 text-slate-400"
              />
              <Input
                type="search"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setPage(0);
                }}
                placeholder={t("invSearchPh")}
                aria-label={t("invSearchPh")}
                className="h-10 rounded-xl border-slate-200 bg-slate-50/80 ps-10 pe-3 text-[12.5px] font-semibold dark:border-white/10 dark:bg-white/[0.04]"
              />
            </div>

            {/* category filter (derived from the live dataset) */}
            <Select
              value={categoryFilter}
              onValueChange={(v) => {
                setCategoryFilter(v);
                setPage(0);
              }}
            >
              <SelectTrigger className="h-10 w-auto min-w-32 rounded-xl text-[12.5px] font-semibold">
                <SelectValue placeholder={t("invCategoryAll")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("invCategoryAll")}</SelectItem>
                {categories.map((c) => (
                  <SelectItem key={c} value={c}>
                    {c}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* sort */}
            <Select
              value={sortKey}
              onValueChange={(v) => setSortKey(v as SortKey)}
            >
              <SelectTrigger className="h-10 w-auto min-w-32 rounded-xl text-[12.5px] font-semibold">
                <span className="flex items-center gap-1.5 text-slate-400">
                  <CatIcon name="sliders" className="h-3 w-3" />
                  {t("invSortLabel")}:
                </span>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {sortOptions.map((opt) => (
                  <SelectItem key={opt.key} value={opt.key}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {filtersActive ? (
              <button
                type="button"
                onClick={resetFilters}
                className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 px-3 text-[11.5px] font-bold text-slate-500 transition hover:border-rose-300 hover:text-rose-600 active:scale-95 dark:border-white/10 dark:text-slate-400"
              >
                <CatIcon name="x" className="h-3.5 w-3.5" />
                {t("invResetFilters")}
              </button>
            ) : null}
          </div>

          {/* status filter chips with live counts */}
          <div className="flex flex-wrap items-center gap-1.5" role="tablist" aria-label={t("modFilterAll")}>
            <button
              type="button"
              role="tab"
              aria-selected={statusFilter === "all"}
              onClick={() => {
                setStatusFilter("all");
                setPage(0);
              }}
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11px] font-extrabold transition active:scale-95",
                statusFilter === "all"
                  ? "border-transparent bg-slate-900 text-white shadow-md dark:bg-white dark:text-slate-900"
                  : "border-slate-200 text-slate-500 hover:border-slate-300 dark:border-white/10 dark:text-slate-400"
              )}
            >
              {t("invFilterAll")}
              <span dir="ltr" className="tabular-nums opacity-70">{fmtNum(items.length, lang)}</span>
            </button>
            {data.statuses.map((s) => {
              const count = statusCounts.get(s.key) ?? 0;
              const active = statusFilter === s.key;
              return (
                <button
                  key={s.key}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => {
                    setStatusFilter(s.key);
                    setPage(0);
                  }}
                  className={cn(
                    "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11px] font-extrabold transition active:scale-95",
                    active ? "border-transparent shadow-sm" : "border-slate-200 hover:border-slate-300 dark:border-white/10",
                    active ? "" : "text-slate-500 dark:text-slate-400",
                    active &&
                      (s.tone === "emerald"
                        ? "bg-emerald-500/12 text-emerald-700 dark:text-emerald-300"
                        : s.tone === "amber"
                          ? "bg-amber-500/12 text-amber-700 dark:text-amber-300"
                          : s.tone === "rose"
                            ? "bg-rose-500/12 text-rose-700 dark:text-rose-300"
                            : s.tone === "sky"
                              ? "bg-sky-500/12 text-sky-700 dark:text-sky-300"
                              : "bg-violet-500/12 text-violet-700 dark:text-violet-300")
                  )}
                >
                  <span className={cn("h-1.5 w-1.5 rounded-full", TONE_DOT[s.tone])} aria-hidden="true" />
                  {lang === "ar" ? s.ar : s.en}
                  <span dir="ltr" className="tabular-nums opacity-70">{fmtNum(count, lang)}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* table / empty states */}
        {pageItems.length > 0 ? (
          <InventoryTable
            items={pageItems}
            cols={data.cols}
            statuses={data.statuses}
            source={source}
            reorderPendingId={reorderPendingId}
            onAdjust={adjustById}
            onReorder={applyReorder}
            onEdit={editById}
            onDelete={deleteById}
            onPrint={printById}
            onViewProducts={viewProductsById}
          />
        ) : source === "mine" && records.length === 0 ? (
          /* first-run empty state for the REAL records tab */
          <div className="rounded-2xl border border-dashed border-slate-200 py-12 text-center dark:border-white/10">
            <span
              className="mx-auto grid h-14 w-14 place-items-center rounded-2xl text-white shadow-lg"
              style={{ backgroundImage: grad(c1, c2) }}
            >
              <CatIcon name="package-open" className="h-6 w-6" />
            </span>
            <p className="mt-3 font-display text-[15px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("invEmptyTitle")}
            </p>
            <p className="mx-auto mt-1.5 max-w-md text-[12px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {t("invEmptyDesc")}
            </p>
            <Button
              type="button"
              onClick={openAddDialog}
              className="mt-4 h-10 gap-2 rounded-xl px-5 text-[12.5px] font-bold text-white shadow-lg transition hover:brightness-110 active:scale-95"
              style={{ backgroundImage: grad(c1, c2) }}
            >
              <CatIcon name="package-plus" className="h-4 w-4" />
              {t("modRecEmptyCta")}
            </Button>
          </div>
        ) : (
          <div className="rounded-2xl border border-dashed border-slate-200 py-10 text-center dark:border-white/10">
            <span className="mx-auto grid h-11 w-11 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5">
              <CatIcon name="search" className="h-5 w-5" />
            </span>
            <p className="mt-2 text-[12.5px] font-bold text-slate-400 dark:text-slate-500">
              {t("modNoResults")}
            </p>
            {filtersActive ? (
              <button
                type="button"
                onClick={resetFilters}
                className="mt-3 inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 px-4 text-[11.5px] font-bold text-slate-500 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:text-slate-400"
              >
                <CatIcon name="x" className="h-3.5 w-3.5" />
                {t("invResetFilters")}
              </button>
            ) : null}
          </div>
        )}

        {/* pagination */}
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
          <p className="text-[11px] font-semibold text-slate-400 dark:text-slate-500">
            {t("modPageOf", { page: fmtNum(safePage + 1, lang), total: fmtNum(pages, lang) })}
            <span className="mx-1.5 text-slate-300 dark:text-slate-600">·</span>
            {t("modRowsUnit")}: <span dir="ltr" className="tabular-nums font-bold">{sorted.length}</span>
          </p>
          <div className="flex items-center gap-1.5">
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={safePage === 0}
              onClick={() => setPage(safePage - 1)}
              className="h-8 rounded-lg px-3 text-[11.5px] font-bold"
              aria-label={t("modPrevPage")}
            >
              <CatIcon name="chevron-down" className="h-3.5 w-3.5 rtl:rotate-90 ltr:rotate-90" />
              {t("modPrevPage")}
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={safePage >= pages - 1}
              onClick={() => setPage(safePage + 1)}
              className="h-8 rounded-lg px-3 text-[11.5px] font-bold"
              aria-label={t("modNextPage")}
            >
              {t("modNextPage")}
              <CatIcon name="chevron-down" className="h-3.5 w-3.5 rtl:-rotate-90 ltr:-rotate-90" />
            </Button>
          </div>
        </div>

        {/* data-source note (demo vs real) + session-local demo note */}
        {source === "demo" ? (
          <div className="mt-3 rounded-xl bg-amber-500/10 p-2.5">
            <p className="text-[10.5px] font-bold leading-relaxed text-amber-700 dark:text-amber-300">
              <CatIcon name="flask-conical" className="me-1 inline h-3 w-3" />
              {t("modDemoNote")} — {t("modDemoNoteDesc")}
            </p>
            {Object.keys(demoOverrides).length > 0 ? (
              <p className="mt-1 text-[10.5px] font-bold leading-relaxed text-amber-600/90 dark:text-amber-300/90">
                <CatIcon name="circle-alert" className="me-1 inline h-3 w-3" />
                {t("invDemoLocalNote")}
              </p>
            ) : null}
          </div>
        ) : (
          <p className="mt-3 rounded-xl bg-emerald-500/10 p-2.5 text-[10.5px] font-bold leading-relaxed text-emerald-700 dark:text-emerald-300">
            <CatIcon name="database" className="me-1 inline h-3 w-3" />
            {t("modRecRealNote")}
          </p>
        )}
      </DashCard>

      {/* ---------------- movements + thresholds ---------------- */}
      <div className="grid gap-4 lg:grid-cols-2">
        <InventoryMovements moves={moves} liveIds={liveIds} />
        <InventoryThresholds
          items={items}
          statuses={data.statuses}
          reorderPendingId={reorderPendingId}
          onReorder={applyReorder}
        />
      </div>

      {/* ---------------- valuation ---------------- */}
      <InventoryValuation stats={valStats} currency={currency} />

      {/* ---------------- add / edit record dialog ---------------- */}
      {recordDialog ? (
        <InvRecordDialog
          key={recordDialog.record?.id ?? "new"}
          record={recordDialog.record}
          suggestedCode={suggestedCode}
          cols={data.cols}
          statuses={data.statuses}
          moduleName={moduleName}
          currency={currency}
          c1={c1}
          c2={c2}
          saving={saveRecord.isPending}
          onSave={handleSaveRecord}
          onClose={() => setRecordDialog(null)}
        />
      ) : null}

      {/* ---------------- quick stock adjust dialog ---------------- */}
      {adjustItem ? (
        <InvAdjustDialog
          key={adjustItem.id}
          item={adjustItem}
          statuses={data.statuses}
          currency={currency}
          c1={c1}
          c2={c2}
          saving={adjustRecord.isPending}
          onApply={({ dir, amount, reasonKey }) => applyAdjust(adjustItem, dir, amount, reasonKey)}
          onClose={() => setAdjustItem(null)}
        />
      ) : null}

      {/* ---------------- professional record print ---------------- */}
      <RecordPrintDialog
        doc={printDoc}
        instance={instance}
        logoUrl={siteQuery.data?.content.logoUrl ?? ""}
        signatureUrl={siteQuery.data?.content.signatureUrl ?? ""}
        stampUrl={siteQuery.data?.content.stampUrl ?? ""}
        signatureScale={siteQuery.data?.content.signatureScale ?? 1}
        stampScale={siteQuery.data?.content.stampScale ?? 1}
        open={printDoc !== null}
        onOpenChange={(o) => !o && setPrintDoc(null)}
      />

      {/* ---------------- ROUND 131 — «عرض المنتجات داخل المخزون» viewer ----------------
          ROUND 141 — the per-row action opens it FOCUSED on the item. */}
      <InventoryProductsViewer
        open={productsViewerOpen}
        onOpenChange={(o) => {
          setProductsViewerOpen(o);
          if (!o) setProductsViewerFocus(null);
        }}
        items={items}
        currency={currency}
        c1={c1}
        c2={c2}
        focusItem={productsViewerFocus}
        statusLabels={Object.fromEntries(
          data.statuses.map((s) => [s.key, { label: lang === "ar" ? s.ar : s.en, tone: s.tone }])
        )}
      />

      {/* ---------------- delete record confirm ---------------- */}
      <AlertDialog open={pendingDelete !== null} onOpenChange={(o) => !o && setPendingDelete(null)}>
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-linear-to-br from-rose-500 to-rose-600 text-white shadow-lg shadow-rose-500/25"
                aria-hidden="true"
              >
                <CatIcon name="trash-2" className="h-[15px] w-[15px]" />
              </span>
              {t("modRecDeleteTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("modRecDeleteMsg", { name: moduleName })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          {pendingDelete ? (
            <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50/60 p-3 dark:border-white/15 dark:bg-white/[0.03]">
              <div className="flex flex-wrap items-center gap-2">
                <span
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white"
                  style={{ backgroundImage: grad(c1, c2) }}
                  aria-hidden="true"
                >
                  <CatIcon name="package" className="h-4 w-4" />
                </span>
                {[pendingDelete.item, pendingDelete.sku, pendingDelete.category]
                  .filter(Boolean)
                  .map((v, i) => (
                    <span
                      key={i}
                      dir={i === 1 ? "ltr" : undefined}
                      className={cn(
                        "max-w-48 truncate rounded-full bg-slate-100 px-2.5 py-1 text-[11px] font-bold text-slate-600 dark:bg-white/10 dark:text-slate-300",
                        i === 1 && "font-mono"
                      )}
                    >
                      {v.length > 28 ? `${v.slice(0, 28)}…` : v}
                    </span>
                  ))}
              </div>
            </div>
          ) : null}
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={removeRecord.isPending}>
              {t("modRecCancelBtn")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => pendingDelete && removeRecord.mutate(pendingDelete.id)}
              disabled={removeRecord.isPending}
              className="h-10 rounded-xl bg-rose-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60"
            >
              {removeRecord.isPending ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : null}
              {t("modRecDeleteBtn")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
