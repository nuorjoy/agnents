"use client";

/**
 * Ashrilogic — inventory movements panel (ROUND 78).
 *
 * «حركة المخزون» — the live+derived feed of inbound / outbound /
 * adjustment entries:
 *   - DERIVED entries: a stable, seeded list computed from the dataset
 *     (src/lib/inventory-data.ts deriveInvMovements — no new DB table).
 *   - LIVE entries: logged client-side by the workspace whenever the
 *     owner quick-adjusts or edits a real row's qty (previous → new),
 *     flagged with a pulsing «مباشر» chip.
 * Rows: direction icon tile (emerald إدخال / rose إخراج / sky تعديل),
 * item + LTR SKU, signed delta (Arabic-Indic via fmtNum), reason chip
 * and a relative date. Scrolls within max-height with the nice scrollbar.
 */
import { CatIcon } from "@/components/icon";
import { DashCard, relativeTime } from "@/components/dashboard/dash-shared";
import { useT } from "@/lib/i18n";
import type { InvMove, InvMoveDir } from "@/lib/inventory-data";
import { cn, fmtNum } from "@/lib/utils";

const DIR_STYLE: Record<InvMoveDir, { icon: string; grad: string; chip: string; labelKey: "invMoveIn" | "invMoveOut" | "invMoveAdjust" }> = {
  in: { icon: "log-in", grad: "linear-gradient(135deg,#10b981,#047857)", chip: "bg-emerald-500/12 text-emerald-700 dark:text-emerald-300", labelKey: "invMoveIn" },
  out: { icon: "log-out", grad: "linear-gradient(135deg,#f43f5e,#e11d48)", chip: "bg-rose-500/12 text-rose-700 dark:text-rose-300", labelKey: "invMoveOut" },
  adjust: { icon: "sliders", grad: "linear-gradient(135deg,#0ea5e9,#0369a1)", chip: "bg-sky-500/12 text-sky-700 dark:text-sky-300", labelKey: "invMoveAdjust" },
};

export function InventoryMovements({
  moves,
  liveIds,
}: {
  moves: InvMove[];
  liveIds: Set<string>;
}) {
  const { t, lang } = useT();

  return (
    <DashCard
      title={t("invMovesTitle")}
      icon="clock-rotate-left"
      action={
        <span
          dir="ltr"
          title={t("invMovesChip", { count: fmtNum(moves.length, lang) })}
          className="rounded-full border border-slate-200 bg-slate-50 px-2.5 py-0.5 text-[10.5px] font-extrabold tabular-nums text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-300"
        >
          {fmtNum(moves.length, lang)}
        </span>
      }
    >
      <p className="mb-3 text-[11px] font-bold leading-relaxed text-slate-400 dark:text-slate-500">
        {t("invMovesDesc")}
      </p>

      {moves.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-200 bg-slate-50/40 p-5 text-center dark:border-white/10 dark:bg-white/[0.02]">
          <span className="mx-auto grid h-11 w-11 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5">
            <CatIcon name="clock-rotate-left" className="h-5 w-5" />
          </span>
          <p className="mx-auto mt-2 max-w-xs text-[11.5px] font-bold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("invMovesEmpty")}
          </p>
        </div>
      ) : (
        <ul className="max-h-96 space-y-2 overflow-y-auto nice-scroll pe-1" aria-label={t("invMovesTitle")}>
          {moves.map((mv) => {
            const dir = DIR_STYLE[mv.dir];
            const live = liveIds.has(mv.id);
            return (
              <li
                key={mv.id}
                className={cn(
                  "flex items-center gap-3 rounded-2xl border p-2.5 transition-colors",
                  live
                    ? "border-emerald-300/60 bg-emerald-50/40 dark:border-emerald-500/20 dark:bg-emerald-500/[0.06]"
                    : "border-slate-200/80 bg-white/60 hover:border-brand-200 dark:border-white/[0.07] dark:bg-white/[0.02]"
                )}
              >
                {/* direction tile */}
                <span
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
                  style={{ backgroundImage: dir.grad }}
                  aria-hidden="true"
                >
                  <CatIcon name={dir.icon} className="h-4 w-4" />
                </span>
                {/* item + reason */}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[12px] font-extrabold text-slate-800 dark:text-slate-100">
                    {mv.item}
                  </p>
                  <p className="mt-0.5 flex flex-wrap items-center gap-1.5">
                    <span
                      className={cn("inline-flex items-center gap-1 rounded-full px-1.5 py-px text-[9.5px] font-extrabold", dir.chip)}
                    >
                      {t(dir.labelKey)}
                    </span>
                    <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-1.5 py-px text-[9.5px] font-bold text-slate-500 dark:bg-white/10 dark:text-slate-400">
                      {t(mv.reasonKey)}
                    </span>
                    {live ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 px-1.5 py-px text-[9.5px] font-extrabold text-emerald-600 dark:text-emerald-300">
                        <span className="h-1 w-1 animate-pulse rounded-full bg-emerald-500" aria-hidden="true" />
                        {t("invMoveLive")}
                      </span>
                    ) : null}
                    {mv.sku ? (
                      <span dir="ltr" className="font-mono text-[9.5px] font-bold text-slate-400 dark:text-slate-500">
                        {mv.sku}
                      </span>
                    ) : null}
                  </p>
                </div>
                {/* delta + time */}
                <div className="shrink-0 text-end">
                  <p
                    dir="ltr"
                    className={cn(
                      "text-[13px] font-extrabold tabular-nums",
                      mv.delta > 0
                        ? "text-emerald-600 dark:text-emerald-400"
                        : mv.delta < 0
                          ? "text-rose-600 dark:text-rose-400"
                          : "text-slate-400"
                    )}
                  >
                    {mv.delta > 0 ? "+" : ""}
                    {fmtNum(mv.delta, lang)}
                    <span className="ms-1 text-[9px] font-bold text-slate-400 dark:text-slate-500">{t("invMoveUnit")}</span>
                  </p>
                  <p className="mt-0.5 text-[9.5px] font-semibold text-slate-400 dark:text-slate-500">
                    {relativeTime(new Date(mv.at), lang)}
                  </p>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </DashCard>
  );
}
