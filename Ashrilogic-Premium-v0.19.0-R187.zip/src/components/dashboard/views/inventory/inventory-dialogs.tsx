"use client";

/**
 * Ashrilogic — inventory dialogs (ROUND 78).
 *
 * Two premium dialogs for the dedicated المخزون workspace:
 *
 *  1. InvRecordDialog — add/edit a REAL inventory record (form aligned
 *     with the extended preset cols: item / SKU / category / qty / unit
 *     cost / status / reorder point / location / supplier / expiry).
 *     Inventory-aware: القيمة auto-computes from qty × unit cost and the
 *     suggested status chip follows the workspace status law.
 *
 *  2. InvAdjustDialog — the quick stock adjust (إدخال / إخراج): picks a
 *     movement type + amount + reason, previews the new quantity and the
 *     auto-status, then applies (the parent persists real rows through
 *     updateModuleRecord and logs the movement client-side; demo rows
 *     apply to local session state).
 */
import { useState, type FormEvent } from "react";
import { CatIcon } from "@/components/icon";
import { useT } from "@/lib/i18n";
import type { ColDef, StatusDef } from "@/lib/module-data";
import {
  INV_REASONS_IN,
  INV_REASONS_OUT,
  statusForQty,
  type InvItem,
  type InvReasonKey,
} from "@/lib/inventory-data";
import { cn, fmtNum, grad, hexAlpha } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PremiumDateInput } from "@/components/ui/premium-date-input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { TONE_DOT, TONE_STYLE, invStatusLabel } from "./inv-shared";

/* ================================================================== */
/* 1. add / edit record                                                */
/* ================================================================== */

export type InvRecordDraft = { id: string; values: string[]; statusKey: string };

function parseNum(v: string | undefined): number {
  const n = Number(String(v ?? "").replace(/[^\d.-]/g, ""));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

export function InvRecordDialog({
  record,
  suggestedCode,
  cols,
  statuses,
  moduleName,
  currency,
  c1,
  c2,
  saving,
  onSave,
  onClose,
}: {
  record: InvRecordDraft | null;
  suggestedCode: string | null;
  cols: ColDef[];
  statuses: StatusDef[];
  moduleName: string;
  currency: string;
  c1: string;
  c2: string;
  saving: boolean;
  onSave: (payload: { recordId: string | null; values: string[]; statusKey: string }) => void;
  onClose: () => void;
}) {
  const { lang, t } = useT();
  const idColIndex = cols.findIndex((c) => c.kind === "id");
  const qtyIndex = cols.findIndex((c) => c.key === "qty");
  const unitIndex = cols.findIndex((c) => c.key === "unit");
  const totalIndex = cols.findIndex((c) => c.key === "total");
  const reorderIndex = cols.findIndex((c) => c.key === "reorder");

  const [values, setValues] = useState<string[]>(() =>
    cols.map((_c, i) =>
      record?.values[i] ?? (i === idColIndex && !record && suggestedCode ? suggestedCode : "")
    )
  );
  const [statusKey, setStatusKey] = useState(record?.statusKey ?? "");
  const statusIndex = cols.findIndex((c) => c.kind === "status");
  const canSave = values.some((v) => v.trim() !== "");

  const setValue = (i: number, v: string) => setValues((prev) => prev.map((p, pi) => (pi === i ? v : p)));

  /* live-computed value + suggested status (the workspace invariant) */
  const qtyNum = parseNum(values[qtyIndex]);
  const unitNum = parseNum(values[unitIndex]);
  const reorderNum = parseNum(values[reorderIndex]) || 25;
  const computedTotal = qtyNum * unitNum;
  const suggestedStatus =
    qtyNum <= 0 ? "out" : statusForQty(qtyNum, reorderNum);
  const suggestedStatusDef = statuses.find((s) => s.key === suggestedStatus);

  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!canSave) return;
    const next = values.map((v, i) => {
      /* القيمة is always the workspace-computed qty × unit cost */
      if (i === totalIndex && qtyNum > 0 && unitNum > 0) return computedTotal.toFixed(2);
      return v;
    });
    onSave({
      recordId: record?.id ?? null,
      values: next.map((v, i) => (i === statusIndex ? statusKey : v)),
      statusKey,
    });
  };

  const labelOf = (col: ColDef): string => (lang === "ar" ? col.ar : col.en);

  return (
    <Dialog open={true} onOpenChange={(o) => !o && onClose()}>
      <DialogContent
        dir={lang === "ar" ? "rtl" : "ltr"}
        className="max-h-[85vh] max-w-lg overflow-y-auto rounded-3xl nice-scroll"
      >
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
            <span
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg"
              style={{ backgroundImage: grad(c1, c2), boxShadow: `0 10px 24px -10px ${hexAlpha(c1, 0.9)}` }}
              aria-hidden="true"
            >
              <CatIcon name={record ? "pencil" : "package-plus"} className="h-4 w-4" />
            </span>
            {record ? t("modRecEditTitle") : t("modRecAddTitle")}
          </DialogTitle>
          <DialogDescription className="text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
            {record
              ? t("modRecEditDesc", { name: moduleName })
              : t("modRecAddDesc", { name: moduleName })}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={submit} className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2">
            {cols.map((col, i) => {
              if (col.kind === "status") {
                if (statuses.length === 0) return null;
                return (
                  <div key={col.key} className="space-y-1.5 sm:col-span-2">
                    <label
                      htmlFor="inv-rec-status"
                      className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
                    >
                      <CatIcon name="badge-check" className="h-3 w-3 text-slate-400" aria-hidden="true" />
                      {labelOf(col)}
                    </label>
                    <Select
                      value={statusKey === "" ? "__none__" : statusKey}
                      onValueChange={(v) => setStatusKey(v === "__none__" ? "" : v)}
                    >
                      <SelectTrigger id="inv-rec-status" className="h-10 rounded-xl text-[12.5px] font-semibold">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="__none__">
                          <span className="flex items-center gap-2 text-slate-400">
                            <span className="h-2 w-2 rounded-full bg-slate-300 dark:bg-slate-600" aria-hidden="true" />
                            {t("modRecStatusNone")}
                          </span>
                        </SelectItem>
                        {statuses.map((s) => (
                          <SelectItem key={s.key} value={s.key}>
                            <span className="flex items-center gap-2">
                              <span className={cn("h-2 w-2 rounded-full", TONE_DOT[s.tone])} aria-hidden="true" />
                              {lang === "ar" ? s.ar : s.en}
                            </span>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {/* suggested status follows the qty-vs-reorder law */}
                    {suggestedStatusDef ? (
                      <p className="flex items-center gap-1 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                        <CatIcon name="sparkles" className="h-3 w-3 shrink-0" />
                        {t("invRecStatusSuggest", {
                          status: invStatusLabel(suggestedStatusDef.key, statuses, lang),
                        })}
                      </p>
                    ) : null}
                  </div>
                );
              }
              /* القيمة is auto-computed (qty × unit) — display, not an input */
              if (col.key === "total") {
                return (
                  <div key={col.key} className="space-y-1.5">
                    <label className="flex flex-wrap items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                      {labelOf(col)}
                      <span
                        dir="ltr"
                        className="rounded-full bg-slate-100 px-1.5 py-px text-[11px] font-bold text-slate-500 dark:bg-white/10 dark:text-slate-400"
                      >
                        {currency}
                      </span>
                    </label>
                    <div className="flex h-10 items-center justify-end gap-2 rounded-xl border border-dashed border-slate-300 bg-slate-50/70 px-3 dark:border-white/15 dark:bg-white/[0.03]">
                      <CatIcon name="sigma" className="h-3.5 w-3.5 text-slate-400" aria-hidden="true" />
                      <span dir="ltr" className="font-display text-[13px] font-extrabold tabular-nums text-slate-700 dark:text-slate-200">
                        {fmtNum(Math.round(computedTotal * 100) / 100, lang)}
                      </span>
                    </div>
                    <p className="text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                      {t("invRecAutoTotal", { total: fmtNum(Math.round(computedTotal * 100) / 100, lang) })}
                    </p>
                  </div>
                );
              }
              const numeric = col.kind === "num" || col.kind === "money";
              const isIdCol = col.kind === "id";
              const isDateCol = col.kind === "date";
              return (
                <div key={col.key} className="space-y-1.5">
                  <label
                    htmlFor={`inv-rec-${col.key}`}
                    className="flex flex-wrap items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
                  >
                    {labelOf(col)}
                    {col.kind === "money" ? (
                      <span
                        dir="ltr"
                        className="rounded-full bg-slate-100 px-1.5 py-px text-[11px] font-bold text-slate-500 dark:bg-white/10 dark:text-slate-400"
                      >
                        {currency}
                      </span>
                    ) : null}
                    {isIdCol && !record && suggestedCode ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-brand-500/10 px-1.5 py-px text-[10px] font-extrabold text-brand-600 dark:bg-brand-500/15 dark:text-brand-300">
                        <span className="h-1 w-1 animate-pulse rounded-full bg-brand-500" aria-hidden="true" />
                        {t("recCodeAutoChip")}
                      </span>
                    ) : null}
                  </label>
                  {/* date columns ride the shared premium date field (R163):
                      brand calendar tile at the field's far right in Arabic,
                      native picker, clear-X + Arabic long-form hint built in. */}
                  {isDateCol ? (
                    <PremiumDateInput
                      id={`inv-rec-${col.key}`}
                      value={values[i] ?? ""}
                      onChange={(e) => setValue(i, e.target.value)}
                    />
                  ) : (
                    <Input
                      id={`inv-rec-${col.key}`}
                      type={numeric ? "number" : "text"}
                      step={col.kind === "money" ? "0.01" : col.kind === "num" ? "1" : undefined}
                      min={numeric ? 0 : undefined}
                      value={values[i] ?? ""}
                      onChange={(e) => setValue(i, e.target.value)}
                      dir={numeric || isIdCol ? "ltr" : undefined}
                      placeholder={col.key === "reorder" ? "25" : numeric ? "0" : ""}
                      className={cn(
                        "h-10 rounded-xl text-[12.5px] font-semibold",
                        isIdCol && "font-mono text-start",
                        numeric && "text-end"
                      )}
                    />
                  )}
                  {isIdCol && !record && suggestedCode ? (
                    <p className="flex items-center gap-1 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                      <CatIcon name="sparkles" className="h-3 w-3 shrink-0" />
                      {t("recCodeHint")}
                    </p>
                  ) : null}
                </div>
              );
            })}
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={saving}
              className="h-10 rounded-xl border-slate-200 bg-white px-5 text-[12.5px] font-bold text-slate-700 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200"
            >
              {t("modRecCancelBtn")}
            </Button>
            <Button
              type="submit"
              disabled={!canSave || saving}
              className="h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:opacity-60"
              style={{ backgroundImage: grad(c1, c2) }}
            >
              {saving ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="check" className="h-4 w-4" />
              )}
              {t("modRecSaveBtn")}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

/* ================================================================== */
/* 2. quick stock adjust                                               */
/* ================================================================== */

export function InvAdjustDialog({
  item,
  statuses,
  currency,
  c1,
  c2,
  saving,
  onApply,
  onClose,
}: {
  item: InvItem;
  statuses: StatusDef[];
  currency: string;
  c1: string;
  c2: string;
  saving: boolean;
  onApply: (payload: { dir: "in" | "out"; amount: number; reasonKey: InvReasonKey }) => void;
  onClose: () => void;
}) {
  const { lang, t } = useT();
  const [dir, setDir] = useState<"in" | "out">("in");
  const [amount, setAmount] = useState("10");
  const [reasonKey, setReasonKey] = useState<InvReasonKey>("invReasonPurchase");

  const reasons: readonly InvReasonKey[] = dir === "in" ? INV_REASONS_IN : INV_REASONS_OUT;

  const amountNum = Math.floor(Number(amount.replace(/[^\d]/g, "")));
  const valid = Number.isFinite(amountNum) && amountNum > 0;
  const newQty = Math.max(0, dir === "in" ? item.qty + amountNum : item.qty - amountNum);
  const newStatus = statusForQty(newQty, item.reorder, item.statusKey);
  const newStatusDef = statuses.find((s) => s.key === newStatus);
  const newTotal = item.unit * newQty;
  const curStatusDef = statuses.find((s) => s.key === item.statusKey);

  const pickDir = (next: "in" | "out") => {
    setDir(next);
    setReasonKey(next === "in" ? "invReasonPurchase" : "invReasonInternal");
  };

  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!valid) return;
    onApply({ dir, amount: amountNum, reasonKey });
  };

  return (
    <Dialog open={true} onOpenChange={(o) => !o && onClose()}>
      <DialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="max-h-[85vh] max-w-md overflow-y-auto rounded-3xl nice-scroll">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
            <span
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg"
              style={{ backgroundImage: grad(c1, c2), boxShadow: `0 10px 24px -10px ${hexAlpha(c1, 0.9)}` }}
              aria-hidden="true"
            >
              <CatIcon name="sliders" className="h-4 w-4" />
            </span>
            {t("invAdjustTitle")}
          </DialogTitle>
          <DialogDescription className="text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
            {t("invAdjustDesc")}
          </DialogDescription>
        </DialogHeader>

        {/* item context header */}
        <div className="rounded-2xl border border-slate-200/80 bg-slate-50/60 p-3 dark:border-white/10 dark:bg-white/[0.03]">
          <div className="flex items-center justify-between gap-2">
            <div className="min-w-0">
              <p className="truncate font-display text-[13.5px] font-extrabold text-slate-800 dark:text-slate-100">
                {item.item || "—"}
              </p>
              <p className="mt-0.5 flex items-center gap-1.5 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                {item.sku ? (
                  <span dir="ltr" className="font-mono">{item.sku}</span>
                ) : null}
                {item.location ? <span>· {item.location}</span> : null}
              </p>
            </div>
            {curStatusDef ? (
              <span
                className={cn(
                  "inline-flex shrink-0 items-center gap-1.5 rounded-full px-2 py-0.5 text-[10.5px] font-extrabold",
                  TONE_STYLE[curStatusDef.tone]
                )}
              >
                <span className={cn("h-1.5 w-1.5 rounded-full", TONE_DOT[curStatusDef.tone])} aria-hidden="true" />
                {invStatusLabel(curStatusDef.key, statuses, lang)}
              </span>
            ) : null}
          </div>
          <div className="mt-2 flex items-center justify-between gap-2 border-t border-dashed border-slate-200/80 pt-2 dark:border-white/10">
            <span className="text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
              {t("invAdjustCurrent")}
            </span>
            <span dir="ltr" className="font-display text-[14px] font-extrabold tabular-nums text-slate-800 dark:text-slate-100">
              {fmtNum(item.qty, lang)}
            </span>
          </div>
        </div>

        <form onSubmit={submit} className="space-y-4">
          {/* movement type toggle */}
          <div className="space-y-1.5">
            <p className="text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">{t("invAdjustMode")}</p>
            <div
              role="tablist"
              aria-label={t("invAdjustMode")}
              className="grid grid-cols-2 gap-2"
            >
              {(["in", "out"] as const).map((mode) => {
                const active = dir === mode;
                return (
                  <button
                    key={mode}
                    type="button"
                    role="tab"
                    aria-selected={active}
                    onClick={() => pickDir(mode)}
                    className={cn(
                      "flex h-11 items-center justify-center gap-2 rounded-xl border text-[12px] font-extrabold transition active:scale-95",
                      active
                        ? mode === "in"
                          ? "border-emerald-400 bg-emerald-500/12 text-emerald-700 dark:text-emerald-300"
                          : "border-rose-400 bg-rose-500/12 text-rose-700 dark:text-rose-300"
                        : "border-slate-200 bg-white text-slate-500 hover:border-slate-300 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-400"
                    )}
                  >
                    <CatIcon name={mode === "in" ? "log-in" : "log-out"} className="h-4 w-4" />
                    {t(mode === "in" ? "invMoveIn" : "invMoveOut")}
                  </button>
                );
              })}
            </div>
          </div>

          {/* amount + reason */}
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <label htmlFor="inv-adj-amount" className="text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                {t("invAdjustAmount")}
              </label>
              <Input
                id="inv-adj-amount"
                type="number"
                min={1}
                step={1}
                dir="ltr"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="h-10 rounded-xl text-end text-[12.5px] font-semibold tabular-nums"
              />
              {!valid ? (
                <p className="flex items-center gap-1 text-[10.5px] font-bold text-amber-600 dark:text-amber-400">
                  <CatIcon name="circle-alert" className="h-3 w-3 shrink-0" />
                  {t("invAdjustInvalid")}
                </p>
              ) : null}
            </div>
            <div className="space-y-1.5">
              <label htmlFor="inv-adj-reason" className="text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                {t("invAdjustReason")}
              </label>
              <Select value={reasonKey} onValueChange={(v) => setReasonKey(v as InvReasonKey)}>
                <SelectTrigger id="inv-adj-reason" className="h-10 rounded-xl text-[12.5px] font-semibold">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {reasons.map((rk) => (
                    <SelectItem key={rk} value={rk}>
                      {t(rk)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* new quantity preview */}
          <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50/70 p-3 dark:border-white/15 dark:bg-white/[0.03]">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                {t("invAdjustNewQty")}
              </span>
              <span className="flex items-center gap-2">
                {newStatusDef ? (
                  <span
                    className={cn(
                      "inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[10.5px] font-extrabold",
                      TONE_STYLE[newStatusDef.tone]
                    )}
                  >
                    <span className={cn("h-1.5 w-1.5 rounded-full", TONE_DOT[newStatusDef.tone])} aria-hidden="true" />
                    {invStatusLabel(newStatusDef.key, statuses, lang)}
                  </span>
                ) : null}
                <span dir="ltr" className="font-display text-[15px] font-extrabold tabular-nums text-slate-900 dark:text-white">
                  {fmtNum(newQty, lang)}
                </span>
              </span>
            </div>
            <p className="mt-1.5 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
              {t("invRecAutoTotal", { total: `${fmtNum(Math.round(newTotal * 100) / 100, lang)} ${currency}` })}
            </p>
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={saving}
              className="h-10 rounded-xl border-slate-200 bg-white px-5 text-[12.5px] font-bold text-slate-700 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200"
            >
              {t("modRecCancelBtn")}
            </Button>
            <Button
              type="submit"
              disabled={!valid || saving}
              className="h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:opacity-60"
              style={{ backgroundImage: dir === "in" ? grad("#10b981", "#047857") : grad("#f43f5e", "#e11d48") }}
            >
              {saving ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name={dir === "in" ? "log-in" : "log-out"} className="h-4 w-4" />
              )}
              {t("invAdjustSave")}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
