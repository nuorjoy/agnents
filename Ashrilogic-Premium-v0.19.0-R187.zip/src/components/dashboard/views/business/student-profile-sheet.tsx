"use client";

/**
 * Ashrilogic — the PREMIUM student profile sheet (ROUND 155).
 *
 * The owner's directive:
 *   «في جميع الأنظمة التي تحتوي على وحدة (الطلاب) قم بحذف بروفايل الطالب
 *    كاملاً وتطوير بروفايل احترافي ومميز بطريقة Premium»
 *
 * The students module previously fell through to the generic MODE 4 grouped
 * passport inside RecordDetailSheet — a flat field list with no academic
 * identity. This dedicated sheet replaces it with a premium card-based
 * student profile:
 *
 *   • HEADER  — gradient avatar (initials), student display name, the
 *               bilingual "Student profile" sub-line, Student ID + University
 *               ID chips (mono, RTL bidi-safe), and the academic-standing
 *               status pill (excellent / good / watch / risk).
 *   • ACADEMIC — a 2×N stat-card grid: college, specialization, academic
 *               year, credit hours, and the GPA progress RING (a circular
 *               SVG gauge out of 5, color-graded by standing).
 *   • GUARDIAN — a single rounded card row (guardian name + relation
 *               explainer strip), the "ولي الأمر / Guardian" section.
 *   • ATTENDANCE — a horizontal gradient progress bar with the % + a one-line
 *               attendance-standing note (excellent / good / needs follow-up).
 *   • META     — created-at + last-updated stamp row (parity with the
 *               generic record-detail sheet footer).
 *
 * Purity contract: every value is read off the row by column key (the same
 * ModuleRecordDTO + ColDef[] + StatusDef[] props the parent already passes
 * RecordDetailSheet). Every numeric / ID value renders through the ROUND 133
 * helpers (fmtNum / fmtId with dir={numDir(lang)}/{idDir}) so the Arabic
 * locale shows Arabic-Indic digits with the correct bidi embedding.
 *
 * Bilingual (AR/EN) with full RTL support — the sheet inherits the dialog's
 * dir={lang === "ar" ? "rtl" : "ltr"} from the parent and every text node
 * uses dir="auto" / labelTrack(lang) for the uppercase Latin-tracking
 * micro-labels. The new i18n keys (studentProfileTitle, studentAcademicSection,
 * studentIdLabel, …) live in src/lib/i18n/domains/business.ts in all three
 * locales (AR + EN + HI) for type parity.
 */
import { useT, type I18nKey } from "@/lib/i18n";
import type { ColDef, StatusDef } from "@/lib/module-data";
import type { Lang, ModuleRecordDTO } from "@/lib/types";
import {
  cn,
  fmtId,
  fmtNum,
  grad,
  hexAlpha,
  idDir,
  initial,
  labelTrack,
  numDir,
} from "@/lib/utils";
import { CatIcon } from "@/components/icon";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";

/* ------------------------------------------------------------------ */
/* tone maps — the exact business-suite / inv-shared pill idiom        */
/* ------------------------------------------------------------------ */

const TONE_DOT: Record<string, string> = {
  emerald: "bg-emerald-500",
  amber: "bg-amber-500",
  rose: "bg-rose-500",
  sky: "bg-sky-500",
  violet: "bg-violet-500",
  slate: "bg-slate-400",
};

const TONE_STYLE: Record<string, string> = {
  emerald: "bg-emerald-500/12 text-emerald-700 dark:text-emerald-300",
  amber: "bg-amber-500/12 text-amber-700 dark:text-amber-300",
  rose: "bg-rose-500/12 text-rose-700 dark:text-rose-300",
  sky: "bg-sky-500/12 text-sky-700 dark:text-sky-300",
  violet: "bg-violet-500/12 text-violet-700 dark:text-violet-300",
  slate: "bg-slate-500/12 text-slate-600 dark:text-slate-300",
};

/* the education brand gradient — the exact pair catalog.ts assigns to the
 * `education` category (#6366f1 → #7c3aed), so the student profile sheet
 * visually belongs to its own sector while staying inside the brand family. */
const STUDENT_C = ["#6366f1", "#7c3aed"] as const;

/* per-standing gradient (for the GPA ring + attendance bar) — emerald for
 * excellent, sky for good, amber for watch, rose for risk. The same tones
 * the students preset's statuses already use. */
const STANDING_GRAD: Record<string, [string, string]> = {
  emerald: ["#10b981", "#059669"],
  sky: ["#0ea5e9", "#0284c7"],
  amber: ["#f59e0b", "#d97706"],
  rose: ["#f43f5e", "#be123c"],
  violet: ["#8b5cf6", "#6d5dfb"],
  slate: ["#64748b", "#475569"],
};

type TFunc = (key: I18nKey, vars?: Record<string, string | number>) => string;

/* ------------------------------------------------------------------ */
/* shared atoms (parity with record-detail-sheet)                       */
/* ------------------------------------------------------------------ */

/** created-stamp — medium date + HH:MM, same locale policy. */
function fmtStamp(iso: string, lang: Lang): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  const date = d.toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB", { dateStyle: "medium" });
  const time = d.toLocaleTimeString(lang === "ar" ? "ar-EG" : "en-GB", { hour: "2-digit", minute: "2-digit" });
  return `${date} · ${time}`;
}

/** the tone-colored status pill (business-suite idiom, optional icon). */
function Pill({ tone, label, icon }: { tone: string; label: string; icon?: string }) {
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1 text-[10.5px] font-extrabold",
        TONE_STYLE[tone] ?? TONE_STYLE.slate
      )}
      dir="auto"
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", TONE_DOT[tone] ?? TONE_DOT.slate)} aria-hidden="true" />
      {icon ? <CatIcon name={icon} className="h-3 w-3" /> : null}
      {label}
    </span>
  );
}

/** section heading — gradient icon chip + label + fading gradient rule. */
function SectionLabel({ icon, label, g1, g2, lang }: { icon: string; label: string; g1: string; g2: string; lang: Lang }) {
  return (
    <p className="flex items-center gap-2" dir="auto">
      <span className="grid h-5 w-5 shrink-0 place-items-center rounded-lg text-white" style={{ backgroundImage: grad(g1, g2) }} aria-hidden="true">
        <CatIcon name={icon} className="h-3 w-3" />
      </span>
      <span className={cn("shrink-0 text-[10px] font-extrabold uppercase text-slate-500 dark:text-slate-400", labelTrack(lang))}>{label}</span>
      <span className="h-px min-w-0 flex-1 bg-gradient-to-r from-slate-200 to-transparent dark:from-white/10" aria-hidden="true" />
    </p>
  );
}

/** mini stat card — icon tile + micro label + formatted value (+ extras). */
function StatCard({
  icon,
  label,
  value,
  dir,
  valueClass,
  g1,
  g2,
  lang,
  children,
}: {
  icon: string;
  label: string;
  value: string;
  dir: "rtl" | "ltr" | "auto";
  valueClass?: string;
  g1: string;
  g2: string;
  lang: Lang;
  children?: React.ReactNode;
}) {
  return (
    <div className="min-w-0 rounded-2xl border border-black/5 bg-slate-50/60 p-2.5 dark:border-white/10 dark:bg-white/[0.03]">
      <p className={cn("flex items-center gap-1.5 text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))} dir="auto">
        <span
          className="grid h-4 w-4 shrink-0 place-items-center rounded-md text-white"
          style={{ backgroundImage: grad(g1, g2) }}
          aria-hidden="true"
        >
          <CatIcon name={icon} className="h-2.5 w-2.5" />
        </span>
        <span className="truncate">{label}</span>
      </p>
      <p dir={dir} className={cn("mt-1 truncate font-display text-[15px] font-extrabold tabular-nums text-slate-800 dark:text-white", valueClass)}>
        {value}
      </p>
      {children}
    </div>
  );
}

/** the always-visible action bar (edit + print + close). */
function SheetFooter({ t, onEdit, onPrint, onClose, g1, g2 }: { t: TFunc; onEdit?: () => void; onPrint?: () => void; onClose: () => void; g1: string; g2: string }) {
  return (
    <div className="flex shrink-0 flex-wrap items-center justify-end gap-2.5 border-t border-slate-200/70 bg-slate-50/60 px-5 py-3.5 dark:border-white/10 dark:bg-white/[0.02]">
      {onEdit ? (
        <Button
          type="button"
          onClick={onEdit}
          className="h-10 gap-2 rounded-xl px-4 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95"
          style={{ backgroundImage: grad(g1, g2) }}
        >
          <CatIcon name="pencil" className="h-4 w-4" />
          {t("bizEditBtn")}
        </Button>
      ) : null}
      {onPrint ? (
        <Button
          type="button"
          variant="outline"
          onClick={onPrint}
          className="h-10 gap-2 rounded-xl px-4 text-[12.5px] font-bold"
        >
          <CatIcon name="printer" className="h-4 w-4" />
          {t("bizPrintBtn")}
        </Button>
      ) : null}
      <Button
        type="button"
        variant="outline"
        onClick={onClose}
        className="h-10 rounded-xl px-5 text-[12.5px] font-extrabold"
      >
        {t("bizClose")}
      </Button>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* the GPA progress ring — a circular SVG gauge out of 5                */
/* ------------------------------------------------------------------ */

/** A circular SVG progress ring for the GPA. The ring fills clockwise from
 *  the top, color-graded by the student's standing (excellent → emerald,
 *  good → sky, watch → amber, risk → rose). The center shows the GPA value
 *  (Arabic-Indic digits in ar) + the "/5" sub-line. */
function GpaRing({ gpa, tone, lang, t }: { gpa: number; tone: string; lang: Lang; t: TFunc }) {
  const [g1, g2] = STANDING_GRAD[tone] ?? STANDING_GRAD.slate;
  /* clamp 0..5 → 0..1 fraction */
  const frac = Math.max(0, Math.min(1, gpa / 5));
  const R = 34;
  const C = 2 * Math.PI * R;
  const dash = C * frac;
  /* gradient id must be stable per render; include the tone so two rings
   * with different tones never share a stale gradient def. */
  const gradId = `gpaGrad-${tone}`;
  return (
    <div className="relative grid h-24 w-24 shrink-0 place-items-center" dir={numDir(lang)}>
      <svg viewBox="0 0 80 80" className="h-24 w-24 -rotate-90" aria-hidden="true">
        <defs>
          <linearGradient id={gradId} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={g1} />
            <stop offset="100%" stopColor={g2} />
          </linearGradient>
        </defs>
        <circle cx="40" cy="40" r={R} fill="none" stroke="currentColor" strokeWidth="6" className="text-slate-200 dark:text-white/10" />
        <circle
          cx="40"
          cy="40"
          r={R}
          fill="none"
          stroke={`url(#${gradId})`}
          strokeWidth="6"
          strokeLinecap="round"
          strokeDasharray={`${dash} ${C}`}
          style={{ transition: "stroke-dasharray 0.6s ease" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span dir={numDir(lang)} className="font-display text-[20px] font-extrabold leading-none tabular-nums text-slate-800 dark:text-white">
          {fmtNum(gpa, lang)}
        </span>
        <span dir={numDir(lang)} className="mt-0.5 text-[9px] font-extrabold uppercase text-slate-400 dark:text-slate-500">
          {t("studentGpaOutOf")}
        </span>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* the premium student profile sheet                                   */
/* ------------------------------------------------------------------ */

/**
 * The premium «ملف الطالب» sheet. Props contract (wired by
 * business-suite.tsx — same shape as RecordDetailSheet so the swap is a
 * one-line conditional):
 *
 *   open / onOpenChange — Radix dialog control
 *   record              — the ModuleRecordDTO to display (null → nothing)
 *   cols / statuses      — the module preset's ColDef[] / StatusDef[]
 *   moduleName           — localized display name of the module
 *   onPrint              — optional print callback (footer print button)
 *   onEdit               — optional edit callback (footer edit button)
 */
export function StudentProfileSheet({
  open,
  onOpenChange,
  record,
  cols,
  statuses,
  moduleName,
  onEdit,
  onPrint,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  record: ModuleRecordDTO | null;
  cols: ColDef[];
  statuses: StatusDef[];
  moduleName: string;
  onEdit?: () => void;
  onPrint?: () => void;
}) {
  const { t, lang } = useT();
  const [g1, g2] = STUDENT_C;

  /* no record → render nothing (the parent usually keeps open === !!record) */
  if (!record) return null;

  /* read every cell by column key (the students preset contract):
   *   code, universityId, name, grade, college, specialization, year,
   *   credits, guardian, attendance, gpa, status */
  const val = (key: string): string => {
    const i = cols.findIndex((c) => c.key === key);
    return i >= 0 ? record.values[i] ?? "" : "";
  };
  const colLabel = (key: string): string => {
    const c = cols.find((x) => x.key === key);
    return c ? (lang === "ar" ? c.ar : c.en) : key;
  };

  const name = val("name").trim() || record.values[2]?.trim() || record.values[0]?.trim() || "—";
  const code = val("code").trim();
  const universityId = val("universityId").trim();
  const grade = val("grade").trim();
  const college = val("college").trim();
  const specialization = val("specialization").trim();
  const year = val("year").trim();
  const creditsRaw = val("credits").trim();
  const guardian = val("guardian").trim();
  const attendanceRaw = val("attendance").trim();
  const gpaRaw = val("gpa").trim();
  const gpa = Number(gpaRaw) || 0;
  /* attendance often stored as "85%" — strip the % to compute the bar. */
  const attendancePct = Math.max(0, Math.min(100, Number(attendanceRaw.replace(/[^\d.]/g, "")) || 0));

  const st = statuses.find((s) => s.key === record.statusKey);
  const tone = st?.tone ?? "slate";
  const [ag1, ag2] = STANDING_GRAD[tone] ?? STANDING_GRAD.slate;

  /* the standing headline — a one-line localized verdict driven by tone */
  const standingKey: I18nKey =
    tone === "emerald" ? "studentStatusExcellent"
      : tone === "sky" ? "studentStatusGood"
        : tone === "amber" ? "studentStatusWatch"
          : tone === "rose" ? "studentStatusRisk"
            : "studentStatusGood";
  const standingLabel = t(standingKey);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        dir={lang === "ar" ? "rtl" : "ltr"}
        showCloseButton={false}
        className="flex max-h-[88vh] flex-col gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-xl"
      >
        {/* ---------------- header — gradient avatar + name + IDs + standing ---------------- */}
        <div
          className="relative shrink-0 overflow-hidden border-b border-slate-200/70 px-5 pt-5 pb-4 dark:border-white/10"
          style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(g1, 0.16)}, ${hexAlpha(g2, 0.16)})` }}
        >
          <span
            className="absolute -end-8 -top-14 h-28 w-28 rounded-full"
            style={{ background: `radial-gradient(circle, ${hexAlpha(g1, 0.28)}, transparent 70%)` }}
            aria-hidden="true"
          />
          <span
            className="absolute -start-10 -bottom-16 h-32 w-32 rounded-full"
            style={{ background: `radial-gradient(circle, ${hexAlpha(g2, 0.18)}, transparent 70%)` }}
            aria-hidden="true"
          />
          <div className="relative flex items-center gap-3.5">
            <span
              className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl font-display text-2xl font-extrabold text-white shadow-lg"
              style={{ backgroundImage: grad(g1, g2), boxShadow: `0 12px 28px -12px ${hexAlpha(g1, 0.9)}` }}
              aria-hidden="true"
            >
              {initial(name)}
            </span>
            <div className="min-w-0 flex-1">
              <DialogTitle className="truncate font-display text-[16px] font-extrabold leading-tight text-slate-900 dark:text-white" dir="auto">
                {name}
              </DialogTitle>
              <DialogDescription className="mt-0.5 truncate text-[11.5px] font-bold text-slate-500 dark:text-slate-400" dir="auto">
                {t("studentProfileTitle")} · {moduleName}
              </DialogDescription>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                {st ? <Pill tone={st.tone} label={lang === "ar" ? st.ar : st.en} icon={tone === "emerald" ? "award" : tone === "rose" ? "triangle-alert" : undefined} /> : null}
                {code ? (
                  <span
                    dir={idDir}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-slate-100 px-2 py-1 font-mono text-[10.5px] font-bold tabular-nums text-slate-600 dark:bg-white/10 dark:text-slate-300"
                  >
                    <CatIcon name="hash" className="h-3 w-3 shrink-0 text-slate-400" />
                    {t("studentIdLabel")}: {fmtId(code, lang)}
                  </span>
                ) : null}
                {universityId ? (
                  <span
                    dir={idDir}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-slate-100 px-2 py-1 font-mono text-[10.5px] font-bold tabular-nums text-slate-600 dark:bg-white/10 dark:text-slate-300"
                  >
                    <CatIcon name="graduation-cap" className="h-3 w-3 shrink-0 text-slate-400" />
                    {t("studentUniversityIdLabel")}: {fmtId(universityId, lang)}
                  </span>
                ) : null}
              </div>
            </div>
          </div>
        </div>

        {/* ---------------- body ---------------- */}
        <div className="nice-scroll min-h-0 flex-1 space-y-4 overflow-y-auto px-5 py-4">
          {/* ---------- academic info + GPA ring ---------- */}
          <div className="space-y-2.5">
            <SectionLabel icon="graduation-cap" label={t("studentAcademicSection")} g1={g1} g2={g2} lang={lang} />
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              {/* left — the 4 academic stat cards */}
              <div className="grid grid-cols-2 gap-2.5">
                <StatCard icon="building-2" label={colLabel("college")} value={college || "—"} dir="auto" g1="#6366f1" g2="#4f46e5" lang={lang} />
                <StatCard icon="book-open" label={colLabel("specialization")} value={specialization || "—"} dir="auto" g1="#8b5cf6" g2="#7c3aed" lang={lang} />
                <StatCard icon="calendar-days" label={colLabel("year")} value={year || "—"} dir="auto" g1="#0ea5e9" g2="#0369a1" lang={lang} />
                <StatCard icon="clock-3" label={colLabel("grade")} value={grade || "—"} dir="auto" g1="#64748b" g2="#475569" lang={lang} />
              </div>
              {/* right — the GPA ring card (full-height) */}
              <div
                className="flex items-center justify-between gap-3 rounded-2xl border border-black/5 p-3 dark:border-white/10"
                style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(ag1, 0.1)}, ${hexAlpha(ag2, 0.08)})` }}
              >
                <div className="min-w-0">
                  <p className={cn("flex items-center gap-1 text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))} dir="auto">
                    <CatIcon name="award" className="h-3 w-3 shrink-0" />
                    {t("studentGpaLabel")}
                  </p>
                  <p dir={numDir(lang)} className="mt-1 font-display text-[22px] font-extrabold tabular-nums text-slate-800 dark:text-white">
                    {gpaRaw ? fmtNum(gpa, lang) : "—"}
                    <span className="ms-1 text-[11px] font-bold text-slate-400 dark:text-slate-500">/ 5</span>
                  </p>
                  <p className="mt-0.5 text-[10.5px] font-bold" style={{ color: ag2 }} dir="auto">
                    {standingLabel}
                  </p>
                </div>
                <GpaRing gpa={gpa} tone={tone} lang={lang} t={t} />
              </div>
            </div>
            {/* the credit-hours banner — full width below the grid */}
            <div className="flex items-center justify-between gap-3 rounded-2xl border border-black/5 bg-slate-50/60 px-3.5 py-2.5 dark:border-white/10 dark:bg-white/[0.03]">
              <span className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-400 dark:text-slate-500" dir="auto">
                <span
                  className="grid h-4 w-4 shrink-0 place-items-center rounded-md text-white"
                  style={{ backgroundImage: grad("#10b981", "#059669") }}
                  aria-hidden="true"
                >
                  <CatIcon name="sigma" className="h-2.5 w-2.5" />
                </span>
                {t("studentCreditsLabel")}
              </span>
              <span dir={numDir(lang)} className="font-display text-[16px] font-extrabold tabular-nums text-emerald-600 dark:text-emerald-400">
                {creditsRaw ? fmtNum(Number(creditsRaw) || 0, lang) : "—"}
              </span>
            </div>
          </div>

          {/* ---------- guardian section ---------- */}
          <div className="space-y-2.5">
            <SectionLabel icon="users" label={t("studentGuardianSection")} g1={g1} g2={g2} lang={lang} />
            <div className="flex items-center justify-between gap-3 rounded-2xl border border-black/5 bg-slate-50/60 px-3.5 py-2.5 dark:border-white/10 dark:bg-white/[0.03]">
              <span className="flex items-center gap-2 text-[12px] font-extrabold text-slate-400 dark:text-slate-500" dir="auto">
                <CatIcon name="user-round" className="h-4 w-4 shrink-0 text-slate-400" />
                {colLabel("guardian")}
              </span>
              {guardian ? (
                <span dir="auto" className="font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
                  {guardian}
                </span>
              ) : (
                <span className="text-[12px] font-bold italic text-slate-400" dir="auto">
                  {t("studentNoGuardian")}
                </span>
              )}
            </div>
          </div>

          {/* ---------- attendance section ---------- */}
          <div className="space-y-2.5">
            <SectionLabel icon="calendar-check" label={t("studentAttendanceSection")} g1={g1} g2={g2} lang={lang} />
            <div
              className="rounded-2xl border border-black/5 p-3.5 dark:border-white/10"
              style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(ag1, 0.1)}, ${hexAlpha(ag2, 0.06)})` }}
            >
              <div className="flex items-baseline justify-between gap-3">
                <span className={cn("flex items-center gap-1.5 text-[10.5px] font-extrabold uppercase text-slate-500 dark:text-slate-400", labelTrack(lang))} dir="auto">
                  <CatIcon name="percent" className="h-3 w-3 shrink-0" />
                  {t("studentAttendanceLabel")}
                </span>
                <span dir={numDir(lang)} className="font-display text-[20px] font-extrabold tabular-nums text-slate-800 dark:text-white">
                  {fmtNum(attendancePct, lang)}
                  <span className="ms-1 text-[12px] font-bold text-slate-400">%</span>
                </span>
              </div>
              <div className="mt-2 h-2.5 w-full overflow-hidden rounded-full bg-slate-200/80 dark:bg-white/10">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{ width: `${attendancePct}%`, backgroundImage: grad(ag1, ag2) }}
                />
              </div>
              <p className="mt-1.5 text-[10.5px] font-bold" style={{ color: ag2 }} dir="auto">
                {standingLabel}
              </p>
            </div>
          </div>

          {/* ---------- meta stamps ---------- */}
          <div className="flex flex-wrap items-center gap-2">
            <span
              dir={numDir(lang)}
              className="inline-flex items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/70 px-2.5 py-1 text-[10px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400"
            >
              <CatIcon name="calendar" className="h-3 w-3 shrink-0" />
              {t("studentMetaStamp")} · {fmtStamp(record.updatedAt || record.createdAt, lang)}
            </span>
          </div>
        </div>

        <SheetFooter t={t} onEdit={onEdit} onPrint={onPrint} onClose={() => onOpenChange(false)} g1={g1} g2={g2} />
      </DialogContent>
    </Dialog>
  );
}

