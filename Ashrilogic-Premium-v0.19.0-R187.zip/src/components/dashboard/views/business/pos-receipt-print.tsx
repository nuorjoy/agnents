"use client";

/**
 * Ashrilogic — ROUND 164: the POS PREMIUM thermal-receipt print preview.
 *
 * The owner's directive:
 *   «في جميع الأنظمة عند وحدة (نقاط البيع) قم بحذف (معاينة الطباعة)
 *    كاملاً ثم قم بتطوير (معاينة الطباعة) بطريقة احترافية ومميزة وPremium
 *    ذات ابتكار وتقدم جذاب»
 *
 * The POS module no longer prints through the shared A4 document
 * (record-print.tsx). Its «معاينة الطباعة» is rebuilt from scratch as a TRUE
 * 80mm thermal receipt — the format POS hardware actually speaks:
 *
 *   • ON SCREEN — a dark studio backdrop where the receipt paper floats
 *     with realistic torn edges (a generated SVG sawtooth), the exact
 *     80mm footprint, a paper-entrance animation, and the print actions
 *     under the sheet. A «إيصال حراري 80مم» chip makes the format law
 *     explicit.
 *   • THE RECEIPT — letterhead (logo/initial + org + contact), the txn
 *     code headline, receipt-style meta rows (dotted label…value), the
 *     totals ladder with a boxed GRAND TOTAL hero, the structured payment
 *     ledger (paid/remaining), the customer stamps, a deterministic CSS
 *     barcode of the txn code, and the thanks / powered-by footer.
 *   • ON PAPER — while this dialog is open a scoped <style> rewrites
 *     @page to `size: 80mm auto; margin: 0` (thermal roll), so the print
 *     output is a real narrow receipt, not an A4 sheet with a small box.
 *     The style is injected on open and removed on close/unmount — other
 *     modules' A4 printing is untouched. The R36 blanket visibility law
 *     and the R156.1 Radix breakout fix are mirrored for the
 *     .pos-receipt / .pos-print-host / .pos-print-scroller classes (see
 *     globals.css).
 *
 * Data contract: the exact PrintDoc the business-suite print builder
 * already produces (fields by kind → meta rows / totals ladder), plus the
 * optional customer stamps (meta.customerName / customerPhone).
 */
import { useEffect, useMemo } from "react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CatIcon } from "@/components/icon";
import { useT } from "@/lib/i18n";
import {
  PAYMENT_METHOD_META,
  summarizePayments,
  type PaymentEntry,
} from "@/lib/payment-methods";
import { BarcodeStrip } from "@/components/dashboard/views/business/record-detail-sheet";
import type { PrintDoc } from "@/components/dashboard/views/record-print";
import { intlLocale } from "@/lib/locales";
import { fmtId, idDir, numDir } from "@/lib/utils";
import type { InstanceDTO, Lang } from "@/lib/types";

/* ------------------------------------------------------------------ */
/* receipt primitives                                                  */
/* ------------------------------------------------------------------ */

/** minor units → display number */
const toMajor = (minor: number) => Math.round(minor) / 100;

function fmtMoneyValue(raw: string, currency: string, lang: Lang): string {
  const n = Number(String(raw).replace(/[^\d.-]/g, ""));
  if (!Number.isFinite(n)) return raw;
  try {
    return new Intl.NumberFormat(intlLocale(lang), {
      style: "currency",
      currency,
      maximumFractionDigits: 2,
    }).format(n);
  } catch {
    return `${raw} ${currency}`;
  }
}

function fmtMinor(minor: number, lang: Lang): string {
  try {
    return new Intl.NumberFormat(intlLocale(lang), {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
    }).format(toMajor(minor));
  } catch {
    return String(toMajor(minor));
  }
}

/** One receipt meta row — the classic dotted «label … value» line. */
function MetaRow({ label, value, mono = false }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-baseline gap-2 py-[3px]">
      <span className="shrink-0 text-[10px] font-bold text-slate-500">{label}</span>
      <span className="min-w-0 flex-1 translate-y-[-2px] border-b border-dotted border-slate-300" aria-hidden="true" />
      <span
        dir={mono ? idDir : undefined}
        className={`max-w-[62%] truncate text-[10.5px] font-extrabold text-slate-900 ${mono ? "font-mono text-[10px] tabular-nums" : ""}`}
        style={{ overflowWrap: "anywhere" }}
      >
        {value || "—"}
      </span>
    </div>
  );
}

/** The torn paper edge — a generated SVG sawtooth (screen-only decoration;
 *  paper prints with a clean cut). `flip` renders the bottom edge. */
function TearEdge({ flip = false }: { flip?: boolean }) {
  const d = useMemo(() => {
    const W = 300;
    const teeth = 24;
    const tw = W / teeth;
    const outer = flip ? 8 : 0;
    const inner = flip ? 0 : 8;
    let path = `M0 ${outer}`;
    for (let i = 0; i < teeth; i++) {
      path += ` L${((i + 0.5) * tw).toFixed(2)} ${inner} L${((i + 1) * tw).toFixed(2)} ${outer}`;
    }
    return `${path} Z`;
  }, [flip]);
  return (
    <svg
      viewBox="0 0 300 8"
      preserveAspectRatio="none"
      className="rcpt-screen-only block h-[7px] w-full"
      aria-hidden="true"
    >
      <path d={d} fill="#ffffff" />
    </svg>
  );
}

/** A dashed receipt rule. */
function DashRule() {
  return <div className="my-2 border-t border-dashed border-slate-300" aria-hidden="true" />;
}

/* ------------------------------------------------------------------ */
/* the premium POS receipt print dialog                                */
/* ------------------------------------------------------------------ */

export function PosReceiptPrintDialog({
  doc,
  instance,
  logoUrl,
  open,
  onOpenChange,
}: {
  doc: PrintDoc | null;
  instance: InstanceDTO;
  logoUrl: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { t, lang } = useT();
  const receiptDir = lang === "ar" ? "rtl" : "ltr";

  /* ROUND 164 — while this dialog is open, the document's @page becomes a
   * TRUE 80mm thermal roll (width 80mm, height auto, margin 0 — the paper
   * carries its own inner padding). The injected <style> sits after
   * globals.css so it wins the cascade; removing it on close restores the
   * A4 page rule for every other module's printing. */
  useEffect(() => {
    if (!open) return;
    const style = document.createElement("style");
    style.id = "ashrilogic-pos-receipt-page";
    style.textContent = "@media print { @page { size: 80mm auto; margin: 0; } }";
    document.head.appendChild(style);
    return () => {
      style.remove();
    };
  }, [open]);

  const print = () => {
    /* let the dialog finish laying out before the print dialog opens */
    window.setTimeout(() => window.print(), 60);
  };

  /* ---- field routing (POS preset shape, resolved BY KIND — resilient
   *    to column evolution): id → the code headline; money → the totals
   *    ladder (the LAST money column is the grand total); everything
   *    else → receipt meta rows. ---- */
  const idField = doc?.fields.find((f) => f.kind === "id") ?? null;
  const moneyFields = doc ? doc.fields.filter((f) => f.kind === "money") : [];
  const grandField = moneyFields.length > 0 ? moneyFields[moneyFields.length - 1] : null;
  const linesFields = moneyFields.slice(0, -1);
  const metaFields = doc
    ? doc.fields.filter((f) => f.kind !== "id" && f.kind !== "money" && f.kind !== "status")
    : [];
  const currency = instance.org.currency || "SAR";
  const payments: PaymentEntry[] = doc?.payments ?? [];
  const summary = payments.length > 0 ? summarizePayments(payments, doc?.totalMinor ?? 0) : null;
  const issued = useMemo(() => new Date().toISOString(), []);

  if (!doc) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        dir={receiptDir}
        className="pos-print-host flex max-h-[92vh] flex-col gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-xl print:max-h-none print:overflow-visible print:rounded-none print:border-0 print:bg-transparent print:p-0 print:shadow-none print:static print:translate-x-0 print:translate-y-0"
      >
        {/* the on-screen header (hidden when printing) */}
        <div className="print:hidden flex shrink-0 items-center gap-3 border-b border-white/10 bg-linear-to-l from-ink-950 to-[#0b1220] px-5 py-3.5">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-linear-to-br from-emerald-400 to-teal-600 text-white shadow-lg shadow-emerald-500/30">
            <CatIcon name="receipt" className="h-4 w-4" />
          </span>
          <div className="min-w-0 flex-1">
            <DialogTitle className="flex flex-wrap items-center gap-2 truncate font-display text-[15px] font-extrabold leading-tight text-white">
              {t("printDialogTitle")}
              <span className="inline-flex items-center gap-1 rounded-full border border-emerald-400/30 bg-emerald-400/10 px-2 py-px text-[9px] font-extrabold tracking-wide text-emerald-300">
                <CatIcon name="printer" className="h-[9px] w-[9px]" />
                {t("posReceiptThermal")}
              </span>
            </DialogTitle>
            <DialogDescription className="mt-0.5 truncate text-[11.5px] leading-relaxed text-slate-400">
              {t("posReceiptPreviewDesc")}
            </DialogDescription>
          </div>
          <button
            type="button"
            onClick={print}
            aria-label={t("printBtn")}
            className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-linear-to-l from-emerald-600 to-teal-500 px-3.5 text-[11.5px] font-extrabold text-white shadow-md transition hover:brightness-110 active:scale-95"
          >
            <CatIcon name="printer" className="h-3.5 w-3.5" />
            {t("printBtn")}
          </button>
        </div>

        {/* ---------------- the dark studio + the receipt paper ---------------- */}
        <div className="pos-print-scroller nice-scroll min-h-0 flex-1 overflow-auto bg-[radial-gradient(120%_90%_at_50%_0%,#101a2e_0%,#070b14_58%,#04060c_100%)] p-5 pb-6 sm:p-8 print:static print:block print:max-h-none print:overflow-visible print:bg-transparent print:p-0">
          <div
            className="pos-receipt rcpt-anim mx-auto w-[300px] max-w-full bg-white text-slate-900 shadow-[0_24px_60px_-18px_rgba(0,0,0,0.65)] print:w-full print:max-w-none print:shadow-none"
            dir={receiptDir}
          >
            {/* torn top edge (screen-only) */}
            <div className="rcpt-screen-only bg-transparent print:hidden" aria-hidden="true">
              <TearEdge />
            </div>

            {/* the receipt body — the paper's own inner padding doubles as
                the print margin (the @page rule carries margin: 0) */}
            <div className="px-[18px] py-4 print:px-[6mm] print:py-[5mm]">
              {/* ---------------- letterhead ---------------- */}
              <div className="flex flex-col items-center text-center">
                {logoUrl ? (
                  <span className="grid h-14 w-14 place-items-center rounded-full p-[3px]" style={{ background: "linear-gradient(135deg,#10b981,#0d9488)" }}>
                    <span className="grid h-full w-full place-items-center overflow-hidden rounded-full bg-white">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={logoUrl} alt={instance.org.name} className="h-11 w-11 rounded-full object-cover" />
                    </span>
                  </span>
                ) : (
                  <span
                    className="grid h-14 w-14 place-items-center rounded-full font-display text-[22px] font-extrabold text-white"
                    style={{ background: "linear-gradient(135deg,#10b981,#0d9488)" }}
                  >
                    {(instance.org.name || "A").trim().charAt(0).toUpperCase()}
                  </span>
                )}
                <p className="mt-2 font-display text-[14px] font-extrabold leading-tight text-slate-900">
                  {instance.org.name || "—"}
                </p>
                {instance.org.phone || instance.org.address ? (
                  <p className="mt-0.5 text-[8.5px] font-semibold leading-snug text-slate-500">
                    {instance.org.phone || ""}
                    {instance.org.phone && instance.org.address ? " · " : ""}
                    {instance.org.address || ""}
                  </p>
                ) : null}
                <p className="mt-1.5 text-[11px] font-extrabold uppercase tracking-[0.18em] text-slate-700">
                  {t("receiptTitle")}
                </p>
                <p className="text-[8.5px] font-bold text-slate-400">{doc.moduleName}</p>
                {doc.statusLabel ? (
                  <span
                    className="mt-1.5 inline-flex items-center gap-1 rounded-full border px-2.5 py-px text-[9px] font-extrabold"
                    style={{ borderColor: "#10b981", color: "#047857", backgroundColor: "#ecfdf5" }}
                  >
                    <span className="h-1 w-1 rounded-full" style={{ backgroundColor: "#10b981" }} aria-hidden="true" />
                    {doc.statusLabel}
                  </span>
                ) : null}
              </div>

              <DashRule />

              {/* ---------------- the txn code headline ---------------- */}
              {idField ? (
                <div className="text-center">
                  <p className="text-[8.5px] font-extrabold uppercase tracking-widest text-slate-400">
                    {t("posReceiptCode")}
                  </p>
                  <p dir={idDir} className="mt-0.5 font-mono text-[15px] font-extrabold tracking-wide text-slate-900">
                    {idField.value || doc.title}
                  </p>
                </div>
              ) : (
                <p className="text-center font-display text-[14px] font-extrabold text-slate-900">{doc.title}</p>
              )}

              <DashRule />

              {/* ---------------- meta rows ---------------- */}
              <div>
                {metaFields.map((field, i) => (
                  <MetaRow key={i} label={field.label} value={field.value} />
                ))}
              </div>

              <DashRule />

              {/* ---------------- the totals ladder ---------------- */}
              <p className="mb-1 text-center text-[8.5px] font-extrabold uppercase tracking-[0.22em] text-slate-400">
                {t("posReceiptTotals")}
              </p>
              {linesFields.map((field, i) => (
                <div key={i} className="flex items-baseline justify-between gap-2 py-[3px]">
                  <span className="text-[10px] font-bold text-slate-500">{field.label}</span>
                  <span dir={numDir(lang)} className="font-mono text-[10.5px] font-extrabold tabular-nums text-rose-600">
                    −{fmtMoneyValue(field.value, currency, lang)}
                  </span>
                </div>
              ))}

              {/* the GRAND TOTAL hero — boxed, double-ruled, unmistakable */}
              {grandField ? (
                <div className="mt-1.5 border-y-[3px] border-double border-slate-900 px-2 py-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[10.5px] font-extrabold uppercase tracking-wide text-slate-900">
                      {t("receiptGrand")}
                    </span>
                    <span dir={numDir(lang)} className="font-mono text-[15px] font-extrabold tabular-nums text-slate-900">
                      {doc.totalMinor !== null && doc.totalMinor !== undefined
                        ? fmtMinor(doc.totalMinor, lang)
                        : fmtMoneyValue(grandField.value, currency, lang)}
                    </span>
                  </div>
                  <p className="mt-0.5 text-end font-mono text-[8px] font-bold text-slate-500">{currency}</p>
                </div>
              ) : null}
              <p className="mt-1 text-center text-[8px] font-semibold text-slate-400">{t("receiptVatNote")}</p>

              {/* ---------------- the payment ledger ---------------- */}
              {payments.length > 0 && summary ? (
                <>
                  <DashRule />
                  <div className="space-y-1">
                    {payments.map((entry, i) => {
                      const meta = PAYMENT_METHOD_META[entry.method];
                      return (
                        <div key={`${entry.method}-${i}`} className="flex items-center justify-between gap-2">
                          <span className="inline-flex items-center gap-1 text-[9.5px] font-extrabold text-slate-600">
                            <CatIcon name={meta.icon} className="h-2.5 w-2.5" aria-hidden="true" />
                            {lang === "ar" ? meta.ar : meta.en}
                          </span>
                          {entry.amountMinor !== undefined ? (
                            <span dir={numDir(lang)} className="font-mono text-[9.5px] font-extrabold tabular-nums text-slate-800">
                              {fmtMinor(entry.amountMinor, lang)}
                            </span>
                          ) : null}
                        </div>
                      );
                    })}
                    <div className="flex items-center justify-between gap-2 pt-0.5">
                      <span className="text-[9.5px] font-extrabold text-emerald-700">{t("payMgrPaidNow")}</span>
                      <span dir={numDir(lang)} className="font-mono text-[9.5px] font-extrabold tabular-nums text-emerald-700">
                        {fmtMinor(summary.paidMinor, lang)}
                      </span>
                    </div>
                    {!summary.fullyPaid ? (
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[9.5px] font-extrabold text-amber-700">
                          {t("payMgrRemaining", { amount: fmtMinor(summary.remainingMinor, lang) })}
                        </span>
                      </div>
                    ) : null}
                  </div>
                </>
              ) : null}

              {/* ---------------- the customer stamps ---------------- */}
              {doc.customerName || doc.customerPhone ? (
                <>
                  <DashRule />
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[9.5px] font-bold text-slate-500">{t("receiptCustomer")}</span>
                    <span className="max-w-[62%] truncate text-[10px] font-extrabold text-slate-900">
                      {doc.customerName || doc.customerPhone}
                      {doc.customerName && doc.customerPhone ? (
                        <span dir={idDir} className="ms-1.5 font-mono text-[9px] font-bold text-slate-500">
                          {doc.customerPhone}
                        </span>
                      ) : null}
                    </span>
                  </div>
                </>
              ) : (
                <>
                  <DashRule />
                  <p className="text-center text-[9px] font-bold text-slate-400">{t("receiptWalkIn")}</p>
                </>
              )}

              {/* ---------------- the barcode + code ---------------- */}
              <div className="mt-3 flex flex-col items-center">
                <BarcodeStrip seed={idField?.value || doc.title} className="h-9 w-full" />
                <p dir={idDir} className="mt-1 font-mono text-[9px] font-bold tracking-[0.14em] text-slate-600">
                  {fmtId(idField?.value || doc.title, lang)}
                </p>
              </div>

              {/* ---------------- the thanks footer ---------------- */}
              <DashRule />
              <p className="text-center text-[10px] font-extrabold leading-relaxed text-slate-800">
                {t("receiptThanks")}
              </p>
              <p className="mt-1 text-center text-[8px] font-bold tracking-wide text-slate-400">
                {t("receiptPoweredBy")}
              </p>

              {/* the ink-only footer (screen: hidden, paper: the print stamp) */}
              <p className="print-only-pagefoot mt-2 text-center text-[7.5px] font-semibold leading-relaxed">
                {t("printPageFootStamp", { date: new Date(issued).toLocaleString(intlLocale(lang)) })}
              </p>
            </div>

            {/* torn bottom edge (screen-only) */}
            <div className="rcpt-screen-only bg-transparent print:hidden" aria-hidden="true">
              <TearEdge flip />
            </div>
          </div>

          {/* the on-screen actions (under the paper, hidden in print) */}
          <div className="print:hidden mt-6 flex items-center justify-center gap-2.5">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="h-10 rounded-xl border-white/15 bg-white/5 px-5 text-[12.5px] font-bold text-slate-200 hover:bg-white/10 hover:text-white"
            >
              {t("dlgCancel")}
            </Button>
            <Button
              type="button"
              onClick={print}
              className="h-10 gap-2 rounded-xl bg-linear-to-l from-emerald-600 to-teal-500 px-6 text-[12.5px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:brightness-110 active:scale-95"
            >
              <CatIcon name="printer" className="h-4 w-4" />
              {t("printBtn")}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
