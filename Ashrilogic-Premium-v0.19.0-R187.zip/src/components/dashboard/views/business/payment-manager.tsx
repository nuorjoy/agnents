"use client";

/**
 * Ashrilogic — ROUND 141 (directive ㉖→㉕): PAYMENT MANAGEMENT — the premium
 * 7-method section riding every business record dialog (sales, POS,
 * purchases — the SUPPLIER side included).
 *
 *  - a segmented picker over the canonical registry (نقدي · بطاقة · تحويل
 *    بنكي · محفظة إلكترونية · مختلط · دفعة جزئية · آجل);
 *  - المختلط opens the SPLIT builder (method + amount rows summing to the
 *    record total);
 *  - الجزئي collects the paid amount + shows the remaining balance;
 *  - الآجل collects the settlement date (dueAt);
 *  - the first entry's label ALSO lands in the legacy `method` cell (the
 *    analytics breakdown, the detail sheet and the print view keep their
 *    contract verbatim).
 *
 * Also exports PaymentsSummary — the read-side rendering (chips per entry
 * + paid/remaining + the due date + the overdue flag) used by the record
 * detail sheet and the print doc.
 */
import { useMemo, useState } from "react";
import { useT } from "@/lib/i18n";
import {
  PAYMENT_ENTRIES_MAX,
  PAYMENT_KINDS,
  PAYMENT_METHOD_META,
  summarizePayments,
  type PaymentEntry,
  type PaymentKind,
} from "@/lib/payment-methods";
import { parseAmountInputToMinor } from "@/lib/amount-input";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PremiumDateInput } from "@/components/ui/premium-date-input";

const toMajor = (minor: number) => Math.round(minor) / 100;

/* -------------------------- the editor section ---------------------------- */

export function PaymentManagerSection({
  value,
  onChange,
  totalMinor,
  currency,
  c1,
  c2,
}: {
  value: PaymentEntry[];
  onChange: (next: PaymentEntry[]) => void;
  /** the record's grand total in MINOR units (null = unknown — the partial
   *  remaining + the mixed sum check degrade gracefully) */
  totalMinor: number | null;
  currency: string;
  c1: string;
  c2: string;
}) {
  const { t, lang } = useT();
  const primary = value[0]?.method ?? null;
  /* the split rows while building a MIXED settlement (method + raw amount) */
  const [splitDraft, setSplitDraft] = useState<{ method: PaymentKind; amount: string }[]>([]);
  const splitSumMinor = useMemo(
    () =>
      splitDraft.reduce((sum, row) => {
        const parsed = parseAmountInputToMinor(row.amount);
        return sum + (parsed.ok ? parsed.minor : 0);
      }, 0),
    [splitDraft]
  );

  const pick = (kind: PaymentKind) => {
    if (kind === "mixed") {
      setSplitDraft([{ method: "cash", amount: "" }]);
      onChange([{ method: "mixed" }]);
      return;
    }
    setSplitDraft([]);
    if (kind === "partial") {
      onChange([{ method: "partial", amountMinor: 0 }]);
      return;
    }
    if (kind === "payable") {
      onChange([{ method: "payable", dueAt: "" }]);
      return;
    }
    onChange([{ method: kind }]);
  };

  const patchFirst = (patch: Partial<PaymentEntry>) => {
    if (value.length === 0) return;
    onChange([{ ...value[0], ...patch }]);
  };

  const partialParsed = value[0]?.method === "partial" && value[0]?.amountMinor !== undefined
    ? value[0].amountMinor
    : null;
  const summary =
    totalMinor !== null ? summarizePayments(value, totalMinor) : null;

  return (
    <section className="rounded-2xl border border-slate-200/80 bg-slate-50/50 p-3.5 dark:border-white/10 dark:bg-white/[0.02]">
      {/* the section header */}
      <div className="flex items-center gap-3">
        <span
          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
          style={{ backgroundImage: grad(c1, c2) }}
          aria-hidden="true"
        >
          <CatIcon name="wallet" className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
            {t("payMgrTitle")}
          </p>
          <p className="mt-0.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("payMgrDesc")}
          </p>
        </div>
      </div>

      {/* the 7-method segmented picker */}
      <div className="mt-3 grid grid-cols-4 gap-1.5" role="radiogroup" aria-label={t("payMgrTitle")}>
        {PAYMENT_KINDS.map((kind) => {
          const meta = PAYMENT_METHOD_META[kind];
          const active = primary === kind;
          return (
            <button
              key={kind}
              type="button"
              role="radio"
              aria-checked={active}
              onClick={() => pick(kind)}
              className={cn(
                "flex flex-col items-center gap-1.5 rounded-xl border px-1 py-2.5 transition active:scale-95",
                active
                  ? "border-transparent text-white shadow-md"
                  : "border-slate-200 bg-white/70 text-slate-500 hover:border-slate-300 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400 dark:hover:border-white/20"
              )}
              style={active ? { backgroundImage: grad(meta.c1, meta.c2) } : undefined}
            >
              <CatIcon name={meta.icon} className="h-[15px] w-[15px]" />
              <span className="w-full truncate px-0.5 text-center text-[9.5px] font-extrabold leading-tight">
                {lang === "ar" ? meta.ar : meta.en}
              </span>
            </button>
          );
        })}
      </div>

      {/* ---- MIXED: the split builder ---- */}
      {primary === "mixed" ? (
        <div className="mt-3 space-y-2 border-t border-dashed border-slate-200/80 pt-3 dark:border-white/10">
          {splitDraft.map((row, i) => {
            const parsed = parseAmountInputToMinor(row.amount);
            const amountOk = parsed.ok;
            return (
              <div key={i} className="flex items-center gap-2">
                <span className="w-6 shrink-0 text-center font-mono text-[10px] font-extrabold text-slate-300 dark:text-slate-600">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <div className="flex flex-1 flex-wrap gap-1">
                  {(["cash", "card", "bank", "ewallet"] as const).map((kind) => {
                    const meta = PAYMENT_METHOD_META[kind];
                    const active = row.method === kind;
                    return (
                      <button
                        key={kind}
                        type="button"
                        onClick={() =>
                          setSplitDraft((rows) => rows.map((r, ri) => (ri === i ? { ...r, method: kind } : r)))
                        }
                        className={cn(
                          "rounded-full px-2.5 py-1 text-[10px] font-extrabold transition active:scale-95",
                          active ? "text-white shadow-sm" : "bg-slate-100 text-slate-500 hover:bg-slate-200 dark:bg-white/10 dark:text-slate-400"
                        )}
                        style={active ? { backgroundImage: grad(meta.c1, meta.c2) } : undefined}
                      >
                        {lang === "ar" ? meta.ar : meta.en}
                      </button>
                    );
                  })}
                </div>
                <Input
                  value={row.amount}
                  onChange={(e) =>
                    setSplitDraft((rows) => rows.map((r, ri) => (ri === i ? { ...r, amount: e.target.value } : r)))
                  }
                  placeholder={t("payMgrAmountPh")}
                  inputMode="decimal"
                  dir="auto"
                  aria-invalid={!amountOk ? true : undefined}
                  className={cn(
                    "h-9 w-[104px] shrink-0 rounded-xl text-end text-[12px] font-extrabold tabular-nums",
                    !amountOk && "border-rose-400 focus-visible:ring-rose-400/30"
                  )}
                />
                {splitDraft.length > 1 ? (
                  <button
                    type="button"
                    onClick={() => setSplitDraft((rows) => rows.filter((_r, ri) => ri !== i))}
                    aria-label={t("payMgrRemoveRow")}
                    className="grid h-9 w-8 shrink-0 place-items-center rounded-lg text-slate-400 transition hover:bg-rose-500/10 hover:text-rose-500 active:scale-90"
                  >
                    <CatIcon name="trash-2" className="h-3.5 w-3.5" />
                  </button>
                ) : (
                  <span className="w-8 shrink-0" aria-hidden="true" />
                )}
              </div>
            );
          })}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              {splitDraft.length < PAYMENT_ENTRIES_MAX ? (
                <button
                  type="button"
                  onClick={() => setSplitDraft((rows) => [...rows, { method: "cash", amount: "" }])}
                  className="inline-flex items-center gap-1 rounded-full border border-dashed border-slate-300 px-2.5 py-1 text-[10px] font-extrabold text-slate-400 transition hover:border-violet-400 hover:text-violet-500 dark:border-white/15 dark:hover:border-violet-500/40"
                >
                  <CatIcon name="plus" className="h-2.5 w-2.5" />
                  {t("payMgrAddRow")}
                </button>
              ) : null}
              <span dir="ltr" className="text-[11px] font-extrabold tabular-nums text-slate-500 dark:text-slate-400">
                {fmtNum(toMajor(splitSumMinor), lang)} {currency}
                {totalMinor !== null ? (
                  <span
                    className={cn(
                      "ms-1.5",
                      splitSumMinor === totalMinor ? "text-emerald-600 dark:text-emerald-300" : "text-amber-600 dark:text-amber-300"
                    )}
                  >
                    {splitSumMinor === totalMinor ? "✓" : `/ ${fmtNum(toMajor(totalMinor), lang)}`}
                  </span>
                ) : null}
              </span>
            </div>
            <button
              type="button"
              onClick={() => {
                const entries: PaymentEntry[] = splitDraft
                  .map((row) => {
                    const parsed = parseAmountInputToMinor(row.amount);
                    return parsed.ok ? { method: row.method, amountMinor: parsed.minor } : null;
                  })
                  .filter((e) => e !== null);
                onChange(entries.length > 0 ? entries : [{ method: "mixed" }]);
              }}
              className="inline-flex h-8 items-center gap-1.5 rounded-xl bg-linear-to-l from-violet-600 to-fuchsia-500 px-3 text-[10.5px] font-extrabold text-white shadow-md transition hover:brightness-110 active:scale-95"
            >
              <CatIcon name="check" className="h-3 w-3" />
              {t("payMgrApplySplit")}
            </button>
          </div>
        </div>
      ) : null}

      {/* ---- PARTIAL: the paid amount + remaining ---- */}
      {primary === "partial" ? (
        <div className="mt-3 space-y-1.5 border-t border-dashed border-slate-200/80 pt-3 dark:border-white/10">
          <Label htmlFor="pay-mgr-partial" className="text-[11px] font-extrabold text-slate-600 dark:text-slate-300">
            {t("payMgrPaidNow")}
          </Label>
          <div className="flex items-center gap-2">
            <Input
              id="pay-mgr-partial"
              value={partialParsed !== null ? String(toMajor(partialParsed)) : ""}
              onChange={(e) => {
                const parsed = parseAmountInputToMinor(e.target.value);
                patchFirst({ amountMinor: parsed.ok ? parsed.minor : 0 });
              }}
              inputMode="decimal"
              dir="auto"
              placeholder={t("payMgrAmountPh")}
              className="h-10 max-w-[180px] rounded-xl text-end text-[13px] font-extrabold tabular-nums"
            />
            <span className="text-[11px] font-bold text-slate-400">{currency}</span>
            {totalMinor !== null && partialParsed !== null ? (
              <span
                className={cn(
                  "ms-auto rounded-full px-2.5 py-1 text-[10.5px] font-extrabold",
                  totalMinor - partialParsed <= 0
                    ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-300"
                    : "bg-amber-500/15 text-amber-600 dark:text-amber-300"
                )}
              >
                {t("payMgrRemaining", { amount: fmtNum(toMajor(Math.max(totalMinor - partialParsed, 0)), lang) })}
              </span>
            ) : null}
          </div>
        </div>
      ) : null}

      {/* ---- PAYABLE: the settlement date ---- */}
      {primary === "payable" ? (
        <div className="mt-3 space-y-1.5 border-t border-dashed border-slate-200/80 pt-3 dark:border-white/10">
          <Label htmlFor="pay-mgr-due" className="text-[11px] font-extrabold text-slate-600 dark:text-slate-300">
            {t("payMgrDueDate")}
          </Label>
          {/* R163 — the shared premium date field: brand calendar tile at
              the field's far right in Arabic, clear-X + Arabic long-form hint
              built in (the compact 180px settlement rhythm preserved). */}
          <PremiumDateInput
            id="pay-mgr-due"
            value={value[0]?.dueAt ?? ""}
            onChange={(e) => patchFirst({ dueAt: e.target.value })}
            wrapperClassName="max-w-[180px]"
          />
          <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500">{t("payMgrDueHint")}</p>
        </div>
      ) : null}

      {/* the settlement summary line (mixed/partial with a known total) */}
      {summary && value.length > 0 && (primary === "mixed" || primary === "partial") ? (
        <p className="mt-2.5 flex items-center gap-1.5 text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
          <CatIcon name="info" className="h-3 w-3 shrink-0" />
          {summary.fullyPaid
            ? t("payMgrSettled")
            : t("payMgrSummary", {
                paid: fmtNum(toMajor(summary.paidMinor), lang),
                remaining: fmtNum(toMajor(summary.remainingMinor), lang),
              })}
        </p>
      ) : null}
    </section>
  );
}

/* --------------------------- the read-side summary -------------------------- */

/** The structured payment summary for the record detail sheet + print doc:
 *  per-entry chips + the paid/remaining ladder + the payable due date. */
export function PaymentsSummary({
  entries,
  totalMinor,
  currency,
}: {
  entries: PaymentEntry[];
  totalMinor: number;
  currency: string;
}) {
  const { t, lang } = useT();
  if (entries.length === 0) return null;
  const summary = summarizePayments(entries, totalMinor);
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-center gap-1.5">
        {entries.map((entry, i) => {
          const meta = PAYMENT_METHOD_META[entry.method];
          return (
            <span
              key={`${entry.method}-${i}`}
              className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-extrabold text-white"
              style={{ backgroundImage: grad(meta.c1, meta.c2) }}
            >
              <CatIcon name={meta.icon} className="h-2.5 w-2.5" />
              {lang === "ar" ? meta.ar : meta.en}
              {entry.amountMinor !== undefined ? (
                <span dir="ltr" className="tabular-nums opacity-90">
                  {fmtNum(toMajor(entry.amountMinor), lang)}
                </span>
              ) : null}
            </span>
          );
        })}
      </div>
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[10.5px] font-bold">
        <span className="text-emerald-600 dark:text-emerald-300">
          {t("payMgrPaid", { amount: fmtNum(toMajor(summary.paidMinor), lang), currency })}
        </span>
        {!summary.fullyPaid ? (
          <span className="text-amber-600 dark:text-amber-300">
            {t("payMgrRemaining", { amount: fmtNum(toMajor(summary.remainingMinor), lang) })}
          </span>
        ) : null}
        {summary.dueAt ? (
          <span className={cn(summary.overdue ? "text-rose-500 dark:text-rose-300" : "text-slate-400 dark:text-slate-500")}>
            <CatIcon name="calendar-clock" className="me-1 inline h-2.5 w-2.5" />
            {t("payMgrDueLabel", { date: summary.dueAt })}
            {summary.overdue ? ` · ${t("payMgrOverdue")}` : ""}
          </span>
        ) : null}
      </div>
    </div>
  );
}
