"use client";

/**
 * Ashrilogic — R163 — the PREMIUM MEDICAL record-detail families.
 *
 * The owner's directive:
 *   «في جميع الأنظمة التي تحتوي على وحدة (الملف الطبي، المواعيد، المرضى،
 *    العمليات، الطوارئ، الفواتير، الكوادر الطبية، الصيدلية، المصروفات،
 *    الطب عن بُعد، التأمين، الأسرة، الأشعة، المختبر، الوصفات) قم بحذف
 *    (تفاصيل السجل) كاملاً وإعادة تطويره بطريقة احترافية ومميزة وPremium
 *    بدقة تامة»
 *
 * This module REPLACES the generic field passport (GenericMode) for the
 * fourteen clinical + financial module families with per-module blueprints:
 *
 *   patient    → patients + ehr        — a clinical dossier: hero patient,
 *                 blood-type / allergy / chronic / insurance alert banners,
 *                 vitals stat cards, visit history chips.
 *   appointment→ appointments + telemedicine — a scheduling pass: date/time
 *                 hero chips, specialty + fee stat cards, consult minutes.
 *   surgical   → operations            — a surgical case file: procedure
 *                 hero, OR room + duration + cost stat cards.
 *   emergency  → emergency             — a triage board: the 1–5 severity
 *                 gauge (color-coded), arrival/wait chips, complaint strip.
 *   finance    → invoices + expenses + insurance — a money grid: amount /
 *                 VAT / total cards, the structured payment ledger, the
 *                 coverage-% bar, the uploaded receipt preview.
 *   clinical   → radiology + lab + prescriptions + pharmacy — a clinical
 *                 item pass: exam/test/drug identity, result chips, stock
 *                 + expiry cards (pharmacy).
 *   bed        → beds                 — a bed status card: ward/floor,
 *                 nightly rate, occupancy pill.
 *
 * PURITY CONTRACT (identical to RecordDetailSheet): everything arrives via
 * the SheetCtx props — no fetch, no i18n edits (labels come from the
 * module preset's own bilingual ColDef labels; only the four section keys
 * above were added). Every numeric / money / ID value renders through the
 * shared policy helpers (fmtNum / fmtMoneyCell / fmtId + numDir/idDir).
 * onEdit / onPrint / onClose hand back to the parent integrator exactly
 * like GenericMode did — the edit + print + demo-row flows are untouched.
 */
import type { ColDef } from "@/lib/module-data";
import {
  cn,
  fmtId,
  fmtMoneyCell,
  fmtNum,
  grad,
  hexAlpha,
  idDir,
  initial,
  numDir,
} from "@/lib/utils";
import { CatIcon } from "@/components/icon";
import { PaymentsSummary } from "@/components/dashboard/views/business/payment-manager";
import { DialogDescription, DialogTitle } from "@/components/ui/dialog";
import {
  fmtDateCell,
  MetaStamps,
  Pill,
  SectionLabel,
  SheetFooter,
  StatCard,
  type SheetCtx,
} from "@/components/dashboard/views/business/record-detail-sheet";

/* ------------------------------------------------------------------ */
/* families — one distinctive gradient per clinical family             */
/* ------------------------------------------------------------------ */

type FamilyKey = "patient" | "appointment" | "surgical" | "emergency" | "finance" | "clinical" | "bed";

const FAMILY_C: Record<FamilyKey, readonly [string, string]> = {
  patient: ["#f43f5e", "#be185d"], /* health rose (the category pair)   */
  appointment: ["#0ea5e9", "#0369a1"], /* scheduling sky                    */
  surgical: ["#8b5cf6", "#6d28d9"], /* theater violet                    */
  emergency: ["#f59e0b", "#b45309"], /* urgency amber                     */
  finance: ["#10b981", "#047857"], /* money emerald                     */
  clinical: ["#06b6d4", "#0e7490"], /* diagnostics cyan                  */
  bed: ["#64748b", "#334155"], /* occupancy slate                   */
};

/* ------------------------------------------------------------------ */
/* blueprints — per-module identity + KPI + alert decisions           */
/* ------------------------------------------------------------------ */

type StatKind = "num" | "money" | "date" | "text";

interface StatSpec {
  key: string;
  icon: string;
  kind: StatKind;
}

interface AlertSpec {
  key: string;
  icon: string;
  tone: "rose" | "amber" | "violet" | "emerald";
}

interface Blueprint {
  family: FamilyKey;
  /** the module badge chip icon (hero row) */
  badge: string;
  /** the primary identity column key (rendered as the sheet hero) */
  heroKey: string;
  /** KPI stat cards (rendered as the premium stats grid) */
  stats: StatSpec[];
  /** clinical alert banners (the ehr dossier) */
  alerts?: AlertSpec[];
  /** special widget: the emergency triage gauge / insurance coverage bar */
  gauge?: { key: string; type: "triage" | "coverage" };
}

const BLUEPRINTS: Record<string, Blueprint> = {
  patients: {
    family: "patient",
    badge: "user-round",
    heroKey: "name",
    stats: [
      { key: "age", icon: "cake", kind: "num" },
      { key: "gender", icon: "user-round", kind: "text" },
      { key: "phone", icon: "phone", kind: "text" },
      { key: "lastVisit", icon: "calendar", kind: "date" },
    ],
  },
  ehr: {
    family: "patient",
    badge: "file-heart",
    heroKey: "patient",
    stats: [
      { key: "visits", icon: "repeat", kind: "num" },
      { key: "updated", icon: "calendar", kind: "date" },
    ],
    alerts: [
      { key: "bloodType", icon: "droplet", tone: "rose" },
      { key: "allergies", icon: "triangle-alert", tone: "amber" },
      { key: "chronic", icon: "heart-pulse", tone: "violet" },
      { key: "insured", icon: "shield-check", tone: "emerald" },
    ],
  },
  appointments: {
    family: "appointment",
    badge: "calendar-clock",
    heroKey: "patient",
    stats: [
      { key: "date", icon: "calendar", kind: "date" },
      { key: "time", icon: "clock", kind: "text" },
      { key: "type", icon: "stethoscope", kind: "text" },
    ],
  },
  telemedicine: {
    family: "appointment",
    badge: "video",
    heroKey: "patient",
    stats: [
      { key: "date", icon: "calendar", kind: "date" },
      { key: "time", icon: "clock", kind: "text" },
      { key: "minutes", icon: "timer", kind: "num" },
      { key: "fee", icon: "banknote", kind: "money" },
    ],
  },
  operations: {
    family: "surgical",
    badge: "activity",
    heroKey: "patient",
    stats: [
      { key: "date", icon: "calendar", kind: "date" },
      { key: "duration", icon: "timer", kind: "num" },
      { key: "room", icon: "door-open", kind: "text" },
      { key: "cost", icon: "banknote", kind: "money" },
    ],
  },
  emergency: {
    family: "emergency",
    badge: "siren",
    heroKey: "patient",
    stats: [
      { key: "arrival", icon: "clock", kind: "text" },
      { key: "wait", icon: "timer", kind: "num" },
      { key: "doctor", icon: "stethoscope", kind: "text" },
    ],
    gauge: { key: "triage", type: "triage" },
  },
  insurance: {
    family: "finance",
    badge: "shield-check",
    heroKey: "holder",
    stats: [
      { key: "provider", icon: "building", kind: "text" },
      { key: "premium", icon: "banknote", kind: "money" },
      { key: "expiry", icon: "calendar", kind: "date" },
    ],
    gauge: { key: "coverage", type: "coverage" },
  },
  beds: {
    family: "bed",
    badge: "bed-double",
    heroKey: "bed",
    stats: [
      { key: "ward", icon: "building", kind: "text" },
      { key: "floor", icon: "layers", kind: "num" },
      { key: "rate", icon: "banknote", kind: "money" },
      { key: "patient", icon: "user-round", kind: "text" },
    ],
  },
  radiology: {
    family: "clinical",
    badge: "scan",
    heroKey: "patient",
    stats: [
      { key: "exam", icon: "scan", kind: "text" },
      { key: "bodyPart", icon: "scan-line", kind: "text" },
      { key: "date", icon: "calendar", kind: "date" },
      { key: "price", icon: "banknote", kind: "money" },
    ],
  },
  lab: {
    family: "clinical",
    badge: "microscope",
    heroKey: "patient",
    stats: [
      { key: "type", icon: "flask-conical", kind: "text" },
      { key: "result", icon: "clipboard-list", kind: "text" },
      { key: "date", icon: "calendar", kind: "date" },
    ],
  },
  prescriptions: {
    family: "clinical",
    badge: "pill",
    heroKey: "patient",
    stats: [
      { key: "drug", icon: "pill", kind: "text" },
      { key: "dose", icon: "pills", kind: "text" },
      { key: "date", icon: "calendar", kind: "date" },
    ],
  },
  pharmacy: {
    family: "clinical",
    badge: "pill-bottle",
    heroKey: "drug",
    stats: [
      { key: "stock", icon: "boxes", kind: "num" },
      { key: "price", icon: "banknote", kind: "money" },
      { key: "expiry", icon: "calendar", kind: "date" },
      { key: "category", icon: "package", kind: "text" },
    ],
  },
  invoices: {
    family: "finance",
    badge: "receipt",
    heroKey: "client",
    stats: [
      { key: "amount", icon: "banknote", kind: "money" },
      { key: "vat", icon: "sigma", kind: "money" },
      { key: "total", icon: "wallet", kind: "money" },
      { key: "date", icon: "calendar", kind: "date" },
    ],
  },
  expenses: {
    family: "finance",
    badge: "wallet",
    heroKey: "title",
    stats: [
      { key: "amount", icon: "banknote", kind: "money" },
      { key: "date", icon: "calendar", kind: "date" },
      { key: "method", icon: "credit-card", kind: "text" },
      { key: "category", icon: "tag", kind: "text" },
    ],
  },
};

/** the dispatch set — every module the medical families own (staff keeps
 *  its own dedicated ROUND-156.1 profile sheet upstream in business-suite). */
export const MEDICAL_DETAIL_MODULES: readonly string[] = Object.keys(BLUEPRINTS);

/* ------------------------------------------------------------------ */
/* the alert banner idiom (tone-tinted clinical banners)               */
/* ------------------------------------------------------------------ */

const ALERT_STYLE: Record<AlertSpec["tone"], { wrap: string; icon: string }> = {
  rose: { wrap: "border-rose-300/80 bg-rose-500/[0.07] dark:border-rose-500/35 dark:bg-rose-500/10", icon: "text-rose-600 dark:text-rose-300" },
  amber: { wrap: "border-amber-300/80 bg-amber-500/[0.07] dark:border-amber-500/35 dark:bg-amber-500/10", icon: "text-amber-600 dark:text-amber-300" },
  violet: { wrap: "border-violet-300/80 bg-violet-500/[0.07] dark:border-violet-500/35 dark:bg-violet-500/10", icon: "text-violet-600 dark:text-violet-300" },
  emerald: { wrap: "border-emerald-300/80 bg-emerald-500/[0.07] dark:border-emerald-500/35 dark:bg-emerald-500/10", icon: "text-emerald-600 dark:text-emerald-300" },
};

/* ------------------------------------------------------------------ */
/* the mode renderer                                                   */
/* ------------------------------------------------------------------ */

export function MedicalDetailMode({ ctx, moduleId }: { ctx: SheetCtx; moduleId: string }) {
  const { record, cols, statuses, moduleName, currency, lang, t, onPrint, onClose, shiftCode } = ctx;
  const bp = BLUEPRINTS[moduleId] ?? null;
  const [g1, g2] = bp ? FAMILY_C[bp.family] : FAMILY_C.clinical;

  /* ---------------- value helpers (the GenericMode policy) ---------------- */
  const idxOf = (key: string): number => cols.findIndex((c) => c.key === key);
  const valAt = (key: string): string => record.values[idxOf(key)] ?? "";
  const hero = bp ? valAt(bp.heroKey).trim() || "—" : (record.values[0] ?? "—");
  const st = statuses.find((s) => s.key === record.statusKey);
  const idIdx = cols.findIndex((c) => c.kind === "id");
  const statusIdx = cols.findIndex((c) => c.kind === "status");

  const renderValue = (c: ColDef, raw: string) => {
    if (!raw.trim()) return <span className="text-[12.5px] font-bold text-slate-400">—</span>;
    switch (c.kind) {
      case "money":
        return (
          <span dir={numDir(lang)} className="text-[13px] font-extrabold tabular-nums text-emerald-600 dark:text-emerald-400">
            {fmtMoneyCell(Number(raw) || 0, lang, currency)}
          </span>
        );
      case "num":
        return (
          <span dir={numDir(lang)} className="text-[12.5px] font-extrabold tabular-nums text-slate-700 dark:text-slate-200">
            {fmtNum(Number(raw) || 0, lang)}
          </span>
        );
      case "id":
        return (
          <span dir={idDir} className="rounded-lg bg-slate-100 px-2 py-0.5 font-mono text-[11px] font-bold tabular-nums text-slate-600 dark:bg-white/10 dark:text-slate-300">
            {fmtId(raw, lang)}
          </span>
        );
      case "date":
        return (
          <span dir={numDir(lang)} className="text-[12.5px] font-bold tabular-nums text-slate-700 dark:text-slate-200">
            {fmtDateCell(raw, lang)}
          </span>
        );
      default:
        return (
          <span dir="auto" className="break-words text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
            {raw}
          </span>
        );
    }
  };

  const statValue = (spec: StatSpec): string => {
    const raw = valAt(spec.key);
    if (!raw.trim()) return "—";
    if (spec.kind === "money") return fmtMoneyCell(Number(raw) || 0, lang, currency);
    if (spec.kind === "num") return fmtNum(Number(raw) || 0, lang);
    if (spec.kind === "date") return fmtDateCell(raw, lang);
    return raw;
  };
  const statDir = (spec: StatSpec): "rtl" | "ltr" | "auto" =>
    spec.kind === "money" || spec.kind === "num" ? numDir(lang) : spec.kind === "date" ? numDir(lang) : "auto";
  const statClass = (spec: StatSpec): string | undefined =>
    spec.kind === "money" ? "text-emerald-600 dark:text-emerald-400" : undefined;

  const statLabel = (key: string): string => {
    const c = cols[idxOf(key)];
    return c ? (lang === "ar" ? c.ar : c.en) : key;
  };

  /* fields already surfaced by the blueprint (hero / stats / alerts / gauge) */
  const surfaced = new Set<string>([...(bp ? [bp.heroKey] : []), ...(bp?.stats.map((s) => s.key) ?? []), ...(bp?.alerts?.map((a) => a.key) ?? []), ...(bp?.gauge ? [bp.gauge.key] : [])]);
  const coreCols = cols.filter((c, i) => i !== statusIdx && !surfaced.has(c.key) && (c.kind === "text" || c.kind === "date" || c.kind === "id"));
  const numCols = cols.filter((c, i) => i !== statusIdx && !surfaced.has(c.key) && (c.kind === "num" || c.kind === "money"));

  const fieldRow = (c: ColDef) => (
    <div key={c.key} className="flex items-start justify-between gap-3 rounded-xl border border-black/5 bg-slate-50/60 px-3.5 py-2.5 dark:border-white/10 dark:bg-white/[0.03]">
      <span className="shrink-0 text-[11.5px] font-extrabold text-slate-400 dark:text-slate-500" dir="auto">
        {lang === "ar" ? c.ar : c.en}
      </span>
      <span className="min-w-0 text-end">{renderValue(c, valAt(c.key))}</span>
    </div>
  );

  /* ---------------- special widgets ---------------- */
  const triageLevel = bp?.gauge?.type === "triage" ? Math.max(1, Math.min(5, Math.round(Number(valAt(bp.gauge.key)) || 1))) : 0;
  const triageTone = triageLevel >= 4 ? ["bg-rose-500", "text-rose-600 dark:text-rose-300"] : triageLevel === 3 ? ["bg-amber-500", "text-amber-600 dark:text-amber-300"] : ["bg-emerald-500", "text-emerald-600 dark:text-emerald-300"];
  const coveragePct = bp?.gauge?.type === "coverage" ? Math.max(0, Math.min(100, Math.round(Number(valAt(bp.gauge.key)) || 0))) : 0;

  return (
    <>
      {/* ——— the hero header — the family gradient + module badge ——— */}
      <div
        className="relative shrink-0 overflow-hidden border-b border-slate-200/70 px-5 pt-4 pb-4 dark:border-white/10"
        style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(g1, 0.16)}, ${hexAlpha(g2, 0.16)})` }}
      >
        <span
          className="absolute -end-8 -top-14 h-28 w-28 rounded-full"
          style={{ background: `radial-gradient(circle, ${hexAlpha(g1, 0.28)}, transparent 70%)` }}
          aria-hidden="true"
        />
        <div className="relative flex items-center gap-3.5">
          {record.imageRef ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={record.imageRef}
              alt={hero}
              className="h-14 w-14 shrink-0 rounded-2xl border border-black/5 object-cover shadow-lg dark:border-white/10"
            />
          ) : (
            <span
              className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl font-display text-xl font-extrabold text-white shadow-lg"
              style={{ backgroundImage: grad(g1, g2), boxShadow: `0 12px 28px -12px ${hexAlpha(g1, 0.9)}` }}
              aria-hidden="true"
            >
              {initial(hero)}
            </span>
          )}
          <div className="min-w-0 flex-1">
            <DialogTitle className="truncate font-display text-[15.5px] font-extrabold leading-tight text-slate-900 dark:text-white" dir="auto">
              {hero}
            </DialogTitle>
            <DialogDescription className="mt-0.5 truncate text-[11.5px] font-bold text-slate-500 dark:text-slate-400">
              {t("bizRowDetailTitle")} · {moduleName}
            </DialogDescription>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              {/* the module badge — the family's identity chip */}
              <span
                className="inline-flex shrink-0 items-center gap-1.5 rounded-full px-2.5 py-1 text-[10.5px] font-extrabold text-white shadow-sm"
                style={{ backgroundImage: grad(g1, g2) }}
                dir="auto"
              >
                <CatIcon name={bp?.badge ?? "clipboard-list"} className="h-3 w-3" />
                {moduleName}
              </span>
              {idIdx >= 0 && idIdx !== idxOf(bp?.heroKey ?? "") ? (
                <span
                  dir={idDir}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-slate-100 px-2 py-1 font-mono text-[10.5px] font-bold tabular-nums text-slate-600 dark:bg-white/10 dark:text-slate-300"
                >
                  <CatIcon name="hash" className="h-3 w-3 shrink-0 text-slate-400" />
                  {fmtId(record.values[idIdx] ?? "", lang)}
                </span>
              ) : null}
              {st ? <Pill tone={st.tone} label={lang === "ar" ? st.ar : st.en} /> : null}
            </div>
          </div>
        </div>
      </div>

      {/* ——— the body ——— */}
      <div className="nice-scroll min-h-0 flex-1 space-y-4 overflow-y-auto px-5 py-4">
        {/* the clinical alert banners (the ehr dossier) */}
        {bp?.alerts && bp.alerts.length > 0 ? (
          <div className="space-y-2.5">
            <SectionLabel icon="heart-pulse" label={t("detailMedicalAlerts")} g1={g1} g2={g2} lang={lang} />
            <div className="grid gap-2 sm:grid-cols-2">
              {bp.alerts.map((a) => {
                const style = ALERT_STYLE[a.tone];
                const raw = valAt(a.key);
                return (
                  <div key={a.key} className={cn("rounded-xl border px-3 py-2.5", style.wrap)}>
                    <p className="flex items-center gap-1.5 text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500" dir="auto">
                      <CatIcon name={a.icon} className={cn("h-3 w-3 shrink-0", style.icon)} />
                      {statLabel(a.key)}
                    </p>
                    <p className="mt-1 break-words text-[13px] font-extrabold text-slate-800 dark:text-white" dir="auto">
                      {raw.trim() ? raw : "—"}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        ) : null}

        {/* the emergency triage gauge (1–5, color-coded severity) */}
        {bp?.gauge?.type === "triage" ? (
          <div className="space-y-2.5">
            <SectionLabel icon="siren" label={t("detailTriageLevel")} g1={g1} g2={g2} lang={lang} />
            <div className="rounded-2xl border border-black/5 bg-slate-50/60 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
              <div className="flex items-end justify-center gap-2" dir="ltr" aria-hidden="true">
                {[1, 2, 3, 4, 5].map((level) => (
                  <span
                    key={level}
                    className={cn(
                      "w-full max-w-14 rounded-lg transition-all",
                      level === triageLevel ? "h-10" : level < triageLevel ? "h-7" : "h-5",
                      level <= triageLevel
                        ? level >= 4
                          ? "bg-linear-to-t from-rose-600 to-rose-400"
                          : level === 3
                            ? "bg-linear-to-t from-amber-600 to-amber-400"
                            : "bg-linear-to-t from-emerald-600 to-emerald-400"
                        : "bg-slate-200 dark:bg-white/10"
                    )}
                  />
                ))}
              </div>
              <div className="mt-2.5 flex items-center justify-between gap-2">
                <p className="text-[10.5px] font-bold text-slate-400 dark:text-slate-500" dir="auto">
                  {statLabel(bp.gauge.key)}
                </p>
                <span dir={numDir(lang)} className={cn("font-display text-[16px] font-extrabold tabular-nums", triageTone[1])}>
                  {fmtNum(triageLevel, lang)} / {fmtNum(5, lang)}
                </span>
              </div>
            </div>
          </div>
        ) : null}

        {/* the insurance coverage bar */}
        {bp?.gauge?.type === "coverage" ? (
          <div className="space-y-2.5">
            <SectionLabel icon="shield-check" label={t("detailCoverageTitle")} g1={g1} g2={g2} lang={lang} />
            <div className="rounded-2xl border border-black/5 bg-slate-50/60 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
              <div className="flex items-center justify-between gap-2">
                <p className="text-[10.5px] font-bold text-slate-400 dark:text-slate-500" dir="auto">
                  {statLabel(bp.gauge.key)}
                </p>
                <span dir={numDir(lang)} className="font-display text-[16px] font-extrabold tabular-nums text-emerald-600 dark:text-emerald-400">
                  {fmtNum(coveragePct, lang)}%
                </span>
              </div>
              <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-slate-200/80 dark:bg-white/10" dir="ltr">
                <div
                  className="h-full rounded-full bg-linear-to-r from-emerald-600 to-teal-400 transition-all"
                  style={{ width: `${coveragePct}%` }}
                />
              </div>
            </div>
          </div>
        ) : null}

        {/* the KPI stat cards — the blueprint's premium stats grid */}
        {bp && bp.stats.length > 0 ? (
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {bp.stats.map((spec) => (
              <StatCard
                key={spec.key}
                icon={spec.icon}
                label={statLabel(spec.key)}
                value={statValue(spec)}
                dir={statDir(spec)}
                valueClass={statClass(spec)}
                g1={g1}
                g2={g2}
                lang={lang}
              />
            ))}
          </div>
        ) : null}

        {/* the remaining clinical fields */}
        {coreCols.length > 0 ? (
          <div className="space-y-2.5">
            <SectionLabel icon="eye" label={t("detailSectionClinical")} g1={g1} g2={g2} lang={lang} />
            <div className="space-y-2">{coreCols.map((c) => fieldRow(c))}</div>
          </div>
        ) : null}

        {/* remaining numbers & money */}
        {numCols.length > 0 ? (
          <div className="space-y-2.5">
            <SectionLabel icon="sigma" label={t("detailSectionNumbers")} g1={g1} g2={g2} lang={lang} />
            <div className="space-y-2">{numCols.map((c) => fieldRow(c))}</div>
          </div>
        ) : null}

        {/* the structured payment ledger (invoices + any ledger record) */}
        {record.payments.length > 0 ? (
          <div className="space-y-2.5">
            <SectionLabel icon="wallet" label={t("payMgrTitle")} g1={g1} g2={g2} lang={lang} />
            <PaymentsSummary
              entries={record.payments}
              totalMinor={(() => {
                let last = -1;
                for (let i = 0; i < cols.length; i++) if (cols[i].kind === "money") last = i;
                if (last < 0) return 0;
                const raw = Number(String(record.values[last] ?? "").replace(/[^\d.-]/g, ""));
                return Number.isFinite(raw) && raw > 0 ? Math.round(raw * 100) : 0;
              })()}
              currency={currency ?? "SAR"}
            />
          </div>
        ) : null}

        {/* the uploaded receipt / cover preview (expenses) */}
        {record.imageRef ? (
          <div className="space-y-2.5">
            <SectionLabel icon="image" label={t("bizReceiptImageTitle")} g1={g1} g2={g2} lang={lang} />
            <div className="overflow-hidden rounded-xl border border-slate-200 bg-white p-2 dark:border-white/10 dark:bg-white/[0.03]">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={record.imageRef}
                alt={t("bizReceiptImageTitle")}
                className="mx-auto max-h-72 w-auto rounded-lg object-contain"
              />
            </div>
          </div>
        ) : null}

        {/* the record metadata stamps */}
        <div className="space-y-2.5">
          <SectionLabel icon="clock" label={t("detailSectionMeta")} g1={g1} g2={g2} lang={lang} />
          <MetaStamps record={record} lang={lang} t={t} shiftCode={shiftCode} />
        </div>
      </div>

      <SheetFooter t={t} onEdit={ctx.onEdit} onPrint={onPrint} onClose={onClose} g1={g1} g2={g2} />
    </>
  );
}
