"use client";

/**
 * Ashrilogic — BARCODE CAPTURE primitives (ROUND 132).
 *
 * The owner's directive: «يمكن مسح باركود المنتج عن اجهزة الباركود أو
 * الكاميرا أو توصيله عن طريق البلوتوث بدقة عالية واحترافية». Three
 * capture channels, one component:
 *
 *   1. HARDWARE SCANNERS (USB / Bluetooth HID) — these are keyboard-wedge
 *      devices: they TYPE the code into whatever field holds focus and send
 *      Enter. The manual mode's dedicated input is built for exactly that
 *      (autoFocus, Enter = submit, never blurs on submit, mono font). No
 *      permissions, no pairing API — this is how retail scanners work.
 *   2. CAMERA — the native BarcodeDetector API (Chrome/Edge/Android). Live
 *      video preview + a 250ms detect loop; thePermissions-Policy allows
 *      camera=(self) (next.config.ts). Browsers without the API degrade
 *      gracefully to the manual/wedge mode with a clear message.
 *   3. MANUAL ENTRY — typing the digits (the fallback that always works).
 *
 * generateEan13() mints real, checksum-valid EAN-13 codes on the Saudi
 * GS1 prefix (629…) so generated product barcodes are globally shapely.
 */
import { useCallback, useEffect, useRef, useState, type FormEvent } from "react";
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";

/* ------------------------------------------------------------------ */
/* BarcodeDetector typing (NOT in TS lib.dom yet)                       */
/* ------------------------------------------------------------------ */

interface DetectedCodeLike {
  rawValue: string;
}
interface BarcodeDetectorLike {
  detect(source: CanvasImageSource): Promise<DetectedCodeLike[]>;
}
type BarcodeDetectorCtor = new (options?: { formats?: string[] }) => BarcodeDetectorLike;

function detectorCtor(): BarcodeDetectorCtor | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as { BarcodeDetector?: BarcodeDetectorCtor };
  return w.BarcodeDetector ?? null;
}

/* ------------------------------------------------------------------ */
/* EAN-13 generator (Saudi GS1 prefix 629 + valid check digit)          */
/* ------------------------------------------------------------------ */

/** The EAN-13 check digit (mod-10, weights 1/3 alternating). */
function ean13CheckDigit(twelve: string): number {
  let sum = 0;
  for (let i = 0; i < 12; i++) {
    const d = Number(twelve[i]);
    sum += i % 2 === 0 ? d : d * 3;
  }
  return (10 - (sum % 10)) % 10;
}

/** Mint a checksum-valid EAN-13 on the Saudi GS1 prefix (629NNNNNNNNNC). */
export function generateEan13(): string {
  let body = "629";
  for (let i = 0; i < 9; i++) body += String(Math.floor(Math.random() * 10));
  return body + String(ean13CheckDigit(body));
}

/** Validate a candidate EAN-13 (digits + checksum). */
export function isValidEan13(code: string): boolean {
  if (!/^\d{13}$/.test(code)) return false;
  const twelve = code.slice(0, 12);
  return ean13CheckDigit(twelve) === Number(code[12]);
}

/* ------------------------------------------------------------------ */
/* the capture dialog                                                   */
/* ------------------------------------------------------------------ */

export function BarcodeCaptureDialog({
  open,
  onOpenChange,
  onCapture,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  /** receives the RAW captured code (scanner wedge, camera or typed). */
  onCapture: (code: string) => void;
}) {
  const { t, lang } = useT();
  const [mode, setMode] = useState<"manual" | "camera">("manual");
  const [manual, setManual] = useState("");
  const [camError, setCamError] = useState<"unsupported" | "denied" | null>(null);
  const [scanning, setScanning] = useState(false);
  const manualRef = useRef<HTMLInputElement>(null);

  /* camera lifecycle */
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const loopRef = useRef<ReturnType<typeof setInterval> | null>(null);

  /* pure resource teardown — NO setState, so it is safe inside effect
   * cleanups (the react-hooks/purity rule stays clean). */
  const teardownStream = useCallback(() => {
    if (loopRef.current) {
      clearInterval(loopRef.current);
      loopRef.current = null;
    }
    if (streamRef.current) {
      for (const track of streamRef.current.getTracks()) track.stop();
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  }, []);

  const stopCamera = useCallback(() => {
    teardownStream();
    setScanning(false);
  }, [teardownStream]);

  const emit = useCallback(
    (raw: string) => {
      const code = raw.trim();
      if (!code) return;
      onCapture(code);
      toast.success(`${t("bcDetected")}: ${code}`);
      stopCamera();
      setManual("");
      onOpenChange(false);
    },
    [onCapture, onOpenChange, stopCamera, t]
  );

  const startCamera = useCallback(async () => {
    setCamError(null);
    const Ctor = detectorCtor();
    if (!Ctor) {
      setCamError("unsupported");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
        audio: false,
      });
      streamRef.current = stream;
      const video = videoRef.current;
      if (!video) return;
      video.srcObject = stream;
      video.setAttribute("playsinline", "true");
      await video.play();
      setScanning(true);
      const detector = new Ctor();
      loopRef.current = setInterval(async () => {
        if (!videoRef.current || videoRef.current.readyState < 2) return;
        try {
          const hits = await detector.detect(videoRef.current);
          if (hits.length > 0 && hits[0].rawValue) {
            emit(hits[0].rawValue);
          }
        } catch {
          /* transient decode errors are non-fatal — keep scanning */
        }
      }, 250);
    } catch {
      setCamError("denied");
      stopCamera();
    }
  }, [emit, stopCamera]);

  /* unmount hygiene — the camera MUST die with the dialog (pure teardown
   * only; the interactive state resets happen in the event handlers). */
  useEffect(() => teardownStream, [teardownStream]);

  /* wedge-friendliness: focus the manual input whenever manual mode opens */
  useEffect(() => {
    if (open && mode === "manual") {
      const id = window.setTimeout(() => manualRef.current?.focus(), 60);
      return () => window.clearTimeout(id);
    }
  }, [open, mode]);

  const submitManual = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    emit(manual);
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!o) {
          /* closing resets the session (event-handler context) */
          stopCamera();
          setManual("");
          setCamError(null);
          setMode("manual");
          onOpenChange(false);
        }
      }}
    >
      <DialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl p-0 sm:max-w-md">
        <div className="flex items-center gap-3 border-b border-slate-200/70 px-5 py-4 dark:border-white/10">
          <span className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-cyan-500 to-cyan-700 text-white shadow-lg" aria-hidden="true">
            <CatIcon name="barcode" className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <DialogTitle className="truncate font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
              {t("bcCaptureTitle")}
            </DialogTitle>
            <DialogDescription className="mt-0.5 text-[11.5px] font-semibold text-slate-500 dark:text-slate-400">
              {t("bcWedgeHint")}
            </DialogDescription>
          </div>
        </div>

        <div className="space-y-4 px-5 py-4">
          {/* mode switch */}
          <div className="grid grid-cols-2 gap-2 rounded-2xl bg-slate-100 p-1 dark:bg-white/5">
            <button
              type="button"
              onClick={() => {
                stopCamera();
                setMode("manual");
              }}
              className={cn(
                "flex h-9 items-center justify-center gap-1.5 rounded-xl text-[11.5px] font-extrabold transition",
                mode === "manual" ? "bg-white text-slate-900 shadow dark:bg-slate-800 dark:text-white" : "text-slate-500 dark:text-slate-400"
              )}
            >
              <CatIcon name="type" className="h-3.5 w-3.5" />
              {t("bcManualMode")}
            </button>
            <button
              type="button"
              onClick={() => setMode("camera")}
              className={cn(
                "flex h-9 items-center justify-center gap-1.5 rounded-xl text-[11.5px] font-extrabold transition",
                mode === "camera" ? "bg-white text-slate-900 shadow dark:bg-slate-800 dark:text-white" : "text-slate-500 dark:text-slate-400"
              )}
            >
              <CatIcon name="camera" className="h-3.5 w-3.5" />
              {t("bcCameraMode")}
            </button>
          </div>

          {mode === "manual" ? (
            <form onSubmit={submitManual} className="space-y-2.5">
              <Input
                ref={manualRef}
                value={manual}
                onChange={(e) => setManual(e.target.value)}
                dir="ltr"
                inputMode="numeric"
                autoFocus
                placeholder="6291234567890"
                className="h-11 rounded-xl font-mono text-[14px] font-bold tracking-wider"
                aria-label={t("bcManualMode")}
              />
              <Button
                type="submit"
                disabled={!manual.trim()}
                className="h-10 w-full gap-2 rounded-xl text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:opacity-50"
                style={{ backgroundImage: "linear-gradient(135deg, #06b6d4, #0891b2)" }}
              >
                <CatIcon name="check" className="h-4 w-4" />
                {t("bcSubmit")}
              </Button>
            </form>
          ) : (
            <div className="space-y-3">
              <div className="relative aspect-video overflow-hidden rounded-2xl bg-slate-900">
                <video ref={videoRef} className="h-full w-full object-cover" muted playsInline aria-label={t("bcCameraMode")} />
                {scanning ? (
                  <span className="pointer-events-none absolute inset-x-6 top-1/2 h-0.5 animate-pulse rounded-full bg-emerald-400 shadow-[0_0_12px_2px_rgba(52,211,153,0.8)]" aria-hidden="true" />
                ) : null}
                {!scanning ? (
                  <div className="absolute inset-0 grid place-items-center p-4 text-center">
                    <p className="text-[11.5px] font-bold text-slate-300">
                      {camError === "unsupported"
                        ? t("bcCameraUnsupported")
                        : camError === "denied"
                          ? t("bcCameraDenied")
                          : t("bcScanning")}
                    </p>
                  </div>
                ) : null}
              </div>
              {scanning ? (
                <p className="flex items-center justify-center gap-1.5 text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                  <CatIcon name="scan-line" className="h-3.5 w-3.5" />
                  {t("bcScanning")}
                </p>
              ) : null}
              <Button
                type="button"
                onClick={() => (scanning ? stopCamera() : void startCamera())}
                className="h-10 w-full gap-2 rounded-xl text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95"
                style={{ backgroundImage: "linear-gradient(135deg, #06b6d4, #0891b2)" }}
              >
                <CatIcon name={scanning ? "circle" : "camera"} className="h-4 w-4" />
                {scanning ? t("bcStopCamera") : t("bcStartCamera")}
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
