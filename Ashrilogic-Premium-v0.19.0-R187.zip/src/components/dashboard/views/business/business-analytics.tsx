"use client";

/**
 * Ashrilogic — BUSINESS-SUITE analytics panels (ROUND 131).
 *
 * Two premium data panels computed live from the dataset:
 *   1. «التوزيع حسب {col}» — horizontal gradient share bars grouped by the
 *      module's breakdown column (money- or count-aggregated) with the
 *      absolute + percentage readout per group.
 *   2. «الأعلى» — the module's top rows (by money or count) as ranked
 *      progress rows.
 *   3. «قراءة سريعة» — a one-line computed insight (the dominant breakdown
 *      group and its share).
 *
 * Everything is deterministic from the seeded dataset — no new backend
 * surface, the numbers always agree with the table/KPIs above.
 */
import { useMemo } from "react";
import { useT } from "@/lib/i18n";
import type { ModuleDataset } from "@/lib/module-data";
import { CatIcon } from "@/components/icon";
import { cn, fmtMoneyCell, fmtNum, grad, hexAlpha, numDir } from "@/lib/utils";
import { DashCard } from "@/components/dashboard/dash-shared";
import type { BizAnalyticsDef, BizCtx } from "./business-config";
import { countByValue, moneyByValue, colIndex, cellOf } from "./business-config";

export function BusinessAnalytics({
  ctx,
  analytics,
  c1,
  c2,
}: {
  ctx: BizCtx;
  analytics: BizAnalyticsDef;
  c1: string;
  c2: string;
}) {
  const { t, lang } = useT();
  const { data, cols, rows, currency } = ctx;

  const breakdown = useMemo(() => {
    const colLabel = (() => {
      const col = cols.find((c) => c.key === analytics.breakdownCol);
      return col ? (lang === "ar" ? col.ar : col.en) : analytics.breakdownCol;
    })();
    const moneyKey = data.valueKey ?? "";
    const groups =
      analytics.breakdownMode === "money" && moneyKey
        ? moneyByValue(rows, cols, analytics.breakdownCol, moneyKey)
        : countByValue(rows, cols, analytics.breakdownCol);
    const entries = [...groups.entries()].sort((a, b) => b[1] - a[1]);
    const total = entries.reduce((s, [, v]) => s + v, 0);
    return { colLabel, entries, total };
  }, [analytics.breakdownCol, analytics.breakdownMode, cols, rows, lang, data.valueKey, currency]);

  const topList = useMemo(() => {
    const moneyKey = data.valueKey ?? "";
    const li = colIndex(cols, analytics.topLabelCol);
    const mi = moneyKey ? colIndex(cols, moneyKey) : -1;
    const ranked =
      analytics.topMode === "money" && mi >= 0
        ? [...rows].sort((a, b) => Number(b.values[mi] ?? 0) - Number(a.values[mi] ?? 0))
        : [...rows].sort((a, b) => b.values.join(" ").length - a.values.join(" ").length);
    const top = ranked.slice(0, analytics.topCount);
    const values =
      analytics.topMode === "money" && mi >= 0
        ? top.map((r) => Number(r.values[mi] ?? 0))
        : top.map((r) => rows.filter((x) => x.statusKey === r.statusKey).length);
    const max = Math.max(...values, 1);
    return {
      labelCol: analytics.topLabelCol,
      rows: li >= 0 ? top.map((r) => (r.values[li] ?? "").trim() || "—") : top.map(() => "—"),
      values,
      max,
      isMoney: analytics.topMode === "money" && mi >= 0,
    };
  }, [analytics, cols, rows, data.valueKey]);

  const insight = useMemo(() => {
    const [rawTopName, topValue] = breakdown.entries[0] ?? [null, 0];
    if (!rawTopName) return null;
    /* ROUND 154 — resolve the status key to a localized label for the
     * insight sentence too (was showing the raw English key). */
    const isStatusCol = cols.find((c) => c.key === analytics.breakdownCol)?.kind === "status";
    const statusDef = isStatusCol ? data.statuses.find((s) => s.key === rawTopName) : null;
    const topName = statusDef ? (lang === "ar" ? statusDef.ar : statusDef.en) : rawTopName;
    const share = breakdown.total > 0 ? Math.round((topValue / breakdown.total) * 1000) / 10 : 0;
    const measure =
      analytics.breakdownMode === "money" && currency
        ? t("bizSubMoney", { money: fmtMoneyCell(Math.round(breakdown.total), lang, currency) })
        : t("bizSubCount", { count: fmtNum(breakdown.total, lang) });
    return { topName, share, measure };
  }, [breakdown, analytics.breakdownCol, analytics.breakdownMode, cols, data.statuses, currency, t, lang]);

  const fmtValue = (v: number): string => {
    if (topList.isMoney) {
      return fmtMoneyCell(v, lang, currency);
    }
    return fmtNum(v, lang);
  };

  return (
    <div className="grid gap-4 lg:grid-cols-3">
      {/* ---------- breakdown panel ---------- */}
      <DashCard
        title={t("bizBreakdownTitle", { col: breakdown.colLabel })}
        icon="chart-pie"
        action={
          <span className="rounded-full border border-slate-200 bg-slate-50 px-2.5 py-0.5 text-[10.5px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
            {analytics.breakdownMode === "money" ? t("bizByValue") : t("bizByCount")}
          </span>
        }
        className="lg:col-span-2"
      >
        <div className="space-y-3">
          {breakdown.entries.length === 0 ? (
            <p className="py-6 text-center text-[12px] font-semibold text-slate-400">{t("bizEmptyNoMatch")}</p>
          ) : (
            breakdown.entries.slice(0, 7).map(([rawLabel, value], i) => {
              const share = breakdown.total > 0 ? Math.round((value / breakdown.total) * 1000) / 10 : 0;
              const width = breakdown.total > 0 ? Math.max(4, Math.round((value / breakdown.total) * 100)) : 0;
              /* ROUND 154 — resolve status keys to localized labels.
               * When the breakdown column is the status column, the raw
               * value is the status KEY (e.g. "excellent") — we must
               * resolve it to the AR/EN label (e.g. "متميز" / "Excellent")
               * using the preset's statuses array. Previously the raw
               * English key was displayed, which the owner reported as
               * «تظهر باللغة الإنجليزية فقط». */
              const statusDef = ctx.cols.find((c) => c.key === analytics.breakdownCol)?.kind === "status"
                ? ctx.data.statuses.find((s) => s.key === rawLabel)
                : null;
              const label = statusDef
                ? (lang === "ar" ? statusDef.ar : statusDef.en)
                : rawLabel;
              return (
                <div key={`${rawLabel}-${i}`} className="group">
                  <div className="mb-1 flex items-baseline justify-between gap-3">
                    <span className="min-w-0 truncate text-[12px] font-bold text-slate-700 dark:text-slate-200">{label}</span>
                    <span dir={numDir(lang)} className="shrink-0 tabular-nums text-[11.5px] font-extrabold text-slate-500 dark:text-slate-400">
                      {analytics.breakdownMode === "money"
                        ? fmtMoneyCell(value, lang, currency)
                        : fmtNum(value, lang)}
                      <span className="ms-1.5 text-slate-400">({fmtNum(share, lang)}%)</span>
                    </span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-slate-100 dark:bg-white/10">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${width}%`,
                        backgroundImage: i === 0 ? grad(c1, c2) : grad(hexAlpha(c1, 0.75), hexAlpha(c2, 0.75)),
                        opacity: 1 - Math.min(i, 5) * 0.11,
                      }}
                    />
                  </div>
                </div>
              );
            })
          )}
        </div>
      </DashCard>

      {/* ---------- top list + insight ---------- */}
      <div className="space-y-4">
        <DashCard title={t("bizTopTitle", { count: fmtNum(topList.rows.length, lang) })} icon="trophy">
          <div className="space-y-2.5">
            {topList.rows.length === 0 ? (
              <p className="py-4 text-center text-[12px] font-semibold text-slate-400">{t("bizEmptyNoMatch")}</p>
            ) : (
              topList.rows.map((label, i) => {
                const v = topList.values[i] ?? 0;
                const width = Math.max(6, Math.round((v / topList.max) * 100));
                return (
                  <div key={`${label}-${i}`} className="flex items-center gap-3">
                    <span
                      className="grid h-6 w-6 shrink-0 place-items-center rounded-lg text-[10.5px] font-extrabold text-white tabular-nums"
                      style={{ backgroundImage: grad(c1, c2), opacity: 1 - Math.min(i, 4) * 0.15 }}
                      aria-hidden="true"
                    >
                      {fmtNum(i + 1, lang)}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-baseline justify-between gap-2">
                        <span className="min-w-0 truncate text-[11.5px] font-bold text-slate-700 dark:text-slate-200">{label}</span>
                        <span dir={numDir(lang)} className="shrink-0 text-[10.5px] font-extrabold tabular-nums text-slate-500 dark:text-slate-400">
                          {fmtValue(v)}
                        </span>
                      </div>
                      <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-slate-100 dark:bg-white/10">
                        <div className="h-full rounded-full" style={{ width: `${width}%`, backgroundImage: grad(c1, c2), opacity: 0.85 }} />
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </DashCard>

        {insight ? (
          <div
            className="relative overflow-hidden rounded-2xl border border-slate-200/80 p-4 dark:border-white/10"
            style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.1)}, ${hexAlpha(c2, 0.08)})` }}
          >
            <span className="absolute -end-6 -top-8 h-20 w-20 rounded-full" style={{ background: `radial-gradient(circle, ${hexAlpha(c1, 0.25)}, transparent 70%)` }} aria-hidden="true" />
            <p className="flex items-center gap-1.5 text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              <CatIcon name="sparkles" className="h-3 w-3" />
              {t("bizInsightTitle")}
            </p>
            <p className="mt-1.5 text-[12.5px] font-bold leading-relaxed text-slate-700 dark:text-slate-200">
              {t("bizInsightTop", { col: breakdown.colLabel, name: insight.topName, pct: fmtNum(insight.share, lang), measure: insight.measure })}
            </p>
          </div>
        ) : null}
      </div>
    </div>
  );
}
