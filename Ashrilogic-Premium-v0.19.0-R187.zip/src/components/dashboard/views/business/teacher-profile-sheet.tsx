"use client";

/**
 * Ashrilogic — the PREMIUM teacher profile sheet (ROUND 156).
 *
 * The owner's directive:
 *   «في جميع الأنظمة عند وحدة (المعلمون) قم بحذف الصفحة (تفاصيل السجل
 *    المعلمون) كاملة وإعادة تطويرها بطريقة مميزة وPremium بدقة عالية
 *    ومتصل بشكل جديد»
 *
 * The teachers module previously fell through to the generic MODE 4 grouped
 * passport inside RecordDetailSheet — a flat field list with no professional
 * identity. This dedicated sheet replaces it with a premium card-based teacher
 * profile (parity with the StudentProfileSheet pattern from ROUND 155):
 *
 *   • HEADER     — gradient avatar (initials), teacher display name, the
 *                  bilingual "Teacher profile" sub-line, Staff ID chip (mono,
 *                  RTL bidi-safe), and the staff-status pill (active /
 *                  training / leave / ended).
 *   • ACADEMIC   — a 2×N stat-card grid: subject taught, academic degree, plus
 *                  the WEEKLY PERIODS radial dial (a circular SVG gauge capped
 *                  at 30, color-graded by contract state) — the «الحصص
 *                  الأسبوعية» visual indicator the directive asked for.
 *   • CONTACT    — a single rounded card with the phone (LTR-formatted,
 *                  RTL-bidi-embedded) + joined date (Arabic-formatted medium
 *                  date) — the «بيانات التواصل والتعيين» section.
 *   • META       — created-at + last-updated stamp row (parity with the
 *                  generic record-detail sheet footer).
 *
 * Purity contract: every value is read off the row by column key (the same
 * ModuleRecordDTO + ColDef[] + StatusDef[] props the parent already passes
 * RecordDetailSheet). Every numeric / ID value renders through the ROUND 133
 * helpers (fmtNum / fmtId with dir={numDir(lang)}/{idDir}) so the Arabic
 * locale shows Arabic-Indic digits with the correct bidi embedding.
 *
 * Bilingual (AR/EN) with full RTL support — the sheet inherits the dialog's
 * dir={lang === "ar" ? "rtl" : "ltr"} from the parent and every text node
 * uses dir="auto" / labelTrack(lang) for the uppercase Latin-tracking
 * micro-labels. The new i18n keys (teacherProfileTitle,
 * teacherAcademicSection, teacherStaffId, …) live in
 * src/lib/i18n/domains/business.ts in all three locales (AR + EN + HI) for
 * type parity.
 */
import { useT, type I18nKey } from "@/lib/i18n";
import type { ColDef, StatusDef } from "@/lib/module-data";
import type { Lang, ModuleRecordDTO } from "@/lib/types";
import {
  cn,
  fmtId,
  fmtNum,
  grad,
  hexAlpha,
  idDir,
  initial,
  labelTrack,
  numDir,
  toArabicDigits,
} from "@/lib/utils";
import { CatIcon } from "@/components/icon";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";

/* ------------------------------------------------------------------ */
/* tone maps — the exact business-suite / inv-shared pill idiom        */
/* ------------------------------------------------------------------ */

const TONE_DOT: Record<string, string> = {
  emerald: "bg-emerald-500",
  amber: "bg-amber-500",
  rose: "bg-rose-500",
  sky: "bg-sky-500",
  violet: "bg-violet-500",
  slate: "bg-slate-400",
};

const TONE_STYLE: Record<string, string> = {
  emerald: "bg-emerald-500/12 text-emerald-700 dark:text-emerald-300",
  amber: "bg-amber-500/12 text-amber-700 dark:text-amber-300",
  rose: "bg-rose-500/12 text-rose-700 dark:text-rose-300",
  sky: "bg-sky-500/12 text-sky-700 dark:text-sky-300",
  violet: "bg-violet-500/12 text-violet-700 dark:text-violet-300",
  slate: "bg-slate-500/12 text-slate-600 dark:text-slate-300",
};

/* the education brand gradient — the exact pair catalog.ts assigns to the
 * `education` category (#6366f1 → #7c3aed), so the teacher profile sheet
 * visually belongs to the campus family while staying inside the brand
 * family. (Matches StudentProfileSheet for visual coherence.) */
const TEACHER_C = ["#6366f1", "#7c3aed"] as const;

/* per-status gradient (for the weekly-periods ring) — emerald for active,
 * sky for training, amber for leave, slate for ended. The same tones the
 * teachers preset's statuses already use. */
const STATUS_GRAD: Record<string, [string, string]> = {
  emerald: ["#10b981", "#059669"],
  sky: ["#0ea5e9", "#0284c7"],
  amber: ["#f59e0b", "#d97706"],
  rose: ["#f43f5e", "#be123c"],
  violet: ["#8b5cf6", "#6d5dfb"],
  slate: ["#64748b", "#475569"],
};

/* the weekly-periods dial is capped at 30 — the teachers preset's RNG range
 * is 4..26 (count(rng, 4, 26)), so 30 is a safe visual ceiling that still
 * leaves a comfortable head-room arc without saturating. */
const CLASSES_CAP = 30;

type TFunc = (key: I18nKey, vars?: Record<string, string | number>) => string;

/* ------------------------------------------------------------------ */
/* shared atoms (parity with student-profile-sheet)                     */
/* ------------------------------------------------------------------ */

/** ROUND 156.1 (TASK PRINT+ARABIC+CERT+STAFF) — the owner's directive:
 *  «عند استخدام اللغة العربية اجعل الأرقام (1,2,3,4,5) ايضاً تدعم
 *   النمط العربي» — every ASCII digit (1..0) in the parent/teacher profile
 *  sheets renders as Arabic-Indic (٠..٩) when the UI is Arabic. This
 *  supersedes ROUND 134 (which keeps IDs Western in the TABLE + print
 *  surfaces) for THIS surface only — the directive is scoped to the
 *  parent/teacher PROFILE sheet specifically. */
function arNumIfAR(text: string, lang: Lang): string {
  if (!text) return text;
  return lang === "ar" ? toArabicDigits(text) : text;
}

/** joined-stamp — medium date (the teachers preset's `joined` column holds
 *  an ISO date string; we render the medium locale-form). */
function fmtJoined(iso: string, lang: Lang): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB", { dateStyle: "medium" });
}

/** created/updated-stamp — medium date + HH:MM, same locale policy. */
function fmtStamp(iso: string, lang: Lang): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  const date = d.toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB", { dateStyle: "medium" });
  const time = d.toLocaleTimeString(lang === "ar" ? "ar-EG" : "en-GB", { hour: "2-digit", minute: "2-digit" });
  return `${date} · ${time}`;
}

/** the tone-colored status pill (business-suite idiom, optional icon). */
function Pill({ tone, label, icon }: { tone: string; label: string; icon?: string }) {
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1 text-[10.5px] font-extrabold",
        TONE_STYLE[tone] ?? TONE_STYLE.slate
      )}
      dir="auto"
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", TONE_DOT[tone] ?? TONE_DOT.slate)} aria-hidden="true" />
      {icon ? <CatIcon name={icon} className="h-3 w-3" /> : null}
      {label}
    </span>
  );
}

/** section heading — gradient icon chip + label + fading gradient rule. */
function SectionLabel({ icon, label, g1, g2, lang }: { icon: string; label: string; g1: string; g2: string; lang: Lang }) {
  return (
    <p className="flex items-center gap-2" dir="auto">
      <span className="grid h-5 w-5 shrink-0 place-items-center rounded-lg text-white" style={{ backgroundImage: grad(g1, g2) }} aria-hidden="true">
        <CatIcon name={icon} className="h-3 w-3" />
      </span>
      <span className={cn("shrink-0 text-[10px] font-extrabold uppercase text-slate-500 dark:text-slate-400", labelTrack(lang))}>{label}</span>
      <span className="h-px min-w-0 flex-1 bg-gradient-to-r from-slate-200 to-transparent dark:from-white/10" aria-hidden="true" />
    </p>
  );
}

/** mini stat card — icon tile + micro label + formatted value. */
function StatCard({
  icon,
  label,
  value,
  dir,
  valueClass,
  g1,
  g2,
  lang,
}: {
  icon: string;
  label: string;
  value: string;
  dir: "rtl" | "ltr" | "auto";
  valueClass?: string;
  g1: string;
  g2: string;
  lang: Lang;
}) {
  return (
    <div className="min-w-0 rounded-2xl border border-black/5 bg-slate-50/60 p-2.5 dark:border-white/10 dark:bg-white/[0.03]">
      <p className={cn("flex items-center gap-1.5 text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))} dir="auto">
        <span
          className="grid h-4 w-4 shrink-0 place-items-center rounded-md text-white"
          style={{ backgroundImage: grad(g1, g2) }}
          aria-hidden="true"
        >
          <CatIcon name={icon} className="h-2.5 w-2.5" />
        </span>
        <span className="truncate">{label}</span>
      </p>
      <p dir={dir} className={cn("mt-1 truncate font-display text-[15px] font-extrabold tabular-nums text-slate-800 dark:text-white", valueClass)}>
        {value}
      </p>
    </div>
  );
}

/** the always-visible action bar (edit + print + close). */
function SheetFooter({ t, onEdit, onPrint, onClose, g1, g2 }: { t: TFunc; onEdit?: () => void; onPrint?: () => void; onClose: () => void; g1: string; g2: string }) {
  return (
    <div className="flex shrink-0 flex-wrap items-center justify-end gap-2.5 border-t border-slate-200/70 bg-slate-50/60 px-5 py-3.5 dark:border-white/10 dark:bg-white/[0.02]">
      {onEdit ? (
        <Button
          type="button"
          onClick={onEdit}
          className="h-10 gap-2 rounded-xl px-4 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95"
          style={{ backgroundImage: grad(g1, g2) }}
        >
          <CatIcon name="pencil" className="h-4 w-4" />
          {t("bizEditBtn")}
        </Button>
      ) : null}
      {onPrint ? (
        <Button
          type="button"
          variant="outline"
          onClick={onPrint}
          className="h-10 gap-2 rounded-xl px-4 text-[12.5px] font-bold"
        >
          <CatIcon name="printer" className="h-4 w-4" />
          {t("bizPrintBtn")}
        </Button>
      ) : null}
      <Button
        type="button"
        variant="outline"
        onClick={onClose}
        className="h-10 rounded-xl px-5 text-[12.5px] font-extrabold"
      >
        {t("bizClose")}
      </Button>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* the weekly-periods radial dial — a circular SVG gauge out of CLASSES_CAP */
/* ------------------------------------------------------------------ */

/** A circular SVG progress dial for the weekly periods. The ring fills
 *  clockwise from the top, color-graded by the teacher's contract state
 *  (active → emerald, training → sky, leave → amber, ended → slate). The
 *  center shows the weekly periods count (Arabic-Indic digits in ar) + the
 *  "periods per week" sub-line. */
function PeriodsDial({ periods, tone, lang, t }: { periods: number; tone: string; lang: Lang; t: TFunc }) {
  const [g1, g2] = STATUS_GRAD[tone] ?? STATUS_GRAD.slate;
  const frac = Math.max(0, Math.min(1, periods / CLASSES_CAP));
  const R = 34;
  const C = 2 * Math.PI * R;
  const dash = C * frac;
  const gradId = `periodsGrad-${tone}`;
  return (
    <div className="relative grid h-24 w-24 shrink-0 place-items-center" dir={numDir(lang)}>
      <svg viewBox="0 0 80 80" className="h-24 w-24 -rotate-90" aria-hidden="true">
        <defs>
          <linearGradient id={gradId} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={g1} />
            <stop offset="100%" stopColor={g2} />
          </linearGradient>
        </defs>
        <circle cx="40" cy="40" r={R} fill="none" stroke="currentColor" strokeWidth="6" className="text-slate-200 dark:text-white/10" />
        <circle
          cx="40"
          cy="40"
          r={R}
          fill="none"
          stroke={`url(#${gradId})`}
          strokeWidth="6"
          strokeLinecap="round"
          strokeDasharray={`${dash} ${C}`}
          style={{ transition: "stroke-dasharray 0.6s ease" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span dir={numDir(lang)} className="font-display text-[20px] font-extrabold leading-none tabular-nums text-slate-800 dark:text-white">
          {fmtNum(periods, lang)}
        </span>
        <span dir={numDir(lang)} className="mt-0.5 text-[9px] font-extrabold uppercase text-slate-400 dark:text-slate-500">
          {t("teacherClassesHint")}
        </span>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* the premium teacher profile sheet                                   */
/* ------------------------------------------------------------------ */

/**
 * The premium «ملف المعلم» sheet. Props contract (wired by
 * business-suite.tsx — same shape as StudentProfileSheet / RecordDetailSheet
 * so the swap is a one-line conditional):
 *
 *   open / onOpenChange — Radix dialog control
 *   record              — the ModuleRecordDTO to display (null → nothing)
 *   cols / statuses      — the module preset's ColDef[] / StatusDef[]
 *   moduleName           — localized display name of the module
 *   onPrint              — optional print callback (footer print button)
 *   onEdit               — optional edit callback (footer edit button)
 */
export function TeacherProfileSheet({
  open,
  onOpenChange,
  record,
  cols,
  statuses,
  moduleName,
  onEdit,
  onPrint,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  record: ModuleRecordDTO | null;
  cols: ColDef[];
  statuses: StatusDef[];
  moduleName: string;
  onEdit?: () => void;
  onPrint?: () => void;
}) {
  const { t, lang } = useT();
  const [g1, g2] = TEACHER_C;

  if (!record) return null;

  /* read every cell by column key (the teachers preset contract):
   *   code, name, subject, degree, classes, phone, joined, status */
  const val = (key: string): string => {
    const i = cols.findIndex((c) => c.key === key);
    return i >= 0 ? record.values[i] ?? "" : "";
  };

  const name = val("name").trim() || record.values[1]?.trim() || record.values[0]?.trim() || "—";
  const code = val("code").trim();
  const subject = val("subject").trim();
  const degree = val("degree").trim();
  const classesRaw = val("classes").trim();
  const phone = val("phone").trim();
  const joined = val("joined").trim();
  const periods = Math.max(0, Number(classesRaw.replace(/[^\d.]/g, "")) || 0);

  const st = statuses.find((s) => s.key === record.statusKey);
  const tone = st?.tone ?? "slate";
  const [ag1, ag2] = STATUS_GRAD[tone] ?? STATUS_GRAD.slate;

  /* the contract-state headline — a one-line localized verdict driven by tone */
  const statusKey: I18nKey =
    tone === "emerald" ? "teacherStatusActive"
      : tone === "sky" ? "teacherStatusTraining"
        : tone === "amber" ? "teacherStatusLeave"
          : tone === "slate" ? "teacherStatusEnded"
            : "teacherStatusActive";
  const statusHeadline = t(statusKey);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        dir={lang === "ar" ? "rtl" : "ltr"}
        showCloseButton={false}
        className="flex max-h-[88vh] flex-col gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-xl"
      >
        {/* ---------------- header — gradient avatar + name + IDs + status ---------------- */}
        <div
          className="relative shrink-0 overflow-hidden border-b border-slate-200/70 px-5 pt-5 pb-4 dark:border-white/10"
          style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(g1, 0.16)}, ${hexAlpha(g2, 0.16)})` }}
        >
          <span
            className="absolute -end-8 -top-14 h-28 w-28 rounded-full"
            style={{ background: `radial-gradient(circle, ${hexAlpha(g1, 0.28)}, transparent 70%)` }}
            aria-hidden="true"
          />
          <span
            className="absolute -start-10 -bottom-16 h-32 w-32 rounded-full"
            style={{ background: `radial-gradient(circle, ${hexAlpha(g2, 0.18)}, transparent 70%)` }}
            aria-hidden="true"
          />
          <div className="relative flex items-center gap-3.5">
            <span
              className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl font-display text-2xl font-extrabold text-white shadow-lg"
              style={{ backgroundImage: grad(g1, g2), boxShadow: `0 12px 28px -12px ${hexAlpha(g1, 0.9)}` }}
              aria-hidden="true"
            >
              {initial(name)}
            </span>
            <div className="min-w-0 flex-1">
              <DialogTitle className="truncate font-display text-[16px] font-extrabold leading-tight text-slate-900 dark:text-white" dir="auto">
                {name}
              </DialogTitle>
              <DialogDescription className="mt-0.5 truncate text-[11.5px] font-bold text-slate-500 dark:text-slate-400" dir="auto">
                {t("teacherProfileTitle")} · {moduleName}
              </DialogDescription>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                {st ? <Pill tone={st.tone} label={lang === "ar" ? st.ar : st.en} icon={tone === "emerald" ? "award" : tone === "slate" ? "triangle-alert" : undefined} /> : null}
                {code ? (
                  <span
                    dir={idDir}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-slate-100 px-2 py-1 font-mono text-[10.5px] font-bold tabular-nums text-slate-600 dark:bg-white/10 dark:text-slate-300"
                  >
                    <CatIcon name="hash" className="h-3 w-3 shrink-0 text-slate-400" />
                    {t("teacherStaffId")}: {arNumIfAR(fmtId(code, lang), lang)}
                  </span>
                ) : null}
              </div>
            </div>
          </div>
        </div>

        {/* ---------------- body ---------------- */}
        <div className="nice-scroll min-h-0 flex-1 space-y-4 overflow-y-auto px-5 py-4">
          {/* ---------- academic info + weekly periods dial ---------- */}
          <div className="space-y-2.5">
            <SectionLabel icon="graduation-cap" label={t("teacherAcademic")} g1={g1} g2={g2} lang={lang} />
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              {/* left — the 2 academic stat cards */}
              <div className="grid grid-cols-1 gap-2.5">
                <StatCard icon="book-open" label={t("teacherSubject")} value={subject || "—"} dir="auto" g1="#6366f1" g2="#4f46e5" lang={lang} />
                <StatCard icon="award" label={t("teacherDegree")} value={degree || "—"} dir="auto" g1="#8b5cf6" g2="#7c3aed" lang={lang} />
              </div>
              {/* right — the weekly periods dial card (full-height) */}
              <div
                className="flex items-center justify-between gap-3 rounded-2xl border border-black/5 p-3 dark:border-white/10"
                style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(ag1, 0.1)}, ${hexAlpha(ag2, 0.08)})` }}
              >
                <div className="min-w-0">
                  <p className={cn("flex items-center gap-1 text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))} dir="auto">
                    <CatIcon name="calendar-days" className="h-3 w-3 shrink-0" />
                    {t("teacherClasses")}
                  </p>
                  <p dir={numDir(lang)} className="mt-1 font-display text-[22px] font-extrabold tabular-nums text-slate-800 dark:text-white">
                    {classesRaw ? fmtNum(periods, lang) : "—"}
                  </p>
                  <p className="mt-0.5 text-[10.5px] font-bold" style={{ color: ag2 }} dir="auto">
                    {statusHeadline}
                  </p>
                </div>
                <PeriodsDial periods={periods} tone={tone} lang={lang} t={t} />
              </div>
            </div>
          </div>

          {/* ---------- contact + appointment section ---------- */}
          <div className="space-y-2.5">
            <SectionLabel icon="phone" label={t("teacherContact")} g1={g1} g2={g2} lang={lang} />
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              {/* the phone card — LTR within RTL (so the digits read naturally) */}
              <div className="flex items-center justify-between gap-3 rounded-2xl border border-black/5 bg-slate-50/60 px-3.5 py-2.5 dark:border-white/10 dark:bg-white/[0.03]">
                <span className="flex items-center gap-2 text-[12px] font-extrabold text-slate-400 dark:text-slate-500" dir="auto">
                  <CatIcon name="smartphone" className="h-4 w-4 shrink-0 text-slate-400" />
                  {t("teacherPhone")}
                </span>
                {phone ? (
                  <span
                    dir="ltr"
                    className="font-display text-[14px] font-extrabold tabular-nums text-slate-700 dark:text-slate-200"
                  >
                    {arNumIfAR(phone, lang)}
                  </span>
                ) : (
                  <span className="text-[12px] font-bold italic text-slate-400" dir="auto">
                    {t("teacherNoContact")}
                  </span>
                )}
              </div>
              {/* the joined date card — medium-date locale-form */}
              <div className="flex items-center justify-between gap-3 rounded-2xl border border-black/5 bg-slate-50/60 px-3.5 py-2.5 dark:border-white/10 dark:bg-white/[0.03]">
                <span className="flex items-center gap-2 text-[12px] font-extrabold text-slate-400 dark:text-slate-500" dir="auto">
                  <CatIcon name="calendar" className="h-4 w-4 shrink-0 text-slate-400" />
                  {t("teacherJoined")}
                </span>
                <span dir="auto" className="font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
                  {joined ? fmtJoined(joined, lang) : "—"}
                </span>
              </div>
            </div>
          </div>

          {/* ---------- meta stamps ---------- */}
          <div className="flex flex-wrap items-center gap-2">
            <span
              dir={numDir(lang)}
              className="inline-flex items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/70 px-2.5 py-1 text-[10px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400"
            >
              <CatIcon name="calendar" className="h-3 w-3 shrink-0" />
              {t("teacherMetaStamp")} · {fmtStamp(record.updatedAt || record.createdAt, lang)}
            </span>
          </div>
        </div>

        <SheetFooter t={t} onEdit={onEdit} onPrint={onPrint} onClose={() => onOpenChange(false)} g1={g1} g2={g2} />
      </DialogContent>
    </Dialog>
  );
}
