"use client";

/**
 * Ashrilogic — BUSINESS-SUITE premium record dialog (ROUND 131).
 *
 * The schema-driven add/edit form for the ten commerce modules. The
 * config's BizFormSection[] drives rendering: sectioned gradient headers,
 * typed inputs (text / number / money / date / tel / select), required
 * gating, per-field hints, money-currency chips, and the id-column
 * auto-code chip on NEW records.
 *
 * The PRODUCTS module gets the flagship treatment (the owner's explicit
 * directive «إضافة المنتجات بطريقة احترافية ومتكاملة بدقة عالية»):
 *   - live margin derivation (cost × price → margin %)
 *   - live final-price-with-VAT preview
 *   - live stock-health preview (stock vs reorder → suggested status)
 *   - the bilingual name pair with an English-name hint
 *   - ROUND 141 product extras (the catalog module only): the premium
 *     media picker (6 photos, on/off switch, per-pick compression) + the
 *     variants builder (متغيرات — up to 20 rows: price override / stock
 *     carve-out / SKU)
 *
 * ROUND 141 (directive ㉕): the transaction modules (POS sales, purchases,
 * returns … — the config's payments flag) ride the structured 7-method
 * PaymentManagerSection (نقدي · بطاقة · تحويل · محفظة · مختلط · جزئي ·
 * آجل); the primary label ALSO lands in the legacy method cell so the
 * analytics breakdown keeps its contract verbatim.
 *
 * Saving maps back to the ModuleRecord contract: values[] aligned with
 * the preset columns + statusKey + the structured payment ledger + the
 * product gallery/variants — the SAME API the generic workspace uses
 * (create/update module-record).
 */
import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { useT } from "@/lib/i18n";
import type { ColDef, ModuleRow, StatusDef } from "@/lib/module-data";
import type { PaymentEntry } from "@/lib/payment-methods";
import { paymentsPrimaryLabel } from "@/lib/payment-methods";
import { fetchModuleRecords, uploadStoreImage } from "@/lib/api-client";
import type { InstanceDTO } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { cn, grad, hexAlpha } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PremiumDateInput } from "@/components/ui/premium-date-input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
/* ROUND 148 — the college/guardian dynamic pickers ride the same Popover +
 * cmdk primitives the quick-add dialog uses (the searchable parent
 * combobox). */
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command as CommandPrimitive } from "cmdk";
import { bizFieldHint, bizSectionTitle, type BizFormSection, type BizFieldDef } from "./business-config";
import { BarcodeCaptureDialog, generateEan13 } from "./barcode-capture";
import { PaymentManagerSection } from "./payment-manager";
import {
  ProductMediaPickerSection,
  VariantsBuilderSection,
  variantRowsFromDTO,
  variantRowsToWire,
  type ProductMediaPickerValue,
  type VariantsBuilderValue,
} from "@/components/dashboard/views/product-form-extras";

const TONE_DOT: Record<string, string> = {
  emerald: "bg-emerald-500",
  amber: "bg-amber-500",
  rose: "bg-rose-500",
  sky: "bg-sky-500",
  violet: "bg-violet-500",
  slate: "bg-slate-400",
};

export interface BizRecordDraft {
  record: ModuleRow | null;
  suggestedCode: string | null;
}

export function BusinessRecordDialog({
  open,
  onOpenChange,
  sections,
  cols,
  statuses,
  derive,
  draft,
  moduleName,
  currency,
  c1,
  c2,
  saving,
  onSave,
  instanceId,
  instance,
  productExtras = false,
  paymentsEnabled = false,
  receiptImage = false,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  sections: BizFormSection[];
  cols: ColDef[];
  statuses: StatusDef[];
  derive?: (values: Record<string, string>) => Record<string, string>;
  draft: BizRecordDraft | null;
  moduleName: string;
  currency: string;
  c1: string;
  c2: string;
  saving: boolean;
  onSave: (payload: {
    recordId: string | null;
    values: string[];
    statusKey: string;
    /** ROUND 141 (㉕) — the structured 7-method payment ledger. */
    payments: PaymentEntry[];
    /** ROUND 141 (product extras) — the uploaded/kept gallery (undefined =
     *  don't touch media) + the variant rows (undefined = keep). */
    gallery?: string[];
    variants?: { id?: string; name: string; price?: number; stock?: number; sku?: string }[];
    /** ROUND 156 — the optional receipt image (the expenses module): the
     *  managed /api/images URL after upload, null to clear, or undefined
     *  to leave the existing image untouched. */
    image?: string | null;
  }) => void;
  /** ROUND 141 — the workspace id (the photo uploads ride /store/media). */
  instanceId: string;
  /** ROUND 148 — the tenant's full DTO (modules[] drives the dynamic
   *  college + guardian pickers — same shape quick-add consumes). */
  instance: InstanceDTO;
  /** ROUND 141 — the catalog module (whichever module feeds the e-store):
   *  the media picker + the variants builder mount only there. */
  productExtras?: boolean;
  /** ROUND 141 (㉕) — transaction modules (POS sales, purchases, returns)
   *  ride the structured payment manager. */
  paymentsEnabled?: boolean;
  /** ROUND 156 — the expenses module (and any future module that needs an
   *  optional receipt photo) mounts the ReceiptImageSection: a single
   *  optional image upload through the existing /store/media pipeline that
   *  lands on the record's imageRef field. */
  receiptImage?: boolean;
}) {
  const { t, lang } = useT();
  const edit = draft?.record ?? null;

  /* field state keyed by column key — derived from the row (edit) or the
   * auto-code (add). The parent remounts via key per subject. */
  const idColKey = cols.find((c) => c.kind === "id")?.key ?? "";
  const statusColKey = cols.find((c) => c.kind === "status")?.key ?? "";
  const [values, setValues] = useState<Record<string, string>>(() => {
    const init: Record<string, string> = {};
    const stampDate = new Date();
    const isoDate = `${stampDate.getFullYear()}-${String(stampDate.getMonth() + 1).padStart(2, "0")}-${String(stampDate.getDate()).padStart(2, "0")}`;
    const stampTime = `${String(stampDate.getHours()).padStart(2, "0")}:${String(stampDate.getMinutes()).padStart(2, "0")}`;
    const allFields = sections.flatMap((s) => s.fields);
    for (const f of allFields) {
      if (edit) {
        const i = cols.findIndex((c) => c.key === f.colKey);
        init[f.colKey] = i >= 0 ? (edit.values[i] ?? "") : "";
      } else {
        if (f.colKey === idColKey && draft?.suggestedCode) {
          init[f.colKey] = draft.suggestedCode;
        } else if (f.autoStamp === "date") {
          init[f.colKey] = isoDate;
        } else if (f.autoStamp === "time") {
          init[f.colKey] = stampTime;
        } else {
          init[f.colKey] = "";
        }
      }
    }
    return init;
  });
  const [statusKey, setStatusKey] = useState(edit?.statusKey ?? "");
  const [invalid, setInvalid] = useState<Record<string, boolean>>({});
  /* ROUND 132 — barcode capture state (scan → fill the barcode field) */
  const [barcodeScanOpen, setBarcodeScanOpen] = useState(false);
  const [barcodeScanTarget, setBarcodeScanTarget] = useState<string | null>(null);

  /* ROUND 141 (㉕) — the structured 7-method payment ledger (edit prefills
   * from the row's payments). */
  const [payments, setPayments] = useState<PaymentEntry[]>(edit?.payments ?? []);
  /* ROUND 141 (product extras) — the media picker + the variants builder
   * values (edit prefills from the row's gallery/variants). */
  const [mediaValue, setMediaValue] = useState<ProductMediaPickerValue>(() => ({
    enabled: (edit?.gallery?.length ?? 0) > 0,
    items: (edit?.gallery ?? []).map((ref) => ({ ref, pending: false })),
  }));
  const [variantsValue, setVariantsValue] = useState<VariantsBuilderValue>(() => ({
    enabled: (edit?.variants?.length ?? 0) > 0,
    rows: variantRowsFromDTO(edit?.variants ?? []),
  }));
  const [mediaUploading, setMediaUploading] = useState(false);
  /* ROUND 156 — the optional receipt image (the expenses module): the
   *  current managed URL (kept on edit) OR a fresh data-URL preview while
   *  the upload is in flight; null = no image attached. */
  const [receiptImageValue, setReceiptImageValue] = useState<string | null>(edit?.imageRef ?? null);
  const [receiptImagePending, setReceiptImagePending] = useState<string | null>(null);
  const [receiptImageUploading, setReceiptImageUploading] = useState(false);
  const receiptImageFileRef = useRef<HTMLInputElement | null>(null);

  /* ROUND 148 — dynamic college + parent pickers (mirrors the quick-add
   * dialog). The tenant's `colleges` module feeds the college Select; the
   * `parents` module feeds the searchable guardian combobox. Both ride the
   * shared ["module-records", instance.id, …] cache key so opening this
   * dialog reuses the same data the quick-add dialog already fetched. The
   * college name is column index 1 in the colleges preset (the `name`
   * column); the parent name is column index 1 in the parents preset (the
   * `parent` column). The queries are only armed when the dialog is open
   * AND the tenant actually has the relevant module enabled. */
  const hasColleges = instance.modules.includes("colleges");
  const formHasCollege = sections.some((s) => s.fields.some((f) => f.colKey === "college"));
  const collegesQuery = useQuery({
    queryKey: ["module-records", instance.id, "colleges"],
    queryFn: () => fetchModuleRecords(instance.id, "colleges"),
    enabled: open && hasColleges && formHasCollege,
    staleTime: 30_000,
    retry: 0,
  });
  const collegeOptions = useMemo(() => {
    if (!hasColleges) return [];
    return (collegesQuery.data ?? [])
      .map((r) => r.values[1] ?? "")
      .filter((v) => v.trim() !== "")
      .map((v) => v.trim());
  }, [hasColleges, collegesQuery.data]);

  const hasParents = instance.modules.includes("parents");
  const formHasGuardian = sections.some((s) =>
    s.fields.some((f) => f.colKey === "guardian" || f.colKey === "parent")
  );
  const parentsQuery = useQuery({
    queryKey: ["module-records", instance.id, "parents"],
    queryFn: () => fetchModuleRecords(instance.id, "parents"),
    enabled: open && hasParents && formHasGuardian,
    staleTime: 30_000,
    retry: 0,
  });
  const parentOptions = useMemo(() => {
    if (!hasParents) return [];
    return (parentsQuery.data ?? [])
      .map((r) => r.values[1] ?? "")
      .filter((v) => v.trim() !== "")
      .map((v) => v.trim());
  }, [hasParents, parentsQuery.data]);

  /* the record's grand total (minor): the LAST money column of the preset
   * (POS grand total, purchases total …) — null when none. */
  const totalMinor = useMemo(() => {
    let last = -1;
    for (let i = 0; i < cols.length; i++) if (cols[i].kind === "money") last = i;
    if (last < 0) return null;
    const raw = Number(String(values[cols[last].key] ?? "").replace(/[^\d.-]/g, ""));
    return Number.isFinite(raw) && raw > 0 ? Math.round(raw * 100) : null;
  }, [cols, values]);
  const methodIndex = cols.findIndex((c) => c.key === "method");

  /* ROUND 131 — the products live-derivation: every keystroke recomputes
   * the margin cell + the suggested status (stock vs reorder). The derived
   * values write straight into the form state so the SAVED row always
   * carries the computed cells (the stored dataset derives them too). */
  useEffect(() => {
    if (!derive) return;
    const derived = derive(values);
    setValues((prev) => {
      let changed = false;
      const next = { ...prev };
      for (const [k, v] of Object.entries(derived)) {
        if (next[k] !== v) {
          next[k] = v;
          changed = true;
        }
      }
      return changed ? next : prev;
    });
    if (derived.status && statusColKey) {
      setStatusKey((prev) => (prev !== derived.status ? derived.status : prev));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [values.cost, values.price, values.stock, values.reorder, values.vat]);

  /* the products live-preview numbers (margin / final price / health) */
  const preview = useMemo(() => {
    if (!derive) return null;
    const cost = Number(values.cost);
    const price = Number(values.price);
    const vat = Number(values.vat || "0");
    const stock = Number(values.stock);
    const reorder = Number(values.reorder || "0");
    const margin = Number.isFinite(cost) && Number.isFinite(price) && price > 0 ? ((price - cost) / price) * 100 : null;
    const withVat = Number.isFinite(price) && price > 0 ? price * (1 + (Number.isFinite(vat) ? vat : 0) / 100) : null;
    const health: "ok" | "low" | "out" | null =
      values.stock === "" || !Number.isFinite(stock) ? null : stock <= 0 ? "out" : stock <= reorder ? "low" : "ok";
    return { margin, withVat, health };
  }, [derive, values.cost, values.price, values.vat, values.stock, values.reorder]);

  const setVal = (key: string, v: string) => setValues((prev) => ({ ...prev, [key]: v }));

  const allFields = useMemo(() => sections.flatMap((s) => s.fields), [sections]);

  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    /* required gating — every required field must hold a non-empty value */
    const bad: Record<string, boolean> = {};
    for (const f of allFields) {
      if (f.required && !(values[f.colKey] ?? "").trim()) bad[f.colKey] = true;
    }
    setInvalid(bad);
    if (Object.keys(bad).length > 0) {
      return;
    }
    /* ROUND 141 (product extras) — the variants validate FIRST (duplicate
     * names / bad numbers block the save with the precise toast). */
    let variantsWire: { id?: string; name: string; price?: number; stock?: number; sku?: string }[] | undefined;
    if (productExtras && variantsValue.enabled) {
      const wire = variantRowsToWire(variantsValue.rows);
      if (wire.error) {
        toast.error(wire.error);
        return;
      }
      variantsWire = wire.variants;
    }
    /* ROUND 141 (product extras) — the pending photos upload through
     * /store/media (the server re-encode is the single authority); kept
     * managed refs pass through untouched. */
    let galleryWire: string[] | undefined;
    if (productExtras && mediaValue.enabled) {
      setMediaUploading(true);
      try {
        const refs: string[] = [];
        for (const item of mediaValue.items) {
          if (item.pending) {
            const { url } = await uploadStoreImage(instanceId, item.ref);
            refs.push(url);
          } else {
            refs.push(item.ref);
          }
        }
        galleryWire = refs;
      } catch (err) {
        toast.error(err instanceof Error ? err.message : t("errorText"));
        setMediaUploading(false);
        return;
      }
      setMediaUploading(false);
    }
    /* ROUND 156 — the optional receipt image upload (the expenses module):
     * a pending data-URL goes through the /store/media pipeline now, and
     * the returned managed URL rides the API's `image` field. When the
     * receipt section is enabled the image payload is ALWAYS defined
     * (string for kept/new, null when the operator cleared it); undefined
     * means the section never mounted — leave the field untouched. */
    let imageWire: string | null | undefined;
    if (receiptImage) {
      if (receiptImagePending) {
        setReceiptImageUploading(true);
        try {
          const { url } = await uploadStoreImage(instanceId, receiptImagePending);
          imageWire = url;
        } catch (err) {
          toast.error(err instanceof Error ? err.message : t("errorText"));
          setReceiptImageUploading(false);
          return;
        }
        setReceiptImageUploading(false);
      } else {
        imageWire = receiptImageValue;
      }
    }
    /* map the key-based state back onto the preset column order; the
     * primary payment label rides the legacy method CELL (the analytics
     * breakdown keeps its contract) while the structured ledger rides
     * paymentsJson. */
    const primaryLabel = paymentsPrimaryLabel(payments);
    const arr = cols.map((c, i) =>
      c.kind === "status" ? statusKey : i === methodIndex && primaryLabel ? primaryLabel : (values[c.key] ?? "").trim()
    );
    onSave({
      recordId: edit?.id ?? null,
      values: arr,
      statusKey,
      payments,
      ...(galleryWire !== undefined ? { gallery: galleryWire } : {}),
      ...(variantsWire !== undefined ? { variants: variantsWire } : {}),
      ...(imageWire !== undefined ? { image: imageWire } : {}),
    });
  };

  const colLabel = (f: BizFieldDef): string => {
    const col = cols.find((c) => c.key === f.colKey);
    return col ? (lang === "ar" ? col.ar : col.en) : f.colKey;
  };

  const isStatusField = (f: BizFieldDef): boolean => f.colKey === statusColKey;

  return (
    <>
    <Dialog open={open} onOpenChange={(o) => !o && onOpenChange(o)}>
      <DialogContent
        dir={lang === "ar" ? "rtl" : "ltr"}
        className="flex max-h-[90vh] flex-col gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-2xl"
      >
        {/* gradient header */}
        <div
          className="relative flex shrink-0 items-center gap-3.5 overflow-hidden border-b border-slate-200/70 px-5 py-4 dark:border-white/10"
          style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.16)}, ${hexAlpha(c2, 0.16)})` }}
        >
          <span className="absolute -end-8 -top-14 h-28 w-28 rounded-full" style={{ background: `radial-gradient(circle, ${hexAlpha(c1, 0.3)}, transparent 70%)` }} aria-hidden="true" />
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg" style={{ backgroundImage: grad(c1, c2) }} aria-hidden="true">
            <CatIcon name={edit ? "pencil" : "plus"} className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <DialogTitle className="truncate font-display text-[15px] font-extrabold leading-tight text-slate-900 dark:text-white">
              {edit ? t("bizEditTitle") : t("bizAddTitle", { name: moduleName })}
            </DialogTitle>
            <DialogDescription className="mt-0.5 truncate text-[11.5px] font-semibold text-slate-500 dark:text-slate-400">
              {edit ? t("bizEditDesc") : t("bizAddDesc")}
            </DialogDescription>
          </div>
        </div>

        <form onSubmit={submit} noValidate className="flex min-h-0 flex-1 flex-col">
          <div className="nice-scroll min-h-0 flex-1 space-y-5 overflow-y-auto px-5 py-4">
            {sections.map((section) => {
              const sectionTitle = bizSectionTitle(section, lang, t);
              return (
              <section key={sectionTitle}>
                <p className="mb-3 flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  <CatIcon name={section.icon} className="h-3 w-3" />
                  {sectionTitle}
                </p>

                {/* the products live-preview strip rides the pricing section */}
                {preview && section.titleKey === "bizSecPricing" ? (
                  <div className="mb-3 grid grid-cols-2 gap-2.5 rounded-2xl border border-slate-200/80 bg-slate-50/60 p-3 dark:border-white/10 dark:bg-white/[0.03] sm:grid-cols-3">
                    <div>
                      <p className="text-[10px] font-extrabold uppercase tracking-wide text-slate-400">{t("bizMarginAuto")}</p>
                      <p dir="ltr" className={cn("mt-0.5 tabular-nums text-[14px] font-extrabold", preview.margin !== null && preview.margin >= 20 ? "text-emerald-600 dark:text-emerald-400" : "text-amber-600 dark:text-amber-400")}>
                        {preview.margin !== null ? `${preview.margin.toFixed(1)}%` : "—"}
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] font-extrabold uppercase tracking-wide text-slate-400">{t("bizPriceWithVat")}</p>
                      <p dir="ltr" className="mt-0.5 tabular-nums text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
                        {preview.withVat !== null ? `${preview.withVat.toFixed(2)} ${currency}` : "—"}
                      </p>
                    </div>
                    <div className="col-span-2 sm:col-span-1">
                      <p className="text-[10px] font-extrabold uppercase tracking-wide text-slate-400">{t("bizStockPreview")}</p>
                      <p className={cn("mt-0.5 flex items-center gap-1.5 text-[11.5px] font-extrabold", preview.health === "ok" ? "text-emerald-600 dark:text-emerald-400" : preview.health === "low" ? "text-amber-600 dark:text-amber-400" : "text-rose-600 dark:text-rose-400")}>
                        <CatIcon name={preview.health === "ok" ? "circle-check" : preview.health === "low" ? "triangle-alert" : "circle-x"} className="h-3.5 w-3.5 shrink-0" />
                        {preview.health === "ok" ? t("bizStockOk") : preview.health === "low" ? t("bizStockLow") : t("bizStockOut")}
                      </p>
                    </div>
                  </div>
                ) : null}

                <div className="grid gap-3 sm:grid-cols-2">
                  {section.fields.map((f) => {
                    const isStatus = isStatusField(f);
                    const numeric = f.type === "number" || f.type === "money";
                    const isDerivedMargin = f.colKey === "margin" && !!derive;

                    if (isStatus) {
                      if (statuses.length === 0) return null;
                      return (
                        <div key={f.colKey} className="space-y-1.5 sm:col-span-2">
                          <Label htmlFor={`biz-status`} className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                            <CatIcon name="badge-check" className="h-3 w-3 text-slate-400" aria-hidden="true" />
                            {colLabel(f)}
                            {derive ? (
                              <span className="inline-flex items-center gap-1 rounded-full bg-brand-500/10 px-1.5 py-px text-[10px] font-extrabold text-brand-600 dark:bg-brand-500/15 dark:text-brand-300">
                                <span className="h-1 w-1 animate-pulse rounded-full bg-brand-500" aria-hidden="true" />
                                {t("bizSuggestStatus")}
                              </span>
                            ) : null}
                          </Label>
                          <Select value={statusKey === "" ? "__none__" : statusKey} onValueChange={(v) => setStatusKey(v === "__none__" ? "" : v)}>
                            <SelectTrigger id="biz-status" className="h-10 rounded-xl text-[12.5px] font-semibold">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectGroup>
                                <SelectItem value="__none__">
                                  <span className="flex items-center gap-2 text-slate-400">
                                    <span className="h-2 w-2 rounded-full bg-slate-300 dark:bg-slate-600" aria-hidden="true" />
                                    —
                                  </span>
                                </SelectItem>
                                {statuses.map((s) => (
                                  <SelectItem key={s.key} value={s.key}>
                                    <span className="flex items-center gap-2">
                                      <span className={cn("h-2 w-2 rounded-full", TONE_DOT[s.tone])} aria-hidden="true" />
                                      {lang === "ar" ? s.ar : s.en}
                                    </span>
                                  </SelectItem>
                                ))}
                              </SelectGroup>
                            </SelectContent>
                          </Select>
                        </div>
                      );
                    }

                    if (f.type === "select" && f.options) {
                      const current = values[f.colKey] ?? "";
                      return (
                        <div key={f.colKey} className={cn("space-y-1.5", f.span === 2 && "sm:col-span-2")}>
                          <Label htmlFor={`biz-${f.colKey}`} className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                            {colLabel(f)}
                            {f.required ? <span className="text-rose-500">*</span> : null}
                          </Label>
                          <Select value={current === "" ? "__none__" : current} onValueChange={(v) => setVal(f.colKey, v === "__none__" ? "" : v)}>
                            <SelectTrigger id={`biz-${f.colKey}`} className="h-10 rounded-xl text-[12.5px] font-semibold">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectGroup>
                                <SelectItem value="__none__">
                                  <span className="text-slate-400">—</span>
                                </SelectItem>
                                {f.options.map((o) => (
                                  <SelectItem key={o.en} value={lang === "ar" ? o.ar : o.en}>
                                    {lang === "ar" ? o.ar : o.en}
                                  </SelectItem>
                                ))}
                              </SelectGroup>
                            </SelectContent>
                          </Select>
                          {bizFieldHint(f, lang, t) ? <p className="text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">{bizFieldHint(f, lang, t)}</p> : null}
                        </div>
                      );
                    }

                    /* ROUND 148 — College field: a dynamic Select populated
                     * from the tenant's `colleges` module records (mirrors the
                     * quick-add dialog). Only renders when the system has the
                     * `colleges` module AND college records exist; otherwise
                     * the field falls through to the generic text Input. */
                    if (f.colKey === "college" && hasColleges && collegeOptions.length > 0) {
                      return (
                        <div key={f.colKey} className={cn("space-y-1.5", f.span === 2 && "sm:col-span-2")}>
                          <Label htmlFor={`biz-${f.colKey}`} className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                            <CatIcon name="building" className="h-3 w-3 text-slate-400" aria-hidden="true" />
                            {colLabel(f)}
                            {f.required ? <span className="text-rose-500">*</span> : null}
                          </Label>
                          <Select value={values[f.colKey] ?? ""} onValueChange={(v) => setVal(f.colKey, v)}>
                            <SelectTrigger id={`biz-${f.colKey}`} className="h-10 rounded-xl text-[12.5px] font-semibold">
                              <SelectValue placeholder={lang === "ar" ? "اختر الكلية" : "Select college"} />
                            </SelectTrigger>
                            <SelectContent>
                              {collegeOptions.map((name) => (
                                <SelectItem key={name} value={name}>
                                  {name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          {bizFieldHint(f, lang, t) ? <p className="text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">{bizFieldHint(f, lang, t)}</p> : null}
                        </div>
                      );
                    }

                    /* ROUND 148 — Guardian/Parent field: a searchable combobox
                     * (cmdk) backed by the tenant's `parents` module records.
                     * The owner can TYPE a new name OR pick an existing parent.
                     * Only mounts when the tenant has the `parents` module;
                     * otherwise the field falls through to the text Input. */
                    if ((f.colKey === "guardian" || f.colKey === "parent") && hasParents) {
                      return (
                        <BizGuardianCombobox
                          key={f.colKey}
                          id={`biz-${f.colKey}`}
                          label={colLabel(f)}
                          required={!!f.required}
                          value={values[f.colKey] ?? ""}
                          onChange={(v) => setVal(f.colKey, v)}
                          options={parentOptions}
                          lang={lang}
                          placeholder={lang === "ar" ? "ابحث أو أضف ولي أمر..." : "Search or add guardian..."}
                          hint={bizFieldHint(f, lang, t) ?? undefined}
                          invalid={!!invalid[f.colKey]}
                        />
                      );
                    }

                    const showCodeChip = f.colKey === idColKey && !edit && draft?.suggestedCode;
                    /* ROUND 132 — the owner's immutability directives:
                     * the record ID (first id-kind column) is auto-generated
                     * and NEVER hand-editable (add shows the auto chip, edit
                     * shows the lock chip); locked fields render read-only
                     * with the lock chip; autoStamp fields are date/time
                     * stamped at open and stay locked. */
                    const isIdField = f.colKey === idColKey;
                    const isLocked = isIdField || f.locked === true || f.autoStamp !== undefined || isDerivedMargin;
                    const showLockChip = (isIdField && (!!edit || !draft?.suggestedCode)) || f.locked === true || f.autoStamp !== undefined;
                    const hint = bizFieldHint(f, lang, t);
                    /* ROUND 149 (TASK F) — date fields ride the new
                     * PremiumDateInput component (brand-colored calendar
                     * button + clear-X + Arabic-formatted hint rendered
                     * inside the component). The label + chips above stay;
                     * the legacy manual arabicDateDisplay is retired. */
                    const isDateField = f.type === "date";
                    return (
                      <div key={f.colKey} className={cn("space-y-1.5", f.span === 2 && "sm:col-span-2")}>
                        <label htmlFor={`biz-${f.colKey}`} className="flex flex-wrap items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                          {colLabel(f)}
                          {f.required ? <span className="text-rose-500">*</span> : null}
                          {f.money ? (
                            <span dir="ltr" className="rounded-full bg-slate-100 px-1.5 py-px text-[11px] font-bold text-slate-500 dark:bg-white/10 dark:text-slate-400">
                              {currency}
                            </span>
                          ) : null}
                          {showCodeChip ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-brand-500/10 px-1.5 py-px text-[10px] font-extrabold text-brand-600 dark:bg-brand-500/15 dark:text-brand-300">
                              <span className="h-1 w-1 animate-pulse rounded-full bg-brand-500" aria-hidden="true" />
                              {t("recCodeAutoChip")}
                            </span>
                          ) : null}
                          {showLockChip ? (
                            <span
                              className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-1.5 py-px text-[10px] font-extrabold text-slate-500 dark:bg-white/10 dark:text-slate-400"
                              title={isIdField ? t("bizIdImmutable") : t("bizAutoLocked")}
                            >
                              <CatIcon name="lock" className="h-2.5 w-2.5" aria-hidden="true" />
                              {t("bizAutoLocked")}
                            </span>
                          ) : null}
                        </label>
                        {isDateField ? (
                          <PremiumDateInput
                            id={`biz-${f.colKey}`}
                            value={values[f.colKey] ?? ""}
                            onChange={(e) => setVal(f.colKey, e.target.value)}
                            readOnly={isLocked}
                            aria-invalid={invalid[f.colKey] || undefined}
                            wrapperClassName={cn(f.span === 2 && "sm:col-span-2", isLocked && "opacity-80")}
                            inputClassName={cn(
                              invalid[f.colKey] && "border-rose-400 focus-visible:ring-rose-500/20",
                            )}
                          />
                        ) : (
                          <div className={cn("relative", f.barcode && "flex items-center gap-1.5")}>
                            <Input
                              id={`biz-${f.colKey}`}
                              type={numeric ? "number" : "text"}
                              inputMode={f.type === "tel" ? "tel" : numeric ? "decimal" : undefined}
                              step={f.type === "money" ? "0.01" : f.step}
                              min={f.min}
                              value={values[f.colKey] ?? ""}
                              onChange={(e) => setVal(f.colKey, e.target.value)}
                              dir={f.dir === "ltr" || numeric ? "ltr" : f.dir === "rtl" ? "rtl" : undefined}
                              placeholder={numeric ? "0" : ""}
                              readOnly={isLocked}
                              tabIndex={isIdField ? -1 : undefined}
                              aria-readonly={isIdField ? "true" : undefined}
                              aria-invalid={invalid[f.colKey] || undefined}
                              className={cn(
                                "h-10 rounded-xl text-[12.5px] font-semibold",
                                numeric && "text-end",
                                (isIdField || isDerivedMargin) && `font-mono ${lang === "ar" ? "text-end" : "text-start"}`,
                                isIdField && "pointer-events-none select-none cursor-not-allowed",
                                invalid[f.colKey] && "border-rose-400 focus-visible:ring-rose-500/20",
                                isLocked && "bg-slate-50 text-slate-500 dark:bg-white/[0.04] dark:text-slate-400",
                                f.barcode && "font-mono tracking-wide"
                              )}
                            />
                            {f.barcode ? (
                              <span className="flex shrink-0 items-center gap-1">
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="icon"
                                  aria-label={t("bizScanBarcode")}
                                  title={t("bizScanBarcode")}
                                  onClick={() => {
                                    setBarcodeScanTarget(f.colKey);
                                    setBarcodeScanOpen(true);
                                  }}
                                  className="h-10 w-10 rounded-xl"
                                >
                                  <CatIcon name="barcode" className="h-4 w-4" />
                                </Button>
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="icon"
                                  aria-label={t("bizGenerateBarcode")}
                                  title={t("bizGenerateBarcode")}
                                  onClick={() => {
                                    setVal(f.colKey, generateEan13());
                                    toast.success(t("bizBarcodeGenerated"));
                                  }}
                                  className="h-10 w-10 rounded-xl"
                                >
                                  <CatIcon name="wand-sparkles" className="h-4 w-4" />
                                </Button>
                              </span>
                            ) : null}
                          </div>
                        )}
                        {hint ? (
                          <p className="flex items-start gap-1 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                            <CatIcon name="info" className="mt-0.5 h-3 w-3 shrink-0" />
                            {hint}
                          </p>
                        ) : null}
                      </div>
                    );
                  })}
                </div>
              </section>
              );
            })}

            {/* ROUND 156 — the optional receipt image section (the expenses
                module): a single optional photo upload through the existing
                /store/media pipeline that lands on the record's imageRef
                field. Renders below the form sections, before the product
                extras + the payment manager. */}
            {receiptImage ? (
              <ReceiptImageSection
                value={receiptImageValue}
                pending={receiptImagePending}
                uploading={receiptImageUploading}
                onPick={() => receiptImageFileRef.current?.click()}
                onPending={(dataUrl) => {
                  setReceiptImagePending(dataUrl);
                  setReceiptImageValue(null);
                }}
                onClear={() => {
                  setReceiptImagePending(null);
                  setReceiptImageValue(null);
                }}
                fileRef={receiptImageFileRef}
                c1={c1}
                c2={c2}
              />
            ) : null}

            {/* ROUND 141 (product extras) — the media picker + the variants
                builder ride the CATALOG module's add/edit form (the owner's
                «صفحة المنتجات»: whichever module feeds the e-store). */}
            {productExtras ? (
              <>
                <ProductMediaPickerSection
                  value={mediaValue}
                  onChange={setMediaValue}
                  c1={c1}
                  c2={c2}
                />
                <VariantsBuilderSection
                  value={variantsValue}
                  onChange={setVariantsValue}
                  currency={currency}
                  c1={c1}
                  c2={c2}
                />
              </>
            ) : null}

            {/* ROUND 141 (directive ㉕) — the structured 7-method payment
                manager on the transaction modules (POS sales, purchases,
                returns): نقدي · بطاقة · تحويل بنكي · محفظة إلكترونية ·
                مختلط · دفعة جزئية · آجل. */}
            {paymentsEnabled ? (
              <PaymentManagerSection
                value={payments}
                onChange={setPayments}
                totalMinor={totalMinor}
                currency={currency}
                c1={c1}
                c2={c2}
              />
            ) : null}
          </div>

          {/* footer */}
          <div className="flex shrink-0 items-center justify-end gap-2.5 border-t border-slate-200/70 px-5 py-3.5 dark:border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={saving}
              className="h-10 rounded-xl px-4 text-[12.5px] font-bold hover:border-slate-300 hover:bg-slate-100 dark:hover:border-white/20 dark:hover:bg-white/5"
            >
              {t("bizCancel")}
            </Button>
            <Button
              type="submit"
              disabled={saving || mediaUploading || receiptImageUploading}
              className="h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:opacity-60"
              style={{ backgroundImage: grad(c1, c2) }}
            >
              {saving || mediaUploading || receiptImageUploading ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : <CatIcon name="check" className="h-4 w-4" />}
              {saving ? t("bizSaving") : mediaUploading || receiptImageUploading ? t("bizReceiptImageUploading") : t("bizSave")}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>

    {/* ROUND 132 — the barcode capture surface (hardware wedge / camera /
        manual) fills the field that requested it. */}
    <BarcodeCaptureDialog
      open={barcodeScanOpen}
      onOpenChange={setBarcodeScanOpen}
      onCapture={(code) => {
        if (barcodeScanTarget) setVal(barcodeScanTarget, code);
      }}
    />
    </>
  );
}



/* ------------------------------------------------------------------ */
/* ROUND 148 — BizGuardianCombobox.                                    */
/* The searchable parent/guardian picker for the full record dialog.  */
/* Mirrors the quick-add dialog's GuardianCombobox: a cmdk-based       */
/* dropdown that lets the operator TYPE a new name OR pick an existing */
/* parent from the tenant's `parents` module records. The trailing    */
/* chevron toggles the dropdown; the add-new row appears when the      */
/* typed search does not match an existing option.                     */
/* ------------------------------------------------------------------ */
function BizGuardianCombobox({
  id,
  label,
  required,
  value,
  onChange,
  options,
  lang,
  placeholder,
  hint,
  invalid,
}: {
  id: string;
  label: string;
  required: boolean;
  value: string;
  onChange: (v: string) => void;
  options: string[];
  lang: string;
  placeholder: string;
  hint?: string;
  invalid?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return options;
    return options.filter((o) => o.toLowerCase().includes(q));
  }, [options, search]);

  const showAddNew =
    search.trim() !== "" &&
    !options.some((o) => o.toLowerCase() === search.trim().toLowerCase());

  return (
    <div className={cn("space-y-1.5")}>
      <Label
        htmlFor={id}
        className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
      >
        <CatIcon name="users" className="h-3 w-3 text-slate-400" aria-hidden="true" />
        {label}
        {required ? <span className="text-rose-500">*</span> : null}
      </Label>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <div className="relative">
            <Input
              id={id}
              type="text"
              value={value || search}
              onChange={(e) => {
                setSearch(e.target.value);
                onChange(e.target.value);
                if (!open) setOpen(true);
              }}
              onFocus={() => setOpen(true)}
              placeholder={placeholder}
              className={cn(
                "h-10 rounded-xl text-[12.5px] font-semibold pe-8",
                invalid && "border-rose-400 focus-visible:ring-rose-500/20"
              )}
              role="combobox"
              aria-expanded={open}
              aria-autocomplete="list"
            />
            <button
              type="button"
              tabIndex={-1}
              onClick={() => setOpen((o) => !o)}
              className="absolute inset-y-0 end-0 me-2.5 grid h-7 w-7 place-items-center rounded-lg text-slate-400"
              aria-label={lang === "ar" ? "عرض القائمة" : "Show list"}
            >
              <CatIcon name={open ? "chevron-up" : "chevron-down"} className="h-3.5 w-3.5" />
            </button>
          </div>
        </PopoverTrigger>
        <PopoverContent
          className="max-h-64 w-[--radix-popover-trigger-width] overflow-y-auto p-0 nice-scroll"
          align="start"
          onOpenAutoFocus={(e) => e.preventDefault()}
        >
          <CommandPrimitive filter={() => 1} className="rounded-xl">
            <div className="p-1">
              {filtered.length === 0 && !showAddNew ? (
                <p className="px-3 py-6 text-center text-[11.5px] font-semibold text-slate-400">
                  {lang === "ar" ? "لا توجد نتائج" : "No results"}
                </p>
              ) : null}
              {filtered.map((name) => (
                <button
                  key={name}
                  type="button"
                  onClick={() => {
                    onChange(name);
                    setSearch("");
                    setOpen(false);
                  }}
                  className={cn(
                    "flex w-full items-center gap-2 rounded-lg px-3 py-2 text-start text-[12px] font-semibold transition hover:bg-slate-100 dark:hover:bg-white/[0.06]",
                    value === name &&
                      "bg-brand-500/10 text-brand-600 dark:bg-brand-500/15 dark:text-brand-300"
                  )}
                >
                  <CatIcon name="user" className="h-3.5 w-3.5 shrink-0 text-slate-400" aria-hidden="true" />
                  <span className="truncate">{name}</span>
                  {value === name ? (
                    <CatIcon name="check" className="ms-auto h-3.5 w-3.5 text-brand-500" aria-hidden="true" />
                  ) : null}
                </button>
              ))}
              {showAddNew ? (
                <button
                  type="button"
                  onClick={() => {
                    onChange(search.trim());
                    setSearch("");
                    setOpen(false);
                  }}
                  className="flex w-full items-center gap-2 rounded-lg border-t border-slate-100 px-3 py-2 text-start text-[12px] font-extrabold text-brand-600 transition hover:bg-brand-500/10 dark:border-white/[0.06] dark:text-brand-300 dark:hover:bg-brand-500/15"
                >
                  <CatIcon name="plus-circle" className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                  <span>
                    {lang === "ar" ? "إضافة " : "Add "}
                    &ldquo;{search.trim()}&rdquo;
                  </span>
                </button>
              ) : null}
            </div>
          </CommandPrimitive>
        </PopoverContent>
      </Popover>
      {hint ? (
        <p className="flex items-start gap-1 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
          <CatIcon name="info" className="mt-0.5 h-3 w-3 shrink-0" aria-hidden="true" />
          {hint}
        </p>
      ) : null}
    </div>
  );
}


/* ------------------------------------------------------------------ */
/* ROUND 156 — ReceiptImageSection.                                   */
/* The premium single-image picker for the expenses module's optional  */
/* receipt photo. Mirrors the product media picker's idiom (canvas     */
/* compression → /store/media upload → managed ref) but collapses it    */
/* to ONE image (no on/off switch, no extras, no cover rotation):      */
/*  • an empty drop-zone tile with a dashed border and the brand       */
/*    gradient icon when no image is set;                              */
/*  • a 4:3 preview tile with hover-replace / clear affordances when  */
/*    an image is set (managed URL or pending data-URL);              */
/*  • a small spinner overlay while the upload is in flight;          */
/*  • the field is OPTIONAL — leaving it empty is always valid.       */
/* ------------------------------------------------------------------ */

const RECEIPT_MAX_INPUT = 8 * 1024 * 1024;
const RECEIPT_MIME_RE = /^image\/(png|jpe?g|webp)$/;

/** Read a picked file into a preserve-aspect JPEG data-URL (max 1600px
 *  on the long side, quality 0.85 — small enough for a quick upload,
 *  large enough to remain legible on screen + in print). The server
 *  re-encode to clean WebP stays the single authority. */
async function receiptImageFromFile(file: File): Promise<string> {
  if (!RECEIPT_MIME_RE.test(file.type)) throw new Error("bad-type");
  if (file.size > RECEIPT_MAX_INPUT) throw new Error("too-large");

  const objectUrl = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error("corrupt"));
      image.src = objectUrl;
    });
    const srcW = img.naturalWidth;
    const srcH = img.naturalHeight;
    if (!srcW || !srcH) throw new Error("corrupt");

    const MAX = 1600;
    const scale = Math.min(1, MAX / Math.max(srcW, srcH));
    const drawW = Math.round(srcW * scale);
    const drawH = Math.round(srcH * scale);

    const canvas = document.createElement("canvas");
    canvas.width = drawW;
    canvas.height = drawH;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("corrupt");
    ctx.imageSmoothingQuality = "high";
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, drawW, drawH);
    ctx.drawImage(img, 0, 0, drawW, drawH);
    return canvas.toDataURL("image/jpeg", 0.85);
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}

function ReceiptImageSection({
  value,
  pending,
  uploading,
  onPick,
  onPending,
  onClear,
  fileRef,
  c1,
  c2,
}: {
  value: string | null;
  pending: string | null;
  uploading: boolean;
  onPick: () => void;
  onPending: (dataUrl: string) => void;
  onClear: () => void;
  fileRef: React.RefObject<HTMLInputElement | null>;
  c1: string;
  c2: string;
}) {
  const { t } = useT();

  const handleFile = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const file = files[0];
    try {
      const dataUrl = await receiptImageFromFile(file);
      onPending(dataUrl);
    } catch (error) {
      const reason = error instanceof Error ? error.message : "corrupt";
      toast.error(
        reason === "too-large"
          ? t("bizReceiptImageTooLarge")
          : reason === "bad-type"
            ? t("bizReceiptImageBadType")
            : t("errorText")
      );
    }
    /* reset the input so picking the same file twice still fires onChange */
    if (fileRef.current) fileRef.current.value = "";
  };

  const preview = pending ?? value;

  return (
    <section className="rounded-2xl border border-slate-200/80 bg-slate-50/50 p-3.5 dark:border-white/10 dark:bg-white/[0.02]">
      <input
        ref={fileRef}
        type="file"
        accept="image/png,image/jpeg,image/webp"
        className="hidden"
        onChange={(e) => handleFile(e.target.files)}
      />
      <div className="flex items-start gap-3">
        <span
          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
          style={{ backgroundImage: grad(c1, c2) }}
          aria-hidden="true"
        >
          <CatIcon name="image" className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
            {t("bizReceiptImageTitle")}
          </p>
          <p className="mt-0.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("bizReceiptImageDesc")}
          </p>
        </div>
        {preview ? (
          <button
            type="button"
            onClick={onClear}
            className="inline-flex h-8 shrink-0 items-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 text-[10.5px] font-extrabold text-slate-600 transition hover:border-rose-300 hover:text-rose-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300 dark:hover:text-rose-400"
          >
            <CatIcon name="trash-2" className="h-3 w-3" />
            {t("bizReceiptImageRemove")}
          </button>
        ) : null}
      </div>

      <div className="mt-3">
        {preview ? (
          <button
            type="button"
            onClick={onPick}
            className="group relative block w-full overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-white/10 dark:bg-white/[0.03]"
            aria-label={t("bizReceiptImageReplace")}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={preview}
              alt={t("bizReceiptImageTitle")}
              className="mx-auto max-h-64 w-auto object-contain p-2"
            />
            <span className="pointer-events-none absolute inset-0 flex items-center justify-center bg-slate-900/0 opacity-0 transition group-hover:bg-slate-900/40 group-hover:opacity-100">
              <span className="inline-flex items-center gap-1.5 rounded-lg bg-white/95 px-3 py-1.5 text-[11px] font-extrabold text-slate-700 shadow">
                <CatIcon name="refresh-cw" className="h-3 w-3" />
                {t("bizReceiptImageReplace")}
              </span>
            </span>
            {uploading ? (
              <span className="absolute inset-0 grid place-items-center bg-white/80 backdrop-blur-sm">
                <span className="inline-flex items-center gap-2 rounded-lg bg-white px-3 py-1.5 text-[11px] font-extrabold text-slate-700 shadow">
                  <CatIcon name="refresh-cw" className="h-3 w-3 animate-spin" />
                  {t("bizReceiptImageUploading")}
                </span>
              </span>
            ) : null}
          </button>
        ) : (
          <button
            type="button"
            onClick={onPick}
            className="flex w-full flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-slate-200 bg-white/60 px-4 py-8 text-center transition hover:border-brand-300 hover:bg-brand-50/40 dark:border-white/15 dark:bg-white/[0.02] dark:hover:border-brand-500/40 dark:hover:bg-brand-500/5"
          >
            <span
              className="grid h-11 w-11 place-items-center rounded-2xl text-white shadow-md"
              style={{ backgroundImage: grad(c1, c2) }}
              aria-hidden="true"
            >
              <CatIcon name="upload" className="h-5 w-5" />
            </span>
            <span className="text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("bizReceiptImagePick")}
            </span>
            <span className="text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
              {t("bizReceiptImageHint")}
            </span>
          </button>
        )}
      </div>
    </section>
  );
}
