"use client";

/**
 * Ashrilogic — the POS TERMINAL dialog (ROUND 132 — the owner's flagship).
 *
 * «صفحة (نقاط البيع) عند (اضافة نقط البيع) طورها لتكون متكاملة
 *  باحترافية حيث يمكن البحث عن المنتجات لإضافتها الي السلة عن طريق
 *  (كود المنتج، اسم المنتج، الباركود) ويمكن مسح باركود المنتج عن
 *  اجهزة الباركود أو الكاميرا أو توصيله عن طريق البلوتوث»
 *
 * A full sale session in one dialog:
 *   1. LOCKED METADATA BAND — رقم العملية (auto POS-XXXXXXXX), الكاشير
 *      (the signed-in owner), الفرع (the workspace's first branch or the
 *      org name), التاريخ (today) and الوقت (a LIVE ticking clock — the
 *      saved time is the save-moment stamp). None of it is editable — the
 *      owner's second directive, enforced visually (lock chips) AND
 *      structurally (the values never come from form state).
 *   2. PRODUCT SEARCH — by code (SKU), name (AR+EN) or barcode, with an
 *      instant-results list and Enter-to-add-first.
 *   3. BARCODE CAPTURE — a dedicated always-focusable scan field (hardware
 *      USB / Bluetooth HID wedge scanners type here + Enter) and a camera
 *      scanner (native BarcodeDetector — see barcode-capture.tsx).
 *   4. THE CART — quantity steppers, live line totals, subtotal / VAT /
 *      discount / grand total, payment method, one-tap best sellers.
 *   5. SAVE — maps back onto the POS module-record contract (the same
 *      create API the generic dialog uses).
 *
 * The catalog resolves from the workspace's REAL products rows (سجلاتي)
 * first, then the deterministic demo products, and falls back to the
 * inventory items when the system has no products module (fun-sector
 * POS systems) — the terminal never shows an empty catalog unless the
 * system truly has nothing sellable.
 */
import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { useT } from "@/lib/i18n";
import type { InstanceDTO } from "@/lib/types";
import { buildModuleDataset, buildRecordsDataset, type ColDef, type ModuleRow } from "@/lib/module-data";
import type { PaymentEntry } from "@/lib/payment-methods";
import { paymentsPrimaryLabel } from "@/lib/payment-methods";
import { fetchModuleRecords } from "@/lib/api-client";
import { colIndex } from "./business-config";
import { normalizeSearch, grad, hexAlpha, cn, fmtNum, fmtId, numDir } from "@/lib/utils";
import { CatIcon } from "@/components/icon";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { BarcodeCaptureDialog } from "./barcode-capture";
import { PaymentManagerSection } from "./payment-manager";

/* the unified sellable-catalog item (products module OR inventory items). */
export interface PosCatalogItem {
  id: string;
  name: string;
  nameEn: string;
  sku: string;
  barcode: string;
  category: string;
  price: number;
  vat: number;
  stock: number;
  sold: number;
}

/* ROUND 141 (directive ㉕) — the legacy PAY_OPTIONS select was RETIRED: the
   POS checkout now rides the structured 7-method payment manager (نقدي ·
   بطاقة · تحويل بنكي · محفظة إلكترونية · مختلط · جزئي · آجل — the same
   premium section as the record dialogs); the primary ledger label lands
   in the legacy method cell so the analytics breakdown keeps its
   contract. */

/* the live clock — Arabic UI keeps latin numerals for tabular alignment. */
function useNow(active: boolean): Date {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    if (!active) return;
    const id = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(id);
  }, [active]);
  return now;
}

const isoToday = (d: Date): string =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

const hhmm = (d: Date): string =>
  `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;

export function PosTerminalDialog({
  open,
  onOpenChange,
  instance,
  suggestedCode,
  saving,
  onSave,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  instance: InstanceDTO;
  suggestedCode: string | null;
  saving: boolean;
  onSave: (payload: {
    recordId: string | null;
    values: string[];
    statusKey: string;
    /** ROUND 133 — the customer link that drives the loyalty engine. */
    meta?: { customerPhone: string; customerName: string };
    /** ROUND 141 (㉕) — the structured 7-method payment ledger. */
    payments: PaymentEntry[];
  }) => void;
}) {
  const { t, lang } = useT();
  const now = useNow(open);
  const currency = instance.org.currency;
  const c1 = "#0ea5e9";
  const c2 = "#0369a1";

  /* ---------------- catalog (real rows → demo products → inventory) --- */
  const hasProducts = instance.modules.includes("products");
  const catalogModule = hasProducts ? "products" : instance.modules.includes("inventory") ? "inventory" : null;

  const realRowsQuery = useQuery({
    queryKey: ["module-records", instance.id, catalogModule],
    queryFn: () => fetchModuleRecords(instance.id, catalogModule as string),
    enabled: open && !!catalogModule,
    staleTime: 30_000,
    retry: 0,
  });

  const catalog: PosCatalogItem[] = useMemo(() => {
    if (!catalogModule) return [];
    const lang0 = lang;
    /* ROUND 132 — MERGE: the owner's REAL rows first, then the demo
     * catalog (deduped by SKU so a real product never appears twice) —
     * the terminal always shows the full sellable catalog, and the
     * owner's own pricing wins for their real products. */
    const merged: PosCatalogItem[] = [];
    const seenSkus = new Set<string>();
    const push = (items: PosCatalogItem[]) => {
      for (const it of items) {
        if (it.sku && seenSkus.has(it.sku)) continue;
        if (it.sku) seenSkus.add(it.sku);
        merged.push(it);
      }
    };
    if (realRowsQuery.data && realRowsQuery.data.length > 0) {
      const ds = buildRecordsDataset(catalogModule, realRowsQuery.data, lang0, currency, instance.systemId);
      push(dsToCatalog(ds.cols, ds.rows, hasProducts));
    }
    const ds = buildModuleDataset(instance.id, catalogModule, lang0, currency, instance.systemId);
    push(dsToCatalog(ds.cols, ds.rows, hasProducts));
    return merged;
  }, [catalogModule, realRowsQuery.data, lang, currency, instance.id, instance.systemId, hasProducts]);

  const branchName = useMemo(() => {
    if (instance.modules.includes("branches")) {
      const ds = buildModuleDataset(instance.id, "branches", lang, currency, instance.systemId);
      const first = ds.rows.find((r) => r.statusKey === "open") ?? ds.rows[0];
      if (first) return first.values[0] ?? instance.org.name;
    }
    return instance.org.name;
  }, [instance.id, instance.modules, instance.org.name, instance.systemId, lang, currency]);

  /* ---------------- ROUND 133 — the customer link (loyalty engine) -----
   * The terminal can attach the sale to a REAL customer (customers module
   * rows, phone-keyed): the server stamps metaJson and the loyalty engine
   * accrues points + upserts the profile automatically on save. */
  const hasCustomers = instance.modules.includes("customers");
  const customersQuery = useQuery({
    queryKey: ["module-records", instance.id, "customers"],
    queryFn: () => fetchModuleRecords(instance.id, "customers"),
    enabled: open && hasCustomers,
    staleTime: 30_000,
    retry: 0,
  });
  const customerOptions = useMemo(() => {
    /* customers preset cols: name(0), phone(1), … */
    const opts: { phone: string; name: string }[] = [];
    const seen = new Set<string>();
    for (const row of customersQuery.data ?? []) {
      const phone = (row.values[1] ?? "").trim();
      const name = (row.values[0] ?? "").trim();
      if (!phone || seen.has(phone)) continue;
      seen.add(phone);
      opts.push({ phone, name: name || phone });
    }
    return opts;
  }, [customersQuery.data]);

  /* ---------------- cart + totals ---------------- */
  const [cart, setCart] = useState<Record<string, number>>({});
  const [query, setQuery] = useState("");
  const [scanValue, setScanValue] = useState("");
  const [discount, setDiscount] = useState("");
  /* ROUND 141 (㉕) — the structured 7-method ledger replaces the legacy
   * method select; بطاقة (the old terminal default مدى) stays the initial
   * pick — one tap switches to any of the other six. */
  const [payments, setPayments] = useState<PaymentEntry[]>([{ method: "card" }]);
  const [customerKey, setCustomerKey] = useState("none");
  const [cameraOpen, setCameraOpen] = useState(false);
  const scanRef = useRef<HTMLInputElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);

  /* the suite mounts this dialog CONDITIONALLY — every open is a fresh
   * mount, so the session state starts clean with no reset effects. The
   * only effect left is the scan-field autofocus (wedge scanners expect
   * focus on open). */
  useEffect(() => {
    if (!open) return;
    const id = window.setTimeout(() => scanRef.current?.focus(), 120);
    return () => window.clearTimeout(id);
  }, [open]);

  const addItem = (item: PosCatalogItem, qty = 1) => {
    setCart((prev) => ({ ...prev, [item.id]: (prev[item.id] ?? 0) + qty }));
    toast.success(t("posScanHit", { name: item.name }), { duration: 1400 });
  };

  const setQty = (id: string, qty: number) => {
    setCart((prev) => {
      const next = { ...prev };
      if (qty <= 0) delete next[id];
      else next[id] = qty;
      return next;
    });
  };

  const byExact = (codeRaw: string): PosCatalogItem | null => {
    const code = codeRaw.trim();
    if (!code) return null;
    const q = normalizeSearch(code);
    return (
      catalog.find((it) => normalizeSearch(it.barcode) === q && it.barcode) ??
      catalog.find((it) => normalizeSearch(it.sku) === q) ??
      null
    );
  };

  /* the wedge/camera entry: exact barcode or SKU hit → straight into the cart */
  const handleScan = (codeRaw: string) => {
    const hit = byExact(codeRaw);
    if (hit) {
      addItem(hit);
      setScanValue("");
      scanRef.current?.focus();
    } else {
      toast.error(t("posScanMiss"));
      setScanValue("");
      scanRef.current?.focus();
    }
  };

  /* ---------------- search results ---------------- */
  const results = useMemo(() => {
    const q = normalizeSearch(query);
    if (!q) return [] as PosCatalogItem[];
    return catalog
      .filter(
        (it) =>
          normalizeSearch(it.name).includes(q) ||
          normalizeSearch(it.nameEn).includes(q) ||
          normalizeSearch(it.sku).includes(q) ||
          normalizeSearch(it.barcode).includes(q)
      )
      .slice(0, 8);
  }, [query, catalog]);

  const popular = useMemo(
    () => [...catalog].sort((a, b) => b.sold - a.sold).slice(0, 6),
    [catalog]
  );

  /* ---------------- totals (live) ---------------- */
  const cartItems = useMemo(
    () =>
      Object.entries(cart)
        .map(([id, qty]) => ({ item: catalog.find((c) => c.id === id), qty }))
        .filter((x): x is { item: PosCatalogItem; qty: number } => !!x.item),
    [cart, catalog]
  );
  const subtotal = cartItems.reduce((s, { item, qty }) => s + item.price * qty, 0);
  const vatTotal = cartItems.reduce((s, { item, qty }) => s + item.price * qty * (item.vat / 100), 0);
  const discountNum = Math.max(0, Math.min(Number(discount) || 0, subtotal + vatTotal));
  const grand = Math.max(0, subtotal + vatTotal - discountNum);
  const totalUnits = cartItems.reduce((s, x) => s + x.qty, 0);

  const submit = () => {
    if (cartItems.length === 0) return;
    const stamp = new Date();
    const selectedCustomer = customerOptions.find((c) => c.phone === customerKey) ?? null;
    /* ROUND 141 (㉕) — the primary ledger label rides the legacy method cell
     * (the analytics breakdown keeps its contract). */
    const methodLabel = paymentsPrimaryLabel(payments) || "نقداً";
    onSave({
      recordId: null,
      values: [
        suggestedCode ?? "",
        instance.admin.name,
        branchName,
        isoToday(stamp),
        hhmm(stamp),
        String(totalUnits),
        discountNum.toFixed(2),
        grand.toFixed(2),
        methodLabel,
        "completed",
      ],
      statusKey: "completed",
      payments,
      /* ROUND 133 — the loyalty link travels with the sale */
      ...(selectedCustomer
        ? { meta: { customerPhone: selectedCustomer.phone, customerName: selectedCustomer.name } }
        : {}),
    });
  };

  const lockedChips = [
    { label: t("posTxNumber"), value: fmtId(suggestedCode ?? "—", lang), mono: true, icon: "hash", rtl: false },
    { label: t("posCashier"), value: instance.admin.name, mono: false, icon: "user-round", rtl: false },
    { label: t("posBranch"), value: branchName, mono: false, icon: "network", rtl: false },
    { label: t("posDate"), value: isoToday(now), mono: true, icon: "calendar", rtl: false },
    { label: t("posTime"), value: hhmm(now), mono: true, icon: "clock", rtl: false },
  ];

  return (
    <>
      <Dialog open={open} onOpenChange={(o) => !o && onOpenChange(o)}>
        <DialogContent
          dir={lang === "ar" ? "rtl" : "ltr"}
          className="flex max-h-[92vh] flex-col gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-4xl"
        >
          {/* gradient header + the LOCKED metadata band */}
          <div
            className="relative shrink-0 overflow-hidden border-b border-slate-200/70 dark:border-white/10"
            style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.16)}, ${hexAlpha(c2, 0.16)})` }}
          >
            <span className="absolute -end-10 -top-16 h-32 w-32 rounded-full" style={{ background: `radial-gradient(circle, ${hexAlpha(c1, 0.28)}, transparent 70%)` }} aria-hidden="true" />
            <div className="flex items-center gap-3.5 px-5 pt-4">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg" style={{ backgroundImage: grad(c1, c2) }} aria-hidden="true">
                <CatIcon name="calculator" className="h-5 w-5" />
              </span>
              <div className="min-w-0 flex-1">
                <DialogTitle className="truncate font-display text-[15px] font-extrabold leading-tight text-slate-900 dark:text-white">
                  {t("posTerminalTitle")}
                </DialogTitle>
                <DialogDescription className="mt-0.5 truncate text-[11.5px] font-semibold text-slate-500 dark:text-slate-400">
                  {t("posTerminalDesc")}
                </DialogDescription>
              </div>
              <span className="hidden items-center gap-1.5 rounded-full border border-slate-200 bg-white/80 px-2.5 py-1 text-[10px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 sm:inline-flex">
                <CatIcon name="lock" className="h-3 w-3" aria-hidden="true" />
                {t("posAutoLocked")}
              </span>
            </div>
            {/* the five system-stamped, non-editable fields */}
            <div className="grid grid-cols-2 gap-2 px-5 pb-4 pt-3 sm:grid-cols-3 lg:grid-cols-5">
              {lockedChips.map((chip) => (
                <div key={chip.label} className="min-w-0 rounded-xl border border-slate-200/80 bg-white/70 px-2.5 py-1.5 dark:border-white/10 dark:bg-white/[0.04]">
                  <p className="flex items-center gap-1 text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                    <CatIcon name={chip.icon} className="h-2.5 w-2.5 shrink-0" aria-hidden="true" />
                    {chip.label}
                  </p>
                  <p dir={chip.rtl ? numDir(lang) : chip.mono ? "ltr" : "auto"} className={cn("truncate text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200", chip.mono && "font-mono tabular-nums")}>
                    {chip.value}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="grid min-h-0 flex-1 gap-0 lg:grid-cols-[1.1fr_1fr]">
            {/* ---------- LEFT: search + scan + catalog ---------- */}
            <div className="nice-scroll min-h-0 space-y-3.5 overflow-y-auto border-e border-slate-200/60 px-5 py-4 dark:border-white/10">
              {/* the dedicated scan field — USB / Bluetooth HID wedge scanners type here */}
              <div
                className="cursor-text rounded-2xl border-2 border-dashed border-cyan-300/70 bg-cyan-50/40 px-3 py-2 dark:border-cyan-500/40 dark:bg-cyan-500/5"
                onClick={() => scanRef.current?.focus()}
              >
                <Label htmlFor="pos-scan" className="flex items-center justify-between gap-2 text-[10px] font-extrabold uppercase tracking-wide text-cyan-700 dark:text-cyan-300">
                  <span className="flex items-center gap-1.5">
                    <CatIcon name="barcode" className="h-3.5 w-3.5" aria-hidden="true" />
                    {t("posScanPh")}
                  </span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setCameraOpen(true);
                    }}
                    className="inline-flex items-center gap-1 rounded-full bg-cyan-600 px-2 py-0.5 text-[10px] font-extrabold text-white transition hover:brightness-110 active:scale-95"
                  >
                    <CatIcon name="camera" className="h-3 w-3" aria-hidden="true" />
                    {t("posScanCamera")}
                  </button>
                </Label>
                <Input
                  id="pos-scan"
                  ref={scanRef}
                  value={scanValue}
                  onChange={(e) => setScanValue(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      handleScan(scanValue);
                    }
                  }}
                  dir="ltr"
                  inputMode="numeric"
                  className="h-9 border-0 bg-transparent px-0 font-mono text-[14px] font-bold tracking-wider text-slate-800 focus-visible:ring-0 dark:text-slate-100"
                  aria-label={t("posScanPh")}
                />
                <p className="text-[9.5px] font-bold text-cyan-600/80 dark:text-cyan-400/80">{t("posScannerHint")}</p>
              </div>

              {/* product search by code / name / barcode */}
              <div className="space-y-2">
                <div className="relative">
                  <CatIcon name="search" className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden="true" />
                  <Input
                    ref={searchRef}
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        if (results.length > 0) {
                          addItem(results[0]);
                          setQuery("");
                        }
                      }
                    }}
                    placeholder={t("posSearchPh")}
                    className="h-10 rounded-xl ps-9 text-[12.5px] font-semibold"
                    aria-label={t("posSearchPh")}
                  />
                </div>

                {query ? (
                  results.length > 0 ? (
                    <ul className="space-y-1.5">
                      {results.map((it) => (
                        <li key={it.id}>
                          <button
                            type="button"
                            onClick={() => {
                              addItem(it);
                              setQuery("");
                            }}
                            className="flex w-full items-center gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2 text-start transition hover:border-cyan-300 hover:bg-cyan-50/50 active:scale-[0.99] dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-cyan-500/50 dark:hover:bg-cyan-500/10"
                          >
                            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-slate-100 text-slate-500 dark:bg-white/10 dark:text-slate-300" aria-hidden="true">
                              <CatIcon name="package" className="h-4 w-4" />
                            </span>
                            <span className="min-w-0 flex-1">
                              <span className="block truncate text-[12px] font-extrabold text-slate-800 dark:text-slate-100">{it.name}</span>
                              <span dir="ltr" className="block truncate font-mono text-[10px] font-bold text-slate-400">
                                {it.sku}
                                {it.barcode ? ` · ${it.barcode}` : ""}
                              </span>
                            </span>
                            <span className="shrink-0 text-end">
                              <span dir="ltr" className="block text-[12px] font-extrabold tabular-nums text-emerald-600 dark:text-emerald-400">
                                {fmtNum(it.price, lang)} {currency}
                              </span>
                              <span className="block text-[9.5px] font-bold text-slate-400">
                                {t("posStock")}: {fmtNum(it.stock, lang)}
                              </span>
                            </span>
                          </button>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="rounded-xl border border-dashed border-slate-300 px-3 py-2.5 text-center text-[11px] font-bold text-slate-400 dark:border-white/15">
                      {t("posNoResults")}
                    </p>
                  )
                ) : (
                  /* best-sellers — one-tap add */
                  <div>
                    <p className="mb-1.5 text-[10px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">{t("posPopularItems")}</p>
                    {catalog.length === 0 ? (
                      <p className="rounded-xl border border-dashed border-amber-300 bg-amber-50/50 px-3 py-2.5 text-center text-[11px] font-bold text-amber-600 dark:border-amber-500/40 dark:bg-amber-500/10 dark:text-amber-300">
                        {t("posCatalogEmpty")}
                      </p>
                    ) : (
                      <div className="flex flex-wrap gap-1.5">
                        {popular.map((it) => (
                          <button
                            key={it.id}
                            type="button"
                            onClick={() => addItem(it)}
                            className="max-w-full truncate rounded-full border border-slate-200 bg-white px-3 py-1.5 text-[11px] font-extrabold text-slate-600 transition hover:border-cyan-300 hover:bg-cyan-50/60 hover:text-cyan-700 active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:border-cyan-500/50"
                          >
                            {it.name}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* ---------- RIGHT: the cart + payment ---------- */}
            <div className="nice-scroll min-h-0 overflow-y-auto px-5 py-4">
              {cartItems.length === 0 ? (
                <div className="grid h-full place-items-center">
                  <div className="text-center">
                    <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-300 dark:bg-white/5 dark:text-slate-600" aria-hidden="true">
                      <CatIcon name="shopping-basket" className="h-7 w-7" />
                    </span>
                    <p className="mt-2.5 text-[12px] font-bold text-slate-400">{t("posCartEmpty")}</p>
                  </div>
                </div>
              ) : (
                <ul className="space-y-1.5">
                  {cartItems.map(({ item, qty }) => (
                    <li key={item.id} className="rounded-xl border border-slate-200 bg-white px-2.5 py-2 dark:border-white/10 dark:bg-white/[0.03]">
                      <div className="flex items-center gap-2">
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-[12px] font-extrabold text-slate-800 dark:text-slate-100">{item.name}</span>
                          <span dir="ltr" className="block truncate font-mono text-[9.5px] font-bold text-slate-400">{item.sku}</span>
                        </span>
                        <span className="shrink-0 tabular-nums text-[10.5px] font-bold text-slate-400" dir="ltr">
                          {fmtNum(item.price, lang)} × {qty}
                        </span>
                        <span dir="ltr" className="shrink-0 text-[12px] font-extrabold tabular-nums text-slate-800 dark:text-slate-100">
                          {fmtNum(item.price * qty, lang)}
                        </span>
                      </div>
                      <div className="mt-1 flex items-center justify-between">
                        <div className="flex items-center gap-1" dir="ltr">
                          <button
                            type="button"
                            onClick={() => setQty(item.id, qty - 1)}
                            aria-label="-"
                            className="grid h-6 w-6 place-items-center rounded-lg border border-slate-200 bg-slate-50 text-[13px] font-extrabold text-slate-500 transition hover:border-slate-300 active:scale-90 dark:border-white/10 dark:bg-white/5 dark:text-slate-300"
                          >
                            −
                          </button>
                          <span className="min-w-7 text-center text-[12px] font-extrabold tabular-nums text-slate-700 dark:text-slate-200">{qty}</span>
                          <button
                            type="button"
                            onClick={() => setQty(item.id, qty + 1)}
                            aria-label="+"
                            className="grid h-6 w-6 place-items-center rounded-lg border border-slate-200 bg-slate-50 text-[13px] font-extrabold text-slate-500 transition hover:border-slate-300 active:scale-90 dark:border-white/10 dark:bg-white/5 dark:text-slate-300"
                          >
                            +
                          </button>
                        </div>
                        <button
                          type="button"
                          onClick={() => setQty(item.id, 0)}
                          className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[9.5px] font-extrabold text-rose-500 transition hover:bg-rose-50 active:scale-95 dark:hover:bg-rose-500/10"
                        >
                          <CatIcon name="trash-2" className="h-3 w-3" aria-hidden="true" />
                          {t("posRemoveItem")}
                        </button>
                      </div>
                    </li>
                  ))}
                </ul>
              )}

              {/* totals + payment */}
              <div className="mt-4 space-y-2.5 rounded-2xl border border-slate-200/80 bg-slate-50/60 p-3 dark:border-white/10 dark:bg-white/[0.03]">
                <p className="text-[10px] font-extrabold uppercase tracking-wide text-slate-400">
                  {t("posItemsCount", { count: String(cartItems.length), qty: String(totalUnits) })}
                </p>
                <div className="space-y-1 text-[12px] font-bold text-slate-600 dark:text-slate-300">
                  <p className="flex justify-between">
                    <span>{t("posSubtotal")}</span>
                    <span dir="ltr" className="tabular-nums">{fmtNum(subtotal, lang)} {currency}</span>
                  </p>
                  <p className="flex justify-between">
                    <span>{t("posVat")}</span>
                    <span dir="ltr" className="tabular-nums">{fmtNum(vatTotal, lang)} {currency}</span>
                  </p>
                  <div className="flex items-center justify-between gap-2">
                    <span className="shrink-0">{t("posDiscount")}</span>
                    <Input
                      type="number"
                      min={0}
                      step="0.01"
                      inputMode="decimal"
                      value={discount}
                      onChange={(e) => setDiscount(e.target.value)}
                      dir="ltr"
                      className="h-8 w-28 rounded-lg text-end text-[12px] font-extrabold tabular-nums"
                      aria-label={t("posDiscount")}
                    />
                  </div>
                </div>
                <div className="flex items-baseline justify-between border-t border-slate-200 pt-2 dark:border-white/10">
                  <span className="text-[11px] font-extrabold uppercase tracking-wide text-slate-500 dark:text-slate-400">{t("posGrandTotal")}</span>
                  <span dir={numDir(lang)} className="font-display text-[20px] font-extrabold tabular-nums text-emerald-600 dark:text-emerald-400">
                    {fmtNum(grand, lang)} {currency}
                  </span>
                </div>
                {/* ROUND 141 (directive ㉕) — the structured 7-method payment
                    manager replaces the legacy method select: نقدي · بطاقة ·
                    تحويل بنكي · محفظة إلكترونية · مختلط · جزئي · آجل (mixed
                    splits + partial amounts + payable due dates included). */}
                <div className="pt-1">
                  <PaymentManagerSection
                    value={payments}
                    onChange={setPayments}
                    totalMinor={Math.round(grand * 100)}
                    currency={currency}
                    c1={c1}
                    c2={c2}
                  />
                </div>
                {/* ROUND 133 — ربط بالعميل: the sale can carry the customer
                    link that feeds the loyalty engine automatically. */}
                {hasCustomers ? (
                  <div className="space-y-1.5 pt-1">
                    <Label className="text-[10px] font-extrabold uppercase tracking-wide text-slate-400">{t("posCustomer")}</Label>
                    <Select value={customerKey} onValueChange={setCustomerKey}>
                      <SelectTrigger className="h-9 rounded-xl text-[12px] font-bold" aria-label={t("posCustomer")}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectGroup>
                          <SelectItem value="none">{t("posCustomerNone")}</SelectItem>
                          {customerOptions.map((c) => (
                            <SelectItem key={c.phone} value={c.phone}>
                              {c.name} · {c.phone}
                            </SelectItem>
                          ))}
                        </SelectGroup>
                      </SelectContent>
                    </Select>
                    <p className="flex items-center gap-1 text-[9.5px] font-bold leading-relaxed text-violet-500 dark:text-violet-400">
                      <CatIcon name="award" className="h-3 w-3 shrink-0" aria-hidden="true" />
                      {t("posLoyaltyHint")}
                    </p>
                  </div>
                ) : null}
              </div>
            </div>
          </div>

          {/* footer */}
          <div className="flex shrink-0 items-center justify-between gap-3 border-t border-slate-200/70 px-5 py-3.5 dark:border-white/10">
            <p dir={numDir(lang)} className="hidden text-[11px] font-extrabold tabular-nums text-slate-400 sm:block">
              {cartItems.length > 0 ? `${fmtNum(grand, lang)} ${currency}` : "—"}
            </p>
            <div className="flex items-center gap-2.5">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                disabled={saving}
                className="h-10 rounded-xl px-4 text-[12.5px] font-bold hover:border-slate-300 hover:bg-slate-100 dark:hover:border-white/20 dark:hover:bg-white/5"
              >
                {t("bizCancel")}
              </Button>
              <Button
                type="button"
                onClick={submit}
                disabled={saving || cartItems.length === 0}
                className="h-10 gap-2 rounded-xl px-6 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:opacity-50"
                style={{ backgroundImage: grad(c1, c2) }}
              >
                {saving ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : <CatIcon name="check" className="h-4 w-4" />}
                {saving ? t("bizSaving") : t("posComplete")}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* the camera capture surface */}
      <BarcodeCaptureDialog open={cameraOpen} onOpenChange={setCameraOpen} onCapture={handleScan} />
    </>
  );
}

/* ------------------------------------------------------------------ */
/* catalog extraction (products preset OR inventory preset rows)        */
/* ------------------------------------------------------------------ */

function dsToCatalog(
  cols: ColDef[],
  rows: ModuleRow[],
  isProducts: boolean
): PosCatalogItem[] {
  const iName = colIndex(cols, isProducts ? "name" : "item");
  const iNameEn = colIndex(cols, "nameEn");
  const iSku = colIndex(cols, "sku");
  const iBarcode = colIndex(cols, "barcode");
  const iPrice = colIndex(cols, isProducts ? "price" : "unit");
  const iVat = colIndex(cols, "vat");
  const iStock = colIndex(cols, isProducts ? "stock" : "qty");
  const iSold = colIndex(cols, "sold");
  const iCat = colIndex(cols, "category");
  const num = (v: string | undefined): number => {
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  };
  return rows.map((r) => ({
    id: r.id,
    name: (iName >= 0 ? r.values[iName] : "") || "—",
    nameEn: iNameEn >= 0 ? (r.values[iNameEn] ?? "") : "",
    sku: iSku >= 0 ? (r.values[iSku] ?? "") : "",
    barcode: iBarcode >= 0 ? (r.values[iBarcode] ?? "") : "",
    category: iCat >= 0 ? (r.values[iCat] ?? "") : "",
    price: num(iPrice >= 0 ? r.values[iPrice] : "0"),
    vat: num(iVat >= 0 ? r.values[iVat] : "0"),
    stock: num(iStock >= 0 ? r.values[iStock] : "0"),
    sold: num(iSold >= 0 ? r.values[iSold] : "0"),
  }));
}
