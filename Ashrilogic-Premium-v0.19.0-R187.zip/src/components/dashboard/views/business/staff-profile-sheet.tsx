"use client";

/**
 * Ashrilogic — the PREMIUM staff profile sheet (ROUND 156.1, TASK PRINT+ARABIC+CERT+STAFF).
 *
 * The owner's directive:
 *   «في جميع الأنظمة عند وحدة (الموظفون) قم بحذف (تفاصيل الموظفون) كاملة
 *    ثم قم بإعادة تطويرها بطريقة احترافية ومميزة وPremium»
 *
 * The staff module previously fell through to the generic MODE 4 grouped
 * passport inside RecordDetailSheet — a flat field list with no HR
 * identity. This dedicated sheet replaces it with a premium HR dossier
 * (parity with the StudentProfileSheet / TeacherProfileSheet pattern):
 *
 *   • HEADER        — gradient avatar (initials), employee display name,
 *                     the bilingual "Staff profile" sub-line, Employee #
 *                     chip (mono, RTL bidi-safe), and the duty-status
 *                     pill (on-duty / leave / field-task / suspended).
 *   • EMPLOYMENT    — a 2×N stat-card grid: department, role, contract
 *                     type, shift, hire date (Arabic-formatted), contract
 *                     end date.
 *   • IDENTITY      — national ID (mono, Arabic-Indic in AR), gender,
 *                     birth date (Arabic-formatted).
 *   • CONTACT       — phone (LTR within RTL) + email (LTR within RTL),
 *                     both with Arabic-Indic digits in AR mode.
 *   • FINANCIAL     — salary (formatted with currency, Arabic-Indic in
 *                     AR), bank, IBAN (mono, Arabic-Indic digits in AR).
 *   • META          — created-at + last-updated stamp row (parity with
 *                     the generic record-detail sheet footer).
 *
 * Purity contract: every value is read off the row by column key (the
 * same ModuleRecordDTO + ColDef[] + StatusDef[] props the parent
 * already passes RecordDetailSheet). The staff preset's columns are:
 *   code, name, nationalId, gender, birthDate, dept, role, email,
 *   phone, hired, contract, endDate, shift, salary, bank, iban, status
 * Every numeric / ID value renders through `arNumIfAR` so the Arabic
 * locale shows Arabic-Indic digits (per the ROUND 156.1 directive —
 * scoped to the staff profile sheet specifically).
 *
 * Bilingual (AR/EN/HI) with full RTL support — the sheet inherits the
 * dialog's dir={lang === "ar" ? "rtl" : "ltr"} and every text node
 * uses dir="auto" / labelTrack(lang).
 */
import { useT, type I18nKey } from "@/lib/i18n";
import type { ColDef, StatusDef } from "@/lib/module-data";
import type { Lang, ModuleRecordDTO } from "@/lib/types";
import {
  cn,
  fmtId,
  grad,
  hexAlpha,
  idDir,
  initial,
  labelTrack,
  numDir,
  toArabicDigits,
} from "@/lib/utils";
import { dateOnly, fullDate } from "@/components/dashboard/dash-shared";
import { CatIcon } from "@/components/icon";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";

/* ------------------------------------------------------------------ */
/* tone maps — the exact business-suite / inv-shared pill idiom        */
/* ------------------------------------------------------------------ */

const TONE_DOT: Record<string, string> = {
  emerald: "bg-emerald-500",
  amber: "bg-amber-500",
  rose: "bg-rose-500",
  sky: "bg-sky-500",
  violet: "bg-violet-500",
  slate: "bg-slate-400",
};

const TONE_STYLE: Record<string, string> = {
  emerald: "bg-emerald-500/12 text-emerald-700 dark:text-emerald-300",
  amber: "bg-amber-500/12 text-amber-700 dark:text-amber-300",
  rose: "bg-rose-500/12 text-rose-700 dark:text-rose-300",
  sky: "bg-sky-500/12 text-sky-700 dark:text-sky-300",
  violet: "bg-violet-500/12 text-violet-700 dark:text-violet-300",
  slate: "bg-slate-500/12 text-slate-600 dark:text-slate-300",
};

/* the staff/HR brand gradient — a warm amber → violet pair (the HR
 * category's identity per catalog.ts), distinct from teachers (indigo)
 * and parents (emerald→sky) so the staff module has its own visual
 * signature inside the brand family. */
const STAFF_C = ["#f59e0b", "#8b5cf6"] as const;

/* per-status gradient — emerald for on-duty, amber for leave, sky for
 * field-task, rose for suspended. Mirrors the staff preset's status
 * tones exactly. */
const STATUS_GRAD: Record<string, [string, string]> = {
  emerald: ["#10b981", "#059669"],
  amber: ["#f59e0b", "#d97706"],
  rose: ["#f43f5e", "#be123c"],
  sky: ["#0ea5e9", "#0284c7"],
  violet: ["#8b5cf6", "#6d5dfb"],
  slate: ["#64748b", "#475569"],
};

type TFunc = (key: I18nKey, vars?: Record<string, string | number>) => string;

/* ------------------------------------------------------------------ */
/* shared atoms (parity with teacher / parent profile sheets)          */
/* ------------------------------------------------------------------ */

/** ROUND 156.1 (TASK PRINT+ARABIC+CERT+STAFF) — the owner's directive:
 *  «عند استخدام اللغة العربية اجعل الأرقام (1,2,3,4,5) ايضاً تدعم
 *   النمط العربي» — every ASCII digit in the staff profile sheet renders
 *  as Arabic-Indic (٠..٩) when the UI is Arabic. Scoped to THIS surface
 *  only (table + print surfaces keep ROUND 134's Western-ID policy). */
function arNumIfAR(text: string, lang: Lang): string {
  if (!text) return text;
  return lang === "ar" ? toArabicDigits(text) : text;
}

/** created/updated-stamp — medium date + HH:MM, same locale policy. */
function fmtStamp(iso: string, lang: Lang): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return fullDate(d, lang);
}

/** the tone-colored status pill (business-suite idiom, optional icon). */
function Pill({ tone, label, icon }: { tone: string; label: string; icon?: string }) {
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1 text-[10.5px] font-extrabold",
        TONE_STYLE[tone] ?? TONE_STYLE.slate
      )}
      dir="auto"
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", TONE_DOT[tone] ?? TONE_DOT.slate)} aria-hidden="true" />
      {icon ? <CatIcon name={icon} className="h-3 w-3" /> : null}
      {label}
    </span>
  );
}

/** section heading — gradient icon chip + label + fading gradient rule. */
function SectionLabel({ icon, label, g1, g2, lang }: { icon: string; label: string; g1: string; g2: string; lang: Lang }) {
  return (
    <p className="flex items-center gap-2" dir="auto">
      <span className="grid h-5 w-5 shrink-0 place-items-center rounded-lg text-white" style={{ backgroundImage: grad(g1, g2) }} aria-hidden="true">
        <CatIcon name={icon} className="h-3 w-3" />
      </span>
      <span className={cn("shrink-0 text-[10px] font-extrabold uppercase text-slate-500 dark:text-slate-400", labelTrack(lang))}>{label}</span>
      <span className="h-px min-w-0 flex-1 bg-gradient-to-r from-slate-200 to-transparent dark:from-white/10" aria-hidden="true" />
    </p>
  );
}

/** mini stat card — icon tile + micro label + formatted value. */
function StatCard({
  icon,
  label,
  value,
  dir,
  valueClass,
  g1,
  g2,
  lang,
}: {
  icon: string;
  label: string;
  value: string;
  dir: "rtl" | "ltr" | "auto";
  valueClass?: string;
  g1: string;
  g2: string;
  lang: Lang;
}) {
  return (
    <div className="min-w-0 rounded-2xl border border-black/5 bg-slate-50/60 p-2.5 dark:border-white/10 dark:bg-white/[0.03]">
      <p className={cn("flex items-center gap-1.5 text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))} dir="auto">
        <span
          className="grid h-4 w-4 shrink-0 place-items-center rounded-md text-white"
          style={{ backgroundImage: grad(g1, g2) }}
          aria-hidden="true"
        >
          <CatIcon name={icon} className="h-2.5 w-2.5" />
        </span>
        <span className="truncate">{label}</span>
      </p>
      <p dir={dir} className={cn("mt-1 truncate font-display text-[14px] font-extrabold tabular-nums text-slate-800 dark:text-white", valueClass)}>
        {value}
      </p>
    </div>
  );
}

/** the always-visible action bar (edit + print + close). */
function SheetFooter({ t, onEdit, onPrint, onClose, g1, g2 }: { t: TFunc; onEdit?: () => void; onPrint?: () => void; onClose: () => void; g1: string; g2: string }) {
  return (
    <div className="flex shrink-0 flex-wrap items-center justify-end gap-2.5 border-t border-slate-200/70 bg-slate-50/60 px-5 py-3.5 dark:border-white/10 dark:bg-white/[0.02]">
      {onEdit ? (
        <Button
          type="button"
          onClick={onEdit}
          className="h-10 gap-2 rounded-xl px-4 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95"
          style={{ backgroundImage: grad(g1, g2) }}
        >
          <CatIcon name="pencil" className="h-4 w-4" />
          {t("bizEditBtn")}
        </Button>
      ) : null}
      {onPrint ? (
        <Button
          type="button"
          variant="outline"
          onClick={onPrint}
          className="h-10 gap-2 rounded-xl px-4 text-[12.5px] font-bold"
        >
          <CatIcon name="printer" className="h-4 w-4" />
          {t("bizPrintBtn")}
        </Button>
      ) : null}
      <Button
        type="button"
        variant="outline"
        onClick={onClose}
        className="h-10 rounded-xl px-5 text-[12.5px] font-extrabold"
      >
        {t("bizClose")}
      </Button>
    </div>
  );
}

/** the salary formatter — major-currency locale form with Arabic-Indic
 *  digits in AR (SAR 4,500.00 → ٤٬٥٠٠٫٠٠ ر.س). */
function fmtSalary(raw: string, lang: Lang, currency: string): string {
  const n = Number(String(raw).replace(/[^\d.-]/g, ""));
  if (!Number.isFinite(n)) return raw || "—";
  try {
    return new Intl.NumberFormat(lang === "ar" ? "ar-EG" : "en-GB", {
      style: "currency",
      currency: currency || "SAR",
      maximumFractionDigits: 2,
    }).format(n);
  } catch {
    return `${raw} ${currency}`;
  }
}

/**
 * The premium «ملف الموظف» sheet.
 */
export function StaffProfileSheet({
  open,
  onOpenChange,
  record,
  cols,
  statuses,
  moduleName,
  currency = "SAR",
  onEdit,
  onPrint,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  record: ModuleRecordDTO | null;
  cols: ColDef[];
  statuses: StatusDef[];
  moduleName: string;
  currency?: string;
  onEdit?: () => void;
  onPrint?: () => void;
}) {
  const { t, lang } = useT();
  const [g1, g2] = STAFF_C;

  if (!record) return null;

  /* read every cell by column key (the staff preset contract):
   *   code, name, nationalId, gender, birthDate, dept, role, email,
   *   phone, hired, contract, endDate, shift, salary, bank, iban, status */
  const val = (key: string): string => {
    const i = cols.findIndex((c) => c.key === key);
    return i >= 0 ? record.values[i] ?? "" : "";
  };

  const name = val("name").trim() || record.values[1]?.trim() || record.values[0]?.trim() || "—";
  const code = val("code").trim();
  const nationalId = val("nationalId").trim();
  const gender = val("gender").trim();
  const birthDate = val("birthDate").trim();
  const dept = val("dept").trim();
  const role = val("role").trim();
  const email = val("email").trim();
  const phone = val("phone").trim();
  const hired = val("hired").trim();
  const contract = val("contract").trim();
  const endDate = val("endDate").trim();
  const shift = val("shift").trim();
  const salary = val("salary").trim();
  const bank = val("bank").trim();
  const iban = val("iban").trim();

  const st = statuses.find((s) => s.key === record.statusKey);
  const tone = st?.tone ?? "slate";
  const [ag1, ag2] = STATUS_GRAD[tone] ?? STATUS_GRAD.slate;

  /* the duty-status headline — a one-line localized verdict driven by tone */
  const statusKey: I18nKey =
    tone === "emerald" ? "staffStatusOnDuty"
      : tone === "amber" ? "staffStatusLeave"
        : tone === "sky" ? "staffStatusTask"
          : tone === "rose" ? "staffStatusSuspended"
            : "staffStatusOnDuty";
  const statusHeadline = t(statusKey);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        dir={lang === "ar" ? "rtl" : "ltr"}
        showCloseButton={false}
        className="flex max-h-[88vh] flex-col gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-xl"
      >
        {/* ---------------- header — gradient avatar + name + IDs + status ---------------- */}
        <div
          className="relative shrink-0 overflow-hidden border-b border-slate-200/70 px-5 pt-5 pb-4 dark:border-white/10"
          style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(g1, 0.16)}, ${hexAlpha(g2, 0.16)})` }}
        >
          <span
            className="absolute -end-8 -top-14 h-28 w-28 rounded-full"
            style={{ background: `radial-gradient(circle, ${hexAlpha(g1, 0.28)}, transparent 70%)` }}
            aria-hidden="true"
          />
          <span
            className="absolute -start-10 -bottom-16 h-32 w-32 rounded-full"
            style={{ background: `radial-gradient(circle, ${hexAlpha(g2, 0.18)}, transparent 70%)` }}
            aria-hidden="true"
          />
          <div className="relative flex items-center gap-3.5">
            <span
              className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl font-display text-2xl font-extrabold text-white shadow-lg"
              style={{ backgroundImage: grad(g1, g2), boxShadow: `0 12px 28px -12px ${hexAlpha(g1, 0.9)}` }}
              aria-hidden="true"
            >
              {initial(name)}
            </span>
            <div className="min-w-0 flex-1">
              <DialogTitle className="truncate font-display text-[16px] font-extrabold leading-tight text-slate-900 dark:text-white" dir="auto">
                {name}
              </DialogTitle>
              <DialogDescription className="mt-0.5 truncate text-[11.5px] font-bold text-slate-500 dark:text-slate-400" dir="auto">
                {t("staffProfileTitle")} · {moduleName}
              </DialogDescription>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                {st ? <Pill tone={st.tone} label={lang === "ar" ? st.ar : st.en} icon={tone === "emerald" ? "badge-check" : tone === "rose" ? "triangle-alert" : undefined} /> : null}
                {code ? (
                  <span
                    dir={idDir}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-slate-100 px-2 py-1 font-mono text-[10.5px] font-bold tabular-nums text-slate-600 dark:bg-white/10 dark:text-slate-300"
                  >
                    <CatIcon name="hash" className="h-3 w-3 shrink-0 text-slate-400" />
                    {t("staffCodeLabel")}: {arNumIfAR(fmtId(code, lang), lang)}
                  </span>
                ) : null}
              </div>
            </div>
          </div>
        </div>

        {/* ---------------- body ---------------- */}
        <div className="nice-scroll min-h-0 flex-1 space-y-4 overflow-y-auto px-5 py-4">
          {/* ---------- employment section ---------- */}
          <div className="space-y-2.5">
            <SectionLabel icon="briefcase" label={t("staffEmploymentSection")} g1={g1} g2={g2} lang={lang} />
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              <StatCard icon="building" label={t("staffDept")} value={dept || "—"} dir="auto" g1="#6366f1" g2="#4f46e5" lang={lang} valueClass={dept ? "" : "italic text-slate-400"} />
              <StatCard icon="briefcase" label={t("staffRole")} value={role || "—"} dir="auto" g1="#8b5cf6" g2="#7c3aed" lang={lang} valueClass={role ? "" : "italic text-slate-400"} />
              <StatCard icon="file-pen" label={t("staffContract")} value={contract || "—"} dir="auto" g1="#0ea5e9" g2="#0284c7" lang={lang} valueClass={contract ? "" : "italic text-slate-400"} />
              <StatCard icon="clock" label={t("staffShift")} value={shift || "—"} dir="auto" g1="#f59e0b" g2="#d97706" lang={lang} valueClass={shift ? "" : "italic text-slate-400"} />
              <StatCard icon="calendar-check" label={t("staffHired")} value={hired ? dateOnly(hired, lang) : "—"} dir={numDir(lang)} g1="#10b981" g2="#059669" lang={lang} valueClass={hired ? "" : "italic text-slate-400"} />
              <StatCard icon="calendar-clock" label={t("staffContractEnd")} value={endDate ? dateOnly(endDate, lang) : "—"} dir={numDir(lang)} g1="#f43f5e" g2="#be123c" lang={lang} valueClass={endDate ? "" : "italic text-slate-400"} />
            </div>
            {/* the duty-status banner — the status headline gradient strip */}
            <div
              className="flex items-center justify-between gap-3 rounded-2xl border border-black/5 px-3.5 py-2.5 dark:border-white/10"
              style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(ag1, 0.12)}, ${hexAlpha(ag2, 0.08)})` }}
            >
              <span className="flex items-center gap-2 text-[11.5px] font-extrabold text-slate-500 dark:text-slate-400" dir="auto">
                <CatIcon name="shield-check" className="h-4 w-4 shrink-0 text-slate-400" />
                {t("staffProfileSub")}
              </span>
              <span className="text-[12px] font-extrabold" style={{ color: ag2 }} dir="auto">
                {statusHeadline}
              </span>
            </div>
          </div>

          {/* ---------- identity section ---------- */}
          <div className="space-y-2.5">
            <SectionLabel icon="id-card" label={t("staffIdentitySection")} g1={g1} g2={g2} lang={lang} />
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-3">
              {/* national ID — mono, Arabic-Indic in AR (RTL flow) */}
              <StatCard
                icon="hash"
                label={t("staffNationalId")}
                value={nationalId ? arNumIfAR(nationalId, lang) : "—"}
                dir={numDir(lang)}
                g1="#475569" g2="#334155"
                lang={lang}
                valueClass={nationalId ? "font-mono text-[12.5px]" : "italic text-slate-400"}
              />
              <StatCard icon="user-round" label={t("staffGender")} value={gender || "—"} dir="auto" g1="#0ea5e9" g2="#0284c7" lang={lang} valueClass={gender ? "" : "italic text-slate-400"} />
              <StatCard icon="cake" label={t("staffBirthDate")} value={birthDate ? dateOnly(birthDate, lang) : "—"} dir={numDir(lang)} g1="#8b5cf6" g2="#6d5dfb" lang={lang} valueClass={birthDate ? "" : "italic text-slate-400"} />
            </div>
          </div>

          {/* ---------- contact section ---------- */}
          <div className="space-y-2.5">
            <SectionLabel icon="phone" label={t("staffContactSection")} g1={g1} g2={g2} lang={lang} />
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              {/* phone — LTR within RTL */}
              <StatCard
                icon="smartphone"
                label={t("staffPhone")}
                value={phone ? arNumIfAR(phone, lang) : "—"}
                dir="ltr"
                g1="#10b981" g2="#059669"
                lang={lang}
                valueClass={phone ? "" : "italic text-slate-400"}
              />
              {/* email — LTR within RTL */}
              <StatCard
                icon="mail"
                label={t("staffEmail")}
                value={email || "—"}
                dir="ltr"
                g1="#8b5cf6" g2="#6d5dfb"
                lang={lang}
                valueClass={email ? "" : "italic text-slate-400"}
              />
            </div>
          </div>

          {/* ---------- financial section ---------- */}
          <div className="space-y-2.5">
            <SectionLabel icon="wallet" label={t("staffFinancialSection")} g1={g1} g2={g2} lang={lang} />
            {/* the salary banner — full-width, premium currency formatting */}
            <div
              className="flex items-center justify-between gap-3 rounded-2xl border border-black/5 px-3.5 py-3 dark:border-white/10"
              style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(ag1, 0.1)}, ${hexAlpha(ag2, 0.06)})` }}
            >
              <span className="flex items-center gap-2 text-[11.5px] font-extrabold text-slate-500 dark:text-slate-400" dir="auto">
                <CatIcon name="banknote" className="h-4 w-4 shrink-0 text-slate-400" />
                {t("staffSalary")}
              </span>
              <span
                dir={numDir(lang)}
                className="font-display text-[16px] font-extrabold tabular-nums text-slate-800 dark:text-white"
              >
                {salary ? fmtSalary(salary, lang, currency) : "—"}
              </span>
            </div>
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              <StatCard icon="bank" label={t("staffBank")} value={bank || "—"} dir="auto" g1="#6366f1" g2="#4f46e5" lang={lang} valueClass={bank ? "" : "italic text-slate-400"} />
              {/* IBAN — mono LTR, Arabic-Indic digits in AR */}
              <StatCard
                icon="credit-card"
                label={t("staffIban")}
                value={iban ? arNumIfAR(iban, lang) : "—"}
                dir={idDir}
                g1="#0ea5e9" g2="#0369a1"
                lang={lang}
                valueClass={iban ? "font-mono text-[12px]" : "italic text-slate-400"}
              />
            </div>
          </div>

          {/* ---------- meta stamps ---------- */}
          <div className="flex flex-wrap items-center gap-2">
            <span
              dir={numDir(lang)}
              className="inline-flex items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/70 px-2.5 py-1 text-[10px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400"
            >
              <CatIcon name="calendar" className="h-3 w-3 shrink-0" />
              {t("staffMetaStamp")} · {fmtStamp(record.updatedAt || record.createdAt, lang)}
            </span>
            <span
              dir="auto"
              className="inline-flex items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/70 px-2.5 py-1 text-[10px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400"
            >
              <CatIcon name="users" className="h-3 w-3 shrink-0" />
              {statusHeadline}
            </span>
          </div>
        </div>

        <SheetFooter t={t} onEdit={onEdit} onPrint={onPrint} onClose={() => onOpenChange(false)} g1={g1} g2={g2} />
      </DialogContent>
    </Dialog>
  );
}
