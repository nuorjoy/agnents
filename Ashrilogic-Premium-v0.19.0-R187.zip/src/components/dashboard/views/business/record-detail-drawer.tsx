"use client";

/**
 * Ashrilogic — ROUND 164: the PREMIUM record-details drawer (تفاصيل السجل).
 *
 * The owner's directive:
 *   «في جميع الأنظمة عند وحدة (العملاء، المرتجعات، العروض، الجرد، التسعير،
 *    الفروع، المشتريات، المباني، الغرف، الساكنون، عقود الايجار، الصيانة،
 *    Security، المدفوعات، الحراس، الرواتب، التدريب، التراخيص والتصاريح،
 *    الأجهزة والمعدات، الحضور، الأصول، الأعمال، التتبع، الضمان، العمولات)
 *    قم بحذف (تفاصيل السجل) كاملاً ثم طورها بطريقة متقدمة واحترافية وPremium»
 *
 * The old generic field-passport dialog is DELETED for these modules and
 * replaced by a modern side-inspector drawer — rebuilt from scratch:
 *
 *   • A slide-over drawer (the end side — opposite the workspace rail)
 *     instead of a centered dialog: the record opens beside its table,
 *     the modern inspector pattern, with its own scrolling body and a
 *     sticky action bar.
 *   • FAMILY BLUEPRINTS — every module resolves to an experience family
 *     (people · finance · asset · ops · doc) that tints the whole drawer:
 *     its accent gradient, its hero treatment (avatar for people, a big
 *     grand-total chip for finance, an identity strip with a CSS barcode
 *     for assets, an ops register header), and its stat emphasis.
 *   • A derived STAT BAND — kind-aware quick stats (money / count /
 *     date chips) auto-computed from the record's own columns, so every
 *     module shows its numbers at a glance without any per-module code.
 *   • Grouped sections (identity · numbers · payments · attachment ·
 *     record meta) with the strict ROUND-133 numeral policy (money and
 *     counts render Arabic-Indic via numDir; identifiers stay Western
 *     LTR via idDir).
 *   • The same props contract as the old sheet (business-suite swaps the
 *     component, nothing else changes); pos / products / the medical
 *     blueprints keep their dedicated specialized views upstream.
 */
import { useMemo } from "react";
import { useT } from "@/lib/i18n";
import {
  cn,
  fmtId,
  fmtMoneyCell,
  fmtNum,
  grad,
  hexAlpha,
  idDir,
  initial,
  labelTrack,
  numDir,
} from "@/lib/utils";
import { CatIcon } from "@/components/icon";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { PaymentsSummary } from "@/components/dashboard/views/business/payment-manager";
import { useShift } from "@/components/dashboard/shift/use-shift";
import {
  BarcodeStrip,
  MetaStamps,
  Pill,
  SectionLabel,
  SheetFooter,
  fmtDateCell,
} from "@/components/dashboard/views/business/record-detail-sheet";
import type { ColDef, StatusDef } from "@/lib/module-data";
import type { ModuleRecordDTO } from "@/lib/types";

/* ------------------------------------------------------------------ */
/* family blueprints                                                   */
/* ------------------------------------------------------------------ */

type DetailFamily = "people" | "finance" | "asset" | "ops" | "doc";

/** module id → experience family. The 25 directive modules map explicitly;
 *  every other generic module renders the doc family. */
const DETAIL_FAMILIES: Record<string, DetailFamily> = {
  /* people — the human records */
  customers: "people",
  guards: "people",
  residents: "people",
  /* finance — money documents */
  payments: "finance",
  payroll: "finance",
  commissions: "finance",
  purchases: "finance",
  leases: "finance",
  pricing: "finance",
  /* asset — physical things with an identity */
  equipment: "asset",
  assets: "asset",
  tracking: "asset",
  warranty: "asset",
  maintenance: "asset",
  jobs: "asset",
  /* ops — operational registers */
  stocktake: "ops",
  branches: "ops",
  promotions: "ops",
  returns: "ops",
  licenses: "ops",
  training: "ops",
  attendance: "ops",
  dormBuildings: "ops",
  dormRooms: "ops",
  /* ROUND 168 — the SAMS refinement trio joins the ops family (dorm
     registers with location emphasis). */
  roomAssignments: "ops",
  facilities: "ops",
  security: "ops",
};

interface FamilyTheme {
  c1: string;
  c2: string;
  heroIcon: string;
  /** the family's stat-band emphasis */
  statIcon: string;
}

const FAMILY_THEME: Record<DetailFamily, FamilyTheme> = {
  people: { c1: "#0ea5e9", c2: "#6366f1", heroIcon: "user-round", statIcon: "chart-column" },
  finance: { c1: "#10b981", c2: "#0d9488", heroIcon: "banknote", statIcon: "wallet" },
  asset: { c1: "#f59e0b", c2: "#ea580c", heroIcon: "scan", statIcon: "sigma" },
  ops: { c1: "#8b5cf6", c2: "#d946ef", heroIcon: "clipboard-list", statIcon: "list-checks" },
  doc: { c1: "#6d5dfb", c2: "#0ea5e9", heroIcon: "file-text", statIcon: "sigma" },
};

/* ------------------------------------------------------------------ */
/* the premium drawer                                                  */
/* ------------------------------------------------------------------ */

export function RecordDetailDrawer({
  open,
  onOpenChange,
  moduleId,
  record,
  cols,
  statuses,
  moduleName,
  currency,
  orgName,
  instanceId,
  onEdit,
  onPrint,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  moduleId: string;
  record: ModuleRecordDTO | null;
  cols: ColDef[];
  statuses: StatusDef[];
  moduleName: string;
  currency?: string;
  orgName?: string;
  /** resolves the record's shift cuid → the HUMAN shift code (SHF-…) */
  instanceId?: string;
  /** opens the record dialog in edit mode (undefined → demo row, no Edit) */
  onEdit?: () => void;
  onPrint?: () => void;
}) {
  const { t, lang } = useT();

  /* the shift stamp's HUMAN code (the record carries only the cuid; the
   * shared ["shifts", id] cache carries the code — current or history) */
  const shiftsQuery = useShift(instanceId);
  const shiftId = record?.shiftId ?? null;
  const shiftsData = shiftsQuery.data ?? null;
  const shiftCode = useMemo(() => {
    if (!shiftId || !shiftsData) return undefined;
    const { current, history } = shiftsData;
    if (current?.id === shiftId) return current.code;
    return history.find((h) => h.id === shiftId)?.code;
  }, [shiftId, shiftsData]);

  if (!record) return null;

  const family = DETAIL_FAMILIES[moduleId] ?? "doc";
  const theme = FAMILY_THEME[family];
  const [g1, g2] = [theme.c1, theme.c2];
  const val = (i: number): string => record.values[i] ?? "";
  const hero = val(0).trim() || "—";
  const idIdx = cols.findIndex((c) => c.kind === "id");
  /* the code chip only when it is NOT the hero itself (orders-like presets
   * lead with the id column — the hero already shows it) */
  const idCode = idIdx > 0 ? val(idIdx).trim() : "";
  const st = statuses.find((s) => s.key === record.statusKey);

  /* the money law (the print-builder precedent): the LAST money column is
   * the record's grand total — for finance families it becomes the hero
   * amount chip; the other money columns + every num column feed the
   * derived stat band. */
  let lastMoneyIdx = -1;
  for (let i = 0; i < cols.length; i++) if (cols[i].kind === "money") lastMoneyIdx = i;
  const grandTotalRaw = lastMoneyIdx >= 0 ? val(lastMoneyIdx) : "";
  const grandTotalNum = Number(String(grandTotalRaw).replace(/[^\d.-]/g, ""));
  const grandTotal =
    lastMoneyIdx >= 0 && Number.isFinite(grandTotalNum) && grandTotalNum > 0 ? grandTotalNum : null;

  /* ---------------- kind-aware value rendering (ROUND-133 policy) ------ */
  const renderValue = (c: ColDef, raw: string) => {
    if (!raw.trim()) return <span className="text-[12.5px] font-bold text-slate-400">—</span>;
    switch (c.kind) {
      case "money":
        return (
          <span dir={numDir(lang)} className="text-[13px] font-extrabold tabular-nums text-emerald-600 dark:text-emerald-400">
            {fmtMoneyCell(Number(raw) || 0, lang, currency)}
          </span>
        );
      case "num":
        return (
          <span dir={numDir(lang)} className="text-[12.5px] font-extrabold tabular-nums text-slate-700 dark:text-slate-200">
            {fmtNum(Number(raw) || 0, lang)}
          </span>
        );
      case "id":
        return (
          <span dir={idDir} className="rounded-lg bg-slate-100 px-2 py-0.5 font-mono text-[11px] font-bold tabular-nums text-slate-600 dark:bg-white/10 dark:text-slate-300">
            {fmtId(raw, lang)}
          </span>
        );
      case "date":
        return (
          <span dir={numDir(lang)} className="text-[12.5px] font-bold tabular-nums text-slate-700 dark:text-slate-200">
            {fmtDateCell(raw, lang)}
          </span>
        );
      default:
        return (
          <span dir="auto" className="break-words text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
            {raw}
          </span>
        );
    }
  };

  const fieldRow = (c: ColDef, i: number) => (
    <div
      key={c.key}
      className="group flex items-start justify-between gap-3 rounded-xl border border-black/5 bg-slate-50/60 px-3.5 py-2.5 transition-colors hover:border-slate-300/60 hover:bg-slate-100/70 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-white/20 dark:hover:bg-white/[0.05]"
    >
      <span className="shrink-0 text-[11.5px] font-extrabold text-slate-400 dark:text-slate-500" dir="auto">
        {lang === "ar" ? c.ar : c.en}
      </span>
      <span className="min-w-0 text-end">{renderValue(c, val(i))}</span>
    </div>
  );

  /* ---------------- the derived STAT BAND ----------------
   * money columns (except the finance hero) + num columns + the last date
   * column become quick-stat chips — kind-aware, zero per-module code. */
  const statusIdx = cols.findIndex((c) => c.kind === "status");
  const statBand: { icon: string; label: string; node: React.ReactNode }[] = [];
  cols.forEach((c, i) => {
    if (i === 0 || i === statusIdx) return;
    if (c.kind === "money" && family === "finance" && i === lastMoneyIdx) return; // hero chip
    if (c.kind === "money" || c.kind === "num") {
      const raw = val(i);
      if (!raw.trim()) return;
      statBand.push({
        icon: c.kind === "money" ? "wallet" : theme.statIcon,
        label: lang === "ar" ? c.ar : c.en,
        node: renderValue(c, raw),
      });
    }
  });
  const lastDateIdx = (() => {
    for (let i = cols.length - 1; i >= 0; i--) if (cols[i].kind === "date") return i;
    return -1;
  })();
  if (lastDateIdx > 0) {
    const raw = val(lastDateIdx);
    if (raw.trim()) {
      statBand.push({
        icon: "calendar",
        label: lang === "ar" ? cols[lastDateIdx].ar : cols[lastDateIdx].en,
        node: renderValue(cols[lastDateIdx], raw),
      });
    }
  }
  const stats = statBand.slice(0, 6);

  /* ---------------- section routing ---------------- */
  const coreCols = cols.filter(
    (c, i) => i > 0 && i !== idIdx && i !== statusIdx && (c.kind === "text" || c.kind === "date" || c.kind === "id")
  );
  const numCols = cols.filter((c, i) => i !== statusIdx && (c.kind === "num" || c.kind === "money"));

  const paymentsTotalMinor = lastMoneyIdx < 0 || grandTotal === null ? 0 : Math.round(grandTotal * 100);

  const drawerDir = lang === "ar" ? "rtl" : "ltr";

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side={lang === "ar" ? "left" : "right"}
        dir={drawerDir}
        className="flex w-full flex-col gap-0 p-0 sm:max-w-xl [&_[data-slot=sheet-close]]:hidden"
      >
        {/* Radix a11y: DialogContent requires a title + description */}
        <SheetHeader className="sr-only">
          <SheetTitle>{t("bizRowDetailTitle")}</SheetTitle>
          <SheetDescription>{moduleName}</SheetDescription>
        </SheetHeader>

        {/* ---------------- family hero ---------------- */}
        <div
          className="relative shrink-0 overflow-hidden border-b border-slate-200/70 dark:border-white/10"
          style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(g1, 0.17)}, ${hexAlpha(g2, 0.17)})` }}
        >
          <span
            className="absolute -end-10 -top-16 h-36 w-36 rounded-full"
            style={{ background: `radial-gradient(circle, ${hexAlpha(g1, 0.3)}, transparent 70%)` }}
            aria-hidden="true"
          />
          <span
            className="absolute -start-8 -bottom-14 h-28 w-28 rounded-full"
            style={{ background: `radial-gradient(circle, ${hexAlpha(g2, 0.22)}, transparent 70%)` }}
            aria-hidden="true"
          />
          <div className="relative flex items-start gap-4 px-5 pt-5 pb-4">
            {/* people → a round avatar; asset → the identity scan tile;
                everything else → the family icon tile */}
            {family === "people" ? (
              record.imageRef ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={record.imageRef}
                  alt={hero}
                  className="h-16 w-16 shrink-0 rounded-full border-2 border-white/70 object-cover shadow-lg dark:border-white/20"
                />
              ) : (
                <span
                  className="grid h-16 w-16 shrink-0 place-items-center rounded-full font-display text-2xl font-extrabold text-white shadow-lg"
                  style={{ backgroundImage: grad(g1, g2), boxShadow: `0 14px 30px -12px ${hexAlpha(g1, 0.9)}` }}
                  aria-hidden="true"
                >
                  {initial(hero)}
                </span>
              )
            ) : (
              <span
                className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
                style={{ backgroundImage: grad(g1, g2), boxShadow: `0 14px 30px -12px ${hexAlpha(g1, 0.9)}` }}
                aria-hidden="true"
              >
                <CatIcon name={theme.heroIcon} className="h-6 w-6" />
              </span>
            )}

            <div className="min-w-0 flex-1">
              <p
                className={cn("flex items-center gap-1.5 text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}
                dir="auto"
              >
                <CatIcon name={family === "asset" ? "scan" : theme.heroIcon} className="h-2.5 w-2.5 shrink-0" />
                {t("bizRowDetailTitle")} · {moduleName}
              </p>
              <h3 className="mt-1 truncate font-display text-[19px] font-extrabold leading-tight text-slate-900 dark:text-white" dir="auto">
                {hero}
              </h3>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                {idCode ? (
                  <span
                    dir={idDir}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-white/80 px-2 py-1 font-mono text-[10.5px] font-bold tabular-nums text-slate-600 shadow-sm dark:bg-white/10 dark:text-slate-300"
                  >
                    <CatIcon name="hash" className="h-3 w-3 shrink-0 text-slate-400" />
                    {fmtId(idCode, lang)}
                  </span>
                ) : null}
                {st ? <Pill tone={st.tone} label={lang === "ar" ? st.ar : st.en} /> : null}
                {/* finance → the grand-total hero chip */}
                {family === "finance" && grandTotal !== null ? (
                  <span
                    dir={numDir(lang)}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-500/12 px-2.5 py-1 font-display text-[13px] font-extrabold tabular-nums text-emerald-700 dark:text-emerald-300"
                  >
                    <CatIcon name="banknote" className="h-3.5 w-3.5 shrink-0" />
                    {fmtMoneyCell(grandTotal, lang, currency)}
                  </span>
                ) : null}
              </div>
            </div>

            {/* the premium close (the built-in sheet close is hidden) */}
            <button
              type="button"
              onClick={() => onOpenChange(false)}
              aria-label={t("bizClose")}
              className="relative grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-white/60 text-slate-500 shadow-sm backdrop-blur transition hover:bg-white hover:text-slate-800 dark:bg-white/10 dark:text-slate-300 dark:hover:bg-white/20 dark:hover:text-white"
            >
              <CatIcon name="x" className="h-4 w-4" />
            </button>
          </div>

          {/* asset families → the identity strip (the deterministic CSS
              barcode over a hairline band) */}
          {family === "asset" && idCode ? (
            <div className="relative flex items-center gap-3 border-t border-dashed border-slate-300/60 px-5 py-2 dark:border-white/15">
              <BarcodeStrip seed={idCode} className="h-8 w-40 shrink-0" />
              <span
                dir={idDir}
                className="min-w-0 flex-1 truncate font-mono text-[10px] font-bold tracking-widest text-slate-500 dark:text-slate-400"
              >
                {fmtId(idCode, lang)}
              </span>
              {orgName ? (
                <span className="hidden shrink-0 text-[9px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500 sm:block" dir="auto">
                  {orgName}
                </span>
              ) : null}
            </div>
          ) : null}
        </div>

        {/* ---------------- the scrolling body ---------------- */}
        <div className="nice-scroll min-h-0 flex-1 space-y-5 overflow-y-auto px-5 py-4">
          {/* the derived stat band — every module's numbers at a glance */}
          {stats.length > 0 ? (
            <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
              {stats.map((s, i) => (
                <div
                  key={i}
                  className="min-w-0 rounded-2xl border border-black/5 bg-slate-50/60 p-2.5 dark:border-white/10 dark:bg-white/[0.03]"
                >
                  <p
                    className={cn("flex items-center gap-1.5 text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}
                    dir="auto"
                  >
                    <span
                      className="grid h-4 w-4 shrink-0 place-items-center rounded-md text-white"
                      style={{ backgroundImage: grad(g1, g2) }}
                      aria-hidden="true"
                    >
                      <CatIcon name={s.icon} className="h-2.5 w-2.5" />
                    </span>
                    <span className="truncate">{s.label}</span>
                  </p>
                  <div className="mt-1 truncate">{s.node}</div>
                </div>
              ))}
            </div>
          ) : null}

          {/* البيانات الأساسية */}
          {coreCols.length > 0 ? (
            <div className="space-y-2.5">
              <SectionLabel icon="eye" label={t("detailSectionCore")} g1={g1} g2={g2} lang={lang} />
              <div className="space-y-2">{cols.map((c, i) => (coreCols.includes(c) ? fieldRow(c, i) : null))}</div>
            </div>
          ) : null}

          {/* الأرقام والقياسات */}
          {numCols.length > 0 ? (
            <div className="space-y-2.5">
              <SectionLabel icon="sigma" label={t("detailSectionNumbers")} g1={g1} g2={g2} lang={lang} />
              <div className="space-y-2">{cols.map((c, i) => (numCols.includes(c) ? fieldRow(c, i) : null))}</div>
            </div>
          ) : null}

          {/* المدفوعات — the structured payment ledger (ROUND 141 law) */}
          {record.payments.length > 0 ? (
            <div className="space-y-2.5">
              <SectionLabel icon="wallet" label={t("payMgrTitle")} g1={g1} g2={g2} lang={lang} />
              <PaymentsSummary entries={record.payments} totalMinor={paymentsTotalMinor} currency={currency ?? "SAR"} />
            </div>
          ) : null}

          {/* المرفقات — the optional receipt/cover image (ROUND 156 law) */}
          {record.imageRef && family !== "people" ? (
            <div className="space-y-2.5">
              <SectionLabel icon="image" label={t("bizReceiptImageTitle")} g1={g1} g2={g2} lang={lang} />
              <div className="overflow-hidden rounded-xl border border-slate-200 bg-white p-2 dark:border-white/10 dark:bg-white/[0.03]">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={record.imageRef}
                  alt={t("bizReceiptImageTitle")}
                  className="mx-auto max-h-72 w-auto rounded-lg object-contain"
                />
              </div>
            </div>
          ) : null}

          {/* customers → the loyalty explainer (every linked POS sale keeps
              this profile + its points live — the old profile-view explainer,
              preserved inside the new drawer) */}
          {moduleId === "customers" ? (
            <p
              className="flex items-start gap-2 rounded-xl border border-sky-200/60 bg-sky-50/60 px-3 py-2 text-[10.5px] font-bold leading-relaxed text-sky-700 dark:border-sky-500/20 dark:bg-sky-500/10 dark:text-sky-300"
              dir="auto"
            >
              <CatIcon name="sparkles" className="mt-0.5 h-3 w-3 shrink-0" />
              {t("posLoyaltyHint")}
            </p>
          ) : null}

          {/* بيانات السجل */}
          <div className="space-y-2.5">
            <SectionLabel icon="clock" label={t("detailSectionMeta")} g1={g1} g2={g2} lang={lang} />
            <MetaStamps record={record} lang={lang} t={t} shiftCode={shiftCode} />
          </div>
        </div>

        {/* ---------------- the sticky action bar ---------------- */}
        <SheetFooter t={t} onEdit={onEdit} onPrint={onPrint} onClose={() => onOpenChange(false)} g1={g1} g2={g2} />
      </SheetContent>
    </Sheet>
  );
}
