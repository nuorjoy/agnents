"use client";

/**
 * Ashrilogic — the PREMIUM resident profile sheet (ROUND 166).
 *
 * The owner's directive (SAMS — نظام إدارة السكن الطلابي): the residents
 * module (labeled «الطلاب» inside the student-accommodation system via
 * MODULE_LABEL_OVERRIDES) must reach PREMIUM parity with the education
 * family's dedicated sheets — students (ROUND 155), teachers (156),
 * parents (156), certificates (156.1), staff (156.1). It previously fell
 * through to the generic family-tinted RecordDetailDrawer; this dedicated
 * sheet replaces it with a premium card-based resident dossier:
 *
 *   • HEADER   — gradient avatar (initials), resident display name, the
 *                bilingual "Resident profile" sub-line, the RES-XXXXXX
 *                code chip (mono, RTL bidi-safe) and the residence-status
 *                pill (مقيم / إخلاء قريب / أخلى / متأخر).
 *   • METRICS  — a compact 3-card KPI row: الإشغال الحالي (room +
 *                building), بقيّة العقد (days left until leaseEnd —
 *                «منتهي» once past), الإيجار الشهري (currency-formatted
 *                monthly rate, the StaffProfileSheet money idiom).
 *   • STUDENT  — بيانات الطالب: university ID (mono), university,
 *                college, mobile (LTR within RTL, Arabic-Indic in AR).
 *   • HOUSING  — بيانات السكن: room, building, lease start, lease end
 *                (locale medium dates).
 *   • TIMELINE — the lease strip: a horizontal gradient progress bar from
 *                leaseStart → leaseEnd with the % elapsed + the one-line
 *                residence-standing verdict.
 *   • META     — created-at + last-updated stamp row (parity with the
 *                generic record-detail sheet footer).
 *
 * Purity contract: every value is read off the row by column key (the
 * same ModuleRecordDTO + ColDef[] + StatusDef[] props the parent already
 * passes RecordDetailSheet). The residents preset's column contract is:
 *   code, name, universityId, university, college, room, building,
 *   leaseStart, leaseEnd, monthlyRate, phone, status
 * and every lookup is DEFENSIVE — real (سجلاتي) rows may carry custom
 * columns, so a missing key renders the graceful "—" fallback. Numeric
 * values render through fmtNum (Arabic-Indic digits in ar), identifiers
 * through fmtId + idDir (Western digits, ROUND 134), and the monthly rate
 * through the Intl currency formatter (the family's money idiom).
 *
 * Bilingual (AR/EN/HI) with full RTL support — the sheet inherits the
 * dialog's dir={lang === "ar" ? "rtl" : "ltr"} from the parent and every
 * text node uses dir="auto" / labelTrack(lang) for the uppercase
 * Latin-tracking micro-labels. The new i18n keys (resSheetTitle,
 * resSheetStudentInfo, resSheetUniversityId, …) live in
 * src/lib/i18n/domains/business.ts in all three locales (AR + EN + HI)
 * for type parity.
 */
import { useT, type I18nKey } from "@/lib/i18n";
import type { ColDef, StatusDef } from "@/lib/module-data";
import type { Lang, ModuleRecordDTO } from "@/lib/types";
import {
  cn,
  fmtId,
  fmtNum,
  grad,
  hexAlpha,
  idDir,
  initial,
  labelTrack,
  numDir,
  toArabicDigits,
} from "@/lib/utils";
import { dateOnly } from "@/components/dashboard/dash-shared";
import { CatIcon } from "@/components/icon";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";

/* ------------------------------------------------------------------ */
/* tone maps — the exact business-suite / inv-shared pill idiom        */
/* ------------------------------------------------------------------ */

const TONE_DOT: Record<string, string> = {
  emerald: "bg-emerald-500",
  amber: "bg-amber-500",
  rose: "bg-rose-500",
  sky: "bg-sky-500",
  violet: "bg-violet-500",
  slate: "bg-slate-400",
};

const TONE_STYLE: Record<string, string> = {
  emerald: "bg-emerald-500/12 text-emerald-700 dark:text-emerald-300",
  amber: "bg-amber-500/12 text-amber-700 dark:text-amber-300",
  rose: "bg-rose-500/12 text-rose-700 dark:text-rose-300",
  sky: "bg-sky-500/12 text-sky-700 dark:text-sky-300",
  violet: "bg-violet-500/12 text-violet-700 dark:text-violet-300",
  slate: "bg-slate-500/12 text-slate-600 dark:text-slate-300",
};

/* the education brand gradient — the exact pair catalog.ts assigns to the
 * `education` category (#6366f1 → #7c3aed). SAMS (student accommodation)
 * is an education-category system, so the resident sheet visually belongs
 * to the campus family while staying inside the brand family (matches
 * Student/TeacherProfileSheet for coherence). */
const RESIDENT_C = ["#6366f1", "#7c3aed"] as const;

/* per-status gradient (for the lease timeline bar) — emerald for مقيم,
 * amber for إخلاء قريب, slate for أخلى, rose for متأخر. The same tones
 * the residents preset's statuses already use. */
const STATUS_GRAD: Record<string, [string, string]> = {
  emerald: ["#10b981", "#059669"],
  sky: ["#0ea5e9", "#0284c7"],
  amber: ["#f59e0b", "#d97706"],
  rose: ["#f43f5e", "#be123c"],
  violet: ["#8b5cf6", "#6d5dfb"],
  slate: ["#64748b", "#475569"],
};

const DAY_MS = 86_400_000;

type TFunc = (key: I18nKey, vars?: Record<string, string | number>) => string;

/* ------------------------------------------------------------------ */
/* shared atoms (parity with student / teacher / staff sheets)          */
/* ------------------------------------------------------------------ */

/** ROUND 156.1 family convention — every ASCII digit in the profile-sheet
 *  phone renders as Arabic-Indic (٠..٩) when the UI is Arabic (scoped to
 *  THIS surface only; the table + print surfaces keep ROUND 134's
 *  Western-ID policy). */
function arNumIfAR(text: string, lang: Lang): string {
  if (!text) return text;
  return lang === "ar" ? toArabicDigits(text) : text;
}

/** created/updated-stamp — medium date + HH:MM, same locale policy. */
function fmtStamp(iso: string, lang: Lang): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  const date = d.toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB", { dateStyle: "medium" });
  const time = d.toLocaleTimeString(lang === "ar" ? "ar-EG" : "en-GB", { hour: "2-digit", minute: "2-digit" });
  return `${date} · ${time}`;
}

/** Parse a preset date cell ("YYYY-MM-DD" or a full ISO string) to the
 *  START-of-day timestamp; null when absent/unparseable — custom rows
 *  may hold junk in the lease columns, so the sheet degrades gracefully
 *  instead of throwing. */
function dayStart(raw: string): number | null {
  const s = raw.trim();
  if (!s) return null;
  const d = /^\d{4}-\d{2}-\d{2}$/.test(s) ? new Date(`${s}T00:00:00`) : new Date(s);
  return Number.isNaN(d.getTime()) ? null : d.getTime();
}

/** Same, but the END of the final day — a lease runs through its last
 *  night, so "lease ends today" still shows ٠ days left (not expired). */
function dayEnd(raw: string): number | null {
  const s = raw.trim();
  if (!s) return null;
  const d = /^\d{4}-\d{2}-\d{2}$/.test(s) ? new Date(`${s}T23:59:59`) : new Date(s);
  return Number.isNaN(d.getTime()) ? null : d.getTime();
}

/** The derived lease facts, computed the moment the sheet opens:
 *   daysLeft   — whole days until the lease ends (negative once past;
 *                the card renders «منتهي» instead of the number)
 *   expired    — the lease window has fully passed
 *   elapsedPct — how much of the leaseStart → leaseEnd window has run,
 *                clamped 0..100 (the timeline strip's fill)
 * Every date degrades defensively: unparseable/absent values yield null
 * so the cards show the graceful "—" instead of a bogus countdown
 * (real rows may hold custom columns or junk in the lease cells). */
function leaseFacts(leaseStart: string, leaseEnd: string): {
  daysLeft: number | null;
  expired: boolean;
  elapsedPct: number | null;
} {
  const now = Date.now();
  const startMs = dayStart(leaseStart);
  const endMs = dayEnd(leaseEnd);
  const daysLeft = endMs === null ? null : Math.ceil((endMs - now) / DAY_MS);
  const expired = daysLeft !== null && daysLeft < 0;
  const elapsedPct =
    startMs !== null && endMs !== null && endMs > startMs
      ? Math.max(0, Math.min(100, ((now - startMs) / (endMs - startMs)) * 100))
      : null;
  return { daysLeft, expired, elapsedPct };
}

/** the tone-colored status pill (business-suite idiom, optional icon). */
function Pill({ tone, label, icon }: { tone: string; label: string; icon?: string }) {
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1 text-[10.5px] font-extrabold",
        TONE_STYLE[tone] ?? TONE_STYLE.slate
      )}
      dir="auto"
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", TONE_DOT[tone] ?? TONE_DOT.slate)} aria-hidden="true" />
      {icon ? <CatIcon name={icon} className="h-3 w-3" /> : null}
      {label}
    </span>
  );
}

/** section heading — gradient icon chip + label + fading gradient rule. */
function SectionLabel({ icon, label, g1, g2, lang }: { icon: string; label: string; g1: string; g2: string; lang: Lang }) {
  return (
    <p className="flex items-center gap-2" dir="auto">
      <span className="grid h-5 w-5 shrink-0 place-items-center rounded-lg text-white" style={{ backgroundImage: grad(g1, g2) }} aria-hidden="true">
        <CatIcon name={icon} className="h-3 w-3" />
      </span>
      <span className={cn("shrink-0 text-[10px] font-extrabold uppercase text-slate-500 dark:text-slate-400", labelTrack(lang))}>{label}</span>
      <span className="h-px min-w-0 flex-1 bg-gradient-to-r from-slate-200 to-transparent dark:from-white/10" aria-hidden="true" />
    </p>
  );
}

/** mini stat card — icon tile + micro label + formatted value (+ extras). */
function StatCard({
  icon,
  label,
  value,
  dir,
  valueClass,
  g1,
  g2,
  lang,
  children,
}: {
  icon: string;
  label: string;
  value: string;
  dir: "rtl" | "ltr" | "auto";
  valueClass?: string;
  g1: string;
  g2: string;
  lang: Lang;
  children?: React.ReactNode;
}) {
  return (
    <div className="min-w-0 rounded-2xl border border-black/5 bg-slate-50/60 p-2.5 dark:border-white/10 dark:bg-white/[0.03]">
      <p className={cn("flex items-center gap-1.5 text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))} dir="auto">
        <span
          className="grid h-4 w-4 shrink-0 place-items-center rounded-md text-white"
          style={{ backgroundImage: grad(g1, g2) }}
          aria-hidden="true"
        >
          <CatIcon name={icon} className="h-2.5 w-2.5" />
        </span>
        <span className="truncate">{label}</span>
      </p>
      <p dir={dir} className={cn("mt-1 truncate font-display text-[14px] font-extrabold tabular-nums text-slate-800 dark:text-white", valueClass)}>
        {value}
      </p>
      {children}
    </div>
  );
}

/** the always-visible action bar (edit + print + close). */
function SheetFooter({ t, onEdit, onPrint, onClose, g1, g2 }: { t: TFunc; onEdit?: () => void; onPrint?: () => void; onClose: () => void; g1: string; g2: string }) {
  return (
    <div className="flex shrink-0 flex-wrap items-center justify-end gap-2.5 border-t border-slate-200/70 bg-slate-50/60 px-5 py-3.5 dark:border-white/10 dark:bg-white/[0.02]">
      {onEdit ? (
        <Button
          type="button"
          onClick={onEdit}
          className="h-10 gap-2 rounded-xl px-4 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95"
          style={{ backgroundImage: grad(g1, g2) }}
        >
          <CatIcon name="pencil" className="h-4 w-4" />
          {t("bizEditBtn")}
        </Button>
      ) : null}
      {onPrint ? (
        <Button
          type="button"
          variant="outline"
          onClick={onPrint}
          className="h-10 gap-2 rounded-xl px-4 text-[12.5px] font-bold"
        >
          <CatIcon name="printer" className="h-4 w-4" />
          {t("bizPrintBtn")}
        </Button>
      ) : null}
      <Button
        type="button"
        variant="outline"
        onClick={onClose}
        className="h-10 rounded-xl px-5 text-[12.5px] font-extrabold"
      >
        {t("bizClose")}
      </Button>
    </div>
  );
}

/** the monthly-rate formatter — the profile-sheet family's money idiom
 *  (mirrored byte-for-byte from StaffProfileSheet's fmtSalary): the
 *  major-currency locale form with Arabic-Indic digits in AR
 *  (SAR 4,500.00 → ٤٬٥٠٠٫٠٠ ر.س). */
function fmtRate(raw: string, lang: Lang, currency: string): string {
  const n = Number(String(raw).replace(/[^\d.-]/g, ""));
  if (!Number.isFinite(n)) return raw || "—";
  try {
    return new Intl.NumberFormat(lang === "ar" ? "ar-EG" : "en-GB", {
      style: "currency",
      currency: currency || "SAR",
      maximumFractionDigits: 2,
    }).format(n);
  } catch {
    return `${raw} ${currency}`;
  }
}

/* ------------------------------------------------------------------ */
/* the premium resident profile sheet                                   */
/* ------------------------------------------------------------------ */

/**
 * The premium «ملف الطالب الساكن» sheet. Props contract (wired by
 * business-suite.tsx — same shape as StudentProfileSheet /
 * RecordDetailSheet so the swap is a one-line conditional; the optional
 * `currency` mirrors StaffProfileSheet, the family's money-bearing
 * precedent, for the monthly-rate card):
 *
 *   open / onOpenChange — Radix dialog control
 *   record              — the ModuleRecordDTO to display (null → nothing)
 *   cols / statuses      — the module preset's ColDef[] / StatusDef[]
 *   moduleName           — localized display name of the module
 *   currency             — tenant currency for the monthly rate (SAR)
 *   onPrint              — optional print callback (footer print button)
 *   onEdit               — optional edit callback (footer edit button)
 */
export function ResidentProfileSheet({
  open,
  onOpenChange,
  record,
  cols,
  statuses,
  moduleName,
  currency = "SAR",
  onEdit,
  onPrint,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  record: ModuleRecordDTO | null;
  cols: ColDef[];
  statuses: StatusDef[];
  moduleName: string;
  currency?: string;
  onEdit?: () => void;
  onPrint?: () => void;
}) {
  const { t, lang } = useT();
  const [g1, g2] = RESIDENT_C;

  /* no record → render nothing (the parent usually keeps open === !!record) */
  if (!record) return null;

  /* read every cell by column key (the residents preset contract):
   *   code, name, universityId, university, college, room, building,
   *   leaseStart, leaseEnd, monthlyRate, phone, status —
   * every lookup is defensive: a missing key (custom columns on real
   * rows) yields "" and renders the graceful "—" fallback. */
  const val = (key: string): string => {
    const i = cols.findIndex((c) => c.key === key);
    return i >= 0 ? record.values[i] ?? "" : "";
  };

  const name = val("name").trim() || record.values[1]?.trim() || record.values[0]?.trim() || "—";
  const code = val("code").trim();
  const universityId = val("universityId").trim();
  const university = val("university").trim();
  const college = val("college").trim();
  const room = val("room").trim();
  const building = val("building").trim();
  const leaseStart = val("leaseStart").trim();
  const leaseEnd = val("leaseEnd").trim();
  const monthlyRate = val("monthlyRate").trim();
  const phone = val("phone").trim();

  const st = statuses.find((s) => s.key === record.statusKey);
  const tone = st?.tone ?? "slate";
  const [ag1, ag2] = STATUS_GRAD[tone] ?? STATUS_GRAD.slate;

  /* the lease math — one defensive derivation (see leaseFacts): the
   * countdown to leaseEnd, the expired flag and the % of the lease window
   * elapsed, all null-safe against junk/missing date cells. */
  const { daysLeft, expired, elapsedPct } = leaseFacts(leaseStart, leaseEnd);
  const elapsedShown = elapsedPct === null ? null : Math.round(elapsedPct);

  /* the residence-standing headline — a one-line localized verdict driven
   * by tone (مقيم / إخلاء قريب / أخلى / متأخر). */
  const statusKey: I18nKey =
    tone === "emerald" ? "resSheetStatusActive"
      : tone === "amber" ? "resSheetStatusNotice"
        : tone === "slate" ? "resSheetStatusVacated"
          : tone === "rose" ? "resSheetStatusOverdue"
            : "resSheetStatusActive";
  const statusHeadline = t(statusKey);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        dir={lang === "ar" ? "rtl" : "ltr"}
        showCloseButton={false}
        className="flex max-h-[88vh] flex-col gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-xl"
      >
        {/* ---------------- header — gradient avatar + name + code + status ---------------- */}
        <div
          className="relative shrink-0 overflow-hidden border-b border-slate-200/70 px-5 pt-5 pb-4 dark:border-white/10"
          style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(g1, 0.16)}, ${hexAlpha(g2, 0.16)})` }}
        >
          <span
            className="absolute -end-8 -top-14 h-28 w-28 rounded-full"
            style={{ background: `radial-gradient(circle, ${hexAlpha(g1, 0.28)}, transparent 70%)` }}
            aria-hidden="true"
          />
          <span
            className="absolute -start-10 -bottom-16 h-32 w-32 rounded-full"
            style={{ background: `radial-gradient(circle, ${hexAlpha(g2, 0.18)}, transparent 70%)` }}
            aria-hidden="true"
          />
          <div className="relative flex items-center gap-3.5">
            <span
              className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl font-display text-2xl font-extrabold text-white shadow-lg"
              style={{ backgroundImage: grad(g1, g2), boxShadow: `0 12px 28px -12px ${hexAlpha(g1, 0.9)}` }}
              aria-hidden="true"
            >
              {initial(name)}
            </span>
            <div className="min-w-0 flex-1">
              <DialogTitle className="truncate font-display text-[16px] font-extrabold leading-tight text-slate-900 dark:text-white" dir="auto">
                {name}
              </DialogTitle>
              <DialogDescription className="mt-0.5 truncate text-[11.5px] font-bold text-slate-500 dark:text-slate-400" dir="auto">
                {t("resSheetTitle")} · {moduleName}
              </DialogDescription>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                {st ? <Pill tone={st.tone} label={lang === "ar" ? st.ar : st.en} icon={tone === "emerald" ? "badge-check" : tone === "rose" || tone === "amber" ? "triangle-alert" : undefined} /> : null}
                {code ? (
                  <span
                    dir={idDir}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-slate-100 px-2 py-1 font-mono text-[10.5px] font-bold tabular-nums text-slate-600 dark:bg-white/10 dark:text-slate-300"
                  >
                    <CatIcon name="hash" className="h-3 w-3 shrink-0 text-slate-400" />
                    {t("resSheetResidentCode")}: {fmtId(code, lang)}
                  </span>
                ) : null}
              </div>
            </div>
          </div>
        </div>

        {/* ---------------- body ---------------- */}
        <div className="nice-scroll min-h-0 flex-1 space-y-4 overflow-y-auto px-5 py-4">
          {/* ---------- the compact metric row — occupancy · lease remaining · monthly rate ---------- */}
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-3">
            {/* current occupancy — the room, with the building as the sub-line */}
            <StatCard
              icon="door-open"
              label={t("resSheetCurrentRoom")}
              value={room || "—"}
              dir="auto"
              g1="#6366f1"
              g2="#4f46e5"
              lang={lang}
              valueClass={room ? "" : "italic text-slate-400"}
            >
              {building ? (
                <span className="mt-0.5 block truncate text-[9.5px] font-bold text-slate-400 dark:text-slate-500" dir="auto">
                  {building}
                </span>
              ) : null}
            </StatCard>
            {/* lease remaining — the countdown to leaseEnd («منتهي» once past) */}
            <StatCard
              icon="hourglass"
              label={t("resSheetLeaseRemaining")}
              value={daysLeft === null ? "—" : expired ? t("resSheetLeaseExpired") : fmtNum(Math.max(0, daysLeft), lang)}
              dir={daysLeft !== null && !expired ? numDir(lang) : "auto"}
              g1="#f59e0b"
              g2="#d97706"
              lang={lang}
              valueClass={expired ? "text-amber-600 dark:text-amber-400" : daysLeft === null ? "italic text-slate-400" : undefined}
            >
              {daysLeft !== null && !expired ? (
                <span className="mt-0.5 block truncate text-[9.5px] font-bold uppercase text-slate-400 dark:text-slate-500" dir="auto">
                  {t("resSheetDaysLeft")}
                </span>
              ) : null}
            </StatCard>
            {/* the monthly rate — the family's Intl currency form */}
            <StatCard
              icon="banknote"
              label={t("resSheetMonthlyRate")}
              value={monthlyRate ? fmtRate(monthlyRate, lang, currency) : "—"}
              dir={numDir(lang)}
              g1="#10b981"
              g2="#059669"
              lang={lang}
              valueClass={monthlyRate ? "" : "italic text-slate-400"}
            />
          </div>

          {/* ---------- student information section ---------- */}
          <div className="space-y-2.5">
            <SectionLabel icon="graduation-cap" label={t("resSheetStudentInfo")} g1={g1} g2={g2} lang={lang} />
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              {/* university ID — mono, Western digits (ROUND 134) */}
              <StatCard
                icon="id-card"
                label={t("resSheetUniversityId")}
                value={universityId || "—"}
                dir={idDir}
                g1="#475569"
                g2="#334155"
                lang={lang}
                valueClass={universityId ? "font-mono text-[12.5px]" : "italic text-slate-400"}
              />
              <StatCard icon="university" label={t("resSheetUniversity")} value={university || "—"} dir="auto" g1="#6366f1" g2="#4f46e5" lang={lang} valueClass={university ? "" : "italic text-slate-400"} />
              <StatCard icon="book-open" label={t("resSheetCollege")} value={college || "—"} dir="auto" g1="#8b5cf6" g2="#7c3aed" lang={lang} valueClass={college ? "" : "italic text-slate-400"} />
              {/* phone — LTR within RTL (so the digits read naturally) */}
              <StatCard
                icon="smartphone"
                label={t("resSheetPhone")}
                value={phone ? arNumIfAR(phone, lang) : "—"}
                dir="ltr"
                g1="#10b981"
                g2="#059669"
                lang={lang}
                valueClass={phone ? "" : "italic text-slate-400"}
              />
            </div>
          </div>

          {/* ---------- housing information section ---------- */}
          <div className="space-y-2.5">
            <SectionLabel icon="bed-double" label={t("resSheetHousingInfo")} g1={g1} g2={g2} lang={lang} />
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              <StatCard icon="bed-double" label={t("resSheetRoom")} value={room || "—"} dir="auto" g1="#0ea5e9" g2="#0369a1" lang={lang} valueClass={room ? "" : "italic text-slate-400"} />
              <StatCard icon="building" label={t("resSheetBuilding")} value={building || "—"} dir="auto" g1="#6366f1" g2="#4f46e5" lang={lang} valueClass={building ? "" : "italic text-slate-400"} />
              <StatCard icon="calendar-days" label={t("resSheetLeaseStart")} value={leaseStart ? dateOnly(leaseStart, lang) : "—"} dir={numDir(lang)} g1="#10b981" g2="#059669" lang={lang} valueClass={leaseStart ? "" : "italic text-slate-400"} />
              <StatCard icon="calendar-check" label={t("resSheetLeaseEnd")} value={leaseEnd ? dateOnly(leaseEnd, lang) : "—"} dir={numDir(lang)} g1="#f43f5e" g2="#be123c" lang={lang} valueClass={leaseEnd ? "" : "italic text-slate-400"} />
            </div>
          </div>

          {/* ---------- lease timeline strip ---------- */}
          <div className="space-y-2.5">
            <SectionLabel icon="calendar-clock" label={t("resSheetLeaseTimeline")} g1={g1} g2={g2} lang={lang} />
            <div
              className="rounded-2xl border border-black/5 p-3.5 dark:border-white/10"
              style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(ag1, 0.1)}, ${hexAlpha(ag2, 0.06)})` }}
            >
              <div className="flex items-baseline justify-between gap-3">
                <span className={cn("flex items-center gap-1.5 text-[10.5px] font-extrabold uppercase text-slate-500 dark:text-slate-400", labelTrack(lang))} dir="auto">
                  <CatIcon name="percent" className="h-3 w-3 shrink-0" />
                  {t("resSheetElapsed")}
                </span>
                <span dir={numDir(lang)} className="font-display text-[20px] font-extrabold tabular-nums text-slate-800 dark:text-white">
                  {elapsedShown === null ? "—" : fmtNum(elapsedShown, lang)}
                  <span className="ms-1 text-[12px] font-bold text-slate-400">%</span>
                </span>
              </div>
              {/* the bar — fills from the reading-direction start (RTL: right),
                  tone-graded by the resident's standing. Static by family
                  convention (premium = restrained; one width transition). */}
              <div className="mt-2 h-2.5 w-full overflow-hidden rounded-full bg-slate-200/80 dark:bg-white/10">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{ width: `${elapsedShown === null ? 0 : elapsedShown}%`, backgroundImage: grad(ag1, ag2) }}
                />
              </div>
              {/* the two lease endpoints — start leads the reading direction */}
              <div className="mt-2 flex items-center justify-between gap-3">
                <span dir={numDir(lang)} className="inline-flex min-w-0 items-center gap-1.5 text-[10px] font-bold tabular-nums text-slate-500 dark:text-slate-400">
                  <CatIcon name="calendar-days" className="h-3 w-3 shrink-0 text-slate-400" />
                  <span className="truncate">{leaseStart ? dateOnly(leaseStart, lang) : "—"}</span>
                </span>
                <span dir={numDir(lang)} className="inline-flex min-w-0 items-center gap-1.5 text-[10px] font-bold tabular-nums text-slate-500 dark:text-slate-400">
                  <span className="truncate">{leaseEnd ? dateOnly(leaseEnd, lang) : "—"}</span>
                  <CatIcon name="calendar-check" className="h-3 w-3 shrink-0 text-slate-400" />
                </span>
              </div>
              <p className="mt-1.5 text-[10.5px] font-bold" style={{ color: ag2 }} dir="auto">
                {statusHeadline}
              </p>
            </div>
          </div>

          {/* ---------- meta stamps ---------- */}
          <div className="flex flex-wrap items-center gap-2">
            <span
              dir={numDir(lang)}
              className="inline-flex items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/70 px-2.5 py-1 text-[10px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400"
            >
              <CatIcon name="calendar" className="h-3 w-3 shrink-0" />
              {t("resSheetMetaStamp")} · {fmtStamp(record.updatedAt || record.createdAt, lang)}
            </span>
          </div>
        </div>

        <SheetFooter t={t} onEdit={onEdit} onPrint={onPrint} onClose={() => onOpenChange(false)} g1={g1} g2={g2} />
      </DialogContent>
    </Dialog>
  );
}
