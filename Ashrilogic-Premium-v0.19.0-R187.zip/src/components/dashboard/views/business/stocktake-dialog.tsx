"use client";

/**
 * Ashrilogic — the STOCKTAKE SESSION dialog (ROUND 132 — the owner's
 * directive: «عند (إضافة الجرد) طورها اكثر لتكون اكثر دقة في عمليات
 * الجرد وتسريع عملية الجرد طريق احترافي وان تكون متمكنه ومتعمقة جداً
 * أثناء الجرد»).
 *
 * A deep, fast, professional counting session:
 *   1. LOCKED HEADER — session code (auto STK-XXXXXXXX), the count date
 *      (today, locked) and the counting team (the signed-in owner, locked).
 *   2. ZONE SELECTION — the physical zone being counted.
 *   3. THE COUNT ENGINE — every sellable/stock item with its EXPECTED
 *      quantity; the counter types or steppers the physical count, and the
 *      variance + accuracy + variance-value recompute LIVE per keystroke.
 *   4. SPEED SURFACES — a search filter (name/SKU), a barcode field (USB /
 *      Bluetooth wedge scanners + camera via barcode-capture.tsx) that
 *      JUMPS straight to the scanned item's count cell, and an
 *      "accept expected" bulk action for the visible rows.
 *   5. COMMIT — maps back onto the stocktake module-record contract
 *      (items counted / net variance / variance value / live accuracy).
 */
import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useT } from "@/lib/i18n";
import type { InstanceDTO } from "@/lib/types";
import { buildModuleDataset, buildRecordsDataset, type ColDef, type ModuleRow } from "@/lib/module-data";
import { fetchModuleRecords } from "@/lib/api-client";
import { colIndex } from "./business-config";
import { normalizeSearch, grad, hexAlpha, cn, fmtId, fmtMoneyCell, fmtNum, idDir, numDir } from "@/lib/utils";
import { CatIcon } from "@/components/icon";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { BarcodeCaptureDialog } from "./barcode-capture";

/* the countable item (products module OR inventory items). */
export interface StkCountItem {
  id: string;
  name: string;
  sku: string;
  barcode: string;
  expected: number;
  unitCost: number;
  location: string;
}

const ZONES = [
  { ar: "المستودع الرئيسي", en: "Main warehouse" },
  { ar: "منطقة الرفوف", en: "Shelving area" },
  { ar: "منطقة الاستلام", en: "Receiving area" },
  { ar: "الغرفة الباردة", en: "Cold room" },
  { ar: "منطقة الشحن", en: "Shipping area" },
  { ar: "رف العرض الأمامي", en: "Front display shelf" },
];

const isoToday = (d: Date): string =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

export function StocktakeDialog({
  open,
  onOpenChange,
  instance,
  suggestedCode,
  saving,
  onSave,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  instance: InstanceDTO;
  suggestedCode: string | null;
  saving: boolean;
  onSave: (payload: { recordId: string | null; values: string[]; statusKey: string }) => void;
}) {
  const { t, lang } = useT();
  const currency = instance.org.currency;
  const c1 = "#0891b2";
  const c2 = "#155e75";

  /* ---------------- countable items (real rows → demo) --------------- */
  const hasProducts = instance.modules.includes("products");
  const sourceModule = hasProducts ? "products" : instance.modules.includes("inventory") ? "inventory" : null;

  const realRowsQuery = useQuery({
    queryKey: ["module-records", instance.id, sourceModule],
    queryFn: () => fetchModuleRecords(instance.id, sourceModule as string),
    enabled: open && !!sourceModule,
    staleTime: 30_000,
    retry: 0,
  });

  const items: StkCountItem[] = useMemo(() => {
    if (!sourceModule) return [];
    /* ROUND 132 — MERGE: real rows first, then the demo count sheet
     * (deduped by SKU) — the session counts the FULL catalog, with the
     * owner's real expected quantities winning for their real items. */
    const merged: StkCountItem[] = [];
    const seenSkus = new Set<string>();
    const push = (list: StkCountItem[]) => {
      for (const it of list) {
        if (it.sku && seenSkus.has(it.sku)) continue;
        if (it.sku) seenSkus.add(it.sku);
        merged.push(it);
      }
    };
    if (realRowsQuery.data && realRowsQuery.data.length > 0) {
      const ds = buildRecordsDataset(sourceModule, realRowsQuery.data, lang, currency, instance.systemId);
      push(dsToItems(ds.cols, ds.rows, hasProducts));
    }
    const ds = buildModuleDataset(instance.id, sourceModule, lang, currency, instance.systemId);
    push(dsToItems(ds.cols, ds.rows, hasProducts));
    return merged;
  }, [sourceModule, realRowsQuery.data, lang, currency, instance.id, instance.systemId, hasProducts]);

  /* ---------------- session state ---------------- */
  const [zone, setZone] = useState(lang === "ar" ? ZONES[0].ar : ZONES[0].en);
  const [counts, setCounts] = useState<Record<string, string>>({});
  const [query, setQuery] = useState("");
  const [scanValue, setScanValue] = useState("");
  const [cameraOpen, setCameraOpen] = useState(false);
  const [jumpedId, setJumpedId] = useState<string | null>(null);
  const scanRef = useRef<HTMLInputElement>(null);
  const jumpRef = useRef<HTMLLIElement>(null);

  /* conditional mount = a fresh session per open; only the scan-field
   * autofocus remains (wedge scanners expect focus on open). */
  useEffect(() => {
    if (!open) return;
    const id = window.setTimeout(() => scanRef.current?.focus(), 120);
    return () => window.clearTimeout(id);
  }, [open]);

  /* the count engine — filtered view of the countable items */
  const filtered = useMemo(() => {
    const q = normalizeSearch(query);
    if (!q) return items;
    return items.filter((it) => normalizeSearch(it.name).includes(q) || normalizeSearch(it.sku).includes(q));
  }, [items, query]);

  const countOf = (id: string): number => {
    const raw = counts[id];
    if (raw === undefined || raw === "") return NaN;
    const n = Number(raw);
    return Number.isFinite(n) ? n : NaN;
  };

  const setCount = (id: string, v: string) => {
    setCounts((prev) => ({ ...prev, [id]: v.replace(/[^\d]/g, "") }));
  };

  const bumpCount = (id: string, delta: number) => {
    const cur = Number.isNaN(countOf(id)) ? 0 : countOf(id);
    setCount(id, String(Math.max(0, cur + delta)));
  };

  /* LIVE aggregates: counted / net variance / accuracy / variance value */
  const stats = useMemo(() => {
    let counted = 0;
    let netVariance = 0;
    let absVariance = 0;
    let expectedTotal = 0;
    let varianceValue = 0;
    for (const it of items) {
      const c = countOf(it.id);
      if (!Number.isNaN(c)) {
        counted += 1;
        netVariance += c - it.expected;
        absVariance += Math.abs(c - it.expected);
        varianceValue += (c - it.expected) * it.unitCost;
      }
      expectedTotal += it.expected;
    }
    /* accuracy: 100 − (Σ|variance| / Σexpected × 100), clamped [0,100] */
    const accuracy = expectedTotal > 0 ? Math.max(0, Math.min(100, 100 - (absVariance / expectedTotal) * 100)) : 100;
    return { counted, netVariance, varianceValue, accuracy };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [counts, items]);

  /* barcode fast-entry: jump to the scanned item's count cell */
  const handleScan = (codeRaw: string) => {
    const code = codeRaw.trim();
    const q = normalizeSearch(code);
    const target =
      items.find((it) => it.barcode && normalizeSearch(it.barcode) === q) ??
      items.find((it) => it.sku && normalizeSearch(it.sku) === q) ??
      null;
    if (target) {
      setQuery("");
      setJumpedId(target.id);
      window.setTimeout(() => {
        jumpRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
      }, 60);
      window.setTimeout(() => setJumpedId(null), 1600);
    } else {
      /* no exact hit → put the code into the search filter instead */
      setQuery(code);
    }
    setScanValue("");
    scanRef.current?.focus();
  };

  const acceptExpectedVisible = () => {
    setCounts((prev) => {
      const next = { ...prev };
      for (const it of filtered) next[it.id] = String(it.expected);
      return next;
    });
  };

  const submit = () => {
    if (stats.counted === 0) return;
    onSave({
      recordId: null,
      values: [
        suggestedCode ?? "",
        zone,
        isoToday(new Date()),
        instance.admin.name,
        String(stats.counted),
        String(stats.netVariance),
        stats.varianceValue.toFixed(2),
        stats.accuracy.toFixed(1),
        "reviewed",
      ],
      statusKey: "reviewed",
    });
  };

  return (
    <>
      <Dialog open={open} onOpenChange={(o) => !o && onOpenChange(o)}>
        <DialogContent
          dir={lang === "ar" ? "rtl" : "ltr"}
          className="flex max-h-[92vh] flex-col gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-3xl"
        >
          {/* gradient header + locked session band */}
          <div
            className="relative shrink-0 overflow-hidden border-b border-slate-200/70 dark:border-white/10"
            style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.16)}, ${hexAlpha(c2, 0.16)})` }}
          >
            <span className="absolute -end-10 -top-16 h-32 w-32 rounded-full" style={{ background: `radial-gradient(circle, ${hexAlpha(c1, 0.28)}, transparent 70%)` }} aria-hidden="true" />
            <div className="flex items-center gap-3.5 px-5 pt-4">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg" style={{ backgroundImage: grad(c1, c2) }} aria-hidden="true">
                <CatIcon name="clipboard-check" className="h-5 w-5" />
              </span>
              <div className="min-w-0 flex-1">
                <DialogTitle className="truncate font-display text-[15px] font-extrabold leading-tight text-slate-900 dark:text-white">
                  {t("stkDialogTitle")}
                </DialogTitle>
                <DialogDescription className="mt-0.5 truncate text-[11.5px] font-semibold text-slate-500 dark:text-slate-400">
                  {t("stkDialogDesc")}
                </DialogDescription>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 px-5 pb-4 pt-3 sm:grid-cols-3">
              <div className="min-w-0 rounded-xl border border-slate-200/80 bg-white/70 px-2.5 py-1.5 dark:border-white/10 dark:bg-white/[0.04]">
                <p className="flex items-center gap-1 text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400">
                  <CatIcon name="hash" className="h-2.5 w-2.5" aria-hidden="true" />
                  {t("posTxNumber")}
                </p>
                <p dir={idDir} className="truncate font-mono text-[11.5px] font-extrabold tabular-nums text-slate-700 dark:text-slate-200">{fmtId(suggestedCode ?? "—", lang)}</p>
              </div>
              <div className="min-w-0 rounded-xl border border-slate-200/80 bg-white/70 px-2.5 py-1.5 dark:border-white/10 dark:bg-white/[0.04]">
                <p className="flex items-center gap-1 text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400">
                  <CatIcon name="calendar" className="h-2.5 w-2.5" aria-hidden="true" />
                  {t("posDate")}
                </p>
                <p dir="ltr" className="truncate font-mono text-[11.5px] font-extrabold tabular-nums text-slate-700 dark:text-slate-200">{isoToday(new Date())}</p>
              </div>
              <div className="col-span-2 min-w-0 rounded-xl border border-slate-200/80 bg-white/70 px-2.5 py-1.5 sm:col-span-1 dark:border-white/10 dark:bg-white/[0.04]">
                <p className="flex items-center gap-1 text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400">
                  <CatIcon name="user-round" className="h-2.5 w-2.5" aria-hidden="true" />
                  {t("stkCounter")}
                </p>
                <p className="truncate text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200">{instance.admin.name}</p>
              </div>
            </div>
          </div>

          {/* toolbar: zone + search + barcode + live stats */}
          <div className="shrink-0 space-y-2.5 border-b border-slate-200/70 px-5 py-3 dark:border-white/10">
            <div className="grid gap-2.5 sm:grid-cols-2">
              <div className="space-y-1">
                <Label className="text-[10px] font-extrabold uppercase tracking-wide text-slate-400">{t("stkZone")}</Label>
                <Select value={zone} onValueChange={setZone}>
                  <SelectTrigger className="h-9 rounded-xl text-[12px] font-bold" aria-label={t("stkZone")}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      {ZONES.map((z) => (
                        <SelectItem key={z.en} value={lang === "ar" ? z.ar : z.en}>
                          {lang === "ar" ? z.ar : z.en}
                        </SelectItem>
                      ))}
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-[10px] font-extrabold uppercase tracking-wide text-slate-400">{t("stkProgress")}</Label>
                <div className="flex h-9 items-center justify-between gap-2 rounded-xl border border-slate-200 bg-slate-50/60 px-3 dark:border-white/10 dark:bg-white/[0.03]">
                  <p className="text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                    {t("stkCountedOf", { counted: fmtNum(stats.counted, lang), total: fmtNum(items.length, lang) })}
                  </p>
                  <p
                    dir={numDir(lang)}
                    className={cn(
                      "text-[11.5px] font-extrabold tabular-nums",
                      stats.accuracy >= 98 ? "text-emerald-600 dark:text-emerald-400" : stats.accuracy >= 95 ? "text-amber-600 dark:text-amber-400" : "text-rose-600 dark:text-rose-400"
                    )}
                  >
                    {t("stkAccuracy")}: {fmtNum(Number(stats.accuracy.toFixed(1)), lang)}%
                  </p>
                </div>
              </div>
            </div>

            {/* the barcode fast-entry (wedge + camera) */}
            <div
              className="cursor-text rounded-xl border border-dashed border-cyan-300/70 bg-cyan-50/40 px-3 py-1.5 dark:border-cyan-500/40 dark:bg-cyan-500/5"
              onClick={() => scanRef.current?.focus()}
            >
              <div className="flex items-center justify-between gap-2">
                <Input
                  id="stk-scan"
                  ref={scanRef}
                  value={scanValue}
                  onChange={(e) => setScanValue(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      handleScan(scanValue);
                    }
                  }}
                  dir="ltr"
                  inputMode="numeric"
                  placeholder={t("stkSearchPh")}
                  className="h-7 border-0 bg-transparent px-0 font-mono text-[12.5px] font-bold tracking-wider focus-visible:ring-0"
                  aria-label={t("stkSearchPh")}
                />
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setCameraOpen(true);
                  }}
                  className="inline-flex shrink-0 items-center gap-1 rounded-full bg-cyan-600 px-2 py-0.5 text-[10px] font-extrabold text-white transition hover:brightness-110 active:scale-95"
                >
                  <CatIcon name="camera" className="h-3 w-3" aria-hidden="true" />
                  {t("posScanCamera")}
                </button>
              </div>
              <p className="text-[9.5px] font-bold text-cyan-600/80 dark:text-cyan-400/80">{t("stkFastHint")}</p>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <CatIcon name="search" className="pointer-events-none absolute start-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" aria-hidden="true" />
                <Input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder={t("bizSearchPh")}
                  className="h-9 rounded-xl ps-9 text-[12px] font-semibold"
                  aria-label={t("bizSearchPh")}
                />
              </div>
              <Button
                type="button"
                variant="outline"
                onClick={acceptExpectedVisible}
                disabled={filtered.length === 0}
                className="h-9 shrink-0 rounded-xl px-3 text-[11.5px] font-bold"
              >
                <CatIcon name="check-check" className="h-3.5 w-3.5" />
                {t("stkCopyExpected")}
              </Button>
            </div>
          </div>

          {/* the count list */}
          <div className="nice-scroll min-h-0 flex-1 overflow-y-auto px-5 py-3">
            {items.length === 0 ? (
              <p className="rounded-xl border border-dashed border-amber-300 bg-amber-50/50 px-3 py-3 text-center text-[11.5px] font-bold text-amber-600 dark:border-amber-500/40 dark:bg-amber-500/10 dark:text-amber-300">
                {t("stkNoItems")}
              </p>
            ) : (
              <ul className="space-y-1.5">
                {filtered.map((it) => {
                  const c = countOf(it.id);
                  const counted = !Number.isNaN(c);
                  const variance = counted ? c - it.expected : null;
                  return (
                    <li
                      key={it.id}
                      ref={jumpedId === it.id ? jumpRef : undefined}
                      className={cn(
                        "rounded-xl border px-3 py-2 transition",
                        jumpedId === it.id
                          ? "border-cyan-400 bg-cyan-50/70 dark:border-cyan-500/60 dark:bg-cyan-500/10"
                          : "border-slate-200 bg-white dark:border-white/10 dark:bg-white/[0.03]"
                      )}
                    >
                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                        <span className="min-w-0 flex-1 basis-52">
                          <span className="block truncate text-[12px] font-extrabold text-slate-800 dark:text-slate-100">{it.name}</span>
                          <span dir={idDir} className="block truncate font-mono text-[9.5px] font-bold text-slate-400">
                            {fmtId(it.sku, lang)}
                            {it.location ? ` · ${it.location}` : ""}
                          </span>
                        </span>
                        <span className="shrink-0 text-[10.5px] font-bold text-slate-400" dir={numDir(lang)}>
                          {t("stkExpected")}: <span className="tabular-nums text-slate-600 dark:text-slate-300">{fmtNum(it.expected, lang)}</span>
                        </span>
                        {/* the count cell */}
                        <span className="flex shrink-0 items-center gap-1" dir="ltr">
                          <button
                            type="button"
                            onClick={() => bumpCount(it.id, -1)}
                            aria-label="-"
                            className="grid h-7 w-7 place-items-center rounded-lg border border-slate-200 bg-slate-50 text-[13px] font-extrabold text-slate-500 transition hover:border-slate-300 active:scale-90 dark:border-white/10 dark:bg-white/5 dark:text-slate-300"
                          >
                            −
                          </button>
                          <Input
                            value={counts[it.id] ?? ""}
                            onChange={(e) => setCount(it.id, e.target.value)}
                            inputMode="numeric"
                            dir="ltr"
                            placeholder="0"
                            aria-label={`${it.name} — ${t("stkCounted")}`}
                            className="h-7 w-16 rounded-lg text-center font-mono text-[12.5px] font-extrabold tabular-nums"
                          />
                          <button
                            type="button"
                            onClick={() => bumpCount(it.id, 1)}
                            aria-label="+"
                            className="grid h-7 w-7 place-items-center rounded-lg border border-slate-200 bg-slate-50 text-[13px] font-extrabold text-slate-500 transition hover:border-slate-300 active:scale-90 dark:border-white/10 dark:bg-white/5 dark:text-slate-300"
                          >
                            +
                          </button>
                        </span>
                        {/* live variance pill */}
                        <span className="w-20 shrink-0 text-end">
                          {variance !== null ? (
                            <span
                              dir={numDir(lang)}
                              className={cn(
                                "inline-flex min-w-full items-center justify-center gap-1 rounded-full px-2 py-0.5 text-[10.5px] font-extrabold tabular-nums",
                                variance === 0
                                  ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300"
                                  : variance > 0
                                    ? "bg-sky-100 text-sky-700 dark:bg-sky-500/15 dark:text-sky-300"
                                    : "bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300"
                              )}
                            >
                              {variance > 0 ? `+${fmtNum(variance, lang)}` : fmtNum(variance, lang)}
                            </span>
                          ) : (
                            <span className="text-[10.5px] font-bold text-slate-300 dark:text-slate-600">—</span>
                          )}
                        </span>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>

          {/* footer: live aggregates + commit */}
          <div className="shrink-0 space-y-2.5 border-t border-slate-200/70 px-5 py-3.5 dark:border-white/10">
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="rounded-xl border border-slate-200/80 bg-slate-50/60 px-2 py-1.5 dark:border-white/10 dark:bg-white/[0.03]">
                <p className="text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400">{t("stkNetVariance")}</p>
                <p dir={numDir(lang)} className={cn("text-[13px] font-extrabold tabular-nums", stats.netVariance === 0 ? "text-emerald-600 dark:text-emerald-400" : stats.netVariance > 0 ? "text-sky-600 dark:text-sky-400" : "text-rose-600 dark:text-rose-400")}>
                  {stats.netVariance > 0 ? `+${fmtNum(stats.netVariance, lang)}` : fmtNum(stats.netVariance, lang)}
                </p>
              </div>
              <div className="rounded-xl border border-slate-200/80 bg-slate-50/60 px-2 py-1.5 dark:border-white/10 dark:bg-white/[0.03]">
                <p className="text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400">{t("stkVarianceValue")}</p>
                <p dir={numDir(lang)} className="text-[13px] font-extrabold tabular-nums text-slate-700 dark:text-slate-200">
                  {fmtMoneyCell(stats.varianceValue, lang, currency)}
                </p>
              </div>
              <div className="rounded-xl border border-slate-200/80 bg-slate-50/60 px-2 py-1.5 dark:border-white/10 dark:bg-white/[0.03]">
                <p className="text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400">{t("stkAccuracy")}</p>
                <p dir={numDir(lang)} className={cn("text-[13px] font-extrabold tabular-nums", stats.accuracy >= 98 ? "text-emerald-600 dark:text-emerald-400" : "text-amber-600 dark:text-amber-400")}>
                  {fmtNum(Number(stats.accuracy.toFixed(1)), lang)}%
                </p>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2.5">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                disabled={saving}
                className="h-10 rounded-xl px-4 text-[12.5px] font-bold hover:border-slate-300 hover:bg-slate-100 dark:hover:border-white/20 dark:hover:bg-white/5"
              >
                {t("bizCancel")}
              </Button>
              <Button
                type="button"
                onClick={submit}
                disabled={saving || stats.counted === 0}
                className="h-10 gap-2 rounded-xl px-6 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:opacity-50"
                style={{ backgroundImage: grad(c1, c2) }}
              >
                {saving ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : <CatIcon name="check-check" className="h-4 w-4" />}
                {saving ? t("bizSaving") : t("stkSave")}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <BarcodeCaptureDialog open={cameraOpen} onOpenChange={setCameraOpen} onCapture={handleScan} />
    </>
  );
}

/* ------------------------------------------------------------------ */
/* item extraction (products preset OR inventory preset rows)           */
/* ------------------------------------------------------------------ */

function dsToItems(cols: ColDef[], rows: ModuleRow[], isProducts: boolean): StkCountItem[] {
  const iName = colIndex(cols, isProducts ? "name" : "item");
  const iSku = colIndex(cols, "sku");
  const iBarcode = colIndex(cols, "barcode");
  const iQty = colIndex(cols, isProducts ? "stock" : "qty");
  const iCost = colIndex(cols, isProducts ? "cost" : "unit");
  const iLoc = colIndex(cols, "location");
  const num = (v: string | undefined): number => {
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  };
  return rows.map((r) => ({
    id: r.id,
    name: (iName >= 0 ? r.values[iName] : "") || "—",
    sku: iSku >= 0 ? (r.values[iSku] ?? "") : "",
    barcode: iBarcode >= 0 ? (r.values[iBarcode] ?? "") : "",
    expected: Math.max(0, num(iQty >= 0 ? r.values[iQty] : "0")),
    unitCost: Math.max(0, num(iCost >= 0 ? r.values[iCost] : "0")),
    location: iLoc >= 0 ? (r.values[iLoc] ?? "") : "",
  }));
}
