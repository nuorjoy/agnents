"use client";

/**
 * Ashrilogic — the premium BUSINESS-SUITE workspace (ROUND 131).
 *
 * The dedicated surface for the ten commerce modules the owner directed
 * (نقاط البيع، المنتجات، العملاء، الموردون، المشتريات، العروض، المرتجعات،
 * الولاء، الفروع، التقارير، الجرد) — everything «مثل الأنظمة الكبيرة
 * والعالمية» lives here:
 *
 *   1. Gradient module header with the system/category identity chips
 *   2. A module-specific KPI strip (4-5 cards computed live from the
 *      rows; ROUND 136 renders them through THE unified golden StatCard —
 *      src/components/shared/stat-card.tsx — markup identical to the
 *      former inline cards)
 *   3. Analytics row — breakdown bars + top list + the computed quick read
 *   4. The premium data table — status pills, id monospace chips, money
 *      alignment, stock-health bars (products), growth tone (branches),
 *      row actions (details / edit / delete / print) + demo|mine tabs +
 *      search + status filter + sort + CSV export + pagination
 *   5. The premium add-record dialog (products flagship — see
 *      business-record-dialog.tsx) and the row-detail sheet
 *
 * Data model UNCHANGED: the same buildModuleDataset demo rows + the same
 * module-records API for real rows (سجلاتي) — the generic workspace stays
 * byte-identical for every non-commerce module.
 */
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CATEGORY_MAP, MODULE_MAP, SYSTEM_MAP, moduleDisplayName } from "@/data/catalog";
import { useT } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import type { InstanceDTO, ModuleRecordDTO } from "@/lib/types";
import { buildModuleDataset, buildRecordsDataset, codePrefixFor, type ModuleRow } from "@/lib/module-data";
import type { PaymentEntry } from "@/lib/payment-methods";
import { storeProductModuleId } from "@/lib/store-modules";
import {
  ApiError,
  createModuleRecord,
  deleteModuleRecord,
  fetchModuleRecords,
  fetchSite,
  resyncLoyalty,
  updateModuleRecord,
} from "@/lib/api-client";
import { DEFAULT_INVOICE_PREFIX, nextRecordCode } from "@/lib/record-code";
import { MODULE_FEATURE_GATES } from "@/lib/plan-features";
import { CatIcon } from "@/components/icon";
import { cn, fmtId, fmtMoneyCell, fmtNum, grad, hexAlpha, idDir, normalizeSearch, numDir } from "@/lib/utils";
import { useShift } from "@/components/dashboard/shift/use-shift";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { DashCard } from "@/components/dashboard/dash-shared";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { StatCard } from "@/components/shared/stat-card";
import { FeatureGate } from "@/components/dashboard/feature-gate";
import { RecordPrintDialog, moneyColumnsTotalMinor, type PrintDoc } from "@/components/dashboard/views/record-print";
/* ROUND 164 — the POS module's «معاينة الطباعة» is the dedicated 80mm
 * thermal-receipt preview (NOT the shared A4 document). */
import { PosReceiptPrintDialog } from "@/components/dashboard/views/business/pos-receipt-print";
import { bizConfig, bizKpiLabel, type BizCtx } from "./business-config";
import { BusinessAnalytics } from "./business-analytics";
import { BusinessRecordDialog } from "./business-record-dialog";
import { PosTerminalDialog } from "./pos-terminal-dialog";
import { StocktakeDialog } from "./stocktake-dialog";
import { RecordDetailSheet } from "./record-detail-sheet";
/* ROUND 164 — the PREMIUM record-details drawer (تفاصيل السجل) — replaces
 * the old generic field-passport for every non-specialized module. */
import { RecordDetailDrawer } from "./record-detail-drawer";
import { MEDICAL_DETAIL_MODULES } from "./medical-detail-modes";
import { StudentProfileSheet } from "./student-profile-sheet";
import { TeacherProfileSheet } from "./teacher-profile-sheet";
import { ParentProfileSheet } from "./parent-profile-sheet";
import { CertificateProfileSheet } from "./certificate-profile-sheet";
import { StaffProfileSheet } from "./staff-profile-sheet";
/* ROUND 166 — SAMS residents (the module labeled الطلاب/Students inside
 * the student-accommodation system) get the DEDICATED premium resident
 * profile sheet — parity with the education family's dedicated sheets. */
import { ResidentProfileSheet } from "./resident-profile-sheet";

const TONE_DOT: Record<string, string> = {
  emerald: "bg-emerald-500",
  amber: "bg-amber-500",
  rose: "bg-rose-500",
  sky: "bg-sky-500",
  violet: "bg-violet-500",
  slate: "bg-slate-400",
};

const TONE_STYLE: Record<string, string> = {
  emerald: "bg-emerald-500/12 text-emerald-700 dark:text-emerald-300",
  amber: "bg-amber-500/12 text-amber-700 dark:text-amber-300",
  rose: "bg-rose-500/12 text-rose-700 dark:text-rose-300",
  sky: "bg-sky-500/12 text-sky-700 dark:text-sky-300",
  violet: "bg-violet-500/12 text-violet-700 dark:text-violet-300",
  slate: "bg-slate-500/12 text-slate-600 dark:text-slate-300",
};

const PAGE_SIZE = 8;

type SortKey = "default" | "moneyDesc" | "moneyAsc" | "name";

export function BusinessWorkspace({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const setDashView = useAppStore((s) => s.setDashView);
  const activeModuleId = useAppStore((s) => s.activeModuleId);
  const setActiveModuleId = useAppStore((s) => s.setActiveModuleId);
  const queryClient = useQueryClient();

  /* ROUND 132 — bizConfig NEVER misses now (fallback generator covers
   * every module in the catalog). ROUND 168 — systemId scopes the fallback
   * preset (SAMS dorm maintenance/security draw dorm vocabulary). */
  const config = activeModuleId ? bizConfig(activeModuleId, instance.systemId) : null;

  /* ROUND 166 — DEMO LIFECYCLE (business modules): prefs.demo governs the
   * showcase exactly as in the generic module workspace. Enabled → demo
   * tab + landing (historical behavior). Disabled → demo tab, dataset and
   * seeded codes vanish; سجلاتي is the only source (honest zero state). */
  const demoEnabled = instance.prefs.demo !== false;
  const [sourceState, setSourceState] = useState<"demo" | "mine">("demo");
  const source: "demo" | "mine" = demoEnabled ? sourceState : "mine";
  const setSource = (next: "demo" | "mine") => {
    if (!demoEnabled && next === "demo") return;
    setSourceState(next);
  };
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortKey, setSortKey] = useState<SortKey>("default");
  const [page, setPage] = useState(0);

  /* real persisted rows (سجلاتي) */
  const recordsQuery = useQuery({
    queryKey: ["module-records", instance.id, activeModuleId],
    queryFn: () => fetchModuleRecords(instance.id, activeModuleId as string),
    enabled: !!activeModuleId,
    staleTime: 30_000,
    retry: 0,
  });
  const records = recordsQuery.data ?? [];

  /* the org letterhead (brand preview + invoice prefix parity with the
   * generic workspace — cached under the same query key) */
  const siteQuery = useQuery({
    queryKey: ["site", instance.id],
    queryFn: () => fetchSite(instance.id),
    staleTime: 60_000,
    retry: 0,
  });
  const invoicePrefix = siteQuery.data?.content.invoicePrefix || DEFAULT_INVOICE_PREFIX;

  const system = SYSTEM_MAP[instance.systemId];
  const cat = system ? CATEGORY_MAP[system.c] : undefined;
  const c1 = cat?.c1 ?? "#6d5dfb";
  const c2 = cat?.c2 ?? "#0ea5e9";

  const mod = activeModuleId ? MODULE_MAP[activeModuleId] : undefined;
  const moduleName = activeModuleId ? moduleDisplayName(activeModuleId, instance.systemId, lang) : "";
  const systemName = system ? (lang === "ar" ? system.nameAr : system.nameEn) : instance.systemId;
  const categoryName = cat ? (lang === "ar" ? cat.nameAr : cat.nameEn) : "";

  /* datasets — demo (deterministic, sector-matched) + mine (real rows).
   *  ROUND 166: the demo set is not built at all when the demo lifecycle
   *  is retired — off the wire and out of memory, not merely hidden. */
  const demoData = useMemo(
    () =>
      activeModuleId && demoEnabled
        ? buildModuleDataset(instance.id, activeModuleId, lang, instance.org.currency, instance.systemId)
        : null,
    [instance.id, instance.org.currency, instance.systemId, activeModuleId, lang, demoEnabled]
  );
  const myData = useMemo(
    () =>
      activeModuleId && source === "mine"
        ? buildRecordsDataset(activeModuleId, records, lang, instance.org.currency, instance.systemId)
        : null,
    [activeModuleId, source, records, lang, instance.org.currency, instance.systemId]
  );
  const data = source === "mine" ? myData : demoData;

  /* record-code machinery (same contract as the generic workspace) */
  const idColIndex = data?.cols.findIndex((c) => c.kind === "id") ?? -1;
  const isInvoiceModule = activeModuleId === "invoices";
  const modulePrefix = activeModuleId ? codePrefixFor(activeModuleId) : "";
  const allCodes = useMemo(() => {
    if (idColIndex < 0) return [] as string[];
    const codes: string[] = [];
    for (const row of demoData?.rows ?? []) {
      const code = row.values[idColIndex];
      if (code) codes.push(code);
    }
    for (const row of records) {
      const code = row.values[idColIndex];
      if (code) codes.push(code);
    }
    return codes;
  }, [demoData, records, idColIndex]);
  const suggestedCode =
    idColIndex >= 0 && activeModuleId ? nextRecordCode(modulePrefix, allCodes, { invoice: isInvoiceModule }) : null;

  /* dialog + delete + print + row-detail state */
  const [recordDialogOpen, setRecordDialogOpen] = useState(false);
  const [editingRow, setEditingRow] = useState<ModuleRow | null>(null);
  const [pendingDelete, setPendingDelete] = useState<ModuleRow | null>(null);
  const [detailRow, setDetailRow] = useState<ModuleRow | null>(null);
  const [printDoc, setPrintDoc] = useState<PrintDoc | null>(null);

  const invalidateRecords = () => {
    void queryClient.invalidateQueries({ queryKey: ["module-records", instance.id, activeModuleId] });
  };

  /* ROUND 133 — نظام الورديات: the shared shift state (same query key the
   * global bar feeds) drives the CLIENT-SIDE gate on every mutation entry
   * point (add/edit/delete); the SERVER enforces the same law with 403
   * SHIFT_REQUIRED — the client gate is UX, never the security boundary. */
  /* ROUND 134 — the الورديات module toggle gates the CLIENT mirror too:
   * module off → no shift state, no pre-gate (the server is the law and
   * its gate is off in exactly the same condition). */
  const shiftsEnabled = instance.modules.includes("shifts");
  const shiftQuery = useShift(instance.id, shiftsEnabled);
  const shiftOpen = !shiftsEnabled || shiftQuery.data?.current != null;
  const requireShift = (action: () => void) => {
    if (!shiftOpen) {
      toast.error(t("shiftGatedToast"));
      void queryClient.invalidateQueries({ queryKey: ["shifts", instance.id] });
      return;
    }
    action();
  };

  const saveRecord = useMutation({
    mutationFn: (payload: {
      recordId: string | null;
      values: string[];
      statusKey: string;
      /** ROUND 133 — POS customer linkage (drives the loyalty engine). */
      meta?: { customerPhone: string; customerName: string };
      /** ROUND 141 (㉕) — the structured 7-method payment ledger. */
      payments?: PaymentEntry[];
      /** ROUND 141 (product extras) — the gallery (undefined = don't touch)
       *  + the variant rows (undefined = keep). */
      gallery?: string[];
      variants?: { id?: string; name: string; price?: number; stock?: number; sku?: string }[];
      /** ROUND 156 — the optional receipt image (the expenses module):
       *  managed /api/images URL, null to clear, undefined to leave
       *  untouched. Rides the API's `image` field. */
      image?: string | null;
    }) =>
      payload.recordId
        ? updateModuleRecord(instance.id, payload.recordId, {
            values: payload.values,
            statusKey: payload.statusKey,
            ...(payload.payments !== undefined ? { payments: payload.payments } : {}),
            ...(payload.gallery !== undefined ? { gallery: payload.gallery } : {}),
            ...(payload.variants !== undefined ? { variants: payload.variants } : {}),
            /* ROUND 156 — null clears the receipt image (the API route's
               resolveRecordImage treats "" as "clear"; undefined omits the
               field so the existing image stays untouched). */
            ...(payload.image !== undefined ? { image: payload.image ?? "" } : {}),
          })
        : createModuleRecord(instance.id, {
            moduleId: activeModuleId as string,
            values: payload.values,
            statusKey: payload.statusKey,
            ...(payload.meta ? { meta: payload.meta } : {}),
            ...(payload.payments !== undefined ? { payments: payload.payments } : {}),
            ...(payload.gallery !== undefined ? { gallery: payload.gallery } : {}),
            ...(payload.variants !== undefined ? { variants: payload.variants } : {}),
            ...(payload.image !== undefined ? { image: payload.image ?? "" } : {}),
          }),
    onSuccess: (_data, payload) => {
      invalidateRecords();
      setSource("mine");
      setRecordDialogOpen(false);
      setEditingRow(null);
      toast.success(payload.recordId ? t("bizUpdatedToast") : t("bizSavedToast"));
      /* a completed POS sale under an open shift refreshes the live aggregates */
      if (activeModuleId === "pos") {
        void queryClient.invalidateQueries({ queryKey: ["shifts", instance.id] });
      }
    },
    onError: (e: Error) => {
      if (e instanceof ApiError) {
        /* ROUND 133 — the strict shift law: server refused the mutation
         * because no shift is open — refresh the state + the precise toast */
        if (e.code === "SHIFT_REQUIRED" || (e.status === 403 && e.message.includes("shift"))) {
          void queryClient.invalidateQueries({ queryKey: ["shifts", instance.id] });
          toast.error(t("shiftGatedTrySave"));
          return;
        }
        if (e.status === 409) invalidateRecords();
      }
      toast.error(e.message || t("modRecSaveErr"));
    },
  });

  /* ROUND 156 — the row-actions STATUS UPDATE mutation: a single-key
   * PATCH (statusKey only) routed through the existing updateModuleRecord
   * API (the user's directive: «زر لتحديث الحالة بطريقة احترافية وPremium»).
   * Mirrors saveRecord's error handling (the shift law + 409 invalidation)
   * so the same operator-side UX applies. */
  const updateStatus = useMutation({
    mutationFn: (payload: { recordId: string; statusKey: string }) =>
      updateModuleRecord(instance.id, payload.recordId, { statusKey: payload.statusKey }),
    onSuccess: (_data, payload) => {
      invalidateRecords();
      const sdef = data?.statuses.find((x) => x.key === payload.statusKey);
      const label = sdef ? (lang === "ar" ? sdef.ar : sdef.en) : payload.statusKey;
      toast.success(t("bizStatusUpdatedToast", { status: label }));
    },
    onError: (e: Error) => {
      if (e instanceof ApiError && (e.code === "SHIFT_REQUIRED" || (e.status === 403 && e.message.includes("shift")))) {
        void queryClient.invalidateQueries({ queryKey: ["shifts", instance.id] });
        toast.error(t("shiftGatedTrySave"));
        return;
      }
      if (e instanceof ApiError && e.status === 409) invalidateRecords();
      toast.error(e.message || t("modRecSaveErr"));
    },
  });

  const removeRecord = useMutation({
    mutationFn: (recordId: string) => deleteModuleRecord(instance.id, recordId),
    onSuccess: () => {
      invalidateRecords();
      setPendingDelete(null);
      toast.success(t("modRecDeleted"));
    },
    onError: (e: Error) => {
      if (e instanceof ApiError && (e.code === "SHIFT_REQUIRED" || (e.status === 403 && e.message.includes("shift")))) {
        void queryClient.invalidateQueries({ queryKey: ["shifts", instance.id] });
        toast.error(t("shiftGatedTrySave"));
        return;
      }
      toast.error(e.message || t("modRecDeleteErr"));
    },
  });

  /* ROUND 133 — the loyalty auto engine's resync action (the loyalty page's
   * «مزامنة من المبيعات»): recompute customers from the REAL completed sales
   * and rebuild the loyalty rows. */
  const loyaltySync = useMutation({
    mutationFn: () => resyncLoyalty(instance.id),
    onSuccess: (data) => {
      invalidateRecords();
      void queryClient.invalidateQueries({ queryKey: ["module-records", instance.id, "customers"] });
      toast.success(
        t("loyaltySyncDone", {
          customers: fmtNum(data.result.customersSynced, lang),
          points: fmtNum(data.result.totalPoints, lang),
          rows: fmtNum(data.result.loyaltyRows, lang),
        })
      );
    },
    onError: (e: Error) => {
      if (e instanceof ApiError && (e.code === "SHIFT_REQUIRED" || (e.status === 403 && e.message.includes("shift")))) {
        toast.error(t("loyaltySyncNeedShift"));
        return;
      }
      toast.error(e.message || t("modRecSaveErr"));
    },
  });

  /* ---------------- filtering + sorting + pagination ---------------- */
  const rows = data?.rows ?? [];
  const moneyIndex = data?.valueKey ? data.cols.findIndex((c) => c.key === data.valueKey) : -1;
  const filtered = useMemo(() => {
    const q = normalizeSearch(query);
    const base = rows.filter((row) => {
      if (statusFilter !== "all" && row.statusKey !== statusFilter) return false;
      if (!q) return true;
      return row.values.some((v) => normalizeSearch(v).includes(q));
    });
    if (sortKey === "default") return base;
    if (sortKey === "name") {
      return [...base].sort((a, b) => (a.values[0] ?? "").localeCompare(b.values[0] ?? "", lang === "ar" ? "ar" : "en"));
    }
    if (moneyIndex >= 0) {
      const dir = sortKey === "moneyDesc" ? -1 : 1;
      return [...base].sort((a, b) => dir * (Number(a.values[moneyIndex] ?? 0) - Number(b.values[moneyIndex] ?? 0)));
    }
    return base;
  }, [rows, query, statusFilter, sortKey, moneyIndex, lang]);

  const pages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, pages - 1);
  const pageRows = filtered.slice(safePage * PAGE_SIZE, safePage * PAGE_SIZE + PAGE_SIZE);

  /* ---------------- plan gate (mirror of the generic workspace) ------- */
  if (!activeModuleId || !data || !config) {
    return (
      <div className="space-y-5">
        <DashCard title={t("modOpenTitle")} icon="cubes">
          <p className="text-[12.5px] text-slate-500 dark:text-slate-400">{t("modOpenEmptyDesc")}</p>
          <Button
            onClick={() => setDashView("modules")}
            className="mt-4 h-10 rounded-xl px-5 text-[12.5px] font-bold text-white shadow-lg shadow-brand-500/25 hover:brightness-110"
            style={{ backgroundImage: grad(c1, c2) }}
          >
            <CatIcon name="cubes" className="h-4 w-4" />
            {t("dashModulesTitle")}
          </Button>
        </DashCard>
      </div>
    );
  }

  const gatedFeature = MODULE_FEATURE_GATES[activeModuleId];
  if (gatedFeature && instance.entitlement?.features?.[gatedFeature] === false) {
    return <FeatureGate feature={gatedFeature} instance={instance} title={moduleName} />;
  }

  /* the analytics/KPI context — one object, pure computations */
  const ctx: BizCtx = {
    data,
    lang,
    currency: data.currency ?? instance.org.currency,
    rows: filtered,
    cols: data.cols,
    statuses: data.statuses,
  };

  /* ---------------- CSV export ---------------- */
  const exportCsv = () => {
    const header = data.cols.map((c) => (lang === "ar" ? c.ar : c.en)).join(",");
    const lines = filtered.map((r) => r.values.map((v) => (v.includes(",") ? `"${v}"` : v)).join(","));
    const csv = `\uFEFF${[header, ...lines].join("\n")}`;
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${instance.org.name}-${activeModuleId}-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(t("modExportDone"), { description: `${filtered.length} ${t("modRowsUnit")}` });
  };

  /* ---------------- print doc ----------------
     ROUND 141 (㉕) — the structured payment ledger + the money-column grand
     total ride the doc (the settlement strip prints on the paper). */
  const buildPrintDoc = (row: ModuleRow) => {
    const fields: PrintDoc["fields"] = [];
    data.cols.forEach((col, i) => {
      const value = row.values[i] ?? "";
      if (col.kind === "status") return;
      fields.push({
        label: lang === "ar" ? col.ar : col.en,
        value,
        kind: col.kind === "num" ? "num" : col.kind,
      });
    });
    const st = data.statuses.find((s) => s.key === row.statusKey);
    /* ROUND 164 — the POS customer stamps (record meta) ride the doc so
     * the thermal receipt can print them; other modules ignore them. */
    const realMeta = records.find((r) => r.id === row.id)?.meta;
    setPrintDoc({
      title: row.values[0] ?? "—",
      moduleName,
      fields,
      statusLabel: st ? (lang === "ar" ? st.ar : st.en) : null,
      payments: row.payments ?? [],
      totalMinor: moneyColumnsTotalMinor(data.cols, row.values),
      /* ROUND 156 — the optional receipt image rides the print doc so the
       * premium print page can render it under the field table. */
      imageUrl: row.imageRef ?? null,
      customerName: realMeta?.customerName ?? null,
      customerPhone: realMeta?.customerPhone ?? null,
    });
  };

  const backToModules = () => {
    setActiveModuleId(null);
    setDashView("modules");
  };

  const statusLabel = (key: string): string => {
    const s = data.statuses.find((x) => x.key === key);
    return s ? (lang === "ar" ? s.ar : s.en) : key || "—";
  };

  /* display columns (config subset → table cell order) */
  const displayCols = config.displayCols.map((key) => data.cols.find((c) => c.key === key)).filter((c): c is NonNullable<typeof c> => !!c);

  /* ROUND 164 — the shared row-detail plumbing (the synthetic-DTO law for
   * demo rows + the edit/print handoffs), spread into EITHER the
   * specialized RecordDetailSheet (pos receipt · products passport · the
   * medical blueprints) OR the new premium RecordDetailDrawer (everything
   * else — the owner's «حذف تفاصيل السجل وإعادة تطويرها» directive). */
  const detailRecordDto = (() => {
    if (!detailRow) return null;
    const real = records.find((r) => r.id === detailRow.id);
    if (real) return real;
    const synthetic: ModuleRecordDTO = {
      id: detailRow.id,
      moduleId: activeModuleId,
      values: detailRow.values,
      statusKey: detailRow.statusKey,
      imageRef: null,
      featured: false,
      salePrice: null,
      saleEndsAt: null,
      gallery: [],
      videos: [],
      storeVisible: true,
      variants: [],
      payments: [],
      shiftId: null,
      meta: null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    return synthetic;
  })();
  const closeDetail = (o: boolean) => {
    if (!o) setDetailRow(null);
  };
  const handleDetailEdit = () => {
    if (!detailRow) return;
    const realRow = records.find((r) => r.id === detailRow.id);
    if (!realRow) {
      toast.info(t("bizEditDemoRowHint"));
      return;
    }
    setEditingRow(realRow);
    setDetailRow(null);
    setRecordDialogOpen(true);
  };
  const handleDetailPrint = () => {
    if (detailRow) buildPrintDoc(detailRow);
    setDetailRow(null);
  };
  const specializedDetail =
    activeModuleId === "pos" || activeModuleId === "products" || MEDICAL_DETAIL_MODULES.includes(activeModuleId);

  return (
    /* ROUND 166 — motion pass: the workspace root enters with the platform's
     * step-in utility (350ms rise+fade). The module dispatch remounts this
     * component per module (key={activeModuleId}), so EVERY module switch in
     * every system gets the same premium entrance; prefers-reduced-motion
     * users skip it via the globals guard. */
    <div className="step-in space-y-5">
      {/* ---------------- header ---------------- */}
      <div className="glass-card card-in rounded-3xl p-4 sm:p-5">
        <div className="flex flex-wrap items-start gap-3">
          <span
            className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
            style={{ backgroundImage: grad(c1, c2), boxShadow: `0 12px 28px -12px ${hexAlpha(c1, 0.9)}` }}
            aria-hidden="true"
          >
            <CatIcon name={mod?.icon ?? "briefcase"} className="h-6 w-6" />
          </span>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="font-display text-lg font-extrabold leading-tight text-slate-900 dark:text-white">{moduleName}</h2>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white/80 px-2.5 py-0.5 text-[10px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300">
                <CatIcon name="sparkles" className="h-3 w-3 text-brand-500" />
                {t("bizSuiteBadge")}
              </span>
            </div>
            <p className="mt-1 flex flex-wrap items-center gap-1.5 text-[11.5px] font-bold text-slate-400 dark:text-slate-500">
              <span className="truncate">{systemName}</span>
              <span aria-hidden="true">·</span>
              <span className="truncate">{categoryName}</span>
              <span aria-hidden="true">·</span>
              <span dir="ltr" className="tabular-nums">{fmtNum(filtered.length, lang)}/{fmtNum(rows.length, lang)}</span>
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {activeModuleId === "loyalty" ? (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-violet-200 bg-violet-50 px-2.5 py-0.5 text-[10px] font-extrabold text-violet-600 dark:border-violet-500/20 dark:bg-violet-500/10 dark:text-violet-300">
                <CatIcon name="award" className="h-3 w-3" />
                {t("loyaltyAutoBadge")}
              </span>
            ) : null}
            {activeModuleId === "loyalty" ? (
              <Button
                onClick={() => loyaltySync.mutate()}
                disabled={loyaltySync.isPending}
                variant="outline"
                className="h-10 gap-2 rounded-xl border-violet-200 bg-violet-50 px-4 text-[12px] font-extrabold text-violet-600 transition hover:bg-violet-100 disabled:opacity-60 dark:border-violet-500/20 dark:bg-violet-500/10 dark:text-violet-300 dark:hover:bg-violet-500/20"
              >
                <CatIcon name="refresh-cw" className={cn("h-4 w-4", loyaltySync.isPending && "animate-spin")} />
                {t("loyaltySyncBtn")}
              </Button>
            ) : null}
            <Button
              onClick={() =>
                requireShift(() => {
                  setEditingRow(null);
                  setRecordDialogOpen(true);
                })}
              className="h-10 gap-2 rounded-xl px-4 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95"
              style={{ backgroundImage: grad(c1, c2) }}
            >
              <CatIcon name="plus" className="h-4 w-4" />
              {t("bizAddBtn", { name: moduleName })}
            </Button>
            <Button
              onClick={() => setDashView("modules")}
              variant="outline"
              className="h-10 rounded-xl border-slate-200 bg-white px-3.5 text-[12px] font-bold text-slate-600 hover:border-slate-300 hover:bg-slate-50 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
            >
              <CatIcon name="grid-2x2" className="h-4 w-4" />
              {t("dashModulesTitle")}
            </Button>
          </div>
        </div>
      </div>

      {/* ---------------- KPI strip (ROUND 136 — THE unified golden
          StatCard; byte-faithful to the former inline cards) ---------------- */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        {config.kpis.map((k) => {
          const computed = k.compute(ctx);
          const kpiLabel = bizKpiLabel(k, lang, t);
          return (
            <StatCard
              key={kpiLabel}
              size="golden"
              label={kpiLabel}
              value={computed.value}
              sub={computed.sub}
              icon={k.icon}
              c1={k.c1}
              c2={k.c2}
              tone={computed.tone}
              aria-label={kpiLabel}
            />
          );
        })}
      </div>

      {/* ---------------- analytics row ---------------- */}
      <BusinessAnalytics ctx={ctx} analytics={config.analytics} c1={c1} c2={c2} />

      {/* ---------------- data table ---------------- */}
      <DashCard
        title={moduleName}
        icon="table"
        action={
          <span dir="ltr" className="rounded-full border border-slate-200 bg-slate-50 px-2.5 py-0.5 text-[10.5px] font-extrabold tabular-nums text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
            {filtered.length}/{rows.length}
          </span>
        }
      >
        {/* toolbar */}
        <div className="mb-4 flex flex-wrap items-center gap-2">
          <div
            role="tablist"
            aria-label={t("modRecSourceLabel")}
            className="flex items-center rounded-full border border-slate-200 bg-slate-50 p-0.5 dark:border-white/10 dark:bg-white/[0.04]"
          >
            {/* ROUND 166 — the demo tab exists ONLY while the demo lifecycle
                is enabled (prefs.demo); retired → single-source honesty. */}
            {(demoEnabled ? (["demo", "mine"] as const) : (["mine"] as const)).map((tab) => (
              <button
                key={tab}
                type="button"
                role="tab"
                aria-selected={source === tab}
                onClick={() => {
                  setSource(tab);
                  setPage(0);
                }}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-[11.5px] font-extrabold transition",
                  source === tab
                    ? "text-white shadow-md"
                    : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white"
                )}
                style={source === tab ? { backgroundImage: grad(c1, c2) } : undefined}
              >
                <CatIcon name={tab === "demo" ? "flask-conical" : "database"} className="h-3 w-3" />
                {tab === "demo" ? t("modRecTabDemo") : t("modRecTabMine")}
                {tab === "mine" ? (
                  <span dir="ltr" className="rounded-full bg-white/25 px-1.5 text-[10px] tabular-nums">
                    {fmtNum(records.length, lang)}
                  </span>
                ) : null}
              </button>
            ))}
          </div>

          <div className="relative min-w-0 flex-1 sm:max-w-xs">
            <CatIcon name="search" className="pointer-events-none absolute start-3.5 top-1/2 h-[12px] w-[12px] -translate-y-1/2 text-slate-400" />
            <Input
              type="search"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setPage(0);
              }}
              placeholder={t("bizSearchPh")}
              aria-label={t("bizSearchPh")}
              className="h-10 rounded-xl border-slate-200 bg-slate-50/80 ps-10 pe-3 text-[12.5px] font-semibold dark:border-white/10 dark:bg-white/[0.04]"
            />
          </div>

          <Select
            value={statusFilter}
            onValueChange={(v) => {
              setStatusFilter(v);
              setPage(0);
            }}
          >
            <SelectTrigger className="h-10 w-auto min-w-32 rounded-xl text-[12.5px] font-semibold" aria-label={t("bizFilterAll")}>
              <SelectValue placeholder={t("bizFilterAll")} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t("bizFilterAll")}</SelectItem>
              {data.statuses.map((s) => (
                <SelectItem key={s.key} value={s.key}>
                  <span className="flex items-center gap-2">
                    <span className={cn("h-2 w-2 rounded-full", TONE_DOT[s.tone])} aria-hidden="true" />
                    {lang === "ar" ? s.ar : s.en}
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={sortKey} onValueChange={(v) => setSortKey(v as SortKey)}>
            <SelectTrigger className="h-10 w-auto min-w-32 rounded-xl text-[12.5px] font-semibold" aria-label={t("bizSortLabel")}>
              <CatIcon name="arrow-down-up" className="h-3.5 w-3.5 text-slate-400" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="default">{t("bizSortDefault")}</SelectItem>
              {data.valueKey ? <SelectItem value="moneyDesc">{t("bizSortMoneyDesc")}</SelectItem> : null}
              {data.valueKey ? <SelectItem value="moneyAsc">{t("bizSortMoneyAsc")}</SelectItem> : null}
              <SelectItem value="name">{t("bizSortName")}</SelectItem>
            </SelectContent>
          </Select>

          <Button
            variant="outline"
            onClick={exportCsv}
            className="h-10 gap-2 rounded-xl border-slate-200 bg-white px-3.5 text-[12px] font-bold text-slate-600 hover:border-slate-300 hover:bg-slate-50 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
          >
            <CatIcon name="download" className="h-4 w-4" />
            {t("bizExportBtn")}
          </Button>
        </div>

        {/* the premium table */}
        <div className="overflow-hidden rounded-2xl border border-slate-200/80 dark:border-white/10">
          <div className="max-h-[520px] overflow-auto nice-scroll">
            <table className="w-full min-w-[720px] border-collapse text-start">
              <thead className="sticky top-0 z-10">
                <tr className="bg-slate-100/95 backdrop-blur dark:bg-[#0b1220]/95">
                  {displayCols.map((col) => (
                    <th
                      key={col.key}
                      scope="col"
                      className={cn(
                        "whitespace-nowrap px-3.5 py-2.5 text-[10.5px] font-extrabold uppercase tracking-wide text-slate-500 dark:text-slate-400",
                        col.kind === "num" || col.kind === "money" ? "text-end" : "text-start"
                      )}
                    >
                      {lang === "ar" ? col.ar : col.en}
                    </th>
                  ))}
                  <th scope="col" className="w-px whitespace-nowrap px-2.5 py-2.5 text-end text-[10.5px] font-extrabold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                    {t("modRecActionsCol")}
                  </th>
                </tr>
              </thead>
              <tbody>
                {pageRows.length === 0 ? (
                  <tr>
                    <td colSpan={displayCols.length + 1} className="px-4 py-12 text-center">
                      {source === "mine" && records.length === 0 ? (
                        <>
                          <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl text-white shadow-lg" style={{ backgroundImage: grad(c1, c2) }}>
                            <CatIcon name="database" className="h-6 w-6" />
                          </span>
                          <p className="mt-3 font-display text-[15px] font-extrabold text-slate-700 dark:text-slate-200">{t("bizEmptyTitle")}</p>
                          <p className="mx-auto mt-1.5 max-w-md text-[12px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">{t("bizEmptyDesc")}</p>
                          <Button
                            onClick={() => {
                              setEditingRow(null);
                              setRecordDialogOpen(true);
                            }}
                            className="mx-auto mt-4 h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg hover:brightness-110"
                            style={{ backgroundImage: grad(c1, c2) }}
                          >
                            <CatIcon name="plus" className="h-4 w-4" />
                            {t("bizAddFirst")}
                          </Button>
                        </>
                      ) : (
                        <>
                          <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5">
                            <CatIcon name="search-x" className="h-6 w-6" />
                          </span>
                          <p className="mt-3 font-display text-[15px] font-extrabold text-slate-700 dark:text-slate-200">{t("bizEmptyNoMatch")}</p>
                          <p className="mx-auto mt-1.5 max-w-md text-[12px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">{t("bizEmptyNoMatchDesc")}</p>
                        </>
                      )}
                    </td>
                  </tr>
                ) : (
                  pageRows.map((row) => {
                    const st = data.statuses.find((s) => s.key === row.statusKey);
                    const statusIdx = data.cols.findIndex((c) => c.kind === "status");
                    return (
                      <tr
                        key={row.id}
                        className="border-t border-slate-100 transition-colors hover:bg-slate-50/80 dark:border-white/5 dark:hover:bg-white/[0.03]"
                      >
                        {displayCols.map((col) => {
                          /* map display col back to its value index in the row */
                          const vi = data.cols.indexOf(col);
                          const v = row.values[vi] ?? "";
                          if (col.kind === "status" || vi === statusIdx) {
                            return (
                              <td key={col.key} className="px-3.5 py-2.5">
                                {st ? (
                                  <span className={cn("inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1 text-[10.5px] font-extrabold", TONE_STYLE[st.tone])}>
                                    <span className={cn("h-1.5 w-1.5 rounded-full", TONE_DOT[st.tone])} aria-hidden="true" />
                                    {lang === "ar" ? st.ar : st.en}
                                  </span>
                                ) : (
                                  <span className="text-[11.5px] font-semibold text-slate-400">—</span>
                                )}
                              </td>
                            );
                          }
                          if (col.kind === "id") {
                            /* ROUND 156 — expenses rows that carry an
                               imageRef get a tiny 22×22 thumbnail in front
                               of the code chip (a glance at the receipt). */
                            const showReceiptThumb = activeModuleId === "expenses" && !!row.imageRef;
                            return (
                              <td key={col.key} className="px-3.5 py-2.5">
                                <span className="inline-flex items-center gap-2">
                                  {showReceiptThumb ? (
                                    // eslint-disable-next-line @next/next/no-img-element
                                    <img
                                      src={row.imageRef as string}
                                      alt=""
                                      className="h-7 w-7 shrink-0 rounded-md border border-slate-200 object-cover dark:border-white/10"
                                    />
                                  ) : null}
                                  <span dir={idDir} className="rounded-lg bg-slate-100 px-2 py-1 font-mono text-[11px] font-bold tabular-nums text-slate-600 dark:bg-white/10 dark:text-slate-300">
                                    {v ? fmtId(v, lang) : "—"}
                                  </span>
                                </span>
                              </td>
                            );
                          }
                          if (col.kind === "money") {
                            return (
                              <td key={col.key} dir={numDir(lang)} className="px-3.5 py-2.5 text-end text-[12px] font-extrabold tabular-nums text-slate-700 dark:text-slate-200">
                                {v ? fmtMoneyCell(Number(v) || 0, lang) : "—"}
                              </td>
                            );
                          }
                          if (col.kind === "num") {
                            /* products: the stock cell carries its health bar */
                            const isStock = col.key === "stock" && activeModuleId === "products";
                            const reorderIdx = data.cols.findIndex((c) => c.key === "reorder");
                            const reorder = isStock && reorderIdx >= 0 ? Number(row.values[reorderIdx] ?? 0) : 0;
                            const qty = Number(v || 0);
                            return (
                              <td key={col.key} className="px-3.5 py-2.5 text-end">
                                {isStock ? (
                                  <div className="inline-flex min-w-24 flex-col items-end gap-1">
                                    <span dir={numDir(lang)} className={cn("text-[12px] font-extrabold tabular-nums", qty <= 0 ? "text-rose-600 dark:text-rose-400" : qty <= reorder ? "text-amber-600 dark:text-amber-400" : "text-slate-700 dark:text-slate-200")}>
                                      {fmtNum(qty, lang)}
                                    </span>
                                    <div className="h-1 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/10">
                                      <div
                                        className={cn("h-full rounded-full", qty <= 0 ? "bg-rose-500" : qty <= reorder ? "bg-amber-500" : "bg-emerald-500")}
                                        style={{ width: `${Math.min(100, Math.max(6, (qty / Math.max(1, reorder * 4)) * 100))}%` }}
                                      />
                                    </div>
                                  </div>
                                ) : (
                                  <span dir={numDir(lang)} className="text-[12px] font-bold tabular-nums text-slate-600 dark:text-slate-300">{v ? fmtNum(Number(v) || 0, lang) : "—"}</span>
                                )}
                              </td>
                            );
                          }
                          return (
                            <td key={col.key} className="max-w-44 truncate px-3.5 py-2.5 text-[12px] font-semibold text-slate-600 dark:text-slate-300">
                              {v || "—"}
                            </td>
                          );
                        })}
                        {/* actions */}
                        <td className="whitespace-nowrap px-2.5 py-2.5 text-end">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => setDetailRow(row)}
                              aria-label={t("bizRowDetailTitle")}
                              title={t("bizRowDetailTitle")}
                              className="grid h-7 w-7 cursor-pointer place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-white/10 dark:hover:text-white"
                            >
                              <CatIcon name="eye" className="h-[13px] w-[13px]" />
                            </button>
                            <button
                              type="button"
                              onClick={() => buildPrintDoc(row)}
                              aria-label={t("bizPrintBtn")}
                              title={t("bizPrintBtn")}
                              className="grid h-7 w-7 cursor-pointer place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-white/10 dark:hover:text-white"
                            >
                              <CatIcon name="printer" className="h-[13px] w-[13px]" />
                            </button>
                            {source === "mine" ? (
                              <>
                                {/* ROUND 156 — the STATUS UPDATE popover: the
                                    trigger shows the row's current status as
                                    a colored dot (premium affordance); the
                                    popover lists every preset status as a
                                    pill (color dot + localized label). The
                                    current status gets a ring so the
                                    operator sees their position at a glance. */}
                                <Popover>
                                  <PopoverTrigger asChild>
                                    <button
                                      type="button"
                                      aria-label={t("bizStatusUpdateAria")}
                                      title={t("bizStatusUpdateBtn")}
                                      className={cn(
                                        "grid h-7 w-7 cursor-pointer place-items-center rounded-lg transition hover:bg-slate-100 dark:hover:bg-white/10",
                                        updateStatus.isPending && updateStatus.variables?.recordId === row.id
                                          ? "opacity-60"
                                          : ""
                                      )}
                                    >
                                      {st ? (
                                        <span
                                          className={cn("h-3.5 w-3.5 rounded-full", TONE_DOT[st.tone])}
                                          aria-hidden="true"
                                        />
                                      ) : (
                                        <CatIcon
                                          name="refresh-cw"
                                          className={cn("h-[13px] w-[13px] text-slate-400", updateStatus.isPending && updateStatus.variables?.recordId === row.id && "animate-spin")}
                                        />
                                      )}
                                    </button>
                                  </PopoverTrigger>
                                  <PopoverContent
                                    align="end"
                                    sideOffset={6}
                                    dir={lang === "ar" ? "rtl" : "ltr"}
                                    className="w-64 rounded-2xl border-slate-200 bg-white p-2 shadow-lift dark:border-white/10 dark:bg-[#0b1220]"
                                  >
                                    <p className="px-2 py-1.5 text-[10.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                                      {t("bizStatusPickTitle")}
                                    </p>
                                    <ul className="space-y-0.5">
                                      {data.statuses.map((opt) => {
                                        const active = opt.key === row.statusKey;
                                        return (
                                          <li key={opt.key}>
                                            <button
                                              type="button"
                                              disabled={updateStatus.isPending}
                                              onClick={() =>
                                                requireShift(() => {
                                                  if (active) return;
                                                  updateStatus.mutate({ recordId: row.id, statusKey: opt.key });
                                                })}
                                              className={cn(
                                                "flex w-full items-center gap-2.5 rounded-xl px-2.5 py-2 text-start text-[11.5px] font-extrabold transition",
                                                active
                                                  ? "bg-brand-500/10 text-brand-600 ring-1 ring-inset ring-brand-400/40 dark:text-brand-300 dark:ring-brand-500/30"
                                                  : "text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-white/10"
                                              )}
                                            >
                                              <span
                                                className={cn("h-2.5 w-2.5 shrink-0 rounded-full", TONE_DOT[opt.tone])}
                                                aria-hidden="true"
                                              />
                                              <span className="min-w-0 flex-1 truncate">
                                                {lang === "ar" ? opt.ar : opt.en}
                                              </span>
                                              {active ? (
                                                <CatIcon name="check" className="h-3.5 w-3.5 shrink-0" />
                                              ) : null}
                                            </button>
                                          </li>
                                        );
                                      })}
                                    </ul>
                                  </PopoverContent>
                                </Popover>
                                <button
                                  type="button"
                                  onClick={() =>
                                    requireShift(() => {
                                      setEditingRow(row);
                                      setRecordDialogOpen(true);
                                    })}
                                  aria-label={t("modRecEditAria")}
                                  title={t("modRecEditAria")}
                                  className="grid h-7 w-7 cursor-pointer place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-white/10 dark:hover:text-white"
                                >
                                  <CatIcon name="pencil" className="h-[13px] w-[13px]" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() =>
                                    requireShift(() => {
                                      setPendingDelete(row);
                                    })}
                                  aria-label={t("modRecDeleteAria")}
                                  title={t("modRecDeleteAria")}
                                  className="grid h-7 w-7 cursor-pointer place-items-center rounded-lg text-slate-400 transition hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-500/10 dark:hover:text-rose-400"
                                >
                                  <CatIcon name="trash-2" className="h-[13px] w-[13px]" />
                                </button>
                              </>
                            ) : null}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* pagination */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <p className="text-[11.5px] font-bold text-slate-400 dark:text-slate-500" dir="auto">
            {t("modPageOf", { page: fmtNum(safePage + 1, lang), total: fmtNum(pages, lang) })}
            {source === "mine" ? <span className="ms-2 text-emerald-500">· {t("bizLiveNote")}</span> : null}
          </p>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              disabled={safePage === 0}
              onClick={() => setPage(safePage - 1)}
              className="h-8 rounded-lg px-3 text-[11.5px] font-bold"
            >
              <CatIcon name="chevron-right" className="h-3.5 w-3.5 rtl:rotate-180" />
              {t("modPrevPage")}
            </Button>
            <Button
              variant="outline"
              disabled={safePage >= pages - 1}
              onClick={() => setPage(safePage + 1)}
              className="h-8 rounded-lg px-3 text-[11.5px] font-bold"
            >
              {t("modNextPage")}
              <CatIcon name="chevron-right" className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      </DashCard>

      {/* ---------------- the premium add/edit surfaces ---------------- */}
      {/* ROUND 132 — POS adds open the full TERMINAL (search + barcode +
          cart + locked metadata); stocktake adds open the COUNT ENGINE;
          every other module keeps the schema-driven record dialog. */}
      {recordDialogOpen && activeModuleId === "pos" && !editingRow ? (
        <PosTerminalDialog
          open={recordDialogOpen}
          onOpenChange={(o) => {
            setRecordDialogOpen(o);
            if (!o) setEditingRow(null);
          }}
          instance={instance}
          suggestedCode={suggestedCode}
          saving={saveRecord.isPending}
          onSave={(payload) => saveRecord.mutate(payload)}
        />
      ) : null}
      {recordDialogOpen && activeModuleId === "stocktake" && !editingRow ? (
        <StocktakeDialog
          open={recordDialogOpen}
          onOpenChange={(o) => {
            setRecordDialogOpen(o);
            if (!o) setEditingRow(null);
          }}
          instance={instance}
          suggestedCode={suggestedCode}
          saving={saveRecord.isPending}
          onSave={(payload) => saveRecord.mutate(payload)}
        />
      ) : null}
      {recordDialogOpen && (editingRow !== null || (activeModuleId !== "pos" && activeModuleId !== "stocktake")) ? (
        <BusinessRecordDialog
          open={recordDialogOpen}
          onOpenChange={(o) => {
            setRecordDialogOpen(o);
            if (!o) setEditingRow(null);
          }}
          sections={config.form}
          cols={data.cols}
          statuses={data.statuses}
          derive={config.derive}
          draft={{ record: editingRow, suggestedCode }}
          moduleName={moduleName}
          currency={instance.org.currency}
          c1={c1}
          c2={c2}
          saving={saveRecord.isPending}
          onSave={(payload) => saveRecord.mutate(payload)}
          instanceId={instance.id}
          /* ROUND 148 — the full tenant DTO drives the dynamic college +
           * guardian pickers (modules[] gates the query arming). */
          instance={instance}
          /* ROUND 141 (product extras) — the media picker + the variants
           * builder mount ONLY on the module that feeds the e-store
           * (pharmacy → products → menu → inventory, the storefront mapper's
           * exact priority). */
          productExtras={activeModuleId === storeProductModuleId(instance.modules)}
          /* ROUND 141 (㉕) — the structured 7-method payment manager on the
           * transaction modules (POS sales, purchases — supplier side). */
          paymentsEnabled={config.payments === true}
          /* ROUND 156 — the optional receipt image (expenses module). */
          receiptImage={activeModuleId === "expenses"}
        />
      ) : null}

      {/* ---------------- row-detail sheet (ROUND 133 — the PREMIUM per-module
          detail experience: students → the dedicated StudentProfileSheet
          (ROUND 155 — premium GPA ring + academic + guardian + attendance
          cards); residents → ResidentProfileSheet (ROUND 166 — the SAMS
          premium parity: occupancy + lease countdown + timeline strip);
          POS → thermal receipt; products → passport with the CSS
          barcode; everything else → the grouped passport). Real (سجلاتي)
          rows pass the FULL DTO (the customer link + shift stamp
          included); demo rows pass a synthetic DTO. ---------------- */}
      {activeModuleId === "students" ? (
        <StudentProfileSheet
          open={detailRow !== null}
          onOpenChange={(o) => {
            if (!o) setDetailRow(null);
          }}
          onEdit={() => {
            if (!detailRow) return;
            const realRow = records.find((r) => r.id === detailRow.id);
            if (!realRow) {
              toast.info(t("bizEditDemoRowHint"));
              return;
            }
            setEditingRow(realRow);
            setDetailRow(null);
            setRecordDialogOpen(true);
          }}
          record={(() => {
            if (!detailRow) return null;
            const real = records.find((r) => r.id === detailRow.id);
            if (real) return real;
            const synthetic: ModuleRecordDTO = {
              id: detailRow.id,
              moduleId: activeModuleId,
              values: detailRow.values,
              statusKey: detailRow.statusKey,
              imageRef: null,
              featured: false,
              salePrice: null,
              saleEndsAt: null,
              gallery: [],
              videos: [],
              storeVisible: true,
              variants: [],
              payments: [],
              shiftId: null,
              meta: null,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            };
            return synthetic;
          })()}
          cols={data.cols}
          statuses={data.statuses}
          moduleName={moduleName}
          onPrint={() => {
            if (detailRow) buildPrintDoc(detailRow);
            setDetailRow(null);
          }}
        />
      ) : activeModuleId === "teachers" ? (
        <TeacherProfileSheet
          open={detailRow !== null}
          onOpenChange={(o) => {
            if (!o) setDetailRow(null);
          }}
          onEdit={() => {
            if (!detailRow) return;
            const realRow = records.find((r) => r.id === detailRow.id);
            if (!realRow) {
              toast.info(t("bizEditDemoRowHint"));
              return;
            }
            setEditingRow(realRow);
            setDetailRow(null);
            setRecordDialogOpen(true);
          }}
          record={(() => {
            if (!detailRow) return null;
            const real = records.find((r) => r.id === detailRow.id);
            if (real) return real;
            const synthetic: ModuleRecordDTO = {
              id: detailRow.id,
              moduleId: activeModuleId,
              values: detailRow.values,
              statusKey: detailRow.statusKey,
              imageRef: null,
              featured: false,
              salePrice: null,
              saleEndsAt: null,
              gallery: [],
              videos: [],
              storeVisible: true,
              variants: [],
              payments: [],
              shiftId: null,
              meta: null,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            };
            return synthetic;
          })()}
          cols={data.cols}
          statuses={data.statuses}
          moduleName={moduleName}
          onPrint={() => {
            if (detailRow) buildPrintDoc(detailRow);
            setDetailRow(null);
          }}
        />
      ) : activeModuleId === "parents" ? (
        <ParentProfileSheet
          open={detailRow !== null}
          onOpenChange={(o) => {
            if (!o) setDetailRow(null);
          }}
          onEdit={() => {
            if (!detailRow) return;
            const realRow = records.find((r) => r.id === detailRow.id);
            if (!realRow) {
              toast.info(t("bizEditDemoRowHint"));
              return;
            }
            setEditingRow(realRow);
            setDetailRow(null);
            setRecordDialogOpen(true);
          }}
          record={(() => {
            if (!detailRow) return null;
            const real = records.find((r) => r.id === detailRow.id);
            if (real) return real;
            const synthetic: ModuleRecordDTO = {
              id: detailRow.id,
              moduleId: activeModuleId,
              values: detailRow.values,
              statusKey: detailRow.statusKey,
              imageRef: null,
              featured: false,
              salePrice: null,
              saleEndsAt: null,
              gallery: [],
              videos: [],
              storeVisible: true,
              variants: [],
              payments: [],
              shiftId: null,
              meta: null,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            };
            return synthetic;
          })()}
          cols={data.cols}
          statuses={data.statuses}
          moduleName={moduleName}
          onPrint={() => {
            if (detailRow) buildPrintDoc(detailRow);
            setDetailRow(null);
          }}
        />
      ) : activeModuleId === "certificates" ? (
        <CertificateProfileSheet
          open={detailRow !== null}
          onOpenChange={(o) => {
            if (!o) setDetailRow(null);
          }}
          onEdit={() => {
            if (!detailRow) return;
            const realRow = records.find((r) => r.id === detailRow.id);
            if (!realRow) {
              toast.info(t("bizEditDemoRowHint"));
              return;
            }
            setEditingRow(realRow);
            setDetailRow(null);
            setRecordDialogOpen(true);
          }}
          record={(() => {
            if (!detailRow) return null;
            const real = records.find((r) => r.id === detailRow.id);
            if (real) return real;
            const synthetic: ModuleRecordDTO = {
              id: detailRow.id,
              moduleId: activeModuleId,
              values: detailRow.values,
              statusKey: detailRow.statusKey,
              imageRef: null,
              featured: false,
              salePrice: null,
              saleEndsAt: null,
              gallery: [],
              videos: [],
              storeVisible: true,
              variants: [],
              payments: [],
              shiftId: null,
              meta: null,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            };
            return synthetic;
          })()}
          cols={data.cols}
          statuses={data.statuses}
          moduleName={moduleName}
          orgName={instance.org.name}
          onPrint={() => {
            if (detailRow) buildPrintDoc(detailRow);
            setDetailRow(null);
          }}
        />
      ) : activeModuleId === "staff" ? (
        <StaffProfileSheet
          open={detailRow !== null}
          onOpenChange={(o) => {
            if (!o) setDetailRow(null);
          }}
          onEdit={() => {
            if (!detailRow) return;
            const realRow = records.find((r) => r.id === detailRow.id);
            if (!realRow) {
              toast.info(t("bizEditDemoRowHint"));
              return;
            }
            setEditingRow(realRow);
            setDetailRow(null);
            setRecordDialogOpen(true);
          }}
          record={(() => {
            if (!detailRow) return null;
            const real = records.find((r) => r.id === detailRow.id);
            if (real) return real;
            const synthetic: ModuleRecordDTO = {
              id: detailRow.id,
              moduleId: activeModuleId,
              values: detailRow.values,
              statusKey: detailRow.statusKey,
              imageRef: null,
              featured: false,
              salePrice: null,
              saleEndsAt: null,
              gallery: [],
              videos: [],
              storeVisible: true,
              variants: [],
              payments: [],
              shiftId: null,
              meta: null,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            };
            return synthetic;
          })()}
          cols={data.cols}
          statuses={data.statuses}
          moduleName={moduleName}
          currency={instance.org.currency}
          onPrint={() => {
            if (detailRow) buildPrintDoc(detailRow);
            setDetailRow(null);
          }}
        />
      ) : activeModuleId === "residents" ? (
        /* ROUND 166 — the SAMS residents module (now labeled الطلاب/Students
           via MODULE_LABEL_OVERRIDES) gets the DEDICATED premium resident
           profile sheet — occupancy + lease countdown + lease timeline —
           exactly parallel to the education family's dedicated sheets. */
        <ResidentProfileSheet
          open={detailRow !== null}
          onOpenChange={(o) => {
            if (!o) setDetailRow(null);
          }}
          onEdit={() => {
            if (!detailRow) return;
            const realRow = records.find((r) => r.id === detailRow.id);
            if (!realRow) {
              toast.info(t("bizEditDemoRowHint"));
              return;
            }
            setEditingRow(realRow);
            setDetailRow(null);
            setRecordDialogOpen(true);
          }}
          record={(() => {
            if (!detailRow) return null;
            const real = records.find((r) => r.id === detailRow.id);
            if (real) return real;
            const synthetic: ModuleRecordDTO = {
              id: detailRow.id,
              moduleId: activeModuleId,
              values: detailRow.values,
              statusKey: detailRow.statusKey,
              imageRef: null,
              featured: false,
              salePrice: null,
              saleEndsAt: null,
              gallery: [],
              videos: [],
              storeVisible: true,
              variants: [],
              payments: [],
              shiftId: null,
              meta: null,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            };
            return synthetic;
          })()}
          cols={data.cols}
          statuses={data.statuses}
          moduleName={moduleName}
          currency={instance.org.currency}
          onPrint={() => {
            if (detailRow) buildPrintDoc(detailRow);
            setDetailRow(null);
          }}
        />
      ) : specializedDetail ? (
        /* ROUND 164 — pos → the thermal-receipt sheet; products → the
           passport; the fourteen medical modules → their blueprints. These
           specialized views keep the RecordDetailSheet home. */
        <RecordDetailSheet
          open={detailRow !== null}
          onOpenChange={closeDetail}
          onEdit={handleDetailEdit}
          moduleId={activeModuleId}
          record={detailRecordDto}
          cols={data.cols}
          statuses={data.statuses}
          moduleName={moduleName}
          currency={instance.org.currency}
          orgName={instance.org.name}
          instanceId={instance.id}
          onPrint={handleDetailPrint}
        />
      ) : (
        /* ROUND 164 — everything else (customers, returns, promotions,
           stocktake, pricing, branches, purchases, buildings, rooms,
           leases, maintenance, payments, guards, payroll,
           training, licenses, equipment, attendance, assets, jobs,
           tracking, warranty, commissions, …) opens the PREMIUM detail
           drawer — the family-tinted side inspector. ROUND 166 removed
           residents from this list: the SAMS module now owns the dedicated
           ResidentProfileSheet above. */
        <RecordDetailDrawer
          open={detailRow !== null}
          onOpenChange={closeDetail}
          onEdit={handleDetailEdit}
          moduleId={activeModuleId}
          record={detailRecordDto}
          cols={data.cols}
          statuses={data.statuses}
          moduleName={moduleName}
          currency={instance.org.currency}
          orgName={instance.org.name}
          instanceId={instance.id}
          onPrint={handleDetailPrint}
        />
      )}

      {/* ---------------- delete confirm ---------------- */}
      <AlertDialog open={pendingDelete !== null} onOpenChange={(o) => !o && setPendingDelete(null)}>
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display text-[15px] font-extrabold text-slate-900 dark:text-white">{t("bizDeleteTitle")}</AlertDialogTitle>
            <AlertDialogDescription className="text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("bizDeleteMsg", { name: pendingDelete?.values[0] ?? "—" })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="gap-2">
            <AlertDialogCancel className="h-10 rounded-xl px-4 text-[12.5px] font-bold" disabled={removeRecord.isPending}>
              {t("modRecCancelBtn")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => pendingDelete && removeRecord.mutate(pendingDelete.id)}
              disabled={removeRecord.isPending}
              className="h-10 gap-2 rounded-xl bg-rose-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/20 hover:bg-rose-700"
            >
              {removeRecord.isPending ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : <CatIcon name="trash-2" className="h-4 w-4" />}
              {t("modRecDeleteBtn")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ---------------- print preview (letterhead parity with the
          generic workspace: org logo + signature + stamp).
          ROUND 164 — the POS module prints through the dedicated 80mm
          thermal-receipt preview instead of the shared A4 document. ---------------- */}
      {activeModuleId === "pos" ? (
        <PosReceiptPrintDialog
          doc={printDoc}
          instance={instance}
          logoUrl={siteQuery.data?.content.logoUrl ?? ""}
          open={printDoc !== null}
          onOpenChange={(o) => !o && setPrintDoc(null)}
        />
      ) : (
        <RecordPrintDialog
          doc={printDoc}
          instance={instance}
          logoUrl={siteQuery.data?.content.logoUrl ?? ""}
          signatureUrl={siteQuery.data?.content.signatureUrl ?? ""}
          stampUrl={siteQuery.data?.content.stampUrl ?? ""}
          signatureScale={siteQuery.data?.content.signatureScale ?? 1}
          stampScale={siteQuery.data?.content.stampScale ?? 1}
          open={printDoc !== null}
          onOpenChange={(o) => !o && setPrintDoc(null)}
        />
      )}
    </div>
  );
}
