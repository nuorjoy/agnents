/**
 * Ashrilogic — BUSINESS-SUITE configuration (ROUND 131).
 *
 * The declarative brain behind the premium commerce workspaces. Every
 * module the owner directed (نقاط البيع، المنتجات، العملاء، الموردون،
 * المشتريات، العروض، المرتجعات، الولاء، الفروع، التقارير، الجرد) maps to
 * ONE config: which KPI cards render (computed live from the dataset),
 * which column drives the analytics breakdown, which columns the table
 * surfaces (the rest stay in the row-detail sheet), and the premium
 * add-record form schema (field types per preset column — the products
 * form is the flagship: sectioned, margin-computing, stock-health-aware).
 *
 * The configs are pure data + pure functions — no React, no hooks — so
 * they stay trivially testable and tree-shakeable.
 */
import { modulePreset, type ColDef, type ModuleRow, type ModuleDataset, type StatusDef } from "@/lib/module-data";
import { t, type I18nKey } from "@/lib/i18n";
import type { Lang } from "@/lib/types";
import { fmtMoneyCell } from "@/lib/utils";

/* ------------------------------------------------------------------ */
/* types                                                                */
/* ------------------------------------------------------------------ */

/** A KPI card definition — a pure function over the dataset.
 * ROUND 132: labelKey (typed i18n) OR inline labelAr/labelEn — the domain
 * configs for the ~90 new modules use inline labels so the dictionaries
 * don't explode; the resolver is bizKpiLabel(). */
export interface BizKpiDef {
  labelKey?: I18nKey;
  labelAr?: string;
  labelEn?: string;
  icon: string;
  c1: string;
  c2: string;
  /** returns { value, sub?, tone? } — tone colors the delta chip. */
  compute: (ctx: BizCtx) => { value: string; sub?: string; tone?: "up" | "down" | "flat" };
}

/** The aggregation context handed to KPI/insight computations. */
export interface BizCtx {
  data: ModuleDataset;
  lang: Lang;
  currency: string;
  rows: ModuleRow[];
  cols: ColDef[];
  statuses: StatusDef[];
}

/** Add-form field types (rendered by business-record-dialog.tsx). */
export type BizFieldType = "text" | "number" | "money" | "date" | "select" | "tel";

export interface BizFieldDef {
  colKey: string;
  type: BizFieldType;
  required?: boolean;
  /** non-status selects (categories, methods, types…) */
  options?: { ar: string; en: string }[];
  dir?: "ltr" | "rtl" | "auto";
  span?: 1 | 2;
  /** hint i18n key rendered under the field (or inline hintAr/hintEn) */
  hintKey?: I18nKey;
  hintAr?: string;
  hintEn?: string;
  /** money fields show the workspace currency chip */
  money?: boolean;
  min?: number;
  step?: string;
  /** ROUND 132 — the owner's immutability directives:
   *  - locked: the field renders read-only with a lock chip (IDs, derived
   *    cells, anything the operator must never hand-edit)
   *  - autoStamp: auto-filled at open with the CURRENT date/time (POS
   *    transactions, stocktake sessions…) — always locked too. */
  locked?: boolean;
  autoStamp?: "date" | "time";
  /** ROUND 132 — barcode-aware fields get the scan + generate affordances */
  barcode?: boolean;
}

export interface BizFormSection {
  titleKey?: I18nKey;
  titleAr?: string;
  titleEn?: string;
  icon: string;
  fields: BizFieldDef[];
}

export interface BizAnalyticsDef {
  /** the column the breakdown groups by */
  breakdownCol: string;
  /** breakdown aggregation */
  breakdownMode: "money" | "count";
  /** top-list ranking */
  topMode: "money" | "count";
  topCount: number;
  /** what the top list ranks (label column + money/count column) */
  topLabelCol: string;
}

export interface BizModuleConfig {
  moduleId: string;
  analytics: BizAnalyticsDef;
  /** the table shows these preset columns (others live in the detail sheet) */
  displayCols: string[];
  kpis: BizKpiDef[];
  form: BizFormSection[];
  /** optional live-derivation: recompute derived cells when the form edits
   *  their inputs (products: margin from cost/price; status from stock) */
  derive?: (values: Record<string, string>) => Record<string, string>;
  /** ROUND 141 (directive ㉕) — the transaction modules (POS sales,
   *  purchases — the supplier side) ride the structured 7-method payment
   *  manager in the record dialog; the form's legacy method field is
   *  RETIRED there (the primary ledger label lands in the method cell). */
  payments?: boolean;
}

/* ------------------------------------------------------------------ */
/* aggregation helpers (pure)                                           */
/* ------------------------------------------------------------------ */

const num = (v: string): number => {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
};

/** column index lookup. */
export function colIndex(cols: ColDef[], key: string): number {
  return cols.findIndex((c) => c.key === key);
}

/** Σ of a numeric column over rows. */
export function sumCol(rows: ModuleRow[], cols: ColDef[], key: string): number {
  const i = colIndex(cols, key);
  if (i < 0) return 0;
  return rows.reduce((s, r) => s + num(r.values[i] ?? "0"), 0);
}

/** avg of a numeric column (0 when empty). */
export function avgCol(rows: ModuleRow[], cols: ColDef[], key: string): number {
  if (rows.length === 0) return 0;
  return sumCol(rows, cols, key) / rows.length;
}

/** rows whose status key is in the set. */
export function rowsWithStatus(rows: ModuleRow[], statuses: string[]): ModuleRow[] {
  return rows.filter((r) => statuses.includes(r.statusKey));
}

/** max numeric value row (by column) — null when no rows. */
export function topRowBy(rows: ModuleRow[], cols: ColDef[], key: string): ModuleRow | null {
  const i = colIndex(cols, key);
  if (i < 0 || rows.length === 0) return null;
  return rows.reduce((best, r) => (num(r.values[i]) > num(best.values[i]) ? r : best), rows[0]);
}

/** value of a row cell by column key. */
export function cellOf(row: ModuleRow, cols: ColDef[], key: string): string {
  const i = colIndex(cols, key);
  return i >= 0 ? row.values[i] ?? "" : "";
}

/** count rows matching a plain-text column value. */
export function countByValue(rows: ModuleRow[], cols: ColDef[], key: string): Map<string, number> {
  const i = colIndex(cols, key);
  const map = new Map<string, number>();
  if (i < 0) return map;
  for (const r of rows) {
    const v = (r.values[i] ?? "").trim() || "—";
    map.set(v, (map.get(v) ?? 0) + 1);
  }
  return map;
}

/** Σ money grouped by a text column. */
export function moneyByValue(rows: ModuleRow[], cols: ColDef[], groupKey: string, moneyKey: string): Map<string, number> {
  const g = colIndex(cols, groupKey);
  const m = colIndex(cols, moneyKey);
  const map = new Map<string, number>();
  if (g < 0 || m < 0) return map;
  for (const r of rows) {
    const v = (r.values[g] ?? "").trim() || "—";
    map.set(v, (map.get(v) ?? 0) + num(r.values[m]));
  }
  return map;
}

const pct = (part: number, total: number): number => (total > 0 ? Math.round((part / total) * 1000) / 10 : 0);

/** formats a number as locale-aware with optional currency suffix.
 * ROUND 133 — unified onto the shared Arabic-Indic policy (fmtMoneyCell:
 * Arabic-Indic digits + Arabic grouping for ar, native for every other
 * locale, currency suffix lands visually on the left in RTL). */
export function fmtBiz(n: number, lang: Lang, currency?: string): string {
  return fmtMoneyCell(n, lang, currency);
}

/* ------------------------------------------------------------------ */
/* the per-module KPI helper                                            */
/* ------------------------------------------------------------------ */

function kpi(
  label: I18nKey | { ar: string; en: string },
  icon: string,
  c1: string,
  c2: string,
  compute: BizKpiDef["compute"]
): BizKpiDef {
  if (typeof label === "string") return { labelKey: label, icon, c1, c2, compute };
  return { labelAr: label.ar, labelEn: label.en, icon, c1, c2, compute };
}

/** resolve a KPI label — typed i18n key first, then the inline pair. */
export function bizKpiLabel(k: BizKpiDef, lang: Lang, tFn: (key: I18nKey) => string): string {
  if (k.labelKey) return tFn(k.labelKey);
  if (lang === "ar") return k.labelAr ?? k.labelEn ?? "";
  return k.labelEn ?? k.labelAr ?? "";
}

/** resolve a section title — typed i18n key first, then the inline pair. */
export function bizSectionTitle(s: BizFormSection, lang: Lang, tFn: (key: I18nKey) => string): string {
  if (s.titleKey) return tFn(s.titleKey);
  if (lang === "ar") return s.titleAr ?? s.titleEn ?? "";
  return s.titleEn ?? s.titleAr ?? "";
}

/** resolve a field hint — typed i18n key first, then the inline pair. */
export function bizFieldHint(f: BizFieldDef, lang: Lang, tFn: (key: I18nKey) => string): string | null {
  if (f.hintKey) return tFn(f.hintKey);
  if (f.hintAr || f.hintEn) return lang === "ar" ? (f.hintAr ?? f.hintEn ?? "") : (f.hintEn ?? f.hintAr ?? "");
  return null;
}

const C_EMERALD = ["#10b981", "#047857"] as const;
const C_AMBER = ["#f59e0b", "#d97706"] as const;
const C_SKY = ["#06b6d4", "#0891b2"] as const;
const C_VIOLET = ["#8b5cf6", "#6d28d9"] as const;
const C_ROSE = ["#f43f5e", "#be185d"] as const;
const C_SLATE = ["#64748b", "#334155"] as const;

/* ------------------------------------------------------------------ */
/* shared form option pools                                             */
/* ------------------------------------------------------------------ */
/* ROUND 141 (㉕) — the legacy POS_PAY_OPTIONS pool was RETIRED: the POS
   method cell is now owned by the structured 7-method payment manager
   (PAYMENT_METHOD_META in src/lib/payment-methods.ts — نقدي · بطاقة ·
   تحويل بنكي · محفظة إلكترونية · مختلط · جزئي · آجل). */

const PROD_CAT_OPTIONS = [
  { ar: "بقالة", en: "Grocery" },
  { ar: "مشروبات", en: "Beverages" },
  { ar: "عناية شخصية", en: "Personal care" },
  { ar: "منظفات", en: "Cleaning" },
  { ar: "ألبان ومبردات", en: "Dairy & chilled" },
  { ar: "مخبوزات", en: "Bakery" },
  { ar: "وجبات خفيفة", en: "Snacks" },
  { ar: "منزل ومطبخ", en: "Home & kitchen" },
];

/** the flagship products derivation: margin from cost/price, status from
 *  stock vs reorder — the form recomputes these LIVE while typing. */
function productsDerive(v: Record<string, string>): Record<string, string> {
  const out: Record<string, string> = {};
  const cost = Number(v.cost);
  const price = Number(v.price);
  if (v.cost !== "" && v.price !== "" && Number.isFinite(cost) && Number.isFinite(price) && price > 0) {
    out.margin = (((price - cost) / price) * 100).toFixed(1);
  }
  const stock = Number(v.stock);
  const reorder = Number(v.reorder);
  if (v.stock !== "" && v.reorder !== undefined && Number.isFinite(stock) && Number.isFinite(reorder)) {
    out.status = stock <= 0 ? "out" : stock <= reorder ? "low" : v.status === "archived" ? "archived" : "active";
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* the module configs                                                   */
/* ------------------------------------------------------------------ */

export const BUSINESS_MODULE_CONFIGS: Record<string, BizModuleConfig> = {
  pos: {
    moduleId: "pos",
    analytics: { breakdownCol: "method", breakdownMode: "money", topMode: "count", topCount: 5, topLabelCol: "cashier" },
    displayCols: ["code", "cashier", "branch", "time", "items", "discount", "total", "method", "status"],
    /* ROUND 141 (㉕) — the structured 7-method payment manager rides the
     * record dialog; the legacy method select field is retired. */
    payments: true,
    kpis: [
      kpi("bizKpiTxns", "calculator", C_SKY[0], C_SKY[1], (c) => ({ value: fmtBiz(c.rows.length, c.lang) })),
      kpi("bizKpiSalesTotal", "wallet", C_EMERALD[0], C_EMERALD[1], (c) => {
        const completed = rowsWithStatus(c.rows, ["completed"]);
        return {
          value: fmtBiz(sumCol(completed, c.cols, "total"), c.lang, c.currency),
          sub: t(c.lang, "bizSubPct", { pct: pct(completed.length, c.rows.length).toString() }),
        };
      }),
      kpi("bizKpiAvgBasket", "shopping-basket", C_VIOLET[0], C_VIOLET[1], (c) => {
        const completed = rowsWithStatus(c.rows, ["completed"]);
        return { value: fmtBiz(avgCol(completed, c.cols, "total"), c.lang, c.currency) };
      }),
      kpi("bizKpiDiscounts", "tags", C_AMBER[0], C_AMBER[1], (c) => ({ value: fmtBiz(sumCol(c.rows, c.cols, "discount"), c.lang, c.currency) })),
      kpi("bizKpiRefundRate", "rotate-ccw", C_ROSE[0], C_ROSE[1], (c) => {
        const refunded = rowsWithStatus(c.rows, ["refunded"]).length;
        return { value: `${pct(refunded, c.rows.length)}%`, tone: refunded / Math.max(1, c.rows.length) > 0.1 ? "down" : "flat" };
      }),
    ],
    form: [
      { titleKey: "bizSecBasics", icon: "calculator", fields: [
        { colKey: "code", type: "text", required: true, dir: "ltr" },
        /* ROUND 132 — the owner's directive: رقم العملية/الكاشير/الفرع/
         * التاريخ/الوقت are system-stamped and STRICTLY non-editable. */
        { colKey: "cashier", type: "text", required: true, locked: true },
        { colKey: "branch", type: "text", locked: true },
        { colKey: "date", type: "date", autoStamp: "date" },
        { colKey: "time", type: "text", dir: "ltr", autoStamp: "time" },
        { colKey: "items", type: "number", min: 0 },
      ] },
      { titleKey: "bizSecPricing", icon: "wallet", fields: [
        { colKey: "discount", type: "money", money: true, min: 0 },
        { colKey: "total", type: "money", money: true, required: true, min: 0 },
        /* ROUND 141 (㉕) — the method field is owned by the structured
           payment manager (payments: true above). */
      ] },
    ],
  },

  products: {
    moduleId: "products",
    analytics: { breakdownCol: "category", breakdownMode: "money", topMode: "money", topCount: 5, topLabelCol: "name" },
    displayCols: ["name", "sku", "barcode", "category", "price", "margin", "stock", "status"],
    kpis: [
      kpi("bizKpiProducts", "package", C_SKY[0], C_SKY[1], (c) => ({ value: fmtBiz(c.rows.length, c.lang) })),
      kpi("bizKpiAvgPrice", "coins", C_VIOLET[0], C_VIOLET[1], (c) => ({ value: fmtBiz(avgCol(c.rows, c.cols, "price"), c.lang, c.currency) })),
      kpi("bizKpiAvgMargin", "trending-up", C_EMERALD[0], C_EMERALD[1], (c) => {
        const m = avgCol(c.rows, c.cols, "margin");
        return { value: `${m.toFixed(1)}%`, tone: m >= 25 ? "up" : m >= 15 ? "flat" : "down" };
      }),
      kpi("bizKpiLowStock", "triangle-alert", C_AMBER[0], C_AMBER[1], (c) => {
        const low = rowsWithStatus(c.rows, ["low", "out"]).length;
        return { value: fmtBiz(low, c.lang), sub: t(c.lang, "bizSubPct", { pct: pct(low, c.rows.length).toString() }), tone: low > 0 ? "down" : "flat" };
      }),
      kpi("bizKpiStockValue", "warehouse", C_SLATE[0], C_SLATE[1], (c) => {
        /* Σ stock × cost — the inventory valuation at cost price */
        const ci = colIndex(c.cols, "cost");
        const si = colIndex(c.cols, "stock");
        const value = ci >= 0 && si >= 0 ? c.rows.reduce((s, r) => s + num(r.values[si]) * num(r.values[ci]), 0) : 0;
        return { value: fmtBiz(value, c.lang, c.currency) };
      }),
    ],
    form: [
      { titleKey: "bizSecBasics", icon: "package", fields: [
        { colKey: "name", type: "text", required: true, span: 2 },
        { colKey: "nameEn", type: "text", dir: "ltr", span: 2, hintKey: "bizEnNameHint" },
        { colKey: "sku", type: "text", required: true, dir: "ltr" },
        { colKey: "barcode", type: "text", dir: "ltr", hintKey: "bizBarcodeHint", barcode: true },
        { colKey: "category", type: "select", options: PROD_CAT_OPTIONS },
      ] },
      { titleKey: "bizSecPricing", icon: "coins", fields: [
        { colKey: "cost", type: "money", money: true, required: true, min: 0, hintKey: "bizCostHint" },
        { colKey: "price", type: "money", money: true, required: true, min: 0 },
        { colKey: "vat", type: "number", min: 0, step: "0.5", hintKey: "bizVatHint" },
        { colKey: "margin", type: "text", dir: "ltr" },
      ] },
      { titleKey: "bizSecStock", icon: "warehouse", fields: [
        { colKey: "stock", type: "number", required: true, min: 0 },
        { colKey: "reorder", type: "number", min: 0 },
        { colKey: "sold", type: "number", min: 0 },
        { colKey: "status", type: "select" },
      ] },
    ],
    derive: productsDerive,
  },

  customers: {
    moduleId: "customers",
    analytics: { breakdownCol: "status", breakdownMode: "money", topMode: "money", topCount: 5, topLabelCol: "name" },
    displayCols: ["name", "phone", "city", "orders", "spent", "points", "visits", "last", "status"],
    kpis: [
      kpi("bizKpiCustomers", "users", C_SKY[0], C_SKY[1], (c) => ({ value: fmtBiz(c.rows.length, c.lang) })),
      kpi("bizKpiActiveRate", "activity", C_EMERALD[0], C_EMERALD[1], (c) => {
        const active = rowsWithStatus(c.rows, ["active", "gold"]).length;
        return { value: `${pct(active, c.rows.length)}%`, tone: "up" };
      }),
      kpi("bizKpiAvgSpend", "wallet", C_VIOLET[0], C_VIOLET[1], (c) => ({ value: fmtBiz(avgCol(c.rows, c.cols, "spent"), c.lang, c.currency) })),
      kpi("bizKpiPoints", "star", C_AMBER[0], C_AMBER[1], (c) => ({ value: fmtBiz(sumCol(c.rows, c.cols, "points"), c.lang) })),
      kpi("bizKpiGoldShare", "award", C_ROSE[0], C_ROSE[1], (c) => {
        const gold = rowsWithStatus(c.rows, ["gold"]).length;
        return { value: `${pct(gold, c.rows.length)}%`, sub: t(c.lang, "bizSubCount", { count: gold.toString() }) };
      }),
    ],
    form: [
      { titleKey: "bizSecBasics", icon: "users", fields: [
        { colKey: "name", type: "text", required: true, span: 2 },
        { colKey: "phone", type: "tel", dir: "ltr" },
        { colKey: "city", type: "text" },
      ] },
      { titleKey: "bizSecExtra", icon: "activity", fields: [
        { colKey: "orders", type: "number", min: 0 },
        { colKey: "spent", type: "money", money: true, min: 0 },
        { colKey: "points", type: "number", min: 0 },
        { colKey: "visits", type: "number", min: 0 },
        { colKey: "last", type: "date" },
      ] },
    ],
  },

  suppliers: {
    moduleId: "suppliers",
    analytics: { breakdownCol: "spec", breakdownMode: "money", topMode: "money", topCount: 5, topLabelCol: "name" },
    displayCols: ["name", "spec", "contact", "lead", "rating", "lastSupply", "due", "status"],
    kpis: [
      kpi("bizKpiSuppliers", "truck", C_SKY[0], C_SKY[1], (c) => ({ value: fmtBiz(c.rows.length, c.lang) })),
      kpi("bizKpiDue", "scale", C_ROSE[0], C_ROSE[1], (c) => ({ value: fmtBiz(sumCol(c.rows, c.cols, "due"), c.lang, c.currency) })),
      kpi("bizKpiAvgLead", "clock", C_AMBER[0], C_AMBER[1], (c) => ({
        value: `${avgCol(c.rows, c.cols, "lead").toFixed(1)} ${c.lang === "ar" ? "يوم" : "days"}`,
      })),
      kpi("bizKpiOnTime", "badge-check", C_EMERALD[0], C_EMERALD[1], (c) => {
        const v = avgCol(c.rows, c.cols, "rating");
        return { value: `${v.toFixed(1)}%`, tone: v >= 90 ? "up" : v >= 80 ? "flat" : "down" };
      }),
      kpi("bizKpiActiveSuppliers", "handshake", C_VIOLET[0], C_VIOLET[1], (c) => {
        const active = rowsWithStatus(c.rows, ["active"]).length;
        return { value: fmtBiz(active, c.lang), sub: t(c.lang, "bizSubPct", { pct: pct(active, c.rows.length).toString() }) };
      }),
    ],
    form: [
      { titleKey: "bizSecBasics", icon: "truck", fields: [
        { colKey: "name", type: "text", required: true, span: 2 },
        { colKey: "spec", type: "text" },
        { colKey: "contact", type: "text" },
        { colKey: "phone", type: "tel", dir: "ltr" },
      ] },
      { titleKey: "bizSecExtra", icon: "clock", fields: [
        { colKey: "lead", type: "number", min: 0 },
        { colKey: "rating", type: "number", min: 0 },
        { colKey: "lastSupply", type: "date" },
        { colKey: "due", type: "money", money: true, min: 0 },
      ] },
    ],
  },

  purchases: {
    moduleId: "purchases",
    analytics: { breakdownCol: "method", breakdownMode: "money", topMode: "money", topCount: 5, topLabelCol: "supplier" },
    displayCols: ["code", "supplier", "category", "items", "total", "method", "expected", "status"],
    /* ROUND 141 (㉕) — the SUPPLIER side rides the same structured 7-method
     * payment manager (the owner's directive named it explicitly). */
    payments: true,
    kpis: [
      kpi("bizKpiPOs", "shopping-cart", C_SKY[0], C_SKY[1], (c) => ({ value: fmtBiz(c.rows.length, c.lang) })),
      kpi("bizKpiPOValue", "coins", C_EMERALD[0], C_EMERALD[1], (c) => ({ value: fmtBiz(sumCol(c.rows, c.cols, "total"), c.lang, c.currency) })),
      kpi("bizKpiPendingPO", "clock", C_AMBER[0], C_AMBER[1], (c) => {
        const pending = rowsWithStatus(c.rows, ["pending", "partial"]).length;
        return { value: fmtBiz(pending, c.lang) };
      }),
      kpi("bizKpiAvgPO", "scale", C_VIOLET[0], C_VIOLET[1], (c) => ({ value: fmtBiz(avgCol(c.rows, c.cols, "total"), c.lang, c.currency) })),
    ],
    form: [
      { titleKey: "bizSecBasics", icon: "shopping-cart", fields: [
        { colKey: "code", type: "text", required: true, dir: "ltr" },
        { colKey: "supplier", type: "text", required: true },
        { colKey: "category", type: "text" },
        { colKey: "items", type: "number", min: 0 },
      ] },
      { titleKey: "bizSecPricing", icon: "wallet", fields: [
        { colKey: "total", type: "money", money: true, required: true, min: 0 },
        /* ROUND 141 (㉕) — the method field is owned by the structured
           payment manager (payments: true above). */
        { colKey: "expected", type: "date" },
      ] },
    ],
  },

  promotions: {
    moduleId: "promotions",
    analytics: { breakdownCol: "type", breakdownMode: "count", topMode: "count", topCount: 5, topLabelCol: "name" },
    displayCols: ["code", "name", "type", "value", "scope", "usage", "cap", "ends", "status"],
    kpis: [
      kpi("bizKpiPromos", "tags", C_SKY[0], C_SKY[1], (c) => ({ value: fmtBiz(c.rows.length, c.lang) })),
      kpi("bizKpiActivePromos", "zap", C_EMERALD[0], C_EMERALD[1], (c) => {
        const active = rowsWithStatus(c.rows, ["active"]).length;
        return { value: fmtBiz(active, c.lang), tone: "up" };
      }),
      kpi("bizKpiRedemptions", "ticket", C_VIOLET[0], C_VIOLET[1], (c) => ({ value: fmtBiz(sumCol(c.rows, c.cols, "usage"), c.lang) })),
      kpi("bizKpiAvgUsage", "percent", C_AMBER[0], C_AMBER[1], (c) => {
        const usage = sumCol(c.rows, c.cols, "usage");
        const cap = sumCol(c.rows, c.cols, "cap");
        return { value: `${pct(usage, cap)}%` };
      }),
      kpi("bizKpiCapFill", "target", C_ROSE[0], C_ROSE[1], (c) => {
        const ai = colIndex(c.cols, "usage");
        const ci = colIndex(c.cols, "cap");
        const top = [...c.rows].sort(
          (a, b) => num(b.values[ai]) / Math.max(1, num(b.values[ci])) - num(a.values[ai]) / Math.max(1, num(a.values[ci]))
        )[0];
        return {
          value: top ? `${pct(num(cellOf(top, c.cols, "usage")), Math.max(1, num(cellOf(top, c.cols, "cap"))))}%` : "—",
          sub: top ? cellOf(top, c.cols, "name").slice(0, 28) : undefined,
        };
      }),
    ],
    form: [
      { titleKey: "bizSecBasics", icon: "tags", fields: [
        { colKey: "code", type: "text", required: true, dir: "ltr" },
        { colKey: "name", type: "text", required: true, span: 2 },
        { colKey: "type", type: "text" },
        { colKey: "value", type: "number", min: 0, step: "0.01" },
        { colKey: "scope", type: "text" },
      ] },
      { titleKey: "bizSecExtra", icon: "target", fields: [
        { colKey: "usage", type: "number", min: 0 },
        { colKey: "cap", type: "number", min: 0 },
        { colKey: "ends", type: "date" },
      ] },
    ],
  },

  returns: {
    moduleId: "returns",
    analytics: { breakdownCol: "reason", breakdownMode: "count", topMode: "money", topCount: 5, topLabelCol: "customer" },
    displayCols: ["code", "order", "customer", "item", "qty", "value", "reason", "date", "status"],
    kpis: [
      kpi("bizKpiReturns", "rotate-ccw", C_SKY[0], C_SKY[1], (c) => ({ value: fmtBiz(c.rows.length, c.lang) })),
      kpi("bizKpiRefundValue", "wallet", C_VIOLET[0], C_VIOLET[1], (c) => ({ value: fmtBiz(sumCol(c.rows, c.cols, "value"), c.lang, c.currency) })),
      kpi("bizKpiPendingInspection", "clock", C_AMBER[0], C_AMBER[1], (c) => {
        const pending = rowsWithStatus(c.rows, ["pending"]).length;
        return { value: fmtBiz(pending, c.lang) };
      }),
      kpi("bizKpiReturnRate", "circle-x", C_ROSE[0], C_ROSE[1], (c) => {
        const rejected = rowsWithStatus(c.rows, ["rejected"]).length;
        return { value: `${pct(rejected, c.rows.length)}%`, tone: rejected > 0 ? "down" : "flat" };
      }),
      kpi("bizKpiAvgRefund", "scale", C_EMERALD[0], C_EMERALD[1], (c) => ({ value: fmtBiz(avgCol(c.rows, c.cols, "value"), c.lang, c.currency) })),
    ],
    form: [
      { titleKey: "bizSecBasics", icon: "rotate-ccw", fields: [
        { colKey: "code", type: "text", required: true, dir: "ltr" },
        { colKey: "order", type: "text", dir: "ltr" },
        { colKey: "customer", type: "text", required: true },
        { colKey: "item", type: "text", span: 2 },
        { colKey: "qty", type: "number", min: 0 },
        { colKey: "reason", type: "text" },
      ] },
      { titleKey: "bizSecPricing", icon: "wallet", fields: [
        { colKey: "value", type: "money", money: true, required: true, min: 0 },
        { colKey: "date", type: "date" },
      ] },
    ],
  },

  loyalty: {
    moduleId: "loyalty",
    analytics: { breakdownCol: "status", breakdownMode: "count", topMode: "count", topCount: 5, topLabelCol: "member" },
    displayCols: ["member", "phone", "points", "earned", "redeemed", "value", "visits", "expiry", "status"],
    kpis: [
      kpi("bizKpiMembers", "heart", C_SKY[0], C_SKY[1], (c) => ({ value: fmtBiz(c.rows.length, c.lang) })),
      kpi("bizKpiPointsOut", "star", C_AMBER[0], C_AMBER[1], (c) => ({ value: fmtBiz(sumCol(c.rows, c.cols, "points"), c.lang) })),
      kpi("bizKpiRewardsValue", "gift", C_VIOLET[0], C_VIOLET[1], (c) => ({ value: fmtBiz(sumCol(c.rows, c.cols, "value"), c.lang, c.currency) })),
      kpi("bizKpiAvgPoints", "activity", C_EMERALD[0], C_EMERALD[1], (c) => ({ value: fmtBiz(avgCol(c.rows, c.cols, "points"), c.lang) })),
      kpi("bizKpiGoldMembers", "award", C_ROSE[0], C_ROSE[1], (c) => {
        const gold = rowsWithStatus(c.rows, ["gold", "platinum"]).length;
        return { value: fmtBiz(gold, c.lang), sub: t(c.lang, "bizSubPct", { pct: pct(gold, c.rows.length).toString() }) };
      }),
    ],
    form: [
      { titleKey: "bizSecBasics", icon: "heart", fields: [
        { colKey: "member", type: "text", required: true, span: 2 },
        { colKey: "phone", type: "tel", dir: "ltr" },
        { colKey: "visits", type: "number", min: 0 },
      ] },
      { titleKey: "bizSecPricing", icon: "star", fields: [
        { colKey: "points", type: "number", required: true, min: 0 },
        { colKey: "earned", type: "number", min: 0 },
        { colKey: "redeemed", type: "number", min: 0 },
        { colKey: "value", type: "money", money: true, min: 0 },
        { colKey: "expiry", type: "date" },
      ] },
    ],
  },

  branches: {
    moduleId: "branches",
    analytics: { breakdownCol: "city", breakdownMode: "money", topMode: "money", topCount: 5, topLabelCol: "name" },
    displayCols: ["name", "city", "manager", "staff", "daily", "monthly", "growth", "opened", "status"],
    kpis: [
      kpi("bizKpiBranches", "network", C_SKY[0], C_SKY[1], (c) => ({ value: fmtBiz(c.rows.length, c.lang) })),
      kpi("bizKpiMonthlySales", "wallet", C_EMERALD[0], C_EMERALD[1], (c) => ({ value: fmtBiz(sumCol(c.rows, c.cols, "monthly"), c.lang, c.currency) })),
      kpi("bizKpiAvgDaily", "activity", C_VIOLET[0], C_VIOLET[1], (c) => ({ value: fmtBiz(avgCol(c.rows, c.cols, "daily"), c.lang, c.currency) })),
      kpi("bizKpiTopBranch", "award", C_AMBER[0], C_AMBER[1], (c) => {
        const top = topRowBy(c.rows, c.cols, "monthly");
        return {
          value: top ? cellOf(top, c.cols, "name") : "—",
          sub: top ? fmtBiz(num(cellOf(top, c.cols, "monthly")), c.lang, c.currency) : undefined,
        };
      }),
      kpi("bizKpiStaff", "users", C_SLATE[0], C_SLATE[1], (c) => ({ value: fmtBiz(sumCol(c.rows, c.cols, "staff"), c.lang) })),
    ],
    form: [
      { titleKey: "bizSecBasics", icon: "network", fields: [
        { colKey: "name", type: "text", required: true },
        { colKey: "city", type: "text" },
        { colKey: "manager", type: "text" },
        { colKey: "staff", type: "number", min: 0 },
      ] },
      { titleKey: "bizSecPricing", icon: "wallet", fields: [
        { colKey: "daily", type: "money", money: true, min: 0 },
        { colKey: "monthly", type: "money", money: true, required: true, min: 0 },
        { colKey: "growth", type: "number", step: "0.1" },
        { colKey: "opened", type: "date" },
      ] },
    ],
  },

  /* ROUND 155 — reports config rebuilt as an advanced + integrated report
   * management system. The owner's directive: «قم بتطوير الصفحة واجعلها
   * متقدمة ومتكاملة». The preset now carries title/type/generatedBy/format/
   * size cols (the old name→title + category→type renames + the 4 new
   * cols); the breakdown switches to TYPE (more meaningful than the old
   * Domain bucket); the top list ranks by title. The 5 statuses use the
   * new vocabulary (generated / generating / scheduled / failed / archived). */
  reports: {
    moduleId: "reports",
    analytics: { breakdownCol: "type", breakdownMode: "count", topMode: "count", topCount: 5, topLabelCol: "title" },
    displayCols: ["code", "title", "type", "period", "generatedBy", "format", "size", "rows", "generated", "status"],
    kpis: [
      kpi("bizKpiReports", "chart-pie", C_SKY[0], C_SKY[1], (c) => ({ value: fmtBiz(c.rows.length, c.lang) })),
      kpi("bizKpiReady", "circle-check", C_EMERALD[0], C_EMERALD[1], (c) => {
        const ready = rowsWithStatus(c.rows, ["generated"]).length;
        return { value: fmtBiz(ready, c.lang), tone: "up" };
      }),
      kpi("bizKpiAutoScheduled", "calendar-clock", C_VIOLET[0], C_VIOLET[1], (c) => {
        const sched = rowsWithStatus(c.rows, ["scheduled"]).length;
        return { value: fmtBiz(sched, c.lang) };
      }),
      kpi("bizKpiDataRows", "database", C_AMBER[0], C_AMBER[1], (c) => ({ value: fmtBiz(sumCol(c.rows, c.cols, "rows"), c.lang) })),
    ],
    form: [
      { titleKey: "bizSecBasics", icon: "chart-pie", fields: [
        { colKey: "code", type: "text", required: true, dir: "ltr" },
        { colKey: "title", type: "text", required: true, span: 2 },
        { colKey: "type", type: "text" },
        { colKey: "period", type: "text" },
        { colKey: "generatedBy", type: "text" },
      ] },
      { titleKey: "bizSecExtra", icon: "file-text", fields: [
        { colKey: "format", type: "text" },
        { colKey: "size", type: "text", dir: "ltr", locked: true },
        { colKey: "rows", type: "number", min: 0 },
        { colKey: "generated", type: "date" },
      ] },
    ],
  },

  stocktake: {
    moduleId: "stocktake",
    analytics: { breakdownCol: "zone", breakdownMode: "count", topMode: "money", topCount: 5, topLabelCol: "zone" },
    displayCols: ["code", "zone", "scheduled", "counter", "items", "variance", "value", "accuracy", "status"],
    kpis: [
      kpi("bizKpiCounts", "clipboard-check", C_SKY[0], C_SKY[1], (c) => ({ value: fmtBiz(c.rows.length, c.lang) })),
      kpi("bizKpiVarianceValue", "scale", C_ROSE[0], C_ROSE[1], (c) => ({ value: fmtBiz(sumCol(c.rows, c.cols, "value"), c.lang, c.currency) })),
      kpi("bizKpiAccuracy", "target", C_EMERALD[0], C_EMERALD[1], (c) => {
        const v = avgCol(c.rows, c.cols, "accuracy");
        return { value: `${v.toFixed(1)}%`, tone: v >= 98 ? "up" : "flat" };
      }),
      kpi("bizKpiReviewed", "badge-check", C_VIOLET[0], C_VIOLET[1], (c) => {
        const reviewed = rowsWithStatus(c.rows, ["reviewed"]).length;
        return { value: fmtBiz(reviewed, c.lang) };
      }),
    ],
    form: [
      { titleKey: "bizSecBasics", icon: "clipboard-check", fields: [
        { colKey: "code", type: "text", required: true, dir: "ltr" },
        { colKey: "zone", type: "text", required: true },
        { colKey: "scheduled", type: "date" },
        { colKey: "counter", type: "text" },
      ] },
      { titleKey: "bizSecPricing", icon: "scale", fields: [
        { colKey: "items", type: "number", min: 0 },
        { colKey: "variance", type: "number", step: "1" },
        { colKey: "value", type: "money", money: true, min: 0 },
        { colKey: "accuracy", type: "number", step: "0.1", min: 0 },
      ] },
    ],
  },

  /* ROUND 156 — expenses config rebuilt SIMPLE + Premium (the owner's
   * directive: «احذف الصفحة كاملة وأعد تطويرها بطريقة بسيطة وجذابة وPremium
   * تخص فقط المنصرفات مع إمكانية رفع صورة للإيصال اختياري بدقة»).
   * The complex 12-col financial breakdown is GONE (no vendor · invoiceRef ·
   * gross · tax · net · recurring). The preset now carries 8 cols (code ·
   * title · category · amount · date · method · notes · status); the table
   * surfaces 7 (notes lives in the detail sheet). Analytics breakdown is
   * BY CATEGORY (the most meaningful expense grouping); the top list ranks
   * TITLES by amount (no more vendor axis). The 4 KPIs cover the simple
   * readout the owner asked for:
   *   • total count · total amount · paid count · pending count · this
   *     month's total (3 statuses — paid · pending · cancelled — replaced
   *     the 4-state approval workflow). The optional receipt image rides
   *     the record's existing imageRef field (uploaded in the add/edit
   *     dialog — see business-record-dialog.tsx's ReceiptImageSection). */
  expenses: {
    moduleId: "expenses",
    analytics: { breakdownCol: "category", breakdownMode: "money", topMode: "money", topCount: 5, topLabelCol: "title" },
    displayCols: ["code", "title", "category", "amount", "date", "method", "status"],
    kpis: [
      kpi("bizKpiExpensesCount", "receipt", C_SKY[0], C_SKY[1], (c) => ({ value: fmtBiz(c.rows.length, c.lang) })),
      kpi("bizKpiExpensesTotal", "wallet", C_VIOLET[0], C_VIOLET[1], (c) => ({ value: fmtBiz(sumCol(c.rows, c.cols, "amount"), c.lang, c.currency) })),
      kpi("bizKpiExpensesPaid", "circle-check", C_EMERALD[0], C_EMERALD[1], (c) => {
        const paid = rowsWithStatus(c.rows, ["paid"]).length;
        return { value: fmtBiz(paid, c.lang), sub: t(c.lang, "bizSubPct", { pct: pct(paid, c.rows.length).toString() }), tone: "up" };
      }),
      kpi("bizKpiExpensesPending", "hourglass", C_AMBER[0], C_AMBER[1], (c) => {
        const pending = rowsWithStatus(c.rows, ["pending"]).length;
        return { value: fmtBiz(pending, c.lang), sub: t(c.lang, "bizSubPct", { pct: pct(pending, c.rows.length).toString() }) };
      }),
      kpi("bizKpiExpensesMonth", "calendar-clock", C_VIOLET[0], C_VIOLET[1], (c) => {
        /* Σ of amount over rows whose date column lands in the current
         * calendar month (YYYY-MM matching the today's ISO month). */
        const di = colIndex(c.cols, "date");
        const ai = colIndex(c.cols, "amount");
        const now = new Date();
        const ym = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
        const monthTotal = di >= 0 && ai >= 0
          ? c.rows.reduce((s, r) => {
              const d = (r.values[di] ?? "").slice(0, 7);
              return d === ym ? s + num(r.values[ai]) : s;
            }, 0)
          : 0;
        return { value: fmtBiz(monthTotal, c.lang, c.currency) };
      }),
    ],
    form: [
      { titleKey: "bizSecBasics", icon: "receipt", fields: [
        { colKey: "code", type: "text", required: true, dir: "ltr" },
        { colKey: "title", type: "text", required: true, span: 2 },
        { colKey: "category", type: "text" },
        { colKey: "amount", type: "money", money: true, required: true, min: 0 },
        { colKey: "date", type: "date" },
      ] },
      { titleKey: "bizSecExtra", icon: "credit-card", fields: [
        { colKey: "method", type: "text" },
        { colKey: "notes", type: "text", span: 2 },
        { colKey: "status", type: "select" },
      ] },
    ],
  },
};

/** modules routed to the business suite (the router's membership set —
 * ROUND 132: EVERY module routes there now; this list stays for callers
 * that need the explicit-registry membership). */
export const BUSINESS_SUITE_MODULES: readonly string[] = Object.keys(BUSINESS_MODULE_CONFIGS);

/* ------------------------------------------------------------------ */
/* ROUND 132 — the FALLBACK config generator                            */
/* ------------------------------------------------------------------ */

/**
 * The premium suite for EVERY module, not just the curated eleven: for any
 * module outside the explicit registry, the config is derived mechanically
 * from its preset (cols / statuses / moneyKey):
 *
 *   - KPIs: total records · last-30-days · positive-status share · total
 *     value (when the preset carries money) · growth
 *   - analytics: status distribution breakdown + top rows by the preset's
 *     first text column (ranked by the money column when present)
 *   - displayCols: the full preset column set
 *   - form: two sections — core details (id + text/date columns; the id is
 *     locked/auto by the dialog's immutability rule) and numbers & status
 *     (numeric/money columns + the status select)
 *
 * The labels are INLINE bilingual pairs (labelAr/labelEn — see
 * bizKpiLabel) so the ~93 domain modules need zero new i18n keys.
 */
function fallbackBizConfig(moduleId: string, systemId?: string): BizModuleConfig {
  const preset = modulePreset(moduleId, systemId);
  const statusKey = preset.cols.find((c) => c.kind === "status")?.key ?? "status";
  /* ROUND 154 — topLabelCol: prefer the "name" column (the standard
   * human-readable label across ALL presets) over the first text column.
   * Previously this picked the first text column, which for the students
   * preset was "universityId" (الرقم الجامعي) — the Top section showed
   * the university ID instead of the student name. Now it correctly
   * prefers "name", falling back to the first non-ID text column. */
  const labelCol = preset.cols.find((c) => c.key === "name")?.key
    ?? preset.cols.find((c) => c.kind === "text" && c.key !== statusKey && c.key !== "code")?.key
    ?? preset.cols[0]?.key
    ?? "name";
  const moneyKey = preset.moneyKey ?? null;
  const hasMoney = moneyKey !== null && preset.cols.some((c) => c.key === moneyKey);

  const kpis: BizKpiDef[] = [
    kpi({ ar: "إجمالي السجلات", en: "Total records" }, "layers", C_SKY[0], C_SKY[1], (c) => ({
      value: fmtBiz(c.rows.length, c.lang),
    })),
    kpi({ ar: "آخر ٣٠ يوماً", en: "Last 30 days" }, "calendar", C_VIOLET[0], C_VIOLET[1], (c) => ({
      value: fmtBiz(c.data.kpis.monthly, c.lang),
      sub: t(c.lang, "bizSubOf", { total: String(c.rows.length) }),
    })),
    kpi({ ar: "الحالات الإيجابية", en: "Positive statuses" }, "activity", C_EMERALD[0], C_EMERALD[1], (c) => {
      const positive = c.rows.filter((r) => {
        const st = c.statuses.find((s) => s.key === r.statusKey);
        return st ? st.tone === "emerald" || st.tone === "sky" : false;
      }).length;
      return { value: `${pct(positive, c.rows.length)}%`, sub: t(c.lang, "bizSubCount", { count: String(positive) }), tone: "up" };
    }),
  ];
  if (hasMoney && moneyKey) {
    kpis.push(
      kpi({ ar: "القيمة الإجمالية", en: "Total value" }, "wallet", C_AMBER[0], C_AMBER[1], (c) => ({
        value: fmtBiz(sumCol(c.rows, c.cols, moneyKey), c.lang, c.currency),
      }))
    );
  }
  kpis.push(
    kpi({ ar: "معدل النمو", en: "Growth rate" }, "trending-up", C_ROSE[0], C_ROSE[1], (c) => ({
      value: `${c.data.kpis.growth > 0 ? "+" : ""}${c.data.kpis.growth}%`,
      tone: c.data.kpis.growth >= 0 ? "up" : "down",
    }))
  );

  /* the form: core details + numbers/status, derived from the columns */
  const idCol = preset.cols.find((c) => c.kind === "id");
  const basics: BizFieldDef[] = [];
  const numbers: BizFieldDef[] = [];
  for (const col of preset.cols) {
    if (col.key === statusKey) {
      numbers.push({ colKey: col.key, type: "select" });
      continue;
    }
    if (col.kind === "id") {
      basics.push({ colKey: col.key, type: "text", required: col === idCol, dir: "ltr" });
    } else if (col.kind === "date") {
      basics.push({ colKey: col.key, type: "date" });
    } else if (col.kind === "num") {
      numbers.push({ colKey: col.key, type: "number", min: 0 });
    } else if (col.kind === "money") {
      numbers.push({ colKey: col.key, type: "money", money: true, min: 0 });
    } else {
      basics.push({ colKey: col.key, type: "text" });
    }
  }

  return {
    moduleId,
    analytics: {
      breakdownCol: statusKey,
      breakdownMode: "count",
      topMode: hasMoney && moneyKey ? "money" : "count",
      topCount: 5,
      topLabelCol: labelCol,
    },
    displayCols: preset.cols.map((c) => c.key),
    kpis,
    form: [
      { titleAr: "البيانات الأساسية", titleEn: "Core details", icon: "clipboard-list", fields: basics },
      { titleAr: "الأرقام والحالة", titleEn: "Numbers & status", icon: "calculator", fields: numbers },
    ],
  };
}

/** config lookup — the explicit registry first, then the ROUND-132 fallback
 * generator so EVERY module gets the premium workspace. Never undefined.
 * ROUND 168 — systemId scopes the fallback's preset (SAMS dorm maintenance
 * draws dorm columns/vocabulary); the explicit registry is system-neutral. */
export function bizConfig(moduleId: string, systemId?: string): BizModuleConfig {
  return BUSINESS_MODULE_CONFIGS[moduleId] ?? fallbackBizConfig(moduleId, systemId);
}
