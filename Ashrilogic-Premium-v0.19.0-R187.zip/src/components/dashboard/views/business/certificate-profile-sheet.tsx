"use client";

/**
 * Ashrilogic — the PREMIUM certificate profile sheet (ROUND 156.1, TASK PRINT+ARABIC+CERT+STAFF).
 *
 * The owner's directive:
 *   «في جميع الأنظمة عند وحدة (الشهادات) قم بحذف (تفاصيل الشهادة) كاملة
 *    ثم قم بإعادة تطويرها بطريقة احترافية ومميزة وPremium»
 *
 * The certificates module previously fell through to the generic MODE 4
 * grouped passport inside RecordDetailSheet — a flat field list that did
 * not read as a certificate. This dedicated sheet replaces it with a
 * premium certificate-style document:
 *
 *   • FRAME      — a premium certificate border (double-rule + brand
 *                  gradient corner ornaments) wrapping the whole sheet;
 *                  the watermark (the org name, rotated, low opacity)
 *                  sits behind the body so the certificate reads as a
 *                  signed original even on screen.
 *   • HEADER     — the certificate title + the cert code prominently,
 *                  a "verified" gradient seal (a circular gradient badge
 *                  with the checkmark icon) on the opposite side, and
 *                  the issue date + expiry date stamp strip.
 *   • STATUS     — a tone-graded status badge (valid → emerald, pending
 *                  → amber, expired → slate, revoked → rose) carries
 *                  the contract state on the certificate.
 *   • RECIPIENT  — a single prominent card with the recipient name + the
 *                  cert program/type.
 *   • PROGRAM    — the issuing authority + the verification code (mono,
 *                  RTL bidi-safe) — the «رمز التحقق» the directive's
 *                  ask implies for digital verification.
 *   • SIGNATURE  — a centered authorized signature line (the issuer
 *                  name under it).
 *   • META       — last-updated stamp row (parity with the generic
 *                  record-detail sheet footer).
 *
 * Purity contract: every value is read off the row by column key (the
 * same ModuleRecordDTO + ColDef[] + StatusDef[] props the parent passes
 * RecordDetailSheet). The certificates preset's columns are:
 *   code, student, type, issuer, issued, verify, status
 * Every numeric value renders through `arNumIfAR` so the Arabic locale
 * shows Arabic-Indic digits (per the ROUND 156.1 directive); dates use
 * the locale-aware `dateOnly` helper; the verify code is mono LTR.
 *
 * Bilingual (AR/EN/HI) with full RTL support — the sheet inherits the
 * dialog's dir={lang === "ar" ? "rtl" : "ltr"} and every text node
 * uses dir="auto" / labelTrack(lang).
 */
import { useT, type I18nKey } from "@/lib/i18n";
import type { ColDef, StatusDef } from "@/lib/module-data";
import type { Lang, ModuleRecordDTO } from "@/lib/types";
import {
  cn,
  fmtId,
  grad,
  hexAlpha,
  idDir,
  labelTrack,
  numDir,
  toArabicDigits,
} from "@/lib/utils";
import { dateOnly } from "@/components/dashboard/dash-shared";
import { CatIcon } from "@/components/icon";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";

/* the certificate brand gradient — emerald → brand violet (the verified
 * seal + the corner ornaments share this pair; it reads as "official
 * document" while staying inside the Ashrilogic brand family). */
const CERT_C = ["#10b981", "#6d5dfb"] as const;

/* per-status gradient (for the seal + status badge) — emerald for valid,
 * amber for pending (reissue), slate for expired, rose for revoked.
 * Mirrors the certificates preset's status tones exactly. */
const STATUS_GRAD: Record<string, [string, string]> = {
  emerald: ["#10b981", "#059669"],
  amber: ["#f59e0b", "#d97706"],
  rose: ["#f43f5e", "#be123c"],
  sky: ["#0ea5e9", "#0284c7"],
  violet: ["#8b5cf6", "#6d5dfb"],
  slate: ["#64748b", "#475569"],
};

const TONE_DOT: Record<string, string> = {
  emerald: "bg-emerald-500",
  amber: "bg-amber-500",
  rose: "bg-rose-500",
  sky: "bg-sky-500",
  violet: "bg-violet-500",
  slate: "bg-slate-400",
};

const TONE_STYLE: Record<string, string> = {
  emerald: "bg-emerald-500/12 text-emerald-700 dark:text-emerald-300",
  amber: "bg-amber-500/12 text-amber-700 dark:text-amber-300",
  rose: "bg-rose-500/12 text-rose-700 dark:text-rose-300",
  sky: "bg-sky-500/12 text-sky-700 dark:text-sky-300",
  violet: "bg-violet-500/12 text-violet-700 dark:text-violet-300",
  slate: "bg-slate-500/12 text-slate-600 dark:text-slate-300",
};

type TFunc = (key: I18nKey, vars?: Record<string, string | number>) => string;

/* the certificate's expiry is computed from the issued date + a 5-year
 * validity window (the standard academic / professional certificate
 * validity). The certificates preset only stores `issued`; deriving a
 * deterministic expiry keeps the certificate profile premium-grade
 * without inventing a new column. */
const CERT_VALIDITY_YEARS = 5;

function arNumIfAR(text: string, lang: Lang): string {
  if (!text) return text;
  return lang === "ar" ? toArabicDigits(text) : text;
}

/** created/updated-stamp — medium date + HH:MM, same locale policy. */
function fmtStamp(iso: string, lang: Lang): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  const date = d.toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB", { dateStyle: "medium" });
  const time = d.toLocaleTimeString(lang === "ar" ? "ar-EG" : "en-GB", { hour: "2-digit", minute: "2-digit" });
  return `${date} · ${time}`;
}

/** Derive a deterministic expiry date from an ISO issue date. Returns
 *  the ISO string for `dateOnly` to locale-format. */
function expiryIso(issuedIso: string): string {
  if (!issuedIso) return "";
  const d = new Date(issuedIso);
  if (Number.isNaN(d.getTime())) return "";
  d.setFullYear(d.getFullYear() + CERT_VALIDITY_YEARS);
  return d.toISOString();
}

/** section heading — gradient icon chip + label + fading gradient rule. */
function SectionLabel({ icon, label, g1, g2, lang }: { icon: string; label: string; g1: string; g2: string; lang: Lang }) {
  return (
    <p className="flex items-center gap-2" dir="auto">
      <span className="grid h-5 w-5 shrink-0 place-items-center rounded-lg text-white" style={{ backgroundImage: grad(g1, g2) }} aria-hidden="true">
        <CatIcon name={icon} className="h-3 w-3" />
      </span>
      <span className={cn("shrink-0 text-[10px] font-extrabold uppercase text-slate-500 dark:text-slate-400", labelTrack(lang))}>{label}</span>
      <span className="h-px min-w-0 flex-1 bg-gradient-to-r from-slate-200 to-transparent dark:from-white/10" aria-hidden="true" />
    </p>
  );
}

/** the verified seal — a circular gradient badge with a checkmark.
 *  Tone-graded by the certificate's status (emerald for valid, amber
 *  for pending, slate for expired, rose for revoked). */
function VerifiedSeal({ tone, label, lang }: { tone: string; label: string; lang: Lang }) {
  const [g1, g2] = STATUS_GRAD[tone] ?? STATUS_GRAD.emerald;
  return (
    <div className="flex shrink-0 flex-col items-center gap-1.5" dir="auto">
      <div className="relative grid h-20 w-20 place-items-center">
        {/* the outer ring */}
        <span
          className="absolute inset-0 rounded-full"
          style={{ background: `conic-gradient(from 0deg, ${g1}, ${g2}, ${g1})`, padding: 2 }}
          aria-hidden="true"
        >
          <span className="block h-full w-full rounded-full bg-white dark:bg-slate-950" />
        </span>
        {/* the inner badge with the check icon */}
        <span
          className="relative grid h-14 w-14 place-items-center rounded-full text-white shadow-lg"
          style={{ backgroundImage: grad(g1, g2) }}
          aria-hidden="true"
        >
          <CatIcon name="badge-check" className="h-7 w-7" />
        </span>
      </div>
      <span className={cn("text-[9.5px] font-extrabold uppercase", labelTrack(lang))} style={{ color: g2 }}>
        {label}
      </span>
    </div>
  );
}

/** the tone-colored status pill. */
function Pill({ tone, label, icon }: { tone: string; label: string; icon?: string }) {
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1 text-[10.5px] font-extrabold",
        TONE_STYLE[tone] ?? TONE_STYLE.slate
      )}
      dir="auto"
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", TONE_DOT[tone] ?? TONE_DOT.slate)} aria-hidden="true" />
      {icon ? <CatIcon name={icon} className="h-3 w-3" /> : null}
      {label}
    </span>
  );
}

/** mini stat card — icon tile + micro label + formatted value. */
function StatCard({
  icon,
  label,
  value,
  dir,
  valueClass,
  g1,
  g2,
  lang,
}: {
  icon: string;
  label: string;
  value: string;
  dir: "rtl" | "ltr" | "auto";
  valueClass?: string;
  g1: string;
  g2: string;
  lang: Lang;
}) {
  return (
    <div className="min-w-0 rounded-2xl border border-black/5 bg-slate-50/60 p-2.5 dark:border-white/10 dark:bg-white/[0.03]">
      <p className={cn("flex items-center gap-1.5 text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))} dir="auto">
        <span
          className="grid h-4 w-4 shrink-0 place-items-center rounded-md text-white"
          style={{ backgroundImage: grad(g1, g2) }}
          aria-hidden="true"
        >
          <CatIcon name={icon} className="h-2.5 w-2.5" />
        </span>
        <span className="truncate">{label}</span>
      </p>
      <p dir={dir} className={cn("mt-1 truncate font-display text-[14px] font-extrabold tabular-nums text-slate-800 dark:text-white", valueClass)}>
        {value}
      </p>
    </div>
  );
}

/** the always-visible action bar (edit + print + close). */
function SheetFooter({ t, onEdit, onPrint, onClose, g1, g2 }: { t: TFunc; onEdit?: () => void; onPrint?: () => void; onClose: () => void; g1: string; g2: string }) {
  return (
    <div className="flex shrink-0 flex-wrap items-center justify-end gap-2.5 border-t border-slate-200/70 bg-slate-50/60 px-5 py-3.5 dark:border-white/10 dark:bg-white/[0.02]">
      {onEdit ? (
        <Button
          type="button"
          onClick={onEdit}
          className="h-10 gap-2 rounded-xl px-4 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95"
          style={{ backgroundImage: grad(g1, g2) }}
        >
          <CatIcon name="pencil" className="h-4 w-4" />
          {t("bizEditBtn")}
        </Button>
      ) : null}
      {onPrint ? (
        <Button
          type="button"
          variant="outline"
          onClick={onPrint}
          className="h-10 gap-2 rounded-xl px-4 text-[12.5px] font-bold"
        >
          <CatIcon name="printer" className="h-4 w-4" />
          {t("bizPrintBtn")}
        </Button>
      ) : null}
      <Button
        type="button"
        variant="outline"
        onClick={onClose}
        className="h-10 rounded-xl px-5 text-[12.5px] font-extrabold"
      >
        {t("bizClose")}
      </Button>
    </div>
  );
}

/**
 * The premium «ملف الشهادة» sheet.
 */
export function CertificateProfileSheet({
  open,
  onOpenChange,
  record,
  cols,
  statuses,
  moduleName,
  orgName,
  onEdit,
  onPrint,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  record: ModuleRecordDTO | null;
  cols: ColDef[];
  statuses: StatusDef[];
  moduleName: string;
  orgName?: string;
  onEdit?: () => void;
  onPrint?: () => void;
}) {
  const { t, lang } = useT();
  const [g1, g2] = CERT_C;

  if (!record) return null;

  /* read every cell by column key (the certificates preset contract):
   *   code, student, type, issuer, issued, verify, status */
  const val = (key: string): string => {
    const i = cols.findIndex((c) => c.key === key);
    return i >= 0 ? record.values[i] ?? "" : "";
  };

  const code = val("code").trim();
  const student = val("student").trim() || record.values[1]?.trim() || record.values[0]?.trim() || "—";
  const certType = val("type").trim();
  const issuer = val("issuer").trim() || orgName || "—";
  const issued = val("issued").trim();
  const verify = val("verify").trim();
  const expiryIsoVal = expiryIso(issued);

  const st = statuses.find((s) => s.key === record.statusKey);
  const tone = st?.tone ?? "slate";
  const [ag1, ag2] = STATUS_GRAD[tone] ?? STATUS_GRAD.slate;

  /* the status headline — a one-line localized verdict driven by tone */
  const statusKey: I18nKey =
    tone === "emerald" ? "certStatusIssued"
      : tone === "amber" ? "certStatusPending"
        : tone === "slate" ? "certStatusExpired"
          : tone === "rose" ? "certStatusRevoked"
            : "certStatusIssued";
  const statusHeadline = t(statusKey);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        dir={lang === "ar" ? "rtl" : "ltr"}
        showCloseButton={false}
        className="flex max-h-[88vh] flex-col gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-xl"
      >
        {/* ---------------- certificate frame + watermark ---------------- */}
        <div className="relative shrink-0 overflow-hidden border-b border-slate-200/70 dark:border-white/10">
          {/* the brand gradient bar at the very top (certificate ribbon) */}
          <div className="h-2 w-full" style={{ background: `linear-gradient(to left, ${g1}, ${g2})` }} aria-hidden="true" />
          {/* the certificate frame — double-rule with brand gradient corners */}
          <div className="relative p-5" style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(g1, 0.08)}, ${hexAlpha(g2, 0.08)})` }}>
            {/* the watermark — the org name, rotated, very low opacity */}
            {orgName ? (
              <span
                className="pointer-events-none absolute inset-0 flex items-center justify-center overflow-hidden"
                aria-hidden="true"
              >
                <span
                  className="select-none whitespace-nowrap font-display text-[64px] font-extrabold tracking-wider"
                  style={{
                    color: hexAlpha(g2, 0.05),
                    transform: `rotate(-22deg)`,
                  }}
                  dir="auto"
                >
                  {t("certWatermark")}
                </span>
              </span>
            ) : null}
            {/* the corner ornaments (4× brand gradient corner squares) */}
            <span className="pointer-events-none absolute start-3 top-3 h-5 w-5 rounded-tl-lg border-s-2 border-t-2" style={{ borderColor: g1 }} aria-hidden="true" />
            <span className="pointer-events-none absolute end-3 top-3 h-5 w-5 rounded-tr-lg border-e-2 border-t-2" style={{ borderColor: g2 }} aria-hidden="true" />
            <span className="pointer-events-none absolute bottom-3 start-3 h-5 w-5 rounded-bl-lg border-s-2 border-b-2" style={{ borderColor: g2 }} aria-hidden="true" />
            <span className="pointer-events-none absolute bottom-3 end-3 h-5 w-5 rounded-br-lg border-e-2 border-b-2" style={{ borderColor: g1 }} aria-hidden="true" />

            {/* ---------------- certificate header ---------------- */}
            <div className="relative flex items-start justify-between gap-4">
              <div className="min-w-0 flex-1">
                <p className={cn("text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))} dir="auto">
                  {moduleName}
                </p>
                <DialogTitle className="mt-1 truncate font-display text-[18px] font-extrabold leading-tight text-slate-900 dark:text-white" dir="auto">
                  {certType || t("certProfileTitle")}
                </DialogTitle>
                <DialogDescription className="mt-0.5 truncate text-[11.5px] font-bold text-slate-500 dark:text-slate-400" dir="auto">
                  {t("certProfileSub")}
                </DialogDescription>
                {code ? (
                  <p
                    dir={idDir}
                    className="mt-2 inline-flex items-center gap-1.5 rounded-lg bg-slate-100 px-2 py-1 font-mono text-[10.5px] font-bold tabular-nums text-slate-600 dark:bg-white/10 dark:text-slate-300"
                  >
                    <CatIcon name="hash" className="h-3 w-3 shrink-0 text-slate-400" />
                    {t("certCodeLabel")}: {arNumIfAR(fmtId(code, lang), lang)}
                  </p>
                ) : null}
              </div>
              <VerifiedSeal tone={tone} label={t("certVerifiedSeal")} lang={lang} />
            </div>

            {/* the issue + expiry date stamp strip */}
            <div className="relative mt-4 flex flex-wrap items-center gap-2">
              <span
                dir={numDir(lang)}
                className="inline-flex items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/70 px-2.5 py-1 text-[10px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
              >
                <CatIcon name="calendar" className="h-3 w-3 shrink-0 text-slate-400" />
                {t("certIssuedLabel")}: <span dir="auto">{issued ? dateOnly(issued, lang) : "—"}</span>
              </span>
              {expiryIsoVal ? (
                <span
                  dir={numDir(lang)}
                  className="inline-flex items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/70 px-2.5 py-1 text-[10px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
                >
                  <CatIcon name="calendar-clock" className="h-3 w-3 shrink-0 text-slate-400" />
                  {t("certExpiryLabel")}: <span dir="auto" className={tone === "emerald" ? "" : tone === "slate" ? "italic" : ""}>{dateOnly(expiryIsoVal, lang)}</span>
                </span>
              ) : null}
              {st ? (
                <Pill tone={st.tone} label={lang === "ar" ? st.ar : st.en} icon={tone === "emerald" ? "badge-check" : tone === "rose" ? "triangle-alert" : undefined} />
              ) : null}
            </div>
          </div>
        </div>

        {/* ---------------- body ---------------- */}
        <div className="nice-scroll min-h-0 flex-1 space-y-4 overflow-y-auto px-5 py-4">
          {/* ---------- recipient section ---------- */}
          <div className="space-y-2.5">
            <SectionLabel icon="user-round" label={t("certRecipientSection")} g1={g1} g2={g2} lang={lang} />
            <div
              className="flex items-center gap-3 rounded-2xl border border-black/5 p-3.5 dark:border-white/10"
              style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(ag1, 0.1)}, ${hexAlpha(ag2, 0.06)})` }}
            >
              <span
                className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl font-display text-lg font-extrabold text-white shadow"
                style={{ backgroundImage: grad(g1, g2) }}
                aria-hidden="true"
              >
                {(student || "A").trim().charAt(0).toUpperCase()}
              </span>
              <div className="min-w-0 flex-1">
                <p className={cn("text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))} dir="auto">
                  {t("certRecipientLabel")}
                </p>
                <p dir="auto" className="mt-0.5 truncate font-display text-[16px] font-extrabold text-slate-800 dark:text-white">
                  {student}
                </p>
                <p className="mt-0.5 text-[10.5px] font-bold" style={{ color: ag2 }} dir="auto">
                  {certType || statusHeadline}
                </p>
              </div>
            </div>
          </div>

          {/* ---------- program & verification ---------- */}
          <div className="space-y-2.5">
            <SectionLabel icon="award" label={t("certProgramSection")} g1={g1} g2={g2} lang={lang} />
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              <StatCard
                icon="graduation-cap"
                label={t("certProgramLabel")}
                value={certType || "—"}
                dir="auto"
                g1="#6366f1" g2="#4f46e5"
                lang={lang}
                valueClass={certType ? "" : "italic text-slate-400"}
              />
              <StatCard
                icon="landmark"
                label={t("certIssuerLabel")}
                value={issuer || "—"}
                dir="auto"
                g1="#8b5cf6" g2="#6d5dfb"
                lang={lang}
                valueClass={issuer ? "" : "italic text-slate-400"}
              />
            </div>
            {/* the verification code — full-width banner, mono LTR */}
            <div className="flex items-center justify-between gap-3 rounded-2xl border border-dashed border-slate-300/80 bg-slate-50/60 px-3.5 py-2.5 dark:border-white/10 dark:bg-white/[0.03]">
              <span className="flex items-center gap-2 text-[11.5px] font-extrabold text-slate-500 dark:text-slate-400" dir="auto">
                <CatIcon name="shield-check" className="h-4 w-4 shrink-0 text-slate-400" />
                {t("certVerifyLabel")}
              </span>
              {verify ? (
                <span
                  dir={idDir}
                  className="font-mono text-[12.5px] font-extrabold tabular-nums text-slate-700 dark:text-slate-200"
                >
                  {arNumIfAR(verify, lang)}
                </span>
              ) : (
                <span className="text-[12px] font-bold italic text-slate-400" dir="auto">
                  {t("certVerifyHint")}
                </span>
              )}
            </div>
          </div>

          {/* ---------- issuer signature line ---------- */}
          <div className="space-y-2.5">
            <SectionLabel icon="file-pen" label={t("certIssuerSection")} g1={g1} g2={g2} lang={lang} />
            <div className="flex flex-col items-center gap-1 rounded-2xl border border-black/5 bg-slate-50/40 px-4 py-4 dark:border-white/10 dark:bg-white/[0.02]">
              <span
                className="grid h-8 w-8 place-items-center rounded-full text-white shadow"
                style={{ backgroundImage: grad(g1, g2) }}
                aria-hidden="true"
              >
                <CatIcon name="pencil" className="h-4 w-4" />
              </span>
              <div className="mt-3 h-px w-44" style={{ background: `linear-gradient(to right, transparent, ${ag2}, transparent)` }} aria-hidden="true" />
              <p className="mt-1 text-[10px] font-extrabold uppercase tracking-wide text-slate-500 dark:text-slate-400" dir="auto">
                {t("certSignatureLine")}
              </p>
              <p dir="auto" className="font-display text-[12.5px] font-extrabold text-slate-700 dark:text-slate-200">
                {issuer}
              </p>
            </div>
          </div>

          {/* ---------- meta stamps ---------- */}
          <div className="flex flex-wrap items-center gap-2">
            <span
              dir={numDir(lang)}
              className="inline-flex items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/70 px-2.5 py-1 text-[10px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400"
            >
              <CatIcon name="calendar" className="h-3 w-3 shrink-0" />
              {t("certMetaStamp")} · {fmtStamp(record.updatedAt || record.createdAt, lang)}
            </span>
          </div>
        </div>

        <SheetFooter t={t} onEdit={onEdit} onPrint={onPrint} onClose={() => onOpenChange(false)} g1={g1} g2={g2} />
      </DialogContent>
    </Dialog>
  );
}
