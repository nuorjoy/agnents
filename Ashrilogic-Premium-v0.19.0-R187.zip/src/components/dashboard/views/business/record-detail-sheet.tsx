"use client";

/**
 * Ashrilogic — the PREMIUM record detail sheet (ROUND 133 / task R133-FE-A).
 *
 * The owner's directive:
 *   «عند الضغط على عرض (المنتجات، المخزون) اجعل التفاصيل التي تظهر
 *    احترافية وجذابة وPremium»
 *   «عند (نقاط البيع) عند الضغط على عرض (تفاصيل السجل) قم بتطويرها
 *    وأظهر تفاصيل السجل بطريقة جذابة جداً»
 *   «في صفحة (العملاء) طور من بروفايل العملاء لتبدو اكثر واضحة وجذابة»
 *
 * One self-contained sheet, four premium modes (dispatched by moduleId):
 *
 *   pos        → MODE 1 — a thermal-printer SALES RECEIPT: letterhead with
 *                 the org initial, lock-styled tx metadata chips, dashed
 *                 separators, a gradient grand-total, customer + shift
 *                 stamps and a decorative CSS barcode footer.
 *   products   → MODE 2 — a PRODUCT PASSPORT: photo/gradient hero, EAN-13
 *                 CSS barcode, stats grid with a stock health bar, sale
 *                 banner, created/shift metadata.
 *   customers  → MODE 3 — a CUSTOMER PROFILE: gradient avatar, tier pill,
 *                 5-stat RFM grid, loyalty explainer strip, contact rows.
 *   (default)  → MODE 4 — a grouped field passport (core details + numbers
 *                 + record metadata) for every other module.
 *
 * Purity contract: everything arrives via props (NO fetch, NO i18n edits —
 * every key already exists). Every numeric / money / ID value renders
 * through the ROUND 133 helpers (fmtNum / fmtMoneyCell / fmtId with
 * dir={numDir(lang)}) so the Arabic locale shows Arabic-Indic digits with
 * the correct RTL bidi embedding; status pills copy the exact tone→class
 * idiom business-suite uses. The sibling integrator (business-suite.tsx)
 * swaps its generic row-detail dialog for this sheet.
 */
import { useMemo } from "react";
import { useT, type I18nKey } from "@/lib/i18n";
import { useShift } from "@/components/dashboard/shift/use-shift";
import type { ColDef, StatusDef } from "@/lib/module-data";
import type { Lang, ModuleRecordDTO } from "@/lib/types";
import {
  cn,
  fmtId,
  fmtMoneyCell,
  fmtNum,
  grad,
  hexAlpha,
  idDir,
  initial,
  labelTrack,
  numDir,
  toArabicDigits,
} from "@/lib/utils";
import { CatIcon } from "@/components/icon";
import { PaymentsSummary } from "@/components/dashboard/views/business/payment-manager";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { MedicalDetailMode } from "@/components/dashboard/views/business/medical-detail-modes";

/* ------------------------------------------------------------------ */
/* tone maps — the exact business-suite / inv-shared pill idiom        */
/* ------------------------------------------------------------------ */

const TONE_DOT: Record<string, string> = {
  emerald: "bg-emerald-500",
  amber: "bg-amber-500",
  rose: "bg-rose-500",
  sky: "bg-sky-500",
  violet: "bg-violet-500",
  slate: "bg-slate-400",
};

const TONE_STYLE: Record<string, string> = {
  emerald: "bg-emerald-500/12 text-emerald-700 dark:text-emerald-300",
  amber: "bg-amber-500/12 text-amber-700 dark:text-amber-300",
  rose: "bg-rose-500/12 text-rose-700 dark:text-rose-300",
  sky: "bg-sky-500/12 text-sky-700 dark:text-sky-300",
  violet: "bg-violet-500/12 text-violet-700 dark:text-violet-300",
  slate: "bg-slate-500/12 text-slate-600 dark:text-slate-300",
};

/* per-mode brand gradients (self-contained — no category colors travel
 * through the props contract) */
const RECEIPT_C = ["#10b981", "#047857"] as const; /* emerald → deep green  */
const PASSPORT_C = ["#6d5dfb", "#8b5cf6"] as const; /* brand violet          */

/* ------------------------------------------------------------------ */
/* shared types + atoms                                                */
/* ------------------------------------------------------------------ */

type TFunc = (key: I18nKey, vars?: Record<string, string | number>) => string;

export interface SheetCtx {
  record: ModuleRecordDTO;
  cols: ColDef[];
  statuses: StatusDef[];
  moduleName: string;
  currency?: string;
  orgName?: string;
  lang: Lang;
  t: TFunc;
  onPrint?: () => void;
  onClose: () => void;
  /** ROUND 149 (TASK E.2) — the «Edit» button callback. Opens the
   *  business-record-dialog in edit mode (the parent swaps the sheet
   *  for the dialog with draft.record = this row). Undefined → no Edit
   *  button (e.g. demo rows the operator can't mutate). */
  onEdit?: () => void;
  /** ROUND 133 fix — the HUMAN shift code (SHF-…) resolved from the shared
   *  shift cache; the record only carries the cuid. Undefined → badge only. */
  shiftCode?: string;
}

/** localized date cell — "2026-03-12" → «١٢ مارس ٢٠٢٦» (ar-EG keeps the
 *  Gregorian calendar + Arabic-Indic digits, the settings-view idiom). */
export function fmtDateCell(v: string, lang: Lang): string {
  if (!v) return "—";
  const iso = /^\d{4}-\d{2}-\d{2}$/.test(v) ? `${v}T00:00:00` : v;
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return lang === "ar" ? toArabicDigits(v) : v;
  return d.toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB", { dateStyle: "medium" });
}

/** created-stamp — medium date + HH:MM, same locale policy. */
export function fmtStamp(iso: string, lang: Lang): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  const date = d.toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB", { dateStyle: "medium" });
  const time = d.toLocaleTimeString(lang === "ar" ? "ar-EG" : "en-GB", { hour: "2-digit", minute: "2-digit" });
  return `${date} · ${time}`;
}

/**
 * Decorative deterministic CSS barcode — pure divs, no images, no fonts.
 * Each seed character expands into 3–4 bars whose widths/heights derive
 * from its char code (stable per record); guard bars at both ends (and
 * around the middle) run full height — the real-printer look, clearly
 * ornamental. Shared with the inventory products viewer.
 */
export function BarcodeStrip({
  seed,
  guards = true,
  className,
  barClassName,
}: {
  seed: string;
  guards?: boolean;
  className?: string;
  barClassName?: string;
}) {
  const chars = (seed || "0").replace(/\s+/g, "");
  const bars: { w: number; h: number }[] = [];
  for (const ch of chars) {
    const code = ch.charCodeAt(0);
    const n = 3 + (code % 2);
    for (let k = 0; k < n; k++) {
      const c = code + k * 17;
      bars.push({ w: 1.5 + (c % 3), h: 62 + ((c >> 3) % 38) });
    }
  }
  const last = bars.length - 1;
  const midA = Math.max(2, Math.floor(bars.length / 2));
  const midB = Math.min(last - 2, midA + 1);
  return (
    <div className={cn("flex h-11 items-end justify-center gap-[2px]", className)} aria-hidden="true">
      {bars.map((b, i) => {
        const guard = guards && (i <= 1 || i >= last - 1 || i === midA || i === midB);
        return (
          <span
            key={i}
            className={cn("shrink-0 bg-slate-800 dark:bg-slate-200", barClassName)}
            style={{ width: `${guard ? Math.max(2, b.w) : b.w}px`, height: guard ? "100%" : `${b.h}%` }}
          />
        );
      })}
    </div>
  );
}

/** the tone-colored status pill (business-suite idiom, optional icon). */
export function Pill({ tone, label, icon }: { tone: string; label: string; icon?: string }) {
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1 text-[10.5px] font-extrabold",
        TONE_STYLE[tone] ?? TONE_STYLE.slate
      )}
      dir="auto"
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", TONE_DOT[tone] ?? TONE_DOT.slate)} aria-hidden="true" />
      {icon ? <CatIcon name={icon} className="h-3 w-3" /> : null}
      {label}
    </span>
  );
}

/** lock-styled metadata chip (the pos-terminal idiom, RTL numeral policy). */
function MetaChip({
  icon,
  label,
  value,
  dir,
  mono,
  lang,
}: {
  icon: string;
  label: string;
  value: string;
  dir: "rtl" | "ltr" | "auto";
  mono?: boolean;
  lang: Lang;
}) {
  return (
    <div className="min-w-0 rounded-xl border border-slate-200/80 bg-white/70 px-2.5 py-1.5 dark:border-white/10 dark:bg-white/[0.04]">
      <p className={cn("flex items-center gap-1 text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))} dir="auto">
        <CatIcon name={icon} className="h-2.5 w-2.5 shrink-0" />
        {label}
      </p>
      <p dir={dir} className={cn("truncate text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200", mono && "font-mono tabular-nums")}>
        {value || "—"}
      </p>
    </div>
  );
}

/** mini stat card — icon tile + micro label + formatted value (+ extras). */
export function StatCard({
  icon,
  label,
  value,
  dir,
  valueClass,
  g1,
  g2,
  lang,
  children,
}: {
  icon: string;
  label: string;
  value: string;
  dir: "rtl" | "ltr" | "auto";
  valueClass?: string;
  g1: string;
  g2: string;
  lang: Lang;
  children?: React.ReactNode;
}) {
  return (
    <div className="min-w-0 rounded-2xl border border-black/5 bg-slate-50/60 p-2.5 dark:border-white/10 dark:bg-white/[0.03]">
      <p className={cn("flex items-center gap-1.5 text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))} dir="auto">
        <span
          className="grid h-4 w-4 shrink-0 place-items-center rounded-md text-white"
          style={{ backgroundImage: grad(g1, g2) }}
          aria-hidden="true"
        >
          <CatIcon name={icon} className="h-2.5 w-2.5" />
        </span>
        <span className="truncate">{label}</span>
      </p>
      <p dir={dir} className={cn("mt-1 truncate font-display text-[15px] font-extrabold tabular-nums text-slate-800 dark:text-white", valueClass)}>
        {value}
      </p>
      {children}
    </div>
  );
}

/** section heading — gradient icon chip + label + fading gradient rule. */
export function SectionLabel({ icon, label, g1, g2, lang }: { icon: string; label: string; g1: string; g2: string; lang: Lang }) {
  return (
    <p className="flex items-center gap-2" dir="auto">
      <span className="grid h-5 w-5 shrink-0 place-items-center rounded-lg text-white" style={{ backgroundImage: grad(g1, g2) }} aria-hidden="true">
        <CatIcon name={icon} className="h-3 w-3" />
      </span>
      <span className={cn("shrink-0 text-[10px] font-extrabold uppercase text-slate-500 dark:text-slate-400", labelTrack(lang))}>{label}</span>
      <span className="h-px min-w-0 flex-1 bg-gradient-to-r from-slate-200 to-transparent dark:from-white/10" aria-hidden="true" />
    </p>
  );
}

/** the always-visible action bar (edit + print + close).
 *  ROUND 149 (TASK E.2) — the «Edit» button is the PRIMARY action (brand
 *  gradient, leading icon) so it stands out as the call-to-action; print
 *  stays outline (secondary), close stays the brand-gradient dismiss. */
export function SheetFooter({ t, onEdit, onPrint, onClose, g1, g2 }: { t: TFunc; onEdit?: () => void; onPrint?: () => void; onClose: () => void; g1: string; g2: string }) {
  return (
    <div className="flex shrink-0 flex-wrap items-center justify-end gap-2.5 border-t border-slate-200/70 bg-slate-50/60 px-5 py-3.5 dark:border-white/10 dark:bg-white/[0.02]">
      {onEdit ? (
        <Button
          type="button"
          onClick={onEdit}
          className="h-10 gap-2 rounded-xl px-4 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95"
          style={{ backgroundImage: grad(g1, g2) }}
        >
          <CatIcon name="pencil" className="h-4 w-4" />
          {t("bizEditBtn")}
        </Button>
      ) : null}
      {onPrint ? (
        <Button
          type="button"
          variant="outline"
          onClick={onPrint}
          className="h-10 gap-2 rounded-xl px-4 text-[12.5px] font-bold"
        >
          <CatIcon name="printer" className="h-4 w-4" />
          {t("bizPrintBtn")}
        </Button>
      ) : null}
      <Button
        type="button"
        variant="outline"
        onClick={onClose}
        className="h-10 rounded-xl px-5 text-[12.5px] font-extrabold"
      >
        {t("bizClose")}
      </Button>
    </div>
  );
}

/** created/shift metadata chips (shared footer stamp). */
export function MetaStamps({ record, lang, t, shiftCode }: { record: ModuleRecordDTO; lang: Lang; t: TFunc; shiftCode?: string }) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <span
        dir={numDir(lang)}
        className="inline-flex items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/70 px-2.5 py-1 text-[10px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400"
      >
        <CatIcon name="calendar" className="h-3 w-3 shrink-0" />
        {t("detailCreatedAt")} · {fmtStamp(record.createdAt, lang)}
      </span>
      {record.shiftId ? (
        <span
          dir={numDir(lang)}
          className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/12 px-2.5 py-1 font-mono text-[10px] font-extrabold tabular-nums text-emerald-700 dark:text-emerald-300"
        >
          <CatIcon name="badge-check" className="h-3 w-3 shrink-0" />
          {t("detailShiftStamp")}{shiftCode ? ` · ${fmtId(shiftCode, lang)}` : ""}
        </span>
      ) : (
        <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-500/10 px-2.5 py-1 text-[10px] font-extrabold text-slate-500 dark:text-slate-400">
          <CatIcon name="timer" className="h-3 w-3 shrink-0" />
          {t("detailNoShift")}
        </span>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* MODE 1 — POS · the thermal receipt                                  */
/* ------------------------------------------------------------------ */

function ReceiptMode({ ctx }: { ctx: SheetCtx }) {
  const { record, cols, statuses, moduleName, currency, orgName, lang, t, onPrint, onClose, shiftCode } = ctx;
  const [g1, g2] = RECEIPT_C;
  const val = (key: string): string => {
    const i = cols.findIndex((c) => c.key === key);
    return i >= 0 ? record.values[i] ?? "" : "";
  };
  const code = val("code");
  const st = statuses.find((s) => s.key === record.statusKey);
  const itemsRaw = val("items").trim();
  const discountRaw = val("discount").trim();
  const totalRaw = val("total").trim();
  const discount = Number(discountRaw) || 0;
  const org = orgName?.trim() || moduleName;

  return (
    <>
      {/* letterhead */}
      <div
        className="relative shrink-0 overflow-hidden px-5 pt-5 pb-3"
        style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(g1, 0.16)}, ${hexAlpha(g2, 0.16)})` }}
      >
        <span
          className="absolute -end-8 -top-14 h-28 w-28 rounded-full"
          style={{ background: `radial-gradient(circle, ${hexAlpha(g1, 0.3)}, transparent 70%)` }}
          aria-hidden="true"
        />
        <div className="relative flex items-center gap-3">
          <span
            className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl font-display text-xl font-extrabold text-white shadow-lg"
            style={{ backgroundImage: grad(g1, g2), boxShadow: `0 12px 28px -12px ${hexAlpha(g1, 0.9)}` }}
            aria-hidden="true"
          >
            {initial(org)}
          </span>
          <div className="min-w-0 flex-1">
            <DialogTitle className="truncate font-display text-[15px] font-extrabold leading-tight text-slate-900 dark:text-white">
              {t("receiptTitle")}
            </DialogTitle>
            <DialogDescription className="mt-0.5 truncate text-[11.5px] font-bold text-slate-500 dark:text-slate-400" dir="auto">
              {org}
            </DialogDescription>
          </div>
          {st ? <Pill tone={st.tone} label={lang === "ar" ? st.ar : st.en} /> : null}
        </div>
        <p
          className={cn("relative mt-2 flex items-center gap-1.5 text-[9px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}
          dir="auto"
        >
          <CatIcon name="sparkles" className="h-2.5 w-2.5 shrink-0 text-emerald-500" />
          {t("receiptPoweredBy")}
        </p>
        <div className="mt-3 border-t border-dashed border-slate-300/80 dark:border-white/15" aria-hidden="true" />
      </div>

      {/* receipt body */}
      <div className="nice-scroll min-h-0 flex-1 overflow-y-auto">
        {/* the tx metadata band — system-stamped lock chips */}
        <div className="grid grid-cols-2 gap-2 px-5 py-4 sm:grid-cols-3">
          <MetaChip icon="hash" label={t("posTxNumber")} value={fmtId(code, lang)} dir={idDir} mono lang={lang} />
          <MetaChip icon="user-round" label={t("posCashier")} value={val("cashier")} dir="auto" lang={lang} />
          <MetaChip icon="network" label={t("posBranch")} value={val("branch")} dir="auto" lang={lang} />
          <MetaChip icon="calendar" label={t("posDate")} value={fmtDateCell(val("date"), lang)} dir={numDir(lang)} lang={lang} />
          <MetaChip icon="clock" label={t("posTime")} value={fmtId(val("time"), lang)} dir={idDir} mono lang={lang} />
          <MetaChip icon="wallet" label={t("receiptPaidBy")} value={val("method")} dir="auto" lang={lang} />
        </div>

        {/* ROUND 141 (㉕) — the structured payment ledger summary (mixed
            splits · partial remaining · payable due date + overdue flag);
            rendered only when the record carries a ledger. */}
        {record.payments.length > 0 ? (
          <div className="border-t border-dashed border-slate-300/80 px-5 py-3.5 dark:border-white/15">
            <PaymentsSummary
              entries={record.payments}
              totalMinor={Math.round((Number(totalRaw.replace(/[^\d.-]/g, "")) || 0) * 100)}
              currency={currency ?? "SAR"}
            />
          </div>
        ) : null}

        {/* totals */}
        <div className="border-t border-dashed border-slate-300/80 px-5 py-4 dark:border-white/15">
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-3">
              <span className="text-[11.5px] font-extrabold text-slate-400 dark:text-slate-500">{t("receiptItems")}</span>
              <span dir={numDir(lang)} className="text-[13px] font-extrabold tabular-nums text-slate-700 dark:text-slate-200">
                {itemsRaw ? fmtNum(Number(itemsRaw) || 0, lang) : "—"}
              </span>
            </div>
            <div className="flex items-center justify-between gap-3">
              <span className="text-[11.5px] font-extrabold text-slate-400 dark:text-slate-500">{t("receiptDiscount")}</span>
              <span
                dir={numDir(lang)}
                className={cn("text-[13px] font-extrabold tabular-nums", discount > 0 ? "text-rose-600 dark:text-rose-400" : "text-slate-400")}
              >
                {discountRaw ? (discount > 0 ? `− ${fmtMoneyCell(discount, lang, currency)}` : fmtMoneyCell(discount, lang, currency)) : "—"}
              </span>
            </div>
          </div>
          <div className="mt-3 rounded-2xl border border-emerald-500/20 bg-emerald-500/[0.07] px-4 py-3.5 dark:border-emerald-400/20 dark:bg-emerald-400/[0.08]">
            <p className={cn("text-[9.5px] font-extrabold uppercase text-emerald-700/80 dark:text-emerald-300/90", labelTrack(lang))}>{t("receiptGrand")}</p>
            <p
              dir={numDir(lang)}
              className="bg-clip-text font-display text-[28px] font-extrabold leading-tight text-transparent tabular-nums"
              style={{ backgroundImage: grad("#059669", "#14b8a6") }}
            >
              {totalRaw ? fmtMoneyCell(Number(totalRaw) || 0, lang, currency) : "—"}
            </p>
            <p className="mt-1 text-[9.5px] font-bold italic text-emerald-700/70 dark:text-emerald-300/70" dir="auto">
              {t("receiptVatNote")}
            </p>
          </div>
        </div>

        {/* customer + shift stamps */}
        <div className="border-t border-dashed border-slate-300/80 px-5 py-4 dark:border-white/15">
          <p className={cn("text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>{t("receiptCustomer")}</p>
          {record.meta?.customerName ? (
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <span
                className="inline-flex items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/80 px-2.5 py-1 text-[11.5px] font-extrabold text-slate-700 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200"
                dir="auto"
              >
                <CatIcon name="user-round" className="h-3 w-3 shrink-0 text-slate-400" />
                {record.meta.customerName}
              </span>
              {record.meta.customerPhone ? (
                <span
                  dir={idDir}
                  className="inline-flex items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/80 px-2.5 py-1 font-mono text-[11px] font-bold tabular-nums text-slate-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
                >
                  <CatIcon name="phone" className="h-3 w-3 shrink-0 text-slate-400" />
                  {fmtId(record.meta.customerPhone, lang)}
                </span>
              ) : null}
            </div>
          ) : (
            <p className="mt-2 inline-flex items-center gap-1.5 text-[11.5px] font-bold text-slate-400 dark:text-slate-500" dir="auto">
              <CatIcon name="user-round" className="h-3 w-3 shrink-0" />
              {t("receiptWalkIn")}
            </p>
          )}
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className={cn("text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>{t("receiptShift")}</span>
            {record.shiftId ? (
              <span
                dir={idDir}
                className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/12 px-2.5 py-1 font-mono text-[10.5px] font-extrabold tabular-nums text-emerald-700 dark:text-emerald-300"
              >
                <CatIcon name="badge-check" className="h-3 w-3 shrink-0" />
                {t("detailShiftStamp")}{shiftCode ? ` · ${fmtId(shiftCode, lang)}` : ""}
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-500/10 px-2.5 py-1 text-[10.5px] font-extrabold text-slate-500 dark:text-slate-400">
                <CatIcon name="timer" className="h-3 w-3 shrink-0" />
                {t("detailNoShift")}
              </span>
            )}
          </div>
        </div>

        {/* thanks + decorative barcode */}
        <div className="border-t border-dashed border-slate-300/80 px-5 py-4 text-center dark:border-white/15">
          <p className="text-[12px] font-extrabold text-slate-600 dark:text-slate-300" dir="auto">
            {t("receiptThanks")}
          </p>
          <div className="mx-auto mt-3 max-w-[260px]">
            <BarcodeStrip seed={code || record.id} guards />
            <p dir={idDir} className="mt-1.5 font-mono text-[10px] font-bold tracking-[0.25em] tabular-nums text-slate-500 dark:text-slate-400">
              {fmtId(code || record.id, lang)}
            </p>
          </div>
          <p dir={numDir(lang)} className="mt-2 text-[9.5px] font-bold text-slate-400 dark:text-slate-500">
            {t("detailCreatedAt")} · {fmtStamp(record.createdAt, lang)}
          </p>
        </div>
      </div>

      <SheetFooter t={t} onEdit={ctx.onEdit} onPrint={onPrint} onClose={onClose} g1={g1} g2={g2} />
    </>
  );
}

/* ------------------------------------------------------------------ */
/* MODE 2 — products · the product passport                            */
/* ------------------------------------------------------------------ */

function PassportMode({ ctx }: { ctx: SheetCtx }) {
  const { record, cols, statuses, moduleName, currency, lang, t, onPrint, onClose, shiftCode } = ctx;
  const [g1, g2] = PASSPORT_C;
  const val = (key: string): string => {
    const i = cols.findIndex((c) => c.key === key);
    return i >= 0 ? record.values[i] ?? "" : "";
  };
  const colLabel = (key: string): string => {
    const c = cols.find((x) => x.key === key);
    return c ? (lang === "ar" ? c.ar : c.en) : key;
  };
  const name = val("name").trim() || record.values[0]?.trim() || "—";
  const nameEn = val("nameEn").trim();
  const sku = val("sku").trim();
  const barcode = val("barcode").trim();
  const category = val("category").trim();
  const priceRaw = val("price").trim();
  const costRaw = val("cost").trim();
  const stockRaw = val("stock").trim();
  const reorderRaw = val("reorder").trim();
  const soldRaw = val("sold").trim();
  const marginRaw = val("margin").trim();
  const vatRaw = val("vat").trim();
  const stock = Number(stockRaw) || 0;
  const reorder = Number(reorderRaw) || 0;
  const price = Number(priceRaw) || 0;
  const sale = record.salePrice != null ? record.salePrice / 100 : null; /* minor units → display */
  const st = statuses.find((s) => s.key === record.statusKey);
  const isEan = /^\d{10,13}$/.test(barcode);
  const health = stock <= 0 ? "out" : stock <= reorder ? "low" : "ok";
  const barWidth = Math.min(100, Math.max(6, (stock / Math.max(1, reorder * 4)) * 100));

  return (
    <>
      {/* passport header — photo (or gradient monogram) + name + status */}
      <div
        className="relative shrink-0 overflow-hidden border-b border-slate-200/70 px-5 pt-4 pb-4 dark:border-white/10"
        style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(g1, 0.16)}, ${hexAlpha(g2, 0.16)})` }}
      >
        <span
          className="absolute -end-8 -top-14 h-28 w-28 rounded-full"
          style={{ background: `radial-gradient(circle, ${hexAlpha(g1, 0.28)}, transparent 70%)` }}
          aria-hidden="true"
        />
        <div className="relative flex items-start gap-3.5">
          {record.imageRef ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={record.imageRef}
              alt={name}
              className="h-16 w-16 shrink-0 rounded-2xl border border-black/5 object-cover shadow-lg dark:border-white/10"
            />
          ) : (
            <span
              className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl font-display text-2xl font-extrabold text-white shadow-lg"
              style={{ backgroundImage: grad(g1, g2), boxShadow: `0 12px 28px -12px ${hexAlpha(g1, 0.9)}` }}
              aria-hidden="true"
            >
              {initial(name)}
            </span>
          )}
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
              <DialogTitle className="truncate font-display text-[16px] font-extrabold leading-tight text-slate-900 dark:text-white" dir="auto">
                {name}
              </DialogTitle>
              {record.featured ? (
                <span
                  className="inline-flex items-center gap-1 rounded-full bg-amber-400/15 px-2 py-0.5 text-[9.5px] font-extrabold text-amber-600 dark:text-amber-400"
                  title={t("storeFilterFeatured")}
                >
                  <CatIcon name="star" className="h-2.5 w-2.5 fill-amber-400 text-amber-500" />
                </span>
              ) : null}
            </div>
            {nameEn && nameEn !== name ? (
              <DialogDescription className="mt-0.5 truncate text-[11.5px] font-bold text-slate-500 dark:text-slate-400" dir="auto">
                {nameEn}
              </DialogDescription>
            ) : (
              <DialogDescription className="mt-0.5 truncate text-[11.5px] font-bold text-slate-500 dark:text-slate-400">
                {t("productPassport")} · {moduleName}
              </DialogDescription>
            )}
            <div className="mt-2 flex flex-wrap items-center gap-2">
              {st ? <Pill tone={st.tone} label={lang === "ar" ? st.ar : st.en} /> : null}
              {sku ? (
                <span
                  dir={idDir}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-slate-100 px-2 py-1 font-mono text-[10.5px] font-bold tabular-nums text-slate-600 dark:bg-white/10 dark:text-slate-300"
                >
                  <CatIcon name="hash" className="h-3 w-3 shrink-0 text-slate-400" />
                  {fmtId(sku, lang)}
                </span>
              ) : null}
              {nameEn && nameEn !== name ? (
                <span className="text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500" dir="auto">
                  {t("productPassport")}
                </span>
              ) : null}
            </div>
          </div>
        </div>
      </div>

      {/* passport body */}
      <div className="nice-scroll min-h-0 flex-1 space-y-4 overflow-y-auto px-5 py-4">
        {/* sale banner */}
        {sale != null ? (
          <div
            className="flex flex-wrap items-center justify-between gap-x-3 gap-y-2 rounded-2xl border border-amber-400/30 px-3.5 py-2.5"
            style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha("#f59e0b", 0.12)}, ${hexAlpha("#f43f5e", 0.12)})` }}
          >
            <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-500/90 px-2.5 py-1 text-[10px] font-extrabold text-white shadow-sm">
              <CatIcon name="ticket-percent" className="h-3 w-3" />
              {t("estoreSaleChip")}
            </span>
            <span dir={numDir(lang)} className="text-[15px] font-extrabold tabular-nums text-amber-700 dark:text-amber-400">
              {fmtMoneyCell(sale, lang, currency)}
              <span className="ms-2 text-[11px] font-bold text-slate-400 line-through">{priceRaw ? fmtMoneyCell(price, lang, currency) : ""}</span>
            </span>
            {record.saleEndsAt ? (
              <span className="inline-flex items-center gap-1.5 text-[10.5px] font-bold text-slate-500 dark:text-slate-400" dir="auto">
                <CatIcon name="calendar-clock" className="h-3 w-3 shrink-0" />
                {t("estoreSaleEndLabel")}: {fmtDateCell(record.saleEndsAt.slice(0, 10), lang)}
              </span>
            ) : null}
          </div>
        ) : null}

        {/* the barcode block — EAN-13 visual or code chip */}
        {isEan ? (
          <div className="rounded-2xl border border-slate-200/80 bg-slate-50/60 px-4 py-3.5 dark:border-white/10 dark:bg-white/[0.03]">
            <p className={cn("text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))} dir="auto">
              {colLabel("barcode")}
            </p>
            <BarcodeStrip seed={barcode} guards className="mt-1.5" />
            <p dir={idDir} className="mt-2 text-center font-mono text-[11.5px] font-bold tracking-[0.3em] tabular-nums text-slate-600 dark:text-slate-300">
              {fmtId(barcode, lang)}
            </p>
          </div>
        ) : null}

        {/* stats grid */}
        <div className="space-y-2.5">
          <SectionLabel icon="sigma" label={t("detailSectionNumbers")} g1={g1} g2={g2} lang={lang} />
          <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
            <StatCard icon="tag" label={colLabel("price")} value={priceRaw ? fmtMoneyCell(price, lang, currency) : "—"} dir={numDir(lang)} valueClass="text-emerald-600 dark:text-emerald-400" g1="#10b981" g2="#059669" lang={lang} />
            <StatCard icon="wallet" label={colLabel("cost")} value={costRaw ? fmtMoneyCell(Number(costRaw) || 0, lang, currency) : "—"} dir={numDir(lang)} g1="#0ea5e9" g2="#0369a1" lang={lang} />
            <StatCard icon="boxes" label={colLabel("stock")} value={stockRaw ? fmtNum(stock, lang) : "—"} dir={numDir(lang)} valueClass={health === "out" ? "text-rose-600 dark:text-rose-400" : health === "low" ? "text-amber-600 dark:text-amber-400" : undefined} g1="#8b5cf6" g2="#7c3aed" lang={lang}>
              <div className="mt-1.5 h-1 w-full overflow-hidden rounded-full bg-slate-200/80 dark:bg-white/10">
                <div
                  className={cn("h-full rounded-full transition-all duration-500", health === "out" ? "bg-rose-500" : health === "low" ? "bg-amber-500" : "bg-emerald-500")}
                  style={{ width: `${barWidth}%` }}
                />
              </div>
              <p dir={numDir(lang)} className="mt-1 text-[9px] font-bold tabular-nums text-slate-400 dark:text-slate-500">
                {colLabel("reorder")}: {reorderRaw ? fmtNum(reorder, lang) : "—"}
              </p>
            </StatCard>
            <StatCard icon="trending-up" label={colLabel("sold")} value={soldRaw ? fmtNum(Number(soldRaw) || 0, lang) : "—"} dir={numDir(lang)} g1="#0ea5e9" g2="#0284c7" lang={lang} />
            <StatCard icon="percent" label={colLabel("margin")} value={marginRaw ? `${fmtNum(Number(marginRaw) || 0, lang)}%` : "—"} dir={numDir(lang)} g1="#14b8a6" g2="#0d9488" lang={lang} />
            <StatCard icon="receipt" label={colLabel("vat")} value={vatRaw ? `${fmtNum(Number(vatRaw) || 0, lang)}%` : "—"} dir={numDir(lang)} g1="#64748b" g2="#475569" lang={lang} />
          </div>
        </div>

        {/* record metadata */}
        <div className="space-y-2.5">
          <SectionLabel icon="clock" label={t("detailSectionMeta")} g1={g1} g2={g2} lang={lang} />
          <div className="flex flex-wrap items-center gap-2">
            {category ? (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/70 px-2.5 py-1 text-[10.5px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300" dir="auto">
                <CatIcon name="tag" className="h-3 w-3 shrink-0 text-slate-400" />
                {category}
              </span>
            ) : null}
            <MetaStamps record={record} lang={lang} t={t} shiftCode={shiftCode} />
          </div>
        </div>
      </div>

      <SheetFooter t={t} onEdit={ctx.onEdit} onPrint={onPrint} onClose={onClose} g1={g1} g2={g2} />
    </>
  );
}

/* ------------------------------------------------------------------ */
/* the exported sheet                                                  */
/* ------------------------------------------------------------------ */

/**
 * The premium «تفاصيل السجل» sheet. Props contract (wired by
 * business-suite.tsx):
 *
 *   open / onOpenChange — Radix dialog control
 *   moduleId            — "pos" | "products" | "customers" | any module id
 *   record              — the ModuleRecordDTO to display (null → nothing)
 *   cols / statuses     — the module preset's ColDef[] / StatusDef[]
 *   moduleName          — localized display name of the module
 *   currency            — org currency code (e.g. "SAR"), optional
 *   orgName             — instance org name (receipt letterhead), optional
 *   onPrint             — optional print callback (footer print button)
 */
export function RecordDetailSheet({
  open,
  onOpenChange,
  moduleId,
  record,
  cols,
  statuses,
  moduleName,
  currency,
  orgName,
  instanceId,
  onEdit,
  onPrint,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  moduleId: string;
  record: ModuleRecordDTO | null;
  cols: ColDef[];
  statuses: StatusDef[];
  moduleName: string;
  currency?: string;
  orgName?: string;
  /** ROUND 133 fix — resolves the record's shift cuid → the HUMAN shift code
   *  (SHF-…) through the shared shift cache (current + history). */
  instanceId?: string;
  /** ROUND 149 (TASK E.2) — the «Edit» button callback; opens the record
   *  dialog in edit mode. Undefined → no Edit button (e.g. demo rows). */
  onEdit?: () => void;
  onPrint?: () => void;
}) {
  const { t, lang } = useT();

  /* resolve the shift stamp's HUMAN code (the record carries only the cuid;
   * the shared ["shifts", id] cache carries the code — current or history) */
  const shiftsQuery = useShift(instanceId);
  const shiftId = record?.shiftId ?? null;
  const shiftsData = shiftsQuery.data ?? null;
  const shiftCode = useMemo(() => {
    if (!shiftId || !shiftsData) return undefined;
    const { current, history } = shiftsData;
    if (current?.id === shiftId) return current.code;
    return history.find((h) => h.id === shiftId)?.code;
  }, [shiftId, shiftsData]);

  /* no record → render nothing (the parent usually keeps open === !!record) */
  if (!record) return null;

  const ctx: SheetCtx = {
    record,
    cols,
    statuses,
    moduleName,
    currency,
    orgName,
    lang,
    t,
    onPrint,
    onEdit,
    onClose: () => onOpenChange(false),
    shiftCode,
  };

  /* R163 — the fourteen clinical + financial families (patients, ehr,
   * appointments, operations, emergency, telemedicine, insurance, beds,
   * radiology, lab, prescriptions, pharmacy, invoices, expenses) render the
   * per-module MEDICAL blueprints (medical-detail-modes.tsx) instead of the
   * generic field passport — the owner's «إعادة تطوير تفاصيل السجل».
   * staff keeps its own dedicated ROUND-156.1 profile sheet upstream.
   *
   * ROUND 164 — the OLD generic + customer-profile modes were DELETED and
   * rebuilt as the premium family-tinted RecordDetailDrawer
   * (record-detail-drawer.tsx); business-suite routes every
   * non-specialized module there, so this sheet now only ever serves the
   * pos receipt, the products passport, and the medical blueprints (the
   * dispatch below stays defensive for any direct caller). */
  const mode: "receipt" | "passport" | "medical" =
    moduleId === "pos"
      ? "receipt"
      : moduleId === "products"
        ? "passport"
        : "medical";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        dir={lang === "ar" ? "rtl" : "ltr"}
        showCloseButton={false}
        className={cn(
          "flex max-h-[88vh] flex-col gap-0 overflow-hidden rounded-3xl p-0",
          mode === "receipt" ? "sm:max-w-md" : "sm:max-w-xl"
        )}
      >
        {mode === "receipt" ? (
          <ReceiptMode ctx={ctx} />
        ) : mode === "passport" ? (
          <PassportMode ctx={ctx} />
        ) : (
          <MedicalDetailMode ctx={ctx} moduleId={moduleId} />
        )}
      </DialogContent>
    </Dialog>
  );
}
