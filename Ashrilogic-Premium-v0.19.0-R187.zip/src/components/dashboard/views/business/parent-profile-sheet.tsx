"use client";

/**
 * Ashrilogic — the PREMIUM parent profile sheet (ROUND 156).
 *
 * The owner's directive:
 *   «في جميع الأنظمة عند وحدة (أولياء الأمور) قم بحذف الصفحة (تفاصيل
 *    السجل أولياء الأمور) كاملة وإعادة تطويرها بطريقة مميزة وPremium
 *    بدقة عالية ومتصل بشكل جديد»
 *
 * The parents module previously fell through to the generic MODE 4 grouped
 * passport inside RecordDetailSheet — a flat field list with no family
 * identity and no visible "new connection" to the student. This dedicated
 * sheet replaces it with a premium card-based parent profile (parity with
 * the StudentProfileSheet pattern from ROUND 155):
 *
 *   • HEADER          — gradient avatar (initials), parent display name, the
 *                       bilingual "Parent profile" sub-line, Parent code chip
 *                       (mono, RTL bidi-safe), and the link-status pill
 *                       (linked / pending / inactive).
 *   • STUDENT LINK    — a single prominent gradient card showing the linked
 *                       student name + the relation (صلة القرابة) — the
 *                       «الصلة بالطالب» "new connection" the directive asked
 *                       for. Carries a directional arrow that flips with the
 *                       dialog's RTL/LTR direction so the link reads
 *                       parent → student visually in either locale.
 *   • CONTACT         — a 3-card grid: phone (primary, LTR within RTL),
 *                       alt phone (LTR within RTL), email (LTR within RTL).
 *   • IDENTITY        — a stat-card grid: national ID (mono), occupation,
 *                       workplace, city, address.
 *   • META            — created-at + last-updated stamp row (parity with the
 *                       generic record-detail sheet footer).
 *
 * Purity contract: every value is read off the row by column key (the same
 * ModuleRecordDTO + ColDef[] + StatusDef[] props the parent already passes
 * RecordDetailSheet). Every numeric / ID value renders through the ROUND 133
 * helpers (fmtId / fmtNum with dir={idDir}/{numDir}) so the Arabic locale
 * shows Arabic-Indic digits with the correct bidi embedding.
 *
 * Bilingual (AR/EN) with full RTL support — the sheet inherits the dialog's
 * dir={lang === "ar" ? "rtl" : "ltr"} from the parent and every text node
 * uses dir="auto" / labelTrack(lang) for the uppercase Latin-tracking
 * micro-labels. The new i18n keys (parentProfileTitle, parentStudentLink,
 * parentRelation, …) live in src/lib/i18n/domains/business.ts in all three
 * locales (AR + EN + HI) for type parity.
 */
import { useT, type I18nKey } from "@/lib/i18n";
import type { ColDef, StatusDef } from "@/lib/module-data";
import type { Lang, ModuleRecordDTO } from "@/lib/types";
import {
  cn,
  fmtId,
  grad,
  hexAlpha,
  idDir,
  initial,
  labelTrack,
  numDir,
  toArabicDigits,
} from "@/lib/utils";
import { CatIcon } from "@/components/icon";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";

/* ------------------------------------------------------------------ */
/* tone maps — the exact business-suite / inv-shared pill idiom        */
/* ------------------------------------------------------------------ */

const TONE_DOT: Record<string, string> = {
  emerald: "bg-emerald-500",
  amber: "bg-amber-500",
  rose: "bg-rose-500",
  sky: "bg-sky-500",
  violet: "bg-violet-500",
  slate: "bg-slate-400",
};

const TONE_STYLE: Record<string, string> = {
  emerald: "bg-emerald-500/12 text-emerald-700 dark:text-emerald-300",
  amber: "bg-amber-500/12 text-amber-700 dark:text-amber-300",
  rose: "bg-rose-500/12 text-rose-700 dark:text-rose-300",
  sky: "bg-sky-500/12 text-sky-700 dark:text-sky-300",
  violet: "bg-violet-500/12 text-violet-700 dark:text-violet-300",
  slate: "bg-slate-500/12 text-slate-600 dark:text-slate-300",
};

/* the parents brand gradient — a warm emerald → sky pair (mirrors the
 * `linked` status's emerald + the family-bond visual cue). Stays inside
 * the brand family while distinguishing the parents module from students
 * (indigo→violet) and teachers (indigo→violet too). */
const PARENT_C = ["#10b981", "#0ea5e9"] as const;

/* per-status gradient (for the student-link card's accent). */
const STATUS_GRAD: Record<string, [string, string]> = {
  emerald: ["#10b981", "#059669"],
  sky: ["#0ea5e9", "#0284c7"],
  amber: ["#f59e0b", "#d97706"],
  rose: ["#f43f5e", "#be123c"],
  violet: ["#8b5cf6", "#6d5dfb"],
  slate: ["#64748b", "#475569"],
};

type TFunc = (key: I18nKey, vars?: Record<string, string | number>) => string;

/* ------------------------------------------------------------------ */
/* shared atoms (parity with student-profile-sheet)                     */
/* ------------------------------------------------------------------ */

/** ROUND 156.1 (TASK PRINT+ARABIC+CERT+STAFF) — the owner's directive:
 *  «عند استخدام اللغة العربية اجعل الأرقام (1,2,3,4,5) ايضاً تدعم
 *   النمط العربي» — every ASCII digit in the parent profile sheet renders
 *  as Arabic-Indic (٠..٩) when the UI is Arabic. Scoped to THIS surface
 *  only (table + print surfaces keep ROUND 134's Western-ID policy). */
function arNumIfAR(text: string, lang: Lang): string {
  if (!text) return text;
  return lang === "ar" ? toArabicDigits(text) : text;
}

/** created/updated-stamp — medium date + HH:MM, same locale policy. */
function fmtStamp(iso: string, lang: Lang): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  const date = d.toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB", { dateStyle: "medium" });
  const time = d.toLocaleTimeString(lang === "ar" ? "ar-EG" : "en-GB", { hour: "2-digit", minute: "2-digit" });
  return `${date} · ${time}`;
}

/** the tone-colored status pill (business-suite idiom, optional icon). */
function Pill({ tone, label, icon }: { tone: string; label: string; icon?: string }) {
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1 text-[10.5px] font-extrabold",
        TONE_STYLE[tone] ?? TONE_STYLE.slate
      )}
      dir="auto"
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", TONE_DOT[tone] ?? TONE_DOT.slate)} aria-hidden="true" />
      {icon ? <CatIcon name={icon} className="h-3 w-3" /> : null}
      {label}
    </span>
  );
}

/** section heading — gradient icon chip + label + fading gradient rule. */
function SectionLabel({ icon, label, g1, g2, lang }: { icon: string; label: string; g1: string; g2: string; lang: Lang }) {
  return (
    <p className="flex items-center gap-2" dir="auto">
      <span className="grid h-5 w-5 shrink-0 place-items-center rounded-lg text-white" style={{ backgroundImage: grad(g1, g2) }} aria-hidden="true">
        <CatIcon name={icon} className="h-3 w-3" />
      </span>
      <span className={cn("shrink-0 text-[10px] font-extrabold uppercase text-slate-500 dark:text-slate-400", labelTrack(lang))}>{label}</span>
      <span className="h-px min-w-0 flex-1 bg-gradient-to-r from-slate-200 to-transparent dark:from-white/10" aria-hidden="true" />
    </p>
  );
}

/** mini stat card — icon tile + micro label + formatted value. */
function StatCard({
  icon,
  label,
  value,
  dir,
  valueClass,
  g1,
  g2,
  lang,
}: {
  icon: string;
  label: string;
  value: string;
  dir: "rtl" | "ltr" | "auto";
  valueClass?: string;
  g1: string;
  g2: string;
  lang: Lang;
}) {
  return (
    <div className="min-w-0 rounded-2xl border border-black/5 bg-slate-50/60 p-2.5 dark:border-white/10 dark:bg-white/[0.03]">
      <p className={cn("flex items-center gap-1.5 text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))} dir="auto">
        <span
          className="grid h-4 w-4 shrink-0 place-items-center rounded-md text-white"
          style={{ backgroundImage: grad(g1, g2) }}
          aria-hidden="true"
        >
          <CatIcon name={icon} className="h-2.5 w-2.5" />
        </span>
        <span className="truncate">{label}</span>
      </p>
      <p dir={dir} className={cn("mt-1 truncate font-display text-[14px] font-extrabold tabular-nums text-slate-800 dark:text-white", valueClass)}>
        {value}
      </p>
    </div>
  );
}

/** the always-visible action bar (edit + print + close). */
function SheetFooter({ t, onEdit, onPrint, onClose, g1, g2 }: { t: TFunc; onEdit?: () => void; onPrint?: () => void; onClose: () => void; g1: string; g2: string }) {
  return (
    <div className="flex shrink-0 flex-wrap items-center justify-end gap-2.5 border-t border-slate-200/70 bg-slate-50/60 px-5 py-3.5 dark:border-white/10 dark:bg-white/[0.02]">
      {onEdit ? (
        <Button
          type="button"
          onClick={onEdit}
          className="h-10 gap-2 rounded-xl px-4 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95"
          style={{ backgroundImage: grad(g1, g2) }}
        >
          <CatIcon name="pencil" className="h-4 w-4" />
          {t("bizEditBtn")}
        </Button>
      ) : null}
      {onPrint ? (
        <Button
          type="button"
          variant="outline"
          onClick={onPrint}
          className="h-10 gap-2 rounded-xl px-4 text-[12.5px] font-bold"
        >
          <CatIcon name="printer" className="h-4 w-4" />
          {t("bizPrintBtn")}
        </Button>
      ) : null}
      <Button
        type="button"
        variant="outline"
        onClick={onClose}
        className="h-10 rounded-xl px-5 text-[12.5px] font-extrabold"
      >
        {t("bizClose")}
      </Button>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* the premium parent profile sheet                                    */
/* ------------------------------------------------------------------ */

/**
 * The premium «ملف ولي الأمر» sheet. Props contract (wired by
 * business-suite.tsx — same shape as StudentProfileSheet / TeacherProfileSheet
 * so the swap is a one-line conditional):
 *
 *   open / onOpenChange — Radix dialog control
 *   record              — the ModuleRecordDTO to display (null → nothing)
 *   cols / statuses      — the module preset's ColDef[] / StatusDef[]
 *   moduleName           — localized display name of the module
 *   onPrint              — optional print callback (footer print button)
 *   onEdit               — optional edit callback (footer edit button)
 */
export function ParentProfileSheet({
  open,
  onOpenChange,
  record,
  cols,
  statuses,
  moduleName,
  onEdit,
  onPrint,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  record: ModuleRecordDTO | null;
  cols: ColDef[];
  statuses: StatusDef[];
  moduleName: string;
  onEdit?: () => void;
  onPrint?: () => void;
}) {
  const { t, lang } = useT();
  const [g1, g2] = PARENT_C;

  if (!record) return null;

  /* read every cell by column key (the parents preset contract):
   *   code, parent, nationalId, phone, altPhone, email, occupation,
   *   workplace, city, address, student, relation, status */
  const val = (key: string): string => {
    const i = cols.findIndex((c) => c.key === key);
    return i >= 0 ? record.values[i] ?? "" : "";
  };

  const name = val("parent").trim() || record.values[1]?.trim() || record.values[0]?.trim() || "—";
  const code = val("code").trim();
  const nationalId = val("nationalId").trim();
  const phone = val("phone").trim();
  const altPhone = val("altPhone").trim();
  const email = val("email").trim();
  const occupation = val("occupation").trim();
  const workplace = val("workplace").trim();
  const city = val("city").trim();
  const address = val("address").trim();
  const student = val("student").trim();
  const relation = val("relation").trim();

  const st = statuses.find((s) => s.key === record.statusKey);
  const tone = st?.tone ?? "slate";
  const [ag1, ag2] = STATUS_GRAD[tone] ?? STATUS_GRAD.slate;

  /* the link-status headline — a one-line localized verdict driven by tone */
  const statusKey: I18nKey =
    tone === "emerald" ? "parentStatusLinked"
      : tone === "amber" ? "parentStatusPending"
        : tone === "slate" ? "parentStatusInactive"
          : "parentStatusLinked";
  const statusHeadline = t(statusKey);

  /* the directional arrow for the student-link card — flips with the
   * dialog's RTL/LTR direction so the link reads parent → student visually
   * in either locale. (AR is RTL, so the arrow points left for AR; EN/HI
   * are LTR, so the arrow points right.) */
  const linkArrowName = lang === "ar" ? "arrow-left" : "arrow-right";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        dir={lang === "ar" ? "rtl" : "ltr"}
        showCloseButton={false}
        className="flex max-h-[88vh] flex-col gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-xl"
      >
        {/* ---------------- header — gradient avatar + name + IDs + status ---------------- */}
        <div
          className="relative shrink-0 overflow-hidden border-b border-slate-200/70 px-5 pt-5 pb-4 dark:border-white/10"
          style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(g1, 0.16)}, ${hexAlpha(g2, 0.16)})` }}
        >
          <span
            className="absolute -end-8 -top-14 h-28 w-28 rounded-full"
            style={{ background: `radial-gradient(circle, ${hexAlpha(g1, 0.28)}, transparent 70%)` }}
            aria-hidden="true"
          />
          <span
            className="absolute -start-10 -bottom-16 h-32 w-32 rounded-full"
            style={{ background: `radial-gradient(circle, ${hexAlpha(g2, 0.18)}, transparent 70%)` }}
            aria-hidden="true"
          />
          <div className="relative flex items-center gap-3.5">
            <span
              className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl font-display text-2xl font-extrabold text-white shadow-lg"
              style={{ backgroundImage: grad(g1, g2), boxShadow: `0 12px 28px -12px ${hexAlpha(g1, 0.9)}` }}
              aria-hidden="true"
            >
              {initial(name)}
            </span>
            <div className="min-w-0 flex-1">
              <DialogTitle className="truncate font-display text-[16px] font-extrabold leading-tight text-slate-900 dark:text-white" dir="auto">
                {name}
              </DialogTitle>
              <DialogDescription className="mt-0.5 truncate text-[11.5px] font-bold text-slate-500 dark:text-slate-400" dir="auto">
                {t("parentProfileTitle")} · {moduleName}
              </DialogDescription>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                {st ? <Pill tone={st.tone} label={lang === "ar" ? st.ar : st.en} icon={tone === "emerald" ? "link" : tone === "slate" ? "triangle-alert" : undefined} /> : null}
                {code ? (
                  <span
                    dir={idDir}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-slate-100 px-2 py-1 font-mono text-[10.5px] font-bold tabular-nums text-slate-600 dark:bg-white/10 dark:text-slate-300"
                  >
                    <CatIcon name="hash" className="h-3 w-3 shrink-0 text-slate-400" />
                    {t("parentCode")}: {arNumIfAR(fmtId(code, lang), lang)}
                  </span>
                ) : null}
              </div>
            </div>
          </div>
        </div>

        {/* ---------------- body ---------------- */}
        <div className="nice-scroll min-h-0 flex-1 space-y-4 overflow-y-auto px-5 py-4">
          {/* ---------- student link section — the "new connection" ---------- */}
          <div className="space-y-2.5">
            <SectionLabel icon="link" label={t("parentStudentLink")} g1={g1} g2={g2} lang={lang} />
            <div
              className="flex items-center gap-3 rounded-2xl border border-black/5 p-3.5 dark:border-white/10"
              style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(ag1, 0.12)}, ${hexAlpha(ag2, 0.08)})` }}
            >
              {/* the parent-side mini avatar (the same gradient avatar as the
               * header) — visually anchors the "from" side of the link. */}
              <span
                className="grid h-12 w-12 shrink-0 place-items-center rounded-xl font-display text-lg font-extrabold text-white shadow"
                style={{ backgroundImage: grad(g1, g2) }}
                aria-hidden="true"
              >
                {initial(name)}
              </span>
              {/* the directional arrow — flips with the dialog's dir so it
               * always reads parent → student. */}
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-white text-slate-400 shadow-sm dark:bg-white/10 dark:text-slate-300"
                aria-hidden="true"
              >
                <CatIcon name={linkArrowName} className="h-4 w-4" />
              </span>
              {/* the student-side avatar + name + relation strip. */}
              <div className="min-w-0 flex-1">
                {student ? (
                  <>
                    <p className={cn("text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))} dir="auto">
                      {t("parentStudent")}
                    </p>
                    <p dir="auto" className="mt-0.5 truncate font-display text-[15px] font-extrabold text-slate-800 dark:text-white">
                      {student}
                    </p>
                    <p className="mt-0.5 text-[10.5px] font-bold" style={{ color: ag2 }} dir="auto">
                      {relation ? `${t("parentRelation")}: ${relation}` : statusHeadline}
                    </p>
                  </>
                ) : (
                  <p className="text-[12.5px] font-bold italic text-slate-400" dir="auto">
                    {t("parentNoStudent")}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* ---------- contact section ---------- */}
          <div className="space-y-2.5">
            <SectionLabel icon="phone" label={t("parentContact")} g1={g1} g2={g2} lang={lang} />
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-3">
              {/* phone (primary) — LTR within RTL */}
              <StatCard
                icon="smartphone"
                label={t("parentPhone")}
                value={phone ? arNumIfAR(phone, lang) : "—"}
                dir="ltr"
                g1="#10b981" g2="#059669"
                lang={lang}
                valueClass={phone ? "" : "italic text-slate-400"}
              />
              {/* alt phone — LTR within RTL */}
              <StatCard
                icon="phone"
                label={t("parentAltPhone")}
                value={altPhone ? arNumIfAR(altPhone, lang) : "—"}
                dir="ltr"
                g1="#0ea5e9" g2="#0284c7"
                lang={lang}
                valueClass={altPhone ? "" : "italic text-slate-400"}
              />
              {/* email — LTR within RTL */}
              <StatCard
                icon="mail"
                label={t("parentEmail")}
                value={email || "—"}
                dir="ltr"
                g1="#8b5cf6" g2="#6d5dfb"
                lang={lang}
                valueClass={email ? "" : "italic text-slate-400"}
              />
            </div>
          </div>

          {/* ---------- identity & occupation section ---------- */}
          <div className="space-y-2.5">
            <SectionLabel icon="id-card" label={t("parentIdentity")} g1={g1} g2={g2} lang={lang} />
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              {/* national ID — mono LTR */}
              <StatCard
                icon="hash"
                label={t("parentNationalId")}
                value={nationalId ? arNumIfAR(nationalId, lang) : "—"}
                dir={numDir(lang)}
                g1="#475569" g2="#334155"
                lang={lang}
                valueClass="font-mono text-[13px]"
              />
              {/* occupation */}
              <StatCard
                icon="briefcase"
                label={t("parentOccupation")}
                value={occupation || "—"}
                dir="auto"
                g1="#f59e0b" g2="#d97706"
                lang={lang}
                valueClass={occupation ? "" : "italic text-slate-400"}
              />
              {/* workplace */}
              <StatCard
                icon="landmark"
                label={t("parentWorkplace")}
                value={workplace || "—"}
                dir="auto"
                g1="#6366f1" g2="#4f46e5"
                lang={lang}
                valueClass={workplace ? "" : "italic text-slate-400"}
              />
              {/* city */}
              <StatCard
                icon="map-pin"
                label={t("parentCity")}
                value={city || "—"}
                dir="auto"
                g1="#0ea5e9" g2="#0369a1"
                lang={lang}
                valueClass={city ? "" : "italic text-slate-400"}
              />
            </div>
            {/* address — full-width banner */}
            <div className="flex items-center justify-between gap-3 rounded-2xl border border-black/5 bg-slate-50/60 px-3.5 py-2.5 dark:border-white/10 dark:bg-white/[0.03]">
              <span className="flex items-center gap-2 text-[11.5px] font-extrabold text-slate-400 dark:text-slate-500" dir="auto">
                <CatIcon name="house" className="h-4 w-4 shrink-0 text-slate-400" />
                {t("parentAddress")}
              </span>
              <span dir="auto" className="truncate font-display text-[13.5px] font-extrabold text-slate-700 dark:text-slate-200">
                {address || "—"}
              </span>
            </div>
          </div>

          {/* ---------- meta stamps ---------- */}
          <div className="flex flex-wrap items-center gap-2">
            <span
              dir={numDir(lang)}
              className="inline-flex items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/70 px-2.5 py-1 text-[10px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400"
            >
              <CatIcon name="calendar" className="h-3 w-3 shrink-0" />
              {t("parentMetaStamp")} · {fmtStamp(record.updatedAt || record.createdAt, lang)}
            </span>
            <span
              dir="auto"
              className="inline-flex items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/70 px-2.5 py-1 text-[10px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400"
            >
              <CatIcon name="users" className="h-3 w-3 shrink-0" />
              {statusHeadline}
            </span>
          </div>
        </div>

        <SheetFooter t={t} onEdit={onEdit} onPrint={onPrint} onClose={() => onOpenChange(false)} g1={g1} g2={g2} />
      </DialogContent>
    </Dialog>
  );
}
