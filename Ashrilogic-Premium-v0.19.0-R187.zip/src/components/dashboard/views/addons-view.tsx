"use client";

/**
 * Ashrilogic — ROUND 141: متجر الإضافات (the Add-ons Store).
 *
 * The owner's directive: a dedicated page for purchasing FEATURES not
 * included in the subscription package, professionally and Premium.
 *
 * Design:
 *  - the FULL feature catalog, grouped by the platform's canonical groups
 *    (presence / commerce / intelligence / data / premium modules), each
 *    card showing its LIVE state: already-active (in plan / trial /
 *    platform / a prior add-on) or purchasable with its per-cycle price;
 *  - a selection cart (checkbox chips on the cards + a sticky summary
 *    bar) → the checkout dialog: cycle picker (monthly / yearly with the
 *    two-months-free saving chip), the console-managed payment methods,
 *    then the invoice step (reference + server-built payment instructions
 *    + copy) — the SAME pipeline the subscription page uses;
 *  - money is ALWAYS server-computed (the POST sends feature keys +
 *    cycle + method only); on the platform's payment confirmation the
 *    features unlock instantly workspace-wide (featureOverridesJson
 *    force-ON);
 *  - the workspace's own add-on order history (pending orders
 *    cancellable) rides at the bottom;
 *  - ROUND 147 — currency honesty: every money line shows the LIVE
 *    currency (each order's own server-stamped AddonOrderDTO.currency —
 *    never a hardcoded "SAR"), the order rows + the invoice step carry
 *    the server-verified HMAC integrity chip (the billing-view idiom),
 *    and a failed catalog fetch renders the error + retry state instead
 *    of a silently blank region.
 */
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import type { I18nKey } from "@/lib/i18n";
import { useT } from "@/lib/i18n";
import type { AddonCatalogItemDTO, AddonOrderDTO, InstanceDTO, PaymentMethod, PaymentInstructionsDTO } from "@/lib/types";
import { WALLET_CHECKOUT_METHOD_ID } from "@/lib/types";
import { WalletCheckoutOption } from "@/components/dashboard/wallet-widgets";
import { FEATURE_GROUPS, FEATURE_META, type PlanFeature } from "@/lib/plan-features";
import {
  cancelAddonOrder,
  createAddonOrder,
  fetchAddonCatalog,
  fetchPlanMethods,
  fetchWallet,
} from "@/lib/api-client";
import { apiErrorText } from "@/lib/api-errors";
import { fmtPlanPrice } from "@/lib/format";
import { CatIcon } from "@/components/icon";
import { cn, copyText, grad, hexAlpha } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { DashCard, ViewHeading } from "@/components/dashboard/dash-shared";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

/* kind metadata (icon / gradient) for the payment-method rows. */
const METHOD_KIND_META: Record<PaymentMethod, { icon: string; c1: string; c2: string; labelKey: I18nKey }> = {
  bank: { icon: "landmark", c1: "#0ea5e9", c2: "#0369a1", labelKey: "payMethodBank" },
  wallet: { icon: "wallet", c1: "#f59e0b", c2: "#d97706", labelKey: "payMethodWallet" },
  paypal: { icon: "at-sign", c1: "#06b6d4", c2: "#0891b2", labelKey: "payMethodPaypal" },
  stripe: { icon: "credit-card", c1: "#8b5cf6", c2: "#7c3aed", labelKey: "payMethodStripe" },
};

const STATUS_STYLE: Record<string, string> = {
  pending: "border-amber-300/70 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300",
  paid: "border-emerald-300/70 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300",
  cancelled: "border-slate-300/70 bg-slate-500/10 text-slate-500 dark:border-white/10 dark:text-slate-400",
  expired: "border-rose-300/70 bg-rose-500/10 text-rose-500 dark:border-rose-500/40 dark:text-rose-300",
};

export function AddonsView({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();

  const catalogQuery = useQuery({
    queryKey: ["addon-catalog", instance.id],
    queryFn: () => fetchAddonCatalog(instance.id),
    staleTime: 30_000,
    retry: 0,
  });
  const catalog = catalogQuery.data?.features ?? [];
  const orders = catalogQuery.data?.orders ?? [];
  const activeCount = catalog.filter((c) => c.active).length;

  /* the selection cart — feature keys chosen for purchase */
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const toggleSelected = (feature: string, active: boolean) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (active) next.delete(feature);
      else next.add(feature);
      return next;
    });
  };
  const selectedRows = useMemo(
    () => catalog.filter((c) => selected.has(c.feature)),
    [catalog, selected]
  );

  /* the checkout dialog */
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [cycle, setCycle] = useState<"monthly" | "yearly">("monthly");
  const [methodId, setMethodId] = useState<string>("");
  const [invoice, setInvoice] = useState<{ order: AddonOrderDTO; instructions: PaymentInstructionsDTO } | null>(null);

  const methodsQuery = useQuery({
    queryKey: ["plan-methods", instance.id],
    queryFn: () => fetchPlanMethods(instance.id),
    enabled: checkoutOpen && !invoice,
    staleTime: 30_000,
  });
  const methods = methodsQuery.data ?? [];

  /* ROUND 141 — the wallet INSTANT checkout option */
  const walletQuery = useQuery({
    queryKey: ["wallet", instance.id],
    queryFn: () => fetchWallet(instance.id),
    enabled: checkoutOpen && !invoice,
    staleTime: 20_000,
  });
  const wallet = walletQuery.data ?? null;

  const effectiveMethodId = methodId || methods[0]?.id || "";

  /* the preview total (server recomputes on create — this is display only).
   * ROUND 166 — catalog prices are integer MINOR units, so the sum is too */
  const previewTotal = selectedRows.reduce(
    (sum, row) => sum + (cycle === "yearly" ? row.yearly : row.monthly),
    0
  );
  const walletSelected = effectiveMethodId === WALLET_CHECKOUT_METHOD_ID;
  /* ROUND 166 — previewTotal is already MINOR units (no ×100 conversion) */
  const walletSufficient = !!wallet && wallet.balanceMinor >= previewTotal;

  const createOrder = useMutation({
    mutationFn: () =>
      createAddonOrder(instance.id, {
        features: [...selected],
        cycle,
        methodId: effectiveMethodId,
        /* ROUND 141 — the wallet pseudo-method pays INSTANTLY */
        ...(walletSelected ? { payWith: "wallet" as const } : {}),
      }),
    onSuccess: (result) => {
      if ("walletPaid" in result) {
        /* the INSTANT wallet outcome — features force-ON, no invoice */
        toast.success(t("walletCheckoutPaidAddon"));
        setCheckoutOpen(false);
        setInvoice(null);
        setSelected(new Set());
        void queryClient.invalidateQueries({ queryKey: ["addon-catalog", instance.id] });
        void queryClient.invalidateQueries({ queryKey: ["wallet", instance.id] });
        void queryClient.invalidateQueries({ queryKey: ["instance", instance.id] });
        return;
      }
      setInvoice(result);
      toast.success(t("addonOrderCreated"));
      void queryClient.invalidateQueries({ queryKey: ["addon-catalog", instance.id] });
    },
    onError: (error: unknown) => toast.error(apiErrorText(error, t)),
  });

  const cancelOrder = useMutation({
    mutationFn: (orderId: string) => cancelAddonOrder(instance.id, orderId),
    onSuccess: () => {
      toast(t("addonOrderCancelled"));
      void queryClient.invalidateQueries({ queryKey: ["addon-catalog", instance.id] });
    },
    onError: (error: unknown) => toast.error(apiErrorText(error, t)),
  });

  const openCheckout = () => {
    if (selected.size === 0) return;
    setInvoice(null);
    setCheckoutOpen(true);
  };

  const closeCheckout = (open: boolean) => {
    if (!open) {
      setCheckoutOpen(false);
      setInvoice(null);
      setSelected(new Set());
    }
  };

  const copyRef = (reference: string) => {
    copyText(reference)
      .then(() => toast.success(t("secCopied")))
      .catch(() => toast.error(t("errGenericAction")));
  };

  /* ROUND 147 — currency honesty: order-backed rows show that order's OWN
   * server-stamped currency (AddonOrderDTO.currency); the pre-order surfaces
   * (card prices, sticky bar, checkout preview) resolve the LIVE currency
   * from the workspace's newest add-on order (createdAt-desc — the same
   * query this view already owns), then the wallet topups' currency (the
   * wallet query only rides during checkout), then the documented fallback
   * "SAR" — the same default the server stamps on every add-on order (the
   * platform's standard convention, src/lib/server/addon-orders.ts). */
  const liveCurrency =
    orders[0]?.currency ?? wallet?.topups[0]?.currency ?? "SAR";
  /* ROUND 166 — add-on prices/order amounts are integer MINOR units;
   *  fmtPlanPrice renders ÷100 with 2 decimals (WESTERN digits). */
  const money = (n: number, currency: string) => `${fmtPlanPrice(n)} ${currency}`;

  return (
    <div className="space-y-5 pb-16">
      <ViewHeading title={t("addonsTitle")} desc={t("addonsDesc")} />

      {/* ---------------- the plan context strip ---------------- */}
      <DashCard title={t("addonsContextTitle")} icon="sparkles">
        <div className="flex flex-wrap items-center gap-3">
          <span
            className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
            style={{ backgroundImage: grad("#8b5cf6", "#d946ef"), boxShadow: `0 10px 24px -10px rgba(139,92,246,0.8)` }}
            aria-hidden="true"
          >
            <CatIcon name="puzzle" className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
              {instance.package ? instance.package.nameAr : t("trialBadge")}
            </p>
            <p className="mt-0.5 text-[11.5px] font-semibold text-slate-500 dark:text-slate-400">
              {t("addonsContextDesc", { on: String(activeCount), total: String(catalog.length) })}
            </p>
          </div>
          <Badge className="gap-1.5 rounded-full bg-violet-500/15 px-3 py-1.5 text-[11px] font-extrabold text-violet-600 hover:bg-violet-500/15 dark:text-violet-300">
            <CatIcon name="badge-check" className="h-3.5 w-3.5" />
            {t("addonsActiveChip", { n: String(activeCount) })}
          </Badge>
        </div>
      </DashCard>

      {/* ---------------- the catalog (grouped) ---------------- */}
      {catalogQuery.isPending ? (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-[132px] rounded-2xl" />
          ))}
        </div>
      ) : catalogQuery.isError ? (
        /* ROUND 147 — the zero-catalog guard: with retry: 0 a single failed
         * fetch rendered a BLANK region (every group filters to zero rows).
         * The activity-view error idiom, existing keys only. A successful
         * catalog response always carries the full feature ladder (active
         * rows included), so loaded-but-empty is unreachable in practice. */
        <div className="py-10 text-center">
          <p className="text-[13px] font-bold text-rose-600 dark:text-rose-400">{t("errorText")}</p>
          <Button
            variant="outline"
            onClick={() => catalogQuery.refetch()}
            className="mt-3 h-10 rounded-xl px-5 text-[12.5px] font-bold"
          >
            <CatIcon name="refresh-cw" className="h-4 w-4" />
            {t("retryText")}
          </Button>
        </div>
      ) : (
        FEATURE_GROUPS.map((group) => {
          const rows = catalog.filter((c) => FEATURE_META[c.feature as PlanFeature]?.group === group.key);
          if (rows.length === 0) return null;
          return (
            <section key={group.key} className="space-y-3" aria-label={t(group.labelKey)}>
              <div className="flex items-center gap-2.5">
                <span className="h-5 w-1 rounded-full bg-linear-to-b from-violet-500 to-fuchsia-500" aria-hidden="true" />
                <h2 className="text-[13px] font-extrabold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                  {t(group.labelKey)}
                </h2>
                <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10.5px] font-bold tabular-nums text-slate-500 dark:bg-white/10 dark:text-slate-400">
                  {rows.length}
                </span>
              </div>
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {rows.map((row) => {
                  const meta = FEATURE_META[row.feature as PlanFeature];
                  const checked = selected.has(row.feature);
                  return (
                    <div
                      key={row.feature}
                      className={cn(
                        "rounded-2xl border p-3.5 transition",
                        row.active
                          ? "border-emerald-300/60 bg-emerald-500/[0.06] dark:border-emerald-500/25 dark:bg-emerald-500/[0.06]"
                          : checked
                            ? "border-violet-400 bg-violet-500/[0.08] shadow-sm dark:border-violet-500/50 dark:bg-violet-500/10"
                            : "border-slate-200 bg-white hover:border-violet-300 hover:shadow-sm dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-violet-500/40"
                      )}
                    >
                      <div className="flex items-start gap-3">
                        <span
                          className={cn(
                            "grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-md",
                            row.active && "opacity-90"
                          )}
                          style={
                            row.active
                              ? { backgroundImage: "linear-gradient(135deg,#10b981,#047857)" }
                              : { backgroundImage: grad("#8b5cf6", "#d946ef") }
                          }
                          aria-hidden="true"
                        >
                          <CatIcon name={meta?.icon ?? "puzzle"} className="h-[15px] w-[15px]" />
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                            {t(meta?.labelKey ?? "addonsTitle")}
                          </p>
                          <p className="mt-0.5 line-clamp-2 min-h-[28px] text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                            {t(meta?.descKey ?? "addonsDesc")}
                          </p>
                        </div>
                      </div>
                      <div className="mt-3 flex items-center justify-between gap-2 border-t border-dashed border-slate-200/80 pt-2.5 dark:border-white/10">
                        {row.active ? (
                          <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/15 px-2.5 py-1 text-[10.5px] font-extrabold text-emerald-600 dark:text-emerald-300">
                            <CatIcon name="circle-check" className="h-3 w-3" />
                            {t("addonsActiveState")}
                          </span>
                        ) : (
                          <span className="flex flex-wrap items-baseline gap-x-1.5">
                            <span dir="ltr" className="font-display text-[15px] font-extrabold tabular-nums text-slate-800 dark:text-white">
                              {money(cycle === "yearly" ? row.yearly : row.monthly, liveCurrency)}
                            </span>
                            <span className="text-[10px] font-bold text-slate-400">
                              / {t(cycle === "yearly" ? "addonsCycleYearly" : "addonsCycleMonthly")}
                            </span>
                          </span>
                        )}
                        {!row.active ? (
                          <Switch
                            checked={checked}
                            onCheckedChange={() => toggleSelected(row.feature, row.active)}
                            aria-label={t("addonsSelectAria", { name: t(meta?.labelKey ?? "addonsTitle") })}
                            className="data-[state=checked]:bg-violet-500"
                          />
                        ) : null}
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>
          );
        })
      )}

      {/* ---------------- the workspace's add-on orders ---------------- */}
      <DashCard title={t("addonsOrdersTitle")} icon="receipt">
        {orders.length === 0 ? (
          <p className="rounded-2xl border-2 border-dashed border-slate-200 py-6 text-center text-[12.5px] font-bold text-slate-400 dark:border-white/10 dark:text-slate-500">
            {t("addonsOrdersEmpty")}
          </p>
        ) : (
          <div className="max-h-72 space-y-2 overflow-y-auto pe-1 nice-scroll">
            {orders.map((order) => (
              <div
                key={order.id}
                className="flex flex-wrap items-center gap-3 rounded-2xl border border-slate-200/80 bg-white/70 px-3.5 py-3 dark:border-white/[0.07] dark:bg-white/[0.03]"
              >
                <div className="min-w-0 flex-1">
                  <p dir="ltr" className="truncate font-mono text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200">
                    {order.reference}
                  </p>
                  <p className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                    <span className="min-w-0 flex-1 truncate">
                      {order.features
                        .map((f) => t(FEATURE_META[f as PlanFeature]?.labelKey ?? "addonsTitle"))
                        .join(" · ")}
                    </span>
                    {/* ROUND 147 — the server-verified HMAC integrity chip
                        (the billing-view order-row idiom) */}
                    {order.integrityVerified ? (
                      <span
                        title={t("orderIntegrityOk")}
                        className="inline-flex shrink-0 items-center gap-1 rounded-full border border-emerald-300/60 bg-emerald-500/[0.08] px-2 py-px text-[11px] font-extrabold text-emerald-600 dark:border-emerald-500/30 dark:text-emerald-300"
                      >
                        <CatIcon name="shield-check" className="h-2.5 w-2.5" />
                        {t("orderIntegrityOk")}
                      </span>
                    ) : null}
                  </p>
                </div>
                <span dir="ltr" className="shrink-0 text-[12px] font-extrabold tabular-nums text-slate-700 dark:text-slate-200">
                  {money(order.amount, order.currency)}
                </span>
                <span className={cn("shrink-0 rounded-full border px-2.5 py-1 text-[10px] font-extrabold", STATUS_STYLE[order.effectiveStatus] ?? STATUS_STYLE.cancelled)}>
                  {t(
                    order.effectiveStatus === "pending"
                      ? "addonStatusPending"
                      : order.effectiveStatus === "paid"
                        ? "addonStatusPaid"
                        : order.effectiveStatus === "expired"
                          ? "addonStatusExpired"
                          : "addonStatusCancelled"
                  )}
                </span>
                {order.effectiveStatus === "pending" ? (
                  <Button
                    type="button"
                    variant="outline"
                    disabled={cancelOrder.isPending}
                    onClick={() => cancelOrder.mutate(order.id)}
                    className="h-8 rounded-lg px-3 text-[10.5px] font-bold text-rose-600 hover:bg-rose-500/10 dark:text-rose-300"
                  >
                    <CatIcon name="x" className="h-3 w-3" />
                    {t("addonCancelBtn")}
                  </Button>
                ) : null}
              </div>
            ))}
          </div>
        )}
      </DashCard>

      {/* ---------------- the sticky selection bar ---------------- */}
      {selected.size > 0 && !checkoutOpen ? (
        <div className="fixed inset-x-0 bottom-0 z-40 border-t border-violet-200/60 bg-white/95 px-4 py-3 shadow-[0_-10px_30px_-15px_rgba(139,92,246,0.4)] backdrop-blur-xl dark:border-violet-500/20 dark:bg-ink-950/95">
          <div className="mx-auto flex max-w-5xl flex-wrap items-center gap-3">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-linear-to-br from-violet-500 to-fuchsia-500 text-white shadow-lg" aria-hidden="true">
              <CatIcon name="shopping-cart" className="h-4 w-4" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                {t("addonsCartCount", { n: String(selected.size) })}
              </p>
              <p dir="ltr" className="text-start text-[11px] font-bold tabular-nums text-violet-600 dark:text-violet-300">
                {money(previewTotal, liveCurrency)} / {t(cycle === "yearly" ? "addonsCycleYearly" : "addonsCycleMonthly")}
              </p>
            </div>
            {/* cycle toggle inside the bar */}
            <div className="flex items-center rounded-full border border-slate-200 bg-slate-50 p-0.5 dark:border-white/10 dark:bg-white/[0.04]">
              {(["monthly", "yearly"] as const).map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setCycle(c)}
                  aria-pressed={cycle === c}
                  className={cn(
                    "rounded-full px-3 py-1.5 text-[11px] font-extrabold transition",
                    cycle === c ? "bg-white text-slate-900 shadow-sm dark:bg-white/10 dark:text-white" : "text-slate-500 dark:text-slate-400"
                  )}
                >
                  {t(c === "monthly" ? "addonsCycleMonthly" : "addonsCycleYearly")}
                </button>
              ))}
            </div>
            <Button
              type="button"
              onClick={openCheckout}
              className="h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95"
              style={{ backgroundImage: grad("#8b5cf6", "#d946ef") }}
            >
              <CatIcon name="arrow-right" className="h-4 w-4 rtl:rotate-180" />
              {t("addonsCheckoutBtn")}
            </Button>
            <Button
              type="button"
              variant="ghost"
              onClick={() => setSelected(new Set())}
              className="h-10 rounded-xl px-3 text-[11.5px] font-bold text-slate-400"
            >
              {t("addonsClearBtn")}
            </Button>
          </div>
        </div>
      ) : null}

      {/* ---------------- the checkout dialog ---------------- */}
      <Dialog open={checkoutOpen} onOpenChange={closeCheckout}>
        <DialogContent
          dir={lang === "ar" ? "rtl" : "ltr"}
          className="max-h-[85vh] gap-0 overflow-y-auto rounded-3xl p-0 sm:max-w-lg nice-scroll"
        >
          <DialogHeader className="border-b border-slate-200/70 p-5 dark:border-white/10">
            <DialogTitle className="flex items-center gap-2.5 font-display text-[17px] font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg"
                style={{ backgroundImage: grad("#8b5cf6", "#d946ef") }}
                aria-hidden="true"
              >
                <CatIcon name={invoice ? "file-check" : "sparkles"} className="h-[15px] w-[15px]" />
              </span>
              {invoice ? t("addonInvoiceTitle") : t("addonsCheckoutTitle")}
            </DialogTitle>
            <DialogDescription className="ps-[46px] text-[12.5px]">
              {invoice ? t("addonInvoiceDesc") : t("addonsCheckoutDesc")}
            </DialogDescription>
          </DialogHeader>

          {invoice ? (
            /* ------------- the invoice step ------------- */
            <div className="space-y-4 p-5">
              {/* the reference — the payment identity */}
              <div className="rounded-2xl border border-violet-200/70 bg-violet-500/[0.06] p-4 dark:border-violet-500/25 dark:bg-violet-500/[0.08]">
                <p className="text-[10.5px] font-extrabold uppercase tracking-wide text-violet-500 dark:text-violet-300">
                  {t("payCopyRef")}
                </p>
                <div className="mt-1.5 flex items-center justify-between gap-2">
                  <p dir="ltr" className="min-w-0 flex-1 truncate font-mono text-[15px] font-extrabold text-slate-800 dark:text-white">
                    {invoice.order.reference}
                  </p>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => copyRef(invoice.order.reference)}
                    className="h-8 shrink-0 gap-1.5 rounded-lg px-3 text-[10.5px] font-bold"
                  >
                    <CatIcon name="copy" className="h-3 w-3" />
                    {t("secCopyTip")}
                  </Button>
                </div>
              </div>

              {/* ROUND 147 — the amount due in the order's OWN currency +
                  the server-verified HMAC integrity chip (the billing-view
                  * invoice idiom — same chip the order rows carry) */}
              <div className="flex items-center justify-between gap-2 rounded-2xl border border-violet-200/70 bg-violet-500/[0.06] px-4 py-3 dark:border-violet-500/25 dark:bg-violet-500/[0.08]">
                <p className="flex min-w-0 flex-wrap items-center gap-2 text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
                  {t("addonsTotal")}
                  {invoice.order.integrityVerified ? (
                    <span
                      title={t("orderIntegrityOk")}
                      className="inline-flex shrink-0 items-center gap-1 rounded-full border border-emerald-300/60 bg-emerald-500/[0.08] px-2 py-px text-[11px] font-extrabold text-emerald-600 dark:border-emerald-500/30 dark:text-emerald-300"
                    >
                      <CatIcon name="shield-check" className="h-2.5 w-2.5" />
                      {t("orderIntegrityOk")}
                    </span>
                  ) : null}
                </p>
                <p dir="ltr" className="shrink-0 font-display text-[18px] font-extrabold tabular-nums text-violet-600 dark:text-violet-300">
                  {money(invoice.order.amount, invoice.order.currency)}
                </p>
              </div>

              {/* the server-built payment instructions */}
              <div className="rounded-2xl border border-slate-200/80 p-4 dark:border-white/10">
                <p className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                  <CatIcon name="landmark" className="h-3.5 w-3.5 text-slate-400" />
                  {invoice.instructions.methodLabel}
                </p>
                <ul className="mt-2.5 space-y-1.5">
                  {invoice.instructions.lines.map((line, i) => (
                    <li key={i} className="flex items-start gap-2 text-[11.5px] font-semibold leading-relaxed text-slate-600 dark:text-slate-300">
                      <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-violet-400" aria-hidden="true" />
                      <span className="min-w-0 break-words" dir="auto">{line}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <p className="flex items-start gap-2 rounded-xl bg-amber-500/10 px-3.5 py-2.5 text-[11px] font-semibold leading-relaxed text-amber-700 dark:text-amber-300">
                <CatIcon name="clock" className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                {t("addonAwaitingNote")}
              </p>

              <DialogFooter>
                <Button
                  type="button"
                  onClick={() => closeCheckout(false)}
                  className="h-10 w-full rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg"
                  style={{ backgroundImage: grad("#8b5cf6", "#d946ef") }}
                >
                  <CatIcon name="check" className="h-4 w-4" />
                  {t("addonDoneBtn")}
                </Button>
              </DialogFooter>
            </div>
          ) : (
            /* ------------- the pay step ------------- */
            <div className="space-y-4 p-5">
              {/* the chosen add-ons summary */}
              <div className="space-y-2">
                {selectedRows.map((row) => {
                  const meta = FEATURE_META[row.feature as PlanFeature];
                  return (
                    <div key={row.feature} className="flex items-center gap-3 rounded-xl border border-slate-200/80 px-3 py-2.5 dark:border-white/10">
                      <span
                        className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white"
                        style={{ backgroundImage: grad("#8b5cf6", "#d946ef") }}
                        aria-hidden="true"
                      >
                        <CatIcon name={meta?.icon ?? "puzzle"} className="h-3.5 w-3.5" />
                      </span>
                      <p className="min-w-0 flex-1 truncate text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
                        {t(meta?.labelKey ?? "addonsTitle")}
                      </p>
                      <span dir="ltr" className="shrink-0 text-[12px] font-extrabold tabular-nums text-slate-700 dark:text-slate-200">
                        {money(cycle === "yearly" ? row.yearly : row.monthly, liveCurrency)}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* the total */}
              <div className="flex items-center justify-between rounded-2xl border border-violet-200/70 bg-violet-500/[0.06] px-4 py-3 dark:border-violet-500/25 dark:bg-violet-500/[0.08]">
                <p className="text-[12px] font-extrabold text-slate-700 dark:text-slate-200">{t("addonsTotal")}</p>
                <p dir="ltr" className="font-display text-[18px] font-extrabold tabular-nums text-violet-600 dark:text-violet-300">
                  {money(previewTotal, liveCurrency)}
                </p>
              </div>

              {/* the payment method */}
              <div className="space-y-1.5">
                <p className="text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">{t("payMethodLabel")}</p>
                {/* ROUND 141 — the wallet INSTANT checkout card rides FIRST */}
                {walletQuery.isPending ? (
                  <Skeleton className="h-[68px] w-full rounded-xl" />
                ) : (
                  <WalletCheckoutOption
                    wallet={wallet}
                    /* ROUND 166 — previewTotal is already MINOR units */
                    amountMinor={previewTotal}
                    selected={walletSelected}
                    onSelect={() => setMethodId(WALLET_CHECKOUT_METHOD_ID)}
                    pending={createOrder.isPending && walletSelected}
                  />
                )}
                {methodsQuery.isPending ? (
                  <Skeleton className="h-11 w-full rounded-xl" />
                ) : methods.length === 0 ? (
                  <p className="rounded-xl border border-dashed border-slate-200 px-3.5 py-3 text-[11.5px] font-semibold text-slate-400 dark:border-white/10 dark:text-slate-500">
                    {t("payNoMethods")}
                  </p>
                ) : (
                  <div className="grid gap-2 sm:grid-cols-2">
                    {methods.map((method) => {
                      const meta = METHOD_KIND_META[method.kind] ?? METHOD_KIND_META.bank;
                      const active = effectiveMethodId === method.id;
                      return (
                        <button
                          key={method.id}
                          type="button"
                          onClick={() => setMethodId(method.id)}
                          aria-pressed={active}
                          className={cn(
                            "flex items-center gap-2.5 rounded-xl border px-3 py-2.5 text-start transition",
                            active
                              ? "border-violet-400 bg-violet-500/[0.08] shadow-sm dark:border-violet-500/50 dark:bg-violet-500/10"
                              : "border-slate-200 hover:border-violet-300 dark:border-white/10 dark:hover:border-violet-500/40"
                          )}
                        >
                          <span
                            className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white"
                            style={{ backgroundImage: grad(meta.c1, meta.c2) }}
                            aria-hidden="true"
                          >
                            <CatIcon name={meta.icon} className="h-3.5 w-3.5" />
                          </span>
                          <span className="min-w-0 flex-1">
                            <span className="block truncate text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200">
                              {t(meta.labelKey)}
                            </span>
                            <span className="block truncate text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                              {method.label}
                            </span>
                          </span>
                          {active ? (
                            <CatIcon name="circle-check" className="h-4 w-4 shrink-0 text-violet-500" />
                          ) : null}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              <DialogFooter className="gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setCheckoutOpen(false)}
                  disabled={createOrder.isPending}
                  className="h-10 rounded-xl border-slate-200 bg-white px-5 text-[12.5px] font-bold text-slate-700 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200"
                >
                  {t("modRecCancelBtn")}
                </Button>
                <Button
                  type="button"
                  disabled={selected.size === 0 || !effectiveMethodId || createOrder.isPending || (walletSelected && !walletSufficient)}
                  onClick={() => createOrder.mutate()}
                  className={cn(
                    "h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:opacity-60",
                    walletSelected
                      ? "bg-linear-to-l from-emerald-600 to-teal-500"
                      : "bg-linear-to-l from-violet-600 to-fuchsia-500"
                  )}
                >
                  {createOrder.isPending ? (
                    <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                  ) : (
                    <CatIcon name="send" className="h-4 w-4" />
                  )}
                  {t("addonSendRequestBtn")}
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

export function AddonsViewSkeleton() {
  return (
    <div className="space-y-4">
      <Skeleton className="h-24 rounded-2xl" />
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-[132px] rounded-2xl" />
        ))}
      </div>
    </div>
  );
}
