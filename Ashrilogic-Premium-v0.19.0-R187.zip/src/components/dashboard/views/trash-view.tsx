"use client";

/**
 * Dashboard — workspace trash view (سلة المحذوفات) · ROUND 87 · TASK 13-c.
 *
 * The owner-side mirror of the platform trash console, strictly scoped to
 * THIS workspace. GET /api/instances/[id]/trash requires the settings.manage
 * permission — a 403 PERMISSION_DENIED (team member without governance
 * rights) renders a dedicated muted lock card instead of the generic error,
 * never a broken half-view.
 *
 * Data model: ONE feed fetch (limit 200 — the server's hard cap) carries the
 * whole console: { items, stats }. The stats drive the KPI strip and the
 * per-entity pill counts; the entity pills, the debounced search and the
 * load-more window are all client-side over that single fetch — no
 * per-keystroke refetches, no pill-click round-trips.
 *
 * Destructive actions are deliberately ceremonial (صارمة جداً):
 *  - restore → AlertDialog confirm → success toast; a 409 conflict
 *    (email re-registered / coupon code retaken / …) gets its own toast;
 *  - purge  → AlertDialog with TYPE-TO-CONFIRM — the destructive button
 *    stays disabled until the typed word === t("trashConfirmWord"); the
 *    bulk purge rides the same ceremony;
 *  - bulk   → sticky selection bar, sequential per-item actions, one
 *    summary toast per outcome, then the selection clears.
 *
 * ROUND 136 — the KPI strip migrated onto the unified StatCard.
 * ROUND 139 — the strip now renders THE golden inventory-page card law
 * (size="golden" inside the exact inventory grid grid-cols-2 → md:grid-cols-3
 * → xl:grid-cols-5), expanded 4 → 5 KPIs: the NOT-EXPIRING-SOON cohort (the
 * complement of the 7-day window) is promoted to its own headline card so the
 * golden 5-column grid fills exactly — the R136-A inventory pattern.
 */
import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { useT, t as tt, type I18nKey } from "@/lib/i18n";
import type { InstanceDTO, Lang } from "@/lib/types";
import { ApiError, fetchInstanceTrash, instanceTrashAction, type TrashItemDTO } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, labelTrack, normalizeSearch } from "@/lib/utils";
import { StatCard } from "@/components/shared/stat-card";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  DashCard,
  IconTile,
  ViewHeading,
  fullDate,
  relativeTime,
} from "@/components/dashboard/dash-shared";

/* ------------------------------------------------------------------ */
/* entity visual map — the six tenant-scope trash entities             */
/* ------------------------------------------------------------------ */

interface EntityStyle {
  labelKey: I18nKey;
  icon: string;
  c1: string;
  c2: string;
}

const ENTITY_ORDER = [
  "moduleRecord",
  "siteOrder",
  "siteCustomer",
  "storeCoupon",
  "teamMember",
  "siteReview",
] as const;

type TenantEntity = (typeof ENTITY_ORDER)[number];
type EntityFilter = "all" | TenantEntity;

const ENTITY_STYLE: Record<string, EntityStyle> = {
  moduleRecord: { labelKey: "trashEntityRecord", icon: "cubes", c1: "#8b5cf6", c2: "#7c3aed" },
  siteOrder: { labelKey: "trashEntityOrder", icon: "receipt", c1: "#10b981", c2: "#059669" },
  siteCustomer: { labelKey: "trashEntityCustomer", icon: "users-round", c1: "#0ea5e9", c2: "#0284c7" },
  storeCoupon: { labelKey: "trashEntityCoupon", icon: "ticket-percent", c1: "#f59e0b", c2: "#d97706" },
  teamMember: { labelKey: "trashEntityMember", icon: "users", c1: "#d946ef", c2: "#c026d3" },
  siteReview: { labelKey: "trashEntityReview", icon: "star", c1: "#f43f5e", c2: "#e11d48" },
};

/** unknown entity ids (never served in tenant scope) — render safe, never crash */
const FALLBACK_STYLE: EntityStyle = { labelKey: "trashTitle", icon: "trash-2", c1: "#64748b", c2: "#475569" };

const styleOf = (entity: string): EntityStyle => ENTITY_STYLE[entity] ?? FALLBACK_STYLE;

/** ONE feed fetch carries the whole console (200 = the server's hard cap);
 *  pills, search and load-more are client-side over that window. */
const FETCH_LIMIT = 200;
const PAGE_STEP = 25;

/** stable selection key — ids are unique per table, the entity prefix makes it total */
const keyOf = (item: TrashItemDTO): string => `${item.entity}:${item.id}`;

/** join up to three labels, then a +N tail — the bulk summary toast payload */
function joinLabels(labels: string[], lang: Lang): string {
  const sep = lang === "ar" ? "، " : ", ";
  const head = labels.slice(0, 3).join(sep);
  return labels.length > 3 ? `${head}${sep}+${fmtNum(labels.length - 3, lang)}` : head;
}

/* ------------------------------------------------------------------ */
/* expiry countdown badge — green >14d · amber 8-14 · rose ≤7 (+pulse) */
/* ------------------------------------------------------------------ */

function CountdownBadge({ daysLeft, lang }: { daysLeft: number; lang: Lang }) {
  const d = Math.max(0, daysLeft);
  const label = d === 1 ? tt(lang, "trashDaysLeftOne") : tt(lang, "trashDaysLeft", { n: fmtNum(d, lang) });
  const tone =
    d > 14
      ? "border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-400"
      : d >= 8
        ? "border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-400"
        : "border-rose-200 bg-rose-50 text-rose-700 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-400";
  return (
    <span
      title={d <= 7 ? tt(lang, "trashExpiringSoon") : undefined}
      className={cn(
        "inline-flex items-center gap-1.5 whitespace-nowrap rounded-full border px-2.5 py-1 text-[10.5px] font-extrabold tabular-nums",
        tone
      )}
    >
      {d <= 7 ? (
        <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-rose-500" aria-hidden="true" />
      ) : (
        <CatIcon name="timer" className="h-3 w-3" />
      )}
      {label}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* row micro-chips                                                     */
/* ------------------------------------------------------------------ */

function EntityChip({ entity, lang }: { entity: string; lang: Lang }) {
  const style = styleOf(entity);
  return (
    <span className="inline-flex max-w-full items-center gap-1.5 rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-[10.5px] font-extrabold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
      <span
        className="h-2 w-2 shrink-0 rounded-full"
        style={{ backgroundImage: grad(style.c1, style.c2) }}
        aria-hidden="true"
      />
      <span className="truncate">{tt(lang, style.labelKey)}</span>
    </span>
  );
}

function ReasonChip({ reason, lang }: { reason: string; lang: Lang }) {
  return (
    <span
      dir="auto"
      title={reason}
      className="inline-flex max-w-full items-center gap-1 rounded-full bg-rose-50 px-2 py-0.5 text-[10px] font-bold text-rose-600 dark:bg-rose-500/10 dark:text-rose-400"
    >
      <CatIcon name="trash-2" className="h-2.5 w-2.5 shrink-0" />
      <span className="truncate">
        {tt(lang, "trashReason")}: {reason}
      </span>
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* type-to-confirm input (the strict purge ceremony)                   */
/* ------------------------------------------------------------------ */

function TypeConfirmInput({
  id,
  value,
  onChange,
  label,
  placeholder,
}: {
  id: string;
  value: string;
  onChange: (v: string) => void;
  label: string;
  placeholder: string;
}) {
  return (
    <div>
      <label htmlFor={id} className="mb-2 block text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
        {label}
      </label>
      <Input
        id={id}
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        autoComplete="off"
        dir="auto"
        className="h-11 rounded-xl border-slate-200 bg-slate-50/80 text-[13px] font-bold text-slate-800 transition focus:border-rose-400 focus:bg-white focus:ring-4 focus:ring-rose-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:focus:border-rose-500/60 dark:focus:bg-white/[0.07]"
      />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* item row                                                            */
/* ------------------------------------------------------------------ */

function TrashRow({
  item,
  selected,
  onToggleSelect,
  onRestore,
  onPurge,
  lang,
}: {
  item: TrashItemDTO;
  selected: boolean;
  onToggleSelect: () => void;
  onRestore: () => void;
  onPurge: () => void;
  lang: Lang;
}) {
  const style = styleOf(item.entity);
  return (
    <li
      className={cn(
        "flex items-start gap-3 rounded-2xl border p-3 transition-all duration-200 lg:items-center",
        selected
          ? "border-brand-300/80 bg-brand-500/[0.05] dark:border-brand-500/40 dark:bg-brand-500/[0.07]"
          : "border-slate-100 bg-white/70 hover:border-slate-200 hover:shadow-sm dark:border-white/[0.06] dark:bg-white/[0.02] dark:hover:border-white/[0.12] dark:hover:bg-white/[0.04]"
      )}
    >
      <Checkbox
        checked={selected}
        onCheckedChange={() => onToggleSelect()}
        aria-label={item.label}
        className="mt-1.5 shrink-0 lg:mt-0"
      />
      <IconTile icon={style.icon} c1={style.c1} c2={style.c2} className="mt-0.5 lg:mt-0" />

      {/* item — label + detail (+ compact meta line on mobile) */}
      <div className="min-w-0 flex-1">
        <p className="truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100" dir="auto" title={item.label}>
          {item.label}
        </p>
        {item.detail ? (
          <p className="mt-0.5 truncate text-[11px] font-semibold text-slate-400 dark:text-slate-500" dir="auto">
            {item.detail}
          </p>
        ) : null}
        <div className="mt-1.5 flex flex-wrap items-center gap-1.5 lg:hidden">
          <CountdownBadge daysLeft={item.daysLeft} lang={lang} />
          <EntityChip entity={item.entity} lang={lang} />
          {item.deletedByName ? (
            <span className="text-[10.5px] font-bold text-slate-500 dark:text-slate-400" dir="auto">
              {item.deletedByName}
            </span>
          ) : null}
          {item.deleteReason ? <ReasonChip reason={item.deleteReason} lang={lang} /> : null}
          <span className="text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
            {relativeTime(item.deletedAt, lang)}
          </span>
        </div>
      </div>

      {/* context — the entity kind (lg column) */}
      <div className="hidden w-36 shrink-0 lg:block">
        <EntityChip entity={item.entity} lang={lang} />
      </div>

      {/* deleted-by + reason (lg column) */}
      <div className="hidden w-44 shrink-0 lg:block">
        <p
          className="truncate text-[11.5px] font-bold text-slate-600 dark:text-slate-300"
          dir="auto"
          title={item.deletedByName ?? undefined}
        >
          {item.deletedByName ?? "—"}
        </p>
        {item.deleteReason ? (
          <div className="mt-1">
            <ReasonChip reason={item.deleteReason} lang={lang} />
          </div>
        ) : null}
      </div>

      {/* deleted-at (lg column) */}
      <p
        className="hidden w-28 shrink-0 text-[11px] font-semibold text-slate-400 dark:text-slate-500 lg:block"
        title={fullDate(item.deletedAt, lang)}
      >
        {relativeTime(item.deletedAt, lang)}
      </p>

      {/* expiry countdown (lg column) */}
      <div className="hidden w-28 shrink-0 lg:block">
        <CountdownBadge daysLeft={item.daysLeft} lang={lang} />
      </div>

      {/* actions */}
      <div className="flex shrink-0 items-center gap-2 self-start lg:self-center">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={onRestore}
          aria-label={tt(lang, "trashRestore")}
          title={tt(lang, "trashRestore")}
          className="h-9 w-9 gap-1.5 rounded-xl border-emerald-200 p-0 text-[11.5px] font-extrabold text-emerald-600 hover:border-emerald-300 hover:bg-emerald-50 hover:text-emerald-700 dark:border-emerald-500/30 dark:text-emerald-400 dark:hover:border-emerald-500/50 dark:hover:bg-emerald-500/10 lg:w-auto lg:px-3"
        >
          <CatIcon name="rotate-ccw" className="h-3.5 w-3.5" />
          <span className="hidden lg:inline">{tt(lang, "trashRestore")}</span>
        </Button>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={onPurge}
          aria-label={tt(lang, "trashPurge")}
          title={tt(lang, "trashPurge")}
          className="h-9 w-9 gap-1.5 rounded-xl border-rose-200 p-0 text-[11.5px] font-extrabold text-rose-600 hover:border-rose-300 hover:bg-rose-50 hover:text-rose-700 dark:border-rose-500/30 dark:text-rose-400 dark:hover:border-rose-500/50 dark:hover:bg-rose-500/10 lg:w-auto lg:px-3"
        >
          <CatIcon name="flame" className="h-3.5 w-3.5" />
          <span className="hidden lg:inline">{tt(lang, "trashPurge")}</span>
        </Button>
      </div>
    </li>
  );
}

/* ------------------------------------------------------------------ */
/* filter pill classes                                                 */
/* ------------------------------------------------------------------ */

const pillClass = (active: boolean): string =>
  cn(
    "inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-[12px] font-extrabold transition active:scale-[0.97]",
    active
      ? "border-slate-900 bg-slate-900 text-white shadow-md dark:border-white dark:bg-white dark:text-slate-900"
      : "border-slate-200 bg-white/70 text-slate-600 hover:border-slate-300 hover:bg-white hover:shadow-sm dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:border-white/20 dark:hover:bg-white/[0.08]"
  );

const pillCountClass = (active: boolean): string =>
  cn(
    "rounded-full px-1.5 py-0.5 text-[10px] font-extrabold tabular-nums",
    active
      ? "bg-white/25 text-white dark:bg-slate-900/10 dark:text-slate-900"
      : "bg-slate-100 text-slate-500 dark:bg-white/10 dark:text-slate-400"
  );

/* ------------------------------------------------------------------ */
/* view                                                                */
/* ------------------------------------------------------------------ */

export function TrashView({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const queryKey = ["instance-trash", instance.id] as const;

  const [entityFilter, setEntityFilter] = useState<EntityFilter>("all");
  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  const [visibleCount, setVisibleCount] = useState(PAGE_STEP);
  const [selection, setSelection] = useState<Set<string>>(new Set());
  const [restoreTarget, setRestoreTarget] = useState<TrashItemDTO | null>(null);
  const [purgeTarget, setPurgeTarget] = useState<TrashItemDTO | null>(null);
  const [purgeWord, setPurgeWord] = useState("");
  const [bulkPurgeOpen, setBulkPurgeOpen] = useState(false);
  const [bulkPurgeWord, setBulkPurgeWord] = useState("");
  const [bulkBusy, setBulkBusy] = useState<"restore" | "purge" | null>(null);

  const query = useQuery({
    queryKey,
    queryFn: () => fetchInstanceTrash(instance.id, { limit: FETCH_LIMIT }),
    staleTime: 15_000,
    retry: 0,
  });

  const items = useMemo(() => query.data?.items ?? [], [query.data]);
  const stats = query.data?.stats;

  /* settings.manage denied (403 PERMISSION_DENIED) → dedicated lock card */
  const denied =
    query.isError &&
    query.error instanceof ApiError &&
    (query.error.status === 403 || query.error.code === "PERMISSION_DENIED");

  /* debounced search (Arabic-safe normalization happens at filter time) */
  useEffect(() => {
    const h = window.setTimeout(() => setDebounced(normalizeSearch(search.trim())), 220);
    return () => window.clearTimeout(h);
  }, [search]);

  /* entity pill + search filtering — all client-side over the one fetch */
  const filtered = useMemo(() => {
    let list = items;
    if (entityFilter !== "all") list = list.filter((it) => it.entity === entityFilter);
    if (debounced) {
      list = list.filter((it) =>
        normalizeSearch(
          [
            it.label,
            it.detail ?? "",
            it.deletedByName ?? "",
            it.deleteReason ?? "",
            tt(lang, styleOf(it.entity).labelKey),
            ...Object.values(it.meta).map((v) => (v === null ? "" : String(v))),
          ].join(" ")
        ).includes(debounced)
      );
    }
    return list;
  }, [items, entityFilter, debounced, lang]);

  const shown = useMemo(() => filtered.slice(0, visibleCount), [filtered, visibleCount]);

  /* fresh filter → fresh page window (reset lives in the click handlers —
   * never a setState-in-effect cascade) */
  const applyEntityFilter = (next: EntityFilter) => {
    setEntityFilter(next);
    setVisibleCount(PAGE_STEP);
  };

  /* selection is DERIVED from the live filtered list (never pruned state):
   * rows hidden by a filter change or removed by a refetch (restore / purge /
   * bulk) drop out automatically — the checked set is always exactly what
   * the user currently sees checked. */
  const selectedItems = useMemo(() => filtered.filter((it) => selection.has(keyOf(it))), [filtered, selection]);
  const selectedCount = selectedItems.length;
  const allSelected = filtered.length > 0 && filtered.every((it) => selection.has(keyOf(it)));

  const toggleSelect = (item: TrashItemDTO) => {
    setSelection((prev) => {
      const next = new Set(prev);
      const key = keyOf(item);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const toggleSelectAll = () => {
    setSelection(allSelected ? new Set() : new Set(filtered.map(keyOf)));
  };

  /* ---------------- single-item actions ---------------- */

  const restore = useMutation({
    mutationFn: (item: TrashItemDTO) =>
      instanceTrashAction(instance.id, { action: "restore", entity: item.entity, id: item.id }),
    onSuccess: (res, item) => {
      toast.success(t("trashRestoredToast", { label: res.label ?? item.label }));
      setRestoreTarget(null);
      void queryClient.invalidateQueries({ queryKey });
    },
    onError: (err: Error) => {
      if (err instanceof ApiError && err.status === 409) toast.error(t("trashConflictToast"));
      else toast.error(`${t("errorText")}: ${err.message}`);
      setRestoreTarget(null);
    },
  });

  const purge = useMutation({
    mutationFn: (item: TrashItemDTO) =>
      instanceTrashAction(instance.id, { action: "purge", entity: item.entity, id: item.id }),
    onSuccess: (res, item) => {
      toast.success(t("trashPurgedToast", { label: res.label ?? item.label }));
      setPurgeTarget(null);
      setPurgeWord("");
      void queryClient.invalidateQueries({ queryKey });
    },
    onError: (err: Error) => {
      if (err instanceof ApiError && err.status === 409) toast.error(t("trashConflictToast"));
      else toast.error(`${t("errorText")}: ${err.message}`);
      setPurgeTarget(null);
      setPurgeWord("");
    },
  });

  /* ---------------- bulk actions (sequential, summarized) ---------------- */

  const runBulk = async (action: "restore" | "purge") => {
    const targets = selectedItems;
    if (targets.length === 0 || bulkBusy !== null) return;
    setBulkBusy(action);
    const okLabels: string[] = [];
    let conflicts = 0;
    let failures = 0;
    for (const item of targets) {
      try {
        const res = await instanceTrashAction(instance.id, { action, entity: item.entity, id: item.id });
        okLabels.push(res.label ?? item.label);
      } catch (err) {
        if (err instanceof ApiError && err.status === 409) conflicts += 1;
        else failures += 1;
      }
    }
    setBulkBusy(null);
    setSelection(new Set());
    setBulkPurgeOpen(false);
    setBulkPurgeWord("");
    if (okLabels.length > 0) {
      toast.success(
        t(action === "restore" ? "trashRestoredToast" : "trashPurgedToast", {
          label: joinLabels(okLabels, lang),
        })
      );
      void queryClient.invalidateQueries({ queryKey });
    }
    if (conflicts > 0) toast.error(t("trashConflictToast"));
    if (failures > 0) toast.error(t("errorText"));
  };

  const restoreStyle = restoreTarget ? styleOf(restoreTarget.entity) : null;
  const confirmWord = t("trashConfirmWord");

  return (
    <div className="space-y-5">
      {/* heading — rose→violet tile + title/desc */}
      <div className="mb-6 flex items-center gap-4 [&>div]:mb-0">
        <IconTile icon="trash-2" c1="#f43f5e" c2="#8b5cf6" size="lg" />
        <ViewHeading title={t("trashTitle")} desc={t("trashDesc")} />
      </div>

      {denied ? (
        /* 403 PERMISSION_DENIED — the dedicated insufficient-permission card */
        <div className="glass-card card-in flex flex-col items-center gap-4 rounded-3xl px-6 py-14 text-center">
          <div className="grid h-16 w-16 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
            <CatIcon name="lock" className="h-7 w-7" />
          </div>
          <div className="max-w-md">
            <h2 className="font-display text-lg font-extrabold text-slate-700 dark:text-slate-200">
              {t("teamPermDenied")}
            </h2>
            <p className="mt-1.5 text-[12.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {t("teamRolesEnforcedDesc")}
            </p>
          </div>
        </div>
      ) : (
        <>
          {/* KPI strip — ROUND 139: THE golden inventory-page cards
              (grid-cols-2 → md:grid-cols-3 → xl:grid-cols-5): numeric
              count-up on the counts, em-dash value only when the fetch
              failed, label-valued card for the oldest item. */}
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
            <StatCard
              size="golden"
              label={t("trashKpiTotal")}
              value={query.isError ? "—" : undefined}
              numeric={query.isError ? undefined : (stats?.total ?? 0)}
              icon="trash-2"
              c1="#f43f5e"
              c2="#8b5cf6"
              index={0}
              lang={lang}
              loading={query.isPending}
            />
            <StatCard
              size="golden"
              label={t("trashKpiExpiring")}
              value={query.isError ? "—" : undefined}
              numeric={query.isError ? undefined : (stats?.expiringSoon ?? 0)}
              chip={
                (stats?.expiringSoon ?? 0) > 0 ? (
                  <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2 py-0.5 text-[10.5px] font-extrabold text-amber-600 transition-transform duration-200 hover:scale-105 dark:bg-amber-500/10 dark:text-amber-400">
                    <CatIcon name="timer" className="h-[10px] w-[10px]" />
                    {t("trashExpiringSoon")}
                  </span>
                ) : null
              }
              icon="timer"
              c1="#f43f5e"
              c2="#e11d48"
              index={1}
              lang={lang}
              tone="down"
              loading={query.isPending}
            />
            <StatCard
              size="golden"
              label={t("trashKpiSafe")}
              value={query.isError ? "—" : undefined}
              numeric={
                query.isError ? undefined : Math.max(0, (stats?.total ?? 0) - (stats?.expiringSoon ?? 0))
              }
              sub={t("trashKpiSafeSub", {
                pct: fmtNum(
                  stats && stats.total > 0
                    ? Math.round(((stats.total - stats.expiringSoon) / stats.total) * 100)
                    : 0,
                  lang,
                ),
              })}
              icon="circle-check"
              c1="#0ea5e9"
              c2="#0284c7"
              index={2}
              lang={lang}
              tone="up"
              loading={query.isPending}
            />
            <StatCard
              size="golden"
              label={t("trashKpiRetention")}
              value={query.isError ? "—" : t("trashKpiRetentionDays", { n: fmtNum(stats?.retentionDays ?? 0, lang) })}
              icon="shield"
              c1="#10b981"
              c2="#059669"
              index={3}
              lang={lang}
              loading={query.isPending}
            />
            <StatCard
              size="golden"
              label={t("trashKpiOldest")}
              value={query.isError || !stats?.oldestAt ? "—" : relativeTime(stats.oldestAt, lang)}
              chip={
                stats?.oldestAt ? (
                  <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 text-[10.5px] font-extrabold text-slate-500 dark:bg-white/10 dark:text-slate-400">
                    <CatIcon name="clock-rotate-left" className="h-[10px] w-[10px]" />
                    {fullDate(stats.oldestAt, lang)}
                  </span>
                ) : null
              }
              icon="clock-rotate-left"
              c1="#06b6d4"
              c2="#0891b2"
              index={4}
              lang={lang}
              loading={query.isPending}
            />
          </div>

          {/* strict retention bar */}
          {query.isPending ? (
            <Skeleton className="h-16 rounded-2xl" />
          ) : stats ? (
            <div
              role="note"
              className="card-in flex items-center gap-3.5 rounded-2xl border border-rose-200/80 bg-linear-to-l from-rose-50/90 to-rose-50/40 p-4 dark:border-rose-500/25 dark:from-rose-500/10 dark:to-rose-500/[0.04]"
            >
              <span
                className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-lg shadow-rose-500/30"
                style={{ backgroundImage: grad("#f43f5e", "#e11d48") }}
                aria-hidden="true"
              >
                <CatIcon name="shield" className="h-[15px] w-[15px]" />
              </span>
              <p className="text-[12.5px] font-bold leading-relaxed text-rose-700 dark:text-rose-300">
                {t("trashRetentionNote", { n: fmtNum(stats.retentionDays, lang) })}
              </p>
            </div>
          ) : null}

          {/* toolbar: search + entity pills */}
          <div className="glass-card card-in rounded-3xl p-4 sm:p-5">
            <div className="relative">
              <CatIcon
                name="search"
                className="pointer-events-none absolute start-3.5 top-1/2 h-[13px] w-[13px] -translate-y-1/2 text-slate-400"
              />
              <Input
                type="search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={t("trashSearchPh")}
                aria-label={t("trashSearchPh")}
                className="h-11 rounded-xl border-slate-200 bg-slate-50/80 ps-10 pe-3 text-[12.5px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:placeholder:text-slate-500 dark:focus:bg-white/[0.07]"
              />
            </div>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => applyEntityFilter("all")}
                aria-pressed={entityFilter === "all"}
                className={pillClass(entityFilter === "all")}
              >
                <CatIcon name="layers" className="h-3.5 w-3.5" />
                {t("trashFilterAll")}
                <span className={pillCountClass(entityFilter === "all")}>{fmtNum(stats?.total ?? 0, lang)}</span>
              </button>
              {ENTITY_ORDER.map((id) => {
                const style = ENTITY_STYLE[id];
                const active = entityFilter === id;
                const count = stats?.byEntity[id] ?? 0;
                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => applyEntityFilter(id)}
                    aria-pressed={active}
                    className={pillClass(active)}
                  >
                    <span
                      className="grid h-5 w-5 place-items-center rounded-md text-white"
                      style={{ backgroundImage: grad(style.c1, style.c2) }}
                      aria-hidden="true"
                    >
                      <CatIcon name={style.icon} className="h-2.5 w-2.5" />
                    </span>
                    {tt(lang, style.labelKey)}
                    <span className={pillCountClass(active)}>{fmtNum(count, lang)}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* item list */}
          <DashCard>
            <p className="sr-only" aria-live="polite">
              {t("trashKpiTotal")}: {fmtNum(filtered.length, lang)}
            </p>

            {query.isPending ? (
              <div className="space-y-2" aria-hidden="true">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-3 rounded-2xl border border-slate-100 p-3 dark:border-white/[0.06]"
                  >
                    <Skeleton className="h-4 w-4 rounded-[4px]" />
                    <Skeleton className="h-10 w-10 rounded-xl" />
                    <div className="min-w-0 flex-1 space-y-1.5">
                      <Skeleton className="h-3.5 w-44 max-w-full" />
                      <Skeleton className="h-2.5 w-28" />
                    </div>
                    <Skeleton className="hidden h-6 w-24 rounded-full lg:block" />
                    <div className="flex gap-2">
                      <Skeleton className="h-9 w-9 rounded-xl" />
                      <Skeleton className="h-9 w-9 rounded-xl" />
                    </div>
                  </div>
                ))}
              </div>
            ) : query.isError ? (
              <div className="py-10 text-center">
                <p className="text-[13px] font-bold text-rose-600 dark:text-rose-400">{t("errorText")}</p>
                <Button
                  variant="outline"
                  onClick={() => void query.refetch()}
                  className="mt-3 h-10 rounded-xl px-5 text-[12.5px] font-bold"
                >
                  <CatIcon name="refresh-cw" className="h-4 w-4" />
                  {t("retryText")}
                </Button>
              </div>
            ) : items.length === 0 ? (
              /* empty trash — a GOOD state */
              <div className="py-12 text-center">
                <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-emerald-50 text-emerald-500 dark:bg-emerald-500/10 dark:text-emerald-400">
                  <CatIcon name="circle-check" className="h-6 w-6" />
                </div>
                <h3 className="mt-4 font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                  {t("trashEmptyTitle")}
                </h3>
                <p className="mx-auto mt-1 max-w-sm text-[12.5px] text-slate-500 dark:text-slate-400">
                  {t("trashEmptyDesc")}
                </p>
              </div>
            ) : filtered.length === 0 ? (
              /* the filters / search ate everything */
              <div className="py-12 text-center">
                <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
                  <CatIcon name="search" className="h-6 w-6" />
                </div>
                <h3 className="mt-4 font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                  {t("trashNoResults")}
                </h3>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    applyEntityFilter("all");
                    setSearch("");
                  }}
                  className="mt-4 h-9 gap-1.5 rounded-xl px-4 text-[11.5px] font-bold"
                >
                  <CatIcon name="x" className="h-3.5 w-3.5" />
                  {t("trashFilterAll")}
                </Button>
              </div>
            ) : (
              <div className="space-y-2">
                {/* column headers (lg+) — mirror the row flex structure */}
                <div className="hidden items-center gap-3 px-3 pb-1 lg:flex">
                  <span className="w-4 shrink-0" />
                  <span className="w-10 shrink-0" />
                  <span
                    className={cn(
                      "min-w-0 flex-1 text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500",
                      labelTrack(lang)
                    )}
                  >
                    {t("trashColItem")}
                  </span>
                  <span
                    className={cn(
                      "w-36 shrink-0 text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500",
                      labelTrack(lang)
                    )}
                  >
                    {t("trashColContext")}
                  </span>
                  <span
                    className={cn(
                      "w-44 shrink-0 text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500",
                      labelTrack(lang)
                    )}
                  >
                    {t("trashColDeletedBy")}
                  </span>
                  <span
                    className={cn(
                      "w-28 shrink-0 text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500",
                      labelTrack(lang)
                    )}
                  >
                    {t("trashColDeletedAt")}
                  </span>
                  <span
                    className={cn(
                      "w-28 shrink-0 text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500",
                      labelTrack(lang)
                    )}
                  >
                    {t("trashColExpires")}
                  </span>
                  <span
                    className={cn(
                      "shrink-0 text-end text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500",
                      labelTrack(lang)
                    )}
                  >
                    {t("trashColActions")}
                  </span>
                </div>

                <ul className="space-y-2" role="list">
                  {shown.map((item) => (
                    <TrashRow
                      key={keyOf(item)}
                      item={item}
                      selected={selection.has(keyOf(item))}
                      onToggleSelect={() => toggleSelect(item)}
                      onRestore={() => setRestoreTarget(item)}
                      onPurge={() => {
                        setPurgeWord("");
                        setPurgeTarget(item);
                      }}
                      lang={lang}
                    />
                  ))}
                </ul>

                {/* client-side load-more over the fetched window */}
                {shown.length < filtered.length ? (
                  <div className="flex flex-col items-center gap-2 border-t border-dashed border-slate-200 pt-4 dark:border-white/10">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setVisibleCount((c) => c + PAGE_STEP)}
                      className="h-10 gap-2 rounded-xl border-slate-200 bg-white px-6 text-[12.5px] font-extrabold text-slate-600 shadow-none transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:bg-transparent dark:text-slate-200 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
                    >
                      <CatIcon name="chevron-down" className="h-4 w-4" />
                      {t("trashLoadMore")}
                    </Button>
                    <p className="text-[10.5px] font-bold tabular-nums text-slate-400 dark:text-slate-500">
                      {fmtNum(shown.length, lang)} / {fmtNum(filtered.length, lang)}
                    </p>
                  </div>
                ) : null}
              </div>
            )}
          </DashCard>

          {/* sticky bulk-action bar */}
          {selectedCount > 0 ? (
            <div className="card-in sticky bottom-4 z-30">
              <div className="glass-card flex flex-wrap items-center gap-2.5 rounded-2xl p-3 shadow-lift sm:gap-3">
                <span className="inline-flex items-center gap-2 rounded-full bg-brand-500/10 px-3 py-1.5 text-[12px] font-extrabold text-brand-700 dark:bg-brand-500/15 dark:text-brand-300">
                  <CatIcon name="check-check" className="h-3.5 w-3.5" />
                  {t("trashSelected", { n: fmtNum(selectedCount, lang) })}
                </span>
                <div className="flex items-center gap-1">
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={toggleSelectAll}
                    className="h-8 rounded-lg px-2.5 text-[11px] font-bold text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100"
                  >
                    {t("trashSelectAll")}
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => setSelection(new Set())}
                    className="h-8 rounded-lg px-2.5 text-[11px] font-bold text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100"
                  >
                    {t("trashClearSel")}
                  </Button>
                </div>
                <span className="min-w-0 flex-1" aria-hidden="true" />
                <Button
                  type="button"
                  onClick={() => void runBulk("restore")}
                  disabled={bulkBusy !== null}
                  className="h-10 gap-2 rounded-xl bg-emerald-600 px-4 text-[12px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:bg-emerald-700 active:scale-95 disabled:opacity-60 sm:px-5 sm:text-[12.5px]"
                >
                  {bulkBusy === "restore" ? (
                    <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                  ) : (
                    <CatIcon name="rotate-ccw" className="h-4 w-4" />
                  )}
                  {t("trashBulkRestore")}
                </Button>
                <Button
                  type="button"
                  onClick={() => {
                    setBulkPurgeWord("");
                    setBulkPurgeOpen(true);
                  }}
                  disabled={bulkBusy !== null}
                  className="h-10 gap-2 rounded-xl bg-rose-600 px-4 text-[12px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60 sm:px-5 sm:text-[12.5px]"
                >
                  <CatIcon name="flame" className="h-4 w-4" />
                  {t("trashBulkPurge")}
                </Button>
              </div>
            </div>
          ) : null}
        </>
      )}

      {/* single restore confirm */}
      <AlertDialog
        open={restoreTarget !== null}
        onOpenChange={(o) => {
          if (!o) setRestoreTarget(null);
        }}
      >
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              {restoreStyle ? <IconTile icon={restoreStyle.icon} c1={restoreStyle.c1} c2={restoreStyle.c2} /> : null}
              {t("trashRestoreConfirmTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[12.5px] leading-relaxed">
              {restoreTarget ? t("trashRestoreConfirmDesc", { label: restoreTarget.label }) : ""}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={restore.isPending} className="h-10 rounded-xl px-5 text-[12.5px] font-bold">
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                if (restoreTarget) restore.mutate(restoreTarget);
              }}
              disabled={restore.isPending}
              className="h-10 gap-2 rounded-xl bg-emerald-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:bg-emerald-700 active:scale-95 disabled:opacity-60"
            >
              {restore.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="rotate-ccw" className="h-4 w-4" />
              )}
              {t("trashRestoreConfirmAction")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* single purge confirm — STRICT type-to-confirm */}
      <AlertDialog
        open={purgeTarget !== null}
        onOpenChange={(o) => {
          if (!o) {
            setPurgeTarget(null);
            setPurgeWord("");
          }
        }}
      >
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-rose-500/10 text-rose-500 dark:text-rose-400">
                <CatIcon name="flame" className="h-5 w-5" />
              </span>
              {t("trashPurgeConfirmTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[12.5px] leading-relaxed">
              {purgeTarget ? t("trashPurgeConfirmDesc", { label: purgeTarget.label }) : ""}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <TypeConfirmInput
            id="trash-purge-word"
            value={purgeWord}
            onChange={setPurgeWord}
            label={t("trashConfirmType", { word: confirmWord })}
            placeholder={confirmWord}
          />
          <AlertDialogFooter>
            <AlertDialogCancel disabled={purge.isPending} className="h-10 rounded-xl px-5 text-[12.5px] font-bold">
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                if (purgeTarget && purgeWord === confirmWord) purge.mutate(purgeTarget);
              }}
              disabled={purgeWord !== confirmWord || purge.isPending}
              className="h-10 gap-2 rounded-xl bg-rose-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/30 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60"
            >
              {purge.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="flame" className="h-4 w-4" />
              )}
              {t("trashPurgeConfirmAction")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* bulk purge confirm — the same strict ceremony, irreversible mass action */}
      <AlertDialog
        open={bulkPurgeOpen}
        onOpenChange={(o) => {
          setBulkPurgeOpen(o);
          if (!o) setBulkPurgeWord("");
        }}
      >
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-rose-500/10 text-rose-500 dark:text-rose-400">
                <CatIcon name="flame" className="h-5 w-5" />
              </span>
              {t("trashPurgeConfirmTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[12.5px] leading-relaxed">
              {t("trashPurgeConfirmDesc", {
                label: joinLabels(
                  selectedItems.map((it) => it.label),
                  lang
                ),
              })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <TypeConfirmInput
            id="trash-bulk-purge-word"
            value={bulkPurgeWord}
            onChange={setBulkPurgeWord}
            label={t("trashConfirmType", { word: confirmWord })}
            placeholder={confirmWord}
          />
          <AlertDialogFooter>
            <AlertDialogCancel disabled={bulkBusy !== null} className="h-10 rounded-xl px-5 text-[12.5px] font-bold">
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                if (bulkPurgeWord === confirmWord) void runBulk("purge");
              }}
              disabled={bulkPurgeWord !== confirmWord || bulkBusy !== null}
              className="h-10 gap-2 rounded-xl bg-rose-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/30 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60"
            >
              {bulkBusy === "purge" ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="flame" className="h-4 w-4" />
              )}
              {t("trashPurgeConfirmAction")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
