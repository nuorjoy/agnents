"use client";

/**
 * Dashboard — module workspace (round 25).
 *
 * Clicking an ENABLED module card opens this premium detail surface: a
 * KPI strip, a searchable/filterable data table with status pills, a
 * mini bar chart, status distribution, CSV export and pagination. The
 * dataset is deterministic per (instance, module) — stable across
 * reloads (see src/lib/module-data.ts).
 *
 * ROUND 78 — this file is now a ROUTER: the «المخزون» (inventory) module
 * branches to the DEDICATED premium inventory workspace
 * (./inventory/inventory-workspace.tsx — KPI strip, stock table with
 * reorder-point health bars, movements feed, alert thresholds,
 * valuation breakdown). Every other module renders the generic surface
 * below with ZERO behavior change. The router reads ONE store field
 * before delegating, so hook order is stable across module switches.
 */
import { useMemo, useState, type FormEvent } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CATEGORY_MAP, MODULE_MAP, SYSTEM_MAP, moduleDisplayName } from "@/data/catalog";
import { useT } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import type { InstanceDTO, Lang, ProductVariantDTO } from "@/lib/types";
import type { PaymentEntry } from "@/lib/payment-methods";
import { paymentsPrimaryLabel } from "@/lib/payment-methods";
import { PaymentManagerSection } from "@/components/dashboard/views/business/payment-manager";
import { buildModuleDataset, buildRecordsDataset, codePrefixFor, type ColDef, type StatusDef, type StatusTone } from "@/lib/module-data";
import {
  ApiError,
  createModuleRecord,
  deleteModuleRecord,
  fetchModuleRecords,
  fetchSite,
  updateModuleRecord,
} from "@/lib/api-client";
import { DEFAULT_INVOICE_PREFIX, nextRecordCode } from "@/lib/record-code";
import { MODULE_FEATURE_GATES } from "@/lib/plan-features";
import { FeatureGate } from "@/components/dashboard/feature-gate";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, hexAlpha } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PremiumDateInput } from "@/components/ui/premium-date-input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { DashCard } from "@/components/dashboard/dash-shared";
import { AiInsightsPanel } from "@/components/dashboard/views/ai-insights-panel";
import { RecordPrintDialog, moneyColumnsTotalMinor, type PrintDoc } from "@/components/dashboard/views/record-print";
import {
  ProductMediaPickerSection,
  VariantsBuilderSection,
  variantRowsFromDTO,
  variantRowsToWire,
  type ProductMediaPickerValue,
  type VariantsBuilderValue,
} from "@/components/dashboard/views/product-form-extras";
import { storeProductModuleId } from "@/lib/store-modules";
import { uploadStoreImage } from "@/lib/api-client";
import { InventoryWorkspace } from "@/components/dashboard/views/inventory/inventory-workspace";
import { ShiftsWorkspace } from "@/components/dashboard/views/shift/shifts-workspace";
import { AttendanceWorkspace } from "@/components/dashboard/views/attendance/attendance-workspace";
import { BusinessWorkspace } from "@/components/dashboard/views/business/business-suite";

const TONE_STYLE: Record<StatusTone, string> = {
  emerald: "bg-emerald-500/12 text-emerald-700 dark:text-emerald-300",
  amber: "bg-amber-500/12 text-amber-700 dark:text-amber-300",
  rose: "bg-rose-500/12 text-rose-700 dark:text-rose-300",
  sky: "bg-sky-500/12 text-sky-700 dark:text-sky-300",
  violet: "bg-violet-500/12 text-violet-700 dark:text-violet-300",
  slate: "bg-slate-500/12 text-slate-600 dark:text-slate-300",
};
const TONE_DOT: Record<StatusTone, string> = {
  emerald: "bg-emerald-500",
  amber: "bg-amber-500",
  rose: "bg-rose-500",
  sky: "bg-sky-500",
  violet: "bg-violet-500",
  slate: "bg-slate-400",
};

const PAGE_SIZE = 8;

function statusLabel(key: string, statuses: { key: string; ar: string; en: string }[], lang: Lang): string {
  /* rows only carry ar/en columns — non-Arabic locales (incl. Hindi round 41)
     explicitly fall back to the ENGLISH label instead of the raw key. */
  const row = statuses.find((s) => s.key === key);
  if (!row) return key;
  return lang === "ar" ? row.ar : row.en;
}

/** round 29 — modules whose documents carry the invoice letterhead brand */
const MONEY_MODULE_KEYS = new Set([
  "invoices",
  "payments",
  "pos",
  "orders",
  "purchases",
  "billing",
  "fees",
]);

export function ModuleWorkspace({ instance }: { instance: InstanceDTO }) {
  /* ROUND 78 — inventory router: ONE store read before delegating, so the
   * router's hook order never changes when modules switch. The dedicated
   * workspace owns its own queries/mutations/state; the generic surface
   * below is untouched for every other module. */
  const activeModuleId = useAppStore((s) => s.activeModuleId);
  if (activeModuleId === "inventory") {
    return <InventoryWorkspace instance={instance} />;
  }
  /* ROUND 134 — الورديات module workspace: REAL Shift rows (the shared
   * ["shifts", id] cache) with the strict-law KPI strip — never synthetic
   * preset rows. Reached from the ENABLED الورديات card in the الوحدات
   * control of every system. */
  if (activeModuleId === "shifts") {
    return <ShiftsWorkspace instance={instance} />;
  }
  /* ROUND 166 — الحضور والغياب (attendance): the dedicated 8-state
   * attendance console (today board + movements + allowances + policy +
   * gate QR) over the REAL attendance API. Student-accommodation ONLY —
   * every other system's attendance module keeps the generic
   * business-suite surface below. Keyed by module → a fresh mount per
   * module switch (the family convention). */
  if (activeModuleId === "attendance" && instance.systemId === "student-accommodation") {
    return <AttendanceWorkspace key={activeModuleId} instance={instance} />;
  }
  /* ROUND 132 — the owner's directive («طور وحدات النظام بدقة عالية مثل
   * الأنظمة الكبيرة والعالمية»): EVERY module now renders through the
   * premium business suite — the explicit registry (POS/products/…/11
   * commerce modules) plus the ROUND-132 fallback generator (KPIs/
   * analytics/premium table/schema forms derived from each module's
   * domain preset — the 93 new preset families). The POS add-action
   * opens the full terminal; stocktake opens the count engine (inside
   * the suite). The generic surface below stays exported as the
   * belt-and-suspenders fallback for any module the catalog retires
   * mid-session (e.g. legacy rows of the retired standalone barcode
   * module). */
  if (activeModuleId) {
    /* keyed by module — every module switch is a FRESH mount: the tab
     * (demo|mine), search, filters and pagination reset cleanly instead
     * of leaking from the previously open module. */
    return <BusinessWorkspace key={activeModuleId} instance={instance} />;
  }
  return <GenericModuleWorkspace instance={instance} />;
}

export function GenericModuleWorkspace({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const setDashView = useAppStore((s) => s.setDashView);
  const activeModuleId = useAppStore((s) => s.activeModuleId);
  const setActiveModuleId = useAppStore((s) => s.setActiveModuleId);
  const queryClient = useQueryClient();

  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [page, setPage] = useState(0);

  /* ---------------- round 30 — REAL persisted rows (سجلاتي) ------------- */
  const recordsQuery = useQuery({
    queryKey: ["module-records", instance.id, activeModuleId],
    queryFn: () => fetchModuleRecords(instance.id, activeModuleId as string),
    enabled: !!activeModuleId,
    staleTime: 30_000,
    retry: 0,
  });
  const records = recordsQuery.data ?? [];

  /* tab state keyed to the module id — derived reset when the module
     changes (no effects): the source defaults back to the demo dataset.
     ROUND 166 — DEMO LIFECYCLE: prefs.demo («بيانات تجريبية», wizard prefs
     step + settings) now GOVERNS the showcase. Enabled → the demo tab is
     available and stays the landing tab (the historical behavior).
     Disabled → the demo tab, dataset and seeded codes disappear entirely:
     the workspace lands on the tenant's real records (سجلاتي) — the honest
     zero state with the first-run CTA. The toggle's full lifecycle
     (activate = showcase appears · deactivate = everything demo vanishes)
     finally behaves as the prefs card always promised. */
  const demoEnabled = instance.prefs.demo !== false;
  const [tabState, setTabState] = useState<{ moduleId: string; source: "demo" | "mine" }>({
    moduleId: "",
    source: "demo",
  });
  const source: "demo" | "mine" = !demoEnabled
    ? "mine"
    : tabState.moduleId === activeModuleId
      ? tabState.source
      : "demo";
  const setSource = (next: "demo" | "mine") => {
    if (!demoEnabled && next === "demo") return; /* retired with the toggle */
    setTabState({ moduleId: activeModuleId ?? "", source: next });
  };

  /* the add/edit dialog + delete confirm (round 30 — REAL rows) */
  const [recordDialog, setRecordDialog] = useState<{ record: RecordDraft | null } | null>(null);
  const [pendingDelete, setPendingDelete] = useState<RecordDraft | null>(null);

  /* ROUND 36 — professional record printing: state only; the doc builder
     lives below (after the dataset derivation) so the compiler's
     memoization analysis stays clean. */
  const [printDoc, setPrintDoc] = useState<PrintDoc | null>(null);

  const invalidateRecords = () => {
    void queryClient.invalidateQueries({ queryKey: ["module-records", instance.id, activeModuleId] });
  };

  const saveRecord = useMutation({
    mutationFn: (payload: {
      recordId: string | null;
      values: string[];
      statusKey: string;
      payments: PaymentEntry[];
      /** ROUND 141 (product extras) — the uploaded/kept gallery (undefined =
       *  don't touch media) + the variant rows (undefined = keep). */
      gallery?: string[];
      variants?: { id?: string; name: string; price?: number; stock?: number; sku?: string }[];
    }) =>
      payload.recordId
        ? updateModuleRecord(instance.id, payload.recordId, {
            values: payload.values,
            statusKey: payload.statusKey,
            /* ROUND 141 (㉕) — the structured ledger rides the same PATCH. */
            payments: payload.payments,
            /* ROUND 141 (product extras) — the gallery + variants ride it too. */
            ...(payload.gallery !== undefined ? { gallery: payload.gallery } : {}),
            ...(payload.variants !== undefined ? { variants: payload.variants } : {}),
          })
        : createModuleRecord(instance.id, {
            moduleId: activeModuleId as string,
            values: payload.values,
            statusKey: payload.statusKey,
            payments: payload.payments,
            ...(payload.gallery !== undefined ? { gallery: payload.gallery } : {}),
            ...(payload.variants !== undefined ? { variants: payload.variants } : {}),
          }),
    onSuccess: (_data, payload) => {
      invalidateRecords();
      setSource("mine");
      setRecordDialog(null);
      toast.success(payload.recordId ? t("modRecUpdated") : t("modRecSaved"));
    },
    onError: (e: Error) => {
      /* 409 RECORD_CONFLICT — a concurrent order changed the row underneath
       * the editor; refresh the table so the owner sees the live stock. */
      if (e instanceof ApiError && e.status === 409) invalidateRecords();
      toast.error(e.message || t("modRecSaveErr"));
    },
  });

  const removeRecord = useMutation({
    mutationFn: (recordId: string) => deleteModuleRecord(instance.id, recordId),
    onSuccess: () => {
      invalidateRecords();
      setPendingDelete(null);
      toast.success(t("modRecDeleted"));
    },
    onError: (e: Error) => toast.error(e.message || t("modRecDeleteErr")),
  });

  /* round 29 — the workspace brand (org logo) shared with the website view:
     money modules preview the real invoice letterhead; every workspace shows
     a compact identity chip. Cached under the same key as WebsiteView. */
  const siteQuery = useQuery({
    queryKey: ["site", instance.id],
    queryFn: () => fetchSite(instance.id),
    staleTime: 60_000,
    retry: 0,
  });
  const logoUrl = siteQuery.data?.content.logoUrl ?? "";
  /* ROUND 68 — owner-configured invoice code prefix (settings → الهوية
     والعلامة → بادئة الفاتورة; "" = module default INV). */
  const invoicePrefix = siteQuery.data?.content.invoicePrefix || DEFAULT_INVOICE_PREFIX;

  const system = SYSTEM_MAP[instance.systemId];
  const cat = system ? CATEGORY_MAP[system.c] : undefined;
  const c1 = cat?.c1 ?? "#6d5dfb";
  const c2 = cat?.c2 ?? "#0ea5e9";

  const mod = activeModuleId ? MODULE_MAP[activeModuleId] : undefined;
  /* ROUND 64 — sector-correct module vocabulary (per-system override:
     e.g. "Staff" renders as "الكوادر الطبية" inside the hospital system) */
  const moduleName = activeModuleId
    ? moduleDisplayName(activeModuleId, instance.systemId, lang)
    : "";
  const systemName = system ? (lang === "ar" ? system.nameAr : system.nameEn) : instance.systemId;
  const categoryName = cat ? (lang === "ar" ? cat.nameAr : cat.nameEn) : "";

  /* deterministic DEMO dataset — memoized on the identity inputs.
   *  ROUND 129: systemId rides along so the rows speak the system's sector
   *  (a hotel workspace's demo rows read like a hotel).
   *  ROUND 166: not built at all when the demo lifecycle is retired
   *  (prefs.demo=false) — the showcase stays off the wire and out of
   *  memory, not merely hidden. */
  const demoData = useMemo(
    () =>
      activeModuleId && demoEnabled
        ? buildModuleDataset(instance.id, activeModuleId, lang, instance.org.currency, instance.systemId)
        : null,
    [instance.id, instance.org.currency, instance.systemId, activeModuleId, lang, demoEnabled]
  );
  /* round 30 — REAL rows dataset (سجلاتي tab) with live KPIs/series.
   *  ROUND 166: built whenever the demo showcase is retired (the mine
   *  tab is the only surface then). */
  const myData = useMemo(
    () =>
      activeModuleId && (source === "mine" || !demoEnabled)
        ? buildRecordsDataset(activeModuleId, records, lang, instance.org.currency, instance.systemId)
        : null,
    [activeModuleId, source, records, lang, instance.org.currency, instance.systemId, demoEnabled]
  );
  const data = source === "mine" ? myData : demoData;

  /* ---------------- ROUND 68 — record-code machinery ----------------
   * The id-column auto-number for NEW records: 8-digit capacity
   * (record-code.ts), continuing from EVERY existing code — demo seeds
   * AND real rows, both tabs — so generated codes never collide and legacy
   * short codes keep their series. The invoices module uses the
   * owner-configured prefix + the classic year-qualified format. */
  const idColIndex = data?.cols.findIndex((c) => c.kind === "id") ?? -1;
  const isInvoiceModule = activeModuleId === "invoices";
  const modulePrefix = isInvoiceModule
    ? invoicePrefix
    : activeModuleId
      ? codePrefixFor(activeModuleId)
      : "";
  const allCodes = useMemo(() => {
    if (idColIndex < 0) return [] as string[];
    const codes: string[] = [];
    for (const row of demoData?.rows ?? []) {
      const code = row.values[idColIndex];
      if (code) codes.push(code);
    }
    for (const row of records) {
      const code = row.values[idColIndex];
      if (code) codes.push(code);
    }
    return codes;
  }, [demoData, records, idColIndex]);
  const suggestedCode =
    idColIndex >= 0 && activeModuleId
      ? nextRecordCode(modulePrefix, allCodes, { invoice: isInvoiceModule })
      : null;

  /* ---------------- filtering (hooks stay above any early return) ------ */
  const rows = data?.rows ?? [];
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return rows.filter((row) => {
      if (statusFilter !== "all" && row.statusKey !== statusFilter) return false;
      if (!q) return true;
      return row.values.some((v) => v.toLowerCase().includes(q));
    });
  }, [rows, query, statusFilter]);

  const pages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, pages - 1);
  const pageRows = filtered.slice(safePage * PAGE_SIZE, safePage * PAGE_SIZE + PAGE_SIZE);

  const maxValue = Math.max(...(data?.series ?? [1]), 1);
  const seriesSum = (data?.series ?? []).reduce((s, v) => s + v, 0);
  /* modules without a money column show "total activity" instead of a value */
  const hasMoney = !!data?.valueKey;

  /* ROUND 36 — professional record printing: the row feeds a formal document
     preview (letterhead + field table + status stamp); the dialog prints only
     the .print-doc root (see globals.css @media print).
     ROUND 141 (㉕) — the structured payment ledger + the money-column grand
     total ride the doc so the settlement strip prints on the paper. */
  const buildPrintDoc = (row: { values: string[]; statusKey: string; payments?: PaymentEntry[] }) => {
    const fields: PrintDoc["fields"] = [];
    data?.cols.forEach((col, i) => {
      const value = row.values[i] ?? "";
      if (col.kind === "status") return; /* rendered as the stamp below */
      fields.push({
        label: lang === "ar" ? col.ar : col.en,
        value,
        kind: col.kind === "num" ? "num" : col.kind,
      });
    });
    const st = data?.statuses.find((s) => s.key === row.statusKey);
    setPrintDoc({
      title: row.values[0] ?? "—",
      moduleName,
      fields,
      statusLabel: st ? statusLabel(st.key, data?.statuses ?? [], lang) : null,
      payments: row.payments ?? [],
      totalMinor: moneyColumnsTotalMinor(data?.cols ?? [], row.values),
    });
  };

  if (!activeModuleId || !data) {
    /* no module selected (deep link / stale persisted state) → modules grid */
    return (
      <div className="space-y-5">
        <DashCard title={t("modOpenTitle")} icon="cubes">
          <p className="text-[12.5px] text-slate-500 dark:text-slate-400">{t("modOpenEmptyDesc")}</p>
          <Button
            onClick={() => setDashView("modules")}
            className="mt-4 h-10 rounded-xl px-5 text-[12.5px] font-bold text-white shadow-lg shadow-brand-500/25 hover:brightness-110"
            style={{ backgroundImage: grad(c1, c2) }}
          >
            <CatIcon name="cubes" className="h-4 w-4" />
            {t("dashModulesTitle")}
          </Button>
        </DashCard>
      </div>
    );
  }

  /* ROUND 80 — premium-module plan gate: a gated module whose feature is
     OFF in the entitlement mirror renders the full-view FeatureGate lock
     instead of the workspace (deep links / persisted dash state can still
     land here; the records API refuses independently — this mirror only
     renders, never gates). undefined features = legacy DTO → fail-open
     client-side; the server stays the authority. */
  const gatedFeature = activeModuleId ? MODULE_FEATURE_GATES[activeModuleId] : undefined;
  if (gatedFeature && instance.entitlement?.features?.[gatedFeature] === false) {
    return <FeatureGate feature={gatedFeature} instance={instance} title={moduleName} />;
  }

  /* ---------------- CSV export (client-side, real file) ---------------- */
  const exportCsv = () => {
    const header = data.cols.map((c) => (lang === "ar" ? c.ar : c.en)).join(",");
    const lines = filtered.map((r) =>
      r.values.map((v) => (v.includes(",") ? `"${v}"` : v)).join(",")
    );
    const csv = `\uFEFF${[header, ...lines].join("\n")}`;
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${instance.org.name}-${activeModuleId}-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(t("modExportDone"), { description: `${filtered.length} ${t("modRowsUnit")}` });
  };

  const backToModules = () => {
    setActiveModuleId(null);
    setDashView("modules");
  };

  /* ---------------- KPI cards ---------------- */
  const kpis = [
    {
      key: "modKpiTotal",
      value: fmtNum(data.kpis.total, lang),
      icon: "database",
      c1,
      c2,
    },
    {
      key: "modKpiMonthly",
      value: fmtNum(data.kpis.monthly, lang),
      icon: "calendar-check",
      c1: "#f59e0b",
      c2: "#d97706",
      delta: data.kpis.growth,
    },
    {
      key: "modKpiActive",
      value: fmtNum(data.kpis.active, lang),
      icon: "circle-check",
      c1: "#10b981",
      c2: "#047857",
    },
    {
      key: hasMoney ? "modKpiValue" : "modWeeklySum",
      value: hasMoney
        ? `${fmtNum(Math.round(data.kpis.value), lang)} ${data.currency}`
        : fmtNum(seriesSum, lang),
      icon: hasMoney ? "wallet" : "activity",
      c1: "#06b6d4",
      c2: "#0891b2",
    },
  ] as const;

  /* round 29 — money modules carry the invoice-letterhead brand preview */
  const moneyModule = MONEY_MODULE_KEYS.has(activeModuleId ?? "");

  return (
    <div className="space-y-5">
      {/* ---------------- header ---------------- */}
      <div className="glass-card card-in rounded-3xl p-4 sm:p-5">
        <div className="flex flex-wrap items-start gap-3">
          <button
            type="button"
            onClick={backToModules}
            aria-label={t("modBackToModules")}
            className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-slate-200 text-slate-500 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:text-slate-300"
          >
            <CatIcon name="arrow-right" className="h-4 w-4 rtl:rotate-180" />
          </button>

          <span
            className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
            style={{ backgroundImage: grad(c1, c2), boxShadow: `0 14px 30px -12px ${hexAlpha(c1, 0.8)}` }}
          >
            <CatIcon name={mod?.icon ?? "cubes"} className="h-6 w-6" />
          </span>

          <div className="min-w-0 flex-1">
            <h1 className="flex flex-wrap items-center gap-2 font-display text-2xl font-extrabold text-slate-900 dark:text-white">
              {moduleName}
              <Badge className="gap-1 bg-emerald-500/15 text-[10.5px] text-emerald-600 hover:bg-emerald-500/15 dark:text-emerald-400">
                <CatIcon name="circle-check" className="h-3 w-3" />
                {t("dashEnabled")}
              </Badge>
            </h1>
            <p className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-[12px] font-semibold text-slate-500 dark:text-slate-400">
              <span className="inline-flex items-center gap-1">
                <CatIcon name="boxes" className="h-3.5 w-3.5" />
                {systemName}
              </span>
              {categoryName ? (
                <>
                  <span className="text-slate-300 dark:text-slate-600">·</span>
                  <span>{categoryName}</span>
                </>
              ) : null}
              <span className="text-slate-300 dark:text-slate-600">·</span>
              <span dir="ltr" className="font-mono text-[10.5px] text-slate-400 dark:text-slate-500">
                {activeModuleId}
              </span>
              {/* round 29 — workspace identity chip (the org logo) */}
              <span className="ms-1 inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white/70 px-2 py-0.5 text-[10px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300">
                {logoUrl ? (
                  <span className="grid h-3.5 w-3.5 place-items-center overflow-hidden rounded-sm">
                    { }
                    <img src={logoUrl} alt="" className="h-3.5 w-3.5 object-contain" />
                  </span>
                ) : (
                  <CatIcon name="building" className="h-3 w-3" />
                )}
                <span className="max-w-40 truncate">{instance.org.name}</span>
              </span>
            </p>
          </div>

          <div className="flex shrink-0 items-center gap-2">
            <Button
              type="button"
              onClick={exportCsv}
              className="h-10 gap-2 rounded-xl border border-slate-200 bg-white px-4 text-[12px] font-bold text-slate-700 shadow-sm transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200"
            >
              <CatIcon name="download" className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">{t("modExportCsv")}</span>
            </Button>
            <Button
              type="button"
              id="workspace-add-record"
              onClick={() => setRecordDialog({ record: null })}
              className="h-10 gap-2 rounded-xl px-4 text-[12px] font-bold text-white shadow-lg transition hover:brightness-110 active:scale-95"
              style={{ backgroundImage: grad(c1, c2) }}
            >
              <CatIcon name="plus" className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">{t("modAddRecord")}</span>
            </Button>
          </div>
        </div>
      </div>

      {/* ROUND 41 — Premium AI insights scoped to THIS module's records */}
      <AiInsightsPanel instanceId={instance.id} moduleId={activeModuleId ?? undefined} />

      {/* ---------------- round 29: invoice letterhead brand ---------------- */}
      {moneyModule ? (
        <div className="glass-card card-in rounded-3xl p-4 sm:p-5">
          {logoUrl ? (
            <div>
              <p className="mb-3 flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                <CatIcon name="receipt" className="h-3.5 w-3.5" />
                {t("wsBrandTitle")}
              </p>
              {/* the letterhead exactly as it heads an invoice */}
              <div className="flex flex-wrap items-start justify-between gap-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/[0.04]">
                <div className="flex min-w-0 items-center gap-3.5">
                  <span className="grid h-16 w-16 shrink-0 place-items-center overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-white/10">
                    { }
                    <img src={logoUrl} alt="" className="h-full w-full object-contain p-1.5" />
                  </span>
                  <div className="min-w-0">
                    <p className="truncate font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                      {instance.org.name}
                    </p>
                    {siteQuery.data?.content.contactPhone ? (
                      <p dir="ltr" className="mt-0.5 truncate text-start font-mono text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                        {siteQuery.data.content.contactPhone}
                      </p>
                    ) : null}
                    {siteQuery.data?.content.contactAddress ? (
                      <p className="mt-0.5 max-w-xs truncate text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                        {siteQuery.data.content.contactAddress}
                      </p>
                    ) : null}
                  </div>
                </div>
                <div className="text-end">
                  <p
                    className="font-display text-[13px] font-extrabold"
                    style={{ color: c1 }}
                  >
                    {lang === "ar" ? "فاتورة" : "INVOICE"}
                  </p>
                  {/* ROUND 68 — the NEXT code this workspace will issue (module
                      prefix + 8-digit capacity, owner-configured for invoices) */}
                  <p dir="ltr" className="mt-0.5 font-mono text-[11px] font-bold text-slate-500 dark:text-slate-400">
                    #{suggestedCode ?? `${modulePrefix}-00000001`}
                  </p>
                </div>
              </div>
              <p className="mt-2.5 flex items-start gap-1.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                <CatIcon name="badge-check" className="mt-0.5 h-3 w-3 shrink-0 text-emerald-500" />
                {t("wsBrandHint")}
              </p>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setDashView("website")}
              className="flex w-full items-center gap-3.5 rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50/40 p-4 text-start transition hover:border-brand-300 hover:bg-brand-50/30 dark:border-white/10 dark:bg-white/[0.02] dark:hover:border-brand-500/40"
            >
              <span
                className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
                style={{ backgroundImage: "linear-gradient(135deg,#6d5dfb,#a855f7)" }}
              >
                <CatIcon name="image-plus" className="h-5 w-5" />
              </span>
              <span className="min-w-0">
                <span className="block text-[12.5px] font-extrabold text-slate-700 dark:text-slate-200">
                  {t("wsBrandUpload")}
                </span>
                <span className="mt-0.5 block text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                  {t("wsBrandHint")}
                </span>
              </span>
              <CatIcon name="arrow-left" className="ms-auto h-4 w-4 shrink-0 text-slate-400 rtl:rotate-180" />
            </button>
          )}
        </div>
      ) : null}

      {/* ---------------- KPI strip ---------------- */}
      <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
        {kpis.map((kpi, i) => (
          <article
            key={kpi.key}
            className="glass-card card-in group relative overflow-hidden rounded-3xl p-4 transition-shadow duration-300 hover:shadow-lift"
            style={{ "--i": i } as React.CSSProperties}
          >
            <span
              className="pointer-events-none absolute inset-x-0 top-0 h-[2px] opacity-50 transition-opacity duration-300 group-hover:opacity-100"
              style={{ backgroundImage: grad(kpi.c1, kpi.c2, 90) }}
              aria-hidden="true"
            />
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="truncate text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  {t(kpi.key)}
                </p>
                <p className="mt-1.5 truncate font-display text-xl font-extrabold text-slate-900 sm:text-2xl dark:text-white">
                  {kpi.value}
                </p>
                {"delta" in kpi && kpi.delta !== undefined ? (
                  <span
                    className={cn(
                      "mt-2 inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-extrabold",
                      kpi.delta >= 0
                        ? "bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400"
                        : "bg-rose-50 text-rose-600 dark:bg-rose-500/10 dark:text-rose-400"
                    )}
                  >
                    <CatIcon name={kpi.delta >= 0 ? "trending-up" : "trending-down"} className="h-[10px] w-[10px]" />
                    {kpi.delta >= 0 ? "+" : ""}
                    {fmtNum(kpi.delta)}%
                  </span>
                ) : null}
              </div>
              <span
                className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white"
                style={{ backgroundImage: grad(kpi.c1, kpi.c2) }}
              >
                <CatIcon name={kpi.icon} className="h-[13px] w-[13px]" />
              </span>
            </div>
          </article>
        ))}
      </div>

      {/* ---------------- data table ---------------- */}
      <DashCard
        title={t("modRecordsTitle", { name: moduleName })}
        icon="table"
        action={
          <span dir="ltr" className="rounded-full border border-slate-200 bg-slate-50 px-2.5 py-0.5 text-[10.5px] font-extrabold tabular-nums text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
            {filtered.length}/{data.rows.length}
          </span>
        }
      >
        {/* toolbar */}
        <div className="mb-4 flex flex-wrap items-center gap-2">
          {/* round 30 — data source: demo showcase vs MY persisted records.
              ROUND 166 — the demo tab exists ONLY while the demo lifecycle
              is enabled (prefs.demo); retired → single-source honesty. */}
          <div
            role="tablist"
            aria-label={t("modRecSourceLabel")}
            className="flex items-center rounded-full border border-slate-200 bg-slate-50 p-0.5 dark:border-white/10 dark:bg-white/[0.04]"
          >
            {(demoEnabled ? (["demo", "mine"] as const) : (["mine"] as const)).map((tab) => (
              <button
                key={tab}
                type="button"
                role="tab"
                aria-selected={source === tab}
                onClick={() => setSource(tab)}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-[11.5px] font-extrabold transition",
                  source === tab
                    ? "text-white shadow-md"
                    : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white"
                )}
                style={source === tab ? { backgroundImage: grad(c1, c2) } : undefined}
              >
                <CatIcon name={tab === "demo" ? "flask-conical" : "database"} className="h-3 w-3" />
                {tab === "demo" ? t("modRecTabDemo") : t("modRecTabMine")}
                {tab === "mine" ? (
                  <span dir="ltr" className="rounded-full bg-white/25 px-1.5 text-[10px] tabular-nums">
                    {fmtNum(records.length, lang)}
                  </span>
                ) : null}
              </button>
            ))}
          </div>
          <div className="relative min-w-0 flex-1 sm:max-w-xs">
            <CatIcon
              name="search"
              className="pointer-events-none absolute start-3.5 top-1/2 h-[12px] w-[12px] -translate-y-1/2 text-slate-400"
            />
            <Input
              type="search"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setPage(0);
              }}
              placeholder={t("modSearchPh")}
              aria-label={t("modSearchPh")}
              className="h-10 rounded-xl border-slate-200 bg-slate-50/80 ps-10 pe-3 text-[12.5px] font-semibold dark:border-white/10 dark:bg-white/[0.04]"
            />
          </div>
          <Select
            value={statusFilter}
            onValueChange={(v) => {
              setStatusFilter(v);
              setPage(0);
            }}
          >
            <SelectTrigger className="h-10 w-auto min-w-36 rounded-xl text-[12.5px] font-semibold">
              <SelectValue placeholder={t("modFilterAll")} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t("modFilterAll")}</SelectItem>
              {data.statuses.map((s) => (
                <SelectItem key={s.key} value={s.key}>
                  <span className="flex items-center gap-2">
                    <span className={cn("h-2 w-2 rounded-full", TONE_DOT[s.tone])} aria-hidden="true" />
                    {statusLabel(s.key, data.statuses, lang)}
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* table (scrolls horizontally on narrow screens) — round 35:
            phones render the stacked card list below instead; the table is
            desktop/tablet only when rows exist (empty states stay visible) */}
        <div
          className={cn(
            "overflow-hidden rounded-2xl border border-slate-200/80 dark:border-white/10",
            pageRows.length > 0 && "hidden md:block"
          )}
        >
          <div className="max-h-[520px] overflow-auto nice-scroll">
            <table className="w-full min-w-[680px] border-collapse text-start">
              <thead className="sticky top-0 z-10">
                <tr className="bg-slate-100/95 backdrop-blur dark:bg-[#0b1220]/95">
                  {data.cols.map((col) => (
                    <th
                      key={col.key}
                      scope="col"
                      className={cn(
                        "whitespace-nowrap px-3.5 py-2.5 text-[10.5px] font-extrabold uppercase tracking-wide text-slate-500 dark:text-slate-400",
                        col.kind === "num" || col.kind === "money" ? "text-end" : "text-start"
                      )}
                    >
                      {lang === "ar" ? col.ar : col.en}
                    </th>
                  ))}
                  {/* ROUND 36 — actions column on EVERY tab (print for all;
                      edit/delete on the REAL records tab) */}
                  <th
                    scope="col"
                    className="w-px whitespace-nowrap px-2.5 py-2.5 text-end text-[10.5px] font-extrabold uppercase tracking-wide text-slate-500 dark:text-slate-400"
                  >
                    {t("modRecActionsCol")}
                  </th>
                </tr>
              </thead>
              <tbody>
                {pageRows.length === 0 ? (
                  source === "mine" && records.length === 0 ? (
                    /* round 30 — first-run empty state for the REAL records tab */
                    <tr>
                      <td colSpan={data.cols.length + 1} className="px-4 py-12 text-center">
                        <span
                          className="mx-auto grid h-14 w-14 place-items-center rounded-2xl text-white shadow-lg"
                          style={{ backgroundImage: grad(c1, c2) }}
                        >
                          <CatIcon name="database" className="h-6 w-6" />
                        </span>
                        <p className="mt-3 font-display text-[15px] font-extrabold text-slate-700 dark:text-slate-200">
                          {t("modRecEmptyTitle")}
                        </p>
                        <p className="mx-auto mt-1.5 max-w-md text-[12px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                          {t("modRecEmptyDesc")}
                        </p>
                        <Button
                          type="button"
                          onClick={() => setRecordDialog({ record: null })}
                          className="mt-4 h-10 gap-2 rounded-xl px-5 text-[12.5px] font-bold text-white shadow-lg transition hover:brightness-110 active:scale-95"
                          style={{ backgroundImage: grad(c1, c2) }}
                        >
                          <CatIcon name="plus" className="h-4 w-4" />
                          {t("modRecEmptyCta")}
                        </Button>
                      </td>
                    </tr>
                  ) : (
                    <tr>
                      <td colSpan={data.cols.length + (source === "mine" ? 1 : 0)} className="px-4 py-10 text-center">
                        <span className="mx-auto grid h-11 w-11 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5">
                          <CatIcon name="search" className="h-5 w-5" />
                        </span>
                        <p className="mt-2 text-[12.5px] font-bold text-slate-400 dark:text-slate-500">
                          {t("modNoResults")}
                        </p>
                      </td>
                    </tr>
                  )
                ) : (
                  pageRows.map((row, idx) => {
                    const st = data.statuses.find((s) => s.key === row.statusKey);
                    return (
                      <tr
                        key={row.id}
                        className={cn(
                          "border-t border-slate-100 transition-colors dark:border-white/[0.06]",
                          idx % 2 === 1 && "bg-slate-50/50 dark:bg-white/[0.02]",
                          "hover:bg-brand-50/50 dark:hover:bg-brand-500/[0.06]"
                        )}
                      >
                        {row.values.map((value, ci) => {
                          const col = data.cols[ci];
                          const isStatus = col.kind === "status";
                          return (
                            <td
                              key={col.key}
                              className={cn(
                                "whitespace-nowrap px-3.5 py-2.5 text-[12px] font-semibold text-slate-700 dark:text-slate-200",
                                (col.kind === "num" || col.kind === "money") && "text-end tabular-nums",
                                col.kind === "id" && "font-mono text-[11px] text-slate-500 dark:text-slate-400",
                                col.kind === "date" && "tabular-nums text-slate-500 dark:text-slate-400"
                              )}
                            >
                              {isStatus && st ? (
                                <span
                                  className={cn(
                                    "inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2 py-0.5 text-[10.5px] font-extrabold",
                                    TONE_STYLE[st.tone]
                                  )}
                                >
                                  <span className={cn("h-1.5 w-1.5 rounded-full", TONE_DOT[st.tone])} aria-hidden="true" />
                                  {statusLabel(st.key, data.statuses, lang)}
                                </span>
                              ) : (
                                value
                              )}
                            </td>
                          );
                        })}
                        {/* ROUND 36 — print action on EVERY row (demo + mine):
                            invoices, lab results, patient cards… print as
                            formal documents; edit/delete stay mine-only. */}
                        <td className="whitespace-nowrap px-2.5 py-2">
                          <div className="flex items-center justify-end gap-1">
                            <button
                              type="button"
                              aria-label={t("printAria")}
                              title={t("printAria")}
                              onClick={() => buildPrintDoc(row)}
                              className="grid h-7 w-7 place-items-center rounded-lg text-slate-400 transition hover:bg-brand-500/10 hover:text-brand-600 active:scale-90 dark:text-slate-500 dark:hover:text-brand-300"
                            >
                              <CatIcon name="printer" className="h-3.5 w-3.5" />
                            </button>
                            {source === "mine" ? (
                              <>
                                <button
                                  type="button"
                                  aria-label={t("modRecEditAria")}
                                  title={t("modRecEditAria")}
                                  onClick={() => setRecordDialog({ record: row })}
                                  className="grid h-7 w-7 place-items-center rounded-lg text-slate-400 transition hover:bg-amber-500/10 hover:text-amber-600 active:scale-90 dark:text-slate-500 dark:hover:text-amber-400"
                                >
                                  <CatIcon name="pencil" className="h-3.5 w-3.5" />
                                </button>
                                <button
                                  type="button"
                                  aria-label={t("modRecDeleteAria")}
                                  title={t("modRecDeleteAria")}
                                  onClick={() => setPendingDelete(row)}
                                  className="grid h-7 w-7 place-items-center rounded-lg text-slate-400 transition hover:bg-rose-500/10 hover:text-rose-600 active:scale-90 dark:text-slate-500 dark:hover:text-rose-400"
                                >
                                  <CatIcon name="trash-2" className="h-3.5 w-3.5" />
                                </button>
                              </>
                            ) : null}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* round 35 — MOBILE-FIRST record cards: phones get stacked
            label:value cards instead of the wide table (no clipped columns,
            every field fully readable, actions reachable with the thumb) */}
        {pageRows.length > 0 ? (
          <div className="space-y-2.5 md:hidden">
            {pageRows.map((row, idx) => {
              const st = data.statuses.find((s) => s.key === row.statusKey);
              const primary = row.values[0] ?? "—";
              return (
                <article
                  key={row.id}
                  className={cn(
                    "rounded-2xl border p-3.5",
                    idx % 2 === 1
                      ? "border-slate-200/80 bg-slate-50/60 dark:border-white/[0.07] dark:bg-white/[0.02]"
                      : "border-slate-200/80 bg-white/70 dark:border-white/[0.07] dark:bg-white/[0.03]"
                  )}
                >
                  <div className="flex items-start justify-between gap-2.5">
                    <p className="min-w-0 flex-1 truncate font-display text-[13.5px] font-extrabold text-slate-800 dark:text-slate-100">
                      {primary}
                    </p>
                    {st ? (
                      <span
                        className={cn(
                          "inline-flex shrink-0 items-center gap-1.5 rounded-full px-2 py-0.5 text-[10.5px] font-extrabold",
                          TONE_STYLE[st.tone]
                        )}
                      >
                        <span className={cn("h-1.5 w-1.5 rounded-full", TONE_DOT[st.tone])} aria-hidden="true" />
                        {statusLabel(st.key, data.statuses, lang)}
                      </span>
                    ) : null}
                  </div>
                  {row.values.length > 1 ? (
                    <dl className="mt-2.5 space-y-1.5 border-t border-dashed border-slate-200/80 pt-2.5 dark:border-white/10">
                      {row.values.slice(1).map((value, ci) => {
                        const col = data.cols[ci + 1];
                        if (!col) return null;
                        const isStatus = col.kind === "status";
                        return (
                          <div key={col.key} className="flex items-start justify-between gap-3">
                            <dt className="shrink-0 max-w-[45%] truncate text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                              {lang === "ar" ? col.ar : col.en}
                            </dt>
                            <dd
                              dir={col.kind === "num" || col.kind === "money" || col.kind === "date" || col.kind === "id" ? "ltr" : undefined}
                              className={cn(
                                "min-w-0 flex-1 text-end text-[11.5px] font-semibold text-slate-700 dark:text-slate-200",
                                (col.kind === "num" || col.kind === "money") && "tabular-nums",
                                col.kind === "id" && "font-mono text-[10.5px] text-slate-500 dark:text-slate-400",
                                col.kind === "date" && "tabular-nums text-slate-500 dark:text-slate-400"
                              )}
                            >
                              {isStatus && st ? statusLabel(st.key, data.statuses, lang) : value}
                            </dd>
                          </div>
                        );
                      })}
                    </dl>
                  ) : null}
                  {/* ROUND 36 — mobile actions: print for every row (demo +
                      mine); edit/delete stay mine-only. */}
                  <div className="mt-2.5 flex items-center justify-end gap-1.5 border-t border-dashed border-slate-200/80 pt-2.5 dark:border-white/10">
                    <button
                      type="button"
                      aria-label={t("printAria")}
                      title={t("printAria")}
                      onClick={() => buildPrintDoc(row)}
                      className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 text-slate-500 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:text-slate-400 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
                    >
                      <CatIcon name="printer" className="h-4 w-4" />
                    </button>
                    {source === "mine" ? (
                      <>
                        <button
                          type="button"
                          aria-label={t("modRecEditAria")}
                          title={t("modRecEditAria")}
                          onClick={() => setRecordDialog({ record: row })}
                          className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 text-slate-500 transition hover:border-amber-300 hover:text-amber-600 active:scale-95 dark:border-white/10 dark:text-slate-400"
                        >
                          <CatIcon name="pencil" className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          aria-label={t("modRecDeleteAria")}
                          title={t("modRecDeleteAria")}
                          onClick={() => setPendingDelete(row)}
                          className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 text-slate-500 transition hover:border-rose-300 hover:text-rose-600 active:scale-95 dark:border-white/10 dark:text-slate-400"
                        >
                          <CatIcon name="trash-2" className="h-4 w-4" />
                        </button>
                      </>
                    ) : null}
                  </div>
                </article>
              );
            })}
          </div>
        ) : null}

        {/* pagination */}
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
          <p className="text-[11px] font-semibold text-slate-400 dark:text-slate-500">
            {t("modPageOf", { page: fmtNum(safePage + 1, lang), total: fmtNum(pages, lang) })}
            <span className="mx-1.5 text-slate-300 dark:text-slate-600">·</span>
            {t("modRowsUnit")}: <span dir="ltr" className="tabular-nums font-bold">{filtered.length}</span>
          </p>
          <div className="flex items-center gap-1.5">
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={safePage === 0}
              onClick={() => setPage(safePage - 1)}
              className="h-8 rounded-lg px-3 text-[11.5px] font-bold"
              aria-label={t("modPrevPage")}
            >
              <CatIcon name="chevron-down" className="h-3.5 w-3.5 rtl:rotate-90 ltr:rotate-90" />
              {t("modPrevPage")}
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={safePage >= pages - 1}
              onClick={() => setPage(safePage + 1)}
              className="h-8 rounded-lg px-3 text-[11.5px] font-bold"
              aria-label={t("modNextPage")}
            >
              {t("modNextPage")}
              <CatIcon name="chevron-down" className="h-3.5 w-3.5 rtl:-rotate-90 ltr:-rotate-90" />
            </Button>
          </div>
        </div>
      </DashCard>

      {/* ---------------- analytics row ---------------- */}
      <div className="grid gap-4 lg:grid-cols-3">
        <DashCard title={t("modWeeklyTitle")} icon="chart-column">
          <div dir="ltr" className="flex h-32 items-end justify-between gap-1.5 px-1" role="img" aria-label={t("modWeeklyTitle")}>
            {data.series.map((v, i) => (
              <div key={i} className="group/bar flex h-full flex-1 flex-col justify-end">
                <span className="mb-1 hidden text-center text-[11px] font-bold tabular-nums text-slate-400 group-hover/bar:block dark:text-slate-500">
                  {v}
                </span>
                <span
                  className="w-full rounded-t-md transition-all duration-300 group-hover/bar:opacity-80"
                  style={{
                    height: `${Math.max(8, (v / maxValue) * 100)}%`,
                    backgroundImage: grad(c1, c2),
                    opacity: 0.85,
                  }}
                  aria-hidden="true"
                />
              </div>
            ))}
          </div>
          <p className="mt-3 text-center text-[11px] font-bold text-slate-400 dark:text-slate-500">
            {t("modWeeklySum")}: <span dir="ltr" className="tabular-nums">{fmtNum(seriesSum, lang)}</span>
          </p>
        </DashCard>

        <DashCard title={t("modDistTitle")} icon="chart-pie">
          <ul className="space-y-3">
            {data.statusDist.map((d) => {
              const st = data.statuses.find((s) => s.key === d.key);
              if (!st) return null;
              const pct = Math.round((d.count / data.rows.length) * 100);
              return (
                <li key={d.key}>
                  <div className="mb-1 flex items-center justify-between text-[12px] font-bold">
                    <span className="flex items-center gap-2 text-slate-600 dark:text-slate-300">
                      <span className={cn("h-2.5 w-2.5 rounded-full", TONE_DOT[st.tone])} aria-hidden="true" />
                      {statusLabel(st.key, data.statuses, lang)}
                    </span>
                    <span dir="ltr" className="tabular-nums text-slate-400 dark:text-slate-500">
                      {fmtNum(d.count, lang)} · {pct}%
                    </span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-white/10">
                    <div
                      className={cn("h-full rounded-full transition-all duration-700", TONE_DOT[st.tone])}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </li>
              );
            })}
          </ul>
        </DashCard>

        <DashCard title={t("modFactsTitle")} icon="info">
          <ul className="space-y-2.5">
            {[
              { icon: "database", label: t("modKpiTotal"), value: fmtNum(data.kpis.total, lang) },
              { icon: "calendar-check", label: t("modKpiMonthly"), value: fmtNum(data.kpis.monthly, lang) },
              ...(hasMoney
                ? [
                    {
                      icon: "wallet",
                      label: t("modKpiValue"),
                      value: `${fmtNum(Math.round(data.kpis.value), lang)} ${data.currency}`,
                    },
                  ]
                : []),
              { icon: "activity", label: t("modWeeklySum"), value: fmtNum(seriesSum, lang) },
              { icon: "building", label: t("modFactsOrg"), value: instance.org.name },
              { icon: "boxes", label: t("modFactsSystem"), value: systemName },
            ].map((fact, i) => (
              <li
                key={i}
                className="flex items-center gap-3 rounded-xl border border-slate-200/70 p-2.5 dark:border-white/[0.07]"
              >
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-slate-100 text-slate-500 dark:bg-white/5 dark:text-slate-400">
                  <CatIcon name={fact.icon} className="h-3.5 w-3.5" />
                </span>
                <span className="min-w-0 flex-1 truncate text-[11px] font-bold text-slate-500 dark:text-slate-400">
                  {fact.label}
                </span>
                <span className="max-w-[45%] truncate text-[12px] font-extrabold text-slate-800 dark:text-slate-100">
                  {fact.value}
                </span>
              </li>
            ))}
          </ul>
          {source === "demo" ? (
            <p className="mt-3 rounded-xl bg-amber-500/10 p-2.5 text-[10.5px] font-bold leading-relaxed text-amber-700 dark:text-amber-300">
              <CatIcon name="flask" className="me-1 inline h-3 w-3" />
              {t("modDemoNote")}
            </p>
          ) : (
            <p className="mt-3 rounded-xl bg-emerald-500/10 p-2.5 text-[10.5px] font-bold leading-relaxed text-emerald-700 dark:text-emerald-300">
              <CatIcon name="database" className="me-1 inline h-3 w-3" />
              {t("modRecRealNote")}
            </p>
          )}
        </DashCard>
      </div>

      {/* ---------------- round 30 — add/edit record dialog ---------------- */}
      {recordDialog ? (
        <RecordDialog
          key={recordDialog.record?.id ?? "new"}
          record={recordDialog.record}
          suggestedCode={suggestedCode}
          cols={data?.cols ?? []}
          statuses={data?.statuses ?? []}
          moduleName={moduleName}
          currency={data?.currency ?? instance.org.currency}
          c1={c1}
          c2={c2}
          saving={saveRecord.isPending}
          onSave={(payload) => saveRecord.mutate(payload)}
          onClose={() => setRecordDialog(null)}
          instanceId={instance.id}
          productExtras={activeModuleId === storeProductModuleId(instance.modules)}
        />
      ) : null}

      {/* ---------------- ROUND 36 — professional record print ---------------- */}
      <RecordPrintDialog
        doc={printDoc}
        instance={instance}
        logoUrl={logoUrl}
        signatureUrl={siteQuery.data?.content.signatureUrl ?? ""}
        stampUrl={siteQuery.data?.content.stampUrl ?? ""}
        signatureScale={siteQuery.data?.content.signatureScale ?? 1}
        stampScale={siteQuery.data?.content.stampScale ?? 1}
        open={printDoc !== null}
        onOpenChange={(o) => !o && setPrintDoc(null)}
      />

      {/* ---------------- round 30 — delete record confirm ---------------- */}
      <AlertDialog open={pendingDelete !== null} onOpenChange={(o) => !o && setPendingDelete(null)}>
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-linear-to-br from-rose-500 to-rose-600 text-white shadow-lg shadow-rose-500/25"
                aria-hidden="true"
              >
                <CatIcon name="trash-2" className="h-[15px] w-[15px]" />
              </span>
              {t("modRecDeleteTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("modRecDeleteMsg", { name: moduleName })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          {pendingDelete ? (
            <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50/60 p-3 dark:border-white/15 dark:bg-white/[0.03]">
              <div className="flex flex-wrap items-center gap-2">
                <span
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white"
                  style={{ backgroundImage: grad(c1, c2) }}
                  aria-hidden="true"
                >
                  <CatIcon name="database" className="h-4 w-4" />
                </span>
                {pendingDelete.values
                  .filter(Boolean)
                  .slice(0, 3)
                  .map((v, i) => (
                    <span
                      key={i}
                      dir="auto"
                      className="max-w-48 truncate rounded-full bg-slate-100 px-2.5 py-1 text-[11px] font-bold text-slate-600 dark:bg-white/10 dark:text-slate-300"
                    >
                      {v.length > 28 ? `${v.slice(0, 28)}…` : v}
                    </span>
                  ))}
              </div>
            </div>
          ) : null}
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={removeRecord.isPending}>
              {t("modRecCancelBtn")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => pendingDelete && removeRecord.mutate(pendingDelete.id)}
              disabled={removeRecord.isPending}
              className="h-10 rounded-xl bg-rose-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60"
            >
              {removeRecord.isPending ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : null}
              {t("modRecDeleteBtn")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default ModuleWorkspace;

/* ------------------------------------------------------------------ */
/* round 30 — add/edit one REAL record (dynamic form from the preset). */
/* The parent keys this component by record id, so every mount starts */
/* from a fresh form state (no sync effects).                          */
/* ------------------------------------------------------------------ */

/* ROUND 141 — the record draft carries the PRODUCT EXTRAS when the module
 * is the store's catalog source: the media gallery (cover + extras) + the
 * variant rows, both read from the record's DTO on edit. */
type RecordDraft = {
  id: string;
  values: string[];
  statusKey: string;
  gallery?: string[];
  videos?: string[];
  variants?: ProductVariantDTO[];
  /* ROUND 141 (㉕ payment management) — the structured payment ledger. */
  payments?: PaymentEntry[];
};

function RecordDialog({
  record,
  suggestedCode,
  cols,
  statuses,
  moduleName,
  currency,
  c1,
  c2,
  saving,
  onSave,
  onClose,
  instanceId,
  productExtras = false,
}: {
  record: RecordDraft | null;
  /** ROUND 68 — auto-generated id-column value for NEW records (7-digit
   *  capacity; null when the module has no id column). Still editable. */
  suggestedCode: string | null;
  cols: ColDef[];
  statuses: StatusDef[];
  moduleName: string;
  currency: string;
  c1: string;
  c2: string;
  saving: boolean;
  onSave: (payload: {
    recordId: string | null;
    values: string[];
    statusKey: string;
    /** ROUND 141 (㉕) — the structured payment ledger. */
    payments: PaymentEntry[];
    /** ROUND 141 (product extras) — the gallery (undefined = don't touch
     *  media) + the variant rows (undefined = keep). */
    gallery?: string[];
    variants?: { id?: string; name: string; price?: number; stock?: number; sku?: string }[];
  }) => void;
  onClose: () => void;
  /** ROUND 141 — the workspace id (the photo uploads ride /store/media). */
  instanceId: string;
  /** ROUND 141 — the catalog module: the media picker + the variants
   *  builder mount only there (the business-suite dialog is the primary
   *  surface; this generic path is the retired-module fallback). */
  productExtras?: boolean;
}) {
  const { lang, t } = useT();
  const idColIndex = cols.findIndex((c) => c.kind === "id");
  const [values, setValues] = useState<string[]>(() =>
    cols.map((_c, i) =>
      record?.values[i] ?? (i === idColIndex && !record && suggestedCode ? suggestedCode : "")
    )
  );
  const [statusKey, setStatusKey] = useState(record?.statusKey ?? "");
  /* ROUND 141 (㉕ payment management) — the structured ledger state; the
   * primary label also lands in the legacy method cell (compat law). */
  const [payments, setPayments] = useState<PaymentEntry[]>(record?.payments ?? []);
  /* ROUND 141 (product extras) — the media picker + the variants builder
   * values (edit prefills from the row's gallery/variants). */
  const [mediaValue, setMediaValue] = useState<ProductMediaPickerValue>(() => ({
    enabled: (record?.gallery?.length ?? 0) > 0,
    items: (record?.gallery ?? []).map((ref) => ({ ref, pending: false })),
  }));
  const [variantsValue, setVariantsValue] = useState<VariantsBuilderValue>(() => ({
    enabled: (record?.variants?.length ?? 0) > 0,
    rows: variantRowsFromDTO(record?.variants ?? []),
  }));
  const [mediaUploading, setMediaUploading] = useState(false);
  const statusIndex = cols.findIndex((c) => c.kind === "status");
  const methodIndex = cols.findIndex((c) => c.key === "method");
  /* the record's grand total (minor): the LAST money column of the preset
   * (POS values[7] grand total, purchases total …) — null when none. */
  const totalMinor = useMemo(() => {
    const moneyIndexes = cols.map((c, i) => ({ kind: c.kind, i })).filter((c) => c.kind === "money");
    if (moneyIndexes.length === 0) return null;
    const lastMoney = moneyIndexes[moneyIndexes.length - 1].i;
    const raw = Number(String(values[lastMoney] ?? "").replace(/[^\d.-]/g, ""));
    return Number.isFinite(raw) && raw > 0 ? Math.round(raw * 100) : null;
  }, [cols, values]);
  const canSave = values.some((v) => v.trim() !== "");

  const setValue = (i: number, v: string) => setValues((prev) => prev.map((p, pi) => (pi === i ? v : p)));

  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!canSave) return;
    /* ROUND 141 (product extras) — the variants validate FIRST (duplicate
     * names / bad numbers block the save with the precise toast). */
    let variantsWire: { id?: string; name: string; price?: number; stock?: number; sku?: string }[] | undefined;
    if (productExtras && variantsValue.enabled) {
      const wire = variantRowsToWire(variantsValue.rows);
      if (wire.error) {
        toast.error(wire.error);
        return;
      }
      variantsWire = wire.variants;
    }
    /* ROUND 141 (product extras) — the pending photos upload through
     * /store/media; kept managed refs pass through untouched. */
    let galleryWire: string[] | undefined;
    if (productExtras && mediaValue.enabled) {
      setMediaUploading(true);
      try {
        const refs: string[] = [];
        for (const item of mediaValue.items) {
          if (item.pending) {
            const { url } = await uploadStoreImage(instanceId, item.ref);
            refs.push(url);
          } else {
            refs.push(item.ref);
          }
        }
        galleryWire = refs;
      } catch (err) {
        toast.error(err instanceof Error ? err.message : t("errorText"));
        setMediaUploading(false);
        return;
      }
      setMediaUploading(false);
    }
    /* the primary payment label rides the legacy method CELL (analytics +
       detail + print keep their contract) while the structured ledger rides
       paymentsJson. */
    const primaryLabel = paymentsPrimaryLabel(payments);
    onSave({
      recordId: record?.id ?? null,
      values: values.map((v, i) =>
        i === statusIndex ? statusKey : i === methodIndex && primaryLabel ? primaryLabel : v
      ),
      statusKey,
      payments,
      ...(galleryWire !== undefined ? { gallery: galleryWire } : {}),
      ...(variantsWire !== undefined ? { variants: variantsWire } : {}),
    });
  };

  return (
    <Dialog open={true} onOpenChange={(o) => !o && onClose()}>
      <DialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="max-h-[85vh] max-w-lg overflow-y-auto rounded-3xl nice-scroll">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
            <span
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg"
              style={{ backgroundImage: grad(c1, c2), boxShadow: `0 10px 24px -10px ${hexAlpha(c1, 0.9)}` }}
              aria-hidden="true"
            >
              <CatIcon name={record ? "pencil" : "plus"} className="h-4 w-4" />
            </span>
            {record ? t("modRecEditTitle") : t("modRecAddTitle")}
          </DialogTitle>
          <DialogDescription className="text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
            {record
              ? t("modRecEditDesc", { name: moduleName })
              : t("modRecAddDesc", { name: moduleName })}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={submit} className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2">
            {cols.map((col, i) => {
              if (col.kind === "status") {
                if (statuses.length === 0) return null;
                return (
                  <div key={col.key} className="space-y-1.5 sm:col-span-2">
                    <label
                      htmlFor="rec-status"
                      className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
                    >
                      <CatIcon name="badge-check" className="h-3 w-3 text-slate-400" aria-hidden="true" />
                      {lang === "ar" ? col.ar : col.en}
                    </label>
                    <Select
                      value={statusKey === "" ? "__none__" : statusKey}
                      onValueChange={(v) => setStatusKey(v === "__none__" ? "" : v)}
                    >
                      <SelectTrigger id="rec-status" className="h-10 rounded-xl text-[12.5px] font-semibold">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="__none__">
                          <span className="flex items-center gap-2 text-slate-400">
                            <span className="h-2 w-2 rounded-full bg-slate-300 dark:bg-slate-600" aria-hidden="true" />
                            {t("modRecStatusNone")}
                          </span>
                        </SelectItem>
                        {statuses.map((s) => (
                          <SelectItem key={s.key} value={s.key}>
                            <span className="flex items-center gap-2">
                              <span className={cn("h-2 w-2 rounded-full", TONE_DOT[s.tone])} aria-hidden="true" />
                              {lang === "ar" ? s.ar : s.en}
                            </span>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                );
              }
              const numeric = col.kind === "num" || col.kind === "money";
              const isIdCol = col.kind === "id";
              const isDateCol = col.kind === "date";
              return (
                <div key={col.key} className="space-y-1.5">
                  <label
                    htmlFor={`rec-${col.key}`}
                    className="flex flex-wrap items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
                  >
                    {lang === "ar" ? col.ar : col.en}
                    {col.kind === "money" ? (
                      <span
                        dir="ltr"
                        className="rounded-full bg-slate-100 px-1.5 py-px text-[11px] font-bold text-slate-500 dark:bg-white/10 dark:text-slate-400"
                      >
                        {currency}
                      </span>
                    ) : null}
                    {/* ROUND 68 — auto-generated 7-digit code chip on new records */}
                    {isIdCol && !record && suggestedCode ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-brand-500/10 px-1.5 py-px text-[10px] font-extrabold text-brand-600 dark:bg-brand-500/15 dark:text-brand-300">
                        <span className="h-1 w-1 animate-pulse rounded-full bg-brand-500" aria-hidden="true" />
                        {t("recCodeAutoChip")}
                      </span>
                    ) : null}
                  </label>
                  {/* date columns ride the shared premium date field (R163):
                      brand calendar tile at the field's far right in Arabic,
                      native picker, clear-X + Arabic long-form hint built in. */}
                  {isDateCol ? (
                    <PremiumDateInput
                      id={`rec-${col.key}`}
                      value={values[i] ?? ""}
                      onChange={(e) => setValue(i, e.target.value)}
                    />
                  ) : (
                    <Input
                      id={`rec-${col.key}`}
                      type={numeric ? "number" : "text"}
                      step={col.kind === "money" ? "0.01" : col.kind === "num" ? "1" : undefined}
                      min={numeric ? 0 : undefined}
                      value={values[i] ?? ""}
                      onChange={(e) => setValue(i, e.target.value)}
                      dir={numeric || isIdCol ? "ltr" : undefined}
                      placeholder={numeric ? "0" : ""}
                      className={cn(
                        "h-10 rounded-xl text-[12.5px] font-semibold",
                        isIdCol && "font-mono text-start",
                        numeric && "text-end"
                      )}
                    />
                  )}
                  {isIdCol && !record && suggestedCode ? (
                    <p className="flex items-center gap-1 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                      <CatIcon name="sparkles" className="h-3 w-3 shrink-0" />
                      {t("recCodeHint")}
                    </p>
                  ) : null}
                </div>
              );
            })}
          </div>

          {/* ROUND 141 (product extras) — the media picker + the variants
              builder ride the CATALOG module's form (the retired-module
              fallback path; the business-suite dialog is the primary surface). */}
          {productExtras ? (
            <>
              <ProductMediaPickerSection value={mediaValue} onChange={setMediaValue} c1={c1} c2={c2} />
              <VariantsBuilderSection
                value={variantsValue}
                onChange={setVariantsValue}
                currency={currency}
                c1={c1}
                c2={c2}
              />
            </>
          ) : null}

          {/* ROUND 141 (㉕) — PAYMENT MANAGEMENT: the premium 7-method
              section (cash · card · bank · ewallet · mixed · partial ·
              payable) riding every record dialog — sales, POS, and the
              purchases (the SUPPLIER side) alike. */}
          <PaymentManagerSection
            value={payments}
            onChange={setPayments}
            totalMinor={totalMinor}
            currency={currency}
            c1={c1}
            c2={c2}
          />

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={saving}
              className="h-10 rounded-xl border-slate-200 bg-white px-5 text-[12.5px] font-bold text-slate-700 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200"
            >
              {t("modRecCancelBtn")}
            </Button>
            <Button
              type="submit"
              disabled={!canSave || saving || mediaUploading}
              className="h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:opacity-60"
              style={{ backgroundImage: grad(c1, c2) }}
            >
              {saving || mediaUploading ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="check" className="h-4 w-4" />
              )}
              {saving || mediaUploading ? t("bizSaving") : t("modRecSaveBtn")}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
