"use client";

/**
 * Ashrilogic — ROUND 156 premium record print page (rebuilt from scratch).
 *
 * The owner's directive:
 *   «في جميع الأنظمة مازال عند الطباعة يظهر صفحة سيئة جداً قم بحذفه
 *    كاملاً وإعادة تطويره بطريقة احترافية وPremium»
 *
 * The previous R36/R67/R148 treatment layered print rules on top of a
 * table-based letterhead that overflowed on long values («متداخلة
 * النصوص»). This file rebuilds the surface from scratch as a clean,
 * minimalist A4 document:
 *
 *   • a single gradient bar at the top (the only background paint);
 *   • a bilingual letterhead — logo + org name + module label + the
 *     issue-date stamp;
 *   • a headline section with the document title + a prominent status
 *     badge;
 *   • a 2-column CSS-GRID field layout (NOT a table, NOT flex) with
 *     proper gap, overflow-wrap:anywhere, min-width:0 — long values
 *     wrap inside their cell, never overflow into the neighbour column;
 *   • an optional receipt-image block (the expenses module's uploaded
 *     receipt photo) when the doc carries imageUrl;
 *   • the structured 7-method payment strip (when payments exist);
 *   • the signature/stamp area (ONLY when the workspace uploaded them);
 *   • a clean footer with the print timestamp + the platform URL + the
 *     page indicator;
 *   • explicit dir={docRef} on the print root so RTL/LTR stays correct.
 *
 * The on-screen preview mirrors the printed paper exactly: a white A4
 * sheet centered on a neutral gray backdrop, with the print + close
 * actions below. Works for EVERY module type — fields render dynamically
 * from the PrintDoc interface.
 *
 * CSS lives in src/app/globals.css (.print-doc / .print-card /
 * .print-field-cell / .print-only-pagefoot). The @page rule declares
 * A4 portrait with a 1.5cm margin.
 */
import { useMemo } from "react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CatIcon } from "@/components/icon";
import { useT } from "@/lib/i18n";
import {
  PAYMENT_METHOD_META,
  summarizePayments,
  type PaymentEntry,
} from "@/lib/payment-methods";
import { fullDate } from "@/components/dashboard/dash-shared";
import { intlLocale } from "@/lib/locales";
import type { InstanceDTO, Lang } from "@/lib/types";

export interface PrintField {
  label: string;
  value: string;
  kind: "text" | "num" | "money" | "date" | "id" | "status";
}

export interface PrintDoc {
  /** document headline — usually the first column (invoice no, patient name…) */
  title: string;
  moduleName: string;
  fields: PrintField[];
  statusLabel: string | null;
  /** ROUND 141 (㉕) — the structured 7-method payment ledger (absent/empty
   *  = the document prints exactly as it always did). */
  payments?: PaymentEntry[];
  /** the record's grand total in MINOR units (null/absent = unknown — the
   *  paid/remaining ladder degrades gracefully). */
  totalMinor?: number | null;
  /** ROUND 156 — the optional receipt image URL (managed /api/images
   *  ref). When present the doc renders a bordered preview block under
   *  the field grid. */
  imageUrl?: string | null;
  /** ROUND 164 — the POS customer stamps (record meta). Consumed by the
   *  thermal-receipt print preview; the A4 document ignores them. */
  customerName?: string | null;
  customerPhone?: string | null;
}

/** ROUND 141 — derive the record's grand total (minor units) from its money
 * columns: the LAST money column is the grand total (POS grand total,
 * purchase total …). Shared by the three print-doc builders. */
export function moneyColumnsTotalMinor(cols: { kind: string }[], values: string[]): number | null {
  let last = -1;
  for (let i = 0; i < cols.length; i++) if (cols[i].kind === "money") last = i;
  if (last < 0) return null;
  const raw = Number(String(values[last] ?? "").replace(/[^\d.-]/g, ""));
  return Number.isFinite(raw) && raw > 0 ? Math.round(raw * 100) : null;
}

function fmtMoney(raw: string, currency: string, lang: Lang): string {
  const n = Number(String(raw).replace(/[^\d.-]/g, ""));
  if (!Number.isFinite(n)) return raw;
  try {
    return new Intl.NumberFormat(intlLocale(lang), {
      style: "currency",
      currency,
      maximumFractionDigits: 2,
    }).format(n);
  } catch {
    return `${raw} ${currency}`;
  }
}

/** minor units → display number (the display-boundary conversion only) */
const toMajor = (minor: number) => Math.round(minor) / 100;

/* ------------------------------------------------------------------ */
/* the payment settlement strip (re-styled, premium)                   */
/* ------------------------------------------------------------------ */

function PaymentStrip({
  entries,
  totalMinor,
  currency,
  lang,
  t,
}: {
  entries: PaymentEntry[];
  totalMinor: number | null;
  currency: string;
  lang: Lang;
  t: ReturnType<typeof useT>["t"];
}) {
  const summary = summarizePayments(entries, totalMinor ?? 0);
  const fmt = (minor: number) => {
    try {
      return new Intl.NumberFormat(intlLocale(lang), {
        minimumFractionDigits: 0,
        maximumFractionDigits: 2,
      }).format(toMajor(minor));
    } catch {
      return String(toMajor(minor));
    }
  };
  return (
    <section className="print-card mt-5 rounded-lg border border-slate-200 bg-slate-50/60 p-3.5">
      <p className="flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-wider text-slate-500">
        <CatIcon name="wallet" className="h-3 w-3" aria-hidden="true" />
        {t("payMgrTitle")}
      </p>

      {/* the per-entry chips (method + the settled amount when present) */}
      <div className="mt-2 flex flex-wrap items-center gap-1.5">
        {entries.map((entry, i) => {
          const meta = PAYMENT_METHOD_META[entry.method];
          return (
            <span
              key={`${entry.method}-${i}`}
              className="inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-extrabold"
              style={{
                borderColor: `${meta.c1}55`,
                color: meta.c2,
                backgroundColor: `${meta.c1}0d`,
              }}
            >
              <CatIcon name={meta.icon} className="h-2.5 w-2.5" aria-hidden="true" />
              {lang === "ar" ? meta.ar : meta.en}
              {entry.amountMinor !== undefined ? (
                <span dir="ltr" className="tabular-nums opacity-80">
                  {fmt(entry.amountMinor)}
                </span>
              ) : null}
            </span>
          );
        })}
      </div>

      {/* the paid/remaining ladder + the due date */}
      {totalMinor !== null ? (
        <div className="mt-2.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[10.5px] font-bold">
          <span className="text-emerald-700">
            {t("payMgrPaid", { amount: fmt(summary.paidMinor), currency })}
          </span>
          {!summary.fullyPaid ? (
            <span className="text-amber-700">
              {t("payMgrRemaining", { amount: fmt(summary.remainingMinor) })}
            </span>
          ) : null}
          {summary.dueAt ? (
            <span className={summary.overdue ? "text-rose-700" : "text-slate-500"}>
              <CatIcon name="calendar-clock" className="me-1 inline h-2.5 w-2.5" aria-hidden="true" />
              {t("payMgrDueLabel", { date: summary.dueAt })}
              {summary.overdue ? ` · ${t("payMgrOverdue")}` : ""}
            </span>
          ) : null}
        </div>
      ) : null}
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* the optional receipt image block (the expenses module)              */
/* ------------------------------------------------------------------ */

function ReceiptImageBlock({ url, label }: { url: string; label: string }) {
  return (
    <section className="print-card mt-5">
      <p className="flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-wider text-slate-500">
        <CatIcon name="image" className="h-3 w-3" aria-hidden="true" />
        {label}
      </p>
      <div className="mt-2 overflow-hidden rounded-lg border border-slate-200 bg-white p-2.5">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={url}
          alt={label}
          className="mx-auto max-h-56 w-auto rounded-md object-contain"
        />
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* the premium print dialog                                            */
/* ------------------------------------------------------------------ */

export function RecordPrintDialog({
  doc,
  instance,
  logoUrl,
  signatureUrl = "",
  stampUrl = "",
  signatureScale = 1,
  stampScale = 1,
  open,
  onOpenChange,
}: {
  doc: PrintDoc | null;
  instance: InstanceDTO;
  logoUrl: string;
  /** ROUND 67 — uploaded official signature (managed ref; "" = none) */
  signatureUrl?: string;
  /** ROUND 67 — uploaded official stamp/seal (managed ref; "" = none) */
  stampUrl?: string;
  /** ROUND 67 — owner-adjusted render scales (settings sliders) */
  signatureScale?: number;
  stampScale?: number;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { t, lang } = useT();

  const issued = useMemo(() => new Date().toISOString(), []);
  const docRef = lang === "ar" ? "rtl" : "ltr";
  const hasContact = Boolean(instance.org.address || instance.org.phone);
  const hasReceiptImage = Boolean(doc?.imageUrl);
  const hasPayments = Boolean(doc?.payments && doc.payments.length > 0);
  const hasSignatureRow = Boolean(signatureUrl || stampUrl);

  const print = () => {
    /* small delay so the dialog finishes laying out before the print dialog */
    window.setTimeout(() => window.print(), 60);
  };

  if (!doc) return null;

  /* the field grid is split into 2 columns of paired (label, value) cells;
   * the LAST cell on a row with an odd count spans both columns so the
   * grid never leaves a hole. min-width:0 + overflow-wrap:anywhere keeps
   * long values inside their cell — the «متداخلة النصوص» fix. */
  const fieldCells = doc.fields;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        dir={docRef}
        className="print-doc-host flex max-h-[92vh] flex-col gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-4xl print:max-h-none print:overflow-visible print:rounded-none print:border-0 print:bg-transparent print:p-0 print:shadow-none print:static print:translate-x-0 print:translate-y-0"
      >
        {/* the on-screen header (hidden when printing) */}
        <div className="print:hidden flex shrink-0 items-center gap-3 border-b border-slate-200/70 px-5 py-3.5 dark:border-white/10">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-linear-to-br from-brand-500 to-fuchsia-500 text-white shadow-lg shadow-brand-500/25">
            <CatIcon name="printer" className="h-4 w-4" />
          </span>
          <div className="min-w-0 flex-1">
            <DialogTitle className="truncate font-display text-[15px] font-extrabold leading-tight text-slate-900 dark:text-white">
              {t("printDialogTitle")}
            </DialogTitle>
            <DialogDescription className="mt-0.5 truncate text-[11.5px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("printDialogDesc", { name: doc.moduleName })}
            </DialogDescription>
          </div>
          <button
            type="button"
            onClick={print}
            aria-label={t("printBtn")}
            className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-linear-to-l from-brand-600 to-brand-500 px-3.5 text-[11.5px] font-extrabold text-white shadow-md transition hover:brightness-110 active:scale-95"
          >
            <CatIcon name="printer" className="h-3.5 w-3.5" />
            {t("printBtn")}
          </button>
        </div>

        {/* ------------------------- the paper ------------------------- */}
        {/* the gray backdrop scroller — centers the white A4 sheet on screen.
            In print, .print-doc lifts to position:fixed and paints the whole page. */}
        <div className="print-doc-scroller nice-scroll min-h-0 flex-1 overflow-auto bg-slate-100 p-4 dark:bg-[#0b1220] sm:p-8 print:static print:block print:max-h-none print:overflow-visible print:bg-transparent print:p-0">
          <div
            className="print-doc relative mx-auto w-full max-w-[820px] bg-white text-slate-900 shadow-xl"
            dir={docRef}
          >
            {/* the only background paint — a single brand gradient bar */}
            <div
              className="h-2 w-full"
              style={{ background: "linear-gradient(to left, #6d5dfb, #d946ef, #22d3ee)" }}
              aria-hidden="true"
            />

            {/* the document body — 1.5cm of inner padding (mirrors @page) */}
            <div className="px-[1.5cm] py-[1.2cm]">
              {/* ------------------------ letterhead ------------------------ */}
              <div className="print-card print-header flex items-start justify-between gap-4">
                <div className="flex min-w-0 items-center gap-3.5">
                  {/* circular logo badge */}
                  {logoUrl ? (
                    <span
                      className="grid h-14 w-14 shrink-0 place-items-center rounded-full p-[3px] shadow-sm"
                      style={{ background: "linear-gradient(135deg,#6d5dfb,#d946ef,#22d3ee)" }}
                    >
                      <span className="grid h-full w-full place-items-center overflow-hidden rounded-full bg-white">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img src={logoUrl} alt={instance.org.name} className="h-11 w-11 rounded-full object-cover" />
                      </span>
                    </span>
                  ) : (
                    <span
                      className="grid h-14 w-14 shrink-0 place-items-center rounded-full font-display text-[20px] font-extrabold text-white shadow-md"
                      style={{ background: "linear-gradient(135deg, #6d5dfb, #d946ef)" }}
                    >
                      {(instance.org.name || "A").trim().charAt(0).toUpperCase()}
                    </span>
                  )}
                  <div className="min-w-0">
                    <p className="truncate font-display text-[16px] font-extrabold leading-tight text-slate-900">
                      {instance.org.name || "—"}
                    </p>
                    <p className="mt-0.5 text-[11px] font-bold text-slate-500">
                      {doc.moduleName}
                    </p>
                    {hasContact ? (
                      <p className="mt-0.5 truncate text-[9.5px] font-medium text-slate-400">
                        {instance.org.phone ? `${instance.org.phone}` : ""}
                        {instance.org.phone && instance.org.address ? " · " : ""}
                        {instance.org.address || ""}
                      </p>
                    ) : null}
                  </div>
                </div>
                <div className="shrink-0 text-end">
                  <span
                    className="inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[9.5px] font-extrabold uppercase tracking-wider"
                    style={{ borderColor: "#ddd6fe", color: "#6d28d9", backgroundColor: "#f5f3ff" }}
                  >
                    <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: "#8b5cf6" }} aria-hidden="true" />
                    {t("printIssued")}
                  </span>
                  <p className="mt-1.5 text-[11px] font-bold tabular-nums text-slate-700">{fullDate(issued, lang)}</p>
                </div>
              </div>

              {/* gradient hairline under the letterhead */}
              <div
                className="mt-4 h-px w-full"
                style={{ background: "linear-gradient(to left, transparent, #c7d2fe 18%, #c7d2fe 82%, transparent)" }}
                aria-hidden="true"
              />

              {/* ------------------------ headline ------------------------- */}
              <div className="print-card mt-5 flex items-start justify-between gap-4">
                <div className="min-w-0">
                  <h2 className="font-display text-[20px] font-extrabold leading-tight tracking-tight text-slate-900">
                    {doc.title}
                  </h2>
                  <p className="mt-1 text-[10.5px] font-semibold text-slate-400">
                    {doc.moduleName} — {instance.org.name}
                  </p>
                </div>
                {doc.statusLabel ? (
                  <span
                    className="inline-flex shrink-0 items-center gap-2 rounded-full border-2 px-4 py-1.5 text-[11.5px] font-extrabold"
                    style={{ borderColor: "#10b981", color: "#047857", backgroundColor: "#ecfdf5" }}
                  >
                    <span className="h-2 w-2 rounded-full" style={{ backgroundColor: "#10b981" }} aria-hidden="true" />
                    {doc.statusLabel}
                  </span>
                ) : null}
              </div>

              {/* ------------------------ the field grid ----------------------
                  CSS Grid (NOT a table, NOT flex): 2 columns with a proper
                  gap. Each cell is a (label, value) pair. min-width:0 +
                  overflow-wrap:anywhere keeps long values inside their cell
                  — the «متداخلة النصوص» root-cause fix. */}
              <div className="print-card mt-5">
                <div
                  className="grid grid-cols-2 gap-x-5 gap-y-3"
                  style={{ direction: docRef }}
                >
                  {fieldCells.map((field, i) => {
                    const isLastOdd = i === fieldCells.length - 1 && (i + 1) % 2 === 1;
                    const isNumeric = field.kind === "money" || field.kind === "num";
                    return (
                      <div
                        key={i}
                        className={`print-field-cell min-w-0 rounded-lg border border-slate-200 bg-slate-50/50 px-3 py-2 ${isLastOdd ? "col-span-2" : ""}`}
                      >
                        <p className="text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400">
                          {field.label}
                        </p>
                        <p
                          dir={field.kind === "text" || field.kind === "status" ? "auto" : "ltr"}
                          className={`mt-1 min-w-0 text-[11px] font-bold leading-relaxed text-slate-800 ${
                            isNumeric ? "tabular-nums" : ""
                          } ${field.kind === "id" ? "font-mono text-[10.5px]" : ""}`}
                          style={{ overflowWrap: "anywhere", wordBreak: "break-word" }}
                        >
                          {field.kind === "money"
                            ? fmtMoney(field.value, instance.org.currency || "SAR", lang)
                            : field.value || "—"}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* ------------------------ the receipt image (optional) -------- */}
              {hasReceiptImage && doc.imageUrl ? (
                <ReceiptImageBlock url={doc.imageUrl} label={t("bizReceiptImageTitle")} />
              ) : null}

              {/* ------------------------ the payment strip (optional) ------- */}
              {hasPayments && doc.payments ? (
                <PaymentStrip
                  entries={doc.payments}
                  totalMinor={doc.totalMinor ?? null}
                  currency={instance.org.currency || "SAR"}
                  lang={lang}
                  t={t}
                />
              ) : null}

              {/* ------------------------ signature & stamp (optional) ------- */}
              {hasSignatureRow ? (
                <div className="print-card mt-8">
                  <div
                    className="flex items-end justify-between gap-6"
                    style={signatureUrl && stampUrl ? undefined : { justifyContent: "center" }}
                  >
                    {/* signature zone — ONLY when the official signature exists */}
                    {signatureUrl ? (
                      <div className="min-w-0 flex-1 text-center">
                        <div className="grid h-[78px] place-items-center">
                          {/* eslint-disable-next-line @next/next/no-img-element */}
                          <img
                            src={signatureUrl}
                            alt={t("printSignatureLabel")}
                            className="max-h-full max-w-[180px] object-contain"
                            style={{ transform: `scale(${signatureScale})` }}
                          />
                        </div>
                        <p className="mt-1.5 text-[9px] font-extrabold uppercase tracking-wider text-slate-500">
                          {t("printSignatureLabel")}
                        </p>
                        <div className="mx-auto mt-1.5 w-36 border-t" style={{ borderColor: "#94a3b8" }} aria-hidden="true" />
                      </div>
                    ) : null}

                    {/* stamp zone — ONLY when the official stamp exists */}
                    {stampUrl ? (
                      <div className="min-w-0 flex-1 text-center">
                        <div className="grid h-[78px] place-items-center">
                          {/* eslint-disable-next-line @next/next/no-img-element */}
                          <img
                            src={stampUrl}
                            alt={t("printStampLabel")}
                            className="max-h-full max-w-[180px] object-contain"
                            style={{ transform: `scale(${stampScale})` }}
                          />
                        </div>
                        <p className="mt-1.5 text-[9px] font-extrabold uppercase tracking-wider text-slate-500">
                          {t("printStampLabel")}
                        </p>
                        <div className="mx-auto mt-1.5 w-36 border-t" style={{ borderColor: "#94a3b8" }} aria-hidden="true" />
                      </div>
                    ) : null}
                  </div>
                </div>
              ) : null}

              {/* ------------------------ footer --------------------------- */}
              <div className="print-card mt-8 border-t border-dashed pt-4" style={{ borderColor: "#cbd5e1" }}>
                <p className="text-[10px] font-semibold leading-relaxed text-slate-400">
                  {t("printFooterNote")}
                </p>
                <div
                  className="mt-3 flex items-center justify-between rounded-lg px-3 py-2"
                  style={{ backgroundColor: "#f8fafc" }}
                >
                  <p className="text-[9px] font-bold tracking-wide text-slate-400">
                    {t("printPoweredBy")}
                  </p>
                  <p className="text-[9px] font-bold tabular-nums text-slate-400">{fullDate(issued, lang)}</p>
                </div>
              </div>

              {/* the ink-only footer (display:none on screen, visible on paper) */}
              <p className="print-only-pagefoot mt-3 text-[9px] font-semibold leading-relaxed">
                {t("printPageFootStamp", { date: fullDate(issued, lang) })}
                <span className="mx-1.5 opacity-50" aria-hidden="true">·</span>
                {t("printPageFootBrand")}
                <span className="mx-1.5 opacity-50" aria-hidden="true">·</span>
                <span dir="ltr" className="tabular-nums">ashrilogic.com</span>
              </p>
            </div>
          </div>

          {/* the on-screen actions (centered under the sheet, hidden in print) */}
          <div className="print:hidden mt-5 flex items-center justify-center gap-2.5">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="h-10 rounded-xl px-5 text-[12.5px] font-bold"
            >
              {t("dlgCancel")}
            </Button>
            <Button
              type="button"
              onClick={print}
              className="h-10 gap-2 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-6 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
            >
              <CatIcon name="printer" className="h-4 w-4" />
              {t("printBtn")}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
