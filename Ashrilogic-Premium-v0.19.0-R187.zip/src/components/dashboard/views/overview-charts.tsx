"use client";

/**
 * Overview-view chart subtree — split from overview-view.tsx so the recharts
 * runtime streams in as its own lazy chunk instead of shipping with the
 * dashboard's first paint (the same lazy-chunk pattern every non-default
 * dashboard view already uses). KPI text and cards stay eager in the view;
 * only the SVG chart machinery lives here. Container heights are reserved by
 * the eager wrappers, so the loading placeholders never shift layout.
 */
import {
  Area,
  AreaChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { useT } from "@/lib/i18n";
import { fmtNum } from "@/lib/utils";
import { CHART_TOOLTIP_STYLE } from "@/components/dashboard/dash-shared";

/** KPI card sparkline — rendered inside the eager h-9 wrapper. */
export function KpiSpark({
  data,
  color,
  gradientId,
}: {
  data: { label: string; value: number }[];
  color: string;
  gradientId: string;
}) {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart data={data} margin={{ top: 2, bottom: 2, left: 0, right: 0 }}>
        <defs>
          <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity={0.3} />
            <stop offset="100%" stopColor={color} stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <Area
          type="monotone"
          dataKey="value"
          stroke={color}
          strokeWidth={2}
          fill={`url(#${gradientId})`}
          dot={false}
          isAnimationActive={false}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}

/** Monthly revenue area chart (lg:col-span-2 DashCard body). */
export function RevenueChart({
  data,
  color,
  gradientId,
}: {
  data: { label: string; value: number }[];
  color: string;
  gradientId: string;
}) {
  const { t, lang } = useT();
  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
        <defs>
          <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity={0.35} />
            <stop offset="100%" stopColor={color} stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 6" stroke="rgba(148,163,184,0.25)" vertical={false} />
        <XAxis
          dataKey="label"
          tickLine={false}
          axisLine={false}
          tick={{ fontSize: 10, fill: "currentColor" }}
          className="text-slate-400"
          interval="preserveStartEnd"
        />
        <YAxis
          tickLine={false}
          axisLine={false}
          tick={{ fontSize: 10, fill: "currentColor" }}
          className="text-slate-400"
          tickFormatter={(v: number) => `${Math.round(v / 1000)}k`}
          width={34}
        />
        <Tooltip
          contentStyle={CHART_TOOLTIP_STYLE}
          formatter={(value) => [`$${fmtNum(Number(value), lang)}`, t("dashKpiRevenue")]}
        />
        <Area
          type="monotone"
          dataKey="value"
          stroke={color}
          strokeWidth={2.5}
          fill={`url(#${gradientId})`}
          activeDot={{ r: 4, fill: color }}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}

/** Tasks breakdown donut — the center total overlay stays eager in the view. */
export function TasksDonut({
  data,
}: {
  data: { label: string; value: number; color: string }[];
}) {
  const { lang } = useT();
  return (
    <ResponsiveContainer width="100%" height="100%">
      <PieChart>
        <Pie
          data={data}
          dataKey="value"
          nameKey="label"
          innerRadius={48}
          outerRadius={64}
          paddingAngle={3}
          strokeWidth={0}
        >
          {data.map((e) => (
            <Cell key={e.label} fill={e.color} />
          ))}
        </Pie>
        <Tooltip contentStyle={CHART_TOOLTIP_STYLE} formatter={(v) => [fmtNum(Number(v), lang), ""]} />
      </PieChart>
    </ResponsiveContainer>
  );
}
