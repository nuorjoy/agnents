"use client";

/**
 * Dashboard — the PUBLIC WEBSITE view (round 24): create, customize and
 * LAUNCH the website linked to this system.
 *
 * Layout: content editor (identity / about / services / contact) beside a
 * status rail (publish state, live launch button, visit counter, public
 * URL, accent theme picker) and a real live preview — the actual /sites/[id]
 * page rendered inside a browser-chrome iframe (draft sites render their
 * owner-preview banner server-side, so the iframe is always truthful).
 *
 * Saving PUTs the whole content (+ theme); publishing is a separate,
 * celebratory action that stamps launchedAt and records the launch in the
 * workspace activity trail + platform audit log.
 */
import { Fragment, useMemo, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { motion } from "framer-motion";
import {
  DndContext,
  DragOverlay,
  KeyboardSensor,
  PointerSensor,
  closestCenter,
  useSensor,
  useSensors,
} from "@dnd-kit/core";
import type { Announcements, DragEndEvent, DragStartEvent } from "@dnd-kit/core";
import { SortableContext, arrayMove, sortableKeyboardCoordinates, useSortable, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import {
  DEFAULT_SITE_BLOCKS,
  type InstanceDTO,
  type SiteBlockKey,
  type SiteBlockLayout,
  type SiteContent,
  type SiteContentEn,
  type SiteService,
  type SiteSocialLink,
  type Lang,
} from "@/lib/types";
import { useT, type I18nKey } from "@/lib/i18n";
import { intlLocale } from "@/lib/locales";
import { nf } from "@/lib/format";
import { defaultPrivacyPolicy, defaultTermsOfUse } from "@/lib/legal-defaults";
import {
  fetchSite,
  updateSite,
  translateSiteContent,
} from "@/lib/api-client";
import { SOCIAL_LINKS } from "@/lib/social";
import { CatIcon } from "@/components/icon";
import { cn, grad, hexAlpha } from "@/lib/utils";
import { SITE_SERVICE_ICONS, siteTheme } from "@/lib/site-themes";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { DashCard, ViewHeading, fullDate, IconTile } from "@/components/dashboard/dash-shared";
import { LegalText } from "@/components/site/legal-page-view";

/* max services enforced by the API schema */
const MAX_SERVICES = 6;

/* max social links enforced by the API schema (round 29) */
const MAX_SOCIAL = 8;

const EMPTY_SERVICE: SiteService = { icon: "sparkles", title: "", desc: "", titleEn: "", descEn: "" };

/* round 32 — neutral EN block used when the site has no translations yet */
const EMPTY_EN: SiteContentEn = {
  tagline: "",
  heroTitle: "",
  heroDesc: "",
  aboutTitle: "",
  about: "",
  contactAddress: "",
  workingHours: "",
};

/* nf moved to lib/format (shared across surfaces) */

/* ------------------------------------------------ service row ---------- */

function ServiceRow({
  index,
  service,
  onChange,
  onRemove,
  onMove,
  canMove,
  total,
}: {
  index: number;
  service: SiteService;
  onChange: (next: SiteService) => void;
  onRemove: () => void;
  onMove: (dir: -1 | 1) => void;
  canMove: (dir: -1 | 1) => boolean;
  total: number;
}) {
  const { t, lang } = useT();
  const theme = siteTheme("aurora");
  /* round 32 — the English sub-form collapses by default */
  const [enOpen, setEnOpen] = useState(false);
  const translated = !!(service.titleEn ?? "").trim() || !!(service.descEn ?? "").trim();
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
      <div className="flex items-center gap-2">
        <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white" style={{ backgroundImage: grad(theme.c1, theme.c2) }}>
          <CatIcon name={service.icon} className="h-3.5 w-3.5" />
        </span>
        <p className="text-[11px] font-extrabold text-slate-400 dark:text-slate-500">
          {t("siteServiceLabel", { index: nf(lang, index + 1), total: nf(lang, total) })}
        </p>
        <button
          type="button"
          onClick={() => setEnOpen((v) => !v)}
          aria-expanded={enOpen}
          title={translated ? t("siteServiceEnDone") : t("siteServiceEnPending")}
          className={cn(
            "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-black transition",
            translated
              ? "border-emerald-300/70 bg-emerald-500/10 text-emerald-600 hover:bg-emerald-500/20 dark:border-emerald-500/40 dark:text-emerald-300"
              : "border-slate-200 bg-slate-50 text-slate-400 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-500 dark:hover:text-brand-300"
          )}
        >
          EN
          <CatIcon name={translated ? "badge-check" : "languages"} className="h-3 w-3" />
        </button>
        <div className="ms-auto flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onMove(-1)}
            disabled={!canMove(-1)}
            aria-label={t("siteServiceUp")}
            className="h-7 w-7 rounded-lg text-slate-400 disabled:opacity-30 dark:text-slate-500"
          >
            <CatIcon name="chevron-up" className="h-3.5 w-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onMove(1)}
            disabled={!canMove(1)}
            aria-label={t("siteServiceDown")}
            className="h-7 w-7 rounded-lg text-slate-400 disabled:opacity-30 dark:text-slate-500"
          >
            <CatIcon name="chevron-down" className="h-3.5 w-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={onRemove}
            aria-label={t("siteServiceRemove")}
            className="h-7 w-7 rounded-lg text-slate-400 transition hover:bg-rose-50 hover:text-rose-500 dark:text-slate-500 dark:hover:bg-rose-500/10"
          >
            <CatIcon name="trash" className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>

      <div className="mt-3 grid gap-2.5 sm:grid-cols-[150px_1fr]">
        <div className="space-y-1">
          <Label className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
            {t("siteServiceIcon")}
          </Label>
          <Select
            value={service.icon}
            onValueChange={(icon) => onChange({ ...service, icon })}
          >
            <SelectTrigger className="h-9 rounded-xl text-[12px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="max-h-64">
              {SITE_SERVICE_ICONS.map((icon) => (
                <SelectItem key={icon} value={icon} className="text-[12px]">
                  <span className="inline-flex items-center gap-2">
                    <CatIcon name={icon} className="h-3.5 w-3.5 text-slate-500" />
                    {icon}
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1">
          <Label className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
            {t("siteServiceTitle")}
          </Label>
          <Input
            value={service.title}
            onChange={(e) => onChange({ ...service, title: e.target.value })}
            placeholder={t("siteServiceTitlePh")}
            maxLength={80}
            className="h-9 rounded-xl text-[12.5px]"
          />
        </div>
      </div>

      <div className="mt-2.5 space-y-1">
        <Label className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
          {t("siteServiceDesc")}
        </Label>
        <Input
          value={service.desc}
          onChange={(e) => onChange({ ...service, desc: e.target.value })}
          placeholder={t("siteServiceDescPh")}
          maxLength={200}
          className="h-9 rounded-xl text-[12.5px]"
        />
      </div>

      {/* round 32 — English translation sub-form (collapsible) */}
      {enOpen ? (
        <div className="mt-3 space-y-2.5 rounded-xl border border-dashed border-brand-300/60 bg-brand-500/[0.04] p-3 dark:border-brand-500/30 dark:bg-brand-500/[0.06]">
          <p className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-wide text-brand-600 dark:text-brand-300">
            <CatIcon name="languages" className="h-3 w-3" />
            {t("siteServiceEnToggle")}
            {service.title.trim() ? (
              <span className="ms-auto truncate font-mono text-[11px] font-bold normal-case tracking-normal text-slate-400 dark:text-slate-500" dir="auto">
                {service.title}
              </span>
            ) : null}
          </p>
          <div className="space-y-1">
            <Label className="text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
              {t("siteServiceEnTitle")}
            </Label>
            <Input
              dir="ltr"
              value={service.titleEn ?? ""}
              onChange={(e) => onChange({ ...service, titleEn: e.target.value })}
              placeholder={service.title || "Specialist consultations"}
              maxLength={80}
              className="h-8.5 rounded-xl text-[12px] text-start"
            />
          </div>
          <div className="space-y-1">
            <Label className="text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
              {t("siteServiceEnDesc")}
            </Label>
            <Input
              dir="ltr"
              value={service.descEn ?? ""}
              onChange={(e) => onChange({ ...service, descEn: e.target.value })}
              placeholder={service.desc || "Top consultants across every specialty"}
              maxLength={200}
              className="h-8.5 rounded-xl text-[12px] text-start"
            />
          </div>
        </div>
      ) : null}
    </div>
  );
}

/* ------------------------------------------------ social links ------- */

/** One editable social row: network select + destination URL + remove. */
function SocialRow({
  index,
  link,
  taken,
  onChange,
  onRemove,
}: {
  index: number;
  link: SiteSocialLink;
  taken: Set<string>;
  onChange: (next: SiteSocialLink) => void;
  onRemove: () => void;
}) {
  const { t, lang } = useT();
  const meta = SOCIAL_LINKS.find((s) => s.icon === link.icon);
  return (
    <div className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-white p-2.5 dark:border-white/10 dark:bg-white/[0.03]">
      <Select value={link.icon} onValueChange={(icon) => onChange({ ...link, icon })}>
        <SelectTrigger className="h-9 w-[132px] shrink-0 rounded-xl text-[12px]" aria-label={t("siteSocialNetwork")}>
          <SelectValue />
        </SelectTrigger>
        <SelectContent className="max-h-64">
          {SOCIAL_LINKS.map((s) => (
            <SelectItem key={s.icon} value={s.icon} disabled={taken.has(s.icon) && s.icon !== link.icon} className="text-[12px]">
              <span className="inline-flex items-center gap-2">
                <CatIcon name={s.icon} className="h-3.5 w-3.5" style={{ color: s.color }} />
                {lang === "ar" ? s.labelAr : s.labelEn}
              </span>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      <Input
        dir="ltr"
        value={link.href}
        onChange={(e) => onChange({ ...link, href: e.target.value })}
        placeholder="https://…"
        maxLength={300}
        className="h-9 flex-1 rounded-xl text-[12.5px] text-start"
        aria-label={t("siteSocialUrl")}
      />
      <span className="hidden items-center gap-1 text-[10px] font-extrabold text-slate-300 dark:text-slate-600 sm:flex">
        #{nf(lang, index + 1)}
      </span>
      <Button
        variant="ghost"
        size="icon"
        onClick={onRemove}
        aria-label={t("siteSocialRemove")}
        className="h-8 w-8 shrink-0 rounded-lg text-slate-400 transition hover:bg-rose-50 hover:text-rose-500 dark:text-slate-500 dark:hover:bg-rose-500/10"
      >
        <CatIcon name="trash" className="h-3.5 w-3.5" />
      </Button>
      {meta ? (
        <span className="sr-only">{lang === "ar" ? meta.labelAr : meta.labelEn}</span>
      ) : null}
    </div>
  );
}

/* ------------------------------------------- legal pages (ROUND 84) --- */

/** char ceiling shared by the editor, the write schema and the counter. */
const LEGAL_MAX_CHARS = 20_000;

/**
 * ROUND 84 (84-LEGAL) — the «الصفحات القانونية» editor: the site's custom
 * PRIVACY-POLICY and TERMS-OF-USE texts, edited with precision.
 *
 *  - a segmented tab picks the page (privacy | terms);
 *  - "" (empty) means "render the professional DEFAULT Arabic copy"
 *    (src/lib/legal-defaults.ts) — stated explicitly, never a blank page;
 *  - «استعادة النص الافتراضي» fills the field from the SAME default
 *    module the public page renders (single source of legal truth);
 *  - «معاينة» renders the EXACT public-page renderer (LegalText) so the
 *    owner previews byte-identical output;
 *  - every keystroke rides the view's normal edit→draft→save flow (PUT
 *    /api/instances/[id]/site persists the two new content fields).
 */
function LegalPagesEditor({
  content,
  orgName,
  instanceId,
  edit,
}: {
  content: SiteContent;
  orgName: string;
  instanceId: string;
  edit: (patch: Partial<SiteContent>) => void;
}) {
  const { t, lang } = useT();
  const [page, setPage] = useState<"privacy" | "terms">("privacy");
  const [previewOn, setPreviewOn] = useState(false);

  const isPrivacy = page === "privacy";
  const value = isPrivacy ? content.privacyPolicy : content.termsOfUse;
  const defaultText = isPrivacy ? defaultPrivacyPolicy(orgName) : defaultTermsOfUse(orgName);
  /* the effective document: custom text when present, the professional
   * default otherwise — exactly what the public page serves. */
  const effective = value.trim().length > 0 ? value : defaultText;
  const customized = value.trim().length > 0;
  const count = value.length;
  const nearLimit = count > LEGAL_MAX_CHARS * 0.9;

  const field = isPrivacy ? "privacyPolicy" : "termsOfUse";
  const publicHref = `/sites/${instanceId}${isPrivacy ? "/privacy" : "/terms"}`;
  const textareaId = `site-legal-${page}`;

  return (
    <div className="space-y-4">
      <p className="text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
        {t("legalEditorDesc")}
      </p>

      {/* segmented page picker (privacy | terms) */}
      <div
        role="tablist"
        aria-label={t("legalEditorSegAria")}
        className="grid grid-cols-2 gap-1 rounded-2xl border border-slate-200 bg-slate-50/70 p-1 dark:border-white/10 dark:bg-white/[0.03]"
      >
        {(["privacy", "terms"] as const).map((key) => {
          const active = page === key;
          return (
            <button
              key={key}
              type="button"
              role="tab"
              aria-selected={active}
              onClick={() => {
                setPage(key);
                setPreviewOn(false);
              }}
              className={cn(
                "flex min-h-11 items-center justify-center gap-2 rounded-xl px-3 py-2.5 text-[12.5px] font-extrabold transition",
                active
                  ? "bg-white text-slate-900 shadow-soft dark:bg-white/[0.09] dark:text-white"
                  : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white"
              )}
            >
              <CatIcon
                name={key === "privacy" ? "shield-check" : "scale"}
                className={cn("h-4 w-4", active && "text-brand-500")}
              />
              {key === "privacy" ? t("legalEditorPrivacyTab") : t("legalEditorTermsTab")}
            </button>
          );
        })}
      </div>

      {/* status chip + live char counter */}
      <div className="flex flex-wrap items-center justify-between gap-2.5">
        <span
          className={cn(
            "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11px] font-extrabold",
            customized
              ? "border-emerald-300/70 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
              : "border-slate-200 bg-white text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400"
          )}
        >
          <CatIcon name={customized ? "file-check" : "book-open"} className="h-3 w-3" />
          {customized ? t("legalEditorStatusCustom") : t("legalEditorStatusDefault")}
        </span>
        <span
          className={cn(
            "font-mono text-[11px] font-extrabold tabular-nums",
            nearLimit
              ? "text-amber-600 dark:text-amber-400"
              : "text-slate-400 dark:text-slate-500"
          )}
          aria-live="polite"
        >
          {t("legalEditorCounter", {
            count: nf(lang, count),
            max: nf(lang, LEGAL_MAX_CHARS),
          })}
        </span>
      </div>

      {/* the editor / the live preview (the public page's own renderer) */}
      {previewOn ? (
        <div className="space-y-2">
          <div className="max-h-[420px] overflow-y-auto rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-white/10 dark:bg-white/[0.035] sm:p-6">
            <LegalText text={effective} />
          </div>
          <p className="flex items-start gap-1.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            <CatIcon name="info" className="mt-px h-3 w-3 shrink-0" />
            {t("legalEditorPreviewHint")}
          </p>
        </div>
      ) : (
        <div className="space-y-1.5">
          <Label htmlFor={textareaId} className="text-[12px] font-bold">
            {t("legalEditorFieldLabel")}
          </Label>
          <textarea
            id={textareaId}
            dir="auto"
            value={value}
            onChange={(e) => edit({ [field]: e.target.value } as Partial<SiteContent>)}
            placeholder={defaultText.split("\n")[0]?.slice(0, 120)}
            maxLength={LEGAL_MAX_CHARS}
            rows={10}
            spellCheck={false}
            className="w-full resize-y rounded-xl border border-slate-200 bg-white px-3.5 py-3 text-[13px] leading-relaxed shadow-sm outline-none transition placeholder:text-slate-400 focus:border-brand-400 focus:ring-2 focus:ring-brand-400/20 dark:border-white/10 dark:bg-white/[0.04] dark:text-white dark:placeholder:text-slate-500"
          />
          <p className="flex items-start gap-1.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            <CatIcon name={customized ? "pencil" : "sparkles"} className="mt-px h-3 w-3 shrink-0" />
            {t("legalEditorEmptyNote")}
          </p>
        </div>
      )}

      {/* actions: preview toggle · restore default · clear · open public page */}
      <div className="flex flex-wrap items-center gap-2">
        <Button
          type="button"
          variant={previewOn ? "default" : "outline"}
          size="sm"
          onClick={() => setPreviewOn((v) => !v)}
          aria-pressed={previewOn}
          className="h-9 gap-1.5 rounded-xl px-4 text-[12px] font-bold"
        >
          <CatIcon name={previewOn ? "pencil" : "eye"} className="h-3.5 w-3.5" />
          {previewOn ? t("legalEditorPreviewOff") : t("legalEditorPreviewOn")}
        </Button>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => {
            edit({ [field]: defaultText } as Partial<SiteContent>);
            setPreviewOn(true);
            toast.success(t("legalEditorRestoreToast"));
          }}
          className="h-9 gap-1.5 rounded-xl px-4 text-[12px] font-bold"
        >
          <CatIcon name="rotate-ccw" className="h-3.5 w-3.5" />
          {t("legalEditorRestore")}
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={() => edit({ [field]: "" } as Partial<SiteContent>)}
          disabled={!customized}
          title={t("legalEditorEmptyNote")}
          className="h-9 gap-1.5 rounded-xl px-4 text-[12px] font-bold text-slate-500 dark:text-slate-400"
        >
          <CatIcon name="x" className="h-3.5 w-3.5" />
          {t("legalEditorClear")}
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          asChild
          aria-label={t("legalEditorViewPage")}
          className="ms-auto h-9 gap-1.5 rounded-xl px-4 text-[12px] font-bold text-brand-600 dark:text-brand-300"
        >
          <a href={publicHref} target="_blank" rel="noopener noreferrer">
            <CatIcon name="external-link" className="h-3.5 w-3.5" />
            {t("legalEditorViewPage")}
          </a>
        </Button>
      </div>
    </div>
  );
}

/* ------------------------------------------------ canvas (round 35) --- */

/** Per-block visual identity on the canvas (icon tile + gradient). */
const BLOCK_STYLE: Record<SiteBlockKey, { icon: string; c1: string; c2: string }> = {
  hero: { icon: "rocket", c1: "#6d5dfb", c2: "#a855f7" },
  services: { icon: "sparkles", c1: "#f59e0b", c2: "#d97706" },
  about: { icon: "house", c1: "#10b981", c2: "#059669" },
  cta: { icon: "send", c1: "#ec4899", c2: "#d946ef" },
  contact: { icon: "message-circle", c1: "#06b6d4", c2: "#0891b2" },
  hours: { icon: "clock", c1: "#f97316", c2: "#ea580c" },
  social: { icon: "share", c1: "#d946ef", c2: "#c026d3" },
};

const BLOCK_NAME_KEY: Record<SiteBlockKey, I18nKey> = {
  hero: "siteBlockHero",
  services: "siteBlockServices",
  about: "siteBlockAbout",
  cta: "siteBlockCta",
  contact: "siteBlockContact",
  hours: "siteBlockHours",
  social: "siteBlockSocial",
};

const BLOCK_DESC_KEY: Record<SiteBlockKey, I18nKey> = {
  hero: "siteBlockHeroDesc",
  services: "siteBlockServicesDesc",
  about: "siteBlockAboutDesc",
  cta: "siteBlockCtaDesc",
  contact: "siteBlockContactDesc",
  hours: "siteBlockHoursDesc",
  social: "siteBlockSocialDesc",
};

/** contact-inner cards — hinted on the canvas rows and nested in the preview */
const NESTED_BLOCKS: readonly SiteBlockKey[] = ["hours", "social"];

/** grid-paper backdrop for the live miniature (subtle, works in both themes) */
const GRID_PAPER: React.CSSProperties = {
  backgroundColor: "rgba(148,163,184,0.07)",
  backgroundImage:
    "linear-gradient(rgba(148,163,184,0.16) 1px, transparent 1px), linear-gradient(90deg, rgba(148,163,184,0.16) 1px, transparent 1px)",
  backgroundSize: "14px 14px",
};

/** One draggable canvas row: grip handle · icon tile · name/desc · visibility. */
function SortableBlockRow({
  block,
  onToggle,
}: {
  block: SiteBlockLayout;
  onToggle: () => void;
}) {
  const { t } = useT();
  const style = BLOCK_STYLE[block.key];
  const { attributes, listeners, setNodeRef, setActivatorNodeRef, transform, transition, isDragging, isOver } =
    useSortable({ id: block.key });
  const nested = NESTED_BLOCKS.includes(block.key);
  const name = t(BLOCK_NAME_KEY[block.key]);

  return (
    <div
      ref={setNodeRef}
      style={{ transform: CSS.Translate.toString(transform), transition }}
      className={cn("touch-none select-none", isDragging && "z-10 opacity-40")}
    >
      {/* animated drop indicator at the hovered row's start edge */}
      {isOver ? (
        <div
          className="mb-1.5 h-1.5 rounded-full bg-linear-to-r from-brand-400 to-fuchsia-400 animate-pulse"
          aria-hidden="true"
        />
      ) : null}
      <div
        className={cn(
          "group flex items-center gap-2.5 rounded-2xl border p-3 shadow-sm transition-all duration-300",
          nested && "ms-4 border-s-2 border-s-dashed",
          block.visible
            ? "border-slate-200 bg-white hover:border-brand-300 hover:shadow-lift dark:border-white/10 dark:bg-white/[0.04] dark:hover:border-brand-500/40"
            : "border-dashed border-slate-300 bg-slate-50/70 dark:border-white/15 dark:bg-white/[0.02]"
        )}
      >
        {/* drag handle (grip) — the ONLY drag activator, so the switch stays clickable */}
        <button
          ref={setActivatorNodeRef}
          type="button"
          {...attributes}
          {...listeners}
          aria-label={t("siteCanvasDragHandle", { name })}
          title={t("siteCanvasDragHandle", { name })}
          className="grid h-8 w-6 shrink-0 cursor-grab place-items-center rounded-lg text-slate-300 transition hover:bg-slate-100 hover:text-slate-500 focus-visible:outline-2 focus-visible:outline-brand-500 active:cursor-grabbing dark:text-slate-600 dark:hover:bg-white/[0.06] dark:hover:text-slate-400"
        >
          <CatIcon name="grip-vertical" className="h-4 w-4" />
        </button>

        {/* icon tile with the block's own gradient */}
        <span
          className={cn(
            "grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md transition duration-300",
            !block.visible && "opacity-40 saturate-50"
          )}
          style={{ backgroundImage: grad(style.c1, style.c2) }}
          aria-hidden="true"
        >
          <CatIcon name={style.icon} className="h-4 w-4" />
        </span>

        {/* name + mini description */}
        <div className="min-w-0 flex-1">
          <p className="flex flex-wrap items-center gap-1.5">
            <span
              className={cn(
                "text-[12.5px] font-extrabold leading-none",
                block.visible ? "text-slate-800 dark:text-slate-200" : "text-slate-400 dark:text-slate-500"
              )}
            >
              {name}
            </span>
            {nested ? (
              <span className="inline-flex items-center gap-1 rounded-full border border-slate-200 bg-slate-50 px-1.5 py-px text-[11px] font-black text-slate-400 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-500">
                <CatIcon name="corner-down-left" className="h-2.5 w-2.5" />
                {t("siteCanvasNested")}
              </span>
            ) : null}
          </p>
          <p className="mt-1 truncate text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t(BLOCK_DESC_KEY[block.key])}
          </p>
        </div>

        {/* shown/hidden: eye ⇄ eye-off transition + compact switch */}
        <div className="flex shrink-0 items-center gap-2">
          <span
            className={cn(
              "relative grid h-7 w-7 place-items-center rounded-lg transition-colors duration-300",
              block.visible
                ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                : "bg-slate-200/80 text-slate-400 dark:bg-white/[0.06] dark:text-slate-500"
            )}
            aria-hidden="true"
          >
            <CatIcon
              name="eye"
              className={cn(
                "absolute h-3.5 w-3.5 transition-all duration-300",
                block.visible ? "rotate-0 scale-100 opacity-100" : "rotate-90 scale-50 opacity-0"
              )}
            />
            <CatIcon
              name="eye-off"
              className={cn(
                "absolute h-3.5 w-3.5 transition-all duration-300",
                block.visible ? "-rotate-90 scale-50 opacity-0" : "rotate-0 scale-100 opacity-100"
              )}
            />
          </span>
          <Switch
            checked={block.visible}
            onCheckedChange={onToggle}
            aria-label={`${name} — ${block.visible ? t("siteCanvasVisible") : t("siteCanvasHidden")}`}
          />
        </div>
      </div>
    </div>
  );
}

/** A skeleton bar atom for the miniature strips. */
function MiniBar({ className }: { className?: string }) {
  return <span className={cn("block rounded-full bg-slate-200 dark:bg-white/15", className)} aria-hidden="true" />;
}

/** One schematic strip of the live miniature (labels + skeleton content). */
function PreviewStrip({ block }: { block: SiteBlockLayout }) {
  const { t } = useT();
  const style = BLOCK_STYLE[block.key];
  const nested = NESTED_BLOCKS.includes(block.key);
  const name = t(BLOCK_NAME_KEY[block.key]);

  const label = (
    <span className="flex items-center gap-1.5">
      <span
        className={cn("grid h-3.5 w-3.5 shrink-0 place-items-center rounded-md text-white", !block.visible && "opacity-60")}
        style={{ backgroundImage: grad(style.c1, style.c2) }}
        aria-hidden="true"
      >
        <CatIcon name={style.icon} className="h-2 w-2" />
      </span>
      <span className="truncate text-[11px] font-black uppercase tracking-wide text-slate-500 dark:text-slate-400">
        {name}
      </span>
      {!block.visible ? (
        <CatIcon name="eye-off" className="ms-auto h-3 w-3 shrink-0 text-slate-400" />
      ) : null}
    </span>
  );

  const stripBase =
    "relative flex flex-col justify-center gap-1.5 rounded-xl px-2.5 py-2 transition-colors duration-300";

  if (block.key === "cta") {
    /* the CTA band is drawn as its actual gradient strip */
    return (
      <motion.div
        layout
        transition={{ layout: { duration: 0.35, ease: [0.22, 1, 0.36, 1] } }}
        animate={{ opacity: block.visible ? 1 : 0.4 }}
        className={cn(
          stripBase,
          "h-11",
          nested && "ms-3.5",
          block.visible ? "" : "border border-dashed border-slate-300 dark:border-white/15"
        )}
        style={block.visible ? { backgroundImage: grad(style.c1, style.c2) } : undefined}
      >
        <span className="flex items-center gap-2">
          <span className="truncate text-[11px] font-black uppercase tracking-wide text-white/90">{name}</span>
          <span className="ms-auto h-3.5 w-12 rounded-full bg-white/90" aria-hidden="true" />
        </span>
        {!block.visible ? (
          <CatIcon name="eye-off" className="absolute end-2 top-1/2 h-3 w-3 -translate-y-1/2 text-slate-400" />
        ) : null}
      </motion.div>
    );
  }

  const heights: Record<Exclude<SiteBlockKey, "cta">, string> = {
    hero: "h-24",
    services: "h-[72px]",
    about: "h-16",
    contact: "h-[72px]",
    hours: "h-[30px]",
    social: "h-[30px]",
  };

  return (
    <motion.div
      layout
      transition={{ layout: { duration: 0.35, ease: [0.22, 1, 0.36, 1] } }}
      animate={{ opacity: block.visible ? 1 : 0.4 }}
      className={cn(
        stripBase,
        heights[block.key],
        nested && "ms-3.5 border-s-2 border-s-dashed border-slate-300 dark:border-white/15",
        block.visible
          ? "border border-slate-200 bg-white/95 shadow-sm dark:border-white/10 dark:bg-white/[0.05]"
          : "border border-dashed border-slate-300 bg-transparent dark:border-white/15"
      )}
    >
      {label}
      {block.visible ? (
        <span className="contents" aria-hidden="true">
          {block.key === "hero" ? (
            <span className="flex flex-col items-center gap-1.5">
              <span className="h-2 w-12 rounded-full" style={{ backgroundImage: grad(style.c1, style.c2) }} />
              <MiniBar className="h-2.5 w-24" />
              <MiniBar className="h-1.5 w-16" />
              <span className="mt-0.5 flex items-center gap-1">
                {[0, 1, 2, 3].map((i) => (
                  <span key={i} className="h-4 w-8 rounded-md bg-slate-100 dark:bg-white/10" />
                ))}
              </span>
            </span>
          ) : null}
          {block.key === "services" ? (
            <span className="grid grid-cols-3 gap-1.5">
              {[0, 1, 2].map((i) => (
                <span
                  key={i}
                  className="flex flex-col gap-1 rounded-lg border border-slate-200 bg-slate-50/80 p-1.5 dark:border-white/10 dark:bg-white/[0.03]"
                >
                  <span className="h-3 w-3 rounded-md" style={{ backgroundImage: grad(style.c1, style.c2) }} />
                  <MiniBar className="h-1.5 w-full" />
                </span>
              ))}
            </span>
          ) : null}
          {block.key === "about" ? (
            <span className="flex items-center gap-2">
              <span className="flex flex-1 flex-col gap-1">
                <MiniBar className="h-2 w-2/3" />
                <MiniBar className="h-1.5 w-1/2" />
                <MiniBar className="h-1.5 w-3/5" />
              </span>
              <span className="flex h-11 w-14 shrink-0 flex-col overflow-hidden rounded-lg border border-slate-200 dark:border-white/10">
                <span className="h-2.5 w-full" style={{ backgroundImage: grad(style.c1, style.c2) }} />
                <span className="flex-1 bg-slate-50 dark:bg-white/[0.04]" />
              </span>
            </span>
          ) : null}
          {block.key === "contact" ? (
            <span className="grid grid-cols-[0.9fr_1.1fr] gap-1.5">
              <span className="flex flex-col gap-1">
                {[0, 1, 2].map((i) => (
                  <span key={i} className="flex items-center gap-1 rounded-md bg-slate-100 px-1 py-0.5 dark:bg-white/10">
                    <span className="h-2 w-2 shrink-0 rounded-full bg-slate-300 dark:bg-white/25" />
                    <MiniBar className="h-1.5 flex-1" />
                  </span>
                ))}
              </span>
              <span className="flex flex-col gap-1 rounded-lg border border-slate-200 p-1.5 dark:border-white/10">
                <MiniBar className="h-1.5 w-2/3" />
                <MiniBar className="h-1.5 w-1/2" />
                <span className="mt-0.5 h-2.5 w-full rounded-full" style={{ backgroundImage: grad(style.c1, style.c2) }} />
              </span>
            </span>
          ) : null}
          {block.key === "hours" ? (
            <span className="flex items-center gap-1.5">
              <MiniBar className="h-1.5 w-1/2" />
              <span className="ms-auto h-3 w-3 shrink-0 rounded-md" style={{ backgroundImage: grad(style.c1, style.c2) }} />
            </span>
          ) : null}
          {block.key === "social" ? (
            <span className="flex items-center gap-1.5">
              {["#25d366", "#64748b", "#d946ef"].map((c) => (
                <span key={c} className="h-3 w-3 rounded-full" style={{ backgroundColor: c }} />
              ))}
            </span>
          ) : null}
        </span>
      ) : null}
    </motion.div>
  );
}

/** The live miniature: a narrow browser frame with the current block order. */
function SitePhonePreview({
  blocks,
  publicPath,
}: {
  blocks: SiteBlockLayout[];
  publicPath: string;
}) {
  const { t } = useT();
  return (
    <div className="flex flex-col gap-2">
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-white/10 dark:bg-ink-950">
        {/* browser chrome */}
        <div className="flex items-center gap-1.5 border-b border-slate-200 bg-slate-50 px-2.5 py-1.5 dark:border-white/10 dark:bg-white/[0.04]">
          <span className="flex items-center gap-1" aria-hidden="true">
            <span className="h-2 w-2 rounded-full bg-rose-400" />
            <span className="h-2 w-2 rounded-full bg-amber-400" />
            <span className="h-2 w-2 rounded-full bg-emerald-400" />
          </span>
          <span
            dir="ltr"
            className="min-w-0 flex-1 truncate rounded-md bg-white px-1.5 py-0.5 text-center font-mono text-[11px] font-bold text-slate-400 dark:bg-white/[0.06] dark:text-slate-500"
          >
            {publicPath}
          </span>
        </div>
        {/* grid-paper canvas with the ordered strips */}
        <div className="max-h-[430px] space-y-1.5 overflow-y-auto p-2.5 [contain:content]" style={GRID_PAPER}>
          {blocks.map((block) => (
            <PreviewStrip key={block.key} block={block} />
          ))}
        </div>
      </div>
      <p className="flex items-center justify-center gap-1 text-center text-[11px] font-bold leading-relaxed text-slate-400 dark:text-slate-500">
        <CatIcon name="eye" className="h-2.5 w-2.5 shrink-0" />
        {t("siteCanvasPreviewDesc")}
      </p>
    </div>
  );
}

/**
 * Round 35 — the premium "Canvas / لوحة البناء" card: drag-and-drop
 * ordering of the site's sections (@dnd-kit, RTL-safe by design), per-block
 * visibility switches with an eye ⇄ eye-off transition, reset-to-default,
 * and a live schematic miniature of the site in its CURRENT order.
 */
function SiteCanvasCard({
  blocks,
  onChange,
  publicPath,
}: {
  blocks: SiteBlockLayout[];
  onChange: (blocks: SiteBlockLayout[]) => void;
  publicPath: string;
}) {
  const { t, lang } = useT();
  const [activeKey, setActiveKey] = useState<SiteBlockKey | null>(null);
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const shownCount = blocks.filter((b) => b.visible).length;
  const blockName = (key: string) => t(BLOCK_NAME_KEY[key as SiteBlockKey]);

  /* localized live-region announcements (screen readers) */
  const announcements: Announcements = {
    onDragStart: ({ active }) => (active ? t("siteCanvasDragStarted", { name: blockName(String(active.id)) }) : ""),
    onDragOver: () => t("siteCanvasDragOver"),
    onDragEnd: ({ active }) => (active ? t("siteCanvasDragDropped", { name: blockName(String(active.id)) }) : ""),
    onDragCancel: ({ active }) => (active ? t("siteCanvasDragDropped", { name: blockName(String(active.id)) }) : ""),
  };

  const handleDragStart = (event: DragStartEvent) => {
    setActiveKey((event.active.id as SiteBlockKey) ?? null);
  };

  const handleDragEnd = (event: DragEndEvent) => {
    setActiveKey(null);
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const oldIndex = blocks.findIndex((b) => b.key === active.id);
    const newIndex = blocks.findIndex((b) => b.key === over.id);
    if (oldIndex < 0 || newIndex < 0) return;
    onChange(arrayMove(blocks, oldIndex, newIndex));
  };

  const toggle = (key: SiteBlockKey) =>
    onChange(blocks.map((b) => (b.key === key ? { ...b, visible: !b.visible } : b)));

  const reset = () => onChange(DEFAULT_SITE_BLOCKS.map((b) => ({ ...b })));

  const active = activeKey ? blocks.find((b) => b.key === activeKey) : null;

  return (
    <DashCard
      title={t("siteCanvasTitle")}
      icon="layers"
      action={
        <Button
          variant="outline"
          size="sm"
          onClick={reset}
          title={t("siteCanvasResetTitle")}
          className="h-8 gap-1.5 rounded-xl px-3 text-[11.5px] font-bold"
        >
          <CatIcon name="rotate-ccw" className="h-3.5 w-3.5" />
          {t("siteCanvasReset")}
        </Button>
      }
    >
      <div className="flex flex-wrap items-center gap-2">
        <p className="min-w-0 flex-1 basis-56 text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
          {t("siteCanvasDesc")}
        </p>
        <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-brand-300/60 bg-brand-500/10 px-2.5 py-1 text-[10px] font-black text-brand-600 dark:border-brand-500/40 dark:bg-brand-500/15 dark:text-brand-300">
          <CatIcon name="grip-vertical" className="h-3 w-3" />
          {t("siteCanvasCount", { shown: nf(lang, shownCount), total: nf(lang, blocks.length) })}
        </span>
      </div>

      {/* mobile-first: explicit minmax(0,1fr) track + min-w-0 children keep the
          auto-sized sortable rows (nowrap truncate descs) from inflating the
          implicit grid track ~400px and overflowing the page on phones */}
      <div className="mt-4 grid min-w-0 grid-cols-1 items-start gap-4 md:grid-cols-[minmax(0,1fr)_248px]">
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          accessibility={{ announcements }}
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
          onDragCancel={() => setActiveKey(null)}
        >
          <SortableContext items={blocks.map((b) => b.key)} strategy={verticalListSortingStrategy}>
            <div className="min-w-0 space-y-2.5">
              {blocks.map((block) => (
                <SortableBlockRow
                  key={block.key}
                  block={block}
                  onToggle={() => toggle(block.key)}
                />
              ))}
            </div>
          </SortableContext>
          <DragOverlay dropAnimation={{ duration: 220, easing: "cubic-bezier(0.22, 1, 0.36, 1)" }}>
            {active ? (
              <div className="flex items-center gap-2.5 rounded-2xl border border-brand-300 bg-white p-3 shadow-lift dark:border-brand-500/40 dark:bg-ink-900">
                <span
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
                  style={{ backgroundImage: grad(BLOCK_STYLE[active.key].c1, BLOCK_STYLE[active.key].c2) }}
                  aria-hidden="true"
                >
                  <CatIcon name={BLOCK_STYLE[active.key].icon} className="h-4 w-4" />
                </span>
                <span className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-200">
                  {t(BLOCK_NAME_KEY[active.key])}
                </span>
                <CatIcon name="grip-vertical" className="h-4 w-4 text-slate-300 dark:text-slate-600" />
              </div>
            ) : null}
          </DragOverlay>
        </DndContext>

        {/* live miniature — the canvas preview of the site in its current order */}
        <div className="min-w-0 md:sticky md:top-2">
          <p className="mb-2 flex items-center gap-1.5 text-[10px] font-black uppercase tracking-wide text-slate-400 dark:text-slate-500">
            <CatIcon name="monitor-smartphone" className="h-3 w-3" />
            {t("siteCanvasPreviewTitle")}
          </p>
          <SitePhonePreview blocks={blocks} publicPath={publicPath} />
          <p className="mt-2 text-[10px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("siteCanvasHiddenHint")}
          </p>
        </div>
      </div>
    </DashCard>
  );
}

/* ------------------------------------------------ main view ------------ */

export function WebsiteView({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();

  /* local overrides — null means "use the server value" (derived state:
     no sync effects; the server value always wins until the user edits) */
  const [draft, setDraft] = useState<SiteContent | null>(null);
  const [previewKey, setPreviewKey] = useState(0);

  const query = useQuery({
    queryKey: ["site", instance.id],
    queryFn: () => fetchSite(instance.id),
    retry: 1,
  });

  const site = query.data;
  /* content being edited — server data until the user touches anything.
   * ROUND 86 (directive ③): the COLOR THEME no longer lives here — it moved
   * to Settings → الألوان والخطوط (its own instant-save picker); this editor
   * owns the CONTENT only, and the miniature reads the theme read-only. */
  const content = draft ?? site?.content ?? null;
  /* round 32/33 — the EN translation block (neutral EMPTY_EN until authored);
   * declared here (before the early returns) so the AI-translate mutation
   * can close over it safely. */
  const en = content?.en ?? EMPTY_EN;
  const themeKey = site?.theme ?? "aurora";

  /* dirty = the CONTENT differs from the server copy (the THEME has its own
   * instant-save picker in Settings → الألوان والخطوط since ROUND 86). */
  const dirty = useMemo(() => {
    if (!site || !content) return false;
    return JSON.stringify(content) !== JSON.stringify(site.content);
  }, [content, site]);

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["site", instance.id] });
    queryClient.invalidateQueries({ queryKey: ["instance", instance.id] });
    queryClient.invalidateQueries({ queryKey: ["instances"] });
  };

  /* ROUND 87 — fields this editor does NOT own. They are managed by their
   * own instant-save cards in Settings (colors & fonts / visitor languages /
   * invoice branding) — the editor STRIPS them from every save payload so a
   * stale editor snapshot can never revert a choice the owner just made on
   * another surface (the server merge-keeps absent fields). */
  const SETTINGS_OWNED_KEYS = [
    "storeTheme",
    "siteFont",
    "storeFont",
    "dashTheme",
    "dashFont",
    "siteLangs",
    "storeLangs",
    "signatureUrl",
    "stampUrl",
    "signatureScale",
    "stampScale",
    "invoicePrefix",
  ] as const;
  const editorPayload = (): SiteContent | undefined => {
    if (!content) return undefined;
    const out: Record<string, unknown> = { ...content };
    for (const key of SETTINGS_OWNED_KEYS) delete out[key];
    return out as unknown as SiteContent;
  };

  const save = useMutation({
    mutationFn: () =>
      updateSite(instance.id, {
        /* ROUND 86 — content ONLY: the theme is managed by Settings →
           الألوان والخطوط with its own instant save.
           ROUND 87 — the styling/langs/invoice fields are STRIPPED (the
           settings cards own them; the server keeps the stored values). */
        content: editorPayload(),
      }),
    onSuccess: () => {
      toast.success(t("siteSaved"));
      invalidate();
      setPreviewKey((k) => k + 1);
    },
    onError: (e: Error) => toast.error(e.message || t("siteSaveErr")),
  });

  const publish = useMutation({
    mutationFn: (published: boolean) =>
      updateSite(instance.id, {
        published,
        /* ROUND 87 — the stripped payload (settings-owned fields absent). */
        ...(dirty ? { content: editorPayload() } : {}),
      }),
    onSuccess: (_data, published) => {
      invalidate();
      setPreviewKey((k) => k + 1);
      if (published) {
        toast.success(t("sitePublishedToast"));
      } else {
        toast.info(t("siteUnpublishedToast"));
      }
    },
    onError: (e: Error) => toast.error(e.message || t("siteSaveErr")),
  });

  /* round 33 — AI draft translations for the empty EN fields. Nothing is
   * persisted server-side: the suggestions land in the editor draft and the
   * owner reviews them through the normal save flow. ROUND 79 — the feature
   * itself is plan-gated: when "translations" is outside the plan the
   * button disables with a lock tooltip (client mirror; the server route
   * refuses with FEATURE_NOT_IN_PLAN anyway). */
  const translationsOn = instance.entitlement?.features?.translations !== false;
  const autoTranslate = useMutation({
    mutationFn: () => {
      if (!content) return Promise.reject(new Error("NO_CONTENT"));
      return translateSiteContent(instance.id, content);
    },
    onSuccess: (result) => {
      if (!content) return;
      const nextEn = { ...en };
      (Object.keys(result.en) as (keyof SiteContentEn)[]).forEach((k) => {
        const v = result.en[k];
        if (v && !(nextEn[k] ?? "").trim()) {
          nextEn[k] = v;
        }
      });
      const services = content.services.map((s, i) => {
        const found = result.services.find((x) => x.index === i);
        if (!found) return s;
        return {
          ...s,
          titleEn: (s.titleEn ?? "").trim() ? s.titleEn : found.titleEn,
          descEn: (s.descEn ?? "").trim() ? s.descEn : found.descEn,
        };
      });
      setDraft({ ...content, en: nextEn, services });
      toast.success(t("siteEnAutoDone"));
    },
    onError: (e: Error) => {
      const msg = e.message || "";
      if (msg.includes("COOLDOWN")) toast.info(t("siteEnAutoCooldown"));
      else if (msg.includes("NOTHING_TO_TRANSLATE")) toast.info(t("siteEnAutoNothing"));
      else toast.error(t("siteEnAutoErr"));
    },
  });

  const resetDraft = () => {
    /* back to the server values (overrides cleared) */
    setDraft(null);
  };

  const validate = (): boolean => {
    if (!content) return false;
    if (!content.tagline.trim()) return toast.error(t("siteErrTagline")) as unknown as boolean;
    if (!content.heroTitle.trim()) return toast.error(t("siteErrHeroTitle")) as unknown as boolean;
    if (!content.aboutTitle.trim()) return toast.error(t("siteErrAboutTitle")) as unknown as boolean;
    if (content.services.some((s) => !s.title.trim()))
      return toast.error(t("siteErrServiceTitle")) as unknown as boolean;
    return true;
  };

  const publicPath = `/sites/${instance.id}`;

  const copyUrl = async () => {
    try {
      await navigator.clipboard.writeText(`${window.location.origin}${publicPath}`);
      toast.success(t("toastCopied"));
    } catch {
      toast.error(t("errorText"));
    }
  };

  /* ------------------------------------------------ loading / error ---- */
  if (query.isPending) {
    return (
      <div aria-busy="true" aria-label={t("siteLoading")}>
        <ViewHeading title={t("dashWebsite")} desc={t("dashWebsiteDesc")} />
        <div className="grid min-w-0 grid-cols-1 gap-4 lg:grid-cols-[minmax(0,1fr)_400px]">
          <div className="min-w-0 space-y-4">
            <Skeleton className="h-52 rounded-3xl" />
            <Skeleton className="h-40 rounded-3xl" />
            <Skeleton className="h-32 rounded-3xl" />
          </div>
          <div className="min-w-0 space-y-4">
            <Skeleton className="h-48 rounded-3xl" />
            <Skeleton className="h-28 rounded-3xl" />
            <Skeleton className="h-80 rounded-3xl" />
          </div>
        </div>
      </div>
    );
  }

  if (query.isError || !site || !content) {
    return (
      <div className="mx-auto max-w-md rounded-3xl border border-slate-200 bg-white p-8 text-center shadow-lift dark:border-white/10 dark:bg-ink-900">
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-rose-50 text-rose-500 dark:bg-rose-500/10 dark:text-rose-400">
          <CatIcon name="triangle-alert" className="h-6 w-6" />
        </div>
        <h3 className="mt-4 font-display text-lg font-extrabold">{t("errorText")}</h3>
        <p className="mt-1 text-[12.5px] text-slate-500 dark:text-slate-400">
          {query.error instanceof Error ? query.error.message : t("errorText")}
        </p>
        <Button
          variant="outline"
          onClick={() => query.refetch()}
          className="mt-4 h-10 rounded-xl px-5 text-[12.5px] font-bold"
        >
          <CatIcon name="refresh-cw" className="h-4 w-4" />
          {t("retryText")}
        </Button>
      </div>
    );
  }

  const theme = siteTheme(themeKey);
  const published = site.published;

  /* round 35 — canvas blocks: the layout rides inside the content (no new
   * API/schema); a site without a layout starts from the default order. */
  const layoutBlocks = content.layout?.blocks ?? DEFAULT_SITE_BLOCKS;

  /* editing helpers — every edit writes the FULL content override */
  const edit = (patch: Partial<SiteContent>) => setDraft({ ...content, ...patch });
  const editEn = (patch: Partial<SiteContentEn>) => edit({ en: { ...en, ...patch } });
  /* translation coverage: 6 text fields (heroTitle excluded — brand names
   * intentionally stay as-is) + one slot per service card. Plain computation
   * (no hook): it must run after the loading/error early-returns above. */
  const enCoverage = (() => {
    const fields = [en.tagline, en.heroDesc, en.aboutTitle, en.about, en.contactAddress, en.workingHours];
    const doneFields = fields.filter((v) => v.trim().length > 0).length;
    const services = content.services;
    const doneServices = services.filter(
      (s) => (s.titleEn ?? "").trim().length > 0 || (s.descEn ?? "").trim().length > 0
    ).length;
    const total = fields.length + services.length;
    return { done: doneFields + doneServices, total, pct: total === 0 ? 0 : Math.round(((doneFields + doneServices) / total) * 100) };
  })();
  const setService = (index: number, next: SiteService) => {
    setDraft({ ...content, services: content.services.map((s, i) => (i === index ? next : s)) });
  };
  const removeService = (index: number) => {
    setDraft({ ...content, services: content.services.filter((_, i) => i !== index) });
  };
  const moveService = (index: number, dir: -1 | 1) => {
    const target = index + dir;
    if (target < 0 || target >= content.services.length) return;
    const services = [...content.services];
    [services[index], services[target]] = [services[target], services[index]];
    setDraft({ ...content, services });
  };
  const addService = () => {
    if (content.services.length >= MAX_SERVICES) return;
    setDraft({ ...content, services: [...content.services, { ...EMPTY_SERVICE }] });
  };

  return (
    <div className="pb-20">
      <div className="mb-6 flex flex-wrap items-start justify-between gap-3">
        <ViewHeading title={t("dashWebsite")} desc={t("dashWebsiteDesc")} />
        <div className="flex items-center gap-2">
          <span
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11px] font-extrabold",
              published
                ? "border-emerald-300/70 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
                : "border-amber-300/70 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300"
            )}
          >
            <CatIcon name={published ? "globe" : "pencil"} className="h-[11px] w-[11px]" />
            {published ? t("siteStatusPublished") : t("siteStatusDraft")}
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-[11px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400">
            <CatIcon name="eye" className="h-[11px] w-[11px]" />
            {nf(lang, site.views)} {t("siteViewsUnit")}
          </span>
        </div>
      </div>

      <div className="grid min-w-0 grid-cols-1 items-start gap-4 lg:grid-cols-[minmax(0,1fr)_400px]">
        {/* --------------------------------------------- editor column --- */}
        <div className="min-w-0 space-y-4">
          {/* round 35 — canvas: drag-and-drop section order + visibility */}
          <SiteCanvasCard
            blocks={layoutBlocks}
            onChange={(blocks) => edit({ layout: { blocks } })}
            publicPath={publicPath}
          />

          {/* identity */}
          <DashCard title={t("siteEditorIdentity")} icon="wand-sparkles">
            <div className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="site-tagline" className="text-[12px] font-bold">
                    {t("siteTagline")}
                  </Label>
                  <Input
                    id="site-tagline"
                    value={content.tagline}
                    onChange={(e) => edit({ tagline: e.target.value })}
                    placeholder={t("siteTaglinePh")}
                    maxLength={90}
                    className="h-10 rounded-xl text-[13px]"
                  />
                  <p className="text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                    {t("siteTaglineHint")}
                  </p>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="site-hero-title" className="text-[12px] font-bold">
                    {t("siteHeroTitle")}
                  </Label>
                  <Input
                    id="site-hero-title"
                    value={content.heroTitle}
                    onChange={(e) => edit({ heroTitle: e.target.value })}
                    placeholder={instance.org.name}
                    maxLength={120}
                    className="h-10 rounded-xl text-[13px]"
                  />
                  <p className="text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                    {t("siteHeroTitleHint")}
                  </p>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="site-hero-desc" className="text-[12px] font-bold">
                  {t("siteHeroDesc")}
                </Label>
                <textarea
                  id="site-hero-desc"
                  value={content.heroDesc}
                  onChange={(e) => edit({ heroDesc: e.target.value })}
                  placeholder={t("siteHeroDescPh")}
                  maxLength={400}
                  rows={3}
                  className="w-full resize-none rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-[13px] shadow-sm outline-none transition placeholder:text-slate-400 focus:border-brand-400 focus:ring-2 focus:ring-brand-400/20 dark:border-white/10 dark:bg-white/[0.04] dark:text-white dark:placeholder:text-slate-500"
                />
              </div>
            </div>
          </DashCard>

          {/* about */}
          <DashCard title={t("siteEditorAbout")} icon="house">
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="site-about-title" className="text-[12px] font-bold">
                  {t("siteAboutTitle")}
                </Label>
                <Input
                  id="site-about-title"
                  value={content.aboutTitle}
                  onChange={(e) => edit({ aboutTitle: e.target.value })}
                  placeholder={t("siteAboutTitlePh")}
                  maxLength={120}
                  className="h-10 rounded-xl text-[13px]"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="site-about" className="text-[12px] font-bold">
                  {t("siteAboutText")}
                </Label>
                <textarea
                  id="site-about"
                  value={content.about}
                  onChange={(e) => edit({ about: e.target.value })}
                  placeholder={t("siteAboutTextPh")}
                  maxLength={1500}
                  rows={5}
                  className="w-full resize-none rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-[13px] leading-relaxed shadow-sm outline-none transition placeholder:text-slate-400 focus:border-brand-400 focus:ring-2 focus:ring-brand-400/20 dark:border-white/10 dark:bg-white/[0.04] dark:text-white dark:placeholder:text-slate-500"
                />
              </div>
            </div>
          </DashCard>

          {/* services */}
          <DashCard
            title={t("siteEditorServices")}
            icon="briefcase"
            action={
              <Button
                variant="outline"
                size="sm"
                onClick={addService}
                disabled={content.services.length >= MAX_SERVICES}
                className="h-8 gap-1.5 rounded-xl px-3 text-[11.5px] font-bold"
              >
                <CatIcon name="plus" className="h-3.5 w-3.5" />
                {t("siteAddService")}
              </Button>
            }
          >
            {content.services.length === 0 ? (
              <div className="rounded-2xl border-2 border-dashed border-slate-200 p-6 text-center dark:border-white/10">
                <div className="mx-auto grid h-11 w-11 place-items-center rounded-xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
                  <CatIcon name="briefcase" className="h-5 w-5" />
                </div>
                <p className="mt-3 text-[12.5px] font-bold text-slate-500 dark:text-slate-400">
                  {t("siteServicesEmpty")}
                </p>
                <p className="mt-1 text-[11.5px] text-slate-400 dark:text-slate-500">
                  {t("siteServicesEmptyDesc", { max: nf(lang, MAX_SERVICES) })}
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {content.services.map((service, i) => (
                  <ServiceRow
                    key={i}
                    index={i}
                    service={service}
                    total={content.services.length}
                    onChange={(next) => setService(i, next)}
                    onRemove={() => removeService(i)}
                    onMove={(dir) => moveService(i, dir)}
                    canMove={(dir) => i + dir >= 0 && i + dir < content.services.length}
                  />
                ))}
              </div>
            )}
          </DashCard>

          {/* contact */}
          <DashCard title={t("siteEditorContact")} icon="phone">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="site-contact-email" className="text-[12px] font-bold">
                  {t("siteContactEmail")}
                </Label>
                <Input
                  id="site-contact-email"
                  type="email"
                  dir="ltr"
                  value={content.contactEmail}
                  onChange={(e) => edit({ contactEmail: e.target.value })}
                  placeholder="info@organization.com"
                  maxLength={160}
                  className="h-10 rounded-xl text-[13px] text-start"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="site-contact-phone" className="text-[12px] font-bold">
                  {t("siteContactPhone")}
                </Label>
                <Input
                  id="site-contact-phone"
                  dir="ltr"
                  value={content.contactPhone}
                  onChange={(e) => edit({ contactPhone: e.target.value })}
                  placeholder="+966 11 000 0000"
                  maxLength={60}
                  className="h-10 rounded-xl text-[13px] text-start"
                />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label htmlFor="site-contact-address" className="text-[12px] font-bold">
                  {t("siteContactAddress")}
                </Label>
                <Input
                  id="site-contact-address"
                  value={content.contactAddress}
                  onChange={(e) => edit({ contactAddress: e.target.value })}
                  placeholder={t("siteContactAddressPh")}
                  maxLength={220}
                  className="h-10 rounded-xl text-[13px]"
                />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label htmlFor="site-working-hours" className="text-[12px] font-bold">
                  {t("siteWorkingHours")}
                </Label>
                <Input
                  id="site-working-hours"
                  value={content.workingHours}
                  onChange={(e) => edit({ workingHours: e.target.value })}
                  placeholder={t("siteWorkingHoursPh")}
                  maxLength={200}
                  className="h-10 rounded-xl text-[13px]"
                />
                <p className="text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                  {t("siteHoursHint")}
                </p>
              </div>
            </div>
          </DashCard>

          {/* English content (round 32) — translation of the authored fields */}
          <DashCard
            title={t("siteEditorEn")}
            icon="languages"
            action={
              <span className="inline-flex items-center gap-1.5 rounded-full border border-brand-300/60 bg-brand-500/10 px-2.5 py-1 text-[10px] font-black text-brand-600 dark:border-brand-500/40 dark:bg-brand-500/15 dark:text-brand-300">
                <CatIcon name="globe" className="h-3 w-3" />
                {t("siteEditorEnChip")}
              </span>
            }
          >
            <div className="space-y-4">
              <p className="text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                {t("siteEditorEnDesc")}
              </p>

              {/* coverage meter */}
              <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
                <div className="flex items-center justify-between gap-3">
                  <p className="flex items-center gap-1.5 text-[11px] font-extrabold text-slate-500 dark:text-slate-400">
                    <CatIcon name="badge-check" className="h-3.5 w-3.5 text-brand-500" />
                    {t("siteEnCoverage")}
                  </p>
                  <p className="font-mono text-[11px] font-extrabold tabular-nums text-slate-700 dark:text-slate-300">
                    {t("siteEnCoverageValue", { done: nf(lang, enCoverage.done), total: nf(lang, enCoverage.total) })}
                  </p>
                </div>
                <div className="mt-2.5 h-2 overflow-hidden rounded-full bg-slate-200/80 dark:bg-white/10">
                  <div
                    className={cn(
                      "h-full rounded-full transition-all duration-500",
                      enCoverage.pct === 100
                        ? "bg-linear-to-r from-emerald-500 to-emerald-400"
                        : "bg-linear-to-r from-brand-500 to-brand-400"
                    )}
                    style={{ width: `${Math.max(enCoverage.pct, 3)}%` }}
                  />
                </div>
                <p
                  className={cn(
                    "mt-2 text-[10.5px] font-bold leading-relaxed",
                    enCoverage.pct === 100
                      ? "text-emerald-600 dark:text-emerald-400"
                      : enCoverage.done === 0
                        ? "text-slate-400 dark:text-slate-500"
                        : "text-brand-600 dark:text-brand-300"
                  )}
                >
                  {enCoverage.pct === 100
                    ? t("siteEnCoverageFull")
                    : enCoverage.done === 0
                      ? t("siteEnCoverageEmpty")
                      : null}
                </p>

                {/* round 33 — AI auto-translate: drafts for the EMPTY fields only.
                    ROUND 79 — locked (disabled + lock tooltip) when the
                    translations feature is outside the current plan. */}
                <div className="mt-3 border-t border-dashed border-slate-200 pt-3 dark:border-white/10">
                  <button
                    type="button"
                    onClick={() => autoTranslate.mutate()}
                    disabled={
                      autoTranslate.isPending ||
                      enCoverage.done >= enCoverage.total ||
                      !translationsOn
                    }
                    title={
                      !translationsOn
                        ? t("featLockedTitle")
                        : enCoverage.done >= enCoverage.total
                          ? t("siteEnAutoNothing")
                          : t("siteEnAutoNothingHint")
                    }
                    aria-disabled={!translationsOn || undefined}
                    className={cn(
                      "group relative flex w-full items-center justify-center gap-2 overflow-hidden rounded-xl px-4 py-2.5 text-[12px] font-extrabold text-white shadow-lg transition active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-60",
                      autoTranslate.isPending && "animate-pulse",
                    )}
                    style={{
                      backgroundImage:
                        "linear-gradient(120deg,#6d5dfb 0%,#8b5cf6 45%,#d946ef 100%)",
                      boxShadow: "0 14px 30px -12px rgba(139, 92, 246, 0.65)",
                    }}
                  >
                    <CatIcon
                      name={
                        !translationsOn
                          ? "lock"
                          : autoTranslate.isPending
                            ? "refresh-cw"
                            : "wand-sparkles"
                      }
                      className={cn("h-4 w-4", autoTranslate.isPending && "animate-spin")}
                    />
                    {!translationsOn ? t("featUpgradeCta") : autoTranslate.isPending ? t("siteEnAutoBusy") : t("siteEnAutoBtn")}
                    <span
                      className="absolute end-2 top-1/2 -translate-y-1/2 rounded-md bg-white/20 px-1.5 py-0.5 text-[11px] font-black tracking-widest"
                      aria-hidden="true"
                    >
                      {t("siteEnAutoBadge")}
                    </span>
                  </button>
                  <p className="mt-1.5 flex items-start gap-1.5 text-[10px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                    <CatIcon name="sparkles" className="mt-px h-3 w-3 shrink-0 text-fuchsia-500" />
                    {t("siteEnAutoNothingHint")}
                  </p>
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="site-en-tagline" className="text-[12px] font-bold">
                    {t("siteEnTagline")}
                  </Label>
                  <Input
                    id="site-en-tagline"
                    dir="ltr"
                    value={en.tagline}
                    onChange={(e) => editEn({ tagline: e.target.value })}
                    placeholder={content.tagline || "Powered by the system"}
                    maxLength={90}
                    className="h-10 rounded-xl text-[13px] text-start"
                  />
                  <p className="truncate text-[10px] font-semibold text-slate-400 dark:text-slate-500" dir="auto">
                    {t("siteEnArRef", { text: content.tagline })}
                  </p>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="site-en-hero-title" className="text-[12px] font-bold">
                    {t("siteEnHeroTitle")}
                  </Label>
                  <Input
                    id="site-en-hero-title"
                    dir="ltr"
                    value={en.heroTitle}
                    onChange={(e) => editEn({ heroTitle: e.target.value })}
                    placeholder={content.heroTitle || instance.org.name}
                    maxLength={120}
                    className="h-10 rounded-xl text-[13px] text-start"
                  />
                  <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                    {t("siteEnHeroTitleHint")}
                  </p>
                </div>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="site-en-hero-desc" className="text-[12px] font-bold">
                  {t("siteEnHeroDesc")}
                </Label>
                <textarea
                  id="site-en-hero-desc"
                  dir="ltr"
                  value={en.heroDesc}
                  onChange={(e) => editEn({ heroDesc: e.target.value })}
                  placeholder={content.heroDesc || "Professional services to world-class standards"}
                  maxLength={400}
                  rows={2}
                  className="w-full resize-none rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-start text-[13px] shadow-sm outline-none transition placeholder:text-slate-400 focus:border-brand-400 focus:ring-2 focus:ring-brand-400/20 dark:border-white/10 dark:bg-white/[0.04] dark:text-white dark:placeholder:text-slate-500"
                />
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="site-en-about-title" className="text-[12px] font-bold">
                  {t("siteEnAboutTitle")}
                </Label>
                <Input
                  id="site-en-about-title"
                  dir="ltr"
                  value={en.aboutTitle}
                  onChange={(e) => editEn({ aboutTitle: e.target.value })}
                  placeholder={content.aboutTitle || "About us"}
                  maxLength={120}
                  className="h-10 rounded-xl text-[13px] text-start"
                />
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="site-en-about" className="text-[12px] font-bold">
                  {t("siteEnAbout")}
                </Label>
                <textarea
                  id="site-en-about"
                  dir="ltr"
                  value={en.about}
                  onChange={(e) => editEn({ about: e.target.value })}
                  placeholder={content.about.slice(0, 80) || "A team of professionals delivering quality every day."}
                  maxLength={1500}
                  rows={4}
                  className="w-full resize-none rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-start text-[13px] leading-relaxed shadow-sm outline-none transition placeholder:text-slate-400 focus:border-brand-400 focus:ring-2 focus:ring-brand-400/20 dark:border-white/10 dark:bg-white/[0.04] dark:text-white dark:placeholder:text-slate-500"
                />
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="site-en-address" className="text-[12px] font-bold">
                    {t("siteEnAddress")}
                  </Label>
                  <Input
                    id="site-en-address"
                    dir="ltr"
                    value={en.contactAddress}
                    onChange={(e) => editEn({ contactAddress: e.target.value })}
                    placeholder={content.contactAddress || "Riyadh, Saudi Arabia"}
                    maxLength={220}
                    className="h-10 rounded-xl text-[13px] text-start"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="site-en-hours" className="text-[12px] font-bold">
                    {t("siteEnHours")}
                  </Label>
                  <Input
                    id="site-en-hours"
                    dir="ltr"
                    value={en.workingHours}
                    onChange={(e) => editEn({ workingHours: e.target.value })}
                    placeholder={content.workingHours || "Sat – Thu · 9:00 AM – 9:00 PM"}
                    maxLength={200}
                    className="h-10 rounded-xl text-[13px] text-start"
                  />
                </div>
              </div>
            </div>
          </DashCard>

          {/* social links (round 29) */}
          <DashCard
            title={t("siteEditorSocial")}
            icon="share-2"
            action={
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  const takenIcons = new Set(content.socialLinks.map((l) => l.icon));
                  const nextNetwork =
                    SOCIAL_LINKS.find((s) => !takenIcons.has(s.icon))?.icon ?? "x";
                  edit({ socialLinks: [...content.socialLinks, { icon: nextNetwork, href: "" }] });
                }}
                disabled={content.socialLinks.length >= MAX_SOCIAL}
                className="h-8 gap-1.5 rounded-xl px-3 text-[11.5px] font-bold"
              >
                <CatIcon name="plus" className="h-3.5 w-3.5" />
                {t("siteSocialAdd")}
              </Button>
            }
          >
            {content.socialLinks.length === 0 ? (
              <div className="rounded-2xl border-2 border-dashed border-slate-200 p-6 text-center dark:border-white/10">
                <div className="mx-auto grid h-11 w-11 place-items-center rounded-xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
                  <CatIcon name="share-2" className="h-5 w-5" />
                </div>
                <p className="mt-3 text-[12.5px] font-bold text-slate-500 dark:text-slate-400">
                  {t("siteSocialEmpty")}
                </p>
                <p className="mt-1 text-[11.5px] text-slate-400 dark:text-slate-500">
                  {t("siteSocialMax", { max: nf(lang, MAX_SOCIAL) })}
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {content.socialLinks.map((link, i) => (
                  <SocialRow
                    key={`${link.icon}-${i}`}
                    index={i}
                    link={link}
                    taken={new Set(content.socialLinks.map((l) => l.icon))}
                    onChange={(next) =>
                      edit({
                        socialLinks: content.socialLinks.map((l, li) => (li === i ? next : l)),
                      })
                    }
                    onRemove={() =>
                      edit({ socialLinks: content.socialLinks.filter((_, li) => li !== i) })
                    }
                  />
                ))}
                <p className="text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                  {t("siteSocialMax", { max: nf(lang, MAX_SOCIAL) })}
                </p>
              </div>
            )}
          </DashCard>

          {/* ROUND 84 (84-LEGAL) — privacy & terms pages: precise editing
              (empty = the professional default copy; preview = the public
              page's own renderer; rides the normal save flow). */}
          <DashCard title={t("legalEditorTitle")} icon="scale">
            <LegalPagesEditor
              content={content}
              orgName={instance.org.name}
              instanceId={instance.id}
              edit={edit}
            />
          </DashCard>
        </div>

        {/* --------------------------------------------- status rail ----- */}
        <div className="min-w-0 space-y-4 lg:sticky lg:top-20">
          {/* launch card */}
          <DashCard className="overflow-hidden !p-0">
            <div
              className="px-5 py-5 text-white"
              style={{ backgroundImage: grad(theme.c1, theme.c2, 130) }}
            >
              <p className="flex items-center gap-2 font-display text-[14px] font-extrabold">
                <CatIcon name="rocket" className="h-4 w-4" />
                {published ? t("siteLiveCard") : t("siteLaunchCard")}
              </p>
              <p className="mt-1.5 text-[11.5px] leading-relaxed text-white/80">
                {published ? t("siteLiveCardDesc") : t("siteLaunchCardDesc")}
              </p>
            </div>

            <div className="space-y-3.5 p-4 sm:p-5">
              <div className="flex items-center justify-between gap-3 rounded-xl bg-slate-50 p-3 dark:bg-white/[0.03]">
                <div className="min-w-0">
                  <p className="text-[12px] font-extrabold text-slate-800 dark:text-slate-200">
                    {t("sitePublishSwitch")}
                  </p>
                  <p className="mt-0.5 truncate text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                    {published ? t("sitePublishOnHint") : t("sitePublishOffHint")}
                  </p>
                </div>
                <Switch
                  checked={published}
                  disabled={publish.isPending}
                  onCheckedChange={(v) => publish.mutate(v)}
                  aria-label={t("sitePublishSwitch")}
                />
              </div>

              {published ? (
                <Button
                  onClick={() => publish.mutate(false)}
                  disabled={publish.isPending}
                  variant="outline"
                  className="h-11 w-full gap-2 rounded-xl text-[12.5px] font-bold"
                >
                  <CatIcon name={publish.isPending ? "refresh-cw" : "power"} className={cn("h-4 w-4", publish.isPending && "animate-spin")} />
                  {t("siteUnpublishBtn")}
                </Button>
              ) : (
                <Button
                  onClick={() => {
                    if (!validate()) return;
                    publish.mutate(true);
                  }}
                  disabled={publish.isPending}
                  className="h-11 w-full gap-2 rounded-xl text-[13px] font-bold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110"
                  style={{ backgroundImage: grad(theme.c1, theme.c2), boxShadow: `0 14px 30px -12px ${hexAlpha(theme.c1, 0.75)}` }}
                >
                  {publish.isPending ? (
                    <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                  ) : (
                    <CatIcon name="rocket" className="h-4 w-4" />
                  )}
                  {t("siteLaunchBtn")}
                </Button>
              )}

              <div className="space-y-2 rounded-xl border border-slate-200 p-3 dark:border-white/10">
                <div className="flex items-center gap-2.5 text-[11.5px] font-bold text-slate-500 dark:text-slate-400">
                  <CatIcon name="eye" className="h-3.5 w-3.5 text-slate-400" />
                  {t("siteViewsUnit")}
                  <span className="ms-auto font-mono text-[12px] font-extrabold text-slate-800 dark:text-slate-200">
                    {nf(lang, site.views)}
                  </span>
                </div>
                <div className="flex items-center gap-2.5 text-[11.5px] font-bold text-slate-500 dark:text-slate-400">
                  <CatIcon name="calendar" className="h-3.5 w-3.5 text-slate-400" />
                  {t("siteLaunchedAt")}
                  <span className="ms-auto text-[11px] font-extrabold text-slate-800 dark:text-slate-200">
                    {site.launchedAt ? fullDate(site.launchedAt, lang) : "—"}
                  </span>
                </div>
              </div>

              {/* public URL row */}
              <div className="rounded-xl border border-slate-200 p-3 dark:border-white/10">
                <p className="flex items-center gap-1.5 text-[10.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                  <CatIcon name="link" className="h-3 w-3" />
                  {t("sitePublicUrl")}
                </p>
                <div className="mt-2 flex items-center gap-1.5">
                  <code
                    dir="ltr"
                    className="min-w-0 flex-1 truncate rounded-lg bg-slate-100 px-2.5 py-2 font-mono text-[11px] font-bold text-slate-700 dark:bg-white/[0.06] dark:text-slate-300"
                  >
                    {publicPath}
                  </code>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={copyUrl}
                    aria-label={t("siteCopyUrl")}
                    className="h-8 w-8 shrink-0 rounded-lg text-slate-400 hover:text-brand-600 dark:text-slate-500"
                  >
                    <CatIcon name="copy" className="h-3.5 w-3.5" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    asChild
                    aria-label={t("siteOpenSite")}
                    className="h-8 w-8 shrink-0 rounded-lg text-slate-400 hover:text-brand-600 dark:text-slate-500"
                  >
                    <a href={`/sites/${instance.id}`} target="_blank" rel="noopener noreferrer">
                      <CatIcon name="external-link" className="h-3.5 w-3.5" />
                    </a>
                  </Button>
                </div>
                {!published ? (
                  <p className="mt-2 flex items-start gap-1.5 text-[10.5px] font-semibold leading-relaxed text-amber-600 dark:text-amber-400">
                    <CatIcon name="eye" className="mt-0.5 h-3 w-3 shrink-0" />
                    {t("siteDraftUrlHint")}
                  </p>
                ) : null}
              </div>
            </div>
          </DashCard>

          {/* ROUND 86 (directive ③) — the COLOR THEME picker was MIGRATED to
              Settings → الألوان والخطوط (its own tab with instant saves and
              per-surface control). The live miniature below still renders
              the current theme (read-only). */}

          {/* live preview */}
          <DashCard
            title={t("sitePreview")}
            icon="monitor-smartphone"
            action={
              <div className="flex items-center gap-1">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setPreviewKey((k) => k + 1)}
                  aria-label={t("sitePreviewRefresh")}
                  className="h-7 w-7 rounded-lg text-slate-400 hover:text-brand-600 dark:text-slate-500"
                >
                  <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  asChild
                  aria-label={t("siteOpenSite")}
                  className="h-7 w-7 rounded-lg text-slate-400 hover:text-brand-600 dark:text-slate-500"
                >
                  <a href={`/sites/${instance.id}`} target="_blank" rel="noopener noreferrer">
                    <CatIcon name="external-link" className="h-3.5 w-3.5" />
                  </a>
                </Button>
              </div>
            }
          >
            {/* browser chrome mockup */}
            <div className="overflow-hidden rounded-2xl border border-slate-200 dark:border-white/10">
              <div className="flex items-center gap-2 border-b border-slate-200 bg-slate-50 px-3 py-2 dark:border-white/10 dark:bg-white/[0.04]">
                <span className="flex items-center gap-1.5" aria-hidden="true">
                  <span className="h-2.5 w-2.5 rounded-full bg-rose-400" />
                  <span className="h-2.5 w-2.5 rounded-full bg-amber-400" />
                  <span className="h-2.5 w-2.5 rounded-full bg-emerald-400" />
                </span>
                <span
                  dir="ltr"
                  className="min-w-0 flex-1 truncate rounded-md bg-white px-2 py-1 text-center font-mono text-[10px] font-bold text-slate-500 dark:bg-white/[0.06] dark:text-slate-400"
                >
                  {publicPath}
                </span>
                <span
                  className={cn(
                    "inline-flex items-center gap-1 rounded-full px-1.5 py-0.5 text-[11px] font-extrabold",
                    published
                      ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                      : "bg-amber-500/10 text-amber-600 dark:text-amber-400"
                  )}
                >
                  <span
                    className={cn(
                      "h-1.5 w-1.5 rounded-full",
                      published ? "animate-pulse bg-emerald-500" : "bg-amber-500"
                    )}
                  />
                  {published ? "LIVE" : "DRAFT"}
                </span>
              </div>
              <iframe
                key={previewKey}
                src={`/sites/${instance.id}`}
                title={t("sitePreview")}
                loading="lazy"
                className="h-[420px] w-full bg-white dark:bg-ink-950"
                sandbox="allow-scripts allow-popups"
              />
            </div>
            <p className="mt-2.5 text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {t("sitePreviewHint")}
            </p>
          </DashCard>
        </div>
      </div>

      {/* ROUND 44 — the storefront order queue now lives in the dedicated
          E-Store view (المتجر الإلكتروني); this page is purely the public
          website builder. */}

      {/* --------------------------------------------- dirty save bar ---- */}
      {dirty ? (
        <div className="fixed inset-x-0 bottom-4 z-40 mx-auto w-fit max-w-[calc(100vw-2rem)]">
          <div className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white/95 px-4 py-3 shadow-lift backdrop-blur-xl dark:border-white/10 dark:bg-ink-900/95">
            <span className="flex items-center gap-2 text-[12px] font-bold text-slate-600 dark:text-slate-300">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand-400 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-brand-500" />
              </span>
              {t("siteDirtyBar")}
            </span>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={resetDraft}
                className="h-9 rounded-xl px-4 text-[12px] font-bold"
              >
                {t("siteDiscardBtn")}
              </Button>
              <Button
                size="sm"
                onClick={() => {
                  if (!validate()) return;
                  save.mutate();
                }}
                disabled={save.isPending}
                className="h-9 gap-2 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-5 text-[12px] font-bold text-white shadow-lg shadow-brand-500/25 hover:brightness-110 dark:from-brand-500 dark:to-brand-400"
              >
                {save.isPending ? (
                  <CatIcon name="refresh-cw" className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <CatIcon name="check" className="h-3.5 w-3.5" />
                )}
                {t("siteSaveBtn")}
              </Button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

export default WebsiteView;
