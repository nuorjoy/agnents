"use client";

/**
 * Ashrilogic — ROUND 82 (batch-5 ③): the Topbar «إضافة سريعة» (Quick Add).
 *
 * The button used to toast "open the add form" outside team/module views.
 * It is now a REAL premium creation dialog available in EVERY dashboard
 * view of EVERY system:
 *
 *  - a module picker (chips of this system's ENABLED modules — sector-
 *    correct labels via moduleDisplayName),
 *  - fields that match the chosen module EXACTLY (modulePreset cols —
 *    patients get name/age/phone/diagnosis, invoices get client/amount/
 *    due date…): text / number / money (currency chip) / date / status
 *    select / the auto-generated 8-digit id code,
 *  - REAL persistence through POST /api/instances/[id]/module-records
 *    (same API + validation the module workspace uses),
 *  - a saved state offering «إضافة أخرى» or «فتح الوحدة» (deep-links into
 *    the module workspace with the سجلاتي tab live).
 *
 * The system type drives everything: field vocabulary, statuses, currency
 * and code prefix all derive from the system's module presets.
 */
import { useMemo, useState, type FormEvent } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { MODULE_MAP, SYSTEM_MAP, moduleDisplayName } from "@/data/catalog";
import { useT } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import type { InstanceDTO } from "@/lib/types";
import { modulePreset, codePrefixFor } from "@/lib/module-data";
import { ApiError, createModuleRecord, fetchModuleRecords, fetchSite } from "@/lib/api-client";
import { DEFAULT_INVOICE_PREFIX, nextRecordCode } from "@/lib/record-code";
import { CatIcon } from "@/components/icon";
import { useShift } from "@/components/dashboard/shift/shift-status-bar";
import { useAccentPair } from "@/components/dashboard/accent-context";
import { cn, fmtNum, grad, hexAlpha } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { PremiumDateInput } from "@/components/ui/premium-date-input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command as CommandPrimitive } from "cmdk";

const TONE_DOT: Record<string, string> = {
  emerald: "bg-emerald-500",
  amber: "bg-amber-500",
  rose: "bg-rose-500",
  sky: "bg-sky-500",
  violet: "bg-violet-500",
  slate: "bg-slate-400",
};

export function QuickAddDialog({
  open,
  onOpenChange,
  instance,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  instance: InstanceDTO;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const setActiveModuleId = useAppStore((s) => s.setActiveModuleId);
  const setDashView = useAppStore((s) => s.setDashView);
  const activeModuleId = useAppStore((s) => s.activeModuleId);
  const dashView = useAppStore((s) => s.dashView);

  const modules = instance.modules;
  const defaultModule = useMemo(() => {
    if (dashView === "module" && activeModuleId && modules.includes(activeModuleId)) {
      return activeModuleId;
    }
    return modules[0] ?? "";
  }, [dashView, activeModuleId, modules]);

  /* the module selection state: "" = follow the smart default (the open
   * module workspace's module, else the system's first enabled module).
   * Reset on close via handleOpenChange — NO setState-in-effect. */
  const [moduleId, setModuleId] = useState<string>("");
  const effectiveModuleId = moduleId || defaultModule;

  /* keyed form state — DERIVED reset when the module changes (the
   * module-workspace tabState pattern: no effect, no cascade) */
  const [formState, setFormState] = useState<{
    moduleId: string;
    values: string[];
    statusKey: string;
    saved: boolean;
  }>({ moduleId: "", values: [], statusKey: "", saved: false });

  /* ROUND 168 — system-scoped preset (SAMS dorm maintenance/security draw
   * the dorm columns here too, matching the workspace + server contract). */
  const preset = useMemo(
    () => (effectiveModuleId ? modulePreset(effectiveModuleId, instance.systemId) : null),
    [effectiveModuleId, instance.systemId]
  );
  const cols = useMemo(() => preset?.cols ?? [], [preset]);
  const statuses = preset?.statuses ?? [];
  const idColIndex = cols.findIndex((c) => c.kind === "id");
  const statusIndex = cols.findIndex((c) => c.kind === "status");

  /* real rows of the selected module (for code continuity + freshness) */
  const recordsQuery = useQuery({
    queryKey: ["module-records", instance.id, effectiveModuleId],
    queryFn: () => fetchModuleRecords(instance.id, effectiveModuleId),
    enabled: open && !!effectiveModuleId,
    staleTime: 30_000,
    retry: 0,
  });
  const records = useMemo(() => recordsQuery.data ?? [], [recordsQuery.data]);

  /* dynamic college options — fetches the tenant's `colleges` module records
   * when the current module is `students` and the system has colleges. The
   * college name is the `name` column (index 1 in the colleges preset). */
  const hasColleges = instance.modules.includes("colleges");
  const collegesQuery = useQuery({
    queryKey: ["module-records", instance.id, "colleges"],
    queryFn: () => fetchModuleRecords(instance.id, "colleges"),
    enabled: open && hasColleges && effectiveModuleId === "students",
    staleTime: 30_000,
    retry: 0,
  });
  const collegeOptions = useMemo(() => {
    if (!hasColleges || effectiveModuleId !== "students") return [];
    const collegeRecords = collegesQuery.data ?? [];
    const nameIdx = 1;
    return collegeRecords
      .map((r) => r.values[nameIdx] ?? "")
      .filter((v) => v.trim() !== "")
      .map((v) => v.trim());
  }, [hasColleges, effectiveModuleId, collegesQuery.data]);

  /* dynamic parent options — fetches the tenant's `parents` module records
   * for the searchable guardian/parent combobox. The parent name is the
   * `parent` column (index 1 in the parents preset). */
  const hasParents = instance.modules.includes("parents");
  const parentsQuery = useQuery({
    queryKey: ["module-records", instance.id, "parents"],
    queryFn: () => fetchModuleRecords(instance.id, "parents"),
    enabled: open && hasParents && (effectiveModuleId === "students" || effectiveModuleId === "parents"),
    staleTime: 30_000,
    retry: 0,
  });
  const parentOptions = useMemo(() => {
    if (!hasParents) return [];
    const parentRecords = parentsQuery.data ?? [];
    return parentRecords
      .map((r) => r.values[1] ?? "")
      .filter((v) => v.trim() !== "")
      .map((v) => v.trim());
  }, [hasParents, parentsQuery.data]);

  /* the owner-configured invoice prefix (invoices module only) */
  const siteQuery = useQuery({
    queryKey: ["site", instance.id],
    queryFn: () => fetchSite(instance.id),
    enabled: open && effectiveModuleId === "invoices",
    staleTime: 60_000,
    retry: 0,
  });
  const invoicePrefix = siteQuery.data?.content.invoicePrefix || DEFAULT_INVOICE_PREFIX;

  /* the auto code: continues from every existing code (demo seeds are not
   * visible here — the suggestion derives from the tenant's OWN real rows) */
  const suggestedCode = useMemo(() => {
    if (!effectiveModuleId || idColIndex < 0) return null;
    const prefix = effectiveModuleId === "invoices" ? invoicePrefix : codePrefixFor(effectiveModuleId);
    const codes = records
      .map((r) => r.values[idColIndex])
      .filter((c): c is string => !!c);
    return nextRecordCode(prefix, codes, { invoice: effectiveModuleId === "invoices" });
  }, [effectiveModuleId, idColIndex, records, invoicePrefix]);

  /* the derived form: a FRESH state whenever the module (or its code
   * suggestion) changed — computed inline, never via effect. The setters
   * below COMMIT the derived default into real state on first interaction
   * (write-through), so the module switch resets without effects. */
  const initialForModule = useMemo(
    () => cols.map((_c, i) => (i === idColIndex && suggestedCode ? suggestedCode : "")),
    [cols, idColIndex, suggestedCode]
  );
  const formStateMatches =
    formState.moduleId === effectiveModuleId && formState.values.length === cols.length;
  const form = formStateMatches
    ? formState
    : { moduleId: effectiveModuleId, values: initialForModule, statusKey: "", saved: false };
  const values = form.values;
  const statusKey = form.statusKey;
  const saved = form.saved;

  const setValue = (i: number, v: string) =>
    setFormState((prev) => {
      const base =
        prev.moduleId === effectiveModuleId && prev.values.length === cols.length
          ? prev
          : { moduleId: effectiveModuleId, values: initialForModule, statusKey: "", saved: false };
      return { ...base, values: base.values.map((p, pi) => (pi === i ? v : p)) };
    });
  const setStatusKey = (v: string) =>
    setFormState((prev) => {
      const base =
        prev.moduleId === effectiveModuleId && prev.values.length === cols.length
          ? prev
          : { moduleId: effectiveModuleId, values: initialForModule, statusKey: "", saved: false };
      return { ...base, statusKey: v };
    });
  const markSaved = () =>
    setFormState((prev) => {
      const base =
        prev.moduleId === effectiveModuleId && prev.values.length === cols.length
          ? prev
          : { moduleId: effectiveModuleId, values: initialForModule, statusKey: "", saved: false };
      return { ...base, saved: true };
    });

  const system = SYSTEM_MAP[instance.systemId];
  /* ROUND 143 — the shell-wide effective accent (owner theme > category). */
  const { c1, c2 } = useAccentPair();
  const mod = moduleId ? MODULE_MAP[moduleId] : undefined;
  const moduleName = effectiveModuleId ? moduleDisplayName(effectiveModuleId, instance.systemId, lang) : "";
  const systemName = system ? (lang === "ar" ? system.nameAr : system.nameEn) : instance.systemId;
  const currency = instance.org.currency;

  /* ROUND 133 — نظام الورديات: every module-record create is a business
   * mutation the server refuses with 403 SHIFT_REQUIRED while no shift is
   * open. The save path gates on the shared ["shifts", id] cache entry —
   * nothing is disabled visually (the bar carries the state), the gate
   * fires at submit.
   * ROUND 134 — module OFF → no gate (mirrors the suspended server law). */
  const shiftsEnabled = instance.modules.includes("shifts");
  const shiftQuery = useShift(instance.id, shiftsEnabled);

  const canSave = !saved && values.some((v) => v.trim() !== "");

  const save = useMutation({
    mutationFn: () =>
      createModuleRecord(instance.id, {
        moduleId: effectiveModuleId,
        values: values.map((v, i) => (i === statusIndex ? statusKey : v)),
        statusKey,
      }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["module-records", instance.id, effectiveModuleId] });
      markSaved();
      toast.success(t("qaSavedToast", { module: moduleName }));
    },
    onError: (e: Error) => {
      if (e instanceof ApiError && e.status === 409) {
        void queryClient.invalidateQueries({ queryKey: ["module-records", instance.id, effectiveModuleId] });
      }
      /* ROUND 133 — the server-side shift gate: the record was refused with
         403 SHIFT_REQUIRED (a race the submit gate missed). Resync the shift
         cache so the global bar flips, keep the typed form intact. */
      if (
        e instanceof ApiError &&
        e.status === 403 &&
        (e.code === "SHIFT_REQUIRED" || e.message.includes("SHIFT_REQUIRED"))
      ) {
        void queryClient.invalidateQueries({ queryKey: ["shifts", instance.id] });
        toast.error(t("shiftGatedTrySave"));
        return;
      }
      toast.error(e.message || t("modRecSaveErr"));
    },
  });

  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!canSave) return;
    /* ROUND 133 — the client-side shift gate: abort the save (and close,
       resetting the form) when the workspace has no open shift.
       ROUND 134 — only while the الورديات module is enabled. */
    if (shiftsEnabled && shiftQuery.data?.current == null) {
      toast.error(t("shiftGatedToast"));
      handleOpenChange(false);
      return;
    }
    save.mutate();
  };

  const openModule = () => {
    setActiveModuleId(effectiveModuleId);
    setDashView("module");
    onOpenChange(false);
  };

  /* fresh form for another record of the SAME module */
  const resetForAnother = () => {
    setFormState({
      moduleId: effectiveModuleId,
      values: cols.map((_c, i) => (i === idColIndex && suggestedCode ? suggestedCode : "")),
      statusKey: "",
      saved: false,
    });
  };

  /* closing resets the selection so the NEXT open re-derives smart defaults */
  const handleOpenChange = (o: boolean) => {
    if (!o) {
      setModuleId("");
      setFormState({ moduleId: "", values: [], statusKey: "", saved: false });
    }
    onOpenChange(o);
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent
        dir={lang === "ar" ? "rtl" : "ltr"}
        className="max-h-[88vh] gap-0 overflow-y-auto rounded-3xl p-0 sm:max-w-xl nice-scroll"
      >
        {/* header */}
        <DialogHeader className="border-b border-slate-200/70 bg-slate-50/70 px-5 pb-4 pt-5 dark:border-white/10 dark:bg-white/[0.03] sm:px-6">
          <DialogTitle className="flex items-center gap-2.5 text-start font-display text-[16px] font-extrabold text-slate-900 dark:text-white">
            <span
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg"
              style={{ backgroundImage: grad(c1, c2), boxShadow: `0 10px 24px -10px ${hexAlpha(c1, 0.8)}` }}
              aria-hidden="true"
            >
              <CatIcon name="zap" className="h-4 w-4" />
            </span>
            {t("qaTitle")}
          </DialogTitle>
          <DialogDescription className="mt-1 text-start text-[12px] leading-relaxed text-slate-500 dark:text-slate-400">
            {t("qaDesc", { system: systemName })}
          </DialogDescription>

          {/* module picker — the system's enabled modules (sector labels) */}
          <div className="mt-3.5">
            <p className="text-[10.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
              {t("qaModuleLabel")}
            </p>
            <div
              className="nice-scroll mt-2 flex max-h-28 flex-wrap gap-1.5 overflow-y-auto"
              role="radiogroup"
              aria-label={t("qaModuleLabel")}
            >
              {modules.map((m) => {
                const active = effectiveModuleId === m;
                const icon = MODULE_MAP[m]?.icon ?? "cubes";
                return (
                  <button
                    key={m}
                    type="button"
                    role="radio"
                    aria-checked={active}
                    onClick={() => setModuleId(m)}
                    className={cn(
                      "inline-flex h-8 items-center gap-1.5 rounded-xl px-3 text-[11px] font-extrabold transition active:scale-95",
                      active
                        ? "text-white shadow-lg"
                        : "border border-slate-200 bg-white/70 text-slate-500 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:text-brand-300"
                    )}
                    style={active ? { backgroundImage: grad(c1, c2) } : undefined}
                  >
                    <CatIcon name={icon} className="h-3 w-3" />
                    <span className="max-w-36 truncate">{moduleDisplayName(m, instance.systemId, lang)}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </DialogHeader>

        {/* body */}
        <div className="px-5 py-5 sm:px-6">
          {saved ? (
            /* ---------------- success state ---------------- */
            <div className="py-6 text-center">
              <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl border border-emerald-300/60 bg-emerald-500/10 text-emerald-500 dark:border-emerald-500/30 dark:bg-emerald-500/15 dark:text-emerald-400">
                <CatIcon name="circle-check" className="h-8 w-8" />
              </div>
              <h3 className="mt-4 font-display text-[16px] font-extrabold text-slate-900 dark:text-white">
                {t("qaSavedTitle", { module: moduleName })}
              </h3>
              <p className="mx-auto mt-1.5 max-w-[38ch] text-[12.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                {t("qaSavedDesc")}
              </p>
              <div className="mt-5 flex flex-wrap items-center justify-center gap-2.5">
                <Button
                  type="button"
                  onClick={resetForAnother}
                  className="h-10 gap-2 rounded-xl border border-brand-300/70 bg-brand-500/[0.07] px-4 text-[12.5px] font-extrabold text-brand-600 transition hover:bg-brand-500/15 active:scale-95 dark:border-brand-500/40 dark:bg-brand-500/10 dark:text-brand-300 dark:hover:bg-brand-500/20"
                >
                  <CatIcon name="plus" className="h-4 w-4" />
                  {t("qaAddAnother")}
                </Button>
                <Button
                  type="button"
                  onClick={openModule}
                  className="h-10 gap-2 rounded-xl px-4 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95"
                  style={{ backgroundImage: grad(c1, c2) }}
                >
                  <CatIcon name="arrow-right" className="h-4 w-4 rtl:rotate-180" />
                  {t("qaOpenModule")}
                </Button>
              </div>
            </div>
          ) : (
            /* ---------------- the form ---------------- */
            <form onSubmit={submit} className="space-y-4">
              {/* current module identity strip */}
              <div className="flex items-center gap-3 rounded-2xl border border-slate-200/80 bg-white/70 px-3.5 py-2.5 dark:border-white/[0.07] dark:bg-white/[0.03]">
                <span
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
                  style={{ backgroundImage: grad(c1, c2) }}
                  aria-hidden="true"
                >
                  <CatIcon name={mod?.icon ?? "cubes"} className="h-4 w-4" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                    {moduleName}
                  </p>
                  <p className="truncate text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                    {systemName} · {fmtNum(modules.length, lang)} {t("selectModulesChip", { count: modules.length })}
                  </p>
                </div>
                {suggestedCode ? (
                  <span className="shrink-0 rounded-full border border-brand-300/70 bg-brand-500/10 px-2.5 py-1 font-mono text-[10.5px] font-extrabold text-brand-600 dark:border-brand-500/40 dark:bg-brand-500/15 dark:text-brand-300" dir="ltr">
                    {suggestedCode}
                  </span>
                ) : null}
              </div>

              {/* the module's REAL fields */}
              <div className="grid gap-3 sm:grid-cols-2">
                {cols.map((col, i) => {
                  if (col.kind === "status") {
                    if (statuses.length === 0) return null;
                    return (
                      <div key={col.key} className="space-y-1.5 sm:col-span-2">
                        <Label
                          htmlFor={`qa-${col.key}`}
                          className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
                        >
                          <CatIcon name="badge-check" className="h-3 w-3 text-slate-400" aria-hidden="true" />
                          {lang === "ar" ? col.ar : col.en}
                        </Label>
                        <Select
                          value={statusKey === "" ? "__none__" : statusKey}
                          onValueChange={(v) => setStatusKey(v === "__none__" ? "" : v)}
                        >
                          <SelectTrigger id={`qa-${col.key}`} className="h-10 rounded-xl text-[12.5px] font-semibold">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="__none__">
                              <span className="flex items-center gap-2 text-slate-400">
                                <span className="h-2 w-2 rounded-full bg-slate-300 dark:bg-slate-600" aria-hidden="true" />
                                {t("modRecStatusNone")}
                              </span>
                            </SelectItem>
                            {statuses.map((s) => (
                              <SelectItem key={s.key} value={s.key}>
                                <span className="flex items-center gap-2">
                                  <span className={cn("h-2 w-2 rounded-full", TONE_DOT[s.tone])} aria-hidden="true" />
                                  {lang === "ar" ? s.ar : s.en}
                                </span>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    );
                  }
                  const numeric = col.kind === "num" || col.kind === "money";
                  const isIdCol = col.kind === "id";
                  const isDateCol = col.kind === "date";
                  const isCollegeCol = col.key === "college" && hasColleges && collegeOptions.length > 0;
                  const isGuardianCol = (col.key === "guardian" || col.key === "parent") && hasParents;

                  /* ID fields: auto-generated, read-only, locked. The code is
                   * always LTR (reads STU-00008801 left-to-right), but aligned
                   * to the FAR RIGHT (text-end) so in Arabic the code sits at
                   * the right edge of the input — matching the RTL reading
                   * flow where the label is also on the right. */
                  if (isIdCol) {
                    return (
                      <div key={col.key} className="space-y-1.5">
                        <Label
                          htmlFor={`qa-${col.key}`}
                          className="flex flex-wrap items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
                        >
                          {lang === "ar" ? col.ar : col.en}
                          <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-1.5 py-px text-[10px] font-extrabold text-slate-500 dark:bg-white/10 dark:text-slate-400">
                            <CatIcon name="lock" className="h-2.5 w-2.5" aria-hidden="true" />
                            {t("bizAutoLocked")}
                          </span>
                        </Label>
                        <Input
                          id={`qa-${col.key}`}
                          type="text"
                          value={values[i] ?? suggestedCode ?? ""}
                          readOnly
                          tabIndex={-1}
                          dir="ltr"
                          aria-readonly="true"
                          className={cn(
                            "h-10 rounded-xl text-[12.5px] font-mono font-bold bg-slate-50 text-slate-500 cursor-not-allowed pointer-events-none select-none dark:bg-white/[0.04] dark:text-slate-400 " + (lang === "ar" ? "text-end" : "text-start")
                          )}
                        />
                        <p className="flex items-center gap-1 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                          <CatIcon name="sparkles" className="h-3 w-3 shrink-0" />
                          {t("recCodeHint")}
                        </p>
                      </div>
                    );
                  }

                  /* College field: dynamic Select populated from the tenant's
                   * `colleges` module records. Only rendered when the system
                   * has the `colleges` module and records exist. */
                  if (isCollegeCol) {
                    return (
                      <div key={col.key} className="space-y-1.5">
                        <Label
                          htmlFor={`qa-${col.key}`}
                          className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
                        >
                          <CatIcon name="building" className="h-3 w-3 text-slate-400" aria-hidden="true" />
                          {lang === "ar" ? col.ar : col.en}
                          <span className="text-rose-500">*</span>
                        </Label>
                        <Select
                          value={values[i] ?? ""}
                          onValueChange={(v) => setValue(i, v)}
                        >
                          <SelectTrigger id={`qa-${col.key}`} className="h-10 rounded-xl text-[12.5px] font-semibold">
                            <SelectValue placeholder={lang === "ar" ? "اختر الكلية" : "Select college"} />
                          </SelectTrigger>
                          <SelectContent>
                            {collegeOptions.map((name) => (
                              <SelectItem key={name} value={name}>
                                {name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    );
                  }

                  /* Guardian / Parent field: searchable combobox. The owner
                   * can TYPE a new name OR select an existing parent from the
                   * `parents` module records via a Command-based dropdown. */
                  if (isGuardianCol) {
                    const currentValue = values[i] ?? "";
                    return (
                      <GuardianCombobox
                        key={col.key}
                        id={`qa-${col.key}`}
                        label={lang === "ar" ? col.ar : col.en}
                        value={currentValue}
                        onChange={(v) => setValue(i, v)}
                        options={parentOptions}
                        lang={lang}
                        placeholder={lang === "ar" ? "ابحث أو أضف ولي أمر..." : "Search or add guardian..."}
                      />
                    );
                  }

                  /* ROUND 149 (TASK F) — date fields now ride the premium
                   * PremiumDateInput component: a brand-colored calendar
                   * button opens the native picker, an X clears the value,
                   * and an Arabic-formatted hint (Gregorian calendar +
                   * Arabic month names + Arabic-Indic digits) renders under
                   * the input. Replaces the manual inline rendering. */
                  if (isDateCol) {
                    return (
                      <PremiumDateInput
                        key={col.key}
                        id={`qa-${col.key}`}
                        value={values[i] ?? ""}
                        onChange={(e) => setValue(i, e.target.value)}
                        label={
                          <>
                            <CatIcon name="calendar" className="h-3 w-3 text-slate-400" aria-hidden="true" />
                            {lang === "ar" ? col.ar : col.en}
                          </>
                        }
                      />
                    );
                  }

                  /* default: text / number / money fields */
                  return (
                    <div key={col.key} className="space-y-1.5">
                      <Label
                        htmlFor={`qa-${col.key}`}
                        className="flex flex-wrap items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
                      >
                        {lang === "ar" ? col.ar : col.en}
                        {col.kind === "money" ? (
                          <span
                            dir="ltr"
                            className="rounded-full bg-slate-100 px-1.5 py-px text-[11px] font-bold text-slate-500 dark:bg-white/10 dark:text-slate-400"
                          >
                            {currency}
                          </span>
                        ) : null}
                      </Label>
                      <Input
                        id={`qa-${col.key}`}
                        type={numeric ? "number" : "text"}
                        step={col.kind === "money" ? "0.01" : col.kind === "num" ? "1" : undefined}
                        min={numeric ? 0 : undefined}
                        value={values[i] ?? ""}
                        onChange={(e) => setValue(i, e.target.value)}
                        dir={numeric ? "ltr" : undefined}
                        placeholder={numeric ? "0" : ""}
                        className={cn(
                          "h-10 rounded-xl text-[12.5px] font-semibold",
                          numeric && "text-end"
                        )}
                      />
                    </div>
                  );
                })}
              </div>

              <DialogFooter className="gap-2 border-t border-slate-200/70 pt-4 dark:border-white/[0.07]">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => onOpenChange(false)}
                  disabled={save.isPending}
                  className="h-10 rounded-xl border-slate-200 bg-white px-5 text-[12.5px] font-bold text-slate-700 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200"
                >
                  {t("modRecCancelBtn")}
                </Button>
                <Button
                  type="submit"
                  disabled={!canSave || save.isPending}
                  className="h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:opacity-60"
                  style={{ backgroundImage: grad(c1, c2) }}
                >
                  {save.isPending ? (
                    <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                  ) : (
                    <CatIcon name="check" className="h-4 w-4" />
                  )}
                  {t("qaSaveBtn")}
                </Button>
              </DialogFooter>
            </form>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}



/* ------------------------------------------------------------------ */
/* GuardianCombobox — searchable parent/guardian selector.            */
/* Allows typing a NEW name or picking an existing parent from the    */
/* tenant's `parents` module records via a cmdk-based dropdown.       */
/* ------------------------------------------------------------------ */
function GuardianCombobox({
  id,
  label,
  value,
  onChange,
  options,
  lang,
  placeholder,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: string[];
  lang: string;
  placeholder: string;
}) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return options;
    return options.filter((o) => o.toLowerCase().includes(q));
  }, [options, search]);

  const showAddNew = search.trim() !== "" && !options.some((o) => o.toLowerCase() === search.trim().toLowerCase());

  return (
    <div className="space-y-1.5">
      <Label htmlFor={id} className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
        <CatIcon name="users" className="h-3 w-3 text-slate-400" aria-hidden="true" />
        {label}
      </Label>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <div className="relative">
            <Input
              id={id}
              type="text"
              value={value || search}
              onChange={(e) => {
                setSearch(e.target.value);
                onChange(e.target.value);
                if (!open) setOpen(true);
              }}
              onFocus={() => setOpen(true)}
              placeholder={placeholder}
              className="h-10 rounded-xl text-[12.5px] font-semibold pe-8"
              role="combobox"
              aria-expanded={open}
              aria-autocomplete="list"
            />
            <button
              type="button"
              tabIndex={-1}
              onClick={() => setOpen((o) => !o)}
              className="absolute inset-y-0 end-0 me-2.5 grid h-7 w-7 place-items-center rounded-lg text-slate-400"
              aria-label={lang === "ar" ? "عرض القائمة" : "Show list"}
            >
              <CatIcon name={open ? "chevron-up" : "chevron-down"} className="h-3.5 w-3.5" />
            </button>
          </div>
        </PopoverTrigger>
        <PopoverContent
          className="max-h-64 w-[--radix-popover-trigger-width] overflow-y-auto p-0 nice-scroll"
          align="start"
          onOpenAutoFocus={(e) => e.preventDefault()}
        >
          <CommandPrimitive
            filter={() => 1}
            className="rounded-xl"
          >
            <div className="p-1">
              {filtered.length === 0 && !showAddNew ? (
                <p className="px-3 py-6 text-center text-[11.5px] font-semibold text-slate-400">
                  {lang === "ar" ? "لا توجد نتائج" : "No results"}
                </p>
              ) : null}
              {filtered.map((name) => (
                <button
                  key={name}
                  type="button"
                  onClick={() => {
                    onChange(name);
                    setSearch("");
                    setOpen(false);
                  }}
                  className={cn(
                    "flex w-full items-center gap-2 rounded-lg px-3 py-2 text-start text-[12px] font-semibold transition hover:bg-slate-100 dark:hover:bg-white/[0.06]",
                    value === name && "bg-brand-500/10 text-brand-600 dark:bg-brand-500/15 dark:text-brand-300"
                  )}
                >
                  <CatIcon name="user" className="h-3.5 w-3.5 shrink-0 text-slate-400" aria-hidden="true" />
                  <span className="truncate">{name}</span>
                  {value === name ? <CatIcon name="check" className="ms-auto h-3.5 w-3.5 text-brand-500" aria-hidden="true" /> : null}
                </button>
              ))}
              {showAddNew ? (
                <button
                  type="button"
                  onClick={() => {
                    onChange(search.trim());
                    setSearch("");
                    setOpen(false);
                  }}
                  className="flex w-full items-center gap-2 rounded-lg border-t border-slate-100 px-3 py-2 text-start text-[12px] font-extrabold text-brand-600 transition hover:bg-brand-500/10 dark:border-white/[0.06] dark:text-brand-300 dark:hover:bg-brand-500/15"
                >
                  <CatIcon name="plus-circle" className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                  <span>
                    {lang === "ar" ? "إضافة " : "Add "}
                    &ldquo;{search.trim()}&rdquo;
                  </span>
                </button>
              ) : null}
            </div>
          </CommandPrimitive>
        </PopoverContent>
      </Popover>
    </div>
  );
}

export default QuickAddDialog;
