"use client";

/**
 * ROUND 68 — the UNIFIED avatar picker (owner's code, promoted to a shared
 * platform primitive).
 *
 * The exact pipeline profile-dialog.tsx (مٍلاك النظام / workspace owner)
 * has used since ROUND 64, extracted verbatim into one component so the
 * owner avatar, every team member (فريق الإدارة) avatar — add-member,
 * profile dialog and roster — and any future surface share ONE code path:
 *
 *   pick → 25MB cap → type allowlist → FileReader decode probe →
 *   AvatarCropperDialog (drag / pinch / rotate → 288px JPEG ≈≤120KB) →
 *   onPick(dataUrl)
 *
 * The component owns ONLY the picking + cropping interaction; persistence
 * (PATCH instance / PATCH member / local dialog state) stays with the
 * parent through `onPick` / `onRemove` — the same contract the owner
 * dialog already had.
 */
import { useRef, useState } from "react";
import { toast } from "sonner";
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { cn, grad, initial } from "@/lib/utils";
import { AvatarCropperDialog } from "@/components/admin/avatar-cropper";

const SIZES = {
  sm: { tile: "h-11 w-11 text-[14px]", badge: "h-6 w-6", icon: "h-[11px] w-[11px]", inset: "-bottom-1 -end-1" },
  md: { tile: "h-12 w-12 text-[19px]", badge: "h-7 w-7", icon: "h-[13px] w-[13px]", inset: "-bottom-1 -end-1.5" },
  lg: { tile: "h-20 w-20 text-[26px]", badge: "h-8 w-8", icon: "h-[14px] w-[14px]", inset: "-bottom-1 -end-1" },
} as const;

export function AvatarPicker({
  avatarUrl,
  name,
  c1,
  c2,
  onPick,
  onRemove,
  size = "md",
  disabled = false,
  ring = true,
  className,
  ariaLabel,
}: {
  /** current avatar (data-URL; "" / null = gradient initials) */
  avatarUrl: string | null;
  /** display name — drives the initials fallback */
  name: string;
  /** gradient colors for the tile + initials fallback */
  c1: string;
  c2: string;
  /** crop-applied data-URL — the parent persists it (server PATCH or local state) */
  onPick: (dataUrl: string) => void;
  /** remove affordance (only rendered when a photo exists AND provided) */
  onRemove?: () => void;
  size?: keyof typeof SIZES;
  disabled?: boolean;
  /** gradient ring around the tile (owner/brand style) */
  ring?: boolean;
  className?: string;
  /** explicit a11y label for the camera badge (defaults to i18n key) */
  ariaLabel?: string;
}) {
  const { t } = useT();
  const inputRef = useRef<HTMLInputElement>(null);
  const [cropSrc, setCropSrc] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const s = SIZES[size];
  const photo = avatarUrl && avatarUrl.length > 0 ? avatarUrl : null;

  /* the owner dialog's acceptance pipeline, byte-for-byte: 25MB cap,
     type allowlist, FileReader decode probe → shared cropper */
  const onFile = async (file: File | undefined | null) => {
    if (!file) return;
    if (file.size > 25 * 1024 * 1024) {
      toast.error(t("cropTooLarge"));
      return;
    }
    if (!/^image\/(png|jpe?g|webp|gif)$/.test(file.type)) {
      toast.error(t("siteLogoBadType"));
      return;
    }
    setBusy(true);
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(new Error("read"));
        reader.readAsDataURL(file);
      });
      const probe = new Image();
      const decodable = await new Promise<boolean>((resolve) => {
        probe.onload = () => resolve(probe.naturalWidth > 0 && probe.naturalHeight > 0);
        probe.onerror = () => resolve(false);
        probe.src = dataUrl;
      });
      if (!decodable) {
        toast.error(t("siteLogoCorrupt"));
        return;
      }
      setCropSrc(dataUrl);
    } catch {
      toast.error(t("siteLogoCorrupt"));
    } finally {
      setBusy(false);
    }
  };

  return (
    <span className={cn("relative inline-block shrink-0", className)}>
      {ring ? (
        <span
          aria-hidden="true"
          className="block rounded-[999px] p-[2px]"
          style={{ backgroundImage: grad(c1, c2) }}
        >
          {photo ? (
            // eslint-disable-next-line @next/next/no-img-element -- sealed data-URL avatar produced by the shared cropper; next/image optimization does not apply
            <img
              src={photo}
              alt=""
              className={cn(s.tile, "rounded-full object-cover")}
            />
          ) : (
            <span
              className={cn(
                s.tile,
                "grid place-items-center rounded-full font-extrabold text-white shadow-md shadow-slate-900/15 dark:shadow-black/30"
              )}
              style={{ backgroundImage: grad(c1, c2) }}
            >
              {initial(name)}
            </span>
          )}
        </span>
      ) : photo ? (
        // eslint-disable-next-line @next/next/no-img-element -- sealed data-URL avatar produced by the shared cropper; next/image optimization does not apply
        <img src={photo} alt="" className={cn(s.tile, "rounded-full object-cover")} />
      ) : (
        <span
          aria-hidden="true"
          className={cn(
            s.tile,
            "grid place-items-center rounded-full font-extrabold text-white shadow-md shadow-slate-900/15 dark:shadow-black/30"
          )}
          style={{ backgroundImage: grad(c1, c2) }}
        >
          {initial(name)}
        </span>
      )}

      {/* WhatsApp-style camera badge */}
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        disabled={disabled || busy}
        aria-label={ariaLabel ?? t("profilePhotoChange")}
        title={ariaLabel ?? t("profilePhotoChange")}
        className={cn(
          s.inset,
          s.badge,
          "absolute grid place-items-center rounded-full border border-slate-200 bg-white text-slate-600 shadow-md transition hover:border-brand-300 hover:text-brand-600 active:scale-90 disabled:opacity-50 dark:border-white/20 dark:bg-[#0b1220] dark:text-slate-300 dark:hover:border-brand-500/50 dark:hover:text-brand-300"
        )}
      >
        <CatIcon name="camera" className={s.icon} />
      </button>

      {/* quiet remove chip (only when a photo exists and a remover is wired) */}
      {photo && onRemove ? (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
          disabled={disabled || busy}
          aria-label={t("profilePhotoRemove")}
          title={t("profilePhotoRemove")}
          className="absolute -start-1 top-0 grid h-6 w-6 place-items-center rounded-full border border-rose-200 bg-white text-rose-500 shadow-md transition hover:border-rose-300 hover:bg-rose-50 active:scale-90 disabled:opacity-50 dark:border-rose-500/30 dark:bg-[#0b1220] dark:text-rose-400 dark:hover:border-rose-500/50"
        >
          <CatIcon name="trash-2" className="h-[10px] w-[10px]" />
        </button>
      ) : null}

      <input
        ref={inputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp,image/gif"
        className="hidden"
        onChange={(e) => {
          void onFile(e.target.files?.[0]);
          /* allow re-picking the same file after cancel/crop */
          e.target.value = "";
        }}
      />

      {/* the shared premium cropper dialog (identical to the owner flow) */}
      <AvatarCropperDialog
        open={cropSrc !== null}
        src={cropSrc}
        onClose={() => setCropSrc(null)}
        onApply={(result) => {
          setCropSrc(null);
          onPick(result.dataUrl);
        }}
      />
    </span>
  );
}
