"use client";

/**
 * Ashrilogic — ROUND 133 (نظام الورديات): the shift DIALOGS.
 * ROUND 134-A — إغلاق الوردية الذكي: ShiftCloseDialog became a
 * calculator-grade reconciliation (currency-aware cash denomination
 * counter + a real numeric keypad + a live math readout + variance
 * forensics), and ShiftHistoryDialog became the premium shifts browser
 * (stats band + pinned live current-shift card + empty-state tile).
 * ROUND 144 — الرمز المتقدم: the PIN is 4-8 digits with a REMEMBERED
 * length (ShiftsResponseDTO.codeLen): ShiftCodeDialog gains the premium
 * length selector (segmented 4/5/6/7/8 pills that live-resize BOTH code
 * PinInputs to exactly N cells and ride to the server as `length`), and
 * every PIN ENTRY surface renders EXACTLY codeLen cells with the
 * contextual pinEnterN hint.
 *
 * Four premium surfaces sharing one file + one react-query cache entry
 * (["shifts", instanceId] via useShift):
 *
 *   • ShiftOpenDialog    — the Argon2id-gated opening (secret code + float);
 *   • ShiftCloseDialog   — the SMART drawer reconciliation: denomination
 *                          ladder drives the counted cash, a keypad +
 *                          quick-adjust chips override it manually
 *                          (latest-edited wins), the live math strip shows
 *                          opening + cash = expected → collected → variance;
 *   • ShiftCodeDialog    — define/change the owner's secret shift code
 *                          (workspace password as identity proof) with the
 *                          ROUND 144 PIN-length selector;
 *   • ShiftHistoryDialog — the full shifts browser: header stats band,
 *                          the pinned live current shift, then the last
 *                          20 closed shifts with variance tones.
 *
 * Server semantics (handled by status): POST /shifts → 401 wrong code,
 * 428 code not set (auto-chains into ShiftCodeDialog), 409 already open;
 * POST /shifts/close → 409 no open shift; PUT /shifts/code → 401 wrong
 * workspace password. Money is DISPLAY UNITS (the DTO already converted).
 */
import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { useT } from "@/lib/i18n";
import type { InstanceDTO, Lang, ShiftDTO } from "@/lib/types";
import { ApiError, closeShift, openShift, setShiftCode } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, fmtId, fmtMoneyCell, fmtNum, grad, hexAlpha, idDir, numDir } from "@/lib/utils";
import { fullDate } from "@/components/dashboard/dash-shared";
import {
  shiftElapsedLabel,
  useShift,
} from "@/components/dashboard/shift/use-shift";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { PinInput } from "@/components/ui/pin-input";
import { Label } from "@/components/ui/label";

/* ------------------------------------------------------------------ */
/* Shared bits                                                         */
/* ------------------------------------------------------------------ */

interface DialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  instance: InstanceDTO;
}

/** The premium gradient header shared by all four dialogs. */
function ShiftHeader({
  icon,
  c1,
  c2,
  title,
  desc,
}: {
  icon: string;
  c1: string;
  c2: string;
  title: string;
  desc?: string;
}) {
  return (
    <div
      className="relative flex shrink-0 items-center gap-3.5 overflow-hidden border-b border-slate-200/70 px-5 py-4 dark:border-white/10"
      style={{ backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.16)}, ${hexAlpha(c2, 0.16)})` }}
    >
      <span
        className="absolute -end-8 -top-14 h-28 w-28 rounded-full"
        style={{ background: `radial-gradient(circle, ${hexAlpha(c1, 0.3)}, transparent 70%)` }}
        aria-hidden="true"
      />
      <span
        className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
        style={{ backgroundImage: grad(c1, c2) }}
        aria-hidden="true"
      >
        <CatIcon name={icon} className="h-5 w-5" />
      </span>
      <div className="min-w-0 flex-1">
        <DialogTitle className="truncate font-display text-[15px] font-extrabold leading-tight text-slate-900 dark:text-white">
          {title}
        </DialogTitle>
        {desc ? (
          <DialogDescription className="mt-0.5 text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
            {desc}
          </DialogDescription>
        ) : null}
      </div>
    </div>
  );
}

/** Read-only summary mini-card (the close dialog's numbers strip). */
function StatCard({
  icon,
  label,
  value,
  dir,
}: {
  icon: string;
  label: string;
  value: string;
  dir: "rtl" | "ltr";
}) {
  return (
    <div className="min-w-0 rounded-xl border border-slate-200/80 bg-white/70 px-3 py-2 dark:border-white/10 dark:bg-white/[0.04]">
      <p className="flex items-center gap-1 text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
        <CatIcon name={icon} className="h-2.5 w-2.5 shrink-0" aria-hidden="true" />
        <span className="min-w-0 truncate">{label}</span>
      </p>
      <p dir={dir} className="mt-0.5 truncate text-[13px] font-extrabold tabular-nums text-slate-800 dark:text-slate-100">
        {value}
      </p>
    </div>
  );
}

/** Variance pill — emerald when the drawer balances, amber over, rose short. */
function VariancePill({
  variance,
  lang,
  currency,
}: {
  variance: number | null;
  lang: Lang;
  currency: string;
}) {
  const { t } = useT();
  if (variance == null || !Number.isFinite(variance)) return null;
  const v = Math.round(variance * 100) / 100;
  const amount = fmtMoneyCell(Math.abs(v), lang, currency);
  const tone =
    v === 0
      ? "border border-emerald-300/70 bg-emerald-500/10 text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/15 dark:text-emerald-300"
      : v > 0
        ? "border border-amber-300/70 bg-amber-500/10 text-amber-700 dark:border-amber-500/30 dark:bg-amber-500/15 dark:text-amber-300"
        : "border border-rose-300/70 bg-rose-500/10 text-rose-700 dark:border-rose-500/30 dark:bg-rose-500/15 dark:text-rose-300";
  return (
    <span dir={numDir(lang)} className={cn("inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10.5px] font-extrabold", tone)}>
      <CatIcon
        name={v === 0 ? "badge-check" : v > 0 ? "trending-up" : "trending-down"}
        className="h-3 w-3"
        aria-hidden="true"
      />
      {v === 0
        ? t("shiftVarianceOk")
        : v > 0
          ? `${t("shiftVarianceOver")} +${amount}`
          : `${t("shiftVarianceShort")} -${amount}`}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* ROUND 134-A — the smart calculator primitives                        */
/* ------------------------------------------------------------------ */

/** round to 2 decimals (display-unit money math everywhere). */
function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

/**
 * The currency-aware banknote/coin ladders for the العدّاد النقدي (cash
 * denomination counter). Keyed by the org's ISO currency code (upper-cased
 * by the lookup helper); unknown currencies fall back to the generic
 * ladder. Values are DISPLAY units.
 */
const DENOM_LADDERS: Record<string, number[]> = {
  SAR: [500, 100, 50, 20, 10, 5, 1, 0.5, 0.25],
  AED: [1000, 500, 200, 100, 50, 20, 10, 5, 1, 0.5, 0.25],
  USD: [100, 50, 20, 10, 5, 2, 1, 0.5, 0.25, 0.1, 0.05],
  EGP: [200, 100, 50, 20, 10, 5, 1, 0.25],
  KWD: [20, 10, 5, 1, 0.5, 0.25],
  OMR: [50, 20, 10, 5, 1, 0.5, 0.25, 0.1],
  BHD: [20, 10, 5, 1, 0.5, 0.25],
  QAR: [500, 100, 50, 20, 10, 5, 1, 0.5, 0.25],
  EUR: [500, 200, 100, 50, 20, 10, 5, 2, 1, 0.5, 0.2, 0.1, 0.05, 0.02, 0.01],
  GBP: [50, 20, 10, 5, 2, 1, 0.5, 0.2, 0.1, 0.05, 0.02, 0.01],
  TRY: [200, 100, 50, 20, 10, 5, 1, 0.5, 0.25, 0.1, 0.05],
  PKR: [5000, 1000, 500, 100, 50, 20, 10, 5],
  INR: [500, 200, 100, 50, 20, 10, 5, 2, 1],
};

/** generic ladder for currencies without a curated map. */
const DEFAULT_DENOMS: number[] = [100, 50, 20, 10, 5, 2, 1, 0.5, 0.25];

function ladderFor(currency: string | undefined): number[] {
  const key = (currency ?? "").trim().toUpperCase();
  return DENOM_LADDERS[key] ?? DEFAULT_DENOMS;
}

/**
 * The real numeric keypad (آلة حاسبة حقيقية) — 3 columns × 5 rows of
 * ≥44px touch targets: 0-9, 00, decimal separator, ⌫ backspace, C clear.
 * Digits always render LTR (canonical ASCII entry, the R133 policy); every
 * key carries a translated aria-label. The key token ("7", "00", ".",
 * "BS", "C") is interpreted by the owner's `onKey` handler.
 */
function CalcKeypad({ onKey }: { onKey: (key: string) => void }) {
  const { t } = useT();
  const keys: { key: string; label: string; aria: string; span?: string }[] = [
    { key: "7", label: "7", aria: t("shiftCalcDigit", { digit: 7 }) },
    { key: "8", label: "8", aria: t("shiftCalcDigit", { digit: 8 }) },
    { key: "9", label: "9", aria: t("shiftCalcDigit", { digit: 9 }) },
    { key: "4", label: "4", aria: t("shiftCalcDigit", { digit: 4 }) },
    { key: "5", label: "5", aria: t("shiftCalcDigit", { digit: 5 }) },
    { key: "6", label: "6", aria: t("shiftCalcDigit", { digit: 6 }) },
    { key: "1", label: "1", aria: t("shiftCalcDigit", { digit: 1 }) },
    { key: "2", label: "2", aria: t("shiftCalcDigit", { digit: 2 }) },
    { key: "3", label: "3", aria: t("shiftCalcDigit", { digit: 3 }) },
    { key: ".", label: ".", aria: t("shiftCalcDecimal") },
    { key: "0", label: "0", aria: t("shiftCalcDigit", { digit: 0 }) },
    { key: "00", label: "00", aria: t("shiftCalcDoubleZero") },
    { key: "BS", label: "⌫", aria: t("shiftCalcBackspace") },
    { key: "C", label: "C", aria: t("shiftCalcClear"), span: "col-span-2" },
  ];
  return (
    <div
      dir="ltr"
      role="group"
      aria-label={t("shiftCalcKeypad")}
      className="grid grid-cols-3 gap-1.5"
    >
      {keys.map((k) => (
        <button
          key={k.key}
          type="button"
          onClick={() => onKey(k.key)}
          aria-label={k.aria}
          className={cn(
            "h-11 min-w-11 rounded-xl border border-slate-200/90 bg-white/85 text-[15px] font-extrabold tabular-nums text-slate-700 shadow-xs transition hover:border-slate-300 hover:bg-slate-100 active:scale-95 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-200 dark:hover:border-white/20 dark:hover:bg-white/[0.1]",
            k.span
          )}
        >
          {k.label}
        </button>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* 1) OPEN — the secret-code + opening-float dialog                    */
/* ------------------------------------------------------------------ */

export function ShiftOpenDialog({ open, onOpenChange, instance }: DialogProps) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  /* ROUND 144 — the REMEMBERED PIN length (the shared ["shifts", id]
   * cache entry the dialogs already consume) drives EXACTLY codeLen
   * cells on this entry surface. */
  const { data: shiftData } = useShift(instance.id);
  const codeLen = shiftData?.codeLen ?? null;
  const codeMinLen = codeLen ?? 4;
  const [code, setCode] = useState("");
  const [openingCash, setOpeningCash] = useState("0");
  /* ROUND 141 (㉖) — the premium PIN error state (rose + shake, cleared
   * after the shake window so the next attempt starts clean). */
  const [pinError, setPinError] = useState(false);
  /* 428 SHIFT_CODE_NOT_SET chains straight into the code dialog */
  const [needCodeOpen, setNeedCodeOpen] = useState(false);

  const currency = instance.org.currency;
  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ["shifts", instance.id] });
  };

  const handleOpenChange = (o: boolean) => {
    if (!o) {
      setCode("");
      setOpeningCash("0");
      setPinError(false);
    }
    onOpenChange(o);
  };

  const openShiftMut = useMutation({
    mutationFn: () =>
      openShift(instance.id, {
        code: code.trim(),
        openingCash: Number(openingCash) || 0,
      }),
    onSuccess: () => {
      invalidate();
      toast.success(t("shiftBarOpen"));
      handleOpenChange(false);
    },
    onError: (e: Error) => {
      if (e instanceof ApiError) {
        if (e.status === 401) {
          /* wrong secret code — the premium PIN shakes rose, clears and
           * stays focused for the next attempt */
          toast.error(t("shiftOpenWrong"));
          setCode("");
          setPinError(true);
          window.setTimeout(() => setPinError(false), 650);
          return;
        }
        if (e.status === 428) {
          /* no code defined yet — resync the bar (codeSet flips false) and
             chain straight into the define-code dialog */
          invalidate();
          toast.error(t("shiftOpenNotSet"));
          handleOpenChange(false);
          setNeedCodeOpen(true);
          return;
        }
        if (e.status === 409) {
          toast.error(t("shiftOpenAlready"));
          invalidate();
          handleOpenChange(false);
          return;
        }
      }
      toast.error(e.message || t("errorText"));
    },
  });

  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (openShiftMut.isPending || code.length < codeMinLen) return;
    openShiftMut.mutate();
  };

  return (
    <>
      <Dialog open={open} onOpenChange={handleOpenChange}>
        <DialogContent
          dir={lang === "ar" ? "rtl" : "ltr"}
          className="flex max-h-[85vh] flex-col gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-md"
        >
          <ShiftHeader
            icon="unlock"
            c1="#10b981"
            c2="#059669"
            title={t("shiftOpenTitle")}
            desc={t("shiftOpenDesc")}
          />
          <form onSubmit={submit} noValidate className="flex min-h-0 flex-1 flex-col">
            <div className="nice-scroll min-h-0 flex-1 space-y-4 overflow-y-auto px-5 py-4">
              {/* ROUND 141 (㉖) — the secret code as the PREMIUM segmented
                  PIN: growing per-digit cells, masked dots + show/hide,
                  Arabic-Indic digits accepted, shake + rose on wrong code.
                  ROUND 144 — EXACTLY codeLen cells when the persisted
                  length is known (4..8 growing otherwise). */}
              <div className="space-y-1.5">
                <Label
                  className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
                >
                  <CatIcon name="key-round" className="h-3 w-3 text-emerald-500" aria-hidden="true" />
                  {t("shiftSecretCode")}
                </Label>
                <PinInput
                  value={code}
                  onChange={setCode}
                  error={pinError}
                  minLength={codeLen ?? 4}
                  maxLength={codeLen ?? 8}
                  onEnter={() => code.length >= codeMinLen && !openShiftMut.isPending && openShiftMut.mutate()}
                  label={t("shiftSecretCode")}
                />
                {codeLen ? (
                  <p className="flex items-center gap-1 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                    <CatIcon name="info" className="h-3 w-3 shrink-0" aria-hidden="true" />
                    {t("pinEnterN", { n: codeLen })}
                  </p>
                ) : null}
              </div>

              {/* the declared opening float */}
              <div className="space-y-1.5">
                <Label
                  htmlFor="shift-open-cash"
                  className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
                >
                  <CatIcon name="wallet" className="h-3 w-3 text-emerald-500" aria-hidden="true" />
                  {t("shiftOpeningCash")}
                  <span
                    dir="ltr"
                    className="rounded-full bg-slate-100 px-1.5 py-px text-[10.5px] font-bold text-slate-500 dark:bg-white/10 dark:text-slate-400"
                  >
                    {currency}
                  </span>
                </Label>
                <Input
                  id="shift-open-cash"
                  type="number"
                  min={0}
                  step="0.01"
                  inputMode="decimal"
                  value={openingCash}
                  onChange={(e) => setOpeningCash(e.target.value)}
                  dir="ltr"
                  placeholder="0"
                  className="h-11 rounded-xl text-end text-[13px] font-extrabold tabular-nums"
                />
              </div>
            </div>

            {/* footer */}
            <div className="flex shrink-0 items-center justify-end gap-2.5 border-t border-slate-200/70 px-5 py-3.5 dark:border-white/10">
              <Button
                type="button"
                variant="outline"
                onClick={() => handleOpenChange(false)}
                disabled={openShiftMut.isPending}
                className="h-10 rounded-xl px-4 text-[12.5px] font-bold hover:border-slate-300 hover:bg-slate-100 dark:hover:border-white/20 dark:hover:bg-white/5"
              >
                {t("modRecCancelBtn")}
              </Button>
              <Button
                type="submit"
                disabled={openShiftMut.isPending || code.length < codeMinLen}
                className="h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:opacity-60"
                style={{ backgroundImage: grad("#10b981", "#059669") }}
              >
                {openShiftMut.isPending ? (
                  <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                ) : (
                  <CatIcon name="unlock" className="h-4 w-4" />
                )}
                {t("shiftOpenAction")}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* 428 chain — define the secret code first, then come back */}
      <ShiftCodeDialog open={needCodeOpen} onOpenChange={setNeedCodeOpen} instance={instance} />
    </>
  );
}

/* ------------------------------------------------------------------ */
/* 2) CLOSE — the SMART calculator reconciliation (إغلاق الوردية الذكي) */
/* ------------------------------------------------------------------ */

export function ShiftCloseDialog({ open, onOpenChange, instance }: DialogProps) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const { data } = useShift(instance.id);
  const current = data?.current ?? null;
  const [counted, setCounted] = useState("");
  const [note, setNote] = useState("");
  /* ROUND 134-A — the calculator state: per-denomination counts (0..999
   * each, keyed by the ladder value) plus which entry surface drove the
   * counted value LAST. The ladder's grand total feeds the submitted
   * counted cash; a manual edit (typing / keypad / quick chips) takes
   * over — latest-edited wins, and the next ladder change wins it back. */
  const [counts, setCounts] = useState<Record<number, number>>({});
  const [source, setSource] = useState<"denom" | "manual">("denom");

  const currency = instance.org.currency;
  const agg = current?.aggregates;
  const ladder = useMemo(() => ladderFor(currency), [currency]);
  /* expected drawer = declared float + cash sales (display units; the
   * server recomputes and freezes the authoritative number at close) */
  const expected =
    current && agg ? Math.round((current.openingCash + agg.cashTotal) * 100) / 100 : null;
  const countedNum = counted.trim() === "" ? null : Number(counted);
  const variance =
    expected != null && countedNum != null && Number.isFinite(countedNum)
      ? Math.round((countedNum - expected) * 100) / 100
      : null;
  /* the denomination counter's live grand total (display units) */
  const denomTotal = round2(ladder.reduce((acc, d) => acc + (counts[d] ?? 0) * d, 0));
  /* variance percent — only meaningful against a non-empty expected drawer */
  const variancePct =
    variance != null && expected != null && expected > 0
      ? Math.round((variance / expected) * 1000) / 10
      : null;
  /* the counted-vs-expected fill ratio for the progress readout */
  const fillRatio =
    expected != null && expected > 0 && countedNum != null && Number.isFinite(countedNum)
      ? countedNum / expected
      : null;

  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ["shifts", instance.id] });
  };

  const handleOpenChange = (o: boolean) => {
    if (!o) {
      setCounted("");
      setNote("");
      setCounts({});
      setSource("denom");
    }
    onOpenChange(o);
  };

  /* ---- العدّاد النقدي — the denomination counter -------------------- */

  /** One ladder row changed → the merged counts drive the ladder's grand
   *  total AND the submitted counted value (the ladder wins the sync). */
  const setDenomCount = (value: number, next: number) => {
    const clamped = Math.min(999, Math.max(0, Math.round(next)));
    const merged = { ...counts, [value]: clamped };
    const total = round2(ladder.reduce((acc, d) => acc + (merged[d] ?? 0) * d, 0));
    setSource("denom");
    setCounts(merged);
    setCounted(String(total));
  };

  const resetDenoms = () => {
    setSource("denom");
    setCounts({});
    setCounted("0");
  };

  /* ---- the manual calculator surface (keypad / chips / typing) ------ */

  /** A keypad key — edits the counted entry buffer (manual wins the sync).
   *  Canonical ASCII entry per the R133 policy; integer digits capped. */
  const pressKey = (key: string) => {
    setSource("manual");
    setCounted((prev) => {
      if (key === "C") return "";
      if (key === "BS") return prev.slice(0, -1);
      if (key === ".") {
        if (prev.includes(".")) return prev;
        return prev === "" ? "0." : prev + ".";
      }
      const digits = prev.replace(/\D/g, "").length;
      if (key === "00") {
        if (prev === "" || prev === "0") return prev === "" ? "0" : prev;
        return digits >= 9 ? prev : prev + "00";
      }
      /* single digit */
      if (digits >= 10) return prev;
      if (prev === "0") return key;
      return prev + key;
    });
  };

  /** quick-adjust chips — ±delta in display units from the current value. */
  const adjustCounted = (delta: number) => {
    const next = Math.max(0, round2((countedNum ?? 0) + delta));
    setSource("manual");
    setCounted(String(next));
  };

  /** الضبط على المتوقع — snap the counted value onto the expected drawer. */
  const matchExpected = () => {
    if (expected == null) return;
    setSource("manual");
    setCounted(String(round2(expected)));
  };

  const close = useMutation({
    mutationFn: () =>
      closeShift(instance.id, {
        countedCash: countedNum as number,
        note: note.trim() === "" ? undefined : note.trim(),
      }),
    onSuccess: (res) => {
      invalidate();
      const v = Math.round((res.shift.variance ?? 0) * 100) / 100;
      const varianceText =
        v === 0
          ? t("shiftVarianceOk")
          : `${v > 0 ? t("shiftVarianceOver") : t("shiftVarianceShort")} ${
              v > 0 ? "+" : "-"
            }${fmtMoneyCell(Math.abs(v), lang, currency)}`;
      toast.success(`${t("shiftCloseTitle")} — ${varianceText}`);
      handleOpenChange(false);
    },
    onError: (e: Error) => {
      if (e instanceof ApiError && e.status === 409) {
        /* the shift vanished between open and confirm — resync + close */
        toast.error(t("shiftBarClosed"));
        invalidate();
        handleOpenChange(false);
        return;
      }
      toast.error(e.message || t("errorText"));
    },
  });

  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (close.isPending || !current || countedNum == null || !Number.isFinite(countedNum)) return;
    close.mutate();
  };

  const avgBasket =
    agg && agg.salesCount > 0 ? Math.round((agg.salesTotal / agg.salesCount) * 100) / 100 : 0;

  /* ---- القراءة الذكية — variance forensics chips -------------------- */
  const insights: { icon: string; text: string; tone: string }[] = [];
  if (variance != null && variance !== 0) {
    /* verdict: surplus vs shortage */
    insights.push(
      variance > 0
        ? {
            icon: "trending-up",
            text: t("shiftInsightOver"),
            tone: "border-amber-300/70 bg-amber-500/10 text-amber-700 dark:border-amber-500/30 dark:bg-amber-500/15 dark:text-amber-300",
          }
        : {
            icon: "trending-down",
            text: t("shiftInsightShort"),
            tone: "border-rose-300/70 bg-rose-500/10 text-rose-700 dark:border-rose-500/30 dark:bg-rose-500/15 dark:text-rose-300",
          }
    );
    /* |variance| EXACTLY equals a ladder denomination → one banknote or
     * coin went missing (or was extra) — name the face. */
    const absV = round2(Math.abs(variance));
    const hit = ladder.find((d) => round2(d) === absV);
    if (hit != null) {
      insights.push({
        icon: "banknote",
        text: t("shiftInsightDenom", { value: fmtMoneyCell(hit, lang, currency) }),
        tone:
          variance > 0
            ? "border-amber-300/70 bg-amber-500/10 text-amber-700 dark:border-amber-500/30 dark:bg-amber-500/15 dark:text-amber-300"
            : "border-rose-300/70 bg-rose-500/10 text-rose-700 dark:border-rose-500/30 dark:bg-rose-500/15 dark:text-rose-300",
      });
    }
    /* within the acceptable 1% margin */
    if (variancePct != null && Math.abs(variancePct) <= 1) {
      insights.push({
        icon: "gauge",
        text: t("shiftInsightMargin"),
        tone: "border-teal-300/70 bg-teal-500/10 text-teal-700 dark:border-teal-500/30 dark:bg-teal-500/15 dark:text-teal-300",
      });
    }
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent
        dir={lang === "ar" ? "rtl" : "ltr"}
        className="flex max-h-[85vh] flex-col gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-2xl"
      >
        <ShiftHeader
          icon="door-closed"
          c1="#f43f5e"
          c2="#e11d48"
          title={t("shiftCloseTitle")}
          desc={t("shiftCloseDesc")}
        />

        {current && agg ? (
          <form onSubmit={submit} noValidate className="flex min-h-0 flex-1 flex-col">
            <div className="nice-scroll min-h-0 flex-1 space-y-3.5 overflow-y-auto px-5 py-4">
              {/* the shift identity strip */}
              <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1">
                <span
                  dir={idDir}
                  className="inline-flex items-center gap-1 rounded-full border border-slate-200 bg-white/80 px-2.5 py-0.5 font-mono text-[10.5px] font-extrabold text-slate-600 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-300"
                >
                  <CatIcon name="hash" className="h-2.5 w-2.5 text-slate-400" aria-hidden="true" />
                  {fmtId(current.code, lang)}
                </span>
                <span className="inline-flex items-center gap-1 text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
                  <CatIcon name="user-round" className="h-3 w-3" aria-hidden="true" />
                  {t("shiftOpenedBy")} {current.openedBy}
                </span>
                <span dir={numDir(lang)} className="inline-flex items-center gap-1 text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
                  <CatIcon name="clock" className="h-3 w-3" aria-hidden="true" />
                  {t("shiftBarOpenSince", { time: shiftElapsedLabel(lang, current.openedAt) })}
                </span>
              </div>

              {/* frozen live-aggregates summary strip (tightened) */}
              <div className="grid grid-cols-3 gap-1.5">
                <StatCard icon="receipt" label={t("shiftAggSales")} value={fmtNum(agg.salesCount, lang)} dir={numDir(lang)} />
                <StatCard icon="coins" label={t("shiftAggTotal")} value={fmtMoneyCell(agg.salesTotal, lang, currency)} dir={numDir(lang)} />
                <StatCard icon="banknote" label={t("shiftAggCash")} value={fmtMoneyCell(agg.cashTotal, lang, currency)} dir={numDir(lang)} />
                <StatCard icon="credit-card" label={t("shiftAggCard")} value={fmtMoneyCell(agg.cardTotal, lang, currency)} dir={numDir(lang)} />
                <StatCard icon="percent" label={t("shiftAggDiscount")} value={fmtMoneyCell(agg.discountTotal, lang, currency)} dir={numDir(lang)} />
                <StatCard icon="timer" label={t("shiftAggAvgBasket")} value={fmtMoneyCell(avgBasket, lang, currency)} dir={numDir(lang)} />
              </div>

              {/* the smart calculator — denomination ladder (RIGHT in RTL) +
                  live math + keypad (LEFT); one column on mobile */}
              <div className="grid gap-3.5 sm:grid-cols-2">
                {/* ===== العدّاد النقدي — the currency-aware counter ===== */}
                <div className="space-y-2 rounded-2xl border border-slate-200/80 bg-white/70 p-3 dark:border-white/10 dark:bg-white/[0.03]">
                  <div className="flex items-center justify-between gap-2">
                    <p className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200">
                      <CatIcon name="banknote" className="h-3.5 w-3.5 text-emerald-500" aria-hidden="true" />
                      {t("shiftCalcDenomTitle")}
                    </p>
                    <button
                      type="button"
                      onClick={resetDenoms}
                      aria-label={t("shiftCalcDenomReset")}
                      className="inline-flex h-7 shrink-0 items-center gap-1 rounded-lg px-2 text-[10px] font-bold text-slate-400 transition hover:bg-rose-500/10 hover:text-rose-500 active:scale-95 dark:text-slate-500 dark:hover:bg-rose-500/15"
                    >
                      <CatIcon name="rotate-ccw" className="h-3 w-3" aria-hidden="true" />
                      {t("shiftCalcDenomReset")}
                    </button>
                  </div>
                  <p className="text-[10px] font-semibold leading-snug text-slate-400 dark:text-slate-500">
                    {t("shiftCalcDenomHint")}
                  </p>

                  <div className="space-y-1">
                    {ladder.map((value) => {
                      const count = counts[value] ?? 0;
                      const lineTotal = round2(count * value);
                      return (
                        <div
                          key={value}
                          className="flex items-center gap-1.5 rounded-xl border border-slate-200/70 bg-white/60 px-2 py-1 dark:border-white/[0.06] dark:bg-white/[0.02]"
                        >
                          <span
                            dir={numDir(lang)}
                            className="w-16 shrink-0 truncate text-[11.5px] font-extrabold tabular-nums text-slate-600 dark:text-slate-300"
                          >
                            {fmtMoneyCell(value, lang)}
                          </span>
                          <button
                            type="button"
                            onClick={() => setDenomCount(value, count - 1)}
                            disabled={count <= 0}
                            aria-label={t("shiftCalcDec")}
                            className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-slate-200/90 bg-white/85 text-slate-500 transition hover:border-slate-300 hover:text-rose-600 active:scale-95 disabled:pointer-events-none disabled:opacity-40 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-300"
                          >
                            <CatIcon name="minus" className="h-3.5 w-3.5" aria-hidden="true" />
                          </button>
                          <input
                            type="text"
                            inputMode="numeric"
                            aria-label={t("shiftCalcDenomRow", { value: fmtMoneyCell(value, lang, currency) })}
                            value={count === 0 ? "" : String(count)}
                            onChange={(e) => {
                              const digits = e.target.value.replace(/\D/g, "").slice(0, 3);
                              setDenomCount(value, digits === "" ? 0 : Number(digits));
                            }}
                            dir="ltr"
                            placeholder="0"
                            className="h-9 w-12 shrink-0 rounded-lg border border-slate-200/90 bg-white/85 text-center text-[12.5px] font-extrabold tabular-nums text-slate-700 outline-none transition focus:border-rose-300 focus:ring-2 focus:ring-rose-500/20 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-200"
                          />
                          <button
                            type="button"
                            onClick={() => setDenomCount(value, count + 1)}
                            disabled={count >= 999}
                            aria-label={t("shiftCalcInc")}
                            className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-slate-200/90 bg-white/85 text-slate-500 transition hover:border-slate-300 hover:text-emerald-600 active:scale-95 disabled:pointer-events-none disabled:opacity-40 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-300"
                          >
                            <CatIcon name="plus" className="h-3.5 w-3.5" aria-hidden="true" />
                          </button>
                          <span
                            dir={numDir(lang)}
                            className={cn(
                              "ms-auto min-w-0 truncate text-[11px] font-extrabold tabular-nums",
                              count > 0 ? "text-emerald-600 dark:text-emerald-400" : "text-slate-300 dark:text-slate-600"
                            )}
                          >
                            {count > 0 ? fmtMoneyCell(lineTotal, lang) : "—"}
                          </span>
                        </div>
                      );
                    })}
                  </div>

                  {/* grand total — feeds the counted value while the ladder
                      is the driving source (the emerald ring marks it) */}
                  <div
                    className={cn(
                      "flex items-center justify-between gap-2 rounded-xl border px-3 py-2 transition",
                      source === "denom"
                        ? "border-emerald-300/70 bg-emerald-500/10 dark:border-emerald-500/30 dark:bg-emerald-500/15"
                        : "border-slate-200/80 bg-slate-50 dark:border-white/10 dark:bg-white/[0.04]"
                    )}
                  >
                    <p className="flex items-center gap-1 text-[9.5px] font-extrabold uppercase tracking-wide text-emerald-700/90 dark:text-emerald-300/90">
                      <CatIcon name="coins" className="h-3 w-3" aria-hidden="true" />
                      {t("shiftCalcDenomTotal")}
                    </p>
                    <p
                      dir={numDir(lang)}
                      className="min-w-0 truncate font-display text-[15px] font-extrabold tabular-nums text-emerald-700 dark:text-emerald-300"
                    >
                      {fmtMoneyCell(denomTotal, lang, currency)}
                    </p>
                  </div>
                </div>

                {/* ===== الحسبة الحية + الآلة الحاسبة ===== */}
                <div className="space-y-3">
                  {/* the live math readout — opening + cash = expected →
                      collected → variance (polite live region + progress) */}
                  <div
                    className={cn(
                      "space-y-1.5 rounded-2xl border px-3.5 py-3 transition",
                      variance === 0
                        ? "border-emerald-400/70 bg-emerald-500/[0.07] ring-1 ring-emerald-400/50 dark:border-emerald-500/40 dark:bg-emerald-500/10"
                        : "border-slate-200/80 bg-slate-50/80 dark:border-white/10 dark:bg-white/[0.04]"
                    )}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <p className="flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                        <CatIcon name="calculator" className="h-3.5 w-3.5 text-teal-500" aria-hidden="true" />
                        {t("shiftCalcMath")}
                      </p>
                      {variance === 0 ? (
                        <span
                          className="animate-in zoom-in-95 inline-flex shrink-0 items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-extrabold text-white shadow-md"
                          style={{ backgroundImage: grad("#10b981", "#059669") }}
                        >
                          <CatIcon name="party-popper" className="h-3 w-3" aria-hidden="true" />
                          {t("shiftInsightPerfect")}
                        </span>
                      ) : null}
                    </div>

                    {/* opening float */}
                    <div className="flex items-center justify-between gap-2">
                      <span className="shrink-0 text-[11px] font-bold text-slate-500 dark:text-slate-400">
                        {t("shiftCalcOpening")}
                      </span>
                      <span dir={numDir(lang)} className="min-w-0 truncate text-[12px] font-extrabold tabular-nums text-slate-700 dark:text-slate-200">
                        {fmtMoneyCell(current.openingCash, lang, currency)}
                      </span>
                    </div>
                    {/* + cash sales */}
                    <div className="flex items-center justify-between gap-2">
                      <span className="shrink-0 text-[11px] font-bold text-slate-500 dark:text-slate-400">
                        {`+ ${t("shiftCalcCashSales")}`}
                      </span>
                      <span dir={numDir(lang)} className="min-w-0 truncate text-[12px] font-extrabold tabular-nums text-slate-700 dark:text-slate-200">
                        {fmtMoneyCell(agg.cashTotal, lang, currency)}
                      </span>
                    </div>
                    {/* = expected */}
                    <div className="flex items-center justify-between gap-2 border-t border-dashed border-slate-300/70 pt-2 dark:border-white/15">
                      <span className="shrink-0 text-[11px] font-extrabold text-emerald-700 dark:text-emerald-300">
                        {`= ${t("shiftCalcExpected")}`}
                      </span>
                      <span dir={numDir(lang)} className="min-w-0 truncate text-[13px] font-extrabold tabular-nums text-emerald-700 dark:text-emerald-300">
                        {expected != null ? fmtMoneyCell(expected, lang, currency) : "—"}
                      </span>
                    </div>
                    {/* collected — the smart counter's live value */}
                    <div className="flex items-center justify-between gap-2">
                      <span className="shrink-0 text-[11px] font-extrabold text-violet-600 dark:text-violet-300">
                        {t("shiftCalcCollected")}
                      </span>
                      <span dir={numDir(lang)} className="min-w-0 truncate font-display text-[15px] font-extrabold tabular-nums text-violet-700 dark:text-violet-300">
                        {countedNum != null && Number.isFinite(countedNum)
                          ? fmtMoneyCell(countedNum, lang, currency)
                          : "—"}
                      </span>
                    </div>
                    {/* variance — live, politely announced */}
                    <div
                      role="status"
                      aria-live="polite"
                      className="flex items-center justify-between gap-2 border-t border-dashed border-slate-300/70 pt-2 dark:border-white/15"
                    >
                      <span className="shrink-0 text-[11px] font-extrabold text-slate-500 dark:text-slate-400">
                        {t("shiftVariance")}
                      </span>
                      <span className="flex min-w-0 items-center gap-1.5">
                        <VariancePill variance={variance} lang={lang} currency={currency} />
                        {variancePct != null ? (
                          <span dir={numDir(lang)} className="shrink-0 text-[10.5px] font-extrabold tabular-nums text-slate-400 dark:text-slate-500">
                            {variancePct > 0 ? "+" : variancePct < 0 ? "−" : ""}
                            {fmtNum(Math.abs(variancePct), lang)}%
                          </span>
                        ) : null}
                      </span>
                    </div>
                    {/* the counted-vs-expected fill bar */}
                    {fillRatio != null ? (
                      <div
                        role="progressbar"
                        aria-label={t("shiftCalcCollected")}
                        aria-valuemin={0}
                        aria-valuemax={100}
                        aria-valuenow={Math.max(0, Math.min(100, Math.round(fillRatio * 100)))}
                        className="h-1.5 overflow-hidden rounded-full bg-slate-200/80 dark:bg-white/10"
                      >
                        <div
                          className={cn(
                            "h-full rounded-full transition-all duration-300",
                            variance === 0
                              ? "bg-linear-to-l from-emerald-500 to-teal-400"
                              : variance != null && variance > 0
                                ? "bg-linear-to-l from-amber-500 to-orange-400"
                                : "bg-linear-to-l from-rose-500 to-orange-400"
                          )}
                          style={{ width: `${Math.max(0, Math.min(100, fillRatio * 100))}%` }}
                        />
                      </div>
                    ) : null}
                  </div>

                  {/* the counted drawer — typed, keypad-driven or fed by the
                      denomination counter (latest-edited wins) */}
                  <div className="space-y-1.5">
                    <Label
                      htmlFor="shift-close-counted"
                      className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
                    >
                      <CatIcon name="hand-coins" className="h-3 w-3 text-rose-500" aria-hidden="true" />
                      {t("shiftCountedCash")}
                      <span
                        dir="ltr"
                        className="rounded-full bg-slate-100 px-1.5 py-px text-[10.5px] font-bold text-slate-500 dark:bg-white/10 dark:text-slate-400"
                      >
                        {currency}
                      </span>
                    </Label>
                    <Input
                      id="shift-close-counted"
                      type="text"
                      inputMode="decimal"
                      autoFocus
                      value={counted}
                      onChange={(e) => {
                        setSource("manual");
                        setCounted(e.target.value);
                      }}
                      dir="ltr"
                      placeholder="0"
                      className="h-12 rounded-xl text-end text-[16px] font-extrabold tabular-nums"
                    />
                  </div>

                  {/* quick-adjust chips + الضبط على المتوقع */}
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                      {t("shiftCalcQuick")}
                    </span>
                    {[-100, -50, 50, 100].map((delta) => {
                      const label = `${delta > 0 ? "+" : "−"}${fmtNum(Math.abs(delta), lang)}`;
                      return (
                        <button
                          key={delta}
                          type="button"
                          onClick={() => adjustCounted(delta)}
                          aria-label={t("shiftCalcQuickChip", { value: label })}
                          dir="ltr"
                          className="h-8 min-w-11 shrink-0 rounded-full border border-slate-200 bg-white/80 px-2.5 text-[11px] font-extrabold tabular-nums text-slate-600 transition hover:border-slate-300 hover:bg-slate-100 active:scale-95 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-300 dark:hover:border-white/20 dark:hover:bg-white/[0.1]"
                        >
                          {label}
                        </button>
                      );
                    })}
                    <button
                      type="button"
                      onClick={matchExpected}
                      disabled={expected == null}
                      className="inline-flex h-8 shrink-0 items-center gap-1 rounded-full border border-violet-300/70 bg-violet-500/10 px-2.5 text-[10.5px] font-extrabold text-violet-700 transition hover:bg-violet-500/20 active:scale-95 disabled:pointer-events-none disabled:opacity-50 dark:border-violet-500/30 dark:bg-violet-500/15 dark:text-violet-300"
                    >
                      <CatIcon name="wand-sparkles" className="h-3 w-3" aria-hidden="true" />
                      {t("shiftCalcMatch")}
                    </button>
                  </div>

                  {/* the real numeric keypad */}
                  <CalcKeypad onKey={pressKey} />

                  {/* القراءة الذكية — variance forensics */}
                  {insights.length > 0 ? (
                    <div className="space-y-1.5" aria-label={t("shiftInsightTitle")}>
                      <p className="flex items-center gap-1 text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                        <CatIcon name="sparkles" className="h-3 w-3 text-violet-500" aria-hidden="true" />
                        {t("shiftInsightTitle")}
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {insights.map((chip) => (
                          <span
                            key={chip.text}
                            className={cn(
                              "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10.5px] font-extrabold",
                              chip.tone
                            )}
                          >
                            <CatIcon name={chip.icon} className="h-3 w-3" aria-hidden="true" />
                            {chip.text}
                          </span>
                        ))}
                      </div>
                    </div>
                  ) : null}
                </div>
              </div>

              {/* optional closing note */}
              <div className="space-y-1.5">
                <Label
                  htmlFor="shift-close-note"
                  className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
                >
                  <CatIcon name="notebook-pen" className="h-3 w-3 text-slate-400" aria-hidden="true" />
                  {t("shiftNote")}
                </Label>
                <Input
                  id="shift-close-note"
                  type="text"
                  maxLength={220}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="…"
                  className="h-11 rounded-xl text-[12.5px] font-semibold"
                />
              </div>
            </div>

            {/* footer */}
            <div className="flex shrink-0 items-center justify-end gap-2.5 border-t border-slate-200/70 px-5 py-3.5 dark:border-white/10">
              <Button
                type="button"
                variant="outline"
                onClick={() => handleOpenChange(false)}
                disabled={close.isPending}
                className="h-10 rounded-xl px-4 text-[12.5px] font-bold hover:border-slate-300 hover:bg-slate-100 dark:hover:border-white/20 dark:hover:bg-white/5"
              >
                {t("modRecCancelBtn")}
              </Button>
              <Button
                type="submit"
                disabled={close.isPending || !current || countedNum == null || !Number.isFinite(countedNum)}
                className="h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:opacity-60"
                style={{ backgroundImage: grad("#f43f5e", "#e11d48") }}
              >
                {close.isPending ? (
                  <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                ) : (
                  <CatIcon name="lock" className="h-4 w-4" />
                )}
                {t("shiftCloseAction")}
              </Button>
            </div>
          </form>
        ) : (
          /* no open shift (race — the bar or server closed it already) */
          <div className="px-5 py-10 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl border border-rose-300/60 bg-rose-500/10 text-rose-500 dark:border-rose-500/30 dark:bg-rose-500/15 dark:text-rose-400">
              <CatIcon name="lock" className="h-7 w-7" />
            </div>
            <p className="mt-3 text-[12.5px] font-bold text-slate-500 dark:text-slate-400">
              {t("shiftBarClosed")}
            </p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

/* ------------------------------------------------------------------ */
/* 3) CODE — define / change the owner's secret shift code             */
/* ------------------------------------------------------------------ */

export function ShiftCodeDialog({ open, onOpenChange, instance }: DialogProps) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  /* ROUND 144 — the persisted PIN length (the shared ["shifts", id] entry):
   * editing an existing PIN defaults the selector to its REMEMBERED
   * length so the owner sees exactly what they chose before. */
  const { data: shiftData } = useShift(instance.id);
  const persistedLen = shiftData?.codeLen ?? null;
  const [password, setPassword] = useState("");
  const [newCode, setNewCode] = useState("");
  const [confirmCode, setConfirmCode] = useState("");
  const [error, setError] = useState<string | null>(null);
  /* ROUND 144 — the CHOSEN length (null until the owner picks a pill →
   * the persisted length wins, then 4). Both code fields live-resize to
   * EXACTLY this many cells while typing. */
  const [lenChoice, setLenChoice] = useState<number | null>(null);
  const chosenLen = Math.min(8, Math.max(4, lenChoice ?? persistedLen ?? 4));

  const chooseLen = (n: number) => {
    setLenChoice(n);
    /* live-resize: digits beyond the newly chosen length drop off both
     * fields so the cells always mirror the exact chosen code */
    setNewCode((v) => v.slice(0, n));
    setConfirmCode((v) => v.slice(0, n));
    if (error) setError(null);
  };

  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ["shifts", instance.id] });
  };

  const handleOpenChange = (o: boolean) => {
    if (!o) {
      setPassword("");
      setNewCode("");
      setConfirmCode("");
      setError(null);
      setLenChoice(null);
    }
    onOpenChange(o);
  };

  const save = useMutation({
    mutationFn: () =>
      setShiftCode(instance.id, {
        currentPassword: password,
        newCode: newCode.trim(),
        length: chosenLen,
      }),
    onSuccess: () => {
      invalidate();
      toast.success(t("shiftCodeSaved"));
      handleOpenChange(false);
    },
    onError: (e: Error) => {
      if (e instanceof ApiError && e.status === 401) {
        toast.error(t("shiftCodeNeedProof"));
        return;
      }
      toast.error(e.message || t("errorText"));
    },
  });

  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (save.isPending) return;
    /* client-side proof: the digits law first (the chosen length is the
     * exact cell count), then the twin match */
    if (!/^\d{4,8}$/.test(newCode.trim()) || newCode.trim().length !== chosenLen) {
      setError(t("shiftCodeDigits"));
      return;
    }
    if (newCode.trim() !== confirmCode.trim()) {
      setError(t("shiftCodeMismatch"));
      return;
    }
    setError(null);
    save.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent
        dir={lang === "ar" ? "rtl" : "ltr"}
        className="flex max-h-[85vh] flex-col gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-md"
      >
        <ShiftHeader
          icon="key-round"
          c1="#8b5cf6"
          c2="#d946ef"
          title={t("shiftCodeTitle")}
          desc={t("shiftCodeDesc")}
        />
        <form onSubmit={submit} noValidate className="flex min-h-0 flex-1 flex-col">
          <div className="nice-scroll min-h-0 flex-1 space-y-4 overflow-y-auto px-5 py-4">
            {/* workspace password — the identity proof */}
            <div className="space-y-1.5">
              <Label
                htmlFor="shift-code-password"
                className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
              >
                <CatIcon name="shield-user" className="h-3 w-3 text-violet-500" aria-hidden="true" />
                {t("shiftCodePassword")}
              </Label>
              <Input
                id="shift-code-password"
                type="password"
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="h-11 rounded-xl text-[13px] font-semibold"
              />
            </div>

            {/* ROUND 144 — the premium LENGTH selector: a segmented pill row
                (4/5/6/7/8) that live-resizes BOTH code fields below to
                EXACTLY N cells while the owner types. Editing an existing
                PIN defaults the selector to its REMEMBERED length. */}
            <div className="space-y-1.5">
              <Label className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                <CatIcon name="sliders" className="h-3 w-3 text-violet-500" aria-hidden="true" />
                {t("pinLengthLabel")}
              </Label>
              <div
                role="radiogroup"
                aria-label={t("pinLengthLabel")}
                className="grid grid-cols-5 gap-1.5"
              >
                {[4, 5, 6, 7, 8].map((n) => {
                  const active = chosenLen === n;
                  return (
                    <button
                      key={n}
                      type="button"
                      role="radio"
                      aria-checked={active}
                      onClick={() => chooseLen(n)}
                      className={cn(
                        "flex min-w-0 flex-col items-center justify-center gap-0.5 rounded-xl border py-2 transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-400/50 active:scale-95",
                        active
                          ? "border-violet-400 bg-violet-500/10 shadow-sm ring-2 ring-violet-400/40 dark:border-violet-500/60 dark:bg-violet-500/15"
                          : "border-slate-200 bg-white/80 hover:border-violet-300 hover:bg-violet-500/[0.04] dark:border-white/10 dark:bg-white/[0.04] dark:hover:border-violet-500/40",
                      )}
                    >
                      <span
                        dir="ltr"
                        className={cn(
                          "text-[16px] font-extrabold tabular-nums leading-none",
                          active
                            ? "text-violet-600 dark:text-violet-300"
                            : "text-slate-500 dark:text-slate-300",
                        )}
                      >
                        {fmtNum(n, lang)}
                      </span>
                      <span
                        className={cn(
                          "truncate text-[8.5px] font-bold",
                          active
                            ? "text-violet-500 dark:text-violet-300/80"
                            : "text-slate-400 dark:text-slate-500",
                        )}
                      >
                        {t("pinLengthCells", { n })}
                      </span>
                    </button>
                  );
                })}
              </div>
              <p className="flex items-start gap-1 text-[10px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                <CatIcon name="info" className="mt-0.5 h-3 w-3 shrink-0" aria-hidden="true" />
                <span className="min-w-0">{t("pinLengthHint")}</span>
              </p>
            </div>

            {/* ROUND 141 (㉖) — the new code as the PREMIUM segmented PIN
                (ROUND 144: EXACTLY chosenLen cells — the live mirror of the
                selector above). */}
            <div className="space-y-1.5">
              <Label
                className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
              >
                <CatIcon name="key-round" className="h-3 w-3 text-violet-500" aria-hidden="true" />
                {t("shiftCodeNew")}
              </Label>
              <PinInput
                value={newCode}
                onChange={(v) => {
                  setNewCode(v);
                  if (error) setError(null);
                }}
                error={error === t("shiftCodeDigits")}
                minLength={chosenLen}
                maxLength={chosenLen}
                label={t("shiftCodeNew")}
              />
              <p className="flex items-center gap-1 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                <CatIcon name="info" className="h-3 w-3 shrink-0" aria-hidden="true" />
                {t("pinEnterN", { n: chosenLen })}
              </p>
            </div>

            {/* ROUND 141 (㉖) — the confirmation twin as the same premium PIN
                (ROUND 144: the same exact chosenLen cells — must match). */}
            <div className="space-y-1.5">
              <Label
                className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
              >
                <CatIcon name="badge-check" className="h-3 w-3 text-violet-500" aria-hidden="true" />
                {t("shiftCodeConfirm")}
              </Label>
              <PinInput
                value={confirmCode}
                onChange={(v) => {
                  setConfirmCode(v);
                  if (error) setError(null);
                }}
                error={error === t("shiftCodeMismatch")}
                minLength={chosenLen}
                maxLength={chosenLen}
                label={t("shiftCodeConfirm")}
              />
            </div>

            {/* client-side validation verdict */}
            {error ? (
              <p className="flex items-center gap-1.5 rounded-xl border border-rose-300/60 bg-rose-500/10 px-3 py-2 text-[11px] font-bold text-rose-600 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-300">
                <CatIcon name="circle-alert" className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                {error}
              </p>
            ) : null}
          </div>

          {/* footer */}
          <div className="flex shrink-0 items-center justify-end gap-2.5 border-t border-slate-200/70 px-5 py-3.5 dark:border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => handleOpenChange(false)}
              disabled={save.isPending}
              className="h-10 rounded-xl px-4 text-[12.5px] font-bold hover:border-slate-300 hover:bg-slate-100 dark:hover:border-white/20 dark:hover:bg-white/5"
            >
              {t("modRecCancelBtn")}
            </Button>
            <Button
              type="submit"
              disabled={save.isPending || password === "" || newCode.trim() === "" || confirmCode.trim() === "" || newCode.trim().length !== chosenLen || confirmCode.trim().length !== chosenLen}
              className="h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:opacity-60"
              style={{ backgroundImage: grad("#8b5cf6", "#d946ef") }}
            >
              {save.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="key-round" className="h-4 w-4" />
              )}
              {t("shiftCodeSave")}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

/* ------------------------------------------------------------------ */
/* 4) HISTORY — the closed-shift premium row cards                      */
/* (rendered by the ShiftHistoryDialog browser AND the الورديات         */
/*  module workspace — one card idiom, two surfaces)                    */
/* ------------------------------------------------------------------ */

/** One closed shift — the compact reconciliation card. */
/* ROUND 134 — exported for the dedicated الورديات module workspace
 * (views/shift/shifts-workspace.tsx renders the same premium row cards). */
export function ShiftHistoryRow({
  shift,
  lang,
  currency,
}: {
  shift: ShiftDTO;
  lang: Lang;
  currency: string;
}) {
  const { t } = useT();
  /* ROUND 138 — the per-row DETAILS dialog (each row owns its own sheet;
   * works identically inside the workspace history list and the browser). */
  const [detailsOpen, setDetailsOpen] = useState(false);
  const total = shift.aggregates.salesTotal;
  return (
    <article className="rounded-2xl border border-slate-200/80 bg-white/70 p-3 dark:border-white/10 dark:bg-white/[0.03]">
      <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1">
        <span
          dir={idDir}
          className="inline-flex items-center gap-1 rounded-full border border-slate-200 bg-white/80 px-2.5 py-0.5 font-mono text-[10.5px] font-extrabold text-slate-600 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-300"
        >
          <CatIcon name="hash" className="h-2.5 w-2.5 text-slate-400" aria-hidden="true" />
          {fmtId(shift.code, lang)}
        </span>
        <VariancePill variance={shift.variance} lang={lang} currency={currency} />
        <span
          dir={numDir(lang)}
          className="ms-auto inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 text-[10.5px] font-extrabold text-slate-500 dark:bg-white/[0.06] dark:text-slate-300"
        >
          <CatIcon name="timer" className="h-3 w-3" aria-hidden="true" />
          {t("shiftDuration")} {shiftElapsedLabel(lang, shift.openedAt, shift.closedAt)}
        </span>
        {/* ROUND 138 — the premium DETAILS lever (owner directive:
            «طور زر لعرض تفاصيل الوردية بطريقة اختر وPremium»). */}
        <button
          type="button"
          onClick={() => setDetailsOpen(true)}
          aria-label={t("shiftDetailsBtn")}
          title={t("shiftDetailsBtn")}
          className="inline-flex h-7 shrink-0 items-center gap-1 rounded-lg border border-slate-200 bg-white/85 px-2 text-[10px] font-extrabold text-slate-600 transition hover:border-brand-300 hover:bg-brand-500/10 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
        >
          <CatIcon name="eye" className="h-3 w-3" aria-hidden="true" />
          {t("shiftDetailsBtn")}
        </button>
      </div>

      <div className="mt-2 grid grid-cols-1 gap-x-3 gap-y-1.5 text-[10.5px] font-bold text-slate-500 dark:text-slate-400 sm:grid-cols-2">
        <span className="inline-flex min-w-0 items-center gap-1.5">
          <CatIcon name="user-round" className="h-3 w-3 shrink-0 text-emerald-500" aria-hidden="true" />
          <span className="shrink-0">{t("shiftOpenedBy")}</span>
          <span className="truncate font-extrabold text-slate-700 dark:text-slate-200">{shift.openedBy}</span>
          <span className="shrink-0 text-slate-400 dark:text-slate-500">· {fullDate(shift.openedAt, lang)}</span>
        </span>
        <span className="inline-flex min-w-0 items-center gap-1.5">
          <CatIcon name="user-round" className="h-3 w-3 shrink-0 text-rose-500" aria-hidden="true" />
          <span className="shrink-0">{t("shiftClosedBy")}</span>
          <span className="truncate font-extrabold text-slate-700 dark:text-slate-200">{shift.closedBy ?? "—"}</span>
          <span className="shrink-0 text-slate-400 dark:text-slate-500">
            · {shift.closedAt ? fullDate(shift.closedAt, lang) : "—"}
          </span>
        </span>
        <span dir={numDir(lang)} className="inline-flex items-center gap-1.5">
          <CatIcon name="receipt" className="h-3 w-3 shrink-0 text-slate-400" aria-hidden="true" />
          {t("shiftAggSales")} {fmtNum(shift.aggregates.salesCount, lang)}
        </span>
        <span dir={numDir(lang)} className="inline-flex items-center gap-1.5">
          <CatIcon name="coins" className="h-3 w-3 shrink-0 text-slate-400" aria-hidden="true" />
          {t("shiftAggTotal")} {fmtMoneyCell(total, lang, currency)}
        </span>
      </div>

      {shift.closingNote ? (
        <p className="mt-1.5 border-t border-slate-200/70 pt-1.5 text-[10.5px] italic font-semibold text-slate-400 dark:border-white/10 dark:text-slate-500">
          {shift.closingNote}
        </p>
      ) : null}

      {/* ROUND 138 — the premium details sheet */}
      <ShiftDetailsDialog shift={shift} lang={lang} currency={currency} open={detailsOpen} onOpenChange={setDetailsOpen} />
    </article>
  );
}

/* ------------------------------------------------------------------ */
/* 5) ROUND 138 — DETAILS — the premium shift details sheet             */
/* ------------------------------------------------------------------ */

/**
 * One PREMIUM detail row (label + value) for the timeline section.
 * `icon` colors the leading tile; the value keeps the caller's boldness.
 */
function DetailLine({
  icon,
  iconClass,
  label,
  children,
}: {
  icon: string;
  iconClass?: string;
  label: string;
  children: ReactNode;
}) {
  return (
    <div className="flex min-w-0 items-center gap-2 rounded-xl border border-slate-200/70 bg-white/60 px-3 py-2 dark:border-white/10 dark:bg-white/[0.04]">
      <CatIcon name={icon} className={cn("h-3.5 w-3.5 shrink-0", iconClass)} aria-hidden="true" />
      <span className="shrink-0 text-[10px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">{label}</span>
      <span className="min-w-0 flex-1 truncate text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200">{children}</span>
    </div>
  );
}

/** The premium section label (hairline + icon + title). */
function DetailSection({ icon, title }: { icon: string; title: string }) {
  return (
    <p className="flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-widest text-slate-400 dark:text-slate-500">
      <CatIcon name={icon} className="h-3 w-3 text-slate-300 dark:text-slate-600" aria-hidden="true" />
      {title}
      <span className="h-px flex-1 bg-linear-to-l from-slate-200 to-transparent dark:from-white/10" aria-hidden="true" />
    </p>
  );
}

/**
 * ROUND 138 — the premium shift DETAILS sheet (owner directive: «طور زر
 * لعرض تفاصيل الوردية بطريقة اختر وPremium»). Mounted from every closed
 * shift row (workspace history + the browser dialog) and from the live
 * current-shift card — renders the FULL readout from the already-cached
 * ShiftDTO (no extra fetch): identity band (code + status + variance
 * verdict), the timeline (opener/closer/duration), the cash
 * reconciliation ladder (opening float → expected → collected →
 * variance), the five sales aggregates, and the closing note.
 *
 * An OPEN shift renders the same sheet with the reconciliation trio as
 * «تُستكمل عند الإغلاق» placeholders (counted/expected/variance are null
 * by law until close) and a ticking duration.
 */
export function ShiftDetailsDialog({
  shift,
  lang,
  currency,
  open,
  onOpenChange,
}: {
  shift: ShiftDTO;
  lang: Lang;
  currency: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { t } = useT();
  const rtl = lang === "ar";
  const isOpen = shift.status === "open";

  /* ticking re-render while the sheet shows a LIVE shift (30s cadence —
   * the same law as the status bar/browser; the tick value is unread). */
  const [, setTick] = useState(0);
  useEffect(() => {
    if (!open || !isOpen) return;
    const timer = window.setInterval(() => setTick(Date.now()), 30_000);
    return () => window.clearInterval(timer);
  }, [open, isOpen]);

  const agg = shift.aggregates;
  const pending = t("shiftDetailsPendingClose");

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onOpenChange(o)}>
      <DialogContent
        dir={rtl ? "rtl" : "ltr"}
        className="flex max-h-[85vh] flex-col gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-lg"
      >
        <ShiftHeader
          icon="notebook-pen"
          c1={isOpen ? "#10b981" : "#8b5cf6"}
          c2={isOpen ? "#059669" : "#7c3aed"}
          title={t("shiftDetailsTitle")}
          desc={t("shiftDetailsDesc")}
        />

        <div className="nice-scroll min-h-0 flex-1 space-y-4 overflow-y-auto px-5 py-4">
          {/* ---- identity band ---- */}
          <div className="flex flex-wrap items-center gap-2">
            <span
              dir={idDir}
              className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white/85 px-3 py-1 font-mono text-[11.5px] font-extrabold text-slate-600 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-300"
            >
              <CatIcon name="hash" className="h-3 w-3 text-slate-400" aria-hidden="true" />
              {fmtId(shift.code, lang)}
            </span>
            {isOpen ? (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-300/70 bg-emerald-500/10 px-3 py-1 text-[10.5px] font-extrabold text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/15 dark:text-emerald-300">
                <span className="relative flex h-1.5 w-1.5" aria-hidden="true">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-500" />
                </span>
                {t("shiftBrowserLive")}
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-slate-100 px-3 py-1 text-[10.5px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/[0.06] dark:text-slate-300">
                <CatIcon name="lock" className="h-3 w-3" aria-hidden="true" />
                {t("shiftDetailsStatusClosed")}
              </span>
            )}
            <VariancePill variance={shift.variance} lang={lang} currency={currency} />
          </div>

          {/* ---- timeline ---- */}
          <div className="space-y-2">
            <DetailSection icon="clock" title={t("shiftDetailsTimeline")} />
            <DetailLine icon="user-round" iconClass="text-emerald-500" label={t("shiftOpenedBy")}>
              {shift.openedBy}
              <span className="ms-1 shrink-0 text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                · {fullDate(shift.openedAt, lang)}
              </span>
            </DetailLine>
            <DetailLine icon="user-round" iconClass="text-rose-500" label={t("shiftClosedBy")}>
              {shift.closedBy ?? "—"}
              <span className="ms-1 shrink-0 text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                · {shift.closedAt ? fullDate(shift.closedAt, lang) : "—"}
              </span>
            </DetailLine>
            <DetailLine icon="timer" iconClass="text-violet-500" label={t("shiftDuration")}>
              <span dir={numDir(lang)}>{shiftElapsedLabel(lang, shift.openedAt, shift.closedAt)}</span>
            </DetailLine>
          </div>

          {/* ---- cash & reconciliation ---- */}
          <div className="space-y-2">
            <DetailSection icon="scale" title={t("shiftDetailsCashSection")} />
            <div className="grid grid-cols-2 gap-2">
              <StatCard
                icon="vault"
                label={t("shiftCalcOpening")}
                value={fmtMoneyCell(shift.openingCash, lang, currency)}
                dir={numDir(lang)}
              />
              <StatCard
                icon="scale"
                label={t("shiftCalcExpected")}
                value={shift.expectedCash == null ? pending : fmtMoneyCell(shift.expectedCash, lang, currency)}
                dir={numDir(lang)}
              />
              <StatCard
                icon="hand-coins"
                label={t("shiftCalcCollected")}
                value={shift.countedCash == null ? pending : fmtMoneyCell(shift.countedCash, lang, currency)}
                dir={numDir(lang)}
              />
              <StatCard
                icon={shift.variance == null ? "help-circle" : shift.variance === 0 ? "badge-check" : shift.variance > 0 ? "trending-up" : "trending-down"}
                label={t("shiftWsKpiVariance")}
                value={
                  shift.variance == null
                    ? pending
                    : `${shift.variance > 0 ? "+" : shift.variance < 0 ? "−" : ""}${fmtMoneyCell(Math.abs(shift.variance), lang, currency)}`
                }
                dir={numDir(lang)}
              />
            </div>
          </div>

          {/* ---- sales aggregates ---- */}
          <div className="space-y-2">
            <DetailSection icon="coins" title={t("shiftDetailsSalesSection")} />
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              <StatCard icon="receipt" label={t("shiftAggSales")} value={fmtNum(agg.salesCount, lang)} dir={numDir(lang)} />
              <StatCard icon="coins" label={t("shiftAggTotal")} value={fmtMoneyCell(agg.salesTotal, lang, currency)} dir={numDir(lang)} />
              <StatCard icon="ticket-percent" label={t("shiftDetailsDiscount")} value={fmtMoneyCell(agg.discountTotal, lang, currency)} dir={numDir(lang)} />
              <StatCard icon="banknote" label={t("shiftAggCash")} value={fmtMoneyCell(agg.cashTotal, lang, currency)} dir={numDir(lang)} />
              <StatCard icon="credit-card" label={t("shiftAggCard")} value={fmtMoneyCell(agg.cardTotal, lang, currency)} dir={numDir(lang)} />
            </div>
          </div>

          {/* ---- closing note ---- */}
          {shift.closingNote ? (
            <div className="space-y-2">
              <DetailSection icon="notebook-pen" title={t("shiftDetailsNote")} />
              <p className="rounded-xl border border-slate-200/70 bg-slate-50/80 px-3.5 py-2.5 text-[11px] italic font-semibold leading-relaxed text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400">
                {shift.closingNote}
              </p>
            </div>
          ) : null}
        </div>
      </DialogContent>
    </Dialog>
  );
}

/* ------------------------------------------------------------------ */
/* 4) HISTORY — the premium SHIFTS BROWSER (متصفح الورديات)             */
/* ------------------------------------------------------------------ */

/** ROUND 134-A — one header stats tile (the browser's band). */
function BrowserStat({
  icon,
  label,
  value,
  dir,
  tone,
}: {
  icon: string;
  label: string;
  value: string;
  dir: "rtl" | "ltr";
  tone: "violet" | "emerald" | "amber" | "rose";
}) {
  const toneMap = {
    violet:
      "border-violet-200/70 bg-violet-500/[0.06] text-violet-600 dark:border-violet-500/25 dark:bg-violet-500/10 dark:text-violet-400",
    emerald:
      "border-emerald-200/70 bg-emerald-500/[0.06] text-emerald-600 dark:border-emerald-500/25 dark:bg-emerald-500/10 dark:text-emerald-400",
    amber:
      "border-amber-200/70 bg-amber-500/[0.06] text-amber-600 dark:border-amber-500/25 dark:bg-amber-500/10 dark:text-amber-400",
    rose:
      "border-rose-200/70 bg-rose-500/[0.06] text-rose-600 dark:border-rose-500/25 dark:bg-rose-500/10 dark:text-rose-400",
  }[tone];
  return (
    <div className={cn("min-w-0 rounded-xl border px-3 py-2", toneMap)}>
      <p className="flex items-center gap-1 text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
        <CatIcon name={icon} className="h-2.5 w-2.5 shrink-0" aria-hidden="true" />
        {label}
      </p>
      <p dir={dir} className="mt-0.5 truncate font-display text-[14px] font-extrabold tabular-nums">
        {value}
      </p>
    </div>
  );
}

/** ROUND 134-A — the pinned LIVE current-shift card (emerald, ticking
 *  elapsed via the owner dialog's re-render, live aggregates). */
function CurrentShiftCard({
  shift,
  lang,
  currency,
}: {
  shift: ShiftDTO;
  lang: Lang;
  currency: string;
}) {
  const { t } = useT();
  const agg = shift.aggregates;
  return (
    <article className="relative overflow-hidden rounded-2xl border border-emerald-300/70 bg-linear-to-l from-emerald-50/90 to-teal-50/50 p-3 dark:border-emerald-500/30 dark:from-emerald-500/10 dark:to-teal-500/5">
      <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1">
        {/* pulsing live dot + the current-shift label + LIVE chip */}
        <span className="inline-flex shrink-0 items-center gap-1.5 text-[11.5px] font-extrabold text-emerald-800 dark:text-emerald-200">
          <span className="relative flex h-2 w-2" aria-hidden="true">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
          </span>
          {t("shiftWsOpenNow")}
        </span>
        <span className="inline-flex shrink-0 items-center rounded-full bg-emerald-500 px-2 py-0.5 text-[9.5px] font-extrabold text-white shadow-sm">
          {t("shiftBrowserLive")}
        </span>
        <span
          dir={idDir}
          className="inline-flex items-center gap-1 rounded-full border border-emerald-200/80 bg-white/75 px-2.5 py-0.5 font-mono text-[10.5px] font-extrabold text-emerald-700 dark:border-emerald-500/25 dark:bg-white/[0.06] dark:text-emerald-300"
        >
          <CatIcon name="hash" className="h-2.5 w-2.5" aria-hidden="true" />
          {fmtId(shift.code, lang)}
        </span>
        <span
          dir={numDir(lang)}
          className="ms-auto inline-flex shrink-0 items-center gap-1 rounded-full bg-white/80 px-2 py-0.5 text-[10.5px] font-extrabold text-emerald-700 dark:bg-white/[0.06] dark:text-emerald-300"
        >
          <CatIcon name="timer" className="h-3 w-3" aria-hidden="true" />
          {shiftElapsedLabel(lang, shift.openedAt)}
        </span>
      </div>

      {/* live aggregates */}
      <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-[10.5px] font-bold text-emerald-700/90 dark:text-emerald-300/80 sm:grid-cols-4">
        <span dir={numDir(lang)} className="inline-flex min-w-0 items-center gap-1">
          <CatIcon name="receipt" className="h-3 w-3 shrink-0" aria-hidden="true" />
          {t("shiftSalesCount", { count: fmtNum(agg.salesCount, lang) })}
        </span>
        <span dir={numDir(lang)} className="inline-flex min-w-0 items-center gap-1 font-extrabold text-emerald-800 dark:text-emerald-200">
          <CatIcon name="coins" className="h-3 w-3 shrink-0" aria-hidden="true" />
          {t("shiftSalesTotal", { total: fmtMoneyCell(agg.salesTotal, lang, currency) })}
        </span>
        <span dir={numDir(lang)} className="inline-flex min-w-0 items-center gap-1">
          <CatIcon name="banknote" className="h-3 w-3 shrink-0" aria-hidden="true" />
          {t("shiftAggCash")} {fmtMoneyCell(agg.cashTotal, lang, currency)}
        </span>
        <span dir={numDir(lang)} className="inline-flex min-w-0 items-center gap-1">
          <CatIcon name="credit-card" className="h-3 w-3 shrink-0" aria-hidden="true" />
          {t("shiftAggCard")} {fmtMoneyCell(agg.cardTotal, lang, currency)}
        </span>
      </div>

      <p className="mt-1.5 flex items-center gap-1 text-[10px] font-semibold text-emerald-600/80 dark:text-emerald-300/60">
        <CatIcon name="user-round" className="h-3 w-3 shrink-0" aria-hidden="true" />
        {t("shiftOpenedBy")} <span className="font-extrabold">{shift.openedBy}</span>
        <span className="shrink-0 text-emerald-500/60 dark:text-emerald-300/40">
          · {fullDate(shift.openedAt, lang)}
        </span>
      </p>
    </article>
  );
}

export function ShiftHistoryDialog({ open, onOpenChange, instance }: DialogProps) {
  const { t, lang } = useT();
  const { data, isPending } = useShift(instance.id);
  const currency = instance.org.currency;
  const history = data?.history ?? [];
  const current = data?.current ?? null;

  /* ROUND 134-A — ticking re-render while the browser pins a LIVE shift
   * card: the tick value is never read; each 30s tick just re-renders so
   * the elapsed label (computed at render time) keeps moving. */
  const [, setTick] = useState(0);
  const liveTick = open && !!current;
  useEffect(() => {
    if (!liveTick) return;
    const timer = window.setInterval(() => setTick(Date.now()), 30_000);
    return () => window.clearInterval(timer);
  }, [liveTick]);

  /* the header stats band — over the CLOSED shifts */
  const closedCount = history.length;
  const totalSales = round2(history.reduce((acc, s) => acc + s.aggregates.salesTotal, 0));
  const netVariance = round2(history.reduce((acc, s) => acc + (s.variance ?? 0), 0));
  const netVarianceText =
    netVariance === 0
      ? fmtMoneyCell(0, lang, currency)
      : `${netVariance > 0 ? "+" : "-"}${fmtMoneyCell(Math.abs(netVariance), lang, currency)}`;

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onOpenChange(o)}>
      <DialogContent
        dir={lang === "ar" ? "rtl" : "ltr"}
        className="flex max-h-[85vh] flex-col gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-2xl"
      >
        <ShiftHeader
          icon="clock-rotate-left"
          c1="#14b8a6"
          c2="#0d9488"
          title={t("shiftHistoryTitle")}
          desc={t("shiftBrowserDesc")}
        />
        <div className="nice-scroll min-h-0 flex-1 space-y-3 overflow-y-auto px-5 py-4">
          {isPending ? (
            <div className="grid place-items-center py-10">
              <CatIcon name="refresh-cw" className="h-5 w-5 animate-spin text-slate-400" />
            </div>
          ) : (
            <>
              {/* the header stats band */}
              <div className="grid grid-cols-3 gap-2">
                <BrowserStat
                  icon="clock-rotate-left"
                  label={t("shiftBrowserClosed")}
                  value={fmtNum(closedCount, lang)}
                  dir={numDir(lang)}
                  tone="violet"
                />
                <BrowserStat
                  icon="coins"
                  label={t("shiftBrowserSales")}
                  value={fmtMoneyCell(totalSales, lang, currency)}
                  dir={numDir(lang)}
                  tone="emerald"
                />
                <BrowserStat
                  icon="scale"
                  label={t("shiftBrowserVariance")}
                  value={netVarianceText}
                  dir={numDir(lang)}
                  tone={netVariance === 0 ? "emerald" : netVariance > 0 ? "amber" : "rose"}
                />
              </div>

              {/* the pinned LIVE current shift (when one is open) */}
              {current ? <CurrentShiftCard shift={current} lang={lang} currency={currency} /> : null}

              {history.length === 0 ? (
                /* the premium empty-state illustration tile */
                <div className="relative overflow-hidden rounded-2xl border border-slate-200/80 bg-linear-to-b from-slate-50 to-white px-6 py-10 text-center dark:border-white/10 dark:from-white/[0.05] dark:to-transparent">
                  <span
                    className="absolute -top-12 inset-x-0 mx-auto h-28 w-28 rounded-full bg-teal-500/15 blur-2xl"
                    aria-hidden="true"
                  />
                  <span
                    className="absolute -bottom-10 -end-6 h-20 w-20 rounded-full bg-violet-500/10 blur-xl"
                    aria-hidden="true"
                  />
                  <div
                    className="relative mx-auto grid h-16 w-16 place-items-center rounded-2xl text-white shadow-lg"
                    style={{ backgroundImage: grad("#14b8a6", "#0d9488") }}
                  >
                    <CatIcon name="clock-rotate-left" className="h-8 w-8" aria-hidden="true" />
                    <span className="absolute -end-1.5 -top-1.5 grid h-6 w-6 place-items-center rounded-full bg-white shadow-md dark:bg-slate-800">
                      <CatIcon name="sparkles" className="h-3 w-3 text-amber-500" aria-hidden="true" />
                    </span>
                  </div>
                  <p className="mt-4 text-[12.5px] font-bold text-slate-500 dark:text-slate-400">
                    {t("shiftHistoryEmpty")}
                  </p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {history.map((s) => (
                    <ShiftHistoryRow key={s.id} shift={s} lang={lang} currency={currency} />
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
