"use client";

/**
 * Ashrilogic — ROUND 133 (نظام الورديات): the SHARED shift-state hook.
 *
 * One react-query cache entry — `["shifts", instanceId]` — feeds the whole
 * client face of the strict shift system: the global status bar
 * (shift-status-bar.tsx), the open/close/code/history dialogs
 * (shift-dialogs.tsx), the topbar logout gate, the quick-add save gate and
 * the business-suite mutation gates (the principal's surface). Everyone
 * reads the same entry; mutations invalidate it and every gate flips in
 * the same tick.
 *
 * Money is DISPLAY UNITS everywhere on the client (the server DTO already
 * converted the integer minor units) — no minor-unit math here, ever.
 */
import { useQuery } from "@tanstack/react-query";
import { fetchShifts } from "@/lib/api-client";
import type { Lang } from "@/lib/types";
import { fmtNum } from "@/lib/utils";

/**
 * The workspace's live shift state: the open shift (with live aggregates),
 * the last 20 closed shifts, and whether the owner's secret shift code is
 * defined. `staleTime` 15s keeps the bar calm while still tracking the
 * drawer; every mutation path invalidates the key explicitly.
 *
 * ROUND 134 — the optional `enabled` flag mirrors the الورديات module
 * toggle: callers pass `instance.modules.includes("shifts")`; when false
 * the query stays idle (no request) and every gate that consults it
 * fails OPEN — exactly matching the server, whose shift gate is likewise
 * off while the module is disabled.
 */
export function useShift(instanceId: string | undefined, enabled = true) {
  return useQuery({
    queryKey: ["shifts", instanceId],
    queryFn: () => fetchShifts(instanceId as string),
    enabled: !!instanceId && enabled,
    staleTime: 15_000,
  });
}

/**
 * The h/m elapsed label shared by the status bar's live timer («منذ ٢س ١٥د»)
 * and the history rows' frozen durations. Locale digits via fmtNum; the
 * Arabic units are س (ساعات) / د (دقائق), every other locale gets h/m.
 * `toIso` freezes the window (history rows); live callers omit it and read
 * the clock at render time (their tick state drives the re-renders).
 */
export function shiftElapsedLabel(
  lang: Lang,
  fromIso: string,
  toIso?: string | null
): string {
  const from = new Date(fromIso).getTime();
  const to = toIso ? new Date(toIso).getTime() : Date.now();
  if (!Number.isFinite(from) || !Number.isFinite(to) || to <= from) {
    return lang === "ar" ? `${fmtNum(0, lang)}د` : `${fmtNum(0, lang)}m`;
  }
  const totalMinutes = Math.floor((to - from) / 60_000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  const hoursLabel =
    lang === "ar" ? `${fmtNum(hours, lang)}س` : `${fmtNum(hours, lang)}h`;
  const minutesLabel =
    lang === "ar" ? `${fmtNum(minutes, lang)}د` : `${fmtNum(minutes, lang)}m`;
  return hours > 0 ? `${hoursLabel} ${minutesLabel}` : minutesLabel;
}
