"use client";

/**
 * Ashrilogic — ROUND 133 (نظام الورديات): the GLOBAL SHIFT STATUS BAR.
 * ROUND 134-A — every one of the three states now carries the persistent
 * premium «عرض الورديات» ghost button (clock-rotate-left) opening the
 * upgraded ShiftHistoryDialog shifts browser (stats band + live pinned
 * current-shift card + closed-shift cards) — the R133 note that history
 * was reachable only in the OPEN state is closed.
 *
 * One compact row mounted in the dashboard shell right under the Topbar —
 * visible on EVERY view, the always-on face of the strict shift law:
 *
 *   a) codeSet === false → amber/violet «define the secret code first»;
 *   b) no open shift      → rose «operations are locked» + open CTA;
 *   c) shift open         → emerald live strip: pulsing dot, shift code,
 *      elapsed timer (ticks every 30s), live sales count + total, close /
 *      shifts-browser / code actions.
 *
 * All numbers render through fmtNum/fmtMoneyCell/fmtId with
 * dir={numDir(lang)} (the ROUND-133 full Arabic RTL display policy).
 * Nothing renders while the query loads (no layout flash).
 */
import { useEffect, useState } from "react";
import { useT } from "@/lib/i18n";
import type { InstanceDTO } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { cn, fmtId, fmtMoneyCell, fmtNum, grad, idDir, numDir } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { shiftElapsedLabel, useShift } from "@/components/dashboard/shift/use-shift";
import {
  ShiftCloseDialog,
  ShiftCodeDialog,
  ShiftHistoryDialog,
  ShiftOpenDialog,
} from "@/components/dashboard/shift/shift-dialogs";

/* The shared hook re-exported from its canonical surface so sibling views
 * (business-suite, topbar, quick-add…) can import it from either path. */
export { useShift } from "@/components/dashboard/shift/use-shift";

type ShiftDialogKind = "open" | "close" | "code" | "history" | null;

export function ShiftStatusBar({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  /* ROUND 134 — الورديات became a TOGGLEABLE module (الوحدات): the bar
   * (and the whole shift UI) only exists while the workspace has the
   * shifts module ENABLED. When disabled the server gate is off too —
   * the ops flow free and the bar renders nothing. */
  const shiftsEnabled = instance.modules.includes("shifts");
  const { data } = useShift(instance.id, shiftsEnabled);
  const [dialog, setDialog] = useState<ShiftDialogKind>(null);
  /* re-render tick — the value is never read; each tick just re-renders so
   * the elapsed label (computed at render time) stays fresh */
  const [, setNowTick] = useState(0);

  const current = data?.current ?? null;
  const codeSet = data?.codeSet ?? false;
  const currency = instance.org.currency;
  const rtl = lang === "ar";

  /* LIVE elapsed timer — only while a shift is open, one tick / 30s. */
  const openedAt = current?.openedAt;
  useEffect(() => {
    if (!openedAt) return;
    const timer = window.setInterval(() => setNowTick(Date.now()), 30_000);
    return () => window.clearInterval(timer);
  }, [openedAt]);

  /* While the shared query loads (or failed on a locked workspace) the bar
   * renders nothing — no layout flash, no dead chrome. ROUND 134: a
   * workspace with the shifts module disabled never renders the bar at
   * all (the API's moduleDisabled marker mirrors the server truth). */
  if (!shiftsEnabled || !data || data.moduleDisabled) return null;

  const closeDialog = () => setDialog(null);

  /* ------------------------------------------------------------------ */
  /* a) no secret code defined yet — amber/violet, define-it-first      */
  /* ------------------------------------------------------------------ */
  if (!codeSet) {
    return (
      <>
        <div
          dir={rtl ? "rtl" : "ltr"}
          className="mx-4 mt-4 flex flex-wrap items-center gap-x-3 gap-y-1.5 rounded-2xl border border-amber-300/60 bg-linear-to-l from-amber-50/90 to-violet-50/50 px-3.5 py-2 backdrop-blur-md sm:mx-6 lg:mx-8 dark:border-amber-500/25 dark:from-amber-500/10 dark:to-violet-500/5"
          role="status"
        >
          <span
            className="grid h-8 w-8 shrink-0 place-items-center rounded-xl text-white shadow-md"
            style={{ backgroundImage: grad("#f59e0b", "#8b5cf6") }}
            aria-hidden="true"
          >
            <CatIcon name="key-round" className="h-4 w-4" />
          </span>
          <p className="min-w-0 flex-1 text-[11.5px] font-extrabold text-amber-800 dark:text-amber-200">
            {t("shiftOpenNotSet")}
          </p>
          <Button
            type="button"
            onClick={() => setDialog("code")}
            className="h-8 shrink-0 rounded-lg bg-linear-to-l from-amber-500 to-violet-500 px-3 text-[11px] font-extrabold text-white shadow-lg shadow-amber-500/25 transition hover:brightness-110 active:scale-95"
          >
            <CatIcon name="key-round" className="h-3.5 w-3.5" />
            {t("shiftBarCodeBtn")}
          </Button>
          {/* ROUND 134-A — the persistent premium shifts browser entry */}
          <Button
            type="button"
            variant="ghost"
            onClick={() => setDialog("history")}
            className="h-8 shrink-0 gap-1.5 rounded-lg px-2.5 text-[11px] font-bold text-amber-700/90 transition hover:bg-amber-50 hover:text-amber-800 active:scale-95 dark:text-amber-300/80 dark:hover:bg-amber-500/10"
          >
            <CatIcon name="clock-rotate-left" className="h-3.5 w-3.5" />
            {t("shiftBarBrowseBtn")}
          </Button>
        </div>
        <ShiftCodeDialog open={dialog === "code"} onOpenChange={closeDialog} instance={instance} />
        <ShiftHistoryDialog open={dialog === "history"} onOpenChange={closeDialog} instance={instance} />
      </>
    );
  }

  /* ------------------------------------------------------------------ */
  /* b) no open shift — rose, operations locked                          */
  /* ------------------------------------------------------------------ */
  if (!current) {
    return (
      <>
        <div
          dir={rtl ? "rtl" : "ltr"}
          className="mx-4 mt-4 flex flex-wrap items-center gap-x-3 gap-y-1.5 rounded-2xl border border-rose-300/60 bg-linear-to-l from-rose-50/90 to-orange-50/50 px-3.5 py-2 backdrop-blur-md sm:mx-6 lg:mx-8 dark:border-rose-500/25 dark:from-rose-500/10 dark:to-orange-500/5"
          role="status"
        >
          <span
            className="grid h-8 w-8 shrink-0 place-items-center rounded-xl text-white shadow-md"
            style={{ backgroundImage: grad("#f43f5e", "#e11d48") }}
            aria-hidden="true"
          >
            <CatIcon name="lock" className="h-4 w-4" />
          </span>
          <p className="min-w-0 text-[11.5px] font-bold text-rose-700 dark:text-rose-300">
            {t("shiftBarClosed")}
            <span className="ms-1.5 font-extrabold">{t("shiftBarLocked")}</span>
          </p>
          <p className="min-w-0 flex-1 text-[10.5px] font-semibold leading-snug text-rose-500/90 dark:text-rose-300/70">
            {t("shiftBarLockedHint")}
          </p>
          <Button
            type="button"
            onClick={() => setDialog("open")}
            className="h-8 shrink-0 rounded-lg bg-linear-to-l from-rose-500 to-orange-500 px-3 text-[11px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:brightness-110 active:scale-95"
          >
            <CatIcon name="unlock" className="h-3.5 w-3.5" />
            {t("shiftBarOpenBtn")}
          </Button>
          {/* ROUND 134-A — the persistent premium shifts browser entry
              (the closed/locked state exposes the history too) */}
          <Button
            type="button"
            variant="ghost"
            onClick={() => setDialog("history")}
            className="h-8 shrink-0 gap-1.5 rounded-lg px-2.5 text-[11px] font-bold text-rose-700/90 transition hover:bg-rose-50 hover:text-rose-800 active:scale-95 dark:text-rose-300/80 dark:hover:bg-rose-500/10"
          >
            <CatIcon name="clock-rotate-left" className="h-3.5 w-3.5" />
            {t("shiftBarBrowseBtn")}
          </Button>
        </div>
        <ShiftOpenDialog open={dialog === "open"} onOpenChange={closeDialog} instance={instance} />
        <ShiftHistoryDialog open={dialog === "history"} onOpenChange={closeDialog} instance={instance} />
      </>
    );
  }

  /* ------------------------------------------------------------------ */
  /* c) shift open — the emerald live strip                              */
  /* ------------------------------------------------------------------ */
  const agg = current.aggregates;
  return (
    <>
      <div
        dir={rtl ? "rtl" : "ltr"}
        className="mx-4 mt-4 flex flex-wrap items-center gap-x-3 gap-y-1.5 rounded-2xl border border-emerald-300/60 bg-linear-to-l from-emerald-50/90 to-teal-50/50 px-3.5 py-2 backdrop-blur-md sm:mx-6 lg:mx-8 dark:border-emerald-500/25 dark:from-emerald-500/10 dark:to-teal-500/5"
        role="status"
      >
        <span
          className="grid h-8 w-8 shrink-0 place-items-center rounded-xl text-white shadow-md"
          style={{ backgroundImage: grad("#10b981", "#059669") }}
          aria-hidden="true"
        >
          <CatIcon name="door-open" className="h-4 w-4" />
        </span>

        {/* pulsing live dot + open label */}
        <span className="inline-flex shrink-0 items-center gap-1.5 text-[11.5px] font-extrabold text-emerald-800 dark:text-emerald-200">
          <span className="relative flex h-2 w-2" aria-hidden="true">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
          </span>
          {t("shiftBarOpen")}
        </span>

        {/* the shift code chip (fmtId + numeric direction) */}
        <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-emerald-200/80 bg-white/75 px-2.5 py-0.5 dark:border-emerald-500/25 dark:bg-white/[0.06]">
          <CatIcon name="hash" className="h-2.5 w-2.5 text-emerald-500" aria-hidden="true" />
          <span className="text-[9.5px] font-extrabold uppercase text-emerald-600/80 dark:text-emerald-300/80">
            {t("shiftCodeLabel")}
          </span>
          <span dir={idDir} className="font-mono text-[10.5px] font-extrabold text-emerald-700 dark:text-emerald-300">
            {fmtId(current.code, lang)}
          </span>
        </span>

        {/* live elapsed timer */}
        <span className="inline-flex shrink-0 items-center gap-1 text-[10.5px] font-bold text-emerald-700/90 dark:text-emerald-300/80">
          <CatIcon name="clock" className="h-3 w-3" aria-hidden="true" />
          <span dir={numDir(lang)}>{t("shiftBarOpenSince", { time: shiftElapsedLabel(lang, current.openedAt) })}</span>
        </span>

        {/* live sales stats */}
        <span className="inline-flex shrink-0 items-center gap-1 text-[10.5px] font-bold text-emerald-700/90 dark:text-emerald-300/80">
          <CatIcon name="receipt" className="h-3 w-3" aria-hidden="true" />
          <span dir={numDir(lang)}>{t("shiftSalesCount", { count: fmtNum(agg.salesCount, lang) })}</span>
        </span>
        <span className="inline-flex shrink-0 items-center gap-1 text-[10.5px] font-extrabold text-emerald-800 dark:text-emerald-200">
          <CatIcon name="coins" className="h-3 w-3" aria-hidden="true" />
          <span dir={numDir(lang)}>{t("shiftSalesTotal", { total: fmtMoneyCell(agg.salesTotal, lang, currency) })}</span>
        </span>

        {/* actions */}
        <span className="ms-auto flex shrink-0 items-center gap-1.5">
          <Button
            type="button"
            onClick={() => setDialog("close")}
            className={cn(
              "h-8 gap-1.5 rounded-lg border px-3 text-[11px] font-extrabold transition active:scale-95",
              "border-emerald-300/80 bg-white/85 text-emerald-700 hover:bg-emerald-50",
              "dark:border-emerald-500/30 dark:bg-white/[0.07] dark:text-emerald-300 dark:hover:bg-white/[0.12]"
            )}
          >
            <CatIcon name="door-closed" className="h-3.5 w-3.5" />
            {t("shiftBarCloseBtn")}
          </Button>
          <Button
            type="button"
            variant="ghost"
            onClick={() => setDialog("history")}
            className="h-8 gap-1.5 rounded-lg px-2.5 text-[11px] font-bold text-emerald-700/90 hover:bg-emerald-50 hover:text-emerald-800 active:scale-95 dark:text-emerald-300/80 dark:hover:bg-emerald-500/10"
          >
            <CatIcon name="clock-rotate-left" className="h-3.5 w-3.5" />
            {t("shiftBarBrowseBtn")}
          </Button>
          <button
            type="button"
            onClick={() => setDialog("code")}
            aria-label={t("shiftBarCodeBtn")}
            title={t("shiftBarCodeBtn")}
            className="grid h-8 w-8 place-items-center rounded-lg text-emerald-600/80 transition hover:bg-emerald-50 hover:text-emerald-700 active:scale-95 dark:text-emerald-300/70 dark:hover:bg-emerald-500/10"
          >
            <CatIcon name="key-round" className="h-3.5 w-3.5" />
          </button>
        </span>
      </div>

      <ShiftOpenDialog open={dialog === "open"} onOpenChange={closeDialog} instance={instance} />
      <ShiftCloseDialog open={dialog === "close"} onOpenChange={closeDialog} instance={instance} />
      <ShiftCodeDialog open={dialog === "code"} onOpenChange={closeDialog} instance={instance} />
      <ShiftHistoryDialog open={dialog === "history"} onOpenChange={closeDialog} instance={instance} />
    </>
  );
}

export default ShiftStatusBar;
