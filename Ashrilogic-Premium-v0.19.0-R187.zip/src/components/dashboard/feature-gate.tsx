"use client";

/**
 * ROUND 79 (UI-A) — FeatureGate premium lock screens.
 *
 * The server decides feature access (403 FEATURE_NOT_IN_PLAN via
 * featureGateResponse — src/lib/server/entitlement.ts); this component is
 * the client MIRROR ONLY: it renders the workspace's surfaces when the
 * feature is on, and a premium violet→fuchsia lock card with an upgrade
 * CTA when it is off. Two variants:
 *
 *  · full    — a whole-view lock screen (mirrors the ROUND 78 role-preview
 *              lock screen in dashboard-app.tsx visually);
 *  · compact — a slim inline banner for embedded panels/sections (coupons,
 *              reviews, AI insights, backup, data export).
 *
 * The upgrade CTA switches the dashboard to the billing view by default
 * (setDashView("billing")); callers may pass their own onUpgrade.
 *
 * IMPORTANT: a LOCKED workspace (expired trial/plan) must still reach the
 * billing view — dashboard-app forces activeView==="billing" while locked,
 * so these gates only ever render for active/trial workspaces.
 */
import type { ReactNode } from "react";
import { useT } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import { FEATURE_META, type PlanFeature } from "@/lib/plan-features";
import type { InstanceDTO } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { cn, grad } from "@/lib/utils";
import { Button } from "@/components/ui/button";

/**
 * Icon names per catalog feature. FEATURE_META carries the catalog icon
 * names; "file-down" is not part of the shared registry (src/lib/icons.ts),
 * so dataExport maps to the "download" glyph instead. ROUND 80 adds the
 * premium module family (all icons verified in the shared registry).
 */
const FEATURE_ICON: Record<PlanFeature, string> = {
  publicWebsite: "globe",
  store: "store",
  coupons: "ticket-percent",
  reviews: "star",
  aiInsights: "sparkles",
  translations: "languages",
  backup: "database-backup",
  dataExport: "download",
  /* ROUND 80 — premium module family */
  pos: "calculator",
  barcode: "barcode",
  loyalty: "heart",
  subscriptions: "repeat",
  staff: "users",
  branches: "network",
  insurance: "shield-check",
  telemedicine: "video",
};

const LOCK_GRAD = { c1: "#8b5cf6", c2: "#d946ef" } as const;

/** Client mirror of the server's feature decision (never for access). */
export function useFeatureEnabled(instance: InstanceDTO, feature: PlanFeature): boolean {
  return instance.entitlement?.features?.[feature] === true;
}

export function FeatureGate({
  feature,
  instance,
  onUpgrade,
  children,
  title,
  compact = false,
}: {
  /** the catalog feature this surface belongs to */
  feature: PlanFeature;
  /** the live workspace (entitlement.features is server truth) */
  instance: InstanceDTO;
  /** override for the default "switch to the billing view" CTA */
  onUpgrade?: () => void;
  /** rendered untouched while the feature is enabled */
  children?: ReactNode;
  /** optional headline override for the lock card */
  title?: string;
  /** slim inline banner instead of the full-view lock screen */
  compact?: boolean;
}) {
  const { t, lang } = useT();
  const setDashView = useAppStore((s) => s.setDashView);

  const ent = instance.entitlement;
  if (ent?.features?.[feature] === true) {
    return <>{children}</>;
  }

  const meta = FEATURE_META[feature];
  const icon = FEATURE_ICON[feature] ?? meta.icon;
  const featureLabel = t(meta.labelKey);
  const pkg = instance.package ?? null;
  const planName = pkg ? (lang === "ar" ? pkg.nameAr : pkg.nameEn) : t("billingNoPlan");
  /* during the 14-Day Full-Access window a locked feature can only be a
   * platform force-OFF override — the shorter trial body fits that case */
  const body =
    ent?.state === "trial"
      ? t("featLockedTrialBody", { feature: featureLabel })
      : t("featLockedBody", { plan: planName, feature: featureLabel });
  const headline = title ?? t("featLockedTitle");
  const goBilling = onUpgrade ?? (() => setDashView("billing"));

  if (compact) {
    /* slim inline banner for embedded panels — 44px touch target on the CTA */
    return (
      <div
        role="status"
        className="card-in flex flex-wrap items-center gap-3 rounded-2xl border border-violet-300/60 bg-linear-to-l from-violet-50/90 to-fuchsia-50/50 p-3.5 dark:border-violet-500/25 dark:from-violet-500/10 dark:to-fuchsia-500/5"
      >
        <span
          className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-md"
          style={{ backgroundImage: grad(LOCK_GRAD.c1, LOCK_GRAD.c2) }}
          aria-hidden="true"
        >
          <CatIcon name={icon} className="h-[17px] w-[17px]" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[12.5px] font-extrabold text-violet-800 dark:text-violet-200">
            {featureLabel} · {headline}
          </p>
          <p className="mt-0.5 text-[11px] font-semibold leading-relaxed text-violet-700/80 dark:text-violet-300/80">
            {body}
          </p>
        </div>
        <Button
          type="button"
          onClick={goBilling}
          className="h-11 shrink-0 gap-1.5 rounded-xl bg-linear-to-l from-violet-600 to-fuchsia-500 px-4 text-[12px] font-extrabold text-white shadow-lg shadow-violet-500/25 transition hover:brightness-110 active:scale-95"
        >
          <CatIcon name="trending-up" className="h-3.5 w-3.5" />
          {t("featUpgradeCta")}
        </Button>
      </div>
    );
  }

  /* full-view premium lock screen (mirrors the ROUND 78 preview lock) */
  return (
    <div className="grid min-h-[52vh] place-items-center">
      <div className="glass-card card-in max-w-md rounded-3xl p-8 text-center">
        <span
          className="mx-auto grid h-16 w-16 place-items-center rounded-2xl text-white shadow-xl"
          style={{
            backgroundImage: grad(LOCK_GRAD.c1, LOCK_GRAD.c2),
            boxShadow: "0 12px 30px -10px #8b5cf666",
          }}
          aria-hidden="true"
        >
          <CatIcon name={icon} className="h-7 w-7" />
        </span>
        <h3 className="mt-5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
          {headline}
        </h3>
        <p className="mt-2 text-[12.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
          {body}
        </p>
        <Button
          type="button"
          onClick={goBilling}
          className="mt-5 h-11 gap-2 rounded-xl bg-linear-to-l from-violet-600 to-fuchsia-500 px-6 text-[12.5px] font-extrabold text-white shadow-lg shadow-violet-500/25 transition hover:brightness-110 active:scale-95"
        >
          <CatIcon name="trending-up" className="h-4 w-4" />
          {t("featUpgradeCta")}
        </Button>
        <p
          className={cn(
            "mt-3 flex items-center justify-center gap-1.5 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500",
          )}
        >
          <CatIcon name="lock" className="h-3 w-3 shrink-0" />
          {t("featLockedHint")}
        </p>
      </div>
    </div>
  );
}

export default FeatureGate;
