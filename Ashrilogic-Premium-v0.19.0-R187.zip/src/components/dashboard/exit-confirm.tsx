"use client";

/**
 * Ashrilogic — dashboard exit flow (sidebar button + user menu logout).
 * Logs a real actExit activity, refreshes the instances list and returns
 * to the landing page. Uses shadcn AlertDialog (resolves reliably).
 */
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useT } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import { addActivity, instanceLogout } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export function useExitInstance(instanceId: string) {
  const exitToLanding = useAppStore((s) => s.exitToLanding);
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: () => addActivity(instanceId, "actExit"),
    onSettled: () => {
      // exit regardless of whether the activity log call succeeded; also
      // clear the workspace session (sign-out on exit), fire-and-forget.
      void instanceLogout(instanceId).catch(() => undefined);
      queryClient.invalidateQueries({ queryKey: ["instances"] });
      queryClient.removeQueries({ queryKey: ["instance", instanceId] });
      exitToLanding();
    },
  });
}

export function ExitConfirmDialog({
  open,
  onOpenChange,
  onConfirm,
  pending,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: () => void;
  pending: boolean;
}) {
  const { t, lang } = useT();

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"}>
        <AlertDialogHeader>
          <AlertDialogTitle>{t("dlgExitTitle")}</AlertDialogTitle>
          <AlertDialogDescription>{t("dlgExitMsg")}</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={pending}>{t("dlgCancel")}</AlertDialogCancel>
          <AlertDialogAction
            onClick={(e) => {
              e.preventDefault(); // keep the dialog open while pending
              onConfirm();
            }}
            className="gap-2 bg-destructive text-white hover:bg-destructive/90"
          >
            {pending ? <CatIcon name="refresh-cw" className="h-3.5 w-3.5 animate-spin" /> : null}
            {t("dlgExitConfirmBtn")}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
