"use client";

/**
 * Ashrilogic — dashboard sidebar.
 *
 * Desktop (lg+): a fixed rail on the start side with a PREMIUM auto-collapse
 * behavior — pinned (default) it stays at full width (w-64) with labels;
 * unpinned it collapses to an icon-only rail (w-16) when the pointer leaves
 * and re-expands to full width when the pointer re-enters. The pin/unpin
 * toggle persists in localStorage so a user's preference survives reloads.
 * Hovering only changes the rail's WIDTH (an overlay expansion), so the main
 * content's padding never shifts on hover — only when the user flips the pin.
 *
 * Mobile: a Sheet from the start side (controlled by the store's
 * `sidebarOpen`). The auto-collapse is desktop-only — the mobile sheet
 * always renders the EXPANDED content (full labels) and opens/closes on tap.
 */
import { useState } from "react";
import { MODULE_MAP, SYSTEM_MAP, moduleDisplayName, teamDisplayName } from "@/data/catalog";
import { MODULE_FEATURE_GATES } from "@/lib/plan-features";
import { useT, type I18nKey } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import type { DashView, InstanceDTO } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { useAccentPair } from "@/components/dashboard/accent-context";
import { grad, cn } from "@/lib/utils";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { SidebarFoldToggle } from "@/components/shared/sidebar-fold-toggle";
import { ExitConfirmDialog, useExitInstance } from "@/components/dashboard/exit-confirm";
import {
  planTermLeftText,
  planTermTone,
  trialCountdownText,
  trialCountdownTone,
  type PlanTermTone,
  type TrialUrgency,
} from "@/components/dashboard/smart-countdown";

interface NavItem {
  id: DashView;
  labelKey: I18nKey;
  icon: string;
}

/* ROUND 141 (directive ㉔) — the PREMIUM sidebar organization: semantically
 * GROUPED sections instead of two flat lists. نظرة عامة leads standalone;
 * الوحدات — the workspace's heart — follows FIRST with the per-module
 * buttons and their LIVE license badges; then the insight reads, the
 * commerce surfaces, the people surfaces, the subscription pair, and the
 * system console terminates the list (the universal convention).
 * The per-module entries now mirror the strict license law: a module
 * gated behind a feature the workspace lacks renders LOCKED and routes to
 * billing (the modules-view precedent) — the sidebar can no longer open
 * an unpaid module's workspace. */
const INSIGHTS_NAV: NavItem[] = [
  { id: "analytics", labelKey: "dashAnalytics", icon: "chart-line" },
  /* ROUND 143 — الإشعارات المتخصصة: the dedicated live notification center
   * (member signups · orders · payments · renewals · packages · add-ons ·
   * wallet) replaces the old flat «التقارير» page. */
  { id: "notifications", labelKey: "dashNotifications", icon: "bell" },
  { id: "activity", labelKey: "dashActivity", icon: "clock-rotate-left" },
];

const STORE_NAV: NavItem[] = [
  { id: "website", labelKey: "dashWebsite", icon: "globe" },
  /* ROUND 44 — the E-Store is a first-class console page, separated from
     the public website builder (المتجر الإلكتروني). */
  { id: "store", labelKey: "dashStore", icon: "store" },
  /* ROUND 114 — the order-event webhook console (تكاملات الطلبات). */
  { id: "webhooks", labelKey: "dashWebhooks", icon: "webhook" },
];

const PEOPLE_NAV: NavItem[] = [
  { id: "customers", labelKey: "dashCustomers", icon: "users-round" },
  { id: "team", labelKey: "dashTeam", icon: "users" },
];

const SUBSCRIPTION_NAV: NavItem[] = [
  { id: "billing", labelKey: "dashBilling", icon: "credit-card" },
  /* ROUND 141 — متجر الإضافات: buy features outside the subscription
     package — right after billing, the natural upsell slot. */
  { id: "addons", labelKey: "dashAddons", icon: "puzzle" },
];

const SYSTEM_NAV: NavItem[] = [
  { id: "settings", labelKey: "dashSettings", icon: "sliders" },
  /* ROUND 87 — the workspace trash (سلة المحذوفات). */
  { id: "trash", labelKey: "trashTitle", icon: "trash-2" },
];

/** One premium GROUP header: the tiny brand dot + the micro label. */
function NavGroupHeader({ labelKey, collapsed }: { labelKey: I18nKey; collapsed: boolean }) {
  const { t } = useT();
  if (collapsed) {
    /* the rail is icon-only — keep a 1px brand-tinted separator so the
     * groups stay visually distinct without consuming horizontal space. */
    return (
      <div className="my-2 ms-3 h-px w-6 rounded-full bg-slate-200/80 dark:bg-white/[0.08]" aria-hidden="true" />
    );
  }
  return (
    <p className="flex items-center gap-1.5 px-3 pb-2 pt-1 text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
      <span className="h-1 w-1 rounded-full bg-linear-to-br from-brand-500 to-fuchsia-500" aria-hidden="true" />
      {t(labelKey)}
    </p>
  );
}

function NavButton({
  item,
  badge,
  locked,
  onClick,
  labelOverride,
  collapsed,
}: {
  item: NavItem;
  badge?: number;
  /** ROUND 47 — trial-lock: locked surfaces are disabled (billing stays live) */
  locked?: boolean;
  onClick: () => void;
  /** ROUND 65 — sector-aware label (teamDisplayName) beats the generic key */
  labelOverride?: string;
  /** premium auto-collapse — render an icon-only rail when true */
  collapsed?: boolean;
}) {
  const { t } = useT();
  const active = useAppStore((s) => s.dashView) === item.id;
  const labelText = labelOverride ?? t(item.labelKey);
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={locked}
      aria-disabled={locked || undefined}
      aria-current={active ? "page" : undefined}
      aria-label={collapsed ? labelText : undefined}
      title={collapsed ? (locked ? t("lockedSidebarHint") : labelText) : locked ? t("lockedSidebarHint") : undefined}
      className={cn(
        "group relative flex w-full items-center rounded-xl text-[12.5px] font-bold transition",
        collapsed ? "justify-center px-0 py-2.5" : "gap-3 px-3 py-2.5",
        active
          ? "bg-brand-500/10 text-brand-600 shadow-[0_0_18px_-6px_rgba(109,93,251,0.45)] dark:text-brand-300 dark:shadow-[0_0_18px_-6px_rgba(139,120,255,0.4)]"
          : "text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-white/[0.06] dark:hover:text-white",
        locked && "cursor-not-allowed opacity-40 hover:bg-transparent dark:hover:bg-transparent"
      )}
    >
      {active ? (
        <span
          className={cn(
            "absolute inset-y-1.5 w-[3px] rounded-full bg-linear-to-b from-brand-500 to-fuchsia-500",
            collapsed ? "start-0.5" : "start-0"
          )}
          aria-hidden="true"
        />
      ) : null}
      <CatIcon name={item.icon} className="h-4 w-4 shrink-0" />
      {collapsed ? null : (
        <>
          <span className="flex-1 truncate text-start">{labelText}</span>
          {locked ? (
            <CatIcon name="lock" className="h-3 w-3 shrink-0 text-slate-400" aria-hidden="true" />
          ) : badge !== undefined ? (
            <span className="rounded-full bg-brand-500/15 px-2 py-0.5 text-[10px] font-extrabold text-brand-600 dark:text-brand-300">
              {badge}
            </span>
          ) : null}
        </>
      )}
    </button>
  );
}

function SidebarContent({
  instance,
  onExit,
  isPinned,
  onTogglePin,
  isHovered,
}: {
  instance: InstanceDTO;
  onExit: () => void;
  /** sidebar stays full-width regardless of hover (the manual override) */
  isPinned: boolean;
  onTogglePin: () => void;
  /** pointer is currently over the rail (only meaningful when unpinned) */
  isHovered: boolean;
}) {
  const { t, lang } = useT();
  const setDashView = useAppStore((s) => s.setDashView);
  const setSidebarOpen = useAppStore((s) => s.setSidebarOpen);
  const dashView = useAppStore((s) => s.dashView);
  const activeModuleId = useAppStore((s) => s.activeModuleId);
  const setActiveModuleId = useAppStore((s) => s.setActiveModuleId);

  const system = SYSTEM_MAP[instance.systemId];
  /* ROUND 143 — the shell-wide effective accent: an owner-picked dashTheme
   * recolors the ENTIRE system (sidebar header/tiles included); the default
   * violet keeps the historical category identity byte-for-byte. */
  const { c1, c2 } = useAccentPair();
  const sysName = system ? (lang === "ar" ? system.nameAr : system.nameEn) : instance.systemId;
  /* ROUND 45 — the workspace's brand identity (settings-managed) leads the
   * header when present; the system icon remains the fallback. */
  const brandLogo = instance.site?.logoUrl || "";

  /* ROUND 47 → ROUND 79 — entitlement mirror (server-computed on every
   * read): smart trial/plan countdown chips + locked nav states (billing
   * and auth stay available). */
  const entitlement = instance.entitlement;
  const isLocked = entitlement?.state === "locked";
  const isTrial = entitlement?.state === "trial";
  /* ROUND 141 — the Add-ons Store stays live while locked (the same law
   * as billing: buying add-ons is a subscription-adjacent action). */
  const navLocked = (view: DashView) => isLocked && view !== "billing" && view !== "addons";

  /* ROUND 79 — W2 smart countdown (Arabic dual forms) + urgency tone:
   * >2 days amber · ≤2 days rose + subtle pulse · last-day hours stronger. */
  const urgency = trialCountdownTone(entitlement);
  const trialCountdown = trialCountdownText(entitlement, lang, t);
  const TRIAL_TONE: Record<TrialUrgency, { shell: string; title: string; sub: string; iconBg: string; icon: string }> = {
    amber: {
      shell:
        "border-amber-300/60 bg-linear-to-l from-amber-50 to-orange-50/60 dark:border-amber-500/30 dark:from-amber-500/10 dark:to-orange-500/5",
      title: "text-amber-700 dark:text-amber-300",
      sub: "text-amber-600/90 dark:text-amber-400/90",
      iconBg: "linear-gradient(135deg,#f59e0b,#d97706)",
      icon: "clock",
    },
    rose: {
      shell:
        "border-rose-300/60 bg-linear-to-l from-rose-50 to-red-50/60 animate-pulse dark:border-rose-500/30 dark:from-rose-500/10 dark:to-red-500/5",
      title: "text-rose-700 dark:text-rose-300",
      sub: "text-rose-600/90 dark:text-rose-400/90",
      iconBg: "linear-gradient(135deg,#f43f5e,#e11d48)",
      icon: "clock",
    },
    critical: {
      shell:
        "border-rose-400/70 bg-linear-to-l from-rose-50 to-red-50/70 animate-pulse shadow-[0_0_20px_-6px_rgba(244,63,94,0.45)] dark:border-rose-500/40 dark:from-rose-500/15 dark:to-red-500/10",
      title: "text-rose-700 dark:text-rose-300",
      sub: "text-rose-600 dark:text-rose-400",
      iconBg: "linear-gradient(135deg,#f43f5e,#e11d48)",
      icon: "hourglass",
    },
  };
  const trialTone = TRIAL_TONE[urgency];

  /* ROUND 79 — W2 plan-term chip variant (active + stamped term):
   * emerald >7d → amber ≤7d → rose ≤2d. */
  const planTermChip =
    !isTrial && !isLocked && entitlement?.planExpiresAt ? planTermLeftText(entitlement, lang, t) : null;
  const PLAN_TONE: Record<PlanTermTone, { shell: string; title: string; sub: string; iconBg: string }> = {
    emerald: {
      shell:
        "border-emerald-300/60 bg-linear-to-l from-emerald-50 to-teal-50/60 dark:border-emerald-500/30 dark:from-emerald-500/10 dark:to-teal-500/5",
      title: "text-emerald-700 dark:text-emerald-300",
      sub: "text-emerald-600/90 dark:text-emerald-400/90",
      iconBg: "linear-gradient(135deg,#10b981,#059669)",
    },
    amber: {
      shell:
        "border-amber-300/60 bg-linear-to-l from-amber-50 to-orange-50/60 dark:border-amber-500/30 dark:from-amber-500/10 dark:to-orange-500/5",
      title: "text-amber-700 dark:text-amber-300",
      sub: "text-amber-600/90 dark:text-amber-400/90",
      iconBg: "linear-gradient(135deg,#f59e0b,#d97706)",
    },
    rose: {
      shell:
        "border-rose-300/60 bg-linear-to-l from-rose-50 to-red-50/60 dark:border-rose-500/30 dark:from-rose-500/10 dark:to-red-500/5",
      title: "text-rose-700 dark:text-rose-300",
      sub: "text-rose-600/90 dark:text-rose-400/90",
      iconBg: "linear-gradient(135deg,#f43f5e,#e11d48)",
    },
  };
  const planTone = PLAN_TONE[planTermTone(entitlement)];

  /* the rail is collapsed ONLY when unpinned AND not hovered — pinned or
   * hovered both render the full-width labels (hover expands as an
   * overlay so the main content never shifts on hover). */
  const collapsed = !isPinned && !isHovered;

  const navigate = (view: DashView) => {
    setDashView(view);
    setSidebarOpen(false); // close the mobile sheet
  };

  return (
    <div className="flex h-full flex-col">
      {/* header — collapses to the brand icon + pin toggle when the rail
          is collapsed; the full text returns as soon as it expands. */}
      <div
        className={cn(
          "flex h-16 shrink-0 items-center justify-between border-b border-slate-200/70 dark:border-white/[0.07]",
          collapsed ? "px-2" : "px-4"
        )}
      >
        <div className={cn("flex min-w-0 items-center", collapsed ? "w-full justify-center" : "gap-2.5")}>
          {brandLogo ? (
            <span
              className="grid h-10 w-10 shrink-0 place-items-center overflow-hidden rounded-xl border border-slate-200/80 bg-white shadow-lg dark:border-white/10 dark:bg-white/90"
              aria-hidden="true"
            >
              <img src={brandLogo} alt="" className="h-full w-full object-contain p-1" />
            </span>
          ) : (
            <span
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg"
              style={{ backgroundImage: grad(c1, c2) }}
            >
              <CatIcon name={system?.icon ?? "boxes"} className="h-[14px] w-[14px]" />
            </span>
          )}
          {collapsed ? null : (
            <div className="min-w-0 leading-none">
              {/* ROUND 166 — tenant isolation: the TENANT BUSINESS NAME leads
                  the sidebar header (the workspace belongs to the tenant's
                  business, not to the platform's system taxonomy); the system
                  name moves to the secondary line as navigational context. */}
              <p className="max-w-[140px] truncate font-display text-[13px] font-extrabold text-slate-900 dark:text-white">
                {instance.org.name}
              </p>
              <p className="mt-0.5 max-w-[140px] truncate text-[10px] font-semibold text-slate-500 dark:text-slate-400">
                {sysName}
              </p>
            </div>
          )}
        </div>
        {/* ROUND 164 — the PREMIUM (طي / فتح) toggle: a color-morphing
            (red = fold · green = open) pill that replaces the old pin lock.
            The committed pin state and its localStorage persistence are
            unchanged — this is the same law with a precise premium affordance. */}
        <SidebarFoldToggle
          isPinned={isPinned}
          onToggle={onTogglePin}
          collapsed={collapsed}
          className={cn("transition-[margin] duration-300", collapsed && "mt-2")}
        />
        <button
          type="button"
          onClick={() => setSidebarOpen(false)}
          aria-label={t("ariaCloseMenu")}
          className="relative grid h-8 w-8 shrink-0 place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100 dark:hover:bg-white/5 before:absolute before:-inset-[6px] before:content-[''] lg:hidden"
        >
          <CatIcon name="x" className="h-[13px] w-[13px]" />
        </button>
      </div>

      {/* ROUND 47 → ROUND 79 — trial chip: «وصول كامل» framing + the smart
          Arabic countdown with urgency tones (≤2d rose + pulse, hours stronger).
          Collapsed rail hides the chip block entirely — it returns on hover. */}
      {isTrial && !collapsed ? (
        <button
          type="button"
          onClick={() => navigate("billing")}
          className={cn(
            "mx-3 mt-3 flex items-center gap-2.5 rounded-2xl border px-3 py-2.5 text-start transition hover:brightness-[0.98]",
            trialTone.shell,
          )}
        >
          <span
            className="relative grid h-8 w-8 shrink-0 place-items-center rounded-xl text-white shadow-md"
            style={{ backgroundImage: trialTone.iconBg }}
            aria-hidden="true"
          >
            <CatIcon name={trialTone.icon} className="h-3.5 w-3.5" />
            {urgency !== "amber" ? (
              <span className="absolute -end-0.5 -top-0.5 flex h-2.5 w-2.5" aria-hidden="true">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-white/80" />
                <span className="relative inline-flex h-2.5 w-2.5 rounded-full border-2 border-rose-500 bg-white" />
              </span>
            ) : null}
          </span>
          <span className="min-w-0 flex-1">
            <span className={cn("block text-[11px] font-extrabold", trialTone.title)}>
              {t("trialFullAccessShort")}
            </span>
            <span className={cn("block truncate text-[10px] font-bold", trialTone.sub)}>
              {trialCountdown ?? t("trialBadge")}
            </span>
          </span>
          <CatIcon name="chevron-left" className={cn("h-3.5 w-3.5 shrink-0 rtl:rotate-0 ltr:rotate-180", trialTone.sub)} aria-hidden="true" />
        </button>
      ) : null}

      {/* ROUND 79 — W2 plan-term chip (active workspace with a stamped paid
          term): «ينتهي الاشتراك خلال …» with emerald → amber → rose tones */}
      {planTermChip && !collapsed ? (
        <button
          type="button"
          onClick={() => navigate("billing")}
          className={cn(
            "mx-3 mt-3 flex items-center gap-2.5 rounded-2xl border px-3 py-2.5 text-start transition hover:brightness-[0.98]",
            planTone.shell,
          )}
        >
          <span
            className="grid h-8 w-8 shrink-0 place-items-center rounded-xl text-white shadow-md"
            style={{ backgroundImage: planTone.iconBg }}
            aria-hidden="true"
          >
            <CatIcon name="calendar-range" className="h-3.5 w-3.5" />
          </span>
          <span className="min-w-0 flex-1">
            <span className={cn("block truncate text-[11px] font-extrabold", planTone.title)}>
              {instance.package ? (lang === "ar" ? instance.package.nameAr : instance.package.nameEn) : t("dashBilling")}
            </span>
            <span className={cn("block truncate text-[10px] font-bold", planTone.sub)}>
              {planTermChip}
            </span>
          </span>
          <CatIcon name="chevron-left" className={cn("h-3.5 w-3.5 shrink-0 rtl:rotate-0 ltr:rotate-180", planTone.sub)} aria-hidden="true" />
        </button>
      ) : null}

      {/* ROUND 47 — locked strip (subscription only) */}
      {isLocked && !collapsed ? (
        <div className="mx-3 mt-3 flex items-center gap-2.5 rounded-2xl border border-rose-300/60 bg-linear-to-l from-rose-50 to-red-50/60 px-3 py-2.5 dark:border-rose-500/30 dark:from-rose-500/10 dark:to-red-500/5">
          <span
            className="grid h-8 w-8 shrink-0 place-items-center rounded-xl text-white shadow-md"
            style={{ backgroundImage: "linear-gradient(135deg,#f43f5e,#e11d48)" }}
            aria-hidden="true"
          >
            <CatIcon name="lock" className="h-3.5 w-3.5" />
          </span>
          <span className="min-w-0 flex-1 text-[10.5px] font-extrabold leading-snug text-rose-600 dark:text-rose-300">
            {t("lockedSidebarHint")}
          </span>
        </div>
      ) : null}

      {/* nav — ROUND 141 (directive ㉔): the PREMIUM grouped organization */}
      <nav className="flex-1 overflow-y-auto overflow-x-hidden px-2 py-4 nice-scroll" aria-label={t("dashMain")}>
        {/* نظرة عامة — the standalone lead item */}
        <div className="mb-4 space-y-1">
          <NavButton
            item={{ id: "overview", labelKey: "dashOverview", icon: "gauge" }}
            locked={navLocked("overview")}
            onClick={() => navigate("overview")}
            collapsed={collapsed}
          />
        </div>

        {/* الوحدات — the workspace's heart: the console entry + the live
            per-module buttons WITH their license badges (strict law) */}
        <NavGroupHeader labelKey="dashModulesList" collapsed={collapsed} />
        <div className="mb-5 space-y-1">
          <NavButton
            item={{ id: "modules", labelKey: "dashModules", icon: "cubes" }}
            badge={instance.modules.length}
            locked={navLocked("modules")}
            onClick={() => navigate("modules")}
            collapsed={collapsed}
          />
          {instance.modules.map((key) => {
            const m = MODULE_MAP[key];
            const active = dashView === "module" && activeModuleId === key;
            /* ROUND 141 (strict license mirror) — a module gated behind a
             * feature the workspace lacks renders LOCKED and routes to
             * billing, exactly like the modules console. */
            const gateFeature = MODULE_FEATURE_GATES[key];
            const planLocked = gateFeature ? entitlement?.features?.[gateFeature] === false : false;
            const disabled = isLocked || planLocked;
            const moduleLabel = moduleDisplayName(key, instance.systemId, lang);
            return (
              <button
                key={key}
                type="button"
                disabled={disabled}
                onClick={() => {
                  if (planLocked) {
                    /* the strict-license route: the upgrade console */
                    setDashView("billing");
                    setSidebarOpen(false);
                    return;
                  }
                  /* open THIS module's premium workspace directly */
                  setActiveModuleId(key);
                  setDashView("module");
                  setSidebarOpen(false);
                }}
                aria-current={active ? "page" : undefined}
                aria-label={collapsed ? moduleLabel : undefined}
                title={collapsed ? (planLocked ? t("lockedModuleHint") : isLocked ? t("lockedSidebarHint") : moduleLabel) : planLocked ? t("lockedModuleHint") : isLocked ? t("lockedSidebarHint") : t("modOpenChip")}
                className={cn(
                  "group relative flex w-full items-center rounded-xl text-[12px] font-bold transition",
                  collapsed ? "justify-center px-0 py-2" : "gap-2.5 px-3 py-2",
                  active
                    ? "bg-brand-500/10 text-brand-600 shadow-[0_0_16px_-6px_rgba(109,93,251,0.4)] dark:text-brand-300 dark:shadow-[0_0_16px_-6px_rgba(139,120,255,0.35)]"
                    : "text-slate-500 hover:bg-slate-100 hover:text-slate-800 dark:text-slate-400 dark:hover:bg-white/[0.06] dark:hover:text-slate-100",
                  disabled && "cursor-not-allowed opacity-40 hover:bg-transparent dark:hover:bg-transparent"
                )}
              >
                <span
                  className="grid h-6 w-6 shrink-0 place-items-center rounded-lg text-white"
                  style={{ backgroundImage: m ? grad(c1, c2) : undefined }}
                >
                  <CatIcon name={m?.icon ?? "cubes"} className="h-[10px] w-[10px]" />
                </span>
                {collapsed ? null : (
                  <span className="min-w-0 flex-1 truncate text-start">
                    {/* ROUND 64 — sector-correct module vocabulary */}
                    {moduleLabel}
                  </span>
                )}
                {collapsed ? null : planLocked ? (
                  <CatIcon name="lock" className="h-3 w-3 shrink-0 text-amber-500" aria-hidden="true" />
                ) : null}
              </button>
            );
          })}
          {instance.modules.length === 0 && !collapsed ? (
            <p className="px-3 text-[11px] font-semibold text-slate-400 dark:text-slate-500">
              {t("dashEmptyState")}
            </p>
          ) : null}
        </div>

        {/* التحليلات */}
        <NavGroupHeader labelKey="sideGroupInsights" collapsed={collapsed} />
        <div className="mb-5 space-y-1">
          {INSIGHTS_NAV.map((item) => (
            <NavButton key={item.id} item={item} locked={navLocked(item.id)} onClick={() => navigate(item.id)} collapsed={collapsed} />
          ))}
        </div>

        {/* المتجر والموقع */}
        <NavGroupHeader labelKey="sideGroupStore" collapsed={collapsed} />
        <div className="mb-5 space-y-1">
          {STORE_NAV.map((item) => (
            <NavButton key={item.id} item={item} locked={navLocked(item.id)} onClick={() => navigate(item.id)} collapsed={collapsed} />
          ))}
        </div>

        {/* العملاء والفريق */}
        <NavGroupHeader labelKey="sideGroupPeople" collapsed={collapsed} />
        <div className="mb-5 space-y-1">
          {PEOPLE_NAV.map((item) => (
            <NavButton
              key={item.id}
              item={item}
              locked={navLocked(item.id)}
              onClick={() => navigate(item.id)}
              /* ROUND 65 — sector-correct team vocabulary (الكوادر الطبية…) */
              labelOverride={item.id === "team" ? teamDisplayName(instance.systemId, lang) : undefined}
              collapsed={collapsed}
            />
          ))}
        </div>

        {/* الاشتراك والفوترة */}
        <NavGroupHeader labelKey="sideGroupSubscription" collapsed={collapsed} />
        <div className="mb-5 space-y-1">
          {SUBSCRIPTION_NAV.map((item) => (
            <NavButton key={item.id} item={item} locked={navLocked(item.id)} onClick={() => navigate(item.id)} collapsed={collapsed} />
          ))}
        </div>

        {/* النظام */}
        <NavGroupHeader labelKey="sideGroupSystem" collapsed={collapsed} />
        <div className="space-y-1">
          {SYSTEM_NAV.map((item) => (
            <NavButton key={item.id} item={item} locked={navLocked(item.id)} onClick={() => navigate(item.id)} collapsed={collapsed} />
          ))}
        </div>
      </nav>

      {/* footer: user + exit — collapses to the avatar only when the rail
          is collapsed; the exit button stays accessible via hover. */}
      <div className={cn("shrink-0 border-t border-slate-200/70 p-3 dark:border-white/[0.07]", collapsed && "px-2")}>
        {collapsed ? (
          <button
            type="button"
            onClick={onExit}
            aria-label={t("dashExit")}
            title={t("dashExit")}
            className="grid h-9 w-full place-items-center rounded-full text-[12px] font-extrabold text-white"
            style={{ backgroundImage: grad(c1, c2) }}
          >
            {instance.admin.name.trim().charAt(0).toUpperCase() || "A"}
          </button>
        ) : (
          <div className="flex items-center gap-2.5 rounded-xl bg-slate-50 p-2.5 dark:bg-white/[0.03]">
            <span
              className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-[12px] font-extrabold text-white"
              style={{ backgroundImage: grad(c1, c2) }}
              aria-hidden="true"
            >
              {instance.admin.name.trim().charAt(0).toUpperCase() || "A"}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[12px] font-extrabold text-slate-900 dark:text-white">
                {instance.admin.name}
              </p>
              <p className="truncate text-[10px] font-semibold text-slate-500 dark:text-slate-400">
                {instance.admin.role === "owner" ? t("wzAdminRoleOwner") : t("wzAdminRoleManager")}
              </p>
            </div>
            <button
              type="button"
              onClick={onExit}
              aria-label={t("ariaExit")}
              title={t("dashExit")}
              className="relative grid h-7 w-7 shrink-0 place-items-center rounded-lg text-slate-400 transition hover:bg-rose-50 hover:text-rose-500 dark:hover:bg-rose-500/10 before:absolute before:-inset-2 before:content-['']"
            >
              <CatIcon name="log-out" className="h-[11px] w-[11px]" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export function Sidebar({
  instance,
  isPinned,
  onTogglePin,
  isHovered,
  onHoverChange,
}: {
  instance: InstanceDTO;
  isPinned: boolean;
  onTogglePin: () => void;
  isHovered: boolean;
  onHoverChange: (hovered: boolean) => void;
}) {
  const { t, lang } = useT();
  const sidebarOpen = useAppStore((s) => s.sidebarOpen);
  const setSidebarOpen = useAppStore((s) => s.setSidebarOpen);
  const [exitOpen, setExitOpen] = useState(false);
  const exit = useExitInstance(instance.id);

  /* ROUND 160 — hover state is managed by the parent (DashboardApp)
   * so the main content padding can react to it too (no more overlay
   * overlap). The sidebar + content animate together in sync. */
  const expanded = isPinned || isHovered;

  return (
    <>
      {/* desktop */}
      <aside
        onMouseEnter={() => onHoverChange(true)}
        onMouseLeave={() => onHoverChange(false)}
        className={cn(
          "fixed inset-y-0 start-0 z-30 hidden flex-col border-e border-slate-200/70 bg-white/95 backdrop-blur-xl transition-all duration-300 ease-in-out dark:border-white/[0.07] dark:bg-ink-950/95 lg:flex",
          /* when expanded the rail covers the full w-64; when collapsed the
           * icon-only rail is w-16 and the EXPANSION overlays the main
           * content (z-30 already wins over the in-flow content) so labels
           * never clip and the main content never shifts on hover. */
          expanded ? "w-64" : "w-16",
          /* hovered expansion sits ABOVE the main content so labels render
           * over the workspace while the rail's RESERVED space stays w-16
           * (the main content's padding never shifts on hover). */
          /* no overlay — content shifts in sync */
        )}
      >
        <SidebarContent
          instance={instance}
          onExit={() => setExitOpen(true)}
          isPinned={isPinned}
          onTogglePin={onTogglePin}
          isHovered={isHovered}
        />
      </aside>

      {/* mobile sheet — slides from the start side; always full labels */}
      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetContent
          side={lang === "ar" ? "right" : "left"}
          className="w-[85vw] max-w-xs gap-0 p-0 [&_[data-slot=sheet-close]]:hidden"
        >
          {/* Radix a11y: DialogContent requires a title + description (sr-only) */}
          <SheetHeader className="sr-only">
            <SheetTitle>{t("dashMain")}</SheetTitle>
            <SheetDescription>{t("dashModulesDesc")}</SheetDescription>
          </SheetHeader>
          <SidebarContent
            instance={instance}
            onExit={() => setExitOpen(true)}
            isPinned
            onTogglePin={onTogglePin}
            isHovered={false}
          />
        </SheetContent>
      </Sheet>

      <ExitConfirmDialog
        open={exitOpen}
        onOpenChange={setExitOpen}
        onConfirm={() => exit.mutate()}
        pending={exit.isPending}
      />
    </>
  );
}
