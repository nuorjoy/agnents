"use client";

/**
 * Ashrilogic — ROUND 141 → ROUND 144: محفظة Ashrilogic (Apple-Pay-grade)
 * + التحويل بين المحافظ (inter-wallet transfers).
 *
 * The owner's directives:
 *   ㉓ a Premium wallet (Apple-Pay-grade experience) integrated into the
 *      OWNER'S PROFILE — one glance: the PHYSICAL balance card (deep
 *      emerald→teal metal/glass, aura blobs, animated diagonal sheen, NFC
 *      mark, count-up balance); one tap: top-up + transfer + the history;
 *   ㉗ the top-up input accepts BOTH Arabic-Indic (١٢٣٫٥٠) and Western
 *      (1,234.50) numerals — parsed LIVE here (client hint) and re-parsed
 *      server-side from the RAW string (the client never sends numbers);
 *   ㉘ the SAME wallet pays for plan renewals/upgrades AND add-on
 *      purchases INSTANTLY (the WalletCheckoutOption card rides both the
 *      billing ActivationDialog and the add-ons checkout);
 *   ★ ROUND 144 — «تصغير وتنسيق» the card is COMPACTED (min-h ≈ 164px,
 *      p-4, ~27px balance, smaller brand tiles — same premium vocabulary),
 *      the REAL unique 8-digit wallet NUMBER renders prominently with a
 *      copy chip (the address other workspaces send money to), a third
 *      action «التحويل» opens the NEW WalletTransferDialog — a 3-step
 *      premium flow (receiver verify → dual-numeral amount + note →
 *      PIN confirmation) sealed by a receipt view — and the ledger learns
 *      the "transfer" kind (sky family, in/out tinted by the signed law);
 *   ★ ROUND 147 — «أصغر وأدق + إخفاء الرصيد»: the card is SMALLER and
 *      more precise (aspect lock removed, min-h ≈ 150px, p-3.5, ~23px
 *      balance, h-8 brand tile — same premium vocabulary), the wallet
 *      NUMBER strip is promoted to the TOP with NO caption (card icon +
 *      mono LTR + copy chip), the holder/powered-by row is DELETED (a
 *      tiny lock keeps the trust cue), the balance gains a PERSISTED
 *      hide/show eye toggle (masked "•••", count-up suppressed), and the
 *      ledger rows become clearly-clickable expandable buttons (chevron +
 *      aria-expanded + the full-detail panel).
 *
 * All money is INTEGER MINOR UNITS on the wire (the money.ts law);
 * toDisplayUnits converts once at the display boundary.
 */
import { Fragment, useEffect, useMemo, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Area, AreaChart, ResponsiveContainer } from "recharts";
import { useT } from "@/lib/i18n";
import { intlLocale } from "@/lib/locales";
import { amountInputIsNeutral, parseAmountInputToMinor } from "@/lib/amount-input";
import {
  ApiError,
  cancelWalletTopup,
  createWalletTopup,
  fetchPlanMethods,
  fetchWallet,
  lookupWalletReceiver,
  transferWalletFunds,
} from "@/lib/api-client";
import { SYSTEM_MAP } from "@/data/catalog";
import type {
  InstanceDTO,
  Lang,
  WalletDTO,
  WalletLookupDTO,
  WalletTopupDTO,
  WalletTransferReceiptDTO,
  WalletTxnDTO,
} from "@/lib/types";
import { WALLET_CHECKOUT_METHOD_ID } from "@/lib/types";
import { apiErrorText } from "@/lib/api-errors";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { PinInput } from "@/components/ui/pin-input";
import { Skeleton } from "@/components/ui/skeleton";

/* ------------------------------- helpers ---------------------------------- */

/** minor → major units (the money.ts law inlined — lib/server stays
 *  server-only by convention; 100 minor = 1 major). */
function toDisplayUnits(minor: number): number {
  return Math.round(minor) / 100;
}

/** localized relative time (the security-cards idiom, inlined — with the
 *  full BCP-47 locale so Hindi gets native relative units too). */
function relTime(iso: string, lang: Lang): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.max(0, Math.round(diffMs / 60_000));
  const rtf = new Intl.RelativeTimeFormat(intlLocale(lang), { numeric: "auto" });
  if (mins < 1) return rtf.format(0, "minute");
  if (mins < 60) return rtf.format(-mins, "minute");
  const hours = Math.round(mins / 60);
  if (hours < 24) return rtf.format(-hours, "hour");
  return rtf.format(-Math.round(hours / 24), "day");
}

/** ROUND 147 — the full locale timestamp for the EXPANDED ledger row
 *  (medium date + short time, the intlLocale law; rendered inside a
 *  dir="auto" cell so Arabic dates read naturally). */
function fullStamp(iso: string, lang: Lang): string {
  return new Intl.DateTimeFormat(intlLocale(lang), { dateStyle: "medium", timeStyle: "short" }).format(
    new Date(iso),
  );
}

/** Format a minor-unit balance for display (major units, locale numerals). */
export function walletMoney(minor: number, lang: Lang, currency = "SAR"): string {
  return `${fmtNum(toDisplayUnits(minor), lang)} ${currency}`;
}

/** ROUND 144→168 — the wallet's UNIQUE 8-digit transfer address, rendered
 *  CLEAN: "3650 5179" (LTR, mono, tabular-nums — the address other
 *  workspaces send money to). The old "••••" mask prefix is REMOVED by the
 *  owner's directive (it made the wallet look bad); while loading /
 *  pre-allocation the strip carries a neutral em-dash instead. */
function formatWalletNo(no: number): string {
  const digits = String(no).padStart(8, "0").slice(0, 8);
  return `${digits.slice(0, 4)} ${digits.slice(4)}`;
}

/** Fold Arabic-Indic ٠-٩ + Extended ۰-۹ digits to ASCII and keep digits
 *  only (the pin-input.tsx folding, inlined for the receiver number). */
function foldWalletNoDigits(raw: string): string {
  let out = "";
  for (const ch of raw) {
    const code = ch.codePointAt(0) ?? 0;
    if (ch >= "0" && ch <= "9") out += ch;
    else if (code >= 0x0660 && code <= 0x0669) out += String(code - 0x0660);
    else if (code >= 0x06f0 && code <= 0x06f9) out += String(code - 0x06f0);
  }
  return out;
}

const QUICK_AMOUNTS = [50, 100, 250, 500, 1000];

/** ROUND 144 — the transfer quick pills (1..10,000 SAR law). */
const TRANSFER_QUICK_AMOUNTS = [25, 50, 100, 250, 500];
/** ROUND 144 — transfer bounds in INTEGER MINOR units (1..10,000 SAR). */
const TRANSFER_MIN_MINOR = 100;
const TRANSFER_MAX_MINOR = 1_000_000;

/** ROUND 147 — the persisted hide/show-balance flag ("1" = hidden).
 *  Read ONCE on mount via a lazy initializer (typeof-window guarded);
 *  written only from the toggle's click handler — never from an effect. */
const BALANCE_HIDDEN_KEY = "wallet-balance-hidden";

const TOPUP_STYLE: Record<string, { c1: string; c2: string }> = {
  pending: { c1: "#f59e0b", c2: "#d97706" },
  paid: { c1: "#10b981", c2: "#047857" },
  cancelled: { c1: "#94a3b8", c2: "#64748b" },
  expired: { c1: "#94a3b8", c2: "#64748b" },
};

/** The premium ledger-kind visual map: gradient tile + icon + i18n key.
 *  ROUND 144 — the "transfer" kind joins the family (sky tiles,
 *  arrow-left-right; rows tint in/out by the signed amount law). */
const TXN_KIND_STYLE: Record<string, { icon: string; c1: string; c2: string; key: string }> = {
  topup: { icon: "arrow-down-to-line", c1: "#10b981", c2: "#047857", key: "walletTxnTopup" },
  debit: { icon: "arrow-up-from-line", c1: "#8b5cf6", c2: "#7c3aed", key: "walletTxnDebit" },
  refund: { icon: "rotate-ccw", c1: "#0ea5e9", c2: "#0284c7", key: "walletTxnRefund" },
  adjust: { icon: "sliders", c1: "#f59e0b", c2: "#d97706", key: "walletTxnAdjust" },
  transfer: { icon: "arrow-left-right", c1: "#0ea5e9", c2: "#0284c7", key: "walletTxnKindTransfer" },
  /* ROUND 168 (منح المحفظة) — grant credits: bulk goodwill + welcome gift. */
  grant: { icon: "gift", c1: "#059669", c2: "#10b981", key: "walletTxnGrant" },
};

/* ---------------------- day bucketing (ledger groups) ---------------------- */

type DayBucket = "today" | "yesterday" | "week" | "month" | "earlier";

const DAY_BUCKET_KEY: Record<DayBucket, string> = {
  today: "walletGroupToday",
  yesterday: "walletGroupYesterday",
  week: "walletGroupThisWeek",
  month: "walletGroupThisMonth",
  earlier: "walletGroupEarlier",
};

const DAY_MS = 86_400_000;

/** Bucket a txn timestamp into the premium day-group ladder
 *  (today → yesterday → this week → this month → earlier). */
function dayBucketOf(iso: string, now: Date): DayBucket {
  const t = new Date(iso).getTime();
  if (!Number.isFinite(t)) return "earlier";
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  if (t >= startOfDay) return "today";
  if (t >= startOfDay - DAY_MS) return "yesterday";
  if (t >= startOfDay - 7 * DAY_MS) return "week";
  if (t >= startOfDay - 30 * DAY_MS) return "month";
  return "earlier";
}

/* -------------------------- the count-up balance ---------------------------- */

/**
 * Apple-Pay-grade count-up: rAF-driven, easeOutCubic, 900ms — and
 * interruption-aware (a mid-flight target change resumes smoothly from
 * the value currently shown on screen, never snapping).
 */
function useCountUp(target: number, active: boolean): number {
  const [display, setDisplay] = useState(() => (active ? 0 : target));
  const currentRef = useRef<number>(active ? 0 : target);

  useEffect(() => {
    /* every transition — including the instant settle when inactive or
       unchanged — rides the SAME rAF hop, so no setState ever fires
       synchronously inside the effect body (cascading-render law). */
    let raf = 0;
    const settle = () => {
      currentRef.current = target;
      setDisplay(target);
    };
    if (!active) {
      raf = requestAnimationFrame(settle);
      return () => cancelAnimationFrame(raf);
    }
    const from = currentRef.current;
    if (from === target) return;
    const start = performance.now();
    const durationMs = 900;
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / durationMs);
      const eased = 1 - Math.pow(1 - p, 3);
      const value = from + (target - from) * eased;
      currentRef.current = value;
      setDisplay(value);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, active]);

  return display;
}

/* ------------------------------ the CSV export ------------------------------ */

/** Bank-grade CSV of the append-only ledger — client-side Blob download.
 *  Columns: date,type,amount,balanceAfter,reference,note,actor. Amounts are
 *  major units at the display boundary (money law: minor on the wire).
 *  ROUND 144 — "transfer" rows flow through the existing kind column. */
function buildWalletCsv(txns: WalletTxnDTO[]): string {
  const esc = (value: string): string =>
    /[",\n\r]/.test(value) ? `"${value.replace(/"/g, '""')}"` : value;
  const lines = ["date,type,amount,balanceAfter,reference,note,actor"];
  for (const txn of txns) {
    lines.push(
      [
        new Date(txn.createdAt).toISOString(),
        txn.kind,
        (txn.amountMinor / 100).toFixed(2),
        (txn.balanceAfterMinor / 100).toFixed(2),
        txn.reference,
        txn.note,
        txn.actorName,
      ]
        .map(esc)
        .join(","),
    );
  }
  return lines.join("\r\n");
}

/* ---------------------- the wallet card (owner profile) -------------------- */

/**
 * The Premium PHYSICAL balance card embedded in the owner's profile dialog —
 * credit-card geometry, deep emerald→teal metal base, aura blobs + an
 * animated diagonal sheen, NFC mark, count-up balance, the REAL unique
 * 8-digit wallet number with a copy chip, and the top-up / transfer /
 * ledger actions (ROUND 144: compacted + transfer + overlap/RTL fixes —
 * every text node min-w-0 + truncate, logical spacing only).
 *
 * ROUND 147 anatomy (top→bottom): brand row (NFC + tiny lock · Ashrilogic
 * mark) → the NUMBER strip (caption DELETED — card icon + masked mono LTR
 * digits + copy chip) → the balance block (label + count-up value + the
 * persisted hide/show eye toggle; hidden renders "•••", suppresses the
 * count-up and skips the pending chip) → the actions row. The holder /
 * powered-by row is DELETED per the owner's directive; every text node
 * keeps the min-w-0 + truncate + logical-spacing law.
 */
export function WalletCard({
  instance,
  onTopup,
  onLedger,
  onTransfer,
}: {
  instance: InstanceDTO;
  onTopup: () => void;
  onLedger: () => void;
  /** ROUND 144 — optional override for the transfer action (when absent
   *  the button opens the card's INTERNAL transfer dialog, so existing
   *  consumers need zero changes). */
  onTransfer?: () => void;
}) {
  const { t, lang } = useT();
  const [transferOpen, setTransferOpen] = useState(false);

  /* ROUND 147 — hide/show the balance, PERSISTED: read once through the
   * lazy initializer behind a typeof-window guard (the WRITE happens only
   * in the toggle's click handler — never inside an effect, so no render
   * loops; the card mounts client-side inside the profile dialog). */
  const [balanceHidden, setBalanceHidden] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    try {
      return window.localStorage.getItem(BALANCE_HIDDEN_KEY) === "1";
    } catch {
      return false;
    }
  });

  const walletQuery = useQuery({
    queryKey: ["wallet", instance.id],
    queryFn: () => fetchWallet(instance.id),
    staleTime: 20_000,
  });
  const wallet = walletQuery.data;

  /* the count-up rides the MINOR units; the display boundary rounds once.
   * ROUND 147 — a HIDDEN balance never animates and never renders a
   * number: the masked "•••" renders directly in its place. */
  const loaded = walletQuery.isSuccess && !!wallet;
  const animatedMinor = useCountUp(wallet?.balanceMinor ?? 0, loaded && !balanceHidden);

  const toggleBalanceVisibility = () => {
    const next = !balanceHidden;
    setBalanceHidden(next);
    try {
      window.localStorage.setItem(BALANCE_HIDDEN_KEY, next ? "1" : "0");
    } catch {
      /* storage unavailable (private mode) — the choice still holds in-session */
    }
  };

  /* ROUND 168 — the owner's «هناك ٤ نقاط تظهر مع رقم المحفظة احذفهم»: the
   * strip renders the CLEAN formatted address (formatWalletNo spaces it
   * NNNN NNNN — no •••• prefix). While loading / pre-allocation a neutral
   * em-dash holds the strip (the copy chip stays disabled until loaded).
   * The BALANCE mask «•••» (the eye toggle) is deliberate and stays. */
  const walletNoText = wallet?.walletNo != null ? formatWalletNo(wallet.walletNo) : "—";

  const copyWalletNo = () => {
    if (wallet?.walletNo == null) return;
    void navigator.clipboard?.writeText(String(wallet.walletNo)).then(
      () => toast.success(t("walletNoCopied")),
      () => toast.error(t("errorText")),
    );
  };

  return (
    <div className="card-in">
      {/* the physical card (ROUND 147: SMALLER + more precise — the aspect
          lock is REMOVED in favor of min-h-[150px], p-3.5, ~23px balance,
          h-8 brand tile, tightened aura — the SAME premium vocabulary:
          emerald→teal metal, inset ring, sheen, NFC, rounded-3xl) */}
      <section
        role="region"
        aria-label={t("walletCardTitle")}
        className="group relative min-h-[150px] overflow-hidden rounded-3xl p-3.5 text-white ring-1 ring-inset ring-white/15"
        style={{
          backgroundImage: grad("#047857", "#0d9488"),
          boxShadow: "0 20px 40px -18px rgba(4,120,87,0.55)",
        }}
      >
        {/* aura blob — emerald, top-end (ROUND 147: tightened) */}
        <div
          className="pointer-events-none absolute -top-12 -end-10 h-36 w-36 rounded-full opacity-25 blur-2xl"
          style={{ background: "radial-gradient(circle, #6ee7b7 0%, transparent 70%)" }}
          aria-hidden="true"
        />
        {/* aura blob — teal, bottom-start (ROUND 147: tightened) */}
        <div
          className="pointer-events-none absolute -bottom-14 -start-10 h-36 w-36 rounded-full opacity-20 blur-2xl"
          style={{ background: "radial-gradient(circle, #99f6e4 0%, transparent 70%)" }}
          aria-hidden="true"
        />
        {/* the fine diagonal sheen stripe — slides on hover */}
        <div
          className="pointer-events-none absolute inset-y-0 -start-1/4 w-[150%] transition-transform duration-700 ease-out group-hover:translate-x-[8%]"
          style={{
            backgroundImage:
              "linear-gradient(120deg, transparent 30%, rgba(255,255,255,0.14) 45%, transparent 60%)",
          }}
          aria-hidden="true"
        />
        {/* the glass-top vignette */}
        <div
          className="pointer-events-none absolute inset-0 bg-[linear-gradient(180deg,rgba(255,255,255,0.10)_0%,transparent_38%)]"
          aria-hidden="true"
        />

        <div className="relative flex h-full flex-col justify-between gap-2">
          {/* top row — NFC waves + the tiny secured lock (start, the
              powered-by/shield trust cue compressed to a no-text icon) +
              the wallet brand mark (end) — ROUND 147: h-8 tile, smaller type */}
          <div className="flex items-start justify-between gap-2.5">
            <div className="flex shrink-0 items-center gap-1.5 pt-0.5">
              <CatIcon name="nfc" className="h-4 w-4 text-white/45" aria-hidden="true" />
              <span title={t("walletSecureBadge")}>
                <CatIcon name="lock" className="h-3 w-3 text-white/45" aria-hidden="true" />
              </span>
            </div>
            <div className="flex min-w-0 items-center gap-2" title={t("walletPremiumTitle")}>
              <span
                className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-white/15 backdrop-blur-sm"
                aria-hidden="true"
              >
                <CatIcon name="wallet" className="h-3.5 w-3.5" />
              </span>
              <span className="flex min-w-0 flex-col items-start gap-0.5">
                <span className="truncate text-[9px] font-black uppercase tracking-[0.2em] text-white/85">
                  Ashrilogic
                </span>
                <span className="inline-flex max-w-full items-center gap-1 truncate rounded-full bg-amber-400/90 px-1.5 py-px text-[8px] font-black text-amber-950">
                  <CatIcon name="zap" className="h-2.5 w-2.5 shrink-0" aria-hidden="true" />
                  <span className="truncate">{t("walletPremiumChip")}</span>
                </span>
              </span>
            </div>
          </div>

          {/* ROUND 147→168 — the wallet NUMBER at the TOP (the «رقم المحفظة
              الفريد» caption is DELETED by the owner's directive): the CLEAN
              LTR mono transfer address rides the glass strip right under the
              brand row — a tiny credit-card icon cue (NO text label) + the
              copy chip; an em-dash holds the strip until the number loads */}
          <div className="flex items-center gap-2.5 rounded-xl border border-white/15 bg-white/10 px-2.5 py-1 backdrop-blur-sm">
            <CatIcon name="credit-card" className="h-3 w-3 shrink-0 text-white/50" aria-hidden="true" />
            <span
              dir="ltr"
              className="min-w-0 flex-1 truncate font-mono text-[12.5px] font-bold tracking-[0.16em] tabular-nums text-white"
            >
              {walletNoText}
            </span>
            <button
              type="button"
              onClick={copyWalletNo}
              disabled={wallet?.walletNo == null}
              title={t("secCopyTip")}
              aria-label={t("secCopyTip")}
              className="grid h-6 w-6 shrink-0 place-items-center rounded-lg bg-white/15 text-white/80 transition hover:bg-white/25 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/70 active:scale-95 disabled:opacity-40"
            >
              <CatIcon name="copy" className="h-3 w-3" aria-hidden="true" />
            </button>
          </div>

          {/* the balance block — start-aligned, count-up (ROUND 147: 23px)
              + the persisted hide/show eye toggle at the row's end; hidden
              renders the masked "•••" IN PLACE of the amount (the count-up
              is suppressed) and skips the pending chip entirely */}
          <div className="flex items-end justify-between gap-2">
            <div className="min-w-0">
              <p className="text-[10px] font-extrabold uppercase tracking-wide text-emerald-100/90">
                {t("walletBalanceNow")}
              </p>
              {walletQuery.isPending && !balanceHidden ? (
                <div className="mt-1 space-y-1.5" aria-hidden="true">
                  <Skeleton className="h-6 w-32 rounded-lg bg-white/20" />
                  <Skeleton className="h-2.5 w-20 rounded-full bg-white/15" />
                </div>
              ) : (
                <p
                  dir="ltr"
                  title={t("walletAvailable")}
                  className="mt-1 flex items-baseline gap-1.5 font-display text-[23px] font-extrabold leading-none tabular-nums text-white"
                >
                  {balanceHidden ? (
                    <span className="tracking-[0.12em]">{t("walletBalanceMasked")}</span>
                  ) : (
                    <span className="truncate">{fmtNum(Math.round(animatedMinor) / 100, lang)}</span>
                  )}
                  <span className="shrink-0 text-[11px] font-bold text-emerald-100/80">SAR</span>
                </p>
              )}
              {!balanceHidden && wallet && wallet.pendingTopupMinor > 0 ? (
                <p
                  className="mt-1.5 inline-flex max-w-full items-center gap-1 truncate rounded-full border border-amber-300/30 bg-amber-400/20 px-2 py-px text-[9.5px] font-extrabold text-amber-100 backdrop-blur-sm"
                  title={t("walletLocked")}
                >
                  <CatIcon name="hourglass" className="h-3 w-3 shrink-0" aria-hidden="true" />
                  {t("walletPendingChip", { amount: fmtNum(toDisplayUnits(wallet.pendingTopupMinor), lang) })}
                </p>
              ) : null}
            </div>
            <button
              type="button"
              onClick={toggleBalanceVisibility}
              aria-pressed={balanceHidden}
              aria-label={balanceHidden ? t("walletShowBalance") : t("walletHideBalance")}
              title={balanceHidden ? t("walletShowBalance") : t("walletHideBalance")}
              className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-white/15 text-white/85 backdrop-blur-sm transition hover:bg-white/25 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/70 active:scale-95"
            >
              <CatIcon name={balanceHidden ? "eye-off" : "eye"} className="h-4 w-4" aria-hidden="true" />
            </button>
          </div>
        </div>
      </section>

      {/* the actions row — THREE compact actions (top-up · التحويل · the
          ledger), flex-1 each, focus rings, press feedback. ROUND 147: the
          ledger button carries a CLEARER click affordance (chevron + ring,
          tooltip walletLedgerCta) per the owner's «سجل غير واضق للضغط»;
          ROUND 168: the owner's «رز سجل الحركات غير واضح لونه سيء جداً» —
          the washed-out translucent white vanished on light dashboards, so
          the trio now reads as a coherent high-contrast set: white/emerald
          solid (top-up) · emerald gradient (transfer) · SOLID deep-emerald
          (ledger) — the label contrast is ≥ 4.5:1 in BOTH themes because
          the solid emerald-950 base carries its own text color. */}
      <div className="mt-2 flex gap-2">
        <button
          type="button"
          onClick={onTopup}
          title={t("walletTapTopup")}
          className="inline-flex h-9 min-w-0 flex-1 items-center justify-center gap-1.5 rounded-xl bg-white px-2 text-[11px] font-extrabold text-emerald-700 shadow-md transition hover:bg-emerald-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500/60 active:scale-95"
        >
          <CatIcon name="plus" className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
          <span className="truncate">{t("walletTopupBtn")}</span>
        </button>
        <button
          type="button"
          onClick={() => (onTransfer ? onTransfer() : setTransferOpen(true))}
          title={t("wtrTitle")}
          className="inline-flex h-9 min-w-0 flex-1 items-center justify-center gap-1.5 rounded-xl bg-linear-to-l from-emerald-600 to-teal-500 px-2 text-[11px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500/60 active:scale-95"
        >
          <CatIcon name="arrow-left-right" className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
          <span className="truncate">{t("wtrOpenBtn")}</span>
        </button>
        <button
          type="button"
          onClick={onLedger}
          title={t("walletLedgerCta")}
          className="inline-flex h-9 min-w-0 flex-1 items-center justify-center gap-1.5 rounded-xl bg-emerald-950 px-2 text-[11px] font-extrabold text-emerald-50 shadow-md ring-1 ring-emerald-700/50 transition hover:bg-emerald-900 hover:ring-emerald-600/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400 active:scale-95 dark:bg-emerald-950/95 dark:hover:bg-emerald-900"
        >
          <CatIcon name="receipt" className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
          <span className="truncate">{t("walletLedgerBtn")}</span>
          <CatIcon name="chevron-down" className="h-3.5 w-3.5 shrink-0 text-emerald-300/80" aria-hidden="true" />
        </button>
      </div>

      {/* ROUND 144 — the inter-wallet transfer flow, SELF-CONTAINED (the
          card owns it exactly like the topup pattern; external consumers
          may also mount the exported dialog themselves). */}
      <WalletTransferDialog open={transferOpen} onOpenChange={setTransferOpen} instance={instance} />
    </div>
  );
}

/* ------------------------- the top-up dialog (㉗) --------------------------- */

export function WalletTopupDialog({
  open,
  onOpenChange,
  instance,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  instance: InstanceDTO;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const [amountRaw, setAmountRaw] = useState("");
  const [methodId, setMethodId] = useState<string | null>(null);
  const [invoice, setInvoice] = useState<{ topup: WalletTopupDTO; lines: string[]; methodLabel: string } | null>(null);

  const parsed = useMemo(() => parseAmountInputToMinor(amountRaw), [amountRaw]);
  const neutral = amountInputIsNeutral(amountRaw);
  const amountOk = parsed.ok && parsed.minor >= 500 && parsed.minor <= 1_000_000;

  const methodsQuery = useQuery({
    queryKey: ["plan-methods", instance.id],
    queryFn: () => fetchPlanMethods(instance.id),
    enabled: open && !invoice,
    staleTime: 30_000,
  });
  const methods = methodsQuery.data ?? [];
  const effectiveMethodId = methodId ?? methods[0]?.id ?? null;

  const createTopup = useMutation({
    mutationFn: () => {
      if (!parsed.ok || !effectiveMethodId) {
        return Promise.reject(new Error(t("walletTopupInvalid")));
      }
      return createWalletTopup(instance.id, { amount: amountRaw.trim(), methodId: effectiveMethodId });
    },
    onSuccess: (result) => {
      setInvoice({
        topup: result.topup,
        lines: result.instructions.lines,
        methodLabel: result.instructions.methodLabel,
      });
      toast.success(t("walletTopupCreated"));
      void queryClient.invalidateQueries({ queryKey: ["wallet", instance.id] });
    },
    onError: (error: unknown) => toast.error(apiErrorText(error, t)),
  });

  const cancelTopup = useMutation({
    mutationFn: (topupId: string) => cancelWalletTopup(instance.id, topupId),
    onSuccess: () => {
      toast(t("walletTopupCancelled"));
      close();
      void queryClient.invalidateQueries({ queryKey: ["wallet", instance.id] });
    },
    onError: (error: unknown) => toast.error(apiErrorText(error, t)),
  });

  const close = () => {
    setInvoice(null);
    setAmountRaw("");
    setMethodId(null);
    createTopup.reset();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={(o) => (o ? onOpenChange(true) : close())}>
      <DialogContent
        dir={lang === "ar" ? "rtl" : "ltr"}
        className="max-h-[85vh] gap-0 overflow-y-auto rounded-3xl p-0 sm:max-w-md nice-scroll"
      >
        <DialogHeader className="border-b border-slate-200/70 p-5 dark:border-white/10">
          <DialogTitle className="flex items-center gap-2.5 font-display text-[17px] font-extrabold text-slate-900 dark:text-white">
            <span
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg"
              style={{ backgroundImage: grad("#059669", "#0f766e") }}
              aria-hidden="true"
            >
              <CatIcon name={invoice ? "circle-check" : "nfc"} className="h-[15px] w-[15px]" />
            </span>
            {invoice ? t("walletTopupSentTitle") : t("walletTopupTitlePremium")}
          </DialogTitle>
          <DialogDescription className="ps-[46px] text-[12.5px]">
            {invoice ? t("walletTopupSentDesc") : t("walletTopupDesc")}
          </DialogDescription>
        </DialogHeader>

        {invoice ? (
          /* ------------- the invoice step (reference + instructions) ------------- */
          <div className="space-y-4 p-5">
            {/* the sealed amount with the big landmark accent */}
            <div className="rounded-2xl border border-emerald-200/70 bg-emerald-500/[0.06] p-4 text-center dark:border-emerald-500/25 dark:bg-emerald-500/[0.08]">
              <span
                className="mx-auto grid h-12 w-12 place-items-center rounded-2xl text-white shadow-lg"
                style={{ backgroundImage: grad("#059669", "#0f766e") }}
                aria-hidden="true"
              >
                <CatIcon name="landmark" className="h-5 w-5" />
              </span>
              <p className="mt-2.5 text-[11px] font-extrabold uppercase tracking-wide text-emerald-600 dark:text-emerald-300">
                {t("walletAmountLabel")}
              </p>
              <p dir="ltr" className="mt-1 font-display text-[30px] font-extrabold tabular-nums leading-none text-slate-900 dark:text-white">
                {fmtNum(toDisplayUnits(invoice.topup.amountMinor), lang)}{" "}
                <span className="text-[13px] font-bold text-slate-400">SAR</span>
              </p>
            </div>

            {/* the reference copy block */}
            <div className="rounded-2xl border border-dashed border-emerald-300/70 bg-emerald-50/40 p-3.5 dark:border-emerald-500/30 dark:bg-emerald-500/[0.05]">
              <p className="text-[11px] font-extrabold uppercase tracking-wide text-emerald-700/80 dark:text-emerald-300/70">
                {t("payCopyRef")}
              </p>
              <div className="mt-1.5 flex items-center justify-between gap-2">
                <p dir="ltr" className="min-w-0 flex-1 truncate font-mono text-[15px] font-extrabold text-slate-800 dark:text-white">
                  {invoice.topup.reference}
                </p>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    void navigator.clipboard?.writeText(invoice.topup.reference).then(
                      () => toast.success(t("secCopyTip")),
                      () => toast.error(t("errorText")),
                    );
                  }}
                  className="h-8 shrink-0 gap-1.5 rounded-lg px-3 text-[10.5px] font-bold"
                >
                  <CatIcon name="copy" className="h-3 w-3" aria-hidden="true" />
                  {t("secCopyTip")}
                </Button>
              </div>
            </div>

            {/* the payment instructions */}
            <div className="rounded-2xl border border-slate-200/80 p-4 dark:border-white/10">
              <p className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                <CatIcon name="landmark" className="h-3.5 w-3.5 text-slate-400" aria-hidden="true" />
                {invoice.methodLabel}
              </p>
              <ul className="mt-2.5 space-y-1.5">
                {invoice.lines.map((line, i) => (
                  <li key={i} className="flex items-start gap-2 text-[11.5px] font-semibold leading-relaxed text-slate-600 dark:text-slate-300">
                    <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-emerald-400" aria-hidden="true" />
                    <span className="min-w-0 break-words" dir="auto">{line}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* the awaiting note */}
            <p className="flex items-start gap-2 rounded-xl bg-amber-500/10 px-3.5 py-2.5 text-[11px] font-semibold leading-relaxed text-amber-700 dark:bg-amber-500/15 dark:text-amber-300">
              <CatIcon name="clock" className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" />
              {t("walletTopupAwaiting")}
            </p>

            <DialogFooter>
              <Button
                type="button"
                onClick={() => cancelTopup.mutate(invoice.topup.id)}
                disabled={cancelTopup.isPending}
                className="h-10 w-full gap-2 rounded-xl px-5 text-[12px] font-bold text-rose-600 transition hover:bg-rose-500/10 active:scale-95 disabled:opacity-50 dark:text-rose-300"
              >
                {cancelTopup.isPending ? (
                  <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" aria-hidden="true" />
                ) : (
                  <CatIcon name="x" className="h-4 w-4" aria-hidden="true" />
                )}
                {t("addonCancelBtn")}
              </Button>
            </DialogFooter>
          </div>
        ) : (
          /* ------------- the amount + method step ------------- */
          <div className="space-y-4 p-5">
            {/* the dual-numeral amount input (㉗) */}
            <div className="space-y-1.5">
              <label
                htmlFor="wallet-topup-amount"
                className="flex items-center justify-between gap-2 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
              >
                {t("walletAmountLabel")}
                <span dir="ltr" className="text-[10px] font-black tracking-wide text-slate-400 dark:text-slate-500">
                  SAR
                </span>
              </label>
              <Input
                id="wallet-topup-amount"
                value={amountRaw}
                onChange={(e) => setAmountRaw(e.target.value)}
                placeholder={t("walletAmountPh")}
                inputMode="decimal"
                autoComplete="off"
                dir="auto"
                aria-describedby="wallet-topup-amount-hint"
                aria-invalid={!neutral && !amountOk ? true : undefined}
                className={cn(
                  "h-12 rounded-xl text-center font-display text-[20px] font-extrabold tabular-nums",
                  !neutral && !amountOk && "border-rose-400 focus-visible:ring-rose-400/30",
                )}
              />
              <p
                id="wallet-topup-amount-hint"
                className={cn(
                  "flex items-center gap-1.5 text-[10.5px] font-semibold",
                  neutral
                    ? "text-slate-400 dark:text-slate-500"
                    : amountOk
                      ? "text-emerald-600 dark:text-emerald-300"
                      : "text-rose-500 dark:text-rose-300",
                )}
              >
                <CatIcon
                  name={neutral ? "info" : amountOk ? "circle-check" : "circle-x"}
                  className="h-3 w-3 shrink-0"
                  aria-hidden="true"
                />
                {neutral
                  ? t("walletAmountHint")
                  : amountOk
                    ? `${t("walletWillCredit")}: ${walletMoney(parsed.ok ? parsed.minor : 0, lang)}`
                    : t("walletTopupInvalid")}
              </p>
            </div>

            {/* quick amounts — gradient-tinted press pills */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[10.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                {t("walletQuickAmounts")}
              </span>
              {QUICK_AMOUNTS.map((major) => {
                const active = parsed.ok && parsed.minor === major * 100;
                return (
                  <button
                    key={major}
                    type="button"
                    onClick={() => setAmountRaw(String(major))}
                    aria-pressed={active}
                    className={cn(
                      "rounded-full border px-3 py-1 text-[11px] font-extrabold tabular-nums transition active:scale-95",
                      active
                        ? "border-emerald-400 bg-linear-to-b from-emerald-500 to-teal-600 text-white shadow-sm ring-2 ring-emerald-400 dark:border-emerald-500"
                        : "border-slate-200 bg-linear-to-b from-white to-slate-50 text-slate-600 hover:border-emerald-400 hover:text-emerald-600 dark:border-white/10 dark:from-white/[0.06] dark:to-white/[0.02] dark:text-slate-300 dark:hover:border-emerald-500/40 dark:hover:text-emerald-300",
                    )}
                  >
                    {fmtNum(major, lang)}
                  </button>
                );
              })}
            </div>

            {/* the console-managed payment methods */}
            <div className="space-y-1.5">
              <p className="text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">{t("payMethodLabel")}</p>
              {methodsQuery.isPending ? (
                <Skeleton className="h-11 w-full rounded-xl" />
              ) : methods.length === 0 ? (
                <p className="rounded-xl border border-dashed border-slate-200 px-3.5 py-3 text-[11.5px] font-semibold text-slate-400 dark:border-white/10 dark:text-slate-500">
                  {t("payNoMethods")}
                </p>
              ) : (
                <div className="grid gap-2">
                  {methods.map((method) => {
                    const active = effectiveMethodId === method.id;
                    return (
                      <button
                        key={method.id}
                        type="button"
                        onClick={() => setMethodId(method.id)}
                        aria-pressed={active}
                        className={cn(
                          "flex items-center gap-2.5 rounded-xl border px-3 py-2.5 text-start transition hover:border-emerald-300 hover:shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/50",
                          active
                            ? "border-emerald-400 bg-emerald-500/[0.08] shadow-sm dark:border-emerald-500/50 dark:bg-emerald-500/10"
                            : "border-slate-200 dark:border-white/10 dark:hover:border-emerald-500/40",
                        )}
                      >
                        <span
                          className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-linear-to-br from-emerald-500 to-teal-600 text-white"
                          aria-hidden="true"
                        >
                          <CatIcon
                            name={
                              method.kind === "bank"
                                ? "landmark"
                                : method.kind === "wallet"
                                  ? "wallet"
                                  : method.kind === "paypal"
                                    ? "user"
                                    : "credit-card"
                            }
                            className="h-3.5 w-3.5"
                          />
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200">
                            {method.label}
                          </span>
                          <span className="block truncate text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                            {t(
                              method.kind === "bank"
                                ? "payMethodBank"
                                : method.kind === "wallet"
                                  ? "payMethodWallet"
                                  : method.kind === "paypal"
                                    ? "payMethodPaypal"
                                    : "payMethodStripe",
                            )}
                          </span>
                        </span>
                        {active ? (
                          <CatIcon name="circle-check" className="h-4 w-4 shrink-0 text-emerald-500" aria-hidden="true" />
                        ) : null}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            <DialogFooter className="gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                disabled={createTopup.isPending}
                className="h-10 rounded-xl px-5 text-[12.5px] font-bold"
              >
                {t("modRecCancelBtn")}
              </Button>
              <Button
                type="button"
                disabled={!amountOk || !effectiveMethodId || createTopup.isPending}
                onClick={() => createTopup.mutate()}
                className="h-10 gap-2 rounded-xl bg-linear-to-l from-emerald-600 to-teal-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
              >
                {createTopup.isPending ? (
                  <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" aria-hidden="true" />
                ) : (
                  <CatIcon name="send" className="h-4 w-4" aria-hidden="true" />
                )}
                {t("walletTopupCreate")}
              </Button>
            </DialogFooter>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

/* ---------------- ROUND 144 — the inter-wallet TRANSFER dialog ---------------- */

/** The 3-step premium transfer flow + the receipt view:
 *    1 — receiver: the 8-digit wallet number (Arabic-Indic folded) →
 *        lookupWalletReceiver → the confirmed receiver card;
 *    2 — amount + note: the dual-numeral input (1..10,000 SAR, live
 *        parsed, insufficient-vs-balance guard) + quick pills + the
 *        balance-after preview + the fee-free note;
 *    3 — PIN confirmation: EXACTLY pinLen cells (pinSet false → the
 *        sealed notice + disabled state), t("wtrPinStepDesc") summary;
 *    ✓ — the receipt: check-pop tile, receiver, amount, the TRF-
 *        reference with a copy chip, the sender's new balance, done →
 *        invalidations (wallet + instance + activities).
 *
 * State resets on EVERY close (the topup close() law); RTL-perfect
 * (logical properties only, LTR-locked money/number cells); errors are
 * aria-live; the amount travels as the RAW string (server re-parses). */
export function WalletTransferDialog({
  open,
  onOpenChange,
  instance,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  instance: InstanceDTO;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();

  /* the shared wallet projection (same key as the card → no duplicate
   * fetches; pinSet/pinLen/walletNo/balanceMinor drive the flow). */
  const walletQuery = useQuery({
    queryKey: ["wallet", instance.id],
    queryFn: () => fetchWallet(instance.id),
    enabled: open,
    staleTime: 15_000,
  });
  const wallet = walletQuery.data;

  type WtrStep = 1 | 2 | 3;
  const [step, setStep] = useState<WtrStep>(1);
  const [receipt, setReceipt] = useState<WalletTransferReceiptDTO | null>(null);

  /* step 1 — the receiver */
  const [walletNoRaw, setWalletNoRaw] = useState("");
  const [receiver, setReceiver] = useState<WalletLookupDTO | null>(null);
  const [lookupError, setLookupError] = useState<string | null>(null);

  /* step 2 — amount + note */
  const [amountRaw, setAmountRaw] = useState("");
  const [note, setNote] = useState("");

  /* step 3 — the PIN */
  const [pin, setPin] = useState("");
  const [pinError, setPinError] = useState(false);

  const parsed = useMemo(() => parseAmountInputToMinor(amountRaw), [amountRaw]);
  const neutral = amountInputIsNeutral(amountRaw);
  const balanceMinor = wallet?.balanceMinor ?? 0;
  const amountInBounds = parsed.ok && parsed.minor >= TRANSFER_MIN_MINOR && parsed.minor <= TRANSFER_MAX_MINOR;
  const insufficient = parsed.ok && parsed.minor > balanceMinor;
  const amountValid = amountInBounds && !insufficient;
  const formattedAmount = parsed.ok ? fmtNum(toDisplayUnits(parsed.minor), lang) : "";

  const canVerify = walletNoRaw.length === 8;

  /* the receiver's system name (lang-aware, catalog-resolved) — a tiny
   * shared lookup so the receiver card, the PIN summary and the receipt
   * all resolve the SAME system identity. */
  const systemMetaOf = (systemId: string): { name: string; icon: string } => {
    const system = SYSTEM_MAP[systemId];
    return {
      name: system ? (lang === "ar" ? system.nameAr : system.nameEn) : systemId,
      icon: system?.icon ?? "building",
    };
  };
  const receiverSystem = receiver ? systemMetaOf(receiver.systemId) : null;
  const receiverSystemIcon = receiverSystem?.icon ?? "building";

  const handleNoChange = (raw: string) => {
    setWalletNoRaw(foldWalletNoDigits(raw).slice(0, 8));
    if (receiver) setReceiver(null);
    if (lookupError) setLookupError(null);
  };

  const lookup = useMutation({
    mutationFn: () => lookupWalletReceiver(instance.id, Number(walletNoRaw)),
    onSuccess: (data) => {
      setReceiver(data.receiver);
      setLookupError(null);
    },
    onError: (error: unknown) => {
      if (error instanceof ApiError) {
        /* 404 → no wallet carries the number · 422 → the owner's own */
        if (error.status === 404) {
          const message = t("wtrNotFoundErr");
          setLookupError(message);
          toast.error(message);
          return;
        }
        if (error.status === 422) {
          const message = t("wtrSelfErr");
          setLookupError(message);
          toast.error(message);
          return;
        }
      }
      setLookupError(null);
      toast.error(apiErrorText(error, t));
    },
  });

  const verify = () => {
    if (!canVerify || lookup.isPending) return;
    setLookupError(null);
    lookup.mutate();
  };

  const send = useMutation({
    mutationFn: () => {
      if (!receiver || !parsed.ok || !amountValid) {
        return Promise.reject(new Error(t("walletTopupInvalid")));
      }
      return transferWalletFunds(instance.id, {
        toWalletNo: receiver.walletNo,
        amount: amountRaw.trim(),
        note: note.trim() === "" ? undefined : note.trim(),
        pin: pin.trim(),
      });
    },
    onSuccess: (data) => {
      setReceipt(data.receipt);
      setPin("");
      setPinError(false);
    },
    onError: (error: unknown) => {
      if (error instanceof ApiError) {
        if (error.code === "PIN_INVALID") {
          /* wrong PIN — shake + clear, stay for the next attempt */
          toast.error(t("wtrPinInvalidErr"));
          setPin("");
          setPinError(true);
          window.setTimeout(() => setPinError(false), 650);
          return;
        }
        if (error.code === "INSUFFICIENT_FUNDS") {
          toast.error(t("wtrInsufficientErr"));
          return;
        }
        if (error.code === "PIN_NOT_SET") {
          toast.error(t("wtrPinNotSetErr"));
          return;
        }
        /* RATE_LIMITED / WALLET_* / TRANSFER_* → the server message */
      }
      toast.error(apiErrorText(error, t));
    },
  });

  const confirm = () => {
    if (send.isPending || !receiver || !amountValid) return;
    if (pin.trim().length < (wallet?.pinLen ?? 4)) return;
    send.mutate();
  };

  /* every close resets the whole flow; a completed receipt also refreshes
   * the wallet + instance + activities caches (ledger + notifications). */
  const close = () => {
    if (receipt) {
      void queryClient.invalidateQueries({ queryKey: ["wallet", instance.id] });
      void queryClient.invalidateQueries({ queryKey: ["instance", instance.id] });
      void queryClient.invalidateQueries({ queryKey: ["activities"] });
    }
    setStep(1);
    setReceipt(null);
    setWalletNoRaw("");
    setReceiver(null);
    setLookupError(null);
    setAmountRaw("");
    setNote("");
    setPin("");
    setPinError(false);
    lookup.reset();
    send.reset();
    onOpenChange(false);
  };

  /* the step strip state (the receipt marks all three complete) */
  const currentStep = receipt ? 4 : step;
  const stepMeta: { key: "wtrStepReceiver" | "wtrStepAmount" | "wtrStepConfirm"; label: string }[] = [
    { key: "wtrStepReceiver", label: t("wtrStepReceiver") },
    { key: "wtrStepAmount", label: t("wtrStepAmount") },
    { key: "wtrStepConfirm", label: t("wtrStepConfirm") },
  ];

  const pinLen = wallet?.pinLen ?? null;
  const pinMinLen = pinLen ?? 4;
  const pinSet = wallet?.pinSet ?? false;

  return (
    <Dialog open={open} onOpenChange={(o) => (o ? onOpenChange(true) : close())}>
      <DialogContent
        dir={lang === "ar" ? "rtl" : "ltr"}
        className="max-h-[85vh] gap-0 overflow-y-auto rounded-3xl p-0 sm:max-w-md nice-scroll"
      >
        <DialogHeader className="border-b border-slate-200/70 p-5 dark:border-white/10">
          <DialogTitle className="flex items-center gap-2.5 font-display text-[17px] font-extrabold text-slate-900 dark:text-white">
            <span
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg"
              style={{ backgroundImage: receipt ? grad("#10b981", "#059669") : grad("#0ea5e9", "#0284c7") }}
              aria-hidden="true"
            >
              <CatIcon name={receipt ? "circle-check" : "arrow-left-right"} className="h-[15px] w-[15px]" />
            </span>
            {receipt ? t("wtrReceiptTitle") : t("wtrTitle")}
          </DialogTitle>
          <DialogDescription className="ps-[46px] text-[12.5px]">
            {t("wtrDesc")}
          </DialogDescription>
        </DialogHeader>

        {receipt ? (
          /* ==================== the RECEIPT view (success) ==================== */
          <div className="space-y-4 p-5">
            {/* the big check-pop tile */}
            <div className="text-center">
              <span
                className="animate-check-pop mx-auto grid h-16 w-16 place-items-center rounded-full text-white shadow-xl"
                style={{
                  backgroundImage: grad("#10b981", "#059669"),
                  boxShadow: "0 18px 40px -12px rgba(16,185,129,0.8)",
                }}
                aria-hidden="true"
              >
                <CatIcon name="check" className="h-8 w-8" />
              </span>
              <p className="mt-3 text-[15px] font-extrabold text-emerald-600 dark:text-emerald-300">
                {t("wtrReceiptTitle")}
              </p>
            </div>

            {/* the receiver card */}
            <div className="rounded-2xl border border-slate-200/80 bg-white/70 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
              <p className="text-[9.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                {t("wtrReceiptSentTo")}
              </p>
              <div className="mt-1.5 flex items-center gap-2.5">
                <span
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-sm"
                  style={{ backgroundImage: grad("#0ea5e9", "#0284c7") }}
                  aria-hidden="true"
                >
                  <CatIcon name={systemMetaOf(receipt.receiver.systemId).icon} className="h-4 w-4" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
                    {receipt.receiver.orgName}
                  </span>
                  <span className="block truncate text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                    {systemMetaOf(receipt.receiver.systemId).name}
                  </span>
                </span>
                <span
                  dir="ltr"
                  className="shrink-0 rounded-lg bg-slate-100 px-2 py-1 font-mono text-[11.5px] font-extrabold tabular-nums text-slate-600 dark:bg-white/10 dark:text-slate-300"
                >
                  {formatWalletNo(receipt.receiver.walletNo)}
                </span>
              </div>
            </div>

            {/* the amount */}
            <div className="rounded-2xl border border-emerald-200/70 bg-emerald-500/[0.06] p-4 text-center dark:border-emerald-500/25 dark:bg-emerald-500/[0.08]">
              <p dir="ltr" className="font-display text-[30px] font-extrabold tabular-nums leading-none text-slate-900 dark:text-white">
                {fmtNum(toDisplayUnits(receipt.amountMinor), lang)}{" "}
                <span className="text-[13px] font-bold text-slate-400">SAR</span>
              </p>
              {receipt.receiver.demo ? (
                <p className="mt-2 inline-flex max-w-full items-center gap-1 truncate rounded-full border border-amber-300/60 bg-amber-400/15 px-2 py-px text-[9.5px] font-extrabold text-amber-700 dark:border-amber-500/30 dark:bg-amber-500/15 dark:text-amber-300">
                  <CatIcon name="eye" className="h-2.5 w-2.5 shrink-0" aria-hidden="true" />
                  <span className="truncate">{t("modDemoNote")}</span>
                </p>
              ) : null}
            </div>

            {/* the reference copy block */}
            <div className="rounded-2xl border border-dashed border-emerald-300/70 bg-emerald-50/40 p-3.5 dark:border-emerald-500/30 dark:bg-emerald-500/[0.05]">
              <p className="text-[11px] font-extrabold uppercase tracking-wide text-emerald-700/80 dark:text-emerald-300/70">
                {t("wtrReceiptRef")}
              </p>
              <div className="mt-1.5 flex items-center justify-between gap-2">
                <p dir="ltr" className="min-w-0 flex-1 truncate font-mono text-[15px] font-extrabold text-slate-800 dark:text-white">
                  {receipt.reference}
                </p>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    void navigator.clipboard?.writeText(receipt.reference).then(
                      () => toast.success(t("wtrReceiptRefCopied")),
                      () => toast.error(t("errorText")),
                    );
                  }}
                  className="h-8 shrink-0 gap-1.5 rounded-lg px-3 text-[10.5px] font-bold"
                >
                  <CatIcon name="copy" className="h-3 w-3" aria-hidden="true" />
                  {t("secCopyTip")}
                </Button>
              </div>
            </div>

            {/* the sender's new balance */}
            <div className="flex items-center justify-between gap-2 rounded-2xl border border-slate-200/80 bg-white/70 px-3.5 py-2.5 dark:border-white/10 dark:bg-white/[0.03]">
              <p className="flex min-w-0 items-center gap-1.5 text-[11px] font-extrabold text-slate-500 dark:text-slate-400">
                <CatIcon name="wallet" className="h-3.5 w-3.5 shrink-0 text-emerald-500" aria-hidden="true" />
                <span className="truncate">{t("wtrReceiptNewBalance")}</span>
              </p>
              <p dir="ltr" className="shrink-0 font-display text-[14px] font-extrabold tabular-nums text-emerald-600 dark:text-emerald-300">
                {walletMoney(receipt.senderBalanceAfterMinor, lang)}
              </p>
            </div>

            <DialogFooter>
              <Button
                type="button"
                onClick={close}
                className="h-10 w-full gap-2 rounded-xl bg-linear-to-l from-emerald-600 to-teal-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:brightness-110 active:scale-95"
              >
                <CatIcon name="circle-check" className="h-4 w-4" aria-hidden="true" />
                {t("wtrReceiptDone")}
              </Button>
            </DialogFooter>
          </div>
        ) : (
          <>
            {/* ==================== the step strip ==================== */}
            <ol
              className="flex items-center gap-1.5 border-b border-slate-200/70 px-4 py-2.5 dark:border-white/10"
              aria-label={t("wtrTitle")}
            >
              {stepMeta.map((meta, i) => {
                const n = i + 1;
                const done = currentStep > n;
                const active = currentStep === n;
                return (
                  <li key={meta.key} className="flex min-w-0 flex-1 items-center gap-1.5">
                    <span
                      className={cn(
                        "grid h-5 w-5 shrink-0 place-items-center rounded-full text-[9.5px] font-black tabular-nums transition",
                        done
                          ? "bg-linear-to-b from-emerald-500 to-teal-600 text-white shadow-sm"
                          : active
                            ? "bg-emerald-500/15 text-emerald-600 ring-2 ring-emerald-400/60 dark:text-emerald-300"
                            : "bg-slate-100 text-slate-400 dark:bg-white/10 dark:text-slate-500",
                      )}
                      aria-current={active ? "step" : undefined}
                    >
                      {done ? <CatIcon name="check" className="h-2.5 w-2.5" aria-hidden="true" /> : fmtNum(n, lang)}
                    </span>
                    <span
                      className={cn(
                        "min-w-0 truncate text-[9.5px] font-extrabold uppercase tracking-wide",
                        active
                          ? "text-emerald-600 dark:text-emerald-300"
                          : done
                            ? "text-slate-500 dark:text-slate-400"
                            : "text-slate-400 dark:text-slate-500",
                      )}
                    >
                      {meta.label}
                    </span>
                    {i < stepMeta.length - 1 ? (
                      <span
                        className={cn(
                          "h-px min-w-2 flex-1",
                          done ? "bg-emerald-300 dark:bg-emerald-500/40" : "bg-slate-200 dark:bg-white/10",
                        )}
                        aria-hidden="true"
                      />
                    ) : null}
                  </li>
                );
              })}
            </ol>

            {step === 1 ? (
              /* ==================== STEP 1 — the receiver ==================== */
              <div className="space-y-3.5 p-5">
                <div className="space-y-1.5">
                  <label
                    htmlFor="wtr-receiver-no"
                    className="flex items-center justify-between gap-2 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
                  >
                    {t("wtrWalletNoLabel")}
                    <span dir="ltr" className="shrink-0 text-[9.5px] font-black tracking-wide text-slate-400 dark:text-slate-500">
                      {fmtNum(8, lang)}
                    </span>
                  </label>
                  <div className="flex gap-2">
                    <Input
                      id="wtr-receiver-no"
                      value={walletNoRaw}
                      onChange={(e) => handleNoChange(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          e.preventDefault();
                          verify();
                        }
                      }}
                      placeholder={t("wtrWalletNoPh")}
                      inputMode="numeric"
                      autoComplete="off"
                      dir="ltr"
                      aria-invalid={lookupError ? true : undefined}
                      aria-describedby="wtr-receiver-no-hint"
                      className="h-11 rounded-xl font-mono text-[16px] font-extrabold tracking-[0.22em] tabular-nums"
                    />
                    <Button
                      type="button"
                      onClick={verify}
                      disabled={!canVerify || lookup.isPending}
                      className="h-11 shrink-0 gap-1.5 rounded-xl bg-linear-to-l from-emerald-600 to-teal-500 px-4 text-[11.5px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
                    >
                      {lookup.isPending ? (
                        <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" aria-hidden="true" />
                      ) : (
                        <CatIcon name="search" className="h-4 w-4" aria-hidden="true" />
                      )}
                      <span className="whitespace-nowrap">{lookup.isPending ? t("wtrChecking") : t("wtrVerifyBtn")}</span>
                    </Button>
                  </div>
                  <p
                    id="wtr-receiver-no-hint"
                    className={cn(
                      "flex items-center gap-1.5 text-[10.5px] font-semibold",
                      lookupError ? "text-rose-500 dark:text-rose-300" : "text-slate-400 dark:text-slate-500",
                    )}
                    role={lookupError ? "alert" : undefined}
                    aria-live={lookupError ? "assertive" : "polite"}
                  >
                    {lookupError ? (
                      <>
                        <CatIcon name="circle-x" className="h-3 w-3 shrink-0" aria-hidden="true" />
                        <span className="min-w-0">{lookupError}</span>
                      </>
                    ) : null}
                  </p>
                </div>

                {/* the CONFIRMED receiver card (lookup success) */}
                {receiver ? (
                  <div className="card-in rounded-2xl border border-emerald-300/70 bg-emerald-500/[0.06] p-3.5 dark:border-emerald-500/30 dark:bg-emerald-500/[0.08]">
                    <p className="flex items-center gap-1.5 text-[9.5px] font-extrabold uppercase tracking-wide text-emerald-600 dark:text-emerald-300">
                      <CatIcon name="circle-check" className="h-3 w-3 shrink-0" aria-hidden="true" />
                      {t("wtrReceiverTitle")}
                    </p>
                    <div className="mt-2 flex items-center gap-2.5">
                      <span
                        className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-sm"
                        style={{ backgroundImage: grad("#0ea5e9", "#0284c7") }}
                        aria-hidden="true"
                      >
                        <CatIcon name={receiverSystemIcon} className="h-4.5 w-4.5" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
                          {receiver.orgName}
                        </span>
                        <span className="block truncate text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                          {t("wtrReceiverSystem")}: {receiverSystem?.name ?? ""}
                        </span>
                      </span>
                      {receiver.demo ? (
                        <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-amber-300/60 bg-amber-400/15 px-2 py-0.5 text-[9.5px] font-extrabold text-amber-700 dark:border-amber-500/30 dark:bg-amber-500/15 dark:text-amber-300">
                          <CatIcon name="eye" className="h-2.5 w-2.5 shrink-0" aria-hidden="true" />
                          <span className="truncate">{t("modDemoNote")}</span>
                        </span>
                      ) : null}
                    </div>
                    <div className="mt-2 flex items-center justify-between gap-2 rounded-xl bg-white/80 px-3 py-1.5 dark:bg-white/[0.06]">
                      <span className="min-w-0 truncate text-[10px] font-extrabold text-slate-400 dark:text-slate-500">
                        {t("wtrReceiverWallet")}
                      </span>
                      <span dir="ltr" className="shrink-0 font-mono text-[13px] font-extrabold tabular-nums tracking-[0.14em] text-slate-700 dark:text-slate-200">
                        {formatWalletNo(receiver.walletNo)}
                      </span>
                    </div>
                  </div>
                ) : null}

                <DialogFooter className="gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={close}
                    disabled={lookup.isPending}
                    className="h-10 rounded-xl px-5 text-[12.5px] font-bold"
                  >
                    {t("modRecCancelBtn")}
                  </Button>
                  <Button
                    type="button"
                    disabled={!receiver}
                    onClick={() => setStep(2)}
                    className="h-10 gap-2 rounded-xl bg-linear-to-l from-emerald-600 to-teal-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
                  >
                    {t("modNextPage")}
                  </Button>
                </DialogFooter>
              </div>
            ) : step === 2 ? (
              /* ==================== STEP 2 — amount + note ==================== */
              <div className="space-y-4 p-5">
                {/* the dual-numeral amount input (the topup idiom, 1..10,000) */}
                <div className="space-y-1.5">
                  <label
                    htmlFor="wtr-amount"
                    className="flex items-center justify-between gap-2 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
                  >
                    <span className="min-w-0 truncate">{t("wtrAmountLabel")}</span>
                    <span dir="ltr" className="shrink-0 text-[10px] font-black tracking-wide text-slate-400 dark:text-slate-500">
                      {fmtNum(1, lang)} — {fmtNum(10_000, lang)} SAR
                    </span>
                  </label>
                  <Input
                    id="wtr-amount"
                    value={amountRaw}
                    onChange={(e) => setAmountRaw(e.target.value)}
                    placeholder={t("walletAmountPh")}
                    inputMode="decimal"
                    autoComplete="off"
                    dir="auto"
                    aria-describedby="wtr-amount-hint"
                    aria-invalid={!neutral && !amountValid ? true : undefined}
                    className={cn(
                      "h-12 rounded-xl text-center font-display text-[20px] font-extrabold tabular-nums",
                      !neutral && !amountValid && "border-rose-400 focus-visible:ring-rose-400/30",
                    )}
                  />
                  <p
                    id="wtr-amount-hint"
                    className={cn(
                      "flex items-center gap-1.5 text-[10.5px] font-semibold",
                      neutral
                        ? "text-slate-400 dark:text-slate-500"
                        : amountValid
                          ? "text-emerald-600 dark:text-emerald-300"
                          : "text-rose-500 dark:text-rose-300",
                    )}
                    aria-live="polite"
                  >
                    <CatIcon
                      name={neutral ? "info" : amountValid ? "circle-check" : "circle-x"}
                      className="h-3 w-3 shrink-0"
                      aria-hidden="true"
                    />
                    <span className="min-w-0">
                      {neutral
                        ? t("walletAmountHint")
                        : !parsed.ok || !amountInBounds
                          ? t("walletTopupInvalid")
                          : insufficient
                            ? t("wtrInsufficientErr")
                            : `${t("wtrBalanceAfter")}: ${walletMoney(balanceMinor - parsed.minor, lang)}`}
                    </span>
                  </p>
                </div>

                {/* quick amounts — the transfer pills */}
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[10.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                    {t("walletQuickAmounts")}
                  </span>
                  {TRANSFER_QUICK_AMOUNTS.map((major) => {
                    const active = parsed.ok && parsed.minor === major * 100;
                    return (
                      <button
                        key={major}
                        type="button"
                        onClick={() => setAmountRaw(String(major))}
                        aria-pressed={active}
                        className={cn(
                          "rounded-full border px-3 py-1 text-[11px] font-extrabold tabular-nums transition active:scale-95",
                          active
                            ? "border-emerald-400 bg-linear-to-b from-emerald-500 to-teal-600 text-white shadow-sm ring-2 ring-emerald-400 dark:border-emerald-500"
                            : "border-slate-200 bg-linear-to-b from-white to-slate-50 text-slate-600 hover:border-emerald-400 hover:text-emerald-600 dark:border-white/10 dark:from-white/[0.06] dark:to-white/[0.02] dark:text-slate-300 dark:hover:border-emerald-500/40 dark:hover:text-emerald-300",
                        )}
                      >
                        {fmtNum(major, lang)}
                      </button>
                    );
                  })}
                </div>

                {/* the optional note */}
                <div className="space-y-1.5">
                  <label
                    htmlFor="wtr-note"
                    className="flex items-center justify-between gap-2 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
                  >
                    <span className="min-w-0 truncate">{t("wtrNoteLabel")}</span>
                    <span dir="ltr" className="shrink-0 text-[9.5px] font-black tabular-nums text-slate-400 dark:text-slate-500">
                      {fmtNum(note.length, lang)}/120
                    </span>
                  </label>
                  <Input
                    id="wtr-note"
                    value={note}
                    onChange={(e) => setNote(e.target.value.slice(0, 120))}
                    placeholder={t("wtrNotePh")}
                    maxLength={120}
                    dir="auto"
                    className="h-11 rounded-xl text-[12.5px] font-semibold"
                  />
                </div>

                {/* the balance-after preview + the fee-free note */}
                {parsed.ok && amountValid ? (
                  <div className="card-in space-y-2 rounded-2xl border border-slate-200/80 bg-white/70 p-3 dark:border-white/10 dark:bg-white/[0.03]">
                    <div className="flex items-center justify-between gap-2">
                      <p className="flex min-w-0 items-center gap-1.5 text-[10.5px] font-extrabold text-slate-500 dark:text-slate-400">
                        <CatIcon name="trending-up" className="h-3.5 w-3.5 shrink-0 text-emerald-500" aria-hidden="true" />
                        <span className="truncate">{t("wtrBalanceAfter")}</span>
                      </p>
                      <p dir="ltr" className="shrink-0 font-display text-[14px] font-extrabold tabular-nums text-emerald-600 dark:text-emerald-300">
                        {walletMoney(balanceMinor - parsed.minor, lang)}
                      </p>
                    </div>
                    <p className="flex items-center gap-1.5 text-[10px] font-bold text-teal-600 dark:text-teal-300">
                      <CatIcon name="zap" className="h-3 w-3 shrink-0" aria-hidden="true" />
                      <span className="min-w-0 truncate">{t("wtrFeesNote")}</span>
                    </p>
                  </div>
                ) : (
                  <p className="flex items-center gap-1.5 rounded-xl bg-teal-500/[0.07] px-3 py-2 text-[10px] font-bold text-teal-600 dark:bg-teal-500/10 dark:text-teal-300">
                    <CatIcon name="zap" className="h-3 w-3 shrink-0" aria-hidden="true" />
                    <span className="min-w-0 truncate">{t("wtrFeesNote")}</span>
                  </p>
                )}

                <DialogFooter className="gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setStep(1)}
                    className="h-10 rounded-xl px-5 text-[12.5px] font-bold"
                  >
                    {t("modPrevPage")}
                  </Button>
                  <Button
                    type="button"
                    disabled={!amountValid}
                    onClick={() => setStep(3)}
                    className="h-10 gap-2 rounded-xl bg-linear-to-l from-emerald-600 to-teal-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
                  >
                    {t("modNextPage")}
                  </Button>
                </DialogFooter>
              </div>
            ) : (
              /* ==================== STEP 3 — PIN confirmation ==================== */
              <div className="space-y-4 p-5">
                {/* the sealed summary — receiver + amount + PIN law */}
                <div className="rounded-2xl border border-slate-200/80 bg-white/70 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
                  <div className="flex items-center gap-2.5">
                    <span
                      className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-sm"
                      style={{ backgroundImage: grad("#0ea5e9", "#0284c7") }}
                      aria-hidden="true"
                    >
                      <CatIcon name={receiverSystemIcon} className="h-4 w-4" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[12px] font-extrabold text-slate-800 dark:text-slate-100">
                        {receiver?.orgName}
                      </span>
                      <span dir="ltr" className="block truncate font-mono text-[10px] font-bold tabular-nums text-slate-400 dark:text-slate-500">
                        {receiver ? formatWalletNo(receiver.walletNo) : ""}
                      </span>
                    </span>
                    <span dir="ltr" className="shrink-0 font-display text-[15px] font-extrabold tabular-nums text-slate-800 dark:text-white">
                      {formattedAmount}
                      <span className="ms-1 text-[10px] font-bold text-slate-400 dark:text-slate-500">SAR</span>
                    </span>
                  </div>
                  <p className="mt-2.5 flex items-start gap-1.5 border-t border-dashed border-slate-200/70 pt-2.5 text-[10.5px] font-semibold leading-relaxed text-slate-500 dark:border-white/10 dark:text-slate-400">
                    <CatIcon name="shield-check" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-500" aria-hidden="true" />
                    <span className="min-w-0">
                      {t("wtrPinStepDesc", { n: pinMinLen, amount: formattedAmount })}
                    </span>
                  </p>
                </div>

                {walletQuery.isPending ? (
                  /* the wallet projection is loading — PIN state unknown yet */
                  <div className="flex justify-center py-2" aria-hidden="true">
                    <Skeleton className="h-14 w-48 rounded-2xl" />
                  </div>
                ) : pinSet ? (
                  <>
                    <p className="text-center text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                      {t("wtrPinStepTitle")}
                    </p>
                    <PinInput
                      value={pin}
                      onChange={setPin}
                      error={pinError}
                      minLength={pinLen ?? 4}
                      maxLength={pinLen ?? 8}
                      onEnter={() => {
                        if (pin.trim().length >= pinMinLen && !send.isPending) send.mutate();
                      }}
                      label={t("wtrPinStepTitle")}
                    />
                    {pinLen != null ? (
                      <p className="flex items-center justify-center gap-1 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                        <CatIcon name="info" className="h-3 w-3 shrink-0" aria-hidden="true" />
                        {t("pinEnterN", { n: pinLen })}
                      </p>
                    ) : null}
                    {pinError ? (
                      <p
                        role="alert"
                        aria-live="assertive"
                        className="flex items-center justify-center gap-1.5 rounded-xl border border-rose-300/60 bg-rose-500/10 px-3 py-2 text-[11px] font-bold text-rose-600 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-300"
                      >
                        <CatIcon name="circle-alert" className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                        {t("wtrPinInvalidErr")}
                      </p>
                    ) : null}
                  </>
                ) : (
                  /* pinSet === false — the sealed notice (define the PIN from
                   * the shift settings first; hint only, no navigation) */
                  <div
                    role="alert"
                    className="flex items-start gap-3 rounded-2xl border border-amber-300/70 bg-amber-500/[0.07] p-4 dark:border-amber-500/30 dark:bg-amber-500/10"
                  >
                    <span
                      className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-sm"
                      style={{ backgroundImage: grad("#f59e0b", "#d97706") }}
                      aria-hidden="true"
                    >
                      <CatIcon name="key-round" className="h-4.5 w-4.5" />
                    </span>
                    <p className="min-w-0 text-[11.5px] font-bold leading-relaxed text-amber-700 dark:text-amber-300">
                      {t("wtrPinNotSetErr")}
                    </p>
                  </div>
                )}

                <DialogFooter className="gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setStep(2)}
                    disabled={send.isPending}
                    className="h-10 rounded-xl px-5 text-[12.5px] font-bold"
                  >
                    {t("modPrevPage")}
                  </Button>
                  <Button
                    type="button"
                    disabled={!pinSet || !receiver || !amountValid || send.isPending || pin.trim().length < pinMinLen}
                    onClick={confirm}
                    className="h-10 gap-2 rounded-xl bg-linear-to-l from-emerald-600 to-teal-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
                  >
                    {send.isPending ? (
                      <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" aria-hidden="true" />
                    ) : (
                      <CatIcon name="arrow-left-right" className="h-4 w-4" aria-hidden="true" />
                    )}
                    <span className="whitespace-nowrap">{send.isPending ? t("wtrSending") : t("wtrConfirmBtn")}</span>
                  </Button>
                </DialogFooter>
              </div>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

/* --------------------- the premium ledger sheet (history) ------------------- */

type LedgerFilter = "all" | "in" | "out";

const LEDGER_FILTERS: { id: LedgerFilter; key: string }[] = [
  { id: "all", key: "walletFilterAll" },
  { id: "in", key: "walletFilterIn" },
  { id: "out", key: "walletFilterOut" },
];

interface TxnGroup {
  bucket: DayBucket;
  netMinor: number;
  txns: WalletTxnDTO[];
}

/** The full wallet history — a BANK-GRADE statement: summary strip, balance
 *  sparkline, in/out filters, day-grouped sealed rows with the verifiable
 *  balance-after chain, the top-up requests queue, and a CSV export.
 *  ROUND 144 — "transfer" rows join the statement (sky tile family, the
 *  kind title from walletTxnKindTransfer, in/out tint by the signed law).
 *  ROUND 147 — every transaction row is a clearly-clickable EXPANDABLE
 *  button (chevron + aria-expanded/aria-controls + the walletTxnExpand/
 *  Collapse labels): the collapsed row stays the classic sealed line; the
 *  expanded panel reveals the full note, the full mono reference + a copy
 *  chip, the actor + the full timestamp, and the sealed balance-after. */
export function WalletLedgerDialog({
  open,
  onOpenChange,
  instance,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  instance: InstanceDTO;
}) {
  const { t, lang } = useT();
  const [filter, setFilter] = useState<LedgerFilter>("all");

  /* ROUND 147 — the expanded-rows set (the EXPANDED txn ids only; every
   * row is an expandable button, collapsed by default). */
  const [expandedTxns, setExpandedTxns] = useState<Set<string>>(() => new Set<string>());

  const toggleTxnExpanded = (id: string): void => {
    setExpandedTxns((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  /* the filter + the expanded set reset between openings — every visit
   * starts at the full statement with all rows collapsed. Reset via the
   * dialog's own onOpenChange flow (an event handler, NOT an effect) so
   * no setState ever fires inside an effect. */
  const handleOpenChange = (next: boolean): void => {
    if (!next) {
      setFilter("all");
      setExpandedTxns(new Set<string>());
    }
    onOpenChange(next);
  };

  const walletQuery = useQuery({
    queryKey: ["wallet", instance.id],
    queryFn: () => fetchWallet(instance.id),
    enabled: open,
    staleTime: 15_000,
  });
  const wallet: WalletDTO | undefined = walletQuery.data;

  /* the statement summary (over the FULL ledger — not the filtered lens) */
  const totals = useMemo(() => {
    let inMinor = 0;
    let outMinor = 0;
    for (const txn of wallet?.txns ?? []) {
      if (txn.amountMinor > 0) inMinor += txn.amountMinor;
      else outMinor += -txn.amountMinor;
    }
    return { inMinor, outMinor, count: wallet?.txns.length ?? 0 };
  }, [wallet]);

  /* the balance curve: txns arrive newest-first → reverse to chronological,
   * then plot balanceAfterMinor/100 at the display boundary */
  const sparkData = useMemo(() => {
    if (!wallet || wallet.txns.length < 2) return [] as { value: number }[];
    return [...wallet.txns].reverse().map((txn) => ({ value: toDisplayUnits(txn.balanceAfterMinor) }));
  }, [wallet]);
  const sparkId = useMemo(
    () => `wallet-spark-${instance.id.replace(/[^a-zA-Z0-9_-]/g, "")}`,
    [instance.id],
  );

  /* day-grouped rows under the active filter (newest-first, buckets merge) */
  const groups = useMemo(() => {
    const source = wallet?.txns ?? [];
    const filtered =
      filter === "in"
        ? source.filter((x) => x.amountMinor > 0)
        : filter === "out"
          ? source.filter((x) => x.amountMinor < 0)
          : source;
    const now = new Date();
    const buckets: TxnGroup[] = [];
    for (const txn of filtered) {
      const bucket = dayBucketOf(txn.createdAt, now);
      const last = buckets[buckets.length - 1];
      if (last && last.bucket === bucket) {
        last.txns.push(txn);
        last.netMinor += txn.amountMinor;
      } else {
        buckets.push({ bucket, netMinor: txn.amountMinor, txns: [txn] });
      }
    }
    return buckets;
  }, [wallet, filter]);
  const visibleCount = useMemo(
    () => groups.reduce((n, group) => n + group.txns.length, 0),
    [groups],
  );

  /* the top-up requests — PENDING first, then paid, then the terminal ones */
  const sortedTopups = useMemo(() => {
    if (!wallet) return [] as WalletTopupDTO[];
    const rank = (status: string) => (status === "pending" ? 0 : status === "paid" ? 1 : 2);
    return [...wallet.topups].sort(
      (a, b) =>
        rank(a.effectiveStatus) - rank(b.effectiveStatus) ||
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
    );
  }, [wallet]);

  /* the CSV export — client-side Blob, BOM-seeded for Excel Arabic */
  const exportHistory = () => {
    if (!wallet || wallet.txns.length === 0) return;
    const csv = buildWalletCsv(wallet.txns);
    const blob = new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `wallet-history-${instance.id.slice(0, 8)}.csv`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent
        dir={lang === "ar" ? "rtl" : "ltr"}
        className="max-h-[85vh] gap-0 overflow-y-auto rounded-3xl p-0 sm:max-w-2xl nice-scroll"
      >
        {/* R163 — pe-14 keeps the whole title row (and the «الرصيد المتاح»
            chip at its end) clear of the dialog's floating close (X), the
            same guard every header that pins content at the inline end uses. */}
        <DialogHeader className="border-b border-slate-200/70 p-5 pe-14 dark:border-white/10">
          <DialogTitle className="flex flex-wrap items-center gap-2.5 font-display text-[17px] font-extrabold text-slate-900 dark:text-white">
            <span
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg"
              style={{ backgroundImage: grad("#059669", "#0f766e") }}
              aria-hidden="true"
            >
              <CatIcon name="receipt" className="h-[15px] w-[15px]" />
            </span>
            <span className="min-w-0 flex-1">{t("walletHistoryTitle")}</span>
            {wallet ? (
              <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-emerald-500/25 bg-emerald-500/10 px-2.5 py-1 text-[10px] font-extrabold text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/15 dark:text-emerald-300">
                {t("walletBalanceLabel")}
                <span dir="ltr" className="font-display tabular-nums">
                  {walletMoney(wallet.balanceMinor, lang)}
                </span>
              </span>
            ) : null}
          </DialogTitle>
          <DialogDescription className="ps-[46px] text-[12.5px]">
            {t("walletHistoryDesc")}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 p-5">
          {walletQuery.isPending ? (
            /* the loading skeleton — 3 statement rows */
            <div className="space-y-2">
              {[0, 1, 2].map((i) => (
                <Skeleton key={i} className="h-16 w-full rounded-2xl" />
              ))}
            </div>
          ) : !wallet ? (
            /* the premium empty state */
            <div className="rounded-2xl border-2 border-dashed border-slate-200 bg-white/50 p-6 text-center dark:border-white/10 dark:bg-white/[0.02]">
              <span
                className="mx-auto grid h-12 w-12 place-items-center rounded-2xl text-white shadow-md"
                style={{ backgroundImage: grad("#059669", "#0f766e") }}
                aria-hidden="true"
              >
                <CatIcon name="wallet" className="h-5 w-5" />
              </span>
              <p className="mt-3 text-[13px] font-extrabold text-slate-700 dark:text-slate-200">
                {t("walletNoHistory")}
              </p>
              <p className="mt-1 text-[11px] font-semibold text-slate-400 dark:text-slate-500">
                {t("walletNoHistoryDesc")}
              </p>
            </div>
          ) : (
            <>
              {/* the summary strip — totals + count */}
              <div
                className="card-in grid grid-cols-3 gap-2 rounded-2xl border border-slate-200/80 bg-white/60 p-3 dark:border-white/10 dark:bg-white/[0.03]"
                style={{ animationDelay: "0ms" }}
              >
                <div className="min-w-0 rounded-xl bg-emerald-500/[0.08] p-2.5 dark:bg-emerald-500/10">
                  <p className="flex items-center gap-1 text-[9.5px] font-extrabold uppercase tracking-wide text-emerald-600 dark:text-emerald-300">
                    <CatIcon name="arrow-down-to-line" className="h-3 w-3 shrink-0" aria-hidden="true" />
                    <span className="truncate">{t("walletTotalIn")}</span>
                  </p>
                  <p dir="ltr" className="mt-1 truncate font-display text-[14px] font-extrabold tabular-nums text-emerald-700 dark:text-emerald-300">
                    +{walletMoney(totals.inMinor, lang)}
                  </p>
                </div>
                <div className="min-w-0 rounded-xl bg-rose-500/[0.08] p-2.5 dark:bg-rose-500/10">
                  <p className="flex items-center gap-1 text-[9.5px] font-extrabold uppercase tracking-wide text-rose-600 dark:text-rose-300">
                    <CatIcon name="arrow-up-from-line" className="h-3 w-3 shrink-0" aria-hidden="true" />
                    <span className="truncate">{t("walletTotalOut")}</span>
                  </p>
                  <p dir="ltr" className="mt-1 truncate font-display text-[14px] font-extrabold tabular-nums text-rose-600 dark:text-rose-300">
                    −{walletMoney(totals.outMinor, lang)}
                  </p>
                </div>
                <div className="min-w-0 rounded-xl bg-slate-500/[0.08] p-2.5 dark:bg-white/[0.06]">
                  <p className="flex items-center gap-1 text-[9.5px] font-extrabold uppercase tracking-wide text-slate-500 dark:text-slate-300">
                    <CatIcon name="activity" className="h-3 w-3 shrink-0" aria-hidden="true" />
                    <span className="truncate">{t("walletTxnCount")}</span>
                  </p>
                  <p dir="ltr" className="mt-1 truncate font-display text-[14px] font-extrabold tabular-nums text-slate-700 dark:text-slate-200">
                    {fmtNum(totals.count, lang)}
                  </p>
                </div>
              </div>

              {/* the balance curve — a slim area sparkline */}
              {sparkData.length >= 2 ? (
                <div
                  className="card-in rounded-2xl border border-slate-200/80 p-3 dark:border-white/10"
                  style={{ animationDelay: "45ms" }}
                >
                  <p className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1 text-[10.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                    <span className="flex items-center gap-1.5">
                      <CatIcon name="trending-up" className="h-3 w-3 text-emerald-500" aria-hidden="true" />
                      {t("walletBalanceSpark")}
                    </span>
                    <span dir="ltr" className="tabular-nums">
                      {fmtNum(sparkData[0]?.value ?? 0, lang)}
                      <span className="mx-1 text-slate-300 dark:text-slate-600">→</span>
                      {fmtNum(sparkData[sparkData.length - 1]?.value ?? 0, lang)}
                      <span className="ms-1 font-bold text-slate-400 dark:text-slate-500">SAR</span>
                    </span>
                  </p>
                  <div className="mt-2 h-16" dir="ltr">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={sparkData} margin={{ top: 2, bottom: 0, left: 0, right: 0 }}>
                        <defs>
                          <linearGradient id={sparkId} x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#10b981" stopOpacity={0.18} />
                            <stop offset="100%" stopColor="#10b981" stopOpacity={0.02} />
                          </linearGradient>
                        </defs>
                        <Area
                          type="monotone"
                          dataKey="value"
                          stroke="#10b981"
                          strokeWidth={2}
                          fill={`url(#${sparkId})`}
                          dot={false}
                          isAnimationActive={false}
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              ) : null}

              {/* the filter row + the CSV export */}
              {wallet.txns.length > 0 ? (
                <div
                  className="card-in flex flex-wrap items-center justify-between gap-2"
                  style={{ animationDelay: "90ms" }}
                >
                  <div
                    role="group"
                    aria-label={t("walletHistoryTitle")}
                    className="flex items-center gap-0.5 rounded-full border border-slate-200 bg-white p-0.5 dark:border-white/10 dark:bg-white/[0.04]"
                  >
                    {LEDGER_FILTERS.map((entry) => {
                      const active = filter === entry.id;
                      return (
                        <button
                          key={entry.id}
                          type="button"
                          onClick={() => setFilter(entry.id)}
                          aria-pressed={active}
                          className={cn(
                            "rounded-full px-3 py-1.5 text-[11px] font-extrabold transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/50",
                            active
                              ? "bg-linear-to-l from-emerald-600 to-teal-500 text-white shadow-sm"
                              : "text-slate-500 hover:text-emerald-600 dark:text-slate-400 dark:hover:text-emerald-300",
                          )}
                        >
                          {t(entry.key as never)}
                        </button>
                      );
                    })}
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={exportHistory}
                    className="h-9 shrink-0 gap-1.5 rounded-full px-3.5 text-[11px] font-bold"
                  >
                    <CatIcon name="download" className="h-3.5 w-3.5" aria-hidden="true" />
                    {t("walletExportHistory")}
                  </Button>
                </div>
              ) : null}

              {/* the append-only ledger — grouped by day */}
              <section className="card-in space-y-2" style={{ animationDelay: "135ms" }}>
                <div className="flex items-center justify-between gap-2">
                  <p className="flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-wide text-slate-600 dark:text-slate-300">
                    <CatIcon name="receipt" className="h-3 w-3" aria-hidden="true" />
                    {t("walletTxnsSection")}
                  </p>
                  <span
                    dir="ltr"
                    className="rounded-full bg-slate-100 px-2 py-px text-[9.5px] font-black tabular-nums text-slate-500 dark:bg-white/10 dark:text-slate-400"
                  >
                    {fmtNum(visibleCount, lang)}
                  </span>
                </div>

                {wallet.txns.length === 0 ? (
                  /* no movements at all — the premium dashed card */
                  <div className="rounded-2xl border-2 border-dashed border-slate-200 bg-white/50 p-6 text-center dark:border-white/10 dark:bg-white/[0.02]">
                    <span
                      className="mx-auto grid h-12 w-12 place-items-center rounded-2xl text-white shadow-md"
                      style={{ backgroundImage: grad("#059669", "#0f766e") }}
                      aria-hidden="true"
                    >
                      <CatIcon name="wallet" className="h-5 w-5" />
                    </span>
                    <p className="mt-3 text-[13px] font-extrabold text-slate-700 dark:text-slate-200">
                      {t("walletNoHistory")}
                    </p>
                    <p className="mt-1 text-[11px] font-semibold text-slate-400 dark:text-slate-500">
                      {t("walletNoHistoryDesc")}
                    </p>
                  </div>
                ) : visibleCount === 0 ? (
                  <p className="rounded-2xl border-2 border-dashed border-slate-200 py-5 text-center text-[12px] font-bold text-slate-400 dark:border-white/10 dark:text-slate-500">
                    {t("walletEmptyTxns")}
                  </p>
                ) : (
                  <div className="max-h-[52vh] overflow-y-auto nice-scroll pe-1 rounded-2xl border border-slate-200/80 bg-white/70 dark:border-white/[0.07] dark:bg-white/[0.02]">
                    <ul className="divide-y divide-slate-100 dark:divide-white/5">
                      {groups.map((group) => (
                        <Fragment key={`${group.bucket}-${group.txns[0]?.id ?? "group"}`}>
                          {/* the sticky day-group header pill */}
                          <li className="sticky top-0 z-10 bg-white/95 pt-2 pb-1.5 backdrop-blur-md dark:bg-[#05080f]/95">
                            <div className="flex flex-wrap items-center gap-x-2 gap-y-1 rounded-full border border-slate-200/80 bg-white/85 px-3 py-1 dark:border-white/10 dark:bg-white/[0.05]">
                              <span className="text-[10.5px] font-extrabold uppercase tracking-wide text-slate-600 dark:text-slate-300">
                                {t(DAY_BUCKET_KEY[group.bucket] as never)}
                              </span>
                              <span
                                dir="ltr"
                                className="rounded-full bg-slate-100 px-1.5 py-px text-[9px] font-black tabular-nums text-slate-500 dark:bg-white/10 dark:text-slate-400"
                              >
                                {fmtNum(group.txns.length, lang)}
                              </span>
                              <span
                                dir="ltr"
                                className={cn(
                                  "ms-auto text-[10.5px] font-extrabold tabular-nums",
                                  group.netMinor >= 0
                                    ? "text-emerald-600 dark:text-emerald-300"
                                    : "text-rose-500 dark:text-rose-300",
                                )}
                              >
                                {group.netMinor >= 0 ? "+" : "−"}
                                {walletMoney(Math.abs(group.netMinor), lang)}
                              </span>
                            </div>
                          </li>

                          {/* the sealed rows — ROUND 147: each row is a
                              clearly-clickable EXPANDABLE button (chevron
                              + aria-expanded/aria-controls + the detail
                              panel rendered under the open row) */}
                          {group.txns.map((txn) => {
                            const style = TXN_KIND_STYLE[txn.kind] ?? TXN_KIND_STYLE.adjust;
                            const credit = txn.amountMinor > 0;
                            const expanded = expandedTxns.has(txn.id);
                            const panelId = `wallet-txn-${txn.id.replace(/[^a-zA-Z0-9_-]/g, "")}`;
                            return (
                              <li key={txn.id}>
                                <button
                                  type="button"
                                  onClick={() => toggleTxnExpanded(txn.id)}
                                  aria-expanded={expanded}
                                  aria-controls={panelId}
                                  aria-label={expanded ? t("walletTxnCollapse") : t("walletTxnExpand")}
                                  className="flex w-full items-start gap-3 px-3 py-3 text-start transition-colors hover:bg-slate-50/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-emerald-400/60 active:bg-slate-100/70 dark:hover:bg-white/[0.03] dark:active:bg-white/[0.05]"
                                >
                                  <span
                                    className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-sm"
                                    style={{ backgroundImage: grad(style.c1, style.c2) }}
                                    aria-hidden="true"
                                  >
                                    <CatIcon name={style.icon} className="h-4 w-4" />
                                  </span>
                                  <span className="min-w-0 flex-1">
                                    <span className="flex flex-wrap items-baseline gap-x-1.5 gap-y-0.5">
                                      <span className="text-[12px] font-extrabold text-slate-800 dark:text-slate-100">
                                        {t(style.key as never)}
                                      </span>
                                      {txn.reference ? (
                                        <span
                                          dir="ltr"
                                          title={t("walletTxnId")}
                                          className="font-mono text-[9.5px] font-bold text-slate-500 dark:text-slate-400"
                                        >
                                          <span className="sr-only">{t("walletTxnId")}: </span>
                                          {txn.reference}
                                        </span>
                                      ) : null}
                                    </span>
                                    {txn.note ? (
                                      <span
                                        dir="auto"
                                        className="mt-0.5 block truncate text-[10.5px] font-semibold text-slate-500 dark:text-slate-400"
                                      >
                                        {txn.note}
                                      </span>
                                    ) : null}
                                    <span className="mt-1 flex flex-wrap items-center gap-x-1.5 gap-y-0.5 text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                                      {txn.actorName ? (
                                        <span className="min-w-0 truncate">
                                          {t("walletTxnActor")} {txn.actorName}
                                          <span className="mx-1" aria-hidden="true">·</span>
                                        </span>
                                      ) : null}
                                      <span>{relTime(txn.createdAt, lang)}</span>
                                      <span
                                        className="inline-block h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-400"
                                        title={t("walletSecureBadge")}
                                        aria-label={t("walletSecureBadge")}
                                      />
                                    </span>
                                  </span>
                                  <span className="shrink-0 text-end">
                                    <span
                                      dir="ltr"
                                      className={cn(
                                        "block text-[13px] font-extrabold tabular-nums",
                                        credit ? "text-emerald-600 dark:text-emerald-300" : "text-rose-500 dark:text-rose-300",
                                      )}
                                    >
                                      {credit ? "+" : "−"}
                                      {walletMoney(Math.abs(txn.amountMinor), lang)}
                                    </span>
                                    <span className="mt-0.5 block text-[9px] font-semibold text-slate-400 dark:text-slate-500">
                                      {t("walletBalanceAfter", { amount: fmtNum(toDisplayUnits(txn.balanceAfterMinor), lang) })}
                                    </span>
                                  </span>
                                  <CatIcon
                                    name="chevron-down"
                                    className={cn(
                                      "mt-1 h-4 w-4 shrink-0 text-slate-300 transition-transform duration-200 dark:text-slate-600",
                                      expanded && "rotate-180",
                                    )}
                                    aria-hidden="true"
                                  />
                                </button>

                                {/* the EXPANDED detail panel — the full note,
                                    the full mono reference + copy chip, the
                                    actor + the full timestamp, and the
                                    sealed balance-after; wired to the row's
                                    aria-controls and rendered only when open */}
                                {expanded ? (
                                  <div
                                    id={panelId}
                                    className="space-y-2 border-t border-dashed border-slate-200/70 px-3.5 pb-3 pt-2 dark:border-white/10"
                                  >
                                    {txn.note ? (
                                      <p
                                        dir="auto"
                                        className="text-[11px] font-semibold leading-relaxed text-slate-600 dark:text-slate-300"
                                      >
                                        {txn.note}
                                      </p>
                                    ) : null}
                                    {txn.reference ? (
                                      <div className="flex items-center justify-between gap-2 rounded-xl border border-slate-200/80 bg-white/70 px-3 py-1.5 dark:border-white/[0.07] dark:bg-white/[0.03]">
                                        <p
                                          dir="ltr"
                                          className="min-w-0 flex-1 truncate font-mono text-[11px] font-extrabold text-slate-600 dark:text-slate-300"
                                        >
                                          <span className="sr-only">{t("walletTxnId")}: </span>
                                          {txn.reference}
                                        </p>
                                        <button
                                          type="button"
                                          onClick={() => {
                                            void navigator.clipboard?.writeText(txn.reference).then(
                                              () => toast.success(t("secCopyTip")),
                                              () => toast.error(t("errorText")),
                                            );
                                          }}
                                          title={t("secCopyTip")}
                                          aria-label={t("secCopyTip")}
                                          className="grid h-6 w-6 shrink-0 place-items-center rounded-lg border border-slate-200 bg-white text-slate-500 transition hover:border-emerald-300 hover:text-emerald-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/60 active:scale-95 dark:border-white/10 dark:bg-white/[0.06] dark:text-slate-300 dark:hover:border-emerald-500/40 dark:hover:text-emerald-300"
                                        >
                                          <CatIcon name="copy" className="h-3 w-3" aria-hidden="true" />
                                        </button>
                                      </div>
                                    ) : null}
                                    <p className="flex flex-wrap items-center gap-x-1.5 gap-y-0.5 text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                                      <span className="inline-flex min-w-0 items-center gap-1">
                                        <CatIcon name={style.icon} className="h-3 w-3 shrink-0" aria-hidden="true" />
                                        <span className="truncate">{t(style.key as never)}</span>
                                      </span>
                                      {txn.actorName ? (
                                        <>
                                          <span aria-hidden="true">·</span>
                                          <span className="min-w-0 truncate">{txn.actorName}</span>
                                        </>
                                      ) : null}
                                      <span aria-hidden="true">·</span>
                                      <span dir="auto" className="tabular-nums">
                                        {fullStamp(txn.createdAt, lang)}
                                      </span>
                                    </p>
                                    <p className="flex items-center gap-1.5 rounded-xl bg-slate-500/[0.06] px-3 py-1.5 dark:bg-white/[0.04]">
                                      <CatIcon name="shield-check" className="h-3.5 w-3.5 shrink-0 text-emerald-500" aria-hidden="true" />
                                      <span dir="auto" className="min-w-0 text-[10.5px] font-bold text-slate-600 dark:text-slate-300">
                                        {t("walletBalanceAfter", { amount: fmtNum(toDisplayUnits(txn.balanceAfterMinor), lang) })}
                                      </span>
                                    </p>
                                  </div>
                                ) : null}
                              </li>
                            );
                          })}
                        </Fragment>
                      ))}
                    </ul>
                  </div>
                )}
              </section>

              {/* the top-up requests (pending first) */}
              {sortedTopups.length > 0 ? (
                <section className="card-in space-y-2" style={{ animationDelay: "180ms" }}>
                  <p className="flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                    <CatIcon name="hourglass" className="h-3 w-3" aria-hidden="true" />
                    {t("walletTopupsSection")}
                  </p>
                  <div className="max-h-44 space-y-1.5 overflow-y-auto pe-1 nice-scroll">
                    {sortedTopups.map((topup) => {
                      const style = TOPUP_STYLE[topup.effectiveStatus] ?? TOPUP_STYLE.cancelled;
                      return (
                        <div
                          key={topup.id}
                          className="flex flex-wrap items-center gap-2 rounded-xl border border-slate-200/80 bg-white/70 px-3 py-2 transition-colors hover:border-emerald-300/70 dark:border-white/[0.07] dark:bg-white/[0.03] dark:hover:border-emerald-500/30"
                        >
                          <span
                            className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-white"
                            style={{ backgroundImage: grad(style.c1, style.c2) }}
                            aria-hidden="true"
                          >
                            <CatIcon
                              name={
                                topup.effectiveStatus === "pending"
                                  ? "hourglass"
                                  : topup.effectiveStatus === "paid"
                                    ? "circle-check"
                                    : "circle-x"
                              }
                              className="h-3 w-3"
                            />
                          </span>
                          <p dir="ltr" className="min-w-0 flex-1 truncate font-mono text-[10.5px] font-extrabold text-slate-500 dark:text-slate-400">
                            <span className="sr-only">{t("walletTxnId")}: </span>
                            {topup.reference}
                          </p>
                          <span dir="ltr" className="text-[11.5px] font-extrabold tabular-nums text-slate-700 dark:text-slate-200">
                            {walletMoney(topup.amountMinor, lang)}
                          </span>
                          <span
                            className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[9.5px] font-extrabold text-white"
                            style={{ backgroundImage: grad(style.c1, style.c2) }}
                          >
                            {t(
                              topup.effectiveStatus === "pending"
                                ? "addonStatusPending"
                                : topup.effectiveStatus === "paid"
                                  ? "orderStatusPaid"
                                  : topup.effectiveStatus === "expired"
                                    ? "addonStatusExpired"
                                    : "orderStatusCancelled",
                            )}
                          </span>
                          <span className="text-[9.5px] font-semibold text-slate-400 dark:text-slate-500">
                            {relTime(topup.createdAt, lang)}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </section>
              ) : null}
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

/* ------------------ the wallet checkout option (㉘) ------------------------- */

/** The premium wallet option card riding the billing + add-ons checkouts.
 *  Selected + sufficient balance → the button pays INSTANTLY. */
export function WalletCheckoutOption({
  wallet,
  amountMinor,
  selected,
  onSelect,
  pending,
}: {
  wallet: WalletDTO | null;
  /** the order total in MINOR units (server-priced) */
  amountMinor: number;
  selected: boolean;
  onSelect: () => void;
  pending: boolean;
}) {
  const { t, lang } = useT();
  const balanceMinor = wallet?.balanceMinor ?? 0;
  const sufficient = balanceMinor >= amountMinor;

  return (
    <button
      type="button"
      aria-pressed={selected}
      onClick={onSelect}
      className={cn(
        "relative flex w-full items-center gap-3 overflow-hidden rounded-2xl border p-3.5 text-start transition-all duration-200",
        selected
          ? "border-emerald-500 bg-emerald-50/70 ring-2 ring-emerald-500/50 dark:border-emerald-500/60 dark:bg-emerald-500/[0.08]"
          : "border-emerald-200/80 bg-linear-to-l from-emerald-50/60 to-teal-50/40 hover:border-emerald-300 dark:border-emerald-500/25 dark:from-emerald-500/[0.06] dark:to-teal-500/[0.04] dark:hover:border-emerald-500/40",
      )}
    >
      {/* the one-tap NFC watermark — the instant-pay identity */}
      <CatIcon
        name="nfc"
        className="pointer-events-none absolute end-12 top-1/2 h-10 w-10 -translate-y-1/2 text-emerald-600/10"
        aria-hidden="true"
      />
      <span
        className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-md"
        style={{ backgroundImage: grad("#059669", "#0f766e"), boxShadow: "0 8px 20px -8px rgba(5,150,105,0.7)" }}
        aria-hidden="true"
      >
        <CatIcon name="wallet" className="h-[15px] w-[15px]" />
      </span>
      <span className="min-w-0 flex-1">
        <span className="flex flex-wrap items-center gap-1.5">
          <span className="text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
            {t("walletCheckoutName")}
          </span>
          <span
            title={t("walletInstantPay")}
            className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 px-2 py-px text-[10px] font-extrabold text-emerald-600 dark:text-emerald-300"
          >
            <CatIcon name="zap" className="h-2.5 w-2.5" aria-hidden="true" />
            {t("walletCheckoutInstant")}
          </span>
        </span>
        <span className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[11px] font-semibold">
          <span dir="ltr" className={cn("tabular-nums font-extrabold", sufficient ? "text-emerald-700 dark:text-emerald-300" : "text-rose-500 dark:text-rose-300")}>
            {t("walletCheckoutBalance", { balance: fmtNum(toDisplayUnits(balanceMinor), lang) })}
          </span>
          {pending ? (
            <span className="text-slate-400 dark:text-slate-500">{t("walletCheckoutProcessing")}</span>
          ) : !sufficient ? (
            <span className="text-rose-500 dark:text-rose-300">{t("walletCheckoutInsufficient")}</span>
          ) : null}
        </span>
      </span>
      <span
        className={cn(
          "grid h-5 w-5 shrink-0 place-items-center rounded-full border-2 transition",
          selected ? "border-emerald-500 bg-emerald-500 text-white" : "border-slate-300 dark:border-white/20",
        )}
        aria-hidden="true"
      >
        {selected ? <CatIcon name="check" className="h-3 w-3" /> : null}
      </span>
    </button>
  );
}

/** Re-exported for the checkout integrations (the shared pseudo-method id). */
export { WALLET_CHECKOUT_METHOD_ID };
