"use client";

/**
 * ROUND 79 (UI-A) → ROUND 80 — smart Arabic-first countdown helpers.
 *
 * The owner's exact requested phrasings for the 14-Day Full-Access trial
 * clock, with the FULL Arabic number-agreement law (ROUND 80 precision
 * pass — orthography يوماً + grammar), driven by the server-computed
 * `trialMsLeft` (exact ms; falls back to the coarser trialDaysLeft /
 * trialHoursLeft fields when the ms field is absent):
 *
 *   days 11+      «بقى {days} يوماً»        (singular accusative)
 *   days 3–10     «بقى {days} أيام»          (plural)
 *   days == 2     «بقى يومان فقط»           (dual)
 *   days == 1     «بقى يوم واحد فقط»        (a full day still remains)
 *   hours 11–23   «بقيت {hours} ساعة فقط»
 *   hours 3–10    «بقيت {hours} ساعات فقط»
 *   hours == 2    «بقيت ساعتان فقط»
 *   1 hour        «بقيت ساعة واحدة فقط»
 *   minutes 11+   «بقيت {minutes} دقيقة فقط»
 *   minutes 3–10  «بقيت {minutes} دقائق فقط»
 *   minutes == 2  «بقيت دقيقتان فقط»
 *   1 minute      «بقيت دقيقة واحدة فقط»
 *
 * EN: "{days} days left" / "2 days left" / "1 day left" / "{hours} hours
 * left" / "1 hour left" / "{minutes} minutes left". HI equivalents.
 * Numbers render through fmtNum (Arabic-Indic digits in AR).
 *
 * Also exports the paid-term (planExpiresAt / planDaysLeft) twin with the
 * same number law («ينتهي الاشتراك خلال …» + «بقيت …») and the urgency
 * tone classifiers used by the sidebar chip / billing strip:
 *   trial:  amber (>2 days) → rose (≤2 days, subtle pulse) → critical (hours)
 *   plan:   emerald (>7 days) → amber (≤7 days) → rose (≤2 days)
 */
import type { I18nKey } from "@/lib/i18n";
import type { InstanceDTO, Lang } from "@/lib/types";
import { fmtNum } from "@/lib/utils";

const MINUTE = 60_000;
const HOUR = 3_600_000;
const DAY = 86_400_000;

/** Translator shape accepted by the helpers (useT's t / the pure t()). */
export type CountdownT = (key: I18nKey, vars?: Record<string, string | number>) => string;

type Ent = InstanceDTO["entitlement"];

/** Resolve the best available trial ms remaining (exact ms → coarse fallbacks). */
function trialMs(ent: Ent | null | undefined): number | null {
  if (!ent) return null;
  if (typeof ent.trialMsLeft === "number") return ent.trialMsLeft;
  if ((ent.trialDaysLeft ?? 0) >= 1) return (ent.trialDaysLeft as number) * DAY;
  if (ent.trialHoursLeft != null && ent.trialHoursLeft > 0) return ent.trialHoursLeft * HOUR;
  return null;
}

/** ROUND 80 — the Arabic number-agreement law for DAYS:
 *  1 → "One" key · 2 → "Two" key · 3–10 → "Few" (plural أيام) · 11+ →
 *  "Many" (singular accusative يوماً). Returns the resolved i18n string. */
function daysPhrase(
  days: number,
  t: CountdownT,
  keys: { few: I18nKey; many: I18nKey; two: I18nKey; one: I18nKey },
  fmt: (n: number) => string,
): string {
  if (days >= 11) return t(keys.many, { days: fmt(days) });
  if (days >= 3) return t(keys.few, { days: fmt(days) });
  if (days === 2) return t(keys.two);
  return t(keys.one);
}

/** Same law for HOURS (3–10 → ساعات plural; 11–23 → ساعة). */
function hoursPhrase(
  hours: number,
  t: CountdownT,
  fmt: (n: number) => string,
): string {
  if (hours >= 11) return t("trialLeftHoursMany", { hours: fmt(hours) });
  if (hours >= 3) return t("trialLeftHoursFew", { hours: fmt(hours) });
  if (hours === 2) return t("trialLeftHoursTwo");
  return t("trialLeftOneHour");
}

/** Same law for MINUTES (3–10 → دقائق plural; 11+ → دقيقة). */
function minutesPhrase(
  minutes: number,
  t: CountdownT,
  fmt: (n: number) => string,
): string {
  if (minutes >= 11) return t("trialLeftMinutes", { minutes: fmt(minutes) });
  if (minutes >= 3) return t("trialLeftMinutesFew", { minutes: fmt(minutes) });
  if (minutes === 2) return t("trialLeftMinutesTwo");
  return t("trialLeftMinutesOne");
}

/**
 * The smart countdown label for the trial clock (null when no usable clock
 * remains — callers decide their own fallback).
 */
export function trialCountdownText(
  ent: Ent | null | undefined,
  lang: Lang,
  t: CountdownT,
): string | null {
  const ms = trialMs(ent);
  if (ms == null || ms <= 0) return null;

  const days = Math.floor(ms / DAY);
  if (days >= 1) {
    return daysPhrase(
      days,
      t,
      {
        few: "trialLeftDaysFew",
        many: "trialLeftDaysMany",
        two: "trialLeftTwo",
        one: "trialLeftOne",
      },
      (n) => fmtNum(n, lang)
    );
  }

  /* inside the LAST day (<24h) — hours, then the final minutes */
  const hours = Math.floor(ms / HOUR);
  if (hours >= 1) return hoursPhrase(hours, t, (n) => fmtNum(n, lang));
  const minutes = Math.max(1, Math.floor(ms / MINUTE));
  return minutesPhrase(minutes, t, (n) => fmtNum(n, lang));
}

/** Urgency tier for trial countdown styling. */
export type TrialUrgency = "amber" | "rose" | "critical";

/**
 * >2 days → "amber" (current tone) · exactly 2 days or fewer → "rose"
 * (rose tint + subtle pulse) · inside the last day → "critical" (stronger).
 */
export function trialCountdownTone(ent: Ent | null | undefined): TrialUrgency {
  const ms = trialMs(ent);
  if (ms == null) return "amber";
  if (ms > 2 * DAY) return "amber";
  if (ms >= DAY) return "rose";
  return "critical";
}

/* ------------------------------------------------------------------ */
/* Paid-term twin (planExpiresAt / planDaysLeft)                       */
/* ------------------------------------------------------------------ */

/** «ينتهي الاشتراك خلال {days} يوماً/أيام» — sidebar chip phrasing (number law). */
export function planTermLeftText(
  ent: Ent | null | undefined,
  lang: Lang,
  t: CountdownT,
): string | null {
  const days = ent?.planDaysLeft ?? null;
  if (days == null || days < 1) return null;
  return daysPhrase(
    days,
    t,
    {
      few: "planTermLeftFew",
      many: "planTermLeftMany",
      two: "planTermLeftTwo",
      one: "planTermLeftOne",
    },
    (n) => fmtNum(n, lang)
  );
}

/** «بقيت {days} يوماً/أيام» — the short strip segment (number law). */
export function planTermDaysText(
  ent: Ent | null | undefined,
  lang: Lang,
  t: CountdownT,
): string | null {
  const days = ent?.planDaysLeft ?? null;
  if (days == null || days < 1) return null;
  return daysPhrase(
    days,
    t,
    {
      few: "planTermDaysFew",
      many: "planTermDaysMany",
      two: "planTermDaysTwo",
      one: "planTermDaysOne",
    },
    (n) => fmtNum(n, lang)
  );
}

/** Tone tier for the paid-term countdown: emerald → amber (≤7d) → rose (≤2d). */
export type PlanTermTone = "emerald" | "amber" | "rose";

export function planTermTone(ent: Ent | null | undefined): PlanTermTone {
  const days = ent?.planDaysLeft ?? null;
  if (days == null) return "emerald";
  if (days <= 2) return "rose";
  if (days <= 7) return "amber";
  return "emerald";
}
