"use client";

/**
 * ROUND 84 (84-PROFILE) — the STRICT owner-profile completion gate.
 *
 * A full-screen blocking overlay (z-[110], the wizard-overlay layering
 * pattern) that mounts from the dashboard shell right after the instance
 * query resolves while `instance.ownerProfile?.completed !== true` — i.e.
 * the moment a freshly created system lands its owner on the dashboard.
 * The platform demands the owner's PERSONAL data (gender, date of birth,
 * personal address, nationality, job title, personal phone) with full
 * precision before the workspace unlocks.
 *
 * STRICT by design:
 *  - NO close button, NO backdrop click, NO Escape — the only way out is a
 *    valid submission (the server re-validates everything with zod; a
 *    "later" affordance would only exist for an ALREADY-completed profile,
 *    and a completed profile never mounts this gate).
 *  - the submit button stays disabled until every field passes the SAME
 *    validation the server enforces (mirrored 1:1 below).
 *  - the shell never renders the gate for LOCKED workspaces (billing stays
 *    reachable) nor for the 401 re-auth gate — see dashboard-app.tsx.
 *
 * On success the ["instance", id] query is invalidated so the dashboard
 * unlocks IN PLACE (no reload). A lightweight GET re-check on mount also
 * unlocks the gate if the profile was completed from another device.
 */
import { useEffect, useId, useMemo, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CATEGORY_MAP, SYSTEM_MAP } from "@/data/catalog";
import { COUNTRIES } from "@/data/countries";
import { useT, type I18nKey } from "@/lib/i18n";
import type { InstanceDTO, MemberGender } from "@/lib/types";
import { fetchOwnerProfile, saveOwnerProfile } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { grad, hexAlpha, cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ShakeField, WZ_INPUT, WZ_LABEL } from "@/components/wizard/wizard-shared";
import { PremiumPhoneInput } from "@/components/ui/premium-contact";
import { PremiumDateInput } from "@/components/ui/premium-date-input";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

/* ------------------------------------------------------------------ */
/* Validation — mirrors the server zod contract EXACTLY (1:1).         */
/* If these rules and the route's schema ever drift, the server wins.  */
/* ------------------------------------------------------------------ */

const PHONE_RE = /^\+?[0-9]{8,15}$/;
const YEAR_MS = 365.2425 * 24 * 60 * 60 * 1000;
const MIN_AGE_YEARS = 13;
const MAX_AGE_YEARS = 120;
const COUNTRY_CODES = new Set(COUNTRIES.map((c) => c.code));

const isoDay = (d: Date) => d.toISOString().slice(0, 10);
/** newest allowed birth day = exactly 13 years ago; oldest = 120 years ago */
const MAX_BIRTH_DAY = isoDay(new Date(Date.now() - MIN_AGE_YEARS * YEAR_MS));
const MIN_BIRTH_DAY = isoDay(new Date(Date.now() - MAX_AGE_YEARS * YEAR_MS));

function validBirthDate(v: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return false;
  const t = Date.parse(`${v}T00:00:00Z`);
  if (Number.isNaN(t) || t >= Date.now()) return false;
  const ageYears = (Date.now() - t) / YEAR_MS;
  return ageYears >= MIN_AGE_YEARS && ageYears <= MAX_AGE_YEARS;
}

interface GateFields {
  gender: MemberGender | "";
  birthDate: string;
  address: string;
  nationality: string;
  jobTitle: string;
  phone: string;
}

type Validity = Record<keyof GateFields, boolean>;

const FIELD_ORDER: (keyof GateFields)[] = [
  "gender",
  "birthDate",
  "address",
  "nationality",
  "jobTitle",
  "phone",
];

function fieldValidity(f: GateFields): Validity {
  return {
    gender: f.gender === "male" || f.gender === "female",
    birthDate: validBirthDate(f.birthDate),
    address: f.address.trim().length >= 10 && f.address.trim().length <= 220,
    nationality: COUNTRY_CODES.has(f.nationality),
    jobTitle: f.jobTitle.trim().length >= 2 && f.jobTitle.trim().length <= 80,
    phone: PHONE_RE.test(f.phone.trim()),
  };
}

const ERROR_KEYS: Record<keyof GateFields, I18nKey> = {
  gender: "opgErrGender",
  birthDate: "opgErrBirthDate",
  address: "opgErrAddress",
  nationality: "opgErrNationality",
  jobTitle: "opgErrJobTitle",
  phone: "opgErrPhone",
};

/* ------------------------------------------------------------------ */
/* Small presentational bits                                           */
/* ------------------------------------------------------------------ */

/** Label row with the field's icon (premium per-field iconography). */
function FieldLabel({
  icon,
  htmlFor,
  children,
}: {
  icon: string;
  htmlFor: string;
  children: string;
}) {
  return (
    <Label htmlFor={htmlFor} className={cn(WZ_LABEL, "flex items-center gap-1.5")}>
      <CatIcon name={icon} className="h-3.5 w-3.5 shrink-0 text-brand-500 dark:text-brand-300" />
      {children}
      <span className="text-rose-500" aria-hidden="true">*</span>
    </Label>
  );
}

/** Inline validation message (revealed only for touched/attempted fields). */
function FieldError({ message }: { message: string }) {
  return (
    <p role="alert" className="mt-1.5 flex items-center gap-1 text-[11px] font-bold text-rose-500 dark:text-rose-400">
      <CatIcon name="x" className="h-3 w-3 shrink-0" />
      <span>{message}</span>
    </p>
  );
}

/** Read-only identity chip in the gradient header (org / owner name / email). */
function IdentityChip({
  icon,
  label,
  value,
  ltr,
}: {
  icon: string;
  label: string;
  value: string;
  ltr?: boolean;
}) {
  return (
    <div
      className="min-w-0 rounded-xl border border-white/25 bg-white/15 px-3 py-2 backdrop-blur-sm"
      title={value}
    >
      <p className="flex items-center gap-1 text-[9.5px] font-bold text-white/75">
        <CatIcon name={icon} className="h-3 w-3 shrink-0" />
        {label}
      </p>
      <p
        dir={ltr ? "ltr" : undefined}
        className={cn(
          "mt-0.5 truncate text-[12px] font-extrabold text-white",
          ltr && "text-left"
        )}
      >
        {value || "—"}
      </p>
    </div>
  );
}

/** Circular completion ring (done/total valid fields) with a gradient stroke. */
function ProgressRing({
  done,
  total,
  c1,
  c2,
  label,
}: {
  done: number;
  total: number;
  c1: string;
  c2: string;
  label: string;
}) {
  const gid = useId();
  const r = 26;
  const circumference = 2 * Math.PI * r;
  const pct = total > 0 ? done / total : 0;
  return (
    <div
      className="relative h-16 w-16 shrink-0"
      role="img"
      aria-label={`${label}: ${done}/${total}`}
    >
      <svg viewBox="0 0 64 64" className="h-16 w-16 -rotate-90" aria-hidden="true">
        <defs>
          <linearGradient id={gid} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={c1} />
            <stop offset="100%" stopColor={c2} />
          </linearGradient>
        </defs>
        <circle
          cx="32"
          cy="32"
          r={r}
          fill="none"
          strokeWidth="6"
          className="stroke-slate-200 dark:stroke-white/10"
        />
        <circle
          cx="32"
          cy="32"
          r={r}
          fill="none"
          strokeWidth="6"
          stroke={`url(#${gid})`}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={circumference * (1 - pct)}
          style={{ transition: "stroke-dashoffset 600ms cubic-bezier(0.22,1,0.36,1)" }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center">
        <span className="text-[13px] font-extrabold tabular-nums text-slate-700 dark:text-slate-200">
          {done}
          <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500">/{total}</span>
        </span>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* The gate                                                            */
/* ------------------------------------------------------------------ */

export function OwnerProfileGate({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const panelRef = useRef<HTMLDivElement>(null);

  const system = SYSTEM_MAP[instance.systemId];
  const cat = system ? CATEGORY_MAP[system.c] : undefined;
  const c1 = cat?.c1 ?? "#6d5dfb";
  const c2 = cat?.c2 ?? "#0ea5e9";

  /* stored profile (resume prefill — only present if a row was written) */
  const stored = instance.ownerProfile?.profile;
  const [fields, setFields] = useState<GateFields>({
    gender: stored?.gender ?? "",
    birthDate: stored?.birthDate ?? "",
    address: stored?.address ?? "",
    nationality: stored?.nationality ?? "",
    jobTitle: stored?.jobTitle ?? "",
    phone: stored?.phone ?? "",
  });
  const [touched, setTouched] = useState<Partial<Record<keyof GateFields, boolean>>>({});
  const [attempted, setAttempted] = useState(false);
  /* per-field shake tokens (bumped on blur-fail / submit-fail) */
  const [shakes, setShakes] = useState<Partial<Record<keyof GateFields, number>>>({});
  const [serverError, setServerError] = useState<string | null>(null);

  const bump = (field: keyof GateFields) =>
    setShakes((prev) => ({ ...prev, [field]: (prev[field] ?? 0) + 1 }));

  const validity = useMemo(() => fieldValidity(fields), [fields]);
  const doneCount = FIELD_ORDER.filter((k) => validity[k]).length;
  const allValid = doneCount === FIELD_ORDER.length;

  /* Scroll lock while the gate is up (wizard-overlay pattern). */
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  /* Initial focus on the panel itself. */
  useEffect(() => {
    panelRef.current?.focus();
  }, []);

  /* Server-truth re-check: if the profile was completed from another
   * device (or the client DTO is stale), unlock in place immediately. */
  const profileQuery = useQuery({
    queryKey: ["owner-profile", instance.id],
    queryFn: () => fetchOwnerProfile(instance.id),
    retry: false,
    staleTime: 30_000,
  });
  useEffect(() => {
    if (profileQuery.data?.completed === true) {
      void queryClient.invalidateQueries({ queryKey: ["instance", instance.id] });
    }
  }, [profileQuery.data?.completed, instance.id, queryClient]);

  /* ---------------- save mutation ---------------- */

  const save = useMutation({
    mutationFn: () =>
      saveOwnerProfile(instance.id, {
        gender: fields.gender as MemberGender,
        birthDate: fields.birthDate.trim(),
        address: fields.address.trim(),
        nationality: fields.nationality,
        jobTitle: fields.jobTitle.trim(),
        phone: fields.phone.trim(),
      }),
    onSuccess: () => {
      setServerError(null);
      toast.success(t("opgSavedToast"));
      /* the dashboard unlocks IN PLACE — the instance query re-fetches and
       * ownerProfile.completed flips the shell's gate condition to false */
      void queryClient.invalidateQueries({ queryKey: ["instance", instance.id] });
      void queryClient.invalidateQueries({ queryKey: ["owner-profile", instance.id] });
    },
    onError: (e: Error) => {
      setServerError(e.message);
      toast.error(`${t("opgErrorToast")} — ${e.message}`);
      /* re-shake everything the server just rejected */
      FIELD_ORDER.forEach(bump);
    },
  });

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (save.isPending) return;
    setAttempted(true);
    if (!allValid) {
      /* defensive (the button is disabled while invalid — this covers the
       * Enter-key path): shake + toast the first invalid field */
      FIELD_ORDER.forEach((k) => {
        if (!validity[k]) bump(k);
      });
      const first = FIELD_ORDER.find((k) => !validity[k]);
      if (first) toast.error(t(ERROR_KEYS[first]));
      return;
    }
    setServerError(null);
    save.mutate();
  };

  const showErr = (k: keyof GateFields) => (attempted || touched[k] === true) && !validity[k];
  const shakeToken = (k: keyof GateFields) => (showErr(k) ? (shakes[k] ?? 0) : 0);

  const set = <K extends keyof GateFields>(key: K, value: GateFields[K]) =>
    setFields((prev) => ({ ...prev, [key]: value }));

  /* the gender radio-cards (premium segmented) */
  const genderCards: { value: MemberGender; labelKey: I18nKey; icon: string; g1: string; g2: string }[] = [
    { value: "male", labelKey: "opgGenderMale", icon: "mars", g1: "#10b981", g2: "#0d9488" },
    { value: "female", labelKey: "opgGenderFemale", icon: "venus", g1: "#f43f5e", g2: "#ec4899" },
  ];

  return (
    <div
      className="fixed inset-0 z-[110] overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-label={t("opgAriaLabel")}
    >
      {/* STRICT backdrop — deliberately NOT a button: there is no
          click-to-close. The only exit is a valid submission. */}
      <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md" aria-hidden="true" />

      <div className="relative flex min-h-screen items-start justify-center p-3 sm:items-center sm:p-6">
        <div
          ref={panelRef}
          tabIndex={-1}
          dir={lang === "ar" ? "rtl" : "ltr"}
          className="modal-in relative w-full max-w-2xl overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-2xl outline-none dark:border-white/10 dark:bg-ink-900"
        >
          {/* ——— gradient identity header ——— */}
          <div className="relative overflow-hidden px-5 py-5 sm:px-7 sm:py-6">
            <div className="absolute inset-0" style={{ backgroundImage: grad(c1, c2) }} aria-hidden="true" />
            {/* readability scrim + decorative orbs */}
            <div className="absolute inset-0 bg-slate-950/45" aria-hidden="true" />
            <div
              className="absolute -top-16 start-1/3 h-40 w-40 rounded-full bg-white/15 blur-2xl"
              aria-hidden="true"
            />
            <div
              className="absolute -bottom-20 -end-10 h-44 w-44 rounded-full bg-white/10 blur-2xl"
              aria-hidden="true"
            />

            <div className="relative">
              <div className="flex items-start gap-3.5">
                <span
                  className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl border border-white/30 bg-white/15 text-white shadow-lg backdrop-blur-sm"
                  aria-hidden="true"
                >
                  <CatIcon name="id-card" className="h-5 w-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-white/30 bg-white/15 px-2.5 py-1 text-[10px] font-extrabold text-white backdrop-blur-sm">
                    <CatIcon name="lock" className="h-3 w-3" />
                    {t("opgBadge")}
                  </span>
                  <h2 className="mt-1.5 font-display text-[19px] font-extrabold leading-tight text-white sm:text-[21px]">
                    {t("opgTitle")}
                  </h2>
                  <p className="mt-1 text-[12px] font-semibold leading-relaxed text-white/85">
                    {t("opgDesc")}
                  </p>
                </div>
              </div>

              {/* read-only identity context (org + owner from adminJson) */}
              <div className="mt-4">
                <p className="mb-1.5 text-[9.5px] font-bold uppercase tracking-wider text-white/70">
                  {t("opgIdentityTitle")}
                </p>
                <div className="grid gap-2 sm:grid-cols-3">
                  <IdentityChip icon="building" label={t("opgIdentityOrg")} value={instance.org.name} />
                  <IdentityChip icon="user-round" label={t("opgIdentityName")} value={instance.admin.name} />
                  <IdentityChip icon="mail" label={t("opgIdentityEmail")} value={instance.admin.email} ltr />
                </div>
                <p className="mt-1.5 text-[10px] font-semibold text-white/60">{t("opgIdentityNote")}</p>
              </div>
            </div>
          </div>

          {/* ——— body: the strict form ——— */}
          <form onSubmit={onSubmit} noValidate className="px-5 py-5 sm:px-7 sm:py-6">
            {/* strictness notice */}
            <div className="mb-5 flex items-start gap-2.5 rounded-2xl border border-amber-300/60 bg-amber-50/80 px-3.5 py-2.5 dark:border-amber-500/25 dark:bg-amber-500/10">
              <CatIcon name="lock" className="mt-0.5 h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400" />
              <p className="text-[11.5px] font-bold leading-relaxed text-amber-800 dark:text-amber-200">
                {t("opgStrictNote")}
              </p>
            </div>

            {/* completion progress */}
            <div className="mb-5 flex items-center gap-4 rounded-2xl border border-slate-200/80 bg-slate-50/70 px-4 py-3 dark:border-white/10 dark:bg-white/[0.03]">
              <ProgressRing done={doneCount} total={FIELD_ORDER.length} c1={c1} c2={c2} label={t("opgProgressLabel")} />
              <div className="min-w-0 flex-1">
                <p className="text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200">
                  {t("opgProgressLabel")}
                </p>
                <p className="mt-0.5 text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                  {t("opgProgress", { done: doneCount, total: FIELD_ORDER.length })}
                </p>
                {/* secondary linear bar */}
                <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-white/10">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${(doneCount / FIELD_ORDER.length) * 100}%`,
                      backgroundImage: grad(c1, c2),
                    }}
                  />
                </div>
              </div>
            </div>

            {/* ——— fields ——— */}
            <div className="grid gap-4 sm:grid-cols-2">
              {/* gender — premium segmented radio-cards */}
              <div className="sm:col-span-2">
                <span id="opg-gender-label" className={cn(WZ_LABEL, "flex items-center gap-1.5")}>
                  <CatIcon name="users" className="h-3.5 w-3.5 shrink-0 text-brand-500 dark:text-brand-300" />
                  {t("opgGender")}
                  <span className="text-rose-500" aria-hidden="true">*</span>
                </span>
                <ShakeField token={shakeToken("gender")}>
                  <div
                    role="radiogroup"
                    aria-labelledby="opg-gender-label"
                    aria-invalid={showErr("gender") || undefined}
                    className="grid grid-cols-2 gap-3"
                  >
                    {genderCards.map((card) => {
                      const selected = fields.gender === card.value;
                      return (
                        <button
                          key={card.value}
                          type="button"
                          role="radio"
                          aria-checked={selected}
                          onClick={() => {
                            set("gender", card.value);
                            setTouched((prev) => ({ ...prev, gender: true }));
                          }}
                          className={cn(
                            "relative flex h-[52px] items-center gap-2.5 overflow-hidden rounded-xl border px-4 text-[13px] font-extrabold transition active:scale-[0.98] focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-brand-500/15",
                            selected
                              ? "border-transparent text-white shadow-lg"
                              : "border-slate-200 bg-white text-slate-600 hover:border-brand-300 dark:border-white/10 dark:bg-ink-900/60 dark:text-slate-300 dark:hover:border-brand-500/40"
                          )}
                          style={selected ? { backgroundImage: grad(card.g1, card.g2) } : undefined}
                        >
                          <span
                            className={cn(
                              "grid h-8 w-8 shrink-0 place-items-center rounded-lg",
                              selected ? "bg-white/20 text-white" : "bg-slate-100 text-slate-400 dark:bg-white/[0.06] dark:text-slate-500"
                            )}
                            aria-hidden="true"
                          >
                            <CatIcon name={card.icon} className="h-4 w-4" />
                          </span>
                          <span className="min-w-0 flex-1 text-start">{t(card.labelKey)}</span>
                          {selected ? (
                            <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-white/25 text-white" aria-hidden="true">
                              <CatIcon name="check" className="h-3 w-3" />
                            </span>
                          ) : null}
                        </button>
                      );
                    })}
                  </div>
                </ShakeField>
                {showErr("gender") ? <FieldError message={t(ERROR_KEYS.gender)} /> : null}
              </div>

              {/* birth date */}
              <div>
                <FieldLabel icon="cake" htmlFor="opg-birth">
                  {t("opgBirthDate")}
                </FieldLabel>
                <ShakeField token={shakeToken("birthDate")}>
                  {/* R163 — the shared premium date field (WZ rhythm): brand
                      calendar tile at the field's far right in Arabic, clear-X
                      + Arabic long-form hint built in. */}
                  <PremiumDateInput
                    id="opg-birth"
                    size="lg"
                    value={fields.birthDate}
                    min={MIN_BIRTH_DAY}
                    max={MAX_BIRTH_DAY}
                    onChange={(e) => set("birthDate", e.target.value)}
                    onBlur={() => {
                      setTouched((prev) => ({ ...prev, birthDate: true }));
                      if (fields.birthDate !== "" && !validity.birthDate) bump("birthDate");
                    }}
                    aria-invalid={showErr("birthDate") || undefined}
                    aria-describedby={showErr("birthDate") ? "opg-birth-err" : undefined}
                  />
                </ShakeField>
                <p className="mt-1 text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                  {t("opgBirthDateHint")}
                </p>
                {showErr("birthDate") ? (
                  <span id="opg-birth-err">
                    <FieldError message={t(ERROR_KEYS.birthDate)} />
                  </span>
                ) : null}
              </div>

              {/* nationality */}
              <div>
                <FieldLabel icon="flag" htmlFor="opg-nationality">
                  {t("opgNationality")}
                </FieldLabel>
                <ShakeField token={shakeToken("nationality")}>
                  <Select
                    value={fields.nationality}
                    onValueChange={(v) => {
                      set("nationality", v);
                      setTouched((prev) => ({ ...prev, nationality: true }));
                    }}
                  >
                    <SelectTrigger id="opg-nationality" className={WZ_INPUT} aria-invalid={showErr("nationality") || undefined}>
                      <SelectValue placeholder={t("opgNationalityPh")} />
                    </SelectTrigger>
                    <SelectContent className="max-h-72">
                      <SelectGroup>
                        {COUNTRIES.map((country) => (
                          <SelectItem key={country.code} value={country.code}>
                            {country.name}
                          </SelectItem>
                        ))}
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                </ShakeField>
                {showErr("nationality") ? <FieldError message={t(ERROR_KEYS.nationality)} /> : null}
              </div>

              {/* job title */}
              <div>
                <FieldLabel icon="briefcase" htmlFor="opg-job">
                  {t("opgJobTitle")}
                </FieldLabel>
                <ShakeField token={shakeToken("jobTitle")}>
                  <Input
                    id="opg-job"
                    value={fields.jobTitle}
                    onChange={(e) => set("jobTitle", e.target.value)}
                    onBlur={() => {
                      setTouched((prev) => ({ ...prev, jobTitle: true }));
                      if (fields.jobTitle.trim() !== "" && !validity.jobTitle) bump("jobTitle");
                    }}
                    placeholder={t("opgJobTitlePh")}
                    autoComplete="organization-title"
                    aria-invalid={showErr("jobTitle") || undefined}
                    className={WZ_INPUT}
                  />
                </ShakeField>
                {showErr("jobTitle") ? <FieldError message={t(ERROR_KEYS.jobTitle)} /> : null}
              </div>

              {/* personal phone — ROUND 84 unification: the shared Premium phone component (gradient tile + dial-code selector, canonical output) */}
              <ShakeField token={shakeToken("phone")}>
                <PremiumPhoneInput
                  id="opg-phone"
                  label="opgPhone"
                  value={fields.phone}
                  onChange={(v) => set("phone", v)}
                  required
                  invalid={showErr("phone")}
                  hint="opgPhoneHint"
                  autoComplete="tel"
                />
              </ShakeField>

              {/* personal address */}
              <div className="sm:col-span-2">
                <FieldLabel icon="map-pin" htmlFor="opg-address">
                  {t("opgAddress")}
                </FieldLabel>
                <ShakeField token={shakeToken("address")}>
                  <Textarea
                    id="opg-address"
                    value={fields.address}
                    onChange={(e) => set("address", e.target.value)}
                    onBlur={() => {
                      setTouched((prev) => ({ ...prev, address: true }));
                      if (fields.address.trim() !== "" && !validity.address) bump("address");
                    }}
                    placeholder={t("opgAddressPh")}
                    autoComplete="street-address"
                    rows={2}
                    aria-invalid={showErr("address") || undefined}
                    className={cn(
                      "field-sizing-normal min-h-[76px] w-full resize-none rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-[13px] font-semibold text-slate-800 transition placeholder:font-normal placeholder:text-slate-400",
                      "focus:border-brand-400 focus:outline-none focus:ring-4 focus:ring-brand-500/15",
                      "dark:border-white/10 dark:bg-ink-900/60 dark:text-slate-100 dark:placeholder:text-slate-500",
                      "aria-invalid:border-rose-400 aria-invalid:ring-2 aria-invalid:ring-rose-500/20"
                    )}
                  />
                </ShakeField>
                {showErr("address") ? <FieldError message={t(ERROR_KEYS.address)} /> : null}
              </div>
            </div>

            {/* server-side rejection banner (zod verdicts land here) */}
            {serverError ? (
              <div
                role="alert"
                className="mt-4 flex items-start gap-2.5 rounded-2xl border border-rose-300/70 bg-rose-50/90 px-3.5 py-2.5 dark:border-rose-500/30 dark:bg-rose-500/10"
              >
                <CatIcon name="triangle-alert" className="mt-0.5 h-4 w-4 shrink-0 text-rose-500" />
                <p className="text-[11.5px] font-bold leading-relaxed text-rose-700 dark:text-rose-300">
                  {t("opgErrorToast")} — {serverError}
                </p>
              </div>
            ) : null}

            {/* submit — disabled until every field is valid (STRICT) */}
            <Button
              type="submit"
              disabled={!allValid || save.isPending}
              className="mt-5 h-12 w-full gap-2 rounded-xl text-[13px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.99] disabled:pointer-events-none disabled:opacity-50"
              style={{
                backgroundImage: grad(c1, c2),
                boxShadow: `0 14px 32px -12px ${hexAlpha(c1, 0.85)}`,
              }}
            >
              {save.isPending ? (
                <>
                  <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                  {t("opgSavingBtn")}
                </>
              ) : (
                <>
                  <CatIcon name="shield-check" className="h-4 w-4" />
                  {t("opgSaveBtn")}
                </>
              )}
            </Button>
          </form>

          {/* ——— footer ——— */}
          <div className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-200/80 bg-slate-50/80 px-5 py-3 dark:border-white/10 dark:bg-white/[0.03] sm:px-7">
            <p className="flex items-center gap-1.5 text-[10.5px] font-bold text-emerald-600 dark:text-emerald-400">
              <CatIcon name="shield-check" className="h-3.5 w-3.5" />
              {t("opgSecureNote")}
            </p>
            <p className="flex items-center gap-1 text-[10.5px] font-bold text-rose-500 dark:text-rose-400">
              <CatIcon name="x" className="h-3 w-3" />
              {t("opgRequired")}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default OwnerProfileGate;
