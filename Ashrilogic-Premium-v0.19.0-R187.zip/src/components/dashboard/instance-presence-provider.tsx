"use client";

/**
 * Ashrilogic — tenant system dashboard presence heartbeat (ROUND 172).
 *
 * Mounted once at the dashboard shell root (DashboardApp — ONLY while a
 * currentInstanceId exists). POST /api/instances/{id}/presence →
 * requireInstanceAccess → checkSessionRecord("instance", …) refreshes the
 * workspace session's lastSeenAt — the call IS the heartbeat, so the Super
 * Admin console's subscriber/system rows flip green the moment an owner is
 * actually inside their system.
 *
 * Same cadence & battery law as the console heartbeat: immediate beat on
 * mount, every 45s afterwards, PAUSED while document.hidden (immediate beat
 * + resumed interval on return-to-visible), silent failures keep the last
 * snapshot, full timer/listener cleanup on unmount.
 *
 * Exposes `useInstancePresence()`:
 *  - me — the workspace owner's own presence (the «مالك النظام» gold card);
 *  - supportOnlineAdmins — distinct online PLATFORM admins (count only,
 *    never identities) for the topbar's premium support indicator;
 *  - serverTime — ISO now for skew-free relative labels;
 *  - ready — false until the first successful beat (surfaces render nothing
 *    instead of flashing a wrong state).
 */
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type { InstancePresenceSnapshot, PresenceDTO } from "@/lib/types";

/** 45s — inside the backend's 2.5-minute online window with wide margin. */
const HEARTBEAT_MS = 45_000;

/** api-client `request` convention, minimal POST form (silent-throw caller). */
async function postInstancePresence(instanceId: string): Promise<InstancePresenceSnapshot> {
  const res = await fetch(`/api/instances/${encodeURIComponent(instanceId)}/presence`, {
    method: "POST",
    credentials: "same-origin",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({}),
  });
  if (!res.ok) throw new Error(`Presence heartbeat failed (${res.status})`);
  return (await res.json()) as InstancePresenceSnapshot;
}

export interface InstancePresenceContextValue {
  /** the workspace owner's own presence; null until the first successful beat */
  me: PresenceDTO | null;
  /** distinct online platform admins (count only — privacy law) */
  supportOnlineAdmins: number;
  /** ISO server "now" for skew-free relative labels */
  serverTime: string | null;
  /** false until the first successful beat (no wrong-state flash) */
  ready: boolean;
  /** trigger an immediate beat (manual refresh hook) */
  refresh: () => void;
}

/* Safe default (house context law, cf. accent-context). */
const InstancePresenceContext = createContext<InstancePresenceContextValue>({
  me: null,
  supportOnlineAdmins: 0,
  serverTime: null,
  ready: false,
  refresh: () => {},
});

export function InstancePresenceProvider({
  instanceId,
  children,
}: {
  instanceId: string;
  children: ReactNode;
}) {
  const [snapshot, setSnapshot] = useState<InstancePresenceSnapshot | null>(null);
  const timerRef = useRef<number | null>(null);
  const inFlightRef = useRef(false);

  const beat = useCallback(async () => {
    if (inFlightRef.current) return;
    if (typeof document !== "undefined" && document.hidden) return;
    inFlightRef.current = true;
    try {
      const next = await postInstancePresence(instanceId);
      setSnapshot(next);
    } catch {
      /* silent — keep the previous snapshot; never block the dashboard */
    } finally {
      inFlightRef.current = false;
    }
  }, [instanceId]);

  const refresh = useCallback(() => {
    void beat();
  }, [beat]);

  useEffect(() => {
    const startInterval = () => {
      if (timerRef.current === null) {
        timerRef.current = window.setInterval(() => void beat(), HEARTBEAT_MS);
      }
    };
    const stopInterval = () => {
      if (timerRef.current !== null) {
        window.clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };

    void beat();
    startInterval();

    const onVisibility = () => {
      if (document.hidden) {
        stopInterval();
      } else {
        void beat();
        startInterval();
      }
    };
    document.addEventListener("visibilitychange", onVisibility);

    return () => {
      stopInterval();
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [beat]);

  const value = useMemo<InstancePresenceContextValue>(
    () => ({
      me: snapshot?.me ?? null,
      supportOnlineAdmins: snapshot?.support.onlineAdmins ?? 0,
      serverTime: snapshot?.serverTime ?? null,
      ready: snapshot !== null,
      refresh,
    }),
    [snapshot, refresh]
  );

  return <InstancePresenceContext.Provider value={value}>{children}</InstancePresenceContext.Provider>;
}

/** Live presence for the current workspace session (safe outside provider). */
export function useInstancePresence(): InstancePresenceContextValue {
  return useContext(InstancePresenceContext);
}

export default InstancePresenceProvider;
