"use client";

/**
 * Ashrilogic — dashboard topbar:
 * hamburger (mobile), system search (module quick-nav), quick add,
 * notifications popover (real unread count via localStorage + a direct
 * link into the specialized Notifications center), premium user menu
 * (profile card, LIVE account meta — wallet balance, real session, fresh
 * package — quick actions + language/theme quick toggles), theme toggle.
 *
 * ROUND 143 — «تبديل النظام» no longer exits the workspace: it routes to
 * the «أنظمتك المنشأة» select screen (owner email preserved) with ZERO
 * logout semantics. The shell accent also flows from the owner-picked
 * dashTheme (useAccentPair) so the whole topbar recolors with the system.
 */
import { useMemo, useRef, useState } from "react";
import { useInfiniteQuery, useQuery, useQueryClient } from "@tanstack/react-query";
import { useTheme } from "next-themes";
import { toast } from "sonner";
import { MODULE_MAP, SYSTEM_MAP, systemMods } from "@/data/catalog";
import { useT } from "@/lib/i18n";
import type { InstanceDTO } from "@/lib/types";
import { useAppStore } from "@/lib/store";
import { ApiError, fetchActivitiesPage, fetchInstance, fetchShifts, fetchWallet } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, hexAlpha, normalizeSearch, initial } from "@/lib/utils";
import { useInstancePresence } from "@/components/dashboard/instance-presence-provider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ExitConfirmDialog, useExitInstance } from "@/components/dashboard/exit-confirm";
import { ProfileDialog } from "@/components/dashboard/profile-dialog";
import { QuickAddDialog } from "@/components/dashboard/quick-add-dialog";
import { useShift } from "@/components/dashboard/shift/shift-status-bar";
import { ShiftCloseDialog } from "@/components/dashboard/shift/shift-dialogs";
import { ACT_STYLE, fullDate, relativeTime } from "@/components/dashboard/dash-shared";
import { useAccentPair } from "@/components/dashboard/accent-context";
import { LiveClock } from "@/components/ui/live-clock";
import { LangMenu } from "@/components/lang-menu";

const NOTIF_READ_PREFIX = "ashrilogic-notif-read-";

export function Topbar({ instance }: { instance: InstanceDTO }) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const setSidebarOpen = useAppStore((s) => s.setSidebarOpen);
  const setDashView = useAppStore((s) => s.setDashView);
  const dashView = useAppStore((s) => s.dashView);
  const setPaletteOpen = useAppStore((s) => s.setPaletteOpen);
  /* ROUND 143 — «تبديل النظام»: routes to the «أنظمتك المنشأة» select
   * screen instead of exiting. The owner's email scopes the list to THEIR
   * systems (the same contract the my-systems screen uses) and the current
   * workspace is highlighted with the ready-to-enter ring. NO session is
   * destroyed — switching is instant, silent and fully reversible. */
  const setView = useAppStore((s) => s.setView);
  const setSelectOwnerEmail = useAppStore((s) => s.setSelectOwnerEmail);
  const setSelectHighlightId = useAppStore((s) => s.setSelectHighlightId);
  const { resolvedTheme, setTheme } = useTheme();
  /* ROUND 143 — the shell-wide effective accent (owner theme > category). */
  const { c1, c2 } = useAccentPair();
  /* ROUND 172 — the support-availability heartbeat: count of online
   * platform admins (never identities). `ready` gates the chip so the
   * first paint never flashes a wrong state. */
  const supportPresence = useInstancePresence();

  /* Unread notifications: activities newer than the stored read timestamp. */
  const readKey = `${NOTIF_READ_PREFIX}${instance.id}`;

  const [query, setQuery] = useState("");
  const [searchFocused, setSearchFocused] = useState(false);
  /* Read the persisted "read" timestamp once at mount (client-only mount —
     the dashboard renders after the instance query, never during SSR). */
  const [lastRead, setLastRead] = useState<number>(() => {
    if (typeof window === "undefined") return 0;
    const stored = Number(localStorage.getItem(readKey) ?? "0");
    return Number.isFinite(stored) && stored > 0 ? stored : 0;
  });
  const [exitOpen, setExitOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  /* user menu open state — drives the precise live refetch of user data */
  const [menuOpen, setMenuOpen] = useState(false);
  /* ROUND 36 — manual refresh: invalidates every dashboard query (instance,
     members, activities, records…) with a spinning premium button. */
  const [refreshing, setRefreshing] = useState(false);
  const manualRefresh = async () => {
    if (refreshing) return;
    setRefreshing(true);
    try {
      await queryClient.invalidateQueries();
      toast.success(t("dashRefreshDone"));
    } catch {
      toast.error(t("errorText"));
    } finally {
      setRefreshing(false);
    }
  };
  const exit = useExitInstance(instance.id);
  const searchWrapRef = useRef<HTMLDivElement>(null);

  /* ------------------------------------------------------------------ */
  /* PRECISE USER DATA: when the menu opens, the workspace record (org /  */
  /* admin / modules / activities / package) is served from the SHARED    */
  /* ["instance", id] cache (the whole shell benefits). ROUND 145 (perf): */
  /* staleTime 15s bounds the staleness — rapid menu re-opens hit the     */
  /* cache while the wallet-adjacent data stays live (the same 15s the     */
  /* wallet query calls live).                                            */
  /* ------------------------------------------------------------------ */
  const liveQuery = useQuery({
    queryKey: ["instance", instance.id],
    queryFn: () => fetchInstance(instance.id),
    enabled: menuOpen,
    staleTime: 15_000,
    retry: 0,
  });
  const live = liveQuery.data?.instance ?? instance;
  const liveChecking = menuOpen && liveQuery.isFetching;

  /* ------------------------------------------------------------------ */
  /* ROUND 141 (owner notifications, directive ㉜) — the ZERO-DELAY feed: */
  /* a 20-second poll over the activity API (the storefront order /      */
  /* review / inquiry events + the wallet money events land in the bell   */
  /* the moment they happen — no menu open needed, no full instance       */
  /* refetch). Unread counts against the localStorage mark.              */
  /* ROUND 145 (perf) — the poll is UNIFIED with the activity view: the   */
  /* SAME ["activities-feed", id, 20] key+limit (both are infinite       */
  /* observers — TanStack cannot mix useQuery/useInfiniteQuery on one    */
  /* key), the same 20s cadence as the notifications center, and a 10s    */
  /* staleTime so opening the activity view dedupes instead of issuing   */
  /* a parallel fetch. The bell reads page one (newest rows).            */
  /* ------------------------------------------------------------------ */
  const notifQuery = useInfiniteQuery({
    queryKey: ["activities-feed", instance.id, 20],
    queryFn: ({ pageParam }) =>
      fetchActivitiesPage(instance.id, { limit: 20, cursor: pageParam }),
    initialPageParam: null as string | null,
    getNextPageParam: (lastPage) => lastPage.nextCursor,
    refetchInterval: 20_000,
    staleTime: 10_000,
    retry: 0,
  });
  const bellActivities = notifQuery.data?.pages[0]?.activities ?? live.activities;

  /* platform-aware palette shortcut label (topbar renders client-only) */
  const isApple = useMemo(
    () => typeof navigator !== "undefined" && /mac|iphone|ipad|ipod/i.test(navigator.userAgent),
    []
  );
  const paletteKbd = isApple ? "⌘ K" : "Ctrl K";

  /* ROUND 143 — the workspace search still needs the SYSTEM definition, but
   * the SHELL COLORS come from useAccentPair (owner theme > category) so a
   * custom accent recolors the entire topbar. */
  const system = SYSTEM_MAP[instance.systemId];

  /* ------------------------------------------------------------------ */
  /* ROUND 143 — REAL LIVE WALLET: the wallet rides the SAME shared cache  */
  /* key the profile/billing/addons surfaces use (zero duplicate fetches) */
  /* and refreshes while the user menu is open, so the balance is always  */
  /* the server's truth — never a guess.                                 */
  /* ------------------------------------------------------------------ */
  const walletQuery = useQuery({
    queryKey: ["wallet", instance.id],
    queryFn: () => fetchWallet(instance.id),
    staleTime: 15_000,
    retry: 0,
  });
  const walletBalanceMinor = walletQuery.data?.balanceMinor ?? null;

  /* user context: last sign-in + workspace facts resolved from the LIVE data */
  const lastLogin = useMemo(() => {
    const logins = live.activities.filter((a) => a.kind === "actLogin");
    return logins.length > 0 ? logins[logins.length - 1].createdAt : null;
  }, [live.activities]);
  const pkgName = live.package
    ? lang === "ar"
      ? live.package.nameAr
      : live.package.nameEn
    : null;

  /* org timezone hour → greeting period label (matches the LiveClock visuals) */
  const greetingKey =
    live.org.timezone === undefined
      ? "clockDay"
      : (() => {
          try {
            const h = Number(
              new Intl.DateTimeFormat("en-US", { hour: "numeric", hour12: false, timeZone: live.org.timezone }).format(new Date())
            );
            if (h >= 5 && h < 12) return "clockMorning";
            if (h >= 12 && h < 17) return "clockDay";
            if (h >= 17 && h < 21) return "clockEvening";
            return "clockNight";
          } catch {
            return "clockDay";
          }
        })();

  const activities = bellActivities;
  const unread = useMemo(
    () => activities.filter((a) => new Date(a.createdAt).getTime() > lastRead).length,
    [activities, lastRead]
  );

  const markAllRead = () => {
    const now = Date.now();
    localStorage.setItem(readKey, String(now));
    setLastRead(now);
    toast.success(t("notifReadAll"));
  };

  /* ROUND 143 — cross-surface read-mark sync: the Notifications CENTER can
   * also mark everything read (its own toolbar button writes the SAME
   * localStorage key). Re-reading the mark whenever the bell popover opens
   * keeps this badge honest without a reload — the two surfaces stay in
   * perfect sync through the shared key. */
  const syncReadMarkFromStorage = () => {
    if (typeof window === "undefined") return;
    const stored = Number(localStorage.getItem(readKey) ?? "0");
    if (Number.isFinite(stored) && stored > 0 && stored !== lastRead) {
      setLastRead(stored);
    }
  };

  /* Search: match the system's effective modules by normalized name. */
  const matches = useMemo(() => {
    const q = normalizeSearch(query.trim());
    if (!q || !system) return [];
    return systemMods(system)
      .map((key) => {
        const m = MODULE_MAP[key];
        if (!m) return null;
        const name = lang === "ar" ? m.nameAr : m.nameEn;
        return normalizeSearch(name).includes(q) ? { key, name, icon: m.icon } : null;
      })
      .filter((x): x is { key: string; name: string; icon: string } => x !== null)
      .slice(0, 6);
  }, [query, system, lang]);

  const searchOpen = searchFocused && query.trim().length > 0;

  const goToModules = () => {
    setDashView("modules");
    setSearchFocused(false);
  };

  const onSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      e.preventDefault();
      goToModules();
    }
    if (e.key === "Escape") {
      setQuery("");
      (e.target as HTMLInputElement).blur();
    }
  };

  /* ROUND 82 (batch-5 ③) — Quick Add is a REAL dialog now: available in
   * EVERY dashboard view of EVERY system (fields per system type — see
   * quick-add-dialog.tsx). The team view keeps its inline focus behavior
   * (workspace members are a different domain). */
  const [quickAddOpen, setQuickAddOpen] = useState(false);

  /* ------------------------------------------------------------------ */
  /* ROUND 133 — نظام الورديات LOGOUT GATE: the workspace refuses sign-out */
  /* while a shift is open (server: 409 SHIFT_OPEN on DELETE auth/login).  */
  /* The client mirrors it BEFORE the exit flow ever starts: a live shift */
  /* blocks the logout item, toasts the reason and offers reconciliation */
  /* via the close-shift dialog instead.                                 */
  /* ROUND 134 — الورديات is now a toggleable module: module OFF → no    */
  /* shift law at all (server gate + logout lock suspended in the same    */
  /* condition) → sign-out flows freely, no probe, no dialogs.           */
  /* ------------------------------------------------------------------ */
  const shiftsEnabled = instance.modules.includes("shifts");
  const shiftQuery = useShift(instance.id, shiftsEnabled);
  const [shiftCloseOpen, setShiftCloseOpen] = useState(false);
  const logoutGateBusy = useRef(false);

  const blockLogoutForShift = () => {
    toast.error(t("shiftLogoutBlocked"));
    setShiftCloseOpen(true);
  };

  /* The cached check that gates the dropdown item itself. */
  const requestLogout = () => {
    if (shiftsEnabled && shiftQuery.data?.current) {
      blockLogoutForShift();
      return;
    }
    setExitOpen(true);
  };

  /* The confirm-time check: a FRESH server read (staleTime 0) right before
   * the irreversible exit — belt-and-braces against the race where a shift
   * opened since the menu opened (the server still answers 409 SHIFT_OPEN,
   * but this keeps the user in context with their data intact). */
  const confirmLogout = () => {
    if (logoutGateBusy.current) return;
    logoutGateBusy.current = true;
    void (async () => {
      try {
        const fresh = await queryClient.fetchQuery({
          queryKey: ["shifts", instance.id],
          queryFn: () => fetchShifts(instance.id),
          staleTime: 0,
        });
        if (fresh.current) {
          setExitOpen(false);
          blockLogoutForShift();
          return;
        }
      } catch (e) {
        /* gate probe failed → let the exit proceed; the server enforces the
           409 SHIFT_OPEN law on the logout call itself */
        if (e instanceof ApiError && (e.status === 409 || e.message.includes("SHIFT_OPEN"))) {
          blockLogoutForShift();
          return;
        }
      } finally {
        logoutGateBusy.current = false;
      }
      exit.mutate();
    })();
  };

  const quickAdd = () => {
    if (dashView === "team") {
      document.getElementById("team-add-name")?.focus();
      return;
    }
    setQuickAddOpen(true);
  };

  /* ROUND 172 — the support indicator's label: the COUNT variant while any
   * platform admin is online, the offline line otherwise (never identities). */
  const supportOnline = supportPresence.supportOnlineAdmins > 0;
  const supportLabel = supportOnline
    ? t("presenceSupportOnlineCount", { count: fmtNum(supportPresence.supportOnlineAdmins, lang) })
    : t("presenceSupportOffline");

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200/70 bg-white/85 backdrop-blur-xl dark:border-white/[0.07] dark:bg-[#05080f]/80">
      <div className="flex h-16 items-center gap-2 px-3 sm:gap-3 sm:px-6 lg:px-8">
        {/* hamburger */}
        <button
          type="button"
          onClick={() => setSidebarOpen(true)}
          aria-label={t("ariaOpenMenu")}
          className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-slate-200 text-slate-600 transition hover:border-brand-300 hover:text-brand-600 lg:hidden dark:border-white/10 dark:text-slate-300"
        >
          <CatIcon name="bars" className="h-[14px] w-[14px]" />
        </button>

        {/* search */}
        <div className="hidden min-w-0 flex-1 sm:block">
          <div ref={searchWrapRef} className="relative max-w-md">
            <CatIcon
              name="search"
              className="pointer-events-none absolute start-3.5 top-1/2 h-[12px] w-[12px] -translate-y-1/2 text-slate-400"
            />
            <Input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onFocus={() => setSearchFocused(true)}
              onBlur={() => setTimeout(() => setSearchFocused(false), 150)}
              onKeyDown={onSearchKeyDown}
              placeholder={t("dashSearchPh")}
              aria-label={t("dashSearchPh")}
              className="h-10 rounded-xl border-slate-200 bg-slate-50/80 ps-10 pe-3 text-[12.5px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:focus:bg-white/[0.07]"
            />
            {searchOpen ? (
              <div
                className="absolute inset-x-0 top-12 z-50 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-lift dark:border-white/10 dark:bg-ink-900"
                role="listbox"
                aria-label={t("dashSearchPh")}
              >
                {matches.length > 0 ? (
                  matches.map((m) => (
                    <button
                      key={m.key}
                      type="button"
                      role="option"
                      aria-selected={false}
                      onMouseDown={(e) => e.preventDefault()} // keep focus until click lands
                      onClick={goToModules}
                      className="flex w-full items-center gap-2.5 px-3.5 py-2.5 text-start transition hover:bg-slate-100 dark:hover:bg-white/5"
                    >
                      <span
                        className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-white"
                        style={{ backgroundImage: grad(c1, c2) }}
                      >
                        <CatIcon name={m.icon} className="h-[11px] w-[11px]" />
                      </span>
                      <span className="truncate text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                        {m.name}
                      </span>
                    </button>
                  ))
                ) : (
                  <p className="px-3.5 py-3 text-[12px] font-semibold text-slate-400 dark:text-slate-500">
                    {t("dashSearchNoResults")}
                  </p>
                )}
              </div>
            ) : null}
          </div>
        </div>

        {/* command palette trigger (⌘K / Ctrl+K) */}
        <button
          type="button"
          onClick={() => setPaletteOpen(true)}
          aria-label={t("cpOpenHint")}
          title={t("cpOpenHint")}
          className="hidden h-10 shrink-0 cursor-pointer items-center gap-2 rounded-xl border border-slate-200 px-2.5 text-slate-500 outline-none transition hover:border-brand-300 hover:text-brand-600 focus-visible:ring-4 focus-visible:ring-brand-500/20 sm:flex dark:border-white/10 dark:text-slate-400 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
        >
          <CatIcon name="command" className="h-[12px] w-[12px]" />
          <kbd className="kbd hidden md:inline-flex">{paletteKbd}</kbd>
        </button>

        {/* actions */}
        <div className="ms-auto flex items-center gap-1.5">
          {/* live clock + localized date (org timezone) */}
          <LiveClock timezone={instance.org.timezone} c1={c1} c2={c2} className="hidden md:flex" />

          {/* command palette trigger (mobile — icon only) */}
          <button
            type="button"
            onClick={() => setPaletteOpen(true)}
            aria-label={t("cpOpenHint")}
            title={t("cpOpenHint")}
            className="grid h-10 w-10 shrink-0 cursor-pointer place-items-center rounded-xl border border-slate-200 text-slate-600 outline-none transition hover:border-brand-300 hover:text-brand-600 focus-visible:ring-4 focus-visible:ring-brand-500/20 sm:hidden dark:border-white/10 dark:text-slate-300"
          >
            <CatIcon name="command" className="h-[14px] w-[14px]" />
          </button>

          <Button
            type="button"
            onClick={quickAdd}
            className="hidden h-10 items-center gap-2 rounded-xl px-3.5 text-[12px] font-bold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95 sm:inline-flex"
            style={{ backgroundImage: grad(c1, c2) }}
          >
            <CatIcon name="plus" className="h-[10px] w-[10px]" />
            <span className="hidden md:inline">{t("dashQuickAdd")}</span>
          </Button>

          {/* ROUND 172 — live support availability chip (online platform
              admins, count only). lg-only so the busy mobile/sm topbar never
              reflows — the same desktop-only law as the live clock. */}
          {supportPresence.ready ? (
            <span
              role="status"
              title={supportLabel}
              className={cn(
                "hidden h-10 shrink-0 items-center gap-2 rounded-xl border px-3 text-[11.5px] font-extrabold lg:inline-flex",
                supportOnline
                  ? "border-emerald-200/80 bg-emerald-50/70 text-emerald-700 dark:border-emerald-500/25 dark:bg-emerald-500/10 dark:text-emerald-300"
                  : "border-rose-200/80 bg-rose-50/70 text-rose-700 dark:border-rose-500/25 dark:bg-rose-500/10 dark:text-rose-300"
              )}
            >
              <span className="relative flex h-2 w-2" aria-hidden="true">
                <span
                  className={cn(
                    "absolute inset-0 rounded-full",
                    supportOnline ? "animate-presence-pulse bg-emerald-500/40" : "bg-rose-500/40"
                  )}
                />
                <span
                  className={cn(
                    "relative m-auto h-1.5 w-1.5 rounded-full",
                    supportOnline ? "bg-emerald-500" : "bg-rose-500"
                  )}
                />
              </span>
              {supportLabel}
            </span>
          ) : null}

          {/* notifications */}
          <Popover onOpenChange={(open) => { if (open) syncReadMarkFromStorage(); }}>
            <PopoverTrigger asChild>
              <button
                type="button"
                aria-label={t("dashNotifications")}
                title={t("dashNotifications")}
                className="relative grid h-10 w-10 place-items-center rounded-xl border border-slate-200 text-slate-600 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:text-slate-300"
              >
                <CatIcon name="bell" className="h-[14px] w-[14px]" />
                {unread > 0 ? (
                  <span className="absolute -top-0.5 -end-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-rose-500 px-1 text-[11px] font-extrabold text-white">
                    {unread}
                  </span>
                ) : null}
              </button>
            </PopoverTrigger>
            <PopoverContent align="end" className="w-80 p-0" dir={lang === "ar" ? "rtl" : "ltr"}>
              <div className="flex items-center justify-between border-b border-slate-200/70 px-4 py-3 dark:border-white/10">
                <p className="text-[12px] font-extrabold text-slate-800 dark:text-slate-100">
                  {t("dashNotifTitle")}
                </p>
                <button
                  type="button"
                  onClick={markAllRead}
                  className="text-[10.5px] font-bold text-brand-600 transition hover:underline dark:text-brand-300"
                >
                  {t("dashNotifMarkAll")}
                </button>
              </div>
              <div className="max-h-80 overflow-y-auto">
                {activities.length === 0 ? (
                  <p className="px-4 py-8 text-center text-[12px] font-semibold text-slate-400 dark:text-slate-500">
                    {t("dashNotifEmpty")}
                  </p>
                ) : (
                  <ul className="divide-y divide-slate-100 dark:divide-white/5">
                    {activities.slice(0, 8).map((a) => {
                      const style = ACT_STYLE[a.kind];
                      return (
                        <li key={a.id} className="flex items-center gap-3 px-4 py-2.5">
                          <span
                            className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white"
                            style={{ backgroundImage: grad(style.c1, style.c2) }}
                          >
                            <CatIcon name={style.icon} className="h-[11px] w-[11px]" />
                          </span>
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-[12px] font-bold text-slate-700 dark:text-slate-200">
                              {t(a.kind)}
                            </p>
                            <p className="text-[10.5px] text-slate-400 dark:text-slate-500">
                              {relativeTime(a.createdAt, lang)}
                            </p>
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </div>
              {/* ROUND 143 — the direct route into the specialized
                  Notifications center (the full live feed with filters,
                  search and history) from the bell. */}
              <div className="border-t border-slate-200/70 p-2 dark:border-white/[0.07]">
                <button
                  type="button"
                  onClick={() => setDashView("notifications")}
                  className="flex w-full items-center justify-center gap-1.5 rounded-xl bg-slate-100/80 px-3 py-2 text-[11.5px] font-extrabold text-slate-600 transition hover:bg-brand-500/10 hover:text-brand-600 active:scale-[0.98] dark:bg-white/[0.05] dark:text-slate-300 dark:hover:bg-brand-500/15 dark:hover:text-brand-300"
                >
                  <CatIcon name="bell" className="h-3.5 w-3.5" />
                  {t("dashNotifViewAll")}
                </button>
              </div>
            </PopoverContent>
          </Popover>

          {/* user menu — premium profile card + quick actions */}
          <DropdownMenu open={menuOpen} onOpenChange={setMenuOpen}>
            <DropdownMenuTrigger asChild>
              <button
                type="button"
                aria-label={t("ariaUserMenu")}
                title={t("userSheetTitle")}
                className="group flex h-10 shrink-0 items-center gap-1 rounded-xl p-1 pe-1.5 outline-none transition-all duration-200 hover:bg-slate-100/80 focus-visible:ring-4 focus-visible:ring-brand-500/20 active:scale-95 dark:hover:bg-white/5"
              >
                {/* gradient ring + avatar tile + online status dot */}
                <span
                  aria-hidden="true"
                  className="rounded-[10px] p-[2px] transition-transform duration-200 group-hover:scale-105"
                  style={{ backgroundImage: grad(c1, c2) }}
                >
                  <span className="relative grid h-8 w-8 place-items-center rounded-lg text-[14px] font-extrabold text-white shadow-[inset_0_0_0_1.5px_rgba(255,255,255,0.35)]"
                    style={{ backgroundImage: grad(c1, c2) }}
                  >
                    {/* ROUND 64 — owner profile photo when set */}
                    {live.admin.avatarUrl ? (
                      <img src={live.admin.avatarUrl} alt="" className="h-8 w-8 rounded-lg object-cover" />
                    ) : (
                      initial(live.admin.name)
                    )}
                    {liveChecking ? (
                      <span className="absolute -bottom-0.5 -end-0.5 grid h-3 w-3 place-items-center rounded-full bg-white ring-2 ring-white dark:ring-[#05080f]">
                        <CatIcon name="refresh-cw" className="h-2 w-2 animate-spin text-brand-600 dark:text-brand-400" />
                      </span>
                    ) : (
                      <span className="absolute -bottom-0.5 -end-0.5 h-3 w-3 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-[#05080f]" />
                    )}
                  </span>
                </span>
                <CatIcon
                  name="chevron-down"
                  className={cn(
                    "h-3 w-3 text-slate-400 transition-transform duration-200 group-hover:translate-y-0.5 dark:text-slate-500",
                    menuOpen && "rotate-180 text-brand-600 dark:text-brand-300"
                  )}
                />
              </button>
            </DropdownMenuTrigger>

            <DropdownMenuContent
              align="end"
              aria-label={t("userSheetOpen")}
              className="w-80 rounded-2xl border-slate-200/80 p-0 shadow-lift dark:border-white/10"
            >
              {/* profile banner — category gradient tint + soft radial accents.
                  ROUND 56 FIX: the old fixed h-14 + overflow-hidden CLIPPED the
                  multi-line identity block (name + email + greeting + workspace
                  line) — hidden/overlapping text. The banner now sizes to its
                  content (min-height keeps the compact look, py keeps the
                  padding) so every line renders fully on all widths. */}
              <div
                className="relative flex min-h-[76px] items-center gap-2.5 overflow-hidden rounded-t-[15px] px-3 py-2.5"
                style={{
                  backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.15)}, ${hexAlpha(c2, 0.15)})`,
                }}
              >
                <span
                  aria-hidden="true"
                  className="absolute -end-6 -top-10 h-20 w-20 rounded-full"
                  style={{ background: `radial-gradient(circle, ${hexAlpha(c1, 0.28)}, transparent 70%)` }}
                />
                <span
                  aria-hidden="true"
                  className="absolute -bottom-12 -start-5 h-24 w-24 rounded-full"
                  style={{ background: `radial-gradient(circle, ${hexAlpha(c2, 0.22)}, transparent 70%)` }}
                />
                <span
                  aria-hidden="true"
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-[10px] text-[14px] font-extrabold text-white shadow-md shadow-slate-900/15 dark:shadow-black/30"
                  style={{ backgroundImage: grad(c1, c2) }}
                >
                  {/* ROUND 64 — owner profile photo when set */}
                  {live.admin.avatarUrl ? (
                    <img src={live.admin.avatarUrl} alt="" className="h-9 w-9 rounded-[10px] object-cover" />
                  ) : (
                    initial(live.admin.name)
                  )}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[14px] font-extrabold leading-tight text-slate-900 dark:text-white">
                    {live.admin.name}
                  </p>
                  <p
                    dir="ltr"
                    className="truncate text-[11px] font-semibold leading-tight text-slate-500 dark:text-slate-400"
                  >
                    {live.admin.email}
                  </p>
                  {/* greeting by org-local time + verified membership chip */}
                  <p className="mt-1 flex min-w-0 flex-wrap items-center gap-1.5 text-[10px] font-bold text-slate-500 dark:text-slate-400">
                    <span className="inline-flex min-w-0 items-center gap-1">
                      <CatIcon name="hand-heart" className="h-[9px] w-[9px] shrink-0 text-brand-500 dark:text-brand-400" />
                      <span className="truncate">{t(greetingKey)}</span>
                    </span>
                    <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-emerald-200 bg-emerald-50/90 px-1.5 py-px text-[11px] font-extrabold text-emerald-700 dark:border-emerald-500/25 dark:bg-emerald-500/10 dark:text-emerald-300">
                      <CatIcon name="badge-check" className="h-[8px] w-[8px]" />
                      {t("userSheetVerified")}
                    </span>
                  </p>
                  {/* live workspace line — org + package resolved from real data */}
                  <p className="mt-0.5 flex min-w-0 items-center gap-1.5 text-[10px] font-bold text-slate-500 dark:text-slate-400">
                    <span className="inline-flex min-w-0 items-center gap-1">
                      <CatIcon name="building" className="h-[9px] w-[9px] shrink-0" />
                      <span className="truncate">{live.org.name}</span>
                    </span>
                    {pkgName ? (
                      <>
                        <span className="text-slate-300 dark:text-slate-600">·</span>
                        <span className="inline-flex shrink-0 items-center gap-1 text-amber-600 dark:text-amber-400">
                          <CatIcon name="crown" className="h-[9px] w-[9px]" />
                          {pkgName}
                        </span>
                      </>
                    ) : null}
                  </p>
                </div>
                {/* role chip */}
                <span
                  className={cn(
                    "inline-flex h-fit shrink-0 items-center gap-1 whitespace-nowrap rounded-full border px-2 py-0.5 text-[11px] font-extrabold",
                    live.admin.role === "owner"
                      ? "border-amber-200 bg-amber-50/90 text-amber-700 dark:border-amber-500/25 dark:bg-amber-500/10 dark:text-amber-300"
                      : "border-brand-200 bg-brand-50/90 text-brand-700 dark:border-brand-500/25 dark:bg-brand-500/10 dark:text-brand-300"
                  )}
                >
                  <CatIcon
                    name={live.admin.role === "owner" ? "crown" : "shield-user"}
                    className="h-[9px] w-[9px]"
                  />
                  {live.admin.role === "owner" ? t("wzAdminRoleOwner") : t("wzAdminRoleManager")}
                </span>
              </div>

              {/* ROUND 143 — LIVE account strip: REAL server facts only —
                  member-since · REAL last sign-in (from the live activity
                  log) · the LIVE wallet balance (shared cache with the
                  profile/billing surfaces) · 2FA state · live-session. No
                  guesses, no statics: every chip re-resolves when the menu
                  opens (the liveQuery refetch) and while it stays open. */}
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5 border-b border-slate-200/70 bg-slate-50/60 px-3 py-2 dark:border-white/[0.07] dark:bg-white/[0.02]">
                <span
                  className="inline-flex items-center gap-1 text-[10.5px] font-bold text-slate-500 dark:text-slate-400"
                  title={fullDate(live.createdAt, lang)}
                >
                  <CatIcon name="calendar" className="h-3 w-3 text-slate-400" />
                  {t("userSheetMemberSince")} {relativeTime(live.createdAt, lang)}
                </span>
                <span
                  className="inline-flex items-center gap-1 text-[10.5px] font-bold text-slate-500 dark:text-slate-400"
                  title={lastLogin ? fullDate(lastLogin, lang) : undefined}
                >
                  <CatIcon name="clock" className="h-3 w-3 text-slate-400" />
                  {lastLogin ? relativeTime(lastLogin, lang) : fullDate(live.createdAt, lang)}
                </span>
                {/* the REAL wallet balance — emerald money chip, live from the
                    shared wallet query (null while it loads, hidden on error) */}
                {walletBalanceMinor !== null ? (
                  <span
                    dir="ltr"
                    className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2 py-0.5 text-[10.5px] font-extrabold tabular-nums text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300"
                    title={t("walletBalanceLabel")}
                  >
                    <CatIcon name="wallet" className="h-2.5 w-2.5" />
                    {fmtNum(Math.round(walletBalanceMinor) / 100, lang)} SAR
                  </span>
                ) : null}
                <span
                  className={cn(
                    "ms-auto inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10.5px] font-extrabold",
                    live.admin.twoFA
                      ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300"
                      : "bg-slate-100 text-slate-500 dark:bg-white/5 dark:text-slate-400"
                  )}
                >
                  <CatIcon
                    name={live.admin.twoFA ? "shield-check" : "circle-alert"}
                    className="h-2.5 w-2.5"
                  />
                  {t("userSheet2FA")} · {t(live.admin.twoFA ? "userSheetOn" : "userSheetOff")}
                </span>
                <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2 py-0.5 text-[10.5px] font-extrabold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
                  {liveChecking ? (
                    <CatIcon name="refresh-cw" className="h-2.5 w-2.5 animate-spin" />
                  ) : (
                    <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-500" aria-hidden="true" />
                  )}
                  {t(liveChecking ? "userSheetLiveNow" : "userSheetSessionActive")}
                </span>
              </div>

              {/* quick actions */}
              <p className="px-3 pb-1 pt-2.5 text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                {t("userSheetQuick")}
              </p>
              <div className="pb-1">
                <DropdownMenuItem
                  onClick={() => setProfileOpen(true)}
                  className="mx-1.5 rounded-lg px-2.5 py-2 text-[12.5px] font-semibold"
                >
                  <CatIcon name="user-round" className="h-[15px] w-[15px]" />
                  {t("dashUserMenuProfile")}
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => setDashView("settings")}
                  className="mx-1.5 rounded-lg px-2.5 py-2 text-[12.5px] font-semibold"
                >
                  <CatIcon name="sliders" className="h-[15px] w-[15px]" />
                  {t("dashUserMenuSettings")}
                </DropdownMenuItem>
                <DropdownMenuItem
                  /* ROUND 143 — «تبديل النظام» → the «أنظمتك المنشأة» select
                   * screen (NOT a logout): the owner's live email scopes the
                   * list, the current workspace gets the highlight ring, and
                   * the workspace session stays fully intact. */
                  onClick={() => {
                    setSelectOwnerEmail(live.admin.email || null);
                    setSelectHighlightId(instance.id);
                    setView("select");
                  }}
                  className="mx-1.5 rounded-lg px-2.5 py-2 text-[12.5px] font-semibold"
                >
                  <CatIcon name="layers" className="h-[15px] w-[15px]" />
                  {t("dashUserMenuSwitch")}
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => setPaletteOpen(true)}
                  className="mx-1.5 rounded-lg px-2.5 py-2 text-[12.5px] font-semibold"
                >
                  <CatIcon name="command" className="h-[15px] w-[15px]" />
                  {t("userSheetShortcuts")}
                  <kbd className="kbd ms-auto inline-flex">{paletteKbd}</kbd>
                </DropdownMenuItem>
              </div>

              {/* language switcher (11 locales) + theme quick toggle */}
              <div className="grid grid-cols-[1fr_auto] items-center gap-2 border-t border-slate-200/70 px-2.5 py-2 dark:border-white/[0.07]">
                <LangMenu className="h-10 w-full justify-center" />
                <button
                  type="button"
                  onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
                  aria-label={t("userSheetTheme")}
                  title={t("userSheetTheme")}
                  className="flex h-10 w-10 items-center justify-center gap-1.5 rounded-lg border border-slate-200 text-[11px] font-bold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
                >
                  <CatIcon name={resolvedTheme === "dark" ? "sun" : "moon"} className="h-3.5 w-3.5" />
                </button>
              </div>

              <DropdownMenuSeparator className="mx-3 my-1.5 bg-slate-200/80 dark:bg-white/[0.07]" />
              <DropdownMenuItem
                onClick={requestLogout}
                className="mx-1.5 mb-1.5 rounded-lg px-2.5 py-2 text-[12.5px] font-semibold text-rose-600 focus:bg-rose-50 focus:text-rose-700 dark:text-rose-400 dark:focus:bg-rose-500/10 dark:focus:text-rose-300"
              >
                <CatIcon name="log-out" className="h-[15px] w-[15px] text-rose-500 dark:text-rose-400" />
                {t("dashUserMenuLogout")}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* ROUND 36 — premium manual refresh (invalidates all dashboard
              queries; the icon spins while refetching) */}
          <button
            type="button"
            onClick={manualRefresh}
            disabled={refreshing}
            aria-label={t("dashRefresh")}
            title={t("dashRefresh")}
            className="group relative grid h-10 w-10 place-items-center overflow-hidden rounded-xl border border-slate-200 text-slate-600 transition-all duration-200 hover:border-brand-300 hover:text-brand-600 active:scale-90 disabled:opacity-60 dark:border-white/10 dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
          >
            <span
              className="absolute inset-0 scale-0 rounded-xl bg-brand-50 opacity-0 transition-all duration-200 group-hover:scale-100 group-hover:opacity-100 dark:bg-brand-500/10"
              aria-hidden="true"
            />
            <CatIcon
              name="refresh-cw"
              className={cn("relative h-[15px] w-[15px]", refreshing && "animate-spin")}
            />
          </button>

          {/* theme toggle */}
          <button
            type="button"
            onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
            aria-label={t("ariaTheme")}
            title={t("ariaTheme")}
            className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 text-slate-600 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:text-slate-300"
          >
            <CatIcon name={resolvedTheme === "dark" ? "sun" : "moon"} className="h-[14px] w-[14px]" />
          </button>

          {/* ROUND 64 — the topbar X exit button was REMOVED per product
              decision: exiting the workspace stays exclusively in the user
              dropdown menu (avatar → log-out) where it is clearly labelled
              and confirm-guarded, keeping the topbar chrome minimal. */}
        </div>
      </div>

      <ExitConfirmDialog
        open={exitOpen}
        onOpenChange={setExitOpen}
        onConfirm={confirmLogout}
        pending={exit.isPending}
      />

      {/* ROUND 133 — the close-shift surface the logout gate chains into:
          reconcile the drawer, then sign out becomes possible. */}
      <ShiftCloseDialog
        open={shiftCloseOpen}
        onOpenChange={setShiftCloseOpen}
        instance={live}
      />

      <ProfileDialog
        open={profileOpen}
        onOpenChange={setProfileOpen}
        instance={instance}
      />

      {/* ROUND 82 — the Quick Add dialog (fields per system type) */}
      <QuickAddDialog
        open={quickAddOpen}
        onOpenChange={setQuickAddOpen}
        instance={live}
      />
    </header>
  );
}
