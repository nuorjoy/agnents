"use client";

/**
 * Ashrilogic — ROUND 143 (owner directive: full-system recolor).
 *
 * When the owner picks a workspace accent in Settings → «الألوان والخطوط» →
 * «النظام (لوحة التحكم)», the dashVars() ramp already retints every
 * brand-* Tailwind utility — but the shell ALSO carries dozens of gradient
 * tiles (avatar rings, icon tiles, primary buttons, focus glows) painted
 * from the SYSTEM CATEGORY colors (CATEGORY_MAP c1/c2). Those stayed
 * category-colored no matter which accent the owner picked, so the system
 * only ever felt "half recolored".
 *
 * This context closes that gap: the dashboard shell provides ONE source of
 * truth — the EFFECTIVE accent pair — resolved from the instance's live
 * dashTheme. Every shell surface (topbar, sidebar, footer, quick actions,
 * views) consumes useAccentPair() instead of reading CATEGORY_MAP directly,
 * so choosing «أزرق» recolors the ENTIRE system: gradients, tiles, rings,
 * buttons — everything — with pixel precision.
 *
 * Fallback law (unchanged identity for untouched workspaces): a workspace
 * on the DEFAULT violet theme keeps its category gradient identity — the
 * historical look is byte-preserved. The moment a custom accent is chosen,
 * the custom pair takes over everywhere.
 */
import { createContext, useContext, useMemo } from "react";
import { CATEGORY_MAP, SYSTEM_MAP } from "@/data/catalog";
import { DASH_THEMES, dashTheme } from "@/lib/surface-styling";
import type { InstanceDTO } from "@/lib/types";

export interface AccentPair {
  /** gradient start — the effective c1 */
  c1: string;
  /** gradient end — the effective c2 */
  c2: string;
  /** true → a CUSTOM owner-picked accent is driving the pair (the system is
   * fully recolored); false → the platform-default category identity */
  custom: boolean;
}

const DEFAULT_PAIR: AccentPair = { c1: "#6d5dfb", c2: "#0ea5e9", custom: false };

const AccentContext = createContext<AccentPair>(DEFAULT_PAIR);

/** Resolve the effective accent pair for a workspace instance. */
export function resolveAccentPair(instance: InstanceDTO): AccentPair {
  const system = SYSTEM_MAP[instance.systemId];
  const cat = system ? CATEGORY_MAP[system.c] : undefined;
  const catPair: AccentPair = {
    c1: cat?.c1 ?? DEFAULT_PAIR.c1,
    c2: cat?.c2 ?? DEFAULT_PAIR.c2,
    custom: false,
  };

  const themeKey = instance.site?.dashTheme;
  /* "" / null / "violet" = the platform default → keep the category
   * identity (byte-preserved historical look). */
  if (!themeKey || themeKey === "violet") return catPair;

  const theme = dashTheme(themeKey);
  if (!theme) return catPair;

  return { c1: theme.c1, c2: theme.c2, custom: true };
}

/** Provider — mounted ONCE at the dashboard shell root (dashboard-app). */
export function AccentProvider({
  instance,
  children,
}: {
  instance: InstanceDTO;
  children: React.ReactNode;
}) {
  const value = useMemo(() => resolveAccentPair(instance), [instance]);
  return <AccentContext.Provider value={value}>{children}</AccentContext.Provider>;
}

/** The effective accent pair for the current workspace (shell-wide law). */
export function useAccentPair(): AccentPair {
  return useContext(AccentContext);
}

/** Convenience: the full DASH_THEMES registry (re-exported for pickers). */
export { DASH_THEMES };
