/**
 * Ashrilogic — ROUND 142 — landing «Mobile app» download section.
 *
 * A premium «coming soon / قريباً» band placed between the final CTA banner
 * and the newsletter signup. The two storefront badges (Google Play +
 * App Store) are styled as the official store badges; both carry a
 * «قريباً / SOON» pill while unpublished.
 *
 * Wiring with the Super-Admin console (admin-mobile-app.tsx):
 *  - Reads the PUBLIC /api/identity feed's mobileApp block (the same
 *    PlatformSetting.identityJson the route serves).
 *  - When `identity.mobileApp.published === true` AND a store URL is set,
 *    that store's badge swaps the «قريباً / SOON» pill for a real download
 *    anchor + an «Live / منشور» chip. Unpublished or empty-URL stores keep
 *    the coming-soon state.
 *
 * Visual identity: brand gradient backdrop (light + dark), the same Reveal
 * motion as every other landing section, CatIcon registry (Google Play =
 * `play`, App Store = `apple` aliased to Smartphone — lucide ships no Apple
 * brand mark). Fully responsive + RTL-aware.
 *
 * ROUND 172d (RSC) — SERVER component with SERVER data: the former
 * usePlatformIdentity() client fetch became a direct server-side read that
 * replicates GET /api/identity's mobileApp resolution EXACTLY (same
 * PlatformSetting row, same readPlatformIdentity mapper; a missing row or
 * a failed read fails SOFT to the coming-soon state — precisely what the
 * client fallback rendered when the feed was unavailable). The store-URL
 * pills are therefore server-rendered text in the first HTML (SEO) and the
 * whole band carries ZERO hydration. The admin's publish toggle converges
 * on the next page load (SSR) instead of the 5-minute client stale window.
 */
import { getCachedPlatformSettings } from "@/lib/server/platform-settings-cache";
import { readPlatformIdentity } from "@/lib/server/admin-mapper";
import type { Lang, PlatformMobileAppIdentity } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { Reveal } from "@/components/landing/reveal";

/** A store badge: either an <a> (published + URL set) or a div (coming soon). */
function StoreBadge({
  store,
  href,
  published,
  label,
  subLabel,
  icon,
  gradient,
  soonLabel,
  liveLabel,
}: {
  store: "google" | "apple";
  href: string;
  published: boolean;
  label: string;
  subLabel: string;
  icon: string;
  gradient: string;
  soonLabel: string;
  liveLabel: string;
}) {
  /* live only when the operator has BOTH flipped the published flag AND
     entered a real URL — never silently downloads a half-configured store */
  const live = published && href.trim().length > 0;
  const Tag = live ? "a" : "div";
  const tagProps = live
    ? { href, target: "_blank", rel: "noopener noreferrer" }
    : {};

  return (
    <Tag
      {...tagProps}
      className={
        "group relative inline-flex items-center gap-3 rounded-2xl border border-slate-200 bg-white px-6 py-3.5 shadow-lg shadow-slate-200/50 transition hover:shadow-xl hover:shadow-slate-300/50 dark:border-white/10 dark:bg-white/[0.04] dark:shadow-black/20 dark:hover:shadow-black/40" +
        (live ? " cursor-pointer hover:-translate-y-0.5 active:scale-95" : "")
      }
      aria-label={live ? label : undefined}
    >
      <span
        className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-md"
        style={{ backgroundImage: gradient }}
        aria-hidden="true"
      >
        <CatIcon name={icon} className="h-5 w-5" />
      </span>
      <div className="text-start">
        <p className="text-[10px] font-bold uppercase tracking-wide text-slate-400">{subLabel}</p>
        <p className="text-[15px] font-extrabold text-slate-900 dark:text-white">{label}</p>
      </div>
      <span
        className={
          "absolute -top-2 -end-2 rounded-full px-2 py-0.5 text-[9px] font-extrabold text-white shadow-md " +
          (live ? "bg-emerald-500" : "bg-brand-500")
        }
      >
        {live ? liveLabel : soonLabel}
      </span>
      {store === "google" ? null : null}
    </Tag>
  );
}

/** The public mobile-app identity block — replicates GET /api/identity's
 *  resolution exactly (same singleton row, same readPlatformIdentity
 *  mapper) so the SSR band and the public feed can never diverge. A missing
 *  row, a corrupt identityJson, or a failed read all fail SOFT to null —
 *  the exact coming-soon state the client fallback rendered. */
async function loadMobileAppIdentity(): Promise<PlatformMobileAppIdentity | null> {
  try {
    const row = await getCachedPlatformSettings();
    if (!row) return null;
    return readPlatformIdentity(row.identityJson)?.mobileApp ?? null;
  } catch (error) {
    console.error("MobileAppSection identity read failed:", error);
    return null;
  }
}

export async function MobileAppSection({ lang }: { lang: Lang }) {
  /* the same identity source the admin console publishes (the route's
   * mobileApp block), resolved BEFORE render — the coming-soon state is
   * the fail-soft default for every unset/unreadable case */
  const mobileApp: PlatformMobileAppIdentity | null = await loadMobileAppIdentity();
  const published = mobileApp?.published === true;
  const googlePlayUrl = (mobileApp?.googlePlayUrl ?? "").trim();
  const appStoreUrl = (mobileApp?.appStoreUrl ?? "").trim();
  const version = (mobileApp?.version ?? "").trim();
  /* premium banner headline copy stays bilingual inline (matches the
     CtaBannerSection pattern — no new i18n keys needed for the public site) */
  const soonLabel = lang === "ar" ? "قريباً" : "SOON";
  const liveLabel = lang === "ar" ? "متاح الآن" : "LIVE";
  const versionLine =
    version.length > 0
      ? lang === "ar"
        ? `الإصدار ${version}`
        : `Version ${version}`
      : lang === "ar"
        ? "قريباً على Google Play و App Store"
        : "Coming soon to Google Play and App Store";

  return (
    <section className="relative overflow-hidden px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
      {/* gradient backdrop — brand-tinted on light, very subtle on dark */}
      <div
        className="absolute inset-0 -z-10 bg-gradient-to-br from-brand-50 via-white to-cyan-50 dark:from-brand-950/20 dark:via-transparent dark:to-cyan-950/20"
        aria-hidden="true"
      />
      {/* soft decorative glow orbs (premium depth) */}
      <div
        className="pointer-events-none absolute -end-24 -top-24 -z-10 h-64 w-64 rounded-full bg-brand-500/10 blur-3xl"
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute -bottom-24 -start-24 -z-10 h-64 w-64 rounded-full bg-cyan-400/10 blur-3xl"
        aria-hidden="true"
      />

      <div className="mx-auto max-w-5xl">
        <Reveal>
          <div className="text-center">
            <span className="inline-flex items-center gap-2 rounded-full border border-brand-200 bg-brand-50 px-4 py-1.5 text-[11px] font-bold text-brand-700 dark:border-brand-500/25 dark:bg-brand-500/10 dark:text-brand-300">
              <span className="relative flex h-1.5 w-1.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand-500 opacity-75" />
                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-brand-500" />
              </span>
              {lang === "ar" ? "قريباً" : "Coming Soon"}
            </span>
            <h2 className="mt-4 font-display text-[28px] font-extrabold tracking-tight text-slate-900 sm:text-4xl dark:text-white">
              {lang === "ar" ? "تطبيق أشرِيلوجيك على هاتفك" : "Ashrilogic on Your Phone"}
            </h2>
            <p className="mx-auto mt-3 max-w-xl text-[14px] leading-relaxed text-slate-600 sm:text-base dark:text-slate-400">
              {lang === "ar"
                ? "أدر أنظمتك من أي مكان — تطبيق الموبايل قادم قريباً لـ Google Play و App Store."
                : "Manage your systems from anywhere — the mobile app is coming soon to Google Play and App Store."}
            </p>
          </div>
        </Reveal>

        <Reveal delay={0.1}>
          <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
            {/* Google Play badge */}
            <StoreBadge
              store="google"
              href={googlePlayUrl}
              published={published}
              icon="play"
              label="Google Play"
              subLabel={lang === "ar" ? "حمّله من" : "GET IT ON"}
              gradient="linear-gradient(135deg, #34a853 0%, #4285f4 50%, #fbbc04 100%)"
              soonLabel={soonLabel}
              liveLabel={liveLabel}
            />
            {/* App Store badge */}
            <StoreBadge
              store="apple"
              href={appStoreUrl}
              published={published}
              icon="apple"
              label="App Store"
              subLabel={lang === "ar" ? "حمّله من" : "Download on the"}
              gradient="linear-gradient(135deg, #1f2937 0%, #0f172a 100%)"
              soonLabel={soonLabel}
              liveLabel={liveLabel}
            />
          </div>
        </Reveal>

        {/* version / availability footnote */}
        <Reveal delay={0.18}>
          <p className="mt-8 text-center text-[11.5px] font-bold text-slate-500 dark:text-slate-400">
            {versionLine}
          </p>
        </Reveal>
      </div>
    </section>
  );
}

export default MobileAppSection;
