"use client";

/**
 * Ashrilogic — pricing interactive core (client island, ROUND 172d).
 *
 * The billing-cycle TOGGLE + the smart price advisor + the plan cards grid
 * + the Enterprise quote dialog — extracted from the former client
 * PricingSection during the RSC conversion. Everything here MUST stay
 * client: the cycle state re-prices every card, each card's CTA is a
 * button (smooth-scroll / quote dialog), the advisor is a stepper form and
 * the dialog owns its own state. The section shell, heading and the
 * 14-day-trial banner are server-rendered (pricing-section.tsx); the LIVE
 * plan feed is resolved SERVER-SIDE and handed in as `packages` (the exact
 * GET /api/packages payload — null on failure, which renders the static
 * fallback tiers exactly like the old client fail-soft).
 *
 * Markup is byte-identical to the former client render at the same state:
 * the island SSRs the monthly cycle with the server-resolved data (the
 * former skeleton branch is kept as the documented dead-for-SSR path —
 * data now resolves before render, cf. partners-strip). Labels resolve
 * through the pure t(lang, ·) with the lang prop (the sectors/
 * systems-library island pattern), so the SSR text follows the cookie
 * language; PriceAdvisor + QuoteDialog keep their own internal useT().
 */
import { useState } from "react";
import type { CSSProperties } from "react";
import { t } from "@/lib/i18n";
import type { Lang, PackageDTO } from "@/lib/types";
import { cycleDiscountPct, discountedPrice, effectiveYearlyPct } from "@/lib/plan-features";
import { fmtPlanPrice } from "@/lib/format";
import { CatIcon } from "@/components/icon";
import { Reveal } from "@/components/landing/reveal";
import { PriceAdvisor } from "@/components/landing/price-advisor";
import { QuoteDialog } from "@/components/landing/quote-dialog";
import { cn, fmtNum, grad, hexAlpha } from "@/lib/utils";

type Cycle = "monthly" | "yearly";

/** Static fallback tiers — used only when the live packages request fails
 *  or yields an empty list. ROUND 167: mirrors the shipped THREE-tier
 *  structure — the Enterprise tier is CUSTOM PRICING (no purchasable
 *  amount: the card prints «تسعير مخصص» and its CTA opens the quote
 *  dialog). `monthly` is the price in integer MINOR units (999 = $9.99)
 *  and the yearly figure is the ANNUAL total with 20% off (two months
 *  free), exactly the live priceYearly convention. */
const PLANS = [
  {
    id: "starter",
    nameKey: "priceStarter",
    descKey: "priceStarterDesc",
    icon: "rocket",
    c1: "#06b6d4",
    c2: "#0891b2",
    monthly: 999,
    ctaKey: "priceCta",
    popular: false,
    features: ["priceFeat1Starter", "priceFeat2", "priceFeat3", "priceFeat4"],
  },
  {
    id: "pro",
    nameKey: "pricePro",
    descKey: "priceProDesc",
    icon: "sparkles",
    c1: "#6d5dfb",
    c2: "#d946ef",
    monthly: 2499,
    ctaKey: "priceCta",
    popular: true,
    features: ["priceFeat1Pro", "priceFeat2", "priceFeat3", "priceFeat4Pro", "priceFeat5Pro", "priceFeat6Pro"],
  },
  {
    id: "enterprise",
    nameKey: "priceEnterprise",
    descKey: "priceEnterpriseDesc",
    icon: "building",
    c1: "#f59e0b",
    c2: "#ea580c",
    /* ROUND 167 — custom pricing: no amount, the quote dialog instead */
    customPricing: true as const,
    monthly: 0,
    ctaKey: "priceCtaQuote",
    popular: false,
    features: ["priceFeat1Ent", "priceFeat2", "priceFeat3", "priceFeat4Ent", "priceFeat5Ent", "priceFeat6Ent"],
  },
] as const;

/** Icon + gradient palette cycled by plan index so rows of 3–4 stay varied. */
const PLAN_STYLES = [
  { icon: "rocket", c1: "#06b6d4", c2: "#0891b2" },
  { icon: "sparkles", c1: "#6d5dfb", c2: "#d946ef" },
  { icon: "building", c1: "#f59e0b", c2: "#ea580c" },
  { icon: "gem", c1: "#10b981", c2: "#059669" },
] as const;

/** One renderable plan card — resolved for language + billing cycle. */
interface PlanCardVM {
  key: string;
  name: string;
  desc: string;
  /** ROUND 79 — the EFFECTIVE (discounted) price for the selected cycle */
  price: number;
  /** ROUND 79 — the crossed-out list price (present only when discounted) */
  basePrice?: number;
  /** ROUND 79 — live discount percentage (0 = none) */
  discountPct?: number;
  /** ROUND 167 — custom-pricing tier: no purchasable amount — the card
   *  prints «تسعير مخصص» and the CTA opens the quote dialog instead of a
   *  checkout scroll (fmtPlanPrice NEVER renders $0.00 on such rows). */
  customPricing: boolean;
  currencyLabel: string;
  features: string[];
  /** total feature count (may exceed the visible slice) */
  featureCount: number;
  /** ROUND 67 — explicit custom-domain gating on the card itself: the
   *  BASIC tier (first plan) cannot attach a professional domain to the
   *  store or the public site; every higher tier includes it. */
  domainIncluded: boolean;
  icon: string;
  c1: string;
  c2: string;
  popular: boolean;
  /** CTA copy + scroll target (primary id, then a graceful fallback id). */
  ctaKey: "priceCta" | "priceCtaContact" | "priceCtaQuote";
  ctaTarget: string;
  ctaFallback?: string;
}

function Check({ c1 }: { c1: string }) {
  return (
    <span
      className="grid h-4.5 w-4.5 shrink-0 place-items-center rounded-full text-white"
      style={{ backgroundColor: c1, width: 18, height: 18 }}
      aria-hidden="true"
    >
      <CatIcon name="check" className="h-[10px] w-[10px]" />
    </span>
  );
}

/** Shared premium card — used for live DB plans and the static fallback alike. */
function PlanCard({ plan, delay, perMonthLabel, popularLabel, lang, onQuote }: {
  plan: PlanCardVM;
  delay: number;
  perMonthLabel: string;
  popularLabel: string;
  /** ROUND 172d — the cookie language (server-threaded prop): labels +
   *  localized figures resolve through the pure t(lang, ·). */
  lang: Lang;
  /** ROUND 167 — opens the Enterprise quote dialog (custom-pricing CTA) */
  onQuote: () => void;
}) {
  return (
    <Reveal delay={delay}>
      <div
        className={cn(
          "group relative flex h-full flex-col overflow-hidden rounded-3xl border p-6 transition-all duration-300 hover:-translate-y-1.5",
          plan.popular
            ? "border-transparent bg-white shadow-xl shadow-brand-500/10 dark:bg-white/[0.05] hover:shadow-2xl hover:shadow-brand-500/20"
            : "border-slate-200/80 bg-white/70 backdrop-blur-sm hover:shadow-lg hover:border-brand-300/60 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-brand-500/30"
        )}
        style={
          plan.popular
            ? { boxShadow: "0 0 0 2px transparent, 0 20px 50px -20px rgba(109,93,251,0.4)" }
            : undefined
        }
      >
        {/* hover glow accent */}
        <div
          className="pointer-events-none absolute inset-0 -z-10 opacity-0 transition-opacity duration-300 group-hover:opacity-100"
          style={{
            background: `radial-gradient(400px circle at 50% 0%, ${hexAlpha(plan.c1, 0.08)}, transparent 70%)`,
          }}
          aria-hidden="true"
        />
        {/* gradient ring for popular plan */}
        {plan.popular ? (
          <span
            className="pointer-events-none absolute inset-0 rounded-3xl p-[2px]"
            style={{ background: grad(plan.c1, plan.c2), WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", maskComposite: "exclude" } as CSSProperties}
            aria-hidden="true"
          />
        ) : null}

        {/* popular badge */}
        {plan.popular ? (
          <span
            className="absolute end-5 top-5 inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-extrabold text-white shadow-md"
            style={{ backgroundImage: grad(plan.c1, plan.c2) }}
          >
            <CatIcon name="star" className="h-[9px] w-[9px] fill-white" />
            {popularLabel}
          </span>
        ) : null}

        {/* plan header */}
        <div className="relative">
          <span
            className="grid h-12 w-12 place-items-center rounded-2xl text-white shadow-lg transition-transform duration-300 group-hover:scale-110"
            style={{ backgroundImage: grad(plan.c1, plan.c2) }}
            aria-hidden="true"
          >
            <CatIcon name={plan.icon} className="h-[17px] w-[17px]" />
          </span>
          <h3 className="mt-4 font-display text-[18px] font-extrabold text-slate-900 dark:text-white">
            {plan.name}
          </h3>
          <p className="mt-1 text-[12px] text-slate-500 dark:text-slate-400">
            {plan.desc}
          </p>
        </div>

        {/* price — ROUND 79: crossed-out list price → live discounted price
            (the same discountedPrice() the server uses for order amounts) +
            an emerald «وفّر {pct}٪» chip next to the figure.
            ROUND 166 — prices are integer MINOR units: fmtPlanPrice renders
            ÷100 with 2 decimals (WESTERN digits in every locale).
            ROUND 167 — custom-pricing tiers carry NO purchasable amount:
            the block prints «تسعير مخصص» (never a $0.00 figure). */}
        <div className="relative mt-5 flex flex-wrap items-end gap-x-1.5 gap-y-1">
          {plan.customPricing ? (
            <>
              <span className="font-display text-[26px] font-extrabold leading-tight text-slate-900 dark:text-white">
                {t(lang, "priceCustom")}
              </span>
              <span className="mb-1.5 inline-flex items-center gap-1 rounded-full bg-amber-500/10 px-2 py-0.5 text-[10.5px] font-extrabold text-amber-600 dark:bg-amber-500/15 dark:text-amber-400">
                <CatIcon name="sparkles" className="h-[10px] w-[10px]" />
                {t(lang, "priceCustomChip")}
              </span>
            </>
          ) : (
            <>
              {plan.basePrice !== undefined && plan.discountPct ? (
                <span
                  dir="ltr"
                  className="mb-1.5 self-center text-[13px] font-bold tabular-nums text-slate-400 line-through decoration-rose-400/80 decoration-2 dark:text-slate-500"
                >
                  <span className="sr-only">{t(lang, "priceInsteadOf")} </span>
                  {fmtPlanPrice(plan.basePrice)}
                </span>
              ) : null}
              <span className="font-display text-4xl font-extrabold text-slate-900 dark:text-white">
                {fmtPlanPrice(plan.price)}
              </span>
              <span className="mb-1 text-[13px] font-bold text-slate-500 dark:text-slate-400">
                {plan.currencyLabel}
              </span>
              <span className="mb-1 text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                {perMonthLabel}
              </span>
              {plan.discountPct ? (
                <span className="mb-1 inline-flex shrink-0 items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10.5px] font-extrabold text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400">
                  <CatIcon name="percent" className="h-[10px] w-[10px]" />
                  {t(lang, "priceSavePct", { n: fmtNum(plan.discountPct, lang), pct: fmtNum(plan.discountPct, lang) })}
                </span>
              ) : null}
            </>
          )}
        </div>

        {/* features */}
        <ul className="relative mt-5 flex-1 space-y-2.5">
          {plan.features.map((feature, i) => (
            <li key={`${plan.key}-${i}`} className="flex items-start gap-2.5 text-[12.5px] font-semibold text-slate-600 dark:text-slate-300">
              <Check c1={plan.c1} />
              <span>{feature}</span>
            </li>
          ))}
          {plan.featureCount > plan.features.length ? (
            <li className="pt-0.5">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-2.5 py-1 text-[11px] font-extrabold text-slate-500 dark:bg-white/10 dark:text-slate-400">
                <CatIcon name="sparkles" className="h-[11px] w-[11px]" style={{ color: plan.c1 }} />
                +{fmtNum(plan.featureCount - plan.features.length, lang)}
                <span>{t(lang, "priceMoreFeatures")}</span>
              </span>
            </li>
          ) : null}
        </ul>

        {/* ROUND 67 — explicit custom-domain gating line: the basic tier is
            honestly marked as NOT carrying the professional domain for the
            store + public website; higher tiers show it as a highlighted
            inclusion (mirrors the compare matrix row). */}
        <div className="relative mt-4 flex items-center gap-2.5 border-t border-dashed border-slate-200 pt-3.5 dark:border-white/10">
          {plan.domainIncluded ? (
            <span className="grid h-[18px] w-[18px] shrink-0 place-items-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400" aria-hidden="true">
              <CatIcon name="check" className="h-[10px] w-[10px]" />
            </span>
          ) : (
            <span className="grid h-[18px] w-[18px] shrink-0 place-items-center rounded-full bg-slate-100 text-slate-400 dark:bg-white/10 dark:text-slate-500" aria-hidden="true">
              <CatIcon name="x" className="h-[10px] w-[10px]" />
            </span>
          )}
          <span
            className={cn(
              "text-[11.5px] font-bold leading-snug",
              plan.domainIncluded
                ? "text-emerald-600 dark:text-emerald-400"
                : "text-slate-500 dark:text-slate-400"
            )}
          >
            {t(lang, plan.domainIncluded ? "priceDomainYes" : "priceDomainNo")}
          </span>
        </div>

        {/* CTA — ROUND 167: custom-pricing tiers open the QUOTE dialog
            (no checkout target); every other card keeps the scroll law. */}
        <button
          type="button"
          onClick={() => {
            if (plan.customPricing) {
              onQuote();
              return;
            }
            const el =
              document.getElementById(plan.ctaTarget) ??
              (plan.ctaFallback ? document.getElementById(plan.ctaFallback) : null);
            el?.scrollIntoView({ behavior: "smooth", block: "start" });
          }}
          className={cn(
            "relative mt-6 inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl text-[13px] font-extrabold transition-all duration-200 hover:-translate-y-0.5 active:scale-95",
            plan.popular
              ? "text-white shadow-lg shadow-brand-500/25 hover:brightness-110 hover:shadow-xl hover:shadow-brand-500/40"
              : "border border-slate-200 bg-white text-slate-700 hover:border-brand-300 hover:text-brand-600 hover:shadow-md dark:border-white/10 dark:bg-white/5 dark:text-slate-200 dark:hover:border-brand-500/40"
          )}
          style={plan.popular ? { backgroundImage: grad(plan.c1, plan.c2) } : undefined}
        >
          {t(lang, plan.ctaKey)}
          <CatIcon name="arrow-left" className="h-3.5 w-3.5 rtl:rotate-180" />
        </button>
      </div>
    </Reveal>
  );
}

/** Loading placeholder — mirrors the card layout with pulse blocks.
 *  ROUND 172d: the live feed now resolves on the SERVER before render, so
 *  `pending` below is a const false — this branch is the documented
 *  dead-for-SSR path (it only ever rendered pre-hydration client-side,
 *  cf. partners-strip). Kept so the grid's aria-busy law stays byte-stable. */
function SkeletonCard({ delay }: { delay: number }) {
  const bar = "rounded-full bg-slate-200 dark:bg-white/10";
  return (
    <Reveal delay={delay}>
      <div
        className="flex h-full flex-col rounded-3xl border border-slate-200/80 bg-white/70 p-6 backdrop-blur-sm dark:border-white/10 dark:bg-white/[0.03]"
        aria-hidden="true"
      >
        <div className="animate-pulse">
          <div className="h-12 w-12 rounded-2xl bg-slate-200 dark:bg-white/10" />
          <div className={cn("mt-4 h-4 w-24", bar)} />
          <div className={cn("mt-2 h-2.5 w-40", bar)} />
          <div className="mt-5 h-9 w-28 rounded-lg bg-slate-200 dark:bg-white/10" />
          <div className="mt-6 space-y-2.5">
            {[88, 76, 84, 64].map((w, i) => (
              <div key={i} className={cn("h-2.5", bar)} style={{ width: `${w}%` }} />
            ))}
          </div>
          <div className="mt-6 h-11 w-full rounded-xl bg-slate-200 dark:bg-white/10" />
        </div>
      </div>
    </Reveal>
  );
}

export interface PricingToggleProps {
  /** cookie language — the server-threaded lang (labels + localized
   *  figures resolve through the pure t(lang, ·)) */
  lang: Lang;
  /** the LIVE plan feed resolved server-side (the exact GET /api/packages
   *  payload — DTO rows, ACTIVE-only, console order). null = the server
   *  read failed → the static fallback tiers (the old client fail-soft). */
  packages: PackageDTO[] | null;
}

export function PricingToggle({ lang, packages }: PricingToggleProps) {
  const [cycle, setCycle] = useState<Cycle>("monthly");
  /* ROUND 167 — the Enterprise quote dialog (custom-pricing CTA): the
   * prefill rides the advisor's systems input when opened from there. */
  const [quoteOpen, setQuoteOpen] = useState(false);
  const [quoteSystems, setQuoteSystems] = useState(1);

  /* ROUND 172d — the react-query fetch moved to the server component; the
   * resolved payload arrives as a prop (same empty-list → fallback law). */
  const dbPlans = packages && packages.length > 0 ? packages : null;
  /* the live feed is resolved before render — `pending` is the documented
   * dead-for-SSR constant (the skeleton branch never fires now). */
  const pending = false;

  const openQuote = (systems: number) => {
    setQuoteSystems(Math.min(500, Math.max(1, systems)));
    setQuoteOpen(true);
  };

  /** ROUND 65 → ROUND 79 → ROUND 80 — live yearly saving: the BEST saving
   *  across all plans, computed from the EFFECTIVE prices with each cycle's
   *  OWN promotion (monthly pct for monthly; the dedicated annual pct for
   *  yearly — 0 inherits the monthly promotion). Heterogeneous discounts
   *  advertise the strongest true saving, never a stale first-row number,
   *  and never a hard-coded percentage. */
  let savePct: number | null = null;
  if (dbPlans) {
    for (const pkg of dbPlans) {
      const monthlyPct = pkg.discountPct ?? 0;
      const yearlyPct = effectiveYearlyPct(pkg);
      const effMonthly = discountedPrice(pkg.priceMonthly, monthlyPct);
      const effYearly = discountedPrice(pkg.priceYearly, yearlyPct);
      if (effMonthly > 0 && effYearly > 0 && effYearly < effMonthly * 12) {
        const planSaving = Math.round((1 - effYearly / (effMonthly * 12)) * 100);
        if (savePct === null || planSaving > savePct) savePct = planSaving;
      }
    }
  }

  /* ---------------- card view models ---------------- */

  const liveCards: PlanCardVM[] = dbPlans
    ? dbPlans.map((pkg, i) => {
        const style = PLAN_STYLES[i % PLAN_STYLES.length];
        /* ROUND 79 → ROUND 80 — the card price is the LIVE effective price
           under the SELECTED CYCLE's own promotion (monthly pct or the
           dedicated annual pct — the same cycleDiscountPct law the server
           stamps on order amounts); the crossed-out list price rides along
           when that cycle's promotion is live. ROUND 167 — a customPricing
           row carries no purchasable amount: the price fields stay 0 and the
           card renders the «تسعير مخصص» block instead. */
        const pct = cycleDiscountPct(pkg, cycle);
        const base = cycle === "monthly" ? pkg.priceMonthly : pkg.priceYearly;
        const effective = discountedPrice(base, pct);
        return {
          key: `pkg-${pkg.id}`,
          name: lang === "ar" ? pkg.nameAr : pkg.nameEn,
          desc: lang === "ar" ? pkg.descAr : pkg.descEn,
          price: effective,
          basePrice: !pkg.customPricing && pct > 0 ? base : undefined,
          discountPct: !pkg.customPricing && pct > 0 ? pct : undefined,
          customPricing: pkg.customPricing,
          currencyLabel: pkg.currency,
          features: (lang === "ar" ? pkg.features : pkg.featuresEn.length > 0 ? pkg.featuresEn : pkg.features).slice(0, 6),
          featureCount: (lang === "ar" ? pkg.features : pkg.featuresEn.length > 0 ? pkg.featuresEn : pkg.features).length,
          /* ROUND 67 — the first (basic) tier is the only one WITHOUT the
             custom professional domain for the store + public website */
          domainIncluded: i > 0,
          icon: style.icon,
          c1: style.c1,
          c2: style.c2,
          popular: pkg.popular,
          ctaKey: pkg.customPricing ? "priceCtaQuote" : "priceCta",
          ctaTarget: "systems",
          ctaFallback: undefined,
        };
      })
    : [];

  const staticCards: PlanCardVM[] = PLANS.map((plan) => ({
    key: `static-${plan.id}`,
    name: t(lang, plan.nameKey),
    desc: t(lang, plan.descKey),
    /* ROUND 166 — monthly is MINOR units; the yearly fallback is the
       ANNUAL total at 20% off (round(monthly × 12 × 0.8)) — the same
       convention as the live priceYearly. ROUND 167 — the Enterprise
       fallback mirrors the custom-pricing law (no amount, quote CTA). */
    price: cycle === "yearly" ? Math.round(plan.monthly * 12 * 0.8) : plan.monthly,
    customPricing: "customPricing" in plan ? plan.customPricing : false,
    currencyLabel: t(lang, "priceCurrency"),
    features: plan.features.map((fk) => t(lang, fk as "priceFeat1Starter")),
    featureCount: plan.features.length,
    domainIncluded: plan.id !== "starter",
    icon: plan.icon,
    c1: plan.c1,
    c2: plan.c2,
    popular: plan.popular ?? false,
    ctaKey: plan.ctaKey,
    ctaTarget: plan.id === "enterprise" ? "download" : "systems",
  }));

  const cards = dbPlans ? liveCards : staticCards;

  return (
    <>
      {/* billing cycle toggle */}
      <Reveal delay={0.08}>
        <div className="mt-8 flex items-center justify-center">
          <div
            className="inline-flex items-center gap-1 rounded-2xl border border-slate-200 bg-white/70 p-1 backdrop-blur-sm dark:border-white/10 dark:bg-white/[0.04]"
            role="group"
            aria-label={t(lang, "priceBadge")}
          >
            {(["monthly", "yearly"] as const).map((c) => {
              const active = cycle === c;
              return (
                <button
                  key={c}
                  type="button"
                  onClick={() => setCycle(c)}
                  aria-pressed={active}
                  className={cn(
                    "relative inline-flex items-center gap-2 rounded-xl px-4 py-2 text-[12.5px] font-extrabold transition-all duration-200",
                    active
                      ? "text-white shadow-lg"
                      : "text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200"
                  )}
                  style={active ? { backgroundImage: grad("#6d5dfb", "#d946ef") } : undefined}
                >
                  {t(lang, c === "monthly" ? "priceMonthly" : "priceYearly")}
                  {c === "yearly" ? (
                    <span
                      className={cn(
                        "rounded-full px-1.5 py-0.5 text-[11px] font-extrabold",
                        active ? "bg-white/25 text-white" : "bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400"
                      )}
                    >
                      {dbPlans
                        ? savePct && savePct > 0
                          ? t(lang, "priceSavePct", { n: savePct, pct: savePct })
                          : null
                        : t(lang, "priceYearlySave")}
                    </span>
                  ) : null}
                </button>
              );
            })}
          </div>
        </div>
      </Reveal>

      {/* ROUND 167 — توصية ذكية للسعر: the smart advisor sits ABOVE the
          cards grid (live tiers only — it reasons over the real quotas);
          collapsible on every breakpoint, premium by design. */}
      {dbPlans ? (
        <Reveal delay={0.05}>
          <div className="mt-8">
            <PriceAdvisor packages={dbPlans} onQuote={openQuote} />
          </div>
        </Reveal>
      ) : null}

      {/* plans */}
      <div
        className={cn(
          "mt-10 grid gap-5 lg:grid-cols-3",
          cards.length === 4 && "xl:grid-cols-4"
        )}
        aria-busy={pending}
      >
        {pending ? (
          [0, 1, 2].map((i) => <SkeletonCard key={i} delay={i * 0.1} />)
        ) : (
          cards.map((plan, i) => (
            <PlanCard
              key={plan.key}
              plan={plan}
              delay={i * 0.1}
              perMonthLabel={t(lang, "pricePerMonth")}
              popularLabel={t(lang, "pricePopular")}
              lang={lang}
              onQuote={() => openQuote(1)}
            />
          ))
        )}
      </div>

      {/* ROUND 167 — the Enterprise quote dialog (custom-pricing CTA) */}
      <QuoteDialog open={quoteOpen} onOpenChange={setQuoteOpen} defaultSystems={quoteSystems} />
    </>
  );
}

export default PricingToggle;
