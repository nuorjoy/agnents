"use client";

/**
 * Ashrilogic — FAQ section.
 *
 * Premium accordion of 8 Q&A pairs backed by the typed i18n dictionary.
 * Uses the shadcn Accordion (single-open, animated) on a glass card with a
 * gradient question icon, smooth expand, and a side support CTA.
 *
 * round-7 — category filter chips: the 8 items are grouped into 4 categories
 * (Setup / Features / Security / Support). A row of pill chips above the
 * accordion filters the visible items; "All" resets. Purely client state
 * (useState) — no URL sync needed (the FAQ is a single viewport section, not
 * a shareable filtered view like the systems library).
 */
import { useState } from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { useT, type I18nKey } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { Reveal } from "@/components/landing/reveal";
import { FaqPageJsonLd } from "@/components/structured-data";
import { cn, grad } from "@/lib/utils";

type FaqCategory = "setup" | "features" | "security" | "support";

const FAQ_ITEMS: { q: I18nKey; a: I18nKey; c1: string; c2: string; icon: string; category: FaqCategory }[] = [
  { q: "faq1Q", a: "faq1A", c1: "#6d5dfb", c2: "#8b5cf6", icon: "wand-sparkles", category: "setup" },
  { q: "faq2Q", a: "faq2A", c1: "#06b6d4", c2: "#0ea5e9", icon: "languages", category: "features" },
  { q: "faq3Q", a: "faq3A", c1: "#f59e0b", c2: "#f97316", icon: "toggle-right", category: "setup" },
  { q: "faq4Q", a: "faq4A", c1: "#10b981", c2: "#059669", icon: "shield-check", category: "security" },
  { q: "faq5Q", a: "faq5A", c1: "#ec4899", c2: "#db2777", icon: "flask", category: "support" },
  { q: "faq6Q", a: "faq6A", c1: "#8b5cf6", c2: "#7c3aed", icon: "life-buoy", category: "support" },
  { q: "faq7Q", a: "faq7A", c1: "#6d5dfb", c2: "#06b6d4", icon: "fingerprint", category: "security" },
  { q: "faq8Q", a: "faq8A", c1: "#10b981", c2: "#14b8a6", icon: "smartphone", category: "features" },
];

/** Filter chip definitions — the "All" pseudo-filter plus the 4 real ones. */
const FAQ_FILTERS: { id: FaqCategory | "all"; labelKey: I18nKey }[] = [
  { id: "all", labelKey: "faqCatAll" },
  { id: "setup", labelKey: "faqCatSetup" },
  { id: "features", labelKey: "faqCatFeatures" },
  { id: "security", labelKey: "faqCatSecurity" },
  { id: "support", labelKey: "faqCatSupport" },
];

export function FaqSection() {
  const { t } = useT();
  const [activeFilter, setActiveFilter] = useState<FaqCategory | "all">("all");
  const visibleItems = activeFilter === "all"
    ? FAQ_ITEMS
    : FAQ_ITEMS.filter((item) => item.category === activeFilter);

  return (
    <section id="faq" className="cv-auto relative scroll-mt-20 overflow-hidden px-4 py-16 sm:px-6 lg:px-8 lg:py-20">
      {/* SEO — FAQPage JSON-LD bound HERE (the only surface that actually
          displays this Q&A content; content mirrors the visible i18n keys). */}
      <FaqPageJsonLd />
      {/* decorative gradient blobs */}
      <div
        className="pointer-events-none absolute -start-20 top-1/4 -z-10 h-72 w-72 rounded-full bg-brand-500/10 blur-3xl"
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute -end-20 bottom-1/4 -z-10 h-72 w-72 rounded-full bg-cyan-400/10 blur-3xl"
        aria-hidden="true"
      />
      <div className="mx-auto max-w-4xl">
        {/* heading */}
        <div className="mx-auto max-w-3xl text-center">
          <Reveal>
            <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3.5 py-1.5 text-[11px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
              <CatIcon name="help-circle" className="h-[11px] w-[11px] text-brand-500" />
              <span>{t("faqBadge")}</span>
            </span>
            <h2 className="mt-5 font-display text-[28px] font-extrabold leading-tight tracking-tight sm:text-4xl">
              <span>{t("faqTitle1")} </span>
              <span className="text-gradient">{t("faqTitle2")}</span>
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-[14px] leading-relaxed text-slate-600 dark:text-slate-400 sm:text-[15px]">
              {t("faqDesc")}
            </p>
          </Reveal>
        </div>

        {/* category filter chips — round-7. Pill row above the accordion;
            filters visibleItems. Active chip carries the brand gradient. */}
        <Reveal delay={0.05}>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-2">
            {FAQ_FILTERS.map((filter) => {
              const isActive = activeFilter === filter.id;
              return (
                <button
                  key={filter.id}
                  type="button"
                  onClick={() => setActiveFilter(filter.id)}
                  aria-pressed={isActive}
                  className={cn(
                    "inline-flex items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-[11.5px] font-bold transition-all duration-200 active:scale-95",
                    isActive
                      ? "border-transparent bg-linear-to-br from-brand-500 to-fuchsia-500 text-white shadow-md shadow-brand-500/20"
                      : "border-slate-200 bg-white text-slate-600 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300 dark:hover:border-brand-500/30 dark:hover:text-brand-300"
                  )}
                >
                  {t(filter.labelKey)}
                </button>
              );
            })}
          </div>
        </Reveal>

        {/* accordion */}
        <Reveal delay={0.1}>
          <div className="glass-card mt-6 rounded-3xl p-3 sm:p-5">
            <Accordion
              type="single"
              collapsible
              defaultValue={`faq-${FAQ_ITEMS.findIndex((it) => it.q === visibleItems[0]?.q)}`}
              className="w-full"
            >
              {visibleItems.map((item) => {
                const i = FAQ_ITEMS.indexOf(item);
                return (
                <AccordionItem
                  key={item.q}
                  value={`faq-${i}`}
                  className={cn(
                    "overflow-hidden rounded-2xl px-3 transition-colors duration-200",
                    "data-[state=open]:bg-white/70 data-[state=open]:shadow-sm dark:data-[state=open]:bg-white/[0.04]",
                    i > 0 ? "mt-1.5 border-t-0" : ""
                  )}
                >
                  <AccordionTrigger className="group gap-3 py-4 text-start hover:no-underline">
                    <span
                      className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md transition-transform duration-200 group-data-[state=open]:scale-110"
                      style={{ backgroundImage: grad(item.c1, item.c2) }}
                      aria-hidden="true"
                    >
                      <CatIcon name={item.icon} className="h-[13px] w-[13px]" />
                    </span>
                    <span className="flex-1 text-[13.5px] font-extrabold text-slate-800 dark:text-slate-100">
                      {t(item.q)}
                    </span>
                  </AccordionTrigger>
                  <AccordionContent className="ps-12 pe-2 text-[13px] leading-relaxed text-slate-600 dark:text-slate-400">
                    {t(item.a)}
                  </AccordionContent>
                </AccordionItem>
                );
              })}
            </Accordion>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export default FaqSection;
