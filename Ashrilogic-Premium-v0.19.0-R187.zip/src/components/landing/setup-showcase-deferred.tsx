"use client";

/**
 * Ashrilogic — deferred setup showcase (client island, ROUND 172d).
 *
 * The cinematic setup showcase is an auto-playing client simulation with
 * its own timers + a ~50KB chunk; loading it right after hydration (the
 * former next/dynamic import in landing-page) put its evaluation on the
 * post-hydration long-task chain. This wrapper keeps the showcase a CLIENT
 * component but arms it on VISIBILITY instead: until the visitor scrolls
 * within ~600px of the band, the wrapper renders the EXACT same pulse
 * placeholder that served as the dynamic loading fallback — so the
 * perceived behavior is unchanged (placeholder → content as you approach
 * the band) while the chunk + its timers leave the page-load path entirely.
 *
 * The inner mount stays next/dynamic with ssr:false (the simulation is a
 * client-only experience by design — its content is decorative, not SEO
 * material), and its `loading` fallback is the same placeholder again, so
 * arming swaps placeholder → placeholder → content with zero visual jump.
 *
 * The gate itself involves no motion (the showcase's own
 * prefers-reduced-motion handling applies once it mounts), so no
 * reduced-motion branch is needed here. Ancient engines without
 * IntersectionObserver fall back to arming immediately — exactly the
 * former always-load behavior.
 */
import dynamic from "next/dynamic";
import { useEffect, useRef, useState } from "react";

/** The showcase chunk — client-only (ssr:false: the simulation renders
 *  exclusively in the browser; the placeholder below covers the load). */
const SetupShowcase = dynamic(
  () => import("@/components/landing/setup-showcase").then((m) => m.SetupShowcase),
  {
    ssr: false,
    loading: () => <ShowcasePlaceholder />,
  }
);

/** The exact footprint of the former dynamic loading fallback — rendered
 *  pre-arm (and while the chunk streams in) so the layout never shifts. */
function ShowcasePlaceholder() {
  return (
    <div className="mx-auto h-[420px] max-w-6xl animate-pulse rounded-3xl border border-slate-200/60 bg-slate-100/50 sm:h-[460px] dark:border-white/[0.06] dark:bg-white/[0.03]" aria-hidden="true" />
  );
}

export function SetupShowcaseDeferred() {
  const ref = useRef<HTMLDivElement | null>(null);
  const [armed, setArmed] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    /* arm ONCE when the band approaches the viewport (600px lead — a
     * human scroll cadence reaches the content before the chunk lands) */
    let io: IntersectionObserver | null = null;
    let fallback = 0;
    try {
      io = new IntersectionObserver(
        (entries) => {
          if (entries.some((entry) => entry.isIntersecting)) {
            setArmed(true);
            io?.disconnect();
          }
        },
        { rootMargin: "600px 0px 600px 0px", threshold: 0 }
      );
      io.observe(el);
    } catch {
      /* no IntersectionObserver → load immediately (the former behavior),
       * queued on a macrotask — never a synchronous setState in the effect
       * body (the house cascading-render rule, cf. reveal.tsx) */
      fallback = window.setTimeout(() => setArmed(true), 0);
    }
    return () => {
      window.clearTimeout(fallback);
      io?.disconnect();
    };
  }, []);

  return <div ref={ref}>{armed ? <SetupShowcase /> : <ShowcasePlaceholder />}</div>;
}

export default SetupShowcaseDeferred;
