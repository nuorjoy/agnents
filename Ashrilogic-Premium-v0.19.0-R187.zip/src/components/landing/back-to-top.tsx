"use client";

import { useEffect, useState } from "react";
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { useReducedMotion } from "@/hooks/use-reduced-motion";
import { cn } from "@/lib/utils";

/** show the button once the page is scrolled this far (px) */
const SHOW_AFTER = 600;

/**
 * Ashrilogic — back-to-top floating button with scroll-progress ring.
 *
 * Circular gradient button pinned to the bottom inline-start corner with an
 * SVG progress ring that fills as the user scrolls down (0% at top → 100% at
 * bottom). Appears after ~600px of scroll and smooth-scrolls to the top.
 * 48px touch target (≥44px requirement).
 *
 * ROUND 170 (performance): the former framer-motion AnimatePresence
 * entrance/exit is now a plain CSS transition (opacity/scale/translate with
 * the same 0.25s + family cubic-bezier feel). The element stays mounted —
 * hidden state removes it from the a11y tree and pointer events — which
 * removes the last framer-motion import from the public landing's critical
 * path without changing a single visible behavior.
 */
export function BackToTop() {
  const { t } = useT();
  const [visible, setVisible] = useState(false);
  const [progress, setProgress] = useState(0);
  const reducedMotion = useReducedMotion();

  useEffect(() => {
    let raf = 0;
    const update = () => {
      const scrollTop = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const pct = docHeight > 0 ? Math.min(1, scrollTop / docHeight) : 0;
      setProgress(pct);
      setVisible(scrollTop > SHOW_AFTER);
    };
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll, { passive: true });
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  // SVG ring geometry
  const size = 52;
  const stroke = 3;
  const r = (size - stroke) / 2;
  const circumference = 2 * Math.PI * r;
  const dashOffset = circumference * (1 - progress);

  return (
    <button
      type="button"
      onClick={() => window.scrollTo({ top: 0, behavior: reducedMotion ? "auto" : "smooth" })}
      aria-label={t("backToTop")}
      title={t("backToTop")}
      aria-hidden={!visible}
      tabIndex={visible ? 0 : -1}
      className={cn(
        "focus-glow fixed bottom-5 start-5 z-40 grid cursor-pointer place-items-center rounded-full active:scale-95 sm:bottom-8 sm:start-8",
        "transition-[opacity,transform] duration-[250ms] ease-[cubic-bezier(0.22,1,0.36,1)] motion-reduce:transition-none motion-reduce:transform-none",
        visible
          ? "pointer-events-auto translate-y-0 scale-100 opacity-100"
          : "pointer-events-none translate-y-3 scale-50 opacity-0"
      )}
      style={{ width: size, height: size }}
    >
      {/* progress ring SVG (background + progress arcs) */}
      <svg
        width={size}
        height={size}
        className="absolute inset-0 -rotate-90"
        aria-hidden="true"
      >
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          strokeWidth={stroke}
          className="stroke-slate-200/70 dark:stroke-white/10"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={dashOffset}
          className="transition-[stroke-dashoffset] duration-150 ease-out"
          style={{ stroke: "url(#btg-progress)" }}
        />
        <defs>
          <linearGradient id="btg-progress" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#6d5dfb" />
            <stop offset="50%" stopColor="#d946ef" />
            <stop offset="100%" stopColor="#22d3ee" />
          </linearGradient>
        </defs>
      </svg>
      {/* inner gradient button */}
      <span
        className="grid h-9 w-9 place-items-center rounded-full bg-linear-to-br from-brand-600 via-brand-500 to-fuchsia-500 text-white shadow-lg shadow-brand-500/35 transition-shadow duration-300 hover:shadow-xl hover:shadow-brand-500/50"
        aria-hidden="true"
      >
        <CatIcon name="arrow-up" className="h-4 w-4" />
      </span>
    </button>
  );
}

export default BackToTop;
