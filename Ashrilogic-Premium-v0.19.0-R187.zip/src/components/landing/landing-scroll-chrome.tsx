"use client";

import dynamic from "next/dynamic";
import { useEffect, useState } from "react";

/**
 * Ashrilogic — ROUND 172c: the client-only scroll chrome (progress bar +
 * back-to-top). `next/dynamic` with `ssr: false` is not allowed inside
 * Server Components, so the two fixed overlays moved into this tiny client
 * island rendered by the server landing shell. Markup and behavior are
 * unchanged (same lazy chunks, same loading behavior).
 *
 * ROUND 172d — the chrome arms on the FIRST scroll or pointer gesture:
 * both overlays are invisible until the visitor actually scrolls (the
 * progress bar fills with scroll; back-to-top appears after a threshold),
 * so mounting them at page load only paid their chunk evaluation inside
 * the TBT window for zero visible value. A visitor who never scrolls
 * never downloads them.
 */
const ScrollProgress = dynamic(
  () => import("@/components/landing/scroll-progress").then((m) => m.ScrollProgress),
  { ssr: false }
);
const BackToTop = dynamic(
  () => import("@/components/landing/back-to-top").then((m) => m.BackToTop),
  { ssr: false }
);

export function LandingScrollChrome() {
  const [armed, setArmed] = useState(false);

  useEffect(() => {
    if (armed) return;
    const arm = () => setArmed(true);
    /* already scrolled (deep link to #systems etc.) → arm on the next
     * frame (deferring one frame avoids a synchronous setState cascading
     * renders inside the effect; the overlays are invisible either way) */
    if (window.scrollY > 0) {
      const raf = requestAnimationFrame(arm);
      return () => cancelAnimationFrame(raf);
    }
    window.addEventListener("scroll", arm, { once: true, passive: true });
    return () => window.removeEventListener("scroll", arm);
  }, [armed]);

  if (!armed) return null;
  return (
    <>
      <ScrollProgress />
      <BackToTop />
    </>
  );
}
