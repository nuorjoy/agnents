"use client";

/**
 * Ashrilogic — ROUND 172 — public support-availability pill (client island).
 *
 * The «فريق الدعم متصل الآن» chip beside the support section's badge:
 * fetched ONCE per mount from GET /api/support/presence (public rate limit
 * 30/10min per IP — never polled), cached forever per session. A failed
 * fetch degrades CLOSED to "offline" (the route's own safe answer) and the
 * chip never breaks the band. A subtle skeleton keeps the centered heading
 * stable until the first answer lands.
 *
 * ROUND 172d (RSC) — moved VERBATIM out of the former client
 * SupportSection during the RSC conversion: the surrounding section,
 * heading, contact channel cards and perks are now server-rendered, while
 * this live indicator stays a hydrated island with its exact former
 * behavior + markup (useQuery options, PresenceDot wiring, useT labels).
 */
import { useQuery } from "@tanstack/react-query";
import type { SupportPresenceSnapshot } from "@/lib/types";
import { useT } from "@/lib/i18n";
import { PresenceDot } from "@/components/shared/presence-dot";
import { cn, fmtNum } from "@/lib/utils";

/**
 * Follows api-client's `request` conventions (relative URL, same-origin
 * credentials, non-2xx → thrown Error); `request` itself is module-private
 * and api-client may not be modified, so the minimal GET lives here.
 */
async function fetchSupportPresence(): Promise<SupportPresenceSnapshot> {
  const res = await fetch("/api/support/presence", { credentials: "same-origin" });
  if (!res.ok) throw new Error(`Support presence failed (${res.status})`);
  return (await res.json()) as SupportPresenceSnapshot;
}

export function SupportPresencePill() {
  const { t, lang } = useT();

  const supportPresence = useQuery({
    queryKey: ["support-presence"],
    queryFn: fetchSupportPresence,
    staleTime: Infinity,
    gcTime: Infinity,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    refetchOnMount: false,
    retry: false,
  });
  const supportOnline = (supportPresence.data?.onlineAdmins ?? 0) > 0;
  const supportCount = supportPresence.data?.onlineAdmins ?? 0;
  const supportLabel = supportOnline
    ? t("presenceSupportOnlineCount", { count: fmtNum(supportCount, lang) })
    : t("presenceSupportOffline");

  return supportPresence.isPending ? (
    <span
      className="inline-flex h-[29px] w-32 animate-pulse rounded-full bg-slate-200/80 dark:bg-white/10"
      aria-hidden="true"
    />
  ) : (
    <span
      role="status"
      title={supportLabel}
      className={cn(
        "inline-flex items-center gap-2 rounded-full border px-3.5 py-1.5 text-[11px] font-bold",
        supportOnline
          ? "border-emerald-200 bg-emerald-50/80 text-emerald-700 dark:border-emerald-500/25 dark:bg-emerald-500/10 dark:text-emerald-300"
          : "border-rose-200 bg-rose-50/80 text-rose-600 dark:border-rose-500/25 dark:bg-rose-500/10 dark:text-rose-300"
      )}
    >
      <PresenceDot
        presence={{ online: supportOnline, lastSeenAt: null }}
        label={supportLabel}
      />
      {supportLabel}
    </span>
  );
}

export default SupportPresencePill;
