"use client";

/**
 * Ashrilogic — /compare: the comprehensive plan-comparison page.
 *
 * The full live comparison matrix (moved here from the landing page —
 * ComparePlansSection renders unchanged inside) enriched with:
 *   - a stats hero (live plan count, criteria count, live-data promise);
 *   - the shared security & compliance band (what EVERY plan includes);
 *   - a decision-helper FAQ accordion + the closing CTA.
 *
 * ROUND 129 (owner directive): the per-plan deep-dive cards section and the
 * live-data note under the matrix were REMOVED; the hero copy now describes
 * the page on its own merits.
 */
import { type ReactNode } from "react";
import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import { useT, type I18nKey } from "@/lib/i18n";
import { fetchPublicPackages } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { Reveal } from "@/components/landing/reveal";
import { LandingHeader } from "@/components/landing/landing-header";
import { ScrollProgress } from "@/components/landing/scroll-progress";
import { BackToTop } from "@/components/landing/back-to-top";
import { ComparePlansSection } from "@/components/landing/compare-plans-section";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { cn, fmtNum, grad } from "@/lib/utils";

import "@/lib/i18n/fragments/app";
import { PrintStamp } from "@/components/landing/print-stamp";
/** Matrix rows on the page (5 live limit rows + 11 curated feature rows). */
const MATRIX_ROWS = 16;

/** Security band items — shared across every plan (i18n pairs). */
const SECURITY_ITEMS: { t: I18nKey; d: I18nKey; icon: string; c1: string; c2: string }[] = [
  { t: "cmpSec1T", d: "cmpSec1D", icon: "lock", c1: "#6d5dfb", c2: "#8b5cf6" },
  { t: "cmpSec2T", d: "cmpSec2D", icon: "scroll-text", c1: "#06b6d4", c2: "#0ea5e9" },
  { t: "cmpSec3T", d: "cmpSec3D", icon: "shield-check", c1: "#10b981", c2: "#059669" },
  { t: "cmpSec4T", d: "cmpSec4D", icon: "database-backup", c1: "#f59e0b", c2: "#f97316" },
];

/** Decision-helper FAQ (page-level, distinct from the landing FAQ). */
const DECISION_FAQ: { q: I18nKey; a: I18nKey; c1: string; c2: string; icon: string }[] = [
  { q: "cmpFaq1Q", a: "cmpFaq1A", c1: "#6d5dfb", c2: "#8b5cf6", icon: "compass" },
  { q: "cmpFaq2Q", a: "cmpFaq2A", c1: "#10b981", c2: "#059669", icon: "banknote" },
  { q: "cmpFaq3Q", a: "cmpFaq3A", c1: "#f59e0b", c2: "#f97316", icon: "rocket" },
  { q: "cmpFaq4Q", a: "cmpFaq4A", c1: "#06b6d4", c2: "#0ea5e9", icon: "sparkles" },
];

/* ROUND 172c (RSC) — the footer became a SERVER component, so it can no
 * longer be imported into this client view; the server route page now
 * renders it and passes the element down here (rendered in the exact same
 * slot). */
export function ComparePageView({ footer }: { footer: ReactNode }) {
  const { t, lang } = useT();

  /* the SAME public cache the pricing section and the matrix consume — one
   * admin edit invalidates every consumer in the same session */
  const packagesQuery = useQuery({
    queryKey: ["public-packages"],
    queryFn: fetchPublicPackages,
    staleTime: 60_000,
  });
  const live = packagesQuery.data ?? [];

  return (
    <div className="relative flex min-h-screen flex-col">
      {/* decorative backgrounds — paper is ink-only */}
      <div className="mesh pointer-events-none fixed inset-0 -z-10 print:hidden" aria-hidden="true" />
      <div className="print:hidden">
        <LandingHeader />
        <ScrollProgress />
        <BackToTop />
      </div>

      {/* ROUND 181 — PRINT: the page prints as a clean DECISION SHEET —
       * hero + stats + the comparison matrix + the security band as ink;
       * .compare-print ink rules live in globals.css (incl. flattening
       * the table's min-width so it fits A4 portrait). R182: the FAQ now
       * prints too — as a dedicated static Q/A list (see the print-only
       * section below) instead of the Radix accordion (closed items
       * unmount, and CDP pipelines can skip beforeprint). The closing CTA
       * band still drops out on paper. */}
      <main className="compare-print flex-1">
        {/* ---------------- hero ---------------- */}
        <section className="relative overflow-hidden px-4 pt-14 pb-6 sm:px-6 sm:pt-20 lg:px-8 lg:pb-8 print:pt-6">
          <div className="grid-lines pointer-events-none absolute inset-x-0 top-0 -z-10 h-[420px] print:hidden" aria-hidden="true" />
          <div className="mx-auto max-w-4xl text-center">
            <Reveal>
              <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3.5 py-1.5 text-[11px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
                <CatIcon name="scale" className="h-[11px] w-[11px] text-brand-500" />
                <span>{t("cmpBadge")}</span>
              </span>
              <h1 className="mt-5 font-display text-[30px] font-extrabold leading-tight tracking-tight sm:text-5xl">
                <span>{t("cmpTitle1")} </span>
                <span className="text-gradient">{t("cmpTitle2")}</span>
              </h1>
              <p className="mx-auto mt-4 max-w-2xl text-[14px] leading-relaxed text-slate-600 dark:text-slate-400 sm:text-[15px]">
                {t("cmpDesc")}
              </p>
            </Reveal>

            {/* stats band */}
            <Reveal delay={0.08}>
              <div className="mx-auto mt-8 grid max-w-2xl grid-cols-3 gap-3">
                {(
                  [
                    { icon: "package", c1: "#6d5dfb", c2: "#8b5cf6", value: live.length > 0 ? fmtNum(live.length, lang) : "3", label: t("cmpStatPlans") },
                    { icon: "list-checks", c1: "#06b6d4", c2: "#0ea5e9", value: fmtNum(MATRIX_ROWS, lang), label: t("cmpStatRows") },
                    { icon: "activity", c1: "#10b981", c2: "#059669", value: "100%", label: t("cmpStatLive") },
                  ] as const
                ).map((item, i) => (
                  <div
                    key={item.label}
                    className="glass-card rounded-2xl p-3.5 text-center"
                  >
                    <span
                      className="mx-auto grid h-9 w-9 place-items-center rounded-xl text-white shadow-md print:hidden"
                      style={{ backgroundImage: grad(item.c1, item.c2) }}
                      aria-hidden="true"
                    >
                      <CatIcon name={item.icon} className="h-[13px] w-[13px]" />
                    </span>
                    <p className="mt-2 font-display text-xl font-extrabold tabular-nums text-slate-900 dark:text-white">
                      {item.value}
                    </p>
                    <p className="mt-0.5 text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
                      {item.label}
                    </p>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </section>

        {/* ---------------- the live feature matrix (moved from the landing page) ---------------- */}
        <ComparePlansSection />

        {/* ---------------- shared security band ---------------- */}
        <section className="relative overflow-hidden px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
          <div className="pointer-events-none absolute inset-0 -z-10 opacity-50" aria-hidden="true">
            <div className="absolute start-0 top-1/4 h-64 w-64 rounded-full bg-emerald-400/10 blur-3xl" />
            <div className="absolute end-0 bottom-1/4 h-72 w-72 rounded-full bg-brand-500/8 blur-3xl" />
          </div>
          <div className="mx-auto max-w-6xl">
            <div className="mx-auto max-w-2xl text-center">
              <Reveal>
                <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3.5 py-1.5 text-[11px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
                  <CatIcon name="shield-check" className="h-[11px] w-[11px] text-emerald-500" />
                  <span>{t("cmpSecurityTitle")}</span>
                </span>
                <h2 className="mt-5 font-display text-[26px] font-extrabold leading-tight tracking-tight sm:text-4xl">
                  <span className="text-gradient">{t("cmpSecurityTitle")}</span>
                </h2>
                <p className="mx-auto mt-4 max-w-2xl text-[14px] leading-relaxed text-slate-600 dark:text-slate-400 sm:text-[15px]">
                  {t("cmpSecurityDesc")}
                </p>
              </Reveal>
            </div>

            <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {SECURITY_ITEMS.map((item, i) => (
                <Reveal key={item.t} delay={i * 0.06} className="h-full">
                  <div className="glass-card h-full rounded-3xl p-5 transition-all duration-300 hover:-translate-y-1 hover:shadow-lift">
                    <span
                      className="grid h-10 w-10 place-items-center rounded-2xl text-white shadow-lg print:hidden"
                      style={{ backgroundImage: grad(item.c1, item.c2) }}
                      aria-hidden="true"
                    >
                      <CatIcon name={item.icon} className="h-[14px] w-[14px]" />
                    </span>
                    <h3 className="mt-4 font-display text-[14px] font-extrabold leading-snug text-slate-900 dark:text-white">
                      {t(item.t)}
                    </h3>
                    <p className="mt-2 text-[12px] leading-relaxed text-slate-500 dark:text-slate-400">
                      {t(item.d)}
                    </p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        {/* ---------------- decision-helper FAQ — interactive accordion;
            closed items are UNMOUNTED by Radix, so a printed FAQ would show
            only the open one — dropped from the paper sheet ---------------- */}
        <section className="px-4 py-12 sm:px-6 lg:px-8 lg:py-16 print:hidden">
          <div className="mx-auto max-w-4xl">
            <div className="mx-auto max-w-2xl text-center">
              <Reveal>
                <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3.5 py-1.5 text-[11px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
                  <CatIcon name="help-circle" className="h-[11px] w-[11px] text-brand-500" />
                  <span>{t("cmpFaqTitle")}</span>
                </span>
              </Reveal>
            </div>

            <Reveal delay={0.1}>
              <div className="glass-card mt-8 rounded-3xl p-3 sm:p-5">
                <Accordion type="single" collapsible defaultValue="cmp-faq-0" className="w-full">
                  {DECISION_FAQ.map((item, i) => (
                    <AccordionItem
                      key={item.q}
                      value={`cmp-faq-${i}`}
                      className={cn(
                        "overflow-hidden rounded-2xl px-3 transition-colors duration-200",
                        "data-[state=open]:bg-white/70 data-[state=open]:shadow-sm dark:data-[state=open]:bg-white/[0.04]",
                        i > 0 ? "mt-1.5 border-t-0" : ""
                      )}
                    >
                      <AccordionTrigger className="group gap-3 py-4 text-start hover:no-underline">
                        <span
                          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md transition-transform duration-200 group-data-[state=open]:scale-110"
                          style={{ backgroundImage: grad(item.c1, item.c2) }}
                          aria-hidden="true"
                        >
                          <CatIcon name={item.icon} className="h-[13px] w-[13px]" />
                        </span>
                        <span className="flex-1 text-start text-[13.5px] font-extrabold text-slate-800 dark:text-slate-100">
                          {t(item.q)}
                        </span>
                      </AccordionTrigger>
                      <AccordionContent className="ps-12 pe-2 text-[13px] leading-relaxed text-slate-600 dark:text-slate-300">
                        {t(item.a)}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            </Reveal>
          </div>
        </section>

        {/* R182 — PRINT FAQ: the interactive accordion above keeps its
            print:hidden (Radix unmounts closed items, and CDP print
            pipelines can skip beforeprint — the R180 counter lesson — so
            expanding-on-print is fragile). The paper sheet carries this
            dedicated STATIC Q/A list built from the same DECISION_FAQ
            data: zero JS coupling, no interactive behavior change, and
            EVERY question prints open. Ink rules come from the
            .compare-print scope; hairline separators are print-visible on
            white; each pair avoids breaking across pages. */}
        <section className="hidden py-4 print:block">
          <h2 className="text-lg font-extrabold">{t("cmpFaqTitle")}</h2>
          <dl className="mt-2">
            {DECISION_FAQ.map((item) => (
              <div
                key={item.q}
                className="break-inside-avoid border-t border-slate-300 pt-2 mt-2"
              >
                <dt className="text-[12.5px] font-extrabold">{t(item.q)}</dt>
                <dd className="mt-1 text-[11.5px] leading-relaxed">{t(item.a)}</dd>
              </div>
            ))}
          </dl>
        </section>

        {/* ---------------- closing CTA — marketing band, worthless printed ---------------- */}
        <section className="px-4 pb-16 pt-6 sm:px-6 lg:px-8 print:hidden">
          <div className="mx-auto max-w-5xl">
            <Reveal>
              <div className="relative overflow-hidden rounded-3xl bg-linear-to-l from-brand-600 via-brand-500 to-fuchsia-600 p-8 text-center shadow-2xl shadow-brand-500/30 sm:p-12">
                <span className="pointer-events-none absolute -start-16 -top-16 h-48 w-48 rounded-full bg-white/10 blur-2xl" aria-hidden="true" />
                <span className="pointer-events-none absolute -bottom-16 -end-16 h-48 w-48 rounded-full bg-white/10 blur-2xl" aria-hidden="true" />
                <h2 className="relative font-display text-2xl font-extrabold text-white sm:text-3xl">
                  {t("cmpCtaTitle")}
                </h2>
                <p className="relative mx-auto mt-3 max-w-xl text-[13.5px] leading-relaxed text-white/85">
                  {t("cmpCtaDesc")}
                </p>
                <div className="relative mt-7 flex flex-col items-center justify-center gap-3 sm:flex-row">
                  <Link
                    href="/#systems"
                    className="inline-flex items-center gap-2 rounded-xl bg-white px-6 py-3 text-[13.5px] font-extrabold text-brand-700 shadow-lg transition hover:shadow-xl hover:brightness-105 active:scale-95"
                  >
                    <CatIcon name="rocket" className="h-[13px] w-[13px]" />
                    {t("cmpCtaPrimary")}
                  </Link>
                  <Link
                    href="/#pricing"
                    className="inline-flex items-center gap-2 rounded-xl border border-white/40 bg-white/10 px-6 py-3 text-[13.5px] font-extrabold text-white backdrop-blur transition hover:bg-white/20 active:scale-95"
                  >
                    <CatIcon name="banknote" className="h-[13px] w-[13px]" />
                    {t("cmpCtaSecondary")}
                  </Link>
                </div>
              </div>
            </Reveal>
          </div>
        </section>
        {/* R182 print provenance + the R183 data-captured line, inside the
            .compare-print scope. Pricing is live data, so the printed sheet
            stamps WHEN the displayed prices were fetched (React Query's
            dataUpdatedAt — the exact moment of the client fetch that
            rendered this matrix; the static curated fallback has no
            timestamp, so it prints without the line — honest). */}
        <PrintStamp dataDateMs={packagesQuery.dataUpdatedAt || undefined} />
      </main>

      <div className="print:hidden">{footer}</div>
    </div>
  );
}

export default ComparePageView;
