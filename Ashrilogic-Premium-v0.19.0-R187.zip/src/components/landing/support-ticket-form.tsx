"use client";

/**
 * Ashrilogic — public support ticket form (client island, ROUND 172d).
 *
 * The right column of the public support section: the premium glass card
 * with the public ticket form. The form is validated per-field on blur +
 * submit, feeds the admin support inbox via POST /api/support
 * (server-side zod + per-IP rate limit), and swaps to a confirmation state
 * with the ticket reference on success.
 *
 * ROUND 172d (RSC) — moved VERBATIM out of the former client
 * SupportSection during the RSC conversion: the section shell, heading,
 * contact channel cards and perks are now server-rendered, while the form
 * (local state + mutation + the Radix category Select that feeds it) stays
 * a hydrated island with its exact former behavior + markup. Labels keep
 * useT() (store lang) as in wave 5-b.
 */
import { useState, type FormEvent } from "react";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { ApiError, submitPublicTicket } from "@/lib/api-client";
import type { TicketCategory } from "@/lib/types";
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { cn, grad } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { EMAIL_RE } from "@/lib/validation";

/* ------------------------------------------------------------------ */
/* vocabulary                                                          */
/* ------------------------------------------------------------------ */

const CATEGORY_OPTIONS: {
  value: TicketCategory;
  labelKey: "supCatTechnical" | "supCatBilling" | "supCatGeneral" | "supCatFeature";
}[] = [
  { value: "technical", labelKey: "supCatTechnical" },
  { value: "billing", labelKey: "supCatBilling" },
  { value: "general", labelKey: "supCatGeneral" },
  { value: "feature", labelKey: "supCatFeature" },
];

/** Input style — the canonical wizard look (WZ_INPUT). */
const SUP_INPUT = cn(
  "h-11 w-full rounded-xl border-slate-200 bg-slate-50/80 px-3.5 text-[13px] font-semibold text-slate-800",
  "placeholder:font-normal placeholder:text-slate-400 transition",
  "focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15",
  "dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:placeholder:text-slate-500 dark:focus:bg-white/[0.07]",
  "aria-invalid:border-rose-300 aria-invalid:ring-2 aria-invalid:ring-rose-500/20 dark:aria-invalid:border-rose-500/40"
);

const SUP_LABEL = "mb-1.5 block text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300";

/* ------------------------------------------------------------------ */
/* form state                                                          */
/* ------------------------------------------------------------------ */

interface FormState {
  name: string;
  email: string;
  category: TicketCategory;
  subject: string;
  message: string;
}

type ErrorField = "name" | "email" | "subject" | "message";
type Touched = Record<ErrorField, boolean>;

const INITIAL_FORM: FormState = {
  name: "",
  email: "",
  category: "technical",
  subject: "",
  message: "",
};

const ALL_TOUCHED: Touched = { name: true, email: true, subject: true, message: true };
const NONE_TOUCHED: Touched = { name: false, email: false, subject: false, message: false };

/* ------------------------------------------------------------------ */
/* small building blocks                                               */
/* ------------------------------------------------------------------ */

function FieldError({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <p role="alert" className="mt-1 flex items-center gap-1 text-[11px] font-bold text-rose-500 dark:text-rose-400">
      <CatIcon name="triangle-alert" className="h-[11px] w-[11px] shrink-0" />
      <span>{message}</span>
    </p>
  );
}

/* ------------------------------------------------------------------ */
/* the form card                                                       */
/* ------------------------------------------------------------------ */

export function SupportTicketForm() {
  const { t } = useT();

  const [form, setForm] = useState<FormState>(INITIAL_FORM);
  const [touched, setTouched] = useState<Touched>(NONE_TOUCHED);
  const [sentId, setSentId] = useState<string | null>(null);

  const submit = useMutation({
    mutationFn: submitPublicTicket,
    onSuccess: (ticket) => {
      setSentId(ticket.id);
      toast.success(t("pubSupSentTitle"));
    },
    onError: (error: Error) => {
      if (error instanceof ApiError && error.status === 429) {
        toast.error(t("pubSupErrRate"));
      } else {
        toast.error(error.message || t("errorText"));
      }
    },
  });

  /* ---------- per-field validation (mirror of the server schema) ---------- */

  const errorFor = (field: ErrorField): string | null => {
    const value = form[field].trim();
    switch (field) {
      case "name":
        return value.length < 2 ? t("pubSupErrName") : null;
      case "email":
        return EMAIL_RE.test(value) ? null : t("pubSupErrEmail");
      case "subject":
        return value.length < 3 ? t("pubSupErrSubject") : null;
      case "message":
        return value.length < 10 ? t("pubSupErrMessage") : null;
    }
  };

  const shown = (field: ErrorField): string | null =>
    touched[field] ? errorFor(field) : null;

  const touch = (field: ErrorField) => setTouched((prev) => ({ ...prev, [field]: true }));

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (submit.isPending) return;

    setTouched(ALL_TOUCHED);
    const hasError = (["name", "email", "subject", "message"] as const).some(
      (field) => errorFor(field) !== null
    );
    if (hasError) return;

    submit.mutate({
      name: form.name.trim(),
      email: form.email.trim(),
      category: form.category,
      subject: form.subject.trim(),
      message: form.message.trim(),
    });
  };

  const resetForm = () => {
    setForm(INITIAL_FORM);
    setTouched(NONE_TOUCHED);
    setSentId(null);
    submit.reset();
  };

  return (
    <div className="glass-card rounded-3xl p-5 sm:p-6">
      {sentId ? (
        /* ---------- success state ---------- */
        <div className="step-in flex flex-col items-center py-8 text-center sm:py-10">
          <span
            className="grid h-16 w-16 place-items-center rounded-full text-white shadow-lg shadow-brand-500/30"
            style={{ backgroundImage: grad("#6d5dfb", "#06b6d4") }}
            aria-hidden="true"
          >
            <CatIcon name="badge-check" className="h-8 w-8" />
          </span>
          <h3 className="mt-5 font-display text-xl font-extrabold text-slate-900 dark:text-white">
            {t("pubSupSentTitle")}
          </h3>
          <p className="mt-2 max-w-sm text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
            {t("pubSupSentDesc")}
          </p>
          <span className="mt-5 inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-[11px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400">
            {t("pubSupSentRef")}
            <span
              dir="ltr"
              className="font-mono text-[11px] font-extrabold tracking-[0.12em] text-brand-600 dark:text-brand-300"
            >
              {sentId.slice(-8).toUpperCase()}
            </span>
          </span>
          <button
            type="button"
            onClick={resetForm}
            className="mt-6 inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-5 text-[12.5px] font-extrabold text-slate-700 transition hover:border-brand-300 hover:text-brand-600 hover:shadow-md active:scale-95 dark:border-white/10 dark:bg-white/5 dark:text-slate-200 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
          >
            <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
            {t("pubSupSentAnother")}
          </button>
        </div>
      ) : (
        /* ---------- form state ---------- */
        <>
          <div className="flex items-start gap-3.5 border-b border-slate-200/70 pb-4 dark:border-white/10">
            <span
              className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg shadow-brand-500/25"
              style={{ backgroundImage: grad("#6d5dfb", "#06b6d4") }}
              aria-hidden="true"
            >
              <CatIcon name="headset" className="h-5 w-5" />
            </span>
            <div>
              <h3 className="font-display text-[17px] font-extrabold text-slate-900 dark:text-white">
                {t("pubSupFormTitle")}
              </h3>
              <p className="mt-0.5 text-[12px] text-slate-500 dark:text-slate-400">
                {t("pubSupFormDesc")}
              </p>
            </div>
          </div>

          <form onSubmit={handleSubmit} noValidate className="mt-5 space-y-4">
            {/* name + email */}
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <Label htmlFor="sup-name" className={SUP_LABEL}>
                  {t("pubSupName")}
                </Label>
                <Input
                  id="sup-name"
                  value={form.name}
                  onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                  onBlur={() => touch("name")}
                  placeholder={t("pubSupNamePh")}
                  autoComplete="name"
                  aria-invalid={Boolean(shown("name")) || undefined}
                  className={SUP_INPUT}
                />
                <FieldError message={shown("name")} />
              </div>
              <div>
                <Label htmlFor="sup-email" className={SUP_LABEL}>
                  {t("pubSupEmail")}
                </Label>
                <Input
                  id="sup-email"
                  type="email"
                  dir="ltr"
                  value={form.email}
                  onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                  onBlur={() => touch("email")}
                  placeholder={t("pubSupEmailPh")}
                  autoComplete="email"
                  aria-invalid={Boolean(shown("email")) || undefined}
                  className={SUP_INPUT}
                />
                <FieldError message={shown("email")} />
              </div>
            </div>

            {/* category */}
            <div>
              <Label htmlFor="sup-category" className={SUP_LABEL}>
                {t("pubSupCategory")}
              </Label>
              <Select
                value={form.category}
                onValueChange={(v) => setForm((f) => ({ ...f, category: v as TicketCategory }))}
              >
                <SelectTrigger
                  id="sup-category"
                  className={cn(
                    SUP_INPUT,
                    "h-11 w-full justify-between data-[size=default]:h-11"
                  )}
                >
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="rounded-xl">
                  <SelectGroup>
                    {CATEGORY_OPTIONS.map((option) => (
                      <SelectItem
                        key={option.value}
                        value={option.value}
                        className="text-[12.5px] font-bold"
                      >
                        {t(option.labelKey)}
                      </SelectItem>
                    ))}
                  </SelectGroup>
                </SelectContent>
              </Select>
            </div>

            {/* subject */}
            <div>
              <Label htmlFor="sup-subject" className={SUP_LABEL}>
                {t("pubSupSubject")}
              </Label>
              <Input
                id="sup-subject"
                value={form.subject}
                onChange={(e) => setForm((f) => ({ ...f, subject: e.target.value }))}
                onBlur={() => touch("subject")}
                placeholder={t("pubSupSubjectPh")}
                aria-invalid={Boolean(shown("subject")) || undefined}
                className={SUP_INPUT}
              />
              <FieldError message={shown("subject")} />
            </div>

            {/* message */}
            <div>
              <Label htmlFor="sup-message" className={SUP_LABEL}>
                {t("pubSupMessage")}
              </Label>
              <Textarea
                id="sup-message"
                rows={5}
                value={form.message}
                onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
                onBlur={() => touch("message")}
                placeholder={t("pubSupMessagePh")}
                aria-invalid={Boolean(shown("message")) || undefined}
                className={cn(
                  SUP_INPUT,
                  "h-auto min-h-[118px] resize-y py-2.5 leading-relaxed"
                )}
              />
              <FieldError message={shown("message")} />
            </div>

            <button
              type="submit"
              disabled={submit.isPending}
              className="mt-1 inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 text-[13px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95 disabled:cursor-not-allowed disabled:opacity-70"
            >
              {submit.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="telegram" className="h-4 w-4" />
              )}
              {submit.isPending ? t("pubSupSending") : t("pubSupSubmit")}
            </button>
          </form>
        </>
      )}
    </div>
  );
}

export default SupportTicketForm;
