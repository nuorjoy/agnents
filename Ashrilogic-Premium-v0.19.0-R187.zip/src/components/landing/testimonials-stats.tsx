"use client";

/**
 * Ashrilogic — testimonials stats strip (client island, ROUND 172d).
 *
 * The animated counter band under the six owner testimonial cards: four
 * `useCountUp` figures (systems / sectors / modules / support) that tick up
 * when the strip scrolls into view. Extracted VERBATIM from the former
 * client TestimonialsSection during the RSC conversion — the section shell,
 * heading and the six cards are now server-rendered (byte-identical), while
 * this genuinely animated strip stays the only hydrated part of the section.
 * Labels keep useT() (store lang) exactly as before (wave 5-b island law).
 */
import { useT } from "@/lib/i18n";
import { useCountUp } from "@/hooks/use-count-up";
import { Reveal } from "@/components/landing/reveal";

function StatCounter({ target, suffix, label }: { target: number; suffix?: string; label: string }) {
  const { ref, value } = useCountUp(target);
  return (
    <div className="text-center">
      <p className="font-display text-3xl font-extrabold sm:text-4xl">
        <span className="bg-clip-text text-transparent bg-linear-to-br from-brand-500 via-fuchsia-500 to-cyan-400">
          <span ref={ref}>
            {value.toLocaleString("en-US")}
            {suffix}
          </span>
        </span>
      </p>
      <p className="mt-1 text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
        {label}
      </p>
    </div>
  );
}

export function TestimonialsStats() {
  const { t } = useT();

  return (
    <Reveal delay={0.15}>
      <div className="glass-card mt-10 grid grid-cols-2 gap-4 rounded-3xl p-6 sm:p-8 md:grid-cols-4">
        {/* counts must match the catalog (SYSTEMS / CATEGORIES / MODULES) */}
        <StatCounter target={102} label={t("statSystems")} />
        <StatCounter target={16} label={t("statSectors")} />
        <StatCounter target={142} label={t("statModules")} />
        <StatCounter target={24} suffix="/7" label={t("statSupport")} />
      </div>
    </Reveal>
  );
}

export default TestimonialsStats;
