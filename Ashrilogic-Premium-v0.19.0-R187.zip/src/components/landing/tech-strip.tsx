import type { CSSProperties } from "react";
import { t } from "@/lib/i18n";
import type { Lang } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { grad, hexAlpha, labelTrack } from "@/lib/utils";

/**
 * Ashrilogic — premium technology strip.
 *
 * A compact band right under the hero presenting the platform's core stack
 * (6 items, curated — see package.json): each technology renders as a
 * compact glass chip (gradient icon tile + name) with a subtle hover lift
 * and a per-chip accent glow.
 *
 * Layout: desktop wraps the chips in a centered flex grid; mobile runs a
 * slow seamless marquee (duplicated track, edge-masked, paused on hover,
 * disabled under prefers-reduced-motion). The marquee viewport is pinned
 * LTR so the shared `marquee` keyframes (translateX 0 → -50%) stay
 * seamless in the Arabic RTL page — chips carry their own dir.
 *
 * A soft shimmer band (the global `shimmer` keyframes) periodically sweeps
 * the strip, and a "secured" sub-row surfaces the real cryptography the
 * platform runs (Argon2id / AES-256-GCM / HMAC / TLS 1.3 — see
 * src/lib/server/crypto-vault.ts). Palette mirrors the landing accents
 * (slate / emerald / teal / cyan + hero-family amber/rose) — no blue.
 *
 * ROUND 172c (RSC) — SERVER component: the strip is text-only (no state, no
 * events), so it renders on the server from the `lang` prop via the pure
 * t(lang, key) — zero hydration cost for this subtree. The `CatIcon` tiles
 * stay client references (shared icon component); live language switching
 * re-renders it through the prop after router.refresh.
 */
interface TechItem {
  icon: string;
  name: string;
  /** icon-tile gradient pair */
  c1: string;
  c2: string;
}

const STACK: TechItem[] = [
  { icon: "code", name: "Next.js 16", c1: "#10b981", c2: "#059669" },
  { icon: "aperture", name: "React 19", c1: "#06b6d4", c2: "#0891b2" },
  { icon: "braces", name: "TypeScript 5", c1: "#475569", c2: "#334155" },
  { icon: "sparkles", name: "Tailwind CSS 4", c1: "#14b8a6", c2: "#0d9488" },
  { icon: "database", name: "Prisma ORM", c1: "#f59e0b", c2: "#d97706" },
  { icon: "hard-drive", name: "PostgreSQL", c1: "#64748b", c2: "#475569" },
];

/** Real cryptography seals protecting the platform (crypto-vault.ts). */
const SECURITY_SEALS: string[] = ["Argon2id", "AES-256-GCM", "HMAC", "TLS 1.3"];

export function TechStrip({ lang }: { lang: Lang }) {
  return (
    <section
      aria-label={t(lang, "stackTitle")}
      className="relative overflow-hidden border-y border-slate-200/70 bg-white/60 py-8 backdrop-blur-sm sm:py-9 dark:border-white/[0.07] dark:bg-white/[0.02]"
    >
      {/* shimmer sweep — one soft light band glides across the strip (global
          `shimmer` keyframes); hidden under prefers-reduced-motion */}
      <div
        className="pointer-events-none absolute inset-0 z-10 animate-[shimmer_7s_linear_infinite] bg-linear-to-r from-transparent via-white/30 to-transparent bg-[length:200%_100%] motion-reduce:hidden dark:via-white/[0.05]"
        aria-hidden="true"
      />

      <div className="relative mx-auto flex max-w-7xl flex-col items-center gap-5 px-4 sm:px-6 lg:px-8">
        {/* header — badge + one-line description */}
        <div className="flex flex-col items-center gap-2 text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1 text-[10.5px] font-bold uppercase text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-400">
            <CatIcon name="cpu" className="h-[11px] w-[11px] text-teal-500" />
            <span className={labelTrack(lang)}>{t(lang, "stackTitle")}</span>
          </span>
          <p className="mx-auto max-w-xl text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
            {t(lang, "stackSub")}
          </p>
        </div>

        {/* desktop — centered wrap-flex grid of glass chips */}
        <div className="hidden flex-wrap items-center justify-center gap-2.5 md:flex">
          {STACK.map((item) => (
            <TechChip key={item.name} item={item} />
          ))}
        </div>

        {/* mobile — slow seamless marquee (edge-masked, pauses on hover,
            stops under prefers-reduced-motion); viewport pinned LTR so the
            shared keyframes stay seamless on the RTL page */}
        <div
          dir="ltr"
          className="relative w-full overflow-hidden md:hidden [mask-image:linear-gradient(to_right,transparent,#000_4%,#000_96%,transparent)] [-webkit-mask-image:linear-gradient(to_right,transparent,#000_4%,#000_96%,transparent)]"
        >
          <div className="flex w-max animate-[marquee_40s_linear_infinite] items-center hover:[animation-play-state:paused] motion-reduce:animate-none">
            <div className="flex items-center gap-2.5 pe-2.5">
              {STACK.map((item) => (
                <TechChip key={item.name} item={item} />
              ))}
            </div>
            {/* duplicated set — decorative, hidden from assistive tech; the
                trailing gap on each group makes -50% land exactly on the seam */}
            <div className="flex items-center gap-2.5 pe-2.5" aria-hidden="true">
              {STACK.map((item) => (
                <TechChip key={item.name} item={item} />
              ))}
            </div>
          </div>
        </div>

        {/* security seals — the real cryptography under the platform */}
        <div className="flex flex-wrap items-center justify-center gap-x-2 gap-y-1.5">
          <span className="flex items-center gap-1.5 text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
            <CatIcon name="lock" className="h-[11px] w-[11px] text-emerald-500" aria-hidden="true" />
            {t(lang, "stackSecurity")}
          </span>
          {SECURITY_SEALS.map((seal) => (
            <span
              key={seal}
              className="whitespace-nowrap rounded-md border border-emerald-600/15 bg-emerald-500/[0.07] px-1.5 py-0.5 font-mono text-[9.5px] font-semibold text-emerald-700 dark:border-emerald-400/15 dark:bg-emerald-400/[0.07] dark:text-emerald-400"
            >
              {seal}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}

/**
 * One technology chip — gradient icon tile + name. Pinned LTR (tech names
 * are Latin script) so the chip reads identically inside the RTL page grid
 * and the LTR marquee.
 */
function TechChip({ item }: { item: TechItem }) {
  return (
    <div
      dir="ltr"
      className="group relative flex shrink-0 items-center gap-2.5 overflow-hidden rounded-2xl border border-slate-200/70 bg-white/70 px-3.5 py-2 backdrop-blur-sm transition-all duration-200 hover:-translate-y-1 hover:border-slate-300 hover:shadow-[0_12px_28px_-10px_var(--chip-glow)] dark:border-white/[0.08] dark:bg-white/[0.03] dark:hover:border-white/[0.16]"
      style={{ "--chip-glow": hexAlpha(item.c1, 0.3) } as CSSProperties}
    >
      {/* hover accent line — a thin gradient bar pinned to the top edge
          that sweeps in on hover (scale-x 0→1, origin-center). Uses the
          tech's own gradient (c1→c2) for color cohesion with the icon
          tile. Purely decorative (aria-hidden). Mirrors the cross-surface
          hover-accent pattern (systems / features / testimonials cards). */}
      <span
        className="absolute inset-x-0 top-0 h-[3px] origin-center scale-x-0 transition-transform duration-300 ease-out group-hover:scale-x-100"
        style={{ backgroundImage: grad(item.c1, item.c2) }}
        aria-hidden="true"
      />
      <span
        className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white shadow-sm transition-transform duration-200 group-hover:scale-110"
        style={{ backgroundImage: grad(item.c1, item.c2) }}
        aria-hidden="true"
      >
        <CatIcon name={item.icon} className="h-[13px] w-[13px]" />
      </span>
      <span className="whitespace-nowrap font-display text-[12.5px] font-extrabold text-slate-700 dark:text-slate-200">
        {item.name}
      </span>
    </div>
  );
}

export default TechStrip;
