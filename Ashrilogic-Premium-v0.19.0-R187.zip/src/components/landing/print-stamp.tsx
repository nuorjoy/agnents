"use client";

/**
 * Ashrilogic — print-only provenance stamp (R182).
 *
 * Printed sheets (blog article/index, systems spec sheet, compare decision
 * sheet, landing catalog) now close with a one-line ink stamp: the brand,
 * the date the sheet was printed and the page's own URL — a paper reader
 * can tell how fresh the pricing/blog text is and where to find the source.
 *
 * The date + URL are written AFTER mount: the server cannot know the
 * visitor clock (an SSR date would both mismatch hydration and print
 * stale), and the print pipelines that motivated this component (CDP
 * print-to-PDF) skip beforeprint — the R180 counter lesson. Because the
 * value is committed on mount and the element itself is `hidden
 * print:block`, BOTH the real-user path and any programmatic snapshotter
 * capture it with zero print-time JS.
 *
 * Screen rendering: nothing (display:none). Hydration: server renders
 * null, first client render renders null (same empty useState) — no
 * mismatch; the effect then fills the stamp.
 *
 * R183 — OPTIONAL data-captured line (the compare decision sheet): pricing
 * is LIVE data, so a printed sheet can go stale while the article/catalog
 * sheets cannot. Pass `dataDateMs` (React Query's dataUpdatedAt — the
 * exact moment the displayed rows were fetched) and the stamp grows a
 * second line "displayed pricing as of …". Deliberately NOT the server
 * timestamp: the matrix the visitor sees is the CLIENT query's data, so
 * the honest capture time is the client fetch, not the SSR request. */
import { useEffect, useState } from "react";
import { useT } from "@/lib/i18n";

export function PrintStamp({ dataDateMs }: { dataDateMs?: number }) {
  const { t, lang } = useT();
  const [stamp, setStamp] = useState("");
  const [dataStamp, setDataStamp] = useState("");

  useEffect(() => {
    /* rAF-deferred (the house lint rule: no synchronous setState inside an
     * effect body — same deferral the landing-scroll-chrome fix uses). The
     * stamp is print-only, so a one-frame delay is invisible by design. */
    let raf = 0;
    raf = requestAnimationFrame(() => {
      const intl = lang === "hi" ? "hi-IN" : lang === "en" ? "en-US" : "ar";
      try {
        const fmt = new Intl.DateTimeFormat(intl, {
          dateStyle: "long",
          timeStyle: "short",
        });
        setStamp(`${fmt.format(new Date())} · ${window.location.href}`);
        /* the data-captured line — only when the caller passed a REAL
         * fetch timestamp (0 = query never resolved → no line, which is
         * the honest state for the static curated fallback matrix) */
        setDataStamp(
          dataDateMs && dataDateMs > 0 ? fmt.format(new Date(dataDateMs)) : "",
        );
      } catch {
        /* Intl/format failure — an undated sheet is still correct; keep the
         * stamp hidden rather than printing a broken string. */
      }
    });
    return () => cancelAnimationFrame(raf);
  }, [lang, dataDateMs]);

  if (!stamp) return null;

  return (
    <p className="mt-6 hidden border-t border-slate-300 pt-2 text-[10px] leading-relaxed print:block">
      {t("printStamp", { date: stamp })}
      {dataStamp && (
        <span className="block">{t("printStampData", { date: dataStamp })}</span>
      )}
    </p>
  );
}

export default PrintStamp;
