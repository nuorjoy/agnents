/**
 * Ashrilogic — pricing section (live, DB-backed).
 *
 * Plans come from GET /api/packages (admin-managed, ACTIVE only). Each card
 * keeps the premium design language of the original static section: glass
 * card, category gradient icon, hover glow, popular gradient ring + badge,
 * check bullets and a gradient CTA. Bilingual display follows the app
 * language (Arabic name/features by default, English when available). If the
 * API fails or returns no plans, the section falls back to the original
 * static tiers so pricing never breaks.
 *
 * ROUND 172d (RSC) — SERVER component with SERVER data: the former
 * useQuery(fetchPublicPackages) became a direct server-side read that
 * replicates GET /api/packages EXACTLY — the very same domain call the
 * route delegates to (service.listPublic(): the idempotent default-plan
 * seeding + the ACTIVE-only repository listing) and the same toPackageDTO
 * mapping, fail-soft to null (= the client's query-error path) so the
 * static fallback tiers render instead and pricing never breaks.
 *
 * The shell, heading and the 14-day-trial banner render with ZERO
 * hydration through the pure t(lang, ·). The billing-cycle TOGGLE, the
 * smart advisor, the cards grid and the Enterprise quote dialog stay the
 * pricing-toggle.tsx client island (cycle state re-prices every card and
 * every card CTA is a handler — the minimal honest hydration boundary),
 * receiving the server-resolved plan feed as a prop; its SSR markup now
 * carries the REAL plan cards instead of the former query-pending
 * skeletons (the documented dead-for-SSR branch, cf. partners-strip).
 */
import Link from "next/link";
import { t } from "@/lib/i18n";
import type { Lang, PackageDTO } from "@/lib/types";
import { toPackageDTO } from "@/lib/server/admin-mapper";
import { listPublic } from "@/server/domains/packages/service";
import { CatIcon } from "@/components/icon";
import { Reveal } from "@/components/landing/reveal";
import { PricingToggle } from "@/components/landing/pricing-toggle";
import { grad } from "@/lib/utils";

/** The live public pricing feed, resolved SERVER-SIDE — the exact GET
 *  /api/packages logic (the route is a thin delegation to the same
 *  service.listPublic() + toPackageDTO mapping used here, including the
 *  idempotent default-tier seeding on an empty table). A failed read
 *  fails SOFT to null — precisely what the client rendered when the API
 *  errored — so the static fallback tiers take over. */
async function loadPublicPackages(): Promise<PackageDTO[] | null> {
  try {
    const rows = await listPublic();
    return rows.map(toPackageDTO);
  } catch (error) {
    console.error("PricingSection server read failed:", error);
    return null;
  }
}

export async function PricingSection({ lang }: { lang: Lang }) {
  const packages = await loadPublicPackages();

  return (
    <section id="pricing" className="cv-auto scroll-mt-20 px-4 py-16 sm:px-6 lg:px-8 lg:py-20">
      <div className="mx-auto max-w-7xl">
        {/* heading */}
        <div className="mx-auto max-w-3xl text-center">
          <Reveal>
            <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3.5 py-1.5 text-[11px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
              <CatIcon name="tag" className="h-[11px] w-[11px] text-brand-500" />
              <span>{t(lang, "priceBadge")}</span>
            </span>
            <h2 className="mt-5 font-display text-[28px] font-extrabold leading-tight tracking-tight sm:text-4xl">
              <span>{t(lang, "priceTitle1")} </span>
              <span className="text-gradient">{t(lang, "priceTitle2")}</span>
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-[14px] leading-relaxed text-slate-600 dark:text-slate-400 sm:text-[15px]">
              {t(lang, "priceDesc")}
            </p>
            {/* ROUND CONTENT — the full comparison matrix now lives on /compare */}
            <Link
              href="/compare"
              className="group mt-5 inline-flex items-center gap-2 rounded-full border border-brand-200 bg-brand-500/[0.07] px-4 py-2 text-[12px] font-extrabold text-brand-700 transition-all duration-200 hover:border-brand-300 hover:bg-brand-500/15 hover:shadow-md hover:shadow-brand-500/20 active:scale-95 dark:border-brand-500/30 dark:bg-brand-500/10 dark:text-brand-300 dark:hover:bg-brand-500/20"
            >
              <CatIcon name="scale" className="h-[12px] w-[12px] transition-transform duration-200 group-hover:scale-110" />
              <span>{t(lang, "cmpBadge")}</span>
              <CatIcon name="arrow-right" className="h-[11px] w-[11px] transition-transform duration-200 group-hover:translate-x-0.5 rtl:rotate-180 rtl:group-hover:-translate-x-0.5" aria-hidden="true" />
            </Link>
          </Reveal>
        </div>

        {/* interactive core — billing toggle + advisor + cards grid + the
            Enterprise quote dialog (client island; the live feed arrives
            server-resolved) */}
        <PricingToggle lang={lang} packages={packages} />

        {/* ROUND 79 — the 14-Day Full-Access positioning banner: every new
            workspace starts with FULL access for two weeks; the only limits
            are the clearly-stated costly/sensitive ones (storage, usage). */}
        <Reveal delay={0.16}>
          <div className="mx-auto mt-8 flex max-w-3xl flex-col items-center gap-2.5 rounded-3xl border border-emerald-200/70 bg-linear-to-br from-emerald-50/70 to-teal-50/40 px-5 py-4 text-center sm:flex-row sm:text-start dark:border-emerald-500/20 dark:from-emerald-500/[0.08] dark:to-teal-500/[0.05]">
            <span
              className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg shadow-emerald-500/25"
              style={{ backgroundImage: grad("#10b981", "#0d9488") }}
              aria-hidden="true"
            >
              <CatIcon name="sparkles" className="h-5 w-5" />
            </span>
            <span className="min-w-0">
              <span className="flex flex-wrap items-center justify-center gap-2 sm:justify-start">
                <span className="font-display text-[14px] font-extrabold text-emerald-700 dark:text-emerald-300">
                  {t(lang, "featTrialFullAccess")}
                </span>
                <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-extrabold text-emerald-600 dark:bg-emerald-500/20 dark:text-emerald-300">
                  <CatIcon name="calendar-check" className="h-[10px] w-[10px]" />
                  {t(lang, "priceCta")}
                </span>
              </span>
              <span className="mt-1 block text-[12px] font-semibold leading-relaxed text-emerald-800/80 dark:text-emerald-200/70">
                {t(lang, "featTrialFullAccessDesc")}
              </span>
            </span>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export default PricingSection;
