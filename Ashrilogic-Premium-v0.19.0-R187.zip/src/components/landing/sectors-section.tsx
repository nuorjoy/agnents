"use client";

import { useMemo } from "react";
import { useLandingUi } from "@/lib/landing-ui-store";
import { CATEGORIES, SYSTEMS } from "@/data/catalog";
import { t } from "@/lib/i18n";
import type { Lang } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { grad } from "@/lib/utils";
import { Reveal } from "@/components/landing/reveal";

export interface SectorsSectionProps {
  /** cookie language for the server-rendered initial text (ROUND 172c —
   *  live switching re-renders this island through the prop after
   *  router.refresh; the interaction model is untouched) */
  lang: Lang;
}

export function SectorsSection({ lang }: SectorsSectionProps) {
  /* ROUND 172c — the sector card click now writes the shared landing UI
   * store + smooth-scrolls to the library (the exact former lifted-state
   * handler, moved inline; the props interface dropped onSelectSector). */
  const setCat = useLandingUi((s) => s.setCat);
  const onSelectSector = (categoryId: string) => {
    setCat(categoryId);
    document.getElementById("systems")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };
  const counts = useMemo(() => {
    const map = new Map<string, number>();
    for (const s of SYSTEMS) map.set(s.c, (map.get(s.c) ?? 0) + 1);
    return map;
  }, []);
  /* the largest sector's system count — drives the relative fill width of the
     thin progress bar under each sector name so visitors see at a glance which
     sectors carry the deepest catalog (visual data-viz, no new content). */
  const maxCount = useMemo(() => Math.max(1, ...Array.from(counts.values())), [counts]);

  return (
    <section id="sectors" className="cv-auto relative scroll-mt-20 overflow-hidden px-4 py-16 sm:px-6 lg:px-8 lg:py-20">
      {/* decorative gradient mesh */}
      <div className="pointer-events-none absolute inset-0 -z-10 opacity-50" aria-hidden>
        <div className="absolute start-0 top-1/3 h-72 w-72 rounded-full bg-cyan-400/10 blur-3xl" />
        <div className="absolute end-0 bottom-1/4 h-80 w-80 rounded-full bg-brand-500/8 blur-3xl" />
      </div>
      <div className="mx-auto max-w-7xl">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3.5 py-1.5 text-[11px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
              <CatIcon name="network" className="h-[11px] w-[11px] text-brand-500" />
              <span>{t(lang, "sectorsBadge")}</span>
            </span>
            <h2 className="mt-5 font-display text-[28px] font-extrabold tracking-tight sm:text-4xl">
              <span>{CATEGORIES.length} </span>
              <span className="text-gradient">{t(lang, "sectorsTitle")}</span>
            </h2>
          </Reveal>
        </div>

        <div className="mt-12 grid grid-cols-2 gap-3.5 sm:grid-cols-3 lg:grid-cols-5">
          {CATEGORIES.map((cat, i) => {
            const count = counts.get(cat.id) ?? 0;
            return (
              <Reveal key={cat.id} delay={Math.min(i, 7) * 0.05} className="h-full">
                <button
                  type="button"
                  onClick={() => onSelectSector(cat.id)}
                  className="group relative h-full w-full cursor-pointer overflow-hidden rounded-3xl border border-slate-200/80 bg-white p-5 text-start shadow-soft outline-none transition-all duration-300 hover:-translate-y-1.5 hover:border-transparent hover:shadow-lift focus-visible:ring-4 focus-visible:ring-brand-500/20 dark:border-white/10 dark:bg-white/[0.035] dark:hover:bg-white/[0.06]"
                >
                  <span
                    className="pointer-events-none absolute -end-8 -top-8 h-24 w-24 rounded-full opacity-10 transition-opacity duration-300 group-hover:opacity-25"
                    style={{ backgroundImage: grad(cat.c1, cat.c2) }}
                    aria-hidden="true"
                  />
                  <span
                    className="relative grid h-11 w-11 place-items-center rounded-2xl text-white shadow-lg transition-transform duration-300 group-hover:scale-110"
                    style={{
                      backgroundImage: grad(cat.c1, cat.c2),
                      boxShadow: `0 10px 22px -10px ${cat.c1}cc`,
                    }}
                  >
                    <CatIcon name={cat.icon} className="h-[15px] w-[15px]" />
                  </span>
                  <h3 className="relative mt-4 font-display text-[13px] font-extrabold leading-snug">
                    {lang === "ar" ? cat.nameAr : cat.nameEn}
                  </h3>
                  <p className="relative mt-1 text-[11px] font-bold text-slate-500 dark:text-slate-400">
                    {count} {t(lang, "resultsUnit")}
                  </p>
                  {/* relative fill bar — the sector's share of the deepest
                      sector's catalog. Thin (1.5px) gradient track with a
                      category-colored fill that scales with count/maxCount.
                      Purely decorative (aria-hidden); the numeric count above
                      stays the accessible source of truth. */}
                  <div
                    className="relative mt-2.5 h-[3px] w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/[0.06]"
                    aria-hidden="true"
                  >
                    <span
                      className="block h-full rounded-full transition-all duration-500 ease-out group-hover:w-full"
                      style={{
                        width: `${Math.round((count / maxCount) * 100)}%`,
                        backgroundImage: grad(cat.c1, cat.c2),
                      }}
                    />
                  </div>
                </button>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export default SectorsSection;
