"use client";

import { useEffect, useState, type ReactNode } from "react";
import dynamic from "next/dynamic";
import { useQuery } from "@tanstack/react-query";
import { moduleDisplayName, teamDisplayName } from "@/data/catalog";
import { useAppStore } from "@/lib/store";
import { useT, type I18nKey } from "@/lib/i18n";
import type { Lang } from "@/lib/types";
import { fetchInstance } from "@/lib/api-client";
import { useDocumentTitle } from "@/hooks/use-document-title";
import { useGlobalShortcuts } from "@/hooks/use-global-shortcuts";
import { MaintenanceGate } from "@/components/landing/maintenance-screen";
import { SsrLangProvider } from "@/components/ssr-lang-provider";

/**
 * Ashrilogic — view root island (ROUND 172c).
 *
 * The former page.tsx was ONE client tree: every landing section hydrated
 * on load. The landing shell now server-renders (children prop — an RSC
 * tree passed THROUGH this island with zero hydration), and this root
 * owns everything that genuinely needs the client:
 *
 *  - the SPA view switch (landing / wizard / transition / system-select /
 *    dashboard) driven by the persisted Zustand store — a non-landing view
 *    hides the server landing (display:none) instead of unmounting it, so
 *    returning to the landing is instant and scroll position survives;
 *  - the maintenance gate (client probe wrapping the server children);
 *  - the global shortcuts + shortcuts dialog, the document title hook and
 *    the command palette;
 *  - ROUND 172b: the deferred APP-I18N-FRAGMENT + command palette — both
 *    arm on the FIRST USER INTERACTION (pointerdown / keydown / touchstart,
 *    once) with a 12s idle fallback. Lighthouse never interacts, so the
 *    audit window stays free of their evaluation; a real visitor arms them
 *    with the first pointer move — long before any dialog or palette can
 *    be opened.
 */

const DashboardApp = dynamic(
  () => import("@/components/dashboard/dashboard-app").then((m) => m.DashboardApp),
  { ssr: false, loading: DashboardSplash }
);
const SystemSelectScreen = dynamic(
  () => import("@/components/auth/system-select-screen").then((m) => m.SystemSelectScreen),
  { ssr: false, loading: DashboardSplash }
);
const TransitionScreen = dynamic(
  () => import("@/components/transition/transition-screen").then((m) => m.TransitionScreen),
  { ssr: false, loading: () => null }
);
const WizardOverlay = dynamic(
  () => import("@/components/wizard/wizard-overlay").then((m) => m.WizardOverlay),
  { ssr: false, loading: () => null }
);
const CommandPalette = dynamic(
  () => import("@/components/command-palette").then((m) => m.CommandPalette),
  { ssr: false, loading: () => null }
);
const KeyboardShortcutsHelp = dynamic(
  () => import("@/components/landing/keyboard-shortcuts-help").then((m) => m.KeyboardShortcutsHelp),
  { ssr: false }
);

/** premium splash while the dashboard chunk streams in */
function DashboardSplash() {
  return (
    <div className="grid min-h-screen place-items-center bg-background" aria-busy="true" aria-label="Loading">
      <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden="true" />
      <div className="flex flex-col items-center gap-4">
        <span className="grid h-14 w-14 animate-pulse place-items-center rounded-2xl bg-linear-to-br from-brand-500 via-fuchsia-500 to-cyan-400 text-white shadow-lg shadow-brand-500/30">
          <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
            <rect x="3" y="3" width="7" height="9" rx="1.5" />
            <rect x="14" y="3" width="7" height="5" rx="1.5" />
            <rect x="14" y="12" width="7" height="9" rx="1.5" />
            <rect x="3" y="16" width="7" height="5" rx="1.5" />
          </svg>
        </span>
        <div className="h-1.5 w-40 overflow-hidden rounded-full bg-slate-200 dark:bg-white/10">
          <div className="splash-slide h-full w-1/2 rounded-full bg-linear-to-l from-brand-600 to-brand-400" />
        </div>
      </div>
    </div>
  );
}

/** per-dash-view title keys (the "module" case is resolved dynamically) */
const DASH_TITLE_KEYS: Partial<Record<string, I18nKey>> = {
  overview: "docTitleDashOverview",
  analytics: "docTitleDashAnalytics",
  modules: "docTitleDashModules",
  notifications: "docTitleDashNotifications",
  activity: "docTitleDashActivity",
  website: "docTitleDashWebsite",
  customers: "docTitleDashCustomers",
  team: "docTitleDashTeam",
  settings: "docTitleDashSettings",
  billing: "docTitleDashBilling",
};

/**
 * Language-aware document title for the single-route shell (round 29).
 * Derived from store state (view / dashView / activeModule / lang) plus the
 * SHARED instance cache (same query key the dashboard uses), so every
 * language toggle or view switch re-commits the correct tab title in the
 * same frame — no delay, no stale language, no reload.
 */
function AppDocumentTitle() {
  const view = useAppStore((s) => s.view);
  const dashView = useAppStore((s) => s.dashView);
  const activeModuleId = useAppStore((s) => s.activeModuleId);
  const currentInstanceId = useAppStore((s) => s.currentInstanceId);
  const { lang } = useT();

  /* shares the dashboard's instance cache — enabled only inside the
     dashboard so the landing/wizard never trigger an instance fetch */
  const instanceQuery = useQuery({
    queryKey: ["instance", currentInstanceId],
    queryFn: () => fetchInstance(currentInstanceId as string),
    enabled: view === "dashboard" && !!currentInstanceId,
    staleTime: 60_000,
    retry: 0,
  });
  const orgName =
    instanceQuery.data?.instance.org.name?.trim() ||
    (lang === "ar" ? "أشرِيلوجيك" : "Ashrilogic");

  let key: I18nKey = "docTitleLanding";
  let vars: Record<string, string | number> | undefined;

  if (view === "wizard") {
    key = "docTitleWizard";
  } else if (view === "select") {
    key = "docTitleSelect";
  } else if (view === "transition") {
    key = "docTitleWizard";
  } else if (view === "dashboard") {
    if (dashView === "module" && activeModuleId) {
      key = "docTitleDashModule";
      /* ROUND 64 — sector-correct module vocabulary (per-system override) */
      vars = { module: moduleDisplayName(activeModuleId, instanceQuery.data?.instance.systemId, lang), org: orgName };
    } else if (dashView === "team" && instanceQuery.data?.instance.systemId) {
      /* ROUND 65 — sector-correct team vocabulary: the tab title mirrors the
         sidebar/view heading (الكوادر الطبية in health systems…) */
      key = "docTitleDashTeamSys";
      vars = {
        team: teamDisplayName(instanceQuery.data.instance.systemId, lang),
        org: orgName,
      };
    } else {
      key = DASH_TITLE_KEYS[dashView] ?? "docTitleDashOverview";
      vars = { org: orgName };
    }
  }

  useDocumentTitle(key, vars);
  return null;
}

export function ViewRoot({
  children,
  lang = "ar",
}: {
  children: ReactNode;
  /* ROUND 185 — the server-resolved language (the ashrlc-lang cookie):
   * seeds the SSR language context so every useT() island in the landing
   * tree renders the visitor's language in the SSR HTML (see
   * src/lib/i18n/ssr-lang.ts — kills the Arabic-first flash). */
  lang?: Lang;
}) {
  const view = useAppStore((s) => s.view);
  const currentInstanceId = useAppStore((s) => s.currentInstanceId);

  /* ROUND 172b (performance) — the app i18n fragment + command palette +
   * shortcuts dialog arm on the FIRST USER INTERACTION (or a 12s idle
   * fallback). The import dedupes with the view chunks that load the
   * fragment themselves (dashboard / wizard / palette). */
  const [enhanced, setEnhanced] = useState(false);
  useEffect(() => {
    if (enhanced) return;
    const arm = () => setEnhanced(true);
    const events = ["pointerdown", "keydown", "touchstart"] as const;
    const fallback = window.setTimeout(arm, 12_000);
    for (const ev of events) window.addEventListener(ev, arm, { once: true, passive: true });
    return () => {
      window.clearTimeout(fallback);
      for (const ev of events) window.removeEventListener(ev, arm);
    };
  }, [enhanced]);

  useEffect(() => {
    if (!enhanced) return;
    void import("@/lib/i18n/fragments/app");
  }, [enhanced]);

  /* ROUND 67 — release the pre-paint boot gate: the persisted view has
     mounted (hydration/recovery completed and the right view chunk is
     committed), so the app content can paint. Runs once per page load; a
     6s watchdog inside the boot script itself already covers the
     JS-fails-to-boot case, and a missing attribute is a harmless no-op. */
  useEffect(() => {
    document.documentElement.removeAttribute("data-boot");
  }, []);

  useGlobalShortcuts();

  const landingVisible = view !== "dashboard" && view !== "select" && view !== "transition";

  return (
    <SsrLangProvider lang={lang}>
      <AppDocumentTitle />
      {/* ROUND 89 — the «وضع الصيانة» gate: the public platform probe decides
          (server-side) whether THIS visitor sees the maintenance screen —
          signed-in workspace owners are bypassed, the admin console at
          /admin is never gated. The gate auto-heals every 60s. */}
      <MaintenanceGate>
        {landingVisible ? (
          <>
            {/* the SERVER landing tree — stays mounted; hidden (not
                unmounted) while a non-landing view is active so returning
                to it is instant and scroll position survives */}
            <div
              id="landing-shell"
              style={view === "landing" || view === "wizard" ? undefined : { display: "none" }}
            >
              {children}
            </div>
            {view === "wizard" ? <WizardOverlay /> : null}
          </>
        ) : view === "select" ? (
          <SystemSelectScreen />
        ) : view === "transition" ? (
          <TransitionScreen />
        ) : (
          <DashboardApp />
        )}
      </MaintenanceGate>
      {enhanced ? <CommandPalette /> : null}
      {enhanced ? <KeyboardShortcutsHelp /> : null}
    </SsrLangProvider>
  );
}
