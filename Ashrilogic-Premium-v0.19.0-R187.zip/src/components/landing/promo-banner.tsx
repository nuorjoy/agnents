"use client";

/**
 * Ashrilogic — the PUBLIC promotion banner strip (ROUND 169, العروض
 * الترويجية) — the Amazon/Walmart-grade top strip.
 *
 * Mounted ONCE inside the shared landing header (every public page that
 * uses the landing chrome shows it): a full-width premium strip ABOVE the
 * header that PUSHES content down (never an overlay).
 *
 *  - DATA: React Query on /api/promotions (staleTime 60s) — the live
 *    window feed (active + [startsAt..endsAt] contains now, ≤ 3). The
 *    first (lowest sortOrder) banner paints.
 *  - THEME SKINS: black-friday (near-black #0a0a0f + electric yellow),
 *    new-year (deep violet + gold sparkle ✦), eid (emerald + cream with
 *    crescent/star decorations ☾ ✧), sale (brand gradient), custom
 *    (slate) — bilingual copy resolved by the current locale.
 *  - LIVE COUNTDOWN to endsAt (days/hours/mins, tabular-nums) that PAUSES
 *    while the document is hidden (the LiveClock visibility law) and
 *    resyncs instantly on return.
 *  - DISMISS ✕ (keyboard: focus + Enter/Space): the dismissal is keyed
 *    promo-dismissed:<id>:<startsAt-epoch> in localStorage — a NEW window
 *    (same id, new startsAt) reappears.
 *  - CTA: next/link for the in-app relative href (the server validated it
 *    starts with "/" or "#" — never external).
 *  - prefers-reduced-motion: no shimmer/pulse — the decorations stay
 *    static (the CSS safety net in globals.css also applies).
 */
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import { useReducedMotion } from "@/hooks/use-reduced-motion";
import { fetchPublicPromotions } from "@/lib/api-client";
import { useT, type I18nKey } from "@/lib/i18n";
import type { Lang } from "@/lib/types";
import type { PublicPromotionDTO } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { cn } from "@/lib/utils";

/* ------------------------------------------------------------------ */
/* countdown (the LiveClock visibility law — zero timers while hidden)  */
/* ------------------------------------------------------------------ */

/** Ticking `now` while the document is visible; paused (and instantly
 * resynced) on visibility return. Mounted-only state — the first client
 * render matches the SSR placeholder (no hydration mismatch). */
function useVisibleNow(intervalMs = 30_000): number | null {
  const [now, setNow] = useState<number | null>(null);
  useEffect(() => {
    const tick = () => setNow(Date.now());
    let id = 0;
    const start = () => {
      tick();
      id = window.setInterval(tick, intervalMs);
    };
    const stop = () => {
      if (id) window.clearInterval(id);
      id = 0;
    };
    const onVisibility = () => {
      if (document.visibilityState === "visible") {
        tick(); /* resync instantly */
        if (id === 0) start();
      } else {
        stop();
      }
    };
    if (document.visibilityState !== "hidden") start();
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      document.removeEventListener("visibilitychange", onVisibility);
      stop();
    };
  }, [intervalMs]);
  return now;
}

/** The remaining [days, hours, minutes] until the target (null = past). */
function countdownParts(remainingMs: number): { days: number; hours: number; mins: number } | null {
  if (remainingMs <= 0) return null;
  const totalMins = Math.floor(remainingMs / 60_000);
  return {
    days: Math.floor(totalMins / 1440),
    hours: Math.floor((totalMins % 1440) / 60),
    mins: totalMins % 60,
  };
}

/* ------------------------------------------------------------------ */
/* theme skins                                                         */
/* ------------------------------------------------------------------ */

interface ThemeSkin {
  /** the strip's background classes (theme-native, both light/dark). */
  strip: string;
  /** the title/message typography classes. */
  text: string;
  /** the muted message typography classes. */
  muted: string;
  /** the countdown chip classes. */
  chip: string;
  /** the dismiss button classes. */
  close: string;
  /** the CTA button classes. */
  cta: string;
  /** the decorative glyph pair rendered beside the copy. */
  glyph: string;
}

const THEME_SKINS: Record<string, ThemeSkin> = {
  "black-friday": {
    strip: "bg-[#0a0a0f] text-white",
    text: "text-white",
    muted: "text-white/70",
    chip: "bg-yellow-400/15 text-yellow-300 ring-1 ring-yellow-400/40",
    close: "text-white/70 hover:text-white hover:bg-white/10",
    cta: "bg-yellow-400 text-[#0a0a0f] hover:bg-yellow-300 shadow-lg shadow-yellow-400/30",
    glyph: "⚡",
  },
  "new-year": {
    strip: "bg-linear-to-l from-[#2e1065] via-[#4c1d95] to-[#6d28d9] text-white",
    text: "text-white",
    muted: "text-amber-100/80",
    chip: "bg-amber-300/15 text-amber-200 ring-1 ring-amber-300/40",
    close: "text-amber-100/70 hover:text-white hover:bg-white/10",
    cta: "bg-amber-300 text-[#2e1065] hover:bg-amber-200 shadow-lg shadow-amber-400/30",
    glyph: "✦",
  },
  eid: {
    strip: "bg-linear-to-l from-emerald-950 via-emerald-800 to-emerald-700 text-emerald-50",
    text: "text-emerald-50",
    muted: "text-emerald-100/80",
    chip: "bg-emerald-200/15 text-emerald-100 ring-1 ring-emerald-200/40",
    close: "text-emerald-100/70 hover:text-white hover:bg-white/10",
    cta: "bg-emerald-100 text-emerald-950 hover:bg-white shadow-lg shadow-emerald-900/30",
    glyph: "☾",
  },
  sale: {
    strip: "bg-linear-to-l from-brand-600 via-brand-500 to-fuchsia-500 text-white",
    text: "text-white",
    muted: "text-white/80",
    chip: "bg-white/15 text-white ring-1 ring-white/40",
    close: "text-white/80 hover:text-white hover:bg-white/15",
    cta: "bg-white text-brand-700 hover:bg-white/90 shadow-lg shadow-brand-900/25",
    glyph: "％",
  },
  custom: {
    strip: "bg-slate-900 text-white dark:bg-slate-800",
    text: "text-white",
    muted: "text-slate-300",
    chip: "bg-white/10 text-slate-100 ring-1 ring-white/25",
    close: "text-slate-400 hover:text-white hover:bg-white/10",
    cta: "bg-white text-slate-900 hover:bg-slate-100 shadow-lg shadow-slate-900/25",
    glyph: "◆",
  },
};

function skinOf(theme: string): ThemeSkin {
  return THEME_SKINS[theme] ?? THEME_SKINS.sale!;
}

/* ------------------------------------------------------------------ */
/* the dismiss key (a NEW window reappears)                            */
/* ------------------------------------------------------------------ */

function dismissKey(promo: PublicPromotionDTO): string {
  return `promo-dismissed:${promo.id}:${Math.floor(new Date(promo.startsAt).getTime() / 1000)}`;
}

/* ------------------------------------------------------------------ */
/* the banner                                                          */
/* ------------------------------------------------------------------ */

/** Resolve the promotion's bilingual copy by the current locale. */
function localized(promo: PublicPromotionDTO, lang: Lang): { title: string; message: string; badge: string; cta: string } {
  const ar = lang === "ar";
  return {
    title: ar ? promo.titleAr : promo.titleEn,
    message: ar ? promo.messageAr : promo.messageEn,
    badge: ar ? promo.badgeAr : promo.badgeEn,
    cta: ar ? promo.ctaTextAr : promo.ctaTextEn,
  };
}

export function PromoBanner() {
  const { t, lang } = useT();
  const prefersReduced = useReducedMotion() ?? false;

  const query = useQuery({
    queryKey: ["public-promotions"],
    queryFn: fetchPublicPromotions,
    staleTime: 60_000,
    retry: 1,
  });

  const now = useVisibleNow(30_000);
  const [dismissedKeys, setDismissedKeys] = useState<Set<string> | null>(null);
  useEffect(() => {
    /* read the dismissal state once on mount (client-only — SSR renders
     * nothing, so there is no hydration decision to match) */
    try {
      const keys = new Set<string>();
      for (let i = 0; i < window.localStorage.length; i += 1) {
        const key = window.localStorage.key(i);
        if (key?.startsWith("promo-dismissed:")) keys.add(key);
      }
      setDismissedKeys(keys);
    } catch {
      setDismissedKeys(new Set());
    }
  }, []);

  const banner = useMemo(() => {
    const rows = query.data ?? [];
    const time = now ?? Date.now();
    return (
      rows.find((promo) => {
        if (dismissedKeys?.has(dismissKey(promo))) return false;
        return new Date(promo.endsAt).getTime() > time;
      }) ?? null
    );
  }, [query.data, dismissedKeys, now]);

  if (!banner) return null;

  const skin = skinOf(banner.theme);
  const copy = localized(banner, lang);
  const parts = countdownParts(new Date(banner.endsAt).getTime() - (now ?? Date.now()));
  const hasCta = banner.ctaHref !== "" && copy.cta !== "";

  const dismiss = () => {
    try {
      window.localStorage.setItem(dismissKey(banner), "1");
    } catch {
      /* storage unavailable — the dismissal simply won't persist */
    }
    setDismissedKeys((prev) => {
      const next = new Set(prev ?? []);
      next.add(dismissKey(banner));
      return next;
    });
  };

  const countdownCells: { value: number; labelKey: I18nKey }[] = parts
    ? [
        { value: parts.days, labelKey: "promoBannerDays" },
        { value: parts.hours, labelKey: "promoBannerHours" },
        { value: parts.mins, labelKey: "promoBannerMins" },
      ]
    : [];

  return (
    <section
      aria-label={t("promoBannerAria")}
      dir={lang === "ar" ? "rtl" : "ltr"}
      className={cn(
        "relative z-40 w-full border-b border-white/10",
        skin.strip,
        /* the fade-in entrance honors prefers-reduced-motion statically */
        prefersReduced ? "" : "banner-enter"
      )}
    >
      <div className="mx-auto flex min-h-11 max-w-7xl flex-wrap items-center justify-between gap-x-4 gap-y-1 px-4 py-1.5 sm:px-6 lg:px-8">
        {/* copy */}
        <p className="flex min-w-0 items-center gap-2 text-[12.5px] font-extrabold leading-tight">
          <span aria-hidden="true" className="shrink-0 select-none text-[13px]">
            {skin.glyph}
          </span>
          <span className={cn("truncate", skin.text)}>{copy.title}</span>
          {copy.message ? (
            <span className={cn("hidden truncate text-[11.5px] font-semibold sm:inline", skin.muted)}>
              {copy.message}
            </span>
          ) : null}
          {copy.badge ? (
            <span className={cn("shrink-0 rounded-full px-2 py-0.5 text-[10px] font-extrabold", skin.chip)}>
              {copy.badge}
            </span>
          ) : null}
          {banner.discountPct > 0 ? (
            <span className={cn("shrink-0 rounded-full px-2 py-0.5 text-[10px] font-extrabold tabular-nums", skin.chip)}>
              {t("promoBannerDiscount", { pct: banner.discountPct })}
            </span>
          ) : null}
        </p>

        {/* countdown + CTA + dismiss */}
        <div className="flex min-w-0 items-center gap-2">
          {countdownCells.length > 0 ? (
            <span
              dir="ltr"
              role="timer"
              aria-label={t("promoBannerAria")}
              className={cn(
                "flex select-none items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[10.5px] font-extrabold tabular-nums",
                skin.chip
              )}
            >
              <CatIcon name="timer" className="h-3 w-3" />
              {countdownCells.map((cell) => (
                <span key={cell.labelKey} className="whitespace-nowrap">
                  {String(cell.value).padStart(2, "0")}
                  <span className="ms-0.5 text-[9px] font-bold opacity-80">{t(cell.labelKey)}</span>
                </span>
              ))}
            </span>
          ) : null}

          {hasCta ? (
            <Link
              href={banner.ctaHref}
              className={cn(
                "inline-flex h-7 shrink-0 items-center gap-1.5 rounded-full px-3 text-[11px] font-extrabold transition hover:brightness-110 active:scale-95",
                skin.cta
              )}
            >
              {copy.cta}
            </Link>
          ) : null}

          <button
            type="button"
            onClick={dismiss}
            aria-label={t("promoBannerDismiss")}
            title={t("promoBannerDismiss")}
            className={cn(
              "grid h-8 w-8 shrink-0 place-items-center rounded-full transition active:scale-95",
              skin.close
            )}
          >
            <CatIcon name="x" className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </section>
  );
}

export default PromoBanner;
