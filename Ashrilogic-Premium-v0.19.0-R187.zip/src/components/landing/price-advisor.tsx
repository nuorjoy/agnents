"use client";

/**
 * ROUND 167 — توصية ذكية للسعر (the smart price recommendation advisor).
 *
 * The flagship interactive advisor embedded in the landing pricing section
 * (above the cards grid). The buyer states their need — users · active
 * modules · systems · storage GB · optional monthly budget — and the PURE
 * engine (src/lib/price-advisor.ts) recommends the CHEAPEST live tier whose
 * quotas satisfy every dimension, or the Enterprise quote arm when nothing
 * purchasable fits.
 *
 * Design law («أكثر فهماً وذكاءً»): EXPLAINABLE + DETERMINISTIC — every
 * number on the output card traces to a quota or a price from the LIVE
 * /api/packages feed (cost per user, per-dimension headroom bars, the
 * over-budget delta, the true yearly saving %), and the same inputs always
 * produce the same verdict. The «لماذا هذا التوصية؟» list narrates each
 * figure's provenance.
 */
import { useMemo, useState } from "react";
import type { Lang, PackageDTO } from "@/lib/types";
import { recommendPlan, type AdvisorDimensionKey, type AdvisorResult } from "@/lib/price-advisor";
import { moneyDisplayToMinor } from "@/components/ui/money-input";
import { fmtPlanPrice } from "@/lib/format";
import { useT, type I18nKey } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, hexAlpha } from "@/lib/utils";

/* ------------------------------------------------------------------ */
/* the need inputs (bounded steppers — the engine's documented domain)  */
/* ------------------------------------------------------------------ */

interface NeedField {
  key: "users" | "modules" | "systems" | "storage" | "budget";
  labelKey: I18nKey;
  icon: string;
  min: number;
  max: number;
  step: number;
  unitKey?: I18nKey;
}

const NEED_FIELDS: NeedField[] = [
  { key: "users", labelKey: "recUsers", icon: "users", min: 1, max: 100, step: 1, unitKey: "recUnitUsers" },
  { key: "modules", labelKey: "recModules", icon: "cubes", min: 1, max: 200, step: 1, unitKey: "recUnitModules" },
  { key: "systems", labelKey: "recSystems", icon: "boxes", min: 1, max: 10, step: 1, unitKey: "recUnitSystems" },
  { key: "storage", labelKey: "recStorage", icon: "hard-drive", min: 1, max: 100, step: 1, unitKey: "recUnitStorage" },
];

const BUDGET_MAX_MAJOR = 100000;

/* ------------------------------------------------------------------ */
/* unit-correct display of one dimension's figures                      */
/* ------------------------------------------------------------------ */

/* The engine reasons about storage in MB (the quota column); every
 * surfaced figure must print in the unit it actually carries — MB below
 * 1 GB, GB above (512 ميجابايت · 50 جيجابايت — never "512 جيجابايت"). */
const MB_PER_GB = 1024;
function storageDisplay(mb: number, lang: Lang): { n: string; unitKey: I18nKey } {
  if (mb >= MB_PER_GB) {
    const gb = mb / MB_PER_GB;
    return { n: fmtNum(Number.isInteger(gb) ? gb : Math.round(gb * 10) / 10, lang), unitKey: "recUnitStorage" };
  }
  return { n: fmtNum(mb, lang), unitKey: "recUnitStorageMb" };
}

/** One surfaced figure: the localized number + its unit key, in the unit
 *  the value actually carries (storage converts; the rest pass through). */
function dimDisplay(key: AdvisorDimensionKey, raw: number, lang: Lang): { n: string; unitKey: I18nKey } {
  if (key === "storage") return storageDisplay(raw, lang);
  return {
    n: fmtNum(raw, lang),
    unitKey: key === "users" ? "recUnitUsers" : key === "modules" ? "recUnitModules" : "recUnitSystems",
  };
}

function Stepper({
  field,
  value,
  onChange,
}: {
  field: NeedField;
  value: number;
  onChange: (next: number) => void;
}) {
  const { t } = useT();
  return (
    <div className="rounded-2xl border border-slate-200/80 bg-white/70 px-3 py-2.5 transition focus-within:border-brand-300 dark:border-white/10 dark:bg-white/[0.03]">
      <div className="flex items-center justify-between gap-2">
        <span className="flex min-w-0 items-center gap-1.5 text-[11px] font-extrabold text-slate-600 dark:text-slate-300">
          <CatIcon name={field.icon} className="h-3.5 w-3.5 shrink-0 text-brand-500" />
          <span className="truncate">{t(field.labelKey)}</span>
        </span>
        <span className="flex shrink-0 items-center gap-1" dir="ltr">
          <button
            type="button"
            onClick={() => onChange(Math.max(field.min, value - field.step))}
            disabled={value <= field.min}
            aria-label={t("pkgQuotaMinus")}
            className="grid h-7 w-7 place-items-center rounded-lg border border-slate-200 bg-white text-slate-500 transition hover:border-brand-300 hover:text-brand-600 active:scale-90 disabled:cursor-not-allowed disabled:opacity-40 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-400"
          >
            <CatIcon name="minus" className="h-3 w-3" />
          </button>
          <span className="min-w-[2.25rem] text-center text-[14px] font-extrabold tabular-nums text-slate-800 dark:text-slate-100">
            {value}
          </span>
          <button
            type="button"
            onClick={() => onChange(Math.min(field.max, value + field.step))}
            disabled={value >= field.max}
            aria-label={t("pkgQuotaPlus")}
            className="grid h-7 w-7 place-items-center rounded-lg border border-slate-200 bg-white text-slate-500 transition hover:border-brand-300 hover:text-brand-600 active:scale-90 disabled:cursor-not-allowed disabled:opacity-40 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-400"
          >
            <CatIcon name="plus" className="h-3 w-3" />
          </button>
        </span>
      </div>
      {field.unitKey ? (
        <p className="mt-1 text-[9.5px] font-semibold text-slate-500 dark:text-slate-400">
          {t(field.unitKey)} · {field.min}–{field.max}
        </p>
      ) : null}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* the headroom bar                                                     */
/* ------------------------------------------------------------------ */

function HeadroomBar({
  labelKey,
  icon,
  pct,
  unlimited,
  c1,
  c2,
}: {
  labelKey: I18nKey;
  icon: string;
  pct: number;
  unlimited: boolean;
  c1: string;
  c2: string;
}) {
  const { t } = useT();
  const width = unlimited ? 100 : Math.min(100, Math.max(3, pct));
  return (
    <div className="flex items-center gap-2.5">
      <span className="flex w-24 shrink-0 items-center gap-1.5 text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
        <CatIcon name={icon} className="h-3 w-3 shrink-0" style={{ color: c1 }} />
        <span className="truncate">{t(labelKey)}</span>
      </span>
      <span className="relative h-2 min-w-0 flex-1 overflow-hidden rounded-full bg-slate-200/80 dark:bg-white/10" dir="ltr">
        <span
          className="absolute inset-y-0 start-0 rounded-full transition-all duration-500"
          style={{ width: `${width}%`, backgroundImage: grad(c1, c2) }}
        />
      </span>
      <span
        className="w-14 shrink-0 text-end text-[10px] font-extrabold tabular-nums text-slate-500 dark:text-slate-400"
        dir="ltr"
      >
        {unlimited ? "∞" : `+${pct}%`}
      </span>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* the verdict card                                                     */
/* ------------------------------------------------------------------ */

function VerdictCard({
  result,
  lang,
  budgetMajor,
  onQuote,
}: {
  result: AdvisorResult;
  lang: Lang;
  budgetMajor: number | null;
  onQuote: (systems: number) => void;
}) {
  const { t } = useT();

  if (result.kind === "enterprise") {
    return (
      <div className="rounded-2xl border border-amber-300/60 bg-linear-to-br from-amber-50/90 to-orange-50/70 p-4 shadow-lg shadow-amber-500/10 dark:border-amber-400/25 dark:from-amber-500/10 dark:to-orange-500/[0.06] sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="flex items-center gap-2 text-[13px] font-extrabold text-amber-700 dark:text-amber-300">
            <span
              className="grid h-8 w-8 place-items-center rounded-xl text-white shadow-md"
              style={{ backgroundImage: grad("#f59e0b", "#ea580c") }}
              aria-hidden="true"
            >
              <CatIcon name="building" className="h-4 w-4" />
            </span>
            {t("recEnterpriseTitle")}
          </p>
          <span className="rounded-full bg-amber-500/15 px-2.5 py-1 text-[10.5px] font-extrabold text-amber-700 dark:text-amber-300">
            {t("priceCustom")}
          </span>
        </div>
        <p className="mt-2 text-[12px] font-semibold leading-relaxed text-amber-800/80 dark:text-amber-200/70">
          {t("recEnterpriseDesc")}
        </p>

        {/* the reasons — every line traces a quota */}
        <ul className="mt-3 space-y-1.5">
          {result.reasons.map((reason) => {
            const need = dimDisplay(reason.key, reason.needed, lang);
            const quota = dimDisplay(reason.key, reason.bestQuota, lang);
            return (
              <li key={reason.key} className="flex items-start gap-2 text-[11.5px] font-semibold leading-relaxed text-slate-600 dark:text-slate-300">
                <span className="mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full bg-rose-500/15 text-rose-500" aria-hidden="true">
                  <CatIcon name="x" className="h-2.5 w-2.5" />
                </span>
                {reason.bestUnlimited
                  ? t("recEnterpriseReasonUnlimited", { unit: t(need.unitKey), need: need.n })
                  : t("recEnterpriseReason", {
                      unit: t(quota.unitKey),
                      needUnit: t(need.unitKey),
                      need: need.n,
                      quota: quota.n,
                    })}
              </li>
            );
          })}
          {result.enterprise ? (
            <li className="flex items-start gap-2 text-[11.5px] font-semibold leading-relaxed text-emerald-700 dark:text-emerald-300">
              <span className="mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full bg-emerald-500/15 text-emerald-500" aria-hidden="true">
                <CatIcon name="check" className="h-2.5 w-2.5" />
              </span>
              {result.reasons.some((reason) => reason.enterpriseCovers === false)
                ? t("recEnterpriseMissing")
                : t("recEnterpriseCovers")}
            </li>
          ) : null}
        </ul>

        <button
          type="button"
          onClick={() => onQuote(Math.min(500, Math.max(1, 10)))}
          className="mt-4 inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl text-[12.5px] font-extrabold text-white shadow-lg shadow-amber-500/30 transition hover:-translate-y-0.5 hover:brightness-110 active:scale-95"
          style={{ backgroundImage: grad("#f59e0b", "#ea580c") }}
        >
          <CatIcon name="send" className="h-4 w-4 rtl:-scale-x-100" />
          {t("recQuoteCta")}
        </button>
      </div>
    );
  }

  const { plan } = result;
  const name = lang === "ar" ? plan.nameAr : plan.nameEn;

  return (
    <div className="relative overflow-hidden rounded-2xl border border-emerald-300/60 bg-linear-to-br from-emerald-50/90 via-white to-cyan-50/70 p-4 shadow-lg shadow-emerald-500/10 dark:border-emerald-400/25 dark:from-emerald-500/10 dark:via-transparent dark:to-cyan-500/[0.06] sm:p-5">
      {/* the popular gradient ring */}
      {plan.popular ? (
        <span
          className="pointer-events-none absolute inset-0 rounded-2xl p-[2px]"
          style={{ background: grad("#6d5dfb", "#d946ef"), WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", maskComposite: "exclude" }}
          aria-hidden="true"
        />
      ) : null}

      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="flex items-center gap-2 text-[13px] font-extrabold text-slate-900 dark:text-white">
          <span
            className="grid h-8 w-8 place-items-center rounded-xl text-white shadow-md"
            style={{ backgroundImage: grad("#10b981", "#0d9488") }}
            aria-hidden="true"
          >
            <CatIcon name="sparkles" className="h-4 w-4" />
          </span>
          {t("recVerdictTitle")}
        </p>
        {plan.popular ? (
          <span className="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-extrabold text-white shadow-md" style={{ backgroundImage: grad("#6d5dfb", "#d946ef") }}>
            <CatIcon name="star" className="h-[9px] w-[9px] fill-white" />
            {t("pricePopular")}
          </span>
        ) : null}
      </div>

      {/* the recommended plan + price */}
      <div className="mt-3 flex flex-wrap items-end gap-x-2 gap-y-1">
        <span className="font-display text-[17px] font-extrabold text-emerald-700 dark:text-emerald-300">{name}</span>
        <span className="mb-0.5 h-4 w-px bg-slate-300 dark:bg-white/20" aria-hidden="true" />
        <span className="font-display text-[22px] font-extrabold tabular-nums text-slate-900 dark:text-white" dir="ltr">
          {fmtPlanPrice(result.monthlyMinor)}
        </span>
        <span className="mb-1 text-[11px] font-bold text-slate-500 dark:text-slate-400">
          {plan.currency} · {t("pricePerMonth")}
        </span>
      </div>

      {/* the WHY lines — every number traces to a quota or a price */}
      <ul className="mt-3 space-y-1.5">
        <li className="flex items-start gap-2 text-[11.5px] font-semibold leading-relaxed text-slate-600 dark:text-slate-300">
          <span className="mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full bg-emerald-500/15 text-emerald-500" aria-hidden="true">
            <CatIcon name="check" className="h-2.5 w-2.5" />
          </span>
          {t("recWhyCheapest")}
        </li>
        {result.dimensions.map((dimension) => {
          /* unit-correct figure (storage prints MB below 1 GB / GB above) */
          const quota = dimDisplay(dimension.key, dimension.quota, lang);
          return (
            <li key={dimension.key} className="flex items-start gap-2 text-[11.5px] font-semibold leading-relaxed text-slate-600 dark:text-slate-300">
              <span className="mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full bg-emerald-500/15 text-emerald-500" aria-hidden="true">
                <CatIcon name="check" className="h-2.5 w-2.5" />
              </span>
              {dimension.unlimited
                ? t("recWhyUnlimited", { unit: t(quota.unitKey) })
                : dimension.headroomPct > 0
                  ? t("recWhyHeadroom", {
                      n: quota.n,
                      unit: t(quota.unitKey),
                      pct: fmtNum(dimension.headroomPct, lang),
                    })
                  : t("recWhyHeadroomExact", { n: quota.n, unit: t(quota.unitKey) })}
            </li>
          );
        })}
        <li className="flex items-start gap-2 text-[11.5px] font-semibold leading-relaxed text-slate-600 dark:text-slate-300">
          <span className="mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full bg-brand-500/15 text-brand-500" aria-hidden="true">
            <CatIcon name="banknote" className="h-2.5 w-2.5" />
          </span>
          {t("recWhyCostPerUser", { price: fmtPlanPrice(result.costPerUserMinor), currency: plan.currency })}
        </li>
        {result.overBudgetMinor !== null && result.overBudgetMinor > 0 ? (
          <li className="flex items-start gap-2 text-[11.5px] font-semibold leading-relaxed text-amber-700 dark:text-amber-300">
            <span className="mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full bg-amber-500/15 text-amber-500" aria-hidden="true">
              <CatIcon name="triangle-alert" className="h-2.5 w-2.5" />
            </span>
            {t("recOverBudget", {
              amount: fmtPlanPrice(result.overBudgetMinor),
              budget: fmtPlanPrice(Math.round((budgetMajor ?? 0) * 100)),
            })}
          </li>
        ) : result.overBudgetMinor !== null ? (
          <li className="flex items-start gap-2 text-[11.5px] font-semibold leading-relaxed text-emerald-700 dark:text-emerald-300">
            <span className="mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full bg-emerald-500/15 text-emerald-500" aria-hidden="true">
              <CatIcon name="wallet" className="h-2.5 w-2.5" />
            </span>
            {t("recWithinBudget")}
          </li>
        ) : null}
        <li className="flex items-start gap-2 text-[11.5px] font-semibold leading-relaxed text-slate-600 dark:text-slate-300">
          <span className="mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full bg-cyan-500/15 text-cyan-500" aria-hidden="true">
            <CatIcon name="calendar-days" className="h-2.5 w-2.5" />
          </span>
          {result.yearlySavingPct >= 15
            ? t("recYearlyAdvice", { pct: fmtNum(result.yearlySavingPct, lang) })
            : t("recYearlyAdviceWeak", { pct: fmtNum(result.yearlySavingPct, lang) })}
        </li>
        {result.runnerUp ? (
          <li className="flex items-start gap-2 text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
            <span className="mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full bg-slate-500/15 text-slate-400" aria-hidden="true">
              <CatIcon name="arrow-up" className="h-2.5 w-2.5" />
            </span>
            {t("recRunnerUpLine", {
              name: lang === "ar" ? result.runnerUp.nameAr : result.runnerUp.nameEn,
              amount: fmtPlanPrice(result.runnerUp.priceMonthly - result.monthlyMinor),
            })}
          </li>
        ) : null}
      </ul>

      {/* headroom bars — the visual WHY */}
      <div className="mt-3.5 space-y-2 rounded-xl border border-slate-200/70 bg-white/60 p-3 dark:border-white/10 dark:bg-white/[0.03]">
        {result.dimensions.map((dimension) => (
          <HeadroomBar
            key={dimension.key}
            labelKey={
              dimension.key === "users"
                ? "recDimUsers"
                : dimension.key === "modules"
                  ? "recDimModules"
                  : dimension.key === "storage"
                    ? "recDimStorage"
                    : "recDimSystems"
            }
            icon={
              dimension.key === "users"
                ? "users"
                : dimension.key === "modules"
                  ? "cubes"
                  : dimension.key === "storage"
                    ? "hard-drive"
                    : "boxes"
            }
            pct={dimension.headroomPct}
            unlimited={dimension.unlimited}
            c1="#10b981"
            c2="#06b6d4"
          />
        ))}
      </div>

      {/* the transparency footer */}
      <p className="mt-3 flex items-start gap-1.5 text-[10.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
        <CatIcon name="info" className="mt-0.5 h-3 w-3 shrink-0" />
        {t("recTransparency")}
      </p>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* the advisor                                                          */
/* ------------------------------------------------------------------ */

export function PriceAdvisor({
  packages,
  onQuote,
}: {
  packages: PackageDTO[];
  onQuote: (systems: number) => void;
}) {
  const { t, lang } = useT();
  const [open, setOpen] = useState(true);
  const [users, setUsers] = useState(5);
  const [modules, setModules] = useState(10);
  const [systems, setSystems] = useState(1);
  const [storage, setStorage] = useState(5);
  const [budget, setBudget] = useState("");

  const budgetMajor = useMemo(() => {
    const minor = moneyDisplayToMinor(budget);
    if (minor === null || minor <= 0) return null;
    return Math.min(BUDGET_MAX_MAJOR * 100, minor) / 100;
  }, [budget]);

  const result = useMemo(
    () =>
      recommendPlan(packages, {
        users,
        modules,
        systems,
        storageGb: storage,
        ...(budgetMajor !== null ? { budgetMonthly: budgetMajor } : {}),
      }),
    [packages, users, modules, systems, storage, budgetMajor]
  );

  const reset = () => {
    setUsers(5);
    setModules(10);
    setSystems(1);
    setStorage(5);
    setBudget("");
  };

  return (
    <div className="relative overflow-hidden rounded-3xl border border-brand-200/70 bg-linear-to-br from-brand-50/80 via-white to-fuchsia-50/50 p-4 shadow-xl shadow-brand-500/10 sm:p-6 dark:border-brand-500/20 dark:from-brand-500/[0.08] dark:via-transparent dark:to-fuchsia-500/[0.05]">
      {/* hover glow accent */}
      <div
        className="pointer-events-none absolute inset-0 -z-10"
        style={{ background: `radial-gradient(500px circle at 20% 0%, ${hexAlpha("#6d5dfb", 0.07)}, transparent 70%)` }}
        aria-hidden="true"
      />

      {/* header — toggle (collapsible, premium) */}
      <div className="flex flex-wrap items-center justify-between gap-2.5">
        <button
          type="button"
          onClick={() => setOpen((next) => !next)}
          aria-expanded={open}
          className="flex min-w-0 items-center gap-3 text-start"
        >
          <span
            className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg shadow-brand-500/30"
            style={{ backgroundImage: grad("#6d5dfb", "#d946ef") }}
            aria-hidden="true"
          >
            <CatIcon name="wand-sparkles" className="h-5 w-5" />
          </span>
          <span className="min-w-0">
            <span className="flex flex-wrap items-center gap-2">
              <span className="font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                {t("recTitle")}
              </span>
              <span className="inline-flex items-center gap-1 rounded-full bg-brand-500/10 px-2 py-0.5 text-[9.5px] font-extrabold text-brand-600 dark:text-brand-300">
                <CatIcon name="sparkles" className="h-[9px] w-[9px]" />
                {t("recBadge")}
              </span>
            </span>
            <span className="mt-0.5 block text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
              {t("recDesc")}
            </span>
          </span>
          <CatIcon
            name="chevron-down"
            className={cn("h-4 w-4 shrink-0 text-slate-400 transition-transform duration-300", open && "rotate-180")}
            aria-hidden="true"
          />
        </button>
        <button
          type="button"
          onClick={reset}
          className="inline-flex h-8 shrink-0 items-center gap-1.5 rounded-xl border border-slate-200 bg-white/80 px-3 text-[10.5px] font-bold text-slate-500 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
        >
          <CatIcon name="rotate-ccw" className="h-3 w-3" />
          {t("recReset")}
        </button>
      </div>

      {open ? (
        <div className="mt-5 grid gap-4 lg:grid-cols-[1.15fr_1fr]">
          {/* the need inputs */}
          <div className="space-y-2.5">
            <p className="flex items-center gap-1.5 text-[10.5px] font-extrabold uppercase tracking-wide text-slate-500 dark:text-slate-400">
              <CatIcon name="sliders" className="h-3 w-3" />
              {t("recInputsTitle")}
            </p>
            <div className="grid gap-2.5 sm:grid-cols-2">
              {NEED_FIELDS.map((field) => (
                <Stepper
                  key={field.key}
                  field={field}
                  value={field.key === "users" ? users : field.key === "modules" ? modules : field.key === "systems" ? systems : storage}
                  onChange={(next) =>
                    field.key === "users"
                      ? setUsers(next)
                      : field.key === "modules"
                        ? setModules(next)
                        : field.key === "systems"
                          ? setSystems(next)
                          : setStorage(next)
                  }
                />
              ))}
            </div>

            {/* the optional monthly budget (decimals welcome) */}
            <div className="rounded-2xl border border-slate-200/80 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.03]">
              <label htmlFor="rec-budget" className="flex items-center gap-1.5 text-[11px] font-extrabold text-slate-600 dark:text-slate-300">
                <CatIcon name="wallet" className="h-3.5 w-3.5 shrink-0 text-emerald-500" />
                {t("recBudget")}
                <span className="text-[9.5px] font-semibold text-slate-500 dark:text-slate-400">
                  {t("recBudgetOptional")}
                </span>
              </label>
              <div className="mt-1.5 flex items-center gap-2" dir="ltr">
                <input
                  id="rec-budget"
                  type="text"
                  inputMode="decimal"
                  autoComplete="off"
                  value={budget}
                  onChange={(e) => {
                    /* comma → dot (the engine's parser — moneyDisplayToMinor
                     * — additionally tolerates international digits) */
                    setBudget(e.target.value.replace(/,/g, ".").slice(0, 12));
                  }}
                  placeholder={t("recBudgetPh")}
                  aria-label={t("recBudget")}
                  className="h-9 w-32 rounded-xl border border-slate-200 bg-white/90 px-3 text-end text-[12.5px] font-extrabold tabular-nums text-slate-800 transition focus:border-emerald-400 focus:shadow-lg focus:shadow-emerald-500/15 focus:ring-4 focus:ring-emerald-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100"
                />
                {budgetMajor !== null ? (
                  <span className="text-[10.5px] font-bold tabular-nums text-emerald-600 dark:text-emerald-400" dir="ltr">
                    ≈ {fmtPlanPrice(Math.round(budgetMajor * 100))} {packages[0]?.currency ?? "USD"}
                  </span>
                ) : null}
              </div>
            </div>
          </div>

          {/* the verdict */}
          <VerdictCard result={result} lang={lang} budgetMajor={budgetMajor} onQuote={onQuote} />
        </div>
      ) : null}
    </div>
  );
}

export default PriceAdvisor;
