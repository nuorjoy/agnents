"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";

import { cn } from "@/lib/utils";

/**
 * Subtle section reveal — ROUND 170 (performance): the former
 * framer-motion `whileInView` implementation cost the PUBLIC landing the
 * entire framer-motion engine chunk (~56KB gzip, evaluated during the
 * critical-hydration window). This drop-in replacement keeps the EXACT
 * same visual contract — 0.5s, y: 18px, cubic-bezier(0.22, 1, 0.36, 1),
 * reveal-once at viewport −60px — via a single IntersectionObserver + a
 * CSS transition (`.reveal-io` in globals.css, disabled under
 * prefers-reduced-motion). The public API (children / className / delay)
 * is unchanged, so every consumer stays byte-compatible.
 *
 * SSR parity: framer shipped the section HTML at opacity:0 and revealed
 * after hydration; `.reveal-io` does the same — then the observer flips
 * the class for any section already in view (the framer `whileInView`
 * behavior, including the "-60px" margin).
 */
export function Reveal({
  children,
  className,
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [shown, setShown] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    /* IntersectionObserver is baseline since 2019 (Chrome 51+, Safari
       12.1+, Firefox 55+) — every browser in the supported matrix has it.
       The try/catch keeps an ancient-engine escape hatch WITHOUT a
       synchronous setState (cascading-render smell): the revealed class
       is applied directly on the node. */
    let io: IntersectionObserver | null = null;
    try {
      io = new IntersectionObserver(
        (entries) => {
          for (const entry of entries) {
            if (entry.isIntersecting) {
              setShown(true);
              io?.disconnect();
            }
          }
        },
        { rootMargin: "-60px 0px 0px 0px", threshold: 0 }
      );
      io.observe(el);
    } catch {
      el.classList.add("reveal-io-in");
    }
    return () => io?.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={cn("reveal-io", shown && "reveal-io-in", className)}
      style={delay ? { transitionDelay: `${delay}s` } : undefined}
    >
      {children}
    </div>
  );
}

/**
 * ROUND 167 (LCP) — the HERO variant: a pure-CSS entrance (the
 * `hero-rise` keyframes in globals.css, same rise distance + the family's
 * cubic-bezier feel). Unlike Reveal, the SSR HTML carries NO hidden
 * initial state — the animation starts at style-parse time, BEFORE
 * JavaScript hydrates, so the largest contentful paint (the hero H1) does
 * not wait for the bundle to download + execute + animate. Use for
 * above-the-fold copy ONLY; below-the-fold sections keep Reveal (its
 * whileInView gating is the right tool there).
 */
export function HeroReveal({
  children,
  className,
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  return (
    <div
      className={cn("hero-rise", className)}
      style={{ animation: `hero-rise 0.55s cubic-bezier(0.22, 1, 0.36, 1) ${delay}s both` }}
    >
      {children}
    </div>
  );
}
