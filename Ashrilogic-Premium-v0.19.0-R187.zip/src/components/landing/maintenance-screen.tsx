"use client";

/**
 * ROUND 89 — the premium MAINTENANCE SCREEN (وضع الصيانة).
 *
 * Rendered by the single-route shell (src/app/page.tsx) when the public
 * platform probe (GET /api/maintenance) reports the platform's
 * maintenanceMode ON for the current visitor (workspace owners are
 * bypassed server-side; the admin console at /admin stays reachable —
 * it is how the toggle gets switched back off).
 *
 * Design language: the landing's mesh + gradient vocabulary, an animated
 * status beacon, the support contact chip, a manual retry button and a
 * 60-second automatic re-check so the site returns the moment the toggle
 * flips — no reload required from the visitor's side.
 */

import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { fetchMaintenanceState } from "@/lib/api-client";
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { grad } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { PlatformBrandTile } from "@/components/shared/platform-brand";

/** The shared query key — every maintenance-aware surface reuses it. */
export const MAINTENANCE_QUERY_KEY = ["maintenance-state"] as const;

/** 60s auto re-check (the site recovers itself the moment the toggle flips). */
const RECHECK_MS = 60_000;

export function MaintenanceScreen() {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const [beacon, setBeacon] = useState(true);

  /* gentle status beacon pulse toggle (pure CSS below needs no state; this
     drives the aria-live text changes only) */
  useEffect(() => {
    const timer = window.setInterval(() => setBeacon((b) => !b), 2000);
    return () => window.clearInterval(timer);
  }, []);

  const siteName = useQuery({
    queryKey: MAINTENANCE_QUERY_KEY,
    queryFn: fetchMaintenanceState,
    staleTime: 30_000,
    retry: 1,
  });

  const orgName =
    lang === "ar" ? siteName.data?.siteNameAr ?? "أشرِيلوجيك" : siteName.data?.siteNameEn ?? "Ashrilogic";

  return (
    <main className="mesh relative grid min-h-screen place-items-center overflow-hidden bg-background px-4 py-10">
      {/* ambient brand glow */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(600px circle at 50% 20%, rgba(109,93,251,0.10), transparent 70%), radial-gradient(400px circle at 80% 90%, rgba(6,182,212,0.08), transparent 70%)",
        }}
        aria-hidden="true"
      />

      <div className="relative w-full max-w-lg">
        {/* card */}
        <div className="card-in rounded-3xl border border-slate-200/80 bg-white/90 p-8 text-center shadow-2xl shadow-brand-500/10 backdrop-blur-xl dark:border-white/10 dark:bg-[#0a0f1c]/90 sm:p-10">
          {/* brand tile + status beacon */}
          <div className="relative mx-auto mb-6 w-fit">
            <PlatformBrandTile
              variant="main"
              className="h-16 w-16 rounded-2xl shadow-brand-500/30"
              fallback={
                <span
                  className="grid h-16 w-16 place-items-center rounded-2xl text-white shadow-lg shadow-brand-500/30"
                  style={{ backgroundImage: grad("#6d5dfb", "#06b6d4") }}
                  aria-hidden="true"
                >
                  <CatIcon name="boxes" className="h-7 w-7" />
                </span>
              }
            />
            {/* animated beacon — the "we're on it" signal */}
            <span className="absolute -end-1.5 -top-1.5 grid h-5 w-5 place-items-center" aria-hidden="true">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-amber-400 opacity-60" />
              <span className="relative inline-flex h-3 w-3 rounded-full bg-amber-500 shadow" />
            </span>
          </div>

          {/* badge */}
          <span className="mb-3 inline-flex items-center gap-1.5 rounded-full bg-amber-500/10 px-3 py-1 text-[10.5px] font-extrabold text-amber-600 dark:text-amber-400">
            <CatIcon name="wrench" className="h-3 w-3" />
            {t("maintBadge")}
          </span>

          <h1 className="font-display text-2xl font-extrabold leading-snug text-slate-900 dark:text-white sm:text-[27px]">
            {t("maintTitle")}
          </h1>
          <p className="mx-auto mt-2.5 max-w-sm text-[13.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
            {t("maintDesc")}
          </p>

          {/* actions */}
          <div className="mt-7 flex flex-wrap items-center justify-center gap-2.5">
            <Button
              onClick={() => void queryClient.invalidateQueries({ queryKey: MAINTENANCE_QUERY_KEY })}
              className="h-11 rounded-xl bg-linear-to-l from-brand-600 to-cyan-500 px-6 text-[13px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
            >
              <CatIcon name="refresh-cw" className="h-4 w-4" />
              {t("maintRefresh")}
            </Button>
            <a
              href="mailto:support@ashrilogic.com"
              className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-200 bg-white px-5 text-[13px] font-extrabold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
            >
              <CatIcon name="lifebuoy" className="h-4 w-4" />
              {t("maintSupport")}
            </a>
          </div>

          <p className="mt-4 flex items-center justify-center gap-1.5 text-[10.5px] font-semibold text-slate-500 dark:text-slate-400">
            <span className={`h-1.5 w-1.5 rounded-full ${beacon ? "bg-emerald-400" : "bg-slate-300 dark:bg-slate-600"} transition-colors`} aria-hidden="true" />
            {t("maintAutoCheck")}
          </p>
        </div>

        {/* footer line */}
        <p className="mt-5 text-center text-[11px] font-bold tracking-wide text-slate-500 dark:text-slate-400">
          {orgName} · Ashrilogic
        </p>
      </div>
    </main>
  );
}

/**
 * The shell-level gate: while the probe reports maintenance for THIS
 * visitor, the maintenance screen replaces the public shell. Refetches
 * automatically every minute (staleTime + the screen's retry button), so
 * flipping the toggle off recovers visitors without their interaction.
 */
export function MaintenanceGate({ children }: { children: React.ReactNode }) {
  const probe = useQuery({
    queryKey: MAINTENANCE_QUERY_KEY,
    queryFn: fetchMaintenanceState,
    /* refetch on window focus + every 60s — the site heals itself */
    staleTime: RECHECK_MS,
    refetchInterval: RECHECK_MS,
    retry: 1,
  });

  if (probe.data?.maintenance) {
    return <MaintenanceScreen />;
  }
  return <>{children}</>;
}
