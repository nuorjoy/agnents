import Link from "next/link";
import { t } from "@/lib/i18n";
import type { Lang } from "@/lib/types";
import { getCachedPlatformSettings } from "@/lib/server/platform-settings-cache";
import { CatIcon } from "@/components/icon";
import { SocialLinks } from "@/components/social-links";
import { SUPPORT_CHANNELS } from "@/lib/social";
import { PlatformBrandTile } from "@/components/shared/platform-brand";

/**
 * Ashrilogic — landing footer.
 *
 * ROUND 172c (RSC) — SERVER component with SERVER data: the former
 * useQuery(fetchSupportContact) + usePlatformWordmark() became one direct
 * server-side read of the PlatformSetting singleton (the same row GET
 * /api/support and GET /api/identity serve), resolving the contact channels
 * and the platform wordmark BEFORE render — fail-soft to the very same
 * SUPPORT_CHANNELS / shipped-wordmark fallbacks the client path had, so the
 * footer never breaks when the settings row is unreadable. Text comes from
 * the pure t(lang, key).
 *
 * Client islands kept byte-identical: PlatformBrandTile (the logo swap on
 * the live identity feed) and SocialLinks (the dashboard-controlled social
 * row, which subscribes to /api/support itself).
 */

/** The shipped Latin wordmark — the value usePlatformWordmark() falls back
 *  to (the feed's default siteNameEn; defined locally because the client
 *  module's const is a client reference, not importable server-side). */
const PLATFORM_WORDMARK = "Ashrilogic";

const YEAR = new Date().getFullYear();

interface FooterCol {
  title: string;
  links: { href: string; label: string }[];
}

const SYSTEM_LINKS_KEYS = ["footerHealth", "footerEducation", "footerRetail", "footerHospitality"] as const;

/** One server-side read of the PlatformSetting singleton feeding both the
 *  contact channels (mirroring GET /api/support's core — same row, same
 *  fail-soft defaults) and the wordmark (mirroring GET /api/identity's
 *  siteNameEn resolution). Render stays read-only: the canonical row
 *  seeding belongs to the API routes / admin flows, so a missing row simply
 *  falls back to the shipped defaults. */
async function resolveFooterSettings(): Promise<{
  wordmark: string;
  supportEmail: string;
  supportPhone: string;
}> {
  try {
    const row = await getCachedPlatformSettings();
    return {
      wordmark: row?.siteNameEn || PLATFORM_WORDMARK,
      /* contact channels mirror the control-panel Settings state (fail-soft
       * to the same SUPPORT_CHANNELS defaults the client path used) */
      supportEmail: row?.supportEmail ?? SUPPORT_CHANNELS.email,
      supportPhone: row?.supportPhone ?? SUPPORT_CHANNELS.phone,
    };
  } catch (error) {
    console.error("LandingFooter settings read failed:", error);
    return {
      wordmark: PLATFORM_WORDMARK,
      supportEmail: SUPPORT_CHANNELS.email,
      supportPhone: SUPPORT_CHANNELS.phone,
    };
  }
}

export async function LandingFooter({ lang }: { lang: Lang }) {
  const { wordmark, supportEmail, supportPhone } = await resolveFooterSettings();

  const systemCol: FooterCol = {
    title: t(lang, "footerSystems"),
    links: SYSTEM_LINKS_KEYS.map((key) => ({ href: "/#systems", label: t(lang, key) })),
  };
  const platformCol: FooterCol = {
    title: t(lang, "footerPlatform"),
    links: [
      { href: "/#support", label: t(lang, "footerSupport") },
      { href: "/#features", label: t(lang, "navFeatures") },
      { href: "/#sectors", label: t(lang, "navSectors") },
      { href: "/#systems", label: t(lang, "footerLibrary") },
      /* ROUND 117 — the platform legal pages (console-editable) */
      { href: "/privacy", label: t(lang, "footerPrivacy") },
      { href: "/terms", label: t(lang, "footerTerms") },
    ],
  };

  const contactItems = [
    { icon: "mail", value: supportEmail, href: `mailto:${supportEmail}` },
    { icon: "phone", value: supportPhone, href: `tel:${supportPhone.replace(/\s+/g, "")}` },
    { icon: "map-pin", value: t(lang, "footerRemote") },
  ];

  return (
    <footer className="safe-bottom mt-auto border-t border-slate-200/70 bg-white/70 backdrop-blur-sm dark:border-white/[0.07] dark:bg-white/[0.02]">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          {/* Brand + social */}
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="flex items-center gap-2.5">
              <PlatformBrandTile
                variant="main"
                className="h-10 w-10 rounded-xl shadow-brand-500/25"
                fallback={
                  <span className="grid h-10 w-10 place-items-center rounded-xl bg-linear-to-br from-brand-500 via-fuchsia-500 to-cyan-400 text-white shadow-lg shadow-brand-500/25">
                    <CatIcon name="boxes" className="h-[15px] w-[15px]" />
                  </span>
                }
              />
              <span className="font-display text-[17px] font-extrabold">
                <span className="text-gradient">{wordmark}</span>
              </span>
            </div>
            <p className="mt-4 max-w-xs text-[13px] leading-relaxed text-slate-600 dark:text-slate-400">
              {t(lang, "footerDesc")}
            </p>
            <div className="mt-5">
              <p className="mb-2.5 text-[11px] font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                {t(lang, "footerFollowUs")}
              </p>
              <SocialLinks variant="compact" />
            </div>
          </div>

          {/* Systems */}
          <div>
            <h4 className="text-[12px] font-extrabold uppercase tracking-wider text-slate-900 dark:text-white">
              {systemCol.title}
            </h4>
            <ul className="mt-4 space-y-2.5 text-[13px] text-slate-600 dark:text-slate-400">
              {systemCol.links.map((link) => (
                <li key={link.label}>
                  <Link href={link.href} prefetch={false} className="transition hover:text-brand-600 dark:hover:text-brand-300">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Platform */}
          <div>
            <h4 className="text-[12px] font-extrabold uppercase tracking-wider text-slate-900 dark:text-white">
              {platformCol.title}
            </h4>
            <ul className="mt-4 space-y-2.5 text-[13px] text-slate-600 dark:text-slate-400">
              {platformCol.links.map((link) => (
                <li key={link.label}>
                  <Link href={link.href} prefetch={false} className="transition hover:text-brand-600 dark:hover:text-brand-300">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-[12px] font-extrabold uppercase tracking-wider text-slate-900 dark:text-white">
              {t(lang, "footerContact")}
            </h4>
            <ul className="mt-4 space-y-2.5 text-[13px] text-slate-600 dark:text-slate-400">
              {contactItems.map((item) => (
                <li key={item.icon} className="flex items-center gap-2">
                  <CatIcon name={item.icon} className="h-4 w-4 shrink-0 text-brand-500" />
                  {item.href ? (
                    <a
                      href={item.href}
                      className="transition hover:text-brand-600 dark:hover:text-brand-300"
                      dir="ltr"
                    >
                      {item.value}
                    </a>
                  ) : (
                    <span>{item.value}</span>
                  )}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Trust & security strip — concise compliance signals surfaced as
            icon chips. Reinforces the platform's security posture (CSP nonce,
            data encryption, passkey auth, tenant isolation) right above the
            copyright line, where visitors evaluating trust naturally land. */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-2 sm:justify-start">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white/60 px-3 py-1.5 text-[10.5px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-300">
            <CatIcon name="shield-check" className="h-[11px] w-[11px] text-emerald-500" />
            {t(lang, "trustCsp")}
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white/60 px-3 py-1.5 text-[10.5px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-300">
            <CatIcon name="database-backup" className="h-[11px] w-[11px] text-brand-500" />
            {t(lang, "trustEncrypt")}
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white/60 px-3 py-1.5 text-[10.5px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-300">
            <CatIcon name="key-round" className="h-[11px] w-[11px] text-fuchsia-500" />
            {t(lang, "trustPasskey")}
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white/60 px-3 py-1.5 text-[10.5px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-300">
            <CatIcon name="shield-user" className="h-[11px] w-[11px] text-cyan-500" />
            {t(lang, "trustIsolation")}
          </span>
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-3 border-t border-slate-200 pt-6 text-center dark:border-white/10 sm:flex-row sm:text-start">
          <p className="text-[12px] text-slate-500 dark:text-slate-400">
            © {YEAR} {wordmark} — {t(lang, "footerRights")}
          </p>
          {/* ROUND 55 — the crafted-with-love credit: heart icon in a soft
              rose→fuchsia gradient, brand-colored team name */}
          <p className="inline-flex items-center gap-1.5 text-[12px] font-semibold text-slate-500 dark:text-slate-400">
            <span
              className="grid h-4.5 w-4.5 place-items-center rounded-full text-white shadow-sm"
              style={{ backgroundImage: "linear-gradient(135deg,#f43f5e,#d946ef)" }}
              aria-hidden="true"
            >
              <CatIcon name="heart" className="h-[10px] w-[10px]" />
            </span>
            <span>{t(lang, "footerMade")}</span>
          </p>
        </div>
      </div>
    </footer>
  );
}

export default LandingFooter;
