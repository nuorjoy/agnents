"use client";

/**
 * Ashrilogic — keyboard shortcuts help dialog.
 *
 * Opens with the `?` key (Shift+/) or a header button. Lists every global
 * shortcut in a premium glass dialog with styled <kbd> chips. Auto-closes on
 * Escape (handled by the Dialog primitive) and on route-level view changes.
 *
 * R182 — CONTEXTUAL section: page-scoped shortcuts ("/" search on the blog
 * + systems library, ←/→ article navigation) now have a dedicated group
 * here so the dialog stays the single canonical reference; the in-context
 * kbd hints (search band chip, prev/next cards) remain the discoverability
 * surface — this section tells the rest of the story.
 */
import { useCallback, useEffect, useState } from "react";
import { useT } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import { CatIcon } from "@/components/icon";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface Shortcut {
  actionKey:
    | "kbSearch"
    | "kbLang"
    | "kbTheme"
    | "kbEsc"
    | "kbTop"
    | "kbHelp"
    | "kbCtxSearch"
    | "kbCtxArticleNav";
  keys: string[];
  icon: string;
  c1: string;
  c2: string;
  /** "combo" joins keys with + (pressed together); "either" shows
   *  alternative keys side by side (either one works — ←/→). */
  join?: "combo" | "either";
}

const SHORTCUTS: Shortcut[] = [
  { actionKey: "kbSearch", keys: ["Ctrl", "K"], icon: "search", c1: "#6d5dfb", c2: "#8b5cf6" },
  { actionKey: "kbLang", keys: ["Alt", "L"], icon: "globe", c1: "#06b6d4", c2: "#0ea5e9" },
  { actionKey: "kbTheme", keys: ["Alt", "T"], icon: "moon-star", c1: "#f59e0b", c2: "#f97316" },
  { actionKey: "kbTop", keys: ["Alt", "↑"], icon: "arrow-up", c1: "#10b981", c2: "#059669" },
  { actionKey: "kbEsc", keys: ["Esc"], icon: "x", c1: "#64748b", c2: "#475569" },
  { actionKey: "kbHelp", keys: ["?"], icon: "help-circle", c1: "#ec4899", c2: "#db2777" },
];

/* R182 — page-scoped shortcuts. The arrows' meaning mirrors the page
 * direction (RTL: → prev / ← next; LTR flipped) exactly like the on-card
 * kbd hints — the label stays direction-neutral ("previous/next"). */
const CONTEXTUAL: Shortcut[] = [
  { actionKey: "kbCtxSearch", keys: ["/"], icon: "search", c1: "#8b5cf6", c2: "#a855f7" },
  { actionKey: "kbCtxArticleNav", keys: ["←", "→"], icon: "book-open", c1: "#0ea5e9", c2: "#06b6d4", join: "either" },
];

/** Global state so the header button can open the dialog. */
let openFn: ((open: boolean) => void) | null = null;
export function openShortcutsHelp() {
  openFn?.(true);
}

function Kbd({ children }: { children: React.ReactNode }) {
  return (
    <kbd className="kbd inline-flex min-w-[28px] items-center justify-center gap-0.5 rounded-md border border-slate-300 bg-white px-1.5 py-0.5 text-[11px] font-extrabold text-slate-700 shadow-sm dark:border-white/15 dark:bg-white/10 dark:text-slate-200">
      {children}
    </kbd>
  );
}

/** One shortcut row — extracted in R182 so the global and contextual lists
 *  share the exact same markup. `join: "either"` renders alternative keys
 *  with a neutral · separator (either key works) instead of the combo "+". */
function ShortcutRow({ sc }: { sc: Shortcut }) {
  const { t } = useT();
  const either = sc.join === "either";
  return (
    <li className="flex items-center justify-between gap-3 rounded-xl px-4 py-2.5 transition-colors hover:bg-slate-50 dark:hover:bg-white/[0.04]">
      <span className="flex items-center gap-3">
        <span
          className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white shadow-sm"
          style={{ backgroundImage: `linear-gradient(135deg,${sc.c1},${sc.c2})` }}
          aria-hidden="true"
        >
          <CatIcon name={sc.icon} className="h-[12px] w-[12px]" />
        </span>
        <span className="text-[13px] font-bold text-slate-700 dark:text-slate-200">
          {t(sc.actionKey)}
        </span>
      </span>
      <span className="flex items-center gap-1" dir="ltr" aria-label={either ? t(sc.actionKey) : undefined}>
        {sc.keys.map((k, i) => (
          <span key={k} className="flex items-center gap-1">
            {i > 0 ? (
              <span className="text-[10px] font-bold text-slate-300 dark:text-slate-600">
                {either ? "·" : "+"}
              </span>
            ) : null}
            <Kbd>{k}</Kbd>
          </span>
        ))}
      </span>
    </li>
  );
}

export function KeyboardShortcutsHelp() {
  const { t } = useT();
  const view = useAppStore((s) => s.view);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    openFn = setOpen;
    return () => {
      openFn = null;
    };
  }, []);

  const onKey = useCallback((e: KeyboardEvent) => {
    // `?` (Shift+/) opens; ignore when typing in an input/textarea
    const tag = (e.target as HTMLElement)?.tagName;
    if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
    if (e.key === "?" && e.shiftKey) {
      e.preventDefault();
      setOpen((v) => !v);
    }
  }, []);

  useEffect(() => {
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onKey]);

  // The dialog is only relevant on the landing view; auto-close when leaving.
  const isOpen = open && view === "landing";
  const handleOpenChange = (next: boolean) => {
    if (view === "landing") setOpen(next);
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-md gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-lg">
        <DialogHeader className="border-b border-slate-200/70 bg-slate-50/80 px-6 py-5 dark:border-white/10 dark:bg-white/[0.03]">
          <DialogTitle className="flex items-center gap-2.5 font-display text-[17px] font-extrabold">
            <span
              className="grid h-9 w-9 place-items-center rounded-xl text-white shadow-lg"
              style={{ backgroundImage: "linear-gradient(135deg,#6d5dfb,#d946ef)" }}
              aria-hidden="true"
            >
              <CatIcon name="command" className="h-[14px] w-[14px]" />
            </span>
            {t("kbHelpTitle")}
          </DialogTitle>
          <DialogDescription className="text-[12.5px]">{t("kbHelpDesc")}</DialogDescription>
        </DialogHeader>

        <div className="px-2 py-2">
          <div className="grid grid-cols-[1fr_auto] gap-2 px-4 py-2 text-[10px] font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            <span>{t("kbHelpAction")}</span>
            <span>{t("kbHelpKey")}</span>
          </div>
          <ul className="space-y-0.5">
            {SHORTCUTS.map((sc) => (
              <ShortcutRow key={sc.actionKey} sc={sc} />
            ))}
          </ul>

          {/* R182 — contextual (page-scoped) shortcuts */}
          <div className="mt-3 border-t border-slate-200/70 px-4 pt-3 pb-1 dark:border-white/10">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              {t("kbCtxSection")}
            </span>
          </div>
          <ul className="space-y-0.5">
            {CONTEXTUAL.map((sc) => (
              <ShortcutRow key={sc.actionKey} sc={sc} />
            ))}
          </ul>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default KeyboardShortcutsHelp;
