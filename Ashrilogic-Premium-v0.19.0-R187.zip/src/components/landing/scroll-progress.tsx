"use client";

import { useEffect, useState, type RefObject } from "react";

/**
 * Ashrilogic — scroll progress bar.
 *
 * A 3px fixed gradient bar (brand → fuchsia → cyan) pinned to the very top of
 * the viewport, showing how far the page has been scrolled. Anchored to the
 * inline-start edge so it grows right-to-left under RTL. The scroll listener
 * is rAF-throttled and passive.
 *
 * ROUND 179 — optional ARTICLE-SCOPED measurement (`targetRef`): the blog
 * reader passes the <article> element so the bar measures READING progress
 * (100% exactly when the viewport bottom passes the article's end) instead
 * of raw page progress (which only tops out below the newsletter CTA and
 * the footer). Formula: (viewportBottom − articleTop) / articleHeight,
 * clamped to 0..1 — 0 while the article is still below the fold, 1 the
 * moment reading finishes, footer scroll keeps it pinned at 1. Surfaces
 * without a target keep the classic page-scoped behavior. The element is
 * read inside every update (not captured), so late-mounting targets are
 * picked up by the next scroll/resize tick; on the article route the
 * component mounts in the same commit as the target, so the initial
 * update already sees it.
 */
export function ScrollProgress({ targetRef }: { targetRef?: RefObject<HTMLElement | null> }) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    let raf = 0;
    const update = () => {
      const doc = document.documentElement;
      const el = targetRef?.current ?? null;
      let ratio: number;
      if (el) {
        const rect = el.getBoundingClientRect();
        ratio = rect.height > 0 ? (doc.clientHeight - rect.top) / rect.height : 0;
      } else {
        const max = doc.scrollHeight - doc.clientHeight;
        ratio = max > 0 ? doc.scrollTop / max : 0;
      }
      setProgress(Math.min(1, Math.max(0, ratio)));
    };
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, [targetRef]);

  return (
    <div
      aria-hidden="true"
      className="pointer-events-none fixed inset-x-0 top-0 z-[60] h-[3px]"
    >
      <div
        className="absolute inset-y-0 start-0 h-full rounded-e-full bg-linear-to-r from-brand-500 via-fuchsia-500 to-cyan-400"
        style={{ width: `${progress * 100}%` }}
      />
    </div>
  );
}

export default ScrollProgress;
