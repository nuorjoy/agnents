/**
 * Ashrilogic — final CTA banner.
 *
 * A premium gradient panel placed just before the footer as a last
 * conversion push. Dark gradient background with decorative glow orbs,
 * a badge, gradient headline, description and two CTAs (primary → systems,
 * outline → download/contact). Fully responsive + dark-mode aware.
 *
 * ROUND 172d (RSC) — SERVER component: purely presentational (no state, no
 * handlers — the CTAs are plain anchors), so the whole band renders with
 * ZERO hydration. Text resolves through the pure t(lang, ·) with the
 * visitor's cookie language; the Reveal wrapper stays a client island
 * (server children render through it). The bilingual inline copy reads the
 * lang prop instead of the store.
 */
import Link from "next/link";
import { t } from "@/lib/i18n";
import type { Lang } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { Reveal } from "@/components/landing/reveal";

export function CtaBannerSection({ lang }: { lang: Lang }) {
  return (
    <section id="cta" className="scroll-mt-20 px-4 py-16 sm:px-6 lg:px-8 lg:py-20">
      <div className="mx-auto max-w-5xl">
        <Reveal>
          <div className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-linear-to-br from-[#0b1020] via-[#1a103a] to-[#05080f] p-8 shadow-2xl sm:p-12 lg:p-16">
            {/* decorative glow orbs */}
            <div
              className="pointer-events-none absolute -end-20 -top-20 h-72 w-72 rounded-full bg-brand-500/30 blur-3xl"
              aria-hidden="true"
            />
            <div
              className="pointer-events-none absolute -bottom-24 -start-20 h-72 w-72 rounded-full bg-cyan-400/20 blur-3xl"
              aria-hidden="true"
            />
            <div
              className="pointer-events-none absolute end-1/3 top-1/2 h-48 w-48 rounded-full bg-fuchsia-500/20 blur-3xl"
              aria-hidden="true"
            />

            {/* grid overlay */}
            <div
              className="pointer-events-none absolute inset-0 opacity-[0.07]"
              style={{
                backgroundImage:
                  "linear-gradient(rgba(255,255,255,0.4) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.4) 1px, transparent 1px)",
                backgroundSize: "32px 32px",
              }}
              aria-hidden="true"
            />

            {/* shimmer sweep — one soft light band glides across the panel
                periodically (the global `shimmer` keyframes already used by
                the tech strip). Adds subtle motion/life to the conversion
                surface without any new content. Paused under
                prefers-reduced-motion (motion-reduce:hidden). */}
            <div
              className="pointer-events-none absolute inset-0 z-10 animate-[shimmer_9s_linear_infinite] bg-linear-to-r from-transparent via-white/10 to-transparent bg-[length:200%_100%] motion-reduce:hidden"
              aria-hidden="true"
            />

            <div className="relative text-center">
              {/* badge */}
              <span className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-1.5 text-[11px] font-bold text-white backdrop-blur-sm">
                <span className="relative flex h-1.5 w-1.5">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-cyan-300 opacity-75" />
                  <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-cyan-300" />
                </span>
                {t(lang, "ctaBadge")}
              </span>

              {/* headline */}
              <h2 className="mx-auto mt-6 max-w-2xl font-display text-[26px] font-extrabold leading-tight tracking-tight text-white sm:text-4xl lg:text-[42px]">
                {t(lang, "ctaTitle")}
              </h2>

              {/* description */}
              <p className="mx-auto mt-4 max-w-xl text-[14px] leading-relaxed text-slate-300 sm:text-[15px]">
                {t(lang, "ctaDesc")}
              </p>

              {/* CTAs */}
              <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
                <Link
                  href="/#systems"
                  className="inline-flex items-center gap-2.5 rounded-2xl bg-linear-to-l from-brand-500 via-fuchsia-500 to-cyan-400 px-6 py-3.5 text-sm font-bold text-white shadow-xl shadow-brand-500/40 transition hover:shadow-brand-500/60 hover:brightness-110 active:scale-95"
                >
                  <CatIcon name="rocket" className="h-4 w-4" />
                  <span>{t(lang, "ctaBtn1")}</span>
                </Link>
                <Link
                  href="/#systems"
                  className="inline-flex items-center gap-2.5 rounded-2xl border border-white/20 bg-white/10 px-6 py-3.5 text-sm font-bold text-white backdrop-blur-sm transition hover:border-white/40 hover:bg-white/20 active:scale-95"
                >
                  <CatIcon name="mail" className="h-4 w-4" />
                  <span>{t(lang, "ctaBtn2")}</span>
                </Link>
              </div>

              {/* mini stats */}
              <div className="mt-10 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-[11px] font-bold text-slate-400">
                <span className="flex items-center gap-1.5">
                  <CatIcon name="circle-check" className="h-3.5 w-3.5 text-emerald-400" />
                  {lang === "ar" ? "إعداد في 7 خطوات" : "Setup in 7 steps"}
                </span>
                <span className="flex items-center gap-1.5">
                  <CatIcon name="circle-check" className="h-3.5 w-3.5 text-emerald-400" />
                  {lang === "ar" ? "دعم متعدد اللغات" : "Multilingual support"}
                </span>
                <span className="flex items-center gap-1.5">
                  <CatIcon name="circle-check" className="h-3.5 w-3.5 text-emerald-400" />
                  {lang === "ar" ? "دعم 24/7" : "24/7 support"}
                </span>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export default CtaBannerSection;
