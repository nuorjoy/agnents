"use client";

/**
 * Ashrilogic — ROUND 175 — the article Table of Contents (TOC).
 *
 * A premium reading-navigation affordance for /blog/[slug]:
 *
 *  - xl screens: a sticky rail anchored in the END margin beside the
 *    `max-w-3xl` article (logical `end` — right in LTR, left in RTL, so the
 *    rail never crowds the reading start edge). The rail is an absolutely
 *    positioned full-height track with a `sticky` child — the classic
 *    "absolute rail + sticky child" pattern that keeps the article's exact
 *    existing centering untouched (no grid re-layout, zero visual shift).
 *  - below xl: a collapsible "On this page" card above the body (native
 *    <button> + conditional panel — same disclosure pattern the platform
 *    uses elsewhere).
 *
 * Headings are discovered from the RENDERED article body (#blog-body h2/h3 —
 * the markdown renderer emits stable per-document anchor ids, ROUND 175), so
 * the TOC always mirrors the real DOM. Scroll-spy highlights the section the
 * reader is currently in (passive scroll listener; the active heading is the
 * last one above a 120px viewport line — robust across RTL/LTR because it
 * works on vertical geometry only).
 *
 * a11y: the rail is a <nav aria-label> landmark; entries are real buttons
 * with aria-current="location" on the active section; clicking scrolls with
 * `prefers-reduced-motion` respected. Renders nothing when the article has
 * fewer than 3 headings (a TOC of 1–2 entries is noise, not navigation).
 */
import { useEffect, useState, type RefObject } from "react";
import { useT, type I18nKey } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { cn } from "@/lib/utils";

interface TocEntry {
  id: string;
  text: string;
  level: 2 | 3;
}

/** Minimum heading count before a TOC is worth rendering. */
const MIN_HEADINGS = 3;

/** Viewport line (px from the top) a heading must cross to become active —
 *  clears the fixed header band so the highlighted entry tracks what the
 *  reader actually sees. */
const SPY_LINE = 120;

function scrollToId(id: string): void {
  const el = document.getElementById(id);
  if (!el) return;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  el.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" });
}

/* ------------------------------------------------ the TOC list ------ */

function TocList({
  entries,
  activeId,
  onJump,
  label,
}: {
  entries: TocEntry[];
  activeId: string | null;
  onJump: (id: string) => void;
  label: (key: I18nKey) => string;
}) {
  return (
    <ol className="space-y-0.5" role="list">
      {entries.map((entry) => {
        const isActive = entry.id === activeId;
        return (
          <li key={entry.id} role="listitem">
            <button
              type="button"
              onClick={() => onJump(entry.id)}
              aria-current={isActive ? "location" : undefined}
              className={cn(
                "group/toc relative flex w-full cursor-pointer items-start gap-2 rounded-lg py-1.5 text-start outline-none transition-all duration-200 focus-visible:ring-4 focus-visible:ring-brand-500/20",
                entry.level === 3 ? "ps-4" : "ps-1"
              )}
            >
              {/* active indicator bar */}
              <span
                aria-hidden="true"
                className={cn(
                  "absolute start-0 top-1/2 h-4 w-0.5 -translate-y-1/2 rounded-full bg-linear-to-b from-brand-500 to-fuchsia-500 transition-all duration-200",
                  isActive ? "opacity-100 scale-y-100" : "opacity-0 scale-y-0"
                )}
              />
              <span
                className={cn(
                  "line-clamp-2 text-[11.5px] font-bold leading-snug transition-colors duration-200",
                  isActive
                    ? "text-brand-600 dark:text-brand-300"
                    : "text-slate-500 group-hover/toc:text-slate-800 dark:text-slate-400 dark:group-hover/toc:text-slate-200"
                )}
              >
                {entry.text}
              </span>
            </button>
          </li>
        );
      })}
    </ol>
  );
}

/* ------------------------------------------------ the component ----- */

export function BlogToc({ bodyRef }: { bodyRef: RefObject<HTMLElement | null> }) {
  const { t } = useT();
  const [entries, setEntries] = useState<TocEntry[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [open, setOpen] = useState(false);

  /* discover headings from the rendered body (re-runs when the ref'd element
   * changes its content — the effect depends on the element itself, which
   * React re-renders with a new body). ROUND 175: the discovery setState is
   * rAF-deferred — the same pattern the codebase already uses for
   * DOM-measuring effects (landing-scroll-chrome) so the React-Compiler
   * no-setState-in-effect rule stays green while behavior is preserved. */
  useEffect(() => {
    const body = bodyRef.current;
    if (!body) return;
    const raf = requestAnimationFrame(() => {
      const headings = Array.from(body.querySelectorAll<HTMLHeadingElement>("h2, h3"));
      const list: TocEntry[] = [];
      for (const h of headings) {
        const id = h.id;
        const text = h.textContent?.trim() ?? "";
        if (!id || !text) continue;
        list.push({ id, text, level: h.tagName === "H2" ? 2 : 3 });
      }
      setEntries(list);
      setActiveId(list.length > 0 ? list[0].id : null);
    });
    return () => cancelAnimationFrame(raf);
  }, [bodyRef]);

  /* scroll-spy — passive listener over the discovered entries. The initial
   * onScroll() sync call was removed: the discovery effect already seeds
   * activeId, and the first real scroll event (or the rAF-measured position
   * on mount below) corrects it — no cascading setState from the effect. */
  useEffect(() => {
    if (entries.length < MIN_HEADINGS) return;
    const onScroll = () => {
      let current: string | null = null;
      for (const entry of entries) {
        const el = document.getElementById(entry.id);
        if (!el) continue;
        if (el.getBoundingClientRect().top - SPY_LINE <= 0) current = entry.id;
      }
      /* past the LAST heading + a screen: un-highlight (finished reading) */
      const lastEl = document.getElementById(entries[entries.length - 1].id);
      if (
        current === entries[entries.length - 1].id &&
        lastEl &&
        lastEl.getBoundingClientRect().bottom < SPY_LINE
      ) {
        current = null;
      }
      setActiveId(current);
    };
    /* the initial position sync runs in the NEXT frame (async — keeps the
     * no-setState-in-effect contract; the discovery effect already seeded
     * a sensible initial activeId) */
    const raf = requestAnimationFrame(onScroll);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("scroll", onScroll);
    };
  }, [entries]);

  if (entries.length < MIN_HEADINGS) return null;

  const jump = (id: string) => {
    scrollToId(id);
    setOpen(false); /* collapse the mobile card after navigation */
  };

  return (
    <>
      {/* ---------- xl+ rail: absolute track in the end margin ---------- */}
      <div
        className="absolute bottom-0 end-[-264px] top-0 hidden w-60 print:hidden! xl:block"
        aria-hidden="false"
      >
        <nav
          aria-label={t("blogTocTitle")}
          className="sticky top-24 max-h-[calc(100vh-8rem)] overflow-y-auto rounded-2xl border border-slate-200/70 bg-white/70 p-4 shadow-soft backdrop-blur-sm dark:border-white/10 dark:bg-white/[0.03]"
        >
          <p className="flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            <CatIcon name="list" className="h-[12px] w-[12px] text-brand-500" />
            {t("blogTocTitle")}
          </p>
          <div className="mt-3">
            <TocList entries={entries} activeId={activeId} onJump={jump} label={t} />
          </div>
        </nav>
      </div>

      {/* ---------- <xl collapsible card above the body ---------- */}
      <div className="mb-8 print:hidden xl:hidden">
        <div className="rounded-2xl border border-slate-200/70 bg-white/70 shadow-soft backdrop-blur-sm dark:border-white/10 dark:bg-white/[0.03]">
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-controls="blog-toc-panel"
            className="flex w-full cursor-pointer items-center justify-between gap-3 px-4 py-3 outline-none focus-visible:ring-4 focus-visible:ring-brand-500/20"
          >
            <span className="flex items-center gap-2 text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
              <CatIcon name="list" className="h-[13px] w-[13px] text-brand-500" />
              {t("blogTocTitle")}
              <span className="rounded-full bg-brand-500/10 px-2 py-0.5 text-[10px] font-extrabold tabular-nums text-brand-600 dark:bg-brand-500/20 dark:text-brand-300">
                {entries.length}
              </span>
            </span>
            <CatIcon
              name="chevron-down"
              className={cn(
                "h-[14px] w-[14px] shrink-0 text-slate-400 transition-transform duration-300",
                open && "rotate-180"
              )}
            />
          </button>
          {open ? (
            <div id="blog-toc-panel" className="border-t border-slate-200/70 px-4 py-3 dark:border-white/10">
              <TocList entries={entries} activeId={activeId} onJump={jump} label={t} />
            </div>
          ) : null}
        </div>
      </div>
    </>
  );
}
