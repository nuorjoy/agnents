"use client";

/**
 * Ashrilogic — /blog/[slug]: the article reader.
 *
 * SSR-first (ROUND 173): the server route page pre-loads the published
 * article + related posts (the exact GET /api/blog/[slug] contract) and
 * passes them as initialData — the article body is in the first HTML for
 * crawlers and visitors. The useQuery below then revalidates through the
 * API after hydration (no staleTime — the query is stale on mount), which
 * is ALSO what preserves the view counter semantics: only a browser that
 * actually rendered the app bumps the read counter server-side (the API
 * route skips the bump for bot user agents), and the revalidation doubles
 * as a live content refresh. Renders the body through the SAFE markdown
 * renderer (src/lib/markdown.ts — HTML-escaped first, allow-listed tags
 * out; no raw HTML ever passes through). The reading direction follows the
 * post's locale: Arabic bodies render RTL, English bodies LTR, regardless
 * of the interface language. Share row + related posts + newsletter CTA.
 */
import { useEffect, useMemo, useRef, type ReactNode } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { useT } from "@/lib/i18n";
import type { BlogCardDTO, BlogPostDTO } from "@/lib/types";
import { fetchBlogPost } from "@/lib/api-client";
import { SITE_URL } from "@/lib/site-url";
import { dirFor } from "@/lib/locales";
import { renderMarkdown } from "@/lib/markdown";
import { CatIcon } from "@/components/icon";
import { Reveal } from "@/components/landing/reveal";
import { ShareRow } from "@/components/landing/share-row";
import { BlogToc } from "@/components/landing/blog/blog-toc";
import { LandingHeader } from "@/components/landing/landing-header";
import { ScrollProgress } from "@/components/landing/scroll-progress";
import { BackToTop } from "@/components/landing/back-to-top";
import { NewsletterForm } from "@/components/landing/newsletter-form";
import { useDocumentTitle } from "@/hooks/use-document-title";
import { cn, fmtNum, grad } from "@/lib/utils";

import "@/lib/i18n/fragments/app";
import { PrintStamp } from "@/components/landing/print-stamp";

/** Deterministic gradient palettes for the article hero (no uploaded cover). */
const HERO_PALETTES: [string, string, string][] = [
  ["#6d5dfb", "#d946ef", "sparkles"],
  ["#06b6d4", "#0ea5e9", "compass"],
  ["#f59e0b", "#f97316", "banknote"],
  ["#10b981", "#059669", "shield-check"],
  ["#ec4899", "#db2777", "heart-pulse"],
  ["#8b5cf6", "#7c3aed", "graduation-cap"],
];

function heroPalette(key: string): [string, string, string] {
  let hash = 0;
  for (let i = 0; i < key.length; i++) hash = (hash * 31 + key.charCodeAt(i)) >>> 0;
  return HERO_PALETTES[hash % HERO_PALETTES.length];
}

function fmtDate(iso: string | null, lang: string): string {
  if (!iso) return "";
  try {
    return new Intl.DateTimeFormat(lang === "ar" ? "ar" : lang === "hi" ? "hi" : "en", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }).format(new Date(iso));
  } catch {
    return iso.slice(0, 10);
  }
}

/* ------------------------------------------------ share row ---------- */

/* ROUND 181 — the share row moved to a SHARED component
 * (src/components/landing/share-row.tsx, extracted verbatim from the
 * ROUND 173/180 implementation) so the article reader and the system
 * detail pages render identical share/copy/print chrome. The call site
 * below passes the article labels; behavior is unchanged. */

/* ------------------------------------------------ article view ------- */

/* ROUND 172c (RSC) — the footer became a SERVER component, so it can no
 * longer be imported into this client view; the server route page now
 * renders it and passes the element down here (rendered in the exact same
 * slot across the loading / error / article branches).
 *
 * SSR-first data (ROUND 173): initialPost/initialRelated come from the
 * server render; the loading skeleton branch only paints when the server
 * could NOT pre-load (fail-open) — with initialData the article renders
 * in the first paint and the query silently revalidates afterwards. */
export function BlogPostView({
  slug,
  footer,
  initialPost,
  initialRelated,
  initialPrev,
  initialNext,
}: {
  slug: string;
  footer: ReactNode;
  initialPost?: BlogPostDTO;
  initialRelated?: BlogCardDTO[];
  /** ROUND 179 — chronological neighbours (SSR seeds so the prev/next
   *  band is in the first HTML for crawlers; the revalidation refresh). */
  initialPrev?: BlogCardDTO | null;
  initialNext?: BlogCardDTO | null;
}) {
  const { t, lang } = useT();
  /* ROUND 180 — UI direction (ar = RTL, en/hi = LTR): drives both the
   * ←/→ keyboard navigation contract and the kbd hints on the cards. */
  const isRtl = dirFor(lang) === "rtl";

  /* ROUND 175 — the TOC discovers h2/h3 anchors in the rendered body
   * through this ref (the renderer emits stable per-document ids).
   * ROUND 179 — articleRef scopes the ScrollProgress bar to READING
   * progress: 100% exactly when the viewport bottom passes the article's
   * end (not the page's end below the newsletter/footer). */
  const bodyRef = useRef<HTMLDivElement>(null);
  const articleRef = useRef<HTMLElement>(null);

  const postQuery = useQuery({
    queryKey: ["public-blog-post", slug],
    queryFn: () => fetchBlogPost(slug),
    retry: 1,
    initialData: initialPost
      ? {
          ...initialPost,
          related: initialRelated ?? [],
          prev: initialPrev ?? null,
          next: initialNext ?? null,
        }
      : undefined,
  });

  const post = postQuery.data;

  /* R183 — data-aware tab title (the R182 docTitleSystemDetail bug class):
   * the SSR metadata renders the SPECIFIC article title, but the old generic
   * hook call stomped every article's tab to "مقال · Ashrilogic" after
   * hydration (and the ROUND 35 MutationObserver guard re-asserted the
   * generic title against Next's per-article metadata). Now the hook
   * interpolates the REAL title — mirroring the SSR generateMetadata
   * contract (titleAr || titleEn, Arabic-script brand suffix) and preferring
   * the UI-language title when one exists. The generic key stays only as
   * the loading-window fallback (client-side prev/next navigation while the
   * new post refetches). */
  const postTitle = post
    ? lang === "en" && post.titleEn
      ? post.titleEn
      : post.titleAr || post.titleEn || "مقال"
    : null;
  useDocumentTitle(
    postTitle ? "docTitleBlogPostNamed" : "docTitleBlogPost",
    postTitle ? { title: postTitle } : undefined,
  );

  /* ROUND 180 — keyboard ←/→ article navigation (R179 rec a): step
   * through the chronological neighbours with the SAME direction contract
   * as the on-screen cards (RTL mirrors LTR via dirFor — ar flips the
   * meaning of the arrow keys like the card arrows flip). Guards:
   * suppressed while typing in any field, while any modifier is held
   * (shift+arrow selects text; ctrl/alt+arrow are browser/OS shortcuts),
   * and while any Radix dialog is open (command palette, quote dialog —
   * arrow keys belong to the overlay, not the page behind it).
   * Navigation rides the App Router client-side — byte-identical to
   * clicking the card Link (same RSC fetch + scroll-to-top contract). */
  const router = useRouter();
  const prevSlug = post?.prev?.slug ?? null;
  const nextSlug = post?.next?.slug ?? null;
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key !== "ArrowLeft" && e.key !== "ArrowRight") return;
      if (e.ctrlKey || e.metaKey || e.altKey || e.shiftKey) return;
      const el = e.target as HTMLElement | null;
      const tag = el?.tagName?.toLowerCase();
      if (tag === "input" || tag === "textarea" || tag === "select" || el?.isContentEditable) return;
      if (document.querySelector('[role="dialog"][data-state="open"]')) return;
      const wantNext = isRtl ? e.key === "ArrowLeft" : e.key === "ArrowRight";
      const target = wantNext ? nextSlug : prevSlug;
      if (!target) return;
      e.preventDefault();
      router.push(`/blog/${target}`);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [router, isRtl, prevSlug, nextSlug]);

  /* the body renders in ITS OWN locale direction: the Arabic body is always
   * RTL and the English body always LTR — independent of the UI language */
  const bodyLang: "ar" | "en" = lang === "en" && post && post.contentEn.trim().length > 0 ? "en" : "ar";
  const body = post ? (bodyLang === "ar" ? post.contentAr : post.contentEn) : "";
  const bodyHtml = useMemo(() => renderMarkdown(body), [body]);

  /* ROUND 180 — heading anchor links (the MDN/GitHub deep-link affordance):
   * each rendered h2/h3 (stable slug ids from ROUND 175) gains a small link
   * chip that appears on heading hover / own focus — see .prose-anchor in
   * globals.css (inline after the text on <sm, tucked into the inline-start
   * margin on sm+; hidden on paper). React owns #blog-body's innerHTML via
   * dangerouslySetInnerHTML: appending anchors AFTER the commit is safe, and
   * a bodyHtml change wipes + re-runs this effect, so the decoration always
   * matches the rendered article. */
  useEffect(() => {
    const root = bodyRef.current;
    if (!root) return;
    const headings = Array.from(root.querySelectorAll<HTMLHeadingElement>("h2[id], h3[id]"));
    const anchors: HTMLAnchorElement[] = [];
    for (const heading of headings) {
      const anchor = document.createElement("a");
      anchor.href = `#${heading.id}`;
      anchor.className = "prose-anchor";
      anchor.setAttribute("aria-label", `${heading.textContent ?? ""} — ${t("blogAnchorLink")}`);
      anchor.innerHTML =
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>';
      heading.appendChild(anchor);
      anchors.push(anchor);
    }
    return () => {
      for (const anchor of anchors) anchor.remove();
    };
  }, [bodyHtml, t]);

  if (postQuery.isLoading) {
    return (
      <div className="relative flex min-h-screen flex-col">
        <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden="true" />
        <LandingHeader />
        <main className="mx-auto w-full max-w-3xl flex-1 px-4 py-16 sm:px-6">
          <div className="h-72 animate-pulse rounded-3xl" aria-hidden="true" />
          <div className="mt-8 h-8 w-3/4 animate-pulse rounded-xl" aria-hidden="true" />
          <div className="mt-4 h-4 w-full animate-pulse rounded-lg" aria-hidden="true" />
          <div className="mt-3 h-4 w-5/6 animate-pulse rounded-lg" aria-hidden="true" />
          <div className="mt-3 h-4 w-4/6 animate-pulse rounded-lg" aria-hidden="true" />
        </main>
        {footer}
      </div>
    );
  }

  /* no article to show (server pre-load failed AND the client fetch
   * failed/404): the not-found branch. A refetch FAILURE after a
   * successful load keeps the article on screen (stale beats broken) —
   * previously a network blip mid-read swapped the article for this
   * not-found page; with SSR initialData the branch only paints when
   * there is genuinely no post. */
  if (!post) {
    return (
      <div className="relative flex min-h-screen flex-col">
        <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden="true" />
        <LandingHeader />
        <main className="mx-auto flex w-full max-w-3xl flex-1 flex-col items-center justify-center px-4 py-24 text-center sm:px-6">
          <div className="grid h-20 w-20 place-items-center rounded-3xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
            <CatIcon name="circle-x" className="h-8 w-8" />
          </div>
          <h1 className="mt-5 font-display text-2xl font-extrabold">{t("sysDetailNotFound")}</h1>
          <p className="mt-2 max-w-sm text-[13px] text-slate-500 dark:text-slate-400">
            {t("sysDetailNotFoundDesc")}
          </p>
          <Link
            href="/blog"
            className="mt-6 inline-flex items-center gap-2 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-5 py-3 text-[13px] font-bold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
          >
            <CatIcon name="arrow-right" className="h-[11px] w-[11px] rtl:rotate-180" />
            {t("blogBack")}
          </Link>
        </main>
        {footer}
      </div>
    );
  }

  const title = lang === "ar" || !post.titleEn ? post.titleAr : post.titleEn;
  const excerpt = lang === "ar" || !post.excerptEn ? post.excerptAr : post.excerptEn;
  const [c1, c2, icon] = heroPalette(post.id);
  /* ROUND 173 — canonical share URL: `${SITE_URL}/blog/${slug}` on BOTH
   * server and client (the previous `typeof window` branch produced the
   * documented hydration attribute mismatch — server rendered a
   * hardcoded `https://ashrilogic.com/...` domain while the client
   * re-rendered `window.location.href` — and the hardcoded domain also
   * disagreed with the page's canonical metadata). Shares now always
   * carry the page's canonical URL, unifying the share/canonical domain
   * (SEO) and removing the mismatch deterministically. */
  const shareUrl = `${SITE_URL}/blog/${post.slug}`;

  return (
    <div className="relative flex min-h-screen flex-col">
      <div className="mesh pointer-events-none fixed inset-0 -z-10 print:hidden" aria-hidden="true" />
      {/* ROUND 176 — print: the article prints as ink only; every piece of
       * navigation chrome below drops out on paper via print:hidden. */}
      <div className="print:hidden">
        <LandingHeader />
      </div>
      <div className="print:hidden">
        <ScrollProgress targetRef={articleRef} />
        <BackToTop />
      </div>

      <main className="flex-1 px-4 py-10 sm:px-6 lg:px-8 lg:py-14 print:py-0">
        <article ref={articleRef} className="blog-print relative mx-auto max-w-3xl">
          {/* breadcrumb */}
          <Reveal>
            <nav aria-label="breadcrumb" className="flex items-center gap-2 text-[12px] font-bold text-slate-500 dark:text-slate-400">
              <Link href="/" className="transition hover:text-brand-600 dark:hover:text-brand-300">
                Ashrilogic
              </Link>
              <CatIcon name="arrow-right" className="h-[9px] w-[9px] rtl:rotate-180" aria-hidden="true" />
              <Link href="/blog" className="transition hover:text-brand-600 dark:hover:text-brand-300">
                {t("navBlog")}
              </Link>
              <CatIcon name="arrow-right" className="h-[9px] w-[9px] rtl:rotate-180" aria-hidden="true" />
              <span className="truncate text-slate-600 dark:text-slate-300">{title}</span>
            </nav>
          </Reveal>

          {/* hero */}
          <Reveal delay={0.05}>
            <header className="mt-6">
              {post.tags.length > 0 ? (
                <div className="flex flex-wrap gap-1.5">
                  {post.tags.map((tg) => (
                    <Link
                      key={tg}
                      href={`/blog?tag=${encodeURIComponent(tg)}`}
                      className="rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-[10.5px] font-bold text-slate-500 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-400 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
                    >
                      #{tg}
                    </Link>
                  ))}
                </div>
              ) : null}

              <h1 className="mt-4 font-display text-[26px] font-extrabold leading-tight tracking-tight text-slate-900 dark:text-white sm:text-4xl">
                {title}
              </h1>
              <p className="mt-4 text-[14px] leading-relaxed text-slate-500 dark:text-slate-400 sm:text-[15px]">
                {excerpt}
              </p>

              {/* meta row */}
              <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-y border-slate-200/70 py-4 dark:border-white/10">
                <div className="flex items-center gap-3">
                  <span
                    className="grid h-10 w-10 place-items-center rounded-2xl text-sm font-extrabold text-white shadow-lg"
                    style={{ backgroundImage: grad(c1, c2) }}
                    aria-hidden="true"
                  >
                    {(post.authorName || "A").trim().charAt(0).toUpperCase()}
                  </span>
                  <div className="leading-tight">
                    <p className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                      {t("blogBy")} {post.authorName}
                    </p>
                    <p className="mt-0.5 flex items-center gap-1.5 text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
                      <CatIcon name="calendar" className="h-[10px] w-[10px]" />
                      {fmtDate(post.publishedAt, lang)}
                      <span className="mx-0.5">·</span>
                      <CatIcon name="clock" className="h-[10px] w-[10px]" />
                      {fmtNum(post.readMinutes, lang)} {t("blogMinRead")}
                      <span className="mx-0.5">·</span>
                      <CatIcon name="eye" className="h-[10px] w-[10px]" />
                      {fmtNum(post.views, lang)} {t("blogViews")}
                    </p>
                  </div>
                </div>
                <ShareRow url={shareUrl} title={title} shareLabel={t("blogShare")} printLabel={t("blogPrint")} />
              </div>
            </header>
          </Reveal>

          {/* cover */}
          <Reveal delay={0.08}>
            <div className="relative mt-8 h-56 overflow-hidden rounded-3xl shadow-lift break-inside-avoid sm:h-72 lg:h-80 print:h-40 print:shadow-none">
              {post.coverImage ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={post.coverImage}
                  alt={title}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="relative h-full w-full" style={{ backgroundImage: grad(c1, c2, 135) }}>
                  <span className="pointer-events-none absolute inset-0 opacity-25" style={{ backgroundImage: "radial-gradient(520px circle at 30% 20%, rgba(255,255,255,0.9), transparent 60%)" }} aria-hidden="true" />
                  <span className="absolute bottom-5 end-5 grid h-14 w-14 place-items-center rounded-3xl bg-white/25 text-white backdrop-blur-sm" aria-hidden="true">
                    <CatIcon name={icon} className="h-6 w-6" />
                  </span>
                </div>
              )}
            </div>
          </Reveal>

          {/* ROUND 175 — table of contents: collapsible card above the body
           * (<xl) + sticky rail in the end margin (xl+). Renders nothing for
           * articles with fewer than 3 headings. */}
          <BlogToc bodyRef={bodyRef} />

          {/* body — rendered in the body's own locale direction */}
          <Reveal delay={0.1}>
            <div
              ref={bodyRef}
              id="blog-body"
              dir={bodyLang === "ar" ? "rtl" : "ltr"}
              lang={bodyLang}
              className={cn(
                "blog-prose mt-10",
                /* typography: a scoped allow-list of element styles (the
                   renderer only ever emits h2/h3/p/strong/code/a/ul/ol/li/
                   blockquote/hr — see src/lib/markdown.ts) */
                "text-[14.5px] leading-[1.9] text-slate-600 dark:text-slate-300",
                "[&_h2]:mt-10 [&_h2]:mb-4 [&_h2]:font-display [&_h2]:text-[20px] [&_h2]:font-extrabold [&_h2]:leading-snug [&_h2]:text-slate-900 dark:[&_h2]:text-white sm:[&_h2]:text-[22px]",
                "[&_h3]:mt-8 [&_h3]:mb-3 [&_h3]:font-display [&_h3]:text-[16.5px] [&_h3]:font-extrabold [&_h3]:text-slate-800 dark:[&_h3]:text-slate-100",
                /* ROUND 175 — anchor jumps (TOC clicks, #deep-links) land
                   BELOW the fixed landing header instead of underneath it */
                "[&_h2]:scroll-mt-28 [&_h3]:scroll-mt-28",
                "[&_h2]:before:bg-linear-to-r [&_h2]:before:from-brand-500 [&_h2]:before:to-fuchsia-500",
                "[&_p]:mt-4 [&_p]:mb-4",
                "[&_strong]:font-extrabold [&_strong]:text-slate-800 dark:[&_strong]:text-slate-100",
                "[&_code]:rounded-md [&_code]:bg-slate-100 [&_code]:px-1.5 [&_code]:py-0.5 [&_code]:font-mono [&_code]:text-[12.5px] [&_code]:text-brand-600 dark:[&_code]:bg-white/10 dark:[&_code]:text-brand-300",
                "[&_a]:font-bold [&_a]:text-brand-600 [&_a]:underline [&_a]:underline-offset-2 [&_a]:transition dark:[&_a]:text-brand-300 dark:[&_a]:hover:brightness-125",
                "[&_ul]:mt-4 [&_ul]:mb-4 [&_ul]:space-y-2 [&_ul]:ps-1",
                "[&_ol]:mt-4 [&_ol]:mb-4 [&_ol]:space-y-2 [&_ol]:list-decimal [&_ol]:ps-6",
                "[&_ul]:list-none",
                "[&_ul>li]:relative [&_ul>li]:ps-6",
                "[&_ul>li]:before:absolute [&_ul>li]:before:start-0 [&_ul>li]:before:top-[0.7em] [&_ul>li]:before:h-1.5 [&_ul>li]:before:w-1.5 [&_ul>li]:before:rounded-full [&_ul>li]:before:bg-brand-500",
                "[&_ol>li]:marker:font-bold [&_ol>li]:marker:text-brand-500",
                "[&_blockquote]:mt-6 [&_blockquote]:mb-6 [&_blockquote]:rounded-2xl [&_blockquote]:border-s-4 [&_blockquote]:border-brand-400 [&_blockquote]:bg-brand-500/[0.06] [&_blockquote]:p-4 [&_blockquote]:text-[13.5px] [&_blockquote]:font-semibold [&_blockquote]:leading-relaxed [&_blockquote]:text-slate-700 dark:[&_blockquote]:border-brand-500 dark:[&_blockquote]:bg-brand-500/10 dark:[&_blockquote]:text-slate-200",
                "[&_hr]:my-10 [&_hr]:h-px [&_hr]:border-0 [&_hr]:bg-linear-to-r [&_hr]:from-transparent [&_hr]:via-slate-300 [&_hr]:to-transparent dark:[&_hr]:via-white/20"
              )}
              dangerouslySetInnerHTML={{ __html: bodyHtml }}
            />
          </Reveal>

          {/* closing share + divider */}
          <Reveal delay={0.12}>
            <div className="mt-12 flex flex-wrap items-center justify-between gap-4 border-t border-slate-200/70 pt-6 print:hidden dark:border-white/10">
              <Link
                href="/blog"
                className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-[12.5px] font-extrabold text-slate-600 shadow-sm transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
              >
                <CatIcon name="arrow-right" className="h-[11px] w-[11px] rtl:rotate-180" />
                {t("blogBack")}
              </Link>
              <ShareRow url={shareUrl} title={title} shareLabel={t("blogShare")} printLabel={t("blogPrint")} />
            </div>
          </Reveal>

          {/* ROUND 179 — chronological prev/next reader navigation: the
           * closest OLDER and NEWER published posts as two lift cards
           * (missing neighbours collapse; the grid keeps the next card on
           * its own side). Paper drops it — links are worthless printed.
           * ROUND 180 — ←/→ also step through the neighbours (kbd hints on
           * the cards; the direction mirrors the UI, see the effect above). */}
          {post.prev || post.next ? (
            <nav
              className="mt-10 grid gap-4 sm:grid-cols-2 print:hidden"
              aria-label={`${t("blogPrev")} / ${t("blogNext")}`}
              aria-keyshortcuts="ArrowLeft ArrowRight"
            >
              {post.prev ? (
                <Link
                  href={`/blog/${post.prev.slug}`}
                  className="glass-card group flex min-h-[76px] flex-col justify-center gap-1.5 rounded-2xl p-4 outline-none transition-all duration-300 hover:-translate-y-1 hover:shadow-lift focus-visible:ring-4 focus-visible:ring-brand-500/20"
                >
                  <span className="flex items-center gap-1.5 text-[10.5px] font-extrabold uppercase tracking-wider text-slate-500 transition-colors group-hover:text-brand-600 dark:text-slate-400 dark:group-hover:text-brand-300">
                    <CatIcon name="arrow-right" className="h-[11px] w-[11px] ltr:rotate-180" />
                    {t("blogPrev")}
                    {/* ROUND 180 — which arrow key drives this card in the
                        CURRENT direction (mirrors with the UI like the icon) */}
                    <kbd className="kbd ms-0.5 hidden h-4 min-w-4 px-1 py-0 text-[9px] sm:inline-flex" aria-hidden="true">
                      {isRtl ? "→" : "←"}
                    </kbd>
                  </span>
                  <span className="line-clamp-2 text-[13px] font-extrabold leading-snug text-slate-800 transition-colors group-hover:text-brand-600 dark:text-slate-100 dark:group-hover:text-brand-300">
                    {lang === "ar" || !post.prev.titleEn ? post.prev.titleAr : post.prev.titleEn}
                  </span>
                  <span className="flex items-center gap-1.5 text-[10px] font-bold text-slate-500 dark:text-slate-400">
                    <CatIcon name="clock" className="h-[10px] w-[10px]" />
                    {fmtNum(post.prev.readMinutes, lang)} {t("blogMinRead")}
                  </span>
                </Link>
              ) : (
                <span className="hidden sm:block" aria-hidden="true" />
              )}
              {post.next ? (
                <Link
                  href={`/blog/${post.next.slug}`}
                  className="glass-card group flex min-h-[76px] flex-col items-end justify-center gap-1.5 rounded-2xl p-4 text-end outline-none transition-all duration-300 hover:-translate-y-1 hover:shadow-lift focus-visible:ring-4 focus-visible:ring-brand-500/20"
                >
                  <span className="flex items-center gap-1.5 text-[10.5px] font-extrabold uppercase tracking-wider text-slate-500 transition-colors group-hover:text-brand-600 dark:text-slate-400 dark:group-hover:text-brand-300">
                    {t("blogNext")}
                    <kbd className="kbd ms-0.5 hidden h-4 min-w-4 px-1 py-0 text-[9px] sm:inline-flex" aria-hidden="true">
                      {isRtl ? "←" : "→"}
                    </kbd>
                    <CatIcon name="arrow-right" className="h-[11px] w-[11px] ltr:rotate-0 rtl:rotate-180" />
                  </span>
                  <span className="line-clamp-2 text-[13px] font-extrabold leading-snug text-slate-800 transition-colors group-hover:text-brand-600 dark:text-slate-100 dark:group-hover:text-brand-300">
                    {lang === "ar" || !post.next.titleEn ? post.next.titleAr : post.next.titleEn}
                  </span>
                  <span className="flex items-center gap-1.5 text-[10px] font-bold text-slate-500 dark:text-slate-400">
                    <CatIcon name="clock" className="h-[10px] w-[10px]" />
                    {fmtNum(post.next.readMinutes, lang)} {t("blogMinRead")}
                  </span>
                </Link>
              ) : null}
            </nav>
          ) : null}

          {/* related posts — paper has no links worth printing */}
          {post.related.length > 0 ? (
            <section className="mt-14 print:hidden" aria-label={t("blogRelated")}>
              <h2 className="flex items-center gap-2.5 font-display text-xl font-extrabold text-slate-900 dark:text-white">
                <span className="grid h-8 w-8 place-items-center rounded-xl bg-linear-to-br from-brand-500 to-fuchsia-500 text-white shadow-md" aria-hidden="true">
                  <CatIcon name="link" className="h-[12px] w-[12px]" />
                </span>
                {t("blogRelated")}
              </h2>
              <div className="mt-6 grid gap-5 sm:grid-cols-3">
                {post.related.map((rel, i) => {
                  const relTitle = lang === "ar" || !rel.titleEn ? rel.titleAr : rel.titleEn;
                  const [rc1, rc2, ricon] = heroPalette(rel.id);
                  return (
                    <Reveal key={rel.id} delay={i * 0.06} className="h-full">
                      <Link
                        href={`/blog/${rel.slug}`}
                        className="glass-card group flex h-full flex-col overflow-hidden rounded-3xl transition-all duration-300 hover:-translate-y-1.5 hover:shadow-lift"
                      >
                        <div className="relative h-28 overflow-hidden">
                          {rel.coverImage ? (
                            // eslint-disable-next-line @next/next/no-img-element
                            <img src={rel.coverImage} alt={relTitle} loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                          ) : (
                            <div className="relative h-full w-full" style={{ backgroundImage: grad(rc1, rc2, 135) }}>
                              <span className="absolute bottom-2.5 end-2.5 grid h-8 w-8 place-items-center rounded-xl bg-white/25 text-white backdrop-blur-sm" aria-hidden="true">
                                <CatIcon name={ricon} className="h-[12px] w-[12px]" />
                              </span>
                            </div>
                          )}
                        </div>
                        <div className="flex flex-1 flex-col p-4">
                          <h3 className="font-display text-[13.5px] font-extrabold leading-snug text-slate-900 transition-colors group-hover:text-brand-600 dark:text-white dark:group-hover:text-brand-300">
                            {relTitle}
                          </h3>
                          <span className="mt-auto flex items-center gap-1.5 pt-3 text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
                            <CatIcon name="clock" className="h-[10px] w-[10px]" />
                            {fmtNum(rel.readMinutes, lang)} {t("blogMinRead")}
                          </span>
                        </div>
                      </Link>
                    </Reveal>
                  );
                })}
              </div>
            </section>
          ) : null}

          {/* newsletter CTA */}
          <Reveal delay={0.1}>
            <section className="mt-14 print:hidden">
              <div className="grid items-center gap-5 rounded-3xl border border-slate-200/70 bg-linear-to-r from-brand-600/5 via-fuchsia-500/5 to-cyan-400/5 p-5 sm:grid-cols-2 sm:p-6 dark:border-white/10">
                <div>
                  <h4 className="flex items-center gap-2 font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                    <span className="grid h-7 w-7 place-items-center rounded-lg bg-linear-to-br from-brand-500 to-fuchsia-500 text-white">
                      <CatIcon name="send" className="h-[12px] w-[12px]" />
                    </span>
                    {t("blogCtaTitle")}
                  </h4>
                  <p className="mt-1.5 text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
                    {t("blogCtaDesc")}
                  </p>
                </div>
                <NewsletterForm />
              </div>
            </section>
          </Reveal>
          {/* R182 — print provenance inside the .blog-print ink scope. */}
          <PrintStamp />
        </article>
      </main>

      <div className="print:hidden">{footer}</div>
    </div>
  );
}

export default BlogPostView;
