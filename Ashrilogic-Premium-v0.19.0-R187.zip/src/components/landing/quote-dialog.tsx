"use client";

/**
 * ROUND 167 — the Enterprise quote dialog («اطلب عرض سعر مخصص») opened from
 * the landing pricing section's Enterprise card (custom pricing — no
 * checkout price, a quote request instead).
 *
 * Bilingual (AR default / EN / HI via the typed dictionary), RTL/LTR aware.
 * Fields: name · email (the shared PremiumEmailInput — live verdict +
 * international keyboard tolerance) · company (optional) · team-size band
 * (premium chip radio, Arabic-Indic labels) · systems count (1..500
 * stepper) · notes (≤1000 chars, live counter).
 *
 * Submit → POST /api/enterprise-quotes (rate-limited public route; the
 * email is SEALED server-side with a blind index). The duplicate arm — an
 * ACTIVE quote (new/contacted/quoted) with the same address — answers
 * { alreadySubmitted: true } and renders its own calm confirmation instead
 * of an error. Fresh success: «سيتواصل معك فريق المؤسسات خلال ٢٤ ساعة».
 */
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { submitEnterpriseQuote } from "@/lib/api-client";
import { QUOTE_TEAM_SIZES, type QuoteTeamSize } from "@/lib/types";
import { useT, type I18nKey } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad } from "@/lib/utils";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { PremiumEmailInput } from "@/components/ui/premium-contact";

/** Client-side UX gate for the submit button (the server validates
 *  authoritatively — this only keeps the button honest). */
const EMAIL_RE = /^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?)+$/;

const TEAM_LABEL_KEYS: Record<QuoteTeamSize, I18nKey> = {
  "1-10": "qdTeam1",
  "11-50": "qdTeam2",
  "51-200": "qdTeam3",
  "201-1000": "qdTeam4",
  "1000+": "qdTeam5",
};

const NOTES_MAX = 1000;

export function QuoteDialog({
  open,
  onOpenChange,
  defaultSystems = 1,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** prefill from the smart advisor's systems input (a head start, editable) */
  defaultSystems?: number;
}) {
  const { t, lang } = useT();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [company, setCompany] = useState("");
  const [teamSize, setTeamSize] = useState<QuoteTeamSize>("1-10");
  const [systems, setSystems] = useState(String(Math.min(500, Math.max(1, defaultSystems))));
  const [notes, setNotes] = useState("");
  const [attempted, setAttempted] = useState(false);
  /** the terminal view: fresh success | duplicate success */
  const [done, setDone] = useState<"created" | "duplicate" | null>(null);

  const systemsNum = Number(systems);
  const systemsValid =
    systems.trim() !== "" && Number.isInteger(systemsNum) && systemsNum >= 1 && systemsNum <= 500;
  const nameValid = name.trim().length >= 2;
  const emailValid = EMAIL_RE.test(email.trim());
  const canSubmit = nameValid && emailValid && systemsValid && notes.length <= NOTES_MAX;

  const submit = useMutation({
    mutationFn: () =>
      submitEnterpriseQuote({
        name: name.trim(),
        email: email.trim().toLowerCase(),
        company: company.trim() || undefined,
        teamSize,
        systemsCount: systemsNum,
        notes: notes.trim() || undefined,
      }),
    onSuccess: (result) => {
      setDone(result.alreadySubmitted ? "duplicate" : "created");
    },
    onError: (error: Error) =>
      toast.error(error.message ? `${t("qdErr")} — ${error.message}` : t("qdErr")),
  });

  const close = () => {
    onOpenChange(false);
    /* reset AFTER the exit animation starts — reopening begins fresh */
    window.setTimeout(() => {
      setDone(null);
      setAttempted(false);
      setName("");
      setEmail("");
      setCompany("");
      setTeamSize("1-10");
      setSystems(String(Math.min(500, Math.max(1, defaultSystems))));
      setNotes("");
    }, 250);
  };

  const nudgeSystems = (dir: 1 | -1) => {
    const next = (Number.isFinite(systemsNum) ? systemsNum : 1) + dir;
    setSystems(String(Math.min(500, Math.max(1, next))));
  };

  const dir = lang === "ar" ? "rtl" : "ltr";

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        if (!next) close();
        else onOpenChange(true);
      }}
    >
      <DialogContent dir={dir} className="max-h-[90vh] gap-0 overflow-y-auto rounded-3xl p-0 sm:max-w-lg">
        <DialogHeader className="border-b border-slate-200/70 bg-slate-50/70 px-5 pb-4 pt-5 dark:border-white/10 dark:bg-white/[0.03] sm:px-6">
          <DialogTitle className="flex items-center gap-2.5 text-start font-display text-[16px] font-extrabold text-slate-900 dark:text-white">
            <span
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg shadow-amber-500/25"
              style={{ backgroundImage: grad("#f59e0b", "#ea580c") }}
              aria-hidden="true"
            >
              <CatIcon name="building" className="h-4 w-4" />
            </span>
            {done ? t("qdSuccessTitle") : t("qdTitle")}
          </DialogTitle>
          <DialogDescription className="mt-1 text-start text-[12px] leading-relaxed text-slate-500 dark:text-slate-400">
            {done === "created"
              ? t("qdSuccessBody")
              : done === "duplicate"
                ? t("qdAlreadyBody")
                : t("qdDesc")}
          </DialogDescription>
        </DialogHeader>

        {done ? (
          /* ---------------- the premium confirmation ---------------- */
          <div className="px-5 py-10 text-center sm:px-6">
            <div
              className="mx-auto grid h-16 w-16 place-items-center rounded-3xl text-white shadow-xl shadow-emerald-500/30"
              style={{ backgroundImage: grad("#10b981", "#0d9488") }}
              aria-hidden="true"
            >
              <CatIcon name="circle-check" className="h-8 w-8" />
            </div>
            <p className="mt-4 font-display text-[16px] font-extrabold text-slate-900 dark:text-white">
              {done === "duplicate" ? t("qdAlreadyTitle") : t("qdSuccessTitle")}
            </p>
            <p className="mx-auto mt-2 max-w-sm text-[12.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
              {done === "duplicate" ? t("qdAlreadyBody") : t("qdSuccessBody")}
            </p>
            <Button
              type="button"
              onClick={close}
              className="mt-6 h-11 gap-2 rounded-xl bg-linear-to-l from-emerald-600 via-teal-500 to-cyan-400 px-6 text-[12.5px] font-extrabold text-white shadow-lg shadow-emerald-500/30 transition hover:brightness-110 active:scale-95"
            >
              <CatIcon name="check" className="h-4 w-4" />
              {t("qdDone")}
            </Button>
          </div>
        ) : (
          /* ---------------- the form ---------------- */
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (submit.isPending) return;
              setAttempted(true);
              if (!canSubmit) return;
              submit.mutate();
            }}
            className="space-y-4 px-5 py-5 sm:px-6"
          >
            {/* name + company */}
            <div className="grid gap-3.5 sm:grid-cols-2">
              <div>
                <Label htmlFor="qd-name" className="block text-[12px] font-extrabold leading-tight text-slate-800 dark:text-slate-100">
                  {t("qdName")} <span className="text-rose-500">*</span>
                </Label>
                <Input
                  id="qd-name"
                  value={name}
                  maxLength={80}
                  disabled={submit.isPending}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={t("qdNamePh")}
                  aria-invalid={attempted && !nameValid ? true : undefined}
                  className="mt-1.5 h-10 rounded-xl border-slate-200 bg-white/90 px-3 text-[12.5px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100"
                />
              </div>
              <div>
                <Label htmlFor="qd-company" className="block text-[12px] font-extrabold leading-tight text-slate-800 dark:text-slate-100">
                  {t("qdCompany")}
                </Label>
                <Input
                  id="qd-company"
                  value={company}
                  maxLength={120}
                  disabled={submit.isPending}
                  onChange={(e) => setCompany(e.target.value)}
                  placeholder={t("qdCompanyPh")}
                  className="mt-1.5 h-10 rounded-xl border-slate-200 bg-white/90 px-3 text-[12.5px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100"
                />
              </div>
            </div>

            {/* email — the shared premium input (live verdict) */}
            <PremiumEmailInput
              id="qd-email"
              label="qdEmail"
              value={email}
              onChange={setEmail}
              required
              invalid={attempted && !emailValid}
              disabled={submit.isPending}
              placeholder="qdEmailPh"
            />

            {/* team size — premium chip radio */}
            <div className="space-y-1.5">
              <Label className="block text-[12px] font-extrabold leading-tight text-slate-800 dark:text-slate-100">
                {t("qdTeamSize")}
              </Label>
              <div className="flex flex-wrap gap-1.5" role="group" aria-label={t("qdTeamSize")}>
                {QUOTE_TEAM_SIZES.map((band) => {
                  const active = teamSize === band;
                  return (
                    <button
                      key={band}
                      type="button"
                      role="radio"
                      aria-checked={active}
                      disabled={submit.isPending}
                      onClick={() => setTeamSize(band)}
                      className={cn(
                        "inline-flex h-9 items-center rounded-xl px-3.5 text-[11.5px] font-extrabold transition active:scale-95",
                        active
                          ? "text-white shadow-lg"
                          : "border border-slate-200 bg-white/70 text-slate-500 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:text-brand-300"
                      )}
                      style={active ? { backgroundImage: grad("#f59e0b", "#ea580c") } : undefined}
                    >
                      {t(TEAM_LABEL_KEYS[band])}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* systems count — bounded stepper + precision input */}
            <div className="space-y-1.5">
              <Label htmlFor="qd-systems" className="block text-[12px] font-extrabold leading-tight text-slate-800 dark:text-slate-100">
                {t("qdSystems")}
              </Label>
              <div className="flex items-center gap-2" dir={dir}>
                <button
                  type="button"
                  onClick={() => nudgeSystems(-1)}
                  disabled={submit.isPending || systemsNum <= 1}
                  aria-label={t("pkgQuotaMinus")}
                  className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-slate-200 bg-white text-slate-500 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 disabled:cursor-not-allowed disabled:opacity-40 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400"
                >
                  <CatIcon name="minus" className="h-4 w-4" />
                </button>
                <Input
                  id="qd-systems"
                  type="number"
                  inputMode="numeric"
                  dir="ltr"
                  min={1}
                  max={500}
                  step={1}
                  value={systems}
                  disabled={submit.isPending}
                  onChange={(e) => setSystems(e.target.value)}
                  onBlur={() => {
                    if (!systemsValid) setSystems("1");
                  }}
                  aria-invalid={attempted && !systemsValid ? true : undefined}
                  className="h-10 flex-1 rounded-xl border-slate-200 bg-white/90 text-center text-[13px] font-extrabold tabular-nums text-slate-800 transition focus:border-brand-400 focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100"
                />
                <button
                  type="button"
                  onClick={() => nudgeSystems(1)}
                  disabled={submit.isPending || systemsNum >= 500}
                  aria-label={t("pkgQuotaPlus")}
                  className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-slate-200 bg-white text-slate-500 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 disabled:cursor-not-allowed disabled:opacity-40 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400"
                >
                  <CatIcon name="plus" className="h-4 w-4" />
                </button>
              </div>
              <p className="text-[10.5px] font-semibold text-slate-500 dark:text-slate-400">
                {t("qdSystemsHint")}
              </p>
            </div>

            {/* notes */}
            <div className="space-y-1.5">
              <div className="flex items-baseline justify-between gap-2">
                <Label htmlFor="qd-notes" className="block text-[12px] font-extrabold leading-tight text-slate-800 dark:text-slate-100">
                  {t("qdNotes")}
                </Label>
                <span
                  className={cn(
                    "text-[10px] font-bold tabular-nums",
                    notes.length > NOTES_MAX ? "text-rose-500" : "text-slate-500 dark:text-slate-400"
                  )}
                  dir="ltr"
                >
                  {fmtNum(notes.length, lang)}/{fmtNum(NOTES_MAX, lang)}
                </span>
              </div>
              <Textarea
                id="qd-notes"
                rows={3}
                value={notes}
                disabled={submit.isPending}
                onChange={(e) => setNotes(e.target.value.slice(0, NOTES_MAX))}
                placeholder={t("qdNotesPh")}
                className="min-h-[84px] w-full resize-none rounded-xl border-slate-200 bg-white/90 px-3.5 py-2.5 text-[12.5px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100"
              />
            </div>

            <Button
              type="submit"
              disabled={submit.isPending}
              className="h-12 w-full gap-2 rounded-xl bg-linear-to-l from-amber-500 via-orange-500 to-rose-500 px-5 text-[13px] font-extrabold text-white shadow-lg shadow-amber-500/30 transition hover:brightness-110 active:scale-95 disabled:opacity-50"
            >
              {submit.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="send" className="h-4 w-4 rtl:-scale-x-100" />
              )}
              {t("qdSubmit")}
            </Button>

            <p className="flex items-center justify-center gap-1.5 text-center text-[10.5px] font-semibold text-slate-500 dark:text-slate-400">
              <CatIcon name="shield-check" className="h-3 w-3 shrink-0 text-emerald-500" />
              {t("qdPrivacy")}
            </p>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}

export default QuoteDialog;
