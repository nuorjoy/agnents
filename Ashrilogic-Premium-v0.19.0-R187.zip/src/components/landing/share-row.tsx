"use client";

/**
 * Ashrilogic — share row (ROUND 181, extracted verbatim from the blog
 * article view's ROUND 173 ShareRow so the article reader and the system
 * detail pages share ONE implementation).
 *
 * X / WhatsApp / LinkedIn share buttons + copy-link + print — the exact
 * visual language the blog article has shipped since R173/R180:
 * • 36px gradient icon tiles for the three social targets (deterministic
 *   per-network colors, lift + brighten on hover);
 * • bordered ghost icon button for copy-link (brand ink on hover) with a
 *   toast confirmation / failure message;
 * • ROUND 180 print affordance: a printer button calling window.print()
 *   so the surface's ink stylesheet is one click away.
 *
 * Parameterized labels: `shareLabel` (the leading uppercase caption) and
 * `printLabel` (the print button's aria-label/title) are passed by the
 * caller so the blog says «شارك المقال / طباعة المقال» while a system
 * page says «مشاركة النظام / طباعة صفحة النظام» with the same chrome.
 * Copy-link strings (blogCopyLink/blogCopied) are generic and shared.
 * The whole row drops on paper (links are worthless printed).
 */
import { toast } from "sonner";
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { grad } from "@/lib/utils";

const SHARE_TARGETS: { icon: string; label: string; href: (url: string, title: string) => string; c1: string; c2: string }[] = [
  {
    icon: "twitter",
    label: "X",
    href: (url, title) =>
      `https://twitter.com/intent/tweet?text=${encodeURIComponent(title)}&url=${encodeURIComponent(url)}`,
    c1: "#0f172a",
    c2: "#334155",
  },
  {
    icon: "whatsapp",
    label: "WhatsApp",
    href: (url, title) => `https://wa.me/?text=${encodeURIComponent(`${title} ${url}`)}`,
    c1: "#10b981",
    c2: "#059669",
  },
  {
    icon: "linkedin",
    label: "LinkedIn",
    href: (url) => `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`,
    c1: "#0a66c2",
    c2: "#084d8d",
  },
];

export function ShareRow({
  url,
  title,
  shareLabel,
  printLabel,
}: {
  /** canonical share URL (server + client identical — see the R173 blog fix) */
  url: string;
  /** pre-localized share title (encoded per target) */
  title: string;
  /** leading caption, e.g. t("blogShare") / t("sysShare") */
  shareLabel: string;
  /** print button label, e.g. t("blogPrint") / t("sysPrint") */
  printLabel: string;
}) {
  const { t } = useT();

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      toast.success(t("blogCopied"));
    } catch {
      toast.error(t("blogCopyLink"));
    }
  };

  return (
    <div className="flex flex-wrap items-center gap-2 print:hidden">
      <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400">
        {shareLabel}
      </span>
      {SHARE_TARGETS.map((link) => (
        <a
          key={link.label}
          href={link.href(url, title)}
          target="_blank"
          rel="noopener noreferrer"
          aria-label={link.label}
          title={link.label}
          className="grid h-9 w-9 place-items-center rounded-xl text-white shadow-md transition-all duration-200 hover:-translate-y-0.5 hover:brightness-110 active:scale-95"
          style={{ backgroundImage: grad(link.c1, link.c2) }}
        >
          <CatIcon name={link.icon} className="h-[13px] w-[13px]" />
        </a>
      ))}
      <button
        type="button"
        onClick={copy}
        aria-label={t("blogCopyLink")}
        title={t("blogCopyLink")}
        className="grid h-9 w-9 cursor-pointer place-items-center rounded-xl border border-slate-200 bg-white text-slate-500 shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
      >
        <CatIcon name="copy" className="h-[13px] w-[13px]" />
      </button>
      <button
        type="button"
        onClick={() => window.print()}
        aria-label={printLabel}
        title={printLabel}
        className="grid h-9 w-9 cursor-pointer place-items-center rounded-xl border border-slate-200 bg-white text-slate-500 shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
      >
        <CatIcon name="printer" className="h-[13px] w-[13px]" />
      </button>
    </div>
  );
}
