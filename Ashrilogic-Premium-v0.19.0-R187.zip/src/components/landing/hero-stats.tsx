"use client";

/**
 * Ashrilogic — ROUND 172c (performance): the hero stat count-up ISLAND.
 *
 * The four hero stats animate from 0 to their target via useCountUp
 * (IntersectionObserver + rAF). Extracted from the now-SERVER hero
 * section so the entire hero markup (the LCP element included)
 * server-renders with ZERO hydration — only these four <dd> numbers
 * attach client behavior. Markup is byte-identical to the former inline
 * HeroStat renderer (same dt/dd classes, same suffix passthrough).
 */
import { useCountUp } from "@/hooks/use-count-up";
import { HeroReveal } from "@/components/landing/reveal";

export interface HeroStatSpec {
  /** numeric target as a string, or a non-numeric literal ("24/7") */
  value: string;
  label: string;
}

export function HeroStats({ stats }: { stats: readonly HeroStatSpec[] }) {
  return (
    <HeroReveal delay={0.2}>
      <dl className="mt-10 grid max-w-xl grid-cols-2 gap-x-6 gap-y-5 sm:grid-cols-4">
        {stats.map((stat) => (
          <HeroStat key={stat.label} value={stat.value} label={stat.label} />
        ))}
      </dl>
    </HeroReveal>
  );
}

/** Hero stat — animates numeric values via count-up; passes through non-numeric. */
function HeroStat({ value, label }: { value: string; label: string }) {
  const num = parseInt(value, 10);
  const isNumeric = !Number.isNaN(num) && value.trim() !== "";
  const suffix = isNumeric ? value.replace(/^\d+/, "") : "";
  const { ref, value: animated } = useCountUp(isNumeric ? num : 0, 1500);

  return (
    <div>
      <dt className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
        {label}
      </dt>
      <dd className="font-display text-2xl font-extrabold text-slate-900 dark:text-white">
        {isNumeric ? (
          <span ref={ref}>
            {animated.toLocaleString("en-US")}
            {suffix}
          </span>
        ) : (
          value
        )}
      </dd>
    </div>
  );
}
