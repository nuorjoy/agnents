/**
 * Ashrilogic — public support section.
 *
 * Split layout: the left column lists the contact channels (live email /
 * phone from the platform settings, with a response-time card) plus the
 * support perks; the right column is the public ticket form. The form is
 * validated per-field on blur + submit, feeds the admin support inbox via
 * POST /api/support (server-side zod + per-IP rate limit), and swaps to a
 * confirmation state with the ticket reference on success.
 *
 * ROUND 172d (RSC) — SERVER component with SERVER data: the section shell,
 * heading, the contact channel cards and the perks render with ZERO
 * hydration through the pure t(lang, ·). The email/phone values resolve
 * through a direct server-side read of the PlatformSetting singleton —
 * the same row GET /api/support serves — with the route's exact fail-soft
 * to the shipped DEFAULT_CONTACT values, so the live anchors ship in the
 * first HTML (SEO; the former client hydration guard + value skeletons
 * existed only to keep the client-fetch path hydration-safe — the values
 * now resolve before render, so that branch is gone). The timer channel
 * renders no value line at all, matching the settled client state.
 *
 * Client islands kept byte-identical (wave 5-b law — useT() inside):
 *  - support-presence-pill.tsx — the ROUND 172 live availability chip
 *    (GET /api/support/presence, once per mount, fail-closed to offline);
 *  - support-ticket-form.tsx — the whole ticket form card (local state,
 *    per-field validation, mutation, the Radix category Select that feeds
 *    the POST — moved verbatim).
 */
import type { CSSProperties } from "react";
import { t } from "@/lib/i18n";
import type { Lang } from "@/lib/types";
import { getCachedPlatformSettings } from "@/lib/server/platform-settings-cache";
import { CatIcon } from "@/components/icon";
import { Reveal } from "@/components/landing/reveal";
import { SupportPresencePill } from "@/components/landing/support-presence-pill";
import { SupportTicketForm } from "@/components/landing/support-ticket-form";
import { cn, grad, hexAlpha } from "@/lib/utils";

/* ------------------------------------------------------------------ */
/* vocabulary                                                          */
/* ------------------------------------------------------------------ */

const PERK_KEYS = ["pubSupPerk1", "pubSupPerk2", "pubSupPerk3"] as const;

interface Channel {
  icon: string;
  c1: string;
  c2: string;
  titleKey: "pubSupChannel1T" | "pubSupChannel2T" | "pubSupChannel3T";
  descKey: "pubSupChannel1D" | "pubSupChannel2D" | "pubSupChannel3D";
  /** live value (email / phone) — always resolved (fail-soft defaults) */
  value?: string;
  href?: string;
}

/* ------------------------------------------------------------------ */
/* server-side contact read                                            */
/* ------------------------------------------------------------------ */

/** Fallback contact channels when the settings row is somehow unreadable —
 *  the exact GET /api/support defaults. */
const DEFAULT_CONTACT = { supportEmail: "support@ashrilogic.com", supportPhone: "+249912179779" };

/** The public support contact channels, resolved SERVER-SIDE — the same
 *  PlatformSetting singleton GET /api/support reads, with the route's exact
 *  fail-soft law (missing row OR failed read → the shipped default
 *  channels, never a broken band). Cf. the landing-footer's footer-props
 *  read of the same row (ROUND 172c). */
async function resolveSupportContact(): Promise<{ supportEmail: string; supportPhone: string }> {
  try {
    const row = await getCachedPlatformSettings();
    if (!row) return DEFAULT_CONTACT;
    return { supportEmail: row.supportEmail, supportPhone: row.supportPhone };
  } catch (error) {
    console.error("SupportSection contact read failed:", error);
    return DEFAULT_CONTACT;
  }
}

/* ------------------------------------------------------------------ */
/* section                                                             */
/* ------------------------------------------------------------------ */

export async function SupportSection({ lang }: { lang: Lang }) {
  const contact = await resolveSupportContact();

  const phoneHref = `tel:${contact.supportPhone.replace(/[\s-]/g, "")}`;

  const channels: Channel[] = [
    {
      icon: "mail",
      c1: "#6d5dfb",
      c2: "#d946ef",
      titleKey: "pubSupChannel1T",
      descKey: "pubSupChannel1D",
      value: contact.supportEmail,
      href: `mailto:${contact.supportEmail}`,
    },
    {
      icon: "phone",
      c1: "#06b6d4",
      c2: "#0891b2",
      titleKey: "pubSupChannel2T",
      descKey: "pubSupChannel2D",
      value: contact.supportPhone,
      href: phoneHref,
    },
    {
      icon: "timer",
      c1: "#f59e0b",
      c2: "#ea580c",
      titleKey: "pubSupChannel3T",
      descKey: "pubSupChannel3D",
    },
  ];

  return (
    <section id="support" className="cv-auto scroll-mt-20 px-4 py-16 sm:px-6 lg:px-8 lg:py-20">
      <div className="mx-auto max-w-7xl">
        {/* heading */}
        <div className="mx-auto max-w-3xl text-center">
          <Reveal>
            <div className="flex flex-wrap items-center justify-center gap-2">
              <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3.5 py-1.5 text-[11px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
                <CatIcon name="life-buoy" className="h-[11px] w-[11px] text-brand-500" />
                <span>{t(lang, "pubSupBadge")}</span>
              </span>
              {/* ROUND 172 — live support availability (count only, fetched
                  once per mount). A subtle skeleton keeps the centered
                  heading stable until the first answer lands. */}
              <SupportPresencePill />
            </div>
            <h2 className="mt-5 font-display text-[28px] font-extrabold leading-tight tracking-tight sm:text-4xl">
              <span>{t(lang, "pubSupTitle1")} </span>
              <span className="text-gradient">{t(lang, "pubSupTitle2")}</span>
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-[14px] leading-relaxed text-slate-600 dark:text-slate-400 sm:text-[15px]">
              {t(lang, "pubSupDesc")}
            </p>
          </Reveal>
        </div>

        <div className="mt-10 grid gap-5 lg:grid-cols-5 lg:items-start">
          {/* LEFT — contact channels + perks */}
          <Reveal className="lg:col-span-2">
            <div className="space-y-4">
              {channels.map((channel, i) => (
                <div
                  key={channel.icon}
                  className="glass-card card-in group flex items-center gap-3.5 rounded-2xl p-4 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg"
                  style={{ "--i": i } as CSSProperties}
                >
                  <span
                    className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg transition-transform duration-300 group-hover:scale-110"
                    style={{
                      backgroundImage: grad(channel.c1, channel.c2),
                      boxShadow: `0 10px 24px -10px ${hexAlpha(channel.c1, 0.8)}`,
                    }}
                    aria-hidden="true"
                  >
                    <CatIcon name={channel.icon} className="h-[17px] w-[17px]" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-extrabold text-slate-900 dark:text-white">
                      {t(lang, channel.titleKey)}
                    </p>
                    {channel.value ? (
                      <a
                        href={channel.href}
                        dir="ltr"
                        className={cn(
                          "mt-0.5 block truncate font-mono text-[12px] font-bold text-brand-600 transition hover:text-brand-500 dark:text-brand-300 dark:hover:text-brand-200",
                          /* ROUND 55 — full Arabic alignment: the LTR email /
                             phone VALUE stays logically ordered (dir=ltr) but
                             is anchored to the FAR RIGHT edge on the Arabic
                             page so it lines up under the Arabic title. */
                          lang === "ar" && "text-end"
                        )}
                      >
                        {channel.value}
                      </a>
                    ) : null}
                    <p className="mt-0.5 text-[11.5px] font-medium text-slate-500 dark:text-slate-400">
                      {t(lang, channel.descKey)}
                    </p>
                  </div>
                </div>
              ))}

              {/* perks */}
              <div
                className="glass-card card-in rounded-2xl p-4"
                style={{ "--i": 3 } as CSSProperties}
              >
                <ul className="space-y-2.5">
                  {PERK_KEYS.map((key) => (
                    <li
                      key={key}
                      className="flex items-center gap-2.5 text-[12.5px] font-semibold text-slate-600 dark:text-slate-300"
                    >
                      <span
                        className="grid h-4.5 w-4.5 shrink-0 place-items-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400"
                        aria-hidden="true"
                      >
                        <CatIcon name="shield-check" className="h-[10px] w-[10px]" />
                      </span>
                      <span>{t(lang, key)}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </Reveal>

          {/* RIGHT — ticket form (client island, verbatim) */}
          <Reveal delay={0.1} className="lg:col-span-3">
            <SupportTicketForm />
          </Reveal>
        </div>
      </div>
    </section>
  );
}

export default SupportSection;
