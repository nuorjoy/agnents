"use client";

/**
 * Ashrilogic — system detail view.
 *
 * Premium per-system page showing: breadcrumb back-link, gradient hero with
 * icon + name + code + description, category badge, key features grid,
 * available modules grid (localized), related systems (same category), and
 * a prominent "Setup & Launch" CTA that starts the wizard.
 */
import type { ReactNode } from "react";
import Link from "next/link";
import { useTheme } from "next-themes";
import { useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  CATEGORIES,
  CATEGORY_MAP,
  MODULE_MAP,
  moduleDisplayName,
  SYSTEMS,
  SYSTEM_MAP,
  systemMods,
} from "@/data/catalog";
import { useT } from "@/lib/i18n";
import { useDocumentTitle } from "@/hooks/use-document-title";
import { useAppStore } from "@/lib/store";
import { buildSystemDraft } from "@/components/landing/systems-library";
import { fetchMaintenanceState } from "@/lib/api-client";
import { MAINTENANCE_QUERY_KEY } from "@/components/landing/maintenance-screen";
import { CatIcon } from "@/components/icon";
import { Reveal } from "@/components/landing/reveal";
import { ShareRow } from "@/components/landing/share-row";
import { SITE_URL } from "@/lib/site-url";
import { LandingHeader } from "@/components/landing/landing-header";
import { ScrollProgress } from "@/components/landing/scroll-progress";
import { BackToTop } from "@/components/landing/back-to-top";
import { cn, grad, hexAlpha } from "@/lib/utils";
import { PrintStamp } from "@/components/landing/print-stamp";

const KEY_FEATURES = [
  { key: "sysDetailFeat1", icon: "wand-sparkles", c1: "#6d5dfb", c2: "#8b5cf6" },
  { key: "sysDetailFeat2", icon: "gauge", c1: "#06b6d4", c2: "#0891b2" },
  { key: "sysDetailFeat3", icon: "languages", c1: "#10b981", c2: "#059669" },
  { key: "sysDetailFeat4", icon: "moon-star", c1: "#f59e0b", c2: "#ea580c" },
] as const;

/* ROUND 172c (RSC) — the footer became a SERVER component, so it can no
 * longer be imported into this client view; the server route page now
 * renders it and passes the element down here (rendered in the exact same
 * slot across the loading / detail branches). */
export function SystemDetailView({ systemId, footer }: { systemId: string; footer: ReactNode }) {
  const { t, lang } = useT();
  const system = SYSTEM_MAP[systemId];
  useDocumentTitle("docTitleSystemDetail", {
    name: system ? (lang === "ar" ? system.nameAr : system.nameEn) : systemId,
  });
  const startWizard = useAppStore((s) => s.startWizard);
  const { resolvedTheme } = useTheme();
  const router = useRouter();

  /* ROUND 89 — the «السماح بالتسجيل» gate (mirrors the library grid);
   *  hoisted ABOVE the not-found early return (rules-of-hooks) */
  const signupAllowed = useQuery({
    queryKey: MAINTENANCE_QUERY_KEY,
    queryFn: fetchMaintenanceState,
    staleTime: 60_000,
    retry: 1,
  }).data?.signupAllowed !== false;

  if (!system) {
    return (
      <div className="relative flex min-h-screen flex-col">
        <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden />
        <LandingHeader />
        <main className="flex flex-1 items-center justify-center px-4 py-20">
          <div className="text-center">
            <div className="mx-auto grid h-20 w-20 place-items-center rounded-3xl bg-slate-100 text-slate-400 dark:bg-white/5">
              <CatIcon name="circle-x" className="h-8 w-8" />
            </div>
            <h1 className="mt-5 font-display text-2xl font-extrabold">{t("sysDetailNotFound")}</h1>
            <p className="mx-auto mt-2 max-w-sm text-[13px] text-slate-500 dark:text-slate-400">
              {t("sysDetailNotFoundDesc")}
            </p>
            <Link
              href="/#systems"
              className="mt-6 inline-flex items-center gap-2 rounded-2xl bg-linear-to-l from-brand-600 to-brand-500 px-5 py-3 text-[13px] font-bold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
            >
              <CatIcon name="arrow-right" className="h-4 w-4 rtl:rotate-180" />
              {t("sysDetailBack")}
            </Link>
          </div>
        </main>
        {footer}
      </div>
    );
  }

  const cat = CATEGORY_MAP[system.c];
  /* round 29 — specialized systems override the category's module set */
  const mods = systemMods(system);
  const c1 = cat?.c1 ?? "#6d5dfb";
  const c2 = cat?.c2 ?? "#0ea5e9";
  const name = lang === "ar" ? system.nameAr : system.nameEn;
  const desc = lang === "ar" ? system.descAr : system.descEn;
  const catName = lang === "ar" ? cat?.nameAr : cat?.nameEn;
  /* ROUND 181 — canonical share URL (server + client identical, the same
   * R173 article fix): the page's canonical URL, so shares/canonical/SEO
   * agree on one domain. */
  const shareUrl = `${SITE_URL}/systems/${system.id}`;

  const handleStart = () => {
    /* ROUND 89 — the «السماح بالتسجيل» gate (mirrors the library grid) */
    if (!signupAllowed) {
      toast.error(t("signupClosedChip"));
      return;
    }
    const theme: "light" | "dark" = resolvedTheme === "light" ? "light" : "dark";
    startWizard(buildSystemDraft(system, lang, theme));
    // The wizard overlay mounts on the home route — client-navigate there
    // (no full reload; the persisted store carries the wizard draft).
    router.push("/");
  };

  // related systems: same category, excluding current, up to 4
  const related = SYSTEMS.filter((s) => s.c === system.c && s.id !== system.id).slice(0, 4);

  return (
    <div className="relative flex min-h-screen flex-col">
      {/* decorative backgrounds — paper is ink-only */}
      <div className="mesh pointer-events-none fixed inset-0 -z-10 print:hidden" aria-hidden />
      <div
        className="grid-lines pointer-events-none absolute inset-x-0 top-0 -z-10 h-[720px] print:hidden"
        aria-hidden
      />

      <div className="print:hidden">
        <LandingHeader />
        <ScrollProgress />
        <BackToTop />
      </div>

      {/* ROUND 181 — PRINT: the page prints as a clean SPEC SHEET (hero
       * name/description + key features + the modules list as ink).
       * Navigation chrome (breadcrumb / related links / the two wizard
       * CTAs / footer / scroll overlays) and every gradient icon tile
       * (white icons over backgrounds the print engine strips would
       * render invisible) drop out on paper; the .systems-detail-print
       * ink rules live in globals.css. */}
      <main className="systems-detail-print flex-1 px-4 py-10 sm:px-6 lg:px-8 lg:py-14 print:py-6">
        <div className="mx-auto max-w-5xl">
          {/* breadcrumb — nav chrome, worthless printed */}
          <Reveal className="print:hidden">
            <Link
              href="/#systems"
              className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white/70 px-3 py-2 text-[12px] font-bold text-slate-600 backdrop-blur-sm transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300"
            >
              <CatIcon name="arrow-right" className="h-3.5 w-3.5 rtl:rotate-180" />
              {t("sysDetailBack")}
            </Link>
          </Reveal>

          {/* hero */}
          <Reveal delay={0.05}>
            <div className="relative mt-6 overflow-hidden rounded-3xl border border-slate-200/80 bg-white/70 p-6 backdrop-blur-sm dark:border-white/10 dark:bg-white/[0.03] sm:p-10 print:overflow-visible">
              {/* inline-start accent stripe — a thin vertical gradient bar on
                  the reading-start edge. Anchors the hero to the sector's
                  color identity; purely decorative (aria-hidden, print-drops). */}
              <span
                className="pointer-events-none absolute inset-y-0 start-0 w-1.5 print:hidden"
                style={{ backgroundImage: grad(c1, c2) }}
                aria-hidden
              />
              {/* gradient glow — decorative, dropped on paper */}
              <div
                className="pointer-events-none absolute -end-10 -top-10 h-60 w-60 rounded-full opacity-30 blur-3xl print:hidden"
                style={{ background: `radial-gradient(circle, ${c1}, transparent 70%)` }}
                aria-hidden
              />
              {/* faint icon watermark — a large, very-low-opacity version of
                  the system's own icon anchored to the opposite corner from
                  the glow. Adds visual depth and identity to the hero without
                  any new content; purely decorative (aria-hidden, print-drops). */}
              <CatIcon
                name={system.icon}
                className="pointer-events-none absolute -bottom-8 end-6 h-44 w-44 opacity-[0.04] print:hidden rtl:rotate-0 dark:opacity-[0.06]"
                aria-hidden
              />
              <div className="relative flex flex-col gap-5 sm:flex-row sm:items-start">
                {/* icon tile — paper: hidden (white icon over a gradient the
                    print engine strips would render invisible) */}
                <span
                  className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl text-white shadow-xl print:hidden"
                  style={{ backgroundImage: grad(c1, c2), boxShadow: `0 14px 30px -10px ${hexAlpha(c1, 0.8)}` }}
                  aria-hidden
                >
                  <CatIcon name={system.icon} className="h-7 w-7" />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-2.5 py-1 text-[10px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
                      <CatIcon name={cat?.icon ?? "boxes"} className="h-[9px] w-[9px]" style={{ color: c1 }} />
                      {catName}
                    </span>
                  </div>
                  <h1 className="mt-3 font-display text-[28px] font-extrabold leading-tight tracking-tight sm:text-4xl">
                    {name}
                  </h1>
                  <p className="mt-3 max-w-2xl text-[14px] leading-relaxed text-slate-600 dark:text-slate-400 sm:text-[15px]">
                    {desc}
                  </p>
                  <div className="mt-6 flex flex-wrap items-center gap-4">
                    {/* wizard CTA — an action button is worthless printed */}
                    <button
                      type="button"
                      onClick={handleStart}
                      className="group mt-0 inline-flex items-center gap-2.5 rounded-2xl px-6 py-3.5 text-sm font-bold text-white shadow-xl shadow-brand-500/30 transition hover:shadow-brand-500/50 hover:brightness-110 active:scale-95 print:hidden"
                      style={{ backgroundImage: grad(c1, c2) }}
                    >
                      <CatIcon name="wand-sparkles" className="h-4 w-4" />
                      {t("sysSetupLaunch")}
                      <CatIcon
                        name={lang === "ar" ? "arrow-left" : "arrow-right"}
                        className="h-4 w-4 transition-transform group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5"
                      />
                    </button>
                    {/* ROUND 181 — share row (X / WhatsApp / LinkedIn + copy
                     * + print): the same chrome the blog articles carry,
                     * from the shared component (labels via the new
                     * sysShare/sysPrint keys). Prints nothing itself. */}
                    <ShareRow
                      url={shareUrl}
                      title={name}
                      shareLabel={t("sysShare")}
                      printLabel={t("sysPrint")}
                    />
                  </div>
                </div>
              </div>
            </div>
          </Reveal>

          {/* Quick Facts — a compact at-a-glance panel: sector, module count
              and the setup commitment. Gives a visitor the headline numbers
              before they scroll into the full module grid / features. */}
          <Reveal delay={0.08}>
            <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-3 print:hidden">
              <div className="flex items-center gap-3 rounded-2xl border border-slate-200/80 bg-white/70 p-4 backdrop-blur-sm dark:border-white/10 dark:bg-white/[0.03]">
                <span
                  className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-md"
                  style={{ backgroundImage: grad(c1, c2) }}
                  aria-hidden
                >
                  <CatIcon name={cat?.icon ?? "boxes"} className="h-[14px] w-[14px]" />
                </span>
                <div className="min-w-0">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    {t("sysDetailCategory")}
                  </p>
                  <p className="truncate text-[14px] font-extrabold text-slate-900 dark:text-white">
                    {catName}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 rounded-2xl border border-slate-200/80 bg-white/70 p-4 backdrop-blur-sm dark:border-white/10 dark:bg-white/[0.03]">
                <span
                  className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-md"
                  style={{ backgroundImage: grad(c1, c2) }}
                  aria-hidden
                >
                  <CatIcon name="cubes" className="h-[14px] w-[14px]" />
                </span>
                <div className="min-w-0">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    {t("sysDetailModules")}
                  </p>
                  <p className="text-[14px] font-extrabold text-slate-900 dark:text-white">
                    {mods.length} {t("statModules")}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 rounded-2xl border border-slate-200/80 bg-white/70 p-4 backdrop-blur-sm dark:border-white/10 dark:bg-white/[0.03]">
                <span
                  className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-md"
                  style={{ backgroundImage: grad(c1, c2) }}
                  aria-hidden
                >
                  <CatIcon name="wand-sparkles" className="h-[14px] w-[14px]" />
                </span>
                <div className="min-w-0">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    {t("sysDetailFeat2")}
                  </p>
                  <p className="text-[14px] font-extrabold text-slate-900 dark:text-white">
                    {t("sysDetailFeat1")}
                  </p>
                </div>
              </div>
            </div>
          </Reveal>

          {/* key features */}
          <Reveal delay={0.1}>
            <div className="mt-8">
              <h2 className="font-display text-[18px] font-extrabold text-slate-900 dark:text-white">
                {t("sysDetailFeatures")}
              </h2>
              <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                {KEY_FEATURES.map((feat) => (
                  <div
                    key={feat.key}
                    className="group rounded-2xl border border-slate-200/80 bg-white/60 p-4 backdrop-blur-sm transition-all duration-200 hover:-translate-y-1 hover:shadow-lg dark:border-white/10 dark:bg-white/[0.03]"
                  >
                    {/* icon tile — hidden on paper (white-on-stripped-gradient) */}
                    <span
                      className="grid h-10 w-10 place-items-center rounded-xl text-white shadow-md transition-transform duration-200 group-hover:scale-110 print:hidden"
                      style={{ backgroundImage: grad(feat.c1, feat.c2) }}
                      aria-hidden
                    >
                      <CatIcon name={feat.icon} className="h-[14px] w-[14px]" />
                    </span>
                    <p className="mt-3 text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                      {t(feat.key)}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>

          {/* available modules */}
          <Reveal delay={0.15}>
            <div className="mt-8">
              <div className="flex items-center gap-2">
                <h2 className="font-display text-[18px] font-extrabold text-slate-900 dark:text-white">
                  {t("sysDetailModules")}
                </h2>
                <span className="rounded-full bg-brand-500/10 px-2 py-0.5 text-[10px] font-extrabold text-brand-600 dark:text-brand-300">
                  {mods.length}
                </span>
              </div>
              <p className="mt-1 text-[12.5px] text-slate-500 dark:text-slate-400">
                {t("sysDetailModulesDesc")}
              </p>
              <div className="mt-4 grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-4">
                {mods.map((modId) => {
                  /* ROUND 168 — the per-system module label (moduleDisplayName)
                   * replaces the raw catalog name so the marketing page and the
                   * workspace show the SAME sector vocabulary (SAMS: «الحضور
                   * والغياب»، «الطلاب»، «عقود السكن»). */
                  const mod = MODULE_MAP[modId];
                  return (
                    <div
                      key={modId}
                      className="flex items-center gap-2.5 rounded-xl border border-slate-200/80 bg-white/60 p-3 dark:border-white/10 dark:bg-white/[0.03] print:break-inside-avoid"
                    >
                      {/* icon tile — hidden on paper (white-on-stripped-gradient) */}
                      <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white print:hidden" style={{ backgroundImage: grad(c1, c2) }} aria-hidden>
                        <CatIcon name={mod?.icon ?? "cubes"} className="h-[11px] w-[11px]" />
                      </span>
                      <span className="truncate text-[12px] font-bold text-slate-700 dark:text-slate-200 print:whitespace-normal">
                        {moduleDisplayName(modId, system.id, lang)}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </Reveal>

          {/* related systems — nav links, worthless printed */}
          {related.length > 0 ? (
            <Reveal delay={0.2} className="print:hidden">
              <div className="mt-10">
                <h2 className="font-display text-[18px] font-extrabold text-slate-900 dark:text-white">
                  {t("sysDetailRelated")}
                </h2>
                <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                  {related.map((rel) => {
                    const relCat = CATEGORY_MAP[rel.c];
                    const relC1 = relCat?.c1 ?? "#6d5dfb";
                    const relC2 = relCat?.c2 ?? "#0ea5e9";
                    const relName = lang === "ar" ? rel.nameAr : rel.nameEn;
                    return (
                      <Link
                        key={rel.id}
                        href={`/systems/${rel.id}`}
                        prefetch={false}
                        className="group rounded-2xl border border-slate-200/80 bg-white/60 p-4 backdrop-blur-sm transition-all duration-200 hover:-translate-y-1 hover:shadow-lg dark:border-white/10 dark:bg-white/[0.03]"
                      >
                        <span
                          className="grid h-10 w-10 place-items-center rounded-xl text-white shadow-md transition-transform duration-200 group-hover:scale-110"
                          style={{ backgroundImage: grad(relC1, relC2) }}
                          aria-hidden
                        >
                          <CatIcon name={rel.icon} className="h-[14px] w-[14px]" />
                        </span>
                        <p className="mt-3 truncate text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                          {relName}
                        </p>
                      </Link>
                    );
                  })}
                </div>
              </div>
            </Reveal>
          ) : null}

          {/* final CTA — marketing band, worthless printed */}
          <Reveal delay={0.25} className="print:hidden">
            <div className="mt-10 overflow-hidden rounded-3xl border border-brand-200/60 bg-linear-to-r from-brand-600/10 via-fuchsia-500/10 to-cyan-400/10 p-6 text-center dark:border-brand-500/20 sm:p-8">
              <h2 className="font-display text-[20px] font-extrabold sm:text-2xl">
                {t("ctaTitle")}
              </h2>
              <p className="mx-auto mt-2 max-w-md text-[13px] text-slate-600 dark:text-slate-400">
                {t("ctaDesc")}
              </p>
              <button
                type="button"
                onClick={handleStart}
                className="mt-5 inline-flex items-center gap-2.5 rounded-2xl px-6 py-3.5 text-sm font-bold text-white shadow-xl shadow-brand-500/30 transition hover:shadow-brand-500/50 hover:brightness-110 active:scale-95"
                style={{ backgroundImage: grad(c1, c2) }}
              >
                <CatIcon name="rocket" className="h-4 w-4" />
                {t("sysSetupLaunch")}
              </button>
            </div>
          </Reveal>
        </div>
        {/* R182 — print provenance inside the .systems-detail-print scope. */}
        <PrintStamp />
      </main>

      <div className="print:hidden">{footer}</div>
    </div>
  );
}

export default SystemDetailView;
