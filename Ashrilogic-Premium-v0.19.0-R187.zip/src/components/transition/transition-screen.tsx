"use client";

/**
 * Ashrilogic — provisioning transition screen.
 *
 * Unlike V2's fake timers, the animated steps correspond to REAL work:
 * the instance (DB row, modules, admin, activities, stats) is fetched via
 * react-query while the progress animation plays; we only enter the
 * dashboard once both the query AND the animation have completed.
 */
import { useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { CATEGORY_MAP, SYSTEM_MAP } from "@/data/catalog";
import { useT } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import { fetchInstance } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { grad, hexAlpha, cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

import "@/lib/i18n/fragments/app";
const STEP_KEYS = ["tsStep1", "tsStep2", "tsStep3", "tsStep4"] as const;
const STEP_ICONS = ["database", "cubes", "users", "shield-check"] as const;

const CADENCE_MS = 450;
const HOLD_MS = 400;
const FADE_MS = 320;

export function TransitionScreen() {
  const { t, lang } = useT();
  const currentInstanceId = useAppStore((s) => s.currentInstanceId);
  const setView = useAppStore((s) => s.setView);
  const exitToLanding = useAppStore((s) => s.exitToLanding);

  const [progress, setProgress] = useState(0);
  const [fading, setFading] = useState(false);
  const welcomedRef = useRef(false);

  const query = useQuery({
    queryKey: ["instance", currentInstanceId],
    queryFn: () => fetchInstance(currentInstanceId as string),
    enabled: !!currentInstanceId,
    retry: 1,
  });

  /* Cadence: step the animation up 25% every ~450ms until 100%. */
  useEffect(() => {
    if (!currentInstanceId) return;
    const timer = setInterval(() => {
      setProgress((p) => (p >= 100 ? p : Math.min(100, p + 25)));
    }, CADENCE_MS);
    return () => clearInterval(timer);
  }, [currentInstanceId]);

  /* No instance id at all → back to landing. */
  useEffect(() => {
    if (!currentInstanceId) exitToLanding();
  }, [currentInstanceId, exitToLanding]);

  const finished = progress >= 100 && query.isSuccess;

  /* Query resolved AND animation complete → hold briefly → fade → dashboard. */
  useEffect(() => {
    if (!finished) return;
    const hold = setTimeout(() => setFading(true), HOLD_MS);
    return () => clearTimeout(hold);
  }, [finished]);

  useEffect(() => {
    if (!fading) return;
    const go = setTimeout(() => {
      setView("dashboard");
      if (!welcomedRef.current) {
        welcomedRef.current = true;
        toast.success(t("welcomeToast"));
      }
    }, FADE_MS);
    return () => clearTimeout(go);
  }, [fading, setView, t]);

  const instance = query.data?.instance;
  const system = instance ? SYSTEM_MAP[instance.systemId] : undefined;
  const cat = system ? CATEGORY_MAP[system.c] : undefined;
  const c1 = cat?.c1 ?? "#6d5dfb";
  const c2 = cat?.c2 ?? "#0ea5e9";
  const sysName = system ? (lang === "ar" ? system.nameAr : system.nameEn) : (instance?.systemId ?? "");

  return (
    <div
      className={cn(
        "fixed inset-0 z-[200] grid place-items-center overflow-y-auto bg-background p-6 transition-opacity duration-300",
        fading && "opacity-0"
      )}
      role="status"
      aria-live="polite"
    >
      <div className="mesh pointer-events-none absolute inset-0" aria-hidden="true" />

      <div className="relative w-full max-w-md text-center">
        {/* orbit */}
        <div className="relative mx-auto grid h-28 w-28 place-items-center">
          <span
            className="animate-orbit absolute inset-0 rounded-full border-2 border-transparent border-t-brand-500"
            aria-hidden="true"
          />
          <span
            className="animate-orbit absolute inset-2.5 rounded-full border-2 border-transparent border-b-fuchsia-500"
            style={{ animationDirection: "reverse", animationDuration: "2s" }}
            aria-hidden="true"
          />
          <span
            className="icon-pop grid h-14 w-14 place-items-center rounded-2xl text-white shadow-xl"
            style={{
              backgroundImage: grad(c1, c2),
              boxShadow: `0 18px 40px -12px ${hexAlpha(c1, 0.8)}`,
            }}
          >
            <CatIcon name={system?.icon ?? "boxes"} className="h-5 w-5" />
          </span>
        </div>

        <h1 className="mt-6 font-display text-2xl font-extrabold text-slate-900 dark:text-white">{sysName}</h1>
        <p className="mt-2 text-[13px] text-slate-500 dark:text-slate-400">{t("tsPreparing")}</p>

        {/* provisioning steps */}
        <ul className="mt-7 space-y-2 text-start">
          {STEP_KEYS.map((key, i) => {
            /* step 1 (DB row) is already true; later steps light up with the
               query (real data loaded) or the animation cadence. */
            const active = i === 0 || query.isSuccess || progress > i * 25;
            const done = progress >= (i + 1) * 25;
            return (
              <li
                key={key}
                className={cn(
                  "flex items-center gap-3 rounded-2xl border p-3 transition-all duration-500",
                  done
                    ? "border-emerald-200 bg-emerald-50/50 dark:border-emerald-500/30 dark:bg-emerald-500/10"
                    : active
                      ? "border-brand-200 bg-brand-50/50 dark:border-brand-500/30 dark:bg-brand-500/10"
                      : "border-slate-200 bg-white/60 opacity-40 dark:border-white/10 dark:bg-white/[0.03]"
                )}
              >
                <span
                  className="grid h-8 w-8 shrink-0 place-items-center rounded-xl text-white transition-all duration-500"
                  style={{
                    backgroundImage: done
                      ? "linear-gradient(135deg,#10b981,#059669)"
                      : active
                        ? grad(c1, c2)
                        : "linear-gradient(135deg,#cbd5e1,#94a3b8)",
                  }}
                >
                  <CatIcon name={STEP_ICONS[i]} className="h-[12px] w-[12px]" />
                </span>
                <span className="flex-1 text-[12.5px] font-bold text-slate-700 dark:text-slate-200">{t(key)}</span>
                {done ? (
                  <CatIcon name="circle-check" className="h-4 w-4 text-emerald-500" />
                ) : (
                  <CatIcon name="refresh-cw" className={cn("h-3.5 w-3.5 text-slate-400", active && "animate-spin")} />
                )}
              </li>
            );
          })}
        </ul>

        {/* progress bar */}
        <div className="mt-7">
          <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-white/10">
            <div
              className="progress-stripes h-full rounded-full bg-linear-to-l from-brand-500 via-fuchsia-500 to-cyan-400 transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="mt-2.5 text-[12px] font-extrabold text-slate-500 dark:text-slate-400" aria-live="polite">
            {progress}%
          </p>
        </div>

        {/* error → inline retry (never hang forever) */}
        {query.isError ? (
          <div className="mt-6 rounded-2xl border border-rose-200 bg-rose-50/70 p-4 dark:border-rose-500/30 dark:bg-rose-500/10">
            <p className="flex items-center justify-center gap-2 text-[13px] font-bold text-rose-600 dark:text-rose-400">
              <CatIcon name="triangle-alert" className="h-4 w-4" />
              {t("errorText")}
            </p>
            <div className="mt-3 flex justify-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => query.refetch()}
                className="h-9 rounded-xl px-4 text-[12px] font-bold"
              >
                <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
                {t("retryText")}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setView("select")}
                className="h-9 rounded-xl px-4 text-[12px] font-bold"
              >
                <CatIcon name="layers" className="h-3.5 w-3.5" />
                {t("dashGoSelect")}
              </Button>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}

export default TransitionScreen;
