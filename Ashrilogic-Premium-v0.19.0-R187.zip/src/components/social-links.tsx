"use client";

/**
 * Ashrilogic — reusable social links strip.
 * Two variants: a compact icon row (footer) and a labeled card grid (error pages).
 *
 * The LIVE state (URL + visibility per network) is owned by the dashboard
 * Settings view and served publicly by GET /api/support — this component
 * subscribes to that endpoint and overlays the dashboard state on the
 * canonical registry, falling back to the defaults while loading.
 */
import { useQuery } from "@tanstack/react-query";
import { CatIcon } from "@/components/icon";
import { SUPPORT_CHANNELS, resolvePublicSocialLinks } from "@/lib/social";
import { fetchSupportContact } from "@/lib/api-client";
import { useT } from "@/lib/i18n";
import { cn, hexAlpha } from "@/lib/utils";

/** Shared query hook — dashboard-controlled contact/social state. */
function useSupportContact() {
  return useQuery({
    queryKey: ["support-contact"],
    queryFn: fetchSupportContact,
    staleTime: 60_000,
    retry: 1,
    /* render canonical defaults while the first fetch resolves */
    placeholderData: (prev) =>
      prev ?? {
        supportEmail: SUPPORT_CHANNELS.email,
        supportPhone: SUPPORT_CHANNELS.phone,
        socialLinks: resolvePublicSocialLinks([]),
      },
  });
}

export function SocialLinks({
  variant = "compact",
  className,
}: {
  variant?: "compact" | "labeled";
  className?: string;
}) {
  const { lang } = useT();
  const { data } = useSupportContact();
  const links = data?.socialLinks ?? resolvePublicSocialLinks([]);

  if (variant === "labeled") {
    return (
      <div className={cn("grid grid-cols-2 gap-3 sm:grid-cols-4", className)}>
        {links.map((s) => (
          <a
            key={s.icon}
            href={s.href}
            target="_blank"
            rel="noopener noreferrer"
            className="group flex flex-col items-center gap-2 rounded-2xl border border-slate-200/80 bg-white/70 p-4 text-center backdrop-blur-sm transition-all duration-200 hover:-translate-y-1 hover:border-transparent hover:shadow-lg dark:border-white/10 dark:bg-white/[0.03]"
            aria-label={lang === "ar" ? s.labelAr : s.labelEn}
          >
            <span
              className="grid h-11 w-11 place-items-center rounded-xl text-white shadow-md transition-transform duration-200 group-hover:scale-110"
              style={{ backgroundColor: s.color }}
            >
              <CatIcon name={s.icon} className="h-[16px] w-[16px]" />
            </span>
            <span className="text-[11px] font-bold leading-tight text-slate-600 dark:text-slate-300">
              {lang === "ar" ? s.labelAr : s.labelEn}
            </span>
          </a>
        ))}
      </div>
    );
  }

  /* compact icon row */
  return (
    <div className={cn("flex flex-wrap items-center gap-2", className)}>
      {links.map((s) => (
        <a
          key={s.icon}
          href={s.href}
          target="_blank"
          rel="noopener noreferrer"
          aria-label={lang === "ar" ? s.labelAr : s.labelEn}
          title={lang === "ar" ? s.labelAr : s.labelEn}
          className="group relative grid h-10 w-10 place-items-center overflow-hidden rounded-xl border border-slate-200 bg-white text-slate-500 transition-all duration-200 hover:-translate-y-0.5 hover:text-white hover:shadow-lg dark:border-white/10 dark:bg-white/5 dark:text-slate-400"
          style={{ ["--brand" as string]: s.color }}
        >
          <span
            className="absolute inset-0 origin-center scale-0 transition-transform duration-200 group-hover:scale-100"
            style={{ backgroundColor: s.color }}
            aria-hidden="true"
          />
          <CatIcon
            name={s.icon}
            className="relative h-[15px] w-[15px] transition-colors duration-200"
          />
        </a>
      ))}
    </div>
  );
}

/** Direct support channels block (email / phone / help center) for error pages. */
export function SupportChannels({ className }: { className?: string }) {
  const { t } = useT();
  const { data } = useSupportContact();
  const email = data?.supportEmail ?? SUPPORT_CHANNELS.email;
  const phone = data?.supportPhone ?? SUPPORT_CHANNELS.phone;
  const items = [
    { icon: "mail", label: t("supportEmail"), value: email, href: `mailto:${email}` },
    { icon: "phone", label: t("supportPhone"), value: phone, href: `tel:${phone.replace(/\s+/g, "")}` },
    { icon: "life-buoy", label: t("supportHelpCenter"), value: SUPPORT_CHANNELS.helpCenter.replace(/^https?:\/\//, ""), href: SUPPORT_CHANNELS.helpCenter },
  ];
  return (
    <div className={cn("grid gap-3 sm:grid-cols-3", className)}>
      {items.map((it) => (
        <a
          key={it.icon}
          href={it.href}
          target={it.href.startsWith("http") ? "_blank" : undefined}
          rel="noopener noreferrer"
          className="group flex items-center gap-3 rounded-2xl border border-slate-200/80 bg-white/70 p-3.5 backdrop-blur-sm transition-all hover:-translate-y-0.5 hover:border-brand-300 hover:shadow-md dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-brand-500/40"
        >
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-linear-to-br from-brand-500 to-fuchsia-500 text-white shadow-md">
            <CatIcon name={it.icon} className="h-[15px] w-[15px]" />
          </span>
          <span className="min-w-0">
            <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              {it.label}
            </span>
            <span className="block truncate text-[13px] font-extrabold text-slate-700 transition group-hover:text-brand-600 dark:text-slate-200 dark:group-hover:text-brand-300" dir="ltr">
              {it.value}
            </span>
          </span>
        </a>
      ))}
    </div>
  );
}

/** Hex helper re-exported for consumers that build custom social UI. */
export { hexAlpha };
