"use client";

/**
 * Wizard step 3 — module selection, powered by the ROUND 134-D smart
 * recommendation engine (src/lib/module-recommend.ts).
 *
 * Selection lives in a LOCAL Set that syncs to the draft on every toggle.
 * The next set is always computed OUTSIDE state updaters (a store update
 * fired inside a functional setState runs during React's render phase) and
 * is mirrored in a ref so the toggle callback keeps a STABLE identity —
 * combined with memoized tiles and stable keys, only the toggled tile
 * re-renders instead of the whole grid (the V2 full-innerHTML re-render
 * fix). The old naive CORE_SIZE=8 slicing is gone: the engine scores every
 * module of the system's effective list and the grid renders THREE tiers —
 * «الأساسية» (essential), «موصى بها» (recommended, star badge), «اختيارية»
 * (optional) — behind a live search, per-tile match chips (tier dot +
 * score%), a WHY-this-recommendation signal strip and a gradient
 * activation ring.
 *
 * Default-selection semantics are PRESERVED from before the round: the
 * draft arrives from buildSystemDraft() with the full effective list
 * pre-selected, and this step initializes its local set from
 * draft.modules verbatim.
 */
import { memo, useCallback, useMemo, useRef, useState } from "react";
import { CATEGORY_MAP, MODULE_MAP, SYSTEM_MAP, moduleDisplayName, systemMods } from "@/data/catalog";
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, hexAlpha, normalizeSearch } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  recommendModules,
  type ModuleRecommendation,
  type RecommendReasonKey,
} from "@/lib/module-recommend";
import { StepHeading, type WizardStepProps } from "@/components/wizard/wizard-shared";

/* Tier identity for the per-tile match chip: a 6px dot whose color encodes
   the engine tier (emerald = essential, amber = the "الموصى بها" star
   family, slate = optional). Static strings keep the memoized tiles pure. */
const TIER_DOT: Record<ModuleRecommendation["tier"], string> = {
  essential: "bg-emerald-500",
  recommended: "bg-amber-400",
  optional: "bg-slate-300 dark:bg-slate-600",
};

/* Signal-chip accent tones for the WHY strip (violet/emerald gradient band). */
const SIGNAL_TONE: Record<string, string> = {
  violet: "border-violet-300/70 bg-violet-500/10 text-violet-700 dark:border-violet-400/25 dark:bg-violet-400/10 dark:text-violet-300",
  emerald: "border-emerald-300/70 bg-emerald-500/10 text-emerald-700 dark:border-emerald-400/25 dark:bg-emerald-400/10 dark:text-emerald-300",
  amber: "border-amber-300/70 bg-amber-500/10 text-amber-700 dark:border-amber-400/25 dark:bg-amber-400/10 dark:text-amber-300",
  sky: "border-sky-300/70 bg-sky-500/10 text-sky-700 dark:border-sky-400/25 dark:bg-sky-400/10 dark:text-sky-300",
  teal: "border-teal-300/70 bg-teal-500/10 text-teal-700 dark:border-teal-400/25 dark:bg-teal-400/10 dark:text-teal-300",
};

/* Progress ring geometry (48×48 viewBox, 4px stroke, gradient stroke). */
const RING_R = 20;
const RING_CIRC = 2 * Math.PI * RING_R;
/* Single instance of this step exists at a time → a static gradient id is safe. */
const RING_GRAD_ID = "wz-modules-ring";

/* Thin custom scrollbar for long module lists (webkit + Firefox). */
const LIST_SCROLL = cn(
  "max-h-96 space-y-5 overflow-y-auto pe-1",
  "[scrollbar-width:thin] [scrollbar-color:rgba(148,163,184,0.55)_transparent]",
  "[&::-webkit-scrollbar]:w-1.5 [&::-webkit-scrollbar-track]:bg-transparent",
  "[&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:border-0",
  "[&::-webkit-scrollbar-thumb]:bg-none [&::-webkit-scrollbar-thumb]:bg-slate-400/60",
  "dark:[&::-webkit-scrollbar-thumb]:bg-white/25"
);

interface TileData {
  key: string;
  icon: string;
  name: string;
  /** normalized name for Arabic-aware search matching */
  norm: string;
  /** engine tier — drives the chip dot color */
  tier: ModuleRecommendation["tier"];
  /** pre-formatted match score label (locale digits + %) */
  scoreLabel: string;
  /** localized why-this-score tooltip (score + top reasons) */
  tooltip: string;
}

interface TileProps {
  moduleId: string;
  icon: string;
  name: string;
  selected: boolean;
  tier: ModuleRecommendation["tier"];
  scoreLabel: string;
  tooltip: string;
  c1: string;
  c2: string;
  onToggle: (moduleId: string) => void;
}

const ModuleTile = memo(function ModuleTile({
  moduleId,
  icon,
  name,
  selected,
  tier,
  scoreLabel,
  tooltip,
  c1,
  c2,
  onToggle,
}: TileProps) {
  return (
    /* Gradient ring: the outer button paints the 1.5px gradient frame +
       soft category glow when selected; the inner span keeps its own
       surface (dark-aware) so both themes read correctly. The title attr
       carries the engine's match score + localized reasons. */
    <button
      type="button"
      onClick={() => onToggle(moduleId)}
      aria-pressed={selected}
      title={tooltip}
      className="w-full rounded-2xl p-[1.5px] text-start transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg hover:shadow-slate-900/5 active:translate-y-0"
      style={
        selected
          ? { backgroundImage: grad(c1, c2), boxShadow: `0 0 20px -6px ${hexAlpha(c1, 0.45)}` }
          : undefined
      }
    >
      <span
        className={cn(
          "flex w-full items-center gap-3 rounded-[14.5px] border p-3.5",
          selected
            ? "border-transparent bg-white dark:bg-ink-900"
            : "border-slate-200 bg-white hover:border-slate-300 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-white/20"
        )}
        style={
          selected
            ? { backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.09)}, ${hexAlpha(c2, 0.09)})` }
            : undefined
        }
      >
        <span
          className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white"
          style={{ backgroundImage: grad(c1, c2) }}
        >
          <CatIcon name={icon} className="h-3.5 w-3.5" />
        </span>
        <span className="min-w-0 flex-1">
          <span
            className={cn(
              "block truncate text-[12.5px] font-bold",
              selected ? "text-slate-900 dark:text-white" : "text-slate-700 dark:text-slate-200"
            )}
          >
            {name}
          </span>
          {/* engine match chip — tier dot + score%, subtle by design */}
          <span className="mt-0.5 inline-flex items-center gap-1 text-[9.5px] font-bold tabular-nums text-slate-400 dark:text-slate-500">
            <span aria-hidden="true" className={cn("h-1.5 w-1.5 rounded-full", TIER_DOT[tier])} />
            {scoreLabel}
          </span>
        </span>
        <span
          className={cn(
            "grid h-6 w-6 shrink-0 place-items-center rounded-full border-2 transition-all duration-200",
            selected ? "scale-100 border-transparent text-white" : "scale-75 border-slate-300 dark:border-white/25"
          )}
          style={selected ? { backgroundImage: grad(c1, c2) } : undefined}
        >
          <CatIcon
            name="check"
            className={cn(
              "h-3 w-3 transition-all duration-200",
              selected ? "scale-100 opacity-100" : "scale-0 opacity-0"
            )}
          />
        </span>
      </span>
    </button>
  );
});

interface GroupProps {
  headingId: string;
  label: string;
  desc: string;
  icon: string;
  recommendedLabel?: string;
  recommendedDesc?: string;
  tiles: TileData[];
  selected: ReadonlySet<string>;
  c1: string;
  c2: string;
  onToggle: (moduleId: string) => void;
}

function ModuleGroup({
  headingId,
  label,
  desc,
  icon,
  recommendedLabel,
  recommendedDesc,
  tiles,
  selected,
  c1,
  c2,
  onToggle,
}: GroupProps) {
  if (tiles.length === 0) return null;
  const selCount = tiles.reduce((n, tl) => n + (selected.has(tl.key) ? 1 : 0), 0);
  return (
    <section role="group" aria-labelledby={headingId}>
      <header className="mb-1.5 flex flex-wrap items-center gap-x-2 gap-y-1">
        <span
          className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-white"
          style={{ backgroundImage: grad(c1, c2) }}
        >
          <CatIcon name={icon} className="h-3 w-3" />
        </span>
        <h4 id={headingId} className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
          {label}
        </h4>
        {recommendedLabel ? (
          <span
            title={recommendedDesc}
            className="inline-flex items-center gap-1 rounded-full border border-amber-300/70 bg-amber-50 px-2 py-0.5 text-[10px] font-extrabold text-amber-600 dark:border-amber-400/25 dark:bg-amber-400/10 dark:text-amber-300"
          >
            <CatIcon name="star" className="h-2.5 w-2.5" />
            {recommendedLabel}
          </span>
        ) : null}
        <span
          aria-hidden="true"
          className="ms-auto inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-extrabold tabular-nums text-white"
          style={{ backgroundImage: grad(c1, c2) }}
        >
          {selCount}/{tiles.length}
        </span>
      </header>
      <p className="mb-2.5 ps-9 text-[11px] leading-snug text-slate-400 dark:text-slate-500">{desc}</p>
      <div className="grid gap-2.5 sm:grid-cols-2">
        {tiles.map((tl) => (
          <ModuleTile
            key={tl.key}
            moduleId={tl.key}
            icon={tl.icon}
            name={tl.name}
            selected={selected.has(tl.key)}
            tier={tl.tier}
            scoreLabel={tl.scoreLabel}
            tooltip={tl.tooltip}
            c1={c1}
            c2={c2}
            onToggle={onToggle}
          />
        ))}
      </div>
    </section>
  );
}

export function ModulesStep({ draft, update }: WizardStepProps) {
  const { t, lang } = useT();
  const system = SYSTEM_MAP[draft.systemId];
  const cat = system ? CATEGORY_MAP[system.c] : undefined;
  /* round 29 — the effective module list is the SYSTEM's (specialized
     systems override the category set), resolved once here. */
  const catMods = useMemo(() => systemMods(system), [system]);
  const c1 = cat?.c1 ?? "#6d5dfb";
  const c2 = cat?.c2 ?? "#0ea5e9";

  /* ROUND 134-D — the smart recommendation engine. Inputs are the step-1/2
     draft fields (primitives), so the memo only recomputes when the tenant
     context genuinely changes — never on selection toggles. */
  const engine = useMemo(
    () =>
      recommendModules({
        systemId: draft.systemId,
        orgName: draft.org.name,
        country: draft.org.country,
        currency: draft.org.currency,
        role: draft.admin.role,
      }),
    [draft.systemId, draft.org.name, draft.org.country, draft.org.currency, draft.admin.role]
  );
  const recommendedKeys = engine.recommendedSet;

  /* ROUND 47 — the free trial replaces birth-time plan assignment: every
     new workspace runs FULL-FEATURED for TRIAL_DAYS days, so the wizard no longer
     caps the selection by the starter plan. The system's own catalog list
     (catMods below) is the only bound, matching what the server accepts. */

  /* Local selection set — the UI source of truth while this step is mounted.
     Initialized from the draft (buildSystemDraft pre-selects the full
     effective list — semantics preserved), synced back on every change. The
     ref mirror keeps the toggle callback identity stable, so memoized tiles
     whose props did not change skip re-rendering entirely. */
  const [selected, setSelected] = useState<ReadonlySet<string>>(() => new Set(draft.modules));
  const selectedRef = useRef<ReadonlySet<string>>(new Set(draft.modules));

  const [query, setQuery] = useState("");

  /* Full replacements (All / None / Recommended quick-sets) — the trial
     window is full-featured, so quick-sets apply the full selection. The
     recommended quick-set now applies the ENGINE's dynamic set (essential ∪
     recommended — never a fixed count), with a live count badge. */
  const quickBadge =
    recommendedKeys.length === 1
      ? t("wzModulesQuickBadgeOne")
      : t("wzModulesQuickBadgeMany", { count: fmtNum(recommendedKeys.length, lang) });

  const apply = useCallback(
    (keys: readonly string[]) => {
      const next = new Set(keys);
      selectedRef.current = next;
      setSelected(next);
      update({ modules: Array.from(next) });
    },
    [update]
  );

  const toggle = useCallback(
    (moduleId: string) => {
      // compute the next set OUTSIDE any state updater — calling the store
      // update inside a functional setState runs during React's render phase
      // and triggers "Cannot update a component while rendering" warnings.
      const current = selectedRef.current;
      const next = new Set(current);
      if (next.has(moduleId)) next.delete(moduleId);
      else next.add(moduleId);
      selectedRef.current = next;
      setSelected(next);
      update({ modules: Array.from(next) });
    },
    [update]
  );

  /* Localized reason strings for the engine's machine keys.
   * ROUND 168 — moduleDisplayName keeps the wizard's tiles in the system's
   * own sector vocabulary (SAMS: «الحضور والغياب»، «الطلاب»…), matching the
   * workspace + landing page. */
  const modName = useCallback(
    (id: string): string => moduleDisplayName(id, draft.systemId, lang),
    [draft.systemId, lang]
  );

  const reasonLabel = useCallback(
    (r: RecommendReasonKey): string => {
      if (r === "core") return t("wzRecReasonCore");
      if (r === "sectorMatch") return t("wzRecReasonSectorMatch");
      if (r === "orgKeyword") return t("wzRecReasonOrgKeyword");
      if (r === "vatCountry") return t("wzRecReasonVat");
      if (r === "roleFit") return t("wzRecReasonRoleFit");
      if (r === "universal") return t("wzRecReasonUniversal");
      return t("wzRecReasonPairs", { module: modName(r.slice("pairsWith:".length)) });
    },
    [t, modName]
  );

  const tiles = useMemo(
    () =>
      catMods.map((key) => {
        const name = modName(key);
        const m = MODULE_MAP[key];
        const rec = engine.perModule.get(key);
        const score = rec?.score ?? 0;
        const scoreLabel = `${fmtNum(score, lang)}%`;
        const matchLine = t("wzModulesMatchAria", { score: fmtNum(score, lang) });
        const reasons = (rec?.reasons ?? []).map(reasonLabel);
        const tooltip =
          reasons.length > 0 ? `${matchLine} — ${reasons.join(" · ")}` : matchLine;
        return {
          key,
          icon: m?.icon ?? "cubes",
          name,
          norm: normalizeSearch(name),
          tier: rec?.tier ?? "optional",
          scoreLabel,
          tooltip,
        };
      }),
    [catMods, modName, engine, lang, t, reasonLabel]
  );

  const visibleTiles = useMemo(() => {
    const q = normalizeSearch(query);
    return q ? tiles.filter((tl) => tl.norm.includes(q)) : tiles;
  }, [tiles, query]);

  /* ROUND 134-D — the three engine tiers replace the CORE_SIZE slicing. */
  const essentialTiles = useMemo(
    () => visibleTiles.filter((tl) => tl.tier === "essential"),
    [visibleTiles]
  );
  const recommendedTiles = useMemo(
    () => visibleTiles.filter((tl) => tl.tier === "recommended"),
    [visibleTiles]
  );
  const optionalTiles = useMemo(
    () => visibleTiles.filter((tl) => tl.tier === "optional"),
    [visibleTiles]
  );

  /* «لماذا هذه التوصية؟» — only signals that actually fired are surfaced. */
  const signalChips = useMemo(() => {
    const chips: Array<{ icon: string; text: string; tone: string }> = [];
    if (engine.signals.sector && cat) {
      chips.push({
        icon: "target",
        text: t("wzModulesSignalSector", { sector: lang === "ar" ? cat.nameAr : cat.nameEn }),
        tone: "violet",
      });
    }
    if (engine.signals.orgKeywords.length > 0) {
      chips.push({
        icon: "badge-check",
        text: t("wzModulesSignalOrg", {
          words: engine.signals.orgKeywords.join(lang === "ar" ? "، " : ", "),
        }),
        tone: "emerald",
      });
    }
    if (engine.signals.countryVat) {
      chips.push({ icon: "percent", text: t("wzModulesSignalVat"), tone: "amber" });
    }
    if (engine.signals.role === "manager") {
      chips.push({ icon: "user-cog", text: t("wzModulesSignalRole", { role: t("wzAdminRoleManager") }), tone: "sky" });
    }
    for (const p of engine.signals.topPairs) {
      chips.push({
        icon: "link",
        text: t("wzModulesSignalPair", { a: modName(p.module), b: modName(p.with) }),
        tone: "teal",
      });
    }
    return chips;
  }, [engine, cat, t, lang, modName]);

  const total = catMods.length;
  const count = selected.size;
  const pct = total > 0 ? Math.min(1, count / total) : 0;
  const sysName = system ? (lang === "ar" ? system.nameAr : system.nameEn) : draft.systemId;
  const catName = cat ? (lang === "ar" ? cat.nameAr : cat.nameEn) : "";

  return (
    <div className="step-in space-y-4">
      {/* heading + quick-set actions */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <StepHeading title={t("wzModulesTitle")} desc={t("wzModulesDesc")} />
        <div className="flex flex-wrap items-center gap-2">
          <Button
            type="button"
            size="sm"
            onClick={() => apply(recommendedKeys)}
            className="h-8 gap-1.5 rounded-lg px-3 text-[11px] font-extrabold text-white transition hover:brightness-110 active:scale-95"
            style={{ backgroundImage: grad(c1, c2), boxShadow: `0 8px 18px -8px ${hexAlpha(c1, 0.6)}` }}
          >
            <CatIcon name="sparkles" className="h-3 w-3" />
            {t("wzModulesQuickRecommended")}
            {/* live engine count badge — «الموصى بها · ٩ وحدات» */}
            <span className="rounded-full bg-white/25 px-1.5 py-0.5 text-[9.5px] font-extrabold leading-none tabular-nums">
              {quickBadge}
            </span>
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => apply(catMods)}
            className="h-8 rounded-lg border-slate-200 bg-white px-2.5 text-[11px] font-bold text-slate-600 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300"
          >
            {t("wzModulesAll")}
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => apply([])}
            className="h-8 rounded-lg border-slate-200 bg-white px-2.5 text-[11px] font-bold text-slate-600 hover:border-rose-300 hover:text-rose-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-300"
          >
            {t("wzModulesNone")}
          </Button>
        </div>
      </div>

      {/* system context strip — which system's units are being picked */}
      {system ? (
        <div
          className="relative flex items-center gap-3 overflow-hidden rounded-2xl border p-3.5"
          style={{
            borderColor: hexAlpha(c1, 0.35),
            backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.08)}, ${hexAlpha(c2, 0.08)})`,
          }}
        >
          <span
            aria-hidden="true"
            className="absolute -end-6 -top-10 h-24 w-24 rounded-full blur-2xl"
            style={{ background: hexAlpha(c1, 0.16) }}
          />
          <span
            className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
            style={{ backgroundImage: grad(c1, c2), boxShadow: `0 10px 24px -10px ${hexAlpha(c1, 0.8)}` }}
          >
            <CatIcon name={system.icon} className="h-4 w-4" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate font-display text-[14px] font-extrabold text-slate-900 dark:text-white">{sysName}</p>
            <p className="mt-0.5 flex min-w-0 items-center gap-1.5 text-[11px] font-bold text-slate-500 dark:text-slate-400">
              <span className="truncate">{catName}</span>
            </p>
          </div>
        </div>
      ) : null}

      {/* activation ring + live count */}
      <div className="flex items-center gap-3.5">
        <div
          className="relative h-14 w-14 shrink-0"
          role="progressbar"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={Math.round(pct * 100)}
          aria-label={t("wzModulesProgress")}
        >
          <svg viewBox="0 0 48 48" aria-hidden="true" className="h-14 w-14 -rotate-90">
            <circle cx="24" cy="24" r={RING_R} fill="none" strokeWidth="4" className="stroke-slate-200 dark:stroke-white/10" />
            <circle
              cx="24"
              cy="24"
              r={RING_R}
              fill="none"
              strokeWidth="4"
              strokeLinecap="round"
              stroke={`url(#${RING_GRAD_ID})`}
              strokeDasharray={RING_CIRC}
              strokeDashoffset={RING_CIRC * (1 - pct)}
              className="transition-[stroke-dashoffset] duration-500 ease-out"
            />
            <defs>
              <linearGradient id={RING_GRAD_ID} x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor={c1} />
                <stop offset="100%" stopColor={c2} />
              </linearGradient>
            </defs>
          </svg>
          <span className="absolute inset-0 grid place-items-center text-[11px] font-extrabold tabular-nums text-slate-700 dark:text-slate-200">
            {Math.round(pct * 100)}%
          </span>
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            {t("wzModulesProgress")}
          </p>
          <p className="mt-0.5 text-[13px] font-extrabold text-slate-900 dark:text-white" aria-live="polite">
            {count} {t("wzModulesUnits")} {t("wzModulesSelectedOf")} {total} — {t("wzModulesSelectedLabel")}
          </p>
          <p className="mt-0.5 text-[11px] leading-snug text-slate-500 dark:text-slate-400">{t("wzModulesHint")}</p>
          {/* ROUND 47 — full-featured free trial: every module is available */}
          <p className="mt-1.5 inline-flex items-center gap-1.5 rounded-full border border-amber-300/60 bg-amber-500/10 px-2.5 py-1 text-[10.5px] font-extrabold text-amber-600 dark:border-amber-500/40 dark:text-amber-300">
            <CatIcon name="sparkles" className="h-3 w-3 shrink-0" />
            {t("wzModulesTrialNote")}
          </p>
        </div>
      </div>

      {/* search (always visible above the scrolling list) */}
      <div className="relative">
        <CatIcon
          name="search"
          className="pointer-events-none absolute start-3.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400 dark:text-slate-500"
        />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t("wzModulesSearchPh")}
          aria-label={t("wzModulesSearchPh")}
          className="h-11 w-full rounded-xl border border-slate-200 bg-white ps-10 pe-10 text-[12.5px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:outline-none focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:placeholder:text-slate-500"
        />
        {query ? (
          <button
            type="button"
            onClick={() => setQuery("")}
            aria-label={t("wzModulesSearchClear")}
            className="absolute end-2 top-1/2 grid h-7 w-7 -translate-y-1/2 place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-white/10 dark:hover:text-slate-200"
          >
            <CatIcon name="x" className="h-3 w-3" />
          </button>
        ) : null}
      </div>

      {/* ROUND 134-D — WHY this recommendation? A premium violet→emerald
          gradient band listing the signals that actually fired (hidden
          entirely when the engine has nothing to explain). */}
      {signalChips.length > 0 ? (
        <div
          className="relative overflow-hidden rounded-2xl border border-violet-200/70 p-3.5 dark:border-violet-400/20"
          style={{
            backgroundImage: "linear-gradient(135deg, rgba(139,92,246,0.10), rgba(16,185,129,0.10))",
          }}
        >
          <span
            aria-hidden="true"
            className="absolute -end-8 -top-10 h-24 w-24 rounded-full bg-violet-500/15 blur-2xl"
          />
          <p className="relative flex items-center gap-1.5 text-[11px] font-extrabold text-violet-700 dark:text-violet-300">
            <CatIcon name="brain" className="h-3.5 w-3.5 shrink-0" />
            {t("wzModulesSmartTitle")}
          </p>
          <div className="relative mt-2 flex flex-wrap gap-1.5">
            {signalChips.map((chip, i) => (
              <span
                key={i}
                className={cn(
                  "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-extrabold",
                  SIGNAL_TONE[chip.tone]
                )}
              >
                <CatIcon name={chip.icon} className="h-2.5 w-2.5 shrink-0" />
                {chip.text}
              </span>
            ))}
          </div>
        </div>
      ) : null}

      {/* module groups / search empty state */}
      {visibleTiles.length === 0 && query.trim() !== "" ? (
        <div className="flex flex-col items-center gap-2 rounded-2xl border border-dashed border-slate-200 py-10 dark:border-white/10">
          <span className="grid h-11 w-11 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
            <CatIcon name="search" className="h-[18px] w-[18px]" />
          </span>
          <p className="text-[13px] font-extrabold text-slate-700 dark:text-slate-200">{t("wzModulesNoResults")}</p>
          <p className="max-w-xs text-center text-[11.5px] leading-snug text-slate-500 dark:text-slate-400">
            {t("wzModulesNoResultsDesc")}
          </p>
        </div>
      ) : (
        <div className={LIST_SCROLL}>
          <ModuleGroup
            headingId="wz-mod-core"
            label={t("wzModulesCore")}
            desc={t("wzModulesCoreDesc")}
            icon="zap-fast"
            tiles={essentialTiles}
            selected={selected}
            c1={c1}
            c2={c2}
            onToggle={toggle}
          />
          <ModuleGroup
            headingId="wz-mod-rec"
            label={t("wzModulesRecommended")}
            desc={t("wzModulesSmartRecDesc")}
            icon="sparkles"
            recommendedLabel={t("wzModulesRecommended")}
            recommendedDesc={t("wzModulesRecommendedDesc")}
            tiles={recommendedTiles}
            selected={selected}
            c1={c1}
            c2={c2}
            onToggle={toggle}
          />
          <ModuleGroup
            headingId="wz-mod-opt"
            label={t("wzModulesOptional")}
            desc={t("wzModulesOptionalDesc")}
            icon="sliders"
            tiles={optionalTiles}
            selected={selected}
            c1={c1}
            c2={c2}
            onToggle={toggle}
          />
        </div>
      )}
    </div>
  );
}
