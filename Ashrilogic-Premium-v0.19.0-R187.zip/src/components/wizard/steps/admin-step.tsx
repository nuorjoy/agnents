"use client";

/**
 * Ashrilogic — wizard step 4 — admin account + workspace password.
 * The password gates dashboard sign-in (my-systems) and is stored as a
 * server-side digest; the strength meter and generator nudge owners toward
 * non-trivial credentials.
 *
 * ROUND 82 (batch-5 ②) — OWNER-ACCOUNT REUSE: when the wizard was launched
 * from the «أنظمتك المنشأة» screen by a signed-in owner (store.wizardOwner),
 * the step opens in "reuse my current account" mode:
 *  - name prefilled, email LOCKED to the owner's address (one account!),
 *  - a single password field («كلمة المرور الحالية») verified live against
 *    POST /api/instances/mine/verify-password — the green «تم التحقق» chip
 *    is the only way forward, guaranteeing the new system is provisioned
 *    with the exact SAME credentials,
 *  - "استخدام بريد مختلف" exits to the classic fresh-account form.
 * Anonymous visitors see the classic form unchanged.
 *
 * ROUND 84 (84-CONTACT) — the admin email field is the unified
 * PremiumEmailInput; the reuse mode maps to its `locked` prop (read-only
 * field + the emerald «بريد حسابك» chip + trailing lock) so the owner-account
 * behavior is preserved exactly.
 *
 * ROUND 134-E — live EMAIL availability: a debounced (500ms) probe of
 * POST /api/instances/check-availability renders the emerald «متاح
 * للاستخدام» / rose «مستخدم مسبقاً» chip under the field. Skipped in the
 * reuse flow (the owner's account email is registered BY DESIGN) and for
 * shapes that fail EMAIL_RE. The server verdict is the SAME deep engine
 * the submit-time guard runs — the chip cannot lie about the 409.
 */
import { useEffect, useMemo, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { CATEGORY_MAP, SYSTEM_MAP } from "@/data/catalog";
import { useT, type I18nKey } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import { verifyOwnerPassword, checkTenantAvailability } from "@/lib/api-client";
/*
 * ROUND 138 — the password generator moved to the shared CSPRNG module
 * (src/lib/password.ts): the former local Math.random "memorable" recipe
 * carried ≈ 20 bits of entropy (crackable in seconds); both this wizard
 * and the Super Admin subscriber sheet now mint from the ONE rejection-
 * sampled crypto.getRandomValues generator (≈ 70.5 bits, every class
 * guaranteed, crypto-shuffled). Same call-site behavior: one click fills
 * the password + confirm pair.
 */
import { generateSecurePassword } from "@/lib/password";
import { CatIcon } from "@/components/icon";
import { grad, cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { PremiumEmailInput } from "@/components/ui/premium-contact";
import { ShakeField, WZ_INPUT, WZ_LABEL, EMAIL_RE, type WizardStepProps } from "@/components/wizard/wizard-shared";

const ROLES = [
  { value: "owner", icon: "crown", key: "wzAdminRoleOwner" },
  { value: "manager", icon: "user-tie", key: "wzAdminRoleManager" },
] as const;

/** Password strength: length + character classes → 0..4 score. */
function passwordScore(password: string): number {
  if (!password) return 0;
  let score = 0;
  if (password.length >= 8) score += 1;
  if (password.length >= 10) score += 1;
  const classes = [/[a-z]/, /[A-Z]/, /[0-9]/, /[^a-zA-Z0-9]/].filter((re) => re.test(password)).length;
  if (classes >= 2) score += 1;
  if (classes >= 3 || password.length >= 14) score += 1;
  return Math.min(4, score);
}

const STRENGTH = [
  { key: "wzPwWeak", c: "#f43f5e" },
  { key: "wzPwFair", c: "#f97316" },
  { key: "wzPwGood", c: "#eab308" },
  { key: "wzPwStrong", c: "#22c55e" },
  { key: "wzPwStrong", c: "#10b981" },
] as const;

/** ROUND 138 — delegated to the shared CSPRNG generator (src/lib/password.ts). */
function generatePassword(): string {
  return generateSecurePassword();
}

function PasswordField({
  id,
  labelKey,
  value,
  onChange,
  invalid,
  placeholder,
  autoComplete,
}: {
  id: string;
  labelKey: I18nKey;
  value: string;
  onChange: (v: string) => void;
  invalid?: boolean;
  placeholder?: string;
  autoComplete?: string;
}) {
  const { t } = useT();
  const [visible, setVisible] = useState(false);
  return (
    <div className="relative">
      <Label htmlFor={id} className={WZ_LABEL}>
        {t(labelKey)} <span className="text-rose-500">*</span>
      </Label>
      <div className="relative">
        <Input
          id={id}
          type={visible ? "text" : "password"}
          dir="ltr"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          autoComplete={autoComplete}
          className={`${WZ_INPUT} pe-11 text-start ${invalid ? "border-rose-400 focus-visible:ring-rose-400" : ""}`}
          aria-invalid={invalid || undefined}
        />
        <button
          type="button"
          onClick={() => setVisible((v) => !v)}
          aria-label={t(visible ? "wzPwHide" : "wzPwShow")}
          className="absolute inset-y-0 end-0 me-2.5 grid h-7 w-7 place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-white/10 dark:hover:text-slate-200"
        >
          <CatIcon name={visible ? "eye-off" : "eye"} className="h-[14px] w-[14px]" />
        </button>
      </div>
    </div>
  );
}

export function AdminStep({ draft, update, error }: WizardStepProps) {
  const { t, lang } = useT();
  const admin = draft.admin;
  const system = SYSTEM_MAP[draft.systemId];
  const cat = system ? CATEGORY_MAP[system.c] : undefined;
  const c1 = cat?.c1 ?? "#6d5dfb";
  const c2 = cat?.c2 ?? "#0ea5e9";

  /* ROUND 82 — the signed-in owner that launched this wizard (if any) */
  const wizardOwner = useAppStore((s) => s.wizardOwner);

  /* reuse mode = the owner context exists AND the draft still carries the
   * owner's email (leaving it — via "use a different email" — exits reuse) */
  const reuseActive = useMemo(
    () =>
      !!wizardOwner &&
      admin.email.trim().toLowerCase() === wizardOwner.email.trim().toLowerCase(),
    [wizardOwner, admin.email]
  );

  /* prefill name/email from the owner context the moment the step mounts
   * with a blank admin section (only once per owner) */
  useEffect(() => {
    if (wizardOwner && !admin.email.trim() && !admin.name.trim()) {
      update({
        admin: { ...admin, name: wizardOwner.name || admin.name, email: wizardOwner.email },
        ownerVerified: false,
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* live server verification of the CURRENT password (reuse mode only) */
  const [verifyError, setVerifyError] = useState<string | null>(null);
  const verify = useMutation({
    mutationFn: () => verifyOwnerPassword(admin.password),
    onSuccess: (data) => {
      setVerifyError(null);
      /* confirmed: the new system will use the exact same credentials —
       * mirror the password into the confirm slot + stamp the draft */
      update({
        ownerVerified: true,
        admin: { ...admin, confirm: admin.password },
      });
      if (data.admin?.name && !admin.name.trim()) {
        update({ admin: { ...admin, name: data.admin.name, confirm: admin.password } });
      }
    },
    onError: (e: Error) => {
      update({ ownerVerified: false });
      setVerifyError(e.message || t("wzOwnerVerifyBad"));
    },
  });

  const setAdmin = (patch: Partial<typeof admin>) => update({ admin: { ...admin, ...patch } });

  /* ROUND 134-E — live email availability probe (see the module header).
   * Debounced 500ms; a new keystroke cancels the stale verdict; probe
   * failures reset silently (never blocks typing or submit). The verdict
   * is stored WITH the value it probed, so the RENDERED state is DERIVED
   * (stale verdicts read as idle — no synchronous setState in the effect). */
  const [emailProbe, setEmailProbe] = useState<{
    value: string;
    verdict: "checking" | "free" | "used";
  } | null>(null);
  const emailAvail =
    emailProbe && emailProbe.value === admin.email.trim() ? emailProbe.verdict : "idle";
  useEffect(() => {
    const email = admin.email.trim();
    if (reuseActive || !EMAIL_RE.test(email)) return; /* derived state stays idle */
    let live = true;
    const timer = setTimeout(() => {
      setEmailProbe({ value: email, verdict: "checking" });
      void checkTenantAvailability({ email })
        .then((res) => {
          if (live) setEmailProbe({ value: email, verdict: res.emailFree ? "free" : "used" });
        })
        .catch(() => {
          if (live) setEmailProbe(null);
        });
    }, 500);
    return () => {
      live = false;
      clearTimeout(timer);
    };
  }, [admin.email, reuseActive]);

  /* editing the password after a successful verify invalidates it */
  const onReusePasswordChange = (v: string) => {
    if (draft.ownerVerified) update({ ownerVerified: false });
    setVerifyError(null);
    setAdmin({ password: v, confirm: "" });
  };

  /* exiting reuse mode → fresh-account form (classic behavior) */
  const exitReuse = () => {
    setVerifyError(null);
    update({
      ownerVerified: undefined,
      admin: { ...admin, email: "", password: "", confirm: "" },
    });
  };

  const score = passwordScore(admin.password ?? "");
  const strength = STRENGTH[score];

  return (
    <div className="step-in">
      <div>
        <h3 className="font-display text-lg font-extrabold text-slate-900 dark:text-white">{t("wzAdminTitle")}</h3>
        <p className="mt-1 text-[12.5px] text-slate-500 dark:text-slate-400">{t("wzAdminDesc")}</p>
      </div>

      {/* ROUND 82 — the owner-reuse banner: this system joins the SAME account */}
      {wizardOwner && reuseActive ? (
        <div className="relative mt-4 overflow-hidden rounded-2xl border border-emerald-300/60 bg-linear-to-l from-emerald-50/90 to-teal-50/50 p-3.5 dark:border-emerald-500/30 dark:from-emerald-500/10 dark:to-teal-500/5">
          <span
            className="pointer-events-none absolute -end-8 -top-10 h-28 w-28 rounded-full"
            style={{ background: "radial-gradient(circle, rgba(16,185,129,0.18), transparent 70%)" }}
            aria-hidden="true"
          />
          <div className="flex items-start gap-3">
            <span
              className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-linear-to-br from-emerald-500 to-teal-600 text-white shadow-lg shadow-emerald-500/25"
              aria-hidden="true"
            >
              <CatIcon name="circle-check" className="h-[15px] w-[15px]" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="flex flex-wrap items-center gap-2 text-[12.5px] font-extrabold text-emerald-700 dark:text-emerald-300">
                {t("wzOwnerReuseTitle")}
                <span className="inline-flex items-center gap-1 rounded-full border border-emerald-300/70 bg-white/80 px-2 py-0.5 text-[9.5px] font-extrabold text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300">
                  <CatIcon name="lock" className="h-2.5 w-2.5" />
                  {t("wzOwnerStaySignedIn")}
                </span>
              </p>
              <p className="mt-1 text-[11px] font-semibold leading-relaxed text-emerald-700/80 dark:text-emerald-400/80">
                {t("wzOwnerReuseDesc")}
              </p>
              <button
                type="button"
                onClick={exitReuse}
                className="mt-2 inline-flex items-center gap-1.5 text-[10.5px] font-extrabold text-slate-500 underline decoration-dotted underline-offset-2 transition hover:text-brand-600 dark:text-slate-400 dark:hover:text-brand-300"
              >
                <CatIcon name="user-round-plus" className="h-3 w-3" />
                {t("wzOwnerUseDifferent")}
              </button>
            </div>
          </div>
        </div>
      ) : null}

      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <ShakeField token={error?.field === "admin-name" ? error.token : 0}>
            <Label htmlFor="wz-admin-name" className={WZ_LABEL}>
              {t("wzAdminName")} <span className="text-rose-500">*</span>
            </Label>
            <Input
              id="wz-admin-name"
              value={admin.name}
              onChange={(e) => setAdmin({ name: e.target.value })}
              placeholder={t("wzAdminNamePh")}
              autoComplete="name"
              className={WZ_INPUT}
              aria-invalid={error?.field === "admin-name" || undefined}
            />
          </ShakeField>
        </div>

        <div className="sm:col-span-2">
          <ShakeField token={error?.field === "admin-email" ? error.token : 0}>
            <PremiumEmailInput
              id="wz-admin-email"
              label="wzAdminEmail"
              value={admin.email}
              onChange={(email) => setAdmin({ email })}
              required
              placeholder="wzAdminEmailPh"
              autoComplete="email"
              locked={reuseActive}
              lockedChip="wzOwnerEmailLocked"
              invalid={error?.field === "admin-email" || emailAvail === "used" || undefined}
            />
          </ShakeField>
          <p className="mt-2 flex items-center gap-2 text-[11.5px] font-semibold text-slate-500 dark:text-slate-400">
            <CatIcon name="mail" className="h-[12px] w-[12px] text-brand-500" />
            {reuseActive ? t("wzOwnerEmailNote") : t("wzAdminInviteNote")}
          </p>
          {/* ROUND 134-E — availability verdict chip (fresh-account flow only) */}
          {!reuseActive && emailAvail === "free" ? (
            <span
              role="status"
              className="mt-2 inline-flex items-center gap-1.5 rounded-full border border-emerald-400/70 bg-emerald-500/15 px-3 py-1 text-[11px] font-extrabold text-emerald-700 dark:border-emerald-500/40 dark:bg-emerald-500/15 dark:text-emerald-300"
            >
              <CatIcon name="circle-check" className="h-3.5 w-3.5" />
              {t("wzAvailEmailFree")}
            </span>
          ) : null}
          {!reuseActive && emailAvail === "used" ? (
            <span
              role="alert"
              className="mt-2 inline-flex items-center gap-1.5 rounded-full border border-rose-300/80 bg-rose-500/10 px-3 py-1 text-[11px] font-extrabold text-rose-600 dark:border-rose-500/40 dark:bg-rose-500/10 dark:text-rose-300"
            >
              <CatIcon name="circle-alert" className="h-3.5 w-3.5" />
              {t("wzAvailEmailUsed")}
            </span>
          ) : null}
        </div>

        {/* workspace password */}
        <div className="sm:col-span-2 grid gap-4 rounded-2xl border border-slate-200 bg-slate-50/50 p-4 dark:border-white/10 dark:bg-white/[0.02]">
          <div className="flex items-center gap-2.5">
            <span
              className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white shadow-md"
              style={{
                backgroundImage: reuseActive
                  ? "linear-gradient(135deg,#10b981,#0e7490)"
                  : "linear-gradient(135deg,#10b981,#0e7490)",
              }}
            >
              <CatIcon name="key-round" className="h-[12px] w-[12px]" />
            </span>
            <div className="min-w-0">
              <p className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                {reuseActive ? t("wzOwnerPwSectionTitle") : t("wzPwSectionTitle")}
              </p>
              <p className="truncate text-[11px] text-slate-500 dark:text-slate-400">
                {reuseActive ? t("wzOwnerPwSectionDesc") : t("wzPwSectionDesc")}
              </p>
            </div>
            {!reuseActive ? (
              <button
                type="button"
                onClick={() => {
                  const generated = generatePassword();
                  setAdmin({ password: generated, confirm: generated });
                }}
                className="ms-auto inline-flex h-9 shrink-0 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-[12px] font-extrabold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:bg-white/5 dark:text-slate-300"
                title={t("wzPwGenerate")}
              >
                <CatIcon name="dice" className="h-[13px] w-[13px]" aria-hidden="true" />
                <span>{t("wzPwGenerate")}</span>
              </button>
            ) : null}
          </div>

          {reuseActive ? (
            /* ---------- reuse mode: ONE field + live verification ---------- */
            <div className="space-y-3">
              <ShakeField token={error?.field === "admin-password" ? error.token : 0}>
                <PasswordField
                  id="wz-admin-password"
                  labelKey="wzOwnerPwLabel"
                  value={admin.password ?? ""}
                  onChange={onReusePasswordChange}
                  invalid={!!verifyError || error?.field === "admin-password"}
                  placeholder="••••••••"
                  autoComplete="current-password"
                />
              </ShakeField>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => verify.mutate()}
                  disabled={!admin.password || verify.isPending || draft.ownerVerified === true}
                  className="inline-flex h-9 items-center gap-2 rounded-xl border border-emerald-300/70 bg-emerald-500/10 px-4 text-[11.5px] font-extrabold text-emerald-700 transition hover:bg-emerald-500/20 active:scale-95 disabled:cursor-not-allowed disabled:opacity-50 dark:border-emerald-500/40 dark:bg-emerald-500/10 dark:text-emerald-300 dark:hover:bg-emerald-500/20"
                >
                  {verify.isPending ? (
                    <CatIcon name="refresh-cw" className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <CatIcon name="fingerprint" className="h-3.5 w-3.5" />
                  )}
                  {t("wzOwnerVerifyBtn")}
                </button>

                {draft.ownerVerified === true ? (
                  <span
                    role="status"
                    className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/70 bg-emerald-500/15 px-3 py-1 text-[11px] font-extrabold text-emerald-700 dark:border-emerald-500/40 dark:bg-emerald-500/15 dark:text-emerald-300"
                  >
                    <CatIcon name="circle-check" className="h-3.5 w-3.5" />
                    {t("wzOwnerVerifiedChip")}
                  </span>
                ) : (
                  <span className="text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                    {t("wzOwnerVerifyHint")}
                  </span>
                )}
              </div>

              {verifyError ? (
                <p
                  role="alert"
                  className="flex items-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50/80 px-3 py-2 text-[11px] font-bold text-rose-600 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-300"
                >
                  <CatIcon name="circle-alert" className="h-3.5 w-3.5 shrink-0" />
                  {verifyError}
                </p>
              ) : null}
            </div>
          ) : (
            /* ---------- classic mode: password + confirm ---------- */
            <>
              <div className="grid gap-4 sm:grid-cols-2">
                <ShakeField token={error?.field === "admin-password" ? error.token : 0}>
                  <PasswordField
                    id="wz-admin-password"
                    labelKey="wzPwLabel"
                    value={admin.password ?? ""}
                    onChange={(v) => setAdmin({ password: v })}
                    invalid={error?.field === "admin-password"}
                    placeholder="••••••••"
                    autoComplete="new-password"
                  />
                </ShakeField>
                <ShakeField token={error?.field === "admin-confirm" ? error.token : 0}>
                  <PasswordField
                    id="wz-admin-confirm"
                    labelKey="wzPwConfirm"
                    value={admin.confirm ?? ""}
                    onChange={(v) => setAdmin({ confirm: v })}
                    invalid={error?.field === "admin-confirm"}
                    placeholder="••••••••"
                    autoComplete="new-password"
                  />
                </ShakeField>
              </div>

              {/* strength meter */}
              <div className="flex items-center gap-3">
                <div className="flex flex-1 gap-1.5" aria-hidden="true">
                  {[0, 1, 2, 3].map((i) => (
                    <span
                      key={i}
                      className="h-1.5 flex-1 rounded-full transition-all duration-300"
                      style={{
                        backgroundColor: i < score ? strength.c : "rgba(148,163,184,0.25)",
                      }}
                    />
                  ))}
                </div>
                <span
                  className={cn(
                    "shrink-0 rounded-full px-2 py-0.5 text-[10px] font-extrabold transition-colors",
                    score === 0
                      ? "bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500"
                      : "text-white"
                  )}
                  style={score > 0 ? { backgroundColor: strength.c } : undefined}
                >
                  {score === 0 ? t("wzPwNone") : t(strength.key)}
                </span>
              </div>
            </>
          )}
        </div>

        <div className="sm:col-span-2">
          <span className={WZ_LABEL}>{t("wzAdminRole")}</span>
          <div
            className="grid grid-cols-2 gap-2.5"
            role="radiogroup"
            aria-label={t("wzAdminRole")}
          >
            {ROLES.map((role) => {
              const active = admin.role === role.value;
              return (
                <button
                  key={role.value}
                  type="button"
                  role="radio"
                  aria-checked={active}
                  onClick={() => setAdmin({ role: role.value })}
                  className={cn(
                    "flex items-center gap-2.5 rounded-xl border p-3 text-start transition",
                    active
                      ? "border-brand-400 bg-brand-50/60 dark:border-brand-500/50 dark:bg-brand-500/10"
                      : "border-slate-200 bg-white hover:border-brand-300 dark:border-white/10 dark:bg-white/[0.03]"
                  )}
                >
                  <span
                    className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white"
                    style={{
                      backgroundImage: active ? grad(c1, c2) : "linear-gradient(135deg,#cbd5e1,#94a3b8)",
                    }}
                  >
                    <CatIcon name={role.icon} className="h-[11px] w-[11px]" />
                  </span>
                  <span className="text-[12px] font-bold text-slate-700 dark:text-slate-200">{t(role.key)}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="sm:col-span-2">
          <div className="flex items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-slate-50/60 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
            <div className="flex items-center gap-3">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-linear-to-br from-emerald-500 to-teal-600 text-white">
                <CatIcon name="fingerprint" className="h-[12px] w-[12px]" />
              </span>
              <div className="min-w-0">
                <p className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">{t("wzAdmin2FA")}</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">{t("wzAdmin2FADesc")}</p>
              </div>
            </div>
            <Switch
              checked={admin.twoFA}
              onCheckedChange={(v) => setAdmin({ twoFA: v })}
              aria-label={t("wzAdmin2FA")}
            />
          </div>
        </div>
      </div>

      <p className="mt-4 text-[11px] font-semibold text-slate-400 dark:text-slate-500">
        {reuseActive
          ? lang === "ar"
            ? "سيُنشأ النظام الجديد بنفس البريد وكلمة المرور الحاليين — حساب واحد لكل أنظمتك."
            : "The new system is provisioned with your current email and password — one account for all your systems."
          : lang === "ar"
            ? "كلمة المرور تُخزَّن كبصمة مشفّرة — استخدمها لتسجيل الدخول إلى لوحة النظام."
            : "Stored as a salted digest — use it to sign in to the system dashboard."}
      </p>
    </div>
  );
}
