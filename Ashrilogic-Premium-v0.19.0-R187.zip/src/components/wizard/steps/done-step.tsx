"use client";

/**
 * Wizard step 7 — done: animated check (check-pop), 7 confetti squares in
 * category colors, the info cards and the real LAUNCH button. Includes the
 * premium "mobile app coming soon" notice so expectations are set right at
 * the setup moment (the web system is complete; the app follows soon).
 *
 * ROUND 144 — premium, PRECISE step-7/7 details (owner directive): the
 * readiness subtitle under the description, the refined 3-column summary
 * grid (chosen system icon tile + org + modules + workspace currency &
 * timezone + admin email), the FINAL readiness checklist (four verified
 * rows, staggered card-in, live modules count) and the launch hint under
 * the button.
 *
 * ROUND MFA — when the admin opted into two-factor at step 4 (admin-step),
 * the wizard stores the flag in draft.admin.twoFA. The flag alone does NOT
 * create a MfaSecret row (the login flow reads the MfaSecret table, not
 * adminJson.twoFA), so without an explicit enrollment step the user would
 * log in next time and 2FA would silently be off. The wizard-overlay now
 * defers the post-launch transition: onSuccess captures instance.id into
 * createdInstanceId (when twoFA is on) and mounts this done-step in its
 * POST-LAUNCH posture. The DoneMfaCard below drives the EXISTING two-step
 * TOTP enrollment via POST + PUT /api/instances/[id]/mfa/setup (the session
 * is already set after launch), and the LAUNCH button morphs into a
 * "Continue to dashboard" control once createdInstanceId is set. When
 * twoFA is off, the legacy behavior is preserved unchanged.
 */
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { CATEGORY_MAP, SYSTEM_MAP } from "@/data/catalog";
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { fmtNum, grad, hexAlpha } from "@/lib/utils";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import type { CSSProperties } from "react";
import type { WizardDraft, MfaSetupDTO } from "@/lib/types";
import { startInstanceMfaSetup, confirmInstanceMfaSetup } from "@/lib/api-client";
import { OtpInput, normalizeDigits, PremiumQr } from "@/components/security/security-cards";

const CONFETTI_LEFTS = ["10%", "30%", "50%", "70%", "88%", "22%", "78%"];

/* ===================== ROUND MFA — done-step 2FA card ===================== */

/**
 * Post-launch TOTP enrollment card. Lives inside the done-step so the new
 * owner finishes 2FA BEFORE first dashboard entry (the wizard-overlay
 * defers the transition until the owner confirms/skips here). Uses the
 * existing /api/instances/[id]/mfa/setup endpoints unchanged.
 *
 * States: idle → setup (QR + secret + 6-digit input) → confirmed (backup
 * codes + "تم التفعيل" badge). On any failure the card surfaces the error
 * inline and stays interactive (the owner can retry without restart).
 */
function DoneMfaCard({
  instanceId,
  onContinue,
}: {
  instanceId: string;
  onContinue: () => void;
}) {
  const { t, lang } = useT();
  const [setup, setSetup] = useState<MfaSetupDTO | null>(null);
  const [code, setCode] = useState("");
  const [backupCodes, setBackupCodes] = useState<string[] | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [confirmed, setConfirmed] = useState(false);

  const startSetup = useMutation({
    mutationFn: () => startInstanceMfaSetup(instanceId),
    onSuccess: (data) => {
      setErrorMsg(null);
      setCode("");
      setBackupCodes(null);
      setSetup(data);
    },
    onError: (error: Error) => {
      setErrorMsg(error.message || t("wzDoneMfaError"));
    },
  });

  const confirmSetup = useMutation({
    mutationFn: (sixDigits: string) => confirmInstanceMfaSetup(instanceId, sixDigits),
    onSuccess: (data) => {
      setErrorMsg(null);
      setBackupCodes(data.backupCodes);
      setConfirmed(true);
      toast.success(t("wzDoneMfaEnabledToast"));
    },
    onError: (error: Error) => {
      setErrorMsg(error.message || t("wzDoneMfaError"));
      setCode("");
    },
  });

  const codeReady = normalizeDigits(code).replace(/\D/g, "").length === 6;
  const c1 = "#10b981";
  const c2 = "#047857";

  /* ---- confirmed state: backup codes + done ---- */
  if (confirmed) {
    return (
      <section
        aria-label={t("wzDoneMfaCardAria")}
        className="mt-3 overflow-hidden rounded-2xl border border-emerald-300/70 bg-linear-to-l from-emerald-50/90 to-teal-50/50 text-start dark:border-emerald-500/30 dark:from-emerald-500/10 dark:to-teal-500/5"
      >
        <div className="flex items-center gap-3 border-b border-emerald-200/60 p-3.5 dark:border-emerald-500/15">
          <span
            className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
            style={{ backgroundImage: grad(c1, c2), boxShadow: `0 12px 24px -10px ${hexAlpha(c1, 0.8)}` }}
            aria-hidden="true"
          >
            <CatIcon name="shield-check" className="h-[16px] w-[16px]" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="flex flex-wrap items-center gap-2 text-[12.5px] font-extrabold text-emerald-700 dark:text-emerald-300">
              {t("wzDoneMfaConfirmed")}
              <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 px-2 py-px text-[11px] font-extrabold text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300">
                <CatIcon name="circle-check" className="h-2.5 w-2.5" />
                2FA
              </span>
            </p>
            <p className="mt-0.5 text-[11px] leading-relaxed text-emerald-700/80 dark:text-emerald-400/80">
              {t("wzDoneMfaBackupHint")}
            </p>
          </div>
        </div>
        {backupCodes ? (
          <div className="p-3.5">
            <p className="text-[10.5px] font-extrabold uppercase tracking-wider text-emerald-700/80 dark:text-emerald-300/80">
              {t("wzDoneMfaBackupTitle")}
            </p>
            <div className="mt-2 grid grid-cols-2 gap-2" dir="ltr">
              {backupCodes.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => {
                    void navigator.clipboard.writeText(c).then(() => toast.success(t("secCopied")));
                  }}
                  title={t("secCopyTip")}
                  className="group inline-flex items-center justify-between gap-1.5 rounded-lg border border-emerald-200/70 bg-white px-2.5 py-1 font-mono text-[11.5px] font-bold text-emerald-700 transition hover:border-emerald-300 hover:text-emerald-800 dark:border-emerald-500/20 dark:bg-white/[0.05] dark:text-emerald-300 dark:hover:text-emerald-200"
                >
                  <span className="truncate">{c}</span>
                  <CatIcon name="copy" className="h-3 w-3 shrink-0 opacity-50 transition group-hover:opacity-100" />
                  <span className="sr-only">{t("secCopyTip")}</span>
                </button>
              ))}
            </div>
            <Button
              type="button"
              onClick={onContinue}
              className="mt-3 h-10 w-full rounded-xl text-[12.5px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:brightness-110 active:scale-95"
              style={{ backgroundImage: grad(c1, c2) }}
            >
              <CatIcon name={lang === "ar" ? "arrow-left" : "arrow-right"} className="h-4 w-4" />
              {t("wzDoneMfaContinue")}
            </Button>
          </div>
        ) : null}
      </section>
    );
  }

  /* ---- setup state: QR + secret + OTP ---- */
  if (setup) {
    return (
      <section
        aria-label={t("wzDoneMfaCardAria")}
        className="mt-3 overflow-hidden rounded-2xl border border-emerald-300/70 bg-linear-to-l from-emerald-50/90 to-teal-50/50 text-start dark:border-emerald-500/30 dark:from-emerald-500/10 dark:to-teal-500/5"
      >
        <div className="flex items-center gap-3 border-b border-emerald-200/60 p-3.5 dark:border-emerald-500/15">
          <span
            className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
            style={{ backgroundImage: grad(c1, c2), boxShadow: `0 12px 24px -10px ${hexAlpha(c1, 0.8)}` }}
            aria-hidden="true"
          >
            <CatIcon name="qr-code" className="h-[16px] w-[16px]" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[12.5px] font-extrabold text-emerald-700 dark:text-emerald-300">{t("wzDoneMfaTitle")}</p>
            <p className="mt-0.5 text-[11px] leading-relaxed text-emerald-700/80 dark:text-emerald-400/80">
              {t("wzDoneMfaScanHint")}
            </p>
          </div>
        </div>
        <div className="space-y-3.5 p-3.5">
          <div className="flex flex-col items-center gap-3 sm:flex-row sm:items-start">
            <PremiumQr svg={setup.qrSvg} c1={c1} c2={c2} icon="shield-check" aria={t("secQrAria")} size="md" />
            <div className="min-w-0 flex-1 space-y-2">
              <p className="text-[10.5px] font-extrabold uppercase tracking-wide text-emerald-700/80 dark:text-emerald-300/80">
                {t("secManualKey")}
              </p>
              <button
                type="button"
                onClick={() => {
                  void navigator.clipboard.writeText(setup.secret).then(() => toast.success(t("secCopied")));
                }}
                title={t("secCopyTip")}
                className="inline-flex max-w-full items-center gap-1.5 rounded-lg border border-emerald-200/70 bg-white px-2.5 py-1 font-mono text-[11.5px] font-bold text-emerald-700 transition hover:border-emerald-300 dark:border-emerald-500/20 dark:bg-white/[0.05] dark:text-emerald-300"
              >
                <span className="truncate" dir="ltr">{setup.secret}</span>
                <CatIcon name="copy" className="h-3 w-3 shrink-0 opacity-50" />
                <span className="sr-only">{t("secCopyTip")}</span>
              </button>
            </div>
          </div>
          <div className="space-y-2">
            <p className="flex items-center justify-between text-[11.5px] font-bold text-emerald-700/90 dark:text-emerald-300/90">
              <span>{t("wzDoneMfaCodeLabel")} <span className="text-rose-500">*</span></span>
              <span className="text-[10px] font-bold text-emerald-700/60 dark:text-emerald-300/60">{t("otpAriaLabel")}</span>
            </p>
            <OtpInput
              idPrefix="wz-mfa"
              value={code}
              onChange={setCode}
              disabled={confirmSetup.isPending}
              invalid={confirmSetup.isError}
              onComplete={(c) => confirmSetup.mutate(c)}
              onEnter={(c) => confirmSetup.mutate(c)}
              autoFocus
            />
          </div>
          {errorMsg ? (
            <p role="alert" className="flex items-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50/80 px-3 py-2 text-[11px] font-bold text-rose-600 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-300">
              <CatIcon name="circle-alert" className="h-3.5 w-3.5 shrink-0" />
              {errorMsg}
            </p>
          ) : null}
          <div className="flex flex-wrap gap-2">
            <Button
              type="button"
              disabled={!codeReady || confirmSetup.isPending}
              onClick={() => confirmSetup.mutate(normalizeDigits(code))}
              className="h-10 flex-1 rounded-xl text-[12.5px] font-extrabold text-white shadow-lg shadow-emerald-500/25 disabled:opacity-50"
              style={{ backgroundImage: grad(c1, c2) }}
            >
              <CatIcon name={confirmSetup.isPending ? "refresh-cw" : "shield-check"} className={`h-4 w-4 ${confirmSetup.isPending ? "animate-spin" : ""}`} />
              {confirmSetup.isPending ? t("wzDoneMfaConfirming") : t("sec2faConfirm")}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={onContinue}
              disabled={confirmSetup.isPending}
              className="h-10 rounded-xl border-emerald-300/70 bg-white px-4 text-[12.5px] font-bold text-emerald-700 transition hover:bg-emerald-50 disabled:opacity-50 dark:border-emerald-500/30 dark:bg-white/[0.05] dark:text-emerald-300 dark:hover:bg-white/[0.08]"
            >
              {t("wzDoneMfaSkip")}
            </Button>
          </div>
        </div>
      </section>
    );
  }

  /* ---- idle state: title + start CTA + skip ---- */
  return (
    <section
      aria-label={t("wzDoneMfaCardAria")}
      className="mt-3 overflow-hidden rounded-2xl border border-emerald-300/70 bg-linear-to-l from-emerald-50/90 to-teal-50/50 text-start dark:border-emerald-500/30 dark:from-emerald-500/10 dark:to-teal-500/5"
    >
      <div className="flex items-center gap-3 border-b border-emerald-200/60 p-3.5 dark:border-emerald-500/15">
        <span
          className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
          style={{ backgroundImage: grad(c1, c2), boxShadow: `0 12px 24px -10px ${hexAlpha(c1, 0.8)}` }}
          aria-hidden="true"
        >
          <CatIcon name="shield-plus" className="h-[16px] w-[16px]" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[12.5px] font-extrabold text-emerald-700 dark:text-emerald-300">{t("wzDoneMfaTitle")}</p>
          <p className="mt-0.5 text-[11px] leading-relaxed text-emerald-700/80 dark:text-emerald-400/80">{t("wzDoneMfaDesc")}</p>
        </div>
      </div>
      <div className="flex flex-wrap gap-2 p-3.5">
        <Button
          type="button"
          disabled={startSetup.isPending}
          onClick={() => startSetup.mutate()}
          className="h-10 flex-1 rounded-xl text-[12.5px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-50"
          style={{ backgroundImage: grad(c1, c2) }}
        >
          <CatIcon name={startSetup.isPending ? "refresh-cw" : "shield-plus"} className={`h-4 w-4 ${startSetup.isPending ? "animate-spin" : ""}`} />
          {startSetup.isPending ? t("wzDoneMfaStarting") : t("wzDoneMfaStart")}
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={onContinue}
          disabled={startSetup.isPending}
          className="h-10 rounded-xl border-emerald-300/70 bg-white px-4 text-[12.5px] font-bold text-emerald-700 transition hover:bg-emerald-50 disabled:opacity-50 dark:border-emerald-500/30 dark:bg-white/[0.05] dark:text-emerald-300 dark:hover:bg-white/[0.08]"
        >
          {t("wzDoneMfaSkip")}
        </Button>
      </div>
      {errorMsg ? (
        <p role="alert" className="mx-3.5 mb-3.5 flex items-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50/80 px-3 py-2 text-[11px] font-bold text-rose-600 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-300">
          <CatIcon name="circle-alert" className="h-3.5 w-3.5 shrink-0" />
          {errorMsg}
        </p>
      ) : null}
    </section>
  );
}

export function DoneStep({
  draft,
  onLaunch,
  launching,
  createdInstanceId,
  onContinue,
}: {
  draft: WizardDraft;
  onLaunch: () => void;
  launching: boolean;
  /** ROUND MFA — set by the wizard-overlay on launch success when
   *  draft.admin.twoFA is true; the done-step then mounts the post-launch
   *  MFA enrollment card and morphs the LAUNCH button into a CONTINUE one. */
  createdInstanceId?: string | null;
  onContinue?: () => void;
}) {
  const { t, lang } = useT();
  const system = SYSTEM_MAP[draft.systemId];
  const cat = system ? CATEGORY_MAP[system.c] : undefined;
  const c1 = cat?.c1 ?? "#6d5dfb";
  const c2 = cat?.c2 ?? "#0ea5e9";
  const colors = [c1, "#f59e0b", "#06b6d4", "#ec4899", "#10b981", "#a855f7", "#22d3ee"];
  const sysName = system ? (lang === "ar" ? system.nameAr : system.nameEn) : draft.systemId;

  /* ROUND 144 — the FINAL readiness checklist: four verified pillars; the
   * workspace row carries the live modules count from the draft. */
  const readiness: { label: string; count?: string }[] = [
    { label: t("wzDoneReadyIdentity") },
    { label: t("wzDoneReadyWorkspace"), count: `${fmtNum(draft.modules.length, lang)} ${t("wzSummaryUnit")}` },
    { label: t("wzDoneReadySite") },
    { label: t("wzDoneReadyWallet") },
  ];

  return (
    <div className="step-in text-center">
      <div className="relative mx-auto h-20 w-20">
        {CONFETTI_LEFTS.map((left, i) => (
          <span
            key={i}
            className="confetti absolute top-0 h-2 w-2 rounded-sm"
            style={{ left, background: colors[i], animationDelay: `${i * 0.08}s` }}
            aria-hidden="true"
          />
        ))}
        <div
          className="check-pop grid h-20 w-20 place-items-center rounded-full text-white shadow-xl"
          style={{
            backgroundImage: grad(c1, c2),
            boxShadow: `0 18px 40px -12px ${hexAlpha(c1, 0.8)}`,
          }}
        >
          <CatIcon name="check" className="h-[34px] w-[34px]" />
        </div>
      </div>

      <h3 className="mt-5 font-display text-xl font-extrabold text-slate-900 dark:text-white">{t("wzDoneTitle")}</h3>
      <p className="mx-auto mt-2 max-w-md text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
        {t("wzDoneDesc")}
      </p>
      {/* ROUND 144 — the small readiness subtitle under the description */}
      <p className="mt-2 text-[12px] font-extrabold text-emerald-600 dark:text-emerald-400">
        {t("wzDoneReadyTitle")}
      </p>

      {/* ROUND 144 — the refined 3-column summary grid (2×2 → 2×3): the
          chosen system (icon tile + real name) leads, the org + modules
          cells are kept verbatim, then the workspace currency + timezone
          and the admin email (double-width cell for LTR truncation relief). */}
      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
        {/* the chosen system — its real icon tile + localized name */}
        <div className="rounded-2xl border border-slate-200 bg-slate-50/60 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
          <p className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            {t("wzDoneSummarySystem")}
          </p>
          <div className="mt-1 flex min-w-0 items-center justify-center gap-2">
            <span
              className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white shadow-md"
              style={{ backgroundImage: grad(c1, c2) }}
              aria-hidden="true"
            >
              <CatIcon name={system?.icon ?? "cubes"} className="h-[12px] w-[12px]" />
            </span>
            <span dir="auto" className="min-w-0 truncate text-[13px] font-bold text-slate-800 dark:text-slate-100">
              {sysName}
            </span>
          </div>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-slate-50/60 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
          <p className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            {t("wzSummaryOrg")}
          </p>
          <p className="mt-1 truncate text-[13px] font-bold text-slate-800 dark:text-slate-100">
            {draft.org.name || "—"}
          </p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-slate-50/60 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
          <p className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            {t("wzSummaryModules")}
          </p>
          <p className="mt-1 truncate text-[13px] font-bold text-slate-800 dark:text-slate-100">
            {draft.modules.length} {t("wzSummaryUnit")}
          </p>
        </div>
        {/* the workspace currency + timezone — dir-locked latin values */}
        <div className="rounded-2xl border border-slate-200 bg-slate-50/60 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
          <p className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            {t("wzOrgCurrency")} · {t("wzOrgTimezone")}
          </p>
          <p className="mt-1 flex min-w-0 items-center justify-center gap-1.5">
            <CatIcon name="coins" className="h-3.5 w-3.5 shrink-0 text-emerald-500 dark:text-emerald-400" />
            <span dir="ltr" className="truncate text-[13px] font-bold tabular-nums text-slate-800 dark:text-slate-100">
              {draft.org.currency || "—"}
            </span>
            <span aria-hidden="true" className="shrink-0 text-slate-300 dark:text-slate-600">
              ·
            </span>
            <CatIcon name="globe" className="h-3.5 w-3.5 shrink-0 text-violet-500 dark:text-violet-400" />
            <span dir="ltr" className="min-w-0 truncate text-[13px] font-bold tabular-nums text-slate-800 dark:text-slate-100">
              {draft.org.timezone || "—"}
            </span>
          </p>
        </div>
        {/* the admin email — double-width cell, dir-locked LTR */}
        <div className="col-span-2 rounded-2xl border border-slate-200 bg-slate-50/60 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
          <p className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            {t("wzSummaryAdmin")}
          </p>
          <p className="mt-1 flex min-w-0 items-center justify-center gap-1.5">
            <CatIcon name="mail" className="h-3.5 w-3.5 shrink-0 text-brand-500 dark:text-brand-400" />
            <span dir="ltr" className="min-w-0 truncate text-[13px] font-bold text-slate-800 dark:text-slate-100">
              {draft.admin.email || "—"}
            </span>
          </p>
        </div>
      </div>

      {/* plan hint — pick a subscription after launch */}
      <div className="mt-3 flex items-center gap-3 rounded-2xl border border-dashed border-slate-300 bg-slate-50/40 p-3.5 text-start dark:border-white/15 dark:bg-white/[0.02]">
        <span
          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
          style={{ backgroundImage: "linear-gradient(135deg,#10b981,#059669)" }}
          aria-hidden="true"
        >
          <CatIcon name="gem" className="h-[14px] w-[14px]" />
        </span>
        <div className="min-w-0">
          <p className="text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
            {t("wzDonePlanTitle")}
          </p>
          <p className="mt-0.5 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
            {t("wzDonePlanHint")}
          </p>
        </div>
      </div>

      {/* website hint — the public site linked to this system */}
      <div className="mt-2.5 flex items-center gap-3 rounded-2xl border border-dashed border-slate-300 bg-slate-50/40 p-3.5 text-start dark:border-white/15 dark:bg-white/[0.02]">
        <span
          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
          style={{ backgroundImage: "linear-gradient(135deg,#6d5dfb,#ec4899)" }}
          aria-hidden="true"
        >
          <CatIcon name="globe" className="h-[14px] w-[14px]" />
        </span>
        <div className="min-w-0">
          <p className="text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
            {t("wzDoneSiteTitle")}
          </p>
          <p className="mt-0.5 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
            {t("wzDoneSiteHint")}
          </p>
        </div>
      </div>

      {/* mobile app — coming soon (premium notice, not a stub) */}
      <div className="mt-2.5 overflow-hidden rounded-2xl border border-brand-200/70 bg-linear-to-l from-brand-50/80 to-fuchsia-50/50 text-start dark:border-brand-500/25 dark:from-brand-500/10 dark:to-fuchsia-500/[0.07]">
        <div className="flex items-center gap-3 p-3.5">
          <span
            className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
            style={{
              backgroundImage: "linear-gradient(135deg,#6d5dfb,#a855f7)",
              boxShadow: `0 12px 24px -10px ${hexAlpha("#6d5dfb", 0.8)}`,
            }}
            aria-hidden="true"
          >
            <CatIcon name="smartphone" className="h-[16px] w-[16px]" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="flex flex-wrap items-center gap-2 text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
              {t("mobileAppTitle")}
              <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2 py-px text-[11px] font-extrabold text-amber-700 dark:bg-amber-500/15 dark:text-amber-300">
                <CatIcon name="timer" className="h-2.5 w-2.5" />
                {t("mobileAppBadge")}
              </span>
            </p>
            <p className="mt-0.5 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("mobileAppDesc")}
            </p>
          </div>
        </div>
        <ul className="grid gap-1.5 border-t border-brand-200/50 p-3.5 pt-3 text-[10.5px] font-bold text-slate-500 dark:border-brand-500/20 dark:text-slate-400 sm:grid-cols-3">
          {["mobileAppF1", "mobileAppF2", "mobileAppF3"].map((key) => (
            <li key={key} className="flex items-center gap-1.5">
              <CatIcon name="circle-check" className="h-3 w-3 shrink-0 text-brand-500 dark:text-brand-400" />
              <span className="truncate">{t(key as "mobileAppF1")}</span>
            </li>
          ))}
        </ul>
        <div className="border-t border-brand-200/50 p-3.5 pt-3 dark:border-brand-500/20">
          <button
            type="button"
            onClick={() => toast.success(t("mobileAppToast"), { description: t("mobileAppTitle") + " · " + t("mobileAppBadge") })}
            className="inline-flex h-9 items-center gap-2 rounded-xl border border-brand-300/70 bg-white/70 px-4 text-[11.5px] font-extrabold text-brand-700 transition hover:border-brand-400 hover:bg-white active:scale-95 dark:border-brand-500/30 dark:bg-white/[0.06] dark:text-brand-300 dark:hover:bg-white/[0.1]"
          >
            <CatIcon name="bell" className="h-3.5 w-3.5" />
            {t("mobileAppNotify")}
          </button>
        </div>
      </div>

      {/* ROUND 144 — the FINAL readiness checklist: four slim bordered rows
          (emerald circle-check), staggered card-in, the workspace row carrying
          the live modules count. */}
      <div className="mt-3 text-start">
        <div className="rounded-2xl border border-slate-200 bg-slate-50/60 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
          <p className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            {t("wzDoneChecklist")}
          </p>
          <ul className="mt-2 space-y-1.5">
            {readiness.map((row, i) => (
              <li
                key={row.label}
                className="card-in flex items-center gap-2.5 rounded-xl border border-slate-200/80 bg-white/70 px-3 py-2 dark:border-white/10 dark:bg-white/[0.04]"
                style={{ "--i": i } as CSSProperties}
              >
                <CatIcon name="circle-check" className="h-4 w-4 shrink-0 text-emerald-500 dark:text-emerald-400" />
                <span className="min-w-0 flex-1 truncate text-[11.5px] font-bold text-slate-700 dark:text-slate-200">
                  {row.label}
                </span>
                {row.count ? (
                  <span className="inline-flex shrink-0 items-center rounded-full bg-emerald-500/10 px-1.5 py-px text-[9.5px] font-extrabold tabular-nums text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400">
                    {row.count}
                  </span>
                ) : null}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* ROUND MFA — post-launch two-factor enrollment card. Mounts ONLY
          when launch succeeded AND the admin opted into 2FA. The card
          drives the existing /api/instances/[id]/mfa/setup endpoints; the
          user finishes enrollment (or skips) before the transition runs. */}
      {createdInstanceId && draft.admin.twoFA && onContinue ? (
        <DoneMfaCard instanceId={createdInstanceId} onContinue={onContinue} />
      ) : null}

      {createdInstanceId && draft.admin.twoFA && onContinue ? (
        /* After launch the LAUNCH button becomes a CONTINUE button (the
         * instance is already created — calling onLaunch again would 409).
         * The MFA card carries the primary action; this one is a secondary
         * path for owners who prefer to skip 2FA from the button itself. */
        <Button
          type="button"
          onClick={onContinue}
          className="mt-5 inline-flex h-[52px] w-full items-center justify-center gap-2.5 rounded-2xl px-6 text-[13.5px] font-extrabold text-white shadow-xl transition hover:brightness-110 active:scale-[0.98]"
          style={{
            backgroundImage: grad(c1, c2),
            boxShadow: `0 16px 34px -12px ${hexAlpha(c1, 0.8)}`,
          }}
        >
          <CatIcon name={lang === "ar" ? "arrow-left" : "arrow-right"} className="h-[15px] w-[15px]" />
          {t("wzDoneMfaContinue")}
        </Button>
      ) : (
        <Button
          type="button"
          onClick={onLaunch}
          disabled={launching}
          className="mt-5 inline-flex h-[52px] w-full items-center justify-center gap-2.5 rounded-2xl px-6 text-[13.5px] font-extrabold text-white shadow-xl transition hover:brightness-110 active:scale-[0.98] disabled:opacity-70"
          style={{
            backgroundImage: grad(c1, c2),
            boxShadow: `0 16px 34px -12px ${hexAlpha(c1, 0.8)}`,
          }}
        >
          {launching ? (
            <CatIcon name="refresh-cw" className="h-[15px] w-[15px] animate-spin" />
          ) : (
            <CatIcon name="rocket" className="h-[15px] w-[15px]" />
          )}
          {launching ? t("wzLaunching") : t("wzLaunch")}
        </Button>
      )}

      {/* ROUND 144 — the launch hint under the button (hidden once the
          instance is created — the user is now finishing 2FA, not about
          to launch). */}
      {!createdInstanceId ? (
        <p className="mt-2.5 text-[11px] font-semibold text-slate-400 dark:text-slate-500">
          {t("wzDoneLaunchHint")}
        </p>
      ) : (
        <p className="mt-2.5 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400">
          {t("wzDoneMfaPendingHint")}
        </p>
      )}
    </div>
  );
}
