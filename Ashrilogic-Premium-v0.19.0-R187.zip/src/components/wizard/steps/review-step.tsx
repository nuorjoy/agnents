"use client";

/**
 * Wizard step 6 — review: summary rows, each clickable to jump back to
 * the related step (data-review-edit pattern from V2, now real buttons).
 */
import { CATEGORY_MAP, MODULE_MAP, SYSTEM_MAP } from "@/data/catalog";
import { useT, type I18nKey } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { grad } from "@/lib/utils";
import type { WizardDraft } from "@/lib/types";

interface ReviewRow {
  labelKey: I18nKey;
  value: string;
  step: number;
}

export function ReviewStep({ draft, onJump }: { draft: WizardDraft; onJump: (step: number) => void }) {
  const { t, lang } = useT();
  const system = SYSTEM_MAP[draft.systemId];
  const cat = system ? CATEGORY_MAP[system.c] : undefined;
  const c1 = cat?.c1 ?? "#6d5dfb";
  const c2 = cat?.c2 ?? "#0ea5e9";
  const sysName = system ? (lang === "ar" ? system.nameAr : system.nameEn) : draft.systemId;

  const themeLabelKey: I18nKey =
    draft.prefs.theme === "light"
      ? "wzPrefsThemeLight"
      : draft.prefs.theme === "dark"
        ? "wzPrefsThemeDark"
        : "wzPrefsThemeAuto";

  const rows: ReviewRow[] = [
    { labelKey: "wzSummarySystem", value: sysName, step: 0 },
    { labelKey: "wzSummaryOrg", value: draft.org.name || "—", step: 1 },
    {
      labelKey: "wzSummaryModules",
      value: `${draft.modules.length} ${t("wzSummaryUnit")} (${t("wzModulesSelected")})`,
      step: 2,
    },
    {
      labelKey: "wzSummaryAdmin",
      value: draft.admin.name ? `${draft.admin.name} · ${draft.admin.email}` : "—",
      step: 3,
    },
    {
      labelKey: "wzPwLabel",
      value: draft.admin.password ? "••••••••" : "—",
      step: 3,
    },
    { labelKey: "wzSummaryLang", value: draft.prefs.lang === "ar" ? "العربية" : "English", step: 4 },
    { labelKey: "wzSummaryTheme", value: t(themeLabelKey), step: 4 },
  ];

  return (
    <div className="step-in">
      <div className="text-center">
        <div
          className="mx-auto grid h-14 w-14 place-items-center rounded-2xl text-white shadow-lg"
          style={{ backgroundImage: grad(c1, c2) }}
        >
          <CatIcon name="list-checks" className="h-[20px] w-[20px]" />
        </div>
        <h3 className="mt-4 font-display text-xl font-extrabold text-slate-900 dark:text-white">
          {t("wzReviewTitle")}
        </h3>
        <p className="mx-auto mt-2 max-w-md text-[13px] text-slate-500 dark:text-slate-400">{t("wzReviewDesc")}</p>
      </div>

      <div className="mt-6 overflow-hidden rounded-2xl border border-slate-200 dark:border-white/10">
        {rows.map((row, i) => (
          <button
            key={row.labelKey}
            type="button"
            data-review-edit={row.step}
            onClick={() => onJump(row.step)}
            className={`flex w-full items-center justify-between gap-3 px-4 py-3 text-start transition hover:bg-slate-100 dark:hover:bg-white/5 ${
              i % 2 === 0 ? "bg-slate-50/60 dark:bg-white/[0.02]" : ""
            }`}
            aria-label={`${t(row.labelKey)}: ${row.value}`}
          >
            <span className="shrink-0 text-[11.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              {t(row.labelKey)}
            </span>
            <span className="flex min-w-0 items-center gap-2">
              <span className="truncate text-[12.5px] font-bold text-slate-800 dark:text-slate-100">{row.value}</span>
              <CatIcon name="pencil" className="h-[10px] w-[10px] shrink-0 text-slate-400" />
            </span>
          </button>
        ))}
      </div>

      <div className="mt-5 flex items-center gap-2.5 rounded-2xl border border-emerald-200 bg-emerald-50/60 p-3.5 dark:border-emerald-500/30 dark:bg-emerald-500/10">
        <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-emerald-500 text-white">
          <CatIcon name="circle-check" className="h-[13px] w-[13px]" />
        </span>
        <p className="text-[12.5px] font-bold text-emerald-700 dark:text-emerald-300">{t("wzReviewReady")}</p>
      </div>

      {draft.modules.length > 0 ? (
        <div className="mt-4 flex flex-wrap gap-1.5">
          {draft.modules.slice(0, 12).map((key) => {
            const m = MODULE_MAP[key];
            return (
              <span
                key={key}
                className="rounded-full border border-slate-200 bg-white px-2.5 py-1 text-[10.5px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300"
              >
                {m ? (lang === "ar" ? m.nameAr : m.nameEn) : key}
              </span>
            );
          })}
          {draft.modules.length > 12 ? (
            <span className="rounded-full bg-brand-500/10 px-2.5 py-1 text-[10.5px] font-bold text-brand-600 dark:text-brand-300">
              +{draft.modules.length - 12}
            </span>
          ) : null}
        </div>
      ) : null}

      {/* ROUND 159 — privacy policy + terms consent: required before
          the system can be provisioned. Strict — the launch button is
          disabled until this checkbox is checked. */}
      <PrivacyConsent />
    </div>
  );
}

/* ROUND 159 — the privacy + terms consent checkbox. This is a STRICT
 * gate: the wizard's launch button is disabled until the user checks
 * this box. The links open /privacy and /terms in a new tab. */
import { useT as useConsentT } from "@/lib/i18n";
import { CatIcon as ConsentIcon } from "@/components/icon";
import { cn as consentCn } from "@/lib/utils";
import { useAppStore as useConsentStore } from "@/lib/store";

const useAppStoreConsent = () => useConsentStore((s) => s.consentAccepted);
const useAppStoreSetConsent = () => useConsentStore((s) => s.setConsentAccepted);

function PrivacyConsent() {
  const { t, lang } = useConsentT();
  const accepted = useAppStoreConsent();
  const setAccepted = useAppStoreSetConsent();
  return (
    <div className="mt-5 rounded-2xl border border-slate-200 bg-slate-50/60 p-4 dark:border-white/10 dark:bg-white/[0.02]">
      <label className="flex items-start gap-3 cursor-pointer">
        <button
          type="button"
          role="checkbox"
          aria-checked={accepted}
          onClick={() => setAccepted(!accepted)}
          className={consentCn(
            "mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-md border-2 transition",
            accepted
              ? "border-emerald-500 bg-emerald-500 text-white"
              : "border-slate-300 bg-white dark:border-white/20 dark:bg-white/5"
          )}
        >
          {accepted ? <ConsentIcon name="check" className="h-3 w-3" /> : null}
        </button>
        <div className="min-w-0 text-[12px] font-semibold leading-relaxed text-slate-600 dark:text-slate-300">
          {lang === "ar"
            ? "أوافق على "
            : "I agree to the "}
          <a
            href="/privacy"
            target="_blank"
            rel="noopener noreferrer"
            className="font-extrabold text-brand-600 underline underline-offset-2 dark:text-brand-300"
          >
            {lang === "ar" ? "سياسة الخصوصية" : "Privacy Policy"}
          </a>
          {lang === "ar" ? " و" : " and "}
          <a
            href="/terms"
            target="_blank"
            rel="noopener noreferrer"
            className="font-extrabold text-brand-600 underline underline-offset-2 dark:text-brand-300"
          >
            {lang === "ar" ? "\u0634\u0631و\u0637 \u0627\u0644\u0627\u0633\u062a\u062e\u062f\u0627\u0645" : "Terms of Service"}
          </a>
          {lang === "ar" ? " \u0627\u0644\u062e\u0627\u0635\u064a\u0646 \u0628\u0645\u0646\u0635\u0629 \u0623\u0634\u0631\u0650\u064a\u0644و\u062c\u064a\u0643." : " of Ashrilogic."}
        </div>
      </label>
    </div>
  );
}
