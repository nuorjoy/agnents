"use client";

/**
 * Wizard step 2 — organization form.
 * All inputs are fully controlled against the store draft (updateDraft),
 * so navigating between steps never loses typed state.
 * Selecting a country auto-fills the currency (data-cur behavior of V2).
 *
 * ROUND 84 (84-CONTACT) — the org phone field is the unified
 * PremiumPhoneInput (dial-code selector + canonical +{dial}{national}
 * output); the shell's non-empty check in wizard-overlay.tsx is untouched.
 *
 * ROUND 134-E — live PHONE availability: a debounced (500ms) probe of
 * POST /api/instances/check-availability renders the emerald «متاح
 * للاستخدام» / rose «مستخدم مسبقاً» chip under the field (≥8 digits
 * only). Skipped in the verified ROUND-82 reuse flow (ownerVerified —
 * that flow is exempt from the deep checks server-side by design). The
 * probe runs the SAME deep engine as the submit-time guard.
 */
import { useEffect, useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PremiumPhoneInput } from "@/components/ui/premium-contact";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { COUNTRIES, TIMEZONES, WZ_INPUT, WZ_LABEL, ShakeField, type WizardStepProps } from "@/components/wizard/wizard-shared";
import { useT } from "@/lib/i18n";
import { checkTenantAvailability } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";

export function OrgStep({ draft, update, error }: WizardStepProps) {
  const { t } = useT();
  const org = draft.org;

  const setOrg = (patch: Partial<typeof org>) => update({ org: { ...org, ...patch } });

  /* ROUND 134-E — live phone availability probe (see the module header).
   * Debounced 500ms; a new keystroke cancels the stale verdict; probe
   * failures reset silently (never blocks typing or submit). The verdict
   * is stored WITH the value it probed, so the RENDERED state is DERIVED
   * (stale verdicts read as idle — no synchronous setState in the effect). */
  const [phoneProbe, setPhoneProbe] = useState<{
    value: string;
    verdict: "checking" | "free" | "used";
  } | null>(null);
  const phoneAvail =
    phoneProbe && phoneProbe.value === org.phone.trim() ? phoneProbe.verdict : "idle";
  useEffect(() => {
    const phone = org.phone.trim();
    const digits = phone.replace(/\D/g, "");
    if (draft.ownerVerified === true || digits.length < 8) return; /* derived state stays idle */
    let live = true;
    const timer = setTimeout(() => {
      setPhoneProbe({ value: phone, verdict: "checking" });
      void checkTenantAvailability({ phone })
        .then((res) => {
          if (live) setPhoneProbe({ value: phone, verdict: res.phoneUsed ? "used" : "free" });
        })
        .catch(() => {
          if (live) setPhoneProbe(null);
        });
    }, 500);
    return () => {
      live = false;
      clearTimeout(timer);
    };
  }, [org.phone, draft.ownerVerified]);

  const onCountryChange = (country: string) => {
    const cur = COUNTRIES.find((c) => c.code === country)?.currency;
    setOrg({ country, ...(cur ? { currency: cur } : {}) });
  };

  return (
    <div className="step-in">
      <div>
        <h3 className="font-display text-lg font-extrabold text-slate-900 dark:text-white">{t("wzOrgTitle")}</h3>
        <p className="mt-1 text-[12.5px] text-slate-500 dark:text-slate-400">{t("wzOrgDesc")}</p>
      </div>

      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <ShakeField token={error?.field === "org-name" ? error.token : 0}>
            <Label htmlFor="wz-org-name" className={WZ_LABEL}>
              {t("wzOrgName")} <span className="text-rose-500">*</span>
            </Label>
            <Input
              id="wz-org-name"
              value={org.name}
              onChange={(e) => setOrg({ name: e.target.value })}
              placeholder={t("wzOrgNamePh")}
              autoComplete="organization"
              className={WZ_INPUT}
              aria-invalid={error?.field === "org-name" || undefined}
            />
          </ShakeField>
        </div>

        <div>
          <Label htmlFor="wz-org-country" className={WZ_LABEL}>
            {t("wzOrgCountry")}
          </Label>
          <Select value={org.country} onValueChange={onCountryChange}>
            <SelectTrigger id="wz-org-country" className={WZ_INPUT}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="max-h-72">
              <SelectGroup>
                {COUNTRIES.map((c) => (
                  <SelectItem key={c.code} value={c.code} data-cur={c.currency}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectGroup>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="wz-org-currency" className={WZ_LABEL}>
            {t("wzOrgCurrency")}
          </Label>
          <Input
            id="wz-org-currency"
            value={org.currency}
            onChange={(e) => setOrg({ currency: e.target.value })}
            placeholder="SAR"
            autoComplete="off"
            className={WZ_INPUT}
          />
        </div>

        <div className="sm:col-span-2">
          <Label htmlFor="wz-org-timezone" className={WZ_LABEL}>
            {t("wzOrgTimezone")}
          </Label>
          <Select value={org.timezone} onValueChange={(tz) => setOrg({ timezone: tz })}>
            <SelectTrigger id="wz-org-timezone" className={WZ_INPUT}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="max-h-72">
              <SelectGroup>
                {TIMEZONES.map((tz) => (
                  <SelectItem key={tz} value={tz}>
                    {tz}
                  </SelectItem>
                ))}
              </SelectGroup>
            </SelectContent>
          </Select>
        </div>

        <div className="sm:col-span-2">
          <ShakeField token={error?.field === "org-address" ? error.token : 0}>
            <Label htmlFor="wz-org-address" className={WZ_LABEL}>
              {t("wzOrgAddress")} <span className="text-rose-500">*</span>
            </Label>
            <Input
              id="wz-org-address"
              value={org.address}
              onChange={(e) => setOrg({ address: e.target.value })}
              placeholder={t("wzOrgAddressPh")}
              autoComplete="street-address"
              className={WZ_INPUT}
              aria-invalid={error?.field === "org-address" || undefined}
            />
          </ShakeField>
        </div>

        <div className="sm:col-span-2">
          <ShakeField token={error?.field === "org-phone" ? error.token : 0}>
            <PremiumPhoneInput
              id="wz-org-phone"
              label="wzOrgPhone"
              value={org.phone}
              onChange={(phone) => setOrg({ phone })}
              required
              autoComplete="tel"
              invalid={error?.field === "org-phone" || phoneAvail === "used" || undefined}
            />
          </ShakeField>
          {/* ROUND 134-E — availability verdict chip */}
          {phoneAvail === "free" ? (
            <span
              role="status"
              className="mt-2 inline-flex items-center gap-1.5 rounded-full border border-emerald-400/70 bg-emerald-500/15 px-3 py-1 text-[11px] font-extrabold text-emerald-700 dark:border-emerald-500/40 dark:bg-emerald-500/15 dark:text-emerald-300"
            >
              <CatIcon name="circle-check" className="h-3.5 w-3.5" />
              {t("wzAvailPhoneFree")}
            </span>
          ) : null}
          {phoneAvail === "used" ? (
            <span
              role="alert"
              className="mt-2 inline-flex items-center gap-1.5 rounded-full border border-rose-300/80 bg-rose-500/10 px-3 py-1 text-[11px] font-extrabold text-rose-600 dark:border-rose-500/40 dark:bg-rose-500/10 dark:text-rose-300"
            >
              <CatIcon name="circle-alert" className="h-3.5 w-3.5" />
              {t("wzAvailPhoneUsed")}
            </span>
          ) : null}
        </div>
      </div>
    </div>
  );
}
