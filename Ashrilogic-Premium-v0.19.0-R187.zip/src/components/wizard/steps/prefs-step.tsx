"use client";

/**
 * Wizard step 5 — preferences.
 * Language and theme apply LIVE (setLang / setTheme) so the wizard flips
 * the whole UI the moment the user changes them.
 */
import { useTheme } from "next-themes";
import { CATEGORY_MAP, SYSTEM_MAP } from "@/data/catalog";
import { useT } from "@/lib/i18n";
import { LOCALES } from "@/lib/locales";
import { useAppStore } from "@/lib/store";
import type { Lang, PrefsInfo } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { grad, cn } from "@/lib/utils";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { WZ_INPUT, WZ_LABEL, type WizardStepProps } from "@/components/wizard/wizard-shared";

const TOGGLES = [
  { key: "notif", icon: "bell", title: "wzPrefsNotif", desc: "wzPrefsNotifDesc", c1: "#f59e0b", c2: "#ea580c" },
  { key: "backup", icon: "cloud-upload", title: "wzPrefsBackup", desc: "wzPrefsBackupDesc", c1: "#06b6d4", c2: "#0e7490" },
  { key: "audit", icon: "clipboard-list", title: "wzPrefsAudit", desc: "wzPrefsAuditDesc", c1: "#8b5cf6", c2: "#7c3aed" },
  { key: "demo", icon: "flask", title: "wzPrefsDemo", desc: "wzPrefsDemoDesc", c1: "#ec4899", c2: "#db2777" },
] as const;

const THEME_OPTIONS = [
  { value: "light", labelKey: "wzPrefsThemeLight" },
  { value: "dark", labelKey: "wzPrefsThemeDark" },
  { value: "auto", labelKey: "wzPrefsThemeAuto" },
] as const;

export function PrefsStep({ draft, update }: WizardStepProps) {
  const { t, lang } = useT();
  const setLang = useAppStore((s) => s.setLang);
  const { setTheme } = useTheme();
  const prefs = draft.prefs;
  const system = SYSTEM_MAP[draft.systemId];
  const cat = system ? CATEGORY_MAP[system.c] : undefined;
  const c1 = cat?.c1 ?? "#6d5dfb";
  const c2 = cat?.c2 ?? "#0ea5e9";

  const setPrefs = (patch: Partial<PrefsInfo>) => update({ prefs: { ...prefs, ...patch } });

  return (
    <div className="step-in">
      <div>
        <h3 className="font-display text-lg font-extrabold text-slate-900 dark:text-white">{t("wzPrefsTitle")}</h3>
        <p className="mt-1 text-[12.5px] text-slate-500 dark:text-slate-400">{t("wzPrefsDesc")}</p>
      </div>

      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <div>
          <Label htmlFor="wz-prefs-lang" className={WZ_LABEL}>
            {t("wzPrefsLang")}
          </Label>
          <Select
            value={prefs.lang}
            onValueChange={(v) => {
              const lang = v as Lang;
              setPrefs({ lang });
              setLang(lang); // live flip of the entire UI
            }}
          >
            <SelectTrigger id="wz-prefs-lang" className={WZ_INPUT}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectGroup>
                {/* ROUND 55 — ALL 11 platform languages selectable (native
                    endonyms from the locale registry; non-translated ones
                    fall back to English UI until their dictionary lands) */}
                {LOCALES.map((loc) => (
                  <SelectItem key={loc.code} value={loc.code} className="text-[12.5px] font-bold">
                    <span className="flex items-center gap-2">
                      <span className={cn("text-[10px] font-extrabold uppercase", lang === loc.code ? "text-brand-600 dark:text-brand-300" : "text-slate-400 dark:text-slate-500")}>
                        {loc.short}
                      </span>
                      {loc.native}
                    </span>
                  </SelectItem>
                ))}
              </SelectGroup>
            </SelectContent>
          </Select>
          <p className="mt-1.5 flex items-center gap-1.5 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
            <CatIcon name="info" className="h-3 w-3 shrink-0" />
            {t("wzPrefsLangHint")}
          </p>
        </div>

        <div>
          <Label htmlFor="wz-prefs-theme" className={WZ_LABEL}>
            {t("wzPrefsTheme")}
          </Label>
          <Select
            value={prefs.theme}
            onValueChange={(v) => {
              const theme = v as PrefsInfo["theme"];
              setPrefs({ theme });
              setTheme(theme === "auto" ? "system" : theme); // live preview
            }}
          >
            <SelectTrigger id="wz-prefs-theme" className={WZ_INPUT}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectGroup>
                {THEME_OPTIONS.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    {t(opt.labelKey)}
                  </SelectItem>
                ))}
              </SelectGroup>
            </SelectContent>
          </Select>
        </div>

        <div className="sm:col-span-2">
          <span className={WZ_LABEL}>{t("wzWelcomeFeatures")}</span>
          <div className="grid gap-2.5 sm:grid-cols-2">
            {TOGGLES.map((row) => {
              const on = prefs[row.key];
              return (
                <div
                  key={row.key}
                  className={cn(
                    "flex items-center justify-between gap-3 rounded-2xl border p-3.5 transition",
                    on
                      ? "border-brand-400/60 bg-brand-50/40 dark:border-brand-500/40 dark:bg-brand-500/10"
                      : "border-slate-200 bg-white dark:border-white/10 dark:bg-white/[0.03]"
                  )}
                >
                  <div className="flex min-w-0 items-center gap-3">
                    <span
                      className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white"
                      style={{ backgroundImage: on ? grad(row.c1, row.c2) : "linear-gradient(135deg,#cbd5e1,#94a3b8)" }}
                    >
                      <CatIcon name={row.icon} className="h-[12px] w-[12px]" />
                    </span>
                    <div className="min-w-0">
                      <p className="truncate text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                        {t(row.title)}
                      </p>
                      <p className="truncate text-[11px] text-slate-500 dark:text-slate-400">{t(row.desc)}</p>
                    </div>
                  </div>
                  <Switch
                    checked={on}
                    onCheckedChange={(v) => setPrefs({ [row.key]: v } as Partial<PrefsInfo>)}
                    aria-label={t(row.title)}
                  />
                </div>
              );
            })}
          </div>
        </div>

        <div className="sm:col-span-2 flex items-center gap-2.5 rounded-2xl border border-dashed border-brand-300/60 bg-brand-50/30 p-3.5 dark:border-brand-500/30 dark:bg-brand-500/5">
          <span
            className="grid h-8 w-8 shrink-0 place-items-center rounded-xl text-white"
            style={{ backgroundImage: grad(c1, c2) }}
          >
            <CatIcon name="circle-check" className="h-[12px] w-[12px]" />
          </span>
          <p className="text-[12px] font-bold text-slate-700 dark:text-slate-200">{t("wzReviewReady")}</p>
        </div>
      </div>
    </div>
  );
}
