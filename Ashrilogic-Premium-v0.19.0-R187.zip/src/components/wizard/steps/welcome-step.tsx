"use client";

/**
 * Wizard step 1 — welcome: gradient system tile, headline and the
 * six feature tiles (gauge / pie / shield / language / cloud / mobile).
 */
import { CATEGORY_MAP, SYSTEM_MAP } from "@/data/catalog";
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { grad, hexAlpha } from "@/lib/utils";

const FEATURES = [
  { icon: "gauge", key: "wzFeature1" },
  { icon: "chart-pie", key: "wzFeature2" },
  { icon: "globe", key: "wzFeature7" },
  { icon: "shield", key: "wzFeature3" },
  { icon: "language", key: "wzFeature4" },
  { icon: "users", key: "wzFeature8" },
  { icon: "cloud-upload", key: "wzFeature5" },
  { icon: "smartphone", key: "wzFeature6" },
  /* ROUND 55 — the e-store joins the welcome showcase (step 1/7): the
     platform ships an Amazon-grade storefront per workspace */
  { icon: "shopping-cart", key: "wzFeature9" },
  /* ROUND 87 (13-e) — trash, full account control and the security audit
     trail complete the 12-tile capability grid (4 rows × 3 at lg) */
  { icon: "trash-2", key: "wzFeature10" },
  { icon: "user-cog", key: "wzFeature11" },
  { icon: "scroll-text", key: "wzFeature12" },
] as const;

export function WelcomeStep({ systemId }: { systemId: string }) {
  const { t, lang } = useT();
  const system = SYSTEM_MAP[systemId];
  const cat = system ? CATEGORY_MAP[system.c] : undefined;
  const c1 = cat?.c1 ?? "#6d5dfb";
  const c2 = cat?.c2 ?? "#0ea5e9";
  const name = system ? (lang === "ar" ? system.nameAr : system.nameEn) : systemId;

  return (
    <div className="step-in text-center">
      <div
        className="icon-pop mx-auto grid h-16 w-16 place-items-center rounded-3xl text-white shadow-xl"
        style={{ backgroundImage: grad(c1, c2), boxShadow: `0 16px 36px -12px ${hexAlpha(c1, 0.8)}` }}
      >
        <CatIcon name={system?.icon ?? "boxes"} className="h-[22px] w-[22px]" />
      </div>
      <h3 className="mt-5 font-display text-xl font-extrabold text-slate-900 dark:text-white">
        {t("wzWelcomeTitle")} {name}
      </h3>
      <p className="mx-auto mt-2 max-w-md text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
        {t("wzWelcomeDesc")}
      </p>

      <div className="mt-7">
        <p className="mb-3 text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
          {t("wzWelcomeFeatures")}
        </p>
        <div className="grid grid-cols-2 gap-2.5 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <div
              key={f.key}
              className="flex items-center gap-2.5 rounded-2xl border border-slate-200/80 bg-slate-50/60 p-3 dark:border-white/10 dark:bg-white/[0.03]"
            >
              <span
                className="grid h-8 w-8 shrink-0 place-items-center rounded-xl text-white"
                style={{ backgroundImage: grad(c1, c2) }}
              >
                <CatIcon name={f.icon} className="h-[11px] w-[11px]" />
              </span>
              <span className="flex min-w-0 flex-wrap items-center gap-1.5">
                <span className="text-[12px] font-bold text-slate-700 dark:text-slate-200">{t(f.key)}</span>
                {/* the mobile app is not shipped yet — say so honestly */}
                {f.key === "wzFeature6" ? (
                  <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-1.5 py-px text-[11px] font-extrabold text-amber-700 dark:bg-amber-500/15 dark:text-amber-300">
                    {t("mobileAppBadge")}
                  </span>
                ) : null}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
