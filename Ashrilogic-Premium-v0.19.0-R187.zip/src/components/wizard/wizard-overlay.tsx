"use client";

/**
 * Ashrilogic — full-screen setup wizard overlay.
 *
 * Layering note: the overlay sits at z-[100]; every shadcn overlay it spawns
 * (confirm AlertDialog, country/timezone Selects) uses z-[120] so it always
 * renders above this overlay and stays fully interactive.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { MotionConfig } from "framer-motion";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CATEGORY_MAP, SYSTEM_MAP } from "@/data/catalog";
import { useT, type I18nKey } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import type { WizardDraft } from "@/lib/types";
import { createInstance, ApiError } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { grad, hexAlpha, cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { EMAIL_RE } from "@/components/wizard/wizard-shared";
import { WelcomeStep } from "@/components/wizard/steps/welcome-step";
import { OrgStep } from "@/components/wizard/steps/org-step";
import { ModulesStep } from "@/components/wizard/steps/modules-step";
import { AdminStep } from "@/components/wizard/steps/admin-step";
import { PrefsStep } from "@/components/wizard/steps/prefs-step";
import { ReviewStep } from "@/components/wizard/steps/review-step";
import { DoneStep } from "@/components/wizard/steps/done-step";

import "@/lib/i18n/fragments/app";
const STEP_NAME_KEYS: I18nKey[] = [
  "wzStepWelcome",
  "wzStepOrg",
  "wzStepModules",
  "wzStepAdmin",
  "wzStepPrefs",
  "wzStepReview",
  "wzStepDone",
];

const FOCUSABLE =
  'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

interface ErrorState {
  field: string;
  token: number;
}

export function WizardOverlay() {
  const { t, lang } = useT();
  const draft = useAppStore((s) => s.wizardDraft);
  const updateDraft = useAppStore((s) => s.updateDraft);
  const clearDraft = useAppStore((s) => s.clearDraft);
  const setView = useAppStore((s) => s.setView);
  const setCurrentInstance = useAppStore((s) => s.setCurrentInstance);
  /* ROUND 82 (batch-5 ②) — owner-reuse context: the wizard was launched by
   * a signed-in owner from «أنظمتك المنشأة» (same email + verified current
   * password → one account across systems). */
  const wizardOwner = useAppStore((s) => s.wizardOwner);
  const setWizardOwner = useAppStore((s) => s.setWizardOwner);
  const consentAccepted = useAppStore((s) => s.consentAccepted);
  const queryClient = useQueryClient();

  const [confirmClose, setConfirmClose] = useState(false);
  const [error, setError] = useState<ErrorState | null>(null);
  /* ROUND MFA — when launch succeeds AND the draft requested two-factor, we
   * keep the wizard mounted on the done-step so the new owner can complete
   * the actual TOTP enrollment (POST + PUT /api/instances/[id]/mfa/setup)
   * BEFORE we transition away. The instance is already created and its
   * session is set, so the existing MFA API works unchanged. When twoFA is
   * false, the legacy behavior is preserved (instant transition). */
  const [createdInstanceId, setCreatedInstanceId] = useState<string | null>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const confirmOpenRef = useRef(false);
  useEffect(() => {
    confirmOpenRef.current = confirmClose;
  }, [confirmClose]);

  const system = draft ? SYSTEM_MAP[draft.systemId] : undefined;
  const cat = system ? CATEGORY_MAP[system.c] : undefined;
  const c1 = cat?.c1 ?? "#6d5dfb";
  const c2 = cat?.c2 ?? "#0ea5e9";
  const sysName = system ? (lang === "ar" ? system.nameAr : system.nameEn) : (draft?.systemId ?? "");

  /* Draft missing (cleared while the overlay is up) → back to landing. */
  useEffect(() => {
    if (!draft) setView("landing");
  }, [draft, setView]);

  /* Scroll lock while the overlay is open. */
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  /* Initial focus on the panel itself (nothing highlighted). */
  useEffect(() => {
    panelRef.current?.focus();
  }, []);

  const step = draft?.step ?? 0;
  const total = 7;

  /* ---------------- navigation & validation ---------------- */

  const update = useCallback(
    (patch: Partial<WizardDraft>) => {
      updateDraft(patch);
    },
    [updateDraft]
  );

  const fail = useCallback((field: string, messageKey: I18nKey) => {
    setError((prev) => ({ field, token: (prev?.token ?? 0) + 1 }));
    toast.error(t(messageKey));
  }, [t]);

  const validateStep = useCallback((): boolean => {
    if (!draft) return false;
    if (step === 1) {
      if (!draft.org.name.trim()) {
        fail("org-name", "wzErrOrg");
        return false;
      }
      if (!draft.org.address.trim()) {
        fail("org-address", "wzErrOrgAddress");
        return false;
      }
      if (!draft.org.phone.trim()) {
        fail("org-phone", "wzErrOrgPhone");
        return false;
      }
    }
    if (step === 2 && draft.modules.length === 0) {
      fail("modules", "wzErrModules");
      return false;
    }
    if (step === 3) {
      if (!draft.admin.name.trim()) {
        fail("admin-name", "wzErrAdmin");
        return false;
      }
      if (!draft.admin.email.trim()) {
        fail("admin-email", "wzErrAdmin");
        return false;
      }
      if (!EMAIL_RE.test(draft.admin.email)) {
        fail("admin-email", "wzErrEmail");
        return false;
      }
      if (draft.admin.password.length < 8) {
        fail("admin-password", "wzErrPassword");
        return false;
      }
      /* ROUND 82 — reuse mode: the typed password must have been VERIFIED
       * server-side against the owner's current password before the new
       * system can be provisioned on the same account. */
      const reuseActive =
        !!wizardOwner &&
        draft.admin.email.trim().toLowerCase() === wizardOwner.email.trim().toLowerCase();
      if (reuseActive && draft.ownerVerified !== true) {
        fail("admin-password", "wzErrOwnerVerify");
        return false;
      }
      if (!reuseActive && draft.admin.confirm !== draft.admin.password) {
        fail("admin-confirm", "wzErrPasswordMatch");
        return false;
      }
    }
    setError(null);
    return true;
  }, [draft, fail, step, wizardOwner]);

  const goNext = useCallback(() => {
    if (!draft) return;
    if (!validateStep()) return;
    if (draft.step < total - 1) update({ step: draft.step + 1 });
  }, [draft, total, update, validateStep]);

  const goBack = useCallback(() => {
    if (!draft || draft.step === 0) return;
    setError(null);
    update({ step: draft.step - 1 });
  }, [draft, update]);

  const jumpTo = useCallback(
    (target: number) => {
      if (!draft) return;
      update({ step: Math.max(0, Math.min(total - 1, target)) });
    },
    [draft, total, update]
  );

  /* ---------------- launch (REAL provisioning) ---------------- */

  const launch = useMutation({
    mutationFn: () => {
      if (!draft) throw new Error("No draft");
      const theme =
        draft.prefs.theme === "auto"
          ? window.matchMedia("(prefers-color-scheme: dark)").matches
            ? "dark"
            : "light"
          : draft.prefs.theme;
      return createInstance({
        systemId: draft.systemId,
        org: draft.org,
        admin: {
          name: draft.admin.name,
          email: draft.admin.email,
          role: draft.admin.role,
          twoFA: draft.admin.twoFA,
          password: draft.admin.password,
        },
        prefs: { ...draft.prefs, theme },
        modules: draft.modules,
      });
    },
    onSuccess: (instance) => {
      queryClient.invalidateQueries({ queryKey: ["instances"] });
      setCurrentInstance(instance.id);
      /* ROUND MFA — if the admin opted into 2FA, defer the transition: the
       * done-step now drives the real TOTP enrollment via the existing
       * /api/instances/[id]/mfa/setup endpoints. The draft is preserved so
       * the done-step still knows twoFA was requested; onContinue clears
       * the draft and runs the legacy transition once enrollment completes
       * or is skipped. Without twoFA, the legacy instant transition runs. */
      if (draft?.admin.twoFA) {
        setCreatedInstanceId(instance.id);
        return;
      }
      clearDraft();
      setWizardOwner(null);
      setView("transition");
    },
    onError: (e: Error) => {
      /* ROUND 134-E — duplicate-identity 409s (deep uniqueness guard):
       * map the machine code to the localized toast + jump to the step
       * owning the offending field (email → the ADMIN step (index 3),
       * phone → the ORG step (index 1)) so the owner fixes the exact
       * input instead of reading a raw server message. The flow aborts
       * cleanly: the draft is kept, the mutation re-arms, relaunching
       * after the edit re-runs the full server-side guard. */
      const code = e instanceof ApiError ? e.code : undefined;
      if (code === "EMAIL_ALREADY_USED") {
        toast.error(t("wzDupEmailToast"));
        jumpTo(3);
        return;
      }
      if (code === "PHONE_ALREADY_USED") {
        toast.error(t("wzDupPhoneToast"));
        jumpTo(1);
        return;
      }
      /* ROUND 167 — maxSystems ceiling: the owner's active paid plan caps
       * their created systems (403 SYSTEM_LIMIT with the limit). The flow
       * aborts cleanly with the localized toast — the fix is a plan upgrade
       * (or closing an existing system), never a field edit. */
      if (code === "SYSTEM_LIMIT") {
        toast.error(t("wzSystemLimitToast"));
        return;
      }
      toast.error(`${t("errorText")}: ${e.message}`);
    },
  });

  /* ROUND MFA — invoked by the done-step once the owner completes (or
   * skips) the post-launch two-factor enrollment. Mirrors the legacy
   * post-launch transition (clear draft, drop owner context, move to the
   * transition view) so the rest of the flow is byte-for-byte the same. */
  const continueToDashboard = useCallback(() => {
    setCreatedInstanceId(null);
    clearDraft();
    setWizardOwner(null);
    setView("transition");
  }, [clearDraft, setView, setWizardOwner]);

  /* ---------------- close / cancel ---------------- */

  const discard = useCallback(() => {
    setConfirmClose(false);
    clearDraft();
    /* ROUND 82 — an owner who launched this wizard from «أنظمتك المنشأة»
     * lands back on THEIR systems screen (never a logout-shaped detour). */
    if (wizardOwner) {
      setWizardOwner(null);
      setView("select");
    } else {
      setView("landing");
    }
  }, [clearDraft, setView, wizardOwner, setWizardOwner]);

  const requestClose = useCallback(() => {
    setConfirmClose(true);
  }, []);

  /* Escape → confirm close (suppressed while the AlertDialog itself is open). */
  const onKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLDivElement>) => {
      if (e.key === "Escape") {
        if (confirmOpenRef.current) return;
        e.preventDefault();
        requestClose();
        return;
      }
      if (e.key === "Tab" && panelRef.current && !confirmOpenRef.current) {
        const items = Array.from(panelRef.current.querySelectorAll<HTMLElement>(FOCUSABLE)).filter(
          (el) => el.offsetParent !== null || el === document.activeElement
        );
        if (items.length === 0) return;
        const first = items[0];
        const last = items[items.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    },
    [requestClose]
  );

  const stepName = useMemo(() => t(STEP_NAME_KEYS[step] ?? "wzStepWelcome"), [step, t]);

  if (!draft) return null;

  return (
    <MotionConfig reducedMotion="user">
    <div
      className="fixed inset-0 z-[100] overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-label={`${t("wzSetupFor")} ${sysName}`}
      onKeyDown={onKeyDown}
    >
      {/* backdrop */}
      <button
        type="button"
        aria-label={t("dlgCancel")}
        tabIndex={-1}
        onClick={requestClose}
        className="absolute inset-0 cursor-default bg-slate-950/70 backdrop-blur-md"
      />

      <div className="relative flex min-h-screen items-start justify-center p-3 sm:items-center sm:p-6">
        <div
          ref={panelRef}
          tabIndex={-1}
          className="modal-in relative w-full max-w-2xl overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-2xl outline-none dark:border-white/10 dark:bg-ink-900"
        >
          {/* header */}
          <div className="relative border-b border-slate-200/80 bg-slate-50/80 px-5 py-4 dark:border-white/10 dark:bg-white/[0.03] sm:px-6 sm:py-5">
            <div className="flex items-center gap-3">
              <span
                className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
                style={{ backgroundImage: grad(c1, c2), boxShadow: `0 10px 24px -10px ${hexAlpha(c1, 0.8)}` }}
              >
                <CatIcon name={system?.icon ?? "boxes"} className="h-[15px] w-[15px]" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  {t("wzSetupFor")}
                </p>
                <h3 className="truncate font-display text-[16px] font-extrabold text-slate-900 dark:text-white">
                  {sysName}
                </h3>
              </div>
              <button
                type="button"
                data-wizard-close
                onClick={requestClose}
                aria-label={t("ariaClose")}
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-slate-200 bg-white text-slate-500 transition hover:border-rose-300 hover:text-rose-500 active:scale-95 dark:border-white/10 dark:bg-white/5 dark:text-slate-400"
              >
                <CatIcon name="x" className="h-[13px] w-[13px]" />
              </button>
            </div>

            <div className="mt-4">
              <div className="flex items-center justify-between">
                <p className="text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
                  {t("wzStep")} <span className="text-brand-600 dark:text-brand-300">{step + 1}</span> {t("wzOf")} {total}
                </p>
                <p className="text-[10.5px] font-extrabold text-slate-700 dark:text-slate-200">{stepName}</p>
              </div>
              <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-white/10">
                <div
                  className="h-full rounded-full bg-linear-to-l from-brand-500 via-fuchsia-500 to-cyan-400 transition-all duration-500"
                  style={{ width: `${((step + 1) / total) * 100}%` }}
                />
              </div>
              <div className="mt-3 flex items-center gap-1" aria-hidden="true">
                {Array.from({ length: total }).map((_, i) => (
                  <span
                    key={i}
                    className="h-1 flex-1 rounded-full transition-all duration-300"
                    style={{
                      background:
                        i === step
                          ? "var(--color-brand-500, #6d5dfb)"
                          : i < step
                            ? "#10b981"
                            : "rgba(148,163,184,0.35)",
                    }}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* body */}
          <div className="min-h-[360px] px-5 py-6 sm:px-6 sm:py-7">
            {step === 0 ? <WelcomeStep systemId={draft.systemId} /> : null}
            {step === 1 ? <OrgStep draft={draft} update={update} error={error} /> : null}
            {step === 2 ? <ModulesStep draft={draft} update={update} error={error} /> : null}
            {step === 3 ? <AdminStep draft={draft} update={update} error={error} /> : null}
            {step === 4 ? <PrefsStep draft={draft} update={update} error={error} /> : null}
            {step === 5 ? <ReviewStep draft={draft} onJump={jumpTo} /> : null}
            {step === 6 ? (
              <DoneStep
                draft={draft}
                onLaunch={() => launch.mutate()}
                launching={launch.isPending}
                createdInstanceId={createdInstanceId}
                onContinue={continueToDashboard}
              />
            ) : null}
          </div>

          {/* footer */}
          <div className="border-t border-slate-200/80 bg-slate-50/80 px-5 py-4 dark:border-white/10 dark:bg-white/[0.03] sm:px-6">
            <div className="flex items-center justify-between gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={goBack}
                disabled={step === 0}
                className="inline-flex items-center gap-2 rounded-xl border-slate-200 bg-white px-4 py-2.5 text-[12.5px] font-bold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 disabled:pointer-events-none disabled:opacity-40 dark:border-white/10 dark:bg-white/5 dark:text-slate-300"
              >
                <CatIcon
                  name={lang === "ar" ? "arrow-right" : "arrow-left"}
                  className="h-[10px] w-[10px]"
                />
                {t("wzBack")}
              </Button>

              <div className="flex items-center gap-2">
                {step < total - 1 ? (
                  <Button
                    type="button"
                    onClick={goNext}
                    disabled={step === 5 && !consentAccepted}
                    className={cn(
                      "inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-50 disabled:pointer-events-none"
                    )}
                    style={{ backgroundImage: grad(c1, c2) }}
                  >
                    {step === 5 ? t("wzLaunch") : t("wzNext")}
                    <CatIcon
                      name={lang === "ar" ? "arrow-left" : "arrow-right"}
                      className="h-[10px] w-[10px]"
                    />
                  </Button>
                ) : null}
                {step === 5 && !consentAccepted ? (
                  <p className="text-[10.5px] font-bold text-rose-500">{lang === "ar" ? "\u064a\u062c\u0628 \u0627\u0644\u0645\u0648\u0627\u0641\u0642\u0629 \u0639\u0644\u0649 \u0627\u0644\u0633\u064a\u0627\u0633\u0629 \u0648\u0627\u0644\u0634\u0631\u0648\u0637 \u0623\u0648\u0644\u0627\u064b" : "Please accept the Privacy Policy and Terms first"}</p>
                ) : null}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* close confirmation — resolving dialog, rendered above the overlay (z-[120]) */}
      <AlertDialog open={confirmClose} onOpenChange={setConfirmClose}>
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"}>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("dlgWzCloseTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("dlgWzCloseMsg")}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("dlgCancel")}</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                discard();
              }}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              {t("dlgWzCloseBtn")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
    </MotionConfig>
  );
}

export default WizardOverlay;
