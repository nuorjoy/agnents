"use client";

import { EMAIL_RE } from "@/lib/validation";
export { EMAIL_RE } from "@/lib/validation";

/**
 * Ashrilogic — wizard shared bits.
 * Input class vocabulary (from the V2 design language), section headers,
 * the shake-on-error wrapper and the country / timezone catalogs.
 */
import { useEffect, type ReactNode } from "react";
import { motion, useAnimationControls } from "framer-motion";
import type { WizardDraft } from "@/lib/types";
import { cn } from "@/lib/utils";

/** Common props every wizard step receives from the overlay shell. */
export interface WizardStepProps {
  draft: WizardDraft;
  update: (patch: Partial<WizardDraft>) => void;
  /** Validation error marker from the shell: which field failed + a token that increments per attempt. */
  error: { field: string; token: number } | null;
}

/* ---------- shared class vocabulary (matches the V2 design language) ---------- */

export const WZ_INPUT = cn(
  "h-11 w-full rounded-xl border border-slate-200 bg-white px-3.5 text-[13px] font-semibold text-slate-800",
  "placeholder:font-normal placeholder:text-slate-400 transition",
  "focus:border-brand-400 focus:outline-none focus:ring-4 focus:ring-brand-500/15 focus:shadow-lg focus:shadow-brand-500/15",
  "dark:border-white/10 dark:bg-ink-900/60 dark:text-slate-100 dark:placeholder:text-slate-500",
  "dark:focus:bg-ink-900/80",
  "aria-invalid:border-rose-400 aria-invalid:ring-2 aria-invalid:ring-rose-500/20"
);

export const WZ_LABEL = "mb-1.5 block text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300";

/* ---------- countries & timezones (V2 catalog, verbatim) ----------
 * ROUND 84 (owner profile gate) — the catalog itself moved to
 * src/data/countries.ts so SERVER code can import it too (a "use client"
 * module's exports are opaque client references on the server). Re-exported
 * here so every existing wizard/dashboard import keeps working unchanged. */
export { COUNTRIES, TIMEZONES } from "@/data/countries";
export type { CountryOption } from "@/data/countries";

/* ---------- section heading ---------- */

export function StepHeading({
  title,
  desc,
}: {
  title: string;
  desc: string;
}) {
  return (
    <div>
      <h3 className="font-display text-lg font-extrabold text-slate-900 dark:text-white">{title}</h3>
      <p className="mt-1 text-[12.5px] text-slate-500 dark:text-slate-400">{desc}</p>
    </div>
  );
}

/* ---------- shake-on-error wrapper (framer-motion, no remount → focus preserved) ---------- */

/**
 * Shakes horizontally whenever `token` changes to a value > 0.
 * The wrapped DOM node is never remounted, so an input keeps its focus.
 */
export function ShakeField({ token, children }: { token: number; children: ReactNode }) {
  const controls = useAnimationControls();

  useEffect(() => {
    if (token > 0) {
      controls.start({ x: [0, -8, 8, -6, 6, -3, 0] }, { duration: 0.45 });
    }
  }, [token, controls]);

  return <motion.div animate={controls}>{children}</motion.div>;
}

/* ---------- email validation (shared wizard / team form) ---------- */

