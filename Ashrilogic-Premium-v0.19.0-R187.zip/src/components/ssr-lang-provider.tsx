"use client";

import { useEffect, useState, type ReactNode } from "react";
import { useAppStore } from "@/lib/store";
import { SsrLangContext } from "@/lib/i18n/ssr-lang";
import type { Lang } from "@/lib/types";

/**
 * Ashrilogic — ROUND 185 — SSR language provider (see the architecture
 * note in src/lib/i18n/ssr-lang.ts).
 *
 * Server pages wrap their tree with the language they resolved from the
 * ashrlc-lang cookie:
 *
 *   const lang = await resolveLandingLang();
 *   <SsrLangProvider lang={lang}> …islands… </SsrLangProvider>
 *
 * Render phases:
 *   1. SSR + hydration pass — context value = `lang` (the server's
 *      cookie language) → every useT() island renders the SAME text the
 *      server rendered: no Arabic-first flash, no text-content hydration
 *      mismatch.
 *   2. after mount — the value flips to the STORE language (zustand
 *      persist has rehydrated from localStorage by then). When cookie and
 *      store agree (the steady state the R185 setLang cookie-mirror
 *      keeps), setState receives an identical value and React bails out —
 *      zero re-renders. When they legitimately diverge (a visitor whose
 *      persisted language predates the cookie), the tree flips once to
 *      the user's language and AppProviders rewrites the cookie — the
 *      NEXT load is clean.
 *
 * Live language switching keeps working everywhere: every switch funnels
 * through setLang (which now writes the cookie), the store updates, this
 * provider re-renders with the new store value, and every context
 * consumer follows in the same frame.
 */
export function SsrLangProvider({
  lang,
  children,
}: {
  lang: Lang;
  children: ReactNode;
}) {
  const storeLang = useAppStore((s) => s.lang);
  const [live, setLive] = useState<Lang>(lang);

  useEffect(() => {
    setLive(storeLang);
  }, [storeLang]);

  return <SsrLangContext.Provider value={live}>{children}</SsrLangContext.Provider>;
}
