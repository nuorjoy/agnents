"use client";

/**
 * Ashrilogic — admin sidebar / nav.
 *
 * Desktop (`lg:`): a fixed vertical rail on the start side with the same
 * PREMIUM auto-collapse behavior as the tenant dashboard — pinned (default)
 * it stays at full width (w-64) with labels; unpinned it collapses to an
 * icon-only rail (w-16) when the pointer leaves and re-expands to full
 * width when the pointer re-enters. The pin/unpin toggle persists in
 * localStorage so a user's preference survives reloads. Hovering only
 * changes the rail's WIDTH (an overlay expansion), so the main content's
 * padding never shifts on hover — only when the user flips the pin.
 * Mobile: a horizontal scrollable pill nav (kept simple — no Sheet). The
 * auto-collapse is desktop-only — the mobile pill nav always shows full
 * labels.
 *
 * The active admin view is held in `AdminApp`'s local state and passed down
 * (NOT in the global store) because admin auth is ephemeral.
 *
 * Round 29: hover-intent prefetch — pointing at the الدعم (support) nav item
 * warms the ["tickets"] query so the reported slow first-visit disappears.
 */
import { useQueryClient } from "@tanstack/react-query";
import { fetchTickets } from "@/lib/api-client";
import { useT, type I18nKey } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { cn, grad } from "@/lib/utils";
import { PlatformBrandTile, usePlatformWordmark } from "@/components/shared/platform-brand";
import { SidebarFoldToggle } from "@/components/shared/sidebar-fold-toggle";

export type AdminView =
  | "overview"
  | "subscribers"
  | "sites"
  | "stores"
  | "systems"
  | "blog"
  | "partners"
  | "activity"
  | "packages"
  | "planOrders"
  | "support"
  | "admins"
  | "audit"
  | "ops"
  | "legal"
  | "trash"
  /* ROUND 142 — the official-site mobile-app storefront controls. */
  | "mobileApp"
  /* ROUND 167 — طلبات المؤسسات (the Enterprise quotes inbox — super+admin
   * surface; the reveal lever inside it is super-only). */
  | "quotes"
  /* ROUND 168 — منح المحفظة (the Super-Admin bulk wallet grants — a
   * money-moving billing surface beside the plans/orders/quotes trio). */
  | "walletGrants"
  /* ROUND 169 — مركز الرسائل (the tenant messaging center — segmented
   * campaigns to subscribers/tenants/plan audiences). */
  | "messages"
  /* ROUND 169 — العروض الترويجية (the site promotion banner manager). */
  | "promotions"
  /* ROUND 166 — استعادة البريد المختوم: the one-time sealed-email recovery
   * console (super-only; the view itself gates non-super roles to the
   * explainer + permission notice). */
  | "emailReveal"
  | "settings"
  | "newsletter";

interface NavItem {
  id: AdminView;
  labelKey: I18nKey;
  icon: string;
}

const MAIN_NAV: NavItem[] = [
  { id: "overview", labelKey: "adminOverview", icon: "gauge" },
  { id: "subscribers", labelKey: "adminSubscribers", icon: "users" },
  { id: "sites", labelKey: "adminSites", icon: "globe" },
  { id: "stores", labelKey: "adminStores", icon: "store" },
  { id: "systems", labelKey: "adminSystems", icon: "boxes" },
  /* CONTENT SYSTEM — the official site's content consoles: the blog editor
   * and the trusted-sector showcase, right under the systems catalog. */
  { id: "blog", labelKey: "adminBlog", icon: "newspaper" },
  { id: "partners", labelKey: "adminPartners", icon: "network" },
  { id: "activity", labelKey: "adminActivity", icon: "activity" },
];

const MANAGE_NAV: NavItem[] = [
  { id: "packages", labelKey: "adminPackages", icon: "package" },
  /* ROUND 47 — activation requests (طلبات التفعيل) right after the plans */
  { id: "planOrders", labelKey: "adminPlanOrders", icon: "receipt" },
  /* ROUND 167 — طلبات المؤسسات (Enterprise quote requests) beside the
     billing surfaces — the CRM behind the landing's quote dialog. */
  { id: "quotes", labelKey: "quotesNav", icon: "building" },
  /* ROUND 168 — منح المحفظة (bulk wallet grants) beside the billing
     surfaces — the money-moving goodwill lever (super+admin). */
  { id: "walletGrants", labelKey: "grantNav", icon: "gift" },
  /* ROUND 169 — مركز الرسائل (the tenant messaging center — segmented
     campaigns) beside the billing surfaces, after the wallet grants. */
  { id: "messages", labelKey: "msgNav", icon: "megaphone" },
  /* ROUND 169 — العروض الترويجية (the site promotion banner manager) — the
     marketing surface of the official site. */
  { id: "promotions", labelKey: "promoNav", icon: "tag" },
  { id: "support", labelKey: "adminSupport", icon: "headset" },
  { id: "admins", labelKey: "adminAdmins", icon: "shield-user" },
  { id: "audit", labelKey: "adminAudit", icon: "scroll-text" },
  /* ROUND 114 — the operations telemetry console (التشغيل): live snapshot
     of the hardened subsystems (audit chain, idempotency guards, scheduler
     leases, backup cache, rate limiting, auth backpressure, webhooks). */
  { id: "ops", labelKey: "adminOps", icon: "activity" },
  /* ROUND 117 — the platform legal documents console (المستندات
   * القانونية): the dynamic editor behind /privacy and /terms. */
  { id: "legal", labelKey: "adminLegal", icon: "scale" },
  /* ROUND 87 — the platform trash console (سلة المحذوفات): every
     soft-deleted row across every tenant + the platform itself. */
  { id: "trash", labelKey: "adminTrash", icon: "trash-2" },
  /* ROUND 142 — the official-site «Mobile App» storefront controls
     (Google Play + App Store links + publish toggle). */
  { id: "mobileApp", labelKey: "adminMobileApp", icon: "smartphone" },
  /* ROUND 166 — استعادة البريد المختوم (the one-time sealed-email reveal
     * lever — super-only surface, security-audited). */
  { id: "emailReveal", labelKey: "revealNav", icon: "key-round" },
  { id: "settings", labelKey: "adminSettings", icon: "cog" },
];

const NAV: NavItem[] = [...MAIN_NAV, ...MANAGE_NAV, { id: "newsletter", labelKey: "adminNewsletter", icon: "mail" }];

/** All admin views + their labels/icons — shared with the admin command palette. */
export const ADMIN_NAV: readonly NavItem[] = NAV;

/** Round 29 — lightweight hover-intent prefetch for the support inbox. */
function useSupportPrefetch() {
  const queryClient = useQueryClient();
  return () => {
    void queryClient.prefetchQuery({ queryKey: ["tickets"], queryFn: fetchTickets });
  };
}

export function AdminSidebar({
  active,
  onSelect,
  onLogout,
  isPinned,
  onTogglePin,
  isHovered,
  onHoverChange,
}: {
  active: AdminView;
  onSelect: (v: AdminView) => void;
  onLogout: () => void;
  /** premium auto-collapse — pin override (persists in localStorage). */
  isPinned: boolean;
  onTogglePin: () => void;
  isHovered: boolean;
  onHoverChange: (hovered: boolean) => void;
}) {
  const { t } = useT();
  const prefetchSupport = useSupportPrefetch();
  const expanded = isPinned || isHovered;

  return (
    <>
      {/* desktop vertical sidebar */}
      <aside
        onMouseEnter={() => onHoverChange(true)}
        onMouseLeave={() => onHoverChange(false)}
        aria-label={t("adminTitle")}
        className={cn(
          /* ROUND 164 — z-50 (was z-30): the fixed rail must paint ABOVE the
           * root-level sticky topbar (z-40, full-width) — the topbar's own
           * content is padded past the rail (lg:ps-[17rem]) so nothing
           * shifts visually, but the rail's header (brand + the طي/فتح
           * toggle) is no longer trapped under the frosted bar and is
           * finally clickable. */
          "fixed inset-y-0 start-0 z-50 hidden flex-col border-e border-slate-200/70 bg-white/90 backdrop-blur-xl transition-all duration-300 ease-in-out dark:border-white/[0.07] dark:bg-ink-950/90 lg:flex",
          expanded ? "w-64" : "w-16",
          /* hovered expansion sits ABOVE the main content so labels render
           * over the workspace while the rail's RESERVED space stays w-16. */
          /* no overlay */
        )}
      >
        <SidebarContent
          active={active}
          onSelect={onSelect}
          onLogout={onLogout}
          onTogglePin={onTogglePin}
          isPinned={isPinned}
          isHovered={isHovered}
          onHoverChange={onHoverChange}
          collapsed={!expanded}
          prefetchSupport={prefetchSupport}
        />
      </aside>

      {/* mobile horizontal pill nav — self-stretch so it fills the column
          layout width (its pills scroll inside via overflow-x-auto) */}
      <nav
        aria-label={t("adminTitle")}
        className="sticky top-16 z-20 min-w-0 self-stretch border-b border-slate-200/70 bg-white/85 backdrop-blur-xl dark:border-white/[0.07] dark:bg-[#05080f]/85 lg:hidden"
      >
        <ul className="no-scrollbar flex gap-1.5 overflow-x-auto px-3 py-2.5 sm:px-6">
          {NAV.map((item) => {
            const isActive = active === item.id;
            return (
              <li key={item.id} className="shrink-0">
                <button
                  type="button"
                  onClick={() => onSelect(item.id)}
                  onPointerEnter={item.id === "support" ? prefetchSupport : undefined}
                  aria-current={isActive ? "page" : undefined}
                  className={cn(
                    "flex min-h-11 items-center gap-1.5 rounded-full px-3.5 py-2 text-[12px] font-bold transition active:scale-95",
                    isActive
                      ? "bg-brand-500/10 text-brand-600 shadow-[0_0_18px_-6px_rgba(109,93,251,0.45)] dark:text-brand-300"
                      : "text-slate-500 hover:bg-slate-100 hover:text-slate-800 dark:text-slate-400 dark:hover:bg-white/[0.06] dark:hover:text-white"
                  )}
                >
                  <CatIcon name={item.icon} className="h-[13px] w-[13px]" />
                  {t(item.labelKey)}
                </button>
              </li>
            );
          })}
        </ul>
      </nav>
    </>
  );
}

function SidebarContent({
  active,
  onSelect,
  onLogout,
  onTogglePin,
  isPinned,
  collapsed,
  prefetchSupport,
}: {
  active: AdminView;
  onSelect: (v: AdminView) => void;
  onLogout: () => void;
  onTogglePin: () => void;
  isPinned: boolean;
  isHovered: boolean;
  onHoverChange: (hovered: boolean) => void;
  collapsed: boolean;
  prefetchSupport: () => void;
}) {
  const { t } = useT();
  const wordmark = usePlatformWordmark();

  return (
    <div className="flex h-full flex-col">
      {/* header — collapses to the brand tile + pin toggle when the rail
          is collapsed; the full text returns as soon as it expands. */}
      <div
        className={cn(
          "flex h-16 shrink-0 items-center justify-between border-b border-slate-200/70 dark:border-white/[0.07]",
          collapsed ? "px-2" : "px-4"
        )}
      >
        <div className={cn("flex min-w-0 items-center", collapsed ? "w-full justify-center" : "gap-2.5")}>
          <PlatformBrandTile
            variant="mini"
            className="h-9 w-9 shrink-0 rounded-xl"
            fallback={
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg shadow-brand-500/25"
                style={{ backgroundImage: grad("#6d5dfb", "#06b6d4") }}
                aria-hidden="true"
              >
                <CatIcon name="boxes" className="h-[14px] w-[14px]" />
              </span>
            }
          />
          {collapsed ? null : (
            <div className="min-w-0 leading-none">
              <p className="truncate font-display text-[13px] font-extrabold text-slate-900 dark:text-white">
                {t("adminTitle")}
              </p>
              <p className="mt-0.5 truncate text-[10px] font-semibold text-slate-500 dark:text-slate-400">
                {wordmark}
              </p>
            </div>
          )}
        </div>
        {/* ROUND 164 — the PREMIUM (طي / فتح) toggle: a color-morphing
            (red = fold · green = open) pill that replaces the old pin lock.
            The committed pin state and its localStorage persistence are
            unchanged — the same premium affordance as the tenant sidebar. */}
        <SidebarFoldToggle
          isPinned={isPinned}
          onToggle={onTogglePin}
          collapsed={collapsed}
          className={cn("transition-[margin] duration-300", collapsed && "mt-2")}
        />
      </div>

      {/* nav */}
      <nav className="flex-1 overflow-y-auto overflow-x-hidden px-2 py-4" aria-label={t("adminTitle")}>
        {collapsed ? null : (
          <p className="px-3 pb-2 text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            {t("adminOverview")}
          </p>
        )}
        <div className="space-y-1">
          {MAIN_NAV.map((item) => {
            const isActive = active === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelect(item.id)}
                aria-current={isActive ? "page" : undefined}
                aria-label={collapsed ? t(item.labelKey) : undefined}
                title={collapsed ? t(item.labelKey) : undefined}
                className={cn(
                  "group relative flex w-full items-center rounded-xl text-[12.5px] font-bold transition",
                  collapsed ? "justify-center px-0 py-2.5" : "gap-3 px-3 py-2.5",
                  isActive
                    ? "bg-brand-500/10 text-brand-600 shadow-[0_0_18px_-6px_rgba(109,93,251,0.45)] dark:text-brand-300 dark:shadow-[0_0_18px_-6px_rgba(139,120,255,0.4)]"
                    : "text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-white/[0.06] dark:hover:text-white"
                )}
              >
                {isActive ? (
                  <span
                    className={cn(
                      "absolute inset-y-1.5 w-[3px] rounded-full bg-linear-to-b from-brand-500 to-fuchsia-500",
                      collapsed ? "start-0.5" : "start-0"
                    )}
                    aria-hidden="true"
                  />
                ) : null}
                <CatIcon name={item.icon} className="h-4 w-4 shrink-0" />
                {collapsed ? null : <span className="flex-1 truncate text-start">{t(item.labelKey)}</span>}
              </button>
            );
          })}
        </div>

        {collapsed ? (
          <div className="my-2 ms-3 h-px w-6 rounded-full bg-slate-200/80 dark:bg-white/[0.08]" aria-hidden="true" />
        ) : (
          <p className="mt-5 px-3 pb-2 text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            {t("adminNavManage")}
          </p>
        )}
        <div className="space-y-1">
          {MANAGE_NAV.map((item) => {
            const isActive = active === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelect(item.id)}
                onPointerEnter={item.id === "support" ? prefetchSupport : undefined}
                aria-current={isActive ? "page" : undefined}
                aria-label={collapsed ? t(item.labelKey) : undefined}
                title={collapsed ? t(item.labelKey) : undefined}
                className={cn(
                  "group relative flex w-full items-center rounded-xl text-[12.5px] font-bold transition",
                  collapsed ? "justify-center px-0 py-2.5" : "gap-3 px-3 py-2.5",
                  isActive
                    ? "bg-brand-500/10 text-brand-600 shadow-[0_0_18px_-6px_rgba(109,93,251,0.45)] dark:text-brand-300 dark:shadow-[0_0_18px_-6px_rgba(139,120,255,0.4)]"
                    : "text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-white/[0.06] dark:hover:text-white"
                )}
              >
                {isActive ? (
                  <span
                    className={cn(
                      "absolute inset-y-1.5 w-[3px] rounded-full bg-linear-to-b from-fuchsia-500 to-cyan-400",
                      collapsed ? "start-0.5" : "start-0"
                    )}
                    aria-hidden="true"
                  />
                ) : null}
                <CatIcon name={item.icon} className="h-4 w-4 shrink-0" />
                {collapsed ? null : <span className="flex-1 truncate text-start">{t(item.labelKey)}</span>}
              </button>
            );
          })}
        </div>

        {collapsed ? (
          <div className="my-2 ms-3 h-px w-6 rounded-full bg-slate-200/80 dark:bg-white/[0.08]" aria-hidden="true" />
        ) : (
          <p className="mt-5 px-3 pb-2 text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            {t("adminNewsletter")}
          </p>
        )}
        <div className="space-y-1">
          <button
            type="button"
            onClick={() => onSelect("newsletter")}
            aria-current={active === "newsletter" ? "page" : undefined}
            aria-label={collapsed ? t("adminNewsletter") : undefined}
            title={collapsed ? t("adminNewsletter") : undefined}
            className={cn(
              "group relative flex w-full items-center rounded-xl text-[12.5px] font-bold transition",
              collapsed ? "justify-center px-0 py-2.5" : "gap-3 px-3 py-2.5",
              active === "newsletter"
                ? "bg-brand-500/10 text-brand-600 shadow-[0_0_18px_-6px_rgba(109,93,251,0.45)] dark:text-brand-300 dark:shadow-[0_0_18px_-6px_rgba(139,120,255,0.4)]"
                : "text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-white/[0.06] dark:hover:text-white"
            )}
          >
            {active === "newsletter" ? (
              <span
                className={cn(
                  "absolute inset-y-1.5 w-[3px] rounded-full bg-linear-to-b from-brand-500 to-fuchsia-500",
                  collapsed ? "start-0.5" : "start-0"
                )}
                aria-hidden="true"
              />
            ) : null}
            <CatIcon name="mail" className="h-4 w-4 shrink-0" />
            {collapsed ? null : <span className="flex-1 truncate text-start">{t("adminNewsletter")}</span>}
          </button>
        </div>
      </nav>

      {/* logout — collapses to the icon only when the rail is collapsed. */}
      <div className={cn("shrink-0 border-t border-slate-200/70 p-3 dark:border-white/[0.07]", collapsed && "px-2")}>
        <button
          type="button"
          onClick={onLogout}
          aria-label={collapsed ? t("adminLogout") : undefined}
          title={collapsed ? t("adminLogout") : undefined}
          className={cn(
            "flex w-full items-center rounded-xl bg-slate-50 text-[12.5px] font-extrabold text-slate-600 transition hover:bg-rose-50 hover:text-rose-600 dark:bg-white/[0.03] dark:text-slate-300 dark:hover:bg-rose-500/10 dark:hover:text-rose-300",
            collapsed ? "justify-center px-0 py-2.5" : "gap-2.5 px-3 py-2.5"
          )}
        >
          <CatIcon name="log-out" className="h-4 w-4 shrink-0" />
          {collapsed ? null : <span className="flex-1 text-start">{t("adminLogout")}</span>}
        </button>
      </div>
    </div>
  );
}

export default AdminSidebar;
