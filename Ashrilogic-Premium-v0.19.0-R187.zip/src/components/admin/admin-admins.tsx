"use client";

/**
 * Ashrilogic — admin users management view.
 *
 * KPI cards, a debounced search (name / email / username) and a Table on
 * desktop / card list on mobile. Full CRUD: create + edit through a
 * client-validated Dialog form (partial PATCH on edit), suspend / reactivate
 * from the row menu, delete behind an AlertDialog confirm. The seed
 * super-admin row is server-protected (403) — the server message surfaces in
 * a toast and the row carries a lock hint. An informational permissions
 * matrix card closes the view. Clicking a row's name (or the row-menu
 * “view profile” item) opens a read-only profile dialog: account details,
 * the role's permission chips and the latest audit-trail entries.
 *
 * Round 29: the photo uploader now accepts up to 10MB and runs the shared
 * analyzeImage pipeline (decode → measure → compress) BEFORE the avatar is
 * committed, showing the analysis line (source dims · before → after) next
 * to the live preview; destructive controls are hidden for roles below
 * admin (server stays the enforcer).
 *
 * Round 81 (81-RBAC-TAB): the view is now a premium TAB switcher —
 * «المسؤولون» (this list, untouched) and «الأدوار والصلاحيات», the new
 * platform RBAC matrix tab (server-enforcement banner, 4 role cards with
 * live member counts, the audited 14×4 permission matrix grouped by domain,
 * and the ADMIN_TIER tenant note).
 *
 * ROUND 82 (BATCH-5 ①): strict separation — the «المسؤولون» tab now
 * carries ONLY administrator data (people, credentials, status, activity).
 * Every roles/permissions surface moved to «الأدوار والصلاحيات»:
 *  - the old informational 6-permission matrix card was already superseded;
 *  - the profile dialog's permission-chips section is replaced by a role
 *    summary + a jump button into the roles tab (onViewRoles);
 *  - the list-tab KPI “distinct roles” became a people-domain KPI (admins
 *    signed in during the last 7 days);
 *  - the roles tab gained the per-role MEMBER roster (avatars + names),
 *    so “who holds which role” lives only there.
 */
import { Fragment, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  createAdminUser,
  deleteAdminUser,
  fetchAuditEntries,
  fetchAdminUsers,
  updateAdminUser,
} from "@/lib/api-client";
import { useAdminCanManage } from "@/lib/admin-auth";
import { useT, type I18nKey } from "@/lib/i18n";
import { formatBytes } from "@/lib/image-tools";
import { AvatarCropperDialog, type CropResult } from "@/components/admin/avatar-cropper";
import type { AdminGender, AdminRole, AdminUserDTO, AdminUserPayload, AuditAction, Lang, PresenceDTO } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, initial, labelTrack, normalizeSearch } from "@/lib/utils";
import { EMAIL_RE } from "@/components/wizard/wizard-shared";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PremiumDateInput } from "@/components/ui/premium-date-input";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { DashCard, IconTile, ViewHeading, fullDate, relativeTime } from "@/components/dashboard/dash-shared";
import { KpiCard } from "@/components/shared/kpi-card";
import { PresenceDot } from "@/components/shared/presence-dot";
import { useAdminPresence } from "@/components/admin/admin-presence-provider";

/* ---------------- round 26: shared avatar ---------------- */

/** Premium admin avatar — uploaded photo first, else the gender icon
    (male/female), else the name initial. Always wears the role gradient. */
export function AdminAvatar({
  admin,
  size = "sm",
  className,
}: {
  admin: Pick<AdminUserDTO, "name" | "avatarUrl" | "gender" | "role">;
  size?: "sm" | "md" | "lg";
  className?: string;
}) {
  const tile = ROLE_TILE[admin.role];
  const dim =
    size === "lg" ? "h-16 w-16" : size === "md" ? "h-10 w-10" : "h-8 w-8";
  const iconDim =
    size === "lg" ? "h-[22px] w-[22px]" : size === "md" ? "h-[16px] w-[16px]" : "h-[13px] w-[13px]";
  const textDim =
    size === "lg" ? "text-[18px]" : size === "md" ? "text-[12px]" : "text-[11px]";

  if (admin.avatarUrl) {
    return (
      <span
        className={cn(
          "relative grid shrink-0 place-items-center overflow-hidden rounded-full text-white shadow-lg",
          dim,
          className
        )}
        style={{ backgroundImage: grad(tile.c1, tile.c2) }}
      >
          <img src={admin.avatarUrl} alt="" className="h-full w-full object-cover" />
      </span>
    );
  }
  if (admin.gender === "male" || admin.gender === "female") {
    return (
      <span
        className={cn("grid shrink-0 place-items-center rounded-full text-white shadow-md", dim, className)}
        style={{ backgroundImage: grad(tile.c1, tile.c2) }}
        aria-hidden="true"
      >
        <CatIcon name={admin.gender === "male" ? "mars" : "venus"} className={iconDim} />
      </span>
    );
  }
  return (
    <span
      className={cn(
        "grid shrink-0 place-items-center rounded-full font-extrabold text-white shadow-md",
        dim,
        textDim,
        className
      )}
      style={{ backgroundImage: grad(tile.c1, tile.c2) }}
      aria-hidden="true"
    >
      {initial(admin.name)}
    </span>
  );
}

/** Locale-aware age helper — null when the birth date is unset or in the future. */
function ageFromBirth(birthDate: string | null): number | null {
  if (!birthDate) return null;
  const b = new Date(birthDate);
  if (Number.isNaN(b.getTime())) return null;
  const now = new Date();
  let age = now.getFullYear() - b.getFullYear();
  const m = now.getMonth() - b.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < b.getDate())) age -= 1;
  return age >= 0 && age < 130 ? age : null;
}

/* ---------------- roles & permissions ---------------- */

const ROLES: readonly AdminRole[] = ["super", "admin", "moderator", "viewer"];

const ROLE_KEY: Record<AdminRole, I18nKey> = {
  super: "staffRoleSuper",
  admin: "staffRoleAdmin",
  moderator: "staffRoleModerator",
  viewer: "staffRoleViewer",
};

const ROLE_BADGE: Record<AdminRole, string> = {
  super: "border-brand-400/70 bg-linear-to-r from-brand-600 via-fuchsia-500 to-cyan-500 bg-clip-text text-transparent dark:from-brand-300 dark:via-fuchsia-400 dark:to-cyan-300",
  admin: "border-cyan-400/60 bg-cyan-500/10 text-cyan-600 dark:border-cyan-500/40 dark:text-cyan-300",
  moderator: "border-amber-400/60 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-400",
  viewer: "border-slate-300/70 bg-slate-500/10 text-slate-600 dark:border-white/15 dark:bg-white/10 dark:text-slate-300",
};

const ROLE_TILE: Record<AdminRole, { icon: string; c1: string; c2: string }> = {
  super: { icon: "shield-user", c1: "#6d5dfb", c2: "#4b35c9" },
  admin: { icon: "shield-check", c1: "#06b6d4", c2: "#0891b2" },
  moderator: { icon: "user-cog", c1: "#f59e0b", c2: "#d97706" },
  viewer: { icon: "eye", c1: "#64748b", c2: "#475569" },
};

const USERNAME_RE = /^[a-zA-Z0-9_.-]{3,32}$/;

/** audit dot-key → existing bilingual action label (unknown keys fall back to the raw key). */
const AUDIT_ACTION_KEY: Partial<Record<AuditAction, I18nKey>> = {
  "admin.login": "auditActAdminLogin",
  "admin.loginFailed": "auditActAdminLoginFailed",
  "admin.logout": "auditActAdminLogout",
  "admin.create": "auditActAdminCreate",
  "admin.update": "auditActAdminUpdate",
  "admin.delete": "auditActAdminDelete",
  "package.create": "auditActPackageCreate",
  "package.update": "auditActPackageUpdate",
  "package.delete": "auditActPackageDelete",
  "settings.update": "auditActSettingsUpdate",
  "ticket.create": "auditActTicketCreate",
  "ticket.update": "auditActTicketUpdate",
  "ticket.delete": "auditActTicketDelete",
  "instance.create": "auditActInstanceCreate",
  "instance.update": "auditActInstanceUpdate",
  "instance.delete": "auditActInstanceDelete",
  "instance.login": "auditActInstanceLogin",
  "instance.loginFailed": "auditActInstanceLoginFailed",
  "instance.logout": "auditActInstanceLogout",
  "instance.password": "auditActInstancePassword",
  "instance.memberAdd": "auditActInstanceMemberAdd",
  "instance.memberUpdate": "auditActInstanceMemberUpdate",
  "instance.memberRemove": "auditActInstanceMemberRemove",
  "instance.ticketCreate": "auditActInstanceTicketCreate",
  "instance.upgradeRequest": "auditActInstanceUpgradeRequest",
  "instance.resetDemo": "auditActInstanceResetDemo",
};

/** Field vocabulary shared with the admin login card. */
const FIELD_INPUT =
  "h-11 rounded-xl border-slate-200 bg-slate-50/80 px-3.5 text-[13px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:focus:bg-white/[0.07]";

/* Arabic never letter-spaces (labelTrack) — form labels render in both langs */
const FIELD_LABEL_BASE = "text-[11px] font-extrabold uppercase text-slate-500 dark:text-slate-400";
const fieldLabel = (lang: Lang) => cn(FIELD_LABEL_BASE, labelTrack(lang));

/** The seed recovery account — server-protected against demote/suspend/delete. */
const isPrimarySuperAdmin = (admin: AdminUserDTO) =>
  admin.username === "admin" && admin.role === "super";

/* ---------------- row pieces ---------------- */

function RoleBadge({ role }: { role: AdminRole }) {
  const { t } = useT();
  return (
    <Badge
      className={cn(
        "rounded-full border px-2.5 py-0.5 text-[11px] font-extrabold",
        ROLE_BADGE[role]
      )}
    >
      {t(ROLE_KEY[role])}
    </Badge>
  );
}

function StatusBadge({ active }: { active: boolean }) {
  const { t } = useT();
  return (
    <Badge
      className={cn(
        "gap-1.5 rounded-full border px-2.5 py-0.5 text-[11px] font-extrabold",
        active
          ? "border-emerald-400/60 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
          : "border-rose-400/60 bg-rose-500/10 text-rose-600 dark:border-rose-500/40 dark:text-rose-300"
      )}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-current" aria-hidden="true" />
      {active ? t("staffActive") : t("staffInactive")}
    </Badge>
  );
}

function SuperLockChip() {
  const { t } = useT();
  return (
    <span
      title={t("staffSuperProtected")}
      className="inline-flex shrink-0 items-center gap-1 rounded-full border border-amber-400/60 bg-amber-500/10 px-1.5 py-0.5 text-amber-600 dark:border-amber-500/40 dark:text-amber-400"
    >
      <CatIcon name="lock" className="h-[10px] w-[10px]" />
      <span className="sr-only">{t("staffSuperProtected")}</span>
    </span>
  );
}

function RowActions({
  admin,
  canManage,
  onProfile,
  onEdit,
  onToggle,
  onDelete,
}: {
  admin: AdminUserDTO;
  /** round 29 — below-admin roles only get the read-only profile item */
  canManage: boolean;
  onProfile: (admin: AdminUserDTO) => void;
  onEdit: (admin: AdminUserDTO) => void;
  onToggle: (admin: AdminUserDTO) => void;
  onDelete: (admin: AdminUserDTO) => void;
}) {
  const { t } = useT();
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-label={t("adminColActions")}
          className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:text-slate-300"
        >
          <CatIcon name="ellipsis-vertical" className="h-[14px] w-[14px]" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuItem onClick={() => onProfile(admin)}>
          <CatIcon name="id-card" className="h-4 w-4" />
          {t("profileView")}
        </DropdownMenuItem>
        {canManage ? (
          <>
            <DropdownMenuItem onClick={() => onEdit(admin)}>
              <CatIcon name="pencil" className="h-4 w-4" />
              {t("staffEditTitle")}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onToggle(admin)}>
              <CatIcon name="power" className="h-4 w-4" />
              {t("staffToggleActive")}
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={() => onDelete(admin)}
              className="text-rose-600 focus:text-rose-600 dark:text-rose-400 dark:focus:text-rose-400"
            >
              <CatIcon name="trash-2" className="h-4 w-4" />
              {t("staffDeleteTitle")}
            </DropdownMenuItem>
          </>
        ) : (
          <DropdownMenuItem disabled title={t("adminNoPerm")}>
            <CatIcon name="lock" className="h-4 w-4" />
            {t("adminNoPerm")}
          </DropdownMenuItem>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

/* ---------------- KPI card ---------------- */
/* Consolidated into src/components/shared/kpi-card.tsx. */

/* ---------------- profile dialog ---------------- */

/** One label/value tile of the profile account-details grid. */
function DetailTile({
  label,
  title,
  children,
}: {
  label: string;
  title?: string;
  children: ReactNode;
}) {
  const { lang } = useT();
  return (
    <div
      title={title}
      className="min-w-0 rounded-xl border border-slate-200/80 bg-white/80 px-3 py-2.5 dark:border-white/[0.07] dark:bg-white/[0.04]"
    >
      <p className={cn("text-start text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
        {label}
      </p>
      <div className="mt-1 min-w-0 text-[12.5px] font-bold text-slate-800 dark:text-slate-100">
        {children}
      </div>
    </div>
  );
}

/** Compact profile section: gradient mini tile + tiny uppercase heading + body. */
function ProfileSection({
  icon,
  c1,
  c2,
  title,
  children,
}: {
  icon: string;
  c1: string;
  c2: string;
  title: string;
  children: ReactNode;
}) {
  const { lang } = useT();
  return (
    <section className="rounded-2xl border border-slate-200/80 bg-slate-50/60 p-4 dark:border-white/[0.07] dark:bg-white/[0.02]">
      <div className="flex items-center gap-2.5">
        <IconTile icon={icon} c1={c1} c2={c2} size="sm" />
        <h3 className={cn("text-start text-[11px] font-extrabold uppercase text-slate-500 dark:text-slate-400", labelTrack(lang))}>
          {title}
        </h3>
      </div>
      <div className="mt-3">{children}</div>
    </section>
  );
}

/**
 * Read-only admin profile: identity header, account-details tiles, the
 * role summary with a jump into «الأدوار والصلاحيات» and the latest
 * audit-trail entries. Edit hands the row to the shared create/edit dialog.
 */
function AdminProfileDialog({
  admin,
  onClose,
  onEdit,
  onViewRoles,
  roleMemberCount,
}: {
  admin: AdminUserDTO | null;
  onClose: () => void;
  onEdit: (admin: AdminUserDTO) => void;
  /** ROUND 82 — jump into «الأدوار والصلاحيات» (permissions live ONLY there) */
  onViewRoles: () => void;
  /** live count of admins holding this admin's role (people-context only) */
  roleMemberCount: number;
}) {
  const { t, lang } = useT();
  /* ROUND 172 — live presence: the heartbeat snapshot's map WINS over the
   *  DTO row value (fresher than the list read); falls back to the DTO. */
  const presenceCtx = useAdminPresence();
  const livePresence: PresenceDTO | undefined = admin
    ? presenceCtx.snapshot?.admins?.[admin.id] ?? admin.presence
    : undefined;

  const activity = useQuery({
    queryKey: ["audit", "admin", admin?.id ?? "-"],
    queryFn: () => fetchAuditEntries({ actorType: "admin", limit: 100 }),
    enabled: !!admin,
  });

  const entries = useMemo(
    () => (admin ? (activity.data?.entries ?? []).filter((e) => e.actorId === admin.id) : []),
    [activity.data, admin]
  );

  return (
    <Dialog open={!!admin} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[85vh] overflow-y-auto rounded-3xl sm:max-w-lg">
        {admin ? (
          <div className="space-y-4">
            {/* identity header — uploaded photo / gender icon / initial */}
            <DialogHeader>
              <div className="flex items-center gap-4 text-start">
                <AdminAvatar admin={admin} size="lg" className="rounded-2xl" />
                <div className="min-w-0 flex-1">
                  <DialogTitle className="flex items-center gap-2 truncate pe-8 font-display text-[18px] font-extrabold leading-tight text-slate-900 dark:text-white">
                    <span className="truncate">{lang !== "ar" && admin.nameEn ? admin.nameEn : admin.name}</span>
                    {/* ROUND 172 — live online/offline projection (green/red) */}
                    {livePresence ? (
                      <PresenceDot presence={livePresence} now={presenceCtx.snapshot?.serverTime} />
                    ) : null}
                  </DialogTitle>
                  {admin.nameEn ? (
                    <p
                      dir={lang === "ar" ? "ltr" : "rtl"}
                      className={cn(
                        "mt-0.5 truncate text-[11px] font-bold text-slate-400 dark:text-slate-500",
                        lang === "ar" ? "text-end" : "text-start"
                      )}
                    >
                      {lang === "ar" ? admin.nameEn : admin.name}
                    </p>
                  ) : null}
                  <p
                    dir="ltr"
                    className={cn(
                      "mt-0.5 truncate font-mono text-[12px] font-bold text-slate-400 dark:text-slate-500",
                      lang === "ar" ? "text-end" : "text-start"
                    )}
                  >
                    @{admin.username}
                  </p>
                  <div className="mt-2 flex flex-wrap items-center gap-1.5">
                    <RoleBadge role={admin.role} />
                    <StatusBadge active={admin.active} />
                    {isPrimarySuperAdmin(admin) ? <SuperLockChip /> : null}
                  </div>
                </div>
              </div>
              <DialogDescription className="sr-only">{t("profileTitle")}</DialogDescription>
            </DialogHeader>

            {isPrimarySuperAdmin(admin) ? (
              <p className="flex items-center gap-2 rounded-xl border border-amber-400/60 bg-amber-500/10 px-3 py-2.5 text-[11px] font-bold leading-relaxed text-amber-600 dark:border-amber-500/40 dark:text-amber-300">
                <CatIcon name="lock" className="h-3.5 w-3.5 shrink-0" />
                {t("profileProtected")}
              </p>
            ) : null}

            {/* account details */}
            <ProfileSection icon="id-card" c1="#06b6d4" c2="#0891b2" title={t("profileAccount")}>
              <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                <DetailTile label={t("profileUsername")}>
                  <span
                    dir="ltr"
                    className={cn("block truncate font-mono", lang === "ar" ? "text-end" : "text-start")}
                  >
                    @{admin.username}
                  </span>
                </DetailTile>
                {admin.nameEn ? (
                  <DetailTile label={t("staffNameEn")}>
                    <span dir="ltr" className={cn("block truncate", lang === "ar" ? "text-end" : "text-start")}>
                      {admin.nameEn}
                    </span>
                  </DetailTile>
                ) : null}
                <DetailTile label={t("profileEmail")} title={admin.email}>
                  <span
                    dir="ltr"
                    className={cn("block truncate", lang === "ar" ? "text-end" : "text-start")}
                  >
                    {admin.email}
                  </span>
                </DetailTile>
                <DetailTile label={t("profileRole")}>
                  <RoleBadge role={admin.role} />
                </DetailTile>
                <DetailTile label={t("profileStatus")}>
                  <StatusBadge active={admin.active} />
                </DetailTile>
                <DetailTile
                  label={t("profileMemberSince")}
                  title={fullDate(admin.createdAt, lang)}
                >
                  {relativeTime(admin.createdAt, lang)}
                </DetailTile>
                <DetailTile
                  label={t("profileLastLogin")}
                  title={admin.lastLoginAt ? fullDate(admin.lastLoginAt, lang) : undefined}
                >
                  {admin.lastLoginAt ? relativeTime(admin.lastLoginAt, lang) : t("staffNever")}
                </DetailTile>
                <DetailTile label={t("profileUpdated")} title={fullDate(admin.updatedAt, lang)}>
                  {relativeTime(admin.updatedAt, lang)}
                </DetailTile>
              </div>
            </ProfileSection>

            {/* personal details — gender / birth date (+ age) / residence */}
            <ProfileSection icon="id-card" c1="#ec4899" c2="#be185d" title={t("staffProfileInfo")}>
              <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                <DetailTile label={t("staffGender")}>
                  {admin.gender ? (
                    <span
                      className={cn(
                        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-extrabold",
                        admin.gender === "male"
                          ? "border-cyan-400/60 bg-cyan-500/10 text-cyan-600 dark:border-cyan-500/40 dark:text-cyan-300"
                          : "border-pink-400/60 bg-pink-500/10 text-pink-600 dark:border-pink-500/40 dark:text-pink-300"
                      )}
                    >
                      <CatIcon name={admin.gender === "male" ? "mars" : "venus"} className="h-3 w-3" />
                      {t(admin.gender === "male" ? "staffGenderMale" : "staffGenderFemale")}
                    </span>
                  ) : (
                    <span className="text-[12px] font-semibold text-slate-400 dark:text-slate-500">
                      {t("staffGenderUnset")}
                    </span>
                  )}
                </DetailTile>
                <DetailTile
                  label={t("staffBirthDate")}
                  title={admin.birthDate ? fullDate(new Date(admin.birthDate), lang) : undefined}
                >
                  {admin.birthDate ? (
                    <span dir="ltr" className={cn("flex items-center gap-1.5 tabular-nums", lang === "ar" ? "flex-row-reverse" : "")}>
                      <span>{new Date(admin.birthDate).toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB")}</span>
                      {ageFromBirth(admin.birthDate) !== null ? (
                        <span className="inline-flex items-center gap-0.5 rounded-full bg-slate-100 px-1.5 py-0.5 text-[10px] font-extrabold text-slate-500 dark:bg-white/10 dark:text-slate-300">
                          <CatIcon name="cake" className="h-[10px] w-[10px]" />
                          {fmtNum(ageFromBirth(admin.birthDate) as number, lang)} {t("staffAgeYears")}
                        </span>
                      ) : null}
                    </span>
                  ) : (
                    <span className="text-[12px] font-semibold text-slate-400 dark:text-slate-500">—</span>
                  )}
                </DetailTile>
                <div className="min-w-0 rounded-xl border border-slate-200/80 bg-white/80 px-3 py-2.5 sm:col-span-2 dark:border-white/[0.07] dark:bg-white/[0.04]">
                  <p className={cn("text-start text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                    {t("staffAddress")}
                  </p>
                  <div className="mt-1 flex items-start gap-1.5 text-[12.5px] font-bold text-slate-800 dark:text-slate-100">
                    <CatIcon name="map-pin" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-pink-500 dark:text-pink-400" />
                    <span className="min-w-0 break-words leading-relaxed">
                      {admin.address ?? <span className="font-semibold text-slate-400 dark:text-slate-500">—</span>}
                    </span>
                  </div>
                </div>
              </div>
            </ProfileSection>

            {/* ROUND 82 — role summary + jump into the roles tab (the
             * permissions matrix lives ONLY in «الأدوار والصلاحيات») */}
            <ProfileSection icon="shield-user" c1="#f59e0b" c2="#d97706" title={t("profileRoleCard")}>
              <div className="flex flex-wrap items-center gap-2.5">
                <RoleBadge role={admin.role} />
                <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-[10.5px] font-extrabold tabular-nums text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400">
                  <CatIcon name="users" className="h-3 w-3" />
                  {fmtNum(roleMemberCount, lang)}
                  <span className="sr-only">{t("rbacMembers")}</span>
                </span>
              </div>
              <p className="mt-2.5 text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                {t(ROLE_DESC[admin.role])}
              </p>
              <Button
                type="button"
                onClick={onViewRoles}
                className="mt-3 h-9 w-full gap-2 rounded-xl border border-brand-300/70 bg-brand-500/[0.07] px-4 text-[11.5px] font-extrabold text-brand-600 transition hover:bg-brand-500/15 hover:shadow-lg hover:shadow-brand-500/10 active:scale-[0.98] dark:border-brand-500/40 dark:bg-brand-500/10 dark:text-brand-300 dark:hover:bg-brand-500/20"
              >
                <CatIcon name="shield-check" className="h-3.5 w-3.5" />
                {t("profileViewRolesBtn")}
                <CatIcon name="chevron-right" className="h-3.5 w-3.5 rtl:rotate-180" />
              </Button>
            </ProfileSection>

            {/* activity */}
            <ProfileSection icon="activity" c1="#8b5cf6" c2="#7c3aed" title={t("profileActivity")}>
              <div className="flex flex-wrap items-center gap-2">
                <Badge
                  variant="secondary"
                  className="rounded-full px-2.5 py-1 text-[10.5px] font-extrabold text-slate-600 dark:text-slate-300"
                >
                  {activity.isPending ? "…" : t("profileActionsCount", { count: entries.length })}
                </Badge>
                <p className="text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                  {t("profileActionsScope")}
                </p>
              </div>
              {activity.isError ? (
                <p className="mt-2.5 text-[11.5px] font-semibold text-rose-500 dark:text-rose-400">
                  {activity.error instanceof Error ? activity.error.message : t("errorText")}
                </p>
              ) : activity.isPending ? (
                <div className="mt-3 space-y-2">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <Skeleton key={i} className="h-9 w-full rounded-xl" />
                  ))}
                </div>
              ) : entries.length === 0 ? (
                <p className="mt-2.5 text-[11.5px] font-semibold text-slate-400 dark:text-slate-500">
                  {t("profileNoActivity")}
                </p>
              ) : (
                <ul className="mt-3 space-y-2">
                  {entries.slice(0, 3).map((e) => {
                    const key = AUDIT_ACTION_KEY[e.action];
                    return (
                      <li
                        key={e.id}
                        className="flex items-baseline justify-between gap-3 rounded-xl border border-slate-200/80 bg-white/80 px-3 py-2 dark:border-white/[0.06] dark:bg-white/[0.03]"
                      >
                        <p className="min-w-0 truncate text-[12px] font-bold text-slate-700 dark:text-slate-200">
                          {key ? t(key) : e.action}
                          {e.targetLabel ? (
                            <span className="ms-1.5 font-semibold text-slate-400 dark:text-slate-500">
                              — {e.targetLabel}
                            </span>
                          ) : null}
                        </p>
                        <p
                          title={fullDate(e.createdAt, lang)}
                          className="shrink-0 whitespace-nowrap text-[10.5px] font-semibold text-slate-400 dark:text-slate-500"
                        >
                          {relativeTime(e.createdAt, lang)}
                        </p>
                      </li>
                    );
                  })}
                </ul>
              )}
            </ProfileSection>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => onEdit(admin)}
                className="h-10 gap-2 rounded-xl px-5 text-[12.5px] font-bold transition hover:border-brand-400 hover:text-brand-600 dark:hover:border-brand-500/50 dark:hover:text-brand-300 active:scale-95"
              >
                <CatIcon name="pencil" className="h-4 w-4" />
                {t("staffEditTitle")}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                className="h-10 rounded-xl px-5 text-[12.5px] font-bold active:scale-95"
              >
                {t("dlgCancel")}
              </Button>
            </DialogFooter>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}

/* ---------------- form dialog ---------------- */

interface FormState {
  name: string;
  /* ROUND 167 — optional English/secondary name (nameEn); empty = unset */
  nameEn: string;
  username: string;
  email: string;
  role: AdminRole;
  active: boolean;
  /* login credential — create: optional; edit: blank keeps the current one */
  password: string;
  /* round-26 premium profile fields */
  gender: AdminGender | null;
  avatarUrl: string | null;
  /* "YYYY-MM-DD" ("" = unset) */
  birthDate: string;
  address: string;
}

const EMPTY_FORM: FormState = {
  name: "",
  nameEn: "",
  username: "",
  email: "",
  role: "admin",
  active: true,
  password: "",
  gender: null,
  avatarUrl: null,
  birthDate: "",
  address: "",
};

type FormMode = { kind: "closed" } | { kind: "create" } | { kind: "edit"; admin: AdminUserDTO };

function matchesQuery(admin: AdminUserDTO, q: string): boolean {
  if (!q) return true;
  return normalizeSearch([admin.name, admin.nameEn ?? "", admin.email, admin.username].join(" ")).includes(q);
}

/* ---------------- view ---------------- */

export function AdminAdmins() {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  /* round 29 — only super/admin manage admin accounts (server-enforced) */
  const canManage = useAdminCanManage();
  /* ROUND 172 — live presence heartbeat (45s): the snapshot's admins map
   * overrides the DTO row value when present (heartbeat wins — fresher). */
  const presenceCtx = useAdminPresence();
  const livePresence = (admin: AdminUserDTO): PresenceDTO | undefined =>
    presenceCtx.snapshot?.admins?.[admin.id] ?? admin.presence;
  const presenceNow = presenceCtx.snapshot?.serverTime;

  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  const [formMode, setFormMode] = useState<FormMode>({ kind: "closed" });
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [invalid, setInvalid] = useState<{ name?: boolean; username?: boolean; email?: boolean; password?: boolean }>({});
  const [pendingDelete, setPendingDelete] = useState<AdminUserDTO | null>(null);
  const [profileAdmin, setProfileAdmin] = useState<AdminUserDTO | null>(null);

  /* ROUND 81 (81-RBAC-TAB) — admins page tab: list / roles & permissions */
  const [tab, setTab] = useState<AdminsTab>("list");
  const tabRefs = useRef<Record<AdminsTab, HTMLButtonElement | null>>({ list: null, roles: null });

  useEffect(() => {
    const h = window.setTimeout(() => setDebounced(normalizeSearch(search.trim())), 150);
    return () => window.clearTimeout(h);
  }, [search]);

  const query = useQuery({
    queryKey: ["admin-users"],
    queryFn: fetchAdminUsers,
  });

  const admins = useMemo(() => query.data ?? [], [query.data]);

  const visible = useMemo(() => {
    const roleRank = (role: AdminRole) => ROLES.indexOf(role);
    return [...admins]
      .filter((a) => matchesQuery(a, debounced))
      .sort(
        (a, b) =>
          roleRank(a.role) - roleRank(b.role) ||
          a.name.localeCompare(b.name, lang === "ar" ? "ar" : "en")
      );
  }, [admins, debounced, lang]);

  const stats = useMemo(
    () => ({
      total: admins.length,
      active: admins.filter((a) => a.active).length,
      super: admins.filter((a) => a.role === "super").length,
      /* ROUND 82 — people-domain KPI (the old "distinct roles" stat moved
       * to the roles tab with the rest of the roles content) */
      recent: admins.filter(
        (a) => a.lastLoginAt && Date.now() - new Date(a.lastLoginAt).getTime() < 7 * 86_400_000
      ).length,
    }),
    [admins]
  );

  /* ROUND 172 — live «متصل الآن» count (from the heartbeat's admins map;
   *  null while the first beat is in flight → no KPI sub-line yet). */
  const onlineAdmins = useMemo(
    () =>
      presenceCtx.snapshot?.admins
        ? Object.values(presenceCtx.snapshot.admins).filter((p) => p.online).length
        : null,
    [presenceCtx.snapshot]
  );

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["admin-users"] });

  const create = useMutation({
    mutationFn: (payload: AdminUserPayload) => createAdminUser(payload),
    onSuccess: () => {
      toast.success(t("staffSaved"));
      setFormMode({ kind: "closed" });
      invalidate();
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const update = useMutation({
    mutationFn: ({ admin, payload }: { admin: AdminUserDTO; payload: Partial<AdminUserPayload> }) =>
      updateAdminUser(admin.id, payload),
    onSuccess: () => {
      toast.success(t("staffUpdated"));
      setFormMode({ kind: "closed" });
      invalidate();
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const remove = useMutation({
    mutationFn: (id: string) => deleteAdminUser(id),
    onSuccess: () => {
      toast.success(t("staffRemoved"));
      setPendingDelete(null);
      invalidate();
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const openCreate = () => {
    setForm(EMPTY_FORM);
    setInvalid({});
    setAvatarAnalysis(null);
    setFormMode({ kind: "create" });
  };

  /* round 35 — WhatsApp-style avatar upload: ANY image size/dimensions is
   * accepted (up to 25MB), decoded raw, then fitted into the circular admin
   * avatar frame through the premium cropper dialog (drag / pinch / wheel
   * zoom, 90° rotate, live circular mask). The cropper emits a compressed
   * 288px circular JPEG (~≤120KB) far under the server's 600_000-char
   * avatarUrl cap. The analysis line is shown BEFORE the photo is committed. */
  const avatarInputRef = useRef<HTMLInputElement>(null);
  const [avatarAnalyzing, setAvatarAnalyzing] = useState(false);
  const [avatarAnalysis, setAvatarAnalysis] = useState<string | null>(null);
  /* raw picked image pending the circular crop */
  const [cropSrc, setCropSrc] = useState<string | null>(null);
  const [cropMeta, setCropMeta] = useState<{ w: number; h: number; bytes: number } | null>(null);

  const onAvatarFile = async (file: File | undefined | null) => {
    if (!file || avatarAnalyzing) return;
    if (file.size > 25 * 1024 * 1024) {
      toast.error(t("cropTooLarge"));
      return;
    }
    setAvatarAnalyzing(true);
    try {
      /* validate the type up front (same accept list as analyzeImage) */
      if (!/^image\/(png|jpe?g|webp|gif)$/.test(file.type)) {
        toast.error(t("siteLogoBadType"));
        return;
      }
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(new Error("read"));
        reader.readAsDataURL(file);
      });
      /* stash the original meta for the analysis line, then open the cropper */
      const probe = new Image();
      const dims = await new Promise<{ w: number; h: number }>((resolve, reject) => {
        probe.onload = () => resolve({ w: probe.naturalWidth, h: probe.naturalHeight });
        probe.onerror = () => reject(new Error("decode"));
        probe.src = dataUrl;
      }).catch(() => ({ w: 0, h: 0 }));
      if (!dims.w || !dims.h) {
        toast.error(t("siteLogoCorrupt"));
        return;
      }
      setCropMeta({ w: dims.w, h: dims.h, bytes: file.size });
      setCropSrc(dataUrl);
    } catch {
      toast.error(t("siteLogoCorrupt"));
    } finally {
      setAvatarAnalyzing(false);
    }
  };

  const onCropApply = (result: CropResult) => {
    setForm((f) => ({ ...f, avatarUrl: result.dataUrl }));
    setAvatarAnalysis(
      t("siteLogoAnalyzed", {
        dims: `${cropMeta?.w ?? 0}×${cropMeta?.h ?? 0}`,
        size: formatBytes(cropMeta?.bytes ?? 0, lang),
        out: formatBytes(result.outBytes, lang),
      })
    );
    setCropSrc(null);
  };

  const openEdit = (admin: AdminUserDTO) => {
    setForm({
      name: admin.name,
      nameEn: admin.nameEn ?? "",
      username: admin.username,
      email: admin.email,
      role: admin.role,
      active: admin.active,
      password: "",
      gender: admin.gender,
      avatarUrl: admin.avatarUrl,
      birthDate: admin.birthDate ?? "",
      address: admin.address ?? "",
    });
    setInvalid({});
    setAvatarAnalysis(null);
    setFormMode({ kind: "edit", admin });
  };

  const toggleActive = (admin: AdminUserDTO) => {
    update.mutate({ admin, payload: { active: !admin.active } });
  };

  const submit = () => {
    const nameOk = form.name.trim().length >= 2;
    const usernameOk = USERNAME_RE.test(form.username.trim());
    const emailOk = EMAIL_RE.test(form.email.trim());
    /* optional but validated when provided (min 6, matching the API schema) */
    const passwordOk = form.password.length === 0 || form.password.length >= 8;
    setInvalid({ name: !nameOk, username: !usernameOk, email: !emailOk, password: !passwordOk });
    if (!nameOk) {
      toast.error(t("staffErrName"));
      return;
    }
    if (!usernameOk) {
      toast.error(t("staffErrUsername"));
      return;
    }
    if (!emailOk) {
      toast.error(t("staffErrEmail"));
      return;
    }
    if (!passwordOk) {
      toast.error(t("staffErrPassword"));
      return;
    }

    const clean: AdminUserPayload = {
      name: form.name.trim(),
      nameEn: form.nameEn.trim() ? form.nameEn.trim() : null,
      username: form.username.trim(),
      email: form.email.trim(),
      role: form.role,
      active: form.active,
      gender: form.gender,
      avatarUrl: form.avatarUrl,
      birthDate: form.birthDate ? form.birthDate : null,
      address: form.address.trim() ? form.address.trim() : null,
      ...(form.password ? { password: form.password } : {}),
    };

    if (formMode.kind === "edit") {
      const admin = formMode.admin;
      const patch: Partial<AdminUserPayload> = {};
      if (admin.name !== clean.name) patch.name = clean.name;
      if ((admin.nameEn ?? null) !== (clean.nameEn ?? null)) patch.nameEn = clean.nameEn ?? null;
      if (admin.username !== clean.username) patch.username = clean.username;
      if (admin.email !== clean.email) patch.email = clean.email;
      if (admin.role !== clean.role) patch.role = clean.role;
      if (admin.active !== clean.active) patch.active = clean.active;
      if (admin.gender !== (clean.gender ?? null)) patch.gender = clean.gender ?? null;
      if (admin.avatarUrl !== (clean.avatarUrl ?? null)) patch.avatarUrl = clean.avatarUrl ?? null;
      if ((admin.birthDate ?? "") !== (clean.birthDate ?? "")) patch.birthDate = clean.birthDate ?? null;
      if ((admin.address ?? "") !== (clean.address ?? "")) patch.address = clean.address ?? null;
      if (form.password) patch.password = form.password;
      if (Object.keys(patch).length === 0) {
        setFormMode({ kind: "closed" });
        return;
      }
      update.mutate({ admin, payload: patch });
    } else {
      create.mutate(clean);
    }
  };

  const editing = formMode.kind === "edit" ? formMode.admin : null;
  const pending = create.isPending || update.isPending;

  if (query.isError) {
    return (
      <div className="space-y-5">
        <ViewHeading title={t("staffTitle")} desc={t("staffDesc")} />
        <DashCard>
          <div className="py-14 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-rose-100 text-rose-500 dark:bg-rose-500/10 dark:text-rose-300">
              <CatIcon name="circle-alert" className="h-6 w-6" />
            </div>
            <p className="mt-3 font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("errorText")}
            </p>
            {query.error instanceof Error ? (
              <p className="mx-auto mt-1 max-w-sm text-[12px] font-semibold text-slate-400 dark:text-slate-500">
                {query.error.message}
              </p>
            ) : null}
            <Button
              type="button"
              variant="outline"
              onClick={() => query.refetch()}
              className="mt-5 h-11 gap-2 rounded-xl px-5 text-[12.5px] font-bold"
            >
              <CatIcon name="refresh-cw" className="h-4 w-4" />
              {t("retryText")}
            </Button>
          </div>
        </DashCard>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <ViewHeading title={t("staffTitle")} desc={t("staffDesc")} />

      {/* ROUND 81 — premium segmented tab switcher (mirrors the plan-orders
       * status-filter chip style): roving tabindex + an arrow-key hop between
       * the two tabs (direction-agnostic, so RTL and LTR behave alike). */}
      <DashCard>
        <div
          role="tablist"
          aria-label={t("rbacTabsLabel")}
          onKeyDown={(e) => {
            if (e.key !== "ArrowLeft" && e.key !== "ArrowRight") return;
            e.preventDefault();
            const next: AdminsTab = tab === "list" ? "roles" : "list";
            setTab(next);
            tabRefs.current[next]?.focus();
          }}
          className="flex flex-wrap items-center gap-1.5"
        >
          {PAGE_TABS.map(({ key, icon, label }) => {
            const active = tab === key;
            return (
              <button
                key={key}
                ref={(el) => {
                  tabRefs.current[key] = el;
                }}
                id={`admins-tab-${key}`}
                type="button"
                role="tab"
                aria-selected={active}
                aria-controls={`admins-panel-${key}`}
                tabIndex={active ? 0 : -1}
                onClick={() => setTab(key)}
                className={cn(
                  "inline-flex h-9 items-center gap-2 rounded-xl px-4 text-[11.5px] font-extrabold transition active:scale-95",
                  active
                    ? "bg-linear-to-r from-brand-600 to-brand-500 text-white shadow-lg shadow-brand-500/25"
                    : "border border-slate-200 bg-white/70 text-slate-500 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:text-brand-300"
                )}
              >
                <CatIcon name={icon} className="h-3.5 w-3.5" />
                {t(label)}
              </button>
            );
          })}
        </div>
      </DashCard>

      {/* tab 1 — «المسؤولون»: ONLY administrator data (ROUND 82: the
       * roles/permissions content lives exclusively in tab 2) */}
      <div
        id="admins-panel-list"
        role="tabpanel"
        aria-labelledby="admins-tab-list"
        hidden={tab !== "list"}
        className="space-y-5"
      >
      {/* KPI cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard
          index={0}
          lang={lang}
          label={t("staffKpiTotal")}
          value={query.isPending ? "…" : fmtNum(stats.total, lang)}
          icon="users"
          c1="#6d5dfb"
          c2="#4b35c9"
        />
        <KpiCard
          index={1}
          lang={lang}
          label={t("staffKpiActive")}
          value={query.isPending ? "…" : fmtNum(stats.active, lang)}
          icon="circle-check"
          c1="#10b981"
          c2="#059669"
        />
        <KpiCard
          index={2}
          lang={lang}
          label={t("staffKpiSuper")}
          value={query.isPending ? "…" : fmtNum(stats.super, lang)}
          icon="shield-user"
          c1="#d946ef"
          c2="#c026d3"
        />
        <KpiCard
          index={3}
          lang={lang}
          label={t("staffKpiRecent")}
          value={query.isPending ? "…" : fmtNum(stats.recent, lang)}
          /* ROUND 172 — the live online count rides the «recent sign-ins»
           * card's sub-line (a 5th card would break the 4-card grid law) */
          sub={onlineAdmins !== null ? t("presenceOnlineCount", { count: fmtNum(onlineAdmins, lang) }) : undefined}
          icon="activity"
          c1="#06b6d4"
          c2="#0891b2"
        />
      </div>

      {/* list */}
      <DashCard>
        {/* search + count + add */}
        <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="relative max-w-md flex-1">
            <CatIcon
              name="search"
              className="pointer-events-none absolute start-3.5 top-1/2 h-[13px] w-[13px] -translate-y-1/2 text-slate-400"
            />
            <Input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t("staffSearchPh")}
              aria-label={t("staffSearchPh")}
              className="h-10 rounded-xl border-slate-200 bg-slate-50/80 ps-10 pe-3 text-[12.5px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:focus:bg-white/[0.07]"
            />
          </div>
          <div className="flex items-center gap-2">
            <Badge
              variant="secondary"
              className="rounded-full px-3 py-1 text-[11px] font-extrabold text-slate-600 dark:text-slate-300"
            >
              {fmtNum(visible.length, lang)} / {fmtNum(admins.length, lang)}
            </Badge>
            {canManage ? (
              <Button
                type="button"
                onClick={openCreate}
                className="h-10 gap-2 rounded-xl bg-linear-to-l from-brand-600 via-fuchsia-500 to-cyan-400 px-4 text-[12px] font-extrabold text-white shadow-lg shadow-brand-500/30 transition hover:brightness-110 active:scale-95"
              >
                <CatIcon name="user-plus" className="h-4 w-4" />
                {t("staffAddBtn")}
              </Button>
            ) : (
              <span
                title={t("adminNoPerm")}
                className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-dashed border-slate-300 px-3 text-[11px] font-bold text-slate-400 dark:border-white/15 dark:text-slate-500"
              >
                <CatIcon name="lock" className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">{t("adminNoPerm")}</span>
              </span>
            )}
          </div>
        </div>

        {query.isPending ? (
          <div className="space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-14 w-full rounded-xl" />
            ))}
          </div>
        ) : visible.length === 0 ? (
          <div className="py-14 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5">
              <CatIcon name="shield-user" className="h-6 w-6" />
            </div>
            <p className="mt-3 font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("staffEmpty")}
            </p>
            <p className="mx-auto mt-1 max-w-sm text-[12px] font-semibold text-slate-400 dark:text-slate-500">
              {t("staffEmptyDesc")}
            </p>
          </div>
        ) : (
          <>
            {/* desktop table */}
            <div className="hidden md:block">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-200/70 dark:border-white/10">
                    <TableHead className={cn("text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {t("staffColName")}
                    </TableHead>
                    <TableHead className={cn("text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {t("staffColEmail")}
                    </TableHead>
                    <TableHead className={cn("text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {t("staffColRole")}
                    </TableHead>
                    <TableHead className={cn("text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {t("staffColStatus")}
                    </TableHead>
                    <TableHead className={cn("text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {t("staffColLastLogin")}
                    </TableHead>
                    <TableHead className={cn("text-end text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {t("adminColActions")}
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {visible.map((admin) => {
                    const tile = ROLE_TILE[admin.role];
                    return (
                      <TableRow key={admin.id}>
                        <TableCell>
                          <div
                            role="button"
                            tabIndex={0}
                            aria-label={t("profileView")}
                            onClick={() => setProfileAdmin(admin)}
                            onKeyDown={(e) => {
                              if (e.key === "Enter" || e.key === " ") {
                                e.preventDefault();
                                setProfileAdmin(admin);
                              }
                            }}
                            className="-mx-1.5 flex cursor-pointer items-center gap-2.5 rounded-xl px-1.5 py-1 transition hover:bg-slate-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400/60 dark:hover:bg-white/[0.06] dark:focus-visible:ring-brand-400/50"
                          >
                            <AdminAvatar admin={admin} size="sm" />
                            <div className="min-w-0">
                              <p className="flex items-center gap-1.5 truncate text-start text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                                {lang !== "ar" && admin.nameEn ? admin.nameEn : admin.name}
                                {isPrimarySuperAdmin(admin) ? <SuperLockChip /> : null}
                                {/* ROUND 172 — live presence (heartbeat wins) */}
                                <PresenceDot presence={livePresence(admin)} now={presenceNow} />
                              </p>
                              {admin.nameEn && lang === "ar" ? (
                                <p dir="ltr" className="truncate text-end text-[10px] font-bold text-slate-400 dark:text-slate-500">
                                  {admin.nameEn}
                                </p>
                              ) : null}
                              <p
                                dir="ltr"
                                className={cn(
                                  "truncate font-mono text-[10.5px] font-bold text-slate-400 dark:text-slate-500",
                                  lang === "ar" ? "text-end" : "text-start"
                                )}
                              >
                                @{admin.username}
                              </p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <p
                            dir="ltr"
                            className={cn(
                              "truncate text-[12px] font-bold text-slate-700 dark:text-slate-200",
                              lang === "ar" ? "text-end" : "text-start"
                            )}
                          >
                            {admin.email}
                          </p>
                        </TableCell>
                        <TableCell>
                          <RoleBadge role={admin.role} />
                        </TableCell>
                        <TableCell>
                          <StatusBadge active={admin.active} />
                        </TableCell>
                        <TableCell>
                          <p className="whitespace-nowrap text-[11.5px] font-bold text-slate-600 dark:text-slate-300">
                            {admin.lastLoginAt ? relativeTime(admin.lastLoginAt, lang) : t("staffNever")}
                          </p>
                        </TableCell>
                        <TableCell className="text-end">
                          <div className="inline-flex">
                            <RowActions
                              admin={admin}
                              onProfile={setProfileAdmin}
                              onEdit={openEdit}
                              onToggle={toggleActive}
                              onDelete={setPendingDelete}
                              canManage={canManage}
                            />
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>

            {/* mobile cards */}
            <ul className="space-y-3 md:hidden">
              {visible.map((admin) => {
                const tile = ROLE_TILE[admin.role];
                return (
                  <li
                    key={admin.id}
                    className="rounded-2xl border border-slate-200/80 bg-white/80 p-4 dark:border-white/[0.07] dark:bg-white/[0.03]"
                  >
                    <div className="flex items-start gap-3">
                      <div
                        role="button"
                        tabIndex={0}
                        aria-label={t("profileView")}
                        onClick={() => setProfileAdmin(admin)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter" || e.key === " ") {
                            e.preventDefault();
                            setProfileAdmin(admin);
                          }
                        }}
                        className="flex min-w-0 flex-1 cursor-pointer items-start gap-3 rounded-xl p-1 -m-1 transition active:scale-[0.99] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400/60 dark:focus-visible:ring-brand-400/50"
                      >
                        <AdminAvatar admin={admin} size="md" />
                        <div className="min-w-0">
                          <p className="flex items-center gap-1.5 truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
                            {admin.name}
                            {isPrimarySuperAdmin(admin) ? <SuperLockChip /> : null}
                            {/* ROUND 172 — live presence (heartbeat wins) */}
                            <PresenceDot presence={livePresence(admin)} now={presenceNow} />
                          </p>
                          <p
                            dir="ltr"
                            className={cn(
                              "truncate font-mono text-[11px] font-bold text-slate-400 dark:text-slate-500",
                              lang === "ar" ? "text-end" : "text-start"
                            )}
                          >
                            @{admin.username}
                          </p>
                          <p
                            dir="ltr"
                            className={cn(
                              "mt-0.5 truncate text-[11px] font-semibold text-slate-500 dark:text-slate-400",
                              lang === "ar" ? "text-end" : "text-start"
                            )}
                          >
                            {admin.email}
                          </p>
                        </div>
                      </div>
                      <RowActions
                        admin={admin}
                        onProfile={setProfileAdmin}
                        onEdit={openEdit}
                        onToggle={toggleActive}
                        onDelete={setPendingDelete}
                        canManage={canManage}
                      />
                    </div>
                    <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-3 dark:border-white/[0.06]">
                      <RoleBadge role={admin.role} />
                      <StatusBadge active={admin.active} />
                      <p className="ms-auto text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                        {admin.lastLoginAt ? relativeTime(admin.lastLoginAt, lang) : t("staffNever")}
                      </p>
                    </div>
                  </li>
                );
              })}
            </ul>
          </>
        )}
      </DashCard>

      </div>

      {/* tab 2 — ROUND 81 (81-RBAC-TAB): «الأدوار والصلاحيات», the premium
       * platform RBAC matrix + per-role member rosters (supersedes the old
       * informational matrix card) */}
      <div
        id="admins-panel-roles"
        role="tabpanel"
        aria-labelledby="admins-tab-roles"
        hidden={tab !== "roles"}
      >
        <RolesPermissionsTab admins={admins} />
      </div>

      {/* create / edit dialog */}
      <Dialog
        open={formMode.kind !== "closed"}
        onOpenChange={(o) => !o && setFormMode({ kind: "closed" })}
      >
        <DialogContent className="max-h-[88vh] overflow-y-auto rounded-3xl sm:max-w-xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2.5 text-start font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-linear-to-br from-brand-500 to-fuchsia-500 text-white shadow-lg shadow-brand-500/25"
                aria-hidden="true"
              >
                <CatIcon name={editing ? "user-round-pen" : "user-plus"} className="h-[15px] w-[15px]" />
              </span>
              {editing ? t("staffEditTitle") : t("staffAddTitle")}
            </DialogTitle>
            <DialogDescription className="text-[12.5px] text-slate-500 dark:text-slate-400">
              {editing ? t("staffEditDesc") : t("staffAddDesc")}
            </DialogDescription>
          </DialogHeader>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              submit();
            }}
            noValidate
            className="space-y-4"
          >
            {/* admin photo — upload a real image or pick a gender default icon */}
            <fieldset className="rounded-2xl border border-dashed border-slate-300/80 bg-slate-50/50 p-3.5 dark:border-white/15 dark:bg-white/[0.02]">
              <legend className={cn("px-1.5 text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                {t("staffAvatarSection")}
              </legend>
              <div className="mt-2 flex flex-wrap items-start gap-4">
                {/* live preview — photo / gender icon / camera placeholder,
                    with a spinner overlay while the image is being analyzed */}
                <span className="relative shrink-0">
                  <span
                    className={cn(
                      "grid h-[72px] w-[72px] place-items-center overflow-hidden rounded-full text-white shadow-lg",
                      avatarAnalyzing && "opacity-60"
                    )}
                    style={{ backgroundImage: grad(ROLE_TILE[form.role].c1, ROLE_TILE[form.role].c2) }}
                    aria-hidden="true"
                  >
                    {form.avatarUrl ? (
                      <img src={form.avatarUrl} alt="" className="h-full w-full object-cover" />
                    ) : form.gender ? (
                      <CatIcon name={form.gender === "male" ? "mars" : "venus"} className="h-8 w-8" />
                    ) : (
                      <CatIcon name="camera" className="h-7 w-7 opacity-80" />
                    )}
                  </span>
                  {avatarAnalyzing ? (
                    <span
                      className="absolute inset-0 grid place-items-center"
                      aria-live="polite"
                      title={t("siteLogoAnalyzing")}
                    >
                      <span className="grid h-7 w-7 place-items-center rounded-full bg-white/90 shadow-md dark:bg-slate-900/90">
                        <CatIcon name="refresh-cw" className="h-3.5 w-3.5 animate-spin text-brand-500" />
                      </span>
                    </span>
                  ) : null}
                  {form.avatarUrl && !avatarAnalyzing ? (
                    <button
                      type="button"
                      onClick={() => {
                        setForm((f) => ({ ...f, avatarUrl: null }));
                        setAvatarAnalysis(null);
                      }}
                      aria-label={t("staffAvatarRemove")}
                      title={t("staffAvatarRemove")}
                      className="absolute -end-1 -top-1 grid h-6 w-6 place-items-center rounded-full bg-rose-600 text-white shadow-md transition hover:bg-rose-700 active:scale-90"
                    >
                      <CatIcon name="x" className="h-3 w-3" />
                    </button>
                  ) : null}
                </span>
                <div className="min-w-0 flex-1 space-y-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <input
                      ref={avatarInputRef}
                      type="file"
                      accept="image/png,image/jpeg,image/webp,image/gif"
                      className="hidden"
                      onChange={(e) => {
                        void onAvatarFile(e.target.files?.[0]);
                        e.target.value = "";
                      }}
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => avatarInputRef.current?.click()}
                      disabled={avatarAnalyzing}
                      className="h-9 gap-2 rounded-xl px-4 text-[12px] font-bold transition hover:border-brand-400 hover:text-brand-600 active:scale-95 disabled:opacity-60 dark:hover:border-brand-500/50 dark:hover:text-brand-300"
                    >
                      <CatIcon
                        name={avatarAnalyzing ? "refresh-cw" : "image-plus"}
                        className={cn("h-4 w-4", avatarAnalyzing && "animate-spin")}
                      />
                      {avatarAnalyzing
                        ? t("siteLogoAnalyzing")
                        : form.avatarUrl
                          ? t("staffAvatarChange")
                          : t("staffAvatarUpload")}
                    </Button>
                    <span className="hidden text-[10px] font-semibold text-slate-400 sm:inline dark:text-slate-500">
                      {t("staffAvatarHint10mb")}
                    </span>
                  </div>
                  {/* round 29 — analysis result shown BEFORE the photo is approved */}
                  {avatarAnalysis && form.avatarUrl && !avatarAnalyzing ? (
                    <p className="flex items-center gap-1.5 text-[10.5px] font-bold text-emerald-600 dark:text-emerald-300">
                      <CatIcon name="circle-check" className="h-3 w-3 shrink-0" />
                      <span className="min-w-0 truncate">{avatarAnalysis}</span>
                    </p>
                  ) : null}
                  {/* gender default icons — mutually exclusive chips */}
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                      {t("staffAvatarOrGender")}
                    </span>
                    {(["male", "female"] as const).map((g) => {
                      const active = form.gender === g && !form.avatarUrl;
                      return (
                        <button
                          key={g}
                          type="button"
                          onClick={() => {
                            setForm((f) => ({
                              ...f,
                              gender: f.gender === g ? null : g,
                              /* picking a gender drops a previously picked photo only when switching */
                              avatarUrl: f.gender === g ? f.avatarUrl : null,
                            }));
                            setAvatarAnalysis(null);
                          }}
                          aria-pressed={form.gender === g}
                          title={t(g === "male" ? "staffAvatarMale" : "staffAvatarFemale")}
                          className={cn(
                            "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11px] font-extrabold transition active:scale-95",
                            active
                              ? g === "male"
                                ? "border-cyan-400/70 bg-cyan-500/10 text-cyan-600 dark:border-cyan-500/50 dark:text-cyan-300"
                                : "border-pink-400/70 bg-pink-500/10 text-pink-600 dark:border-pink-500/50 dark:text-pink-300"
                              : "border-slate-200 bg-white text-slate-500 hover:border-slate-300 hover:text-slate-700 dark:border-white/10 dark:bg-white/5 dark:text-slate-400 dark:hover:text-slate-200"
                          )}
                        >
                          <CatIcon name={g === "male" ? "mars" : "venus"} className="h-3.5 w-3.5" />
                          {t(g === "male" ? "staffGenderMale" : "staffGenderFemale")}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </fieldset>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <Label htmlFor="staff-form-name" className={fieldLabel(lang)}>
                  {t("staffName")} <span className="text-rose-500">*</span>
                </Label>
                <div className="relative mt-1.5">
                  <CatIcon
                    name="user-round"
                    className="pointer-events-none absolute start-3.5 top-1/2 h-[14px] w-[14px] -translate-y-1/2 text-slate-400"
                  />
                  <Input
                    id="staff-form-name"
                    value={form.name}
                    onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                    placeholder={t("staffName")}
                    maxLength={60}
                    autoComplete="off"
                    dir="auto"
                    aria-invalid={invalid.name || undefined}
                    className={`${FIELD_INPUT} ps-10`}
                  />
                </div>
                <p className="mt-1 text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                  {t("staffNameArHint")}
                </p>
              </div>
              {/* ROUND 167 — bilingual admin identity: the optional English/
                  secondary name. Latin-first field (dir ltr) with a SOFT
                  warning for Arabic glyphs — never a hard block, the field
                  exists precisely for other scripts. */}
              <div className="sm:col-span-2">
                <Label htmlFor="staff-form-name-en" className={fieldLabel(lang)}>
                  {t("staffNameEn")}
                </Label>
                <div className="relative mt-1.5">
                  <CatIcon
                    name="languages"
                    className="pointer-events-none absolute start-3.5 top-1/2 h-[14px] w-[14px] -translate-y-1/2 text-slate-400"
                  />
                  <Input
                    id="staff-form-name-en"
                    value={form.nameEn}
                    onChange={(e) => setForm((f) => ({ ...f, nameEn: e.target.value }))}
                    placeholder={t("staffNameEnPh")}
                    maxLength={80}
                    autoComplete="off"
                    dir="ltr"
                    className={`${FIELD_INPUT} ps-10 text-start`}
                  />
                </div>
                <p className="mt-1 text-[10px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                  {/[\u0600-\u06FF]/.test(form.nameEn) ? t("staffNameEnWarn") : t("staffNameEnHint")}
                </p>
              </div>
              <div>
                <Label htmlFor="staff-form-username" className={fieldLabel(lang)}>
                  {t("staffUsername")} <span className="text-rose-500">*</span>
                </Label>
                <div className="relative mt-1.5">
                  <CatIcon
                    name="at-sign"
                    className="pointer-events-none absolute start-3.5 top-1/2 h-[14px] w-[14px] -translate-y-1/2 text-slate-400"
                  />
                  <Input
                    id="staff-form-username"
                    dir="ltr"
                    value={form.username}
                    onChange={(e) => setForm((f) => ({ ...f, username: e.target.value }))}
                    placeholder="username"
                    maxLength={32}
                    autoComplete="off"
                    aria-invalid={invalid.username || undefined}
                    className={`${FIELD_INPUT} ps-10 text-start`}
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="staff-form-email" className={fieldLabel(lang)}>
                  {t("staffEmail")} <span className="text-rose-500">*</span>
                </Label>
                <div className="relative mt-1.5">
                  <CatIcon
                    name="mail"
                    className="pointer-events-none absolute start-3.5 top-1/2 h-[14px] w-[14px] -translate-y-1/2 text-slate-400"
                  />
                  <Input
                    id="staff-form-email"
                    type="email"
                    dir="ltr"
                    value={form.email}
                    onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                    placeholder="name@company.com"
                    maxLength={120}
                    autoComplete="off"
                    aria-invalid={invalid.email || undefined}
                    className={`${FIELD_INPUT} ps-10 text-start`}
                  />
                </div>
              </div>
              <div className="sm:col-span-2">
                <Label htmlFor="staff-form-password" className={fieldLabel(lang)}>
                  {editing ? t("staffPasswordReset") : t("staffPassword")}{" "}
                  <span className="font-bold text-slate-400 dark:text-slate-500">
                    ({editing ? t("staffPasswordKeepHint") : t("staffPasswordHint")})
                  </span>
                </Label>
                <div className="relative mt-1.5">
                  <CatIcon
                    name="key-round"
                    className="pointer-events-none absolute start-3.5 top-1/2 h-[14px] w-[14px] -translate-y-1/2 text-slate-400"
                  />
                  <Input
                    id="staff-form-password"
                    type="text"
                    dir="ltr"
                    value={form.password}
                    onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
                    placeholder={editing ? t("staffPasswordPlaceholder") : "••••••"}
                    maxLength={72}
                    autoComplete="new-password"
                    aria-invalid={invalid.password || undefined}
                    className={`${FIELD_INPUT} ps-10 text-start`}
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="staff-form-role" className={fieldLabel(lang)}>
                  {t("staffRole")}
                </Label>
                <Select
                  value={form.role}
                  onValueChange={(v) => setForm((f) => ({ ...f, role: v as AdminRole }))}
                  disabled={editing !== null && isPrimarySuperAdmin(editing)}
                >
                  <SelectTrigger id="staff-form-role" className={`${FIELD_INPUT} mt-1.5 w-full justify-between`}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="rounded-xl">
                    <SelectGroup>
                      {ROLES.map((role) => (
                        <SelectItem key={role} value={role} className="text-[12.5px] font-bold">
                          {t(ROLE_KEY[role])}
                        </SelectItem>
                      ))}
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end">
                <div className="flex w-full items-center justify-between gap-3 rounded-xl border border-slate-200 bg-slate-50/60 px-3.5 py-2.5 dark:border-white/10 dark:bg-white/[0.03]">
                  <div className="min-w-0">
                    <Label htmlFor="staff-form-active" className="block text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                      {t("staffStatus")}
                    </Label>
                    <p
                      className={cn(
                        "text-[11px] font-bold",
                        form.active
                          ? "text-emerald-600 dark:text-emerald-300"
                          : "text-rose-500 dark:text-rose-400"
                      )}
                    >
                      {form.active ? t("staffActive") : t("staffInactive")}
                    </p>
                  </div>
                  <Switch
                    id="staff-form-active"
                    tone="success"
                    checked={form.active}
                    onCheckedChange={(v) => setForm((f) => ({ ...f, active: v }))}
                    aria-label={t("staffStatus")}
                    disabled={editing !== null && isPrimarySuperAdmin(editing)}
                  />
                </div>
              </div>

              {/* birth date — R163: the shared premium date field (the
                  staff form's h-11 rhythm) with its own brand calendar
                  tile at the far right in Arabic; age preview below. */}
              <div>
                <Label htmlFor="staff-form-birth" className={fieldLabel(lang)}>
                  {t("staffBirthDate")}
                </Label>
                <PremiumDateInput
                  id="staff-form-birth"
                  size="lg"
                  value={form.birthDate}
                  max={new Date().toISOString().slice(0, 10)}
                  min="1925-01-01"
                  onChange={(e) => setForm((f) => ({ ...f, birthDate: e.target.value }))}
                  aria-label={t("staffBirthDate")}
                  wrapperClassName="mt-1.5"
                />
                {ageFromBirth(form.birthDate || null) !== null ? (
                  <p className="mt-1 flex items-center gap-1 text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                    <CatIcon name="calendar-days" className="h-3 w-3" />
                    {fmtNum(ageFromBirth(form.birthDate) as number, lang)} {t("staffAgeYears")}
                  </p>
                ) : null}
              </div>

              {/* residence address */}
              <div>
                <Label htmlFor="staff-form-address" className={fieldLabel(lang)}>
                  {t("staffAddress")}
                </Label>
                <div className="relative mt-1.5">
                  <CatIcon
                    name="map-pin"
                    className="pointer-events-none absolute start-3.5 top-1/2 h-[14px] w-[14px] -translate-y-1/2 text-slate-400"
                  />
                  <Input
                    id="staff-form-address"
                    value={form.address}
                    onChange={(e) => setForm((f) => ({ ...f, address: e.target.value }))}
                    placeholder={t("staffAddressPh")}
                    maxLength={160}
                    autoComplete="off"
                    dir="auto"
                    className={`${FIELD_INPUT} ps-10`}
                  />
                </div>
              </div>
            </div>

            {editing !== null && isPrimarySuperAdmin(editing) ? (
              <p className="flex items-center gap-2 rounded-xl border border-amber-400/60 bg-amber-500/10 px-3 py-2.5 text-[11px] font-bold leading-relaxed text-amber-600 dark:border-amber-500/40 dark:text-amber-300">
                <CatIcon name="lock" className="h-3.5 w-3.5 shrink-0" />
                {t("staffSuperProtected")}
              </p>
            ) : null}

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setFormMode({ kind: "closed" })}
                disabled={pending}
                className="h-10 rounded-xl px-5 text-[12.5px] font-bold"
              >
                {t("dlgCancel")}
              </Button>
              <Button
                type="submit"
                disabled={pending}
                className="h-10 gap-2 rounded-xl bg-linear-to-l from-brand-600 via-fuchsia-500 to-cyan-400 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
              >
                {pending ? (
                  <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                ) : (
                  <CatIcon name={editing ? "save" : "user-plus"} className="h-4 w-4" />
                )}
                {editing ? t("staffUpdateBtn") : t("staffAddBtn")}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* round 35 — WhatsApp-style circular avatar cropper (any size/dimensions) */}
      <AvatarCropperDialog
        open={cropSrc !== null}
        src={cropSrc}
        onClose={() => setCropSrc(null)}
        onApply={onCropApply}
      />

      {/* profile dialog — ROUND 82: role summary + jump into the roles tab */}
      <AdminProfileDialog
        admin={profileAdmin}
        onClose={() => setProfileAdmin(null)}
        onEdit={(a) => {
          setProfileAdmin(null);
          openEdit(a);
        }}
        onViewRoles={() => {
          setProfileAdmin(null);
          setTab("roles");
        }}
        roleMemberCount={
          profileAdmin ? admins.filter((a) => a.role === profileAdmin.role).length : 0
        }
      />

      {/* delete confirm */}
      <AlertDialog
        open={pendingDelete !== null}
        onOpenChange={(o) => !o && setPendingDelete(null)}
      >
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display text-lg font-extrabold text-slate-900 dark:text-white">
              {t("staffDeleteTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] text-slate-500 dark:text-slate-400">
              {t("staffDeleteMsg")}
              {pendingDelete ? ` — ${pendingDelete.name}` : ""}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={remove.isPending}>
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => pendingDelete && remove.mutate(pendingDelete.id)}
              disabled={remove.isPending}
              className="h-10 rounded-xl bg-rose-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60"
            >
              {remove.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="trash-2" className="h-4 w-4" />
              )}
              {t("staffDeleteConfirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

/* ---------------- ROUND 81 (81-RBAC-TAB): platform roles & permissions ---------------- */

/**
 * Round 81 — «الأدوار والصلاحيات» tab of the Super Admin panel's Admins
 * page. Mirrors the tenant-side roles-permissions-tab design language but
 * renders the PLATFORM matrix audited from the live route guards
 * (requireAdmin role arrays, the super-only levers and the
 * requireInstanceAccess ADMIN_TIER split). The matrix below is the reviewed
 * mirror of the SERVER truth — enforcement itself lives on every
 * /api/admin/* route; nothing here grants anything.
 */

/** Audited platform permission ids (the matrix rows). */
type PlatformPerm =
  | "panel.view"
  | "subscribers.govern"
  | "sites.manage"
  | "packages.manage"
  | "planOrders.confirm"
  | "support.triage"
  | "audit.view"
  | "customers.inbox"
  | "admins.manage"
  | "admins.delete"
  | "settings.manage"
  | "ai.manage"
  | "demo.reset"
  | "tenants.manage";

/** A matrix cell — "partial" marks the admin tenant-tier split (ADMIN_TIER). */
type PlatformGrant = boolean | "partial";

const PLATFORM_PERMS: readonly PlatformPerm[] = [
  "panel.view",
  "subscribers.govern",
  "sites.manage",
  "packages.manage",
  "planOrders.confirm",
  "support.triage",
  "audit.view",
  "customers.inbox",
  "admins.manage",
  "admins.delete",
  "settings.manage",
  "ai.manage",
  "demo.reset",
  "tenants.manage",
];

const PLATFORM_GROUPS = ["panel", "platform", "support", "tenants"] as const;
type PlatformGroup = (typeof PLATFORM_GROUPS)[number];

const PERM_LABEL: Record<PlatformPerm, I18nKey> = {
  "panel.view": "rbacPermPanelView",
  "subscribers.govern": "rbacPermSubscribers",
  "sites.manage": "rbacPermSites",
  "packages.manage": "rbacPermPackages",
  "planOrders.confirm": "rbacPermPlanOrders",
  "support.triage": "rbacPermSupport",
  "audit.view": "rbacPermAudit",
  "customers.inbox": "rbacPermCustomers",
  "admins.manage": "rbacPermAdmins",
  "admins.delete": "rbacPermAdminsDelete",
  "settings.manage": "rbacPermSettings",
  "ai.manage": "rbacPermAi",
  "demo.reset": "rbacPermDemo",
  "tenants.manage": "rbacPermTenants",
};

const PERM_DESC: Record<PlatformPerm, I18nKey> = {
  "panel.view": "rbacPermDescPanelView",
  "subscribers.govern": "rbacPermDescSubscribers",
  "sites.manage": "rbacPermDescSites",
  "packages.manage": "rbacPermDescPackages",
  "planOrders.confirm": "rbacPermDescPlanOrders",
  "support.triage": "rbacPermDescSupport",
  "audit.view": "rbacPermDescAudit",
  "customers.inbox": "rbacPermDescCustomers",
  "admins.manage": "rbacPermDescAdmins",
  "admins.delete": "rbacPermDescAdminsDelete",
  "settings.manage": "rbacPermDescSettings",
  "ai.manage": "rbacPermDescAi",
  "demo.reset": "rbacPermDescDemo",
  "tenants.manage": "rbacPermDescTenants",
};

const PERM_META: Record<PlatformPerm, { icon: string; c1: string; c2: string; group: PlatformGroup }> = {
  "panel.view": { icon: "chart-line", c1: "#6d5dfb", c2: "#4b35c9", group: "panel" },
  "subscribers.govern": { icon: "users-round", c1: "#06b6d4", c2: "#0891b2", group: "platform" },
  "sites.manage": { icon: "globe", c1: "#10b981", c2: "#059669", group: "platform" },
  "packages.manage": { icon: "package", c1: "#f59e0b", c2: "#d97706", group: "platform" },
  "planOrders.confirm": { icon: "circle-check", c1: "#d946ef", c2: "#c026d3", group: "platform" },
  "support.triage": { icon: "life-buoy", c1: "#14b8a6", c2: "#0d9488", group: "support" },
  "audit.view": { icon: "fingerprint", c1: "#8b5cf6", c2: "#7c3aed", group: "support" },
  "customers.inbox": { icon: "inbox", c1: "#ec4899", c2: "#be185d", group: "support" },
  "admins.manage": { icon: "shield-user", c1: "#f43f5e", c2: "#e11d48", group: "platform" },
  "admins.delete": { icon: "trash-2", c1: "#64748b", c2: "#475569", group: "platform" },
  "settings.manage": { icon: "settings", c1: "#f59e0b", c2: "#d97706", group: "platform" },
  "ai.manage": { icon: "sparkles", c1: "#8b5cf6", c2: "#7c3aed", group: "platform" },
  "demo.reset": { icon: "rotate-ccw", c1: "#6d5dfb", c2: "#4b35c9", group: "platform" },
  "tenants.manage": { icon: "building", c1: "#d946ef", c2: "#c026d3", group: "tenants" },
};

const GROUP_LABEL: Record<PlatformGroup, I18nKey> = {
  panel: "rbacGroupPanel",
  platform: "rbacGroupPlatform",
  support: "rbacGroupSupport",
  tenants: "rbacGroupTenants",
};

const GROUP_ICON: Record<PlatformGroup, string> = {
  panel: "chart-line",
  platform: "cubes",
  support: "life-buoy",
  tenants: "building",
};

const ROLE_DESC: Record<AdminRole, I18nKey> = {
  super: "rbacRoleDescSuper",
  admin: "rbacRoleDescAdmin",
  moderator: "rbacRoleDescModerator",
  viewer: "rbacRoleDescViewer",
};

/** Live member-count chip tint per role (mirrors the ROLE_TILE accents). */
const ROLE_MEMBER_TINT: Record<AdminRole, string> = {
  super: "bg-brand-500/15 text-brand-600 dark:text-brand-300",
  admin: "bg-cyan-500/15 text-cyan-600 dark:text-cyan-300",
  moderator: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
  viewer: "bg-slate-100 text-slate-500 dark:bg-white/[0.06] dark:text-slate-400",
};

/**
 * Round 81 — audited against the LIVE server guards:
 *  - panel.view:            requireAdmin() no-arg on the read-only surfaces
 *  - subscribers.govern:    ["super","admin"] on subscribers/[id] PATCH
 *  - sites.manage:          ["super","admin"] on sites/[id] + customers/inquiries
 *  - packages.manage:       ["super","admin"] on packages + [id]
 *  - planOrders.confirm:    ["super","admin"] on plan-orders/[id] PATCH
 *  - support.triage:        ["super","admin","moderator"] on tickets
 *  - audit.view:            ["super","admin","moderator"] on /api/admin/audit
 *  - customers.inbox:       ["super","admin","moderator"] on customers GET
 *  - admins.manage:         ["super","admin"] on admins + [id] PATCH
 *  - admins.delete:         ["super"] on admins/[id] DELETE
 *  - settings.manage:       ["super","admin"] on settings/newsletter/campaigns
 *  - ai.manage:             ["super"] on /api/admin/ai
 *  - demo.reset:            ["super"] on /api/admin/reset-demo
 *  - tenants.manage:        requireInstanceAccess — super = full mandate,
 *                           admin = ADMIN_TIER (everything EXCEPT tenant
 *                           governance: team/billing/workspace settings)
 */
const PLATFORM_GRANTS: Record<PlatformPerm, Record<AdminRole, PlatformGrant>> = {
  "panel.view": { super: true, admin: true, moderator: true, viewer: true },
  "subscribers.govern": { super: true, admin: true, moderator: false, viewer: false },
  "sites.manage": { super: true, admin: true, moderator: false, viewer: false },
  "packages.manage": { super: true, admin: true, moderator: false, viewer: false },
  "planOrders.confirm": { super: true, admin: true, moderator: false, viewer: false },
  "support.triage": { super: true, admin: true, moderator: true, viewer: false },
  "audit.view": { super: true, admin: true, moderator: true, viewer: false },
  "customers.inbox": { super: true, admin: true, moderator: true, viewer: false },
  "admins.manage": { super: true, admin: true, moderator: false, viewer: false },
  "admins.delete": { super: true, admin: false, moderator: false, viewer: false },
  "settings.manage": { super: true, admin: true, moderator: false, viewer: false },
  "ai.manage": { super: true, admin: false, moderator: false, viewer: false },
  "demo.reset": { super: true, admin: false, moderator: false, viewer: false },
  "tenants.manage": { super: true, admin: "partial", moderator: false, viewer: false },
};

/* ROUND 81 — the two admins-page tabs (segmented control above the panels) */
const PAGE_TABS = [
  { key: "list", icon: "users", label: "rbacTabList" },
  { key: "roles", icon: "shield-check", label: "rbacTabRoles" },
] as const;

type AdminsTab = (typeof PAGE_TABS)[number]["key"];

/** granted / partial / total stats for one role across the audited matrix. */
function platformRoleStats(role: AdminRole): { full: number; partial: number; total: number } {
  let full = 0;
  let partial = 0;
  for (const p of PLATFORM_PERMS) {
    const grant = PLATFORM_GRANTS[p][role];
    if (grant === true) full += 1;
    else if (grant === "partial") partial += 1;
  }
  return { full, partial, total: PLATFORM_PERMS.length };
}

/** One of the four role cards — identity tile, description, live member
 * count, granted/total progress bar, the role's marker chip (super =
 * «كل الصلاحيات» crown, admin = the +partial tenant-tier chip) and the
 * ROUND 82 member roster (avatars + names — "who holds this role" lives
 * ONLY in this tab, keeping «المسؤولون» pure administrators). */
function RoleStatCard({ role, members }: { role: AdminRole; members: AdminUserDTO[] }) {
  const { t, lang } = useT();
  const tile = ROLE_TILE[role];
  const { full, partial, total } = platformRoleStats(role);
  const pct = Math.round((full / total) * 100);
  const isSuper = role === "super";
  const [rosterOpen, setRosterOpen] = useState(false);

  const body = (
    <article
      className={cn(
        "glass-card card-in group relative overflow-hidden p-4 transition-shadow duration-300 hover:shadow-lift sm:p-5",
        isSuper ? "rounded-[22.5px]" : "rounded-3xl"
      )}
    >
      {/* gradient hairline */}
      <span
        className="pointer-events-none absolute inset-x-0 top-0 h-[2px] opacity-60 transition-opacity duration-300 group-hover:opacity-100"
        style={{ backgroundImage: grad(tile.c1, tile.c2, 90) }}
        aria-hidden="true"
      />
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2.5">
            <span
              className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
              style={{ backgroundImage: grad(tile.c1, tile.c2), boxShadow: `0 8px 20px -8px ${tile.c2}66` }}
              aria-hidden="true"
            >
              <CatIcon name={tile.icon} className="h-5 w-5" />
            </span>
            <div className="min-w-0">
              <p className="truncate font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                {t(ROLE_KEY[role])}
              </p>
              <p className="mt-0.5 text-[10.5px] font-extrabold tabular-nums text-slate-400 dark:text-slate-500">
                {t("rbacPermCount", { granted: fmtNum(full, lang), total: fmtNum(total, lang) })}
              </p>
            </div>
          </div>
          <p className="mt-2.5 line-clamp-3 min-h-[42px] text-[11px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
            {t(ROLE_DESC[role])}
          </p>
        </div>
        {/* live member count — rides the already-fetched admins query */}
        <span
          className={cn(
            "inline-flex shrink-0 items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-extrabold tabular-nums",
            ROLE_MEMBER_TINT[role]
          )}
        >
          <CatIcon name="users" className="h-3 w-3" />
          {fmtNum(members.length, lang)}
          <span className="sr-only">{t("rbacMembers")}</span>
        </span>
      </div>

      {/* granted-permission progress bar (ratio in the ARIA label) */}
      <div className="mt-3">
        <div
          className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/[0.07]"
          role="progressbar"
          aria-valuenow={full}
          aria-valuemin={0}
          aria-valuemax={total}
          aria-label={t("rbacProgressAria", { granted: fmtNum(full, lang), total: fmtNum(total, lang) })}
        >
          <div
            className="h-full rounded-full transition-[width] duration-700 ease-out"
            style={{ width: `${pct}%`, backgroundImage: grad(tile.c1, tile.c2) }}
          />
        </div>
      </div>

      {/* role marker — the super crown / the admin partial-split chip */}
      {isSuper ? (
        <p className="mt-3 inline-flex items-center gap-1.5 rounded-full border border-brand-400/60 bg-brand-500/10 px-2.5 py-1 text-[10px] font-extrabold text-brand-600 dark:border-brand-500/40 dark:text-brand-300">
          <CatIcon name="crown" className="h-3 w-3" />
          {t("rbacSuperAll")}
        </p>
      ) : partial > 0 ? (
        <p
          title={t("rbacPartialHint")}
          className="mt-3 inline-flex cursor-help items-center gap-1.5 rounded-full border border-amber-400/60 bg-amber-500/10 px-2.5 py-1 text-[10px] font-extrabold text-amber-600 dark:border-amber-500/40 dark:text-amber-400"
        >
          <CatIcon name="circle-dot" className="h-3 w-3" />
          {t("rbacPartialCount", { n: fmtNum(partial, lang) })}
        </p>
      ) : null}

      {/* ROUND 82 — member roster (avatars + names), collapsible. Empty
       * roles collapse to the muted empty note. */}
      <div className="mt-3 border-t border-slate-200/70 pt-3 dark:border-white/[0.07]">
        <button
          type="button"
          onClick={() => members.length > 0 && setRosterOpen((v) => !v)}
          aria-expanded={rosterOpen}
          aria-controls={`rbac-roster-${role}`}
          disabled={members.length === 0}
          className={cn(
            "flex w-full items-center gap-1.5 text-[10.5px] font-extrabold transition",
            members.length > 0
              ? "cursor-pointer text-slate-500 hover:text-brand-600 dark:text-slate-400 dark:hover:text-brand-300"
              : "cursor-default text-slate-300 dark:text-slate-600"
          )}
        >
          <CatIcon name="users" className="h-3 w-3" />
          {t("rbacRosterLabel", { n: fmtNum(members.length, lang) })}
          {members.length > 0 ? (
            <CatIcon
              name="chevron-down"
              className={cn(
                "ms-auto h-3 w-3 transition-transform duration-300",
                rosterOpen && "rotate-180"
              )}
            />
          ) : null}
        </button>
        {rosterOpen && members.length > 0 ? (
          <ul id={`rbac-roster-${role}`} className="mt-2.5 max-h-44 space-y-1.5 overflow-y-auto nice-scroll pe-1">
            {members.map((m) => (
              <li
                key={m.id}
                className="flex items-center gap-2 rounded-xl border border-slate-200/70 bg-white/70 px-2 py-1.5 dark:border-white/[0.06] dark:bg-white/[0.03]"
              >
                <AdminAvatar admin={m} size="sm" />
                <span className="min-w-0 flex-1 truncate text-[11.5px] font-bold text-slate-700 dark:text-slate-200">
                  {m.name}
                </span>
                <span
                  dir="ltr"
                  className="shrink-0 truncate font-mono text-[9.5px] font-bold text-slate-400 dark:text-slate-500"
                >
                  @{m.username}
                </span>
              </li>
            ))}
          </ul>
        ) : null}
      </div>
    </article>
  );

  /* super wears the royal gradient ring (the ROLE_BADGE.super gradient) */
  return isSuper ? (
    <div className="card-in rounded-3xl bg-linear-to-r from-brand-600 via-fuchsia-500 to-cyan-500 p-[1.5px] shadow-lg shadow-brand-500/20 transition-shadow duration-300 hover:shadow-lift">
      {body}
    </div>
  ) : (
    body
  );
}

/** Granted / denied / partial cell chip of the matrix. */
function GrantChip({ grant }: { grant: PlatformGrant }) {
  const { t } = useT();
  if (grant === "partial") {
    return (
      <span
        role="img"
        aria-label={t("rbacPartial")}
        title={t("rbacPartialHint")}
        className="inline-flex cursor-help items-center gap-1 rounded-full border border-amber-400/60 bg-amber-500/10 px-2 py-0.5 text-[10px] font-extrabold text-amber-600 dark:border-amber-500/40 dark:text-amber-400"
      >
        <CatIcon name="circle-dot" className="h-3 w-3" />
        {t("rbacPartial")}
      </span>
    );
  }
  return (
    <span
      role="img"
      aria-label={grant ? t("rbacGranted") : t("rbacDenied")}
      className={cn(
        "grid h-6 w-6 place-items-center rounded-full",
        grant
          ? "bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400"
          : "bg-slate-100 text-slate-300 dark:bg-white/5 dark:text-slate-600"
      )}
    >
      <CatIcon name={grant ? "circle-check" : "lock"} className="h-3.5 w-3.5" />
    </span>
  );
}

/** ROUND 81 — the premium platform RBAC matrix tab. */
function RolesPermissionsTab({ admins }: { admins: AdminUserDTO[] }) {
  const { t, lang } = useT();

  /* live member rosters per role (rides the already-fetched admins query) */
  const membersByRole = useMemo(() => {
    const groups: Record<AdminRole, AdminUserDTO[]> = {
      super: [],
      admin: [],
      moderator: [],
      viewer: [],
    };
    for (const a of admins) groups[a.role].push(a);
    for (const key of Object.keys(groups) as AdminRole[]) {
      groups[key].sort((x, y) => x.name.localeCompare(y.name, lang === "ar" ? "ar" : "en"));
    }
    return groups;
  }, [admins, lang]);

  return (
    <div className="space-y-5">
      {/* server-enforcement banner — the matrix is the reviewed mirror of the
       * guards the server applies on every admin API route */}
      <div className="relative overflow-hidden rounded-3xl border border-emerald-300/60 bg-linear-to-l from-emerald-50/90 to-teal-50/50 p-4 dark:border-emerald-500/25 dark:from-emerald-500/10 dark:to-teal-500/5 sm:p-5">
        <span
          aria-hidden="true"
          className="absolute -end-10 -top-12 h-32 w-32 rounded-full"
          style={{ background: "radial-gradient(circle, rgba(16,185,129,0.18), transparent 70%)" }}
        />
        <div className="flex flex-wrap items-center gap-3.5">
          <span
            className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-white shadow-lg shadow-emerald-500/25"
            style={{ backgroundImage: grad("#10b981", "#0d9488") }}
            aria-hidden="true"
          >
            <CatIcon name="shield-check" className="h-5.5 w-5.5" />
          </span>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <p className="font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                {t("rbacBannerTitle")}
              </p>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-300/70 bg-white/80 px-2.5 py-0.5 text-[10.5px] font-extrabold text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300">
                <span className="relative flex h-1.5 w-1.5" aria-hidden="true">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-500 opacity-60" />
                  <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-500" />
                </span>
                {t("rbacEnforced")}
              </span>
            </div>
            <p className="mt-1 max-w-2xl text-[11.5px] font-semibold leading-relaxed text-slate-600 dark:text-slate-400">
              {t("rbacBannerDesc")}
            </p>
          </div>
        </div>
      </div>

      {/* role cards — live member rosters + granted/total progress */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {ROLES.map((role) => (
          <RoleStatCard key={role} role={role} members={membersByRole[role]} />
        ))}
      </div>

      {/* the audited matrix — 14 permissions x 4 roles, grouped by domain */}
      <DashCard title={t("rbacTabRoles")} icon="shield-check">
        {/* desktop table */}
        <div className="hidden overflow-x-auto md:block">
          <Table className="min-w-[620px]">
            <TableHeader>
              <TableRow className="border-slate-200/70 dark:border-white/10">
                <TableHead
                  scope="col"
                  className={cn("w-[46%] text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}
                >
                  {t("rbacMatrixColPerm")}
                </TableHead>
                {ROLES.map((role) => {
                  const tile = ROLE_TILE[role];
                  return (
                    <TableHead
                      key={role}
                      scope="col"
                      className="text-center text-[11px] font-extrabold text-slate-400 dark:text-slate-500"
                    >
                      <span className="inline-flex items-center gap-1.5">
                        <span
                          className="grid h-4.5 w-4.5 place-items-center rounded-md text-white"
                          style={{ backgroundImage: grad(tile.c1, tile.c2) }}
                          aria-hidden="true"
                        >
                          <CatIcon name={tile.icon} className="h-2.5 w-2.5" />
                        </span>
                        <span className="whitespace-nowrap">{t(ROLE_KEY[role])}</span>
                      </span>
                    </TableHead>
                  );
                })}
              </TableRow>
            </TableHeader>
            <TableBody>
              {PLATFORM_GROUPS.map((group) => {
                const groupPerms = PLATFORM_PERMS.filter((p) => PERM_META[p].group === group);
                return (
                  <Fragment key={group}>
                    {/* group header row */}
                    <TableRow className="bg-slate-50/80 hover:bg-slate-50/80 dark:bg-white/[0.03] dark:hover:bg-white/[0.03]">
                      <TableCell colSpan={5} className="py-2">
                        <span className="flex items-center gap-2 text-[11px] font-extrabold text-slate-500 dark:text-slate-300">
                          <CatIcon name={GROUP_ICON[group]} className="h-3.5 w-3.5 text-brand-500" />
                          {t(GROUP_LABEL[group])}
                          <span className="rounded-full bg-slate-100 px-1.5 py-0.5 text-[9.5px] font-extrabold tabular-nums text-slate-400 dark:bg-white/[0.06] dark:text-slate-500">
                            {fmtNum(groupPerms.length, lang)}
                          </span>
                          <span className="ms-1 h-px flex-1 bg-slate-200/70 dark:bg-white/[0.07]" aria-hidden="true" />
                        </span>
                      </TableCell>
                    </TableRow>
                    {/* permission rows */}
                    {groupPerms.map((p) => {
                      const meta = PERM_META[p];
                      return (
                        <TableRow key={p}>
                          <TableCell>
                            <div className="flex items-center gap-2.5">
                              <span
                                className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-white shadow-sm"
                                style={{ backgroundImage: grad(meta.c1, meta.c2) }}
                                aria-hidden="true"
                              >
                                <CatIcon name={meta.icon} className="h-3.5 w-3.5" />
                              </span>
                              <div className="min-w-0">
                                <p className="truncate text-[12px] font-bold text-slate-700 dark:text-slate-200">
                                  {t(PERM_LABEL[p])}
                                </p>
                                <p className="truncate text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                                  {t(PERM_DESC[p])}
                                </p>
                              </div>
                            </div>
                          </TableCell>
                          {ROLES.map((role) => (
                            <TableCell key={role} className="text-center">
                              <GrantChip grant={PLATFORM_GRANTS[p][role]} />
                            </TableCell>
                          ))}
                        </TableRow>
                      );
                    })}
                  </Fragment>
                );
              })}
            </TableBody>
          </Table>
        </div>

        {/* mobile — stacked permission cards (one per permission, the four
         * role verdicts rendered as labeled chips underneath) */}
        <div className="space-y-4 md:hidden">
          {PLATFORM_GROUPS.map((group) => {
            const groupPerms = PLATFORM_PERMS.filter((p) => PERM_META[p].group === group);
            return (
              <section key={group} className="space-y-2.5">
                <span className="flex items-center gap-2 text-[11px] font-extrabold text-slate-500 dark:text-slate-300">
                  <CatIcon name={GROUP_ICON[group]} className="h-3.5 w-3.5 text-brand-500" />
                  {t(GROUP_LABEL[group])}
                  <span className="rounded-full bg-slate-100 px-1.5 py-0.5 text-[9.5px] font-extrabold tabular-nums text-slate-400 dark:bg-white/[0.06] dark:text-slate-500">
                    {fmtNum(groupPerms.length, lang)}
                  </span>
                  <span className="ms-1 h-px flex-1 bg-slate-200/70 dark:bg-white/[0.07]" aria-hidden="true" />
                </span>
                <ul className="space-y-2.5">
                  {groupPerms.map((p) => {
                    const meta = PERM_META[p];
                    return (
                      <li
                        key={p}
                        className="rounded-2xl border border-slate-200/80 bg-white/80 p-3 dark:border-white/[0.07] dark:bg-white/[0.03]"
                      >
                        <div className="flex items-center gap-2.5">
                          <span
                            className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-white shadow-sm"
                            style={{ backgroundImage: grad(meta.c1, meta.c2) }}
                            aria-hidden="true"
                          >
                            <CatIcon name={meta.icon} className="h-3.5 w-3.5" />
                          </span>
                          <div className="min-w-0">
                            <p className="truncate text-[12px] font-bold text-slate-700 dark:text-slate-200">
                              {t(PERM_LABEL[p])}
                            </p>
                            <p className="truncate text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                              {t(PERM_DESC[p])}
                            </p>
                          </div>
                        </div>
                        <ul className="mt-2.5 grid grid-cols-4 gap-1.5 border-t border-slate-100 pt-2.5 dark:border-white/[0.06]">
                          {ROLES.map((role) => (
                            <li key={role} className="flex min-w-0 flex-col items-center gap-1">
                              <GrantChip grant={PLATFORM_GRANTS[p][role]} />
                              <span className="max-w-full truncate text-[9px] font-bold text-slate-400 dark:text-slate-500">
                                {t(ROLE_KEY[role])}
                              </span>
                            </li>
                          ))}
                        </ul>
                      </li>
                    );
                  })}
                </ul>
              </section>
            );
          })}
        </div>
      </DashCard>

      {/* tenant-tier note — the ADMIN_TIER split on tenant surfaces */}
      <div className="relative overflow-hidden rounded-3xl border border-slate-200/80 bg-slate-50/60 p-4 dark:border-white/10 dark:bg-white/[0.03] sm:p-5">
        <span
          aria-hidden="true"
          className="absolute -end-10 -top-12 h-32 w-32 rounded-full"
          style={{ background: "radial-gradient(circle, rgba(109,93,251,0.14), transparent 70%)" }}
        />
        <div className="flex items-start gap-3.5">
          <span
            className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
            style={{ backgroundImage: grad("#6d5dfb", "#4b35c9"), boxShadow: "0 8px 20px -8px #4b35c966" }}
            aria-hidden="true"
          >
            <CatIcon name="building" className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="font-display text-[13.5px] font-extrabold text-slate-900 dark:text-white">
              {t("rbacTierNoteTitle")}
            </p>
            <p className="mt-1 text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
              {t("rbacTierNoteBody")}
            </p>
            <div className="mt-2.5 flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-brand-400/60 bg-brand-500/10 px-2.5 py-1 text-[10px] font-extrabold text-brand-600 dark:border-brand-500/40 dark:text-brand-300">
                <CatIcon name="crown" className="h-3 w-3" />
                {t(ROLE_KEY.super)} — {t("rbacSuperAll")}
              </span>
              <span
                title={t("rbacPartialHint")}
                className="inline-flex cursor-help items-center gap-1.5 rounded-full border border-amber-400/60 bg-amber-500/10 px-2.5 py-1 text-[10px] font-extrabold text-amber-600 dark:border-amber-500/40 dark:text-amber-400"
              >
                <CatIcon name="circle-dot" className="h-3 w-3" />
                {t(ROLE_KEY.admin)} — {t("rbacPartial")}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AdminAdmins;
