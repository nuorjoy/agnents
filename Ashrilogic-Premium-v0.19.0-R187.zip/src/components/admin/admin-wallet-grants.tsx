"use client";

/**
 * Ashrilogic — Super Admin wallet grants (منح المحفظة) — ROUND 168.
 *
 * The owner's directive: «add a certain financial amount to ALL subscribers
 * or to the subscribers of a specific package». A premium grant composer:
 *  - TARGET: جميع المشتركين (every live workspace — trial included, the
 *    owner's «جميع المشتركين») or مشتركو باقة محددة (package picker);
 *  - AMOUNT: the MoneyInput primitive (dual-numeral entry, minor-units
 *    output — never a client-trusted pre-computed number on the wire);
 *  - LIVE AUDIENCE: the GET preview endpoint's count rendered while the
 *    operator composes (keyed by target + package);
 *  - CONFIRMATION: a mandatory dialog carrying the EXACT receipt
 *    (X مشتركين × المبلغ = الإجمالي) before a single minor unit moves;
 *  - EXECUTION: one POST — bounded keyset batches of per-recipient CAS
 *    credits server-side; the result panel renders the honest receipt
 *    (credited / audience / skipped + the grant identity every ledger row
 *    carries).
 *
 * Design follows the admin-quotes idiom — pipeline cards, gradient tiles,
 * emerald wallet family — with the money-moving confirmation weight of the
 * subscriber governance levers.
 */
import { useMemo, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { createWalletGrant, fetchPackages, fetchWalletGrantAudience } from "@/lib/api-client";
import { useAdminCanManage } from "@/lib/admin-auth";
import { useT, type I18nKey } from "@/lib/i18n";
import type { WalletGrantAudienceDTO, WalletGrantResultDTO } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { MoneyInput } from "@/components/ui/money-input";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { ViewHeading, DashCard } from "@/components/dashboard/dash-shared";
import { KpiCard } from "@/components/shared/kpi-card";

/** Grant bounds in MINOR units (mirrors the server law: $1 .. $100k). */
const MIN_AMOUNT_MINOR = 100;
const MAX_AMOUNT_MINOR = 10_000_000;

/** The composer's local target state. */
type GrantTarget = "all" | "plan";

/** One selectable target card. */
function TargetCard({
  active,
  icon,
  c1,
  c2,
  title,
  hint,
  onClick,
  disabled,
}: {
  active: boolean;
  icon: string;
  c1: string;
  c2: string;
  title: string;
  hint: string;
  onClick: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-pressed={active}
      className={cn(
        "flex w-full items-start gap-3 rounded-2xl border p-3.5 text-start transition active:scale-[0.98] disabled:opacity-60",
        active
          ? "border-brand-400 bg-brand-500/[0.07] shadow-lg shadow-brand-500/10 dark:border-brand-500/50 dark:bg-brand-500/10"
          : "border-slate-200 bg-white/70 hover:border-slate-300 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-white/20"
      )}
    >
      <span
        className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
        style={{ backgroundImage: grad(c1, c2) }}
        aria-hidden="true"
      >
        <CatIcon name={icon} className="h-4 w-4" />
      </span>
      <span className="min-w-0">
        <span className="flex items-center gap-2 text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
          {title}
          {active ? <CatIcon name="circle-check" className="h-3.5 w-3.5 text-brand-500" /> : null}
        </span>
        <span className="mt-0.5 block text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
          {hint}
        </span>
      </span>
    </button>
  );
}

export function AdminWalletGrants() {
  const { t, lang } = useT();
  const canManage = useAdminCanManage();

  /* ---------------- composer state ---------------- */
  const [target, setTarget] = useState<GrantTarget>("all");
  const [packageId, setPackageId] = useState("");
  const [amountDisplay, setAmountDisplay] = useState("");
  const [amountMinor, setAmountMinor] = useState(0);
  const [note, setNote] = useState("");
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [result, setResult] = useState<WalletGrantResultDTO | null>(null);

  /* ---------------- the packages picker list ---------------- */
  const packagesQuery = useQuery({
    queryKey: ["packages"],
    queryFn: fetchPackages,
    staleTime: 60_000,
    enabled: target === "plan",
  });
  const packages = useMemo(() => packagesQuery.data ?? [], [packagesQuery.data]);

  /* ---------------- the LIVE audience preview ---------------- */
  const audienceKey = target === "plan" ? `plan:${packageId}` : "all";
  const audienceQuery = useQuery({
    queryKey: ["wallet-grant-audience", audienceKey],
    queryFn: () =>
      fetchWalletGrantAudience({
        target,
        ...(target === "plan" && packageId ? { packageId } : {}),
      }),
    enabled: target === "all" || packageId !== "",
    staleTime: 15_000,
  });
  const audience: WalletGrantAudienceDTO | null = audienceQuery.data ?? null;
  const audienceCount = audience?.count ?? null;

  /* ---------------- the grant execution ---------------- */
  const grant = useMutation({
    mutationFn: () =>
      createWalletGrant({
        target,
        ...(target === "plan" && packageId ? { packageId } : {}),
        amountMinor,
        ...(note.trim() ? { note: note.trim().slice(0, 200) } : {}),
      }),
    onSuccess: (data) => {
      setResult(data);
      setConfirmOpen(false);
      toast.success(
        t("grantResultDesc", {
          credited: fmtNum(data.credited, lang),
          audience: fmtNum(data.audience, lang),
          amount: fmtNum(data.amountMinor / 100, lang),
        })
      );
      void audienceQuery.refetch();
    },
    onError: (error: Error) =>
      toast.error(error.message ? `${t("grantErr")} — ${error.message}` : t("grantErr")),
  });

  /* ---------------- compose validity ---------------- */
  const targetOk = target === "all" || packageId !== "";
  const amountOk = amountMinor >= MIN_AMOUNT_MINOR && amountMinor <= MAX_AMOUNT_MINOR;
  const canCompose = canManage && targetOk && amountOk && audienceCount !== null;

  const submit = () => {
    if (!canCompose || grant.isPending) return;
    if ((audienceCount ?? 0) === 0) {
      toast.error(t("grantEmptyTitle"), { description: t("grantEmptyDesc") });
      return;
    }
    setConfirmOpen(true);
  };

  const execute = () => {
    if (grant.isPending) return;
    grant.mutate();
  };

  const closeResult = () => {
    setResult(null);
    /* the composer resets for a fresh run — the previous run's receipt
     * stays in the audit trail + the ledger (reference grant:<id>). */
    setAmountDisplay("");
    setAmountMinor(0);
    setNote("");
  };

  const selectedPackage = packages.find((p) => p.id === packageId) ?? null;
  const receiptTotal = (audienceCount ?? 0) * amountMinor;

  return (
    <div className="space-y-5">
      <ViewHeading title={t("grantTitle")} desc={t("grantDesc")} />

      {/* the result receipt — shown once a run completes */}
      {result ? (
        <DashCard>
          <div className="flex flex-wrap items-center gap-3">
            <span
              className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
              style={{ backgroundImage: grad("#059669", "#10b981"), boxShadow: "0 10px 24px -10px rgba(5,150,105,0.7)" }}
              aria-hidden="true"
            >
              <CatIcon name="party-popper" className="h-5 w-5" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                {t("grantResultTitle")}
              </p>
              <p className="mt-0.5 text-[12px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                {t("grantResultDesc", {
                  credited: fmtNum(result.credited, lang),
                  audience: fmtNum(result.audience, lang),
                  amount: fmtNum(result.amountMinor / 100, lang),
                })}
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {result.skipped > 0 ? (
                <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/10 px-2.5 py-1 text-[10.5px] font-extrabold text-amber-600 dark:text-amber-300">
                  <CatIcon name="triangle-alert" className="h-3 w-3" />
                  {t("grantSkippedChip", { n: fmtNum(result.skipped, lang) })}
                </span>
              ) : null}
              <code
                dir="ltr"
                className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-2.5 py-1 font-mono text-[10.5px] font-bold text-slate-500 dark:bg-white/10 dark:text-slate-400"
              >
                <CatIcon name="hash" className="h-3 w-3" />
                {t("grantGrantId")}: {result.grantId}
              </code>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={closeResult}
                className="h-8 gap-1.5 rounded-lg px-3 text-[11px] font-bold"
              >
                <CatIcon name="plus" className="h-3.5 w-3.5" />
                {t("grantRunCta")}
              </Button>
            </div>
          </div>
        </DashCard>
      ) : null}

      <div className="grid gap-5 lg:grid-cols-3">
        {/* ---------------- the composer ---------------- */}
        <DashCard title={t("grantTitle")} icon="gift" className="lg:col-span-2">
          <div className="space-y-4">
            {/* target selector */}
            <div>
              <Label className="text-[12px] font-extrabold leading-tight text-slate-700 dark:text-slate-200">
                {t("grantTargetLabel")}
              </Label>
              <div className="mt-2 grid gap-2.5 sm:grid-cols-2">
                <TargetCard
                  active={target === "all"}
                  icon="users"
                  c1="#6d5dfb"
                  c2="#06b6d4"
                  title={t("grantTargetAll")}
                  hint={t("grantTargetAllHint")}
                  onClick={() => setTarget("all")}
                  disabled={!canManage}
                />
                <TargetCard
                  active={target === "plan"}
                  icon="package"
                  c1="#f59e0b"
                  c2="#d97706"
                  title={t("grantTargetPlan")}
                  hint={selectedPackage
                    ? `${selectedPackage.nameAr} · ${selectedPackage.nameEn}`
                    : t("grantPackagePh")}
                  onClick={() => setTarget("plan")}
                  disabled={!canManage}
                />
              </div>
            </div>

            {/* package picker (target = plan) */}
            {target === "plan" ? (
              <div className="space-y-1.5">
                <Label htmlFor="grant-package" className="text-[12px] font-extrabold leading-tight text-slate-700 dark:text-slate-200">
                  {t("grantPackageLabel")}
                </Label>
                {packagesQuery.isPending ? (
                  <Skeleton className="h-11 w-full rounded-xl" />
                ) : (
                  <Select
                    value={packageId}
                    onValueChange={(v) => setPackageId(v)}
                    dir={lang === "ar" ? "rtl" : "ltr"}
                    disabled={!canManage}
                  >
                    <SelectTrigger id="grant-package" className="h-11 w-full rounded-xl">
                      <SelectValue placeholder={t("grantPackagePh")} />
                    </SelectTrigger>
                    <SelectContent className="rounded-xl">
                      <SelectGroup>
                        {packages.map((pkg) => (
                          <SelectItem key={pkg.id} value={pkg.id} className="text-[12.5px] font-bold">
                            <span className="flex min-w-0 items-center gap-2">
                              <span className="truncate">
                                {lang === "ar" ? pkg.nameAr : pkg.nameEn}
                              </span>
                              <span dir="ltr" className="ms-auto shrink-0 text-[10px] font-extrabold text-slate-400">
                                {fmtNum(pkg.priceMonthly / 100, lang)} {pkg.currency}
                              </span>
                            </span>
                          </SelectItem>
                        ))}
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                )}
              </div>
            ) : null}

            {/* amount + note */}
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="grant-amount" className="text-[12px] font-extrabold leading-tight text-slate-700 dark:text-slate-200">
                  {t("grantAmountLabel")}
                </Label>
                <MoneyInput
                  id="grant-amount"
                  value={amountDisplay}
                  onChange={setAmountDisplay}
                  onValueMinor={setAmountMinor}
                  currency="SAR"
                  minMajor={1}
                  maxMajor={100_000}
                  disabled={!canManage}
                  invalid={amountMinor > 0 && !amountOk}
                  ariaLabel={t("grantAmountLabel")}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="grant-note" className="text-[12px] font-extrabold leading-tight text-slate-700 dark:text-slate-200">
                  {t("grantNoteLabel")}
                </Label>
                <div className="relative">
                  <CatIcon
                    name="notebook-pen"
                    className="pointer-events-none absolute start-3.5 top-1/2 h-[14px] w-[14px] -translate-y-1/2 text-slate-400"
                  />
                  <Input
                    id="grant-note"
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    placeholder={t("grantNotePh")}
                    maxLength={200}
                    disabled={!canManage}
                    dir="auto"
                    className="h-11 rounded-xl border-slate-200 bg-slate-50/80 ps-10 text-[13px] font-semibold text-slate-800 shadow-none outline-none transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 disabled:opacity-60 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100"
                  />
                </div>
              </div>
            </div>

            {/* the run CTA */}
            <Button
              type="button"
              onClick={submit}
              disabled={!canCompose || grant.isPending}
              className="h-12 w-full gap-2 rounded-2xl bg-linear-to-l from-emerald-600 to-teal-500 text-[13px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:brightness-110 active:scale-[0.98] disabled:opacity-50"
            >
              <CatIcon name={grant.isPending ? "refresh-cw" : "gift"} className={cn("h-4 w-4", grant.isPending && "animate-spin")} />
              {grant.isPending ? t("grantProgress") : t("grantRunCta")}
            </Button>
          </div>
        </DashCard>

        {/* ---------------- the live audience ---------------- */}
        <div className="space-y-5">
          <KpiCard
            label={t("grantAudienceLabel")}
            numeric={audienceCount ?? 0}
            icon="users"
            c1="#059669"
            c2="#0f766e"
            index={0}
          />
          <DashCard>
            <p className="text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
              {audienceQuery.isError
                ? t("grantAudienceErr")
                : audience?.target === "plan" && audience.packageName
                  ? `${audience.packageName}`
                  : t("grantAudienceHint")}
            </p>
            {/* the exact receipt preview — the same figures the confirmation
                dialog carries (X × amount = total) */}
            <div className="mt-3 space-y-1.5 border-t border-dashed border-slate-200 pt-3 text-[11.5px] dark:border-white/10">
              <div className="flex items-center justify-between gap-2">
                <span className="font-semibold text-slate-400 dark:text-slate-500">{t("grantAudienceLabel")}</span>
                <span dir="ltr" className="font-extrabold tabular-nums text-slate-700 dark:text-slate-200">
                  {audienceQuery.isPending ? "…" : fmtNum(audienceCount ?? 0, lang)}
                </span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="font-semibold text-slate-400 dark:text-slate-500">{t("grantAmountLabel")}</span>
                <span dir="ltr" className="font-extrabold tabular-nums text-slate-700 dark:text-slate-200">
                  {fmtNum(amountMinor / 100, lang)} SAR
                </span>
              </div>
              <div className="flex items-center justify-between gap-2 border-t border-dashed border-slate-200 pt-1.5 dark:border-white/10">
                <span className="font-extrabold text-slate-600 dark:text-slate-300">=</span>
                <span dir="ltr" className="font-extrabold tabular-nums text-emerald-600 dark:text-emerald-300">
                  {fmtNum(receiptTotal / 100, lang)} SAR
                </span>
              </div>
            </div>
          </DashCard>
        </div>
      </div>

      {/* ---------------- the money-moving confirmation ---------------- */}
      <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <AlertDialogContent dir="auto" className="sm:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-[15px] font-extrabold">
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg shadow-emerald-500/25"
                style={{ backgroundImage: grad("#059669", "#10b981") }}
                aria-hidden="true"
              >
                <CatIcon name="gift" className="h-4 w-4" />
              </span>
              {t("grantConfirmTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="leading-relaxed">
              {t("grantConfirmDesc")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="rounded-2xl border border-emerald-200/70 bg-emerald-50/60 p-3.5 dark:border-emerald-500/25 dark:bg-emerald-500/10">
            <p dir="auto" className="text-center font-display text-[14px] font-extrabold leading-relaxed text-emerald-800 dark:text-emerald-200">
              {t("grantReceipt", {
                n: fmtNum(audienceCount ?? 0, lang),
                amount: `${fmtNum(amountMinor / 100, lang)} SAR`,
                total: `${fmtNum(receiptTotal / 100, lang)} SAR`,
              })}
            </p>
            {target === "plan" && selectedPackage ? (
              <p dir="auto" className="mt-1 text-center text-[11px] font-bold text-emerald-600/80 dark:text-emerald-300/80">
                {selectedPackage.nameAr} · {selectedPackage.nameEn}
              </p>
            ) : null}
            {note.trim() ? (
              <p dir="auto" className="mt-1.5 text-center text-[11px] font-semibold text-emerald-700/70 dark:text-emerald-300/70">
                «{note.trim().slice(0, 200)}»
              </p>
            ) : null}
          </div>
          <AlertDialogFooter className="gap-2">
            <AlertDialogCancel className="h-10 rounded-xl px-4 text-[12.5px] font-bold">
              {t("quotesCancelNotes")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                /* keep the dialog open while the run executes — the mutation's
                 * success/error closes or toasts it. */
                e.preventDefault();
                execute();
              }}
              disabled={grant.isPending}
              className="h-10 gap-2 rounded-xl bg-linear-to-l from-emerald-600 to-teal-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-emerald-500/25"
            >
              <CatIcon name={grant.isPending ? "refresh-cw" : "check"} className={cn("h-4 w-4", grant.isPending && "animate-spin")} />
              {grant.isPending ? t("grantProgress") : t("grantConfirmCta")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default AdminWalletGrants;
