"use client";

/**
 * Ashrilogic — admin login card.
 *
 * Server-verified credentials: the form POSTs to /api/admin/login which
 * checks the AdminUser table (Argon2id records) and drops an HTTP-only
 * session cookie. Administrator accounts are provisioned via the secure
 * bootstrap flow (bootstrap-admin CLI / seeded super-admin) — no demo
 * credentials are surfaced in the UI. The server's error message
 * (invalid credentials / disabled account) is surfaced inline.
 *
 * ROUND 45 — TWO-STEP sign-in: when the account has two-factor enrolled,
 * the password step returns a short-lived challenge ticket instead of a
 * session. Step 2 accepts a 6-digit TOTP code / backup code, or completes
 * with a registered passkey (browser ceremony). A "use passkey instead"
 * shortcut also allows passkey-FIRST sign-in (discoverable, no password).
 *
 * Visual language: glass card centered on the mesh background, gradient
 * brand badge, shake-on-error animation via framer-motion.
 *
 * ROUND 83 — (a) the identifier field accepts the USERNAME **OR EMAIL** and
 * is fully Arabic-first: RTL field direction with Arabic placeholders,
 * field labels without `tracking-wider` (letter-spacing fractures Arabic
 * cursive joining — a typographic error), and a discoverability hint under
 * the field; (b) the footer carries the professional platform credit
 * «AshriLogic — Developed by Noureldin Osman» (precisely translated).
 *
 * ROUND 134-B — premium visual pass (owner directive: «في واجهة تسجيل دخول
 * الـ Super Admin أضف القليل من التأثيرات الجذابة وتكون Premium»): aurora
 * orbs (emerald → teal → violet, no indigo/blue) + blueprint grid + top
 * spotlight behind the card, medallion sheen sweep, breathing emerald halo,
 * emerald input focus rings, and hover-lift submit buttons with a one-time
 * shine sweep. The LOGIN LOGIC (passkey / MFA / shake-on-error / spinners)
 * is untouched — this is visual polish only; every animation carries its
 * own prefers-reduced-motion guard (the globals.css convention).
 */
import { useEffect, useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { toast } from "sonner";
import { useT } from "@/lib/i18n";
import { useDocumentTitle } from "@/hooks/use-document-title";
import type { AdminUserDTO } from "@/lib/types";
import { ApiError } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { LangMenu } from "@/components/lang-menu";
import { PasskeyLoginBlock } from "@/components/auth/passkey-login-block";
import { CrossDevicePasskeyDialog } from "@/components/auth/cross-device-passkey-dialog";
import { CrossDeviceCompleteCard } from "@/components/auth/cross-device-complete-card";
import { grad, cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { OtpInput, normalizeDigits } from "@/components/security/security-cards";

import "@/lib/i18n/fragments/app";
/* ROUND 83 — Arabic typography law: `uppercase` is a no-op for Arabic, but
 * `tracking-wider` (letter-spacing) FRACTURES the cursive joining of the
 * script. Latin labels keep the spaced small-caps look; Arabic labels use
 * zero letter-spacing — the professional convention. */
const FIELD_LABEL_BASE = "text-[11px] font-extrabold text-slate-500 dark:text-slate-400";
const FIELD_LABEL_LATIN = `${FIELD_LABEL_BASE} uppercase tracking-wider`;
const FIELD_LABEL_AR = FIELD_LABEL_BASE;
/* ROUND 134-B — emerald focus glow: border + 4px ring + halo shadow, with
 * smooth border-color/box-shadow transitions in both themes. The focus
 * styles use the `focus-visible:` variant (the shadcn Input base idiom) so
 * tailwind-merge cleanly supersedes the base `focus-visible:border-ring
 * focus-visible:ring-ring/50 focus-visible:ring-[3px]` (violet) — text
 * inputs match :focus-visible whenever focused, mouse or keyboard. */
const FIELD_INPUT =
  "h-11 rounded-xl border-slate-200 bg-slate-50/80 px-3.5 text-[13px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus-visible:border-emerald-400 focus-visible:bg-white focus-visible:shadow-lg focus-visible:shadow-emerald-500/25 focus-visible:ring-4 focus-visible:ring-emerald-500/20 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:focus-visible:border-emerald-400/70 dark:focus-visible:bg-white/[0.07] dark:focus-visible:shadow-emerald-400/15 dark:focus-visible:ring-emerald-400/15";

/* ROUND 134-B — Super Admin login premium FX. The keyframes live inline in
 * a <style> tag scoped by the unique `alp-` prefix (globals.css is outside
 * this round's file ownership) and mirror the codebase convention: every
 * animated class gets its own prefers-reduced-motion guard, with the global
 * `*` kill-switch in globals.css as the final backstop. All loops animate
 * transform/opacity only (compositor-friendly); the blurs are static. */
const LOGIN_FX_CSS = `
  /* micro-detail — faint blueprint grid, radially masked so it fades out */
  .alp-grid {
    position: absolute;
    inset: 0;
    background-image: linear-gradient(to right, rgba(100, 116, 139, 0.09) 1px, transparent 1px),
      linear-gradient(to bottom, rgba(100, 116, 139, 0.09) 1px, transparent 1px);
    background-size: 44px 44px;
    -webkit-mask-image: radial-gradient(75% 62% at 50% 42%, #000 22%, transparent 72%);
    mask-image: radial-gradient(75% 62% at 50% 42%, #000 22%, transparent 72%);
  }
  .dark .alp-grid {
    background-image: linear-gradient(to right, rgba(148, 163, 184, 0.07) 1px, transparent 1px),
      linear-gradient(to bottom, rgba(148, 163, 184, 0.07) 1px, transparent 1px);
  }

  /* micro-detail — faint radial spotlight (أشعة) falling from the top */
  .alp-spotlight {
    position: absolute;
    inset: 0;
    background: radial-gradient(72% 46% at 50% -8%, rgba(16, 185, 129, 0.13), transparent 70%);
  }
  .dark .alp-spotlight {
    background: radial-gradient(72% 46% at 50% -8%, rgba(16, 185, 129, 0.2), transparent 70%),
      radial-gradient(46% 30% at 82% 10%, rgba(139, 92, 246, 0.12), transparent 72%);
  }

  /* aurora orbs — emerald → teal → violet (no indigo/blue), slow drift */
  .alp-orb {
    position: absolute;
    border-radius: 9999px;
    filter: blur(80px);
  }
  .alp-orb-a {
    top: -14%;
    left: -12%;
    width: 28rem;
    height: 28rem;
    background: radial-gradient(closest-side, rgba(16, 185, 129, 0.2), transparent 70%);
    animation: alp-drift-a 26s ease-in-out infinite alternate;
  }
  .alp-orb-b {
    top: 24%;
    right: -14%;
    width: 24rem;
    height: 24rem;
    background: radial-gradient(closest-side, rgba(20, 184, 166, 0.17), transparent 70%);
    animation: alp-drift-b 32s ease-in-out infinite alternate;
  }
  .alp-orb-c {
    bottom: -20%;
    left: 20%;
    width: 32rem;
    height: 32rem;
    background: radial-gradient(closest-side, rgba(139, 92, 246, 0.15), transparent 70%);
    animation: alp-drift-c 38s ease-in-out infinite alternate;
  }
  .dark .alp-orb-a { background: radial-gradient(closest-side, rgba(16, 185, 129, 0.3), transparent 70%); }
  .dark .alp-orb-b { background: radial-gradient(closest-side, rgba(20, 184, 166, 0.27), transparent 70%); }
  .dark .alp-orb-c { background: radial-gradient(closest-side, rgba(139, 92, 246, 0.24), transparent 70%); }
  @keyframes alp-drift-a {
    from { transform: translate3d(0, 0, 0) scale(1); }
    to { transform: translate3d(9rem, 5.5rem, 0) scale(1.18); }
  }
  @keyframes alp-drift-b {
    from { transform: translate3d(0, 0, 0) scale(1.08); }
    to { transform: translate3d(-10rem, 6rem, 0) scale(0.94); }
  }
  @keyframes alp-drift-c {
    from { transform: translate3d(0, 0, 0) scale(0.96); }
    to { transform: translate3d(7rem, -6rem, 0) scale(1.14); }
  }

  /* brand medallion — slow diagonal sheen sweep (dwell + glide, ~6s) */
  .alp-sheen {
    position: absolute;
    inset: -35% -70%;
    background: linear-gradient(105deg, transparent 43%, rgba(255, 255, 255, 0.55) 50%, transparent 57%);
    transform: translateX(-75%);
    animation: alp-sheen 6s cubic-bezier(0.5, 0, 0.2, 1) infinite;
  }
  @keyframes alp-sheen {
    0%, 55% { transform: translateX(-75%); }
    100% { transform: translateX(75%); }
  }

  /* breathing emerald halo behind the glass card */
  .alp-glow {
    position: absolute;
    inset: -1.25rem;
    border-radius: 2rem;
    background: linear-gradient(160deg, rgba(16, 185, 129, 0.22), rgba(20, 184, 166, 0.1) 45%, rgba(139, 92, 246, 0.16));
    filter: blur(26px);
    animation: alp-breathe 7s ease-in-out infinite;
  }
  .dark .alp-glow {
    background: linear-gradient(160deg, rgba(16, 185, 129, 0.38), rgba(20, 184, 166, 0.16) 45%, rgba(139, 92, 246, 0.3));
  }
  @keyframes alp-breathe {
    0%, 100% { opacity: 0.45; }
    50% { opacity: 0.9; }
  }

  /* per-animation reduced-motion guards (the globals.css pattern) */
  @media (prefers-reduced-motion: reduce) {
    .alp-orb,
    .alp-sheen,
    .alp-glow { animation: none; }
    .alp-sheen { opacity: 0; }
    .alp-glow { opacity: 0.6; }
  }
`;

export interface AdminLoginAuth {
  /** password step — resolves with the user OR the MFA challenge payload */
  login: (username: string, password: string) => Promise<AdminUserDTO | { mfaRequired: true; ticket: string; passkeys: boolean }>;
  /** step 2 — TOTP / backup code completion */
  loginMfa: (ticket: string, code: string) => Promise<AdminUserDTO>;
  /** step 2 — passkey completion (ticket optional → passkey-first login) */
  loginPasskey: (ticket?: string) => Promise<AdminUserDTO>;
  /** ROUND 117 — publish a session the cross-device bridge claimed */
  applyUser: (dto: AdminUserDTO) => Promise<AdminUserDTO>;
}

export function AdminLogin({ auth }: { auth: AdminLoginAuth }) {
  const { t, lang } = useT();
  useDocumentTitle("docTitleLogin");
  const fieldLabel = lang === "ar" ? FIELD_LABEL_AR : FIELD_LABEL_LATIN;
  const fieldDir = lang === "ar" ? "rtl" : "ltr";
  /* R134-B — respect prefers-reduced-motion for the mount transition. The
   * error shake stays even when reduced: it is functional feedback (an
   * error occurred), not decoration — the WCAG "essential motion" case. */
  const reducedMotion = useReducedMotion();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [pending, setPending] = useState(false);
  const [errored, setErrored] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);

  /* ROUND 45 — second-factor step state */
  const [challenge, setChallenge] = useState<{ ticket: string; passkeys: boolean } | null>(null);
  const [mfaCode, setMfaCode] = useState("");
  const [mfaPending, setMfaPending] = useState(false);
  const [passkeyPending, setPasskeyPending] = useState(false);

  /* ROUND 117 — the cross-device passkey dialog (desktop side) + the phone
   * completion card (the QR opens /admin/login?cd=<token>). */
  const [crossOpen, setCrossOpen] = useState(false);
  const [phoneCd, setPhoneCd] = useState<string | null>(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const cd = params.get("cd");
    /* eslint-disable-next-line react-hooks/set-state-in-effect --
       ROUND 117: one-shot URL truth at mount — the QR hands ?cd=<token>
       to this page. The state flips ONCE (null → token) and never again,
       so the cascading-render hazard this rule guards against cannot
       occur; deriving in render instead would mismatch SSR hydration. */
    if (cd && /^[A-Za-z0-9_-]{43}$/.test(cd)) setPhoneCd(cd);
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (pending) return;
    setPending(true);
    setErrored(false);
    setServerError(null);
    try {
      const result = await auth.login(username, password);
      if ("mfaRequired" in result) {
        /* password OK — the second factor is required before any session */
        setChallenge({ ticket: result.ticket, passkeys: result.passkeys });
        setMfaCode("");
        setPending(false);
        return;
      }
      toast.success(t("adminLoginWelcome", { name: result.name }));
      // authed state flips via the useAdminAuth subscription; AdminApp re-renders
    } catch (error) {
      setErrored(true);
      const message =
        error instanceof ApiError && error.status !== 500
          ? error.message
          : t("adminLoginErr");
      setServerError(message);
      toast.error(message);
      setPending(false);
    }
  };

  /* TOTP / backup code completion. ROUND 46 — the 6-digit code goes through
     the boxed OTP input (paste + international digit normalization + auto
     submit); a toggle switches to a free-text backup-code field. */
  const [backupMode, setBackupMode] = useState(false);
  const codeValid = backupMode
    ? mfaCode.trim().length >= 4
    : normalizeDigits(mfaCode).replace(/\D/g, "").length === 6;

  const runMfa = async (code: string) => {
    if (!challenge || mfaPending) return;
    setMfaPending(true);
    setServerError(null);
    try {
      const user = await auth.loginMfa(challenge.ticket, code.trim());
      toast.success(t("adminLoginWelcome", { name: user.name }));
    } catch (error) {
      setErrored(true);
      setServerError(error instanceof Error ? error.message : t("adminLoginErr"));
      toast.error(error instanceof Error ? error.message : t("adminLoginErr"));
      setMfaPending(false);
    }
  };

  const submitMfa = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!codeValid) return;
    await runMfa(mfaCode);
  };

  /* passkey-first (usernameless) premium entry — ROUND 117: clicking the
     passkey button opens the CROSS-DEVICE dialog (native ceremony + QR for
     the phone/tablet that holds the key). */
  const startPasskeyFirst = () => {
    if (passkeyPending) return;
    setCrossOpen(true);
  };

  /* the native ceremony runner handed to the dialog (the same-device path) */
  const runNativePasskey = () => {
    if (passkeyPending) return;
    setPasskeyPending(true);
    setServerError(null);
    auth
      .loginPasskey()
      .then((user) => toast.success(t("adminLoginWelcome", { name: user.name })))
      .catch((error: unknown) => {
        if (error instanceof Error && error.name === "NotAllowedError") {
          /* inside an embedded preview iframe the browser blocks the
             ceremony — guide the user to a standalone window */
          const embedded =
            typeof window !== "undefined" &&
            window.self !== window.top;
          toast.info(embedded ? t("secPasskeyIframeHint") : t("secPasskeyCancelled"));
        } else if (error instanceof Error && error.message) {
          toast.error(error.message);
        }
        setPasskeyPending(false);
      });
  };

  /* passkey completion of the MFA challenge (ticket-pinned ceremony) */
  const completeWithPasskey = async () => {
    if (!challenge || passkeyPending) return;
    setPasskeyPending(true);
    setServerError(null);
    try {
      const user = await auth.loginPasskey(challenge.ticket);
      toast.success(t("adminLoginWelcome", { name: user.name }));
    } catch (error) {
      const message = error instanceof Error ? error.message : t("adminLoginErr");
      if (error instanceof Error && error.name === "NotAllowedError") {
        const embedded =
          typeof window !== "undefined" &&
          window.self !== window.top;
        toast.info(embedded ? t("secPasskeyIframeHint") : t("secPasskeyCancelled"));
      } else {
        setServerError(message);
        toast.error(message);
      }
      setPasskeyPending(false);
    }
  };

  const stepPending = mfaPending || passkeyPending;

  /* ROUND 117 — the QR opened THIS page on the phone: render the
   * completion card instead of the login form. */
  if (phoneCd) return <CrossDeviceCompleteCard token={phoneCd} />;

  return (
    /* flex (not grid place-items-center): a `w-full max-w-md` child inside
     * an auto-sized grid track resolves its percentage against the track's
     * content-based sizing — input intrinsic widths (size attr × font) then
     * inflate the track past the viewport on narrow screens (mobile overflow).
     * Flex gives the child a definite containing block: 100% = container
     * content box, deterministic at every width.
     * R134-B — `overflow-x-clip` keeps the card's -inset halo (and the
     * error-shake) from opening a 4px horizontal scrollbar on narrow
     * viewports; clip (not hidden) creates no scroll container, and the
     * fixed mesh/aurora stage is unaffected (the root is no containing
     * block for fixed descendants). */
    <div className="relative flex min-h-screen items-center justify-center overflow-x-clip px-4 py-12">
      {/* R134-B — the scoped premium-FX stylesheet (idempotent, tiny) */}
      <style>{LOGIN_FX_CSS}</style>

      {/* decorative mesh background */}
      <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden />

      {/* R134-B — premium stage: blueprint grid + top spotlight + three
          slow-drifting aurora orbs (emerald → teal → violet) behind the
          card. Painted after the mesh (same -z-10, later in DOM order). */}
      <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden" aria-hidden>
        <div className="alp-grid absolute inset-0" />
        <div className="alp-spotlight absolute inset-0" />
        <span className="alp-orb alp-orb-a" />
        <span className="alp-orb alp-orb-b" />
        <span className="alp-orb alp-orb-c" />
      </div>

      <motion.div
        initial={reducedMotion ? false : { opacity: 0, y: 28, scale: 0.95 }}
        animate={
          errored
            ? { opacity: 1, y: 0, scale: 1, x: [0, -10, 10, -7, 7, 0] }
            : { opacity: 1, y: 0, scale: 1, x: 0 }
        }
        transition={
          errored
            ? { duration: 0.45, ease: "easeInOut" }
            : { duration: 0.65, ease: [0.22, 1, 0.36, 1] }
        }
        className="relative w-full max-w-md"
      >
        {/* R134-B — breathing emerald halo behind the glass card. Placed as
            the first child of the (relative) motion.div: it rides the card
            through the mount transition AND the error shake — a child of
            the animated element, so it moves as one composition. */}
        <div className="alp-glow" aria-hidden="true" />

        <div className="glass-card card-in relative rounded-3xl p-6 sm:p-8">
          {/* R134-B — emerald light catching the top edge of the glass */}
          <span
            className="pointer-events-none absolute inset-x-10 top-0 h-px bg-linear-to-r from-transparent via-emerald-400/70 to-transparent dark:via-emerald-400/40"
            aria-hidden="true"
          />
          {/* top controls: language toggle */}
          <div className="absolute end-4 top-4 flex items-center gap-1.5">
            <LangMenu className="h-9" />
          </div>

          {/* brand badge */}
          <div className="flex flex-col items-center text-center">
            <span
              className="relative grid h-16 w-16 place-items-center overflow-hidden rounded-2xl text-white shadow-lg shadow-brand-500/30"
              style={{
                backgroundImage: challenge
                  ? grad("#10b981", "#059669")
                  : grad("#6d5dfb", "#06b6e9"),
              }}
              aria-hidden="true"
            >
              <CatIcon name={challenge ? "shield-check" : "boxes"} className="h-7 w-7" />
              {/* R134-B — slow diagonal sheen sweep across the medallion */}
              <span className="alp-sheen" aria-hidden="true" />
            </span>
            <h1 className="mt-5 font-display text-2xl font-extrabold text-slate-900 dark:text-white">
              {challenge ? t("mfaLoginTitle") : t("adminLoginTitle")}
            </h1>
            <p className="mt-1.5 max-w-xs text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {challenge ? t("mfaLoginDesc") : t("adminLoginDesc")}
            </p>
          </div>

          {challenge ? (
            /* ------------------------- STEP 2 — 2FA ------------------------- */
            <form onSubmit={submitMfa} className="mt-7 space-y-4" autoComplete="off">
              <div>
                {backupMode ? (
                  <>
                    <Label htmlFor="admin-mfa-backup" className={fieldLabel}>
                      {t("mfaLoginCodeLabel")}
                    </Label>
                    <div className="relative mt-1.5">
                      <CatIcon
                        name="key-round"
                        className="pointer-events-none absolute start-3.5 top-1/2 h-[14px] w-[14px] -translate-y-1/2 text-slate-400"
                      />
                      <Input
                        id="admin-mfa-backup"
                        dir="ltr"
                        value={mfaCode}
                        onChange={(e) => setMfaCode(normalizeDigits(e.target.value.trim()).slice(0, 12))}
                        placeholder="XXXX-XXXX"
                        className={`${FIELD_INPUT} ps-10 text-center font-black tracking-[0.2em]`}
                      />
                    </div>
                  </>
                ) : (
                  <>
                    <Label htmlFor="admin-otp-0" className={cn(fieldLabel, "flex items-center justify-center gap-1.5")}>
                      <CatIcon name="shield-check" className="h-3.5 w-3.5 text-emerald-500" />
                      {t("mfaLoginCodeLabel")}
                    </Label>
                    <div className="mt-2">
                      <OtpInput
                        idPrefix="admin-otp"
                        value={mfaCode}
                        onChange={setMfaCode}
                        disabled={mfaPending}
                        autoFocus
                        onComplete={(code) => void runMfa(code)}
                        onEnter={(code) => void runMfa(code)}
                      />
                    </div>
                  </>
                )}
                <button
                  type="button"
                  onClick={() => {
                    setBackupMode((v) => !v);
                    setMfaCode("");
                    setServerError(null);
                  }}
                  className="mx-auto mt-2.5 flex items-center gap-1.5 text-[10.5px] font-bold text-slate-400 transition hover:text-brand-600 dark:hover:text-brand-300"
                >
                  <CatIcon name={backupMode ? "hash" : "key-round"} className="h-3 w-3" />
                  {t(backupMode ? "mfaLoginUseCode" : "mfaLoginBackupHint")}
                </button>
              </div>

              {serverError ? (
                <motion.p
                  initial={{ opacity: 0, y: -6 }}
                  animate={{ opacity: 1, y: 0 }}
                  role="alert"
                  dir={lang === "ar" ? "rtl" : "ltr"}
                  className="flex items-center gap-2 rounded-xl border border-rose-200 bg-rose-50/90 px-3.5 py-2.5 text-[12px] font-bold text-rose-600 dark:border-rose-500/25 dark:bg-rose-500/10 dark:text-rose-300"
                >
                  <CatIcon name="circle-alert" className="h-4 w-4 shrink-0" />
                  <span className="min-w-0 flex-1">{serverError}</span>
                </motion.p>
              ) : null}

              <Button
                type="submit"
                disabled={stepPending || !codeValid}
                className="shine-sweep relative h-11 w-full overflow-hidden rounded-xl bg-linear-to-l from-emerald-600 via-emerald-500 to-cyan-400 px-5 text-[13px] font-extrabold text-white shadow-lg shadow-emerald-500/30 transition-all hover:-translate-y-0.5 hover:shadow-xl hover:shadow-emerald-500/40 hover:brightness-110 active:translate-y-0 active:scale-95 disabled:opacity-70"
              >
                {mfaPending ? (
                  <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                ) : (
                  <CatIcon name="key-round" className="h-4 w-4" />
                )}
                {t("mfaLoginSubmit")}
              </Button>

              {challenge.passkeys ? (
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => void completeWithPasskey()}
                  disabled={stepPending}
                  className="h-11 w-full gap-2 rounded-xl border-brand-300 text-[12.5px] font-extrabold text-brand-600 transition hover:border-brand-400 hover:bg-brand-50/60 disabled:opacity-60 dark:border-brand-500/40 dark:text-brand-300 dark:hover:bg-brand-500/10"
                >
                  <CatIcon
                    name={passkeyPending ? "refresh-cw" : "fingerprint"}
                    className={passkeyPending ? "h-4 w-4 animate-spin" : "h-4 w-4"}
                  />
                  {t("mfaLoginPasskey")}
                </Button>
              ) : null}

              <button
                type="button"
                onClick={() => {
                  setChallenge(null);
                  setMfaCode("");
                  setServerError(null);
                  setPending(false);
                }}
                className="mx-auto flex items-center gap-1.5 text-[11.5px] font-bold text-slate-400 transition hover:text-slate-600 dark:hover:text-slate-200"
              >
                <CatIcon name="arrow-left" className="h-3.5 w-3.5 rtl:rotate-180" />
                {t("mfaLoginBack")}
              </button>
            </form>
          ) : (
            /* ------------------------ STEP 1 — password ------------------------ */
            <form onSubmit={submit} className="mt-7 space-y-4" autoComplete="off">
              <div>
                <Label htmlFor="admin-user" className={fieldLabel}>
                  {t("adminLoginIdentifier")}
                </Label>
                <div className="relative mt-1.5">
                  <CatIcon
                    name="at-sign"
                    className="pointer-events-none absolute start-3.5 top-1/2 h-[14px] w-[14px] -translate-y-1/2 text-slate-400"
                  />
                  <Input
                    id="admin-user"
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder={t("adminLoginIdentifierPh")}
                    autoComplete="username"
                    dir={fieldDir}
                    className={`${FIELD_INPUT} ps-10 text-start`}
                  />
                </div>
                {/* ROUND 83 — username-or-email discoverability hint */}
                <p className="mt-1.5 flex items-center gap-1.5 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                  <CatIcon name="sparkles" className="h-3 w-3 shrink-0 text-brand-400" />
                  <span>{t("adminLoginIdentifierHint")}</span>
                </p>
              </div>

              <div>
                <Label htmlFor="admin-pass" className={fieldLabel}>
                  {t("adminLoginPass")}
                </Label>
                <div className="relative mt-1.5">
                  <CatIcon
                    name="lock"
                    className="pointer-events-none absolute start-3.5 top-1/2 h-[14px] w-[14px] -translate-y-1/2 text-slate-400"
                  />
                  <Input
                    id="admin-pass"
                    type={showPass ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder={t("adminLoginPass")}
                    autoComplete="current-password"
                    dir={fieldDir}
                    className={`${FIELD_INPUT} ps-10 pe-10 text-start`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPass((v) => !v)}
                    aria-label={t("adminLoginPass")}
                    className="absolute end-2 top-1/2 grid h-7 w-7 -translate-y-1/2 place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-white/10 dark:hover:text-slate-200"
                  >
                    <CatIcon name={showPass ? "eye-off" : "eye"} className="h-[13px] w-[13px]" />
                  </button>
                </div>
              </div>

              {/* server error banner — real API message (invalid credentials / disabled) */}
              {serverError ? (
                <motion.p
                  initial={{ opacity: 0, y: -6 }}
                  animate={{ opacity: 1, y: 0 }}
                  role="alert"
                  dir={lang === "ar" ? "rtl" : "ltr"}
                  className="flex items-center gap-2 rounded-xl border border-rose-200 bg-rose-50/90 px-3.5 py-2.5 text-[12px] font-bold text-rose-600 dark:border-rose-500/25 dark:bg-rose-500/10 dark:text-rose-300"
                >
                  <CatIcon name="circle-alert" className="h-4 w-4 shrink-0" />
                  <span className="min-w-0 flex-1">{serverError}</span>
                </motion.p>
              ) : null}

              <Button
                type="submit"
                disabled={pending}
                className="shine-sweep relative h-11 w-full overflow-hidden rounded-xl bg-linear-to-l from-brand-600 via-fuchsia-500 to-cyan-400 px-5 text-[13px] font-extrabold text-white shadow-lg shadow-brand-500/30 transition-all hover:-translate-y-0.5 hover:shadow-xl hover:shadow-brand-500/40 hover:brightness-110 active:translate-y-0 active:scale-95 disabled:opacity-70"
              >
                {pending ? (
                  <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                ) : (
                  <CatIcon name="key-round" className="h-4 w-4" />
                )}
                {t("adminLoginBtn")}
              </Button>

              {/* ROUND 55→57 — PREMIUM passkey-first block (divider + branded
                  full-width button with an animated fingerprint medallion)
                  shared with the owners login. Passkeys are a first-class
                  sign-in path (usernameless, no password). Round 57 removed
                  the cross-device sign-in QR from the login interfaces by
                  product decision. */}
              <PasskeyLoginBlock
                onTrigger={startPasskeyFirst}
                pending={passkeyPending}
                disabled={pending}
              />
            </form>
          )}

          {/* secured access note (replaces the old back-to-site link) */}
          <div className="mt-5 text-center">
            <p className="inline-flex items-center gap-1.5 text-[11px] font-bold text-slate-400 dark:text-slate-500">
              <CatIcon name="shield-check" className="h-3.5 w-3.5 text-emerald-500" />
              {t("adminLoginSecureNote")}
            </p>
          </div>
        </div>

        {/* ROUND 83 — the professional platform credit (replaces the old
            «لوحة الإدارة Ashrilogic» line) with a precise translation. */}
        <p className="mt-4 flex items-center justify-center gap-1.5 text-center text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
          <span
            className="h-1.5 w-1.5 shrink-0 rounded-full bg-linear-to-l from-brand-500 to-cyan-400"
            aria-hidden="true"
          />
          {t("adminLoginCredit")}
        </p>
      </motion.div>

      {/* ROUND 117 — the cross-device passkey dialog (native path + QR) */}
      <CrossDevicePasskeyDialog
        scope="admin"
        open={crossOpen}
        onClose={() => {
          setCrossOpen(false);
          setPasskeyPending(false);
        }}
        onNative={runNativePasskey}
        nativePending={passkeyPending}
        onClaimed={(claim) => {
          if (claim.admin) {
            void auth.applyUser(claim.admin).then((user) => {
              toast.success(t("adminLoginWelcome", { name: user.name }));
            });
          }
        }}
      />
    </div>
  );
}

export default AdminLogin;
