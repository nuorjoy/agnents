"use client";

/**
 * Ashrilogic — ROUND 81 — subscriber governance UI (Super Admin).
 *
 * The premium face of PATCH /api/admin/subscribers/[id]:
 *
 *  • «تعديل بيانات المشترك» (EditSubscriberDialog) — precise console-side
 *    control of the owner's identity: institution name, phone, admin name,
 *    admin email (re-sealed + re-indexed server-side) and an OPTIONAL
 *    password rotation (Argon2id, epoch bump, every live session revoked)
 *    with a one-click strong generator.
 *
 *  • «حظر مؤقت» / «حظر دائم» (BanSubscriberDialog) — the strict platform
 *    suspension: temporary bans carry an exact self-lift instant (quick
 *    presets + a precise datetime editor + a reason shown to the subscriber
 *    at sign-in refusal); permanent bans demand an explicit acknowledgment
 *    before the confirm unlocks.
 *
 *  • «إلغاء الحظر» (UnbanSubscriberDialog) — one click, everything resumes.
 *
 *  • BanChip — the rose row chip (dائم solid / مؤقت with a live countdown
 *    phrase honoring the Arabic number-agreement law).
 *
 *  • SubscriberBanSection — the ban-state card for the detail sheet.
 *
 * Every mutation writes an audit row server-side (instance.update /
 * instance.password / instance.ban / instance.unban).
 */
import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  adminBanSubscriber,
  adminResetSubscriberPassword,
  adminUnbanSubscriber,
  adminUpdateSubscriberProfile,
} from "@/lib/api-client";
import { apiErrorText } from "@/lib/api-errors";
import { useT, type I18nKey } from "@/lib/i18n";
import { generateSecurePassword } from "@/lib/password";
import { EMAIL_RE, PASSWORD_RE } from "@/lib/validation";
import type { InstanceDTO, Lang } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, labelTrack } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PremiumDateInput } from "@/components/ui/premium-date-input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { fullDate } from "@/components/dashboard/dash-shared";

/* ------------------------------------------------------------------ */
/* duration phrases — the Arabic number-agreement law (ROUND 80 twin)   */
/* ------------------------------------------------------------------ */

/** Days phrase: 1 → واحد · 2 → يومان · 3–10 → أيام · 11+ → يوماً. */
function daysPhrase(
  days: number,
  t: (k: I18nKey, v?: Record<string, string | number>) => string,
  fmt: (n: number) => string = String
): string {
  if (days >= 11) return t("durDaysMany", { days: fmt(days) });
  if (days >= 3) return t("durDaysFew", { days: fmt(days) });
  if (days === 2) return t("durDaysTwo");
  return t("durDaysOne");
}

/** Hours phrase: 1 → ساعة واحدة · 2 → ساعتان · 3–10 → ساعات · 11+ → ساعة. */
function hoursPhrase(
  hours: number,
  t: (k: I18nKey, v?: Record<string, string | number>) => string,
  fmt: (n: number) => string = String
): string {
  if (hours >= 11) return t("durHoursMany", { hours: fmt(hours) });
  if (hours >= 3) return t("durHoursFew", { hours: fmt(hours) });
  if (hours === 2) return t("durHoursTwo");
  return t("durHoursOne");
}

/** Minutes phrase: same law (دقيقة واحدة / دقيقتان / دقائق / دقيقة). */
function minutesPhrase(
  minutes: number,
  t: (k: I18nKey, v?: Record<string, string | number>) => string,
  fmt: (n: number) => string = String
): string {
  if (minutes >= 11) return t("durMinutesMany", { minutes: fmt(minutes) });
  if (minutes >= 3) return t("durMinutesFew", { minutes: fmt(minutes) });
  if (minutes === 2) return t("durMinutesTwo");
  return t("durMinutesOne");
}

/** «بقي …» label for a future instant — the largest sensible unit wins.
 *  `fmt` localizes the figure (Arabic-Indic digits in AR). */
export function timeLeftPhrase(
  targetIso: string,
  t: (k: I18nKey, v?: Record<string, string | number>) => string,
  fmt: (n: number) => string = String
): string {
  const ms = new Date(targetIso).getTime() - Date.now();
  if (ms <= 0) return "";
  const minutes = Math.floor(ms / 60_000);
  if (minutes < 60) return minutesPhrase(Math.max(1, minutes), t, fmt);
  const hours = Math.floor(minutes / 60);
  if (hours < 48) return hoursPhrase(hours, t, fmt);
  const days = Math.floor(hours / 24);
  return daysPhrase(days, t, fmt);
}

/* ------------------------------------------------------------------ */
/* row chip                                                            */
/* ------------------------------------------------------------------ */

/** Rose governance chip for banned rows (live countdown for temporary). */
export function BanChip({ inst }: { inst: InstanceDTO }) {
  const { t, lang } = useT();
  const ban = inst.entitlement?.ban;
  if (!ban?.active) return null;
  const left = ban.until ? timeLeftPhrase(ban.until, t, (n) => fmtNum(n, lang)) : "";
  return (
    <span
      title={ban.reason ?? (ban.kind === "permanent" ? t("subsBanDescPerm") : t("subsBanDescTemp"))}
      className={cn(
        "inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[10px] font-bold",
        ban.kind === "permanent"
          ? "bg-rose-600 text-white"
          : "bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300"
      )}
    >
      <CatIcon name="octagon-x" className="h-[9px] w-[9px] shrink-0" />
      {ban.kind === "permanent" ? t("subsBanChipPerm") : t("subsBanChipTemp")}
      {left ? <span className="tabular-nums opacity-90">· {t("subsBanChipLeft", { time: left })}</span> : null}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* edit subscriber data                                                */
/* ------------------------------------------------------------------ */

const FIELD_BOX =
  "h-11 rounded-xl border bg-slate-50/80 px-3.5 text-[13px] font-semibold transition focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 dark:bg-white/[0.04]";
const FIELD_OK = "border-slate-200 text-slate-800 focus:border-brand-400 focus:bg-white focus:ring-brand-500/15 dark:border-white/10 dark:text-slate-100 dark:focus:bg-white/[0.07]";
const FIELD_BAD = "border-rose-300 bg-rose-50/60 text-rose-700 focus:border-rose-400 focus:ring-rose-500/15 dark:border-rose-500/40 dark:bg-rose-500/10 dark:text-rose-300";

/**
 * ROUND 138 — the password generator moved to the shared CSPRNG module
 * (src/lib/password.ts). The former local recipe drew its first 4 class
 * characters from Math.random in a FIXED order (upper, lower, digit,
 * symbol — never shuffled) and filled the remaining 8 with a modulo-biased
 * `% pool.length`; both this sheet and the registration wizard now mint
 * from the ONE rejection-sampled crypto.getRandomValues generator
 * (≈ 70.5 bits, every class guaranteed, crypto Fisher–Yates shuffle).
 */
function generatePassword(): string {
  return generateSecurePassword();
}

export function EditSubscriberDialog({
  inst,
  open,
  onOpenChange,
}: {
  inst: InstanceDTO | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();

  const [orgName, setOrgName] = useState("");
  const [phone, setPhone] = useState("");
  const [adminName, setAdminName] = useState("");
  const [adminEmail, setAdminEmail] = useState("");
  const [password, setPassword] = useState("");
  const [invalid, setInvalid] = useState<{ orgName?: boolean; phone?: boolean; adminName?: boolean; adminEmail?: boolean; password?: boolean }>({});

  /* re-seed the form every time the dialog opens for a row */
  const seededKey = inst?.id ?? "";
  const [seededFor, setSeededFor] = useState("");
  if (open && inst && seededFor !== seededKey) {
    setSeededFor(seededKey);
    setOrgName(inst.org.name ?? "");
    setPhone(inst.org.phone ?? "");
    setAdminName(inst.admin.name ?? "");
    setAdminEmail(inst.admin.email ?? "");
    setPassword("");
    setInvalid({});
  }
  if (!open && seededFor !== "") {
    setSeededFor("");
  }

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["instances"] });
    /* the detail sheet rides its own query */
    if (inst) queryClient.invalidateQueries({ queryKey: ["instance", inst.id] });
  };

  const save = useMutation({
    mutationFn: async () => {
      if (!inst) throw new Error("no instance");
      /* profile first (identity fields), then the password lever — the API
       * splits them into distinct audited actions */
      await adminUpdateSubscriberProfile(inst.id, {
        orgName: orgName.trim(),
        phone: phone.trim(),
        adminName: adminName.trim(),
        adminEmail: adminEmail.trim(),
      });
      if (password) {
        await adminResetSubscriberPassword(inst.id, password);
      }
    },
    onSuccess: () => {
      toast.success(t("subsEditSaved"));
      invalidate();
      onOpenChange(false);
    },
    onError: (error: Error) => toast.error(apiErrorText(error, t)),
  });

  const submit = () => {
    const orgOk = orgName.trim().length >= 2;
    const phoneOk = phone.trim().length === 0 || /^\+?[0-9\s().-]{6,24}$/.test(phone.trim());
    const nameOk = adminName.trim().length >= 2;
    const emailOk = EMAIL_RE.test(adminEmail.trim());
    const passOk = password.length === 0 || PASSWORD_RE.test(password);
    setInvalid({ orgName: !orgOk, phone: !phoneOk, adminName: !nameOk, adminEmail: !emailOk, password: !passOk });
    if (!orgOk || !phoneOk || !nameOk || !emailOk || !passOk) return;
    save.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !save.isPending && onOpenChange(o)}>
      <DialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="gap-0 overflow-y-auto rounded-3xl p-0 sm:max-w-lg">
        <DialogHeader className="border-b border-slate-200/70 px-6 py-5 dark:border-white/10">
          <DialogTitle className="flex items-center gap-3 font-display text-lg font-extrabold text-slate-900 dark:text-white">
            <span
              className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl text-white shadow-lg shadow-brand-500/25"
              style={{ backgroundImage: grad("#6d5dfb", "#06b6d4") }}
              aria-hidden="true"
            >
              <CatIcon name="user-pen" className="h-[18px] w-[18px]" />
            </span>
            {t("subsEditTitle")}
          </DialogTitle>
          <DialogDescription className="mt-1 ps-[52px] text-[12px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
            {inst?.org.name} — {t("subsEditDesc")}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5 px-6 py-5">
          {/* org identity */}
          <section className="space-y-3">
            <p className={cn("flex items-center gap-1.5 text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
              <CatIcon name="building-2" className="h-3.5 w-3.5 text-brand-500" />
              {t("subsEditOrgName")}
            </p>
            <div className="space-y-1.5">
              <Label htmlFor="subs-org-name" className="text-[11.5px] font-bold text-slate-600 dark:text-slate-300">
                {t("subsEditOrgName")}
              </Label>
              <Input
                id="subs-org-name"
                value={orgName}
                onChange={(e) => setOrgName(e.target.value)}
                placeholder={t("subsEditOrgNamePh")}
                dir={lang === "ar" ? "rtl" : "ltr"}
                className={cn(FIELD_BOX, invalid.orgName ? FIELD_BAD : FIELD_OK)}
                autoComplete="off"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="subs-phone" className="text-[11.5px] font-bold text-slate-600 dark:text-slate-300">
                {t("subsEditPhone")}
              </Label>
              <Input
                id="subs-phone"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder={t("subsEditPhonePh")}
                dir="ltr"
                className={cn(FIELD_BOX, invalid.phone ? FIELD_BAD : FIELD_OK, "text-start")}
                autoComplete="off"
                inputMode="tel"
              />
            </div>
          </section>

          {/* sign-in identity */}
          <section className="space-y-3 rounded-2xl border border-slate-200/70 bg-slate-50/60 p-4 dark:border-white/10 dark:bg-white/[0.03]">
            <p className={cn("flex items-center gap-1.5 text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
              <CatIcon name="shield-user" className="h-3.5 w-3.5 text-cyan-500" />
              {t("adminColAdmin")}
            </p>
            <div className="space-y-1.5">
              <Label htmlFor="subs-admin-name" className="text-[11.5px] font-bold text-slate-600 dark:text-slate-300">
                {t("subsEditAdminName")}
              </Label>
              <Input
                id="subs-admin-name"
                value={adminName}
                onChange={(e) => setAdminName(e.target.value)}
                dir={lang === "ar" ? "rtl" : "ltr"}
                className={cn(FIELD_BOX, invalid.adminName ? FIELD_BAD : FIELD_OK)}
                autoComplete="off"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="subs-email" className="text-[11.5px] font-bold text-slate-600 dark:text-slate-300">
                {t("subsEditAdminEmail")}
              </Label>
              <Input
                id="subs-email"
                type="email"
                value={adminEmail}
                onChange={(e) => setAdminEmail(e.target.value)}
                dir="ltr"
                className={cn(FIELD_BOX, invalid.adminEmail ? FIELD_BAD : FIELD_OK, "text-start")}
                autoComplete="off"
              />
              <p className="text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                {t("subsEditEmailHint")}
              </p>
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between gap-2">
                <Label htmlFor="subs-password" className="text-[11.5px] font-bold text-slate-600 dark:text-slate-300">
                  {t("subsEditPassword")}
                </Label>
                <button
                  type="button"
                  onClick={() => {
                    setPassword(generatePassword());
                    setInvalid((v) => ({ ...v, password: false }));
                  }}
                  className="inline-flex h-7 items-center gap-1 rounded-lg border border-brand-200 bg-white/80 px-2.5 text-[10.5px] font-extrabold text-brand-600 transition hover:border-brand-300 hover:bg-brand-500/10 active:scale-95 dark:border-brand-500/30 dark:bg-brand-500/15 dark:text-brand-300"
                >
                  <CatIcon name="wand-sparkles" className="h-3 w-3" />
                  {t("subsEditPasswordGen")}
                </button>
              </div>
              <Input
                id="subs-password"
                type="text"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                dir="ltr"
                placeholder="••••••••"
                className={cn(FIELD_BOX, "font-mono tracking-wide", invalid.password ? FIELD_BAD : FIELD_OK, "text-start")}
                autoComplete="new-password"
              />
              <p className="text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                {t("subsEditPasswordHint")}
              </p>
            </div>
          </section>
        </div>

        <DialogFooter className="border-t border-slate-200/70 px-6 py-4 dark:border-white/10">
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={save.isPending}
            className="h-10 rounded-xl px-5 text-[12.5px] font-bold"
          >
            {t("dlgCancel")}
          </Button>
          <Button
            type="button"
            onClick={submit}
            disabled={save.isPending}
            className="h-10 gap-2 rounded-xl bg-linear-to-l from-brand-600 to-cyan-500 px-6 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
          >
            {save.isPending ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : <CatIcon name="save" className="h-4 w-4" />}
            {t("subsEditSave")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ------------------------------------------------------------------ */
/* ban dialog (temporary / permanent)                                  */
/* ------------------------------------------------------------------ */

/** local datetime-local value for a future instant (minutes granularity) */
function toLocalInputValue(date: Date): string {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

export function BanSubscriberDialog({
  inst,
  kind,
  open,
  onOpenChange,
}: {
  inst: InstanceDTO | null;
  kind: "temporary" | "permanent";
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();

  /* the datetime value persists per kind while the dialog is open */
  const [untilLocal, setUntilLocal] = useState("");
  const [reason, setReason] = useState("");
  const [ack, setAck] = useState(false);
  const [ackTouched, setAckTouched] = useState(false);

  const seededKey = inst?.id ?? "";
  const [seededFor, setSeededFor] = useState("");
  if (open && inst && seededFor !== seededKey) {
    setSeededFor(seededKey);
    /* default: +7 days at the current minute — a sane first offer */
    setUntilLocal(toLocalInputValue(new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)));
    setReason("");
    setAck(false);
    setAckTouched(false);
  }
  if (!open && seededFor !== "") {
    setSeededFor("");
  }

  const untilMs = untilLocal ? new Date(untilLocal).getTime() : Number.NaN;
  const untilValid =
    kind === "permanent" || (Number.isFinite(untilMs) && untilMs > Date.now() + 60_000);
  const reasonClean = reason.trim().slice(0, 280);
  const canConfirm = kind === "permanent" ? ack : true;

  const ban = useMutation({
    mutationFn: async () => {
      if (!inst) throw new Error("no instance");
      if (kind === "temporary") {
        return adminBanSubscriber(inst.id, "temporary", {
          until: new Date(untilMs).toISOString(),
          reason: reasonClean || null,
        });
      }
      return adminBanSubscriber(inst.id, "permanent", { reason: reasonClean || null });
    },
    onSuccess: () => {
      toast.success(t(kind === "temporary" ? "subsBanDoneTemp" : "subsBanDonePerm"));
      queryClient.invalidateQueries({ queryKey: ["instances"] });
      if (inst) queryClient.invalidateQueries({ queryKey: ["instance", inst.id] });
      onOpenChange(false);
    },
    onError: (error: Error) => toast.error(apiErrorText(error, t)),
  });

  const confirm = () => {
    if (kind === "permanent" && !ack) {
      setAckTouched(true);
      return;
    }
    if (!untilValid) return;
    ban.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !ban.isPending && onOpenChange(o)}>
      <DialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="gap-0 overflow-y-auto rounded-3xl p-0 sm:max-w-md">
        <DialogHeader className="border-b border-rose-200/70 px-6 py-5 dark:border-rose-500/20">
          <DialogTitle className="flex items-center gap-3 font-display text-lg font-extrabold text-slate-900 dark:text-white">
            <span
              className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl text-white shadow-lg shadow-rose-500/30"
              style={{ backgroundImage: grad("#e11d48", "#881337") }}
              aria-hidden="true"
            >
              <CatIcon name="octagon-x" className="h-[18px] w-[18px]" />
            </span>
            {t(kind === "temporary" ? "subsBanTitleTemp" : "subsBanTitlePerm", { org: inst?.org.name ?? "" })}
          </DialogTitle>
          <DialogDescription className="mt-1 ps-[52px] text-[12px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
            {t(kind === "temporary" ? "subsBanDescTemp" : "subsBanDescPerm")}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 px-6 py-5">
          {kind === "temporary" ? (
            <div className="space-y-2">
              <Label htmlFor="ban-until" className="text-[11.5px] font-bold text-slate-600 dark:text-slate-300">
                {t("subsBanUntil")}
              </Label>
              {/* R163 — the shared premium date field, datetime-local
                  flavor (the admin h-11 rhythm): brand calendar tile at
                  the field's far right in Arabic, clear-X + Arabic long-
                  form hint with the local time built in. */}
              <PremiumDateInput
                id="ban-until"
                type="datetime-local"
                size="lg"
                value={untilLocal}
                min={toLocalInputValue(new Date(Date.now() + 5 * 60_000))}
                onChange={(e) => setUntilLocal(e.target.value)}
                inputClassName={cn("text-start", !untilValid && untilLocal ? FIELD_BAD : FIELD_OK)}
              />
              {/* quick presets — 1 / 3 / 7 / 30 days */}
              <div className="flex flex-wrap items-center gap-1.5 pt-1">
                {[1, 3, 7, 30].map((days) => (
                  <button
                    key={days}
                    type="button"
                    onClick={() => setUntilLocal(toLocalInputValue(new Date(Date.now() + days * 24 * 60 * 60 * 1000)))}
                    className="h-8 rounded-xl border border-slate-200 bg-white/70 px-3 text-[11px] font-extrabold text-slate-600 transition hover:border-rose-300 hover:bg-rose-500/10 hover:text-rose-600 active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:text-rose-300"
                  >
                    +{fmtNum(days, lang)}
                    {lang === "ar" ? (days === 1 ? " يوم" : days === 2 ? " يومان" : " أيام") : days === 1 ? " day" : " days"}
                  </button>
                ))}
              </div>
              {untilLocal && Number.isFinite(untilMs) && untilMs > Date.now() ? (
                <p className="flex items-center gap-1.5 pt-1 text-[10.5px] font-bold text-rose-600 dark:text-rose-300">
                  <CatIcon name="calendar-clock" className="h-3.5 w-3.5" />
                  {t("subsBanLiftsAt")} {fullDate(new Date(untilMs).toISOString(), lang)}
                </p>
              ) : null}
            </div>
          ) : (
            <label
              className={cn(
                "flex cursor-pointer items-start gap-2.5 rounded-2xl border p-3.5 transition",
                ack
                  ? "border-rose-300 bg-rose-500/[0.07]"
                  : ackTouched
                    ? "border-rose-300 bg-rose-500/[0.05]"
                    : "border-slate-200 bg-slate-50/60 dark:border-white/10 dark:bg-white/[0.03]"
              )}
            >
              <Checkbox checked={ack} onCheckedChange={(v) => setAck(v === true)} className="mt-0.5" />
              <span className="text-[11.5px] font-bold leading-relaxed text-slate-700 dark:text-slate-200">
                {t("subsBanAck")}
              </span>
            </label>
          )}

          <div className="space-y-1.5">
            <Label htmlFor="ban-reason" className="text-[11.5px] font-bold text-slate-600 dark:text-slate-300">
              {t("subsBanReason")}
            </Label>
            <Textarea
              id="ban-reason"
              value={reason}
              onChange={(e) => setReason(e.target.value.slice(0, 280))}
              placeholder={t("subsBanReasonPh")}
              dir={lang === "ar" ? "rtl" : "ltr"}
              rows={3}
              className="rounded-xl border-slate-200 bg-slate-50/80 text-[13px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-rose-400 focus:bg-white focus:shadow-lg focus:shadow-rose-500/15 focus:ring-4 focus:ring-rose-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100"
            />
            <p className="text-end text-[10px] font-bold tabular-nums text-slate-400 dark:text-slate-500">
              {fmtNum(reason.length, lang)} / {fmtNum(280, lang)}
            </p>
          </div>
        </div>

        <DialogFooter className="border-t border-slate-200/70 px-6 py-4 dark:border-white/10">
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={ban.isPending}
            className="h-10 rounded-xl px-5 text-[12.5px] font-bold"
          >
            {t("dlgCancel")}
          </Button>
          <Button
            type="button"
            onClick={confirm}
            disabled={ban.isPending || !untilValid || !canConfirm}
            className="h-10 gap-2 rounded-xl bg-rose-600 px-6 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60"
          >
            {ban.isPending ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : <CatIcon name="octagon-x" className="h-4 w-4" />}
            {t("subsBanConfirm")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ------------------------------------------------------------------ */
/* unban dialog                                                        */
/* ------------------------------------------------------------------ */

export function UnbanSubscriberDialog({
  inst,
  open,
  onOpenChange,
}: {
  inst: InstanceDTO | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();

  const unban = useMutation({
    mutationFn: () => (inst ? adminUnbanSubscriber(inst.id) : Promise.reject(new Error("no instance"))),
    onSuccess: () => {
      toast.success(t("subsUnbanDone"));
      queryClient.invalidateQueries({ queryKey: ["instances"] });
      if (inst) queryClient.invalidateQueries({ queryKey: ["instance", inst.id] });
      onOpenChange(false);
    },
    onError: (error: Error) => toast.error(apiErrorText(error, t)),
  });

  const ban = inst?.entitlement?.ban;

  return (
    <AlertDialog open={open} onOpenChange={(o) => !unban.isPending && onOpenChange(o)}>
      <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl">
        <AlertDialogHeader>
          <AlertDialogTitle className="flex items-center gap-3 font-display text-lg font-extrabold text-slate-900 dark:text-white">
            <span
              className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl text-white shadow-lg shadow-emerald-500/25"
              style={{ backgroundImage: grad("#10b981", "#047857") }}
              aria-hidden="true"
            >
              <CatIcon name="badge-check" className="h-[18px] w-[18px]" />
            </span>
            {t("subsUnbanTitle")}
          </AlertDialogTitle>
          <AlertDialogDescription className="ps-[52px] text-[12.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
            {inst?.org.name} — {t("subsUnbanDesc")}
            {ban?.reason ? (
              <span className="mt-1 block text-[11px] text-slate-400 dark:text-slate-500">
                {t("subsBanReasonLabel")}: {ban.reason}
              </span>
            ) : null}
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={unban.isPending}>
            {t("dlgCancel")}
          </AlertDialogCancel>
          <AlertDialogAction
            onClick={(e) => {
              e.preventDefault();
              unban.mutate();
            }}
            disabled={unban.isPending}
            className="h-10 gap-2 rounded-xl bg-emerald-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:bg-emerald-700 active:scale-95 disabled:opacity-60"
          >
            {unban.isPending ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : <CatIcon name="badge-check" className="h-4 w-4" />}
            {t("subsUnbanConfirm")}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

/* ------------------------------------------------------------------ */
/* detail-sheet ban state card                                         */
/* ------------------------------------------------------------------ */

export function SubscriberBanSection({ inst }: { inst: InstanceDTO }) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const ban = inst.entitlement?.ban;

  const unban = useMutation({
    mutationFn: () => adminUnbanSubscriber(inst.id),
    onSuccess: () => {
      toast.success(t("subsUnbanDone"));
      queryClient.invalidateQueries({ queryKey: ["instance", inst.id] });
      queryClient.invalidateQueries({ queryKey: ["instances"] });
    },
    onError: (error: Error) => toast.error(apiErrorText(error, t)),
  });

  const active = ban?.active === true;
  const left = ban?.until ? timeLeftPhrase(ban.until, t) : "";

  return (
    <section
      className={cn(
        "rounded-2xl border p-4",
        active
          ? ban.kind === "permanent"
            ? "border-rose-300/80 bg-rose-500/[0.06] dark:border-rose-500/30 dark:bg-rose-500/[0.08]"
            : "border-amber-300/80 bg-amber-500/[0.06] dark:border-amber-500/30 dark:bg-amber-500/[0.07]"
          : "border-slate-200/70 bg-slate-50/50 dark:border-white/10 dark:bg-white/[0.02]"
      )}
    >
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className={cn("flex items-center gap-1.5 text-[11px] font-extrabold uppercase text-slate-500 dark:text-slate-400", labelTrack(lang))}>
          <CatIcon name="gavel" className="h-3.5 w-3.5 text-rose-500" />
          {t("subsBanStateTitle")}
        </p>
        {active ? (
          <Badge
            className={cn(
              "rounded-full border px-2.5 py-0.5 text-[10.5px] font-extrabold",
              ban.kind === "permanent"
                ? "border-rose-400/60 bg-rose-600 text-white"
                : "border-amber-400/60 bg-amber-500/15 text-amber-700 dark:text-amber-300"
            )}
          >
            <CatIcon name="octagon-x" className="h-3 w-3" />
            {t(ban.kind === "permanent" ? "subsBanActivePerm" : "subsBanActiveTemp")}
          </Badge>
        ) : (
          <Badge className="rounded-full border border-emerald-400/60 bg-emerald-500/10 px-2.5 py-0.5 text-[10.5px] font-extrabold text-emerald-600 dark:text-emerald-300">
            <CatIcon name="circle-check" className="h-3 w-3" />
            {t("subsBanNone")}
          </Badge>
        )}
      </div>

      {active ? (
        <div className="mt-3 space-y-2 text-[11.5px] font-semibold text-slate-600 dark:text-slate-300">
          {ban.until ? (
            <p className="flex flex-wrap items-center gap-1.5">
              <CatIcon name="calendar-clock" className="h-3.5 w-3.5 text-amber-500" />
              {t("subsBanLiftsAt")}
              <span className="font-extrabold">{fullDate(ban.until, lang)}</span>
              {left ? (
                <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/10 px-2 py-px text-[10.5px] font-extrabold text-amber-700 dark:text-amber-300">
                  {t("subsBanChipLeft", { time: left })}
                </span>
              ) : null}
            </p>
          ) : null}
          {ban.at ? (
            <p className="flex items-center gap-1.5">
              <CatIcon name="clock" className="h-3.5 w-3.5 text-slate-400" />
              {t("subsBanAppliedAt")}
              <span className="font-extrabold">{fullDate(ban.at, lang)}</span>
            </p>
          ) : null}
          {ban.reason ? (
            <p className="flex items-start gap-1.5 rounded-xl border border-slate-200/70 bg-white/70 p-2.5 dark:border-white/10 dark:bg-white/[0.04]">
              <CatIcon name="message-square-quote" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-rose-400" />
              <span>
                <span className="font-extrabold text-slate-700 dark:text-slate-200">{t("subsBanReasonLabel")}: </span>
                {ban.reason}
              </span>
            </p>
          ) : null}
          <Button
            type="button"
            onClick={() => unban.mutate()}
            disabled={unban.isPending}
            className="mt-1 h-9 w-full gap-2 rounded-xl bg-emerald-600 text-[11.5px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:bg-emerald-700 active:scale-95 disabled:opacity-60"
          >
            {unban.isPending ? <CatIcon name="refresh-cw" className="h-3.5 w-3.5 animate-spin" /> : <CatIcon name="badge-check" className="h-3.5 w-3.5" />}
            {t("subsUnbanConfirm")}
          </Button>
        </div>
      ) : null}
    </section>
  );
}
