"use client";

/**
 * Ashrilogic — ROUND 142 — Super-Admin «Mobile App» console view.
 *
 * A dedicated premium page where the platform's super admin controls the
 * storefront links for the official-site «Mobile app» download section
 * (Google Play + App Store) plus a version label and a «publish» toggle.
 *
 * Persistence model:
 *  - Reuses the SAME identityJson column the brand identity uses (no schema
 *    migration — the mobile-app block is an embedded `mobileApp` field on
 *    the identity object, validated by the identitySchema/identityRead zod
 *    schemas in src/lib/server/admin-mapper.ts).
 *  - Saves via PATCH /api/admin/settings with `{ identity: { ...current, mobileApp } }`
 *    (the existing settings PATCH already accepts the COMPLETE identity
 *    object — the page reconstructs it so the save is idempotent).
 *  - On success it invalidates BOTH the platform-settings cache (the
 *    console's own row) AND the public /api/identity cache (the bridge + the
 *    landing MobileAppSection share the IDENTITY_QUERY_KEY), so a publish
 *    converges on the official site within the 5-minute stale window and
 *    instantly on the next focus.
 *
 * UX: live preview at the head of the page replays the EXACT landing badges
 * (the same StoreBadge visual: gradient tile + store name + «قريباً / LIVE»
 * pill), so the operator sees the visitor-side result before saving.
 */
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { fetchPlatformSettings, updatePlatformSettings } from "@/lib/api-client";
import { useT } from "@/lib/i18n";
import { useAdminAuth } from "@/lib/admin-auth";
import { CatIcon } from "@/components/icon";
import { cn, grad } from "@/lib/utils";
import { DashCard, ViewHeading, relativeTime } from "@/components/dashboard/dash-shared";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import type {
  PlatformIdentityDTO,
  PlatformMobileAppIdentity,
  PlatformSettingsDTO,
  PlatformSettingsPayload,
} from "@/lib/types";
import { IDENTITY_QUERY_KEY } from "@/components/shared/identity-bridge";

/** Local editable draft of the mobileApp block (independent URL/version/publish). */
type MobileDraft = {
  googlePlayUrl: string;
  appStoreUrl: string;
  version: string;
  published: boolean;
};

const EMPTY_DRAFT: MobileDraft = {
  googlePlayUrl: "",
  appStoreUrl: "",
  version: "",
  published: false,
};

function toDraft(value: PlatformMobileAppIdentity | null | undefined): MobileDraft {
  return {
    googlePlayUrl: (value?.googlePlayUrl ?? "").trim(),
    appStoreUrl: (value?.appStoreUrl ?? "").trim(),
    version: (value?.version ?? "").trim(),
    published: value?.published === true,
  };
}

/** True when both sides agree byte-for-byte (used for the dirty check). */
function draftsEqual(a: MobileDraft, b: MobileDraft): boolean {
  return (
    a.googlePlayUrl === b.googlePlayUrl &&
    a.appStoreUrl === b.appStoreUrl &&
    a.version === b.version &&
    a.published === b.published
  );
}

export function AdminMobileApp() {
  const { t, lang } = useT();
  const { user } = useAdminAuth();
  const canManage = user?.role === "super" || user?.role === "admin";
  const queryClient = useQueryClient();

  const [draft, setDraft] = useState<MobileDraft>(EMPTY_DRAFT);
  const [loadedFrom, setLoadedFrom] = useState<string | null>(null);

  const query = useQuery({
    queryKey: ["platform-settings"],
    queryFn: fetchPlatformSettings,
    staleTime: 60_000,
  });

  const serverIdentity: PlatformIdentityDTO | null = query.data?.identity ?? null;
  const serverDraft = useMemo(() => toDraft(serverIdentity?.mobileApp ?? null), [serverIdentity]);

  /* load the draft once data lands (or the row changes after a save) */
  const fingerprint = JSON.stringify(serverDraft);
  if (query.data && loadedFrom !== fingerprint) {
    setLoadedFrom(fingerprint);
    setDraft(serverDraft);
  }

  const isDirty = !draftsEqual(draft, serverDraft);

  /* the save dispatches the COMPLETE identity object (the existing
     settings PATCH contract requires the complete identity, never a
     partial). The mobileApp block carries the local draft; every other
     identity field rides through verbatim from the server row. */
  const save = useMutation({
    mutationFn: (payload: PlatformSettingsPayload) => updatePlatformSettings(payload),
    onSuccess: (data: PlatformSettingsDTO) => {
      queryClient.setQueryData(["platform-settings"], data);
      queryClient.invalidateQueries({ queryKey: ["platform-settings"] });
      /* the PUBLIC identity feed follows the save immediately — the
         landing MobileAppSection + the IdentityBridge share this key. */
      queryClient.invalidateQueries({ queryKey: IDENTITY_QUERY_KEY });
      toast.success(t("adminAppSaveSuccess"));
    },
    onError: (error: Error) =>
      toast.error(
        error.message ? `${t("adminAppSaveErr")} — ${error.message}` : t("adminAppSaveErr")
      ),
  });

  const submit = () => {
    if (!canManage || !isDirty || save.isPending || !serverIdentity) return;
    /* the COMPLETE identity object: server fields verbatim + the draft's
       mobileApp block (the schema accepts null/empty/undefined per field) */
    const nextIdentity: PlatformIdentityDTO = {
      ...serverIdentity,
      mobileApp: {
        googlePlayUrl: draft.googlePlayUrl.trim() || null,
        appStoreUrl: draft.appStoreUrl.trim() || null,
        version: draft.version.trim() || null,
        published: draft.published,
      },
    };
    save.mutate({ identity: nextIdentity });
  };

  const discard = () => {
    setDraft(serverDraft);
    toast.success(t("setResetDone"));
  };

  /* error / loading states — mirrors the admin-legal view's pattern */
  if (query.isError) {
    return (
      <div className="space-y-5">
        <ViewHeading title={t("adminMobileApp")} desc={t("adminMobileAppDesc")} />
        <DashCard>
          <div className="py-14 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-rose-100 text-rose-500 dark:bg-rose-500/10 dark:text-rose-300">
              <CatIcon name="circle-alert" className="h-6 w-6" />
            </div>
            <p className="mt-3 font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("errorText")}
            </p>
            <Button
              type="button"
              variant="outline"
              onClick={() => query.refetch()}
              className="mt-5 h-11 gap-2 rounded-xl px-5 text-[12.5px] font-bold"
            >
              <CatIcon name="refresh-cw" className="h-4 w-4" />
              {t("retryText")}
            </Button>
          </div>
        </DashCard>
      </div>
    );
  }

  if (query.isPending) {
    return (
      <div className="space-y-5">
        <ViewHeading title={t("adminMobileApp")} desc={t("adminMobileAppDesc")} />
        <Skeleton className="h-11 w-64 rounded-xl" />
        <Skeleton className="h-64 rounded-3xl" />
        <Skeleton className="h-48 rounded-3xl" />
      </div>
    );
  }

  /* derived preview-state: live-ness per store (matches the landing logic) */
  const published = draft.published;
  const playLive = published && draft.googlePlayUrl.trim().length > 0;
  const appleLive = published && draft.appStoreUrl.trim().length > 0;
  const anyUrl = draft.googlePlayUrl.trim().length > 0 || draft.appStoreUrl.trim().length > 0;

  return (
    <div className="space-y-5">
      <ViewHeading title={t("adminMobileApp")} desc={t("adminMobileAppDesc")} />

      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
        className="space-y-5"
      >
        {/* actions header — always visible, never sticky */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          {query.data ? (
            <Badge
              variant="secondary"
              className="gap-1.5 rounded-full bg-slate-500/10 px-3 py-1 text-[11px] font-bold text-slate-500 dark:text-slate-400"
            >
              <CatIcon name="clock" className="h-3 w-3" />
              <span>
                {t("setLastSaved")}: {relativeTime(query.data.updatedAt, lang)}
              </span>
            </Badge>
          ) : (
            <span />
          )}
          <div className="ms-auto flex items-center gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={discard}
              disabled={!isDirty || save.isPending || !canManage}
              title={!canManage ? t("adminNoPerm") : undefined}
              className="h-11 gap-2 rounded-xl border-slate-200 px-4 text-[12.5px] font-bold text-slate-600 transition hover:border-rose-300 hover:text-rose-600 active:scale-95 disabled:opacity-50 dark:border-white/10 dark:text-slate-300 dark:hover:border-rose-400/50 dark:hover:text-rose-300"
            >
              <CatIcon name="clock-rotate-left" className="h-4 w-4" />
              {t("setReset")}
            </Button>
            <Button
              type="submit"
              disabled={!isDirty || save.isPending || !canManage}
              title={!canManage ? t("adminNoPerm") : undefined}
              className="h-11 gap-2 rounded-xl bg-linear-to-l from-brand-600 via-fuchsia-500 to-cyan-400 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/30 transition hover:brightness-110 active:scale-95 disabled:opacity-50"
            >
              {save.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="save" className="h-4 w-4" />
              )}
              {t("setSave")}
            </Button>
          </div>
        </div>

        {/* live preview — replays the exact landing badges under the current
            unsaved draft so the operator sees what visitors will see */}
        <DashCard title={t("adminAppPreviewTitle")} icon="eye">
          <p className="mb-4 text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
            {t("adminAppPreviewHint")}
          </p>
          <div className="rounded-2xl border border-slate-200/70 bg-gradient-to-br from-brand-50 via-white to-cyan-50 p-6 dark:border-white/10 dark:from-brand-950/20 dark:via-transparent dark:to-cyan-950/20">
            <div className="flex flex-wrap items-center justify-center gap-4">
              <PreviewBadge
                live={playLive}
                icon="play"
                label="Google Play"
                subLabel={lang === "ar" ? "حمّله من" : "GET IT ON"}
                gradient="linear-gradient(135deg, #34a853 0%, #4285f4 50%, #fbbc04 100%)"
                liveLabel={lang === "ar" ? "متاح الآن" : "LIVE"}
                soonLabel={lang === "ar" ? "قريباً" : "SOON"}
              />
              <PreviewBadge
                live={appleLive}
                icon="apple"
                label="App Store"
                subLabel={lang === "ar" ? "حمّله من" : "Download on the"}
                gradient="linear-gradient(135deg, #1f2937 0%, #0f172a 100%)"
                liveLabel={lang === "ar" ? "متاح الآن" : "LIVE"}
                soonLabel={lang === "ar" ? "قريباً" : "SOON"}
              />
            </div>
            {!anyUrl ? (
              <p className="mt-4 text-center text-[11px] font-bold text-amber-600 dark:text-amber-400">
                {t("adminAppBothMissing")}
              </p>
            ) : null}
          </div>
        </DashCard>

        {/* the form card — URLs + version + publish toggle */}
        <DashCard title={t("adminMobileApp")} icon="smartphone">
          <div className="space-y-1">
            {/* Google Play URL */}
            <div className="flex flex-col gap-3 py-4 sm:flex-row sm:items-center sm:justify-between sm:gap-6">
              <div className="flex min-w-0 items-center gap-3">
                <span
                  aria-hidden="true"
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
                  style={{ backgroundImage: "linear-gradient(135deg, #34a853 0%, #4285f4 50%, #fbbc04 100%)" }}
                >
                  <CatIcon name="play" className="h-[12px] w-[12px]" />
                </span>
                <div className="min-w-0">
                  <Label htmlFor="mobile-app-google" className="block text-[12.5px] font-extrabold leading-tight text-slate-800 dark:text-slate-100">
                    {t("adminGooglePlayUrl")}
                  </Label>
                  <p className="mt-0.5 text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                    {t("adminGooglePlayUrlPh")}
                  </p>
                </div>
              </div>
              <div className="w-full sm:w-80">
                <Input
                  id="mobile-app-google"
                  type="url"
                  inputMode="url"
                  dir="ltr"
                  value={draft.googlePlayUrl}
                  maxLength={300}
                  disabled={!canManage || save.isPending}
                  placeholder={t("adminGooglePlayUrlPh")}
                  onChange={(e) => setDraft((d) => ({ ...d, googlePlayUrl: e.target.value }))}
                  className="w-full text-start"
                />
              </div>
            </div>

            {/* App Store URL */}
            <div className="flex flex-col gap-3 border-t border-slate-200/70 py-4 sm:flex-row sm:items-center sm:justify-between sm:gap-6 dark:border-white/10">
              <div className="flex min-w-0 items-center gap-3">
                <span
                  aria-hidden="true"
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
                  style={{ backgroundImage: "linear-gradient(135deg, #1f2937 0%, #0f172a 100%)" }}
                >
                  <CatIcon name="apple" className="h-[12px] w-[12px]" />
                </span>
                <div className="min-w-0">
                  <Label htmlFor="mobile-app-apple" className="block text-[12.5px] font-extrabold leading-tight text-slate-800 dark:text-slate-100">
                    {t("adminAppStoreUrl")}
                  </Label>
                  <p className="mt-0.5 text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                    {t("adminAppStoreUrlPh")}
                  </p>
                </div>
              </div>
              <div className="w-full sm:w-80">
                <Input
                  id="mobile-app-apple"
                  type="url"
                  inputMode="url"
                  dir="ltr"
                  value={draft.appStoreUrl}
                  maxLength={300}
                  disabled={!canManage || save.isPending}
                  placeholder={t("adminAppStoreUrlPh")}
                  onChange={(e) => setDraft((d) => ({ ...d, appStoreUrl: e.target.value }))}
                  className="w-full text-start"
                />
              </div>
            </div>

            {/* Version */}
            <div className="flex flex-col gap-3 border-t border-slate-200/70 py-4 sm:flex-row sm:items-center sm:justify-between sm:gap-6 dark:border-white/10">
              <div className="flex min-w-0 items-center gap-3">
                <span
                  aria-hidden="true"
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
                  style={{ backgroundImage: grad("#6d5dfb", "#06b6d4") }}
                >
                  <CatIcon name="tag" className="h-[12px] w-[12px]" />
                </span>
                <div className="min-w-0">
                  <Label htmlFor="mobile-app-version" className="block text-[12.5px] font-extrabold leading-tight text-slate-800 dark:text-slate-100">
                    {t("adminAppVersion")}
                  </Label>
                  <p className="mt-0.5 text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                    {t("adminAppVersionPh")}
                  </p>
                </div>
              </div>
              <div className="w-full sm:w-48">
                <Input
                  id="mobile-app-version"
                  type="text"
                  dir="ltr"
                  value={draft.version}
                  maxLength={40}
                  disabled={!canManage || save.isPending}
                  placeholder={t("adminAppVersionPh")}
                  onChange={(e) => setDraft((d) => ({ ...d, version: e.target.value }))}
                  className="w-full text-start"
                />
              </div>
            </div>

            {/* Published toggle */}
            <div className="flex flex-col gap-3 border-t border-slate-200/70 py-4 sm:flex-row sm:items-center sm:justify-between sm:gap-6 dark:border-white/10">
              <div className="flex min-w-0 items-center gap-3">
                <span
                  aria-hidden="true"
                  className={cn(
                    "grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md",
                    draft.published
                      ? "bg-linear-to-br from-emerald-400 to-teal-500 shadow-emerald-500/25"
                      : "bg-linear-to-br from-slate-400 to-slate-500"
                  )}
                >
                  <CatIcon name={draft.published ? "circle-check" : "rocket"} className="h-[12px] w-[12px]" />
                </span>
                <div className="min-w-0">
                  <Label htmlFor="mobile-app-published" className="block text-[12.5px] font-extrabold leading-tight text-slate-800 dark:text-slate-100">
                    {t("adminAppPublished")}
                  </Label>
                  <p className="mt-0.5 max-w-md text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                    {t("adminAppPublishedHint")}
                  </p>
                </div>
              </div>
              <Switch
                id="mobile-app-published"
                tone="brand"
                checked={draft.published}
                disabled={!canManage || save.isPending}
                onCheckedChange={(v) => setDraft((d) => ({ ...d, published: v }))}
                aria-label={t("adminAppPublished")}
              />
            </div>
          </div>
        </DashCard>
      </form>
    </div>
  );
}

/** The live-preview badge — visually identical to the landing StoreBadge,
    but never an anchor (the preview is informational only). */
function PreviewBadge({
  live,
  icon,
  label,
  subLabel,
  gradient,
  liveLabel,
  soonLabel,
}: {
  live: boolean;
  icon: string;
  label: string;
  subLabel: string;
  gradient: string;
  liveLabel: string;
  soonLabel: string;
}) {
  return (
    <div className="group relative inline-flex items-center gap-3 rounded-2xl border border-slate-200 bg-white px-6 py-3.5 shadow-lg shadow-slate-200/50 dark:border-white/10 dark:bg-white/[0.04] dark:shadow-black/20">
      <span
        className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-md"
        style={{ backgroundImage: gradient }}
        aria-hidden="true"
      >
        <CatIcon name={icon} className="h-5 w-5" />
      </span>
      <div className="text-start">
        <p className="text-[10px] font-bold uppercase tracking-wide text-slate-400 dark:text-slate-500">{subLabel}</p>
        <p className="text-[15px] font-extrabold text-slate-900 dark:text-white">{label}</p>
      </div>
      <span
        className={cn(
          "absolute -top-2 -end-2 rounded-full px-2 py-0.5 text-[9px] font-extrabold text-white shadow-md",
          live ? "bg-emerald-500" : "bg-brand-500"
        )}
      >
        {live ? liveLabel : soonLabel}
      </span>
    </div>
  );
}

export default AdminMobileApp;
