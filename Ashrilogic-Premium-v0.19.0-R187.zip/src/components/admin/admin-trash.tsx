"use client";

/**
 * Ashrilogic — Super Admin trash console (سلة المحذوفات).
 *
 * ROUND 87 — every soft-deleted row (workspaces, admin accounts, tenant
 * records / orders / customers / coupons / members / reviews) lands here
 * with a live retention countdown. The API runs the retention sweep before
 * every read, so what this console shows is exactly what is still
 * recoverable.
 *
 * - TWO feeds: a global stats query (KPIs + per-entity pill counts) and a
 *   filtered item query (entity + 300ms-debounced search, one 200-item
 *   fetch — the API cap — paginated client-side with "load more");
 * - restore: AlertDialog confirm → POST restore; 409 key conflicts surface
 *   the localized conflict toast;
 * - purge: STRICT type-to-confirm AlertDialog — the destructive button
 *   stays disabled until the typed word matches t("trashConfirmWord");
 * - "purge expired now" retention-sweep button (super/admin only — the
 *   server 403s moderators on every POST);
 * - governance rows (workspaces + admin accounts) are super-only: their
 *   actions are locked for every other role (server enforces the same law
 *   independently with SUPER_ONLY);
 * - bulk selection bar: restore / purge every selected row via
 *   Promise.allSettled + a count summary toast.
 */
import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { adminTrashAction, fetchAdminTrash, ApiError } from "@/lib/api-client";
import type { TrashItemDTO } from "@/lib/api-client";
import { useAdminAuth, useAdminCanManage } from "@/lib/admin-auth";
import { useT, type I18nKey } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { KpiCard } from "@/components/shared/kpi-card";
import { DashCard, dateOnly, fullDate, relativeTime } from "@/components/dashboard/dash-shared";

/* ---------------- vocabulary ---------------- */

/** One feed fetch (the API hard-caps limit at 200). */
const FETCH_LIMIT = 200;
/** Client-side page step for the "load more" button. */
const PAGE_STEP = 25;

/** Entity vocabulary — icon tile + gradient per trash entity (pill order). */
const ENTITY_META: { id: string; key: I18nKey; icon: string; c1: string; c2: string }[] = [
  { id: "instance", key: "trashEntityInstance", icon: "globe", c1: "#8b5cf6", c2: "#06b6d4" },
  { id: "adminUser", key: "trashEntityAdmin", icon: "shield-user", c1: "#6d5dfb", c2: "#4b35c9" },
  { id: "moduleRecord", key: "trashEntityRecord", icon: "database", c1: "#0ea5e9", c2: "#0369a1" },
  { id: "siteOrder", key: "trashEntityOrder", icon: "receipt", c1: "#10b981", c2: "#059669" },
  { id: "siteCustomer", key: "trashEntityCustomer", icon: "users-round", c1: "#f59e0b", c2: "#d97706" },
  { id: "storeCoupon", key: "trashEntityCoupon", icon: "ticket-percent", c1: "#f59e0b", c2: "#b45309" },
  { id: "teamMember", key: "trashEntityMember", icon: "users", c1: "#06b6d4", c2: "#0e7490" },
  { id: "siteReview", key: "trashEntityReview", icon: "star", c1: "#d946ef", c2: "#c026d3" },
];

const ENTITY_BY_ID = new Map(ENTITY_META.map((e) => [e.id, e]));

/** Restore/purge of these entities is SUPER-ONLY (mirrors the route guard). */
const GOVERNANCE_ENTITIES = new Set(["instance", "adminUser"]);

/** Unknown entity → neutral fallback tile (server vocabulary may grow). */
const FALLBACK_META = { icon: "archive", c1: "#64748b", c2: "#475569" };

/** Countdown badge tone: green > 14 · amber 8–14 · rose ≤ 7 (+ pulse). */
function daysLeftTone(days: number): string {
  if (days <= 7)
    return "border-rose-200 bg-rose-50 text-rose-600 dark:border-rose-500/25 dark:bg-rose-500/10 dark:text-rose-300";
  if (days <= 14)
    return "border-amber-200 bg-amber-50 text-amber-600 dark:border-amber-500/25 dark:bg-amber-500/10 dark:text-amber-300";
  return "border-emerald-200 bg-emerald-50 text-emerald-600 dark:border-emerald-500/25 dark:bg-emerald-500/10 dark:text-emerald-300";
}

/** Selection key — entity-scoped (ids alone are not unique across tables). */
const keyOf = (item: TrashItemDTO): string => `${item.entity}:${item.id}`;

/* ---------------- skeletons ---------------- */

function KpiSkeletonStrip() {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <Skeleton key={i} className="h-[118px] rounded-3xl" />
      ))}
    </div>
  );
}

function TrashRowsSkeleton() {
  return (
    <div className="space-y-3">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className="flex items-center gap-3">
          <Skeleton className="h-4 w-4 rounded-[4px]" />
          <Skeleton className="h-11 w-11 rounded-xl" />
          <div className="flex-1 space-y-1.5">
            <Skeleton className="h-3.5 w-56" />
            <Skeleton className="h-2.5 w-40" />
            <Skeleton className="h-2.5 w-32" />
          </div>
          <div className="space-y-1.5">
            <Skeleton className="h-6 w-16 rounded-full" />
            <Skeleton className="h-8 w-20 rounded-xl" />
          </div>
        </div>
      ))}
    </div>
  );
}

/* ---------------- view ---------------- */

export function AdminTrash() {
  const { t, lang } = useT();
  const { user } = useAdminAuth();
  const canManage = useAdminCanManage();
  const isSuper = user?.role === "super";
  const queryClient = useQueryClient();

  const [entity, setEntity] = useState("all");
  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  const [visible, setVisible] = useState(PAGE_STEP);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [restoreTarget, setRestoreTarget] = useState<TrashItemDTO | null>(null);
  const [purgeTarget, setPurgeTarget] = useState<TrashItemDTO | null>(null);
  const [confirmText, setConfirmText] = useState("");
  const [bulkPending, setBulkPending] = useState(false);

  /* 300ms debounce — lowercased to match the server-side search filter.
     The timeout callback ALSO restarts client-side pagination (async — never
     a synchronous setState inside the effect body). */
  useEffect(() => {
    const h = window.setTimeout(() => {
      setDebounced(search.trim().toLowerCase());
      setVisible(PAGE_STEP);
    }, 300);
    return () => window.clearTimeout(h);
  }, [search]);

  /** New entity filter → restart client-side pagination (event-driven). */
  const applyEntity = (id: string) => {
    setEntity(id);
    setVisible(PAGE_STEP);
  };

  /* Global stats feed (KPIs + pill counts — never narrowed by the filter). */
  const statsQuery = useQuery({
    queryKey: ["admin-trash", "stats"],
    queryFn: () => fetchAdminTrash({ limit: 1 }),
  });

  /* Filtered item feed — one capped fetch, paginated client-side. */
  const listQuery = useQuery({
    queryKey: ["admin-trash", "list", entity, debounced],
    queryFn: () =>
      fetchAdminTrash({
        entity: entity === "all" ? null : entity,
        q: debounced || null,
        limit: FETCH_LIMIT,
      }),
  });

  const items = useMemo(() => listQuery.data?.items ?? [], [listQuery.data]);
  const shown = useMemo(() => items.slice(0, visible), [items, visible]);

  /* rows the current role may act on (drives checkboxes + select-all). */
  const selectableShown = useMemo(
    () => shown.filter((it) => canManage && !(GOVERNANCE_ENTITIES.has(it.entity) && !isSuper)),
    [shown, canManage, isSuper]
  );
  const allShownSelected =
    selectableShown.length > 0 && selectableShown.every((it) => selected.has(keyOf(it)));

  const dropSelected = (keys: string[]) => {
    setSelected((prev) => {
      if (keys.every((k) => !prev.has(k))) return prev;
      const next = new Set(prev);
      keys.forEach((k) => next.delete(k));
      return next;
    });
  };

  const invalidateAll = () => {
    void queryClient.invalidateQueries({ queryKey: ["admin-trash"] });
  };

  /* ---------------- mutations ---------------- */

  const restore = useMutation({
    mutationFn: (item: TrashItemDTO) =>
      adminTrashAction({ action: "restore", entity: item.entity, id: item.id }),
    onSuccess: (res, item) => {
      toast.success(t("trashRestoredToast", { label: res.label ?? item.label }));
      setRestoreTarget(null);
      dropSelected([keyOf(item)]);
      invalidateAll();
    },
    onError: (error: Error) => {
      if (error instanceof ApiError && (error.status === 409 || error.code === "CONFLICT")) {
        toast.error(t("trashRestoreConflictTitle"), { description: t("trashConflictToast") });
      } else {
        toast.error(error.message);
      }
    },
  });

  const purge = useMutation({
    mutationFn: (item: TrashItemDTO) =>
      adminTrashAction({ action: "purge", entity: item.entity, id: item.id }),
    onSuccess: (res, item) => {
      toast.success(t("trashPurgedToast", { label: res.label ?? item.label }));
      setPurgeTarget(null);
      setConfirmText("");
      dropSelected([keyOf(item)]);
      invalidateAll();
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const purgeExpired = useMutation({
    mutationFn: () => adminTrashAction({ action: "purgeExpired" }),
    onSuccess: (res) => {
      toast.success(t("trashPurgeExpiredToast", { n: res.purged ?? 0 }));
      invalidateAll();
    },
    onError: (error: Error) => toast.error(error.message),
  });

  /** Bulk restore / purge — every selected row via Promise.allSettled,
   *  then ONE count summary toast + selection cleared. */
  const runBulk = async (action: "restore" | "purge") => {
    const targets = items.filter((it) => selected.has(keyOf(it)));
    if (targets.length === 0) return;
    setBulkPending(true);
    const results = await Promise.allSettled(
      targets.map((it) => adminTrashAction({ action, entity: it.entity, id: it.id }))
    );
    setBulkPending(false);

    let ok = 0;
    let conflicts = 0;
    for (const r of results) {
      if (r.status === "fulfilled" && r.value.ok) ok += 1;
      else if (
        r.status === "rejected" &&
        r.reason instanceof ApiError &&
        (r.reason.status === 409 || r.reason.code === "CONFLICT")
      )
        conflicts += 1;
    }
    const total = targets.length;
    if (ok > 0) {
      toast.success(
        `${t(action === "restore" ? "trashBulkRestore" : "trashBulkPurge")}: ${fmtNum(ok, lang)}/${fmtNum(total, lang)}`
      );
    }
    if (conflicts > 0) toast.error(t("trashConflictToast"));
    if (ok + conflicts < total) toast.error(t("errorText"));
    setSelected(new Set());
    invalidateAll();
  };

  /* ---------------- render helpers ---------------- */

  const header = (
    <div className="mb-6 flex items-center gap-4">
      <span
        className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl text-white shadow-lg shadow-rose-500/25"
        style={{ backgroundImage: grad("#f43f5e", "#8b5cf6") }}
        aria-hidden="true"
      >
        <CatIcon name="trash-2" className="h-6 w-6" />
      </span>
      <div className="min-w-0">
        <h1 className="font-display text-2xl font-extrabold text-slate-900 dark:text-white">
          {t("trashTitle")}
        </h1>
        <p className="mt-1 text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
          {t("trashDesc")}
        </p>
      </div>
    </div>
  );

  const pillClass = (active: boolean) =>
    cn(
      "inline-flex h-8 shrink-0 items-center gap-1.5 rounded-xl px-3 text-[11.5px] font-extrabold transition active:scale-95",
      active
        ? "bg-brand-500/10 text-brand-600 shadow-[0_0_16px_-6px_rgba(109,93,251,0.5)] dark:text-brand-300"
        : "text-slate-500 hover:bg-slate-100 hover:text-slate-800 dark:text-slate-400 dark:hover:bg-white/[0.06] dark:hover:text-white"
    );

  const countChip = (n: number, active: boolean) => (
    <span
      dir="ltr"
      className={cn(
        "rounded-full px-1.5 py-px text-[10px] font-extrabold tabular-nums",
        active
          ? "bg-brand-500/15 text-brand-600 dark:bg-brand-500/20 dark:text-brand-300"
          : "bg-slate-100 text-slate-500 dark:bg-white/10 dark:text-slate-400"
      )}
    >
      {fmtNum(n, lang)}
    </span>
  );

  /* ---------------- loading / error ---------------- */

  if (statsQuery.isPending || listQuery.isPending) {
    return (
      <div className="space-y-5">
        {header}
        <KpiSkeletonStrip />
        <DashCard title={t("trashTitle")} icon="trash-2">
          <TrashRowsSkeleton />
        </DashCard>
      </div>
    );
  }

  if (statsQuery.isError || listQuery.isError) {
    return (
      <div className="space-y-5">
        {header}
        <DashCard>
          <div className="py-12 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-rose-50 text-rose-500 dark:bg-rose-500/10 dark:text-rose-300">
              <CatIcon name="triangle-alert" className="h-6 w-6" />
            </div>
            <p className="mt-3 text-[13px] font-bold text-rose-600 dark:text-rose-400">{t("errorText")}</p>
            <Button
              variant="outline"
              onClick={() => {
                void statsQuery.refetch();
                void listQuery.refetch();
              }}
              className="mt-3 h-10 rounded-xl px-5 text-[12.5px] font-bold"
            >
              <CatIcon name="refresh-cw" className="h-4 w-4" />
              {t("retryText")}
            </Button>
          </div>
        </DashCard>
      </div>
    );
  }

  const stats = statsQuery.data?.stats;

  /* ---------------- premium empty state (whole trash empty) ---------------- */

  if (!stats || stats.total === 0) {
    return (
      <div className="space-y-5">
        {header}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <KpiCard
            index={0}
            lang={lang}
            label={t("trashKpiTotal")}
            value={fmtNum(0, lang)}
            numeric={0}
            icon="archive"
            c1="#64748b"
            c2="#7c3aed"
          />
          <KpiCard
            index={1}
            lang={lang}
            label={t("trashKpiExpiring")}
            value={fmtNum(0, lang)}
            numeric={0}
            icon="hourglass"
            c1="#f59e0b"
            c2="#d97706"
          />
          <KpiCard
            index={2}
            lang={lang}
            label={t("trashKpiRetention")}
            value={t("trashKpiRetentionDays", { n: fmtNum(stats?.retentionDays ?? 0, lang) })}
            icon="calendar-clock"
            c1="#06b6d4"
            c2="#0891b2"
          />
          <KpiCard
            index={3}
            lang={lang}
            label={t("trashKpiOldest")}
            value="—"
            icon="clock-rotate-left"
            c1="#8b5cf6"
            c2="#6d28d9"
          />
        </div>

        <DashCard>
          <div className="py-16 text-center">
            <div className="relative mx-auto w-fit">
              <span
                className="grid h-16 w-16 place-items-center rounded-3xl text-white shadow-xl shadow-emerald-500/25 ring-8 ring-emerald-500/10 dark:ring-emerald-400/10"
                style={{ backgroundImage: grad("#10b981", "#06b6d4") }}
                aria-hidden="true"
              >
                <CatIcon name="sparkles" className="h-7 w-7" />
              </span>
            </div>
            <p className="mt-4 font-display text-[15px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("trashEmptyTitle")}
            </p>
            <p className="mx-auto mt-1.5 max-w-sm text-[12px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {t("trashEmptyDesc")}
            </p>
          </div>
        </DashCard>
      </div>
    );
  }

  /* ---------------- main console ---------------- */

  const confirmReady = confirmText.trim() === t("trashConfirmWord");
  const filtersActive = entity !== "all" || debounced !== "";

  return (
    <div className="space-y-5">
      {header}

      {/* KPI strip — totals count up on first view */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard
          index={0}
          lang={lang}
          label={t("trashKpiTotal")}
          value={fmtNum(stats.total, lang)}
          numeric={stats.total}
          icon="archive"
          c1="#64748b"
          c2="#7c3aed"
        />
        <KpiCard
          index={1}
          lang={lang}
          label={t("trashKpiExpiring")}
          value={fmtNum(stats.expiringSoon, lang)}
          numeric={stats.expiringSoon}
          icon="hourglass"
          c1="#f59e0b"
          c2="#d97706"
        />
        <KpiCard
          index={2}
          lang={lang}
          label={t("trashKpiRetention")}
          value={t("trashKpiRetentionDays", { n: fmtNum(stats.retentionDays, lang) })}
          icon="calendar-clock"
          c1="#06b6d4"
          c2="#0891b2"
        />
        <KpiCard
          index={3}
          lang={lang}
          label={t("trashKpiOldest")}
          value={stats.oldestAt ? dateOnly(stats.oldestAt, lang) : "—"}
          icon="clock-rotate-left"
          c1="#8b5cf6"
          c2="#6d28d9"
        />
      </div>

      {/* entity filter pills — horizontal scroll, counts from the global stats */}
      <div
        className="no-scrollbar -mx-1 flex gap-1.5 overflow-x-auto rounded-2xl border border-slate-200 bg-white p-1.5 dark:border-white/10 dark:bg-white/[0.03]"
        role="group"
        aria-label={t("trashColContext")}
      >
        <button type="button" onClick={() => applyEntity("all")} aria-pressed={entity === "all"} className={pillClass(entity === "all")}>
          <CatIcon name="layers" className="h-[12px] w-[12px]" />
          {t("trashFilterAll")}
          {countChip(stats.total, entity === "all")}
        </button>
        {ENTITY_META.map((e) => {
          const active = entity === e.id;
          return (
            <button key={e.id} type="button" onClick={() => applyEntity(e.id)} aria-pressed={active} className={pillClass(active)}>
              <CatIcon name={e.icon} className="h-[12px] w-[12px]" />
              {t(e.key)}
              {countChip(stats.byEntity[e.id] ?? 0, active)}
            </button>
          );
        })}
      </div>

      {/* search + refresh */}
      <div className="flex flex-wrap items-center gap-2.5">
        <div className="relative min-w-44 flex-1">
          <CatIcon
            name="search"
            className="pointer-events-none absolute inset-y-0 start-3 my-auto h-[14px] w-[14px] text-slate-400"
          />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t("trashSearchPh")}
            className="h-10 rounded-2xl ps-9 text-[12.5px]"
            aria-label={t("trashSearchPh")}
          />
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            void statsQuery.refetch();
            void listQuery.refetch();
          }}
          disabled={statsQuery.isFetching || listQuery.isFetching}
          className="h-10 rounded-2xl px-4 text-[12px] font-bold"
        >
          <CatIcon
            name="refresh-cw"
            className={cn("h-3.5 w-3.5", (statsQuery.isFetching || listQuery.isFetching) && "animate-spin")}
          />
          <span className="hidden sm:inline">{t("retryText")}</span>
        </Button>
      </div>

      {/* retention notice — the strict auto-purge law + manual sweep */}
      <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-amber-200/80 bg-amber-50/80 p-3.5 dark:border-amber-500/25 dark:bg-amber-500/10">
        <span
          className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-lg shadow-amber-500/25"
          style={{ backgroundImage: grad("#f59e0b", "#e11d48") }}
          aria-hidden="true"
        >
          <CatIcon name="shield-alert" className="h-[15px] w-[15px]" />
        </span>
        <p className="min-w-0 flex-1 text-[12px] font-bold leading-relaxed text-amber-800 dark:text-amber-200">
          {t("trashRetentionNote", { n: fmtNum(stats.retentionDays, lang) })}
        </p>
        {canManage ? (
          <Button
            onClick={() => purgeExpired.mutate()}
            disabled={purgeExpired.isPending}
            className="h-9 shrink-0 rounded-xl bg-rose-600 px-4 text-[12px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60"
          >
            <CatIcon
              name={purgeExpired.isPending ? "refresh-cw" : "flame"}
              className={cn("h-3.5 w-3.5", purgeExpired.isPending && "animate-spin")}
            />
            <span className="hidden sm:inline">{t("trashPurgeExpiredBtn")}</span>
            <span className="sm:hidden" dir="auto">
              {t("trashPurgeExpiredBtn")}
            </span>
          </Button>
        ) : null}
      </div>

      {/* items list — rich card rows */}
      <DashCard
        title={t("trashTitle")}
        icon="trash-2"
        action={
          <div className="flex items-center gap-2">
            <span
              dir="ltr"
              title={t("trashColItem")}
              className="rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-[10.5px] font-extrabold tabular-nums text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-400"
            >
              {fmtNum(shown.length, lang)}/{fmtNum(items.length, lang)}
            </span>
            {canManage && shown.length > 0 ? (
              <button
                type="button"
                onClick={() =>
                  allShownSelected
                    ? setSelected(new Set())
                    : setSelected((prev) => new Set([...prev, ...selectableShown.map(keyOf)]))
                }
                className="inline-flex h-7 items-center gap-1 rounded-lg px-2 text-[10.5px] font-extrabold text-slate-500 transition hover:bg-slate-100 hover:text-slate-800 active:scale-95 dark:text-slate-400 dark:hover:bg-white/[0.06] dark:hover:text-white"
              >
                <CatIcon name={allShownSelected ? "check-check" : "check"} className="h-3 w-3" />
                {allShownSelected ? t("trashClearSel") : t("trashSelectAll")}
              </button>
            ) : null}
          </div>
        }
      >
        {items.length === 0 ? (
          /* filtered empty — search / entity filter matched nothing */
          <div className="py-12 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5">
              <CatIcon name="search" className="h-6 w-6" />
            </div>
            <p className="mt-3 font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("trashNoResults")}
            </p>
            {filtersActive ? (
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setSearch("");
                  applyEntity("all");
                }}
                className="mt-3 h-9 rounded-xl px-4 text-[12px] font-bold"
              >
                <CatIcon name="x" className="h-3.5 w-3.5" />
                {t("trashFilterAll")}
              </Button>
            ) : null}
          </div>
        ) : (
          <>
            <ol className="space-y-1.5">
              {shown.map((item) => {
                const metaEntry = ENTITY_BY_ID.get(item.entity);
                const meta = metaEntry ?? FALLBACK_META;
                const entityLabel = metaEntry ? t(metaEntry.key) : item.entity;
                const governance = GOVERNANCE_ENTITIES.has(item.entity);
                const rowLocked = !canManage || (governance && !isSuper);
                const lockTitle = governance && !isSuper ? t("trashSuperOnly") : undefined;
                const rowKey = keyOf(item);
                const isSelected = selected.has(rowKey);
                const systemId =
                  item.entity === "instance" && typeof item.meta.systemId === "string"
                    ? item.meta.systemId
                    : null;
                const daysText =
                  item.daysLeft === 1
                    ? t("trashDaysLeftOne")
                    : t("trashDaysLeft", { n: fmtNum(item.daysLeft, lang) });
                return (
                  <li
                    key={rowKey}
                    className={cn(
                      "relative flex items-start gap-3 rounded-2xl p-3 transition hover:bg-slate-50 dark:hover:bg-white/5",
                      isSelected && "bg-brand-500/[0.06] hover:bg-brand-500/[0.08] dark:bg-brand-500/10 dark:hover:bg-brand-500/[0.14]"
                    )}
                  >
                    {/* selection */}
                    {canManage ? (
                      <Checkbox
                        checked={isSelected}
                        onCheckedChange={(checked) => {
                          setSelected((prev) => {
                            const next = new Set(prev);
                            if (checked === true) next.add(rowKey);
                            else next.delete(rowKey);
                            return next;
                          });
                        }}
                        disabled={governance && !isSuper}
                        title={lockTitle}
                        className="mt-3"
                        aria-label={item.label}
                      />
                    ) : null}

                    {/* entity icon tile */}
                    <span
                      className="grid h-11 w-11 shrink-0 place-items-center rounded-xl text-white shadow-lg"
                      style={{ backgroundImage: grad(meta.c1, meta.c2) }}
                      title={entityLabel}
                      aria-hidden="true"
                    >
                      <CatIcon name={meta.icon} className="h-[15px] w-[15px]" />
                    </span>

                    {/* item block */}
                    <div className="min-w-0 flex-1" aria-label={t("trashColItem")}>
                      <p
                        className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[13px] font-extrabold text-slate-800 dark:text-slate-100"
                        dir="auto"
                      >
                        <span className="min-w-0 truncate">{item.label}</span>
                        <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-slate-200 bg-slate-50 px-2 py-0.5 text-[10px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-400">
                          <CatIcon name={meta.icon} className="h-2.5 w-2.5" />
                          {entityLabel}
                        </span>
                      </p>

                      {item.detail ? (
                        <p
                          className="mt-0.5 truncate text-[11.5px] font-semibold text-slate-500 dark:text-slate-400"
                          dir="auto"
                        >
                          {item.detail}
                        </p>
                      ) : null}

                      {/* context chips — workspace of the row / systemId for workspace rows */}
                      <div className="mt-1.5 flex flex-wrap items-center gap-1.5" aria-label={t("trashColContext")}>
                        {systemId ? (
                          <span
                            dir="ltr"
                            className="inline-flex max-w-full items-center gap-1 rounded-full border border-violet-200 bg-violet-50 px-2 py-0.5 text-[10px] font-extrabold text-violet-600 dark:border-violet-500/25 dark:bg-violet-500/10 dark:text-violet-300"
                          >
                            <CatIcon name="globe" className="h-2.5 w-2.5 shrink-0" />
                            <span className="truncate">{systemId}</span>
                          </span>
                        ) : null}
                        {item.instanceId && item.instanceLabel ? (
                          <span
                            dir="auto"
                            className="inline-flex max-w-full items-center gap-1 rounded-full border border-slate-200 bg-slate-50 px-2 py-0.5 text-[10px] font-extrabold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300"
                          >
                            <CatIcon name="boxes" className="h-2.5 w-2.5 shrink-0" />
                            <span className="truncate">{item.instanceLabel}</span>
                          </span>
                        ) : null}
                      </div>

                      {/* deleted-by + deleted-at */}
                      <p className="mt-1 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                        {item.deletedByName ? (
                          <span className="inline-flex min-w-0 items-center gap-1">
                            <span className="shrink-0 text-slate-400 dark:text-slate-500">
                              {t("trashColDeletedBy")}:
                            </span>
                            <span dir="auto" className="truncate font-bold">
                              {item.deletedByName}
                            </span>
                          </span>
                        ) : null}
                        <span title={fullDate(item.deletedAt, lang)} dir="auto">
                          <span className="text-slate-400 dark:text-slate-500">{t("trashColDeletedAt")}: </span>
                          {relativeTime(item.deletedAt, lang)}
                        </span>
                      </p>

                      {/* deletion reason chip */}
                      {item.deleteReason ? (
                        <span
                          dir="auto"
                          title={t("trashReason")}
                          className="mt-1.5 inline-flex max-w-full items-center gap-1 rounded-full border border-rose-200 bg-rose-50 px-2 py-0.5 text-[10.5px] font-bold text-rose-600 dark:border-rose-500/25 dark:bg-rose-500/10 dark:text-rose-300"
                        >
                          <CatIcon name="circle-alert" className="h-3 w-3 shrink-0" />
                          <span className="truncate">
                            {t("trashReason")}: {item.deleteReason}
                          </span>
                        </span>
                      ) : null}
                    </div>

                    {/* end column — countdown + row actions */}
                    <div className="flex shrink-0 flex-col items-end gap-2">
                      <span
                        title={`${t("trashColExpires")} · ${fullDate(item.expiresAt, lang)}`}
                        className={cn(
                          "inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[11px] font-extrabold tabular-nums",
                          daysLeftTone(item.daysLeft),
                          item.daysLeft <= 7 && "animate-pulse"
                        )}
                        dir="auto"
                      >
                        <CatIcon name="hourglass" className="h-3 w-3 shrink-0" />
                        {daysText}
                      </span>
                      {item.daysLeft <= 7 ? (
                        <span className="text-[9.5px] font-extrabold text-rose-500 dark:text-rose-400">
                          {t("trashExpiringSoon")}
                        </span>
                      ) : null}

                      <div className="flex items-center gap-1.5" role="group" aria-label={t("trashColActions")}>
                        <Button
                          variant="outline"
                          size="sm"
                          disabled={rowLocked}
                          title={lockTitle}
                          onClick={() => setRestoreTarget(item)}
                          aria-label={t("trashRestore")}
                          className="h-8 rounded-xl border-emerald-200 bg-emerald-50 px-3 text-[11.5px] font-extrabold text-emerald-600 transition hover:bg-emerald-100 hover:text-emerald-700 active:scale-95 disabled:opacity-50 dark:border-emerald-500/25 dark:bg-emerald-500/10 dark:text-emerald-300 dark:hover:bg-emerald-500/20"
                        >
                          <CatIcon name="rotate-ccw" className="h-3.5 w-3.5" />
                          <span className="hidden md:inline">{t("trashRestore")}</span>
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          disabled={rowLocked}
                          title={lockTitle}
                          onClick={() => {
                            setPurgeTarget(item);
                            setConfirmText("");
                          }}
                          aria-label={t("trashPurge")}
                          className="h-8 rounded-xl border-transparent bg-rose-600 px-3 text-[11.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-50 dark:border-transparent dark:bg-rose-600 dark:hover:bg-rose-500"
                        >
                          <CatIcon name="trash-2" className="h-3.5 w-3.5" />
                          <span className="hidden md:inline">{t("trashPurge")}</span>
                        </Button>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ol>

            {/* client-side pagination — "load more" while rows remain hidden */}
            {visible < items.length ? (
              <div className="mt-4 flex justify-center">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setVisible((v) => v + PAGE_STEP)}
                  className="h-9 rounded-xl px-5 text-[12px] font-bold"
                >
                  <CatIcon name="chevron-down" className="h-3.5 w-3.5" />
                  {t("trashLoadMore")}
                </Button>
              </div>
            ) : null}
          </>
        )}
      </DashCard>

      {/* floating bulk-action bar — appears while rows are selected */}
      {canManage && selected.size > 0 ? (
        <div
          role="toolbar"
          aria-label={t("trashTitle")}
          className="fixed bottom-5 left-1/2 z-50 w-[min(92vw,640px)] -translate-x-1/2 animate-in slide-in-from-bottom-4 fade-in rounded-2xl border border-slate-200/80 bg-white/95 p-2.5 shadow-2xl shadow-slate-900/15 backdrop-blur-xl dark:border-white/10 dark:bg-[#0b1220]/95 dark:shadow-black/40"
        >
          <div className="flex flex-wrap items-center gap-2">
            <span className="ms-1 inline-flex shrink-0 items-center gap-1.5 rounded-xl bg-brand-500/10 px-3 py-1.5 text-[12px] font-extrabold text-brand-600 dark:text-brand-300">
              <CatIcon name="check-check" className="h-[13px] w-[13px]" />
              {t("trashSelected", { n: fmtNum(selected.size, lang) })}
            </span>
            <span className="hidden h-6 w-px shrink-0 bg-slate-200 sm:block dark:bg-white/10" aria-hidden="true" />

            <button
              type="button"
              onClick={() => void runBulk("restore")}
              disabled={bulkPending}
              className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-emerald-200 bg-emerald-50 px-3 text-[11.5px] font-extrabold text-emerald-600 transition hover:bg-emerald-100 active:scale-95 disabled:opacity-50 dark:border-emerald-500/25 dark:bg-emerald-500/10 dark:text-emerald-300 dark:hover:bg-emerald-500/20"
            >
              <CatIcon name="rotate-ccw" className="h-[13px] w-[13px]" />
              {t("trashBulkRestore")}
            </button>
            <button
              type="button"
              onClick={() => void runBulk("purge")}
              disabled={bulkPending}
              className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-rose-300 bg-rose-600 px-3 text-[11.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-50"
            >
              <CatIcon name={bulkPending ? "refresh-cw" : "trash-2"} className={cn("h-[13px] w-[13px]", bulkPending && "animate-spin")} />
              {t("trashBulkPurge")}
            </button>

            <button
              type="button"
              onClick={() => setSelected(new Set())}
              disabled={bulkPending}
              className="ms-auto inline-flex h-9 items-center gap-1.5 rounded-xl px-3 text-[11.5px] font-extrabold text-slate-500 transition hover:bg-slate-100 active:scale-95 disabled:opacity-50 dark:text-slate-400 dark:hover:bg-white/[0.06]"
            >
              <CatIcon name="x" className="h-[13px] w-[13px]" />
              {t("trashClearSel")}
            </button>
          </div>
        </div>
      ) : null}

      {/* restore confirm */}
      <AlertDialog
        open={restoreTarget !== null}
        onOpenChange={(o) => {
          if (!o) setRestoreTarget(null);
        }}
      >
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg shadow-emerald-500/25"
                style={{ backgroundImage: grad("#10b981", "#059669") }}
                aria-hidden="true"
              >
                <CatIcon name="rotate-ccw" className="h-[15px] w-[15px]" />
              </span>
              {t("trashRestoreConfirmTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {restoreTarget ? t("trashRestoreConfirmDesc", { label: restoreTarget.label }) : null}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={restore.isPending}>
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (restoreTarget) restore.mutate(restoreTarget);
              }}
              disabled={restore.isPending}
              className="h-10 rounded-xl bg-emerald-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:bg-emerald-700 active:scale-95 disabled:opacity-60"
            >
              {restore.isPending ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : null}
              {t("trashRestoreConfirmAction")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* purge confirm — STRICT type-to-confirm */}
      <AlertDialog
        open={purgeTarget !== null}
        onOpenChange={(o) => {
          if (!o) {
            setPurgeTarget(null);
            setConfirmText("");
          }
        }}
      >
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg shadow-rose-500/25"
                style={{ backgroundImage: grad("#f43f5e", "#be123c") }}
                aria-hidden="true"
              >
                <CatIcon name="trash-2" className="h-[15px] w-[15px]" />
              </span>
              {t("trashPurgeConfirmTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {purgeTarget ? t("trashPurgeConfirmDesc", { label: purgeTarget.label }) : null}
            </AlertDialogDescription>
          </AlertDialogHeader>

          <div className="space-y-1.5">
            <label
              htmlFor="trash-purge-confirm-word"
              className="block text-[12px] font-extrabold text-rose-600 dark:text-rose-300"
              dir="auto"
            >
              {t("trashConfirmType", { word: t("trashConfirmWord") })}
            </label>
            <Input
              id="trash-purge-confirm-word"
              value={confirmText}
              onChange={(e) => setConfirmText(e.target.value)}
              placeholder={t("trashConfirmWord")}
              dir="auto"
              autoComplete="off"
              className="h-10 rounded-xl text-[13px] font-extrabold"
            />
          </div>

          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={purge.isPending}>
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (purgeTarget && confirmReady) purge.mutate(purgeTarget);
              }}
              disabled={purge.isPending || !confirmReady}
              className="h-10 rounded-xl bg-rose-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60"
            >
              {purge.isPending ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : null}
              {t("trashPurgeConfirmAction")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default AdminTrash;
