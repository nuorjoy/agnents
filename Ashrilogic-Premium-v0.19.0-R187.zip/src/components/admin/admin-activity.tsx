"use client";

/**
 * ROUND 65 — admin activity stream (premium rebuild).
 *
 * Every system event across ALL instances in one live feed, served by the
 * new keyset-paginated /api/admin/activities route: a KPI strip (platform
 * total / today / last 7 days / active organizations), a search +
 * kind-filter + org-filter + CSV-export toolbar, and a grouped vertical
 * timeline (today / yesterday / earlier) where each row carries the
 * originating org as a chip and the catalog system in its meta line.
 * Visual language is shared with the owner-side activity view
 * (ACT_STYLE tiles, ActKpi cards, day-grouped timeline) so both consoles
 * feel like one product.
 */
import { useMemo, useState } from "react";
import { useInfiniteQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { useT, type I18nKey, t as tt } from "@/lib/i18n";
import type { ActivityKind, AdminActivityDTO, Lang } from "@/lib/types";
import { fetchAdminActivitiesPage } from "@/lib/api-client";
import { SYSTEM_MAP } from "@/data/catalog";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, normalizeSearch } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ACT_STYLE,
  DashCard,
  IconTile,
  ViewHeading,
  fullDate,
  relativeTime,
} from "@/components/dashboard/dash-shared";

/** Ordered activity kinds (ACT_STYLE keys double as i18n kind labels). */
const KINDS = Object.keys(ACT_STYLE) as ActivityKind[];

type KindFilter = "all" | ActivityKind;

/** Org filter value: "all" or the originating instance id. */
type OrgFilter = "all" | string;

type GroupKey = "today" | "yesterday" | "earlier";

const GROUP_LABEL: Record<GroupKey, I18nKey> = {
  today: "actGroupToday",
  yesterday: "actGroupYesterday",
  earlier: "actGroupEarlier",
};

/** Calendar-day bucket for the timeline groups. */
function dayBucket(iso: string): GroupKey {
  const at = new Date(iso);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  if (at >= today) return "today";
  if (at >= yesterday) return "yesterday";
  return "earlier";
}

/** Catalog display name + icon for a system id (house i18n idiom:
 *  Arabic readers get nameAr, everyone else nameEn; unknown ids fall back
 *  to the raw slug so the row never loses its provenance). */
function systemOf(systemId: string, lang: Lang): { name: string; icon: string } {
  const sys = SYSTEM_MAP[systemId];
  return {
    name: sys ? (lang === "ar" ? sys.nameAr : sys.nameEn) : systemId,
    icon: sys?.icon ?? "layers",
  };
}

/* ---------------- KPI card (owner-side ActKpi twin) ---------------- */

function ActKpi({
  title,
  value,
  chip,
  icon,
  c1,
  c2,
  index,
  loading,
  small,
}: {
  title: string;
  value: string;
  chip?: React.ReactNode;
  icon: string;
  c1: string;
  c2: string;
  index: number;
  loading?: boolean;
  /** label-valued KPI renders slightly smaller to stay balanced */
  small?: boolean;
}) {
  return (
    <article
      className="glass-card card-in group relative overflow-hidden rounded-3xl p-4 transition-shadow duration-300 hover:shadow-lift sm:p-5"
      style={{ "--i": index } as React.CSSProperties}
    >
      {/* gradient top hairline, brightens on hover */}
      <span
        className="pointer-events-none absolute inset-x-0 top-0 h-[2px] opacity-50 transition-opacity duration-300 group-hover:opacity-100"
        style={{ backgroundImage: grad(c1, c2, 90) }}
        aria-hidden="true"
      />
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            {title}
          </p>
          {loading ? (
            <Skeleton className="mt-2.5 h-8 w-16" />
          ) : (
            <p
              className={cn(
                "mt-1.5 font-display font-extrabold text-slate-900 dark:text-white",
                small ? "line-clamp-2 text-xl leading-snug" : "text-3xl"
              )}
            >
              {value}
            </p>
          )}
          {chip && !loading ? chip : null}
        </div>
        <IconTile icon={icon} c1={c1} c2={c2} size="lg" />
      </div>
    </article>
  );
}

/* ---------------- ROUND 71 — analytics strip ---------------- */

/** One kind row in the Event Mix card — icon tile + label + proportional
 *  gradient bar; clicking the row TOGGLES the timeline's kind filter
 *  (drill-down), the active row gets the brand ring + check chip. Twin of
 *  the owner-side strip so both consoles feel like one product. */
function KindMixRow({
  kind,
  count,
  share,
  active,
  onClick,
  lang,
}: {
  kind: ActivityKind;
  count: number;
  share: number;
  active: boolean;
  onClick: () => void;
  lang: Lang;
}) {
  const style = ACT_STYLE[kind];
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      title={tt(lang, "actMixBarHint", { count: fmtNum(count, lang) })}
      className={cn(
        "group/mix flex w-full items-center gap-3 rounded-xl px-2.5 py-2 text-start transition active:scale-[0.99]",
        active
          ? "bg-brand-500/10 ring-1 ring-brand-400/60 dark:bg-brand-500/15 dark:ring-brand-500/40"
          : "hover:bg-slate-100/70 dark:hover:bg-white/[0.05]"
      )}
    >
      <span
        className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-white shadow-sm transition-transform duration-200 group-hover/mix:scale-110"
        style={{ backgroundImage: grad(style.c1, style.c2) }}
        aria-hidden="true"
      >
        <CatIcon name={style.icon} className="h-3 w-3" />
      </span>
      <span className="min-w-0 flex-1">
        <span className="flex items-baseline justify-between gap-2">
          <span className="truncate text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200">
            {tt(lang, kind)}
          </span>
          <span className="shrink-0 text-[11px] font-extrabold tabular-nums text-slate-400 dark:text-slate-500">
            {fmtNum(count, lang)}
          </span>
        </span>
        <span className="mt-1.5 block h-1.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/[0.06]">
          <span
            className="block h-full rounded-full transition-[width] duration-500 ease-out"
            style={{ width: `${Math.max(share * 100, 3)}%`, backgroundImage: grad(style.c1, style.c2) }}
            aria-hidden="true"
          />
        </span>
      </span>
      {active ? (
        <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-brand-500/15 px-2 py-0.5 text-[9.5px] font-extrabold text-brand-600 dark:text-brand-300">
          <CatIcon name="check" className="h-2.5 w-2.5" />
        </span>
      ) : null}
    </button>
  );
}

/** 24-hour activity histogram — 12 two-hour buckets, gradient columns,
 *  peak bucket crowned + pulsing. Hour labels locale-aware (Arabic-Indic
 *  in AR). Owner-side twin. */
function HourHistogram({ events, lang }: { events: AdminActivityDTO[]; lang: Lang }) {
  const BUCKETS = 12;
  const bucketCounts = useMemo(() => {
    const arr = new Array<number>(BUCKETS).fill(0);
    for (const ev of events) {
      const h = new Date(ev.createdAt).getHours();
      arr[Math.floor(h / 2)] += 1;
    }
    return arr;
  }, [events]);
  const max = Math.max(...bucketCounts, 1);
  const peakIdx = bucketCounts.indexOf(Math.max(...bucketCounts));
  const hasData = events.length > 0;

  const hourLabel = (bucket: number) => {
    const h = bucket * 2;
    return `${fmtNum(h, lang)}–${fmtNum(h + 2, lang)}`;
  };

  if (!hasData) {
    return (
      <p className="py-6 text-center text-[11.5px] font-bold text-slate-400 dark:text-slate-500">
        {tt(lang, "actNoMixData")}
      </p>
    );
  }

  return (
    <div className="flex items-end gap-1.5 pt-1" role="img" aria-label={tt(lang, "actHotHoursDesc")}>
      {bucketCounts.map((count, i) => {
        const isPeak = i === peakIdx && count > 0;
        const ratio = count / max;
        return (
          <div key={i} className="group/hour flex min-w-0 flex-1 flex-col items-center gap-1.5">
            <span
              className={cn(
                "text-[9px] font-extrabold tabular-nums transition-opacity",
                isPeak ? "text-amber-600 dark:text-amber-400" : "text-slate-300 opacity-0 dark:text-slate-600"
              )}
            >
              {fmtNum(count, lang)}
            </span>
            <span
              className={cn(
                "w-full rounded-t-md transition-all duration-300 group-hover/hour:brightness-110",
                count === 0 && "bg-slate-100 dark:bg-white/[0.06]",
                isPeak && "animate-pulse"
              )}
              style={
                count > 0
                  ? {
                      height: `${Math.max(ratio * 56, 6)}px`,
                      backgroundImage: isPeak
                        ? grad("#f59e0b", "#d97706")
                        : grad("#6d5dfb", "#a855f7"),
                    }
                  : { height: "6px" }
              }
              title={`${hourLabel(i)} · ${fmtNum(count, lang)}`}
              aria-hidden="true"
            />
            <span className="text-[8.5px] font-bold tabular-nums text-slate-400 dark:text-slate-500" dir="ltr">
              {hourLabel(i)}
            </span>
          </div>
        );
      })}
    </div>
  );
}

/** One org row in the Top Organizations card — emerald accent (matches the
 *  toolbar's emerald org-filter chip) so the color carries meaning: brand =
 *  kind, emerald = organization. Clicking the row toggles the org filter. */
function OrgMixRow({
  name,
  count,
  share,
  active,
  onClick,
  lang,
}: {
  name: string;
  count: number;
  share: number;
  active: boolean;
  onClick: () => void;
  lang: Lang;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      title={tt(lang, "actMixOrgHint", { count: fmtNum(count, lang) })}
      className={cn(
        "group/org flex w-full items-center gap-3 rounded-xl px-2.5 py-2 text-start transition active:scale-[0.99]",
        active
          ? "bg-emerald-500/10 ring-1 ring-emerald-400/60 dark:bg-emerald-500/15 dark:ring-emerald-500/40"
          : "hover:bg-slate-100/70 dark:hover:bg-white/[0.05]"
      )}
    >
      <span
        className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-linear-to-br from-emerald-500 to-teal-600 text-white shadow-sm transition-transform duration-200 group-hover/org:scale-110"
        aria-hidden="true"
      >
        <CatIcon name="building" className="h-3 w-3" />
      </span>
      <span className="min-w-0 flex-1">
        <span className="flex items-baseline justify-between gap-2">
          <span className="truncate text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200" dir="auto">
            {name}
          </span>
          <span className="shrink-0 text-[11px] font-extrabold tabular-nums text-slate-400 dark:text-slate-500">
            {fmtNum(count, lang)}
          </span>
        </span>
        <span className="mt-1.5 block h-1.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/[0.06]">
          <span
            className="block h-full rounded-full bg-linear-to-r from-emerald-500 to-teal-500 transition-[width] duration-500 ease-out"
            style={{ width: `${Math.max(share * 100, 3)}%` }}
            aria-hidden="true"
          />
        </span>
      </span>
      {active ? (
        <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-emerald-500/15 px-2 py-0.5 text-[9.5px] font-extrabold text-emerald-600 dark:text-emerald-300">
          <CatIcon name="check" className="h-2.5 w-2.5" />
        </span>
      ) : null}
    </button>
  );
}

/* ---------------- view ---------------- */

export function AdminActivity() {
  const { t, lang } = useT();

  const [search, setSearch] = useState("");
  const [kindFilter, setKindFilter] = useState<KindFilter>("all");
  const [orgFilter, setOrgFilter] = useState<OrgFilter>("all");

  /* ROUND 65 — admin-wide keyset feed: pages are stable under concurrent
   * inserts (the cursor resumes strictly after the last seen row). The
   * server `total` powers the honest platform "total" KPI and the
   * envelope's `orgs` powers both the org filter and the active-orgs KPI. */
  const PAGE_SIZE = 20;
  const feed = useInfiniteQuery({
    queryKey: ["admin-activities-feed", PAGE_SIZE],
    queryFn: ({ pageParam }) =>
      fetchAdminActivitiesPage({ limit: PAGE_SIZE, cursor: pageParam }),
    initialPageParam: null as string | null,
    getNextPageParam: (lastPage) => lastPage.nextCursor,
    staleTime: 15_000,
    retry: 0,
  });

  const query = feed;
  const events = useMemo(
    () => feed.data?.pages.flatMap((p) => p.activities) ?? [],
    [feed.data]
  );
  /* every page carries the full envelope scalars — page 0 is authoritative */
  const serverTotal = feed.data?.pages[0]?.total ?? 0;
  const orgs = useMemo(
    () => (feed.data?.pages[0]?.orgs ?? []).filter((o) => o.name !== ""),
    [feed.data]
  );

  /* KPI stats over the loaded window — independent of the toolbar filters. */
  const stats = useMemo(() => {
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const weekStart = Date.now() - 7 * 86_400_000;
    let today = 0;
    let week = 0;
    for (const ev of events) {
      const ts = new Date(ev.createdAt).getTime();
      if (ts >= todayStart.getTime()) today += 1;
      if (ts >= weekStart) week += 1;
    }
    return { today, week };
  }, [events]);

  /* ROUND 71 — kind + org mix over the LOADED window (independent of the
   * toolbar filters) so the strip doubles as a live distribution snapshot;
   * clicking a row toggles the matching timeline filter (drill-down). */
  const kindMix = useMemo(() => {
    const counts = new Map<ActivityKind, number>();
    for (const ev of events) counts.set(ev.kind, (counts.get(ev.kind) ?? 0) + 1);
    const total = events.length;
    return [...counts.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8)
      .map(([kind, count]) => ({ kind, count, share: total > 0 ? count / total : 0 }));
  }, [events]);

  const orgMix = useMemo(() => {
    const counts = new Map<string, number>();
    for (const ev of events) {
      const name = ev.orgName.trim();
      if (!name) continue;
      counts.set(name, (counts.get(name) ?? 0) + 1);
    }
    const total = events.length;
    return [...counts.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6)
      .map(([name, count]) => ({ name, count, share: total > 0 ? count / total : 0 }));
  }, [events]);

  /* Toolbar filtering: kind label + meta values + org name + system name
   * (Arabic-safe normalization). */
  const normalizedQuery = normalizeSearch(search.trim());
  const filtered = useMemo(() => {
    let list = events ?? [];
    if (kindFilter !== "all") list = list.filter((ev) => ev.kind === kindFilter);
    if (orgFilter !== "all") list = list.filter((ev) => ev.instanceId === orgFilter);
    if (normalizedQuery) {
      list = list.filter((ev) => {
        const sys = systemOf(ev.systemId, lang).name;
        const haystack = [t(ev.kind), ev.orgName, sys, ...Object.values(ev.meta ?? {})];
        return normalizeSearch(haystack.join(" ")).includes(normalizedQuery);
      });
    }
    return [...list].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }, [events, kindFilter, orgFilter, normalizedQuery, t, lang]);

  /* Timeline groups (newest first) with their counts. */
  const groups = useMemo(() => {
    const buckets: Record<GroupKey, AdminActivityDTO[]> = { today: [], yesterday: [], earlier: [] };
    for (const ev of filtered) buckets[dayBucket(ev.createdAt)].push(ev);
    return (["today", "yesterday", "earlier"] as const)
      .filter((key) => buckets[key].length > 0)
      .map((key) => ({ key, label: t(GROUP_LABEL[key]), items: buckets[key] }));
  }, [filtered, t]);

  const kindCount =
    kindFilter === "all" ? 0 : (events ?? []).filter((ev) => ev.kind === kindFilter).length;
  const orgCount =
    orgFilter === "all" ? 0 : (events ?? []).filter((ev) => ev.instanceId === orgFilter).length;
  const orgName = orgFilter === "all" ? "" : orgs.find((o) => o.id === orgFilter)?.name ?? "";
  const filtersActive =
    kindFilter !== "all" || orgFilter !== "all" || normalizedQuery !== "";

  const clearFilters = () => {
    setKindFilter("all");
    setOrgFilter("all");
    setSearch("");
  };

  /* KPI value: skeleton while pending, em-dash when the fetch failed.
   * The "total" KPI is the SERVER platform count; the active-orgs KPI is
   * the envelope's full-feed distinct org list. */
  const kpiValue = (n: number) => (query.isError ? "—" : fmtNum(n, lang));
  const totalKpi = query.isPending ? "" : kpiValue(serverTotal);
  const orgsKpi = query.isPending ? "" : kpiValue(orgs.length);

  /* Client-side CSV export of the filtered events (BOM + RFC quoting). */
  const exportCsv = () => {
    if (filtered.length === 0) return;
    const esc = (v: unknown) => {
      const s = String(v ?? "");
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const rows = [
      ["kind", "org", "system", "meta", "createdAt"],
      ...filtered.map((ev) => [
        ev.kind,
        ev.orgName,
        systemOf(ev.systemId, lang).name,
        ev.meta && Object.keys(ev.meta).length > 0 ? JSON.stringify(ev.meta) : "",
        ev.createdAt,
      ]),
    ];
    const csv = rows.map((r) => r.map(esc).join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "ashrilogic-admin-activities.csv";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success(t("adminExportDone"));
  };

  return (
    <div className="space-y-5">
      <ViewHeading title={t("adminActivity")} desc={t("actAdminDesc")} />

      {/* KPI strip */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <ActKpi
          title={t("actKpiTotal")}
          value={totalKpi}
          icon="activity"
          c1="#6d5dfb"
          c2="#8b5cf6"
          index={0}
          loading={query.isPending}
        />
        <ActKpi
          title={t("actKpiToday")}
          value={kpiValue(stats.today)}
          icon="calendar-check"
          c1="#06b6d4"
          c2="#0891b2"
          index={1}
          loading={query.isPending}
        />
        <ActKpi
          title={t("actKpiWeek")}
          value={kpiValue(stats.week)}
          icon="timer"
          c1="#d946ef"
          c2="#c026d3"
          index={2}
          loading={query.isPending}
        />
        <ActKpi
          title={t("actKpiOrgs")}
          value={orgsKpi}
          icon="building"
          c1="#10b981"
          c2="#059669"
          index={3}
          loading={query.isPending}
        />
      </div>

      {/* ROUND 71 — analytics strip: interactive kind mix + peak-hours
          histogram + top-organizations bars. Three premium cards that
          double as drill-down filters for the timeline (stack on mobile). */}
      {query.isPending ? (
        <div className="grid gap-4 lg:grid-cols-2 xl:grid-cols-3">
          <Skeleton className="h-64 rounded-3xl" />
          <Skeleton className="h-64 rounded-3xl" />
          <Skeleton className="h-64 rounded-3xl" />
        </div>
      ) : !query.isError && events.length > 0 ? (
        <div className="grid gap-4 lg:grid-cols-2 xl:grid-cols-3">
          <DashCard title={t("actMixTitle")} icon="chart-bar">
            <p className="-mt-2 mb-1 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
              {t("actMixDesc")}
            </p>
            <ul className="space-y-0.5">
              {kindMix.map(({ kind, count, share }) => (
                <li key={kind}>
                  <KindMixRow
                    kind={kind}
                    count={count}
                    share={share}
                    active={kindFilter === kind}
                    lang={lang}
                    onClick={() => setKindFilter(kindFilter === kind ? "all" : kind)}
                  />
                </li>
              ))}
            </ul>
          </DashCard>
          <DashCard title={t("actHotHours")} icon="clock">
            <p className="-mt-2 mb-2 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
              {t("actHotHoursDesc")}
            </p>
            <HourHistogram events={events} lang={lang} />
          </DashCard>
          <DashCard title={t("actTopOrgs")} icon="building">
            <p className="-mt-2 mb-1 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
              {t("actTopOrgsDesc")}
            </p>
            <ul className="space-y-0.5">
              {orgMix.map(({ name, count, share }) => (
                <li key={name}>
                  <OrgMixRow
                    name={name}
                    count={count}
                    share={share}
                    active={orgFilter !== "all" && orgName === name}
                    lang={lang}
                    onClick={() => setOrgFilter(orgName === name ? "all" : orgs.find((o) => o.name === name)?.id ?? "all")}
                  />
                </li>
              ))}
            </ul>
          </DashCard>
        </div>
      ) : null}

      {/* toolbar: search + kind filter + org filter + export */}
      <div className="glass-card card-in rounded-3xl p-4 sm:p-5">
        <div className="flex flex-col gap-3 xl:flex-row xl:items-center">
          <div className="relative min-w-0 flex-1">
            <CatIcon
              name="search"
              className="pointer-events-none absolute start-3.5 top-1/2 h-[13px] w-[13px] -translate-y-1/2 text-slate-400"
            />
            <Input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t("actSearchPh")}
              aria-label={t("actSearchPh")}
              className="h-11 rounded-xl border-slate-200 bg-slate-50/80 ps-10 pe-3 text-[12.5px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:placeholder:text-slate-500 dark:focus:bg-white/[0.07]"
            />
          </div>

          <Select value={kindFilter} onValueChange={(v) => setKindFilter(v as KindFilter)}>
            <SelectTrigger
              aria-label={t("actViewKind")}
              className="h-11 w-full rounded-xl border-slate-200 bg-slate-50/80 px-3.5 text-[12.5px] font-semibold text-slate-800 transition hover:border-brand-300 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:hover:border-brand-500/40 lg:w-48"
            >
              <span className="flex min-w-0 items-center gap-2">
                <CatIcon name="filter" className="h-3.5 w-3.5 shrink-0 text-slate-400" />
                <SelectValue />
              </span>
            </SelectTrigger>
            <SelectContent>
              <SelectGroup>
                <SelectItem value="all">{t("actFilterAll")}</SelectItem>
                {KINDS.map((kind) => (
                  <SelectItem key={kind} value={kind}>
                    {t(kind)}
                  </SelectItem>
                ))}
              </SelectGroup>
            </SelectContent>
          </Select>

          <Select value={orgFilter} onValueChange={(v) => setOrgFilter(v)}>
            <SelectTrigger
              aria-label={t("actFilterOrg")}
              className="h-11 w-full rounded-xl border-slate-200 bg-slate-50/80 px-3.5 text-[12.5px] font-semibold text-slate-800 transition hover:border-brand-300 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:hover:border-brand-500/40 lg:w-56"
            >
              <span className="flex min-w-0 items-center gap-2">
                <CatIcon name="building" className="h-3.5 w-3.5 shrink-0 text-slate-400" />
                <span className="truncate">
                  {orgFilter === "all" ? t("actAllOrgs") : orgName || t("actAllOrgs")}
                </span>
              </span>
            </SelectTrigger>
            <SelectContent>
              <SelectGroup>
                <SelectItem value="all">{t("actAllOrgs")}</SelectItem>
                {orgs.map((o) => (
                  <SelectItem key={o.id} value={o.id}>
                    {o.name}
                  </SelectItem>
                ))}
              </SelectGroup>
            </SelectContent>
          </Select>

          <Button
            type="button"
            variant="outline"
            onClick={exportCsv}
            disabled={filtered.length === 0}
            className="h-11 shrink-0 gap-2 rounded-xl border-slate-200 bg-white px-5 text-[12.5px] font-extrabold text-slate-700 shadow-none transition hover:border-brand-300 hover:text-brand-600 disabled:opacity-40 dark:border-white/10 dark:bg-transparent dark:text-slate-200 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
          >
            <CatIcon name="download" className="h-4 w-4" />
            {t("actExport")}
          </Button>
        </div>

        {/* active filter chips (kind + org) */}
        {kindFilter !== "all" || orgFilter !== "all" ? (
          <div className="mt-3 flex flex-wrap items-center gap-2">
            {kindFilter !== "all" ? (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-brand-200 bg-brand-500/10 py-1 pe-1.5 ps-3 text-[11px] font-extrabold text-brand-700 dark:border-brand-500/30 dark:bg-brand-500/15 dark:text-brand-300">
                <CatIcon name="filter" className="h-3 w-3" />
                {t("actSelectedFilter")}: {t(kindFilter)}
                <span className="rounded-full bg-white/70 px-1.5 py-0.5 text-[10px] font-extrabold text-brand-600 dark:bg-white/10 dark:text-brand-300">
                  {fmtNum(kindCount, lang)}
                </span>
                <button
                  type="button"
                  onClick={() => setKindFilter("all")}
                  aria-label={t("actClearFilter")}
                  title={t("actClearFilter")}
                  className="grid h-6 w-6 place-items-center rounded-full text-brand-500 transition hover:bg-brand-500/20 hover:text-brand-700 dark:hover:text-brand-200"
                >
                  <CatIcon name="x" className="h-3 w-3" />
                </button>
              </span>
            ) : null}
            {orgFilter !== "all" ? (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-500/10 py-1 pe-1.5 ps-3 text-[11px] font-extrabold text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/15 dark:text-emerald-300">
                <CatIcon name="building" className="h-3 w-3" />
                {t("actFilterOrg")}: {orgName}
                <span className="rounded-full bg-white/70 px-1.5 py-0.5 text-[10px] font-extrabold text-emerald-600 dark:bg-white/10 dark:text-emerald-300">
                  {fmtNum(orgCount, lang)}
                </span>
                <button
                  type="button"
                  onClick={() => setOrgFilter("all")}
                  aria-label={t("actClearFilter")}
                  title={t("actClearFilter")}
                  className="grid h-6 w-6 place-items-center rounded-full text-emerald-500 transition hover:bg-emerald-500/20 hover:text-emerald-700 dark:hover:text-emerald-200"
                >
                  <CatIcon name="x" className="h-3 w-3" />
                </button>
              </span>
            ) : null}
          </div>
        ) : null}
      </div>

      {/* timeline */}
      <DashCard
        title={t("actTimeline")}
        icon="history"
        action={
          query.isError ? (
            <Button
              variant="outline"
              size="sm"
              onClick={() => query.refetch()}
              className="h-7 rounded-lg text-[11px] font-bold"
            >
              <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
              {t("retryText")}
            </Button>
          ) : !query.isPending && events && events.length > 0 ? (
            <Badge
              variant="secondary"
              className="rounded-full px-3 py-1 text-[11px] font-extrabold text-slate-600 dark:text-slate-300"
              title={t("actLoadedHint", { loaded: fmtNum(events.length, lang), total: fmtNum(serverTotal, lang) })}
            >
              {fmtNum(filtered.length, lang)} / {fmtNum(events.length, lang)}
            </Badge>
          ) : null
        }
      >
        {/* live count announcement for assistive tech */}
        <p className="sr-only" aria-live="polite">
          {t("actKpiTotal")}: {fmtNum(filtered.length, lang)}
        </p>

        {query.isPending ? (
          <div className="space-y-1" aria-hidden="true">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3 rounded-2xl p-3">
                <Skeleton className="h-10 w-10 rounded-xl" />
                <div className="flex-1 space-y-1.5">
                  <Skeleton className="h-3.5 w-44" />
                  <Skeleton className="h-2.5 w-28" />
                </div>
                <Skeleton className="h-2.5 w-20" />
              </div>
            ))}
          </div>
        ) : query.isError ? (
          <div className="py-10 text-center">
            <p className="text-[13px] font-bold text-rose-600 dark:text-rose-400">{t("errorText")}</p>
            <Button
              variant="outline"
              onClick={() => query.refetch()}
              className="mt-3 h-10 rounded-xl px-5 text-[12.5px] font-bold"
            >
              <CatIcon name="refresh-cw" className="h-4 w-4" />
              {t("retryText")}
            </Button>
          </div>
        ) : groups.length === 0 ? (
          <div className="py-12 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
              <CatIcon name="clock-rotate-left" className="h-6 w-6" />
            </div>
            <h3 className="mt-4 font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
              {t("actEmpty")}
            </h3>
            <p className="mx-auto mt-1 max-w-sm text-[12.5px] text-slate-500 dark:text-slate-400">
              {t("actEmptyDesc")}
            </p>
            {filtersActive ? (
              <Button
                variant="outline"
                onClick={clearFilters}
                className="mt-4 h-9 gap-2 rounded-xl px-4 text-[12px] font-bold"
              >
                <CatIcon name="x" className="h-3.5 w-3.5" />
                {t("actClearFilter")}
              </Button>
            ) : null}
          </div>
        ) : (
          <div className="max-h-[600px] overflow-y-auto pe-1" role="log" aria-label={t("actTimeline")}>
            {groups.map((group) => (
              <section key={group.key} aria-label={group.label}>
                {/* sticky group header */}
                <div className="sticky top-0 z-20 flex items-center gap-2 bg-white/85 px-1 py-2 backdrop-blur-sm dark:bg-[#101828]/90">
                  <h3 className="text-[10.5px] font-extrabold uppercase tracking-[0.12em] text-slate-400 dark:text-slate-500">
                    {group.label}
                  </h3>
                  <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-extrabold text-slate-500 dark:bg-white/10 dark:text-slate-400">
                    {fmtNum(group.items.length, lang)}
                  </span>
                  <span className="h-px flex-1 bg-slate-100 dark:bg-white/[0.06]" aria-hidden="true" />
                </div>

                <ol className="space-y-1 pb-2">
                  {group.items.map((ev, i) => {
                    const style = ACT_STYLE[ev.kind];
                    const sys = systemOf(ev.systemId, lang);
                    const last = i === group.items.length - 1;
                    return (
                      <li
                        key={ev.id}
                        className="relative flex gap-3 rounded-2xl p-3 transition hover:bg-slate-50 dark:hover:bg-white/5"
                      >
                        {/* vertical connector: this tile center → next tile center */}
                        {!last ? (
                          <span
                            aria-hidden="true"
                            className="absolute top-[32px] h-[calc(100%_+_4px)] w-0.5 bg-slate-200 start-[31px] dark:bg-white/10"
                          />
                        ) : null}
                        <span
                          className="relative grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white"
                          style={{ backgroundImage: grad(style.c1, style.c2) }}
                        >
                          <CatIcon name={style.icon} className="h-[13px] w-[13px]" />
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                            <p className="text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                              {t(ev.kind)}
                            </p>
                            {/* originating org chip */}
                            {ev.orgName ? (
                              <span
                                className="inline-flex max-w-[200px] items-center gap-1 rounded-full border border-brand-200/70 bg-brand-500/10 px-2 py-0.5 text-[10px] font-extrabold text-brand-700 dark:border-brand-500/25 dark:bg-brand-500/15 dark:text-brand-300"
                                dir="auto"
                              >
                                <CatIcon name="building" className="h-2.5 w-2.5 shrink-0" />
                                <span className="truncate">{ev.orgName}</span>
                              </span>
                            ) : null}
                          </div>
                          {/* meta line: system identity + first meta entries */}
                          <div className="mt-1 flex flex-wrap gap-1.5">
                            <span
                              className="inline-flex max-w-[220px] items-center gap-1 rounded-full border border-slate-200 bg-white/70 px-2 py-0.5 text-[10px] font-extrabold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300"
                              dir="auto"
                              title={sys.name}
                            >
                              <CatIcon name={sys.icon} className="h-2.5 w-2.5 shrink-0 text-slate-400" />
                              <span className="truncate">{sys.name}</span>
                            </span>
                            {Object.entries(ev.meta ?? {})
                              .slice(0, 3)
                              .map(([k, v]) => (
                                <span
                                  key={k}
                                  className="rounded-full border border-slate-200 bg-slate-50 px-2 py-0.5 text-[10px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-400"
                                  dir="auto"
                                >
                                  {k}: {v}
                                </span>
                              ))}
                          </div>
                          <p
                            className="mt-1 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500"
                            dir="auto"
                          >
                            {fullDate(ev.createdAt, lang)} · {relativeTime(ev.createdAt, lang)}
                          </p>
                        </div>
                      </li>
                    );
                  })}
                </ol>
              </section>
            ))}

            {/* keyset load-more: stable under concurrent inserts */}
            {feed.hasNextPage ? (
              <div className="flex flex-col items-center gap-2 border-t border-dashed border-slate-200 pb-1 pt-4 dark:border-white/10">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => feed.fetchNextPage()}
                  disabled={feed.isFetchingNextPage}
                  className="h-10 gap-2 rounded-xl border-slate-200 bg-white px-6 text-[12.5px] font-extrabold text-slate-600 shadow-none transition hover:border-brand-300 hover:text-brand-600 active:scale-95 disabled:opacity-60 dark:border-white/10 dark:bg-transparent dark:text-slate-200 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
                >
                  <CatIcon
                    name="chevron-down"
                    className={cn("h-4 w-4 transition-transform", feed.isFetchingNextPage && "animate-bounce")}
                  />
                  {feed.isFetchingNextPage ? t("actLoadingMore") : t("actLoadMore")}
                </Button>
                <p className="text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                  {t("actLoadedHint", {
                    loaded: fmtNum(events.length, lang),
                    total: fmtNum(serverTotal, lang),
                  })}
                </p>
              </div>
            ) : events.length > 0 ? (
              <div className="flex items-center justify-center gap-2 border-t border-dashed border-slate-200 pt-3 dark:border-white/10">
                <span className="h-1.5 w-1.5 rounded-full bg-slate-300 dark:bg-white/20" aria-hidden="true" />
                <p className="text-[10.5px] font-extrabold text-slate-400 dark:text-slate-500">
                  {t("actEndOfFeed")}
                </p>
                <span className="h-1.5 w-1.5 rounded-full bg-slate-300 dark:bg-white/20" aria-hidden="true" />
              </div>
            ) : null}
          </div>
        )}
      </DashCard>
    </div>
  );
}

export default AdminActivity;
