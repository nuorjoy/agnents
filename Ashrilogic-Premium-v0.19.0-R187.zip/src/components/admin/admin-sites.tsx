"use client";

/**
 * Ashrilogic — admin Sites view (round 27).
 *
 * Every public website linked to a provisioned system in one premium table:
 * org + system identity, the identity-theme swatch, a REAL publish switch
 * (admin-guarded PATCH, audit-logged — mirrors the owner-side launch),
 * views counter, customer-account count with public-inquiry subtext, launch
 * date and copy/open quick actions. KPI strip + search + live/draft filter
 * chips + mobile cards + skeletons + empty state. Arabic-first typography
 * (labelTrack, end-aligned LTR URLs, tabular numerals).
 *
 * Round 28: the customers badge / new manager action opens the per-site
 * customer manager sheet (list + ban/unban + delete — see
 * site-customers-sheet.tsx).
 */
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CATEGORY_MAP, SYSTEM_MAP } from "@/data/catalog";
import { fetchAdminSiteTrends, fetchAdminSites, setAdminSitePublished } from "@/lib/api-client";
import { useAdminCanManage } from "@/lib/admin-auth";
import { useT } from "@/lib/i18n";
import type { AdminSiteDTO, AdminSiteTrendsDTO, Lang } from "@/lib/types";
import { siteTheme } from "@/lib/site-themes";
import { CatIcon } from "@/components/icon";
import { cn, copyText, fmtNum, grad, labelTrack, normalizeSearch } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { SiteCustomersSheet } from "@/components/admin/site-customers-sheet";
import { KpiCard } from "@/components/shared/kpi-card";
import {
  DashCard,
  IconTile,
  ViewHeading,
  fullDate,
  relativeTime,
} from "@/components/dashboard/dash-shared";

type SiteFilter = "" | "live" | "draft";

/* ---------------- round 32 — per-site growth sparkline ---------------- */

/**
 * A 12-week signup sparkline for one site row: gradient area + line, an
 * end-dot on the newest week, RTL-mirrored so time flows the way the admin
 * reads. Flat dashed baseline when the site had no signups in the window.
 */
function SiteSparkline({
  series,
  total,
  emptyLabel,
  windowLabel,
  rtl,
  uid,
}: {
  series: number[];
  total: number;
  emptyLabel: string;
  windowLabel: string;
  rtl: boolean;
  uid: string;
}) {
  const W = 68;
  const H = 24;
  const PAD = 3;
  const n = series.length;
  const max = Math.max(1, ...series);
  const x = (i: number) => (rtl ? W - PAD - (i / Math.max(1, n - 1)) * (W - 2 * PAD) : PAD + (i / Math.max(1, n - 1)) * (W - 2 * PAD));
  const y = (v: number) => H - PAD - (v / max) * (H - 2 * PAD);

  if (total === 0) {
    return (
      <span
        title={emptyLabel}
        className="inline-flex items-center gap-1.5 text-[10.5px] font-bold text-slate-300 dark:text-slate-600"
        dir="ltr"
      >
        <svg width={W} height={14} viewBox={`0 0 ${W} 14`} aria-hidden="true">
          <line x1={2} x2={W - 2} y1={7} y2={7} stroke="currentColor" strokeWidth={1.5} strokeDasharray="2 4" strokeLinecap="round" />
        </svg>
      </span>
    );
  }

  const points = series.map((v, i) => `${x(i)},${y(v)}`).join(" ");
  const area = `M${x(0)},${H - PAD} L${series.map((v, i) => `${x(i)},${y(v)}`).join(" L")} L${x(n - 1)},${H - PAD} Z`;
  const lastX = x(n - 1);
  const lastY = y(series[n - 1]);

  return (
    <span title={windowLabel} dir="ltr" className="inline-flex cursor-default items-center">
      <svg width={W} height={H + 4} viewBox={`0 0 ${W} ${H + 4}`} role="img" aria-label={windowLabel}>
        <defs>
          <linearGradient id={`${uid}-fill`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#8b5cf6" stopOpacity="0.35" />
            <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.02" />
          </linearGradient>
          <linearGradient id={`${uid}-line`} x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#6d5dfb" />
            <stop offset="100%" stopColor="#d946ef" />
          </linearGradient>
        </defs>
        <path d={area} fill={`url(#${uid}-fill)`} />
        <polyline points={points} fill="none" stroke={`url(#${uid}-line)`} strokeWidth={1.75} strokeLinecap="round" strokeLinejoin="round" />
        <circle cx={lastX} cy={lastY} r={3} fill="#d946ef" stroke="#fff" strokeWidth={1.25} />
      </svg>
    </span>
  );
}

/* ---------------- KPI card ---------------- */
/* Consolidated into src/components/shared/kpi-card.tsx — the local copy
   (hover accent sweep + LTR value variant) is expressed through the shared
   component's `accent`/`ltrValue` props. */

/* ---------------- round 31 — customer analytics over time ---------------- */

const TREND_WEEKS = 12;

function TrendsPanel() {
  const { t, lang } = useT();
  const [hovered, setHovered] = useState<number | null>(null);

  const query = useQuery({
    queryKey: ["admin-site-trends"],
    queryFn: fetchAdminSiteTrends,
    staleTime: 30_000,
    retry: 1,
  });

  if (query.isError) {
    /* the sites table below remains the hero — surface the miss honestly as a
       compact retryable panel instead of silently dropping the widget */
    return (
      <DashCard className="overflow-hidden">
        <div className="flex flex-wrap items-center gap-3">
          <IconTile icon="chart-column" c1="#6d5dfb" c2="#4b35c9" size="lg" />
          <div className="min-w-0 flex-1">
            <h2 className="font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
              {t("adminSitesTrendsTitle")}
            </h2>
            <p role="alert" className="mt-0.5 text-[12px] font-semibold text-rose-600 dark:text-rose-400">
              {t("errorText")}
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => query.refetch()}
            className="h-9 rounded-xl px-4 text-[12px] font-bold"
          >
            <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
            {t("retryText")}
          </Button>
        </div>
      </DashCard>
    );
  }

  if (query.isPending) {
    return (
      <DashCard className="overflow-hidden">
        <div className="mb-4 flex items-center gap-3">
          <Skeleton className="h-10 w-10 rounded-xl" />
          <div className="flex-1 space-y-2">
            <Skeleton className="h-4 w-48" />
            <Skeleton className="h-3 w-64" />
          </div>
        </div>
        <Skeleton className="h-40 w-full rounded-2xl" />
      </DashCard>
    );
  }

  const data: AdminSiteTrendsDTO = query.data;
  const { totals, weeks, topSites } = data;
  const isRtl = lang === "ar";

  if (totals.customers === 0) {
    return (
      <DashCard>
        <div className="flex items-center gap-3">
          <IconTile icon="chart-column" c1="#6d5dfb" c2="#4b35c9" size="lg" />
          <div className="min-w-0">
            <h2 className="font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
              {t("adminSitesTrendsTitle")}
            </h2>
            <p className="mt-0.5 text-[12px] text-slate-500 dark:text-slate-400">
              {t("adminSitesTrendsEmptyDesc")}
            </p>
          </div>
        </div>
      </DashCard>
    );
  }

  /* ---- chart geometry ---- */
  const W = 660;
  const H = 168;
  const PAD_T = 18;
  const PAD_B = 26;
  const slot = W / TREND_WEEKS;
  const barW = slot * 0.46;
  const maxVal = Math.max(
    3,
    ...weeks.map((w) => Math.max(w.signups, w.inquiries))
  );
  const y = (v: number) => PAD_T + (1 - v / maxVal) * (H - PAD_T - PAD_B);
  const barX = (i: number) =>
    (isRtl ? W - (i + 1) * slot : i * slot) + (slot - barW) / 2;
  const lineX = (i: number) =>
    (isRtl ? W - (i + 1) * slot : i * slot) + slot / 2;

  const delta = totals.signups7d - totals.signupsPrev7d;
  const deltaTone =
    delta > 0
      ? "border-emerald-300/70 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
      : delta < 0
        ? "border-rose-300/70 bg-rose-500/10 text-rose-600 dark:border-rose-500/40 dark:text-rose-300"
        : "border-slate-300/70 bg-slate-100 text-slate-500 dark:border-white/15 dark:bg-white/[0.06] dark:text-slate-400";

  const weekLabelFmt = new Intl.DateTimeFormat(
    lang === "ar" ? "ar-EG" : "en-US",
    { day: "numeric", month: "short" }
  );
  const hover = hovered != null ? weeks[hovered] : null;
  const hoverPct = hovered != null ? ((hovered + 0.5) / TREND_WEEKS) * 100 : 0;

  const maxTop = Math.max(1, ...topSites.map((s) => s.signups));

  return (
    <DashCard className="overflow-hidden">
      {/* header */}
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <IconTile icon="chart-column" c1="#6d5dfb" c2="#4b35c9" size="lg" />
        <div className="min-w-0 flex-1">
          <h2 className="font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
            {t("adminSitesTrendsTitle")}
          </h2>
          <p className="mt-0.5 text-[12px] text-slate-500 dark:text-slate-400">
            {t("adminSitesTrendsDesc")}
          </p>
        </div>
        <div
          className={cn(
            "inline-flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11px] font-extrabold",
            deltaTone
          )}
          title={t("adminSitesTrendsPrev")}
        >
          <CatIcon
            name={delta > 0 ? "trending-up" : delta < 0 ? "trending-down" : "activity"}
            className="h-3.5 w-3.5"
          />
          <span className="tabular-nums">
            {fmtNum(totals.signups7d, lang)} · {delta > 0 ? "+" : ""}
            {fmtNum(delta, lang)}
          </span>
          <span className="hidden text-[10px] font-bold opacity-70 sm:inline">
            {t("adminSitesTrendsThisWeek")}
          </span>
        </div>
      </div>

      {/* legend */}
      <div className="mb-2 flex flex-wrap items-center gap-x-5 gap-y-1.5 text-[11px] font-bold text-slate-500 dark:text-slate-400">
        <span className="inline-flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-[3px] bg-linear-to-b from-brand-500 to-fuchsia-500" />
          {t("adminSitesTrendsLegendSignups")}
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-cyan-400" />
          {t("adminSitesTrendsLegendInquiries")}
        </span>
      </div>

      {/* chart — hover tooltip follows the active week */}
      <div className="relative" dir="ltr">
        <svg viewBox={`0 0 ${W} ${H}`} className="h-40 w-full" role="img" aria-label={t("adminSitesTrendsTitle")}>
          <defs>
            <linearGradient id="trendBar" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#8b5cf6" />
              <stop offset="100%" stopColor="#6d5dfb" stopOpacity="0.55" />
            </linearGradient>
          </defs>

          {/* horizontal gridlines */}
          {[0.25, 0.5, 0.75, 1].map((f) => (
            <line
              key={f}
              x1={0}
              x2={W}
              y1={y(maxVal * f)}
              y2={y(maxVal * f)}
              className="stroke-slate-200/80 dark:stroke-white/10"
              strokeWidth={1}
              strokeDasharray="3 5"
            />
          ))}

          {/* inquiry line + dots */}
          <polyline
            points={weeks.map((w, i) => `${lineX(i)},${y(w.inquiries)}`).join(" ")}
            fill="none"
            stroke="#22d3ee"
            strokeWidth={2}
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeOpacity={hovered == null ? 0.9 : 0.45}
          />
          {weeks.map((w, i) => (
            <circle
              key={`d${i}`}
              cx={lineX(i)}
              cy={y(w.inquiries)}
              r={hovered === i ? 4.5 : 2.5}
              fill={hovered === i ? "#22d3ee" : "#0e7490"}
              className="transition-all"
            />
          ))}

          {/* signup bars */}
          {weeks.map((w, i) => {
            const h = Math.max(w.signups > 0 ? 6 : 3, y(0) - y(w.signups));
            return (
              <g
                key={`b${i}`}
                onMouseEnter={() => setHovered(i)}
                onMouseLeave={() => setHovered(null)}
                className="cursor-pointer"
              >
                {/* invisible full-height hit area */}
                <rect x={i * slot} y={0} width={slot} height={H} fill="transparent" />
                <rect
                  x={barX(i)}
                  y={y(0) - h}
                  width={barW}
                  height={h}
                  rx={Math.min(5, barW / 2)}
                  fill="url(#trendBar)"
                  opacity={hovered == null || hovered === i ? 1 : 0.4}
                  className="transition-opacity"
                />
              </g>
            );
          })}

          {/* x labels — every 3rd week, RTL-mirrored order */}
          {weeks.map((w, i) =>
            i % 3 === 0 ? (
              <text
                key={`x${i}`}
                x={lineX(i)}
                y={H - 6}
                textAnchor="middle"
                className="fill-slate-400 text-[10px] font-bold dark:fill-slate-500"
                style={{ fontSize: 10 }}
              >
                {weekLabelFmt.format(new Date(w.start))}
              </text>
            ) : null
          )}
        </svg>

        {/* tooltip */}
        {hover ? (
          <div
            className="pointer-events-none absolute top-0 z-10 -translate-x-1/2 rounded-xl border border-slate-200/80 bg-white/95 px-3 py-2 shadow-xl backdrop-blur dark:border-white/10 dark:bg-slate-900/95"
            style={{ left: `${hoverPct}%` }}
            dir={isRtl ? "rtl" : "ltr"}
          >
            <p className="text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500">
              {weekLabelFmt.format(new Date(hover.start))}
            </p>
            <p className="mt-0.5 flex items-center gap-1.5 text-[11.5px] font-extrabold text-slate-800 dark:text-slate-100">
              <span className="h-2 w-2 rounded-[3px] bg-linear-to-b from-brand-500 to-fuchsia-500" />
              <span className="tabular-nums">
                {hover.signups === 1
                  ? t("adminSitesTrendsSignupOne")
                  : t("adminSitesTrendsSignupMany", { n: fmtNum(hover.signups, lang) })}
              </span>
            </p>
            <p className="mt-0.5 flex items-center gap-1.5 text-[11.5px] font-extrabold text-cyan-700 dark:text-cyan-300">
              <span className="h-2 w-2 rounded-full bg-cyan-400" />
              <span className="tabular-nums">
                {hover.inquiries === 1
                  ? t("adminSitesTrendsInqOne")
                  : t("adminSitesTrendsInqMany", { n: fmtNum(hover.inquiries, lang) })}
              </span>
            </p>
          </div>
        ) : null}
      </div>

      {/* totals strip */}
      <div className="mt-3 grid grid-cols-2 gap-2.5 border-t border-dashed border-slate-200 pt-3.5 dark:border-white/10 sm:grid-cols-5">
        {(
          [
            { icon: "users-round", label: t("adminSitesTrendsTotCustomers"), value: totals.customers, cls: "text-brand-600 dark:text-brand-300" },
            { icon: "circle-check", label: t("adminSitesTrendsTotActive"), value: totals.active, cls: "text-emerald-600 dark:text-emerald-300" },
            { icon: "ban", label: t("adminSitesTrendsTotBanned"), value: totals.banned, cls: "text-rose-600 dark:text-rose-300" },
            { icon: "message-circle", label: t("adminSitesTrendsTotInquiries"), value: totals.inquiries, cls: "text-cyan-600 dark:text-cyan-300" },
            { icon: "calendar-days", label: t("adminSitesTrendsTotAvg"), value: totals.avgPerWeek, cls: "text-slate-700 dark:text-slate-200" },
          ] as const
        ).map((stat) => (
          <div key={stat.label} className="flex items-center gap-2.5 rounded-xl bg-slate-50/80 px-3 py-2 dark:bg-white/[0.04]">
            <CatIcon name={stat.icon} className={cn("h-4 w-4 shrink-0", stat.cls)} />
            <div className="min-w-0">
              <p className="truncate text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500">
                {stat.label}
              </p>
              <p dir="ltr" className={cn("text-start font-display text-[15px] font-extrabold tabular-nums", stat.cls)}>
                {fmtNum(stat.value, lang)}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* top sites */}
      {topSites.length > 0 ? (
        <div className="mt-3.5 border-t border-dashed border-slate-200 pt-3.5 dark:border-white/10">
          <p className="mb-2 text-[11px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
            {t("adminSitesTrendsTopSites")}
          </p>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {topSites.map((site) => {
              const sys = SYSTEM_MAP[site.systemId];
              const cat = sys ? CATEGORY_MAP[sys.c] : undefined;
              return (
                <div
                  key={site.instanceId}
                  className="flex items-center gap-3 rounded-xl border border-slate-200/70 bg-white/60 p-2.5 transition hover:border-brand-300 hover:shadow-soft dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-brand-500/40"
                >
                  <span
                    className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white"
                    style={{ backgroundImage: grad(cat?.c1 ?? "#6d5dfb", cat?.c2 ?? "#0ea5e9") }}
                  >
                    <CatIcon name={sys?.icon ?? "globe"} className="h-[11px] w-[11px]" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12px] font-extrabold text-slate-800 dark:text-slate-100">
                      {site.orgName}
                    </p>
                    <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-slate-100 dark:bg-white/10">
                      <div
                        className="h-full rounded-full bg-linear-to-r from-brand-500 to-fuchsia-500 transition-all"
                        style={{ width: `${Math.max(8, (site.signups / maxTop) * 100)}%` }}
                      />
                    </div>
                  </div>
                  <div className="shrink-0 text-end">
                    <p dir="ltr" className="text-[12px] font-extrabold tabular-nums text-slate-800 dark:text-slate-100">
                      {fmtNum(site.signups, lang)}
                    </p>
                    <p className="text-[11px] font-bold text-slate-400 dark:text-slate-500">
                      {t("adminSitesTrendsTopCustomers", { n: fmtNum(site.customers, lang) })}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : null}
    </DashCard>
  );
}

/* ---------------- view ---------------- */

export function AdminSites() {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  /* round 29 — publishing is super/admin (server-enforced); every role
     keeps the read-only view + copy/open actions */
  const canManage = useAdminCanManage();

  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<SiteFilter>("");
  /* round 28 — per-site customer manager sheet */
  const [customersSite, setCustomersSite] = useState<AdminSiteDTO | null>(null);

  const query = useQuery({
    queryKey: ["admin-sites"],
    queryFn: fetchAdminSites,
    staleTime: 15_000,
  });

  /* round 32 — the per-site growth series (same cache key as the TrendsPanel
   * query — React Query shares the request, no double fetch) */
  const trendsQuery = useQuery({
    queryKey: ["admin-site-trends"],
    queryFn: fetchAdminSiteTrends,
    staleTime: 30_000,
    retry: 1,
  });
  const perSiteSeries = trendsQuery.data?.perSite ?? {};

  const sites = useMemo(() => query.data ?? [], [query.data]);

  const filtered = useMemo(() => {
    const q = normalizeSearch(search.trim());
    return sites.filter((s) => {
      const sys = SYSTEM_MAP[s.systemId];
      const haystack = normalizeSearch([s.orgName, s.systemId, sys ? (lang === "ar" ? sys.nameAr : sys.nameEn) : ""].join(" "));
      const matchesQ = !q || haystack.includes(q);
      const matchesFilter =
        filter === "" ? true : filter === "live" ? s.published : !s.published;
      return matchesQ && matchesFilter;
    });
  }, [sites, search, filter, lang]);

  const stats = useMemo(
    () => ({
      total: sites.length,
      live: sites.filter((s) => s.published).length,
      views: sites.reduce((sum, s) => sum + s.views, 0),
      customers: sites.reduce((sum, s) => sum + s.customers, 0),
    }),
    [sites]
  );

  /* real publish toggle — admin-guarded, audit-logged server side */
  const togglePublish = useMutation({
    mutationFn: ({ site, published }: { site: AdminSiteDTO; published: boolean }) =>
      setAdminSitePublished(site.id, published),
    onSuccess: (_data, { published }) => {
      toast.success(t(published ? "adminSitesPublishedToast" : "adminSitesUnpublishedToast"));
      queryClient.invalidateQueries({ queryKey: ["admin-sites"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const copyUrl = (site: AdminSiteDTO) => {
    const url = `${window.location.origin}/sites/${site.instanceId}`;
    copyText(url)
      .then(() => toast.success(t("adminSitesCopied")))
      .catch(() => toast.error(t("errorText")));
  };

  const openSite = (site: AdminSiteDTO) => {
    window.open(`/sites/${site.instanceId}`, "_blank", "noopener,noreferrer");
  };

  /* round 32 — CSV export of the FILTERED sites list (client-side blob,
   * UTF-8 BOM so Excel renders the Arabic headers/values correctly) */
  const exportCsv = () => {
    const rows = filtered;
    if (rows.length === 0) return;
    const esc = (v: string) => `"${v.replace(/"/g, '""')}"`;
    const header = [
      t("adminSitesCsvHeadOrg"),
      t("adminSitesCsvHeadSystem"),
      t("adminSitesCsvHeadStatus"),
      t("adminSitesCsvHeadViews"),
      t("adminSitesCsvHeadCustomers"),
      t("adminSitesCsvHeadInquiries"),
      t("adminSitesCsvHeadLaunched"),
      t("adminSitesCsvHeadUrl"),
    ].map(esc).join(",");
    const body = rows.map((s) => {
      const sys = SYSTEM_MAP[s.systemId];
      return [
        s.orgName,
        sys ? (lang === "ar" ? sys.nameAr : sys.nameEn) : s.systemId,
        t(s.published ? "adminSitesLiveBadge" : "adminSitesDraftBadge"),
        String(s.views),
        String(s.customers),
        String(s.inquiries),
        s.launchedAt ? fullDate(s.launchedAt, lang) : "—",
        `${window.location.origin}/sites/${s.instanceId}`,
      ].map(esc).join(",");
    });
    const blob = new Blob(["\uFEFF" + header + "\n" + body.join("\n")], {
      type: "text/csv;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `ashrilogic-sites-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    toast.success(t("adminSitesCsvToast", { count: fmtNum(rows.length, lang) }));
  };

  if (query.isError) {
    return (
      <div className="space-y-5">
        <ViewHeading title={t("adminSites")} desc={t("adminSitesDesc")} />
        <DashCard>
          <div className="py-14 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-rose-100 text-rose-500 dark:bg-rose-500/10 dark:text-rose-300">
              <CatIcon name="circle-alert" className="h-6 w-6" />
            </div>
            <p className="mt-3 font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("errorText")}
            </p>
            <button
              type="button"
              onClick={() => query.refetch()}
              className="mt-5 inline-flex h-11 items-center gap-2 rounded-xl border border-slate-200 px-5 text-[12.5px] font-bold transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10"
            >
              <CatIcon name="refresh-cw" className="h-4 w-4" />
              {t("retryText")}
            </button>
          </div>
        </DashCard>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <ViewHeading title={t("adminSites")} desc={t("adminSitesDesc")} />

      {/* KPI cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard accent ltrValue index={0} lang={lang} label={t("adminSitesKpiTotal")} value={query.isPending ? "…" : fmtNum(stats.total, lang)} icon="globe" c1="#6d5dfb" c2="#4b35c9" />
        <KpiCard accent ltrValue index={1} lang={lang} label={t("adminSitesKpiLive")} value={query.isPending ? "…" : fmtNum(stats.live, lang)} icon="radio-tower" c1="#10b981" c2="#059669" />
        <KpiCard accent ltrValue index={2} lang={lang} label={t("adminSitesKpiViews")} value={query.isPending ? "…" : fmtNum(stats.views, lang)} icon="eye" c1="#06b6d4" c2="#0891b2" />
        <KpiCard accent ltrValue index={3} lang={lang} label={t("adminSitesKpiCustomers")} value={query.isPending ? "…" : fmtNum(stats.customers, lang)} icon="users-round" c1="#d946ef" c2="#c026d3" />
      </div>

      {/* round 31 — customer analytics over time */}
      <TrendsPanel />

      {/* list */}
      <DashCard>
        {/* search + live/draft filter chips + count */}
        <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex min-w-0 flex-1 flex-col gap-2.5 sm:flex-row sm:items-center">
            <div className="relative w-full max-w-md flex-1">
              <CatIcon
                name="search"
                className="pointer-events-none absolute start-3.5 top-1/2 h-[13px] w-[13px] -translate-y-1/2 text-slate-400"
              />
              <input
                type="search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={t("adminSitesSearchPh")}
                aria-label={t("adminSitesSearchPh")}
                className="h-10 w-full rounded-xl border border-slate-200 bg-slate-50/80 ps-10 pe-3 text-[12.5px] font-semibold text-slate-800 outline-none transition placeholder:font-normal placeholder:text-slate-400 focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:focus:bg-white/[0.07]"
              />
            </div>
            {/* live/draft filter chips */}
            <div className="flex shrink-0 items-center gap-1.5">
              {(
                [
                  { key: "" as const, label: t("adminSitesFilterAll"), icon: "layers", count: stats.total },
                  { key: "live" as const, label: t("adminSitesFilterLive"), icon: "globe", count: stats.live },
                  { key: "draft" as const, label: t("adminSitesFilterDraft"), icon: "pencil", count: stats.total - stats.live },
                ] as const
              ).map((chip) => (
                <button
                  key={chip.key || "all"}
                  type="button"
                  onClick={() => setFilter(chip.key)}
                  aria-pressed={filter === chip.key}
                  className={cn(
                    "inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[10.5px] font-extrabold transition active:scale-95",
                    filter === chip.key
                      ? "border-brand-300 bg-brand-500/10 text-brand-600 dark:border-brand-500/40 dark:text-brand-300"
                      : "border-slate-200 bg-white text-slate-500 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-400"
                  )}
                >
                  <CatIcon name={chip.icon} className="h-[10px] w-[10px]" />
                  {chip.label}
                  <span dir="ltr" className="tabular-nums opacity-60">{fmtNum(chip.count, lang)}</span>
                </button>
              ))}
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            {/* round 32 — CSV export of the filtered list */}
            <button
              type="button"
              onClick={exportCsv}
              disabled={query.isPending || filtered.length === 0}
              aria-label={t("adminSitesExportCsvAria")}
              title={t("adminSitesExportCsvAria")}
              className="inline-flex h-8 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-[11px] font-extrabold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 disabled:cursor-not-allowed disabled:opacity-50 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
            >
              <CatIcon name="download" className="h-3.5 w-3.5" />
              {t("adminSitesExportCsv")}
            </button>
            <Badge variant="secondary" className="shrink-0 rounded-full px-3 py-1 text-[11px] font-extrabold text-slate-600 dark:text-slate-300">
              {fmtNum(filtered.length, lang)} / {fmtNum(sites.length, lang)}
            </Badge>
          </div>
        </div>

        {query.isPending ? (
          <div className="space-y-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-16 w-full rounded-xl" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="py-14 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5">
              <CatIcon name="globe" className="h-6 w-6" />
            </div>
            <p className="mt-3 font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
              {sites.length === 0 ? t("adminSitesEmpty") : t("adminSitesEmptyDesc")}
            </p>
            {sites.length === 0 ? (
              <p className="mx-auto mt-1 max-w-sm text-[12px] font-semibold text-slate-400 dark:text-slate-500">
                {t("adminSitesEmptyDesc")}
              </p>
            ) : null}
          </div>
        ) : (
          <>
            {/* desktop table */}
            <div className="hidden md:block">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-200/70 dark:border-white/10">
                    <th className={cn("pb-2 text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {t("adminSitesColSite")}
                    </th>
                    <th className={cn("pb-2 text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {t("adminSitesColIdentity")}
                    </th>
                    <th className={cn("pb-2 text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {t("adminSitesColStatus")}
                    </th>
                    <th className={cn("pb-2 text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {t("adminSitesColViews")}
                    </th>
                    <th className={cn("pb-2 text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {t("adminSitesColCustomers")}
                    </th>
                    <th className={cn("pb-2 text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {t("adminSitesColTrend")}
                    </th>
                    <th className={cn("pb-2 text-end text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {t("adminColActions")}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((site) => {
                    const sys = SYSTEM_MAP[site.systemId];
                    const cat = sys ? CATEGORY_MAP[sys.c] : undefined;
                    const theme = siteTheme(site.theme);
                    const trend = perSiteSeries[site.instanceId] ?? [];
                    const trendTotal = trend.reduce((s, v) => s + v, 0);
                    return (
                      <tr key={site.id} className="group border-b border-slate-100 transition-colors last:border-0 hover:bg-slate-50/70 dark:border-white/[0.05] dark:hover:bg-white/[0.03]">
                        {/* site identity — org name + system + demo */}
                        <td className="py-3">
                          <div className="flex items-center gap-2.5">
                            <IconTile icon={sys?.icon ?? "globe"} c1={cat?.c1 ?? "#6d5dfb"} c2={cat?.c2 ?? "#06b6d4"} size="sm" />
                            <div className="min-w-0">
                              <p className="flex items-center gap-1.5 truncate text-start text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                                {site.orgName}
                                {site.demo ? (
                                  <span
                                    title={t("adminDemoHint")}
                                    className="inline-flex shrink-0 items-center gap-1 rounded-full bg-violet-100 px-2 py-0.5 text-[10px] font-extrabold text-violet-700 dark:bg-violet-500/15 dark:text-violet-300"
                                  >
                                    <CatIcon name="flask-conical" className="h-[9px] w-[9px]" />
                                    {t("adminDemoBadge")}
                                  </span>
                                ) : null}
                              </p>
                              <p className="truncate text-start text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                                {sys ? (lang === "ar" ? sys.nameAr : sys.nameEn) : site.systemId}
                              </p>
                            </div>
                          </div>
                        </td>
                        {/* identity theme — gradient swatch chip */}
                        <td className="py-3">
                          <span
                            title={t("adminSitesThemeLabel")}
                            className="inline-flex items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/70 px-2.5 py-1 text-[10.5px] font-extrabold text-slate-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
                          >
                            <span
                              className="h-2.5 w-2.5 shrink-0 rounded-full"
                              style={{ backgroundImage: grad(theme.c1, theme.c2) }}
                              aria-hidden="true"
                            />
                            {lang === "ar" ? theme.labelAr : theme.labelEn}
                          </span>
                        </td>
                        {/* status — real publish switch */}
                        <td className="py-3">
                          <div className="flex items-center gap-2">
                            <Switch
                              checked={site.published}
                              onCheckedChange={(published) => togglePublish.mutate({ site, published })}
                              disabled={togglePublish.isPending || !canManage}
                              aria-label={`${t("adminSitesTogglePublish")} — ${site.orgName}`}
                              title={!canManage ? t("adminNoPerm") : t("adminSitesToggleHint")}
                            />
                            <span
                              className={cn(
                                "inline-flex shrink-0 items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-extrabold",
                                site.published
                                  ? "border-emerald-400/60 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
                                  : "border-amber-400/60 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-400"
                              )}
                            >
                              <span className={cn("h-1.5 w-1.5 rounded-full", site.published ? "bg-emerald-500" : "bg-amber-500")} aria-hidden="true" />
                              {t(site.published ? "adminSitesLiveBadge" : "adminSitesDraftBadge")}
                            </span>
                          </div>
                        </td>
                        {/* views */}
                        <td className="py-3">
                          <p dir="ltr" className="text-start text-[12.5px] font-extrabold tabular-nums text-slate-700 dark:text-slate-200">
                            {fmtNum(site.views, lang)}
                          </p>
                          <p className="text-start text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                            {site.launchedAt ? relativeTime(site.launchedAt, lang) : t("adminSitesDraftBadge")}
                          </p>
                        </td>
                        {/* customers + inquiries — badge opens the manager (round 28) */}
                        <td className="py-3">
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => setCustomersSite(site)}
                              title={t("siteCustManage")}
                              aria-label={`${t("siteCustManage")} — ${site.orgName}`}
                              className="inline-flex cursor-pointer items-center gap-1 rounded-full bg-fuchsia-500/10 px-2.5 py-0.5 text-[11px] font-extrabold tabular-nums text-fuchsia-600 transition hover:bg-fuchsia-500/20 active:scale-95 dark:text-fuchsia-300"
                            >
                              <CatIcon name="users-round" className="h-[10px] w-[10px]" />
                              {fmtNum(site.customers, lang)}
                              <CatIcon name="ellipsis" className="h-[9px] w-[9px] opacity-60" aria-hidden="true" />
                            </button>
                            {site.inquiries > 0 ? (
                              <span
                                title={t("adminSitesColInquiries")}
                                dir="ltr"
                                className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-extrabold tabular-nums text-slate-500 dark:bg-white/10 dark:text-slate-400"
                              >
                                <CatIcon name="message-square" className="h-[9px] w-[9px]" />
                                {fmtNum(site.inquiries, lang)}
                              </span>
                            ) : null}
                          </div>
                        </td>
                        {/* round 32 — growth sparkline (12-week signups) */}
                        <td className="py-3">
                          <span className="inline-block origin-center transition-transform duration-300 group-hover:scale-110">
                            <SiteSparkline
                              uid={`spark-${site.instanceId.slice(-6)}`}
                              series={trend}
                              total={trendTotal}
                              emptyLabel={t("adminSitesTrendEmpty")}
                              windowLabel={
                                trendTotal === 1
                                  ? t("adminSitesTrendWindowOne")
                                  : t("adminSitesTrendWindow", { n: fmtNum(trendTotal, lang) })
                              }
                              rtl={lang === "ar"}
                            />
                          </span>
                        </td>
                        {/* actions — customers + copy URL + open */}
                        <td className="py-3 text-end">
                          <div className="inline-flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => setCustomersSite(site)}
                              aria-label={`${t("siteCustManage")} — ${site.orgName}`}
                              title={t("siteCustManage")}
                              className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-fuchsia-300 hover:text-fuchsia-600 dark:border-white/10 dark:text-slate-300 dark:hover:border-fuchsia-500/40 dark:hover:text-fuchsia-300"
                            >
                              <CatIcon name="users-round" className="h-[14px] w-[14px]" />
                            </button>
                            <button
                              type="button"
                              onClick={() => copyUrl(site)}
                              aria-label={`${t("adminSitesCopyUrl")} — ${site.orgName}`}
                              title={t("adminSitesCopyUrl")}
                              className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:text-slate-300"
                            >
                              <CatIcon name="copy" className="h-[14px] w-[14px]" />
                            </button>
                            <button
                              type="button"
                              onClick={() => openSite(site)}
                              aria-label={`${t("adminSitesOpen")} — ${site.orgName}`}
                              title={t("adminSitesOpen")}
                              className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-emerald-300 hover:text-emerald-600 dark:border-white/10 dark:text-slate-300 dark:hover:border-emerald-500/40 dark:hover:text-emerald-300"
                            >
                              <CatIcon name="external-link" className="h-[14px] w-[14px]" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* mobile cards */}
            <ul className="space-y-3 md:hidden">
              {filtered.map((site) => {
                const sys = SYSTEM_MAP[site.systemId];
                const cat = sys ? CATEGORY_MAP[sys.c] : undefined;
                const theme = siteTheme(site.theme);
                return (
                  <li
                    key={site.id}
                    className="rounded-2xl border border-slate-200/80 bg-white/80 p-4 dark:border-white/[0.07] dark:bg-white/[0.03]"
                  >
                    <div className="flex items-start gap-3">
                      <IconTile icon={sys?.icon ?? "globe"} c1={cat?.c1 ?? "#6d5dfb"} c2={cat?.c2 ?? "#06b6d4"} size="sm" />
                      <div className="min-w-0 flex-1">
                        <p className="flex items-center gap-1.5 truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
                          {site.orgName}
                          {site.demo ? (
                            <span className="inline-flex shrink-0 items-center rounded-full bg-violet-100 px-1.5 py-0.5 text-[11px] font-extrabold text-violet-700 dark:bg-violet-500/15 dark:text-violet-300">
                              {t("adminDemoBadge")}
                            </span>
                          ) : null}
                        </p>
                        <p className="truncate text-[11px] font-semibold text-slate-400 dark:text-slate-500">
                          {sys ? (lang === "ar" ? sys.nameAr : sys.nameEn) : site.systemId}
                        </p>
                      </div>
                      <Switch
                        checked={site.published}
                        onCheckedChange={(published) => togglePublish.mutate({ site, published })}
                        disabled={togglePublish.isPending || !canManage}
                        title={!canManage ? t("adminNoPerm") : undefined}
                        aria-label={`${t("adminSitesTogglePublish")} — ${site.orgName}`}
                      />
                    </div>
                    <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-3 dark:border-white/[0.06]">
                      <span
                        className="inline-flex items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/70 px-2.5 py-1 text-[10.5px] font-extrabold text-slate-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
                      >
                        <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundImage: grad(theme.c1, theme.c2) }} aria-hidden="true" />
                        {lang === "ar" ? theme.labelAr : theme.labelEn}
                      </span>
                      <span
                        className={cn(
                          "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-extrabold",
                          site.published
                            ? "border-emerald-400/60 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
                            : "border-amber-400/60 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-400"
                        )}
                      >
                        {t(site.published ? "adminSitesLiveBadge" : "adminSitesDraftBadge")}
                      </span>
                      <span dir="ltr" className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-extrabold tabular-nums text-slate-500 dark:bg-white/10 dark:text-slate-400">
                        <CatIcon name="eye" className="h-[9px] w-[9px]" />
                        {fmtNum(site.views, lang)}
                      </span>
                      <button
                        type="button"
                        onClick={() => setCustomersSite(site)}
                        aria-label={t("siteCustManage")}
                        title={t("siteCustManage")}
                        dir="ltr"
                        className="inline-flex items-center gap-1 rounded-full bg-fuchsia-500/10 px-2 py-0.5 text-[10px] font-extrabold tabular-nums text-fuchsia-600 transition hover:bg-fuchsia-500/20 active:scale-95 dark:text-fuchsia-300"
                      >
                        <CatIcon name="users-round" className="h-[9px] w-[9px]" />
                        {fmtNum(site.customers, lang)}
                        <CatIcon name="ellipsis" className="h-[8px] w-[8px] opacity-60" aria-hidden="true" />
                      </button>
                      {/* round 32 — growth sparkline on mobile too */}
                      {(perSiteSeries[site.instanceId] ?? []).reduce((s, v) => s + v, 0) > 0 ? (
                        <span
                          title={t("adminSitesTrendWindow", {
                            n: fmtNum((perSiteSeries[site.instanceId] ?? []).reduce((s, v) => s + v, 0), lang),
                          })}
                          className="inline-flex items-center"
                        >
                          <SiteSparkline
                            uid={`m-spark-${site.instanceId.slice(-6)}`}
                            series={perSiteSeries[site.instanceId] ?? []}
                            total={(perSiteSeries[site.instanceId] ?? []).reduce((s, v) => s + v, 0)}
                            emptyLabel={t("adminSitesTrendEmpty")}
                            windowLabel={t("adminSitesTrendWindow", {
                              n: fmtNum((perSiteSeries[site.instanceId] ?? []).reduce((s, v) => s + v, 0), lang),
                            })}
                            rtl={lang === "ar"}
                          />
                        </span>
                      ) : null}
                      <div className="ms-auto flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => copyUrl(site)}
                          aria-label={t("adminSitesCopyUrl")}
                          className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:text-slate-300"
                        >
                          <CatIcon name="copy" className="h-[13px] w-[13px]" />
                        </button>
                        <button
                          type="button"
                          onClick={() => openSite(site)}
                          aria-label={t("adminSitesOpen")}
                          className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-emerald-300 hover:text-emerald-600 active:scale-95 dark:border-white/10 dark:text-slate-300"
                        >
                          <CatIcon name="external-link" className="h-[13px] w-[13px]" />
                        </button>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          </>
        )}
      </DashCard>

      {/* round 28 — per-site customer manager */}
      <SiteCustomersSheet
        site={customersSite}
        open={customersSite !== null}
        onOpenChange={(o) => !o && setCustomersSite(null)}
      />
    </div>
  );
}

export default AdminSites;
