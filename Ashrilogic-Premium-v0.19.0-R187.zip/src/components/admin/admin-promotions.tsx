"use client";

/**
 * Ashrilogic — Super Admin promotions console (العروض الترويجية) —
 * ROUND 169.
 *
 * The owner's directive: «add offer messages on the official website like
 * Black Friday, New Year, Eid Mubarak promotions — like the big sites
 * (Amazon, Walmart) — in a Premium way». The EVENT-BANNER MANAGER:
 *
 *  - PREMIUM CARD GRID: every promotion with a LIVE THEME PREVIEW (a
 *    miniature of the exact banner skin the landing strip renders), the
 *    schedule window + its status chip (قادمة / نشطة الآن / منتهية —
 *    plus متوقفة for inactive rows), the discount badge and the CTA
 *    target;
 *  - CREATE/EDIT DIALOG: bilingual title/message/badge/CTA copy, the five
 *    theme swatches (Black Friday — near-black + electric yellow; New
 *    Year — deep violet + gold; Eid Mubarak — emerald + cream; Sale —
 *    brand gradient; Custom — slate), a discount stepper, the in-app CTA
 *    href (validated client + server), native datetime-local pickers, the
 *    active toggle and the display order;
 *  - every mutation is audited server-side (platform.promotion* rows).
 *
 * Design follows the admin-wallet-grants idiom — pipeline cards, gradient
 * tiles, KPI strip.
 */
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  fetchAdminPromotions,
  createAdminPromotion,
  updateAdminPromotion,
  deleteAdminPromotion,
} from "@/lib/api-client";
import { useAdminCanManage } from "@/lib/admin-auth";
import { useT, type I18nKey } from "@/lib/i18n";
import type { AdminPromotionDTO } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { ViewHeading, DashCard, fullDate } from "@/components/dashboard/dash-shared";
import { KpiCard } from "@/components/shared/kpi-card";

/* ------------------------------------------------------------------ */
/* static registries                                                   */
/* ------------------------------------------------------------------ */

type ThemeId = "black-friday" | "new-year" | "eid" | "sale" | "custom";

interface ThemeMeta {
  key: I18nKey;
  icon: string;
  c1: string;
  c2: string;
  /** the miniature skin classes (the banner strip's own family). */
  swatch: string;
  text: string;
}

const THEMES: Record<ThemeId, ThemeMeta> = {
  "black-friday": {
    key: "promoThemeBlackFriday",
    icon: "zap",
    c1: "#eab308",
    c2: "#facc15",
    swatch: "bg-[#0a0a0f]",
    text: "text-yellow-300",
  },
  "new-year": {
    key: "promoThemeNewYear",
    icon: "sparkles",
    c1: "#7c3aed",
    c2: "#a78bfa",
    swatch: "bg-linear-to-l from-[#2e1065] via-[#4c1d95] to-[#6d28d9]",
    text: "text-amber-200",
  },
  eid: {
    key: "promoThemeEid",
    icon: "moon-star",
    c1: "#059669",
    c2: "#10b981",
    swatch: "bg-linear-to-l from-emerald-950 via-emerald-800 to-emerald-700",
    text: "text-emerald-100",
  },
  sale: {
    key: "promoThemeSale",
    icon: "tag",
    c1: "#6d5dfb",
    c2: "#d946ef",
    swatch: "bg-linear-to-l from-brand-600 via-brand-500 to-fuchsia-500",
    text: "text-white",
  },
  custom: {
    key: "promoThemeCustom",
    icon: "shapes",
    c1: "#64748b",
    c2: "#94a3b8",
    swatch: "bg-slate-900 dark:bg-slate-800",
    text: "text-slate-100",
  },
};

function themeMeta(theme: string): ThemeMeta {
  return (THEMES as Record<string, ThemeMeta>)[theme] ?? THEMES.sale;
}

/** The typed theme id for a stored row ("sale" on an unknown value). */
function themeIdOf(theme: string): ThemeId {
  return ((Object.keys(THEMES) as ThemeId[]).find((id) => id === theme) ?? "sale") as ThemeId;
}

/** The schedule status of one promotion row (client-side derivation). */
type ScheduleStatus = "live" | "upcoming" | "expired";

function scheduleStatus(promo: AdminPromotionDTO, now: number): ScheduleStatus {
  const start = new Date(promo.startsAt).getTime();
  const end = new Date(promo.endsAt).getTime();
  if (now < start) return "upcoming";
  if (now > end) return "expired";
  return "live";
}

const STATUS_META: Record<ScheduleStatus, { key: I18nKey; cls: string; icon: string }> = {
  live: {
    key: "promoStatusLive",
    cls: "border-emerald-400/60 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300",
    icon: "circle-check",
  },
  upcoming: {
    key: "promoStatusUpcoming",
    cls: "border-amber-400/60 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-400",
    icon: "clock",
  },
  expired: {
    key: "promoStatusExpired",
    cls: "border-slate-300/60 bg-slate-500/10 text-slate-500 dark:border-white/10 dark:bg-white/[0.06] dark:text-slate-400",
    icon: "history",
  },
};

/** datetime-local value from an ISO string (local wall clock). */
function toLocalInput(iso: string): string {
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

/** The in-app CTA href law (mirrors the server zod refine). */
function isValidHref(href: string): boolean {
  const trimmed = href.trim();
  return trimmed === "" || trimmed.startsWith("/") || trimmed.startsWith("#");
}

/* ------------------------------------------------------------------ */
/* the theme miniature (the live banner skin preview)                  */
/* ------------------------------------------------------------------ */

function ThemeMiniature({
  theme,
  discountPct,
  title,
  message,
}: {
  theme: string;
  discountPct: number;
  title: string;
  message: string;
}) {
  const meta = themeMeta(theme);
  return (
    <div className={cn("relative overflow-hidden rounded-xl px-3.5 py-3", meta.swatch)}>
      <div className="flex items-center justify-between gap-2">
        <p className={cn("truncate text-[12px] font-extrabold", meta.text)} dir="auto">
          {title}
        </p>
        {discountPct > 0 ? (
          <span className="shrink-0 rounded-full bg-white/15 px-2 py-0.5 text-[9.5px] font-extrabold tabular-nums text-white ring-1 ring-white/30" dir="ltr">
            {discountPct}%
          </span>
        ) : null}
      </div>
      {message ? (
        <p className="mt-0.5 truncate text-[10px] font-semibold text-white/70" dir="auto">
          {message}
        </p>
      ) : null}
    </div>
  );
}

/* ================================================================== */
/* the view                                                            */
/* ================================================================== */

export function AdminPromotions() {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const canManage = useAdminCanManage();

  /* ---------------- data ---------------- */
  const query = useQuery({
    queryKey: ["admin-promotions"],
    queryFn: () => fetchAdminPromotions("all"),
    staleTime: 30_000,
    retry: 1,
  });
  const promotions = useMemo(() => query.data ?? [], [query.data]);

  /* ---------------- dialog state ---------------- */
  const [editor, setEditor] = useState<{ mode: "create" } | { mode: "edit"; row: AdminPromotionDTO } | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<AdminPromotionDTO | null>(null);
  const [statusFilter, setStatusFilter] = useState<"all" | "live" | "upcoming" | "expired">("all");

  /* the editor's field state */
  const [titleAr, setTitleAr] = useState("");
  const [titleEn, setTitleEn] = useState("");
  const [messageAr, setMessageAr] = useState("");
  const [messageEn, setMessageEn] = useState("");
  const [badgeAr, setBadgeAr] = useState("");
  const [badgeEn, setBadgeEn] = useState("");
  const [ctaTextAr, setCtaTextAr] = useState("");
  const [ctaTextEn, setCtaTextEn] = useState("");
  const [ctaHref, setCtaHref] = useState("");
  const [theme, setTheme] = useState<ThemeId>("sale");
  const [discountPct, setDiscountPct] = useState(0);
  const [startsAt, setStartsAt] = useState("");
  const [endsAt, setEndsAt] = useState("");
  const [active, setActive] = useState(true);
  const [sortOrder, setSortOrder] = useState(0);

  /* ---------------- mutations ---------------- */
  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["admin-promotions"] });

  const save = useMutation({
    mutationFn: () => {
      const payload = {
        titleAr: titleAr.trim(),
        titleEn: titleEn.trim(),
        messageAr: messageAr.trim(),
        messageEn: messageEn.trim(),
        badgeAr: badgeAr.trim(),
        badgeEn: badgeEn.trim(),
        ctaTextAr: ctaTextAr.trim(),
        ctaTextEn: ctaTextEn.trim(),
        ctaHref: ctaHref.trim(),
        theme,
        discountPct,
        startsAt: new Date(startsAt).toISOString(),
        endsAt: new Date(endsAt).toISOString(),
        active,
        sortOrder,
      };
      return editor?.mode === "edit"
        ? updateAdminPromotion(editor.row.id, payload)
        : createAdminPromotion(payload);
    },
    onSuccess: () => {
      toast.success(t(editor?.mode === "edit" ? "promoUpdatedToast" : "promoCreatedToast"));
      setEditor(null);
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message || t("errorText")),
  });

  const remove = useMutation({
    mutationFn: (id: string) => deleteAdminPromotion(id),
    onSuccess: () => {
      toast.success(t("promoDeletedToast"));
      setConfirmDelete(null);
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message || t("errorText")),
  });

  /* ---------------- editor actions ---------------- */
  const openCreate = () => {
    setTitleAr("");
    setTitleEn("");
    setMessageAr("");
    setMessageEn("");
    setBadgeAr("");
    setBadgeEn("");
    setCtaTextAr("");
    setCtaTextEn("");
    setCtaHref("");
    setTheme("sale");
    setDiscountPct(0);
    /* default window: now → +7 days (datetime-local values) */
    const start = new Date();
    const end = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    setStartsAt(toLocalInput(start.toISOString()));
    setEndsAt(toLocalInput(end.toISOString()));
    setActive(true);
    setSortOrder(0);
    setEditor({ mode: "create" });
  };

  const openEdit = (row: AdminPromotionDTO) => {
    setTitleAr(row.titleAr);
    setTitleEn(row.titleEn);
    setMessageAr(row.messageAr);
    setMessageEn(row.messageEn);
    setBadgeAr(row.badgeAr);
    setBadgeEn(row.badgeEn);
    setCtaTextAr(row.ctaTextAr);
    setCtaTextEn(row.ctaTextEn);
    setCtaHref(row.ctaHref);
    setTheme(themeIdOf(row.theme));
    setDiscountPct(row.discountPct);
    setStartsAt(toLocalInput(row.startsAt));
    setEndsAt(toLocalInput(row.endsAt));
    setActive(row.active);
    setSortOrder(row.sortOrder);
    setEditor({ mode: "edit", row });
  };

  const submit = () => {
    if (titleAr.trim().length < 2 || titleEn.trim().length < 2) {
      toast.error(t("promoErrRequired"));
      return;
    }
    if (!startsAt || !endsAt) {
      toast.error(t("promoErrWindow"));
      return;
    }
    if (new Date(endsAt).getTime() <= new Date(startsAt).getTime()) {
      toast.error(t("promoErrWindow"));
      return;
    }
    if (editor?.mode === "create" && new Date(endsAt).getTime() <= Date.now()) {
      toast.error(t("promoErrFuture"));
      return;
    }
    if (!isValidHref(ctaHref)) {
      toast.error(t("promoErrHref"));
      return;
    }
    save.mutate();
  };

  /* ---------------- stats + filtering ---------------- */
  const now = Date.now();
  const stats = useMemo(() => {
    const live = promotions.filter((p) => p.active && scheduleStatus(p, now) === "live").length;
    const upcoming = promotions.filter((p) => scheduleStatus(p, now) === "upcoming").length;
    const expired = promotions.filter((p) => scheduleStatus(p, now) === "expired").length;
    return { total: promotions.length, live, upcoming, expired };
  }, [promotions, now]);

  const filtered = useMemo(
    () =>
      promotions.filter((p) => {
        if (statusFilter === "all") return true;
        if (statusFilter === "live") return p.active && scheduleStatus(p, now) === "live";
        return scheduleStatus(p, now) === statusFilter;
      }),
    [promotions, statusFilter, now]
  );

  const bilingualTitle = (row: AdminPromotionDTO) => (lang === "ar" ? row.titleAr : row.titleEn);
  const bilingualMessage = (row: AdminPromotionDTO) => (lang === "ar" ? row.messageAr : row.messageEn);

  return (
    <div className="space-y-5">
      <ViewHeading title={t("promoTitle")} desc={t("promoDesc")} />

      {/* KPI strip */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <KpiCard label={t("promoKpiTotal")} numeric={stats.total} icon="megaphone" c1="#6d5dfb" c2="#8b5cf6" index={0} />
        <KpiCard label={t("promoKpiLive")} numeric={stats.live} icon="circle-check" c1="#10b981" c2="#059669" index={1} />
        <KpiCard label={t("promoKpiUpcoming")} numeric={stats.upcoming} icon="clock" c1="#f59e0b" c2="#d97706" index={2} />
        <KpiCard label={t("promoKpiExpired")} numeric={stats.expired} icon="history" c1="#64748b" c2="#94a3b8" index={3} />
      </div>

      {/* the banner manager */}
      <DashCard
        title={t("promoTitle")}
        icon="tag"
        action={
          canManage ? (
            <Button
              type="button"
              size="sm"
              onClick={openCreate}
              className="h-9 gap-1.5 rounded-lg bg-linear-to-l from-fuchsia-600 to-brand-500 px-3.5 text-[11px] font-extrabold text-white shadow-lg shadow-fuchsia-500/25 transition hover:brightness-110 active:scale-95"
            >
              <CatIcon name="plus" className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">{t("promoNewBtn")}</span>
            </Button>
          ) : null
        }
      >
        {/* status filter chips */}
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-[10.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500">
            {t("promoFilterLabel")}
          </span>
          {(["all", "live", "upcoming", "expired"] as const).map((value) => (
            <button
              key={value}
              type="button"
              onClick={() => setStatusFilter(value)}
              aria-pressed={statusFilter === value}
              className={cn(
                "rounded-full px-2.5 py-1 text-[10.5px] font-extrabold transition active:scale-95",
                statusFilter === value
                  ? "bg-brand-500/10 text-brand-600 dark:text-brand-300"
                  : "text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-white/[0.06] dark:hover:text-slate-300"
              )}
            >
              {t(
                value === "all"
                  ? "promoFilterAll"
                  : value === "live"
                    ? "promoStatusLive"
                    : value === "upcoming"
                      ? "promoStatusUpcoming"
                      : "promoStatusExpired"
              )}
            </button>
          ))}
        </div>

        {/* the card grid */}
        <div className="mt-3">
          {query.isPending ? (
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-56 w-full rounded-2xl" />
              ))}
            </div>
          ) : query.isError ? (
            <div className="rounded-2xl border border-rose-200 bg-rose-50/70 p-5 text-center text-[12.5px] font-bold text-rose-600 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-300">
              {t("errorText")}
            </div>
          ) : filtered.length === 0 ? (
            <div className="rounded-2xl border-2 border-dashed border-slate-200 p-7 text-center dark:border-white/10">
              <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-fuchsia-500/10 text-fuchsia-500 dark:text-fuchsia-300">
                <CatIcon name="tag" className="h-5 w-5" />
              </div>
              <p className="mt-3 font-display text-[13.5px] font-extrabold text-slate-600 dark:text-slate-300">
                {t("promoEmptyTitle")}
              </p>
              <p className="mx-auto mt-1 max-w-sm text-[11.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                {t("promoEmptyDesc")}
              </p>
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {filtered.map((row) => {
                const meta = themeMeta(row.theme);
                const status = scheduleStatus(row, now);
                const statusMeta = STATUS_META[status];
                return (
                  <article
                    key={row.id}
                    className="group flex flex-col rounded-2xl border border-slate-200/80 bg-white/80 p-3.5 transition hover:border-fuchsia-300/70 hover:shadow-soft dark:border-white/[0.07] dark:bg-white/[0.03] dark:hover:border-fuchsia-500/40"
                  >
                    {/* theme preview miniature */}
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <span
                          className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-extrabold text-white"
                          style={{ backgroundImage: grad(meta.c1, meta.c2) }}
                        >
                          <CatIcon name={meta.icon} className="h-[10px] w-[10px]" />
                          {t(meta.key)}
                        </span>
                        <span
                          className={cn(
                            "inline-flex shrink-0 items-center gap-1 rounded-full border px-2.5 py-0.5 text-[10px] font-extrabold",
                            row.active
                              ? statusMeta.cls
                              : "border-slate-300/60 bg-slate-500/10 text-slate-500 dark:border-white/10 dark:bg-white/[0.06] dark:text-slate-400"
                          )}
                        >
                          <CatIcon
                            name={row.active ? statusMeta.icon : "ban"}
                            className="h-[10px] w-[10px]"
                          />
                          {t(row.active ? statusMeta.key : "promoStatusInactive")}
                        </span>
                      </div>
                      <div className="mt-2.5">
                        <ThemeMiniature
                          theme={row.theme}
                          discountPct={row.discountPct}
                          title={bilingualTitle(row)}
                          message={bilingualMessage(row)}
                        />
                      </div>
                    </div>

                    {/* schedule + evidence */}
                    <div className="mt-3 space-y-1.5 text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
                      <p className="flex items-center gap-1.5">
                        <CatIcon name="calendar-clock" className="h-3 w-3 shrink-0 text-slate-400" />
                        <span className="shrink-0">{t("promoScheduleLabel")}:</span>
                        <span dir="ltr" className="truncate tabular-nums">
                          {fullDate(row.startsAt, lang)} → {fullDate(row.endsAt, lang)}
                        </span>
                      </p>
                      <div className="flex flex-wrap items-center gap-1.5">
                        {row.discountPct > 0 ? (
                          <span className="inline-flex items-center gap-1 rounded-full bg-rose-500/10 px-2 py-0.5 text-[10px] font-extrabold tabular-nums text-rose-600 dark:text-rose-300">
                            <CatIcon name="percent" className="h-[10px] w-[10px]" />
                            {t("promoDiscountChip", { pct: fmtNum(row.discountPct, lang) })}
                          </span>
                        ) : null}
                        {row.badgeAr || row.badgeEn ? (
                          <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/10 px-2 py-0.5 text-[10px] font-extrabold text-amber-600 dark:text-amber-300" dir="auto">
                            <CatIcon name="stamp" className="h-[10px] w-[10px]" />
                            {lang === "ar" ? row.badgeAr : row.badgeEn}
                          </span>
                        ) : null}
                        {row.ctaHref ? (
                          <span className="inline-flex items-center gap-1 rounded-full bg-brand-500/10 px-2 py-0.5 text-[10px] font-extrabold text-brand-600 dark:text-brand-300" dir="ltr">
                            <CatIcon name="link" className="h-[10px] w-[10px]" />
                            <span className="max-w-[140px] truncate">{row.ctaHref}</span>
                          </span>
                        ) : null}
                        <span className="ms-auto inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-extrabold tabular-nums text-slate-500 dark:bg-white/10 dark:text-slate-400" dir="ltr">
                          <CatIcon name="hash" className="h-[10px] w-[10px]" />
                          {fmtNum(row.sortOrder, lang)}
                        </span>
                      </div>
                    </div>

                    {/* actions */}
                    <div className="mt-auto flex items-center gap-1.5 border-t border-slate-100 pt-2.5 dark:border-white/[0.06]">
                      <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500">
                        {t("promoCtaTarget")}: <span dir="ltr">{row.ctaHref || "—"}</span>
                      </span>
                      <div className="ms-auto flex items-center gap-1.5">
                        {canManage ? (
                          <>
                            <button
                              type="button"
                              onClick={() => openEdit(row)}
                              aria-label={`${t("promoEditBtn")} — ${row.titleAr}`}
                              title={t("promoEditBtn")}
                              className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
                            >
                              <CatIcon name="pencil" className="h-[14px] w-[14px]" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDelete(row)}
                              aria-label={`${t("promoDeleteBtn")} — ${row.titleAr}`}
                              title={t("promoDeleteBtn")}
                              className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-rose-300 hover:bg-rose-50 hover:text-rose-600 active:scale-95 dark:border-white/10 dark:text-slate-300 dark:hover:border-rose-500/40 dark:hover:bg-rose-500/10 dark:hover:text-rose-300"
                            >
                              <CatIcon name="trash" className="h-[14px] w-[14px]" />
                            </button>
                          </>
                        ) : null}
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </div>
      </DashCard>

      {/* ---------------- the create / edit dialog ---------------- */}
      <Dialog open={editor !== null} onOpenChange={(o) => !o && setEditor(null)}>
        <DialogContent dir="auto" className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-8 w-8 place-items-center rounded-xl text-white"
                style={{ backgroundImage: grad("#d946ef", "#6d5dfb") }}
              >
                <CatIcon name="tag" className="h-4 w-4" />
              </span>
              {t(editor?.mode === "edit" ? "promoUpdateBtn" : "promoNewBtn")}
            </DialogTitle>
            <DialogDescription className="text-[12.5px] leading-relaxed">{t("promoDesc")}</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* theme picker */}
            <div>
              <Label className="text-[12px] font-extrabold leading-tight text-slate-700 dark:text-slate-200">
                {t("promoThemeLabel")}
              </Label>
              <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-5">
                {(Object.keys(THEMES) as ThemeId[]).map((id) => {
                  const meta = THEMES[id];
                  const selected = theme === id;
                  return (
                    <button
                      key={id}
                      type="button"
                      onClick={() => setTheme(id)}
                      disabled={!canManage}
                      aria-pressed={selected}
                      className={cn(
                        "group rounded-xl border p-2 text-center transition active:scale-[0.97] disabled:opacity-60",
                        selected
                          ? "border-brand-400 ring-2 ring-brand-400/30 dark:border-brand-500/60"
                          : "border-slate-200 hover:border-slate-300 dark:border-white/10 dark:hover:border-white/20"
                      )}
                    >
                      <span className={cn("block h-10 w-full rounded-lg", meta.swatch)} aria-hidden="true" />
                      <span className="mt-1.5 flex items-center justify-center gap-1 text-[10.5px] font-extrabold text-slate-600 dark:text-slate-300">
                        <CatIcon name={meta.icon} className="h-3 w-3" />
                        {t(meta.key)}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* bilingual title */}
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="promo-title-ar" className="text-[12px] font-bold">
                  {t("promoFieldTitle")} · {t("promoLangAr")}
                </Label>
                <Input
                  id="promo-title-ar"
                  value={titleAr}
                  onChange={(e) => setTitleAr(e.target.value)}
                  maxLength={80}
                  disabled={!canManage}
                  dir="rtl"
                  className="h-10 rounded-xl text-[13px] font-semibold"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="promo-title-en" className="text-[12px] font-bold">
                  {t("promoFieldTitle")} · {t("promoLangEn")}
                </Label>
                <Input
                  id="promo-title-en"
                  value={titleEn}
                  onChange={(e) => setTitleEn(e.target.value)}
                  maxLength={80}
                  disabled={!canManage}
                  dir="ltr"
                  className="h-10 rounded-xl text-[13px] font-semibold"
                />
              </div>
            </div>

            {/* bilingual message */}
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="promo-msg-ar" className="text-[12px] font-bold">
                  {t("promoFieldMessage")} · {t("promoLangAr")}
                </Label>
                <Input
                  id="promo-msg-ar"
                  value={messageAr}
                  onChange={(e) => setMessageAr(e.target.value)}
                  maxLength={140}
                  disabled={!canManage}
                  dir="rtl"
                  className="h-10 rounded-xl text-[13px]"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="promo-msg-en" className="text-[12px] font-bold">
                  {t("promoFieldMessage")} · {t("promoLangEn")}
                </Label>
                <Input
                  id="promo-msg-en"
                  value={messageEn}
                  onChange={(e) => setMessageEn(e.target.value)}
                  maxLength={140}
                  disabled={!canManage}
                  dir="ltr"
                  className="h-10 rounded-xl text-[13px]"
                />
              </div>
            </div>

            {/* badge + discount */}
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="promo-badge" className="text-[12px] font-bold">
                  {t("promoFieldBadge")}
                </Label>
                <div className="flex gap-2">
                  <Input
                    id="promo-badge"
                    value={badgeAr}
                    onChange={(e) => setBadgeAr(e.target.value)}
                    maxLength={24}
                    disabled={!canManage}
                    dir="rtl"
                    placeholder="خصم ٤٠٪"
                    className="h-10 rounded-xl text-[12.5px]"
                  />
                  <Input
                    aria-label={t("promoFieldBadge")}
                    value={badgeEn}
                    onChange={(e) => setBadgeEn(e.target.value)}
                    maxLength={24}
                    disabled={!canManage}
                    dir="ltr"
                    placeholder="40% OFF"
                    className="h-10 rounded-xl text-[12.5px]"
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-[12px] font-bold">{t("promoFieldDiscount")}</Label>
                <div className="flex h-10 items-center gap-2 rounded-xl border border-slate-200 px-2 dark:border-white/10">
                  <button
                    type="button"
                    onClick={() => setDiscountPct((p) => Math.max(0, p - 5))}
                    disabled={!canManage || discountPct <= 0}
                    aria-label="-"
                    className="grid h-7 w-7 place-items-center rounded-lg bg-slate-100 text-slate-600 transition hover:bg-slate-200 active:scale-95 disabled:opacity-40 dark:bg-white/10 dark:text-slate-300"
                  >
                    <CatIcon name="minus" className="h-3.5 w-3.5" />
                  </button>
                  <span dir="ltr" className="flex-1 select-none text-center text-[14px] font-extrabold tabular-nums text-slate-700 dark:text-slate-200">
                    {discountPct}%
                  </span>
                  <button
                    type="button"
                    onClick={() => setDiscountPct((p) => Math.min(90, p + 5))}
                    disabled={!canManage || discountPct >= 90}
                    aria-label="+"
                    className="grid h-7 w-7 place-items-center rounded-lg bg-slate-100 text-slate-600 transition hover:bg-slate-200 active:scale-95 disabled:opacity-40 dark:bg-white/10 dark:text-slate-300"
                  >
                    <CatIcon name="plus" className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </div>

            {/* CTA text + href */}
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="promo-cta-ar" className="text-[12px] font-bold">
                  {t("promoFieldCta")}
                </Label>
                <div className="flex gap-2">
                  <Input
                    id="promo-cta-ar"
                    value={ctaTextAr}
                    onChange={(e) => setCtaTextAr(e.target.value)}
                    maxLength={40}
                    disabled={!canManage}
                    dir="rtl"
                    className="h-10 rounded-xl text-[12.5px]"
                  />
                  <Input
                    aria-label={t("promoFieldCta")}
                    value={ctaTextEn}
                    onChange={(e) => setCtaTextEn(e.target.value)}
                    maxLength={40}
                    disabled={!canManage}
                    dir="ltr"
                    className="h-10 rounded-xl text-[12.5px]"
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="promo-href" className="text-[12px] font-bold">
                  {t("promoFieldHref")}
                </Label>
                <Input
                  id="promo-href"
                  value={ctaHref}
                  onChange={(e) => setCtaHref(e.target.value)}
                  maxLength={200}
                  disabled={!canManage}
                  dir="ltr"
                  placeholder="/compare"
                  aria-invalid={ctaHref !== "" && !isValidHref(ctaHref)}
                  className="h-10 rounded-xl font-mono text-[12.5px]"
                />
                <p
                  className={cn(
                    "text-[10.5px] font-semibold leading-relaxed",
                    ctaHref !== "" && !isValidHref(ctaHref)
                      ? "text-rose-500 dark:text-rose-300"
                      : "text-slate-400 dark:text-slate-500"
                  )}
                >
                  {ctaHref !== "" && !isValidHref(ctaHref) ? t("promoFieldHrefBad") : t("promoFieldHrefHint")}
                </p>
              </div>
            </div>

            {/* schedule window */}
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="promo-start" className="text-[12px] font-bold">
                  {t("promoFieldStart")}
                </Label>
                <Input
                  id="promo-start"
                  type="datetime-local"
                  value={startsAt}
                  onChange={(e) => setStartsAt(e.target.value)}
                  disabled={!canManage}
                  dir="ltr"
                  className="h-10 rounded-xl text-[12.5px] tabular-nums"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="promo-end" className="text-[12px] font-bold">
                  {t("promoFieldEnd")}
                </Label>
                <Input
                  id="promo-end"
                  type="datetime-local"
                  value={endsAt}
                  onChange={(e) => setEndsAt(e.target.value)}
                  disabled={!canManage}
                  dir="ltr"
                  className="h-10 rounded-xl text-[12.5px] tabular-nums"
                />
              </div>
            </div>

            {/* active toggle + sort order */}
            <div className="grid items-center gap-4 sm:grid-cols-2">
              <div className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 px-3 py-2.5 dark:border-white/10">
                <div className="min-w-0">
                  <Label htmlFor="promo-active" className="text-[12px] font-bold">
                    {t("promoFieldActive")}
                  </Label>
                  <p className="mt-0.5 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                    {t("promoFieldActiveHint")}
                  </p>
                </div>
                <Switch id="promo-active" checked={active} onCheckedChange={setActive} disabled={!canManage} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="promo-sort" className="text-[12px] font-bold">
                  {t("promoFieldSort")}
                </Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="promo-sort"
                    type="number"
                    value={sortOrder}
                    onChange={(e) => setSortOrder(Math.max(-100, Math.min(1000, Number(e.target.value) || 0)))}
                    disabled={!canManage}
                    dir="ltr"
                    className="h-10 w-24 rounded-xl text-[12.5px] tabular-nums"
                  />
                  <p className="text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                    {t("promoFieldSortHint")}
                  </p>
                </div>
              </div>
            </div>

            {/* live theme preview */}
            <div>
              <Label className="text-[12px] font-bold">{t("promoPreviewLabel")}</Label>
              <div className="mt-2">
                <ThemeMiniature
                  theme={theme}
                  discountPct={discountPct}
                  title={titleAr.trim() || titleEn.trim() || t("promoFieldTitle")}
                  message={messageAr.trim() || messageEn.trim()}
                />
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setEditor(null)}
              disabled={save.isPending}
              className="h-10 rounded-xl px-4 text-[12px] font-bold"
            >
              {t("dlgCancel")}
            </Button>
            <Button
              type="button"
              onClick={submit}
              disabled={!canManage || save.isPending}
              className="h-10 gap-2 rounded-xl bg-linear-to-l from-fuchsia-600 to-brand-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-fuchsia-500/25 transition hover:brightness-110 active:scale-95"
            >
              <CatIcon
                name={save.isPending ? "refresh-cw" : editor?.mode === "edit" ? "check" : "plus"}
                className={cn("h-4 w-4", save.isPending && "animate-spin")}
              />
              {t(editor?.mode === "edit" ? "promoUpdateBtn" : "promoCreateBtn")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ---------------- delete confirm ---------------- */}
      <AlertDialog open={confirmDelete !== null} onOpenChange={(o) => !o && setConfirmDelete(null)}>
        <AlertDialogContent dir="auto" className="sm:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display text-[15px] font-extrabold">
              {t("promoDeleteTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="leading-relaxed">
              {t("promoDeleteMsg", {
                title: confirmDelete ? bilingualTitle(confirmDelete).slice(0, 40) : "",
              })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={remove.isPending}>
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => confirmDelete && remove.mutate(confirmDelete.id)}
              disabled={remove.isPending}
              className="h-10 gap-2 rounded-xl bg-rose-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60"
            >
              <CatIcon name={remove.isPending ? "refresh-cw" : "trash"} className={cn("h-4 w-4", remove.isPending && "animate-spin")} />
              {t("promoDeleteConfirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default AdminPromotions;
