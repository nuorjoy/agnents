"use client";

/**
 * Ashrilogic — ROUND 166 — Super-Admin «استعادة البريد المختوم» console view.
 *
 * The one-time sealed-email recovery surface (the owner's «استعادة البريد
 * الإلكتروني المختوم مرة واحدة»): old data renders mailbox addresses as
 * MASKED everywhere; this view recovers one sealed address exactly once
 * without weakening the seal.
 *
 * Flow: a super admin MINTS a single-use reveal token for one target row
 * (subscriber / system user / site customer / ticket requester) with a
 * MANDATORY justification → the RAW token is displayed EXACTLY ONCE with a
 * copy affordance and a live 15-minute expiry countdown → pasting it back
 * into the consume form performs the atomic single-use claim and reveals
 * the decrypted email EXACTLY ONCE (highlighted card + who minted it, why,
 * when). The plaintext never persists anywhere — the token row stores only
 * the sha256, and the audit trail carries the recipient MASKED.
 *
 * Server side: POST/PUT /api/admin/email-reveal (super-only, rate-limited,
 * security-audited — see src/lib/server/email-reveal.ts). Non-super roles
 * see the security-model explainer plus the permission notice only.
 */
import { useEffect, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { consumeEmailRevealToken, mintEmailRevealToken } from "@/lib/api-client";
import { useT, type I18nKey } from "@/lib/i18n";
import { useAdminAuth } from "@/lib/admin-auth";
import { CatIcon } from "@/components/icon";
import { cn, grad } from "@/lib/utils";
import { DashCard, ViewHeading, fullDate } from "@/components/dashboard/dash-shared";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import type {
  EmailRevealConsumeDTO,
  EmailRevealMintDTO,
  EmailRevealTargetType,
} from "@/lib/types";

/** The five sealed-mailbox families + their presentation tiles. */
const TARGET_TYPES: {
  id: EmailRevealTargetType;
  labelKey: I18nKey;
  icon: string;
  c1: string;
  c2: string;
}[] = [
  { id: "subscriber", labelKey: "revealTargetSubscriber", icon: "mail", c1: "#6d5dfb", c2: "#06b6d4" },
  { id: "admin", labelKey: "revealTargetAdmin", icon: "shield-user", c1: "#f59e0b", c2: "#ea580c" },
  { id: "siteCustomer", labelKey: "revealTargetSiteCustomer", icon: "users", c1: "#10b981", c2: "#0ea5e9" },
  { id: "ticketRequester", labelKey: "revealTargetTicketRequester", icon: "headset", c1: "#d946ef", c2: "#8b5cf6" },
  /* ROUND 167 — an Enterprise quote lead (طلبات المؤسسات): the quotes inbox
   * masks by default; recovery rides the SAME one-time lever. */
  { id: "quote", labelKey: "revealTargetQuote", icon: "building", c1: "#0891b2", c2: "#6d5dfb" },
];

/** One selectable target-type tile (premium radio card). */
function TargetTypeTile({
  active,
  icon,
  c1,
  c2,
  label,
  onSelect,
}: {
  active: boolean;
  icon: string;
  c1: string;
  c2: string;
  label: string;
  onSelect: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onSelect}
      aria-pressed={active}
      className={cn(
        "flex min-w-0 flex-1 items-center gap-2.5 rounded-2xl border px-3.5 py-3 text-start transition active:scale-[0.98]",
        active
          ? "border-brand-400 bg-brand-500/10 shadow-[0_0_18px_-6px_rgba(109,93,251,0.45)]"
          : "border-slate-200/80 bg-white hover:border-brand-300 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-brand-400/40"
      )}
    >
      <span
        className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
        style={{ backgroundImage: grad(c1, c2) }}
        aria-hidden="true"
      >
        <CatIcon name={icon} className="h-[13px] w-[13px]" />
      </span>
      <span
        className={cn(
          "truncate text-[12.5px] font-extrabold",
          active ? "text-brand-600 dark:text-brand-300" : "text-slate-600 dark:text-slate-300"
        )}
      >
        {label}
      </span>
    </button>
  );
}

/** The raw-token reveal block — shown EXACTLY ONCE after a successful mint. */
function MintedTokenCard({ minted }: { minted: EmailRevealMintDTO }) {
  const { t, lang } = useT();
  const [nowMs, setNowMs] = useState(() => Date.now());

  /* live countdown to the 15-minute expiry */
  useEffect(() => {
    const id = window.setInterval(() => setNowMs(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const secondsLeft = Math.max(0, Math.floor((Date.parse(minted.expiresAt) - nowMs) / 1000));
  const expired = secondsLeft <= 0;
  const countdown = `${Math.floor(secondsLeft / 60)}:${String(secondsLeft % 60).padStart(2, "0")}`;

  return (
    <div className="rounded-2xl border border-amber-300/60 bg-linear-to-br from-amber-50/90 to-white p-4 shadow-lg shadow-amber-500/10 dark:border-amber-400/25 dark:from-amber-500/10 dark:to-transparent sm:p-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="flex items-center gap-2 text-[12.5px] font-extrabold text-amber-700 dark:text-amber-300">
          <CatIcon name="triangle-alert" className="h-4 w-4" />
          {t("revealTokenOnce")}
        </p>
        <Badge
          variant="secondary"
          className={cn(
            "gap-1.5 rounded-full px-3 py-1 font-mono text-[11px] font-bold",
            expired
              ? "bg-rose-500/10 text-rose-600 dark:text-rose-300"
              : "bg-emerald-500/10 text-emerald-600 dark:text-emerald-300"
          )}
        >
          <CatIcon name="clock" className="h-3 w-3" />
          <span dir="ltr">{expired ? t("revealExpired") : t("revealExpiresIn", { time: countdown })}</span>
        </Badge>
      </div>

      {/* the RAW token — mono, LTR, copyable; never rendered anywhere else */}
      <div className="mt-3 flex items-center gap-2 rounded-xl border border-slate-200 bg-white p-3 dark:border-white/10 dark:bg-[#0a0f1c]">
        <code
          dir="ltr"
          className="min-w-0 flex-1 truncate font-mono text-[12px] font-bold text-slate-800 dark:text-slate-100"
        >
          {minted.token}
        </code>
        <button
          type="button"
          onClick={() => {
            void navigator.clipboard.writeText(minted.token).then(() => toast.success(t("revealCopied")));
          }}
          title={t("revealCopy")}
          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-slate-200 text-slate-600 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:text-slate-300 dark:hover:border-brand-400/50 dark:hover:text-brand-300"
        >
          <CatIcon name="clipboard-check" className="h-4 w-4" />
        </button>
      </div>

      <p className="mt-2.5 text-[11px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
        {t("revealConsumeDesc")} · {t("revealRevealedAt")}: {fullDate(minted.expiresAt, lang)}
      </p>
    </div>
  );
}

/** The revealed-email card — the plaintext appears here EXACTLY ONCE. */
function RevealedEmailCard({ result }: { result: EmailRevealConsumeDTO }) {
  const { t, lang } = useT();
  const target = TARGET_TYPES.find((x) => x.id === result.targetType);

  return (
    <div className="rounded-2xl border border-emerald-300/60 bg-linear-to-br from-emerald-50/90 via-white to-cyan-50/80 p-4 shadow-lg shadow-emerald-500/10 dark:border-emerald-400/25 dark:from-emerald-500/10 dark:via-transparent dark:to-cyan-500/10 sm:p-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="flex items-center gap-2 text-[13px] font-extrabold text-emerald-700 dark:text-emerald-300">
          <CatIcon name="circle-check" className="h-4.5 w-4.5" />
          {t("revealResultTitle")}
        </p>
        <span className="rounded-full bg-emerald-500/15 px-2.5 py-1 text-[10.5px] font-extrabold text-emerald-700 dark:text-emerald-300">
          {t("revealOnceBadge")}
        </span>
      </div>

      {/* the recovered address — mono, LTR, copyable */}
      <div className="mt-3 flex items-center gap-2 rounded-xl border border-emerald-300/60 bg-white p-3.5 dark:border-emerald-400/20 dark:bg-[#0a0f1c]">
        <span
          className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-md"
          style={{ backgroundImage: grad(target?.c1 ?? "#10b981", target?.c2 ?? "#06b6d4") }}
          aria-hidden="true"
        >
          <CatIcon name="mail" className="h-[14px] w-[14px]" />
        </span>
        <code
          dir="ltr"
          className="min-w-0 flex-1 truncate font-mono text-[14px] font-extrabold text-slate-900 dark:text-white"
        >
          {result.email}
        </code>
        <button
          type="button"
          onClick={() => {
            void navigator.clipboard.writeText(result.email).then(() => toast.success(t("revealEmailCopied")));
          }}
          title={t("revealCopyEmail")}
          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-slate-200 text-slate-600 transition hover:border-emerald-300 hover:text-emerald-600 active:scale-95 dark:border-white/10 dark:text-slate-300 dark:hover:border-emerald-400/50 dark:hover:text-emerald-300"
        >
          <CatIcon name="clipboard-check" className="h-4 w-4" />
        </button>
      </div>

      {/* provenance — who minted, why, when */}
      <dl className="mt-3.5 grid gap-2.5 sm:grid-cols-3">
        <div className="rounded-xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.03]">
          <dt className="text-[10px] font-bold uppercase tracking-wide text-slate-400 dark:text-slate-500">
            {t("revealMintedBy")}
          </dt>
          <dd className="mt-0.5 truncate text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
            {result.mintedBy}
          </dd>
        </div>
        <div className="rounded-xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.03]">
          <dt className="text-[10px] font-bold uppercase tracking-wide text-slate-400 dark:text-slate-500">
            {t("revealRevealedAt")}
          </dt>
          <dd className="mt-0.5 truncate text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
            {fullDate(result.revealedAt, lang)}
          </dd>
        </div>
        <div className="rounded-xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.03]">
          <dt className="text-[10px] font-bold uppercase tracking-wide text-slate-400 dark:text-slate-500">
            {t("revealReasonLabel")}
          </dt>
          <dd className="mt-0.5 line-clamp-2 text-[12px] font-semibold leading-relaxed text-slate-600 dark:text-slate-300">
            {result.reason}
          </dd>
        </div>
      </dl>
    </div>
  );
}

export function AdminEmailReveal() {
  const { t } = useT();
  const { user } = useAdminAuth();
  const canManage = user?.role === "super";

  /* the mint form draft */
  const [targetType, setTargetType] = useState<EmailRevealTargetType>("subscriber");
  const [targetId, setTargetId] = useState("");
  const [instanceId, setInstanceId] = useState("");
  const [reason, setReason] = useState("");
  /* the RAW token — held in state ONLY between mint and the operator's copy */
  const [minted, setMinted] = useState<EmailRevealMintDTO | null>(null);
  /* the consume form */
  const [tokenInput, setTokenInput] = useState("");
  const [revealed, setRevealed] = useState<EmailRevealConsumeDTO | null>(null);

  const mint = useMutation({
    mutationFn: () =>
      mintEmailRevealToken({
        targetType,
        targetId: targetId.trim(),
        /* optional tenant scope — sent only when non-empty */
        ...(instanceId.trim() ? { instanceId: instanceId.trim() } : {}),
        reason: reason.trim(),
      }),
    onSuccess: (data) => {
      setMinted(data);
      toast.success(t("revealMintTitle"));
    },
    onError: (error: Error) =>
      toast.error(
        error.message ? `${t("revealMintErr")} — ${error.message}` : t("revealMintErr")
      ),
  });

  const consume = useMutation({
    mutationFn: () => consumeEmailRevealToken(tokenInput.trim()),
    onSuccess: (data) => {
      setRevealed(data);
      setTokenInput("");
      setMinted(null);
      toast.success(t("revealResultTitle"));
    },
    onError: (error: Error) =>
      toast.error(
        error.message ? `${t("revealConsumeErr")} — ${error.message}` : t("revealConsumeErr")
      ),
  });

  const submitMint = () => {
    if (!canManage || mint.isPending) return;
    if (!targetId.trim() || !reason.trim()) return;
    mint.mutate();
  };

  const submitConsume = () => {
    if (!canManage || consume.isPending) return;
    if (!tokenInput.trim()) return;
    consume.mutate();
  };

  return (
    <div className="space-y-5">
      <ViewHeading title={t("revealNav")} desc={t("revealDesc")} />

      {/* the security-model explainer — always visible, every role */}
      <DashCard title={t("revealExplainerTitle")} icon="shield-check">
        <ul className="space-y-2.5">
          {(["revealExplainerPoint1", "revealExplainerPoint2", "revealExplainerPoint3"] as const).map(
            (key) => (
              <li key={key} className="flex items-start gap-2.5">
                <span
                  className="mt-0.5 grid h-5.5 w-5.5 shrink-0 place-items-center rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-300"
                  aria-hidden="true"
                >
                  <CatIcon name="circle-check" className="h-3 w-3" />
                </span>
                <span className="text-[12.5px] font-semibold leading-relaxed text-slate-600 dark:text-slate-300">
                  {t(key)}
                </span>
              </li>
            )
          )}
        </ul>
      </DashCard>

      {canManage ? (
        <div className="grid gap-5 xl:grid-cols-2">
          {/* ---------------- the mint form ---------------- */}
          <DashCard title={t("revealMintTitle")} icon="key-round">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                submitMint();
              }}
              className="space-y-4"
            >
              {/* target type — premium radio tiles */}
              <div className="space-y-1.5">
                <Label htmlFor="reveal-target-type" className="block text-[12.5px] font-extrabold leading-tight text-slate-800 dark:text-slate-100">
                  {t("revealTargetType")}
                </Label>
                <div className="flex flex-wrap gap-2" id="reveal-target-type" role="group">
                  {TARGET_TYPES.map((item) => (
                    <TargetTypeTile
                      key={item.id}
                      active={targetType === item.id}
                      icon={item.icon}
                      c1={item.c1}
                      c2={item.c2}
                      label={t(item.labelKey)}
                      onSelect={() => setTargetType(item.id)}
                    />
                  ))}
                </div>
              </div>

              {/* target id */}
              <div className="space-y-1.5">
                <Label htmlFor="reveal-target-id" className="block text-[12.5px] font-extrabold leading-tight text-slate-800 dark:text-slate-100">
                  {t("revealTargetId")}
                </Label>
                <Input
                  id="reveal-target-id"
                  type="text"
                  dir="ltr"
                  value={targetId}
                  maxLength={64}
                  disabled={mint.isPending}
                  placeholder={t("revealTargetIdPh")}
                  onChange={(e) => setTargetId(e.target.value)}
                  className="w-full text-start"
                />
                <p className="text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                  {t("revealTargetIdHint")}
                </p>
              </div>

              {/* optional tenant scope */}
              <div className="space-y-1.5">
                <Label htmlFor="reveal-instance-id" className="block text-[12.5px] font-extrabold leading-tight text-slate-800 dark:text-slate-100">
                  {t("revealInstanceId")}
                </Label>
                <Input
                  id="reveal-instance-id"
                  type="text"
                  dir="ltr"
                  value={instanceId}
                  maxLength={64}
                  disabled={mint.isPending}
                  placeholder={t("revealTargetIdPh")}
                  onChange={(e) => setInstanceId(e.target.value)}
                  className="w-full text-start"
                />
                <p className="text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                  {t("revealInstanceIdHint")}
                </p>
              </div>

              {/* the mandatory justification */}
              <div className="space-y-1.5">
                <Label htmlFor="reveal-reason" className="block text-[12.5px] font-extrabold leading-tight text-slate-800 dark:text-slate-100">
                  {t("revealReason")}
                </Label>
                <Textarea
                  id="reveal-reason"
                  value={reason}
                  maxLength={200}
                  rows={3}
                  disabled={mint.isPending}
                  placeholder={t("revealReasonPh")}
                  onChange={(e) => setReason(e.target.value)}
                  className="min-h-20 w-full resize-none text-start text-[12.5px]"
                />
              </div>

              <Button
                type="submit"
                disabled={mint.isPending || !targetId.trim() || !reason.trim()}
                className="h-11 w-full gap-2 rounded-xl bg-linear-to-l from-brand-600 via-fuchsia-500 to-cyan-400 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/30 transition hover:brightness-110 active:scale-95 disabled:opacity-50"
              >
                {mint.isPending ? (
                  <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                ) : (
                  <CatIcon name="key-round" className="h-4 w-4" />
                )}
                {t("revealMintBtn")}
              </Button>
            </form>

            {/* the RAW token — rendered EXACTLY ONCE, right under the mint */}
            {minted ? (
              <div className="mt-4">
                <MintedTokenCard minted={minted} />
              </div>
            ) : null}
          </DashCard>

          {/* ---------------- the consume form ---------------- */}
          <div className="space-y-5">
            <DashCard title={t("revealConsumeTitle")} icon="unlock">
              <p className="mb-4 text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                {t("revealConsumeDesc")}
              </p>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  submitConsume();
                }}
                className="space-y-4"
              >
                <div className="space-y-1.5">
                  <Label htmlFor="reveal-token" className="block text-[12.5px] font-extrabold leading-tight text-slate-800 dark:text-slate-100">
                    {t("revealTokenField")}
                  </Label>
                  <Textarea
                    id="reveal-token"
                    dir="ltr"
                    value={tokenInput}
                    maxLength={128}
                    rows={2}
                    disabled={consume.isPending}
                    placeholder={t("revealTokenPh")}
                    onChange={(e) => setTokenInput(e.target.value)}
                    className="min-h-16 w-full resize-none font-mono text-start text-[12px]"
                  />
                </div>
                <Button
                  type="submit"
                  disabled={consume.isPending || !tokenInput.trim()}
                  className="h-11 w-full gap-2 rounded-xl bg-linear-to-l from-emerald-600 via-teal-500 to-cyan-400 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-emerald-500/30 transition hover:brightness-110 active:scale-95 disabled:opacity-50"
                >
                  {consume.isPending ? (
                    <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                  ) : (
                    <CatIcon name="unlock" className="h-4 w-4" />
                  )}
                  {t("revealConsumeBtn")}
                </Button>
              </form>
            </DashCard>

            {/* the revealed email — rendered EXACTLY ONCE per successful consume */}
            {revealed ? <RevealedEmailCard result={revealed} /> : null}
          </div>
        </div>
      ) : (
        /* non-super roles — the explainer + the permission notice only */
        <DashCard>
          <div className="py-10 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-amber-100 text-amber-500 dark:bg-amber-500/10 dark:text-amber-300">
              <CatIcon name="lock" className="h-6 w-6" />
            </div>
            <p className="mt-3 font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("adminNoPerm")}
            </p>
          </div>
        </DashCard>
      )}
    </div>
  );
}

export default AdminEmailReveal;
