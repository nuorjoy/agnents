"use client";

/**
 * Ashrilogic — Super Admin tenant messaging center (مركز الرسائل) —
 * ROUND 169 (رسائل المشتركين).
 *
 * The owner's directive: «an innovative way to send welcome messages to
 * new subscribers, or offer/discount messages about add-ons, packages, or
 * new updates». The SEGMENTED COMPOSER:
 *  - AUDIENCE: the newsletter list, EVERY live subscriber (each workspace
 *    owner's sealed mailbox) or ONE plan's subscribers (package picker —
 *    the CURRENT package match, the wallet-grants law);
 *  - MESSAGE FAMILY: ترحيب / عرض / خصم / تحديث / عام chips, each with its
 *    own color + icon;
 *  - TEMPLATE TOKENS: {name} {org} {plan} {amount} injected by buttons —
 *    substituted per recipient at delivery from the recipient's own row
 *    (orgJson name / adminJson name / CURRENT package + price); unknown
 *    tokens stay literal;
 *  - LIVE PREVIEW: the email mockup with a sample recipient's values +
 *    the LIVE audience count (the GET preview) BEFORE anything is claimed;
 *  - HONEST DISPATCH: the send is a CLAIM — draft → sending (progress) →
 *    sent with delivered/failed/queued evidence (the durable dispatcher
 *    owns the delivery; the list polls while anything is "sending").
 *
 * Design follows the admin-wallet-grants + admin-newsletter idioms —
 * pipeline cards, gradient tiles, the campaign status surfaces.
 */
import { useMemo, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  fetchAdminCampaigns,
  fetchCampaignAudiencePreview,
  fetchPackages,
  createAdminCampaign,
  updateAdminCampaign,
  sendAdminCampaign,
  deleteAdminCampaign,
  type CampaignComposerPayload,
} from "@/lib/api-client";
import { useAdminCanManage } from "@/lib/admin-auth";
import { useT, type I18nKey } from "@/lib/i18n";
import type { CampaignAudienceTarget, CampaignDTO, PackageDTO } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { DashCard, ViewHeading, relativeTime } from "@/components/dashboard/dash-shared";
import { KpiCard } from "@/components/shared/kpi-card";

/* ------------------------------------------------------------------ */
/* static registries                                                   */
/* ------------------------------------------------------------------ */

/** The message families — color + icon per chip (the composer + the list). */
const KIND_META: Record<string, { key: I18nKey; icon: string; c1: string; c2: string }> = {
  welcome: { key: "msgKindWelcome", icon: "hand-heart", c1: "#10b981", c2: "#059669" },
  offer: { key: "msgKindOffer", icon: "tag", c1: "#f59e0b", c2: "#d97706" },
  discount: { key: "msgKindDiscount", icon: "percent", c1: "#f43f5e", c2: "#e11d48" },
  update: { key: "msgKindUpdate", icon: "megaphone", c1: "#0ea5e9", c2: "#0891b2" },
  broadcast: { key: "msgKindBroadcast", icon: "send", c1: "#6d5dfb", c2: "#8b5cf6" },
};

function kindMeta(kind: string) {
  return KIND_META[kind] ?? KIND_META.broadcast!;
}

/** The audience label for a campaign row (parsed from the stored string). */
function audienceLabelKey(audience: string): I18nKey {
  if (audience === "tenants") return "msgAudienceTenants";
  if (audience.startsWith("tenants:plan:")) return "msgAudiencePlan";
  return "msgAudienceSubscribers";
}

/** The composer's target derived from a stored audience string (edit mode). */
function targetOf(audience: string): { target: CampaignAudienceTarget; packageId: string } {
  if (audience === "tenants") return { target: "tenants", packageId: "" };
  if (audience.startsWith("tenants:plan:")) {
    return { target: "tenants:plan", packageId: audience.slice("tenants:plan:".length) };
  }
  return { target: "subscribers", packageId: "" };
}

/** The template tokens the composer injects (the delivery-time law). */
const TOKENS: { token: string; key: I18nKey; icon: string }[] = [
  { token: "{{name}}", key: "msgTokenName", icon: "user-round" },
  { token: "{{org}}", key: "msgTokenOrg", icon: "building" },
  { token: "{{plan}}", key: "msgTokenPlan", icon: "package" },
  { token: "{{amount}}", key: "msgTokenAmount", icon: "coins" },
];

/** Client-side preview substitution — the SAME token grammar the
 * dispatcher applies per recipient at enqueue time. */
function substitutePreview(text: string, vars: Record<string, string>): string {
  return text.replace(/\{\{\s*(name|org|plan|amount)\s*\}\}/g, (match, token: string) => vars[token] ?? match);
}

/* ------------------------------------------------------------------ */
/* the composer's audience target card                                 */
/* ------------------------------------------------------------------ */

function TargetCard({
  active,
  icon,
  c1,
  c2,
  title,
  hint,
  onClick,
  disabled,
}: {
  active: boolean;
  icon: string;
  c1: string;
  c2: string;
  title: string;
  hint: string;
  onClick: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-pressed={active}
      className={cn(
        "flex w-full items-start gap-3 rounded-2xl border p-3.5 text-start transition active:scale-[0.98] disabled:opacity-60",
        active
          ? "border-brand-400 bg-brand-500/[0.07] shadow-lg shadow-brand-500/10 dark:border-brand-500/50 dark:bg-brand-500/10"
          : "border-slate-200 bg-white/70 hover:border-slate-300 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-white/20"
      )}
    >
      <span
        className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
        style={{ backgroundImage: grad(c1, c2) }}
        aria-hidden="true"
      >
        <CatIcon name={icon} className="h-4 w-4" />
      </span>
      <span className="min-w-0">
        <span className="flex items-center gap-2 text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
          {title}
          {active ? <CatIcon name="circle-check" className="h-3.5 w-3.5 text-brand-500" /> : null}
        </span>
        <span className="mt-0.5 block text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
          {hint}
        </span>
      </span>
    </button>
  );
}

/* ================================================================== */
/* the view                                                            */
/* ================================================================== */

export function AdminMessages() {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const canManage = useAdminCanManage();

  /* ---------------- composer state ---------------- */
  const [target, setTarget] = useState<CampaignAudienceTarget>("subscribers");
  const [packageId, setPackageId] = useState("");
  const [kind, setKind] = useState<string>("broadcast");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [editing, setEditing] = useState<CampaignDTO | null>(null);
  /* dialogs */
  const [confirmSend, setConfirmSend] = useState<CampaignDTO | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<CampaignDTO | null>(null);
  const [previewCampaign, setPreviewCampaign] = useState<CampaignDTO | null>(null);
  /* filters */
  const [kindFilter, setKindFilter] = useState<string>("all");
  const [audienceFilter, setAudienceFilter] = useState<string>("all");

  const bodyRef = useRef<HTMLTextAreaElement | null>(null);

  /* ---------------- data ---------------- */
  const query = useQuery({
    queryKey: ["admin-campaigns"],
    queryFn: fetchAdminCampaigns,
    staleTime: 30_000,
    retry: 1,
    /* a campaign mid-dispatch is progressing server-side — poll until it
     * settles so the archive reflects the honest lifecycle */
    refetchInterval: (q) =>
      (q.state.data?.campaigns ?? []).some((c) => c.status === "sending") ? 15_000 : false,
  });
  const campaigns = query.data?.campaigns ?? [];

  const packagesQuery = useQuery({
    queryKey: ["packages"],
    queryFn: fetchPackages,
    staleTime: 60_000,
    enabled: target === "tenants:plan",
  });
  const packages = useMemo(() => packagesQuery.data ?? [], [packagesQuery.data]);

  /* the LIVE audience preview (the wallet-grants law: BEFORE any claim) */
  const audienceKey = target === "tenants:plan" ? `plan:${packageId}` : target;
  const audienceQuery = useQuery({
    queryKey: ["campaign-audience", audienceKey],
    queryFn: () =>
      fetchCampaignAudiencePreview({
        target,
        ...(target === "tenants:plan" && packageId ? { packageId } : {}),
      }),
    enabled: target !== "tenants:plan" || packageId !== "",
    staleTime: 15_000,
    retry: 1,
  });
  const audienceCount = audienceQuery.data?.count ?? null;
  const selectedPackage: PackageDTO | null = packages.find((p) => p.id === packageId) ?? null;

  /* ---------------- mutations ---------------- */
  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["admin-campaigns"] });

  const saveDraft = useMutation({
    mutationFn: () => {
      const payload: CampaignComposerPayload = {
        subject: subject.trim(),
        body: body.trim(),
        kind: kind as CampaignComposerPayload["kind"],
        ...(target !== "subscribers" ? { audience: target } : {}),
        ...(target === "tenants:plan" && packageId ? { packageId } : {}),
      };
      return editing
        ? updateAdminCampaign(editing.id, payload)
        : createAdminCampaign(payload);
    },
    onSuccess: () => {
      toast.success(t(editing ? "msgUpdatedToast" : "msgCreatedToast"));
      setEditing(null);
      setSubject("");
      setBody("");
      setKind("broadcast");
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message || t("errorText")),
  });

  const send = useMutation({
    mutationFn: (id: string) => sendAdminCampaign(id),
    onSuccess: (row) => {
      /* the send is a CLAIM — delivery runs in the durable dispatcher */
      toast.success(t("msgDispatchToast", { n: fmtNum(row.recipients, lang) }));
      setConfirmSend(null);
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message || t("errorText")),
  });

  const remove = useMutation({
    mutationFn: (id: string) => deleteAdminCampaign(id),
    onSuccess: () => {
      toast.success(t("msgDeletedToast"));
      setConfirmDelete(null);
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message || t("errorText")),
  });

  /* ---------------- compose actions ---------------- */
  const submit = () => {
    const s = subject.trim();
    const b = body.trim();
    if (s.length < 3 || s.length > 120) {
      toast.error(t("msgErrSubject"));
      return;
    }
    if (b.length < 10 || b.length > 5000) {
      toast.error(t("msgErrBody"));
      return;
    }
    if (target === "tenants:plan" && !packageId) {
      toast.error(t("msgPackagePh"));
      return;
    }
    saveDraft.mutate();
  };

  const openEdit = (c: CampaignDTO) => {
    const resolved = targetOf(c.audience);
    setTarget(resolved.target);
    setPackageId(resolved.packageId);
    setKind(c.kind);
    setSubject(c.subject);
    setBody(c.body);
    setEditing(c);
  };

  const resetComposer = () => {
    setEditing(null);
    setTarget("subscribers");
    setPackageId("");
    setKind("broadcast");
    setSubject("");
    setBody("");
  };

  /** Insert a template token at the body cursor (append as fallback). */
  const insertToken = (token: string) => {
    const el = bodyRef.current;
    if (!el) {
      setBody((prev) => `${prev}${token}`);
      return;
    }
    const start = el.selectionStart ?? body.length;
    const end = el.selectionEnd ?? body.length;
    const next = `${body.slice(0, start)}${token}${body.slice(end)}`;
    setBody(next);
    requestAnimationFrame(() => {
      el.focus();
      const caret = start + token.length;
      el.setSelectionRange(caret, caret);
    });
  };

  /* the LIVE PREVIEW sample vars — the plan/amount tokens resolve from the
   * SELECTED package when one is picked (the name/org pair stays a sample). */
  const previewVars = useMemo<Record<string, string>>(() => {
    const vars: Record<string, string> = {
      name: t("msgSampleName"),
      org: t("msgSampleOrg"),
    };
    if (selectedPackage) {
      vars.plan = `${selectedPackage.nameAr} · ${selectedPackage.nameEn}`;
      vars.amount = `${fmtNum(selectedPackage.priceMonthly / 100, lang)} ${selectedPackage.currency}`;
    }
    return vars;
  }, [selectedPackage, t, lang]);

  const previewSubject = substitutePreview(subject, previewVars);
  const previewBody = substitutePreview(body, previewVars);

  /* ---------------- the filtered archive ---------------- */
  const filtered = useMemo(
    () =>
      campaigns.filter((c) => {
        if (kindFilter !== "all" && c.kind !== kindFilter) return false;
        if (audienceFilter === "subscribers" && c.audience !== "subscribers") return false;
        if (audienceFilter === "tenants" && c.audience !== "tenants") return false;
        if (audienceFilter === "plan" && !c.audience.startsWith("tenants:plan:")) return false;
        return true;
      }),
    [campaigns, kindFilter, audienceFilter]
  );

  const tenantsTarget = target !== "subscribers";

  return (
    <div className="space-y-5">
      <ViewHeading title={t("msgTitle")} desc={t("msgDesc")} />

      <div className="grid gap-5 lg:grid-cols-3">
        {/* ---------------- the segmented composer ---------------- */}
        <DashCard
          title={t(editing ? "msgComposerEditTitle" : "msgComposerTitle")}
          icon="megaphone"
          className="lg:col-span-2"
          action={
            editing ? (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={resetComposer}
                className="h-8 rounded-lg px-3 text-[11px] font-bold"
              >
                <CatIcon name="plus" className="h-3.5 w-3.5" />
                {t("msgComposerTitle")}
              </Button>
            ) : null
          }
        >
          <div className="space-y-4">
            {/* audience picker */}
            <div>
              <Label className="text-[12px] font-extrabold leading-tight text-slate-700 dark:text-slate-200">
                {t("msgAudienceLabel")}
              </Label>
              <div className="mt-2 grid gap-2.5 sm:grid-cols-3">
                <TargetCard
                  active={target === "subscribers"}
                  icon="mail"
                  c1="#6d5dfb"
                  c2="#8b5cf6"
                  title={t("msgAudienceSubscribers")}
                  hint={t("msgAudienceSubscribersHint")}
                  onClick={() => setTarget("subscribers")}
                  disabled={!canManage}
                />
                <TargetCard
                  active={target === "tenants"}
                  icon="users"
                  c1="#0ea5e9"
                  c2="#0891b2"
                  title={t("msgAudienceTenants")}
                  hint={t("msgAudienceTenantsHint")}
                  onClick={() => setTarget("tenants")}
                  disabled={!canManage}
                />
                <TargetCard
                  active={target === "tenants:plan"}
                  icon="package"
                  c1="#f59e0b"
                  c2="#d97706"
                  title={t("msgAudiencePlan")}
                  hint={t("msgAudiencePlanHint")}
                  onClick={() => setTarget("tenants:plan")}
                  disabled={!canManage}
                />
              </div>
            </div>

            {/* package picker (plan target) */}
            {target === "tenants:plan" ? (
              <div className="space-y-1.5">
                <Label htmlFor="msg-package" className="text-[12px] font-extrabold leading-tight text-slate-700 dark:text-slate-200">
                  {t("msgPackageLabel")}
                </Label>
                {packagesQuery.isPending ? (
                  <Skeleton className="h-11 w-full rounded-xl" />
                ) : (
                  <Select
                    value={packageId}
                    onValueChange={(v) => setPackageId(v)}
                    dir={lang === "ar" ? "rtl" : "ltr"}
                    disabled={!canManage}
                  >
                    <SelectTrigger id="msg-package" className="h-11 w-full rounded-xl">
                      <SelectValue placeholder={t("msgPackagePh")} />
                    </SelectTrigger>
                    <SelectContent className="rounded-xl">
                      <SelectGroup>
                        {packages.map((pkg) => (
                          <SelectItem key={pkg.id} value={pkg.id} className="text-[12.5px] font-bold">
                            <span className="flex min-w-0 items-center gap-2">
                              <span className="truncate">{lang === "ar" ? pkg.nameAr : pkg.nameEn}</span>
                              <span dir="ltr" className="ms-auto shrink-0 text-[10px] font-extrabold text-slate-400">
                                {fmtNum(pkg.priceMonthly / 100, lang)} {pkg.currency}
                              </span>
                            </span>
                          </SelectItem>
                        ))}
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                )}
              </div>
            ) : null}

            {/* message family chips */}
            <div>
              <Label className="text-[12px] font-extrabold leading-tight text-slate-700 dark:text-slate-200">
                {t("msgKindLabel")}
              </Label>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {Object.entries(KIND_META).map(([value, meta]) => {
                  const active = kind === value;
                  return (
                    <button
                      key={value}
                      type="button"
                      onClick={() => setKind(value)}
                      disabled={!canManage}
                      aria-pressed={active}
                      className={cn(
                        "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11.5px] font-extrabold transition active:scale-95 disabled:opacity-60",
                        active
                          ? "border-transparent text-white shadow-md"
                          : "border-slate-200 bg-white/70 text-slate-500 hover:border-slate-300 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-400"
                      )}
                      style={active ? { backgroundImage: grad(meta.c1, meta.c2) } : undefined}
                    >
                      <CatIcon name={meta.icon} className="h-3.5 w-3.5" />
                      {t(meta.key)}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* subject */}
            <div className="space-y-1.5">
              <Label htmlFor="msg-subject" className="text-[12px] font-extrabold leading-tight text-slate-700 dark:text-slate-200">
                {t("msgSubjectLabel")}
              </Label>
              <Input
                id="msg-subject"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder={t("msgSubjectPh")}
                maxLength={120}
                disabled={!canManage}
                dir="auto"
                className="h-11 rounded-xl text-[13px] font-semibold"
              />
            </div>

            {/* body + template tokens */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label htmlFor="msg-body" className="text-[12px] font-extrabold leading-tight text-slate-700 dark:text-slate-200">
                  {t("msgBodyLabel")}
                </Label>
                <span dir="ltr" className="font-mono text-[10px] font-bold tabular-nums text-slate-400 dark:text-slate-500">
                  {fmtNum(body.length, lang)} / 5,000
                </span>
              </div>
              <Textarea
                id="msg-body"
                ref={bodyRef}
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder={t("msgBodyPh")}
                maxLength={5000}
                rows={7}
                disabled={!canManage}
                dir="auto"
                className="rounded-xl text-[13px] leading-relaxed"
              />
              <div className="rounded-xl border border-slate-200/80 bg-slate-50/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.03]">
                <p className="text-[10.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500" dir="auto">
                  {t("msgTokensLabel")}
                </p>
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  {TOKENS.map((tok) => (
                    <button
                      key={tok.token}
                      type="button"
                      onClick={() => insertToken(tok.token)}
                      disabled={!canManage}
                      title={t(tok.key)}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-1 font-mono text-[10.5px] font-bold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 disabled:opacity-60 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-300"
                    >
                      <CatIcon name={tok.icon} className="h-3 w-3 text-slate-400" />
                      {tok.token}
                    </button>
                  ))}
                </div>
                <p className="mt-1.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                  {t("msgTokensHint")}
                  {tenantsTarget ? ` ${t("msgPlanHint")}` : ""}
                </p>
              </div>
            </div>

            {/* the save CTA */}
            <Button
              type="button"
              onClick={submit}
              disabled={!canManage || saveDraft.isPending}
              className="h-12 w-full gap-2 rounded-2xl bg-linear-to-l from-brand-600 to-fuchsia-500 text-[13px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-[0.98] disabled:opacity-50"
            >
              <CatIcon
                name={saveDraft.isPending ? "refresh-cw" : editing ? "check" : "plus"}
                className={cn("h-4 w-4", saveDraft.isPending && "animate-spin")}
              />
              {t(editing ? "msgUpdateBtn" : "msgCreateBtn")}
            </Button>
          </div>
        </DashCard>

        {/* ---------------- live audience + preview ---------------- */}
        <div className="space-y-5">
          <KpiCard
            label={t("msgAudienceCountLabel")}
            numeric={audienceCount ?? 0}
            icon="users"
            c1="#6d5dfb"
            c2="#06b6d4"
            index={0}
          />
          <DashCard>
            {audienceQuery.isError ? (
              <p className="text-[11.5px] font-semibold leading-relaxed text-rose-500 dark:text-rose-300">
                {t("msgAudienceErr")}
              </p>
            ) : audienceQuery.isPending ? (
              <Skeleton className="h-4 w-40 rounded-lg" />
            ) : (
              <p className="text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                {audienceQuery.data?.packageName ?? t("msgAudienceCountHint")}
              </p>
            )}
            {(audienceCount ?? 0) === 0 && !audienceQuery.isPending && !audienceQuery.isError ? (
              <p className="mt-2 text-[11px] font-bold text-amber-600 dark:text-amber-300">{t("msgAudienceEmpty")}</p>
            ) : null}
          </DashCard>

          {/* the LIVE PREVIEW — the email mockup with the sample values */}
          <DashCard title={t("msgPreviewTitle")} icon="eye">
            <div className="overflow-hidden rounded-2xl border border-slate-200 dark:border-white/10">
              <div className="space-y-1 border-b border-slate-200 bg-slate-50/80 px-3.5 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
                <div className="flex flex-wrap items-center gap-1.5 text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
                  <CatIcon name="mail" className="h-3 w-3 text-slate-400" />
                  <span dir="ltr" className="truncate font-mono text-slate-700 dark:text-slate-200">
                    newsletter@ashrilogic.com
                  </span>
                </div>
              </div>
              <div className="px-3.5 py-3">
                <p className="font-display text-[13.5px] font-extrabold text-slate-900 dark:text-white" dir="auto">
                  {previewSubject || t("msgSubjectPh")}
                </p>
                <p className="mt-2 whitespace-pre-line text-[12px] leading-[1.85] text-slate-600 dark:text-slate-300" dir="auto">
                  {previewBody || t("msgBodyPh")}
                </p>
              </div>
            </div>
            <p className="mt-2.5 flex items-start gap-1.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              <CatIcon name="info" className="mt-px h-3 w-3 shrink-0" />
              {t("msgPreviewNote")}
            </p>
          </DashCard>
        </div>
      </div>

      {/* ---------------- the campaign archive ---------------- */}
      <DashCard title={t("msgListTitle")} icon="send">
        <p className="mt-0.5 text-[12px] leading-relaxed text-slate-500 dark:text-slate-400">{t("msgListDesc")}</p>

        {/* filters */}
        <div className="mt-3 flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="text-[10.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500">
              {t("msgFilterKindLabel")}
            </span>
            <div className="flex flex-wrap gap-1">
              {["all", ...Object.keys(KIND_META)].map((value) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setKindFilter(value)}
                  aria-pressed={kindFilter === value}
                  className={cn(
                    "rounded-full px-2.5 py-1 text-[10.5px] font-extrabold transition active:scale-95",
                    kindFilter === value
                      ? "bg-brand-500/10 text-brand-600 dark:text-brand-300"
                      : "text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-white/[0.06] dark:hover:text-slate-300"
                  )}
                >
                  {t(value === "all" ? "msgFilterKindAll" : kindMeta(value).key)}
                </button>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-[10.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500">
              {t("msgFilterAudienceLabel")}
            </span>
            <div className="flex flex-wrap gap-1">
              {(["all", "subscribers", "tenants", "plan"] as const).map((value) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setAudienceFilter(value)}
                  aria-pressed={audienceFilter === value}
                  className={cn(
                    "rounded-full px-2.5 py-1 text-[10.5px] font-extrabold transition active:scale-95",
                    audienceFilter === value
                      ? "bg-brand-500/10 text-brand-600 dark:text-brand-300"
                      : "text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-white/[0.06] dark:hover:text-slate-300"
                  )}
                >
                  {t(
                    value === "all"
                      ? "msgFilterAudienceAll"
                      : value === "subscribers"
                        ? "msgAudienceSubscribers"
                        : value === "tenants"
                          ? "msgAudienceTenants"
                          : "msgAudiencePlan"
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* the list */}
        <div className="mt-3">
          {query.isPending ? (
            <div className="space-y-2.5">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-24 w-full rounded-2xl" />
              ))}
            </div>
          ) : query.isError ? (
            <div className="rounded-2xl border border-rose-200 bg-rose-50/70 p-5 text-center text-[12.5px] font-bold text-rose-600 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-300">
              {t("errorText")}
            </div>
          ) : filtered.length === 0 ? (
            <div className="rounded-2xl border-2 border-dashed border-slate-200 p-7 text-center dark:border-white/10">
              <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-brand-500/10 text-brand-500 dark:text-brand-300">
                <CatIcon name="megaphone" className="h-5 w-5" />
              </div>
              <p className="mt-3 font-display text-[13.5px] font-extrabold text-slate-600 dark:text-slate-300">
                {t("msgEmptyTitle")}
              </p>
              <p className="mx-auto mt-1 max-w-sm text-[11.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                {t("msgEmptyDesc")}
              </p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {filtered.map((c) => {
                const sent = c.status === "sent";
                const sending = c.status === "sending";
                const meta = kindMeta(c.kind);
                return (
                  <article
                    key={c.id}
                    className="group rounded-2xl border border-slate-200/80 bg-white/80 p-3.5 transition hover:border-brand-300/70 hover:shadow-soft dark:border-white/[0.07] dark:bg-white/[0.03] dark:hover:border-brand-500/40"
                  >
                    <div className="flex flex-wrap items-center gap-2">
                      {/* kind chip */}
                      <span
                        className="inline-flex shrink-0 items-center gap-1 rounded-full px-2.5 py-0.5 text-[10px] font-extrabold text-white"
                        style={{ backgroundImage: grad(meta.c1, meta.c2) }}
                      >
                        <CatIcon name={meta.icon} className="h-[10px] w-[10px]" />
                        {t(meta.key)}
                      </span>
                      {/* audience chip */}
                      <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-slate-200 px-2.5 py-0.5 text-[10px] font-extrabold text-slate-500 dark:border-white/10 dark:text-slate-400">
                        <CatIcon name="users" className="h-[10px] w-[10px]" />
                        {t(audienceLabelKey(c.audience))}
                      </span>
                      {/* status chip */}
                      <span
                        className={cn(
                          "inline-flex shrink-0 items-center gap-1 rounded-full border px-2.5 py-0.5 text-[10px] font-extrabold",
                          sent
                            ? "border-emerald-400/60 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
                            : sending
                              ? "border-sky-400/60 bg-sky-500/10 text-sky-600 dark:border-sky-500/40 dark:text-sky-300"
                              : "border-amber-400/60 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-400"
                        )}
                      >
                        <CatIcon name={sent ? "send" : sending ? "clock" : "pencil"} className="h-[10px] w-[10px]" />
                        {t(
                          sent
                            ? "newsCampaignSentBadge"
                            : sending
                              ? "newsCampaignSendingBadge"
                              : "newsCampaignDraftBadge"
                        )}
                      </span>
                      <p className="min-w-0 flex-1 truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
                        {c.subject}
                      </p>
                      <span
                        title={c.createdAt}
                        className="shrink-0 text-[10.5px] font-bold text-slate-400 dark:text-slate-500"
                      >
                        {relativeTime(c.createdAt, lang)}
                      </span>
                    </div>

                    <p className="mt-1.5 line-clamp-2 text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                      {c.body}
                    </p>

                    {/* delivery evidence */}
                    <div className="mt-2.5 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-2.5 dark:border-white/[0.06]">
                      <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2.5 py-0.5 text-[10.5px] font-extrabold tabular-nums text-slate-500 dark:bg-white/10 dark:text-slate-400" dir="ltr">
                        <CatIcon name="users" className="h-[10px] w-[10px]" />
                        {t("msgStatRecipients")}: {fmtNum(c.recipients, lang)}
                      </span>
                      {c.status !== "draft" ? (
                        <>
                          <span className="inline-flex items-center gap-1 rounded-full bg-sky-500/10 px-2.5 py-0.5 text-[10.5px] font-extrabold tabular-nums text-sky-600 dark:text-sky-300" dir="ltr">
                            <CatIcon name="inbox" className="h-[10px] w-[10px]" />
                            {t("msgStatEnqueued")}: {fmtNum(c.dispatchEnqueued, lang)}
                          </span>
                          <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2.5 py-0.5 text-[10.5px] font-extrabold tabular-nums text-emerald-600 dark:text-emerald-300" dir="ltr">
                            <CatIcon name="circle-check" className="h-[10px] w-[10px]" />
                            {t("msgStatDelivered")}: {fmtNum(c.delivered, lang)}
                          </span>
                          {c.failed > 0 ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-rose-500/10 px-2.5 py-0.5 text-[10.5px] font-extrabold tabular-nums text-rose-600 dark:text-rose-300" dir="ltr">
                              <CatIcon name="triangle-alert" className="h-[10px] w-[10px]" />
                              {t("msgStatFailed")}: {fmtNum(c.failed, lang)}
                            </span>
                          ) : null}
                        </>
                      ) : (
                        <span className="text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                          {t("msgDraftHint")}
                        </span>
                      )}

                      <div className="ms-auto flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => setPreviewCampaign(c)}
                          aria-label={`${t("msgViewBtn")} — ${c.subject}`}
                          title={t("msgViewBtn")}
                          className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-sky-300 hover:text-sky-600 active:scale-95 dark:border-white/10 dark:text-slate-300 dark:hover:border-sky-500/40 dark:hover:text-sky-300"
                        >
                          <CatIcon name="eye" className="h-[14px] w-[14px]" />
                        </button>
                        {canManage && !sent && !sending ? (
                          <>
                            <button
                              type="button"
                              onClick={() => openEdit(c)}
                              aria-label={`${t("msgEditBtn")} — ${c.subject}`}
                              title={t("msgEditBtn")}
                              className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
                            >
                              <CatIcon name="pencil" className="h-[14px] w-[14px]" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmSend(c)}
                              aria-label={`${t("msgSendBtnIcon")} — ${c.subject}`}
                              title={t("msgSendBtnIcon")}
                              className="grid h-8 w-8 place-items-center rounded-lg border border-emerald-200 text-emerald-600 transition hover:border-emerald-400 hover:bg-emerald-50 hover:text-emerald-700 active:scale-95 dark:border-emerald-500/30 dark:text-emerald-300 dark:hover:bg-emerald-500/10"
                            >
                              <CatIcon name="send" className="h-[14px] w-[14px]" />
                            </button>
                          </>
                        ) : null}
                        {canManage && !sending ? (
                          <button
                            type="button"
                            onClick={() => setConfirmDelete(c)}
                            aria-label={`${t("msgDeleteBtn")} — ${c.subject}`}
                            title={t("msgDeleteBtn")}
                            className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-rose-300 hover:bg-rose-50 hover:text-rose-600 active:scale-95 dark:border-white/10 dark:text-slate-300 dark:hover:border-rose-500/40 dark:hover:bg-rose-500/10 dark:hover:text-rose-300"
                          >
                            <CatIcon name="trash" className="h-[14px] w-[14px]" />
                          </button>
                        ) : null}
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </div>
      </DashCard>

      {/* ---------------- preview dialog (the email mockup) ---------------- */}
      <AlertDialog open={previewCampaign !== null} onOpenChange={(o) => !o && setPreviewCampaign(null)}>
        <AlertDialogContent dir="auto" className="sm:max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-[15px] font-extrabold">
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white"
                style={{ backgroundImage: grad("#0ea5e9", "#6d5dfb") }}
              >
                <CatIcon name="eye" className="h-4 w-4" />
              </span>
              {t("msgPreviewTitle")}
            </AlertDialogTitle>
          </AlertDialogHeader>
          {previewCampaign ? (
            <div className="overflow-hidden rounded-2xl border border-slate-200 dark:border-white/10">
              <div className="space-y-1.5 border-b border-slate-200 bg-slate-50/80 px-4 py-3 dark:border-white/10 dark:bg-white/[0.04]">
                <div className="flex flex-wrap items-center gap-1.5 text-[11px] font-bold text-slate-500 dark:text-slate-400">
                  <CatIcon name="users" className="h-3 w-3 text-slate-400" />
                  {t(audienceLabelKey(previewCampaign.audience))}
                  <span dir="ltr" className="tabular-nums">
                    · {fmtNum(previewCampaign.recipients, lang)}
                  </span>
                </div>
                {previewCampaign.sentFrom ? (
                  <div className="flex flex-wrap items-center gap-1.5 text-[11px] font-bold text-slate-500 dark:text-slate-400">
                    <CatIcon name="mail" className="h-3 w-3 text-slate-400" />
                    <span dir="ltr" className="truncate font-mono text-slate-700 dark:text-slate-200">
                      {previewCampaign.sentFrom}
                    </span>
                  </div>
                ) : null}
              </div>
              <div className="px-4 py-4">
                <p className="font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                  {previewCampaign.subject}
                </p>
                <p className="mt-3 whitespace-pre-line text-[13px] leading-[1.85] text-slate-600 dark:text-slate-300">
                  {previewCampaign.body}
                </p>
              </div>
            </div>
          ) : null}
          <p className="flex items-start gap-1.5 text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            <CatIcon name="info" className="mt-px h-3.5 w-3.5 shrink-0" />
            {t("msgPreviewNote")}
          </p>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold">
              {t("dlgCancel")}
            </AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ---------------- send confirm ---------------- */}
      <AlertDialog open={confirmSend !== null} onOpenChange={(o) => !o && setConfirmSend(null)}>
        <AlertDialogContent dir="auto" className="sm:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-[15px] font-extrabold">
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg shadow-emerald-500/25"
                style={{ backgroundImage: grad("#10b981", "#059669") }}
              >
                <CatIcon name="send" className="h-4 w-4" />
              </span>
              {t("msgSendTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="leading-relaxed">
              {t("msgSendMsg", {
                n: fmtNum(confirmSend ? confirmSend.recipients : 0, lang),
              })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={send.isPending}>
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => confirmSend && send.mutate(confirmSend.id)}
              disabled={send.isPending}
              className="h-10 gap-2 rounded-xl bg-emerald-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:bg-emerald-700 active:scale-95 disabled:opacity-60"
            >
              <CatIcon name={send.isPending ? "refresh-cw" : "send"} className={cn("h-4 w-4", send.isPending && "animate-spin")} />
              {t("msgSendBtn")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ---------------- delete confirm ---------------- */}
      <AlertDialog open={confirmDelete !== null} onOpenChange={(o) => !o && setConfirmDelete(null)}>
        <AlertDialogContent dir="auto" className="sm:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display text-[15px] font-extrabold">
              {t("msgDeleteTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="leading-relaxed">
              {t("msgDeleteMsg", {
                subject: confirmDelete ? confirmDelete.subject.slice(0, 40) : "",
              })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={remove.isPending}>
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => confirmDelete && remove.mutate(confirmDelete.id)}
              disabled={remove.isPending}
              className="h-10 gap-2 rounded-xl bg-rose-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60"
            >
              <CatIcon name={remove.isPending ? "refresh-cw" : "trash"} className={cn("h-4 w-4", remove.isPending && "animate-spin")} />
              {t("msgDeleteConfirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default AdminMessages;
