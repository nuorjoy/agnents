"use client";

/**
 * Ashrilogic — Super-Admin console presence heartbeat (ROUND 172).
 *
 * Mounted once at the console root (AdminApp, authed branch only). The call
 * itself IS the heartbeat: POST /api/admin/presence → requireAdmin →
 * checkSessionRecord refreshes the caller's SessionRecord.lastSeenAt
 * (throttled server-side to once a minute), so no extra write path exists.
 * The response snapshot (me + admins map + instances map + support count +
 * serverTime) feeds every presence dot in the console views.
 *
 * Cadence & battery law:
 *  - one beat immediately on mount, then every 45 seconds;
 *  - PAUSED while document.hidden (visibilitychange) — no background tabs
 *    burn battery or server budget; on return-to-visible an immediate beat
 *    lands and the interval resumes;
 *  - SILENT failure: a failed beat keeps the previous snapshot (never a
 *    toast, never a blocked console — presence is additive, not critical);
 *  - all timers/listeners cleaned up on unmount (logout, view teardown).
 *
 * The fetch helper follows src/lib/api-client.ts's `request` conventions
 * (relative URL, same-origin credentials, JSON Content-Type on the body,
 * non-2xx → thrown Error) — `request` itself is module-private there, and
 * api-client may not be modified, so the minimal POST lives here.
 */
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type { AdminPresenceSnapshot } from "@/lib/types";

/** 45s — inside the backend's 2.5-minute online window with wide margin. */
const HEARTBEAT_MS = 45_000;

/** api-client `request` convention, minimal POST form (silent-throw caller). */
async function postAdminPresence(): Promise<AdminPresenceSnapshot> {
  const res = await fetch("/api/admin/presence", {
    method: "POST",
    credentials: "same-origin",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({}),
  });
  if (!res.ok) throw new Error(`Presence heartbeat failed (${res.status})`);
  return (await res.json()) as AdminPresenceSnapshot;
}

export interface AdminPresenceContextValue {
  /** latest snapshot; null until the first successful beat */
  snapshot: AdminPresenceSnapshot | null;
  /** trigger an immediate beat (manual refresh hook) */
  refresh: () => void;
}

/* Safe default (house context law, cf. accent-context): consumers outside
 * the provider render gracefully — null snapshot → dots fall back to the
 * DTO row presence or render nothing. */
const AdminPresenceContext = createContext<AdminPresenceContextValue>({
  snapshot: null,
  refresh: () => {},
});

export function AdminPresenceProvider({ children }: { children: ReactNode }) {
  const [snapshot, setSnapshot] = useState<AdminPresenceSnapshot | null>(null);
  const timerRef = useRef<number | null>(null);
  const inFlightRef = useRef(false);

  const beat = useCallback(async () => {
    if (inFlightRef.current) return;
    /* belt & braces: never beat into a hidden tab (the interval is also
       torn down on visibilitychange, but the guard keeps racing beats out) */
    if (typeof document !== "undefined" && document.hidden) return;
    inFlightRef.current = true;
    try {
      const next = await postAdminPresence();
      setSnapshot(next);
    } catch {
      /* silent — keep the previous snapshot; presence never blocks the console */
    } finally {
      inFlightRef.current = false;
    }
  }, []);

  const refresh = useCallback(() => {
    void beat();
  }, [beat]);

  useEffect(() => {
    const startInterval = () => {
      if (timerRef.current === null) {
        timerRef.current = window.setInterval(() => void beat(), HEARTBEAT_MS);
      }
    };
    const stopInterval = () => {
      if (timerRef.current !== null) {
        window.clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };

    void beat();
    startInterval();

    const onVisibility = () => {
      if (document.hidden) {
        stopInterval();
      } else {
        void beat();
        startInterval();
      }
    };
    document.addEventListener("visibilitychange", onVisibility);

    return () => {
      stopInterval();
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [beat]);

  const value = useMemo(() => ({ snapshot, refresh }), [snapshot, refresh]);

  return <AdminPresenceContext.Provider value={value}>{children}</AdminPresenceContext.Provider>;
}

/** Live presence snapshot for the Super-Admin console (safe outside provider). */
export function useAdminPresence(): AdminPresenceContextValue {
  return useContext(AdminPresenceContext);
}

export default AdminPresenceProvider;
