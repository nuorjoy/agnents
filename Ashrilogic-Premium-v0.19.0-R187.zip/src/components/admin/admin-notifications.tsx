"use client";

/**
 * Ashrilogic — admin notifications dropdown (ROUND 141 — the REAL-EVENT
 * upgrade, directive ㉝).
 *
 * The old bell derived a decorative feed client-side from the instances
 * list (read state in-memory, no operational value). This is the REAL
 * console feed: GET /api/admin/notifications aggregates the platform's
 * live operational queues server-side — PENDING plan orders (activation
 * queue), PENDING add-on orders, PENDING wallet top-up requests, OPEN
 * support tickets (urgent first), and NEW subscribers (7d) — and the bell
 * polls it every 30 seconds.
 *
 * Unread state persists per admin in localStorage (a feed item is unread
 * while newer than the last "mark all read" stamp); clicking a money row
 * jumps straight to the Payments console, a ticket to Support, a
 * subscriber to the Subscribers console.
 */
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { fetchAdminNotifFeed } from "@/lib/api-client";
import { useT, type I18nKey } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

/** where each notification kind navigates (the admin sidebar views). */
type NotifView = "planOrders" | "support" | "subscribers";

const KIND_STYLE: Record<
  string,
  { icon: string; c1: string; c2: string; view: NotifView; titleKey: I18nKey; subKey: I18nKey }
> = {
  planOrder: {
    icon: "credit-card",
    c1: "#6d5dfb",
    c2: "#d946ef",
    view: "planOrders",
    titleKey: "adminNotifPlanOrder",
    subKey: "adminNotifAwaitingPay",
  },
  addonOrder: {
    icon: "puzzle",
    c1: "#8b5cf6",
    c2: "#7c3aed",
    view: "planOrders",
    titleKey: "adminNotifAddonOrder",
    subKey: "adminNotifAwaitingPay",
  },
  topup: {
    icon: "wallet",
    c1: "#059669",
    c2: "#0f766e",
    view: "planOrders",
    titleKey: "adminNotifTopup",
    subKey: "adminNotifAwaitingPay",
  },
  ticket: {
    icon: "life-buoy",
    c1: "#f59e0b",
    c2: "#d97706",
    view: "support",
    titleKey: "adminNotifTicket",
    subKey: "adminNotifTicketSub",
  },
  subscriber: {
    icon: "user-plus",
    c1: "#0ea5e9",
    c2: "#0284c7",
    view: "subscribers",
    titleKey: "adminNotifSubscriber",
    subKey: "adminNotifSubscriberSub",
  },
};

const READ_KEY = "ashrilogic-admin-notif-read";

function relTime(iso: string, lang: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.max(0, Math.round(diffMs / 60_000));
  const locale = lang === "ar" ? "ar-EG" : "en-US";
  const rtf = new Intl.RelativeTimeFormat(locale, { numeric: "auto" });
  if (mins < 1) return rtf.format(0, "minute");
  if (mins < 60) return rtf.format(-mins, "minute");
  const hours = Math.round(mins / 60);
  if (hours < 24) return rtf.format(-hours, "hour");
  return rtf.format(-Math.round(hours / 24), "day");
}

export function AdminNotifications({ onNavigate }: { onNavigate?: (view: NotifView) => void }) {
  const { t, lang } = useT();
  const [lastRead, setLastRead] = useState<number>(() => {
    if (typeof window === "undefined") return 0;
    const stored = Number(localStorage.getItem(READ_KEY) ?? "0");
    return Number.isFinite(stored) && stored > 0 ? stored : 0;
  });

  /* ROUND 141 — the REAL-EVENT feed: a 30-second poll over the aggregated
   * operational queues (pending money + open tickets + new subscribers). */
  const feedQuery = useQuery({
    queryKey: ["admin-notif-feed"],
    queryFn: fetchAdminNotifFeed,
    refetchInterval: 30_000,
    refetchOnWindowFocus: true,
    staleTime: 20_000,
    retry: 0,
  });
  const items = feedQuery.data?.items ?? [];

  const unread = useMemo(
    () => items.filter((i) => new Date(i.createdAt).getTime() > lastRead).length,
    [items, lastRead]
  );

  const markAllRead = () => {
    const now = Date.now();
    localStorage.setItem(READ_KEY, String(now));
    setLastRead(now);
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-label={t("adminNotifTitle")}
          title={t("adminNotifTitle")}
          className="relative grid h-10 w-10 place-items-center rounded-xl border border-slate-200 text-slate-600 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:text-slate-300"
        >
          <CatIcon name="bell" className="h-[14px] w-[14px]" />
          {unread > 0 ? (
            <span className="absolute -top-0.5 -end-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-rose-500 px-1 text-[11px] font-extrabold text-white">
              {unread > 99 ? "99+" : unread}
            </span>
          ) : null}
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80 p-0">
        <div className="flex items-center justify-between border-b border-slate-200/70 px-4 py-3 dark:border-white/10">
          <p className="text-[12px] font-extrabold text-slate-800 dark:text-slate-100">
            {t("adminNotifTitle")}
          </p>
          <button
            type="button"
            onClick={markAllRead}
            className="text-[10.5px] font-bold text-brand-600 transition hover:underline dark:text-brand-300"
          >
            {t("adminNotifMarkRead")}
          </button>
        </div>
        <div className="max-h-80 overflow-y-auto nice-scroll">
          {feedQuery.isPending ? (
            <p className="px-4 py-8 text-center text-[12px] font-semibold text-slate-400 dark:text-slate-500">
              {t("adminSessionRestore")}
            </p>
          ) : items.length === 0 ? (
            <p className="px-4 py-8 text-center text-[12px] font-semibold text-slate-400 dark:text-slate-500">
              {t("adminNotifEmpty")}
            </p>
          ) : (
            items.slice(0, 14).map((item) => {
              const style = KIND_STYLE[item.kind] ?? KIND_STYLE.subscriber;
              const isUnread = new Date(item.createdAt).getTime() > lastRead;
              return (
                <DropdownMenuItem
                  key={item.id}
                  onClick={() => onNavigate?.(style.view)}
                  className="flex cursor-pointer items-center gap-3 px-4 py-2.5 text-start focus:bg-slate-100 dark:focus:bg-white/5"
                >
                  <span
                    className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white"
                    style={{ backgroundImage: grad(style.c1, style.c2) }}
                  >
                    <CatIcon name={style.icon} className="h-[11px] w-[11px]" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-1.5">
                      <span className="truncate text-[12px] font-bold text-slate-700 dark:text-slate-200">
                        {t(style.titleKey)}
                      </span>
                      {item.amount !== null ? (
                        <span dir="ltr" className="shrink-0 text-[11px] font-extrabold tabular-nums text-slate-500 dark:text-slate-400">
                          {fmtNum(item.amount, lang)} {item.currency}
                        </span>
                      ) : null}
                    </span>
                    <span className="mt-0.5 flex items-center gap-1.5">
                      <span className="min-w-0 truncate text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                        {item.orgName}
                      </span>
                      <span className="shrink-0 text-[10px] text-slate-300 dark:text-slate-600">
                        {relTime(item.createdAt, lang)}
                      </span>
                    </span>
                  </span>
                  {isUnread ? (
                    <span className={cn("h-1.5 w-1.5 shrink-0 rounded-full bg-brand-500")} aria-hidden="true" />
                  ) : null}
                </DropdownMenuItem>
              );
            })
          )}
        </div>
        {(feedQuery.data?.counts.planOrders ?? 0) +
          (feedQuery.data?.counts.addonOrders ?? 0) +
          (feedQuery.data?.counts.topups ?? 0) >
        0 ? (
          <>
            <DropdownMenuSeparator className="my-0" />
            <div className="px-4 py-2.5">
              <p className="text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                {t("adminNotifQueuesNote")}
              </p>
            </div>
          </>
        ) : null}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
