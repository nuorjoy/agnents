"use client";

/**
 * Ashrilogic — Super Admin BLOG console (المدونة).
 *
 * Premium post management for the official /blog:
 *  - KPI strip (total · published · drafts · lifetime views);
 *  - searchable, status-filtered post table (cover thumb, bilingual title,
 *    status chip, views, read time, published date, featured star, actions);
 *  - the PREMIUM EDITOR dialog: bilingual tabs (العربية / English) for
 *    title + excerpt + body, a safe-markdown toolbar (wraps the selection),
 *    a live preview pane rendering the EXACT public renderer, slug + tags +
 *    author + status + featured controls, cover upload (data-URL → server
 *    image pipeline) with preview, and a live reading-time estimate;
 *  - publish / unpublish quick actions + delete behind a confirm dialog.
 *
 * Mutations hit /api/admin/blog(+[id]); every write is audited server-side.
 * Viewer/moderator roles keep read-only visibility (enforcement is
 * server-side — the UI gate mirrors it, same as the newsletter console).
 */
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  createBlogPost,
  deleteBlogPost,
  fetchAdminBlogPosts,
  updateBlogPost,
  uploadBlogImage,
} from "@/lib/api-client";
import { useAdminCanManage, useAdminAuth } from "@/lib/admin-auth";
import { useT, type I18nKey } from "@/lib/i18n";
import type { AdminBlogPostDTO, BlogPostPayload } from "@/lib/types";
import { readingMinutes, renderMarkdown, slugify, countWords, MD_ICON_KEYS } from "@/lib/markdown";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad } from "@/lib/utils";
import { ViewHeading, IconTile, DashCard, dateOnly } from "@/components/dashboard/dash-shared";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

/* ------------------------------------------------------------------ */
/* editor state                                                        */
/* ------------------------------------------------------------------ */

interface EditorState {
  id: string | null;
  slug: string;
  slugTouched: boolean;
  titleAr: string;
  titleEn: string;
  excerptAr: string;
  excerptEn: string;
  contentAr: string;
  contentEn: string;
  tags: string;
  authorName: string;
  status: "draft" | "published";
  featured: boolean;
  /** data-URL of a freshly picked file OR an existing managed ref */
  coverImage: string;
  coverIsManaged: boolean;
}

const EMPTY_EDITOR: EditorState = {
  id: null,
  slug: "",
  slugTouched: false,
  titleAr: "",
  titleEn: "",
  excerptAr: "",
  excerptEn: "",
  contentAr: "",
  contentEn: "",
  tags: "",
  authorName: "Ashrilogic",
  status: "draft",
  featured: false,
  coverImage: "",
  coverIsManaged: false,
};

/** Safe-markdown toolbar actions — wrap the current textarea selection. */
const MD_TOOLS: { key: string; icon: string; labelKey: "blogMdH2" | "blogMdH3" | "blogMdBold" | "blogMdList" | "blogMdQuote" | "blogMdCode" | "blogMdHr"; wrap: [string, string]; block: boolean }[] = [
  { key: "h2", icon: "heading", labelKey: "blogMdH2", wrap: ["## ", ""], block: true },
  { key: "h3", icon: "heading-1", labelKey: "blogMdH3", wrap: ["### ", ""], block: true },
  { key: "bold", icon: "bold", labelKey: "blogMdBold", wrap: ["**", "**"], block: false },
  { key: "list", icon: "list", labelKey: "blogMdList", wrap: ["- ", ""], block: true },
  { key: "quote", icon: "quote", labelKey: "blogMdQuote", wrap: ["> ", ""], block: true },
  { key: "code", icon: "code", labelKey: "blogMdCode", wrap: ["`", "`"], block: false },
  { key: "hr", icon: "minus", labelKey: "blogMdHr", wrap: ["\n---\n", ""], block: false },
];

/** ROUND 129 — rich-insert tools (links, images, emojis, icon badges).
 *  Link/image open a small inline form below the toolbar; emoji/icon open
 *  curated picker grids. All insert at the ACTIVE textarea's cursor. */
type RichPanel = "none" | "link" | "image" | "emoji" | "icon";

const RICH_TOOLS: { key: RichPanel; icon: string; labelKey: "blogMdLink" | "blogMdImage" | "blogMdEmoji" | "blogMdIcon" }[] = [
  { key: "link", icon: "link", labelKey: "blogMdLink" },
  { key: "image", icon: "image", labelKey: "blogMdImage" },
  { key: "emoji", icon: "smile", labelKey: "blogMdEmoji" },
  { key: "icon", icon: "badge-check", labelKey: "blogMdIcon" },
];

/** Curated professional emoji palette (four themed groups — no search, no
 *  unbounded picker: a deliberately small, tasteful set). */
const EMOJI_GROUPS: { labelKey: I18nKey; items: string[] }[] = [
  {
    labelKey: "blogEmojiG1",
    items: ["📊", "📈", "📉", "📋", "📌", "🗂️", "💼", "🏆", "🎯", "✅", "⚡", "🔍", "💡", "🛠️", "⚙️", "🔒", "🛡️", "💰"],
  },
  {
    labelKey: "blogEmojiG2",
    items: ["✉️", "📞", "💬", "🤝", "👥", "🌐", "📅", "⏰", "🔔"],
  },
  {
    labelKey: "blogEmojiG3",
    items: ["🚀", "✨", "🌟", "🔥", "🎉", "❤️", "👍", "🙏", "😊"],
  },
  {
    labelKey: "blogEmojiG4",
    items: ["⭐", "➡️", "⚠️", "❌", "🎁", "🧩", "🧠", "💎"],
  },
];

/** Deterministic gradient for the editor cover placeholder. */
function editorGradient(title: string): [string, string, string] {
  const palettes: [string, string, string][] = [
    ["#6d5dfb", "#d946ef", "sparkles"],
    ["#06b6d4", "#0ea5e9", "compass"],
    ["#f59e0b", "#f97316", "banknote"],
    ["#10b981", "#059669", "shield-check"],
  ];
  let hash = 0;
  for (let i = 0; i < title.length; i++) hash = (hash * 31 + title.charCodeAt(i)) >>> 0;
  return palettes[hash % palettes.length];
}

/* ------------------------------------------------------------------ */
/* main view                                                           */
/* ------------------------------------------------------------------ */

export function AdminBlog() {
  const { t, lang } = useT();
  const canManage = useAdminCanManage();
  const { user: adminUser } = useAdminAuth();
  const queryClient = useQueryClient();

  const [statusFilter, setStatusFilter] = useState<"" | "draft" | "published">("");
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [page, setPage] = useState(1);

  const [editorOpen, setEditorOpen] = useState(false);
  const [editor, setEditor] = useState<EditorState>(EMPTY_EDITOR);
  const [activeTab, setActiveTab] = useState<"ar" | "en">("ar");
  const [previewOn, setPreviewOn] = useState(false);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<AdminBlogPostDTO | null>(null);

  /* ROUND 129 — rich-insert panels (link / image / emoji / icon) */
  const [richPanel, setRichPanel] = useState<RichPanel>("none");
  const [linkText, setLinkText] = useState("");
  const [linkUrl, setLinkUrl] = useState("");
  const [imgAlt, setImgAlt] = useState("");
  const [imgUrl, setImgUrl] = useState("");
  const [imgBusy, setImgBusy] = useState(false);

  const fileRef = useRef<HTMLInputElement>(null);
  const inlineImgRef = useRef<HTMLInputElement>(null);

  /* debounce search (300ms — table-sized, not keystroke-sized) */
  useEffect(() => {
    const id = setTimeout(() => {
      setDebouncedSearch(search);
      setPage(1);
    }, 300);
    return () => clearTimeout(id);
  }, [search]);

  const listQuery = useQuery({
    queryKey: ["admin-blog", statusFilter, debouncedSearch, page],
    queryFn: () =>
      fetchAdminBlogPosts({
        page,
        pageSize: 12,
        status: statusFilter || undefined,
        q: debouncedSearch || undefined,
      }),
    placeholderData: (prev) => prev,
  });

  const rows = listQuery.data?.rows ?? [];
  const total = listQuery.data?.total ?? 0;
  const totalPages = Math.max(1, Math.ceil(total / 12));

  /* lifetime views KPI — derived from the loaded page (honest window) */
  const viewsInWindow = rows.reduce((sum, r) => sum + r.views, 0);

  const invalidate = useCallback(() => {
    void queryClient.invalidateQueries({ queryKey: ["admin-blog"] });
    /* public feeds refresh alongside (same cache family as the site) */
    void queryClient.invalidateQueries({ queryKey: ["public-blog"] });
    void queryClient.invalidateQueries({ queryKey: ["public-blog-post"] });
  }, [queryClient]);

  /* ---------------- mutations ---------------- */

  const saveMutation = useMutation({
    mutationFn: async (payload: BlogPostPayload & { id: string | null }) => {
      const { id, ...body } = payload;
      return id ? updateBlogPost(id, body) : createBlogPost(body);
    },
    onSuccess: (row, variables) => {
      toast.success(variables.id ? t("blogSaved") : t("blogCreated"));
      invalidate();
      setEditorOpen(false);
    },
    onError: (error: Error) => toast.error(error.message || t("blogSaveFailed")),
  });

  const quickMutation = useMutation({
    mutationFn: async (args: { id: string; payload: BlogPostPayload }) =>
      updateBlogPost(args.id, args.payload),
    onSuccess: () => {
      invalidate();
    },
    onError: (error: Error) => toast.error(error.message || t("blogSaveFailed")),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => deleteBlogPost(id),
    onSuccess: () => {
      toast.success(t("blogDeleted"));
      invalidate();
      setDeleteTarget(null);
    },
    onError: (error: Error) => toast.error(error.message || t("blogSaveFailed")),
  });

  /* ---------------- editor helpers ---------------- */

  /* ROUND 129 — the author is AUTO-ASSIGNED from the signed-in admin
   * account (create) or the post's original author (edit) and is LOCKED:
   * the input is read-only and the payload never carries it. The server
   * enforces the same contract (POST stamps the acting admin; PATCH
   * ignores the field entirely). */
  const openCreate = useCallback(() => {
    setEditor({
      ...EMPTY_EDITOR,
      authorName: adminUser?.name?.trim() || adminUser?.username || "Ashrilogic",
    });
    setActiveTab("ar");
    setPreviewOn(false);
    setRichPanel("none");
    setEditorOpen(true);
  }, [adminUser]);

  const openEdit = useCallback((post: AdminBlogPostDTO) => {
    setEditor({
      id: post.id,
      slug: post.slug,
      slugTouched: true,
      titleAr: post.titleAr,
      titleEn: post.titleEn,
      excerptAr: post.excerptAr,
      excerptEn: post.excerptEn,
      contentAr: post.contentAr,
      contentEn: post.contentEn,
      tags: post.tags.join(", "),
      authorName: post.authorName,
      status: post.status,
      featured: post.featured,
      coverImage: post.coverImage,
      coverIsManaged: true,
    });
    setActiveTab("ar");
    setPreviewOn(false);
    setRichPanel("none");
    setEditorOpen(true);
  }, []);

  const patchEditor = useCallback((patch: Partial<EditorState>) => {
    setEditor((prev) => ({ ...prev, ...patch }));
  }, []);

  /* title edit — also refreshes the auto-slug while untouched (derived in
   * the change handler itself, never a synchronous effect setState) */
  const patchTitle = useCallback(
    (field: "titleAr" | "titleEn", value: string) => {
      setEditor((prev) => {
        const next = { ...prev, [field]: value };
        if (prev.id === null && !prev.slugTouched) {
          next.slug = slugify(next.titleEn || next.titleAr);
        }
        return next;
      });
    },
    []
  );

  const pickCover = useCallback((file: File | undefined) => {
    if (!file) return;
    if (file.size > 6 * 1024 * 1024) {
      toast.error(t("blogEdCoverHint"));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") {
        patchEditor({ coverImage: reader.result, coverIsManaged: false });
      }
    };
    reader.readAsDataURL(file);
  }, [patchEditor, t]);

  /* ---------------- ROUND 129 — rich-insert helpers ---------------- */

  /** Insert a snippet at the ACTIVE textarea's cursor (both tabs share the
   *  helper; the emoji/icon/link/image panels all route through it). */
  const insertSnippet = useCallback(
    (tab: "ar" | "en", snippet: string) => {
      const fieldId = `ed-content-${tab}`;
      const el = document.getElementById(fieldId) as HTMLTextAreaElement | null;
      if (!el) {
        /* panel opened without the textarea mounted (edge) — append */
        patchEditor(
          tab === "ar"
            ? { contentAr: `${editor.contentAr}${editor.contentAr ? "\n" : ""}${snippet}` }
            : { contentEn: `${editor.contentEn}${editor.contentEn ? "\n" : ""}${snippet}` }
        );
        return;
      }
      const { selectionStart: start, selectionEnd: end, value } = el;
      const next = `${value.slice(0, start)}${snippet}${value.slice(end)}`;
      patchEditor(tab === "ar" ? { contentAr: next } : { contentEn: next });
      requestAnimationFrame(() => {
        el.focus();
        const cursor = start + snippet.length;
        el.setSelectionRange(cursor, cursor);
      });
    },
    [editor.contentAr, editor.contentEn, patchEditor]
  );

  /* ROUND 131 — editorial URL normalization (the «link renders as text»
   *  root-fix companion): what authors type into the link/image panels is
   *  made CANONICAL before insertion so the markdown renderer always
   *  validates it — bidi control chars (RLM/isolates) from RTL typing are
   *  stripped, angle brackets/quotes from copy-paste peel off, and a
   *  scheme-less host (example.com/path) upgrades to https://. */
  const normalizeEditorUrl = useCallback((raw: string): string => {
    let url = raw.replace(/[\u200E\u200F\u200B\u202A-\u202E\u2066-\u2069]/g, "").trim();
    url = url.replace(/^[<"']+/, "").replace(/[>"']+$/, "").trim();
    if (!url) return "";
    if (/^https?:\/\//i.test(url) || /^mailto:/i.test(url) || url.startsWith("/") || url.startsWith("/api/images/")) {
      return url;
    }
    /* scheme-less host-shaped target → https (the renderer would too, but
     * the stored body should be canonical and readable in the source) */
    if (/^[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+(?:\/[^\s]*)?$/.test(url) && !url.includes("@")) {
      return `https://${url}`;
    }
    return url;
  }, []);

  const insertLink = useCallback(() => {
    const url = normalizeEditorUrl(linkUrl);
    if (!url) return;
    const text = linkText.trim() || url.replace(/^https?:\/\//, "").slice(0, 60) || url;
    insertSnippet(activeTab, `[${text}](${url})`);
    setLinkText("");
    setLinkUrl("");
    setRichPanel("none");
  }, [linkText, linkUrl, activeTab, insertSnippet, normalizeEditorUrl]);

  const insertImage = useCallback(
    (src: string) => {
      const trimmed = normalizeEditorUrl(src);
      if (!trimmed) return;
      insertSnippet(activeTab, `![${imgAlt.trim()}](${trimmed})`);
      setImgAlt("");
      setImgUrl("");
      setRichPanel("none");
    },
    [imgAlt, activeTab, insertSnippet, normalizeEditorUrl]
  );

  /** Inline-image upload leg: data-URL → sanitized managed ref (same
   *  pipeline as the cover); the ref is what the body stores. */
  const pickInlineImage = useCallback(
    (file: File | undefined) => {
      if (!file) return;
      if (file.size > 6 * 1024 * 1024) {
        toast.error(t("blogEdCoverHint"));
        return;
      }
      setImgBusy(true);
      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = typeof reader.result === "string" ? reader.result : "";
        if (!dataUrl) {
          setImgBusy(false);
          return;
        }
        uploadBlogImage(dataUrl)
          .then((ref) => {
            setImgUrl(ref);
            toast.success(t("blogImgReady"));
          })
          .catch((error: Error) => toast.error(error.message || t("blogSaveFailed")))
          .finally(() => setImgBusy(false));
      };
      reader.onerror = () => setImgBusy(false);
      reader.readAsDataURL(file);
    },
    [t]
  );

  const estimate = useMemo(
    () => readingMinutes(editor.contentAr, editor.contentEn),
    [editor.contentAr, editor.contentEn]
  );
  const activeWords = useMemo(
    () => countWords(activeTab === "ar" ? editor.contentAr : editor.contentEn),
    [activeTab, editor.contentAr, editor.contentEn]
  );

  const handleSave = useCallback(() => {
    if (!editor.titleAr.trim()) {
      toast.error(t("blogEdTitleAr"));
      setActiveTab("ar");
      return;
    }
    setSaving(true);
    const payload: BlogPostPayload = {
      slug: editor.slug.trim() || undefined,
      titleAr: editor.titleAr.trim(),
      titleEn: editor.titleEn.trim() || undefined,
      excerptAr: editor.excerptAr,
      excerptEn: editor.excerptEn,
      contentAr: editor.contentAr,
      contentEn: editor.contentEn,
      tags: editor.tags
        .split(",")
        .map((tg) => tg.trim().toLowerCase())
        .filter(Boolean)
        .slice(0, 6),
      /* ROUND 129 — authorName deliberately ABSENT: the server stamps the
       * acting admin on create and keeps the original author on update */
      status: editor.status,
      featured: editor.featured,
      /* only send the cover when it changed (data-URL) — an existing managed
         ref is passed through untouched so PATCH keeps it */
      ...(editor.coverImage && !editor.coverIsManaged ? { coverImage: editor.coverImage } : {}),
      ...(editor.coverImage === "" && editor.id ? { coverImage: "" } : {}),
    };
    saveMutation.mutate(
      { id: editor.id, ...payload },
      { onSettled: () => setSaving(false) }
    );
  }, [editor, saveMutation, t]);

  const toggleFeatured = useCallback(
    (post: AdminBlogPostDTO) => {
      quickMutation.mutate({ id: post.id, payload: { featured: !post.featured } });
    },
    [quickMutation]
  );

  const toggleStatus = useCallback(
    (post: AdminBlogPostDTO) => {
      quickMutation.mutate({
        id: post.id,
        payload: { status: post.status === "published" ? "draft" : "published" },
      });
    },
    [quickMutation]
  );

  const previewHtml = useMemo(
    () => renderMarkdown(activeTab === "ar" ? editor.contentAr : editor.contentEn),
    [activeTab, editor.contentAr, editor.contentEn]
  );

  /* ---------------- render ---------------- */

  return (
    <div className="space-y-6">
      <ViewHeading title={t("adminBlog")} desc={t("blogConsoleDesc")} />

      {/* KPI strip */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {(
          [
            { label: t("blogKpiTotal"), value: total, icon: "newspaper", c1: "#6d5dfb", c2: "#8b5cf6" },
            { label: t("blogKpiPublished"), value: rows.filter((r) => r.status === "published").length, icon: "circle-check", c1: "#10b981", c2: "#059669" },
            { label: t("blogKpiDrafts"), value: rows.filter((r) => r.status === "draft").length, icon: "pencil-line", c1: "#f59e0b", c2: "#f97316" },
            { label: t("blogKpiViews"), value: viewsInWindow, icon: "eye", c1: "#06b6d4", c2: "#0ea5e9" },
          ] as const
        ).map((kpi) => (
          <DashCard key={kpi.label}>
            <div className="flex items-center gap-3">
              <IconTile icon={kpi.icon} c1={kpi.c1} c2={kpi.c2} />
              <div className="min-w-0">
                <p className="truncate text-[10.5px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  {kpi.label}
                </p>
                <p className="font-display text-xl font-extrabold tabular-nums text-slate-900 dark:text-white">
                  {fmtNum(kpi.value, lang)}
                </p>
              </div>
            </div>
          </DashCard>
        ))}
      </div>

      {/* toolbar + table */}
      <DashCard>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-1 flex-col gap-2 sm:flex-row sm:items-center">
            {/* search */}
            <div className="relative min-w-0 flex-1">
              <CatIcon name="search" className="pointer-events-none absolute start-3.5 top-1/2 h-[13px] w-[13px] -translate-y-1/2 text-slate-400" />
              <Input
                type="search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={t("blogSearchPh")}
                className="h-10 rounded-xl border-slate-200 bg-white ps-10 text-[12.5px] font-semibold dark:border-white/10 dark:bg-white/[0.04]"
              />
            </div>
            {/* status chips */}
            <div className="flex shrink-0 gap-1.5" role="group">
              {(
                [
                  { key: "", labelKey: "blogFilterAll" as const },
                  { key: "published", labelKey: "blogFilterPublished" as const },
                  { key: "draft", labelKey: "blogFilterDraft" as const },
                ] as const
              ).map((chip) => (
                <button
                  key={chip.key || "all"}
                  type="button"
                  onClick={() => {
                    setStatusFilter(chip.key as "" | "draft" | "published");
                    setPage(1);
                  }}
                  aria-pressed={statusFilter === chip.key}
                  className={cn(
                    "cursor-pointer rounded-xl border px-3 py-2 text-[11.5px] font-bold transition",
                    statusFilter === chip.key
                      ? "border-transparent bg-brand-500/10 text-brand-600 dark:text-brand-300"
                      : "border-slate-200 bg-white text-slate-500 hover:text-slate-700 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400"
                  )}
                >
                  {t(chip.labelKey)}
                </button>
              ))}
            </div>
          </div>

          {canManage ? (
            <Button
              onClick={openCreate}
              className="h-10 shrink-0 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-4 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
            >
              <CatIcon name="plus" className="h-[13px] w-[13px]" />
              {t("blogNewPost")}
            </Button>
          ) : null}
        </div>

        {/* table */}
        <div className="mt-4 overflow-x-auto nice-scrollbar">
          {listQuery.isLoading ? (
            <div className="space-y-2">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="h-16 animate-pulse rounded-2xl bg-slate-100/70 dark:bg-white/[0.04]" aria-hidden="true" />
              ))}
            </div>
          ) : rows.length === 0 ? (
            <div className="py-14 text-center">
              <div className="mx-auto grid h-16 w-16 place-items-center rounded-3xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
                <CatIcon name="newspaper" className="h-6 w-6" />
              </div>
              <h3 className="mt-4 font-display text-lg font-extrabold">{t("blogAdminEmptyTitle")}</h3>
              <p className="mx-auto mt-1.5 max-w-xs text-[12.5px] text-slate-500 dark:text-slate-400">
                {t("blogAdminEmptyDesc")}
              </p>
              {canManage ? (
                <Button onClick={openCreate} variant="outline" className="mt-5 rounded-xl">
                  <CatIcon name="pencil-line" className="h-[13px] w-[13px]" />
                  {t("blogEmptyBtn")}
                </Button>
              ) : null}
            </div>
          ) : (
            <table className="w-full min-w-[760px] text-start">
              <thead>
                <tr className="border-b border-slate-200/70 text-start dark:border-white/10">
                  {(
                    [
                      t("blogColPost"),
                      t("blogColStatus"),
                      t("blogColViews"),
                      t("blogColRead"),
                      t("blogColPublished"),
                      canManage ? t("blogColActions") : "",
                    ] as const
                  ).map((head, i) => (
                    <th
                      key={i}
                      className={cn(
                        "p-3 text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500",
                        i === 0 ? "text-start" : "text-center",
                        i === 5 && !canManage && "hidden"
                      )}
                    >
                      {head}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((post) => {
                  const [gc1, gc2, gicon] = editorGradient(post.id);
                  return (
                    <tr
                      key={post.id}
                      className="border-b border-slate-100 transition-colors hover:bg-slate-50/60 dark:border-white/[0.05] dark:hover:bg-white/[0.02]"
                    >
                      {/* post cell */}
                      <td className="p-3">
                        <div className="flex items-center gap-3">
                          {post.coverImage ? (
                            // eslint-disable-next-line @next/next/no-img-element
                            <img src={post.coverImage} alt="" className="h-11 w-16 shrink-0 rounded-xl object-cover" loading="lazy" />
                          ) : (
                            <span
                              className="grid h-11 w-16 shrink-0 place-items-center rounded-xl text-white shadow-sm"
                              style={{ backgroundImage: grad(gc1, gc2) }}
                              aria-hidden="true"
                            >
                              <CatIcon name={gicon} className="h-[14px] w-[14px]" />
                            </span>
                          )}
                          <div className="min-w-0">
                            <p className="truncate text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                              {post.titleAr}
                              {post.featured ? (
                                <CatIcon name="star" className="ms-1.5 inline h-3 w-3 fill-amber-400 text-amber-400" aria-hidden="true" />
                              ) : null}
                            </p>
                            <p className="truncate text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                              {post.titleEn} · /blog/{post.slug}
                            </p>
                          </div>
                        </div>
                      </td>
                      {/* status */}
                      <td className="p-3 text-center">
                        <button
                          type="button"
                          disabled={!canManage}
                          onClick={() => toggleStatus(post)}
                          title={canManage ? (post.status === "published" ? t("blogEdUnpublish") : t("blogEdPublish")) : undefined}
                          className={cn(
                            "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10.5px] font-extrabold transition",
                            post.status === "published"
                              ? "bg-emerald-50 text-emerald-600 hover:brightness-95 dark:bg-emerald-500/10 dark:text-emerald-400"
                              : "bg-amber-50 text-amber-600 hover:brightness-95 dark:bg-amber-500/10 dark:text-amber-400",
                            !canManage && "cursor-default"
                          )}
                        >
                          <CatIcon name={post.status === "published" ? "circle-check" : "pencil-line"} className="h-[10px] w-[10px]" />
                          {post.status === "published" ? t("blogStatusPublished") : t("blogStatusDraft")}
                        </button>
                      </td>
                      <td className="p-3 text-center text-[12px] font-extrabold tabular-nums text-slate-600 dark:text-slate-300">
                        {fmtNum(post.views, lang)}
                      </td>
                      <td className="p-3 text-center text-[12px] font-bold tabular-nums text-slate-500 dark:text-slate-400">
                        {fmtNum(post.readMinutes, lang)} {t("blogMinUnit")}
                      </td>
                      <td className="p-3 text-center text-[11.5px] font-bold text-slate-500 dark:text-slate-400">
                        {post.publishedAt ? dateOnly(post.publishedAt, lang) : "—"}
                      </td>
                      {canManage ? (
                        <td className="p-3">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              type="button"
                              onClick={() => toggleFeatured(post)}
                              title={t("blogToggleFeatured")}
                              aria-label={t("blogToggleFeatured")}
                              className={cn(
                                "grid h-8 w-8 cursor-pointer place-items-center rounded-lg transition active:scale-90",
                                post.featured
                                  ? "bg-amber-50 text-amber-500 hover:bg-amber-100 dark:bg-amber-500/10 dark:text-amber-400"
                                  : "text-slate-300 hover:bg-slate-100 hover:text-amber-400 dark:text-slate-600 dark:hover:bg-white/10"
                              )}
                            >
                              <CatIcon name="star" className={cn("h-[14px] w-[14px]", post.featured && "fill-amber-400 text-amber-400")} />
                            </button>
                            <button
                              type="button"
                              onClick={() => openEdit(post)}
                              title={t("blogEditPost")}
                              aria-label={t("blogEditPost")}
                              className="grid h-8 w-8 cursor-pointer place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-brand-600 active:scale-90 dark:text-slate-500 dark:hover:bg-white/10 dark:hover:text-brand-300"
                            >
                              <CatIcon name="pencil" className="h-[14px] w-[14px]" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setDeleteTarget(post)}
                              title={t("partnerDeleteTitle")}
                              aria-label={t("partnerDeleteTitle")}
                              className="grid h-8 w-8 cursor-pointer place-items-center rounded-lg text-slate-400 transition hover:bg-rose-50 hover:text-rose-500 active:scale-90 dark:text-slate-500 dark:hover:bg-rose-500/10 dark:hover:text-rose-400"
                            >
                              <CatIcon name="trash-2" className="h-[14px] w-[14px]" />
                            </button>
                          </div>
                        </td>
                      ) : null}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        {/* pagination */}
        {totalPages > 1 ? (
          <div className="mt-4 flex items-center justify-between gap-3">
            <p className="text-[11.5px] font-bold text-slate-400 dark:text-slate-500">
              {t("sysShowing")} {fmtNum((page - 1) * 12 + rows.length, lang)} {t("sysOf")} {fmtNum(total, lang)}
            </p>
            <div className="flex items-center gap-1.5">
              <Button
                variant="outline"
                size="sm"
                disabled={page <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                className="h-8 rounded-lg px-3"
              >
                <CatIcon name="arrow-right" className="h-3 w-3 rtl:rotate-180" />
              </Button>
              <span className="rounded-lg bg-slate-100 px-3 py-1.5 text-[11.5px] font-extrabold tabular-nums text-slate-600 dark:bg-white/10 dark:text-slate-300">
                {fmtNum(page, lang)} / {fmtNum(totalPages, lang)}
              </span>
              <Button
                variant="outline"
                size="sm"
                disabled={page >= totalPages}
                onClick={() => setPage((p) => p + 1)}
                className="h-8 rounded-lg px-3"
              >
                <CatIcon name="arrow-left" className="h-3 w-3 rtl:rotate-180" />
              </Button>
            </div>
          </div>
        ) : null}
      </DashCard>

      {/* ---------------- the premium editor dialog ---------------- */}
      <Dialog open={editorOpen} onOpenChange={setEditorOpen}>
        {/* ROUND 129 (owner directive): the editor dialog is WIDER (1440px)
           * and its two columns are BALANCED 1:1 — equal breathing room right
           * and left, more freedom while writing. max-w-none is REQUIRED:
           * the base DialogContent carries sm:max-w-lg which otherwise caps
           * the dialog at 512px — the root cause of the narrow editor the
           * owner reported. */}
        <DialogContent className="max-h-[92vh] w-[min(97vw,1440px)] max-w-none p-0 overflow-y-auto nice-scrollbar rounded-3xl sm:max-w-none">
          <DialogHeader className="border-b border-slate-200/70 px-6 py-4 dark:border-white/10">
            <DialogTitle className="flex items-center gap-2.5 font-display text-[15px] font-extrabold">
              <IconTile icon={editor.id ? "pencil-line" : "newspaper"} c1="#6d5dfb" c2="#d946ef" size="sm" />
              {editor.id ? t("blogEditPost") : t("blogNewPost")}
            </DialogTitle>
            <DialogDescription className="sr-only">{t("blogConsoleDesc")}</DialogDescription>
          </DialogHeader>

          <div className="grid gap-0 lg:grid-cols-2">
            {/* ------- left column: bilingual editor ------- */}
            <div className="space-y-4 border-e border-slate-200/70 p-5 dark:border-white/10">
              <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "ar" | "en")}>
                <TabsList className="grid w-full grid-cols-2 rounded-xl">
                  <TabsTrigger value="ar" className="text-[12px] font-bold">
                    {t("blogEdLangAr")}
                  </TabsTrigger>
                  <TabsTrigger value="en" className="text-[12px] font-bold">
                    {t("blogEdLangEn")}
                  </TabsTrigger>
                </TabsList>

                {(["ar", "en"] as const).map((tab) => (
                  <TabsContent key={tab} value={tab} className="mt-4 space-y-3">
                    <div className="space-y-1.5">
                      <Label htmlFor={`ed-title-${tab}`} className="text-[11.5px] font-bold">
                        {t(tab === "ar" ? "blogEdTitleAr" : "blogEdTitleEn")}
                      </Label>
                      <Input
                        id={`ed-title-${tab}`}
                        dir={tab === "ar" ? "rtl" : "ltr"}
                        value={tab === "ar" ? editor.titleAr : editor.titleEn}
                        onChange={(e) => patchTitle(tab === "ar" ? "titleAr" : "titleEn", e.target.value)}
                        className="h-10 rounded-xl text-[13px] font-bold"
                        maxLength={180}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor={`ed-excerpt-${tab}`} className="text-[11.5px] font-bold">
                        {t(tab === "ar" ? "blogEdExcerptAr" : "blogEdExcerptEn")}
                      </Label>
                      <Textarea
                        id={`ed-excerpt-${tab}`}
                        dir={tab === "ar" ? "rtl" : "ltr"}
                        value={tab === "ar" ? editor.excerptAr : editor.excerptEn}
                        onChange={(e) =>
                          patchEditor(tab === "ar" ? { excerptAr: e.target.value } : { excerptEn: e.target.value })
                        }
                        className="min-h-[64px] rounded-xl text-[12.5px] leading-relaxed"
                        maxLength={400}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor={`ed-content-${tab}`} className="text-[11.5px] font-bold">
                        {t(tab === "ar" ? "blogEdContentAr" : "blogEdContentEn")}
                      </Label>
                      <div className="flex flex-wrap gap-1 rounded-xl border border-slate-200 bg-slate-50/70 p-1.5 dark:border-white/10 dark:bg-white/[0.03]">
                        {MD_TOOLS.map((tool) => (
                          <button
                            key={tool.key}
                            type="button"
                            title={t(tool.labelKey)}
                            aria-label={t(tool.labelKey)}
                            onClick={() => {
                              const fieldId = `ed-content-${tab}`;
                              const el = document.getElementById(fieldId) as HTMLTextAreaElement | null;
                              if (!el) return;
                              const { selectionStart: start, selectionEnd: end, value } = el;
                              const selected = value.slice(start, end);
                              let next: string;
                              let cursor: number;
                              if (tool.block) {
                                /* block tools prefix the current line */
                                const lineStart = value.lastIndexOf("\n", start - 1) + 1;
                                next = `${value.slice(0, lineStart)}${tool.wrap[0]}${value.slice(lineStart)}`;
                                cursor = start + tool.wrap[0].length;
                              } else {
                                next = `${value.slice(0, start)}${tool.wrap[0]}${selected}${tool.wrap[1]}${value.slice(end)}`;
                                cursor = start + tool.wrap[0].length + selected.length;
                              }
                              patchEditor(tab === "ar" ? { contentAr: next } : { contentEn: next });
                              requestAnimationFrame(() => {
                                el.focus();
                                el.setSelectionRange(cursor, cursor);
                              });
                            }}
                            className="grid h-7 w-7 cursor-pointer place-items-center rounded-lg text-slate-500 transition hover:bg-white hover:text-brand-600 hover:shadow-sm active:scale-90 dark:text-slate-400 dark:hover:bg-white/10 dark:hover:text-brand-300"
                          >
                            <CatIcon name={tool.icon} className="h-[12px] w-[12px]" />
                          </button>
                        ))}
                        {/* ROUND 129 — the rich-insert group: link · image · emoji · icon */}
                        <span className="mx-0.5 h-5 w-px bg-slate-200 dark:bg-white/10" aria-hidden="true" />
                        {RICH_TOOLS.map((tool) => (
                          <button
                            key={tool.key}
                            type="button"
                            title={t(tool.labelKey)}
                            aria-label={t(tool.labelKey)}
                            aria-pressed={richPanel === tool.key}
                            onClick={() => {
                              if (richPanel === tool.key) {
                                setRichPanel("none");
                                return;
                              }
                              /* prefill the link text with the current selection */
                              if (tool.key === "link") {
                                const el = document.getElementById(`ed-content-${tab}`) as HTMLTextAreaElement | null;
                                if (el) {
                                  const selected = el.value.slice(el.selectionStart, el.selectionEnd).trim();
                                  setLinkText(selected.slice(0, 80));
                                }
                              }
                              setRichPanel(tool.key);
                            }}
                            className={cn(
                              "grid h-7 w-7 cursor-pointer place-items-center rounded-lg transition active:scale-90",
                              richPanel === tool.key
                                ? "bg-brand-500/15 text-brand-600 shadow-sm dark:text-brand-300"
                                : "text-slate-500 hover:bg-white hover:text-brand-600 hover:shadow-sm dark:text-slate-400 dark:hover:bg-white/10 dark:hover:text-brand-300"
                            )}
                          >
                            <CatIcon name={tool.icon} className="h-[12px] w-[12px]" />
                          </button>
                        ))}
                      </div>

                      {/* -------- ROUND 129: the rich-insert panels -------- */}
                      {richPanel === "link" ? (
                        <div className="space-y-2 rounded-xl border border-brand-200 bg-brand-50/60 p-3 dark:border-brand-500/30 dark:bg-brand-500/[0.07]">
                          <div className="grid gap-2 sm:grid-cols-2">
                            <Input
                              value={linkText}
                              onChange={(e) => setLinkText(e.target.value)}
                              placeholder={t("blogLinkText")}
                              maxLength={120}
                              className="h-9 rounded-lg text-[12px]"
                            />
                            <Input
                              dir="ltr"
                              value={linkUrl}
                              onChange={(e) => setLinkUrl(e.target.value)}
                              placeholder="https://…"
                              maxLength={500}
                              className="h-9 rounded-lg text-[12px]"
                            />
                          </div>
                          <div className="flex items-center justify-end gap-2">
                            <Button size="sm" variant="outline" onClick={() => setRichPanel("none")} className="h-8 rounded-lg px-3 text-[11px]">
                              {t("blogEdCancel")}
                            </Button>
                            <Button size="sm" onClick={insertLink} disabled={!linkUrl.trim()} className="h-8 rounded-lg px-3 text-[11px] font-extrabold">
                              <CatIcon name="link" className="h-[11px] w-[11px]" />
                              {t("blogLinkInsert")}
                            </Button>
                          </div>
                        </div>
                      ) : null}

                      {richPanel === "image" ? (
                        <div className="space-y-2 rounded-xl border border-brand-200 bg-brand-50/60 p-3 dark:border-brand-500/30 dark:bg-brand-500/[0.07]">
                          <Input
                            dir="ltr"
                            value={imgUrl}
                            onChange={(e) => setImgUrl(e.target.value)}
                            placeholder="https://…"
                            maxLength={500}
                            className="h-9 rounded-lg text-[12px]"
                          />
                          <Input
                            value={imgAlt}
                            onChange={(e) => setImgAlt(e.target.value)}
                            placeholder={t("blogImgAlt")}
                            maxLength={160}
                            className="h-9 rounded-lg text-[12px]"
                          />
                          {imgUrl.trim() && /^https?:\/\/|^\/api\/images\//i.test(imgUrl.trim()) ? (
                            // eslint-disable-next-line @next/next/no-img-element
                            <img src={imgUrl.trim()} alt="" className="h-20 w-full rounded-lg border border-slate-200 object-cover dark:border-white/10" />
                          ) : null}
                          <div className="flex items-center justify-between gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => inlineImgRef.current?.click()}
                              disabled={imgBusy}
                              className="h-8 rounded-lg px-3 text-[11px]"
                            >
                              <CatIcon name="image" className="h-[11px] w-[11px]" />
                              {imgBusy ? t("blogImgUploading") : t("blogImgUpload")}
                            </Button>
                            <div className="flex items-center gap-2">
                              <Button size="sm" variant="outline" onClick={() => setRichPanel("none")} className="h-8 rounded-lg px-3 text-[11px]">
                                {t("blogEdCancel")}
                              </Button>
                              <Button
                                size="sm"
                                onClick={() => insertImage(imgUrl)}
                                disabled={imgBusy || !/^https?:\/\//i.test(imgUrl.trim())}
                                title={/^https?:\/\//i.test(imgUrl.trim()) ? undefined : t("blogImgUrlHint")}
                                className="h-8 rounded-lg px-3 text-[11px] font-extrabold"
                              >
                                <CatIcon name="image" className="h-[11px] w-[11px]" />
                                {t("blogImgInsert")}
                              </Button>
                            </div>
                          </div>
                          <input
                            ref={inlineImgRef}
                            type="file"
                            accept="image/png,image/jpeg,image/webp"
                            className="hidden"
                            onChange={(e) => {
                              pickInlineImage(e.target.files?.[0]);
                              e.target.value = "";
                            }}
                          />
                          <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                            {t("blogImgPanelHint")}
                          </p>
                        </div>
                      ) : null}

                      {richPanel === "emoji" ? (
                        <div className="max-h-56 space-y-2.5 overflow-y-auto nice-scrollbar rounded-xl border border-slate-200 bg-slate-50/70 p-3 dark:border-white/10 dark:bg-white/[0.03]">
                          {EMOJI_GROUPS.map((group) => (
                            <div key={group.labelKey}>
                              <p className="mb-1 text-[9.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                                {t(group.labelKey)}
                              </p>
                              <div className="flex flex-wrap gap-1">
                                {group.items.map((emoji) => (
                                  <button
                                    key={emoji}
                                    type="button"
                                    onClick={() => insertSnippet(tab, emoji)}
                                    className="grid h-8 w-8 cursor-pointer place-items-center rounded-lg text-[16px] leading-none transition hover:bg-white hover:shadow-sm active:scale-90 dark:hover:bg-white/10"
                                  >
                                    {emoji}
                                  </button>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : null}

                      {richPanel === "icon" ? (
                        <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-3 dark:border-white/10 dark:bg-white/[0.03]">
                          <p className="mb-2 text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                            {t("blogIconHint")}
                          </p>
                          <div className="flex flex-wrap gap-1">
                            {MD_ICON_KEYS.map((iconKey) => (
                              <button
                                key={iconKey}
                                type="button"
                                title={`:${iconKey}:`}
                                aria-label={`:${iconKey}:`}
                                onClick={() => insertSnippet(tab, `:${iconKey}:`)}
                                className="grid h-8 w-8 cursor-pointer place-items-center rounded-lg text-slate-500 transition hover:bg-white hover:text-brand-600 hover:shadow-sm active:scale-90 dark:text-slate-400 dark:hover:bg-white/10 dark:hover:text-brand-300"
                              >
                                <CatIcon name={iconKey} className="h-[15px] w-[15px]" />
                              </button>
                            ))}
                          </div>
                        </div>
                      ) : null}

                      <Textarea
                        id={`ed-content-${tab}`}
                        dir={tab === "ar" ? "rtl" : "ltr"}
                        value={tab === "ar" ? editor.contentAr : editor.contentEn}
                        onChange={(e) =>
                          patchEditor(tab === "ar" ? { contentAr: e.target.value } : { contentEn: e.target.value })
                        }
                        className="min-h-[340px] rounded-xl font-mono text-[12px] leading-relaxed"
                        placeholder={t("blogEdContentHint")}
                        maxLength={60000}
                      />
                      <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                        {t("blogEdWordCount", { n: fmtNum(tab === "ar" ? countWords(editor.contentAr) : countWords(editor.contentEn), lang) })}
                        {" · "}
                        {t("blogEdContentHint")}
                      </p>
                    </div>
                  </TabsContent>
                ))}
              </Tabs>
            </div>

            {/* ------- right column: settings + preview ------- */}
            <div className="space-y-4 p-5">
              {/* slug */}
              <div className="space-y-1.5">
                <Label htmlFor="ed-slug" className="text-[11.5px] font-bold">
                  {t("blogEdSlug")}
                </Label>
                <div dir="ltr" className="flex items-center rounded-xl border border-slate-200 bg-slate-50/70 ps-3 dark:border-white/10 dark:bg-white/[0.03]">
                  <span className="select-none text-[11px] font-bold text-slate-400">/blog/</span>
                  <input
                    id="ed-slug"
                    value={editor.slug}
                    onChange={(e) => patchEditor({ slug: e.target.value.replace(/[^a-zA-Z0-9-]/g, "-").toLowerCase(), slugTouched: true })}
                    className="h-10 w-full bg-transparent px-2 text-[12.5px] font-bold text-slate-700 outline-none dark:text-slate-200"
                    maxLength={96}
                  />
                </div>
                <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500">{t("blogEdSlugHint")}</p>
              </div>

              {/* tags */}
              <div className="space-y-1.5">
                <Label htmlFor="ed-tags" className="text-[11.5px] font-bold">
                  {t("blogEdTags")}
                </Label>
                <Input
                  id="ed-tags"
                  value={editor.tags}
                  onChange={(e) => patchEditor({ tags: e.target.value })}
                  className="h-10 rounded-xl text-[12.5px] font-semibold"
                  placeholder="growth, security, guide"
                  maxLength={200}
                />
                <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500">{t("blogEdTagsHint")}</p>
                {editor.tags.trim() ? (
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {editor.tags
                      .split(",")
                      .map((tg) => tg.trim().toLowerCase())
                      .filter(Boolean)
                      .slice(0, 6)
                      .map((tg) => (
                        <Badge key={tg} variant="secondary" className="rounded-full text-[10px] font-bold">
                          #{tg}
                        </Badge>
                      ))}
                  </div>
                ) : null}
              </div>

              {/* author + status + featured */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label htmlFor="ed-author" className="text-[11.5px] font-bold">
                    {t("blogEdAuthor")}
                  </Label>
                  {/* ROUND 129 — auto-assigned and LOCKED: create stamps the
                      signed-in admin, edit keeps the original author; the
                      server enforces the same contract. */}
                  <div className="relative">
                    <Input
                      id="ed-author"
                      value={editor.authorName}
                      readOnly
                      aria-readonly="true"
                      className="h-10 cursor-default rounded-xl bg-slate-50 pe-9 text-[12.5px] font-semibold text-slate-500 dark:bg-white/[0.04] dark:text-slate-400"
                    />
                    <CatIcon
                      name="lock"
                      className="pointer-events-none absolute end-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400"
                      aria-hidden="true"
                    />
                  </div>
                  <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                    {t("blogAuthorAuto")}
                  </p>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="ed-status" className="text-[11.5px] font-bold">
                    {t("blogEdStatus")}
                  </Label>
                  <select
                    id="ed-status"
                    value={editor.status}
                    onChange={(e) => patchEditor({ status: e.target.value as "draft" | "published" })}
                    className="h-10 w-full cursor-pointer rounded-xl border border-slate-200 bg-white px-3 text-[12.5px] font-bold text-slate-700 outline-none transition focus-visible:ring-4 focus-visible:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200"
                  >
                    <option value="draft">{t("blogStatusDraft")}</option>
                    <option value="published">{t("blogStatusPublished")}</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-between rounded-xl border border-slate-200 bg-white/60 px-4 py-3 dark:border-white/10 dark:bg-white/[0.03]">
                <div className="min-w-0">
                  <p className="text-[12px] font-extrabold text-slate-800 dark:text-slate-100">{t("blogEdFeatured")}</p>
                </div>
                <Switch checked={editor.featured} onCheckedChange={(v) => patchEditor({ featured: v })} />
              </div>

              {/* cover */}
              <div className="space-y-2">
                <Label className="text-[11.5px] font-bold">{t("blogEdCover")}</Label>
                <div className="relative h-32 overflow-hidden rounded-2xl border border-slate-200 dark:border-white/10">
                  {editor.coverImage ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={editor.coverImage} alt="" className="h-full w-full object-cover" />
                  ) : (() => {
                    const [c1, c2, icon] = editorGradient((editor.titleAr || editor.titleEn || editor.id || "cover"));
                    return (
                      <div className="grid h-full w-full place-items-center" style={{ backgroundImage: grad(c1, c2) }}>
                        <CatIcon name={icon} className="h-7 w-7 text-white/70" />
                      </div>
                    );
                  })()}
                  {canManage ? (
                    <div className="absolute inset-x-0 bottom-0 flex items-center justify-center gap-1.5 bg-linear-to-t from-black/60 to-transparent p-2">
                      <button
                        type="button"
                        onClick={() => fileRef.current?.click()}
                        className="rounded-lg bg-white/90 px-2.5 py-1 text-[10.5px] font-extrabold text-slate-700 shadow transition hover:bg-white active:scale-95"
                      >
                        {editor.coverImage ? t("blogEdCoverChange") : t("blogEdCoverUpload")}
                      </button>
                      {editor.coverImage ? (
                        <button
                          type="button"
                          onClick={() => patchEditor({ coverImage: "", coverIsManaged: false })}
                          className="rounded-lg bg-rose-500/90 px-2.5 py-1 text-[10.5px] font-extrabold text-white shadow transition hover:bg-rose-500 active:scale-95"
                        >
                          {t("blogEdCoverRemove")}
                        </button>
                      ) : null}
                    </div>
                  ) : null}
                  <input
                    ref={fileRef}
                    type="file"
                    accept="image/png,image/jpeg,image/webp"
                    className="hidden"
                    onChange={(e) => pickCover(e.target.files?.[0])}
                  />
                </div>
                <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500">{t("blogEdCoverHint")}</p>
              </div>

              {/* reading estimate */}
              <div className="flex items-center justify-between rounded-xl border border-brand-200/70 bg-brand-500/[0.06] px-4 py-3 dark:border-brand-500/30 dark:bg-brand-500/[0.08]">
                <span className="flex items-center gap-2 text-[12px] font-bold text-slate-700 dark:text-slate-200">
                  <CatIcon name="clock" className="h-[13px] w-[13px] text-brand-500" />
                  {t("blogEdReadEst")}
                </span>
                <span className="font-display text-lg font-extrabold tabular-nums text-brand-600 dark:text-brand-300">
                  {fmtNum(estimate, lang)}
                  <span className="ms-1 text-[10px] font-bold">{t("blogEdReadUnit")}</span>
                </span>
              </div>

              {/* live preview toggle */}
              <button
                type="button"
                onClick={() => setPreviewOn((v) => !v)}
                className={cn(
                  "flex w-full items-center justify-between rounded-xl border px-4 py-3 text-[12px] font-extrabold transition",
                  previewOn
                    ? "border-brand-300 bg-brand-500/10 text-brand-600 dark:border-brand-500/40 dark:text-brand-300"
                    : "border-slate-200 bg-white text-slate-600 hover:border-brand-200 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-300"
                )}
              >
                <span className="flex items-center gap-2">
                  <CatIcon name="eye" className="h-[13px] w-[13px]" />
                  {t("blogEdPreview")}
                </span>
                <CatIcon name={previewOn ? "chevron-up" : "chevron-down"} className="h-[13px] w-[13px]" />
              </button>

              {previewOn ? (
                <div
                  dir={activeTab === "ar" ? "rtl" : "ltr"}
                  className="max-h-72 overflow-y-auto nice-scrollbar rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/[0.02]"
                >
                  <h2 className="mb-3 font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                    {activeTab === "ar" ? editor.titleAr || "—" : editor.titleEn || editor.titleAr || "—"}
                  </h2>
                  <div
                    className={cn(
                      "text-[12.5px] leading-[1.85] text-slate-600 dark:text-slate-300",
                      "[&_h2]:mt-5 [&_h2]:mb-2 [&_h2]:font-display [&_h2]:text-[15px] [&_h2]:font-extrabold [&_h2]:text-slate-900 dark:[&_h2]:text-white",
                      "[&_h3]:mt-4 [&_h3]:mb-2 [&_h3]:font-display [&_h3]:text-[13.5px] [&_h3]:font-extrabold [&_h3]:text-slate-800 dark:[&_h3]:text-slate-100",
                      "[&_p]:mt-2 [&_p]:mb-2",
                      "[&_strong]:font-extrabold [&_strong]:text-slate-800 dark:[&_strong]:text-slate-100",
                      "[&_code]:rounded bg-slate-100 px-1 py-0.5 font-mono text-[11px] text-brand-600 dark:bg-white/10 dark:text-brand-300",
                      "[&_ul]:mt-2 [&_ul]:mb-2 [&_ul]:list-disc [&_ul]:ps-5 [&_ul]:space-y-1",
                      "[&_ol]:mt-2 [&_ol]:mb-2 [&_ol]:list-decimal [&_ol]:ps-5 [&_ol]:space-y-1",
                      "[&_blockquote]:my-3 [&_blockquote]:rounded-xl [&_blockquote]:border-s-4 [&_blockquote]:border-brand-400 [&_blockquote]:bg-brand-500/[0.06] [&_blockquote]:p-3 [&_blockquote]:text-[12px] [&_blockquote]:font-semibold",
                      "[&_hr]:my-5 [&_hr]:border-slate-200 dark:[&_hr]:border-white/10"
                    )}
                    dangerouslySetInnerHTML={{ __html: previewHtml }}
                  />
                </div>
              ) : null}
            </div>
          </div>

          {/* footer actions */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200/70 px-6 py-4 dark:border-white/10">
            <p className="text-[11px] font-bold text-slate-400 dark:text-slate-500">
              {t("sysShowing")} {fmtNum(activeWords, lang)} {t("blogEdWordCount", { n: fmtNum(activeWords, lang) })}
            </p>
            <div className="flex items-center gap-2">
              <Button variant="outline" onClick={() => setEditorOpen(false)} className="rounded-xl px-5">
                {t("blogEdCancel")}
              </Button>
              {canManage ? (
                <Button
                  onClick={handleSave}
                  disabled={saving || saveMutation.isPending}
                  className="rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-6 font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
                >
                  <CatIcon name="save" className="h-[13px] w-[13px]" />
                  {editor.status === "published" ? t("blogEdSave") : t("blogEdSave")}
                </Button>
              ) : null}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ---------------- delete confirm ---------------- */}
      <AlertDialog open={deleteTarget !== null} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 font-display">
              <IconTile icon="triangle-alert" c1="#e11d48" c2="#be123c" size="sm" />
              {t("blogDeleteTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {t("blogDeleteDesc", { title: deleteTarget?.titleAr ?? "" })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-xl">{t("blogEdCancel")}</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteTarget && deleteMutation.mutate(deleteTarget.id)}
              disabled={deleteMutation.isPending}
              className="rounded-xl bg-rose-600 font-extrabold text-white hover:bg-rose-500"
            >
              <CatIcon name="trash-2" className="h-[13px] w-[13px]" />
              {t("blogDeleteTitle")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default AdminBlog;
