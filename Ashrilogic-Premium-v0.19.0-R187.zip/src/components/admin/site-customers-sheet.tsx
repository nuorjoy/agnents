"use client";

/**
 * Ashrilogic — per-site customer manager (round 28).
 *
 * Premium Sheet opened from the admin Sites view: the website's registered
 * customer accounts with live moderation. Identity banner (org + system +
 * theme + live/draft), a KPI mini-strip (total / active / banned / inquiries),
 * a searchable account list (avatar tile, name, end-aligned LTR email, phone,
 * inquiry count, member-since + last-login with full-date tooltips) and real
 * actions — ban / reactivate (cuts off live sessions server-side) and delete
 * with count-aware bilingual confirm dialogs. Arabic-first typography.
 */
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CATEGORY_MAP, SYSTEM_MAP } from "@/data/catalog";
import {
  deleteSiteCustomer,
  fetchSiteCustomers,
  setSiteCustomerStatus,
  verifySiteCustomerAdmin,
} from "@/lib/api-client";
import { useAdminCanManage } from "@/lib/admin-auth";
import { useT } from "@/lib/i18n";
import type { AdminSiteDTO, SiteCustomerAdminDTO } from "@/lib/types";
import { siteTheme } from "@/lib/site-themes";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, initial, labelTrack, normalizeSearch } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { IconTile, fullDate, relativeTime } from "@/components/dashboard/dash-shared";
import { SiteInquiriesDialog } from "@/components/dashboard/views/site-inquiries-dialog";

/* ---------------- mini KPI ---------------- */

function MiniKpi({
  icon,
  c1,
  c2,
  label,
  value,
  accent,
  sub,
  onClick,
  ariaLabel,
}: {
  icon: string;
  c1: string;
  c2: string;
  label: string;
  value: string;
  accent?: string;
  /** ROUND 77 — optional sub-line (e.g. the amber open-inquiries backlog). */
  sub?: { text: string; hot?: boolean } | null;
  /** ROUND 77 — optional interactivity (the inquiries KPI opens triage). */
  onClick?: () => void;
  ariaLabel?: string;
}) {
  const inner = (
    <>
      <span
        className="grid h-8 w-8 shrink-0 place-items-center rounded-xl text-white"
        style={{ backgroundImage: grad(c1, c2) }}
        aria-hidden="true"
      >
        <CatIcon name={icon} className="h-[14px] w-[14px]" />
      </span>
      <div className="min-w-0">
        <p className={cn("truncate text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", accent)}>
          {label}
        </p>
        <p dir="ltr" className="text-start font-display text-[17px] font-extrabold tabular-nums text-slate-800 dark:text-slate-100">
          {value}
        </p>
        {sub ? (
          <p
            className={cn(
              "mt-0.5 inline-flex items-center gap-1 rounded-full px-1.5 py-0.5 text-[9px] font-extrabold",
              sub.hot
                ? "bg-amber-500/10 text-amber-600 dark:bg-amber-500/15 dark:text-amber-300"
                : "text-slate-400 dark:text-slate-500"
            )}
          >
            {sub.hot ? <span className="h-1 w-1 animate-pulse rounded-full bg-current" aria-hidden="true" /> : null}
            {sub.text}
          </p>
        ) : null}
      </div>
    </>
  );

  if (onClick) {
    return (
      <button
        type="button"
        onClick={onClick}
        aria-label={ariaLabel}
        title={ariaLabel}
        className="flex min-w-0 flex-1 items-center gap-2.5 rounded-2xl border border-slate-200/80 bg-white/70 p-2.5 text-start transition hover:border-cyan-300 hover:bg-cyan-50/50 hover:shadow-md hover:shadow-cyan-500/10 active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-500 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-cyan-500/40 dark:hover:bg-cyan-500/[0.06]"
      >
        {inner}
      </button>
    );
  }

  return (
    <div className="flex min-w-0 flex-1 items-center gap-2.5 rounded-2xl border border-slate-200/80 bg-white/70 p-2.5 dark:border-white/10 dark:bg-white/[0.03]">
      {inner}
    </div>
  );
}

/* ---------------- customer row ---------------- */

function CustomerRow({
  customer,
  canManage,
  onBanToggle,
  onDelete,
  onVerify,
  onInquiries,
  pending,
}: {
  customer: SiteCustomerAdminDTO;
  /** round 29 — moderation buttons hidden for below-admin roles */
  canManage: boolean;
  onBanToggle: (customer: SiteCustomerAdminDTO) => void;
  onDelete: (customer: SiteCustomerAdminDTO) => void;
  /** ROUND 75 — opens the staff-assisted verification dialog. */
  onVerify: (customer: SiteCustomerAdminDTO) => void;
  /** ROUND 77 — opens the triage dialog scoped to this customer. */
  onInquiries: (customer: SiteCustomerAdminDTO) => void;
  pending: boolean;
}) {
  const { t, lang } = useT();
  const banned = customer.status === "banned";

  return (
    <li
      className={cn(
        "relative overflow-hidden rounded-2xl border p-3.5 transition",
        banned
          ? "border-rose-200/80 bg-rose-50/50 dark:border-rose-500/20 dark:bg-rose-500/[0.06]"
          : "border-slate-200/70 bg-white/60 hover:border-brand-200 hover:bg-brand-50/40 dark:border-white/[0.07] dark:bg-white/[0.03] dark:hover:border-brand-500/30 dark:hover:bg-brand-500/[0.05]"
      )}
    >
      <div className="flex items-start gap-3">
        {/* avatar tile — status-aware gradient */}
        <span
          className={cn(
            "grid h-10 w-10 shrink-0 place-items-center rounded-xl font-display text-[14px] font-extrabold text-white",
            banned ? "" : ""
          )}
          style={{
            backgroundImage: banned
              ? grad("#f43f5e", "#e11d48")
              : grad("#6d5dfb", "#d946ef"),
          }}
          aria-hidden="true"
        >
          {initial(customer.name)}
        </span>

        {/* identity + meta */}
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
            <p
              className={cn(
                "truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100",
                banned && "line-through decoration-rose-400/70 decoration-2"
              )}
            >
              {customer.name}
            </p>
            {banned ? (
              <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-rose-300/60 bg-rose-500/10 px-2 py-0.5 text-[11px] font-extrabold text-rose-600 dark:border-rose-500/40 dark:text-rose-300">
                <CatIcon name="user-round-x" className="h-[9px] w-[9px]" />
                {t("siteCustStatusBanned")}
              </span>
            ) : (
              <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-emerald-300/60 bg-emerald-500/10 px-2 py-0.5 text-[11px] font-extrabold text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300">
                <CatIcon name="user-round-check" className="h-[9px] w-[9px]" />
                {t("siteCustStatusActive")}
              </span>
            )}
            {/* ROUND 75 — email verification state (amber opens the
                staff-assisted verify dialog; emerald is informational) */}
            {customer.emailVerified ? (
              <span
                title={t("siteCustVerifyHint")}
                className="inline-flex shrink-0 items-center gap-1 rounded-full border border-emerald-300/60 bg-emerald-500/10 px-2 py-0.5 text-[11px] font-extrabold text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
              >
                <CatIcon name="badge-check" className="h-[9px] w-[9px]" />
                {t("siteCustVerified")}
              </span>
            ) : (
              <button
                type="button"
                onClick={() => onVerify(customer)}
                title={t("siteCustVerifyBtnHint")}
                aria-label={`${t("siteCustVerifyBtnHint")} — ${customer.name}`}
                className="inline-flex shrink-0 items-center gap-1 rounded-full border border-amber-300/70 bg-amber-500/10 px-2 py-0.5 text-[11px] font-extrabold text-amber-600 transition hover:bg-amber-500/20 hover:ring-2 hover:ring-amber-400/30 active:scale-95 dark:border-amber-500/40 dark:text-amber-300 dark:hover:bg-amber-500/25"
              >
                <CatIcon name="mail-warning" className="h-[9px] w-[9px]" />
                {t("siteCustUnverified")}
              </button>
            )}
            {customer.inquiries > 0 ? (
              <button
                type="button"
                onClick={() => onInquiries(customer)}
                title={t("siteCustInquiriesHint")}
                aria-label={`${t("siteCustInquiriesHint")} — ${customer.name}`}
                dir="ltr"
                className="inline-flex shrink-0 items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 text-[11px] font-extrabold tabular-nums text-slate-500 transition hover:bg-cyan-500/10 hover:text-cyan-600 hover:ring-2 hover:ring-cyan-400/30 active:scale-95 dark:bg-white/10 dark:text-slate-400 dark:hover:bg-cyan-500/15 dark:hover:text-cyan-300"
              >
                <CatIcon name="message-square" className="h-[8px] w-[8px]" />
                {fmtNum(customer.inquiries, lang)}
              </button>
            ) : null}
          </div>
          <p
            dir="ltr"
            className={cn("mt-0.5 truncate text-[11.5px] font-semibold text-slate-500 dark:text-slate-400", lang === "ar" ? "text-end" : "text-start")}
          >
            {customer.email}
          </p>
          <div className="mt-1.5 flex flex-wrap items-center gap-x-2.5 gap-y-0.5 text-[10px] font-semibold text-slate-400 dark:text-slate-500">
            {customer.phone ? (
              <span dir="ltr" className="inline-flex items-center gap-1">
                <CatIcon name="phone" className="h-[9px] w-[9px]" />
                {customer.phone}
              </span>
            ) : null}
            <span title={fullDate(customer.createdAt, lang)}>
              {t("siteCustMemberSince")} {relativeTime(customer.createdAt, lang)}
            </span>
            <span aria-hidden="true">·</span>
            <span
              title={customer.lastLoginAt ? fullDate(customer.lastLoginAt, lang) : t("siteCustNever")}
              className={cn(!customer.lastLoginAt && "italic")}
            >
              {customer.lastLoginAt
                ? `${t("siteCustLastLogin")} ${relativeTime(customer.lastLoginAt, lang)}`
                : t("siteCustNeverLogin")}
            </span>
          </div>
        </div>

        {/* actions — ROUND 36: side-by-side (was a stacked column that
            escaped the card frame on narrow sheets); contained by
            overflow-hidden + shrink-0 + self-start so the delete icon always
            sits INSIDE the frame. */}
        {canManage ? (
          <div className="flex shrink-0 flex-row items-center gap-1.5 self-start">
            <button
              type="button"
              onClick={() => onBanToggle(customer)}
              disabled={pending}
              title={banned ? t("siteCustUnbanHint") : t("siteCustBanHint")}
              className={cn(
                "inline-flex h-8 items-center gap-1.5 rounded-xl border px-2.5 text-[10.5px] font-extrabold transition active:scale-95 disabled:opacity-50",
                banned
                  ? "border-emerald-200 bg-emerald-50 text-emerald-600 hover:bg-emerald-100 dark:border-emerald-500/25 dark:bg-emerald-500/10 dark:text-emerald-300 dark:hover:bg-emerald-500/20"
                  : "border-rose-200 bg-rose-50 text-rose-600 hover:bg-rose-100 dark:border-rose-500/25 dark:bg-rose-500/10 dark:text-rose-300 dark:hover:bg-rose-500/20"
              )}
            >
              <CatIcon name={banned ? "user-round-check" : "user-round-x"} className="h-[12px] w-[12px]" />
              <span className="hidden sm:inline">{t(banned ? "siteCustUnban" : "siteCustBan")}</span>
            </button>
            <button
              type="button"
              onClick={() => onDelete(customer)}
              disabled={pending}
              title={t("siteCustDelete")}
              aria-label={`${t("siteCustDelete")} — ${customer.email}`}
              className="inline-flex h-8 w-8 shrink-0 place-items-center rounded-xl border border-slate-200 text-slate-400 transition hover:border-rose-300 hover:text-rose-500 active:scale-95 disabled:opacity-50 dark:border-white/10 dark:text-slate-500 dark:hover:border-rose-500/40 dark:hover:text-rose-300"
            >
              <CatIcon name="trash-2" className="h-[13px] w-[13px]" />
            </button>
          </div>
        ) : (
          <span
            title={t("adminNoPerm")}
            className="grid h-8 w-8 shrink-0 place-items-center self-start rounded-xl border border-dashed border-slate-300 text-slate-300 dark:border-white/15 dark:text-slate-600"
            aria-hidden="true"
          >
            <CatIcon name="lock" className="h-[12px] w-[12px]" />
          </span>
        )}
      </div>
    </li>
  );
}

/* ---------------- sheet ---------------- */

export function SiteCustomersSheet({
  site,
  open,
  onOpenChange,
}: {
  site: AdminSiteDTO | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  /* round 29 — moderation is super/admin (server-enforced) */
  const canManage = useAdminCanManage();

  const [search, setSearch] = useState("");
  const [pendingBan, setPendingBan] = useState<SiteCustomerAdminDTO | null>(null);
  const [pendingDelete, setPendingDelete] = useState<SiteCustomerAdminDTO | null>(null);
  /* ROUND 75 — staff-assisted email verification */
  const [pendingVerify, setPendingVerify] = useState<SiteCustomerAdminDTO | null>(null);
  /* ROUND 77 — the Super Admin triage dialog (all of the site's inquiries,
   * or scoped to one customer via the row chips). */
  const [inqDialog, setInqDialog] = useState<{ open: boolean; customer: SiteCustomerAdminDTO | null }>({
    open: false,
    customer: null,
  });

  const query = useQuery({
    queryKey: ["site-customers", site?.instanceId],
    queryFn: () => fetchSiteCustomers(site!.instanceId),
    enabled: open && site !== null,
    staleTime: 10_000,
  });

  const customers = useMemo(() => query.data?.customers ?? [], [query.data]);
  const counts = query.data?.counts;

  const filtered = useMemo(() => {
    const q = normalizeSearch(search.trim());
    if (!q) return customers;
    return customers.filter((c) => normalizeSearch(`${c.name} ${c.email} ${c.phone ?? ""}`).includes(q));
  }, [customers, search]);

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["site-customers", site?.instanceId] });
    queryClient.invalidateQueries({ queryKey: ["admin-sites"] });
  };

  const banToggle = useMutation({
    mutationFn: (customer: SiteCustomerAdminDTO) =>
      setSiteCustomerStatus(site!.instanceId, customer.id, customer.status === "banned" ? "active" : "banned"),
    onSuccess: (_data, customer) => {
      toast.success(t(customer.status === "banned" ? "siteCustUnbannedToast" : "siteCustBannedToast", { name: customer.name }));
      setPendingBan(null);
      invalidate();
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  const remove = useMutation({
    mutationFn: (customer: SiteCustomerAdminDTO) => deleteSiteCustomer(site!.instanceId, customer.id),
    onSuccess: (_data, customer) => {
      toast.success(t("siteCustDeletedToast", { name: customer.name }));
      setPendingDelete(null);
      invalidate();
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  /* ROUND 75 — Super Admin verification actions (manual confirm or
   * re-dispatch the single-use link; the admin never sees the link). */
  const verifyAction = useMutation({
    mutationFn: ({ customer, action }: { customer: SiteCustomerAdminDTO; action: "verify" | "resendVerify" }) =>
      verifySiteCustomerAdmin(site!.instanceId, customer.id, action),
    onSuccess: (_data, { action }) => {
      toast.success(t(action === "verify" ? "siteCustVerifyDone" : "siteCustResendDone"));
      if (action === "verify") setPendingVerify(null);
      invalidate();
    },
    onError: (error: Error) => {
      const code = (error as { code?: string }).code;
      toast.error(
        code === "RESEND_COOLDOWN" ? t("acctVerifyWaitToast") : t("siteCustVerifyFail")
      );
    },
  });

  const sys = site ? SYSTEM_MAP[site.systemId] : undefined;
  const cat = sys ? CATEGORY_MAP[sys.c] : undefined;
  const theme = site ? siteTheme(site.theme) : null;
  const pending = banToggle.isPending || remove.isPending || verifyAction.isPending;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side={lang === "ar" ? "left" : "right"}
        className="w-full gap-0 overflow-y-auto p-0 sm:max-w-xl"
      >
        {site ? (
          <>
            {/* identity banner — pe-9 clears the sheet's floating close (X)
                button (absolute top-4 end-4) so the live/draft badge is never
                covered by it (round 35 fix) */}
            <SheetHeader className="border-b border-slate-200/70 bg-slate-50/80 px-5 py-4 pe-14 dark:border-white/10 dark:bg-white/[0.03]">
              <SheetTitle className="flex items-start gap-3">
                <IconTile icon={sys?.icon ?? "globe"} c1={cat?.c1 ?? "#6d5dfb"} c2={cat?.c2 ?? "#06b6d4"} size="md" />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                    {t("siteCustTitle")}
                  </p>
                  <p className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                    <span className="truncate">{site.orgName}</span>
                    <span aria-hidden="true">·</span>
                    <span className="truncate">{sys ? (lang === "ar" ? sys.nameAr : sys.nameEn) : site.systemId}</span>
                    {theme ? (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="inline-flex items-center gap-1">
                          <span
                            className="h-2 w-2 rounded-full"
                            style={{ backgroundImage: grad(theme.c1, theme.c2) }}
                            aria-hidden="true"
                          />
                          {lang === "ar" ? theme.labelAr : theme.labelEn}
                        </span>
                      </>
                    ) : null}
                  </p>
                </div>
                <span
                  className={cn(
                    "inline-flex shrink-0 items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-extrabold",
                    site.published
                      ? "border-emerald-400/60 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
                      : "border-amber-400/60 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-400"
                  )}
                >
                  <span className={cn("h-1.5 w-1.5 rounded-full", site.published ? "bg-emerald-500" : "bg-amber-500")} aria-hidden="true" />
                  {t(site.published ? "adminSitesLiveBadge" : "adminSitesDraftBadge")}
                </span>
              </SheetTitle>
              <SheetDescription className="sr-only">{t("siteCustDesc")}</SheetDescription>
            </SheetHeader>

            <div className="space-y-4 p-5">
              {/* KPI mini-strip */}
              {query.isPending ? (
                <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <Skeleton key={i} className="h-16 w-full rounded-2xl" />
                  ))}
                </div>
              ) : counts ? (
                <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
                  <MiniKpi icon="users-round" c1="#6d5dfb" c2="#4b35c9" label={t("siteCustKpiTotal")} value={fmtNum(counts.total, lang)} />
                  <MiniKpi icon="user-round-check" c1="#10b981" c2="#059669" label={t("siteCustKpiActive")} value={fmtNum(counts.active, lang)} />
                  <MiniKpi icon="user-round-x" c1="#f43f5e" c2="#e11d48" label={t("siteCustKpiBanned")} value={fmtNum(counts.banned, lang)} />
                  {/* ROUND 77 — the inquiries KPI opens the triage inbox; the
                      amber sub-badge surfaces the open backlog at a glance. */}
                  <MiniKpi
                    icon="message-square"
                    c1="#06b6d4"
                    c2="#0891b2"
                    label={t("siteCustKpiInquiries")}
                    value={fmtNum(counts.inquiries, lang)}
                    sub={
                      (counts.openInquiries ?? 0) > 0
                        ? {
                            text: `${t("siteCustKpiOpenNow")}: ${fmtNum(counts.openInquiries ?? 0, lang)}`,
                            hot: true,
                          }
                        : counts.inquiries > 0
                          ? { text: t("siteCustKpiAllAnswered") }
                          : null
                    }
                    onClick={() => setInqDialog({ open: true, customer: null })}
                    ariaLabel={`${t("siteInqOpenBtn")} — ${site.orgName}`}
                  />
                </div>
              ) : null}

              {/* search */}
              <div className="relative">
                <CatIcon
                  name="search"
                  className="pointer-events-none absolute start-3.5 top-1/2 h-[13px] w-[13px] -translate-y-1/2 text-slate-400"
                />
                <input
                  type="search"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder={t("siteCustSearchPh")}
                  aria-label={t("siteCustSearchPh")}
                  className="h-10 w-full rounded-xl border border-slate-200 bg-slate-50/80 ps-10 pe-3 text-[12.5px] font-semibold text-slate-800 outline-none transition placeholder:font-normal placeholder:text-slate-400 focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:focus:bg-white/[0.07]"
                />
              </div>

              {/* list */}
              {query.isPending ? (
                <div className="space-y-2.5">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <Skeleton key={i} className="h-24 w-full rounded-2xl" />
                  ))}
                </div>
              ) : query.isError ? (
                <div className="py-12 text-center">
                  <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-rose-100 text-rose-500 dark:bg-rose-500/10 dark:text-rose-300">
                    <CatIcon name="circle-alert" className="h-6 w-6" />
                  </div>
                  <p className="mt-3 font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
                    {t("errorText")}
                  </p>
                  <button
                    type="button"
                    onClick={() => query.refetch()}
                    className="mt-5 inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 px-5 text-[12.5px] font-bold transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10"
                  >
                    <CatIcon name="refresh-cw" className="h-4 w-4" />
                    {t("retryText")}
                  </button>
                </div>
              ) : filtered.length === 0 ? (
                <div className="py-12 text-center">
                  <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
                    <CatIcon name="users-round" className="h-6 w-6" />
                  </div>
                  <p className="mt-3 font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
                    {search ? t("siteCustNoMatches") : t("siteCustEmpty")}
                  </p>
                  <p className="mx-auto mt-1 max-w-xs text-[12px] font-semibold text-slate-400 dark:text-slate-500">
                    {search ? t("siteCustNoMatchesDesc") : t("siteCustEmptyDesc")}
                  </p>
                </div>
              ) : (
                <>
                  {search ? (
                    <p className={cn("text-[10.5px] font-bold text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {t("siteCustShowing")} {fmtNum(filtered.length, lang)} / {fmtNum(customers.length, lang)}
                    </p>
                  ) : null}
                  <ul className="space-y-2.5">
                    {filtered.map((customer) => (
                      <CustomerRow
                        key={customer.id}
                        customer={customer}
                        canManage={canManage}
                        onBanToggle={setPendingBan}
                        onDelete={setPendingDelete}
                        onVerify={setPendingVerify}
                        onInquiries={(c) => setInqDialog({ open: true, customer: c })}
                        pending={pending}
                      />
                    ))}
                  </ul>
                </>
              )}
            </div>
          </>
        ) : null}
      </SheetContent>

      {/* ban confirm */}
      <AlertDialog open={pendingBan !== null} onOpenChange={(o) => !o && setPendingBan(null)}>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className={cn(
                  "grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg",
                  pendingBan?.status === "banned"
                    ? "bg-linear-to-br from-emerald-500 to-emerald-600 shadow-emerald-500/25"
                    : "bg-linear-to-br from-rose-500 to-rose-600 shadow-rose-500/25"
                )}
                aria-hidden="true"
              >
                <CatIcon
                  name={pendingBan?.status === "banned" ? "user-round-check" : "user-round-x"}
                  className="h-[15px] w-[15px]"
                />
              </span>
              {pendingBan?.status === "banned" ? t("siteCustUnban") : t("siteCustBan")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {pendingBan?.status === "banned"
                ? t("siteCustUnbanMsg", { name: pendingBan?.name ?? "" })
                : t("siteCustBanMsg", { name: pendingBan?.name ?? "" })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          {pendingBan ? (
            <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50/60 p-3 dark:border-white/15 dark:bg-white/[0.03]">
              <p className="truncate text-[12.5px] font-extrabold text-slate-700 dark:text-slate-200">{pendingBan.name}</p>
              <p dir="ltr" className="truncate text-end font-mono text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                {pendingBan.email}
              </p>
            </div>
          ) : null}
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={pending}>
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => pendingBan && banToggle.mutate(pendingBan)}
              disabled={pending}
              className={cn(
                "h-10 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition active:scale-95 disabled:opacity-60",
                pendingBan?.status === "banned"
                  ? "bg-emerald-600 shadow-emerald-500/25 hover:bg-emerald-700"
                  : "bg-rose-600 shadow-rose-500/25 hover:bg-rose-700"
              )}
            >
              {banToggle.isPending ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : null}
              {pendingBan?.status === "banned" ? t("siteCustUnbanConfirm") : t("siteCustBanConfirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* delete confirm */}
      <AlertDialog open={pendingDelete !== null} onOpenChange={(o) => !o && setPendingDelete(null)}>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-linear-to-br from-slate-600 to-slate-700 text-white shadow-lg shadow-slate-500/25" aria-hidden="true">
                <CatIcon name="trash-2" className="h-[15px] w-[15px]" />
              </span>
              {t("siteCustDelete")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("siteCustDeleteMsg", { name: pendingDelete?.name ?? "" })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          {pendingDelete ? (
            <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50/60 p-3 dark:border-white/15 dark:bg-white/[0.03]">
              <p className="truncate text-[12.5px] font-extrabold text-slate-700 dark:text-slate-200">{pendingDelete.name}</p>
              <p dir="ltr" className="truncate text-end font-mono text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                {pendingDelete.email}
              </p>
            </div>
          ) : null}
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={pending}>
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => pendingDelete && remove.mutate(pendingDelete)}
              disabled={pending}
              className="h-10 rounded-xl bg-rose-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60"
            >
              {remove.isPending ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : null}
              {t("siteCustDeleteConfirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ROUND 75 — staff-assisted email verification (Super Admin twin of
          the owner console dialog: re-dispatch the link, or confirm on the
          customer's behalf when the identity checked out out-of-band) */}
      <AlertDialog open={pendingVerify !== null} onOpenChange={(o) => !o && setPendingVerify(null)}>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-linear-to-br from-amber-500 to-orange-500 text-white shadow-lg shadow-amber-500/25"
                aria-hidden="true"
              >
                <CatIcon name="mail-warning" className="h-[15px] w-[15px]" />
              </span>
              {t("siteCustVerifyTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("siteCustVerifyDesc", { name: pendingVerify?.name ?? "" })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          {pendingVerify ? (
            <div className="rounded-xl border border-dashed border-amber-300 bg-amber-50/50 p-3 dark:border-amber-500/30 dark:bg-amber-500/[0.06]">
              <p className="truncate text-[12.5px] font-extrabold text-slate-700 dark:text-slate-200">{pendingVerify.name}</p>
              <p dir="ltr" className="truncate text-end font-mono text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                {pendingVerify.email}
              </p>
            </div>
          ) : null}
          <AlertDialogFooter className="flex-col gap-2 sm:flex-row sm:items-center">
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={pending}>
              {t("dlgCancel")}
            </AlertDialogCancel>
            <div className="flex flex-1 flex-col-reverse gap-2 sm:flex-row sm:justify-end">
              <button
                type="button"
                onClick={() =>
                  pendingVerify &&
                  verifyAction.mutate({ customer: pendingVerify, action: "resendVerify" })
                }
                disabled={pending}
                className="inline-flex h-10 items-center justify-center gap-1.5 rounded-xl border border-amber-300 bg-amber-50 px-5 text-[12.5px] font-extrabold text-amber-700 shadow-sm transition hover:bg-amber-100 active:scale-95 disabled:opacity-60 dark:border-amber-500/40 dark:bg-amber-500/10 dark:text-amber-300 dark:hover:bg-amber-500/20"
              >
                <CatIcon name="send" className="h-4 w-4" />
                {t("siteCustVerifyResend")}
              </button>
              <button
                type="button"
                onClick={() =>
                  pendingVerify && verifyAction.mutate({ customer: pendingVerify, action: "verify" })
                }
                disabled={pending}
                className="inline-flex h-10 items-center justify-center gap-1.5 rounded-xl bg-linear-to-r from-amber-500 to-orange-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-amber-500/30 transition hover:brightness-105 active:scale-95 disabled:opacity-60"
              >
                <CatIcon
                  name={verifyAction.isPending ? "refresh-cw" : "badge-check"}
                  className={cn("h-4 w-4", verifyAction.isPending && "animate-spin")}
                />
                {t("siteCustVerifyManual")}
              </button>
            </div>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      {/* ROUND 77 — the Super Admin's triage inbox (platform-side twin of
          the owner's ROUND 74 dialog: same SUPPORT dictionary, same reply
          flow — the customer reads the same words either way). */}
      <SiteInquiriesDialog
        open={inqDialog.open}
        onOpenChange={(open) => setInqDialog((prev) => ({ ...prev, open }))}
        instanceId={site?.instanceId ?? ""}
        customer={inqDialog.customer}
        variant="admin"
        orgName={site?.orgName}
      />
    </Sheet>
  );
}

export default SiteCustomersSheet;
