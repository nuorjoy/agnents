"use client";

/**
 * AshriLogic — EMAIL SYSTEM — the Communications → Email admin section.
 *
 * The console's operational window over the unified mail pipeline
 * (Settings → Communications → Email):
 *
 *   ├── SMTP Configuration + Sender Identity   (Super-Admin only — the
 *   │    password is write-only and sealed AES-256-GCM server-side)
 *   ├── Test Email      (admin+super — a real round-trip through the
 *   │                     production pipeline, rate-limited)
 *   ├── Email Health    (admin+super — connection probe + honest
 *   │                     SPF/DKIM/DMARC DNS states + trail stats)
 *   └── Delivery Logs   (admin+super — the paginated EmailLog feed;
 *                         recipients masked for non-super server-side)
 *
 * Follows the AiAdminSection pattern: self-contained client component with
 * its own fetch/save/test mutations; the routes enforce every gate
 * independently of this rendering.
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import {
  fetchEmailLogs,
  fetchMailPanel,
  sendTestMail,
  updateMailSettings,
} from "@/lib/api-client";
import { useT } from "@/lib/i18n";
import type {
  EmailLogDTO,
  EmailLogPageDTO,
  MailPanelDTO,
  MailSettingsDTO,
  MailTestResultDTO,
} from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { cn, grad } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { DashCard, relativeTime } from "@/components/dashboard/dash-shared";

/** Field vocabulary shared with the settings view. */
const FIELD_INPUT =
  "h-11 rounded-xl border-slate-200 bg-slate-50/80 px-3.5 text-[13px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:focus:bg-white/[0.07]";

const clampInt = (n: number, min: number, max: number) =>
  Math.min(max, Math.max(min, Math.round(n)));

/** The email log types the console can filter by (server union). */
const LOG_TYPES = [
  "verification",
  "passwordReset",
  "welcome",
  "securityAlert",
  "subscription",
  "orderStatus",
  "campaign",
  "platformEvent",
  "weeklyDigest",
  "test",
  "system",
] as const;

/* ------------------------------------------------------------------ */
/* small building blocks (the settings view's vocabulary, local copies) */
/* ------------------------------------------------------------------ */

function MailRow({
  icon,
  c1,
  c2,
  label,
  desc,
  htmlFor,
  children,
}: {
  icon?: string;
  c1?: string;
  c2?: string;
  label: string;
  desc?: string;
  htmlFor?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-3 py-4 sm:flex-row sm:items-center sm:justify-between sm:gap-6">
      <div className="flex min-w-0 items-center gap-3">
        {icon ? (
          <span
            aria-hidden="true"
            className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
            style={{ backgroundImage: grad(c1 ?? "#6d5dfb", c2 ?? "#06b6d4") }}
          >
            <CatIcon name={icon} className="h-[12px] w-[12px]" />
          </span>
        ) : null}
        <div className="min-w-0">
          <Label
            htmlFor={htmlFor}
            className="block text-[12.5px] font-extrabold leading-tight text-slate-800 dark:text-slate-100"
          >
            {label}
          </Label>
          {desc ? (
            <p className="mt-0.5 max-w-md text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {desc}
            </p>
          ) : null}
        </div>
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

/** The honest DNS-check badge (pass / fail / error / skipped). */
function DnsBadge({ label, check }: { label: string; check: { status: string; detail: string } }) {
  const { t } = useT();
  const tone =
    check.status === "pass"
      ? "border-emerald-300/70 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
      : check.status === "fail"
        ? "border-rose-300/70 bg-rose-500/10 text-rose-600 dark:border-rose-500/40 dark:text-rose-300"
        : check.status === "error"
          ? "border-amber-300/70 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300"
          : "border-slate-300/70 bg-slate-500/10 text-slate-500 dark:border-white/15 dark:text-slate-400";
  const stateKey =
    check.status === "pass"
      ? "mailDnsPass"
      : check.status === "fail"
        ? "mailDnsFail"
        : check.status === "error"
          ? "mailDnsError"
          : "mailDnsSkipped";
  return (
    <span
      title={check.detail}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-extrabold",
        tone
      )}
    >
      <span
        className={cn(
          "h-1.5 w-1.5 rounded-full",
          check.status === "pass"
            ? "bg-emerald-500"
            : check.status === "fail"
              ? "bg-rose-500"
              : check.status === "error"
                ? "bg-amber-500"
                : "bg-slate-400"
        )}
        aria-hidden="true"
      />
      {label}
      <span className="font-bold opacity-80">· {t(stateKey as never)}</span>
    </span>
  );
}

/** Status chip for one EmailLog row. */
function LogStatusChip({ status }: { status: string }) {
  const { t } = useT();
  const key =
    status === "sent" ? "mailLogsSent" : status === "failed" ? "mailLogsFailed" : "mailLogsSkipped";
  return (
    <Badge
      className={cn(
        "rounded-full px-2.5 py-0.5 text-[10px] font-extrabold",
        status === "sent"
          ? "bg-emerald-500/15 text-emerald-600 hover:bg-emerald-500/15 dark:text-emerald-300"
          : status === "failed"
            ? "bg-rose-500/15 text-rose-600 hover:bg-rose-500/15 dark:text-rose-300"
            : "bg-slate-500/15 text-slate-500 hover:bg-slate-500/15 dark:text-slate-400"
      )}
    >
      {t(key as never)}
    </Badge>
  );
}

/* ------------------------------------------------------------------ */
/* the section                                                         */
/* ------------------------------------------------------------------ */

export function AdminMailSection({ isSuper }: { isSuper: boolean }) {
  const { t, lang } = useT();

  /* panel (settings + health) */
  const [panel, setPanel] = useState<MailPanelDTO | null>(null);
  const [loadFailed, setLoadFailed] = useState(false);
  const [probing, setProbing] = useState(false);

  /* the super-only editable form */
  const [enabled, setEnabled] = useState(false);
  const [host, setHost] = useState("");
  const [port, setPort] = useState(587);
  const [secure, setSecure] = useState<"none" | "starttls" | "tls">("starttls");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [fromName, setFromName] = useState("Ashrilogic");
  const [fromEmail, setFromEmail] = useState("");
  const [replyTo, setReplyTo] = useState("");
  const [timeoutSec, setTimeoutSec] = useState(15);
  const [sendWelcome, setSendWelcome] = useState(false);
  const [saving, setSaving] = useState(false);
  const [rotating, setRotating] = useState(false);

  /* test email */
  const [testTo, setTestTo] = useState("");
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<MailTestResultDTO | null>(null);

  /* delivery logs */
  const [logs, setLogs] = useState<EmailLogPageDTO | null>(null);
  const [logsPage, setLogsPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [search, setSearch] = useState("");
  const searchDebounce = useRef<ReturnType<typeof setTimeout> | null>(null);

  const applyPanel = useCallback(
    (data: MailPanelDTO) => {
      setPanel(data);
      if (isSuper) {
        const s = data.settings;
        setEnabled(s.enabled);
        setHost(s.host);
        setPort(s.port);
        setSecure(s.secure);
        setUsername(s.username);
        setFromName(s.fromName || "Ashrilogic");
        setFromEmail(s.fromEmail);
        setReplyTo(s.replyTo);
        setTimeoutSec(Math.round(s.timeoutMs / 1000));
        setSendWelcome(s.sendWelcome);
      }
    },
    [isSuper]
  );

  const load = useCallback(async () => {
    try {
      applyPanel(await fetchMailPanel());
      setLoadFailed(false);
    } catch {
      setLoadFailed(true);
    }
  }, [applyPanel]);

  useEffect(() => {
    void load();
  }, [load]);

  const loadLogs = useCallback(
    async (page: number) => {
      try {
        const data = await fetchEmailLogs({
          page,
          pageSize: 15,
          ...(statusFilter !== "all" ? { status: statusFilter } : {}),
          ...(typeFilter !== "all" ? { type: typeFilter } : {}),
          ...(search.trim() ? { q: search.trim() } : {}),
        });
        setLogs(data);
        setLogsPage(data.page);
      } catch {
        setLogs(null);
      }
    },
    [statusFilter, typeFilter, search]
  );

  useEffect(() => {
    void loadLogs(logsPage);
  }, [loadLogs, logsPage]);

  const onSearchChange = (value: string) => {
    setSearch(value);
    if (searchDebounce.current) clearTimeout(searchDebounce.current);
    searchDebounce.current = setTimeout(() => setLogsPage(1), 350);
  };

  /* health re-probe */
  const refreshHealth = async () => {
    if (probing) return;
    setProbing(true);
    try {
      applyPanel(await fetchMailPanel());
      toast.success(t("mailRefreshBtn"));
    } catch {
      setLoadFailed(true);
    } finally {
      setProbing(false);
    }
  };

  /* super-only: save the panel */
  const save = async () => {
    if (saving || !isSuper) return;
    setSaving(true);
    try {
      const dto: MailSettingsDTO = await updateMailSettings({
        enabled,
        host: host.trim(),
        port: clampInt(port, 1, 65_535),
        secure,
        username: username.trim(),
        fromName: fromName.trim() || "Ashrilogic",
        fromEmail: fromEmail.trim(),
        replyTo: replyTo.trim(),
        timeoutMs: clampInt(timeoutSec, 3, 60) * 1000,
        sendWelcome,
        /* only seal a NEW password when one was typed */
        ...(password.length >= 4 ? { password } : {}),
      });
      setPassword("");
      /* refresh panel (settings + health) after the write */
      applyPanel(await fetchMailPanel());
      void dto;
      toast.success(t("mailSavedToast"));
    } catch (error) {
      toast.error(error instanceof Error ? error.message : t("setSaveErr"));
    } finally {
      setSaving(false);
    }
  };

  /* super-only: drop the stored password */
  const rotate = async () => {
    if (rotating || !isSuper) return;
    setRotating(true);
    try {
      await updateMailSettings({ rotatePassword: true });
      setPassword("");
      applyPanel(await fetchMailPanel());
      toast.success(t("mailSavedToast"));
    } catch (error) {
      toast.error(error instanceof Error ? error.message : t("setSaveErr"));
    } finally {
      setRotating(false);
    }
  };

  /* the test round-trip */
  const runTest = async () => {
    if (testing) return;
    const to = testTo.trim();
    if (!to.includes("@")) {
      toast.error(t("mailTestFail"));
      return;
    }
    setTesting(true);
    setTestResult(null);
    try {
      const result = await sendTestMail(to);
      setTestResult(result);
      if (result.ok) {
        toast.success(t("mailTestOk"));
      } else {
        toast.error(t("mailTestFail"), { description: result.detail });
      }
      /* the trail just grew — refresh health + logs */
      void load();
      void loadLogs(1);
    } catch (error) {
      toast.error(t("mailTestFail"), {
        description: error instanceof Error ? error.message : undefined,
      });
      /* a transport-level error may still have produced a trail row */
      void loadLogs(1);
    } finally {
      setTesting(false);
    }
  };

  /* ---------------- render ---------------- */

  if (loadFailed) {
    return (
      <DashCard title={t("mailAdminTitle")} icon="mail">
        <div className="py-8 text-center">
          <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-rose-100 text-rose-500 dark:bg-rose-500/10 dark:text-rose-300">
            <CatIcon name="circle-alert" className="h-5 w-5" />
          </div>
          <p className="mt-3 text-[13px] font-extrabold text-slate-700 dark:text-slate-200">{t("errorText")}</p>
          <Button
            type="button"
            variant="outline"
            onClick={() => {
              setLoadFailed(false);
              void load();
            }}
            className="mt-4 h-10 gap-2 rounded-xl px-4 text-[12px] font-bold"
          >
            <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
            {t("retryText")}
          </Button>
        </div>
      </DashCard>
    );
  }

  if (!panel) {
    return (
      <DashCard title={t("mailAdminTitle")} icon="mail">
        <div className="space-y-3">
          {[0, 1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-14 rounded-2xl" />
          ))}
        </div>
      </DashCard>
    );
  }

  const s = panel.settings;
  const health = panel.health;
  const modeLabel =
    s.activeMode === "smtp-db" ? t("mailModeDb") : s.activeMode === "smtp-env" ? t("mailModeEnv") : t("mailModeSpool");
  const incomplete = isSuper && s.enabled && (!host.trim() || !fromEmail.trim());

  return (
    <div className="space-y-6">
      {/* intro + active-path chip */}
      <p className="max-w-2xl text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
        {t("mailAdminDesc")}
      </p>

      {/* ------------------------------------------------ SMTP + sender (super) */}
      {isSuper ? (
        <DashCard
          title={t("mailCfgTitle")}
          icon="server"
          action={
            <div className="flex flex-wrap items-center gap-2">
              <Badge className="rounded-full bg-cyan-500/10 px-2.5 py-0.5 text-[10px] font-extrabold text-cyan-600 hover:bg-cyan-500/10 dark:text-cyan-300">
                {t("mailModeLabel")}: {modeLabel}
              </Badge>
              <Badge
                className={cn(
                  "gap-1 rounded-full px-2.5 py-0.5 text-[10px] font-extrabold",
                  s.enabled
                    ? "bg-emerald-500/15 text-emerald-600 hover:bg-emerald-500/15 dark:text-emerald-300"
                    : "bg-rose-500/15 text-rose-600 hover:bg-rose-500/15 dark:text-rose-300"
                )}
              >
                <span className={cn("h-1.5 w-1.5 rounded-full", s.enabled ? "bg-emerald-500" : "bg-rose-500")} aria-hidden="true" />
                {s.enabled ? t("aiStatusOn") : t("aiStatusOff")}
              </Badge>
            </div>
          }
        >
          {incomplete ? (
            <p className="mb-3 flex items-center gap-2 rounded-xl border border-amber-300/70 bg-amber-500/[0.07] px-3.5 py-2.5 text-[11px] font-bold leading-relaxed text-amber-600 dark:border-amber-500/30 dark:text-amber-300">
              <CatIcon name="triangle-alert" className="h-3.5 w-3.5 shrink-0" />
              {t("mailIncomplete")}
            </p>
          ) : null}
          <div className="divide-y divide-slate-100 dark:divide-white/[0.06]">
            <MailRow icon="toggle-right" c1="#06b6d4" c2="#0891b2" label={t("mailEnabledLabel")} desc={t("mailEnabledD")} htmlFor="set-mail-enabled">
              <Switch id="set-mail-enabled" tone="brand" checked={enabled} onCheckedChange={setEnabled} aria-label={t("mailEnabledLabel")} />
            </MailRow>
            <MailRow icon="server" c1="#6d5dfb" c2="#d946ef" label={t("mailProviderLabel")}>
              <Select value="smtp" onValueChange={() => undefined} disabled>
                <SelectTrigger id="set-mail-provider" className={`${FIELD_INPUT} w-56 text-start`} aria-label={t("mailProviderLabel")}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectItem value="smtp">{t("mailProviderSmtp")}</SelectItem>
                    <SelectItem value="resend" disabled>
                      Resend · {t("mailProviderSoon")}
                    </SelectItem>
                    <SelectItem value="ses" disabled>
                      Amazon SES · {t("mailProviderSoon")}
                    </SelectItem>
                  </SelectGroup>
                </SelectContent>
              </Select>
            </MailRow>
            <MailRow icon="globe" c1="#0ea5e9" c2="#6366f1" label={t("mailHostLabel")} htmlFor="set-mail-host">
              <Input
                id="set-mail-host"
                dir="ltr"
                value={host}
                maxLength={253}
                placeholder={t("mailHostPh")}
                onChange={(e) => setHost(e.target.value)}
                className={`${FIELD_INPUT} w-full text-start sm:w-56`}
              />
            </MailRow>
            <MailRow icon="plug-zap" c1="#f59e0b" c2="#d97706" label={t("mailPortLabel")} htmlFor="set-mail-port">
              <Input
                id="set-mail-port"
                dir="ltr"
                type="number"
                inputMode="numeric"
                min={1}
                max={65535}
                value={port}
                onChange={(e) => setPort(Number.parseInt(e.target.value, 10) || 0)}
                className={`${FIELD_INPUT} w-full text-start sm:w-28`}
              />
            </MailRow>
            <MailRow icon="shield-check" c1="#10b981" c2="#0e7490" label={t("mailSecureLabel")}>
              <Select value={secure} onValueChange={(v) => setSecure(v as typeof secure)}>
                <SelectTrigger id="set-mail-secure" className={`${FIELD_INPUT} w-56 text-start`} aria-label={t("mailSecureLabel")}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectItem value="tls">{t("mailSecureTls")}</SelectItem>
                    <SelectItem value="starttls">{t("mailSecureStarttls")}</SelectItem>
                    <SelectItem value="none">{t("mailSecureNone")}</SelectItem>
                  </SelectGroup>
                </SelectContent>
              </Select>
            </MailRow>
            <MailRow icon="user" c1="#8b5cf6" c2="#6d28d9" label={t("mailUsernameLabel")} htmlFor="set-mail-user">
              <Input
                id="set-mail-user"
                dir="ltr"
                value={username}
                maxLength={200}
                placeholder={t("mailUsernamePh")}
                onChange={(e) => setUsername(e.target.value)}
                className={`${FIELD_INPUT} w-full text-start sm:w-56`}
              />
            </MailRow>
            <MailRow
              icon="key-round"
              c1="#f43f5e"
              c2="#e11d48"
              label={t("mailPasswordLabel")}
              desc={s.hasPassword ? t("mailPasswordHint") : t("mailPasswordHint")}
              htmlFor="set-mail-pass"
            >
              <div className="flex w-full flex-wrap items-center gap-2 sm:w-auto">
                <Input
                  id="set-mail-pass"
                  dir="ltr"
                  type="password"
                  autoComplete="new-password"
                  value={password}
                  maxLength={400}
                  placeholder={s.hasPassword ? "•••••••• (saved)" : t("mailPasswordPh")}
                  onChange={(e) => setPassword(e.target.value)}
                  className={`${FIELD_INPUT} w-full text-start sm:w-48`}
                />
                {s.hasPassword ? (
                  <Button
                    type="button"
                    variant="outline"
                    disabled={rotating}
                    onClick={rotate}
                    className="h-11 gap-2 rounded-xl px-3 text-[11px] font-bold"
                  >
                    <CatIcon name="trash-2" className="h-3.5 w-3.5" />
                    {t("mailRotateBtn")}
                  </Button>
                ) : null}
              </div>
            </MailRow>
          </div>

          {/* sender identity */}
          <p className="mt-5 mb-1 text-[12px] font-extrabold text-slate-500 dark:text-slate-400">
            {t("mailIdentityTitle")}
          </p>
          <div className="divide-y divide-slate-100 dark:divide-white/[0.06]">
            <MailRow icon="signature" c1="#d946ef" c2="#8b5cf6" label={t("mailFromNameLabel")} htmlFor="set-mail-from-name">
              <Input
                id="set-mail-from-name"
                value={fromName}
                maxLength={80}
                onChange={(e) => setFromName(e.target.value)}
                className={`${FIELD_INPUT} w-full text-start sm:w-48`}
              />
            </MailRow>
            <MailRow icon="at-sign" c1="#6d5dfb" c2="#06b6d4" label={t("mailFromEmailLabel")} htmlFor="set-mail-from-email">
              <Input
                id="set-mail-from-email"
                dir="ltr"
                type="email"
                inputMode="email"
                value={fromEmail}
                maxLength={254}
                placeholder="no-reply@example.com"
                onChange={(e) => setFromEmail(e.target.value)}
                className={`${FIELD_INPUT} w-full text-start sm:w-56`}
              />
            </MailRow>
            <MailRow icon="reply" c1="#0ea5e9" c2="#10b981" label={t("mailReplyToLabel")} htmlFor="set-mail-replyto">
              <Input
                id="set-mail-replyto"
                dir="ltr"
                type="email"
                inputMode="email"
                value={replyTo}
                maxLength={254}
                placeholder={t("mailReplyToPh")}
                onChange={(e) => setReplyTo(e.target.value)}
                className={`${FIELD_INPUT} w-full text-start sm:w-56`}
              />
            </MailRow>
            <MailRow icon="timer" c1="#f59e0b" c2="#e11d48" label={t("mailTimeoutLabel")} htmlFor="set-mail-timeout">
              <Input
                id="set-mail-timeout"
                dir="ltr"
                type="number"
                inputMode="numeric"
                min={3}
                max={60}
                value={timeoutSec}
                onChange={(e) => setTimeoutSec(Number.parseInt(e.target.value, 10) || 15)}
                className={`${FIELD_INPUT} w-full text-start sm:w-24`}
              />
            </MailRow>
            <MailRow icon="party-popper" c1="#f59e0b" c2="#d946ef" label={t("mailSendWelcomeLabel")} desc={t("mailSendWelcomeD")}>
              <Switch tone="brand" checked={sendWelcome} onCheckedChange={setSendWelcome} aria-label={t("mailSendWelcomeLabel")} />
            </MailRow>
          </div>

          <div className="mt-5 flex justify-end">
            <Button
              type="button"
              disabled={saving}
              onClick={save}
              className="h-11 gap-2 rounded-xl bg-linear-to-l from-brand-600 via-fuchsia-500 to-cyan-400 px-6 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
            >
              <CatIcon name={saving ? "loader-circle" : "save"} className={cn("h-4 w-4", saving && "animate-spin")} />
              {t("mailSaveBtn")}
            </Button>
          </div>
        </DashCard>
      ) : (
        /* non-super: the compact operational summary (no credential surface) */
        <DashCard
          title={t("mailAdminTitle")}
          icon="mail"
          action={
            <Badge className="rounded-full bg-cyan-500/10 px-2.5 py-0.5 text-[10px] font-extrabold text-cyan-600 hover:bg-cyan-500/10 dark:text-cyan-300">
              {t("mailModeLabel")}: {modeLabel}
            </Badge>
          }
        >
          <div className="divide-y divide-slate-100 dark:divide-white/[0.06]">
            <MailRow icon="server" c1="#6d5dfb" c2="#d946ef" label={t("mailHostLabel")}>
              <p dir="ltr" className="text-[12.5px] font-extrabold text-slate-700 dark:text-slate-200">
                {s.host || t("mailNever")}
              </p>
            </MailRow>
            <MailRow icon="at-sign" c1="#6d5dfb" c2="#06b6d4" label={t("mailHealthSender")}>
              <p dir="ltr" className="text-[12.5px] font-extrabold text-slate-700 dark:text-slate-200">
                {health.senderIdentity.from}
              </p>
            </MailRow>
          </div>
        </DashCard>
      )}

      {/* ------------------------------------------------ health */}
      <DashCard
        title={t("mailHealthTitle")}
        icon="heart-pulse"
        action={
          <Button
            type="button"
            variant="outline"
            disabled={probing}
            onClick={refreshHealth}
            className="h-9 gap-2 rounded-xl px-3.5 text-[11px] font-bold"
          >
            <CatIcon name="refresh-cw" className={cn("h-3.5 w-3.5", probing && "animate-spin")} />
            {t("mailRefreshBtn")}
          </Button>
        }
      >
        <div className="grid gap-3 sm:grid-cols-2">
          {/* connection + sender */}
          <div className="rounded-2xl border border-slate-100 bg-slate-50/60 p-4 dark:border-white/[0.06] dark:bg-white/[0.02]">
            <div className="flex items-center justify-between gap-3">
              <p className="flex items-center gap-2 text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
                <CatIcon name="plug-zap" className="h-3.5 w-3.5 text-cyan-500" />
                {t("mailHealthConn")}
              </p>
              <Badge
                className={cn(
                  "rounded-full px-2.5 py-0.5 text-[10px] font-extrabold",
                  health.connection.ok
                    ? "bg-emerald-500/15 text-emerald-600 hover:bg-emerald-500/15 dark:text-emerald-300"
                    : "bg-rose-500/15 text-rose-600 hover:bg-rose-500/15 dark:text-rose-300"
                )}
              >
                {health.connection.ok ? t("mailDnsPass") : t("mailDnsFail")}
              </Badge>
            </div>
            <p dir="ltr" className="mt-2 line-clamp-2 break-all text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {health.connection.detail}
            </p>
            <div className="mt-3 space-y-1.5 border-t border-slate-100 pt-3 dark:border-white/[0.06]">
              <p dir="auto" className="flex items-center gap-2 text-[11px] font-bold text-slate-500 dark:text-slate-400">
                <CatIcon name="at-sign" className="h-3 w-3 text-brand-500" />
                {t("mailHealthSender")}:
                <span dir="ltr" className="font-extrabold text-slate-700 dark:text-slate-200">{health.senderIdentity.from}</span>
              </p>
              <p dir="auto" className="flex items-center gap-2 text-[11px] font-bold text-slate-500 dark:text-slate-400">
                <CatIcon name="globe" className="h-3 w-3 text-cyan-500" />
                {t("mailHealthDnsDomain")}:
                <span dir="ltr" className="font-extrabold text-slate-700 dark:text-slate-200">{health.dns.domain || "—"}</span>
              </p>
            </div>
          </div>

          {/* DNS authentication */}
          <div className="rounded-2xl border border-slate-100 bg-slate-50/60 p-4 dark:border-white/[0.06] dark:bg-white/[0.02]">
            <p className="mb-2.5 flex items-center gap-2 text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
              <CatIcon name="shield-check" className="h-3.5 w-3.5 text-emerald-500" />
              SPF · DKIM · DMARC
            </p>
            <div className="flex flex-wrap gap-2">
              <DnsBadge label={t("mailDnsSpf")} check={health.dns.spf} />
              <DnsBadge label={t("mailDnsDkim")} check={health.dns.dkim} />
              <DnsBadge label={t("mailDnsDmarc")} check={health.dns.dmarc} />
            </div>
            <p className="mt-2.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {health.dns.dkim.detail}
            </p>
          </div>

          {/* trail stats */}
          <div className="grid grid-cols-2 gap-3 sm:col-span-2 sm:grid-cols-4">
            <div className="rounded-2xl border border-slate-100 bg-slate-50/60 p-3.5 text-center dark:border-white/[0.06] dark:bg-white/[0.02]">
              <p className="text-[18px] font-black tabular-nums text-emerald-600 dark:text-emerald-300">{health.sent24h}</p>
              <p className="mt-0.5 text-[10px] font-bold text-slate-400 dark:text-slate-500">{t("mailSent24h")}</p>
            </div>
            <div className="rounded-2xl border border-slate-100 bg-slate-50/60 p-3.5 text-center dark:border-white/[0.06] dark:bg-white/[0.02]">
              <p className="text-[18px] font-black tabular-nums text-rose-600 dark:text-rose-300">{health.failed24h}</p>
              <p className="mt-0.5 text-[10px] font-bold text-slate-400 dark:text-slate-500">{t("mailFailed24h")}</p>
            </div>
            <div className="col-span-2 rounded-2xl border border-slate-100 bg-slate-50/60 p-3.5 text-start dark:border-white/[0.06] dark:bg-white/[0.02]">
              <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500">{t("mailLastSent")}</p>
              <p className="mt-0.5 truncate text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200">
                {health.lastSent ? `${relativeTime(health.lastSent.at, lang)} · ${health.lastSent.subject}` : t("mailNever")}
              </p>
              <p className="mt-1.5 text-[10px] font-bold text-slate-400 dark:text-slate-500">{t("mailLastFailed")}</p>
              <p className="mt-0.5 truncate text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200">
                {health.lastFailed ? `${relativeTime(health.lastFailed.at, lang)} · ${health.lastFailed.subject}` : t("mailNever")}
              </p>
            </div>
          </div>
        </div>
      </DashCard>

      {/* ------------------------------------------------ test email */}
      <DashCard title={t("mailTestTitle")} icon="send">
        <p className="mb-3 max-w-lg text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
          {t("mailTestDesc")}
        </p>
        <div className="flex flex-col gap-2.5 sm:flex-row sm:items-center">
          <div className="flex-1">
            <Label htmlFor="mail-test-to" className="sr-only">
              {t("mailTestToLabel")}
            </Label>
            <Input
              id="mail-test-to"
              dir="ltr"
              type="email"
              inputMode="email"
              value={testTo}
              maxLength={254}
              placeholder={t("mailTestToPh")}
              onChange={(e) => setTestTo(e.target.value)}
              className={`${FIELD_INPUT} w-full text-start`}
            />
          </div>
          <Button
            type="button"
            disabled={testing || !testTo.trim().includes("@")}
            onClick={runTest}
            className="h-11 gap-2 rounded-xl bg-linear-to-l from-cyan-500 via-sky-500 to-brand-500 px-6 text-[12.5px] font-extrabold text-white shadow-lg shadow-cyan-500/20 transition hover:brightness-110 active:scale-95"
          >
            <CatIcon name={testing ? "loader-circle" : "send"} className={cn("h-4 w-4", testing && "animate-spin")} />
            {testing ? t("mailTestSending") : t("mailTestBtn")}
          </Button>
        </div>
        {testResult ? (
          <p
            className={cn(
              "mt-3 flex items-start gap-2 rounded-xl border px-3.5 py-2.5 text-[11.5px] font-bold leading-relaxed",
              testResult.ok
                ? "border-emerald-300/70 bg-emerald-500/[0.07] text-emerald-600 dark:border-emerald-500/30 dark:text-emerald-300"
                : "border-rose-300/70 bg-rose-500/[0.07] text-rose-600 dark:border-rose-500/30 dark:text-rose-300"
            )}
          >
            <CatIcon name={testResult.ok ? "circle-check" : "circle-alert"} className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            <span>
              {testResult.ok ? t("mailTestOk") : t("mailTestFail")}
              <span className="block text-[10.5px] font-semibold opacity-80" dir="ltr">
                {testResult.recipient} · {testResult.transport}
                {testResult.detail ? ` · ${testResult.detail}` : ""}
              </span>
            </span>
          </p>
        ) : null}
      </DashCard>

      {/* ------------------------------------------------ delivery logs */}
      <DashCard title={t("mailLogsTitle")} icon="list-checks">
        <p className="mb-3 max-w-lg text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
          {t("mailLogsDesc")}
        </p>

        {/* filters */}
        <div className="mb-3 flex flex-col gap-2 sm:flex-row sm:items-center">
          <Input
            dir="auto"
            value={search}
            maxLength={120}
            placeholder={t("mailLogsSearchPh")}
            onChange={(e) => onSearchChange(e.target.value)}
            className={`${FIELD_INPUT} flex-1 text-start`}
          />
          <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setLogsPage(1); }}>
            <SelectTrigger className={`${FIELD_INPUT} w-full text-start sm:w-36`} aria-label={t("mailLogsStatus")}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectGroup>
                <SelectItem value="all">{t("mailLogsFilterAll")}</SelectItem>
                <SelectItem value="sent">{t("mailLogsSent")}</SelectItem>
                <SelectItem value="failed">{t("mailLogsFailed")}</SelectItem>
              </SelectGroup>
            </SelectContent>
          </Select>
          <Select value={typeFilter} onValueChange={(v) => { setTypeFilter(v); setLogsPage(1); }}>
            <SelectTrigger className={`${FIELD_INPUT} w-full text-start sm:w-44`} aria-label={t("mailLogsStatus")}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectGroup>
                <SelectItem value="all">{t("mailLogsFilterAll")}</SelectItem>
                {LOG_TYPES.map((type) => (
                  <SelectItem key={type} value={type}>
                    {type}
                  </SelectItem>
                ))}
              </SelectGroup>
            </SelectContent>
          </Select>
        </div>

        {/* the trail table */}
        <div className="overflow-hidden rounded-2xl border border-slate-100 dark:border-white/[0.06]">
          <div className="max-h-96 overflow-y-auto">
            <table className="w-full min-w-[640px] text-start text-[11.5px]">
              <thead className="sticky top-0 z-10 bg-slate-50/95 backdrop-blur dark:bg-slate-900/95">
                <tr className="text-[10px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                  <th className="px-3 py-2.5 text-start">{t("mailLogsRecipient")}</th>
                  <th className="px-3 py-2.5 text-start">{t("mailLogsSubject")}</th>
                  <th className="px-3 py-2.5 text-start">{t("mailLogsStatus")}</th>
                  <th className="px-3 py-2.5 text-start">{t("mailLogsAttempts")}</th>
                  <th className="px-3 py-2.5 text-start">{t("mailLogsTime")}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-white/[0.05]">
                {logs && logs.rows.length > 0 ? (
                  logs.rows.map((row: EmailLogDTO) => (
                    <tr key={row.id} className="transition hover:bg-slate-50/80 dark:hover:bg-white/[0.03]">
                      <td dir="ltr" className="max-w-[180px] truncate px-3 py-2.5 font-bold text-slate-600 dark:text-slate-300">
                        {row.recipient}
                      </td>
                      <td dir="auto" className="max-w-[240px] truncate px-3 py-2.5 font-semibold text-slate-700 dark:text-slate-200" title={row.subject}>
                        {row.subject}
                      </td>
                      <td className="px-3 py-2.5">
                        <LogStatusChip status={row.status} />
                      </td>
                      <td className="px-3 py-2.5 font-bold tabular-nums text-slate-500 dark:text-slate-400">
                        {row.attempts}
                        {row.error ? (
                          <span className="ms-1.5 align-middle" title={`${row.errorClass ?? "unknown"}: ${row.error ?? ""}`}>
                            <CatIcon name="triangle-alert" className="inline h-3 w-3 text-rose-400" />
                          </span>
                        ) : null}
                      </td>
                      <td dir="auto" className="whitespace-nowrap px-3 py-2.5 font-semibold text-slate-400 dark:text-slate-500">
                        {relativeTime(row.createdAt, lang)}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="px-3 py-8 text-center text-[12px] font-bold text-slate-400 dark:text-slate-500">
                      {logs ? t("mailLogsEmpty") : <Skeleton className="mx-auto h-5 w-40 rounded-full" />}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* pagination */}
        {logs && logs.total > 0 ? (
          <div className="mt-3 flex items-center justify-between gap-3">
            <p className="text-[11px] font-bold text-slate-400 dark:text-slate-500">
              {logs.total.toLocaleString(lang === "ar" ? "ar-EG" : lang === "hi" ? "hi-IN" : "en-US")} · {t("mailLogsPage")} {logs.page}/{Math.max(1, Math.ceil(logs.total / logs.pageSize))}
            </p>
            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="outline"
                disabled={logsPage <= 1}
                onClick={() => setLogsPage((p) => Math.max(1, p - 1))}
                className="h-9 gap-1.5 rounded-xl px-3 text-[11px] font-bold"
              >
                <CatIcon name={lang === "ar" ? "chevron-right" : "chevron-left"} className="h-3.5 w-3.5" />
                {t("mailLogsPrev")}
              </Button>
              <Button
                type="button"
                variant="outline"
                disabled={logsPage >= Math.ceil(logs.total / logs.pageSize)}
                onClick={() => setLogsPage((p) => p + 1)}
                className="h-9 gap-1.5 rounded-xl px-3 text-[11px] font-bold"
              >
                {t("mailLogsNext")}
                <CatIcon name={lang === "ar" ? "chevron-left" : "chevron-right"} className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        ) : null}
      </DashCard>
    </div>
  );
}
