"use client";

/**
 * Ashrilogic — admin LEGAL DOCUMENTS console (ROUND 117).
 *
 * The dynamic editor behind the platform's privacy policy and terms of
 * use: what is edited here is EXACTLY what /privacy and /terms render on
 * their next request (those pages are force-dynamic — a publish is live
 * immediately, no rebuild, no cache to bust).
 *
 *  - two document tabs (سياسة الخصوصية / شروط الاستخدام) × three locale
 *    pills (ar / en / hi — hi falls back to the EN copy until authored);
 *  - the editor edits the STRUCTURE directly: title, intro, and the
 *    sections list with per-section heading/body, move-up/down, remove
 *    and add — precise by construction (the editor sees exactly what the
 *    page renders, section by section, in order);
 *  - a live PREVIEW panel (the exact reading layout of the public page);
 *  - PUBLISH is versioned + attributed + sealed-audited
 *    (admin.legalDocUpdate); «استعادة النص الافتراضي» removes the
 *    console draft and returns the locale to the code-carried default
 *    (admin.legalDocReset) — confirmed with an AlertDialog;
 *  - status chips per locale: الافتراضية (code default) / منشورة vN
 *    + last-updated relative time;
 *  - moderators/viewers get the read-only note (the API enforces
 *    super/admin on mutations anyway).
 */

import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { useT } from "@/lib/i18n";
import { useAdminAuth } from "@/lib/admin-auth";
import { CatIcon } from "@/components/icon";
import { cn, grad } from "@/lib/utils";
import { fetchLegalDocs, resetLegalDoc, saveLegalDoc, type LegalDocDTO } from "@/lib/api-client";
import { defaultLegalContent, type LegalDocKey, type LegalDocLocale } from "@/lib/platform-legal-defaults";
import { DashCard, ViewHeading, relativeTime } from "@/components/dashboard/dash-shared";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

type Draft = {
  title: string;
  intro: string;
  sections: { heading: string; body: string }[];
};

const GRADS: Record<LegalDocKey, { c1: string; c2: string; icon: string }> = {
  privacy: { c1: "#6d5dfb", c2: "#06b6d4", icon: "shield-check" },
  terms: { c1: "#059669", c2: "#10b981", icon: "scale" },
};

function toDraft(dto: LegalDocDTO): Draft {
  return { title: dto.title, intro: dto.intro, sections: dto.sections.map((s) => ({ ...s })) };
}

export function AdminLegal() {
  const { t, lang } = useT();
  const { user } = useAdminAuth();
  const queryClient = useQueryClient();
  const canManage = user?.role === "super" || user?.role === "admin";

  const [docKey, setDocKey] = useState<LegalDocKey>("privacy");
  const [locale, setLocale] = useState<LegalDocLocale>("ar");
  const [draft, setDraft] = useState<Draft | null>(null);
  const [dirty, setDirty] = useState(false);
  const [preview, setPreview] = useState(false);
  const [resetOpen, setResetOpen] = useState(false);

  const bundle = useQuery({
    queryKey: ["admin-legal"],
    queryFn: fetchLegalDocs,
    staleTime: 30_000,
  });

  const current = useMemo(
    () => bundle.data?.find((d) => d.key === docKey && d.locale === locale) ?? null,
    [bundle.data, docKey, locale]
  );

  /* load the draft whenever the selection changes (or data first lands) */
  const loadedKey = `${docKey}:${locale}`;
  const [loadedFrom, setLoadedFrom] = useState<string | null>(null);
  if (bundle.data && loadedFrom !== loadedKey) {
    setLoadedFrom(loadedKey);
    setDirty(false);
    setDraft(
      current
        ? toDraft(current)
        : { title: "", intro: "", sections: [] }
    );
  }

  /* the doc list is guaranteed complete server-side; a missing entry
     means hi (not authored) — seed the editor from the EN default */
  const effectiveDraft: Draft = useMemo(() => {
    if (draft && (draft.title || draft.sections.length > 0)) return draft;
    if (current) return toDraft(current);
    const def = defaultLegalContent(docKey, locale);
    return { title: def.title, intro: def.intro, sections: def.sections.map((s) => ({ ...s })) };
  }, [draft, current, docKey, locale]);

  const save = useMutation({
    mutationFn: () =>
      saveLegalDoc({
        key: docKey,
        locale,
        title: effectiveDraft.title,
        intro: effectiveDraft.intro,
        sections: effectiveDraft.sections,
      }),
    onSuccess: ({ doc, version }) => {
      toast.success(t("legalSavedToast", { v: String(version) }));
      setDirty(false);
      queryClient.setQueryData(["admin-legal"], (old: LegalDocDTO[] | undefined) =>
        old?.map((d) => (d.key === doc.key && d.locale === doc.locale ? doc : d)) ?? [doc]
      );
      setDraft(toDraft(doc));
      setLoadedFrom(`${doc.key}:${doc.locale}`);
    },
    onError: (e: Error) => toast.error(e.message || t("errorText")),
  });

  const reset = useMutation({
    mutationFn: () => resetLegalDoc(docKey, locale),
    onSuccess: ({ doc }) => {
      toast.success(t("legalResetToast"));
      setDirty(false);
      queryClient.setQueryData(["admin-legal"], (old: LegalDocDTO[] | undefined) =>
        old?.map((d) => (d.key === doc.key && d.locale === doc.locale ? doc : d)) ?? [doc]
      );
      setDraft(toDraft(doc));
    },
    onError: (e: Error) => toast.error(e.message || t("errorText")),
  });

  const theme = GRADS[docKey];
  const customizedLocales = bundle.data?.filter((d) => d.customized).length ?? 0;

  const update = (patch: Partial<Draft>) => {
    setDraft({ ...effectiveDraft, ...patch });
    setDirty(true);
  };

  const updateSection = (i: number, patch: Partial<{ heading: string; body: string }>) => {
    const sections = effectiveDraft.sections.map((s, j) => (j === i ? { ...s, ...patch } : s));
    update({ sections });
  };

  const moveSection = (i: number, dir: -1 | 1) => {
    const j = i + dir;
    if (j < 0 || j >= effectiveDraft.sections.length) return;
    const sections = [...effectiveDraft.sections];
    [sections[i], sections[j]] = [sections[j]!, sections[i]!];
    update({ sections });
  };

  const removeSection = (i: number) => {
    if (effectiveDraft.sections.length <= 1) {
      toast.info(t("legalMinSections"));
      return;
    }
    update({ sections: effectiveDraft.sections.filter((_, j) => j !== i) });
  };

  const addSection = () => {
    update({
      sections: [...effectiveDraft.sections, { heading: "", body: "" }],
    });
  };

  return (
    <div className="mx-auto w-full max-w-6xl space-y-5">
      <ViewHeading title={t("legalConsoleTitle")} desc={t("legalConsoleDesc")} />

      {/* the doc + locale selector + status chips */}
      <DashCard className="p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            {(["privacy", "terms"] as const).map((k) => {
              const active = docKey === k;
              const g = GRADS[k];
              return (
                <button
                  key={k}
                  type="button"
                  onClick={() => {
                    setDocKey(k);
                    setPreview(false);
                  }}
                  className={cn(
                    "flex h-11 items-center gap-2 rounded-xl border px-4 text-[12.5px] font-extrabold transition",
                    active
                      ? "border-transparent text-white shadow-lg"
                      : "border-slate-200 bg-white/70 text-slate-500 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400 dark:hover:text-brand-300"
                  )}
                  style={active ? { backgroundImage: grad(g.c1, g.c2) } : undefined}
                >
                  <CatIcon name={g.icon} className="h-4 w-4" />
                  {t(k === "privacy" ? "legalTabPrivacy" : "legalTabTerms")}
                </button>
              );
            })}
          </div>
          <div className="flex items-center gap-1.5">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white/70 px-3 py-1 text-[11px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400">
              <CatIcon name="file-check-2" className="h-3 w-3" />
              {t("legalCustomizedCount", { n: String(customizedLocales) })}
            </span>
            <Button
              variant="outline"
              onClick={() => setPreview((v) => !v)}
              className="h-9 gap-1.5 rounded-xl px-3.5 text-[12px] font-bold"
            >
              <CatIcon name={preview ? "pencil" : "eye"} className="h-3.5 w-3.5" />
              {t(preview ? "legalEditMode" : "legalPreviewMode")}
            </Button>
            {(["ar", "en", "hi"] as const).map((l) => {
              const active = locale === l;
              const exists = bundle.data?.some((d) => d.key === docKey && d.locale === l && d.customized);
              return (
                <button
                  key={l}
                  type="button"
                  onClick={() => {
                    setLocale(l);
                    setPreview(false);
                  }}
                  className={cn(
                    "relative h-9 rounded-xl px-4 text-[12px] font-extrabold uppercase transition",
                    active
                      ? "bg-slate-900 text-white dark:bg-white dark:text-slate-900"
                      : "bg-slate-500/10 text-slate-500 hover:bg-slate-500/15 dark:bg-white/[0.06] dark:text-slate-400"
                  )}
                >
                  {l}
                  {exists ? (
                    <span className="absolute end-1 top-1 h-1.5 w-1.5 rounded-full bg-emerald-400" aria-hidden="true" />
                  ) : null}
                </button>
              );
            })}
          </div>
        </div>

        {/* status chips */}
        <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-3 dark:border-white/[0.06]">
          {current?.customized ? (
            <>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-[11px] font-bold text-emerald-600 dark:border-emerald-500/25 dark:bg-emerald-500/10 dark:text-emerald-300">
                <CatIcon name="badge-check" className="h-3 w-3" />
                {t("legalStatusPublished", { v: String(current.version) })}
              </span>
              <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-slate-400 dark:text-slate-500">
                <CatIcon name="clock" className="h-3 w-3" />
                {t("legalLastEdit", { when: relativeTime(current.updatedAt ?? "", lang) })}
              </span>
              <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-slate-400 dark:text-slate-500">
                <CatIcon name="user" className="h-3 w-3" />
                {current.updatedAt ? current.updatedById || "—" : "—"}
              </span>
            </>
          ) : (
            <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-[11px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400">
              <CatIcon name="file-lock" className="h-3 w-3" />
              {t("legalStatusDefault")}
            </span>
          )}
          <a
            href={docKey === "privacy" ? "/privacy" : "/terms"}
            target="_blank"
            rel="noreferrer"
            className="ms-auto inline-flex items-center gap-1.5 rounded-full border border-brand-200 bg-brand-50 px-3 py-1 text-[11px] font-bold text-brand-600 transition hover:bg-brand-100 dark:border-brand-500/25 dark:bg-brand-500/10 dark:text-brand-300"
          >
            <CatIcon name="external-link" className="h-3 w-3" />
            {t("legalViewPublic")}
          </a>
        </div>
      </DashCard>

      {/* the editor / preview */}
      {bundle.isLoading ? (
        <DashCard className="grid place-items-center p-12">
          <CatIcon name="refresh-cw" className="h-5 w-5 animate-spin text-brand-400" />
        </DashCard>
      ) : bundle.isError ? (
        <DashCard className="p-6">
          <p className="text-[12.5px] font-bold text-rose-500">{t("errorText")}</p>
        </DashCard>
      ) : !canManage ? (
        <DashCard className="grid place-items-center gap-2 p-10 text-center">
          <span
            className="grid h-12 w-12 place-items-center rounded-2xl text-white"
            style={{ backgroundImage: grad("#f59e0b", "#f43f5e") }}
            aria-hidden="true"
          >
            <CatIcon name="lock" className="h-5 w-5" />
          </span>
          <p className="text-[13px] font-bold text-slate-600 dark:text-slate-300">{t("legalReadOnlyNote")}</p>
        </DashCard>
      ) : preview ? (
        /* ---------------------------- the preview ---------------------------- */
        <DashCard className="p-5 sm:p-7">
          <div className="flex flex-col items-start gap-4 sm:flex-row sm:items-center">
            <span
              className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-white"
              style={{ backgroundImage: grad(theme.c1, theme.c2) }}
              aria-hidden="true"
            >
              <CatIcon name={theme.icon} className="h-5 w-5" />
            </span>
            <div className="min-w-0">
              <h2 className="font-display text-2xl font-extrabold text-slate-900 dark:text-white">
                {effectiveDraft.title || t("legalUntitled")}
              </h2>
              <p className="mt-1.5 text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
                {effectiveDraft.intro}
              </p>
            </div>
          </div>
          <div className="mt-6 space-y-5">
            {effectiveDraft.sections.map((s, i) => (
              <div key={i} className="rounded-2xl border border-slate-100 bg-slate-50/60 p-4 dark:border-white/[0.06] dark:bg-white/[0.02]">
                <h3 className="flex items-start gap-2.5 text-[15px] font-extrabold text-slate-800 dark:text-slate-100">
                  <span
                    className="grid h-6 w-6 shrink-0 place-items-center rounded-lg text-[11px] font-black text-white"
                    style={{ backgroundImage: grad(theme.c1, theme.c2) }}
                    aria-hidden="true"
                  >
                    {i + 1}
                  </span>
                  <span className="min-w-0 pt-0.5">{s.heading || t("legalUntitled")}</span>
                </h3>
                <div className="mt-2 space-y-2 sm:ps-9">
                  {s.body
                    .split(/\n\n+/)
                    .filter((p) => p.trim())
                    .map((p, j) => (
                      <p key={j} className="text-[12.5px] font-medium leading-[1.85] text-slate-600 dark:text-slate-300">
                        {p}
                      </p>
                    ))}
                </div>
              </div>
            ))}
          </div>
        </DashCard>
      ) : (
        /* ---------------------------- the editor ---------------------------- */
        <DashCard className="space-y-4 p-4 sm:p-6">
          <div>
            <label htmlFor="legal-title" className="text-[11px] font-extrabold text-slate-500 dark:text-slate-400">
              {t("legalTitleLabel")}
            </label>
            <Input
              id="legal-title"
              value={effectiveDraft.title}
              maxLength={160}
              onChange={(e) => update({ title: e.target.value })}
              className="mt-1.5 h-11 rounded-xl text-[14px] font-extrabold"
              dir="auto"
            />
          </div>
          <div>
            <label htmlFor="legal-intro" className="text-[11px] font-extrabold text-slate-500 dark:text-slate-400">
              {t("legalIntroLabel")}
            </label>
            <Textarea
              id="legal-intro"
              value={effectiveDraft.intro}
              maxLength={1_200}
              onChange={(e) => update({ intro: e.target.value })}
              className="mt-1.5 min-h-[70px] rounded-xl text-[13px] font-medium leading-relaxed"
              dir="auto"
            />
          </div>

          <div className="space-y-3">
            <p className="flex items-center gap-1.5 text-[11px] font-extrabold text-slate-500 dark:text-slate-400">
              <CatIcon name="list" className="h-3.5 w-3.5" />
              {t("legalSectionsLabel", { n: String(effectiveDraft.sections.length) })}
            </p>
            {effectiveDraft.sections.map((s, i) => (
              <motion.div
                key={i}
                initial={false}
                className="rounded-2xl border border-slate-200 bg-slate-50/50 p-3.5 dark:border-white/10 dark:bg-white/[0.02]"
              >
                <div className="flex items-center gap-2">
                  <span
                    className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-[11px] font-black text-white"
                    style={{ backgroundImage: grad(theme.c1, theme.c2) }}
                    aria-hidden="true"
                  >
                    {i + 1}
                  </span>
                  <Input
                    value={s.heading}
                    maxLength={160}
                    placeholder={t("legalSectionHeadingPh")}
                    onChange={(e) => updateSection(i, { heading: e.target.value })}
                    className="h-9 rounded-lg text-[13px] font-bold"
                    dir="auto"
                  />
                  <div className="flex shrink-0 items-center gap-1">
                    <button
                      type="button"
                      onClick={() => moveSection(i, -1)}
                      disabled={i === 0}
                      aria-label={t("legalMoveUp")}
                      className="grid h-8 w-8 place-items-center rounded-lg text-slate-400 transition hover:bg-slate-200/70 hover:text-slate-700 disabled:opacity-40 dark:hover:bg-white/10 dark:hover:text-slate-200"
                    >
                      <CatIcon name="arrow-up" className="h-3.5 w-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => moveSection(i, 1)}
                      disabled={i === effectiveDraft.sections.length - 1}
                      aria-label={t("legalMoveDown")}
                      className="grid h-8 w-8 place-items-center rounded-lg text-slate-400 transition hover:bg-slate-200/70 hover:text-slate-700 disabled:opacity-40 dark:hover:bg-white/10 dark:hover:text-slate-200"
                    >
                      <CatIcon name="arrow-down" className="h-3.5 w-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => removeSection(i)}
                      aria-label={t("legalRemoveSection")}
                      className="grid h-8 w-8 place-items-center rounded-lg text-slate-400 transition hover:bg-rose-100 hover:text-rose-600 dark:hover:bg-rose-500/15 dark:hover:text-rose-300"
                    >
                      <CatIcon name="trash-2" className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
                <Textarea
                  value={s.body}
                  maxLength={8_000}
                  placeholder={t("legalSectionBodyPh")}
                  onChange={(e) => updateSection(i, { body: e.target.value })}
                  className="mt-2 min-h-[110px] rounded-xl text-[12.5px] font-medium leading-relaxed"
                  dir="auto"
                />
                <p className="mt-1 text-end text-[10px] font-semibold tabular-nums text-slate-400 dark:text-slate-500">
                  {s.body.length}/8000
                </p>
              </motion.div>
            ))}
            <Button
              type="button"
              variant="outline"
              onClick={addSection}
              disabled={effectiveDraft.sections.length >= 40}
              className="h-10 w-full gap-1.5 rounded-xl border-dashed text-[12.5px] font-bold"
            >
              <CatIcon name="plus" className="h-4 w-4" />
              {t("legalAddSection")}
            </Button>
          </div>

          {/* the action bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-4 dark:border-white/[0.06]">
            <Button
              type="button"
              onClick={() => setResetOpen(true)}
              disabled={!current?.customized || reset.isPending}
              variant="outline"
              className="h-10 gap-1.5 rounded-xl border-rose-200 text-[12px] font-bold text-rose-600 transition hover:bg-rose-50 disabled:opacity-50 dark:border-rose-500/30 dark:text-rose-300 dark:hover:bg-rose-500/10"
            >
              <CatIcon name={reset.isPending ? "refresh-cw" : "rotate-ccw"} className={cn("h-4 w-4", reset.isPending && "animate-spin")} />
              {t("legalResetDefault")}
            </Button>
            <Button
              type="button"
              onClick={() => save.mutate()}
              disabled={save.isPending || !dirty || !effectiveDraft.title.trim() || effectiveDraft.sections.length === 0 || effectiveDraft.sections.some((s) => !s.heading.trim() || !s.body.trim())}
              className="h-10 gap-1.5 rounded-xl bg-linear-to-l from-brand-600 via-fuchsia-500 to-cyan-400 px-6 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/30 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
            >
              <CatIcon name={save.isPending ? "refresh-cw" : "cloud-upload"} className={cn("h-4 w-4", save.isPending && "animate-spin")} />
              {dirty ? t("legalPublish") : t("legalPublished")}
            </Button>
          </div>
        </DashCard>
      )}

      {/* the reset confirm */}
      <AlertDialog open={resetOpen} onOpenChange={setResetOpen}>
        <AlertDialogContent dir="auto">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-start">
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white"
                style={{ backgroundImage: grad("#f59e0b", "#f43f5e") }}
                aria-hidden="true"
              >
                <CatIcon name="rotate-ccw" className="h-4 w-4" />
              </span>
              {t("legalResetTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-start">
              {t("legalResetDesc", { doc: t(docKey === "privacy" ? "legalTabPrivacy" : "legalTabTerms"), locale })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-xl">{t("dlgCancel")}</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => reset.mutate()}
              className="rounded-xl bg-linear-to-l from-amber-500 to-rose-500 text-white"
            >
              {t("legalResetConfirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
