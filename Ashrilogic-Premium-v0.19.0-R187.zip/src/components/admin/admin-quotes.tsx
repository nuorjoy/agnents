"use client";

/**
 * Ashrilogic — Super Admin quotes inbox (طلبات المؤسسات) — ROUND 167.
 *
 * The CRM behind the landing's Enterprise card («اطلب عرض سعر مخصص»):
 * every public quote request lands here as a pipeline card. Design follows
 * the admin-subscribers / admin-email-reveal idioms — premium pipeline
 * cards, status chips, keyset «load more», masked emails by default.
 *
 *  - LISTING: keyset pages (newest first) with a status filter chip row
 *    (كل / جديد / تم التواصل / تم التسعير / فاز / خسر). Bounded — never a
 *    full-table read.
 *  - PIPELINE: one-directional transitions new → contacted → quoted →
 *    won|lost (QUOTE_TRANSITIONS is the single source; terminal rows show
 *    their closed stamp only). contactedAt/quotedAt/closedAt are stamped
 *    server-side on entry and rendered as relative timeline chips.
 *  - WORKING PAD: an inline adminNotes editor per lead (≤2000 chars,
 *    saved through the same PATCH).
 *  - EMAIL LAW: masked by default (n***@domain). The «كشف البريد» action
 *    rides the EXISTING one-time sealed-email reveal lever (super-only):
 *    a mandatory-reason dialog mints a single-use token for targetType
 *    "quote" and consumes it immediately — the plaintext appears exactly
 *    once, the audit trail records the disclosure with the MASK.
 */
import { useMemo, useState } from "react";
import { useInfiniteQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  consumeEmailRevealToken,
  fetchAdminEnterpriseQuotes,
  mintEmailRevealToken,
  patchAdminEnterpriseQuote,
} from "@/lib/api-client";
import { useAdminAuth, useAdminCanManage } from "@/lib/admin-auth";
import { useT, type I18nKey } from "@/lib/i18n";
import { QUOTE_TRANSITIONS, type EnterpriseQuoteDTO, type QuoteStatus } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ViewHeading, DashCard, relativeTime } from "@/components/dashboard/dash-shared";
import { KpiCard } from "@/components/shared/kpi-card";

/* ------------------------------------------------------------------ */
/* status vocabulary                                                   */
/* ------------------------------------------------------------------ */

const STATUS_META: Record<QuoteStatus, { labelKey: I18nKey; icon: string; c1: string; c2: string }> = {
  new: { labelKey: "quotesStatusNew", icon: "inbox", c1: "#6d5dfb", c2: "#06b6d4" },
  contacted: { labelKey: "quotesStatusContacted", icon: "send", c1: "#0891b2", c2: "#0ea5e9" },
  quoted: { labelKey: "quotesStatusQuoted", icon: "file-text", c1: "#f59e0b", c2: "#ea580c" },
  won: { labelKey: "quotesStatusWon", icon: "circle-check", c1: "#10b981", c2: "#0d9488" },
  lost: { labelKey: "quotesStatusLost", icon: "x", c1: "#f43f5e", c2: "#e11d48" },
};

const STATUS_VALUES: readonly QuoteStatus[] = ["new", "contacted", "quoted", "won", "lost"];

/** The one-directional transition targets for a row (the engine's table). */
function nextStatuses(status: QuoteStatus): QuoteStatus[] {
  return QUOTE_TRANSITIONS[status] ?? [];
}

/* ------------------------------------------------------------------ */
/* the reveal dialog (super-only — the EXISTING one-time lever)        */
/* ------------------------------------------------------------------ */

function RevealEmailDialog({
  quote,
  onOpenChange,
}: {
  quote: EnterpriseQuoteDTO | null;
  onOpenChange: (open: boolean) => void;
}) {
  const { t } = useT();
  const [reason, setReason] = useState("");
  const [revealed, setRevealed] = useState<string | null>(null);

  const reveal = useMutation({
    mutationFn: async () => {
      /* mint → consume in ONE operator action (the same super-only flow
       * the reveal console exposes; the token never leaves this dialog) */
      const minted = await mintEmailRevealToken({
        targetType: "quote",
        targetId: quote?.id ?? "",
        reason: reason.trim(),
      });
      return consumeEmailRevealToken(minted.token);
    },
    onSuccess: (data) => setRevealed(data.email),
    onError: (error: Error) =>
      toast.error(error.message ? `${t("quotesRevealErr")} — ${error.message}` : t("quotesRevealErr")),
  });

  const close = () => {
    onOpenChange(false);
    /* reset AFTER the exit animation starts — reopening begins fresh */
    window.setTimeout(() => {
      setReason("");
      setRevealed(null);
      reveal.reset();
    }, 250);
  };

  const submit = () => {
    if (reveal.isPending) return;
    if (reason.trim().length === 0) return;
    reveal.mutate();
  };

  return (
    <Dialog open={quote !== null} onOpenChange={(next) => (next ? onOpenChange(true) : close())}>
      <DialogContent dir="auto" className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2.5 font-display text-[15px] font-extrabold">
            <span
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg shadow-amber-500/25"
              style={{ backgroundImage: grad("#f59e0b", "#ea580c") }}
              aria-hidden="true"
            >
              <CatIcon name="key-round" className="h-4 w-4" />
            </span>
            {t("quotesRevealTitle")}
          </DialogTitle>
          <DialogDescription className="leading-relaxed">
            {t("quotesRevealDesc")}
          </DialogDescription>
        </DialogHeader>

        {revealed !== null ? (
          /* the recovered address — shown EXACTLY ONCE, copyable */
          <div className="space-y-3">
            <div className="flex items-center gap-2 rounded-xl border border-amber-300/60 bg-amber-50/70 p-3 dark:border-amber-400/25 dark:bg-amber-500/10">
              <CatIcon name="mail" className="h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400" />
              <code dir="ltr" className="min-w-0 flex-1 truncate font-mono text-[13px] font-bold text-slate-800 dark:text-slate-100">
                {revealed}
              </code>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => {
                  void navigator.clipboard.writeText(revealed).then(() => toast.success(t("quotesEmailCopied")));
                }}
                className="h-8 gap-1.5 rounded-lg px-2.5 text-[11px]"
              >
                <CatIcon name="clipboard-check" className="h-3.5 w-3.5" />
                {t("quotesCopyEmail")}
              </Button>
            </div>
            <p className="flex items-start gap-1.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              <CatIcon name="shield-check" className="mt-0.5 h-3 w-3 shrink-0 text-emerald-500" />
              {t("quotesRevealOnce")}
            </p>
            <Button type="button" onClick={close} className="h-10 w-full rounded-xl font-extrabold">
              {t("quotesRevealDone")}
            </Button>
          </div>
        ) : (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              submit();
            }}
            className="space-y-3.5"
          >
            <div className="space-y-1.5">
              <Label htmlFor="quote-reveal-reason" className="text-[12px] font-extrabold leading-tight">
                {t("quotesRevealReason")}
              </Label>
              <Input
                id="quote-reveal-reason"
                value={reason}
                maxLength={200}
                disabled={reveal.isPending}
                onChange={(e) => setReason(e.target.value)}
                placeholder={t("quotesRevealReasonPh")}
                className="w-full"
              />
              <p className="text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                {t("quotesRevealAudit")}
              </p>
            </div>
            <Button
              type="submit"
              disabled={reveal.isPending || reason.trim().length === 0}
              className="h-11 w-full gap-2 rounded-xl bg-linear-to-l from-amber-500 to-orange-500 font-extrabold text-white shadow-lg shadow-amber-500/30"
            >
              {reveal.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="key-round" className="h-4 w-4" />
              )}
              {t("quotesRevealCta")}
            </Button>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}

/* ------------------------------------------------------------------ */
/* one pipeline card                                                   */
/* ------------------------------------------------------------------ */

function QuoteCard({
  quote,
  canManage,
  isSuper,
  onReveal,
}: {
  quote: EnterpriseQuoteDTO;
  canManage: boolean;
  isSuper: boolean;
  onReveal: (quote: EnterpriseQuoteDTO) => void;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const [notesDraft, setNotesDraft] = useState(quote.adminNotes);
  const [editingNotes, setEditingNotes] = useState(false);

  const meta = STATUS_META[quote.status];
  const transitions = nextStatuses(quote.status);

  const patch = useMutation({
    mutationFn: (payload: { status?: QuoteStatus; adminNotes?: string }) =>
      patchAdminEnterpriseQuote({ id: quote.id, ...payload }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["admin-quotes"] });
    },
    onError: (error: Error) =>
      toast.error(error.message ? `${t("quotesPatchErr")} — ${error.message}` : t("quotesPatchErr")),
  });

  const saveNotes = () => {
    if (patch.isPending) return;
    setEditingNotes(false);
    patch.mutate({ adminNotes: notesDraft.slice(0, 2000) });
  };

  const move = (status: QuoteStatus) => {
    if (patch.isPending) return;
    patch.mutate({ status });
  };

  return (
    <article className="glass-card card-in rounded-3xl p-4 sm:p-5">
      {/* header: identity + status chip */}
      <div className="flex flex-wrap items-start justify-between gap-2.5">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <span
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
              style={{ backgroundImage: grad(meta.c1, meta.c2) }}
              aria-hidden="true"
            >
              <CatIcon name="building" className="h-4 w-4" />
            </span>
            <h3 className="truncate font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
              {quote.company || quote.name}
            </h3>
            {quote.company ? (
              <span className="truncate text-[11.5px] font-semibold text-slate-400 dark:text-slate-500">
                {quote.name}
              </span>
            ) : null}
          </div>
          {/* masked email + the reveal lever (super-only) */}
          <div className="mt-1.5 flex flex-wrap items-center gap-2">
            <code
              dir="ltr"
              className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-2.5 py-1 font-mono text-[11px] font-bold text-slate-500 dark:bg-white/10 dark:text-slate-400"
            >
              <CatIcon name="lock" className="h-3 w-3 shrink-0" />
              {quote.emailMasked}
            </code>
            {isSuper ? (
              <button
                type="button"
                onClick={() => onReveal(quote)}
                className="inline-flex items-center gap-1 rounded-full bg-amber-500/10 px-2.5 py-1 text-[10.5px] font-extrabold text-amber-600 transition hover:bg-amber-500/20 active:scale-95 dark:text-amber-400"
              >
                <CatIcon name="key-round" className="h-3 w-3" />
                {t("quotesRevealBtn")}
              </button>
            ) : null}
          </div>
        </div>
        <span
          className="inline-flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1 text-[11px] font-extrabold text-white shadow-md"
          style={{ backgroundImage: grad(meta.c1, meta.c2) }}
        >
          <CatIcon name={meta.icon} className="h-3 w-3" />
          {t(meta.labelKey)}
        </span>
      </div>

      {/* need badges: team size + systems + timeline stamps */}
      <div className="mt-3.5 flex flex-wrap items-center gap-1.5">
        <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-2.5 py-1 text-[10.5px] font-extrabold text-slate-600 dark:bg-white/10 dark:text-slate-300">
          <CatIcon name="users" className="h-[11px] w-[11px]" />
          {t("quotesTeamSize")}: {quote.teamSize}
        </span>
        <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-2.5 py-1 text-[10.5px] font-extrabold text-slate-600 dark:bg-white/10 dark:text-slate-300">
          <CatIcon name="server" className="h-[11px] w-[11px]" />
          {t("quotesSystemsCount", { n: fmtNum(quote.systemsCount, lang) })}
        </span>
        <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-2.5 py-1 text-[10.5px] font-semibold text-slate-500 dark:bg-white/10 dark:text-slate-400">
          <CatIcon name="clock" className="h-[11px] w-[11px]" />
          {relativeTime(quote.createdAt, lang)}
        </span>
        {quote.contactedAt ? (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-sky-500/10 px-2.5 py-1 text-[10.5px] font-bold text-sky-600 dark:text-sky-300">
            <CatIcon name="send" className="h-[11px] w-[11px]" />
            {t("quotesContactedAt")}: {relativeTime(quote.contactedAt, lang)}
          </span>
        ) : null}
        {quote.quotedAt ? (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-500/10 px-2.5 py-1 text-[10.5px] font-bold text-amber-600 dark:text-amber-300">
            <CatIcon name="file-text" className="h-[11px] w-[11px]" />
            {t("quotesQuotedAt")}: {relativeTime(quote.quotedAt, lang)}
          </span>
        ) : null}
        {quote.closedAt ? (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-500/10 px-2.5 py-1 text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
            <CatIcon name="circle-check" className="h-[11px] w-[11px]" />
            {t("quotesClosedAt")}: {relativeTime(quote.closedAt, lang)}
          </span>
        ) : null}
      </div>

      {/* the lead's own notes */}
      {quote.notes ? (
        <div className="mt-3 rounded-xl border border-slate-200/70 bg-white/60 px-3.5 py-2.5 dark:border-white/10 dark:bg-white/[0.03]">
          <p className="text-[10px] font-bold uppercase tracking-wide text-slate-400 dark:text-slate-500">
            {t("quotesNotes")}
          </p>
          <p className="mt-1 whitespace-pre-line text-[12px] font-semibold leading-relaxed text-slate-600 dark:text-slate-300">
            {quote.notes}
          </p>
        </div>
      ) : null}

      {/* the working pad (adminNotes) */}
      <div className="mt-3 rounded-xl border border-dashed border-slate-200 px-3.5 py-2.5 dark:border-white/10">
        <div className="flex items-center justify-between gap-2">
          <p className="text-[10px] font-bold uppercase tracking-wide text-slate-400 dark:text-slate-500">
            {t("quotesAdminNotes")}
          </p>
          {canManage ? (
            editingNotes ? (
              <span className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={saveNotes}
                  disabled={patch.isPending}
                  className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2.5 py-1 text-[10px] font-extrabold text-emerald-600 transition hover:bg-emerald-500/20 active:scale-95 disabled:opacity-50 dark:text-emerald-300"
                >
                  <CatIcon name="check" className="h-3 w-3" />
                  {t("quotesSaveNotes")}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setEditingNotes(false);
                    setNotesDraft(quote.adminNotes);
                  }}
                  className="inline-flex items-center gap-1 rounded-full bg-slate-500/10 px-2.5 py-1 text-[10px] font-extrabold text-slate-500 transition hover:bg-slate-500/20 active:scale-95 dark:text-slate-400"
                >
                  <CatIcon name="x" className="h-3 w-3" />
                  {t("quotesCancelNotes")}
                </button>
              </span>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setNotesDraft(quote.adminNotes);
                  setEditingNotes(true);
                }}
                className="inline-flex items-center gap-1 rounded-full bg-brand-500/10 px-2.5 py-1 text-[10px] font-extrabold text-brand-600 transition hover:bg-brand-500/20 active:scale-95 dark:text-brand-300"
              >
                <CatIcon name="pen-line" className="h-3 w-3" />
                {t("quotesEditNotes")}
              </button>
            )
          ) : null}
        </div>
        {editingNotes ? (
          <Textarea
            rows={3}
            value={notesDraft}
            maxLength={2000}
            disabled={patch.isPending}
            onChange={(e) => setNotesDraft(e.target.value)}
            placeholder={t("quotesAdminNotesPh")}
            className="mt-2 min-h-[72px] w-full resize-none rounded-xl text-[12px] font-semibold leading-relaxed"
          />
        ) : quote.adminNotes ? (
          <p className="mt-1 whitespace-pre-line text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
            {quote.adminNotes}
          </p>
        ) : (
          <p className="mt-1 text-[11.5px] font-semibold italic leading-relaxed text-slate-300 dark:text-slate-600">
            {t("quotesNoNotes")}
          </p>
        )}
      </div>

      {/* pipeline transitions */}
      {canManage && transitions.length > 0 ? (
        <div className="mt-3.5 flex flex-wrap items-center gap-1.5 border-t border-slate-200/70 pt-3 dark:border-white/10">
          <span className="text-[10px] font-bold uppercase tracking-wide text-slate-400 dark:text-slate-500">
            {t("quotesMoveLabel")}
          </span>
          {transitions.map((next) => {
            const nextMeta = STATUS_META[next];
            return (
              <button
                key={`${quote.id}-${next}`}
                type="button"
                onClick={() => move(next)}
                disabled={patch.isPending}
                className="inline-flex items-center gap-1 rounded-full px-3 py-1.5 text-[11px] font-extrabold text-white shadow-md transition hover:brightness-110 active:scale-95 disabled:opacity-50"
                style={{ backgroundImage: grad(nextMeta.c1, nextMeta.c2) }}
              >
                <CatIcon name={nextMeta.icon} className="h-3 w-3" />
                {t(nextMeta.labelKey)}
              </button>
            );
          })}
          {patch.isPending ? (
            <CatIcon name="refresh-cw" className="h-3.5 w-3.5 animate-spin text-slate-400" />
          ) : null}
        </div>
      ) : canManage && transitions.length === 0 ? (
        <div className="mt-3.5 flex items-center gap-1.5 border-t border-slate-200/70 pt-3 text-[10.5px] font-bold text-slate-400 dark:border-white/10 dark:text-slate-500">
          <CatIcon name="lock" className="h-3 w-3 shrink-0" />
          {t("quotesTerminal")}
        </div>
      ) : null}
    </article>
  );
}

/* ------------------------------------------------------------------ */
/* the inbox                                                           */
/* ------------------------------------------------------------------ */

export function AdminQuotes() {
  const { t } = useT();
  const { user } = useAdminAuth();
  const canManage = useAdminCanManage();
  const isSuper = user?.role === "super";
  const [filter, setFilter] = useState<QuoteStatus | "all">("all");
  const [revealTarget, setRevealTarget] = useState<EnterpriseQuoteDTO | null>(null);

  /* keyset pages (newest first) — the admin-activities-feed law: the cursor
   * resumes STRICTLY after the last seen row, pages accumulate client-side,
   * and the feed never reads the whole table. */
  const PAGE_SIZE = 20;
  const feed = useInfiniteQuery({
    queryKey: ["admin-quotes", filter, PAGE_SIZE],
    queryFn: ({ pageParam }) =>
      fetchAdminEnterpriseQuotes({
        ...(filter !== "all" ? { status: filter } : {}),
        ...(pageParam ? { cursor: pageParam } : {}),
        limit: PAGE_SIZE,
      }),
    initialPageParam: null as string | null,
    getNextPageParam: (lastPage) => lastPage.nextCursor,
    staleTime: 30_000,
  });

  const rows = useMemo(
    () => feed.data?.pages.flatMap((p) => p.rows) ?? [],
    [feed.data]
  );
  const hasNextPage = feed.hasNextPage;

  /* the loaded-page pipeline census (honest: what is in view, not a
   * full-table count — the keyset feed never reads the whole table) */
  const counts = useMemo(() => {
    const base: Record<QuoteStatus, number> = { new: 0, contacted: 0, quoted: 0, won: 0, lost: 0 };
    for (const row of rows) base[row.status] += 1;
    return base;
  }, [rows]);

  const changeFilter = (next: QuoteStatus | "all") => {
    setFilter(next);
  };

  return (
    <div className="space-y-5">
      <ViewHeading title={t("quotesNav")} desc={t("quotesDesc")} />

      {/* pipeline KPIs (the loaded page's census) */}
      <div className="grid gap-3.5 sm:grid-cols-2 lg:grid-cols-4">
        <KpiCard
          label={t("quotesStatusNew")}
          numeric={counts.new}
          icon="inbox"
          c1="#6d5dfb"
          c2="#06b6d4"
          index={0}
        />
        <KpiCard
          label={t("quotesKpiActive")}
          numeric={counts.contacted + counts.quoted}
          icon="send"
          c1="#0891b2"
          c2="#0ea5e9"
          index={1}
        />
        <KpiCard
          label={t("quotesStatusWon")}
          numeric={counts.won}
          icon="circle-check"
          c1="#10b981"
          c2="#0d9488"
          index={2}
        />
        <KpiCard
          label={t("quotesStatusLost")}
          numeric={counts.lost}
          icon="x"
          c1="#f43f5e"
          c2="#e11d48"
          index={3}
        />
      </div>

      {/* status filter chips */}
      <div className="flex flex-wrap items-center gap-1.5">
        {(["all", ...STATUS_VALUES] as const).map((value) => {
          const active = filter === value;
          return (
            <button
              key={value}
              type="button"
              onClick={() => changeFilter(value)}
              aria-pressed={active}
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-[11.5px] font-extrabold transition active:scale-95",
                active
                  ? "border-brand-400 bg-brand-500/10 text-brand-600 shadow-sm dark:border-brand-400/40 dark:text-brand-300"
                  : "border-slate-200 bg-white/70 text-slate-500 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:text-brand-300"
              )}
            >
              <CatIcon
                name={value === "all" ? "scale" : STATUS_META[value].icon}
                className="h-3 w-3"
              />
              {value === "all" ? t("quotesFilterAll") : t(STATUS_META[value].labelKey)}
            </button>
          );
        })}
      </div>

      {/* the pipeline cards */}
      {feed.isPending ? (
        <div className="grid gap-3.5">
          {[0, 1, 2].map((i) => (
            <div key={i} className="glass-card rounded-3xl p-5">
              <Skeleton className="h-16 w-full" />
              <Skeleton className="mt-3 h-8 w-2/3" />
              <Skeleton className="mt-3 h-20 w-full" />
            </div>
          ))}
        </div>
      ) : rows.length === 0 ? (
        <DashCard>
          <div className="flex flex-col items-center gap-3 py-10 text-center">
            <span
              className="grid h-14 w-14 place-items-center rounded-2xl text-white shadow-lg shadow-amber-500/25"
              style={{ backgroundImage: grad("#f59e0b", "#ea580c") }}
              aria-hidden="true"
            >
              <CatIcon name="building" className="h-6 w-6" />
            </span>
            <p className="font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
              {t("quotesEmptyTitle")}
            </p>
            <p className="max-w-sm text-[12.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
              {t("quotesEmptyDesc")}
            </p>
          </div>
        </DashCard>
      ) : (
        <div className="grid gap-3.5">
          {rows.map((quote) => (
            <QuoteCard
              key={quote.id}
              quote={quote}
              canManage={canManage}
              isSuper={isSuper}
              onReveal={setRevealTarget}
            />
          ))}
        </div>
      )}

      {/* keyset load-more */}
      {rows.length > 0 && hasNextPage ? (
        <div className="flex justify-center">
          <Button
            type="button"
            variant="outline"
            onClick={() => void feed.fetchNextPage()}
            disabled={feed.isFetchingNextPage}
            className="h-10 gap-2 rounded-xl px-5 text-[12px] font-extrabold"
          >
            {feed.isFetchingNextPage ? (
              <CatIcon name="refresh-cw" className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <CatIcon name="chevron-down" className="h-3.5 w-3.5" />
            )}
            {t("quotesLoadMore")}
          </Button>
        </div>
      ) : null}

      {/* the one-time email reveal lever (super-only) */}
      {isSuper ? <RevealEmailDialog quote={revealTarget} onOpenChange={(open) => !open && setRevealTarget(null)} /> : null}
    </div>
  );
}

export default AdminQuotes;
