"use client";

/**
 * Ashrilogic — ROUND 46 (F-8) — admin Stores view.
 *
 * Every tenant storefront on the platform in one premium grid, powered by
 * GET /api/admin/stores (one admin-guarded aggregation — catalog module,
 * currency, live product/stock stats, the whole order pipeline, revenue of
 * completed orders and the public-site state).
 *
 * Layout: KPI strip → search + status chips → premium store cards (mobile
 * one-column, desktop two-column) with per-store catalog stats, order
 * pipeline badges, revenue and quick actions (open public store / open the
 * tenant dashboard). Arabic-first typography (labelTrack, tabular numerals,
 * RTL-safe LTR figures).
 */
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { CATEGORY_MAP, MODULE_MAP, SYSTEM_MAP } from "@/data/catalog";
import { fetchAdminStores } from "@/lib/api-client";
import { useAdminCanManage } from "@/lib/admin-auth";
import { useT } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import type { AdminStoreDTO, Lang } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { cn, copyText, fmtNum, grad, labelTrack, normalizeSearch } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { DashCard, IconTile, ViewHeading, relativeTime } from "@/components/dashboard/dash-shared";
import { intlLocale } from "@/lib/locales";

type StoreFilter = "all" | "catalog" | "orders" | "live";

/* ---------------- KPI card ---------------- */

function StoreKpi({
  label,
  value,
  /** ROUND 67 — mobile-compact rendering for long figures (money strings
   *  with currency codes) so the value never truncates or collides on
   *  narrow RTL layouts; falls back to the full value when absent. */
  compact,
  icon,
  c1,
  c2,
  index,
  lang,
}: {
  label: string;
  value: string;
  compact?: string;
  icon: string;
  c1: string;
  c2: string;
  index: number;
  lang: Lang;
}) {
  return (
    <article
      className="glass-card card-in group relative overflow-hidden rounded-3xl p-4 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lift sm:p-5"
      style={{ "--i": index } as React.CSSProperties}
    >
      <span
        className="absolute inset-x-0 top-0 h-1 origin-center scale-x-0 transition-transform duration-300 group-hover:scale-x-100"
        style={{ backgroundImage: grad(c1, c2, 90) }}
        aria-hidden="true"
      />
      <div className="flex items-center gap-3">
        <span
          className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl text-white shadow-lg transition-transform duration-300 group-hover:scale-105 sm:h-12 sm:w-12"
          style={{ backgroundImage: grad(c1, c2) }}
        >
          <CatIcon name={icon} className="h-4 w-4 sm:h-[18px] sm:w-[18px]" />
        </span>
        <div className="min-w-0 flex-1">
          <p className={cn("truncate text-[9.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500 sm:text-[10.5px]", labelTrack(lang))}>
            {label}
          </p>
          {/* ROUND 67 — responsive value typography: compact figures at
              mobile widths (never truncated/colliding), full display size
              from the sm breakpoint up. */}
          {/* ROUND 69 — full Arabic RTL: Arabic-Indic digits flow natively
              RTL; values align start (right in AR) so figure and Arabic
              label share one reading edge — no LTR islands, no imbalance.
              English keeps its LTR posture untouched. */}
          <p dir={lang === "en" ? "ltr" : undefined} className="mt-0.5 hidden text-start font-display text-[26px] font-extrabold tabular-nums leading-tight text-slate-900 dark:text-white sm:block">
            {value}
          </p>
          <p dir={lang === "en" ? "ltr" : undefined} className="mt-0.5 truncate text-start font-display text-[15.5px] font-extrabold tabular-nums leading-tight text-slate-900 dark:text-white sm:hidden">
            {compact ?? value}
          </p>
        </div>
      </div>
    </article>
  );
}

/* ---------------- store card ---------------- */

function OrderPill({ n, tone, label }: { n: number; tone: string; label: string }) {
  if (n <= 0) return null;
  return (
    <span
      className={cn(
        /* ROUND 67 — shrink-0 + nowrap: flex children can otherwise be
           compressed below their content width on narrow RTL rows, which
           painted pill text OVER its neighbours (تداخل). The pills now keep
           their intrinsic width and the wrapping row stacks them cleanly. */
        "inline-flex shrink-0 items-center gap-1 whitespace-nowrap rounded-full px-2 py-0.5 text-[10px] font-extrabold tabular-nums",
        tone
      )}
    >
      {label}
    </span>
  );
}

function StoreCard({ store, canManage, onOpenDash }: { store: AdminStoreDTO; canManage: boolean; onOpenDash: (id: string) => void }) {
  const { t, lang } = useT();
  const sys = SYSTEM_MAP[store.systemId];
  const cat = sys ? CATEGORY_MAP[sys.c] : undefined;
  const c1 = cat?.c1 ?? "#6d5dfb";
  const c2 = cat?.c2 ?? "#0ea5e9";
  const mod = store.moduleId ? MODULE_MAP[store.moduleId] : undefined;

  const copyStoreUrl = () => {
    /* ROUND 69 — the STORES view links to the storefront (/store), never to
     * the public site — the two destinations must stay distinct. */
    const url = `${window.location.origin}/sites/${store.instanceId}/store`;
    copyText(url)
      .then(() => toast.success(t("secCopied")))
      .catch(() => toast.error(t("errGenericAction")));
  };

  return (
    <article className="glass-card card-in group relative overflow-hidden rounded-3xl p-5" style={{ "--i": 1 } as React.CSSProperties}>
      {/* header: identity + site state */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <IconTile icon={sys?.icon ?? "store"} c1={c1} c2={c2} size="md" />
          <div className="min-w-0">
            <p className="truncate font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
              {store.orgName}
            </p>
            <p className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] font-bold text-slate-400 dark:text-slate-500">
              <span className="truncate">{sys ? (lang === "ar" ? sys.nameAr : sys.nameEn) : store.systemId}</span>
              {mod ? (
                <span className="inline-flex items-center gap-1 rounded-full bg-brand-500/10 px-2 py-px text-[11px] font-extrabold text-brand-600 dark:text-brand-300">
                  <CatIcon name={mod.icon} className="h-2.5 w-2.5" />
                  {lang === "ar" ? mod.nameAr : mod.nameEn}
                </span>
              ) : null}
            </p>
          </div>
        </div>
        <span
          className={cn(
            "inline-flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-extrabold",
            store.sitePublished
              ? "border-emerald-300/70 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
              : "border-slate-300/70 bg-slate-500/10 text-slate-400 dark:border-white/10 dark:text-slate-500"
          )}
        >
          {store.sitePublished ? (
            <>
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-500" aria-hidden="true" />
              {t("adminStoresPublished")}
            </>
          ) : (
            <>
              <CatIcon name="eye-off" className="h-3 w-3" />
              {t("adminStoresDraft")}
            </>
          )}
        </span>
      </div>

      {store.moduleId === null ? (
        /* no catalog module */
        <div className="mt-4 rounded-2xl border border-dashed border-slate-300/70 bg-slate-50/50 p-4 text-center dark:border-white/10 dark:bg-white/[0.02]">
          <p className="text-[12px] font-extrabold text-slate-500 dark:text-slate-400">
            {t("adminStoresNoModule")}
          </p>
          <p className="mt-1 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("adminStoresNoModuleHint")}
          </p>
        </div>
      ) : (
        <>
          {/* catalog stats — ROUND 69 RTL: Arabic-Indic figures flow
              naturally RTL and align to the reading edge (right), matching
              the Arabic label above them. */}
          <div className="mt-4 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
            <div className="rounded-2xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
              <p className={cn("text-[11px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                {t("adminStoresColCatalog")}
              </p>
              <p dir={lang === "en" ? "ltr" : undefined} className="mt-0.5 text-start text-[15px] font-extrabold tabular-nums text-slate-800 dark:text-slate-100">
                {fmtNum(store.products, lang)}
              </p>
            </div>
            <div className="rounded-2xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
              <p className={cn("text-[11px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                {t("adminStoresLowStock")}
              </p>
              <p dir={lang === "en" ? "ltr" : undefined} className={cn("mt-0.5 text-start text-[15px] font-extrabold tabular-nums", store.lowStock > 0 ? "text-amber-600 dark:text-amber-400" : "text-slate-800 dark:text-slate-100")}>
                {fmtNum(store.lowStock, lang)}
              </p>
            </div>
            <div className="rounded-2xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
              <p className={cn("text-[11px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                {t("adminStoresStockValue")}
              </p>
              {/* currency as a natural Arabic SUFFIX: figure first (right),
                  currency code to its left — never a Latin-ordered prefix */}
              <p dir={lang === "en" ? "ltr" : undefined} className="mt-0.5 text-start text-[13px] font-extrabold tabular-nums text-slate-800 dark:text-slate-100">
                {fmtNum(store.stockValue, lang)} <span className="text-[11px] font-bold text-slate-400">{store.currency}</span>
              </p>
            </div>
            <div className="rounded-2xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
              <p className={cn("text-[11px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                {t("adminStoresCategories")}
              </p>
              <p dir={lang === "en" ? "ltr" : undefined} className="mt-0.5 text-start text-[15px] font-extrabold tabular-nums text-slate-800 dark:text-slate-100">
                {fmtNum(store.categories, lang)}
              </p>
            </div>
          </div>

          {/* order pipeline */}
          <div className="mt-3 rounded-2xl border border-slate-200/70 bg-slate-50/50 p-3 dark:border-white/10 dark:bg-white/[0.02]">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                <CatIcon name="shopping-cart" className="h-3 w-3" />
                {t("adminStoresColOrders")}
              </span>
              <span className="text-[13px] font-extrabold tabular-nums text-slate-800 dark:text-slate-100">
                {fmtNum(store.orders, lang)}
              </span>
              <span className="ms-auto flex flex-wrap items-center gap-1.5">
                <OrderPill
                  n={store.ordersPending}
                  tone="bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300"
                  label={t("adminStoresPendingBadge", { n: fmtNum(store.ordersPending, lang) })}
                />
                <OrderPill
                  n={store.ordersActive}
                  tone="bg-cyan-100 text-cyan-700 dark:bg-cyan-500/15 dark:text-cyan-300"
                  label={t("adminStoresActiveBadge", { n: fmtNum(store.ordersActive, lang) })}
                />
                <OrderPill
                  n={store.ordersCompleted}
                  tone="bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300"
                  label={t("adminStoresDoneBadge", { n: fmtNum(store.ordersCompleted, lang) })}
                />
                <OrderPill
                  n={store.ordersCancelled}
                  tone="bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300"
                  label={t("adminStoresCancelledBadge", { n: fmtNum(store.ordersCancelled, lang) })}
                />
              </span>
            </div>
            <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 border-t border-slate-200/70 pt-2 text-[10.5px] font-bold text-slate-400 dark:border-white/[0.06] dark:text-slate-500">
              <span className="inline-flex shrink-0 items-center gap-1 whitespace-nowrap">
                <CatIcon name="hand-coins" className="h-3 w-3 text-emerald-500" />
                {t("adminStoresKpiRevenue")}:
                <span dir={lang === "en" ? "ltr" : undefined} className="font-extrabold text-emerald-600 dark:text-emerald-400">
                  {fmtNum(store.revenue / 100, lang)} {store.currency}
                </span>
              </span>
              <span className="inline-flex shrink-0 items-center gap-1 whitespace-nowrap">
                <CatIcon name="clock" className="h-3 w-3" />
                {t("adminStoresLastOrder")}:
                {store.lastOrderAt ? relativeTime(store.lastOrderAt, lang) : t("adminStoresOrdersEmpty")}
              </span>
              <span className="inline-flex shrink-0 items-center gap-1 whitespace-nowrap">
                <CatIcon name="eye" className="h-3 w-3" />
                {t("adminStoresViews", { n: fmtNum(store.siteViews, lang) })}
              </span>
            </div>
          </div>
        </>
      )}

      {/* actions */}
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={() => window.open(`/sites/${store.instanceId}/store`, "_blank", "noopener,noreferrer")}
          disabled={store.moduleId === null}
          className="inline-flex h-9 items-center gap-1.5 rounded-xl px-3.5 text-[11.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-40 disabled:active:scale-100"
          style={{ backgroundImage: grad("#6d5dfb", "#a855f7") }}
        >
          <CatIcon name="external-link" className="h-3.5 w-3.5" />
          {t("adminStoresOpenSite")}
        </button>
        <button
          type="button"
          onClick={copyStoreUrl}
          className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 px-3.5 text-[11.5px] font-bold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:text-slate-300 dark:hover:text-brand-300"
        >
          <CatIcon name="copy" className="h-3.5 w-3.5" />
          {t("secCopyTip")}
        </button>
        {canManage ? (
          <button
            type="button"
            onClick={() => onOpenDash(store.instanceId)}
            className="ms-auto inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 px-3.5 text-[11.5px] font-bold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:text-slate-300 dark:hover:text-brand-300"
          >
            <CatIcon name="gauge" className="h-3.5 w-3.5" />
            {t("adminStoresOpenDash")}
          </button>
        ) : null}
      </div>
    </article>
  );
}

/* ---------------- view ---------------- */

export function AdminStores() {
  const { t, lang } = useT();
  const canManage = useAdminCanManage();
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<StoreFilter>("all");

  /* ROUND 81 — the «لوحة المستأجر» (tenant dashboard) button previously
   * relied on an OPTIONAL onOpenDashboard prop the admin shell never
   * passed, so the click did NOTHING (the reported bug). The view is now
   * self-sufficient — exactly like the subscribers view: arming the
   * persisted store AND navigating to the app root where the tenant
   * dashboard actually renders (the admin session authorizes tenant
   * access server-side via requireInstanceAccess's admin path). */
  const router = useRouter();
  const setCurrentInstance = useAppStore((s) => s.setCurrentInstance);
  const setView = useAppStore((s) => s.setView);
  const openTenantDashboard = (instanceId: string) => {
    setCurrentInstance(instanceId);
    setView("dashboard");
    router.push("/");
  };

  const query = useQuery({
    queryKey: ["admin-stores"],
    queryFn: fetchAdminStores,
  });

  const stores = query.data?.stores ?? [];
  const totals = query.data?.totals;

  const filtered = useMemo(() => {
    const q = normalizeSearch(search.trim());
    return stores.filter((store) => {
      if (q) {
        const sys = SYSTEM_MAP[store.systemId];
        const mod = store.moduleId ? MODULE_MAP[store.moduleId] : undefined;
        const haystack = [
          store.orgName,
          store.systemId,
          sys?.nameAr ?? "",
          sys?.nameEn ?? "",
          mod?.nameAr ?? "",
          mod?.nameEn ?? "",
        ].join(" ");
        if (!normalizeSearch(haystack).includes(q)) return false;
      }
      switch (filter) {
        case "catalog":
          return store.moduleId !== null;
        case "orders":
          return store.orders > 0;
        case "live":
          return store.sitePublished;
        default:
          return true;
      }
    });
  }, [stores, search, filter]);

  const revenueLabel =
    totals && totals.revenue.length > 0
      ? totals.revenue
          .slice(0, 2)
          .map((r) => `${fmtNum(r.value, lang)} ${r.currency}`)
          .join(" + ")
      : "—";

  /* ROUND 67 — compact figures (Intl compact notation) for the KPI strip's
     narrow mobile columns: "٦٣٫٨ SAR" / "٣١ ألف SAR" instead of long
     decimal money strings that truncated at 2-column mobile widths. */
  const compactMoney = (v: number): string => {
    try {
      return new Intl.NumberFormat(intlLocale(lang), {
        notation: "compact",
        maximumFractionDigits: 1,
      }).format(v);
    } catch {
      return String(v);
    }
  };
  const revenueCompact =
    totals && totals.revenue.length > 0
      ? totals.revenue
          .slice(0, 2)
          .map((r) => `${compactMoney(r.value)} ${r.currency}`)
          .join(" + ")
      : "—";

  const FILTERS: { key: StoreFilter; label: string }[] = [
    { key: "all", label: t("adminStoresFilterAll") },
    { key: "catalog", label: t("adminStoresFilterCatalog") },
    { key: "orders", label: t("adminStoresFilterOrders") },
    { key: "live", label: t("adminStoresFilterLive") },
  ];

  return (
    <div className="space-y-5">
      <ViewHeading title={t("adminStores")} desc={t("adminStoresDesc")} />

      {/* KPI strip */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        <StoreKpi index={0} lang={lang} icon="store" c1="#6d5dfb" c2="#a855f7" label={t("adminStoresKpiStores")} value={fmtNum(totals?.stores ?? 0, lang)} />
        <StoreKpi index={1} lang={lang} icon="package" c1="#0ea5e9" c2="#0284c7" label={t("adminStoresKpiCatalog")} value={fmtNum(totals?.withCatalog ?? 0, lang)} />
        <StoreKpi index={2} lang={lang} icon="cubes" c1="#10b981" c2="#059669" label={t("adminStoresKpiProducts")} value={fmtNum(totals?.products ?? 0, lang)} />
        <StoreKpi index={3} lang={lang} icon="shopping-cart" c1="#f59e0b" c2="#ea580c" label={t("adminStoresKpiOrders")} value={fmtNum(totals?.orders ?? 0, lang)} />
        <StoreKpi index={4} lang={lang} icon="hourglass" c1="#d946ef" c2="#c026d3" label={t("adminStoresKpiPending")} value={fmtNum(totals?.ordersPending ?? 0, lang)} />
        <StoreKpi index={5} lang={lang} icon="hand-coins" c1="#06b6d4" c2="#0891b2" label={t("adminStoresKpiRevenue")} value={revenueLabel} compact={revenueCompact} />
      </div>

      {/* toolbar: search + status chips */}
      <DashCard>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="relative max-w-md flex-1">
            <CatIcon
              name="search"
              className="pointer-events-none absolute start-3.5 top-1/2 h-[13px] w-[13px] -translate-y-1/2 text-slate-400"
            />
            <Input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t("adminStoresSearchPh")}
              aria-label={t("adminStoresSearchPh")}
              className="h-10 rounded-xl border-slate-200 bg-slate-50/80 ps-10 pe-3 text-[12.5px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:focus:bg-white/[0.07]"
            />
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            {FILTERS.map((f) => (
              <button
                key={f.key}
                type="button"
                onClick={() => setFilter(f.key)}
                className={cn(
                  "h-9 rounded-xl px-3.5 text-[11.5px] font-extrabold transition active:scale-95",
                  filter === f.key
                    ? "bg-linear-to-r from-brand-600 to-brand-500 text-white shadow-lg shadow-brand-500/25"
                    : "border border-slate-200 bg-white/70 text-slate-500 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:text-brand-300"
                )}
              >
                {f.label}
              </button>
            ))}
            <Badge variant="secondary" className="rounded-full px-3 py-1 text-[11px] font-extrabold text-slate-600 dark:text-slate-300">
              {fmtNum(filtered.length, lang)} / {fmtNum(stores.length, lang)}
            </Badge>
          </div>
        </div>
      </DashCard>

      {/* store cards */}
      {query.isPending ? (
        <div className="grid gap-4 lg:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-64 w-full rounded-3xl" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <DashCard>
          <div className="flex flex-col items-center justify-center py-10 text-center">
            <span className="grid h-16 w-16 place-items-center rounded-3xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
              <CatIcon name="store" className="h-7 w-7" />
            </span>
            <p className="mt-4 text-[13px] font-extrabold text-slate-600 dark:text-slate-300">
              {t("adminStoresEmpty")}
            </p>
          </div>
        </DashCard>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {filtered.map((store) => (
            <StoreCard key={store.instanceId} store={store} canManage={canManage} onOpenDash={openTenantDashboard} />
          ))}
        </div>
      )}
    </div>
  );
}
