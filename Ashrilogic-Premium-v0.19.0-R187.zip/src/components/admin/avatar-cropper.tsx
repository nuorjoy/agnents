"use client";

/**
 * Ashrilogic — WhatsApp-style circular avatar cropper (round 35).
 *
 * Accepts an image of ANY size and ANY dimensions (phones shoot 12–50 MP
 * portraits, screenshots are extreme aspect ratios — all welcome) and lets
 * the admin fit it into the circular profile frame exactly like WhatsApp's
 * profile-photo editor:
 *
 *  - DRAG anywhere on the image to reposition (pointer events — mouse,
 *    touch and pen; two-finger pinch zooms on touch devices).
 *  - WHEEL zoom + zoom-out/in buttons + a precision slider (1×–8×).
 *  - TRUE 90° rotation in BOTH directions (ROUND 64): rotation lives in
 *    state and is applied as an animated CSS transform on the preview —
 *    instant, silky and lossless (the source is never re-encoded per
 *    step); APPLY bakes the net rotation into the canvas ONCE, so there
 *    is no generational JPEG loss no matter how many times you spun.
 *  - The circular mask is enforced LIVE: the pan is clamped so the circle
 *    can never show an empty gap, and the zoom can never drop below the
 *    cover fit — whatever the user applies is guaranteed to fill the frame.
 *  - APPLY crops the circle through a canvas at 288×288 (device-pixel
 *    aware) with an iterative JPEG quality search targeting ≤ 120 KB so
 *    the data-URL stays far below the server's 600k-char avatarUrl cap.
 *
 * Bilingual (AR/RTL + EN/LTR), dark mode, keyboard accessible controls.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { cn } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Slider } from "@/components/ui/slider";

/** viewport (crop circle) edge in CSS px — comfortable on phones too. */
const VIEW = 280;
/** output canvas edge (square) — 288 keeps the cap generous under 600k chars. */
const OUT = 288;
/** zoom range relative to the cover fit. */
const MIN_ZOOM = 1;
const MAX_ZOOM = 8;
/** target compressed payload (bytes, pre-base64). */
const TARGET_BYTES = 120 * 1024;

export interface CropResult {
  /** square circular-cropped data-URL (JPEG) */
  dataUrl: string;
  /** final encoded size in bytes */
  outBytes: number;
}

interface PinchState {
  distance: number;
  zoom: number;
}

export function AvatarCropperDialog({
  open,
  src,
  onClose,
  onApply,
}: {
  open: boolean;
  /** raw picked image (data-URL of ANY size / dimensions) */
  src: string | null;
  onClose: () => void;
  onApply: (result: CropResult) => void;
}) {
  const { t, lang } = useT();
  const imgRef = useRef<HTMLImageElement | null>(null);
  const pointersRef = useRef(new Map<number, { x: number; y: number }>());
  const pinchRef = useRef<PinchState | null>(null);
  const dragRef = useRef<{ x: number; y: number; ox: number; oy: number } | null>(null);

  const [zoom, setZoom] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [natural, setNatural] = useState({ w: 0, h: 0 });
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  /* ROUND 64 — net rotation in degrees (0 / 90 / 180 / 270). Kept as state
     and applied as an animated CSS transform on the preview; APPLY bakes it
     into the output canvas exactly once (lossless until the final encode). */
  const [rotation, setRotation] = useState(0);

  /* cover-fit scale: the image's SHORTER side exactly fills the viewport
     (rotation-invariant — the shorter side stays the shorter side). */
  const coverScale = useMemo(() => {
    if (!natural.w || !natural.h) return 1;
    return VIEW / Math.min(natural.w, natural.h);
  }, [natural]);
  const scale = coverScale * zoom;
  /** unrotated displayed image size (the <img> element's box) */
  const boxW = natural.w * scale;
  const boxH = natural.h * scale;
  /** ROTATED visible extent — what must cover the viewport square */
  const swapped = rotation % 180 !== 0;
  const dispW = swapped ? boxH : boxW;
  const dispH = swapped ? boxW : boxH;

  /* reset whenever a fresh image arrives */
  useEffect(() => {
    if (!open || !src) return;
    setZoom(1);
    setOffset({ x: 0, y: 0 });
    setRotation(0);
    setReady(false);
    const img = new Image();
    img.decoding = "async";
    img.onload = () => {
      imgRef.current = img;
      setNatural({ w: img.naturalWidth, h: img.naturalHeight });
      setReady(true);
    };
    img.src = src;
  }, [open, src]);

  /* clamp pan so the viewport square is always fully covered by the image */
  const clampOffset = useCallback(
    (x: number, y: number, w: number, h: number) => {
      const maxX = Math.max(0, (w - VIEW) / 2);
      const maxY = Math.max(0, (h - VIEW) / 2);
      return {
        x: Math.min(maxX, Math.max(-maxX, x)),
        y: Math.min(maxY, Math.max(-maxY, y)),
      };
    },
    []
  );

  const setZoomClamped = useCallback(
    (next: number) => {
      const z = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, next));
      setZoom(z);
      /* re-clamp the offset for the new size (anchored at the viewport
         center) — against the ROTATED extent so the circle stays covered */
      setOffset((o) =>
        clampOffset(o.x, o.y, (swapped ? natural.h : natural.w) * coverScale * z, (swapped ? natural.w : natural.h) * coverScale * z)
      );
    },
    [clampOffset, coverScale, natural, swapped]
  );

  /* ------------------------------ interactions ----------------------------- */

  const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    pointersRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pointersRef.current.size === 1) {
      dragRef.current = { x: e.clientX, y: e.clientY, ox: offset.x, oy: offset.y };
    } else if (pointersRef.current.size === 2) {
      const [a, b] = [...pointersRef.current.values()];
      pinchRef.current = { distance: Math.hypot(a.x - b.x, a.y - b.y), zoom };
      dragRef.current = null;
    }
  };

  const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!pointersRef.current.has(e.pointerId)) return;
    pointersRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

    if (pointersRef.current.size >= 2 && pinchRef.current) {
      /* two-finger pinch zoom */
      const [a, b] = [...pointersRef.current.values()];
      const dist = Math.hypot(a.x - b.x, a.y - b.y);
      const next = pinchRef.current.zoom * (dist / pinchRef.current.distance);
      setZoomClamped(next);
      return;
    }

    if (dragRef.current) {
      const d = dragRef.current;
      /* RTL does not affect pixel-space dragging — deltas are absolute */
      setOffset(clampOffset(d.ox + (e.clientX - d.x), d.oy + (e.clientY - d.y), dispW, dispH));
    }
  };

  const onPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    pointersRef.current.delete(e.pointerId);
    if (pointersRef.current.size < 2) pinchRef.current = null;
    if (pointersRef.current.size === 0) dragRef.current = null;
  };

  const onWheel = (e: React.WheelEvent<HTMLDivElement>) => {
    e.preventDefault();
    setZoomClamped(zoom * (e.deltaY < 0 ? 1.08 : 1 / 1.08));
  };

  /* --------------------------- ROUND 64 rotation --------------------------- */

  /* TRUE ±90° steps: pure display state (no re-encode, no decode, no jank) —
     the CSS transition on the <img> turns the swap into a silky spin, and
     the pan is re-clamped against the rotated extent so the circle can
     never expose a gap after a quarter turn of a wide image. */
  const rotateBy = (quarterTurns: 1 | -1) => {
    if (!ready || busy) return;
    setRotation((r) => (r + quarterTurns * 90 + 360) % 360);
    setOffset((o) => clampOffset(o.x, o.y, dispH, dispW));
  };

  /* full reset — zoom, pan AND orientation back to the picked original */
  const resetEdit = () => {
    if (!ready || busy) return;
    setZoom(1);
    setOffset({ x: 0, y: 0 });
    setRotation(0);
  };

  /* -------------------------------- apply ---------------------------------- */

  const apply = () => {
    const img = imgRef.current;
    if (!img || !ready || busy) return;
    setBusy(true);
    try {
      const canvas = document.createElement("canvas");
      canvas.width = OUT;
      canvas.height = OUT;
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("no 2d context");

      /* map the VIEW-sized viewport onto the OUT-sized canvas */
      const k = OUT / VIEW;
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = "high";
      /* the circular crop = the full viewport square, masked by its
         inscribed circle (exactly what the user positioned against) */
      ctx.save();
      ctx.beginPath();
      ctx.arc(OUT / 2, OUT / 2, OUT / 2, 0, Math.PI * 2);
      ctx.clip();
      /* white backdrop so transparent PNGs composite predictably */
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, OUT, OUT);
      /* ROUND 64 — bake the net rotation ONCE: translate to the display
         center, rotate, draw the unrotated box centered. Identical to the
         pre-rotation math when rotation === 0. */
      ctx.translate((VIEW / 2 + offset.x) * k, (VIEW / 2 + offset.y) * k);
      if (rotation) ctx.rotate((rotation * Math.PI) / 180);
      ctx.drawImage(img, (-boxW / 2) * k, (-boxH / 2) * k, boxW * k, boxH * k);
      ctx.restore();

      /* iterative quality search toward the payload target */
      let dataUrl = canvas.toDataURL("image/jpeg", 0.92);
      for (const q of [0.85, 0.75, 0.65, 0.55]) {
        if (dataUrl.length * 0.75 <= TARGET_BYTES) break;
        dataUrl = canvas.toDataURL("image/jpeg", q);
      }
      onApply({ dataUrl, outBytes: Math.round(dataUrl.length * 0.75) });
    } finally {
      setBusy(false);
    }
  };

  const rtl = lang === "ar";

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-[calc(100vw-2rem)] rounded-3xl sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2.5 font-display text-base font-extrabold text-slate-900 dark:text-white">
            <span
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg shadow-brand-500/25"
              style={{ backgroundImage: "linear-gradient(135deg, #6d5dfb, #06b6d4)" }}
              aria-hidden="true"
            >
              <CatIcon name="crop" className="h-[15px] w-[15px]" />
            </span>
            {t("cropTitle")}
          </DialogTitle>
          <DialogDescription className="text-[12px] leading-relaxed text-slate-500 dark:text-slate-400">
            {t("cropDesc")}
          </DialogDescription>
        </DialogHeader>

        {/* canvas stage */}
        <div className="flex justify-center">
          <div
            className="relative select-none touch-none"
            style={{ width: VIEW, height: VIEW }}
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerCancel={onPointerUp}
            onWheel={onWheel}
            role="application"
            aria-label={t("cropTitle")}
          >
            {/* dimmed backdrop + circular window (WhatsApp-style mask) */}
            <div className="absolute inset-0 overflow-hidden rounded-2xl bg-slate-100 dark:bg-white/[0.04]">
              {src && ready ? (
                <img
                  src={src}
                  alt=""
                  draggable={false}
                  className="crop-rotate-anim pointer-events-none absolute origin-center will-change-transform"
                  style={{
                    width: boxW,
                    height: boxH,
                    left: VIEW / 2 + offset.x - boxW / 2,
                    top: VIEW / 2 + offset.y - boxH / 2,
                    maxWidth: "none",
                    transform: rotation ? `rotate(${rotation}deg)` : undefined,
                  }}
                />
              ) : (
                <div className="grid h-full w-full place-items-center text-[12px] font-bold text-slate-400">
                  …
                </div>
              )}
            </div>
            {/* circular mask overlay */}
            <div
              className="pointer-events-none absolute inset-0"
              style={{
                background:
                  "radial-gradient(circle at 50% 50%, transparent 0, transparent calc(50% - 1.5px), rgba(15,23,42,0.55) calc(50% - 1.5px))",
              }}
              aria-hidden="true"
            />
            {/* subtle center guides */}
            <div className="pointer-events-none absolute inset-0" aria-hidden="true">
              <span className="absolute left-1/2 top-1/2 h-6 w-px -translate-x-1/2 -translate-y-1/2 bg-white/25" />
              <span className="absolute left-1/2 top-1/2 h-px w-6 -translate-x-1/2 -translate-y-1/2 bg-white/25" />
            </div>
            {/* focus ring */}
            <span
              className="pointer-events-none absolute inset-0 rounded-2xl ring-1 ring-inset ring-slate-900/10 dark:ring-white/15"
              aria-hidden="true"
            />
          </div>
        </div>

        {/* zoom controls */}
        <div className="flex items-center gap-3" dir={rtl ? "rtl" : "ltr"}>
          <button
            type="button"
            onClick={() => setZoomClamped(zoom / 1.25)}
            disabled={zoom <= MIN_ZOOM + 0.001 || !ready}
            aria-label={t("cropZoomOut")}
            title={t("cropZoomOut")}
            className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-slate-200 text-slate-600 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 disabled:opacity-40 dark:border-white/10 dark:text-slate-300"
          >
            <CatIcon name="zoom-out" className="h-4 w-4" />
          </button>
          <Slider
            value={[zoom]}
            min={MIN_ZOOM}
            max={MAX_ZOOM}
            step={0.01}
            onValueChange={(v) => setZoomClamped(v[0] ?? zoom)}
            disabled={!ready}
            aria-label={t("cropZoomIn")}
            className="flex-1"
          />
          <button
            type="button"
            onClick={() => setZoomClamped(zoom * 1.25)}
            disabled={zoom >= MAX_ZOOM - 0.001 || !ready}
            aria-label={t("cropZoomIn")}
            title={t("cropZoomIn")}
            className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-slate-200 text-slate-600 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 disabled:opacity-40 dark:border-white/10 dark:text-slate-300"
          >
            <CatIcon name="zoom-in" className="h-4 w-4" />
          </button>
        </div>

        <DialogFooter className="flex-row items-center gap-2 sm:justify-between">
          <div className="flex items-center gap-1.5">
            {/* ROUND 64 — true bidirectional rotation + a dedicated reset */}
            <button
              type="button"
              onClick={() => rotateBy(-1)}
              disabled={!ready || busy}
              aria-label={t("cropRotateCcw")}
              title={t("cropRotateCcw")}
              className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 text-slate-600 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 disabled:opacity-40 dark:border-white/10 dark:text-slate-300"
            >
              <CatIcon name="rotate-ccw" className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => rotateBy(1)}
              disabled={!ready || busy}
              aria-label={t("cropRotateCw")}
              title={t("cropRotateCw")}
              className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 text-slate-600 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 disabled:opacity-40 dark:border-white/10 dark:text-slate-300"
            >
              <CatIcon name="rotate-cw" className="h-4 w-4" />
            </button>
            <span className="mx-0.5 h-6 w-px bg-slate-200 dark:bg-white/10" aria-hidden="true" />
            <button
              type="button"
              onClick={resetEdit}
              disabled={!ready || busy}
              aria-label={t("cropReset")}
              title={t("cropReset")}
              className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 text-slate-600 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 disabled:opacity-40 dark:border-white/10 dark:text-slate-300"
            >
              <CatIcon name="refresh-cw" className="h-4 w-4" />
            </button>
            <span dir="ltr" className="ms-1 text-[11px] font-extrabold tabular-nums text-slate-400 dark:text-slate-500">
              {zoom.toFixed(zoom < 10 ? 2 : 1)}×
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="h-10 rounded-xl border border-slate-200 px-4 text-[12.5px] font-bold text-slate-600 transition hover:bg-slate-50 active:scale-95 dark:border-white/10 dark:text-slate-300 dark:hover:bg-white/5"
            >
              {t("cropCancel")}
            </button>
            <button
              type="button"
              onClick={apply}
              disabled={!ready || busy}
              className={cn(
                "inline-flex h-10 items-center gap-2 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-50"
              )}
            >
              {busy ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : <CatIcon name="check" className="h-4 w-4" />}
              {t("cropApply")}
            </button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default AvatarCropperDialog;
