"use client";

/**
 * ROUND 89 — the Notifications-tab LIVE FEED (سجل الإشعارات).
 *
 * The «إشعارات البريد» and «التقرير الأسبوعي» toggles now DO things
 * (platform-notifications.ts): event notices, the weekly digest and test
 * sends all leave real artifacts. This component makes that visible and
 * testable from the console itself:
 *
 *  - the transport chip (live SMTP vs the verifiable local outbox spool);
 *  - «إرسال إشعار تجريبي» — fires a REAL notice through the exact
 *    notifEmail pipeline and shows the delivery outcome;
 *  - «إرسال التقرير الآن» — builds + delivers THIS week's report on demand
 *    (idempotent per ISO week, exactly like the scheduler);
 *  - the dispatch log — the last notifications with kind, recipient,
 *    delivery outcome and relative time.
 */

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  fetchAdminNotifications,
  sendTestNotification,
  sendWeeklyReportNow,
} from "@/lib/api-client";
import { useT, type I18nKey } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { cn, grad } from "@/lib/utils";
import { relativeTime } from "@/components/dashboard/dash-shared";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

const FEED_QUERY_KEY = ["admin-notifications"] as const;

const KIND_META: Record<"event" | "weekly" | "test", { icon: string; c1: string; c2: string; key: I18nKey }> = {
  event: { icon: "zap", c1: "#06b6d4", c2: "#0e7490", key: "notifKindEvent" },
  weekly: { icon: "chart-pie", c1: "#d946ef", c2: "#c026d3", key: "notifKindWeekly" },
  test: { icon: "flask", c1: "#10b981", c2: "#059669", key: "notifKindTest" },
};

export function NotificationFeed() {
  const { t, lang } = useT();
  const queryClient = useQueryClient();

  const feed = useQuery({
    queryKey: FEED_QUERY_KEY,
    queryFn: fetchAdminNotifications,
    staleTime: 30_000,
  });

  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: FEED_QUERY_KEY });
  };

  const modeLabel = (mode: "smtp" | "spool"): string =>
    mode === "smtp" ? t("notifTransportSmtp") : t("notifTransportSpool");

  const testSend = useMutation({
    mutationFn: sendTestNotification,
    onSuccess: (result) => {
      invalidate();
      if (!result.sent) {
        /* the toggle is OFF — the pipeline correctly refused (the honest test) */
        toast.info(t("notifTestSkipped"));
        return;
      }
      if (result.delivered) {
        toast.success(t("notifTestSent", { to: result.recipient ?? "—", mode: modeLabel(result.transport ?? "spool") }));
      } else {
        toast.warning(t("notifTestFailed"));
      }
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  const weeklySend = useMutation({
    mutationFn: sendWeeklyReportNow,
    onSuccess: (result) => {
      invalidate();
      if (result.outcome === "sent") {
        if (result.delivered) {
          toast.success(t("notifWeeklySent", { week: result.weekKey, mode: modeLabel(result.transport ?? "spool") }));
        } else {
          toast.warning(t("notifWeeklyFailed", { err: result.error ?? t("notifFailed") }));
        }
      } else if (result.outcome === "skipped-already") {
        toast.info(t("notifWeeklyAlready", { week: result.weekKey }));
      } else {
        toast.error(t("notifWeeklyFailed", { err: result.error ?? t("errorText") }));
      }
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  const transport = feed.data?.transport ?? null;
  const rows = feed.data?.notifications ?? [];

  return (
    <div className="mt-1 rounded-2xl border border-slate-200 bg-slate-50/60 p-3.5 dark:border-white/10 dark:bg-white/[0.02]">
      {/* header: transport chip + action buttons */}
      <div className="flex flex-wrap items-center justify-between gap-2.5">
        <div className="flex min-w-0 items-center gap-2">
          <span
            aria-hidden="true"
            className="grid h-8 w-8 shrink-0 place-items-center rounded-xl text-white shadow-md"
            style={{ backgroundImage: grad("#6d5dfb", "#06b6d4") }}
          >
            <CatIcon name="activity" className="h-3.5 w-3.5" />
          </span>
          <div className="min-w-0">
            <p className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
              {t("notifFeedTitle")}
            </p>
            {transport ? (
              <p className="flex items-center gap-1.5 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                <CatIcon name={transport === "smtp" ? "zap" : "archive"} className="h-3 w-3 shrink-0" />
                {t("notifTransportLabel")}:{" "}
                <span className="font-extrabold text-brand-600 dark:text-brand-300">
                  {transport === "smtp" ? t("notifTransportSmtp") : t("notifTransportSpool")}
                </span>
              </p>
            ) : null}
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => testSend.mutate()}
            disabled={testSend.isPending || weeklySend.isPending}
            className="h-8 rounded-lg border-slate-200 px-3 text-[11px] font-extrabold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 disabled:opacity-60 dark:border-white/10 dark:text-slate-300"
          >
            <CatIcon name="flask" className="h-3.5 w-3.5" />
            {testSend.isPending ? "…" : t("notifTestBtn")}
          </Button>
          <Button
            type="button"
            size="sm"
            onClick={() => weeklySend.mutate()}
            disabled={testSend.isPending || weeklySend.isPending}
            className="h-8 rounded-lg bg-linear-to-l from-brand-600 to-cyan-500 px-3 text-[11px] font-extrabold text-white shadow-md shadow-brand-500/25 transition hover:brightness-110 disabled:opacity-60"
          >
            <CatIcon name="chart-pie" className="h-3.5 w-3.5" />
            {weeklySend.isPending ? "…" : t("notifWeeklyBtn")}
          </Button>
        </div>
      </div>

      {/* the dispatch log */}
      <div className="mt-3">
        {feed.isLoading ? (
          <div className="space-y-2">
            {[0, 1, 2].map((i) => (
              <Skeleton key={i} className="h-11 w-full rounded-xl" />
            ))}
          </div>
        ) : rows.length === 0 ? (
          <p className="flex items-center gap-2 rounded-xl border border-dashed border-slate-200 px-3.5 py-3 text-[11.5px] font-semibold text-slate-400 dark:border-white/10 dark:text-slate-500">
            <CatIcon name="inbox" className="h-3.5 w-3.5 shrink-0" />
            {t("notifEmpty")}
          </p>
        ) : (
          <ul className="max-h-72 space-y-1.5 overflow-y-auto pe-1" role="list">
            {rows.map((row) => {
              const meta = KIND_META[row.kind] ?? KIND_META.event;
              return (
                <li
                  key={row.id}
                  className="flex items-center gap-2.5 rounded-xl border border-slate-200 bg-white px-3 py-2 dark:border-white/[0.07] dark:bg-white/[0.02]"
                >
                  <span
                    aria-hidden="true"
                    className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-white"
                    style={{ backgroundImage: grad(meta.c1, meta.c2) }}
                  >
                    <CatIcon name={meta.icon} className="h-3 w-3" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12px] font-bold text-slate-700 dark:text-slate-200">
                      {row.title}
                    </p>
                    <p className="truncate text-[10px] font-semibold text-slate-400 dark:text-slate-500" dir="ltr">
                      {row.recipient}
                    </p>
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-0.5">
                    <span
                      className={cn(
                        "rounded-full px-2 py-px text-[9.5px] font-extrabold",
                        row.delivered
                          ? "bg-emerald-500/10 text-emerald-600 dark:bg-emerald-400/15 dark:text-emerald-300"
                          : "bg-rose-500/10 text-rose-600 dark:bg-rose-400/15 dark:text-rose-300"
                      )}
                    >
                      {row.delivered ? t("notifDelivered") : t("notifFailed")}
                    </span>
                    <span className="text-[9.5px] font-semibold text-slate-400 dark:text-slate-500">
                      {relativeTime(row.sentAt, lang)}
                    </span>
                  </div>
                  <span className="hidden shrink-0 rounded-full bg-slate-500/10 px-2 py-px text-[9.5px] font-extrabold text-slate-500 sm:inline dark:bg-white/10 dark:text-slate-400">
                    {t(meta.key)}
                  </span>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
