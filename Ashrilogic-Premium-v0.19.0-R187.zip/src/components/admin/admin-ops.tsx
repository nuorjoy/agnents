"use client";

/**
 * Ashrilogic — admin OPERATIONS console (ROUND 114).
 *
 * The queryable face of GET /api/admin/ops (added in the v0.15 hardening
 * QA round): a live snapshot of the hardened subsystems' state so the
 * platform operator sees audit-chain integrity, idempotency-guard
 * retention, scheduler leases, backup-cache efficiency, rate-limit volume,
 * argon2 backpressure depth, email-confirmation backlog and webhook
 * delivery posture WITHOUT shell access.
 *
 *  - super-admin ONLY by API contract; a moderator session gets the
 *    premium lock note instead of the console,
 *  - manual refresh + 30s auto-refresh (the snapshot is point-in-time),
 *  - purely additive — no existing admin surface was touched.
 */

import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { useT } from "@/lib/i18n";
import { fetchAdminOps, fetchStorageGcPlan, runStorageGc, type StorageGcPlanDTO } from "@/lib/api-client";
import { useAdminAuth } from "@/lib/admin-auth";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { DashCard, ViewHeading, relativeTime } from "@/components/dashboard/dash-shared";

/* ---------------------------------------------------- helpers ----- */

/** One labeled metric row inside a subsystem card. */
function MetricRow({
  label,
  value,
  tone = "neutral",
  icon,
}: {
  label: string;
  value: string;
  tone?: "neutral" | "good" | "warn" | "bad";
  icon?: string;
}) {
  return (
    <li className="flex items-center justify-between gap-3 py-1.5">
      <span className="flex min-w-0 items-center gap-1.5 text-[11.5px] font-bold text-slate-500 dark:text-slate-400">
        {icon ? <CatIcon name={icon} className="h-3.5 w-3.5 shrink-0 text-slate-400" /> : null}
        <span className="truncate">{label}</span>
      </span>
      <span
        dir="ltr"
        className={cn(
          "shrink-0 rounded-lg px-2 py-0.5 font-mono text-[12px] font-extrabold tabular-nums",
          tone === "good" && "bg-emerald-500/10 text-emerald-600 dark:text-emerald-300",
          tone === "warn" && "bg-amber-500/10 text-amber-600 dark:text-amber-300",
          tone === "bad" && "bg-rose-500/10 text-rose-600 dark:text-rose-300",
          tone === "neutral" && "bg-slate-500/10 text-slate-700 dark:bg-white/[0.06] dark:text-slate-200"
        )}
      >
        {value}
      </span>
    </li>
  );
}

/** The subsystem card header — gradient icon tile + title. */
function SubsystemCard({
  title,
  icon,
  c1,
  c2,
  children,
  className,
}: {
  title: string;
  icon: string;
  c1: string;
  c2: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <DashCard className={className}>
      <header className="mb-3 flex items-center gap-2.5">
        <span
          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
          style={{ backgroundImage: grad(c1, c2) }}
          aria-hidden="true"
        >
          <CatIcon name={icon} className="h-4 w-4" />
        </span>
        <h2 className="font-display text-[13.5px] font-extrabold text-slate-900 dark:text-white">
          {title}
        </h2>
      </header>
      {children}
    </DashCard>
  );
}

/* --------------------------------------------- ROUND 117 — storage ----- */

function fmtBytes(bytes: number): string {
  if (bytes >= 1024 * 1024 * 1024) return `${fmtNum(Math.round((bytes / (1024 * 1024 * 1024)) * 10) / 10)} GB`;
  if (bytes >= 1024 * 1024) return `${fmtNum(Math.round((bytes / (1024 * 1024)) * 10) / 10)} MB`;
  if (bytes >= 1024) return `${fmtNum(Math.round((bytes / 1024) * 10) / 10)} KB`;
  return `${fmtNum(bytes)} B`;
}

/**
 * ROUND 117 — the storage reclamation card: the dry-run plan of the
 * unreferenced-image GC (asset rows whose references are gone past the
 * grace window + the orphan half) with the operator's on-demand RUN
 * button (lease-protected sweep, admin.storageGc-audited). The targeted
 * release hooks after every replace/clear/purge remain the primary path;
 * this is the backstop window the operator controls.
 */
function StorageGcCard() {
  const { t } = useT();
  const queryClient = useQueryClient();

  const planQuery = useQuery({
    queryKey: ["admin-storage-gc-plan"],
    queryFn: () => fetchStorageGcPlan(24),
    /* heavier than the ops snapshot (a full reference scan) — manual
       refresh only, never on the 30s ops cadence */
    refetchInterval: false,
    staleTime: 0,
    retry: 0,
  });

  const [confirmOpen, setConfirmOpen] = useState(false);
  const runMutation = useMutation({
    mutationFn: () => runStorageGc(24),
    onSuccess: (data) => {
      setConfirmOpen(false);
      if (data.leaseHeld) {
        toast.info(t("opsStorageLeaseHeld"));
      } else if (!data.ran || !data.result) {
        toast.info(t("opsStorageNoop"));
      } else {
        const r = data.result;
        const freed = r.reclaimedBytes + r.orphan.reclaimedBytes;
        toast.success(
          t("opsStorageDone", {
            n: fmtNum(r.deletedRows + r.orphan.deletedOrphans + r.orphan.deletedTemp),
            b: fmtBytes(freed),
          })
        );
      }
      void queryClient.invalidateQueries({ queryKey: ["admin-storage-gc-plan"] });
    },
    onError: () => {
      setConfirmOpen(false);
      toast.error(t("opsStorageFailed"));
    },
  });

  const plan: StorageGcPlanDTO | undefined = planQuery.data;
  const busy = planQuery.isFetching || runMutation.isPending;

  return (
    <SubsystemCard title={t("opsStorageTitle")} icon="hard-drive" c1="#ec4899" c2="#db2777">
      {planQuery.isPending ? (
        <div className="grid place-items-center py-6">
          <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin text-brand-400" />
        </div>
      ) : planQuery.isError || !plan ? (
        <div className="space-y-3 py-2 text-center">
          <p className="text-[11.5px] font-bold text-slate-400 dark:text-slate-500">{t("opsStorageLoadFailed")}</p>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => void planQuery.refetch()}
            className="h-8 gap-2 rounded-xl text-[11.5px] font-bold"
          >
            <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
            {t("retryText")}
          </Button>
        </div>
      ) : (
        <>
          <ul className="divide-y divide-slate-100 dark:divide-white/[0.06]">
            <MetricRow label={t("opsStorageReferenced")} value={fmtNum(plan.referenced)} tone="good" icon="image" />
            <MetricRow
              label={t("opsStorageUnref")}
              value={fmtNum(plan.unreferencedCount)}
              tone={plan.unreferencedCount > 0 ? "warn" : "neutral"}
              icon="trash-2"
            />
            <MetricRow
              label={t("opsStorageReclaimable")}
              value={fmtBytes(plan.reclaimableBytes)}
              tone={plan.reclaimableBytes > 0 ? "warn" : "good"}
              icon="hard-drive"
            />
            <MetricRow label={t("opsStorageOrphans")} value={fmtNum(plan.orphanPlan.orphans + plan.orphanPlan.tempStale)} />
            <MetricRow label={t("opsStorageTotal")} value={fmtBytes(plan.imagesBytes)} />
          </ul>
          <p className="mt-2.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("opsStorageNote")}
          </p>
        </>
      )}

      <div className="mt-3 flex items-center gap-2">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() =>
            planQuery
              .refetch()
              .then(() => toast.success(t("opsRefreshed")))
              .catch(() => toast.error(t("opsRefreshFailed")))
          }
          disabled={busy}
          className="h-8 flex-1 gap-2 rounded-xl text-[11.5px] font-bold"
        >
          <CatIcon name="refresh-cw" className={cn("h-3.5 w-3.5", planQuery.isFetching && "animate-spin")} />
          {t("refrTip")}
        </Button>
        <Button
          type="button"
          size="sm"
          onClick={() => setConfirmOpen(true)}
          disabled={busy}
          className="h-8 flex-1 gap-2 rounded-xl bg-linear-to-l from-rose-600 via-pink-500 to-fuchsia-500 text-[11.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-70"
        >
          <CatIcon
            name={runMutation.isPending ? "refresh-cw" : "trash-2"}
            className={cn("h-3.5 w-3.5", runMutation.isPending && "animate-spin")}
          />
          {t("opsStorageRun")}
        </Button>
      </div>

      <AlertDialog open={confirmOpen} onOpenChange={(o) => !runMutation.isPending && setConfirmOpen(o)}>
        <AlertDialogContent dir="auto">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-start font-display text-[15px] font-extrabold">
              {t("opsStorageRunTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-start text-[12px] leading-relaxed">
              {t("opsStorageRunDesc")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-9 rounded-xl text-[12px] font-bold" disabled={runMutation.isPending}>
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                runMutation.mutate();
              }}
              className="h-9 rounded-xl bg-linear-to-l from-rose-600 via-pink-500 to-fuchsia-500 text-[12px] font-extrabold text-white"
            >
              {runMutation.isPending ? (
                <CatIcon name="refresh-cw" className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <CatIcon name="trash-2" className="h-3.5 w-3.5" />
              )}
              {t("opsStorageRunConfirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </SubsystemCard>
  );
}

/* ------------------------------------------------------ the view ----- */

export function AdminOps() {
  const { t, lang } = useT();
  const { user } = useAdminAuth();
  const isSuper = user?.role === "super";

  const opsQuery = useQuery({
    queryKey: ["admin-ops"],
    queryFn: fetchAdminOps,
    enabled: isSuper,
    /* point-in-time snapshot: auto-refresh every 30s while mounted */
    refetchInterval: 30_000,
    staleTime: 15_000,
    retry: 0,
  });

  /* Non-super moderators: the API is super-only by contract — render the
     premium lock note instead of a failing console. */
  if (!isSuper) {
    return (
      <div className="space-y-5">
        <ViewHeading title={t("adminOps")} desc={t("opsDesc")} />
        <div className="mx-auto max-w-xl rounded-3xl border-2 border-dashed border-slate-200 bg-white/70 p-10 text-center dark:border-white/10 dark:bg-white/[0.02]">
          <span
            className="mx-auto grid h-14 w-14 place-items-center rounded-2xl text-white shadow-xl"
            style={{ backgroundImage: grad("#f43f5e", "#e11d48"), boxShadow: "0 12px 30px -10px #e11d4866" }}
          >
            <CatIcon name="lock" className="h-7 w-7" />
          </span>
          <h3 className="mt-4 font-display text-[17px] font-extrabold text-slate-900 dark:text-white">
            {t("opsSuperOnlyTitle")}
          </h3>
          <p className="mx-auto mt-2 max-w-md text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
            {t("opsSuperOnlyDesc")}
          </p>
        </div>
      </div>
    );
  }

  const snap = opsQuery.data;

  return (
    <div className="space-y-5">
      <ViewHeading title={t("adminOps")} desc={t("opsDesc")} />

      {/* provider banner — the active database runtime + snapshot age */}
      <div className="glass-card card-in flex flex-wrap items-center gap-3 rounded-2xl p-4">
        <span
          className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
          style={{
            backgroundImage: grad("#0ea5e9", "#6d5dfb"),
          }}
          aria-hidden="true"
        >
          <CatIcon name="database" className="h-5 w-5" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[13px] font-extrabold text-slate-900 dark:text-white">
            {t("opsProviderPg")}
          </p>
          <p className="mt-0.5 text-[11px] font-semibold text-slate-500 dark:text-slate-400">
            {snap
              ? t("opsSnapshotAt", { when: relativeTime(snap.generatedAt, lang) })
              : t("opsSnapshotLoading")}
          </p>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <span className="hidden items-center gap-1.5 rounded-full border border-emerald-300/60 bg-emerald-500/10 px-3 py-1.5 text-[10.5px] font-extrabold text-emerald-600 sm:inline-flex dark:border-emerald-500/40 dark:text-emerald-300">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-500" aria-hidden="true" />
            {t("opsAutoRefresh")}
          </span>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() =>
              opsQuery
                .refetch()
                .then(() => toast.success(t("opsRefreshed")))
                .catch(() => toast.error(t("opsRefreshFailed")))
            }
            disabled={opsQuery.isFetching}
            className="h-9 gap-2 rounded-xl text-[12px] font-bold"
          >
            <CatIcon
              name="refresh-cw"
              className={cn("h-3.5 w-3.5", opsQuery.isFetching && "animate-spin")}
            />
            {t("refrTip")}
          </Button>
        </div>
      </div>

      {opsQuery.isPending ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-56 w-full rounded-3xl" />
          ))}
        </div>
      ) : opsQuery.isError || !snap ? (
        <div className="rounded-3xl border border-rose-300/60 bg-rose-500/10 p-8 text-center dark:border-rose-500/40 dark:bg-rose-500/10">
          <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-rose-500/15 text-rose-500">
            <CatIcon name="triangle-alert" className="h-6 w-6" />
          </div>
          <h4 className="mt-3 font-display text-[14px] font-extrabold text-slate-900 dark:text-white">
            {t("opsLoadFailed")}
          </h4>
          <p className="mx-auto mt-1 max-w-sm text-[12px] leading-relaxed text-slate-500 dark:text-slate-400">
            {opsQuery.error instanceof Error ? opsQuery.error.message : t("errorText")}
          </p>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => void opsQuery.refetch()}
            className="mt-4 h-9 gap-2 rounded-xl text-[12px] font-bold"
          >
            <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
            {t("retryText")}
          </Button>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {/* audit chain integrity */}
          <SubsystemCard title={t("opsAuditTitle")} icon="scroll-text" c1="#6d5dfb" c2="#8b5cf6">
            <ul className="divide-y divide-slate-100 dark:divide-white/[0.06]">
              <MetricRow label={t("opsAuditRows")} value={fmtNum(snap.audit.totalRows)} />
              <MetricRow
                label={t("opsAuditChained")}
                value={fmtNum(snap.audit.chainedRows)}
                tone={snap.audit.chainedRows === snap.audit.totalRows ? "good" : "warn"}
              />
              <MetricRow
                label={t("opsAuditAnchor")}
                value={snap.audit.anchored ? t("opsAnchorSet") : t("opsAnchorOpen")}
                tone={snap.audit.anchored ? "good" : "neutral"}
              />
              {/* ROUND 121 — chain health at a glance: the unanchored tail
               * (rows written since the anchor row — the stretch that
               * exists only in this database until the next off-host
               * journal export) and the anchor's age. */}
              <MetricRow
                label={t("opsAuditSinceAnchor")}
                value={snap.audit.rowsSinceAnchor != null ? fmtNum(snap.audit.rowsSinceAnchor) : "—"}
                tone={
                  snap.audit.rowsSinceAnchor != null && snap.audit.rowsSinceAnchor > 10_000
                    ? "warn"
                    : "neutral"
                }
              />
              <MetricRow
                label={t("opsAnchorAge")}
                value={
                  snap.audit.anchorAgeHours != null
                    ? t("opsHours", { n: fmtNum(snap.audit.anchorAgeHours) })
                    : "—"
                }
              />
              {/* ROUND 122 — the off-host journal copy path's freshness:
               * how long since the anchor journal (the export/safety-net
               * artifact an operator copies to WORM storage) was last
               * written. A stale journal on a live chain = export due. */}
              <MetricRow
                label={t("opsJournalFreshness")}
                value={
                  snap.audit.anchorJournal.exists && snap.audit.anchorJournal.lastWriteAgeHours != null
                    ? t("opsHours", { n: fmtNum(snap.audit.anchorJournal.lastWriteAgeHours) })
                    : "—"
                }
                tone={
                  snap.audit.anchorJournal.exists && snap.audit.anchorJournal.lastWriteAgeHours != null
                    ? snap.audit.anchorJournal.lastWriteAgeHours > 72
                      ? "warn"
                      : "good"
                    : "neutral"
                }
              />
            </ul>
            <p className="mt-2.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {t("opsAuditNote")}
            </p>
          </SubsystemCard>

          {/* order idempotency guards */}
          <SubsystemCard title={t("opsIdemTitle")} icon="fingerprint" c1="#0ea5e9" c2="#0284c7">
            <ul className="divide-y divide-slate-100 dark:divide-white/[0.06]">
              <MetricRow label={t("opsIdemCompleted")} value={fmtNum(snap.idempotency.completedGuards)} />
              <MetricRow
                label={t("opsIdemInFlight")}
                value={fmtNum(snap.idempotency.inFlightGuards)}
                tone={snap.idempotency.inFlightGuards > 0 ? "warn" : "good"}
              />
              <MetricRow
                label={t("opsIdemOldest")}
                value={
                  snap.idempotency.oldestCompletedAgeHours != null
                    ? t("opsHours", { n: fmtNum(snap.idempotency.oldestCompletedAgeHours) })
                    : "—"
                }
              />
            </ul>
            <p className="mt-2.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {t("opsIdemNote")}
            </p>
          </SubsystemCard>

          {/* scheduler leases (multi-instance safety) */}
          <SubsystemCard title={t("opsLeasesTitle")} icon="clock" c1="#f59e0b" c2="#d97706">
            {snap.schedulerLeases.length === 0 ? (
              <p className="rounded-xl border border-dashed border-slate-200 px-3 py-4 text-center text-[11.5px] font-bold text-slate-400 dark:border-white/10 dark:text-slate-500">
                {t("opsLeasesIdle")}
              </p>
            ) : (
              <ul className="space-y-1.5">
                {snap.schedulerLeases.map((lease) => (
                  <li
                    key={`${lease.job}-${lease.holderPid}`}
                    className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-200 bg-slate-50/70 px-2.5 py-2 dark:border-white/10 dark:bg-white/[0.03]"
                  >
                    <span className="flex min-w-0 items-center gap-1.5">
                      <CatIcon name="activity" className="h-3.5 w-3.5 shrink-0 text-amber-500" />
                      <code dir="ltr" className="truncate font-mono text-[11px] font-extrabold text-slate-700 dark:text-slate-200">
                        {lease.job}
                      </code>
                    </span>
                    <span dir="ltr" className="flex shrink-0 items-center gap-2 font-mono text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
                      <span title={t("opsLeaseHolder")}>pid {lease.holderPid}</span>
                      <span className="rounded bg-amber-500/10 px-1.5 py-0.5 text-amber-600 dark:text-amber-300">
                        TTL {Math.max(0, Math.round(lease.expiresInMillis / 1000))}s
                      </span>
                    </span>
                  </li>
                ))}
              </ul>
            )}
            <p className="mt-2.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {t("opsLeasesNote")}
            </p>
          </SubsystemCard>

          {/* backup cache */}
          <SubsystemCard title={t("opsBackupTitle")} icon="database" c1="#06b6d4" c2="#0891b2">
            <ul className="divide-y divide-slate-100 dark:divide-white/[0.06]">
              <MetricRow label={t("opsBackupEntries")} value={fmtNum(snap.backupCache.entries)} />
              <MetricRow label={t("opsBackupBytes")} value={fmtNum(Math.round(snap.backupCache.bytes / 1024)) + " KB"} />
              <MetricRow
                label={t("opsBackupHits")}
                value={`${fmtNum(snap.backupCache.hits)} / ${fmtNum(snap.backupCache.misses)}`}
                tone={snap.backupCache.misses === 0 || snap.backupCache.hits >= snap.backupCache.misses ? "good" : "warn"}
              />
              <MetricRow label={t("opsBackupBuilds")} value={fmtNum(snap.backupCache.builds)} />
            </ul>
            <p className="mt-2.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {t("opsBackupNote")}
            </p>
          </SubsystemCard>

          {/* rate limiting + auth backpressure */}
          <SubsystemCard title={t("opsGuardTitle")} icon="shield-check" c1="#10b981" c2="#059669">
            <ul className="divide-y divide-slate-100 dark:divide-white/[0.06]">
              <MetricRow label={t("opsRateRows")} value={fmtNum(snap.rateLimit.windowRows)} />
              <MetricRow
                label={t("opsAuthDepth")}
                value={`${fmtNum(snap.authWork.windowDepth)} / 20`}
                tone={snap.authWork.windowDepth >= 20 ? "bad" : snap.authWork.windowDepth >= 12 ? "warn" : "good"}
              />
              <MetricRow
                label={t("opsEmailPending")}
                value={fmtNum(snap.emailQueue.pendingDeliveryConfirmations)}
                tone={snap.emailQueue.pendingDeliveryConfirmations > 10 ? "warn" : "neutral"}
              />
            </ul>
            <p className="mt-2.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {t("opsGuardNote")}
            </p>
          </SubsystemCard>

          {/* webhook delivery posture */}
          <SubsystemCard title={t("opsWebhooksTitle")} icon="webhook" c1="#8b5cf6" c2="#7c3aed">
            <ul className="divide-y divide-slate-100 dark:divide-white/[0.06]">
              <MetricRow
                label={t("opsWhEndpoints")}
                value={`${fmtNum(snap.webhooks.activeEndpoints)} / ${fmtNum(snap.webhooks.endpoints)}`}
              />
              <MetricRow
                label={t("opsWhSucceeded")}
                value={fmtNum(snap.webhooks.succeededDeliveries)}
                tone="good"
              />
              <MetricRow
                label={t("opsWhPending")}
                value={fmtNum(snap.webhooks.pendingDeliveries)}
                tone={snap.webhooks.pendingDeliveries > 0 ? "warn" : "neutral"}
              />
              <MetricRow
                label={t("opsWhExhausted")}
                value={fmtNum(snap.webhooks.exhaustedDeliveries)}
                tone={snap.webhooks.exhaustedDeliveries > 0 ? "bad" : "good"}
              />
              {/* ROUND 116 — manual redelivery usage (owner recovery action) */}
              <MetricRow
                label={t("opsWhManualRedeliveries")}
                value={fmtNum(snap.webhooks.manualRedeliveries)}
                tone={snap.webhooks.manualRedeliveries > 0 ? "warn" : "neutral"}
              />
            </ul>
            <p className="mt-2.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {t("opsWebhooksNote")}
            </p>
          </SubsystemCard>

          {/* ROUND 117 — storage reclamation (unreferenced assets + orphans) */}
          <StorageGcCard />
        </div>
      )}
    </div>
  );
}
