"use client";

/**
 * Ashrilogic — admin support desk view (الدعم).
 *
 * Inbox-style ticket management: KPI cards (open / pending / resolved /
 * urgent), quick stats (avg. first-response time + category breakdown),
 * status pills + debounced search over an inbox list (priority start-stripe,
 * category tile, requester chip, status/priority badges), and a detail Sheet
 * with reply composer, status/priority quick-switches and delete confirm.
 *
 * Round 28: bulk triage — checkbox selection (select-all with indeterminate
 * state) over the inbox, a floating action toolbar (mark pending / resolved /
 * closed, priority menu, bulk delete with a count-aware confirm dialog) that
 * mirrors the newsletter moderation pattern.
 */
import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  bulkDeleteTickets,
  bulkUpdateTickets,
  deleteTicket,
  fetchTickets,
  updateTicket,
} from "@/lib/api-client";
import { useAdminCanManage, useAdminCanTriage } from "@/lib/admin-auth";
import { useT, type I18nKey } from "@/lib/i18n";
import type { SupportTicketDTO, TicketCategory, TicketPriority, TicketStatus } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, initial, labelTrack, normalizeSearch } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { IconTile, ViewHeading, fullDate, relativeTime } from "@/components/dashboard/dash-shared";
import { KpiCard } from "@/components/shared/kpi-card";

/* ---------------- visual maps ---------------- */

const CATEGORY_META: Record<TicketCategory, { icon: string; c1: string; c2: string; label: I18nKey }> = {
  technical: { icon: "headset", c1: "#06b6d4", c2: "#0891b2", label: "supCatTechnical" },
  billing: { icon: "receipt", c1: "#10b981", c2: "#059669", label: "supCatBilling" },
  general: { icon: "message-square", c1: "#6d5dfb", c2: "#d946ef", label: "supCatGeneral" },
  feature: { icon: "lightbulb", c1: "#d946ef", c2: "#c026d3", label: "supCatFeature" },
};

const CATEGORY_BADGE: Record<TicketCategory, string> = {
  technical: "bg-cyan-500/10 text-cyan-700 dark:text-cyan-300",
  billing: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
  general: "bg-brand-500/10 text-brand-600 dark:text-brand-300",
  feature: "bg-fuchsia-500/10 text-fuchsia-600 dark:text-fuchsia-400",
};

const STATUS_KEYS: Record<TicketStatus, I18nKey> = {
  open: "supStatusOpen",
  pending: "supStatusPending",
  resolved: "supStatusResolved",
  closed: "supStatusClosed",
};

const STATUS_BADGE: Record<TicketStatus, string> = {
  open: "bg-rose-500/10 text-rose-600 dark:text-rose-400",
  pending: "bg-amber-500/10 text-amber-600 dark:text-amber-400",
  resolved: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
  closed: "bg-slate-500/10 text-slate-600 dark:text-slate-300",
};

/** Gradient used for the active status pill (and matching accents). */
const STATUS_GRADIENT: Record<TicketStatus, { c1: string; c2: string }> = {
  open: { c1: "#f43f5e", c2: "#e11d48" },
  pending: { c1: "#f59e0b", c2: "#d97706" },
  resolved: { c1: "#10b981", c2: "#059669" },
  closed: { c1: "#64748b", c2: "#475569" },
};

const PRIORITY_KEYS: Record<TicketPriority, I18nKey> = {
  low: "supPrioLow",
  medium: "supPrioMedium",
  high: "supPrioHigh",
  urgent: "supPrioUrgent",
};

const PRIORITY_BADGE: Record<TicketPriority, string> = {
  low: "bg-slate-500/10 text-slate-600 dark:text-slate-300",
  medium: "bg-amber-500/10 text-amber-600 dark:text-amber-400",
  high: "bg-orange-500/10 text-orange-600 dark:text-orange-400",
  urgent: "bg-rose-500/10 text-rose-600 dark:text-rose-400",
};

/** Priority stripe / dot / active-pill colors. */
const PRIORITY_META: Record<TicketPriority, { c1: string; c2: string }> = {
  low: { c1: "#94a3b8", c2: "#64748b" },
  medium: { c1: "#f59e0b", c2: "#d97706" },
  high: { c1: "#f97316", c2: "#e11d48" },
  urgent: { c1: "#f43f5e", c2: "#be123c" },
};

const STATUSES: TicketStatus[] = ["open", "pending", "resolved", "closed"];
const PRIORITIES: TicketPriority[] = ["low", "medium", "high", "urgent"];
const CATEGORIES: TicketCategory[] = ["technical", "billing", "general", "feature"];

type StatusFilter = "all" | TicketStatus;

/* ---------------- source badge (public / instance) ---------------- */

/**
 * Where the ticket came from: public landing form (globe), subscriber
 * dashboard (server, always has instanceId) or plain internal (nothing).
 */
function SourceBadge({ ticket }: { ticket: SupportTicketDTO }) {
  const { t } = useT();
  if (ticket.source === "public") {
    return (
      <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-sky-300/70 bg-sky-100 px-2 py-0.5 text-[11px] font-extrabold text-sky-700 dark:border-sky-500/30 dark:bg-sky-500/15 dark:text-sky-300">
        <CatIcon name="globe" className="h-[9px] w-[9px]" />
        {t("supSourcePublic")}
      </span>
    );
  }
  if (ticket.source === "instance" || ticket.instanceId !== null) {
    return (
      <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-brand-300/70 bg-brand-100 px-2 py-0.5 text-[11px] font-extrabold text-brand-700 dark:border-brand-500/30 dark:bg-brand-500/15 dark:text-brand-300">
        <CatIcon name="server" className="h-[9px] w-[9px]" />
        {t("supSourceInstance")}
      </span>
    );
  }
  return null;
}


/* ---------------- KPI card ---------------- */
/* Consolidated into src/components/shared/kpi-card.tsx. */

/* ---------------- inbox row ---------------- */

function TicketRow({
  ticket,
  selectable,
  onOpen,
  selected,
  onToggle,
}: {
  ticket: SupportTicketDTO;
  /** round 29 — selection is only offered to roles that can triage */
  selectable: boolean;
  onOpen: (id: string) => void;
  selected: boolean;
  onToggle: (id: string) => void;
}) {
  const { t, lang } = useT();
  const cat = CATEGORY_META[ticket.category];
  const prio = PRIORITY_META[ticket.priority];

  return (
    <li className={cn("relative", selected && "bg-brand-500/[0.045] dark:bg-brand-500/[0.07]")}>
      {/* start-edge priority stripe */}
      <span
        className="pointer-events-none absolute inset-y-2 start-0 w-[3px] rounded-full"
        style={{ backgroundImage: grad(prio.c1, prio.c2, 180) }}
        aria-hidden="true"
      />
      <div className="flex w-full items-start gap-1">
        {/* round-28 bulk selection checkbox (outside the row button) */}
        {selectable ? (
          <div className="flex shrink-0 items-center pt-4 ps-3">
            <Checkbox
              checked={selected}
              onCheckedChange={() => onToggle(ticket.id)}
              aria-label={`${t("supBulkSelect")} — ${ticket.subject}`}
              className="data-[state=checked]:border-brand-500 data-[state=checked]:bg-brand-500"
            />
          </div>
        ) : null}
        <button
          type="button"
          onClick={() => onOpen(ticket.id)}
          aria-label={`${t("supDetailView")} — ${ticket.subject}`}
          className="flex min-w-0 flex-1 cursor-pointer items-start gap-3 rounded-2xl p-3.5 ps-2 text-start transition hover:bg-slate-50 focus-visible:bg-slate-50 dark:hover:bg-white/[0.04] dark:focus-visible:bg-white/[0.04]"
        >
        <IconTile icon={cat.icon} c1={cat.c1} c2={cat.c2} size="sm" className="mt-1" />

        {/* subject + preview + requester */}
        <div className="min-w-0 flex-1">
          <p className="truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
            {ticket.subject}
          </p>
          <p className="mt-0.5 truncate text-[11.5px] font-medium text-slate-400 dark:text-slate-500">
            {ticket.message}
          </p>
          <div className="mt-2 flex min-w-0 items-center gap-2">
            <span
              className="grid h-6 w-6 shrink-0 place-items-center rounded-full text-[11px] font-extrabold text-white"
              style={{ backgroundImage: grad(prio.c1, prio.c2) }}
              aria-hidden="true"
            >
              {initial(ticket.requesterName)}
            </span>
            <span className="truncate text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
              {ticket.requesterName}
            </span>
            <span
              dir="ltr"
              className="hidden truncate text-start text-[10px] font-semibold text-slate-400 dark:text-slate-500 sm:inline"
            >
              {ticket.requesterEmail}
            </span>
            <SourceBadge ticket={ticket} />
          </div>
        </div>

        {/* status / priority / time */}
        <div className="flex shrink-0 flex-col items-end gap-1.5">
          <Badge
            className={cn("rounded-full px-2.5 py-0.5 text-[10.5px] font-extrabold", STATUS_BADGE[ticket.status])}
          >
            {t(STATUS_KEYS[ticket.status])}
          </Badge>
          <Badge
            className={cn(
              "gap-1.5 rounded-full px-2.5 py-0.5 text-[10.5px] font-extrabold",
              PRIORITY_BADGE[ticket.priority]
            )}
          >
            <span
              className="h-1.5 w-1.5 rounded-full"
              style={{ backgroundColor: prio.c1 }}
              aria-hidden="true"
            />
            {t(PRIORITY_KEYS[ticket.priority])}
          </Badge>
          <p className="whitespace-nowrap text-[10px] font-semibold text-slate-400 dark:text-slate-500">
            {relativeTime(ticket.updatedAt, lang)}
          </p>
        </div>
        </button>
      </div>
    </li>
  );
}

/* ---------------- ticket detail sheet body ---------------- */

interface TicketPatch {
  status?: TicketStatus;
  priority?: TicketPriority;
  reply?: string;
}

function TicketDetailBody({
  ticket,
  canManage,
  canTriage,
  onDelete,
}: {
  ticket: SupportTicketDTO;
  /** round 29 — delete is super/admin; updates are super/admin/moderator */
  canManage: boolean;
  canTriage: boolean;
  onDelete: (id: string) => void;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const [replyText, setReplyText] = useState(ticket.reply ?? "");

  const patch = useMutation({
    mutationFn: (payload: TicketPatch) => updateTicket(ticket.id, payload),
    onSuccess: (_data, payload) => {
      toast.success(
        t(payload.status !== undefined || payload.priority !== undefined ? "supStatusUpdated" : "supReplySent")
      );
      queryClient.invalidateQueries({ queryKey: ["tickets"] });
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  const cat = CATEGORY_META[ticket.category];

  return (
    <div className="space-y-4 p-5">
      {/* requester */}
      <section className="flex items-center gap-3 rounded-2xl border border-slate-200/80 bg-white/60 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
        <span
          className="grid h-10 w-10 shrink-0 place-items-center rounded-xl font-display text-[14px] font-extrabold text-white"
          style={{ backgroundImage: grad(cat.c1, cat.c2) }}
          aria-hidden="true"
        >
          {initial(ticket.requesterName)}
        </span>
        <div className="min-w-0">
          <p className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            {t("supFrom")}
          </p>
          <p className="truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
            {ticket.requesterName}
          </p>
          <p
            dir="ltr"
            className="truncate text-start text-[11.5px] font-semibold text-slate-500 dark:text-slate-400"
          >
            {ticket.requesterEmail}
          </p>
        </div>
        <div className="ms-auto flex flex-col items-end gap-1.5">
          <SourceBadge ticket={ticket} />
        </div>
      </section>

      {/* original message */}
      <section className="rounded-2xl bg-slate-50 p-4 dark:bg-white/[0.04]">
        <p className="whitespace-pre-wrap break-words text-[13px] font-medium leading-relaxed text-slate-700 dark:text-slate-200">
          {ticket.message}
        </p>
      </section>

      {/* reply composer */}
      {canTriage ? (
        <section className="space-y-2.5">
          <div className="flex items-center justify-between gap-2">
            <h3 className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              {t("supReply")}
            </h3>
            {ticket.reply === null ? (
              <span className="inline-flex items-center gap-1 text-[10.5px] font-bold text-amber-600 dark:text-amber-400">
                <CatIcon name="clock" className="h-3 w-3" />
                {t("supNoReply")}
              </span>
            ) : null}
          </div>
          <Textarea
            value={replyText}
            onChange={(e) => setReplyText(e.target.value)}
            rows={4}
            placeholder={t("supReplyPh")}
            aria-label={t("supReply")}
            className="min-h-[96px] rounded-xl border-slate-200 bg-slate-50/80 px-3.5 py-3 text-[13px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100"
          />
          <Button
            type="button"
            onClick={() => patch.mutate({ reply: replyText.trim() })}
            disabled={patch.isPending || replyText.trim().length === 0}
            className="h-10 w-full gap-2 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
          >
            {patch.isPending ? (
              <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
            ) : (
              <CatIcon name="telegram" className="h-4 w-4" />
            )}
            {t("supSendReply")}
          </Button>
        </section>
      ) : null}

      {/* status quick-switch */}
      {canTriage ? (
        <section className="space-y-2">
          <h3 className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            {t("supChangeStatus")}
          </h3>
          <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-4">
            {STATUSES.map((status) => {
              const active = ticket.status === status;
              const sc = STATUS_GRADIENT[status];
              return (
                <button
                  key={status}
                  type="button"
                  aria-pressed={active}
                  disabled={patch.isPending || active}
                  onClick={() => patch.mutate({ status })}
                  className={cn(
                    "inline-flex h-9 items-center justify-center rounded-xl px-3 text-[11.5px] font-extrabold transition",
                    active
                      ? "text-white shadow-lg"
                      : "border border-slate-200 bg-white/60 text-slate-500 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400 dark:hover:text-slate-200"
                  )}
                  style={active ? { backgroundImage: grad(sc.c1, sc.c2) } : undefined}
                >
                  {t(STATUS_KEYS[status])}
                </button>
              );
            })}
          </div>
        </section>
      ) : null}

      {/* priority quick-switch */}
      {canTriage ? (
        <section className="space-y-2">
          <h3 className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            {t("supChangePriority")}
          </h3>
          <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-4">
            {PRIORITIES.map((priority) => {
              const active = ticket.priority === priority;
              const pc = PRIORITY_META[priority];
              return (
                <button
                  key={priority}
                  type="button"
                  aria-pressed={active}
                  disabled={patch.isPending || active}
                  onClick={() => patch.mutate({ priority })}
                  className={cn(
                    "inline-flex h-8 items-center justify-center gap-1.5 rounded-xl px-2.5 text-[11px] font-extrabold transition",
                    active
                      ? "text-white shadow-md"
                      : "border border-slate-200 bg-white/60 text-slate-500 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400 dark:hover:text-slate-200"
                  )}
                  style={active ? { backgroundImage: grad(pc.c1, pc.c2) } : undefined}
                >
                  {!active ? (
                    <span
                      className="h-1.5 w-1.5 rounded-full"
                      style={{ backgroundColor: pc.c1 }}
                      aria-hidden="true"
                    />
                  ) : null}
                  {t(PRIORITY_KEYS[priority])}
                </button>
              );
            })}
          </div>
        </section>
      ) : null}

      {/* delete */}
      {canManage ? (
        <Button
          type="button"
          variant="outline"
          onClick={() => onDelete(ticket.id)}
          className="h-10 w-full gap-2 rounded-xl border-rose-200 text-[12.5px] font-bold text-rose-600 transition hover:border-rose-300 hover:bg-rose-50 dark:border-rose-500/30 dark:text-rose-400 dark:hover:bg-rose-500/10"
        >
          <CatIcon name="trash-2" className="h-4 w-4" />
          {t("supDeleteTitle")}
        </Button>
      ) : null}
    </div>
  );
}

/* ---------------- ticket detail sheet ---------------- */

function TicketDetailSheet({
  ticket,
  open,
  canManage,
  canTriage,
  onOpenChange,
  onDelete,
}: {
  ticket: SupportTicketDTO | null;
  open: boolean;
  /** round 29 — role gates forwarded to the detail body */
  canManage: boolean;
  canTriage: boolean;
  onOpenChange: (open: boolean) => void;
  onDelete: (id: string) => void;
}) {
  const { t, lang } = useT();
  const cat = ticket ? CATEGORY_META[ticket.category] : null;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side={lang === "ar" ? "left" : "right"}
        className="w-full gap-0 overflow-y-auto p-0 sm:max-w-lg"
      >
        {ticket && cat ? (
          <>
            <SheetHeader className="border-b border-slate-200/70 bg-slate-50/80 px-5 py-4 dark:border-white/10 dark:bg-white/[0.03]">
              <SheetTitle className="flex items-start gap-3">
                <IconTile icon={cat.icon} c1={cat.c1} c2={cat.c2} size="md" />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                    {ticket.subject}
                  </p>
                  <p className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                    <span className="whitespace-nowrap">
                      {t("supTicketNo")}{" "}
                      <span dir="ltr" className="font-mono uppercase tracking-wide">
                        {ticket.id.slice(0, 8).toUpperCase()}
                      </span>
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="whitespace-nowrap">
                      {t("supCreated")}: {fullDate(ticket.createdAt, lang)}
                    </span>
                  </p>
                </div>
              </SheetTitle>
              <div className="flex flex-wrap items-center gap-1.5">
                <Badge
                  className={cn("rounded-full px-2.5 py-0.5 text-[10.5px] font-extrabold", STATUS_BADGE[ticket.status])}
                >
                  {t(STATUS_KEYS[ticket.status])}
                </Badge>
                <Badge
                  className={cn(
                    "gap-1.5 rounded-full px-2.5 py-0.5 text-[10.5px] font-extrabold",
                    PRIORITY_BADGE[ticket.priority]
                  )}
                >
                  <span
                    className="h-1.5 w-1.5 rounded-full"
                    style={{ backgroundColor: PRIORITY_META[ticket.priority].c1 }}
                    aria-hidden="true"
                  />
                  {t(PRIORITY_KEYS[ticket.priority])}
                </Badge>
                <Badge
                  className={cn(
                    "gap-1.5 rounded-full px-2.5 py-0.5 text-[10.5px] font-extrabold",
                    CATEGORY_BADGE[ticket.category]
                  )}
                >
                  <CatIcon name={cat.icon} className="h-[10px] w-[10px]" />
                  {t(cat.label)}
                </Badge>
              </div>
              <SheetDescription className="sr-only">{t("supViewTitle")}</SheetDescription>
            </SheetHeader>

            <TicketDetailBody
              key={ticket.id}
              ticket={ticket}
              canManage={canManage}
              canTriage={canTriage}
              onDelete={onDelete}
            />
          </>
        ) : null}
      </SheetContent>
    </Sheet>
  );
}

/* ---------------- main view ---------------- */

export function AdminSupport() {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  /* round 29 — role gates mirroring the route guards: super/admin manage
     (delete), moderator keeps triage rights, viewer is read-only */
  const canManage = useAdminCanManage();
  const canTriage = useAdminCanTriage();

  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  const [detailId, setDetailId] = useState<string | null>(null);
  const [pendingDelete, setPendingDelete] = useState<string | null>(null);

  /* round 28 — bulk triage selection */
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [confirmBulkDelete, setConfirmBulkDelete] = useState(false);

  useEffect(() => {
    const h = window.setTimeout(() => setDebounced(normalizeSearch(search.trim())), 150);
    return () => window.clearTimeout(h);
  }, [search]);

  const query = useQuery({ queryKey: ["tickets"], queryFn: fetchTickets });

  const tickets = useMemo(
    () =>
      [...(query.data ?? [])].sort(
        (a, b) => b.updatedAt.localeCompare(a.updatedAt)
      ),
    [query.data]
  );

  const counts = useMemo(
    () => ({
      open: tickets.filter((x) => x.status === "open").length,
      pending: tickets.filter((x) => x.status === "pending").length,
      resolved: tickets.filter((x) => x.status === "resolved").length,
      closed: tickets.filter((x) => x.status === "closed").length,
      urgent: tickets.filter((x) => x.priority === "urgent").length,
    }),
    [tickets]
  );

  const quickStats = useMemo(() => {
    const replied = tickets.filter((x) => x.reply !== null);
    const avgHours =
      replied.length > 0
        ? Math.round(
            (replied.reduce(
              (s, x) =>
                s + (new Date(x.updatedAt).getTime() - new Date(x.createdAt).getTime()) / 3_600_000,
              0
            ) /
              replied.length) *
              10
          ) / 10
        : null;
    const perCat: Record<TicketCategory, number> = { technical: 0, billing: 0, general: 0, feature: 0 };
    for (const x of tickets) perCat[x.category] += 1;
    return { avgHours, perCat };
  }, [tickets]);

  const filtered = useMemo(
    () =>
      tickets.filter((x) => {
        if (statusFilter !== "all" && x.status !== statusFilter) return false;
        if (!debounced) return true;
        const haystack = [x.subject, x.requesterEmail, x.requesterName].join(" ");
        return normalizeSearch(haystack).includes(debounced);
      }),
    [tickets, statusFilter, debounced]
  );

  const detailTicket = useMemo(
    () => tickets.find((x) => x.id === detailId) ?? null,
    [tickets, detailId]
  );

  /* selection helpers — live below `filtered` by design */
  const allVisibleSelected = filtered.length > 0 && filtered.every((x) => selected.has(x.id));
  const someSelected = selected.size > 0;

  const toggleRow = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleAllVisible = () => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (filtered.length > 0 && filtered.every((x) => next.has(x.id))) {
        filtered.forEach((x) => next.delete(x.id));
      } else {
        filtered.forEach((x) => next.add(x.id));
      }
      return next;
    });
  };

  const remove = useMutation({
    mutationFn: (id: string) => deleteTicket(id),
    onSuccess: () => {
      toast.success(t("supDeleted"));
      queryClient.invalidateQueries({ queryKey: ["tickets"] });
      setPendingDelete(null);
      setDetailId(null);
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  /* round 28 — bulk triage mutations */
  const bulkPatch = useMutation({
    mutationFn: (payload: { status?: TicketStatus; priority?: TicketPriority }) =>
      bulkUpdateTickets([...selected], payload),
    onSuccess: (data, payload) => {
      toast.success(
        t("supBulkUpdatedToast", { count: fmtNum(data.updated, lang) }) +
          (payload.status !== undefined ? ` — ${t(STATUS_KEYS[payload.status])}` : "")
      );
      setSelected(new Set());
      queryClient.invalidateQueries({ queryKey: ["tickets"] });
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  const bulkRemove = useMutation({
    mutationFn: () => bulkDeleteTickets([...selected]),
    onSuccess: (data) => {
      toast.success(t("supBulkDeletedToast", { count: fmtNum(data.removed, lang) }));
      setSelected(new Set());
      setConfirmBulkDelete(false);
      queryClient.invalidateQueries({ queryKey: ["tickets"] });
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  const pending = query.isPending;
  const kpiValue = (node: React.ReactNode) => (pending ? <Skeleton className="h-8 w-16" /> : node);

  const statusPills: { value: StatusFilter; label: string; count: number }[] = [
    { value: "all", label: t("supFilterAll"), count: tickets.length },
    { value: "open", label: t("supStatusOpen"), count: counts.open },
    { value: "pending", label: t("supStatusPending"), count: counts.pending },
    { value: "resolved", label: t("supStatusResolved"), count: counts.resolved },
    { value: "closed", label: t("supStatusClosed"), count: counts.closed },
  ];

  return (
    <div className="space-y-5">
      <ViewHeading title={t("supTitle")} desc={t("supDesc")} />

      {/* KPI cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard
          index={0}
          label={t("supKpiOpen")}
          value={kpiValue(fmtNum(counts.open, lang))}
          icon="inbox"
          c1="#06b6d4"
          c2="#0891b2"
        />
        <KpiCard
          index={1}
          label={t("supKpiPending")}
          value={kpiValue(fmtNum(counts.pending, lang))}
          icon="timer"
          c1="#f59e0b"
          c2="#d97706"
        />
        <KpiCard
          index={2}
          label={t("supKpiResolved")}
          value={kpiValue(fmtNum(counts.resolved, lang))}
          icon="circle-check"
          c1="#10b981"
          c2="#059669"
        />
        <KpiCard
          index={3}
          label={t("supKpiUrgent")}
          value={kpiValue(fmtNum(counts.urgent, lang))}
          icon="flag"
          c1="#f43f5e"
          c2="#e11d48"
        />
      </div>

      {/* quick stats */}
      <section className="glass-card card-in rounded-3xl p-4 sm:p-5" style={{ "--i": 4 } as React.CSSProperties}>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-5">
          <div className="flex items-center gap-3">
            <IconTile icon="timer" c1="#f59e0b" c2="#d97706" size="sm" />
            <div>
              <p className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                {t("supAvgResponse")}
              </p>
              <div className="font-display text-[17px] font-extrabold text-slate-900 dark:text-white">
                {pending ? (
                  <Skeleton className="h-6 w-14" />
                ) : quickStats.avgHours !== null ? (
                  `${fmtNum(quickStats.avgHours, lang)}h`
                ) : (
                  "—"
                )}
              </div>
            </div>
          </div>
          <div className="hidden h-9 w-px bg-slate-200 dark:bg-white/10 sm:block" aria-hidden="true" />
          <div className="flex min-w-0 flex-wrap items-center gap-2">
            <p className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              {t("supCategoryBreakdown")}
            </p>
            {CATEGORIES.map((c) => {
              const meta = CATEGORY_META[c];
              return (
                <span
                  key={c}
                  className="inline-flex items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/60 px-2.5 py-1 text-[11px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
                >
                  <span
                    className="h-2 w-2 rounded-full"
                    style={{ backgroundColor: meta.c1 }}
                    aria-hidden="true"
                  />
                  {t(meta.label)}
                  <span className="font-extrabold tabular-nums text-slate-500 dark:text-slate-400">
                    {fmtNum(quickStats.perCat[c], lang)}
                  </span>
                </span>
              );
            })}
          </div>
        </div>
      </section>

      {/* inbox */}
      <section className="glass-card card-in rounded-3xl p-4 sm:p-5" style={{ "--i": 5 } as React.CSSProperties}>
        {/* status pills + search */}
        <div className="mb-4 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div
            className="flex flex-wrap items-center gap-1.5"
            role="group"
            aria-label={t("supColStatus")}
          >
            {statusPills.map((pill) => {
              const active = statusFilter === pill.value;
              const sc =
                pill.value === "all"
                  ? { c1: "#6d5dfb", c2: "#d946ef" }
                  : STATUS_GRADIENT[pill.value];
              return (
                <button
                  key={pill.value}
                  type="button"
                  aria-pressed={active}
                  onClick={() => setStatusFilter(pill.value)}
                  className={cn(
                    "inline-flex h-9 cursor-pointer items-center gap-1.5 rounded-xl px-3 text-[11.5px] font-extrabold transition",
                    active
                      ? "border-transparent text-white shadow-lg"
                      : "border border-slate-200 bg-white/60 text-slate-500 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400 dark:hover:text-slate-200"
                  )}
                  style={active ? { backgroundImage: grad(sc.c1, sc.c2) } : undefined}
                >
                  {pill.label}
                  <span className="rounded-full bg-slate-900/10 px-1.5 py-px text-[11px] font-extrabold tabular-nums dark:bg-white/15">
                    {fmtNum(pill.count, lang)}
                  </span>
                </button>
              );
            })}
          </div>
          <div className="relative max-w-md min-w-0 flex-1">
            <CatIcon
              name="search"
              className="pointer-events-none absolute start-3.5 top-1/2 h-[13px] w-[13px] -translate-y-1/2 text-slate-400"
            />
            <Input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t("supSearchPh")}
              aria-label={t("supSearchPh")}
              className="h-10 rounded-xl border-slate-200 bg-slate-50/80 ps-10 pe-3 text-[12.5px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:focus:bg-white/[0.07]"
            />
          </div>
        </div>

        {pending ? (
          <div className="space-y-2.5">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-20 w-full rounded-2xl" />
            ))}
          </div>
        ) : query.isError ? (
          <div className="py-14 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-rose-100 text-rose-500 dark:bg-rose-500/10 dark:text-rose-400">
              <CatIcon name="circle-alert" className="h-6 w-6" />
            </div>
            <p className="mt-3 font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("errorText")}
            </p>
            <Button
              type="button"
              variant="outline"
              onClick={() => query.refetch()}
              className="mt-4 h-10 gap-1.5 rounded-xl border-slate-200 px-5 text-[12.5px] font-bold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:text-slate-300"
            >
              <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
              {t("retryText")}
            </Button>
          </div>
        ) : filtered.length === 0 ? (
          <div className="py-14 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
              <CatIcon name="inbox" className="h-6 w-6" />
            </div>
            <p className="mt-3 font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("supEmpty")}
            </p>
            <p className="mx-auto mt-1 max-w-sm text-[12px] font-semibold text-slate-400 dark:text-slate-500">
              {t("supEmptyDesc")}
            </p>
          </div>
        ) : (
          <>
            {/* round 28 — select-all header row (roles that cannot triage skip selection) */}
            {canTriage ? (
              <div
                className="mb-2 flex items-center justify-between gap-2 rounded-xl bg-slate-50/80 px-3 py-2 dark:bg-white/[0.03]"
                role="group"
                aria-label={t("supBulkSelectAll")}
              >
                <div className="flex min-w-0 items-center gap-2.5">
                  <Checkbox
                    checked={allVisibleSelected ? true : someSelected ? "indeterminate" : false}
                    onCheckedChange={toggleAllVisible}
                    aria-label={t("supBulkSelectAll")}
                    disabled={filtered.length === 0}
                    className="data-[state=checked]:border-brand-500 data-[state=checked]:bg-brand-500 data-[state=indeterminate]:border-brand-500 data-[state=indeterminate]:bg-brand-500/80"
                  />
                  <p className={cn("truncate text-[11px] font-extrabold text-slate-500 dark:text-slate-400", labelTrack(lang))}>
                    {someSelected
                      ? t("supBulkSelectedCount", {
                          count: fmtNum(selected.size, lang),
                          total: fmtNum(filtered.length, lang),
                        })
                      : t("supBulkHint")}
                  </p>
                </div>
                {someSelected ? (
                  <button
                    type="button"
                    onClick={() => setSelected(new Set())}
                    className="inline-flex h-7 shrink-0 items-center gap-1 rounded-lg px-2 text-[10.5px] font-bold text-slate-400 transition hover:text-slate-600 active:scale-95 dark:hover:text-slate-200"
                  >
                    <CatIcon name="x" className="h-[12px] w-[12px]" />
                    <span className="hidden sm:inline">{t("supBulkClear")}</span>
                  </button>
                ) : null}
              </div>
            ) : null}
            <ul className="max-h-[34rem] divide-y divide-slate-100 overflow-y-auto [scrollbar-width:thin] [&::-webkit-scrollbar]:w-1.5 dark:divide-white/[0.06]">
              {filtered.map((ticket) => (
                <TicketRow
                  key={ticket.id}
                  ticket={ticket}
                  selectable={canTriage}
                  onOpen={setDetailId}
                  selected={selected.has(ticket.id)}
                  onToggle={toggleRow}
                />
              ))}
            </ul>
          </>
        )}
      </section>

      {/* round 28 — floating bulk-action toolbar
          (round 29: only for roles that can triage; delete inside needs manage) */}
      {someSelected && canTriage ? (
        <div
          role="toolbar"
          aria-label={t("supBulkToolbarLabel")}
          className="fixed bottom-5 left-1/2 z-50 w-[min(92vw,680px)] -translate-x-1/2 animate-in slide-in-from-bottom-4 fade-in rounded-2xl border border-slate-200/80 bg-white/95 p-2.5 shadow-2xl shadow-slate-900/15 backdrop-blur-xl dark:border-white/10 dark:bg-[#0b1220]/95 dark:shadow-black/40"
        >
          <div className="flex flex-wrap items-center gap-2">
            {/* count chip */}
            <span className="ms-1 inline-flex shrink-0 items-center gap-1.5 rounded-xl bg-brand-500/10 px-3 py-1.5 text-[12px] font-extrabold text-brand-600 dark:text-brand-300">
              <CatIcon name="check-check" className="h-[13px] w-[13px]" />
              <span dir="ltr" className="tabular-nums">{fmtNum(selected.size, lang)}</span>
              {t("supBulkSelected")}
            </span>
            <span className="hidden h-6 w-px shrink-0 bg-slate-200 sm:block dark:bg-white/10" aria-hidden="true" />

            {/* status actions */}
            {(["pending", "resolved", "closed"] as const).map((status) => {
              const sc = STATUS_GRADIENT[status];
              return (
                <button
                  key={status}
                  type="button"
                  onClick={() => bulkPatch.mutate({ status })}
                  disabled={bulkPatch.isPending || bulkRemove.isPending}
                  className="inline-flex h-9 items-center gap-1.5 rounded-xl border px-3 text-[11.5px] font-extrabold transition active:scale-95 disabled:opacity-50"
                  style={{
                    borderColor: `${sc.c1}55`,
                    backgroundColor: `${sc.c1}14`,
                    color: sc.c1,
                  }}
                >
                  <CatIcon name={status === "resolved" ? "circle-check" : status === "closed" ? "lock" : "timer"} className="h-[13px] w-[13px]" />
                  {t(STATUS_KEYS[status])}
                </button>
              );
            })}

            {/* priority menu */}
            <DropdownMenu>
              <DropdownMenuTrigger
                disabled={bulkPatch.isPending || bulkRemove.isPending}
                className="inline-flex h-9 cursor-pointer items-center gap-1.5 rounded-xl border border-fuchsia-200 bg-fuchsia-50 px-3 text-[11.5px] font-extrabold text-fuchsia-600 transition hover:bg-fuchsia-100 active:scale-95 disabled:opacity-50 dark:border-fuchsia-500/25 dark:bg-fuchsia-500/10 dark:text-fuchsia-300 dark:hover:bg-fuchsia-500/20"
              >
                <CatIcon name="flag" className="h-[13px] w-[13px]" />
                {t("supBulkPriority")}
                <CatIcon name="chevron-down" className="h-[11px] w-[11px] opacity-60" />
              </DropdownMenuTrigger>
              <DropdownMenuContent align="center" className="rounded-2xl">
                <DropdownMenuLabel className={cn("text-[10.5px] font-extrabold uppercase text-slate-400", labelTrack(lang))}>
                  {t("supBulkPriorityMenu")}
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                {PRIORITIES.map((p) => {
                  const pc = PRIORITY_META[p];
                  return (
                    <DropdownMenuItem
                      key={p}
                      onClick={() => bulkPatch.mutate({ priority: p })}
                      disabled={bulkPatch.isPending}
                      className="cursor-pointer gap-2 text-[12.5px] font-bold"
                    >
                      <span className="h-2 w-2 rounded-full" style={{ backgroundColor: pc.c1 }} aria-hidden="true" />
                      {t(PRIORITY_KEYS[p])}
                    </DropdownMenuItem>
                  );
                })}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* bulk delete */}
            {canManage ? (
              <button
                type="button"
                onClick={() => setConfirmBulkDelete(true)}
                disabled={bulkPatch.isPending || bulkRemove.isPending}
                className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-rose-300 bg-rose-600 px-3 text-[11.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-50"
              >
                <CatIcon name="trash-2" className="h-[13px] w-[13px]" />
                {t("supBulkDelete")}
              </button>
            ) : null}

            {/* clear selection */}
            <button
              type="button"
              onClick={() => setSelected(new Set())}
              className="ms-auto inline-flex h-9 shrink-0 items-center gap-1 rounded-xl px-2.5 text-[11.5px] font-bold text-slate-400 transition hover:text-slate-600 active:scale-95 dark:hover:text-slate-200"
            >
              <CatIcon name="x" className="h-[13px] w-[13px]" />
              <span className="hidden sm:inline">{t("supBulkClear")}</span>
            </button>
          </div>
        </div>
      ) : null}

      {/* ticket detail drawer */}
      <TicketDetailSheet
        ticket={detailTicket}
        open={detailTicket !== null}
        canManage={canManage}
        canTriage={canTriage}
        onOpenChange={(o) => !o && setDetailId(null)}
        onDelete={setPendingDelete}
      />

      {/* delete confirm */}
      <AlertDialog
        open={pendingDelete !== null}
        onOpenChange={(o) => !o && setPendingDelete(null)}
      >
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display text-lg font-extrabold text-slate-900 dark:text-white">
              {t("supDeleteTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] text-slate-500 dark:text-slate-400">
              {t("supDeleteMsg")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel
              className="h-10 rounded-xl px-5 text-[12.5px] font-bold"
              disabled={remove.isPending}
            >
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => pendingDelete && remove.mutate(pendingDelete)}
              disabled={remove.isPending}
              className="h-10 rounded-xl bg-rose-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60"
            >
              {remove.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : null}
              {t("supDeleteConfirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* round 28 — bulk delete confirm */}
      <AlertDialog open={confirmBulkDelete} onOpenChange={setConfirmBulkDelete}>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-linear-to-br from-slate-600 to-slate-700 text-white shadow-lg shadow-slate-500/25" aria-hidden="true">
                <CatIcon name="trash-2" className="h-[15px] w-[15px]" />
              </span>
              {t("supBulkDelete")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("supBulkDeleteMsg", { count: fmtNum(selected.size, lang) })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          {/* affected ticket subjects — first 12 + overflow */}
          <div className="flex max-h-32 flex-wrap gap-1.5 overflow-y-auto rounded-xl border border-dashed border-slate-300 bg-slate-50/60 p-2.5 dark:border-white/15 dark:bg-white/[0.03]">
            {tickets
              .filter((x) => selected.has(x.id))
              .slice(0, 12)
              .map((ticket) => (
                <span
                  key={ticket.id}
                  className="max-w-[220px] truncate rounded-full bg-white px-2 py-0.5 text-[10.5px] font-bold text-slate-500 dark:bg-white/10 dark:text-slate-300"
                >
                  {ticket.subject}
                </span>
              ))}
            {selected.size > 12 ? (
              <span dir="ltr" className="rounded-full bg-slate-100 px-2 py-0.5 text-[10.5px] font-extrabold tabular-nums text-slate-400 dark:bg-white/10 dark:text-slate-400">
                +{fmtNum(selected.size - 12, lang)}
              </span>
            ) : null}
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel
              className="h-10 rounded-xl px-5 text-[12.5px] font-bold"
              disabled={bulkRemove.isPending}
            >
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => bulkRemove.mutate()}
              disabled={bulkRemove.isPending}
              className="h-10 rounded-xl bg-rose-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60"
            >
              {bulkRemove.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : null}
              {t("supBulkApply", { count: fmtNum(selected.size, lang) })}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default AdminSupport;
