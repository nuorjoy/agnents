"use client";

/**
 * Ashrilogic — ROUND 142 — notification sound player.
 *
 * Mounted ONCE inside the root AppProviders (alongside IdentityBridge). It
 * instantiates the `useNotificationSound` hook so:
 *
 *   • an AudioContext is created lazily on the FIRST user gesture anywhere
 *     on the page (browser autoplay policy);
 *   • every rise in the unread notification count (admin feed OR any
 *     tenant workspace feed) fires the soft two-note chime;
 *   • a localStorage toggle (`ashrilogic-notif-sound` = "1"|"0") mutes the
 *     chime without a reload — default ON.
 *
 * This component renders NOTHING — it has zero visual footprint (returns
 * null). It is purely a side-effect mount.
 */
import { useNotificationSound } from "@/hooks/use-notification-sound";

export function NotificationSoundPlayer() {
  useNotificationSound(true);
  return null;
}

export default NotificationSoundPlayer;
