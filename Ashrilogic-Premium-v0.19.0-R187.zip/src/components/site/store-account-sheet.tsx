"use client";

/**
 * ROUND 85 — the SIGNED-IN customer account sheet, split out of
 * store-account.tsx so the public surfaces can LAZY-LOAD it
 * (next/dynamic, ssr:false): guests never download this code anymore —
 * since ROUND 85 they are LINKED to the DEDICATED account page
 * (/sites/[id]/account — account-page-view.tsx carries the full sign-in /
 * sign-up / forgot-password / reset journey; the old StoreAuthDialog popup
 * is gone). This module loads only when a signed-in customer opens the
 * sheet.
 *
 * Contents (a VERBATIM move of the ROUND 65–76 account home — behavior,
 * styling, i18n keys and logic are byte-identical to the original):
 *  - StoreAccountSheet — the account home (Profile / Addresses / Payments /
 *    Orders / Inquiries + sign-out), following the cart/wishlist sheet
 *    conventions (side by language, w-full on mobile, themed header,
 *    nice-scroll body). ROUND 73: the Inquiries tab is the customer's own
 *    support history — the blind-index twin of the owner's tickets console;
 *  - VerifyBanner (ROUND 75) + the five panels with their private helpers
 *    (useCountdown, card-brand preview, order/inquiry status maps);
 *  - the sheet-request bus wiring is intact: onAccountSheetRequest is
 *    imported from store-account.tsx (the bus itself lives there) so the
 *    live-reply toast still routes straight to استفساراتي;
 *  - shared atoms (AcctAvatar / AcctField / ConfirmDeletePopover /
 *    AcctEmptyState), useApplyAccount, mapAccountError and the account
 *    context (useStoreAccount) are imported one-directionally from
 *    store-account.tsx — which must NEVER import back from this file.
 *
 * Conventions (mirrored from storefront-view.tsx / store-shared.tsx):
 * RTL logical classes only (ms-/me-/ps-/pe-/start-/end-), grad()/hexAlpha()
 * theming, CatIcon vocabulary, sonner toasts, aria labels in Arabic,
 * dark: variants on every custom color, touch targets at 44px (h-11).
 */
import { useCallback, useEffect, useState, type CSSProperties } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import type { I18nKey } from "@/lib/i18n";
import { useT } from "@/lib/i18n";
import type {
  Lang,
  SiteInquiryDTO,
  SiteOrderDTO,
  SiteOrderStatus,
  StoreAccountDTO,
  StoreAddressDTO,
} from "@/lib/types";
import {
  ApiError,
  addStoreAddress,
  addStorePaymentMethod,
  checkStoreUsername,
  deleteStoreAddress,
  deleteStorePaymentMethod,
  fetchStoreAccountInquiries,
  fetchStoreAccountOrders,
  resendStoreVerification,
  updateStoreAddress,
  updateStoreProfile,
} from "@/lib/api-client";
import { cn, fmtNum, grad, hexAlpha } from "@/lib/utils";
import { fullDate, relativeTime } from "@/components/dashboard/dash-shared";
import { CatIcon } from "@/components/icon";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
} from "@/components/ui/select";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PremiumEmailInput, PremiumPhoneInput } from "@/components/ui/premium-contact";
import { fmtPrice, nf, TRACK_FLOW, TRACK_STEP_META, StoreTrackingCard } from "@/components/site/store-shared";
import {
  OrderReceiptDialog,
  type OrderReceiptData,
  type ReceiptIdentity,
} from "@/components/site/order-receipt";
import { intlLocale } from "@/lib/locales";
import { PHONE_RE } from "@/lib/validation";
import {
  AcctAvatar,
  AcctEmptyState,
  AcctField,
  ConfirmDeletePopover,
  mapAccountError,
  PanelProps,
  useApplyAccount,
  useStoreAccount,
} from "@/components/site/store-account";

/* ------------------------------------------------------------------ */
/* card-brand helpers (payments panel only — moved verbatim)            */
/* ------------------------------------------------------------------ */

/** brand visual + label per detected card brand (server re-detects anyway). */
const BRAND_META: Record<string, { gradient: string; labelKey: I18nKey }> = {
  visa: { gradient: "linear-gradient(135deg, #2563eb, #1e3a8a)", labelKey: "acctBrandVisa" },
  mastercard: { gradient: "linear-gradient(135deg, #f97316, #b91c1c)", labelKey: "acctBrandMastercard" },
  mada: { gradient: "linear-gradient(135deg, #059669, #065f46)", labelKey: "acctBrandMada" },
  amex: { gradient: "linear-gradient(135deg, #0e7490, #155e75)", labelKey: "acctBrandAmex" },
  card: { gradient: "linear-gradient(135deg, #475569, #1e293b)", labelKey: "acctBrandCard" },
};

/** LIVE brand preview while typing — the exact same order the server uses
 * (visa → mastercard → amex → mada BINs → generic) so the preview matches
 * the persisted verdict. */
function detectBrandPreview(digits: string): string {
  if (/^4/.test(digits)) return "visa";
  if (/^(5[1-5]|2[2-7])/.test(digits)) return "mastercard";
  if (/^(3[47])/.test(digits)) return "amex";
  if (/^(9682|588845|564182|504300|440647|440795|457992|458039)/.test(digits)) return "mada";
  return "card";
}

/** group the PAN visually (4-digit blocks, max 19 digits) as the user types. */
function formatCardNumber(raw: string): string {
  const digits = raw.replace(/\D/g, "").slice(0, 19);
  return digits.replace(/(\d{4})(?=\d)/g, "$1 ");
}

/* ------------------------------------------------------------------ */
/* order/inquiry status maps (orders + inquiries panels — verbatim)    */
/* ------------------------------------------------------------------ */

/** order-status label keys (the CHIP STYLING itself is reused from
 * TRACK_STEP_META — same vocabulary as the guest tracking timeline). */
const ORDER_STATUS_KEY: Record<SiteOrderStatus, I18nKey> = {
  pending: "ordStatusPending",
  confirmed: "ordStatusConfirmed",
  preparing: "ordStatusPreparing",
  ready: "ordStatusReady",
  completed: "ordStatusCompleted",
  cancelled: "ordStatusCancelled",
};

/** ROUND 73 — inquiry-status vocabulary (label keys reuse the SUPPORT
 * console's dictionary so the customer and the owner read the same words;
 * each entry carries its chip skin + icon). */
const INQUIRY_STATUS_META: Record<
  string,
  { label: I18nKey; icon: string; chip: string; dot: string }
> = {
  open: {
    label: "supStatusOpen",
    icon: "inbox",
    chip:
      "border-amber-300/60 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300",
    dot: "bg-amber-500",
  },
  pending: {
    label: "supStatusPending",
    icon: "clock",
    chip:
      "border-sky-300/60 bg-sky-500/10 text-sky-600 dark:border-sky-500/40 dark:text-sky-300",
    dot: "bg-sky-500",
  },
  resolved: {
    label: "supStatusResolved",
    icon: "check",
    chip:
      "border-emerald-300/60 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300",
    dot: "bg-emerald-500",
  },
  closed: {
    label: "supStatusClosed",
    icon: "archive",
    chip:
      "border-slate-300/60 bg-slate-500/10 text-slate-500 dark:border-white/15 dark:text-slate-400",
    dot: "bg-slate-400 dark:bg-slate-500",
  },
};

/** inquiry-category labels (support dictionary). */
const INQUIRY_CATEGORY_KEY: Record<string, I18nKey> = {
  billing: "supCatBilling",
  technical: "supCatTechnical",
  general: "supCatGeneral",
  feature: "supCatFeature",
  urgent: "supPrioUrgent",
};

/* ------------------------------------------------------------------ */
/* account sheet — profile panel                                        */
/* ------------------------------------------------------------------ */

/* ------------------------------------------------------------------ */
/* ROUND 75 — email verification banner (profile tab, unverified only)   */
/* ------------------------------------------------------------------ */

/** one second of cooldown per tick — Arabic-Indic numerals in AR. */
function useCountdown(): [number, (secs: number) => void] {
  const [left, setLeft] = useState(0);
  useEffect(() => {
    if (left <= 0) return;
    const id = window.setTimeout(() => setLeft((v) => v - 1), 1000);
    return () => window.clearTimeout(id);
  }, [left]);
  return [left, setLeft];
}

function VerifyBanner({ instanceId }: { instanceId: string }) {
  const { t, lang } = useT();
  const { account, refresh } = useStoreAccount();
  const [cooldown, setCooldown] = useCountdown();
  const [devLink, setDevLink] = useState<string | null>(null);

  /* parity poll: while the customer sits on the banner, a verification
   * done in another tab (the mailed link) should clear it without a
   * manual reload — one lightweight probe every 30s, only unverified. */
  useEffect(() => {
    if (account?.emailVerified) return;
    const id = window.setInterval(() => refresh(), 30_000);
    return () => window.clearInterval(id);
  }, [account?.emailVerified, refresh]);

  const resend = useMutation({
    mutationFn: () => resendStoreVerification(instanceId),
    onSuccess: (hint) => {
      /* ROUND 86 — the strict 45-second cooldown, unified with the
       * forgot-password flow (the server limiter is 45s too). */
      setCooldown(45);
      setDevLink(hint.devLink ?? null);
      toast.success(t("acctVerifySentToast"));
    },
    onError: (e: Error) => {
      const code = (e as { code?: string }).code;
      toast.error(
        code === "RESEND_COOLDOWN" ? t("acctVerifyWaitToast") : t("acctVerifyFailToast")
      );
    },
  });

  if (!account || account.emailVerified) return null;

  const copyLink = async () => {
    if (!devLink) return;
    try {
      await navigator.clipboard.writeText(devLink);
      toast.success(t("teamCopyEmail"));
    } catch {
      toast.error(t("acctVerifyFailToast"));
    }
  };

  return (
    <section
      aria-label={t("acctVerifyTitle")}
      className="card-in relative overflow-hidden rounded-2xl border border-amber-300/70 bg-gradient-to-br from-amber-50 via-orange-50/60 to-transparent p-4 shadow-soft dark:border-amber-500/30 dark:from-amber-500/[0.12] dark:via-orange-500/[0.06] dark:to-transparent"
    >
      {/* soft radial accent behind the icon tile */}
      <span
        aria-hidden="true"
        className="pointer-events-none absolute -top-10 start-0 h-28 w-28 rounded-full bg-amber-400/20 blur-2xl dark:bg-amber-400/10"
      />
      <div className="relative flex items-start gap-3">
        <span className="relative grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 text-white shadow-lg shadow-amber-500/30">
          <CatIcon name="mail-warning" className="h-5 w-5" />
          <span
            aria-hidden="true"
            className="absolute inset-0 rounded-2xl ring-1 ring-inset ring-white/30"
          />
        </span>
        <div className="min-w-0 flex-1">
          <p className="font-display text-[13.5px] font-extrabold text-amber-900 dark:text-amber-200">
            {t("acctVerifyTitle")}
          </p>
          <p className="mt-0.5 text-[11.5px] font-semibold leading-relaxed text-amber-800/80 dark:text-amber-200/70">
            {t("acctVerifyDesc", { email: account.email })}
          </p>
        </div>
      </div>

      {/* benefits — three compact proof rows */}
      <ul className="relative mt-3 grid gap-1.5">
        {(
          [
            { icon: "package", key: "acctVerifyBenefitOrders" },
            { icon: "shield-check", key: "acctVerifyBenefitSecure" },
            { icon: "message-square", key: "acctVerifyBenefitReplies" },
          ] as const
        ).map((row) => (
          <li
            key={row.key}
            className="flex items-center gap-2 rounded-xl bg-white/70 px-2.5 py-1.5 text-[11px] font-bold text-amber-900/90 ring-1 ring-inset ring-amber-200/60 dark:bg-white/[0.04] dark:text-amber-200/80 dark:ring-amber-500/20"
          >
            <CatIcon name={row.icon} className="h-3.5 w-3.5 shrink-0 text-amber-500 dark:text-amber-300" />
            <span className="min-w-0 truncate">{t(row.key)}</span>
          </li>
        ))}
      </ul>

      {/* resend action — ROUND 86: strict 45s cooldown countdown after a dispatch */}
      <button
        type="button"
        onClick={() => resend.mutate()}
        disabled={resend.isPending || cooldown > 0}
        className="mt-3 inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-[12.5px] font-extrabold text-white shadow-lg shadow-amber-500/30 transition hover:brightness-105 active:scale-[0.99] disabled:opacity-60"
      >
        {resend.isPending ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : cooldown > 0 ? (
          <CatIcon name="clock" className="h-4 w-4" />
        ) : (
          <CatIcon name="send" className="h-4 w-4" />
        )}
        {cooldown > 0
          ? t("acctVerifyCooldown", { secs: fmtNum(cooldown, lang) })
          : resend.isPending
            ? t("acctWorking")
            : t("acctVerifyResend")}
      </button>

      {/* dev/demo affordance — the link itself, only when the API chose to
          reveal it (development / ALLOW_DEMO_SECRETS; production never does) */}
      {devLink ? (
        <div className="relative mt-2.5 rounded-xl border border-dashed border-amber-400/70 bg-amber-100/40 p-2.5 dark:border-amber-500/40 dark:bg-amber-500/[0.08]">
          <p className="flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-wide text-amber-700 dark:text-amber-300">
            <CatIcon name="external-link" className="h-3 w-3" />
            {t("acctVerifyDevLabel")}
          </p>
          <div className="mt-1.5 flex items-center gap-1.5">
            <code
              dir="ltr"
              className="min-w-0 flex-1 truncate rounded-lg bg-white/80 px-2 py-1.5 text-[10px] font-bold text-amber-800 dark:bg-white/10 dark:text-amber-200"
            >
              {devLink}
            </code>
            <button
              type="button"
              onClick={copyLink}
              aria-label={t("teamCopyEmail")}
              className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-white/80 text-amber-700 transition hover:bg-white dark:bg-white/10 dark:text-amber-300 dark:hover:bg-white/20"
            >
              <CatIcon name="copy" className="h-3.5 w-3.5" />
            </button>
            <a
              href={devLink}
              target="_blank"
              rel="noreferrer"
              className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-white/80 text-amber-700 transition hover:bg-white dark:bg-white/10 dark:text-amber-300 dark:hover:bg-white/20"
              aria-label={t("acctVerifyOpen")}
              title={t("acctVerifyOpen")}
            >
              <CatIcon name="external-link" className="h-3.5 w-3.5" />
            </a>
          </div>
        </div>
      ) : null}
    </section>
  );
}

export function ProfilePanel({ instanceId, c1, c2 }: PanelProps) {
  const { t, lang } = useT();
  const { account } = useStoreAccount();
  const apply = useApplyAccount(instanceId);
  /* ROUND 147 — edit-on-demand: the panel boots READ-ONLY (label+value
   * rows); the edit button reveals the EXISTING form, cancel reverts
   * without saving. Entering edit mode re-seeds the inputs from the LIVE
   * account snapshot (it may have moved — e.g. an avatar upload wrote
   * through the shared cache while the panel sat read-only). */
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(account?.name ?? "");
  const [phone, setPhone] = useState(account?.phone ?? "");

  const nameDirty = name.trim() !== (account?.name ?? "");
  const phoneDirty = phone.trim() !== (account?.phone ?? "");
  const nameValid = name.trim().length >= 2;
  const phoneValid = phone.trim() === "" || PHONE_RE.test(phone.trim());
  const canSave = !!account && (nameDirty || phoneDirty) && nameValid && phoneValid;

  const save = useMutation({
    mutationFn: () =>
      updateStoreProfile(instanceId, {
        ...(nameDirty ? { name: name.trim() } : {}),
        ...(phoneDirty ? { phone: phone.trim() || null } : {}),
      }),
    onSuccess: (next) => {
      apply(next);
      setEditing(false);
      toast.success(t("acctProfileSavedToast"));
    },
    onError: (e: Error) => toast.error(mapAccountError(e, t)),
  });

  const startEditing = () => {
    setName(account?.name ?? "");
    setPhone(account?.phone ?? "");
    setEditing(true);
  };
  /* cancel reverts to read-only WITHOUT saving — the inputs return to the
   * persisted values, the dirty state dies with them. */
  const cancelEditing = () => {
    setName(account?.name ?? "");
    setPhone(account?.phone ?? "");
    setEditing(false);
  };

  if (!account) return <Skeleton className="h-64 rounded-2xl" />;

  return (
    <div className="space-y-4">
    {/* ROUND 75 — the verification call-to-action rides above the profile */}
    <VerifyBanner instanceId={instanceId} />
    <div className="card-in space-y-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-soft dark:border-white/10 dark:bg-white/[0.03]">
      <div className="flex items-center gap-2.5">
        <span
          className="grid h-9 w-9 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
          style={{ backgroundImage: grad(c1, c2) }}
        >
          <CatIcon name="user-round" className="h-4 w-4" />
        </span>
        <div className="min-w-0">
          <p className="font-display text-[13.5px] font-extrabold text-slate-900 dark:text-white">
            {t("acctTabProfile")}
          </p>
          <p className="truncate text-[11px] font-semibold text-slate-500 dark:text-slate-400">
            {account.name}
          </p>
        </div>
      </div>

      {!editing ? (
        <>
          {/* ROUND 147 — the READ-ONLY view: label + value rows (the email
              keeps its identity-lock hint exactly as before). */}
          <dl className="space-y-2">
            <div className="rounded-xl border border-slate-200/70 bg-slate-50/60 px-3.5 py-2.5 dark:border-white/[0.06] dark:bg-white/[0.02]">
              <dt className="text-[10px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                {t("acctProfileName")}
              </dt>
              <dd className="mt-0.5 truncate text-[13px] font-bold leading-relaxed text-slate-800 dark:text-slate-100">
                {account.name}
              </dd>
            </div>
            <div className="rounded-xl border border-slate-200/70 bg-slate-50/60 px-3.5 py-2.5 dark:border-white/[0.06] dark:bg-white/[0.02]">
              <dt className="text-[10px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                {t("acctProfilePhone")}
              </dt>
              <dd
                dir="ltr"
                className={cn(
                  /* ROUND L (TASK STORE-PROFILE) — phone + email RTL: the
                   * field row is RTL in Arabic; the phone DISPLAY value is
                   * kept dir="ltr" (digits are LTR) but the row's TEXT ALIGN
                   * is pushed to text-end so the number sits at the FAR
                   * RIGHT of the RTL row (premium Arabic-first formatting).
                   * The stored value keeps Western digits; Arabic-Indic is
                   * a DISPLAY-only transform (the API persists Western). */
                  "mt-0.5 truncate text-[13px] font-bold leading-relaxed",
                  lang === "ar" ? "text-end" : "text-start",
                  account.phone
                    ? "text-slate-800 dark:text-slate-100"
                    : "text-slate-400 dark:text-slate-500"
                )}
              >
                {account.phone ? toArabicIndicDigits(lang, account.phone) : "—"}
              </dd>
            </div>
            <div className="rounded-xl border border-slate-200/70 bg-slate-50/60 px-3.5 py-2.5 dark:border-white/[0.06] dark:bg-white/[0.02]">
              <dt className="text-[10px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                {t("acctProfileEmail")}
              </dt>
              <dd dir="ltr" className="mt-0.5 truncate text-start text-[13px] font-bold leading-relaxed text-slate-800 dark:text-slate-100">
                {account.email}
              </dd>
            </div>
          </dl>
          <p className="text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("acctProfileEmailLock")}
          </p>

          {/* the edit affordance + its subtle reassurance hint */}
          <div className="space-y-1.5">
            <Button
              type="button"
              onClick={startEditing}
              className="h-11 w-full gap-2 rounded-xl text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.99]"
              style={{
                backgroundImage: grad(c1, c2),
                boxShadow: `0 12px 26px -10px ${hexAlpha(c1, 0.75)}`,
              }}
            >
              <CatIcon name="pencil" className="h-4 w-4" />
              {t("acctEditBtn")}
            </Button>
            <p className="text-center text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {t("acctEditHint")}
            </p>
          </div>
        </>
      ) : (
        <>
          {/* the EXISTING edit form — same inputs, same validation, same
              save contract; only its VISIBILITY became on-demand. */}
          <AcctField id="acct-profile-name" label={t("acctProfileName")} required>
            <Input
              id="acct-profile-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={80}
              autoComplete="name"
              disabled={save.isPending}
              aria-invalid={!nameValid || undefined}
              className="h-11 rounded-xl"
            />
          </AcctField>

          <div dir={lang === "ar" ? "rtl" : "ltr"}>
            <PremiumEmailInput
              id="acct-profile-email"
              label="acctProfileEmail"
              value={account.email}
              onChange={() => {
                /* the account email is identity-locked — display only */
              }}
              autoComplete="email"
              locked
            />
          </div>
          <p className="mt-1.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("acctProfileEmailLock")}
          </p>

          <div dir={lang === "ar" ? "rtl" : "ltr"}>
            <PremiumPhoneInput
              id="acct-profile-phone"
              label="acctProfilePhone"
              value={phone}
              onChange={setPhone}
              hint="pciStorePhoneHint"
              autoComplete="tel"
              disabled={save.isPending}
              invalid={!phoneValid || undefined}
            />
          </div>

          <div className="flex items-center gap-2">
            <Button
              type="button"
              onClick={() => save.mutate()}
              disabled={!canSave || save.isPending}
              className="h-11 flex-1 gap-2 rounded-xl text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.99] disabled:opacity-60"
              style={{
                backgroundImage: grad(c1, c2),
                boxShadow: canSave ? `0 12px 26px -10px ${hexAlpha(c1, 0.75)}` : undefined,
              }}
            >
              {save.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="save" className="h-4 w-4" />
              )}
              {save.isPending ? t("acctWorking") : t("acctProfileSave")}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={cancelEditing}
              disabled={save.isPending}
              className="h-11 shrink-0 gap-1.5 rounded-xl px-4 text-[12px] font-bold"
            >
              <CatIcon name="circle-x" className="h-4 w-4" />
              {t("acctCancelEdit")}
            </Button>
          </div>
        </>
      )}
    </div>

    {/* ROUND L (TASK STORE-PROFILE) — order tracking moved INTO the profile.
        The store homepage used to carry #tracking; per the directive it now
        lives here as a premium section (the customer's own order pipeline). */}
    <PremiumTrackingSection instanceId={instanceId} c1={c1} c2={c2} />

    {/* ROUND L (TASK STORE-PROFILE) — username self-service: the customer
        can change their own handle (subject to the same uniqueness check
        the register route runs). */}
    <UsernameEditCard instanceId={instanceId} c1={c1} c2={c2} />

    {/* ROUND 87 (13-e) — danger zone: the customer can destroy their own
        account permanently (password proof + typed confirmation). */}
    <DeleteAccountCard instanceId={instanceId} />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* ROUND 87 (13-e) — permanent account deletion (danger zone card)      */
/* ------------------------------------------------------------------ */

/**
 * The profile tab's danger zone. The strict DELETE /api/sites/[id]/account
 * contract is mirrored here: the destructive button stays disabled until
 * the customer types the exact confirmation word (ar "حذف" / en "DELETE")
 * AND supplies their password; a 403 PASSWORD_PROOF answer renders the
 * inline acctDeleteErrPw message. On success the session is already dead
 * server-side (the API clears it before the row dies) — toast + navigate
 * to the public site home, which now greets them as a guest.
 */
/* ------------------------------------------------------------------ */
/* ROUND L (TASK STORE-PROFILE) — RTL phone/email helpers + new sections */
/* ------------------------------------------------------------------ */

/** Convert Western digits in a string to Arabic-Indic digits when the active
 *  language is Arabic (٠١٢٣٤٥٦٧٨٩). Used for DISPLAY ONLY — the stored value
 *  keeps Western digits (the API + the dial-code selector always operate on
 *  ASCII digits). Returns the input unchanged for non-Arabic languages. */
function toArabicIndicDigits(lang: Lang, value: string): string {
  if (lang !== "ar") return value;
  const map = ["٠", "١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩"];
  return value.replace(/[0-9]/g, (d) => map[Number(d)]);
}

/**
 * ROUND L (TASK STORE-PROFILE) — the username self-service card. The
 * customer can change their own handle from inside the profile panel.
 *
 * UX:
 *  - the card boots READ-ONLY: the current handle + a small "تعديل / Edit"
 *    button reveal the form;
 *  - the form carries a live «متاح / Available» / «مأخوذ / Taken» chip
 *    driven by a DEBOUNCED probe to POST /account/check-username;
 *  - on save, PATCH /account with the new username — the server re-checks
 *    uniqueness (the client chip is UX only; the server is the source of
 *    truth);
 *  - the form is disabled while a save is in flight; a success toast
 *    confirms + the panel returns to read-only with the fresh handle.
 */
function UsernameEditCard({ instanceId, c1, c2 }: PanelProps) {
  const { t, lang } = useT();
  const { account, refresh } = useStoreAccount();
  const apply = useApplyAccount(instanceId);
  const [editing, setEditing] = useState(false);
  const [username, setUsername] = useState(account?.username ?? "");

  /* ROUND L — username shape gate (mirrors the server-side usernameSchema).
   *  Allows latin letters, digits, dot, underscore, hyphen + Arabic letters
   *  U+0621..U+064A. Start/end with a letter or digit. 3-30 chars. */
  const USERNAME_RE = /^[a-z0-9\u0621-\u064a][a-z0-9._\-\u0621-\u064a]{1,28}[a-z0-9\u0621-\u064a]$/i;

  /* ROUND L — derived verdict computation (PURE, render-time):
   *  - the SHAPE verdict (idle / invalid / available-when-matches-current)
   *    is computed SYNCHRONOUSLY during render — no setState in the effect
   *    body (the react-hooks/purity rule). The server is the source of
   *    truth; this UX chip NEVER replaces the server-side re-check on save.
   *  - the SERVER verdict (taken / available) is fetched in a DEBOUNCED
   *    effect (350ms) and stored in `serverVerdict`. The chip prefers the
   *    server verdict when the shape passes + the customer moved off the
   *    current handle. */
  const wantedUsername = username.trim().toLowerCase();
  const matchesCurrent = wantedUsername === (account?.username ?? "");
  const shapeValid =
    wantedUsername.length >= 3 &&
    wantedUsername.length <= 30 &&
    USERNAME_RE.test(wantedUsername);
  const [serverVerdict, setServerVerdict] = useState<"idle" | "checking" | "available" | "taken">("idle");
  const verdict: "idle" | "checking" | "available" | "taken" | "invalid" = (() => {
    if (!editing || wantedUsername.length === 0) return "idle";
    if (!shapeValid) return "invalid";
    if (matchesCurrent) return "available";
    return serverVerdict;
  })();

  /* the debounced server probe — the setServerVerdict calls happen INSIDE
   * the setTimeout callback (async — the purity rule stays clean; matches
   * the wizard's email/phone availability pattern in org-step.tsx). */
  useEffect(() => {
    if (!editing || wantedUsername.length === 0 || !shapeValid || matchesCurrent) {
      return;
    }
    let live = true;
    const handle = window.setTimeout(() => {
      if (!live) return;
      setServerVerdict("checking");
      void checkStoreUsername(instanceId, wantedUsername)
        .then((res) => {
          if (live) setServerVerdict(res.available ? "available" : "taken");
        })
        .catch(() => {
          /* network/shape errors → stay neutral so the customer can still
           * submit (the server re-validates on save). */
          if (live) setServerVerdict("idle");
        });
    }, 350);
    return () => {
      live = false;
      window.clearTimeout(handle);
    };
  }, [wantedUsername, editing, shapeValid, matchesCurrent, instanceId]);

  const dirty = wantedUsername !== (account?.username ?? "");
  const canSave = dirty && (verdict === "available");

  const save = useMutation({
    mutationFn: () => updateStoreProfile(instanceId, { username: username.trim().toLowerCase() }),
    onSuccess: (next) => {
      apply(next);
      setEditing(false);
      toast.success(t("acctUsernameSavedToast"));
      refresh();
    },
    onError: (e: Error) => {
      const code = (e as { code?: string }).code;
      if (code === "USERNAME_TAKEN") {
        setServerVerdict("taken");
        toast.error(t("acctUsernameTaken"));
      } else {
        toast.error(mapAccountError(e, t));
      }
    },
  });

  const cancel = () => {
    setUsername(account?.username ?? "");
    setServerVerdict("idle");
    setEditing(false);
  };

  if (!account) return null;

  const verdictChip = (() => {
    if (verdict === "checking") {
      return (
        <span className="inline-flex items-center gap-1 rounded-full border border-slate-200 bg-slate-50 px-2 py-0.5 text-[10px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400">
          <Loader2 className="h-3 w-3 animate-spin" />
          {t("acctUsernameChecking")}
        </span>
      );
    }
    if (verdict === "available") {
      return (
        <span className="inline-flex items-center gap-1 rounded-full border border-emerald-300/60 bg-emerald-500/10 px-2 py-0.5 text-[10px] font-extrabold text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300">
          <CatIcon name="circle-check" className="h-3 w-3" />
          {t("acctUsernameAvailable")}
        </span>
      );
    }
    if (verdict === "taken") {
      return (
        <span className="inline-flex items-center gap-1 rounded-full border border-rose-300/60 bg-rose-500/10 px-2 py-0.5 text-[10px] font-extrabold text-rose-600 dark:border-rose-500/40 dark:text-rose-300">
          <CatIcon name="circle-x" className="h-3 w-3" />
          {t("acctUsernameTaken")}
        </span>
      );
    }
    if (verdict === "invalid") {
      return (
        <span className="inline-flex items-center gap-1 rounded-full border border-amber-300/60 bg-amber-500/10 px-2 py-0.5 text-[10px] font-extrabold text-amber-600 dark:border-amber-500/40 dark:text-amber-300">
          <CatIcon name="triangle-alert" className="h-3 w-3" />
          {t("acctUsernameInvalid")}
        </span>
      );
    }
    return null;
  })();

  return (
    <section className="card-in space-y-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-soft dark:border-white/10 dark:bg-white/[0.03]">
      <div className="flex items-center gap-2.5">
        <span
          className="grid h-9 w-9 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
          style={{ backgroundImage: grad(c1, c2) }}
        >
          <CatIcon name="at-sign" className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="font-display text-[13.5px] font-extrabold text-slate-900 dark:text-white">
            {t("acctUsernameEdit")}
          </p>
          <p className="truncate text-[11px] font-semibold text-slate-500 dark:text-slate-400">
            {t("acctUsernameEditHint")}
          </p>
        </div>
        {editing ? verdictChip : null}
      </div>

      {!editing ? (
        <>
          <div className="rounded-xl border border-slate-200/70 bg-slate-50/60 px-3.5 py-2.5 dark:border-white/[0.06] dark:bg-white/[0.02]">
            <p className="text-[10px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
              {t("acctUsernameCurrent")}
            </p>
            <p
              dir="ltr"
              className={cn(
                "mt-0.5 truncate font-mono text-[13px] font-extrabold",
                lang === "ar" ? "text-end" : "text-start"
              )}
              style={{ color: c1 }}
            >
              @{account.username || "—"}
            </p>
          </div>
          <Button
            type="button"
            onClick={() => {
              setUsername(account.username ?? "");
              setServerVerdict("idle");
              setEditing(true);
            }}
            className="h-11 w-full gap-2 rounded-xl text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.99]"
            style={{
              backgroundImage: grad(c1, c2),
              boxShadow: `0 12px 26px -10px ${hexAlpha(c1, 0.75)}`,
            }}
          >
            <CatIcon name="pencil" className="h-4 w-4" />
            {t("acctUsernameEdit")}
          </Button>
        </>
      ) : (
        <>
          <AcctField id="acct-username-new" label={t("acctUsernameNew")} required>
            <div className="relative">
              <CatIcon
                name="at-sign"
                className="pointer-events-none absolute start-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
              />
              <Input
                id="acct-username-new"
                dir="ltr"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder={t("acctUsernamePh")}
                maxLength={30}
                autoComplete="off"
                spellCheck={false}
                disabled={save.isPending}
                className="h-11 rounded-xl bg-white ps-10 font-mono text-[13px] font-bold text-slate-800 dark:bg-white/[0.04] dark:text-slate-100"
              />
            </div>
          </AcctField>
          <p className="text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("acctUsernameHint")}
          </p>

          <div className="flex items-center gap-2">
            <Button
              type="button"
              onClick={() => save.mutate()}
              disabled={!canSave || save.isPending}
              className="h-11 flex-1 gap-2 rounded-xl text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.99] disabled:opacity-60"
              style={{
                backgroundImage: grad(c1, c2),
                boxShadow: canSave ? `0 12px 26px -10px ${hexAlpha(c1, 0.75)}` : undefined,
              }}
            >
              {save.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="save" className="h-4 w-4" />
              )}
              {save.isPending ? t("acctWorking") : t("acctProfileSave")}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={cancel}
              disabled={save.isPending}
              className="h-11 shrink-0 gap-1.5 rounded-xl px-4 text-[12px] font-bold"
            >
              <CatIcon name="circle-x" className="h-4 w-4" />
              {t("acctCancelEdit")}
            </Button>
          </div>
        </>
      )}
    </section>
  );
}

/**
 * ROUND L (TASK STORE-PROFILE) — the order tracking card moved INSIDE the
 * customer profile (premium section). The store homepage used to carry the
 * #tracking section; per the directive «احذف التتبع من الصفحة الرئيسية
 * واجعلها داخل بروفايل العميل بطريقة احترافية وPremium» it now lives here
 * as a premium section above the danger zone. The shared StoreTrackingCard
 * is reused VERBATIM (code + phone → live status timeline + printable
 * receipt) — same component the public storefront used to mount.
 */
function PremiumTrackingSection({ instanceId, c1, c2 }: PanelProps) {
  const { t } = useT();
  return (
    <section className="card-in space-y-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-soft dark:border-white/10 dark:bg-white/[0.03]">
      <div className="flex items-center gap-2.5">
        <span
          className="grid h-9 w-9 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
          style={{ backgroundImage: grad(c1, c2) }}
        >
          <CatIcon name="package-search" className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="font-display text-[13.5px] font-extrabold text-slate-900 dark:text-white">
            {t("acctTrackingTitle")}
          </p>
          <p className="truncate text-[11px] font-semibold text-slate-500 dark:text-slate-400">
            {t("acctTrackingDesc")}
          </p>
        </div>
      </div>
      <StoreTrackingCard instanceId={instanceId} c1={c1} c2={c2} />
    </section>
  );
}

function DeleteAccountCard({ instanceId }: { instanceId: string }) {
  const { t, lang } = useT();
  const [open, setOpen] = useState(false);
  const [password, setPassword] = useState("");
  const [confirmText, setConfirmText] = useState("");
  const [pwError, setPwError] = useState(false);

  const confirmWord = t("acctDeleteConfirmWord");
  const confirmReady = password.trim().length > 0 && confirmText.trim() === confirmWord;

  const closeDialog = () => {
    setOpen(false);
    setPassword("");
    setConfirmText("");
    setPwError(false);
  };

  const remove = useMutation({
    mutationFn: async () => {
      /* same-origin DELETE with the strict body the API re-checks — the
       * typed word is the UI gesture; the machine confirm is always the
       * literal "DELETE" the server validates. */
      const res = await fetch(`/api/sites/${encodeURIComponent(instanceId)}/account`, {
        method: "DELETE",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: password.trim(), confirm: "DELETE" }),
      });
      if (!res.ok) {
        let message = `Request failed (${res.status})`;
        let code: string | undefined;
        try {
          const data = (await res.json()) as { error?: string; code?: string };
          if (data && typeof data.error === "string" && data.error) message = data.error;
          if (data && typeof data.code === "string" && data.code) code = data.code;
        } catch {
          /* non-JSON error body — keep the generic message */
        }
        throw new ApiError(message, res.status, code);
      }
      return (await res.json()) as { ok?: boolean; permanent?: boolean };
    },
    onSuccess: () => {
      toast.success(t("acctDeleteSuccess"));
      /* the session died with the row — land on the public site home
       * (full page load, guest state; works from BOTH the website and the
       * e-store, which share the /sites/[id] base path). */
      window.location.assign(`/sites/${encodeURIComponent(instanceId)}`);
    },
    onError: (e: Error) => {
      const code = (e as { code?: string }).code;
      if (code === "PASSWORD_PROOF") {
        setPwError(true);
      } else {
        toast.error(mapAccountError(e, t));
      }
    },
  });

  return (
    <section
      aria-label={t("acctDeleteTitle")}
      className="card-in relative overflow-hidden rounded-2xl border border-rose-200 bg-gradient-to-br from-rose-50 via-rose-50/60 to-transparent p-4 shadow-soft dark:border-rose-500/30 dark:from-rose-500/[0.12] dark:via-rose-500/[0.05] dark:to-transparent"
    >
      {/* soft radial accent behind the icon tile */}
      <span
        aria-hidden="true"
        className="pointer-events-none absolute -top-10 start-0 h-28 w-28 rounded-full bg-rose-400/20 blur-2xl dark:bg-rose-400/10"
      />
      <div className="relative flex items-start gap-3">
        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-rose-500 to-rose-700 text-white shadow-lg shadow-rose-500/30">
          <CatIcon name="triangle-alert" className="h-5 w-5" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="font-display text-[13.5px] font-extrabold text-rose-900 dark:text-rose-200">
            {t("acctDeleteTitle")}
          </p>
          <p className="mt-0.5 text-[11.5px] font-semibold leading-relaxed text-rose-800/80 dark:text-rose-200/70">
            {t("acctDeleteDesc")}
          </p>
        </div>
      </div>

      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label={t("acctDeleteBtn")}
        className="relative mt-3 inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-rose-600 to-rose-700 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/30 transition hover:brightness-105 active:scale-[0.99]"
      >
        <CatIcon name="trash-2" className="h-4 w-4" />
        {t("acctDeleteBtn")}
      </button>

      {/* strict delete ceremony — password proof + typed confirmation */}
      <AlertDialog
        open={open}
        onOpenChange={(o) => {
          if (o) setOpen(true);
          else closeDialog();
        }}
      >
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-rose-500 to-rose-700 text-white shadow-lg shadow-rose-500/25"
                aria-hidden="true"
              >
                <CatIcon name="triangle-alert" className="h-[15px] w-[15px]" />
              </span>
              {t("acctDeleteTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("acctDeleteDesc")}
            </AlertDialogDescription>
          </AlertDialogHeader>

          <div className="space-y-3">
            <AcctField id="acct-delete-pw" label={t("acctDeletePwLabel")} required>
              <Input
                id="acct-delete-pw"
                type="password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setPwError(false);
                }}
                autoComplete="current-password"
                disabled={remove.isPending}
                aria-invalid={pwError || undefined}
                className="h-11 rounded-xl"
              />
              {pwError ? (
                <p role="alert" className="text-[11px] font-bold text-rose-600 dark:text-rose-300">
                  {t("acctDeleteErrPw")}
                </p>
              ) : null}
            </AcctField>

            <div className="space-y-1.5">
              <label
                htmlFor="acct-delete-confirm"
                className="block text-[12px] font-extrabold text-rose-600 dark:text-rose-300"
                dir="auto"
              >
                {t("trashConfirmType", { word: confirmWord })}
              </label>
              <Input
                id="acct-delete-confirm"
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                placeholder={confirmWord}
                dir="auto"
                autoComplete="off"
                disabled={remove.isPending}
                className="h-11 rounded-xl text-[13px] font-extrabold"
              />
            </div>
          </div>

          <AlertDialogFooter>
            <AlertDialogCancel
              className="h-10 rounded-xl px-5 text-[12.5px] font-bold"
              disabled={remove.isPending}
            >
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                /* keep the dialog open while the request runs (spinner) —
                   only the success path navigates away */
                e.preventDefault();
                if (confirmReady) remove.mutate();
              }}
              disabled={!confirmReady || remove.isPending}
              className="h-10 rounded-xl bg-rose-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60"
            >
              {remove.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="trash-2" className="h-4 w-4" />
              )}
              {t("acctDeleteBtn")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* account sheet — addresses panel                                      */
/* ------------------------------------------------------------------ */

interface AddressFormState {
  label: string;
  fullName: string;
  phone: string;
  city: string;
  district: string;
  street: string;
  building: string;
  floor: string;
  apartment: string;
  notes: string;
  isDefault: boolean;
}

export function AddressesPanel({ instanceId, c1, c2 }: PanelProps) {
  const { t, lang } = useT();
  const { account } = useStoreAccount();
  const apply = useApplyAccount(instanceId);
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState<AddressFormState>({
    label: "",
    fullName: account?.name ?? "",
    phone: account?.phone ?? "",
    city: "",
    district: "",
    street: "",
    building: "",
    floor: "",
    apartment: "",
    notes: "",
    isDefault: false,
  });

  const upd = useCallback(
    <K extends keyof AddressFormState>(key: K, value: AddressFormState[K]) =>
      setForm((f) => ({ ...f, [key]: value })),
    []
  );

  const addresses = account?.addresses ?? [];
  const sep = lang === "ar" ? "، " : ", ";

  const formValid =
    form.label.trim().length >= 1 &&
    form.fullName.trim().length >= 2 &&
    PHONE_RE.test(form.phone.trim()) &&
    form.city.trim().length >= 1 &&
    form.street.trim().length >= 1;

  const add = useMutation({
    mutationFn: () =>
      addStoreAddress(instanceId, {
        label: form.label.trim(),
        fullName: form.fullName.trim(),
        phone: form.phone.trim(),
        city: form.city.trim(),
        district: form.district.trim(),
        street: form.street.trim(),
        building: form.building.trim(),
        floor: form.floor.trim(),
        apartment: form.apartment.trim(),
        notes: form.notes.trim(),
        isDefault: form.isDefault,
      }),
    onSuccess: (next) => {
      apply(next);
      toast.success(t("acctAddressSavedToast"));
      setAdding(false);
      setForm((f) => ({
        ...f,
        label: "",
        city: "",
        district: "",
        street: "",
        building: "",
        floor: "",
        apartment: "",
        notes: "",
        isDefault: false,
      }));
    },
    onError: (e: Error) => toast.error(mapAccountError(e, t)),
  });

  const makeDefault = useMutation({
    mutationFn: (addressId: string) =>
      updateStoreAddress(instanceId, addressId, { isDefault: true }),
    onSuccess: apply,
    onError: (e: Error) => toast.error(mapAccountError(e, t)),
  });

  const remove = useMutation({
    mutationFn: (addressId: string) => deleteStoreAddress(instanceId, addressId),
    onSuccess: (next) => {
      apply(next);
      toast.success(t("acctAddressDeletedToast"));
    },
    onError: (e: Error) => toast.error(mapAccountError(e, t)),
  });

  return (
    <div className="space-y-3">
      {addresses.length === 0 && !adding ? (
        <AcctEmptyState
          icon="map-pin"
          title={t("acctAddressesEmptyTitle")}
          desc={t("acctAddressesEmptyDesc")}
          c1={c1}
          c2={c2}
        />
      ) : null}

      {addresses.length > 0 ? (
        <ul className="space-y-2.5">
          {addresses.map((a: StoreAddressDTO, i: number) => {
            const line = [a.city, a.district, a.street, a.building, a.floor, a.apartment]
              .filter((part) => part && part.trim().length > 0)
              .join(sep);
            return (
              <li
                key={a.id}
                className="card-in rounded-2xl border border-slate-200 bg-white p-3.5 shadow-soft dark:border-white/10 dark:bg-white/[0.03]"
                style={{ "--i": Math.min(i, 5) } as CSSProperties}
              >
                <div className="flex items-start justify-between gap-2.5">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <p className="inline-flex items-center gap-1.5 font-display text-[13px] font-extrabold text-slate-900 dark:text-white">
                        <CatIcon name="map-pin" className="h-3.5 w-3.5 shrink-0" style={{ color: c1 }} />
                        <span className="truncate">{a.label}</span>
                      </p>
                      {a.isDefault ? (
                        <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-emerald-300/70 bg-emerald-500/10 px-2 py-0.5 text-[10px] font-extrabold text-emerald-700 dark:border-emerald-500/40 dark:text-emerald-300">
                          <CatIcon name="badge-check" className="h-3 w-3" />
                          {t("acctAddressDefaultBadge")}
                        </span>
                      ) : null}
                    </div>
                    <p className="mt-1.5 text-[12px] font-semibold leading-relaxed text-slate-600 dark:text-slate-300">
                      {line}
                    </p>
                    <p className="mt-1 flex flex-wrap items-center gap-x-2.5 gap-y-0.5 text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                      <span className="inline-flex items-center gap-1">
                        <CatIcon name="user-round" className="h-3 w-3" />
                        {a.fullName}
                      </span>
                      <span dir="ltr" className="inline-flex items-center gap-1">
                        <CatIcon name="phone" className="h-3 w-3" />
                        {a.phone}
                      </span>
                    </p>
                    {a.notes ? (
                      <p className="mt-1 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                        {a.notes}
                      </p>
                    ) : null}
                  </div>
                  <div className="flex shrink-0 items-center gap-1.5">
                    {!a.isDefault ? (
                      <button
                        type="button"
                        onClick={() => makeDefault.mutate(a.id)}
                        disabled={makeDefault.isPending}
                        aria-label={`${t("acctAddressMakeDefault")} — ${a.label}`}
                        title={`${t("acctAddressMakeDefault")} — ${a.label}`}
                        className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 px-2.5 text-[10.5px] font-extrabold text-slate-500 transition hover:border-amber-300 hover:bg-amber-50 hover:text-amber-700 active:scale-95 disabled:opacity-60 dark:border-white/10 dark:text-slate-400 dark:hover:border-amber-500/40 dark:hover:bg-amber-500/10 dark:hover:text-amber-300"
                      >
                        <CatIcon name="star" className="h-3.5 w-3.5" />
                        <span className="hidden whitespace-nowrap sm:inline">
                          {t("acctAddressMakeDefault")}
                        </span>
                      </button>
                    ) : null}
                    <ConfirmDeletePopover
                      triggerLabel={`${t("acctAddressDelete")} — ${a.label}`}
                      itemLabel={a.label}
                      itemIcon="map-pin"
                      confirmLabel={t("acctAddressDelete")}
                      pending={remove.isPending}
                      onConfirm={() => remove.mutate(a.id)}
                    />
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      ) : null}

      {/* collapsible add-address card */}
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-soft dark:border-white/10 dark:bg-white/[0.03]">
        <button
          type="button"
          onClick={() => setAdding((v) => !v)}
          aria-expanded={adding}
          aria-label={t("acctAddAddress")}
          className="flex h-11 w-full items-center gap-2.5 px-3.5 text-[12.5px] font-extrabold text-slate-700 transition hover:bg-slate-50 active:scale-[0.99] dark:text-slate-200 dark:hover:bg-white/[0.04]"
        >
          <span
            className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-white"
            style={{ backgroundImage: grad(c1, c2) }}
          >
            <CatIcon name={adding ? "x" : "plus"} className="h-3.5 w-3.5" />
          </span>
          {t("acctAddAddress")}
        </button>

        {adding ? (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (formValid) add.mutate();
            }}
            className="space-y-3 border-t border-slate-200/70 p-3.5 dark:border-white/10"
            noValidate
          >
            <AcctField id="acct-addr-label" label={t("acctAddressLabel")} required>
              <Input
                id="acct-addr-label"
                value={form.label}
                onChange={(e) => upd("label", e.target.value)}
                placeholder={t("acctAddressLabelPh")}
                maxLength={40}
                disabled={add.isPending}
                className="h-11 rounded-xl"
              />
            </AcctField>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <AcctField id="acct-addr-fullname" label={t("acctAddressFullName")} required>
                <Input
                  id="acct-addr-fullname"
                  value={form.fullName}
                  onChange={(e) => upd("fullName", e.target.value)}
                  maxLength={80}
                  autoComplete="name"
                  disabled={add.isPending}
                  className="h-11 rounded-xl"
                />
              </AcctField>
              <PremiumPhoneInput
                id="acct-addr-phone"
                label="acctAddressPhone"
                value={form.phone}
                onChange={(v) => upd("phone", v)}
                required
                autoComplete="tel"
                disabled={add.isPending}
              />
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <AcctField id="acct-addr-city" label={t("acctAddressCity")} required>
                <Input
                  id="acct-addr-city"
                  value={form.city}
                  onChange={(e) => upd("city", e.target.value)}
                  maxLength={60}
                  disabled={add.isPending}
                  className="h-11 rounded-xl"
                />
              </AcctField>
              <AcctField id="acct-addr-district" label={t("acctAddressDistrict")}>
                <Input
                  id="acct-addr-district"
                  value={form.district}
                  onChange={(e) => upd("district", e.target.value)}
                  maxLength={60}
                  disabled={add.isPending}
                  className="h-11 rounded-xl"
                />
              </AcctField>
            </div>
            <AcctField id="acct-addr-street" label={t("acctAddressStreet")} required>
              <Input
                id="acct-addr-street"
                value={form.street}
                onChange={(e) => upd("street", e.target.value)}
                maxLength={80}
                disabled={add.isPending}
                className="h-11 rounded-xl"
              />
            </AcctField>
            <div className="grid grid-cols-3 gap-3">
              <AcctField id="acct-addr-building" label={t("acctAddressBuilding")}>
                <Input
                  id="acct-addr-building"
                  value={form.building}
                  onChange={(e) => upd("building", e.target.value)}
                  maxLength={40}
                  disabled={add.isPending}
                  className="h-11 rounded-xl"
                />
              </AcctField>
              <AcctField id="acct-addr-floor" label={t("acctAddressFloor")}>
                <Input
                  id="acct-addr-floor"
                  value={form.floor}
                  onChange={(e) => upd("floor", e.target.value)}
                  maxLength={10}
                  disabled={add.isPending}
                  className="h-11 rounded-xl"
                />
              </AcctField>
              <AcctField id="acct-addr-apartment" label={t("acctAddressApartment")}>
                <Input
                  id="acct-addr-apartment"
                  value={form.apartment}
                  onChange={(e) => upd("apartment", e.target.value)}
                  maxLength={10}
                  disabled={add.isPending}
                  className="h-11 rounded-xl"
                />
              </AcctField>
            </div>
            <AcctField id="acct-addr-notes" label={t("acctAddressNotes")}>
              <textarea
                id="acct-addr-notes"
                value={form.notes}
                onChange={(e) => upd("notes", e.target.value)}
                maxLength={200}
                rows={2}
                disabled={add.isPending}
                className="w-full resize-none rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-[13px] shadow-sm outline-none transition placeholder:text-slate-400 focus:border-brand-400 focus:ring-2 focus:ring-brand-400/20 dark:border-white/10 dark:bg-white/[0.04] dark:text-white dark:placeholder:text-slate-500"
              />
            </AcctField>
            <div className="flex items-center gap-2.5">
              <Checkbox
                id="acct-addr-default"
                checked={form.isDefault}
                onCheckedChange={(v) => upd("isDefault", v === true)}
                disabled={add.isPending}
              />
              <Label htmlFor="acct-addr-default" className="cursor-pointer text-[12px] font-bold">
                {t("acctAddressDefault")}
              </Label>
            </div>

            <Button
              type="submit"
              disabled={!formValid || add.isPending}
              className="h-11 w-full gap-2 rounded-xl text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.99] disabled:opacity-60"
              style={{
                backgroundImage: grad(c1, c2),
                boxShadow: formValid ? `0 12px 26px -10px ${hexAlpha(c1, 0.75)}` : undefined,
              }}
            >
              {add.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="check-check" className="h-4 w-4" />
              )}
              {add.isPending ? t("acctWorking") : t("acctAddressSave")}
            </Button>
          </form>
        ) : null}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* account sheet — payments panel                                       */
/* ------------------------------------------------------------------ */

export function PaymentsPanel({ instanceId, c1, c2 }: PanelProps) {
  const { t } = useT();
  const { account } = useStoreAccount();
  const apply = useApplyAccount(instanceId);
  const [adding, setAdding] = useState(false);

  const [number, setNumber] = useState("");
  const [holder, setHolder] = useState("");
  const [expMonth, setExpMonth] = useState<number>(new Date().getMonth() + 1);
  const [expYear, setExpYear] = useState<number>(Number(String(new Date().getFullYear()).slice(-2)));
  const [isDefault, setIsDefault] = useState(false);

  const methods = account?.paymentMethods ?? [];
  const digits = number.replace(/\D/g, "");
  const preview = detectBrandPreview(digits);
  const previewMeta = BRAND_META[preview] ?? BRAND_META.card;

  const currentYY = Number(String(new Date().getFullYear()).slice(-2));
  const yearOptions = Array.from({ length: 11 }, (_, i) => currentYY + i);

  const formValid = digits.length >= 12 && holder.trim().length >= 2;

  const remove = useMutation({
    mutationFn: (methodId: string) => deleteStorePaymentMethod(instanceId, methodId),
    onSuccess: (next) => {
      apply(next);
      toast.success(t("acctCardDeletedToast"));
    },
    onError: (e: Error) => toast.error(mapAccountError(e, t)),
  });

  const add = useMutation({
    mutationFn: () =>
      addStorePaymentMethod(instanceId, {
        number: digits,
        holder: holder.trim(),
        expMonth,
        expYear,
        isDefault,
      }),
    onSuccess: (next) => {
      apply(next);
      toast.success(t("acctCardSavedToast"));
      setAdding(false);
      setNumber("");
      setHolder("");
      setIsDefault(false);
    },
    onError: (e: Error) => toast.error(mapAccountError(e, t)),
  });

  return (
    <div className="space-y-3">
      {methods.length === 0 && !adding ? (
        <AcctEmptyState
          icon="credit-card"
          title={t("acctPaymentsEmptyTitle")}
          desc={t("acctPaymentsEmptyDesc")}
          c1={c1}
          c2={c2}
        />
      ) : null}

      {methods.length > 0 ? (
        <ul className="space-y-2.5">
          {methods.map((pm, i: number) => {
            const meta = BRAND_META[pm.brand] ?? BRAND_META.card;
            return (
              <li
                key={pm.id}
                className="card-in overflow-hidden rounded-2xl border border-slate-200 shadow-soft dark:border-white/10"
                style={{ "--i": Math.min(i, 5) } as CSSProperties}
              >
                {/* the card face */}
                <div
                  className="relative flex h-[104px] flex-col justify-between p-3.5 text-white"
                  style={{ backgroundImage: meta.gradient }}
                >
                  <span
                    aria-hidden="true"
                    className="pointer-events-none absolute -top-10 end-[-6%] h-24 w-24 rounded-full bg-white/10 blur-xl"
                  />
                  <span
                    aria-hidden="true"
                    className="pointer-events-none absolute -bottom-12 start-[18%] h-20 w-20 rounded-full bg-black/10 blur-lg"
                  />
                  <div className="relative flex items-center justify-between gap-2">
                    <span className="inline-flex items-center gap-1.5 text-[11px] font-extrabold">
                      <CatIcon name="credit-card" className="h-3.5 w-3.5" />
                      {t(meta.labelKey)}
                    </span>
                    {pm.isDefault ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-white/20 px-2 py-0.5 text-[9.5px] font-black backdrop-blur-sm">
                        <CatIcon name="badge-check" className="h-3 w-3" />
                        {t("acctCardDefaultBadge")}
                      </span>
                    ) : null}
                  </div>
                  <p dir="ltr" className="relative text-start font-mono text-[15px] font-black tracking-[0.18em]">
                    •••• •••• •••• {pm.last4}
                  </p>
                  <div className="relative flex items-end justify-between gap-3">
                    <p className="truncate text-[10px] font-bold uppercase tracking-wide opacity-90">
                      {pm.holder}
                    </p>
                    <p dir="ltr" className="shrink-0 font-mono text-[11px] font-extrabold opacity-90">
                      {String(pm.expMonth).padStart(2, "0")}/{pm.expYear}
                    </p>
                  </div>
                </div>
                {/* actions */}
                <div className="flex items-center justify-end gap-1.5 border-t border-slate-200/70 bg-white px-3 py-2 dark:border-white/10 dark:bg-white/[0.03]">
                  <ConfirmDeletePopover
                    triggerLabel={`${t("acctAddressDelete")} — ${pm.last4}`}
                    itemLabel={`•••• ${pm.last4}`}
                    itemIcon="credit-card"
                    confirmLabel={t("acctAddressDelete")}
                    pending={remove.isPending}
                    onConfirm={() => remove.mutate(pm.id)}
                  />
                </div>
              </li>
            );
          })}
        </ul>
      ) : null}

      {/* collapsible add-card card */}
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-soft dark:border-white/10 dark:bg-white/[0.03]">
        <button
          type="button"
          onClick={() => setAdding((v) => !v)}
          aria-expanded={adding}
          aria-label={t("acctAddCard")}
          className="flex h-11 w-full items-center gap-2.5 px-3.5 text-[12.5px] font-extrabold text-slate-700 transition hover:bg-slate-50 active:scale-[0.99] dark:text-slate-200 dark:hover:bg-white/[0.04]"
        >
          <span
            className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-white"
            style={{ backgroundImage: grad(c1, c2) }}
          >
            <CatIcon name={adding ? "x" : "plus"} className="h-3.5 w-3.5" />
          </span>
          {t("acctAddCard")}
        </button>

        {adding ? (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (formValid) add.mutate();
            }}
            className="space-y-3 border-t border-slate-200/70 p-3.5 dark:border-white/10"
            noValidate
          >
            <AcctField id="acct-card-number" label={t("acctCardNumber")} required>
              <div className="relative">
                <Input
                  id="acct-card-number"
                  dir="ltr"
                  value={number}
                  onChange={(e) => setNumber(formatCardNumber(e.target.value))}
                  placeholder={t("acctCardNumberPh")}
                  inputMode="numeric"
                  autoComplete="cc-number"
                  maxLength={23}
                  disabled={add.isPending}
                  className="h-11 rounded-xl bg-white ps-10 text-start font-mono text-[13px] font-bold tracking-wider dark:bg-white/[0.04]"
                />
                <span
                  aria-hidden="true"
                  className="pointer-events-none absolute start-2 top-1/2 grid h-7 w-7 -translate-y-1/2 place-items-center rounded-lg text-[8px] font-black text-white"
                  style={{ backgroundImage: previewMeta.gradient }}
                  title={t(previewMeta.labelKey)}
                >
                  {digits.length > 0 ? t(previewMeta.labelKey).slice(0, 2) : ""}
                </span>
              </div>
              {digits.length >= 1 ? (
                <p className="text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                  {t(previewMeta.labelKey)}
                </p>
              ) : null}
            </AcctField>
            <AcctField id="acct-card-holder" label={t("acctCardHolder")} required>
              <Input
                id="acct-card-holder"
                value={holder}
                onChange={(e) => setHolder(e.target.value)}
                maxLength={60}
                autoComplete="cc-name"
                disabled={add.isPending}
                className="h-11 rounded-xl"
              />
            </AcctField>
            <div>
              <p className="text-[12px] font-bold">{t("acctCardExpiry")}</p>
              <div className="mt-1.5 grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="acct-card-month" className="sr-only">
                    {t("acctCardMonth")}
                  </Label>
                  <Select
                    value={String(expMonth)}
                    onValueChange={(v) => setExpMonth(Number(v))}
                    disabled={add.isPending}
                  >
                    <SelectTrigger id="acct-card-month" aria-label={t("acctCardMonth")} className="h-11 rounded-xl">
                      <span dir="ltr" className="text-start font-mono text-[13px] font-bold">
                        {String(expMonth).padStart(2, "0")}
                      </span>
                    </SelectTrigger>
                    <SelectContent className="z-[130]">
                      {Array.from({ length: 12 }, (_, i) => i + 1).map((m) => (
                        <SelectItem key={m} value={String(m)}>
                          <span dir="ltr" className="font-mono">
                            {String(m).padStart(2, "0")}
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="acct-card-year" className="sr-only">
                    {t("acctCardYear")}
                  </Label>
                  <Select
                    value={String(expYear)}
                    onValueChange={(v) => setExpYear(Number(v))}
                    disabled={add.isPending}
                  >
                    <SelectTrigger id="acct-card-year" aria-label={t("acctCardYear")} className="h-11 rounded-xl">
                      <span dir="ltr" className="text-start font-mono text-[13px] font-bold">
                        {expYear}
                      </span>
                    </SelectTrigger>
                    <SelectContent className="z-[130]">
                      {yearOptions.map((y) => (
                        <SelectItem key={y} value={String(y)}>
                          <span dir="ltr" className="font-mono">
                            {y}
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2.5">
              <Checkbox
                id="acct-card-default"
                checked={isDefault}
                onCheckedChange={(v) => setIsDefault(v === true)}
                disabled={add.isPending}
              />
              <Label htmlFor="acct-card-default" className="cursor-pointer text-[12px] font-bold">
                {t("acctCardMakeDefault")}
              </Label>
            </div>

            <Button
              type="submit"
              disabled={!formValid || add.isPending}
              className="h-11 w-full gap-2 rounded-xl text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.99] disabled:opacity-60"
              style={{
                backgroundImage: grad(c1, c2),
                boxShadow: formValid ? `0 12px 26px -10px ${hexAlpha(c1, 0.75)}` : undefined,
              }}
            >
              {add.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="check-check" className="h-4 w-4" />
              )}
              {add.isPending ? t("acctWorking") : t("acctCardSave")}
            </Button>
          </form>
        ) : null}
      </div>

      {/* PCI-safe security note */}
      <p className="flex items-start gap-2 rounded-2xl border border-emerald-200/70 bg-emerald-500/[0.06] px-3.5 py-2.5 text-[10.5px] font-semibold leading-relaxed text-emerald-700 dark:border-emerald-500/25 dark:bg-emerald-500/10 dark:text-emerald-300">
        <CatIcon name="shield-check" className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
        {t("acctCardSecurityNote")}
      </p>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* account sheet — orders panel                                         */
/* ------------------------------------------------------------------ */

/** ROUND 147 — compact per-step stamp (the tracking card's law): time-only
 * when the transition happened today, short date + time otherwise. */
function fmtOrderStep(lang: Lang, iso: string): string {
  try {
    const d = new Date(iso);
    const sameDay = new Date().toDateString() === d.toDateString();
    return new Intl.DateTimeFormat(intlLocale(lang), {
      ...(sameDay ? {} : { day: "numeric", month: "short" }),
      hour: "2-digit",
      minute: "2-digit",
    }).format(d);
  } catch {
    return iso.slice(11, 16);
  }
}

/**
 * ROUND 147 — one EXPANDABLE order row: the collapsed summary (status chip
 * + #code + date + items line + total) is the expand BUTTON itself (spans
 * only — valid phrasing content); the expanded area reveals the full order
 * anatomy: per-item rows with photos, the totals block, the customer's own
 * note + the store's status note, the TRACK_FLOW timeline with per-step
 * timestamps from statusHistory, and the printable receipt affordance.
 */
function OrderRow({
  order,
  index,
  c1,
  expanded,
  onToggle,
  onReceipt,
}: {
  order: SiteOrderDTO;
  index: number;
  c1: string;
  expanded: boolean;
  onToggle: () => void;
  onReceipt: () => void;
}) {
  const { t, lang } = useT();
  const sep = lang === "ar" ? "، " : ", ";
  const meta = TRACK_STEP_META[order.status];
  const code = `#${order.code ?? order.id.slice(0, 8).toUpperCase()}`;
  const parts = order.items
    .slice(0, 3)
    .map((item) => `${item.name} × ${nf(lang, item.qty)}`);
  const extra = order.items.length - 3;
  const itemsLine =
    parts.join(sep) + (extra > 0 ? ` +${nf(lang, extra)}` : "");
  const panelId = `order-detail-${order.id}`;

  /* the persistent lifecycle trail drives the timeline: each step shows
   * WHEN it happened (latest occurrence — open states can revisit). */
  const history = order.statusHistory ?? [];
  const stepAt = new Map<string, string>();
  for (const ev of history) stepAt.set(ev.status, ev.at);

  return (
    <li
      className="card-in rounded-2xl border border-slate-200 bg-white shadow-soft dark:border-white/10 dark:bg-white/[0.03]"
      style={{ "--i": Math.min(index, 5) } as CSSProperties}
    >
      {/* ---------- the collapsed row IS the expand button ---------- */}
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={expanded}
        aria-controls={panelId}
        className="block w-full rounded-2xl p-3.5 text-start transition hover:bg-slate-50/70 focus-visible:outline-2 focus-visible:outline-offset-[-2px] dark:hover:bg-white/[0.04]"
      >
        <span className="sr-only">
          {expanded ? t("acctOrderHideDetail") : t("acctOrderDetail")}
        </span>
        {/* status chip + #code — wrap safely on narrow screens (RTL-safe) */}
        <span className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1.5">
          <span
            className={cn(
              "inline-flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10.5px] font-extrabold",
              meta.current
            )}
          >
            <CatIcon name={meta.icon} className="h-3 w-3" />
            {t(ORDER_STATUS_KEY[order.status])}
          </span>
          <span className="flex min-w-0 items-center gap-1.5">
            <code
              dir="ltr"
              className="min-w-0 truncate font-mono text-[11px] font-black tracking-wider"
              style={{ color: c1 }}
            >
              {code}
            </code>
            <CatIcon
              name="chevron-down"
              className={cn(
                "h-4 w-4 shrink-0 text-slate-400 transition-transform duration-300 dark:text-slate-500",
                expanded && "rotate-180"
              )}
            />
          </span>
        </span>
        <span className="mt-2.5 flex min-w-0 flex-wrap items-center gap-x-1.5 gap-y-0.5 text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
          <CatIcon name="calendar" className="h-3 w-3 shrink-0" />
          <span className="min-w-0 truncate">
            {t("acctOrderPlaced")}: {fullDate(order.createdAt, lang)}
          </span>
        </span>
        <span className="mt-2 block">
          <span className="block text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500">
            {t("acctOrderItems")}
          </span>
          <span className="mt-0.5 block text-[12px] font-semibold leading-relaxed text-slate-600 dark:text-slate-300">
            {itemsLine}
          </span>
        </span>
        <span className="mt-2.5 flex items-center justify-between gap-3 border-t border-dashed border-slate-200 pt-2.5 dark:border-white/10">
          <span className="text-[11px] font-extrabold text-slate-500 dark:text-slate-400">
            {t("storeCartTotal")}
          </span>
          <span
            dir="ltr"
            className="font-display text-[14px] font-black tabular-nums"
            style={{ color: c1 }}
          >
            {fmtPrice(lang, order.total, order.currency)}
          </span>
        </span>
      </button>

      {/* ---------- the expanded anatomy ---------- */}
      {expanded ? (
        <div id={panelId} className="space-y-4 border-t border-dashed border-slate-200 p-3.5 pt-3 dark:border-white/10">
          {/* (1) per-item rows — the product photo AS ORDERED (placement
                  snapshot) with a themed initial tile when none exists */}
          <div>
            <p className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              {t("trackItems")}
            </p>
            <ul className="mt-1.5 space-y-1.5">
              {order.items.map((item, i) => (
                <li
                  key={`${item.recordId}-${i}`}
                  className="flex flex-wrap items-center gap-2.5 rounded-xl border border-slate-200/60 bg-slate-50/60 px-2 py-1.5 transition hover:border-slate-300/80 dark:border-white/[0.06] dark:bg-white/[0.02] dark:hover:border-white/15"
                >
                  {item.image ? (
                    <span className="h-10 w-10 shrink-0 overflow-hidden rounded-lg border border-slate-200/80 dark:border-white/10">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={item.image}
                        alt={item.name}
                        loading="lazy"
                        decoding="async"
                        className="h-full w-full object-cover"
                      />
                    </span>
                  ) : (
                    <span
                      className="grid h-10 w-10 shrink-0 place-items-center rounded-lg border text-[13px] font-black"
                      style={{
                        borderColor: hexAlpha(c1, 0.25),
                        backgroundColor: hexAlpha(c1, 0.08),
                        color: c1,
                      }}
                      aria-hidden="true"
                    >
                      {item.name.trim().charAt(0)}
                    </span>
                  )}
                  <span className="min-w-0 flex-1 basis-32 text-[12px] font-bold text-slate-700 dark:text-slate-200">
                    <span className="block truncate">{item.name}</span>
                  </span>
                  <span
                    dir="ltr"
                    className="shrink-0 text-[11px] font-extrabold tabular-nums text-slate-500 dark:text-slate-400"
                  >
                    ×{nf(lang, item.qty)} · {fmtPrice(lang, item.price, order.currency)}
                  </span>
                  <span
                    dir="ltr"
                    className="shrink-0 text-[12px] font-black tabular-nums text-slate-700 dark:text-slate-200"
                  >
                    {fmtPrice(lang, item.price * item.qty, order.currency)}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          {/* (2) totals block — subtotal / discount / coupon / total */}
          <div className="space-y-1.5 rounded-xl border border-slate-200/70 bg-white p-3 dark:border-white/[0.07] dark:bg-white/[0.03]">
            <p className="flex items-center justify-between gap-2 text-[11px] font-bold text-slate-500 dark:text-slate-400">
              <span>{t("storeSubtotal")}</span>
              <span dir="ltr" className="tabular-nums">
                {fmtPrice(lang, order.total + order.discount, order.currency)}
              </span>
            </p>
            {order.discount > 0 ? (
              <p className="flex items-center justify-between gap-2 text-[11px] font-extrabold text-emerald-600 dark:text-emerald-400">
                <span className="inline-flex items-center gap-1.5">
                  <CatIcon name="ticket-percent" className="h-3 w-3" />
                  {t("trackCouponUsed")} {order.couponCode}
                </span>
                <span dir="ltr" className="tabular-nums">
                  −{fmtPrice(lang, order.discount, order.currency)}
                </span>
              </p>
            ) : null}
            <p className="flex items-center justify-between gap-2 border-t border-dashed border-slate-200 pt-1.5 text-[12px] font-black dark:border-white/10">
              <span className="text-slate-600 dark:text-slate-300">{t("storeCartTotal")}</span>
              <span
                dir="ltr"
                className="font-display text-[14px] tabular-nums"
                style={{ color: c1 }}
              >
                {fmtPrice(lang, order.total, order.currency)}
              </span>
            </p>
            <div className="space-y-1 border-t border-dashed border-slate-200 pt-1.5 dark:border-white/10">
              <p className="flex items-center justify-between gap-2 text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                <span>{t("trackPlacedAt")}</span>
                <span dir="ltr" className="tabular-nums">{fullDate(order.createdAt, lang)}</span>
              </p>
              <p className="flex items-center justify-between gap-2 text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                <span>{t("trackUpdated")}</span>
                <span dir="ltr" className="tabular-nums">{fullDate(order.updatedAt, lang)}</span>
              </p>
            </div>
          </div>

          {/* (3) the customer's own note + the store's status note */}
          {order.note ? (
            <p className="flex items-start gap-2 rounded-xl bg-slate-500/[0.07] px-3 py-2 text-[11.5px] font-semibold leading-relaxed text-slate-600 dark:bg-white/[0.05] dark:text-slate-300">
              <CatIcon name="notebook-pen" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-slate-400" />
              <span className="min-w-0">
                <span className="font-extrabold text-slate-500 dark:text-slate-400">{t("storeOrderNote")}: </span>
                {order.note}
              </span>
            </p>
          ) : null}

          {/* (4) the timeline — TRACK_FLOW steps with per-step timestamps
                  from statusHistory (the tracking card's visual language:
                  icon tile + label + time; done vs current vs pending;
                  the terminal cancelled state renders its own card). */}
          <div>
            <p className="flex items-center gap-1.5 text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              <CatIcon name="route" className="h-3.5 w-3.5" />
              {t("acctOrderTimeline")}
            </p>
            {order.status === "cancelled" ? (
              <div
                className={cn(
                  "mt-2 flex items-center gap-3 rounded-2xl border px-4 py-3.5",
                  TRACK_STEP_META.cancelled.current
                )}
              >
                <CatIcon name="circle-x" className="h-5 w-5 shrink-0" />
                <div className="min-w-0">
                  <p className="text-[13px] font-extrabold">{t(ORDER_STATUS_KEY.cancelled)}</p>
                  {order.statusNote ? (
                    <p className="mt-0.5 text-[11.5px] font-semibold opacity-80">{order.statusNote}</p>
                  ) : null}
                  {stepAt.get("cancelled") ? (
                    <p dir="ltr" className="mt-1 text-start text-[10.5px] font-bold tabular-nums opacity-70">
                      {fmtOrderStep(lang, stepAt.get("cancelled") as string)}
                    </p>
                  ) : null}
                </div>
              </div>
            ) : (
              <ol className="mt-2.5 space-y-3">
                {TRACK_FLOW.map((step, i) => {
                  const stepMeta = TRACK_STEP_META[step];
                  const at = stepAt.get(step);
                  const isDone = at != null;
                  const isCurrent = order.status === step;
                  const nextReached =
                    i < TRACK_FLOW.length - 1 && stepAt.has(TRACK_FLOW[i + 1]);
                  return (
                    <li key={step} className="relative flex items-start gap-3">
                      {/* connector to the next step (emerald when reached) */}
                      {i < TRACK_FLOW.length - 1 ? (
                        <span
                          aria-hidden="true"
                          className={cn(
                            "absolute start-[17px] top-[36px] bottom-[-12px] w-0.5 rounded-full",
                            nextReached
                              ? "bg-emerald-400/70"
                              : "bg-slate-200 dark:bg-white/10"
                          )}
                        />
                      ) : null}
                      <span
                        className={cn(
                          "relative grid h-9 w-9 shrink-0 place-items-center rounded-xl border-2 transition",
                          isDone
                            ? stepMeta.done
                            : "border-slate-200 bg-white text-slate-300 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-600",
                          isCurrent && "scale-110 shadow-lg",
                          isCurrent && stepMeta.current
                        )}
                      >
                        <CatIcon name={stepMeta.icon} className="h-4 w-4" />
                      </span>
                      <div className="min-w-0 flex-1 pt-1">
                        <p
                          className={cn(
                            "text-[12px] font-extrabold leading-tight",
                            isCurrent
                              ? "text-slate-700 dark:text-slate-200"
                              : isDone
                                ? "text-slate-600 dark:text-slate-300"
                                : "text-slate-400 dark:text-slate-500"
                          )}
                        >
                          {t(ORDER_STATUS_KEY[step])}
                        </p>
                        {at ? (
                          <p
                            dir="ltr"
                            className="mt-0.5 text-start text-[10px] font-bold tabular-nums text-slate-400 dark:text-slate-500"
                          >
                            {fmtOrderStep(lang, at)}
                          </p>
                        ) : null}
                      </div>
                    </li>
                  );
                })}
              </ol>
            )}
            {order.status !== "cancelled" && order.statusNote ? (
              <p className="mt-3 flex items-start gap-2 rounded-xl bg-sky-500/10 px-3 py-2 text-[11.5px] font-semibold leading-relaxed text-sky-700 dark:text-sky-300">
                <CatIcon name="info" className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                <span className="min-w-0">
                  <span className="font-extrabold">{t("ordStatusNoteLabel")}: </span>
                  {order.statusNote}
                </span>
              </p>
            ) : null}
          </div>

          {/* (5) the printable receipt — the SAME dialog the public tracking
                  card prints through (the member order carries unit prices,
                  so the paper is invoice-grade; NO receiptToken → no share
                  link, no QR — nothing is invented). */}
          <div className="flex flex-wrap items-center justify-end gap-2">
            <button
              type="button"
              onClick={onReceipt}
              title={t("acctOrderReceipt")}
              className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 text-[11.5px] font-extrabold text-slate-600 shadow-sm transition hover:border-slate-300 hover:text-slate-800 active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:border-white/25 dark:hover:text-white"
            >
              <CatIcon name="printer" className="h-3.5 w-3.5" />
              {t("acctOrderReceipt")}
            </button>
          </div>
        </div>
      ) : null}
    </li>
  );
}

export function OrdersPanel({ instanceId, c1, c2, orgName, logoUrl }: PanelProps) {
  const { t } = useT();
  const { signedIn } = useStoreAccount();

  /* ROUND 147 — ONE expanded row at a time (accordion discipline keeps the
   * history scannable) + the printable receipt target. */
  const [openId, setOpenId] = useState<string | null>(null);
  const [receiptFor, setReceiptFor] = useState<SiteOrderDTO | null>(null);

  /* mounts ONLY when the Orders tab is active (Radix unmounts inactive tab
   * panels) — the history query therefore runs exactly on demand */
  const ordersQuery = useQuery({
    queryKey: ["store-orders", instanceId],
    queryFn: () => fetchStoreAccountOrders(instanceId),
    enabled: signedIn,
    staleTime: 15_000,
    retry: 0,
  });

  if (ordersQuery.isPending) {
    return (
      <div className="space-y-2.5">
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-32 rounded-2xl" />
        ))}
      </div>
    );
  }

  if (ordersQuery.isError) {
    return (
      <div className="rounded-2xl border border-rose-300/60 bg-rose-500/10 p-5 text-center dark:border-rose-500/30">
        <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-rose-500/15 text-rose-500">
          <CatIcon name="circle-x" className="h-5 w-5" />
        </div>
        <p className="mt-3 text-[12.5px] font-bold leading-relaxed text-rose-600 dark:text-rose-300">
          {mapAccountError(ordersQuery.error, t)}
        </p>
        <button
          type="button"
          onClick={() => void ordersQuery.refetch()}
          className="mt-4 inline-flex h-10 items-center gap-1.5 rounded-xl border border-rose-300 bg-white px-4 text-[11.5px] font-extrabold text-rose-600 transition hover:bg-rose-50 active:scale-95 dark:border-rose-500/40 dark:bg-transparent dark:text-rose-300 dark:hover:bg-rose-500/10"
        >
          <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
          {t("errTryAgain")}
        </button>
      </div>
    );
  }

  const orders: SiteOrderDTO[] = ordersQuery.data ?? [];

  if (orders.length === 0) {
    return (
      <AcctEmptyState
        icon="package"
        title={t("acctOrdersEmptyTitle")}
        desc={t("acctOrdersEmptyDesc")}
        c1={c1}
        c2={c2}
      />
    );
  }

  /* the receipt letterhead identity (the member page passes the org's
   * display name + logo; sheet mounts fall back to the store badge). */
  const receiptIdentity: ReceiptIdentity = {
    orgName: orgName?.trim() || t("storeBadge"),
    logoUrl: logoUrl ?? null,
    c1,
    c2,
    orgContact: null,
  };
  const receiptData: OrderReceiptData | null = receiptFor
    ? {
        code: receiptFor.code ?? receiptFor.id.slice(0, 8).toUpperCase(),
        items: receiptFor.items.map((it) => ({
          name: it.name,
          qty: it.qty,
          unitPrice: it.price,
        })),
        total: receiptFor.total,
        discount: receiptFor.discount,
        couponCode: receiptFor.couponCode,
        currency: receiptFor.currency,
        status: receiptFor.status,
        statusHistory: receiptFor.statusHistory,
        createdAt: receiptFor.createdAt,
        updatedAt: receiptFor.updatedAt,
        note: receiptFor.note,
      }
    : null;

  return (
    <>
      <ul className="space-y-2.5">
        {orders.map((order, i) => (
          <OrderRow
            key={order.id}
            order={order}
            index={i}
            c1={c1}
            expanded={openId === order.id}
            onToggle={() => setOpenId((prev) => (prev === order.id ? null : order.id))}
            onReceipt={() => setReceiptFor(order)}
          />
        ))}
      </ul>

      {/* the shared printable receipt (same paper as the public tracking
          card — thermal style, .print-doc print root, window.print()) */}
      <OrderReceiptDialog
        open={receiptFor !== null}
        onOpenChange={(open) => {
          if (!open) setReceiptFor(null);
        }}
        identity={receiptIdentity}
        data={receiptData}
      />
    </>
  );
}

/* ------------------------------------------------------------------ */
/* account sheet — inquiries panel (ROUND 73)                           */
/* ------------------------------------------------------------------ */

/** one inquiry row — status chip + category, the message (clamped with a
 * gentle expand), dates, and the organization's reply in an emerald card.
 * High/urgent priorities carry a pulsing rose dot beside the status. */
function InquiryCard({
  inquiry,
  index,
  c1,
}: {
  inquiry: SiteInquiryDTO;
  index: number;
  c1: string;
}) {
  const { t, lang } = useT();
  const [expanded, setExpanded] = useState(false);
  const meta = INQUIRY_STATUS_META[inquiry.status] ?? INQUIRY_STATUS_META.open;
  const catKey = INQUIRY_CATEGORY_KEY[inquiry.category];
  const hot = inquiry.priority === "high" || inquiry.priority === "urgent";
  const long = inquiry.message.length > 180;

  return (
    <li
      className="card-in rounded-2xl border border-slate-200 bg-white p-3.5 shadow-soft dark:border-white/10 dark:bg-white/[0.03]"
      style={{ "--i": Math.min(index, 5) } as CSSProperties}
    >
      {/* status chip + category + hot-priority pulse */}
      <div className="flex flex-wrap items-center gap-1.5">
        <span
          className={cn(
            "inline-flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10.5px] font-extrabold",
            meta.chip
          )}
        >
          <span className="relative flex h-1.5 w-1.5 shrink-0" aria-hidden="true">
            {hot && inquiry.status !== "closed" && inquiry.status !== "resolved" ? (
              <span className={cn("absolute inline-flex h-full w-full animate-ping rounded-full opacity-75", meta.dot)} />
            ) : null}
            <span className={cn("relative inline-flex h-1.5 w-1.5 shrink-0 rounded-full", meta.dot)} />
          </span>
          <CatIcon name={meta.icon} className="h-3 w-3" />
          {t(meta.label)}
        </span>
        {catKey ? (
          <span
            className="inline-flex shrink-0 items-center rounded-full border px-2 py-0.5 text-[9.5px] font-extrabold"
            style={{
              borderColor: hexAlpha(c1, 0.3),
              backgroundColor: hexAlpha(c1, 0.07),
              color: c1,
            }}
          >
            {t(catKey)}
          </span>
        ) : null}
        <span
          className="ms-auto shrink-0 text-[10.5px] font-bold text-slate-400 dark:text-slate-500"
          title={fullDate(inquiry.updatedAt, lang)}
        >
          {relativeTime(inquiry.updatedAt, lang)}
        </span>
      </div>

      {/* subject */}
      <p className="mt-2.5 text-[12.5px] font-extrabold leading-relaxed text-slate-800 dark:text-slate-100">
        {inquiry.subject}
      </p>

      {/* the customer's own message — clamped until expanded */}
      <p
        className={cn(
          "mt-1 text-[12px] font-semibold leading-relaxed text-slate-600 dark:text-slate-300",
          !expanded && long && "line-clamp-3"
        )}
      >
        {inquiry.message}
      </p>
      {long ? (
        <button
          type="button"
          onClick={() => setExpanded((v) => !v)}
          aria-expanded={expanded}
          className="mt-1 inline-flex h-7 items-center gap-1 rounded-lg px-1.5 text-[10.5px] font-extrabold transition hover:brightness-110 active:scale-95"
          style={{ color: c1 }}
        >
          <CatIcon
            name="chevron-down"
            className={cn("h-3 w-3 transition-transform", expanded && "rotate-180")}
          />
          {t(expanded ? "acctInqLess" : "acctInqMore")}
        </button>
      ) : null}

      {/* the organization's reply — the emerald moment of the tab */}
      {inquiry.reply && inquiry.reply.trim().length > 0 ? (
        <div
          className={cn(
            "mt-2.5 rounded-xl border px-3 py-2.5",
            inquiry.fresh
              ? "border-amber-300/60 bg-gradient-to-l from-amber-500/[0.1] to-orange-500/[0.07] shadow-sm dark:border-amber-500/40 dark:from-amber-500/[0.12] dark:to-orange-500/[0.08]"
              : "border-emerald-300/50 bg-gradient-to-l from-emerald-500/[0.08] to-teal-500/[0.06] dark:border-emerald-500/30 dark:from-emerald-500/[0.1] dark:to-teal-500/[0.08]"
          )}
        >
          <p
            className={cn(
              "flex flex-wrap items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-wide",
              inquiry.fresh
                ? "text-amber-600 dark:text-amber-300"
                : "text-emerald-600 dark:text-emerald-300"
            )}
          >
            <CatIcon name="message-square" className="h-3 w-3 shrink-0" />
            {t("acctInqReply")}
            {inquiry.fresh ? (
              <span className="inline-flex items-center gap-1 rounded-full border border-amber-400/70 bg-amber-400/20 px-1.5 py-0.5 text-[9px] font-extrabold normal-case tracking-normal text-amber-700 dark:border-amber-400/50 dark:bg-amber-400/15 dark:text-amber-200">
                <span className="relative flex h-1.5 w-1.5" aria-hidden="true">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-amber-400 opacity-75" />
                  <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-amber-500" />
                </span>
                {t("acctInqNew")}
              </span>
            ) : null}
          </p>
          <p
            className={cn(
              "mt-1 whitespace-pre-line text-[12px] font-semibold leading-relaxed",
              inquiry.fresh
                ? "text-amber-900 dark:text-amber-100"
                : "text-emerald-800 dark:text-emerald-200"
            )}
          >
            {inquiry.reply}
          </p>
        </div>
      ) : null}

      {/* dates footer */}
      <div className="mt-2.5 flex items-center justify-between gap-3 border-t border-dashed border-slate-200 pt-2.5 text-[10px] font-bold text-slate-400 dark:border-white/10 dark:text-slate-500">
        <span className="flex items-center gap-1">
          <CatIcon name="calendar" className="h-3 w-3 shrink-0" />
          {t("acctInqPlaced")}: {fullDate(inquiry.createdAt, lang)}
        </span>
        {inquiry.updatedAt !== inquiry.createdAt ? (
          <span className="flex items-center gap-1">
            <CatIcon name="refresh-cw" className="h-3 w-3 shrink-0" />
            {t("acctInqUpdated")}
          </span>
        ) : null}
      </div>
    </li>
  );
}

/** ROUND 73 — the "استفساراتي" panel: the signed-in customer's own support
 * history (blind-index matched server-side). A summary strip of status
 * counts rides the top; rows newest-activity first. */
export function InquiriesPanel({ instanceId, c1, c2 }: PanelProps) {
  const { t, lang } = useT();
  const { signedIn } = useStoreAccount();
  const queryClient = useQueryClient();

  /* mounts ONLY when the tab is active (Radix unmounts inactive panels) */
  const inquiriesQuery = useQuery({
    queryKey: ["store-inquiries", instanceId],
    queryFn: () => fetchStoreAccountInquiries(instanceId),
    enabled: signedIn,
    staleTime: 15_000,
    retry: 0,
  });

  /* ROUND 74 — the history GET marks the org's replies as read; re-probe
   * the account so the amber badge on the header button clears as soon as
   * the customer has actually seen the answers. */
  const historyLoaded = inquiriesQuery.data;
  useEffect(() => {
    if (historyLoaded && historyLoaded.unreadCount > 0) {
      void queryClient.invalidateQueries({ queryKey: ["store-account", instanceId] });
    }
  }, [historyLoaded, queryClient, instanceId]);

  if (inquiriesQuery.isPending) {
    return (
      <div className="space-y-2.5">
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-36 rounded-2xl" />
        ))}
      </div>
    );
  }

  if (inquiriesQuery.isError) {
    return (
      <div className="rounded-2xl border border-rose-300/60 bg-rose-500/10 p-5 text-center dark:border-rose-500/30">
        <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-rose-500/15 text-rose-500">
          <CatIcon name="circle-x" className="h-5 w-5" />
        </div>
        <p className="mt-3 text-[12.5px] font-bold leading-relaxed text-rose-600 dark:text-rose-300">
          {mapAccountError(inquiriesQuery.error, t)}
        </p>
        <button
          type="button"
          onClick={() => void inquiriesQuery.refetch()}
          className="mt-4 inline-flex h-10 items-center gap-1.5 rounded-xl border border-rose-300 bg-white px-4 text-[11.5px] font-extrabold text-rose-600 transition hover:bg-rose-50 active:scale-95 dark:border-rose-500/40 dark:bg-transparent dark:text-rose-300 dark:hover:bg-rose-500/10"
        >
          <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
          {t("errTryAgain")}
        </button>
      </div>
    );
  }

  const inquiries: SiteInquiryDTO[] = inquiriesQuery.data?.inquiries ?? [];

  if (inquiries.length === 0) {
    return (
      <AcctEmptyState
        icon="message-square"
        title={t("acctInqEmptyTitle")}
        desc={t("acctInqEmptyDesc")}
        c1={c1}
        c2={c2}
      />
    );
  }

  /* status summary strip — counts over the four lifecycle states */
  const counts = new Map<string, number>();
  for (const q of inquiries) counts.set(q.status, (counts.get(q.status) ?? 0) + 1);
  const summary = (["open", "pending", "resolved", "closed"] as const)
    .map((status) => ({ status, n: counts.get(status) ?? 0 }))
    .filter((entry) => entry.n > 0);

  return (
    <div className="space-y-2.5">
      {summary.length > 1 ? (
        <div className="flex flex-wrap items-center gap-1.5">
          {summary.map(({ status, n }) => {
            const meta = INQUIRY_STATUS_META[status];
            return (
              <span
                key={status}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-extrabold",
                  meta.chip
                )}
              >
                <CatIcon name={meta.icon} className="h-3 w-3" />
                {t(meta.label)}
                <span dir="ltr" className="tabular-nums opacity-80">
                  {nf(lang, n)}
                </span>
              </span>
            );
          })}
        </div>
      ) : null}
      <ul className="space-y-2.5">
        {inquiries.map((inquiry, i) => (
          <InquiryCard key={inquiry.id} inquiry={inquiry} index={i} c1={c1} />
        ))}
      </ul>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* account sheet                                                        */
/* ------------------------------------------------------------------ */

/**
 * The signed-in account home. Follows the cart/wishlist sheet conventions
 * exactly: language-aware side, w-full on mobile / sm:max-w-md on desktop,
 * themed gradient header (pe-14 clears the floating close), nice-scroll
 * body, fixed chrome (header + tab nav + sign-out footer).
 */
export function StoreAccountSheet({
  open,
  onOpenChange,
  instanceId,
  c1,
  c2,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  instanceId: string;
  c1: string;
  c2: string;
}) {
  const { t, lang } = useT();
  const { account, signedIn, signOut } = useStoreAccount();
  const [tab, setTab] = useState("profile");

  /* reset to the profile tab every time the sheet opens (previous-value
   * pattern — react-hooks v7 clean, no setState-in-effect).
   * ROUND 141 — the sheet-request bus is retired (the live-reply toast
   * navigates to the member's dedicated profile page now); the sheet stays
   * a valid exported surface for any legacy mount. */
  const [prevOpen, setPrevOpen] = useState(open);
  if (open !== prevOpen) {
    setPrevOpen(open);
    if (open) {
      setTab("profile");
    }
  }

  /* hold the last signed-in snapshot so the exit animation never flashes an
   * empty shell (sign-out flips the cache while the sheet is closing) */
  const [shown, setShown] = useState<StoreAccountDTO | null>(account);
  const [prevAccount, setPrevAccount] = useState<StoreAccountDTO | null>(account);
  if (account !== prevAccount) {
    setPrevAccount(account);
    if (account) setShown(account);
  }
  const acct = account ?? shown;

  const signOutMut = useMutation({
    mutationFn: signOut,
    onSuccess: () => {
      toast.success(t("acctSignedOutToast"));
      onOpenChange(false);
    },
    onError: (e: Error) => toast.error(mapAccountError(e, t)),
  });

  const TABS: { value: string; icon: string; label: string }[] = [
    { value: "profile", icon: "user-round", label: t("acctTabProfile") },
    { value: "addresses", icon: "map-pin", label: t("acctTabAddresses") },
    { value: "payments", icon: "credit-card", label: t("acctTabPayments") },
    { value: "orders", icon: "package", label: t("acctTabOrders") },
    /* ROUND 73 — the unified account's own support history */
    { value: "inquiries", icon: "message-square", label: t("acctTabInquiries") },
  ];

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side={lang === "ar" ? "right" : "left"}
        className="flex w-full flex-col gap-0 overflow-hidden p-0 sm:max-w-md"
      >
        {/* themed header — pe-14 clears the sheet's floating close (X) */}
        <SheetHeader
          className="space-y-0 border-b border-slate-200/70 px-5 pb-4 pt-5 pe-14 dark:border-white/[0.07]"
          style={{
            backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.14)}, ${hexAlpha(c2, 0.1)} 60%, transparent)`,
          }}
        >
          <SheetTitle className="flex items-center gap-3">
            {acct ? (
              <AcctAvatar name={acct.name} c1={c1} c2={c2} avatarUrl={acct.avatarUrl} />
            ) : (
              <Skeleton className="h-14 w-14 rounded-full" />
            )}
            <span className="min-w-0 flex-1">
              <span className="flex items-center gap-2">
                <span className="truncate font-display text-[15px] font-extrabold text-slate-900 dark:text-white" title={acct?.name}>
                  {acct ? acct.name : t("acctSheetTitle")}
                </span>
                <span
                  className="inline-flex shrink-0 items-center gap-1 rounded-full border px-2 py-0.5 text-[9.5px] font-extrabold"
                  style={{
                    borderColor: hexAlpha(c1, 0.35),
                    backgroundColor: hexAlpha(c1, 0.08),
                    color: c1,
                  }}
                >
                  <CatIcon name="badge-check" className="h-3 w-3" />
                  {t("acctWelcome")}
                </span>
                {/* ROUND 75 — the email's verification state, always visible */}
                {acct ? (
                  <span
                    className={cn(
                      "inline-flex shrink-0 items-center gap-1 rounded-full border px-2 py-0.5 text-[9.5px] font-extrabold",
                      acct.emailVerified
                        ? "border-emerald-300/60 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
                        : "border-amber-300/70 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300"
                    )}
                    title={acct.emailVerified ? t("acctVerifiedChip") : t("acctUnverifiedChipHint")}
                  >
                    <CatIcon
                      name={acct.emailVerified ? "badge-check" : "mail-warning"}
                      className="h-3 w-3"
                    />
                    {t(acct.emailVerified ? "acctVerifiedChip" : "acctUnverifiedChip")}
                  </span>
                ) : null}
              </span>
              {acct ? (
                <>
                  <span dir="ltr" className="mt-0.5 block truncate text-start text-[11px] font-bold text-slate-500 dark:text-slate-400">
                    {acct.email}
                  </span>
                  <span className="mt-0.5 flex items-center gap-1.5 text-[10px] font-bold text-slate-400 dark:text-slate-500">
                    <CatIcon name="calendar-days" className="h-3 w-3 shrink-0" />
                    <span className="truncate">
                      {t("acctSheetMemberSince", { date: fullDate(acct.createdAt, lang) })}
                    </span>
                  </span>
                </>
              ) : null}
            </span>
          </SheetTitle>
          <SheetDescription className="sr-only">{t("acctSheetTitle")}</SheetDescription>
        </SheetHeader>

        {/* tab nav — fixed chrome above the scroll area */}
        <Tabs
          value={tab}
          onValueChange={setTab}
          className="flex min-h-0 flex-1 flex-col gap-0"
        >
          <div className="shrink-0 border-b border-slate-200/70 px-4 py-2.5 dark:border-white/[0.07]">
            <TabsList className="grid h-auto w-full grid-cols-5 gap-1 rounded-xl bg-slate-100/80 p-1 dark:bg-white/5">
              {TABS.map((entry) => (
                <TabsTrigger
                  key={entry.value}
                  value={entry.value}
                  className="flex h-10 flex-col items-center justify-center gap-0.5 rounded-lg px-0.5 text-[9.5px] font-extrabold text-slate-500 transition data-[state=active]:bg-white data-[state=active]:text-slate-900 data-[state=active]:shadow-sm dark:text-slate-400 dark:data-[state=active]:bg-white/10 dark:data-[state=active]:text-white"
                >
                  <CatIcon name={entry.icon} className="h-3.5 w-3.5" />
                  <span className="w-full truncate text-center">{entry.label}</span>
                </TabsTrigger>
              ))}
            </TabsList>
          </div>

          {/* scrollable body — the established custom scrollbar */}
          <div className="nice-scroll min-h-0 flex-1 overflow-y-auto">
            <TabsContent
              value="profile"
              className="m-0 p-4 data-[state=active]:animate-in data-[state=active]:fade-in-0 data-[state=active]:slide-in-from-bottom-2 duration-300"
            >
              {signedIn || acct ? <ProfilePanel instanceId={instanceId} c1={c1} c2={c2} /> : null}
            </TabsContent>
            <TabsContent
              value="addresses"
              className="m-0 p-4 data-[state=active]:animate-in data-[state=active]:fade-in-0 data-[state=active]:slide-in-from-bottom-2 duration-300"
            >
              {signedIn || acct ? <AddressesPanel instanceId={instanceId} c1={c1} c2={c2} /> : null}
            </TabsContent>
            <TabsContent
              value="payments"
              className="m-0 p-4 data-[state=active]:animate-in data-[state=active]:fade-in-0 data-[state=active]:slide-in-from-bottom-2 duration-300"
            >
              {signedIn || acct ? <PaymentsPanel instanceId={instanceId} c1={c1} c2={c2} /> : null}
            </TabsContent>
            <TabsContent
              value="orders"
              className="m-0 p-4 data-[state=active]:animate-in data-[state=active]:fade-in-0 data-[state=active]:slide-in-from-bottom-2 duration-300"
            >
              {signedIn ? <OrdersPanel instanceId={instanceId} c1={c1} c2={c2} /> : null}
            </TabsContent>
            <TabsContent
              value="inquiries"
              className="m-0 p-4 data-[state=active]:animate-in data-[state=active]:fade-in-0 data-[state=active]:slide-in-from-bottom-2 duration-300"
            >
              {signedIn ? <InquiriesPanel instanceId={instanceId} c1={c1} c2={c2} /> : null}
            </TabsContent>
          </div>
        </Tabs>

        {/* sign-out footer — the store's subtle rose destructive style */}
        <div className="shrink-0 border-t border-slate-200/70 p-4 dark:border-white/[0.07]">
          <button
            type="button"
            onClick={() => signOutMut.mutate()}
            disabled={signOutMut.isPending || !signedIn}
            aria-label={t("acctSignOut")}
            className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-rose-200 bg-white text-[12.5px] font-extrabold text-rose-600 shadow-sm transition hover:border-rose-300 hover:bg-rose-50 active:scale-[0.99] disabled:opacity-60 dark:border-rose-500/30 dark:bg-transparent dark:text-rose-300 dark:hover:border-rose-500/50 dark:hover:bg-rose-500/10"
          >
            {signOutMut.isPending ? (
              <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
            ) : (
              <CatIcon name="log-out" className="h-4 w-4" />
            )}
            {t("acctSignOut")}
          </button>
        </div>
      </SheetContent>
    </Sheet>
  );
}
