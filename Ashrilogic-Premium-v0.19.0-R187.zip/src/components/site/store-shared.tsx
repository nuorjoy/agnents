"use client";

/**
 * ROUND 55 — shared storefront building blocks.
 *
 * The e-store was SEPARATED from the public website (round 55): the website
 * (/sites/[id]) now shows only a compact gateway strip, while the full
 * Amazon-grade shopping experience lives on its own standalone page
 * (/sites/[id]/store — src/components/site/storefront-view.tsx).
 *
 * Everything both surfaces need moved HERE so there is zero duplication:
 *  - numeric/money helpers (nf · fmtPrice · countryName);
 *  - the product card + its qty stepper + sale countdown chip;
 *  - the guest cart sheet (checkout, coupons, placement) and the guest
 *    order-tracking card (code + phone → status timeline).
 *
 * ROUND 147 ADDITIONS (all additive — existing surfaces byte-preserved):
 *  - StoreCartItem gains the optional `variant` label (round 141) that
 *    now travels with each placement line; cart lines are keyed by
 *    (recordId + variant) and the sheet renders the label chip per row
 *    (the persistent cart itself lives in src/hooks/use-store-cart.ts);
 *  - CartSheetInner gains SAVED-ADDRESS shipping for signed-in shoppers
 *    (radio chooser over account.addresses, default preselected, one-tap
 *    prefill of name/phone + a compact one-line address injected into the
 *    order note, manual-entry fallback always reachable);
 *  - StoreProductQuickView gains the VARIANT picker (label chips, variant
 *    price/stock honesty) and RELATED-products rows (same-category
 *    siblings that chain the quick view to the next product).
 *
 * The underlying APIs are untouched (rounds 36–54 + the round-141 optional
 * `variant` field the orders service already accepts): /api/sites/[id]/store,
 * /api/sites/[id]/orders, /api/sites/[id]/store/coupon and
 * /api/sites/[id]/orders/track stay exactly as they were.
 */
import { useCallback, useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import type {
  CouponPreviewDTO,
  Lang,
  SiteOrderDTO,
  SiteOrderTrackedDTO,
  SiteProductDTO,
  SiteReviewDTO,
  StoreAddressDTO,
} from "@/lib/types";
import { useT, type I18nKey } from "@/lib/i18n";
import { intlLocale } from "@/lib/locales";
/* shared formatting lives in lib/format.ts; re-exported here so the many
   existing `store-shared` imports keep resolving (the public website now
   imports the pure helpers directly from lib/format instead of pulling the
   whole cart/account dependency graph). */
export { nf, countryName, fmtPrice } from "@/lib/format";
import { nf, fmtPrice } from "@/lib/format";
import { placeSiteOrder, trackSiteOrder, validateSiteCoupon, fetchProductReviews, submitProductReview } from "@/lib/api-client";
import { OrderReceiptDialog } from "@/components/site/order-receipt";
import { useStoreAccountMirror } from "@/components/site/store-account";
import { CatIcon } from "@/components/icon";
import { grad, hexAlpha, cn } from "@/lib/utils";
import { fullDate } from "@/components/dashboard/dash-shared";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { Reveal } from "@/components/landing/reveal";

/* ------------------------------------------------ locale helpers ------ */
/* moved to src/lib/format.ts (re-exported above) */

/* ------------------------------------------------ cart line ----------- */

/** one cart line — ROUND 147: persisted per instance through
 *  src/hooks/use-store-cart.ts (localStorage + useSyncExternalStore, the
 *  wishlist's proven architecture). A line's identity is (recordId +
 *  variant): the same product under two variants travels as two lines. */
export interface StoreCartItem {
  recordId: string;
  name: string;
  price: number;
  qty: number;
  /** purchase ceiling for this line (stock at add time, capped at 99) */
  max: number;
  /** ROUND 51 — the product photo (managed ref) for the cart row thumbnail. */
  imageRef?: string | null;
  /** ROUND 147 — the chosen VARIANT label (round 141 متغيرات; undefined =
   *  single-SKU line). Rides the line into the placement body's optional
   *  `variant` field; the server resolves it against the record's stored
   *  variants and derives the charged price from the variant override. */
  variant?: string;
}

/** ROUND 147 — the compact one-line shipping note injected when a saved
 *  address is chosen («الشحن إلى: {label} — {city} {street} …»). The
 *  prefix is the localized storeShipTo string; empty address parts drop
 *  out so the line stays tight whatever the merchant's shopper saved. */
function addressNoteLine(addr: StoreAddressDTO, prefix: string): string {
  const parts = [addr.city, addr.street, addr.building, addr.apartment]
    .map((s) => s.trim())
    .filter((s) => s.length > 0);
  const tail = parts.length > 0 ? ` — ${parts.join(" ")}` : "";
  return `${prefix}: ${addr.label.trim()}${tail}`;
}

/* ------------------------------------------------ qty stepper --------- */

/** touch-friendly quantity stepper (− / value / +) clamped to min..max. */
export function StoreQty({
  value,
  min,
  max,
  onChange,
  full = false,
}: {
  value: number;
  min: number;
  max: number;
  onChange: (next: number) => void;
  full?: boolean;
}) {
  const { t } = useT();
  return (
    <div
      role="group"
      aria-label={t("storeCartQty")}
      className={cn(
        "inline-flex items-center gap-1 rounded-xl border border-slate-200 bg-white p-1 dark:border-white/10 dark:bg-white/[0.04]",
        full && "w-full justify-between"
      )}
    >
      <button
        type="button"
        onClick={() => onChange(Math.max(min, value - 1))}
        disabled={value <= min}
        aria-label={t("storeQtyMinus")}
        className="grid h-8 w-8 place-items-center rounded-lg text-slate-500 transition hover:bg-slate-100 hover:text-slate-800 active:scale-90 disabled:opacity-40 dark:text-slate-400 dark:hover:bg-white/10 dark:hover:text-white"
      >
        <CatIcon name="minus" className="h-3.5 w-3.5" />
      </button>
      <span
        dir="ltr"
        className={cn(
          "text-center font-display text-[14px] font-extrabold tabular-nums text-slate-800 dark:text-slate-100",
          full ? "min-w-8" : "min-w-7"
        )}
      >
        {value}
      </span>
      <button
        type="button"
        onClick={() => onChange(Math.min(max, value + 1))}
        disabled={value >= max}
        aria-label={t("storeQtyPlus")}
        title={t("storeStockLeft", { n: max })}
        className="grid h-8 w-8 place-items-center rounded-lg text-slate-500 transition hover:bg-slate-100 hover:text-slate-800 active:scale-90 disabled:opacity-40 dark:text-slate-400 dark:hover:bg-white/10 dark:hover:text-white"
      >
        <CatIcon name="plus" className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}

/* ------------------------------------------------ countdown chip ------ */

/**
 * ROUND 53 — the sale-window countdown chip on a storefront product card.
 * Urgency styling scales with the remaining time (≤3 days = rose pulse),
 * and the text stays honest: the DTO already degrades expired sales to the
 * regular price, so this chip can only ever advertise a LIVE window.
 */
export function SaleCountdownChip({ endsAt }: { endsAt: string }) {
  const { t, lang } = useT();
  const msLeft = new Date(endsAt).getTime() - Date.now();
  if (msLeft <= 0) return null;
  const hoursLeft = Math.floor(msLeft / 3_600_000);
  const daysLeft = Math.ceil(msLeft / 86_400_000);
  const urgent = daysLeft <= 3;
  return (
    <span
      className={cn(
        "mt-1.5 inline-flex w-fit items-center gap-1 rounded-full border px-2 py-0.5 text-[10.5px] font-extrabold",
        urgent
          ? "animate-pulse border-rose-300/70 bg-rose-500/10 text-rose-600 dark:border-rose-500/40 dark:text-rose-300"
          : "border-slate-200 bg-slate-50 text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400"
      )}
      title={fullDate(new Date(endsAt), lang)}
    >
      <CatIcon name="hourglass" className="h-3 w-3" />
      {daysLeft <= 0
        ? t("storeSaleEndsHours", { n: nf(lang, Math.max(1, hoursLeft)) })
        : t("storeSaleEndsIn", { n: nf(lang, daysLeft) })}
    </span>
  );
}

/* ------------------------------------------------ wishlist heart ------- */

/** ROUND 58 — the wishlist toggle. Standalone so BOTH card layouts (photo /
 * photo-less) share one animated, accessible implementation: heart outline
 * when idle, filled rose with a springy pop when saved. The pop is a pure
 * CSS keyframe (heart-pop) gated behind prefers-reduced-motion. */
function WishlistHeart({
  active,
  labelOn,
  labelOff,
  onClick,
  className,
}: {
  active: boolean;
  labelOn: string;
  labelOff: string;
  onClick: () => void;
  className?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      aria-label={active ? labelOn : labelOff}
      title={active ? labelOn : labelOff}
      className={cn(
        "grid h-8 w-8 shrink-0 place-items-center rounded-full border backdrop-blur-sm transition-all duration-200 active:scale-90",
        active
          ? "border-rose-300/70 bg-rose-500/90 text-white shadow-lg shadow-rose-500/40 animate-heart-pop"
          : "border-white/30 bg-black/40 text-white/85 hover:bg-black/60 hover:text-white dark:border-white/25",
        className
      )}
    >
      <CatIcon name="heart" className={cn("h-4 w-4", active && "fill-current")} />
    </button>
  );
}

/* ------------------------------------------------ rating stars ------- */

/**
 * ROUND 63 — the storefront star-rating row (DISPLAY-ONLY; the interactive
 * picker inside StoreReviewsDialog is a separate control).
 *
 * 5 CatIcon stars over a slate base with amber PARTIAL fill via the classic
 * overlay-clip technique: a relative `dir="ltr"` inline-flex base row plus
 * an absolutely-positioned overflow-hidden overlay (width = value/5) that
 * carries the filled row. The `dir="ltr"` wrapper keeps the star geometry
 * byte-identical on RTL pages (the glyphs are symmetric — only the clip
 * anchor must stay physical-start, which dir="ltr" guarantees).
 *
 * Purely decorative: `aria-hidden` on the whole visual — the PARENT supplies
 * accessibility (a text average/count beside it, or an aria-label). Zero
 * dependencies, no hooks, so it renders identically on the server.
 */
export function StarsRow({
  value,
  size = "sm",
  className,
}: {
  /** 0..5 (values outside the range clamp); fractional = partial star */
  value: number;
  size?: "sm" | "md" | "lg";
  className?: string;
}) {
  const star = size === "sm" ? "h-3 w-3" : size === "md" ? "h-4 w-4" : "h-5 w-5";
  const fill = `${(Math.max(0, Math.min(5, value)) / 5) * 100}%`;
  const row = (filled: boolean) => (
    <span className="inline-flex gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <CatIcon
          key={i}
          name="star"
          className={cn(
            star,
            "shrink-0",
            filled
              ? "fill-amber-400 text-amber-400"
              : "fill-slate-200 text-slate-300 dark:fill-white/10 dark:text-slate-600"
          )}
        />
      ))}
    </span>
  );
  return (
    <span aria-hidden="true" dir="ltr" className={cn("relative inline-flex shrink-0", className)}>
      {/* base row — the slate outline stars (sets the intrinsic width) */}
      {row(false)}
      {/* overlay — the amber filled row, clipped to the exact fraction */}
      <span className="absolute start-0 top-0 h-full overflow-hidden" style={{ width: fill }}>
        {row(true)}
      </span>
    </span>
  );
}

/* ------------------------------------------------ product card --------- */

export function StoreProductCard({
  product,
  currency,
  c1,
  c2,
  onAdd,
  wishlisted = false,
  onToggleWishlist,
  onQuickView,
  staggerIndex,
}: {
  product: SiteProductDTO;
  currency: string;
  c1: string;
  c2: string;
  onAdd: (product: SiteProductDTO, qty: number) => void;
  /** ROUND 58 — wishlist state (undefined = wishlist UI hidden) */
  wishlisted?: boolean;
  onToggleWishlist?: (product: SiteProductDTO) => void;
  /** ROUND 61 — opens the quick-view dialog (undefined = no quick view) */
  onQuickView?: () => void;
  /** ROUND 61 — entrance stagger position (the card-in delay reads --i) */
  staggerIndex?: number;
}) {
  const { t, lang } = useT();
  const [qty, setQty] = useState(1);
  const [justAdded, setJustAdded] = useState(false);
  const max = Math.min(99, Math.max(1, Math.floor(product.stock) || 1));
  const low = product.statusKey === "low" || product.stock <= 10;

  /* ROUND 51 — the merchant's product photo: renders as a full-bleed 4:3
   * media block with a hover zoom; chips overlay the image. Records without
   * a photo keep the exact pre-51 layout (graceful fallback). */
  const photo = product.imageRef;

  /* ROUND 59 — photo load tracking: a ONE-WAY state machine feeding the
   * skeleton shimmer ("loading") and the themed error fallback ("error").
   * Server + client both render the <img> with state "loading", so the
   * hydration markup is byte-identical; onLoad/onError advance the state
   * client-only, and the <img> is keyed by its URL (remount, never a flap:
   * once "error" swaps in the fallback the img unmounts — onError can't
   * re-fire). The photo-change reset uses React's documented previous-value
   * pattern DURING render (react-hooks v7 gates setState-in-effect as an
   * error; the reset also recovers the card from the error fallback when a
   * merchant swaps the photo), and the stable ref callback below covers the
   * cached-image race, where the load/error event fires before hydration
   * attaches the handlers (it re-fires whenever the keyed <img> remounts). */
  const [imgState, setImgState] = useState<"loading" | "ok" | "error">("loading");
  const [prevPhoto, setPrevPhoto] = useState(photo);
  if (photo !== prevPhoto) {
    setPrevPhoto(photo);
    setImgState("loading");
  }
  const attachImg = useCallback((el: HTMLImageElement | null) => {
    if (el?.complete) setImgState(el.naturalWidth > 0 ? "ok" : "error");
  }, []);

  /* ROUND 52 — merchandising: the golden featured badge + the sale pricing
   * (struck regular price, rose sale price, discount pill). The EFFECTIVE
   * price (sale ?? regular) is what the cart charges. */
  const onSale = product.salePrice != null;
  const effective = onSale ? (product.salePrice as number) : product.price;
  const salePct = onSale ? Math.round((1 - effective / product.price) * 100) : 0;

  return (
    <article
      className={cn(
        "card-in group relative flex h-full flex-col overflow-hidden rounded-3xl border bg-white shadow-soft transition-all duration-300 hover:-translate-y-1 hover:border-transparent hover:shadow-lift dark:bg-white/[0.035]",
        product.featured
          ? "border-amber-300/70 ring-1 ring-amber-400/50 dark:border-amber-400/30"
          : "border-slate-200/80 dark:border-white/10"
      )}
      /* ROUND 61 — wave entrance: position in the grid delays card-in
       * (var --i feeds the keyframe delay in globals.css) */
      style={staggerIndex != null ? ({ "--i": staggerIndex } as React.CSSProperties) : undefined}
    >
      {/* ROUND 58 — shine sweep: a diagonal light band that glides across
       * the card on hover (pointer-events none, reduced-motion safe) */}
      <span
        aria-hidden="true"
        className="shine-sweep pointer-events-none absolute inset-0 z-10"
      />

      {photo ? (
        <div
          className={cn(
            "relative mx-4 mt-4 aspect-[4/3] overflow-hidden rounded-2xl",
            /* ROUND 59 — soft skeleton shimmer while the photo streams in
             * (removed the moment onLoad fires) */
            imgState === "loading" && "img-loading"
          )}
        >
          {imgState === "error" ? (
            /* ROUND 59 — themed fallback tile: never a broken-image glyph.
             * A soft duotone of the site's own palette (hexAlpha over the
             * white / ink card), the product's first initial in big display
             * type, and its category as a small chip (the photo-layout
             * top-start chip is suppressed in this state — no duplicate). */
            <div
              className="absolute inset-0 grid place-content-center justify-items-center gap-2 p-4"
              style={{
                backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.85)}, ${hexAlpha(c2, 0.9)})`,
              }}
            >
              <span
                aria-hidden="true"
                className="font-display text-[44px] font-black leading-none text-white/95 drop-shadow-lg"
              >
                {product.name.trim().charAt(0) || "؟"}
              </span>
              {product.category ? (
                <span
                  className="max-w-full truncate rounded-full border border-white/30 bg-black/25 px-2.5 py-0.5 text-[10.5px] font-extrabold text-white backdrop-blur-sm"
                  title={product.category}
                >
                  {product.category}
                </span>
              ) : null}
            </div>
          ) : (
            <img
              key={photo}
              ref={attachImg}
              src={photo}
              alt={t("storePhotoAlt", { name: product.name })}
              loading="lazy"
              decoding="async"
              onError={() => setImgState("error")}
              onLoad={() => setImgState("ok")}
              className="relative h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.06]"
            />
          )}
          {/* soft bottom scrim so the overlay chips stay readable on any photo */}
          <span
            aria-hidden="true"
            className="pointer-events-none absolute inset-x-0 bottom-0 h-10 bg-gradient-to-t from-black/35 to-transparent"
          />
          <div className="absolute inset-x-2.5 top-2.5 flex items-start justify-between gap-2">
            {product.category && imgState !== "error" ? (
              <span
                className="inline-flex min-w-0 items-center gap-1 rounded-full border border-white/25 bg-black/45 px-2 py-0.5 text-[10.5px] font-extrabold text-white backdrop-blur-sm transition-all duration-200 group-hover:backdrop-blur-md group-hover:bg-black/60"
                title={product.category}
              >
                <CatIcon name="tag" className="h-[9px] w-[9px] shrink-0" />
                <span className="max-w-24 truncate">{product.category}</span>
              </span>
            ) : (
              <span />
            )}
            <span className="flex shrink-0 flex-col items-end gap-1">
              {product.featured ? (
                <span
                  title={t("storeFeaturedBadge")}
                  className="inline-flex items-center gap-1 rounded-full border border-amber-300/70 bg-gradient-to-l from-amber-400 to-orange-500 px-2 py-0.5 text-[10.5px] font-extrabold text-white shadow-md"
                >
                  <CatIcon name="star" className="h-[9px] w-[9px] fill-current" />
                  {t("storeFeaturedBadge")}
                </span>
              ) : null}
              {onSale ? (
                <span
                  title={t("storeSaleBadge", { p: nf(lang, salePct) })}
                  dir="ltr"
                  className="rounded-full bg-rose-600 px-2 py-0.5 text-[10.5px] font-black text-white shadow-md"
                >
                  −{nf(lang, salePct)}%
                </span>
              ) : null}
              <span
                className={cn(
                  "inline-flex shrink-0 items-center gap-1 rounded-full border px-2 py-0.5 text-[10.5px] font-extrabold backdrop-blur-sm",
                  low
                    ? "border-amber-300/50 bg-amber-500/30 text-amber-100"
                    : "border-emerald-300/50 bg-emerald-500/30 text-emerald-100"
                )}
                title={t("storeStockLeft", { n: nf(lang, product.stock) })}
              >
                <span
                  className={cn("h-1.5 w-1.5 rounded-full", low ? "bg-amber-300" : "bg-emerald-300")}
                  aria-hidden="true"
                />
                {low ? t("storeStockLow") : t("storeStockIn")}
              </span>
            </span>
          </div>

          {/* ROUND 58 — wishlist heart pinned to the photo's bottom-start
           * corner (the top row is reserved for merchandising chips) */}
          {onToggleWishlist ? (
            <WishlistHeart
              active={wishlisted}
              labelOn={t("wishlistRemove", { name: product.name })}
              labelOff={t("wishlistAdd", { name: product.name })}
              onClick={() => onToggleWishlist(product)}
              className="absolute bottom-2.5 start-2.5"
            />
          ) : null}

          {/* ROUND 140 — media chips (photos beyond the cover + video clips)
           * beside the quick-view button: a soft pill that hints the gallery */}
          {onQuickView && ((product.gallery?.length ?? 0) > 1 || (product.videos?.length ?? 0) > 0) ? (
            <span className="absolute bottom-2.5 end-12 flex items-center gap-1.5 opacity-0 transition-opacity duration-200 group-hover:opacity-100 [@media(pointer:coarse)]:opacity-100">
              {(product.gallery?.length ?? 0) > 1 ? (
                <span
                  title={t("storeQvPhotosBadge", { n: nf(lang, product.gallery.length) })}
                  className="inline-flex items-center gap-1 rounded-full border border-white/35 bg-black/55 px-2 py-0.5 text-[10px] font-black text-white backdrop-blur-md"
                >
                  <CatIcon name="camera" className="h-3 w-3" />
                  {nf(lang, product.gallery.length)}
                </span>
              ) : null}
              {(product.videos?.length ?? 0) > 0 ? (
                <span
                  title={t("storeQvVideoBadge")}
                  className="inline-flex items-center gap-1 rounded-full border border-white/35 bg-black/55 px-2 py-0.5 text-[10px] font-black text-white backdrop-blur-md"
                >
                  <CatIcon name="play" className="h-3 w-3 fill-current" />
                  {nf(lang, product.videos.length)}
                </span>
              ) : null}
            </span>
          ) : null}

          {/* ROUND 61 — quick-view eye button, the photo's bottom-END corner
           * (hover-reveal on pointer devices, always visible on touch) */}
          {onQuickView ? (
            <button
              type="button"
              onClick={onQuickView}
              aria-label={t("storeQuickViewAria", { name: product.name })}
              title={t("storeQuickViewAria", { name: product.name })}
              className="absolute bottom-2.5 end-2.5 grid h-9 w-9 place-items-center rounded-xl border border-white/35 bg-black/55 text-white opacity-0 shadow-md backdrop-blur-md transition-all duration-200 hover:bg-black/75 hover:scale-105 focus-visible:opacity-100 group-hover:opacity-100 active:scale-95 [@media(pointer:coarse)]:opacity-100"
            >
              <CatIcon name="eye" className="h-4 w-4" />
            </button>
          ) : null}
        </div>
      ) : null}

      <div className={cn("flex flex-1 flex-col", photo ? "px-4 pb-4 pt-3" : "p-4")}>
        {!photo ? (
          <div className="flex items-start justify-between gap-2">
            <span className="flex min-w-0 items-start gap-2">
              {product.category ? (
                <span
                  className="inline-flex min-w-0 items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-extrabold"
                  style={{
                    borderColor: hexAlpha(c1, 0.3),
                    backgroundColor: hexAlpha(c1, 0.07),
                    color: c1,
                  }}
                  title={product.category}
                >
                  <CatIcon name="tag" className="h-[9px] w-[9px] shrink-0" />
                  <span className="max-w-24 truncate">{product.category}</span>
                </span>
              ) : (
                <span />
              )}
              {onToggleWishlist ? (
                <WishlistHeart
                  active={wishlisted}
                  labelOn={t("wishlistRemove", { name: product.name })}
                  labelOff={t("wishlistAdd", { name: product.name })}
                  onClick={() => onToggleWishlist(product)}
                  className={cn(
                    "border-slate-200 bg-white text-slate-400 hover:border-rose-300 hover:text-rose-500 dark:border-white/10 dark:bg-white/[0.06] dark:text-slate-400 dark:hover:border-rose-500/40",
                    wishlisted &&
                      "border-rose-300/70 bg-rose-500/90 text-white shadow-lg shadow-rose-500/40"
                  )}
                />
              ) : null}
            </span>
            <span className="flex shrink-0 flex-col items-end gap-1">
              {product.featured ? (
                <span
                  title={t("storeFeaturedBadge")}
                  className="inline-flex items-center gap-1 rounded-full border border-amber-300/70 bg-gradient-to-l from-amber-400 to-orange-500 px-2 py-0.5 text-[10.5px] font-extrabold text-white shadow-md"
                >
                  <CatIcon name="star" className="h-[9px] w-[9px] fill-current" />
                  {t("storeFeaturedBadge")}
                </span>
              ) : null}
              {onSale ? (
                <span
                  title={t("storeSaleBadge", { p: nf(lang, salePct) })}
                  dir="ltr"
                  className="rounded-full bg-rose-600 px-2 py-0.5 text-[10.5px] font-black text-white shadow-md"
                >
                  −{nf(lang, salePct)}%
                </span>
              ) : null}
              <span
                className={cn(
                  "inline-flex shrink-0 items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-extrabold",
                  low
                    ? "border-amber-300/60 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300"
                    : "border-emerald-300/60 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
                )}
                title={t("storeStockLeft", { n: nf(lang, product.stock) })}
              >
                <span
                  className={cn("h-1.5 w-1.5 rounded-full", low ? "bg-amber-500" : "bg-emerald-500")}
                  aria-hidden="true"
                />
                {low ? t("storeStockLow") : t("storeStockIn")}
              </span>
            </span>
          </div>
        ) : null}

        <h3
          className={cn(
            "line-clamp-2 min-h-10 font-display text-[14px] font-extrabold leading-snug text-slate-900 dark:text-white",
            photo ? "mt-0" : "mt-3"
          )}
          title={product.name}
        >
          {/* ROUND 61 — the name opens the quick view (keyboard accessible,
           * decorated underline on hover — a real button, not a card click) */}
          {onQuickView ? (
            <button
              type="button"
              onClick={onQuickView}
              className="text-start decoration-2 underline-offset-4 transition hover:underline"
              aria-label={t("storeQuickViewAria", { name: product.name })}
            >
              {product.featured ? (
                <CatIcon
                  name="star"
                  className="me-1 inline h-3.5 w-3.5 fill-current text-amber-500 dark:text-amber-300"
                />
              ) : null}
              {product.name}
            </button>
          ) : (
            <>
              {product.featured ? (
                <CatIcon
                  name="star"
                  className="me-1 inline h-3.5 w-3.5 fill-current text-amber-500 dark:text-amber-300"
                />
              ) : null}
              {product.name}
            </>
          )}
        </h3>

        {/* ROUND 63 — the rating line: subtle stars + count under the NAME,
         * only when the product has visible reviews (conditional render, so
         * unrated cards keep the exact pre-63 rhythm — no layout shift) */}
        {product.ratingCount > 0 ? (
          <div className="mt-1 flex items-center gap-1.5">
            <StarsRow value={product.ratingAvg ?? 0} size="sm" />
            <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
              ({nf(lang, product.ratingCount)})
            </span>
          </div>
        ) : null}

        {/* ROUND 52 — sale pricing: struck regular + rose sale price
         *  ROUND 53 — plus the window countdown chip when the merchant set
         *  an end date (the DTO only exposes it while the sale applies). */}
        {onSale ? (
          <div
            dir="ltr"
            className="price-row mt-2 flex items-end gap-2 transition-transform duration-200 ease-out"
          >
            <span
              className="text-start font-display text-[13px] font-bold tabular-nums text-slate-400 line-through dark:text-slate-500"
            >
              {fmtPrice(lang, product.price, currency)}
            </span>
            <span
              className="text-start font-display text-[20px] font-black tabular-nums text-rose-600 dark:text-rose-400"
            >
              {fmtPrice(lang, effective, currency)}
            </span>
          </div>
        ) : (
          <p
            dir="ltr"
            className="price-row mt-2 text-start font-display text-[19px] font-black tabular-nums transition-transform duration-200 ease-out"
            style={{ color: c1 }}
          >
            {fmtPrice(lang, product.price, currency)}
          </p>
        )}
        {onSale && product.saleEndsAt ? (
          <SaleCountdownChip endsAt={product.saleEndsAt} />
        ) : null}

        <div className="mt-auto space-y-2 pt-3.5">
          <StoreQty value={qty} min={1} max={max} onChange={setQty} full />
          {/* ROUND 58 — the button confirms with a check-pop flourish for
           * 1.4s after adding (reduced-motion safe: the keyframe is gated) */}
          <Button
            type="button"
            onClick={() => {
              onAdd(product, qty);
              setQty(1);
              setJustAdded(true);
              window.setTimeout(() => setJustAdded(false), 1400);
            }}
            className="btn-grad h-10 w-full gap-1.5 rounded-xl text-[12px] font-bold text-white shadow-lg transition-[transform,filter,background-position,background-size] duration-200 ease-[cubic-bezier(0.22,1,0.36,1)] hover:brightness-110 active:scale-95"
            style={{
              backgroundImage: grad(c1, c2),
              boxShadow: `0 10px 22px -10px ${hexAlpha(c1, 0.75)}`,
            }}
          >
            {justAdded ? (
              <>
                <CatIcon name="check" className="h-4 w-4 animate-check-pop" />
                {t("storeAddedBtn")}
              </>
            ) : (
              <>
                <CatIcon name="shopping-cart" className="h-4 w-4" />
                {t("storeAdd")}
              </>
            )}
          </Button>
        </div>
      </div>
    </article>
  );
}

/* ------------------------------------------------ cart sheet ---------- */

/** inner sheet body — mounted INSIDE SheetContent, so the note + placed-order
 *  state reset to a clean slate on every open (same trick as the auth gate). */
export function CartSheetInner({
  instanceId,
  cart,
  currency,
  c1,
  c2,
  onQty,
  onRemove,
  onClear,
}: {
  instanceId: string;
  cart: StoreCartItem[];
  currency: string;
  c1: string;
  c2: string;
  onQty: (recordId: string, qty: number, variant?: string) => void;
  onRemove: (recordId: string, variant?: string) => void;
  onClear: () => void;
}) {
  const { t, lang } = useT();
  const [placed, setPlaced] = useState<SiteOrderDTO | null>(null);

  /* ROUND 65 — signed-in checkout prefill (one-tap checkout): the account
   * snapshot flows in through the module-level mirror exported by
   * store-account.tsx (its provider lives in storefront-view — no prop
   * drilling through this sheet chain). This inner body remounts on every
   * sheet open, so the fields INITIALIZE from a live account (signed-in
   * shopper lands prefilled) and the previous-value pattern below re-syncs
   * them whenever the account snapshot changes (profile save / sign-out) —
   * no setState-in-effect. While signed in, the email renders read-only
   * below: the SESSION customer is the order's identity server-side, so
   * the email is never editable here.
   *
   * ROUND 147 — when the account carries SAVED ADDRESSES, the DEFAULT one
   * additionally initializes the shipping selection, the name/phone
   * prefill (its fullName/phone) and the compact one-line address injected
   * into the order note — a true one-tap checkout for the signed-in
   * member; the note and every input stay fully editable afterwards. */
  const account = useStoreAccountMirror();
  const addresses = account?.addresses ?? [];
  const initialAddress =
    addresses.length > 0 ? (addresses.find((a) => a.isDefault) ?? addresses[0]) : null;

  const [note, setNote] = useState(() =>
    initialAddress != null ? addressNoteLine(initialAddress, t("storeShipTo")) : ""
  );
  /* the last AUTO-injected address line — selecting a different address
   * replaces exactly this line, never the shopper's own words */
  const [autoNoteLine, setAutoNoteLine] = useState(() =>
    initialAddress != null ? addressNoteLine(initialAddress, t("storeShipTo")) : ""
  );

  /* ROUND 44 — guest checkout: the visitor's contact details travel WITH the
   * order (name required, phone optional). No account, no session, no sign-in. */
  const [guestName, setGuestName] = useState(initialAddress?.fullName || account?.name || "");
  const [guestPhone, setGuestPhone] = useState(initialAddress?.phone || account?.phone || "");
  const [guestAttempted, setGuestAttempted] = useState(false);

  /* ROUND 147 — the saved-address shipping state: the default address
   * preselects; `manualAddress` folds the chooser away so the plain
   * guest-style form below is fully reachable (storeChooseAddress brings
   * the chooser back). */
  const [selectedAddressId, setSelectedAddressId] = useState<string | null>(
    initialAddress != null ? initialAddress.id : null
  );
  const [manualAddress, setManualAddress] = useState(false);

  const [prevAccount, setPrevAccount] = useState(account);
  if (account !== prevAccount) {
    setPrevAccount(account);
    const nextAddresses = account?.addresses ?? [];
    const nextDefault =
      nextAddresses.length > 0
        ? (nextAddresses.find((a) => a.isDefault) ?? nextAddresses[0])
        : null;
    setGuestName(nextDefault?.fullName || account?.name || "");
    setGuestPhone(nextDefault?.phone || account?.phone || "");
    setSelectedAddressId(nextDefault != null ? nextDefault.id : null);
    const nextLine = nextDefault != null ? addressNoteLine(nextDefault, t("storeShipTo")) : "";
    setAutoNoteLine(nextLine);
    setNote(nextLine);
  }

  /* ROUND 147 — selecting a saved address: prefills the contact fields
   * (fullName/phone) and swaps the compact one-line address into the note
   * (the previous AUTO line is replaced in place; any manual text
   * survives). The inputs stay editable afterwards. */
  const selectAddress = (addr: StoreAddressDTO) => {
    setSelectedAddressId(addr.id);
    setGuestName(addr.fullName || account?.name || "");
    setGuestPhone(addr.phone || "");
    const line = addressNoteLine(addr, t("storeShipTo"));
    let base = note;
    if (autoNoteLine) {
      if (base === autoNoteLine) base = "";
      else if (base.endsWith(`\n${autoNoteLine}`))
        base = base.slice(0, base.length - autoNoteLine.length - 1);
    }
    base = base.trim();
    setNote(base ? `${base}\n${line}` : line);
    setAutoNoteLine(line);
  };

  /* ROUND 50 — coupon: raw input + the validated preview (discount shown in
   * display units, derived from the server's minor-unit verdict). */
  const [couponInput, setCouponInput] = useState("");
  const [applied, setApplied] = useState<CouponPreviewDTO | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);

  const subtotal = cart.reduce((sum, i) => sum + i.price * i.qty, 0);
  const subtotalMinor = Math.round(subtotal * 100);

  /** map the API's machine reason to the actionable guest-facing message */
  const couponErrorMessage = (e: Error): string => {
    const code = (e as Error & { code?: string }).code;
    if (code === "NOTFOUND") return t("storeCouponErrNotFound");
    if (code === "INACTIVE") return t("storeCouponErrInactive");
    if (code === "WINDOW") return t("storeCouponErrWindow");
    if (code === "EXHAUSTED") return t("storeCouponErrExhausted");
    if (code === "MINSUBTOTAL") return t("storeCouponErrMinSubtotal");
    return e.message || t("storeCouponErr");
  };

  const applyCoupon = useMutation({
    mutationFn: () => validateSiteCoupon(instanceId, { code: couponInput.trim(), subtotal: subtotalMinor }),
    onSuccess: (preview) => {
      setApplied(preview);
      setCouponInput("");
      toast.success(t("storeCouponApplied"));
    },
    onError: (e: Error) => toast.error(couponErrorMessage(e)),
  });

  /* keep the applied coupon honest when the cart changes — re-validate
   * against the new subtotal; a code that no longer applies drops off */
  useEffect(() => {
    if (!applied || cart.length === 0) return;
    let cancelled = false;
    validateSiteCoupon(instanceId, { code: applied.code, subtotal: subtotalMinor })
      .then((preview) => {
        if (!cancelled) setApplied(preview);
      })
      .catch(() => {
        if (!cancelled) setApplied(null);
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [subtotalMinor, cart.length, instanceId]);

  const discount = applied ? Math.min(subtotal, applied.discountMinor / 100) : 0;
  const grandTotal = Math.max(0, subtotal - discount);

  const place = useMutation({
    mutationFn: () => {
      /* ROUND 147 — each line carries its chosen variant label (round 141:
       * the server resolves it against the record's stored variantsJson and
       * derives the charged price from the variant's own override when it
       * carries one; variant-less lines order exactly as before). Built as
       * a separately-typed array so the optional field rides the EXISTING
       * placeSiteOrder payload — no API change, no client contract drift. */
      const items: { recordId: string; qty: number; variant?: string }[] = cart.map((i) => ({
        recordId: i.recordId,
        qty: i.qty,
        ...(i.variant ? { variant: i.variant } : {}),
      }));
      return placeSiteOrder(instanceId, {
        items,
        ...(note.trim() ? { note: note.trim() } : {}),
        customer: {
          name: guestName.trim(),
          ...(guestPhone.trim() ? { phone: guestPhone.trim() } : {}),
        },
        ...(applied ? { couponCode: applied.code } : {}),
      });
    },
    onSuccess: (order) => {
      setPlaced(order);
      onClear();
      /* the note resets to the still-selected address's auto line (empty
       * for guests) — the one-tap checkout stays coherent for the NEXT
       * order too; the shopper can always edit it again */
      setNote(autoNoteLine);
      setGuestAttempted(false);
      setApplied(null);
      setCouponInput("");
    },
    onError: (e: Error) => {
      /* 409 STOCK / ITEM_GONE / COUPON — the server message carries the reason */
      toast.error(e.message || t("errorText"));
    },
  });

  const submitOrder = () => {
    if (guestName.trim().length < 2) {
      setGuestAttempted(true);
      toast.error(t("storeGuestErrName"));
      return;
    }
    place.mutate();
  };

  /** ROUND 50 — copy the tracking code to the clipboard (same-origin). */
  const copyTrackingCode = async () => {
    if (!placed?.code) return;
    try {
      await navigator.clipboard.writeText(placed.code);
      setCopiedCode(true);
      toast.success(t("storeTrackCopied"));
      window.setTimeout(() => setCopiedCode(false), 2000);
    } catch {
      toast.error(t("errorText"));
    }
  };

  const count = cart.reduce((sum, i) => sum + i.qty, 0);

  return (
    <>
      {/* themed banner header — pe-14 clears the sheet's floating close (X) */}
      <SheetHeader
        className="border-b border-slate-200/70 px-5 py-4 pe-14 dark:border-white/10"
        style={{
          backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.14)}, ${hexAlpha(c2, 0.14)})`,
        }}
      >
        <SheetTitle className="flex items-start gap-3">
          <span
            className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
            style={{ backgroundImage: grad(c1, c2) }}
          >
            <CatIcon name="shopping-cart" className="h-5 w-5" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block truncate font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
              {t("storeCartTitle")}
            </span>
            <span className="mt-0.5 block text-[11px] font-bold text-slate-500 dark:text-slate-400">
              {placed
                ? `${t("storeOrderChip")} #${placed.code ?? placed.id.slice(0, 8).toUpperCase()}`
                : count > 0
                  ? t("storeCartItems", { n: nf(lang, count) })
                  : t("storeCartEmpty")}
            </span>
          </span>
        </SheetTitle>
        <SheetDescription className="sr-only">{t("storeCartTitle")}</SheetDescription>
      </SheetHeader>

      {placed ? (
        /* --------------------------------------------- success state ----- */
        <div className="px-6 py-10 text-center">
          <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
            <CatIcon name="check" className="h-7 w-7" />
          </span>
          <h3 className="mt-4 font-display text-[16px] font-extrabold text-slate-900 dark:text-white">
            {t("storePlacedTitle")}
          </h3>
          <p className="mx-auto mt-1.5 max-w-xs text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
            {t("storePlacedDesc")}
          </p>

          {/* ROUND 50 — the tracking code card: prominent, monospaced,
              copyable — the guest's key to following the order */}
          {placed.code ? (
            <div className="mx-auto mt-5 max-w-xs rounded-2xl border border-emerald-300/60 bg-emerald-500/[0.07] p-4 dark:border-emerald-500/30 dark:bg-emerald-500/10">
              <p className="flex items-center justify-center gap-1.5 text-[10.5px] font-extrabold uppercase tracking-wider text-emerald-700 dark:text-emerald-300">
                <CatIcon name="package-search" className="h-3.5 w-3.5" />
                {t("storeTrackCodeLabel")}
              </p>
              <button
                type="button"
                onClick={copyTrackingCode}
                title={t("storeTrackCopy")}
                className="group mt-2 inline-flex items-center gap-2.5 rounded-xl border-2 border-dashed border-emerald-400/60 bg-white px-4 py-2.5 transition hover:border-emerald-500 hover:bg-emerald-50 active:scale-95 dark:border-emerald-500/40 dark:bg-white/5 dark:hover:bg-emerald-500/10"
              >
                <code dir="ltr" className="font-mono text-[20px] font-black tracking-[0.2em] text-emerald-700 dark:text-emerald-300">
                  {placed.code}
                </code>
                <CatIcon
                  name={copiedCode ? "check" : "copy"}
                  className={cn(
                    "h-4 w-4 transition",
                    copiedCode ? "text-emerald-500" : "text-slate-400 group-hover:text-emerald-600 dark:group-hover:text-emerald-300"
                  )}
                />
              </button>
              <p className="mt-2.5 text-[10.5px] font-semibold leading-relaxed text-emerald-700/80 dark:text-emerald-400/80">
                {t("storeTrackHint")}
              </p>
            </div>
          ) : (
            <p className="mt-4 inline-flex items-center gap-2 rounded-full border border-emerald-300/60 bg-emerald-500/10 px-3.5 py-1.5 text-[12px] font-extrabold text-emerald-700 dark:border-emerald-500/40 dark:text-emerald-300">
              {t("storeOrderChip")}
              <code dir="ltr" className="font-mono tracking-wider">
                #{placed.id.slice(0, 8).toUpperCase()}
              </code>
            </p>
          )}

          {placed.discount > 0 ? (
            <p className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-3 py-1 text-[11px] font-extrabold text-emerald-700 dark:text-emerald-300">
              <CatIcon name="ticket-percent" className="h-3.5 w-3.5" />
              {t("storeCouponApplied")} · {t("storeDiscount")}{" "}
              {fmtPrice(lang, placed.discount, placed.currency)}
            </p>
          ) : null}

          <div className="mt-5">
            <Button
              variant="outline"
              onClick={() => setPlaced(null)}
              className="h-10 gap-2 rounded-xl px-5 text-[12.5px] font-bold"
            >
              <CatIcon name="shopping-cart" className="h-4 w-4" />
              {t("storeNewOrder")}
            </Button>
          </div>
        </div>
      ) : cart.length === 0 ? (
        /* --------------------------------------------- empty state ------- */
        <div className="px-6 py-14 text-center">
          <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
            <CatIcon name="shopping-cart" className="h-6 w-6" />
          </div>
          <h3 className="mt-4 font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
            {t("storeCartEmpty")}
          </h3>
          <p className="mx-auto mt-1 max-w-xs text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
            {t("storeCartEmptyDesc")}
          </p>
        </div>
      ) : (
        /* --------------------------------------------- cart body --------- */
        <div className="space-y-4 p-5">
          <ul className="nice-scroll max-h-[22rem] space-y-2.5 overflow-y-auto pe-1">
            {cart.map((item) => (
              <li
                key={`${item.recordId}:${item.variant ?? ""}`}
                className="rounded-2xl border border-slate-200 bg-white p-3.5 dark:border-white/10 dark:bg-white/[0.03]"
              >
                <div className="flex items-start justify-between gap-2.5">
                  <div className="flex min-w-0 items-start gap-2.5">
                    {/* ROUND 51 — cart line thumbnail (managed ref at add time) */}
                    {item.imageRef ? (
                      <img
                        src={item.imageRef}
                        alt=""
                        loading="lazy"
                        decoding="async"
                        className="h-11 w-[58px] shrink-0 rounded-xl border border-slate-200/80 object-cover dark:border-white/10"
                      />
                    ) : null}
                    <div className="min-w-0">
                      <p
                        className="truncate text-[13px] font-bold text-slate-800 dark:text-slate-100"
                        title={item.name}
                      >
                        {item.name}
                      </p>
                      {/* ROUND 147 — the chosen variant label rides the line
                          (its own price override is already folded into the
                          unit price the row displays) */}
                      {item.variant ? (
                        <span
                          className="mt-0.5 inline-flex w-fit max-w-full items-center gap-1 rounded-full border border-slate-200 bg-slate-50 px-1.5 py-0.5 text-[9.5px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-400"
                          title={item.variant}
                        >
                          <CatIcon name="tag" className="h-2.5 w-2.5 shrink-0" />
                          <span className="truncate">{item.variant}</span>
                        </span>
                      ) : null}
                      <p
                        dir="ltr"
                        className="mt-0.5 text-start text-[11.5px] font-semibold tabular-nums text-slate-500 dark:text-slate-400"
                      >
                        {fmtPrice(lang, item.price, currency)} × {nf(lang, item.qty)} ={" "}
                        <span className="font-extrabold text-slate-700 dark:text-slate-200">
                          {fmtPrice(lang, item.price * item.qty, currency)}
                        </span>
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onRemove(item.recordId, item.variant)}
                    aria-label={t("storeCartRemove", { name: item.name })}
                    title={t("storeCartRemove", { name: item.name })}
                    className="grid h-8 w-8 shrink-0 place-items-center rounded-xl border border-slate-200 text-slate-400 transition hover:border-rose-300 hover:text-rose-500 active:scale-95 dark:border-white/10 dark:text-slate-500 dark:hover:border-rose-500/40 dark:hover:text-rose-300"
                  >
                    <CatIcon name="trash-2" className="h-3.5 w-3.5" />
                  </button>
                </div>
                <div className="mt-2.5">
                  <StoreQty
                    value={item.qty}
                    min={1}
                    max={item.max}
                    onChange={(qty) => onQty(item.recordId, qty, item.variant)}
                    full
                  />
                </div>
              </li>
            ))}
          </ul>

          {/* ROUND 147 — saved-address shipping chooser (signed-in shopper
              with a non-empty address book): a native radio group (free
              keyboard + screen-reader semantics) listing the saved
              addresses with the DEFAULT preselected; each row shows label +
              fullName + a city/district/street summary, the selected row
              carries the storeAddressSelected chip and the
              storeShipThisAddress hint. Selecting prefills the contact
              fields and swaps the one-line address into the note. A
              manual-entry toggle folds the chooser away so the guest-style
              form below is fully reachable (and back). */}
          {account != null && addresses.length > 0 && !manualAddress ? (
            <div className="space-y-2.5 rounded-2xl border border-slate-200 bg-slate-50/80 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="flex items-center gap-1.5 text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
                    <CatIcon name="map-pin" className="h-3.5 w-3.5 shrink-0" style={{ color: c1 }} />
                    {t("storeShipTo")}
                  </p>
                  <p className="mt-0.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                    {t("storeChooseAddress")}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setManualAddress(true)}
                  aria-label={t("storeGuestTitle")}
                  title={t("storeGuestTitle")}
                  className="inline-flex h-8 shrink-0 items-center gap-1 rounded-full border border-slate-200 bg-white px-2.5 text-[10px] font-bold text-slate-500 transition hover:border-slate-300 hover:text-slate-700 active:scale-95 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-400 dark:hover:text-slate-200"
                >
                  <CatIcon name="pencil-line" className="h-3 w-3" />
                  <span className="whitespace-nowrap">{t("storeGuestTitle")}</span>
                </button>
              </div>
              <div role="radiogroup" aria-label={t("storeChooseAddress")} className="space-y-2">
                {addresses.map((addr) => {
                  const selected = selectedAddressId === addr.id;
                  const summary = [addr.city, addr.district, addr.street]
                    .map((s) => s.trim())
                    .filter((s) => s.length > 0)
                    .join(" · ");
                  return (
                    <label
                      key={addr.id}
                      className={cn(
                        "block cursor-pointer rounded-xl border p-3 transition has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-brand-400/40",
                        selected
                          ? "border-brand-400 bg-brand-500/[0.07] shadow-sm dark:border-brand-500/50 dark:bg-brand-500/10"
                          : "border-slate-200 bg-white hover:border-slate-300 dark:border-white/10 dark:bg-white/[0.04] dark:hover:border-white/20"
                      )}
                    >
                      <input
                        type="radio"
                        name="store-ship-address"
                        className="sr-only"
                        checked={selected}
                        onChange={() => selectAddress(addr)}
                      />
                      <span className="flex items-start justify-between gap-2">
                        <span className="min-w-0">
                          <span className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
                            <span className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                              {addr.label}
                            </span>
                            {addr.isDefault ? (
                              <span className="rounded-full bg-slate-100 px-1.5 py-0.5 text-[9.5px] font-black text-slate-500 dark:bg-white/10 dark:text-slate-400">
                                {t("acctAddressDefaultBadge")}
                              </span>
                            ) : null}
                            {selected ? (
                              <span className="rounded-full border border-brand-300 bg-brand-500/10 px-1.5 py-0.5 text-[9.5px] font-black text-brand-600 dark:border-brand-500/40 dark:text-brand-300">
                                {t("storeAddressSelected")}
                              </span>
                            ) : null}
                          </span>
                          <span
                            className="mt-0.5 block truncate text-[11.5px] font-bold text-slate-500 dark:text-slate-400"
                            title={addr.fullName}
                          >
                            {addr.fullName}
                          </span>
                          {summary ? (
                            <span className="mt-0.5 block truncate text-[10.5px] font-semibold text-slate-400 dark:text-slate-500" title={summary}>
                              {summary}
                            </span>
                          ) : null}
                        </span>
                        <span
                          className={cn(
                            "shrink-0 whitespace-nowrap rounded-full px-2 py-0.5 text-[9.5px] font-bold",
                            selected
                              ? "bg-brand-500/10 text-brand-600 dark:bg-brand-500/15 dark:text-brand-300"
                              : "border border-slate-200 text-slate-400 dark:border-white/10 dark:text-slate-500"
                          )}
                        >
                          {t("storeShipThisAddress")}
                        </span>
                      </span>
                    </label>
                  );
                })}
              </div>
            </div>
          ) : account != null && addresses.length > 0 && manualAddress ? (
            /* manual mode — one tap brings the saved-address chooser back */
            <button
              type="button"
              onClick={() => setManualAddress(false)}
              className="flex w-full items-center justify-between gap-2 rounded-2xl border border-dashed border-slate-300 bg-slate-50/60 px-3.5 py-2.5 text-start transition hover:border-slate-400 active:scale-[0.99] dark:border-white/15 dark:bg-white/[0.02] dark:hover:border-white/25"
            >
              <span className="flex min-w-0 items-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                <CatIcon name="map-pin" className="h-3.5 w-3.5 shrink-0" style={{ color: c1 }} />
                <span className="truncate">{t("storeChooseAddress")}</span>
              </span>
              <CatIcon name="chevron-down" className="h-3.5 w-3.5 shrink-0 text-slate-400" />
            </button>
          ) : null}

          {/* ROUND 44 — guest contact details (name required, phone optional;
              they travel with the order — no account, no sign-in) */}
          <div className="space-y-2.5 rounded-2xl border border-slate-200 bg-slate-50/80 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
            <div>
              <p className="flex items-center gap-1.5 text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
                <CatIcon name="user-round" className="h-3.5 w-3.5 shrink-0" style={{ color: c1 }} />
                {t("storeGuestTitle")}
              </p>
              <p className="mt-0.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                {t("storeGuestDesc")}
              </p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="store-guest-name" className="text-[12px] font-bold">
                {t("storeGuestName")} <span className="text-rose-500">*</span>
              </Label>
              <Input
                id="store-guest-name"
                value={guestName}
                onChange={(e) => setGuestName(e.target.value)}
                placeholder={t("storeGuestNamePh")}
                maxLength={80}
                autoComplete="name"
                aria-invalid={guestAttempted && guestName.trim().length < 2 ? true : undefined}
                className="h-11 rounded-xl"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="store-guest-phone" className="text-[12px] font-bold">
                {t("storeGuestPhone")}
              </Label>
              <Input
                id="store-guest-phone"
                dir="ltr"
                value={guestPhone}
                onChange={(e) => setGuestPhone(e.target.value)}
                placeholder={t("storeGuestPhonePh")}
                maxLength={30}
                autoComplete="tel"
                className="h-11 rounded-xl text-start"
              />
            </div>
            {/* ROUND 65 — the signed-in identity rides with the order (the
                session customer takes priority server-side); read-only. */}
            {account ? (
              <div className="space-y-1.5">
                <Label htmlFor="store-guest-email" className="text-[12px] font-bold">
                  {t("acctProfileEmail")}
                </Label>
                <div className="relative">
                  <Input
                    id="store-guest-email"
                    dir="ltr"
                    readOnly
                    value={account.email}
                    autoComplete="email"
                    className="h-11 rounded-xl bg-slate-100/70 pe-10 text-start font-semibold text-slate-500 dark:bg-white/[0.05] dark:text-slate-400"
                  />
                  <span
                    aria-hidden="true"
                    className="pointer-events-none absolute end-3 top-1/2 grid h-6 w-6 -translate-y-1/2 place-items-center rounded-full bg-slate-200/70 text-slate-400 dark:bg-white/10 dark:text-slate-500"
                  >
                    <CatIcon name="lock" className="h-3 w-3" />
                  </span>
                </div>
              </div>
            ) : null}
          </div>

          {/* order note (optional, ≤ 500 chars — server-validated) */}
          <div className="space-y-1.5">
            <Label htmlFor="store-order-note" className="text-[12px] font-bold">
              {t("storeCartNote")}
            </Label>
            <textarea
              id="store-order-note"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder={t("storeCartNotePh")}
              maxLength={500}
              rows={3}
              className="w-full resize-none rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-[13px] shadow-sm outline-none transition placeholder:text-slate-400 focus:border-brand-400 focus:ring-2 focus:ring-brand-400/20 dark:border-white/10 dark:bg-white/[0.04] dark:text-white dark:placeholder:text-slate-500"
            />
          </div>

          {/* ROUND 50 — coupon entry: input + apply, or the applied chip */}
          <div className="rounded-2xl border border-slate-200 bg-slate-50/80 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
            {applied ? (
              <div className="flex items-center gap-2.5 rounded-xl border border-emerald-300/60 bg-emerald-500/10 px-3 py-2.5 dark:border-emerald-500/40">
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                  <CatIcon name="ticket-percent" className="h-4 w-4" />
                </span>
                <div className="min-w-0 flex-1">
                  <p dir="ltr" className="truncate text-start font-mono text-[12.5px] font-black tracking-wider text-emerald-700 dark:text-emerald-300">
                    {applied.code}
                  </p>
                  <p className="text-[10.5px] font-bold text-emerald-600/80 dark:text-emerald-400/80">
                    {applied.kind === "percent"
                      ? t("storeCouponPercentOff", { n: nf(lang, applied.value) })
                      : t("storeDiscount")}
                  </p>
                </div>
                <p dir="ltr" className="shrink-0 text-[13px] font-black tabular-nums text-emerald-700 dark:text-emerald-300">
                  −{fmtPrice(lang, discount, currency)}
                </p>
                <button
                  type="button"
                  onClick={() => setApplied(null)}
                  aria-label={t("storeCouponRemove")}
                  title={t("storeCouponRemove")}
                  className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-slate-400 transition hover:bg-rose-500/10 hover:text-rose-500 active:scale-95"
                >
                  <CatIcon name="x" className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (couponInput.trim().length >= 3) applyCoupon.mutate();
                }}
                className="flex items-center gap-2"
              >
                <div className="relative min-w-0 flex-1">
                  <CatIcon
                    name="ticket-percent"
                    className="pointer-events-none absolute start-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400"
                  />
                  <Input
                    value={couponInput}
                    onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
                    placeholder={t("storeCouponPh")}
                    maxLength={24}
                    dir="ltr"
                    autoComplete="off"
                    aria-label={t("storeCouponLabel")}
                    className="h-10 rounded-xl bg-white ps-9 font-mono text-[12.5px] font-bold tracking-wider dark:bg-white/[0.04]"
                  />
                </div>
                <Button
                  type="submit"
                  variant="outline"
                  disabled={applyCoupon.isPending || couponInput.trim().length < 3}
                  className="h-10 shrink-0 gap-1.5 rounded-xl px-4 text-[12px] font-extrabold transition active:scale-95"
                >
                  {applyCoupon.isPending ? (
                    <CatIcon name="refresh-cw" className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <CatIcon name="check" className="h-3.5 w-3.5" />
                  )}
                  {t("storeCouponApply")}
                </Button>
              </form>
            )}
          </div>

          {/* total + place order */}
          <div className="space-y-3 rounded-2xl border border-slate-200 bg-slate-50/80 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
            {applied ? (
              <>
                <div className="flex items-center justify-between gap-3">
                  <p className="text-[12px] font-extrabold text-slate-500 dark:text-slate-400">
                    {t("storeSubtotal")}
                  </p>
                  <p dir="ltr" className="text-[13px] font-bold tabular-nums text-slate-500 line-through dark:text-slate-400">
                    {fmtPrice(lang, subtotal, currency)}
                  </p>
                </div>
                <div className="flex items-center justify-between gap-3">
                  <p className="flex items-center gap-1.5 text-[12px] font-extrabold text-emerald-600 dark:text-emerald-400">
                    <CatIcon name="ticket-percent" className="h-3.5 w-3.5" />
                    {t("storeDiscount")}
                  </p>
                  <p dir="ltr" className="text-[13px] font-black tabular-nums text-emerald-600 dark:text-emerald-400">
                    −{fmtPrice(lang, discount, currency)}
                  </p>
                </div>
                <div className="border-t border-dashed border-slate-200 dark:border-white/10" />
              </>
            ) : null}
            <div className="flex items-center justify-between gap-3">
              <p className="text-[12px] font-extrabold text-slate-500 dark:text-slate-400">
                {t("storeCartTotal")}
              </p>
              <p
                dir="ltr"
                className={cn(
                  "font-display tabular-nums text-slate-900 dark:text-white",
                  applied ? "text-[18px] font-black text-emerald-700 dark:text-emerald-300" : "text-[18px] font-black"
                )}
              >
                {fmtPrice(lang, grandTotal, currency)}
              </p>
            </div>
            <Button
              type="button"
              onClick={submitOrder}
              disabled={place.isPending}
              className="h-11 w-full gap-2 rounded-xl text-[13px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.99] disabled:opacity-70"
              style={{
                backgroundImage: grad(c1, c2),
                boxShadow: `0 12px 26px -10px ${hexAlpha(c1, 0.75)}`,
              }}
            >
              {place.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="check-check" className="h-4 w-4" />
              )}
              {place.isPending ? t("storePlacing") : t("storePlace")}
            </Button>
          </div>
        </div>
      )}
    </>
  );
}

/** the cart sheet — slides in from the start edge, themed like the site. */
export function StoreCartSheet({
  open,
  onOpenChange,
  instanceId,
  cart,
  currency,
  c1,
  c2,
  onQty,
  onRemove,
  onClear,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  instanceId: string;
  cart: StoreCartItem[];
  currency: string;
  c1: string;
  c2: string;
  onQty: (recordId: string, qty: number, variant?: string) => void;
  onRemove: (recordId: string, variant?: string) => void;
  onClear: () => void;
}) {
  const { lang } = useT();
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side={lang === "ar" ? "right" : "left"}
        className="w-full gap-0 overflow-y-auto p-0 sm:max-w-md"
      >
        <CartSheetInner
          instanceId={instanceId}
          cart={cart}
          currency={currency}
          c1={c1}
          c2={c2}
          onQty={onQty}
          onRemove={onRemove}
          onClear={onClear}
        />
      </SheetContent>
    </Sheet>
  );
}

/* ------------------------------------------------ wishlist sheet ------- */

/** One saved wishlist row: snapshot or FRESH catalog data (the parent merges
 *  by recordId — fresh wins for price/stock), one-tap add-to-cart, heart-off. */
function WishlistRow({
  item,
  currency,
  c1,
  c2,
  onAdd,
  onRemove,
}: {
  item: SiteProductDTO & { addedAt?: string };
  currency: string;
  c1: string;
  c2: string;
  onAdd: (item: SiteProductDTO) => void;
  onRemove: (recordId: string) => void;
}) {
  const { t, lang } = useT();
  const out = item.stock <= 0;

  return (
    <li className="card-in flex items-center gap-3 rounded-2xl border border-slate-200/80 bg-white p-3 shadow-soft dark:border-white/10 dark:bg-white/[0.03]">
      {/* photo or themed initial */}
      <span className="relative h-14 w-14 shrink-0 overflow-hidden rounded-xl border border-slate-200/80 dark:border-white/10">
        {item.imageRef ? (
          <img
            src={item.imageRef}
            alt={t("storePhotoAlt", { name: item.name })}
            loading="lazy"
            decoding="async"
            className="h-full w-full object-cover"
          />
        ) : (
          <span
            className="grid h-full w-full place-items-center text-[15px] font-black text-white"
            style={{ backgroundImage: grad(c1, c2) }}
          >
            {item.name.trim().charAt(0) || "؟"}
          </span>
        )}
        {out ? (
          <span className="absolute inset-0 grid place-items-center bg-black/55 backdrop-blur-[1px]">
            <span className="rounded-full bg-rose-600 px-2 py-0.5 text-[9px] font-black text-white">
              {t("wishlistOutOfStock")}
            </span>
          </span>
        ) : null}
      </span>

      {/* name + category + price */}
      <div className="min-w-0 flex-1">
        <p className="truncate text-[12.5px] font-extrabold text-slate-900 dark:text-white" title={item.name}>
          {item.name}
        </p>
        {item.category ? (
          <p className="mt-0.5 truncate text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
            {item.category}
          </p>
        ) : null}
        <p dir="ltr" className="mt-1 text-start font-display text-[13.5px] font-black tabular-nums" style={{ color: c1 }}>
          {item.salePrice != null ? (
            <>
              <span className="me-1.5 text-[11px] font-bold text-slate-400 line-through dark:text-slate-500">
                {fmtPrice(lang, item.price, currency)}
              </span>
              {fmtPrice(lang, item.salePrice, currency)}
            </>
          ) : (
            fmtPrice(lang, item.price, currency)
          )}
        </p>
      </div>

      {/* actions */}
      <div className="flex shrink-0 flex-col gap-1.5">
        <Button
          type="button"
          size="sm"
          disabled={out}
          onClick={() => onAdd(item)}
          className="h-8 gap-1 rounded-lg px-3 text-[11px] font-bold text-white shadow-md transition hover:brightness-110 active:scale-95 disabled:opacity-40"
          style={{ backgroundImage: grad(c1, c2) }}
        >
          <CatIcon name="shopping-cart" className="h-3.5 w-3.5" />
          <span className="whitespace-nowrap">{t("wishlistAddToCart")}</span>
        </Button>
        <button
          type="button"
          onClick={() => onRemove(item.recordId)}
          aria-label={t("wishlistRemove", { name: item.name })}
          title={t("wishlistRemove", { name: item.name })}
          className="inline-flex h-8 items-center justify-center gap-1 rounded-lg border border-slate-200 px-3 text-[10.5px] font-bold text-slate-400 transition hover:border-rose-300 hover:text-rose-500 active:scale-95 dark:border-white/10 dark:text-slate-500 dark:hover:border-rose-500/40 dark:hover:text-rose-300"
        >
          <CatIcon name="heart" className="h-3.5 w-3.5 fill-current" />
        </button>
      </div>
    </li>
  );
}

/** the wishlist sheet — slides in from the start edge like the cart sheet.
 *  Items arrive already MERGED with the fresh catalog (parent's job). */
export function StoreWishlistSheet({
  open,
  onOpenChange,
  items,
  currency,
  c1,
  c2,
  onAdd,
  onRemove,
  onClear,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  items: (SiteProductDTO & { addedAt?: string })[];
  currency: string;
  c1: string;
  c2: string;
  onAdd: (item: SiteProductDTO) => void;
  onRemove: (recordId: string) => void;
  onClear: () => void;
}) {
  const { t, lang } = useT();

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side={lang === "ar" ? "right" : "left"}
        className="w-full gap-0 overflow-y-auto p-0 sm:max-w-md"
      >
        <SheetHeader
          className="space-y-0 border-b border-slate-200/70 px-5 pb-4 pt-5 dark:border-white/[0.07]"
          style={{
            background: `linear-gradient(135deg, ${hexAlpha(c1, 0.08)}, transparent 65%)`,
          }}
        >
          <SheetTitle className="flex items-center gap-2.5 font-display text-[15px] font-extrabold">
            <span
              className="grid h-9 w-9 place-items-center rounded-2xl text-white shadow-lg"
              style={{ backgroundImage: "linear-gradient(135deg, #fb7185, #e11d48)" }}
            >
              <CatIcon name="heart" className="h-4 w-4 fill-current" />
            </span>
            {t("wishlistTitle")}
            {items.length > 0 ? (
              <span
                dir="ltr"
                className="rounded-full bg-rose-500/15 px-2 py-0.5 text-[11px] font-black tabular-nums text-rose-600 dark:text-rose-300"
              >
                {nf(lang, items.length)}
              </span>
            ) : null}
          </SheetTitle>
          <SheetDescription className="text-[12px] font-semibold text-slate-500 dark:text-slate-400">
            {t("wishlistDesc")}
          </SheetDescription>
        </SheetHeader>

        <div className="flex flex-col gap-3 p-5">
          {items.length === 0 ? (
            /* ROUND 59 — a delightful empty state instead of plain text: a
             * 72px heart tile on a soft rose→pink gradient, floating gently
             * (wl-float, reduced-motion safe), ringed by tiny decorative
             * heart outlines at varied rotations/opacities, with a radial
             * rose glow blurred behind it. Everything but title + desc is
             * purely decorative (aria-hidden); no new i18n keys. */
            <div className="relative rounded-2xl border-2 border-dashed border-slate-200 px-6 pb-8 pt-10 text-center dark:border-white/10">
              {/* soft radial glow behind the tile */}
              <span
                aria-hidden="true"
                className="pointer-events-none absolute inset-x-4 top-7 h-32 rounded-full bg-rose-500/10 blur-2xl dark:bg-rose-500/20"
              />
              <div className="relative mx-auto h-[72px] w-[72px]">
                {/* tiny decorative heart outlines — varied rotation/opacity */}
                <span
                  aria-hidden="true"
                  className="absolute -start-2 top-1.5 -rotate-[14deg] text-rose-400/70 dark:text-rose-300/50"
                >
                  <CatIcon name="heart" className="h-3 w-3" />
                </span>
                <span
                  aria-hidden="true"
                  className="absolute -end-1.5 top-7 rotate-[16deg] text-rose-300/60 dark:text-rose-400/40"
                >
                  <CatIcon name="heart" className="h-2.5 w-2.5" />
                </span>
                <span
                  aria-hidden="true"
                  className="absolute bottom-0.5 -start-3 rotate-[8deg] text-rose-300/40 dark:text-rose-400/30"
                >
                  <CatIcon name="heart" className="h-2 w-2" />
                </span>
                {/* the floating tile itself */}
                <span className="wl-float grid h-full w-full place-items-center rounded-full bg-gradient-to-br from-rose-400 to-pink-500 text-white shadow-xl shadow-rose-500/30 ring-4 ring-rose-400/10 dark:shadow-rose-400/25">
                  <CatIcon name="heart" className="h-8 w-8 fill-current" />
                </span>
              </div>
              <h3 className="mt-5 font-display text-[14px] font-extrabold text-slate-900 dark:text-white">
                {t("wishlistEmpty")}
              </h3>
              <p className="mx-auto mt-1.5 max-w-xs text-[12px] leading-relaxed text-slate-500 dark:text-slate-400">
                {t("wishlistEmptyDesc")}
              </p>
            </div>
          ) : (
            <>
              <ul className="space-y-2.5">
                {items.map((item) => (
                  <WishlistRow
                    key={item.recordId}
                    item={item}
                    currency={currency}
                    c1={c1}
                    c2={c2}
                    onAdd={onAdd}
                    onRemove={onRemove}
                  />
                ))}
              </ul>

              <div className="mt-1 flex items-center justify-between gap-2 border-t border-slate-200/70 pt-4 dark:border-white/[0.07]">
                <p className="text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                  {t("wishlistDeviceNote")}
                </p>
                <button
                  type="button"
                  onClick={onClear}
                  className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-xl border border-slate-200 px-3.5 text-[11px] font-bold text-slate-500 transition hover:border-rose-300 hover:text-rose-500 active:scale-95 dark:border-white/10 dark:text-slate-400 dark:hover:border-rose-500/40 dark:hover:text-rose-300"
                >
                  <CatIcon name="trash" className="h-3.5 w-3.5" />
                  {t("wishlistClear")}
                </button>
              </div>
            </>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}

/* ------------------------------------------------ order tracking ------ */

/** the 5-step happy-path flow shown as a timeline (cancelled renders its own
 *  terminal state — mirroring the owner console's ORDER_FLOW). */
export const TRACK_FLOW: readonly SiteOrderTrackedDTO["status"][] = [
  "pending",
  "confirmed",
  "preparing",
  "ready",
  "completed",
];

export const TRACK_STEP_META: Record<
  SiteOrderTrackedDTO["status"],
  { icon: string; done: string; current: string }
> = {
  pending: {
    icon: "hourglass",
    done: "border-amber-400/60 bg-amber-500/15 text-amber-600 dark:text-amber-300",
    current: "border-amber-400 bg-amber-500/20 text-amber-600 dark:text-amber-300",
  },
  confirmed: {
    icon: "badge-check",
    done: "border-sky-400/60 bg-sky-500/15 text-sky-600 dark:text-sky-300",
    current: "border-sky-400 bg-sky-500/20 text-sky-600 dark:text-sky-300",
  },
  preparing: {
    icon: "package-open",
    done: "border-violet-400/60 bg-violet-500/15 text-violet-600 dark:text-violet-300",
    current: "border-violet-400 bg-violet-500/20 text-violet-600 dark:text-violet-300",
  },
  ready: {
    icon: "package-check",
    done: "border-emerald-400/60 bg-emerald-500/15 text-emerald-600 dark:text-emerald-300",
    current: "border-emerald-400 bg-emerald-500/20 text-emerald-600 dark:text-emerald-300",
  },
  completed: {
    icon: "circle-check",
    done: "border-emerald-400/60 bg-emerald-500/20 text-emerald-700 dark:text-emerald-300",
    current: "border-emerald-400 bg-emerald-500/25 text-emerald-700 dark:text-emerald-300",
  },
  cancelled: {
    icon: "circle-x",
    done: "border-rose-400/60 bg-rose-500/15 text-rose-600 dark:text-rose-300",
    current: "border-rose-400 bg-rose-500/20 text-rose-600 dark:text-rose-300",
  },
};

const TRACK_STATUS_KEY: Record<SiteOrderTrackedDTO["status"], I18nKey> = {
  pending: "ordStatusPending",
  confirmed: "ordStatusConfirmed",
  preparing: "ordStatusPreparing",
  ready: "ordStatusReady",
  completed: "ordStatusCompleted",
  cancelled: "ordStatusCancelled",
};

/** ROUND 50 — guest order tracking: code + phone → live status timeline.
 *  Lives on the standalone storefront (round 55) under #tracking.
 *  ROUND 62 — a tracked order can be printed as a receipt (the guest
 *  projection carries no unit prices, so the paper prints qty-only lines
 *  with the totals — exactly what the track API exposes). */
export function StoreTrackingCard({
  instanceId,
  c1,
  c2,
  orgName,
  logoUrl,
  orgContact,
}: {
  instanceId: string;
  c1: string;
  c2: string;
  orgName?: string;
  logoUrl?: string | null;
  orgContact?: string;
}) {
  const { t, lang } = useT();
  const [code, setCode] = useState("");
  const [phone, setPhone] = useState("");
  const [result, setResult] = useState<SiteOrderTrackedDTO | null>(null);
  const [notFound, setNotFound] = useState(false);
  /* ROUND 62 — the printable receipt dialog over the tracked order */
  const [receiptOpen, setReceiptOpen] = useState(false);

  const track = useMutation({
    mutationFn: () => trackSiteOrder(instanceId, { code: code.trim().toUpperCase(), phone: phone.trim() }),
    onSuccess: (order) => {
      setResult(order);
      setNotFound(false);
    },
    onError: () => {
      setResult(null);
      setNotFound(true);
    },
  });

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (code.trim().length < 4 || phone.trim().length < 4) return;
    track.mutate();
  };

  const fmtDate = (iso: string) => {
    try {
      return new Intl.DateTimeFormat(intlLocale(lang), {
        dateStyle: "medium",
        timeStyle: "short",
      }).format(new Date(iso));
    } catch {
      return iso.slice(0, 16);
    }
  };

  /* ROUND 56 — compact per-step stamp: time-only when the transition
     happened today, short date + time otherwise. */
  const fmtStep = (iso: string) => {
    try {
      const d = new Date(iso);
      const sameDay = new Date().toDateString() === d.toDateString();
      return new Intl.DateTimeFormat(intlLocale(lang), {
        ...(sameDay ? {} : { day: "numeric", month: "short" }),
        hour: "2-digit",
        minute: "2-digit",
      }).format(d);
    } catch {
      return iso.slice(11, 16);
    }
  };

  /* ROUND 56 — the persistent lifecycle trail drives the timeline: each
     step shows WHEN it happened (latest occurrence — open states can be
     revisited). Legacy rows (empty trail) keep the positional fallback. */
  const history = result?.statusHistory ?? [];
  const stepAt = new Map<string, string>();
  for (const ev of history) {
    stepAt.set(ev.status, ev.at);
  }
  const stepIndexLegacy = result ? TRACK_FLOW.indexOf(result.status) : -1;
  const reached = (step: string) =>
    stepAt.has(step) ||
    (history.length === 0 &&
      stepIndexLegacy >= TRACK_FLOW.indexOf(step as SiteOrderTrackedDTO["status"]));
  const currentAt = result ? (stepAt.get(result.status) ?? null) : null;

  return (
    <Reveal delay={0.05}>
      <div className="mx-auto max-w-2xl">
        <div
          className="overflow-hidden rounded-3xl border border-slate-200/80 bg-white shadow-xl shadow-slate-200/40 dark:border-white/10 dark:bg-white/[0.03] dark:shadow-black/20"
          id="track-order"
        >
          {/* header */}
          <div
            className="border-b border-slate-200/70 px-6 py-5 dark:border-white/10"
            style={{
              backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.12)}, ${hexAlpha(c2, 0.12)})`,
            }}
          >
            <div className="flex items-center gap-3">
              <span
                className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
                style={{ backgroundImage: grad(c1, c2) }}
              >
                <CatIcon name="package-search" className="h-5 w-5" />
              </span>
              <div className="min-w-0">
                <p
                  className="inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[10px] font-extrabold"
                  style={{ borderColor: hexAlpha(c1, 0.35), backgroundColor: hexAlpha(c1, 0.08), color: c1 }}
                >
                  {t("trackBadge")}
                </p>
                <h3 className="mt-1 font-display text-[17px] font-extrabold text-slate-900 dark:text-white">
                  {t("trackTitle")}
                </h3>
              </div>
            </div>
            <p className="mt-2.5 text-[12px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
              {t("trackDesc")}
            </p>
          </div>

          {/* body */}
          <div className="space-y-5 p-6">
            <form onSubmit={submit} className="grid gap-3 sm:grid-cols-[1fr_1fr_auto]">
              <div className="space-y-1.5">
                <Label htmlFor="track-code" className="text-[12px] font-bold">
                  {t("trackCodeLabel")}
                </Label>
                <Input
                  id="track-code"
                  value={code}
                  onChange={(e) => {
                    setCode(e.target.value.toUpperCase());
                    setResult(null);
                    setNotFound(false);
                  }}
                  placeholder={t("trackCodePh")}
                  maxLength={24}
                  dir="ltr"
                  autoComplete="off"
                  className="h-11 rounded-xl text-start font-mono text-[13px] font-bold tracking-wider"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="track-phone" className="text-[12px] font-bold">
                  {t("trackPhoneLabel")}
                </Label>
                <Input
                  id="track-phone"
                  value={phone}
                  onChange={(e) => {
                    setPhone(e.target.value);
                    setResult(null);
                    setNotFound(false);
                  }}
                  placeholder="05xxxxxxxx"
                  maxLength={30}
                  dir="ltr"
                  inputMode="tel"
                  autoComplete="tel"
                  className="h-11 rounded-xl text-start"
                />
              </div>
              <div className="flex items-end">
                <Button
                  type="submit"
                  disabled={track.isPending || code.trim().length < 4 || phone.trim().length < 4}
                  className="h-11 w-full gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.98] disabled:opacity-70 sm:w-auto"
                  style={{
                    backgroundImage: grad(c1, c2),
                    boxShadow: `0 12px 26px -10px ${hexAlpha(c1, 0.75)}`,
                  }}
                >
                  {track.isPending ? (
                    <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                  ) : (
                    <CatIcon name="package-search" className="h-4 w-4" />
                  )}
                  <span className="sm:hidden">{track.isPending ? t("trackTracking") : t("trackBtn")}</span>
                  <span className="hidden sm:inline">{track.isPending ? t("trackTracking") : t("trackBtn")}</span>
                </Button>
              </div>
            </form>

            {notFound ? (
              <div role="alert" className="flex items-start gap-2.5 rounded-2xl border border-rose-300/60 bg-rose-500/10 px-4 py-3.5 dark:border-rose-500/30">
                <CatIcon name="circle-x" className="mt-0.5 h-4 w-4 shrink-0 text-rose-500" />
                <p className="text-[12.5px] font-bold leading-relaxed text-rose-600 dark:text-rose-300">
                  {t("trackNotFound")}
                </p>
              </div>
            ) : null}

            {result ? (
              <div className="space-y-4 rounded-2xl border border-slate-200/80 bg-slate-50/70 p-4 dark:border-white/10 dark:bg-white/[0.03]">
                {/* status timeline */}
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                      {t("ordColStatus")}
                    </p>
                    <div className="flex items-center gap-2">
                      <p dir="ltr" className="font-mono text-[11px] font-black tracking-wider" style={{ color: c1 }}>
                        {result.code}
                      </p>
                      {/* ROUND 62 — print this order as a receipt */}
                      <button
                        type="button"
                        onClick={() => setReceiptOpen(true)}
                        title={t("rcptPrint")}
                        aria-label={t("rcptPrint")}
                        className="inline-flex h-7 items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 text-[10.5px] font-extrabold text-slate-500 transition hover:border-slate-300 hover:text-slate-700 active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:border-white/25 dark:hover:text-white"
                      >
                        <CatIcon name="printer" className="h-3.5 w-3.5" />
                        <span className="hidden sm:inline">{t("rcptPrintShort")}</span>
                      </button>
                    </div>
                  </div>
                  {result.status === "cancelled" ? (
                    <div
                      className={cn(
                        "mt-2.5 flex items-center gap-3 rounded-2xl border px-4 py-3.5",
                        TRACK_STEP_META.cancelled.current
                      )}
                    >
                      <CatIcon name="circle-x" className="h-5 w-5 shrink-0" />
                      <div className="min-w-0">
                        <p className="text-[13px] font-extrabold">{t(TRACK_STATUS_KEY.cancelled)}</p>
                        {result.statusNote ? (
                          <p className="mt-0.5 text-[11.5px] font-semibold opacity-80">{result.statusNote}</p>
                        ) : null}
                        {currentAt ? (
                          <p dir="ltr" className="mt-1 text-start text-[10.5px] font-bold tabular-nums opacity-70">
                            {fmtStep(currentAt)}
                          </p>
                        ) : null}
                      </div>
                    </div>
                  ) : (
                    <ol className="mt-3 flex items-start" dir="ltr">
                      {TRACK_FLOW.map((step, i) => {
                        const meta = TRACK_STEP_META[step];
                        const isDone = reached(step);
                        const isCurrent = result.status === step;
                        const at = stepAt.get(step);
                        const nextReached = i < TRACK_FLOW.length - 1 && reached(TRACK_FLOW[i + 1]);
                        return (
                          <li key={step} className={cn("flex items-start", i < TRACK_FLOW.length - 1 ? "flex-1" : "")}>
                            <div className="flex flex-col items-center gap-1.5" style={{ minWidth: 48 }}>
                              <span
                                className={cn(
                                  "grid h-9 w-9 place-items-center rounded-xl border-2 transition",
                                  isDone ? meta.done : "border-slate-200 bg-white text-slate-300 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-600",
                                  isCurrent && "scale-110 shadow-lg"
                                )}
                              >
                                <CatIcon name={meta.icon} className="h-4 w-4" />
                              </span>
                              <span
                                dir="rtl"
                                className={cn(
                                  "text-center text-[9.5px] font-extrabold leading-tight",
                                  isCurrent ? "text-slate-700 dark:text-slate-200" : "text-slate-400 dark:text-slate-500"
                                )}
                              >
                                {t(TRACK_STATUS_KEY[step])}
                              </span>
                              {/* ROUND 56 — when this step actually happened */}
                              {at ? (
                                <span
                                  dir="ltr"
                                  className="text-center text-[8.5px] font-bold leading-none tabular-nums text-slate-400 dark:text-slate-500"
                                >
                                  {fmtStep(at)}
                                </span>
                              ) : null}
                            </div>
                            {i < TRACK_FLOW.length - 1 ? (
                              <span
                                className={cn(
                                  "mx-1 mt-4 h-0.5 flex-1 rounded-full",
                                  nextReached ? "bg-emerald-400/70" : "bg-slate-200 dark:bg-white/10"
                                )}
                              />
                            ) : null}
                          </li>
                        );
                      })}
                    </ol>
                  )}
                  {result.status !== "cancelled" && result.statusNote ? (
                    <p className="mt-3 flex items-start gap-2 rounded-xl bg-sky-500/10 px-3 py-2 text-[11.5px] font-semibold leading-relaxed text-sky-700 dark:text-sky-300">
                      <CatIcon name="info" className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                      {result.statusNote}
                    </p>
                  ) : null}
                </div>

                {/* items + totals */}
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="rounded-xl border border-slate-200/70 bg-white p-3 dark:border-white/[0.07] dark:bg-white/[0.03]">
                    <p className="mb-2 text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                      {t("trackItems")}
                    </p>
                    <ul className="space-y-1.5">
                      {result.items.map((item, i) => (
                        <li
                          key={i}
                          className="flex items-center gap-2.5 rounded-xl border border-slate-200/60 bg-slate-50/60 px-2 py-1.5 transition hover:border-slate-300/80 dark:border-white/[0.06] dark:bg-white/[0.02] dark:hover:border-white/15"
                        >
                          {/* ROUND 54 — the product photo AS ORDERED (placement-time
                              snapshot); themed initial tile when none was captured */}
                          {item.image ? (
                            <span className="h-10 w-10 shrink-0 overflow-hidden rounded-lg border border-slate-200/80 dark:border-white/10">
                              <img
                                src={item.image}
                                alt={item.name}
                                loading="lazy"
                                decoding="async"
                                className="h-full w-full object-cover"
                              />
                            </span>
                          ) : (
                            <span
                              className="grid h-10 w-10 shrink-0 place-items-center rounded-lg border text-[13px] font-black"
                              style={{
                                borderColor: hexAlpha(c1, 0.25),
                                backgroundColor: hexAlpha(c1, 0.08),
                                color: c1,
                              }}
                              aria-hidden="true"
                            >
                              {item.name.trim().charAt(0)}
                            </span>
                          )}
                          <span className="min-w-0 flex-1 truncate text-[12px] font-bold text-slate-700 dark:text-slate-200">
                            {item.name}
                          </span>
                          <span dir="ltr" className="shrink-0 font-extrabold tabular-nums text-slate-500 dark:text-slate-400">
                            ×{nf(lang, item.qty)}
                          </span>
                        </li>
                      ))}
                      {result.items.length === 0 ? (
                        <li className="text-[11.5px] font-semibold text-slate-400">—</li>
                      ) : null}
                    </ul>
                  </div>
                  <div className="space-y-2 rounded-xl border border-slate-200/70 bg-white p-3 dark:border-white/[0.07] dark:bg-white/[0.03]">
                    <p className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                      {t("trackTotal")}
                    </p>
                    {result.discount > 0 ? (
                      <>
                        <p dir="ltr" className="text-start text-[11.5px] font-bold tabular-nums text-slate-400 line-through">
                          {fmtPrice(lang, result.total + result.discount, result.currency)}
                        </p>
                        <p className="flex items-center gap-1.5 text-[10.5px] font-extrabold text-emerald-600 dark:text-emerald-400">
                          <CatIcon name="ticket-percent" className="h-3 w-3" />
                          {t("trackCouponUsed")} {result.couponCode}
                        </p>
                      </>
                    ) : null}
                    <p dir="ltr" className="text-start font-display text-[16px] font-black tabular-nums text-slate-900 dark:text-white">
                      {fmtPrice(lang, result.total, result.currency)}
                    </p>
                    <div className="space-y-1 border-t border-dashed border-slate-200 pt-2 dark:border-white/10">
                      <p className="flex items-center justify-between gap-2 text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                        <span>{t("trackPlacedAt")}</span>
                        <span dir="ltr">{fmtDate(result.createdAt)}</span>
                      </p>
                      <p className="flex items-center justify-between gap-2 text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                        <span>{t("trackUpdated")}</span>
                        <span dir="ltr">{fmtDate(result.updatedAt)}</span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      </div>

      {/* ROUND 62 — the printable receipt for the tracked order (guest
          projection: qty-only lines, totals, trail — no PII, no prices) */}
      <OrderReceiptDialog
        open={receiptOpen}
        onOpenChange={setReceiptOpen}
        identity={{
          orgName: orgName?.trim() || t("storeBadge"),
          logoUrl: logoUrl ?? null,
          c1,
          c2,
          orgContact: orgContact?.trim() || null,
        }}
        data={
          result
            ? {
                code: result.code,
                items: result.items.map((it) => ({ name: it.name, qty: it.qty, unitPrice: null })),
                total: result.total,
                discount: result.discount,
                couponCode: result.couponCode,
                currency: result.currency,
                status: result.status,
                statusHistory: result.statusHistory,
                createdAt: result.createdAt,
                updatedAt: result.updatedAt,
              }
            : null
        }
        /* ROUND 119 — the standalone receipt-page link (the track
           response's MAC-sealed token): copy → re-open the printable
           receipt anywhere without re-entering the code + phone. */
        shareUrl={
          result?.receiptToken
            ? `/sites/${instanceId}/receipt?token=${encodeURIComponent(result.receiptToken)}`
            : null
        }
        /* ROUND 121 — the receipt QR (same bearer token, server-minted
           SVG — the endpoint verifies the token before minting): scan to
           open the standalone receipt page on the phone. */
        qrSrc={
          result?.receiptToken
            ? `/api/sites/${instanceId}/receipt-qr?token=${encodeURIComponent(result.receiptToken)}`
            : null
        }
      />
    </Reveal>
  );
}

/* ------------------------------------------------------------------ */
/* ROUND 60 — the store share dialog (QR + copy link + native share)   */
/*                                                                     */
/* A centered card: the QR is minted SERVER-SIDE by the public route    */
/* /api/sites/[id]/store-qr (SVG, published sites only, rate-limited,  */
/* URL derived from the request's own host — never caller-supplied),   */
/* while the copy/native-share actions use the visitor's own origin    */
/* resolved here (no state: the dialog content only renders after a   */
/* client-side open click, so window is guaranteed there).             */
/* ------------------------------------------------------------------ */
export function StoreShareDialog({
  open,
  onOpenChange,
  instanceId,
  orgName,
  c1,
  c2,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  instanceId: string;
  orgName: string;
  c1: string;
  c2: string;
}) {
  const { t } = useT();
  const [qrState, setQrState] = useState<"loading" | "ok" | "error">("loading");
  const [copied, setCopied] = useState(false);

  /* reset the QR state every time the dialog re-opens (render-time
   * previous-value pattern — react-hooks v7 clean, no effect setState) */
  const [prevOpen, setPrevOpen] = useState(open);
  if (open !== prevOpen) {
    setPrevOpen(open);
    if (open) setQrState("loading");
  }

  /* the URL + native-share capability — derived statelessly. During SSR
   * and closed renders these are ""/false, but the dialog content below
   * only renders after a client click, so window/navigator are safe. */
  const shareUrl =
    typeof window !== "undefined"
      ? `${window.location.origin}/sites/${instanceId}/store`
      : "";
  const canNative =
    typeof navigator !== "undefined" && typeof navigator.share === "function";

  /* copied feedback auto-clear (the effect owns ONLY the timer). */
  useEffect(() => {
    if (!copied) return;
    const id = window.setTimeout(() => setCopied(false), 1600);
    return () => window.clearTimeout(id);
  }, [copied]);

  /* the cached-image race guard — the same stable ref callback the product
   * card uses: fires at attach, covers QRs that finished loading before
   * React attached onLoad (browser cache), and re-fires on remount. */
  const attachQr = useCallback((el: HTMLImageElement | null) => {
    if (el?.complete) setQrState(el.naturalWidth > 0 ? "ok" : "error");
  }, []);

  const copyLink = async () => {
    if (!shareUrl) return;
    try {
      await navigator.clipboard.writeText(shareUrl);
    } catch {
      /* non-secure-context fallback — the legacy textarea copy */
      try {
        const ta = document.createElement("textarea");
        ta.value = shareUrl;
        ta.style.position = "fixed";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.select();
        document.execCommand("copy");
        ta.remove();
      } catch {
        return;
      }
    }
    setCopied(true);
    toast.success(t("storeShareCopied"));
  };

  const nativeShare = async () => {
    if (!canNative || !shareUrl) return;
    try {
      await navigator.share({ title: orgName, url: shareUrl });
    } catch {
      /* the user dismissed the OS share sheet — not an error */
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[calc(100vw-2rem)] gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-sm">
        {/* themed header */}
        <div
          className="border-b border-slate-200/70 px-6 pb-5 pt-6 dark:border-white/[0.07]"
          style={{
            background: `linear-gradient(135deg, ${hexAlpha(c1, 0.1)}, ${hexAlpha(c2, 0.06)} 60%, transparent)`,
          }}
        >
          <div className="flex items-center gap-3">
            <span
              className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
              style={{
                backgroundImage: grad(c1, c2),
                boxShadow: `0 10px 24px -10px ${hexAlpha(c1, 0.8)}`,
              }}
            >
              <CatIcon name="share-2" className="h-5 w-5" />
            </span>
            <div className="min-w-0">
              <DialogTitle className="text-start font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                {t("storeShareTitle")}
              </DialogTitle>
              <p className="mt-0.5 truncate text-[11.5px] font-bold text-slate-500 dark:text-slate-400">
                {orgName} — {t("storeBadge")}
              </p>
            </div>
          </div>
          <DialogDescription className="mt-3 text-[12px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
            {t("storeShareDesc")}
          </DialogDescription>
        </div>

        {/* body — the QR tile + the link + the actions */}
        <div className="flex flex-col items-center gap-4 px-6 py-6">
          <div className="relative">
            {/* themed glow behind the tile */}
            <span
              aria-hidden="true"
              className="qr-glow pointer-events-none absolute -inset-4 rounded-[2.5rem] blur-2xl"
              style={{
                background: `radial-gradient(closest-side, ${hexAlpha(c1, 0.3)}, transparent)`,
              }}
            />
            <span className="card-in relative grid place-items-center rounded-2xl bg-white p-3.5 shadow-xl ring-1 ring-slate-200 dark:ring-white/10">
              {/* viewfinder corner brackets — the scanner affordance */}
              {(
                [
                  "top-0 start-0 rounded-tl-2xl border-t-[3px] border-s-[3px]",
                  "top-0 end-0 rounded-tr-2xl border-t-[3px] border-e-[3px]",
                  "bottom-0 start-0 rounded-bl-2xl border-b-[3px] border-s-[3px]",
                  "bottom-0 end-0 rounded-br-2xl border-b-[3px] border-e-[3px]",
                ] as const
              ).map((pos) => (
                <span
                  key={pos}
                  aria-hidden="true"
                  className={cn("pointer-events-none absolute h-6 w-6", pos)}
                  style={{ borderColor: c1 }}
                />
              ))}

              {qrState === "error" ? (
                /* QR unavailable (rate-limited / transient) — tap to retry;
                 * the copy/native actions below still work regardless */
                <button
                  type="button"
                  onClick={() => setQrState("loading")}
                  className="grid h-44 w-44 place-items-center rounded-xl bg-slate-100 text-slate-300 transition hover:bg-slate-200 hover:text-slate-400 active:scale-95 dark:bg-slate-200"
                  aria-label={t("storeShareScanHint")}
                >
                  <CatIcon name="refresh-cw" className="h-10 w-10" />
                </button>
              ) : (
                // eslint-disable-next-line @next/next/no-img-element -- the QR is a dynamically minted SVG from our own API route; next/image optimization does not apply
                <img
                  ref={attachQr}
                  src={`/api/sites/${instanceId}/store-qr`}
                  alt={t("storeShareQrAlt")}
                  onLoad={() => setQrState("ok")}
                  onError={() => setQrState("error")}
                  className={cn(
                    "h-44 w-44 rounded-xl transition-opacity duration-300",
                    qrState === "loading" ? "opacity-0" : "opacity-100"
                  )}
                />
              )}
              {qrState === "loading" ? (
                <span className="absolute inset-3.5 grid place-items-center rounded-xl bg-slate-100">
                  <span className="h-8 w-8 animate-spin rounded-full border-[3px] border-slate-200 border-t-slate-500" />
                </span>
              ) : null}
            </span>
          </div>

          {/* scan hint */}
          <p className="inline-flex items-center gap-1.5 text-[11.5px] font-bold text-slate-400 dark:text-slate-500">
            <CatIcon name="qr" className="h-3.5 w-3.5" />
            {t("storeShareScanHint")}
          </p>

          {/* the link itself — truncated, LTR, full URL on hover */}
          <p
            dir="ltr"
            title={shareUrl}
            className="w-full select-all truncate rounded-xl border border-slate-200 bg-white/70 px-3.5 py-2.5 text-center font-mono text-[11px] font-semibold text-slate-500 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-400"
          >
            {shareUrl}
          </p>

          {/* actions */}
          <div className="grid w-full gap-2">
            <Button
              type="button"
              onClick={copyLink}
              className={cn(
                "h-11 gap-2 rounded-xl text-[12.5px] font-bold text-white shadow-lg transition hover:brightness-110 active:scale-95",
                copied && "brightness-110"
              )}
              style={{ backgroundImage: grad(c1, c2) }}
            >
              <CatIcon name={copied ? "circle-check" : "clipboard-check"} className="h-4 w-4" />
              {copied ? t("storeShareCopied") : t("storeShareCopy")}
            </Button>
            {canNative ? (
              <Button
                type="button"
                variant="outline"
                onClick={nativeShare}
                className="h-11 gap-2 rounded-xl border-slate-200 bg-white text-[12.5px] font-bold text-slate-700 shadow-sm transition hover:border-transparent hover:shadow-lift active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200"
              >
                <CatIcon name="share-2" className="h-4 w-4" />
                {t("storeShareNative")}
              </Button>
            ) : null}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/* ------------------------------------------------------------------ */
/* ROUND 61 — the product quick-view dialog (Amazon-style detail peek)  */
/*                                                                     */
/* Opens from the storefront card (photo eye-button or the product      */
/* name). Two columns on ≥sm (photo at the inline-START, details at     */
/* the inline-END), stacked on mobile. Same photo state machine as the  */
/* card (skeleton shimmer → themed fallback), same sale/stock/featured  */
/* merchandising vocabulary, qty stepper + add-to-cart + wishlist.     */
/* ------------------------------------------------------------------ */
export function StoreProductQuickView({
  open,
  onOpenChange,
  product,
  currency,
  c1,
  c2,
  onAdd,
  onToggleWishlist,
  wishlisted = false,
  onOpenReviews,
  related,
  onSwitchProduct,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  product: SiteProductDTO | null;
  currency: string;
  c1: string;
  c2: string;
  onAdd: (product: SiteProductDTO, qty: number, variantLabel?: string) => void;
  onToggleWishlist?: (product: SiteProductDTO) => void;
  wishlisted?: boolean;
  /** ROUND 63 — opens the product's reviews & ratings dialog (undefined =
   *  the reviews entry button stays hidden) */
  onOpenReviews?: (product: SiteProductDTO) => void;
  /** ROUND 147 — same-category siblings (≤6, the current product excluded)
   *  rendered as compact rows under the details column; clicking a row
   *  switches the quick view to that product. */
  related?: SiteProductDTO[];
  /** ROUND 147 — chains the quick view to another product (the host passes
   *  its own quick-view open handler — also recording recently-viewed). */
  onSwitchProduct?: (product: SiteProductDTO) => void;
}) {
  const { t, lang } = useT();
  const [qty, setQty] = useState(1);
  /* ROUND 147 — the selected variant LABEL (round 141): null = no variant
   * chosen (single-SKU display). Reset per product with the same
   * render-time previous-value pattern as qty/media below. */
  const [variantSel, setVariantSel] = useState<string | null>(null);
  const ar = lang === "ar";

  /* ROUND 140 — the product MEDIA CAROUSEL: the ordered photo gallery
   * (cover first) followed by the video clips; one index navigates both.
   * ALL hooks run unconditionally BEFORE the null-product early return
   * below (the dialog mounts once and stays mounted — rules-of-hooks). */
  const mediaItems = useMemo<
    Array<{ kind: "image"; src: string } | { kind: "video"; src: string }>
  >(() => {
    const photos = (product?.gallery ?? []).map((src) => ({ kind: "image" as const, src }));
    const clips = (product?.videos ?? []).map((src) => ({ kind: "video" as const, src }));
    return [...photos, ...clips];
  }, [product]);
  const [mediaIndex, setMediaIndex] = useState(0);

  /* the card's photo state machine, verbatim (shimmer / themed fallback /
   * cached-image race guard) — now keyed to the ACTIVE media image. */
  const activeImage =
    mediaItems[mediaIndex]?.kind === "image" ? (mediaItems[mediaIndex] as { kind: "image"; src: string }).src : null;
  const [imgState, setImgState] = useState<"loading" | "ok" | "error">("loading");
  const [prevPhoto, setPrevPhoto] = useState(activeImage);
  if (activeImage !== prevPhoto) {
    setPrevPhoto(activeImage);
    setImgState("loading");
  }
  const attachImg = useCallback((el: HTMLImageElement | null) => {
    if (el?.complete) setImgState(el.naturalWidth > 0 ? "ok" : "error");
  }, []);

  /* per-product qty + media + variant reset DURING render (previous-value
   * pattern — the visitor peeks at product after product without
   * unmounting) */
  const [prevId, setPrevId] = useState(product?.recordId);
  if (product?.recordId !== prevId) {
    setPrevId(product?.recordId);
    setQty(1);
    setMediaIndex(0);
    setVariantSel(null);
  }
  /* safety clamp (a stale index past a shorter media list) */
  const safeIndex = Math.min(mediaIndex, Math.max(0, mediaItems.length - 1));
  const goPrevMedia = () => setMediaIndex((i) => (i - 1 + mediaItems.length) % mediaItems.length);
  const goNextMedia = () => setMediaIndex((i) => (i + 1) % mediaItems.length);

  if (!product) {
    /* closed / no selection — render the bare dialog shell (keeps Radix
     * state consistent without conditional mounting at the call site). The
     * sr-only title+description satisfy Radix's accessibility contract. */
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="hidden">
          <DialogTitle className="sr-only">{t("storeQuickViewTitle")}</DialogTitle>
          <DialogDescription className="sr-only">{t("storeQuickViewTitle")}</DialogDescription>
        </DialogContent>
      </Dialog>
    );
  }

  /* ROUND 147 — the variant-aware truth: the chosen variant's price
   * OVERRIDES the product price (round 141) — sale pricing only applies
   * when NO variant override is in play; the variant's own stock carve-out
   * caps the qty stepper (and a sold-out variant disables add honestly). */
  const selectedVariant =
    variantSel != null ? (product.variants.find((v) => v.name === variantSel) ?? null) : null;
  const variantOut = selectedVariant?.stock != null && selectedVariant.stock <= 0;
  const max = Math.min(
    99,
    Math.max(1, Math.floor(selectedVariant?.stock ?? product.stock) || 1)
  );
  const low = product.statusKey === "low" || product.stock <= 10;
  const onSale = product.salePrice != null && selectedVariant?.price == null;
  const effective =
    selectedVariant?.price != null
      ? selectedVariant.price
      : onSale
        ? (product.salePrice as number)
        : product.price;
  const salePct = onSale ? Math.round((1 - effective / product.price) * 100) : 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[calc(100vw-1.5rem)] gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-3xl">
        {/* sr-only description — the visible stock/category chips below
         * carry this visually; this makes it one screen-reader announcement */}
        <DialogDescription className="sr-only">
          {`${product.name}${product.category ? ` — ${product.category}` : ""} — ${
            low ? t("storeStockLow") : t("storeStockIn")
          }`}
        </DialogDescription>
        <div className="grid sm:grid-cols-2">
          {/* ---------------- media column (inline-START in RTL) --------- */}
          <div
            className={cn(
              "relative flex flex-col overflow-hidden",
              activeImage === null && mediaItems[safeIndex]?.kind !== "video" && "img-loading"
            )}
            style={
              imgState === "error" || (!activeImage && mediaItems[safeIndex]?.kind !== "video")
                ? { backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.85)}, ${hexAlpha(c2, 0.9)})` }
                : { backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.08)}, ${hexAlpha(c2, 0.05)})` }
            }
          >
            {/* the main viewer */}
            <div
              className={cn(
                "relative aspect-[4/3] w-full overflow-hidden sm:aspect-auto sm:min-h-[380px]",
                imgState === "loading" && activeImage !== null && "img-loading"
              )}
            >
              {mediaItems[safeIndex]?.kind === "video" ? (
                // eslint-disable-next-line jsx-a11y/media-has-caption -- a merchant product clip; the aria-label carries the context
                <video
                  src={mediaItems[safeIndex].src}
                  controls
                  autoPlay={false}
                  preload="metadata"
                  playsInline
                  aria-label={t("storeQvVideoLabel", { name: product.name })}
                  className="absolute inset-0 h-full w-full bg-slate-950 object-contain"
                />
              ) : activeImage && imgState !== "error" ? (
                // eslint-disable-next-line @next/next/no-img-element -- merchant-hosted store photo served from the workspace's own storage API; next/image optimization does not apply
                <img
                  key={activeImage}
                  ref={attachImg}
                  src={activeImage}
                  alt={t("storePhotoAlt", { name: product.name })}
                  onError={() => setImgState("error")}
                  onLoad={() => setImgState("ok")}
                  className="absolute inset-0 h-full w-full object-cover"
                />
              ) : (
                <div className="absolute inset-0 grid place-content-center justify-items-center gap-3 p-6">
                  <span
                    aria-hidden="true"
                    className="font-display text-[72px] font-black leading-none text-white/95 drop-shadow-lg"
                  >
                    {product.name.trim().charAt(0) || "؟"}
                  </span>
                  {product.category ? (
                    <span className="max-w-full truncate rounded-full border border-white/30 bg-black/25 px-3 py-1 text-[11px] font-extrabold text-white backdrop-blur-sm">
                      {product.category}
                    </span>
                  ) : null}
                </div>
              )}

              {/* merchandising chips — the card's vocabulary, larger */}
              <div className="pointer-events-none absolute inset-x-3 top-3 flex items-start justify-between gap-2">
                {product.category && (activeImage ?? null) && imgState !== "error" ? (
                  <span className="inline-flex min-w-0 items-center gap-1 rounded-full border border-white/25 bg-black/45 px-2.5 py-1 text-[11px] font-extrabold text-white backdrop-blur-md">
                    <CatIcon name="tag" className="h-3 w-3 shrink-0" />
                    <span className="max-w-40 truncate">{product.category}</span>
                  </span>
                ) : (
                  <span />
                )}
                <span className="flex shrink-0 flex-col items-end gap-1.5">
                  {product.featured ? (
                    <span className="inline-flex items-center gap-1 rounded-full border border-amber-300/70 bg-gradient-to-l from-amber-400 to-orange-500 px-2.5 py-1 text-[11px] font-extrabold text-white shadow-md">
                      <CatIcon name="star" className="h-3 w-3 fill-current" />
                      {t("storeFeaturedBadge")}
                    </span>
                  ) : null}
                  {onSale ? (
                    <span
                      dir="ltr"
                      className="rounded-full bg-rose-600 px-2.5 py-1 text-[11.5px] font-black text-white shadow-md"
                    >
                      −{nf(lang, salePct)}%
                    </span>
                  ) : null}
                  {/* ROUND 140 — the media position indicator */}
                  {mediaItems.length > 1 ? (
                    <span
                      dir="ltr"
                      className="rounded-full bg-black/50 px-2.5 py-1 text-[10.5px] font-black text-white backdrop-blur-md"
                    >
                      {t("storeQvMediaPos", {
                        i: nf(lang, safeIndex + 1),
                        n: nf(lang, mediaItems.length),
                      })}
                    </span>
                  ) : null}
                </span>
              </div>

              {/* ROUND 140 — the carousel arrows (RTL-aware) */}
              {mediaItems.length > 1 ? (
                <>
                  <button
                    type="button"
                    onClick={goPrevMedia}
                    aria-label={t("storeQvPrevMedia")}
                    className="absolute start-2.5 top-1/2 z-10 grid h-9 w-9 -translate-y-1/2 place-items-center rounded-full bg-white/90 text-slate-700 shadow-md backdrop-blur transition hover:bg-white active:scale-90"
                  >
                    <CatIcon name={ar ? "arrow-right" : "arrow-left"} className="h-4.5 w-4.5" />
                  </button>
                  <button
                    type="button"
                    onClick={goNextMedia}
                    aria-label={t("storeQvNextMedia")}
                    className="absolute end-2.5 top-1/2 z-10 grid h-9 w-9 -translate-y-1/2 place-items-center rounded-full bg-white/90 text-slate-700 shadow-md backdrop-blur transition hover:bg-white active:scale-90"
                  >
                    <CatIcon name={ar ? "arrow-left" : "arrow-right"} className="h-4.5 w-4.5" />
                  </button>
                </>
              ) : null}

              {/* wishlist heart — the photo's bottom-START corner */}
              {onToggleWishlist ? (
                <WishlistHeart
                  active={wishlisted}
                  labelOn={t("wishlistRemove", { name: product.name })}
                  labelOff={t("wishlistAdd", { name: product.name })}
                  onClick={() => onToggleWishlist(product)}
                  className="absolute bottom-3 start-3 h-11 w-11"
                />
              ) : null}
            </div>

            {/* ROUND 140 — the media thumbnail strip (photos + video slots) */}
            {mediaItems.length > 1 ? (
              <div
                role="tablist"
                aria-label={t("estoreMediaTitle")}
                className="flex gap-2 overflow-x-auto border-t border-slate-200/70 p-2.5 [scrollbar-width:thin] dark:border-white/10"
              >
                {mediaItems.map((item, i) => (
                  <button
                    key={item.src}
                    type="button"
                    role="tab"
                    aria-selected={i === safeIndex}
                    onClick={() => setMediaIndex(i)}
                    title={
                      item.kind === "video"
                        ? t("storeQvVideoLabel", { name: product.name })
                        : t("storePhotoAlt", { name: product.name })
                    }
                    aria-label={
                      item.kind === "video"
                        ? t("storeQvVideoLabel", { name: product.name })
                        : t("storePhotoAlt", { name: product.name })
                    }
                    className={cn(
                      "relative h-14 w-14 shrink-0 overflow-hidden rounded-xl border-2 transition",
                      i === safeIndex
                        ? "border-brand-500 ring-2 ring-brand-500/25"
                        : "border-transparent opacity-70 hover:opacity-100"
                    )}
                  >
                    {item.kind === "video" ? (
                      <>
                        {/* eslint-disable-next-line jsx-a11y/media-has-caption -- a muted poster thumb; the button's aria-label carries the context */}
                        <video
                          src={item.src}
                          preload="metadata"
                          muted
                          playsInline
                          className="h-full w-full bg-slate-950 object-cover"
                        />
                        <span className="absolute inset-0 grid place-items-center bg-black/35">
                          <CatIcon name="play" className="h-4 w-4 fill-current text-white drop-shadow" />
                        </span>
                      </>
                    ) : (
                      // eslint-disable-next-line @next/next/no-img-element -- merchant-hosted store photo (managed ref); next/image optimization does not apply
                      <img
                        src={item.src}
                        alt=""
                        loading="lazy"
                        decoding="async"
                        className="h-full w-full object-cover"
                      />
                    )}
                  </button>
                ))}
              </div>
            ) : null}
          </div>

          {/* ---------------- details column (inline-END in RTL) --------- */}
          <div className="flex flex-col gap-4 p-5 sm:p-6">
            <div className="min-w-0">
              <p className="mb-1.5 text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                {t("storeQuickViewTitle")}
              </p>
              {/* DialogTitle — Radix's accessibility contract (aria-linked) */}
              <DialogTitle
                className="text-start font-display text-[18px] font-extrabold leading-snug text-slate-900 dark:text-white"
                title={product.name}
              >
                {product.featured ? (
                  <CatIcon
                    name="star"
                    className="me-1.5 inline h-4 w-4 fill-current text-amber-500 dark:text-amber-300"
                  />
                ) : null}
                {product.name}
              </DialogTitle>
            </div>

            {/* ROUND 63 — rating summary + the reviews dialog entry: stars +
             * locale average + count when rated, and ALWAYS the secondary
             * reviews button (it doubles as the “be the first to review”
             * affordance when count = 0 — hidden only when the host passes
             * no onOpenReviews) */}
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5">
              {product.ratingCount > 0 ? (
                <span className="inline-flex items-center gap-2">
                  <StarsRow value={product.ratingAvg ?? 0} size="md" />
                  <span
                    dir="ltr"
                    className="font-display text-[13px] font-black tabular-nums text-slate-800 dark:text-slate-100"
                  >
                    {nf(lang, product.ratingAvg ?? 0)}
                  </span>
                  <span className="text-[11.5px] font-bold text-slate-500 dark:text-slate-400">
                    {t("reviewsCountLabel", { n: nf(lang, product.ratingCount) })}
                  </span>
                </span>
              ) : null}
              {onOpenReviews ? (
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => onOpenReviews(product)}
                  className="h-8 w-fit gap-1.5 rounded-full border-slate-200 bg-white px-3.5 text-[11.5px] font-bold text-slate-700 shadow-sm transition hover:border-transparent hover:shadow-lift active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200"
                >
                  <CatIcon name="message-square" className="h-3.5 w-3.5 shrink-0" />
                  {t("reviewsViewBtn", { n: nf(lang, product.ratingCount) })}
                </Button>
              ) : null}
            </div>

            {/* stock chip */}
            <span
              className={cn(
                "inline-flex w-fit items-center gap-1.5 rounded-full border px-3 py-1 text-[11.5px] font-extrabold",
                low
                  ? "border-amber-300/60 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300"
                  : "border-emerald-300/60 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
              )}
              title={t("storeStockLeft", { n: nf(lang, product.stock) })}
            >
              <span
                className={cn("h-2 w-2 rounded-full", low ? "bg-amber-500" : "bg-emerald-500")}
                aria-hidden="true"
              />
              {low ? t("storeStockLow") : t("storeStockIn")}
              <span dir="ltr" className="tabular-nums opacity-70">
                ({nf(lang, product.stock)})
              </span>
            </span>

            {/* price block — the sale vocabulary when the effective price
                sits below the base (an active sale OR a cheaper variant
                override); the variant override renders in the BRAND color
                (it is an option price, not necessarily a sale) */}
            {effective < product.price ? (
              <div dir="ltr" className="flex items-end gap-2.5">
                <span className="text-start font-display text-[15px] font-bold tabular-nums text-slate-400 line-through dark:text-slate-500">
                  {fmtPrice(lang, product.price, currency)}
                </span>
                <span
                  className={cn(
                    "text-start font-display text-[28px] font-black tabular-nums",
                    onSale ? "text-rose-600 dark:text-rose-400" : undefined
                  )}
                  style={onSale ? undefined : { color: c1 }}
                >
                  {fmtPrice(lang, effective, currency)}
                </span>
              </div>
            ) : (
              <p
                dir="ltr"
                className="text-start font-display text-[28px] font-black tabular-nums"
                style={{ color: c1 }}
              >
                {fmtPrice(lang, effective, currency)}
              </p>
            )}
            {onSale && product.saleEndsAt ? <SaleCountdownChip endsAt={product.saleEndsAt} /> : null}

            {/* ROUND 147 — the variant picker (round 141 متغيرات): label
                chips with a selected ring; a variant that carries its own
                price shows it beside the label (dir=ltr + tabular-nums); the
                selection rides the cart line + the placement body. */}
            {product.variants.length > 0 ? (
              <fieldset className="space-y-2">
                <legend className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  {t("storeVariantLabel")}
                </legend>
                <div className="flex flex-wrap gap-1.5">
                  {product.variants.map((v) => {
                    const active = variantSel === v.name;
                    return (
                      <button
                        key={v.id}
                        type="button"
                        aria-pressed={active}
                        onClick={() => setVariantSel(active ? null : v.name)}
                        title={v.name}
                        className={cn(
                          "inline-flex min-h-9 items-center gap-1.5 rounded-full border px-3 text-[11.5px] font-extrabold transition active:scale-95",
                          active
                            ? "border-brand-400 bg-brand-500/10 text-brand-600 ring-2 ring-brand-400/30 dark:border-brand-500/60 dark:text-brand-300 dark:ring-brand-500/25"
                            : "border-slate-200 bg-white/70 text-slate-600 hover:border-slate-300 hover:text-slate-800 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:text-white"
                        )}
                      >
                        <span className="max-w-40 truncate">{v.name}</span>
                        {v.price != null ? (
                          <span
                            dir="ltr"
                            className="text-[10.5px] font-black tabular-nums opacity-80"
                          >
                            {fmtPrice(lang, v.price, currency)}
                          </span>
                        ) : null}
                      </button>
                    );
                  })}
                </div>
                {variantOut ? (
                  <p className="text-[10.5px] font-bold text-rose-500 dark:text-rose-400">
                    {t("wishlistOutOfStock")}
                  </p>
                ) : null}
              </fieldset>
            ) : null}

            {/* qty + add */}
            <div className="mt-auto space-y-2.5 pt-2">
              <StoreQty value={qty} min={1} max={max} onChange={setQty} full />
              <Button
                type="button"
                onClick={() => {
                  onAdd(product, qty, selectedVariant?.name);
                  onOpenChange(false);
                }}
                disabled={variantOut}
                className="btn-grad h-12 w-full gap-2 rounded-xl text-[13px] font-bold text-white shadow-lg transition-[transform,filter,background-position,background-size] duration-200 ease-[cubic-bezier(0.22,1,0.36,1)] hover:brightness-110 active:scale-95 disabled:opacity-60"
                style={{
                  backgroundImage: grad(c1, c2),
                  boxShadow: `0 12px 26px -12px ${hexAlpha(c1, 0.75)}`,
                }}
              >
                <CatIcon name="shopping-cart" className="h-[18px] w-[18px]" />
                {t("storeAdd")}
              </Button>
            </div>

            {/* ROUND 147 — related products: same-category siblings from
                the same fetched catalog; clicking a row CHAINS the quick
                view to that product (the host's own open handler), and the
                end-side button quick-adds it to the cart. */}
            {related && related.length > 0 ? (
              <div className="space-y-2 border-t border-slate-200/70 pt-3.5 dark:border-white/10">
                <p className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  {t("storeRelatedTitle")}
                </p>
                <ul className="nice-scroll max-h-44 space-y-1.5 overflow-y-auto pe-1">
                  {related.map((rp) => {
                    const rpOnSale = rp.salePrice != null;
                    const rpEffective = rpOnSale ? (rp.salePrice as number) : rp.price;
                    return (
                      <li
                        key={rp.recordId}
                        className="flex items-center gap-2.5 rounded-xl border border-slate-200 bg-white/70 p-2 transition hover:border-slate-300 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-white/20"
                      >
                        <button
                          type="button"
                          onClick={() => onSwitchProduct?.(rp)}
                          aria-label={t("storeQuickViewAria", { name: rp.name })}
                          title={rp.name}
                          className="flex min-w-0 flex-1 items-center gap-2.5 text-start"
                        >
                          <span className="relative h-10 w-10 shrink-0 overflow-hidden rounded-lg border border-slate-200/80 dark:border-white/10">
                            {rp.imageRef ? (
                              <img
                                src={rp.imageRef}
                                alt=""
                                loading="lazy"
                                decoding="async"
                                className="h-full w-full object-cover"
                              />
                            ) : (
                              <span
                                className="grid h-full w-full place-items-center text-[11px] font-black text-white"
                                style={{ backgroundImage: grad(c1, c2) }}
                              >
                                {rp.name.trim().charAt(0) || "؟"}
                              </span>
                            )}
                          </span>
                          <span className="min-w-0 flex-1">
                            <span className="block truncate text-[11.5px] font-extrabold text-slate-800 dark:text-slate-100">
                              {rp.name}
                            </span>
                            <span
                              dir="ltr"
                              className="mt-0.5 block text-start text-[11px] font-black tabular-nums"
                              style={{ color: c1 }}
                            >
                              {rpOnSale ? (
                                <>
                                  <span className="me-1.5 text-[9.5px] font-bold text-slate-400 line-through dark:text-slate-500">
                                    {fmtPrice(lang, rp.price, currency)}
                                  </span>
                                  {fmtPrice(lang, rpEffective, currency)}
                                </>
                              ) : (
                                fmtPrice(lang, rpEffective, currency)
                              )}
                            </span>
                          </span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onAdd(rp, 1)}
                          aria-label={t("storeAdd")}
                          title={t("storeAdd")}
                          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md transition hover:brightness-110 active:scale-95"
                          style={{ backgroundImage: grad(c1, c2) }}
                        >
                          <CatIcon name="shopping-cart" className="h-4 w-4" />
                        </button>
                      </li>
                    );
                  })}
                </ul>
              </div>
            ) : null}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/* ------------------------------------------------------------------ */
/* ROUND 63 — the product reviews & ratings dialog                      */
/*                                                                     */
/* Opens from the quick-view's reviews entry (storefront-view owns the  */
/* selected product). Structure: gradient header (product name + avg),  */
/* the 5→1★ distribution bars, the keyset-paginated review list with    */
/* load-more, and a collapsible guest write-form pinned at the bottom   */
/* (interactive star picker with the review-star-pop spring).           */
/*                                                                     */
/* RADIX CONTRACT: DialogContent ALWAYS carries a visible DialogTitle   */
/* (the product name) + an sr-only DialogDescription — in the hidden    */
/* null-product shell too (round 61's hard-won lesson). ALL hooks run   */
/* BEFORE the null-product early return; per-product state resets use   */
/* the documented render-time previous-value pattern.                   */
/* ------------------------------------------------------------------ */

/** one review row — private to this module (never exported). */
function StoreReviewRow({
  review,
  index,
  c1,
  c2,
}: {
  review: SiteReviewDTO;
  /** list position — drives the review-in cascade stagger (capped at 8) */
  index: number;
  c1: string;
  c2: string;
}) {
  const { t, lang } = useT();
  /* same date approach as StoreTrackingCard's fmtDate (medium date, the
   * file's Intl + intlLocale idiom — reviews need no time-of-day) */
  const fmtDate = (iso: string) => {
    try {
      return new Intl.DateTimeFormat(intlLocale(lang), { dateStyle: "medium" }).format(new Date(iso));
    } catch {
      return iso.slice(0, 10);
    }
  };
  return (
    <li
      className="review-in rounded-2xl border border-slate-200/70 bg-white p-3.5 dark:border-white/[0.07] dark:bg-white/[0.03]"
      style={{ "--ri": Math.min(index, 8) } as React.CSSProperties}
    >
      <div className="flex items-start gap-3">
        {/* gradient avatar tile — the reviewer's first initial (decorative) */}
        <span
          aria-hidden="true"
          className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-[14px] font-bold text-white shadow-md"
          style={{ backgroundImage: grad(c1, c2) }}
        >
          {review.name.trim().charAt(0) || "؟"}
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
            <p className="truncate text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100" title={review.name}>
              {review.name}
            </p>
            {/* the tiny verified-guest chip beside the name */}
            <span className="inline-flex shrink-0 items-center gap-0.5 rounded-full border border-emerald-300/60 bg-emerald-500/10 px-1.5 py-0.5 text-[10px] font-bold text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300">
              <CatIcon name="badge-check" className="h-2.5 w-2.5" />
              {t("reviewsVerifiedGuest")}
            </span>
            <span
              dir="ltr"
              className="ms-auto shrink-0 text-[10.5px] font-semibold tabular-nums text-slate-400 dark:text-slate-500"
            >
              {fmtDate(review.createdAt)}
            </span>
          </div>
          <div className="mt-1.5">
            <StarsRow value={review.rating} size="sm" />
          </div>
          {review.body ? (
            <p className="mt-1.5 whitespace-pre-line text-[12px] leading-relaxed text-slate-600 dark:text-slate-300">
              {review.body}
            </p>
          ) : null}
        </div>
      </div>
    </li>
  );
}

export function StoreReviewsDialog({
  open,
  onOpenChange,
  product,
  instanceId,
  c1,
  c2,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  product: SiteProductDTO | null;
  instanceId: string;
  c1: string;
  c2: string;
}) {
  const { t, lang } = useT();

  /* ---------------- hooks (ALL before the null early return) --------- */

  /* ROUND 63 — catalog invalidation hook (submit success path) */
  const queryClient = useQueryClient();

  /* a review submission bumps `reload` → the query key changes → the list
   * + summary re-fetch from the server's truth (same react-query pattern
   * the storefront catalog uses) */
  const [reload, setReload] = useState(0);
  const recordId = product?.recordId ?? null;

  const reviewsQuery = useQuery({
    queryKey: ["site-reviews", instanceId, recordId, reload],
    queryFn: () => fetchProductReviews(instanceId, recordId as string),
    enabled: open && recordId != null,
    staleTime: 30_000,
    retry: 0,
  });

  /* load-more accumulation: the FIRST page belongs to the query; extra
   * keyset pages append here. Everything resets when the product or the
   * reload counter moves — React's documented previous-value pattern
   * DURING render (react-hooks v7 clean, no effect setState) */
  const [extra, setExtra] = useState<SiteReviewDTO[]>([]);
  const [extraCursor, setExtraCursor] = useState<string | null>(null);
  const [loadingMore, setLoadingMore] = useState(false);
  const [prevListKey, setPrevListKey] = useState<string | null>(null);
  const listKey = recordId != null ? `${recordId}:${reload}` : null;
  if (listKey !== prevListKey) {
    setPrevListKey(listKey);
    setExtra([]);
    setExtraCursor(null);
    setLoadingMore(false);
  }

  /* the write form: collapsed by default; resets per product (same
   * render-time reset idiom as the quick-view's qty) */
  const [formOpen, setFormOpen] = useState(false);
  const [rating, setRating] = useState(0);
  const [hovered, setHovered] = useState(0);
  const [name, setName] = useState("");
  const [body, setBody] = useState("");
  const [prevFormId, setPrevFormId] = useState<string | null>(recordId);
  if (recordId !== prevFormId) {
    setPrevFormId(recordId);
    setFormOpen(false);
    setRating(0);
    setHovered(0);
    setName("");
    setBody("");
  }

  /** 429-aware error message picker (ApiError carries .status; a plain
   * Error without it falls through to the generic message) */
  const reviewErr = (e: unknown): string =>
    (e as { status?: number }).status === 429 ? t("reviewsErrRateLimited") : t("reviewsErrGeneric");

  const submitReview = useMutation({
    mutationFn: () => {
      const rid = recordId;
      if (rid == null) throw new Error(t("reviewsErrGeneric"));
      return submitProductReview(instanceId, {
        recordId: rid,
        rating,
        name: name.trim(),
        ...(body.trim() ? { body: body.trim() } : {}),
      });
    },
    onSuccess: (res) => {
      toast.success(res.updated ? t("reviewsUpdatedToast") : t("reviewsSubmittedToast"));
      /* collapse + clear the form, then refresh list + summary */
      setFormOpen(false);
      setRating(0);
      setHovered(0);
      setName("");
      setBody("");
      setReload((n) => n + 1);
      /* ROUND 63 — the storefront CATALOG query ("site-store", instanceId)
       * carries the product cards'/quick-view's ratingAvg/ratingCount; a
       * fresh submission/revision changes those aggregates, so invalidate
       * the prefix (all q/category variants) to self-heal the surfaces
       * behind this dialog (cards + quick-view) on their next read. */
      queryClient.invalidateQueries({ queryKey: ["site-store", instanceId] });
    },
    onError: (e: Error) => toast.error(reviewErr(e)),
  });

  const submitForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (rating < 1) {
      toast.error(t("reviewsErrRating"));
      return;
    }
    if (name.trim().length < 2) {
      toast.error(t("reviewsErrName"));
      return;
    }
    submitReview.mutate();
  };

  /* surface fetch failures as a toast (once per error identity — the
   * inline retry block in the body carries the same message) */
  useEffect(() => {
    const err = reviewsQuery.error;
    if (!err) return;
    toast.error(reviewErr(err));
    // eslint-disable-next-line react-hooks/exhaustive-deps -- t re-binds per lang; toasting exactly once per error object is the intent
  }, [reviewsQuery.error]);

  const loadMore = async () => {
    const cursor = extraCursor ?? reviewsQuery.data?.nextCursor ?? null;
    const rid = recordId;
    if (!cursor || rid == null || loadingMore) return;
    setLoadingMore(true);
    try {
      const page = await fetchProductReviews(instanceId, rid, cursor);
      setExtra((prev) => [...prev, ...page.reviews]);
      setExtraCursor(page.nextCursor);
    } catch (e) {
      toast.error(reviewErr(e));
    } finally {
      setLoadingMore(false);
    }
  };

  /* ---------------- derived display state ---------------- */

  const first = reviewsQuery.data;
  const summary = first?.summary ?? null;
  const reviews = [...(first?.reviews ?? []), ...extra];
  const nextCursor = extraCursor ?? first?.nextCursor ?? null;
  const loading = reviewsQuery.isPending;
  const fetchError = reviewsQuery.error;
  /* the DTO's aggregate previews instantly; the fetched summary (server
   * truth) wins the moment it arrives */
  const avg = summary?.avg ?? product?.ratingAvg ?? 0;
  const count = summary?.count ?? product?.ratingCount ?? 0;
  const dist = summary && summary.count > 0 ? summary.dist : null;

  if (!product) {
    /* closed / no selection — the bare hidden shell (keeps Radix state
     * consistent; the sr-only title+description satisfy the a11y contract) */
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="hidden">
          <DialogTitle className="sr-only">{t("reviewsTitle")}</DialogTitle>
          <DialogDescription className="sr-only">{t("reviewsDialogDesc")}</DialogDescription>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="nice-scroll flex max-h-[88vh] max-w-[calc(100vw-1.5rem)] flex-col gap-0 overflow-y-auto rounded-3xl p-0 sm:max-w-[520px]">
        {/* sr-only description — one screen-reader announcement */}
        <DialogDescription className="sr-only">
          {t("reviewsDialogDesc", { name: product.name })}
        </DialogDescription>

        {/* ---------------- header band (gradient c1→c2) ---------------- */}
        <div
          className="shrink-0 p-5 pe-14"
          style={{ backgroundImage: grad(c1, c2) }}
        >
          <p className="text-[10px] font-extrabold uppercase tracking-wider text-white/75">
            {t("reviewsTitle")}
          </p>
          {/* DialogTitle — Radix's accessibility contract (aria-linked) */}
          <DialogTitle
            className="mt-1 text-start font-display text-[16px] font-extrabold leading-snug text-white"
            title={product.name}
          >
            {product.name}
          </DialogTitle>
          <div className="mt-2 flex flex-wrap items-center gap-x-2.5 gap-y-1">
            <StarsRow value={avg} size="md" />
            {count > 0 ? (
              <>
                <span dir="ltr" className="font-display text-[14px] font-black tabular-nums text-white">
                  {nf(lang, avg)}
                </span>
                <span className="text-[11px] font-bold text-white/80">
                  {t("reviewsCountLabel", { n: nf(lang, count) })}
                </span>
              </>
            ) : (
              <span className="text-[11px] font-bold text-white/80">{t("reviewsNoneTitle")}</span>
            )}
          </div>
        </div>

        {/* ---------------- distribution (5★ → 1★) --------------------- */}
        {dist ? (
          <div className="p-5 pb-0">
            <div className="space-y-1.5">
              {dist.map((bucket, i) => {
                const stars = 5 - i;
                const pct = Math.round((bucket / count) * 100);
                return (
                  <div key={stars} className="flex items-center gap-2.5">
                    <span
                      dir="ltr"
                      className="inline-flex w-9 shrink-0 items-center justify-center gap-0.5 text-[11px] font-extrabold tabular-nums text-slate-600 dark:text-slate-300"
                    >
                      {nf(lang, stars)}
                      <CatIcon name="star" className="h-2.5 w-2.5 fill-amber-400 text-amber-400" />
                    </span>
                    {/* the track + the growing amber fill (--rb staggers) */}
                    <span aria-hidden="true" className="h-2 min-w-0 flex-1 overflow-hidden rounded-full bg-slate-200/60 dark:bg-white/10">
                      <span
                        className="rating-bar-fill block h-full rounded-full bg-gradient-to-r from-amber-400 to-amber-500"
                        style={{ width: `${pct}%`, "--rb": i } as React.CSSProperties}
                      />
                    </span>
                    <span
                      dir="ltr"
                      className="w-7 shrink-0 text-center text-[11px] font-bold tabular-nums text-slate-500 dark:text-slate-400"
                    >
                      {nf(lang, bucket)}
                    </span>
                    <span
                      dir="ltr"
                      className="w-9 shrink-0 text-center text-[10.5px] font-semibold tabular-nums text-slate-400 dark:text-slate-500"
                    >
                      {nf(lang, pct)}%
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        ) : null}

        {/* ---------------- list / states ------------------------------- */}
        <div className="px-5 py-4">
          {fetchError ? (
            /* fetch failed — a small centered retry block */
            <div className="py-6 text-center">
              <p className="mx-auto inline-flex items-center gap-1.5 rounded-full border border-rose-300/60 bg-rose-500/10 px-3.5 py-1.5 text-[12px] font-bold text-rose-600 dark:border-rose-500/40 dark:text-rose-300">
                <CatIcon name="circle-x" className="h-3.5 w-3.5 shrink-0" />
                {reviewErr(fetchError)}
              </p>
              <div className="mt-3">
                <button
                  type="button"
                  onClick={() => reviewsQuery.refetch()}
                  className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-4 text-[11.5px] font-bold text-slate-600 shadow-sm transition hover:border-transparent hover:shadow-lift active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
                >
                  <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
                  {t("retryText")}
                </button>
              </div>
            </div>
          ) : loading ? (
            /* first page in flight — 3 skeleton review rows */
            <ul className="space-y-2.5">
              {[0, 1, 2].map((i) => (
                <li
                  key={i}
                  className="flex items-start gap-3 rounded-2xl border border-slate-200/70 bg-white p-3.5 dark:border-white/[0.07] dark:bg-white/[0.03]"
                >
                  <Skeleton className="h-9 w-9 shrink-0 rounded-full" />
                  <div className="min-w-0 flex-1 space-y-2">
                    <Skeleton className="h-3 w-28" />
                    <Skeleton className="h-3 w-16" />
                    <Skeleton className="h-3 w-3/4" />
                  </div>
                </li>
              ))}
            </ul>
          ) : count === 0 ? (
            /* no reviews yet — invite the first one */
            <div className="py-8 text-center">
              <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-amber-500/10 text-amber-500 dark:text-amber-300">
                <CatIcon name="star" className="h-6 w-6" />
              </div>
              <h3 className="mt-4 font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                {t("reviewsNoneTitle")}
              </h3>
              <p className="mx-auto mt-1.5 max-w-xs text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
                {t("reviewsNoneDesc")}
              </p>
            </div>
          ) : (
            <>
              <ul className="nice-scroll max-h-72 space-y-2.5 overflow-y-auto pe-1">
                {reviews.map((review, i) => (
                  <StoreReviewRow key={review.id} review={review} index={i} c1={c1} c2={c2} />
                ))}
              </ul>
              {nextCursor ? (
                /* keyset pagination — append the next page */
                <div className="mt-3 flex justify-center">
                  <button
                    type="button"
                    onClick={loadMore}
                    disabled={loadingMore}
                    className="inline-flex h-9 items-center gap-2 rounded-2xl border border-slate-200 bg-white px-5 text-[12px] font-extrabold text-slate-600 shadow-sm transition hover:border-transparent hover:shadow-lift active:scale-95 disabled:opacity-60 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
                  >
                    {loadingMore ? (
                      <CatIcon name="refresh-cw" className="h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <CatIcon name="chevron-down" className="h-3.5 w-3.5" />
                    )}
                    {t("reviewsLoadMore")}
                  </button>
                </div>
              ) : null}
            </>
          )}
        </div>

        {/* ---------------- the write form (pinned bottom) -------------- */}
        <div className="shrink-0 border-t border-slate-200/70 bg-slate-50/60 p-5 dark:border-white/[0.07] dark:bg-white/[0.03]">
          {formOpen ? (
            <form onSubmit={submitForm} className="space-y-3.5">
              <p className="text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
                {t("reviewsFormTitle", { name: product.name })}
              </p>

              {/* the interactive star picker — radiogroup semantics via the
               * container role + per-button aria-labels; the JUST-CHOSEN
               * star remounts (key) and replays review-star-pop per pick */}
              <div className="space-y-1.5">
                <p className="text-[12px] font-bold text-slate-700 dark:text-slate-200">
                  {t("reviewsRatingLabel")} <span className="text-rose-500">*</span>
                </p>
                <div
                  dir="ltr"
                  role="radiogroup"
                  aria-label={t("reviewsRatingLabel")}
                  className="flex items-center gap-1"
                >
                  {[1, 2, 3, 4, 5].map((i) => {
                    const active = i <= (hovered || rating);
                    const chosen = rating === i;
                    return (
                      <button
                        key={i}
                        type="button"
                        onClick={() => setRating(i)}
                        onMouseEnter={() => setHovered(i)}
                        onMouseLeave={() => setHovered(0)}
                        onFocus={() => setHovered(i)}
                        onBlur={() => setHovered(0)}
                        aria-label={t("reviewsStarsA11y", { n: nf(lang, i) })}
                        className={cn(
                          "grid h-9 w-9 place-items-center rounded-xl transition-all duration-150 hover:scale-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400/60 active:scale-95",
                          active
                            ? "text-amber-400"
                            : "text-slate-300 hover:text-amber-300 dark:text-slate-600 dark:hover:text-amber-400/70"
                        )}
                      >
                        <CatIcon
                          key={chosen ? `${product.recordId}:${rating}` : i}
                          name="star"
                          className={cn(
                            "h-5 w-5 transition-colors",
                            active && "fill-amber-400 text-amber-400",
                            chosen && "review-star-pop"
                          )}
                        />
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* reviewer name */}
              <div className="space-y-1.5">
                <Label htmlFor={`rv-name-${product.recordId}`} className="text-[12px] font-bold">
                  {t("reviewsFormName")} <span className="text-rose-500">*</span>
                </Label>
                <Input
                  id={`rv-name-${product.recordId}`}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={t("reviewsFormNamePh")}
                  maxLength={60}
                  autoComplete="name"
                  className="h-10 rounded-xl"
                />
              </div>

              {/* optional body */}
              <div className="space-y-1.5">
                <Label htmlFor={`rv-body-${product.recordId}`} className="text-[12px] font-bold">
                  {t("reviewsFormBody")}
                </Label>
                <textarea
                  id={`rv-body-${product.recordId}`}
                  value={body}
                  onChange={(e) => setBody(e.target.value)}
                  placeholder={t("reviewsFormBodyPh")}
                  maxLength={500}
                  rows={3}
                  className="w-full resize-none rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-[13px] shadow-sm outline-none transition placeholder:text-slate-400 focus:border-brand-400 focus:ring-2 focus:ring-brand-400/20 dark:border-white/10 dark:bg-white/[0.04] dark:text-white dark:placeholder:text-slate-500"
                />
              </div>

              {/* privacy note */}
              <p className="flex items-start gap-1.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                <CatIcon name="info" className="mt-0.5 h-3 w-3 shrink-0" />
                {t("reviewsPrivacyNote")}
              </p>

              {/* actions */}
              <div className="flex items-center gap-2">
                <Button
                  type="submit"
                  disabled={submitReview.isPending}
                  className="btn-grad h-10 gap-1.5 rounded-xl px-5 text-[12.5px] font-bold text-white shadow-lg transition-[transform,filter,background-position,background-size] duration-200 ease-[cubic-bezier(0.22,1,0.36,1)] hover:brightness-110 active:scale-95 disabled:opacity-70"
                  style={{
                    backgroundImage: grad(c1, c2),
                    boxShadow: `0 10px 22px -10px ${hexAlpha(c1, 0.75)}`,
                  }}
                >
                  {submitReview.isPending ? (
                    <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                  ) : (
                    <CatIcon name="send" className="h-4 w-4" />
                  )}
                  {submitReview.isPending ? t("reviewsFormSubmitting") : t("reviewsFormSubmit")}
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => setFormOpen(false)}
                  className="h-10 rounded-xl px-4 text-[12px] font-bold text-slate-500 transition hover:text-slate-800 active:scale-95 dark:text-slate-400 dark:hover:text-white"
                >
                  {t("reviewsFormCancel")}
                </Button>
              </div>
            </form>
          ) : (
            /* collapsed — the ghost write toggle */
            <button
              type="button"
              onClick={() => setFormOpen(true)}
              className="inline-flex h-9 w-fit items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-4 text-[12px] font-bold text-slate-600 shadow-sm transition hover:border-transparent hover:shadow-lift active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
            >
              <CatIcon name="pencil-line" className="h-3.5 w-3.5" />
              {t("reviewsWrite")}
            </button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
