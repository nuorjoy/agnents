"use client";

/**
 * Ashrilogic — ROUND 62 printable order receipt.
 *
 * A thermal-style receipt rendered as a premium document: store letterhead
 * (logo tile / initial + org name), a decorative barcode milled from the
 * tracking code, the items table (qty-only lines when the source projection
 * hides unit prices — the guest tracking view), totals with the coupon
 * discount, the status trail, and a thank-you / track-hint footer. Prints
 * through the SAME dedicated `.print-doc` print root as the dashboard's
 * record printing (globals.css — everything else is hidden under @media
 * print), so the paper is theme-agnostic ink on white regardless of the
 * active dark/light theme.
 *
 * SHARED by two very different callers:
 *  - the PUBLIC storefront tracking card (guest projection: no unit prices,
 *    no customer identity — exactly what the track API exposes);
 *  - the dashboard E-Store orders console (owner projection: full line
 *    prices + the customer name — an invoice-grade receipt).
 * Both feed the same normalized `OrderReceiptData` shape, so the paper is
 * pixel-identical for the same order whichever side prints it (minus the
 * price column and customer row the guest projection does not carry).
 */
import { useMemo, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CatIcon } from "@/components/icon";
import { useT, t as pureT, type I18nKey } from "@/lib/i18n";
import { intlLocale } from "@/lib/locales";
import { fullDate } from "@/components/dashboard/dash-shared";
import { grad, hexAlpha, cn } from "@/lib/utils";
import { hasInvoiceAsset } from "@/lib/invoice-assets";
import type { Lang, OrderStatusEvent, SiteOrderStatus } from "@/lib/types";
import { nf, fmtPrice } from "@/lib/format";

/** status → i18n key (the same mapping the tracking card and the orders
 *  console use locally — kept module-private like both of them) */
const STATUS_KEY: Record<SiteOrderStatus, I18nKey> = {
  pending: "ordStatusPending",
  confirmed: "ordStatusConfirmed",
  preparing: "ordStatusPreparing",
  ready: "ordStatusReady",
  completed: "ordStatusCompleted",
  cancelled: "ordStatusCancelled",
};

/* ------------------------------------------------------------------ */
/* data shapes                                                         */

/** one receipt line. `unitPrice` is null when the source projection hides
 *  prices (guest tracking) — the line then renders name + qty only. */
export interface ReceiptItem {
  name: string;
  qty: number;
  unitPrice: number | null;
}

/** normalized order projection (built by each caller from its DTO). */
export interface OrderReceiptData {
  /** public tracking code, or the internal id prefix on legacy rows */
  code: string;
  items: ReceiptItem[];
  /** grand total in display units, NET of the discount */
  total: number;
  /** discount applied at placement (display units; 0 = none) */
  discount: number;
  couponCode: string | null;
  currency: string;
  status: SiteOrderStatus;
  statusHistory: OrderStatusEvent[];
  createdAt: string;
  updatedAt: string;
  note?: string | null;
  /** owner receipts only — the guest projection never carries it */
  customerName?: string | null;
}

/** store identity for the letterhead (theme colors + logo + contact). */
export interface ReceiptIdentity {
  orgName: string;
  logoUrl?: string | null;
  c1: string;
  c2: string;
  /** optional contact channel (phone · address) for the paper footer */
  orgContact?: string | null;
  /** ROUND 67 — invoice signature & stamp (owner projection only: the
   *  guest tracking receipt never passes them) + their render scales. */
  signatureUrl?: string | null;
  stampUrl?: string | null;
  signatureScale?: number;
  stampScale?: number;
}

/* ------------------------------------------------------------------ */
/* ------------------------------------------------------------------ */
/* the paper (shared by the dialog and the standalone receipt page)     */

/**
 * ROUND 119 — the extracted RECEIPT PAPER: the exact R62 thermal-style
 * document (cut edges, letterhead, barcode, items, totals, trail,
 * signature/stamp), rendered byte-identically inside the receipt dialog
 * AND on the standalone public receipt page
 * (/sites/[id]/receipt?token=… — the emailable link). `issued` is minted
 * by the CALLER once per mount/open so a re-render never re-dates the
 * paper; `lang` is a prop so a server page can drive it without the hook.
 */
export function ReceiptPaper({
  data,
  identity,
  issued,
  lang,
}: {
  data: OrderReceiptData;
  identity: ReceiptIdentity;
  /** ISO timestamp printed as the issue date (caller-minted, stable) */
  issued: string;
  lang: Lang;
}) {
  const docDir = lang === "ar" ? "rtl" : "ltr";
  const tt = (key: I18nKey, vars?: Record<string, string | number>) =>
    pureT(lang, key, vars);

  /* decorative barcode bars milled deterministically from the code —
   * every character contributes a narrow/wide pair; the outer guards are
   * the classic taller end bars. Purely visual (aria-hidden pattern with
   * the real code announced by the mono text below). */
  const bars = useMemo(() => {
    const inner: number[] = [];
    for (const ch of data?.code ?? "") {
      const n = ch.charCodeAt(0);
      inner.push(1 + (n % 3), 1 + ((n >> 2) % 2));
    }
    return inner;
  }, [data?.code]);

  const hasPrices = (data?.items ?? []).some((it) => it.unitPrice != null);
  const subtotal = (data?.total ?? 0) + (data?.discount ?? 0);

  const fmtTrail = (iso: string) => {
    try {
      return new Intl.DateTimeFormat(intlLocale(lang), {
        day: "numeric",
        month: "short",
        hour: "2-digit",
        minute: "2-digit",
      }).format(new Date(iso));
    } catch {
      return iso.slice(0, 16);
    }
  };

  if (!data) return null;

  return (
          <div
            className="print-doc rcpt-anim mx-auto w-full max-w-[380px] rounded-xl bg-white p-6 text-slate-900 shadow-2xl shadow-slate-400/25 ring-1 ring-slate-200"
            dir={docDir}
          >
            {/* cut-here top edge */}
            <div className="flex items-center gap-2 text-slate-300" aria-hidden="true">
              <CatIcon name="scissors" className="h-3 w-3 -scale-x-100 rtl:scale-x-100" />
              <span className="h-px flex-1 border-t border-dashed border-slate-300" />
            </div>

            {/* letterhead */}
            <div className="mt-4 flex items-center gap-3">
              {identity.logoUrl ? (
                /* managed image ref (server-minted, same-origin) — the
                 * receipt paper intentionally avoids next/image so the
                 * print pipeline renders a plain <img> without the
                 * optimizer's runtime in the print path */
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={identity.logoUrl}
                  alt={identity.orgName}
                  className="h-11 w-11 shrink-0 rounded-xl object-cover ring-1 ring-slate-200"
                />
              ) : (
                <span
                  className="grid h-11 w-11 shrink-0 place-items-center rounded-xl font-display text-[18px] font-extrabold text-white"
                  style={{ backgroundImage: grad(identity.c1, identity.c2) }}
                >
                  {(identity.orgName || "A").trim().charAt(0).toUpperCase()}
                </span>
              )}
              <div className="min-w-0 flex-1">
                <p className="truncate font-display text-[15.5px] font-extrabold leading-tight text-slate-900">
                  {identity.orgName || "—"}
                </p>
                <p className="mt-0.5 text-[10px] font-extrabold uppercase tracking-[0.14em] text-slate-400">
                  {tt("rcptTitle")}
                </p>
              </div>
              {/* status chip — print-safe tinted ink */}
              <span
                className={cn(
                  "inline-flex shrink-0 items-center gap-1 rounded-full border px-2.5 py-1 text-[10px] font-extrabold",
                  data.status === "cancelled"
                    ? "border-rose-300 bg-rose-50 text-rose-600"
                    : data.status === "completed"
                      ? "border-emerald-300 bg-emerald-50 text-emerald-600"
                      : "border-amber-300 bg-amber-50 text-amber-600"
                )}
              >
                {tt(STATUS_KEY[data.status])}
              </span>
            </div>

            {/* the code + decorative barcode (the real code is announced by
                the mono text right below — the bars stay decorative) */}
            <div className="mt-5 rounded-xl border border-slate-200 bg-slate-50/60 px-4 py-3.5">
              <div
                className="flex h-10 items-center justify-center gap-[2px]"
                dir="ltr"
                aria-hidden="true"
              >
                <span className="h-10 w-[3px] bg-slate-900" />
                {bars.map((w, i) => (
                  <span
                    key={i}
                    className="h-6 self-center bg-slate-900"
                    style={{ width: `${w}px` }}
                  />
                ))}
                <span className="h-10 w-[3px] bg-slate-900" />
              </div>
              <p
                dir="ltr"
                className="mt-2 text-center font-mono text-[15px] font-black tracking-[0.32em] text-slate-900"
              >
                {data.code}
              </p>
            </div>

            {/* meta rows */}
            <dl className="mt-4 space-y-1.5 text-[11px] font-semibold">
              <div className="flex items-center justify-between gap-3">
                <dt className="text-slate-400">{tt("trackPlacedAt")}</dt>
                <dd dir="ltr" className="tabular-nums text-slate-700">
                  {fullDate(data.createdAt, lang)}
                </dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="text-slate-400">{tt("printIssued")}</dt>
                <dd dir="ltr" className="tabular-nums text-slate-700">
                  {fullDate(issued, lang)}
                </dd>
              </div>
              {data.customerName ? (
                <div className="flex items-center justify-between gap-3">
                  <dt className="text-slate-400">{tt("rcptCustomer")}</dt>
                  <dd className="truncate text-slate-700">{data.customerName}</dd>
                </div>
              ) : null}
            </dl>

            <div className="my-4 h-px border-t border-dashed border-slate-300" aria-hidden="true" />

            {/* items */}
            <p className="mb-2 text-[10px] font-extrabold uppercase tracking-[0.14em] text-slate-400">
              {tt("rcptItems")}
            </p>
            <table className="w-full border-collapse text-[11.5px]">
              <thead>
                <tr className="border-b border-slate-200 text-[9.5px] font-extrabold uppercase tracking-wider text-slate-400">
                  <th scope="col" className="pb-1.5 text-start font-extrabold">
                    {tt("rcptItems")}
                  </th>
                  <th scope="col" className="pb-1.5 text-center font-extrabold">
                    {tt("rcptQty")}
                  </th>
                  {hasPrices ? (
                    <>
                      <th scope="col" className="pb-1.5 text-center font-extrabold">
                        {tt("rcptUnit")}
                      </th>
                      <th scope="col" className="pb-1.5 text-end font-extrabold">
                        {tt("rcptLineTotal")}
                      </th>
                    </>
                  ) : null}
                </tr>
              </thead>
              <tbody>
                {data.items.map((item, i) => (
                  <tr key={i} className="border-b border-dashed border-slate-200 last:border-0">
                    <td className="py-2 pe-2 align-top font-bold text-slate-800">
                      {item.name}
                    </td>
                    <td dir="ltr" className="py-2 text-center align-top tabular-nums font-bold text-slate-600">
                      ×{nf(lang, item.qty)}
                    </td>
                    {hasPrices ? (
                      <>
                        <td dir="ltr" className="py-2 text-center align-top tabular-nums text-slate-500">
                          {item.unitPrice != null ? fmtPrice(lang, item.unitPrice, data.currency) : "—"}
                        </td>
                        <td dir="ltr" className="py-2 text-end align-top tabular-nums font-extrabold text-slate-800">
                          {item.unitPrice != null
                            ? fmtPrice(lang, item.unitPrice * item.qty, data.currency)
                            : "—"}
                        </td>
                      </>
                    ) : null}
                  </tr>
                ))}
                {data.items.length === 0 ? (
                  <tr>
                    <td colSpan={hasPrices ? 4 : 2} className="py-2 text-center text-slate-400">
                      —
                    </td>
                  </tr>
                ) : null}
              </tbody>
            </table>

            {/* totals */}
            <div className="mt-3 space-y-1.5 rounded-xl border border-slate-200 bg-slate-50/60 px-3.5 py-3">
              {data.discount > 0 ? (
                <>
                  <div className="flex items-center justify-between gap-3 text-[11px] font-bold text-slate-500">
                    <span>{tt("rcptSubtotal")}</span>
                    <span dir="ltr" className="tabular-nums">
                      {fmtPrice(lang, subtotal, data.currency)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between gap-3 text-[11px] font-bold text-emerald-600">
                    <span className="inline-flex items-center gap-1">
                      <CatIcon name="ticket-percent" className="h-3 w-3" />
                      {tt("rcptDiscount")}
                      {data.couponCode ? (
                        <code dir="ltr" className="font-mono text-[10px] tracking-wider">
                          {data.couponCode}
                        </code>
                      ) : null}
                    </span>
                    <span dir="ltr" className="tabular-nums">
                      −{fmtPrice(lang, data.discount, data.currency)}
                    </span>
                  </div>
                </>
              ) : null}
              <div className="flex items-center justify-between gap-3 border-t border-dashed border-slate-300 pt-2">
                <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-500">
                  {tt("rcptGrand")}
                </span>
                <span dir="ltr" className="font-display text-[16px] font-black tabular-nums text-slate-900">
                  {fmtPrice(lang, data.total, data.currency)}
                </span>
              </div>
            </div>

            {/* customer note (as placed) */}
            {data.note ? (
              <p className="mt-3 rounded-xl bg-amber-50 px-3 py-2 text-[10.5px] font-semibold leading-relaxed text-amber-700">
                <span className="font-extrabold">{tt("ordCustomerNote")}:</span> {data.note}
              </p>
            ) : null}

            {/* status trail */}
            {data.statusHistory.length > 0 ? (
              <div className="mt-4">
                <p className="mb-2 text-[10px] font-extrabold uppercase tracking-[0.14em] text-slate-400">
                  {tt("ordTrailTitle")}
                </p>
                <ol className="relative space-y-1.5">
                  {[...data.statusHistory].reverse().map((ev, i) => (
                    <li key={`${ev.status}-${ev.at}-${i}`} className="flex items-center justify-between gap-3 text-[11px]">
                      <span className={cn("font-extrabold", i === 0 ? "text-slate-800" : "text-slate-500")}>
                        {tt(STATUS_KEY[ev.status])}
                      </span>
                      <time dir="ltr" dateTime={ev.at} className="shrink-0 tabular-nums text-slate-400">
                        {fmtTrail(ev.at)}
                      </time>
                    </li>
                  ))}
                </ol>
              </div>
            ) : null}

            {/* thank-you + track hint + store contact */}
            <div className="mt-5 space-y-1.5 border-t border-dashed border-slate-300 pt-4 text-center">
              <p className="text-[11.5px] font-extrabold text-slate-700">{tt("rcptThankYou")}</p>
              {data.code ? (
                <p className="text-[10px] font-semibold leading-relaxed text-slate-400">
                  {tt("rcptTrackHint", { code: data.code })}
                </p>
              ) : null}
              {identity.orgContact ? (
                <p dir="ltr" className="text-[10px] font-bold tabular-nums text-slate-500">
                  {identity.orgContact}
                </p>
              ) : null}
            </div>

            {/* ROUND 67 — the workspace's official signature & stamp on the
                owner invoice projection (compact thermal-paper composition,
                each at its owner-adjusted scale).
                ROUND 138 — the GATING LAW: a workspace with NO uploaded
                stamp/signature renders NEITHER the block nor its label
                ceremony (hasInvoiceAsset refuses empty strings, whitespace
                and payload-less data: URLs — see src/lib/invoice-assets.ts). */}
            {hasInvoiceAsset(identity.signatureUrl) || hasInvoiceAsset(identity.stampUrl) ? (
              <div className="mt-4 flex items-end justify-center gap-10">
                {hasInvoiceAsset(identity.signatureUrl) ? (
                  <div className="text-center">
                    <div className="grid h-14 place-items-center">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={identity.signatureUrl}
                        alt={tt("printSignatureLabel")}
                        className="max-h-full max-w-[130px] object-contain"
                        style={{ transform: `scale(${identity.signatureScale ?? 1})` }}
                      />
                    </div>
                    <p className="mt-1 text-[8.5px] font-extrabold uppercase tracking-wider text-slate-400">
                      {tt("printSignatureLabel")}
                    </p>
                    <div className="mx-auto mt-1 w-28 border-t border-slate-400" aria-hidden="true" />
                  </div>
                ) : null}
                {hasInvoiceAsset(identity.stampUrl) ? (
                  <div className="text-center">
                    <div className="grid h-14 place-items-center">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={identity.stampUrl}
                        alt={tt("printStampLabel")}
                        className="max-h-full max-w-[130px] object-contain"
                        style={{ transform: `scale(${identity.stampScale ?? 1})` }}
                      />
                    </div>
                    <p className="mt-1 text-[8.5px] font-extrabold uppercase tracking-wider text-slate-400">
                      {tt("printStampLabel")}
                    </p>
                    <div className="mx-auto mt-1 w-28 border-t border-slate-400" aria-hidden="true" />
                  </div>
                ) : null}
              </div>
            ) : null}

            {/* cut-here bottom edge */}
            <div className="mt-4 flex items-center gap-2 text-slate-300" aria-hidden="true">
              <span className="h-px flex-1 border-t border-dashed border-slate-300" />
              <CatIcon name="scissors" className="h-3 w-3" />
            </div>

            <p className="mt-3 text-center text-[9px] font-bold tracking-wide text-slate-300">
              Ashrilogic · {fullDate(issued, lang)}
            </p>
          </div>
  );
}
/* ------------------------------------------------------------------ */
/* the receipt dialog                                                  */

export function OrderReceiptDialog({
  data,
  identity,
  open,
  onOpenChange,
  shareUrl,
  qrSrc,
}: {
  data: OrderReceiptData | null;
  identity: ReceiptIdentity;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** ROUND 119 — the standalone receipt-page URL (tokened, guest-side
   *  only): when present, the actions row gains a copy-link affordance so
   *  the customer can re-open / share the printable receipt without
   *  re-entering the code + phone. Owners never pass it (no prop → no
   *  button — the dashboard surface is untouched). */
  shareUrl?: string | null;
  /** ROUND 121 — the server-minted receipt-QR endpoint URL (same bearer
   *  token, guest-side only): when present, an icon button toggles a
   *  compact QR panel so the customer can beam the receipt page to their
   *  phone. The QR is minted server-side (SVG — the qrcode package never
   *  ships to the browser) and the endpoint verifies the token before
   *  minting anything. Owners never pass it (no prop → no button). */
  qrSrc?: string | null;
}) {
  const { t, lang } = useT();

  /* the issue timestamp is minted once per mount (never per render —
   * a receipt re-issued mid-dialog keeps its original print date) */
  const issued = useMemo(() => new Date().toISOString(), []);
  const docDir = lang === "ar" ? "rtl" : "ltr";

  /* ROUND 119 — copy-link feedback (resets when the dialog closes) */
  const [linkCopied, setLinkCopied] = useState(false);

  /* ROUND 121 — the receipt-QR panel (toggled; hidden from paper) */
  const [qrOpen, setQrOpen] = useState(false);
  const [qrState, setQrState] = useState<"loading" | "ok" | "error">("loading");

  const copyLink = async () => {
    if (!shareUrl) return;
    try {
      await navigator.clipboard.writeText(shareUrl);
      setLinkCopied(true);
      window.setTimeout(() => setLinkCopied(false), 2500);
    } catch {
      /* clipboard unavailable (permissions / http context) — the link
       * remains copyable from the address bar after opening the page */
    }
  };

  const print = () => {
    /* small delay so the dialog finishes laying out before the print dialog */
    window.setTimeout(() => window.print(), 60);
  };

  if (!data) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        dir={docDir}
        className="max-h-[88vh] max-w-[460px] overflow-y-auto rounded-3xl nice-scroll p-0"
      >
        {/* hidden-in-print chrome: title + actions (Radix a11y keeps the
            DialogTitle mounted for aria-labelledby even on paper) */}
        <div className="print:hidden flex items-start justify-between gap-3 px-6 pt-6">
          <div className="flex items-center gap-2.5">
            <span
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg"
              style={{ backgroundImage: grad(identity.c1, identity.c2) }}
            >
              <CatIcon name="printer" className="h-4 w-4" />
            </span>
            <DialogTitle className="font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
              {t("rcptTitle")}
            </DialogTitle>
          </div>
          {/* ROUND 70 fix — DialogDescription already renders a <p>; the old
              sr-only <p> wrapper produced invalid nested <p><p> (hydration
              error). The sr-only class moves onto the description itself. */}
          <DialogDescription className="sr-only">
            {t("rcptDialogDesc")}
          </DialogDescription>
        </div>

        {/* ------------------------- the paper ------------------------- */}
        <div className="px-4 pb-4 pt-3">
          <ReceiptPaper data={data} identity={identity} issued={issued} lang={lang} />
        </div>

        {/* ROUND 121 — the receipt-QR panel (guest-side only, never on
            paper): a compact bordered card with the server-minted SVG —
            scan to open the standalone receipt page on the phone. */}
        {qrSrc && qrOpen ? (
          <div className="print:hidden mx-auto flex w-full max-w-[240px] flex-col items-center gap-2 rounded-2xl border border-slate-200 bg-slate-50/70 px-4 py-4 dark:border-white/10 dark:bg-white/[0.03]">
            <span
              className="relative grid h-[168px] w-[168px] place-items-center overflow-hidden rounded-xl bg-white p-2 shadow-sm"
              aria-label={t("rcptQrBtn")}
            >
              {qrState === "error" ? (
                <CatIcon name="qr" className="h-10 w-10 text-slate-300" />
              ) : (
                /* eslint-disable-next-line @next/next/no-img-element */
                <img
                  src={qrSrc}
                  alt={t("rcptQrBtn")}
                  onLoad={() => setQrState("ok")}
                  onError={() => setQrState("error")}
                  className={cn(
                    "h-full w-full object-contain transition-opacity duration-300",
                    qrState === "loading" ? "opacity-0" : "opacity-100"
                  )}
                />
              )}
              {qrState === "loading" ? (
                <CatIcon name="refresh-cw" className="absolute h-5 w-5 animate-spin text-slate-300" />
              ) : null}
            </span>
            <p className="text-center text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {t("rcptQrHint")}
            </p>
          </div>
        ) : null}

        {/* actions (hidden when printing) */}
        <div className="print:hidden flex items-center justify-end gap-2 px-6 pb-6 pt-1">
          {qrSrc ? (
            <Button
              type="button"
              variant="outline"
              onClick={() => setQrOpen((v) => !v)}
              aria-pressed={qrOpen}
              title={t("rcptQrBtn")}
              className={cn(
                "h-10 gap-2 rounded-xl px-4 text-[12.5px] font-bold",
                qrOpen && "bg-slate-100/70 dark:bg-white/[0.06]"
              )}
            >
              <CatIcon name="qr" className="h-4 w-4" />
              <span className="sr-only">{t("rcptQrBtn")}</span>
            </Button>
          ) : null}
          {shareUrl ? (
            <Button
              type="button"
              variant="outline"
              onClick={() => void copyLink()}
              title={shareUrl}
              className="me-auto h-10 gap-2 rounded-xl px-5 text-[12.5px] font-bold"
            >
              <CatIcon
                name={linkCopied ? "check" : "link"}
                className={cn("h-4 w-4", linkCopied && "text-emerald-500")}
              />
              {linkCopied ? t("rcptLinkCopied") : t("rcptCopyLink")}
            </Button>
          ) : null}
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="h-10 rounded-xl px-5 text-[12.5px] font-bold"
          >
            {t("dlgCancel")}
          </Button>
          <Button
            type="button"
            onClick={print}
            className="h-10 gap-2 rounded-xl px-6 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95"
            style={{
              backgroundImage: grad(identity.c1, identity.c2),
              boxShadow: `0 12px 26px -10px ${hexAlpha(identity.c1, 0.75)}`,
            }}
          >
            <CatIcon name="printer" className="h-4 w-4" />
            {t("printBtn")}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
