"use client";

/**
 * ROUND 85 — the DEDICATED customer-account PAGE (no popup).
 *
 * «في جميع الأنظمة (المتجر الإلكتروني، الموقع العام) انشاء حساب جديد يجب
 * ان يكون صفحة مخصصة وليس Pop Up وتكون متكاملة وفيها نسيت المرور» — this
 * page replaces StoreAuthDialog everywhere: one PREMIUM, unified, bilingual
 * (AR/EN) surface at /sites/[id]/account serving BOTH the public website and
 * the storefront (the unified ROUND 70 account), with the complete journey:
 *
 *  - ?mode=signin  (default) — sign in
 *  - ?mode=signup           — create a new account
 *  - ?mode=forgot           — «نسيت كلمة المرور» (email → reset link)
 *  - ?mode=reset&token=…    — the emailed link lands HERE (new password)
 *  - ?next=/sites/{id}/…    — the validated return path after success
 *
 * Backend (this round): POST /account/forgot (neutral, single-use 1h
 * sha256-indexed token) + POST /account/reset (Argon2id replacement,
 * sessionVersion bump — every stolen session dies — + immediate sign-in).
 *
 * Design language: the site/store premium vocabulary — gradient brand panel
 * (org colors c1/c2 + orbs + sheen), glass auth panel, WZ-style fields with
 * the shared PremiumEmailInput / PremiumPhoneInput, RTL-native with LTR data
 * islands, dark/light aware, ≥44px touch targets, sonner toasts, complete
 * aria wiring. The header carries the site + store return links, the AR/EN
 * toggle and the theme toggle (exact site-header patterns).
 */
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useTheme } from "next-themes";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import type { I18nKey } from "@/lib/i18n";
import { useT } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import type { StoreAccountDTO } from "@/lib/types";
import {
  checkStoreUsername,
  fetchStoreAccount,
  forgotStorePassword,
  loginStoreAccount,
  logoutStoreAccount,
  registerStoreAccount,
  resetStorePassword,
  type StoreForgotHintDTO,
  type StoreUsernameCheckDTO,
  type StoreVerifyHintDTO,
} from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { PremiumEmailInput, PremiumPhoneInput } from "@/components/ui/premium-contact";
import { SkipLink } from "@/components/skip-link";
import { useDocumentTitle } from "@/hooks/use-document-title";
import { useBrandFavicon } from "@/hooks/use-brand-favicon";
import { EMAIL_RE, PHONE_RE, PASSWORD_RE } from "@/lib/validation";
/* ROUND L (TASK STORE-PROFILE) — username shape: latin letters + digits +
 * dot + underscore + hyphen + Arabic letters (U+0621..U+064A). Start/end
 * with a letter or digit. 3-30 chars. The server re-validates (this regex
 * is UX-only — same shape as the server-side usernameSchema). */
const USERNAME_RE = /^[a-z0-9\u0621-\u064a][a-z0-9._\-\u0621-\u064a]{1,28}[a-z0-9\u0621-\u064a]$/i;
import { cn, grad, hexAlpha, fmtNum } from "@/lib/utils";
import { fontVars, accentVars } from "@/lib/surface-styling";
import { mapAccountError } from "@/components/site/store-account";
import type { ApiError } from "@/lib/api-client";

import "@/lib/i18n/fragments/app";
/* ------------------------------------------------------------------ */
/* shared bits                                                          */
/* ------------------------------------------------------------------ */

/** ROUND 86 (directive ①) — the STRICT 45-second resend cooldown ticker.
 * One second per tick; the server refuses any request inside the window
 * (429 FORGOT_COOLDOWN + retryAfterSec) and this ticker mirrors the same
 * window client-side so the button itself never invites a dead click. */
const FORGOT_COOLDOWN_SECS = 45;

function useCountdown(): [number, (secs: number) => void] {
  const [left, setLeft] = useState(0);
  useEffect(() => {
    if (left <= 0) return;
    const id = window.setTimeout(() => setLeft((v) => v - 1), 1000);
    return () => window.clearTimeout(id);
  }, [left]);
  return [left, setLeft];
}

const AP_LABEL = "mb-1.5 block text-[12px] font-extrabold text-slate-600 dark:text-slate-300";

/** password field with the premium eye toggle (LTR data island). */
function AccountPasswordField({
  id,
  labelKey,
  value,
  onChange,
  invalid,
  autoComplete,
  placeholder,
  disabled,
}: {
  id: string;
  labelKey: I18nKey;
  value: string;
  onChange: (v: string) => void;
  invalid?: boolean;
  autoComplete?: string;
  placeholder?: string;
  disabled?: boolean;
}) {
  const { t } = useT();
  const [visible, setVisible] = useState(false);
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id} className={AP_LABEL}>
        {t(labelKey)} <span className="text-rose-500">*</span>
      </Label>
      <div className="relative">
        <CatIcon
          name="lock"
          className="pointer-events-none absolute start-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
        />
        <Input
          id={id}
          type={visible ? "text" : "password"}
          dir="ltr"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          maxLength={72}
          autoComplete={autoComplete}
          disabled={disabled}
          aria-invalid={invalid || undefined}
          className={cn(
            "h-11 rounded-xl ps-10 pe-11 text-start",
            invalid && "border-rose-400 focus-visible:ring-rose-400"
          )}
        />
        <button
          type="button"
          onClick={() => setVisible((v) => !v)}
          aria-label={t(visible ? "wzPwHide" : "wzPwShow")}
          className="absolute inset-y-0 end-0 me-2.5 grid h-7 w-7 place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-white/10 dark:hover:text-slate-200"
        >
          <CatIcon name={visible ? "eye-off" : "eye"} className="h-[14px] w-[14px]" />
        </button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* the page                                                             */
/* ------------------------------------------------------------------ */

type PageMode = "signin" | "signup" | "forgot" | "forgot-done" | "reset" | "reset-done";

export interface AccountPageViewProps {
  instanceId: string;
  orgName: string;
  systemIcon: string;
  c1: string;
  c2: string;
  logoUrl?: string;
  published: boolean;
  /** the store feature is enabled for this tenant (shows the store link) */
  storeLive: boolean;
  /** draft preview (owner/admin only — server gated) */
  preview: boolean;
  /** ROUND 86 — the e-store's OWN font choice (the account portal follows
   *  the store's identity: its theme colors arrive as c1/c2 above). */
  storeFont?: string;
}

export function AccountPageView({
  instanceId,
  orgName,
  systemIcon,
  c1,
  c2,
  logoUrl,
  published,
  storeLive,
  preview,
  storeFont,
}: AccountPageViewProps) {
  const { t, lang } = useT();
  const router = useRouter();
  const searchParams = useSearchParams();
  const queryClient = useQueryClient();
  const { resolvedTheme, setTheme } = useTheme();
  const setLang = useAppStore((s) => s.setLang);

  useDocumentTitle("docTitleSiteAccount", { org: orgName });
  useBrandFavicon(instanceId);

  const siteHref = `/sites/${instanceId}`;
  const storeHref = `/sites/${instanceId}/store`;

  /* the validated return path — only SAME-SITE relative paths are honored */
  const rawNext = searchParams.get("next") ?? "";
  const next = useMemo(() => {
    const base = `/sites/${instanceId}`;
    if (rawNext === base || rawNext.startsWith(`${base}/`)) return rawNext;
    return storeLive ? storeHref : siteHref;
  }, [rawNext, instanceId, storeLive, siteHref, storeHref]);

  /* ---------------- mode resolution ---------------- */
  const initialMode = (): PageMode => {
    const m = searchParams.get("mode");
    if (m === "signup") return "signup";
    if (m === "forgot") return "forgot";
    if (m === "reset") return "reset";
    return "signin";
  };
  const [mode, setMode] = useState<PageMode>(initialMode);
  const resetToken = searchParams.get("token") ?? "";

  /* ---------------- session probe ---------------- */
  const sessionQuery = useQuery({
    queryKey: ["store-account", instanceId],
    queryFn: () => fetchStoreAccount(instanceId),
    staleTime: 60_000,
    retry: 0,
  });
  const account = sessionQuery.data?.signedIn ? sessionQuery.data.account ?? null : null;

  /* ---------------- form state ---------------- */
  const [error, setError] = useState<string | null>(null);
  const [siEmail, setSiEmail] = useState("");
  const [siPassword, setSiPassword] = useState("");
  const [suName, setSuName] = useState("");
  const [suEmail, setSuEmail] = useState("");
  const [suPassword, setSuPassword] = useState("");
  const [suPhone, setSuPhone] = useState("");
  /* ROUND L (TASK STORE-PROFILE) — the customer CHOOSES their own username at
   * signup. Optional: when left blank the server mints one from the email
   * local-part (the existing member-handle law). Live availability chip
   * driven by a debounced probe to /account/check-username — UX only; the
   * server re-validates before persisting. */
  const [suUsername, setSuUsername] = useState("");
  const [fpEmail, setFpEmail] = useState("");
  const [forgotHint, setForgotHint] = useState<StoreForgotHintDTO | null>(null);
  const [rsPassword, setRsPassword] = useState("");
  const [rsConfirm, setRsConfirm] = useState("");
  /* ROUND 86 — the strict 45s resend cooldown (directive ①) */
  const [forgotCooldown, setForgotCooldown] = useCountdown();

  const clearError = () => setError(null);

  /* post-auth redirect — the destination surface re-probes the session and
   * mounts its account UI with the fresh cookie */
  const finish = (delayMs = 350) => {
    window.setTimeout(() => router.replace(next), delayMs);
  };

  /* ROUND 85 (QA fix) — WRITE-THROUGH to the SHARED ["store-account"] cache
   * (the same key the store/site providers probe). The account page's own
   * initial GUEST probe lives in the global QueryClient and would otherwise
   * survive the router.replace — the destination surface would serve the
   * stale guest state for up to staleTime (60s) after a successful
   * sign-in / sign-up / reset. Mirrors useApplyAccount exactly. */
  const applyAccount = (next: StoreAccountDTO) => {
    queryClient.setQueryData(["store-account", instanceId], {
      signedIn: true,
      account: next,
      unreadReplies: 0,
    });
    void queryClient.invalidateQueries({ queryKey: ["store-account", instanceId] });
  };

  /* ---------------- mutations ---------------- */
  const signIn = useQueryMutationSafe<StoreAccountDTO>();
  const submitSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    if (!EMAIL_RE.test(siEmail.trim())) {
      setError(t("acctErrGeneric"));
      return;
    }
    if (siPassword.length < 1) {
      setError(t("acctErrCreds"));
      return;
    }
    signIn.mutate(
      () => loginStoreAccount(instanceId, { email: siEmail.trim().toLowerCase(), password: siPassword }),
      {
        onSuccess: (acct) => {
          applyAccount(acct);
          toast.success(t("acctSignedInToast", { name: acct.name }));
          finish();
        },
        onError: (err) => setError(mapAccountError(err, t)),
      }
    );
  };

  const signUp = useQueryMutationSafe<{ account: StoreAccountDTO; verify?: StoreVerifyHintDTO }>();
  const submitSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    if (suName.trim().length < 2) {
      setError(t("acctErrGeneric"));
      return;
    }
    if (!EMAIL_RE.test(suEmail.trim())) {
      setError(t("acctErrGeneric"));
      return;
    }
    if (!PASSWORD_RE.test(suPassword)) {
      setError(t("acctErrPassword"));
      return;
    }
    if (suPhone.trim() && !PHONE_RE.test(suPhone.trim())) {
      setError(t("acctErrGeneric"));
      return;
    }
    /* ROUND L — username is OPTIONAL. When supplied, validate the shape +
     * availability locally before submit (the chip already does both, but
     * a fast-typing customer may hit ENTER mid-debounce; re-checking here
     * prevents a wasted 409 roundtrip). The server is still the source of
     * truth — the register route re-validates regardless. */
    const suUsernameTrim = suUsername.trim().toLowerCase();
    if (suUsernameTrim.length > 0) {
      if (!USERNAME_RE.test(suUsernameTrim) || suUsernameTrim.length < 3 || suUsernameTrim.length > 30) {
        setError(t("acctUsernameInvalid"));
        return;
      }
      if (suUsernameVerdict === "taken") {
        setError(t("acctUsernameTaken"));
        return;
      }
    }
    signUp.mutate(
      () =>
        registerStoreAccount(instanceId, {
          name: suName.trim(),
          email: suEmail.trim().toLowerCase(),
          password: suPassword,
          ...(suPhone.trim() ? { phone: suPhone.trim() } : {}),
          ...(suUsernameTrim ? { username: suUsernameTrim } : {}),
        }),
      {
        onSuccess: ({ account: acct }) => {
          applyAccount(acct);
          toast.success(
            acct.emailVerified
              ? t("acctSignedUpToast", { name: acct.name })
              : t("acctSignedUpVerifyToast", { name: acct.name, email: acct.email })
          );
          finish(650);
        },
        onError: (err) => setError(mapAccountError(err, t)),
      }
    );
  };

  const forgot = useQueryMutationSafe<StoreForgotHintDTO>();
  /** the shared dispatch — used by the forgot FORM and the forgot-done
   *  panel's RESEND (identical journey, identical cooldown discipline).
   *  ROUND 86: every successful dispatch arms the 45-second cooldown and a
   *  server 429 FORGOT_COOLDOWN re-arms it from the exact retryAfterSec. */
  const dispatchForgot = () =>
    forgot.mutate(
      () => forgotStorePassword(instanceId, { email: fpEmail.trim().toLowerCase() }),
      {
        onSuccess: (hint) => {
          setForgotHint(hint);
          setMode("forgot-done");
          setForgotCooldown(FORGOT_COOLDOWN_SECS);
        },
        onError: (err) => {
          const api = err as ApiError;
          if (api && typeof (api as { code?: string }).code === "string" && (api as { code?: string }).code === "FORGOT_COOLDOWN") {
            const secs = Math.max(1, Math.min(FORGOT_COOLDOWN_SECS, Math.floor((api as { retryAfterSec?: number }).retryAfterSec ?? FORGOT_COOLDOWN_SECS)));
            setForgotCooldown(secs);
            toast.info(
              t("acctForgotCooldownToast", { s: fmtNum(secs, lang) })
            );
            return;
          }
          setError(mapAccountError(err, t));
        },
      }
    );
  const submitForgot = (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    if (!EMAIL_RE.test(fpEmail.trim())) {
      setError(t("acctErrGeneric"));
      return;
    }
    dispatchForgot();
  };

  const reset = useQueryMutationSafe<StoreAccountDTO>();
  const submitReset = (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    if (!PASSWORD_RE.test(rsPassword)) {
      setError(t("acctErrPassword"));
      return;
    }
    if (rsPassword !== rsConfirm) {
      setError(t("acctResetMismatch"));
      return;
    }
    reset.mutate(
      () => resetStorePassword(instanceId, { token: resetToken, password: rsPassword }),
      {
        onSuccess: (acct) => {
          applyAccount(acct);
          toast.success(t("acctSignedInToast", { name: acct.name }));
          setMode("reset-done");
          finish(1500);
        },
        onError: (err) => setError(mapAccountError(err, t)),
      }
    );
  };

  const signOut = useQueryMutationSafe<void>();
  const doSignOut = () => {
    signOut.mutate(
      () => logoutStoreAccount(instanceId),
      {
        onSuccess: () => {
          toast.success(t("acctSignedOutToast"));
          void queryClient.invalidateQueries({ queryKey: ["store-account", instanceId] });
          setMode("signin");
        },
      }
    );
  };

  /* the reset link may be pasted cold — surface the token's absence clearly
   * instead of letting the submit fail generically */
  useEffect(() => {
    if (mode === "reset" && !resetToken) {
      setError(t("acctResetInvalid"));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, resetToken]);

  const busy = signIn.isPending || signUp.isPending || forgot.isPending || reset.isPending;

  /* ROUND L — derived username verdict (PURE, render-time):
   *  - the SHAPE verdict (idle / invalid) is computed SYNCHRONOUSLY during
   *    render — no setState in the effect body (react-hooks/purity rule);
   *  - the SERVER verdict (taken / available / checking) is fetched in a
   *    DEBOUNCED effect (350ms) — the setServerVerdict calls happen AFTER
   *    the timeout fires (async, not synchronous in the effect body). */
  const wantedSignupUsername = suUsername.trim().toLowerCase();
  const signupUsernameShapeValid =
    wantedSignupUsername.length >= 3 &&
    wantedSignupUsername.length <= 30 &&
    USERNAME_RE.test(wantedSignupUsername);
  const [suUsernameServerVerdict, setSuUsernameServerVerdict] = useState<
    "idle" | "checking" | "available" | "taken"
  >("idle");
  const suUsernameVerdict: "idle" | "checking" | "available" | "taken" | "invalid" = (() => {
    if (wantedSignupUsername.length === 0) return "idle";
    if (!signupUsernameShapeValid) return "invalid";
    return suUsernameServerVerdict;
  })();

  useEffect(() => {
    if (wantedSignupUsername.length === 0 || !signupUsernameShapeValid) {
      return;
    }
    /* the setSuUsernameServerVerdict calls happen INSIDE the setTimeout
     * callback (async — the purity rule stays clean; matches the wizard's
     * email/phone availability pattern in org-step.tsx). */
    let live = true;
    const handle = window.setTimeout(() => {
      if (!live) return;
      setSuUsernameServerVerdict("checking");
      void checkStoreUsername(instanceId, wantedSignupUsername)
        .then((res: StoreUsernameCheckDTO) => {
          if (live) setSuUsernameServerVerdict(res.available ? "available" : "taken");
        })
        .catch(() => {
          /* network/shape errors → stay neutral so the customer can still submit
           * (the server re-validates on save). */
          if (live) setSuUsernameServerVerdict("idle");
        });
    }, 350);
    return () => {
      live = false;
      window.clearTimeout(handle);
    };
  }, [wantedSignupUsername, signupUsernameShapeValid, instanceId]);


  /* ---------------- mode switcher (signin ↔ signup) ---------------- */
  const isAuthMode = mode === "signin" || mode === "signup";

  return (
    /* ROUND 86 — the account portal carries the STORE's identity: the
       owner-picked store font re-anchors here and the store accent ramp
       retints every brand utility (c1/c2 already arrive from the resolved
       store theme — server side). */
    <div
      className="brand-scope surface-font-scope relative flex min-h-screen flex-col bg-background"
      dir={lang === "ar" ? "rtl" : "ltr"}
      style={{ ...fontVars(storeFont), ...accentVars(c1) }}
    >
      {/* skip-to-content */}
      <SkipLink target="acct-page-main" />

      {/* decorative background */}
      <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden="true" />
      <div
        className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[420px] opacity-60"
        style={{
          background: `radial-gradient(60% 50% at 50% 0%, ${hexAlpha(c1, 0.14)}, transparent 70%)`,
        }}
        aria-hidden="true"
      />

      {/* draft preview banner (owner / admin only — server-gated) */}
      {!published ? (
        <div className="border-b border-amber-300/60 bg-amber-100/90 px-4 py-2 text-center backdrop-blur-sm dark:border-amber-500/30 dark:bg-amber-500/15">
          <p className="inline-flex items-center gap-2 text-[11.5px] font-extrabold text-amber-800 dark:text-amber-300">
            <CatIcon name="eye" className="h-3.5 w-3.5" />
            {t("acctPagePreviewBanner")}
          </p>
        </div>
      ) : null}

      {/* ---------------- mini header ---------------- */}
      <header className="border-b border-slate-200/70 bg-white/80 backdrop-blur-xl dark:border-white/[0.07] dark:bg-ink-950/80">
        <div className="mx-auto flex h-16 max-w-5xl items-center gap-2.5 px-4 sm:px-6">
          <Link href={siteHref} className="flex min-w-0 items-center gap-2.5">
            {logoUrl ? (
              <span
                className="grid h-10 w-10 shrink-0 place-items-center overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-lg dark:border-white/10 dark:bg-white/90"
                aria-hidden="true"
              >
                <img src={logoUrl} alt="" className="h-full w-full object-contain p-1" />
              </span>
            ) : (
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg"
                style={{ backgroundImage: grad(c1, c2), boxShadow: `0 8px 20px -8px ${hexAlpha(c1, 0.8)}` }}
              >
                <CatIcon name={systemIcon} className="h-[15px] w-[15px]" />
              </span>
            )}
            <span className="min-w-0">
              <span className="block truncate font-display text-[14.5px] font-extrabold text-slate-900 dark:text-white">
                {orgName}
              </span>
            </span>
          </Link>

          <div className="ms-auto flex items-center gap-1.5">
            {/* back-to-surface links */}
            <Link
              href={siteHref}
              className="hidden h-11 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-[11.5px] font-extrabold text-slate-600 shadow-sm transition hover:border-transparent hover:shadow-lift active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 sm:inline-flex"
            >
              <CatIcon name="globe" className="h-[14px] w-[14px]" />
              {t("acctPageBackSite")}
            </Link>
            {storeLive ? (
              <Link
                href={storeHref}
                className="hidden h-11 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-[11.5px] font-extrabold text-slate-600 shadow-sm transition hover:border-transparent hover:shadow-lift active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 sm:inline-flex"
              >
                <CatIcon name="store" className="h-[14px] w-[14px]" />
                {t("acctPageBackStore")}
              </Link>
            ) : null}

            {/* language toggle (2 langs — the account portal's own switcher) */}
            <div className="flex items-center rounded-xl border border-slate-200 bg-white p-0.5 dark:border-white/10 dark:bg-white/[0.04]">
              {(["ar", "en"] as const).map((code) => (
                <button
                  key={code}
                  type="button"
                  onClick={() => setLang(code)}
                  aria-pressed={lang === code}
                  className={cn(
                    "grid min-h-11 min-w-11 place-items-center rounded-lg text-[11px] font-extrabold uppercase transition",
                    lang === code
                      ? "bg-slate-900 text-white dark:bg-white dark:text-slate-900"
                      : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white"
                  )}
                >
                  {code === "ar" ? "ع" : "EN"}
                </button>
              ))}
            </div>

            {/* theme toggle */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
              aria-label={t("siteThemeToggle")}
              className="h-11 w-11 rounded-xl text-slate-500 dark:text-slate-400"
            >
              <CatIcon name="sun" className="hidden h-4 w-4 dark:block" />
              <CatIcon name="moon" className="block h-4 w-4 dark:hidden" />
            </Button>
          </div>
        </div>
      </header>

      {/* ---------------- body ---------------- */}
      <main
        id="acct-page-main"
        className="mx-auto grid w-full max-w-5xl flex-1 items-stretch gap-0 px-4 py-10 sm:px-6 lg:grid-cols-[1.05fr_1fr] lg:gap-6 lg:py-16"
      >
        {/* ---------- brand panel ---------- */}
        <section
          className="relative overflow-hidden rounded-3xl p-7 sm:p-9 lg:p-10"
          style={{ backgroundImage: grad(c1, c2) }}
          aria-hidden={false}
        >
          {/* orbs + sheen */}
          <span className="pointer-events-none absolute -top-16 end-[-12%] h-44 w-44 rounded-full bg-white/15 blur-2xl" aria-hidden="true" />
          <span className="pointer-events-none absolute -bottom-20 start-[-10%] h-40 w-40 rounded-full bg-black/10 blur-2xl" aria-hidden="true" />
          <span className="pointer-events-none absolute inset-0 bg-linear-to-b from-white/10 via-transparent to-black/10" aria-hidden="true" />

          <div className="relative flex h-full flex-col">
            <span className="inline-flex w-fit items-center gap-1.5 rounded-full border border-white/30 bg-white/15 px-3 py-1 text-[10.5px] font-extrabold text-white backdrop-blur-sm">
              <CatIcon name="shield-check" className="h-3 w-3" />
              {t("acctPageBadge")}
            </span>

            <div className="mt-6 flex items-center gap-3">
              {logoUrl ? (
                <span className="grid h-14 w-14 shrink-0 place-items-center overflow-hidden rounded-2xl border border-white/30 bg-white/90 p-1.5 shadow-xl">
                  <img src={logoUrl} alt="" className="h-full w-full object-contain" />
                </span>
              ) : (
                <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl border border-white/30 bg-white/15 text-white shadow-xl backdrop-blur-sm">
                  <CatIcon name={systemIcon} className="h-6 w-6" />
                </span>
              )}
              <p className="font-display text-[19px] font-extrabold leading-tight text-white">
                {orgName}
              </p>
            </div>

            <h1 className="mt-5 font-display text-[24px] font-extrabold leading-snug text-white sm:text-[27px]">
              {t("acctPageTitle")}
            </h1>
            <p className="mt-3 max-w-md text-[13px] font-semibold leading-relaxed text-white/85">
              {t("acctPageSubtitle")}
            </p>

            {/* trust bullets */}
            <ul className="mt-7 space-y-3">
              {(
                [
                  { icon: "package", key: "acctPageTrustOrders" },
                  { icon: "shield-check", key: "acctPageTrustSecure" },
                  { icon: "headset", key: "acctPageTrustSupport" },
                ] as const
              ).map((item) => (
                <li key={item.key} className="flex items-center gap-2.5">
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl border border-white/25 bg-white/15 text-white backdrop-blur-sm">
                    <CatIcon name={item.icon} className="h-[13px] w-[13px]" />
                  </span>
                  <span className="text-[12px] font-bold text-white/90">{t(item.key)}</span>
                </li>
              ))}
            </ul>

            <p className="mt-auto flex items-center gap-1.5 pt-8 text-[10.5px] font-bold text-white/70">
              <CatIcon name="lock" className="h-3 w-3" />
              {t("acctPageSecureNote")}
            </p>
          </div>
        </section>

        {/* ---------- auth panel ---------- */}
        <section className="glass-card card-in relative mt-4 flex flex-col rounded-3xl p-6 sm:p-8 lg:mt-0">
          {sessionQuery.isPending ? (
            <div className="space-y-4 py-8" aria-busy="true">
              <Skeleton className="h-8 w-2/3" />
              <Skeleton className="h-11 w-full rounded-xl" />
              <Skeleton className="h-11 w-full rounded-xl" />
              <Skeleton className="h-11 w-full rounded-xl" />
            </div>
          ) : account ? (
            /* ---------------- already signed in ---------------- */
            <div className="flex flex-1 flex-col items-center justify-center py-10 text-center">
              <span
                className="grid h-16 w-16 place-items-center rounded-2xl text-white shadow-xl"
                style={{ backgroundImage: grad(c1, c2) }}
              >
                <CatIcon name="circle-check" className="h-7 w-7" />
              </span>
              <h2 className="mt-5 font-display text-[17px] font-extrabold text-slate-900 dark:text-white">
                {t("acctPageSignedTitle")}
              </h2>
              <p className="mt-2 max-w-xs text-[12.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                {t("acctPageSignedDesc", { name: account.name })}
              </p>
              <div className="mt-6 flex flex-wrap items-center justify-center gap-2.5">
                <Button
                  onClick={() => router.replace(next)}
                  className="h-11 gap-2 rounded-xl px-5 text-[13px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.99]"
                  style={{
                    backgroundImage: grad(c1, c2),
                    boxShadow: `0 12px 26px -10px ${hexAlpha(c1, 0.75)}`,
                  }}
                >
                  <CatIcon name="arrow-left" className="h-4 w-4 rtl:rotate-180" />
                  {t("acctPageContinue")}
                </Button>
                <Button
                  variant="outline"
                  onClick={doSignOut}
                  disabled={signOut.isPending}
                  className="h-11 gap-2 rounded-xl px-4 text-[12.5px] font-bold"
                >
                  <CatIcon name="log-out" className="h-4 w-4" />
                  {t("selectSignOut")}
                </Button>
              </div>
            </div>
          ) : isAuthMode ? (
            /* ---------------- sign in / sign up ---------------- */
            <div className="flex flex-1 flex-col">
              {/* mode switcher */}
              <div
                role="tablist"
                aria-label={t("acctPageTitle")}
                className="grid h-12 w-full grid-cols-2 gap-1 rounded-2xl bg-slate-100 p-1 dark:bg-white/5"
              >
                {(
                  [
                    { value: "signin", key: "acctTabSignIn" },
                    { value: "signup", key: "acctTabSignUp" },
                  ] as const
                ).map((tabDef) => {
                  const active = mode === tabDef.value;
                  return (
                    <button
                      key={tabDef.value}
                      type="button"
                      role="tab"
                      aria-selected={active}
                      onClick={() => {
                        setMode(tabDef.value);
                        clearError();
                      }}
                      className={cn(
                        "h-10 rounded-xl text-[12.5px] font-extrabold transition",
                        active
                          ? "bg-white text-slate-900 shadow-sm dark:bg-white/10 dark:text-white"
                          : "text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200"
                      )}
                    >
                      {t(tabDef.key)}
                    </button>
                  );
                })}
              </div>

              {mode === "signin" ? (
                <form onSubmit={submitSignIn} className="mt-6 flex flex-1 flex-col gap-4" noValidate>
                  <PremiumEmailInput
                    id="ap-si-email"
                    label="acctEmail"
                    value={siEmail}
                    onChange={setSiEmail}
                    required
                    placeholder="acctEmailPh"
                    autoComplete="email"
                    disabled={busy}
                  />
                  <AccountPasswordField
                    id="ap-si-password"
                    labelKey="acctPassword"
                    value={siPassword}
                    onChange={setSiPassword}
                    autoComplete="current-password"
                    placeholder={t("acctPasswordPh")}
                    disabled={busy}
                  />

                  {/* forgot link */}
                  <button
                    type="button"
                    onClick={() => {
                      setMode("forgot");
                      clearError();
                      setFpEmail(siEmail);
                    }}
                    className="-mt-1 w-fit text-[11.5px] font-extrabold text-brand-600 underline decoration-dotted underline-offset-4 transition hover:text-brand-500 dark:text-brand-300 dark:hover:text-brand-200"
                  >
                    {t("acctPageForgotLink")}
                  </button>

                  {error ? <ErrorBanner text={error} /> : null}

                  <Button
                    type="submit"
                    disabled={signIn.isPending}
                    className="mt-auto h-12 w-full gap-2 rounded-xl text-[13.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.99] disabled:opacity-70"
                    style={{
                      backgroundImage: grad(c1, c2),
                      boxShadow: `0 12px 26px -10px ${hexAlpha(c1, 0.75)}`,
                    }}
                  >
                    {signIn.isPending ? (
                      <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                    ) : (
                      <CatIcon name="log-in" className="h-4 w-4" />
                    )}
                    {signIn.isPending ? t("acctWorking") : t("acctDoSignIn")}
                  </Button>

                  <ModeAltLink
                    text={t("acctPageSignupAlt")}
                    onClick={() => {
                      setMode("signup");
                      clearError();
                    }}
                  />
                </form>
              ) : (
                <form onSubmit={submitSignUp} className="mt-6 flex flex-1 flex-col gap-4" noValidate>
                  <div className="space-y-1.5">
                    <Label htmlFor="ap-su-name" className={AP_LABEL}>
                      {t("acctName")} <span className="text-rose-500">*</span>
                    </Label>
                    <div className="relative">
                      <CatIcon
                        name="user-round"
                        className="pointer-events-none absolute start-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
                      />
                      <Input
                        id="ap-su-name"
                        value={suName}
                        onChange={(e) => setSuName(e.target.value)}
                        placeholder={t("acctNamePh")}
                        maxLength={80}
                        autoComplete="name"
                        disabled={busy}
                        className="h-11 rounded-xl ps-10 text-start"
                      />
                    </div>
                  </div>

                  {/* ROUND L (TASK STORE-PROFILE) — the customer CHOOSES their
                      own username at signup. Optional: when left blank the
                      server mints one from the email local-part. The live
                      availability chip is driven by a debounced probe to
                      /account/check-username — UX only; the server re-validates. */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <Label htmlFor="ap-su-username" className={AP_LABEL}>
                        {t("acctUsername")}
                      </Label>
                      {suUsernameVerdict === "checking" ? (
                        <span className="inline-flex items-center gap-1 rounded-full border border-slate-200 bg-slate-50 px-2 py-0.5 text-[9.5px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400">
                          <Loader2 className="h-3 w-3 animate-spin" />
                          {t("acctUsernameChecking")}
                        </span>
                      ) : suUsernameVerdict === "available" ? (
                        <span className="inline-flex items-center gap-1 rounded-full border border-emerald-300/60 bg-emerald-500/10 px-2 py-0.5 text-[9.5px] font-extrabold text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300">
                          <CatIcon name="circle-check" className="h-3 w-3" />
                          {t("acctUsernameAvailable")}
                        </span>
                      ) : suUsernameVerdict === "taken" ? (
                        <span className="inline-flex items-center gap-1 rounded-full border border-rose-300/60 bg-rose-500/10 px-2 py-0.5 text-[9.5px] font-extrabold text-rose-600 dark:border-rose-500/40 dark:text-rose-300">
                          <CatIcon name="circle-x" className="h-3 w-3" />
                          {t("acctUsernameTaken")}
                        </span>
                      ) : suUsernameVerdict === "invalid" ? (
                        <span className="inline-flex items-center gap-1 rounded-full border border-amber-300/60 bg-amber-500/10 px-2 py-0.5 text-[9.5px] font-extrabold text-amber-600 dark:border-amber-500/40 dark:text-amber-300">
                          <CatIcon name="triangle-alert" className="h-3 w-3" />
                          {t("acctUsernameInvalid")}
                        </span>
                      ) : (
                        <span className="text-[9.5px] font-bold text-slate-400 dark:text-slate-500">
                          {t("acctUsernameOptional")}
                        </span>
                      )}
                    </div>
                    <div className="relative">
                      <CatIcon
                        name="at-sign"
                        className="pointer-events-none absolute start-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
                      />
                      <Input
                        id="ap-su-username"
                        dir="ltr"
                        value={suUsername}
                        onChange={(e) => setSuUsername(e.target.value)}
                        placeholder={t("acctUsernamePh")}
                        maxLength={30}
                        autoComplete="off"
                        spellCheck={false}
                        disabled={busy}
                        className="h-11 rounded-xl bg-white ps-10 text-start font-mono text-[13px] font-bold dark:bg-white/[0.04]"
                      />
                    </div>
                    <p className="text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                      {t("acctUsernameHint")}
                    </p>
                  </div>

                  <PremiumEmailInput
                    id="ap-su-email"
                    label="acctEmail"
                    value={suEmail}
                    onChange={setSuEmail}
                    required
                    placeholder="acctEmailPh"
                    hint="pciStoreEmailVerifyHint"
                    autoComplete="email"
                    disabled={busy}
                  />

                  <AccountPasswordField
                    id="ap-su-password"
                    labelKey="acctPassword"
                    value={suPassword}
                    onChange={setSuPassword}
                    autoComplete="new-password"
                    placeholder={t("acctPasswordPh")}
                    disabled={busy}
                  />

                  <PremiumPhoneInput
                    id="ap-su-phone"
                    label="acctPhone"
                    value={suPhone}
                    onChange={setSuPhone}
                    hint="pciStorePhoneHint"
                    autoComplete="tel"
                    disabled={busy}
                  />

                  {error ? <ErrorBanner text={error} /> : null}

                  <Button
                    type="submit"
                    disabled={signUp.isPending}
                    className="mt-auto h-12 w-full gap-2 rounded-xl text-[13.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.99] disabled:opacity-70"
                    style={{
                      backgroundImage: grad(c1, c2),
                      boxShadow: `0 12px 26px -10px ${hexAlpha(c1, 0.75)}`,
                    }}
                  >
                    {signUp.isPending ? (
                      <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                    ) : (
                      <CatIcon name="user-round-plus" className="h-4 w-4" />
                    )}
                    {signUp.isPending ? t("acctWorking") : t("acctDoSignUp")}
                  </Button>

                  <ModeAltLink
                    text={t("acctPageSigninAlt")}
                    onClick={() => {
                      setMode("signin");
                      clearError();
                    }}
                  />
                </form>
              )}
            </div>
          ) : mode === "forgot" ? (
            /* ---------------- forgot password ---------------- */
            <form onSubmit={submitForgot} className="flex flex-1 flex-col gap-4" noValidate>
              <ModeHeading
                icon="key-round"
                title={t("acctForgotTitle")}
                desc={t("acctForgotDesc")}
                c1={c1}
                c2={c2}
              />
              <PremiumEmailInput
                id="ap-fp-email"
                label="acctEmail"
                value={fpEmail}
                onChange={setFpEmail}
                required
                placeholder="acctEmailPh"
                autoComplete="email"
                disabled={forgot.isPending}
              />
              {error ? <ErrorBanner text={error} /> : null}
              <Button
                type="submit"
                disabled={forgot.isPending}
                className="mt-auto h-12 w-full gap-2 rounded-xl text-[13.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.99] disabled:opacity-70"
                style={{
                  backgroundImage: grad(c1, c2),
                  boxShadow: `0 12px 26px -10px ${hexAlpha(c1, 0.75)}`,
                }}
              >
                {forgot.isPending ? (
                  <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                ) : (
                  <CatIcon name="mail" className="h-4 w-4" />
                )}
                {forgot.isPending ? t("acctWorking") : t("acctForgotDo")}
              </Button>
              <ModeAltLink text={t("acctForgotBack")} onClick={() => { setMode("signin"); clearError(); }} />
            </form>
          ) : mode === "forgot-done" ? (
            /* ---------------- forgot → check your inbox ---------------- */
            <div className="flex flex-1 flex-col items-center justify-center gap-3 py-6 text-center">
              <span
                className="grid h-16 w-16 place-items-center rounded-2xl text-white shadow-xl"
                style={{ backgroundImage: grad(c1, c2) }}
              >
                <CatIcon name="mail-check" className="h-7 w-7" />
              </span>
              <h2 className="font-display text-[16.5px] font-extrabold text-slate-900 dark:text-white">
                {t("acctForgotDoneTitle")}
              </h2>
              <p className="max-w-sm text-[12.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                {t("acctForgotDoneDesc")}
              </p>
              {forgotHint?.devLink ? (
                <a
                  href={forgotHint.devLink}
                  dir="ltr"
                  className="mt-1 inline-flex max-w-full items-center gap-2 rounded-2xl border border-amber-300/70 bg-amber-500/10 px-4 py-2.5 text-start text-[11px] font-bold text-amber-700 transition hover:bg-amber-500/20 dark:border-amber-500/40 dark:bg-amber-500/15 dark:text-amber-300"
                >
                  <CatIcon name="flask-conical" className="h-4 w-4 shrink-0" />
                  <span className="min-w-0">
                    <span className="block text-[10px] font-extrabold uppercase tracking-wide">
                      {t("acctForgotDevLabel")}
                    </span>
                    <span className="block truncate font-mono">{forgotHint.devLink}</span>
                  </span>
                </a>
              ) : null}
              {/* ROUND 86 (directive ①) — the STRICT 45-second resend
                  cooldown: the button is dead until the window closes, the
                  label counts down in Arabic-Indic numerals (AR), a slim
                  progress bar drains in real time, and the server refuses
                  any request inside the window with 429 + retryAfterSec. */}
              <div className="mt-3 w-full max-w-xs">
                <Button
                  variant="outline"
                  onClick={() => {
                    clearError();
                    dispatchForgot();
                  }}
                  disabled={forgot.isPending || forgotCooldown > 0}
                  className="h-11 w-full gap-2 rounded-xl px-4 text-[12.5px] font-bold disabled:opacity-70"
                >
                  {forgot.isPending ? (
                    <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                  ) : forgotCooldown > 0 ? (
                    <CatIcon name="clock" className="h-4 w-4 text-brand-600 dark:text-brand-300" />
                  ) : (
                    <CatIcon name="send" className="h-4 w-4" />
                  )}
                  <span dir={lang === "ar" ? "rtl" : "ltr"} className="tabular-nums">
                    {forgotCooldown > 0
                      ? t("acctForgotResendIn", { s: fmtNum(forgotCooldown, lang) })
                      : t("acctForgotResendNow")}
                  </span>
                </Button>
                {forgotCooldown > 0 ? (
                  <div
                    className="mt-2 h-1 overflow-hidden rounded-full bg-slate-200 dark:bg-white/10"
                    role="progressbar"
                    aria-label={t("acctForgotResendIn", { s: fmtNum(forgotCooldown, lang) })}
                    aria-valuenow={forgotCooldown}
                    aria-valuemin={0}
                    aria-valuemax={FORGOT_COOLDOWN_SECS}
                  >
                    <div
                      className="h-full rounded-full transition-[width] duration-1000 ease-linear"
                      style={{
                        width: `${(forgotCooldown / FORGOT_COOLDOWN_SECS) * 100}%`,
                        backgroundImage: grad(c1, c2),
                      }}
                    />
                  </div>
                ) : null}
              </div>
              <div className="mt-3 flex flex-wrap items-center justify-center gap-2.5">
                <Button
                  variant="ghost"
                  onClick={() => { setMode("signin"); clearError(); }}
                  className="h-11 gap-2 rounded-xl px-4 text-[12.5px] font-bold"
                >
                  <CatIcon name="arrow-left" className="h-4 w-4 rtl:rotate-180" />
                  {t("acctForgotBack")}
                </Button>
              </div>
            </div>
          ) : mode === "reset" ? (
            /* ---------------- the emailed link: new password ---------------- */
            <form onSubmit={submitReset} className="flex flex-1 flex-col gap-4" noValidate>
              <ModeHeading
                icon="key-round"
                title={t("acctResetTitle")}
                desc={t("acctResetDesc")}
                c1={c1}
                c2={c2}
              />
              <AccountPasswordField
                id="ap-rs-password"
                labelKey="acctResetPasswordLabel"
                value={rsPassword}
                onChange={setRsPassword}
                autoComplete="new-password"
                placeholder={t("acctPasswordPh")}
                invalid={!!error}
                disabled={reset.isPending}
              />
              <AccountPasswordField
                id="ap-rs-confirm"
                labelKey="acctResetConfirmLabel"
                value={rsConfirm}
                onChange={setRsConfirm}
                autoComplete="new-password"
                placeholder={t("acctPasswordPh")}
                invalid={!!error}
                disabled={reset.isPending}
              />
              {error ? <ErrorBanner text={error} /> : null}
              <Button
                type="submit"
                disabled={reset.isPending || !resetToken}
                className="mt-auto h-12 w-full gap-2 rounded-xl text-[13.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.99] disabled:opacity-70"
                style={{
                  backgroundImage: grad(c1, c2),
                  boxShadow: `0 12px 26px -10px ${hexAlpha(c1, 0.75)}`,
                }}
              >
                {reset.isPending ? (
                  <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                ) : (
                  <CatIcon name="circle-check" className="h-4 w-4" />
                )}
                {reset.isPending ? t("acctWorking") : t("acctResetDo")}
              </Button>
              <ModeAltLink text={t("acctForgotBack")} onClick={() => { setMode("signin"); clearError(); }} />
            </form>
          ) : (
            /* ---------------- reset done → redirecting ---------------- */
            <div className="flex flex-1 flex-col items-center justify-center gap-3 py-10 text-center">
              <span
                className="grid h-16 w-16 place-items-center rounded-2xl text-white shadow-xl"
                style={{ backgroundImage: grad(c1, c2) }}
              >
                <CatIcon name="circle-check" className="h-7 w-7" />
              </span>
              <h2 className="font-display text-[16.5px] font-extrabold text-slate-900 dark:text-white">
                {t("acctResetDoneTitle")}
              </h2>
              <p className="max-w-sm text-[12.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                {t("acctResetDoneDesc")}
              </p>
              <span className="mt-2 h-1.5 w-40 overflow-hidden rounded-full bg-slate-200 dark:bg-white/10">
                <span className="splash-slide h-full w-1/2 rounded-full" style={{ backgroundImage: grad(c1, c2) }} />
              </span>
            </div>
          )}
        </section>
      </main>

      {/* ---------------- footer ---------------- */}
      <footer className="safe-bottom border-t border-slate-200/70 bg-white/60 py-4 backdrop-blur-sm dark:border-white/[0.07] dark:bg-white/[0.02]">
        <p className="flex flex-wrap items-center justify-center gap-2 px-4 text-center text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
          <CatIcon name="shield-check" className="h-3 w-3 text-emerald-500" />
          {t("acctPageSecureNote")}
          <span className="text-slate-300 dark:text-slate-600">·</span>
          © {new Date().getFullYear()} {orgName}
          <span className="text-slate-300 dark:text-slate-600">·</span>
          {lang === "ar" ? "مدعوم بأشرِيلوجيك" : "Powered by Ashrilogic"}
        </p>
      </footer>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* small view helpers                                                   */
/* ------------------------------------------------------------------ */

/** the shared rose error banner (dialog conventions). */
function ErrorBanner({ text }: { text: string }) {
  return (
    <div
      role="alert"
      className="flex items-start gap-2.5 rounded-2xl border border-rose-300/60 bg-rose-500/10 px-4 py-3 dark:border-rose-500/30"
    >
      <CatIcon name="circle-x" className="mt-0.5 h-4 w-4 shrink-0 text-rose-500" />
      <p className="text-[12px] font-bold leading-relaxed text-rose-600 dark:text-rose-300">{text}</p>
    </div>
  );
}

/** the subtle dotted switch link under the forms. */
function ModeAltLink({ text, onClick }: { text: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="mx-auto w-fit text-center text-[11.5px] font-extrabold text-slate-500 underline decoration-dotted underline-offset-4 transition hover:text-brand-600 dark:text-slate-400 dark:hover:text-brand-300"
    >
      {text}
    </button>
  );
}

/** the heading block for the forgot / reset modes. */
function ModeHeading({
  icon,
  title,
  desc,
  c1,
  c2,
}: {
  icon: string;
  title: string;
  desc: string;
  c1: string;
  c2: string;
}) {
  return (
    <div className="flex items-start gap-3.5">
      <span
        className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
        style={{ backgroundImage: grad(c1, c2) }}
        aria-hidden="true"
      >
        <CatIcon name={icon} className="h-5 w-5" />
      </span>
      <div className="min-w-0">
        <h2 className="font-display text-[16px] font-extrabold text-slate-900 dark:text-white">{title}</h2>
        <p className="mt-1 text-[12px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">{desc}</p>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* a tiny typed mutation wrapper (keeps the JSX above readable)         */
/* ------------------------------------------------------------------ */

/**
 * useMutation with the mutationFn supplied per-call (the page's four flows
 * share one shape: fn → onSuccess(data) / onError(Error)).
 */
function useQueryMutationSafe<T>() {
  return useMutation<T, Error, () => Promise<T>>({
    mutationFn: (fn) => fn(),
  });
}

export default AccountPageView;
