"use client";

/**
 * ROUND 65 — storefront CUSTOMER ACCOUNTS (Amazon/Shopify-grade, Arabic-first).
 *
 * The whole backend surface already exists (built + verified by the main
 * agent — see the Task 65-main worklog entry): register / login / logout /
 * profile / address-book / saved-cards / order-history routes with an
 * HttpOnly customer session, Argon2id credentials, Luhn+brand card intake
 * (PCI-safe: only {brand,last4,expiry,holder} ever persists) and
 * exactly-one-default invariants. This file is ONLY the React wiring:
 *
 *  - StoreAccountProvider — one react-query probe of GET /account feeding a
 *    context (useStoreAccount) + a tiny module-level mirror
 *    (useStoreAccountMirror) so the guest checkout sheet can prefill the
 *    contact card WITHOUT prop-drilling through store-shared's 3000 lines;
 *  - StoreAccountButton — the header entry: guests get a subtle "create
 *    account" pill that LINKS to the dedicated account PAGE (ROUND 85 —
 *    /sites/[id]/account?mode=signup: the full sign-in / sign-up /
 *    forgot-password / reset journey, no popup); signed-in customers get
 *    the initials avatar with a brand gradient ring, which opens the
 *    account sheet;
 *  - StoreAccountSheet — the SIGNED-IN account home (Profile / Addresses /
 *    Payments / Orders / Inquiries + sign-out) was split into
 *    store-account-sheet.tsx (ROUND 85) so the public surfaces can
 *    lazy-load it; this module keeps and exports the shared internals the
 *    sheet imports one-directionally: the provider/context, the
 *    sheet-request bus (onAccountSheetRequest), AcctAvatar / AcctField /
 *    ConfirmDeletePopover / AcctEmptyState, useApplyAccount, PanelProps and
 *    mapAccountError. The old StoreAuthDialog popup is GONE — account
 *    creation is the dedicated page's job now.
 *
 * Conventions (mirrored from storefront-view.tsx / store-shared.tsx):
 * RTL logical classes only (ms-/me-/ps-/pe-/start-/end-), grad()/hexAlpha()
 * theming, CatIcon vocabulary, sonner toasts, aria labels in Arabic,
 * dark: variants on every custom color, touch targets at 44px (h-11).
 */
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
  type ReactNode,
} from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import Link from "next/link";
import { UserRoundPlus } from "lucide-react";
import { toast } from "sonner";
import { useT } from "@/lib/i18n";
import type { StoreAccountDTO } from "@/lib/types";
import {
  fetchStoreAccount,
  logoutStoreAccount,
  removeStoreAccountAvatar,
  uploadStoreAccountAvatar,
} from "@/lib/api-client";
import { cn, fmtNum, grad, hexAlpha, initial } from "@/lib/utils";
import { CatIcon } from "@/components/icon";
import { AvatarPicker } from "@/components/dashboard/avatar-picker";
import { Label } from "@/components/ui/label";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Skeleton } from "@/components/ui/skeleton";

/* ------------------------------------------------------------------ */
/* tiny module-level account mirror                                     */
/* ------------------------------------------------------------------ */

/**
 * The signed-in snapshot also lives in a tiny external store so surfaces
 * OUTSIDE the provider's React tree can subscribe without prop drilling
 * (the checkout contact form in store-shared.tsx is the consumer; the
 * provider is the ONLY writer). useSyncExternalStore keeps it tear-free.
 */
let accountMirror: StoreAccountDTO | null = null;
const mirrorListeners = new Set<() => void>();

function setAccountMirror(next: StoreAccountDTO | null): void {
  if (accountMirror === next) return;
  accountMirror = next;
  for (const listener of mirrorListeners) listener();
}

function subscribeMirror(listener: () => void): () => void {
  mirrorListeners.add(listener);
  return () => {
    mirrorListeners.delete(listener);
  };
}

/** The signed-in account wherever you are (null = guest). Live-updating. */
export function useStoreAccountMirror(): StoreAccountDTO | null {
  return useSyncExternalStore(
    subscribeMirror,
    () => accountMirror,
    () => null
  );
}

/* ------------------------------------------------------------------ */
/* ROUND 76 — the sheet-request bus                                     */
/* ------------------------------------------------------------------ */

/**
 * Cross-component "open the account sheet at tab X" signal. The provider's
 * live-reply toast (below) fires from outside every surface's sheet wiring —
 * this tiny bus routes its action straight to استفساراتي without
 * prop-drilling open-state through public-site-view / storefront-view.
 * Same shape as the mirror: module-level listener set, one emitter.
 */
type SheetRequestListener = (tab: string) => void;
const sheetRequestListeners = new Set<SheetRequestListener>();

/** fire-and-forget: ask the mounted sheet to open (switching tabs if it
 * already is). No listener mounted → a silent no-op (safe anywhere). */
function openAccountSheetAt(tab: string): void {
  for (const listener of sheetRequestListeners) listener(tab);
}

/** ROUND 85 — exported: the account sheet now lives in
 * store-account-sheet.tsx and subscribes through this bus. */
export function onAccountSheetRequest(fn: SheetRequestListener): () => void {
  sheetRequestListeners.add(fn);
  return () => {
    sheetRequestListeners.delete(fn);
  };
}

/* ------------------------------------------------------------------ */
/* shared helpers                                                       */
/* ------------------------------------------------------------------ */

type TranslateFn = ReturnType<typeof useT>["t"];

/** server error → localized message (by machine code, message as fallback).
 *  ROUND 85 — exported: the dedicated account PAGE reuses the exact mapping. */
export function mapAccountError(e: unknown, t: TranslateFn): string {
  const err = e as { code?: string; message?: string; status?: number } | null;
  const code = err?.code;
  if (code === "EMAIL_TAKEN") return t("acctErrTaken");
  if (code === "NO_ACCOUNT") return t("acctErrNoAccount");
  if (code === "RATE") return t("acctErrRate");
  if (code === "LUHN") return t("acctCardLuhnErr");
  if (code === "CAP") return t("acctAddressCapErr");
  /* blind 401 from the login route (no code) — never leak which half failed */
  if (err?.status === 401) return t("acctErrCreds");
  return err?.message || t("acctErrGeneric");
}

/* ------------------------------------------------------------------ */
/* ROUND 76 — the live-reply notification card                          */
/* ------------------------------------------------------------------ */

/**
 * The premium toast the customer sees the moment the organization replies
 * while they browse (sonner's toast.custom slot). Presentational ONLY:
 * every string arrives as a prop because the Toaster portal renders
 * OUTSIDE the i18n provider's tree — the provider captures t()/lang at
 * emit time. Amber conversation tile with a live pulse dot, emerald
 * action that routes straight to استفساراتي via the sheet-request bus.
 */
function ReplyToast({
  dir,
  title,
  sub,
  action,
  onOpen,
}: {
  dir: "rtl" | "ltr";
  title: string;
  sub: string;
  action: string;
  onOpen: () => void;
}) {
  return (
    <div
      dir={dir}
      role="status"
      className="pointer-events-auto relative mx-auto flex w-full max-w-[calc(100vw-2.5rem)] items-center gap-3 overflow-hidden rounded-2xl border border-amber-300/70 bg-white p-3 pe-2.5 shadow-lift ring-1 ring-black/[0.03] dark:border-amber-400/25 dark:bg-slate-900 dark:ring-white/[0.04] sm:w-[390px]"
    >
      {/* soft amber wash + radial accent */}
      <span
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-gradient-to-br from-amber-50/90 via-transparent to-transparent dark:from-amber-400/[0.07]"
      />
      <span
        aria-hidden="true"
        className="pointer-events-none absolute -top-8 end-6 h-20 w-20 rounded-full bg-amber-300/25 blur-2xl dark:bg-amber-400/10"
      />
      {/* conversation tile + live pulse dot */}
      <span className="relative grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 text-white shadow-lg shadow-amber-500/30">
        <CatIcon name="messages-square" className="h-5 w-5" />
        <span className="absolute -end-0.5 -top-0.5" aria-hidden="true">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-amber-300 opacity-75" />
          <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-amber-500 ring-2 ring-white dark:ring-slate-900" />
        </span>
      </span>
      <div className="relative min-w-0 flex-1">
        <p className="truncate font-display text-[13px] font-extrabold text-slate-900 dark:text-white">
          {title}
        </p>
        <p className="mt-0.5 line-clamp-2 text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
          {sub}
        </p>
      </div>
      <button
        type="button"
        onClick={onOpen}
        className="relative inline-flex h-10 shrink-0 items-center gap-1.5 self-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-500 px-3.5 text-[12px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:brightness-110 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-emerald-500 active:scale-95"
      >
        <span className="whitespace-nowrap">{action}</span>
        <CatIcon name={dir === "rtl" ? "arrow-left" : "arrow-right"} className="h-4 w-4 shrink-0" />
      </button>
    </div>
  );
}

/** shared panel props (instance + brand colors), like every store block.
 * ROUND 85 — exported: the panels live in store-account-sheet.tsx now.
 * ROUND 147 — optional store identity (org display name + logo) for the
 * surfaces that print receipts from a panel (the member page passes them;
 * legacy sheet mounts keep the bare trio — the receipt falls back). */
export interface PanelProps {
  instanceId: string;
  c1: string;
  c2: string;
  orgName?: string;
  logoUrl?: string;
}

/* ------------------------------------------------------------------ */
/* provider + context                                                   */
/* ------------------------------------------------------------------ */

interface StoreAccountContextValue {
  account: StoreAccountDTO | null;
  signedIn: boolean;
  loading: boolean;
  /** ROUND 74 — org replies not opened yet (badge on the account button). */
  unreadReplies: number;
  refresh: () => void;
  signOut: () => Promise<void>;
  /** ROUND 147 — the member's avatar photo mutations. Lived IN THE
   *  PROVIDER so every consumer heals together: both write the fresh
   *  account straight through the shared ["store-account", id] cache
   *  (useApplyAccount) — the header button, the sheet header and the
   *  member hero all repaint from ONE trip, and the errors surface as
   *  localized toasts (mapAccountError) without any caller plumbing. */
  avatarSaving: boolean;
  uploadAvatar: (dataUrl: string) => void;
  removeAvatar: () => void;
}

const StoreAccountContext = createContext<StoreAccountContextValue | null>(null);

/**
 * ONE probe of GET /api/sites/[id]/account (guest → {signedIn:false}, 200 —
 * never 401). Mounted once by StorefrontView; every account mutation writes
 * its fresh StoreAccountDTO straight back into this cache, and the mirror
 * effect below republishes it for the checkout prefill.
 */
export function StoreAccountProvider({
  instanceId,
  children,
}: {
  instanceId: string;
  children: ReactNode;
}) {
  const qc = useQueryClient();
  const { t, lang } = useT();
  const query = useQuery({
    queryKey: ["store-account", instanceId],
    queryFn: () => fetchStoreAccount(instanceId),
    staleTime: 60_000,
    retry: 0,
  });
  const account = query.data?.signedIn ? query.data.account ?? null : null;

  /* ROUND 76 — live reply notifications. While the customer is signed in
   * and the tab is VISIBLE, one lightweight probe every 45s keeps the
   * account button's unread badge fresh — and when unreadReplies INCREASES
   * (the organization replied while they browsed), a premium toast lets
   * them jump straight to استفساراتي. Hidden tabs skip the poll entirely
   * (visibilitychange does not fire here; the guard inside the tick is the
   * cheap, dependable gate). */
  const prevUnreadRef = useRef<number | null>(null);
  useEffect(() => {
    if (!account) {
      prevUnreadRef.current = null;
      return;
    }
    const id = window.setInterval(() => {
      if (document.visibilityState === "visible") {
        void qc.invalidateQueries({ queryKey: ["store-account", instanceId] });
      }
    }, 45_000);
    return () => window.clearInterval(id);
  }, [account, qc, instanceId]);

  const unread = query.data?.unreadReplies ?? 0;
  useEffect(() => {
    if (!account) {
      prevUnreadRef.current = null;
      return;
    }
    const prev = prevUnreadRef.current;
    prevUnreadRef.current = unread;
    /* first observation after sign-in only arms the baseline — the badge
     * on the button already tells that story; the toast is strictly for
     * replies that land WHILE the customer is here. */
    if (prev === null || unread <= prev) return;
    const delta = unread - prev;
    const dir = lang === "ar" ? "rtl" : "ltr";
    /* ROUND 141 — the action routes to the member's DEDICATED profile page
     * (استفساراتي tab) — the popup sheet is retired on both surfaces. */
    const memberInquiriesHref = account.username
      ? `/sites/${instanceId}/account/${encodeURIComponent(account.username)}?tab=inquiries`
      : `/sites/${instanceId}/account`;
    toast.custom(
      (toastId) => (
        <ReplyToast
          dir={dir}
          title={
            delta === 1
              ? t("acctReplyToastTitle")
              : t("acctReplyToastTitleMany", { count: fmtNum(delta, lang) })
          }
          sub={t("acctReplyToastSub")}
          action={t("acctReplyToastAction")}
          onOpen={() => {
            toast.dismiss(toastId);
            window.location.assign(memberInquiriesHref);
          }}
        />
      ),
      { duration: 10_000 }
    );
  }, [unread, account, t, lang, instanceId]);

  /* the ONLY writer of the module mirror (subscribe side lives anywhere) */
  useEffect(() => {
    setAccountMirror(account);
  }, [account]);

  const refresh = useCallback(() => {
    void qc.invalidateQueries({ queryKey: ["store-account", instanceId] });
    void qc.invalidateQueries({ queryKey: ["store-orders", instanceId] });
  }, [qc, instanceId]);

  const signOut = useCallback(async () => {
    await logoutStoreAccount(instanceId);
    refresh();
  }, [instanceId, refresh]);

  /* ROUND 147 — avatar upload/remove: same write-through discipline as
   * every account mutation (the fresh DTO lands in the shared cache and
   * the probe re-fetches so the unread badge survives). */
  const applyAccount = useApplyAccount(instanceId);
  const uploadAvatarMut = useMutation({
    mutationFn: (dataUrl: string) => uploadStoreAccountAvatar(instanceId, dataUrl),
    onSuccess: (next) => {
      applyAccount(next);
      toast.success(t("acctAvatarUpdated"));
    },
    onError: (e: Error) => toast.error(mapAccountError(e, t)),
  });
  const removeAvatarMut = useMutation({
    mutationFn: () => removeStoreAccountAvatar(instanceId),
    onSuccess: (next) => {
      applyAccount(next);
      toast.success(t("acctAvatarRemoved"));
    },
    onError: (e: Error) => toast.error(mapAccountError(e, t)),
  });

  /* const aliases FIRST so the memo's dependency list matches what the
   * compiler infers (mutate/isPending are the exact references the value
   * closure uses — TanStack keeps them referentially stable). */
  const avatarSaving = uploadAvatarMut.isPending || removeAvatarMut.isPending;
  const uploadAvatarMutate = uploadAvatarMut.mutate;
  const removeAvatarMutate = removeAvatarMut.mutate;

  const value = useMemo<StoreAccountContextValue>(
    () => ({
      account,
      signedIn: account !== null,
      loading: query.isPending,
      unreadReplies: query.data?.unreadReplies ?? 0,
      refresh,
      signOut,
      avatarSaving,
      uploadAvatar: (dataUrl: string) => uploadAvatarMutate(dataUrl),
      removeAvatar: () => removeAvatarMutate(),
    }),
    [
      account,
      query.isPending,
      query.data?.unreadReplies,
      refresh,
      signOut,
      avatarSaving,
      uploadAvatarMutate,
      removeAvatarMutate,
    ]
  );

  return <StoreAccountContext.Provider value={value}>{children}</StoreAccountContext.Provider>;
}

/** account state inside the provider tree (throws loudly when mismounted). */
export function useStoreAccount(): StoreAccountContextValue {
  const ctx = useContext(StoreAccountContext);
  if (!ctx) {
    throw new Error("useStoreAccount must be used inside <StoreAccountProvider>");
  }
  return ctx;
}

/** write-through: mutations return the fresh account — push it into the
 * cache so the button/sheet/checkout prefill update with zero extra trips.
 * ROUND 85 — exported: the panels in store-account-sheet.tsx reuse it. */
export function useApplyAccount(instanceId: string): (next: StoreAccountDTO) => void {
  const qc = useQueryClient();
  return useCallback(
    (next: StoreAccountDTO) => {
      qc.setQueryData(["store-account", instanceId], { signedIn: true, account: next });
      /* ROUND 74 — the unread-replies count lives on the probe response;
       * the write-through above would clobber it to undefined. Re-fetch the
       * probe (one lightweight request) so the account-button badge always
       * reflects reality right after a login / register / profile write. */
      void qc.invalidateQueries({ queryKey: ["store-account", instanceId] });
    },
    [qc, instanceId]
  );
}

/* ------------------------------------------------------------------ */
/* small shared atoms                                                   */
/* ------------------------------------------------------------------ */

/** gradient-ring initials avatar (the dashboard's avatar vocabulary).
 * ROUND 85 — exported: the account sheet (store-account-sheet.tsx) reuses it.
 * ROUND 147 — renders the member's UPLOADED photo (a managed
 * /api/images/<sha> ref) inside the exact same ring/gradient shell when
 * `avatarUrl` is present; a missing ref or a broken load falls back to the
 * historical initials tile (the fallback is per-URL, so replacing the photo
 * retries the image instead of staying stuck on the initials). */
export function AcctAvatar({
  name,
  c1,
  c2,
  size = "md",
  avatarUrl,
}: {
  name: string;
  c1: string;
  c2: string;
  size?: "sm" | "md";
  avatarUrl?: string | null;
}) {
  const [brokenUrl, setBrokenUrl] = useState<string | null>(null);
  const photo = avatarUrl && avatarUrl !== brokenUrl ? avatarUrl : null;
  return (
    <span
      aria-hidden="true"
      className={cn(
        "grid shrink-0 place-items-center rounded-full p-[2.5px]",
        size === "sm" ? "h-9 w-9" : "h-14 w-14"
      )}
      style={{
        backgroundImage: grad(c1, c2),
        boxShadow: `0 10px 24px -10px ${hexAlpha(c1, 0.8)}`,
      }}
    >
      <span
        className={cn(
          "relative grid h-full w-full place-items-center overflow-hidden rounded-full bg-white font-black text-slate-900 dark:bg-ink-900 dark:text-white",
          size === "sm" ? "text-[13px]" : "text-[20px]"
        )}
      >
        {photo ? (
          <>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={photo}
              alt=""
              loading="lazy"
              decoding="async"
              onError={() => setBrokenUrl(photo)}
              className="h-full w-full object-cover"
            />
          </>
        ) : (
          initial(name)
        )}
      </span>
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* ROUND 147 (revised, ROUND L) — avatar editing (own-profile surfaces)  */
/* ------------------------------------------------------------------ */

/* The member's own avatar now rides the UNIFIED AvatarPicker pipeline
 * (src/components/dashboard/avatar-picker.tsx — pick → 25MB cap → type
 * allowlist → FileReader decode probe → AvatarCropperDialog drag/pinch/
 * rotate → 288px JPEG ≈≤120KB). The bespoke canvas-compression helpers
 * (compressAvatarFile, the size/quality ladders, AVATAR_MAX_INPUT_BYTES,
 * AVATAR_EDGE, AVATAR_TARGET_BYTES, AVATAR_MIME_RE) are RETIRED — the
 * unified picker owns the whole intake now, and its toasts (cropTooLarge,
 * siteLogoBadType, siteLogoCorrupt) replace the old acctAvatarTooLarge /
 * acctAvatarInvalid guards. The server pipeline at
 * /api/sites/[id]/account/avatar remains the authority on the wire. */

/**
 * ROUND 147 → ROUND L (unified) — the member's own avatar now rides the
 * SAME premium AvatarPicker component the workspace OWNER and every team
 * member use (src/components/dashboard/avatar-picker.tsx): pick → 25MB
 * cap → type allowlist → FileReader decode probe → AvatarCropperDialog
 * (drag / pinch / rotate → 288px JPEG ≈≤120KB) → onPick(dataUrl).
 *
 * The owner's directive — «في جميع الأنظمة تعديل صورة بروفايل العضو يجب
 * يكون متطورة بنفس برمجية تعديل صورة بروفايل مٌلاك الأنظمة الموحد بدقة
 * عالية» — is satisfied by this single delegation: no bespoke canvas
 * compression, no custom pencil overlay, no hidden file input here. The
 * uploadAvatar(dataUrl) mutation (POST /api/sites/[id]/account/avatar) and
 * removeAvatar() mutation (DELETE) feed straight into the unified picker's
 * onPick / onRemove callbacks; the disabled={avatarSaving} gate stays so
 * the picker is inert while either mutation is in flight. The picker owns
 * its own size/mime/decode toasts (cropTooLarge / siteLogoBadType /
 * siteLogoCorrupt) so the old acctAvatarTooLarge / acctAvatarInvalid
 * guards are retired.
 */
export function AcctAvatarEditor({ c1, c2 }: { c1: string; c2: string }) {
  const { t } = useT();
  const { account, avatarSaving, uploadAvatar, removeAvatar } = useStoreAccount();
  const hasPhoto = !!account?.avatarUrl;

  return (
    <AvatarPicker
      avatarUrl={account?.avatarUrl ?? null}
      name={account?.name ?? ""}
      c1={c1}
      c2={c2}
      onPick={(dataUrl) => uploadAvatar(dataUrl)}
      onRemove={hasPhoto ? () => removeAvatar() : undefined}
      disabled={avatarSaving}
      size="lg"
      ring
      ariaLabel={t("acctAvatarUpload")}
    />
  );
}

/** the account tab empty states (icon on a soft gradient circle).
 * ROUND 85 — exported: the panels in store-account-sheet.tsx reuse it. */
export function AcctEmptyState({
  icon,
  title,
  desc,
  c1,
  c2,
}: {
  icon: string;
  title: string;
  desc: string;
  c1: string;
  c2: string;
}) {
  return (
    <div className="rounded-2xl border-2 border-dashed border-slate-200 px-6 py-9 text-center dark:border-white/10">
      <span
        aria-hidden="true"
        className="mx-auto grid h-16 w-16 place-items-center rounded-full ring-1"
        style={{
          backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.16)}, ${hexAlpha(c2, 0.16)})`,
          color: c1,
          boxShadow: `inset 0 0 0 1px ${hexAlpha(c1, 0.18)}`,
        }}
      >
        <CatIcon name={icon} className="h-7 w-7" />
      </span>
      <h3 className="mt-4 font-display text-[13.5px] font-extrabold text-slate-900 dark:text-white">
        {title}
      </h3>
      <p className="mx-auto mt-1.5 max-w-[30ch] text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
        {desc}
      </p>
    </div>
  );
}

/** one labeled form field (label + optional required asterisk).
 * ROUND 85 — exported: the panels in store-account-sheet.tsx reuse it. */
export function AcctField({
  id,
  label,
  required = false,
  children,
}: {
  id: string;
  label: string;
  required?: boolean;
  children: ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id} className="text-[12px] font-bold">
        {label}
        {required ? <span className="text-rose-500"> *</span> : null}
      </Label>
      {children}
    </div>
  );
}

/** destructive confirm (popover) — reused by addresses + cards.
 * ROUND 85 — exported: the panels in store-account-sheet.tsx reuse it. */
export function ConfirmDeletePopover({
  triggerLabel,
  itemLabel,
  itemIcon,
  confirmLabel,
  pending,
  onConfirm,
}: {
  triggerLabel: string;
  itemLabel: string;
  itemIcon: string;
  confirmLabel: string;
  pending: boolean;
  onConfirm: () => void;
}) {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <button
          type="button"
          aria-label={triggerLabel}
          title={triggerLabel}
          className="grid h-9 w-9 place-items-center rounded-xl border border-slate-200 text-slate-400 transition hover:border-rose-300 hover:text-rose-500 active:scale-95 dark:border-white/10 dark:text-slate-500 dark:hover:border-rose-500/40 dark:hover:text-rose-300"
        >
          <CatIcon name="trash-2" className="h-3.5 w-3.5" />
        </button>
      </PopoverTrigger>
      <PopoverContent align="end" className="z-[130] w-52 rounded-2xl p-3.5">
        <p className="flex items-center gap-2 text-[12px] font-extrabold text-slate-800 dark:text-slate-100">
          <CatIcon name={itemIcon} className="h-4 w-4 shrink-0 text-rose-500" />
          <span className="truncate">{itemLabel}</span>
        </p>
        <button
          type="button"
          onClick={onConfirm}
          disabled={pending}
          className="mt-3 inline-flex h-9 w-full items-center justify-center gap-1.5 rounded-xl bg-rose-600 px-3 text-[11.5px] font-extrabold text-white shadow-sm transition hover:bg-rose-500 active:scale-95 disabled:opacity-60"
        >
          {pending ? (
            <CatIcon name="refresh-cw" className="h-3.5 w-3.5 animate-spin" />
          ) : (
            <CatIcon name="trash-2" className="h-3.5 w-3.5" />
          )}
          {confirmLabel}
        </button>
      </PopoverContent>
    </Popover>
  );
}

/* ------------------------------------------------------------------ */
/* header entry button                                                  */
/* ------------------------------------------------------------------ */

/**
 * The header account entry. Guest: a subtle bordered "create account" pill
 * (icon-only on mobile — the header is packed) that navigates to the
 * DEDICATED account page (ROUND 85 — /sites/[id]/account?mode=signup,
 * optionally carrying a validated ?next= return path; the page itself
 * offers one-tap sign-in, forgot password and reset — no popup anymore).
 * Signed-in (ROUND 141): the initials avatar with a brand gradient ring +
 * the first name (desktop widths) LINKS to the member's DEDICATED profile
 * page — /sites/<id>/account/<username> — the owner's directive: member
 * profiles are real pages carrying the member's own username, never a
 * popup. The unread-replies badge still rides the avatar (the member
 * page's استفساراتي tab marks them read).
 */
export function StoreAccountButton({
  instanceId,
  authNext,
  onAccount,
  c1,
  c2,
}: {
  instanceId: string;
  /** validated same-site return path handed to the page as ?next=... */
  authNext?: string;
  /** ROUND 141 — RETAINED for legacy wiring but the default signed-in path
   *  is the member page; surfaces that still prefer a popup pass it through. */
  onAccount?: () => void;
  c1: string;
  c2: string;
}) {
  const { t, lang } = useT();
  const { account, signedIn, loading, unreadReplies } = useStoreAccount();

  if (loading) {
    return <Skeleton className="h-11 w-11 rounded-xl sm:w-36" />;
  }

  if (!signedIn || !account) {
    return (
      <Link
        href={`/sites/${instanceId}/account?mode=signup${authNext ? `&next=${encodeURIComponent(authNext)}` : ""}`}
        aria-label={t("acctSignUpBtn")}
        title={t("acctSignUpBtn")}
        className="inline-flex h-11 shrink-0 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-2.5 text-[11.5px] font-extrabold text-slate-600 shadow-sm transition hover:border-transparent hover:shadow-lift hover:text-slate-800 active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:text-white sm:px-3.5"
      >
        <UserRoundPlus className="h-[17px] w-[17px] shrink-0" style={{ color: c1 }} />
        <span className="hidden whitespace-nowrap sm:inline">{t("acctSignUpBtn")}</span>
      </Link>
    );
  }

  const firstName = account.name.trim().split(/\s+/)[0] || account.name;
  /* ROUND 141 — the member's DEDICATED profile page (the popup is retired):
   * /sites/<id>/account/<username>. A missing handle (a vault read hiccup)
   * falls back to the account portal — never a dead link. */
  const memberHref = account.username
    ? `/sites/${instanceId}/account/${encodeURIComponent(account.username)}`
    : `/sites/${instanceId}/account`;

  return (
    <Link
      href={memberHref}
      aria-label={unreadReplies > 0 ? t("acctUnreadHint") : t("acctAccountBtn")}
      title={unreadReplies > 0 ? `${t("acctUnreadHint")} (${unreadReplies})` : t("acctAccountBtn")}
      className="relative inline-flex h-11 shrink-0 items-center gap-2 rounded-full border border-slate-200 bg-white ps-1.5 pe-1.5 shadow-sm transition hover:border-transparent hover:shadow-lift active:scale-95 dark:border-white/10 dark:bg-white/[0.04] lg:pe-4"
    >
      {/* ROUND 147 — the member's uploaded photo rides the same shell
          (initials remain the fallback); the button itself stays a LINK. */}
      <AcctAvatar name={account.name} c1={c1} c2={c2} size="sm" avatarUrl={account.avatarUrl} />
      <span className="hidden max-w-24 truncate text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200 lg:inline">
        {firstName}
      </span>
      {/* ROUND 74 — unread org replies: amber pill on the avatar's corner */}
      {unreadReplies > 0 ? (
        <span
          dir="ltr"
          className="absolute -end-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-gradient-to-br from-amber-400 to-orange-500 px-1 text-[10px] font-black tabular-nums text-white shadow-md ring-2 ring-white dark:ring-slate-950"
        >
          {fmtNum(unreadReplies, lang)}
        </span>
      ) : null}
    </Link>
  );
}
