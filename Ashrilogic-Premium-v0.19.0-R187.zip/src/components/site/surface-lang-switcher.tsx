"use client";

/**
 * ROUND 86 — the visitor language switcher for the public surfaces
 * (public website · e-store · account page).
 *
 * Renders ONLY the languages the owner enabled in
 * Settings → التفضيلات → لغات الزوار (siteLangs / storeLangs):
 *
 *   • 1 language  → HIDDEN (nothing to switch — a deliberate, clean look)
 *   • 2–3 langs   → the classic segmented pill control (instant flip)
 *   • 4+ langs    → a compact globe dropdown (native endonym labels)
 *
 * The active chip highlights the CURRENT visitor language when it is part of
 * the enabled set; a language outside the set simply shows no active state
 * (the owner's choice governs what is offered, never a hard redirect).
 */
import { useAppStore } from "@/lib/store";
import { useT } from "@/lib/i18n";
import { LOCALES, localeShortLabel } from "@/lib/locales";
import type { Lang } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function SurfaceLangSwitcher({ langs }: { langs: readonly string[] }) {
  const { t, lang } = useT();
  const setLang = useAppStore((s) => s.setLang);

  /* nothing to switch — render nothing at all */
  if (langs.length < 2) return null;

  /* the classic segmented control (2–3 languages) */
  if (langs.length <= 3) {
    return (
      <div
        className="flex items-center rounded-xl border border-slate-200 bg-white p-0.5 dark:border-white/10 dark:bg-white/[0.04]"
        role="group"
        aria-label={t("langMenuTitle")}
      >
        {langs.map((code) => {
          const active = lang === code;
          return (
            <button
              key={code}
              type="button"
              onClick={() => setLang(code as Lang)}
              aria-pressed={active}
              className={cn(
                "grid min-h-11 min-w-11 place-items-center rounded-lg text-[11px] font-extrabold transition",
                active
                  ? "bg-slate-900 text-white dark:bg-white dark:text-slate-900"
                  : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white"
              )}
            >
              {localeShortLabel(code as Lang)}
            </button>
          );
        })}
      </div>
    );
  }

  /* 4+ languages — the globe dropdown */
  return (
    <DropdownMenu dir={lang === "ar" ? "rtl" : "ltr"}>
      <DropdownMenuTrigger
        className="inline-flex h-11 min-w-11 items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-[11px] font-extrabold text-slate-600 transition hover:border-slate-300 hover:text-slate-900 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:text-white"
        aria-label={t("langMenuTitle")}
      >
        <CatIcon name="globe" className="h-4 w-4" />
        <span className="hidden sm:inline">{localeShortLabel(lang)}</span>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="min-w-44">
        <DropdownMenuRadioGroup
          value={lang}
          onValueChange={(v) => setLang(v as Lang)}
        >
          {langs.map((code) => {
            const meta = LOCALES.find((l) => l.code === code);
            if (!meta) return null;
            return (
              <DropdownMenuRadioItem
                key={code}
                value={code}
                className="text-[12.5px] font-bold"
              >
                <span className="text-[10px] font-extrabold uppercase text-slate-400">
                  {meta.short}
                </span>
                {meta.native}
              </DropdownMenuRadioItem>
            );
          })}
        </DropdownMenuRadioGroup>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
