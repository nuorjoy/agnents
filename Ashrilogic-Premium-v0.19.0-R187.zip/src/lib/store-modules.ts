/**
 * Ashrilogic — ROUND 141 (client-safe store module resolution).
 *
 * The storefront catalog is derived from ONE catalog module of the workspace
 * (priority: pharmacy → products → menu → inventory — see
 * src/lib/server/store-mapper.ts, the server authority). This PURE module
 * carries the same list for CLIENT surfaces: the module-workspace record
 * dialog shows the premium product extras (the media switch + the variants
 * builder) ONLY on the module that actually feeds the store — the owner's
 * «صفحة المنتجات» is whichever catalog module their system uses.
 *
 * No imports beyond types — safe on the client AND the server.
 */

/** The catalog module priority (single source of truth shared with the server mapper). */
export const STORE_MODULE_PRIORITY: readonly string[] = ["pharmacy", "products", "menu", "inventory"];

/**
 * Resolve the catalog module of a workspace from its ENABLED module list.
 * Returns null when the workspace has no catalog module (no store products).
 */
export function storeProductModuleId(enabledModules: readonly string[]): string | null {
  for (const candidate of STORE_MODULE_PRIORITY) {
    if (enabledModules.includes(candidate)) return candidate;
  }
  return null;
}
