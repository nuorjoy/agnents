/**
 * Ashrilogic — ROUND 141 (wallet): the dual-numeral AMOUNT INPUT parser.
 *
 * The owner's directive: wallet top-ups accept BOTH Arabic-Indic numerals
 * (١٢٣٫٥٠) and Western numerals (1,234.50) — the premium input never makes
 * the user think about which keyboard they are on.
 *
 * PURE module — imported by the client (live input validation) AND the
 * server (the wallet top-up route re-parses the RAW string: the client
 * never sends a pre-computed number).
 *
 * The normalization folds:
 *   - Arabic-Indic digits ٠-٩ (U+0660–U+0669) and Extended ۰-۹
 *     (U+06F0–U+06F9) → ASCII 0-9;
 *   - the Arabic decimal separator ٫ (U+066B) → ".";
 *   - thousands separators — Arabic ٬ (U+066C), the Arabic full stop forms,
 *     Latin commas and spaces (incl. NBSP) — stripped entirely;
 * then validates the numeric shape (≤ 2 decimals) and the minor-unit
 * bounds from money.ts.
 */

export const AMOUNT_INPUT_MAX_MINOR = 1_000_000_000; // 10M major units — hard ceiling
export const AMOUNT_INPUT_MAX_DECIMALS = 2;

/** Fold every supported numeral/separator form into canonical ASCII. */
export function normalizeAmountInput(raw: string): string {
  if (typeof raw !== "string") return "";
  let out = "";
  for (const ch of raw.trim()) {
    const code = ch.codePointAt(0) ?? 0;
    if (ch >= "0" && ch <= "9") {
      out += ch;
    } else if (code >= 0x0660 && code <= 0x0669) {
      // Arabic-Indic ٠-٩
      out += String(code - 0x0660);
    } else if (code >= 0x06f0 && code <= 0x06f9) {
      // Extended Arabic-Indic ۰-۹
      out += String(code - 0x06f0);
    } else if (ch === "٫") {
      out += ".";
    } else if (ch === "." ) {
      out += ".";
    } else if (ch === "٬" || ch === "," || ch === " " || ch === "\u00a0" || ch === "\u066c") {
      // thousands separators — dropped
      continue;
    } else if (ch === "+" || ch === "-") {
      out += ch;
    } else {
      return ""; // any foreign character disqualifies the input
    }
  }
  return out;
}

export type AmountParseResult =
  | { ok: true; minor: number; major: number; normalized: string }
  | { ok: false; error: "EMPTY" | "MALFORMED" | "NEGATIVE" | "DECIMALS" | "TOO_LARGE" };

/**
 * Parse a raw dual-numeral amount string into INTEGER MINOR UNITS.
 * Returns a discriminated error so the UI can explain precisely.
 */
export function parseAmountInputToMinor(raw: string): AmountParseResult {
  const normalized = normalizeAmountInput(raw);
  if (normalized === "") return { ok: false, error: "EMPTY" };
  if (!/^[+-]?\d+(\.\d+)?$|^[+-]?\.\d+$/.test(normalized)) {
    return { ok: false, error: "MALFORMED" };
  }
  const value = Number(normalized);
  if (!Number.isFinite(value)) return { ok: false, error: "MALFORMED" };
  if (value <= 0) return { ok: false, error: "NEGATIVE" };
  const decimals = normalized.includes(".") ? normalized.split(".")[1]!.length : 0;
  if (decimals > AMOUNT_INPUT_MAX_DECIMALS) return { ok: false, error: "DECIMALS" };
  const minor = Math.round(value * 100);
  if (minor > AMOUNT_INPUT_MAX_MINOR) return { ok: false, error: "TOO_LARGE" };
  return { ok: true, minor, major: value, normalized };
}

/** True when the raw input is INCOMPLETE but not yet invalid (mid-typing). */
export function amountInputIsNeutral(raw: string): boolean {
  return normalizeAmountInput(raw) === "";
}
