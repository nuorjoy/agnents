/**
 * Ashrilogic — tenant backup DR import (create-from-backup, ROUND 97).
 *
 * THE GAP THIS CLOSES (audit 2-b, CRITICAL #3): the tenant backup envelope
 * is a complete reconstruction artifact, but the RESTORE path requires the
 * Instance row to still exist and to match `meta.instanceId` — the
 * ownership gate. In the actual disaster scenario (the Instance row or the
 * whole database is lost), the file could NOT be restored anywhere. There
 * was no platform-side path back. This module is that path.
 *
 * PROTOCOL (data-safety lock — same shape as the re-seal runbook):
 *   1. VERIFY      — standalone envelope verification (backup.ts's exact
 *                    battery: format, version, size, SHA-256 digest, deep
 *                    zod shape), trusting the file's own instanceId.
 *   2. GATES       — target instance id must be FREE (an existing row means
 *                    this is an in-place restore — use the dashboard restore
 *                    endpoint instead, never this path), systemId must be a
 *                    known catalog system, backup modules must belong to
 *                    that system, an optional assigned package must exist.
 *   3. KEY GATE    — every sealed customer/team envelope must open under the
 *                    running ASHRILOGIC_DATA_KEY (copied verbatim — a key
 *                    mismatch halts BEFORE anything is created).
 *   4. IMAGE GATE  — every embedded image re-hashes to its content address
 *                    (tampered bytes abort BEFORE anything is created).
 *   5. SHELL       — create the Instance row with the SAME id (site URLs,
 *                    audit references and the tenant's identity stay
 *                    stable), a FRESH sealed owner identity (the backup
 *                    deliberately carries no credentials — a stolen file
 *                    must never yield a working login) and a fresh trial
 *                    (entitlement levers are excluded from the file by
 *                    design; the platform re-establishes them).
 *   6. RESTORE     — run the battle-tested restore engine over the shell —
 *                    it re-verifies everything server-side, takes the
 *                    maintenance lease, and lands ALL sections + images in
 *                    ONE transaction with its own `instance.restore` audit
 *                    row. Maximal reuse: zero restore logic is duplicated.
 *   7. COMPENSATE  — if ANY step after the shell creation fails, the shell
 *                    row is DELETED by id (scoped — we just created it, so
 *                    the delete can only ever remove this import's own
 *                    shell) and the database is left byte-identical to the
 *                    pre-import state. Additive image files are
 *                    content-addressed and idempotent — harmless orphans,
 *                    exactly like an upload whose owning row was never
 *                    saved.
 *   8. VERIFY+AUDIT— post-import row counts vs the file, the login
 *                    candidate resolves by blind index, and an
 *                    `instance.import` SECURITY audit row (unconditional)
 *                    records the file digest, counts, bootstrap identity
 *                    and outcome.
 *
 * USAGE: offline CLI `scripts/import-backup.ts` (dry-run by default;
 * `--confirm` requires the app to be STOPPED and takes a VACUUM INTO
 * snapshot first — see that script for the full operator runbook).
 *
 * ROLLBACK (operator): the CLI snapshots the database to
 * db/pre-import-<stamp>.db before any write — cp it back + remove stale WAL
 * sidecars, documented in the script header.
 */

import { createHash } from "node:crypto";
import { db } from "@/lib/db";
import { SYSTEM_MAP, systemMods } from "@/data/catalog";
import { normalizeEmail, sealAdminSection } from "@/lib/server/instance-mapper";
import { hashPassword } from "@/lib/server/admin-session";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { TRIAL_DAYS, freshTrialEndsAt } from "@/lib/server/entitlement";
import { isSealedField, decryptField } from "@/lib/server/crypto-vault";
import {
  verifyBackupEnvelope,
  restoreInstanceBackup,
  type RestoreActor,
} from "@/lib/server/backup";

/* ------------------------------- contract -------------------------------- */

export interface ImportOptions {
  /** Bootstrap owner login email — the workspace's NEW authentication
   *  identifier (the file carries none by design). Normalized like
   *  provisioning. */
  ownerEmail: string;
  /** Owner display name (default: "<org name> — Owner"). */
  ownerName?: string;
  /** Bootstrap owner password (PLAINTEXT, min 12 chars — same policy as
   *  provisioning). Hashed with Argon2id before anything is stored; never
   *  logged, never persisted in the clear. */
  ownerPassword: string;
  /** Optional plan linkage (defaults to a fresh free-trial window, exactly
   *  like new provisioning — entitlement levers never travel in the file). */
  packageId?: string | null;
  /** Audit identity for the operator performing the import. */
  actor: RestoreActor;
}

export type ImportResult =
  | {
      ok: true;
      instanceId: string;
      restored: number;
      imagesRestored: number;
      imagesMissing: number;
      bootstrapEmail: string;
      backupChecksum: string;
    }
  | { ok: false; reason: string };

/** Documented failure vocabulary (reason strings are load-bearing — the
 *  CLI maps them to actionable operator guidance). */
export const IMPORT_REASONS = {
  format: "not an Ashrilogic backup file (envelope shape/version)",
  checksum: "integrity digest mismatch — the file is corrupt or was edited",
  size: "sections payload exceeds the portable size ceiling",
  unknownSystem: "the backup's systemId is not in the platform catalog",
  instanceExists:
    "the target instance already exists — use the dashboard RESTORE (in-place) path instead",
  unknownModule: "the backup enables modules outside its system's catalog",
  packageNotFound: "the requested package id does not exist",
  planModules: "the requested package caps modules below the backup's enabled set",
  planUsers: "the requested package caps team size below the backup's team",
  sealedKeyMismatch:
    "sealed envelopes do not open under the running ASHRILOGIC_DATA_KEY (rotated key? see the re-seal runbook)",
  imageChecksum: "an embedded image does not hash to its content address (tampered bytes)",
  weakPassword: "the bootstrap password must be at least 12 characters",
  badEmail: "a usable bootstrap email is required",
  shellCreate: "the instance shell row could not be created",
  restoreFailed: "the restore engine failed after the shell was created (rolled back)",
  verify: "post-import verification mismatch — investigate before touching the data",
} as const;

/* ------------------------------- helpers --------------------------------- */

/** Serialize a parsed-or-raw JSON column exactly like the restore engine. */
function serializeColumn(value: unknown): string {
  return typeof value === "string" ? value : JSON.stringify(value);
}

/** Read the org display name for labels (fail-soft, same as backup.ts). */
function orgNameOf(org: unknown): string {
  if (typeof org === "object" && org !== null && !Array.isArray(org)) {
    const name = (org as Record<string, unknown>).name;
    if (typeof name === "string") return name.slice(0, 200);
  }
  return "";
}

/** Validate a bootstrap credential pair BEFORE any database write. */
function validateBootstrap(
  email: string,
  password: string
): { ok: true; email: string } | { ok: false; reason: string } {
  if (typeof password !== "string" || password.length < 12) {
    return { ok: false, reason: "weak-password" };
  }
  const normalized = normalizeEmail(email ?? "");
  if (!normalized || !normalized.includes("@") || normalized.length > 254) {
    return { ok: false, reason: "bad-email" };
  }
  return { ok: true, email: normalized };
}

/* -------------------------------- import --------------------------------- */

/**
 * Create a tenant from a verified backup envelope — the DR path for a lost
 * Instance row. Pure library function: preflight gates, shell creation,
 * battle-tested restore engine, compensating rollback, post-verification,
 * unconditional audit row. The CLI (scripts/import-backup.ts) owns the
 * app-stopped port probe and the VACUUM INTO snapshot AROUND this call.
 *
 * NEVER runs while a live server holds the database open — the CLI enforces
 * that; this function trusts its caller (same contract as re-seal).
 */
export async function importInstanceBackup(
  envelope: unknown,
  options: ImportOptions
): Promise<ImportResult> {
  /* ---- 1. standalone verification (checksum + deep shape) ---- */
  const verified = await verifyBackupEnvelope(envelope);
  if (!verified.ok) return { ok: false, reason: verified.reason };
  const { meta, sections } = verified;

  /* ---- bootstrap credential gate (before any database access) ---- */
  const boot = validateBootstrap(options.ownerEmail, options.ownerPassword);
  if (!boot.ok) return { ok: false, reason: boot.reason };

  const instanceId = meta.instanceId;
  const system = SYSTEM_MAP[sections.instance.systemId];

  /* ---- 2. target + catalog gates ---- */
  if (!system) return { ok: false, reason: "unknown-system" };
  const existing = await db.instance.findUnique({
    where: { id: instanceId },
    select: { id: true },
  });
  if (existing) return { ok: false, reason: "instance-exists" };

  /* module allowlist — same rule as provisioning + restore (defense in
     depth: the restore engine re-checks after the shell exists) */
  const backupModules = Array.isArray(sections.instance.modules)
    ? (sections.instance.modules as unknown[]).filter(
        (m): m is string => typeof m === "string"
      )
    : [];
  const allowed = new Set(systemMods(system));
  if (backupModules.some((m) => !allowed.has(m))) {
    return { ok: false, reason: "unknown-module" };
  }

  /* optional plan linkage — a package id must exist; its caps apply (the
     restore engine enforces them again server-side) */
  if (options.packageId) {
    const pkg = await db.package.findUnique({
      where: { id: options.packageId },
      select: { maxModules: true, maxUsers: true },
    });
    if (!pkg) return { ok: false, reason: "package-not-found" };
    if (backupModules.length > pkg.maxModules) {
      return { ok: false, reason: "plan-modules" };
    }
    if (sections.team.length > pkg.maxUsers) {
      return { ok: false, reason: "plan-users" };
    }
  }

  /* ---- 3. sealed-key compatibility gate (BEFORE anything is created) ----
   * Same contract as the restore engine: sealed values that fail GCM
   * authentication under the running key = key mismatch or corruption —
   * halt with an actionable reason, never silently degrade. */
  for (const c of sections.customers) {
    if (isSealedField(c.emailSealed) && decryptField(c.emailSealed) === "") {
      return { ok: false, reason: "sealed-key-mismatch" };
    }
  }
  for (const m of sections.team) {
    if (isSealedField(m.emailSealed) && decryptField(m.emailSealed) === "") {
      return { ok: false, reason: "sealed-key-mismatch" };
    }
  }

  /* ---- 4. image digest gate (BEFORE anything is created) ---- */
  for (const img of sections.images ?? []) {
    if (!img.dataBase64) continue; // missing-at-build markers are counted, not fatal
    const digest = createHash("sha256")
      .update(Buffer.from(img.dataBase64, "base64"))
      .digest("hex");
    if (digest !== img.id) {
      return { ok: false, reason: "image-checksum" };
    }
  }

  /* ---- 5. shell row: same id, fresh owner identity, fresh entitlement ----
   * The backup deliberately carries no credentials and no entitlement
   * levers — the platform re-establishes both (documented exclusions in
   * backup.ts). Keeping the FILE's id means /sites/<id> URLs, audit-trail
   * references and the tenant's identity survive the disaster. */
  const ownerName =
    options.ownerName?.trim() || `${orgNameOf(sections.instance.org) || system.nameEn} — Owner`;
  const sealed = sealAdminSection({
    name: ownerName.slice(0, 120),
    email: boot.email,
    role: "owner",
    twoFA: false,
  });

  try {
    await db.instance.create({
      data: {
        id: instanceId,
        systemId: sections.instance.systemId,
        /* the restore engine lands the file's exact org/prefs/modules right
           after — the shell carries them so even a mid-flight observer sees
           a coherent workspace */
        orgJson: serializeColumn(sections.instance.org),
        adminJson: sealed.adminJson,
        adminEmailIndex: sealed.adminEmailIndex,
        prefsJson: serializeColumn(sections.instance.prefs),
        modulesJson: serializeColumn(sections.instance.modules),
        /* fresh free trial (or the operator's package) — entitlement levers
           never travel in the file; the owner activates a plan after login */
        packageId: options.packageId ?? null,
        trialEndsAt: freshTrialEndsAt(),
        passwordHash: hashPassword(options.ownerPassword),
        /* preserve the workspace's business creation date (audit + billing
           history coherence); the IMPORT event itself is recorded below with
           today's timestamp */
        createdAt: new Date(sections.instance.createdAt),
        activities: {
          create: [
            {
              kind: "actCreated",
              metaJson: JSON.stringify({
                system: sections.instance.systemId,
                trial: String(TRIAL_DAYS),
                imported: "1",
              }),
            },
            { kind: "actLogin" },
            {
              kind: "actModuleEnabled",
              metaJson: JSON.stringify({ count: String(backupModules.length) }),
            },
            { kind: "actBackup" },
          ],
        },
      },
    });
  } catch (error) {
    console.error(`importInstanceBackup(${instanceId}) shell create failed:`, error);
    return { ok: false, reason: "shell-create" };
  }

  /* ---- 6. the battle-tested restore engine (re-verifies + lands all) ---- */
  const restore = await restoreInstanceBackup(instanceId, envelope, options.actor);

  if (!restore.ok) {
    /* ---- 7. compensating rollback: remove OUR OWN shell ----
     * Scoped by the id we just created; the restore engine is fully
     * transactional, so its failure already left zero data rows — deleting
     * the shell returns the database to the exact pre-import state. */
    try {
      await db.instance.delete({ where: { id: instanceId } });
    } catch (error) {
      /* the compensating delete itself failed — surface loudly; the shell
         row is inert (no data, no site) and can be removed manually */
      console.error(
        `importInstanceBackup(${instanceId}) COMPENSATING DELETE FAILED — remove the shell row manually:`,
        error
      );
    }
    await logAudit({
      actorType: options.actor.actorType,
      actorId: options.actor.actorId,
      actorName: options.actor.actorName,
      action: "instance.import",
      targetLabel: orgNameOf(sections.instance.org) || sections.instance.systemId,
      meta: {
        outcome: "failed",
        reason: restore.reason,
        fileChecksum: meta.checksum.slice(0, 16),
        rollback: "shell-removed",
      },
    });
    return { ok: false, reason: "restore-failed" };
  }

  /* ---- 8. post-import verification (app stopped — mismatches mean the
     file lied about itself; data stays for investigation, never deleted) ---- */
  const [records, customers, orders, team, reviews, coupons, found] = await Promise.all([
    db.moduleRecord.count({ where: { instanceId } }),
    db.siteCustomer.count({ where: { instanceId } }),
    db.siteOrder.count({ where: { instanceId } }),
    db.teamMember.count({ where: { instanceId } }),
    db.siteReview.count({ where: { instanceId } }),
    db.storeCoupon.count({ where: { instanceId } }),
    db.instance.findFirst({
      where: { adminEmailIndex: sealed.adminEmailIndex },
      select: { id: true },
    }),
  ]);
  const countMismatch =
    records !== sections.moduleRecords.length ||
    customers !== sections.customers.length ||
    orders !== sections.orders.length ||
    team !== sections.team.length ||
    reviews !== (sections.reviews?.length ?? 0) ||
    coupons !== (sections.coupons?.length ?? 0);
  if (countMismatch || found?.id !== instanceId) {
    console.error(
      `importInstanceBackup(${instanceId}) POST-VERIFY MISMATCH — counts r${records}/c${customers}/o${orders}/t${team}/v${reviews}/k${coupons}, login-candidate=${found?.id ?? "none"}`
    );
    await logAudit({
      actorType: options.actor.actorType,
      actorId: options.actor.actorId,
      actorName: options.actor.actorName,
      action: "instance.import",
      targetLabel: orgNameOf(sections.instance.org) || sections.instance.systemId,
      meta: {
        outcome: "verify-failed",
        fileChecksum: meta.checksum.slice(0, 16),
        counts: `${records}/${customers}/${orders}/${team}/${reviews}/${coupons}`,
      },
    });
    return { ok: false, reason: "verify" };
  }

  /* ---- audit row: the import event (the restore engine already logged
     its own instance.restore row with the data digests) ---- */
  await logAudit({
    actorType: options.actor.actorType,
    actorId: options.actor.actorId,
    actorName: options.actor.actorName,
    action: "instance.import",
    targetLabel: orgNameOf(sections.instance.org) || sections.instance.systemId,
    meta: {
      outcome: "imported",
      fileChecksum: meta.checksum.slice(0, 16),
      restored: String(restore.restored),
      imagesRestored: String(restore.imagesRestored),
      imagesMissing: String(restore.imagesMissing),
      backupVersion: String(meta.version),
      bootstrapOwner: maskEmail(boot.email),
    },
  });

  return {
    ok: true,
    instanceId,
    restored: restore.restored,
    imagesRestored: restore.imagesRestored,
    imagesMissing: restore.imagesMissing,
    bootstrapEmail: boot.email,
    backupChecksum: meta.checksum,
  };
}
