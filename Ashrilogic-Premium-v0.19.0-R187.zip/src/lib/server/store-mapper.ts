import { db } from "@/lib/db";
import type { Instance, ModuleRecord } from "@prisma/client";
import type { SiteProductDTO, SiteRatingSummaryDTO, StoreInfoDTO } from "@/lib/types";
import { isValidMinorUnits, parsePriceCellToMinor, toDisplayUnits, toMinorUnits } from "@/lib/server/money";
import { isManagedImageRef } from "@/lib/server/image-store";
import {
  readStoredGalleryExtras,
  readStoredVideos,
} from "@/lib/server/record-media";
import { readStoredVariants, type ProductVariant } from "@/lib/server/record-variants";
import { STORE_MODULE_PRIORITY } from "@/lib/store-modules";

/**
 * Ashrilogic — storefront catalog derivation (round 36).
 *
 * The public site's e-commerce "products" are derived LIVE from the
 * workspace's inventory-ish module records (ModuleRecord rows aligned with
 * the module preset's column layout — see src/lib/module-data.ts). The
 * module priority picks the most retail-shaped module the instance actually
 * has enabled:
 *
 *   pharmacy → inventory → products → menu
 *
 * Column mapping is per-module (name / category / stock / price indexes)
 * with defensive parsing — a record with a malformed price or qty degrades
 * gracefully (price 0 / stock 0) instead of breaking the storefront.
 */

/** ROUND 141 — the catalog module priority now lives in the PURE
 * src/lib/store-modules.ts (client + server share the one list); the
 * client mirrors it to decide which module workspace shows the premium
 * product extras (media switch + variants). */

/** per-module column indexes { name, category, stock, price } */
const STORE_COLUMNS: Record<string, { name: number; category: number; stock: number; price: number }> = {
  pharmacy: { name: 0, category: 1, stock: 4, price: 5 },
  inventory: { name: 0, category: 2, stock: 3, price: 4 },
  products: { name: 0, category: 2, stock: 3, price: 4 },
  /* ROUND 66 — menu preset layout is [item, category, price, stock,
   * rating, status]; the previous {category:2, stock:3, price:4} mapping
   * read the PRICE cell as the category, the ORDERS cell as stock and the
   * RATING cell as the price (a latent bug — restaurant storefronts never
   * actually used the menu module until this round). */
  menu: { name: 0, category: 1, stock: 3, price: 2 },
};

/** Column layout for a storefront module (defensive fallback included). */
export function storeColumnsFor(moduleId: string): { name: number; category: number; stock: number; price: number } {
  return STORE_COLUMNS[moduleId] ?? { name: 0, category: 2, stock: 3, price: 4 };
}

/** Parse a module record's cell values (defensive — malformed JSON degrades to []). */
export function parseRecordValues(dataJson: string | null | undefined): string[] {
  try {
    const parsed = JSON.parse(dataJson ?? "[]") as unknown;
    if (Array.isArray(parsed)) return parsed.map((v) => (typeof v === "string" ? v : ""));
  } catch {
    /* malformed row — empty values */
  }
  return [];
}

/** statuses that make an item unsellable. ROUND 66 — "soldout" added: a
 * menu row marked sold-out must disappear from the public storefront the
 * same way "out"/"expired" inventory rows already do (before, a sold-out
 * dish stayed purchasable whenever its stock cell was > 0). */
const BLOCKED_STATUS_KEYS = new Set(["out", "expired", "soldout"]);

/**
 * ROUND 53 (window-bound sales) — is the sale WINDOW still open?
 * `saleEndsAt == null` means "runs until manually cleared" (always open);
 * otherwise the sale is active only strictly BEFORE the end timestamp.
 * Pure on (end, now) so tests can pin both sides deterministically.
 */
export function saleWindowOpen(saleEndsAt: Date | null, now: Date = new Date()): boolean {
  return saleEndsAt == null || now.getTime() < saleEndsAt.getTime();
}

/** Max catalog size served to the public storefront. */
export const STORE_CATALOG_CAP = 200;

function parseNumber(raw: string | undefined): number {
  if (raw == null) return 0;
  const n = Number(String(raw).replace(/[^\d.-]/g, ""));
  return Number.isFinite(n) && n >= 0 ? n : 0;
}

function readModules(row: Pick<Instance, "modulesJson">): string[] {
  try {
    const parsed = JSON.parse(row.modulesJson ?? "[]") as unknown;
    return Array.isArray(parsed) ? parsed.filter((m): m is string => typeof m === "string") : [];
  } catch {
    return [];
  }
}

function readCurrency(row: Pick<Instance, "orgJson">): string {
  try {
    const org = JSON.parse(row.orgJson ?? "{}") as { currency?: unknown };
    return typeof org.currency === "string" && org.currency.trim() ? org.currency.trim() : "SAR";
  } catch {
    return "SAR";
  }
}

/** Which catalog module does this instance's storefront use (null = none). */
export function storeModuleId(row: Pick<Instance, "modulesJson">): string | null {
  const modules = readModules(row);
  for (const candidate of STORE_MODULE_PRIORITY) {
    if (modules.includes(candidate)) return candidate;
  }
  return null;
}

/** Storefront metadata for the public site (availability + currency). */
export function storeInfo(row: Pick<Instance, "orgJson" | "modulesJson">): StoreInfoDTO {
  return {
    available: storeModuleId(row) !== null,
    moduleId: storeModuleId(row),
    currency: readCurrency(row),
  };
}

/** Map one module record to a purchasable product (defensive parsing). */
export function toSiteProduct(moduleId: string, record: ModuleRecord): SiteProductDTO {
  const cols = storeColumnsFor(moduleId);
  const values = parseRecordValues(record.dataJson);
  const at = (i: number) => (i < values.length ? values[i] : "");
  /* the regular price is derived ONCE in minor units (the authoritative
   * form) and converted for display — the sale check below compares against
   * the SAME value the placement route charges (no float-drift window). */
  const regularMinor = parsePriceCellToMinor(at(cols.price));
  const regular = toDisplayUnits(regularMinor);
  /* ROUND 52 — the sale price only applies while it is a positive integer
   * minor-unit amount STRICTLY below the regular price (a stale/equal/zero
   * value degrades to "no sale" — the merchant's data can never raise a
   * price or free an item through the sale column).
   * ROUND 53 — the verdict now ALSO requires the sale window to be open
   * (saleEndsAt unset = open-ended); an expired window degrades silently to
   * the regular price — identical on the storefront, the cart AND placement
   * (all three read this same derivation). */
  const saleMinor = record.salePrice;
  const saleApplies =
    saleMinor != null &&
    isValidMinorUnits(saleMinor) &&
    saleMinor > 0 &&
    saleMinor < regularMinor &&
    saleWindowOpen(record.saleEndsAt ?? null);
  return {
    recordId: record.id,
    name: at(cols.name).trim(),
    category: at(cols.category).trim(),
    price: regular,
    stock: Math.floor(parseNumber(at(cols.stock))),
    statusKey: record.statusKey ?? "",
    /* ROUND 51 — the merchant's product photo (managed ref or null). */
    imageRef: record.imageRef ?? null,
    /* ROUND 140 — the FULL ordered photo gallery (cover first): the cover
     * + the stored galleryJson extras, shape-guarded and capped at 6 —
     * the storefront carousel renders exactly this order. */
    gallery: [
      ...(isManagedImageRef(record.imageRef ?? "") ? [record.imageRef as string] : []),
      ...readStoredGalleryExtras(record.galleryJson).slice(0, 5),
    ],
    /* ROUND 140 — the product's video clips (managed /api/videos refs,
     * shape-guarded, capped at 2). */
    videos: readStoredVideos(record.videosJson).slice(0, 2),
    /* ROUND 141 — the product's variant rows (متغيرات), fail-soft read of
     * the stored variantsJson (shape-guarded + capped at 20). */
    variants: readStoredVariants(record.variantsJson),
    /* ROUND 140 — the merchant's storefront visibility checkmark (the
     * owner console reads the real flag; public payloads only ever carry
     * visible rows — loadStoreProducts filters them out first). */
    storeVisible: record.storeVisible !== false,
    /* ROUND 52 — merchandising flags. */
    featured: record.featured === true,
    salePrice: saleApplies ? toDisplayUnits(saleMinor) : null,
    /* ROUND 53 — the ACTIVE sale's end timestamp (ISO) — only exposed while
     * the whole sale applies, so the storefront countdown chip can never
     * advertise a window the charge logic no longer honors. */
    saleEndsAt: saleApplies ? (record.saleEndsAt?.toISOString() ?? null) : null,
    /* ROUND 63 — rating aggregates default to "no reviews" here: this is a
     * PURE mapper (no DB); attachRatingAggregates() fills them in-place for
     * payloads that carry ratings. */
    ratingAvg: null,
    ratingCount: 0,
  };
}

/**
 * ROUND 52 — the price an order line is CHARGED (integer minor units):
 * the active sale price when it applies, else the regular price parsed from
 * the record's money cell. Used by the storefront placement route so the
 * guest can never over- or under-pay relative to what the storefront shows.
 */
export function effectivePriceMinor(record: ModuleRecord, moduleId: string): number {
  const cols = storeColumnsFor(moduleId);
  const values = parseRecordValues(record.dataJson);
  const regular = parsePriceCellToMinor(values[cols.price] ?? "");
  const saleMinor = record.salePrice;
  if (
    saleMinor != null &&
    isValidMinorUnits(saleMinor) &&
    saleMinor > 0 &&
    saleMinor < regular &&
    saleWindowOpen(record.saleEndsAt ?? null)
  ) {
    return saleMinor;
  }
  return regular;
}

/**
 * ROUND 141 — the price a VARIANT order line is CHARGED (integer minor
 * units): the variant's own price override when it carries one, else the
 * record's effective price (sale-aware — a variant WITHOUT its own price
 * inherits the active sale). Pure derivation, shared by the storefront
 * quick view mirror and the placement route (the server stays the
 * authority: the client's variant copy is never trusted).
 */
export function effectiveVariantPriceMinor(
  record: ModuleRecord,
  moduleId: string,
  variant: ProductVariant | null
): number {
  if (!variant || variant.price == null) return effectivePriceMinor(record, moduleId);
  return toMinorUnits(Math.max(0, variant.price));
}

/**
 * ROUND 141 — the stock a VARIANT order line may draw on: the variant's
 * own carve-out when it carries one, else the record's stock cell.
 */
export function effectiveVariantStock(
  record: ModuleRecord,
  moduleId: string,
  variant: ProductVariant | null
): number {
  const cols = storeColumnsFor(moduleId);
  const values = parseRecordValues(record.dataJson);
  const recordStock = Math.floor(parseNumber(values[cols.stock] ?? ""));
  if (!variant || variant.stock == null) return recordStock;
  return Math.min(recordStock, Math.max(0, Math.floor(variant.stock)));
}

/** Featured products sort first (stable — the DB's createdAt desc order is
 *  preserved inside each group). */
function featuredFirst(products: SiteProductDTO[]): SiteProductDTO[] {
  return [...products].sort((a, b) => Number(b.featured) - Number(a.featured));
}

/**
 * Load the storefront catalog for an instance: the enabled catalog module's
 * records mapped to products, sellable-only (stock > 0, status not
 * out/expired, has a name), capped at STORE_CATALOG_CAP.
 */
export async function loadStoreProducts(
  instance: Pick<Instance, "id" | "modulesJson">
): Promise<SiteProductDTO[]> {
  const moduleId = storeModuleId(instance);
  if (!moduleId) return [];
  /* ROUND 87 — trashed (soft-deleted) products never reach the public
   * storefront catalog.
   * ROUND 140 — HIDDEN products (the merchant's storeVisible checkmark =
   * FALSE) never reach the public catalog either: the product AND its
   * media disappear from the storefront while staying fully manageable
   * in the workspace. */
  const records = await db.moduleRecord.findMany({
    where: { instanceId: instance.id, moduleId, deletedAt: null, storeVisible: true },
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    take: 400,
  });
  return featuredFirst(
    records
      .map((record) => toSiteProduct(moduleId, record))
      .filter(
        (p) =>
          p.name.length > 0 &&
          p.stock > 0 &&
          p.price > 0 &&
          !BLOCKED_STATUS_KEYS.has(p.statusKey)
      )
      .slice(0, STORE_CATALOG_CAP)
  );
}

/** Max catalog rows served to the OWNER's E-Store products console. */
export const OWNER_CATALOG_CAP = 120;

/**
 * ROUND 51 — owner-scoped catalog load for the E-Store products console.
 * Unlike loadStoreProducts this does NOT filter to sellable rows: the
 * merchant manages photos on out-of-stock / blocked items too. Named rows
 * only (a nameless row is workspace noise, not a product), newest first,
 * capped at OWNER_CATALOG_CAP.
 */
export async function loadStoreProductsForOwner(
  instance: Pick<Instance, "id" | "modulesJson">
): Promise<SiteProductDTO[]> {
  const moduleId = storeModuleId(instance);
  if (!moduleId) return [];
  /* ROUND 87 — trashed (soft-deleted) products never reach the owner's
   * E-Store products console either. */
  const records = await db.moduleRecord.findMany({
    where: { instanceId: instance.id, moduleId, deletedAt: null },
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    take: 400,
  });
  return featuredFirst(
    records
      .map((record) => toSiteProduct(moduleId, record))
      .filter((p) => p.name.length > 0 && p.price > 0)
      .slice(0, OWNER_CATALOG_CAP)
  );
}

/* ------------------ ROUND 63 — product reviews & ratings ------------------ */

/**
 * ROUND 63 — fill each product's `ratingAvg` / `ratingCount` from the
 * store's VISIBLE reviews (hidden rows count nowhere the public sees).
 *
 * ONE batched groupBy covers the whole catalog (regardless of product
 * count); products with no review row keep the mapper's "no reviews"
 * defaults. Mutates the passed array's objects IN PLACE and returns the
 * same array — call it right after loadStoreProducts /
 * loadStoreProductsForOwner, before the payload ships.
 *
 * Fail-soft by design: any reviews hiccup (DB error, un-migrated dev copy)
 * leaves the defaults in place — the storefront must never break because
 * ratings could not be attached.
 */
export async function attachRatingAggregates(
  products: SiteProductDTO[],
  instanceId: string
): Promise<SiteProductDTO[]> {
  const ids = products.map((p) => p.recordId);
  if (ids.length === 0) return products;
  try {
    const rows = await db.siteReview.groupBy({
      by: ["recordId"],
      where: { instanceId, recordId: { in: ids }, hidden: false, deletedAt: null },
      _avg: { rating: true },
      _count: { _all: true },
    });
    const byRecord = new Map(rows.map((row) => [row.recordId, row]));
    for (const product of products) {
      const row = byRecord.get(product.recordId);
      if (!row) continue; // no visible review — keep the defaults
      product.ratingCount = row._count._all;
      product.ratingAvg =
        row._avg.rating != null ? Math.round(row._avg.rating * 10) / 10 : null;
    }
  } catch (error) {
    console.error(`attachRatingAggregates(${instanceId}) failed:`, error);
  }
  return products;
}

/**
 * ROUND 63 — the FULL visible-only rating summary for one product: the
 * exact per-star histogram (drives the storefront's distribution bars —
 * `dist[0]` = 5★ … `dist[4]` = 1★), the count and the mean to one decimal.
 * Fail-soft to the zero summary.
 */
export async function loadRatingSummary(
  instanceId: string,
  recordId: string
): Promise<SiteRatingSummaryDTO> {
  const empty: SiteRatingSummaryDTO = { avg: null, count: 0, dist: [0, 0, 0, 0, 0] };
  try {
    const rows = await db.siteReview.groupBy({
      by: ["rating"],
      where: { instanceId, recordId, hidden: false, deletedAt: null },
      _count: { _all: true },
    });
    const dist: [number, number, number, number, number] = [0, 0, 0, 0, 0];
    let count = 0;
    let weighted = 0;
    for (const row of rows) {
      const stars = row.rating;
      if (stars < 1 || stars > 5) continue; // legacy/hostile row — uncounted
      const n = row._count._all;
      dist[5 - stars] += n;
      count += n;
      weighted += stars * n;
    }
    if (count === 0) return empty;
    return { avg: Math.round((weighted / count) * 10) / 10, count, dist };
  } catch (error) {
    console.error(`loadRatingSummary(${instanceId}, ${recordId}) failed:`, error);
    return empty;
  }
}

/**
 * ROUND 63 — resolve ModuleRecord ids to the storefront display names for
 * the owner reviews console. Deleted / missing / nameless records map to
 * "" (the UI renders "—") — a review whose product vanished from the
 * workspace still lists instead of breaking the console. Never throws.
 */
export async function resolveRecordNames(
  instanceId: string,
  recordIds: string[]
): Promise<Map<string, string>> {
  const names = new Map<string, string>();
  if (recordIds.length === 0) return names;
  try {
    const records = await db.moduleRecord.findMany({
      where: { instanceId, id: { in: recordIds }, deletedAt: null },
      select: { id: true, moduleId: true, dataJson: true },
    });
    for (const record of records) {
      const cols = storeColumnsFor(record.moduleId);
      const name = parseRecordValues(record.dataJson)[cols.name]?.trim() ?? "";
      names.set(record.id, name);
    }
  } catch (error) {
    console.error(`resolveRecordNames(${instanceId}) failed:`, error);
  }
  return names;
}
