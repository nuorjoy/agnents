/**
 * Ashrilogic — MAIL OUTBOX SWEEPER (ROUND 120).
 *
 * The durability net for the outbox inversion (service.ts): sendMail now
 * persists a PENDING EmailLog row (with the full envelope) BEFORE
 * delivery. A process crash between the row write and the outcome settle
 * previously meant the mail was LOST with no re-drivable record; this
 * sweep re-drives those rows:
 *
 *   - PENDING rows past the crash window (2 min — a healthy inline send
 *     settles in seconds) are re-delivered and settled;
 *   - a row with an idempotencyKey whose twin already SUCCEEDED is
 *     settled as skipped (the unique key arbitrates);
 *   - bounded batch, one attempt per sweep per row (a row that keeps
 *     failing accumulates attempts; after MAX_SWEEP_ATTEMPTS it settles
 *     as failed — the dead-letter state — visible in the admin mail
 *     trail);
 *   - rows WITHOUT bodyJson (pre-ROUND-120 / legacy inline writes) are
 *     untouched: there is nothing to re-drive.
 *
 * Under a SchedulerLease (multi-instance safe), fail-closed on
 * lease-store outage (external side effect — a skipped tick self-heals,
 * an ungated double-send does not).
 */

import { db } from "@/lib/db";
import { withJobLease } from "@/lib/server/job-lease";
import { opLog } from "@/lib/server/oplog";

/** sweep cadence */
const TICK_MS = 60 * 1000;
/** lease TTL < tick */
const LEASE_TTL_MS = 50 * 1000;
/** pending rows younger than this are the inline send's window */
const CRASH_WINDOW_MS = 2 * 60 * 1000;
/** bounded batch per pass */
const BATCH = 20;
/** total attempts (inline + sweeps) before the dead-letter settle */
const MAX_TOTAL_ATTEMPTS = 5;

interface SweptMail {
  to: string;
  subject: string;
  text: string;
  html?: string;
  type?: string;
  instanceId?: string;
  /* ROUND 137 — the original row's STABLE Message-ID: the re-drive sends
   * the SAME id so receivers can collapse duplicate deliveries. */
  messageId?: string;
}

export interface MailSweepOutcome {
  scanned: number;
  redriven: number;
  settled: number;
  deadLettered: number;
}

/** One sweep pass. Returns counts (never throws — best-effort contract). */
export async function sweepMailOutbox(now = new Date()): Promise<MailSweepOutcome> {
  const outcome: MailSweepOutcome = {
    scanned: 0,
    redriven: 0,
    settled: 0,
    deadLettered: 0,
  };
  try {
    /* ROUND 165 — campaign rows are the campaign dispatcher's exclusive
     * domain (enqueue + in-place delivery + completion): excluding them
     * here removes the double-driver race (both drivers picking the same
     * pending row) while keeping every crash-recovery guarantee — the
     * dispatcher scans its pending rows on every tick with no age window. */
    const due = await db.emailLog.findMany({
      where: {
        status: "pending",
        bodyJson: { not: null },
        type: { not: "campaign" },
        createdAt: { lt: new Date(now.getTime() - CRASH_WINDOW_MS) },
      },
      orderBy: { createdAt: "asc" },
      take: BATCH,
      select: { id: true, bodyJson: true, attempts: true, idempotencyKey: true },
    });
    outcome.scanned = due.length;

    const { sendMail } = await import("./service");
    for (const row of due) {
      let mail: SweptMail | null = null;
      try {
        mail = JSON.parse(row.bodyJson ?? "") as SweptMail;
      } catch {
        /* corrupt envelope — settle as failed (dead-letter) */
        await settleFailed(row.id, "corrupt outbox envelope");
        outcome.deadLettered += 1;
        continue;
      }
      if (!mail?.to || !mail?.subject || !mail?.text) {
        await settleFailed(row.id, "incomplete outbox envelope");
        outcome.deadLettered += 1;
        continue;
      }

      /* the idempotency arbitration: a twin that SUCCEEDED means this
       * pending row is a crash leftover of an already-delivered mail */
      if (row.idempotencyKey) {
        try {
          const twin = await db.emailLog.findFirst({
            where: {
              idempotencyKey: row.idempotencyKey,
              status: { in: ["sent", "skipped"] },
              id: { not: row.id },
            },
            select: { id: true },
          });
          if (twin) {
            await db.emailLog.update({
              where: { id: row.id },
              data: { status: "skipped", bodyJson: null, failedAt: new Date() },
            });
            outcome.settled += 1;
            continue;
          }
        } catch {
          /* best-effort arbitration — fall through to the re-drive */
        }
      }

      /* attempts accounting: the row's inline attempt + this sweep's */
      const totalAttempts = (row.attempts ?? 0) + 1;
      if (totalAttempts >= MAX_TOTAL_ATTEMPTS) {
        await settleFailed(row.id, "exhausted after max attempts (dead-letter)");
        outcome.deadLettered += 1;
        continue;
      }

      const ok = await sendMail(
        {
          to: mail.to,
          subject: mail.subject,
          text: mail.text,
          ...(mail.html ? { html: mail.html } : {}),
        },
        {
          ...(mail.type ? { type: mail.type as never } : {}),
          ...(mail.instanceId ? { instanceId: mail.instanceId } : {}),
          /* NOTE: the idempotency key is NOT re-passed — the pending row
           * itself is the record being settled; passing it would make
           * sendMail's gate skip the re-drive */
          ...(mail.messageId ? { stableMessageId: mail.messageId } : {}),
        }
      );
      if (ok) {
        /* the re-drive opened its OWN settled row — this pending row is
         * now redundant: settle it as skipped (dedupe of the same mail) */
        await db.emailLog.update({
          where: { id: row.id },
          data: { status: "skipped", bodyJson: null, failedAt: new Date() },
        });
        outcome.redriven += 1;
      } else {
        /* the re-drive failed and settled its own row; keep the pending
         * row for the next sweep with its attempts incremented */
        await db.emailLog.update({
          where: { id: row.id },
          data: { attempts: totalAttempts },
        });
        outcome.settled += 1;
      }
    }

    if (outcome.scanned > 0) {
      opLog.info("mail.outbox-sweep", {
        result: `scanned ${outcome.scanned} · redriven ${outcome.redriven} · settled ${outcome.settled} · dead-lettered ${outcome.deadLettered}`,
      });
    }
  } catch (error) {
    opLog.warn("mail.outbox-sweep-error", {
      result: error instanceof Error ? error.message.slice(0, 80) : "unknown",
    });
  }
  return outcome;
}

async function settleFailed(rowId: string, reason: string): Promise<void> {
  try {
    await db.emailLog.update({
      where: { id: rowId },
      data: {
        status: "failed",
        error: reason.slice(0, 200),
        failedAt: new Date(),
        bodyJson: null,
      },
    });
  } catch {
    /* best-effort — the next sweep retries */
  }
}

const FLAG = "__ashrilogicMailOutboxSweeper" as const;

interface SweeperState {
  timer: ReturnType<typeof setInterval> | null;
}

function state(): SweeperState {
  const g = globalThis as Record<string, unknown>;
  const existing = g[FLAG] as SweeperState | undefined;
  if (existing) return existing;
  const fresh: SweeperState = { timer: null };
  g[FLAG] = fresh;
  return fresh;
}

/** Register the standing sweeper (idempotent across dev reloads). */
export function startMailOutboxSweeper(): void {
  const s = state();
  if (s.timer != null) return;
  /* first pass soon after boot — crash leftovers from the previous
   * process lifetime are picked up immediately */
  setTimeout(() => void sweepMailOutbox().catch(() => {}), 30_000).unref?.();
  s.timer = setInterval(() => {
    void (async () => {
      await withJobLease(
        "mail-outbox-sweep",
        LEASE_TTL_MS,
        async () => {
          await sweepMailOutbox();
        },
        { failure: "skip" }
      );
    })().catch(() => {});
  }, TICK_MS);
  s.timer.unref?.();
}
