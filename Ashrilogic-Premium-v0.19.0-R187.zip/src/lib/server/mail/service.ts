import { randomUUID } from "node:crypto";
import { db } from "@/lib/db";
import { resolveMailRuntime, type ResolvedMailRuntime } from "./settings";
import { createSmtpProvider } from "./providers/smtp";
import { createSpoolProvider } from "./providers/spool";
import type { MailEnvelope, MailErrorClass, MailProvider } from "./providers/types";
import { scrubMailError } from "./providers/types";

/**
 * AshriLogic — EMAIL SYSTEM — the unified MAIL SERVICE.
 *
 * The ONE sending primitive for every platform mail surface. Callers
 * (routes, domain modules) never touch a transport directly:
 *
 *   Application / Routes
 *        ↓
 *   Domain senders (verification.ts, platform-notifications.ts, notify.ts)
 *        ↓
 *   THIS SERVICE — retry · backoff · timeout · logging · idempotency
 *        ↓
 *   Provider adapter (smtp | spool | future: resend, ses…)
 *
 * Reliability posture (production-grade, queue-ready, no added infra):
 *  - RETRY with exponential backoff on TRANSIENT classes only
 *    (connection/timeout/unknown): 3 attempts max, 400ms·4ⁿ backoff.
 *    Permanent classes (auth / rejected) fail fast — retrying a bad
 *    password only locks accounts.
 *  - TIMEOUT bounded by the resolved runtime (socket/connection/greeting).
 *  - IDEMPOTENCY: an optional `idempotencyKey` makes a send exactly-once
 *    (unique EmailLog row) — the natural unit of work for a future queue.
 *  - DELIVERY LOG: every envelope lands in EmailLog with its transport
 *    outcome, attempts, error class and provider message id.
 *  - SECRETS: error strings are scrubbed twice (adapter + here) —
 *    credentials never reach storage or logs.
 *
 * DELIVERY SEMANTICS (ROUND 137 — stated honestly): AT-LEAST-ONCE.
 * A unique DB row is NOT external exactly-once: a crash after the SMTP
 * server accepted the DATA terminator but before the settle leaves a
 * re-drivable PENDING row, and the sweeper's re-drive (or a concurrent
 * sender that lost the idempotency race) may produce a SECOND copy of
 * the SAME message. The mitigation is a STABLE Message-ID: every outbox
 * row mints one, every attempt (inline + swept re-drives) sends the SAME
 * id, so receivers with duplicate delivery can collapse the copies by
 * Message-ID — application-level idempotency on the RECEIVING side.
 * Providers that mint their own ids (a provider ACK'd id is still
 * recorded when different) keep working unchanged.
 */

/** Every mail type the platform can send (EmailLog.type union). */
export type MailType =
  | "verification"
  | "passwordReset"
  | "welcome"
  | "securityAlert"
  | "subscription"
  | "orderStatus"
  | "campaign"
  | "platformEvent"
  | "weeklyDigest"
  | "test"
  | "system";

/** The outgoing message shape (compat with the former mailer.ts API). */
export interface OutgoingMail {
  to: string;
  subject: string;
  text: string;
  html?: string;
}

/** Per-send options (type tagging, tenant context, idempotency). */
export interface SendMailOptions {
  type?: MailType;
  instanceId?: string;
  idempotencyKey?: string;
  /** ROUND 137 — reuse a prior outbox row's Message-ID (the sweeper's
   *  re-drive keeps the ORIGINAL id so receivers can deduplicate the
   *  at-least-once stream). Ignored when absent — a fresh id is minted. */
  stableMessageId?: string;
}

/** ROUND 137 — mint the stable outbox Message-ID: globally unique
 *  (uuid), domain-qualified from the sender identity when parseable
 *  (RFC 5322 msg-id), with the RFC-2606-reserved fallback domain. */
function mintMessageId(from: string): string {
  const domain = /@([\w.-]+)\s*>?\s*$/.exec(from)?.[1] ?? "ashrilogic.invalid";
  return `<ashrilogic-${randomUUID()}@${domain}>`;
}

/** Bulk dispatch outcome (compat with the former mailer.ts API). */
export interface MailDispatchResult {
  accepted: number;
  rejected: number;
  /** first error encountered (surfaces in admin UI / logs) */
  error?: string;
}

/* ------------------------------------------------------------------ */
/* retry policy                                                        */
/* ------------------------------------------------------------------ */

const MAX_ATTEMPTS = 3;
const BACKOFF_BASE_MS = 400;
const BACKOFF_FACTOR = 4;

function isTransient(errorClass: MailErrorClass | undefined): boolean {
  return errorClass === "connection" || errorClass === "timeout" || errorClass === "unknown";
}

function backoffDelayMs(attempt: number): number {
  return BACKOFF_BASE_MS * Math.pow(BACKOFF_FACTOR, attempt - 1);
}

const sleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

/* ------------------------------------------------------------------ */
/* provider resolution                                                 */
/* ------------------------------------------------------------------ */

function providerFor(runtime: ResolvedMailRuntime): MailProvider {
  if (runtime.providerName === "smtp") return createSmtpProvider(runtime);
  return createSpoolProvider({ from: runtime.from, replyTo: runtime.replyTo });
}

/* ------------------------------------------------------------------ */
/* the delivery core (one envelope → attempts → EmailLog row)          */
/* ------------------------------------------------------------------ */

interface DeliveryOutcome {
  ok: boolean;
  status: "sent" | "failed";
  messageId?: string;
  error?: string;
  errorClass?: MailErrorClass;
  attempts: number;
}

async function deliverWithRetry(
  runtime: ResolvedMailRuntime,
  envelope: MailEnvelope
): Promise<DeliveryOutcome> {
  const provider = providerFor(runtime);
  let attempts = 0;
  let last: { error?: string; errorClass?: MailErrorClass } = {};

  for (;;) {
    attempts += 1;
    const result = await provider.send(envelope);
    if (result.ok) {
      return {
        ok: true,
        status: "sent",
        messageId: result.messageId,
        attempts,
      };
    }
    last = { error: result.error, errorClass: result.errorClass };
    if (attempts >= MAX_ATTEMPTS || !isTransient(result.errorClass)) {
      return { ok: false, status: "failed", ...last, attempts };
    }
    await sleep(backoffDelayMs(attempts));
  }
}

/** Persist the transport-level truth for one envelope (never throws). */
async function writeEmailLog(params: {
  type: MailType;
  runtime: ResolvedMailRuntime;
  envelope: MailEnvelope;
  outcome: DeliveryOutcome;
  instanceId?: string;
  idempotencyKey?: string;
}): Promise<void> {
  const { type, runtime, envelope, outcome, instanceId, idempotencyKey } = params;
  const now = new Date();
  try {
    await db.emailLog.create({
      data: {
        type,
        recipient: envelope.to.slice(0, 320),
        subject: envelope.subject.slice(0, 500),
        provider: runtime.providerName,
        status: outcome.status,
        ...(outcome.messageId ? { messageId: outcome.messageId } : {}),
        attempts: outcome.attempts,
        ...(outcome.error ? { error: scrubMailError(outcome.error) } : {}),
        ...(outcome.errorClass ? { errorClass: outcome.errorClass } : {}),
        ...(idempotencyKey ? { idempotencyKey } : {}),
        ...(instanceId ? { instanceId } : {}),
        ...(outcome.status === "sent"
          ? { sentAt: now, deliveredAt: now }
          : { failedAt: now }),
      },
    });
  } catch (error) {
    /* the delivery trail is best-effort — it must never break a send */
    if ((error as { code?: string }).code === "P2002") return; /* idempotent twin won the race */
    console.error("mail: EmailLog write failed:", error);
  }
}

/* ------------------------------------------------------------------ */
/* public API                                                          */
/* ------------------------------------------------------------------ */

/**
 * Send one message through the unified pipeline.
 * Resolves true when the transport accepted it (SMTP accepted OR spooled
 * to the outbox); false on final failure. Every outcome is logged.
 */
export async function sendMail(mail: OutgoingMail, options?: SendMailOptions): Promise<boolean> {
  const runtime = await resolveMailRuntime();
  /* ROUND 137 — the stable Message-ID: ONE id per logical message across
   * every attempt and every re-drive (the sweeper passes the original
   * row's id back through stableMessageId). */
  const messageId = options?.stableMessageId ?? mintMessageId(runtime.from);
  const envelope: MailEnvelope = {
    to: mail.to,
    subject: mail.subject,
    text: mail.text,
    ...(mail.html ? { html: mail.html } : {}),
    ...(runtime.replyTo ? { replyTo: runtime.replyTo } : {}),
    messageId,
  };

  /* idempotency gate — a previously SUCCESSFUL key never re-sends */
  if (options?.idempotencyKey) {
    try {
      const existing = await db.emailLog.findUnique({
        where: { idempotencyKey: options.idempotencyKey },
        select: { status: true },
      });
      if (existing?.status === "sent") return true;
    } catch {
      /* gate is best-effort — a lookup failure must not block the send */
    }
  }

  /* ROUND 120 — OUTBOX INVERSION: the PENDING row (with the full
   * envelope) lands BEFORE delivery — a crash between here and the
   * outcome write leaves a re-drivable row instead of a lost mail (the
   * mail sweeper picks up pending rows past the crash window). */
  const pendingRow = await openOutboxRow({
    type: options?.type ?? "system",
    runtime,
    envelope,
    ...(options?.instanceId ? { instanceId: options.instanceId } : {}),
    ...(options?.idempotencyKey ? { idempotencyKey: options.idempotencyKey } : {}),
  });
  const outcome = await deliverWithRetry(runtime, envelope);
  await settleOutboxRow(pendingRow, {
    type: options?.type ?? "system",
    runtime,
    envelope,
    outcome,
    ...(options?.instanceId ? { instanceId: options.instanceId } : {}),
    ...(options?.idempotencyKey ? { idempotencyKey: options.idempotencyKey } : {}),
  });
  if (!outcome.ok && outcome.error) {
    /* the recipient address is PII — the oplog contract forbids raw PII in
     * logs; the EmailLog row (masked trail) carries the full outcome */
    console.error(`mail: delivery failed (${outcome.errorClass ?? "unknown"}):`, outcome.error);
  }
  return outcome.ok;
}

/** ROUND 120 — persist the pending outbox row BEFORE delivery. Best-effort:
 *  a store hiccup degrades to the legacy write-after-send path (the mail
 *  still goes out; the sweeper simply has nothing to re-drive). */
async function openOutboxRow(params: {
  type: MailType;
  runtime: ResolvedMailRuntime;
  envelope: MailEnvelope;
  instanceId?: string;
  idempotencyKey?: string;
}): Promise<string | null> {
  const { type, runtime, envelope, instanceId, idempotencyKey } = params;
  try {
    const row = await db.emailLog.create({
      data: {
        type,
        recipient: envelope.to.slice(0, 320),
        subject: envelope.subject.slice(0, 500),
        provider: runtime.providerName,
        status: "pending",
        attempts: 0,
        bodyJson: JSON.stringify({
          to: envelope.to,
          subject: envelope.subject,
          text: envelope.text,
          ...(envelope.html ? { html: envelope.html } : {}),
          type,
          ...(instanceId ? { instanceId } : {}),
          /* ROUND 137 — rides the envelope so the sweeper's re-drive sends
           * the SAME Message-ID (receiver-side dedupe of duplicates) */
          messageId: envelope.messageId,
        }),
        ...(idempotencyKey ? { idempotencyKey } : {}),
        ...(instanceId ? { instanceId } : {}),
      },
      select: { id: true },
    });
    return row.id;
  } catch (error) {
    /* P2002: an idempotent twin already owns the key — do not double-send */
    if ((error as { code?: string }).code === "P2002") return "idempotent-twin";
    console.error("mail: outbox row open failed:", error);
    return null;
  }
}

/** ROUND 120 — settle the pending row with the delivery outcome (the
 *  legacy writeEmailLog path remains for rows opened without one). */
async function settleOutboxRow(
  rowId: string | null,
  params: Parameters<typeof writeEmailLog>[0]
): Promise<void> {
  if (rowId === "idempotent-twin") return; /* the twin owns the record */
  if (!rowId) {
    await writeEmailLog(params);
    return;
  }
  const { runtime, outcome } = params;
  const now = new Date();
  try {
    await db.emailLog.update({
      where: { id: rowId },
      data: {
        provider: runtime.providerName,
        status: outcome.status,
        attempts: outcome.attempts,
        ...(outcome.messageId ? { messageId: outcome.messageId } : {}),
        ...(outcome.error ? { error: scrubMailError(outcome.error) } : {}),
        ...(outcome.errorClass ? { errorClass: outcome.errorClass } : {}),
        ...(outcome.status === "sent"
          ? { sentAt: now, deliveredAt: now, bodyJson: null }
          : { failedAt: now }),
      },
    });
  } catch (error) {
    /* the pending row stays — the sweeper re-drives it */
    console.error("mail: outbox settle failed:", error);
  }
}

/**
 * Send one message to many recipients sequentially, bounded and awaitable —
 * sized for the platform's subscriber lists (the admin console caps and
 * paginates them). Returns per-recipient counts for the campaign trail.
 * The runtime (and therefore the pooled SMTP transport) resolves ONCE.
 */
export async function sendBulkMail(
  recipients: readonly string[],
  message: { subject: string; text: string; html?: string },
  options?: Omit<SendMailOptions, "idempotencyKey">
): Promise<MailDispatchResult> {
  const runtime = await resolveMailRuntime();
  const provider = providerFor(runtime);
  let accepted = 0;
  let rejected = 0;
  let error: string | undefined;

  for (const to of recipients) {
    const envelope: MailEnvelope = {
      to,
      subject: message.subject,
      text: message.text,
      ...(message.html ? { html: message.html } : {}),
      ...(runtime.replyTo ? { replyTo: runtime.replyTo } : {}),
    };

    let attempts = 0;
    let outcome: { ok: boolean; messageId?: string; error?: string; errorClass?: MailErrorClass } | null = null;
    for (;;) {
      attempts += 1;
      const result = await provider.send(envelope);
      if (result.ok) {
        outcome = { ok: true, messageId: result.messageId };
        break;
      }
      outcome = { ok: false, error: result.error, errorClass: result.errorClass };
      if (attempts >= MAX_ATTEMPTS || !isTransient(result.errorClass)) break;
      await sleep(backoffDelayMs(attempts));
    }

    await writeEmailLog({
      type: options?.type ?? "campaign",
      runtime,
      envelope,
      outcome: {
        ok: outcome.ok,
        status: outcome.ok ? "sent" : "failed",
        ...(outcome.messageId ? { messageId: outcome.messageId } : {}),
        ...(outcome.error ? { error: outcome.error } : {}),
        ...(outcome.errorClass ? { errorClass: outcome.errorClass } : {}),
        attempts,
      },
      ...(options?.instanceId ? { instanceId: options.instanceId } : {}),
    });

    if (outcome.ok) {
      accepted += 1;
    } else {
      rejected += 1;
      error ??= `delivery to ${to} failed`;
    }
  }
  return { accepted, rejected, ...(error ? { error } : {}) };
}

/* ------------------------------------------------------------------ */
/* ROUND 165 — durable bulk-dispatch primitives (campaign dispatcher)   */
/* ------------------------------------------------------------------ */

/** Outcome of driving one pending outbox row to a terminal state. */
export type PendingRowOutcome = "sent" | "failed" | "skipped" | "gone";

/**
 * ROUND 165 — enqueue WITHOUT delivery: persist the PENDING outbox row
 * (full envelope + stable Message-ID + optional idempotency key) and
 * return its id. The row is driven to a terminal state later by
 * deliverPendingOutboxRow — the separation bulk dispatch needs (enqueue
 * bounded batches cheaply; deliver in bounded batches with retries).
 *
 * Returns "idempotent-twin" when the unique key already owns a row (the
 * recipient was already enqueued — never double-enqueued), or null when
 * the row could not be opened (store hiccup — the caller retries next
 * tick; nothing is lost because nothing was delivered).
 */
export async function enqueueOutboxMail(
  mail: OutgoingMail,
  options?: SendMailOptions
): Promise<string | "idempotent-twin" | null> {
  const runtime = await resolveMailRuntime();
  const messageId = options?.stableMessageId ?? mintMessageId(runtime.from);
  const envelope: MailEnvelope = {
    to: mail.to,
    subject: mail.subject,
    text: mail.text,
    ...(mail.html ? { html: mail.html } : {}),
    ...(runtime.replyTo ? { replyTo: runtime.replyTo } : {}),
    messageId,
  };
  return openOutboxRow({
    type: options?.type ?? "system",
    runtime,
    envelope,
    ...(options?.instanceId ? { instanceId: options.instanceId } : {}),
    ...(options?.idempotencyKey ? { idempotencyKey: options.idempotencyKey } : {}),
  });
}

/**
 * ROUND 165 — drive ONE pending outbox row to a terminal state, in place
 * (the row written by enqueueOutboxMail). Idempotency-twin arbitration
 * runs first (a twin that already SUCCEEDED settles this row skipped);
 * then the same retry/backoff pipeline sendMail uses; then the SAME row
 * is settled (never a second row). Attempts accumulate on the row — the
 * caller's dead-letter policy decides when to stop retrying.
 *
 * "gone" = the row disappeared (concurrent driver settled it) — a benign
 * race the caller treats as terminal.
 */
export async function deliverPendingOutboxRow(rowId: string): Promise<PendingRowOutcome> {
  const row = await db.emailLog.findUnique({
    where: { id: rowId },
    select: { bodyJson: true, attempts: true, idempotencyKey: true, status: true },
  });
  if (!row || row.status !== "pending" || !row.bodyJson) return "gone";

  /* idempotency arbitration — a twin that SUCCEEDED means this pending
   * row is a leftover of an already-delivered mail (crash race) */
  if (row.idempotencyKey) {
    try {
      const twin = await db.emailLog.findFirst({
        where: {
          idempotencyKey: row.idempotencyKey,
          status: { in: ["sent", "skipped"] },
          id: { not: rowId },
        },
        select: { id: true },
      });
      if (twin) {
        await db.emailLog.update({
          where: { id: rowId },
          data: { status: "skipped", bodyJson: null, failedAt: new Date() },
        });
        return "skipped";
      }
    } catch {
      /* best-effort arbitration — fall through to the delivery */
    }
  }

  let mail: SweptMailShape | null = null;
  try {
    mail = JSON.parse(row.bodyJson) as SweptMailShape;
  } catch {
    await settlePendingFailed(rowId, "corrupt outbox envelope");
    return "failed";
  }
  if (!mail?.to || !mail?.subject || !mail?.text) {
    await settlePendingFailed(rowId, "incomplete outbox envelope");
    return "failed";
  }

  const runtime = await resolveMailRuntime();
  const envelope: MailEnvelope = {
    to: mail.to,
    subject: mail.subject,
    text: mail.text,
    ...(mail.html ? { html: mail.html } : {}),
    ...(runtime.replyTo ? { replyTo: runtime.replyTo } : {}),
    /* ROUND 137 — the ORIGINAL row's stable Message-ID rides every
     * attempt so receivers can collapse duplicate deliveries */
    messageId: mail.messageId ?? mintMessageId(runtime.from),
  };
  const outcome = await deliverWithRetry(runtime, envelope);
  const now = new Date();
  try {
    await db.emailLog.update({
      where: { id: rowId },
      data: {
        provider: runtime.providerName,
        status: outcome.status,
        attempts: (row.attempts ?? 0) + outcome.attempts,
        ...(outcome.messageId ? { messageId: outcome.messageId } : {}),
        ...(outcome.error ? { error: scrubMailError(outcome.error) } : {}),
        ...(outcome.errorClass ? { errorClass: outcome.errorClass } : {}),
        ...(outcome.status === "sent"
          ? { sentAt: now, deliveredAt: now, bodyJson: null }
          : { failedAt: now }),
      },
    });
  } catch {
    /* the settle lost a race with a concurrent driver — "gone"-equivalent;
     * the outcome is still truthful for accounting */
  }
  return outcome.status;
}

/** The outbox envelope shape persisted in bodyJson (mirrors the sweeper). */
interface SweptMailShape {
  to: string;
  subject: string;
  text: string;
  html?: string;
  type?: string;
  instanceId?: string;
  messageId?: string;
}

async function settlePendingFailed(rowId: string, reason: string): Promise<void> {
  try {
    await db.emailLog.update({
      where: { id: rowId },
      data: { status: "failed", error: reason.slice(0, 200), failedAt: new Date(), bodyJson: null },
    });
  } catch {
    /* best-effort — a concurrent driver settled it */
  }
}

/* ------------------------------------------------------------------ */
/* log retention                                                       */
/* ------------------------------------------------------------------ */

/**
 * Purge EmailLog rows older than the platform's data-retention window
 * (PlatformSetting.dataRetention days; 0 = keep forever). Called from the
 * weekly scheduler tick — delivery diagnostics are operational data, not
 * an eternal PII archive. Never throws.
 */
export async function purgeExpiredEmailLogs(): Promise<number> {
  try {
    const settings = await db.platformSetting.findUnique({
      where: { id: "global" },
      select: { dataRetention: true },
    });
    const days = settings?.dataRetention ?? 90;
    if (days <= 0) return 0;
    const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
    const result = await db.emailLog.deleteMany({ where: { createdAt: { lt: cutoff } } });
    return result.count;
  } catch (error) {
    console.error("mail: EmailLog purge failed:", error);
    return 0;
  }
}
