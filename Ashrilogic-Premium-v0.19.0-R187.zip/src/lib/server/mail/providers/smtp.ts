import { createHash } from "node:crypto";
import type {
  MailEnvelope,
  MailErrorClass,
  MailProvider,
  MailSendResult,
  MailVerifyResult,
} from "./types";
import { scrubMailError } from "./types";
import type { ResolvedMailRuntime } from "../settings";

/**
 * AshriLogic — EMAIL SYSTEM — the SMTP adapter (nodemailer).
 *
 * Two wire configurations, both already proven in this codebase:
 *  - DB config (console Settings → Communications → Email): explicit
 *    host/port/encryption/username + the AES-256-GCM-sealed password,
 *    decrypted in-memory per runtime resolution.
 *  - legacy env config: the raw SMTP_URL string ("smtps://user:pass@host:port")
 *    passed straight to nodemailer — the pre-existing deployment path,
 *    byte-for-byte preserved.
 *
 * Transport pooling: ONE cached nodemailer transport per configKey — a
 * settings change rotates the key, closes the old sockets and pools a fresh
 * transport. Timeouts come from the resolved runtime (socket + connection
 * + greeting), so a hung SMTP server can never pin a request forever.
 */

interface TransportLike {
  sendMail(options: {
    from: string;
    to: string;
    subject: string;
    text: string;
    html?: string;
    replyTo?: string;
    connectionTimeout?: number;
    greetingTimeout?: number;
    socketTimeout?: number;
  }): Promise<{ messageId?: string; rejected?: unknown[] }>;
  verify(): Promise<void>;
  close(): void;
}

/** the single pooled transport slot {configKey, transport} */
let pooled: { key: string; transport: TransportLike } | null = null;

async function buildTransport(runtime: ResolvedMailRuntime): Promise<TransportLike> {
  const nodemailer = await import("nodemailer");

  if (runtime.mode === "smtp-env") {
    /* legacy path — SMTP_URL carries everything (implicit TLS for smtps,
     * STARTTLS for smtp). The string overload's typing doesn't declare the
     * socket timeout knobs, but nodemailer merges them at runtime — cast
     * through unknown to keep strictness everywhere else. */
    const envDefaults = {
      connectionTimeout: runtime.timeoutMs,
      greetingTimeout: runtime.timeoutMs,
      socketTimeout: runtime.timeoutMs,
    } as unknown as Omit<import("nodemailer").SendMailOptions, "from">;
    return nodemailer.createTransport(process.env.SMTP_URL ?? "", envDefaults) as unknown as TransportLike;
  }

  /* DB path — explicit connection facts with the decrypted password */
  const smtp = runtime.smtp;
  if (!smtp) {
    /* unreachable by construction (callers only build smtp providers for
     * smtp runtimes) — fail loudly rather than send through a void config */
    throw new Error("smtp provider requires a resolved smtp runtime");
  }
  return nodemailer.createTransport({
    host: smtp.host,
    port: smtp.port,
    secure: smtp.secure,
    ...(smtp.requireTLS ? { requireTLS: true } : {}),
    ...(smtp.username !== null
      ? { auth: { user: smtp.username, ...(smtp.password !== null ? { pass: smtp.password } : {}) } }
      : {}),
    connectionTimeout: runtime.timeoutMs,
    greetingTimeout: runtime.timeoutMs,
    socketTimeout: runtime.timeoutMs,
  }) as unknown as TransportLike;
}

/** Pooled transport for the runtime's configKey (rotates on settings change). */
async function transportFor(runtime: ResolvedMailRuntime): Promise<TransportLike> {
  if (pooled && pooled.key === runtime.configKey) return pooled.transport;
  const fresh = await buildTransport(runtime);
  if (pooled) {
    try {
      pooled.transport.close();
    } catch {
      /* closing stale sockets is best-effort */
    }
  }
  pooled = { key: runtime.configKey, transport: fresh };
  return fresh;
}

/** Best-effort cache invalidation hook (called after settings writes). */
export function invalidateSmtpTransportCache(): void {
  if (pooled) {
    try {
      pooled.transport.close();
    } catch {
      /* best-effort */
    }
  }
  pooled = null;
}

/** Classify an SMTP failure — drives retry policy (transient vs permanent). */
export function classifySmtpError(error: unknown): MailErrorClass {
  const message = error instanceof Error ? error.message : String(error);
  const code = (error as { code?: string })?.code ?? "";
  if (/auth|credential|login|535|530|username|password/i.test(message) || code === "EAUTH") {
    return "auth";
  }
  if (code === "ETIMEDOUT" || /timed?\s?out/i.test(message)) return "timeout";
  if (
    code === "ECONNECTION" ||
    code === "ECONNREFUSED" ||
    code === "ECONNRESET" ||
    code === "EHOSTUNREACH" ||
    code === "ENOTFOUND" ||
    code === "EAI_AGAIN" ||
    code === "ESOCKET" ||
    /connect|dns|resolve|network|socket|getaddrinfo/i.test(message)
  ) {
    return "connection";
  }
  if (/recipient|address|rejected|spam|block|blacklist|550|551|553/i.test(message)) {
    return "rejected";
  }
  return "unknown";
}

function sanitizeHeader(value: string): string {
  return value.replace(/[\r\n\u0000-\u001f\u007f]/g, " ").trim();
}

/** The SMTP transport (one instance per resolved runtime). */
export function createSmtpProvider(runtime: ResolvedMailRuntime): MailProvider {
  return {
    name: "smtp",
    async send(envelope: MailEnvelope): Promise<MailSendResult> {
      try {
        const transport = await transportFor(runtime);
        const info = await transport.sendMail({
          from: runtime.from,
          to: envelope.to,
          ...(runtime.replyTo ? { replyTo: runtime.replyTo } : {}),
          ...(envelope.replyTo ? { replyTo: envelope.replyTo } : {}),
          subject: sanitizeHeader(envelope.subject),
          text: envelope.text,
          ...(envelope.html ? { html: envelope.html } : {}),
          /* ROUND 137 — the stable outbox Message-ID: nodemailer uses the
           * provided id instead of minting one, so re-drives of the same
           * logical message carry the SAME id (receiver-side dedupe). */
          ...(envelope.messageId ? { messageId: envelope.messageId } : {}),
          connectionTimeout: runtime.timeoutMs,
          greetingTimeout: runtime.timeoutMs,
          socketTimeout: runtime.timeoutMs,
        });
        return {
          ok: true,
          messageId: typeof info.messageId === "string" ? info.messageId.slice(0, 200) : undefined,
        };
      } catch (error) {
        return {
          ok: false,
          error: scrubMailError(error instanceof Error ? error.message : String(error)),
          errorClass: classifySmtpError(error),
        };
      }
    },
    async verify(): Promise<MailVerifyResult> {
      try {
        const transport = await transportFor(runtime);
        await transport.verify();
        return { ok: true, detail: "smtp" };
      } catch (error) {
        return {
          ok: false,
          detail: scrubMailError(error instanceof Error ? error.message : String(error)),
          errorClass: classifySmtpError(error),
        };
      }
    },
  };
}

/** Config fingerprint for tests / diagnostics (never includes the password). */
export function smtpConfigFingerprint(runtime: ResolvedMailRuntime): string {
  return createHash("sha256")
    .update(
      JSON.stringify({
        mode: runtime.mode,
        host: runtime.smtp?.host ?? null,
        port: runtime.smtp?.port ?? null,
        secure: runtime.smtp?.secure ?? null,
        requireTLS: runtime.smtp?.requireTLS ?? null,
        username: runtime.smtp?.username ?? null,
        hasPassword: runtime.smtp?.password !== null,
      })
    )
    .digest("hex")
    .slice(0, 16);
}
