import { randomBytes } from "node:crypto";
import type { MailEnvelope, MailProvider, MailSendResult, MailVerifyResult } from "./types";
import { objectStorage } from "@/lib/server/storage/object-store";

/**
 * AshriLogic — EMAIL SYSTEM — the DEV SPOOL adapter.
 *
 * Verbatim relocation of the former mailer.ts spool: when no SMTP path is
 * configured, every recipient produces a verifiable RFC-5322 `.eml` artifact
 * — the platform NEVER silently pretends a send happened. Delivery
 * logging/retry live in the service layer; this adapter only writes the
 * artifact and reports success.
 *
 * ROUND 123 — the artifacts are written through the OBJECT STORAGE ADAPTER
 * (the R122 lift completed for the outbox namespace): identical bytes,
 * identical `outbox/<stamp>_<recipient>.eml` key shape, identical physical
 * location under ASHRILOGIC_STORAGE_DIR (default <repo>/storage) on the
 * LOCAL driver — including the atomic tmp+rename landing discipline.
 * With ASHRILOGIC_STORAGE_DRIVER=s3 the artifacts land in the bucket under
 * the same keys (an operator lists/downloads them from the object store;
 * the app itself never reads them back).
 *
 * Behavioral note: the adapter's put is SKIP-IF-EXISTS (idempotent by
 * key), while the historical writeFileSync overwrote. Two different mails
 * for the same recipient inside the SAME millisecond would previously
 * keep the last artifact and now keep the first — a dev-only once-in-a-
 * lifetime shape (the stamp has millisecond resolution), documented here
 * rather than papered over with a mutation of the key shape.
 *
 * verify() upgraded to a REAL reachability proof that matches the active
 * driver: a tiny probe object is written and removed through the adapter
 * (local: an actual tmp+rename write into the outbox namespace; S3: a
 * signed PUT + DELETE round trip) — the transport is "up" only when the
 * active object store actually accepts writes.
 */

function sanitizeHeader(value: string): string {
  // strip CR/LF + control chars — header injection stays impossible even
  // when a subject (admin-authored) later carries odd characters
  return value.replace(/[\r\n\u0000-\u001f\u007f]/g, " ").trim();
}

/** RFC-5322 message for the dev spool (multipart/alternative when HTML). */
function renderEml(mail: MailEnvelope, from: string, replyTo: string | null): string {
  const boundary = `----=_ashrilogic_${Date.now().toString(36)}`;
  const headers = [
    `From: ${from}`,
    `To: ${mail.to}`,
    ...(replyTo ? [`Reply-To: ${replyTo}`] : []),
    /* ROUND 137 — the stable outbox Message-ID rides the spooled .eml so
     * the dev-spool artifact is dedupe-compatible with SMTP re-drives */
    ...(mail.messageId ? [`Message-ID: ${sanitizeHeader(mail.messageId)}`] : []),
    `Subject: ${sanitizeHeader(mail.subject)}`,
    `Date: ${new Date().toUTCString()}`,
    "MIME-Version: 1.0",
    mail.html
      ? `Content-Type: multipart/alternative; boundary="${boundary}"`
      : 'Content-Type: text/plain; charset="utf-8"',
  ];
  if (mail.html) {
    const body = [
      "--" + boundary,
      'Content-Type: text/plain; charset="utf-8"',
      "",
      mail.text,
      "--" + boundary,
      'Content-Type: text/html; charset="utf-8"',
      "",
      mail.html,
      "--" + boundary + "--",
      "",
    ].join("\r\n");
    return headers.join("\r\n") + "\r\n\r\n" + body;
  }
  return headers.join("\r\n") + "\r\n\r\n" + mail.text + "\r\n";
}

/** The dev-spool transport (one instance; the service passes from/replyTo). */
export function createSpoolProvider(identity: { from: string; replyTo: string | null }): MailProvider {
  return {
    name: "spool",
    async send(envelope: MailEnvelope): Promise<MailSendResult> {
      try {
        const store = await objectStorage();
        const stamp = new Date().toISOString().replace(/[:.]/g, "-");
        const recipient = envelope.to.replace(/[^a-zA-Z0-9@._-]/g, "_");
        const key = `outbox/${stamp}_${recipient}.eml`;
        await store.put(
          key,
          Buffer.from(renderEml(envelope, identity.from, identity.replyTo), "utf8")
        );
        return {
          ok: true,
          /* ROUND 137 — prefer the STABLE outbox Message-ID when present
           * (the .eml header carries it; the spool key is the fallback). */
          messageId: envelope.messageId ?? key.split("/").pop() ?? undefined,
        };
      } catch (error) {
        return {
          ok: false,
          error: error instanceof Error ? error.message : String(error),
          errorClass: "unknown",
        };
      }
    },
    async verify(): Promise<MailVerifyResult> {
      /* the driver-aware probe: put + delete a tiny throwaway object —
       * a REAL writability/reachability check for whichever store is
       * active (the old mkdirSync test only proved the local dir) */
      try {
        const store = await objectStorage();
        const probe = `outbox/.probe-${Date.now().toString(36)}-${randomBytes(4).toString("hex")}.eml`;
        await store.put(probe, Buffer.from("spool-verify-probe", "utf8"));
        const existed = await store.delete(probe);
        if (!existed) {
          throw new Error("spool verify probe missing after write");
        }
        return { ok: true, detail: "spool" };
      } catch (error) {
        return {
          ok: false,
          detail: error instanceof Error ? error.message : String(error),
          errorClass: "unknown",
        };
      }
    },
  };
}
