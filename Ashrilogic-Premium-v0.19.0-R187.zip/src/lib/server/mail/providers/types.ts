/**
 * AshriLogic — EMAIL SYSTEM — provider adapter contract.
 *
 * Every outbound mail transport implements this one interface, so the Mail
 * Service stays provider-agnostic (requirement: adding Resend / SES / any
 * future provider must never touch the service or the callers):
 *
 *   MailService (service.ts)
 *        ↓ uses
 *   MailProvider ← smtp.ts (nodemailer)  ← spool.ts (dev .eml outbox)
 *                  ← future adapters…
 *
 * Adapters are TRANSPORT-ONLY: they receive a fully rendered envelope and
 * report the outcome. Retry policy, delivery logging, idempotency and
 * audit live in the service layer — never duplicated per provider.
 */

/** A fully rendered, ready-to-send message (headers sanitized upstream). */
export interface MailEnvelope {
  to: string;
  subject: string;
  text: string;
  html?: string;
  /** optional explicit Reply-To (resolved sender identity upstream) */
  replyTo?: string;
  /** ROUND 137 — the STABLE outbox Message-ID: one id per logical message
   *  across inline attempts and sweeper re-drives (receiver-side dedupe of
   *  the at-least-once stream). Providers SHOULD honor it. */
  messageId?: string;
}

/** Transient-error classification — drives the service's retry policy. */
export type MailErrorClass =
  | "auth"
  | "connection"
  | "timeout"
  | "rejected"
  | "unknown";

/** The adapter's send outcome (one transport attempt — retries live above). */
export interface MailSendResult {
  ok: boolean;
  /** provider message id when one is available (SMTP Message-ID) */
  messageId?: string;
  /** sanitized error summary — NEVER carries credentials (service scrubs) */
  error?: string;
  errorClass?: MailErrorClass;
}

/** The adapter's connection/auth probe outcome. */
export interface MailVerifyResult {
  ok: boolean;
  /** sanitized human-readable detail for the admin health surface */
  detail?: string;
  errorClass?: MailErrorClass;
}

/** One outbound transport. Implementations MUST be stateless-per-config. */
export interface MailProvider {
  /** transport identifier ("smtp" | "spool" — future: "resend", "ses") */
  readonly name: string;
  /** Send one envelope (single attempt). Must not throw — report instead. */
  send(envelope: MailEnvelope): Promise<MailSendResult>;
  /** Connection/authentication probe (no message sent). */
  verify(): Promise<MailVerifyResult>;
}

/** Strip credentials from any URL-ish or key-ish fragment before it is
 *  stored in EmailLog.error or returned to the admin UI. Defense in depth:
 *  adapters also sanitize, the service scrubs again before persisting. */
export function scrubMailError(raw: string): string {
  return raw
    // user:pass@host → ***@host
    .replace(/:\/\/[^\s@/:]+@[^\s/]+/g, "://***@")
    // long bearer-ish tokens (SMTP URLs, API keys) → first 4 chars only
    .replace(/\b[A-Za-z0-9+/_-]{24,}\b/g, (m) => `${m.slice(0, 4)}***`)
    .slice(0, 240);
}
