import { escHtml, renderEmailShell, TEXT_DIVIDER } from "./layout";

/**
 * AshriLogic — EMAIL SYSTEM — the TEST letter.
 *
 * The admin's «إرسال بريد اختباري» round-trip: verifies SMTP connection,
 * authentication, sender identity, recipient delivery AND HTML rendering
 * in ONE artifact. Carries explicit transport diagnostics (mode, provider,
 * resolved sender) so the operator sees exactly which path delivered it —
 * without a single secret.
 */

export interface TestMailInput {
  to: string;
  orgName: string;
  /** diagnostics block, pre-rendered by the route (mode/host/port — NO secrets) */
  diagnosticsAr: string;
  diagnosticsEn: string;
}

export function renderTestEmail(input: TestMailInput): {
  subject: string;
  text: string;
  html: string;
} {
  const subject = `بريد اختباري من ${input.orgName} · Test email — ${input.orgName}`;
  const when = new Date().toISOString().replace("T", " ").slice(0, 16) + " UTC";

  const text = [
    `هذه رسالة اختبارية من ${input.orgName}.`,
    `الوقت: ${when}`,
    "",
    "المؤشرات:",
    input.diagnosticsAr,
    "",
    "وصول هذه الرسالة يعني أن إعدادات البريد تعمل بشكل صحيح.",
    "",
    TEXT_DIVIDER,
    "",
    `This is a test email from ${input.orgName}.`,
    `Time: ${when}`,
    "",
    "Diagnostics:",
    input.diagnosticsEn,
    "",
    "Receiving this message means the mail configuration is working end-to-end.",
  ].join("\r\n");

  const bodyHtml = `
              <p dir="rtl" style="margin:0 0 10px;font-size:15px;font-weight:700;color:#0f172a;text-align:right;">بريد اختباري · Test email</p>
              <p dir="rtl" style="margin:0 0 16px;font-size:13px;line-height:1.9;color:#475569;text-align:right;">هذه رسالة اختبارية من <strong>${escHtml(input.orgName)}</strong> أُرسلت من لوحة التحكم. وصولها يعني أن إعدادات البريد (الاتصال، المصادقة، هوية المُرسِل، تنسيق HTML) تعمل بشكل صحيح.</p>
              <div dir="rtl" style="margin:0 0 18px;padding:14px 16px;background:#f1f5f9;border-radius:12px;font-size:12.5px;line-height:1.9;color:#334155;text-align:right;white-space:pre-line">${escHtml(input.diagnosticsAr)}</div>
              <p dir="ltr" style="margin:0 0 6px;font-size:13px;line-height:1.8;color:#475569;text-align:left;">This is a test email from <strong>${escHtml(input.orgName)}</strong>, sent from the admin console. Receiving it means the mail configuration (connection, authentication, sender identity, HTML rendering) works end-to-end.</p>
              <div dir="ltr" style="margin:0 0 18px;padding:14px 16px;background:#f8fafc;border-radius:12px;font-size:12.5px;line-height:1.9;color:#334155;text-align:left;white-space:pre-line">${escHtml(input.diagnosticsEn)}</div>
              <p dir="ltr" style="margin:0;font-size:11.5px;color:#94a3b8;text-align:left;"><span dir="ltr">${escHtml(when)}</span></p>`;

  const html = renderEmailShell({
    orgName: input.orgName,
    lang: "ar",
    headerTag: "بريد اختباري · Test email",
    headerGradient: "135deg,#6d5dfb,#06b6d4",
    bodyHtml,
  });

  return { subject, text, html };
}
