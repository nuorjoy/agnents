import { escHtml } from "./layout";

/**
 * AshriLogic — EMAIL SYSTEM — the CUSTOMER VERIFICATION letter.
 *
 * VERBATIM relocation of the proven ROUND 75 markup from
 * src/lib/server/verification.ts (bilingual AR-first, inline styles,
 * single-use 24h link). Rendering only — sending, logging and retry live
 * in the Mail Service; token minting stays in verification.ts.
 */

export interface VerificationMailInput {
  to: string;
  name: string;
  url: string;
  orgName: string;
}

export function renderVerificationEmail(input: VerificationMailInput): {
  subject: string;
  text: string;
  html: string;
} {
  const name = input.name.trim() || "عميلنا العزيز";
  const subject = `تأكيد بريدك الإلكتروني · Verify your email — ${input.orgName}`;

  const text = [
    `مرحباً ${name}،`,
    "",
    `شكراً لتسجيلك في ${input.orgName}.`,
    "لتوثيق بريدك الإلكتروني وتفعيل كامل مزايا حسابك (سجل الطلبات، الاستفسارات، العناوين المحفوظة)، افتح الرابط التالي:",
    "",
    input.url,
    "",
    "الرابط صالح لمدة ٢٤ ساعة ولمرة واحدة فقط.",
    "إذا لم تطلب هذا التسجيل فيمكنك تجاهل هذه الرسالة بأمان.",
    "",
    "----------------------------------------",
    "",
    `Hello ${name},`,
    "",
    `Thanks for signing up with ${input.orgName}.`,
    "To verify your email address and unlock your full account (order history, inquiries, saved addresses), open the link below:",
    "",
    input.url,
    "",
    "The link is single-use and valid for 24 hours.",
    "If you did not request this signup you can safely ignore this message.",
  ].join("\r\n");

  const cta = escHtml(input.url);
  const org = escHtml(input.orgName);
  const who = escHtml(name);

  const html = `<!doctype html>
<html lang="ar" dir="rtl">
  <body style="margin:0;padding:0;background:#f4f4f7;font-family:Segoe UI,Tahoma,Arial,sans-serif;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f7;padding:28px 12px;">
      <tr><td align="center">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:520px;background:#ffffff;border-radius:18px;overflow:hidden;box-shadow:0 8px 30px rgba(15,23,42,.08);">
          <tr>
            <td style="background:linear-gradient(135deg,#6d5dfb,#d946ef);padding:26px 28px;text-align:center;">
              <div style="font-size:21px;font-weight:800;color:#ffffff;letter-spacing:.2px;">${org}</div>
              <div style="margin-top:6px;font-size:12px;font-weight:600;color:rgba(255,255,255,.85);">تأكيد البريد الإلكتروني · Email verification</div>
            </td>
          </tr>
          <tr>
            <td style="padding:28px 28px 8px;">
              <p dir="rtl" style="margin:0 0 10px;font-size:15px;font-weight:700;color:#0f172a;text-align:right;">مرحباً ${who} 👋</p>
              <p dir="rtl" style="margin:0 0 18px;font-size:13px;line-height:1.9;color:#475569;text-align:right;">شكراً لتسجيلك في <strong>${org}</strong>. وثّق بريدك لتفعيل كامل مزايا حسابك: سجل الطلبات والاستفسارات، العناوين المحفوظة، وإشعارات ردود خدمة العملاء.</p>
              <p dir="ltr" style="margin:0 0 22px;font-size:13px;line-height:1.8;color:#475569;text-align:left;">Hello ${who} — thanks for signing up with <strong>${org}</strong>. Verify your email to unlock your full account: order &amp; inquiry history, saved addresses, and support-reply notifications.</p>
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                <tr><td align="center" style="padding:4px 0 18px;">
                  <a href="${cta}" style="display:inline-block;background:linear-gradient(135deg,#6d5dfb,#d946ef);color:#ffffff;text-decoration:none;font-weight:800;font-size:14px;padding:14px 34px;border-radius:12px;">وثّق بريدي الآن · Verify my email</a>
                </td></tr>
                <tr><td align="center" style="padding:0 0 14px;">
                  <p dir="rtl" style="margin:0;font-size:11.5px;color:#94a3b8;text-align:center;">الرابط يعمل لمرة واحدة وصالح ٢٤ ساعة من الآن.</p>
                  <p dir="ltr" style="margin:6px 0 0;font-size:11.5px;color:#94a3b8;text-align:center;">Single-use link, valid for 24 hours.</p>
                </td></tr>
              </table>
              <p dir="rtl" style="margin:0 0 6px;font-size:11.5px;line-height:1.8;color:#94a3b8;border-top:1px solid #eef0f4;padding-top:14px;text-align:right;">إذا لم تطلب هذا التسجيل، تجاهل هذه الرسالة بأمان — لن يُنشأ أي التزام.</p>
              <p dir="ltr" style="margin:0;font-size:11.5px;line-height:1.8;color:#94a3b8;text-align:left;">Didn't sign up? You can safely ignore this email.</p>
            </td>
          </tr>
        </table>
        <div style="margin-top:14px;font-size:10.5px;color:#94a3b8;">© ${new Date().getFullYear()} ${org} · مدعوم بأشرِيلوجيك · Powered by Ashrilogic</div>
      </td></tr>
    </table>
  </body>
</html>`;

  return { subject, text, html };
}
