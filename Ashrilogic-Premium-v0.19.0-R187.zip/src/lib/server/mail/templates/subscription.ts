import { escHtml, renderEmailShell, TEXT_DIVIDER } from "./layout";

/**
 * AshriLogic — EMAIL SYSTEM — the SUBSCRIPTION letter (new mail type).
 *
 * Plan lifecycle notices for tenant subscribers: activation / renewal /
 * expiry heads-up. Bilingual AR-first twin; amounts arrive ALREADY
 * formatted by the caller (money.ts convention — the backend never
 * formats currency twice).
 */

export interface SubscriptionMailInput {
  to: string;
  name: string;
  orgName: string;
  /** "activated" | "renewed" | "expiring" | "expired" */
  event: "activated" | "renewed" | "expiring" | "expired";
  /** the plan's display name (e.g. "Professional") */
  planName: string;
  /** formatted amount + currency when billing-relevant (e.g. "199 SAR") */
  amountFormatted?: string;
  /** coverage window end, already formatted for display */
  validUntil?: string;
}

const EVENT_TEXT: Record<SubscriptionMailInput["event"], { ar: string; en: string }> = {
  activated: { ar: "تم تنشيط باقتك بنجاح", en: "Your plan is now active" },
  renewed: { ar: "تم تجديد باقتك بنجاح", en: "Your plan was renewed" },
  expiring: { ar: "باقتك تقترب من الانتهاء", en: "Your plan expires soon" },
  expired: { ar: "انتهت صلاحية باقتك", en: "Your plan has expired" },
};

export function renderSubscriptionEmail(input: SubscriptionMailInput): {
  subject: string;
  text: string;
  html: string;
} {
  const name = input.name.trim() || "عميلنا العزيز";
  const ev = EVENT_TEXT[input.event];
  const subject = `${ev.ar} · ${ev.en} — ${input.orgName}`;

  const detailLines = [
    `الباقة: ${input.planName}`,
    input.amountFormatted ? `المبلغ: ${input.amountFormatted}` : "",
    input.validUntil ? `صالحة حتى: ${input.validUntil}` : "",
  ]
    .filter(Boolean)
    .join("\n");
  const detailLinesEn = [
    `Plan: ${input.planName}`,
    input.amountFormatted ? `Amount: ${input.amountFormatted}` : "",
    input.validUntil ? `Valid until: ${input.validUntil}` : "",
  ]
    .filter(Boolean)
    .join("\n");

  const text = [
    `مرحباً ${name}،`,
    "",
    `${ev.ar} في ${input.orgName}.`,
    ...(detailLines ? ["", detailLines] : []),
    "",
    "شكراً لثقتك بمنصة أشرِيلوجيك.",
    "",
    TEXT_DIVIDER,
    "",
    `Hello ${name},`,
    "",
    `${ev.en} on ${input.orgName}.`,
    ...(detailLinesEn ? ["", detailLinesEn] : []),
    "",
    "Thank you for trusting the Ashrilogic platform.",
  ].join("\r\n");

  const detailHtml = [
    `<tr><td dir="rtl" style="padding:8px 0;color:#64748b;font-weight:700;text-align:right;">الباقة</td><td dir="ltr" style="padding:8px 0;text-align:left;font-weight:800">${escHtml(input.planName)}</td></tr>`,
    input.amountFormatted
      ? `<tr><td dir="rtl" style="padding:8px 0;color:#64748b;font-weight:700;text-align:right;">المبلغ</td><td dir="ltr" style="padding:8px 0;text-align:left;font-weight:800">${escHtml(input.amountFormatted)}</td></tr>`
      : "",
    input.validUntil
      ? `<tr><td dir="rtl" style="padding:8px 0;color:#64748b;font-weight:700;text-align:right;">صالحة حتى</td><td dir="ltr" style="padding:8px 0;text-align:left;font-weight:800">${escHtml(input.validUntil)}</td></tr>`
      : "",
  ].join("");

  const bodyHtml = `
              <p dir="rtl" style="margin:0 0 10px;font-size:15px;font-weight:700;color:#0f172a;text-align:right;">مرحباً ${escHtml(name)} 👋</p>
              <p dir="rtl" style="margin:0 0 18px;font-size:13px;line-height:1.9;color:#475569;text-align:right;"><strong>${escHtml(ev.ar)}</strong> في ${escHtml(input.orgName)}.</p>
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="font-size:13.5px">${detailHtml}</table>
              <p dir="ltr" style="margin:16px 0 6px;font-size:13px;line-height:1.8;color:#475569;text-align:left;"><strong>${escHtml(ev.en)}</strong> on ${escHtml(input.orgName)}.</p>
              <p dir="ltr" style="margin:0 0 8px;font-size:11.5px;line-height:1.8;color:#94a3b8;text-align:left;">Thank you for trusting the Ashrilogic platform.</p>`;

  const html = renderEmailShell({
    orgName: input.orgName,
    lang: "ar",
    headerTag: `${ev.ar} · ${ev.en}`,
    headerGradient: "135deg,#06b6d4,#6d5dfb",
    bodyHtml,
  });

  return { subject, text, html };
}
