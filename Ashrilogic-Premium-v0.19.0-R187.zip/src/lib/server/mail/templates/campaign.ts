/**
 * AshriLogic — EMAIL SYSTEM — the NEWSLETTER CAMPAIGN letter.
 *
 * VERBATIM relocation of the proven campaign renderer from
 * src/lib/server/mailer.ts (minimal client-safe HTML wrapper, no remote
 * assets, RTL-friendly dir="auto"). Rendering only — bulk dispatch,
 * logging and retry live in the Mail Service.
 */

/** Plain-text body for a newsletter campaign (subscriber-visible). */
export function renderCampaignText(subject: string, body: string): string {
  return `${subject}\n\n${body}\n\n— Ashrilogic\n`;
}

/** Minimal, client-safe HTML wrapper (no remote assets, RTL-friendly). */
export function renderCampaignHtml(subject: string, body: string): string {
  const esc = (s: string): string =>
    s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  return `<!doctype html><html dir="auto"><body style="margin:0;padding:24px;background:#f6f7fb;font-family:system-ui,Segoe UI,Tahoma,Arial,sans-serif;color:#1e293b"><div style="max-width:560px;margin:0 auto;background:#ffffff;border-radius:16px;padding:32px;border:1px solid #e2e8f0"><h2 style="margin:0 0 16px;font-size:20px;color:#0f172a">${esc(subject)}</h2><div style="white-space:pre-wrap;font-size:15px;line-height:1.8">${esc(body)}</div><p style="margin:24px 0 0;font-size:12px;color:#94a3b8">— Ashrilogic</p></div></body></html>`;
}
