import { escHtml, renderEmailShell, TEXT_DIVIDER } from "./layout";

/**
 * AshriLogic — EMAIL SYSTEM — the SECURITY ALERT letter (new mail type).
 *
 * Account-security events that MUST reach the mailbox owner:
 *  - password successfully changed (the standard post-reset confirmation —
 *    a stolen-session attacker rotating the password can no longer hide).
 *  - future: suspicious-login alerts, MFA changes…
 *
 * Deliberately fact-free beyond the event itself: no links to click (a
 * security alert that trains users to click would be a phishing school),
 * only the event + when + the honest "wasn't you?" guidance.
 */

export interface SecurityAlertMailInput {
  to: string;
  name: string;
  orgName: string;
  /** already-localized event summary (AR-first convention at the call site) */
  eventAr: string;
  eventEn: string;
}

export function renderSecurityAlertEmail(input: SecurityAlertMailInput): {
  subject: string;
  text: string;
  html: string;
} {
  const name = input.name.trim() || "عميلنا العزيز";
  const subject = `تنبيه أمني · Security alert — ${input.orgName}`;
  const when = new Date().toISOString().replace("T", " ").slice(0, 16) + " UTC";

  const text = [
    `مرحباً ${name}،`,
    "",
    `تنبيه أمني من ${input.orgName}:`,
    `الحدث: ${input.eventAr}`,
    `الوقت: ${when}`,
    "",
    "إذا لم تقم بهذا الإجراء بنفسك فبادر فوراً بإعادة تعيين كلمة المرور من صفحة حسابك.",
    "لن نطلب منك عبر البريد أي بيانات دخول أو رموز تحقق — احذر التصيّد.",
    "",
    TEXT_DIVIDER,
    "",
    `Hello ${name},`,
    "",
    `Security alert from ${input.orgName}:`,
    `Event: ${input.eventEn}`,
    `Time: ${when}`,
    "",
    "If this wasn't you, reset your password from the account page immediately.",
    "We will NEVER ask for credentials or verification codes over email.",
  ].join("\r\n");

  const bodyHtml = `
              <p dir="rtl" style="margin:0 0 10px;font-size:15px;font-weight:700;color:#0f172a;text-align:right;">مرحباً ${escHtml(name)}،</p>
              <div dir="rtl" style="margin:0 0 18px;padding:14px 16px;background:#fef2f2;border:1px solid #fecaca;border-radius:12px;font-size:13px;line-height:1.9;color:#7f1d1d;text-align:right;"><strong>الحدث:</strong> ${escHtml(input.eventAr)}<br/><strong>الوقت:</strong> <span dir="ltr">${escHtml(when)}</span></div>
              <p dir="rtl" style="margin:0 0 18px;font-size:13px;line-height:1.9;color:#475569;text-align:right;">إذا لم تقم بهذا الإجراء بنفسك فبادر فوراً بإعادة تعيين كلمة المرور من صفحة حسابك. لن نطلب منك عبر البريد أي بيانات دخول أو رموز تحقق — احذر التصيّد.</p>
              <p dir="ltr" style="margin:0 0 10px;font-size:13px;line-height:1.8;color:#475569;text-align:left;">Hello ${escHtml(name)} — <strong>${escHtml(input.eventEn)}</strong> at <span dir="ltr">${escHtml(when)}</span>.</p>
              <p dir="ltr" style="margin:0 0 22px;font-size:13px;line-height:1.8;color:#475569;text-align:left;">If this wasn't you, reset your password from the account page immediately. We will <strong>never</strong> ask for credentials or verification codes over email.</p>`;

  const html = renderEmailShell({
    orgName: input.orgName,
    lang: "ar",
    headerTag: "تنبيه أمني · Security alert",
    headerGradient: "135deg,#e11d48,#7c2d12",
    bodyHtml,
  });

  return { subject, text, html };
}
