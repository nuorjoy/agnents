import { Resolver } from "node:dns/promises";
import { db } from "@/lib/db";
import { resolveMailRuntime, loadMailRow, dbConfigComplete } from "./settings";
import { createSmtpProvider } from "./providers/smtp";
import { createSpoolProvider } from "./providers/spool";
import type { ResolvedMailRuntime } from "./settings";
import type { MailHealthDTO } from "@/lib/types";

/**
 * AshriLogic — EMAIL SYSTEM — the EMAIL HEALTH probe.
 *
 * Aggregates the honest answer to "does outbound mail work?":
 *  - SMTP connection + authentication (a REAL nodemailer verify() probe)
 *  - sender identity (what the envelope says)
 *  - SPF / DKIM / DMARC — ACTUAL DNS TXT lookups against the sender domain.
 *    A check only reports "pass" when the record genuinely resolved;
 *    lookups that fail report "error" with the resolver's message — this
 *    surface never claims success it did not verify.
 *  - last successful / failed send + 24h counts from the EmailLog trail.
 *
 * Nothing here is cached for long: connection + DNS are point-in-time
 * probes triggered from the admin console (rate-limited at the route).
 */

/* ------------------------------------------------------------------ */
/* DNS authentication checks (SPF / DKIM / DMARC)                      */
/* ------------------------------------------------------------------ */

export type DnsCheckStatus = "pass" | "fail" | "error" | "skipped";

export interface DnsCheck {
  status: DnsCheckStatus;
  /** short honest detail (record fragment, selector found, or the error) */
  detail: string;
}

const resolver = new Resolver({ timeout: 4_000, tries: 2 });

async function txtRecords(name: string): Promise<string[]> {
  const chunks = await resolver.resolveTxt(name);
  /* resolveTxt returns per-record chunk arrays — join each record */
  return chunks.map((chunksOfRecord) => chunksOfRecord.join(""));
}

function lookupErrorDetail(error: unknown): string {
  const code = (error as { code?: string }).code;
  if (code === "ENOTFOUND" || code === "ENODATA") return "no record";
  return error instanceof Error ? error.message.slice(0, 120) : String(error).slice(0, 120);
}

async function checkSpf(domain: string): Promise<DnsCheck> {
  try {
    const records = await txtRecords(domain);
    const spf = records.find((r) => r.toLowerCase().startsWith("v=spf1"));
    if (!spf) return { status: "fail", detail: "no SPF record at the domain root" };
    return { status: "pass", detail: spf.slice(0, 120) };
  } catch (error) {
    return { status: "error", detail: lookupErrorDetail(error) };
  }
}

/** Conventional DKIM selector candidates (provider-dependent in reality). */
const DKIM_SELECTORS = ["default", "s1", "s2", "selector1", "selector2", "google", "resend", "smtp"];

async function checkDkim(domain: string): Promise<DnsCheck> {
  for (const selector of DKIM_SELECTORS) {
    try {
      const records = await txtRecords(`${selector}._domainkey.${domain}`);
      const dkim = records.find((r) => r.includes("v=DKIM1") || r.includes("p="));
      if (dkim) {
        return { status: "pass", detail: `selector "${selector}" · ${dkim.slice(0, 60)}…` };
      }
    } catch (error) {
      const code = (error as { code?: string }).code;
      if (code !== "ENOTFOUND" && code !== "ENODATA") {
        /* a real resolver failure (not a missing record) is worth surfacing */
        return { status: "error", detail: lookupErrorDetail(error) };
      }
      /* selector absent — try the next candidate */
    }
  }
  return {
    status: "fail",
    detail: "no DKIM record found at the common selectors (the actual selector depends on your provider)",
  };
}

async function checkDmarc(domain: string): Promise<DnsCheck> {
  try {
    const records = await txtRecords(`_dmarc.${domain}`);
    const dmarc = records.find((r) => r.toLowerCase().startsWith("v=dmarc1"));
    if (!dmarc) return { status: "fail", detail: "no DMARC record at _dmarc" };
    return { status: "pass", detail: dmarc.slice(0, 120) };
  } catch (error) {
    return { status: "error", detail: lookupErrorDetail(error) };
  }
}

function senderDomain(fromEmail: string): string | null {
  const at = fromEmail.lastIndexOf("@");
  if (at <= 0 || at === fromEmail.length - 1) return null;
  const domain = fromEmail.slice(at + 1).toLowerCase();
  return domain.includes(".") ? domain : null;
}

/* ------------------------------------------------------------------ */
/* the aggregated probe                                                */
/* ------------------------------------------------------------------ */

/** SMTP connection/auth probe through the ACTIVE provider. */
async function probeConnection(runtime: ResolvedMailRuntime): Promise<MailHealthDTO["connection"]> {
  try {
    const provider =
      runtime.providerName === "smtp" ? createSmtpProvider(runtime) : createSpoolProvider({ from: runtime.from, replyTo: runtime.replyTo });
    const result = await provider.verify();
    return {
      ok: result.ok,
      detail: result.detail ?? (result.ok ? "connection verified" : "verification failed"),
    };
  } catch (error) {
    return {
      ok: false,
      detail: error instanceof Error ? error.message.slice(0, 160) : String(error).slice(0, 160),
    };
  }
}

async function emailLogStats(): Promise<{
  lastSent: MailHealthDTO["lastSent"];
  lastFailed: MailHealthDTO["lastFailed"];
  sent24h: number;
  failed24h: number;
}> {
  const since = new Date(Date.now() - 24 * 60 * 60 * 1000);
  const [lastSentRow, lastFailedRow, sent24h, failed24h] = await Promise.all([
    db.emailLog.findFirst({ where: { status: "sent" }, orderBy: { deliveredAt: "desc" }, select: { deliveredAt: true, subject: true, type: true, recipient: true } }),
    db.emailLog.findFirst({ where: { status: "failed" }, orderBy: { failedAt: "desc" }, select: { failedAt: true, subject: true, type: true, recipient: true, error: true } }),
    db.emailLog.count({ where: { status: "sent", createdAt: { gte: since } } }),
    db.emailLog.count({ where: { status: "failed", createdAt: { gte: since } } }),
  ]);
  return {
    lastSent: lastSentRow
      ? { at: (lastSentRow.deliveredAt ?? new Date()).toISOString(), subject: lastSentRow.subject, type: lastSentRow.type }
      : null,
    lastFailed: lastFailedRow
      ? {
          at: (lastFailedRow.failedAt ?? new Date()).toISOString(),
          subject: lastFailedRow.subject,
          type: lastFailedRow.type,
          ...(lastFailedRow.error ? { error: lastFailedRow.error } : {}),
        }
      : null,
    sent24h,
    failed24h,
  };
}

/**
 * The full health snapshot (point-in-time — invoked from the admin
 * console, rate-limited upstream). Never throws; each leg reports its
 * own honest outcome.
 */
export async function getMailHealth(): Promise<MailHealthDTO> {
  const runtime = await resolveMailRuntime();
  const row = await loadMailRow();

  const [connection, stats] = await Promise.all([probeConnection(runtime), emailLogStats()]);

  /* DNS auth checks: only meaningful with a real sender domain on the
   * active config (DB identity in smtp-db mode; the env identity is the
   * legacy path and still worth checking when live). */
  const domain = senderDomain(runtime.fromEmail);
  const dns =
    domain && runtime.providerName === "smtp"
      ? {
          domain,
          spf: await checkSpf(domain),
          dkim: await checkDkim(domain),
          dmarc: await checkDmarc(domain),
        }
      : {
          domain: domain ?? "",
          spf: { status: "skipped" as DnsCheckStatus, detail: "no active SMTP sender domain" },
          dkim: { status: "skipped" as DnsCheckStatus, detail: "no active SMTP sender domain" },
          dmarc: { status: "skipped" as DnsCheckStatus, detail: "no active SMTP sender domain" },
        };

  return {
    mode: runtime.mode,
    provider: runtime.providerName,
    senderIdentity: {
      from: runtime.from,
      fromEmail: runtime.fromEmail,
      ...(runtime.replyTo ? { replyTo: runtime.replyTo } : {}),
    },
    connection,
    dns,
    ...stats,
    dbConfig: {
      enabled: row.enabled,
      complete: dbConfigComplete(row),
      hasPassword: row.passwordSealed !== null,
    },
    checkedAt: new Date().toISOString(),
  };
}
