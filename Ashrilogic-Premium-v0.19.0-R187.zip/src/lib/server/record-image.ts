import { isManagedImageRef, storeImageDataUrl } from "@/lib/server/image-store";
import { ImageValidationError } from "@/lib/server/upload-validation";
import { db } from "@/lib/db";

/**
 * Ashrilogic — ROUND 51 (storefront visual merchandising).
 *
 * Shared resolver for the optional product photo on module records. The write
 * routes (POST/PATCH /api/instances/[id]/module-records) accept an `image`
 * field with exactly three shapes — anything else is a 400:
 *
 *   • undefined        — not submitted; the stored imageRef is untouched;
 *   • ""               — explicit CLEAR (the stored imageRef becomes NULL);
 *   • a MANAGED ref    — `/api/images/<64 lowercase hex>` minted by THIS
 *                        server from already-sanitized bytes (an editor echo
 *                        or a deliberate reuse) — persisted VERBATIM, no
 *                        re-encode, byte-identical idempotence;
 *   • a data-URL       — a FRESH upload: the full upload-validation pipeline
 *                        (magic bytes, dimension/pixel/bomb caps, sharp
 *                        re-encode to clean WebP) runs, the sanitized bytes
 *                        land in the content-addressed store and the SHORT
 *                        managed ref is what gets persisted — the data-URL
 *                        itself is never written to the business row.
 *
 * SECURITY: identical semantics to the site-logo path (site route, round 37 +
 * round 40) which has been pentested — a managed ref can only contain
 * server-minted bytes because the id is the sha256 of the re-encoded output;
 * arbitrary paths/URLs are rejected by the fixed-shape regex.
 */

/** client data-URLs are capped well below the 2 MB bounded-body read */
const MAX_INPUT_BYTES = 3 * 1024 * 1024;
/** sanitized output cap (WebP) — product photos are listed 20-up in grids */
const MAX_OUTPUT_BYTES = 500 * 1024;

/** The `image` field as accepted on module-record write bodies. */
export const RECORD_IMAGE_INPUT_RE =
  /^data:image\/(png|jpeg|jpg|webp|gif);base64,[A-Za-z0-9+/=\r\n]+$/;

/** Is this value shaped like a fresh upload (data-URL)? */
export function isRecordImageDataUrl(v: unknown): v is string {
  return typeof v === "string" && RECORD_IMAGE_INPUT_RE.test(v);
}

export type ResolvedRecordImage =
  | { ok: true; imageRef: string | null; changed: boolean }
  | { ok: false; error: string; code?: "IMAGE_GONE" };

/**
 * Resolve the submitted `image` field to the value persisted in
 * ModuleRecord.imageRef. `stored` is the row's current ref (for PATCH).
 * Throws ImageValidationError (user-presentable) — callers map it to 400.
 *
 * ROUND 120 — a MANAGED-ref echo whose ImageAsset row no longer exists
 * (GC'd between the editor's read and this submit) is REFUSED with the
 * IMAGE_GONE code instead of silently committing a dangling reference:
 * this is the write-side half of the GC TOCTOU contract (the GC's delete
 * is an atomic conditional re-check; this check makes the two sides
 * serialize around the truth). The message is user-presentable — the
 * editor re-attaches or re-uploads the photo.
 */
export async function resolveRecordImage(
  submitted: string | undefined,
  stored: string | null
): Promise<ResolvedRecordImage> {
  if (submitted === undefined) {
    /* not submitted — keep whatever is stored */
    return { ok: true, imageRef: stored, changed: false };
  }

  if (submitted === "") {
    /* explicit clear */
    return { ok: true, imageRef: null, changed: stored !== null };
  }

  if (isManagedImageRef(submitted)) {
    /* server-minted, pre-validated — persisted verbatim ONLY when the
     * asset row still exists (a GC'd asset must be re-uploaded, never
     * dangled); a same-ref re-upload of identical bytes re-mints the SAME
     * id, so the legitimate re-submit path self-heals */
    const id = submitted.slice("/api/images/".length);
    const asset = await db.imageAsset.findUnique({
      where: { id },
      select: { id: true },
    });
    if (!asset) {
      return {
        ok: false,
        code: "IMAGE_GONE",
        error: "That image is no longer available — re-upload the photo",
      };
    }
    return { ok: true, imageRef: submitted, changed: submitted !== stored };
  }

  if (isRecordImageDataUrl(submitted)) {
    /* fresh upload — full validation + re-encode pipeline, then persist the
     * short managed reference (never the raw data-URL) */
    const stored_img = await storeImageDataUrl(submitted, {
      maxInputBytes: MAX_INPUT_BYTES,
      maxOutputBytes: MAX_OUTPUT_BYTES,
    });
    return { ok: true, imageRef: stored_img.url, changed: stored_img.url !== stored };
  }

  /* anything else — garbage shape, cross-origin URL, path, … */
  return {
    ok: false,
    error: "image must be a data-URL, a managed /api/images reference, or empty",
  };
}

/** Re-export so write routes can map validation failures uniformly. */
export { ImageValidationError };

/* re-exports — the mapper's zod refinements consume both guards from here */
export { isManagedImageRef };
