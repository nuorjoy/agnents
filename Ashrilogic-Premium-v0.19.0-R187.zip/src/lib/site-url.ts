/**
 * Ashrilogic — the canonical public site URL (single source of truth for SEO).
 *
 * Used by:
 *  - the root layout's `metadataBase`
 *  - `src/app/robots.ts` (sitemap + host hints)
 *  - `src/app/sitemap.ts` (every static + dynamic URL)
 *  - every page's `alternates.canonical` and OpenGraph `url`
 *  - the JSON-LD structured-data blocks (Organization / WebSite / SoftwareApplication)
 *
 * The override env `NEXT_PUBLIC_SITE_URL` is honored (trailing slash trimmed)
 * so preview/staging deployments (Vercel, PR-draft, local) do NOT pollute the
 * production canonical URLs — Google would otherwise de-dupe a preview URL
 * against the canonical and pick the wrong one.
 *
 * Default: the Vercel production deployment URL (Task 3-c/3-d SEO round).
 */
const RAW_URL =
  process.env.NEXT_PUBLIC_SITE_URL?.trim().replace(/\/+$/, "") || "https://ashrilogic.vercel.app";

export const SITE_URL = RAW_URL;
export const SITE_URL_OBJ = new URL(SITE_URL);
