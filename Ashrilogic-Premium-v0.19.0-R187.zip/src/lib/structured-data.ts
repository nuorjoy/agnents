/**
 * Ashrilogic — structured-data source.
 *
 * English FAQ Q&A pairs for the FAQPage JSON-LD schema, rendered ONLY
 * inside the landing page's FAQ section (the surface that actually
 * displays this Q&A content — markup must reflect page content).
 *
 * Content contract: every Q/A here mirrors the visible i18n FAQ keys
 * (faq1Q..faq8Q / faq1A..faq8A) in src/lib/i18n/domains/landing.ts —
 * EN wording, same order, same facts. The regression test
 * tests/security/seo-sitemap.test.ts pins the Q7 passkey question so the
 * historical Q7 drift (an isolation answer with no matching visible
 * question) cannot return.
 */
export const FAQS: { q: string; a: string }[] = [
  {
    q: "Do I need technical expertise to set up my system?",
    a: "Not at all. The smart setup wizard walks you through 7 visual steps — org data, modules, admin, preferences — then launches a ready-to-use dashboard instantly.",
  },
  {
    q: "Are the systems multilingual?",
    a: "Yes — Arabic, English, and Hindi are fully translated end-to-end, and 8 more languages (French, Spanish, Portuguese, German, Chinese, Japanese, Korean, Turkish) are selectable in the interface with English strings until their dictionaries ship — with instant RTL/LTR switching across the entire platform: UI, modules, settings, and dashboard.",
  },
  {
    q: "Can I modify modules after launch?",
    a: "Absolutely. You can enable or disable any module from the dashboard at any time without data loss, with every change tracked in the activity log.",
  },
  {
    q: "What about my data security?",
    a: "Two-factor auth, full audit log, multi-level roles, daily automatic backups, and multi-layer protection for each system individually.",
  },
  {
    q: "Is there a trial version?",
    a: "Yes, you can enable demo data during setup to explore the system before entering your real data.",
  },
  {
    q: "How do I get technical support?",
    a: "Support is available 24/7 via email, phone, and the help center, plus official social media channels for fast response.",
  },
  {
    q: "Can I sign in to my account without a password?",
    a: "Yes — Ashrilogic supports passkey sign-in (fingerprint, face recognition, or a hardware security key) across every login surface. It is faster than passwords and fully phishing-resistant because the authentication is cryptographically bound to the platform's own domain. You can register multiple passkeys per account and manage or revoke them anytime from your security settings.",
  },
  {
    q: "Do the systems work on phones and tablets?",
    a: "Absolutely — the entire platform is built mobile-first and adapts seamlessly to every screen size, from phones to tablets to desktops, with no layout overlap or loss of functionality.",
  },
];
