import type { Lang } from "@/lib/types";
import { landing } from "./domains/landing";
import { common } from "./domains/common";
import { features } from "./domains/features";
/* TYPE-ONLY imports of the heavy domain modules: the I18nKey contract still
 * covers EVERY key (the type is erased at emit time — zero runtime bytes),
 * while the RUNTIME fragment for these domains is registered on demand by
 * src/lib/i18n/fragments/app.ts (ROUND 172b — see the registry header). */
import type { auth } from "./domains/auth";
import type { wizard } from "./domains/wizard";
import type { dashboard } from "./domains/dashboard";
import type { site } from "./domains/site";
import type { admin } from "./domains/admin";
import type { store } from "./domains/store";
import type { inventory } from "./domains/inventory";
import type { business } from "./domains/business";

/**
 * Ashrilogic — ROUND 172b (performance) — the i18n REGISTRY.
 *
 * The former index.ts statically composed ALL ELEVEN domains (~1.39 MB of
 * TS dictionary source) into one module, so every surface that touched
 * `t()`/`useT()` — including the PUBLIC LANDING — shipped and evaluated the
 * entire AR/EN/HI dictionary set for the admin console, dashboard, wizard,
 * store and site surfaces it never renders. On production mobile that was
 * the single biggest parse/eval block on the critical path (~950 KB raw
 * page chunk; measured Lighthouse mobile: 8.5 s main-thread work).
 *
 * The split:
 *
 *  - STATIC fragment (this module): landing + common + features — the keys
 *    the landing SSR tree actually evaluates. Every `t()` caller keeps
 *    resolving them synchronously, server and client, exactly as before.
 *    Keys the landing SSR tree needs from the heavy domains (setup-showcase
 *    wizard vocabulary, systems-library favorites, tech-strip/pricing/
 *    support band, lang-menu, document titles) were MOVED into the landing
 *    domain file with byte-identical values, so the flat composed
 *    dictionaries are unchanged (regression-verified against the
 *    pre-refactor snapshot).
 *
 *  - APP fragment (src/lib/i18n/fragments/app.ts): the eight heavy domains
 *    (auth · wizard · dashboard · site · admin · store · inventory ·
 *    business), registered into this registry by a module side effect. It
 *    is imported by the ENTRY modules of the surfaces that render those
 *    keys (dashboard-app, admin-app/admin-login, login view, system-select,
 *    transition, wizard overlay, command palette, compare/blog routes, the
 *    public site/store/account views and the four server-side site pages),
 *    so each entry's chunk carries exactly what it renders. The landing
 *    page idle-loads it after first paint (requestIdleCallback) so any
 *    interaction-gated component (quote dialog, price advisor) resolves
 *    its keys by the time a human can click.
 *
 * The public API is byte-compatible with the old index.ts: t(), useT(),
 * I18nKey, and the locale-helper re-exports (index.ts re-exports this
 * module). `t()` falls back key-first exactly as before — a key that
 * belongs to an unregistered fragment renders as its own key name, which
 * is precisely the pre-existing behavior for unknown keys.
 */

/* ------------------------- the type contract ---------------------------- */

type FullAR = typeof landing.ar &
  typeof auth.ar &
  typeof wizard.ar &
  typeof dashboard.ar &
  typeof site.ar &
  typeof admin.ar &
  typeof store.ar &
  typeof inventory.ar &
  typeof business.ar &
  typeof features.ar &
  typeof common.ar;

/** Every dictionary key across all domains (same contract as before). */
export type I18nKey = keyof FullAR;

/* --------------------------- the registry ------------------------------- */

/** Runtime store per language: the static fragment + whatever app
 *  fragments have registered. Partial by construction (locales beyond
 *  ar/en/hi resolve through the EN fallback in t(), exactly as before). */
const AR: Partial<Record<I18nKey, string>> = { ...landing.ar, ...common.ar, ...features.ar };
const EN: Partial<Record<I18nKey, string>> = { ...landing.en, ...common.en, ...features.en };
const HI: Partial<Record<I18nKey, string>> = { ...landing.hi, ...common.hi, ...features.hi };
const DICTS: Partial<Record<Lang, Partial<Record<I18nKey, string>>>> = { ar: AR, en: EN, hi: HI };

/** True when the static fragment defines the key (debug/tests). */
export function isStaticI18nKey(key: I18nKey): boolean {
  return key in AR || key in EN || key in HI;
}

/** Shape every fragment registers (ar/en/hi objects of key→string). */
export interface I18nFragment {
  ar: Record<string, string>;
  en: Record<string, string>;
  hi: Record<string, string>;
}

/**
 * Register an app fragment into the live dictionaries (module side effect
 * of fragments/app.ts). Idempotent per fragment — safe under double import
 * (dev fast-refresh, shared server module cache).
 */
export function registerI18nFragment(fragment: I18nFragment): void {
  Object.assign(AR, fragment.ar);
  Object.assign(EN, fragment.en);
  Object.assign(HI, fragment.hi);
}

/* ------------------------------ translate ------------------------------- */
/**
 * Translate a key for the given language.
 * Pure function — safe on the server and the client.
 * Falls back to English for locales without a dictionary, then to the key
 * itself (never undefined). Interpolates `{var}` placeholders when `vars`
 * is provided.
 */
export function t(lang: Lang, key: I18nKey, vars?: Record<string, string | number>): string {
  const dict: Partial<Record<I18nKey, string>> = DICTS[lang] ?? EN;
  const raw = dict[key] ?? key;
  if (!vars) return raw;
  return raw.replace(/\{(\w+)\}/g, (match, name: string) =>
    vars[name] !== undefined ? String(vars[name]) : match
  );
}

/* NOTE (ROUND 185) — useT() MOVED to src/lib/i18n/use-t.ts: the hook now
 * reads the SSR language context (createContext — a CLIENT-only API), and
 * this registry module is imported by SERVER components (pages calling the
 * pure t() in generateMetadata), where createContext cannot execute. The
 * public surface is unchanged — src/lib/i18n/index.ts re-exports useT
 * from the hook module; every `import { useT } from "@/lib/i18n"` keeps
 * resolving to the same signature. */
