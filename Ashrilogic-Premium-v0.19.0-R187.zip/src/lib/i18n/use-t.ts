"use client";

import { useCallback, useContext } from "react";
import { useAppStore } from "@/lib/store";
import type { Lang } from "@/lib/types";
import { t, type I18nKey } from "./registry";
import { SsrLangContext } from "./ssr-lang";

/**
 * Ashrilogic — the useT() hook (ROUND 185 home; previously defined inline
 * in the registry — see the registry's move note).
 *
 * Reads the current language and returns memoized translation helpers
 * bound to it. SSR-language aware: inside a public page tree wrapped in
 * SsrLangProvider (src/components/ssr-lang-provider.tsx), the SSR and
 * hydration passes resolve the SERVER's cookie language — which the
 * provider flips to the store language after mount — so client islands
 * render the visitor's language from the very first server byte instead
 * of the store's hardcoded "ar" default (the pre-R185 Arabic-first flash
 * on every reload for non-Arabic visitors). Surfaces WITHOUT a provider
 * (dashboard / admin / site trees rendered outside the public pages)
 * keep the pure store language — byte-identical to the previous
 * behavior.
 */
export function useT(): {
  lang: Lang;
  t: (key: I18nKey, vars?: Record<string, string | number>) => string;
} {
  const storeLang = useAppStore((s) => s.lang);
  const ssrLang = useContext(SsrLangContext);
  const lang = ssrLang ?? storeLang;
  const translate = useCallback(
    (key: I18nKey, vars?: Record<string, string | number>) => t(lang, key, vars),
    [lang]
  );
  return { lang, t: translate };
}
