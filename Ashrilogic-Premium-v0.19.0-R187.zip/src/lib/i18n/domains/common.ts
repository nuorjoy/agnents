/**
 * Ashrilogic i18n — Shared / misc (transition, error pages) (21 keys).
 *
 * Extracted VERBATIM from the former src/lib/i18n.ts monolith (Round 60
 * split): one file per domain, re-composed into the full AR/EN/HI
 * dictionaries by src/lib/i18n/index.ts. Section comments are kept for
 * navigation. Sections included:
 *   - support / error pages
 *   - transition screen
 */
export const common = {
  ar: {
    /* ---------- support / error pages ---------- */
    supportEmail: "البريد الفني", 
    /* ROUND 167 — MoneyInput (ui/money-input.tsx): the formatted helper
       line's screen-reader label. */
    moneyHelperSr: "القيمة المنسّقة للسعر الحالي",
    supportPhone: "الهاتف", 
    supportHelpCenter: "مركز المساعدة", 
    err404Title: "الصفحة غير موجودة", 
    err404Desc: "الصفحة التي تبحث عنها غير موجودة أو تم نقلها. يمكنك العودة للرئيسية أو التواصل مع الدعم الفني.",
    err401Title: "غير مصرّح بالوصول", 
    err401Desc: "لا تملك صلاحية الوصول إلى هذا المورد. سجّل الدخول بحساب مصرّح له أو تواصل مع الدعم.",
    err500Title: "حدث خطأ غير متوقع", 
    err500Desc: "واجهنا خطأ تقني أثناء معالجة طلبك. فريقنا يعمل على حلها — يمكنك إعادة المحاولة أو التواصل مع الدعم.",
    errSupportTitle: "الدعم الفني على مدار الساعة", 
    errSupportDesc: "فريقنا جاهز لمساعدتك. تواصل عبر أي قناة أدناه وسنرد عليك بأسرع وقت.",
    errGoHome: "العودة للرئيسية", 
    errTryAgain: "إعادة المحاولة", 
    errGoAdmin: "لوحة الإدارة", 
    errReportId: "معرّف التتبّع",
    errReportDesc: "احفظ هذا المعرّف عند التواصل مع الدعم لتسريع الحل.",

    /* ---------- transition screen ---------- */
    tsPreparing: "جارٍ تجهيز مساحة العمل الخاصة بك…",
    tsStep1: "تهيئة قاعدة البيانات",
    tsStep2: "تحميل الوحدات المختارة",
    tsStep3: "إعداد حساب المسؤول والصلاحيات",
    tsStep4: "تفعيل التقارير والنسخ الاحتياطي",
  },
  en: {
    /* ---------- support / error pages ---------- */
    supportEmail: "Email Support",
    /* ROUND 167 — MoneyInput (ui/money-input.tsx): the formatted helper
       line's screen-reader label. */
    moneyHelperSr: "Formatted value of the current price",
    supportPhone: "Phone",
    supportHelpCenter: "Help Center",
    err404Title: "Page not found",
    err404Desc: "The page you are looking for doesn't exist or has been moved. Return home or reach our support team.",
    err401Title: "Unauthorized access",
    err401Desc: "You don't have permission to access this resource. Sign in with an authorized account or contact support.",
    err500Title: "Something went wrong",
    err500Desc: "We hit a technical error while processing your request. Our team is on it — try again or reach support.",
    errSupportTitle: "24/7 Technical Support",
    errSupportDesc: "Our team is ready to help. Reach us on any channel below and we'll respond as fast as we can.",
    errGoHome: "Back to home",
    errTryAgain: "Try again",
    errGoAdmin: "Admin Panel",
    errReportId: "Trace ID",
    errReportDesc: "Keep this ID when contacting support to speed up resolution.",

    /* ---------- transition screen ---------- */
    tsPreparing: "Preparing your workspace…",
    tsStep1: "Initializing database",
    tsStep2: "Loading selected modules",
    tsStep3: "Setting up admin account and permissions",
    tsStep4: "Enabling reports and auto-backup",
  },
  hi: {
    /* ---------- support / error pages ---------- */
    supportEmail: "तकनीकी ईमेल",
    /* ROUND 167 — MoneyInput (ui/money-input.tsx): the formatted helper
       line's screen-reader label. */
    moneyHelperSr: "मौजूदा मूल्य का स्वरूपित मान",
    supportPhone: "फ़ोन",
    supportHelpCenter: "हेल्प सेंटर",
    err404Title: "पेज नहीं मिला",
    err404Desc: "आप जिस पेज को खोज रहे हैं वह मौजूद नहीं है या हटा दिया गया। मुख्य पेज पर लौटें या सपोर्ट से संपर्क करें।",
    err401Title: "पहुँच अनधिकृत",
    err401Desc: "आपके पास इस संसाधन की पहुँच नहीं है। अधिकृत अकाउंट से लॉगिन करें या सपोर्ट से संपर्क करें।",
    err500Title: "अप्रत्याशित त्रुटि हुई",
    err500Desc: "आपके अनुरोध को प्रोसेस करते समय तकनीकी त्रुटि आई। हमारी टीम समाधान पर काम कर रही है — दोबारा कोशिश करें या सपोर्ट से संपर्क करें।",
    errSupportTitle: "24 घंटे तकनीकी सपोर्ट",
    errSupportDesc: "हमारी टीम मदद के लिए तैयार है। नीचे किसी भी चैनल से संपर्क करें — हम जल्द से जल्द जवाब देंगे।",
    errGoHome: "मुख्य पेज पर",
    errTryAgain: "दोबारा कोशिश करें",
    errGoAdmin: "एडमिन पैनल",
    errReportId: "ट्रैकिंग आईडी",
    errReportDesc: "तेज़ समाधान के लिए सपोर्ट से संपर्क करते समय यह आईडी बताएँ।",

    /* ---------- transition screen ---------- */
    tsPreparing: "आपका वर्कस्पेस तैयार हो रहा है…",
    tsStep1: "डेटाबेस कॉन्फ़िगर किया जा रहा है",
    tsStep2: "चयनित मॉड्यूल लोड हो रहे हैं",
    tsStep3: "एडमिन अकाउंट और अनुमतियाँ सेट हो रही हैं",
    tsStep4: "रिपोर्ट और बैकअप चालू हो रहे हैं",
  },
};
