/**
 * Ashrilogic i18n — INVENTORY (المخزون) workspace domain (ROUND 78).
 *
 * A DEDICATED domain so the premium inventory module (module-workspace
 * branch) owns its strings without touching the dashboard fragment.
 * Sections:
 *   - KPI strip (incl. sub-lines)
 *   - stock table / toolbar / sort / filters
 *   - expiry chips
 *   - movements (in / out / adjust + reason vocabulary)
 *   - thresholds / reorder affordances
 *   - valuation breakdown
 *   - quick-adjust dialog
 *   - record dialog helpers
 *   - empty states / demo notes
 *
 * Every key MUST exist in all three locales (ar / en / hi).
 */
export const inventory = {
  ar: {
    /* ---------- KPI strip ---------- */
    invKpiItems: "إجمالي الأصناف",
    invKpiValue: "قيمة المخزون",
    invKpiLow: "أصناف منخفضة",
    invKpiOut: "أصناف نافدة",
    invKpiUnitsSub: "الوحدات المتاحة: {count}",
    invKpiAvgSub: "متوسط تكلفة الوحدة: {cost}",
    invKpiPctSub: "{pct}٪ من إجمالي الأصناف",

    /* ---------- stock table / toolbar ---------- */
    invTableTitle: "أرصدة المخزون",
    invSearchPh: "ابحث بالصنف أو الرمز أو الفئة…",
    invFilterAll: "الكل",
    invCategoryAll: "كل الفئات",
    invSortLabel: "الترتيب",
    invSortValue: "الأعلى قيمة",
    invSortQtyDesc: "الأعلى كمية",
    invSortQtyAsc: "الأقل كمية أولاً",
    invSortName: "أبجدياً",
    invResetFilters: "مسح التصفية",
    invQtyAria: "الكمية {qty} مقابل حد الطلب {reorder}",
    invRowAdjust: "تعديل الكمية",
    invRowReorder: "طلب شراء",

    /* ---------- expiry ---------- */
    invExpiringSoon: "قارب على الانتهاء",
    invExpiryExpired: "منتهي",
    invExpiryIn: "ينتهي خلال {days} يوماً",

    /* ---------- movements ---------- */
    invMovesTitle: "حركة المخزون",
    invMovesDesc: "آخر عمليات الإدخال والإخراج والتعديل",
    invMoveIn: "إدخال",
    invMoveOut: "إخراج",
    invMoveAdjust: "تعديل",
    invMovesChip: "آخر {count} حركة",
    invMovesEmpty: "لا توجد حركات بعد — سجّل إدخالاً أو إخراجاً لتحديث السجل",
    invMoveLive: "مباشر",
    invMoveUnit: "وحدة",

    /* ---------- movement reasons ---------- */
    invReasonPurchase: "شراء جديد",
    invReasonCycle: "توريد دوري",
    invReasonInternal: "صرف داخلي",
    invReasonWaste: "هالك وتالف",
    invReasonCount: "جرد وتسوية",
    invReasonTransfer: "تحويل بين المواقع",
    invReasonReturn: "إرجاع لمورد",
    invReasonCorrection: "تصحيح قيد",

    /* ---------- thresholds / reorder ---------- */
    invThresholdsTitle: "حدود التنبيه",
    invThresholdsDesc: "الأصناف التي وصلت حد إعادة الطلب",
    invThresholdsChipOut: "نافد: {count}",
    invThresholdsChipLow: "تحت الحد: {count}",
    invThresholdsChipOrdered: "قيد الطلب: {count}",
    invThresholdsEmpty: "كل الأصناف فوق حد الطلب",
    invThresholdsEmptySub: "لا توجد أصناف تحتاج إعادة طلب حالياً — عمل ممتاز",
    invReorderDone: "تم تحويل «{name}» إلى طلب شراء",
    invReorderSuggest: "الكمية المقترحة: {qty}",

    /* ---------- valuation ---------- */
    invValuationTitle: "تقييم المخزون",
    invValuationDesc: "محسوبة من الأصناف المعروضة بعد التصفية",
    invValuationUnits: "إجمالي الوحدات",
    invValuationAvg: "متوسط تكلفة الوحدة",
    invValuationTopItem: "الصنف الأعلى قيمة",
    invValuationCats: "الفئات حسب القيمة",
    invValuationOther: "فئات أخرى",
    invValuationSharePct: "{pct}٪ من القيمة",

    /* ---------- quick-adjust dialog ---------- */
    invAdjustTitle: "تعديل كمية الصنف",
    invAdjustDesc: "سجّل إدخالاً أو إخراجاً سريعاً — تُحدّث القيمة والحالة تلقائياً",
    invAdjustCurrent: "الكمية الحالية",
    invAdjustMode: "نوع الحركة",
    invAdjustAmount: "المقدار",
    invAdjustNewQty: "الكمية الجديدة",
    invAdjustReason: "سبب الحركة",
    invAdjustSave: "تنفيذ الحركة",
    invAdjustSaved: "تم تحديث الكمية إلى {qty} وسُجّلت الحركة",
    invAdjustErr: "تعذر تنفيذ الحركة",
    invAdjustInvalid: "أدخل مقداراً أكبر من صفر",

    /* ---------- record dialog helpers ---------- */
    invRecAutoTotal: "القيمة تُحسب تلقائياً: {total}",
    invRecStatusSuggest: "الحالة المقترحة: {status}",

    /* ---------- empty states / notes ---------- */
    invEmptyTitle: "المخزون فارغ",
    invEmptyDesc: "أضف أول صنف لتتبّع الكميات والقيم وحدود إعادة الطلب",
    invDemoLocalNote: "تغييراتك على بيانات العرض محلية لهذه الجلسة فقط",

    /* ---------- ROUND 136 — unified golden KPI strip ---------- */
    invKpiUnits: "إجمالي الوحدات",
    invKpiAvgUnitsSub: "متوسط الوحدات لكل صنف: {avg}",

    /* ---------- ROUND 141 — زر منتجات الصنف ---------- */
    invRowViewProducts: "عرض منتجات الصنف",
  },
  en: {
    /* ---------- KPI strip ---------- */
    invKpiItems: "Total items",
    invKpiValue: "Stock value",
    invKpiLow: "Low stock",
    invKpiOut: "Out of stock",
    invKpiUnitsSub: "Units on hand: {count}",
    invKpiAvgSub: "Avg unit cost: {cost}",
    invKpiPctSub: "{pct}% of all items",

    /* ---------- stock table / toolbar ---------- */
    invTableTitle: "Stock balances",
    invSearchPh: "Search by item, SKU or category…",
    invFilterAll: "All",
    invCategoryAll: "All categories",
    invSortLabel: "Sort by",
    invSortValue: "Highest value",
    invSortQtyDesc: "Highest quantity",
    invSortQtyAsc: "Lowest quantity first",
    invSortName: "Alphabetical",
    invResetFilters: "Clear filters",
    invQtyAria: "Quantity {qty} against reorder point {reorder}",
    invRowAdjust: "Adjust quantity",
    invRowReorder: "Reorder",

    /* ---------- expiry ---------- */
    invExpiringSoon: "Expiring soon",
    invExpiryExpired: "Expired",
    invExpiryIn: "Expires in {days} days",

    /* ---------- movements ---------- */
    invMovesTitle: "Stock movements",
    invMovesDesc: "Latest inbound, outbound and adjustment entries",
    invMoveIn: "Inbound",
    invMoveOut: "Outbound",
    invMoveAdjust: "Adjustment",
    invMovesChip: "Last {count} movements",
    invMovesEmpty: "No movements yet — log an inbound or outbound entry to start the feed",
    invMoveLive: "Live",
    invMoveUnit: "units",

    /* ---------- movement reasons ---------- */
    invReasonPurchase: "New purchase",
    invReasonCycle: "Scheduled supply",
    invReasonInternal: "Internal issue",
    invReasonWaste: "Wastage",
    invReasonCount: "Stock count",
    invReasonTransfer: "Location transfer",
    invReasonReturn: "Supplier return",
    invReasonCorrection: "Entry correction",

    /* ---------- thresholds / reorder ---------- */
    invThresholdsTitle: "Alert thresholds",
    invThresholdsDesc: "Items that reached their reorder point",
    invThresholdsChipOut: "Out: {count}",
    invThresholdsChipLow: "Below point: {count}",
    invThresholdsChipOrdered: "On order: {count}",
    invThresholdsEmpty: "All items are above their reorder points",
    invThresholdsEmptySub: "No items need reordering right now — great job",
    invReorderDone: "“{name}” moved to reorder",
    invReorderSuggest: "Suggested order qty: {qty}",

    /* ---------- valuation ---------- */
    invValuationTitle: "Stock valuation",
    invValuationDesc: "Computed from the items currently in view",
    invValuationUnits: "Total units",
    invValuationAvg: "Average unit cost",
    invValuationTopItem: "Highest-value item",
    invValuationCats: "Categories by value",
    invValuationOther: "Other categories",
    invValuationSharePct: "{pct}% of value",

    /* ---------- quick-adjust dialog ---------- */
    invAdjustTitle: "Adjust item quantity",
    invAdjustDesc: "Log a quick inbound or outbound move — value and status update automatically",
    invAdjustCurrent: "Current quantity",
    invAdjustMode: "Movement type",
    invAdjustAmount: "Amount",
    invAdjustNewQty: "New quantity",
    invAdjustReason: "Reason",
    invAdjustSave: "Apply movement",
    invAdjustSaved: "Quantity updated to {qty} — movement logged",
    invAdjustErr: "Couldn't apply the movement",
    invAdjustInvalid: "Enter an amount greater than zero",

    /* ---------- record dialog helpers ---------- */
    invRecAutoTotal: "Value auto-computed: {total}",
    invRecStatusSuggest: "Suggested status: {status}",

    /* ---------- empty states / notes ---------- */
    invEmptyTitle: "Inventory is empty",
    invEmptyDesc: "Add your first item to start tracking quantities, values and reorder points",
    invDemoLocalNote: "Your demo-data changes are local to this session",

    /* ---------- ROUND 136 — unified golden KPI strip ---------- */
    invKpiUnits: "Total units",
    invKpiAvgUnitsSub: "Avg units per item: {avg}",

    /* ---------- ROUND 141 — the item-products lever ---------- */
    invRowViewProducts: "View item products",
  },
  hi: {
    /* ---------- KPI strip ---------- */
    invKpiItems: "कुल आइटम",
    invKpiValue: "स्टॉक मूल्य",
    invKpiLow: "कम स्टॉक",
    invKpiOut: "स्टॉक समाप्त",
    invKpiUnitsSub: "उपलब्ध इकाइयाँ: {count}",
    invKpiAvgSub: "औसत इकाई लागत: {cost}",
    invKpiPctSub: "सभी आइटम का {pct}%",

    /* ---------- stock table / toolbar ---------- */
    invTableTitle: "स्टॉक बैलेंस",
    invSearchPh: "आइटम, SKU या श्रेणी से खोजें…",
    invFilterAll: "सभी",
    invCategoryAll: "सभी श्रेणियाँ",
    invSortLabel: "क्रम",
    invSortValue: "उच्चतम मूल्य",
    invSortQtyDesc: "उच्चतम मात्रा",
    invSortQtyAsc: "न्यूनतम मात्रा पहले",
    invSortName: "वर्णानुक्रम",
    invResetFilters: "फ़िल्टर साफ़ करें",
    invQtyAria: "पुनः ऑर्डर बिंदु {reorder} के सापेक्ष मात्रा {qty}",
    invRowAdjust: "मात्रा समायोजित करें",
    invRowReorder: "पुनः ऑर्डर",

    /* ---------- expiry ---------- */
    invExpiringSoon: "जल्द समाप्त होगा",
    invExpiryExpired: "समाप्त",
    invExpiryIn: "{days} दिनों में समाप्त",

    /* ---------- movements ---------- */
    invMovesTitle: "स्टॉक मूवमेंट",
    invMovesDesc: "नवीनतम इनबाउंड, आउटबाउंड और समायोजन प्रविष्टियाँ",
    invMoveIn: "इनबाउंड",
    invMoveOut: "आउटबाउंड",
    invMoveAdjust: "समायोजन",
    invMovesChip: "अंतिम {count} मूवमेंट",
    invMovesEmpty: "अभी कोई मूवमेंट नहीं — फ़ीड शुरू करने के लिए एक प्रविष्टि दर्ज करें",
    invMoveLive: "लाइव",
    invMoveUnit: "इकाइयाँ",

    /* ---------- movement reasons ---------- */
    invReasonPurchase: "नई खरीद",
    invReasonCycle: "निर्धारित आपूर्ति",
    invReasonInternal: "आंतरिक जारी",
    invReasonWaste: "क्षय",
    invReasonCount: "स्टॉक गिनती",
    invReasonTransfer: "स्थानांतरण",
    invReasonReturn: "आपूर्तिकर्ता को वापसी",
    invReasonCorrection: "प्रविष्टि सुधार",

    /* ---------- thresholds / reorder ---------- */
    invThresholdsTitle: "अलर्ट सीमाएँ",
    invThresholdsDesc: "पुनः ऑर्डर बिंदु तक पहुँचे आइटम",
    invThresholdsChipOut: "समाप्त: {count}",
    invThresholdsChipLow: "बिंदु से नीचे: {count}",
    invThresholdsChipOrdered: "ऑर्डर पर: {count}",
    invThresholdsEmpty: "सभी आइटम अपने पुनः ऑर्डर बिंदु से ऊपर हैं",
    invThresholdsEmptySub: "अभी किसी आइटम को पुनः ऑर्डर की आवश्यकता नहीं है",
    invReorderDone: "“{name}” पुनः ऑर्डर पर चला गया",
    invReorderSuggest: "सुझाई गई ऑर्डर मात्रा: {qty}",

    /* ---------- valuation ---------- */
    invValuationTitle: "स्टॉक मूल्यांकन",
    invValuationDesc: "वर्तमान में दिखाई गई आइटम से गणना",
    invValuationUnits: "कुल इकाइयाँ",
    invValuationAvg: "औसत इकाई लागत",
    invValuationTopItem: "उच्चतम-मूल्य आइटम",
    invValuationCats: "मूल्य के अनुसार श्रेणियाँ",
    invValuationOther: "अन्य श्रेणियाँ",
    invValuationSharePct: "मूल्य का {pct}%",

    /* ---------- quick-adjust dialog ---------- */
    invAdjustTitle: "आइटम मात्रा समायोजित करें",
    invAdjustDesc: "त्वरित इनबाउंड या आउटबाउंड दर्ज करें — मूल्य और स्थिति स्वतः अपडेट होती हैं",
    invAdjustCurrent: "वर्तमान मात्रा",
    invAdjustMode: "मूवमेंट प्रकार",
    invAdjustAmount: "राशि",
    invAdjustNewQty: "नई मात्रा",
    invAdjustReason: "कारण",
    invAdjustSave: "मूवमेंट लागू करें",
    invAdjustSaved: "मात्रा {qty} पर अपडेट हुई — मूवमेंट दर्ज हुआ",
    invAdjustErr: "मूवमेंट लागू नहीं हो सका",
    invAdjustInvalid: "शून्य से बड़ी राशि दर्ज करें",

    /* ---------- record dialog helpers ---------- */
    invRecAutoTotal: "मूल्य स्वतः गणना: {total}",
    invRecStatusSuggest: "सुझाई गई स्थिति: {status}",

    /* ---------- empty states / notes ---------- */
    invEmptyTitle: "इन्वेंटरी खाली है",
    invEmptyDesc: "मात्रा, मूल्य और पुनः ऑर्डर बिंदु ट्रैक करना शुरू करने के लिए पहला आइटम जोड़ें",
    invDemoLocalNote: "आपके डेमो-डेटा परिवर्तन केवल इस सत्र के लिए स्थानीय हैं",

    /* ---------- ROUND 136 — unified golden KPI strip ---------- */
    invKpiUnits: "कुल इकाइयाँ",
    invKpiAvgUnitsSub: "प्रति आइटम औसत इकाइयाँ: {avg}",

    /* ---------- ROUND 141 — आइटम उत्पाद लीवर ---------- */
    invRowViewProducts: "आइटम उत्पाद देखें",
  },
};
