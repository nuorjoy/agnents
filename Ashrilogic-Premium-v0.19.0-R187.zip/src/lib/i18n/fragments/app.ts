import { auth } from "../domains/auth";
import { wizard } from "../domains/wizard";
import { dashboard } from "../domains/dashboard";
import { site } from "../domains/site";
import { admin } from "../domains/admin";
import { store } from "../domains/store";
import { inventory } from "../domains/inventory";
import { business } from "../domains/business";
import { registerI18nFragment } from "../registry";

/**
 * Ashrilogic — ROUND 172b (performance) — the APP i18n fragment.
 *
 * Registers the eight heavy dictionary domains (auth · wizard · dashboard ·
 * site · admin · store · inventory · business — ~1.24 MB of TS source) into
 * the i18n registry (src/lib/i18n/registry.ts) as a MODULE SIDE EFFECT.
 *
 * Import it ONCE at the entry of every surface that renders those keys:
 *   - tenant product:  dashboard-app, wizard overlay, system-select,
 *     transition screen, command palette;
 *   - auth surfaces:   login page view, admin login;
 *   - console:         admin-app;
 *   - public routes:   /compare, /blog, the tenant site/store/account/
 *     receipt views + the four server-side site pages (privacy/terms/
 *     account pages call t() server-side, so the server bundle registers
 *     the fragment through the same import).
 *
 * NEVER import this module from anything statically reachable by the
 * LANDING page (src/app/page.tsx → landing tree) — that would pull the
 * whole fragment back into the landing's critical-path chunk. The landing
 * idle-loads it after first paint instead (see page.tsx), which covers the
 * interaction-gated landing components (quote dialog, price advisor).
 *
 * Double-registration is idempotent (Object.assign of identical values).
 */
registerI18nFragment({
  ar: {
    ...auth.ar,
    ...wizard.ar,
    ...dashboard.ar,
    ...site.ar,
    ...admin.ar,
    ...store.ar,
    ...inventory.ar,
    ...business.ar,
  },
  en: {
    ...auth.en,
    ...wizard.en,
    ...dashboard.en,
    ...site.en,
    ...admin.en,
    ...store.en,
    ...inventory.en,
    ...business.en,
  },
  hi: {
    ...auth.hi,
    ...wizard.hi,
    ...dashboard.hi,
    ...site.hi,
    ...admin.hi,
    ...store.hi,
    ...inventory.hi,
    ...business.hi,
  },
});

/** Marker export — keeps the side-effect import tree-shaking-safe and
 *  gives tests a value to assert against. */
export const APP_I18N_FRAGMENT = true as const;
