import { landing } from "./domains/landing";
import { auth } from "./domains/auth";
import { wizard } from "./domains/wizard";
import { dashboard } from "./domains/dashboard";
import { site } from "./domains/site";
import { admin } from "./domains/admin";
import { store } from "./domains/store";
import { inventory } from "./domains/inventory";
import { features } from "./domains/features";
import { business } from "./domains/business";
import { common } from "./domains/common";

/**
 * Ashrilogic — ROUND 172b — the FULLY composed dictionary snapshot.
 *
 * TOOLING ONLY (scripts, verification, CI): never import this from
 * application code — it statically composes every domain (the exact graph
 * the registry split removed from the landing's critical path). Use
 * `t()` from "@/lib/i18n" (registry) plus the fragments/app import at
 * your surface's entry, instead.
 */
const AR = { ...landing.ar, ...auth.ar, ...wizard.ar, ...dashboard.ar, ...site.ar, ...admin.ar, ...store.ar, ...inventory.ar, ...features.ar, ...business.ar, ...common.ar };
const EN = { ...landing.en, ...auth.en, ...wizard.en, ...dashboard.en, ...site.en, ...admin.en, ...store.en, ...inventory.en, ...features.en, ...business.en, ...common.en };
const HI = { ...landing.hi, ...auth.hi, ...wizard.hi, ...dashboard.hi, ...site.hi, ...admin.hi, ...store.hi, ...inventory.hi, ...features.hi, ...business.hi, ...common.hi };

/** The complete dictionaries (the pre-split I18N export, unchanged). */
export const I18N = { ar: AR, en: EN, hi: HI } as const;
