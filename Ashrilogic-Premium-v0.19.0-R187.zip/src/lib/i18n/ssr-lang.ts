import { createContext, useContext } from "react";
import type { Lang } from "@/lib/types";

/**
 * Ashrilogic — ROUND 185 — the SSR language context.
 *
 * THE BUG this module kills: every landing "use client" island that
 * resolves its text through useT() reads the ZUSTAND store, whose SSR
 * value is the hardcoded default "ar" (the server has no localStorage).
 * For a visitor whose language is EN/HI/FR the server therefore painted
 * the whole interactive shell in ARABIC and swapped it after hydration
 * (~seconds on a cold load) — the "Arabic first, then my language"
 * flash, plus a tab title that stayed Arabic until useDocumentTitle ran.
 *
 * THE FIX (zero hydration mismatch, zero flash): the SERVER page knows
 * the visitor's language (the ashrlc-lang cookie — resolveLandingLang).
 * It hands that language to SsrLangProvider (src/components/ssr-lang-
 * provider.tsx), a client boundary around the page's tree. The provider
 * supplies this context with the SERVER value for the SSR pass AND the
 * hydration pass (so first client render === server HTML — React never
 * sees a mismatch), then flips its value to the store language after
 * mount (steady state — identical whenever cookie and localStorage agree,
 * which the R185 setLang cookie-mirror guarantees).
 *
 * useT() prefers this context when a provider is present; surfaces
 * without one (dashboard / admin / site trees rendered outside the public
 * pages' providers) keep exactly the old behavior (pure store language).
 *
 * Deliberately a SEPARATE module (not inside registry.ts) so the provider
 * component can import the context without pulling the whole dictionary
 * graph, and so registry.ts stays free of component imports. React-only
 * imports — safe on the server and the client.
 */

/** undefined = no provider above → useT() falls back to the store language. */
export const SsrLangContext = createContext<Lang | undefined>(undefined);

/** Read the server-provided language, when a provider is mounted. */
export function useSsrLang(): Lang | undefined {
  return useContext(SsrLangContext);
}
