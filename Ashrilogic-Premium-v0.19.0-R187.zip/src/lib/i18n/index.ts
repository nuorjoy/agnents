/**
 * Ashrilogic — typed AR/EN/HI dictionary (public API).
 *
 * ROUND 172b (performance): this module is now a byte-compatible FACADE
 * over the registry (src/lib/i18n/registry.ts). The composed dictionaries
 * are SPLIT — the static fragment (landing + common + features, the keys
 * the landing SSR tree evaluates) lives in the registry itself; the eight
 * heavy domains register on demand from
 * src/lib/i18n/fragments/app.ts at the entry of every surface that
 * renders them. See the registry header for the full architecture note.
 *
 * The public API is unchanged for every consumer:
 *   - `t()` / `useT()` / `I18nKey` — same signatures, same fallbacks;
 *   - the locale-helper re-exports below are the same as before.
 *
 * Scripts that need the FULLY composed dictionaries (e.g.
 * scripts/verify-i18n-usage.ts) import the domain modules directly — they
 * never went through this facade; a complete snapshot is also available
 * at src/lib/i18n/all.ts for tooling.
 */
/* ROUND 185 — useT moved to ./use-t (a "use client" module: the hook now
 * reads the SSR language context, and createContext cannot execute inside
 * server-shared modules). Same signature, same behavior without a
 * provider — pure re-export, zero call-site churn. */
export { t, registerI18nFragment, isStaticI18nKey, type I18nKey, type I18nFragment } from "./registry";
export { useT } from "./use-t";

/* Locale helpers (10-language registry) — re-exported for convenience. */
export { LOCALES, localeMeta, dirFor, intlLocale, localeNativeLabel, localeShortLabel, nextLocale } from "@/lib/locales";
