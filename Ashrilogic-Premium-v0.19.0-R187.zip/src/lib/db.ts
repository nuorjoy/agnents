import { PrismaClient } from "@prisma/client";

/**
 * Ashrilogic — PostgreSQL database runtime.
 *
 * ARCHITECTURE: PostgreSQL is the platform's ONLY database engine. The
 * single Prisma schema (prisma/schema.prisma, provider "postgresql") is
 * the source of truth; the generated client under @prisma/client binds to
 * DATABASE_URL directly. JSON payloads stay in JSON-string text columns
 * (validated with Zod on read) — a deliberate representation preserved
 * from the SQLite era; see the schema header.
 *
 * CONNECTION URL CONTRACT: DATABASE_URL must be a PostgreSQL connection
 * string ("postgresql://…" / "postgres://…"). A missing or unparseable
 * value is a hard configuration error — no silent fallback, no guessing.
 *
 * HISTORY: the pre-cutover runtime detected the provider from DATABASE_URL
 * (file:… → SQLite, postgres://… → the generated pg-client mirror). The
 * cutover removed the SQLite client, the mirror schema, and the migration
 * control plane; legacy SQLite DATA is imported by the one-time operator
 * tool scripts/migrate-sqlite-to-postgres.ts.
 *
 * ROUND 167 (build safety) — THE LAZY SINGLETON: `next build` imports every
 * route module during page-data collection, and on Vercel the production
 * environment variables are RUNTIME-ONLY by default — importing this
 * module at build time used to run the URL assert at module scope and fail
 * the whole deployment ("Failed to collect page data"). The client is now
 * constructed on FIRST USE through a Proxy: importing `db` is inert (build
 * never needs a connection), while the very first query still fails fast
 * with the SAME hard configuration error the assert has always thrown —
 * the contract moved from import-time to first-use-time, nothing softened.
 */

/** Validate the connection URL once at first use — provider drift is a
 *  configuration error, never a runtime surprise deep in a request. */
export function assertPostgresUrl(rawUrl: string | undefined): string {
  const url = (rawUrl ?? "").trim();
  if (!/^postgres(ql)?:\/\//i.test(url)) {
    throw new Error(
      `DATABASE_URL is not a PostgreSQL connection string (expected "postgres://…" or "postgresql://…"): ${
        url ? "unparseable value" : "not set"
      }`
    );
  }
  return url;
}

/* --------------------------- client construction --------------------------- */

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

/** Construct the real client exactly once (the URL assert rides along —
 *  the first query is the earliest moment a connection could ever matter). */
function resolveClient(): PrismaClient {
  if (!globalForPrisma.prisma) {
    assertPostgresUrl(process.env.DATABASE_URL);
    globalForPrisma.prisma = new PrismaClient();
  }
  return globalForPrisma.prisma;
}

/**
 * The platform's database handle — a lazy Proxy over the singleton.
 * Property access (a query, $transaction, $disconnect…) resolves the real
 * client first; the Proxy itself never stores state so the cached
 * globalThis instance stays the single source of truth.
 */
export const db: PrismaClient = new Proxy({} as PrismaClient, {
  get(_target: PrismaClient, prop: string | symbol): unknown {
    const client = resolveClient() as unknown as Record<string | symbol, unknown>;
    const value = client[prop];
    return typeof value === "function" ? (value as (...args: unknown[]) => unknown).bind(client) : value;
  },
});
