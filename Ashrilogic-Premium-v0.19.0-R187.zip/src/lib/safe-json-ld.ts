/**
 * Ashrilogic — safe JSON-LD serialization (round 36 security hardening).
 *
 * `JSON.stringify` alone does NOT make a value safe to interpolate into a
 * `<script type="application/ld+json">` block: `<`, `>`, `&` are emitted
 * verbatim, so a user-controlled value like `</script><script>alert(1)</script>`
 * breaks out of the script context → stored XSS. The JSON spec also forbids
 * raw U+2028/U+2029 line separators inside JS string literals.
 *
 * `safeJsonLd` escapes every dangerous sequence to its JSON-legal unicode
 * escape form — the JSON document stays byte-identical for parsers, but can
 * never terminate the surrounding script element. EVERY JSON-LD emission in
 * the app routes through this helper.
 */
export function safeJsonLd(value: unknown): string {
  return JSON.stringify(value)
    .replace(/</g, "\\u003c")
    .replace(/>/g, "\\u003e")
    .replace(/&/g, "\\u0026")
    .replace(/\u2028/g, "\\u2028")
    .replace(/\u2029/g, "\\u2029");
}
