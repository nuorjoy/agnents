import { readFile } from "node:fs/promises";
import path from "node:path";
import type { ReactElement, ReactNode } from "react";

/**
 * Ashrilogic — dynamic Open-Graph image foundation (R183).
 *
 * Branded social cards for /systems/[id] (static catalog — zero DB) and
 * /blog/[slug] (one lean column-narrowed read). WhatsApp is the dominant
 * sharing channel in this platform's market, so every article and every
 * system page deserves its own card instead of inheriting the one static
 * /og.png.
 *
 * FONTS: satori needs explicit font binaries and accepts TTF/OTF/WOFF (NOT
 * woff2). The site already ships Cairo (Arabic + Latin, OFL) through
 * @fontsource, so the exact BRAND typeface is copied once into
 * public/og-fonts/ (3 × ~20KB) and read from disk — self-contained in the
 * release ZIP, no node_modules dependency at image-render time.
 *
 * Visual identity follows the landing's ink-violet aesthetic (deep
 * #150f2e→#1c1440 ground, violet #6d5dfb→#8b5cf6 accents, Cairo 800) —
 * the cards must read as the same product the shared /og.png advertises.
 */

/** The OG canvas contract (Open-Graph standard landscape card). */
export const OG_WIDTH = 1200;
export const OG_HEIGHT = 630;

/** Brand tokens (mirrors the landing palette — globals.css / grad()). */
export const OG_BRAND = {
  inkFrom: "#150f2e",
  inkTo: "#1c1440",
  violetFrom: "#6d5dfb",
  violetTo: "#8b5cf6",
  text: "#ffffff",
  subtext: "#c7c3e8",
  chipBg: "rgba(139,92,246,0.18)",
  chipBorder: "rgba(139,92,246,0.45)",
  hairline: "rgba(199,195,232,0.25)",
} as const;

interface OgFont {
  name: string;
  data: ArrayBuffer;
}

/** Module-scope cache — the woff binaries are read once per server
 * process, not per image request (fonts are immutable assets). */
let cachedFonts: OgFont[] | null = null;

function toArrayBuffer(buf: Buffer): ArrayBuffer {
  return buf.buffer.slice(
    buf.byteOffset,
    buf.byteOffset + buf.byteLength,
  ) as ArrayBuffer;
}

/** Load the Cairo weights used by the cards (800 display + 500 body). */
export async function loadOgFonts(): Promise<OgFont[]> {
  if (cachedFonts) return cachedFonts;
  const dir = path.join(process.cwd(), "public", "og-fonts");
  const [arabic800, latin800, arabic500] = await Promise.all([
    readFile(path.join(dir, "cairo-arabic-800.woff")),
    readFile(path.join(dir, "cairo-latin-800.woff")),
    readFile(path.join(dir, "cairo-arabic-500.woff")),
  ]);
  cachedFonts = [
    { name: "CairoArabic800", data: toArrayBuffer(arabic800) },
    { name: "CairoLatin800", data: toArrayBuffer(latin800) },
    { name: "CairoArabic500", data: toArrayBuffer(arabic500) },
  ];
  return cachedFonts;
}

/** Font-family stacks for inline styles (weight 800 display faces). */
export const OG_FONT_AR = "CairoArabic800, CairoLatin800";
export const OG_FONT_EN = "CairoLatin800, CairoArabic800";
export const OG_FONT_AR_BODY = "CairoArabic500";

/**
 * The shared card SHELL — the full-bleed ink gradient ground, the hairline
 * frame and the brand footer strip every card closes with. satori needs
 * everything inline-styled (no Tailwind) and every multi-child node must be
 * a flex container; the returned nodes embed the caller's children between
 * the top chip row and the footer.
 */
export function ogCardShell(
  top: ReturnType<typeof ogChipRow>,
  children: ReactNode[],
  opts: { accentFrom?: string; accentTo?: string } = {},
): ReactElement {
  const accentFrom = opts.accentFrom ?? OG_BRAND.violetFrom;
  const accentTo = opts.accentTo ?? OG_BRAND.violetTo;
  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        padding: "64px 72px 44px 72px",
        backgroundImage: `linear-gradient(135deg, ${OG_BRAND.inkFrom} 0%, ${OG_BRAND.inkTo} 58%, ${accentFrom}22 100%)`,
        fontFamily: OG_FONT_AR,
        color: OG_BRAND.text,
      }}
    >
      {/* top chip row (category / blog badge) */}
      {top}

      {/* body */}
      <div style={{ display: "flex", flexDirection: "column" }}>
        {children}
      </div>

      {/* brand footer */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          borderTop: `1px solid ${OG_BRAND.hairline}`,
          paddingTop: "22px",
        }}
      >
        <div style={{ display: "flex", flexDirection: "column" }}>
          <div style={{ display: "flex", fontSize: 30, fontWeight: 800 }}>
            أشرِيلوجيك
          </div>
          <div
            style={{
              display: "flex",
              fontFamily: OG_FONT_EN,
              fontSize: 19,
              color: OG_BRAND.subtext,
            }}
          >
            Ashrilogic — Unified Business Platform
          </div>
        </div>
        <div
          style={{
            display: "flex",
            width: 88,
            height: 8,
            borderRadius: 999,
            backgroundImage: `linear-gradient(90deg, ${accentFrom}, ${accentTo})`,
          }}
        />
      </div>
    </div>
  );
}

/** A single rounded chip (satori has no border-radius shorthand issues at
 * this size; background rgba keeps it readable on any accent). */
export function ogChip(
  text: string,
  opts: { fontFamily?: string; fontSize?: number } = {},
): ReactElement {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        padding: "10px 22px",
        borderRadius: 999,
        backgroundColor: OG_BRAND.chipBg,
        border: `2px solid ${OG_BRAND.chipBorder}`,
        fontSize: opts.fontSize ?? 22,
        fontWeight: 800,
        color: "#e7e4fb",
        fontFamily: opts.fontFamily ?? OG_FONT_AR,
      }}
    >
      {text}
    </div>
  );
}

/** The horizontal chip row (up to 3 chips; satori has no flex-wrap!). */
export function ogChipRow(
  chips: { text: string; fontFamily?: string }[],
): ReactElement {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
      {chips.slice(0, 3).map((chip) => (
        <div key={chip.text} style={{ display: "flex" }}>
          {ogChip(chip.text, chip)}
        </div>
      ))}
    </div>
  );
}

/** Long text truncation — satori has no line-clamp; pure JS clip keeps the
 * layout deterministic for any localized title length. */
export function ogClip(text: string, max: number): string {
  if (text.length <= max) return text;
  return `${text.slice(0, max - 1).trimEnd()}…`;
}
