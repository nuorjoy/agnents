/**
 * Ashrilogic — shared Arabic-aware fuzzy matcher.
 *
 * Extracted from `src/components/landing/systems-library.tsx` (Task 5-b) so
 * the landing search box AND the global command palette share ONE matching
 * implementation — no duplicated stemming logic.
 *
 * Matching model (identical to the landing search behavior):
 * - full normalized substring match, OR
 * - per-token stem match (AND across query tokens, OR against haystack tokens)
 *   where stemming strips the Arabic definite article (ال/وال/بال/…) and
 *   common plural / possessive suffixes (ات/ون/ين/ان/ية/ه/ة/ي/…), with an
 *   alef-insensitive equality fallback (covers broken plurals like
 *   فنادق/فندق and صيدلية/الصيدليات).
 */
import { normalizeSearch } from "@/lib/utils";

/** Split normalized text into word tokens (Arabic letters, latin, digits). */
const TOKEN_SPLIT = /[^\u0621-\u064Aa-z0-9]+/;

const AR_PREFIX = /^(وال|بال|كال|فال|لل|ال)/;
const AR_SUFFIX = /(ات|ون|ين|ان|يه|ية|ه|ة|ي|ها|هم|هن|كم|كن|نا)$/;

/** Light stemmer: strip the definite article + common endings (≥3-char guard). */
export function stemToken(token: string): string {
  let t = token.replace(AR_PREFIX, "");
  for (let round = 0; round < 2; round++) {
    const next = t.replace(AR_SUFFIX, "");
    if (next.length >= 3 && next !== t) t = next;
    else break;
  }
  return t;
}

/** Tokenize (and stem) normalized text. */
export function tokenize(text: string): string[] {
  return text.split(TOKEN_SPLIT).filter(Boolean).map(stemToken);
}

/** Token-level match: equality, prefix (≥ 3 chars) or alef-insensitive equality. */
export function stemMatch(haystackStem: string, queryStem: string): boolean {
  if (haystackStem === queryStem) return true;
  if (queryStem.length >= 3 && haystackStem.startsWith(queryStem)) return true;
  if (haystackStem.length >= 3 && queryStem.startsWith(haystackStem)) return true;
  const ha = haystackStem.replace(/\u0627/g, "");
  const qa = queryStem.replace(/\u0627/g, "");
  return qa.length >= 3 && ha === qa;
}

/** Pre-computed searchable index entry for a haystack. */
export interface SearchEntry {
  /** normalized full text (substring matching) */
  full: string;
  /** stemmed tokens (token matching) */
  stems: string[];
}

/** Build a search index entry from arbitrary text. */
export function buildSearchEntry(text: string): SearchEntry {
  const full = normalizeSearch(text);
  return { full, stems: tokenize(full) };
}

/**
 * Match a query against a haystack (pre-indexed entry or raw text).
 * Empty queries match everything.
 */
export function arabicMatches(entry: SearchEntry | string, query: string): boolean {
  const qFull = normalizeSearch(query);
  if (!qFull) return true;
  const haystack: SearchEntry = typeof entry === "string" ? buildSearchEntry(entry) : entry;
  if (haystack.full.includes(qFull)) return true;
  const qStems = tokenize(qFull);
  return qStems.length > 0 && qStems.every((q) => haystack.stems.some((h) => stemMatch(h, q)));
}
