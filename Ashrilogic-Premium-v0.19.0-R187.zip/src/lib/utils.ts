import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import type { Lang } from "@/lib/types"
import { intlLocale } from "@/lib/locales"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Arabic-aware search normalization:
 * - strips tashkeel (diacritics) & tatweel
 * - unifies alef variants (أ إ آ ٱ → ا)
 * - unifies ya/alef-maqsura (ى → ي)
 * - unifies ta-marbuta/ha (ة → ه)
 * - strips zero-width chars
 */
export function normalizeArabic(input: string): string {
  return input
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670\u0640]/g, "") // harakat + tatweel
    .replace(/[\u0622\u0623\u0625\u0627\u0671]/g, "\u0627") // alef variants
    .replace(/\u0649/g, "\u064A") // alef maqsura -> ya
    .replace(/\u0629/g, "\u0647") // ta marbuta -> ha
    .replace(/[\u200B-\u200F\uFEFF\u061C]/g, "") // zero-width & marks
    .replace(/\s+/g, " ")
    .trim()
}

/** Normalize latin text for search: lowercase, collapse spaces */
export function normalizeLatin(input: string): string {
  return input.toLowerCase().replace(/\s+/g, " ").trim()
}

/** Combined searchable haystack normalizer (AR + EN safe) */
export function normalizeSearch(input: string): string {
  return normalizeArabic(input)
}

/** hex -> rgba() string. `alpha` 0..1 */
export function hexAlpha(hex: string, alpha: number): string {
  const h = hex.replace("#", "")
  const full = h.length === 3 ? h.split("").map((c) => c + c).join("") : h
  const r = parseInt(full.slice(0, 2), 16)
  const g = parseInt(full.slice(2, 4), 16)
  const b = parseInt(full.slice(4, 6), 16)
  return `rgba(${r}, ${g}, ${b}, ${alpha})`
}

/** CSS linear-gradient from two hex colors */
export function grad(c1: string, c2: string, deg = 135): string {
  return `linear-gradient(${deg}deg, ${c1}, ${c2})`
}

/** Deterministic pseudo-random number from a seed string (stable SSR/CSR stats) */
export function seededRandom(seed: string): () => number {
  let h = 1779033703 ^ seed.length
  for (let i = 0; i < seed.length; i++) {
    h = Math.imul(h ^ seed.charCodeAt(i), 3432918353)
    h = (h << 13) | (h >>> 19)
  }
  return () => {
    h = Math.imul(h ^ (h >>> 16), 2246822507)
    h = Math.imul(h ^ (h >>> 13), 3266489909)
    h ^= h >>> 16
    return (h >>> 0) / 4294967296
  }
}

/** Format a number with locale-aware grouping (Arabic-Indic digits for AR,
 *  native digits/separators for every other locale — see src/lib/locales.ts) */
export function fmtNum(n: number, lang: Lang = "en"): string {
  return new Intl.NumberFormat(intlLocale(lang)).format(n)
}

/* ------------------------------------------------------------------ */
/* ROUND 133 — full Arabic RTL display policy for money cells          */
/* ROUND 134 — IDs render in WESTERN digits (1..0) in EVERY locale     */
/* ------------------------------------------------------------------ */

/**
 * The direction a formatted number/money cell should render in: RTL
 * when the UI is Arabic (Arabic-Indic digits + the Arabic comma read
 * right-to-left, currency suffix lands on the LEFT — the Arabic reading
 * convention), LTR for every Latin-digit locale.
 */
export function numDir(lang: Lang): "rtl" | "ltr" {
  return lang === "ar" ? "rtl" : "ltr"
}

/**
 * ROUND 134 — the direction an IDENTIFIER cell renders in: always LTR.
 * Record/shift/POS/expense codes are stored canonical ASCII
 * ("SHF-00000002", "POS-00061028", "EXP-00039001") and the owner's
 * directive is explicit: «اجعل جميع الـIDs تحمل الأرقام (1,2,3,4,5,6,7,8,9,0)
 * بدلاً عن الأرقام (١،٢،٣،٤،٥،٦،٧،٨،٩،٠)» — Western digits, read
 * left-to-right, in EVERY system and EVERY locale. Money/quantity stat
 * cells keep the ROUND-133 Arabic-Indic RTL policy (numDir); only the
 * ID surface flipped.
 */
export const idDir = "ltr" as const

/** Western digits → Arabic-Indic digits (٠١٢٣٤٥٦٧٨٩).
 * ROUND 134: NO LONGER used for identifiers (fmtId passes codes through
 * verbatim); kept for the non-ID Arabic-numeral surfaces that still
 * localize (date-cell fallbacks). */
const ARABIC_DIGITS = "٠١٢٣٤٥٦٧٨٩"
export function toArabicDigits(text: string): string {
  return text.replace(/[0-9]/g, (d) => ARABIC_DIGITS[Number(d)])
}

/**
 * Format a record identifier for display. ROUND 134: the owner's
 * directive flipped the ID policy — every ID carries WESTERN digits
 * (1,2,3,4,5,6,7,8,9,0) in all systems and all locales, exactly as
 * stored (canonical ASCII, unique + immutable, server-enforced). The
 * `lang` parameter is kept for call-site compatibility and semantic
 * documentation: it never rewrites the digits anymore. Pair with
 * {@link idDir} for the cell direction (always LTR).
 */
export function fmtId(code: string, _lang: Lang = "en"): string {
  return code
}

/** Format a money-ish cell with the unified Arabic-Indic policy (up to 2
 *  decimals), optionally suffixed with the currency code. Arabic renders
 *  "٤١١٫١٥ ر.س"-style RTL (dir comes from {@link numDir}). */
export function fmtMoneyCell(value: number, lang: Lang = "en", currency?: string): string {
  const n = new Intl.NumberFormat(intlLocale(lang), {
    maximumFractionDigits: 2,
  }).format(Number.isFinite(value) ? value : 0)
  return currency ? `${n} ${currency}` : n
}

/** initials avatar letter */
export function initial(name: string): string {
  return (name || "A").trim().charAt(0).toUpperCase()
}

/**
 * Arabic script must never be letter-spaced — tracking gaps break the natural
 * glyph joining and read as broken typography. This helper returns the right
 * tracking class for uppercase micro-labels rendered in both languages.
 */
export function labelTrack(lang: Lang): string {
  return lang === "ar" ? "tracking-normal" : "tracking-wider"
}

/**
 * Copy text to the clipboard with a graceful fallback chain:
 * async Clipboard API -> hidden-textarea execCommand -> reject.
 * Resolves when the text made it to the clipboard, rejects otherwise.
 */
export async function copyText(text: string): Promise<void> {
  if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(text)
      return
    } catch {
      /* fall through to the execCommand path (non-secure context / no permission) */
    }
  }
  if (typeof document === "undefined") {
    throw new Error("clipboard unavailable")
  }
  const ta = document.createElement("textarea")
  ta.value = text
  ta.setAttribute("readonly", "")
  ta.style.position = "fixed"
  ta.style.top = "-1000px"
  ta.style.opacity = "0"
  document.body.appendChild(ta)
  ta.focus()
  ta.select()
  let ok = false
  try {
    ok = document.execCommand("copy")
  } catch {
    ok = false
  }
  document.body.removeChild(ta)
  if (!ok) throw new Error("clipboard unavailable")
}
