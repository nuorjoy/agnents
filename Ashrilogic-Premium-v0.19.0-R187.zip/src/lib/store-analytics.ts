/**
 * Ashrilogic — ROUND 53 (store analytics).
 *
 * Pure, client-safe aggregation over the owner's storefront order queue.
 * The E-Store dashboard already holds the full order list (react-query
 * "instance-orders" — the same cached feed the order queue renders), so the
 * top-products insight is derived ENTIRELY client-side: zero new API surface,
 * zero new schema, one source of truth.
 *
 * All money here is DISPLAY units (the order DTO converts minor→display at
 * the API boundary); totals are summed with cent rounding to keep float
 * noise out of the UI.
 */

import type { SiteOrderAdminDTO } from "@/lib/types";

/** One ranked product line (display units). */
export interface TopProductLine {
  recordId: string;
  name: string;
  /** total units ordered across counted orders */
  qty: number;
  /** revenue in display units (unit price × qty, summed per line) */
  revenue: number;
  /** how many distinct orders carried this product */
  orderCount: number;
}

/** Momentum summary comparing the last 7 days to the prior 7. */
export interface SalesMomentum {
  /** counted (non-cancelled) orders placed in the last 7 days */
  last7: number;
  /** counted (non-cancelled) orders placed in days 8–14 */
  prev7: number;
  /** signed ratio in (-1, +1): (last7 - prev7) / max(prev7, 1) */
  delta: number;
}

/** An order that never converts to revenue (excluded from analytics). */
const EXCLUDED_STATUS = "cancelled";

/** Counted revenue + bestseller lines from the owner order queue.
 *
 * Aggregates per recordId (the module-record identity — product names can
 * repeat across rows; ids never do). Ties break by revenue then qty then
 * name so the ranking is deterministic (test-friendly).
 */
export function aggregateTopProducts(
  orders: SiteOrderAdminDTO[],
  limit = 5
): TopProductLine[] {
  const acc = new Map<string, TopProductLine>();
  for (const order of orders) {
    if (order.status === EXCLUDED_STATUS) continue;
    for (const item of order.items) {
      const line = acc.get(item.recordId) ?? {
        recordId: item.recordId,
        name: item.name,
        qty: 0,
        revenue: 0,
        orderCount: 0,
      };
      line.qty += item.qty;
      line.revenue += Math.round(item.price * item.qty * 100) / 100;
      line.orderCount += 1;
      acc.set(item.recordId, line);
    }
  }
  return [...acc.values()]
    .sort(
      (a, b) =>
        b.qty - a.qty ||
        b.revenue - a.revenue ||
        b.orderCount - a.orderCount ||
        a.name.localeCompare(b.name)
    )
    .slice(0, Math.max(1, limit));
}

/** Total counted (non-cancelled) revenue in display units. */
export function countedRevenue(orders: SiteOrderAdminDTO[]): number {
  return (
    Math.round(
      orders
        .filter((o) => o.status !== EXCLUDED_STATUS)
        .reduce((sum, o) => sum + o.total, 0) * 100
    ) / 100
  );
}

/** Last-7-days vs prior-7-days order momentum (cancelled excluded).
 * `now` is injectable so tests pin the window edges deterministically. */
export function salesMomentum(
  orders: SiteOrderAdminDTO[],
  now: Date = new Date()
): SalesMomentum {
  const msDay = 24 * 60 * 60 * 1000;
  const nowMs = now.getTime();
  let last7 = 0;
  let prev7 = 0;
  for (const order of orders) {
    if (order.status === EXCLUDED_STATUS) continue;
    const age = nowMs - new Date(order.createdAt).getTime();
    if (age < 0) continue; // future-dated rows are not momentum signal
    if (age < 7 * msDay) last7 += 1;
    else if (age < 14 * msDay) prev7 += 1;
  }
  const delta = (last7 - prev7) / Math.max(prev7, 1);
  return { last7, prev7, delta };
}

/** One calendar day of counted sales (display units). */
export interface DailySalesBucket {
  /** local calendar day start, formatted YYYY-MM-DD (stable UI key) */
  day: string;
  /** counted (non-cancelled) orders placed that day */
  orders: number;
  /** counted revenue in display units (cent-rounded) */
  revenue: number;
}

/** ROUND 54 — aggregate counted sales per calendar day over the trailing
 * `days` window (cancelled excluded; future-dated rows ignored).
 *
 * Day boundaries use LOCAL time (the owner thinks in their own calendar) and
 * `now` is injectable so tests pin window edges deterministically. The result
 * is ALWAYS exactly `days` buckets ending today — days with zero sales are
 * included as zero buckets (the chart shows the gap, not a hole). */
export function aggregateDailySales(
  orders: SiteOrderAdminDTO[],
  days = 14,
  now: Date = new Date()
): DailySalesBucket[] {
  const count = Math.min(Math.max(Math.min(days, 90), 1), 90);
  const round = (v: number) => Math.round(v * 100) / 100;

  /* local-calendar day key for an instant */
  const dayKey = (d: Date) => {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  };

  /* trailing `count` local day keys, oldest → newest, ending today */
  const keys: string[] = [];
  for (let back = count - 1; back >= 0; back--) {
    const d = new Date(now);
    d.setDate(d.getDate() - back);
    keys.push(dayKey(d));
  }
  const byKey = new Map<string, DailySalesBucket>(keys.map((day) => [day, { day, orders: 0, revenue: 0 }]));

  const todayStart = new Date(now);
  todayStart.setHours(0, 0, 0, 0);
  const windowStartMs = todayStart.getTime() - (count - 1) * 24 * 60 * 60 * 1000;

  for (const order of orders) {
    if (order.status === EXCLUDED_STATUS) continue;
    const at = new Date(order.createdAt).getTime();
    if (at < windowStartMs || at > now.getTime()) continue; // outside the window / future-dated
    const bucket = byKey.get(dayKey(new Date(order.createdAt)));
    if (!bucket) continue; // cannot happen (dayKey of an in-window instant is a key)
    bucket.orders += 1;
    bucket.revenue = round(bucket.revenue + order.total);
  }

  return keys.map((day) => byKey.get(day)!);
}
