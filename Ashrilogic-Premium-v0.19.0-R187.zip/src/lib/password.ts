/**
 * Ashrilogic — ROUND 138 — the ONE shared SECURE PASSWORD GENERATOR.
 *
 * Owner directive (security review): the registration wizard's admin-step
 * and the Super Admin subscriber-governance dialog both minted tenant-admin
 * passwords from `Math.random`:
 *   • wizard/steps/admin-step.tsx — 3 syllables × 12 + 2 digits + 1 symbol
 *     ≈ 933,120 possibilities (≈ 20 bits): cracked in seconds;
 *   • admin/subscriber-governance.tsx — the first 4 characters (one per
 *     class, FIXED order, never shuffled) came from Math.random; only the
 *     remaining 8 used crypto (with `% pool.length` modulo bias).
 *
 * This module is the single replacement for both call sites:
 *   • ALL randomness comes from the platform CSPRNG via
 *     `crypto.getRandomValues` (WebCrypto — available in every browser
 *     context AND Bun/Node ≥ 19; NOT `Math.random`, ever);
 *   • UNBIASED selection via REJECTION SAMPLING — a 32-bit draw is only
 *     accepted when it falls inside the largest multiple of the alphabet
 *     size that fits in 2^32; every other draw is discarded and re-drawn
 *     (the modulo-bias tail is refused, not clamped);
 *   • every character class is GUARANTEED (≥ 1 upper, 1 lower, 1 digit,
 *     1 symbol) and the result is SHUFFLED with a crypto Fisher–Yates so
 *     the guaranteed characters never sit in predictable positions;
 *   • the alphabet is UNAMBIGUOUS (no I/O/0/1/l) so a hand-copied or
 *     read-aloud password cannot be mistyped;
 *   • FAILS CLOSED: when `crypto.getRandomValues` is unavailable the
 *     generator THROWS — it NEVER silently degrades to Math.random.
 *
 * Output contract: length 12 default (59-char pool → ≈ 70.5 bits of
 * entropy) always satisfies PASSWORD_RE (≥ 8 chars, letter + digit) and
 * the UI strength meter's top tier (4 classes, ≥ 10 chars).
 *
 * Client-safe module: no server imports, no side effects, pure functions.
 */

/** Uppercase Latin letters without the ambiguous I / O. */
const UPPER = "ABCDEFGHJKLMNPQRSTUVWXYZ";

/** Lowercase Latin letters without the ambiguous l. */
const LOWER = "abcdefghijkmnopqrstuvwxyz";

/** Digits without the ambiguous 0 / 1. */
const DIGITS = "23456789";

/** Keyboard-safe symbols (no quotes / backslash / grave — copy-safe). */
const SYMBOLS = "!@#$%&*";

/** The full unambiguous pool (24 + 24 + 8 + 7 = 59 characters). */
const POOL = UPPER + LOWER + DIGITS + SYMBOLS;

/** Minimum supported length: 4 guaranteed class characters. */
export const MIN_GENERATED_PASSWORD_LENGTH = 4;

/** One CSPRNG uint32 draw — the single non-null read point. */
function drawUint32(): number {
  const c = globalThis.crypto;
  if (!c || typeof c.getRandomValues !== "function") {
    /* FAIL CLOSED — a missing CSPRNG must never degrade to Math.random. */
    throw new Error(
      "cryptoRandomInt: crypto.getRandomValues is unavailable in this environment"
    );
  }
  const buf = new Uint32Array(1);
  c.getRandomValues(buf);
  return buf[0]!;
}

/**
 * Uniform integer in [0, max) drawn from the platform CSPRNG using
 * rejection sampling (no modulo bias). `max` must be a positive integer.
 *
 * The 32-bit draws are consumed one at a time; the acceptance window is
 * `floor(2^32 / max) * max`, so the accepted region is an exact multiple
 * of `max` — every index is equally likely by construction.
 */
export function cryptoRandomInt(max: number): number {
  if (!Number.isInteger(max) || max <= 0) {
    throw new Error("cryptoRandomInt: max must be a positive integer");
  }
  if (max === 1) return 0;

  /* Largest multiple of max that fits in 2^32 — draws ≥ limit are rejected. */
  const LIMIT = 2 ** 32 - (2 ** 32 % max);
  let draw = drawUint32();
  let guard = 0;
  while (draw >= LIMIT) {
    draw = drawUint32();
    if (++guard > 64) {
      /* Unreachable for any sane alphabet (rejection probability ≤ 50%
       * per draw); a hard stop guarantees the generator always terminates. */
      throw new Error("cryptoRandomInt: rejection sampling failed to converge");
    }
  }
  return draw % max;
}

/** One unbiased character pick from `set` (charAt never yields undefined). */
function pickFrom(set: string): string {
  return set.charAt(cryptoRandomInt(set.length));
}

/**
 * The shared strong password generator (owner directive ROUND 138).
 *
 * Guarantees per call:
 *   • exactly `length` characters (default 12) from the 59-char pool;
 *   • at least one character from EVERY class (upper / lower / digit /
 *     symbol) — satisfies PASSWORD_RE and the strength meter's top tier;
 *   • characters shuffled with a crypto Fisher–Yates — the guaranteed
 *     class characters never sit in fixed positions 0–3;
 *   • every character selected via rejection-sampled CSPRNG draws.
 */
export function generateSecurePassword(length = 12): string {
  if (
    !Number.isInteger(length) ||
    length < MIN_GENERATED_PASSWORD_LENGTH ||
    length > 128
  ) {
    throw new Error(
      `generateSecurePassword: length must be an integer between ${MIN_GENERATED_PASSWORD_LENGTH} and 128`
    );
  }

  /* Guarantee every class, then fill the rest from the full pool. */
  const chars: string[] = [
    pickFrom(UPPER),
    pickFrom(LOWER),
    pickFrom(DIGITS),
    pickFrom(SYMBOLS),
  ];
  for (let i = chars.length; i < length; i++) {
    chars.push(pickFrom(POOL));
  }

  /* Crypto Fisher–Yates — destroys the fixed 0–3 class ordering. */
  for (let i = chars.length - 1; i > 0; i--) {
    const j = cryptoRandomInt(i + 1);
    if (i === j) continue;
    const atI = chars[i] as string;
    const atJ = chars[j] as string;
    chars[i] = atJ;
    chars[j] = atI;
  }

  return chars.join("");
}
