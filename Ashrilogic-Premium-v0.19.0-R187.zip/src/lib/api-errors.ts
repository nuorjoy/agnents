"use client";

/**
 * Ashrilogic — ROUND 46 (F-7) — localized API error presentation.
 *
 * API routes return English error strings (server convention) plus a
 * machine-readable `code` (ApiError.code). The Arabic-first UI must never
 * surface raw English to the end user, so mutation handlers translate KNOWN
 * codes through the i18n dictionary and fall back to the server message for
 * anything unmapped (never a blank).
 *
 * Numeric details embedded in the English message (plan module/user caps)
 * are extracted and interpolated into the localized sentence.
 */
import { ApiError } from "@/lib/api-client";
import type { I18nKey } from "@/lib/i18n";

type TFn = (key: I18nKey, vars?: Record<string, string | number>) => string;

const CODE_KEYS: Record<string, I18nKey> = {
  PACKAGE_ADMIN_ONLY: "errPACKAGE_ADMIN_ONLY",
  PLAN_MODULE_LIMIT: "errPLAN_MODULE_LIMIT",
  PLAN_USER_LIMIT: "errPLAN_USER_LIMIT",
  PACKAGE_NOT_FOUND: "errPACKAGE_NOT_FOUND",
  INSTANCE_STALE: "errINSTANCE_STALE",
  /* ROUND 156 — INSTANCE_AUTH: surfaces when assertInstanceSession returns
   * the 401 «Workspace sign-in required» (no/revoked workspace cookie). */
  INSTANCE_AUTH: "errINSTANCE_AUTH",
  /* workspace password rotation proof-of-knowledge */
  PASSWORD_REQUIRED: "errPASSWORD_REQUIRED",
  PASSWORD_MISMATCH: "errPASSWORD_MISMATCH",
  /* ROUND 134 — the shifts toggle cannot strand an open cashier drawer */
  SHIFT_OPEN_MUST_CLOSE: "errSHIFT_OPEN_MUST_CLOSE",
  /* R163 — strict e-store ⇄ catalog coupling (store cannot run without its
   * product-source modules — removal guard + sourceless activation gate) */
  STORE_MODULE_REQUIRED: "errSTORE_MODULE_REQUIRED",
  /* ROUND 47 — trial lockdown + billing order errors */
  TRIAL_EXPIRED: "errTRIAL_EXPIRED",
  /* ROUND 81 — platform governance ban (subscriber suspension) */
  BANNED: "errBANNED",
  STORAGE_QUOTA_EXCEEDED: "errSTORAGE_QUOTA",
  ORDER_INTEGRITY: "errORDER_INTEGRITY",
  ORDER_EXPIRED: "errORDER_EXPIRED",
  ORDER_NOT_PENDING: "errORDER_NOT_PENDING",
  PAYMENT_METHOD_UNAVAILABLE: "errPAYMENT_METHOD",
  ORDER_NOT_FOUND: "errPACKAGE_NOT_FOUND",
  /* ROUND 144/145 (145-fix-qual) — the wallet-TRANSFER + PIN-proof paths
   * (wallet controller + wallet.ts engine + shifts routes). Every code
   * those surfaces can answer now resolves to a localized message instead
   * of the raw English server string. Semantically identical EXISTING
   * keys are reused — no duplicated messages:
   *   PIN_INVALID / PIN_NOT_SET / WALLET_SELF / WALLET_NOT_FOUND /
   *   INSUFFICIENT_FUNDS → the ROUND-144 wtr* transfer-dialog keys;
   *   RATE_LIMITED → acctErrRate (the generic throttled message);
   *   PASSWORD_INVALID → errPASSWORD_MISMATCH (identical wording);
   *   SHIFT_CODE_NOT_SET / SHIFT_CODE_INVALID / SHIFT_ALREADY_OPEN → the
   *   shifts-bar keys; NO_OPEN_SHIFT → shiftWsOpenNowEmpty;
   *   SHIFTS_MODULE_DISABLED → shiftWsModuleOff.
   * Only the six errTRANSFER / errWALLET / errOWNER_ONLY keys are new. */
  PIN_INVALID: "wtrPinInvalidErr",
  PIN_NOT_SET: "wtrPinNotSetErr",
  INSUFFICIENT_FUNDS: "wtrInsufficientErr",
  WALLET_SELF: "wtrSelfErr",
  WALLET_NOT_FOUND: "wtrNotFoundErr",
  RATE_LIMITED: "acctErrRate",
  OWNER_ONLY: "errOWNER_ONLY",
  WALLET_CONFLICT: "errWALLET_CONFLICT",
  WALLET_CAP: "errWALLET_CAP",
  /* the raw dual-numeral amount parse failures (EMPTY/MALFORMED/NEGATIVE/
   * DECIMALS/TOO_LARGE) plus the engine's non-integer guard — one message */
  TRANSFER_AMOUNT: "errTRANSFER_AMOUNT",
  TRANSFER_EMPTY: "errTRANSFER_AMOUNT",
  TRANSFER_MALFORMED: "errTRANSFER_AMOUNT",
  TRANSFER_NEGATIVE: "errTRANSFER_AMOUNT",
  TRANSFER_DECIMALS: "errTRANSFER_AMOUNT",
  TRANSFER_TOO_LARGE: "errTRANSFER_AMOUNT",
  TRANSFER_MIN: "errTRANSFER_MIN",
  TRANSFER_MAX: "errTRANSFER_MAX",
  /* the shifts routes (PUT shifts/code + POST shifts open/close) */
  PASSWORD_INVALID: "errPASSWORD_MISMATCH",
  SHIFT_CODE_NOT_SET: "shiftOpenNotSet",
  SHIFT_CODE_INVALID: "shiftOpenWrong",
  SHIFT_ALREADY_OPEN: "shiftOpenAlready",
  NO_OPEN_SHIFT: "shiftWsOpenNowEmpty",
  SHIFTS_MODULE_DISABLED: "shiftWsModuleOff",
};

/** first integer embedded in a sentence ("at most 10 enabled" → "10") */
function embeddedNumber(message: string): string | undefined {
  const match = message.match(/(\d+)/);
  return match ? match[1] : undefined;
}

/** Localized, user-ready message for any thrown API error. */
export function apiErrorText(error: unknown, t: TFn): string {
  if (error instanceof ApiError && error.code) {
    const key = CODE_KEYS[error.code];
    if (key) {
      const max = embeddedNumber(error.message);
      return t(key, max ? { max } : undefined);
    }
  }
  if (error instanceof Error && error.message) return error.message;
  return t("errGenericAction");
}
