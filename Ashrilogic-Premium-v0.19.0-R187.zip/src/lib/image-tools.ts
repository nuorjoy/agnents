"use client";

import type { Lang } from "@/lib/types";
import { intlLocale } from "@/lib/locales";

/**
 * Ashrilogic — client-side image analysis + compression (round 29).
 *
 * A shared, dependency-free utility used by every photo/logo uploader:
 *  1. VALIDATE the MIME type against an allowlist;
 *  2. DECODE the image (catches corrupted files the browser cannot parse);
 *  3. ANALYZE the result (natural dimensions, aspect, original bytes);
 *  4. COMPRESS deterministically — contain-fit onto a transparent square
 *     canvas, re-encode, and if the output still exceeds the target bytes,
 *     retry with lower quality then a smaller canvas;
 *  5. RETURN the analysis so the UI can show it BEFORE the image is
 *     approved ("تحليل الصورة قبل اعتمادها").
 *
 * The output is a compact data-URL sized for JSON storage (text
 * column) — large originals (up to 10MB) are accepted at the door and
 * professionally reduced on the way in.
 */

export const IMAGE_MIME_RE = /^image\/(png|jpe?g|webp|gif)$/;

/** human-readable byte size, locale aware (Arabic-Indic numerals for AR,
 *  native digits for every other locale). */
export function formatBytes(bytes: number, lang: Lang): string {
  const kb = bytes / 1024;
  const mb = kb / 1024;
  const ar = lang === "ar";
  let value: string;
  let unit: string;
  if (mb >= 1) {
    value = (Math.round(mb * 10) / 10).toFixed(1);
    unit = ar ? "ميجابايت" : "MB";
  } else {
    value = String(Math.max(1, Math.round(kb)));
    unit = ar ? "كيلوبايت" : "KB";
  }
  if (lang !== "en") {
    try {
      value = new Intl.NumberFormat(intlLocale(lang)).format(Number(value));
    } catch {
      /* keep western digits */
    }
  }
  return `${value} ${unit}`;
}

export interface AnalyzedImage {
  /** compressed, square data-URL ready for storage */
  dataUrl: string;
  /** natural source dimensions */
  srcWidth: number;
  srcHeight: number;
  /** output canvas size (square) */
  outSize: number;
  /** original file size in bytes */
  originalBytes: number;
  /** compressed payload size in bytes */
  outBytes: number;
  /** source mime type */
  mime: string;
  /** true when the source was already square (±2px) */
  square: boolean;
}

export class ImageAnalysisError extends Error {
  constructor(
    public readonly code:
      | "bad-type"
      | "too-large"
      | "corrupt"
      | "tiny"
      | "encode-failed"
  ) {
    super(code);
  }
}

export interface AnalyzeOptions {
  /** max accepted ORIGINAL file size (bytes) — 10MB by default */
  maxInputBytes?: number;
  /** reject sources smaller than this (both dimensions) */
  minDimension?: number;
  /** output square canvas edge */
  outputSize?: number;
  /** keep PNG/GIF as PNG (preserves transparency), flatten others to JPEG */
  outputSizeSmall?: number;
  /** max stored data-URL payload (bytes of the binary payload) */
  targetBytes?: number;
}

const KB = 1024;

/**
 * Analyze + compress an image file. Throws {@link ImageAnalysisError} with a
 * stable code the UI maps to a localized message.
 */
export async function analyzeImage(
  file: File,
  options: AnalyzeOptions = {}
): Promise<AnalyzedImage> {
  const {
    maxInputBytes = 10 * 1024 * 1024,
    minDimension = 64,
    outputSize = 320,
    outputSizeSmall = 192,
    targetBytes = 420 * KB,
  } = options;

  if (!IMAGE_MIME_RE.test(file.type)) throw new ImageAnalysisError("bad-type");
  if (file.size > maxInputBytes) throw new ImageAnalysisError("too-large");

  /* decode — a corrupted file rejects and surfaces "corrupt" */
  const objectUrl = URL.createObjectURL(file);
  let img: HTMLImageElement;
  try {
    img = await loadImage(objectUrl);
  } catch {
    throw new ImageAnalysisError("corrupt");
  } finally {
    URL.revokeObjectURL(objectUrl);
  }

  const srcWidth = img.naturalWidth;
  const srcHeight = img.naturalHeight;
  if (!srcWidth || !srcHeight) throw new ImageAnalysisError("corrupt");
  if (srcWidth < minDimension || srcHeight < minDimension) {
    throw new ImageAnalysisError("tiny");
  }

  /* PNG/GIF keep transparency (PNG out); raster photos compress best as JPEG */
  const keepAlpha = file.type === "image/png" || file.type === "image/gif";
  const outMime = keepAlpha ? "image/png" : "image/jpeg";

  /* quality ladder for JPEG; PNG has no quality dial so the size ladder applies */
  const qualityLadder = keepAlpha ? [undefined] : [0.92, 0.8, 0.68, 0.55];
  const sizeLadder = [outputSize, outputSizeSmall, Math.max(96, outputSizeSmall / 2)];

  let last: { dataUrl: string; size: number } | null = null;
  outer: for (const size of sizeLadder) {
    for (const quality of qualityLadder) {
      const dataUrl = renderSquare(img, size, outMime, quality);
      if (!dataUrl) throw new ImageAnalysisError("encode-failed");
      const bytes = estimateDataUrlBytes(dataUrl);
      last = { dataUrl, size: bytes };
      if (bytes <= targetBytes) break outer;
    }
  }
  /* the final attempt is always accepted (it is the smallest we can make) */
  if (!last) throw new ImageAnalysisError("encode-failed");

  return {
    dataUrl: last.dataUrl,
    srcWidth,
    srcHeight,
    outSize: sizeLadder[0],
    originalBytes: file.size,
    outBytes: last.size,
    mime: file.type,
    square: Math.abs(srcWidth - srcHeight) <= 2,
  };
}

/** Load an HTMLImageElement from a blob/object URL (rejects on decode failure). */
function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("decode failed"));
    img.src = src;
  });
}

/** Contain-fit the image onto a transparent square canvas and encode it. */
function renderSquare(
  img: HTMLImageElement,
  size: number,
  mime: string,
  quality: number | undefined
): string | null {
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");
  if (!ctx) return null;
  /* scale to fit, centered (transparent padding keeps the whole logo) */
  const scale = Math.min(size / img.naturalWidth, size / img.naturalHeight);
  const w = Math.max(1, Math.round(img.naturalWidth * scale));
  const h = Math.max(1, Math.round(img.naturalHeight * scale));
  const x = Math.round((size - w) / 2);
  const y = Math.round((size - h) / 2);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(img, x, y, w, h);
  try {
    return quality === undefined
      ? canvas.toDataURL(mime)
      : canvas.toDataURL(mime, quality);
  } catch {
    return null;
  }
}

/** Approximate the binary payload size of a base64 data-URL. */
function estimateDataUrlBytes(dataUrl: string): number {
  const comma = dataUrl.indexOf(",");
  if (comma < 0) return dataUrl.length;
  const base64 = dataUrl.length - comma - 1;
  return Math.round((base64 * 3) / 4);
}
