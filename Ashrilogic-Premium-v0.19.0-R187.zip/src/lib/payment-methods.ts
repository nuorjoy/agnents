/**
 * Ashrilogic — ROUND 141 (directive ㉕): PAYMENT MANAGEMENT — the canonical
 * 7-method registry shared by the record dialogs (sales + POS + purchases —
 * the supplier side), the record detail sheet, and the print view.
 *
 * The owner's directive: every business record supports precisely these
 * payment methods:
 *   نقدي      cash      — paid in cash
 *   بطاقة     card      — card / network (مدى …)
 *   تحويل     bank      — bank transfer
 *   محفظة     ewallet   — electronic wallet (بنكك، أورنج …)
 *   مختلط     mixed     — SEVERAL methods in one settlement (the split rows)
 *   جزئي      partial   — a PARTIAL payment now + the remaining balance
 *   آجل       payable   — on account: a future settlement date (dueAt)
 *
 * STORAGE LAW: a record's structured ledger rides ModuleRecord.paymentsJson
 * (PaymentEntry[] ≤4, amounts in MINOR units); the preset's legacy `method`
 * CELL keeps carrying the PRIMARY label so the existing analytics breakdown,
 * the detail sheet, and the print view keep working verbatim.
 *
 * PURE module — no db, no next/server (importable from both sides).
 */

export const PAYMENT_KINDS = [
  "cash",
  "card",
  "bank",
  "ewallet",
  "mixed",
  "partial",
  "payable",
] as const;
export type PaymentKind = (typeof PAYMENT_KINDS)[number];

/** One structured payment row on a record. */
export interface PaymentEntry {
  method: PaymentKind;
  /** the settled amount in MINOR units (absent = the full record total) */
  amountMinor?: number;
  /** free-form note (e.g. the bank reference) */
  note?: string;
  /** the future settlement date (payable) — ISO date (YYYY-MM-DD) */
  dueAt?: string;
}

export interface PaymentMethodMeta {
  /** the canonical Arabic label (what the legacy method cell carries) */
  ar: string;
  en: string;
  icon: string;
  c1: string;
  c2: string;
}

/** The bilingual registry (the single source — the three legacy duplicated
 *  POS option lists now derive from this). */
export const PAYMENT_METHOD_META: Record<PaymentKind, PaymentMethodMeta> = {
  cash: { ar: "نقداً", en: "Cash", icon: "banknote", c1: "#10b981", c2: "#047857" },
  card: { ar: "بطاقة", en: "Card", icon: "credit-card", c1: "#6d5dfb", c2: "#8b5cf6" },
  bank: { ar: "تحويل بنكي", en: "Bank transfer", icon: "landmark", c1: "#0ea5e9", c2: "#0369a1" },
  ewallet: { ar: "محفظة إلكترونية", en: "E-wallet", icon: "wallet", c1: "#f59e0b", c2: "#d97706" },
  mixed: { ar: "دفع مختلط", en: "Mixed", icon: "layers", c1: "#8b5cf6", c2: "#7c3aed" },
  partial: { ar: "دفعة جزئية", en: "Partial", icon: "circle-dashed", c1: "#f59e0b", c2: "#b45309" },
  payable: { ar: "آجل", en: "Payable", icon: "calendar-clock", c1: "#f43f5e", c2: "#be123c" },
};

/** The quick-picker option list (POS terminal + the classic method cell):
 *  the four settled kinds in canonical order. */
export const QUICK_PAYMENT_OPTIONS: string[] = [
  PAYMENT_METHOD_META.cash.ar,
  PAYMENT_METHOD_META.card.ar,
  PAYMENT_METHOD_META.bank.ar,
  PAYMENT_METHOD_META.ewallet.ar,
];

/** Max structured entries per record (mixed splits bounded). */
export const PAYMENT_ENTRIES_MAX = 4;

export function isPaymentKind(value: string): value is PaymentKind {
  return (PAYMENT_KINDS as readonly string[]).includes(value);
}

/** The primary label for the legacy method cell (the first entry wins;
 *  empty ledger = "" — the record keeps whatever the cell already had). */
export function paymentsPrimaryLabel(entries: PaymentEntry[] | null | undefined): string {
  if (!entries || entries.length === 0) return "";
  const first = entries[0];
  return PAYMENT_METHOD_META[first.method]?.ar ?? "";
}

/** The settlement summary computed from the structured ledger + the record
 *  total (minor units): paid so far, remaining, the payable due date, and
 *  whether the balance is overdue. */
export interface PaymentSummary {
  paidMinor: number;
  remainingMinor: number;
  fullyPaid: boolean;
  dueAt: string | null;
  overdue: boolean;
}

export function summarizePayments(
  entries: PaymentEntry[] | null | undefined,
  totalMinor: number
): PaymentSummary {
  if (!entries || entries.length === 0) {
    return { paidMinor: totalMinor, remainingMinor: 0, fullyPaid: true, dueAt: null, overdue: false };
  }
  let paid = 0;
  let dueAt: string | null = null;
  for (const entry of entries) {
    if (typeof entry.amountMinor === "number" && Number.isFinite(entry.amountMinor)) {
      paid += entry.amountMinor;
    } else if (entry.method !== "payable" && entry.method !== "partial") {
      /* a settled method with no explicit amount = the full total */
      paid = totalMinor;
    }
    if (entry.dueAt) dueAt = entry.dueAt;
  }
  const paidClamped = Math.min(Math.max(Math.round(paid), 0), Math.max(totalMinor, 0));
  const remaining = Math.max(totalMinor - paidClamped, 0);
  const overdue =
    dueAt !== null && remaining > 0 && new Date(`${dueAt}T23:59:59`).getTime() < Date.now();
  return {
    paidMinor: paidClamped,
    remainingMinor: remaining,
    fullyPaid: remaining === 0,
    dueAt,
    overdue,
  };
}

/** Parse a stored paymentsJson (fail-soft: corrupt rows read as no ledger). */
export function parsePaymentsJson(raw: string | null | undefined): PaymentEntry[] {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    const out: PaymentEntry[] = [];
    for (const row of parsed.slice(0, PAYMENT_ENTRIES_MAX)) {
      if (typeof row !== "object" || row === null) continue;
      const e = row as Record<string, unknown>;
      if (typeof e.method !== "string" || !isPaymentKind(e.method)) continue;
      const entry: PaymentEntry = { method: e.method };
      if (typeof e.amountMinor === "number" && Number.isFinite(e.amountMinor)) {
        entry.amountMinor = Math.max(0, Math.round(e.amountMinor));
      }
      if (typeof e.note === "string" && e.note.trim()) entry.note = e.note.trim().slice(0, 120);
      if (typeof e.dueAt === "string" && /^\d{4}-\d{2}-\d{2}$/.test(e.dueAt)) entry.dueAt = e.dueAt;
      out.push(entry);
    }
    return out;
  } catch {
    return [];
  }
}
