/**
 * Ashrilogic — accent themes for the public websites linked to provisioned
 * systems (round 24). Pure data shared by the server (site mapper validation)
 * and the client (theme picker + public site rendering) — no imports.
 *
 * Round 25: every website now MATCHES its system — the category registry maps
 * each of the 15 sectors to its best-fitting theme, and ships localized
 * default service cards so a fresh draft already speaks the system's language.
 */
export type SiteThemeKey =
  | "aurora"
  | "emerald"
  | "sunset"
  | "royal"
  | "ocean"
  | "crimson"
  | "rose"
  | "lime"
  | "fuchsia"
  | "graphite"
  | "teal"
  | "green"
  | "orange"
  | "pink"
  | "sky"
  | "yellow"
  | "bronze"
  | "forest"
  | "wine"
  | "sapphire";

export interface SiteThemeDef {
  /** registry key stored in Site.theme */
  key: SiteThemeKey;
  labelAr: string;
  labelEn: string;
  /** gradient start / end, hex */
  c1: string;
  c2: string;
}

export const SITE_THEME_KEYS = [
  "aurora",
  "emerald",
  "sunset",
  "royal",
  "ocean",
  "crimson",
  "rose",
  "lime",
  "fuchsia",
  "graphite",
  "teal",
  "green",
  "orange",
  "pink",
  "sky",
  "yellow",
  "bronze",
  "forest",
  "wine",
  "sapphire",
] as const satisfies readonly SiteThemeKey[];

export const SITE_THEMES = [
  { key: "aurora", labelAr: "أورورا", labelEn: "Aurora", c1: "#6d5dfb", c2: "#0ea5e9" },
  { key: "emerald", labelAr: "زمردي", labelEn: "Emerald", c1: "#10b981", c2: "#65a30d" },
  { key: "sunset", labelAr: "غروب", labelEn: "Sunset", c1: "#f59e0b", c2: "#f43f5e" },
  { key: "royal", labelAr: "ملكي", labelEn: "Royal", c1: "#a855f7", c2: "#ec4899" },
  { key: "ocean", labelAr: "محيطي", labelEn: "Ocean", c1: "#0ea5e9", c2: "#14b8a6" },
  /* ROUND 88 — five new accents (owner directive: more colors). The
     site/store surfaces derive their brand ramp from c1 via accentVars()
     (color-mix), so two hex values per theme are all that is needed. */
  { key: "crimson", labelAr: "قرمزي", labelEn: "Crimson", c1: "#ef4444", c2: "#991b1b" },
  { key: "rose", labelAr: "وردي", labelEn: "Rose", c1: "#f43f5e", c2: "#be123c" },
  { key: "lime", labelAr: "ليموني", labelEn: "Lime", c1: "#84cc16", c2: "#3f6212" },
  { key: "fuchsia", labelAr: "فوشي", labelEn: "Fuchsia", c1: "#d946ef", c2: "#86198f" },
  { key: "graphite", labelAr: "غرافيت", labelEn: "Graphite", c1: "#64748b", c2: "#0f172a" },
  /* ROUND 129 (owner directive: «أضف ١٠ ألوان Premium جديدة») — the SAME
     ten accents the workspace dash registry gained, mirrored here so the
     public-site and store pickers stay in lockstep with the system theme. */
  { key: "teal", labelAr: "تركوازي", labelEn: "Teal", c1: "#14b8a6", c2: "#0f766e" },
  { key: "green", labelAr: "أخضر حيوي", labelEn: "Vivid Green", c1: "#22c55e", c2: "#15803d" },
  { key: "orange", labelAr: "برتقالي", labelEn: "Orange", c1: "#f97316", c2: "#c2410c" },
  { key: "pink", labelAr: "زهري", labelEn: "Pink", c1: "#ec4899", c2: "#be185d" },
  { key: "sky", labelAr: "سماوي", labelEn: "Sky", c1: "#0ea5e9", c2: "#0369a1" },
  { key: "yellow", labelAr: "ذهبي", labelEn: "Golden", c1: "#eab308", c2: "#a16207" },
  { key: "bronze", labelAr: "برونزي", labelEn: "Bronze", c1: "#c99741", c2: "#85541e" },
  { key: "forest", labelAr: "أخضر غابات", labelEn: "Forest", c1: "#2f8f5b", c2: "#164f32" },
  { key: "wine", labelAr: "نبيتي", labelEn: "Wine", c1: "#b93a63", c2: "#6d1335" },
  { key: "sapphire", labelAr: "ياقوتي", labelEn: "Sapphire", c1: "#3b78d2", c2: "#234a8c" },
] as const satisfies readonly SiteThemeDef[];

const FALLBACK_THEME: SiteThemeDef = SITE_THEMES[0];

/** Resolve a theme by key (fail-soft → aurora). */
export function siteTheme(key: string): SiteThemeDef {
  return SITE_THEMES.find((theme) => theme.key === key) ?? FALLBACK_THEME;
}

/**
 * Category → best-matching theme. A website auto-inherits the visual
 * identity of ITS system's sector (health = emerald, education = royal, …)
 * when the draft is created — the owner can still pick any theme later.
 */
const CATEGORY_THEME: Record<string, SiteThemeKey> = {
  health: "emerald",
  education: "royal",
  retail: "sunset",
  hospitality: "sunset",
  services: "aurora",
  finance: "ocean",
  logistics: "ocean",
  agriculture: "emerald",
  industry: "aurora",
  media: "royal",
  hr: "aurora",
  fun: "sunset",
  legal: "ocean",
  nonprofit: "emerald",
  general: "aurora",
};

/** The theme that matches a system's category (fail-soft → aurora). */
export function categoryTheme(categoryId: string | undefined): SiteThemeKey {
  if (!categoryId) return "aurora";
  return CATEGORY_THEME[categoryId] ?? "aurora";
}

/**
 * Curated icon set for site service cards — every key exists in the CatIcon
 * registry (src/lib/icons.ts), so the public site and the editor can render
 * them without extra lookups.
 */
export const SITE_SERVICE_ICONS = [
  "heart-pulse",
  "stethoscope",
  "microscope",
  "pill",
  "ambulance",
  "hospital",
  "graduation-cap",
  "book-open",
  "users",
  "briefcase",
  "shopping-cart",
  "chef-hat",
  "truck",
  "wrench",
  "house",
  "sparkles",
] as const;

/* ------------------------------------------------------------------ */
/* Round 25: system-matched default service cards                       */
/* ------------------------------------------------------------------ */

export interface CategoryServicePreset {
  icon: (typeof SITE_SERVICE_ICONS)[number];
  titleAr: string;
  descAr: string;
  titleEn: string;
  descEn: string;
}

/** Localized starter services per sector — a fresh draft already matches its system. */
export const CATEGORY_SERVICE_PRESETS: Record<string, CategoryServicePreset[]> = {
  health: [
    { icon: "stethoscope", titleAr: "استشارات تخصصية", descAr: "نخبة الاستشاريين في جميع التخصصات", titleEn: "Specialist consultations", descEn: "Top consultants across every specialty" },
    { icon: "microscope", titleAr: "مختبر تحاليل", descAr: "نتائج دقيقة وسريعة بنظام إدارة مختبري", titleEn: "Diagnostic laboratory", descEn: "Fast, accurate lab results" },
    { icon: "pill", titleAr: "صيدلية متكاملة", descAr: "أدوية أصلية مع تتبع المخزون والصلاحية", titleEn: "Full pharmacy", descEn: "Original medicines with expiry tracking" },
    { icon: "ambulance", titleAr: "طوارئ ٢٤ ساعة", descAr: "استجابة فورية على مدار الساعة", titleEn: "24/7 emergency", descEn: "Immediate response around the clock" },
    { icon: "heart-pulse", titleAr: "متابعة الحالات المزمنة", descAr: "خطط علاج ومتابعة دورية للمرضى", titleEn: "Chronic care follow-up", descEn: "Treatment plans and periodic follow-up" },
    { icon: "hospital", titleAr: "قبول وعمليات", descAr: "أسرّة وعمليات مجهزة بأعلى المعايير", titleEn: "Admissions & surgery", descEn: "Beds and operating rooms to standard" },
  ],
  education: [
    { icon: "graduation-cap", titleAr: "برامج أكاديمية", descAr: "مناهج معتمدة لجميع المراحل", titleEn: "Academic programs", descEn: "Accredited curricula for all stages" },
    { icon: "book-open", titleAr: "مكتبة رقمية", descAr: "مصادر تعلم إلكترونية في متناول الطلاب", titleEn: "Digital library", descEn: "E-learning resources for students" },
    { icon: "users", titleAr: "أنشطة طلابية", descAr: "أندية ومسابقات تصنع الشخصية", titleEn: "Student activities", descEn: "Clubs and competitions that build character" },
    { icon: "briefcase", titleAr: "تطوير المعلمين", descAr: "تدريب مستمر على أحدث الممارسات", titleEn: "Teacher development", descEn: "Continuous modern-practice training" },
    { icon: "sparkles", titleAr: "تقارير الأداء", descAr: "متابعة دقيقة لتقدم كل طالب", titleEn: "Performance reports", descEn: "Precise tracking of every student" },
    { icon: "house", titleAr: "التواصل مع أولياء الأمور", descAr: "قنوات مباشرة لمتابعة الأبناء", titleEn: "Parent communication", descEn: "Direct channels to follow your children" },
  ],
  retail: [
    { icon: "shopping-cart", titleAr: "تجربة تسوق متكاملة", descAr: "فروع مجهزة ومنتجات أصلية", titleEn: "Complete shopping experience", descEn: "Equipped branches, original products" },
    { icon: "truck", titleAr: "توصيل سريع", descAr: "طلبك يصلك في الوقت المحدد", titleEn: "Fast delivery", descEn: "Your order arrives on time" },
    { icon: "sparkles", titleAr: "عروض أسبوعية", descAr: "خصومات وبرامج ولاء للمشترين", titleEn: "Weekly offers", descEn: "Discounts and loyalty programs" },
    { icon: "users", titleAr: "خدمة عملاء", descAr: "فريق يخدمك بكل احترافية", titleEn: "Customer service", descEn: "A team serving you professionally" },
    { icon: "briefcase", titleAr: "مشتريات جملة", descAr: "حلول توريد للشركات والمؤسسات", titleEn: "Wholesale supply", descEn: "Supply solutions for businesses" },
    { icon: "house", titleAr: "فروع قريبة منك", descAr: "شبكة فروع تغطي المدينة", titleEn: "Branches near you", descEn: "A branch network covering the city" },
  ],
  hospitality: [
    { icon: "chef-hat", titleAr: "قائمة شيف مميزة", descAr: "أطباق تُعد بعناية من مكونات مختارة", titleEn: "Signature chef menu", descEn: "Dishes crafted from selected ingredients" },
    { icon: "truck", titleAr: "توصيل للمنازل", descAr: "طلبك ساخناً حتى باب منزلك", titleEn: "Home delivery", descEn: "Your order hot at your door" },
    { icon: "sparkles", titleAr: "حجوزات المناسبات", descAr: "أجنحة وقاعات لمناسباتك", titleEn: "Event bookings", descEn: "Suites and halls for your events" },
    { icon: "house", titleAr: "إقامة مريحة", descAr: "غرف مصممة لراحتك وهدوئك", titleEn: "Comfortable stays", descEn: "Rooms designed around your comfort" },
    { icon: "users", titleAr: "خدمة ضيافة", descAr: "فريق يضع تجربتك أولاً", titleEn: "Hospitality service", descEn: "A team putting your experience first" },
    { icon: "briefcase", titleAr: "حلول الشركات", descAr: "اتفاقيات إقامة وضيافة للشركات", titleEn: "Corporate solutions", descEn: "Corporate stay & hospitality agreements" },
  ],
  services: [
    { icon: "sparkles", titleAr: "حجز مواعيد فوري", descAr: "احجز خدمتك أونلاين في ثوانٍ", titleEn: "Instant booking", descEn: "Book your service online in seconds" },
    { icon: "users", titleAr: "خبراء معتمدون", descAr: "فنيون ومتخصصون بشهادات موثوقة", titleEn: "Certified experts", descEn: "Certified technicians and specialists" },
    { icon: "briefcase", titleAr: "عقود مرنة", descAr: "باقات شهرية وسنوية تناسب احتياجك", titleEn: "Flexible contracts", descEn: "Monthly and yearly plans that fit you" },
    { icon: "truck", titleAr: "خدمة ميدانية", descAr: "نصلك أينما كنت", titleEn: "Field service", descEn: "We come to you wherever you are" },
    { icon: "wrench", titleAr: "صيانة دورية", descAr: "خطط صيانة تحمي استثمارك", titleEn: "Periodic maintenance", descEn: "Maintenance plans that protect your investment" },
    { icon: "house", titleAr: "تغطية شاملة", descAr: "خدمات تغطي المدينة بأكملها", titleEn: "City-wide coverage", descEn: "Services covering the entire city" },
  ],
  finance: [
    { icon: "briefcase", titleAr: "محاسبة احترافية", descAr: "قيود دقيقة وتقارير مالية معتمدة", titleEn: "Professional accounting", descEn: "Accurate books, certified statements" },
    { icon: "sparkles", titleAr: "إعداد الضرائب", descAr: "إقرارات ضريبية في وقتها دون غرامات", titleEn: "Tax filing", descEn: "On-time tax returns, zero penalties" },
    { icon: "users", titleAr: "الرواتب والموظفين", descAr: "مسير رواتب متكامل مع المستحقات", titleEn: "Payroll & staff", descEn: "Full payroll with benefits" },
    { icon: "house", titleAr: "تدفق نقدي واضح", descAr: "لوحات تحليلية لحركة السيولة", titleEn: "Clear cash flow", descEn: "Liquidity dashboards at a glance" },
    { icon: "truck", titleAr: "مدفوعات موثوقة", descAr: "ربط بنكي وتسويات تلقائية", titleEn: "Reliable payments", descEn: "Bank feeds and auto reconciliation" },
    { icon: "shopping-cart", titleAr: "متابعة المصروفات", descAr: "ضبط كامل على بنود الإنفاق", titleEn: "Expense tracking", descEn: "Full control over spending" },
  ],
  logistics: [
    { icon: "truck", titleAr: "شحن بري وجوي", descAr: "شبكة نقل تغطي كل المدن", titleEn: "Land & air freight", descEn: "A network covering every city" },
    { icon: "sparkles", titleAr: "تتبع لحظي", descAr: "اعرف مكان شحنتك في أي لحظة", titleEn: "Live tracking", descEn: "Know your shipment's location anytime" },
    { icon: "briefcase", titleAr: "تخليص جمركي", descAr: "إجراءات جمركية بلا تعقيد", titleEn: "Customs clearance", descEn: "Customs without the hassle" },
    { icon: "house", titleAr: "مستودعات مجهزة", descAr: "تخزين آمن بمراقبة كاملة", titleEn: "Equipped warehouses", descEn: "Secure, fully monitored storage" },
    { icon: "users", titleAr: "أسطول وسائقون", descAr: "مركبات حديثة وسائقون مدرّبون", titleEn: "Fleet & drivers", descEn: "Modern vehicles, trained drivers" },
    { icon: "shopping-cart", titleAr: "توصيل المندوبين", descAr: "توصيل باب للباب بسرعة وأمان", titleEn: "Last-mile delivery", descEn: "Fast, safe door-to-door delivery" },
  ],
  agriculture: [
    { icon: "sparkles", titleAr: "إنتاج نوعي", descAr: "محاصيل وثروة حيوانية بأعلى جودة", titleEn: "Premium production", descEn: "Crops and livestock of top quality" },
    { icon: "truck", titleAr: "توريد وتسويق", descAr: "من المزرعة إلى السوق مباشرة", titleEn: "Supply & marketing", descEn: "From farm straight to market" },
    { icon: "heart-pulse", titleAr: "صحة الحيوان", descAr: "متابعة بيطرية دورية للقطيع", titleEn: "Animal health", descEn: "Periodic veterinary follow-up" },
    { icon: "briefcase", titleAr: "استشارات زراعية", descAr: "خبراء زراعة يرافقون موسمك", titleEn: "Agronomy consulting", descEn: "Experts alongside your season" },
    { icon: "house", titleAr: "حلول ريّ ذكية", descAr: "أنظمة ريّ توفر الماء والجهد", titleEn: "Smart irrigation", descEn: "Systems that save water and effort" },
    { icon: "users", titleAr: "تدريب المزارعين", descAr: "برامج تدريب على الممارسات الحديثة", titleEn: "Farmer training", descEn: "Modern-practice training programs" },
  ],
  industry: [
    { icon: "briefcase", titleAr: "مشاريع هندسية", descAr: "من التصميم إلى التسليم بمهنية", titleEn: "Engineering projects", descEn: "From design to handover, professionally" },
    { icon: "wrench", titleAr: "صيانة صناعية", descAr: "خطط صيانة تمنع التوقف", titleEn: "Industrial maintenance", descEn: "Plans that prevent downtime" },
    { icon: "users", titleAr: "فرق فنية", descAr: "مهندسون وفنيون معتمدون", titleEn: "Technical crews", descEn: "Certified engineers and technicians" },
    { icon: "sparkles", titleAr: "ضبط الجودة", descAr: "معايير جودة في كل مرحلة", titleEn: "Quality control", descEn: "Quality standards at every stage" },
    { icon: "truck", titleAr: "توريد وتسليم", descAr: "جدولة توريد دقيقة لمواقعك", titleEn: "Supply & delivery", descEn: "Precise delivery scheduling to your sites" },
    { icon: "house", titleAr: "دراسات مخططات", descAr: "مخططات تنفيذية معتمدة", titleEn: "Drawing studies", descEn: "Certified executive drawings" },
  ],
  media: [
    { icon: "sparkles", titleAr: "حملات إبداعية", descAr: "أفكار تصنع الفرق لعلامتك", titleEn: "Creative campaigns", descEn: "Ideas that make your brand stand out" },
    { icon: "users", titleAr: "إدارة منصات", descAr: "محتوى يوصل لجمهورك الصحيح", titleEn: "Platform management", descEn: "Content that reaches the right audience" },
    { icon: "briefcase", titleAr: "هوية بصرية", descAr: "تصميم هوية تكبر مع أعمالك", titleEn: "Brand identity", descEn: "An identity that grows with you" },
    { icon: "truck", titleAr: "إنتاج وتوزيع", descAr: "من الفكرة إلى النشر بتنظيم واحد", titleEn: "Production & distribution", descEn: "Idea to publish under one roof" },
    { icon: "shopping-cart", titleAr: "تسويق أداء", descAr: "إعلانات مدروسة بعائد مقيس", titleEn: "Performance marketing", descEn: "Measured-return advertising" },
    { icon: "house", titleAr: "استوديو محتوى", descAr: "تصوير ومونتاج بجودة عالية", titleEn: "Content studio", descEn: "High-quality shooting and editing" },
  ],
  hr: [
    { icon: "users", titleAr: "التوظيف المتكامل", descAr: "استقطاب أفضل الكفاءات", titleEn: "End-to-end hiring", descEn: "Attracting the best talent" },
    { icon: "briefcase", titleAr: "رواتب ومزايا", descAr: "مسيرات دقيقة وخطط مزايا عادلة", titleEn: "Payroll & benefits", descEn: "Accurate payroll, fair benefit plans" },
    { icon: "graduation-cap", titleAr: "تدريب وتطوير", descAr: "مسارات تعلم تصنع قادة الغد", titleEn: "Training & development", descEn: "Learning paths that build future leaders" },
    { icon: "sparkles", titleAr: "تقييم الأداء", descAr: "مؤشرات عادلة تقيس الإسهام", titleEn: "Performance appraisal", descEn: "Fair metrics that measure impact" },
    { icon: "house", titleAr: "ثقافة مؤسسية", descAr: "بيئة عمل تجذب وتحتفظ بالأفضل", titleEn: "Company culture", descEn: "A workplace that attracts and retains" },
    { icon: "truck", titleAr: "الالتزام والأنظمة", descAr: "امتثال كامل بأنظمة العمل", titleEn: "Compliance", descEn: "Full labor-law compliance" },
  ],
  fun: [
    { icon: "sparkles", titleAr: "تجارب ترفيهية", descAr: "فعاليات وجلسات لا تُنسى", titleEn: "Entertainment experiences", descEn: "Events and sessions to remember" },
    { icon: "users", titleAr: "عضويات مميزة", descAr: "باقات أعضاء بمزايا حصرية", titleEn: "Premium memberships", descEn: "Member plans with exclusive perks" },
    { icon: "chef-hat", titleAr: "ضيافة كاملة", descAr: "مأكولات ومرطبات ضمن التجربة", titleEn: "Full hospitality", descEn: "Food and drinks within the experience" },
    { icon: "briefcase", titleAr: "فعاليات شركات", descAr: "يوم مؤسسي بمعايير احترافية", titleEn: "Corporate events", descEn: "A professional company day out" },
    { icon: "truck", titleAr: "تنقلات مريحة", descAr: "نقل مجاني من وإلى الموقع", titleEn: "Easy transport", descEn: "Free to/from transfers" },
    { icon: "house", titleAr: "موقع مجهز", descAr: "مرافق حديثة وآمنة للجميع", titleEn: "Fully equipped venue", descEn: "Modern, safe facilities for all" },
  ],
  legal: [
    { icon: "briefcase", titleAr: "استشارات قانونية", descAr: "رأي واضح في أخطر التفاصيل", titleEn: "Legal counsel", descEn: "Clear advice on the finest details" },
    { icon: "users", titleAr: "تمثيل أمام المحاكم", descAr: "ترافع محترف في كل درجات التقاضي", titleEn: "Court representation", descEn: "Professional advocacy at every level" },
    { icon: "sparkles", titleAr: "صياغة العقود", descAr: "عقود تحمي مصالحك بوضوح", titleEn: "Contract drafting", descEn: "Contracts that clearly protect you" },
    { icon: "house", titleAr: "تحكيم ووساطة", descAr: "حلول نزاعات دون طول التقاضي", titleEn: "Arbitration & mediation", descEn: "Dispute resolution without the wait" },
    { icon: "truck", titleAr: "متابعة الجلسات", descAr: "تنبيهات ومتابعة لمواعيد قضائك", titleEn: "Hearing follow-up", descEn: "Alerts and tracking of your dates" },
    { icon: "graduation-cap", titleAr: "تدريب قانوني", descAr: "برامج تأهيل للممارسين الجدد", titleEn: "Legal training", descEn: "Qualification programs for juniors" },
  ],
  nonprofit: [
    { icon: "heart-pulse", titleAr: "برامج إنسانية", descAr: "مبادرات تصل لمستحقيها", titleEn: "Humanitarian programs", descEn: "Initiatives that reach those in need" },
    { icon: "users", titleAr: "تطوع منظم", descAr: "فرق تطوع بإدارة احترافية", titleEn: "Organized volunteering", descEn: "Volunteer teams, professionally run" },
    { icon: "sparkles", titleAr: "جمع التبرعات", descAr: "قنوات جمع شفافة وموثوقة", titleEn: "Fundraising", descEn: "Transparent, trusted channels" },
    { icon: "briefcase", titleAr: "مشاريع تنموية", descAr: "أثر مستدام في المجتمع", titleEn: "Development projects", descEn: "Sustainable community impact" },
    { icon: "house", titleAr: "خدمات المستفيدين", descAr: "تسجيل ومتابعة المستفيدين بنظام", titleEn: "Beneficiary services", descEn: "Systemized registration and follow-up" },
    { icon: "truck", titleAr: "توزيع الإغاثة", descAr: "لوجستيات إغاثة سريعة وفعالة", titleEn: "Relief distribution", descEn: "Fast, effective relief logistics" },
  ],
  general: [
    { icon: "wrench", titleAr: "خدمات صيانة", descAr: "إصلاحات منزلية بضمان", titleEn: "Maintenance services", descEn: "Home repairs with warranty" },
    { icon: "truck", titleAr: "خدمة سريعة", descAr: "استجابة في نفس اليوم", titleEn: "Same-day service", descEn: "Response on the same day" },
    { icon: "users", titleAr: "فنيون معتمدون", descAr: "خبرة موثوقة في كل تخصص", titleEn: "Certified technicians", descEn: "Trusted expertise in every craft" },
    { icon: "sparkles", titleAr: "أسعار واضحة", descAr: "تسعير مسبق بلا مفاجآت", titleEn: "Transparent pricing", descEn: "Upfront pricing, no surprises" },
    { icon: "house", titleAr: "عقود سنوية", descAr: "باقات صيانة دورية للمنازل والشركات", titleEn: "Annual contracts", descEn: "Periodic plans for homes & offices" },
    { icon: "briefcase", titleAr: "أعمال حرفية", descAr: "نجارة وكهرباء وسباكة بإتقان", titleEn: "Craftsmanship", descEn: "Carpentry, electrical, plumbing done right" },
  ],
};
