/**
 * ROUND 167 — توصية ذكية للسعر (the smart price recommendation engine).
 *
 * PURE module — no React, no db, no clock reads: importable from the server
 * AND the client, unit-testable by simply calling it with synthetic tiers
 * (the plan-features.ts law). Deterministic by construction: the same
 * package feed + the same needs ALWAYS produce the same recommendation and
 * the same reasoning numbers — every figure the output card shows traces to
 * a quota or a price the caller supplied («أكثر فهماً وذكاءً»: explainable).
 *
 * THE ALGORITHM (one page, no magic):
 *   1. Purchasable tiers = the live /api/packages rows EXCLUDING
 *      customPricing rows (they carry no amount — the Enterprise tier is
 *      sold through a quote, never a checkout), ordered by priceMonthly.
 *   2. A tier FITS when its quotas satisfy EVERY dimension of the need:
 *      users ≤ maxUsers · modules ≤ maxModules · storage (MB) ≤
 *      maxStorageMb · systems ≤ maxSystems (0 = unlimited).
 *   3. The recommendation is the CHEAPEST fitting tier (the buyer never
 *      pays for headroom they did not ask for). Nothing fits ⇒ the
 *      ENTERPRISE arm: the custom-pricing tier's quotas act as the top fit
 *      and the output carries the per-dimension reasons + the quote CTA.
 *   4. Reasoning metrics are computed for the winner only: cost per needed
 *      user, per-dimension headroom %, the over-budget delta (when a
 *      monthly budget was supplied) and the yearly-cycle saving %.
 */

/** One purchasable-or-custom tier as the engine sees it (a PackageDTO
 *  slice — callers pass the live /api/packages feed directly). */
export interface AdvisorPlanInput {
  id: string;
  nameAr: string;
  nameEn: string;
  /** integer MINOR units (money.ts) — 0 on customPricing rows */
  priceMonthly: number;
  priceYearly: number;
  currency: string;
  maxUsers: number;
  maxModules: number;
  maxStorageMb: number;
  /** 0 = unlimited (the Enterprise law) */
  maxSystems: number;
  customPricing: boolean;
  popular: boolean;
  sortOrder: number;
}

/** The buyer's need (the advisor dialog inputs). `budgetMonthly` is in
 *  MAJOR units (e.g. 12.5 = $12.50) exactly as typed — the engine converts
 *  once to minor units for every comparison. */
export interface AdvisorNeeds {
  /** 1..100 */
  users: number;
  /** 1..200 */
  modules: number;
  /** 1..10 */
  systems: number;
  /** 1..100 GB */
  storageGb: number;
  /** optional monthly budget, MAJOR units (accepts decimals) */
  budgetMonthly?: number;
}

/** The quota dimensions the engine reasons about (order = display order). */
export type AdvisorDimensionKey = "users" | "modules" | "storage" | "systems";

/** One dimension's fit verdict against a specific tier. */
export interface AdvisorDimension {
  key: AdvisorDimensionKey;
  /** the tier's quota in the dimension's natural unit (storage = MB) */
  quota: number;
  /** the need in the same unit */
  needed: number;
  /** floor((quota − needed) / needed × 100) — 0 when exact; capped at 999
   *  for unlimited quotas so a bar can still render */
  headroomPct: number;
  /** quota 0 = unlimited (systems on Enterprise) */
  unlimited: boolean;
  /** did this dimension ALONE fit? */
  fits: boolean;
}

/** The fitting-tier recommendation. */
export interface AdvisorResultFit {
  kind: "fit";
  plan: AdvisorPlanInput;
  /** effective monthly price (integer minor units) */
  monthlyMinor: number;
  /** list yearly price (integer minor units) */
  yearlyMinor: number;
  /** cost per NEEDED user per month (minor units, rounded) */
  costPerUserMinor: number;
  /** round((1 − yearly/(monthly×12)) × 100) — the true annual saving */
  yearlySavingPct: number;
  /** the next tier UP (the one not chosen) — context for the WHY list */
  runnerUp: AdvisorPlanInput | null;
  /** per-dimension fit + headroom (display order) */
  dimensions: AdvisorDimension[];
  /** minor units ABOVE the supplied budget (0 when within; null = no budget) */
  overBudgetMinor: number | null;
}

/** The nothing-fits recommendation (Enterprise quote arm). */
export interface AdvisorResultEnterprise {
  kind: "enterprise";
  /** the custom-pricing tier (when one exists in the feed) — its quotas are
   *  treated as the platform's top fit */
  enterprise: AdvisorPlanInput | null;
  /** why no purchasable tier fit: one entry per FAILING dimension with the
   *  BEST quota any purchasable tier offers (0 = none / unlimited) */
  reasons: {
    key: AdvisorDimensionKey;
    needed: number;
    bestQuota: number;
    bestUnlimited: boolean;
    /** does even the custom tier's quota cover the need? */
    enterpriseCovers: boolean | null;
  }[];
  /** the cheapest purchasable tier that was rejected (price context) */
  cheapestRejected: AdvisorPlanInput | null;
}

export type AdvisorResult = AdvisorResultFit | AdvisorResultEnterprise;

/** GB → MB (the storage quota column is megabytes). */
const MB_PER_GB = 1024;

/** Headroom cap for unlimited quotas — bars need a finite width. */
const UNLIMITED_HEADROOM_PCT = 999;

function dimensionOf(
  key: AdvisorDimensionKey,
  quota: number,
  needed: number,
  unlimitedWhenZero: boolean
): AdvisorDimension {
  const unlimited = unlimitedWhenZero && quota === 0;
  const fits = unlimited || quota >= needed;
  const headroomPct = unlimited
    ? UNLIMITED_HEADROOM_PCT
    : needed > 0
      ? Math.max(0, Math.floor(((quota - needed) / needed) * 100))
      : UNLIMITED_HEADROOM_PCT;
  return { key, quota, needed, fits, headroomPct, unlimited };
}

function dimensionsOf(plan: AdvisorPlanInput, needs: AdvisorNeeds): AdvisorDimension[] {
  return [
    dimensionOf("users", plan.maxUsers, needs.users, false),
    dimensionOf("modules", plan.maxModules, needs.modules, false),
    dimensionOf("storage", plan.maxStorageMb, needs.storageGb * MB_PER_GB, false),
    dimensionOf("systems", plan.maxSystems, needs.systems, true),
  ];
}

/** Does the tier satisfy EVERY dimension? */
function planFits(plan: AdvisorPlanInput, needs: AdvisorNeeds): boolean {
  return dimensionsOf(plan, needs).every((dimension) => dimension.fits);
}

/**
 * The recommendation. `plans` is the LIVE public feed (active tiers);
 * customPricing rows are excluded from the price math and treated as the
 * top fit for the Enterprise arm.
 */
export function recommendPlan(plans: AdvisorPlanInput[], needs: AdvisorNeeds): AdvisorResult {
  const purchasable = plans
    .filter((plan) => !plan.customPricing)
    .sort((a, b) => a.priceMonthly - b.priceMonthly || a.sortOrder - b.sortOrder);
  const enterprise = plans.find((plan) => plan.customPricing) ?? null;

  /* the winner: the CHEAPEST tier that satisfies every dimension */
  const winner = purchasable.find((plan) => planFits(plan, needs)) ?? null;

  if (winner) {
    const winnerIndex = purchasable.findIndex((plan) => plan.id === winner.id);
    const runnerUp =
      winnerIndex >= 0 && winnerIndex + 1 < purchasable.length ? purchasable[winnerIndex + 1] : null;
    const monthlyMinor = winner.priceMonthly;
    const yearlyMinor = winner.priceYearly;
    const costPerUserMinor = needs.users > 0 ? Math.round(monthlyMinor / needs.users) : monthlyMinor;
    const yearlySavingPct =
      monthlyMinor > 0 && yearlyMinor > 0 && yearlyMinor < monthlyMinor * 12
        ? Math.round((1 - yearlyMinor / (monthlyMinor * 12)) * 100)
        : 0;
    const budgetMinor =
      needs.budgetMonthly !== undefined && Number.isFinite(needs.budgetMonthly)
        ? Math.round(needs.budgetMonthly * 100)
        : null;
    const overBudgetMinor =
      budgetMinor !== null ? Math.max(0, monthlyMinor - budgetMinor) : null;
    return {
      kind: "fit",
      plan: winner,
      monthlyMinor,
      yearlyMinor,
      costPerUserMinor,
      yearlySavingPct,
      runnerUp,
      dimensions: dimensionsOf(winner, needs),
      overBudgetMinor,
    };
  }

  /* ---------------- nothing purchasable fits ⇒ the Enterprise arm ---------------- */
  const needed = {
    users: needs.users,
    modules: needs.modules,
    storage: needs.storageGb * MB_PER_GB,
    systems: needs.systems,
  } as const;
  const reasons = (Object.keys(needed) as AdvisorDimensionKey[])
    .map((key) => {
      const need = needed[key];
      const unlimitedWhenZero = key === "systems";
      let bestQuota = 0;
      let bestUnlimited = false;
      for (const plan of purchasable) {
        const quota =
          key === "users"
            ? plan.maxUsers
            : key === "modules"
              ? plan.maxModules
              : key === "storage"
                ? plan.maxStorageMb
                : plan.maxSystems;
        if (unlimitedWhenZero && quota === 0) bestUnlimited = true;
        if (quota > bestQuota) bestQuota = quota;
      }
      const bestFits = bestUnlimited || bestQuota >= need;
      const enterpriseCovers = enterprise
        ? dimensionOf(
            key,
            key === "users"
              ? enterprise.maxUsers
              : key === "modules"
                ? enterprise.maxModules
                : key === "storage"
                  ? enterprise.maxStorageMb
                  : enterprise.maxSystems,
            need,
            unlimitedWhenZero
          ).fits
        : null;
      /* only list the dimension when it is part of WHY nothing fit (the
       * best purchasable tier still fails it) */
      return { key, need, bestQuota, bestUnlimited, bestFits, enterpriseCovers };
    })
    .filter((reason) => !reason.bestFits)
    .map((reason) => ({
      key: reason.key,
      needed: reason.need,
      bestQuota: reason.bestQuota,
      bestUnlimited: reason.bestUnlimited,
      enterpriseCovers: reason.enterpriseCovers,
    }));

  return {
    kind: "enterprise",
    enterprise,
    reasons,
    cheapestRejected: purchasable[0] ?? null,
  };
}
