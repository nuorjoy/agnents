/**
 * Ashrilogic — typed role & permission engine (ROUND 78).
 *
 * The SINGLE SOURCE OF TRUTH for the strict workspace RBAC. The product
 * owner demanded a professional, precise and VERY STRICT permission
 * system; this module is the contract every layer obeys:
 *
 *  - the SERVER enforces it: /api/instances/[id]/* handlers declare the
 *    permission each operation requires and requireInstanceAccess()
 *    (instance-session.ts) refuses principals whose role does not carry
 *    it — 403 PERMISSION_DENIED, audit-logged (deny-by-default: a
 *    principal kind without an explicit grant can never pass).
 *  - the CLIENT reflects it: the فريق الإدارة page's «الأدوار والصلاحيات»
 *    tab renders THIS matrix (never a hand-written copy), the member
 *    profile sheet shows the member's EFFECTIVE permissions from here,
 *    and the owner's "preview as role" lens gates the dashboard views
 *    through the same map.
 *
 * Strictness laws:
 *  1. DENY-BY-DEFAULT — a role only carries what ROLE_MATRIX lists.
 *  2. GOVERNANCE IS OWNER-ONLY — billing, settings, backups and role
 *     management never leave the workspace owner (the historical UI
 *     suggested managers could reach settings; the strict matrix
 *     removes that ambiguity).
 *  3. NO WILDCARDS — every permission id is a literal in PERMISSION_IDS;
 *     TypeScript guarantees the matrix references only real ids.
 *
 * Pure data + pure functions: importable from server routes and client
 * components alike (no db, no cookies, no React).
 */

/* ------------------------------- catalog -------------------------------- */

/** Permission groups — presentation order for the matrix UI. */
export const PERMISSION_GROUPS = [
  "insights",
  "operations",
  "people",
  "governance",
] as const;

export type PermissionGroup = (typeof PERMISSION_GROUPS)[number];

/**
 * The 14 granular workspace permissions. Ids are stable API contracts —
 * never rename one (server routes reference them literally).
 */
export const PERMISSION_IDS = [
  // insights — read the business
  "overview.view", // dashboards, analytics, reports, AI insights
  "activity.view", // the workspace activity trail
  "exports.run", // CSV/data exports
  // operations — run the business
  "modules.view", // open module workspaces and read their records
  "modules.edit", // create / update / delete module records
  "inventory.manage", // stock adjustments, stocktake, reorder actions
  "orders.manage", // e-store orders fulfilment
  "support.manage", // customer inquiries triage (reply / status)
  // people
  "customers.view", // customer accounts, KPIs and history
  "team.view", // the roster and member profiles
  "team.manage", // invite / edit / remove members and their roles
  // governance — owner-only under the strict matrix
  "website.manage", // publish / edit the public site & storefront content
  "billing.manage", // plans, plan orders, billing surfaces
  "settings.manage", // workspace settings, security, backups & restore
] as const;

export type PermissionId = (typeof PERMISSION_IDS)[number];

/** every permission's group (literal mapping — no inference drift). */
export const PERMISSION_META: Record<
  PermissionId,
  { group: PermissionGroup; icon: string; c1: string; c2: string }
> = {
  "overview.view": { group: "insights", icon: "gauge", c1: "#6d5dfb", c2: "#8b5cf6" },
  "activity.view": { group: "insights", icon: "clock-rotate-left", c1: "#0ea5e9", c2: "#0284c7" },
  "exports.run": { group: "insights", icon: "download", c1: "#f59e0b", c2: "#d97706" },
  "modules.view": { group: "operations", icon: "cubes", c1: "#06b6d4", c2: "#0891b2" },
  "modules.edit": { group: "operations", icon: "pencil", c1: "#10b981", c2: "#059669" },
  "inventory.manage": { group: "operations", icon: "boxes", c1: "#14b8a6", c2: "#0d9488" },
  "orders.manage": { group: "operations", icon: "shopping-bag", c1: "#f43f5e", c2: "#be185d" },
  "support.manage": { group: "operations", icon: "headset", c1: "#8b5cf6", c2: "#7c3aed" },
  "customers.view": { group: "people", icon: "users-round", c1: "#0ea5e9", c2: "#0369a1" },
  "team.view": { group: "people", icon: "users", c1: "#6d5dfb", c2: "#d946ef" },
  "team.manage": { group: "people", icon: "user-cog", c1: "#a855f7", c2: "#7e22ce" },
  "website.manage": { group: "governance", icon: "globe", c1: "#f59e0b", c2: "#ea580c" },
  "billing.manage": { group: "governance", icon: "credit-card", c1: "#f43f5e", c2: "#e11d48" },
  "settings.manage": { group: "governance", icon: "sliders", c1: "#64748b", c2: "#334155" },
};

/* -------------------------------- roles --------------------------------- */

export type MemberRole = "manager" | "staff" | "viewer";
/** every principal the workspace can carry (owner = the account owner). */
export type WorkspaceRole = "owner" | MemberRole;

export const WORKSPACE_ROLES: readonly WorkspaceRole[] = ["owner", "manager", "staff", "viewer"];
export const MEMBER_ROLES_STRICT: readonly MemberRole[] = ["manager", "staff", "viewer"];

/**
 * THE strict matrix (deny-by-default). Keep in sync with nothing — this IS
 * the reference; UI and server both read it.
 */
export const ROLE_MATRIX: Record<WorkspaceRole, readonly PermissionId[]> = {
  owner: PERMISSION_IDS,
  manager: [
    "overview.view",
    "activity.view",
    "exports.run",
    "modules.view",
    "modules.edit",
    "inventory.manage",
    "orders.manage",
    "support.manage",
    "customers.view",
    "team.view",
    "website.manage",
  ],
  staff: [
    "overview.view",
    "modules.view",
    "modules.edit",
    "inventory.manage",
    "orders.manage",
    "support.manage",
    "customers.view",
  ],
  viewer: ["overview.view", "modules.view", "customers.view"],
};

/* ------------------------------- helpers -------------------------------- */

/** role → granted permission set (Set for O(1) server checks). */
const ROLE_SETS: Record<WorkspaceRole, ReadonlySet<PermissionId>> = {
  owner: new Set(ROLE_MATRIX.owner),
  manager: new Set(ROLE_MATRIX.manager),
  staff: new Set(ROLE_MATRIX.staff),
  viewer: new Set(ROLE_MATRIX.viewer),
};

/** Strict membership test — the one function both worlds call. */
export function can(role: WorkspaceRole, permission: PermissionId): boolean {
  return ROLE_SETS[role].has(permission);
}

/** The effective permission list of a role (presentation order). */
export function permissionsOf(role: WorkspaceRole): readonly PermissionId[] {
  return ROLE_MATRIX[role];
}

/** granted count / total — matrix headers and role cards. */
export function permissionStats(role: WorkspaceRole): { granted: number; total: number } {
  return { granted: ROLE_SETS[role].size, total: PERMISSION_IDS.length };
}

/**
 * Server-side resolution of a WRITE into the inventory module: the stock
 * surface is guarded by its own dedicated permission ( stricter than the
 * generic modules.edit — a manager may edit records while stocktake stays
 * owner/staff-controlled… both carry it today, but the CONTRACT splits).
 */
export function moduleWritePermission(moduleId: string): PermissionId {
  return moduleId === "inventory" ? "inventory.manage" : "modules.edit";
}

/* --------------------------- dashboard lens ------------------------------ */

/** The permission each dashboard view requires (the preview lens + the
 *  sidebar lock badges). dashView ids, not routes. */
export const VIEW_PERMISSION: Record<string, PermissionId> = {
  overview: "overview.view",
  analytics: "overview.view",
  notifications: "overview.view",
  activity: "activity.view",
  modules: "modules.view",
  module: "modules.view",
  website: "website.manage",
  store: "orders.manage",
  /* ROUND 114 — the order-event webhook console rides the store-integration
     permission (the API routes themselves require orders.manage). */
  webhooks: "orders.manage",
  customers: "customers.view",
  team: "team.view",
  billing: "billing.manage",
  settings: "settings.manage",
  /* ROUND 141 (strict enforcement) — the preview lens now covers the trash
   * console (a settings-class surface) and the Add-ons Store (a billing
   * surface): a role that cannot bill can no longer preview the store. */
  trash: "settings.manage",
  addons: "billing.manage",
};
