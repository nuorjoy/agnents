/**
 * Client-side input shape checks — single source of truth.
 *
 * Previously the email/phone/password regexes were re-declared in ~10
 * component files with drifting behavior (two email variants disagree on
 * the TLD length, two phone variants disagree on allowed separators —
 * validation boundaries must not vary by surface). Server-side validation
 * is stricter and stays in the Zod schemas (instance-mapper.ts,
 * admin-mapper.ts, customer-account.ts) — these regexes are the
 * first-line UX gate only.
 */

/** Email shape: local@domain.tld (display-level check, not RFC 5322). */
export const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/** Phone shape: optional leading +, digits and common separators, 6–20. */
export const PHONE_RE = /^\+?[0-9\s().-]{6,20}$/;

/** Password shape: at least one letter + one digit, 8+ characters. */
export const PASSWORD_RE = /^(?=.*[A-Za-z])(?=.*\d).{8,}$/;
