/**
 * ROUND 87 — the professional benefits library (مكتبة المزايا الاحترافية).
 *
 * The owner demanded a RICHER, STRICTLY professional «المزايا» authoring
 * experience in the Super Admin packages editor: "عند تعديل باقة (المزايا)
 * قم بإضافة المزيد من المزايا بدقة وتأكد أنه صارم جداً".
 *
 * PURE DATA — importable from server and client alike. Two artifacts:
 *
 *   1. BENEFIT_LIBRARY — a curated, categorized catalog of bilingual
 *      (ar/en) marketing lines aligned with the platform's REAL
 *      capabilities (the 16-key PLAN_FEATURES catalog + the operational
 *      traits every tier actually ships). One tap appends the pair to BOTH
 *      the Arabic and the English feature lists, keeping pricing-page
 *      parity by construction.
 *
 *   2. TIER_PRESETS — full professional benefit SETS for the three
 *      standard tiers (starter / professional / enterprise), so a
 *      one-tap "fill" gives a rigorous, well-ordered baseline the admin
 *      can then tailor.
 *
 * Every line respects the strict server contract (2..200 chars, no
 * bullet markers, single spaces) — they pass normalizeFeatureLine as-is.
 */
/* ROUND 145 (145-fix-qual) — type-only import (erased at compile time —
 * the module stays pure data, importable from server and client alike). */
import type { I18nKey } from "@/lib/i18n";

export interface BenefitSuggestion {
  /** the Arabic marketing line (what pricing cards render in ar) */
  ar: string;
  /** the exact English counterpart (rendered in en; keeps 1:1 parity) */
  en: string;
}

export interface BenefitCategory {
  key: "essentials" | "presence" | "commerce" | "intelligence" | "data" | "support";
  /** i18n label key (admin domain — ROUND 145: typed I18nKey) */
  labelKey: I18nKey;
  /** lucide icon name for the category header */
  icon: string;
  items: BenefitSuggestion[];
}

export const BENEFIT_LIBRARY: readonly BenefitCategory[] = [
  {
    key: "essentials",
    labelKey: "pkgLibCatEssentials",
    icon: "layout-dashboard",
    items: [
      { ar: "لوحة تحكم تنفيذية متكاملة", en: "Full executive dashboard" },
      { ar: "معالج إعداد ذكي في ٧ خطوات", en: "Smart 7-step setup wizard" },
      { ar: "واجهة عربية وإنجليزية كاملة", en: "Complete Arabic & English interface" },
      { ar: "دعم فني على مدار الساعة", en: "24/7 technical support" },
      { ar: "تحديثات دورية مجانية للمنصة", en: "Free regular platform updates" },
      { ar: "تدريب مجاني على استخدام النظام", en: "Free system onboarding & training" },
      { ar: "بيانات مستضافة بأمان داخل المنصة", en: "Securely hosted platform data" },
      { ar: "إدارة كاملة للعملاء والموردين", en: "Full customers & suppliers management" },
    ],
  },
  {
    key: "presence",
    labelKey: "pkgLibCatPresence",
    icon: "globe",
    items: [
      { ar: "موقع عام احترافي خاص بنظامك", en: "A professional public website for your system" },
      { ar: "متجر إلكتروني متكامل للمنتجات", en: "Complete e-store for your products" },
      { ar: "صفحة أسعار احترافية للباقات", en: "Professional pricing page" },
      { ar: "تحسين محركات البحث SEO مدمج", en: "Built-in SEO optimization" },
      { ar: "هوية بصرية مخصصة بألوان شركتك", en: "Custom brand identity with your colors" },
      { ar: "نطاق مخصص وربط بالموقع", en: "Custom domain & site linking" },
    ],
  },
  {
    key: "commerce",
    labelKey: "pkgLibCatCommerce",
    icon: "shopping-bag",
    items: [
      { ar: "نظام نقاط بيع POS متكامل", en: "Full point-of-sale (POS) system" },
      { ar: "دعم الباركود وقارئ الماسح الضوئي", en: "Barcode & scanner support" },
      { ar: "برنامج ولاء ومكافآت العملاء", en: "Customer loyalty & rewards program" },
      { ar: "إدارة الاشتراكات والمدفوعات المتكررة", en: "Recurring subscriptions management" },
      { ar: "كوبونات وأكواد خصم للعملاء", en: "Coupons & customer discount codes" },
      { ar: "إدارة الفروع المتعددة من مكان واحد", en: "Multi-branch management in one place" },
      { ar: "إدارة صلاحيات فريق العمل بدقة", en: "Precise staff roles & permissions" },
      { ar: "فواتير وطباعة احترافية بتوقيعك وختمك", en: "Professional invoices with your signature & stamp" },
      { ar: "إدارة المخزون والمستودعات", en: "Inventory & warehouse management" },
      { ar: "إدارة حجوزات ومواعيد العملاء", en: "Customer bookings & appointments" },
    ],
  },
  {
    key: "intelligence",
    labelKey: "pkgLibCatIntelligence",
    icon: "sparkles",
    items: [
      { ar: "تحليلات وتوصيات بالذكاء الاصطناعي", en: "AI-powered insights & recommendations" },
      { ar: "تقارير فورية قابلة للتصدير", en: "Instant exportable reports" },
      { ar: "ترجمة آلية لواجهات النظام والموقع", en: "Automatic system & site translations" },
      { ar: "لوحة مؤشرات أداء KPI مباشرة", en: "Live KPI performance dashboard" },
      { ar: "تنبيهات ذكية للأحداث المهمة", en: "Smart alerts for critical events" },
      { ar: "تقييمات ومراجعات العملاء", en: "Customer reviews & ratings" },
    ],
  },
  {
    key: "data",
    labelKey: "pkgLibCatData",
    icon: "database-backup",
    items: [
      { ar: "نسخ احتياطي يومي آمن للبيانات", en: "Secure daily data backups" },
      { ar: "تصدير البيانات بصيغ متعددة", en: "Multi-format data export" },
      { ar: "سجل تدقيق كامل لكل العمليات", en: "Complete audit trail for every operation" },
      { ar: "حماية البيانات بتشفير كامل", en: "Full data encryption at rest" },
      { ar: "استعادة البيانات عند الطلب", en: "On-demand data restoration" },
      { ar: "أرشفة آمنة للسجلات القديمة", en: "Secure archiving for historical records" },
    ],
  },
  {
    key: "support",
    labelKey: "pkgLibCatSupport",
    icon: "headset",
    items: [
      { ar: "دعم ذو أولوية عالية", en: "High-priority priority support" },
      { ar: "مدير حساب مخصص لمنشأتك", en: "Dedicated account manager" },
      { ar: "اتفاقية استجابة خلال ساعة SLA", en: "1-hour response SLA" },
      { ar: "ترقية مجانية للإصدارات الجديدة", en: "Free upgrades to new releases" },
      { ar: "تدريب فريق العمل عن بُعد", en: "Remote team training sessions" },
      { ar: "استشارات تهيئة النظام لطبيعة عملك", en: "System tailoring consultations" },
    ],
  },
] as const;

/* ------------------------------------------------------------------ */
/* Tier presets — one-tap professional baselines                        */
/* ------------------------------------------------------------------ */

/**
 * Full professional benefit sets for the three standard tiers. Each preset
 * is a flat ordered list of bilingual pairs (⊆ the library above, curated
 * per tier). The "fill" action REPLACES both textareas — the admin then
 * tailors freely; the strict linter keeps everything professional.
 */
export const TIER_PRESETS: Record<
  "starter" | "professional" | "enterprise",
  readonly BenefitSuggestion[]
> = {
  starter: [
    { ar: "لوحة تحكم تنفيذية متكاملة", en: "Full executive dashboard" },
    { ar: "معالج إعداد ذكي في ٧ خطوات", en: "Smart 7-step setup wizard" },
    { ar: "واجهة عربية وإنجليزية كاملة", en: "Complete Arabic & English interface" },
    { ar: "إدارة كاملة للعملاء والموردين", en: "Full customers & suppliers management" },
    { ar: "تقارير فورية قابلة للتصدير", en: "Instant exportable reports" },
    { ar: "نسخ احتياطي يومي آمن للبيانات", en: "Secure daily data backups" },
    { ar: "دعم فني على مدار الساعة", en: "24/7 technical support" },
    { ar: "تحديثات دورية مجانية للمنصة", en: "Free regular platform updates" },
  ],
  professional: [
    { ar: "كل مزايا الباقة الأساسية", en: "Everything in the Starter plan" },
    { ar: "متجر إلكتروني متكامل للمنتجات", en: "Complete e-store for your products" },
    { ar: "نظام نقاط بيع POS متكامل", en: "Full point-of-sale (POS) system" },
    { ar: "دعم الباركود وقارئ الماسح الضوئي", en: "Barcode & scanner support" },
    { ar: "برنامج ولاء ومكافآت العملاء", en: "Customer loyalty & rewards program" },
    { ar: "كوبونات وأكواد خصم للعملاء", en: "Coupons & customer discount codes" },
    { ar: "إدارة الاشتراكات والمدفوعات المتكررة", en: "Recurring subscriptions management" },
    { ar: "إدارة صلاحيات فريق العمل بدقة", en: "Precise staff roles & permissions" },
    { ar: "تحليلات وتوصيات بالذكاء الاصطناعي", en: "AI-powered insights & recommendations" },
    { ar: "ترجمة آلية لواجهات النظام والموقع", en: "Automatic system & site translations" },
    { ar: "فواتير وطباعة احترافية بتوقيعك وختمك", en: "Professional invoices with your signature & stamp" },
    { ar: "تدريب مجاني على استخدام النظام", en: "Free system onboarding & training" },
  ],
  enterprise: [
    { ar: "كل مزايا الباقة الاحترافية", en: "Everything in the Professional plan" },
    { ar: "موقع عام احترافي خاص بنظامك", en: "A professional public website for your system" },
    { ar: "إدارة الفروع المتعددة من مكان واحد", en: "Multi-branch management in one place" },
    { ar: "صفحة أسعار احترافية للباقات", en: "Professional pricing page" },
    { ar: "هوية بصرية مخصصة بألوان شركتك", en: "Custom brand identity with your colors" },
    { ar: "سجل تدقيق كامل لكل العمليات", en: "Complete audit trail for every operation" },
    { ar: "حماية البيانات بتشفير كامل", en: "Full data encryption at rest" },
    { ar: "استعادة البيانات عند الطلب", en: "On-demand data restoration" },
    { ar: "دعم ذو أولوية عالية", en: "High-priority priority support" },
    { ar: "مدير حساب مخصص لمنشأتك", en: "Dedicated account manager" },
    { ar: "اتفاقية استجابة خلال ساعة SLA", en: "1-hour response SLA" },
    { ar: "تدريب فريق العمل عن بُعد", en: "Remote team training sessions" },
    { ar: "استشارات تهيئة النظام لطبيعة عملك", en: "System tailoring consultations" },
    { ar: "ترقية مجانية للإصدارات الجديدة", en: "Free upgrades to new releases" },
  ],
};

/**
 * Does a suggestion's Arabic line already exist in the typed features text
 * (normalized, case-insensitive — the same key the strict linter uses)?
 */
export function benefitAlreadyAdded(suggestion: BenefitSuggestion, featuresAr: string): boolean {
  const haystack = featuresAr
    .split("\n")
    .map((line) => normalizeKey(line));
  return haystack.includes(normalizeKey(suggestion.ar));
}

function normalizeKey(line: string): string {
  return line
    .replace(/[\u0000-\u001f\u007f]/g, "")
    .replace(/^[\s•·▪▫●○◦*\-–—>+]+/u, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLocaleLowerCase("ar");
}
