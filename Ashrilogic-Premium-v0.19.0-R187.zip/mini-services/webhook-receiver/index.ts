/**
 * Ashrilogic — WEBHOOK E2E RECEIVER (ROUND 113 test fixture).
 *
 * A deliberately-dumb HTTP sink on port 3030: every POST it receives is
 * appended (with headers) to webhook-receiver.log as JSON lines, and
 * GET /__dump returns the recorded entries for test assertions. This is
 * the "merchant integration" the e2e flow delivers signed events to.
 *
 * Not part of the application — a test fixture only.
 */
const PORT = 3030;
const LOG = new URL("./webhook-receiver.log", import.meta.url).pathname;

type Entry = {
  at: string;
  path: string;
  signature: string | null;
  event: string | null;
  body: string;
};

Bun.serve({
  port: PORT,
  async fetch(req: Request): Promise<Response> {
    const url = new URL(req.url);
    if (req.method === "GET" && url.pathname === "/__dump") {
      const entries = await Bun.file(LOG).exists()
        ? (await Bun.file(LOG).text()).split("\n").filter(Boolean).map((l) => JSON.parse(l) as Entry)
        : [];
      return Response.json({ count: entries.length, entries });
    }
    if (req.method === "GET" && url.pathname === "/__reset") {
      await Bun.write(LOG, "");
      return Response.json({ ok: true });
    }
    if (req.method === "POST") {
      const entry: Entry = {
        at: new Date().toISOString(),
        path: url.pathname,
        signature: req.headers.get("x-ashrilogic-signature"),
        event: req.headers.get("x-ashrilogic-event"),
        body: await req.text(),
      };
      const existing = await Bun.file(LOG).exists() ? await Bun.file(LOG).text() : "";
      await Bun.write(LOG, existing + JSON.stringify(entry) + "\n");
      return Response.json({ received: true }, { status: 200 });
    }
    return new Response("not found", { status: 404 });
  },
});

console.log(`[webhook-receiver] listening on :${PORT}`);
