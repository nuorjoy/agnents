# API-ARCHITECTURE

The authoritative contract for Ashrilogic API routes: the `routeHandler`
wrapper (its two forms, guard-stage order, envelope shapes, correlation
ids), the error model, the telemetry/redaction contract, and the protocol
for migrating hand-rolled routes into domain decomposition. Layering
context: [ARCHITECTURE.md](./ARCHITECTURE.md).

## The two forms

**Legacy 2-arg** (opt-in wrapper only — zero behavior change for unwrapped
routes):

```ts
export const GET = routeHandler("list packages", async (ctx) => {
  const guard = await requireAdmin();                  // hand-rolled guards
  if (guard instanceof NextResponse) return guard;     // pass-through
  const input = await ctx.parseBody(schema);           // 400/413 envelopes
  return NextResponse.json(dto);                       // x-request-id attached
});
```

**Declarative 3-arg** (ROUND 127 — the guard plan; the wrapper invokes the
REAL guard functions verbatim):

```ts
export const POST = routeHandler("submit review", {
  origin: true,                                    // originViolation(req) — FIRST
  admin: { roles: ["super"], withRequest: true },  // requireAdmin(...)
  tenant: { permission: "billing.manage", withRequest: true },
  maintenance: true,                               // maintenanceBlock(params.id, req)
  rateLimit: { key, rule, body, failClosed },      // rateLimited + tooManyRequests
  body: { schema, invalid },                       // read + validate, custom 400
}, async (ctx) => { /* ctxAdmin, ctxTenant, ctx.params, ctxBody */ });
```

**Stage order is fixed** (the historical corpus): `origin → admin → tenant
→ maintenance → body* → rateLimit → body† → handler`. (*before the throttle
only when `rateLimit.afterBody` is set — the coupon-validate semantics
where an invalid body does NOT burn a throttle hit; †the default position,
after the throttle.) The admin/tenant stages call `requireAdmin` /
`requireInstanceAccess` VERBATIM — `withRequest` reproduces their internal
origin + MFA/maintenance gates and exact short-circuit envelopes.

## Envelope shapes

| Status | Body | Producer |
| --- | --- | --- |
| 400 | `{ error: "Request body is required" }` | empty body |
| 400 | `{ error: "Invalid JSON body" }` | malformed JSON |
| 400 | `{ error: zodError(parsed.error) }` / route-specific | schema mismatch |
| 409 | `{ error: "…" }` (e.g. campaign mid-flight send) | domain CAS conflict |
| 413 | `{ error: "Request body too large" }` | over `DEFAULT_BODY_LIMIT_BYTES` |
| 429 | `{ error: "Too many requests" }` | throttle refuse |
| 500 | `{ error: "Failed to <label>" }` | uncaught — the label is the route's verb phrase |

`throw new HttpError(status, message, code?)` renders exactly
`{ error: message }` (+ optional additive `code`). Every guard
short-circuit and every response flows through the same `withRequestId`
path.

## Correlation: x-request-id

Every response carries `x-request-id` — the client's echoed value when it
matches `[A-Za-z0-9._-]{8,64}` (bounded against header injection / log
flooding), else a fresh UUID. Never trusted, only echoed. The 500 telemetry
line carries the same id, so a reported toast maps 1:1 to a log line.

## Telemetry / redaction contract

The 500 path emits ONE structured opLog line: requestId, method,
**pathname only — never the query string** (it can carry tokens),
`dbErrorClass` classification, error constructor name. Message text is
deliberately NOT included — Prisma errors embed SQL fragments and the
oplog redaction contract forbids raw SQL. Outside production (dev/test) the
full error still reaches console.error for debugging. No PII: the
ROUND-165 mail fix removed recipient addresses from sendMail failure logs;
emails in audit rows are masked (`maskEmail`). `safePath`-style bounded
path reporting — never raw internals.

## The migration protocol (hand-rolled → domain)

The **campaigns ROUND-165 worked example**:

1. **Route census first**: identify the legacy route(s) importing `@/lib/db`
   (they sit in `LEGACY_DB_ROUTES`).
2. **Decide correctness fixes WITH the move** — the campaigns route had a
   take:5000 truncation bug and in-request bulk delivery; the
   decomposition is the vehicle for the durable-dispatch redesign
   (ADR 0004).
3. **Schema first if needed**: additive-only migration, deployed before
   code (`20260929100000_campaign_durable_dispatch`).
4. **repository.ts** — every `db.*` call moves here; row→DTO mappers.
5. **service.ts** — business rules, audit actions (`campaign.create`,
   `campaign.send`, `campaign.dispatch-completed` registered in
   AUDIT_ACTIONS), `HttpError` for domain failures; schedulers live here.
6. **controller.ts** — `routeHandler(...)` per HTTP verb with declarative
   guard plans; PRESERVE historical envelopes (the campaigns create route
   keeps its custom first-zod-issue 400; DELETE 409s on mid-flight
   sending).
7. **route.ts becomes thin delegation** — import the controller export,
   nothing else.
8. **Allowlist removal** — drop the route(s) from `LEGACY_DB_ROUTES`
   (99 → the set shrinks; it NEVER grows).
9. **Regression suites** — `campaign-dispatch.test.ts` (5 tests: claim
   CAS/409/404, no-truncation, crash-resume idempotency, dead-letter);
   run the battery.

Post-conditions enforced by lint: the route imports no db in any form;
tsc/eslint clean; battery green.
