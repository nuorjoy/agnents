# JOBS

The authoritative inventory of the platform's standing schedulers — all 10
registered from `src/instrumentation.ts` (nodejs runtime only; edge is
skipped) — plus the `SchedulerLease` design that makes them multi-instance
safe. The campaign dispatcher's lifecycle is documented in detail.
Boot-gate ordering: the fail-closed invariants run BEFORE any scheduler
registration (see [SECURITY-MODEL.md](./SECURITY-MODEL.md)).

## Scheduler inventory

| # | Job | Tick | Lease (SchedulerLease) | Failure policy | Durable backing |
| --- | --- | --- | --- | --- | --- |
| 1 | weekly-digest (`platform-notifications.ts`) | 15 min | `weekly-digest`, TTL 10 min | run (own idempotence) | `NotificationLog` `@@unique([eventKey, weekKey])` |
| 2 | backup-safety-net (`platform-backup.ts`) | 15 min | `backup-safety-net`, TTL 10 min | run | disk-based freshness gate (newest snapshot age) + `SchedulerLease` |
| 3 | trash-retention (`trash.ts`) | daily guard (15-min ticker, once-per-ISO-day) | `trash-retention`, TTL 10 min | **skip** (destructive) | `deletedAt` + retention settings |
| 4 | webhook-dispatch (`webhook-dispatch.ts`) | 60 s | `webhook-dispatch`, TTL 50 s | **skip** (external side effect) | `WebhookDelivery` CAS-claimed rows |
| 5 | image-ref-gc (`image-ref-gc.ts`) | hourly | `image-ref-gc`, TTL 5 min | **skip** (destructive) | `ImageAsset` rows + storage, 24 h grace |
| 6 | media-ref-gc (`media-ref-gc.ts`) | hourly | `media-ref-gc`, TTL 5 min | **skip** (destructive) | `MediaAsset` rows + storage |
| 7 | audit-anchor (`audit-anchor.ts`) | hourly | `audit-anchor`, TTL 50 min | **skip** (correctness-sensitive seal) | `AuditChainAnchor` + MAC-verified `data/audit-anchors.jsonl` |
| 8 | order-compensation (`order-compensation.ts`) | 15 min | `order-compensation-repair`, TTL 10 min | **skip** | `compensatedAt` marker on cancelled orders |
| 9 | mail-outbox-sweep (`mail/outbox-sweeper.ts`) | 60 s | `mail-outbox-sweep`, TTL 50 s | **skip** (external side effect) | `EmailLog` PENDING rows (crash window 2 min; batch 20; dead-letter after 5 total attempts) |
| 10 | campaign-dispatch (`server/domains/campaigns/service.ts`) — **ROUND 165, NEW** | 60 s | `campaign-dispatch`, TTL **5 min** (renewed while running) | **skip** (fail-closed) | `NewsletterCampaign` dispatch columns + `EmailLog` per-recipient ledger |

What each does:

1. **weekly-digest** — delivers the platform weekly report for any ISO week
   lacking a NotificationLog row; idempotent across dev reloads and
   downtime catch-ups.
2. **backup-safety-net** (ROUND 112) — closes the zero-traffic gap: the
   opportunistic backup nudges only fire on audited mutations; this tick's
   freshness gate is DISK-based (newest snapshot age vs configured daily/
   weekly frequency).
3. **trash-retention** (ROUND 87) — destroys expired soft-deleted rows
   permanently; cheap no-op when nothing is due.
4. **webhook-dispatch** (ROUND 113) — dispatches due deliveries (pending +
   backoff-elapsed retries) and runs terminal-row retention; in-request
   opportunistic dispatch keeps latency near zero, this is the reliability
   net (both paths race-safe via CAS).
5. **image-ref-gc** (ROUND 117) — reclaims storage behind replaced/cleared/
   purged images past the 24 h grace plus orphan files (no row) in the same
   tick.
6. **media-ref-gc** (ROUND 140) — the same discipline for product video
   clips (`ModuleRecord.videosJson` references).
7. **audit-anchor** (ROUND 118) — seals the chain head into the external
   anchor file; a bad verdict (truncated/tampered) writes the sealed
   `system.auditAnchor` alert onto the chain itself.
8. **order-compensation** (ROUND 120) — re-drives cancelled orders whose
   stock/coupon release did not fully land until `compensatedAt` is set;
   reservations never leak silently.
9. **mail-outbox-sweep** (ROUND 120) — re-drives PENDING EmailLog rows a
   crashed process left behind; twin-success arbitration on
   `idempotencyKey`; stable Message-ID so receivers collapse duplicates.
10. **campaign-dispatch** — the durable newsletter engine, below.

Interval handles are kept on `globalThis` (the module-state idiom) so
Next.js dev reloads never stack a second ticker; timers are `.unref?.()`-ed
so they never hold the process open.

## The SchedulerLease design (`src/lib/server/job-lease.ts`)

Each tick acquires the job's lease row under a TTL slightly shorter than
the tick interval. ROUND 120 made it a real distributed lock:

1. **CAS CLAIM** — the takeover is a guarded UPDATE (absent row, expired
   row, or OUR row — never a live foreign row) followed by a unique-key
   INSERT for the absent case. The pre-R120 unconditional upsert could
   STEAL a live foreign lease (split brain).
2. **FENCING EPOCH** — every (re)acquire increments `epoch`; the holder
   captures its epoch and `stillMine()` re-verifies ownership so
   long-running ticks detect a takeover and stop before their next
   destructive step instead of writing as a zombie.
3. **HEARTBEAT** — `withJobLease` renews every ttl/3 while the body runs;
   a body that legitimately outlives the TTL (webhook dispatcher under a
   deep backlog) keeps its lease instead of silently letting a second
   instance double-dispatch.
4. **FAILURE POLICY** — `{ failure: "skip" }` makes a lease-store outage
   SKIP the tick instead of running ungated: REQUIRED for destructive/external
   jobs (all but weekly-digest and backup-safety-net above). Default `"run"`
   preserves availability for jobs whose own idempotence is the documented
   guard.

Idempotence is layered: the lease prevents duplicate TICKS; each job's body
stays idempotent on its own (freshness gates, unique constraints) — the
lease is a guard, never the sole correctness mechanism.

## The campaign dispatcher lifecycle (ROUND 165, ADR 0004)

`startCampaignDispatcher()` — 60 s tick, lease `campaign-dispatch`
(5-min TTL, renewed mid-flight), fail-closed skip, in-flight guard; first
pass 10 s after boot.

```
PATCH { action:"send" }  → CLAIM: draft → "sending" (CAS — one concurrent
                           sender wins, the loser 409s; NO delivery in HTTP)
dispatcher tick          → ENQUEUE: keyset-cursor pages (id > cursor,
                           take 500/tick) of the audience become PENDING
                           EmailLog rows — idempotencyKey campaign:<cid>:<sid>,
                           stable Message-ID, full envelope. Cursor advances
                           per batch; ANY list size, NO truncation,
                           crash-resume (the take:5000 bug this closes).
                         → DELIVER: bounded batches (100/tick, ≤5 campaigns
                           per tick) driven IN PLACE through the mail
                           service's retry/backoff pipeline
                           (deliverPendingOutboxRow); invalid addresses are
                           skipped; a row that keeps failing DEAD-LETTERS
                           after 5 attempts.
                         → COMPLETE: when enqueue has exhausted the audience
                           (dispatchEnqueueDone) AND zero rows are pending,
                           stamp "sent" + delivered/failed counts + the
                           campaign.dispatch-completed audit row (system
                           actor, full outcome ledger). Until then the
                           campaign is honestly "sending" — never "sent".
```

The outbox sweeper EXCLUDES `type=campaign` rows — the dispatcher owns them
(no double-driver race). Mail settings resolve through the shared 10 s
TTL platform-settings cache. UI: the admin newsletter surface shows the
sending badge and polls at 15 s while any campaign is sending.
