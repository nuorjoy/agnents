# SECURITY-MODEL

The authoritative statement of Ashrilogic's security posture: session
architecture, tenant isolation, secrets policy, fail-closed production
invariants, rate limiting, webhook SSRF posture, upload hardening, and audit
integrity. Architecture layering: [ARCHITECTURE.md](./ARCHITECTURE.md).
Operations-side runbook: [OPERATIONS.md](./OPERATIONS.md).

## Sessions

One signing primitive backs all session kinds (admin, instance workspace,
site customer) — `src/lib/server/tokens.ts`:

- **Scope-tagged HMAC tokens**: `base64url(payload).hmac(payload)` with
  `{ scope, sub, ver, exp }`. A token's scope binds it to its surface — an
  instance-workspace token can never replay against `/api/admin/*`.
- **Epoch rotation**: `ver` is the session epoch issued at; every guarded
  principal re-reads its DB row and compares the row's `sessionVersion` —
  bumping the row (password change, disable, security reset) invalidates
  every outstanding token up to cookie TTL.
- **jti registry revocation** (ROUND 45): tokens carry a `jti` mapped to a
  `SessionRecord` row; per-session ("this device") revocation via
  `checkSessionRecord`. Pre-jti tokens keep verifying (rollout safety).
- **Cookie flags**: HTTP-only session cookies, scoped names per surface.
- **MFA** (`mfa.ts`): TOTP RFC 6238, SHA-1/6-digit, ±1 step timing-safe.
  Secret is server-generated, sealed AES-256-GCM before storage, leaves the
  server exactly once (enrollment otpauth URI + QR). Two-step enrollment;
  10 single-use backup codes stored as SHA-256 digests. Policy is a
  **fail-closed tri-state** (ROUND 137, `admin-session.ts`):
  `on | off | unknown` — `unknown` (settings row unreadable) means sensitive
  admin mutations answer `MFA_POLICY_UNAVAILABLE`, never silently disarm;
  failures are never cached.
- **Passkeys** (`webauthn.ts`): WebAuthn via @simplewebauthn/server; private
  key never touches the server (public COSE key + clone-detection counter
  persisted, never serialized to clients); challenges single-purpose, bound
  to scope+subject, 3-minute TTL (single-use).
- **Cross-device login** (`cross-device-login.ts`, ROUND 117): 256-bit
  bridge token + QR encoding this deployment's own origin; the assertion is
  verified pinned to the bridge's own challenge; the desktop claim issues
  the real HTTP-only session cookie after the full login postlude.
- **Legacy secret window**: `LEGACY_SESSION_SECRET` accepts (verification
  only) a previous deployment's secret for a bounded rollover — never a
  committed constant.

## Tenant isolation

- `requireInstanceAccess` (`instance-session.ts`) is the tenant guard every
  `/api/instances/[id]/*` handler must pass: principal kind, membership, and
  the declared permission. Deny-by-default.
- **Strict RBAC** (`src/lib/permissions.ts`, ROUND 78): the ROLE_MATRIX is
  the single source of truth; 14 literal permission ids, NO wildcards;
  governance (billing, settings, backups, role management) is owner-only.
  The client renders THIS matrix, never a copy.
- **Maintenance windows** (`maintenance.ts`): RestoreLease-guarded restores
  raise 503 + Retry-After on tenant-scoped mutating surfaces while a
  restore is live; GETs keep serving. Advisory, honestly documented — the
  window is narrowed to one in-flight request, only the DB transaction is
  atomic.
- **Shift gates**: mutating workspace routes validate the open shift
  (`Shift` model) where the operation requires one (POS-style surfaces).

## Secrets

- **Centralized minimum-length policy** (ROUND 165, ADR 0003):
  `MIN_PROVISIONED_SECRET_LENGTH = 32` in `runtime-guard.ts` — the single
  loader every env-bound key resolves through. A spec declaring a lower
  floor is a programming error at module load. Production fails fast on
  missing/weak secrets; dev/test may use documented demo constants
  (one-time loud banner); any other NODE_ENV shape requires explicit
  `ALLOW_DEMO_SECRETS=1`. The historical 16/32 split across
  tokens/crypto-vault/audit-chain/wallet/audit-anchor/receipt-token/
  plan-orders is closed.
- **Demo-fallback posture**: never silently fall back to source-known
  constants in production — every token/field would be forgeable.
- **Backup key sealing**: offsite/mirror backups are AES-256-GCM envelopes
  (`backup-crypto.ts`) that REFUSE to run without `ASHRILOGIC_BACKUP_KEY`;
  rotation drains old envelopes via `_PREVIOUS` before the old key is
  dropped.

## Production invariants (fail-closed boot gates)

- **Storage invariant** (ROUND 161→165): production refuses to boot (and
  refuses storage use at `objectStorage()` — defense in depth) with
  `ASHRILOGIC_STORAGE_DRIVER=local` unless the operator asserts
  `ALLOW_LOCAL_STORAGE_IN_PRODUCTION=1` (durable self-hosted volume).
  Ephemeral filesystems (Vercel /tmp) silently lose uploads, the mail
  spool, and backup members.
- **Proxy-trust gate** (ROUND 165): `TRUST_PROXY_MODE` must be explicit in
  production — `always` (overwrite-mode proxy front; the bundled Caddyfile),
  `conditional` (trust forwarded headers only behind the platform edge
  anchor `x-vercel-forwarded-for`; everything else collapses to the
  untrusted bucket), or `never` (direct-exposure testing only). An implicit
  "always" default would make every per-IP throttle and the IP banlist
  forgeable.

## Rate limits

`src/lib/server/rate-limit.ts` — durable sliding window over the
`RateLimitHit` table:

- One guarded `INSERT … SELECT` per check. On PostgreSQL, a per-key
  **advisory transaction lock** in the same transaction closes the READ
  COMMITTED TOCTOU (N pooled connections could each observe `COUNT < limit`
  and all insert — MVCC guarantees the opposite of atomicity here).
- **failClosed callers** (login, password reset, registration): a durable
  store outage REFUSES the request. **fail-open callers** keep the
  process-local fallback (availability-first endpoints).
- **IP normalization**: the RIGHTMOST `x-forwarded-for` entry — correct
  behind an overwrite-mode gateway; client-supplied spoofed hops appear on
  the LEFT and are ignored. Refusals write nothing; the table is swept
  (10-min cadence, 24-h retention).

## Webhooks

`src/lib/server/webhooks.ts` + `webhook-dispatch.ts` (ROUND 113/137):

- **SSRF posture**: https-only URLs, no user credentials in URL, IP-literal
  hosts in private/reserved ranges refused, port allowlist
  (`WEBHOOK_ALLOWED_HTTPS_PORTS`). Plain http is loopback-only AND
  non-production (or explicit `ALLOW_HTTP_LOOPBACK_WEBHOOKS=1`). The URL is
  re-validated at EVERY dispatch attempt — legacy/restored rows cannot
  bypass. **Dispatch-time DNS pinning**: the hostname resolves once via
  `node:dns` lookup and the connection is pinned to the validated address
  through a custom `lookup` — redirects are never followed.
- **Signatures**: Stripe-style `X-Ashrilogic-Signature: t=<unix>,v1=<hmac>`
  over the EXACT dispatched bytes; tolerance window defeats replay.
- **Lease-claimed delivery** (ROUND 137): a dispatcher CAS-claims a due row
  to `processing` (leaseId, workerId, lockedUntil) BEFORE the transport
  fires; the settle is lease-scoped; expired leases are reclaimed; bounded
  retries with exponential backoff + jitter; at-least-once semantics —
  receivers deduplicate on `x-ashrilogic-delivery` + `x-ashrilogic-attempt`.
- Error strings are sanitized classes (timeout | network | dns |
  invalid-response | unsafe-url); endpoint response bodies are never stored
  or logged.

## Uploads

`src/lib/server/upload-validation.ts` — nothing about the client's claim is
trusted: MIME allowlist (raster families only; SVG rejected as a
script-capable document format), **magic-byte** format verification via
sharp, dimension + total-pixel caps BEFORE decode (decompression bombs),
re-encode to clean WebP (strips EXIF/GPS/ICC/trailing bytes), output
size-capped. Storage is content-addressed (`storage/…/<sha>.<ext>` style
keys under `ASHRILOGIC_STORAGE_DIR` or S3 prefix) — path-traversal-proof
keys derived server-side, never from client filenames.

## Audit

- `AuditLog` is **hash-chained** (`audit-chain.ts`): each row seals the
  prior hash; `verify:audit` (`scripts/verify-audit-chain.ts`) walks the
  chain.
- An hourly **external anchor** (`audit-anchor.ts`, ROUND 118) seals the
  chain head (id + hash + counts) into the MAC-verified
  `data/audit-anchors.jsonl` — a database-only compromise cannot silently
  truncate the newest rows; a bad verdict writes the sealed
  `system.auditAnchor` alert onto the chain itself.
- **PII masking** (`audit.ts`): emails masked (`maskEmail`); no secrets, no
  SQL fragments, no endpoint response bodies in logs (oplog redaction
  contract — see [API-ARCHITECTURE.md](./API-ARCHITECTURE.md)).

## Known accepted risks

- **Sandbox Caddyfile XTransformPort**: the repo-root `Caddyfile` proxies
  client-chosen localhost ports (`query XTransformPort=...`) — sandbox-only
  plumbing, an SSRF-class hole if shipped to production. Exempted by
  design; `check:caddy` (strict in CI + the release packager) fails any
  production Caddyfile that reintroduces the pattern and fails on a MISSING
  `deploy/Caddyfile.production` in strict mode.
- Legacy routes (~100) log raw error objects (TECHNICAL-DEBT P2) — Prisma
  SQL-fragment leakage risk in server logs; the mail recipient-PII variant
  was fixed in ROUND 165.
- The maintenance-window guard is advisory, not a serialization boundary
  (documented above).
