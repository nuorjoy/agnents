# TECHNICAL-DEBT

The engineering debt register — every known compromise, categorized P0
(blocker) through P3 (cosmetic/hardening), with status and the round that
last touched it. P0 items from the ROUND-164 intake are all CLOSED; this
register tracks what remains. Related docs:
[ARCHITECTURE.md](./ARCHITECTURE.md),
[TEST-MATRIX.md](./TEST-MATRIX.md), [adr/](./adr/).

## P0 — closed (recorded for context)

| Item | Status |
| --- | --- |
| GHSA-vcvr-r3jv-pc5j (Satori RCE, next 16.3.5) | **CLOSED R165** — upgraded to 16.3.6 (ADR 0001) |
| Campaign take:5000 truncation + in-request bulk delivery | **CLOSED R165** — durable dispatch (ADR 0004) |
| loadSecret 16/32 split | **CLOSED R165** — centralized 32 floor (ADR 0003) |
| eslint import-form bypass | **CLOSED R165** — all forms + both resolutions (ADR 0005); 2 real violations fixed |
| Storage invariant console.warn only | **CLOSED R165** — fail-closed boot gate (ADR 0002) |

## P1 — structural (migration waves)

| # | Item | Notes |
| --- | --- | --- |
| P1-1 | **151 hand-rolled routes** lack the routeHandler wrapper | no correlation ids (`x-request-id`), no redacted 500 telemetry, hand-written guard drift. Migration protocol: [API-ARCHITECTURE.md](./API-ARCHITECTURE.md) §migration. 40/191 delegated as of R186 (verified by filesystem + import census). |
| P1-2 | **99 frozen `LEGACY_DB_ROUTES` allowlist entries** | eslint-enforced, shrink-only. Each domain decomposition wave removes its routes (campaigns pair removed R165). New db-importing routes are structurally impossible. |
| P1-3 | **CLOSED R187** — usage.ts IS transactional (since R171) | `withStorageQuotaWrite` = `pg_advisory_xact_lock(storage-quota:<tenant>)` → FRESH 8-aggregate recompute INSIDE the tx → check + write commit atomically (`usage.ts`, 15s timeout/maxWait), pinned by `tests/security/storage-quota-race.test.ts` (5 concurrent writers vs 1MB allowance). The 60s snapshot cache is DISPLAY-only. The historical "60s cache + self-healing" relaxation (ADR 0006 §3) no longer describes the code — this register previously carried the stale state. |
| P1-4 | **backup.ts builds the ENTIRE tenant in memory** before the 16 MB canonical-ceiling check (`SECTIONS_BUILD_MAX_JSON_BYTES = 16_000_000`) | restore is ONE mega-transaction. Streaming design sketch: section-at-a-time serialization (per-model canonical batches streamed to the envelope), restore driven per-section with the RestoreLease + maintenance window already in place; the teardown/swap stays one transaction. |

## P2 — scoped correctness/performance

| # | Item | Notes |
| --- | --- | --- |
| P2-1 | **trash.ts `LIST_TAKE = 500`** per-entity stats caps | trash volume is retention-bounded; counts cap at 500 per entity in list stats. |
| P2-2 | **instance purge is a mega-cascade** | application-driven scoped deletes; unbounded work per purge. |
| P2-3 | **trash sweep misses gallery/video refs** | hourly image/media GC safety nets reclaim them (24 h grace) — the documented net. |
| P2-4 | **CLOSED R187** — ModuleRecord codeKey IS DB-unique | `@@unique([instanceId, moduleId, codeKey])` (schema:288) + migration `20261001000000_codekey_wallet_dedupe_trash_idx` + `scripts/backfill-…` + `tests/security/db-invariants-race.test.ts` (8 concurrent inserts → exactly 1 survivor, P2002×7). Trash NULLs the key so codes recycle. The former "in-memory sibling scan only" state is gone. |
| P2-5 | **sitemap `force-dynamic`** | CLOSED R166: promoted to ISR (`revalidate = 3600`) — deterministic, take-bounded output makes the cached copy byte-stable; see src/app/sitemap.ts ROUND 166 note. |
| P2-6 | **~116 legacy route FILES still log raw error objects** (115 of them pass the raw Error; 181 call sites total) | Prisma SQL-fragment leakage risk in server logs. The mail-recipient PII variant was FIXED R165 (sendMail failure log no longer embeds the address). R187 census: 116 files / 115 raw-loggers under `src/app/api/**` (docs previously said ~100). The 40 domain-delegated routes are the migration path (routeHandler redacts). |
| P2-7 | **wallet domain has no service.ts** | controller composes `lib/server` directly (documented in ARCHITECTURE.md). |
| P2-8 | **order-lifecycle / coupon-patch / loyalty-engine unmigrated to domains** | still lib/server engines without domain wrappers. |

## P3 — hardening / cleanup

| # | Item | Notes |
| --- | --- | --- |
| P3-1 | **CORRECTED R187** — image-gc.ts is NOT dead code | The former claim ("zero `src/` importers") was wrong: `image-ref-gc.ts` statically imports `executeImageGc` and dynamically imports `collectImageGcPlan` (the hourly orphan safety net registered in `instrumentation.ts` piggybacks it); `scripts/gc-images.ts` imports it too. Both test files (image-gc, image-ref-gc) pin the behavior. Do NOT delete. |
| P3-2 | **admin/activities org directory loads ALL orgJson** | parses every row to build the directory. |
| P3-3 | **eslint warnings baseline: 247** | pre-existing, tracked; 0 errors is the contract. |
| P3-4 | **Int32 margins — `Shift.salesTotal` uncapped running sum** | The former second half (`priceYearly × 100` at the wallet-checkout conversion seam) is OBSOLETE post-R166: the money family converged to minor units and the seam was removed (plan-orders debits the order amount directly). Overflow needs >21.4M SAR of POS sales inside ONE shift. |

## Register discipline

- Every entry states its evidence and last-touching round; no entry is
  removed without a closing note in the worklog.
- A fix closes an entry only when the verification contract
  (TEST-MATRIX.md) is satisfied for the change.
- Debt may not be "fixed" by weakening a control (AGENTS.md §9).
