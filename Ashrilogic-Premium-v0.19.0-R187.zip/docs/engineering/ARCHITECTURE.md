# ARCHITECTURE

The authoritative map of the Ashrilogic Premium server architecture: the
layering contract, the domain decomposition under `src/server/domains/`, the
shared-core engines under `src/lib/server/` that domains compose, and the lint
ratchet that keeps the boundary from regressing. Route-handler contract
details live in [API-ARCHITECTURE.md](./API-ARCHITECTURE.md); security
posture in [SECURITY-MODEL.md](./SECURITY-MODEL.md); data conventions in
[DATA-MODEL.md](./DATA-MODEL.md). ROUND references point at the worklog.

## Layering contract

```
src/app/api/**/route.ts        thin delegation: parse → domain controller export
  → src/server/domains/<d>/    controller (routeHandler + declarative guard plan)
                               service   (business rules, audit, HttpError)
                               repository(Prisma queries — the ONLY db touch)
  → src/lib/server/*           shared live engines domains compose over
  → Prisma client → PostgreSQL (single provider; src/lib/db.ts refuses others)
```

A route file imports a domain controller export and nothing else. A
controller owns the HTTP seam: `routeHandler(...)` wrapper, Zod schemas,
guard plans. A service owns business rules and audit side effects. A
repository owns every `db.*` call for the domain. The shared
`src/lib/server/*` modules are LIVE ENGINES — plan-orders.ts, wallet.ts,
addon-orders.ts, entitlement.ts, store-mapper.ts, coupons.ts,
order-lifecycle.ts, order-snapshot.ts — not shims: domains compose them
directly (e.g. the wallet controller calls `lib/server/wallet.ts` +
`crypto-vault` + `rate-limit` itself; the campaigns service calls
`mail.deliverPendingOutboxRow`, `job-lease`, `audit`).

## Domains (src/server/domains/)

| Domain | Layers | Notes |
| --- | --- | --- |
| `packages` | controller + service + repository | ROUND 88 wave; public + admin routes |
| `orders` | controller + service + repository | storefront orders, lifecycle via `order-lifecycle.ts` |
| `store` | controller + service + repository | public storefront catalog/coupons/reviews |
| `plan-orders` | controller + service + repository | billing, wallet checkout, entitlement stamping |
| `addon-orders` | controller + service + repository | add-on catalog, same wallet-checkout seam |
| `wallet` | controller + repository — **no service.ts** | controller composes the shared `lib/server` core (`wallet.ts`, `crypto-vault`, `rate-limit`, `money`) directly; tracked as debt (TECHNICAL-DEBT P2) |
| `campaigns` | controller + service + repository | ROUND 165 — the durable-dispatch worked example (ADR 0004) |
| `attendance` | controller + service + repository | the الورديات domain (shifts, QR redeem, policy, allowances) |
| `promotions` | controller + service + repository | public + admin promotions surfaces |
| `enterprise-quotes` | controller + service + repository | quote intake + admin queue |
| `wallet-grants` | controller + service + repository | bulk wallet grants + welcome bonus engine |

## Route census (as of ROUND 187)

- **191** API `route.ts` files total (`src/app/api/**`)
  — verified by filesystem census.
- **40 domain-delegated** (the campaign pair plus the 38 routes
  delegating to the 11 domain controllers) — verified by import scan.
- **151 hand-rolled legacy** routes: no `routeHandler` wrapper, no
  correlation id, hand-written guards (P1 debt).
- **99 entries in the frozen `LEGACY_DB_ROUTES` allowlist**
  (`eslint.config.mjs`) — routes still allowed to import `@/lib/db`.
  ESLint-enforced; **shrinking only** (entries are never added; the campaigns
  pair was removed in ROUND 165 after decomposition).

## The routeHandler contract (ROUND 124/127)

`src/lib/server/route.ts` — one wrapper, two call forms:

1. **Legacy 2-arg** `routeHandler("label", handler)` — correlation ids +
   error envelope + redacted telemetry only.
2. **Declarative 3-arg** `routeHandler("label", guardPlan, handler)` — the
   plan declares `origin → admin → tenant → maintenance → body → rateLimit`
   stages; the wrapper invokes the REAL guard functions (`originViolation`,
   `requireAdmin`, `requireInstanceAccess`, `maintenanceBlock`,
   `rateLimited`) verbatim, preserving historical envelope shapes and stage
   order. Injections: `ctxAdmin`, `ctxTenant`, `ctx.params`, `ctxBody`.

Every response carries `x-request-id` (client-echoed when bounded
`[A-Za-z0-9._-]{8,64}`, else fresh UUID); the 500 oplog line carries the
same id. Full envelope table: [API-ARCHITECTURE.md](./API-ARCHITECTURE.md).

## Architecture lint ratchet (ROUND 165 hardening)

`eslint.config.mjs` — two structural rules, `error` severity:

- **`no-db-in-route-handler`** — an API route.ts may not import the Prisma
  client in ANY form: static import, dynamic `import()`, `require()`,
  re-export (`export … from`, `export * from`), with BOTH `@/` alias and
  RELATIVE path resolution (`resolveModuleSource`). The frozen legacy set is
  the only exemption. Verified empirically with a 7-form bypass probe; the
  hardening found and fixed 2 real violations (`instances/[id]/passkeys`,
  `mfa/setup` — both used `await import("@/lib/db")`; helpers collapsed into
  shared `readWorkspaceEmail()` in `instance-session.ts`).
- **`no-server-only-in-client`** — a `"use client"` file may not import
  `@/lib/db` or `@/lib/server/**` through any of the same import forms.
  Current violations: 0.

## Standing processes

Server boot (`src/instrumentation.ts`, nodejs runtime only) runs the
fail-closed boot gates (storage invariant, proxy-trust mode) then registers
**10 schedulers**, each under a durable `SchedulerLease`. Inventory and
lease design: [JOBS.md](./JOBS.md).

## Enforcement summary

| Boundary | Mechanism |
| --- | --- |
| route → domain only | ESLint `no-db-in-route-handler` (all import forms) |
| server-only in client | ESLint `no-server-only-in-client` |
| legacy db imports | `LEGACY_DB_ROUTES` frozen set (99, shrink-only) |
| production boot | storage invariant + proxy-trust gates (SECURITY-MODEL) |
| verification | tsc + eslint + battery (TEST-MATRIX) |
