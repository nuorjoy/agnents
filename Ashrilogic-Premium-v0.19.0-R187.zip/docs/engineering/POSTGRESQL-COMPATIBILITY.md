# Ashrilogic — PostgreSQL Compatibility Program

> Status: **active** (ROUND 166). This document is the single source of truth
> for the platform's PostgreSQL version policy, the CI channel matrix, and the
> upgrade path. It exists so that "which versions do we support, and how do we
> know?" never depends on memory.

## 1. Policy in one paragraph

PostgreSQL is the platform's **only** database engine (prisma/schema.prisma).
The **current** channel is PostgreSQL **17** — every release is verified
against it with the full gate chain (tsc, eslint, migration chain, ~70 offline
security suites). PostgreSQL **19 Beta 4** is an **upgrade-testing target
only**: a non-blocking CI radar that answers "will the next major be a
drop-in?" early, while it is still cheap to find out. **No database semantics
— SQL, migrations, constraints, transaction shapes, isolation assumptions —
may ever be changed to make a beta build pass.** A beta regression is FILED
(§5), not bent around. GA promotion follows the procedure in §4.

## 2. CI channel matrix

| Channel | Job | Image | Blocking? | Scope |
|---|---|---|---|---|
| `postgresql-current` | `quality` | `postgres:17-alpine` service | **YES** — release gate | Full chain: OSV dependency gate, SBOM, repo hygiene, prisma generate, tsc, eslint (0 errors), Caddy strict gate, `prisma migrate deploy` (the versioned migration chain — the production path), the full offline security battery (~70 suites, one bun process per file), advisory i18n report |
| `postgresql-19-beta4` | `postgresql-19-beta4` | `postgres:19beta4-alpine` service | **NO** (`continue-on-error: true`) — radar | Migration chain + representative engine-sensitive core suites: `crypto-vault`, `audit-chain`, `attendance`, `coupons` |

Why those four core suites: they exercise the engine surfaces most likely to
move across a major — JSON-string columns (crypto-vault's sealed envelopes),
transactional CAS updates and chained hashing (audit-chain), single-use token
arbitration with unique-constraint races (attendance QR), and constraint
arbitration on money paths (coupons). The full battery stays on the current
channel so beta noise never drowns the release signal.

## 3. What "compatibility" means concretely

1. **Migration parity** — `prisma migrate deploy` applies the ENTIRE versioned
   chain (baseline → … → `20260930140000_email_reveal_token`) from scratch on
   the beta engine with zero drift. This is the primary compat artifact: it is
   the exact path production upgrades take.
2. **Suite parity on the core** — the four core suites pass byte-identical
   behavior on the beta engine (no skipped assertions, no loosened bounds).
3. **Client tooling** — `pg_dump`/`pg_restore` majors must match the server
   major (the backup subsystem spawns them). The current channel pins
   `postgresql-client-17` via PGDG. A PG19 GA promotion requires adding the
   matching client major and extending the backup suites to the new channel.
4. **Provider scope** — Prisma's own engine support for a beta PostgreSQL is
   *best-effort*: a beta channel failure may be Prisma-side, not ours. Such
   findings are recorded here with the root cause and re-tested each beta
   drop; they are never "fixed" by weakening schema or SQL.

## 4. GA promotion procedure (when PostgreSQL 19 goes stable)

1. The `postgresql-19-beta4` channel must have been **green across a full beta
   cycle** (all betas since the previous major, no open §5 entries that are
   ours).
2. Swap the radar's image to the stable `postgres:19-alpine` tag, duplicate
   the current channel's FULL battery onto it, and run both channels in
   parallel for one release.
3. After one clean parallel release: the PG19 channel becomes the blocking
   `postgresql-current`, the PG17 channel is retired, the PGDG client pin is
   bumped to 19, and this document's matrix is updated.
4. Neon alignment: the hosted production major is tracked in §6 — if Neon
   promotes before we do, the radar channel is re-pointed at Neon's major and
   the same procedure applies.

## 5. Beta findings register

| Beta | Date | Finding | Root cause | Status |
|---|---|---|---|---|
| — | — | *(none recorded — channel added ROUND 166)* | — | — |

A row is added whenever the radar channel fails: the failing suite, the
assertion, the engine version, and the determined root cause (ours / Prisma /
upstream beta bug). Rows close when a beta drop or a code fix (never a
semantic bend) turns them green.

## 6. Production alignment

- **Neon (hosted production):** the runtime database. The connection split is
  documented in DEPLOYMENT.md — pooled URL for the runtime, direct URL for
  `prisma migrate deploy`. Neon's engine major is pinned by their platform
  announcements; the radar channel's image is kept within one major of it.
- **Self-hosted:** PostgreSQL 17 is the documented floor (the migration chain
  and the battery are verified against it); anything ≥17 that passes the same
  chain is supported by evidence, not assertion.

## 7. Non-goals

- No multi-provider abstraction (no MySQL/SQLite fallbacks — the SQLite era
  ended with the R122 cutover; the JSON-string column representation is a
  deliberate provider-portability choice, not a provider dependency).
- No beta engine in production, staging, or the local dev defaults — beta
  engines only ever run in the CI radar.
- No "beta-specific" SQL branches in the codebase: every query is written
  against stable PostgreSQL semantics, and the radar verifies that those
  semantics hold on the next major.
