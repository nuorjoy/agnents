# DATA-MODEL

The authoritative conventions for Ashrilogic's PostgreSQL schema
(`prisma/schema.prisma`, single provider): the money-unit law and its one
exception family, the JSON-as-String policy, soft-delete mechanics, the
lease/outbox model family, and the migration history. Security of the
sealed-field family: [SECURITY-MODEL.md](./SECURITY-MODEL.md).

## Money convention

**The law** (`src/lib/server/money.ts`): ALL wallet/store/order money is
INTEGER MINOR UNITS (factor 100; 199 SAR → 19900). Floating-point never
touches stored money — floats appear only at the display boundary,
converted once per DTO. Client-supplied totals are never trusted; prices
are re-derived server-side from module records at order time.
`MAX_MINOR_UNITS = 2_000_000_000` — anything above is rejected
(`isValidMinorUnits`).

Applies to: `SiteOrder.total`, order item snapshots, `WalletTxn.amountMinor`
+ `balanceAfterMinor`, `WalletTopup.amountMinor`, `Shift.salesTotal`, and
(since the ROUND-166 convergence migration
`20260930120000_money_minor_units`) **`Package.priceMonthly` /
`Package.priceYearly`, `PlanOrder.amount`, `AddonOrder.amount`** — the
whole money family is minor-native end to end. Each amount is a
server-computed snapshot — the client never sends an amount.

**The conversion seam is GONE** (ROUND 166): the former
`toMinorUnits(amount)` call sites at wallet checkout were removed — the
plan/add-on wallet checkout debits the order's own minor-unit amount
directly (plan-orders/service.ts: "NO toMinorUnits conversion — double
conversion would 100× overcharge").

**Int32 margins (tracked debt — TECHNICAL-DEBT P3-4):**
- `Shift.salesTotal` is an uncapped running sum (Int) — no overflow guard
  (needs >21.4M SAR of POS sales inside ONE shift).
- The former `priceYearly × 100` seam risk is OBSOLETE post-R166 (the
  multiplication no longer happens anywhere at checkout).

## JSON-as-String policy

| Class | Examples | Rule |
| --- | --- | --- |
| **Immutable snapshots** | order items (`itemsJson`), payment-method snapshots (`methodJson`), `WebhookDelivery.payloadJson` | written once at the event, never mutated — the snapshot IS the record (re-serialization never rewrites history; webhook receivers verify the exact bytes) |
| **Mutable state** | `Instance.contentJson`, `ModuleRecord.dataJson`, `Instance.orgJson` | read-modify-write by owning service |
| **Sealed PII** | email, phone, TOTP secrets, SMTP settings | AES-256-GCM envelopes (`crypto-vault.ts`) + HMAC-SHA256 **blind indexes** for lookups (`emailIndex`, `authorIndex`, `orgPhoneIndex`) — ciphertext in the value column, deterministic index in the twin column |

## Soft delete

- **Tuples**: `deletedAt DateTime?` + `deletedKey` (JSON preserving the
  mangled unique key's original — username, code, email index) on
  `SiteCustomer`, `SiteOrder`, `StoreCoupon`, `SiteReview`, `AdminUser`,
  `WebhookEndpoint`. Restore un-mangles; conflict-checked.
- Queries filter `deletedAt: null` (indexed `@@index([instanceId, deletedAt])`).
- **Tombstone mangling**: deleted `SiteCustomer.emailIndex` → `del:<id>`;
  `StoreCoupon.code` → `DEL-<id>` — creation of a colliding key stays legal
  while the trash row survives.
- **Trashed orders keep their reservations** — trash is restorable; a
  restore must not double-release stock/coupon quota (order-lifecycle.ts
  business rule).

## Tenant-keyed unique constraints

| Model | Constraint |
| --- | --- |
| ModuleRecord | `@@unique([instanceId, moduleId, codeKey])` (migration `20261001000000` + `scripts/backfill-record-codekey.ts`; trash NULLs the key so codes recycle) |
| SiteCustomer | `@@unique([instanceId, emailIndex])`, `@@unique([instanceId, username])` |
| SiteOrder | `@@unique([instanceId, code])` |
| StoreCoupon | `@@unique([instanceId, code])` |
| SiteReview | `@@unique([instanceId, recordId, authorIndex])` |
| MfaSecret / WebauthnCredential | `@@unique([scope, subjectId])`, `@@unique([scope, subjectId, id])` |
| NotificationLog | `@@unique([eventKey, weekKey])` |

**Cascade rules**: `Instance` is the parent — tenant purge cascades scoped
children (the purge sweep is application-driven). `Package` is **Restrict**:
referencing plan orders block destructive package changes. The tenant-scoped
ledger rows `WalletTxn` and `WalletTopup` carry `instance FK onDelete:
Cascade` — a tenant purge deletes them together with the workspace (the
platform-side money trail for a purged tenant goes with it; the
pre-purge backup envelope is the retention copy). The quota/stock ledgers
(`CouponRedemption`, `OrderReservation`) are **FK-less by design** — their
rows must survive referenced-row trash/purge
(`@@unique([orderId, recordId])`, `@@unique([orderId, couponId])` keep
them deduplicated).

## Lease / job / outbox models

| Model | Role |
| --- | --- |
| `SchedulerLease` | the distributed job lock: CAS claim (absent/expired/own row — never a live foreign row), **fencing epoch** incremented per (re)acquire, heartbeat renewal, token-matched release |
| `RestoreLease` | per-tenant restore lock; expired leases take over, release drops only own row |
| `WebhookDelivery` | CAS-claimed outbox: pending → processing (leaseId/workerId/lockedUntil) → terminal; attempts-CAS result writes |
| `EmailLog` | mail outbox (PENDING row persisted BEFORE delivery — ROUND 120) + per-recipient campaign ledger (type `campaign`, `idempotencyKey campaign:<cid>:<sid>`, stable Message-ID) |
| `OrderIdempotency` | duplicate-submission absorption at order placement |
| `CouponRedemption` / `OrderReservation` | quota + stock durability; released by the order-compensation sweep |
| `NewsletterCampaign` | dispatch state: `dispatchCursor`, `dispatchEnqueueDone`, `dispatchEnqueued`, `delivered`, `failed` (ROUND 165) |
| `AuditChainAnchor` | sealed chain-head records backing the external anchor file |

## Migrations

`prisma/migrations/` — versioned, `migrate deploy` is the production path
(the squashed `20260928000000_postgres_baseline` is the PostgreSQL-only
baseline after the SQLite cutover). The post-baseline chain, in order:

1. `20260929100000_campaign_durable_dispatch` — additive-only columns on
   `NewsletterCampaign` (cursor, enqueue-done marker, enqueue count,
   terminal delivered/failed counts). Existing rows untouched; `sending`
   is only ever written by the draft→sending claim.
2. `20260929110000_tenant_phone_index` — `Instance.orgPhoneIndex` +
   index; **NULL on legacy rows — backfill via
   `bun run backfill:phone-index`** (release protocol, OPERATIONS.md);
   the deep-check retains a bounded legacy fallback.
3. `20260930120000_money_minor_units` — **DATA REWRITE** (the one
   non-additive migration in the chain): `Package`/`PlanOrder`/
   `AddonOrder` amounts ×100 into minor units; pending orders lose their
   HMAC seals (409 ORDER_INTEGRITY on confirm — let them expire);
   `addonsPricingJson` reset to the minor-unit defaults (re-enter custom
   prices from the console). Operator notes are in the migration header.
4. `20260930130000_attendance_domain` — the الورديات domain tables.
5. `20260930140000_email_reveal_token` — one-time email-reveal tokens.
6. `20260930150000_platform_growth_round167` — platform growth surfaces.
7. `20261001000000_codekey_wallet_dedupe_trash_idx` — the
   ModuleRecord `@@unique([instanceId, moduleId, codeKey])` + wallet
   dedupe/trash indexes (`scripts/backfill-record-codekey.ts` backfills
   legacy rows; `tests/security/db-invariants-race.test.ts` pins the
   constraint under concurrency).
8. `20261002120000_blog_view_ledger` — the blog view ledger.
