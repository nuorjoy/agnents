# OPERATIONS

The operator runbook for Ashrilogic Premium in production: required
environment, the fail-closed boot gates and their remediations, backup and
restore operations, observability surfaces, and the release protocol.
Deployment platform specifics (Vercel + Neon): [DEPLOYMENT.md](/DEPLOYMENT.md).
Security rationale: [SECURITY-MODEL.md](./SECURITY-MODEL.md).

## Required production environment

| Variable | Requirement |
| --- | --- |
| `DATABASE_URL` | PostgreSQL connection string — the ONLY engine (`src/lib/db.ts` refuses others) |
| `ADMIN_SESSION_SECRET` | ≥ 32 random chars (session HMAC) |
| `ASHRILOGIC_DATA_KEY` | ≥ 32 random chars (field-encryption root key) |
| `TRUST_PROXY_MODE` | EXPLICIT: `always` / `conditional` / `never` |
| Storage | `ASHRILOGIC_STORAGE_DRIVER=s3` (+ S3_* block) **or** `local` + `ALLOW_LOCAL_STORAGE_IN_PRODUCTION=1` (durable self-hosted volume assertion) |
| `ASHRILOGIC_BACKUP_KEY` | required for off-site/mirror backups (AES-256-GCM envelopes refuse to run without it — fail-closed) |
| `SMTP_URL`, `MAIL_FROM` | optional mail transport (campaigns/notices need it) |
| `WEBHOOK_ALLOWED_HTTPS_PORTS`, `ALLOW_HTTP_LOOPBACK_WEBHOOKS` | webhook hardening knobs |
| `ASHRILOGIC_AUDIT_ANCHOR_FILE`, `ASHRILOGIC_BACKUP_MIRROR_DIR`, `ASHRILOGIC_OPS_LOG` | optional runtime locations |

Full annotated template: `.env.example`.

## Boot gates (fail-closed)

| Gate | Trigger | Error gist | Remediation |
| --- | --- | --- | --- |
| Storage invariant (`assertDurableStorageInvariant`, boot + first storage use) | production + `local` driver + no durable assertion | "PRODUCTION STORAGE INVARIANT: ASHRILOGIC_STORAGE_DRIVER=local on an ephemeral filesystem loses uploaded images, the mail spool, and backup off-site members…" | switch to S3 driver, or set `ALLOW_LOCAL_STORAGE_IN_PRODUCTION=1` ONLY on a durable volume |
| Proxy-trust gate (`assertExplicitProxyTrustMode`) | production + `TRUST_PROXY_MODE` unset/unrecognized | "PROXY TRUST GATE: TRUST_PROXY_MODE must be set explicitly in production…" | pin the mode explicitly (decision matrix in DEPLOYMENT.md) |
| Secret floor (`runtime-guard.ts`) | production + missing/weak (< 32) `ADMIN_SESSION_SECRET` / `ASHRILOGIC_DATA_KEY` | fail-fast with the documented contract | provision ≥ 32-char secrets |
| Demo-secret opt-in | non-dev/test NODE_ENV shape + demo constants without opt-in | refuses to run on demo material | set real secrets, or `ALLOW_DEMO_SECRETS=1` only for staging you own |

Next.js re-throws `register()` errors — these gates actually stop the boot.

## Backup / restore operations

- **Snapshots**: pg_dump-based per-tenant + platform snapshots, spawned at
  runtime (client tools must match the server major version — CI installs
  postgresql-client-17 for this reason).
- **Off-site copies**: AES-256-GCM sealed (`ASHRILOGIC_BACKUP_KEY`);
  REFUSE to run without the key (fail-closed by design).
- **Mirror**: `ASHRILOGIC_BACKUP_MIRROR_DIR` local mirror member.
- **Key rotation**: `bun run reseal:keys` — put the OLD key in
  `ASHRILOGIC_BACKUP_KEY_PREVIOUS` first; the sweeper drains old envelopes,
  then the old key can be dropped.
- **Restore**: `bun run platform:backup-restore` (CLI) — rebuilds a tenant
  inside ONE transaction under a `RestoreLease` + maintenance window
  (tenant-scoped mutations answer 503 + Retry-After during the window).
  `bun run import:backup` imports an archive.
- **Snapshot health**: `snapshot-health` verifier (pg_restore-based).

## Observability

- **oplog events** (structured, redacted — no SQL fragments, no PII):
  `campaign-dispatch.*` (campaign-error, completion ledger),
  `ops.backup.*` (completed / failed / mirror-refused / offsite-refused /
  local-encryption-unavailable), `rate-limit.refused`,
  `mfa.policy-read-failed`, scheduler registration lines from
  instrumentation.
- **Audit chain**: `bun run verify:audit` walks the hash chain;
  the hourly anchor job seals heads into `data/audit-anchors.jsonl`
  (MAC-verified) so DB-only compromise cannot silently truncate rows.
- **Health probes**: `GET /api/healthz` (liveness) and `GET /api/readyz`
  (readiness — database-touching).
- **Scheduler posture**: each of the 10 jobs logs its registration at boot
  (JOBS.md has the inventory); lease contention is silent by design.

## The release protocol

```
bunx prisma migrate deploy          # versioned migrations (additive-only R165 pair)
bun run backfill:phone-index        # Instance.orgPhoneIndex legacy rows (20260929110000)
bash .zscripts/test-battery.sh      # full battery: offline + live + slicing + restore
bash .zscripts/package-release.sh R165
```

The packager stages from an explicit allowlist and FAILS the build if any
runtime artifact (`.env`, databases, `storage/`, logs) reaches the archive;
strict Caddy gate runs inside it. The tag is REQUIRED.

## Incident quick reference

| Symptom | First check |
| --- | --- |
| boot refuses with PRODUCTION STORAGE INVARIANT | storage driver / durable assertion (above) |
| boot refuses with PROXY TRUST GATE | `TRUST_PROXY_MODE` value |
| all requests 429 | limiter bucket collapse — proxy mode `never` with direct exposure, or a flooding key (`rate-limit.refused` events) |
| tenant mutations 503 + Retry-After | a restore is live (RestoreLease) — wait for completion |
| campaign stuck "sending" | dispatcher lease/audit ledger (`campaign-dispatch.*`), EmailLog pending rows |
| audit verify fails | run `verify:audit`, inspect anchor file verdicts — treat as tamper until proven otherwise |
