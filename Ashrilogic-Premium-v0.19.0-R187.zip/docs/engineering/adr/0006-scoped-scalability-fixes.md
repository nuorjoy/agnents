# ADR 0006 — Scoped scalability fixes

- **Status:** ACCEPTED (ROUND 165) — implemented, tested where testable
- **Date:** 2026-09-29 (session ROUND 165)

## Context

Five independent scaling hotspots, each evidenced by a full scan or an
unbounded query path on a growing tenant base: (1) the KPI dashboard
loaded 12 months of RAW order rows into JS to bucket them by month;
(2) the sitemap read unbounded site + blog tables per request; (3) the
usage engine ran eight aggregate scans per call, repeated per dashboard
view and per write-gate; (4) tenant phone-uniqueness deep-checks parsed
`orgJson` of EVERY Instance row on each availability probe; (5) the image
GC's write-path reference check raced file deletion against reference
re-creation.

## Decision

Apply five scoped fixes, each the smallest change that removes the scan,
with honest documentation of any property traded:

1. **SQL month bucketing with tz parity** (stats.ts): revenue is grouped
   in SQL using the app server's resolved timezone
   (`Intl.DateTimeFormat().resolvedOptions().timeZone`) so the SQL buckets
   match the JS `monthKey()` local-calendar semantics EXACTLY — labels
   stay local months, empty months still render honest zeros.
2. **Sitemap bounds** (sitemap.ts): the site query is take-capped at 20k
   rows (40k emitted URLs — headroom under the 50k-per-sitemap-file
   protocol ceiling) and the blog query at the newest 10k published
   posts. Promotion from `force-dynamic` to ISR `revalidate` is
   deliberately NOT taken here — a build-time rendering change reviewed
   separately (TECHNICAL-DEBT P2-5).
3. **Usage snapshot cache** (usage.ts): the eight aggregate scans are
   memoized per workspace for a 60 s TTL. **Documented security
   relaxation**: a burst of writes inside one window is checked against
   the window's opening snapshot — over-quota drift is bounded by ≤ 60 s
   of write throughput and caught by the first gate after expiry
   (self-healing reconciliation). "Client cannot fake usage" is unchanged
   (every value is still server-derived from DB ground truth), and
   `computedAt` in the DTO reports the snapshot's true age — staleness
   is visible, never hidden. Full transactional delta-counters remain
   the end-state (TECHNICAL-DEBT P1-3).
4. **Indexed tenant phone uniqueness** (migration
   `20260929110000_tenant_phone_index`): `Instance.orgPhoneIndex` stores
   the persisted `normalizePhoneDeep(org.phone)` comparison key with a
   plain index — the deep check becomes an indexed point lookup instead
   of a full-table `orgJson` parse. Legacy rows are NULL; backfill via
   `bun run backfill:phone-index` (release protocol), with a bounded
   legacy fallback retained for un-backfilled stores.
5. **GC write-path atomic-delete authority** (image-ref-gc.ts): the
   ATOMIC conditional delete (the `NOT EXISTS` reference re-check and the
   row delete in one statement) is the write-path AUTHORITY — a reference
   that re-appears between plan and execution re-creates the row safely,
   and the sweeper treats the write-path verdict as ground truth when
   reclaiming storage.

## Consequences

- **(+) Dashboard, sitemap, signup probes and GC scale linearly with the
  slice they actually need**, not the tenant's lifetime row count.
- **(+) The phone index converts an O(all-tenants) JSON parse into an
  index lookup** with a zero-downtime additive migration + backfill.
- **(−) The usage cache trades ≤ 60 s of quota strictness for an 8-scan
  reduction per call** — accepted, bounded, VISIBLE in the DTO, and
  slated for replacement by transactional counters.
- **(−) Sitemap bounds cap emitted URLs** — beyond the caps, older
  entries drop out (crawl-quality tradeoff documented in the route).
- Verified: sale-window/analytics, usage and GC suites in the offline
  battery; `tenant-uniqueness.test.ts`; migration applied on the live
  database during ROUND 165.
