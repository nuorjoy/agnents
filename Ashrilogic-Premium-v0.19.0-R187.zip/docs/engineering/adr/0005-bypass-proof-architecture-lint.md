# ADR 0005 — Bypass-proof architecture lint (all import forms + relative resolution)

- **Status:** ACCEPTED (ROUND 165) — implemented, probe-verified
- **Date:** 2026-09-29 (session ROUND 165)

## Context

Two structural ESLint rules guard the architecture boundary:

- `no-db-in-route-handler` — an API `route.ts` may not import the Prisma
  client (persistence belongs behind a domain repository/service or a
  lib/server engine);
- `no-server-only-in-client` — a `"use client"` file may not import
  `@/lib/db` or `@/lib/server/**`.

The ROUND-164 review found the implementation matched only
`ImportDeclaration` nodes with the `@/` alias — a rule that a route could
sidestep by writing `await import("@/lib/db")`, `require("@/lib/db")`, a
re-export (`export { db } from "@/lib/db"` / `export * from "@/lib/db"`),
or simply a relative path (`../../lib/db`). The frozen
`LEGACY_DB_ROUTES` allowlist (99 entries) makes the rule load-bearing for
the migration strategy: a bypass silently un-freezes the debt.

## Decision

Rebuild the detection so it matches EVERY import form that reaches the
module — static import, dynamic `import()`, `require()`,
`export … from`, `export *` — and resolves BOTH the `@/` alias AND
relative paths (`resolveModuleSource` normalizes the source to a module
identity before comparison). The rule semantics otherwise stay unchanged:
allowlisted legacy routes are grandfathered (shrink-only — entries are
NEVER added), everything else fails lint at `error` severity.

Verification was empirical: a 7-form bypass probe (one file exercising
each import form + both resolutions) was compiled against the rule —
all seven detected. The hardened rule then ran over the real tree and
found **2 actual violations**: `instances/[id]/passkeys` and
`mfa/setup` routes used `await import("@/lib/db")` for route-local
duplicated helpers — fixed by collapsing the duplicates into a shared
`readWorkspaceEmail()` in `instance-session.ts`, and the campaigns pair
was removed from the allowlist as part of the ROUND-165 decomposition
(99 entries remain).

## Consequences

- **(+) The boundary is now form-proof** — the only remaining bypass
  classes are deliberate rule changes or allowlist edits, both
  review-visible.
- **(+) The ratchet is real**: LEGACY_DB_ROUTES can only shrink, and each
  shrink is forced through the domain architecture.
- **(−) Import-form coverage must track the language** — a future
  ECMAScript/TypeScript import form would need a rule update (small,
  contained surface: one plugin).
- Documented in ARCHITECTURE.md §architecture lint ratchet;
  `no-server-only-in-client` current violations: 0.
