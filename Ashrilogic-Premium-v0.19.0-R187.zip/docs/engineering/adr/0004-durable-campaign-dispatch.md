# ADR 0004 — Durable campaign dispatch (EmailLog as the per-recipient ledger)

- **Status:** ACCEPTED (ROUND 165) — implemented, tested
- **Date:** 2026-09-29 (session ROUND 165)

## Context

The historical newsletter send path, inside one HTTP request:
`subscriber.count()` computed the audience, but delivery iterated
`findMany({ take: 5000 })` — **silent truncation above 5,000
subscribers** — and the entire bulk delivery ran inline, stamping the
campaign `sent` before any delivery outcome existed. No durable queue, no
per-recipient results, no retries, no crash recovery. A request timeout
or process crash mid-send left an untruthful `sent` (or a lost half-send)
with no ledger to resume from.

## Decision

Rebuild the send path as a durable, database-backed pipeline; all state
is rows — a crashed process at ANY point loses nothing:

1. **CLAIM**: `PATCH { action:"send" }` transitions the draft to `sending`
   via CAS (one concurrent sender wins; the loser gets the historical
   409). The request performs NO delivery.
2. **ENQUEUE (cursor)**: the dispatcher (`startCampaignDispatcher`,
   60 s tick, SchedulerLease `campaign-dispatch` 5-min TTL, fail-closed
   skip) pages the audience with a **keyset cursor** (`id > cursor`,
   500 rows/tick) into PENDING `EmailLog` rows (type `campaign`), each
   with `idempotencyKey campaign:<cid>:<sid>` and a stable Message-ID.
   The cursor advances per batch: ANY audience size, no truncation,
   crash-resume from the persisted cursor.
3. **DELIVER (in place)**: bounded batches (100 rows/tick, ≤5 campaigns
   per tick) are driven through the existing mail retry/backoff pipeline
   (`deliverPendingOutboxRow`); an invalid address is skipped; a row that
   keeps failing **dead-letters after 5 attempts**.
4. **COMPLETION GATE**: the campaign is stamped `sent` ONLY when the
   enqueue has exhausted the audience (`dispatchEnqueueDone`) AND zero
   rows remain pending — together with `delivered`/`failed` counts and a
   `campaign.dispatch-completed` audit row (system actor, full outcome
   ledger). Until then it is honestly `sending`.

Schema support is the additive-only migration `20260929100000`
(`dispatchCursor`, `dispatchEnqueueDone`, `dispatchEnqueued`, `delivered`,
`failed`). The generic mail outbox sweeper EXCLUDES campaign rows — the
dispatcher owns them, eliminating the double-driver race. DELETE on a
mid-flight campaign answers 409.

## Consequences

- **(+) The take:5000 truncation class is closed** at every audience size
  (verified: 7 recipients at batch size 2).
- **(+) Bulk mail never runs inside an HTTP request**; crash at any point
  resumes from rows (verified: crash-resume idempotency test).
- **(+) The per-recipient ledger is EmailLog itself** — retries,
  dead-letters, at-least-once with stable Message-IDs, admin mail trail —
  reusing the ROUND-120 outbox architecture instead of a new queue.
- **(−) Delivery latency is dispatcher-cadence-bound** (up to ~60 s to
  first delivery; fan-in bounds throughput) — acceptable for newsletters
  by design.
- **(−) Two migration columns carry dispatch bookkeeping on the campaign
  row** — accepted; they are additive and untouched on legacy rows.
- Verified by `tests/security/campaign-dispatch.test.ts` (5 tests);
  documented in JOBS.md §campaign dispatcher and
  API-ARCHITECTURE.md §migration protocol.
