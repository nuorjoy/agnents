# ADR 0003 — Centralized secret minimum-length policy (32-char floor)

- **Status:** ACCEPTED (ROUND 165) — implemented, tested
- **Date:** 2026-09-29 (session ROUND 165)

## Context

Every long-lived key (session HMAC secret, field-encryption root key,
audit-chain key, order-integrity key, backup seal key, receipt-token key,
plan-order integrity key) resolves from an environment variable through
`loadSecret` in `src/lib/server/runtime-guard.ts`. Historically each
caller declared its own `minLen`: `tokens.ts` enforced 32, while
crypto-vault, audit-chain, wallet, audit-anchor, receipt-token and
plan-orders each accepted 16. The documented contract in `.env.example`
said "at least 32 characters" for the two root secrets — so half the
key surface silently accepted material weaker than the documented
contract. N callers ⇒ N chances to drift.

## Decision

Centralize the floor: `MIN_PROVISIONED_SECRET_LENGTH = 32` is exported
from `runtime-guard.ts` and enforced IN THE SINGLE LOADER. A `SecretSpec`
that declares a lower `minLen` is treated as a programming error and fails
loudly at module load. The seven call sites (tokens, crypto-vault,
audit-chain, wallet, audit-anchor, receipt-token, plan-orders) were
updated to the shared constant in ROUND 165; the production error message
carries the documented contract so remediation is self-describing.

The rest of the loader's posture is unchanged and remains part of this
policy: provisioned env secret of sufficient length always wins;
production fails fast on missing/weak; dev/test may use the documented
demo constants (loud one-time banner); any other NODE_ENV shape requires
explicit `ALLOW_DEMO_SECRETS=1`.

## Consequences

- **(+) The 16/32 split is closed** — no key can be weaker than any other,
  and future keys inherit the floor by construction (they must route
  through the loader to resolve at all).
- **(+) Weaker specs fail at module load** — the drift class is now a
  crash, not a posture.
- **(−) Deployments previously running 17–31-char keys under the
  16-len callers must rotate to ≥ 32 chars** — intentional breaking
  change for an undersized secret; the boot error states the requirement.
- Verified by `tests/security/secret-policy.test.ts` (6 tests); the floor
  is cross-referenced in SECURITY-MODEL.md §Secrets and DEPLOYMENT.md.
