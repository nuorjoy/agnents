# ADR 0002 — Fail-closed production invariants (storage + proxy trust)

- **Status:** ACCEPTED (ROUND 161 invariant → ROUND 165 fail-closed) — implemented, tested
- **Date:** 2026-09-29 (session ROUND 165)

## Context

Two production misconfigurations previously degraded SILENTLY:

1. **Storage**: with `ASHRILOGIC_STORAGE_DRIVER=local` on an ephemeral
   filesystem (Vercel `/tmp`, containers), uploaded images, the mail spool
   and backup off-site members vanish on restart. The ROUND-161 invariant
   only `console.warn`ed at boot — the process kept running and the data
   loss surfaced later, unattributed.
2. **Proxy trust**: the client-IP trust model defaulted to "always" when
   `TRUST_PROXY_MODE` was unset. Behind the overwrite-mode proxy that is
   sound; on direct exposure every per-IP throttle, the IP banlist and
   session/audit attribution become forgeable via `X-Forwarded-For`.

In both cases the operator is the ONLY party who knows the deployment
shape (durable volume? proxy in front?) — the application cannot infer it
reliably.

## Decision

Make both assertions **explicit operator statements, enforced as boot
gates that throw**:

- `assertDurableStorageInvariant()` (storage/object-store.ts) runs at
  instrumentation boot AND re-runs at first storage use
  (`objectStorage()`) as defense in depth. Production + local driver +
  no `ALLOW_LOCAL_STORAGE_IN_PRODUCTION=1` ⇒ the server refuses to start.
  The flag is an explicit durable-volume assertion, never a convenience.
- `assertExplicitProxyTrustMode()` (rate-limit.ts) refuses production boot
  unless `TRUST_PROXY_MODE` is one of the three documented modes
  (`always` / `conditional` / `never`); `conditional` anchors trust on the
  platform edge header only (the historical circular x-real-ip trust was
  removed). Next.js re-throws `register()` errors, so the gates genuinely
  stop the boot (verified via instrumentation-globals).

## Consequences

- **(+) Silent data loss and forgeable throttles become loud, immediate,
  actionable boot failures** with the remediation in the error text.
- **(+) Correct-by-construction** for future deployments — no runbook
  knowledge required to be safe; the deployment shape must be declared.
- **(−) Zero-config boots are impossible in production** — deliberate: a
  production deployment MUST make two decisions (storage durability,
  proxy trust) and this records them.
- Verified by `tests/security/storage-invariant.test.ts` (7) and
  `tests/security/proxy-trust.test.ts` (7); documented in
  SECURITY-MODEL.md and OPERATIONS.md.
