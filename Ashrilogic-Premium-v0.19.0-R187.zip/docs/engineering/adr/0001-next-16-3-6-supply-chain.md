# ADR 0001 — Upgrade Next.js 16.3.5 → 16.3.6

- **Status:** ACCEPTED (ROUND 165) — implemented and verified
- **Date:** 2026-09-29 (session ROUND 165)

## Context

GHSA-vcvr-r3jv-pc5j (Satori RCE, critical severity) affects
`next >= 16.2.0 < 16.3.6`. The project pinned 16.3.5 — inside the affected
range. Codebase inspection confirmed the application does NOT import
`next/og` (the vulnerable rendering surface). Related advisories
(CVE-2025-66478 React RSC RCE — CVSS 10 — plus the follow-up DoS/SCX
CVEs) were assessed: 16.3.5 is not affected by the React RCE (patched in
16.0.7+; react 19.2.3 is a patched direct dependency), and 16.3.6 is the
current Active LTS patched release for the remainder of the family.

## Decision

Upgrade `next` 16.3.5 → 16.3.6 together with `eslint-config-next@16.3.6`,
despite the app not exercising the vulnerable import path. Rationale:
supply-chain posture — the platform runs the patched Active LTS so the
question "are we affected by this advisory?" never depends on a claim
about internal import graphs staying true over time. The OSV vulnerability
gate (CI) would otherwise permanently report an in-range dependency.

## Consequences

- **(+) The advisory is closed by version position, not by a usage
  argument.** Future audits need no reasoning about `next/og` reachability.
- **(+) The CI OSV gate stays green** for direct dependencies.
- **(−) A patch bump carries integration risk** — mitigated by the full
  verification loop: boot verified, HTTP 200 verified, tsc/eslint clean,
  offline battery 76/76 (including the 4 ROUND-165 suites).
- Follow-up CVEs against 16.3.6 would re-open this decision; the OSV gate
  is the standing tripwire (unfixed industry CVEs are tracked, not
  blocking).
