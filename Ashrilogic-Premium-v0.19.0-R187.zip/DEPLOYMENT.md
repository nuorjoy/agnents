# DEPLOYMENT — Ashrilogic Premium

Production deployment guide (historical posture: Vercel + Neon PostgreSQL;
any managed PostgreSQL works — the app is single-provider and refuses
non-PostgreSQL `DATABASE_URL`). Local/quick start: README.md. Operator
runbook (boot gates, backups, incidents): docs/engineering/OPERATIONS.md.

## 1. Provision

1. **Database** — managed PostgreSQL (Neon or equivalent). Note the server
   major version: the backup subsystem spawns `pg_dump`/`pg_restore` at
   runtime, and the CLIENT major version must match the SERVER.
2. **Object storage** — S3-compatible bucket (AWS S3, MinIO, Cloudflare R2).
3. **Secrets** — generate two independent random values ≥ 32 characters
   (`ADMIN_SESSION_SECRET`, `ASHRILOGIC_DATA_KEY`), plus
   `ASHRILOGIC_BACKUP_KEY` if off-site backups will run.

## 2. Environment variables

| Variable | Required | Notes |
| --- | --- | --- |
| `DATABASE_URL` | **yes** | `postgresql://…` only (src/lib/db.ts refuses anything else) |
| `ADMIN_SESSION_SECRET` | **yes (prod)** | ≥ 32 chars — session HMAC; boot fails fast below the floor |
| `ASHRILOGIC_DATA_KEY` | **yes (prod)** | ≥ 32 chars — field-encryption root key (HKDF → AES-256-GCM + blind indexes) |
| `TRUST_PROXY_MODE` | **yes (prod)** | explicit `always` / `conditional` / `never` — see matrix below |
| `NODE_ENV` | set by platform | `production` arms every boot gate |
| `ASHRILOGIC_STORAGE_DRIVER` | **yes (prod)** | `s3` (recommended) or `local` |
| `ALLOW_LOCAL_STORAGE_IN_PRODUCTION` | only for local driver | `=1` asserts a DURABLE volume; never on Vercel/containers |
| `S3_ENDPOINT` | with s3 driver | MinIO/R2: your endpoint; AWS: leave empty or region endpoint |
| `S3_BUCKET` | with s3 driver | bucket name |
| `S3_REGION` | with s3 driver | region |
| `S3_ACCESS_KEY_ID` / `S3_SECRET_ACCESS_KEY` | with s3 driver | credentials |
| `S3_KEY_PREFIX` | optional | key namespace inside the bucket |
| `ASHRILOGIC_BACKUP_KEY` | for off-site backups | AES-256-GCM envelope sealing; off-site/mirror REFUSE to run without it |
| `ASHRILOGIC_BACKUP_KEY_PREVIOUS` | during rotation | old key drained by the sweeper before removal |
| `SMTP_URL` / `MAIL_FROM` | for mail | smtp(s)://… transport; campaigns and business notices need it |
| `WEBHOOK_ALLOWED_HTTPS_PORTS` | optional | webhook destination port allowlist |
| `ALLOW_HTTP_LOOPBACK_WEBHOOKS` | optional (default 0) | loopback http webhook opt-in, non-production only |
| `TRUSTED_EDGE_IPS` | optional | extra trusted edge IPs for `conditional` proxy mode |
| `ASHRILOGIC_AUDIT_ANCHOR_FILE` | optional | external audit anchor location |
| `ASHRILOGIC_BACKUP_MIRROR_DIR` | optional | local mirror member location |
| `ASHRILOGIC_OPS_LOG` | optional | oplog location |
| `TEST_DATABASE_URL` | never in prod | throwaway test fixture only |

## 3. Storage driver setup

- **S3 / MinIO / R2** (production default): set the `S3_*` block above.
  Keys are content-addressed and server-derived — no client-controlled
  path segments. Re-encoding (sharp → WebP) happens before persistence.
- **Local driver**: fine for durable self-hosted volumes
  (`ASHRILOGIC_STORAGE_DIR`). In production this REQUIRES
  `ALLOW_LOCAL_STORAGE_IN_PRODUCTION=1` — an explicit operator assertion
  that the directory sits on durable media. On ephemeral filesystems
  (Vercel `/tmp`, containers) the boot REFUSES: uploads, the mail spool,
  and backup off-site members would silently vanish on restart.

## 4. TRUST_PROXY_MODE decision matrix

| Deployment shape | Mode | Why |
| --- | --- | --- |
| Vercel (or any platform edge that injects `x-vercel-forwarded-for`) | `conditional` | forwarded headers trusted ONLY behind the platform edge anchor; everything else collapses to the untrusted bucket (fail-closed) |
| Own overwrite-mode reverse proxy in front (the bundled Caddyfile pattern) | `always` | the proxy overwrites `X-Forwarded-For`/`X-Real-IP` with the real client address; rightmost-entry parsing is correct |
| Direct exposure, no proxy (testing only) | `never` | all forwarded headers ignored; every client shares one limiter bucket — NOT production-viable for multi-user |

Production boot REFUSES an unset/unrecognized mode: an implicit "always"
behind no proxy makes every per-IP throttle and the IP banlist forgeable.

## 5. SMTP

Set `SMTP_URL` (e.g. `smtps://user:pass@host:465`) and `MAIL_FROM`.
Mail delivery is durable: `sendMail` persists a PENDING `EmailLog` row
before transport; a 60 s outbox sweeper re-drives crashed sends; campaign
bulk mail runs ONLY through the dispatcher (never inside HTTP requests).
Without SMTP configured, mail-dependent surfaces (campaigns, digests,
notices) will dead-letter — set it before relying on them.

## 6. First boot

```bash
bun install
bunx prisma migrate deploy      # versioned migrations — the production path
bun run db:generate             # Prisma client
bun run bootstrap:admin         # provisions the super-admin credentials
```

`bootstrap:admin` (scripts/bootstrap-admin.ts) is the production path for
the first super-admin. NEVER run `seed:demo` on a production database —
demo credentials are dev/test only and production never arms them.

## 7. Post-deploy verification checklist

1. Boot completed with no gate errors (storage invariant, proxy trust,
   secret floors — OPERATIONS.md §boot gates).
2. All 10 scheduler registration lines appear in server logs
   (JOBS.md inventory).
3. `GET /api/healthz` → 200 (liveness); `GET /api/readyz` → 200
   (readiness touches the database).
4. Admin console login works with the bootstrap credentials; MFA/passkey
   enrollment surfaces respond.
5. Upload one image through the product surface → object appears under the
   S3 prefix / storage dir; fetch renders.
6. Webhook endpoint registration accepts an https URL; a test order event
   delivers with `X-Ashrilogic-Signature`.
7. `bun run verify:audit` passes on the fresh chain; the anchor file is
   being written hourly.
8. Trigger a manual backup; confirm the snapshot + sealed off-site member;
  then a restore drill on a staging tenant (RestoreLease + 503 window
   behavior).
9. Run the full battery on the staging twin: `bash .zscripts/test-battery.sh`.
10. Release archive only via `bash .zscripts/package-release.sh <TAG>`
    (allowlist-staged; strict Caddy gate inside).

## 8. Release / migration order

`migrate deploy` → `backfill:phone-index` (ROUND-165
`Instance.orgPhoneIndex` legacy rows — the deep uniqueness check keeps a
bounded fallback until backfilled) → battery → `package:release`. Both
R165 migrations are additive-only and safe to deploy ahead of code.

## 9. One-command deployment (ROUND 166)

`scripts/deploy-vercel.sh` automates §2–§5 against the GitHub-hosted source
(`nuorjoy/Ashrilogic`, private): creates-or-reuses the Vercel project linked
to the repo (auto-deploy on every push to `main`), upserts the full
production env (Neon pooled `DATABASE_URL` + `DIRECT_DATABASE_URL`, the two
generated ≥32-char root secrets — printed once for archival —,
`TRUST_PROXY_MODE=always`, `ASHRILOGIC_STORAGE_DRIVER=s3`), applies the
versioned migration chain to Neon via the DIRECT url, bootstraps the first
super admin, and triggers + verifies the production deployment. Idempotent:
re-running converges.

```bash
VERCEL_TOKEN=vcp_… \
DATABASE_URL='postgresql://…-pooler…/neondb?sslmode=require' \
DIRECT_DATABASE_URL='postgresql://…/neondb?sslmode=require' \
INIT_ADMIN_PASSWORD='…' \
bash scripts/deploy-vercel.sh
```
