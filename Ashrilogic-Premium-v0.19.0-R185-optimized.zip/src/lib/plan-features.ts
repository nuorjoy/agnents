/**
 * ROUND 79 — plan capability catalog + feature resolution (PURE module —
 * importable from the server AND the client; no db / no next/server here).
 *
 * The platform's feature system, in precedence order (HIGHEST wins):
 *
 *   1. Instance.featureOverridesJson  — per-tenant switches the PLATFORM
 *      flips from the admin console WITHOUT touching code:
 *        { "featureKey": true  }  → force-ON  (granted even below plan tier)
 *        { "featureKey": false }  → force-OFF (revoked even on Enterprise)
 *   2. Workspace state:
 *        - "trial"  (14-Day FULL ACCESS) → every feature ON (source "trial")
 *        - "active" WITHOUT a package (platform-managed showcase rows) →
 *          every feature ON (source "platform")
 *   3. Package.capabilitiesJson — the machine-readable feature list of the
 *      assigned plan (falls back to DEFAULT_CAPABILITIES by the package's
 *      Arabic name for legacy rows with an empty list).
 *
 * Enforced SERVER-SIDE per route via featureGateResponse() (403
 * FEATURE_NOT_IN_PLAN + upgrade hint) — the client mirrors the map purely
 * for premium lock screens with an upgrade CTA, never for access itself.
 */
/* ROUND 145 (145-fix-qual) — type-only import: erased at compile time, so
 * the module stays PURE (no runtime dependency on the i18n bundle). */
import type { I18nKey } from "@/lib/i18n";

/** The one and only catalog — a feature exists ONLY if listed here.
 *
 * ROUND 80 expanded the catalog 8 → 16: the new "modules" group carries the
 * PREMIUM MODULE family (pos, barcode, loyalty, subscriptions, staff,
 * branches, insurance, telemedicine) whose workspaces are plan-gated via
 * MODULE_FEATURE_GATES — a Starter tenant sees a premium lock card with an
 * upgrade CTA instead of the module, and the records API answers 403
 * FEATURE_NOT_IN_PLAN (defense in depth — the client mirror never gates). */
export const PLAN_FEATURES = [
  "publicWebsite",
  "store",
  "coupons",
  "reviews",
  "aiInsights",
  "translations",
  "backup",
  "dataExport",
  /* ROUND 80 — premium module family ("الوحدات المتقدمة") */
  "pos",
  "barcode",
  "loyalty",
  "subscriptions",
  "staff",
  "branches",
  "insurance",
  "telemedicine",
] as const;

export type PlanFeature = (typeof PLAN_FEATURES)[number];

/** Where an effective feature decision came from (UI chips + audit meta). */
export type FeatureSource = "override" | "trial" | "platform" | "plan";

export interface FeatureResolution {
  enabled: boolean;
  source: FeatureSource;
}

/** Presentation metadata for UI (order + grouping + i18n label keys).
 * ROUND 145 (145-fix-qual) — labelKey/descKey are now TYPED I18nKey (the
 * composer's union): every consumer t() call type-checks at compile time,
 * and the ~20 `as I18nKey` casts at the call sites became redundant. */
export const FEATURE_META: Record<
  PlanFeature,
  { group: "presence" | "commerce" | "intelligence" | "data" | "modules"; icon: string; labelKey: I18nKey; descKey: I18nKey }
> = {
  publicWebsite: { group: "presence", icon: "globe", labelKey: "featPublicWebsite", descKey: "featPublicWebsiteDesc" },
  store: { group: "commerce", icon: "shopping-bag", labelKey: "featStore", descKey: "featStoreDesc" },
  coupons: { group: "commerce", icon: "ticket-percent", labelKey: "featCoupons", descKey: "featCouponsDesc" },
  reviews: { group: "commerce", icon: "star", labelKey: "featReviews", descKey: "featReviewsDesc" },
  aiInsights: { group: "intelligence", icon: "sparkles", labelKey: "featAiInsights", descKey: "featAiInsightsDesc" },
  translations: { group: "intelligence", icon: "languages", labelKey: "featTranslations", descKey: "featTranslationsDesc" },
  backup: { group: "data", icon: "database-backup", labelKey: "featBackup", descKey: "featBackupDesc" },
  dataExport: { group: "data", icon: "file-down", labelKey: "featDataExport", descKey: "featDataExportDesc" },
  /* ROUND 80 — premium module family */
  pos: { group: "modules", icon: "calculator", labelKey: "featPos", descKey: "featPosDesc" },
  barcode: { group: "modules", icon: "barcode", labelKey: "featBarcode", descKey: "featBarcodeDesc" },
  loyalty: { group: "modules", icon: "heart", labelKey: "featLoyalty", descKey: "featLoyaltyDesc" },
  subscriptions: { group: "modules", icon: "repeat", labelKey: "featSubscriptions", descKey: "featSubscriptionsDesc" },
  staff: { group: "modules", icon: "users", labelKey: "featStaff", descKey: "featStaffDesc" },
  branches: { group: "modules", icon: "network", labelKey: "featBranches", descKey: "featBranchesDesc" },
  insurance: { group: "modules", icon: "shield-check", labelKey: "featInsurance", descKey: "featInsuranceDesc" },
  telemedicine: { group: "modules", icon: "video", labelKey: "featTelemedicine", descKey: "featTelemedicineDesc" },
};

/** Feature groups in display order (label keys resolved by the UI —
 * ROUND 145: typed I18nKey). */
export const FEATURE_GROUPS: { key: "presence" | "commerce" | "intelligence" | "data" | "modules"; labelKey: I18nKey }[] = [
  { key: "presence", labelKey: "featGroupPresence" },
  { key: "commerce", labelKey: "featGroupCommerce" },
  { key: "intelligence", labelKey: "featGroupIntelligence" },
  { key: "data", labelKey: "featGroupData" },
  { key: "modules", labelKey: "featGroupModules" },
];

/**
 * Default capability sets for the three STANDARD tiers. Used for legacy
 * package rows whose capabilitiesJson is empty — the platform can override
 * the stored list any time from the admin console (dynamic, no code edits).
 *
 * ROUND 80 — the premium module family joins the ladder: pos/barcode/
 * loyalty/subscriptions/staff unlock at Professional; branches/insurance/
 * telemedicine stay Enterprise-exclusive.
 */
export const DEFAULT_CAPABILITIES: Record<"starter" | "professional" | "enterprise", PlanFeature[]> = {
  starter: ["reviews", "dataExport"],
  professional: [
    "store", "coupons", "reviews", "aiInsights", "translations", "backup", "dataExport",
    "pos", "barcode", "loyalty", "subscriptions", "staff",
  ],
  enterprise: [
    "publicWebsite", "store", "coupons", "reviews", "aiInsights", "translations", "backup", "dataExport",
    "pos", "barcode", "loyalty", "subscriptions", "staff", "branches", "insurance", "telemedicine",
  ],
};

/** ROUND 80 — module-id → plan-feature gate map. A module workspace whose
 * id appears here refuses records (403 FEATURE_NOT_IN_PLAN) and renders a
 * premium lock card when the tenant's plan lacks the mapped feature.
 * Unlisted modules are never plan-gated. Pure + shared (server + client). */
export const MODULE_FEATURE_GATES: Record<string, PlanFeature> = {
  pos: "pos",
  barcode: "barcode",
  loyalty: "loyalty",
  subscriptions: "subscriptions",
  staff: "staff",
  branches: "branches",
  insurance: "insurance",
  telemedicine: "telemedicine",
};

/** Map a stored package name (AR or EN) to its standard tier, if any. */
export function standardTierOf(nameAr: string, nameEn?: string): "starter" | "professional" | "enterprise" | null {
  const n = `${nameAr} ${nameEn ?? ""}`;
  if (/(مؤسس|Enterprise)/i.test(n)) return "enterprise";
  if (/(احتراف|Professional)/i.test(n)) return "professional";
  if (/(أساس|Starter|Basic)/i.test(n)) return "starter";
  return null;
}

/** Parse a stored capabilitiesJson — invalid keys are dropped (never trusted). */
export function parseCapabilities(json: string | null | undefined, tierFallback: "starter" | "professional" | "enterprise" | null): PlanFeature[] {
  let keys: unknown = [];
  try {
    keys = json ? JSON.parse(json) : [];
  } catch {
    keys = [];
  }
  const valid = Array.isArray(keys)
    ? keys.filter((k): k is PlanFeature => typeof k === "string" && (PLAN_FEATURES as readonly string[]).includes(k))
    : [];
  /* legacy rows (or custom packages with no list yet) resolve to their
     standard tier's default set — custom tiers fall back to the starter set
     so an unnamed plan is NEVER accidentally full-access. */
  if (valid.length === 0 && tierFallback) return [...DEFAULT_CAPABILITIES[tierFallback]];
  return valid;
}

/** Parse a stored featureOverridesJson — invalid keys are dropped. */
export function parseOverrides(json: string | null | undefined): Partial<Record<PlanFeature, boolean>> {
  let map: unknown = {};
  try {
    map = json ? JSON.parse(json) : {};
  } catch {
    map = {};
  }
  const out: Partial<Record<PlanFeature, boolean>> = {};
  if (map && typeof map === "object") {
    for (const [k, v] of Object.entries(map as Record<string, unknown>)) {
      if ((PLAN_FEATURES as readonly string[]).includes(k) && typeof v === "boolean") {
        out[k as PlanFeature] = v;
      }
    }
  }
  return out;
}

export interface ResolveFeaturesInput {
  /** live workspace state (from computeEntitlement) */
  state: "active" | "trial" | "locked";
  /** a package is assigned (paid / platform-managed plan) */
  hasPackage: boolean;
  /** the assigned plan's capability list (already parsed) */
  capabilities: PlanFeature[];
  /** the per-tenant platform overrides (already parsed) */
  overrides: Partial<Record<PlanFeature, boolean>>;
}

/**
 * Resolve the EFFECTIVE feature map — pure. A locked workspace resolves to
 * everything OFF (its surfaces are already blocked by the lock gate; the
 * OFF map keeps client lock screens honest). Explicit overrides win over
 * EVERYTHING else, including the trial's full access.
 */
export function resolveInstanceFeatures(input: ResolveFeaturesInput): Record<PlanFeature, FeatureResolution> {
  const out = {} as Record<PlanFeature, FeatureResolution>;
  for (const key of PLAN_FEATURES) {
    if (key in input.overrides) {
      out[key] = { enabled: input.overrides[key] === true, source: "override" };
      continue;
    }
    if (input.state === "locked") {
      out[key] = { enabled: false, source: "plan" };
    } else if (input.state === "trial") {
      out[key] = { enabled: true, source: "trial" };
    } else if (!input.hasPackage) {
      out[key] = { enabled: true, source: "platform" };
    } else {
      out[key] = { enabled: input.capabilities.includes(key), source: "plan" };
    }
  }
  return out;
}

/** Flat boolean map for DTO transport (clients check `features[key]`). */
export function featuresToBooleans(res: Record<PlanFeature, FeatureResolution>): Record<PlanFeature, boolean> {
  const out = {} as Record<PlanFeature, boolean>;
  for (const key of PLAN_FEATURES) out[key] = res[key].enabled;
  return out;
}

/** Guard used by API validation: a body-provided feature key must exist. */
export function isPlanFeature(key: string): key is PlanFeature {
  return (PLAN_FEATURES as readonly string[]).includes(key);
}

/* ------------------------------------------------------------------ */
/* ROUND 87 — STRICT marketing-feature lines (الباقات → المزايا)        */
/* ------------------------------------------------------------------ */

/** The owner demanded a VERY strict features editor: precise lines, live
 *  lint, hard server validation. These pure helpers are shared verbatim by
 *  the admin client editor and the package schemas (single source of
 *  truth). */

export const MIN_PACKAGE_FEATURES = 3;
export const MAX_PACKAGE_FEATURES = 24;
export const PACKAGE_FEATURE_MIN_CHARS = 2;
export const PACKAGE_FEATURE_MAX_CHARS = 200;

/**
 * Normalize ONE feature line "بديقة":
 *  • strip control characters;
 *  • strip leading bullet/dash markers people paste (• · ▪ ● ○ * - – — +);
 *  • collapse inner whitespace runs to single spaces;
 *  • trim.
 * Idempotent — normalizing an already-clean line is a no-op.
 */
export function normalizeFeatureLine(raw: string): string {
  return raw
    .replace(/[\u0000-\u001f\u007f]/g, "")
    .replace(/^[\s•·▪▫●○◦*\-–—>+]+/u, "")
    .replace(/\s+/g, " ")
    .trim();
}

/** Parse a textarea's raw value into candidate feature lines (blanks kept
 *  as "" so the linter can point at the exact line number). */
export function rawFeatureLines(raw: string): string[] {
  return raw.split("\n").map((line) => line.replace(/\r$/, ""));
}

export interface FeatureLineIssue {
  line: number;
  kind: "short" | "long" | "duplicate" | "min" | "max";
  text?: string;
}

export interface FeatureLintResult {
  /** the normalized, valid-as-typed lines (before dedup decisions) */
  lines: string[];
  issues: FeatureLineIssue[];
  /** normalized duplicates (exact, case-insensitive) — the save is refused */
  duplicates: string[];
  count: number;
  valid: boolean;
}

/**
 * Lint the feature lines the way the SERVER will judge them — the editor
 * shows these exact verdicts live. `valid` = the list would pass the write
 * schema (count within range, every line within char range, no duplicates;
 * blank lines are ignored by the parser and are NOT an error).
 */
export function lintFeatureLines(raw: string): FeatureLintResult {
  const lines = rawFeatureLines(raw)
    .map(normalizeFeatureLine)
    .filter((line) => line.length > 0);
  const issues: FeatureLineIssue[] = [];
  const duplicates: string[] = [];
  const seen = new Map<string, number>();
  rawFeatureLines(raw).forEach((rawLine, idx) => {
    const norm = normalizeFeatureLine(rawLine);
    if (norm.length === 0) return; // blank line — ignored, not an error
    if (norm.length < PACKAGE_FEATURE_MIN_CHARS) {
      issues.push({ line: idx + 1, kind: "short", text: norm });
      return;
    }
    if (norm.length > PACKAGE_FEATURE_MAX_CHARS) {
      issues.push({ line: idx + 1, kind: "long", text: norm.slice(0, 30) });
      return;
    }
    const key = norm.toLocaleLowerCase("ar");
    if (seen.has(key)) {
      duplicates.push(norm);
      issues.push({ line: idx + 1, kind: "duplicate", text: norm });
    } else {
      seen.set(key, idx + 1);
    }
  });
  if (lines.length < MIN_PACKAGE_FEATURES) {
    issues.push({ line: 0, kind: "min" });
  }
  if (lines.length > MAX_PACKAGE_FEATURES) {
    issues.push({ line: 0, kind: "max" });
  }
  return {
    lines,
    issues,
    duplicates,
    count: lines.length,
    valid:
      issues.length === 0 &&
      duplicates.length === 0 &&
      lines.length >= MIN_PACKAGE_FEATURES &&
      lines.length <= MAX_PACKAGE_FEATURES,
  };
}

/* ------------------------------------------------------------------ */
/* ROUND 79 → ROUND 80 — dynamic discounts (pure shared helpers)        */
/* ------------------------------------------------------------------ */

/** Validated discount range: 0 (none) … 90. */
export const MAX_DISCOUNT_PCT = 90;

/** Effective price of a base price under a discount percentage. */
export function discountedPrice(base: number, pct: number): number {
  const p = Number.isFinite(pct) ? Math.max(0, Math.min(MAX_DISCOUNT_PCT, Math.round(pct))) : 0;
  return Math.max(0, Math.round((base * (100 - p)) / 100));
}

/** Discount presets offered in the admin console (the owner's 5%…50% ladder). */
export const DISCOUNT_PRESETS: number[] = [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50];

/** ROUND 80 — dedicated ANNUAL-cycle discount. `yearlyDiscountPct` = 0
 * means "inherit the monthly promotion" (legacy rows keep rendering
 * exactly as before); a value > 0 wins for the yearly cycle only. */
export function effectiveYearlyPct(pkg: { discountPct: number; yearlyDiscountPct?: number | null }): number {
  const y = pkg.yearlyDiscountPct ?? 0;
  const pct = y > 0 ? y : (pkg.discountPct ?? 0);
  return Math.max(0, Math.min(MAX_DISCOUNT_PCT, Math.round(pct)));
}

/** The per-cycle promotion a surface should apply (monthly → discountPct,
 * yearly → effectiveYearlyPct). */
export function cycleDiscountPct(
  pkg: { discountPct: number; yearlyDiscountPct?: number | null },
  cycle: "monthly" | "yearly"
): number {
  return cycle === "yearly"
    ? effectiveYearlyPct(pkg)
    : Math.max(0, Math.min(MAX_DISCOUNT_PCT, Math.round(pkg.discountPct ?? 0)));
}
