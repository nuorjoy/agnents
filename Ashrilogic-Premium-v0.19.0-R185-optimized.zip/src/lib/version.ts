/**
 * Ashrilogic — application version, SINGLE SOURCE OF TRUTH.
 *
 * The version lives in package.json (the release manifest) and is imported
 * here via a NAMED, tree-shakeable JSON import — every surface that needs
 * to display a version (console footers, admin footer, support contexts)
 * must consume APP_VERSION from this module. Hardcoding version literals
 * in components or i18n dictionaries is how the footer once drifted two
 * minor versions behind the release (0.15.0 shown while shipping 0.16.0);
 * scripts/verify-version-source.ts guards the dictionary side of that
 * contract at CI time (run via `bun run verify:version`).
 *
 * Named-import note: `import { version } from "../../package.json"` keeps
 * only the single string in the client bundle (webpack 5 tree-shakes JSON
 * named exports) — no manifest contents leak into the payload.
 */
import { version } from "../../package.json";

/** The platform's release version, e.g. "0.16.0". */
export const APP_VERSION: string = version;

/** Convenience display form: "Ashrilogic 0.16.0". */
export const APP_VERSION_LABEL: string = `Ashrilogic ${APP_VERSION}`;
