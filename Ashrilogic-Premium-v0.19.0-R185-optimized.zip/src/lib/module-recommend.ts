/**
 * ROUND 134-D — the wizard step-3 SMART MODULE RECOMMENDATION ENGINE.
 *
 * Owner directive: «في جميع الأنظمة الـ100 عند اعداد وتشغيل نظام جديد في
 * (الخطوة 3 من 7) اعداد النظام طور من طريقة التوصية (الموصى بها) لتكون
 * أكثر احترافية ودقة وذكاء خارق يستطيع التوصية بإحترافية» — this replaces
 * the old naive "first CORE_SIZE=8 curated modules = recommended" slicing in
 * modules-step.tsx with a per-system, per-tenant scoring engine.
 *
 * PURE + DETERMINISTIC by design: no clock, no randomness, no network, no
 * store reads — the only imports are the static catalog and the shared types.
 * The same input always produces a byte-identical result (fixed iteration
 * order + explicit tie-breakers), so it is trivially unit-testable and safe
 * on the server and during render.
 *
 * ============================ SCORING MODEL ============================
 * Every module of the system's EFFECTIVE list (systemMods() — the curated
 * set plus the resolver-appended "shifts" and "expenses") is scored 0..100
 * by additive, clamped stages:
 *
 *   A. CURATED PRIOR (82 → 38)      position decay over the system's curated
 *                                    module list (system.mods override, else
 *                                    category.mods). Earlier = stronger. The
 *                                    catalog's curation is real expert
 *                                    knowledge, so it is the dominant prior.
 *   B. UNIVERSAL BASES              reports = 78 (always high); expenses =
 *                                    62 (72 in trade/finance sectors);
 *                                    shifts = 45 (69 when POS/orders/cash
 *                                    anchors exist). A base only applies when
 *                                    it BEATS the curated prior.
 *   C. ORG-NAME KEYWORDS (+12/+6)   normalized (AR + EN) organization-name
 *                                    keywords detect the sector; the sector's
 *                                    signature modules gain +12 when the
 *                                    keyword matches the system's own sector,
 *                                    +6 cross-sector (cap +18/module).
 *   D. COUNTRY INTELLIGENCE         VAT country (GCC + EG + MA + DZ + TN +
 *                                    TR + GB + EU + IN + …) → invoices/taxes
 *                                    +8, reports +4; Arab-country language
 *                                    hint → reports +3.
 *   E. ROLE FIT (+6)                admin.role === "manager" → staff /
 *                                    attendance / scheduling.
 *   F. SECTOR COUPLING (+4/pair)    an operational COUPLING map (pos↔inventory,
 *                                    invoices↔payments, orders↔kitchen,
 *                                    students↔grades, accounting↔expenses …).
 *                                    Each partner with an EXPERT base ≥ 64
 *                                    earns +4, capped at +12. Coupling is
 *                                    computed on the expert base (stage A+B)
 *                                    so it never cascades through itself or
 *                                    through keyword boosts, and it only
 *                                    REINFORCES modules with an expert base
 *                                    ≥ 48 — strong operational pairs rise
 *                                    together, but signals alone never
 *                                    resurrect the deep curated tail.
 *
 * TIERS:  essential   = score ≥ 75 AND curated rank < 8 (the top of the
 *                      expert-curated backbone — mirrors the old CORE_SIZE
 *                      gate, but pruned by real intelligence);
 *         recommended = score ≥ 55;
 *         optional    = everything else.
 * The recommendedSet (essential ∪ recommended) is DYNAMIC — never a fixed
 * count; it typically spans 6–14 modules depending on system, sector,
 * org-name signals, country and role.
 *
 * Every recommendation carries 1–3 machine reason keys ("core",
 * "sectorMatch", "orgKeyword", "universal", `pairsWith:<module>`,
 * "vatCountry", "roleFit") that the UI maps to human strings via i18n.
 */
import { CATEGORY_MAP, SYSTEM_MAP, systemMods } from "@/data/catalog";
import type { SystemDef } from "@/lib/types";

/* ------------------------------------------------------------------ */
/* Public contracts                                                    */
/* ------------------------------------------------------------------ */

/** Inputs the engine needs — everything the wizard already holds in the draft. */
export interface RecommendInput {
  systemId: string;
  /** raw organization name (AR or EN, any casing) — scanned for sector keywords */
  orgName?: string;
  /** ISO-2 country code, e.g. "SA" — drives VAT / language intelligence */
  country?: string;
  /** currency code, e.g. "SAR" — corroborates the country signal */
  currency?: string;
  /** wizard admin role — "manager" gains ops-management boosts */
  role?: string;
}

/** Machine reason keys — mapped to localized human strings by the step UI. */
export type RecommendReasonKey =
  | "core"
  | "sectorMatch"
  | "orgKeyword"
  | "universal"
  | "vatCountry"
  | "roleFit"
  | `pairsWith:${string}`;

export interface ModuleRecommendation {
  /** 0..100 integer — the UI renders it as the match % chip */
  score: number;
  tier: "essential" | "recommended" | "optional";
  /** 1–3 reason keys, most informative first */
  reasons: RecommendReasonKey[];
}

export interface RecommendSignals {
  /** true when an org-name keyword sector matches the system's own category */
  sector: boolean;
  /** the org-name keywords that fired (raw form, AR or EN, capped at 4) */
  orgKeywords: string[];
  /** true when the chosen country applies VAT */
  countryVat: boolean;
  /** the role the engine actually scored with ("owner" | "manager") */
  role: string;
  /** the strongest operational pairs behind the coupling boosts (≤ 2) */
  topPairs: Array<{ module: string; with: string }>;
}

export interface RecommendResult {
  perModule: Map<string, ModuleRecommendation>;
  /** essential ∪ recommended, ordered best-first (score desc, curated rank asc) */
  recommendedSet: string[];
  signals: RecommendSignals;
}

/* ------------------------------------------------------------------ */
/* Weights (single tunable table — see the file header for semantics)  */
/* ------------------------------------------------------------------ */

const W = {
  priorTop: 82,          // curated rank 0 score
  priorSpan: 44,         // decay → last curated slot scores 38
  univReports: 78,       // reports always high
  univExpenses: 62,      // expenses broadly recommended
  univExpensesTrade: 72, // expenses high in trade/finance sectors
  univShifts: 45,        // shifts low by default (toggle, not a must)
  univShiftsCash: 69,    // shifts high when POS/orders/cash present
  keywordSameSector: 12, // org keyword matches the system's sector
  keywordCrossSector: 6, // detected but for another sector
  keywordCap: 18,        // max total keyword boost per module
  vatCore: 8,            // invoices / taxes in a VAT country
  vatReports: 4,         // reports in a VAT country
  langReports: 3,        // reports in a typical-Arabic country
  roleFit: 6,            // staff/attendance/scheduling for a manager
  couplingStep: 4,       // per strong partner present in the system
  couplingMax: 12,
  couplingAnchorMin: 64, // a partner counts as a strong anchor at ≥ 64
  couplingFloor: 48,     // coupling only reinforces modules already ≥ 48
  essentialScore: 75,
  essentialRank: 8,      // curated top-N gate (mirrors the old CORE_SIZE)
  recommendedScore: 55,
} as const;

/** Sectors where expenses are close to the operational heart (trade/finance). */
const EXPENSES_TRADE_SECTORS = new Set(["retail", "finance", "logistics", "general", "industry", "hospitality"]);

/** Cash-heavy module anchors that make الورديات genuinely valuable. */
const CASH_ANCHORS = ["pos", "orders", "payments", "invoices", "delivery", "deliveries"];

/** Modules a manager-role admin naturally leans on. */
const ROLE_FIT_MODULES = new Set(["staff", "attendance", "scheduling"]);

/** Countries applying VAT (GCC family + broader VAT jurisdictions). */
const VAT_COUNTRIES = new Set([
  "SA", "AE", "QA", "KW", "BH", "OM", "EG", "MA", "DZ", "TN", "JO",
  "TR", "GB", "EU", "IN", "ID", "MX", "BR", "PH", "VN", "TH", "PK",
]);

/** Countries whose typical business language is Arabic (reports hint). */
const ARAB_COUNTRIES = new Set([
  "SA", "AE", "QA", "KW", "BH", "OM", "EG", "MA", "DZ", "TN", "JO",
  "IQ", "LY", "SY", "LB", "YE", "SD", "SS",
]);

/** Currencies that corroborate a VAT country even when the code is odd. */
const VAT_CURRENCIES = new Set(["SAR", "AED", "QAR", "KWD", "BHD", "OMR", "EGP", "TRY"]);

/* ------------------------------------------------------------------ */
/* Normalization (engine-local — no imports beyond catalog + types)    */
/* ------------------------------------------------------------------ */

/**
 * Arabic + Latin search normalization: lowercase, strip tashkeel/tatweel,
 * unify alef/ya/ta-marbuta, drop zero-width marks, turn punctuation into
 * spaces (so word-boundary matching survives "مطاعم/كافيهات"), collapse.
 */
function normalizeText(input: string): string {
  return input
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670\u0640]/g, "")
    .replace(/[\u0622\u0623\u0625\u0627\u0671]/g, "\u0627")
    .replace(/\u0649/g, "\u064A")
    .replace(/\u0629/g, "\u0647")
    .replace(/[\u200B-\u200F\uFEFF\u061C]/g, "")
    .replace(/[_\-–—.,/\\()[\]{}:;'"«»؟?!،]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/* ------------------------------------------------------------------ */
/* Org-name sector keywords (AR + EN, word-boundary matched)           */
/* ------------------------------------------------------------------ */

interface SectorKeywords {
  id: string;
  /** [raw display form, normalized match form] */
  words: Array<[string, string]>;
}

/** Build the [raw, normalized] pairs from raw AR + EN word lists. */
function words(ar: string[], en: string[]): Array<[string, string]> {
  return [...ar, ...en].map((raw) => [raw, normalizeText(raw)] as [string, string]);
}

/* Fixed order = detection order (deterministic; first 2 detected sectors boost). */
const SECTOR_KEYWORDS: SectorKeywords[] = [
  {
    id: "health",
    words: words(
      ["مستشفى", "مستشفيات", "عيادة", "عيادات", "طبيب", "أطباء", "أسنان", "مختبر", "مختبرات", "صيدلية", "صيدليات", "تمريض", "طب", "بيطرية", "أشعة", "تأهيل", "علاج"],
      ["hospital", "hospitals", "clinic", "clinics", "medical", "medicine", "doctor", "doctors", "dental", "dentist", "pharmacy", "pharmacies", "physiotherapy", "rehab", "healthcare", "health", "laboratory", "diagnostic", "imaging", "veterinary", "vet"]
    ),
  },
  {
    id: "education",
    words: words(
      ["مدرسة", "مدارس", "معهد", "معاهد", "كلية", "كليات", "جامعة", "جامعات", "تدريب", "تعليم", "روضة", "ثانوية", "ابتدائية", "أكاديمية", "طلاب"],
      ["school", "schools", "academy", "academies", "institute", "institutes", "college", "colleges", "university", "universities", "training", "education", "educational", "kindergarten", "learning", "tuition"]
    ),
  },
  {
    id: "retail",
    words: words(
      ["متجر", "متاجر", "محل", "محلات", "تجزئة", "سوبرماركت", "سوبر ماركت", "بقالة", "تجارة", "سوق", "أسواق", "مول", "ماركت"],
      ["store", "stores", "shop", "shops", "retail", "supermarket", "market", "markets", "grocery", "boutique", "trading", "trade", "mall", "outlet", "mart"]
    ),
  },
  {
    id: "hospitality",
    words: words(
      ["مطعم", "مطاعم", "كافيه", "كافيهات", "مقهى", "مقاهي", "مخبز", "مخابز", "حلويات", "وجبات", "بيتزا", "برجر", "شاورما", "فندق", "فنادق", "ضيافة", "كاترينج"],
      ["restaurant", "restaurants", "cafe", "cafes", "coffee", "bakery", "bakeries", "food", "kitchen", "pizzeria", "burger", "grill", "hotel", "hotels", "hospitality", "catering", "juice", "shawarma", "sweets", "pastry"]
    ),
  },
  {
    id: "services",
    words: words(
      ["صالون", "صالونات", "حلاقة", "حلاق", "سبا", "خدمات", "صيانة", "تنظيف", "سباكة", "مغسلة", "شركة", "مكتب"],
      ["salon", "barbershop", "barber", "spa", "services", "service", "cleaning", "laundry", "repair", "grooming", "stylist", "beauty"]
    ),
  },
  {
    id: "finance",
    words: words(
      ["محاسبة", "محاسبي", "تدقيق", "مراجعة", "ضرائب", "مالي", "مالية", "استشارات", "استشارية"],
      ["accounting", "accountant", "accounts", "audit", "auditing", "tax", "taxes", "finance", "financial", "bookkeeping", "consultancy", "consulting"]
    ),
  },
  {
    id: "logistics",
    words: words(
      ["نقل", "شحن", "لوجستيك", "لوجستيات", "تخليص", "جمارك", "مستودع", "مستودعات", "توصيل"],
      ["logistics", "transport", "transportation", "shipping", "freight", "cargo", "customs", "clearance", "warehouse", "warehousing", "delivery", "courier", "trucking"]
    ),
  },
  {
    id: "agriculture",
    words: words(
      ["مزرعة", "مزارع", "مستزرع", "زراعة", "زراعي", "حظيرة", "حظائر", "دواجن", "ماشية", "نخل", "محصول"],
      ["farm", "farms", "farming", "agriculture", "agricultural", "poultry", "livestock", "dairy", "greenhouse", "crops", "plantation", "hatchery"]
    ),
  },
  {
    id: "industry",
    words: words(
      ["مصنع", "مصانع", "ورشة", "ورش", "صناعي", "صناعة", "تصنيع", "معمل", "بناء", "مقاولات", "هندسة", "هندسية"],
      ["factory", "industrial", "industries", "manufacturing", "manufacturer", "workshop", "workshops", "plant", "construction", "contracting", "contractor", "engineering", "engineers", "steel", "cement", "fabrication"]
    ),
  },
  {
    id: "media",
    words: words(
      ["تسويق", "إعلان", "إعلانات", "إعلام", "دعاية", "وكالة", "وكالات", "نشر", "مطبعة", "تصميم"],
      ["marketing", "advertising", "media", "agency", "agencies", "branding", "digital", "publishing", "publisher", "creative", "design", "studio", "communications"]
    ),
  },
  {
    id: "hr",
    words: words(
      ["موارد بشرية", "توظيف", "استقدام", "شؤون موظفين", "كوادر"],
      ["recruitment", "staffing", "manpower", "employment", "human", "resources", "hr"]
    ),
  },
  {
    id: "fun",
    words: words(
      ["ترفيه", "ألعاب", "ملاهي", "سينما", "بولينج", "بلياردو"],
      ["entertainment", "games", "arcade", "cinema", "bowling", "billiards", "fun", "gaming", "esports"]
    ),
  },
  {
    id: "legal",
    words: words(
      ["محامي", "محاماة", "محامون", "قانوني", "قانونية", "توثيق", "محكمين"],
      ["law", "legal", "attorney", "attorneys", "lawyer", "lawyers", "advocate", "advocates", "notary", "notaries", "chambers"]
    ),
  },
  {
    id: "nonprofit",
    words: words(
      ["جمعية", "جمعيات", "خيري", "خيرية", "تكافل", "تطوع", "أهلي", "وقف", "أوقاف"],
      ["nonprofit", "charity", "charities", "ngo", "foundation", "foundations", "waqf", "endowment", "volunteer", "volunteers", "humanitarian", "relief"]
    ),
  },
  {
    id: "general",
    words: words(
      ["حرفي", "تصليح", "كهرباء", "تكييف", "نجارة", "حدادة", "ميكانيك"],
      ["handyman", "repairs", "technician", "technicians", "electrician", "electricians", "plumbing", "plumber", "carpenter", "carpentry", "mechanic", "mechanics", "garage", "hvac", "maintenance"]
    ),
  },
];

/**
 * Each sector's SIGNATURE modules — the modules an org-name keyword of that
 * sector boosts (only those present in the system's effective list apply).
 */
const SECTOR_SIGNATURE: Record<string, string[]> = {
  health: ["patients", "appointments", "prescriptions", "ehr", "lab", "radiology", "insurance", "pharmacy", "beds", "operations", "emergency", "telemedicine"],
  education: ["students", "teachers", "courses", "grades", "attendance", "fees", "exams", "timetable", "parents", "elearning", "certificates"],
  retail: ["products", "pos", "inventory", "customers", "suppliers", "invoices", "purchases", "promotions", "loyalty", "pricing", "stocktake", "returns"],
  hospitality: ["menu", "orders", "kitchen", "tables", "reservations", "delivery", "rooms", "housekeeping", "events", "reviews"],
  services: ["bookings", "services", "customers", "staff", "scheduling", "memberships", "queue", "reminders", "commissions", "subscriptions"],
  finance: ["accounting", "invoices", "taxes", "reconciliation", "expenses", "payments", "bankfeeds", "quotations", "payroll", "documents"],
  logistics: ["shipments", "tracking", "fleet", "drivers", "routes", "warehouses", "deliveries", "customs", "documents"],
  agriculture: ["production", "harvest", "irrigation", "feeding", "animalhealth", "breeding", "assets", "sales"],
  industry: ["projects", "tasks", "assets", "maintenance", "quality", "safety", "drawings", "resources", "contracts"],
  media: ["campaigns", "leads", "content", "publishing", "analytics", "billing", "creative", "distribution", "documents"],
  hr: ["staff", "attendance", "payroll", "leaves", "recruitment", "training", "performance", "benefits", "onboarding", "timeclock"],
  fun: ["bookings", "members", "subscriptions", "tournaments", "sessions", "equipment", "loyalty", "pos"],
  legal: ["cases", "clients", "hearings", "contracts", "documents", "timetracking", "deadlines", "billing", "appointments"],
  nonprofit: ["donations", "members", "volunteers", "beneficiaries", "fundraising", "events", "communications", "documents"],
  general: ["jobs", "customers", "appointments", "commissions", "warranty", "tracking", "invoices", "staff"],
};

/* ------------------------------------------------------------------ */
/* Operational coupling map (module → strongly-related partners)       */
/* Both directions are listed so the pairing is symmetric in the UI.   */
/* Partners absent from the system's list are simply inert.            */
/* ------------------------------------------------------------------ */

const COUPLING: Record<string, string[]> = {
  pos: ["inventory", "customers", "loyalty", "shifts", "promotions", "returns", "products"],
  inventory: ["pos", "products", "purchases", "suppliers", "warehouses", "stocktake", "shifts"],
  products: ["pos", "inventory", "pricing", "promotions"],
  customers: ["invoices", "pos", "loyalty", "returns", "appointments", "bookings", "memberships", "sales"],
  invoices: ["customers", "payments", "taxes", "quotations", "accounting", "insurance"],
  payments: ["invoices", "customers", "subscriptions", "fees", "accounting"],
  orders: ["menu", "kitchen", "tables", "delivery", "customers", "shifts"],
  menu: ["orders", "kitchen", "products"],
  kitchen: ["orders", "menu", "inventory"],
  tables: ["orders", "reservations"],
  reservations: ["tables", "rooms", "customers"],
  rooms: ["reservations", "housekeeping"],
  housekeeping: ["rooms", "staff"],
  delivery: ["orders", "tracking", "drivers"],
  shifts: ["pos", "orders", "payments", "invoices", "staff", "attendance", "timeclock"],
  expenses: ["accounting", "invoices", "purchases"],
  accounting: ["expenses", "reconciliation", "bankfeeds", "taxes", "invoices", "payroll"],
  reconciliation: ["accounting", "bankfeeds", "insurance"],
  bankfeeds: ["accounting", "reconciliation"],
  taxes: ["invoices", "accounting"],
  quotations: ["invoices", "contracts", "customers"],
  purchases: ["suppliers", "inventory", "expenses"],
  suppliers: ["purchases", "inventory"],
  stocktake: ["inventory", "products"],
  pricing: ["products", "promotions", "pos"],
  promotions: ["pos", "pricing", "loyalty", "products"],
  loyalty: ["pos", "customers", "promotions", "members", "memberships"],
  returns: ["pos", "customers", "inventory"],
  sales: ["production", "customers", "invoices", "harvest"],
  appointments: ["customers", "staff", "reminders", "queue", "services"],
  bookings: ["customers", "staff", "scheduling", "sessions", "services", "queue"],
  scheduling: ["staff", "bookings", "classes", "lessons", "appointments"],
  services: ["appointments", "bookings", "queue", "commissions"],
  queue: ["appointments", "bookings", "staff", "services"],
  reminders: ["appointments", "bookings", "customers", "patients"],
  contracts: ["quotations", "clients", "documents", "cases"],
  documents: ["contracts", "cases", "clients"],
  commissions: ["services", "staff", "jobs", "customers"],
  subscriptions: ["members", "payments", "invoices", "memberships"],
  members: ["subscriptions", "memberships", "loyalty", "sessions", "coaches", "fundraising"],
  memberships: ["members", "customers", "loyalty"],
  sessions: ["bookings", "members", "classes", "equipment"],
  classes: ["scheduling", "members", "coaches", "attendance"],
  coaches: ["classes", "members", "training"],
  students: ["grades", "attendance", "fees", "exams", "timetable", "parents", "courses", "certificates", "teachers", "lessons"],
  teachers: ["students", "courses", "timetable", "attendance", "training"],
  courses: ["students", "teachers", "grades", "elearning", "exams"],
  grades: ["students", "exams", "courses", "certificates"],
  attendance: ["students", "staff", "timetable", "timeclock", "shifts", "classes"],
  fees: ["students", "invoices", "payments"],
  exams: ["students", "grades", "courses", "certificates"],
  timetable: ["students", "teachers", "attendance", "courses"],
  parents: ["students", "attendance"],
  elearning: ["students", "courses", "grades"],
  certificates: ["students", "exams", "courses"],
  cafeteria: ["students", "menu", "inventory"],
  transport: ["students", "tracking", "routes"],
  patients: ["appointments", "ehr", "prescriptions", "insurance", "lab", "radiology", "pharmacy", "telemedicine"],
  ehr: ["patients", "prescriptions", "lab", "radiology"],
  prescriptions: ["patients", "pharmacy", "ehr"],
  pharmacy: ["prescriptions", "inventory", "patients"],
  lab: ["patients", "ehr", "radiology"],
  radiology: ["patients", "ehr", "lab"],
  insurance: ["patients", "invoices", "reconciliation"],
  telemedicine: ["patients", "appointments", "prescriptions"],
  beds: ["operations", "emergency", "rooms"],
  operations: ["patients", "beds", "emergency", "staff"],
  emergency: ["patients", "beds", "operations", "staff"],
  staff: ["attendance", "payroll", "scheduling", "shifts", "timeclock", "leaves", "performance", "training", "commissions"],
  payroll: ["staff", "attendance", "accounting", "timeclock", "leaves", "benefits"],
  timeclock: ["staff", "attendance", "payroll", "shifts"],
  leaves: ["staff", "payroll", "attendance"],
  performance: ["staff", "attendance"],
  training: ["staff", "recruitment", "teachers", "coaches"],
  recruitment: ["staff", "training", "onboarding"],
  onboarding: ["recruitment", "staff"],
  benefits: ["staff", "payroll"],
  shipments: ["tracking", "fleet", "drivers", "routes", "deliveries", "warehouses", "customs"],
  tracking: ["shipments", "deliveries", "vehicles", "transport", "fleet"],
  fleet: ["drivers", "maintenance", "tracking", "shipments", "vehicles"],
  drivers: ["fleet", "shipments", "deliveries", "vehicles"],
  routes: ["fleet", "drivers", "shipments", "deliveries", "transport"],
  deliveries: ["shipments", "drivers", "tracking"],
  customs: ["shipments", "warehouses", "documents"],
  warehouses: ["inventory", "shipments", "customs"],
  vehicles: ["maintenance", "tracking", "lessons", "fleet", "drivers"],
  lessons: ["students", "teachers", "vehicles", "scheduling"],
  production: ["inventory", "harvest", "feeding", "sales", "irrigation"],
  harvest: ["production", "irrigation", "sales"],
  irrigation: ["production", "harvest"],
  feeding: ["production", "animalhealth"],
  animalhealth: ["feeding", "breeding", "production"],
  breeding: ["animalhealth", "production"],
  projects: ["tasks", "documents", "assets", "resources", "maintenance"],
  tasks: ["projects", "staff", "maintenance"],
  assets: ["maintenance", "projects", "inventory"],
  maintenance: ["assets", "equipment", "fleet", "tasks", "vehicles"],
  quality: ["production", "inventory"],
  safety: ["staff", "tasks"],
  drawings: ["projects", "documents"],
  resources: ["projects", "tasks"],
  jobs: ["customers", "staff", "warranty", "tracking", "commissions"],
  warranty: ["jobs", "customers"],
  campaigns: ["leads", "content", "analytics", "distribution", "publishing"],
  leads: ["campaigns", "customers", "analytics"],
  content: ["campaigns", "publishing", "creative"],
  publishing: ["content", "campaigns", "distribution"],
  creative: ["content", "campaigns"],
  distribution: ["campaigns", "publishing", "deliveries"],
  analytics: ["campaigns", "leads", "sales"],
  billing: ["invoices", "clients", "payments"],
  cases: ["clients", "hearings", "documents", "contracts", "appointments"],
  clients: ["cases", "contracts", "billing", "appointments", "documents"],
  hearings: ["cases", "deadlines"],
  deadlines: ["hearings", "cases"],
  timetracking: ["cases", "billing", "staff"],
  donations: ["members", "fundraising", "beneficiaries", "events"],
  fundraising: ["donations", "members", "events", "beneficiaries"],
  beneficiaries: ["donations", "fundraising"],
  volunteers: ["events", "donations", "members"],
  events: ["reservations", "members", "donations", "fundraising", "volunteers"],
  reviews: ["customers", "menu"],
  equipment: ["maintenance", "sessions", "inventory"],
  tournaments: ["members", "sessions"],
};

/* ------------------------------------------------------------------ */
/* Detection helpers                                                   */
/* ------------------------------------------------------------------ */

/** Word-boundary keyword scan of a normalized haystack. */
function detectSectors(
  paddedHay: string
): Array<{ sector: string; matched: string[] }> {
  const out: Array<{ sector: string; matched: string[] }> = [];
  for (const s of SECTOR_KEYWORDS) {
    const matched: string[] = [];
    for (const [raw, norm] of s.words) {
      if (norm && paddedHay.includes(` ${norm} `)) matched.push(raw);
    }
    if (matched.length > 0) out.push({ sector: s.id, matched });
  }
  return out;
}

const clamp100 = (n: number): number => (n < 0 ? 0 : n > 100 ? 100 : n);

/* ------------------------------------------------------------------ */
/* The engine                                                          */
/* ------------------------------------------------------------------ */

export function recommendModules(input: RecommendInput): RecommendResult {
  const system: SystemDef | undefined = SYSTEM_MAP[input.systemId];
  const role = input.role === "manager" ? "manager" : "owner";

  if (!system) {
    return {
      perModule: new Map<string, ModuleRecommendation>(),
      recommendedSet: [],
      signals: { sector: false, orgKeywords: [], countryVat: false, role, topPairs: [] },
    };
  }

  /* The effective toggleable surface — systemMods() appends the universal
     "shifts" + "expenses" toggles; the engine scores them sensibly rather
     than by their appended (last) position. */
  const effective = systemMods(system);
  if (effective.length === 0) {
    return {
      perModule: new Map<string, ModuleRecommendation>(),
      recommendedSet: [],
      signals: { sector: false, orgKeywords: [], countryVat: false, role, topPairs: [] },
    };
  }

  /* The curated prior source: the system's own override, else its category. */
  const curated = system.mods ?? CATEGORY_MAP[system.c]?.mods ?? [];
  const M = curated.length;
  const rank = new Map<string, number>();
  curated.forEach((id, i) => {
    if (!rank.has(id)) rank.set(id, i);
  });
  const effIndex = new Map<string, number>();
  effective.forEach((id, i) => effIndex.set(id, i));

  /* ---- stage A: curated prior (position decay 82 → 38) ----
     `base` carries the expert signal ONLY (curated prior + universal
     bases); stages C/D/E add tenant signal on top into `scores`. Keeping
     them apart lets the coupling stage amplify what the CATALOG blessed
     without keyword/VAT boosts unlocking the cascade for the deep tail. */
  const base = new Map<string, number>();
  const universalSource = new Set<string>();
  for (const id of effective) {
    const r = rank.get(id);
    base.set(id, r === undefined ? 0 : W.priorTop - W.priorSpan * (M <= 1 ? 0 : r / (M - 1)));
  }

  /* ---- stage B: universal bases (sector-aware) ---- */
  const cashHeavy = CASH_ANCHORS.some((a) => effective.includes(a));
  for (const id of effective) {
    let univ: number | null = null;
    if (id === "reports") univ = W.univReports;
    else if (id === "expenses") univ = EXPENSES_TRADE_SECTORS.has(system.c) ? W.univExpensesTrade : W.univExpenses;
    else if (id === "shifts") univ = cashHeavy ? W.univShiftsCash : W.univShifts;
    if (univ !== null && univ > (base.get(id) ?? 0)) {
      base.set(id, univ);
      universalSource.add(id);
    }
  }

  /* ---- stage C: org-name keyword signals ---- */
  const norm = normalizeText(input.orgName ?? "");
  const detected = norm ? detectSectors(` ${norm} `) : [];
  const kwBoost = new Map<string, number>();
  const kwReason = new Map<string, "sectorMatch" | "orgKeyword">();
  for (const d of detected.slice(0, 2)) {
    const sameSector = d.sector === system.c;
    const signature = SECTOR_SIGNATURE[d.sector] ?? [];
    for (const id of effective) {
      if (!signature.includes(id)) continue;
      kwBoost.set(id, Math.min(W.keywordCap, (kwBoost.get(id) ?? 0) + (sameSector ? W.keywordSameSector : W.keywordCrossSector)));
      if (sameSector || kwReason.get(id) !== "sectorMatch") kwReason.set(id, sameSector ? "sectorMatch" : "orgKeyword");
    }
  }

  /* ---- stage D: country/currency intelligence ---- */
  const country = (input.country ?? "").trim().toUpperCase();
  const currency = (input.currency ?? "").trim().toUpperCase();
  const countryVat = VAT_COUNTRIES.has(country) || VAT_CURRENCIES.has(currency);
  const arabicHint = ARAB_COUNTRIES.has(country);

  /* ---- stage E: role fit ---- */
  const roleFit = role === "manager";

  /* ---- apply C/D/E boosts on top of the expert base ---- */
  const scores = new Map<string, number>();
  const vatApplied = new Set<string>();
  const roleApplied = new Set<string>();
  for (const id of effective) {
    let s = base.get(id) ?? 0;
    s += kwBoost.get(id) ?? 0;
    if (countryVat && (id === "invoices" || id === "taxes")) {
      s += W.vatCore;
      vatApplied.add(id);
    }
    if (countryVat && id === "reports") {
      s += W.vatReports;
      vatApplied.add(id);
    }
    if (arabicHint && id === "reports") s += W.langReports;
    if (roleFit && ROLE_FIT_MODULES.has(id)) {
      s += W.roleFit;
      roleApplied.add(id);
    }
    scores.set(id, s);
  }

  /* ---- stage F: operational coupling, computed on the EXPERT base (stage
          A+B). A partner counts as a strong anchor at ≥ 64, each earns +4
          (cap +12); the boost only REINFORCES modules whose expert base is
          already ≥ 48 — strong operational pairs rise together, but signals
          alone never resurrect the deep curated tail (the experts placed
          those late on purpose). ---- */
  const coupling = new Map<string, { boost: number; anchor: string }>();
  for (const id of effective) {
    if ((base.get(id) ?? 0) < W.couplingFloor) continue;
    const partners = COUPLING[id] ?? [];
    let anchors = 0;
    let best = "";
    let bestScore = -1;
    for (const p of partners) {
      const pi = effIndex.get(p);
      if (pi === undefined) continue; // partner not offered by this system
      const ps = base.get(p) ?? 0;
      if (ps >= W.couplingAnchorMin) {
        anchors++;
        if (ps > bestScore) {
          bestScore = ps;
          best = p;
        }
      }
    }
    if (anchors > 0) coupling.set(id, { boost: Math.min(W.couplingMax, anchors * W.couplingStep), anchor: best });
  }

  /* ---- final scores (rounded BEFORE tiering so the chip % always
          agrees with the tier it renders) ---- */
  const final = new Map<string, number>();
  for (const id of effective) {
    final.set(id, Math.round(clamp100((scores.get(id) ?? 0) + (coupling.get(id)?.boost ?? 0))));
  }

  /* ---- tiers + reasons + recommendedSet ---- */
  const perModule = new Map<string, ModuleRecommendation>();
  const recommended: string[] = [];
  for (const id of effective) {
    const score = final.get(id) ?? 0;
    const r = rank.get(id);
    const tier: ModuleRecommendation["tier"] =
      score >= W.essentialScore && r !== undefined && r < W.essentialRank
        ? "essential"
        : score >= W.recommendedScore
          ? "recommended"
          : "optional";

    const reasons: RecommendReasonKey[] = [];
    if (r !== undefined && (r < W.essentialRank || tier !== "optional")) reasons.push("core");
    const kw = kwReason.get(id);
    if (kw && (kwBoost.get(id) ?? 0) > 0 && tier !== "optional") reasons.push(kw);
    if (universalSource.has(id) && tier !== "optional") reasons.push("universal");
    const c = coupling.get(id);
    if (c) reasons.push(`pairsWith:${c.anchor}` as RecommendReasonKey);
    if (vatApplied.has(id)) reasons.push("vatCountry");
    if (roleApplied.has(id)) reasons.push("roleFit");

    perModule.set(id, { score, tier, reasons: reasons.slice(0, 3) });
    if (tier !== "optional") recommended.push(id);
  }

  /* Best-first order for the quick-set: score desc → curated rank asc →
     effective position asc → id (full determinism, stable across runs). */
  const ordered = recommended.slice().sort((a, b) => {
    const sa = final.get(a) ?? 0;
    const sb = final.get(b) ?? 0;
    if (sa !== sb) return sb - sa;
    const ra = rank.get(a) ?? Number.MAX_SAFE_INTEGER;
    const rb = rank.get(b) ?? Number.MAX_SAFE_INTEGER;
    if (ra !== rb) return ra - rb;
    const ia = effIndex.get(a) ?? 0;
    const ib = effIndex.get(b) ?? 0;
    if (ia !== ib) return ia - ib;
    return a < b ? -1 : 1;
  });

  /* The strongest coupling pairs actually behind the recommendation
     (mirrored pairs deduped — pos↔inventory counts once). */
  const topPairs: Array<{ module: string; with: string }> = [];
  const seenPairs = new Set<string>();
  for (const id of ordered) {
    const c = coupling.get(id);
    if (!c) continue;
    const key = id < c.anchor ? `${id}|${c.anchor}` : `${c.anchor}|${id}`;
    if (seenPairs.has(key)) continue;
    seenPairs.add(key);
    topPairs.push({ module: id, with: c.anchor });
    if (topPairs.length >= 2) break;
  }

  const orgKeywords: string[] = [];
  for (const d of detected) {
    for (const kw of d.matched) {
      if (orgKeywords.length >= 4) break;
      if (!orgKeywords.includes(kw)) orgKeywords.push(kw);
    }
  }

  return {
    perModule,
    recommendedSet: ordered,
    signals: {
      sector: detected.some((d) => d.sector === system.c),
      orgKeywords,
      countryVat,
      role,
      topPairs,
    },
  };
}
