import type { Lang } from "@/lib/types";
import { intlLocale } from "@/lib/locales";

/**
 * Shared client-side number/money/country formatting.
 *
 * Single source of truth for locale-aware formatting on the CLIENT (the
 * server twin with integer-minor-unit money lives in
 * src/lib/server/money.ts). Previously the same helpers were re-implemented
 * in six+ modules — behavioral drift between storefront surfaces is the
 * direct consequence; this module ends that. Pure functions, no React, no
 * client-only imports — safe for any component tree (including the public
 * website, which must NOT depend on the store's cart/account graph).
 */

/** locale-aware numerals (Arabic-Indic for AR, native digits otherwise) */
export function nf(lang: Lang, n: number): string {
  try {
    return new Intl.NumberFormat(intlLocale(lang)).format(n);
  } catch {
    return String(n);
  }
}

/** localized country name (fail-soft) */
export function countryName(lang: Lang, code: string): string | null {
  if (!code) return null;
  try {
    return new Intl.DisplayNames([intlLocale(lang)], { type: "region" }).of(code) ?? null;
  } catch {
    return null;
  }
}

/** storefront money formatting — locale-aware + the store's own currency. */
export function fmtPrice(lang: Lang, amount: number, currency: string): string {
  try {
    return new Intl.NumberFormat(intlLocale(lang), {
      style: "currency",
      currency: /^[A-Za-z]{3}$/.test(currency) ? currency : "SAR",
      maximumFractionDigits: 2,
    }).format(amount);
  } catch {
    return `${nf(lang, amount)} ${currency || "SAR"}`;
  }
}

/* ------------------------------------------------------------------ */
/* ROUND 166 — plan/addon money display (integer minor units → ÷100)   */
/* ------------------------------------------------------------------ */

/**
 * Format a PLAN/ADDON price carried in integer MINOR units (the money.ts
 * contract — Package.priceMonthly, PlanOrder/AddonOrder.amount, the add-on
 * catalog ladder) for display: "9.99" for 999, "95.90" for 9590.
 *
 * Conventions (mirroring the landing price prints the platform already
 * ships — `toLocaleString("en-US")`):
 *  - WESTERN digits in EVERY locale, including Arabic (prices never render
 *    in Arabic-Indic numerals; counts/percentages keep fmtNum's policy);
 *  - always 2 decimal places (minimumFractionDigits + maximumFractionDigits),
 *    so the $9.99 anchor reads exactly "9.99";
 *  - the currency LABEL rides along separately from the row's own currency
 *    field (the caller composes `fmtPlanPrice(minor) + " USD"`), matching
 *    every existing price cell's "figure + code suffix" shape.
 *
 * Pure + client-safe: the ÷100 factor is inlined (lib/server/money.ts stays
 * server-only by the eslint boundary), exactly like wallet-widgets.tsx's
 * local toDisplayUnits.
 */
export function fmtPlanPrice(minor: number): string {
  const major = Math.round(minor) / 100;
  try {
    return new Intl.NumberFormat("en-US", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(Number.isFinite(major) ? major : 0);
  } catch {
    return (Number.isFinite(major) ? major : 0).toFixed(2);
  }
}
