"use client";

import { useEffect, useState } from "react";

/**
 * ROUND 170 (performance) — a dependency-free prefers-reduced-motion hook.
 *
 * framer-motion exports `useReducedMotion`, but importing ANY symbol from
 * framer-motion pulls its engine chunk into the importing graph. The PUBLIC
 * landing previously paid ~56KB (gzip) of framer-motion just for this tiny
 * hook + the section Reveal + the back-to-top entrance. This local twin —
 * the same matchMedia contract, SSR-safe (null → false until mounted) —
 * lets those landing surfaces drop the framer dependency entirely; the
 * library itself stays on the lazy product chunks that actually animate.
 *
 * Returns `true` once the OS "reduce motion" preference is observed.
 * SSR / first render: `false` (matches the pre-hydration HTML).
 */
export function useReducedMotion(): boolean {
  const [reduced, setReduced] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const apply = () => setReduced(mq.matches);
    apply();
    if (mq.addEventListener) {
      mq.addEventListener("change", apply);
      return () => mq.removeEventListener("change", apply);
    }
    /* Safari < 14 / old engines */
    mq.addListener(apply);
    return () => mq.removeListener(apply);
  }, []);

  return reduced;
}
