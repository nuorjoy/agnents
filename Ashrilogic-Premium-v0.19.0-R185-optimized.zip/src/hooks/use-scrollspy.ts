"use client";

/**
 * Ashrilogic — scrollspy hook.
 *
 * Tracks which section id is currently active in the viewport via
 * IntersectionObserver. Returns the active id (or null). SSR-safe.
 */
import { useEffect, useState } from "react";

export function useScrollSpy(ids: string[], offset = 0): string | null {
  const [active, setActive] = useState<string | null>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (ids.length === 0) return;

    const visible = new Map<string, number>();

    const io = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          visible.set(entry.target.id, entry.intersectionRatio);
        }
        let best: string | null = null;
        let bestRatio = 0;
        for (const [id, ratio] of visible) {
          if (ratio > bestRatio) {
            bestRatio = ratio;
            best = id;
          }
        }
        if (best && best !== active) setActive(best);
      },
      {
        rootMargin: `-${offset}px 0px -55% 0px`,
        threshold: [0, 0.25, 0.5, 0.75, 1],
      }
    );

    for (const id of ids) {
      const el = document.getElementById(id);
      if (el) io.observe(el);
    }

    return () => io.disconnect();
  }, [ids.join(","), offset, active]);

  return active;
}
