"use client";

import { useEffect } from "react";

/**
 * ROUND 69 — strict workspace favicon isolation (rework of ROUND 67).
 *
 * While a workspace surface is open (the tenant dashboard, the public
 * website, the storefront) the browser tab shows the workspace's identity
 * rendered as a PREMIUM CIRCULAR favicon — server-composed by
 * GET /api/instances/[id]/favicon.png (logo badge with the platform's
 * signature gradient ring, or the circular brand mark when no logo is
 * stored yet). Chrome resolves multiple <link rel=icon> entries by picking
 * the LAST one, so appending here reliably overrides the platform's static
 * icons.
 *
 * ISOLATION LAW (the ROUND 67 bug this fixes): removing the injected link
 * on unmount does NOT reliably restore the platform icon — Chromium keeps
 * painting the last-seen favicon, so a tenant's brand mark leaked onto the
 * landing page (ashrilogic), the system-select screen and every other
 * workspace opened afterwards in the same tab. The cleanup now actively
 * RE-ASSERTS the platform mark instead of just removing ours:
 *
 *   unmount / id change → swap href to /favicon.svg (+ cache-buster)
 *
 * so leaving ANY workspace snaps the tab back to the Ashrilogic icon in
 * the same frame. The platform link is tagged with a data attribute so
 * successive workspace sessions reuse one slot instead of stacking links.
 *
 * The href carries a `rev` (the current logo reference) purely as a
 * cache-buster: uploading a new logo changes the managed-ref hash, which
 * changes the URL, which forces every open tab to refetch the fresh
 * circular composition.
 */

/** marker attribute for the tab-icon slot this hook owns */
const SLOT_ATTR = "data-ashrilogic-favicon";

/** Re-assert the platform's own icon as the tab favicon. */
function restorePlatformIcon(): HTMLLinkElement {
  const existing = document.head.querySelector<HTMLLinkElement>(`link[rel="icon"][${SLOT_ATTR}]`);
  const link = existing ?? document.createElement("link");
  link.rel = "icon";
  link.type = "image/svg+xml";
  link.setAttribute(SLOT_ATTR, "platform");
  /* cache-buster: a fresh URL every restore forces a real refetch instead
     of the browser silently reusing its in-memory last-seen PNG */
  link.href = `/favicon.svg?r=${Date.now()}`;
  if (!existing) document.head.appendChild(link);
  return link;
}

export function useBrandFavicon(instanceId: string | null | undefined, rev?: string): void {
  useEffect(() => {
    if (!instanceId) return;
    /* reuse (or create) the single managed slot — never stack links */
    const existing = document.head.querySelector<HTMLLinkElement>(`link[rel="icon"][${SLOT_ATTR}]`);
    const link = existing ?? document.createElement("link");
    link.rel = "icon";
    link.type = "image/png";
    link.setAttribute(SLOT_ATTR, instanceId);
    link.href =
      `/api/instances/${encodeURIComponent(instanceId)}/favicon.png` +
      (rev ? `?rev=${encodeURIComponent(rev)}` : "");
    if (!existing) document.head.appendChild(link);
    return () => {
      /* STRICT ISOLATION: leaving the workspace (or switching ids) must
         visibly return the tab to the platform mark — never leave the
         tenant's icon painted on platform surfaces. */
      restorePlatformIcon();
    };
  }, [instanceId, rev]);
}
