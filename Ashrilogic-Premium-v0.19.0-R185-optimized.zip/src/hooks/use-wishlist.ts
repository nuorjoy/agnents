"use client";

/**
 * Ashrilogic — ROUND 58 (storefront wishlist), refactored ROUND 59.
 *
 * A per-instance guest wishlist persisted in localStorage (NO server
 * surface: no PII, no account — the key is scoped to the workspace so two
 * stores never share a list). Stores a MINIMAL product snapshot at toggle
 * time so the wishlist sheet can render offline of the current catalog
 * query; whenever the live catalog is loaded, callers merge fresh
 * price/stock state by recordId (the snapshot is only a fallback).
 *
 * ROUND 59 — the hook now rides on `useSyncExternalStore` (same proven
 * pattern as src/lib/admin-auth.ts): localStorage IS the store, React just
 * subscribes to it. This removes the load-in-effect setState (cascading
 * renders, hydration gymnastics) entirely:
 *  - SSR-safe by construction: the server snapshot is the stable empty
 *    list, React itself swaps in the client snapshot after hydration
 *    (documented uSES behavior — no markup mismatch);
 *  - cross-tab: the native `storage` event notifies other tabs;
 *  - same-tab: mutations dispatch a private `ashrilogic:wishlist` event so
 *    every mounted hook (and any future consumer) re-reads instantly;
 *  - referential stability: getSnapshot caches the parsed array keyed by
 *    (instanceId, raw) — unchanged data returns the SAME reference, so
 *    uSES never loops;
 *  - bounded: capped at 100 items (oldest evicted first), defensive JSON
 *    parsing — corrupt storage degrades to an empty list, never a crash;
 *  - the reduced-motion safe "pop" feedback lives in the card component.
 */
import { useCallback, useMemo, useSyncExternalStore } from "react";

export interface WishlistItem {
  /** ModuleRecord id — the stable product identity */
  recordId: string;
  name: string;
  /** effective price at save time (integer minor units) */
  price: number;
  /** regular price when a sale was active (minor units, null = no sale) */
  salePrice: number | null;
  currency: string;
  category: string;
  imageRef: string | null;
  /** ISO timestamp — drives the "newest first" ordering */
  addedAt: string;
}

const CAP = 100;
const KEY_PREFIX = "ashrilogic:wishlist:";
/** private same-tab notification channel (storage events never fire in
 *  the tab that performed the write) */
const WISHLIST_EVENT = "ashrilogic:wishlist";

/** stable reference for the server/hydration snapshot — NEVER mutate */
const EMPTY: WishlistItem[] = [];

function storageKey(instanceId: string): string {
  return `${KEY_PREFIX}${instanceId}`;
}

/** Defensive parse of the persisted array (bounds + shape checked). */
function parseItems(raw: string | null): WishlistItem[] {
  if (!raw) return EMPTY;
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return EMPTY;
    const items: WishlistItem[] = [];
    for (const row of parsed) {
      if (!row || typeof row !== "object" || Array.isArray(row)) continue;
      const it = row as Partial<WishlistItem>;
      if (typeof it.recordId !== "string" || typeof it.name !== "string") continue;
      if (it.recordId.length === 0 || it.recordId.length > 64 || it.name.length > 160) continue;
      items.push({
        recordId: it.recordId,
        name: it.name,
        price: typeof it.price === "number" && Number.isFinite(it.price) ? it.price : 0,
        salePrice: typeof it.salePrice === "number" && Number.isFinite(it.salePrice) ? it.salePrice : null,
        currency: typeof it.currency === "string" ? it.currency.slice(0, 8) : "SAR",
        category: typeof it.category === "string" ? it.category.slice(0, 120) : "",
        imageRef: typeof it.imageRef === "string" ? it.imageRef : null,
        addedAt: typeof it.addedAt === "string" ? it.addedAt : new Date().toISOString(),
      });
      if (items.length >= CAP) break;
    }
    return items;
  } catch {
    return EMPTY;
  }
}

/* --- snapshot cache: uSES requires the SAME reference for unchanged data.
 * The cache is module-level and keyed by (instanceId, raw) so several hooks
 * (or several instances) can never poison each other's snapshot. */
let cacheKey = "";
let cacheItems: WishlistItem[] = EMPTY;

function readSnapshot(instanceId: string): WishlistItem[] {
  const raw = window.localStorage.getItem(storageKey(instanceId));
  const key = `${instanceId}\u0000${raw ?? ""}`;
  if (key !== cacheKey) {
    cacheKey = key;
    cacheItems = parseItems(raw);
  }
  return cacheItems;
}

/** write-through mutation: localStorage first (source of truth), then the
 *  same-tab event so every subscriber re-reads immediately. */
function writeSnapshot(instanceId: string, next: WishlistItem[]): void {
  try {
    window.localStorage.setItem(storageKey(instanceId), JSON.stringify(next));
  } catch {
    /* quota exceeded / private mode — keep the in-memory cache consistent
     * with what the caller intended, so the UI stays usable this session */
    cacheItems = next;
    cacheKey = `${instanceId}\u0000__volatile__`;
    window.dispatchEvent(new Event(WISHLIST_EVENT));
    return;
  }
  window.dispatchEvent(new Event(WISHLIST_EVENT));
}

export function useWishlist(instanceId: string): {
  items: WishlistItem[];
  count: number;
  has: (recordId: string) => boolean;
  toggle: (item: WishlistItem) => boolean;
  remove: (recordId: string) => void;
  clear: () => void;
} {
  /* subscribe: cross-tab `storage` + same-tab private event, scoped to the
   * instance's key. uSES re-subscribes whenever the callback identity
   * changes (instance switch) — exactly the lifecycle we want. */
  const subscribe = useCallback(
    (onStoreChange: () => void) => {
      const onStorage = (e: StorageEvent) => {
        if (e.key === storageKey(instanceId)) onStoreChange();
      };
      window.addEventListener("storage", onStorage);
      window.addEventListener(WISHLIST_EVENT, onStoreChange);
      return () => {
        window.removeEventListener("storage", onStorage);
        window.removeEventListener(WISHLIST_EVENT, onStoreChange);
      };
    },
    [instanceId]
  );

  const getSnapshot = useCallback(() => readSnapshot(instanceId), [instanceId]);
  const getServerSnapshot = useCallback(() => EMPTY, []);

  const items = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);

  const has = useCallback((recordId: string) => items.some((i) => i.recordId === recordId), [items]);

  /** Toggle by snapshot — returns TRUE when the item ended up SAVED. */
  const toggle = useCallback(
    (item: WishlistItem) => {
      const current = readSnapshot(instanceId);
      const exists = current.some((i) => i.recordId === item.recordId);
      if (exists) {
        writeSnapshot(instanceId, current.filter((i) => i.recordId !== item.recordId));
        return false;
      }
      /* newest first; oldest evicted beyond the cap */
      writeSnapshot(instanceId, [item, ...current.filter((i) => i.recordId !== item.recordId)].slice(0, CAP));
      return true;
    },
    [instanceId]
  );

  const remove = useCallback(
    (recordId: string) => {
      const current = readSnapshot(instanceId);
      writeSnapshot(instanceId, current.filter((i) => i.recordId !== recordId));
    },
    [instanceId]
  );

  const clear = useCallback(() => writeSnapshot(instanceId, []), [instanceId]);

  const count = useMemo(() => items.length, [items]);

  return { items, count, has, toggle, remove, clear };
}
