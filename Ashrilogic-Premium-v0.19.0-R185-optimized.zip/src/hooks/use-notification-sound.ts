"use client";

/**
 * Ashrilogic — ROUND 156 — premium notification sound hook.
 *
 * Synthesizes a four-note ascending C-major arpeggio (C5 → E5 → G5 → C6,
 * TRIANGLE wave, ~0.06 gain per note, 100ms each with a 50ms gap) through
 * a warm low-pass filter (2 kHz cutoff) and a one-tap feedback delay
 * (200ms, 30% wet, single repeat) via the Web Audio API — ZERO audio
 * files, zero network overhead, instant playback the moment a notification
 * arrives.
 *
 * Premium = the calm of the prior two-note sine chime, but with the warmth
 * of a major chord arpeggio (the same vocabulary Apple/Stripe notifications
 * use). Lower per-note gain (0.06 vs 0.08) + the low-pass filter tame the
 * triangle's upper harmonics so the chime stays non-intrusive on every
 * page where it fires (admin + tenant dashboard + store). The single
 * feedback repeat adds a soft "tail" without dragging the chime past
 * ~700ms total — short enough to never overlap a second chime.
 *
 * Browser autoplay policy: AudioContext is created lazily on the FIRST user
 * gesture (click / keydown / touchstart) and resumed whenever Chrome's
 * autoplay-gate suspends it. The chime therefore NEVER fires before the
 * visitor has interacted with the page (per spec) — and after the first
 * gesture it fires for every subsequent rise in the unread notification
 * count, on EVERY page where the hook is mounted (mounted once at the root
 * providers, so admin + tenant dashboard + store all benefit).
 *
 * Trigger source: the React Query cache. The hook subscribes to query
 * updates for the two notification feeds in this product:
 *
 *   1. Admin feed — `["admin-notif-feed"]` (AdminNotifications bell). The
 *      unread count = items with `createdAt > lastRead` (the bell's own
 *      localStorage mark — `ashrilogic-admin-notif-read`).
 *
 *   2. Tenant feed — `["activities-feed", <instanceId>, 20]` (the tenant
 *      dashboard topbar bell). The unread count = the first page's
 *      activities newer than the per-instance lastRead mark
 *      (`ashrilogic-notif-read-<instanceId>`).
 *
 * The chime fires once per increase (a re-fetch returning the SAME unread
 * count does NOT replay). A decrease (mark-all-read) does NOT fire.
 *
 * Toggle: `localStorage["ashrilogic-notif-sound"]` — `"1"` (default, on) /
 * `"0"` (off). The player reads it live so an operator can mute mid-session
 * from the devtools console without a reload.
 */
import { useCallback, useEffect, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";

/** The localStorage flag key — defaults ON (mute by setting "0"). */
export const NOTIF_SOUND_FLAG_KEY = "ashrilogic-notif-sound";

/**
 * ROUND 156 — the four notes of the premium chime: a C-major arpeggio
 * ascending one octave (C5 → E5 → G5 → C6). 100ms per note, 50ms gap
 * (start offsets 0 / 0.15 / 0.30 / 0.45 s). Triangle waveform (warmer
 * than sine, richer than square) runs through the LOW-PASS filter below
 * so the upper harmonics never feel shrill.
 */
const CHIME_NOTES: ReadonlyArray<{ freq: number; start: number; dur: number }> = [
  { freq: 523.25, start: 0, dur: 0.1 }, /* C5 */
  { freq: 659.25, start: 0.15, dur: 0.1 }, /* E5 */
  { freq: 783.99, start: 0.3, dur: 0.1 }, /* G5 */
  { freq: 1046.5, start: 0.45, dur: 0.14 }, /* C6 (the slight tail) */
] as const;

const CHIME_GAIN = 0.06;
const CHIME_ATTACK = 0.012;
/** ROUND 156 — the warm low-pass ceiling: tames triangle's upper harmonics. */
const CHIME_FILTER_FREQ = 2000;
/** ROUND 156 — the one-tap feedback delay (200ms, single repeat at 30%). */
const CHIME_DELAY_MS = 0.2;
const CHIME_DELAY_FEEDBACK = 0.3;
const CHIME_DELAY_WET = 0.3;

/** Read the live localStorage toggle (default ON — `null`/unset = on). */
function soundEnabled(): boolean {
  if (typeof window === "undefined") return true;
  try {
    const v = window.localStorage.getItem(NOTIF_SOUND_FLAG_KEY);
    return v === null ? true : v !== "0";
  } catch {
    return true;
  }
}

/** Compute the admin bell's current unread count from a cached payload. */
function adminUnread(payload: unknown, lastRead: number): number {
  if (!payload || typeof payload !== "object") return 0;
  const p = payload as { items?: Array<{ createdAt?: string }> };
  const items = Array.isArray(p.items) ? p.items : [];
  if (items.length === 0) return 0;
  return items.filter((i) => {
    const t = i?.createdAt ? Date.parse(i.createdAt) : NaN;
    return Number.isFinite(t) && t > lastRead;
  }).length;
}

/** Compute the tenant bell's current unread count from a cached infinite
 *  query payload (pages[0].activities newer than the per-instance mark). */
function tenantUnread(payload: unknown, lastRead: number): number {
  if (!payload || typeof payload !== "object") return 0;
  const p = payload as { pages?: Array<{ activities?: Array<{ createdAt?: string }> }> };
  const pages = Array.isArray(p.pages) ? p.pages : [];
  if (pages.length === 0) return 0;
  const acts = pages[0]?.activities;
  if (!Array.isArray(acts) || acts.length === 0) return 0;
  return acts.filter((a) => {
    const t = a?.createdAt ? Date.parse(a.createdAt) : NaN;
    return Number.isFinite(t) && t > lastRead;
  }).length;
}

/** Read the admin bell's lastRead stamp (0 when unset). */
function readAdminMark(): number {
  if (typeof window === "undefined") return 0;
  const raw = window.localStorage.getItem("ashrilogic-admin-notif-read");
  if (!raw) return 0;
  const n = Number(raw);
  return Number.isFinite(n) && n > 0 ? n : 0;
}

/** Read a per-instance tenant bell's lastRead stamp (0 when unset). */
function readTenantMark(instanceId: string): number {
  if (typeof window === "undefined") return 0;
  const raw = window.localStorage.getItem(`ashrilogic-notif-read-${instanceId}`);
  if (!raw) return 0;
  const n = Number(raw);
  return Number.isFinite(n) && n > 0 ? n : 0;
}

export interface UseNotificationSoundApi {
  /** manually trigger the chime (e.g. for a "test sound" button) */
  playChime: () => void;
}

/**
 * Mount-once notification sound player. The hook returns a `playChime`
 * callback for manual triggering; it ALSO subscribes to the React Query
 * cache and fires the chime automatically when a notification feed's unread
 * count rises. Designed to be mounted ONCE at the root (inside AppProviders).
 */
export function useNotificationSound(enabled: boolean = true): UseNotificationSoundApi {
  const audioCtxRef = useRef<AudioContext | null>(null);
  const adminPrevRef = useRef<number>(0);
  /* the tenant feed is keyed by instanceId; track the latest one seen so a
     cross-workspace switch starts from the new workspace's count, not the
     previous workspace's (which would either false-fire or false-mute). */
  const tenantPrevRef = useRef<Map<string, number>>(new Map());

  /* lazy AudioContext creation + autoplay-gate resume on first gesture */
  useEffect(() => {
    if (!enabled) return;

    const ensureCtx = () => {
      if (audioCtxRef.current?.state === "suspended") {
        void audioCtxRef.current.resume().catch(() => {});
        return;
      }
      if (audioCtxRef.current) return;
      try {
        const Ctor =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (!Ctor) return;
        audioCtxRef.current = new Ctor();
      } catch {
        /* AudioContext not supported — silently no-op */
      }
    };

    const opts: AddEventListenerOptions = { once: false, passive: true };
    document.addEventListener("click", ensureCtx, opts);
    document.addEventListener("keydown", ensureCtx, opts);
    document.addEventListener("touchstart", ensureCtx, opts);

    return () => {
      document.removeEventListener("click", ensureCtx);
      document.removeEventListener("keydown", ensureCtx);
      document.removeEventListener("touchstart", ensureCtx);
    };
  }, [enabled]);

  const playChime = useCallback(() => {
    const ctx = audioCtxRef.current;
    if (!ctx) return;
    if (ctx.state === "suspended") {
      /* a suspended context means autoplay hasn't been lifted yet — try to
         resume (the first user gesture did its job or this was called from
         inside an event handler); if it fails, drop the chime silently. */
      void ctx.resume().catch(() => {});
      if (ctx.state === "suspended") return;
    }
    const now = ctx.currentTime;

    /* ROUND 156 — the PREMIUM chain: a SHARED low-pass filter (warmth) + a
     * shared feedback delay (the soft tail) sit between every note's gain
     * node and the destination. Sharing the filter + delay across all four
     * notes keeps the chime cohesive (one cabinet, not four) and avoids
     * per-note allocation; the filter's own gain stays at 1.0 so the
     * per-note envelope is the only amplitude control. */
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = CHIME_FILTER_FREQ;
    filter.Q.value = 0.7; /* gentle — no resonance peak at the cutoff */

    const delay = ctx.createDelay(1.0);
    delay.delayTime.value = CHIME_DELAY_MS;
    const delayFeedback = ctx.createGain();
    delayFeedback.gain.value = CHIME_DELAY_FEEDBACK;
    const delayWet = ctx.createGain();
    delayWet.gain.value = CHIME_DELAY_WET;
    const dryGain = ctx.createGain();
    dryGain.gain.value = 1.0;

    /* dry path: filter → dryGain → destination
     * wet path: filter → delay → delayWet → destination, with the delay
     *   feeding back into itself through delayFeedback (one audible
     *   repeat — the spec's «single repeat at 30% volume»). */
    filter.connect(dryGain);
    dryGain.connect(ctx.destination);
    filter.connect(delay);
    delay.connect(delayFeedback);
    delayFeedback.connect(delay);
    delay.connect(delayWet);
    delayWet.connect(ctx.destination);

    for (const { freq, start, dur } of CHIME_NOTES) {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "triangle"; /* warmer than sine, more "premium" */
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0, now + start);
      gain.gain.linearRampToValueAtTime(CHIME_GAIN, now + start + CHIME_ATTACK);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + start + dur);
      osc.connect(gain);
      gain.connect(filter);
      osc.start(now + start);
      osc.stop(now + start + dur + 0.05);
    }

    /* free the shared nodes after the chime + its delay tail have fully
     * decayed (~1.2s — well past the delay's last repeat). */
    /* fade the shared wet + dry gains to silence just past the delay
     * tail so the nodes can be GC'd cleanly. The BiquadFilter + DelayNode
     * themselves are not stoppable (only Oscillators/SourceBuffers are) —
     * they auto-release once their inputs disconnect (the oscillator
     * stop() calls below already did that). */
    const cleanupAt = now + 1.2;
    try {
      dryGain.gain.setValueAtTime(1.0, cleanupAt);
      delayWet.gain.setValueAtTime(CHIME_DELAY_WET, cleanupAt);
      dryGain.gain.linearRampToValueAtTime(0, cleanupAt + 0.05);
      delayWet.gain.linearRampToValueAtTime(0, cleanupAt + 0.05);
    } catch {
      /* older Safari guards */
    }
  }, []);

  /* subscribe to the React Query cache — fire the chime whenever a
     notification feed's unread count rises. */
  const queryClient = useQueryClient();
  useEffect(() => {
    if (!enabled) return;
    const cache = queryClient.getQueryCache();

    const unsubscribe = cache.subscribe((event) => {
      /* only act on SUCCESS fetches (not on loading/error states) — a
         background refetch that returns the SAME count must not replay */
      if (event.type !== "updated") return;
      const action = event.action as unknown as { type?: string };
      if (action?.type !== "success") return;

      const query = event.query;
      const key = query.queryKey;
      if (!Array.isArray(key) || key.length === 0) return;
      const data = query.state.data;
      if (!soundEnabled()) return;

      /* admin feed */
      if (key[0] === "admin-notif-feed") {
        const lastRead = readAdminMark();
        const count = adminUnread(data, lastRead);
        const prev = adminPrevRef.current;
        if (count > prev && prev > 0) {
          /* prev === 0 means the player just mounted — do NOT chime on the
             very first feed read (the admin opening the panel should not be
             greeted by a chime for items already waiting for them) */
          playChime();
        }
        adminPrevRef.current = count;
        return;
      }

      /* tenant feed — key shape: ["activities-feed", instanceId, 20] */
      if (key[0] === "activities-feed" && typeof key[1] === "string") {
        const instanceId = key[1];
        const lastRead = readTenantMark(instanceId);
        const count = tenantUnread(data, lastRead);
        const map = tenantPrevRef.current;
        const prev = map.get(instanceId) ?? 0;
        if (count > prev && prev > 0) {
          playChime();
        }
        map.set(instanceId, count);
        return;
      }
    });

    return () => {
      unsubscribe();
    };
  }, [enabled, queryClient, playChime]);

  return { playChime };
}

export default useNotificationSound;
