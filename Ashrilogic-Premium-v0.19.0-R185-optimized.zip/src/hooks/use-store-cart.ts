"use client";

/**
 * Ashrilogic — ROUND 147 (storefront cart persistence).
 *
 * The e-store cart was TRANSIENT component state since round 55 (lost on
 * every reload). This hook promotes it to a per-instance localStorage cart
 * with the EXACT architecture of src/hooks/use-wishlist.ts (round 59):
 * `useSyncExternalStore` over localStorage — the storage IS the store,
 * React just subscribes:
 *  - SSR-safe by construction: the server snapshot is the stable empty
 *    list; React itself swaps in the client snapshot after hydration
 *    (documented uSES behavior — no markup mismatch);
 *  - cross-tab: the native `storage` event notifies other tabs;
 *  - same-tab: mutations dispatch a private `ashrilogic:storecart` event so
 *    every mounted hook re-reads instantly;
 *  - referential stability: getSnapshot caches the parsed array keyed by
 *    (instanceId, raw) — unchanged data returns the SAME reference, so
 *    uSES never loops;
 *  - bounded: capped at 60 lines (oldest evicted first), defensive JSON
 *    parsing — corrupt storage degrades to an empty cart, never a crash.
 *
 * LINE IDENTITY (round 141 variants): a cart line is keyed by
 * (recordId + variant label) — the same product under two different
 * variants travels as two lines, each sending its own {recordId, qty,
 * variant} at placement (the orders API accepts the optional variant).
 * The stored price/max/imageRef are SNAPSHOTS at add time (display units);
 * the server re-derives the charged price and re-verifies stock at
 * placement, exactly as it always has.
 *
 * The item shape is the shared StoreCartItem (store-shared.tsx) — a
 * type-only import, so this hook adds zero runtime coupling to the
 * component module.
 */
import { useCallback, useMemo, useSyncExternalStore } from "react";
import type { StoreCartItem } from "@/components/site/store-shared";

const CAP = 60;
const KEY_PREFIX = "ashrilogic:storecart:";
/** private same-tab notification channel (storage events never fire in
 * the tab that performed the write) */
const STORECART_EVENT = "ashrilogic:storecart";

/** stable reference for the server/hydration snapshot — NEVER mutate */
const EMPTY: StoreCartItem[] = [];

function storageKey(instanceId: string): string {
  return `${KEY_PREFIX}${instanceId}`;
}

/** the line identity — recordId + variant (variant-less lines match on "") */
function lineKey(item: Pick<StoreCartItem, "recordId" | "variant">): string {
  return `${item.recordId}\u0000${item.variant ?? ""}`;
}

/** Defensive parse of the persisted array (bounds + shape checked). */
function parseItems(raw: string | null): StoreCartItem[] {
  if (!raw) return EMPTY;
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return EMPTY;
    const items: StoreCartItem[] = [];
    for (const row of parsed) {
      if (!row || typeof row !== "object" || Array.isArray(row)) continue;
      const it = row as Partial<StoreCartItem>;
      if (typeof it.recordId !== "string" || typeof it.name !== "string") continue;
      if (it.recordId.length === 0 || it.recordId.length > 64 || it.name.length > 160) continue;
      const qty = typeof it.qty === "number" && Number.isInteger(it.qty) ? it.qty : 1;
      const max = typeof it.max === "number" && Number.isInteger(it.max) ? it.max : 1;
      items.push({
        recordId: it.recordId,
        name: it.name,
        price: typeof it.price === "number" && Number.isFinite(it.price) && it.price >= 0 ? it.price : 0,
        qty: Math.min(99, Math.max(1, qty)),
        max: Math.min(99, Math.max(1, max)),
        imageRef: typeof it.imageRef === "string" ? it.imageRef : null,
        /* round 141 — the chosen variant label (undefined = single-SKU line) */
        variant: typeof it.variant === "string" && it.variant.length > 0 && it.variant.length <= 80 ? it.variant : undefined,
      });
      if (items.length >= CAP) break;
    }
    return items;
  } catch {
    return EMPTY;
  }
}

/* --- snapshot cache: uSES requires the SAME reference for unchanged data.
 * The cache is module-level and keyed by (instanceId, raw) so several hooks
 * (or several instances) can never poison each other's snapshot. */
let cacheKey = "";
let cacheItems: StoreCartItem[] = EMPTY;

function readSnapshot(instanceId: string): StoreCartItem[] {
  const raw = window.localStorage.getItem(storageKey(instanceId));
  const key = `${instanceId}\u0000${raw ?? ""}`;
  if (key !== cacheKey) {
    cacheKey = key;
    cacheItems = parseItems(raw);
  }
  return cacheItems;
}

/** write-through mutation: localStorage first (source of truth), then the
 * same-tab event so every subscriber re-reads immediately. */
function writeSnapshot(instanceId: string, next: StoreCartItem[]): void {
  try {
    window.localStorage.setItem(storageKey(instanceId), JSON.stringify(next));
  } catch {
    /* quota exceeded / private mode — keep the in-memory cache consistent
     * with what the caller intended, so the UI stays usable this session */
    cacheItems = next;
    cacheKey = `${instanceId}\u0000__volatile__`;
    window.dispatchEvent(new Event(STORECART_EVENT));
    return;
  }
  window.dispatchEvent(new Event(STORECART_EVENT));
}

export function useStoreCart(instanceId: string): {
  items: StoreCartItem[];
  /** total unit count across lines (the FAB / header badge number) */
  count: number;
  /** upsert one line — an existing (recordId, variant) line merges its qty
   *  (capped at the fresh snapshot's max) and refreshes price/photo/name */
  add: (item: StoreCartItem) => void;
  setQty: (recordId: string, qty: number, variant?: string) => void;
  remove: (recordId: string, variant?: string) => void;
  clear: () => void;
} {
  /* subscribe: cross-tab `storage` + same-tab private event, scoped to the
   * instance's key. uSES re-subscribes whenever the callback identity
   * changes (instance switch) — exactly the lifecycle we want. */
  const subscribe = useCallback(
    (onStoreChange: () => void) => {
      const onStorage = (e: StorageEvent) => {
        if (e.key === storageKey(instanceId)) onStoreChange();
      };
      window.addEventListener("storage", onStorage);
      window.addEventListener(STORECART_EVENT, onStoreChange);
      return () => {
        window.removeEventListener("storage", onStorage);
        window.removeEventListener(STORECART_EVENT, onStoreChange);
      };
    },
    [instanceId]
  );

  const getSnapshot = useCallback(() => readSnapshot(instanceId), [instanceId]);
  const getServerSnapshot = useCallback(() => EMPTY, []);

  const items = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);

  const add = useCallback(
    (item: StoreCartItem) => {
      const current = readSnapshot(instanceId);
      const key = lineKey(item);
      const existing = current.find((i) => lineKey(i) === key);
      if (existing) {
        writeSnapshot(
          instanceId,
          current.map((i) =>
            lineKey(i) === key
              ? {
                  ...i,
                  qty: Math.min(item.max, existing.qty + item.qty),
                  price: item.price,
                  max: item.max,
                  imageRef: item.imageRef,
                }
              : i
          )
        );
        return;
      }
      /* append at the end (oldest-first order); oldest evicted beyond the cap */
      writeSnapshot(instanceId, [...current, item].slice(-CAP));
    },
    [instanceId]
  );

  const setQty = useCallback(
    (recordId: string, qty: number, variant?: string) => {
      const current = readSnapshot(instanceId);
      const key = lineKey({ recordId, variant });
      writeSnapshot(
        instanceId,
        current.map((i) =>
          lineKey(i) === key
            ? { ...i, qty: Math.min(i.max, Math.max(1, Math.floor(qty) || 1)) }
            : i
        )
      );
    },
    [instanceId]
  );

  const remove = useCallback(
    (recordId: string, variant?: string) => {
      const current = readSnapshot(instanceId);
      const key = lineKey({ recordId, variant });
      writeSnapshot(instanceId, current.filter((i) => lineKey(i) !== key));
    },
    [instanceId]
  );

  const clear = useCallback(() => writeSnapshot(instanceId, []), [instanceId]);

  const count = useMemo(() => items.reduce((sum, i) => sum + i.qty, 0), [items]);

  return { items, count, add, setQty, remove, clear };
}
