"use client";

/**
 * Ashrilogic — global landing keyboard shortcuts.
 *
 * Wires Alt+L (language), Alt+T (theme), Alt+ArrowUp (back to top).
 * Search (Ctrl/Cmd+K) is handled by the command palette; the `?` help dialog
 * is handled by its own component. This hook only runs on the landing view.
 */
import { useEffect } from "react";
import { useTheme } from "next-themes";
import { useAppStore } from "@/lib/store";
import { useT } from "@/lib/i18n";
import { nextLocale } from "@/lib/locales";

export function useGlobalShortcuts() {
  const { lang } = useT();
  const setLang = useAppStore((s) => s.setLang);
  const view = useAppStore((s) => s.view);
  const { resolvedTheme, setTheme } = useTheme();

  useEffect(() => {
    if (view !== "landing") return;

    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      const typing = tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT";

      // Alt+L → cycle languages (10-locale registry order)
      if (e.altKey && !e.ctrlKey && !e.metaKey && (e.key === "l" || e.key === "L")) {
        if (typing) return;
        e.preventDefault();
        setLang(nextLocale(lang));
        return;
      }
      // Alt+T → toggle theme
      if (e.altKey && !e.ctrlKey && !e.metaKey && (e.key === "t" || e.key === "T")) {
        if (typing) return;
        e.preventDefault();
        setTheme(resolvedTheme === "dark" ? "light" : "dark");
        return;
      }
      // Alt+ArrowUp → back to top
      if (e.altKey && !e.ctrlKey && !e.metaKey && e.key === "ArrowUp") {
        e.preventDefault();
        window.scrollTo({ top: 0, behavior: "smooth" });
      }
    };

    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [view, lang, setLang, resolvedTheme, setTheme]);
}
