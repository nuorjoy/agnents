"use client";

/**
 * Ashrilogic — sidebar pin toggle (Premium desktop auto-collapse).
 *
 * ROUND 160 — the pin preference is PER-SYSTEM: each tenant workspace
 * remembers its own sidebar pin state independently. The storage key
 * includes the instance ID so switching between systems honors each
 * one's own preference.
 *
 * SSR-safe: the server snapshot returns the pinned default (true) so
 * server-rendered markup matches the first client render.
 */
import { useCallback, useSyncExternalStore } from "react";

function readStored(storageKey: string): boolean {
  try {
    const stored = window.localStorage.getItem(storageKey);
    if (stored === "false") return false;
    if (stored === "true") return true;
  } catch {
    /* localStorage unavailable — keep default */
  }
  return true;
}

export interface SidebarPinState {
  isPinned: boolean;
  toggle: () => void;
}

/**
 * @param instanceId — when provided, the pin state is scoped to this
 *   workspace (per-system preference). When omitted, uses the global
 *   fallback key (backward compatible with legacy callers).
 */
export function useSidebarPin(instanceId?: string): SidebarPinState {
  const storageKey = instanceId
    ? `ashrilogic-sidebar-pinned-${instanceId}`
    : "ashrilogic-sidebar-pinned";

  const subscribe = useCallback(
    (onStoreChange: () => void) => {
      const onStorage = (e: StorageEvent) => {
        if (e.key === storageKey) onStoreChange();
      };
      window.addEventListener("storage", onStorage);
      return () => window.removeEventListener("storage", onStorage);
    },
    [storageKey]
  );

  const getSnapshot = useCallback(() => readStored(storageKey), [storageKey]);
  const getServerSnapshot = useCallback(() => true, []);

  const isPinned = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);

  const toggle = useCallback(() => {
    const next = !readStored(storageKey);
    try {
      window.localStorage.setItem(storageKey, next ? "true" : "false");
    } catch {
      /* best-effort persistence */
    }
    window.dispatchEvent(new StorageEvent("storage", { key: storageKey }));
  }, [storageKey]);

  return { isPinned, toggle };
}

/** Legacy fallback keys (used when no instanceId is passed) */
export const DASHBOARD_SIDEBAR_PIN_KEY = "ashrilogic-sidebar-pinned";
export const ADMIN_SIDEBAR_PIN_KEY = "ashrilogic-admin-sidebar-pinned";
