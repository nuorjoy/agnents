/**
 * Static asset module declarations (ROUND 170, performance).
 *
 * The root layout preloads the critical above-the-fold @fontsource WOFF2
 * files by importing them directly — the bundler then emits each file to
 * /_next/static/media with its content-hashed URL, and the <link
 * rel="preload"> references that exact URL (no hardcoded, drift-prone
 * paths). @fontsource ships font-display: swap, so the preload only moves
 * the LCP text paint EARLIER (the file downloads in parallel with the
 * render-blocking CSS instead of being discovered after the first layout);
 * it never blocks rendering on its own.
 */

declare module "*.woff2" {
  const src: string;
  export default src;
}

declare module "*.woff" {
  const src: string;
  export default src;
}
