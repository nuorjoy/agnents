import { NextResponse } from "next/server";
import { routeHandler, ctxAdmin } from "@/lib/server/route";
import { clampLimit, decodeKeyset } from "@/lib/server/keyset";
import type { QuoteStatus } from "@/lib/types";
import * as service from "./service";

/**
 * Ashrilogic — enterprise-quotes domain CONTROLLER (ROUND 167).
 *
 * The HTTP seam for the طلبات المؤسسات pipeline. Every handler is a
 * `routeHandler(...)` — correlation ids, the 500 envelope (`Failed to
 * <label>`), the bounded body reader and the zod 400 envelope come from the
 * unified wrapper. Guard surface is DECLARATIVE (ROUND 127):
 *
 *  - POST /api/enterprise-quotes — PUBLIC submit (the landing quote
 *    dialog): origin CSRF gate + per-IP throttle BEFORE the body read (the
 *    subscribe law), then the zod schema through ctx.parseBody.
 *  - GET /api/admin/enterprise-quotes — super+admin listing: keyset pages
 *    (?cursor, ?limit, ?status filter).
 *  - PATCH /api/admin/enterprise-quotes — super+admin pipeline mutation
 *    (withRequest: origin + the MFA-enrollment policy gate like every
 *    mutating admin route) + a light per-admin throttle.
 */

/** Public submit throttle: 5 requests / 10 min per IP (the subscribe law). */
const SUBMIT_RULE = { limit: 5, windowMs: 10 * 60 * 1000 };
/** Console mutation throttle: 60 transitions / 10 min per admin + IP. */
const PATCH_RULE = { limit: 60, windowMs: 10 * 60 * 1000 };

/** The legal status filter values (anything else is ignored → all). */
const STATUS_VALUES: readonly QuoteStatus[] = ["new", "contacted", "quoted", "won", "lost"];

/** POST /api/enterprise-quotes — public quote request (201 new / 200 dup). */
export const publicSubmit = routeHandler(
  "submit enterprise quote",
  {
    origin: true,
    rateLimit: {
      key: (parts) => `quote-submit:${parts.ip}`,
      rule: SUBMIT_RULE,
      body: { error: "Too many quote requests — try again later", code: "RATE_LIMITED" },
    },
  },
  async (ctx): Promise<NextResponse> => {
    const input = await ctx.parseBody(service.quoteCreateSchema);
    const result = await service.submit(input);
    return NextResponse.json(
      { ok: true, alreadySubmitted: result.alreadySubmitted },
      { status: result.alreadySubmitted ? 200 : 201 }
    );
  }
);

/** GET /api/admin/enterprise-quotes — the console inbox (keyset pages). */
export const adminList = routeHandler(
  "list enterprise quotes",
  { admin: { roles: ["super", "admin"] } },
  async (ctx): Promise<NextResponse> => {
    const params = new URL(ctx.req.url).searchParams;
    const rawStatus = params.get("status");
    const status = STATUS_VALUES.find((value) => value === rawStatus);
    const rawCursor = params.get("cursor");
    const cursor = rawCursor ? decodeKeyset(rawCursor) : null;
    /* a malformed cursor is a LOUD 400 (the keyset law: never silently
     * restart page 1 — the client would re-read the same page forever) */
    if (rawCursor && !cursor) {
      return NextResponse.json({ error: "Invalid pagination cursor" }, { status: 400 });
    }
    const limit = clampLimit(params.get("limit"), 20, 100);
    const page = await service.listPage({ status, cursor, limit });
    return NextResponse.json({ rows: page.rows, nextCursor: page.nextCursor });
  }
);

/** PATCH /api/admin/enterprise-quotes — pipeline transition + notes. */
export const adminPatch = routeHandler(
  "update enterprise quote",
  {
    origin: true,
    admin: { roles: ["super", "admin"], withRequest: true },
    rateLimit: {
      key: (parts) => `quote-patch:${parts.adminId()}:${parts.ip}`,
      rule: PATCH_RULE,
      body: { error: "Too many quote updates — try again later", code: "RATE_LIMITED" },
    },
  },
  async (ctx): Promise<NextResponse> => {
    const admin = ctxAdmin(ctx);
    const input = await ctx.parseBody(service.quotePatchSchema);
    const row = await service.patch(input, { id: admin.id, username: admin.username });
    return NextResponse.json(row);
  }
);
