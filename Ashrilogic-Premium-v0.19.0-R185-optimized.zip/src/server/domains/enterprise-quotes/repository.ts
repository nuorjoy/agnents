import type { EnterpriseQuote, Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { encodeKeyset, keysetPredicate, type KeysetCursor } from "@/lib/server/keyset";

/**
 * Ashrilogic — enterprise-quotes domain REPOSITORY (ROUND 167).
 *
 * The persistence seam for the طلبات المؤسسات (Enterprise quote) pipeline:
 * every Prisma touch for the EnterpriseQuote aggregate lives here and
 * nowhere else. The lead's email is SEALED at rest (AES-256-GCM envelope,
 * crypto-vault.ts) with the blind index as the dedupe/search key — the
 * Subscriber/AdminUser law; the plaintext NEVER persists in this table.
 *
 * Feed pagination rides the SHARED keyset helper (lib/server/keyset.ts —
 * the `(createdAt DESC, id DESC)` total order + opaque base64url cursor),
 * never a hand-rolled predicate.
 */

/** Console listing cap per response (keyset pages stay bounded). */
export const QUOTE_LIST_CAP = 100;

/** One inbox row shape (the full aggregate — the DTO maps it). */
export type QuoteRow = EnterpriseQuote;

/** The keyset page: rows + the opaque next-page cursor (null = exhausted). */
export interface QuotePage {
  rows: QuoteRow[];
  nextCursor: string | null;
}

/**
 * Find an ACTIVE quote (new/contacted/quoted — the dedupe law: a lead with
 * a live request never files a second row; a closed won/lost lead may
 * submit a fresh one) by its blind-indexed email.
 */
export async function findActiveByEmailIndex(emailIndex: string): Promise<QuoteRow | null> {
  return db.enterpriseQuote.findFirst({
    where: { emailIndex, status: { in: ["new", "contacted", "quoted"] } },
    orderBy: { createdAt: "desc" },
  });
}

/** The create input (the service pre-seals the email + index). */
export interface QuoteCreateInput {
  name: string;
  email: string;
  emailIndex: string;
  company: string;
  teamSize: string;
  systemsCount: number;
  notes: string;
}

/** Persist a fresh quote lead (status "new", no pipeline stamps yet). */
export async function create(input: QuoteCreateInput): Promise<QuoteRow> {
  return db.enterpriseQuote.create({ data: { ...input, status: "new" } });
}

/** Full row for the PATCH path (404 + transition policy is the service's). */
export async function findById(id: string): Promise<QuoteRow | null> {
  return db.enterpriseQuote.findUnique({ where: { id } });
}

/**
 * Keyset listing (newest first): the cursor resumes STRICTLY AFTER the last
 * row the caller saw, the page limit is clamped by the controller, and the
 * status filter is an optional exact match on the pipeline column.
 */
export async function listPage(opts: {
  status?: string;
  cursor?: KeysetCursor | null;
  limit: number;
}): Promise<QuotePage> {
  const where: Prisma.EnterpriseQuoteWhereInput = {
    ...(opts.status ? { status: opts.status } : {}),
    ...(opts.cursor ? keysetPredicate(opts.cursor) : {}),
  };
  /* fetch limit + 1 — the extra row decides whether a next page exists */
  const bounded = Math.min(QUOTE_LIST_CAP, Math.max(1, opts.limit));
  const rows = await db.enterpriseQuote.findMany({
    where,
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    take: bounded + 1,
  });
  const hasMore = rows.length > bounded;
  const page = hasMore ? rows.slice(0, bounded) : rows;
  const last = page[page.length - 1];
  return { rows: page, nextCursor: hasMore && last ? encodeKeyset(last) : null };
}

/** The PATCH write — only the service-validated fields ever land here. */
export async function update(
  id: string,
  data: Pick<EnterpriseQuote, "status" | "adminNotes"> &
    Partial<Pick<EnterpriseQuote, "contactedAt" | "quotedAt" | "closedAt">>
): Promise<QuoteRow> {
  return db.enterpriseQuote.update({ where: { id }, data });
}
