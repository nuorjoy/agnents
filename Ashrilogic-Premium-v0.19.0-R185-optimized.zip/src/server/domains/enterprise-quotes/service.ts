import { z } from "zod";
import { blindIndex, decryptField, encryptField } from "@/lib/server/crypto-vault";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { HttpError } from "@/lib/server/route";
import { QUOTE_TEAM_SIZES, QUOTE_TRANSITIONS, type EnterpriseQuoteDTO, type QuoteStatus } from "@/lib/types";
import * as repository from "./repository";

/**
 * Ashrilogic — enterprise-quotes domain SERVICE (ROUND 167).
 *
 * Business rules for the طلبات المؤسسات (Enterprise quote) pipeline — the
 * CRM behind the landing's Enterprise card («اطلب عرض سعر مخصص»):
 *
 *  - PUBLIC SUBMIT: the lead's email is SEALED (AES-256-GCM) with a blind
 *    index, exactly like a newsletter subscriber. DEDUPE: when an ACTIVE
 *    quote (new/contacted/quoted) with the same blind index already exists
 *    the submit answers 200 { alreadySubmitted: true } — no second row, no
 *    error (a closed won/lost lead may file a fresh request). The creation
 *    rides the BUSINESS audit trail with the address MASKED.
 *  - CONSOLE LIST: keyset pages (newest first) with an optional status
 *    filter; the DTO carries the MASKED address only (n***@domain) — the
 *    plaintext is recovered exclusively through the one-time sealed-email
 *    reveal lever (targetType "quote").
 *  - CONSOLE PATCH: one-directional pipeline new → contacted → quoted →
 *    won|lost (QUOTE_TRANSITIONS — terminal states never reopen), with
 *    contactedAt/quotedAt/closedAt stamped on entry, plus the adminNotes
 *    working pad. Every mutation writes a platform.quoteStatus audit row
 *    (masked address, from → to, the stamped clock columns).
 *
 * HTTP never appears here: no Request, no NextResponse — the controller and
 * the unified route wrapper own the envelope; HttpError is the domain signal.
 */

/* ------------------------------------------------------------------ */
/* zod — the route-boundary schemas                                     */
/* ------------------------------------------------------------------ */

/**
 * The public quote-request body. The email is normalized (trim + lowercase)
 * BEFORE the seal so the blind index is stable across keyboard layouts.
 */
export const quoteCreateSchema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.email().max(254).transform((value) => value.trim().toLowerCase()),
  company: z.string().trim().max(120).optional().default(""),
  teamSize: z.enum(QUOTE_TEAM_SIZES),
  systemsCount: z.number().int().min(1).max(500),
  notes: z.string().trim().max(1000).optional().default(""),
});

/** The console PATCH body: the target id (always required) plus a status
 *  transition and/or the working notes. */
export const quotePatchSchema = z
  .object({
    id: z.string().trim().min(1).max(64),
    status: z.enum(["new", "contacted", "quoted", "won", "lost"]).optional(),
    adminNotes: z.string().max(2000).optional(),
  })
  .refine((data) => data.status !== undefined || data.adminNotes !== undefined, {
    message: "At least one of status / adminNotes is required",
  });

export type QuoteCreateInput = z.infer<typeof quoteCreateSchema>;
export type QuotePatchInput = z.infer<typeof quotePatchSchema>;

/* ------------------------------------------------------------------ */
/* DTO                                                                  */
/* ------------------------------------------------------------------ */

/** Map one row for the console — the email arrives MASKED, never plaintext
 *  (the sealed cell is decrypted ONLY to build the n***@domain mask). */
function toQuoteDTO(row: repository.QuoteRow): EnterpriseQuoteDTO {
  const status: QuoteStatus =
    row.status === "contacted" || row.status === "quoted" || row.status === "won" || row.status === "lost"
      ? row.status
      : "new";
  return {
    id: row.id,
    name: row.name,
    emailMasked: maskEmail(decryptField(row.email) ?? ""),
    company: row.company,
    teamSize: row.teamSize,
    systemsCount: row.systemsCount,
    notes: row.notes,
    status,
    adminNotes: row.adminNotes,
    contactedAt: row.contactedAt ? row.contactedAt.toISOString() : null,
    quotedAt: row.quotedAt ? row.quotedAt.toISOString() : null,
    closedAt: row.closedAt ? row.closedAt.toISOString() : null,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

/* ------------------------------------------------------------------ */
/* the acting admin (audit attribution)                                 */
/* ------------------------------------------------------------------ */

export interface QuoteActor {
  id: string;
  username: string;
}

/* ------------------------------------------------------------------ */
/* public submit                                                        */
/* ------------------------------------------------------------------ */

/**
 * File one Enterprise quote request. Returns { alreadySubmitted: true }
 * (200 semantics decided by the controller) when the lead already has an
 * ACTIVE quote — the dialog's duplicate arm.
 */
export async function submit(input: QuoteCreateInput): Promise<{ alreadySubmitted: boolean }> {
  const emailIndex = blindIndex(input.email) ?? "";
  const existing = emailIndex ? await repository.findActiveByEmailIndex(emailIndex) : null;
  if (existing) {
    return { alreadySubmitted: true };
  }

  const row = await repository.create({
    name: input.name,
    email: encryptField(input.email) ?? "",
    emailIndex,
    company: input.company ?? "",
    teamSize: input.teamSize,
    systemsCount: input.systemsCount,
    notes: input.notes ?? "",
  });

  /* BUSINESS trail (the newsletter.add law): masked address only, the lead
   * profile fields ride the meta so the console trail narrates the lead. */
  await logAudit({
    actorType: "public",
    actorId: row.id,
    actorName: maskEmail(input.email),
    action: "platform.quoteCreate",
    targetLabel: row.company || row.name,
    meta: {
      teamSize: row.teamSize,
      systems: String(row.systemsCount),
      ...(row.company ? { company: row.company } : {}),
    },
  });

  return { alreadySubmitted: false };
}

/* ------------------------------------------------------------------ */
/* console listing                                                      */
/* ------------------------------------------------------------------ */

/** One keyset page of the inbox (masked emails, newest first). */
export async function listPage(opts: {
  status?: QuoteStatus;
  cursor?: { t: string; i: string } | null;
  limit: number;
}): Promise<{ rows: EnterpriseQuoteDTO[]; nextCursor: string | null }> {
  const page = await repository.listPage({
    status: opts.status,
    cursor: opts.cursor ?? null,
    limit: opts.limit,
  });
  return { rows: page.rows.map(toQuoteDTO), nextCursor: page.nextCursor };
}

/* ------------------------------------------------------------------ */
/* console PATCH (pipeline transition + working notes)                  */
/* ------------------------------------------------------------------ */

/**
 * Transition a lead through the pipeline and/or update the working notes.
 * Illegal moves (skipping stages, reopening a terminal won/lost row) are
 * the 400 QUOTE_INVALID_TRANSITION envelope; unknown ids are the 404
 * QUOTE_NOT_FOUND one. contactedAt/quotedAt/closedAt stamp on ENTRY into
 * their status (transitions are one-directional, so each stamps at most
 * once; an explicit later stamp never overwrites the first).
 */
export async function patch(input: QuotePatchInput, actor: QuoteActor): Promise<EnterpriseQuoteDTO> {
  const row = await repository.findById(input.id);
  if (!row) {
    throw new HttpError(404, "Quote request not found", "QUOTE_NOT_FOUND");
  }

  const nextStatus = input.status;
  if (nextStatus !== undefined && nextStatus !== row.status) {
    const legal = QUOTE_TRANSITIONS[row.status as QuoteStatus] ?? [];
    if (!legal.includes(nextStatus)) {
      throw new HttpError(
        400,
        `Invalid quote transition: ${row.status} → ${nextStatus}`,
        "QUOTE_INVALID_TRANSITION"
      );
    }
  }

  const now = new Date();
  const stamps: Partial<Pick<repository.QuoteRow, "contactedAt" | "quotedAt" | "closedAt">> = {};
  if (nextStatus === "contacted" && !row.contactedAt) stamps.contactedAt = now;
  if (nextStatus === "quoted" && !row.quotedAt) stamps.quotedAt = now;
  if ((nextStatus === "won" || nextStatus === "lost") && !row.closedAt) stamps.closedAt = now;

  const updated = await repository.update(row.id, {
    status: nextStatus ?? (row.status as QuoteStatus),
    adminNotes: input.adminNotes !== undefined ? input.adminNotes : row.adminNotes,
    ...stamps,
  });

  /* the triage trail: which lead moved where (+ the stamped clock columns
   * + whether the working pad changed) — masked address as the label. */
  await logAudit({
    actorType: "admin",
    actorId: actor.id,
    actorName: actor.username,
    action: "platform.quoteStatus",
    targetLabel: updated.company || updated.name,
    meta: {
      ...(nextStatus !== undefined ? { from: row.status, to: nextStatus } : {}),
      ...(stamps.contactedAt ? { contactedAt: stamps.contactedAt.toISOString() } : {}),
      ...(stamps.quotedAt ? { quotedAt: stamps.quotedAt.toISOString() } : {}),
      ...(stamps.closedAt ? { closedAt: stamps.closedAt.toISOString() } : {}),
      ...(input.adminNotes !== undefined ? { adminNotes: "updated" } : {}),
    },
  });

  return toQuoteDTO(updated);
}
