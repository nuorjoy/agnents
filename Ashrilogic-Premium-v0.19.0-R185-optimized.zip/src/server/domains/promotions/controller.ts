import { NextResponse } from "next/server";
import { routeHandler, ctxAdmin } from "@/lib/server/route";
import * as service from "./service";
import * as repo from "./repository";

/**
 * Ashrilogic — promotions domain CONTROLLER (ROUND 169, العروض الترويجية).
 *
 * The HTTP seam of the site-promotion banner domain. Every handler is a
 * `routeHandler(...)` (the unified wrapper: correlation ids, the bounded
 * body reader + zod 400 envelope, redacted telemetry) with DECLARATIVE
 * guards:
 *
 *  - GET  /api/promotions — the PUBLIC live-window feed: no auth, a
 *    standard per-IP public read throttle + a short public cache header
 *    (the /api/identity law — changes converge everywhere within a minute).
 *    Only the PUBLIC display projection ever leaves this route.
 *  - GET  /api/admin/promotions — the archive (super/admin read; the
 *    schedule-status filter rides ?status=live|upcoming|expired|all).
 *  - POST /api/admin/promotions — create (super/admin + origin CSRF gate +
 *    MFA-policy gate — the standard mutation posture).
 *  - PATCH /api/admin/promotions/[id] — update (same posture).
 *  - DELETE /api/admin/promotions/[id] — remove (same posture).
 */

/** Standard public read throttle: 60 requests / 10 min per IP. */
const PUBLIC_READ_RULE = { limit: 60, windowMs: 10 * 60 * 1000 };

/** The public feed's short cache (the /api/identity law). */
const PUBLIC_CACHE_HEADERS = {
  "Cache-Control": "public, max-age=60, stale-while-revalidate=300",
};

/** The recognized status filter values (anything else is ignored → all). */
function statusFilter(raw: string | null): repo.PromotionStatusFilter {
  return raw === "live" || raw === "upcoming" || raw === "expired" ? raw : "all";
}

/** Segment shape for the [id] route (Next 16: params is a Promise). */
interface PromotionSegment {
  params: Promise<{ id: string }>;
}

/** GET /api/promotions — the PUBLIC live-window feed (≤ 3, display fields). */
export const publicList = routeHandler(
  "list promotions",
  {
    rateLimit: {
      key: (parts) => `promotions:${parts.ip}`,
      rule: PUBLIC_READ_RULE,
      body: { error: "Too many requests — try again later", code: "RATE_LIMITED" },
    },
  },
  async (): Promise<NextResponse> => {
    const rows = await service.listPublic();
    return NextResponse.json(rows, { headers: PUBLIC_CACHE_HEADERS });
  }
);

/** GET /api/admin/promotions — the archive (super/admin read). */
export const adminList = routeHandler(
  "list promotions",
  { admin: { roles: ["super", "admin"] } },
  async (ctx): Promise<NextResponse> => {
    const params = new URL(ctx.req.url).searchParams;
    const rows = await service.listAdmin(statusFilter(params.get("status")));
    return NextResponse.json(rows);
  }
);

/** POST /api/admin/promotions — create a promotion (super/admin, audited). */
export const adminCreate = routeHandler(
  "create promotion",
  {
    origin: true,
    admin: { roles: ["super", "admin"], withRequest: true },
  },
  async (ctx): Promise<NextResponse> => {
    const admin = ctxAdmin(ctx);
    const input = await ctx.parseBody(service.promotionCreateSchema);
    const row = await service.create(input, { id: admin.id, username: admin.username });
    return NextResponse.json(row, { status: 201 });
  }
);

/** PATCH /api/admin/promotions/[id] — update (super/admin, audited). */
export const adminUpdate = routeHandler(
  "update promotion",
  {
    origin: true,
    admin: { roles: ["super", "admin"], withRequest: true },
  },
  async (ctx, segment: PromotionSegment): Promise<NextResponse> => {
    const admin = ctxAdmin(ctx);
    const { id } = await segment.params;
    const input = await ctx.parseBody(service.promotionUpdateSchema);
    const row = await service.update(id, input, { id: admin.id, username: admin.username });
    return NextResponse.json(row);
  }
);

/** DELETE /api/admin/promotions/[id] — remove (super/admin, audited). */
export const adminRemove = routeHandler(
  "delete promotion",
  {
    origin: true,
    admin: { roles: ["super", "admin"], withRequest: true },
  },
  async (ctx, segment: PromotionSegment): Promise<NextResponse> => {
    const admin = ctxAdmin(ctx);
    const { id } = await segment.params;
    await service.remove(id, { id: admin.id, username: admin.username });
    return new NextResponse(null, { status: 204 });
  }
);
