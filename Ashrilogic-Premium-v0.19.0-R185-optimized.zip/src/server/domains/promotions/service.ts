import { z } from "zod";
import { logAudit } from "@/lib/server/audit";
import { HttpError } from "@/lib/server/route";
import * as repo from "./repository";

/**
 * Ashrilogic — promotions domain SERVICE (ROUND 169, العروض الترويجية).
 *
 * The owner's directive: «add offer messages on the official website like
 * Black Friday, New Year, Eid Mubarak promotions — like the big sites
 * (Amazon, Walmart) — in a Premium way». Business shape:
 *
 *  - PUBLIC FEED: the ACTIVE promotions whose [startsAt..endsAt] window
 *    contains now, lowest sortOrder first, capped at 3 — projected onto the
 *    PUBLIC display fields only (bilingual copy, theme, badge, discount,
 *    CTA + the window itself; never the internal timestamps).
 *  - ADMIN CRUD: bilingual titles/messages/badges/CTA copy, one of the five
 *    theme skins, a 0..90% discount chip, an IN-APP relative CTA href (a
 *    same-origin path or an in-page anchor — never an external/protocol
 *    URL, the open-redirect law), a strictly-ordered schedule window and
 *    the active toggle. Every mutation is audited
 *    (platform.promotionCreate/Update/Delete — the content-visibility
 *    business trail).
 *
 * HTTP never appears here: no Request, no NextResponse — the controller and
 * the unified route wrapper own the envelope; HttpError is the domain
 * signal.
 */

/* ------------------------------------------------------------------ */
/* bounds                                                              */
/* ------------------------------------------------------------------ */

/** Bilingual copy length ceilings (characters). */
export const TITLE_MAX = 80;
export const MESSAGE_MAX = 140;
export const BADGE_MAX = 24;
export const CTA_TEXT_MAX = 40;
/** The CTA href ceiling — in-app relative paths stay well under it. */
export const CTA_HREF_MAX = 200;
/** Discount chip ceiling (percent). */
export const DISCOUNT_MAX = 90;
/** Sort-order bounds (lowest paints first). */
export const SORT_MIN = -100;
export const SORT_MAX = 1000;
/** The live public feed cap (the landing strip shows at most this many). */
export const PUBLIC_TAKE = 3;

/** The schedule-window span ceiling (days) — a banner is an EVENT, not a
 *  permanent fixture. */
export const WINDOW_MAX_DAYS = 366;

/* ------------------------------------------------------------------ */
/* zod — the route-boundary schemas                                    */
/* ------------------------------------------------------------------ */

/**
 * The CTA href law: EMPTY (informational banner) or a RELATIVE in-app
 * path — "/"-prefixed route or "#"-prefixed anchor. Anything else
 * (absolute URLs, protocol-relative "//evil", "javascript:…") is rejected
 * at the boundary — the public banner must never become an open redirect.
 */
const ctaHrefSchema = z
  .string()
  .trim()
  .max(CTA_HREF_MAX)
  .refine((href) => href === "" || href.startsWith("/") || href.startsWith("#"), {
    message: "ctaHref must be an in-app relative path (\"/…\" or \"#…\")",
  });

const scheduleFields = {
  /** ISO datetime (the console sends datetime-local values). */
  startsAt: z.coerce.date(),
  endsAt: z.coerce.date(),
};

/** The shared bilingual/theme/presentation fields (create + update). */
const copyFields = {
  titleAr: z.string().trim().min(2).max(TITLE_MAX),
  titleEn: z.string().trim().min(2).max(TITLE_MAX),
  messageAr: z.string().trim().max(MESSAGE_MAX).default(""),
  messageEn: z.string().trim().max(MESSAGE_MAX).default(""),
  theme: z.enum(repo.PROMOTION_THEMES),
  badgeAr: z.string().trim().max(BADGE_MAX).default(""),
  badgeEn: z.string().trim().max(BADGE_MAX).default(""),
  discountPct: z.number().int().min(0).max(DISCOUNT_MAX).default(0),
  ctaTextAr: z.string().trim().max(CTA_TEXT_MAX).default(""),
  ctaTextEn: z.string().trim().max(CTA_TEXT_MAX).default(""),
  ctaHref: ctaHrefSchema.default(""),
  active: z.boolean().default(true),
  sortOrder: z.number().int().min(SORT_MIN).max(SORT_MAX).default(0),
};

export const promotionCreateSchema = z
  .object({ ...copyFields, ...scheduleFields })
  .refine((data) => data.endsAt > data.startsAt, {
    message: "endsAt must be after startsAt",
    path: ["endsAt"],
  })
  .refine((data) => data.endsAt.getTime() > Date.now(), {
    message: "endsAt must be in the future",
    path: ["endsAt"],
  })
  .refine(
    (data) => data.endsAt.getTime() - data.startsAt.getTime() <= WINDOW_MAX_DAYS * 24 * 60 * 60 * 1000,
    { message: "the schedule window cannot exceed a year", path: ["endsAt"] }
  );

export const promotionUpdateSchema = z
  .object({
    titleAr: z.string().trim().min(2).max(TITLE_MAX).optional(),
    titleEn: z.string().trim().min(2).max(TITLE_MAX).optional(),
    messageAr: z.string().trim().max(MESSAGE_MAX).optional(),
    messageEn: z.string().trim().max(MESSAGE_MAX).optional(),
    theme: z.enum(repo.PROMOTION_THEMES).optional(),
    badgeAr: z.string().trim().max(BADGE_MAX).optional(),
    badgeEn: z.string().trim().max(BADGE_MAX).optional(),
    discountPct: z.number().int().min(0).max(DISCOUNT_MAX).optional(),
    ctaTextAr: z.string().trim().max(CTA_TEXT_MAX).optional(),
    ctaTextEn: z.string().trim().max(CTA_TEXT_MAX).optional(),
    ctaHref: ctaHrefSchema.optional(),
    active: z.boolean().optional(),
    sortOrder: z.number().int().min(SORT_MIN).max(SORT_MAX).optional(),
    startsAt: z.coerce.date().optional(),
    endsAt: z.coerce.date().optional(),
  })
  .refine(
    (data) =>
      data.startsAt === undefined || data.endsAt === undefined || data.endsAt > data.startsAt,
    { message: "endsAt must be after startsAt", path: ["endsAt"] }
  );

export type PromotionCreateInput = z.infer<typeof promotionCreateSchema>;
export type PromotionUpdateInput = z.infer<typeof promotionUpdateSchema>;

/* ------------------------------------------------------------------ */
/* the acting admin (audit attribution)                                */
/* ------------------------------------------------------------------ */

export interface PromotionActor {
  id: string;
  username: string;
}

/** The audit target label — the bilingual title pair, truncated. */
function targetLabel(input: { titleAr: string; titleEn: string }): string {
  return `${input.titleAr} · ${input.titleEn}`.slice(0, 60);
}

/* ------------------------------------------------------------------ */
/* public feed                                                         */
/* ------------------------------------------------------------------ */

/** GET /api/promotions — the live public window feed (≤ 3, public fields). */
export async function listPublic(): Promise<repo.PublicPromotionDTO[]> {
  const rows = await repo.listLivePublic(PUBLIC_TAKE);
  return rows.map(repo.toPublicPromotionDTO);
}

/* ------------------------------------------------------------------ */
/* admin surfaces                                                      */
/* ------------------------------------------------------------------ */

/** GET /api/admin/promotions — the archive + the schedule-status filter. */
export async function listAdmin(
  filter: repo.PromotionStatusFilter
): Promise<repo.AdminPromotionDTO[]> {
  const rows = await repo.listPromotions(filter);
  return rows.map(repo.toAdminPromotionDTO);
}

/** POST /api/admin/promotions — create (audited platform.promotionCreate). */
export async function create(
  input: PromotionCreateInput,
  actor: PromotionActor
): Promise<repo.AdminPromotionDTO> {
  const row = await repo.createPromotion(input);
  await logAudit({
    actorType: "admin",
    actorId: actor.id,
    actorName: actor.username,
    action: "platform.promotionCreate",
    targetLabel: targetLabel(input),
    meta: {
      theme: input.theme,
      discountPct: String(input.discountPct),
      active: String(input.active),
      startsAt: input.startsAt.toISOString(),
      endsAt: input.endsAt.toISOString(),
      ctaHref: input.ctaHref,
    },
  });
  return repo.toAdminPromotionDTO(row);
}

/** PATCH /api/admin/promotions/[id] — update (audited
 *  platform.promotionUpdate; the window pair is validated against the
 *  MERGED row so a partial patch cannot produce startsAt ≥ endsAt). */
export async function update(
  id: string,
  input: PromotionUpdateInput,
  actor: PromotionActor
): Promise<repo.AdminPromotionDTO> {
  const existing = await repo.findPromotion(id);
  if (!existing) {
    throw new HttpError(404, "Promotion not found", "PROMOTION_NOT_FOUND");
  }
  const startsAt = input.startsAt ?? existing.startsAt;
  const endsAt = input.endsAt ?? existing.endsAt;
  if (endsAt <= startsAt) {
    throw new HttpError(400, "endsAt must be after startsAt", "PROMOTION_BAD_WINDOW");
  }
  if (endsAt.getTime() - startsAt.getTime() > WINDOW_MAX_DAYS * 24 * 60 * 60 * 1000) {
    throw new HttpError(400, "the schedule window cannot exceed a year", "PROMOTION_BAD_WINDOW");
  }
  const row = await repo.updatePromotion(id, { ...input, startsAt, endsAt });
  await logAudit({
    actorType: "admin",
    actorId: actor.id,
    actorName: actor.username,
    action: "platform.promotionUpdate",
    targetLabel: targetLabel(row),
    meta: {
      theme: row.theme,
      discountPct: String(row.discountPct),
      active: String(row.active),
      startsAt: startsAt.toISOString(),
      endsAt: endsAt.toISOString(),
      ctaHref: row.ctaHref,
    },
  });
  return repo.toAdminPromotionDTO(row);
}

/** DELETE /api/admin/promotions/[id] — remove (audited
 *  platform.promotionDelete). */
export async function remove(
  id: string,
  actor: PromotionActor
): Promise<void> {
  const existing = await repo.findPromotion(id);
  if (!existing) {
    throw new HttpError(404, "Promotion not found", "PROMOTION_NOT_FOUND");
  }
  await repo.deletePromotion(id);
  await logAudit({
    actorType: "admin",
    actorId: actor.id,
    actorName: actor.username,
    action: "platform.promotionDelete",
    targetLabel: targetLabel(existing),
    meta: {
      theme: existing.theme,
      active: String(existing.active),
      startsAt: existing.startsAt.toISOString(),
      endsAt: existing.endsAt.toISOString(),
    },
  });
}
