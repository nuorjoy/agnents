import { db } from "@/lib/db";
import type { Promotion } from "@prisma/client";

/**
 * Ashrilogic — promotions domain REPOSITORY (ROUND 169, العروض الترويجية).
 *
 * The ONLY Prisma touchpoint of the site-promotion banner domain: the
 * public live-window feed (the landing banner strip) + the Super-Admin
 * archive with its schedule-status filter. Shapes follow the
 * domain-repository conventions of the sibling domains (bounded takes,
 * explicit selects, DTO projections at the boundary).
 */

/** The theme skins the landing banner renders (drives colors/emoji). */
export const PROMOTION_THEMES = [
  "black-friday",
  "new-year",
  "eid",
  "sale",
  "custom",
] as const;
export type PromotionTheme = (typeof PROMOTION_THEMES)[number];

/** The schedule-status buckets the admin list filters by. */
export const PROMOTION_FILTERS = ["all", "live", "upcoming", "expired"] as const;
export type PromotionStatusFilter = (typeof PROMOTION_FILTERS)[number];

export type PromotionRow = Promotion;

/** The PUBLIC display projection — bilingual copy, theme, badge, discount,
 * CTA + the schedule window the countdown/dismiss key needs. NO internal
 * timestamps (createdAt/updatedAt), NO admin-only fields (this model has
 * none beyond the timestamps). */
export interface PublicPromotionDTO {
  id: string;
  titleAr: string;
  titleEn: string;
  messageAr: string;
  messageEn: string;
  theme: string;
  badgeAr: string;
  badgeEn: string;
  discountPct: number;
  ctaTextAr: string;
  ctaTextEn: string;
  ctaHref: string;
  startsAt: string;
  endsAt: string;
  sortOrder: number;
}

/** The ADMIN projection — the full row (schedule + audit-relevant state). */
export interface AdminPromotionDTO extends PublicPromotionDTO {
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

/** Serialize the public projection (the /api/promotions response shape). */
export function toPublicPromotionDTO(row: PromotionRow): PublicPromotionDTO {
  return {
    id: row.id,
    titleAr: row.titleAr,
    titleEn: row.titleEn,
    messageAr: row.messageAr,
    messageEn: row.messageEn,
    theme: row.theme,
    badgeAr: row.badgeAr,
    badgeEn: row.badgeEn,
    discountPct: row.discountPct,
    ctaTextAr: row.ctaTextAr,
    ctaTextEn: row.ctaTextEn,
    ctaHref: row.ctaHref,
    startsAt: row.startsAt.toISOString(),
    endsAt: row.endsAt.toISOString(),
    sortOrder: row.sortOrder,
  };
}

/** Serialize the admin projection (the console's card grid shape). */
export function toAdminPromotionDTO(row: PromotionRow): AdminPromotionDTO {
  return {
    ...toPublicPromotionDTO(row),
    active: row.active,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

/** The live-window predicate — active AND [startsAt..endsAt] contains now. */
function liveWhere() {
  const now = new Date();
  return { active: true, startsAt: { lte: now }, endsAt: { gte: now } };
}

/**
 * The PUBLIC live feed: active promotions whose window contains now,
 * lowest sortOrder first (then the earliest window for a deterministic
 * order), capped at 3 — the landing banner strip.
 */
export async function listLivePublic(take = 3): Promise<PromotionRow[]> {
  return db.promotion.findMany({
    where: liveWhere(),
    orderBy: [{ sortOrder: "asc" }, { startsAt: "asc" }],
    take,
  });
}

/** The schedule-status where shape for the admin archive filter. */
function statusWhere(filter: PromotionStatusFilter) {
  const now = new Date();
  switch (filter) {
    case "live":
      return liveWhere();
    case "upcoming":
      return { startsAt: { gt: now } };
    case "expired":
      return { endsAt: { lt: now } };
    default:
      return {};
  }
}

/** The admin archive (newest first, bounded — the console's card grid). */
export async function listPromotions(
  filter: PromotionStatusFilter = "all",
  take = 100
): Promise<PromotionRow[]> {
  return db.promotion.findMany({
    where: statusWhere(filter),
    orderBy: { createdAt: "desc" },
    take,
  });
}

export async function findPromotion(id: string): Promise<PromotionRow | null> {
  return db.promotion.findUnique({ where: { id } });
}

/** The writable column set (create + update share the projection). */
export type PromotionWriteData = Pick<
  PromotionRow,
  | "titleAr"
  | "titleEn"
  | "messageAr"
  | "messageEn"
  | "theme"
  | "badgeAr"
  | "badgeEn"
  | "discountPct"
  | "ctaTextAr"
  | "ctaTextEn"
  | "ctaHref"
  | "startsAt"
  | "endsAt"
  | "active"
  | "sortOrder"
>;

export async function createPromotion(
  data: PromotionWriteData
): Promise<PromotionRow> {
  return db.promotion.create({ data });
}

export async function updatePromotion(
  id: string,
  data: Partial<PromotionWriteData>
): Promise<PromotionRow> {
  return db.promotion.update({ where: { id }, data });
}

export async function deletePromotion(id: string): Promise<void> {
  await db.promotion.delete({ where: { id } });
}
