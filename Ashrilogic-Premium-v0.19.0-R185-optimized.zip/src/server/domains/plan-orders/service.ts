import type { AdminPlanOrderDTO } from "@/lib/types";
import { db } from "@/lib/db";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { toInstanceDTO } from "@/lib/server/instance-mapper";
import {
  buildInstructions,
  createPlanOrder,
  cancelPlanOrder,
  confirmPlanOrderPaid,
  findPaymentMethod,
  readPaymentsSettings,
  toPlanOrderDTO,
  WALLET_CHECKOUT_METHOD_ID,
  type PlanCycle,
} from "@/lib/server/plan-orders";
import { payOrderFromWallet, refundWalletDebit } from "@/lib/server/wallet";
import { deliverWelcomeBonusOnPaidOrder } from "@/lib/server/welcome-bonus";
import { HttpError } from "@/lib/server/route";
import * as repository from "./repository";

/**
 * Ashrilogic — plan-orders domain SERVICE (ROUND 125).
 *
 * Business flows for the billing/activation surface, lifted verbatim from
 * the four legacy route handlers and composed over the SHARED transition
 * core (src/lib/server/plan-orders.ts — the HMAC-sealed state machine).
 * Every flow owns its audit row with the exact legacy meta shapes.
 *
 * Error policy: the legacy handlers returned `{ error, code? }` result
 * objects with explicit statuses; here those become HttpError throws with
 * the SAME status/message/code — the unified wrapper renders the identical
 * envelope. The one legacy response the wrapper cannot express (429 with
 * Retry-After headers) stays a controller concern.
 */

/** The acting admin (from the session guard) — audit attribution. */
export interface AdminActor {
  id: string;
  name: string;
}

/** The acting workspace principal (tenant session) — audit attribution. */
export interface TenantPrincipal {
  kind: string;
  actorId?: string;
  actorName: string;
}

/** The create-input shape (already Zod-validated by the controller).
 *  ROUND 141 — payWith "wallet" selects the INSTANT wallet checkout: the
 *  order is created, the wallet is DEBITED (CAS), and the plan is
 *  CONFIRMED + ACTIVATED in the same flow — no admin round-trip. */
export interface CreateOrderInput {
  packageId: string;
  cycle: PlanCycle;
  methodId: string;
  payWith?: "wallet";
}

/** Admin console listing: DTOs enriched with the owning workspace identity. */
export async function listConsole(
  status?: "pending" | "paid" | "cancelled"
): Promise<AdminPlanOrderDTO[]> {
  const rows = await repository.listForConsole(status);
  return rows.map((row) => {
    /* org name from the sealed orgJson — the legacy lenient parse with
     * corrupt-JSON fallback to the system id, then the em dash. */
    let orgName = row.instance?.systemId ?? "—";
    try {
      const org = JSON.parse(row.instance?.orgJson ?? "{}") as { name?: unknown };
      if (typeof org.name === "string" && org.name.trim()) orgName = org.name.trim();
    } catch {
      /* corrupt orgJson — fall back to systemId */
    }
    return {
      ...toPlanOrderDTO(row),
      orgName,
      systemId: row.instance?.systemId ?? "",
    };
  });
}

/** Tenant's own history (newest first, live effective status in the DTO). */
export async function listOwn(instanceId: string) {
  const rows = await repository.listForInstance(instanceId);
  return rows.map(toPlanOrderDTO);
}

/**
 * The admin PATCH flow: confirm a receipt ({ action: "paid" }) or cancel
 * ({ action: "cancelled" }). Unknown ids are the legacy 404 with the
 * ORDER_NOT_FOUND code. Confirming is the ACTIVATION event — the response
 * carries BOTH the order DTO and the freshly-activated instance DTO.
 */
export async function confirmOrCancel(
  orderId: string,
  action: "paid" | "cancelled",
  actor: AdminActor
) {
  const ref = await repository.findInstanceRef(orderId);
  if (!ref) {
    throw new HttpError(404, "Order not found", "ORDER_NOT_FOUND");
  }

  const result = action === "paid" ? await confirmPlanOrderPaid(orderId) : await cancelPlanOrder(orderId);
  if (!result.ok) {
    throw new HttpError(result.status, result.error, result.code);
  }

  /* ROUND 168 (مكافأة الترحيب) — the paid-order trigger: when the console
   * confirms a plan payment AND the welcome bonus is enabled, the one-shot
   * gift credit + bilingual message fire for the workspace (reference
   * dedupe inside the credit transaction — never twice, never fails the
   * activation). */
  if (action === "paid") {
    await deliverWelcomeBonusOnPaidOrder({ instanceId: result.instance.id });
  }

  await logAudit({
    actorType: "admin",
    actorId: actor.id,
    actorName: actor.name,
    action: action === "paid" ? "instance.planActivate" : "instance.planOrderCancel",
    targetLabel: `${result.order.package.nameEn} · ${result.order.reference}`,
    meta: {
      instance: result.instance.id,
      cycle: result.order.cycle,
      method: result.order.method,
      amount: String(result.order.amount),
      currency: result.order.currency,
      ...(action === "paid" ? { activated: "true" } : { by: "admin" }),
    },
  });

  return {
    order: toPlanOrderDTO(result.order),
    instance: toInstanceDTO(result.instance),
  };
}

/**
 * The tenant POST flow: mint a payment request for the workspace. The
 * instance must be LIVE (trashed workspaces never mint orders — the
 * session guard already rejects them; this is the defense in depth).
 * Returns the order DTO plus the server-built payment instructions.
 */
export async function createOwn(instanceId: string, input: CreateOrderInput, principal: TenantPrincipal) {
  const instance = await repository.findLiveInstance(instanceId);
  if (!instance) {
    throw new HttpError(404, "Instance not found");
  }

  /* ROUND 167 — CUSTOM-PRICING protection: a customPricing package (the
   * Enterprise tier) carries NO purchasable amount — checkout against it
   * fails cleanly BEFORE any order row is minted. Add-on orders are NOT
   * affected (they price the add-on catalog, never the package row). */
  const pkg = await db.package.findUnique({
    where: { id: input.packageId },
    select: { customPricing: true },
  });
  if (pkg?.customPricing) {
    throw new HttpError(
      400,
      "This plan has custom pricing — request an enterprise quote instead",
      "CUSTOM_PRICING"
    );
  }

  const result = await createPlanOrder(
    instance,
    input.packageId,
    input.cycle,
    input.payWith === "wallet" ? WALLET_CHECKOUT_METHOD_ID : input.methodId
  );
  if (!result.ok) {
    throw new HttpError(result.status, result.error, result.code);
  }

  /* ------------------ ROUND 141 — the INSTANT wallet checkout ------------------
   * Debit the wallet (CAS, fails closed on INSUFFICIENT_FUNDS — the pending
   * order is cancelled cleanly), then confirm + activate. When the
   * confirmation itself fails after a successful debit, the debit is
   * REFUNDED (the compensating ledger row) and the order cancelled — money
   * never vanishes into a half-finished purchase.
   * ROUND 166 (minor units) — PlanOrder.amount is ALREADY integer minor
   * units (the money.ts contract), so the wallet is debited the order's
   * own amount directly — NO toMinorUnits conversion (double conversion
   * would 100× overcharge). */
  if (input.payWith === "wallet") {
    const amountMinor = result.order.amount;
    const pay = await payOrderFromWallet({
      instanceId: instance.id,
      amountMinor,
      linkId: result.order.id,
      reference: result.order.reference,
      note: `الخطة: ${result.order.package.nameAr} (${result.order.cycle === "yearly" ? "سنوي" : "شهري"})`,
    });
    if (!pay.ok) {
      await cancelPlanOrder(result.order.id);
      throw new HttpError(pay.status, pay.error, pay.code);
    }
    const confirm = await confirmPlanOrderPaid(result.order.id);
    /* ROUND 162 — the ORDER_NOT_PENDING→paid race: when a concurrent admin
     * confirm wins the status flip between our debit and our confirm, the
     * debit has already bought the activated plan — refunding here would
     * hand the plan out for free. Only compensate when the order did NOT
     * end up paid; the raced-paid case falls through to the success tail
     * with the re-read rows. */
    let paidOrder = confirm.ok ? confirm.order : null;
    let paidInstance = confirm.ok ? confirm.instance : null;
    if (!confirm.ok) {
      const raced =
        confirm.code === "ORDER_NOT_PENDING"
          ? await repository.findPaidOrderWithInstance(result.order.id)
          : null;
      if (raced) {
        paidOrder = raced.order;
        paidInstance = raced.instance;
      } else {
        await refundWalletDebit({
          instanceId: instance.id,
          amountMinor,
          linkId: result.order.id,
          reference: result.order.reference,
          note: "استرداد تلقائي — تعذر تفعيل الطلب",
        });
        await cancelPlanOrder(result.order.id);
        throw new HttpError(confirm.status, confirm.error, confirm.code);
      }
    }
    if (!paidOrder || !paidInstance) {
      /* unreachable structurally (both arms assign real rows or throw) —
       * kept for the type system and as defense in depth */
      throw new HttpError(500, "Order confirmation failed");
    }
    /* ROUND 168 (مكافأة الترحيب) — the wallet checkout's paid-order trigger
     * (the raced-paid arm lands here too: the order DID end up paid, so the
     * one-shot bonus law applies exactly like the direct confirmation). */
    await deliverWelcomeBonusOnPaidOrder({ instanceId: instance.id });
    /* ROUND 141 (owner notifications) — the instant wallet payment rides
     * the workspace activity feed (zero-delay bell). */
    await db.activity.create({
      data: {
        instanceId: instance.id,
        kind: "actWalletDebit",
        metaJson: JSON.stringify({
          amount: amountMinor / 100,
          plan: paidOrder.package.nameAr,
          cycle: paidOrder.cycle,
        }),
      },
    });
    await logAudit({
      actorType: principal.kind === "admin" ? "admin" : "instance",
      actorId: principal.actorId,
      actorName: maskEmail(principal.actorName),
      action: "instance.planOrderCreate",
      targetLabel: `${paidOrder.package.nameEn} · ${paidOrder.reference}`,
      meta: {
        cycle: paidOrder.cycle,
        method: "wallet",
        methodLabel: "محفظة Ashrilogic",
        amount: String(paidOrder.amount),
        currency: paidOrder.currency,
        walletPaid: "instant",
        activated: "true",
      },
    });
    return {
      order: toPlanOrderDTO(paidOrder),
      instance: toInstanceDTO(paidInstance),
      walletPaid: true as const,
      balanceAfterMinor: pay.balanceAfterMinor,
    };
  }

  const payments = await readPaymentsSettings();
  const method = findPaymentMethod(payments, result.order.methodId || input.methodId);
  if (!method) {
    /* the historical post-create inconsistency envelope (kept verbatim:
       the order EXISTS but its method vanished from the console list) */
    throw new HttpError(500, "Payment method not found");
  }
  const instructions = buildInstructions(method, result.order.reference, payments);

  await logAudit({
    actorType: principal.kind === "admin" ? "admin" : "instance",
    actorId: principal.actorId,
    actorName: maskEmail(principal.actorName),
    action: "instance.planOrderCreate",
    targetLabel: `${result.order.package.nameEn} · ${result.order.reference}`,
    meta: {
      cycle: result.order.cycle,
      method: result.order.method,
      methodLabel: result.order.methodLabel,
      amount: String(result.order.amount),
      currency: result.order.currency,
    },
  });

  return { order: toPlanOrderDTO(result.order), instructions };
}

/**
 * The tenant PATCH flow: cancel the workspace's OWN pending request.
 * Ownership is proven by cross-checking the orderId against the
 * session-bound instance (cross-tenant ids are plain 404s — no code, the
 * legacy shape). The HMAC integrity re-verification lives inside the
 * transition core (409 ORDER_INTEGRITY on a tampered row).
 */
export async function cancelOwn(
  instanceId: string,
  orderId: string,
  principal: TenantPrincipal
) {
  const ref = await repository.findOrderInstanceRef(orderId);
  if (!ref || ref.instanceId !== instanceId) {
    throw new HttpError(404, "Order not found");
  }

  const result = await cancelPlanOrder(orderId);
  if (!result.ok) {
    throw new HttpError(result.status, result.error, result.code);
  }

  await logAudit({
    actorType: principal.kind === "admin" ? "admin" : "instance",
    actorId: principal.actorId,
    actorName: maskEmail(principal.actorName),
    action: "instance.planOrderCancel",
    targetLabel: `${result.order.package.nameEn} · ${result.order.reference}`,
    meta: { by: "tenant" },
  });

  return toPlanOrderDTO(result.order);
}
