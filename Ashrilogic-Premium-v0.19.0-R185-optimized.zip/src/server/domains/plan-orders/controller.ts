import { NextResponse } from "next/server";
import { routeHandler, ctxAdmin, ctxTenant } from "@/lib/server/route";
import { planOrderCreateSchema } from "@/lib/server/plan-orders";
import * as service from "./service";

/**
 * Ashrilogic — plan-orders domain CONTROLLER (ROUND 125; ROUND 127 — the
 * guards are now DECLARATIVE).
 *
 * The HTTP seam for the billing/activation surface. Every handler is a
 * routeHandler(...) (ROUND 124's unified wrapper: correlation ids, the 500
 * envelope with the route's own verb phrase, redacted structured telemetry).
 *
 * ROUND 127 — the guard sequences are declared in the wrapper config and
 * the wrapper translates each stage into the REAL guard call, preserving
 * the historical sequences byte-for-byte (including their asymmetries):
 *  - admin listing: requireAdmin() with NO req — no origin/2FA gate on
 *    reads, any authenticated admin;
 *  - admin PATCH: originViolation(req) FIRST (the origin stage), then
 *    requireAdmin() with NO req (the admin stage without withRequest — so
 *    NO 2FA-policy gate, the historical posture), then the MANUAL role
 *    check with the ADMIN_FORBIDDEN_ROLE code (the manualRoles stage —
 *    requireAdmin's built-in denial does NOT carry the code), then the
 *    confirmation throttle (keyed by admin id + IP, so the key builder
 *    uses parts.adminId()). The 429 keeps its tooManyRequests headers
 *    (Retry-After, X-RateLimit-*) — rendered by the throttle stage;
 *  - tenant listing: requireInstanceAccess(id, undefined, billing.manage)
 *    — no origin check on reads (the tenant stage without withRequest);
 *  - tenant create/cancel: requireInstanceAccess(id, req, billing.manage)
 *    — origin-checked mutations (the tenant stage with withRequest).
 */

/** Confirmation throttle: 20 confirmations / 10 min per admin + IP. */
const CONFIRM_RULE = { limit: 20, windowMs: 10 * 60 * 1000 };
/** Plan-order creation throttle: 5 requests / 10 min per workspace + IP. */
const ORDER_RULE = { limit: 5, windowMs: 10 * 60 * 1000 };

/** Segment shape for the [id] routes (Next 16: params is a Promise). */
interface InstanceSegment {
  params: Promise<{ id: string }>;
}
interface OrderSegment {
  params: Promise<{ id: string; orderId: string }>;
}

/** GET /api/admin/plan-orders — the console's activation-requests queue. */
export const adminList = routeHandler(
  "list plan orders",
  { admin: {} },
  async (ctx): Promise<NextResponse> => {
    const raw = new URL(ctx.req.url).searchParams.get("status");
    const status =
      raw === "pending" || raw === "paid" || raw === "cancelled" ? raw : undefined;
    const orders = await service.listConsole(status);
    return NextResponse.json(orders);
  }
);

/** PATCH /api/admin/plan-orders/[id] — confirm receipt / cancel request. */
export const adminConfirmOrCancel = routeHandler(
  "update plan order",
  {
    origin: true,
    admin: {
      manualRoles: {
        roles: ["super", "admin"],
        denied: {
          error: "This action requires one of: super, admin",
          code: "ADMIN_FORBIDDEN_ROLE",
        },
      },
    },
    rateLimit: {
      key: (parts) => `plan-confirm:${parts.adminId()}:${parts.ip}`,
      rule: CONFIRM_RULE,
      body: { error: "Too many confirmations — try again shortly", code: "RATE_LIMITED" },
    },
  },
  async (ctx, segment: InstanceSegment): Promise<NextResponse> => {
    const admin = ctxAdmin(ctx);
    const { id } = await segment.params;

    const body = (await ctx.readBody()) as { action?: unknown };
    const action = body?.action;
    if (action !== "paid" && action !== "cancelled") {
      return NextResponse.json(
        { error: 'action must be "paid" or "cancelled"' },
        { status: 400 }
      );
    }

    const result = await service.confirmOrCancel(id, action, {
      id: admin.id,
      name: admin.name,
    });
    return NextResponse.json(result);
  }
);

/** GET /api/instances/[id]/plan-orders — the workspace's own history. */
export const tenantList = routeHandler(
  "list plan orders",
  { tenant: { permission: "billing.manage" } },
  async (_ctx, segment: InstanceSegment): Promise<NextResponse> => {
    const { id } = await segment.params;
    const orders = await service.listOwn(id);
    return NextResponse.json(orders);
  }
);

/** POST /api/instances/[id]/plan-orders — create a payment request. */
export const tenantCreate = routeHandler(
  "create plan order",
  {
    tenant: { permission: "billing.manage", withRequest: true },
    rateLimit: {
      key: (parts) => `plan-order:${parts.params.id}:${parts.ip}`,
      rule: ORDER_RULE,
      body: { error: "Too many activation requests — try again shortly", code: "RATE_LIMITED" },
    },
  },
  async (ctx, segment: InstanceSegment): Promise<NextResponse> => {
    const { id } = await segment.params;
    const guard = ctxTenant(ctx);

    const input = await ctx.parseBody(planOrderCreateSchema);

    const result = await service.createOwn(
      id,
      {
        packageId: input.packageId,
        cycle: input.cycle,
        methodId: input.methodId,
        ...(input.payWith ? { payWith: input.payWith } : {}),
      },
      {
        kind: guard.principal.kind,
        actorId: guard.principal.actorId,
        actorName: guard.principal.actorName,
      }
    );
    return NextResponse.json(result, { status: 201 });
  }
);

/** PATCH /api/instances/[id]/plan-orders/[orderId] — cancel own request. */
export const tenantCancel = routeHandler(
  "update plan order",
  { tenant: { permission: "billing.manage", withRequest: true } },
  async (ctx, segment: OrderSegment): Promise<NextResponse> => {
    const { id, orderId } = await segment.params;
    const guard = ctxTenant(ctx);

    const body = (await ctx.readBody()) as { action?: unknown };
    const action = body?.action;
    if (action !== "cancel") {
      return NextResponse.json({ error: 'Only { action: "cancel" } is supported' }, { status: 400 });
    }

    const order = await service.cancelOwn(id, orderId, {
      kind: guard.principal.kind,
      actorId: guard.principal.actorId,
      actorName: guard.principal.actorName,
    });
    return NextResponse.json(order);
  }
);
