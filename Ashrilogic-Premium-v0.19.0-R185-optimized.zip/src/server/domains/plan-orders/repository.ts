import type { Instance, Package, PlanOrder } from "@prisma/client";
import { db } from "@/lib/db";

/**
 * Ashrilogic — plan-orders domain REPOSITORY (ROUND 125).
 *
 * The persistence seam of the second route→controller→service→repository
 * decomposition (after packages, ROUND 124): every Prisma lookup the four
 * plan-order route handlers previously inlined lives here and nowhere else.
 * The transition core (createPlanOrder / confirmPlanOrderPaid /
 * cancelPlanOrder — the HMAC-sealed state machine in
 * src/lib/server/plan-orders.ts) keeps its OWN Prisma usage: it is the
 * shared domain core, imported by admin-mapper and the plan-methods route
 * as well; this repository owns the route-level lookups around it.
 *
 * Behavior is lifted VERBATIM from the legacy handlers — the exact
 * `include` shapes, the exact ordering, the exact caps.
 */

/** Console listing cap (GET /api/admin/plan-orders). */
export const CONSOLE_LIST_CAP = 300;
/** Own-order history cap per response (GET /api/instances/[id]/plan-orders). */
export const OWN_LIST_CAP = 50;

type PlanOrderWithPackage = PlanOrder & { package: Package };

/** Console shape: order + package + the owning instance's identity trio. */
export type ConsoleOrderRow = PlanOrder & {
  package: Package;
  instance: { id: string; systemId: string; orgJson: string } | null;
};

/** Admin console listing, newest first, optional status filter. */
export async function listForConsole(status?: "pending" | "paid" | "cancelled"): Promise<ConsoleOrderRow[]> {
  return db.planOrder.findMany({
    where: status ? { status } : undefined,
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    take: CONSOLE_LIST_CAP,
    include: {
      package: true,
      instance: { select: { id: true, systemId: true, orgJson: true } },
    },
  });
}

/** Tenant's own history, newest first, package joined for DTO rendering. */
export async function listForInstance(instanceId: string): Promise<PlanOrderWithPackage[]> {
  return db.planOrder.findMany({
    where: { instanceId },
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    take: OWN_LIST_CAP,
    include: { package: true },
  });
}

/** The owning-workspace probe for the admin PATCH's 404 policy. */
export async function findInstanceRef(
  orderId: string
): Promise<Pick<PlanOrder, "instanceId"> | null> {
  return db.planOrder.findUnique({ where: { id: orderId }, select: { instanceId: true } });
}

/**
 * The ownership cross-check for the tenant cancel path: the order's
 * instanceId must EQUAL the session-bound instance id (cross-tenant ids
 * are 404s, never actionable).
 */
export async function findOrderInstanceRef(
  orderId: string
): Promise<Pick<PlanOrder, "instanceId"> | null> {
  return db.planOrder.findUnique({ where: { id: orderId }, select: { instanceId: true } });
}

/** Live (non-trashed) workspace probe for the tenant create path
 * (ROUND 87 — trashed workspaces never mint plan orders). */
export async function findLiveInstance(id: string): Promise<Instance | null> {
  return db.instance.findUnique({ where: { id, deletedAt: null } });
}

/** ROUND 162 — the wallet-checkout race probe: when the instant checkout's
 *  confirm loses the status flip to a concurrent admin confirm
 *  (ORDER_NOT_PENDING), the saga re-reads the terminal rows to decide
 *  between compensating (refund + cancel) and accepting the raced PAID
 *  outcome (the debit already bought the activated plan — refunding it
 *  would hand the plan out for free). */
export async function findPaidOrderWithInstance(
  orderId: string
): Promise<
  | { order: PlanOrderWithPackage; instance: Instance & { package: Package | null } }
  | null
> {
  const order = await db.planOrder.findUnique({
    where: { id: orderId },
    include: { package: true },
  });
  if (!order || order.status !== "paid") return null;
  const instance = await db.instance.findUnique({
    where: { id: order.instanceId },
    include: { package: true },
  });
  return instance ? { order, instance } : null;
}
