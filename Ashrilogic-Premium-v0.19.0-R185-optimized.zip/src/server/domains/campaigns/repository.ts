import { db } from "@/lib/db";
import type { NewsletterCampaign } from "@prisma/client";

/**
 * Ashrilogic — campaigns domain REPOSITORY (ROUND 165).
 *
 * The ONLY Prisma touchpoint of the newsletter-campaign domain. Every
 * query the service needs is declared here — the service never imports
 * the client. Shapes follow the domain-repository conventions of the
 * sibling domains (bounded takes, explicit selects, CAS transitions).
 */

/** The audience statuses a campaign delivers to (the historical filter). */
export const AUDIENCE_STATUSES = ["active", "restricted"] as const;

/** The campaign message families (ROUND 167 tenant messaging console). */
export const CAMPAIGN_KINDS = ["welcome", "offer", "discount", "update", "broadcast"] as const;
export type CampaignKind = (typeof CAMPAIGN_KINDS)[number];

/** The audience selector forms the console sends (the storage form for the
 *  plan variant is `tenants:plan:<packageId>`). */
export const AUDIENCE_TARGETS = ["subscribers", "tenants", "tenants:plan"] as const;
export type AudienceTarget = (typeof AUDIENCE_TARGETS)[number];

/** A stored audience string, parsed ("subscribers" | "tenants" | the plan
 *  variant carrying its packageId). */
export interface ParsedAudience {
  kind: "subscribers" | "tenants";
  packageId: string | null;
}

/** Parse a stored audience column ("subscribers" | "tenants" |
 * "tenants:plan:<packageId>") — null on an unrecognized shape. */
export function parseCampaignAudience(raw: string): ParsedAudience | null {
  if (raw === "subscribers") return { kind: "subscribers", packageId: null };
  if (raw === "tenants") return { kind: "tenants", packageId: null };
  if (raw.startsWith("tenants:plan:")) {
    const packageId = raw.slice("tenants:plan:".length);
    return packageId.length > 0 ? { kind: "tenants", packageId } : null;
  }
  return null;
}

export type CampaignRow = NewsletterCampaign;

/** The client DTO shape (byte-compatible superset of the historical route
 * DTO — ROUND 167 adds the segmentation + dispatch-evidence fields). */
export interface CampaignDTO {
  id: string;
  subject: string;
  body: string;
  status: string;
  /** "subscribers" | "tenants" | "tenants:plan:<packageId>" (ROUND 167). */
  audience: string;
  /** "welcome" | "offer" | "discount" | "update" | "broadcast" (ROUND 167). */
  kind: string;
  /** audience snapshot at claim time (0 for drafts) */
  recipients: number;
  /** per-recipient rows actually enqueued (invalid/undecryptable skipped). */
  dispatchEnqueued: number;
  /** terminal delivery counts stamped by the completion gate. */
  delivered: number;
  failed: number;
  sentFrom: string | null;
  sentAt: string | null;
  createdAt: string;
  updatedAt: string;
}

/** Serialize one row (the field set the admin console consumes). */
export function toCampaignDTO(row: CampaignRow): CampaignDTO {
  return {
    id: row.id,
    subject: row.subject,
    body: row.body,
    status: row.status,
    audience: row.audience,
    kind: row.kind,
    recipients: row.recipients,
    dispatchEnqueued: row.dispatchEnqueued,
    delivered: row.delivered,
    failed: row.failed,
    sentFrom: row.sentFrom,
    sentAt: row.sentAt ? row.sentAt.toISOString() : null,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

/** The campaign archive (latest first, capped — the console's list view). */
export async function listCampaigns(take = 50): Promise<CampaignRow[]> {
  return db.newsletterCampaign.findMany({ orderBy: { createdAt: "desc" }, take });
}

/** Audience estimate for drafts: active + restricted subscribers (the
 * legacy default — the newsletter list) or the live-instance audience of
 * a tenant campaign ("tenants" = every live workspace, "tenants:plan:<id>"
 * = owners whose CURRENT package matches). An unrecognized audience
 * string falls back to the legacy subscriber count. */
export async function countAudience(audience: string = "subscribers"): Promise<number> {
  const parsed = parseCampaignAudience(audience);
  if (parsed?.kind === "tenants") {
    return db.instance.count({
      where: {
        deletedAt: null,
        ...(parsed.packageId ? { packageId: parsed.packageId } : {}),
      },
    });
  }
  return db.subscriber.count({ where: { status: { in: [...AUDIENCE_STATUSES] } } });
}

/** The target package row for audience validation + labels (null when the
 * id matches no live package — the composer's plan picker source). */
export async function findPackageLabel(
  packageId: string
): Promise<{ id: string; nameAr: string; nameEn: string } | null> {
  const row = await db.package.findUnique({
    where: { id: packageId },
    select: { id: true, nameAr: true, nameEn: true },
  });
  return row ?? null;
}

export async function findCampaign(id: string): Promise<CampaignRow | null> {
  return db.newsletterCampaign.findUnique({ where: { id } });
}

export async function createCampaign(
  data: Pick<CampaignRow, "subject" | "body"> &
    Partial<Pick<CampaignRow, "audience" | "kind">>
): Promise<CampaignRow> {
  return db.newsletterCampaign.create({ data });
}

export async function updateDraft(
  id: string,
  data: Pick<CampaignRow, "subject" | "body"> &
    Partial<Pick<CampaignRow, "audience" | "kind">>
): Promise<CampaignRow> {
  return db.newsletterCampaign.update({ where: { id }, data });
}

export async function deleteCampaign(id: string): Promise<void> {
  await db.newsletterCampaign.delete({ where: { id } });
}

/**
 * THE CLAIM (draft → sending) — a conditional update so exactly ONE
 * concurrent send can ever transition the row; the loser observes
 * count = 0 and reports the 409. Delivery never runs inside the HTTP
 * request that claims (the dispatcher owns it from here).
 */
export async function claimDraft(
  id: string,
  claim: { recipients: number; sentFrom: string | null }
): Promise<number> {
  const result = await db.newsletterCampaign.updateMany({
    where: { id, status: "draft" },
    data: {
      status: "sending",
      recipients: claim.recipients,
      sentFrom: claim.sentFrom,
      dispatchCursor: null,
      dispatchEnqueueDone: false,
      dispatchEnqueued: 0,
      delivered: 0,
      failed: 0,
    },
  });
  return result.count;
}

/* ------------------------- the dispatch driver ------------------------- */

/** Campaigns currently dispatching (bounded per tick). */
export async function findDispatching(take: number): Promise<CampaignRow[]> {
  return db.newsletterCampaign.findMany({
    where: { status: "sending" },
    orderBy: { updatedAt: "asc" },
    take,
  });
}

/** The per-package label projection joined onto each tenant audience row
 * (the CURRENT package of the instance — name + price for token vars). */
export interface AudiencePackageLabel {
  nameAr: string;
  nameEn: string;
  priceMonthly: number;
  currency: string;
}

/**
 * One resolved audience member — the SOURCE shape per audience family;
 * decryption (sealed email / sealed adminJson email) and template-token
 * resolution happen in the SERVICE at enqueue time (this repository never
 * imports the crypto vault, the ROUND 165 separation):
 *  - subscribers: `identity` = the SEALED Subscriber.email envelope,
 *    orgJson = "", pkg = null (no tenant context → tokens stay literal);
 *  - tenants: `identity` = the raw Instance.adminJson blob (the owner's
 *    email sealed inside), orgJson = the raw org blob, pkg = the joined
 *    CURRENT package row (null when the workspace has none).
 */
export interface AudienceMemberRow {
  /** the recipient identity — subscriber id OR instance id (the idempotency
   * key tail campaign:<campaignId>:<rowId>). */
  id: string;
  identity: string;
  orgJson: string;
  pkg: AudiencePackageLabel | null;
}

/** The tenant-audience where shape (live instances, package-matched). */
function tenantAudienceWhere(packageId: string | null) {
  return {
    deletedAt: null,
    ...(packageId ? { packageId } : {}),
  };
}

/**
 * The next cursor page of audience members — keyset pagination on the
 * primary key (id > cursor), NEVER an offset/limit window: the full
 * audience is enumerated across ticks with no silent truncation at any
 * list size. `take + 1` is fetched so exhaustion is detectable without a
 * separate count. An unrecognized audience string degrades to the legacy
 * subscriber enumeration (the column default).
 */
export async function listAudienceFromCursor(
  audience: string,
  cursor: string | null,
  take: number
): Promise<AudienceMemberRow[]> {
  const parsed = parseCampaignAudience(audience);
  if (parsed?.kind === "tenants") {
    const rows = await db.instance.findMany({
      where: {
        ...tenantAudienceWhere(parsed.packageId),
        ...(cursor !== null ? { id: { gt: cursor } } : {}),
      },
      orderBy: { id: "asc" },
      take: take + 1,
      select: {
        id: true,
        adminJson: true,
        orgJson: true,
        package: { select: { nameAr: true, nameEn: true, priceMonthly: true, currency: true } },
      },
    });
    return rows.map((row) => ({
      id: row.id,
      identity: row.adminJson,
      orgJson: row.orgJson,
      pkg: row.package,
    }));
  }
  const rows = await db.subscriber.findMany({
    where: {
      status: { in: [...AUDIENCE_STATUSES] },
      ...(cursor !== null ? { id: { gt: cursor } } : {}),
    },
    orderBy: { id: "asc" },
    take: take + 1,
    select: { id: true, email: true },
  });
  return rows.map((row) => ({ id: row.id, identity: row.email, orgJson: "", pkg: null }));
}

/** Persist the enqueue-phase progress (cursor + completion marker). */
export async function markEnqueueProgress(
  id: string,
  data: { dispatchCursor: string | null; dispatchEnqueueDone: boolean; dispatchEnqueued?: number }
): Promise<void> {
  await db.newsletterCampaign.update({ where: { id }, data });
}

/** The campaign's pending per-recipient rows (the delivery work queue). */
export async function listPendingDeliveryRows(
  campaignId: string,
  take: number
): Promise<{ id: string; attempts: number }[]> {
  return db.emailLog.findMany({
    where: {
      type: "campaign",
      status: "pending",
      idempotencyKey: { startsWith: `campaign:${campaignId}:` },
    },
    orderBy: { createdAt: "asc" },
    take,
    select: { id: true, attempts: true },
  });
}

/** Terminal outcome counts for the campaign's per-recipient ledger. */
export async function countDeliveryOutcomes(
  campaignId: string
): Promise<{ pending: number; sent: number; failed: number; skipped: number; enqueued: number }> {
  const keyPrefix = `campaign:${campaignId}:`;
  const groups = await db.emailLog.groupBy({
    by: ["status"],
    where: { type: "campaign", idempotencyKey: { startsWith: keyPrefix } },
    _count: { _all: true },
  });
  const byStatus = new Map(groups.map((g) => [g.status, g._count._all]));
  const enqueued = groups.reduce((sum, g) => sum + g._count._all, 0);
  return {
    enqueued,
    pending: byStatus.get("pending") ?? 0,
    sent: byStatus.get("sent") ?? 0,
    failed: byStatus.get("failed") ?? 0,
    skipped: byStatus.get("skipped") ?? 0,
  };
}

/** THE COMPLETION STAMP — sending → sent, only when no delivery is pending. */
export async function finalizeDispatch(
  id: string,
  data: { delivered: number; failed: number }
): Promise<number> {
  const result = await db.newsletterCampaign.updateMany({
    where: { id, status: "sending" },
    data: { status: "sent", sentAt: new Date(), delivered: data.delivered, failed: data.failed },
  });
  return result.count;
}

/** Settle one exhausted per-recipient row as failed (the dead-letter
 *  terminal state — CAS-guarded so a concurrent settle is a no-op). */
export async function deadLetterDeliveryRow(rowId: string): Promise<void> {
  await db.emailLog.update({
    where: { id: rowId, status: "pending" },
    data: {
      status: "failed",
      error: "exhausted after max delivery attempts (dead-letter)",
      failedAt: new Date(),
      bodyJson: null,
    },
  });
}

/** The platform's newsletter sending addresses (labels for the snapshot). */
export async function sendingAddresses(): Promise<string> {
  const row = await db.platformSetting.findUnique({ where: { id: "global" } });
  if (!row?.newsletterEmailsJson) return "";
  try {
    const list = JSON.parse(row.newsletterEmailsJson) as { email?: string }[];
    const emails = (Array.isArray(list) ? list : [])
      .map((e) => (typeof e.email === "string" ? e.email.trim() : ""))
      .filter((e) => e.length > 0);
    return emails.slice(0, 3).join(", ");
  } catch {
    return "";
  }
}
