import { logAudit } from "@/lib/server/audit";
import { opLog } from "@/lib/server/oplog";
import { withJobLease } from "@/lib/server/job-lease";
import { decryptField } from "@/lib/server/crypto-vault";
import { readAdminEmail } from "@/lib/server/instance-mapper";
import { toDisplayUnits } from "@/lib/server/money";
import {
  renderCampaignHtml,
  renderCampaignText,
  enqueueOutboxMail,
  deliverPendingOutboxRow,
} from "@/lib/server/mail";
import { HttpError } from "@/lib/server/route";
import * as repo from "./repository";
import type { CampaignRow } from "./repository";

/**
 * Ashrilogic — campaigns domain SERVICE (ROUND 165).
 *
 * THE CORRECTNESS FIX this domain owns: the historical send path counted
 * the whole audience (subscriber.count()) but delivered to findMany({
 * take: 5000 }) — a silent truncation above 5,000 subscribers — and it
 * ran the entire bulk delivery INSIDE the HTTP request, stamping the
 * campaign "sent" before any delivery outcome existed.
 *
 * THE DURABLE DISPATCH LIFECYCLE (all state is database rows — a crashed
 * process at ANY point loses nothing; every step is idempotent):
 *
 *   PATCH { action:"send" }     → CLAIM: draft → "sending" (CAS — one
 *                                 concurrent sender wins, the loser 409s).
 *                                 NO delivery happens in the request.
 *   dispatcher tick (60s,       → ENQUEUE: keyset-cursor pages of the
 *   under SchedulerLease)          audience become PENDING EmailLog rows
 *                                   (idempotency key campaign:<id>:<subId>,
 *                                   stable Message-ID, full envelope). The
 *                                   cursor advances per batch — ANY list
 *                                   size, no truncation, crash-resume.
 *                                → DELIVER: bounded batches of pending rows
 *                                   driven in place through the mail
 *                                   service's retry/backoff pipeline; a
 *                                   row that keeps failing dead-letters
 *                                   after MAX_DELIVERY_ATTEMPTS.
 *                                → COMPLETE: when the enqueue has exhausted
 *                                   the audience AND zero rows are pending,
 *                                   the campaign is stamped "sent" with
 *                                   per-recipient delivered/failed counts
 *                                   and an audit row. Until then it is
 *                                   honestly "sending" — never "sent".
 *
 * The per-recipient ledger IS EmailLog (type "campaign") — retries,
 * dead-letters, at-least-once semantics with stable Message-IDs, and the
 * admin mail trail all come from the existing mail architecture.
 */

/* ----------------------------- tuning ----------------------------- */

/** subscribers enqueued per tick (cheap row writes) */
const ENQUEUE_BATCH = 500;
/** pending rows delivered per tick (real transport work) */
const DELIVERY_BATCH = 100;
/** campaigns driven per tick (fan-in bound) */
const CAMPAIGNS_PER_TICK = 5;
/** dispatcher cadence */
const TICK_MS = 60 * 1000;
/** lease TTL — long enough for one delivery batch, renewed while running */
const LEASE_TTL_MS = 5 * 60 * 1000;
/** total delivery attempts (inline retries count as one attempt here)
 * before a per-recipient row dead-letters */
const MAX_DELIVERY_ATTEMPTS = 5;

export { toCampaignDTO } from "./repository";
export type { CampaignDTO } from "./repository";
export {
  CAMPAIGN_KINDS,
  AUDIENCE_TARGETS,
  parseCampaignAudience,
} from "./repository";
export type { CampaignKind, AudienceTarget } from "./repository";

/** Who performed an admin action (audit actor). */
export interface CampaignActor {
  id: string;
  username: string;
}

/** The composer input — the audience/kind segmentation (ROUND 167) rides
 * the same create/update shapes; both default to the legacy broadcast to
 * the newsletter list so every historical caller keeps its behavior. */
export interface CampaignDraftInput {
  subject: string;
  body: string;
  /** "subscribers" | "tenants" | "tenants:plan:<packageId>". */
  audience?: string;
  /** "welcome" | "offer" | "discount" | "update" | "broadcast". */
  kind?: string;
}

/* ------------------------- template tokens ------------------------- */

/** The per-recipient template tokens the composer injects — substituted at
 * ENQUEUE time from the recipient's own row (ROUND 167 tenant messaging).
 * Anything else (or a var the row cannot resolve) stays LITERAL. */
const TOKEN_RE = /\{\{\s*(name|org|plan|amount)\s*\}\}/g;

/** Replace every recognized {{token}} with the recipient's value — unknown
 * tokens (and tokens with no resolved value) are left literal. */
export function substituteCampaignTokens(
  text: string,
  vars: Record<string, string>
): string {
  return text.replace(TOKEN_RE, (match, token: string) => vars[token] ?? match);
}

/** Read one JSON string field (never throws — "" on any corrupt shape). */
function jsonStringField(raw: string, field: string): string {
  try {
    const parsed = JSON.parse(raw || "{}") as Record<string, unknown>;
    const value = parsed[field];
    return typeof value === "string" && value.trim() ? value.trim() : "";
  } catch {
    return "";
  }
}

/** The tenant recipient's token vars — the owner name (adminJson), the org
 * display name (orgJson), the CURRENT package label + price. Only fields
 * that actually resolve enter the map (an unresolved var keeps the token
 * literal — the unknown-token law). */
function tenantVars(row: repo.AudienceMemberRow): Record<string, string> {
  const vars: Record<string, string> = {};
  const name = jsonStringField(row.identity, "name");
  if (name) vars.name = name;
  const org = jsonStringField(row.orgJson, "name");
  if (org) vars.org = org;
  if (row.pkg) {
    vars.plan = `${row.pkg.nameAr} · ${row.pkg.nameEn}`;
    vars.amount = `${toDisplayUnits(row.pkg.priceMonthly).toFixed(2)} ${row.pkg.currency}`;
  }
  return vars;
}

/* --------------------------- admin actions --------------------------- */

/** GET — the archive + the live audience estimate for drafts. */
export async function listCampaigns(): Promise<{
  campaigns: repo.CampaignDTO[];
  audience: number;
}> {
  const [rows, audience] = await Promise.all([repo.listCampaigns(), repo.countAudience()]);
  return { campaigns: rows.map(repo.toCampaignDTO), audience };
}

/** POST — create a draft (audited). */
export async function createDraft(
  input: CampaignDraftInput,
  actor: CampaignActor
): Promise<repo.CampaignDTO> {
  const row = await repo.createCampaign({
    subject: input.subject,
    body: input.body,
    ...(input.audience ? { audience: input.audience } : {}),
    ...(input.kind ? { kind: input.kind } : {}),
  });
  await logAudit({
    actorType: "admin",
    actorId: actor.id,
    actorName: actor.username,
    action: "campaign.create",
    targetLabel: input.subject.slice(0, 60),
    meta: {
      subject: "created",
      ...(input.audience ? { audience: input.audience } : {}),
      ...(input.kind ? { kind: input.kind } : {}),
    },
  });
  return repo.toCampaignDTO(row);
}

/** The audience-preview DTO (the segmented composer's live count — the
 * wallet-grants preview law: resolve BEFORE anything is claimed/sent). */
export interface CampaignAudiencePreviewDTO {
  /** the storage-form audience string the composer will persist. */
  audience: string;
  /** the exact population a claim would snapshot + the dispatcher walks. */
  count: number;
  /** bilingual package label when the target is a plan (null otherwise). */
  packageName: string | null;
}

/** Resolve + VALIDATE the composer's audience selection into the
 * storage-form audience string (400 when the plan variant carries no
 * packageId, 404 on an id matching no live package row). */
export async function resolveAudience(
  target: repo.AudienceTarget,
  packageId?: string
): Promise<string> {
  if (target === "tenants:plan") {
    if (!packageId) {
      throw new HttpError(400, "packageId is required when target is \"tenants:plan\"", "CAMPAIGN_PACKAGE_REQUIRED");
    }
    const pkg = await repo.findPackageLabel(packageId);
    if (!pkg) {
      throw new HttpError(404, "Package not found", "CAMPAIGN_PACKAGE_NOT_FOUND");
    }
    return `tenants:plan:${packageId}`;
  }
  return target;
}

/** GET preview — resolve the audience size + label for one composer target
 * ("subscribers" | "tenants" | "tenants:plan" + packageId). */
export async function audiencePreview(
  target: repo.AudienceTarget,
  packageId?: string
): Promise<CampaignAudiencePreviewDTO> {
  const audience = await resolveAudience(target, packageId);
  const [count, pkg] = await Promise.all([
    repo.countAudience(audience),
    target === "tenants:plan" && packageId ? repo.findPackageLabel(packageId) : Promise.resolve(null),
  ]);
  return {
    audience,
    count,
    packageName: pkg ? `${pkg.nameAr} · ${pkg.nameEn}` : null,
  };
}

/**
 * PATCH { action: "send" } — THE CLAIM. The draft transitions to
 * "sending" with its audience + sender snapshots; the durable dispatcher
 * owns every delivery from here. Concurrent senders: exactly one wins
 * (the CAS), the loser gets the historical 409 envelope.
 */
export async function claimCampaign(
  id: string,
  actor: CampaignActor
): Promise<repo.CampaignDTO> {
  const existing = await repo.findCampaign(id);
  if (!existing) {
    throw new HttpError(404, "Campaign not found");
  }
  if (existing.status !== "draft") {
    /* the exact historical envelope — now also guarding "sending" */
    throw new HttpError(409, "CAMPAIGN_ALREADY_SENT");
  }
  try {
    /* ROUND 167 — the snapshot resolves THIS campaign's audience (the
     * segmented tenant audiences count live instances, package-matched). */
    const [recipients, sentFrom] = await Promise.all([
      repo.countAudience(existing.audience),
      repo.sendingAddresses(),
    ]);
    const claimed = await repo.claimDraft(id, { recipients, sentFrom: sentFrom || null });
    if (claimed === 0) {
      throw new HttpError(409, "CAMPAIGN_ALREADY_SENT");
    }
    await logAudit({
      actorType: "admin",
      actorId: actor.id,
      actorName: actor.username,
      action: "campaign.send",
      targetLabel: existing.subject.slice(0, 60),
      meta: {
        status: "dispatch-started",
        recipients: String(recipients),
        from: sentFrom || "default",
        audience: existing.audience,
        kind: existing.kind,
      },
    });
    const row = await repo.findCampaign(id);
    if (!row) throw new HttpError(404, "Campaign not found");
    return repo.toCampaignDTO(row);
  } catch (error) {
    if (error instanceof HttpError) throw error;
    /* preserve the historical send-path 500 envelope verbatim */
    throw new HttpError(500, "Failed to send campaign");
  }
}

/** PATCH { subject, body } — edit a DRAFT in place (audited). */
export async function editDraft(
  id: string,
  input: CampaignDraftInput,
  actor: CampaignActor
): Promise<repo.CampaignDTO> {
  const existing = await repo.findCampaign(id);
  if (!existing) {
    throw new HttpError(404, "Campaign not found");
  }
  if (existing.status !== "draft") {
    throw new HttpError(409, "CAMPAIGN_ALREADY_SENT");
  }
  try {
    const row = await repo.updateDraft(id, {
      subject: input.subject,
      body: input.body,
      ...(input.audience ? { audience: input.audience } : {}),
      ...(input.kind ? { kind: input.kind } : {}),
    });
    await logAudit({
      actorType: "admin",
      actorId: actor.id,
      actorName: actor.username,
      action: "campaign.update",
      targetLabel: input.subject.slice(0, 60),
      meta: {
        subject: "updated",
        ...(input.audience ? { audience: input.audience } : {}),
        ...(input.kind ? { kind: input.kind } : {}),
      },
    });
    return repo.toCampaignDTO(row);
  } catch {
    throw new HttpError(500, "Failed to update campaign");
  }
}

/**
 * DELETE — remove a draft or an archived sent record. A campaign that is
 * currently "sending" refuses (its durable dispatch is mid-flight; the
 * per-recipient ledger must be allowed to settle first) — the new-state
 * lifecycle guard, not a behavior change for any historical state.
 */
export async function removeCampaign(
  id: string,
  actor: CampaignActor
): Promise<void> {
  const existing = await repo.findCampaign(id);
  if (!existing) {
    throw new HttpError(404, "Campaign not found");
  }
  if (existing.status === "sending") {
    throw new HttpError(409, "CAMPAIGN_DISPATCH_IN_PROGRESS");
  }
  try {
    await repo.deleteCampaign(id);
    await logAudit({
      actorType: "admin",
      actorId: actor.id,
      actorName: actor.username,
      action: "campaign.delete",
      targetLabel: existing.subject.slice(0, 60),
      meta: { status: existing.status, recipients: String(existing.recipients) },
    });
  } catch {
    throw new HttpError(500, "Failed to delete campaign");
  }
}

/* ------------------------- the dispatch driver ------------------------- */

/** One sweep's per-campaign outcome (observability + test assertions). */
export interface CampaignDispatchOutcome {
  campaignId: string;
  enqueued: number;
  enqueueDone: boolean;
  delivered: number;
  deadLettered: number;
  completed: boolean;
}

/** Test seams for the batch bounds (production uses the tuning above). */
export interface DispatchSweepOptions {
  enqueueBatch?: number;
  deliveryBatch?: number;
}

/** The recipient mailbox for one audience row (sealed at rest): a
 * subscriber's sealed email column, or a tenant owner's sealed-in-adminJson
 * email (the welcome-bonus readAdminEmail idiom — legacy plaintext passes
 * through, corrupt/undecryptable shapes return ""). */
function audienceAddress(row: repo.AudienceMemberRow, tenants: boolean): string {
  const raw = tenants ? readAdminEmail(row.identity) : (decryptField(row.identity) ?? "");
  return raw.trim().toLowerCase();
}

function isValidAddress(addr: string): boolean {
  return addr.length > 3 && addr.includes("@");
}

/**
 * One dispatcher pass over every "sending" campaign. Never throws — each
 * campaign's phases are individually best-effort; the next tick resumes
 * from the durable state (cursor + pending rows). Idempotent at every
 * step (claim marker, cursor, unique per-recipient rows).
 */
export async function sweepCampaignDispatch(
  options: DispatchSweepOptions = {}
): Promise<CampaignDispatchOutcome[]> {
  const enqueueBatch = options.enqueueBatch ?? ENQUEUE_BATCH;
  const deliveryBatch = options.deliveryBatch ?? DELIVERY_BATCH;
  const outcomes: CampaignDispatchOutcome[] = [];

  let campaigns: CampaignRow[];
  try {
    campaigns = await repo.findDispatching(CAMPAIGNS_PER_TICK);
  } catch {
    return outcomes; /* store hiccup — next tick retries */
  }

  for (const campaign of campaigns) {
    const outcome: CampaignDispatchOutcome = {
      campaignId: campaign.id,
      enqueued: 0,
      enqueueDone: campaign.dispatchEnqueueDone,
      delivered: 0,
      deadLettered: 0,
      completed: false,
    };
    try {
      if (!campaign.dispatchEnqueueDone) {
        await enqueuePhase(campaign, enqueueBatch, outcome);
      }
      await deliveryPhase(campaign, deliveryBatch, outcome);
      await completionGate(campaign, outcome);
    } catch (error) {
      /* one campaign's failure never blocks the others; the durable
       * state resumes it next tick */
      opLog.warn("campaign-dispatch.campaign-error", {
        campaignId: campaign.id,
        result: error instanceof Error ? error.constructor.name : "unknown",
      });
    }
    outcomes.push(outcome);
  }
  return outcomes;
}

/** Phase 1 — enqueue the next cursor page as pending EmailLog rows.
 *
 * ROUND 167 (tenant messaging): the page resolves per the campaign's
 * AUDIENCE — "subscribers" pages the newsletter list (the legacy path),
 * "tenants"/"tenants:plan:<id>" page LIVE instances (keyset, the
 * wallet-grants batch idiom) and resolve each owner's SEALED adminJson
 * email. Per recipient, the {{name}}/{{org}}/{{plan}}/{{amount}} template
 * tokens are substituted from that recipient's own row (orgJson name,
 * adminJson name, CURRENT package label + price) — unknown tokens stay
 * literal. The idempotency key stays campaign:<id>:<rowId> (the instance
 * id for tenant rows — per-workspace exactly-once). */
async function enqueuePhase(
  campaign: CampaignRow,
  batch: number,
  outcome: CampaignDispatchOutcome
): Promise<void> {
  const tenants = repo.parseCampaignAudience(campaign.audience)?.kind === "tenants";
  const page = await repo.listAudienceFromCursor(campaign.audience, campaign.dispatchCursor, batch);
  const exhausted = page.length <= batch;
  const rows = exhausted ? page : page.slice(0, batch);

  for (const row of rows) {
    const address = audienceAddress(row, tenants);
    if (!isValidAddress(address)) continue; /* undecryptable/invalid — skipped, never silently truncated */
    const vars = tenants ? tenantVars(row) : {};
    const subject = substituteCampaignTokens(campaign.subject, vars);
    const text = renderCampaignText(subject, substituteCampaignTokens(campaign.body, vars));
    const html = renderCampaignHtml(subject, substituteCampaignTokens(campaign.body, vars));
    const opened = await enqueueOutboxMail(
      { to: address, subject, text, html },
      {
        type: "campaign",
        idempotencyKey: `campaign:${campaign.id}:${row.id}`,
        ...(tenants ? { instanceId: row.id } : {}),
      }
    );
    if (typeof opened === "string") outcome.enqueued += 1; /* row id or idempotent twin */
  }

  const lastId = rows.length > 0 ? rows[rows.length - 1].id : campaign.dispatchCursor;
  if (exhausted) {
    const counts = await repo.countDeliveryOutcomes(campaign.id);
    await repo.markEnqueueProgress(campaign.id, {
      dispatchCursor: lastId,
      dispatchEnqueueDone: true,
      dispatchEnqueued: counts.enqueued,
    });
    outcome.enqueueDone = true;
    opLog.info("campaign-dispatch.enqueued", {
      campaignId: campaign.id,
      result: `enqueued ${counts.enqueued} recipients (audience snapshot ${campaign.recipients})`,
    });
  } else if (lastId !== null) {
    await repo.markEnqueueProgress(campaign.id, {
      dispatchCursor: lastId,
      dispatchEnqueueDone: false,
    });
  }
}

/** Phase 2 — drive bounded batches of pending rows to terminal states. */
async function deliveryPhase(
  campaign: CampaignRow,
  batch: number,
  outcome: CampaignDispatchOutcome
): Promise<void> {
  if (!campaign.dispatchEnqueueDone && outcome.enqueueDone) {
    /* this sweep just finished the enqueue — pick the refreshed row's
     * pending queue on the next pass through (the rows exist already) */
    campaign = (await repo.findCampaign(campaign.id)) ?? campaign;
  }
  const pending = await repo.listPendingDeliveryRows(campaign.id, batch);
  for (const row of pending) {
    if (row.attempts >= MAX_DELIVERY_ATTEMPTS) {
      /* the dead-letter settle — exceeded the retry budget */
      try {
        await repo.deadLetterDeliveryRow(row.id);
        outcome.deadLettered += 1;
      } catch {
        /* best-effort — the next tick retries the settle */
      }
      continue;
    }
    const result = await deliverPendingOutboxRow(row.id);
    if (result === "sent") outcome.delivered += 1;
  }
}

/**
 * Phase 3 — THE COMPLETION GATE. "sent" is stamped ONLY when the audience
 * enumeration is exhausted AND zero per-recipient rows are pending. The
 * completion is audited with the full outcome ledger.
 */
async function completionGate(
  campaign: CampaignRow,
  outcome: CampaignDispatchOutcome
): Promise<void> {
  const fresh = (await repo.findCampaign(campaign.id)) ?? campaign;
  if (!fresh.dispatchEnqueueDone) return;
  const counts = await repo.countDeliveryOutcomes(fresh.id);
  if (counts.pending > 0) return;

  const stamped = await repo.finalizeDispatch(fresh.id, {
    delivered: counts.sent,
    failed: counts.failed,
  });
  if (stamped > 0) {
    outcome.completed = true;
    await logAudit({
      actorType: "system",
      actorName: "dispatcher",
      action: "campaign.dispatch-completed",
      targetLabel: fresh.subject.slice(0, 60),
      meta: {
        recipients: String(fresh.recipients),
        enqueued: String(counts.enqueued),
        delivered: String(counts.sent),
        failed: String(counts.failed),
        skipped: String(counts.skipped),
      },
    });
    opLog.info("campaign-dispatch.completed", {
      campaignId: fresh.id,
      result: `delivered ${counts.sent} · failed ${counts.failed} · skipped ${counts.skipped}`,
    });
  }
}

/* --------------------------- registration --------------------------- */

const FLAG = "__ashrilogicCampaignDispatcher" as const;

interface DispatcherState {
  timer: ReturnType<typeof setInterval> | null;
  inFlight: boolean;
}

function state(): DispatcherState {
  const g = globalThis as Record<string, unknown>;
  const existing = g[FLAG] as DispatcherState | undefined;
  if (existing) return existing;
  const fresh: DispatcherState = { timer: null, inFlight: false };
  g[FLAG] = fresh;
  return fresh;
}

/**
 * Register the standing dispatcher (idempotent across dev reloads).
 * Under a SchedulerLease — multi-instance safe; fail-closed ("skip") on
 * lease-store outage: an external side effect must never run ungated.
 */
export function startCampaignDispatcher(): void {
  const s = state();
  if (s.timer != null) return;
  /* first pass soon after boot — freshly claimed campaigns start flowing */
  setTimeout(() => {
    void withJobLease(
      "campaign-dispatch",
      LEASE_TTL_MS,
      () => sweepCampaignDispatch(),
      { failure: "skip" }
    ).catch(() => {});
  }, 10_000).unref?.();
  s.timer = setInterval(() => {
    if (s.inFlight) return; /* one pass at a time per process */
    s.inFlight = true;
    void (async () => {
      try {
        await withJobLease(
          "campaign-dispatch",
          LEASE_TTL_MS,
          () => sweepCampaignDispatch(),
          { failure: "skip" }
        );
      } catch {
        /* best-effort tick */
      } finally {
        s.inFlight = false;
      }
    })();
  }, TICK_MS);
  s.timer.unref?.();
}
