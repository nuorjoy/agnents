import { NextResponse } from "next/server";
import { z } from "zod";
import { routeHandler, ctxAdmin, ctxBody } from "@/lib/server/route";
import * as service from "./service";

/**
 * Ashrilogic — campaigns domain CONTROLLER (ROUND 165).
 *
 * The HTTP seam of the newsletter-campaign domain. Every handler is a
 * routeHandler(...) (the unified wrapper: correlation ids, the 500
 * envelope with the route's own verb phrase, redacted telemetry) and the
 * guards are DECLARATIVE — preserving the historical sequences:
 *
 *  - GET    the archive: requireAdmin() with NO req (read posture, any
 *           authenticated admin);
 *  - POST   create draft: requireAdmin(["super","admin"], req) — the
 *           roles + withRequest stages (origin + MFA-policy gates run
 *           inside requireAdmin exactly as the legacy call did);
 *  - PATCH  send/edit: the same admin stage, then the body stage with the
 *           union schema (send-action OR draft-edit — one read of the
 *           stream, the exact "Invalid payload" 400 envelope when neither
 *           shape matches);
 *  - DELETE remove: the same admin stage.
 *
 * THE SEND PATH IS A CLAIM, NOT A DELIVERY: { action: "send" } transitions
 * the draft to "sending" (CAS) and returns immediately — the durable
 * dispatcher (service.sweepCampaignDispatch, registered from
 * instrumentation) owns enqueue, delivery, retries, dead-lettering and the
 * completion stamp. No bulk mail ever runs inside the HTTP request.
 */

const campaignEditSchema = z.object({
  subject: z.string().trim().min(3).max(120),
  body: z.string().trim().min(10).max(5000),
  /* ROUND 167 (tenant messaging) — the segmentation fields (both optional:
   * the legacy newsletter composer sends subject+body only and keeps the
   * subscribers/broadcast defaults). */
  audience: z.enum(["subscribers", "tenants", "tenants:plan"]).optional(),
  /** required when (and only when) audience = "tenants:plan". */
  packageId: z.string().trim().min(1).max(64).optional(),
  kind: z.enum(["welcome", "offer", "discount", "update", "broadcast"]).optional(),
}).refine((data) => data.audience !== "tenants:plan" || (data.packageId ?? "") !== "", {
  message: "packageId is required when audience is \"tenants:plan\"",
});

const campaignSendSchema = z.object({ action: z.literal("send") });

const campaignCreateSchema = z.object({
  subject: z.string().trim().min(3).max(120),
  body: z.string().trim().min(10).max(5000),
  audience: z.enum(["subscribers", "tenants", "tenants:plan"]).optional(),
  packageId: z.string().trim().min(1).max(64).optional(),
  kind: z.enum(["welcome", "offer", "discount", "update", "broadcast"]).optional(),
}).refine((data) => data.audience !== "tenants:plan" || (data.packageId ?? "") !== "", {
  message: "packageId is required when audience is \"tenants:plan\"",
});

/** The historical first-issue message for a failed draft-shape parse. */
function zodFirst(error: z.ZodError): string {
  const issue = error.issues[0];
  return issue ? `${issue.path.join(".") || "body"}: ${issue.message}` : "Invalid payload";
}

/** GET /api/admin/campaigns — the archive + audience estimate. */
export const adminList = routeHandler(
  "list campaigns",
  { admin: {} },
  async (): Promise<NextResponse> => {
    const result = await service.listCampaigns();
    return NextResponse.json(result);
  }
);

/** POST /api/admin/campaigns — create a DRAFT (super/admin, audited). */
export const adminCreate = routeHandler(
  "create campaign",
  {
    admin: {
      roles: ["super", "admin"],
      withRequest: true,
    },
  },
  async (ctx): Promise<NextResponse> => {
    const admin = ctxAdmin(ctx);
    /* the body keeps its CUSTOM historical 400 envelope (first zod issue),
     * so the parse happens inline rather than in a body stage */
    const data = (await ctx.readBody()) as {
      subject?: unknown;
      body?: unknown;
      audience?: unknown;
      packageId?: unknown;
      kind?: unknown;
    };
    const parsed = campaignCreateSchema.safeParse(data);
    if (!parsed.success) {
      return NextResponse.json({ error: zodFirst(parsed.error) }, { status: 400 });
    }
    /* the plan-variant audience is validated against a LIVE package row
     * and composed into its storage form ("tenants:plan:<id>"). */
    const audience = parsed.data.audience
      ? await service.resolveAudience(parsed.data.audience, parsed.data.packageId)
      : undefined;
    const dto = await service.createDraft(
      {
        subject: parsed.data.subject,
        body: parsed.data.body,
        ...(audience ? { audience } : {}),
        ...(parsed.data.kind ? { kind: parsed.data.kind } : {}),
      },
      {
        id: admin.id,
        username: admin.username,
      }
    );
    return NextResponse.json(dto, { status: 201 });
  }
);

/** GET /api/admin/campaigns/audience — the SEGMENTED composer's live
 * audience preview (the wallet-grants preview law: ?target=…&packageId=…). */
export const adminAudiencePreview = routeHandler(
  "preview campaign audience",
  { admin: { roles: ["super", "admin"] } },
  async (ctx): Promise<NextResponse> => {
    const params = new URL(ctx.req.url).searchParams;
    const rawTarget = params.get("target") ?? "subscribers";
    const target = (rawTarget === "tenants" || rawTarget === "tenants:plan"
      ? rawTarget
      : "subscribers") as service.AudienceTarget;
    const packageId = params.get("packageId") ?? undefined;
    const dto = await service.audiencePreview(target, packageId);
    return NextResponse.json(dto);
  }
);

/** Segment shape for the [id] route (Next 16: params is a Promise). */
interface CampaignSegment {
  params: Promise<{ id: string }>;
}

/**
 * PATCH /api/admin/campaigns/[id] — the two guarded operations:
 *  - { action: "send" } : CLAIM the draft for background dispatch (409 on
 *    any non-draft — including an in-flight "sending");
 *  - { subject, body }  : edit a DRAFT in place (409 on any non-draft).
 */
export const adminSendOrEdit = routeHandler(
  "update campaign",
  {
    admin: {
      roles: ["super", "admin"],
      withRequest: true,
    },
    body: {
      /* one read of the stream; either shape validates (send wins first —
       * the historical branch order); neither → the "Invalid payload" 400 */
      schema: z.union([campaignSendSchema, campaignEditSchema]),
      invalid: { error: "Invalid payload" },
    },
  },
  async (ctx, segment: CampaignSegment): Promise<NextResponse> => {
    const admin = ctxAdmin(ctx);
    const { id } = await segment.params;
    const body = ctxBody<z.infer<typeof campaignSendSchema> | z.infer<typeof campaignEditSchema>>(ctx);

    if ("action" in body && body.action === "send") {
      const dto = await service.claimCampaign(id, {
        id: admin.id,
        username: admin.username,
      });
      return NextResponse.json(dto);
    }
    const edit = body as z.infer<typeof campaignEditSchema>;
    /* the plan-variant audience is validated against a LIVE package row and
     * composed into its storage form — exactly like the create path. */
    const audience = edit.audience
      ? await service.resolveAudience(edit.audience, edit.packageId)
      : undefined;
    const dto = await service.editDraft(
      id,
      {
        subject: edit.subject,
        body: edit.body,
        ...(audience ? { audience } : {}),
        ...(edit.kind ? { kind: edit.kind } : {}),
      },
      {
        id: admin.id,
        username: admin.username,
      }
    );
    return NextResponse.json(dto);
  }
);

/** DELETE /api/admin/campaigns/[id] — remove a draft or archived record
 *  (super/admin; a mid-flight "sending" campaign refuses with 409). */
export const adminRemove = routeHandler(
  "delete campaign",
  {
    admin: {
      roles: ["super", "admin"],
      withRequest: true,
    },
  },
  async (ctx, segment: CampaignSegment): Promise<NextResponse> => {
    const admin = ctxAdmin(ctx);
    const { id } = await segment.params;
    await service.removeCampaign(id, { id: admin.id, username: admin.username });
    return new NextResponse(null, { status: 204 });
  }
);
