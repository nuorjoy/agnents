import { NextResponse } from "next/server";
import { routeHandler, ctxBody } from "@/lib/server/route";
import {
  placeOrderSchema,
  trackSchema,
  placeOrder,
  trackOrder,
  readIdempotencyKey,
} from "./service";

/**
 * Ashrilogic — orders domain CONTROLLER (ROUND 128).
 *
 * The HTTP seam for the PUBLIC guest-checkout surface. Every handler is a
 * routeHandler(...) (ROUND 124's unified wrapper: correlation ids, the 500
 * envelope with the route's own verb phrase, redacted structured telemetry
 * — the labels "place the order" / "track the order" reproduce the legacy
 * 500 strings byte-for-byte).
 *
 * ROUND 128 — the guard sequences are declared in the wrapper config and
 * the wrapper translates each stage into the REAL guard call, preserving
 * the historical sequences byte-for-byte (including their asymmetries):
 *  - placement POST: originViolation FIRST (the origin stage), then the
 *    ROUND-96 maintenance block (503 while a restore of THIS tenant is in
 *    flight — an order would otherwise commit into the teardown path),
 *    then the body + schema with the LEGACY custom 400 ("Order must hold
 *    1–20 items…"), then the placement throttle (rateLimit.afterBody: an
 *    INVALID body never burns a hit — the historical semantics);
 *  - track POST: originViolation FIRST, then the body + schema ("Enter
 *    your tracking code…"), then the lookup throttle (afterBody — same
 *    historical position), NO maintenance stage (the legacy track route
 *    never had one).
 *
 * The Zod envelopes here are the LEGACY custom strings, not zodError —
 * these routes never used the shared mapper's envelope, and
 * byte-compatibility is the contract.
 */

/** order placement throttling: 10 orders / 10 min per source IP + site. */
const ORDER_RULE = { limit: 10, windowMs: 10 * 60 * 1000 };

/** tracking throttling: 20 lookups / 10 min per source IP + site — the
 *  endpoint requires BOTH a valid code and the matching phone, but the cap
 *  still blunts scripted enumeration of either. */
const TRACK_RULE = { limit: 20, windowMs: 10 * 60 * 1000 };

/** Segment shape for the [id] routes (Next 16: params is a Promise). */
interface SiteSegment {
  params: Promise<{ id: string }>;
}

/** POST /api/sites/[id]/orders — place a storefront order (guest). */
export const orderPlace = routeHandler(
  "place the order",
  {
    origin: true,
    maintenance: true,
    body: {
      schema: placeOrderSchema,
      invalid: {
        error: "Order must hold 1–20 items with quantities 1–99 and guest contact details",
      },
    },
    rateLimit: {
      key: (parts) => `site-order:${parts.params.id}:${parts.ip}`,
      rule: ORDER_RULE,
      body: { error: "Too many orders — please wait a moment", code: "RATE" },
      afterBody: true,
    },
  },
  async (ctx, segment: SiteSegment): Promise<NextResponse> => {
    const { id } = await segment.params;
    const input = ctxBody<typeof placeOrderSchema._output>(ctx);
    const outcome = await placeOrder(id, input, readIdempotencyKey(ctx.req));
    /* the idempotency replay outcome is a RAW response (its
     * `idempotency-replayed: true` header is part of the contract) —
     * passed through untouched; everything else renders from the DTO. */
    return outcome.kind === "response"
      ? outcome.response
      : NextResponse.json(outcome.dto, { status: 201 });
  }
);

/** POST /api/sites/[id]/orders/track — follow an order by code + phone. */
export const orderTrack = routeHandler(
  "track the order",
  {
    origin: true,
    body: {
      schema: trackSchema,
      invalid: {
        error: "Enter your tracking code and the phone number you ordered with",
      },
    },
    rateLimit: {
      key: (parts) => `order-track:${parts.params.id}:${parts.ip}`,
      rule: TRACK_RULE,
      body: { error: "Too many attempts — please wait", code: "RATE" },
      afterBody: true,
    },
  },
  async (ctx, segment: SiteSegment): Promise<NextResponse> => {
    const { id } = await segment.params;
    const input = ctxBody<typeof trackSchema._output>(ctx);
    const payload = await trackOrder(id, input);
    return NextResponse.json(payload);
  }
);
