import { NextResponse } from "next/server";
import { z } from "zod";
import { createHash } from "node:crypto";
import { db } from "@/lib/db";
import { computeEntitlement } from "@/lib/server/entitlement";
import { enqueueWebhookEvent } from "@/lib/server/webhooks";
import { resolveCustomerSession } from "@/lib/server/customer-session";
import { blindIndex, encryptField } from "@/lib/server/crypto-vault";
import { isUniqueViolation } from "@/lib/server/db-errors";
import { opLog } from "@/lib/server/oplog";
import {
  effectiveVariantPriceMinor,
  effectiveVariantStock,
  parseRecordValues,
  storeColumnsFor,
  storeModuleId,
} from "@/lib/server/store-mapper";
import { findVariantByName } from "@/lib/server/record-variants";
import { toDisplayUnits, isValidMinorUnits } from "@/lib/server/money";
import {
  appendStatusEvent,
  parseOrderSnapshot,
  parseStatusHistory,
  snapshotImage,
  type SnapshotItem,
} from "@/lib/server/order-snapshot";
import {
  evaluateCoupon,
  generateTrackingCode,
  normalizeCouponCode,
  normalizePhoneForIndex,
} from "@/lib/server/coupons";
import { issueReceiptToken } from "@/lib/server/receipt-token";
import { guestOrderProjection } from "@/lib/server/order-guest";
import { HttpError } from "@/lib/server/route";
import type { SiteCustomer, SiteOrder } from "@prisma/client";
import type { SiteOrderDTO, SiteOrderItemDTO } from "@/lib/types";
import * as repository from "./repository";

/**
 * Ashrilogic — orders domain SERVICE (ROUND 128).
 *
 * Business flows for the PUBLIC guest-checkout surface (order placement
 * and order tracking), lifted VERBATIM from the two legacy route handlers
 * (src/app/api/sites/[id]/orders/route.ts + orders/track/route.ts —
 * ROUND 44 guest checkout, ROUND 50 coupons + idempotency, ROUND 54 image
 * snapshots, ROUND 56 status trail, ROUND 65 signed-in shopper priority,
 * ROUND 87 soft-delete gates, ROUND 113 webhook fan-out, ROUND 120
 * passwordHash-NULL + the coupon-identity/OrderReservation ledgers).
 *
 * Error policy: the legacy handlers returned inline
 * `NextResponse.json({ error, code? }, { status })` shapes; here those
 * become HttpError throws with the SAME status/message/code — the unified
 * wrapper (ROUND 124) renders the identical envelope. The two cases that
 * genuinely need a RAW response (the idempotency REPLAY with its
 * `idempotency-replayed: true` header) come back as
 * `{ kind: "response" }` outcomes for the controller to pass through.
 *
 * The placement TRANSACTION keeps its own Prisma usage (db.$transaction
 * with per-row CAS decrements) — the plan-orders precedent for
 * transactional state machines.
 */

const ORDER_STATUSES = [
  "pending",
  "confirmed",
  "preparing",
  "ready",
  "completed",
  "cancelled",
] as const;

const orderStatusRead = z.enum(ORDER_STATUSES).catch("pending");

/** single-item and per-order quantity ceiling (also applies to merged lines) */
const MAX_QTY_PER_LINE = 99;

/** CAS retries when the owner concurrently edits the same inventory row. */
const STOCK_RETRIES = 3;

/* ROUND 44 — GUEST checkout (member login removed from the public website):
 * the visitor supplies contact details with the order; NO account, NO
 * session, NO sign-in. When an email is provided it doubles as the dedupe
 * key (an existing customer row is reused); phone-only guests get a fresh
 * row with an UNUSABLE random credential — identical to the restore path's
 * dead-credential pattern. */
const guestContactSchema = z.object({
  name: z.string().trim().min(2).max(80),
  phone: z.string().trim().max(30).optional(),
  email: z.email().max(160).optional(),
});

const placeOrderSchema = z.object({
  items: z
    .array(
      z.object({
        recordId: z.string().min(1).max(64),
        qty: z.number().int().min(1).max(99),
        /** ROUND 141 — the chosen VARIANT label (متغيرات المنتج). Optional:
         *  variant-less products order exactly as before. The label is
         *  resolved server-side against the record's stored variantsJson
         *  (an unknown label = the product changed under the guest →
         *  LineGone), and the charged price derives from the variant's
         *  own override when it carries one. */
        variant: z.string().trim().min(1).max(80).optional(),
      })
    )
    .min(1)
    .max(20),
  note: z.string().trim().max(500).optional(),
  customer: guestContactSchema,
  /* ROUND 50 — optional coupon code; validated + re-priced server-side */
  couponCode: z.string().trim().min(3).max(32).optional(),
});

const trackSchema = z.object({
  code: z.string().trim().min(4).max(24),
  phone: z.string().trim().min(4).max(30),
});

export type PlaceOrderInput = z.infer<typeof placeOrderSchema>;
export type TrackOrderInput = z.infer<typeof trackSchema>;
export type GuestContact = z.infer<typeof guestContactSchema>;

export { placeOrderSchema, trackSchema };

/* --------------------------- IDEMPOTENT PLACEMENT ----------------------- */

/** The idempotency header (case-insensitive lookup via Headers). */
const IDEMPOTENCY_HEADER = "idempotency-key";

/** Client-supplied key shape: 8–80 chars, URL/word-safe. */
const IDEMPOTENCY_KEY_RE = /^[A-Za-z0-9._:-]{8,80}$/;

/** in-flight rows older than this are crashed holders — safe to replace */
const IN_FLIGHT_STALE_MS = 2 * 60 * 1000;

/** Idempotent retry window: completed records replay inside it, then expire. */
const RETENTION_MS = 24 * 60 * 60 * 1000;

/* RETENTION SWEEP (the same opportunistic housekeeping discipline as the
 * rate limiter's): completed guard rows beyond the replay window and stale
 * in-flight holders are dead weight — without a sweep the table grows
 * forever with every keyed placement. Fired at most once per SWEEP_MS per
 * process, bounded to one small deleteMany, failures swallowed (the
 * window queries below prune logically regardless). */
const SWEEP_MS = 10 * 60 * 1000;
let lastSweep = 0;
let sweepInFlight = false;

async function sweepExpiredGuards(now: number): Promise<void> {
  if (sweepInFlight || now - lastSweep < SWEEP_MS) return;
  sweepInFlight = true;
  lastSweep = now;
  try {
    const completedCutoff = new Date(now - RETENTION_MS);
    const staleCutoff = new Date(now - IN_FLIGHT_STALE_MS);
    await db.orderIdempotency.deleteMany({
      where: {
        OR: [
          { status: "completed", completedAt: { lt: completedCutoff } },
          { status: "in_flight", createdAt: { lt: staleCutoff } },
        ],
      },
    });
  } catch {
    /* best-effort — expired rows are simply re-checked-and-replaced on the
       next keyed placement (the replay path deletes them lazily too) */
  } finally {
    sweepInFlight = false;
  }
}

interface IdempotencyScope {
  /** fully-scoped record key: site + customer scope + client key */
  key: string;
  /** SHA-256 of the canonical request payload */
  requestHash: string;
}

/** Canonical request fingerprint: merged lines (sorted), coupon, note and
 *  the guest contact — the payload identity a retry must reproduce.
 *  ROUND 141 — the merge key carries the variant label too (a retry of the
 *  same cart reproduces the same variant lines byte-for-byte). */
function canonicalRequestHash(data: PlaceOrderInput): string {
  const merged = new Map<string, number>();
  for (const item of data.items) {
    const key = lineKeyOf(item.recordId, item.variant);
    merged.set(key, (merged.get(key) ?? 0) + item.qty);
  }
  const canonical = {
    items: [...merged.entries()].sort(([a], [b]) => (a < b ? -1 : 1)),
    couponCode: data.couponCode ? normalizeCouponCode(data.couponCode) : null,
    note: data.note ?? null,
    customer: {
      name: data.customer.name,
      phone: data.customer.phone ? normalizePhoneForIndex(data.customer.phone) : null,
      email: data.customer.email?.trim().toLowerCase() ?? null,
    },
  };
  return createHash("sha256").update(JSON.stringify(canonical), "utf8").digest("hex");
}

/** ROUND 141 — the merge/identity key of one order line: record + variant. */
function lineKeyOf(recordId: string, variant: string | undefined): string {
  return variant ? `${recordId}\u0000${variant.trim()}` : recordId;
}

/** Parse + validate the Idempotency-Key header; null when absent/invalid. */
export function readIdempotencyKey(req: Request): string | null {
  const raw = req.headers.get(IDEMPOTENCY_HEADER)?.trim();
  if (!raw) return null;
  if (!IDEMPOTENCY_KEY_RE.test(raw)) return null; /* invalid shape → treated as absent */
  return raw;
}

/** Pre-transaction replay check for a scoped key.
 *  Returns the raw replay NextResponse to short-circuit with, or null to
 *  proceed; the 422/409 conflict cases are HttpError throws (identical
 *  envelopes to the legacy inline responses). */
async function idempotencyReplay(
  scope: IdempotencyScope
): Promise<NextResponse | null> {
  const existing = await repository.findOrderIdempotency(scope.key);
  if (!existing) return null;

  if (existing.status === "completed") {
    if (existing.requestHash !== scope.requestHash) {
      /* key REUSE with a different payload — a client bug or probe; refuse */
      throw new HttpError(
        422,
        "This Idempotency-Key was already used with a different request",
        "KEY_REUSED"
      );
    }
    if (existing.completedAt && Date.now() - existing.completedAt.getTime() > RETENTION_MS) {
      /* expired record — replay window over; proceed as a fresh placement
         (the transaction's INSERT must first replace this row) */
      await repository.deleteOrderIdempotency(scope.key);
      return null;
    }
    opLog.info("order.idempotency-replay", {
      instanceId: scope.key.split(":")[1],
      result: "stored response served — no duplicate order created",
    });
    return new NextResponse(existing.responseJson ?? JSON.stringify({ error: "Order already placed" }), {
      status: 200,
      headers: { "content-type": "application/json", "idempotency-replayed": "true" },
    });
  }

  /* in-flight: fresh → the concurrent twin is still running; stale → a
     crashed holder never completed — replace and proceed */
  const age = Date.now() - existing.createdAt.getTime();
  if (age < IN_FLIGHT_STALE_MS) {
    opLog.warn("order.idempotency-in-progress", {
      instanceId: scope.key.split(":")[1],
      result: "concurrent duplicate attempt refused",
      detail: `in-flight for ${Math.round(age / 1000)}s`,
    });
    throw new HttpError(
      409,
      "This request is already being processed",
      "IN_PROGRESS"
    );
  }
  await repository.deleteOrderIdempotency(scope.key);
  return null;
}

/** Resolve (find-or-create) the guest contact row for this order.
 * Sealing mirrors the former register route: email/phone AES-256-GCM at
 * rest, email lookups via the keyed blind index, Argon2id unusable
 * credential for account-less rows.
 * CONCURRENT FIRST ORDERS: two simultaneous placements from the same email
 * both miss the findFirst and both attempt the create — the loser hits the
 * `@@unique([instanceId, emailIndex])` constraint. Catching that violation
 * and re-finding turns a former 500 into the intended find-or-create. */
async function resolveGuestCustomer(
  instanceId: string,
  guest: GuestContact
): Promise<SiteCustomer | null> {
  const normalizedEmail = guest.email?.trim().toLowerCase();
  if (normalizedEmail) {
    const existing = await repository.findGuestByEmailIndex(
      instanceId,
      blindIndex(normalizedEmail) ?? undefined
    );
    if (existing) return existing;
  }
  /* no matching row — create the guest contact (emailIndex NULL for
   * phone-only guests: SQLite unique treats NULLs as distinct).
   * ROUND 120 — NO Argon2id burn: the guest credential was a random
   * 32-byte secret nobody could ever present (guests do not log in);
   * hashing it cost a full KDF (~tens of ms of event-loop CPU) per guest
   * checkout for zero security value. passwordHash is NULL —
   * checkCustomerPassword fails closed on null; the REGISTER upgrade
   * path (guest → account) sets the real hash. */
  try {
    return await repository.createGuestCustomer({
      instanceId,
      name: guest.name,
      email: encryptField(normalizedEmail ?? "") ?? "",
      emailIndex: normalizedEmail ? blindIndex(normalizedEmail) ?? null : null,
      phone: encryptField(guest.phone?.trim() || null) ?? null,
      passwordHash: null,
    });
  } catch (error) {
    /* Prisma surfaces unique violations as P2002 — a racing twin created
       the same contact between our miss and our insert. Re-find and
       continue; anything else is a genuine failure. */
    if ((error as { code?: string }).code === "P2002" && normalizedEmail) {
      const raced = await repository.findGuestByEmailIndex(
        instanceId,
        blindIndex(normalizedEmail) ?? undefined
      );
      if (raced) return raced;
    }
    throw error;
  }
}

/**
 * ROUND 65 — a signed-in shopper placed an order: refresh the sealed
 * name/phone from the checkout form when provided (the account stays the
 * order's owner; typed contact data keeps the row current), and return the
 * row. The GUEST schema's fields are all OPTIONAL so an account checkout
 * that prefilled everything simply re-writes the same values.
 */
async function refreshSignedInContact(
  row: SiteCustomer,
  guest: GuestContact
): Promise<SiteCustomer> {
  const data: Record<string, unknown> = {};
  if (guest.name && guest.name !== row.name) data.name = guest.name;
  const typedPhone = guest.phone?.trim() || null;
  if (typedPhone) {
    const sealed = encryptField(typedPhone) ?? null;
    if (sealed !== row.phone) data.phone = sealed;
  }
  if (Object.keys(data).length === 0) return row;
  return repository.refreshCustomerContact(row, data);
}

/**
 * Items snapshot shape. v2 (current) stores integer MINOR-UNIT prices; the
 * legacy v1 shape (bare array of display floats) is still read by the SHARED
 * parser (src/lib/server/order-snapshot.ts) so rows created before the
 * migration keep rendering (migrate with scripts/migrate-money-minor-units.ts).
 * ROUND 54: each item carries the optional managed image ref captured at
 * placement — the photo the customer saw when ordering.
 */
interface SnapshotV2 {
  v: 2;
  items: SnapshotItem[];
}

/** Map a SiteOrder row to the customer-facing DTO (display-unit floats). */
function toOrderDTO(row: SiteOrder): SiteOrderDTO {
  const { items: parsedItems, legacy } = parseOrderSnapshot(row.itemsJson);
  const items: SiteOrderItemDTO[] = parsedItems.map((it) =>
    legacy ? { ...it, image: it.image ?? null } : { ...it, price: toDisplayUnits(it.price), image: it.image ?? null }
  );
  // v2 rows: total is integer minor units → display float. Legacy rows were
  // stored in (truncated) display units — returned unchanged.
  const total = legacy ? row.total : toDisplayUnits(row.total);
  const discount = legacy ? 0 : toDisplayUnits(row.discount);
  return {
    id: row.id,
    code: row.code,
    items,
    total,
    discount,
    couponCode: row.couponCode,
    currency: row.currency,
    status: orderStatusRead.parse(row.status),
    note: row.note,
    statusNote: row.statusNote,
    // ROUND 56 — the lifecycle trail (empty array on legacy/NULL rows)
    statusHistory: parseStatusHistory(row.statusHistoryJson),
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

function storeCurrencyOf(instance: { orgJson: string }): string {
  try {
    const org = JSON.parse(instance.orgJson ?? "{}") as { currency?: unknown };
    return typeof org.currency === "string" && org.currency.trim() ? org.currency.trim() : "SAR";
  } catch {
    return "SAR";
  }
}

/** Sentinel thrown inside the stock CAS loop when the row changed mid-flight. */
class StockConflict extends Error {
  constructor() {
    super("STOCK_CONFLICT");
  }
}

/** ROUND 50 — the coupon's last use was consumed by a concurrent order
 *  (CAS on usedCount failed). The whole placement retries against fresh
 *  stock + a fresh coupon verdict — the guest never over-redeems. */
class CouponRaceError extends Error {
  constructor() {
    super("COUPON_RACE");
  }
}

/** ROUND 50 — the generated tracking code collided with an existing order
 *  of the same workspace (32^6 space; astronomically rare) — retry with a
 *  fresh code. */
class TrackingCodeCollision extends Error {
  constructor() {
    super("CODE_COLLISION");
  }
}

/** The concurrent twin already owns the idempotency guard row — the
 *  transaction is aborted; the outcome is resolved from the twin's record. */
class IdempotencyConflictError extends Error {
  constructor() {
    super("IDEMPOTENCY_CONFLICT");
  }
}

/** Distinguishing errors thrown inside the transaction for clean mapping. */
class LineGoneError extends Error {
  constructor() {
    super("ITEM_GONE");
  }
}
class InsufficientStockError extends Error {
  constructor(
    public itemName: string,
    public stock: number
  ) {
    super("STOCK");
  }
}

/** The placement outcome: a raw response to pass through (the idempotency
 *  replay with its header) or the created order's DTO (→ 201). */
export type PlacementOutcome =
  | { kind: "response"; response: NextResponse }
  | { kind: "placed"; dto: SiteOrderDTO };

/**
 * POST /api/sites/[id]/orders — place a storefront order (GUEST checkout,
 * ROUND 44: the member-login process was removed from the public website —
 * orders no longer require or accept a customer session).
 *
 * SECURITY:
 *  - item prices are re-derived SERVER-SIDE from the module records at
 *    placement time — the client only sends record ids + quantities;
 *  - the whole placement runs in ONE transaction with per-row
 *    compare-and-swap stock decrements (updateMany guarded by the exact
 *    dataJson that was read) — two concurrent orders can never both consume
 *    the last unit, and stock is genuinely consumed (no oversell);
 *  - totals are computed in INTEGER MINOR UNITS end-to-end and stored as
 *    such (no floating-point money in storage);
 *  - the guest contact is resolved server-side (find-or-create by the
 *    keyed email blind index when an email is given); a BANNED contact
 *    still cannot order; throttling is per source IP + site.
 *
 * The origin/maintenance/body/throttle GUARDS run in the wrapper's
 * declarative plan (the controller) — the same order the legacy handler
 * hand-wrote: origin → maintenance → body → throttle (an INVALID body
 * never burns a throttle hit).
 */
export async function placeOrder(
  instanceId: string,
  input: PlaceOrderInput,
  clientKey: string | null
): Promise<PlacementOutcome> {
  /* banned contacts keep being refused (the owner's ban decision is
   * enforced even in guest mode when the email matches the row).
   *
   * ROUND 65 (customer accounts): a signed-in shopper's session customer
   * row takes PRIORITY over the guest payload — the order lands on the
   * ACCOUNT (their history tab), and the contact fields they typed at
   * checkout refresh the sealed name/phone on the row. Guests keep the
   * exact former find-or-create path. */
  const session = await resolveCustomerSession(instanceId);
  const customer = session.status === "valid"
    ? await refreshSignedInContact(session.customer, input.customer)
    : await resolveGuestCustomer(instanceId, input.customer);
  if (!customer) {
    throw new HttpError(500, "Failed to resolve contact details");
  }
  if (customer.status === "banned") {
    throw new HttpError(403, "This contact cannot place orders");
  }

  /* IDEMPOTENT PLACEMENT: when the client sends an Idempotency-Key, the
   * request is scoped to (site × customer scope × key) with the payload's
   * canonical hash. Completed twins replay the stored response; a
   * concurrent twin gets a clean in-progress 409. The guard row itself
   * is written INSIDE the placement transaction below — creation and
   * completion are atomic, and a crash rolls both back. */
  /* scope AFTER customer resolution: the signed-in shopper's account id
   * separates their key space from every guest's (tenant/site + session
   * identity + request identity — the documented scoping contract) */
  const scope: IdempotencyScope | null = clientKey
    ? {
        key: `site:${instanceId}:${session.status === "valid" ? customer.id : "guest"}:${clientKey}`,
        requestHash: canonicalRequestHash(input),
      }
    : null;

  if (scope) {
    /* opportunistic retention sweep (bounded; at most once per 10 min) */
    void sweepExpiredGuards(Date.now());
    const replay = await idempotencyReplay(scope);
    if (replay) return { kind: "response", response: replay };
  }

  // merge duplicate lines first, then enforce the per-line ceiling on the
  // MERGED quantity (two entries of 99 each cannot sneak past as 198).
  // ROUND 141 — a variant-carrying line is its OWN line: the same record
  // under two different variants orders as two lines (each ≤99).
  const merged = new Map<string, { recordId: string; variant?: string; qty: number }>();
  for (const item of input.items) {
    const key = lineKeyOf(item.recordId, item.variant);
    const prev = merged.get(key);
    merged.set(key, {
      recordId: item.recordId,
      variant: item.variant,
      qty: (prev?.qty ?? 0) + item.qty,
    });
  }
  for (const line of merged.values()) {
    if (line.qty > MAX_QTY_PER_LINE) {
      throw new HttpError(400, "Quantity per item is limited to 99", "QTY");
    }
  }

  try {
    /* ROUND 47 — trial stop: a locked storefront accepts no orders. */
    const site = await repository.findSiteGate(instanceId);
    const ent = site ? computeEntitlement(site.instance) : null;
    /* ROUND 79 — feature-aware: the surface stops when the workspace is
     * locked OR the plan does not include the "store" feature. */
    const stopped = !ent || ent.state === "locked" || ent.features.store !== true;
    if (!site || !site.published || stopped) {
      throw new HttpError(404, "Store not available");
    }

    /* ROUND 49 — column-narrowed public read (sealed columns never enter
       a public request context; pricing re-verifies from module records).
       ROUND 87 — a trashed (soft-deleted) workspace accepts NO orders. */
    const instance = await repository.findLiveCatalogInstance(instanceId);
    const moduleId = instance ? storeModuleId(instance) : null;
    if (!instance || !moduleId) {
      throw new HttpError(404, "Store not available");
    }
    const currency = storeCurrencyOf(instance);
    const cols = storeColumnsFor(moduleId);

    /* ROUND 50 — the requested coupon, resolved ONCE per attempt (the
     * verdict is re-checked INSIDE the transaction against the true
     * server-derived subtotal). */
    const requestedCode = input.couponCode
      ? normalizeCouponCode(input.couponCode)
      : null;

    let row: SiteOrder | null = null;
    for (let attempt = 0; attempt < STOCK_RETRIES; attempt++) {
      try {
        row = await db.$transaction(async (tx) => {
          /* IDEMPOTENCY GUARD — INSIDE the same transaction as the order: the
           * creation and its completion marker are ATOMIC (a crash rolls both
           * back; no orphan in-flight row can pin the key). A concurrent twin
           * loses the unique-key INSERT and surfaces the in-progress 409. */
          if (scope) {
            try {
              await tx.orderIdempotency.create({
                data: {
                  key: scope.key,
                  instanceId,
                  requestHash: scope.requestHash,
                  status: "in_flight",
                },
              });
            } catch (guardError) {
              if (isUniqueViolation(guardError)) {
                /* the twin's guard row exists — completed (replay) or
                   in-flight (conflict); resolve OUTSIDE the aborted tx */
                throw new IdempotencyConflictError();
              }
              throw guardError;
            }
          }

          const recordIds = [...new Set([...merged.values()].map((l) => l.recordId))];
          /* ROUND 87 — LIVE products only: a trashed (soft-deleted) product
           * must never be purchasable (it reads as ITEM_GONE below).
           * ROUND 140 — HIDDEN products (the merchant's storeVisible
           * checkmark = FALSE) are equally gone from the public surface: a
           * guest with a stale storefront copy cannot order a product the
           * merchant has deliberately hidden. */
          const records = await tx.moduleRecord.findMany({
            where: { instanceId, moduleId, id: { in: recordIds }, deletedAt: null },
          });
          const byId = new Map(records.map((r) => [r.id, r]));

          const snapshotItems: SnapshotItem[] = [];
          let subtotalMinor = 0;
          /* ROUND 141 — the AGGREGATED per-record decrement: the same record
           * may now ride SEVERAL variant lines (each its own snapshot line),
           * so the physical stock pool decrements ONCE per record with the
           * summed quantity (a per-line CAS would conflict with itself). */
          const recordDecrement = new Map<string, number>();

          for (const line of merged.values()) {
            const { recordId, variant } = line;
            const qty = line.qty;
            const record = byId.get(recordId);
            if (!record) {
              throw new LineGoneError();
            }
            if (record.storeVisible === false) {
              throw new LineGoneError();
            }
            const values = parseRecordValues(record.dataJson);
            const at = (i: number) => (i < values.length ? values[i] : "");
            const name = at(cols.name).trim();
            /* ROUND 141 — the chosen VARIANT, resolved server-side against
             * the record's stored variantsJson: an unknown label (the
             * merchant edited the product under the guest's stale cart)
             * reads as LineGone, exactly like a hidden/removed product. */
            const variantRow = variant ? findVariantByName(record.variantsJson, variant) : null;
            if (variant && !variantRow) {
              throw new LineGoneError();
            }
            /* ROUND 52 — the charged price is the EFFECTIVE price: the active
             * sale price (validated strictly below the regular minor price
             * at write time, re-validated here) when one is set, else the
             * regular price parsed from the money cell. The storefront shows
             * exactly this value — no drift between display and charge.
             * ROUND 141 — a variant carrying its own price override wins
             * (effectiveVariantPriceMinor); the line's NAME carries the
             * variant label so the receipt reads «المنتج — المتغير». */
            const priceMinor = effectiveVariantPriceMinor(record, moduleId, variantRow);
            const lineName = variantRow ? `${name} — ${variantRow.name}` : name;
            /* ROUND 141 — the stock a variant line may draw on: the variant's
             * own carve-out when it carries one (validated here at placement;
             * the RECORD stock cell below remains the physical pool that
             * decrements once per record). */
            const variantStock = effectiveVariantStock(record, moduleId, variantRow);

            if (!name || priceMinor <= 0) {
              throw new LineGoneError();
            }
            if (record.statusKey === "out" || record.statusKey === "expired" || record.statusKey === "soldout") {
              throw new LineGoneError();
            }
            if (!(variantStock >= qty)) {
              throw new InsufficientStockError(lineName, Math.max(0, variantStock));
            }

            /* ROUND 141 — aggregate the physical decrement per record (the
             * variant lines of one record share its stock pool; the summed
             * quantity is checked against the RECORD stock below). */
            recordDecrement.set(recordId, (recordDecrement.get(recordId) ?? 0) + qty);

            /* ROUND 54 — capture the product photo AT PLACEMENT: the image the
             * customer saw. imageRef is a server-read managed ref (or null); a
             * malformed stored value degrades to NO image via the shared
             * shape guard instead of reaching an <img src> on read. */
            const image = snapshotImage(record.imageRef);

            snapshotItems.push(
              image
                ? { recordId, name: lineName, price: priceMinor, qty, image }
                : { recordId, name: lineName, price: priceMinor, qty }
            );
            subtotalMinor += priceMinor * qty;
          }

          /* ROUND 141 — ONE guarded CAS decrement per record with the summed
           * quantity: two variant lines of the same record can never oversell
           * the shared stock pool (the aggregate is checked as a whole), and
           * the compare-and-swap on dataJson still forces a retry on any
           * concurrent writer (owner edit or rival order). */
          for (const [recordId, totalQty] of recordDecrement) {
            const record = byId.get(recordId);
            if (!record) throw new LineGoneError();
            const values = parseRecordValues(record.dataJson);
            const at = (i: number) => (i < values.length ? values[i] : "");
            const name = at(cols.name).trim();
            const recordStock = Math.floor(Number(String(at(cols.stock)).replace(/[^\d.-]/g, "")) || 0);
            if (!(recordStock >= totalQty)) {
              throw new InsufficientStockError(name, Math.max(0, recordStock));
            }
            const nextValues = [...values];
            while (nextValues.length <= cols.stock) nextValues.push("");
            nextValues[cols.stock] = String(Math.floor(recordStock - totalQty));
            const nextJson = JSON.stringify(nextValues);
            const updated = await tx.moduleRecord.updateMany({
              where: { id: record.id, dataJson: record.dataJson },
              data: { dataJson: nextJson },
            });
            if (updated.count !== 1) {
              throw new StockConflict();
            }
          }

          if (!isValidMinorUnits(subtotalMinor)) {
            throw new Error("ORDER_TOTAL_OVERFLOW");
          }

          /* ---------------- ROUND 50: coupon redemption ----------------
           * The authoritative verdict runs INSIDE the transaction against
           * the server-derived subtotal (never the client's preview): a
           * code that expired / exhausted / fell under its minimum since
           * validation cleanly downgrades to NO coupon rather than failing
           * the whole placement — the guest keeps their cart; the discount
           * simply does not apply. The CAS increment guards the usage cap:
           * two concurrent orders can never both consume the last use. */
          let discountMinor = 0;
          let appliedCouponCode: string | null = null;
          /* ROUND 120 — the coupon IDENTITY snapshot: the order stores the
           * coupon row's id next to the code, and the CouponRedemption
           * ledger row (unique per order) is written in THIS transaction —
           * cancellation compensation releases by the id, immune to
           * code-reuse after the original coupon is trashed */
          let appliedCouponId: string | null = null;
          if (requestedCode) {
            /* ROUND 87 — trashed (soft-deleted) coupons NEVER redeem: the
             * engine mangles their code (lookup misses → silent no-coupon
             * downgrade); the filter makes it belt+suspenders. */
            const coupon = await tx.storeCoupon.findUnique({
              where: { instanceId_code: { instanceId, code: requestedCode }, deletedAt: null },
            });
            const verdict = evaluateCoupon(coupon, subtotalMinor);
            if (verdict.ok) {
              const redeemed = await tx.storeCoupon.updateMany({
                where: {
                  id: verdict.coupon.id,
                  active: true,
                  ...(verdict.coupon.maxUses != null
                    ? { usedCount: { lt: verdict.coupon.maxUses } }
                    : {}),
                },
                data: { usedCount: { increment: 1 } },
              });
              if (redeemed.count !== 1) {
                /* lost the race for the last use — retry the placement
                 * without the coupon rather than over-redeeming */
                throw new CouponRaceError();
              }
              discountMinor = verdict.discountMinor;
              appliedCouponCode = verdict.coupon.code;
              appliedCouponId = verdict.coupon.id;
            }
            /* !verdict.ok → silent downgrade (order continues, no discount) */
          }

          const totalMinor = subtotalMinor - discountMinor;
          if (!isValidMinorUnits(totalMinor) || totalMinor < 0) {
            throw new Error("ORDER_TOTAL_OVERFLOW");
          }

          /* ROUND 50 — tracking: short unambiguous code (unique per
           * workspace) + blind index of the normalized guest phone, so the
           * visitor can follow the order with code + phone and no account.
           * A unique-violation (astronomically rare collision) retries the
           * placement with a fresh code. */
          const trackingCode = generateTrackingCode();
          const phoneIdx = input.customer.phone
            ? (blindIndex(normalizePhoneForIndex(input.customer.phone)) ?? null)
            : null;
          /* ROUND 56 — the trail starts at placement: the "pending" event is
           * recorded with the same server clock as createdAt so the customer
           * timeline has a trustworthy first step. */
          const initialHistory = appendStatusEvent(null, {
            status: "pending",
            note: null,
            at: new Date().toISOString(),
          });
          try {
            const created = await tx.siteOrder.create({
              data: {
                instanceId,
                customerId: customer.id,
                itemsJson: JSON.stringify({ v: 2, items: snapshotItems } satisfies SnapshotV2),
                total: totalMinor,
                discount: discountMinor,
                couponCode: appliedCouponCode,
                couponId: appliedCouponId,
                currency,
                status: "pending",
                note: input.note ?? null,
                code: trackingCode,
                phoneIndex: phoneIdx,
                statusHistoryJson: initialHistory,
              },
            });

            /* ROUND 120 — the two integrity ledgers, written in the SAME
             * placement transaction (a crash rolls them back with the
             * order — no ledger row ever points at a ghost order):
             *   1. OrderReservation per line — the moduleId + stockColumn
             *      the placement decremented (module-drift-proof release)
             *      and the durable per-line release state;
             *   2. CouponRedemption — the coupon-identity record the
             *      release targets (unique per order: exactly-once by
             *      construction). */
            await tx.orderReservation.createMany({
              data: snapshotItems.map((it) => ({
                orderId: created.id,
                instanceId,
                recordId: it.recordId,
                moduleId,
                stockColumn: cols.stock,
                qty: it.qty,
                state: "reserved",
              })),
            });
            if (appliedCouponId) {
              await tx.couponRedemption.create({
                data: {
                  orderId: created.id,
                  instanceId,
                  couponId: appliedCouponId,
                  code: appliedCouponCode ?? "",
                },
              });
            }
            /* ROUND 141 (owner notifications, directive ㉜) — the workspace
             * activity feed carries the ORDER RECEIVED event INSIDE the
             * placement transaction (zero-delay: the owner's bell sees it
             * on the very next poll). The order total (major) + tracking
             * code ride in the bilingual meta. */
            await tx.activity.create({
              data: {
                instanceId,
                kind: "actOrderReceived",
                metaJson: JSON.stringify({
                  code: trackingCode,
                  total: Math.round(totalMinor) / 100,
                  currency,
                  items: String(snapshotItems.reduce((n, it) => n + it.qty, 0)),
                }),
              },
            });

            /* complete the idempotency guard atomically with the creation —
               the stored response replays byte-identically on retries */
            if (scope) {
              await tx.orderIdempotency.update({
                where: { key: scope.key },
                data: {
                  status: "completed",
                  orderId: created.id,
                  responseJson: JSON.stringify(toOrderDTO(created)),
                  completedAt: new Date(),
                },
              });
            }
            return created;
          } catch (createError) {
            if (isUniqueViolation(createError, "code")) {
              throw new TrackingCodeCollision();
            }
            throw createError;
          }
        });
        break; // transaction committed
      } catch (error) {
        if (error instanceof IdempotencyConflictError) {
          /* the concurrent twin won the guard INSERT — re-read its outcome:
             completed → replay its response; in-flight → clean 409 */
          opLog.warn("order.idempotency-race", {
            instanceId,
            result: "twin transaction won the guard insert",
          });
          const twin = scope ? await repository.findOrderIdempotency(scope.key) : null;
          if (twin?.status === "completed" && twin.requestHash === scope?.requestHash) {
            return {
              kind: "response",
              response: new NextResponse(twin.responseJson ?? JSON.stringify({ error: "Order already placed" }), {
                status: 200,
                headers: { "content-type": "application/json", "idempotency-replayed": "true" },
              }),
            };
          }
          throw new HttpError(409, "This request is already being processed", "IN_PROGRESS");
        }
        if (error instanceof StockConflict) {
          if (attempt === STOCK_RETRIES - 1) {
            throw new HttpError(409, "Stock just changed — please review your cart", "STOCK");
          }
          continue; // retry the whole placement against fresh rows
        }
        if (error instanceof CouponRaceError) {
          /* retry the placement — the verdict re-runs against a fresh
             coupon row and an exhausted cap downgrades to no-coupon cleanly */
          if (attempt === STOCK_RETRIES - 1) {
            throw new HttpError(409, "This coupon was just used up — please review your order", "COUPON");
          }
          continue;
        }
        if (error instanceof TrackingCodeCollision) {
          continue; // fresh code next attempt
        }
        throw error;
      }
    }

    if (!row) {
      /* unreachable (the loop either breaks on a committed row or throws)
       * — kept as the legacy terminal guard, rendered by the wrapper as
       * the route's 500 envelope with the identical message. */
      throw new HttpError(500, "Failed to place the order");
    }
    /* ROUND 113 — order-event webhook fan-out (best-effort, fire-and-
     * forget: the placement is already durable; a webhook hiccup can
     * never fail it). The payload is the SAME DTO the 201 returns. */
    const dto = toOrderDTO(row);
    void enqueueWebhookEvent(instanceId, "order.placed", dto);
    return { kind: "placed", dto };
  } catch (error) {
    if (error instanceof LineGoneError) {
      throw new HttpError(409, "One of the items is no longer available", "ITEM_GONE");
    }
    if (error instanceof InsufficientStockError) {
      throw new HttpError(409, `Only ${error.stock} × ${error.itemName} left in stock`, "STOCK");
    }
    if (error instanceof Error && error.message === "ORDER_TOTAL_OVERFLOW") {
      throw new HttpError(400, "Order total exceeds the allowed limit");
    }
    /* everything else propagates — the wrapper renders the route's 500
     * envelope ("Failed to place the order") with its structured
     * telemetry, replacing the legacy console.error line. */
    throw error;
  }
}

/**
 * POST /api/sites/[id]/orders/track — follow an order by tracking code +
 * the phone number used when placing it (public, no account).
 *
 * SECURITY:
 *  - the lookup key is the keyed BLIND INDEX of the normalized phone (last
 *    9 digits) — raw phone digits never touch the query layer and a DB
 *    reader learns nothing about guest phones from the index;
 *  - both the code AND the phone index must match — a valid code alone is
 *    a plain 404 (no existence oracle);
 *  - the response carries NO customer PII: items (name + qty), totals,
 *    status timeline, timestamps only.
 *
 * The origin/body/throttle GUARDS run in the wrapper's declarative plan
 * (the controller) — the same order the legacy handler hand-wrote.
 */
export async function trackOrder(
  instanceId: string,
  input: TrackOrderInput
): Promise<{ receiptToken: string } & ReturnType<typeof guestOrderProjection>> {
  /* ROUND 47/79 — trial stop: a locked or feature-stopped storefront
   * answers nothing. */
  const site = await repository.findSiteGate(instanceId);
  const ent = site ? computeEntitlement(site.instance) : null;
  const stopped = !ent || ent.state === "locked" || ent.features.store !== true;
  if (!site || !site.published || stopped) {
    throw new HttpError(404, "Store not available");
  }

  const code = input.code.trim().toUpperCase();
  const phoneIdx = blindIndex(normalizePhoneForIndex(input.phone));
  if (!phoneIdx) {
    throw new HttpError(404, "Order not found");
  }

  /* code + phone index must BOTH match; NULL-phone orders (guest gave no
   * number) are simply not trackable — the lookup misses them by design.
   * ROUND 87 — a trashed (soft-deleted) order is NOT trackable (its code
   * is mangled anyway; the filter is belt+suspenders). */
  const order = await repository.findTrackableOrder(instanceId, code, phoneIdx);
  if (!order) {
    throw new HttpError(404, "Order not found");
  }

  /* ROUND 119 — the projection builder is now the SHARED guest
   * projection (order-guest.ts): this endpoint and the standalone
   * receipt page render the identical guest-safe shape by construction. */
  return {
    ...guestOrderProjection(order),
    /* ROUND 119 — the RECEIPT LINK token: the caller has ALREADY proven
     * knowledge of the code + phone (the tracking bar); this scoped,
     * MAC-sealed, 30-day capability lets them re-open the printable
     * receipt on /sites/[id]/receipt without re-entering anything —
     * shareable in chat/email by the customer's own choice. The token
     * carries only the two ids (no PII); the page re-checks the binding
     * and renders the SAME guest projection as this endpoint. */
    receiptToken: issueReceiptToken(instanceId, order.id),
  };
}
