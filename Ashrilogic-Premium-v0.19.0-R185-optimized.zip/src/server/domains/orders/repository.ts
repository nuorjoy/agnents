import type { Instance, SiteCustomer, SiteOrder } from "@prisma/client";
import { db } from "@/lib/db";

/**
 * Ashrilogic — orders domain REPOSITORY (ROUND 128).
 *
 * The persistence seam of the fourth route→controller→service→repository
 * decomposition (after packages/plan-orders/store): every Prisma lookup
 * the two legacy guest-checkout handlers previously inlined lives here
 * and nowhere else.
 *
 * The PLACEMENT TRANSACTION core keeps its own Prisma usage (the
 * `db.$transaction` block with per-row CAS decrements, coupon
 * redemption, the R120 ledgers and the idempotency guard writes) — the
 * plan-orders precedent: a transactional state machine stays coherent in
 * the service; this repository owns the route-level lookups around it.
 *
 * Behavior is lifted VERBATIM from the legacy handlers — the exact
 * `select`/`where` shapes, the exact soft-delete filters, the exact
 * ordering. Byte-compatibility is the contract.
 */

/** The published-site gate probe — the EXACT select shape the two legacy
 *  handlers repeated (site → instance → package; entitlement input). */
export type SiteGateRow = {
  published: boolean;
  instance: {
    packageId: string | null;
    trialEndsAt: Date | null;
    planExpiresAt: Date | null;
    featureOverridesJson: string | null;
    bannedPermanently: boolean;
    bannedUntil: Date | null;
    package: { capabilitiesJson: string | null; nameAr: string; nameEn: string } | null;
  };
};

/** The published-site gate read (entitlement input for the stop gate). */
export async function findSiteGate(instanceId: string): Promise<SiteGateRow | null> {
  return db.site.findUnique({
    where: { instanceId },
    select: {
      published: true,
      instance: {
        select: {
          packageId: true,
          trialEndsAt: true,
          planExpiresAt: true,
          featureOverridesJson: true,
          bannedPermanently: true,
          bannedUntil: true,
          package: { select: { capabilitiesJson: true, nameAr: true, nameEn: true } },
        },
      },
    },
  });
}

/**
 * The live-instance catalog probe (ROUND 49 column narrowing — the sealed
 * admin identity, password hash and blind index never enter a public
 * request context; ROUND 87 — a trashed workspace accepts no orders).
 */
export async function findLiveCatalogInstance(
  instanceId: string
): Promise<Pick<Instance, "id" | "orgJson" | "modulesJson"> | null> {
  return db.instance.findUnique({
    where: { id: instanceId, deletedAt: null },
    select: { id: true, orgJson: true, modulesJson: true },
  });
}

/** ROUND 87 — trashed (soft-deleted) contacts are never reused: the trash
 *  engine mangles their emailIndex, and this filter is the
 *  belt+suspenders so a fresh guest row is created instead. */
export async function findGuestByEmailIndex(
  instanceId: string,
  emailIndex: string | undefined
): Promise<SiteCustomer | null> {
  return db.siteCustomer.findFirst({
    where: { instanceId, emailIndex: emailIndex ?? undefined, deletedAt: null },
  });
}

/** The guest contact CREATE (email/phone AES-256-GCM at rest, keyed blind
 *  index for email lookups, ROUND 120 passwordHash NULL — no KDF burn for
 *  a secret nobody can ever present). Throws the raw Prisma error on
 *  anything but success — the P2002 race is handled by the caller. */
export async function createGuestCustomer(data: {
  instanceId: string;
  name: string;
  email: string;
  emailIndex: string | null;
  phone: string | null;
  passwordHash: null;
}): Promise<SiteCustomer> {
  return db.siteCustomer.create({ data });
}

/** Best-effort sealed-contact refresh for a signed-in shopper (ROUND 65 —
 *  typed contact data keeps the row current; the order still places when
 *  the refresh loses a race). Returns the UPDATED row or the original on
 *  any failure — never throws. */
export async function refreshCustomerContact(
  row: SiteCustomer,
  data: Record<string, unknown>
): Promise<SiteCustomer> {
  try {
    return await db.siteCustomer.update({ where: { id: row.id }, data });
  } catch {
    return row;
  }
}

/** The idempotency guard row read (replay / conflict resolution). */
export type OrderIdempotencyRow = {
  key: string;
  instanceId: string;
  requestHash: string;
  status: string;
  orderId: string | null;
  responseJson: string | null;
  createdAt: Date;
  completedAt: Date | null;
};

export async function findOrderIdempotency(
  key: string
): Promise<OrderIdempotencyRow | null> {
  return db.orderIdempotency.findUnique({ where: { key } });
}

/** The lazy guard-row eviction (expired replay / crashed in-flight
 *  holder) — both the pre-check path and the stale-sweep use it. Failures
 *  are swallowed by the callers (housekeeping, never request-critical). */
export async function deleteOrderIdempotency(key: string): Promise<void> {
  await db.orderIdempotency.delete({ where: { key } }).catch(() => undefined);
}

/** The tracking projection input — the EXACT legacy select shape (no
 *  customer PII: items, totals, status trail, timestamps only). */
export type TrackableOrderRow = Pick<
  SiteOrder,
  | "id"
  | "code"
  | "itemsJson"
  | "total"
  | "discount"
  | "couponCode"
  | "currency"
  | "status"
  | "statusNote"
  | "statusHistoryJson"
  | "createdAt"
  | "updatedAt"
>;

/**
 * The trackable-order lookup (POST /api/sites/[id]/orders/track): code +
 * keyed phone index must BOTH match; NULL-phone orders (guest gave no
 *  number) are simply not trackable — the lookup misses them by design.
 * ROUND 87 — a trashed (soft-deleted) order is NOT trackable (its code is
 * mangled anyway; the filter is belt+suspenders).
 */
export async function findTrackableOrder(
  instanceId: string,
  code: string,
  phoneIndex: string
): Promise<TrackableOrderRow | null> {
  return db.siteOrder.findFirst({
    where: { instanceId, code, phoneIndex, deletedAt: null },
    select: {
      id: true,
      code: true,
      itemsJson: true,
      total: true,
      discount: true,
      couponCode: true,
      currency: true,
      status: true,
      statusNote: true,
      statusHistoryJson: true,
      createdAt: true,
      updatedAt: true,
    },
  });
}
