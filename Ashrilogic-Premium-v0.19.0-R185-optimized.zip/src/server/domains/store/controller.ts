import { NextResponse } from "next/server";
import { z } from "zod";
import { clientIp } from "@/lib/server/rate-limit";
import { clampLimit, decodeKeyset } from "@/lib/server/keyset";
import { routeHandler, ctxBody } from "@/lib/server/route";
import * as service from "./service";

/**
 * Ashrilogic — store domain CONTROLLER (ROUND 126; ROUND 127 — the guards
 * are now DECLARATIVE).
 *
 * The HTTP seam for the PUBLIC storefront surface. Every handler is a
 * routeHandler(...) (ROUND 124's unified wrapper: correlation ids, the 500
 * envelope with the route's own verb phrase, redacted structured telemetry
 * — the labels "load the store" / "validate the coupon" / "load reviews" /
 * "submit review" reproduce the legacy 500 strings byte-for-byte).
 *
 * ROUND 127 — the guard sequences are declared in the wrapper config and
 * the wrapper translates each stage into the REAL guard call, preserving
 * the historical sequences byte-for-byte (including their asymmetries):
 *  - catalog GET: NO origin check (public read), the entitlement gate in
 *    the service;
 *  - coupon POST: originViolation FIRST (the origin stage), then the body
 *    + schema with the LEGACY custom 400 ("Invalid coupon request" — the
 *    body stage), then the validation throttle (rateLimit.afterBody: an
 *    INVALID request never burns a hit — the historical semantics), then
 *    the gate;
 *  - reviews GET: NO origin check; query validation (recordId, cursor)
 *    BEFORE the gate (kept inline — it is query-shape logic, not a guard);
 *  - reviews POST: origin FIRST, then the maintenance block, the guest
 *    throttle (default position — a re-submission of an existing review
 *    also burns a hit), then the body + schema ("Invalid review"), then
 *    the gate.
 *
 * The Zod envelopes here are the LEGACY custom strings, NOT zodError —
 * these routes never used the shared mapper's envelope, and
 * byte-compatibility is the contract.
 */

/** validation throttling: 20 attempts / 10 min per source IP + site — the
 *  endpoint answers "is this code any good", which makes it a probing
 *  surface for code enumeration; the cap keeps brute force impractical. */
const VALIDATE_RULE = { limit: 20, windowMs: 10 * 60 * 1000 };

/** review submission throttling: 8 reviews / hour per source IP + site. */
const REVIEW_RULE = { limit: 8, windowMs: 60 * 60 * 1000 };

/** reviews page sizing (keyset contract). */
const DEFAULT_LIMIT = 10;
const MAX_LIMIT = 20;

const validateSchema = z.object({
  code: z.string().trim().min(3).max(32),
  /** cart subtotal in minor units — used ONLY for the min-subtotal rule and
   *  the previewed discount; the placement path always re-derives both from
   *  server-side prices. */
  subtotal: z.number().int().min(0),
});

const reviewSchema = z.object({
  recordId: z.string().min(1).max(64),
  rating: z.number().int().min(1).max(5),
  name: z.string().trim().min(2).max(60),
  body: z.string().trim().max(500).optional(),
});

/** Segment shape for the [id] routes (Next 16: params is a Promise). */
interface SiteSegment {
  params: Promise<{ id: string }>;
}

/** GET /api/sites/[id]/store — the PUBLIC storefront catalog. */
export const catalogGet = routeHandler(
  "load the store",
  async (ctx, segment: SiteSegment): Promise<NextResponse> => {
    const { id } = await segment.params;

    const url = new URL(ctx.req.url);
    const q = (url.searchParams.get("q") ?? "").trim().toLowerCase().slice(0, 80);
    const category = (url.searchParams.get("category") ?? "").trim().slice(0, 120);

    const payload = await service.getCatalog(id, { q, category });
    return NextResponse.json(payload);
  }
);

/** POST /api/sites/[id]/store/coupon — validate a coupon code (guest). */
export const couponValidate = routeHandler(
  "validate the coupon",
  {
    origin: true,
    body: {
      schema: validateSchema,
      invalid: { error: "Invalid coupon request" },
    },
    rateLimit: {
      key: (parts) => `coupon-validate:${parts.params.id}:${parts.ip}`,
      rule: VALIDATE_RULE,
      body: { error: "Too many attempts — please wait", code: "RATE" },
      afterBody: true,
    },
  },
  async (ctx, segment: SiteSegment): Promise<NextResponse> => {
    const { id } = await segment.params;
    const parsed = ctxBody<typeof validateSchema._output>(ctx);
    const payload = await service.validateCoupon(id, parsed);
    return NextResponse.json(payload);
  }
);

/** GET /api/sites/[id]/store/reviews — one product's visible reviews. */
export const reviewsList = routeHandler(
  "load reviews",
  async (ctx, segment: SiteSegment): Promise<NextResponse> => {
    const { id } = await segment.params;

    const url = new URL(ctx.req.url);
    const recordId = (url.searchParams.get("recordId") ?? "").trim();
    if (!recordId || recordId.length > 64) {
      return NextResponse.json({ error: "A product (recordId) is required" }, { status: 400 });
    }
    const limit = clampLimit(url.searchParams.get("limit"), DEFAULT_LIMIT, MAX_LIMIT);
    const cursorRaw = url.searchParams.get("cursor");
    const cursor = cursorRaw ? decodeKeyset(cursorRaw) : null;
    /* malformed cursor → loud 400 (never silently re-read page one) */
    if (cursorRaw && !cursor) {
      return NextResponse.json(
        { error: "Invalid pagination cursor", code: "BAD_CURSOR" },
        { status: 400 }
      );
    }

    const payload = await service.listReviews(id, recordId, cursor, limit);
    return NextResponse.json(payload);
  }
);

/** POST /api/sites/[id]/store/reviews — guest submission. */
export const reviewsSubmit = routeHandler(
  "submit review",
  {
    origin: true,
    maintenance: true,
    rateLimit: {
      key: (parts) => `site-review:${parts.params.id}:${parts.ip}`,
      rule: REVIEW_RULE,
      body: { error: "Too many reviews" },
    },
    body: {
      schema: reviewSchema,
      invalid: { error: "Invalid review" },
    },
  },
  async (ctx, segment: SiteSegment): Promise<NextResponse> => {
    const { id } = await segment.params;
    const parsed = ctxBody<typeof reviewSchema._output>(ctx);

    const result = await service.submitReview(
      id,
      {
        recordId: parsed.recordId,
        rating: parsed.rating,
        name: parsed.name,
        body: parsed.body ?? null,
      },
      clientIp(ctx.req)
    );
    return NextResponse.json(result, { status: result.updated ? 200 : 201 });
  }
);
