import type { SiteReview } from "@prisma/client";
import { db } from "@/lib/db";
import type {
  SiteProductDTO,
  SiteRatingSummaryDTO,
  SiteReviewDTO,
  StoreInfoDTO,
} from "@/lib/types";
import { computeEntitlement } from "@/lib/server/entitlement";
import { isValidMinorUnits } from "@/lib/server/money";
import { evaluateCoupon, normalizeCouponCode } from "@/lib/server/coupons";
import { blindIndex } from "@/lib/server/crypto-vault";
import {
  attachRatingAggregates,
  loadRatingSummary,
  loadStoreProducts,
  storeInfo,
} from "@/lib/server/store-mapper";
import { encodeKeyset, type KeysetCursor } from "@/lib/server/keyset";
import { HttpError } from "@/lib/server/route";
import * as repository from "./repository";

/**
 * Ashrilogic — store domain SERVICE (ROUND 126).
 *
 * Business flows for the PUBLIC storefront surface (catalog, coupon
 * validation, product reviews), lifted verbatim from the three legacy
 * route handlers and composed over the shared catalog mappers
 * (src/lib/server/store-mapper.ts) and the coupon engine
 * (src/lib/server/coupons.ts).
 *
 * Error policy: the legacy handlers returned inline
 * `NextResponse.json({ error, code? }, { status })` shapes; here those
 * become HttpError throws with the SAME status/message/code — the unified
 * wrapper (ROUND 124) renders the identical envelope.
 */

/** Which plan feature each public surface requires (ROUND 79). */
export type StoreFeature = "store" | "coupons" | "reviews";

/**
 * The shared public gate: a PUBLISHED site on a workspace that is not
 * trial-locked AND whose plan includes the surface's feature. Everything
 * else is the legacy 404 "Store not available" — the exact envelope all
 * four handlers returned.
 */
async function assertStoreOpen(instanceId: string, feature: StoreFeature): Promise<void> {
  const site = await repository.findSiteGate(instanceId);
  const ent = site ? computeEntitlement(site.instance) : null;
  const stopped = !ent || ent.state === "locked" || ent.features[feature] !== true;
  if (!site || !site.published || stopped) {
    throw new HttpError(404, "Store not available");
  }
}

/** Public projection — authorIndex (blind IP index) and the moderation
 *  state are server-side concerns and never enter a public payload. */
function toReviewDTO(row: SiteReview): SiteReviewDTO {
  return {
    id: row.id,
    recordId: row.recordId,
    rating: row.rating,
    name: row.name,
    body: row.body,
    createdAt: row.createdAt.toISOString(),
  };
}

/**
 * GET flow — the public catalog: derived products with rating aggregates,
 * server-side search/category filtering, and the per-category counts over
 * the UNFILTERED catalog (ROUND 51 — the chips show honest numbers while a
 * filter is active). The unavailable-store path (no catalog module) keeps
 * the legacy 200-with-empty-products shape, never a 404.
 */

/** The public catalog payload (info + products + facets). The facets are
 *  ABSENT on the unavailable-store path — the legacy response shape
 *  (`{ ...info, products: [] }`) never carried them, and byte-compatibility
 *  is the contract of this decomposition. */
export interface StoreCatalogDTO extends StoreInfoDTO {
  products: SiteProductDTO[];
  categories?: string[];
  categoryCounts?: Record<string, number>;
}

export async function getCatalog(
  instanceId: string,
  filters: { q: string; category: string }
): Promise<StoreCatalogDTO> {
  await assertStoreOpen(instanceId, "store");

  /* ROUND 49/87 — column-narrowed read; a trashed workspace's storefront
   * is GONE. */
  const instance = await repository.findLiveInstance(instanceId);
  if (!instance) {
    throw new HttpError(404, "Store not available");
  }

  const info = storeInfo(instance);
  if (!info.available) {
    return { ...info, products: [] };
  }

  const products = await loadStoreProducts(instance);

  /* ROUND 63 — visible-review rating aggregates ride every product of the
   * public payload (fail-soft). Attached BEFORE filtering so
   * search/category views show the same stars as the full grid. */
  await attachRatingAggregates(products, instanceId);

  const { q, category } = filters;
  const filtered = products.filter((p) => {
    const matchesQ =
      !q || p.name.toLowerCase().includes(q) || p.category.toLowerCase().includes(q);
    const matchesCategory = !category || p.category === category;
    return matchesQ && matchesCategory;
  });

  const categoryCounts: Record<string, number> = {};
  for (const p of products) {
    if (p.category) categoryCounts[p.category] = (categoryCounts[p.category] ?? 0) + 1;
  }

  return {
    ...info,
    products: filtered,
    categories: [...new Set(products.map((p) => p.category).filter(Boolean))].sort(),
    categoryCounts,
  };
}

/**
 * POST /coupon flow — validate a coupon code against the CURRENT cart.
 * The subtotal is client-supplied for PREVIEW only; the authoritative
 * discount is recomputed inside the placement transaction. Machine reasons
 * map to their distinct legacy statuses (404 notFound / 409 the rest) with
 * the reason as the envelope's machine code.
 */
export async function validateCoupon(
  instanceId: string,
  input: { code: string; subtotal: number }
): Promise<{
  code: string;
  kind: "fixed" | "percent";
  value: number;
  discountMinor: number;
  minSubtotal: number | null;
}> {
  await assertStoreOpen(instanceId, "coupons");

  const code = normalizeCouponCode(input.code);
  const coupon = await repository.findLiveCoupon(instanceId, code);

  const verdict = evaluateCoupon(coupon, input.subtotal);
  if (!verdict.ok) {
    const REASON_STATUS: Record<string, number> = {
      notFound: 404,
      inactive: 409,
      window: 409,
      exhausted: 409,
      minSubtotal: 409,
    };
    throw new HttpError(
      REASON_STATUS[verdict.reason] ?? 404,
      "Coupon not applicable",
      verdict.reason.toUpperCase()
    );
  }

  const { coupon: c, discountMinor } = verdict;
  if (!isValidMinorUnits(discountMinor)) {
    /* the legacy no-code 409 (kept verbatim — distinct from the reason
     * codes above) */
    throw new HttpError(409, "Coupon not applicable");
  }

  return {
    code: c.code,
    kind: c.kind === "fixed" ? "fixed" : "percent",
    value: c.value,
    discountMinor,
    minSubtotal: c.minSubtotal,
  };
}

/**
 * GET /reviews flow — one product's VISIBLE reviews, newest first,
 * keyset-paginated, plus the recomputed visible-only rating summary.
 */
export async function listReviews(
  instanceId: string,
  recordId: string,
  cursor: KeysetCursor | null,
  limit: number
): Promise<{
  reviews: SiteReviewDTO[];
  nextCursor: string | null;
  summary: SiteRatingSummaryDTO;
}> {
  await assertStoreOpen(instanceId, "reviews");

  /* take limit+1 so the extra row only signals hasMore (never returned) */
  const rows = await repository.listVisibleReviewsPage(instanceId, recordId, cursor, limit + 1);
  const hasMore = rows.length > limit;
  const page = hasMore ? rows.slice(0, limit) : rows;
  const nextCursor =
    hasMore && page.length > 0 ? encodeKeyset(page[page.length - 1]) : null;

  const summary = await loadRatingSummary(instanceId, recordId);

  return { reviews: page.map(toReviewDTO), nextCursor, summary };
}

/**
 * POST /reviews flow — guest submission (no account, no session). One
 * review per visitor per product, keyed by the blind index of the client
 * IP (no raw PII at rest): a re-submission UPDATES rating/name/body and
 * never resets the moderation state; a racing twin submission (P2002
 * between the miss and the insert) lands as the intended update too.
 */
export async function submitReview(
  instanceId: string,
  input: { recordId: string; rating: number; name: string; body: string | null },
  clientIp: string
): Promise<{ review: SiteReviewDTO; updated: boolean }> {
  await assertStoreOpen(instanceId, "reviews");

  /* ROUND 87 — a trashed (soft-deleted) workspace accepts NO reviews. */
  const instance = await repository.findLiveInstance(instanceId);
  if (!instance) {
    throw new HttpError(404, "Store not available");
  }

  /* the review target must be a product the storefront actually lists —
   * the SELLABLE catalog (a hidden/out-of-stock/unreleased row cannot
   * accumulate public reviews). */
  const products = await loadStoreProducts(instance);
  if (!products.some((p) => p.recordId === input.recordId)) {
    throw new HttpError(404, "Product not found");
  }

  const content = { rating: input.rating, name: input.name, body: input.body };

  const authorIndex = blindIndex(clientIp) ?? null;
  if (authorIndex) {
    const existing = await repository.findLiveAuthorReview(
      instanceId,
      input.recordId,
      authorIndex
    );
    if (existing) {
      const updated = await repository.updateReviewContent(existing.id, content);
      return { review: toReviewDTO(updated), updated: true };
    }
  }

  try {
    const created = await repository.createReview({
      instanceId,
      recordId: input.recordId,
      ...content,
      authorIndex,
    });
    /* ROUND 141 (owner notifications, directive ㉜) — a NEW review rides
     * the workspace activity feed (zero-delay for the owner's bell). */
    try {
      await db.activity.create({
        data: {
          instanceId,
          kind: "actReviewReceived",
          metaJson: JSON.stringify({ rating: input.rating, recordId: input.recordId }),
        },
      });
    } catch {
      /* the feed is best-effort — never blocks the shopper's submission */
    }
    return { review: toReviewDTO(created), updated: false };
  } catch (createError) {
    /* a racing twin submission landed between our miss and the insert —
     * re-find and update (the intended upsert); anything else is real.
     * ROUND 87 — live rows only (same trash law as the first lookup). */
    if ((createError as { code?: string }).code === "P2002" && authorIndex) {
      const raced = await repository.findLiveAuthorReview(
        instanceId,
        input.recordId,
        authorIndex
      );
      if (raced) {
        const updated = await repository.updateReviewContent(raced.id, content);
        return { review: toReviewDTO(updated), updated: true };
      }
    }
    throw createError;
  }
}
