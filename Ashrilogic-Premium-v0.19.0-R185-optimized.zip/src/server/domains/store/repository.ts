import type { Instance, Site, SiteReview, StoreCoupon } from "@prisma/client";
import { db } from "@/lib/db";
import { keysetPredicate, type KeysetCursor } from "@/lib/server/keyset";

/**
 * Ashrilogic — store domain REPOSITORY (ROUND 126).
 *
 * The persistence seam of the third route→controller→service→repository
 * decomposition (after packages, ROUND 124, and plan-orders, ROUND 125):
 * every Prisma lookup the three storefront route handlers previously
 * inlined lives here and nowhere else. The shared catalog mappers
 * (loadStoreProducts / storeInfo / attachRatingAggregates /
 * loadRatingSummary — src/lib/server/store-mapper.ts) keep their own
 * Prisma usage: they are the shared domain core, imported by the owner
 * console's routes as well; this repository owns the route-level
 * lookups around them.
 *
 * Behavior is lifted VERBATIM from the legacy handlers — the exact
 * `select`/`include` shapes, the exact ordering, the exact caps and
 * soft-delete filters.
 */

/** The entitlement gate lookup's site shape (shared by all four handlers).
 *  Site.instance is a REQUIRED relation — never null when the row exists. */
export type SiteGateRow = Pick<Site, "published"> & {
  instance: {
    packageId: string | null;
    trialEndsAt: Date | null;
    planExpiresAt: Date | null;
    featureOverridesJson: string | null;
    bannedPermanently: boolean;
    bannedUntil: Date | null;
    package: { capabilitiesJson: string | null; nameAr: string; nameEn: string } | null;
  };
};

/**
 * The published-site gate probe — the EXACT select shape all four legacy
 * handlers repeated (site → instance → package). Returns null when no Site
 * row exists for the instance id.
 */
export async function findSiteGate(instanceId: string): Promise<SiteGateRow | null> {
  return db.site.findUnique({
    where: { instanceId },
    select: {
      published: true,
      instance: {
        select: {
          packageId: true,
          trialEndsAt: true,
          planExpiresAt: true,
          featureOverridesJson: true,
          bannedPermanently: true,
          bannedUntil: true,
          package: { select: { capabilitiesJson: true, nameAr: true, nameEn: true } },
        },
      },
    },
  });
}

/**
 * The live-instance catalog probe (ROUND 49 column narrowing — the sealed
 * admin identity, password hash and blind index never enter a public
 * request context; ROUND 87 — a trashed workspace's storefront is GONE).
 */
export async function findLiveInstance(
  instanceId: string
): Promise<Pick<Instance, "id" | "orgJson" | "modulesJson"> | null> {
  return db.instance.findUnique({
    where: { id: instanceId, deletedAt: null },
    select: { id: true, orgJson: true, modulesJson: true },
  });
}

/**
 * ROUND 87 — trashed (soft-deleted) coupons NEVER validate (the engine
 * mangles their code so the lookup misses; this filter is the hard
 * guarantee). Unique per (instanceId, code).
 */
export async function findLiveCoupon(
  instanceId: string,
  code: string
): Promise<StoreCoupon | null> {
  return db.storeCoupon.findUnique({
    where: { instanceId_code: { instanceId, code }, deletedAt: null },
  });
}

/**
 * One keyset-resumed page of VISIBLE reviews, newest first — take limit+1
 * so the extra row only signals hasMore (the caller slices it off).
 * ROUND 87 — trashed (soft-deleted) reviews never render publicly.
 */
export async function listVisibleReviewsPage(
  instanceId: string,
  recordId: string,
  cursor: KeysetCursor | null,
  take: number
): Promise<SiteReview[]> {
  return db.siteReview.findMany({
    where: {
      instanceId,
      recordId,
      hidden: false,
      deletedAt: null,
      ...(cursor ? keysetPredicate(cursor) : {}),
    },
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    take,
  });
}

/**
 * The one-review-per-visitor upsert probe: the live row keyed by the blind
 * index of the client IP. ROUND 87 — a trashed review by this author is NOT
 * found (its authorIndex is mangled anyway; this filter is the safety net).
 */
export async function findLiveAuthorReview(
  instanceId: string,
  recordId: string,
  authorIndex: string
): Promise<SiteReview | null> {
  return db.siteReview.findUnique({
    where: {
      instanceId_recordId_authorIndex: { instanceId, recordId, authorIndex },
      deletedAt: null,
    },
  });
}

/** The re-submission UPDATE — rating/name/body only, never the moderation
 *  state (hidden) and never the author key. */
export async function updateReviewContent(
  reviewId: string,
  data: { rating: number; name: string; body: string | null }
): Promise<SiteReview> {
  return db.siteReview.update({ where: { id: reviewId }, data });
}

/** The fresh-row INSERT (guest's first review of this product). */
export async function createReview(data: {
  instanceId: string;
  recordId: string;
  rating: number;
  name: string;
  body: string | null;
  authorIndex: string | null;
}): Promise<SiteReview> {
  return db.siteReview.create({ data });
}
