import { NextResponse } from "next/server";
import { z } from "zod";
import { routeHandler, ctxAdmin, ctxTenant } from "@/lib/server/route";
import * as service from "./service";

/**
 * Ashrilogic — ROUND 141 (متجر الإضافات): the add-on orders CONTROLLER.
 *
 * The HTTP seam for the Add-ons Store — every handler is a routeHandler
 * (ROUND 124's unified wrapper), with the same declarative guard shape the
 * plan-orders controller uses:
 *  - tenant surfaces require the billing.manage permission (add-on
 *    purchases are a billing flow), origin-checked on mutations;
 *  - the console queue + confirmation are super/admin-gated with the
 *    confirmation throttle;
 *  - the create throttle bounds runaway cart clicks.
 */

/** Confirmation throttle: 20 confirmations / 10 min per admin + IP. */
const CONFIRM_RULE = { limit: 20, windowMs: 10 * 60 * 1000 };
/** Add-on order creation throttle: 5 requests / 10 min per workspace + IP. */
const ORDER_RULE = { limit: 5, windowMs: 10 * 60 * 1000 };

interface InstanceSegment {
  params: Promise<{ id: string }>;
}
interface OrderSegment {
  params: Promise<{ id: string; orderId: string }>;
}

const addonOrderCreateSchema = z.object({
  /** the add-on feature keys (validated against the catalog + the live
   *  effective map — the server never trusts the client's amount) */
  features: z.array(z.string().min(1).max(48)).min(1).max(8),
  cycle: z.enum(["monthly", "yearly"]),
  methodId: z.string().min(1).max(64),
  /** ROUND 141 — the INSTANT wallet checkout (the wallet pays; activation
   *  is immediate — no admin confirmation round-trip). */
  payWith: z.literal("wallet").optional(),
});

/** GET /api/admin/addon-orders — the console's add-on requests queue. */
export const adminList = routeHandler(
  "list addon orders",
  { admin: {} },
  async (ctx): Promise<NextResponse> => {
    const raw = new URL(ctx.req.url).searchParams.get("status");
    const status =
      raw === "pending" || raw === "paid" || raw === "cancelled" ? raw : undefined;
    const orders = await service.listConsole(status);
    return NextResponse.json(orders);
  }
);

/** PATCH /api/admin/addon-orders/[id] — confirm receipt / cancel request. */
export const adminConfirmOrCancel = routeHandler(
  "update addon order",
  {
    origin: true,
    admin: {
      manualRoles: {
        roles: ["super", "admin"],
        denied: {
          error: "This action requires one of: super, admin",
          code: "ADMIN_FORBIDDEN_ROLE",
        },
      },
    },
    rateLimit: {
      key: (parts) => `addon-confirm:${parts.adminId()}:${parts.ip}`,
      rule: CONFIRM_RULE,
      body: { error: "Too many confirmations — try again shortly", code: "RATE_LIMITED" },
    },
  },
  async (ctx, segment: { params: Promise<{ id: string }> }): Promise<NextResponse> => {
    const admin = ctxAdmin(ctx);
    const { id } = await segment.params;

    const body = (await ctx.readBody()) as { action?: unknown };
    const action = body?.action;
    if (action !== "paid" && action !== "cancelled") {
      return NextResponse.json(
        { error: 'action must be "paid" or "cancelled"' },
        { status: 400 }
      );
    }

    const result = await service.confirmOrCancel(id, action, {
      id: admin.id,
      name: admin.name,
    });
    return NextResponse.json(result);
  }
);

/** GET /api/instances/[id]/addon-orders — the catalog + own history. */
export const tenantList = routeHandler(
  "list addon orders",
  { tenant: { permission: "billing.manage" } },
  async (_ctx, segment: InstanceSegment): Promise<NextResponse> => {
    const { id } = await segment.params;
    const payload = await service.catalogFor(id);
    return NextResponse.json(payload);
  }
);

/** POST /api/instances/[id]/addon-orders — create an add-on purchase request. */
export const tenantCreate = routeHandler(
  "create addon order",
  {
    tenant: { permission: "billing.manage", withRequest: true },
    rateLimit: {
      key: (parts) => `addon-order:${parts.params.id}:${parts.ip}`,
      rule: ORDER_RULE,
      body: { error: "Too many add-on requests — try again shortly", code: "RATE_LIMITED" },
    },
  },
  async (ctx, segment: InstanceSegment): Promise<NextResponse> => {
    const { id } = await segment.params;
    const guard = ctxTenant(ctx);

    const input = await ctx.parseBody(addonOrderCreateSchema);

    const result = await service.createOwn(
      id,
      { features: input.features, cycle: input.cycle, methodId: input.methodId },
      {
        kind: guard.principal.kind,
        actorId: guard.principal.actorId,
        actorName: guard.principal.actorName,
      }
    );
    return NextResponse.json(result, { status: 201 });
  }
);

/** PATCH /api/instances/[id]/addon-orders/[orderId] — cancel own request. */
export const tenantCancel = routeHandler(
  "update addon order",
  { tenant: { permission: "billing.manage", withRequest: true } },
  async (ctx, segment: OrderSegment): Promise<NextResponse> => {
    const { id, orderId } = await segment.params;
    const guard = ctxTenant(ctx);

    const body = (await ctx.readBody()) as { action?: unknown };
    const action = body?.action;
    if (action !== "cancel") {
      return NextResponse.json({ error: 'Only { action: "cancel" } is supported' }, { status: 400 });
    }

    const order = await service.cancelOwn(id, orderId, {
      kind: guard.principal.kind,
      actorId: guard.principal.actorId,
      actorName: guard.principal.actorName,
    });
    return NextResponse.json(order);
  }
);
