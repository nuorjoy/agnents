import { db } from "@/lib/db";
import type { AddonOrder, Instance } from "@prisma/client";

/**
 * Ashrilogic — ROUND 141 (متجر الإضافات): the add-on orders REPOSITORY.
 *
 * Pure data access for the addon-orders domain (the service layer in
 * ./service.ts owns the business flows; the controllers in
 * ./controller.ts own the HTTP seam).
 */

export const CONSOLE_LIST_CAP = 300;
export const OWN_LIST_CAP = 50;

export type ConsoleAddonRow = AddonOrder & {
  instance: { id: string; systemId: string; orgJson: string } | null;
};

/** Admin console listing, newest first, optional status filter. */
export async function listForConsole(status?: "pending" | "paid" | "cancelled"): Promise<ConsoleAddonRow[]> {
  return db.addonOrder.findMany({
    where: status ? { status } : undefined,
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    take: CONSOLE_LIST_CAP,
    include: { instance: { select: { id: true, systemId: true, orgJson: true } } },
  });
}

/** Tenant's own history, newest first. */
export async function listForInstance(instanceId: string): Promise<AddonOrder[]> {
  return db.addonOrder.findMany({
    where: { instanceId },
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    take: OWN_LIST_CAP,
  });
}

/** The ownership cross-check for the tenant cancel path: the order's
 *  instanceId must EQUAL the session-bound instance id (cross-tenant ids
 *  are 404s, never actionable). */
export async function findOrderInstanceRef(
  orderId: string
): Promise<Pick<AddonOrder, "instanceId"> | null> {
  return db.addonOrder.findUnique({ where: { id: orderId }, select: { instanceId: true } });
}

/** The live workspace row (package joined for the entitlement derivation). */
export async function findLiveInstance(id: string): Promise<
  (Instance & { package?: { capabilitiesJson?: string | null; nameAr?: string; nameEn?: string } | null }) | null
> {
  return db.instance.findFirst({
    where: { id, deletedAt: null },
    include: { package: { select: { capabilitiesJson: true, nameAr: true, nameEn: true } } },
  });
}

/** ROUND 162 — the wallet-checkout race probe: when the instant checkout's
 *  confirm loses the status flip to a concurrent admin confirm
 *  (ORDER_NOT_PENDING), the saga re-reads the order to decide between
 *  compensating (refund + cancel) and accepting the raced PAID outcome
 *  (the debit already bought the activated features). */
export async function findPaidOrder(orderId: string): Promise<AddonOrder | null> {
  const order = await db.addonOrder.findUnique({ where: { id: orderId } });
  return order && order.status === "paid" ? order : null;
}
