import { NextResponse } from "next/server";
import { z } from "zod";
import { routeHandler, ctxAdmin, ctxTenant } from "@/lib/server/route";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { toDisplayUnits } from "@/lib/server/money";
import { rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { verifyPasswordArgon2id } from "@/lib/server/crypto-vault";
import { parseAmountInputToMinor } from "@/lib/amount-input";
import {
  adjustWallet,
  cancelWalletTopup,
  confirmWalletTopupPaid,
  createWalletTopup,
  lookupWalletByNo,
  toWalletTopupDTO,
  transferWalletFunds,
  walletSnapshot,
  WALLET_NO_MAX,
  WALLET_NO_MIN,
} from "@/lib/server/wallet";
import * as repository from "./repository";

/**
 * Ashrilogic — ROUND 141 (محفظة Ashrilogic): the wallet CONTROLLER.
 *
 * The HTTP seam for the platform wallet — every handler is a routeHandler
 * (ROUND 124's unified wrapper) with the same declarative guard shapes the
 * plan-orders controller uses:
 *  - tenant surfaces require the billing.manage permission and work while
 *    TRIAL-LOCKED (the wallet is a subscription surface — a locked
 *    workspace can still top up + pay for its renewal);
 *  - the console queue + confirmation are super/admin-gated (money-moving:
 *    audited unconditionally, retention floor);
 *  - the create throttle bounds runaway top-up clicks.
 */

/** Top-up creation throttle: 5 requests / 10 min per workspace + IP. */
const TOPUP_RULE = { limit: 5, windowMs: 10 * 60 * 1000 };
/** Console confirmation throttle: 20 confirmations / 10 min per admin + IP. */
const CONFIRM_RULE = { limit: 20, windowMs: 10 * 60 * 1000 };

interface InstanceSegment {
  params: Promise<{ id: string }>;
}
interface TopupSegment {
  params: Promise<{ id: string; topupId: string }>;
}

const topupCreateSchema = z.object({
  /** the RAW dual-numeral amount string (١٢٣ / 1,234.50 both legal) —
   *  parsed + bounded server-side (never a pre-computed number). */
  amount: z.string().min(1).max(32),
  methodId: z.string().min(1).max(64),
});

const adjustSchema = z.object({
  instanceId: z.string().min(1).max(64),
  amount: z.string().min(1).max(32),
  direction: z.enum(["credit", "debit"]),
  note: z.string().trim().max(160).optional().default(""),
});

/** GET /api/instances/[id]/wallet — the wallet projection (balance + the
 *  pending top-up total + recent ledger rows + top-up requests). */
export const tenantOverview = routeHandler(
  "read wallet",
  { tenant: { permission: "billing.manage" } },
  async (_ctx, segment: InstanceSegment): Promise<NextResponse> => {
    const { id } = await segment.params;
    const wallet = await walletSnapshot(id);
    return NextResponse.json(wallet);
  }
);

/** POST /api/instances/[id]/wallet/topup — create a top-up REQUEST (the
 *  amount arrives as the raw dual-numeral string; the server parses +
 *  bounds it, resolves the method, stamps the reference + instructions). */
export const tenantTopupCreate = routeHandler(
  "create wallet topup",
  {
    tenant: { permission: "billing.manage", withRequest: true },
    rateLimit: {
      key: (parts) => `wallet-topup:${parts.params.id}:${parts.ip}`,
      rule: TOPUP_RULE,
      body: { error: "Too many top-up requests — try again shortly", code: "RATE_LIMITED" },
    },
  },
  async (ctx, segment: InstanceSegment): Promise<NextResponse> => {
    const { id } = await segment.params;
    const guard = ctxTenant(ctx);

    const input = await ctx.parseBody(topupCreateSchema);

    const instance = await repository.findInstance(id);
    if (!instance) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }
    const result = await createWalletTopup(instance, input.amount, input.methodId);
    if (!result.ok) {
      return NextResponse.json(
        { error: result.error, ...(result.code ? { code: result.code } : {}) },
        { status: result.status }
      );
    }

    await logAudit({
      actorType: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: maskEmail(guard.principal.actorName),
      action: "instance.walletTopupCreate",
      targetLabel: result.topup.reference,
      meta: {
        amountMinor: String(result.topup.amountMinor),
        amountMajor: String(toDisplayUnits(result.topup.amountMinor)),
        method: result.topup.method,
        methodLabel: result.topup.methodLabel,
      },
    });

    return NextResponse.json(
      { topup: result.topup, instructions: result.instructions },
      { status: 201 }
    );
  }
);

/** PATCH /api/instances/[id]/wallet/topup/[topupId] — cancel the
 *  workspace's OWN pending request ({ action: "cancel" }). */
export const tenantTopupCancel = routeHandler(
  "cancel wallet topup",
  { tenant: { permission: "billing.manage", withRequest: true } },
  async (ctx, segment: TopupSegment): Promise<NextResponse> => {
    const { id, topupId } = await segment.params;
    const guard = ctxTenant(ctx);

    const body = (await ctx.readBody()) as { action?: unknown };
    if (body?.action !== "cancel") {
      return NextResponse.json({ error: 'Only { action: "cancel" } is supported' }, { status: 400 });
    }

    /* ownership: the topup must belong to THIS workspace (cross-tenant ids
     * are plain 404s — the legacy shape). */
    const row = await repository.findTopupOwner(topupId);
    if (!row || row.instanceId !== id) {
      return NextResponse.json({ error: "Top-up request not found" }, { status: 404 });
    }

    const result = await cancelWalletTopup(topupId);
    if (!result.ok) {
      return NextResponse.json(
        { error: result.error, ...(result.code ? { code: result.code } : {}) },
        { status: result.status }
      );
    }

    await logAudit({
      actorType: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: maskEmail(guard.principal.actorName),
      action: "instance.walletTopupCancel",
      targetLabel: result.topup.reference,
      meta: { amountMinor: String(result.topup.amountMinor) },
    });

    return NextResponse.json({ ok: true });
  }
);

/** GET /api/admin/wallet-topups — the console's top-up requests queue
 *  (org + system identity attached per row). super/admin only —
 *  ROUND 146: this was the ONE money-adjacent console read still open to
 *  every admin role (`admin: {}` with no role list), contradicting the
 *  module header and every sibling money surface (adminTopupAction /
 *  adminAdjust / packages CUD). The console views that consume it
 *  (plan-orders queue, subscriber detail) are super/admin surfaces. */
export const adminTopupList = routeHandler(
  "list wallet topups",
  {
    admin: {
      manualRoles: {
        roles: ["super", "admin"],
        denied: {
          error: "This action requires one of: super, admin",
          code: "ADMIN_FORBIDDEN_ROLE",
        },
      },
    },
  },
  async (ctx): Promise<NextResponse> => {
    const raw = new URL(ctx.req.url).searchParams.get("status");
    const status = raw === "pending" || raw === "paid" || raw === "cancelled" ? raw : undefined;
    const rows = await repository.listTopupsForConsole(status);
    const payload = rows.map((row) => {
      let orgName = row.instance?.systemId ?? "—";
      try {
        const org = JSON.parse(row.instance?.orgJson ?? "{}") as { name?: unknown };
        if (typeof org.name === "string" && org.name.trim()) orgName = org.name.trim();
      } catch {
        /* corrupt orgJson — fall back to systemId */
      }
      return {
        ...toWalletTopupDTO(row),
        orgName,
        systemId: row.instance?.systemId ?? "",
        instanceId: row.instanceId,
      };
    });
    return NextResponse.json(payload);
  }
);

/** PATCH /api/admin/wallet-topups/[id] — confirm receipt (credits the
 *  wallet atomically) or cancel the request. super/admin only. */
export const adminTopupAction = routeHandler(
  "update wallet topup",
  {
    origin: true,
    admin: {
      manualRoles: {
        roles: ["super", "admin"],
        denied: {
          error: "This action requires one of: super, admin",
          code: "ADMIN_FORBIDDEN_ROLE",
        },
      },
    },
    rateLimit: {
      key: (parts) => `wallet-confirm:${parts.adminId()}:${parts.ip}`,
      rule: CONFIRM_RULE,
      body: { error: "Too many confirmations — try again shortly", code: "RATE_LIMITED" },
    },
  },
  async (ctx, segment: { params: Promise<{ id: string }> }): Promise<NextResponse> => {
    const admin = ctxAdmin(ctx);
    const { id } = await segment.params;

    const body = (await ctx.readBody()) as { action?: unknown };
    const action = body?.action;
    if (action !== "paid" && action !== "cancelled") {
      return NextResponse.json(
        { error: 'action must be "paid" or "cancelled"' },
        { status: 400 }
      );
    }

    const result =
      action === "paid"
        ? await confirmWalletTopupPaid(id, maskEmail(admin.name))
        : await cancelWalletTopup(id);
    if (!result.ok) {
      return NextResponse.json(
        { error: result.error, ...(result.code ? { code: result.code } : {}) },
        { status: result.status }
      );
    }

    await logAudit({
      actorType: "admin",
      actorId: admin.id,
      actorName: admin.name,
      action: action === "paid" ? "wallet.topupConfirm" : "instance.walletTopupCancel",
      targetLabel: result.topup.reference,
      meta: {
        instance: result.topup.instanceId,
        amountMinor: String(result.topup.amountMinor),
        amountMajor: String(toDisplayUnits(result.topup.amountMinor)),
        ...(action === "paid" && result.balanceAfterMinor >= 0
          ? { balanceAfterMinor: String(result.balanceAfterMinor) }
          : { by: "admin" }),
      },
    });

    return NextResponse.json({
      ok: true,
      ...(action === "paid" && result.balanceAfterMinor >= 0
        ? { balanceAfterMinor: result.balanceAfterMinor }
        : {}),
    });
  }
);

/** POST /api/admin/wallet-adjust — a direct console credit/debit (a
 *  complimentary balance or a correction). Accepts the RAW dual-numeral
 *  amount exactly like a top-up. super/admin only — MONEY-MOVING. */
export const adminAdjust = routeHandler(
  "adjust wallet",
  {
    origin: true,
    admin: {
      manualRoles: {
        roles: ["super", "admin"],
        denied: {
          error: "This action requires one of: super, admin",
          code: "ADMIN_FORBIDDEN_ROLE",
        },
      },
    },
    rateLimit: {
      key: (parts) => `wallet-adjust:${parts.adminId()}:${parts.ip}`,
      rule: CONFIRM_RULE,
      body: { error: "Too many adjustments — try again shortly", code: "RATE_LIMITED" },
    },
  },
  async (ctx): Promise<NextResponse> => {
    const admin = ctxAdmin(ctx);
    const input = await ctx.parseBody(adjustSchema);

    const result = await adjustWallet(
      input.instanceId,
      input.amount,
      input.direction,
      input.note,
      maskEmail(admin.name)
    );
    if (!result.ok) {
      return NextResponse.json(
        { error: result.error, ...(result.code ? { code: result.code } : {}) },
        { status: result.status }
      );
    }

    await logAudit({
      actorType: "admin",
      actorId: admin.id,
      actorName: admin.name,
      action: "wallet.adjust",
      targetLabel: input.instanceId.slice(0, 8),
      meta: {
        instance: input.instanceId,
        direction: input.direction,
        amount: input.amount,
        note: input.note,
        balanceAfterMinor: String(result.balanceAfterMinor),
      },
    });

    return NextResponse.json({ ok: true, balanceAfterMinor: result.balanceAfterMinor });
  }
);

/* ------------------------------------------------------------------ */
/* ROUND 144 — inter-wallet TRANSFERS (lookup + PIN-gated execution)   */
/* ------------------------------------------------------------------ */

/** Receiver-lookup throttle: 20 lookups / 10 min per workspace + IP. */
const TRANSFER_LOOKUP_RULE = { limit: 20, windowMs: 10 * 60 * 1000 };
/** Transfer execution throttle: 8 transfers / 10 min per workspace + IP. */
const TRANSFER_RULE = { limit: 8, windowMs: 10 * 60 * 1000 };
/** PIN failure throttle: 6 wrong PINs / 10 min per workspace (fail-closed).
 *  ROUND 145 — the SHARED `pin-fail:${id}` budget: the SAME secret
 *  (shiftCodeHash) arms the shift-open route, and that route burns this
 *  SAME key — one secret, ONE fail-closed budget (not two independent
 *  guessing budgets ≈ 2.3k guesses/day). */
const PIN_FAIL_RULE = { limit: 6, windowMs: 10 * 60 * 1000 };

const transferLookupSchema = z.object({
  walletNo: z.number().int().min(WALLET_NO_MIN).max(WALLET_NO_MAX),
});

const transferSchema = z.object({
  toWalletNo: z.number().int().min(WALLET_NO_MIN).max(WALLET_NO_MAX),
  /** the RAW dual-numeral amount string (١٢٣ / 1,234.50 both legal) —
   *  parsed + bounded server-side, never a pre-computed number. */
  amount: z.string().min(1).max(32),
  note: z.string().trim().max(120).optional().default(""),
  /** the owner's personal secret PIN (Argon2id-verified — the SAME PIN
   *  that arms the shift system; 4..8 digits). */
  pin: z
    .string()
    .trim()
    .regex(/^\d{4,8}$/, "The PIN is 4-8 digits"),
});

/** POST /api/instances/[id]/wallet/transfer/lookup — resolve a wallet
 *  NUMBER to the receiver preview the sender confirms before sending.
 *  The WORKSPACE OWNER session only (an admin console principal never
 *  transfers tenant money) + throttled (enumeration resistance). */
export const tenantTransferLookup = routeHandler(
  "lookup wallet receiver",
  {
    tenant: { permission: "billing.manage", withRequest: true },
    rateLimit: {
      key: (parts) => `wallet-lookup:${parts.params.id}:${parts.ip}`,
      rule: TRANSFER_LOOKUP_RULE,
      body: { error: "Too many lookups — try again shortly", code: "RATE_LIMITED" },
    },
  },
  async (ctx, segment: InstanceSegment): Promise<NextResponse> => {
    const { id } = await segment.params;
    const guard = ctxTenant(ctx);
    if (guard.principal.kind !== "session") {
      return NextResponse.json(
        { error: "Owner sign-in required for wallet transfers", code: "OWNER_ONLY" },
        { status: 403 }
      );
    }

    const input = await ctx.parseBody(transferLookupSchema);
    const result = await lookupWalletByNo(input.walletNo, id);
    if (!result.ok) {
      return NextResponse.json(
        { error: result.error, ...(result.code ? { code: result.code } : {}) },
        { status: result.status }
      );
    }
    return NextResponse.json({ receiver: result.receiver });
  }
);

/** POST /api/instances/[id]/wallet/transfer — EXECUTE an inter-wallet
 *  transfer. The strict, non-bypassable order:
 *    1. WORKSPACE OWNER session (admins never move tenant money);
 *    2. the owner's secret PIN verified Argon2id-side (428 PIN_NOT_SET
 *       before one exists; 401 PIN_INVALID on a wrong code — throttled
 *       fail-closed so brute force dies at the rate limiter);
 *    3. the amount parsed from the RAW dual-numeral string server-side
 *       and bounded (1..10,000 SAR);
 *    4. the atomic two-sided engine (one transaction: debit + credit +
 *       both ledger rows + both notification rows — zero-sum by design);
 *    5. unconditional audit.
 */
export const tenantTransferCreate = routeHandler(
  "execute wallet transfer",
  {
    tenant: { permission: "billing.manage", withRequest: true },
    rateLimit: {
      key: (parts) => `wallet-transfer:${parts.params.id}:${parts.ip}`,
      rule: TRANSFER_RULE,
      body: { error: "Too many transfers — try again shortly", code: "RATE_LIMITED" },
      /* ROUND 145 — money-moving surface: a durable-store outage REFUSES
       * the transfer instead of failing the throttle open. */
      failClosed: true,
    },
  },
  async (ctx, segment: InstanceSegment): Promise<NextResponse> => {
    const { id } = await segment.params;
    const guard = ctxTenant(ctx);
    if (guard.principal.kind !== "session") {
      return NextResponse.json(
        { error: "Owner sign-in required for wallet transfers", code: "OWNER_ONLY" },
        { status: 403 }
      );
    }

    const input = await ctx.parseBody(transferSchema);

    const instance = await repository.findTransferPinHolder(id);
    if (!instance) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }

    /* 2 — the PIN proof (the same secret that arms the shift system) */
    if (!instance.shiftCodeHash) {
      return NextResponse.json(
        {
          error: "Define your secret PIN first (Settings → الورديات) — transfers are PIN-protected",
          code: "PIN_NOT_SET",
        },
        { status: 428 }
      );
    }
    const pinOk = verifyPasswordArgon2id(input.pin, instance.shiftCodeHash);
    if (!pinOk) {
      /* ROUND 145 — the SHARED `pin-fail:${id}` key: the shift-open route
       * burns the SAME fail-closed budget (one secret, one budget). */
      if (await rateLimited(`pin-fail:${id}`, PIN_FAIL_RULE, { failClosed: true })) {
        return tooManyRequests(PIN_FAIL_RULE, {
          error: "Too many incorrect PIN attempts — try again later",
          code: "RATE_LIMITED",
        });
      }
      await logAudit({
        actorType: "instance",
        actorId: guard.principal.actorId,
        actorName: maskEmail(guard.principal.actorName),
        action: "instance.walletTransfer",
        targetLabel: String(input.toWalletNo),
        meta: { pin: "invalid", to: String(input.toWalletNo) },
      });
      return NextResponse.json(
        { error: "The PIN is incorrect", code: "PIN_INVALID" },
        { status: 401 }
      );
    }

    /* 3 — the amount (server-side parse of the RAW string) */
    const parsed = parseAmountInputToMinor(input.amount);
    if (!parsed.ok) {
      const error =
        parsed.error === "EMPTY" || parsed.error === "MALFORMED"
          ? "Enter a valid amount — Arabic-Indic (١٢٣) and Western (123) numerals both work"
          : parsed.error === "NEGATIVE"
            ? "The amount must be positive"
            : parsed.error === "DECIMALS"
              ? "At most two decimal places (halalas)"
              : "The amount is too large";
      return NextResponse.json({ error, code: `TRANSFER_${parsed.error}` }, { status: 422 });
    }

    /* 4 — the atomic engine */
    const result = await transferWalletFunds({
      fromInstanceId: id,
      toWalletNo: input.toWalletNo,
      amountMinor: parsed.minor,
      note: input.note,
      actorName: maskEmail(guard.principal.actorName),
    });
    if (!result.ok) {
      return NextResponse.json(
        { error: result.error, ...(result.code ? { code: result.code } : {}) },
        { status: result.status }
      );
    }

    /* 5 — unconditional audit */
    await logAudit({
      actorType: "instance",
      actorId: guard.principal.actorId,
      actorName: maskEmail(guard.principal.actorName),
      action: "instance.walletTransfer",
      targetLabel: result.receipt.reference,
      meta: {
        to: String(input.toWalletNo),
        receiver: result.receipt.receiver.orgName,
        amountMinor: String(result.receipt.amountMinor),
        amountMajor: String(toDisplayUnits(result.receipt.amountMinor)),
        senderBalanceAfterMinor: String(result.receipt.senderBalanceAfterMinor),
        receiverBalanceAfterMinor: String(result.receipt.receiverBalanceAfterMinor),
        note: input.note,
      },
    });

    return NextResponse.json({ receipt: result.receipt }, { status: 201 });
  }
);
