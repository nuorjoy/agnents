import { db } from "@/lib/db";
import type { Instance, WalletTopup } from "@prisma/client";

/**
 * Ashrilogic — wallet domain REPOSITORY (ROUND 162).
 *
 * The persistence seam completing the wallet decomposition: the four
 * lookups the controller previously inlined live here and nowhere else
 * (the CAS transaction engine stays in src/lib/server/wallet.ts — it is
 * the shared domain core, the same standing the plan-orders transition
 * core enjoys). Behavior is lifted VERBATIM — the exact where/include
 * shapes and caps.
 */

/** The top-up create path's workspace row (the full shape —
 *  createWalletTopup stamps the HMAC integrity onto it). */
export async function findInstance(id: string): Promise<Instance | null> {
  return db.instance.findUnique({ where: { id } });
}

/** The top-up cancel ownership probe (cross-tenant ids are 404s). */
export async function findTopupOwner(
  topupId: string
): Promise<Pick<WalletTopup, "instanceId"> | null> {
  return db.walletTopup.findUnique({
    where: { id: topupId },
    select: { instanceId: true },
  });
}

/** Console queue listing shape (identity trio joined per row). */
export type ConsoleTopupRow = WalletTopup & {
  instance: { id: string; systemId: string; orgJson: string } | null;
};

/** The console's top-up queue, newest first, capped at 100. */
export async function listTopupsForConsole(
  status?: "pending" | "paid" | "cancelled"
): Promise<ConsoleTopupRow[]> {
  return db.walletTopup.findMany({
    where: status ? { status } : undefined,
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    take: 100,
    include: { instance: { select: { id: true, systemId: true, orgJson: true } } },
  });
}

/** The transfer path's live-workspace PIN holder (trashed workspaces
 *  cannot transfer — deletedAt: null is part of the lookup). */
export async function findTransferPinHolder(
  id: string
): Promise<Pick<Instance, "shiftCodeHash" | "shiftCodeLen"> | null> {
  return db.instance.findUnique({
    where: { id, deletedAt: null },
    select: { shiftCodeHash: true, shiftCodeLen: true },
  });
}
