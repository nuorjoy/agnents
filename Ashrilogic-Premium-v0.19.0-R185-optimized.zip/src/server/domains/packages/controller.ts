import { NextResponse } from "next/server";
import { packageCreateSchema, packageUpdateSchema, toPackageDTO } from "@/lib/server/admin-mapper";
import { routeHandler, ctxAdmin } from "@/lib/server/route";
import * as service from "./service";

/**
 * Ashrilogic — packages domain CONTROLLER (ROUND 124 pilot; ROUND 127 —
 * the guards are now DECLARATIVE).
 *
 * The HTTP seam: Zod validation (through the unified route wrapper's
 * bounded reader), DTO mapping and status codes. Every handler is a
 * `routeHandler(...)` — correlation ids, the 500 envelope (`Failed to
 * <label>` — the exact legacy strings) and structured error telemetry
 * come from the wrapper. Business rules live in the service; persistence
 * in the repository.
 *
 * ROUND 127 — the guard surface is declared in the wrapper config and the
 * wrapper translates each stage into the REAL guard call (requireAdmin
 * verbatim — same envelopes, same order the legacy handlers hand-wrote).
 * The resolved admin arrives on the context (ctxAdmin) — no more
 * `if (guard instanceof NextResponse) return guard;` chains:
 *
 *  - public listing: NO auth (the landing pricing feed);
 *  - admin listing: any authenticated admin session (requireAdmin()
 *    WITHOUT req — no origin/2FA gate on reads, the historical posture);
 *  - create/update/delete: super/admin roles + origin + 2FA policy gate
 *    (requireAdmin([roles], req) — the withRequest stage).
 */

/** Segment shape for the [id] routes (Next 16: params is a Promise). */
interface IdSegment {
  params: Promise<{ id: string }>;
}

/** GET /api/packages — public pricing feed (active plans only). */
export const publicList = routeHandler("list packages", async (): Promise<NextResponse> => {
  const rows = await service.listPublic();
  return NextResponse.json(rows.map(toPackageDTO));
});

/** GET /api/admin/packages — the full catalog for the control panel. */
export const adminList = routeHandler(
  "list packages",
  { admin: {} },
  async (): Promise<NextResponse> => {
    const rows = await service.listAdmin();
    return NextResponse.json(rows.map(toPackageDTO));
  }
);

/** POST /api/admin/packages — create a plan (201 + DTO). */
export const adminCreate = routeHandler(
  "create package",
  { admin: { roles: ["super", "admin"], withRequest: true } },
  async (ctx): Promise<NextResponse> => {
    const admin = ctxAdmin(ctx);
    const data = await ctx.parseBody(packageCreateSchema);
    const row = await service.create(data, { id: admin.id, username: admin.username });
    return NextResponse.json(toPackageDTO(row), { status: 201 });
  }
);

/** PATCH /api/admin/packages/[id] — update a plan (200 + DTO). */
export const adminUpdate = routeHandler(
  "update package",
  { admin: { roles: ["super", "admin"], withRequest: true } },
  async (ctx, segment: IdSegment): Promise<NextResponse> => {
    const admin = ctxAdmin(ctx);
    const { id } = await segment.params;
    const data = await ctx.parseBody(packageUpdateSchema);
    const row = await service.update(id, data, { id: admin.id, username: admin.username });
    return NextResponse.json(toPackageDTO(row));
  }
);

/** DELETE /api/admin/packages/[id] — remove a plan ({ ok: true }). */
export const adminRemove = routeHandler(
  "delete package",
  { admin: { roles: ["super", "admin"], withRequest: true } },
  async (ctx, segment: IdSegment): Promise<NextResponse> => {
    const admin = ctxAdmin(ctx);
    const { id } = await segment.params;
    await service.remove(id, { id: admin.id, username: admin.username });
    return NextResponse.json({ ok: true });
  }
);
