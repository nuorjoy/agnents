import type { Package } from "@prisma/client";
import { db } from "@/lib/db";
import type { PackagePayload } from "@/lib/types";

/**
 * Ashrilogic — packages domain REPOSITORY (ROUND 124 pilot).
 *
 * The persistence seam of the first route→controller→service→repository
 * decomposition: every Prisma touch for the Package aggregate lives here
 * and NOWHERE else. Business rules (audit trail, the single-popular-plan
 * INVARIANT semantics, 404 policy) live in the service; HTTP mapping in
 * the controller.
 *
 * Behavior is lifted VERBATIM from the legacy route handlers — the exact
 * queries, the exact transaction scopes (ROUND 36 clear-then-set inside
 * ONE transaction so concurrent mutations cannot interleave into two
 * popular plans or zero), the exact JSON-column encoding (ROUND 79
 * capabilities / features ride stringified JSON columns; scalar columns
 * flow through `rest`).
 */

/** All plans, admin listing order (sortOrder, then creation, then id). */
export async function listAll(): Promise<Package[]> {
  return db.package.findMany({
    orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }, { id: "asc" }],
  });
}

/** ACTIVE plans only — the public pricing feed. */
export async function listActive(): Promise<Package[]> {
  return db.package.findMany({
    where: { active: true },
    orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }, { id: "asc" }],
  });
}

/** Full row for the update path (404 policy is the service's call). */
export async function findById(id: string): Promise<Package | null> {
  return db.package.findUnique({ where: { id } });
}

/** Brief row (id + English name) — enough for the delete audit label. */
export async function findBriefById(id: string): Promise<Pick<Package, "id" | "nameEn"> | null> {
  return db.package.findUnique({ where: { id }, select: { id: true, nameEn: true } });
}

/** Create; when the new plan is `popular`, clear the flag from every
 * existing plan inside the SAME transaction (single featured plan). */
export async function createWithPopularSwap(input: PackagePayload): Promise<Package> {
  const { features, featuresEn, capabilities, ...rest } = input;
  return db.$transaction(async (tx) => {
    if (input.popular) {
      await tx.package.updateMany({ where: { popular: true }, data: { popular: false } });
    }
    return tx.package.create({
      data: {
        ...rest,
        featuresJson: JSON.stringify(features ?? []),
        featuresEnJson: JSON.stringify(featuresEn ?? []),
        capabilitiesJson: JSON.stringify(capabilities ?? []),
      },
    });
  });
}

/** Update; `popular: true` clears the flag from every OTHER plan inside
 * the SAME transaction. JSON columns are rewritten only when present in
 * the partial input (PATCH semantics — absent keys stay untouched). */
export async function updateWithPopularSwap(
  id: string,
  input: Partial<PackagePayload>
): Promise<Package> {
  const { features, featuresEn, capabilities, ...rest } = input;
  return db.$transaction(async (tx) => {
    if (input.popular === true) {
      await tx.package.updateMany({
        where: { popular: true, id: { not: id } },
        data: { popular: false },
      });
    }
    return tx.package.update({
      where: { id },
      data: {
        ...rest,
        ...(features !== undefined ? { featuresJson: JSON.stringify(features) } : {}),
        ...(featuresEn !== undefined ? { featuresEnJson: JSON.stringify(featuresEn) } : {}),
        ...(capabilities !== undefined ? { capabilitiesJson: JSON.stringify(capabilities) } : {}),
      },
    });
  });
}

/** Hard delete (plans have no soft-delete lifecycle). */
export async function remove(id: string): Promise<void> {
  await db.package.delete({ where: { id } });
}
