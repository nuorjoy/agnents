import type { Package } from "@prisma/client";
import { db } from "@/lib/db";
import { seedAdminDefaults } from "@/lib/server/admin-mapper";
import { logAudit } from "@/lib/server/audit";
import { HttpError } from "@/lib/server/route";
import type { PackagePayload } from "@/lib/types";
import * as repository from "./repository";

/**
 * Ashrilogic — packages domain SERVICE (ROUND 124 pilot).
 *
 * Business rules for the subscription-plan catalog, lifted verbatim from
 * the legacy route handlers:
 *  - both listing paths seed the default plans first (idempotent, memoized
 *    by seedAdminDefaults) so a fresh database self-heals on first read;
 *  - create/update enforce the SINGLE popular plan through the
 *    repository's transactional clear-then-set;
 *  - update/delete on an unknown id raise HttpError(404, "Package not
 *    found") — the exact legacy envelope;
 *  - every mutation writes its audit row with the EXACT legacy meta shape
 *    (create's meta reads the CREATED ROW; update's meta reads the INPUT
 *    PATCH — the historical asymmetry is preserved on purpose).
 *
 * HTTP never appears here: no Request, no NextResponse, no status codes
 * beyond the HttpError domain signal. That is what makes the layer
 * unit-testable against a throwaway database without a server.
 */

/** The acting admin (from the session guard) — audit attribution. */
export interface PackageActor {
  id: string;
  username: string;
}

/** Public pricing feed: active plans, defaults seeded on an empty table. */
export async function listPublic(): Promise<Package[]> {
  await seedAdminDefaults(db);
  return repository.listActive();
}

/** Admin catalog: every plan, defaults seeded on an empty table. */
export async function listAdmin(): Promise<Package[]> {
  await seedAdminDefaults(db);
  return repository.listAll();
}

/** Create a plan (single-popular-plan swap included). */
export async function create(input: PackagePayload, actor: PackageActor): Promise<Package> {
  const row = await repository.createWithPopularSwap(input);
  await logAudit({
    actorType: "admin",
    actorId: actor.id,
    actorName: actor.username,
    action: "package.create",
    targetLabel: row.nameEn,
    meta: {
      priceMonthly: String(row.priceMonthly),
      ...(row.discountPct ? { discountPct: String(row.discountPct) } : {}),
      ...(row.yearlyDiscountPct ? { yearlyDiscountPct: String(row.yearlyDiscountPct) } : {}),
    },
  });
  return row;
}

/** Update a plan; unknown ids are the legacy 404 envelope. */
export async function update(
  id: string,
  input: Partial<PackagePayload>,
  actor: PackageActor
): Promise<Package> {
  const existing = await repository.findById(id);
  if (!existing) {
    throw new HttpError(404, "Package not found");
  }
  const row = await repository.updateWithPopularSwap(id, input);
  await logAudit({
    actorType: "admin",
    actorId: actor.id,
    actorName: actor.username,
    action: "package.update",
    targetLabel: row.nameEn,
    meta: {
      ...(input.priceMonthly !== undefined ? { priceMonthly: String(input.priceMonthly) } : {}),
      ...(input.active !== undefined ? { active: String(input.active) } : {}),
      ...(input.popular !== undefined ? { popular: String(input.popular) } : {}),
      ...(input.discountPct !== undefined ? { discountPct: String(input.discountPct) } : {}),
      ...(input.yearlyDiscountPct !== undefined
        ? { yearlyDiscountPct: String(input.yearlyDiscountPct) }
        : {}),
      ...(input.capabilities !== undefined
        ? { capabilities: input.capabilities.join(",") }
        : {}),
    },
  });
  return row;
}

/** Delete a plan; unknown ids are the legacy 404 envelope. */
export async function remove(id: string, actor: PackageActor): Promise<void> {
  const existing = await repository.findBriefById(id);
  if (!existing) {
    throw new HttpError(404, "Package not found");
  }
  await repository.remove(id);
  await logAudit({
    actorType: "admin",
    actorId: actor.id,
    actorName: actor.username,
    action: "package.delete",
    targetLabel: existing.nameEn ?? id,
  });
}
