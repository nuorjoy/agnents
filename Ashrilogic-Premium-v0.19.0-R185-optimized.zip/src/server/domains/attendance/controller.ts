import { NextResponse } from "next/server";
import { routeHandler, ctxTenant, ctxBody } from "@/lib/server/route";
import { maskEmail } from "@/lib/server/audit";
import { trialLockResponse } from "@/lib/server/entitlement";
import type { InstancePrincipal } from "@/lib/server/instance-session";
import * as service from "./service";
import type { AttendanceActor } from "./service";

/**
 * Ashrilogic — attendance domain CONTROLLER (ROUND 166, الحضور والغياب).
 *
 * The HTTP seam of the attendance surface. Every handler is a
 * routeHandler(...) (the unified wrapper: correlation ids, the 500
 * envelope with the route's own verb phrase, redacted telemetry) and the
 * guards are DECLARATIVE — the same stage vocabulary the plan-orders and
 * wallet controllers use:
 *
 *  - READS (policy/roster/movements/allowances): the tenant stage with
 *    `modules.view` — any workspace member (owner/manager/staff/viewer)
 *    may watch the board;
 *  - WRITES (policy/movements/allowances/QR mint): the tenant stage with
 *    `modules.edit` + withRequest (origin-checked) — owner/manager/staff;
 *    viewer is refused by the strict RBAC matrix. The business surfaces
 *    additionally honor the trial/plan lock (trialLockResponse) exactly
 *    like every other module surface;
 *  - REDEEM (the gate kiosk): deliberately NOT staff-authenticated — the
 *    256-bit single-use token IS the credential. Origin-guarded (the CSRF
 *    gate — a cookieless kiosk POST passes, a cross-site page does not),
 *    body-validated, and throttled per instance + IP.
 */

/** Manual-movement throttle: 60 records / 10 min per workspace + IP. */
const MOVEMENT_RULE = { limit: 60, windowMs: 10 * 60 * 1000 };
/** Allowance-creation throttle: 30 / 10 min per workspace + IP. */
const ALLOWANCE_RULE = { limit: 30, windowMs: 10 * 60 * 1000 };
/** QR minting throttle: 30 / 10 min per workspace + IP. */
const QR_MINT_RULE = { limit: 30, windowMs: 10 * 60 * 1000 };
/**
 * QR redemption throttle: 600 / 10 min per workspace + IP. Generous by
 * design — a real gate redeems once per student pass (a class-change
 * burst can hit hundreds), while a brute-force flood of 128-char tokens
 * against a 256-bit hash is hopeless long before the cap bites. The
 * throttle bounds DB write amplification, not the credential space.
 */
const QR_REDEEM_RULE = { limit: 600, windowMs: 10 * 60 * 1000 };

/** Segment shape for the [id] routes (Next 16: params is a Promise). */
interface InstanceSegment {
  params: Promise<{ id: string }>;
}
interface AllowanceSegment {
  params: Promise<{ id: string; allowanceId: string }>;
}

/** Email-shaped values are PII — mask them for the audit trail; plain
 *  handles ("sarah.super") pass through so the trail stays correlatable. */
const EMAIL_SHAPE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function auditActorName(name: string): string {
  return EMAIL_SHAPE.test(name) ? maskEmail(name) : name;
}

/**
 * Build the attendance actor from the tenant principal. The movement
 * stamp follows the shift-domain precedent (openedById): the platform
 * admin's id when an admin acts, otherwise the workspace session's jti —
 * every value is SERVER-derived, never client input.
 */
function tenantActor(principal: InstancePrincipal): AttendanceActor {
  const stampId =
    principal.kind === "admin"
      ? `staff:${principal.actorId ?? principal.instanceId}`
      : `staff:${principal.sessionJti ?? principal.instanceId}`;
  return {
    stampId,
    stampName: principal.actorName,
    audit: {
      actorType: principal.kind === "admin" ? "admin" : "instance",
      actorId: principal.actorId ?? principal.instanceId,
      actorName: auditActorName(principal.actorName),
    },
  };
}

/* --------------------------------- policy ---------------------------------- */

/** GET /api/instances/[id]/attendance/policy — the workspace's policy. */
export const policyGet = routeHandler(
  "read attendance policy",
  { tenant: { permission: "modules.view" } },
  async (_ctx, segment: InstanceSegment): Promise<NextResponse> => {
    const { id } = await segment.params;
    return NextResponse.json(await service.getPolicy(id));
  }
);

/** PUT /api/instances/[id]/attendance/policy — update the policy. */
export const policyPut = routeHandler(
  "update attendance policy",
  {
    tenant: { permission: "modules.edit", withRequest: true },
  },
  async (ctx, segment: InstanceSegment): Promise<NextResponse> => {
    const { id } = await segment.params;
    const lock = await trialLockResponse(id);
    if (lock) return lock;
    const guard = ctxTenant(ctx);
    const input = await ctx.parseBody(service.policyUpdateSchema);
    return NextResponse.json(
      await service.updatePolicy(tenantActor(guard.principal), id, input)
    );
  }
);

/* ---------------------------------- roster ---------------------------------- */

/** GET /api/instances/[id]/attendance/roster?date=YYYY-MM-DD — the day board. */
export const rosterGet = routeHandler(
  "read attendance roster",
  { tenant: { permission: "modules.view" } },
  async (ctx, segment: InstanceSegment): Promise<NextResponse> => {
    const { id } = await segment.params;
    const lock = await trialLockResponse(id);
    if (lock) return lock;
    const date = new URL(ctx.req.url).searchParams.get("date");
    return NextResponse.json(await service.getRoster(id, date));
  }
);

/* -------------------------------- movements --------------------------------- */

/** GET /api/instances/[id]/attendance/movements?cursor=&limit= — the feed. */
export const movementsGet = routeHandler(
  "list attendance movements",
  { tenant: { permission: "modules.view" } },
  async (ctx, segment: InstanceSegment): Promise<NextResponse> => {
    const { id } = await segment.params;
    const lock = await trialLockResponse(id);
    if (lock) return lock;
    const url = new URL(ctx.req.url);
    return NextResponse.json(
      await service.listMovements(
        id,
        url.searchParams.get("cursor"),
        url.searchParams.get("limit")
      )
    );
  }
);

/** POST /api/instances/[id]/attendance/movements — a MANUAL movement. */
export const movementsPost = routeHandler(
  "record attendance movement",
  {
    tenant: { permission: "modules.edit", withRequest: true },
    rateLimit: {
      key: (parts) => `att-move:${parts.params.id}:${parts.ip}`,
      rule: MOVEMENT_RULE,
      body: { error: "Too many movement records — try again shortly", code: "RATE_LIMITED" },
    },
  },
  async (ctx, segment: InstanceSegment): Promise<NextResponse> => {
    const { id } = await segment.params;
    const lock = await trialLockResponse(id);
    if (lock) return lock;
    const guard = ctxTenant(ctx);
    const input = await ctx.parseBody(service.movementCreateSchema);
    const result = await service.recordMovement(
      tenantActor(guard.principal),
      id,
      input
    );
    return NextResponse.json(result, { status: 201 });
  }
);

/* -------------------------------- allowances -------------------------------- */

/** GET /api/instances/[id]/attendance/allowances — upcoming + active. */
export const allowancesGet = routeHandler(
  "list attendance allowances",
  { tenant: { permission: "modules.view" } },
  async (_ctx, segment: InstanceSegment): Promise<NextResponse> => {
    const { id } = await segment.params;
    const lock = await trialLockResponse(id);
    if (lock) return lock;
    return NextResponse.json(await service.listAllowances(id));
  }
);

/** POST /api/instances/[id]/attendance/allowances — create one. */
export const allowancesPost = routeHandler(
  "create attendance allowance",
  {
    tenant: { permission: "modules.edit", withRequest: true },
    rateLimit: {
      key: (parts) => `att-allow:${parts.params.id}:${parts.ip}`,
      rule: ALLOWANCE_RULE,
      body: { error: "Too many allowance writes — try again shortly", code: "RATE_LIMITED" },
    },
  },
  async (ctx, segment: InstanceSegment): Promise<NextResponse> => {
    const { id } = await segment.params;
    const lock = await trialLockResponse(id);
    if (lock) return lock;
    const guard = ctxTenant(ctx);
    const input = await ctx.parseBody(service.allowanceCreateSchema);
    return NextResponse.json(
      await service.createAllowance(tenantActor(guard.principal), id, input),
      { status: 201 }
    );
  }
);

/** DELETE /api/instances/[id]/attendance/allowances/[allowanceId]. */
export const allowanceDelete = routeHandler(
  "delete attendance allowance",
  { tenant: { permission: "modules.edit", withRequest: true } },
  async (ctx, segment: AllowanceSegment): Promise<NextResponse> => {
    const { id, allowanceId } = await segment.params;
    const lock = await trialLockResponse(id);
    if (lock) return lock;
    const guard = ctxTenant(ctx);
    await service.deleteAllowance(tenantActor(guard.principal), id, allowanceId);
    return new NextResponse(null, { status: 204 });
  }
);

/* ------------------------------------ QR ------------------------------------- */

/** POST /api/instances/[id]/attendance/qr — mint a single-use token. */
export const qrMint = routeHandler(
  "mint attendance QR",
  {
    tenant: { permission: "modules.edit", withRequest: true },
    rateLimit: {
      key: (parts) => `att-qr-mint:${parts.params.id}:${parts.ip}`,
      rule: QR_MINT_RULE,
      body: { error: "Too many QR mints — try again shortly", code: "RATE_LIMITED" },
    },
  },
  async (ctx, segment: InstanceSegment): Promise<NextResponse> => {
    const { id } = await segment.params;
    const lock = await trialLockResponse(id);
    if (lock) return lock;
    const guard = ctxTenant(ctx);
    const input = await ctx.parseBody(service.qrMintSchema);
    return NextResponse.json(
      await service.mintQr(tenantActor(guard.principal), id, input),
      { status: 201 }
    );
  }
);

/**
 * POST /api/instances/[id]/attendance/qr/redeem — the GATE KIOSK.
 *
 * No staff session by design: the 256-bit single-use token is the
 * credential (minted ≤5 minutes earlier by an authenticated staff member
 * for exactly one student + direction). Everything else about the
 * movement law is identical to the manual path — live-roster validation,
 * strict alternation, server-stamped timestamps, audited insert. The
 * instance scoping is absolute: the token hash is looked up WITH the
 * route's [id] segment, so a QR minted on workspace A can never be
 * redeemed against workspace B.
 */
export const qrRedeem = routeHandler(
  "redeem attendance QR",
  {
    origin: true,
    body: {
      schema: service.qrRedeemSchema,
      invalid: { error: "token is required", code: "BAD_TOKEN" },
    },
    rateLimit: {
      key: (parts) => `att-qr-redeem:${parts.params.id}:${parts.ip}`,
      rule: QR_REDEEM_RULE,
      body: { error: "Too many QR scans — try again shortly", code: "RATE_LIMITED" },
      /* an INVALID body never burns a throttle hit (the coupon-validate
       * semantics) — only real token attempts count against the gate. */
      afterBody: true,
    },
  },
  async (ctx, segment: InstanceSegment): Promise<NextResponse> => {
    const { id } = await segment.params;
    const input = ctxBody<typeof service.qrRedeemSchema._output>(ctx);
    const result = await service.redeemQr(id, input);
    return NextResponse.json(result, { status: 201 });
  }
);
