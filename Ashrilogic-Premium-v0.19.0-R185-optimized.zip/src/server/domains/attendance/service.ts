import { createHash, randomBytes } from "node:crypto";
import { z } from "zod";
import { HttpError } from "@/lib/server/route";
import { logAudit } from "@/lib/server/audit";
import { modulePreset } from "@/lib/module-data";
import {
  decodeKeyset,
  encodeKeyset,
} from "@/lib/server/keyset";
import {
  deriveDayState,
  summarizeRoster,
  startOfDay,
  type AttendanceCounts,
  type AttendancePolicyInput,
  type AttendanceShift,
  type AttendanceState,
  type AllowanceInput,
  type DayState,
  type MovementInput,
} from "@/lib/server/attendance/derive";
import * as repo from "./repository";
import type {
  AttendanceAllowance,
  AttendanceMovement,
  AttendancePolicy,
} from "@prisma/client";

/**
 * Ashrilogic — attendance domain SERVICE (ROUND 166, الحضور والغياب).
 *
 * Business rules only — every failure is an HttpError with a stable code,
 * every mutation is audit-logged, every read is bounded (see the
 * repository's bounded-query law). The derived daily state NEVER touches
 * the database: this layer fetches the day's rows and hands them to the
 * PURE engine (src/lib/server/attendance/derive.ts) with one injected
 * `now`.
 *
 * SERVER-STAMPED TRUTH (never client-trusted):
 *  - occurredAt is ALWAYS new Date() at the service edge;
 *  - recordedById/recordedByName come from the authenticated actor (or
 *    the literal "qr" stamp on the kiosk path);
 *  - studentCode arrives from the body but is validated against the LIVE
 *    residents roster before anything is written.
 *
 * THE ALTERNATION LAW: movements strictly alternate in/out per student
 * per day — "in" after "in" is DUPLICATE_CHECK_IN, "out" with no prior
 * "in" is INVALID_CHECK_OUT, "out" after "out" is DUPLICATE_CHECK_OUT.
 * The SAME law guards manual and QR movements: a stale IN token redeemed
 * after a manual IN still 409s (documented intent — the QR path is a
 * movement recorder, not a bypass).
 */

/* ------------------------------ tuning ------------------------------ */

/** QR token TTL bounds (seconds) — short-lived by design (gate kiosk). */
export const QR_TTL_MIN_SECONDS = 30;
export const QR_TTL_MAX_SECONDS = 300;
export const QR_TTL_DEFAULT_SECONDS = 120;

/** Movements feed page bounds (clamped [min, max], default 50). */
export const MOVEMENT_FEED_DEFAULT = 50;
export const MOVEMENT_FEED_MIN = 20;
export const MOVEMENT_FEED_MAX = 100;

/** The schema-default policy (the lazy-create shape). */
export const DEFAULT_POLICY: AttendancePolicyInput = {
  dayStartMin: 480,
  dayEndMin: 1080,
  graceMin: 10,
  absenceEvalMin: 1260,
  requireReview: true,
};

/* ------------------------------- actors ----------------------------------- */

/** Who performed an attendance mutation (built by the controller). */
export interface AttendanceActor {
  /** movement stamp — "staff:<id>" (server-stamped, never client input). */
  stampId: string;
  /** movement display-name snapshot. */
  stampName: string;
  /** audit-trail identity. */
  audit: {
    actorType: "admin" | "instance" | "public";
    actorId?: string;
    actorName: string;
  };
}

/* ------------------------------- schemas ---------------------------------- */

/**
 * ONE دوام shift (ROUND 167): type + window + grace, with the partial
 * law — `partialHours` (1..12) is REQUIRED for a partial shift and
 * REJECTED on any other type (it is the expected coverage duration, a
 * contract the partial editor owns exclusively).
 */
const shiftEntrySchema = z
  .object({
    type: z.enum(["morning", "evening", "partial"]),
    startMin: z.number().int().min(0).max(1439),
    endMin: z.number().int().min(0).max(1439),
    graceMin: z.number().int().min(0).max(240),
    partialHours: z.number().int().min(1).max(12).optional(),
  })
  .superRefine((shift, ctx) => {
    if (shift.startMin >= shift.endMin) {
      ctx.addIssue({
        code: "custom",
        path: ["endMin"],
        message: "shift startMin must be before endMin",
      });
    }
    if (shift.type === "partial" && shift.partialHours === undefined) {
      ctx.addIssue({
        code: "custom",
        path: ["partialHours"],
        message: "partialHours is required for partial shifts",
      });
    }
    if (shift.type !== "partial" && shift.partialHours !== undefined) {
      ctx.addIssue({
        code: "custom",
        path: ["partialHours"],
        message: "partialHours applies to partial shifts only",
      });
    }
  });

export const policyUpdateSchema = z.object({
  dayStartMin: z.number().int().min(0).max(1439),
  dayEndMin: z.number().int().min(0).max(1439),
  graceMin: z.number().int().min(0).max(240),
  absenceEvalMin: z.number().int().min(0).max(1439),
  requireReview: z.boolean(),
  /**
   * ROUND 167 (دوام) — the OPTIONAL shift schedule (0..3 entries):
   *   • undefined → KEEP the stored schedule (legacy clients / partial
   *     updates never silently wipe a configured دوام);
   *   • []        → the explicit return to the legacy single window;
   *   • entries   → validated, sorted by startMin, overlap-rejected in the
   *     service (SHIFTS_OVERLAP) and STAMPED onto the legacy columns for
   *     every other reader (dayStart = first start, dayEnd = last end,
   *     grace = first grace).
   */
  shifts: z.array(shiftEntrySchema).max(3).optional(),
});

export const movementCreateSchema = z.object({
  studentCode: z.string().trim().min(1).max(64),
  direction: z.enum(["in", "out"]),
});

export const allowanceCreateSchema = z.object({
  studentCode: z.string().trim().min(1).max(64),
  kind: z.enum(["excused", "authorized", "leave", "outside"]),
  /** ISO-8601 local timestamps (validated + Date-parsed server-side). */
  startsAt: z.string().min(10).max(40),
  endsAt: z.string().min(10).max(40),
  note: z.string().trim().max(200).optional(),
});

export const qrMintSchema = z.object({
  studentCode: z.string().trim().min(1).max(64),
  direction: z.enum(["in", "out"]),
  gateLabel: z.string().trim().min(1).max(40).optional(),
  ttlSeconds: z.number().int().min(1).max(3600).optional(),
});

export const qrRedeemSchema = z.object({
  token: z.string().min(16).max(128),
});

/* -------------------------------- DTOs ------------------------------------- */

export interface PolicyDTO {
  dayStartMin: number;
  dayEndMin: number;
  graceMin: number;
  absenceEvalMin: number;
  requireReview: boolean;
  /** ROUND 167 (دوام) — the parsed shift schedule (empty = legacy window). */
  shifts: AttendanceShift[];
  updatedAt: string;
}

export interface RosterRowDTO {
  studentCode: string;
  name: string;
  room: string;
  building: string;
  state: AttendanceState;
  /** ISO strings at the DTO boundary (Dates inside the pure engine). */
  lastMovementAt: string | null;
  lastDirection: "in" | "out" | null;
  lateMinutes: number | null;
  expectedReturnAt: string | null;
  overdue: boolean;
}

export interface RosterResponseDTO {
  policy: PolicyDTO;
  date: string;
  rows: RosterRowDTO[];
  counts: AttendanceCounts;
}

export interface MovementDTO {
  id: string;
  studentCode: string;
  studentName: string;
  direction: string;
  method: string;
  occurredAt: string;
  recordedById: string;
  recordedByName: string;
  qrTokenId: string | null;
  createdAt: string;
}

export interface MovementFeedDTO extends MovementDTO {
  /** the student's derived state for THIS movement's local day. */
  state: DayState["state"];
}

export interface AllowanceDTO {
  id: string;
  studentCode: string;
  studentName: string;
  kind: string;
  startsAt: string;
  endsAt: string;
  note: string | null;
  createdByName: string;
  createdAt: string;
}

export interface QrMintDTO {
  /** the RAW token — shown once, never stored (only its sha256 lands). */
  token: string;
  expiresAt: string;
  /** the exact JSON string the UI renders as the QR code. */
  qrPayload: string;
}

/* ------------------------------- helpers ----------------------------------- */

function toPolicyDTO(row: AttendancePolicy): PolicyDTO {
  return {
    dayStartMin: row.dayStartMin,
    dayEndMin: row.dayEndMin,
    graceMin: row.graceMin,
    absenceEvalMin: row.absenceEvalMin,
    requireReview: row.requireReview,
    shifts: parseShiftsJson(row.shiftsJson),
    updatedAt: row.updatedAt.toISOString(),
  };
}

/**
 * Parse the stored دوام shiftsJson (ROUND 167) — blank or corrupt JSON
 * falls back to [] (the legacy single window), the same defensive read
 * every pre-167 row exercises. Only shapes this service writes (or a
 * stricter subset) parse; anything else is deliberately unreadable.
 */
export function parseShiftsJson(raw: string): AttendanceShift[] {
  if (raw.trim() === "") return [];
  try {
    const parsed: unknown = JSON.parse(raw);
    const result = z.array(shiftEntrySchema).max(3).safeParse(parsed);
    return result.success ? result.data : [];
  } catch {
    return [];
  }
}

/**
 * The ENGINE's policy input for a stored row — the دوام schedule rides
 * along (parsed), everything else is the row's plain columns. Every
 * deriveDayState/summarizeRoster call site passes exactly this.
 */
function policyInputFromRow(row: AttendancePolicy): AttendancePolicyInput {
  return {
    dayStartMin: row.dayStartMin,
    dayEndMin: row.dayEndMin,
    graceMin: row.graceMin,
    absenceEvalMin: row.absenceEvalMin,
    requireReview: row.requireReview,
    shifts: parseShiftsJson(row.shiftsJson),
  };
}

/** sha256 hex of a raw token — the only stored form (verification.ts law). */
function sha256Hex(value: string): string {
  return createHash("sha256").update(value, "utf8").digest("hex");
}

/** "YYYY-MM-DD" → local-midnight Date (null on anything malformed). */
export function parseLocalDate(raw: string): Date | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(raw)) return null;
  const [y, m, d] = raw.split("-").map((part) => Number.parseInt(part, 10));
  const date = new Date(y, m - 1, d);
  if (
    date.getFullYear() !== y ||
    date.getMonth() !== m - 1 ||
    date.getDate() !== d
  ) {
    return null;
  }
  return date;
}

/** ISO-ish timestamp → Date (null when unparseable). */
function parseTimestamp(raw: string): Date | null {
  const date = new Date(raw);
  return Number.isNaN(date.getTime()) ? null : date;
}

/** The residents preset's roster field positions (code/name/room/building). */
interface RosterCols {
  code: number;
  name: number;
  room: number;
  building: number;
}

const ROSTER_COLS: RosterCols = (() => {
  const cols = modulePreset(repo.ROSTER_MODULE_ID).cols;
  const indexOf = (key: string): number => {
    const i = cols.findIndex((c) => c.key === key);
    return i >= 0 ? i : -1;
  };
  return {
    code: indexOf("code"),
    name: indexOf("name"),
    room: indexOf("room"),
    building: indexOf("building"),
  };
})();

/** One parsed residents row (the roster projection). */
export interface RosterEntry {
  studentCode: string;
  name: string;
  room: string;
  building: string;
}

function cell(values: string[], index: number): string {
  const value = index >= 0 ? values[index] : undefined;
  return typeof value === "string" && value.trim() !== "" ? value.trim() : "—";
}

/** Parse one residents dataJson row (defensive: a corrupt row reads as null). */
function parseRosterRow(dataJson: string): RosterEntry | null {
  try {
    const values = JSON.parse(dataJson) as unknown;
    if (!Array.isArray(values)) return null;
    const strings = values.map((v) => (typeof v === "string" ? v : ""));
    const studentCode = cell(strings, ROSTER_COLS.code);
    if (studentCode === "—") return null;
    return {
      studentCode,
      name: cell(strings, ROSTER_COLS.name),
      room: cell(strings, ROSTER_COLS.room),
      building: cell(strings, ROSTER_COLS.building),
    };
  } catch {
    return null;
  }
}

/** The live roster (residents rows, parsed + deduped by code, roster order). */
async function loadRoster(instanceId: string): Promise<RosterEntry[]> {
  const rows = await repo.listRosterRecords(instanceId);
  const seen = new Set<string>();
  const roster: RosterEntry[] = [];
  for (const row of rows) {
    const entry = parseRosterRow(row.dataJson);
    if (!entry || seen.has(entry.studentCode)) continue;
    seen.add(entry.studentCode);
    roster.push(entry);
  }
  return roster;
}

/** Is this studentCode a LIVE resident? (the movement/allowance/QR gate). */
async function ensureLiveResident(
  instanceId: string,
  studentCode: string
): Promise<RosterEntry> {
  const roster = await loadRoster(instanceId);
  const entry = roster.find((r) => r.studentCode === studentCode);
  if (!entry) {
    throw new HttpError(
      404,
      "Student not found on this workspace roster",
      "STUDENT_NOT_FOUND"
    );
  }
  return entry;
}

/** The policy row (lazy-created with schema defaults on first touch). */
async function getPolicyRow(instanceId: string): Promise<AttendancePolicy> {
  const existing = await repo.findPolicy(instanceId);
  if (existing) return existing;
  /* upsert (not create) so two concurrent first-touches converge on one row */
  return repo.upsertPolicy(instanceId, { ...DEFAULT_POLICY, shiftsJson: "" });
}

/**
 * Derive the day states for a set of students in ONE batch: the day's
 * movements + overlapping allowances (roster-chunked, window-bounded) fed
 * through the pure engine with one injected clock.
 */
async function dayStateBatch(
  instanceId: string,
  policy: AttendancePolicyInput,
  day: Date,
  studentCodes: readonly string[],
  now: Date
): Promise<Map<string, DayState>> {
  const { from, to } = repo.dayWindow(day);
  const [movementRows, allowanceRows] = await Promise.all([
    repo.listDayMovements(instanceId, studentCodes, from, to),
    repo.listDayAllowances(instanceId, studentCodes, from, to),
  ]);
  const movements: MovementInput[] = movementRows.map((m) => ({
    studentCode: m.studentCode,
    direction: m.direction,
    occurredAt: m.occurredAt,
  }));
  const allowances: AllowanceInput[] = allowanceRows.map((a) => ({
    studentCode: a.studentCode,
    kind: a.kind,
    startsAt: a.startsAt,
    endsAt: a.endsAt,
  }));
  const states = new Map<string, DayState>();
  for (const code of studentCodes) {
    states.set(
      code,
      deriveDayState({ policy, studentCode: code, day, movements, allowances, now })
    );
  }
  return states;
}

/* ------------------------------------------------------------------ */
/* دوام policy update (ROUND 167)                                       */
/* ------------------------------------------------------------------ */

/** Do two shift windows' [start, end) ranges intersect? */
function shiftsOverlap(a: AttendanceShift, b: AttendanceShift): boolean {
  return a.startMin < b.endMin && b.startMin < a.endMin;
}

/**
 * Audit-meta summary of a shift schedule: "0" when none, otherwise
 * "2[morning+evening]" — count + types, the ROUND 167 contract.
 */
function shiftAuditSummary(shifts: readonly AttendanceShift[]): string {
  if (shifts.length === 0) return "0";
  return `${shifts.length}[${shifts.map((s) => s.type).join("+")}]`;
}

/**
 * Audited mutation — meta values are strings (the logAudit contract).
 * AWAITED (not fire-and-forget): the audit row is guaranteed to exist when
 * the service call resolves — the regression suite asserts the trail, and
 * logAudit itself swallows write failures so a trailing audit can never
 * fail the user's request.
 */
async function audit(
  actor: AttendanceActor,
  action:
    | "instance.attendancePolicy"
    | "instance.attendanceMovement"
    | "instance.attendanceAllowanceCreate"
    | "instance.attendanceAllowanceDelete"
    | "instance.attendanceQrMint",
  targetLabel: string,
  meta: Record<string, string>
): Promise<void> {
  await logAudit({
    actorType: actor.audit.actorType,
    actorId: actor.audit.actorId,
    actorName: actor.audit.actorName,
    action,
    targetLabel,
    meta,
  });
}

/* -------------------------------- policy ----------------------------------- */

/** GET — the workspace's policy (lazily created with the defaults). */
export async function getPolicy(instanceId: string): Promise<PolicyDTO> {
  return toPolicyDTO(await getPolicyRow(instanceId));
}

/** PUT — validate + update the policy (audited with old/new values). */
export async function updatePolicy(
  actor: AttendanceActor,
  instanceId: string,
  input: z.infer<typeof policyUpdateSchema>
): Promise<PolicyDTO> {
  /* ROUND 167 (دوام) — the shift schedule, when submitted, is sorted by
   * start and must be pairwise NON-OVERLAPPING (the arrival→shift map is
   * only deterministic over disjoint windows). */
  const shifts =
    input.shifts === undefined
      ? undefined
      : [...input.shifts].sort((a, b) => a.startMin - b.startMin);
  if (shifts && shifts.length > 1) {
    for (let i = 1; i < shifts.length; i += 1) {
      if (shiftsOverlap(shifts[i - 1], shifts[i])) {
        throw new HttpError(
          400,
          "shift windows must not overlap",
          "SHIFTS_OVERLAP"
        );
      }
    }
  }

  /* The LEGACY columns the derive's fallback + every other reader consume:
   * with shifts they are DERIVED (first start / last end / first grace —
   * invisible to the دوام editor, which never edits them directly);
   * without shifts the caller's own values persist as before. */
  const dayStartMin =
    shifts && shifts.length > 0 ? shifts[0].startMin : input.dayStartMin;
  const dayEndMin =
    shifts && shifts.length > 0 ? shifts[shifts.length - 1].endMin : input.dayEndMin;
  const graceMin =
    shifts && shifts.length > 0 ? shifts[0].graceMin : input.graceMin;

  /* cross-field law: the window must be non-empty and the review cutoff
   * must not fire before the (effective) window ends. */
  if (dayStartMin >= dayEndMin) {
    throw new HttpError(
      400,
      "dayStartMin must be before dayEndMin",
      "POLICY_WINDOW_INVALID"
    );
  }
  if (input.absenceEvalMin < dayEndMin) {
    throw new HttpError(
      400,
      "absenceEvalMin must be at or after dayEndMin",
      "POLICY_EVAL_INVALID"
    );
  }

  const before = await getPolicyRow(instanceId);
  /* undefined shifts → the stored schedule survives untouched (the
   * backwards-compat arm); an explicit array — even empty — is written. */
  const shiftsJson =
    shifts === undefined ? before.shiftsJson : JSON.stringify(shifts);
  const row = await repo.upsertPolicy(instanceId, {
    dayStartMin,
    dayEndMin,
    graceMin,
    absenceEvalMin: input.absenceEvalMin,
    requireReview: input.requireReview,
    shiftsJson,
  });
  await audit(actor, "instance.attendancePolicy", "attendance-policy", {
    dayStartMin: `${before.dayStartMin}→${row.dayStartMin}`,
    dayEndMin: `${before.dayEndMin}→${row.dayEndMin}`,
    graceMin: `${before.graceMin}→${row.graceMin}`,
    absenceEvalMin: `${before.absenceEvalMin}→${row.absenceEvalMin}`,
    requireReview: `${before.requireReview}→${row.requireReview}`,
    /* ROUND 167 — the shift count + types ride the trail ("0→2[morning+evening]"). */
    shifts: `${shiftAuditSummary(parseShiftsJson(before.shiftsJson))}→${shiftAuditSummary(
      parseShiftsJson(row.shiftsJson)
    )}`,
  });
  return toPolicyDTO(row);
}

/* --------------------------------- roster ---------------------------------- */

/** GET — the day roster: residents + derived states + per-state counts. */
export async function getRoster(
  instanceId: string,
  rawDate?: string | null
): Promise<RosterResponseDTO> {
  const day =
    rawDate !== undefined && rawDate !== null && rawDate !== ""
      ? parseLocalDate(rawDate)
      : startOfDay(new Date());
  if (!day) {
    throw new HttpError(400, "date must be YYYY-MM-DD", "BAD_DATE");
  }
  const now = new Date();
  const policyRow = await getPolicyRow(instanceId);
  const roster = await loadRoster(instanceId);
  const codes = roster.map((r) => r.studentCode);
  const { rows, counts } = summarizeRoster({
    policy: policyInputFromRow(policyRow),
    roster: codes,
    day,
    movements: (await repo.listDayMovements(
      instanceId,
      codes,
      repo.dayWindow(day).from,
      repo.dayWindow(day).to
    )).map((m) => ({
      studentCode: m.studentCode,
      direction: m.direction,
      occurredAt: m.occurredAt,
    })),
    allowances: (await repo.listDayAllowances(
      instanceId,
      codes,
      repo.dayWindow(day).from,
      repo.dayWindow(day).to
    )).map((a) => ({
      studentCode: a.studentCode,
      kind: a.kind,
      startsAt: a.startsAt,
      endsAt: a.endsAt,
    })),
    now,
  });
  const stateByCode = new Map(rows.map((r) => [r.studentCode, r]));
  const iso = (d: Date | null): string | null => (d ? d.toISOString() : null);
  return {
    policy: toPolicyDTO(policyRow),
    date: `${day.getFullYear()}-${String(day.getMonth() + 1).padStart(2, "0")}-${String(
      day.getDate()
    ).padStart(2, "0")}`,
    rows: roster.map((entry) => {
      const state = stateByCode.get(entry.studentCode);
      return {
        studentCode: entry.studentCode,
        name: entry.name,
        room: entry.room,
        building: entry.building,
        state: state?.state ?? "absent",
        lastMovementAt: iso(state?.lastMovementAt ?? null),
        lastDirection: state?.lastDirection ?? null,
        lateMinutes: state?.lateMinutes ?? null,
        expectedReturnAt: iso(state?.expectedReturnAt ?? null),
        overdue: state?.overdue ?? false,
      };
    }),
    counts,
  };
}

/* ------------------------------- movements --------------------------------- */

/**
 * The shared movement core (manual + QR): live-roster validation, the
 * alternation law, the server-stamped insert, the audit row, and the
 * freshly derived state for the student's day.
 */
async function insertValidatedMovement(
  instanceId: string,
  input: { studentCode: string; direction: "in" | "out" },
  method: "manual" | "qr",
  stamp: { recordedById: string; recordedByName: string },
  qrTokenId: string | null,
  actor: AttendanceActor
): Promise<{ movement: AttendanceMovement; state: DayState; studentName: string }> {
  const resident = await ensureLiveResident(instanceId, input.studentCode);

  const now = new Date();
  const { from, to } = repo.dayWindow(now);
  const todays = await repo.listStudentDayMovements(
    instanceId,
    input.studentCode,
    from,
    to
  );
  const last = todays.length > 0 ? todays[todays.length - 1] : null;

  /* THE ALTERNATION LAW (in/out strictly alternate per student per day) */
  if (input.direction === "in" && last?.direction === "in") {
    throw new HttpError(
      409,
      "Student is already checked in today",
      "DUPLICATE_CHECK_IN"
    );
  }
  if (input.direction === "out") {
    if (!last) {
      throw new HttpError(
        409,
        "No check-in today to check out from",
        "INVALID_CHECK_OUT"
      );
    }
    if (last.direction === "out") {
      throw new HttpError(
        409,
        "Student is already checked out today",
        "DUPLICATE_CHECK_OUT"
      );
    }
  }

  const movement = await repo.insertMovement({
    instanceId,
    studentCode: input.studentCode,
    direction: input.direction,
    method,
    occurredAt: now,
    recordedById: stamp.recordedById,
    recordedByName: stamp.recordedByName,
    qrTokenId,
  });

  await audit(
    actor,
    "instance.attendanceMovement",
    `${input.studentCode} ${input.direction === "in" ? "→ in" : "→ out"}`,
    {
      studentCode: input.studentCode,
      direction: input.direction,
      method,
      /* ROUND 136 meta convention — links the kiosk path's public-actor
       * row into the per-instance audit drilldown (instanceAuditWhere). */
      ...(method === "qr" ? { instance: instanceId } : {}),
    }
  );

  /* the freshly derived state (includes the movement just written) */
  const policyRow = await getPolicyRow(instanceId);
  const state = deriveDayState({
    policy: policyInputFromRow(policyRow),
    studentCode: input.studentCode,
    day: now,
    movements: [
      ...todays.map((m) => ({
        studentCode: m.studentCode,
        direction: m.direction,
        occurredAt: m.occurredAt,
      })),
      {
        studentCode: input.studentCode,
        direction: input.direction,
        occurredAt: now,
      },
    ],
    allowances: (
      await repo.listDayAllowances(instanceId, [input.studentCode], from, to)
    ).map((a) => ({
      studentCode: a.studentCode,
      kind: a.kind,
      startsAt: a.startsAt,
      endsAt: a.endsAt,
    })),
    now,
  });
  return { movement, state, studentName: resident.name };
}

/** POST — a MANUAL movement (occurredAt/recordedBy are server-stamped). */
export async function recordMovement(
  actor: AttendanceActor,
  instanceId: string,
  input: z.infer<typeof movementCreateSchema>
): Promise<{ movement: MovementDTO; state: DayState }> {
  const { movement, state, studentName } = await insertValidatedMovement(
    instanceId,
    input,
    "manual",
    { recordedById: actor.stampId, recordedByName: actor.stampName },
    null,
    actor
  );
  return { movement: toMovementDTO(movement, studentName), state };
}

function toMovementDTO(
  row: AttendanceMovement,
  studentName: string
): MovementDTO {
  return {
    id: row.id,
    studentCode: row.studentCode,
    studentName,
    direction: row.direction,
    method: row.method,
    occurredAt: row.occurredAt.toISOString(),
    recordedById: row.recordedById,
    recordedByName: row.recordedByName,
    qrTokenId: row.qrTokenId,
    createdAt: row.createdAt.toISOString(),
  };
}

/**
 * GET — the movements feed: keyset pagination (createdAt+id, newest
 * first), each row joined with the student's derived state for THAT
 * movement's local day + the roster name.
 */
export async function listMovements(
  instanceId: string,
  rawCursor?: string | null,
  rawLimit?: string | null
): Promise<{
  movements: MovementFeedDTO[];
  nextCursor: string | null;
}> {
  const cursorRaw = rawCursor ?? null;
  const cursor = cursorRaw ? decodeKeyset(cursorRaw) : null;
  if (cursorRaw && !cursor) {
    throw new HttpError(400, "Invalid pagination cursor", "BAD_CURSOR");
  }
  const parsed = rawLimit ? Number.parseInt(rawLimit, 10) : Number.NaN;
  const take = Number.isFinite(parsed)
    ? Math.min(MOVEMENT_FEED_MAX, Math.max(MOVEMENT_FEED_MIN, parsed))
    : MOVEMENT_FEED_DEFAULT;

  const [rows, roster] = await Promise.all([
    repo.listMovementsPage(instanceId, cursor, take),
    loadRoster(instanceId),
  ]);
  const names = new Map(roster.map((r) => [r.studentCode, r.name]));

  /* per-day state derivation for the page's (student, day) pairs —
   * the distinct days on a feed page are few; each day costs one bounded
   * chunk query pair (see dayStateBatch). */
  const policyRow = await getPolicyRow(instanceId);
  const now = new Date();
  const byDay = new Map<string, string[]>();
  for (const row of rows) {
    const day = startOfDay(row.occurredAt);
    const key = `${day.getFullYear()}-${day.getMonth()}-${day.getDate()}`;
    const codes = byDay.get(key) ?? [];
    if (!codes.includes(row.studentCode)) codes.push(row.studentCode);
    byDay.set(key, codes);
  }
  const stateByDayCode = new Map<string, DayState>();
  for (const [key, codes] of byDay) {
    const [y, m, d] = key.split("-").map((part) => Number.parseInt(part, 10));
    const states = await dayStateBatch(
      instanceId,
      policyInputFromRow(policyRow),
      new Date(y, m, d),
      codes,
      now
    );
    for (const [code, state] of states) stateByDayCode.set(`${key}:${code}`, state);
  }

  const movements = rows.map((row) => {
    const day = startOfDay(row.occurredAt);
    const key = `${day.getFullYear()}-${day.getMonth()}-${day.getDate()}`;
    return {
      ...toMovementDTO(row, names.get(row.studentCode) ?? "—"),
      state: stateByDayCode.get(`${key}:${row.studentCode}`)?.state ?? "absent",
    };
  });
  const nextCursor =
    rows.length === take ? encodeKeyset(rows[rows.length - 1]) : null;
  return { movements, nextCursor };
}

/* ------------------------------- allowances -------------------------------- */

function toAllowanceDTO(
  row: AttendanceAllowance,
  studentName: string
): AllowanceDTO {
  return {
    id: row.id,
    studentCode: row.studentCode,
    studentName,
    kind: row.kind,
    startsAt: row.startsAt.toISOString(),
    endsAt: row.endsAt.toISOString(),
    note: row.note,
    createdByName: row.createdByName,
    createdAt: row.createdAt.toISOString(),
  };
}

/** GET — upcoming + active allowances (bounded, soonest first). */
export async function listAllowances(
  instanceId: string
): Promise<{ allowances: AllowanceDTO[] }> {
  const [rows, roster] = await Promise.all([
    repo.listAllowances(instanceId, new Date()),
    loadRoster(instanceId),
  ]);
  const names = new Map(roster.map((r) => [r.studentCode, r.name]));
  return {
    allowances: rows.map((row) =>
      toAllowanceDTO(row, names.get(row.studentCode) ?? "—")
    ),
  };
}

/** POST — create an allowance (live-resident validated, audited). */
export async function createAllowance(
  actor: AttendanceActor,
  instanceId: string,
  input: z.infer<typeof allowanceCreateSchema>
): Promise<AllowanceDTO> {
  const resident = await ensureLiveResident(instanceId, input.studentCode);
  const startsAt = parseTimestamp(input.startsAt);
  const endsAt = parseTimestamp(input.endsAt);
  if (!startsAt || !endsAt) {
    throw new HttpError(400, "startsAt/endsAt must be ISO timestamps", "BAD_WINDOW");
  }
  if (endsAt.getTime() <= startsAt.getTime()) {
    throw new HttpError(400, "endsAt must be after startsAt", "BAD_WINDOW");
  }
  const row = await repo.insertAllowance({
    instanceId,
    studentCode: input.studentCode,
    kind: input.kind,
    startsAt,
    endsAt,
    note: input.note ?? null,
    createdById: actor.stampId,
    createdByName: actor.stampName,
  });
  await audit(actor, "instance.attendanceAllowanceCreate", `${input.studentCode} ${input.kind}`, {
    studentCode: input.studentCode,
    kind: input.kind,
    startsAt: startsAt.toISOString(),
    endsAt: endsAt.toISOString(),
  });
  return toAllowanceDTO(row, resident.name);
}

/** DELETE — remove an allowance (instance-scoped, audited). */
export async function deleteAllowance(
  actor: AttendanceActor,
  instanceId: string,
  allowanceId: string
): Promise<void> {
  const existing = await repo.findAllowance(instanceId, allowanceId);
  if (!existing) {
    throw new HttpError(404, "Allowance not found", "ALLOWANCE_NOT_FOUND");
  }
  await repo.deleteAllowance(instanceId, allowanceId);
  await audit(actor, "instance.attendanceAllowanceDelete", `${existing.studentCode} ${existing.kind}`, {
    studentCode: existing.studentCode,
    kind: existing.kind,
  });
}

/* ---------------------------------- QR -------------------------------------- */

/** POST — mint a single-use QR token for ONE student + direction. */
export async function mintQr(
  actor: AttendanceActor,
  instanceId: string,
  input: z.infer<typeof qrMintSchema>
): Promise<QrMintDTO> {
  await ensureLiveResident(instanceId, input.studentCode);
  const ttl = Math.min(
    QR_TTL_MAX_SECONDS,
    Math.max(QR_TTL_MIN_SECONDS, input.ttlSeconds ?? QR_TTL_DEFAULT_SECONDS)
  );
  const expiresAt = new Date(Date.now() + ttl * 1000);
  const token = randomBytes(32).toString("base64url");
  await repo.insertQrToken({
    instanceId,
    tokenHash: sha256Hex(token),
    studentCode: input.studentCode,
    direction: input.direction,
    gateLabel: input.gateLabel ?? null,
    expiresAt,
  });
  await audit(actor, "instance.attendanceQrMint", `${input.studentCode} ${input.direction}`, {
    studentCode: input.studentCode,
    direction: input.direction,
    ttlSeconds: String(ttl),
    ...(input.gateLabel ? { gate: input.gateLabel } : {}),
  });
  const qrPayload = JSON.stringify({
    v: 1,
    instanceId,
    studentCode: input.studentCode,
    direction: input.direction,
    gate: input.gateLabel ?? null,
    token,
    exp: expiresAt.getTime(),
  });
  return { token, expiresAt: expiresAt.toISOString(), qrPayload };
}

/**
 * POST — redeem a QR token at the gate kiosk (NOT staff-authenticated by
 * design; the token itself is the 256-bit bearer credential and the route
 * throttles per instance + IP).
 *
 * The lifecycle is unforgiving by law:
 *   unknown hash  → 404 QR_NOT_FOUND;
 *   expired       → 410 QR_EXPIRED;
 *   already used  → 410 QR_REUSED (the CAS claim — exactly one winner);
 *   then the SAME movement rules as the manual path: a deleted student
 *   404s (STUDENT_NOT_FOUND) and a stale direction still 409s.
 */
export async function redeemQr(
  instanceId: string,
  input: z.infer<typeof qrRedeemSchema>
): Promise<{ movement: MovementDTO; state: DayState }> {
  const tokenHash = sha256Hex(input.token);
  const row = await repo.findQrByHash(instanceId, tokenHash);
  if (!row) {
    throw new HttpError(404, "QR token not found", "QR_NOT_FOUND");
  }
  const now = new Date();
  if (row.expiresAt.getTime() <= now.getTime()) {
    throw new HttpError(410, "QR token has expired", "QR_EXPIRED");
  }
  /* THE SINGLE-USE CLAIM — updateMany CAS: concurrent scans of the same
   * QR resolve to exactly one movement; every loser reads QR_REUSED. */
  const claimed = await repo.claimQrToken(row.id, now);
  if (claimed === 0) {
    throw new HttpError(410, "QR token was already used", "QR_REUSED");
  }
  const actor: AttendanceActor = {
    stampId: "qr",
    stampName: row.gateLabel ?? "QR gate",
    audit: {
      actorType: "public",
      /* the token row that authorized the movement (the acting subject) */
      actorId: row.id,
      actorName: row.gateLabel ?? "qr-gate",
    },
  };
  const { movement, state, studentName } = await insertValidatedMovement(
    instanceId,
    { studentCode: row.studentCode, direction: row.direction === "out" ? "out" : "in" },
    "qr",
    { recordedById: actor.stampId, recordedByName: actor.stampName },
    row.id,
    actor
  );
  return { movement: toMovementDTO(movement, studentName), state };
}

/** Test/diagnostic surface: the sha256 form used for token storage. */
export function qrTokenHash(token: string): string {
  return sha256Hex(token);
}
