import { db } from "@/lib/db";
import { keysetPredicate, type KeysetCursor } from "@/lib/server/keyset";
import type {
  AttendanceAllowance,
  AttendanceMovement,
  AttendancePolicy,
  AttendanceQrToken,
} from "@prisma/client";

/**
 * Ashrilogic — attendance domain REPOSITORY (ROUND 166).
 *
 * The ONLY Prisma touchpoint of the الحضور والغياب domain. Every query
 * the service needs is declared here — the service never imports the
 * client. Shapes follow the domain-repository conventions of the sibling
 * domains (bounded takes, explicit selects, CAS transitions).
 *
 * BOUNDED-QUERY LAW (every list below is structurally capped):
 *  - day queries are window-scoped (occurredAt/startsAt within ONE local
 *    day) AND roster-chunked (studentCode IN …, 200 codes per statement —
 *    the SQL parameter ceiling stays far away);
 *  - the movement feed is keyset-paginated (createdAt+id cursor);
 *  - the roster read is capped (take) — a workspace's residents module is
 *    a curated list, not an unbounded event log.
 */

/** The SAMS roster module — attendance students ARE residents rows. */
export const ROSTER_MODULE_ID = "residents";

/** Roster-code chunk size for IN queries (bounded per statement). */
export const ROSTER_CHUNK = 200;

/** Cap on the roster read (residents module rows per workspace). */
export const ROSTER_TAKE = 2000;

/** Cap on the allowance list (upcoming + active). */
export const ALLOWANCE_TAKE = 200;

/** Movements feed page bounds (clamped again at the service boundary). */
export const MOVEMENT_PAGE_MIN = 20;
export const MOVEMENT_PAGE_MAX = 100;

/* ------------------------------- policy ----------------------------------- */

export async function findPolicy(
  instanceId: string
): Promise<AttendancePolicy | null> {
  return db.attendancePolicy.findUnique({ where: { instanceId } });
}

/** Lazy default creation — the 1:1 row is born with the schema defaults. */
export async function upsertPolicy(
  instanceId: string,
  data: {
    dayStartMin: number;
    dayEndMin: number;
    graceMin: number;
    absenceEvalMin: number;
    requireReview: boolean;
    /** ROUND 167 (دوام) — the serialized shift schedule ("" = legacy window). */
    shiftsJson: string;
  }
): Promise<AttendancePolicy> {
  return db.attendancePolicy.upsert({
    where: { instanceId },
    create: { instanceId, ...data },
    update: data,
  });
}

/* ------------------------------ movements --------------------------------- */

export async function insertMovement(
  data: Pick<
    AttendanceMovement,
    | "instanceId"
    | "studentCode"
    | "direction"
    | "method"
    | "occurredAt"
    | "recordedById"
    | "recordedByName"
    | "qrTokenId"
  >
): Promise<AttendanceMovement> {
  return db.attendanceMovement.create({ data });
}

/**
 * Every movement of ONE student inside a day window — the alternation law
 * and the day derivation both read exactly this (ordered, single-student,
 * window-bounded).
 */
export async function listStudentDayMovements(
  instanceId: string,
  studentCode: string,
  from: Date,
  to: Date
): Promise<AttendanceMovement[]> {
  return db.attendanceMovement.findMany({
    where: {
      instanceId,
      studentCode,
      occurredAt: { gte: from, lt: to },
    },
    orderBy: { occurredAt: "asc" },
    take: 500,
  });
}

/**
 * Every movement of a roster chunk inside a day window — the roster
 * derivation's batch read. `take` is a belt-and-braces ceiling (a single
 * student/day pair cannot exceed the alternation alphabet in practice).
 */
export async function listDayMovements(
  instanceId: string,
  studentCodes: readonly string[],
  from: Date,
  to: Date
): Promise<AttendanceMovement[]> {
  const rows: AttendanceMovement[] = [];
  for (let i = 0; i < studentCodes.length; i += ROSTER_CHUNK) {
    const chunk = studentCodes.slice(i, i + ROSTER_CHUNK);
    const page = await db.attendanceMovement.findMany({
      where: {
        instanceId,
        studentCode: { in: chunk },
        occurredAt: { gte: from, lt: to },
      },
      orderBy: [{ occurredAt: "asc" }, { id: "asc" }],
      take: ROSTER_CHUNK * 24,
    });
    rows.push(...page);
  }
  return rows;
}

/**
 * The movements FEED — keyset pagination on the (createdAt, id) total
 * order (newest first), the same cursor law the activities/orders feeds
 * obey. `take` is pre-clamped by the service (20..100).
 */
export async function listMovementsPage(
  instanceId: string,
  cursor: KeysetCursor | null,
  take: number
): Promise<AttendanceMovement[]> {
  return db.attendanceMovement.findMany({
    where: {
      instanceId,
      ...(cursor ? keysetPredicate(cursor) : {}),
    },
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    take,
  });
}

/* ------------------------------ allowances -------------------------------- */

/** Upcoming + active allowances (endsAt in the future), soonest first. */
export async function listAllowances(
  instanceId: string,
  now: Date
): Promise<AttendanceAllowance[]> {
  return db.attendanceAllowance.findMany({
    where: { instanceId, endsAt: { gt: now } },
    orderBy: { startsAt: "asc" },
    take: ALLOWANCE_TAKE,
  });
}

/**
 * Allowances overlapping a day window for a roster chunk — the derivation
 * read (leave/excused/authorized need whole-day coverage, outside needs
 * movement coverage; both are decided by the pure engine off these rows).
 */
export async function listDayAllowances(
  instanceId: string,
  studentCodes: readonly string[],
  from: Date,
  to: Date
): Promise<AttendanceAllowance[]> {
  const rows: AttendanceAllowance[] = [];
  for (let i = 0; i < studentCodes.length; i += ROSTER_CHUNK) {
    const chunk = studentCodes.slice(i, i + ROSTER_CHUNK);
    const page = await db.attendanceAllowance.findMany({
      where: {
        instanceId,
        studentCode: { in: chunk },
        startsAt: { lt: to },
        endsAt: { gt: from },
      },
      take: ROSTER_CHUNK * 8,
    });
    rows.push(...page);
  }
  return rows;
}

export async function insertAllowance(
  data: Pick<
    AttendanceAllowance,
    "instanceId" | "studentCode" | "kind" | "startsAt" | "endsAt" | "note" | "createdById" | "createdByName"
  >
): Promise<AttendanceAllowance> {
  return db.attendanceAllowance.create({ data });
}

export async function findAllowance(
  instanceId: string,
  id: string
): Promise<AttendanceAllowance | null> {
  return db.attendanceAllowance.findFirst({ where: { id, instanceId } });
}

export async function deleteAllowance(
  instanceId: string,
  id: string
): Promise<number> {
  return db.attendanceAllowance.deleteMany({ where: { id, instanceId } }).then((r) => r.count);
}

/* ------------------------------ QR tokens --------------------------------- */

export async function insertQrToken(
  data: Pick<
    AttendanceQrToken,
    "instanceId" | "tokenHash" | "studentCode" | "direction" | "gateLabel" | "expiresAt"
  >
): Promise<AttendanceQrToken> {
  return db.attendanceQrToken.create({ data });
}

/**
 * The redeem lookup — instance-scoped (a token minted on workspace A can
 * never be redeemed against workspace B's URL) and hash-addressed (the
 * raw token is never stored, exactly like the verification-token law).
 */
export async function findQrByHash(
  instanceId: string,
  tokenHash: string
): Promise<AttendanceQrToken | null> {
  return db.attendanceQrToken.findFirst({ where: { instanceId, tokenHash } });
}

/**
 * THE SINGLE-USE CLAIM (CAS): exactly ONE concurrent redemption can flip
 * usedAt from null — the loser observes count = 0 and gets QR_REUSED.
 * Mirrors the campaign claim transition's atomicity law.
 */
export async function claimQrToken(
  id: string,
  usedAt: Date
): Promise<number> {
  const result = await db.attendanceQrToken.updateMany({
    where: { id, usedAt: null },
    data: { usedAt },
  });
  return result.count;
}

/* --------------------------------- roster ---------------------------------- */

/**
 * The live residents rows (the roster source of truth). Codes/names/rooms
 * live inside dataJson aligned with the residents preset cols — parsed by
 * the service (this layer stays prisma-shaped).
 */
export async function listRosterRecords(
  instanceId: string
): Promise<{ id: string; dataJson: string; createdAt: Date }[]> {
  return db.moduleRecord.findMany({
    where: { instanceId, moduleId: ROSTER_MODULE_ID, deletedAt: null },
    orderBy: { createdAt: "asc" },
    take: ROSTER_TAKE,
    select: { id: true, dataJson: true, createdAt: true },
  });
}

/** The day window [local midnight, next midnight) as Date bounds. */
export function dayWindow(day: Date): { from: Date; to: Date } {
  const from = new Date(day.getFullYear(), day.getMonth(), day.getDate());
  const to = new Date(from.getTime() + 24 * 60 * 60_000);
  return { from, to };
}
