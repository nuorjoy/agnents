import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";

/**
 * Ashrilogic — wallet-grants domain REPOSITORY (ROUND 168, منح المحفظة).
 *
 * The persistence seam for the Super-Admin BULK wallet credit: audience
 * resolution (live instances only — deletedAt: null — matching the target
 * package when one is selected) + the bounded keyset batches the grant
 * engine walks. Every Prisma touch for the grant audience lives here and
 * nowhere else; the money primitive itself stays in wallet.ts (the CAS
 * engine — this repository NEVER writes a balance).
 */

/** The audience resolution shape shared by count + batch listing. */
function audienceWhere(target: "all" | "plan", packageId?: string): Prisma.InstanceWhereInput {
  return {
    deletedAt: null,
    ...(target === "plan" && packageId ? { packageId } : {}),
  };
}

/** BATCH_SIZE — the attendance-roster idiom: bounded keyset chunks so a
 *  mid-flight crash leaves only completed per-recipient credits (each is
 *  its own committed transaction; the WalletTxn ledger is the truth). */
export const GRANT_BATCH = 200;

/** The live-subscriber audience size for the composer's live preview. */
export async function countAudience(
  target: "all" | "plan",
  packageId?: string
): Promise<number> {
  return db.instance.count({ where: audienceWhere(target, packageId) });
}

/** One keyset batch of recipient ids (id-ascending — stable under inserts,
 *  unlike a (createdAt, id) ladder over a mutating table). Pass the last
 *  id of the previous batch as the cursor; null starts from the top. */
export async function listAudienceBatch(
  target: "all" | "plan",
  packageId: string | undefined,
  cursorId: string | null,
  take: number
): Promise<{ id: string }[]> {
  return db.instance.findMany({
    where: {
      ...audienceWhere(target, packageId),
      ...(cursorId ? { id: { gt: cursorId } } : {}),
    },
    orderBy: { id: "asc" },
    take,
    select: { id: true },
  });
}

/** The target package row for the preview label (null = unknown id). */
export async function findPackageLabel(
  packageId: string
): Promise<{ nameAr: string; nameEn: string } | null> {
  const row = await db.package.findUnique({
    where: { id: packageId },
    select: { nameAr: true, nameEn: true },
  });
  return row ?? null;
}
