import { NextResponse } from "next/server";
import { routeHandler, ctxAdmin } from "@/lib/server/route";
import * as service from "./service";

/**
 * Ashrilogic — wallet-grants domain CONTROLLER (ROUND 168, منح المحفظة).
 *
 * The HTTP seam for the Super-Admin bulk wallet credit. Every handler is a
 * `routeHandler(...)` — correlation ids, the bounded body reader and the
 * zod 400 envelope come from the unified wrapper. Guard surface is
 * DECLARATIVE (ROUND 127):
 *
 *  - GET /api/admin/wallet-grants?target=all|plan&packageId=… — the
 *    audience PREVIEW (super+admin read: the composer's live count + the
 *    confirmation receipt figure — the exact audience a grant would hit).
 *  - POST /api/admin/wallet-grants — the grant itself (super+admin,
 *    MONEY-MOVING): origin CSRF gate + the MFA-enrollment policy gate +
 *    the standard admin mutation throttle (30 / 10 min per admin + IP).
 */

/** Standard admin mutation throttle: 30 requests / 10 min per admin + IP. */
const GRANT_RULE = { limit: 30, windowMs: 10 * 60 * 1000 };

/** GET /api/admin/wallet-grants — audience preview (count + label). */
export const adminAudience = routeHandler(
  "preview wallet grant audience",
  { admin: { roles: ["super", "admin"] } },
  async (ctx): Promise<NextResponse> => {
    const params = new URL(ctx.req.url).searchParams;
    const rawTarget = params.get("target");
    const target = rawTarget === "plan" ? "plan" : "all";
    const packageId = params.get("packageId") ?? undefined;
    const dto = await service.audiencePreview(target, packageId);
    return NextResponse.json(dto);
  }
);

/** POST /api/admin/wallet-grants — execute the bulk credit. */
export const adminGrant = routeHandler(
  "grant wallet credit",
  {
    origin: true,
    admin: { roles: ["super", "admin"], withRequest: true },
    rateLimit: {
      key: (parts) => `wallet-grant:${parts.adminId()}:${parts.ip}`,
      rule: GRANT_RULE,
      body: { error: "Too many grant requests — try again later", code: "RATE_LIMITED" },
    },
  },
  async (ctx): Promise<NextResponse> => {
    const admin = ctxAdmin(ctx);
    const input = await ctx.parseBody(service.grantCreateSchema);
    const result = await service.executeGrant(input, { id: admin.id, name: admin.name });
    return NextResponse.json(result, { status: 201 });
  }
);
