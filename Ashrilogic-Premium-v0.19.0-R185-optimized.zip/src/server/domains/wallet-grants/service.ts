import { randomBytes } from "node:crypto";
import { z } from "zod";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { toDisplayUnits } from "@/lib/server/money";
import {
  creditWalletGrant,
  MAX_GRANT_MINOR,
  MIN_GRANT_MINOR,
} from "@/lib/server/wallet";
import { HttpError } from "@/lib/server/route";
import * as repository from "./repository";

/**
 * Ashrilogic — wallet-grants domain SERVICE (ROUND 168, منح المحفظة).
 *
 * The Super-Admin bulk goodwill credit — the owner's directive: «add a
 * certain financial amount to ALL subscribers or to the subscribers of a
 * specific package». Business shape:
 *
 *  - AUDIENCE: every LIVE workspace (deletedAt: null). target "plan"
 *    narrows to the CURRENT package match; target "all" includes trial
 *    workspaces with no package at all («جميع المشتركين» — a goodwill
 *    gesture reaches every live subscriber, not just the paid ones).
 *  - EXECUTION: bounded keyset batches (GRANT_BATCH = 200). Per recipient:
 *    ONE transaction through the CAS engine — the "grant" WalletTxn row
 *    (reference "grant:<grantId>", the admin's note, actorType "admin",
 *    masked actor label) + the zero-delay activity feed row. ZERO direct
 *    balance writes.
 *  - CRASH HONESTY: each per-recipient credit is independently committed;
 *    a mid-flight crash leaves the completed credits in place — the
 *    append-only ledger (reference carries the grant identity) is the
 *    reconciliation truth. No half-written balances can exist.
 *  - TRAIL: one platform.walletGrant summary row per run (count, amount,
 *    target, note) — the money-moving audit law.
 *
 * HTTP never appears here: no Request, no NextResponse — the controller
 * and the unified route wrapper own the envelope; HttpError is the domain
 * signal.
 */

/* ------------------------------------------------------------------ */
/* zod — the route-boundary schema                                     */
/* ------------------------------------------------------------------ */

export const grantCreateSchema = z.object({
  /** "all" = every live subscriber; "plan" = subscribers of one package. */
  target: z.enum(["all", "plan"]),
  /** required when (and only when) target = "plan". */
  packageId: z.string().trim().min(1).max(64).optional(),
  /** integer MINOR units (money.ts law) — the addon-pricing bounds law:
   *  $1 (100) .. $100k (10,000,000) per recipient. */
  amountMinor: z.number().int().min(MIN_GRANT_MINOR).max(MAX_GRANT_MINOR),
  /** optional admin note riding the ledger row + the activity feed. */
  note: z.string().trim().max(200).optional().default(""),
}).refine((data) => data.target !== "plan" || (data.packageId ?? "") !== "", {
  message: "packageId is required when target is \"plan\"",
});

export type GrantCreateInput = z.infer<typeof grantCreateSchema>;

/* ------------------------------------------------------------------ */
/* the acting admin (audit attribution)                                */
/* ------------------------------------------------------------------ */

export interface GrantActor {
  id: string;
  name: string;
}

/* ------------------------------------------------------------------ */
/* audience preview (the composer's live count)                        */
/* ------------------------------------------------------------------ */

export interface GrantAudienceDTO {
  target: "all" | "plan";
  /** live subscribers matching the target (the exact grant audience). */
  count: number;
  /** bilingual package label when target = "plan" (null on unknown ids). */
  packageName: string | null;
}

/** Resolve the audience size + label BEFORE any money moves (the composer
 *  fetches this for its live preview and the confirmation receipt). */
export async function audiencePreview(
  target: "all" | "plan",
  packageId?: string
): Promise<GrantAudienceDTO> {
  if (target !== "all" && target !== "plan") {
    throw new HttpError(400, 'target must be "all" or "plan"', "GRANT_BAD_TARGET");
  }
  if (target === "plan" && !packageId) {
    throw new HttpError(400, "packageId is required when target is \"plan\"", "GRANT_PACKAGE_REQUIRED");
  }
  let packageName: string | null = null;
  if (target === "plan") {
    const pkg = await repository.findPackageLabel(packageId!);
    if (!pkg) {
      throw new HttpError(404, "Package not found", "GRANT_PACKAGE_NOT_FOUND");
    }
    packageName = `${pkg.nameAr} · ${pkg.nameEn}`;
  }
  const count = await repository.countAudience(target, packageId);
  return { target, count, packageName };
}

/* ------------------------------------------------------------------ */
/* execution (bounded batches, per-recipient CAS credits)              */
/* ------------------------------------------------------------------ */

export interface GrantResultDTO {
  /** the run identity carried by every ledger row (reference "grant:<id>"). */
  grantId: string;
  /** audience size resolved at run start. */
  audience: number;
  /** recipients actually credited. */
  credited: number;
  /** recipients skipped (wallet cap / CAS conflict — surfaced honestly). */
  skipped: number;
  amountMinor: number;
}

/** Mint the run identity (GRN- + CSPRNG hex — the transfer-reference law). */
function newGrantId(): string {
  return `GRN-${randomBytes(6).toString("hex")}`;
}

/**
 * Execute one bulk grant. The audience is resolved ONCE (count), then
 * walked in bounded keyset batches; each recipient is its own committed
 * CAS transaction. Returns the honest receipt (credited vs skipped).
 */
export async function executeGrant(
  input: GrantCreateInput,
  actor: GrantActor
): Promise<GrantResultDTO> {
  if (input.target === "plan" && !(input.packageId ?? "")) {
    throw new HttpError(400, "packageId is required when target is \"plan\"", "GRANT_PACKAGE_REQUIRED");
  }
  if (input.target === "plan") {
    const pkg = await repository.findPackageLabel(input.packageId!);
    if (!pkg) {
      throw new HttpError(404, "Package not found", "GRANT_PACKAGE_NOT_FOUND");
    }
  }

  const audience = await repository.countAudience(input.target, input.packageId);
  const grantId = newGrantId();
  const reference = `grant:${grantId}`;
  const actorName = maskEmail(actor.name);
  const note = input.note ?? "";
  /* bilingual default note when the admin left it empty (the activity feed
   * renders it verbatim next to the amount). */
  const effectiveNote = note || "منحة محفظة من الإدارة · Wallet grant from the platform";

  let credited = 0;
  let skipped = 0;
  let cursorId: string | null = null;
  for (;;) {
    const batch = await repository.listAudienceBatch(
      input.target,
      input.packageId,
      cursorId,
      repository.GRANT_BATCH
    );
    if (batch.length === 0) break;
    for (const recipient of batch) {
      const outcome = await creditWalletGrant({
        instanceId: recipient.id,
        amountMinor: input.amountMinor,
        reference,
        note: effectiveNote,
        actorType: "admin",
        actorName,
        activityKind: "actWalletGrant",
        activityMeta: {
          amount: input.amountMinor / 100,
          currency: "SAR",
          reference,
          note: effectiveNote,
        },
      });
      if (outcome.ok) {
        credited += 1;
      } else {
        skipped += 1;
      }
    }
    cursorId = batch[batch.length - 1]!.id;
    if (batch.length < repository.GRANT_BATCH) break;
  }

  /* the money-moving summary trail — the per-recipient truth is the
   * append-only WalletTxn ledger (reference carries the grant identity). */
  await logAudit({
    actorType: "admin",
    actorId: actor.id,
    actorName: actor.name,
    action: "platform.walletGrant",
    targetLabel: grantId,
    meta: {
      count: String(credited),
      skipped: String(skipped),
      audience: String(audience),
      amountMinor: String(input.amountMinor),
      amountMajor: String(toDisplayUnits(input.amountMinor)),
      target: input.target,
      ...(input.target === "plan" && input.packageId ? { packageId: input.packageId } : {}),
      ...(note ? { note } : {}),
    },
  });

  return {
    grantId,
    audience,
    credited,
    skipped,
    amountMinor: input.amountMinor,
  };
}
