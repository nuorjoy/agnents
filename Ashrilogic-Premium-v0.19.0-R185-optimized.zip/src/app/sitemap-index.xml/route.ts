import { NextResponse } from "next/server";
import { SITE_URL } from "@/lib/site-url";
import { resolveShardPlan, shardUrls } from "@/lib/server/sitemap-plan";

export const dynamic = "force-dynamic";

/**
 * GET /sitemap-index.xml (rewritten from /sitemap.xml) — the SITEMAP INDEX (ROUND 172).
 *
 * Next.js does NOT auto-emit a sitemap index for `generateSitemaps` shards
 * — /sitemap.xml was a 404 on production while the shard files lived at
 * /sitemap/{id}.xml. Crawlers conventionally probe /sitemap.xml first, so
 * this route serves a proper protocol-compliant <sitemapindex> listing
 * every shard from the SAME planner the shards use
 * (src/lib/server/sitemap-plan.ts) — one source of truth, zero drift:
 * a DB hiccup degrades the index to the core-only plan exactly like the
 * shard files and robots.txt do.
 *
 * Caching: s-maxage=600 puts the response on Vercel's CDN — crawler and
 * PageSpeed fetches are answered at the edge (~ms) instead of waking the
 * serverless function (the cold-start path that timed out robots.txt
 * probes in PageSpeed Insights). stale-while-revalidate keeps serving the
 * previous index for a day while a refresh regenerates in the background.
 */
export async function GET() {
  try {
    const plan = await resolveShardPlan();
    const urls = shardUrls(plan, SITE_URL);
    const lastmod = new Date().toISOString();
    const entries = urls
      .map((loc) => `  <sitemap>\n    <loc>${loc}</loc>\n    <lastmod>${lastmod}</lastmod>\n  </sitemap>`)
      .join("\n");
    const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${entries}\n</sitemapindex>\n`;
    return new NextResponse(xml, {
      headers: {
        "Content-Type": "application/xml; charset=utf-8",
        "Cache-Control": "public, max-age=0, s-maxage=600, stale-while-revalidate=86400",
      },
    });
  } catch (error) {
    console.error("GET /sitemap.xml failed:", error);
    /* degrade to the core-only index — never a 500 for crawlers: the core
       shard (0) is deterministic and always exists in the plan contract. */
    const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <sitemap>\n    <loc>${SITE_URL}/sitemap/0.xml</loc>\n    <lastmod>${new Date().toISOString()}</lastmod>\n  </sitemap>\n</sitemapindex>\n`;
    return new NextResponse(xml, {
      status: 200,
      headers: {
        "Content-Type": "application/xml; charset=utf-8",
        "Cache-Control": "public, max-age=0, s-maxage=60, stale-while-revalidate=3600",
      },
    });
  }
}
