import type { Metadata } from "next";

/**
 * Ashrilogic — /admin route (Task 3-d SEO hardening: Super Admin is NEAR-HIDDEN).
 *
 * Server component so the page can export `metadata` with a hard
 * `robots: { index: false, follow: false }` directive — the AdminApp shell
 * is a client component imported below. The admin layout also emits the
 * same directive (defense-in-depth: layout + page both say noindex/nofollow
 * so a future refactor of either cannot accidentally re-expose the panel).
 *
 * NEVER linked from any public marketing surface, never listed in the
 * sitemap, and disallowed in robots.txt — the URL is provisioned to the
 * platform operator out-of-band only.
 */
export const metadata: Metadata = {
  /* Task 6 — drop `absolute` so the root layout's "%s · أشرِيلوجيك"
     template applies → rendered <title> is "لوحة الإدارة · أشرِيلوجيك"
     per spec (was "Ashrilogic Admin" — English, no Arabic brand).
     noindex/nofollow preserved. */
  title: "لوحة الإدارة",
  description:
    "Ashrilogic Super-Admin control panel — manage systems and subscribers.",
  robots: { index: false, follow: false },
  alternates: { canonical: "/admin" },
};

export default async function AdminPage() {
  const { AdminApp } = await import("@/components/admin/admin-app");
  return <AdminApp />;
}
