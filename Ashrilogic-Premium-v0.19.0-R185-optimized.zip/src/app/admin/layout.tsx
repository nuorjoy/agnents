import type { Metadata } from "next";

export const metadata: Metadata = {
  /* Task 6 — Arabic admin-subtree fallback title (was English
     "Admin Panel"); the root layout's "%s · أشرِيلوجيك" template
     appends the brand → "لوحة الإدارة · أشرِيلوجيك". Only renders if a
     future admin sub-route omits its own metadata. */
  title: "لوحة الإدارة",
  description: "Ashrilogic administrator control panel — manage systems and subscribers.",
  robots: { index: false, follow: false },
};

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return children;
}
