import type { Metadata } from "next";

/**
 * Ashrilogic — /admin/login route (Task 3-d SEO hardening: Super Admin login
 * is NEAR-HIDDEN).
 *
 * Server component so the page can export `metadata` with a hard
 * `robots: { index: false, follow: false }` directive. Renders the AdminApp
 * shell; since the session is empty on a fresh deep-link, the login card
 * shows. Authenticated visitors are redirected to /admin by the shell.
 *
 * NEVER linked from any public marketing surface, never listed in the
 * sitemap, disallowed in robots.txt — the URL is provisioned to the platform
 * operator out-of-band only.
 */
export const metadata: Metadata = {
  /* Task 6 — drop `absolute` so the root layout's "%s · أشرِيلوجيك"
     template applies → rendered <title> is "دخول الإدارة · أشرِيلوجيك"
     per spec (was "Ashrilogic Admin · Sign in" — English, no Arabic
     brand). noindex/nofollow preserved. */
  title: "دخول الإدارة",
  description: "Ashrilogic Super-Admin sign-in.",
  robots: { index: false, follow: false },
  alternates: { canonical: "/admin/login" },
};

export default async function AdminLoginPage() {
  const { AdminApp } = await import("@/components/admin/admin-app");
  return <AdminApp />;
}
