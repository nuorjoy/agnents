import type { Metadata, Viewport } from "next";
import { headers } from "next/headers";
// Task 3-c — single source of truth for SEO canonical URLs (env-overridable).
import { SITE_URL, SITE_URL_OBJ } from "@/lib/site-url";
import { dictLang, dirFor } from "@/lib/locales";
// Self-hosted fonts (@fontsource) — WOFF2 + @font-face, zero external CDN requests.
import "@fontsource/cairo/arabic-400.css";
import "@fontsource/cairo/arabic-500.css";
import "@fontsource/cairo/arabic-600.css";
import "@fontsource/cairo/arabic-700.css";
import "@fontsource/cairo/arabic-800.css";
import "@fontsource/cairo/arabic-900.css";
import "@fontsource/cairo/latin-400.css";
import "@fontsource/cairo/latin-500.css";
import "@fontsource/cairo/latin-600.css";
import "@fontsource/cairo/latin-700.css";
import "@fontsource/cairo/latin-800.css";
import "@fontsource/cairo/latin-900.css";
import "@fontsource/inter/latin-400.css";
import "@fontsource/inter/latin-500.css";
import "@fontsource/inter/latin-600.css";
import "@fontsource/inter/latin-700.css";
import "@fontsource/inter/latin-800.css";
import "@fontsource/inter/latin-900.css";
import "@fontsource/tajawal/arabic-400.css";
import "@fontsource/tajawal/arabic-500.css";
import "@fontsource/tajawal/arabic-700.css";
import "@fontsource/tajawal/arabic-800.css";
import "@fontsource/tajawal/arabic-900.css";
/* ROUND 86 — Tajawal's Latin subset + the missing arabic-400: the font is
 * now a FULL per-surface choice (site / store / system), so it must cover
 * Latin text at body weight too, not just the display headline weights. */
import "@fontsource/tajawal/latin-400.css";
import "@fontsource/tajawal/latin-500.css";
import "@fontsource/tajawal/latin-700.css";
import "@fontsource/tajawal/latin-800.css";
/* ROUND 88 — the four NEW per-surface font choices (Settings → الألوان
 * والخطوط): Rubik, Almarai, IBM Plex Sans Arabic and Noto Kufi Arabic.
 * Arabic + Latin subsets at the weights the design system actually uses
 * (400 body / 500 semibold / 700 bold; Almarai ships 300-800 without 500,
 * so its set is 400/700/800). Self-hosted @fontsource = zero external
 * CDN requests, same as every other face above. */
import "@fontsource/rubik/arabic-400.css";
import "@fontsource/rubik/arabic-500.css";
import "@fontsource/rubik/arabic-700.css";
import "@fontsource/rubik/latin-400.css";
import "@fontsource/rubik/latin-500.css";
import "@fontsource/rubik/latin-700.css";
import "@fontsource/almarai/arabic-400.css";
import "@fontsource/almarai/arabic-700.css";
import "@fontsource/almarai/arabic-800.css";
import "@fontsource/almarai/latin-400.css";
import "@fontsource/almarai/latin-700.css";
import "@fontsource/ibm-plex-sans-arabic/arabic-400.css";
import "@fontsource/ibm-plex-sans-arabic/arabic-500.css";
import "@fontsource/ibm-plex-sans-arabic/arabic-700.css";
import "@fontsource/ibm-plex-sans-arabic/latin-400.css";
import "@fontsource/ibm-plex-sans-arabic/latin-500.css";
import "@fontsource/ibm-plex-sans-arabic/latin-700.css";
import "@fontsource/noto-kufi-arabic/arabic-400.css";
import "@fontsource/noto-kufi-arabic/arabic-500.css";
import "@fontsource/noto-kufi-arabic/arabic-700.css";
import "@fontsource/noto-kufi-arabic/latin-400.css";
import "@fontsource/noto-kufi-arabic/latin-500.css";
import "@fontsource/noto-kufi-arabic/latin-700.css";
/* ROUND 41 — Hindi (hi): Devanagari fallback, bundled locally. Devanagari
 * glyphs resolve here when no earlier face covers them.
 * ROUND 145 (perf) — the six CJK @fontsource faces (noto-sans-sc/jp/kr,
 * 400+700 each — ~600KB of @font-face CSS shipped on every page for locales
 * the product does not serve today) were removed. The CJK family names stay
 * in the globals.css / surface-styling fallback stacks as inert CSS
 * fallbacks (browsers fall through to system fonts); re-import the faces
 * when zh/ja/ko actually ship. */
import "@fontsource/noto-sans-devanagari/400.css";
import "@fontsource/noto-sans-devanagari/500.css";
import "@fontsource/noto-sans-devanagari/600.css";
import "@fontsource/noto-sans-devanagari/700.css";
import "./globals.css";
/* ROUND 170 (performance) — critical above-the-fold font preloads.
 * @fontsource faces are plain @font-face CSS: the browser only DISCOVERS
 * a font file after the render-blocking CSS parses AND the first layout
 * maps glyphs to families — measured on production mobile as the LCP h1
 * repainting seconds after HTML arrival (the Arabic LCP text waited for
 * Tajawal-800 + Cairo body faces that started downloading late, queued
 * behind ~720KB of JS on a simulated slow-4G). Preloading the four faces
 * the above-the-fold RTL paint actually uses (Tajawal 800 = font-display
 * headlines; Cairo 400/600/700 = body, semibold badges, bold labels)
 * starts those downloads in parallel with the CSS itself.
 * The URLs come from direct bundler asset imports (hashed, zero drift);
 * see src/types/static-assets.d.ts for the module declarations. */
import tajawalArabic800Url from "@fontsource/tajawal/files/tajawal-arabic-800-normal.woff2";
import cairoArabic400Url from "@fontsource/cairo/files/cairo-arabic-400-normal.woff2";
import cairoArabic600Url from "@fontsource/cairo/files/cairo-arabic-600-normal.woff2";
import cairoArabic700Url from "@fontsource/cairo/files/cairo-arabic-700-normal.woff2";
/* ROUND 177 — latin + devanagari faces for the COOKIE-AWARE preload set:
 * a visitor whose `ashrlc-lang` cookie says en/hi renders latin/devanagari
 * glyphs above the fold, so the four arabic preloads above would be pure
 * wasted bandwidth for them (and their real LCP faces would still be
 * discovered late). The RootLayout resolves the same cookie the public
 * pages use (resolveLandingLang — the layout already reads headers() for
 * the CSP nonce, so no new dynamism is introduced) and swaps the preload
 * set per language; ar keeps the exact R170 behavior. */
import tajawalLatin800Url from "@fontsource/tajawal/files/tajawal-latin-800-normal.woff2";
import cairoLatin400Url from "@fontsource/cairo/files/cairo-latin-400-normal.woff2";
import cairoLatin600Url from "@fontsource/cairo/files/cairo-latin-600-normal.woff2";
import cairoLatin700Url from "@fontsource/cairo/files/cairo-latin-700-normal.woff2";
import devanagari400Url from "@fontsource/noto-sans-devanagari/files/noto-sans-devanagari-devanagari-400-normal.woff2";
import devanagari600Url from "@fontsource/noto-sans-devanagari/files/noto-sans-devanagari-devanagari-600-normal.woff2";
import devanagari700Url from "@fontsource/noto-sans-devanagari/files/noto-sans-devanagari-devanagari-700-normal.woff2";
import { resolveLandingLang } from "@/lib/server/landing-lang";
import { AppProviders } from "@/components/providers";
import { Toaster } from "@/components/ui/sonner";
import { StructuredData } from "@/components/structured-data";
/* ROUND 87 — the platform identity bridge: applies the public brand
   (primary color ramp / radius / favicon / theme-color) to the live DOM
   once per session, app-lifetime, zero visual footprint. */
import { IdentityBridge } from "@/components/shared/identity-bridge";

/**
 * ROUND 67 — pre-paint boot gate script.
 *
 * Runs inline in <head> BEFORE the first paint (blocking, ~200 bytes). It
 * reads the SPA's persisted view state from localStorage and, whenever a
 * NON-landing view is stored (dashboard / wizard / select / transition),
 * marks <html data-boot="1"> so the pre-paint CSS (globals.css) can hide
 * the server-rendered landing and show the branded boot splash instead —
 * eliminating the landing flash that made every workspace refresh look
 * like "exit dashboard → automatic re-login".
 *
 * The flag is removed by the page shell as soon as the persisted view has
 * actually mounted; the 6s watchdog below guarantees the content can never
 * stay hidden if JavaScript fails to boot (the SSR landing then shows).
 * Path-scoped to "/" — every other route (/login, /admin, /sites/*) renders
 * its own server page and must never be gated. Strictly static (no PII, no
 * dynamic values) so it is CSP-nonce'd and fully cacheable.
 *
 * ROUND 78 — TITLE RESTORE: the same pre-paint script also restores the
 * tab title from the last-committed snapshot (`ashrlc:title`, written by
 * useDocumentTitle on every commit while on "/"). Before this, a returning
 * dashboard session painted the static SSR title (أشرِيلوجيك…) for the
 * first frames and only re-titled after the instance query resolved — the
 * visible "ashrilogic → system name" flash the product owner reported.
 * Restoring pre-paint makes the very FIRST frame carry the correct title;
 * useDocumentTitle then re-commits the same (or refreshed) title after boot.
 */
const BOOT_GATE_SCRIPT = `(function(){try{if(location.pathname!=="/")return;var raw=localStorage.getItem("ashrilogic-ui");if(!raw)return;var v=null;try{v=JSON.parse(raw).state.view}catch(e){}if(v==="dashboard"||v==="wizard"||v==="select"||v==="transition"){var d=document.documentElement;d.setAttribute("data-boot","1");setTimeout(function(){d.removeAttribute("data-boot")},6000);var t=null;try{t=localStorage.getItem("ashrlc:title")}catch(e){}if(t){try{document.title=t}catch(e){}}}}catch(e){}})();`;

export async function generateMetadata(): Promise<Metadata> {
  /* ROUND 185 — the root title speaks the VISITOR's language from the
   * first byte (the ashrlc-lang cookie — same resolution as the public
   * RSC slots). Pre-R185 the default title was static Arabic, so every
   * EN/HI/… visitor's tab read «أشرِيلوجيك — منصة الأعمال الموحّدة»
   * until useDocumentTitle ran post-hydration (seconds on a cold load,
   * forever on routes without the hook) — the reported "titles revert
   * to Arabic" bug. Values below are byte-identical to the AR default
   * for cookie-less visitors (the SSR default). */
  const lang = await resolveLandingLang();
  const brandTitle: Record<"ar" | "en" | "hi", string> = {
    ar: "أشرِيلوجيك — منصة الأعمال الموحّدة",
    en: "ASHRILOGIC — Unified Business Platform",
    hi: "ASHRILOGIC — एकीकृत बिज़नेस प्लेटफ़ॉर्म",
  };
  /* the template brand suffix follows the dictionary language (fr/es/…
   * render through EN — dictLang mirrors t()'s fallback) */
  const dl = dictLang(lang);
  const brandSuffix = dl === "ar" ? "أشرِيلوجيك" : "Ashrilogic";
  return {
  // Task 3-c — env-overridable so preview/staging deployments don't pollute
  // production canonical URLs. Default = the Vercel production URL.
  metadataBase: SITE_URL_OBJ,
  title: {
    default: brandTitle[dl],
    template: `%s · ${brandSuffix}`,
  },
  description:
    "منصة واحدة. أعمال بلا حدود. أشرِيلوجيك توحّد أعمالك في منصة واحدة: 102 نظام إدارة احترافي بدعم متعدد اللغات، معالج إعداد ذكي في 7 خطوات، ولوحة تحكم تنفيذية متكاملة. One platform, limitless business — 102 professional management systems with full multilingual support, a smart 7-step setup wizard and a full executive dashboard.",
  keywords: [
    "Ashrilogic",
    "أشرِيلوجيك",
    "management systems",
    "unified business platform",
    "منصة أعمال موحدة",
    "أنظمة إدارة",
    "ERP",
    "dashboard",
    "Next.js",
    "Prisma",
  ],
  applicationName: "Ashrilogic",
  manifest: "/site.webmanifest",
  appleWebApp: {
    capable: true,
    title: "Ashrilogic",
    statusBarStyle: "black-translucent",
  },
  icons: {
    icon: [
      { url: "/favicon.svg", type: "image/svg+xml" },
      { url: "/favicon-32.png", sizes: "32x32", type: "image/png" },
      { url: "/favicon-16.png", sizes: "16x16", type: "image/png" },
    ],
    shortcut: [{ url: "/favicon-32.png", type: "image/png" }],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
  },
  openGraph: {
    type: "website",
    locale: "ar_SA",
    alternateLocale: ["en_US", "hi_IN"],
    url: SITE_URL,
    siteName: "أشرِيلوجيك · Ashrilogic",
    title: "أشرِيلوجيك — منصة الأعمال الموحّدة",
    description:
      "منصة واحدة. أعمال بلا حدود. أشرِيلوجيك توحّد أعمالك في منصة واحدة: 102 نظام إدارة احترافي بدعم متعدد اللغات، معالج إعداد ذكي في 7 خطوات، ولوحة تحكم تنفيذية متكاملة. One platform, limitless business — 102 professional management systems with full multilingual support and a smart 7-step setup wizard.",
    images: [
      {
        url: "/og.png",
        width: 1200,
        height: 630,
        alt: "أشرِيلوجيك — Ashrilogic: Unified Business Platform",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    site: "@ashrilogic",
    creator: "@ashrilogic",
    title: "أشرِيلوجيك — Ashrilogic: Unified Business Platform",
    description:
      "One platform, limitless business — 102 professional management systems with full multilingual support, a smart 7-step setup wizard, and a premium executive dashboard.",
    images: ["/og.png"],
  },
  authors: [{ name: "Ashrilogic" }],
  creator: "Ashrilogic",
  publisher: "Ashrilogic",
  alternates: {
    canonical: SITE_URL,
    /* hreflang REMOVED — the product does NOT use locale-prefixed routes
     * (e.g. /ar/... /en/...). The locale is client-state-controlled
     * (Zustand + cookie). Declaring hreflang with IDENTICAL URLs for
     * ar/en/hi is a soft violation (Google ignores it or penalizes it).
     * Restore hreflang ONLY when true locale-prefixed routes are implemented.
     * See docs/engineering/TECHNICAL-DEBT.md P2-2. */
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
      "max-video-preview": -1,
    },
  },
  } satisfies Metadata;
}

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f8f8fc" },
    { media: "(prefers-color-scheme: dark)", color: "#05080f" },
  ],
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default async function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  /* Per-request CSP nonce (set by src/middleware.ts) — threaded into
     next-themes so its pre-paint no-flash script passes the nonce-based
     CSP. Reading headers() makes every route render per-request, which is
     also what guarantees the nonce matches the served document. */
  const nonce = (await headers()).get("x-nonce") ?? undefined;

  /* ROUND 177 — cookie-aware critical font preloads: the language the
   * visitor actually reads decides WHICH four faces are above-the-fold
   * critical (same resolution as the public RSC slots — resolveLandingLang
   * reads the ashrlc-lang cookie, default ar).
   * ROUND 185 — dictLang() maps the 8 dictionary-less locales (fr, es, …)
   * onto the EN glyph set: they render through the English dictionary
   * (t()'s fallback), so their critical faces are the LATIN ones — the
   * pre-R185 code preloaded the ARABIC set for them (wasted bandwidth +
   * late-discovered real LCP faces). */
  const preloadLang = await resolveLandingLang();
  const preloadDict = dictLang(preloadLang);
  const preloadFonts =
    preloadDict === "en"
      ? /* EN first paint: Tajawal latin 800 headlines + Cairo latin
         * 400/600/700 body/badges/labels (the sans stack resolves Cairo
         * BEFORE Inter for latin glyphs). */
        [tajawalLatin800Url, cairoLatin400Url, cairoLatin600Url, cairoLatin700Url]
      : preloadDict === "hi"
        ? /* HI first paint: Devanagari body 400/600/700 (the sans stack
           * falls through Cairo/Inter straight to Noto Sans Devanagari)
           * + Tajawal latin 800 for the latin headline run. */
          [devanagari400Url, devanagari600Url, devanagari700Url, tajawalLatin800Url]
        : /* AR default — byte-identical to R170. */
          [tajawalArabic800Url, cairoArabic400Url, cairoArabic600Url, cairoArabic700Url];

  /* ROUND 185 — <html lang/dir> follows the cookie language too: the
   * pre-R185 hardcoded `lang="ar" dir="rtl"` made every EN/HI/FR visitor's
   * FIRST frames lay out right-to-left (Arabic attribution for
   * screen readers) until the LangProvider effect corrected it after
   * hydration. The server already knows the language — render it
   * correctly from byte zero. suppressHydrationWarning stays (the
   * next-themes class mutation on <html> requires it). */
  const htmlLang = preloadLang;
  return (
    <html lang={htmlLang} dir={dirFor(htmlLang)} data-scroll-behavior="smooth" suppressHydrationWarning>
      <head>
        <StructuredData />
        {/* ROUND 170 — critical font preloads (see the import block above).
            crossorigin is REQUIRED: font fetches are CORS-mode, and a
            preload without it double-fetches.
            ROUND 177 — the set is cookie-aware (see preloadLang above). */}
        {preloadFonts.map((href) => (
          <link key={href} rel="preload" as="font" type="font/woff2" crossOrigin="anonymous" href={href} />
        ))}
        {/* ROUND 178 — RSS feed autodiscovery for the public blog (the
            /blog.xml route handler; relative href resolves against the
            actual serving origin, so it is correct on every deployment).
            ROUND 179 — the EN mirror channel (/blog.en.xml) is advertised
            alongside the canonical AR channel so bilingual readers can
            subscribe to their language directly from the reader UI.
            ROUND 180 — the HI mirror channel (/blog.hi.xml) completes the
            set for the site's three fully-translated UI languages. */}
        <link rel="alternate" type="application/rss+xml" title="RSS" href="/blog.xml" />
        <link rel="alternate" type="application/rss+xml" title="RSS (English)" href="/blog.en.xml" />
        <link rel="alternate" type="application/rss+xml" title="RSS (हिन्दी)" href="/blog.hi.xml" />
        {/* ROUND 67 — pre-paint boot gate (see the script source above).
            ROUND 68 — suppressHydrationWarning: browsers strip the nonce
            attribute from the DOM right after first script execution (spec
            behavior), so React 19 would otherwise report a false mismatch
            between the SSR nonce and the post-strip DOM. The script body
            itself is static and identical on both sides. */}
        <script
          nonce={nonce}
          suppressHydrationWarning
          dangerouslySetInnerHTML={{ __html: BOOT_GATE_SCRIPT }}
        />
      </head>
      <body className="min-h-screen bg-background font-sans text-foreground antialiased">
        {/* ROUND 67 — branded boot splash: only painted while the pre-paint
            gate is active (html[data-boot="1"]); pure static markup so it
            server-renders identically and never hydration-mismatches. */}
        <div id="app-boot-splash" aria-hidden="true">
          <span className="grid h-14 w-14 place-items-center rounded-2xl bg-linear-to-br from-brand-500 via-fuchsia-500 to-cyan-400 text-white shadow-lg shadow-brand-500/30">
            <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
              <rect x="3" y="3" width="7" height="9" rx="1.5" />
              <rect x="14" y="3" width="7" height="5" rx="1.5" />
              <rect x="14" y="12" width="7" height="9" rx="1.5" />
              <rect x="3" y="16" width="7" height="5" rx="1.5" />
            </svg>
          </span>
          <span className="font-display text-[19px] font-extrabold tracking-tight text-slate-900 dark:text-white">
            Ashrilogic
          </span>
          <span className="h-1.5 w-40 overflow-hidden rounded-full bg-slate-200 dark:bg-white/10">
            <span className="splash-slide block h-full w-1/2 rounded-full bg-linear-to-l from-brand-600 to-brand-400" />
          </span>
        </div>
        {/* ROUND 87 — the identity bridge rides INSIDE the provider tree
            (it needs the shared QueryClient) after the app content. */}
        <AppProviders nonce={nonce}>
          {children}
          <IdentityBridge />
        </AppProviders>
        <Toaster />
      </body>
    </html>
  );
}
