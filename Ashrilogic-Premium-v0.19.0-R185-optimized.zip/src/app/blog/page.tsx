import type { Metadata } from "next";
import { SITE_URL } from "@/lib/site-url";
import { t } from "@/lib/i18n";
import { BlogPageView } from "@/components/landing/blog/blog-page-view";
import { LandingFooter } from "@/components/landing/landing-footer";
import { SsrLangProvider } from "@/components/ssr-lang-provider";
import { loadBlogFeedPage, normalizeBlogFeedParams } from "@/lib/server/blog-feed";
import { resolveLandingLang } from "@/lib/server/landing-lang";
import { dictLang } from "@/lib/locales";

export async function generateMetadata(): Promise<Metadata> {
  /* ROUND 185 — the SSR title speaks the visitor's language: AR keeps the
   * template form ("المدوّنة · أشرِيلوجيك" — crawler-facing, byte-identical
   * to the pre-R185 default), EN/HI render the localized dictionary title
   * the useDocumentTitle hook re-commits post-hydration — so the tab never
   * shows Arabic to a non-Arabic visitor. */
  const lang = await resolveLandingLang();
  const dl = dictLang(lang);
  const localized: Record<"ar" | "en" | "hi", string> = {
    ar: t("ar", "docTitleBlog"),
    en: t("en", "docTitleBlog"),
    hi: t("hi", "docTitleBlog"),
  };
  return {
    title:
      dl === "ar"
        ? "المدوّنة"
        : /* absolute — the EN/HI dictionary titles carry their own brand
           * suffix ("The Official Blog · Ashrilogic"), bypass the template. */
          { absolute: localized[dl] },
    description:
      "مقالات هندسية وتجارية حول التحول الرقمي والأمان وبناء الأنظمة المتكاملة. Engineering and business essays on digital transformation, security and integrated systems.",
    robots: { index: true, follow: true },
    /* og:url must be the page's own URL — inheriting the root default
       advertised the home URL on this page's share cards. */
    openGraph: { url: `${SITE_URL}/blog` },
    alternates: {
      canonical: `${SITE_URL}/blog`,
    },
  };
}

type PageProps = { searchParams: Promise<{ tag?: string; q?: string }> };

/**
 * /blog — the blog index, SERVER-RENDERED first paint: the route page
 * loads the first feed page (published only, newest first — the exact
 * /api/blog contract via the shared src/lib/server/blog-feed.ts layer)
 * and passes it as initialData into the client view, so the SEO-critical
 * listing is in the first HTML and React Query only re-fetches when the
 * user filters tags / loads more / the data goes stale. The fail-open
 * posture of the API is mirrored here: a DB hiccup renders the empty
 * state, never a broken page.
 */
export default async function BlogPage({ searchParams }: PageProps) {
  /* ?tag= and ?q= (ROUND 175) deep links: the server filters the FIRST page
   * on the requested tag / search text so the link lands on filtered content
   * in the first HTML. */
  const { tag: tagParam, q: qParam } = await searchParams;
  const tag = typeof tagParam === "string" ? tagParam : "";
  const q = typeof qParam === "string" ? qParam : "";
  const { page, pageSize, tag: cleanTag, q: cleanQ } = normalizeBlogFeedParams(1, 9, tag, q);

  let initialFeed: Awaited<ReturnType<typeof loadBlogFeedPage>> | undefined;
  try {
    initialFeed = await loadBlogFeedPage(page, pageSize, cleanTag, cleanQ);
  } catch {
    initialFeed = undefined; /* fail-open — the client view fetches */
  }

  /* ROUND 172c (RSC) — the footer is a SERVER component rendered here and
   * passed into the client view (the same slot, the same markup); the
   * language resolves from the `ashrlc-lang` cookie exactly like the home
   * page, so an EN/HI visitor no longer gets the Arabic SSR default. */
  const lang = await resolveLandingLang();

  return (
    <SsrLangProvider lang={lang}>
      <BlogPageView footer={<LandingFooter lang={lang} />} initialTag={cleanTag} initialQ={cleanQ} initialFeed={initialFeed} />
    </SsrLangProvider>
  );
}
