import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { cache } from "react";
import { SITE_URL } from "@/lib/site-url";
import { safeJsonLd } from "@/lib/safe-json-ld";
import { t } from "@/lib/i18n";
import { BlogPostView } from "@/components/landing/blog/blog-post-view";
import { LandingFooter } from "@/components/landing/landing-footer";
import { SsrLangProvider } from "@/components/ssr-lang-provider";
import { loadBlogArticle, type BlogArticle } from "@/lib/server/blog-feed";
import { resolveLandingLang } from "@/lib/server/landing-lang";
import { dictLang } from "@/lib/locales";

export const dynamic = "force-dynamic";

type PageProps = { params: Promise<{ slug: string }> };

/**
 * /blog/[slug] — a published article, FULLY server-rendered: the route
 * page loads the complete article + related posts (the exact
 * GET /api/blog/[slug] contract via the shared src/lib/server/blog-feed.ts
 * layer) and passes them as initialData into the client view, so the
 * article body is in the first HTML for crawlers and link previews — no
 * hydration wait, no API round-trip before content.
 *
 * SEO 404 CONTRACT (parity with /systems/[id]): a missing or draft slug
 * renders the real not-found page with a hard 404 status — the previous
 * soft-404 (HTTP 200 + client-side not-found branch) is gone.
 *
 * React cache(): generateMetadata and the page body share ONE database
 * read per request (previously the same row was loaded twice for
 * metadata + JSON-LD and a third time through the API route).
 */
const loadArticle = cache(async (slug: string): Promise<BlogArticle | null> => {
  try {
    return await loadBlogArticle(slug);
  } catch {
    return null;
  }
});

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const article = await loadArticle(slug);
  const post = article?.post;
  if (!post) {
    return {
      title: "مقال غير موجود",
      robots: { index: false, follow: false },
    };
  }
  /* Task 6 — single-language title (Arabic preferred, English fallback);
     the root layout's "%s · أشرِيلوجيك" template appends the brand suffix
     so the rendered <title> is "{postTitle} · أشرِيلوجيك" per spec. The
     bilingual coverage is preserved in description + openGraph.title + JSON-LD.
     ROUND 185 — for a non-Arabic visitor the title localizes to the exact
     string the view's useDocumentTitle commits post-hydration
     ("{titleEn} · Ashrilogic") — no Arabic tab, no post-load flip. AR / no
     cookie keeps the crawler-facing template form. */
  const lang = await resolveLandingLang();
  const dl = dictLang(lang);
  const localizedTitle =
    dl === "en" || dl === "hi"
      ? t(dl, "docTitleBlogPostNamed", { title: post.titleEn || post.titleAr || "مقال" })
      : post.titleAr || post.titleEn || "مقال";
  const title = localizedTitle;
  const description = (post.excerptAr || post.excerptEn || "").slice(0, 300);
  return {
    title:
      dl === "ar"
        ? title /* template appends " · أشرِيلوجيك" */
        : { absolute: title },
    description,
    robots: { index: true, follow: true },
    alternates: {
      canonical: `${SITE_URL}/blog/${post.slug}`,
    },
    openGraph: {
      title: post.titleAr && post.titleEn ? `${post.titleAr} · ${post.titleEn}` : title,
      description,
      type: "article",
      publishedTime: post.publishedAt ?? undefined,
      modifiedTime: post.updatedAt ?? undefined,
      /* images DELIBERATELY OMITTED (R183): the per-article dynamic card
       * from opengraph-image.tsx in this segment provides og:image (file
       * convention wins over config). The twitter object below exists for
       * the same reason — a page-level twitter without images makes
       * twitter:image fall back to the dynamic og card instead of the root
       * layout's static /og.png. */
    },
    twitter: {
      card: "summary_large_image",
      title: post.titleAr && post.titleEn ? `${post.titleAr} · ${post.titleEn}` : title,
      description,
    },
  };
}

export default async function BlogPostPage({ params }: PageProps) {
  const { slug } = await params;
  const clean = slug.trim().slice(0, 96).toLowerCase();
  const article = await loadArticle(clean);
  if (!article) notFound(); /* SEO 404 CONTRACT — hard 404, like /systems/[id] */
  const post = article.post;

  /* BlogPosting JSON-LD for rich article results (only for real posts).
   * dateModified uses the row's updatedAt (the last real edit), NOT the
   * publish date — matching the sitemap's lastModified source. */
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    headline: post.titleAr || post.titleEn,
    alternativeHeadline: post.titleEn || post.titleAr,
    description: (post.excerptAr || post.excerptEn || "").slice(0, 300),
    author: { "@type": "Organization", name: post.authorName || "Ashrilogic" },
    publisher: {
      "@type": "Organization",
      name: "Ashrilogic",
      logo: { "@type": "ImageObject", url: `${SITE_URL}/favicon.svg` },
    },
    url: `${SITE_URL}/blog/${post.slug}`,
    datePublished: post.publishedAt ?? undefined,
    dateModified: post.updatedAt ?? undefined,
    inLanguage: ["ar", "en"],
    ...(post.coverImage ? { image: [`${SITE_URL}${post.coverImage}`] } : {}),
  };

  /* ROUND 172c (RSC) — the footer is a SERVER component rendered here and
   * passed into the client view (the same slot, the same markup); the
   * language resolves from the `ashrlc-lang` cookie exactly like the home
   * page, so an EN/HI visitor no longer gets the Arabic SSR default. */
  const lang = await resolveLandingLang();

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: safeJsonLd(jsonLd) }} />
      {/* ROUND 185 — SsrLangProvider seeds the view's useT() islands (share
          row, TOC, related strip) with the cookie language for the
          SSR/hydration passes — no Arabic-first flash for EN/HI visitors. */}
      <SsrLangProvider lang={lang}>
        <BlogPostView
          slug={clean}
          footer={<LandingFooter lang={lang} />}
          initialPost={post}
          initialRelated={article.related}
          initialPrev={article.prev}
          initialNext={article.next}
        />
      </SsrLangProvider>
    </>
  );
}
