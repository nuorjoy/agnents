import { ImageResponse } from "next/og";
import { db } from "@/lib/db";
import {
  OG_BRAND,
  OG_FONT_AR_BODY,
  OG_FONT_EN,
  OG_HEIGHT,
  OG_WIDTH,
  loadOgFonts,
  ogCardShell,
  ogChipRow,
  ogClip,
} from "@/lib/og";

/**
 * R183 — per-article Open-Graph card (1200×630). File-based metadata: the
 * presence of this route file makes Next serve it as /blog/<slug>'s
 * og:image automatically (replacing the inherited static /og.png for
 * articles — WhatsApp/Twitter link previews become per-article branded).
 *
 * ONE lean column-narrowed read (same where-contract as the public blog
 * feed: published + publishedAt set) — not loadBlogArticle, which pulls the
 * full body + related + neighbours for the reader payload an image never
 * needs. Unpublished/unknown slug → the blog brand fallback card (never a
 * 500; the page itself already 404s per the SEO 404 CONTRACT).
 */
export const size = { width: OG_WIDTH, height: OG_HEIGHT };
export const contentType = "image/png";
export const alt = "مقالات أشرِيلوجيك — Ashrilogic Blog";

interface OgPostRow {
  titleAr: string;
  titleEn: string;
  tagsJson: string;
  publishedAt: Date | null;
  /** R184 — card meta line: author + reading time. */
  authorName: string;
  readMinutes: number;
}

async function loadPostForOg(slug: string): Promise<OgPostRow | null> {
  try {
    return await db.blogPost.findFirst({
      where: { slug, status: "published", publishedAt: { not: null } },
      select: {
        titleAr: true,
        titleEn: true,
        tagsJson: true,
        publishedAt: true,
        authorName: true,
        readMinutes: true,
      },
    });
  } catch {
    return null;
  }
}

/** Server-side Arabic date for the chip (best-effort; ISO fallback). */
function ogDateAr(date: Date | null): string | null {
  if (!date) return null;
  try {
    return new Intl.DateTimeFormat("ar", { dateStyle: "long" }).format(date);
  } catch {
    return date.toISOString().slice(0, 10);
  }
}

/** Arabic minute-plural for the reading-time meta (1 دقيقة · 2–10 دقائق ·
 * 11+ دقيقة — satori renders the composed string as-is). */
function ogMinutesAr(n: number): string {
  if (n <= 1) return "دقيقة";
  if (n >= 2 && n <= 10) return "دقائق";
  return "دقيقة";
}

export default async function BlogOgImage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const clean = slug.trim().slice(0, 96).toLowerCase();
  const [post, fonts] = await Promise.all([loadPostForOg(clean), loadOgFonts()]);

  /* unknown/unpublished slug → the blog brand fallback card */
  if (!post) {
    return new ImageResponse(
      ogCardShell(
        ogChipRow([{ text: "المدونة الرسمية" }]),
        [
          <div
            key="title"
            style={{ display: "flex", fontSize: 66, fontWeight: 800 }}
          >
            مدونة أشرِيلوجيك
          </div>,
          <div
            key="sub"
            style={{
              display: "flex",
              fontFamily: OG_FONT_EN,
              fontSize: 33,
              color: OG_BRAND.subtext,
            }}
          >
            The Official Blog — مقالات المنصة والتحديثات
          </div>,
        ],
      ),
      { ...size, fonts },
    );
  }

  let tags: string[] = [];
  try {
    const parsed = JSON.parse(post.tagsJson);
    if (Array.isArray(parsed)) tags = parsed.filter((t) => typeof t === "string").slice(0, 2);
  } catch {
    /* malformed tagsJson — the card simply carries no tag chips */
  }
  const dateAr = ogDateAr(post.publishedAt);
  /* R184 — author + reading-time meta line under the titles (defaults
   * readMinutes=3 / authorName="Ashrilogic" per the schema — always
   * presentable, never fabricated). */
  const metaAr = `${post.authorName || "Ashrilogic"} · قراءة ${Math.max(1, post.readMinutes)} ${ogMinutesAr(post.readMinutes)}`;

  return new ImageResponse(
    ogCardShell(
      ogChipRow([
        { text: "المدونة الرسمية" },
        ...(dateAr ? [{ text: dateAr }] : []),
        ...(tags.length > 0 ? [{ text: `#${tags[0]}` }] : []),
      ]),
      [
        <div
          key="titleAr"
          style={{
            display: "flex",
            fontSize: post.titleAr.length > 34 ? 52 : post.titleAr.length > 22 ? 62 : 74,
            fontWeight: 800,
            lineHeight: 1.2,
            maxWidth: 960,
          }}
        >
          {ogClip(post.titleAr, 64)}
        </div>,
        <div
          key="titleEn"
          style={{
            display: "flex",
            fontFamily: OG_FONT_EN,
            fontSize: 32,
            lineHeight: 1.3,
            color: "#a5a0e8",
            marginTop: 14,
            maxWidth: 960,
          }}
        >
          {ogClip(post.titleEn, 72)}
        </div>,
        <div
          key="meta"
          style={{
            display: "flex",
            fontFamily: OG_FONT_AR_BODY,
            fontSize: 24,
            color: OG_BRAND.subtext,
            marginTop: 20,
          }}
        >
          {ogClip(metaAr, 80)}
        </div>,
      ],
    ),
    { ...size, fonts },
  );
}
