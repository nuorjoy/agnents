import type { MetadataRoute } from "next";
import { SITE_URL } from "@/lib/site-url";

/**
 * Ashrilogic — static robots.txt (ROUND 172 hardening of the Task 3-d fix).
 *
 * Indexing posture (unchanged):
 *  - ALLOW the public marketing surface (landing, blog, compare, privacy,
 *    terms, the 102 system detail pages, and the published tenant websites
 *    + storefronts).
 *  - DISALLOW every sensitive route: the Super-Admin console (/admin/**)
 *    is NEAR-HIDDEN — never indexed, never followed, never linked from any
 *    public page, and never listed in the sitemap. The owner-login (/login),
 *    all API routes (/api/**) and every customer-account portal
 *    (/sites/* /account/**) follow the same posture.
 *
 * ROUND 172 (PageSpeed fix): this generator is now SYNCHRONOUS and
 * DB-FREE, so Next.js prerenders /robots.txt at BUILD time and Vercel
 * serves it as a static asset from the CDN edge. The previous dynamic
 * generator resolved the sitemap shard plan from the DATABASE on every
 * request — a cold serverless wake (~3.5s measured) that made Lighthouse/
 * PageSpeed robots.txt probes time out ("Timed out fetching resource"),
 * dinging the SEO score. robots.txt no longer needs the shard list: it
 * points at the SITEMAP INDEX (/sitemap.xml — src/app/sitemap.xml/route.ts),
 * which lists every shard that exists and is itself CDN-cached
 * (s-maxage=600). One static file + one cached index — zero cold starts on
 * the crawler path, and the shard coverage stays a single source of truth
 * inside the index route (src/app/sitemap-index.xml/route.ts — ROUND 173
 * doc fix: the previous text pointed at a nonexistent src/app/sitemap.xml/
 * route directory; the index handler actually lives at /sitemap-index.xml
 * and next.config.ts rewrites /sitemap.xml onto it).
 */
export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        // The default block — applies to every crawler not listed below.
        userAgent: "*",
        allow: [
          "/",
          "/blog",
          "/blog/",
          "/compare",
          "/privacy",
          "/terms",
          "/sitemap.xml",
          "/sitemap",
          "/sitemap/",
        ],
        // Sensitive routes — never index, never follow (defense-in-depth; the
        // page-level metadata also emits robots:noindex on every entry).
        disallow: [
          "/admin",
          "/admin/",
          "/admin/*",
          "/admin/login",
          "/login",
          "/api/",
          "/api/*",
          "/sites/*/account",
          "/sites/*/account/",
          "/sites/*/account/*",
          "/sites/*/receipt",
          "/sites/*/receipt/*",
        ],
      },
      {
        // Google — same posture as the default block, with explicit
        // googleBot directives for snippet/image richness on ALLOWED pages.
        userAgent: "Googlebot",
        allow: [
          "/",
          "/blog",
          "/blog/",
          "/compare",
          "/privacy",
          "/terms",
        ],
        disallow: [
          "/admin",
          "/admin/",
          "/admin/*",
          "/admin/login",
          "/login",
          "/api/",
          "/api/*",
          "/sites/*/account",
          "/sites/*/account/",
          "/sites/*/account/*",
          "/sites/*/receipt",
          "/sites/*/receipt/*",
        ],
      },
      {
        // Social scrapers — they must still render the OG cards for shared
        // links, so the ALLOW list mirrors the public marketing surface but
        // SENSITIVE routes remain disallowed so a leaked tweet can never
        // preview the admin panel or a customer-account URL.
        userAgent: ["Twitterbot", "facebookexternalhit", "LinkedInBot", "Slackbot", "WhatsApp"],
        allow: ["/", "/blog", "/blog/", "/compare", "/privacy", "/terms"],
        disallow: [
          "/admin",
          "/admin/",
          "/admin/*",
          "/login",
          "/api/",
          "/api/*",
          "/sites/*/account",
          "/sites/*/account/",
          "/sites/*/account/*",
          /* ROUND 173 — receipt parity: the `*`/Googlebot groups already
           * disallow the tokenized receipt URLs; the social group was the
           * only one missing them (a leaked share could have previewed a
           * receipt URL — the MAC token still gates the page itself, this
           * closes the posture asymmetry). */
          "/sites/*/receipt",
          "/sites/*/receipt/*",
        ],
      },
    ],
    sitemap: `${SITE_URL}/sitemap.xml`,
    host: SITE_URL,
  };
}
