import type { Metadata } from "next";
import { LoginPageView } from "@/components/auth/login-page-view";
import { resolveLandingLang } from "@/lib/server/landing-lang";
import { dictLang } from "@/lib/locales";
import { t } from "@/lib/i18n";
import { SsrLangProvider } from "@/components/ssr-lang-provider";

/* ROUND 185 — docTitleLogin lives in the SITE domain (app fragment); the
 * fragment import registers it server-side so generateMetadata can
 * resolve the same localized title the client hook commits. */
import "@/lib/i18n/fragments/app";

/**
 * Ashrilogic — /login route (round 23).
 *
 * Deep-linkable, dedicated sign-in page: the landing topbar "تسجيل الدخول"
 * button navigates here. The page resolves the workspace by the admin email,
 * drops the HTTP-only workspace cookie and hands off to the dashboard (single
 * workspace) or the system-select screen (multiple workspaces).
 *
 * Auth pages are transactional — kept out of the index but followed so
 * internal links remain discoverable.
 *
 * ROUND 185 — the tab title follows the visitor's language from the FIRST
 * server byte (generateMetadata + the ashrlc-lang cookie) and the client
 * view is wrapped in SsrLangProvider so its useT() islands SSR-render in
 * the visitor's language (no Arabic-first flash, no Arabic title).
 */
export async function generateMetadata(): Promise<Metadata> {
  const lang = await resolveLandingLang();
  /* absolute (suffix included) — byte-identical to what useDocumentTitle
   * commits post-hydration, so the title never flips. */
  const title: Record<"ar" | "en" | "hi", string> = {
    ar: t("ar", "docTitleLogin"),
    en: t("en", "docTitleLogin"),
    hi: t("hi", "docTitleLogin"),
  };
  return {
    title: { absolute: title[dictLang(lang)] },
    description:
      "سجّل دخولك للوصول إلى مساحة عملك في أشرِيلوجيك — ١٠٢ نظام إداري احترافي مع لوحة تحكم تنفيذية كاملة. Sign in to your Ashrilogic workspace.",
    // Auth pages are transactional — kept OUT of the index but followed so
    // internal links (the landing CTA, the forgot-password flow) remain
    // discoverable and PageRank flows back to the marketing surface.
    robots: { index: false, follow: true },
    alternates: { canonical: "/login" },
    openGraph: {
      title: "تسجيل الدخول · أشرِيلوجيك",
      description:
        "سجّل دخولك للوصول إلى مساحة عملك في أشرِيلوجيك — ١٠٢ نظام إداري احترافي مع لوحة تحكم تنفيذية كاملة.",
      url: "/login",
      type: "website",
      siteName: "أشرِيلوجيك · Ashrilogic",
      images: [{ url: "/og.png", width: 1200, height: 630, alt: "أشرِيلوجيك — تسجيل الدخول" }],
    },
    twitter: {
      card: "summary_large_image",
      title: "تسجيل الدخول · أشرِيلوجيك",
      description:
        "Sign in to your Ashrilogic workspace — one platform, limitless business.",
      images: ["/og.png"],
    },
  };
}

export default async function LoginPage() {
  const lang = await resolveLandingLang();
  return (
    <SsrLangProvider lang={lang}>
      <LoginPageView />
    </SsrLangProvider>
  );
}
