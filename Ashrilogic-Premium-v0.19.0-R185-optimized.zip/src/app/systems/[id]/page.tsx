import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { SITE_URL } from "@/lib/site-url";
import { SYSTEMS, SYSTEM_MAP, CATEGORY_MAP } from "@/data/catalog";
import { safeJsonLd } from "@/lib/safe-json-ld";
import { t } from "@/lib/i18n";
import { LandingFooter } from "@/components/landing/landing-footer";
import { SsrLangProvider } from "@/components/ssr-lang-provider";
import { resolveLandingLang } from "@/lib/server/landing-lang";
import { dictLang } from "@/lib/locales";

/**
 * Ashrilogic — static params for /systems/[id].
 *
 * Pre-generates all 102 system pages at build time so they're fully static,
 * SEO-indexable, and deep-linkable. Each page gets its own <title>, OG
 * metadata, and a per-system JSON-LD SoftwareApplication schema.
 *
 * SEO 404 CONTRACT: an unknown system id triggers a REAL 404 (notFound())
 * instead of the historical 200 + client-side "النظام غير موجود" view. The
 * open-ended URL space previously served indexable thin-content pages on
 * every junk id — a soft-404 crawl-budget drain and a link-farm vector.
 */
export function generateStaticParams() {
  return SYSTEMS.map((s) => ({ id: s.id }));
}

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
  const { id } = await params;
  const sys = SYSTEM_MAP[id];
  if (!sys) {
    /* notFound() inside generateMetadata renders the true 404 page (with
     * its noindex metadata) — never a 200 "not found" shell. */
    notFound();
  }
  const cat = CATEGORY_MAP[sys.c];
  /* bilingual description: the Arabic name + English name both rank for
     Arabic and English queries respectively */
  const description = `${sys.descAr} — ${sys.descEn}`;
  /* ROUND 185 — visitor-language tab title from the first byte: AR keeps
   * the template form ("{nameAr} · أشرِيلوجيك" — the crawler-facing
   * default, byte-identical to pre-R185); EN/HI render the localized
   * dictionary title the system view's useDocumentTitle commits
   * post-hydration ("{nameEn} · Ashrilogic Systems") — no Arabic title,
   * no post-hydration flip. */
  const lang = await resolveLandingLang();
  const dl = dictLang(lang);
  const localizedTitle =
    dl === "ar"
      ? (sys.nameAr || sys.nameEn)
      : t(dl, "docTitleSystemDetail", { name: sys.nameEn || sys.nameAr });
  return {
    title:
      dl === "ar"
        ? localizedTitle /* template appends " · أشرِيلوجيك" */
        : { absolute: localizedTitle },
    description,
    keywords: [sys.nameEn, sys.nameAr, cat?.nameEn, cat?.nameAr, "management system", "Ashrilogic"],
    alternates: {
      canonical: `${SITE_URL}/systems/${sys.id}`,
      /* hreflang REMOVED — same-URL alternates are a soft violation (the
       * product has no locale-prefixed routes; the locale is client state).
       * See the root layout's P2-2 policy note. */
    },
    openGraph: {
      title: `${sys.nameAr} · ${sys.nameEn}`,
      siteName: "أشرِيلوجيك · Ashrilogic",
      description,
      url: `${SITE_URL}/systems/${sys.id}`,
      type: "website",
      /* images DELIBERATELY OMITTED (R183): the per-system dynamic card
       * from opengraph-image.tsx in this segment provides og:image AND
       * twitter:card imagery (file-based metadata wins over config —
       * keeping an explicit images array here would override it back to the
       * static brand card). The alt text for the dynamic card is the route
       * file's `alt` export. */
    },
    /* twitter images inherit from openGraph when omitted — same dynamic
     * card, one source of truth (R183). */
    twitter: {
      card: "summary_large_image",
      title: `${sys.nameAr} · ${sys.nameEn}`,
      description,
    },
    robots: { index: true, follow: true },
  };
}

/** Per-system JSON-LD SoftwareApplication schema for rich search results. */
function systemJsonLd(id: string) {
  const sys = SYSTEM_MAP[id];
  if (!sys) return null;
  const cat = CATEGORY_MAP[sys.c];
  return {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    name: sys.nameEn,
    alternateName: sys.nameAr,
    applicationCategory: "BusinessApplication",
    operatingSystem: "Web",
    url: `${SITE_URL}/systems/${sys.id}`,
    description: `${sys.descEn} — ${sys.descAr}`,
    category: cat?.nameEn,
    /* offers REMOVED — pricing must come from the canonical source (the
       * admin-editable Package rows served by /api/packages). A hardcoded
       * "$9.99" in build-time JSON-LD diverges the moment an admin changes
       * the Starter tier. Same policy the platform-level JSON-LD block
       * already applies (src/components/structured-data.tsx P2-1 note). */
    /* aggregateRating REMOVED — no real review data source exists for
       * system pages (the only review model is per-product SiteReview in
       * storefronts). A fabricated static 4.9/128 on all 102 pages is
       * fabricated-review schema spam Google penalizes. Restore ONLY when
       * a real per-system review aggregation exists. */
    publisher: {
      "@type": "Organization",
      name: "Ashrilogic",
      url: `${SITE_URL}`,
    },
  };
}

/** R182 — BreadcrumbList JSON-LD. The visible trail is a single back-link
 *  (nav chrome); rich results deserve the full four-level path: Home →
 *  systems library → category filter → this system. Names are AR-primary —
 *  the page's canonical rendering and its own <title> lead Arabic — with
 *  the EN form as alternateName on every crumb (the same bilingual pattern
 *  the SoftwareApplication block above applies). The category crumb URL is
 *  the REAL shareable ?cat= catalog state (R176 URL contract, SSR-filtered
 *  server-side) — not a decorative anchor. A system without a category
 *  collapses to a three-crumb trail (positions stay contiguous). */
function systemBreadcrumbLd(id: string) {
  const sys = SYSTEM_MAP[id];
  if (!sys) return null;
  const cat = CATEGORY_MAP[sys.c];
  const crumb = (position: number, name: string, alternateName: string, url: string) => ({
    "@type": "ListItem",
    position,
    name,
    alternateName,
    item: url,
  });
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      crumb(1, "أشرِيلوجيك", "Ashrilogic", `${SITE_URL}`),
      crumb(2, "الأنظمة", "Systems", `${SITE_URL}/#systems`),
      ...(cat ? [crumb(3, cat.nameAr, cat.nameEn, `${SITE_URL}/?cat=${cat.id}`)] : []),
      crumb(cat ? 4 : 3, sys.nameAr, sys.nameEn, `${SITE_URL}/systems/${sys.id}`),
    ],
  };
}

export default async function SystemPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const lang = await resolveLandingLang();
  /* Unknown ids never render the 200 shell — true 404 (SEO 404 CONTRACT). */
  if (!SYSTEM_MAP[id]) notFound();
  const { SystemDetailView } = await import("@/components/landing/system-detail-view");
  const jsonLd = systemJsonLd(id);
  const breadcrumbLd = systemBreadcrumbLd(id);
  return (
    <>
      {breadcrumbLd ? (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: safeJsonLd(breadcrumbLd) }}
        />
      ) : null}
      {jsonLd ? (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: safeJsonLd(jsonLd) }}
        />
      ) : null}
      {/* ROUND 172c (RSC) — the footer is a SERVER component now: the route
          page renders it and passes the element into the client view (the
          same slot, the same markup). ROUND 173: the language resolves from
          the `ashrlc-lang` cookie exactly like the home page, so an EN/HI
          visitor no longer gets the Arabic SSR default.
          ROUND 185 — SsrLangProvider seeds the view's useT() islands with
          the cookie language for the SSR/hydration passes (no Arabic-first
          flash on the interactive header/spec sheets). */}
      <SsrLangProvider lang={lang}>
        <SystemDetailView systemId={id} footer={<LandingFooter lang={lang} />} />
      </SsrLangProvider>
    </>
  );
}
