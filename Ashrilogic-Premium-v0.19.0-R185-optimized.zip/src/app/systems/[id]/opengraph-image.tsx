import { ImageResponse } from "next/og";
import { CATEGORY_MAP, SYSTEM_MAP, systemMods } from "@/data/catalog";
import {
  OG_BRAND,
  OG_FONT_AR_BODY,
  OG_FONT_EN,
  OG_HEIGHT,
  OG_WIDTH,
  loadOgFonts,
  ogCardShell,
  ogChipRow,
  ogClip,
} from "@/lib/og";

/**
 * R183 — per-system Open-Graph card (1200×630). File-based metadata: the
 * presence of this route file makes Next serve it as /systems/<id>'s
 * og:image automatically (the root layout's static /og.png stays the
 * default for every other route). Data comes from the STATIC catalog —
 * zero DB, zero request reads; unknown ids render the brand fallback card
 * (the page itself 404s, and a crawler fetching the image URL of a dead
 * link deserves an image, not a 500).
 *
 * Layout contract (satori): inline styles only, every multi-child node is
 * a flex container, no flex-wrap (chips are pre-truncated to 3), pure-JS
 * line truncation for any localized title length.
 */
export const size = { width: OG_WIDTH, height: OG_HEIGHT };
export const contentType = "image/png";
export const alt = "أشرِيلوجيك — Ashrilogic Systems";

export default async function SystemOgImage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const system = SYSTEM_MAP[id];
  const fonts = await loadOgFonts();

  /* unknown id → the brand fallback card (never a 500) */
  if (!system) {
    return new ImageResponse(
      ogCardShell(
        ogChipRow([{ text: "منصة الأعمال الموحّدة" }]),
        [
          <div
            key="title"
            style={{ display: "flex", fontSize: 72, fontWeight: 800 }}
          >
            أشرِيلوجيك
          </div>,
          <div
            key="sub"
            style={{
              display: "flex",
              fontFamily: OG_FONT_EN,
              fontSize: 34,
              color: OG_BRAND.subtext,
            }}
          >
            102 professional management systems · إعداد ذكي في 7 خطوات
          </div>,
        ],
      ),
      { ...size, fonts },
    );
  }

  const category = CATEGORY_MAP[system.c];
  const moduleCount = systemMods(system).length;

  return new ImageResponse(
    ogCardShell(
      ogChipRow([
        { text: `${category?.nameAr ?? "أنظمة"} · ${moduleCount} وحدة` },
        { text: `SYS-${String(system.code).padStart(3, "0")}`, fontFamily: OG_FONT_EN },
      ]),
      [
        <div
          key="nameAr"
          style={{
            display: "flex",
            fontSize: system.nameAr.length > 34 ? 54 : system.nameAr.length > 24 ? 64 : 76,
            fontWeight: 800,
            lineHeight: 1.18,
            maxWidth: 940,
          }}
        >
          {ogClip(system.nameAr, 48)}
        </div>,
        <div
          key="nameEn"
          style={{
            display: "flex",
            fontFamily: OG_FONT_EN,
            fontSize: 33,
            lineHeight: 1.25,
            color: "#a5a0e8",
            marginTop: 14,
            maxWidth: 940,
          }}
        >
          {ogClip(system.nameEn, 64)}
        </div>,
        <div
          key="descAr"
          style={{
            display: "flex",
            fontFamily: OG_FONT_AR_BODY,
            fontSize: 25,
            lineHeight: 1.55,
            color: OG_BRAND.subtext,
            marginTop: 26,
            maxWidth: 900,
          }}
        >
          {ogClip(system.descAr, 150)}
        </div>,
      ],
      {
        accentFrom: category?.c1 ?? OG_BRAND.violetFrom,
        accentTo: category?.c2 ?? OG_BRAND.violetTo,
      },
    ),
    { ...size, fonts },
  );
}
