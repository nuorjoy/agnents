import { buildBlogFeed, renderEmptyFeedXml, feedHeaders } from "@/lib/server/rss";

/**
 * Ashrilogic — RSS 2.0 HINDI mirror of the public blog feed
 * (ROUND 180 — R179 recommendation c).
 *
 * Route: GET /blog.hi.xml — a separate STATIC route (same contract as the
 * ROUND 179 EN mirror) so all three channels keep identical pure-ISR cache
 * semantics: no request read, `revalidate = 3600`, per-URL CDN caching,
 * and feed readers get the distinct standard URL they prefer.
 *
 * Honest content policy (documented in src/lib/server/rss.ts): BlogPost
 * carries no Hindi title/excerpt fields yet, so the CHANNEL metadata is
 * Hindi (title/description/language) while ITEMS prefer the English field
 * with graceful fallback to Arabic — the same valid-item-beats-missing
 * posture as the EN mirror. When Hindi content fields ship, the pick()
 * in the shared builder is the single place to extend.
 *
 * Discovery: the root layout emits all three alternate links on every page
 * (/blog.xml AR canonical · /blog.en.xml EN · /blog.hi.xml HI).
 */
export const revalidate = 3600;

export async function GET() {
  try {
    const xml = await buildBlogFeed("hi");
    return new Response(xml, { status: 200, headers: feedHeaders() });
  } catch (error) {
    console.error("GET /blog.hi.xml failed:", error);
    /* Fail-open with a VALID empty channel (same posture as the other feeds). */
    return new Response(renderEmptyFeedXml("hi"), {
      status: 200,
      headers: {
        "Content-Type": "application/rss+xml; charset=utf-8",
        "Cache-Control": "public, max-age=0, s-maxage=60, stale-while-revalidate=600",
      },
    });
  }
}
