import { LandingPage } from "@/components/landing/landing-page";
import { ViewRoot } from "@/components/landing/view-root";
import { resolveLandingLang } from "@/lib/server/landing-lang";
import { CATEGORIES } from "@/data/catalog";

/**
 * Ashrilogic — single-route application shell (ROUND 172c: SERVER page).
 *
 * View switching (landing / wizard / transition / system-select / dashboard)
 * stays client-driven through the persisted Zustand store — the ViewRoot
 * ISLAND (src/components/landing/view-root.tsx) receives the ENTIRE landing
 * as a server-rendered RSC tree (children) and hides it while a non-landing
 * view is active. The admin panel lives at its own deep-linkable route
 * `/admin` (`/admin/login`) and is not part of the in-app view switcher.
 * The global command palette (⌘K / ⌘J) arms on first interaction inside
 * ViewRoot.
 *
 * ROUND 42 — performance: the executive dashboard, the setup wizard, the
 * system-select screen, the transition screen and the command palette are
 * split into lazy chunks. A first-time visitor downloads ONLY the landing
 * experience; the (much heavier) product chunks stream in on demand and
 * are prefetched in the background after first paint, so switching views
 * stays instant. SSR is disabled for these client-state-driven surfaces
 * (they render exclusively after the store decides a view is active).
 *
 * ROUND 172c — performance: the landing shell is server-rendered through
 * and through (hero / tech strip / partners / features / footer carry ZERO
 * hydration; only the interactive islands hydrate). The visitor's language
 * resolves from the `ashrlc-lang` COOKIE — the language menu writes it on
 * every switch and calls router.refresh(), so the server text re-renders
 * in the new language without a full reload (the client islands follow via
 * the store). Visitors without a cookie get the Arabic-first default,
 * byte-identical to the previous SSR output.
 *
 * ROUND 176 — ?cat= deep links: the systems library filter is shareable.
 * The server validates the requested category against the catalog (real
 * ids + the "all" pseudo-category; "favorites" is deliberately NOT
 * deep-linkable — it is device-local state, a shared link would land on an
 * empty grid for everyone else) and hands it to the islands as initialCat,
 * which the client seeds into the landing UI store right after hydration.
 */

/** Valid deep-linkable category ids ("all" + the 16 real sector ids). */
const DEEP_LINK_CATS = new Set<string>(["all", ...CATEGORIES.map((c) => c.id)]);

function validateCatParam(raw: string): string {
  const clean = raw.trim().toLowerCase().slice(0, 48);
  return DEEP_LINK_CATS.has(clean) ? clean : "all";
}

type HomeProps = { searchParams: Promise<{ cat?: string }> };

export default async function Home({ searchParams }: HomeProps) {
  const lang = await resolveLandingLang();
  const { cat } = await searchParams;
  const initialCat = validateCatParam(typeof cat === "string" ? cat : "");

  return (
    <ViewRoot lang={lang}>
      <LandingPage lang={lang} initialCat={initialCat} />
    </ViewRoot>
  );
}
