import type { Metadata } from "next";
import { cache } from "react";
import { SITE_URL } from "@/lib/site-url";
import { readPlatformLegalDoc } from "@/lib/server/legal-docs";
import { resolveLandingLang } from "@/lib/server/landing-lang";
import { dictLang } from "@/lib/locales";
import { PlatformLegalView } from "@/components/legal/platform-legal-view";
import { SsrLangProvider } from "@/components/ssr-lang-provider";

import "@/lib/i18n/fragments/app";
/**
 * Ashrilogic — ROUND 117 — the PLATFORM terms of use (/terms).
 *
 * Server-rendered (force-dynamic) so a console publish is live on the
 * next request: the page reads the LegalDoc rows for every locale (the
 * console-edited row when one exists, the code-carried default
 * otherwise) and hands ALL variants to the language-aware view (the
 * visitor's language picks client-side; hi falls back en → ar — the
 * same chain the server uses).
 *
 * ROUND 185 — visitor-language tab title from the first server byte
 * (generateMetadata + the localized doc title, React-cache shared with
 * the page body) and SsrLangProvider around the view (no Arabic-first
 * flash). See /privacy for the full note.
 */

export const dynamic = "force-dynamic";

const CANONICAL = `${SITE_URL}/terms`;

/* React cache(): generateMetadata + the page body share ONE read per
 * locale per request (the R183 blog-article contract). */
const readTermsDoc = cache((langCode: "ar" | "en" | "hi") => readPlatformLegalDoc("terms", langCode));

export async function generateMetadata(): Promise<Metadata> {
  const lang = await resolveLandingLang();
  const dl = dictLang(lang);
  const doc = await readTermsDoc(dl);
  const title = `${doc.title} · ${dl === "ar" ? "أشرِيلوجيك" : "Ashrilogic"}`;
  return {
    title: { absolute: title },
    description:
      "شروط استخدام منصة أشرِيلوجيك — القواعد المنظِّمة لاستخدام المنصة وخدماتها واشتراكاتها. Ashrilogic terms of use.",
    alternates: { canonical: CANONICAL },
    openGraph: {
      title: "الشروط والأحكام · أشرِيلوجيك",
      description: "القواعد المنظِّمة لاستخدام المنصة وخدماتها واشتراكاتها.",
      url: CANONICAL,
      type: "website",
      siteName: "أشرِيلوجيك · Ashrilogic",
      images: [{ url: "/og.png", width: 1200, height: 630, alt: "Ashrilogic terms of use" }],
    },
    robots: { index: true, follow: true },
  };
}

export default async function TermsPage() {
  const [ar, en, hi] = await Promise.all([
    readTermsDoc("ar"),
    readTermsDoc("en"),
    readTermsDoc("hi"),
  ]);
  const lang = await resolveLandingLang();

  return (
    <SsrLangProvider lang={lang}>
      <PlatformLegalView
        kind="terms"
        docs={{
          ar: { key: "terms", title: ar.title, intro: ar.intro, sections: ar.sections, updatedAt: ar.updatedAt, version: ar.version, customized: ar.customized },
          en: { key: "terms", title: en.title, intro: en.intro, sections: en.sections, updatedAt: en.updatedAt, version: en.version, customized: en.customized },
          hi: { key: "terms", title: hi.title, intro: hi.intro, sections: hi.sections, updatedAt: hi.updatedAt, version: hi.version, customized: hi.customized },
        }}
      />
    </SsrLangProvider>
  );
}
