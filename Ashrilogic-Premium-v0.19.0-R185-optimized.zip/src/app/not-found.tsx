import { NotFoundView } from "@/components/error-pages/not-found-view";

/**
 * Ashrilogic — 404 page.
 *
 * Next.js renders this server component automatically when no route matches
 * (or when `notFound()` is thrown from a Server Component). The actual UI
 * lives in the client `NotFoundView` because the page needs `useT()` / the
 * app store, both of which are client-only.
 */
export default function NotFound() {
  return <NotFoundView />;
}
