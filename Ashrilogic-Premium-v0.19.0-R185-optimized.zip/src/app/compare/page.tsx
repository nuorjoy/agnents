import type { Metadata } from "next";
import { SITE_URL } from "@/lib/site-url";
import { t } from "@/lib/i18n";
import { safeJsonLd } from "@/lib/safe-json-ld";
import { db } from "@/lib/db";
import { ComparePageView } from "@/components/landing/compare-page-view";
import { LandingFooter } from "@/components/landing/landing-footer";
import { SsrLangProvider } from "@/components/ssr-lang-provider";
import { resolveLandingLang } from "@/lib/server/landing-lang";
import { dictLang } from "@/lib/locales";

export async function generateMetadata(): Promise<Metadata> {
  /* ROUND 185 — visitor-language title. /compare has NO client title
   * hook (its useDocumentTitle was never wired), so the SSR metadata is
   * the tab's PERMANENT title — pre-R185 that meant a permanent Arabic
   * title for every EN/HI visitor. AR keeps the template form
   * ("مقارنة الباقات · أشرِيلوجيك", byte-identical default); EN/HI render
   * the localized dictionary title. */
  const lang = await resolveLandingLang();
  const dl = dictLang(lang);
  const localized: Record<"ar" | "en" | "hi", string> = {
    ar: t("ar", "docTitleCompare"),
    en: t("en", "docTitleCompare"),
    hi: t("hi", "docTitleCompare"),
  };
  return {
    title: dl === "ar" ? "مقارنة الباقات" : { absolute: localized[dl] },
    description:
      "قارن بين خطط Ashrilogic بمنتهى الشفافية: الأسعار الفعلية، الحدود، القدرات والأمان — مصفوفة حية من لوحة التحكم. Compare Ashrilogic plans side by side: live pricing, limits, capabilities and security.",
    robots: { index: true, follow: true },
    /* og:url must be the page's own URL — inheriting the root default
       advertised the home URL on this page's share cards. */
    openGraph: { url: `${SITE_URL}/compare` },
    alternates: {
      canonical: `${SITE_URL}/compare`,
    },
  };
}

/** The minimal projection the ItemList JSON-LD needs. */
interface PlanJsonLdRow {
  nameAr: string;
  nameEn: string;
  descAr: string;
  descEn: string;
  priceMonthly: number;
  currency: string;
  customPricing: boolean;
}

/**
 * R183 — the plans for the ItemList JSON-LD, read with a MINIMAL direct
 * Prisma query (column-narrowed select, same where/orderBy as the public
 * packages repository — service.listActive's contract minus the seeding
 * side-effects and DTO machinery). DELIBERATELY not imported from
 * src/server/domains/packages: pulling that module graph (repository +
 * admin-mapper + audit + seed chain) into the page's Turbopack compile
 * OOM-killed the 4GB sandbox dev server during the first compile attempt
 * of this round — the db client is ALREADY in the page's module graph
 * (LandingFooter reads platform settings through it), so this shape adds
 * near-zero compile weight. Fail-open like every other public JSON-LD
 * emitter (partners strip, blog feed): no rows → no ItemList, never a 500.
 */
async function loadPlansForJsonLd(): Promise<PlanJsonLdRow[]> {
  try {
    return await db.package.findMany({
      where: { active: true },
      orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }, { id: "asc" }],
      take: 12,
      select: {
        nameAr: true,
        nameEn: true,
        descAr: true,
        descEn: true,
        priceMonthly: true,
        currency: true,
        customPricing: true,
      },
    });
  } catch {
    return [];
  }
}

export default async function ComparePage() {
  /* ROUND 172c (RSC) — the footer is a SERVER component now: the route
   * page renders it and passes the element into the client view (the same
   * slot, the same markup). ROUND 173: the language resolves from the
   * `ashrlc-lang` cookie exactly like the home page, so an EN/HI visitor
   * no longer gets the Arabic SSR default. */
  const lang = await resolveLandingLang();

  /* R183 — ItemList JSON-LD (R182 rec c): the comparison page is a
   * product-catalog entry point for crawlers. Each active plan is a
   * Product with the live monthly offer (skip offers entirely for
   * custom-pricing plans — no purchasable amount, matching the on-page
   * chip). AR-primary names + EN alternateName mirrors the systems
   * breadcrumb convention; prices are the schema's integer MINOR units
   * ÷ 100 (the ROUND 166 money.ts contract). Same live-DB source the
   * rendered matrix loads, so the structured data cannot drift from what
   * the visitor sees. */
  const plans = await loadPlansForJsonLd();
  const itemListLd =
    plans.length > 0
      ? {
          "@context": "https://schema.org",
          "@type": "ItemList",
          name: "باقات Ashrilogic",
          description:
            "قارن بين خطط Ashrilogic: الأسعار الفعلية، الحدود والقدرات. Compare Ashrilogic plans side by side.",
          itemListElement: plans.map((plan, index) => ({
            "@type": "ListItem",
            position: index + 1,
            item: {
              "@type": "Product",
              name: plan.nameAr,
              alternateName: plan.nameEn,
              description: plan.descAr || plan.descEn || undefined,
              brand: { "@type": "Brand", name: "Ashrilogic" },
              ...(plan.customPricing || plan.priceMonthly <= 0
                ? {}
                : {
                    offers: {
                      "@type": "Offer",
                      price: plan.priceMonthly / 100,
                      priceCurrency: plan.currency,
                      availability: "https://schema.org/InStock",
                      url: `${SITE_URL}/compare`,
                    },
                  }),
            },
          })),
        }
      : null;

  return (
    <>
      {itemListLd && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: safeJsonLd(itemListLd) }}
        />
      )}
      <SsrLangProvider lang={lang}>
        <ComparePageView footer={<LandingFooter lang={lang} />} />
      </SsrLangProvider>
    </>
  );
}
