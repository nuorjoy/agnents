import { NextResponse } from "next/server";
import { loadSectorPartners } from "@/lib/server/partners-feed";

export const dynamic = "force-dynamic";

/**
 * GET /api/partners — the curated TRUSTED-SECTOR marquee feed (public).
 *
 * Every row maps to a REAL registered workspace: the join back to Instance
 * guarantees authenticity AND freshness — a trashed (soft-deleted) workspace
 * silently drops out of the showcase, and the display name falls back to the
 * LIVE org name whenever the console override is empty.
 *
 * ROUND 164 — the «قيادات القطاعية تختار Ashrilogic» law (owner directive):
 *  - DYNAMIC: the feed is a live database read on every request — a sector
 *    leader added (or removed) in the Super Admin console appears here on
 *    the next fetch, with zero caching in between (force-dynamic).
 *  - NO DUPLICATE SECTORS: at most ONE leader card per sector (first-seen
 *    wins in the console's curated order).
 *  - TRUSTWORTHY: only healthy workspaces showcase — soft-deleted,
 *    permanently/temporarily banned, and owner-disabled workspaces are
 *    filtered out alongside invisible rows.
 *  - `since` carries the workspace's real registration date (the
 *    «عميل منذ YYYY» chip in the admin console).
 *  - fail-open: any error answers an empty list — the landing strip then
 *    hides itself gracefully (never a broken section, never fake data).
 *
 * ROUND 173 — the query + filters live in the shared server layer
 * (src/lib/server/partners-feed.ts) so this route and the landing
 * PartnersStrip (which renders the same feed server-side) can never
 * drift apart.
 */
export async function GET() {
  const partners = await loadSectorPartners();
  return NextResponse.json({ partners });
}
