import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { storeUnavailable } from "@/lib/server/customer-account";
import { requireCustomer } from "@/lib/server/customer-session";
import { parseOrderSnapshot, parseStatusHistory } from "@/lib/server/order-snapshot";
import { toDisplayUnits } from "@/lib/server/money";
import type { SiteOrderDTO, SiteOrderItemDTO, SiteOrderStatus } from "@/lib/types";
import type { SiteOrder } from "@prisma/client";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

const ORDER_STATUSES = [
  "pending",
  "confirmed",
  "preparing",
  "ready",
  "completed",
  "cancelled",
] as const;

/** Max history rows served (the shopper's own orders, newest first). */
const HISTORY_CAP = 50;

function toOrderDTO(row: SiteOrder): SiteOrderDTO {
  const { items: parsedItems, legacy } = parseOrderSnapshot(row.itemsJson);
  const items: SiteOrderItemDTO[] = parsedItems.map((it) =>
    legacy ? { ...it, image: it.image ?? null } : { ...it, price: toDisplayUnits(it.price), image: it.image ?? null }
  );
  const total = legacy ? row.total : toDisplayUnits(row.total);
  const discount = legacy ? 0 : toDisplayUnits(row.discount);
  return {
    id: row.id,
    code: row.code,
    items,
    total,
    discount,
    couponCode: row.couponCode,
    currency: row.currency,
    status: (ORDER_STATUSES as readonly string[]).includes(row.status)
      ? (row.status as SiteOrderStatus)
      : "pending",
    note: row.note,
    statusNote: row.statusNote,
    statusHistory: parseStatusHistory(row.statusHistoryJson),
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

/**
 * GET /api/sites/[id]/account/orders — the signed-in shopper's order
 * history (round 65). Own rows only (customerId + instanceId scoped),
 * newest first, capped at 50 — the Amazon "Your Orders" tab.
 */
export async function GET(_req: Request, { params }: RouteContext) {
  const { id } = await params;
  const unavailable = await storeUnavailable(id);
  if (unavailable) return unavailable;
  const guard = await requireCustomer(id);
  if (guard instanceof NextResponse) return guard;

  try {
    /* ROUND 87 — trashed (soft-deleted) orders vanish from the shopper's
     * own history too. */
    const rows = await db.siteOrder.findMany({
      where: { instanceId: id, customerId: guard.customer.id, deletedAt: null },
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: HISTORY_CAP,
    });
    return NextResponse.json({ orders: rows.map(toOrderDTO) });
  } catch (error) {
    console.error(`account orders(${id}) failed:`, error);
    return NextResponse.json({ error: "Loading order history failed" }, { status: 500 });
  }
}
