import { NextResponse } from "next/server";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { originViolation } from "@/lib/server/origin-guard";
import { logAudit } from "@/lib/server/audit";
import { storeUnavailable } from "@/lib/server/customer-account";
import { readCustomerEmail, requireCustomer } from "@/lib/server/customer-session";
import {
  issueVerifyToken,
  orgDisplayName,
  sendVerificationEmail,
  verificationUrl,
  verifyLinkRevealEnabled,
  VERIFY_RESEND_COOLDOWN_MS,
} from "@/lib/server/verification";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * POST /api/sites/[id]/account/verify/resend — the signed-in customer asks
 * for a fresh verification email (ROUND 75).
 *
 *  - session-bound (requireCustomer) + origin-checked (CSRF);
 *  - 409 when the address is already verified;
 *  - ROUND 86 — exactly ONE request / 45 seconds / customer (the in-memory
 *    limiter keys on the customer id — rotating faster is meaningless, the
 *    previous link dies the moment a new token is minted);
 *  - rotates the single-use token (24h) and re-sends through the platform
 *    mailer; the response carries { sent, expiresAt } and — in development
 *    or ALLOW_DEMO_SECRETS deployments only — `devLink` so the flow stays
 *    walkable where mail delivery is spooled. Production never returns it.
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;

  const violation = originViolation(req);
  if (violation) return violation;

  const unavailable = await storeUnavailable(id);
  if (unavailable) return unavailable;

  const guard = await requireCustomer(id, req);
  if (guard instanceof NextResponse) return guard;
  const customer = guard.customer;

  if (customer.emailVerifiedAt) {
    return NextResponse.json(
      { error: "Email already verified", code: "ALREADY_VERIFIED" },
      { status: 409 }
    );
  }

  if (
    await rateLimited(`verify-resend:${customer.id}:${clientIp(req)}`, {
      limit: 1,
      windowMs: VERIFY_RESEND_COOLDOWN_MS,
    }, { failClosed: true })
  ) {
    return tooManyRequests({ limit: 1, windowMs: VERIFY_RESEND_COOLDOWN_MS, }, { error: "Please wait 45 seconds before requesting another email", code: "RESEND_COOLDOWN" });
  }

  try {
    const origin = new URL(req.url).origin;
    const orgName = await orgDisplayName(id);

    const { token, expiresAt } = await issueVerifyToken(customer.id);
    const url = verificationUrl(origin, id, token);
    const sent = await sendVerificationEmail({
      to: readCustomerEmail(customer),
      name: customer.name,
      url,
      orgName,
    });

    /* the customer's own audit trail (customer.verificationResend — in the
     * union since the ROUND 40 plan). Best-effort, never fails the send. */
    try {
      await logAudit({
        actorType: "public",
        actorId: customer.id,
        actorName: customer.name,
        action: "customer.verificationResend",
        targetLabel: customer.name,
        meta: { surface: "site-account", site: id, customer: customer.id, sent: String(sent) },
      });
    } catch (auditError) {
      console.error(`resend audit(${id}) failed:`, auditError);
    }

    return NextResponse.json({
      ok: true,
      sent,
      expiresAt: expiresAt.toISOString(),
      ...(verifyLinkRevealEnabled() ? { devLink: url } : {}),
    });
  } catch (error) {
    console.error(`POST /api/sites/${id}/account/verify/resend failed:`, error);
    return NextResponse.json({ error: "Could not send the email" }, { status: 500 });
  }
}
