import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { clientIp, rateLimited } from "@/lib/server/rate-limit";
import { logAudit } from "@/lib/server/audit";
import {
  hashVerifyToken,
  isVerifyTokenShape,
} from "@/lib/server/verification";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/** link-grind throttle: 10 verification attempts / hour / source IP + site. */
const VERIFY_RULE = { limit: 10, windowMs: 60 * 60 * 1000 };

/**
 * GET /api/sites/[id]/account/verify?token=… — the emailed verification
 * link (ROUND 75). PUBLIC by design: the link itself is the bearer proof —
 * no session cookie is read (the customer clicks it from their mail client,
 * often on another device). No origin guard either: it is a pure GET with
 * no side effects beyond consuming the single-use token.
 *
 * Flow: sha256(token) → the instance-scoped row → expiry window → an
 * atomic updateMany guarded on the SAME hash (a replayed token matches 0
 * rows and fails closed) → 303 redirect to the public site with
 * ?verified=1 (success) or ?verified=0 (anything else). The site page
 * turns the flag into a toast.
 */
export async function GET(req: Request, { params }: RouteContext) {
  const { id } = await params;

  /* ROUND 120 — no-store on BOTH redirects: a one-time-token outcome
   * must never sit in an intermediary's cache */
  const failure = () => {
    const res = NextResponse.redirect(new URL(`/sites/${id}?verified=0`, req.url), 303);
    res.headers.set("Cache-Control", "no-store");
    return res;
  };

  const token = new URL(req.url).searchParams.get("token") ?? "";
  if (!isVerifyTokenShape(token)) return failure();

  if (
    await rateLimited(`verify:${id}:${clientIp(req)}`, VERIFY_RULE, {
      failClosed: true,
    })
  ) {
    return failure();
  }

  try {
    const hash = hashVerifyToken(token);
    /* ROUND 87 — a trashed (soft-deleted) account's verification link is
     * dead (failure redirect, same as any invalid token). */
    const row = await db.siteCustomer.findFirst({
      where: { instanceId: id, verifyTokenHash: hash, deletedAt: null },
      select: { id: true, verifyTokenExpiresAt: true, name: true },
    });
    if (
      !row ||
      !row.verifyTokenExpiresAt ||
      row.verifyTokenExpiresAt.getTime() < Date.now()
    ) {
      return failure();
    }

    /* atomic single-use consumption — the WHERE keeps a racing replay
     * (double click, mail-client prefetch) from both succeeding. */
    const consumed = await db.siteCustomer.updateMany({
      where: { id: row.id, instanceId: id, verifyTokenHash: hash },
      data: {
        emailVerifiedAt: new Date(),
        verifyTokenHash: null,
        verifyTokenExpiresAt: null,
      },
    });
    if (consumed.count !== 1) return failure();

    /* the email address is now proven controlled — the account's own
     * audit trail (customer.verify has existed in the union since the
     * ROUND 40 schema plan). */
    try {
      await logAudit({
        actorType: "public",
        actorId: row.id,
        actorName: row.name,
        action: "customer.verify",
        targetLabel: row.name,
        meta: { surface: "site-account", site: id, customer: row.id },
      });
    } catch (auditError) {
      /* the verification itself already committed — never fail over it */
      console.error(`verify audit(${id}) failed:`, auditError);
    }

    const success = NextResponse.redirect(
      new URL(`/sites/${id}?verified=1`, req.url),
      303
    );
    success.headers.set("Cache-Control", "no-store");
    return success;
  } catch (error) {
    console.error(`GET /api/sites/${id}/account/verify failed:`, error);
    return failure();
  }
}
