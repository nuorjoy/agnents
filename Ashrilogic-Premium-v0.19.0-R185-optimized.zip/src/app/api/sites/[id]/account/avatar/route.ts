import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { readJson } from "@/lib/server/http";
import { clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { zodError } from "@/lib/server/instance-mapper";
import { ImageValidationError } from "@/lib/server/upload-validation";
import { storeImageDataUrl } from "@/lib/server/image-store";
import { storeUnavailable, toAccountDTO } from "@/lib/server/customer-account";
import { requireCustomer } from "@/lib/server/customer-session";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * ROUND 147 — the customer-scoped AVATAR leg:
 * /api/sites/[id]/account/avatar.
 *
 * POST   { image: dataUrl } — the signed-in member uploads their profile
 *        photo. The data-URL runs the FULL image pipeline (magic bytes,
 *        dimension/pixel/bomb caps, sharp re-encode to clean WebP — the
 *        same storeImageDataUrl the merchant media leg uses) and the row
 *        stores ONLY the short managed reference /api/images/<sha>. The
 *        client normally ships a canvas-compressed JPEG, but the raw
 *        original (≤5 MB) is accepted too — the server re-encode is the
 *        single authority either way.
 *
 * DELETE — clears the avatar (the initials tile returns).
 *
 * Guards mirror the account PATCH posture EXACTLY (storeUnavailable +
 * requireCustomer — the account subtree is not trial-locked the way
 * business APIs are; requireCustomer carries the same-origin CSRF check
 * and the maintenance window) plus a per-site+IP upload throttle
 * (failClosed — an upload surface must not fail open) and the bounded
 * readJson body cap. The write is scoped to the SESSION OWNER's row only
 * (guard.customer.id) — no body-supplied id is ever trusted.
 *
 * Responses: 200 { account } (the same shape PATCH /account answers with —
 * the client write-through feeds the shared ["store-account", id] cache)
 * · 400 pipeline rejection (its user-presentable message verbatim) /
 * bad payload · 401/403 the session guard · 413 oversized body ·
 * 429 throttle · 500 store failure.
 */

/** avatar churn throttle: 10 mutations / 10 min per site + source IP. */
const AVATAR_RULE = { limit: 10, windowMs: 10 * 60 * 1000 };

/** the door matches the bounded-body ceiling (5 MB of image payload). */
const MAX_IMAGE_INPUT_BYTES = 5 * 1024 * 1024;
/** base64 inflates by 4/3 + the JSON envelope — the bounded-body ceiling. */
const JSON_BODY_CAP = Math.ceil((MAX_IMAGE_INPUT_BYTES * 4) / 3) + 64 * 1024;

const avatarUploadSchema = z.object({
  image: z.string().min(30).max(JSON_BODY_CAP),
});

export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;

  /* the account PATCH's exact guard posture, in the same order. */
  const unavailable = await storeUnavailable(id);
  if (unavailable) return unavailable;
  const guard = await requireCustomer(id, req);
  if (guard instanceof NextResponse) return guard;

  if (await rateLimited(`avatar:${id}:${clientIp(req)}`, AVATAR_RULE, { failClosed: true })) {
    return tooManyRequests(AVATAR_RULE, {
      error: "Too many avatar updates — try again in a few minutes",
    });
  }

  const body = await readJson(req, JSON_BODY_CAP);
  if (!body.ok) return body.response;

  const parsed = avatarUploadSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }

  try {
    /* the full validation + re-encode pipeline — nothing about the
     * client's bytes is trusted; the persisted value is the SHORT
     * managed ref the pipeline mints. */
    const stored = await storeImageDataUrl(parsed.data.image, {
      maxInputBytes: MAX_IMAGE_INPUT_BYTES,
    });

    const fresh = await db.siteCustomer.update({
      where: { id: guard.customer.id },
      data: { avatarUrl: stored.url },
    });
    return NextResponse.json({ account: toAccountDTO(fresh) });
  } catch (error) {
    if (error instanceof ImageValidationError) {
      /* the pipeline's message is user-presentable by contract */
      return NextResponse.json({ error: error.message }, { status: 400 });
    }
    console.error(`avatar upload(${id}) failed:`, error);
    return NextResponse.json({ error: "Avatar update failed" }, { status: 500 });
  }
}

export async function DELETE(req: Request, { params }: RouteContext) {
  const { id } = await params;

  /* the same guard + throttle posture as the upload leg. */
  const unavailable = await storeUnavailable(id);
  if (unavailable) return unavailable;
  const guard = await requireCustomer(id, req);
  if (guard instanceof NextResponse) return guard;

  if (await rateLimited(`avatar:${id}:${clientIp(req)}`, AVATAR_RULE, { failClosed: true })) {
    return tooManyRequests(AVATAR_RULE, {
      error: "Too many avatar updates — try again in a few minutes",
    });
  }

  try {
    const fresh = await db.siteCustomer.update({
      where: { id: guard.customer.id },
      data: { avatarUrl: null },
    });
    return NextResponse.json({ account: toAccountDTO(fresh) });
  } catch (error) {
    console.error(`avatar remove(${id}) failed:`, error);
    return NextResponse.json({ error: "Avatar removal failed" }, { status: 500 });
  }
}
