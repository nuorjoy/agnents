import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { originViolation } from "@/lib/server/origin-guard";
import { readJson } from "@/lib/server/http";
import { storeUnavailable, toAccountDTO } from "@/lib/server/customer-account";
import { hashCustomerPassword, setCustomerSession } from "@/lib/server/customer-session";
import { hashVerifyToken, isVerifyTokenShape, orgDisplayName, sendPasswordChangedEmail } from "@/lib/server/verification";
import { decryptField } from "@/lib/server/crypto-vault";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/** reset throttle: 10 attempts / 15 min / source IP + site (brute-forcing a
 *  token must be as impractical as brute-forcing a password). */
const RESET_RULE = { limit: 10, windowMs: 15 * 60 * 1000 };

const resetSchema = z.object({
  token: z.string().min(64).max(64),
  password: z
    .string()
    .min(8)
    .max(72)
    .refine((pw) => /[A-Za-z]/.test(pw) && /[0-9]/.test(pw), {
      message: "password must mix letters and digits",
    }),
});

/**
 * ROUND 85 — POST /api/sites/[id]/account/reset
 *
 * Consumes a single-use password-reset token (the emailed link opens the
 * ACCOUNT PAGE in reset mode, which posts here):
 *
 *  200 { ok: true, account } — password replaced with a fresh Argon2id
 *       record, the token columns cleared, sessionVersion BUMPED (every
 *       outstanding session on every device dies instantly — the ROUND 36
 *       convention) and the customer signed in right away (Amazon-style
 *       friction-free recovery);
 *  400 bad payload · 401 unknown/expired/used token (uniform — no token
 *       oracle) · 403 origin violation / store unavailable · 429 rate.
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;

  const violation = originViolation(req);
  if (violation) return violation;

  const unavailable = await storeUnavailable(id);
  if (unavailable) return unavailable;

  if (await rateLimited(`reset:${id}:${clientIp(req)}`, RESET_RULE, { failClosed: true })) {
    return tooManyRequests(RESET_RULE, { error: "Too many attempts — try again in a few minutes" });
  }

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = resetSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid reset details", issues: parsed.error.flatten().fieldErrors },
      { status: 400 }
    );
  }

  try {
    /* shape gate first — a non-hex string can never match an index anyway */
    if (!isVerifyTokenShape(parsed.data.token)) {
      return NextResponse.json(
        { error: "This reset link is invalid or has expired", code: "RESET_INVALID" },
        { status: 401 }
      );
    }

    /* ROUND 87 — a trashed (soft-deleted) account's reset link is dead
     * (uniform 401 like every other invalid token). */
    const row = await db.siteCustomer.findFirst({
      where: { instanceId: id, resetTokenHash: hashVerifyToken(parsed.data.token), deletedAt: null },
      select: { id: true, status: true, resetTokenExpiresAt: true, name: true, email: true },
    });

    /* uniform 401 for unknown / already-used / expired tokens */
    if (
      !row ||
      !row.resetTokenExpiresAt ||
      row.resetTokenExpiresAt.getTime() < Date.now() ||
      row.status === "banned"
    ) {
      return NextResponse.json(
        { error: "This reset link is invalid or has expired", code: "RESET_INVALID" },
        { status: 401 }
      );
    }

    /* the atomic recovery: fresh Argon2id record + token columns cleared +
     * sessionVersion bumped (kills every stolen session) in ONE update */
    const fresh = await db.siteCustomer.update({
      where: { id: row.id },
      data: {
        passwordHash: hashCustomerPassword(parsed.data.password),
        resetTokenHash: null,
        resetTokenExpiresAt: null,
        sessionVersion: { increment: 1 },
        lastLoginAt: new Date(),
      },
    });

    /* friction-free recovery — the customer is signed in on THIS device
     * immediately (the bumped epoch is what the fresh session carries) */
    await setCustomerSession(id, fresh.id, fresh.sessionVersion ?? 0, {
      ip: clientIp(req),
      userAgent: req.headers.get("user-agent"),
    });

    /* EMAIL SYSTEM — the standard post-reset SECURITY ALERT (typed
     * "securityAlert" in the EmailLog trail): a stolen-session attacker
     * rotating the password can no longer hide. Best-effort by contract —
     * it must never fail the completed recovery. */
    try {
      const email = (decryptField(row.email) ?? "").trim();
      if (email.includes("@")) {
        await sendPasswordChangedEmail({
          to: email,
          name: row.name,
          orgName: await orgDisplayName(id),
        });
      }
    } catch (alertError) {
      console.error(`password-changed alert(${id}) failed:`, alertError);
    }

    return NextResponse.json({ ok: true, account: toAccountDTO(fresh) });
  } catch (error) {
    console.error(`reset(${id}) failed:`, error);
    return NextResponse.json({ error: "Reset failed" }, { status: 500 });
  }
}
