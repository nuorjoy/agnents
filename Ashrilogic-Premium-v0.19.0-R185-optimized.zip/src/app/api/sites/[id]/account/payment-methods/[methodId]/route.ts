import { NextResponse } from "next/server";
import {
  storeUnavailable,
  toAccountDTO,
  withoutPaymentMethod,
  writeCustomerWalletCas,
} from "@/lib/server/customer-account";
import { requireCustomer } from "@/lib/server/customer-session";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string; methodId: string }> };

/**
 * DELETE /api/sites/[id]/account/payment-methods/[methodId] — remove a
 * saved card (deleting the default promotes the first remaining).
 */
export async function DELETE(req: Request, { params }: RouteContext) {
  const { id, methodId } = await params;
  const unavailable = await storeUnavailable(id);
  if (unavailable) return unavailable;
  const guard = await requireCustomer(id, req);
  if (guard instanceof NextResponse) return guard;

  /* ROUND 121 — CAS write (the pre-121 unconditional update lost a
   * concurrent wallet change): the removal is re-applied on the freshest
   * wallet; the card vanishing under us surfaces as 404; a still-live race
   * resolves as a clean 409 — never a silent last-write-win. */
  try {
    const outcome = await writeCustomerWalletCas(
      guard.customer,
      "paymentMethodsJson",
      (row) => {
        const next = withoutPaymentMethod(row, methodId);
        return next ? { value: JSON.stringify(next) } : { error: "GONE" };
      }
    );
    if (outcome.ok) {
      return NextResponse.json({ account: toAccountDTO(outcome.customer) });
    }
    if (outcome.code === "GONE" || outcome.code === "CAP") {
      return NextResponse.json({ error: "Card not found" }, { status: 404 });
    }
    return NextResponse.json(
      { error: "This account was updated on another device — refresh and retry", code: "CONFLICT" },
      { status: 409 }
    );
  } catch (error) {
    console.error(`payment-method delete(${id}) failed:`, error);
    return NextResponse.json({ error: "Removing the card failed" }, { status: 500 });
  }
}
