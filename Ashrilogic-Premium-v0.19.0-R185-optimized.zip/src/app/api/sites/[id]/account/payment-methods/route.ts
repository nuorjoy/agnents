import { NextResponse } from "next/server";
import { readJson } from "@/lib/server/http";
import {
  expiryIsFuture,
  luhnValid,
  paymentMethodSchema,
  readPaymentMethods,
  storeUnavailable,
  toAccountDTO,
  withPaymentMethod,
  writeCustomerWalletCas,
} from "@/lib/server/customer-account";
import { requireCustomer } from "@/lib/server/customer-session";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * GET /api/sites/[id]/account/payment-methods — the saved payment methods
 * (display-safe metadata only — the payload never contained the PAN).
 */
export async function GET(_req: Request, { params }: RouteContext) {
  const { id } = await params;
  const unavailable = await storeUnavailable(id);
  if (unavailable) return unavailable;
  const guard = await requireCustomer(id);
  if (guard instanceof NextResponse) return guard;
  return NextResponse.json({ paymentMethods: readPaymentMethods(guard.customer) });
}

/**
 * POST /api/sites/[id]/account/payment-methods — save a card (round 65).
 *
 * PCI posture: the card NUMBER arrives ONCE in the request body, is
 * validated (LUHN) + brand-detected inside the shared domain module and
 * REDUCED to {brand, last4} — the persisted row (paymentMethodsJson) never
 * contains the full number, and no log line ever echoes it. Capped at
 * MAX_PAYMENT_METHODS; first card auto-defaults.
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const unavailable = await storeUnavailable(id);
  if (unavailable) return unavailable;
  const guard = await requireCustomer(id, req);
  if (guard instanceof NextResponse) return guard;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = paymentMethodSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid card details", issues: parsed.error.flatten().fieldErrors },
      { status: 400 }
    );
  }

  const digits = parsed.data.number.replace(/[\s-]/g, "");
  if (!luhnValid(digits)) {
    return NextResponse.json(
      { error: "This card number failed the checksum — retype it", code: "LUHN" },
      { status: 400 }
    );
  }

  /* ROUND 120 — the CURRENT-YEAR boundary the year schema cannot express:
  * a card expiring THIS year must have a month ≥ the current month */
  if (!expiryIsFuture(parsed.data.expYear, parsed.data.expMonth)) {
    return NextResponse.json(
      { error: "This card is expired", code: "EXPIRED" },
      { status: 400 }
    );
  }

  const result = withPaymentMethod(guard.customer, { ...parsed.data, number: digits });
  if (result.error === "CAP") {
    return NextResponse.json(
      { error: "Card wallet is full — remove one first", code: "CAP" },
      { status: 409 }
    );
  }

  /* ROUND 121 — CAS write via the shared wallet writer: the add is
   * re-applied on the FRESH wallet when a concurrent device changed it
   * (the R120 retry wrote the original-base value — the concurrent change
   * was still lost); a second miss is a clean 409. */
  try {
    const outcome = await writeCustomerWalletCas(
      guard.customer,
      "paymentMethodsJson",
      (row) => {
        const result = withPaymentMethod(row, { ...parsed.data, number: digits });
        return result.error === "CAP"
          ? { error: "CAP" }
          : { value: JSON.stringify(result.methods) };
      }
    );
    if (outcome.ok) {
      return NextResponse.json({ account: toAccountDTO(outcome.customer) }, { status: 201 });
    }
    if (outcome.code === "CAP") {
      return NextResponse.json(
        { error: "Card wallet is full — remove one first", code: "CAP" },
        { status: 409 }
      );
    }
    return NextResponse.json(
      { error: "This account was updated on another device — refresh and retry", code: "CONFLICT" },
      { status: 409 }
    );
  } catch (error) {
    console.error(`payment-method add(${id}) failed:`, error);
    return NextResponse.json({ error: "Could not save the card — try again", code: "STORE" }, { status: 500 });
  }
}
