import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { readJson } from "@/lib/server/http";
import { zodError } from "@/lib/server/instance-mapper";
import { encryptField, blindIndex, verifyPasswordArgon2id } from "@/lib/server/crypto-vault";
import {
  profilePatchSchema,
  storeUnavailable,
  toAccountDTO,
  toAccountDTOWithHandle,
} from "@/lib/server/customer-account";
import {
  readCustomerEmail,
  requireCustomer,
  clearCustomerSession,
} from "@/lib/server/customer-session";
import { logAudit, maskEmail } from "@/lib/server/audit";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * GET /api/sites/[id]/account — the signed-in shopper's own account
 * (profile + saved addresses + saved payment methods). Guest callers get
 * `{ signedIn: false }` (200 — the storefront boots guest-first, this is
 * the state probe, not an error).
 *
 * ROUND 74 — the signed-in response now carries `unreadReplies`: how many
 * of the org's replies to this customer's inquiries have not been SEEN yet
 * (one indexed count through the email blind index). Drives the amber
 * badge on the account button; clears when the customer opens the
 * "استفساراتي" tab (the history route marks them read).
 */
export async function GET(_req: Request, { params }: RouteContext) {
  const { id } = await params;
  const unavailable = await storeUnavailable(id);
  if (unavailable) return unavailable;
  const guard = await requireCustomer(id);
  if (guard instanceof NextResponse) {
    return NextResponse.json({ signedIn: false });
  }

  let unreadReplies = 0;
  try {
    const email = readCustomerEmail(guard.customer).trim().toLowerCase();
    const index = email ? blindIndex(email) : null;
    if (index) {
      unreadReplies = await db.supportTicket.count({
        where: {
          instanceId: id,
          requesterEmailIndex: index,
          reply: { not: null },
          replyReadAt: null,
        },
      });
    }
  } catch (error) {
    /* the badge is decorative — never fail the probe over it */
    console.error(`unread replies count(${id}) failed:`, error);
  }

  /* ROUND 141 — the state probe hands the client the member's handle (the
   * profile-page URL) — lazily minted + persisted for legacy rows. */
  return NextResponse.json({
    signedIn: true,
    account: await toAccountDTOWithHandle(guard.customer),
    unreadReplies,
  });
}

/**
 * PATCH /api/sites/[id]/account — profile self-service (name / phone).
 * The EMAIL is immutable from this route (it is the credential identity —
 * changing it needs re-verification, out of scope for round 65).
 */
export async function PATCH(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const unavailable = await storeUnavailable(id);
  if (unavailable) return unavailable;
  const guard = await requireCustomer(id, req);
  if (guard instanceof NextResponse) return guard;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = profilePatchSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid profile fields" }, { status: 400 });
  }

  const data: Record<string, unknown> = {};
  if (parsed.data.name !== undefined) data.name = parsed.data.name;
  if (parsed.data.phone !== undefined) {
    data.phone = parsed.data.phone ? (encryptField(parsed.data.phone) ?? null) : null;
  }
  /* ROUND L (TASK STORE-PROFILE) — username self-service: server-side
   * re-validation + uniqueness check BEFORE the update. A 409 USERNAME_TAKEN
   * is friendlier than a raw P2002 from the unique index (and surfaces a
   * localized toast via mapAccountError). Same law as the register route. */
  if (typeof parsed.data.username === "string" && parsed.data.username.length > 0) {
    const wanted = parsed.data.username.toLowerCase();
    if (wanted !== guard.customer.username) {
      const collision = await db.siteCustomer.findFirst({
        where: {
          instanceId: id,
          username: wanted,
          deletedAt: null,
          /* exclude the customer's own row (no-op when the handle is unchanged). */
          NOT: { id: guard.customer.id },
        },
        select: { id: true },
      });
      if (collision) {
        return NextResponse.json(
          { error: "This username is taken — pick another", code: "USERNAME_TAKEN" },
          { status: 409 }
        );
      }
      data.username = wanted;
    }
  }
  if (Object.keys(data).length === 0) {
    return NextResponse.json({ error: "Nothing to update" }, { status: 400 });
  }

  try {
    const fresh = await db.siteCustomer.update({
      where: { id: guard.customer.id },
      data,
    });
    return NextResponse.json({ account: toAccountDTO(fresh) });
  } catch (error) {
    /* P2002 race: a concurrent writer claimed this username in the sub-second
     * window between our check and the update — surface USERNAME_TAKEN (the
     * localized toast handles it). */
    if ((error as { code?: string }).code === "P2002") {
      return NextResponse.json(
        { error: "This username is taken — pick another", code: "USERNAME_TAKEN" },
        { status: 409 }
      );
    }
    console.error(`profile patch(${id}) failed:`, error);
    return NextResponse.json({ error: "Profile update failed" }, { status: 500 });
  }
}

const deleteSchema = z.object({
  /** proof-of-knowledge: the account's own password (never a one-click delete) */
  password: z.string().min(1).max(128),
  /** the typed confirmation phrase — the UI enforces it, the API
   *  re-checks it: permanent deletion must be a deliberate two-factor
   *  gesture (password + typed confirmation), not a misclick. */
  confirm: z.literal("DELETE"),
});

/**
 * DELETE /api/sites/[id]/account — ROUND 87 (account lifecycle): the
 * customer PERMANENTLY deletes their own account (نهائي وسريع).
 *
 * Strict contract:
 *  - password proof-of-knowledge + the typed DELETE confirmation;
 *  - the deletion is PERMANENT (no trash — the customer is gone NOW):
 *    the account row is destroyed and their orders cascade with it
 *    (guest orders and the org's other data are untouched);
 *  - the live customer session is revoked + the cookie cleared before
 *    the row dies;
 *  - audited unconditionally as a SECURITY action (siteCustomer.selfDelete)
 *    with the masked email for the trail — the raw address leaves with row.
 */
export async function DELETE(req: Request, { params }: RouteContext) {
  const { id } = await params;

  /* same posture as every account mutation: live site + not maintenance */
  const unavailable = await storeUnavailable(id);
  if (unavailable) return unavailable;

  const guard = await requireCustomer(id, req);
  if (guard instanceof NextResponse) return guard;
  const customer = guard.customer;

  const body = await readJson(req);
  if (!body.ok) return body.response;
  const parsed = deleteSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json(
      { error: zodError(parsed.error), code: "CONFIRM_REQUIRED" },
      { status: 400 }
    );
  }

  /* proof-of-knowledge: the account's own Argon2id password record */
  const passwordOk = verifyPasswordArgon2id(parsed.data.password, customer.passwordHash);
  if (!passwordOk) {
    await logAudit({
      actorType: "public",
      actorName: maskEmail(readCustomerEmail(customer)),
      action: "siteCustomer.selfDelete",
      targetLabel: "password-proof-failed",
    });
    return NextResponse.json(
      { error: "Incorrect password — account deletion refused", code: "PASSWORD_PROOF" },
      { status: 403 }
    );
  }

  try {
    const maskedEmail = maskEmail(readCustomerEmail(customer));
    /* cut the session BEFORE the row dies (cookie + jti registry) */
    await clearCustomerSession();

    /* permanent: the account row is destroyed; their orders cascade with
       it (FK law) — the store's other orders, coupons and content are
       untouched, and support inquiries keyed by the email blind index
       survive as the org's own records. */
    await db.siteCustomer.delete({ where: { id: customer.id } });

    await logAudit({
      actorType: "public",
      actorName: maskedEmail,
      action: "siteCustomer.selfDelete",
      targetLabel: maskedEmail,
      meta: { site: id, permanent: "true" },
    });

    return NextResponse.json({ ok: true, permanent: true });
  } catch (error) {
    console.error(`DELETE /api/sites/${id}/account failed:`, error);
    return NextResponse.json({ error: "Failed to delete the account" }, { status: 500 });
  }
}
