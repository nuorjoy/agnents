import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { storeUnavailable } from "@/lib/server/customer-account";
import { readCustomerEmail, requireCustomer } from "@/lib/server/customer-session";
import { blindIndex } from "@/lib/server/crypto-vault";
import type { SiteInquiryDTO } from "@/lib/types";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/** Max inquiry rows served (newest activity first). */
const HISTORY_CAP = 50;

/**
 * ROUND 73 — GET /api/sites/[id]/account/inquiries
 *
 * The signed-in customer's own support-inquiry history — the "استفساراتي"
 * tab on the account sheet. Matching runs through the requester email BLIND
 * INDEX (the exact HMAC join the owner's customers console uses), so:
 *  - zero AES-GCM decrypt per ticket (index lookup only),
 *  - only tickets filed with THIS account's sealed email ever match,
 *  - the projection carries no PII beyond the customer's own words.
 *
 * Scoped to this instance; newest-updated first; capped at 50.
 */
export async function GET(_req: Request, { params }: RouteContext) {
  const { id } = await params;
  const unavailable = await storeUnavailable(id);
  if (unavailable) return unavailable;
  const guard = await requireCustomer(id);
  if (guard instanceof NextResponse) return guard;

  try {
    /* unseal the account's email → the same normalized blind index the
     * public contact form stamped onto its tickets at filing time */
    const email = readCustomerEmail(guard.customer).trim().toLowerCase();
    const index = email ? blindIndex(email) : null;
    if (!index) return NextResponse.json({ inquiries: [], unreadCount: 0 });

    const rows = await db.supportTicket.findMany({
      where: { instanceId: id, requesterEmailIndex: index },
      orderBy: [{ updatedAt: "desc" }, { id: "desc" }],
      take: HISTORY_CAP,
      select: {
        id: true,
        subject: true,
        message: true,
        category: true,
        priority: true,
        status: true,
        reply: true,
        replyReadAt: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    /* ROUND 74 — `fresh`: the org's reply hasn't been opened yet (computed
     * BEFORE the mark-read below so this very response still carries it —
     * the card paints its «جديد» chip and the badge count survives this
     * render, then clears on the next probe). */
    const inquiries: SiteInquiryDTO[] = rows.map((row) => ({
      id: row.id,
      subject: row.subject,
      message: row.message,
      category: row.category,
      priority: row.priority,
      status: row.status,
      reply: row.reply,
      fresh: row.reply != null && row.replyReadAt == null,
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
    }));

    /* ROUND 74 — opening the history IS reading the replies: mark the
     * returned rows read (scoped to their ids — nothing older is touched)
     * so the amber badge on the account button clears once the customer
     * has actually SEEN the answers. */
    const unreadCount = inquiries.filter((i) => i.fresh).length;
    if (unreadCount > 0) {
      await db.supportTicket.updateMany({
        where: {
          id: { in: rows.map((row) => row.id) },
          reply: { not: null },
          replyReadAt: null,
        },
        data: { replyReadAt: new Date() },
      });
    }

    return NextResponse.json({ inquiries, unreadCount });
  } catch (error) {
    console.error(`account inquiries(${id}) failed:`, error);
    return NextResponse.json(
      { error: "Loading inquiry history failed" },
      { status: 500 }
    );
  }
}
