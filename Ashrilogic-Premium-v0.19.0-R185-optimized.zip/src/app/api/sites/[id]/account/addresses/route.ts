import { NextResponse } from "next/server";
import { readJson } from "@/lib/server/http";
import {
  addressSchema,
  readAddresses,
  storeUnavailable,
  toAccountDTO,
  withAddress,
  writeCustomerWalletCas,
} from "@/lib/server/customer-account";
import { requireCustomer } from "@/lib/server/customer-session";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * GET /api/sites/[id]/account/addresses — the saved shipping addresses
 * (part of the account payload; a light list endpoint for the sheet).
 */
export async function GET(_req: Request, { params }: RouteContext) {
  const { id } = await params;
  const unavailable = await storeUnavailable(id);
  if (unavailable) return unavailable;
  const guard = await requireCustomer(id);
  if (guard instanceof NextResponse) return guard;
  return NextResponse.json({ addresses: readAddresses(guard.customer) });
}

/**
 * POST /api/sites/[id]/account/addresses — add a shipping address
 * (Amazon address-book pattern; capped at MAX_ADDRESSES, first = default).
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const unavailable = await storeUnavailable(id);
  if (unavailable) return unavailable;
  const guard = await requireCustomer(id, req);
  if (guard instanceof NextResponse) return guard;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = addressSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid address details", issues: parsed.error.flatten().fieldErrors },
      { status: 400 }
    );
  }

  /* ROUND 121 — CAS write: a concurrent address-book change on another
   * device is MERGED (the add is re-applied on the fresh book) or cleanly
   * conflicts — never silently discarded. */
  try {
    const outcome = await writeCustomerWalletCas(
      guard.customer,
      "addressesJson",
      (row) => {
        const result = withAddress(row, parsed.data);
        return result.error === "CAP"
          ? { error: "CAP" }
          : { value: JSON.stringify(result.addresses) };
      }
    );
    if (outcome.ok) {
      return NextResponse.json({ account: toAccountDTO(outcome.customer) }, { status: 201 });
    }
    if (outcome.code === "CAP") {
      return NextResponse.json(
        { error: "Address book is full — remove one first", code: "CAP" },
        { status: 409 }
      );
    }
    return NextResponse.json(
      { error: "This account was updated on another device — refresh and retry", code: "CONFLICT" },
      { status: 409 }
    );
  } catch (error) {
    console.error(`address add(${id}) failed:`, error);
    return NextResponse.json({ error: "Saving the address failed" }, { status: 500 });
  }
}
