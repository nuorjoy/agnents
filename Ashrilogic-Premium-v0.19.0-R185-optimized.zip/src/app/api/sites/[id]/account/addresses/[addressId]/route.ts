import { NextResponse } from "next/server";
import { readJson } from "@/lib/server/http";
import {
  addressPatchSchema,
  patchAddress,
  storeUnavailable,
  toAccountDTO,
  withoutAddress,
  writeCustomerWalletCas,
} from "@/lib/server/customer-account";
import { requireCustomer } from "@/lib/server/customer-session";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string; addressId: string }> };

/**
 * PATCH /api/sites/[id]/account/addresses/[addressId] — merge-edit one
 * saved address (any subset of fields; `isDefault` re-points the default).
 */
export async function PATCH(req: Request, { params }: RouteContext) {
  const { id, addressId } = await params;
  const unavailable = await storeUnavailable(id);
  if (unavailable) return unavailable;
  const guard = await requireCustomer(id, req);
  if (guard instanceof NextResponse) return guard;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = addressPatchSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid address changes" }, { status: 400 });
  }

  /* ROUND 121 — CAS write: the edit is re-applied on the freshest address
   * book (a concurrent add/remove on another device survives); the target
   * address vanishing under us surfaces as 404, and a still-live race
   * resolves as a clean 409 — never a silent last-write-win. */
  try {
    const outcome = await writeCustomerWalletCas(
      guard.customer,
      "addressesJson",
      (row) => {
        const next = patchAddress(row, addressId, parsed.data);
        return next ? { value: JSON.stringify(next) } : { error: "GONE" };
      }
    );
    if (outcome.ok) {
      return NextResponse.json({ account: toAccountDTO(outcome.customer) });
    }
    if (outcome.code === "GONE") {
      return NextResponse.json({ error: "Address not found" }, { status: 404 });
    }
    if (outcome.code === "CAP") {
      return NextResponse.json({ error: "Address not found" }, { status: 404 });
    }
    return NextResponse.json(
      { error: "This account was updated on another device — refresh and retry", code: "CONFLICT" },
      { status: 409 }
    );
  } catch (error) {
    console.error(`address patch(${id}) failed:`, error);
    return NextResponse.json({ error: "Updating the address failed" }, { status: 500 });
  }
}

/**
 * DELETE /api/sites/[id]/account/addresses/[addressId] — remove one saved
 * address (deleting the default promotes the first remaining).
 */
export async function DELETE(req: Request, { params }: RouteContext) {
  const { id, addressId } = await params;
  const unavailable = await storeUnavailable(id);
  if (unavailable) return unavailable;
  const guard = await requireCustomer(id, req);
  if (guard instanceof NextResponse) return guard;

  /* ROUND 121 — CAS write (see PATCH above). */
  try {
    const outcome = await writeCustomerWalletCas(
      guard.customer,
      "addressesJson",
      (row) => {
        const next = withoutAddress(row, addressId);
        return next ? { value: JSON.stringify(next) } : { error: "GONE" };
      }
    );
    if (outcome.ok) {
      return NextResponse.json({ account: toAccountDTO(outcome.customer) });
    }
    if (outcome.code === "GONE" || outcome.code === "CAP") {
      return NextResponse.json({ error: "Address not found" }, { status: 404 });
    }
    return NextResponse.json(
      { error: "This account was updated on another device — refresh and retry", code: "CONFLICT" },
      { status: 409 }
    );
  } catch (error) {
    console.error(`address delete(${id}) failed:`, error);
    return NextResponse.json({ error: "Removing the address failed" }, { status: 500 });
  }
}
