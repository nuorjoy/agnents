import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { originViolation } from "@/lib/server/origin-guard";
import { readJson } from "@/lib/server/http";
import { blindIndex, encryptField } from "@/lib/server/crypto-vault";
import {
  registerSchema,
  storeUnavailable,
  toAccountDTO,
  toAccountDTOWithHandle,
} from "@/lib/server/customer-account";
import {
  hashCustomerPassword,
  setCustomerSession,
  resolveCustomerSession,
} from "@/lib/server/customer-session";
import {
  issueVerifyToken,
  orgDisplayName,
  sendVerificationEmail,
  verificationUrl,
  verifyLinkRevealEnabled,
} from "@/lib/server/verification";
import { sendWelcomeEmail, welcomeMailEnabled } from "@/lib/server/mail";
/* ROUND L (TASK STORE-PROFILE) — the customer CHOOSES their username. When
 * they DON'T supply one (legacy clients), the server mints a unique handle
 * from the email local-part (the existing member-handle.ensureHandle law). */
import { mintUniqueHandle } from "@/lib/server/member-handle";

/** verification dispatch — best-effort by design: a mail hiccup must NEVER
 *  fail a durable signup (the ROUND 75 banner lets the customer re-send).
 *  Returns the response hint (and, on dev/demo deployments, the link).
 *  EMAIL SYSTEM — the optional welcome letter (mail settings `sendWelcome`)
 *  rides the same best-effort dispatch, typed "welcome" in the EmailLog. */
async function dispatchVerification(
  instanceId: string,
  customerId: string,
  email: string,
  name: string,
  origin: string
): Promise<{ sent: boolean; expiresAt: string; devLink?: string } | null> {
  try {
    const orgName = await orgDisplayName(instanceId);
    const { token, expiresAt } = await issueVerifyToken(customerId);
    const url = verificationUrl(origin, instanceId, token);
    const sent = await sendVerificationEmail({
      to: email,
      name,
      url,
      orgName,
    });
    /* the optional warm greeting — only when the admin opted in */
    if (await welcomeMailEnabled()) {
      try {
        await sendWelcomeEmail({
          to: email,
          name,
          orgName,
          siteUrl: `${origin}/sites/${encodeURIComponent(instanceId)}/store`,
        });
      } catch {
        /* the welcome letter is strictly cosmetic — never surfaces */
      }
    }
    return {
      sent,
      expiresAt: expiresAt.toISOString(),
      ...(verifyLinkRevealEnabled() ? { devLink: url } : {}),
    };
  } catch (error) {
    console.error(`verification dispatch(${instanceId}) failed:`, error);
    return null;
  }
}

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/** registration throttle: 5 signups / hour / source IP + site. */
const REGISTER_RULE = { limit: 5, windowMs: 60 * 60 * 1000 };

/**
 * POST /api/sites/[id]/account/register — storefront SIGN UP (round 65).
 *
 * Creates a full customer account (profile + saved-address + saved-payment
 * container) and signs the shopper in immediately (Amazon signup pattern).
 *
 *  - the email lands VAULT-SEALED (AES-256-GCM) with the keyed blind index
 *    as the lookup key — identical at-rest posture to the guest contacts;
 *  - the password is an Argon2id record (never reversible);
 *  - ROUND 75 — email verification is now REAL: the signup starts
 *    UNVERIFIED, a single-use 24h token is mailed (SMTP, or the dev spool
 *    artifact), and the account sheet urges confirmation. SOFT gate by
 *    design — an unverified shopper can still sign in and shop (a hard
 *    gate would lock out every signup on deployments whose mail transport
 *    is the spool); pre-ROUND-75 rows keep their verified timestamps.
 *    The response carries a `verify` hint (sent / expiresAt, plus `devLink`
 *    on dev/demo deployments only);
 *  - an EXISTING row with the same emailIndex (a prior guest order) is
 *    UPGRADED in place: the unusable random credential is replaced by the
 *    shopper's Argon2id hash and their history carries into the account —
 *    exactly like Amazon's "your guest order became your account" flow;
 *  - rate-limited per IP + origin-checked (CSRF).
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;

  const violation = originViolation(req);
  if (violation) return violation;

  const unavailable = await storeUnavailable(id);
  if (unavailable) return unavailable;

  if (await rateLimited(`register:${id}:${clientIp(req)}`, REGISTER_RULE, { failClosed: true })) {
    return tooManyRequests(REGISTER_RULE, { error: "Too many signups from this device — try again later" });
  }

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = registerSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid signup details", issues: parsed.error.flatten().fieldErrors },
      { status: 400 }
    );
  }
  const { name, email, password, phone, username } = parsed.data;


  /* ROUND L (TASK STORE-PROFILE) — resolve the final username to persist:
   *  - if the customer supplied one, NORMALIZE (lowercase) + VERIFY it is
   *    free inside this site (a friendly 409 USERNAME_TAKEN beats a raw
   *    P2002 from the unique index);
   *  - if they didn't, MINT one from the email local-part (the existing
   *    member-handle law — no behavioral change for legacy clients). */
  let resolvedUsername: string | null = null;
  if (typeof username === "string" && username.trim().length > 0) {
    const wanted = username.trim().toLowerCase();
    /* server-side re-validation (defense in depth — the zod schema already
     * enforced the shape, but a direct caller could bypass it). */
    if (!/^[a-z0-9\u0621-\u064a][a-z0-9._\-\u0621-\u064a]*[a-z0-9\u0621-\u064a]$/.test(wanted) || wanted.length < 3 || wanted.length > 30) {
      return NextResponse.json(
        { error: "Invalid username", code: "USERNAME_INVALID" },
        { status: 400 }
      );
    }
    /* uniqueness: a live row (deletedAt = null) that already owns the handle. */
    const collision = await db.siteCustomer.findFirst({
      where: { instanceId: id, username: wanted, deletedAt: null },
      select: { id: true },
    });
    if (collision) {
      return NextResponse.json(
        { error: "This username is taken — pick another", code: "USERNAME_TAKEN" },
        { status: 409 }
      );
    }
    resolvedUsername = wanted;
  } else {
    /* no choice → mint a unique one (the existing law; never throws because
     * the unique-index race is settled by suffixed retries inside the helper). */
    try {
      resolvedUsername = await mintUniqueHandle(id, email);
    } catch (error) {
      console.error(`mintUniqueHandle(${id}) failed:`, error);
      resolvedUsername = null;
    }
  }

  try {
    const emailIdx = blindIndex(email) ?? "";

    /* an existing GUEST row for this email becomes the account (upgrade in
     * place); a row with a REAL credential is an existing account — 409.
     * ROUND 87 — trashed (soft-deleted) rows are invisible here (their
     * emailIndex is mangled so the email is claimable again; the filter is
     * the hard guarantee). */
    const existing = await db.siteCustomer.findFirst({
      where: { instanceId: id, emailIndex: emailIdx, deletedAt: null },
    });
    if (existing) {
      /* guest rows carry passwordHash NULL (ROUND 120 — no KDF burn); a
       * real account has lastLoginAt set (register/login are the only
       * writers — the nullability is display-only state, the CAS below is
       * the upgrade gate). */
      if (existing.lastLoginAt) {
        return NextResponse.json(
          { error: "This email already has an account — sign in instead", code: "EMAIL_TAKEN" },
          { status: 409 }
        );
      }
      /* the upgrade is a compare-and-set on lastLoginAt: concurrent signups
       * on the same guest contact can no longer clobber each other's
       * credential (a plain read-then-update let the last password win). */
      const cas = await db.siteCustomer.updateMany({
        where: { id: existing.id, lastLoginAt: null },
        data: {
          name,
          /* new phone when given; else keep the sealed one already stored */
          phone: phone ? (encryptField(phone) ?? null) : existing.phone,
          passwordHash: hashCustomerPassword(password),
          /* ROUND 75 — a guest order proves nothing about mailbox control:
             the upgraded account starts UNVERIFIED and gets its own link. */
          emailVerifiedAt: null,
          /* ROUND L (TASK STORE-PROFILE) — set the chosen/minted username on
           * the upgraded row when one was resolved. NULL keeps the legacy
           * ensureHandle lazy-mint path intact for callers that pass none. */
          ...(resolvedUsername ? { username: resolvedUsername } : {}),
          lastLoginAt: new Date(),
        },
      });
      if (cas.count === 0) {
        /* another writer converted the guest row first — re-read and apply
         * the registered-account semantics: a real account answers exactly
         * like the branch above; a row removed by owner moderation leaves
         * the email unclaimed (the fresh-account path below applies).
         * ROUND 87 — a row trashed mid-flight also reads as unclaimed. */
        const current = await db.siteCustomer.findUnique({
          where: { id: existing.id, deletedAt: null },
          select: { lastLoginAt: true },
        });
        if (current?.lastLoginAt) {
          return NextResponse.json(
            { error: "This email already has an account — sign in instead", code: "EMAIL_TAKEN" },
            { status: 409 }
          );
        }
      } else {
        /* ROUND 87 — live rows only: a row trashed mid-flight mints NO
         * session (the email falls back to the fresh-account path). */
        const upgraded = await db.siteCustomer.findUnique({
          where: { id: existing.id, deletedAt: null },
        });
        if (upgraded) {
          await setCustomerSession(id, upgraded.id, upgraded.sessionVersion ?? 0, {
            ip: clientIp(req),
            userAgent: req.headers.get("user-agent"),
          });
          const verify = await dispatchVerification(
            id,
            upgraded.id,
            email,
            name,
            new URL(req.url).origin
          );
          return NextResponse.json(
            { account: await toAccountDTOWithHandle(upgraded), ...(verify ? { verify } : {}) },
            { status: 201 }
          );
        }
        /* the row vanished between the CAS write and the re-read (owner
         * moderation) — the email is unclaimed again; the fresh-account
         * path below applies. */
      }
    }

    const created = await db.siteCustomer.create({
      data: {
        instanceId: id,
        name,
        email: encryptField(email) ?? "",
        emailIndex: emailIdx,
        phone: encryptField(phone ?? null) ?? null,
        passwordHash: hashCustomerPassword(password),
        /* ROUND 75 — REAL verification: unverified at birth, link mailed. */
        emailVerifiedAt: null,
        /* ROUND L (TASK STORE-PROFILE) — the customer's chosen/minted handle. */
        ...(resolvedUsername ? { username: resolvedUsername } : {}),
        lastLoginAt: new Date(),
      },
    });

    await setCustomerSession(id, created.id, created.sessionVersion ?? 0, {
      ip: clientIp(req),
      userAgent: req.headers.get("user-agent"),
    });

    const verify = await dispatchVerification(
      id,
      created.id,
      email,
      name,
      new URL(req.url).origin
    );
    return NextResponse.json(
      { account: await toAccountDTOWithHandle(created), ...(verify ? { verify } : {}) },
      { status: 201 }
    );
  } catch (error) {
    /* racing twin signups: the loser of the unique-index race lands here —
     * surface the honest 409 instead of a 500. */
    if ((error as { code?: string }).code === "P2002") {
      return NextResponse.json(
        { error: "This email already has an account — sign in instead", code: "EMAIL_TAKEN" },
        { status: 409 }
      );
    }
    console.error(`register(${id}) failed:`, error);
    return NextResponse.json({ error: "Signup failed" }, { status: 500 });
  }
}

/** GET — convenience: the current session state for this store (used by the
 *  signup dialog to pre-check without 401 noise). */
export async function GET(_req: Request, { params }: RouteContext) {
  const { id } = await params;
  const state = await resolveCustomerSession(id);
  if (state.status === "valid") {
    return NextResponse.json({ signedIn: true, account: await toAccountDTOWithHandle(state.customer) });
  }
  return NextResponse.json({ signedIn: false });
}
