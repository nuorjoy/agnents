import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { zodError } from "@/lib/server/instance-mapper";
import { clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { originViolation } from "@/lib/server/origin-guard";
import { readJson } from "@/lib/server/http";
import { storeUnavailable } from "@/lib/server/customer-account";
import { isValidHandleShape } from "@/lib/server/member-handle";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * POST /api/sites/[id]/account/check-username — ROUND L (TASK STORE-PROFILE).
 *
 * The signup form + the profile's "Edit Username" card debounce-probe this
 * endpoint to render a green «متاح / Available» chip when the typed handle
 * is free, or a red «مأخوذ / Taken» chip when a live row already owns it.
 *
 * Security posture (mirrors /api/instances/check-availability):
 *  - same-origin guard (originViolation) — a mutating-method probe;
 *  - durable per-IP rate limit (30 / 10 min, FAIL-CLOSED — a probing flood
 *    must never slam the customer scan);
 *  - bounded body read + a strict Zod shape (1..30 chars);
 *  - RESPONSE = A BOOLEAN ONLY ({ available }): no enumeration data beyond
 *    the typed handle's own status — no colliding ids, no masked echoes.
 *
 * The server is the SOURCE OF TRUTH: the client chip is UX only — the
 * register / PATCH routes re-validate before persisting (race-safe).
 */
const CHECK_RULE = { limit: 30, windowMs: 10 * 60 * 1000 };

const checkSchema = z.object({
  username: z
    .string()
    .trim()
    .toLowerCase()
    .min(3, "too short")
    .max(30, "too long"),
});

export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;

  const violation = originViolation(req);
  if (violation) return violation;

  const unavailable = await storeUnavailable(id);
  if (unavailable) return unavailable;

  const ip = clientIp(req);
  if (await rateLimited(`cust-uname:${id}:${ip}`, CHECK_RULE, { failClosed: true })) {
    return tooManyRequests(CHECK_RULE, {
      error: "Too many username checks — try again later",
    });
  }

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = checkSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }

  const wanted = parsed.data.username;

  /* shape gate — the regex enforces the same handle law the register route
   * uses (start/end with a letter or digit; middle may carry . _ - and
   * Arabic letters U+0621..U+064A). An invalid shape answers available:false
   * so the chip stays red without leaking WHY (the client-side regex already
   * told the customer). */
  if (!isValidHandleShape(wanted)) {
    return NextResponse.json({ available: false, valid: false });
  }

  try {
    const collision = await db.siteCustomer.findFirst({
      where: { instanceId: id, username: wanted, deletedAt: null },
      select: { id: true },
    });
    return NextResponse.json({ available: !collision, valid: true });
  } catch (error) {
    console.error(`check-username(${id}) failed:`, error);
    return NextResponse.json(
      { error: "Failed to check username" },
      { status: 500 }
    );
  }
}
