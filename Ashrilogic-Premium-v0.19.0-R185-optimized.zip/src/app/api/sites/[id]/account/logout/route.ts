import { NextResponse } from "next/server";
import { originViolation } from "@/lib/server/origin-guard";
import { clearCustomerSession } from "@/lib/server/customer-session";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * POST /api/sites/[id]/account/logout — storefront SIGN OUT (round 65).
 *
 * Revokes the presented session's registry row ("sign out this device") and
 * clears the cookie. Idempotent: signing out while signed out is a 200.
 */
export async function POST(req: Request, { params }: RouteContext) {
  void params;
  const violation = originViolation(req);
  if (violation) return violation;
  await clearCustomerSession();
  return NextResponse.json({ ok: true });
}
