import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { originViolation } from "@/lib/server/origin-guard";
import { readJson } from "@/lib/server/http";
import { blindIndex } from "@/lib/server/crypto-vault";
import { emailSchema, storeUnavailable } from "@/lib/server/customer-account";
import {
  issueResetToken,
  orgDisplayName,
  passwordResetUrl,
  sendPasswordResetEmail,
  verifyLinkRevealEnabled,
} from "@/lib/server/verification";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/** forgot-password throttle: 5 requests / hour / source IP + site. */
const FORGOT_RULE = { limit: 5, windowMs: 60 * 60 * 1000 };

/* ROUND 86 — STRICT resend cooldown: exactly ONE request per 45 seconds per
 * IP + site (the owner's directive: «بعد ٤٥ ثانية يمكنه الطلب مرة أخرى بشكل
 * صارم»). Durable + atomic like every other rule; the 429 carries the
 * precise remaining seconds so the account page can re-arm its countdown
 * even after a refresh. */
const FORGOT_COOLDOWN_MS = 45 * 1000;
const FORGOT_COOLDOWN_RULE = { limit: 1, windowMs: FORGOT_COOLDOWN_MS };

/** Seconds left on the 45s cooldown (fail-soft: 45 = full window). */
async function forgotCooldownRemaining(key: string): Promise<number> {
  try {
    const last = await db.rateLimitHit.findFirst({
      where: { key },
      orderBy: { at: "desc" },
      select: { at: true },
    });
    if (!last) return 45;
    const left = Math.ceil((last.at.getTime() + FORGOT_COOLDOWN_MS - Date.now()) / 1000);
    return Math.min(45, Math.max(1, left));
  } catch {
    return 45;
  }
}

const forgotSchema = z.object({ email: emailSchema });

/**
 * ROUND 85 — POST /api/sites/[id]/account/forgot
 *
 * «نسيت كلمة المرور» on the dedicated account page. Always answers the
 * NEUTRAL success shape — an unknown email MUST NOT become an
 * account-existence oracle (identical response bytes; the mail dispatch
 * simply never happens):
 *
 *  200 { ok: true, sent: boolean, expiresAt } (+ devLink on dev/demo only)
 *  400 invalid email · 403 origin violation / store unavailable · 429 rate
 *  (hourly ceiling, or the ROUND 86 45-second resend cooldown — the latter
 *  answers { error: "FORGOT_COOLDOWN", retryAfterSec })
 *
 * When the address REALLY owns an account (lastLoginAt set — guest rows
 * carry no credential), a single-use 1-hour sha256-indexed token is minted
 * (rotating any outstanding one) and the bilingual reset mail goes out;
 * the link opens the ACCOUNT PAGE's reset mode, never a bare API.
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;

  const violation = originViolation(req);
  if (violation) return violation;

  const unavailable = await storeUnavailable(id);
  if (unavailable) return unavailable;

  if (await rateLimited(`forgot:${id}:${clientIp(req)}`, FORGOT_RULE, { failClosed: true })) {
    return tooManyRequests(FORGOT_RULE, { error: "Too many reset requests — try again later" });
  }

  /* ROUND 86 — the strict 45-second resend cooldown. Order matters: the
   * hourly ceiling refuses first, then the cooldown consumes its slot only
   * for requests that passed everything above (a 429 here never burns the
   * hourly budget). */
  const cooldownKey = `forgot-cool:${id}:${clientIp(req)}`;
  if (await rateLimited(cooldownKey, FORGOT_COOLDOWN_RULE, { failClosed: true })) {
    const retryAfter = await forgotCooldownRemaining(cooldownKey);
    return NextResponse.json(
      { error: "FORGOT_COOLDOWN", retryAfterSec: retryAfter },
      { status: 429, headers: { "Retry-After": String(retryAfter) } }
    );
  }

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = forgotSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid email address" }, { status: 400 });
  }
  const email = parsed.data.email;

  /* the neutral, always-identical response the client renders */
  const neutral = (sent: boolean, expiresAt: Date) =>
    NextResponse.json({
      ok: true,
      sent,
      expiresAt: expiresAt.toISOString(),
    });

  try {
    /* ROUND 87 — trashed (soft-deleted) accounts get the neutral response
     * (their emailIndex is mangled; the filter is the hard guarantee). */
    const row = await db.siteCustomer.findFirst({
      where: { instanceId: id, emailIndex: blindIndex(email) ?? undefined, deletedAt: null },
      select: { id: true, name: true, lastLoginAt: true, status: true },
    });

    /* no account (or a credential-less guest row / banned row): answer the
     * neutral success — the mail simply never goes out */
    if (!row || !row.lastLoginAt || row.status === "banned") {
      return neutral(false, new Date(Date.now() + 60 * 60 * 1000));
    }

    const orgName = await orgDisplayName(id);
    const { token, expiresAt } = await issueResetToken(row.id);
    const url = passwordResetUrl(new URL(req.url).origin, id, token);

    let sent = false;
    try {
      sent = await sendPasswordResetEmail({
        to: email,
        name: row.name,
        url,
        orgName,
      });
    } catch (error) {
      /* a mail hiccup must not 500 the request — the neutral shape still
       * tells the customer to check their inbox (best-effort transport) */
      console.error(`forgot(${id}) mail dispatch failed:`, error);
    }

    if (verifyLinkRevealEnabled()) {
      return NextResponse.json({
        ok: true,
        sent,
        expiresAt: expiresAt.toISOString(),
        devLink: url,
      });
    }
    return neutral(sent, expiresAt);
  } catch (error) {
    console.error(`forgot(${id}) failed:`, error);
    /* even the failure path keeps the neutral shape — no oracle, no panic */
    return neutral(false, new Date(Date.now() + 60 * 60 * 1000));
  }
}
