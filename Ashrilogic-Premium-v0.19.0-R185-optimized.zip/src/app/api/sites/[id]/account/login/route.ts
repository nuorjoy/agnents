import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { originViolation } from "@/lib/server/origin-guard";
import { readJson } from "@/lib/server/http";
import { blindIndex } from "@/lib/server/crypto-vault";
import {
  loginSchema,
  storeUnavailable,
  toAccountDTO,
  toAccountDTOWithHandle,
} from "@/lib/server/customer-account";
import {
  checkCustomerPassword,
  setCustomerSession,
} from "@/lib/server/customer-session";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/** login throttle: 10 attempts / 15 min / source IP + site. */
const LOGIN_RULE = { limit: 10, windowMs: 15 * 60 * 1000 };

/** per-account throttle: 50 attempts / 15 min / email + site — the high
 *  ceiling bounds distributed-IP brute force on ONE victim account without
 *  drifting into lockout-DoS range for a mailbox's legitimate shoppers. */
const LOGIN_EMAIL_RULE = { limit: 50, windowMs: 15 * 60 * 1000 };

/**
 * POST /api/sites/[id]/account/login — storefront SIGN IN (round 65).
 *
 *  - lookup by the keyed blind index (the sealed email is never the WHERE
 *    key — PII stays out of the query plan);
 *  - Argon2id verification with transparent legacy-digest upgrade;
 *  - banned rows are refused (the owner's Customers moderation);
 *  - a matching GUEST row (no real credential — created by a guest order
 *    with this email) cannot sign in: 409 with a "sign up" hint, because
 *    the row has no password to check (its credential is random junk);
 *  - rate-limited per IP + origin-checked (CSRF); a successful login
 *    refreshes lastLoginAt (which also flips future guest→account
 *    upgrade checks).
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;

  const violation = originViolation(req);
  if (violation) return violation;

  const unavailable = await storeUnavailable(id);
  if (unavailable) return unavailable;

  if (await rateLimited(`login:${id}:${clientIp(req)}`, LOGIN_RULE, { failClosed: true })) {
    return tooManyRequests(LOGIN_RULE, { error: "Too many attempts — try again in a few minutes" });
  }

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = loginSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid sign-in details" }, { status: 400 });
  }
  const { email, password } = parsed.data;

  /* per-EMAIL throttle alongside the per-IP rule: a fresh IP per attempt
   * must still hit a ceiling on a single victim account. The key is the
   * blind index (the durable limiter table carries no PII); the uniform
   * 429 is identical to the IP rule's — never an account-existence
   * oracle. Runs after shape validation so only well-formed emails are
   * keyed. */
  const emailIdx = blindIndex(email) ?? undefined;
  if (
    emailIdx &&
    (await rateLimited(`cust-login-email:${id}:${emailIdx}`, LOGIN_EMAIL_RULE, {
      failClosed: true,
    }))
  ) {
    return tooManyRequests(LOGIN_EMAIL_RULE, { error: "Too many attempts — try again in a few minutes" });
  }

  try {
    /* ROUND 87 — trashed (soft-deleted) customer accounts never sign in
     * (the trash engine mangles their emailIndex; the filter is the hard
     * guarantee — uniform 401, no oracle). */
    const row = await db.siteCustomer.findFirst({
      where: { instanceId: id, emailIndex: emailIdx, deletedAt: null },
    });

    /* uniform failure — no account-existence oracle for strangers */
    if (!row) {
      return NextResponse.json({ error: "Incorrect email or password" }, { status: 401 });
    }
    if (row.status === "banned") {
      return NextResponse.json(
        { error: "This account is suspended", code: "BANNED" },
        { status: 403 }
      );
    }
    /* guest rows hold unusable random credentials — the shopper must sign
     * UP (the register route upgrades the row in place) */
    if (!row.lastLoginAt) {
      return NextResponse.json(
        {
          error: "No account uses this email yet — create one in seconds",
          code: "NO_ACCOUNT",
        },
        { status: 409 }
      );
    }

    const check = checkCustomerPassword(password, row.passwordHash);
    if (!check.ok) {
      return NextResponse.json({ error: "Incorrect email or password" }, { status: 401 });
    }

    const data: Record<string, unknown> = { lastLoginAt: new Date() };
    if (check.upgraded && check.hash) data.passwordHash = check.hash;

    const fresh = await db.siteCustomer.update({ where: { id: row.id }, data });

    await setCustomerSession(id, fresh.id, fresh.sessionVersion ?? 0, {
      ip: clientIp(req),
      userAgent: req.headers.get("user-agent"),
    });

    return NextResponse.json({ account: await toAccountDTOWithHandle(fresh) });
  } catch (error) {
    console.error(`login(${id}) failed:`, error);
    return NextResponse.json({ error: "Sign-in failed" }, { status: 500 });
  }
}
