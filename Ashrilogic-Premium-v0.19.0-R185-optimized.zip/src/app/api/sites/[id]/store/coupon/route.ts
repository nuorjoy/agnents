import { couponValidate } from "@/server/domains/store/controller";

export const dynamic = "force-dynamic";

/**
 * POST /api/sites/[id]/store/coupon — validate a coupon code against the
 * CURRENT cart (public storefront, guest checkout).
 *
 * SECURITY:
 *  - rate limited per IP + site (enumeration resistance);
 *  - the store must be published and the workspace not trial-locked;
 *  - the subtotal is client-supplied for PREVIEW only — the authoritative
 *    discount is recomputed inside the placement transaction from
 *    server-derived item prices (see /api/sites/[id]/orders POST).
 *
 * ROUND 126 — the handler moved to the store domain
 * (src/server/domains/store): this file is the thin route delegation.
 */
export const POST = couponValidate;
