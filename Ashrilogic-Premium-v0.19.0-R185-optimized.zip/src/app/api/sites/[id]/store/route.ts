import { catalogGet } from "@/server/domains/store/controller";

export const dynamic = "force-dynamic";

/**
 * GET /api/sites/[id]/store — the PUBLIC storefront catalog (round 36).
 *
 * Serves the purchasable items derived from the workspace's catalog module
 * (pharmacy / inventory / products / menu) for PUBLISHED sites only:
 *  - prices are parsed server-side from module records (client never sets
 *    them — orders re-verify against these);
 *  - out-of-stock / expired rows are excluded;
 *  - search (?q=) and category (?category=) run server-side over the mapped
 *    products (sealed-free public data, bounded at 200 rows).
 *
 * ROUND 126 — the handler moved to the store domain
 * (src/server/domains/store): this file is the thin route delegation.
 */
export const GET = catalogGet;
