import { reviewsList, reviewsSubmit } from "@/server/domains/store/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 63 — storefront product reviews (public).
 *
 * GET  /api/sites/[id]/store/reviews?recordId=&cursor= — one product's
 *      VISIBLE reviews, newest first, KEYSET-paginated (same opaque-cursor
 *      contract as the orders/activities feeds) + the recomputed visible-
 *      only rating summary (mean, count, exact per-star histogram).
 *
 * POST /api/sites/[id]/store/reviews — guest submission (no account, no
 *      session — mirroring guest checkout). Security posture:
 *       - same-origin guard first (mutating method);
 *       - durable rate limit: 8 reviews / hour per source IP + site;
 *       - bounded body + Zod validation (rating 1–5, name 2–60, body ≤500);
 *       - gates: PUBLISHED site on a live trial, and the target recordId
 *         must be a product the storefront actually lists (sellable rows
 *         only — no reviews for unreleased/hidden items);
 *       - one review per visitor per product: the keyed blind index of the
 *         client IP (never raw PII) upserts the row — a re-submission
 *         UPDATES rating/name/body and never resets the moderation state;
 *       - the public DTO never carries authorIndex/hidden.
 *
 * ROUND 126 — the handlers moved to the store domain
 * (src/server/domains/store): this file is the thin route delegation.
 */
export const GET = reviewsList;
export const POST = reviewsSubmit;
