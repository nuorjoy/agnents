import { orderTrack } from "@/server/domains/orders/controller";

export const dynamic = "force-dynamic";

/**
 * POST /api/sites/[id]/orders/track — follow an order by tracking code +
 * the phone number used when placing it (public, no account).
 *
 * SECURITY (enforced by the domain, see src/server/domains/orders):
 *  - origin gate, the body schema and the per-IP+site lookup throttle —
 *    all declared in the controller's guard plan (an INVALID body never
 *    burns a throttle hit);
 *  - the lookup key is the keyed BLIND INDEX of the normalized phone —
 *    raw phone digits never touch the query layer;
 *  - both the code AND the phone index must match — a valid code alone is
 *    a plain 404 (no existence oracle);
 *  - the response carries NO customer PII: items (name + qty), totals,
 *    status timeline, timestamps only;
 *  - the response mints the ROUND-119 MAC-sealed receipt token (30-day,
 *    this-site binding) for the printable receipt page.
 *
 * ROUND 128 — the handler moved to the orders domain
 * (src/server/domains/orders): this file is the thin route delegation.
 */
export const POST = orderTrack;
