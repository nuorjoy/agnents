import { orderPlace } from "@/server/domains/orders/controller";

export const dynamic = "force-dynamic";

/**
 * POST /api/sites/[id]/orders — place a storefront order (GUEST checkout,
 * ROUND 44: the member-login process was removed from the public website —
 * orders no longer require or accept a customer session).
 *
 * SECURITY (enforced by the domain, see src/server/domains/orders):
 *  - origin gate + the ROUND-96 maintenance window, the body schema and
 *    the per-IP+site throttle — all declared in the controller's guard
 *    plan (an INVALID body never burns a throttle hit);
 *  - item prices are re-derived SERVER-SIDE from the module records at
 *    placement time — the client only sends record ids + quantities;
 *  - the whole placement runs in ONE transaction with per-row
 *    compare-and-swap stock decrements — no oversell, no lost updates;
 *  - totals are computed in INTEGER MINOR UNITS end-to-end;
 *  - the guest contact is resolved server-side (find-or-create by the
 *    keyed email blind index when an email is given); a BANNED contact
 *    still cannot order;
 *  - Idempotency-Key: exactly-once placement (replay / 409 / 422
 *    semantics — the guard row is written inside the placement
 *    transaction; a crash rolls both back);
 *  - ROUND 120 — the OrderReservation + CouponRedemption ledgers are
 *    written in the same transaction (module-drift-proof stock release +
 *    coupon-identity release on cancellation).
 *
 * ROUND 128 — the handler moved to the orders domain
 * (src/server/domains/orders): this file is the thin route delegation.
 */
export const POST = orderPlace;

/* ROUND 44 — the customer-facing GET ("my orders") was removed together with
 * the member-login process: without site sessions there is no "me" to list
 * orders for. The OWNER-side order queue lives at
 * /api/instances/[id]/orders (unchanged). */
