import { NextResponse } from "next/server";
import { computeEntitlement } from "@/lib/server/entitlement";

import { db } from "@/lib/db";
import { clientIp, rateLimited } from "@/lib/server/rate-limit";
import { originViolation } from "@/lib/server/origin-guard";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/* gentle public counter — one visit per browser tab per hour */
const VISIT_RULE = { limit: 20, windowMs: 60 * 60 * 1000 };

/**
 * POST /api/sites/[id]/visit — public visit counter for a PUBLISHED site
 * (the page view pings this once per session). Drafts never count. The
 * counter is intentionally best-effort and rate-limited per IP.
 */
export async function POST(_req: Request, { params }: RouteContext) {
  const { id } = await params;

  /* same-origin guard (public-mutation contract): a cross-site page must
     not drive the visit counter — it is a documented exemption from the
     SESSION guards, never from the origin check itself */
  const violation = originViolation(_req);
  if (violation) return NextResponse.json({ ok: true, views: null }, { status: 403 });

  if (await rateLimited(`site-visit:${id}:${clientIp(_req)}`, VISIT_RULE)) {
    return NextResponse.json({ ok: true, views: null }, { status: 200 });
  }

  try {
    /* ROUND 47 — trial stop: stopped sites count no visits (silent no-op). */
    const site = await db.site.findUnique({
      where: { instanceId: id },
      select: {
        published: true,
        views: true,
        instance: { select: { packageId: true, trialEndsAt: true, planExpiresAt: true, featureOverridesJson: true, bannedPermanently: true, bannedUntil: true, package: { select: { capabilitiesJson: true, nameAr: true, nameEn: true } } } },
      },
    });
    const ent = site ? computeEntitlement(site.instance) : null;
    /* ROUND 79 — feature-aware: the surface stops when the workspace is
     * locked OR the plan does not include the "publicWebsite" feature. */
    const stopped = !ent || ent.state === "locked" || ent.features.publicWebsite !== true;
    if (!site || !site.published || stopped) {
      // unpublished / missing / stopped → silently no-op (never a client error)
      return NextResponse.json({ ok: true, views: null }, { status: 200 });
    }
    const row = await db.site.update({
      where: { instanceId: id },
      data: { views: { increment: 1 } },
      select: { views: true },
    });
    return NextResponse.json({ ok: true, views: row.views });
  } catch (error) {
    console.error(`POST /api/sites/${id}/visit failed:`, error);
    return NextResponse.json({ ok: true, views: null }, { status: 200 });
  }
}
