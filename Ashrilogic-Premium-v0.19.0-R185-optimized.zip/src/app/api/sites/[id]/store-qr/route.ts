import { NextResponse } from "next/server";
import QRCode from "qrcode";
import { db } from "@/lib/db";
import { computeEntitlement } from "@/lib/server/entitlement";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * GET /api/sites/[id]/store-qr — a QR code that opens the PUBLIC storefront.
 *
 * ROUND 60 — storefront share card. Public, read-only, SVG (tiny, crisp at
 * any size, zero client bundle cost — the `qrcode` package never ships to
 * the browser). The encoded URL is derived SERVER-SIDE from the instance id
 * + the request's own host/proto — the caller never supplies the payload,
 * so the endpoint can never be abused to mint QR codes for arbitrary URLs.
 *
 * Gating mirrors /api/sites/[id]/store exactly: published sites of
 * non-locked workspaces only. Rate-limited per IP (durable limiter).
 */
const QR_RULE = { limit: 30, windowMs: 60_000 };

/** Effective public host (same trust chain as webauthn.ts / origin-guard). */
function effectiveHost(req: Request): string {
  const forwarded = req.headers.get("x-forwarded-host");
  if (forwarded) {
    const first = forwarded.split(",")[0]?.trim();
    const host = first?.split(":")[0];
    if (host) return host;
  }
  try {
    return new URL(req.url).host.split(":")[0] ?? "localhost";
  } catch {
    return "localhost";
  }
}

/** Effective scheme — forwarded proto wins (the proxy terminates TLS). */
function effectiveProtocol(req: Request): "https" | "http" {
  const proto = req.headers.get("x-forwarded-proto")?.split(",")[0]?.trim();
  if (proto === "https" || proto === "http") return proto;
  try {
    return new URL(req.url).protocol === "https:" ? "https" : "http";
  } catch {
    return "http";
  }
}

/**
 * The storefront URL as THIS VISITOR addresses it. When the browser-declared
 * Origin/Referer host matches the effective host (browser-set, not forgeable
 * cross-site — the same trust chain the WebAuthn origin set uses), its full
 * origin wins: it carries the exact scheme the visitor is on even when the
 * gateway stamps X-Forwarded-Proto with its own listener's scheme.
 */
function storefrontUrl(req: Request, id: string): string {
  const host = effectiveHost(req);
  const declared = req.headers.get("origin") ?? req.headers.get("referer");
  if (declared) {
    try {
      const u = new URL(declared);
      if (u.host.split(":")[0] === host && (u.protocol === "https:" || u.protocol === "http:")) {
        return `${u.origin}/sites/${id}/store`;
      }
    } catch {
      /* malformed header — fall through to the computed origin */
    }
  }
  return `${effectiveProtocol(req)}://${host}/sites/${id}/store`;
}

export async function GET(req: Request, { params }: RouteContext) {
  const { id } = await params;

  if (await rateLimited(`store-qr:${clientIp(req)}`, QR_RULE)) {
    return tooManyRequests(QR_RULE, { error: "Too many requests" });
  }

  try {
    /* the same availability rule as the public store catalog */
    const site = await db.site.findUnique({
      where: { instanceId: id },
      select: { published: true, instance: { select: { packageId: true, trialEndsAt: true, planExpiresAt: true, featureOverridesJson: true, bannedPermanently: true, bannedUntil: true, package: { select: { capabilitiesJson: true, nameAr: true, nameEn: true } } } } },
    });
    const ent = site ? computeEntitlement(site.instance) : null;
    /* ROUND 79 — feature-aware: the surface stops when the workspace is
     * locked OR the plan does not include the "store" feature. */
    const stopped = !ent || ent.state === "locked" || ent.features.store !== true;
    if (!site || !site.published || stopped) {
      return NextResponse.json({ error: "Store not available" }, { status: 404 });
    }

    const url = storefrontUrl(req, id);
    const svg = await QRCode.toString(url, {
      type: "svg",
      margin: 1,
      width: 360,
      errorCorrectionLevel: "M",
      color: { dark: "#0f172a", light: "#ffffff" },
    });

    return new NextResponse(svg, {
      status: 200,
      headers: {
        "content-type": "image/svg+xml; charset=utf-8",
        /* the QR is stable per instance — let browsers/CDNs cache it */
        "cache-control": "public, max-age=300",
        "x-content-type-options": "nosniff",
      },
    });
  } catch {
    return NextResponse.json({ error: "QR unavailable" }, { status: 500 });
  }
}
