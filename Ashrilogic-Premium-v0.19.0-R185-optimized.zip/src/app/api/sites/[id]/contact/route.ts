import { NextResponse } from "next/server";
import { computeEntitlement } from "@/lib/server/entitlement";

import { db } from "@/lib/db";
import { toTicketDTO } from "@/lib/server/admin-mapper";
import { zodError } from "@/lib/server/instance-mapper";
import { siteContactSchema } from "@/lib/server/site-mapper";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { blindIndex, encryptField } from "@/lib/server/crypto-vault";
import { originViolation } from "@/lib/server/origin-guard";
import { maintenanceBlock } from "@/lib/server/maintenance";
import { readJson } from "@/lib/server/http";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/** Max public inquiries per IP inside the window. */
const RATE_RULE = { limit: 5, windowMs: 60 * 60 * 1000 };

/**
 * POST /api/sites/[id]/contact — public inquiry form on a PUBLISHED site.
 * Inquiries land in the admin support inbox as tickets LINKED to the system
 * (instanceId + source "public"), closing the loop between the public
 * website and the workspace it belongs to. Drafts accept nothing.
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;

  /* ROUND 37 (task 3-a) — same-origin guard first (public-form CSRF) */
  const violation = originViolation(req);
  if (violation) return violation;

  /* ROUND 96 — maintenance window: an inquiry filed while a restore of
   * THIS tenant is in flight lands on the tenant's ticket linkage that the
   * restore transaction is rebuilding. Fail fast with 503 instead. */
  const maintenance = await maintenanceBlock(id, req);
  if (maintenance) return maintenance;

  /* ROUND 49 — rate limit BEFORE the bounded body read (guard-first, like
     every authenticated mutation) so invalid payloads still consume the
     caller's budget. */
  const ip = clientIp(req);
  if (await rateLimited(`site-contact:${id}:${ip}`, RATE_RULE)) {
    return tooManyRequests(RATE_RULE, { error: "Too many messages submitted, please try again later" });
  }

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = siteContactSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }

  try {
    /* ROUND 47 — trial stop: no contact channel for a stopped site.
     * ROUND 87 — a trashed (soft-deleted) workspace has no contact channel. */
    const instance = await db.instance.findUnique({
      where: { id, deletedAt: null },
      select: {
        id: true,
        systemId: true,
        orgJson: true,
        packageId: true,
        trialEndsAt: true,
        /* ROUND 79 — feature-aware public presence */
        planExpiresAt: true,
        featureOverridesJson: true,
        /* ROUND 81 — platform ban (public presence held while active) */
        bannedPermanently: true,
        bannedUntil: true,
        package: { select: { capabilitiesJson: true, nameAr: true, nameEn: true } },
        site: { select: { published: true } },
      },
    });
    const ent = instance ? computeEntitlement(instance) : null;
    /* ROUND 79 — feature-aware: contact submits need the public-website feature */
    const stopped = !ent || ent.state === "locked" || ent.features.publicWebsite !== true;
    if (!instance || !instance.site?.published || stopped) {
      return NextResponse.json({ error: "Site not found" }, { status: 404 });
    }
    let orgName = "";
    try {
      const org = JSON.parse(instance.orgJson) as { name?: string };
      orgName = org.name ?? "";
    } catch {
      // corrupt orgJson — fall back to the system id for the subject
    }

    const row = await db.supportTicket.create({
      data: {
        subject: `استفسار من الموقع العام — ${orgName || instance.systemId}`,
        message: parsed.data.message,
        requesterName: parsed.data.name,
        /* round 35 — sealed at rest + blind-indexed */
        requesterEmail: encryptField(parsed.data.email) ?? "",
        requesterEmailIndex: blindIndex(parsed.data.email) ?? "",
        category: "general",
        priority: "medium",
        status: "open",
        instanceId: instance.id,
        source: "public",
      },
    });

    /* ROUND 141 (owner notifications, directive ㉜) — a public-website
     * inquiry rides the workspace activity feed (zero-delay bell). */
    try {
      await db.activity.create({
        data: { instanceId: instance.id, kind: "actInquiryReceived" },
      });
    } catch {
      /* best-effort feed — never blocks the inquiry */
    }
    await logAudit({
      actorType: "public",
      actorName: maskEmail(parsed.data.email),
      action: "ticket.create",
      targetLabel: `site:${orgName || instance.systemId}`,
      meta: { channel: "public-website" },
    });
    return NextResponse.json(toTicketDTO(row), { status: 201 });
  } catch (error) {
    console.error(`POST /api/sites/${id}/contact failed:`, error);
    return NextResponse.json({ error: "Failed to send message" }, { status: 500 });
  }
}
