import { NextResponse } from "next/server";
import QRCode from "qrcode";
import { clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { verifyReceiptToken } from "@/lib/server/receipt-token";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * GET /api/sites/[id]/receipt-qr?token=… — ROUND 121 — a QR code that
 * opens the STANDALONE RECEIPT PAGE (/sites/[id]/receipt?token=…).
 *
 * Same discipline as /api/sites/[id]/store-qr (ROUND 60): the QR payload
 * is derived SERVER-SIDE, the `qrcode` package never ships to the
 * browser, the response is a tiny crisp SVG. The difference: the receipt
 * link is a BEARER CAPABILITY (the MAC-sealed token the caller earned by
 * proving code + phone at tracking time), so the endpoint's contract is:
 *
 *   - the token is VERIFIED (MAC + expiry + THIS site's id from the
 *     claims) before anything is minted — a garbage, expired, or
 *     cross-site token is a plain 404, and the endpoint can therefore
 *     only ever mint QRs for valid receipt links on THIS site (never an
 *     arbitrary-URL QR oracle);
 *   - no additional availability gate: the token itself is the
 *     capability; the receipt page re-checks everything at render (the
 *     page is the authority — the QR merely encodes its URL);
 *   - cache-control is PRIVATE (the URL embeds a bearer token — no
 *     shared-cache copies), 5 minutes (the QR is stable for the token's
 *     lifetime, but the conservative header wins);
 *   - rate-limited per IP (durable limiter) like the store QR.
 */
const QR_RULE = { limit: 30, windowMs: 60_000 };

/** Effective public host (same trust chain as store-qr / webauthn.ts). */
function effectiveHost(req: Request): string {
  const forwarded = req.headers.get("x-forwarded-host");
  if (forwarded) {
    const first = forwarded.split(",")[0]?.trim();
    const host = first?.split(":")[0];
    if (host) return host;
  }
  try {
    return new URL(req.url).host.split(":")[0] ?? "localhost";
  } catch {
    return "localhost";
  }
}

/** Effective scheme — forwarded proto wins (the proxy terminates TLS). */
function effectiveProtocol(req: Request): "https" | "http" {
  const proto = req.headers.get("x-forwarded-proto")?.split(",")[0]?.trim();
  if (proto === "https" || proto === "http") return proto;
  try {
    return new URL(req.url).protocol === "https:" ? "https" : "http";
  } catch {
    return "http";
  }
}

/** The receipt-page URL as THIS VISITOR addresses it (same declared-origin
 *  preference as store-qr: the browser-set origin wins when it matches the
 *  effective host — it carries the visitor's exact scheme). */
function receiptUrl(req: Request, id: string, token: string): string {
  const host = effectiveHost(req);
  const declared = req.headers.get("origin") ?? req.headers.get("referer");
  const path = `/sites/${id}/receipt?token=${encodeURIComponent(token)}`;
  if (declared) {
    try {
      const u = new URL(declared);
      if (u.host.split(":")[0] === host && (u.protocol === "https:" || u.protocol === "http:")) {
        return `${u.origin}${path}`;
      }
    } catch {
      /* malformed header — fall through to the computed origin */
    }
  }
  return `${effectiveProtocol(req)}://${host}${path}`;
}

export async function GET(req: Request, { params }: RouteContext) {
  const { id } = await params;

  if (await rateLimited(`receipt-qr:${clientIp(req)}`, QR_RULE)) {
    return tooManyRequests(QR_RULE, { error: "Too many requests" });
  }

  try {
    const token = new URL(req.url).searchParams.get("token") ?? "";
    /* the capability gate: a valid, unexpired, THIS-site token — the QR
     * mints nothing for anything else (no oracle, no arbitrary URLs) */
    const claims = verifyReceiptToken(token);
    if (!claims || claims.instanceId !== id) {
      return NextResponse.json({ error: "Receipt not available" }, { status: 404 });
    }

    const url = receiptUrl(req, id, token);
    const svg = await QRCode.toString(url, {
      type: "svg",
      margin: 1,
      width: 360,
      errorCorrectionLevel: "M",
      color: { dark: "#0f172a", light: "#ffffff" },
    });

    return new NextResponse(svg, {
      status: 200,
      headers: {
        "content-type": "image/svg+xml; charset=utf-8",
        /* PRIVATE: the URL embeds a bearer token — never a shared cache */
        "cache-control": "private, max-age=300",
        "x-content-type-options": "nosniff",
      },
    });
  } catch {
    return NextResponse.json({ error: "QR unavailable" }, { status: 500 });
  }
}
