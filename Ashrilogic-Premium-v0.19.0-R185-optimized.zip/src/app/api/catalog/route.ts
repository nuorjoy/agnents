import { NextResponse } from "next/server";
import { CATALOG } from "@/data/catalog";

/**
 * GET /api/catalog — static bundled catalog (categories/modules/systems).
 * Immutable data, no DB roundtrip.
 *
 * Internal system codes (the numeric `code` field / SYS-xxx labels) are
 * STRICTLY stripped from the public response — codes are a control-panel
 * affordance only and must never be exposed publicly in any form.
 */
export async function GET() {
  return NextResponse.json(
    {
      categories: CATALOG.categories,
      modules: CATALOG.modules,
      systems: CATALOG.systems.map(({ code: _code, ...publicFields }) => publicFields),
    },
    { headers: { "Cache-Control": "public, max-age=3600" } }
  );
}
