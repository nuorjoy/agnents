import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { seedAdminDefaults, toTicketDTO } from "@/lib/server/admin-mapper";
import { zodError } from "@/lib/server/instance-mapper";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { blindIndex, encryptField } from "@/lib/server/crypto-vault";
import { originViolation } from "@/lib/server/origin-guard";
import { readJson } from "@/lib/server/http";
import { resolvePublicSocialLinks } from "@/lib/social";

export const dynamic = "force-dynamic";

/** Fallback contact channels when the settings row is somehow unreadable. */
const DEFAULT_CONTACT = { supportEmail: "support@ashrilogic.com", supportPhone: "+249912179779" };

/**
 * GET /api/support — public support contact channels + the dashboard-
 * controlled social links (consumed by the landing footer and the error
 * pages, so both always mirror the control panel state). Reads the
 * PlatformSetting singleton (seeded on first read).
 */
export async function GET() {
  try {
    await seedAdminDefaults(db);
    const row = await db.platformSetting.findUnique({ where: { id: "global" } });
    if (!row) return NextResponse.json({ ...DEFAULT_CONTACT, socialLinks: resolvePublicSocialLinks([]) });
    return NextResponse.json({
      supportEmail: row.supportEmail,
      supportPhone: row.supportPhone,
      socialLinks: resolvePublicSocialLinks(
        row.socialJson ? (JSON.parse(row.socialJson) as { icon: string; href: string; enabled: boolean }[]) : []
      ),
    });
  } catch (error) {
    console.error("GET /api/support failed:", error);
    return NextResponse.json(
      { ...DEFAULT_CONTACT, socialLinks: resolvePublicSocialLinks([]) },
      { status: 200 }
    );
  }
}

/* ------------------------------------------------------------------ */
/* Public ticket submission (local schema — independent of admin)     */
/* ------------------------------------------------------------------ */

const publicTicketSchema = z.object({
  name: z.string().min(2).max(80),
  email: z.email().max(254),
  category: z.enum(["technical", "billing", "general", "feature"]),
  subject: z.string().min(3).max(120),
  message: z.string().min(10).max(2000),
});

/** Max public submissions per IP inside the window. */
const RATE_RULE = { limit: 5, windowMs: 10 * 60 * 1000 };

/**
 * ROUND 36 — server-side org-name enrichment for the forgot-password flow:
 * when the requester name equals the requester email (the login page's
 * forgot form), the workspace owning that email contributes its org name to
 * the ticket so the admin inbox carries the precise context WITHOUT any
 * public directory exposure. Runs entirely server-side — nothing about the
 * match is revealed to the caller.
 */
async function resolveRequesterName(
  name: string,
  email: string
): Promise<string> {
  if (name.trim().toLowerCase() !== email.trim().toLowerCase()) return name;
  try {
    /* ROUND 87 — trashed (soft-deleted) workspaces contribute no org-name
     * enrichment (blind-index lookup filters them). */
    const row = await db.instance.findFirst({
      where: { adminEmailIndex: blindIndex(email) ?? "", deletedAt: null },
      select: { orgJson: true },
    });
    if (!row) return name;
    const org = JSON.parse(row.orgJson ?? "{}") as { name?: string };
    return org.name?.trim() || name;
  } catch {
    return name; /* enrichment is best-effort — the ticket is still filed */
  }
}

/**
 * POST /api/support — submit a support ticket from the public landing form.
 * Validates the body, applies an in-memory per-IP rate limit, then creates
 * an open medium-priority ticket in the admin support inbox.
 */
export async function POST(req: Request) {
  /* ROUND 37 (task 3-a) — same-origin guard first (public-form CSRF) */
  const violation = originViolation(req);
  if (violation) return violation;

  /* ROUND 49 — rate limit BEFORE the bounded body read (guard-first) so
     anonymous scanners cannot burn capped JSON parses for free. */
  const ip = clientIp(req);
  if (await rateLimited(`support:${ip}`, RATE_RULE)) {
    return tooManyRequests(RATE_RULE, { error: "Too many tickets submitted, please try again later" });
  }

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = publicTicketSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }

  try {
    const requesterName = await resolveRequesterName(parsed.data.name, parsed.data.email);
    const row = await db.supportTicket.create({
      data: {
        subject: parsed.data.subject,
        message: parsed.data.message,
        requesterName,
        /* round 35 — sealed at rest + blind-indexed */
        requesterEmail: encryptField(parsed.data.email) ?? "",
        requesterEmailIndex: blindIndex(parsed.data.email) ?? "",
        category: parsed.data.category,
        priority: "medium",
        status: "open",
        instanceId: null,
        source: "public",
      },
    });
    await logAudit({
      actorType: "public",
      actorName: maskEmail(parsed.data.email),
      action: "ticket.create",
      targetLabel: parsed.data.subject.slice(0, 120),
    });
    return NextResponse.json(toTicketDTO(row), { status: 201 });
  } catch (error) {
    console.error("POST /api/support failed:", error);
    return NextResponse.json({ error: "Failed to submit ticket" }, { status: 500 });
  }
}
