import { NextResponse } from "next/server";
import { onlineAdminCount } from "@/lib/server/presence";
import { clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";

export const dynamic = "force-dynamic";

/**
 * GET /api/support/presence — ROUND 172 (public support availability).
 *
 * The PUBLIC premium indicator («فريق الدعم متصل الآن») on the landing
 * support band. Exposes the COUNT of online platform admins ONLY — never
 * identities, never usernames (privacy law of the presence module).
 *
 * Rate-limited per IP (the landing fetches it once per visit; the system
 * dashboards use their own authenticated heartbeat instead) and memoized
 * for 30s in-process so a burst of landing visits costs ONE grouped query.
 */
const RATE_RULE = { limit: 30, windowMs: 10 * 60 * 1000 };

/** In-process memo — 30s. */
let memo: { value: number; at: number } | null = null;
const MEMO_MS = 30_000;

export async function GET(req: Request) {
  const ip = clientIp(req);
  if (await rateLimited(`support-presence:${ip}`, RATE_RULE)) {
    return tooManyRequests(RATE_RULE);
  }
  try {
    const now = Date.now();
    if (!memo || now - memo.at > MEMO_MS) {
      memo = { value: await onlineAdminCount(), at: now };
    }
    return NextResponse.json(
      { onlineAdmins: memo.value, serverTime: new Date().toISOString() },
      { headers: { "Cache-Control": "no-store" } }
    );
  } catch (error) {
    console.error("GET /api/support/presence failed:", error);
    /* degrade closed: "no one online" is a safe, non-blocking answer for
       a marketing indicator — never a 500 that could take the band down. */
    return NextResponse.json({ onlineAdmins: 0, serverTime: new Date().toISOString() });
  }
}
