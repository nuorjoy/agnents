import { NextResponse } from "next/server";
import { loadBlogFeedPage, normalizeBlogFeedParams } from "@/lib/server/blog-feed";

export const dynamic = "force-dynamic";

/**
 * GET /api/blog — the PUBLIC blog feed.
 *
 *  - only PUBLISHED posts with a publishedAt stamp, newest first;
 *  - `?page=1&pageSize=9` paginated (pageSize capped at 24);
 *  - `?tag=growth` filters on the tagsJson JSON array;
 *  - `?q=` (ROUND 175) free-text search over title/excerpt in BOTH content
 *    languages (server-side, case-insensitive);
 *  - `tags` in the response lists every distinct tag across PUBLISHED posts so
 *    the public filter chips reflect real content, never a hardcoded list.
 *
 * The queries live in the shared server layer (src/lib/server/blog-feed.ts)
 * so this route and the server-rendered /blog page can never drift apart;
 * the distinct-tag facet is TTL-cached there (the previous full-table
 * scan + JS parse ran on every request — see that module for the cache
 * contract).
 *
 * Fail-open by design (same posture as /api/testimonials): any error answers
 * an empty page so the marketing site never breaks on a DB hiccup.
 */
export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const { page, pageSize, tag } = normalizeBlogFeedParams(
      Number.parseInt(url.searchParams.get("page") ?? "1", 10),
      Number.parseInt(url.searchParams.get("pageSize") ?? "9", 10),
      url.searchParams.get("tag") ?? ""
    );
    const q = url.searchParams.get("q") ?? "";
    const feed = await loadBlogFeedPage(page, pageSize, tag, q);
    return NextResponse.json(feed);
  } catch (error) {
    console.error("GET /api/blog failed:", error);
    return NextResponse.json(
      { rows: [], total: 0, page: 1, pageSize: 9, tags: [], tagFacets: [], totalPublished: 0, totalReadMinutes: 0 },
      { status: 200 }
    );
  }
}
