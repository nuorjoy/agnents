import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { looksLikeBot, loadBlogArticle } from "@/lib/server/blog-feed";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ slug: string }> };

/**
 * GET /api/blog/[slug] — one PUBLISHED article + its related posts.
 *
 *  - drafts never serve publicly (404 even though the row exists);
 *  - the view counter increments best-effort on every HUMAN read (a failed
 *    bump must not block the article itself); JS-less crawlers and link
 *    previewers (bot user agents) are skipped so ambient bot traffic no
 *    longer inflates the public counter — the article data itself is
 *    still served to them;
 *  - related = up to 3 published posts sharing at least one tag (newest
 *    first), falling back to the 3 newest posts when the article is untagged
 *    or nothing overlaps.
 *
 * The article/related queries live in the shared server layer
 * (src/lib/server/blog-feed.ts) so this route and the server-rendered
 * /blog/[slug] page (which passes the same payload as initialData) can
 * never drift apart.
 */
export async function GET(req: Request, ctx: RouteContext) {
  const { slug } = await ctx.params;
  const clean = slug.trim().slice(0, 96).toLowerCase();

  try {
    const article = await loadBlogArticle(clean);
    if (!article) {
      return NextResponse.json({ error: "Article not found" }, { status: 404 });
    }
    const post = article.post;

    /* best-effort view bump — never blocks the read; skipped for bot user
     * agents (see looksLikeBot: crawlers, previewers, monitoring agents
     * never render the app, so they must not count as reads) */
    if (!looksLikeBot(req.headers.get("user-agent"))) {
      void db.blogPost
        .update({ where: { id: post.id }, data: { views: { increment: 1 } } })
        .catch(() => undefined);
    }

    /* ROUND 179 — prev/next chronological neighbours ride the same payload
     * (loadBlogArticle now computes them with the related posts) so the
     * reader navigation is live for the client revalidation too. */
    return NextResponse.json({
      ...post,
      related: article.related,
      prev: article.prev,
      next: article.next,
    });
  } catch (error) {
    console.error("GET /api/blog/[slug] failed:", error);
    return NextResponse.json({ error: "Failed to load article" }, { status: 500 });
  }
}
