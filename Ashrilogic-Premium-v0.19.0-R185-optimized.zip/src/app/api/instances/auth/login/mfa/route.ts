import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toInstanceDTO } from "@/lib/server/instance-mapper";
import {
  setInstanceSession,
  verifyInstanceMfaTicket,
} from "@/lib/server/instance-session";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { originViolation } from "@/lib/server/origin-guard";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { verifyMfaLogin } from "@/lib/server/mfa";

export const dynamic = "force-dynamic";

/** Second-factor attempt throttling: 8 tries / 5 minutes per IP. */
const MFA_RULE = { limit: 8, windowMs: 5 * 60 * 1000 };
/** ROUND 146 — per-ACCOUNT second-factor budget (fail closed) — the admin
 *  twin's exact idiom: the IP rule alone admitted ~8k distributed TOTP
 *  guesses per 5-min ticket window; this caps the grind at 8 total. */
const MFA_USER_RULE = { limit: 8, windowMs: 5 * 60 * 1000 };

/**
 * ROUND 45 — POST /api/instances/auth/login/mfa — finish the two-step
 * workspace login (both login routes funnel here).
 *
 * Body: { ticket, code } — the ticket is the short-lived instance-mfa ticket
 * (password already verified, bound to the exact workspace + email blind
 * index + epoch); the code is a live TOTP or a single-use backup code.
 *
 * On success the workspace session cookie is issued with its SessionRecord
 * row. Hardening mirrors the admin twin: origin guard, bounded body, durable
 * fail-closed limiter, epoch + emailIndex re-check, uniform 401s, audit.
 */
export async function POST(req: Request) {
  const violation = originViolation(req);
  if (violation) return violation;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const ticket = (body.data as { ticket?: unknown }).ticket;
  const code = (body.data as { code?: unknown }).code;
  if (
    typeof ticket !== "string" ||
    typeof code !== "string" ||
    !ticket ||
    !/^[0-9A-Za-z-]{4,20}$/.test(code.trim())
  ) {
    return NextResponse.json({ error: "Invalid verification request" }, { status: 400 });
  }

  const ip = clientIp(req);
  if (await rateLimited(`inst-mfa:${ip}`, MFA_RULE, { failClosed: true })) {
    return tooManyRequests(MFA_RULE, { error: "Too many verification attempts, please try again later" });
  }

  const payload = verifyInstanceMfaTicket(ticket);
  if (!payload) {
    return NextResponse.json(
      { error: "Verification session expired — sign in again" },
      { status: 401 }
    );
  }

  try {
    /* ROUND 87 — a trashed (soft-deleted) workspace never completes 2FA
     * sign-in (uniform 401, no enumeration). */
    const row = await db.instance.findUnique({
      where: { id: payload.instanceId, deletedAt: null },
      include: {
        activities: { orderBy: [{ createdAt: "desc" }, { id: "desc" }], take: 8 },
        package: true,
        site: { select: { published: true, theme: true, views: true, contentJson: true } },
      },
    });
    if (!row || (row.sessionVersion ?? 0) !== payload.ver) {
      return NextResponse.json(
        { error: "Verification session expired — sign in again" },
        { status: 401 }
      );
    }

    /* ROUND 146 — the account-scoped budget, AFTER the ticket/row prove
     * WHICH workspace is grinding, BEFORE the code is checked (mirrors
     * the admin twin; same uniform 429 shape). */
    if (await rateLimited(`inst-mfa-acct:${row.id}`, MFA_USER_RULE, { failClosed: true })) {
      return tooManyRequests(MFA_USER_RULE, {
        error: "Too many verification attempts, please try again later",
      });
    }

    const ok = await verifyMfaLogin("instance", row.id, code.trim());
    if (!ok) {
      await logAudit({
        actorType: "instance",
        actorId: row.id,
        actorName: "workspace",
        action: "instance.loginFailed",
        meta: { mfa: "invalid-code" },
      });
      return NextResponse.json({ error: "Incorrect verification code" }, { status: 401 });
    }

    await setInstanceSession(row.id, row.sessionVersion ?? 0, {
      ip,
      userAgent: req.headers.get("user-agent"),
    });
    await db.activity.create({ data: { instanceId: row.id, kind: "actLogin" } });
    await logAudit({
      actorType: "instance",
      actorId: row.id,
      actorName: "workspace · 2FA",
      action: "instance.login",
      targetLabel: toInstanceDTO(row).org.name || row.systemId,
      meta: { mfa: "passed" },
    });

    return NextResponse.json({ ok: true, instance: toInstanceDTO(row) });
  } catch (error) {
    console.error("POST /api/instances/auth/login/mfa failed:", error);
    return NextResponse.json({ error: "Verification failed" }, { status: 500 });
  }
}
