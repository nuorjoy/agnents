import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { toInstanceDTO, zodError } from "@/lib/server/instance-mapper";
import {
  checkInstancePassword,
  setInstanceSession,
} from "@/lib/server/instance-session";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { isIpBanned } from "@/lib/server/ip-ban";
import { originViolation } from "@/lib/server/origin-guard";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { blindIndex, hashPasswordArgon2id, verifyPasswordArgon2id } from "@/lib/server/crypto-vault";
import { isMfaEnabled } from "@/lib/server/mfa";
import { hasCredentials } from "@/lib/server/webauthn";
import { issueInstanceMfaTicket } from "@/lib/server/instance-session";
import { computeBan } from "@/lib/server/entitlement";

export const dynamic = "force-dynamic";

const loginSchema = z.object({
  email: z.email().max(254),
  password: z.string().min(1).max(128),
  /* ROUND 87 (owner self-disable) — sent by the login screen's reactivate
     step: a disabled workspace signs back in ONLY through the explicit
     password-proven re-activation, which clears disabledAt and audits
     instance.selfEnable before the session is minted. */
  reactivate: z.boolean().optional(),
});

/** Login-attempt throttling: 8 tries / 10 min per IP + per account email. */
const LOGIN_RULE = { limit: 8, windowMs: 10 * 60 * 1000 };

/* lazy fixed Argon2id record for timing equalization — burning exactly one
   verify on the unknown-email path keeps response times indistinguishable */
let timingHash: string | null = null;
function burnTimingEqualizer(password: string): void {
  timingHash ??= hashPasswordArgon2id("ashrilogic-timing-equalizer");
  verifyPasswordArgon2id(password, timingHash);
}

/**
 * POST /api/instances/auth/login — ROUND 36 (security) email-first workspace
 * sign-in with SERVER-SIDE credential resolution.
 *
 * The former flow (login page fetching the PUBLIC /api/instances directory
 * and matching the admin email client-side) enumerated every subscriber's
 * PII and let attackers probe which emails own workspaces. Now:
 *
 *  - the email is resolved through the adminEmailIndex blind index (no
 *    directory exposure, no LIKE scans);
 *  - the password is verified server-side against each candidate row;
 *  - failures return a UNIFORM "Incorrect email or password" (same status,
 *    same body, indistinguishable whether the email exists) and burn a
 *    dummy Argon2id verification so response timing cannot reveal account
 *    existence either;
 *  - success signs into the FIRST credential match (a shared admin email
 *    may own several workspaces — the client gets `owned` for the
 *    multi-workspace hint) and returns the authenticated instance DTO.
 */
export async function POST(req: Request) {
  const violation = originViolation(req);
  if (violation) return violation;

  /* ROUND 37 (task 3-a) — bounded body read (declared + streamed caps) in
     place of the unbounded req.json(). */
  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = loginSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const email = parsed.data.email.trim().toLowerCase();
  const ip = clientIp(req);

  /* ROUND 158 (security) — platform-wide IP banlist: a banned IP cannot
   * sign into the tenant dashboard either. Refused BEFORE any rate-limit
   * accounting, BEFORE any password verification, BEFORE the timing
   * equalizer. The check reads through the cached platform settings (10s
   * propagation). Fail-open when the store is unavailable so the ban never
   * locks EVERYONE out; the rate limiter + password check still apply. */
  if (await isIpBanned(ip)) {
    await logAudit({
      actorType: "instance",
      actorName: maskEmail(email),
      action: "instance.loginBlocked",
      meta: { reason: "ip-banned" },
    });
    return NextResponse.json(
      { error: "This IP address is blocked", code: "IP_BLOCKED" },
      { status: 403 }
    );
  }

  if (await rateLimited(`inst-login-ip:${ip}`, LOGIN_RULE, { failClosed: true })) {
    return tooManyRequests(LOGIN_RULE, { error: "Too many sign-in attempts, please try again later" });
  }
  if (await rateLimited(`inst-login-email:${blindIndex(email) ?? ""}`, LOGIN_RULE, { failClosed: true })) {
    return tooManyRequests(LOGIN_RULE, { error: "Too many sign-in attempts for this account, please try again later" });
  }

  /* uniform failure helper — same message for every failure mode.
     ROUND 37 (task 3-a): the attempted address is MASKED for the trail —
     loginFailed rows must never carry plaintext emails. */
  const reject = async (audit: boolean) => {
    if (audit) {
      await logAudit({
        actorType: "instance",
        actorName: maskEmail(email),
        action: "instance.loginFailed",
      });
    }
    return NextResponse.json({ error: "Incorrect email or password" }, { status: 401 });
  };

  try {
    const emailIndex = blindIndex(email) ?? "";
    const candidates = await db.instance.findMany({
      where: { adminEmailIndex: emailIndex, deletedAt: null },
      select: {
        id: true,
        passwordHash: true,
        sessionVersion: true,
        bannedPermanently: true,
        bannedUntil: true,
        bannedReason: true,
        bannedAt: true,
        disabledAt: true,
        disabledReason: true,
      },
    });

    /* minimal identity for the MFA challenge screen (system + org name only —
       the full DTO is only issued after the second factor verifies) */
    const toSanitizedSummary = (row: { systemId: string; orgJson: string }) => ({
      id: row.systemId,
      orgName: (() => {
        try {
          return (JSON.parse(row.orgJson ?? "{}") as { name?: string }).name ?? "";
        } catch {
          return "";
        }
      })(),
    });

    /* timing uniformity: an unknown email burns one Argon2id verify so the
       response time matches the known-email path */
    if (candidates.length === 0) {
      burnTimingEqualizer(parsed.data.password);
      return reject(false);
    }

    for (const candidate of candidates) {
      const pw = checkInstancePassword(parsed.data.password, candidate.passwordHash);
      if (!pw.ok) continue;

      /* ROUND 81 — BAN gate at the credential boundary: a banned workspace
       * refuses sign-in BEFORE any session (or MFA ticket) can be minted —
       * with the platform reason and, for a temporary ban, the exact
       * instant it lifts itself. Logged for the audit trail (masked email). */
      const ban = computeBan(candidate);
      if (ban.active) {
        await logAudit({
          actorType: "instance",
          actorId: candidate.id,
          actorName: maskEmail(email),
          action: "instance.loginFailed",
          targetLabel: "banned",
          meta: { ban: ban.kind ?? "active", ...(ban.reason ? { reason: ban.reason.slice(0, 120) } : {}) },
        });
        return NextResponse.json(
          {
            error:
              "This workspace is suspended by the platform. Access is refused until the suspension is lifted" +
              (ban.until ? ` (it lifts itself automatically on ${ban.until})` : ""),
            code: "BANNED",
            ban,
          },
          { status: 403 }
        );
      }

      /* Persist the bootstrapped demo-password hash OR the transparent
         Argon2id upgrade so legacy rows migrate themselves on first login. */
      if ((pw.bootstrapped || pw.upgraded) && pw.hash) {
        await db.instance.update({
          where: { id: candidate.id },
          data: { passwordHash: pw.hash },
        });
      }

      /* ROUND 87 (owner self-disable) — a paused workspace refuses sign-in
       * with its precise reason. The ONLY way back in is the explicit
       * reactivate flag (same request, password just verified above): that
       * clears the pause, revokes nothing (there are no live sessions),
       * audits instance.selfEnable and falls through to the normal login.
       * Without the flag the owner sees exactly how to resume. */
      if (candidate.disabledAt) {
        if (!parsed.data.reactivate) {
          return NextResponse.json(
            {
              error: "This workspace is disabled by its owner",
              code: "WORKSPACE_DISABLED",
              disabledAt: candidate.disabledAt.toISOString(),
              disabledReason: candidate.disabledReason ?? null,
              reactivate: true,
            },
            { status: 403 }
          );
        }
        await db.instance.update({
          where: { id: candidate.id },
          data: { disabledAt: null, disabledReason: null },
        });
        await logAudit({
          actorType: "instance",
          actorId: candidate.id,
          actorName: maskEmail(email),
          action: "instance.selfEnable",
          targetLabel: "self-reactivate-at-login",
        });
      }

      const row = await db.instance.findUnique({
        where: { id: candidate.id },
        include: {
          activities: { orderBy: [{ createdAt: "desc" }, { id: "desc" }], take: 8 },
          package: true,
          site: { select: { published: true, theme: true, views: true, contentJson: true } },
        },
      });
      if (!row) continue;

      /* ROUND 45 — workspace two-factor gate (see the [id] twin): a 5-minute
       * HMAC ticket replaces the session until the second factor verifies. */
      if (await isMfaEnabled("instance", row.id)) {
        const passkeys = await hasCredentials("instance", row.id);
        await logAudit({
          actorType: "instance",
          actorId: row.id,
          actorName: maskEmail(email),
          action: "instance.login",
          targetLabel: toInstanceDTO(row).org.name || row.systemId,
          meta: { mfa: "challenge" },
        });
        const summary = toSanitizedSummary(row);
        return NextResponse.json({
          ok: true,
          mfaRequired: true,
          /* the REAL workspace id (the passkey completion route is
           * instance-scoped) + a minimal identity for the challenge screen */
          instanceId: row.id,
          orgName: summary.orgName,
          systemId: summary.id,
          ticket: issueInstanceMfaTicket(row.id, row.sessionVersion ?? 0, emailIndex),
          passkeys,
          owned: candidates.length,
        });
      }

      await setInstanceSession(row.id, row.sessionVersion ?? 0, {
        ip,
        userAgent: req.headers.get("user-agent"),
      });
      await db.activity.create({ data: { instanceId: row.id, kind: "actLogin" } });
      await logAudit({
        actorType: "instance",
        actorId: row.id,
        actorName: maskEmail(email),
        action: "instance.login",
        targetLabel: toInstanceDTO(row).org.name || row.systemId,
      });

      return NextResponse.json({
        ok: true,
        instance: toInstanceDTO(row),
        owned: candidates.length,
      });
    }

    return reject(true);
  } catch (error) {
    console.error("POST /api/instances/auth/login failed:", error);
    return NextResponse.json({ error: "Failed to sign in" }, { status: 500 });
  }
}
