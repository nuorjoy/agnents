import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toInstanceDTO } from "@/lib/server/instance-mapper";
import { setInstanceSession } from "@/lib/server/instance-session";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { originViolation } from "@/lib/server/origin-guard";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { computeBan } from "@/lib/server/entitlement";
import type { AuthenticationResponseJSON } from "@simplewebauthn/server";
import { finishPasskeyLogin, startPasskeyLogin } from "@/lib/server/webauthn";

export const dynamic = "force-dynamic";

/** Passkey-login throttling: 10 / 5 min per IP. */
const PK_RULE = { limit: 10, windowMs: 5 * 60 * 1000 };

/**
 * ROUND 56 — POST /api/instances/auth/passkey-login — PASSKEY-FIRST sign-in
 * for system owners (workspace accounts), mirroring the admin pattern:
 *
 *  { step: "start" }             → DISCOVERABLE (usernameless) options: the
 *    browser lists every workspace-scoped passkey created for this origin;
 *    the workspace is resolved from the credential id at finish time.
 *  { step: "finish", response }  → verify the assertion, resolve the owning
 *    workspace, open the HTTP-only workspace session.
 *
 * The password path (/api/instances/auth/login) stays untouched — the
 * per-workspace MFA completion lives at /api/instances/[id]/auth/passkey.
 * This route is the passwordless FRONT door for owners who registered a
 * passkey on their workspace.
 *
 * Hardening: origin guard, bounded body, durable IP limiter (fail closed),
 * single-use 3-minute challenges, counter-based clone detection, audited
 * successes. No workspace enumeration: a failed/unknown passkey yields a
 * generic 401.
 */
export async function POST(req: Request) {
  const violation = originViolation(req);
  if (violation) return violation;

  const body = await readJson(req, 200_000);
  if (!body.ok) return body.response;

  const step = (body.data as { step?: unknown }).step;
  const response = (body.data as { response?: unknown }).response;
  /* L-4 (security audit fix) — the ROUND 87 reactivate flag, mirrored from
   * the password path (/api/instances/auth/login): consumed only by the
   * finish step, only for a disabled workspace whose passkey assertion just
   * verified (see the gate below). */
  const reactivate = (body.data as { reactivate?: unknown }).reactivate === true;

  const ip = clientIp(req);
  if (await rateLimited(`inst-passkey-login:${ip}`, PK_RULE, { failClosed: true })) {
    return tooManyRequests(PK_RULE, { error: "Too many attempts — try again later" });
  }

  /* ------------------------------ STEP 1 ------------------------------ */
  if (step === "start") {
    const started = await startPasskeyLogin(req, "instance", null);
    if (!started.ok) {
      return NextResponse.json(
        { error: "No workspace passkeys registered yet" },
        { status: 400 }
      );
    }
    return NextResponse.json({ options: started.options });
  }

  /* ------------------------------ STEP 2 ------------------------------ */
  if (step === "finish") {
    if (!response || typeof response !== "object" || !("id" in response)) {
      return NextResponse.json({ error: "Invalid assertion" }, { status: 400 });
    }

    const result = await finishPasskeyLogin(
      req,
      "instance",
      response as AuthenticationResponseJSON
    );
    if (!result.ok) {
      const message =
        result.error === "EXPIRED"
          ? "The sign-in window expired — try again"
          : result.error === "UNKNOWN_CREDENTIAL"
            ? "This passkey is not registered"
            : "Passkey verification failed — try again";
      return NextResponse.json({ error: message, code: result.error }, { status: 401 });
    }

    /* the credential resolves to the OWNING workspace (subjectId).
     * ROUND 87 — a trashed (soft-deleted) workspace never signs in. */
    const row = await db.instance.findUnique({
      where: { id: result.subjectId, deletedAt: null },
      include: {
        activities: { orderBy: [{ createdAt: "desc" }, { id: "desc" }], take: 8 },
        package: true,
        site: { select: { published: true, theme: true, views: true, contentJson: true } },
      },
    });
    if (!row) {
      return NextResponse.json({ error: "Passkey verification failed" }, { status: 401 });
    }

    /* ROUND 81 — BAN gate: passkeys must not become a side door around a
     * suspended workspace (the password path refuses at the same boundary). */
    const ban = computeBan(row);
    if (ban.active) {
      await logAudit({
        actorType: "instance",
        actorId: row.id,
        actorName: "workspace · passkey-first",
        action: "instance.loginFailed",
        targetLabel: "banned",
        meta: { ban: ban.kind ?? "active", passkey: "refused" },
      });
      return NextResponse.json(
        {
          error: "This workspace is suspended by the platform — access is refused until the suspension is lifted",
          code: "BANNED",
          ban,
        },
        { status: 403 }
      );
    }

    /* L-4 (security audit fix) — ROUND 87 parity for the passwordless front
     * door: a paused (owner-disabled) workspace refuses passkey-first
     * sign-in with the EXACT envelope the password path returns (same
     * status, code and field set — WORKSPACE_DISABLED + the reason + the
     * reactivate instruction), closing the disabled-gate bypass that
     * switching entry surfaces used to offer.
     *
     * The reactivate contract mirrors /api/instances/auth/login precisely:
     * that surface binds the flag to the password verified in the SAME
     * request; THIS surface binds it to the WebAuthn assertion verified
     * above — userVerification is REQUIRED at both option generation and
     * verification (biometric/PIN), so the proof is possession +
     * user-verification, at least as strong as the password factor. A
     * passkey-only owner (one who never set a password they know) therefore
     * has a genuinely equivalent re-activation path: resubmit the ceremony
     * as { step: "finish", response, reactivate: true } — the pause clears,
     * instance.selfEnable is audited and the normal session mint follows.
     * Without the explicit flag: fail closed, envelope only. */
    if (row.disabledAt) {
      if (!reactivate) {
        await logAudit({
          actorType: "instance",
          actorId: row.id,
          actorName: "workspace · passkey-first",
          action: "instance.loginFailed",
          targetLabel: "disabled",
          meta: { passkey: "refused" },
        });
        return NextResponse.json(
          {
            error: "This workspace is disabled by its owner",
            code: "WORKSPACE_DISABLED",
            disabledAt: row.disabledAt.toISOString(),
            disabledReason: row.disabledReason ?? null,
            reactivate: true,
          },
          { status: 403 }
        );
      }
      /* the explicit re-activation proof — same write + same audit action
       * as the password path's reactivate branch (nothing to revoke: a
       * disabled workspace has no live sessions by construction). */
      await db.instance.update({
        where: { id: row.id },
        data: { disabledAt: null, disabledReason: null },
      });
      await logAudit({
        actorType: "instance",
        actorId: row.id,
        actorName: "workspace · passkey-first",
        action: "instance.selfEnable",
        targetLabel: "self-reactivate-at-passkey-login",
      });
    }

    await setInstanceSession(row.id, row.sessionVersion ?? 0, {
      ip,
      userAgent: req.headers.get("user-agent"),
    });
    await db.activity.create({ data: { instanceId: row.id, kind: "actLogin" } });
    await logAudit({
      actorType: "instance",
      actorId: row.id,
      actorName: "workspace · passkey-first",
      action: "instance.login",
      targetLabel: toInstanceDTO(row).org.name || row.systemId,
      meta: { passkey: "passed", flow: "discoverable" },
    });

    return NextResponse.json({ ok: true, instance: toInstanceDTO(row) });
  }

  return NextResponse.json({ error: "Unknown step" }, { status: 400 });
}
