import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { zodError } from "@/lib/server/instance-mapper";
import { clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { originViolation } from "@/lib/server/origin-guard";
import { readJson } from "@/lib/server/http";
import { deepCheckTenantIdentity } from "@/lib/server/tenant-uniqueness";

export const dynamic = "force-dynamic";

/**
 * POST /api/instances/check-availability — ROUND 134-E.
 *
 * The wizard's live signup availability probe: is the typed login email /
 * org phone free on the platform? A standard public-probe posture:
 *
 *  - same-origin guard (originViolation) — it is a mutating-method probe,
 *    so ambient-credential replay is rejected like every other POST;
 *  - durable per-IP rate limit (30 / 10 min, FAIL-CLOSED — a probing flood
 *    must never slam the instance scan);
 *  - bounded body read + a strict Zod shape (at least ONE of email/phone);
 *  - DEEP semantics (the same engine the provisioning guard runs): the
 *    verdict includes soft-deleted AND demo rows, exactly like the
 *    eventual POST /api/instances decision — the chip the wizard shows is
 *    the verdict the submit will get;
 *  - RESPONSE = BOOLEANS ONLY ({ emailFree, phoneUsed }): no enumeration
 *    data beyond the typed values' own status — no colliding ids, no
 *    masked echoes, nothing else. Values not provided report their
 *    neutral value (emailFree: true / phoneUsed: false).
 */
const AVAILABILITY_RULE = { limit: 30, windowMs: 10 * 60 * 1000 };

const availabilitySchema = z
  .object({
    email: z.email().max(254).optional(),
    phone: z.string().trim().min(1).max(32).optional(),
  })
  .refine((data) => data.email !== undefined || data.phone !== undefined, {
    message: "At least one of email or phone must be provided",
  });

export async function POST(req: Request) {
  const violation = originViolation(req);
  if (violation) return violation;

  const ip = clientIp(req);
  if (await rateLimited(`inst-avail-ip:${ip}`, AVAILABILITY_RULE, { failClosed: true })) {
    return tooManyRequests(AVAILABILITY_RULE, {
      error: "Too many availability checks — try again later",
    });
  }

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = availabilitySchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const { email, phone } = parsed.data;

  try {
    const collisions = await deepCheckTenantIdentity(db, { email, phone });
    return NextResponse.json({
      /* free when not probed or unclaimed — the boolean the wizard chips */
      emailFree: email === undefined ? true : collisions.emailUsedBy === null,
      phoneUsed: phone === undefined ? false : collisions.phoneUsedBy !== null,
    });
  } catch (error) {
    console.error("POST /api/instances/check-availability failed:", error);
    return NextResponse.json({ error: "Failed to check availability" }, { status: 500 });
  }
}
