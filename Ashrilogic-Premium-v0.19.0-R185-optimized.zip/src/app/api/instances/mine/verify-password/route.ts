import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { zodError, readAdminEmail, normalizeEmail } from "@/lib/server/instance-mapper";
import { resolveInstanceSession, checkInstancePassword } from "@/lib/server/instance-session";
import { getSessionUser } from "@/lib/server/admin-session";
import {rateLimited, clientIp, tooManyRequests } from "@/lib/server/rate-limit";
import { originViolation } from "@/lib/server/origin-guard";
import { readJson } from "@/lib/server/http";

export const dynamic = "force-dynamic";

/**
 * ROUND 82 (batch-5 ②) — POST /api/instances/mine/verify-password
 *
 * The signed-in owner is creating ANOTHER system from the «أنظمتك المنشأة»
 * screen and chose "reuse my current account": the wizard's admin step needs
 * proof the typed password is really the owner's CURRENT password, so the new
 * workspace is provisioned with the exact same credentials (one account,
 * many systems).
 *
 *  - principal: the workspace session (owner). Platform admins manage
 *    tenants but hold no workspace password — the reuse flow is owner-only.
 *  - body:      { password: string } (bounded read, 4KB cap)
 *  - 200:       { ok: true, admin: { name, email } } — the identity of the
 *               session workspace's owner, for the wizard prefill
 *  - 401:       wrong password / no session · 403 origin violation ·
 *               429 rate-limited (per IP, fail-closed)
 *
 * The response NEVER leaks whether any OTHER email exists; it describes only
 * the already-authenticated principal's own workspace. A successful verify of
 * a bootstrapped demo row persists the fresh digest exactly like login does.
 */

const VERIFY_RULE = { limit: 12, windowMs: 10 * 60 * 1000 };

const verifySchema = z.object({
  password: z.string().min(1).max(72),
});

export async function POST(req: Request) {
  const violation = originViolation(req);
  if (violation) return violation;

  const body = await readJson(req, 4_000);
  if (!body.ok) return body.response;

  const parsed = verifySchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }

  if (await rateLimited(`owner-pw-verify:${clientIp(req)}`, VERIFY_RULE, { failClosed: true })) {
    return tooManyRequests(VERIFY_RULE, { error: "Too many verification attempts" });
  }

  try {
    /* ROUND 85 — resolve the WORKSPACE session FIRST. The previous
       admin-first order rejected a perfectly valid owner session whenever
       a platform-admin cookie happened to coexist in the same browser
       (the operator tests BOTH consoles) — the wizard's «تحقق» then failed
       with "Workspace sign-in required for password verification" even
       though the owner was fully signed in. The admin branch now only
       speaks when NO valid workspace session exists: platform admins
       manage tenants but hold no workspace password — the reuse flow is
       owner-only. */
    const sessionState = await resolveInstanceSession();
    if (sessionState.status !== "valid") {
      const admin = await getSessionUser();
      if (admin) {
        return NextResponse.json(
          { error: "Workspace sign-in required for password verification" },
          { status: 401 }
        );
      }
      if (sessionState.status === "none") {
        return NextResponse.json({ error: "Sign in first" }, { status: 401 });
      }
      return NextResponse.json(
        { error: "Session expired — sign in again", code: "INSTANCE_STALE" },
        { status: 401 }
      );
    }

    /* ROUND 87 — a trashed workspace's session row reads as gone (the
     * session guard already rejects soft-deleted instances; belt+suspenders) */
    const row = await db.instance.findUnique({
      where: { id: sessionState.instanceId, deletedAt: null },
      select: { passwordHash: true, adminJson: true },
    });
    if (!row) {
      return NextResponse.json(
        { error: "Session expired — sign in again", code: "INSTANCE_STALE" },
        { status: 401 }
      );
    }

    const check = checkInstancePassword(parsed.data.password, row.passwordHash);
    if (!check.ok) {
      return NextResponse.json({ error: "Incorrect password" }, { status: 401 });
    }

    /* persist a bootstrapped/upgraded digest (same contract as login) */
    if (check.bootstrapped || check.upgraded) {
      await db.instance.update({
        where: { id: sessionState.instanceId },
        data: { passwordHash: check.hash },
      });
    }

    /* the admin NAME rides unsealed inside adminJson (only the email is
       sealed); read it defensively for the wizard prefill */
    let name = "";
    try {
      const parsedAdmin = JSON.parse(row.adminJson ?? "{}") as { name?: unknown };
      if (typeof parsedAdmin.name === "string") name = parsedAdmin.name;
    } catch {
      /* corrupt adminJson — empty name is fine */
    }

    return NextResponse.json({
      ok: true,
      admin: {
        name,
        email: normalizeEmail(readAdminEmail(row.adminJson)),
      },
    });
  } catch (error) {
    console.error("POST /api/instances/mine/verify-password failed:", error);
    return NextResponse.json({ error: "Verification failed" }, { status: 500 });
  }
}
