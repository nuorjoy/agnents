import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toInstanceDTO, readAdminEmail, normalizeEmail } from "@/lib/server/instance-mapper";
import { resolveInstanceSession } from "@/lib/server/instance-session";
import { getSessionUser } from "@/lib/server/admin-session";
import { blindIndex } from "@/lib/server/crypto-vault";
import { ensureWalletNo } from "@/lib/server/wallet";

export const dynamic = "force-dynamic";

/**
 * GET /api/instances/mine — ROUND 36 (security) authenticated "my systems"
 * listing for the post-login workspace-select screen.
 *
 * Replaces the public-directory + client-side email filter (which required
 * the anonymous surface to know every subscriber's admin email). The signed-in
 * workspace session identifies the owner; the response carries ONLY that
 * owner's workspaces as full DTOs (they authenticated, so their own admin
 * identity/org data is theirs to see).
 *
 *  - workspace session → owner's workspaces (via adminEmailIndex blind index,
 *    legacy rows backfilled lazily)
 *  - admin session      → panel role: same full list as the admin surface
 *                         (the select screen is reachable from the panel)
 *  - anonymous          → 401 (the client falls back to the public showcase
 *                         projection from GET /api/instances)
 *
 * ROUND 144 — every returned workspace carries the ADVANCED REAL metrics
 * the «أنظمتك المنشأة» premium cards render: the wallet's UNIQUE number +
 * live balance (both straight off the row) and the live team-member count
 * (one grouped count — never N+1 row scans).
 */
export async function GET() {
  try {
    const admin = await getSessionUser();
    if (admin) {
      /* ROUND 87 — trashed (soft-deleted) workspaces vanish from the panel
       * role's select screen too (trash engine owns their visibility). */
      const rows = await db.instance.findMany({
        where: { deletedAt: null },
        orderBy: [{ createdAt: "desc" }, { id: "desc" }],
        take: 500,
        include: {
          activities: { orderBy: [{ createdAt: "desc" }, { id: "desc" }], take: 8 },
          package: true,
          site: { select: { published: true, theme: true, views: true, contentJson: true } },
        },
      });
      const enriched = rows as unknown as (typeof rows[number] & {
        memberCount?: number;
        walletNo?: number | null;
      })[];
      const ids = enriched.map((row) => row.id);
      const memberCounts = await db.teamMember.groupBy({
        by: ["instanceId"],
        where: { instanceId: { in: ids }, deletedAt: null },
        _count: { _all: true },
      });
      const countMap = new Map(memberCounts.map((g) => [g.instanceId, g._count._all]));
      await Promise.all(
        enriched.map((row) =>
          row.walletNo == null
            ? ensureWalletNo(row.id).then((n) => {
                row.walletNo = n;
              })
            : Promise.resolve()
        )
      );
      enriched.forEach((row) => {
        row.memberCount = countMap.get(row.id) ?? 0;
      });
      return NextResponse.json(enriched.map(toInstanceDTO));
    }

    /* ROUND 37 (task 3-a) + jti revocation (round 49): the session must
       pass BOTH revocation layers — the SessionRecord registry ("sign out
       this device") and the instance epoch (password rotation) — before
       the listing serves the owner's PII. */
    const sessionState = await resolveInstanceSession();
    if (sessionState.status === "none") {
      return NextResponse.json({ error: "Sign in to list your systems" }, { status: 401 });
    }
    if (sessionState.status === "invalid") {
      return NextResponse.json(
        { error: "Session expired — sign in again", code: "INSTANCE_STALE" },
        { status: 401 }
      );
    }
    const sessionId = sessionState.instanceId;

    /* ROUND 87 — a trashed workspace's session row reads as gone */
    const session = await db.instance.findUnique({
      where: { id: sessionId, deletedAt: null },
      select: { adminEmailIndex: true, adminJson: true },
    });
    if (!session) {
      return NextResponse.json(
        { error: "Session expired — sign in again", code: "INSTANCE_STALE" },
        { status: 401 }
      );
    }

    let emailIndex = session.adminEmailIndex ?? null;
    if (!emailIndex) {
      /* legacy row — derive + persist the index now (sealed-email read via
         readAdminEmail; no direct JSON.parse of the vault column) */
      const email = normalizeEmail(readAdminEmail(session.adminJson));
      emailIndex = blindIndex(email) ?? "";
      await db.instance.update({ where: { id: sessionId }, data: { adminEmailIndex: emailIndex } });
    }

    /* ROUND 87 — a trashed workspace never appears in the owner's own
     * "mine" listing. */
    const rows = await db.instance.findMany({
      where: { adminEmailIndex: emailIndex, deletedAt: null },
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: 100,
      include: {
        activities: { orderBy: [{ createdAt: "desc" }, { id: "desc" }], take: 8 },
        package: true,
        site: { select: { published: true, theme: true, views: true, contentJson: true } },
      },
    });
    /* ROUND 144 — enrich with the REAL advanced metrics (member count +
     * wallet number/balance) before mapping to the DTO projection. */
    const enriched = rows as unknown as (typeof rows[number] & {
      memberCount?: number;
      walletNo?: number | null;
    })[];
    const memberCounts = await db.teamMember.groupBy({
      by: ["instanceId"],
      where: { instanceId: { in: enriched.map((row) => row.id) }, deletedAt: null },
      _count: { _all: true },
    });
    const countMap = new Map(memberCounts.map((g) => [g.instanceId, g._count._all]));
    await Promise.all(
      enriched.map((row) =>
        row.walletNo == null
          ? ensureWalletNo(row.id).then((n) => {
              row.walletNo = n;
            })
          : Promise.resolve()
      )
    );
    enriched.forEach((row) => {
      row.memberCount = countMap.get(row.id) ?? 0;
    });
    return NextResponse.json(enriched.map(toInstanceDTO));
  } catch (error) {
    console.error("GET /api/instances/mine failed:", error);
    return NextResponse.json({ error: "Failed to list your systems" }, { status: 500 });
  }
}
