import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { SYSTEM_MAP, systemMods } from "@/data/catalog";
import {
  toInstanceDTO,
  toMemberDTO,
  updateInstanceSchema,
  zodError,
  sealAdminSection,
} from "@/lib/server/instance-mapper";
import { computeInstanceStatsFromDb, loadInstanceAggregates } from "@/lib/server/stats";
import { checkPassword, getSessionUser, hashPassword } from "@/lib/server/admin-session";
import { requireInstanceAccess, setInstanceSession } from "@/lib/server/instance-session";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { clientIp } from "@/lib/server/rate-limit";
import { revokeAllSessions } from "@/lib/server/sessions";
import { trialLockResponse, computeEntitlement, type EntitlementRow } from "@/lib/server/entitlement";
import { getOpenShift } from "@/lib/server/shift-gate";
import { PLAN_FEATURES } from "@/lib/plan-features";
import {
  STORE_FORCED_MODULES,
  droppedStoreSources,
  storeHasAnySource,
  unionModules,
} from "@/lib/server/store-module-gate";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/** ROUND 147 — TOCTOU closure marker: thrown from INSIDE the update
 *  transaction when the LIVE module ceiling (re-read from the row being
 *  written) is exceeded — the pre-PATCH guard validates a `current` fetch
 *  that can go stale while a concurrent PATCH lands first. The PATCH catch
 *  below translates it into the byte-identical 403 refusal the pre-check
 *  emits, rolling the transaction back so no oversized module list is
 *  ever persisted. */
class PlanModuleLimitError extends Error {
  constructor(readonly maxModules: number) {
    super("PLAN_MODULE_LIMIT");
    this.name = "PlanModuleLimitError";
  }
}

/**
 * GET /api/instances/[id] — instance detail with deterministic KPI stats
 * and its team members. Requires a workspace session for THIS instance or
 * an authenticated admin (see instance-session.ts).
 */
export async function GET(_req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id);
  if (guard instanceof NextResponse) return guard;

  try {
    const row = await db.instance.findUnique({
      where: { id },
      include: {
        activities: { orderBy: [{ createdAt: "desc" }, { id: "desc" }], take: 8 },
        /* round 36 — bounded member include. ROUND 131: trashed (soft-
         * deleted) members are filtered here too — the dedicated
         * /members route already scoped deletedAt:null, but this embed
         * leaked trashed members back into the dashboard team list. */
        members: { where: { deletedAt: null }, orderBy: { createdAt: "asc" }, take: 200 },
        package: true,
        site: { select: { published: true, theme: true, views: true, contentJson: true } },
      },
    });
    if (!row) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }
    const instance = toInstanceDTO(row);
    /* ROUND 61 (H-8) — real aggregates when the workspace has real order
     * history; deterministic showcase values + demo flag otherwise */
    const agg = await loadInstanceAggregates([instance.id]);
    const stats = computeInstanceStatsFromDb(instance.id, instance.prefs.lang, agg);
    return NextResponse.json({ instance, stats, members: row.members.map((m) => toMemberDTO(m)) });
  } catch (error) {
    console.error(`GET /api/instances/${id} failed:`, error);
    return NextResponse.json({ error: "Failed to fetch instance" }, { status: 500 });
  }
}

/**
 * PATCH /api/instances/[id] — deep-merge partial org/admin/prefs, or replace
 * modules. Records an actSettingsUpdated activity when anything changed.
 * `admin.password` rotates the workspace password (hashed; never stored in
 * adminJson). Authorized by the workspace session or an admin session.
 */
export async function PATCH(req: Request, { params }: RouteContext) {
  const { id } = await params;

  /* ROUND 42 — guard BEFORE the bounded body read (cross-tenant callers
   * can no longer burn the read + zod parse or probe validation). */
  const guard = await requireInstanceAccess(id, req, { permission: "settings.manage" });
  if (guard instanceof NextResponse) return guard;
  let actor = guard.principal;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = updateInstanceSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const data = parsed.data;

  // Split the password out so it never lands in adminJson.
  const { password: newPassword, ...adminPatch } = data.admin ?? {};

  /* ROUND 47 — billing-cycle edits ride the same admin-only gate as
   * packageId (they describe a PURCHASE, never a preference).
   * ROUND 79 — planExpiresAt + featureOverrides are platform levers of the
   * same authority class: term end + per-tenant feature switches. */
  const adminLevers =
    data.planCycle !== undefined ||
    data.planExpiresAt !== undefined ||
    data.featureOverrides !== undefined;
  if (adminLevers && actor.kind !== "admin") {
    const adminActor = await getSessionUser();
    if (adminActor && (adminActor.role === "super" || adminActor.role === "admin")) {
      actor = { kind: "admin", instanceId: id, actorName: adminActor.name, actorId: adminActor.id };
    } else {
      return NextResponse.json(
        { error: "Billing details are managed by the platform — request an upgrade instead", code: "PACKAGE_ADMIN_ONLY" },
        { status: 403 }
      );
    }
  }

  /* ROUND 47 — trial lockdown: a locked workspace accepts NO business
     mutations from its owner (subscription surfaces only). Managing admins
     (directly or via the dual-cookie path above) stay able to assign a plan
     — that is exactly how a locked workspace is reactivated. */
  if (actor.kind === "session") {
    const lock = await trialLockResponse(id);
    if (lock) return lock;
  }

  /* ROUND 36 — plan assignment is an ADMIN action: a signed-in workspace
     owner must not be able to self-assign a higher tier through the API
     (the dashboard goes through the upgrade-request flow instead).
     ROUND 46 — a browser may hold BOTH an admin cookie AND a workspace
     session for this same instance (the operator signed into the tenant
     dashboard to inspect it, then returned to the control panel).
     requireInstanceAccess resolves the workspace session first, which
     used to reject the panel's plan assignment with PACKAGE_ADMIN_ONLY.
     When the request ALSO carries a valid managing-admin session, the plan
     change is admin-authorized and the actor is re-attributed to that
     admin (correct audit trail) — workspace-only callers still get 403. */
  if (data.packageId !== undefined && actor.kind !== "admin") {
    const adminActor = await getSessionUser();
    if (adminActor && (adminActor.role === "super" || adminActor.role === "admin")) {
      actor = { kind: "admin", instanceId: id, actorName: adminActor.name, actorId: adminActor.id };
    } else {
      return NextResponse.json(
        { error: "Plan changes are managed by the platform — request an upgrade instead", code: "PACKAGE_ADMIN_ONLY" },
        { status: 403 }
      );
    }
  }

  try {
    const current = await db.instance.findUnique({
      where: { id },
      include: {
        activities: { orderBy: [{ createdAt: "desc" }, { id: "desc" }], take: 8 },
        package: true,
      },
    });
    if (!current) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }

    /* Password rotation is a proof-of-knowledge operation: a workspace
     * session must re-present the CURRENT password before it may set a new
     * one. Without this, a stolen session cookie is enough to irreversibly
     * take over the tenant (the attacker rotates the secret, every other
     * session dies, and no self-service recovery exists). Platform admins
     * stay exempt — their authority flows from the control panel and is
     * independently audited (mirrors /api/admin/me/password semantics). */
    if (newPassword !== undefined && actor.kind === "session") {
      if (!data.currentPassword) {
        return NextResponse.json(
          { error: "Current password is required to set a new one", code: "PASSWORD_REQUIRED" },
          { status: 400 }
        );
      }
      if (!checkPassword(data.currentPassword, current.passwordHash)) {
        return NextResponse.json(
          { error: "Current password is incorrect", code: "PASSWORD_MISMATCH" },
          { status: 401 }
        );
      }
    }

    const cur = toInstanceDTO(current);

    /* ROUND 36 — module allowlist: replacement module lists must stay inside
       the chosen system's catalog (arbitrary ids are rejected).
       ROUND 136 — legacy grandfathering: modules that are ALREADY enabled on
       the instance (historical catalog drift, e.g. a module that once shipped
       for this system) stay valid members of a replacement list — the strict
       invariant is "no NEW unknown id may enter", not "old rows must be
       purged before the console can touch the list". Without this, any
       instance carrying a drifted module could never save ANY module edit
       (the console module grid bricked with 400). */
    if (data.modules !== undefined) {
      const system = SYSTEM_MAP[cur.systemId];
      const catalogModuleIds = new Set(systemMods(system));
      const badModule = data.modules.find(
        (moduleId) => !catalogModuleIds.has(moduleId) && !cur.modules.includes(moduleId)
      );
      if (badModule) {
        return NextResponse.json(
          { error: `Unknown module for this system: ${badModule}` },
          { status: 400 }
        );
      }
      /* ROUND 134 — الورديات is a toggleable module, but the toggle cannot
       * STRAND an open drawer: removing "shifts" while a shift is open is
       * refused (409 SHIFT_OPEN_MUST_CLOSE) — close the shift first, then
         disable the module. Keeps the shift table invariant (no open shift
         can outlive the module that governs it). */
      if (cur.modules.includes("shifts") && !data.modules.includes("shifts")) {
        const openShift = await getOpenShift(id);
        if (openShift) {
          return NextResponse.json(
            {
              error: "Cannot disable the shifts module while a shift is open — close the shift first",
              code: "SHIFT_OPEN_MUST_CLOSE",
              shiftCode: openShift.code,
            },
            { status: 409 }
          );
        }
      }
    }

    /* ROUND 36 — business-rule enforcement: the assigned plan's maxModules
       caps the enabled module count (client bypasses get a 403). */
    if (
      data.modules !== undefined &&
      current.packageId &&
      data.modules.length > (current.package?.maxModules ?? Infinity)
    ) {
      return NextResponse.json(
        {
          error: `Your plan allows at most ${current.package?.maxModules} enabled modules — disable one first or upgrade`,
          code: "PLAN_MODULE_LIMIT",
        },
        { status: 403 }
      );
    }

    // Merge sections (spreading undefined is a no-op, so absent sections keep current values).
    const nextOrg = { ...cur.org, ...data.org };
    const nextAdmin = { ...cur.admin, ...adminPatch };
    const nextPrefs = { ...cur.prefs, ...data.prefs };
    let nextModules = data.modules ?? cur.modules;

    // Plan assignment: non-null ids must reference an existing package.
    let nextPackageId = cur.packageId;
    /* R163 — the AFTER-state package row for the store entitlement
       computation (capabilitiesJson + tier names are all the engine reads). */
    let nextPackageRow: EntitlementRow["package"] = null;
    /* ROUND 46 — bilingual plan identity for the activity trail: renderers
       pick the reader's language instead of showing an English-only name
       inside the Arabic dashboard (F-7). */
    let assignedPackageName: string | null = null;
    let assignedPackageAr: string | null = null;
    if (data.packageId !== undefined) {
      if (data.packageId === null) {
        nextPackageId = null;
      } else {
        const pkg = await db.package.findUnique({
          where: { id: data.packageId },
          select: { id: true, nameEn: true, nameAr: true, capabilitiesJson: true },
        });
        if (!pkg) {
          return NextResponse.json(
            { error: "Package not found", code: "PACKAGE_NOT_FOUND" },
            { status: 404 }
          );
        }
        nextPackageId = pkg.id;
        assignedPackageName = pkg.nameEn;
        assignedPackageAr = pkg.nameAr;
        nextPackageRow = pkg;
      }
    }

    /* ROUND 47 — activation trail: assigning a plan stamps the activation
       timestamp (+ purchased cycle when provided); clearing the plan clears
       both. This is what restores a trial-locked workspace instantly.
       ROUND 79 — direct panel assignments default to an UNLIMITED term
       (NULL expiry, platform-managed) unless the admin passes an explicit
       date; paid-order confirmation stamps 30d/365d. An explicit
       planExpiresAt in the SAME payload wins (e.g. panel sets an exact date
       together with the assignment). */
    const planActivatedAt =
      nextPackageId !== null ? (cur.packageId !== nextPackageId ? new Date() : (current.planActivatedAt ?? new Date())) : null;
    const planCycle =
      nextPackageId !== null ? (data.planCycle !== undefined ? (data.planCycle ?? null) : (current.planCycle ?? null)) : null;
    const planExpiresAt =
      data.planExpiresAt !== undefined
        ? (data.planExpiresAt ? new Date(data.planExpiresAt) : null)
        : nextPackageId !== cur.packageId
          ? (nextPackageId !== null ? null : (current.planExpiresAt ?? null))
          : (current.planExpiresAt ?? null);
    if (planExpiresAt && Number.isNaN(planExpiresAt.getTime())) {
      return NextResponse.json(
        { error: "Invalid plan expiry date", code: "PLAN_EXPIRY_INVALID" },
        { status: 400 }
      );
    }

    /* ROUND 79 — per-tenant feature overrides: validated keys only (zod
     * already enforces the catalog enum); stored as a canonical JSON map.
     * An empty object clears all overrides (control returns to the plan). */
    const featureOverridesJson =
      data.featureOverrides !== undefined
        ? JSON.stringify(
            Object.fromEntries(
              (Object.entries(data.featureOverrides) as [string, boolean][])
                .filter(([k]) => (PLAN_FEATURES as readonly string[]).includes(k))
            )
          )
        : (current.featureOverridesJson ?? "{}");

    /* R163 — strict e-store ⇄ catalog coupling (the owner's rule: «تفعيل
     * المتجر الإلكتروني يجبّر المستأجرين تفعيل وحدة المنتجات والمخزون
     * بطريقة صارمة»). The storefront renders products from the enabled
     * catalog modules, so three laws are enforced HERE — the single write
     * choke point for the workspace module list (see
     * src/lib/server/store-module-gate.ts for the shared decisions):
     *
     *   LAW 1 — REMOVAL GUARD: while the store is (or becomes) ON, a modules
     *   update may not drop any catalog-source module (products / inventory /
     *   pharmacy / menu) → 409 STORE_MODULE_REQUIRED, mirroring the ROUND-134
     *   shifts precedent (a toggle may never strand a running surface).
     *
     *   LAW 2 — ACTIVATION GATE: force-ON of the store feature on a system
     *   whose catalog carries NO source module is refused → 409 (the store
     *   would be permanently empty). Plan-driven activation only cascades —
     *   a billing assignment is never blocked by module topology (the add-on
     *   purchase path rejects sourceless systems at ORDER CREATION instead,
     *   before any money moves).
     *
     *   LAW 3 — CASCADE: whenever the store is effectively ON, products +
     *   inventory (catalog-permitting) are unioned into the persisted list.
     *   Forced modules are exempt from the plan's maxModules ceiling: the
     *   ceiling governs tenant choices, never the platform's own rule. */
    const storeBefore = computeEntitlement(current).features.store === true;
    const storeAfter = computeEntitlement({
      packageId: nextPackageId,
      trialEndsAt: current.trialEndsAt,
      planActivatedAt: current.planActivatedAt,
      planCycle: current.planCycle,
      planExpiresAt: planExpiresAt ?? current.planExpiresAt ?? null,
      featureOverridesJson,
      bannedPermanently: current.bannedPermanently,
      bannedUntil: current.bannedUntil,
      bannedReason: current.bannedReason,
      bannedAt: current.bannedAt,
      disabledAt: current.disabledAt,
      package: nextPackageRow ?? current.package ?? null,
    } satisfies EntitlementRow).features.store === true;
    if (storeAfter) {
      const system = SYSTEM_MAP[cur.systemId];
      const allowedSources = new Set([
        ...systemMods(system),
        ...cur.modules,
      ]);
      /* LAW 1 — refuse dropping a live catalog source while the store runs */
      if (data.modules !== undefined) {
        const dropping = droppedStoreSources(cur.modules, data.modules);
        if (dropping.length > 0) {
          return NextResponse.json(
            {
              error:
                "Cannot disable the products/inventory modules while the e-commerce store is active — disable the store first",
              code: "STORE_MODULE_REQUIRED",
            },
            { status: 409 }
          );
        }
      }
      /* LAW 2 — a store force-ON needs at least one possible source */
      if (
        !storeBefore &&
        data.featureOverrides?.store === true &&
        !storeHasAnySource(cur.systemId, cur.modules)
      ) {
        return NextResponse.json(
          {
            error:
              "This system's catalog has no products or inventory modules — the e-commerce store cannot be activated for it",
            code: "STORE_MODULE_REQUIRED",
          },
          { status: 409 }
        );
      }
      /* LAW 3 — cascade the forced pair (idempotent union) */
      const forced = STORE_FORCED_MODULES.filter((m) => allowedSources.has(m));
      if (forced.length > 0) {
        nextModules = unionModules(nextModules, forced);
      }
    }

    const passwordChanged = newPassword !== undefined;
    const emailChanged =
      adminPatch.email !== undefined &&
      adminPatch.email.trim().toLowerCase() !== cur.admin.email.trim().toLowerCase();
    const modulesChanged = data.modules !== undefined && JSON.stringify(nextModules) !== JSON.stringify(cur.modules);
    const settingsChanged =
      JSON.stringify(nextOrg) !== JSON.stringify(cur.org) ||
      JSON.stringify(nextAdmin) !== JSON.stringify(cur.admin) ||
      JSON.stringify(nextPrefs) !== JSON.stringify(cur.prefs);
    const packageChanged = nextPackageId !== cur.packageId;
    const planExpiryChanged =
      data.planExpiresAt !== undefined &&
      (planExpiresAt?.getTime() ?? null) !== (current.planExpiresAt?.getTime() ?? null);
    const overridesChanged = featureOverridesJson !== (current.featureOverridesJson ?? "{}");

    /*
     * WORKSPACE EMAIL INDEX CONSISTENCY (critical): when the admin email
     * changes, adminJson AND its HMAC blind index MUST flip together —
     * atomically. Login (/api/instances/auth/login) and /api/instances/mine
     * resolve workspaces by adminEmailIndex only, so a stale index would
     * permanently lock the new email out while the old one keeps working.
     * The email is stored SEALED (AES-256-GCM) inside adminJson; the write
     * below runs inside one transaction together with the activity row so
     * no observer can ever see a half-migrated state.
     */
    const sealed = sealAdminSection({
      name: nextAdmin.name,
      email: nextAdmin.email,
      role: nextAdmin.role,
      twoFA: nextAdmin.twoFA,
      /* ROUND 64 — owner profile photo survives the re-seal */
      avatarUrl: nextAdmin.avatarUrl ?? null,
    });

    // Log the settings update BEFORE updating so the refreshed include picks it up.
    const activityCreate =
      packageChanged || passwordChanged || modulesChanged || settingsChanged || planExpiryChanged || overridesChanged
        ? {
            data: packageChanged
              ? {
                  instanceId: id,
                  kind: "actSettingsUpdated" as const,
                  /* ROUND 46 — both names travel in the meta so every surface
                     renders the plan in the reader's language */
                  metaJson: JSON.stringify({
                    package: assignedPackageName ?? "—",
                    packageAr: assignedPackageAr ?? assignedPackageName ?? "—",
                  }),
                }
              : { instanceId: id, kind: "actSettingsUpdated" as const },
          }
        : null;

    const row = await db.$transaction(async (tx) => {
      /* ROUND 147 — TOCTOU closure (owner's rule: the workspace may NEVER
       * exceed the package/units): `current` was fetched BEFORE this
       * transaction, so the maxModules pre-check above validated a snapshot
       * that can already be stale — a concurrent PATCH could have pushed the
       * module list past the ceiling in between. The package + module state
       * is re-read here from the LIVE row, inside the SAME transaction that
       * writes it, BEFORE the update — so the ceiling is enforced against
       * the exact state being replaced. Belt+braces with the pre-check: the
       * refusal is identical, but the race is closed. */
      if (data.modules !== undefined) {
        const live = await tx.instance.findUnique({
          where: { id },
          select: { packageId: true, package: { select: { maxModules: true } } },
        });
        const liveMax = live?.packageId ? (live.package?.maxModules ?? Infinity) : Infinity;
        if (data.modules.length > liveMax) {
          throw new PlanModuleLimitError(liveMax);
        }
      }
      if (activityCreate) {
        await tx.activity.create(activityCreate);
      }
      return tx.instance.update({
        where: { id },
        data: {
          orgJson: JSON.stringify(nextOrg),
          adminJson: sealed.adminJson,
          /* email changed → the blind index flips in the SAME transaction */
          ...(emailChanged ? { adminEmailIndex: sealed.adminEmailIndex } : {}),
          prefsJson: JSON.stringify(nextPrefs),
          modulesJson: JSON.stringify(nextModules),
          ...(data.packageId !== undefined ? { packageId: nextPackageId, planActivatedAt, planCycle } : {}),
          /* ROUND 79 — term end + feature overrides are independent levers:
             they may arrive with or without a packageId in the same PATCH. */
          ...(data.planExpiresAt !== undefined ? { planExpiresAt } : {}),
          ...(data.featureOverrides !== undefined ? { featureOverridesJson } : {}),
          ...(passwordChanged && newPassword
            ? {
                passwordHash: hashPassword(newPassword),
                /* round 36 — bump the session epoch: every outstanding workspace
                   token is revoked instantly on password rotation */
                sessionVersion: { increment: 1 },
              }
            : {}),
        },
        include: {
          activities: { orderBy: [{ createdAt: "desc" }, { id: "desc" }], take: 8 },
          package: true,
        },
      });
    });

    /* round 36 — the actor that just rotated the password keeps working in
       THIS browser: re-issue its token at the new epoch (all other sessions,
       including stolen cookies, are now stale).
       ROUND 45 — the registry mirrors the revocation, then a fresh row is
       created for the surviving session (with real device metadata). */
    if (passwordChanged && newPassword) {
      await revokeAllSessions("instance", id);
    }
    if (passwordChanged && newPassword && actor.kind === "session") {
      await setInstanceSession(id, row.sessionVersion ?? 0, {
        ip: clientIp(req),
        userAgent: req.headers.get("user-agent"),
      });
    }

    await logAudit(
      passwordChanged && !settingsChanged && !modulesChanged && !packageChanged
        ? {
            actorType: actor.kind === "admin" ? "admin" : "instance",
            actorId: actor.actorId,
            actorName: maskEmail(actor.actorName),
            action: "instance.password",
            targetLabel: cur.org.name || cur.systemId,
          }
        : {
            actorType: actor.kind === "admin" ? "admin" : "instance",
            actorId: actor.actorId,
            actorName: maskEmail(actor.actorName),
            action: "instance.update",
            targetLabel: cur.org.name || cur.systemId,
            meta: {
              ...(packageChanged ? { package: assignedPackageName ?? "—", ...(nextPackageId ? { activated: "true" } : {}) } : {}),
              ...(modulesChanged ? { modules: String(nextModules.length) } : {}),
              ...(passwordChanged ? { password: "changed" } : {}),
              ...(emailChanged ? { email: "changed" } : {}),
            },
          }
    );

    return NextResponse.json(toInstanceDTO(row));
  } catch (error) {
    /* ROUND 147 — the in-transaction module-ceiling re-check refuses with
     * the EXACT body/code/message of the pre-check above (403
     * PLAN_MODULE_LIMIT). */
    if (error instanceof PlanModuleLimitError) {
      return NextResponse.json(
        {
          error: `Your plan allows at most ${error.maxModules} enabled modules — disable one first or upgrade`,
          code: "PLAN_MODULE_LIMIT",
        },
        { status: 403 }
      );
    }
    console.error(`PATCH /api/instances/${id} failed:`, error);
    return NextResponse.json({ error: "Failed to update instance" }, { status: 500 });
  }
}

/**
 * DELETE /api/instances/[id] — removes the instance; activities and members
 * cascade-delete with it. Authorized by the workspace session or an admin
 * session (my-systems delete prompts for sign-in when anonymous).
 */
export async function DELETE(_req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, _req, { permission: "settings.manage" });
  if (guard instanceof NextResponse) return guard;

  try {
    const existing = await db.instance.findUnique({
      where: { id },
      select: { systemId: true, orgJson: true },
    });
    if (!existing) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }
    let orgName = "";
    try {
      const org = JSON.parse(existing.orgJson) as { name?: string };
      orgName = org.name ?? "";
    } catch {
      // corrupt orgJson — audit with the systemId instead
    }
    /* ROUND 87 (trash) — the workspace delete is a SOFT DELETE: the row
       moves to the platform trash (restorable for the retention window,
       purge destroys it permanently with the exact cascade below). Live
       sessions are revoked by the engine on the spot. The OWNER path
       additionally proves knowledge of the workspace password (the owner
       deleting their own account is a destructive account-lifecycle
       action); the platform-admin path keeps its rbac mandate as-is. */
    /* ROUND 88 — the F-6 cookie-shadowing mirror for DELETE: a browser may
       hold BOTH the workspace session and a managing-admin session (the
       operator signed into the tenant dashboard to inspect it, then
       returned to the control panel and deleted the workspace from there).
       requireInstanceAccess resolves the workspace session first, which
       routed this DELETE into the owner's password-proof branch and 403'd
       the panel with PASSWORD_PROOF_REQUIRED — the admin does not know the
       workspace password. When the request ALSO carries a valid
       managing-admin session, the delete is admin-authorized and
       re-attributed to that admin (the PATCH route's ROUND 46 packageId
       precedent verbatim); workspace-only callers still face the password
       proof. */
    let principal = guard.principal;
    if (principal.kind !== "admin") {
      const adminActor = await getSessionUser();
      if (adminActor && (adminActor.role === "super" || adminActor.role === "admin")) {
        principal = {
          kind: "admin",
          instanceId: id,
          actorName: adminActor.name,
          actorId: adminActor.id,
          adminRole: adminActor.role,
        };
      }
    }
    if (principal.kind !== "admin") {
      /* owner self-delete — password proof required (destructive). */
      const row = await db.instance.findUnique({
        where: { id },
        select: { passwordHash: true },
      });
      const { checkInstancePassword } = await import("@/lib/server/instance-session");
      const body = await readJson(_req).catch(() => null);
      const password = body && body.ok ? (body.data as { password?: string }).password : undefined;
      const pw = checkInstancePassword(password ?? "", row?.passwordHash ?? null);
      if (!pw.ok) {
        await logAudit({
          actorType: "instance",
          actorId: id,
          actorName: guard.principal.actorName,
          action: "instance.selfDelete",
          targetLabel: "password-proof-failed",
        });
        return NextResponse.json(
          { error: "Workspace password confirmation is required to delete this account", code: "PASSWORD_PROOF_REQUIRED" },
          { status: 403 }
        );
      }
      const { softDelete } = await import("@/lib/server/trash");
      const reason = body && body.ok ? ((body.data as { reason?: string }).reason ?? null) : null;
      const result = await softDelete("instance", id, {
        kind: "instance",
        actorId: id,
        actorName: principal.actorName,
      }, { reason });
      if (!result.ok) {
        return NextResponse.json({ error: "Failed to delete instance" }, { status: result.status });
      }
      await logAudit({
        actorType: "instance",
        actorId: id,
        actorName: guard.principal.actorName,
        action: "instance.selfDelete",
        targetLabel: orgName || existing.systemId,
        meta: { soft: "true", ...(reason ? { reason } : {}) },
      });
      return NextResponse.json({ ok: true, soft: true });
    }

    const { softDelete } = await import("@/lib/server/trash");
    const result = await softDelete("instance", id, {
      kind: "admin",
      actorId: principal.actorId,
      actorName: principal.actorName,
    });
    if (!result.ok) {
      return NextResponse.json({ error: "Failed to delete instance" }, { status: result.status });
    }
    return NextResponse.json({ ok: true, soft: true });
  } catch (error) {
    console.error(`DELETE /api/instances/${id} failed:`, error);
    return NextResponse.json({ error: "Failed to delete instance" }, { status: 500 });
  }
}
