import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { moduleRecordUpdateSchema, toModuleRecordDTO } from "@/lib/server/module-record-mapper";
import { zodError } from "@/lib/server/instance-mapper";
import { requireInstanceAccess, assertInstancePermission } from "@/lib/server/instance-session";
import { trialLockResponse, featureGateResponse } from "@/lib/server/entitlement";
import { MODULE_FEATURE_GATES } from "@/lib/plan-features";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { modulePreset } from "@/lib/module-data";
import { deriveRecordCodeKey } from "@/lib/record-code";
import { resolveRecordImage, ImageValidationError } from "@/lib/server/record-image";
import {
  resolveRecordGallery,
  resolveRecordVideos,
} from "@/lib/server/record-media";
import { resolveRecordVariants } from "@/lib/server/record-variants";
import { shiftGateResponse } from "@/lib/server/shift-gate";
import { parseRecordValues, storeColumnsFor } from "@/lib/server/store-mapper";
import { parsePriceCellToMinor } from "@/lib/server/money";
import { withStorageQuotaWrite } from "@/lib/server/usage";
import { moduleWritePermission } from "@/lib/permissions";
import {rateLimited, tooManyRequests } from "@/lib/server/rate-limit";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string; recordId: string }> };

/** Per-instance write throttle (shared with the collection POST): bounds the
 *  sharp re-encode CPU-burn behind the auth gate. Fail-open — the plan/quota
 *  gates stay the authoritative limiters. */
const RECORD_WRITE_RULE = { limit: 300, windowMs: 10 * 60 * 1000 };

/** Email-shaped values are PII — mask them for the audit trail; plain admin
 *  handles ("sarah.super") pass through so the trail stays correlatable. */
const EMAIL_SHAPE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function auditActorName(name: string): string {
  return EMAIL_SHAPE.test(name) ? maskEmail(name) : name;
}

/**
 * PATCH /api/instances/[id]/module-records/[recordId] — edit one REAL row
 * (values and/or statusKey). Workspace-session guarded; the record must
 * belong to THIS instance. Audit-logged.
 */
export async function PATCH(req: Request, { params }: RouteContext) {
  const { id, recordId } = await params;
  const guard = await requireInstanceAccess(id, req);
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const trialLock = await trialLockResponse(id);
  if (trialLock) return trialLock;

  /* per-instance write throttle (see RECORD_WRITE_RULE above). */
  if (await rateLimited(`rec-write:${id}`, RECORD_WRITE_RULE)) {
    return tooManyRequests(RECORD_WRITE_RULE, { error: "Too many record writes — try again shortly" });
  }

  /* ROUND 37 (task 3-c) — bounded body read: 2 MB cap (ROUND 51 — the payload
   * may carry a product-photo data-URL alongside the row values). */
  const body = await readJson(req, 2_000_000);
  if (!body.ok) return body.response;

  const parsed = moduleRecordUpdateSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json(
      { error: zodError(parsed.error) || "values[] and/or statusKey are required" },
      { status: 400 }
    );
  }

  try {
    /* ROUND 146 — trashed records are dead to the live PATCH surface
     * (trash owns restore/purge; GET already filtered). */
    const existing = await db.moduleRecord.findFirst({
      where: { id: recordId, deletedAt: null },
      select: { instanceId: true, moduleId: true, imageRef: true, dataJson: true, galleryJson: true, videosJson: true, variantsJson: true, storeVisible: true, paymentsJson: true },
    });
    if (!existing || existing.instanceId !== id) {
      return NextResponse.json({ error: "Record not found" }, { status: 404 });
    }

    /* ROUND 80 — premium-module plan gate (records of a gated module refuse
       edits when the plan lacks the mapped feature). */
    const gatedFeature = MODULE_FEATURE_GATES[existing.moduleId];
    if (gatedFeature) {
      const gate = await featureGateResponse(id, gatedFeature);
      if (gate) return gate;
    }

    /* ROUND 78 — strict RBAC: the write permission is resolved from the
     * RECORD'S module (the inventory surface demands its own dedicated
     * permission; every other module takes modules.edit). */
    const permCheck = await assertInstancePermission(
      guard.principal,
      moduleWritePermission(existing.moduleId)
    );
    if (permCheck) return permCheck;

    /* ROUND 133 — نظام الورديات: editing a business record is a business
     * mutation → refused with 403 SHIFT_REQUIRED while no shift is open
     * (the strict, non-bypassable shift law — see shift-gate.ts). */
    const shiftGate = await shiftGateResponse(id);
    if (shiftGate) return shiftGate;

    /* ROUND 37 (task 3-c) — module-SHAPE validation against the preset of
     * the RECORD'S module (the PATCH body carries no moduleId). Same rules
     * as the create route: a submitted statusKey must be "" or a preset
     * status key; a submitted values array cannot exceed the preset's
     * column count. Fields that are not submitted are not validated.
     * ROUND 168 — the preset is resolved SYSTEM-SCOPED (the instance's
     * systemId) so the contract matches the workspace's own columns. */
    const instanceSystem = await db.instance.findUnique({
      where: { id },
      select: { systemId: true },
    });
    const preset = modulePreset(existing.moduleId, instanceSystem?.systemId);
    if (
      parsed.data.statusKey !== undefined &&
      preset.statuses.length > 0 &&
      parsed.data.statusKey !== "" &&
      !preset.statuses.some((s) => s.key === parsed.data.statusKey)
    ) {
      return NextResponse.json({ error: "Unknown status for this module" }, { status: 400 });
    }
    if (parsed.data.values !== undefined && parsed.data.values.length > preset.cols.length) {
      return NextResponse.json({ error: "Too many values for this module" }, { status: 400 });
    }

    /* ROUND 132 — IMMUTABLE record IDs (the owner's directive: «جميع الـIDs
     * غير قابلة للتعديل»). When a PATCH submits a values array, its
     * id-column cell (the preset's FIRST kind:"id" column) must match the
     * stored row's id cell — any attempt to re-key an existing record is a
     * 409 CONFLICT, never a silent rewrite. Values that were never stored
     * (short legacy arrays) simply pass through. */
    if (parsed.data.values !== undefined) {
      const idIndex = preset.cols.findIndex((c) => c.kind === "id");
      if (idIndex >= 0) {
        let storedId = "";
        try {
          const storedValues = JSON.parse(existing.dataJson) as string[];
          storedId = (storedValues[idIndex] ?? "").trim();
        } catch {
          storedId = "";
        }
        const incomingId = (parsed.data.values[idIndex] ?? "").trim();
        if (storedId !== "" && incomingId !== storedId) {
          return NextResponse.json(
            { error: "Record codes are immutable — they cannot be changed after creation", code: "RECORD_CODE_IMMUTABLE" },
            { status: 409 }
          );
        }
      }
    }

    /* ROUND 51 — optional product photo: resolve the submitted image field
     * against the row's stored ref (data-URL → validated + re-encoded +
     * content-addressed store; managed ref → verbatim; "" → clear).
     * Runs AFTER auth so anonymous callers can never burn sharp CPU.
     * ROUND 140 — the GALLERY array and the legacy single `image` field
     * overlap in meaning (the gallery's FIRST entry IS the cover); a body
     * that submits both is ambiguous and refused outright. */
    if (parsed.data.image !== undefined && parsed.data.gallery !== undefined) {
      return NextResponse.json(
        { error: "image and gallery are mutually exclusive — submit the ordered gallery array", code: "IMAGE_GALLERY_CONFLICT" },
        { status: 400 }
      );
    }
    let imagePatch: { imageRef: string | null } | undefined;
    if (parsed.data.image !== undefined) {
      try {
        const resolved = await resolveRecordImage(parsed.data.image, existing.imageRef);
        if (!resolved.ok) {
          /* ROUND 120 — a GC'd asset echo is a CONFLICT (the submitted
           * reference points at state that no longer exists), not a
           * malformed request */
          return NextResponse.json(
            { error: resolved.error, ...(resolved.code ? { code: resolved.code } : {}) },
            { status: resolved.code === "IMAGE_GONE" ? 409 : 400 }
          );
        }
        if (resolved.changed) imagePatch = { imageRef: resolved.imageRef };
      } catch (error) {
        if (error instanceof ImageValidationError) {
          return NextResponse.json({ error: error.message }, { status: 400 });
        }
        throw error;
      }
    }

    /* ROUND 140 — the product MEDIA GALLERY: the submitted ordered array
     * is validated entry-by-entry against the ImageAsset table (the ROUND
     * 120 GC TOCTOU contract), then split into cover (imageRef) + extras
     * (galleryJson). Dropped refs become targeted GC release candidates. */
    let galleryPatch:
      | { imageRef: string | null; galleryJson: string | null }
      | undefined;
    let droppedImages: string[] = [];
    if (parsed.data.gallery !== undefined) {
      const resolved = await resolveRecordGallery(
        parsed.data.gallery,
        existing.imageRef,
        existing.galleryJson
      );
      if (!resolved.ok) {
        return NextResponse.json(
          { error: resolved.error, ...(resolved.code ? { code: resolved.code } : {}) },
          { status: resolved.code === "IMAGE_GONE" ? 409 : 400 }
        );
      }
      if (resolved.changed && resolved.data.kind === "gallery") {
        galleryPatch = { imageRef: resolved.data.imageRef, galleryJson: resolved.data.galleryJson };
        droppedImages = resolved.droppedImages;
      }
    }

    /* ROUND 140 — the product VIDEO clips (≤2 managed /api/videos refs,
     * each verified against the MediaAsset table). */
    let videosPatch: { videosJson: string | null } | undefined;
    let droppedVideos: string[] = [];
    if (parsed.data.videos !== undefined) {
      const resolved = await resolveRecordVideos(parsed.data.videos, existing.videosJson);
      if (!resolved.ok) {
        return NextResponse.json(
          { error: resolved.error, ...(resolved.code ? { code: resolved.code } : {}) },
          { status: resolved.code === "VIDEO_GONE" ? 409 : 400 }
        );
      }
      if (resolved.changed && resolved.data.kind === "videos") {
        videosPatch = { videosJson: resolved.data.videosJson };
        droppedVideos = resolved.droppedVideos;
      }
    }

    /* ROUND 141 — product VARIANTS (متغيرات): pure JSON rows — validated,
     * normalized + diffed against the stored variantsJson. undefined keeps
     * the stored rows; [] clears them. */
    let variantsPatch: { variantsJson: string | null } | undefined;
    if (parsed.data.variants !== undefined) {
      const resolved = resolveRecordVariants(parsed.data.variants, existing.variantsJson);
      if (!resolved.ok) {
        return NextResponse.json({ error: resolved.error }, { status: 400 });
      }
      if (resolved.changed) {
        variantsPatch = { variantsJson: resolved.variantsJson };
      }
    }

    /* ROUND 52 — merchandising fields. The sale price must be a positive
     * integer minor-unit amount STRICTLY below the record's CURRENT regular
     * price (parsed from its dataJson money cell): a sale can never raise
     * the price, equal it, or free the item. Cleared with null.
     * ROUND 53 — optional sale END window (saleEndsAt): bounded to
     * [start-of-today UTC, +365 days]. Clearing the sale price also clears
     * its window (no stale dates linger on the row). */
    let merchPatch:
      | { featured?: boolean; salePrice?: number | null; saleEndsAt?: Date | null }
      | undefined;
    if (
      parsed.data.featured !== undefined ||
      parsed.data.salePrice !== undefined ||
      parsed.data.saleEndsAt !== undefined
    ) {
      merchPatch = {};
      if (parsed.data.featured !== undefined) merchPatch.featured = parsed.data.featured;
      if (parsed.data.salePrice !== undefined) {
        if (parsed.data.salePrice === null) {
          merchPatch.salePrice = null;
          /* clearing the sale clears its window too */
          merchPatch.saleEndsAt = null;
        } else {
          const cols = storeColumnsFor(existing.moduleId);
          const values = parseRecordValues(existing.dataJson);
          const regularMinor = parsePriceCellToMinor(
            values[cols.price] ?? ""
          );
          if (regularMinor <= 0 || parsed.data.salePrice >= regularMinor) {
            return NextResponse.json(
              { error: "The sale price must be lower than the product's regular price", code: "SALE_ABOVE_REGULAR" },
              { status: 400 }
            );
          }
          merchPatch.salePrice = parsed.data.salePrice;
        }
      }
      if (parsed.data.saleEndsAt !== undefined) {
        if (parsed.data.saleEndsAt === null) {
          merchPatch.saleEndsAt = null;
        } else {
          const end = new Date(parsed.data.saleEndsAt);
          if (Number.isNaN(end.getTime())) {
            return NextResponse.json(
              { error: "Invalid sale end date", code: "SALE_END_INVALID" },
              { status: 400 }
            );
          }
          const startOfToday = new Date();
          startOfToday.setUTCHours(0, 0, 0, 0);
          const maxEnd = new Date(startOfToday.getTime() + 365 * 24 * 60 * 60 * 1000);
          if (end.getTime() < startOfToday.getTime() || end.getTime() > maxEnd.getTime()) {
            return NextResponse.json(
              { error: "The sale end date must be between today and 365 days from now", code: "SALE_END_OUT_OF_RANGE" },
              { status: 400 }
            );
          }
          merchPatch.saleEndsAt = end;
        }
      }
    }

    /* LOST-UPDATE GUARD: owner edits must not silently undo a concurrent
     * stock decrement (a guest order commits between this handler's read
     * and its write). The order-placement route already decrements stock
     * with a compare-and-swap on dataJson — the owner PATCH applies the
     * SAME predicate so a stale editor copy is rejected instead of
     * overwriting the sold inventory. Non-values patches (status/merch/
     * image/media only) never touch dataJson and stay plain updates. */
    const mediaPatch = {
      ...(galleryPatch !== undefined ? galleryPatch : {}),
      ...(videosPatch !== undefined ? videosPatch : {}),
      ...(variantsPatch !== undefined ? variantsPatch : {}),
      ...(parsed.data.storeVisible !== undefined ? { storeVisible: parsed.data.storeVisible } : {}),
      /* ROUND 141 (㉕ payment management) — the structured ledger
       * (undefined = keep; [] clears to null). */
      ...(parsed.data.payments !== undefined
        ? { paymentsJson: parsed.data.payments.length > 0 ? JSON.stringify(parsed.data.payments) : null }
        : {}),
    };
    if (parsed.data.values !== undefined) {
      /* ROUND 165/171 — QUOTA GATE GAP CLOSED + made race-free: a
       * values-edit can grow dataJson without bound. The incoming row's
       * new dataJson is checked against the workspace's REAL usage with
       * the old dataJson netted out (replaceBytes), and the check + the
       * CAS update commit atomically under the tenant's storage-quota
       * advisory lock — concurrent editors serialize. The CAS predicate
       * itself still guards the lost-update hazard inside the transaction. */
      const incomingBytes = Buffer.byteLength(JSON.stringify(parsed.data.values), "utf8");
      const replaceBytes = Buffer.byteLength(existing.dataJson ?? "", "utf8");

      /* ROUND 171 — the values-edit re-derives the DB-enforced unique-code
       * key: a code EDIT updates codeKey atomically with the row (the CAS
       * predicate still guards the lost-update hazard); a raced duplicate
       * hits the unique index → the 409 collision envelope below. */
      const idIndex = preset.cols.findIndex((c) => c.kind === "id");
      const codeKey = deriveRecordCodeKey(parsed.data.values, idIndex);

      const gated = await withStorageQuotaWrite(
        id,
        { incomingBytes, replaceBytes },
        (tx) =>
          tx.moduleRecord.updateMany({
            where: { id: recordId, dataJson: existing.dataJson },
            data: {
              dataJson: JSON.stringify(parsed.data.values),
              ...(codeKey !== null ? { codeKey } : { codeKey: null }),
              ...(parsed.data.statusKey !== undefined ? { statusKey: parsed.data.statusKey } : {}),
              ...(imagePatch !== undefined ? imagePatch : {}),
              ...(merchPatch !== undefined ? merchPatch : {}),
              ...mediaPatch,
            },
          })
      ).catch((err: unknown) => {
        if (
          err instanceof Error &&
          (err as { code?: string }).code === "P2002"
        ) {
          return {
            ok: false as const,
            response: NextResponse.json(
              { error: "This record code already exists — codes are unique and never duplicated", code: "RECORD_CODE_COLLISION" },
              { status: 409 }
            ),
          };
        }
        throw err;
      });
      if (!gated.ok) return gated.response;
      const cas = gated.result;
      if (cas.count !== 1) {
        return NextResponse.json(
          {
            error: "This record changed while you were editing (a new order may have updated its stock) — reload and retry",
            code: "RECORD_CONFLICT",
          },
          { status: 409 }
        );
      }
    } else {
      await db.moduleRecord.update({
        where: { id: recordId },
        data: {
          ...(parsed.data.statusKey !== undefined ? { statusKey: parsed.data.statusKey } : {}),
          ...(imagePatch !== undefined ? imagePatch : {}),
          ...(merchPatch !== undefined ? merchPatch : {}),
          ...mediaPatch,
        },
      });
    }

    /* ROUND 117 — the replaced/cleared photo's storage is reclaimed the
     * moment nothing references it anymore (a fresh reference scan runs
     * inside releaseImageRefs; fire-and-forget, never blocks the write).
     * ROUND 140 — the same targeted release now covers the dropped GALLERY
     * photos and the dropped VIDEO clips (media-ref GC). */
    if (imagePatch !== undefined && existing.imageRef) {
      const { releaseImageRefs } = await import("@/lib/server/image-ref-gc");
      void releaseImageRefs([existing.imageRef]).catch(() => undefined);
    }
    if (droppedImages.length > 0) {
      const { releaseImageRefs } = await import("@/lib/server/image-ref-gc");
      void releaseImageRefs(droppedImages).catch(() => undefined);
    }
    if (droppedVideos.length > 0) {
      const { releaseVideoRefs } = await import("@/lib/server/media-ref-gc");
      void releaseVideoRefs(droppedVideos).catch(() => undefined);
    }

    const row = await db.moduleRecord.findUnique({ where: { id: recordId } });
    if (!row) {
      return NextResponse.json({ error: "Record not found" }, { status: 404 });
    }

    await logAudit({
      actorType: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: auditActorName(guard.principal.actorName),
      action: "moduleRecord.update",
      targetLabel: `${existing.moduleId} · ${recordId.slice(0, 8)}`,
      meta: {
        surface: "module-workspace",
        ...(imagePatch !== undefined ? { image: "1" } : {}),
        ...(galleryPatch !== undefined ? { gallery: "1" } : {}),
        ...(videosPatch !== undefined ? { videos: "1" } : {}),
        ...(variantsPatch !== undefined ? { variants: "1" } : {}),
        ...(parsed.data.storeVisible !== undefined ? { storeVisible: String(parsed.data.storeVisible) } : {}),
        ...(parsed.data.payments !== undefined ? { payments: String(parsed.data.payments.length) } : {}),
        ...(merchPatch?.featured !== undefined ? { featured: String(merchPatch.featured) } : {}),
        ...(merchPatch?.salePrice !== undefined ? { sale: "1" } : {}),
        ...(merchPatch?.saleEndsAt !== undefined ? { saleEnd: "1" } : {}),
      },
    });

    return NextResponse.json(toModuleRecordDTO(row));
  } catch (error) {
    console.error(`PATCH /api/instances/${id}/module-records/${recordId} failed:`, error);
    return NextResponse.json({ error: "Failed to update record" }, { status: 500 });
  }
}

/**
 * DELETE /api/instances/[id]/module-records/[recordId] — remove one REAL row.
 * Workspace-session guarded; the record must belong to THIS instance.
 * Audit-logged.
 */
export async function DELETE(_req: Request, { params }: RouteContext) {
  const { id, recordId } = await params;
  const guard = await requireInstanceAccess(id, _req);
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const trialLock = await trialLockResponse(id);
  if (trialLock) return trialLock;

  try {
    /* ROUND 146 — same soft-delete law as PATCH: the live DELETE route
     * 404s on trashed rows (trash purge owns them from here). */
    const existing = await db.moduleRecord.findFirst({
      where: { id: recordId, deletedAt: null },
      select: { instanceId: true, moduleId: true },
    });
    if (!existing || existing.instanceId !== id) {
      return NextResponse.json({ error: "Record not found" }, { status: 404 });
    }

    /* ROUND 80 — premium-module plan gate (same law as PATCH above). */
    const gatedFeature = MODULE_FEATURE_GATES[existing.moduleId];
    if (gatedFeature) {
      const gate = await featureGateResponse(id, gatedFeature);
      if (gate) return gate;
    }

    /* ROUND 78 — strict RBAC: deleting an inventory row demands
     * inventory.manage; every other module takes modules.edit. */
    const permCheck = await assertInstancePermission(
      guard.principal,
      moduleWritePermission(existing.moduleId)
    );
    if (permCheck) return permCheck;

    /* ROUND 133 — نظام الورديات: deleting a business record is a business
     * mutation → refused with 403 SHIFT_REQUIRED while no shift is open. */
    const shiftGate = await shiftGateResponse(id);
    if (shiftGate) return shiftGate;

    /* ROUND 87 (trash) — soft delete: the record moves to the workspace
       trash and vanishes from every live surface (workspace tables,
       storefront, reports, exports) while staying restorable; its imageRef
       survives so the GC never collects a restorable product's photo. */
    const { softDelete } = await import("@/lib/server/trash");
    const result = await softDelete("moduleRecord", recordId, {
      kind: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: guard.principal.actorName,
    }, { instanceScope: id });
    if (!result.ok) {
      return NextResponse.json({ error: "Failed to delete record" }, { status: result.status });
    }

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error(`DELETE /api/instances/${id}/module-records/${recordId} failed:`, error);
    return NextResponse.json({ error: "Failed to delete record" }, { status: 500 });
  }
}
