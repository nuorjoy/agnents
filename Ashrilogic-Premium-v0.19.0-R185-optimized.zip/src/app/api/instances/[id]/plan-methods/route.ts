import { NextResponse } from "next/server";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { readPaymentsSettings } from "@/lib/server/plan-orders";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * ROUND 48 — GET /api/instances/[id]/plan-methods — the ACTIVE payment
 * methods offered to this workspace on the subscription page.
 *
 * Only a tenant-SAFE subset is served (id + kind + label): the receiving
 * details (account numbers, IBANs, PayPal/Stripe links) are revealed
 * exclusively on the server-built invoice AFTER an order exists. The list
 * is fully console-managed (banks / wallets / PayPal / Stripe added and
 * edited without code) and works while TRIAL-LOCKED — it is a subscription
 * surface.
 */
export async function GET(_req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, undefined, { permission: "billing.manage" });
  if (guard instanceof NextResponse) return guard;

  try {
    const payments = await readPaymentsSettings();
    return NextResponse.json(
      payments.methods
        .filter((m) => m.active)
        .map((m) => ({ id: m.id, kind: m.kind, label: m.label }))
    );
  } catch (error) {
    console.error(`GET /api/instances/${id}/plan-methods failed:`, error);
    return NextResponse.json({ error: "Failed to list payment methods" }, { status: 500 });
  }
}
