import { NextResponse } from "next/server";
import sharp from "sharp";
import { db } from "@/lib/db";
import { readSiteContent } from "@/lib/server/site-mapper";
import { getImageAsset } from "@/lib/server/image-store";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";

/**
 * ROUND 67 — circular brand favicon.
 *
 * GET /api/instances/[id]/favicon.png renders the workspace's brand identity
 * as a PREMIUM CIRCULAR favicon:
 *
 *   • logo uploaded (Settings → الهوية والعلامة) → white circular badge with
 *     the logo contained inside and the platform's signature gradient ring
 *     (violet → fuchsia → cyan) around it — distinctive and legible at 16px;
 *   • no logo yet → the circular gradient disc carries the white Ashrilogic
 *     "boxes" mark, so every workspace ALWAYS gets a distinctive circular
 *     tab icon the moment its dashboard opens.
 *
 * PUBLIC by design: a favicon is fetched by the browser without credentials
 * (public site pages, the storefront and the dashboard all reference it) and
 * the fallback output is byte-identical for unknown ids — no existence
 * oracle. Output is a 128×128 PNG with transparent corners, cached for 5
 * minutes so logo updates propagate quickly.
 *
 * The same route powers: the dashboard tab (client-injected <link rel=icon>),
 * the settings brand card's live browser-tab preview, and the public site's
 * generateMetadata icons (sites/[id]/page.tsx).
 */

const SIZE = 128;
const RING_RADIUS = 61.5;
const RING_WIDTH = 5;

/** render throttle: 30 rasterizations / min / IP + workspace — each request
 *  runs CPU-bound sharp work on a credential-free surface (fail-open: the
 *  route is read-only, a limiter outage must not break every favicon). */
const FAVICON_RULE = { limit: 30, windowMs: 60 * 1000 };

/** Platform signature gradient (matches the boot splash / brand marks). */
const GRADIENT_STOPS =
  '<linearGradient id="g" x1="0" y1="0" x2="1" y2="1">' +
  '<stop offset="0" stop-color="#6d5dfb"/>' +
  '<stop offset="0.5" stop-color="#d946ef"/>' +
  '<stop offset="1" stop-color="#22d3ee"/>' +
  "</linearGradient>";

/** The Ashrilogic "boxes" mark as pure vector shapes (no text → no font
 *  dependency, no RTL/Arabic glyph issues in librsvg). */
const BOXES_MARK =
  '<g fill="#ffffff" stroke="#ffffff" stroke-width="0.6">' +
  '<rect x="3" y="3" width="7" height="9" rx="1.5"/>' +
  '<rect x="14" y="3" width="7" height="5" rx="1.5"/>' +
  '<rect x="14" y="12" width="7" height="9" rx="1.5"/>' +
  '<rect x="3" y="16" width="7" height="5" rx="1.5"/>' +
  "</g>";

/** Rasterize an SVG fragment into a PNG buffer via sharp. */
async function rasterSvg(svg: string): Promise<Buffer> {
  return sharp(Buffer.from(svg)).png().toBuffer();
}

/** The no-logo fallback: gradient disc + white boxes mark, circular. */
async function fallbackFavicon(): Promise<Buffer> {
  const svg =
    `<svg xmlns="http://www.w3.org/2000/svg" width="${SIZE}" height="${SIZE}">` +
    `<defs>${GRADIENT_STOPS}</defs>` +
    `<circle cx="64" cy="64" r="64" fill="url(#g)"/>` +
    `<g transform="translate(39,39) scale(2.0833)">${BOXES_MARK}</g>` +
    `</svg>`;
  return rasterSvg(svg);
}

/** Compose the circular logo badge: white disc → contained logo → circular
 *  clip (dest-in) → gradient ring overlay. */
async function logoFavicon(logoBuffer: Buffer): Promise<Buffer> {
  /* contain the logo inside the inner area (clear of the ring) */
  const logoLayer = await sharp(logoBuffer)
    .resize(SIZE, SIZE, {
      fit: "contain",
      background: { r: 0, g: 0, b: 0, alpha: 0 },
    })
    .png()
    .toBuffer();

  /* white disc + logo composited on top */
  const disc = await sharp({
    create: {
      width: SIZE,
      height: SIZE,
      channels: 4,
      background: { r: 255, g: 255, b: 255, alpha: 1 },
    },
  })
    .composite([{ input: logoLayer, blend: "over" }])
    .png()
    .toBuffer();

  /* clip everything to a perfect circle (transparent corners) */
  const mask = await rasterSvg(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${SIZE}" height="${SIZE}">` +
      `<circle cx="64" cy="64" r="63" fill="#ffffff"/></svg>`
  );
  const clipped = await sharp(disc)
    .composite([{ input: mask, blend: "dest-in" }])
    .png()
    .toBuffer();

  /* the signature gradient ring on top */
  const ring = await rasterSvg(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${SIZE}" height="${SIZE}">` +
      `<defs>${GRADIENT_STOPS}</defs>` +
      `<circle cx="64" cy="64" r="${RING_RADIUS}" fill="none" stroke="url(#g)" stroke-width="${RING_WIDTH}"/>` +
      `</svg>`
  );

  return sharp(clipped)
    .composite([{ input: ring, blend: "over" }])
    .png({ compressionLevel: 9 })
    .toBuffer();
}

/** Resolve the workspace's stored logo into raw image bytes (managed ref or
 *  legacy data-URL). Null when absent / unreadable. */
async function resolveLogoBytes(instanceId: string): Promise<Buffer | null> {
  const siteRow = await db.site.findUnique({
    where: { instanceId },
    select: { contentJson: true },
  });
  if (!siteRow) return null;
  const logoUrl = readSiteContent(siteRow.contentJson).logoUrl;
  if (!logoUrl) return null;

  const managed = /^\/api\/images\/([a-f0-9]{64})$/.exec(logoUrl);
  if (managed) {
    const asset = await getImageAsset(managed[1]);
    return asset?.buffer ?? null;
  }
  const dataUrl = /^data:image\/(png|jpeg|webp|gif);base64,(.+)$/.exec(logoUrl);
  if (dataUrl) {
    try {
      return Buffer.from(dataUrl[2], "base64");
    } catch {
      return null;
    }
  }
  return null;
}

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;

  /* CPU-bound rasterization behind no auth — bound it per IP + workspace
   * (same client-IP resolution and 429 shape as the other public routes). */
  if (await rateLimited(`favicon:${id}:${clientIp(req)}`, FAVICON_RULE)) {
    return tooManyRequests(FAVICON_RULE, { error: "Too many requests" });
  }

  try {
    const logo = id ? await resolveLogoBytes(id) : null;
    const png = logo
      ? await logoFavicon(logo)
      : await fallbackFavicon();
    return new NextResponse(new Uint8Array(png), {
      status: 200,
      headers: {
        "Content-Type": "image/png",
        "Cache-Control": "public, max-age=300, must-revalidate",
        "X-Content-Type-Options": "nosniff",
      },
    });
  } catch {
    /* never break a page over a favicon — always answer with the mark */
    try {
      const png = await fallbackFavicon();
      return new NextResponse(new Uint8Array(png), {
        status: 200,
        headers: {
          "Content-Type": "image/png",
          "Cache-Control": "public, max-age=300, must-revalidate",
          "X-Content-Type-Options": "nosniff",
        },
      });
    } catch {
      return NextResponse.json({ error: "favicon unavailable" }, { status: 500 });
    }
  }
}
