import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { computeEntitlement } from "@/lib/server/entitlement";
import { computeWorkspaceUsage, storageQuotaMb } from "@/lib/server/usage";
import type { WorkspaceUsageDTO } from "@/lib/types";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * ROUND 47 — GET /api/instances/[id]/usage — REAL workspace storage usage.
 *
 * Every number is computed server-side from the database's own bytes (JSON
 * column octet lengths, row counts, content-addressed image assets actually
 * referenced by this workspace) — there is NO client input anywhere in the
 * computation, so the reported size cannot be forged or manipulated. The
 * quota resolves from the assigned plan (or the trial allowance while no
 * plan is active) and is enforced on every data write.
 */
export async function GET(_req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, undefined, { permission: "billing.manage" });
  if (guard instanceof NextResponse) return guard;

  try {
    /* ROUND 87 — trashed (soft-deleted) workspaces never serve usage */
    const instance = await db.instance.findUnique({
      where: { id, deletedAt: null },
      select: {
        packageId: true,
        trialEndsAt: true,
        planActivatedAt: true,
        planCycle: true,
        package: { select: { maxStorageMb: true } },
      },
    });
    if (!instance) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }

    const entitlement = computeEntitlement(instance);
    const quotaMb = storageQuotaMb(entitlement, instance.package?.maxStorageMb ?? null);
    const usage: WorkspaceUsageDTO = await computeWorkspaceUsage(id, quotaMb);
    return NextResponse.json(usage);
  } catch (error) {
    console.error(`GET /api/instances/${id}/usage failed:`, error);
    return NextResponse.json({ error: "Failed to compute usage" }, { status: 500 });
  }
}
