import { NextResponse } from "next/server";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { listCredentials, removePasskey } from "@/lib/server/webauthn";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string; credentialId: string }> };

/**
 * ROUND 45 — DELETE /api/instances/[id]/passkeys/[credentialId] — remove one
 * of the workspace's passkeys. The subject is pinned to the URL's workspace
 * id inside removePasskey, so credentials can never cross workspaces.
 */
export async function DELETE(req: Request, { params }: RouteContext) {
  const { id, credentialId } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "settings.manage" });
  if (guard instanceof NextResponse) return guard;
  const actor = guard.principal;

  const ok = await removePasskey("instance", id, credentialId);
  if (!ok) {
    return NextResponse.json({ error: "Passkey not found" }, { status: 404 });
  }

  await logAudit({
    actorType: actor.kind === "admin" ? "admin" : "instance",
    actorId: actor.actorId,
    actorName: maskEmail(actor.actorName),
    action: "instance.update",
    targetLabel: "workspace passkey removed",
    meta: { credential: credentialId.slice(0, 12) },
  });

  return NextResponse.json({ ok: true, credentials: await listCredentials("instance", id) });
}
