import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { trialLockResponse, featureGateResponse } from "@/lib/server/entitlement";
import { rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { shiftGateResponse } from "@/lib/server/shift-gate";
import { resyncLoyalty } from "@/lib/server/loyalty-engine";
import { modulePreset } from "@/lib/module-data";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

const RESYNC_RULE = { limit: 10, windowMs: 10 * 60 * 1000 };

/**
 * POST /api/instances/[id]/loyalty/resync — the loyalty page's «مزامنة»
 * action: recompute every customer's stats from the ACTUAL completed POS
 * sales, then rebuild the loyalty rows (tiers, points, values, expiry).
 * Idempotent and self-healing. Permission-gated at the SESSION GUARD
 * (ROUND 145 — modules.edit declared on requireInstanceAccess, the
 * sibling-route idiom), SHIFT-GATED (a business mutation), plan-gated
 * (the loyalty feature), rate-limited, audit-logged.
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;
  /* ROUND 145 — the permission rides the guard call itself (identical
   * tier matrix + PERMISSION_DENIED envelope the inline assert used —
   * assertInstancePermission is exactly the guard's opts.permission
   * check, so the redundant inline call was dropped). */
  const guard = await requireInstanceAccess(id, req, { permission: "modules.edit" });
  if (guard instanceof NextResponse) return guard;

  const trialLock = await trialLockResponse(id);
  if (trialLock) return trialLock;

  /* the loyalty module must be enabled on the workspace */
  const modules = await db.instance.findUnique({
    where: { id },
    select: { modulesJson: true },
  });
  let enabled: string[] = [];
  try {
    const parsed = JSON.parse(modules?.modulesJson ?? "[]") as unknown;
    enabled = Array.isArray(parsed) ? parsed.filter((m): m is string => typeof m === "string") : [];
  } catch {
    enabled = [];
  }
  if (!modules || !enabled.includes("loyalty")) {
    return NextResponse.json(
      { error: "The loyalty module is not enabled on the workspace", code: "MODULE_NOT_ENABLED" },
      { status: 403 }
    );
  }

  /* ROUND 80 — plan gate (loyalty is a premium feature) */
  const featureGate = await featureGateResponse(id, "loyalty");
  if (featureGate) return featureGate;

  /* ROUND 133 — THE SHIFT LAW: a business mutation needs an open shift */
  const shiftGate = await shiftGateResponse(id);
  if (shiftGate) return shiftGate;

  if (await rateLimited(`loyalty-sync:${id}`, RESYNC_RULE)) {
    return tooManyRequests(RESYNC_RULE, { error: "Too many loyalty syncs — try again shortly" });
  }

  try {
    /* keep the module-shape contract visible: the loyalty preset must keep
       its 9-column layout the engine writes (member..status) */
    const preset = modulePreset("loyalty");
    if (preset.cols.length < 9) {
      return NextResponse.json({ error: "Loyalty preset contract changed — engine needs 9 columns" }, { status: 500 });
    }

    const result = await resyncLoyalty(id);

    await logAudit({
      actorType: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: maskEmail(guard.principal.actorName),
      action: "instance.loyaltySync",
      targetLabel: "loyalty",
      meta: {
        customers: String(result.customersSynced),
        members: String(result.loyaltyRows),
        created: String(result.loyaltyCreated),
      },
    });

    return NextResponse.json({ ok: true, result });
  } catch (error) {
    console.error(`POST /api/instances/${id}/loyalty/resync failed:`, error);
    return NextResponse.json({ error: "Failed to sync loyalty" }, { status: 500 });
  }
}
