import { NextResponse } from "next/server";
import { z } from "zod";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { featureGateResponse } from "@/lib/server/entitlement";
import {rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { maskEmail } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { zodError } from "@/lib/server/instance-mapper";
import { restoreInstanceBackup, verifyInstanceBackup } from "@/lib/server/backup";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * Restore is the heaviest mutation in the product — a full-tenant
 * transactional write. 4 per hour per instance.
 */
const RESTORE_RULE = { windowMs: 3_600_000, limit: 4 };

/** The upload carries the whole workspace envelope — 25 MB ceiling. */
const RESTORE_BODY_LIMIT_BYTES = 25_000_000;

const bodySchema = z.object({
  /** true = integrity pre-check only (no writes); false = perform the restore */
  verifyOnly: z.boolean(),
  /** the parsed backup file */
  payload: z.unknown(),
});

/** Email-shaped values are PII — mask them for the audit trail; plain admin
 *  handles ("sarah.super") pass through so the trail stays correlatable. */
const EMAIL_SHAPE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function auditActorName(name: string): string {
  return EMAIL_SHAPE.test(name) ? maskEmail(name) : name;
}

/**
 * POST /api/instances/[id]/restore — verify or restore THIS workspace from
 * an uploaded backup file (round 41).
 *
 * Body: { verifyOnly: boolean, payload: <parsed backup JSON> }
 *
 *  - verifyOnly:true  → ALWAYS 200 { ok, meta, reason? } — a bad file is a
 *    *result*, not a request error, so the client can present
 *    bkInvalidFile / bkWrongSystem precisely. Only a non-object payload
 *    (not even a JSON envelope) is a 400.
 *  - verifyOnly:false → the file is re-verified SERVER-SIDE (the client's
 *    verification is never trusted); a failure is 409 with
 *    BACKUP_INVALID / BACKUP_WRONG_SYSTEM, and a success lands the whole
 *    restore transactionally (either everything or nothing).
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;

  /* auth BEFORE the 25 MB body read — an unauthenticated caller must never
     burn a capped body read (the tickets/site routes read first, but their
     caps are 1–2 MB; this one is 12× larger, so the guard runs first) */
  const guard = await requireInstanceAccess(id, req, { permission: "settings.manage" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const featureLock = await featureGateResponse(id, "backup");
  if (featureLock) return featureLock;

  const body = await readJson(req, RESTORE_BODY_LIMIT_BYTES);
  if (!body.ok) return body.response;

  if (await rateLimited(`inst-restore:${id}`, RESTORE_RULE)) {
    return tooManyRequests(RESTORE_RULE, { error: "Too many restore attempts — please wait a moment before trying again" });
  }

  const parsed = bodySchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const { verifyOnly, payload } = parsed.data;

  /* ---------- integrity pre-check (never a 4xx for a bad file) ---------- */
  if (verifyOnly) {
    if (typeof payload !== "object" || payload === null || Array.isArray(payload)) {
      return NextResponse.json(
        { error: "Backup payload must be a JSON object" },
        { status: 400 }
      );
    }
    const result = await verifyInstanceBackup(id, payload);
    return NextResponse.json({
      ok: result.ok,
      meta: result.meta ?? null,
      ...(result.reason ? { reason: result.reason } : {}),
    });
  }

  /* ---------- actual restore — re-verify server-side, never trust the client ---------- */
  const verify = await verifyInstanceBackup(id, payload);
  if (!verify.ok) {
    if (verify.reason === "wrong-system") {
      return NextResponse.json(
        { error: "This backup belongs to a different system", code: "BACKUP_WRONG_SYSTEM" },
        { status: 409 }
      );
    }
    return NextResponse.json(
      { error: "Backup file integrity check failed", code: "BACKUP_INVALID" },
      { status: 409 }
    );
  }

  try {
    const result = await restoreInstanceBackup(id, payload, {
      actorType: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: auditActorName(guard.principal.actorName),
    });
    if (!result.ok) {
      if (result.reason === "wrong-system") {
        return NextResponse.json(
          { error: "This backup belongs to a different system", code: "BACKUP_WRONG_SYSTEM" },
          { status: 409 }
        );
      }
      /* ROUND 96 — another worker (or a queued request on another process)
       * holds the restore lease for this tenant; nothing was changed. */
      if (result.reason === "restore-in-progress") {
        return NextResponse.json(
          {
            error: "A restore of this workspace is already in progress — wait for it to finish before starting another",
            code: "RESTORE_IN_PROGRESS",
          },
          { status: 409 }
        );
      }
      /* ROUND 44 — plan enforcement (restore can no longer lift the tenant
         beyond its assigned package — see backup.ts) */
      if (result.reason === "plan-modules") {
        return NextResponse.json(
          {
            error: "The backup enables more modules than your current plan allows — upgrade your plan first",
            code: "PLAN_MODULE_LIMIT",
          },
          { status: 409 }
        );
      }
      if (result.reason === "plan-users") {
        return NextResponse.json(
          {
            error: "The backup holds more team members than your current plan allows — upgrade your plan first",
            code: "PLAN_USER_LIMIT",
          },
          { status: 409 }
        );
      }
      if (result.reason === "unknown-module") {
        return NextResponse.json(
          {
            error: "The backup contains modules that do not belong to this system",
            code: "BACKUP_INVALID",
          },
          { status: 409 }
        );
      }
      /* embedded image bytes failed their SHA-256 re-verification — the file
         was corrupted or tampered with in transit; nothing was changed */
      if (result.reason === "image-checksum") {
        return NextResponse.json(
          {
            error: "Backup image data failed the integrity check",
            code: "BACKUP_IMAGE_INVALID",
          },
          { status: 409 }
        );
      }
      /* sealed envelopes cannot be opened with the running encryption key —
         the backup predates an ASHRILOGIC_DATA_KEY rotation (or the sealed
         cells are corrupt). Nothing was changed; the rotation re-seal
         runbook must run first (README-SETUP.md). */
      if (result.reason === "sealed-key-mismatch") {
        return NextResponse.json(
          {
            error:
              "This backup was sealed with a different encryption key — run the key-rotation re-seal procedure before restoring",
            code: "BACKUP_KEY_MISMATCH",
          },
          { status: 409 }
        );
      }
      return NextResponse.json(
        { error: "Backup file integrity check failed", code: "BACKUP_INVALID" },
        { status: 409 }
      );
    }
    /* the image outcome is part of the contract: a restore that could not
       re-materialize every referenced asset says so, never silently */
    return NextResponse.json({
      ok: true,
      restored: result.restored,
      imagesRestored: result.imagesRestored,
      imagesMissing: result.imagesMissing,
    });
  } catch (error) {
    console.error(`POST /api/instances/${id}/restore failed:`, error);
    return NextResponse.json({ error: "Failed to restore backup" }, { status: 500 });
  }
}
