import { NextResponse } from "next/server";
import { zodError } from "@/lib/server/instance-mapper";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import {rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { z } from "zod";
import {
  disableMfa,
  getMfaStatus,
  regenerateBackupCodes,
} from "@/lib/server/mfa";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/** Management-action throttling: 10 / 10 min per workspace. */
const MGMT_RULE = { limit: 10, windowMs: 10 * 60 * 1000 };

const manageSchema = z.object({
  action: z.enum(["disable", "regenerate-backups"]),
  code: z.string().trim().min(4).max(20),
});

/**
 * ROUND 45 — POST /api/instances/[id]/mfa — workspace MFA management.
 *
 * body { action: "disable" | "regenerate-backups", code } — both require a
 * live TOTP code or an unused backup code (a stolen session cookie can never
 * silently disarm the workspace's second factor).
 *
 * Enrollment (start/confirm) + status live in /api/instances/[id]/mfa/setup.
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "settings.manage" });
  if (guard instanceof NextResponse) return guard;
  const actor = guard.principal;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = manageSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }

  if (await rateLimited(`inst-mfa-mgmt:${id}`, MGMT_RULE, { failClosed: true })) {
    return tooManyRequests(MGMT_RULE, { error: "Too many attempts — try again later" });
  }

  if (parsed.data.action === "disable") {
    const ok = await disableMfa("instance", id, parsed.data.code);
    if (!ok) {
      return NextResponse.json({ error: "Incorrect verification code" }, { status: 401 });
    }
    await logAudit({
      actorType: actor.kind === "admin" ? "admin" : "instance",
      actorId: actor.actorId,
      actorName: maskEmail(actor.actorName),
      action: "instance.update",
      targetLabel: "workspace two-factor",
      meta: { mfa: "disabled" },
    });
    return NextResponse.json({ ok: true, status: await getMfaStatus("instance", id) });
  }

  const result = await regenerateBackupCodes("instance", id, parsed.data.code);
  if (!result.ok) {
    return NextResponse.json({ error: "Incorrect verification code" }, { status: 401 });
  }
  await logAudit({
    actorType: actor.kind === "admin" ? "admin" : "instance",
    actorId: actor.actorId,
    actorName: maskEmail(actor.actorName),
    action: "instance.update",
    targetLabel: "workspace backup codes",
    meta: { mfa: "backups-regenerated" },
  });
  return NextResponse.json({ ok: true, backupCodes: result.backupCodes });
}
