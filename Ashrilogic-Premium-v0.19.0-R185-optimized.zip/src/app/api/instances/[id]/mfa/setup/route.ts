import { NextResponse } from "next/server";
import { zodError } from "@/lib/server/instance-mapper";
import { readWorkspaceEmail, requireInstanceAccess } from "@/lib/server/instance-session";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import {rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { z } from "zod";
import {
  confirmMfaEnrollment,
  getMfaStatus,
  otpauthQrSvg,
  startMfaEnrollment,
} from "@/lib/server/mfa";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/** Enrollment throttling: 6 starts / 10 min per workspace. */
const SETUP_RULE = { limit: 6, windowMs: 10 * 60 * 1000 };

const confirmSchema = z.object({ code: z.string().trim().regex(/^\d{6}$/) });

/**
 * ROUND 45 — workspace TOTP enrollment (two-step), managed from the tenant
 * settings security card.
 *
 * GET  — { enabled, pending, backupCodesLeft }
 * POST — START: fresh sealed secret (disabled) + otpauth URI + QR SVG.
 * PUT  — CONFIRM: { code } enables MFA and returns the 10 backup codes
 *        (their only plaintext moment).
 */
export async function GET(_req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, undefined, { permission: "settings.manage" });
  if (guard instanceof NextResponse) return guard;
  return NextResponse.json(await getMfaStatus("instance", id));
}

export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "settings.manage" });
  if (guard instanceof NextResponse) return guard;
  const actor = guard.principal;

  if (await rateLimited(`inst-mfa-setup:${id}`, SETUP_RULE, { failClosed: true })) {
    return tooManyRequests(SETUP_RULE, { error: "Too many enrollment attempts — try again later" });
  }

  /* label the authenticator entry with the workspace admin email (or org) */
  const email = await readWorkspaceEmail(id);
  const label = email || `workspace-${id.slice(0, 8)}`;
  const started = await startMfaEnrollment("instance", id, label);
  if ("alreadyEnabled" in started) {
    return NextResponse.json(
      { error: "Two-factor is already enabled — disable it first" },
      { status: 409 }
    );
  }

  await logAudit({
    actorType: actor.kind === "admin" ? "admin" : "instance",
    actorId: actor.actorId,
    actorName: maskEmail(actor.actorName),
    action: "instance.update",
    targetLabel: "workspace two-factor enrollment",
    meta: { mfa: "setup-started" },
  });

  return NextResponse.json({
    otpauth: started.otpauth,
    secret: started.secret,
    qrSvg: await otpauthQrSvg(started.otpauth),
  });
}

export async function PUT(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "settings.manage" });
  if (guard instanceof NextResponse) return guard;
  const actor = guard.principal;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = confirmSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }

  const result = await confirmMfaEnrollment("instance", id, parsed.data.code);
  if (!result.ok) {
    return NextResponse.json(
      {
        error:
          result.reason === "invalid"
            ? "Incorrect code — try again"
            : "Start the enrollment first",
      },
      { status: 400 }
    );
  }

  await logAudit({
    actorType: actor.kind === "admin" ? "admin" : "instance",
    actorId: actor.actorId,
    actorName: maskEmail(actor.actorName),
    action: "instance.update",
    targetLabel: "workspace two-factor",
    meta: { mfa: "enabled" },
  });

  return NextResponse.json({
    ok: true,
    backupCodes: result.backupCodes,
    status: await getMfaStatus("instance", id),
  });
}
