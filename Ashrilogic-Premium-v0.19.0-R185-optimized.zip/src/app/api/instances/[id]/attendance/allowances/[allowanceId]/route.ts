import { allowanceDelete } from "@/server/domains/attendance/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 166 — الحضور والغياب (attendance):
 *   DELETE /api/instances/[id]/attendance/allowances/[allowanceId] —
 *        remove one allowance (instance-scoped; 404 when absent).
 *        Owner/staff write (modules.edit), audited.
 *
 * The handler lives in the attendance domain — thin route delegation.
 */
export const DELETE = allowanceDelete;
