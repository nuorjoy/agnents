import { allowancesGet, allowancesPost } from "@/server/domains/attendance/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 166 — الحضور والغياب (attendance):
 *   GET /api/instances/[id]/attendance/allowances — upcoming + active
 *        allowances (endsAt in the future, soonest first, bounded), each
 *        joined with the roster name; any workspace member.
 *   POST /api/instances/[id]/attendance/allowances — create one:
 *        { studentCode, kind: "excused"|"authorized"|"leave"|"outside",
 *          startsAt, endsAt, note? } — live-resident validated, window
 *        validated (endsAt > startsAt), owner/staff write, audited.
 *
 * The handlers live in the attendance domain — thin route delegation.
 */
export const GET = allowancesGet;
export const POST = allowancesPost;
