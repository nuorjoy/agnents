import { qrRedeem } from "@/server/domains/attendance/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 166 — الحضور والغياب (attendance):
 *   POST /api/instances/[id]/attendance/qr/redeem — the GATE KIOSK:
 *        { token }. Deliberately NOT staff-authenticated (the 256-bit
 *        single-use token is the credential — minted minutes earlier by
 *        an authenticated staff member for exactly one student +
 *        direction). Origin-guarded, body-validated, throttled per
 *        instance + IP. The token is claimed single-use via CAS BEFORE
 *        the movement law runs: unknown → 404 QR_NOT_FOUND, expired →
 *        410 QR_EXPIRED, replayed → 410 QR_REUSED; then the SAME
 *        movement rules as the manual path (live roster, alternation,
 *        server stamps, audit).
 *
 * The handler lives in the attendance domain — thin route delegation.
 */
export const POST = qrRedeem;
