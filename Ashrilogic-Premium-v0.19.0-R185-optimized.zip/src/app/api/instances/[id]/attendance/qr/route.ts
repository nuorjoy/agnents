import { qrMint } from "@/server/domains/attendance/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 166 — الحضور والغياب (attendance):
 *   POST /api/instances/[id]/attendance/qr — mint a single-use gate QR
 *        token: { studentCode, direction, gateLabel?, ttlSeconds? } (ttl
 *        clamped 30–300s, default 120). The RAW 256-bit token is shown
 *        exactly once — only its sha256 hash is stored. Returns
 *        { token, expiresAt, qrPayload } where qrPayload is the exact
 *        JSON string the UI renders as the QR code. Owner/staff write
 *        (modules.edit), throttled, audited.
 *
 * The handler lives in the attendance domain — thin route delegation.
 */
export const POST = qrMint;
