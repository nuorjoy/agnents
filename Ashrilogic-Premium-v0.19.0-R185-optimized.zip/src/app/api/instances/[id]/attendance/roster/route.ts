import { rosterGet } from "@/server/domains/attendance/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 166 — الحضور والغياب (attendance):
 *   GET /api/instances/[id]/attendance/roster?date=YYYY-MM-DD — the day
 *        board: the live residents roster (module "residents"), each
 *        student's DERIVED state (never persisted — Movements + Policy +
 *        Allowances through the pure 8-state engine) and the per-state
 *        counts. Date defaults to today (server-local); any workspace
 *        member (modules.view).
 *
 * The handler lives in the attendance domain — thin route delegation.
 */
export const GET = rosterGet;
