import { policyGet, policyPut } from "@/server/domains/attendance/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 166 — الحضور والغياب (attendance):
 *   GET /api/instances/[id]/attendance/policy — the workspace's attendance
 *        policy (lazily created with the schema defaults on first read);
 *        any workspace member (modules.view).
 *   PUT /api/instances/[id]/attendance/policy — update the policy (zod:
 *        dayStartMin/dayEndMin/absenceEvalMin 0–1439 with the cross-field
 *        window law, graceMin 0–240, requireReview bool); owner/staff
 *        write (modules.edit), audited with old→new values.
 *
 * The handlers live in the attendance domain
 * (src/server/domains/attendance) — this file is the thin route delegation.
 */
export const GET = policyGet;
export const PUT = policyPut;
