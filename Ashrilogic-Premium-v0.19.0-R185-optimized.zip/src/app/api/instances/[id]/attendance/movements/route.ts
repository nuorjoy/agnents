import { movementsGet, movementsPost } from "@/server/domains/attendance/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 166 — الحضور والغياب (attendance):
 *   GET /api/instances/[id]/attendance/movements?cursor=&limit= — the
 *        movements feed, newest first, KEYSET-paginated (createdAt+id
 *        cursor, limit clamped 20–100), each row joined with the roster
 *        name + the student's derived state for that movement's day.
 *   POST /api/instances/[id]/attendance/movements — a MANUAL movement:
 *        { studentCode, direction: "in"|"out" }. occurredAt/recordedBy
 *        are SERVER-stamped (never client input); the student must be a
 *        live resident; strict in/out alternation per day (409
 *        DUPLICATE_CHECK_IN / INVALID_CHECK_OUT / DUPLICATE_CHECK_OUT).
 *        Owner/staff write (modules.edit), throttled, audited; returns
 *        the movement + the freshly derived day state.
 *
 * The handlers live in the attendance domain — thin route delegation.
 */
export const GET = movementsGet;
export const POST = movementsPost;
