import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toInstanceDTO, toActivityDTO, toMemberDTO } from "@/lib/server/instance-mapper";
import { computeInstanceStatsFromDb, loadInstanceAggregates } from "@/lib/server/stats";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { featureGateResponse } from "@/lib/server/entitlement";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { toDisplayUnits } from "@/lib/server/money";
import { parseOrderSnapshot, parseStatusHistory } from "@/lib/server/order-snapshot";
import type { SiteOrderAdminDTO, SiteOrderItemDTO, SiteOrderStatus } from "@/lib/types";
import type { SiteOrder } from "@prisma/client";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };
type ExportType = "activities" | "members" | "summary" | "orders";
type ExportFormat = "csv" | "json";

const EXPORT_TYPES: ExportType[] = ["activities", "members", "summary", "orders"];
/** hard cap on exported rows — exports stay memory-bounded (round 36) */
const EXPORT_ROW_CAP = 5000;
/** export throttling — heavy authenticated reads (round 36) */
const EXPORT_RULE = { limit: 12, windowMs: 10 * 60 * 1000 };

/**
 * RFC 4180 escaping: quote fields containing commas, quotes or newlines.
 * ROUND 36 — CSV formula injection defense: any cell whose first character
 * is a formula initiator (=, +, -, @, tab, CR) is neutralized with a leading
 * apostrophe so Excel/LibreOffice/Sheets render it as text instead of
 * evaluating it (=cmd|…, =HYPERLINK(…), +SUM(…) payloads).
 */
const FORMULA_PREFIX = /^[=+\-@\t\r]/;

function csvEscape(value: string): string {
  let cell = value;
  if (FORMULA_PREFIX.test(cell)) cell = `'${cell}`;
  if (/[",\n\r]/.test(cell)) return `"${cell.replace(/"/g, '""')}"`;
  return cell;
}

function csvRow(values: (string | number)[]): string {
  return values.map((v) => csvEscape(String(v))).join(",");
}

function metaToCsv(meta: unknown): string {
  if (meta == null || (typeof meta === "object" && Object.keys(meta as object).length === 0)) return "";
  try {
    return JSON.stringify(meta);
  } catch {
    return "";
  }
}

/* ======================================================================
 * ROUND 59 — order history export (type=orders): the merchant's storefront
 * order history for accounting/Excel. ONE mapper feeds BOTH formats (CSV
 * and JSON can never disagree); it is modeled on toOrderDTO in
 * /api/instances/[id]/orders:
 *  - v2 snapshots (integer minor-unit prices — every order since the money
 *    migration) convert minor→display units via toDisplayUnits;
 *  - legacy v1 arrays render raw (their numbers are display floats);
 *  - malformed itemsJson degrades to an empty item list (never 500s);
 *  - the ROUND 56 status trail parses via the shared order-snapshot lib.
 * ==================================================================== */

/** The six storefront order lifecycle statuses (mirrors the orders route). */
const ORDER_STATUSES = new Set([
  "pending",
  "confirmed",
  "preparing",
  "ready",
  "completed",
  "cancelled",
]);

/** An order row as the export include shapes it (+ the joined customer name). */
type OrderExportRow = SiteOrder & { customer: { name: string } };

/** Map one order row to its export DTO (SiteOrderAdminDTO-compatible). */
function toOrderExportDTO(row: OrderExportRow): SiteOrderAdminDTO {
  const { items: parsedItems, legacy } = parseOrderSnapshot(row.itemsJson);
  const items: SiteOrderItemDTO[] = parsedItems.map((it) =>
    legacy ? { ...it, image: it.image ?? null } : { ...it, price: toDisplayUnits(it.price), image: it.image ?? null }
  );
  const total = legacy ? row.total : toDisplayUnits(row.total);
  const discount = legacy ? 0 : toDisplayUnits(row.discount);
  return {
    id: row.id,
    code: row.code,
    items,
    total,
    discount,
    couponCode: row.couponCode,
    currency: row.currency,
    status: (ORDER_STATUSES.has(row.status) ? row.status : "pending") as SiteOrderStatus,
    note: row.note,
    statusNote: row.statusNote,
    statusHistory: parseStatusHistory(row.statusHistoryJson),
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
    customerId: row.customerId,
    customerName: row.customer.name,
  };
}

/**
 * GET /api/instances/[id]/export?type=activities|members|summary|orders&format=csv|json
 * Downloads a CSV (UTF-8 BOM so Excel renders Arabic correctly) or a rich JSON
 * document (instance DTO + related rows; summary also embeds deterministic
 * stats). Authorized by the workspace session or an admin session (cookie
 * rides along with the download navigation). ROUND 59 adds type=orders — the
 * storefront order history (newest first, row-capped, display units) for
 * merchant accounting/Excel.
 */
export async function GET(req: Request, { params }: RouteContext) {
  const { id } = await params;

  const guard = await requireInstanceAccess(id, undefined, { permission: "exports.run" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const featureLock = await featureGateResponse(id, "dataExport");
  if (featureLock) return featureLock;

  /* round 36 — export throttling (expensive bounded reads) */
  if (await rateLimited(`export:${id}:${clientIp(req)}`, EXPORT_RULE)) {
    return tooManyRequests(EXPORT_RULE, { error: "Too many exports — please wait a moment before downloading again" });
  }

  const url = new URL(req.url);
  const type = url.searchParams.get("type") as ExportType | null;
  const format = (url.searchParams.get("format") ?? "csv") as ExportFormat;

  if (!type || !EXPORT_TYPES.includes(type)) {
    return NextResponse.json(
      { error: `Invalid export type — expected one of: ${EXPORT_TYPES.join(", ")}` },
      { status: 400 }
    );
  }
  if (format !== "csv" && format !== "json") {
    return NextResponse.json({ error: "Invalid export format — expected csv or json" }, { status: 400 });
  }

  try {
    const row = await db.instance.findUnique({
      where: { id },
      include: {
        /* round 36 — bounded export queries (was unbounded include) */
        activities: { orderBy: [{ createdAt: "desc" }, { id: "desc" }], take: EXPORT_ROW_CAP },
        members: { orderBy: { createdAt: "asc" }, take: EXPORT_ROW_CAP },
        /* round 59 — order history: newest first, bounded, + customer name */
        orders: {
          orderBy: [{ createdAt: "desc" }, { id: "desc" }],
          take: EXPORT_ROW_CAP,
          include: { customer: { select: { name: true } } },
        },
      },
    });
    if (!row) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }

    /* ------------------------------ JSON ------------------------------ */
    if (format === "json") {
      const dto = toInstanceDTO(row);
      const activities = [...row.activities]
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
        .map(toActivityDTO);
      const members = row.members
        .slice()
        .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime())
        .map(toMemberDTO);
      /* round 59 — order DTOs (already newest-first from the bounded query) */
      const orders = row.orders.map(toOrderExportDTO);

      const payload: Record<string, unknown> =
        type === "activities"
          ? {
              exportedAt: new Date().toISOString(),
              instance: { id: row.id, systemId: dto.systemId, org: dto.org.name },
              count: activities.length,
              activities,
            }
          : type === "members"
            ? {
                exportedAt: new Date().toISOString(),
                instance: { id: row.id, systemId: dto.systemId, org: dto.org.name },
                count: members.length,
                members,
              }
            : type === "orders"
              ? {
                  exportedAt: new Date().toISOString(),
                  instance: { id: row.id, systemId: dto.systemId, org: dto.org.name },
                  count: orders.length,
                  orders,
                }
              : {
                  exportedAt: new Date().toISOString(),
                  instance: { id: row.id, systemId: dto.systemId, org: dto.org },
                  admin: dto.admin,
                  prefs: dto.prefs,
                  modules: dto.modules,
                  counts: {
                    modules: dto.modules.length,
                    members: members.length,
                    activities: activities.length,
                  },
                  /* ROUND 61 (H-8) — real aggregates where real order
                   * history exists (demo flag included either way) */
                  stats: computeInstanceStatsFromDb(
                    row.id,
                    dto.prefs.lang,
                    await loadInstanceAggregates([row.id])
                  ),
                };

      return new NextResponse(JSON.stringify(payload, null, 2), {
        status: 200,
        headers: {
          "Content-Type": "application/json; charset=utf-8",
          "Content-Disposition": `attachment; filename="ashrilogic-${type}-${id}.json"`,
          "Cache-Control": "no-store",
        },
      });
    }

    /* ------------------------------ CSV ------------------------------- */
    const lines: string[] = [];

    if (type === "activities") {
      lines.push(csvRow(["id", "kind", "meta", "createdAt"]));
      [...row.activities]
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
        .forEach((a) => lines.push(csvRow([a.id, a.kind, metaToCsv(a.metaJson), a.createdAt.toISOString()])));
    } else if (type === "members") {
      lines.push(csvRow(["id", "name", "email", "role", "createdAt"]));
      row.members
        .slice()
        .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime())
        /* round 36 — decrypt the sealed email (was exporting raw ciphertext) */
        .forEach((m) =>
          lines.push(
            csvRow([m.id, m.name, toMemberDTO(m).email, m.role, m.createdAt.toISOString()])
          )
        );
    } else if (type === "orders") {
      lines.push(
        csvRow([
          "id",
          "code",
          "status",
          "createdAt",
          "updatedAt",
          "customerName",
          "itemCount",
          "currency",
          "total",
          "discount",
          "couponCode",
          "note",
        ])
      );
      /* round 59 — one row per order; money in DISPLAY units (v2 rows come
         through toDisplayUnits; legacy v1 rows already are display floats —
         same rule as toOrderDTO); itemCount = parsed snapshot items length;
         nullable code/couponCode/note → empty string */
      row.orders.forEach((o) => {
        const dto = toOrderExportDTO(o);
        lines.push(
          csvRow([
            dto.id,
            dto.code ?? "",
            dto.status,
            dto.createdAt,
            dto.updatedAt,
            dto.customerName,
            dto.items.length,
            dto.currency,
            dto.total,
            dto.discount,
            dto.couponCode ?? "",
            dto.note ?? "",
          ])
        );
      });
    } else {
      // summary
      const dto = toInstanceDTO(row);
      const summary: [string, string][] = [
        ["System ID", dto.systemId],
        ["Organization", dto.org.name],
        ["Country", dto.org.country],
        ["Currency", dto.org.currency],
        ["Timezone", dto.org.timezone],
        ["Admin", dto.admin.name],
        ["Admin Email", dto.admin.email],
        ["Language", dto.prefs.lang],
        ["Theme", dto.prefs.theme],
        ["Module Count", String(dto.modules.length)],
        ["Member Count", String(row.members.length)],
        ["Activity Count", String(row.activities.length)],
        ["Created At", dto.createdAt],
      ];
      lines.push(csvRow(["key", "value"]));
      summary.forEach(([key, value]) => lines.push(csvRow([key, value])));
    }

    // BOM prefix → Excel detects UTF-8 and renders Arabic correctly.
    const csv = `\uFEFF${lines.join("\n")}\n`;
    return new NextResponse(csv, {
      status: 200,
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="ashrilogic-${type}-${id}.csv"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    console.error(`GET /api/instances/${id}/export failed:`, error);
    return NextResponse.json({ error: "Failed to export data" }, { status: 500 });
  }
}
