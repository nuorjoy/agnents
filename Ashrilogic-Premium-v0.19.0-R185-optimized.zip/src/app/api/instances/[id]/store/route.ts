import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { featureGateResponse } from "@/lib/server/entitlement";
import {
  attachRatingAggregates,
  loadStoreProducts,
  loadStoreProductsForOwner,
  storeInfo,
} from "@/lib/server/store-mapper";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * GET /api/instances/[id]/store — the OWNER-scoped storefront status for the
 * dashboard's E-Store view (round 44).
 *
 * Unlike the public /api/sites/[id]/store route (published sites only), this
 * answers for DRAFT sites too: the owner needs to see availability, the
 * listed-product count and the live categories while the website is still
 * unpublished. Prices/stock are derived server-side from the same catalog
 * module mapping — the client never gets to declare them.
 *
 * ROUND 51 — the response now carries the FULL owner catalog (unfiltered by
 * sellability, capped at OWNER_CATALOG_CAP) so the E-Store products console
 * can manage product photos per row; `productCount` keeps its original
 * semantics (the SELLABLE rows the public storefront actually lists).
 */
export async function GET(_req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, undefined, { permission: "orders.manage" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const featureLock = await featureGateResponse(id, "store");
  if (featureLock) return featureLock;

  try {
    /* trashed (soft-deleted) workspaces never serve a store status */
    const instance = await db.instance.findUnique({ where: { id, deletedAt: null } });
    if (!instance) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }

    const site = await db.site.findUnique({
      where: { instanceId: id },
      select: { published: true, launchedAt: true, views: true },
    });

    const info = storeInfo(instance);
    if (!info.available) {
      return NextResponse.json({
        available: false,
        moduleId: null,
        currency: info.currency,
        published: site?.published ?? false,
        products: [],
        categories: [],
        productCount: 0,
      });
    }

    const [products, ownerProducts] = await Promise.all([
      loadStoreProducts(instance),
      loadStoreProductsForOwner(instance),
    ]);

    /* ROUND 63 — rating aggregates for the E-Store products console chips:
       attached to the OWNER catalog (the payload's `products` array) so the
       merchant sees the same stars the storefront shows. */
    await attachRatingAggregates(ownerProducts, id);

    return NextResponse.json({
      ...info,
      published: site?.published ?? false,
      products: ownerProducts,
      categories: [...new Set(products.map((p) => p.category).filter(Boolean))].sort(),
      productCount: products.length,
    });
  } catch (error) {
    console.error(`GET /api/instances/${id}/store failed:`, error);
    return NextResponse.json({ error: "Failed to load the store status" }, { status: 500 });
  }
}
