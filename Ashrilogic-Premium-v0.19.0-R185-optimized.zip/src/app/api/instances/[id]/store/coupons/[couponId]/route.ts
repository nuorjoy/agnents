import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { shiftGateResponse } from "@/lib/server/shift-gate";
import { featureGateResponse } from "@/lib/server/entitlement";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { couponPatchSchema, applyCouponPatch } from "@/lib/server/coupon-patch";
import type { StoreCouponDTO } from "@/lib/types";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string; couponId: string }> };

/** owner mutation throttling: 30 coupon writes / 10 min per source IP. */
const COUPON_RULE = { limit: 30, windowMs: 10 * 60 * 1000 };

const EMAIL_SHAPE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function auditActorName(name: string): string {
  return EMAIL_SHAPE.test(name) ? maskEmail(name) : name;
}

function toCouponDTO(
  c: import("@prisma/client").StoreCoupon,
  now = new Date()
): StoreCouponDTO {
  const state: StoreCouponDTO["state"] = !c.active
    ? "disabled"
    : c.startsAt && now < c.startsAt
      ? "scheduled"
      : c.expiresAt && now > c.expiresAt
        ? "expired"
        : c.maxUses != null && c.usedCount >= c.maxUses
          ? "exhausted"
          : "live";
  return {
    id: c.id,
    code: c.code,
    kind: c.kind === "fixed" ? "fixed" : "percent",
    value: c.value,
    minSubtotal: c.minSubtotal,
    maxUses: c.maxUses,
    usedCount: c.usedCount,
    startsAt: c.startsAt?.toISOString() ?? null,
    expiresAt: c.expiresAt?.toISOString() ?? null,
    active: c.active,
    state,
    createdAt: c.createdAt.toISOString(),
  };
}

/* ------------------------------------------------------------------ *
 * PATCH body schema + the transactional merge engine live in
 * src/lib/server/coupon-patch.ts (ROUND 112 — lost-update fix: the merge
 * base is read INSIDE the write transaction; see that module's header
 * for the concurrent-owner-edit scenario it closes).
 * ------------------------------------------------------------------ */

/**
 * PATCH /api/instances/[id]/store/coupons/[couponId] — edit / toggle a
 * coupon. Scoped lookup (instanceId + id) so a cross-tenant id is a plain
 * 404; the code itself is immutable (history on orders references it).
 */
export async function PATCH(req: Request, { params }: RouteContext) {
  const { id, couponId } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "website.manage" });
  if (guard instanceof NextResponse) return guard;

  const featureLock = await featureGateResponse(id, "coupons");
  if (featureLock) return featureLock;

  /* ROUND 133 — نظام الورديات: coupon writes are business mutations →
     403 SHIFT_REQUIRED while no shift is open. */
  const shiftGate = await shiftGateResponse(id);
  if (shiftGate) return shiftGate;

  if (await rateLimited(`coupon-write:${id}:${clientIp(req)}`, COUPON_RULE)) {
    return tooManyRequests(COUPON_RULE, { error: "Too many changes — try again shortly", code: "RATE" });
  }

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = couponPatchSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid coupon update" }, { status: 400 });
  }

  try {
    const result = await applyCouponPatch(id, couponId, parsed.data);
    if (!result.ok) {
      return NextResponse.json({ error: result.error }, { status: result.status });
    }

    await logAudit({
      actorType: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: auditActorName(guard.principal.actorName),
      action: "instance.couponUpdate",
      targetLabel: result.row.code,
    });

    return NextResponse.json(toCouponDTO(result.row));
  } catch (error) {
    console.error(`PATCH /api/instances/${id}/store/coupons/${couponId} failed:`, error);
    return NextResponse.json({ error: "Failed to update the coupon" }, { status: 500 });
  }
}

/**
 * DELETE /api/instances/[id]/store/coupons/[couponId] — remove a coupon.
 * Orders that redeemed it keep their couponCode + discount snapshot
 * (historical totals never change); only future redemptions stop.
 */
export async function DELETE(req: Request, { params }: RouteContext) {
  const { id, couponId } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "website.manage" });
  if (guard instanceof NextResponse) return guard;

  const featureLock = await featureGateResponse(id, "coupons");
  if (featureLock) return featureLock;

  /* ROUND 133 — نظام الورديات: coupon writes are business mutations →
     403 SHIFT_REQUIRED while no shift is open. */
  const shiftGate = await shiftGateResponse(id);
  if (shiftGate) return shiftGate;

  if (await rateLimited(`coupon-write:${id}:${clientIp(req)}`, COUPON_RULE)) {
    return tooManyRequests(COUPON_RULE, { error: "Too many changes — try again shortly", code: "RATE" });
  }

  try {
    /* ROUND 146 — a trashed coupon is dead to the live DELETE route
     * (trash purge owns it from here; the code is already mangled) */
    const existing = await db.storeCoupon.findFirst({
      where: { id: couponId, instanceId: id, deletedAt: null },
      select: { id: true, code: true },
    });
    if (!existing) {
      return NextResponse.json({ error: "Coupon not found" }, { status: 404 });
    }

    /* ROUND 87 (trash) — soft delete: the coupon moves to the workspace
       trash (code mangled, original kept for conflict-checked restore) and
       stops validating at checkout immediately. */
    const { softDelete } = await import("@/lib/server/trash");
    const result = await softDelete("storeCoupon", existing.id, {
      kind: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: guard.principal.actorName,
    }, { instanceScope: id });
    if (!result.ok) {
      return NextResponse.json({ error: "Failed to delete the coupon" }, { status: result.status });
    }

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error(`DELETE /api/instances/${id}/store/coupons/${couponId} failed:`, error);
    return NextResponse.json({ error: "Failed to delete the coupon" }, { status: 500 });
  }
}
