import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { shiftGateResponse } from "@/lib/server/shift-gate";
import { featureGateResponse } from "@/lib/server/entitlement";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { storeModuleId } from "@/lib/server/store-mapper";
import { isValidMinorUnits, MAX_MINOR_UNITS } from "@/lib/server/money";
import {
  COUPON_KINDS,
  isValidCouponCode,
  normalizeCouponCode,
} from "@/lib/server/coupons";
import type { StoreCouponDTO } from "@/lib/types";
import type { StoreCoupon } from "@prisma/client";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/** owner mutation throttling: 30 coupon writes / 10 min per source IP. */
const COUPON_RULE = { limit: 30, windowMs: 10 * 60 * 1000 };

/** listing bound — a workspace realistically runs a handful of codes. */
const COUPON_LIST_CAP = 200;

const EMAIL_SHAPE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function auditActorName(name: string): string {
  return EMAIL_SHAPE.test(name) ? maskEmail(name) : name;
}

/** Lifecycle badge a coupon renders with (derived, not stored). */
function couponState(c: StoreCoupon, now = new Date()): StoreCouponDTO["state"] {
  if (!c.active) return "disabled";
  if (c.startsAt && now < c.startsAt) return "scheduled";
  if (c.expiresAt && now > c.expiresAt) return "expired";
  if (c.maxUses != null && c.usedCount >= c.maxUses) return "exhausted";
  return "live";
}

export function toCouponDTO(c: StoreCoupon): StoreCouponDTO {
  return {
    id: c.id,
    code: c.code,
    kind: c.kind === "fixed" ? "fixed" : "percent",
    value: c.value,
    minSubtotal: c.minSubtotal,
    maxUses: c.maxUses,
    usedCount: c.usedCount,
    startsAt: c.startsAt?.toISOString() ?? null,
    expiresAt: c.expiresAt?.toISOString() ?? null,
    active: c.active,
    state: couponState(c),
    createdAt: c.createdAt.toISOString(),
  };
}

/* ------------------------------ schemas ------------------------------ */

const createSchema = z
  .object({
    code: z.string().trim().min(3).max(32),
    kind: z.enum(COUPON_KINDS),
    value: z.number().int(),
    minSubtotal: z.number().int().min(1).max(MAX_MINOR_UNITS).nullable().optional(),
    maxUses: z.number().int().min(1).max(1_000_000).nullable().optional(),
    startsAt: z.string().datetime().nullable().optional(),
    expiresAt: z.string().datetime().nullable().optional(),
    active: z.boolean().optional(),
  })
  .refine(
    (v) =>
      v.kind === "percent"
        ? v.value >= 1 && v.value <= 99
        : isValidMinorUnits(v.value) && v.value > 0,
    { message: "percent coupons take 1–99; fixed coupons take a positive minor-unit amount" }
  )
  .refine(
    (v) => !v.startsAt || !v.expiresAt || Date.parse(v.startsAt) < Date.parse(v.expiresAt),
    { message: "the redemption window must start before it ends" }
  );

/**
 * GET /api/instances/[id]/store/coupons — the owner's coupon list for the
 * dashboard E-Store view (newest first, bounded).
 */
export async function GET(_req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, undefined, { permission: "website.manage" });
  if (guard instanceof NextResponse) return guard;

  const featureLock = await featureGateResponse(id, "coupons");
  if (featureLock) return featureLock;

  try {
    const rows = await db.storeCoupon.findMany({
      where: { instanceId: id, deletedAt: null },
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: COUPON_LIST_CAP,
    });
    return NextResponse.json({ coupons: rows.map(toCouponDTO) });
  } catch (error) {
    console.error(`GET /api/instances/${id}/store/coupons failed:`, error);
    return NextResponse.json({ error: "Failed to load coupons" }, { status: 500 });
  }
}

/**
 * POST /api/instances/[id]/store/coupons — create a storefront coupon.
 *
 * SECURITY: the code is normalized server-side and checked structurally +
 * for per-workspace uniqueness (409 on collision); value semantics are
 * re-validated (percent 1–99 / fixed minor units) — the client never gets
 * to declare a discount shape the placement path would not honor.
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "website.manage" });
  if (guard instanceof NextResponse) return guard;

  const featureLock = await featureGateResponse(id, "coupons");
  if (featureLock) return featureLock;

  /* ROUND 133 — نظام الورديات: coupon writes are business mutations →
     403 SHIFT_REQUIRED while no shift is open. */
  const shiftGate = await shiftGateResponse(id);
  if (shiftGate) return shiftGate;

  if (await rateLimited(`coupon-write:${id}:${clientIp(req)}`, COUPON_RULE)) {
    return tooManyRequests(COUPON_RULE, { error: "Too many changes — try again shortly", code: "RATE" });
  }

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = createSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid coupon definition" }, { status: 400 });
  }
  const data = parsed.data;

  const code = normalizeCouponCode(data.code);
  if (!isValidCouponCode(code)) {
    return NextResponse.json(
      { error: "Codes are 3–24 letters/digits (separators are stripped automatically)" },
      { status: 400 }
    );
  }

  try {
    /* the storefront must actually exist (a catalog module is enabled) —
     * coupons on a store-less workspace are meaningless. Soft-deleted
     * (trashed) instances never mint new coupons. */
    const instance = await db.instance.findUnique({
      where: { id, deletedAt: null },
      select: { id: true, modulesJson: true },
    });
    if (!instance) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }
    if (!storeModuleId(instance)) {
      return NextResponse.json(
        { error: "Enable a catalog module (products / inventory / menu / pharmacy) first", code: "NO_STORE" },
        { status: 409 }
      );
    }

    const clash = await db.storeCoupon.findUnique({
      where: { instanceId_code: { instanceId: id, code }, deletedAt: null },
      select: { id: true },
    });
    if (clash) {
      return NextResponse.json({ error: "This code already exists", code: "DUPLICATE" }, { status: 409 });
    }

    const row = await db.$transaction(async (tx) => {
      const created = await tx.storeCoupon.create({
        data: {
          instanceId: id,
          code,
          kind: data.kind,
          value: data.value,
          minSubtotal: data.minSubtotal ?? null,
          maxUses: data.maxUses ?? null,
          startsAt: data.startsAt ? new Date(data.startsAt) : null,
          expiresAt: data.expiresAt ? new Date(data.expiresAt) : null,
          active: data.active ?? true,
        },
      });
      await tx.activity.create({
        data: {
          instanceId: id,
          kind: "actCouponCreated",
          metaJson: JSON.stringify({ code, kind: data.kind, value: data.value }),
        },
      });
      return created;
    });

    await logAudit({
      actorType: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: auditActorName(guard.principal.actorName),
      action: "instance.couponCreate",
      targetLabel: code,
    });

    return NextResponse.json(toCouponDTO(row), { status: 201 });
  } catch (error) {
    /* a concurrent twin create loses the (instanceId, code) unique race —
     * surface the same 409 as the sequential pre-check above. */
    if ((error as { code?: string }).code === "P2002") {
      return NextResponse.json(
        { error: "This code already exists", code: "DUPLICATE" },
        { status: 409 }
      );
    }
    console.error(`POST /api/instances/${id}/store/coupons failed:`, error);
    return NextResponse.json({ error: "Failed to create the coupon" }, { status: 500 });
  }
}
