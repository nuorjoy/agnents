import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { zodError } from "@/lib/server/instance-mapper";
import { requireInstanceAccess, assertInstancePermission } from "@/lib/server/instance-session";
import { trialLockResponse, featureGateResponse } from "@/lib/server/entitlement";
import { moduleWritePermission } from "@/lib/permissions";
import { logAudit } from "@/lib/server/audit";
import { readJson, readRawBody } from "@/lib/server/http";
import { rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { storeImageDataUrl } from "@/lib/server/image-store";
import { storeValidatedVideo, VideoValidationError } from "@/lib/server/media-store";
import { storeModuleId } from "@/lib/server/store-mapper";
import { shiftGateResponse } from "@/lib/server/shift-gate";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * POST /api/instances/[id]/store/media — the PRODUCT MEDIA upload leg
 * (ROUND 140 — the owner's directive: 6 photos ≤8 MB each + 2 video clips
 * ≤10 MB each per product).
 *
 * TWO legs on one route, branched by Content-Type:
 *
 *  • application/json  { image: dataUrl }  — a GALLERY PHOTO. The data-URL
 *    runs the FULL image pipeline (magic bytes, dimension/pixel/bomb caps,
 *    sharp re-encode to clean WebP ≤500 KB) and mints a managed
 *    /api/images/<sha> ref. The client normally ships a canvas-compressed
 *    JPEG (fast path), but the raw original (≤8 MB) is accepted too — the
 *    server re-encode is the single authority either way.
 *
 *  • multipart/form-data  video=<file>     — a VIDEO CLIP. Raw bytes
 *    ≤10 MB, magic-byte-verified (MP4 `ftyp` / WebM EBML / QuickTime) with
 *    the declared type cross-checked, stored content-addressed and minted
 *    as /api/videos/<sha>. No server re-encode exists for video; the magic
 *    gate + mime-from-DB-row serving is the security boundary.
 *
 * The route only MINTS refs — the product row's gallery/videos arrays are
 * committed by the ordinary module-records PATCH (which re-validates every
 * ref against the asset tables). Orphaned uploads (a merchant cancelling
 * mid-edit) are reclaimed by the reference GCs past the 24h grace.
 *
 * Guards: workspace session + the STORE module's write permission
 * (inventory.manage for inventory-shaped catalogs, modules.edit otherwise)
 * + trial lock + store feature gate + the strict SHIFT law + a 60/10-min
 * per-instance upload throttle. Audited with the minted ref.
 */

/** 60 uploads / 10 min per workspace (6 images + 2 videos per product). */
const UPLOAD_RULE = { limit: 60, windowMs: 10 * 60 * 1000 };

/** The owner's directive: photo originals up to 8 MB. */
const MAX_IMAGE_INPUT_BYTES = 8 * 1024 * 1024;
/** base64 inflates by 4/3 + the JSON envelope — the bounded-body ceiling. */
const JSON_BODY_CAP = Math.ceil((MAX_IMAGE_INPUT_BYTES * 4) / 3) + 64 * 1024;
/** The multipart ceiling: file ≤10 MB + part overhead. */
const FORM_CAP = 10 * 1024 * 1024 + 512 * 1024;

const imageUploadSchema = z.object({
  image: z.string().min(30).max(JSON_BODY_CAP),
});

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, req);
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown. */
  const trialLock = await trialLockResponse(id);
  if (trialLock) return trialLock;

  /* per-instance upload throttle. */
  if (await rateLimited(`store-media:${id}`, UPLOAD_RULE)) {
    return tooManyRequests(UPLOAD_RULE, { error: "Too many media uploads — try again shortly" });
  }

  /* The write permission follows the instance's STORE module (the catalog
   * these media attach to) — the same resolution the record PATCH applies. */
  const instance = await db.instance.findUnique({
    where: { id, deletedAt: null },
    select: { modulesJson: true },
  });
  if (!instance) {
    return NextResponse.json({ error: "Instance not found" }, { status: 404 });
  }
  const moduleId = storeModuleId(instance);
  if (!moduleId) {
    return NextResponse.json(
      { error: "This workspace has no store catalog module", code: "STORE_MODULE_MISSING" },
      { status: 403 }
    );
  }
  const permCheck = await assertInstancePermission(guard.principal, moduleWritePermission(moduleId));
  if (permCheck) return permCheck;

  /* The store feature gate (same as the E-Store console itself). */
  const featureLock = await featureGateResponse(id, "store");
  if (featureLock) return featureLock;

  /* ROUND 133 — the strict shift law: attaching media to a product is part
   * of a business-record edit (the PATCH that commits the refs is gated the
   * same way; the upload leg must not become the bypass). */
  const shiftGate = await shiftGateResponse(id);
  if (shiftGate) return shiftGate;

  const contentType = (req.headers.get("content-type") ?? "").toLowerCase();

  try {
    /* ------------------------- the PHOTO leg (JSON) ------------------------- */
    if (contentType.includes("application/json")) {
      const body = await readJson(req, JSON_BODY_CAP);
      if (!body.ok) return body.response;

      const parsed = imageUploadSchema.safeParse(body.data);
      if (!parsed.success) {
        return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
      }

      try {
        const stored = await storeImageDataUrl(parsed.data.image, {
          maxInputBytes: MAX_IMAGE_INPUT_BYTES,
          maxOutputBytes: 500 * 1024,
        });
        await logAudit({
          actorType: guard.principal.kind === "admin" ? "admin" : "instance",
          actorId: guard.principal.actorId,
          actorName: guard.principal.actorName,
          action: "store.media-upload",
          targetLabel: stored.url,
          meta: { kind: "image", ref: stored.url, bytes: String(stored.bytes) },
        });
        return NextResponse.json({ url: stored.url, kind: "image" }, { status: 201 });
      } catch (error) {
        const message = error instanceof Error ? error.message : "Invalid image";
        return NextResponse.json({ error: `Image rejected — ${message}` }, { status: 400 });
      }
    }

    /* ------------------------ the VIDEO leg (multipart) --------------------- */
    if (contentType.includes("multipart/form-data")) {
      /* ROUND 146 — the REAL body cap. The previous form checked only the
       * DECLARED Content-Length and then called req.formData(), which
       * buffers the whole body in memory before any route-level size
       * check runs — a chunked or Content-Length-less request (curl's
       * default for stdin uploads) bypassed the declared check entirely,
       * and oversized NON-file fields were equally unbounded. The raw
       * bytes now flow through the chunk-capped stream reader FIRST
       * (FORM_CAP — the exact same law readJson enforces for JSON
       * bodies); the multipart parser then runs on a synthesized Request
       * over the bounded buffer. Memory cost is capped at FORM_CAP no
       * matter how the client encodes or lies. */
      const raw = await readRawBody(req, FORM_CAP);
      if (!raw.ok) {
        if (raw.response.status === 413) {
          return NextResponse.json(
            { error: "Video size exceeds the allowed 10 MB limit" },
            { status: 413 }
          );
        }
        return NextResponse.json({ error: "Malformed upload payload" }, { status: 400 });
      }

      let file: File | null = null;
      try {
        /* parse the multipart from the BOUNDED buffer — content-type only:
         * a synthesized Request must not inherit a stale Content-Length. */
        const formReq = new Request(req.url, {
          method: "POST",
          headers: { "content-type": contentType },
          body: new Uint8Array(raw.bytes),
        });
        const form = await formReq.formData();
        const candidates = form.getAll("video");
        if (candidates.length > 1) {
          /* ONE video part per request — the client contract has always
           * been a single clip; multiple parts previously fell through to
           * first-wins silently, which is undefined behavior on an upload
           * surface. Refused loudly instead. */
          return NextResponse.json(
            { error: "Only one video file is allowed per upload" },
            { status: 400 }
          );
        }
        const candidate = candidates[0];
        if (candidate instanceof File) file = candidate;
      } catch {
        return NextResponse.json({ error: "Malformed upload payload" }, { status: 400 });
      }
      if (!file) {
        return NextResponse.json({ error: "A video file is required" }, { status: 400 });
      }
      if (file.size > 10 * 1024 * 1024) {
        return NextResponse.json(
          { error: "Video size exceeds the allowed 10 MB limit" },
          { status: 413 }
        );
      }

      const buffer = Buffer.from(await file.arrayBuffer());
      try {
        const stored = await storeValidatedVideo(buffer, { declaredMime: file.type });
        await logAudit({
          actorType: guard.principal.kind === "admin" ? "admin" : "instance",
          actorId: guard.principal.actorId,
          actorName: guard.principal.actorName,
          action: "store.media-upload",
          targetLabel: stored.url,
          meta: { kind: "video", ref: stored.url, bytes: String(stored.bytes) },
        });
        return NextResponse.json({ url: stored.url, kind: "video" }, { status: 201 });
      } catch (error) {
        if (error instanceof VideoValidationError) {
          return NextResponse.json({ error: error.message }, { status: 400 });
        }
        throw error;
      }
    }

    return NextResponse.json(
      { error: "Content-Type must be application/json (image) or multipart/form-data (video)" },
      { status: 415 }
    );
  } catch (error) {
    console.error(`POST /api/instances/${id}/store/media failed:`, error);
    return NextResponse.json({ error: "Failed to store the media" }, { status: 500 });
  }
}
