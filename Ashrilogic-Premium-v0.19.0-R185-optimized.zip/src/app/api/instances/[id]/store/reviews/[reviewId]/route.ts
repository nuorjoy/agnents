import { NextResponse } from "next/server";
import { z } from "zod";

import { db } from "@/lib/db";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { featureGateResponse } from "@/lib/server/entitlement";
import { readJson } from "@/lib/server/http";
import { resolveRecordNames } from "@/lib/server/store-mapper";
import type { OwnerReviewDTO } from "@/lib/types";
import type { SiteReview } from "@prisma/client";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string; reviewId: string }> };

const moderationSchema = z.object({ hidden: z.boolean() });

/** Owner-console projection (same shape as the list route's mapper). */
function toOwnerDTO(row: SiteReview, productName: string): OwnerReviewDTO {
  return {
    id: row.id,
    recordId: row.recordId,
    productName,
    rating: row.rating,
    name: row.name,
    body: row.body,
    hidden: row.hidden,
    createdAt: row.createdAt.toISOString(),
  };
}

/**
 * PATCH /api/instances/[id]/store/reviews/[reviewId] — owner moderation
 * (ROUND 63): hide or restore one review. Hidden rows vanish from every
 * public read AND every public aggregate (cards, quick-view, dialog).
 *
 * The compound `where: { id, instanceId }` makes the update tenant-scoped:
 * a reviewId from another workspace simply matches no row (P2025 → 404) —
 * cross-instance review tampering is structurally impossible.
 */
export async function PATCH(req: Request, { params }: RouteContext) {
  const { id, reviewId } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "support.manage" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const featureLock = await featureGateResponse(id, "reviews");
  if (featureLock) return featureLock;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = moderationSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: "hidden must be a boolean" }, { status: 400 });
  }

  try {
    const row = await db.siteReview.update({
      where: { id: reviewId, instanceId: id },
      data: { hidden: parsed.data.hidden },
    });
    const names = await resolveRecordNames(id, [row.recordId]);
    return NextResponse.json({ review: toOwnerDTO(row, names.get(row.recordId) ?? "") });
  } catch (error) {
    /* P2025 = row-not-found under the compound tenant-scoped where (the
       only legitimate 404); real faults surface as logged 500s. */
    if ((error as { code?: string }).code === "P2025") {
      return NextResponse.json({ error: "Review not found" }, { status: 404 });
    }
    console.error(`PATCH /api/instances/${id}/store/reviews/${reviewId} failed:`, error);
    return NextResponse.json({ error: "Failed to update the review" }, { status: 500 });
  }
}

/**
 * DELETE /api/instances/[id]/store/reviews/[reviewId] — permanently remove
 * one review (ROUND 63). Same guards + the same tenant-scoped compound
 * where as PATCH; the row leaves every surface (public + owner) at once.
 */
export async function DELETE(req: Request, { params }: RouteContext) {
  const { id, reviewId } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "support.manage" });
  if (guard instanceof NextResponse) return guard;

  const featureLock = await featureGateResponse(id, "reviews");
  if (featureLock) return featureLock;

  try {
    const existing = await db.siteReview.findFirst({
      where: { id: reviewId, instanceId: id, deletedAt: null },
      select: { id: true },
    });
    if (!existing) {
      return NextResponse.json({ error: "Review not found" }, { status: 404 });
    }
    /* ROUND 87 (trash) — soft delete: the review moves to the workspace
       trash (author index mangled for restore conflicts) and leaves the
       public surface + aggregates immediately. */
    const { softDelete } = await import("@/lib/server/trash");
    const result = await softDelete("siteReview", existing.id, {
      kind: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: guard.principal.actorName,
    }, { instanceScope: id });
    if (!result.ok) {
      return NextResponse.json({ error: "Failed to delete the review" }, { status: result.status });
    }
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error(`DELETE /api/instances/${id}/store/reviews/${reviewId} failed:`, error);
    return NextResponse.json({ error: "Failed to delete the review" }, { status: 500 });
  }
}
