import { NextResponse } from "next/server";

import { db } from "@/lib/db";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { featureGateResponse } from "@/lib/server/entitlement";
import { clampLimit, decodeKeyset, encodeKeyset, keysetPredicate } from "@/lib/server/keyset";
import { resolveRecordNames } from "@/lib/server/store-mapper";
import type { OwnerReviewDTO } from "@/lib/types";
import type { SiteReview } from "@prisma/client";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

const DEFAULT_LIMIT = 15;
const MAX_LIMIT = 50;

/** Owner-console projection: the public shape + the moderation state + the
 *  server-resolved product attribution (authorIndex never ships). */
function toOwnerDTO(row: SiteReview, productName: string): OwnerReviewDTO {
  return {
    id: row.id,
    recordId: row.recordId,
    productName,
    rating: row.rating,
    name: row.name,
    body: row.body,
    hidden: row.hidden,
    createdAt: row.createdAt.toISOString(),
  };
}

/**
 * GET /api/instances/[id]/store/reviews?limit=&cursor= — the owner's
 * moderation console feed (ROUND 63).
 *
 * Lists ALL reviews (visible + hidden) newest-first, KEYSET-paginated on the
 * same `(createdAt, id)` total order as the orders/activities feeds, with
 * the product display names resolved server-side from the module records
 * (deleted/unresolvable products render as "" — the UI shows "—").
 *
 * Console-wide aggregates ride every page (they drive the KPI strip, so
 * they must not shrink with the loaded window): `total` / `avg` count
 * VISIBLE reviews only (what the storefront actually shows), `hiddenCount`
 * is the moderated backlog.
 */
export async function GET(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, undefined, { permission: "support.manage" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const featureLock = await featureGateResponse(id, "reviews");
  if (featureLock) return featureLock;

  const url = new URL(req.url);
  const limit = clampLimit(url.searchParams.get("limit"), DEFAULT_LIMIT, MAX_LIMIT);
  const cursorRaw = url.searchParams.get("cursor");
  const cursor = cursorRaw ? decodeKeyset(cursorRaw) : null;
  /* malformed cursor → loud 400 (never silently re-read page one) */
  if (cursorRaw && !cursor) {
    return NextResponse.json(
      { error: "Invalid pagination cursor", code: "BAD_CURSOR" },
      { status: 400 }
    );
  }

  try {
    /* every review (visible + hidden) — moderation needs the full list.
       take limit+1 so the extra row only signals hasMore (never returned).
       Trashed (soft-deleted) reviews vanish from the console too. */
    const rows = await db.siteReview.findMany({
      where: { instanceId: id, deletedAt: null, ...(cursor ? keysetPredicate(cursor) : {}) },
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: limit + 1,
    });
    const hasMore = rows.length > limit;
    const page = hasMore ? rows.slice(0, limit) : rows;
    const nextCursor = hasMore && page.length > 0 ? encodeKeyset(page[page.length - 1]) : null;

    /* product attribution for THIS page only (one bounded in-query). */
    const productNames = await resolveRecordNames(id, [
      ...new Set(page.map((row) => row.recordId)),
    ]);

    /* console-wide aggregates (independent of page + cursor): visible-only
       count + mean in ONE aggregate, hidden count in a second — cheap
       indexed scans on instanceId. */
    const visible = await db.siteReview.aggregate({
      where: { instanceId: id, hidden: false, deletedAt: null },
      _count: { _all: true },
      _avg: { rating: true },
    });
    const hiddenAgg = await db.siteReview.aggregate({
      where: { instanceId: id, hidden: true, deletedAt: null },
      _count: { _all: true },
    });

    const reviews: OwnerReviewDTO[] = page.map((row) =>
      toOwnerDTO(row, productNames.get(row.recordId) ?? "")
    );

    return NextResponse.json({
      reviews,
      nextCursor,
      total: visible._count._all,
      hiddenCount: hiddenAgg._count._all,
      avg: visible._avg.rating != null ? Math.round(visible._avg.rating * 10) / 10 : null,
    });
  } catch (error) {
    console.error(`GET /api/instances/${id}/store/reviews failed:`, error);
    return NextResponse.json({ error: "Failed to load reviews" }, { status: 500 });
  }
}
