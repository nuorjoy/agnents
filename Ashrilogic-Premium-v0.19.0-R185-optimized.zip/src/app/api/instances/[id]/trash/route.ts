import { NextResponse } from "next/server";
import { z } from "zod";
import { readJson } from "@/lib/server/http";
import { zodError } from "@/lib/server/instance-mapper";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { trialLockResponse } from "@/lib/server/entitlement";
import {
  listTrash,
  purgeExpired,
  purgeItem,
  restoreItem,
  TRASH_ENTITIES,
  type TrashEntity,
} from "@/lib/server/trash";

export const dynamic = "force-dynamic";

/** Tenant-scope entity kinds only — the workspace itself and platform
 *  admins are governed from the Super Admin trash console. */
const TENANT_ENTITIES = TRASH_ENTITIES.filter(
  (e) => e !== "instance" && e !== "adminUser"
) as readonly TrashEntity[];

const entityEnum = z.enum(TENANT_ENTITIES as unknown as [TrashEntity, ...TrashEntity[]]);

/**
 * GET /api/instances/[id]/trash — the workspace's own trash feed
 * (الإدارة → سلة المحذوفات). Same strict contract as the platform trash:
 * the retention sweep runs before every read, items carry an expiry
 * countdown, and stats expose per-entity counts + expiring-soon.
 * Requires the settings.manage permission (trash is governance).
 */
export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "settings.manage" });
  if (guard instanceof NextResponse) return guard;

  try {
    void purgeExpired().catch(() => undefined);

    const url = new URL(req.url);
    const entityRaw = url.searchParams.get("entity");
    const q = url.searchParams.get("q");
    const rawLimit = url.searchParams.get("limit");
    const rawOffset = url.searchParams.get("offset");

    const entity = entityRaw && TENANT_ENTITIES.includes(entityRaw as TrashEntity)
      ? (entityRaw as TrashEntity)
      : null;
    const limit = rawLimit !== null ? Math.min(200, Math.max(1, Number.parseInt(rawLimit, 10) || 50)) : 50;
    const offset = rawOffset !== null ? Math.max(0, Number.parseInt(rawOffset, 10) || 0) : 0;

    const result = await listTrash({
      instanceId: id,
      entity,
      search: q,
      limit,
      offset,
      includePlatformEntities: false,
    });
    /* the stats' byEntity map covers platform entities too — strip them
       from the tenant's own console view for honest numbers */
    const byEntity = Object.fromEntries(
      TENANT_ENTITIES.map((e) => [e, result.stats.byEntity[e] ?? 0])
    ) as Record<TrashEntity, number>;
    return NextResponse.json({
      items: result.items,
      stats: { ...result.stats, byEntity },
    });
  } catch (error) {
    console.error(`GET /api/instances/${id}/trash failed:`, error);
    return NextResponse.json({ error: "Failed to read trash" }, { status: 500 });
  }
}

const actionSchema = z.object({
  action: z.enum(["restore", "purge"]),
  entity: entityEnum,
  id: z.string().min(1).max(64),
});

/**
 * POST /api/instances/[id]/trash — restore / purge ONE trashed row inside
 * THIS workspace. Strictly scoped: a row from another instance is a 404,
 * and the workspace trash can never touch platform entities.
 */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "settings.manage" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 141 (strict enforcement) — a RESTORE is a workspace write: a
   * trial-locked or plan-expired workspace cannot restore items (the UI
   * already blocks every other write surface the same way). */
  const lock = await trialLockResponse(id);
  if (lock) return lock;

  const body = await readJson(req);
  if (!body.ok) return body.response;
  const parsed = actionSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }

  const actor = {
    kind: guard.principal.kind === "admin" ? ("admin" as const) : ("instance" as const),
    actorId: guard.principal.actorId ?? null,
    actorName: guard.principal.actorName ?? null,
  };

  try {
    const { action, entity, id: targetId } = parsed.data;

    if (action === "restore") {
      const result = await restoreItem(entity, targetId, actor, { instanceScope: id });
      if (!result.ok) {
        return NextResponse.json(
          { error: result.message ?? "Restore failed", code: result.code ?? "RESTORE_FAILED" },
          { status: result.status }
        );
      }
      return NextResponse.json({ ok: true, label: result.label ?? null });
    }

    const result = await purgeItem(entity, targetId, actor, { instanceScope: id });
    if (!result.ok) {
      return NextResponse.json(
        { error: "Purge failed", code: result.code ?? "PURGE_FAILED" },
        { status: result.status }
      );
    }
    return NextResponse.json({ ok: true, label: result.label ?? null });
  } catch (error) {
    console.error(`POST /api/instances/${id}/trash failed:`, error);
    return NextResponse.json({ error: "Trash action failed" }, { status: 500 });
  }
}
