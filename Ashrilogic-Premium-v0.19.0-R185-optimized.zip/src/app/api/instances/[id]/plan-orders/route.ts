import { tenantCreate, tenantList } from "@/server/domains/plan-orders/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 47 — GET  /api/instances/[id]/plan-orders — the workspace's own
 *        activation/payment requests (newest first) with live effective
 *        status (pending orders past their 48h expiry report "expired")
 *        and the HMAC integrity re-verification flag. Works while
 *        TRIAL-LOCKED — this is a subscription surface.
 * ROUND 48 — POST /api/instances/[id]/plan-orders — create a plan-activation
 *        payment request. The body carries ONLY { packageId, cycle,
 *        methodId } — no amount, no currency, no reference. The server
 *        recomputes the price from the LIVE package row, resolves the
 *        payment method from the console-managed dynamic list, stamps a
 *        unique reference, seals the order with an HMAC integrity hash and
 *        returns method-specific payment instructions built server-side.
 *        Any previous pending order for this workspace is cancelled
 *        atomically (one live request at a time).
 *
 * ROUND 125 — the handlers moved to the plan-orders domain
 * (src/server/domains/plan-orders): this file is the thin route delegation.
 */
export const GET = tenantList;
export const POST = tenantCreate;
