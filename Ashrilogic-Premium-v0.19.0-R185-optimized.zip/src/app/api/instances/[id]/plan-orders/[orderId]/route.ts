import { tenantCancel } from "@/server/domains/plan-orders/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 47 — PATCH /api/instances/[id]/plan-orders/[orderId] — the tenant
 * cancels their OWN pending activation request ({ action: "cancel" }).
 *
 * Ownership is proven by the workspace session bound to THIS instance (the
 * orderId is cross-checked against it — cross-tenant ids are 404s, never
 * actionable). The HMAC integrity hash is re-verified inside the transition
 * core; a tampered row is refused with 409 ORDER_INTEGRITY.
 *
 * ROUND 125 — the handler moved to the plan-orders domain
 * (src/server/domains/plan-orders): this file is the thin route delegation.
 */
export const PATCH = tenantCancel;
