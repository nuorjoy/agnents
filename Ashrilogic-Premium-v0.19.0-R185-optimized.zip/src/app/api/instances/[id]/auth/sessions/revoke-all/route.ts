import { NextResponse } from "next/server";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { listSessions, revokeAllSessions, revokeOtherSessions } from "@/lib/server/sessions";
import { readJson } from "@/lib/server/http";
import { shiftOpenBlockResponse } from "@/lib/server/shift-gate";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * ROUND 45 — POST /api/instances/[id]/auth/sessions/revoke-all — sign out
 * every OTHER workspace session (the caller's own survives). A managing
 * admin calling without a workspace session revokes ALL workspace sessions.
 *
 * ROUND 46 — `{ includeCurrent: true }` escalates to "sign out EVERYWHERE"
 * (every session including this one; the client routes back to the login
 * screen). Explicit opt-in, audited.
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "settings.manage" });
  if (guard instanceof NextResponse) return guard;
  const actor = guard.principal;

  const body = await readJson(req);
  if (!body.ok) return body.response;
  const includeCurrent =
    (body.data as { includeCurrent?: unknown }).includeCurrent === true;

  /* ROUND 133 — نظام الورديات: "sign out EVERYWHERE" (includeCurrent) is a
   * full self sign-out → refused with 409 SHIFT_OPEN while a shift is open
   * (the cashier must close the shift first). Revoking OTHER sessions stays
   * allowed (security hygiene, not a sign-out). */
  if (includeCurrent) {
    const shiftBlock = await shiftOpenBlockResponse(id);
    if (shiftBlock) return shiftBlock;
  }

  let currentJti: string | undefined;
  if (actor.kind === "session") {
    const { getInstanceSessionJti } = await import("@/lib/server/instance-session");
    currentJti = await getInstanceSessionJti();
  }

  let revoked: number;
  if (includeCurrent) {
    const before = await listSessions("instance", id);
    await revokeAllSessions("instance", id);
    revoked = before.length;
  } else {
    revoked = await revokeOtherSessions("instance", id, currentJti);
  }

  await logAudit({
    actorType: actor.kind === "admin" ? "admin" : "instance",
    actorId: actor.actorId,
    actorName: maskEmail(actor.actorName),
    action: "instance.update",
    targetLabel: includeCurrent ? "all workspace sessions signed out" : "workspace sessions revoked",
    meta: { count: String(revoked) },
  });

  return NextResponse.json({
    ok: true,
    revoked,
    signedOutEverywhere: includeCurrent,
    sessions: await listSessions("instance", id),
  });
}
