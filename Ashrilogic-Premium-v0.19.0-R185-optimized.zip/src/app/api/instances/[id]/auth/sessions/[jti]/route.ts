import { NextResponse } from "next/server";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { listSessions, revokeSession } from "@/lib/server/sessions";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string; jti: string }> };

/**
 * ROUND 45 — DELETE /api/instances/[id]/auth/sessions/[jti] — revoke ONE of
 * the workspace's sessions. The subject is pinned to the URL's workspace id,
 * so a jti from another workspace is never touched.
 */
export async function DELETE(req: Request, { params }: RouteContext) {
  const { id, jti } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "settings.manage" });
  if (guard instanceof NextResponse) return guard;
  const actor = guard.principal;

  const ok = await revokeSession("instance", id, jti);
  if (!ok) {
    return NextResponse.json({ error: "Session not found" }, { status: 404 });
  }

  await logAudit({
    actorType: actor.kind === "admin" ? "admin" : "instance",
    actorId: actor.actorId,
    actorName: maskEmail(actor.actorName),
    action: "instance.update",
    targetLabel: "workspace session revoked",
    meta: { session: jti.slice(0, 10) },
  });

  return NextResponse.json({ ok: true, sessions: await listSessions("instance", id) });
}
