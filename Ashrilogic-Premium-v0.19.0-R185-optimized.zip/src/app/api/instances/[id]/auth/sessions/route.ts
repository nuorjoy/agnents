import { NextResponse } from "next/server";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { listSessions } from "@/lib/server/sessions";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * ROUND 45 — GET /api/instances/[id]/auth/sessions — the workspace's ACTIVE
 * sessions (device, IP, last activity) with the current session's jti marked
 * (when the caller is the workspace owner rather than a managing admin).
 * Revocation: DELETE …/sessions/[jti] and POST …/sessions/revoke-all.
 */
export async function GET(_req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, undefined, { permission: "settings.manage" });
  if (guard instanceof NextResponse) return guard;

  const { getInstanceSessionJti } = await import("@/lib/server/instance-session");
  const [sessions, currentJti] = await Promise.all([
    listSessions("instance", id),
    guard.principal.kind === "session" ? getInstanceSessionJti() : Promise.resolve(undefined),
  ]);
  return NextResponse.json({ sessions, currentJti: currentJti ?? null });
}
