import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { toInstanceDTO, zodError, readAdminEmail } from "@/lib/server/instance-mapper";
import {
  checkInstancePassword,
  setInstanceSession,
  clearInstanceSession,
  getInstanceSessionId,
} from "@/lib/server/instance-session";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { originViolation } from "@/lib/server/origin-guard";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { blindIndex, hashPasswordArgon2id, verifyPasswordArgon2id } from "@/lib/server/crypto-vault";
import { readJson } from "@/lib/server/http";
import { isMfaEnabled } from "@/lib/server/mfa";
import { hasCredentials } from "@/lib/server/webauthn";
import { shiftOpenBlockResponse } from "@/lib/server/shift-gate";
import { revokeAllSessions } from "@/lib/server/sessions";
import { issueInstanceMfaTicket } from "@/lib/server/instance-session";
import { computeBan } from "@/lib/server/entitlement";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

const loginSchema = z.object({
  email: z.email(),
  password: z.string().min(1).max(128),
});

/** Login-attempt throttling: 8 tries per 10 minutes per IP + instance. */
const LOGIN_RULE = { limit: 8, windowMs: 10 * 60 * 1000 };
/**
 * ROUND 37 (task 3-a) — per-ACCOUNT dimension keyed by the email's BLIND
 * INDEX (never the plaintext address): password-spraying one account across
 * rotating source IPs trips this rule even when every per-IP window is
 * clean. Both rules fail CLOSED on a durable-store outage.
 */
const LOGIN_EMAIL_RULE = { limit: 8, windowMs: 10 * 60 * 1000 };

/* ROUND 37 (task 3-a) — lazy fixed Argon2id record for timing equalization:
   an unknown instance OR an email whose blind index does not match burns
   exactly one verify, so response latency cannot reveal account existence. */
let timingHash: string | null = null;
function burnTimingEqualizer(password: string): void {
  timingHash ??= hashPasswordArgon2id("ashrilogic-legacy-gate-timing-equalizer");
  verifyPasswordArgon2id(password, timingHash);
}

/** Org name for audit target labels (orgJson is plaintext — fine to read). */
function orgLabel(orgJson: string | null | undefined): string {
  try {
    const name = (JSON.parse(orgJson ?? "{}") as { name?: unknown }).name;
    return typeof name === "string" ? name : "";
  } catch {
    return "";
  }
}

/**
 * POST /api/instances/[id]/auth/login — subscriber workspace sign-in.
 *
 * ROUND 37 (task 3-a) — hardening port from the static email-first route
 * (this legacy twin was the one remaining surface with a plaintext email
 * comparison, a 404 existence oracle and no origin/rate/audit hygiene):
 *
 *  - same-origin guard runs first (login CSRF);
 *  - the body is read through the bounded reader;
 *  - the credential is resolved through the adminEmailIndex BLIND INDEX —
 *    no plaintext/decrypted email comparison anywhere;
 *  - a missing instance and a wrong email return the SAME uniform 401 as a
 *    wrong password (no existence oracle), each burning one dummy Argon2id
 *    verification so timing matches too;
 *  - the issued session carries the instance's SESSION EPOCH so password
 *    rotation / logout revokes outstanding tokens;
 *  - bootstrap/upgrade password hashes are persisted like the static route;
 *  - audit rows mask the attempted email.
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;

  const violation = originViolation(req);
  if (violation) return violation;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = loginSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const email = parsed.data.email.trim().toLowerCase();

  if (await rateLimited(`inst-login:${clientIp(req)}:${id}`, LOGIN_RULE, { failClosed: true })) {
    return tooManyRequests(LOGIN_RULE, { error: "Too many sign-in attempts, please try again later" });
  }
  if (await rateLimited(`inst-login-email:${blindIndex(email) ?? ""}`, LOGIN_EMAIL_RULE, { failClosed: true })) {
    return tooManyRequests(LOGIN_EMAIL_RULE, { error: "Too many sign-in attempts for this account, please try again later" });
  }

  try {
    /* email verification happens entirely through the blind index — the
       query itself is the credential match (no plaintext compare, no oracle).
       ROUND 87 — a trashed (soft-deleted) workspace fails sign-in with the
       SAME uniform 401 (its keys are not mangled, so this filter is the
       load-bearing guard on this path). */
    const row = await db.instance.findFirst({
      where: { id, adminEmailIndex: blindIndex(email) ?? "", deletedAt: null },
      include: {
        activities: { orderBy: [{ createdAt: "desc" }, { id: "desc" }], take: 8 },
        package: true,
        site: { select: { published: true, theme: true, views: true, contentJson: true } },
      },
    });
    if (!row) {
      /* uniform 401 — identical status, body and (dummy-Argon2id) latency
         as the wrong-password path: no instance/email existence oracle */
      burnTimingEqualizer(parsed.data.password);
      return NextResponse.json({ error: "Incorrect email or password" }, { status: 401 });
    }

    const instance = toInstanceDTO(row);
    const pw = checkInstancePassword(parsed.data.password, row.passwordHash);

    if (!pw.ok) {
      await logAudit({
        actorType: "instance",
        actorName: maskEmail(email),
        action: "instance.loginFailed",
        targetLabel: instance.org.name || instance.systemId,
      });
      return NextResponse.json({ error: "Incorrect email or password" }, { status: 401 });
    }

    // Persist the bootstrapped demo-password hash OR the transparent
    // Argon2id upgrade so legacy rows migrate themselves on first login.
    if ((pw.bootstrapped || pw.upgraded) && pw.hash) {
      await db.instance.update({ where: { id }, data: { passwordHash: pw.hash } });
    }

    /* ROUND 81 — BAN gate (same boundary as the primary login route): a
     * suspended workspace refuses sign-in BEFORE any MFA ticket or session
     * can be minted, with the platform reason + self-lift instant. */
    const ban = computeBan(row);
    if (ban.active) {
      await logAudit({
        actorType: "instance",
        actorId: id,
        actorName: maskEmail(email),
        action: "instance.loginFailed",
        targetLabel: "banned",
        meta: { ban: ban.kind ?? "active" },
      });
      return NextResponse.json(
        {
          error:
            "This workspace is suspended by the platform. Access is refused until the suspension is lifted" +
            (ban.until ? ` (it lifts itself automatically on ${ban.until})` : ""),
          code: "BANNED",
          ban,
        },
        { status: 403 }
      );
    }

    /* ROUND 45 — workspace two-factor gate: with TOTP enrolled, the password
     * alone never issues a session. A 5-minute HMAC ticket (scope
     * "instance-mfa", epoch-bound, emailIndex-bound) is returned instead;
     * the finish step is POST /api/instances/auth/login/mfa. */
    if (await isMfaEnabled("instance", id)) {
      const passkeys = await hasCredentials("instance", id);
      await logAudit({
        actorType: "instance",
        actorId: id,
        actorName: maskEmail(email),
        action: "instance.login",
        targetLabel: instance.org.name || instance.systemId,
        meta: { mfa: "challenge" },
      });
      return NextResponse.json({
        ok: true,
        mfaRequired: true,
        ticket: issueInstanceMfaTicket(id, row.sessionVersion ?? 0, blindIndex(email) ?? ""),
        passkeys,
      });
    }

    /* the session token carries the row's session epoch — password changes
       and logouts bump it, revoking every outstanding token immediately */
    await setInstanceSession(id, row.sessionVersion ?? 0, {
      ip: clientIp(req),
      userAgent: req.headers.get("user-agent"),
    });
    await db.activity.create({ data: { instanceId: id, kind: "actLogin" } });
    await logAudit({
      actorType: "instance",
      actorId: id,
      actorName: maskEmail(email),
      action: "instance.login",
      targetLabel: instance.org.name || instance.systemId,
    });

    return NextResponse.json({ ok: true, instance });
  } catch (error) {
    console.error(`POST /api/instances/${id}/auth/login failed:`, error);
    return NextResponse.json({ error: "Failed to sign in" }, { status: 500 });
  }
}

/**
 * DELETE /api/instances/[id]/auth/login — sign out of the workspace.
 *
 * ROUND 37 (task 3-a) — BOUND logout: the cookie is only cleared when the
 * session actually belongs to THIS instance (a stale or foreign cookie is
 * left alone — this endpoint cannot sign you out of a different workspace),
 * and the instance's sessionVersion is bumped so the sign-out is a
 * server-side revocation of every outstanding token, not just this
 * browser's cookie. Cross-origin attempts are rejected up front.
 */
export async function DELETE(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const violation = originViolation(req);
  if (violation) return violation;
  try {
    const row = await db.instance.findUnique({
      where: { id },
      select: { id: true, adminJson: true, orgJson: true, systemId: true },
    });
    if (!row) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }

    const bound = await getInstanceSessionId();
    if (bound === id) {
      /* ROUND 133 — نظام الورديات (the owner's directive: «لا يمكن تسجيل
       * الخروج والوردية مفتوحة»): the workspace REFUSES sign-out while a
       * shift is open — the shift must be closed first so the drawer is
       * always reconciled by the cashier who opened it. 409 SHIFT_OPEN with
       * the shift code; the client surfaces the close-shift dialog. */
      const shiftBlock = await shiftOpenBlockResponse(id);
      if (shiftBlock) return shiftBlock;

      await clearInstanceSession();
      await db.instance.update({
        where: { id },
        data: { sessionVersion: { increment: 1 } },
      });
      /* ROUND 45 — mirror the epoch revocation in the session registry */
      await revokeAllSessions("instance", id);
      await logAudit({
        actorType: "instance",
        actorId: id,
        actorName: maskEmail(readAdminEmail(row.adminJson)),
        action: "instance.logout",
        targetLabel: orgLabel(row.orgJson) || row.systemId,
      });
    }
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error(`DELETE /api/instances/${id}/auth/login failed:`, error);
    return NextResponse.json({ error: "Failed to sign out" }, { status: 500 });
  }
}
