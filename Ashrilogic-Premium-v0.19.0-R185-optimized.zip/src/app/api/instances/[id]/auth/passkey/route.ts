import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toInstanceDTO } from "@/lib/server/instance-mapper";
import {
  setInstanceSession,
  verifyInstanceMfaTicket,
} from "@/lib/server/instance-session";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { originViolation } from "@/lib/server/origin-guard";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { computeBan } from "@/lib/server/entitlement";
import type { AuthenticationResponseJSON } from "@simplewebauthn/server";
import { finishPasskeyLogin, startPasskeyLogin } from "@/lib/server/webauthn";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/** Passkey-login throttling: 10 / 5 min per IP + workspace. */
const PK_RULE = { limit: 10, windowMs: 5 * 60 * 1000 };

/**
 * ROUND 45 — POST /api/instances/[id]/auth/passkey — passkey sign-in for a
 * workspace, as the SECOND FACTOR of the MFA challenge:
 *
 *  { step: "start", ticket }   → pinned options for THIS workspace (the
 *    ticket is the instance-mfa ticket issued after the password verified).
 *  { step: "finish", ticket, response } → verify the assertion and issue the
 *    workspace session.
 *
 * Discoverable (usernameless) login is intentionally NOT offered for
 * workspaces: a workspace identity is email-scoped, so the password step
 * always runs first and the passkey completes it.
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;

  const violation = originViolation(req);
  if (violation) return violation;

  const body = await readJson(req, 200_000);
  if (!body.ok) return body.response;

  const step = (body.data as { step?: unknown }).step;
  const ticket = (body.data as { ticket?: unknown }).ticket;
  const response = (body.data as { response?: unknown }).response;

  const ip = clientIp(req);
  if (await rateLimited(`inst-passkey:${ip}:${id}`, PK_RULE, { failClosed: true })) {
    return tooManyRequests(PK_RULE, { error: "Too many attempts — try again later" });
  }

  /* the ticket MUST be present and match THIS workspace in both steps */
  const payload = typeof ticket === "string" && ticket ? verifyInstanceMfaTicket(ticket) : null;
  if (!payload || payload.instanceId !== id) {
    return NextResponse.json(
      { error: "Verification session expired — sign in again" },
      { status: 401 }
    );
  }

  /* ------------------------------ STEP 1 ------------------------------ */
  if (step === "start") {
    const started = await startPasskeyLogin(req, "instance", id);
    if (!started.ok) {
      return NextResponse.json(
        { error: "No passkeys registered for this workspace yet" },
        { status: 400 }
      );
    }
    return NextResponse.json({ options: started.options });
  }

  /* ------------------------------ STEP 2 ------------------------------ */
  if (step === "finish") {
    if (!response || typeof response !== "object" || !("id" in response)) {
      return NextResponse.json({ error: "Invalid assertion" }, { status: 400 });
    }

    const result = await finishPasskeyLogin(
      req,
      "instance",
      response as AuthenticationResponseJSON
    );
    if (!result.ok || result.subjectId !== id) {
      const message =
        (!result.ok && result.error === "EXPIRED")
          ? "The sign-in window expired — try again"
          : "Passkey verification failed — try again";
      return NextResponse.json(
        { error: message, code: (!result.ok && result.error) || "INVALID" },
        { status: 401 }
      );
    }

    /* ROUND 87 — a trashed (soft-deleted) workspace never completes passkey
     * MFA sign-in (uniform 401 like every other dead-session path). */
    const row = await db.instance.findUnique({
      where: { id, deletedAt: null },
      include: {
        activities: { orderBy: [{ createdAt: "desc" }, { id: "desc" }], take: 8 },
        package: true,
        site: { select: { published: true, theme: true, views: true, contentJson: true } },
      },
    });
    if (!row || (row.sessionVersion ?? 0) !== payload.ver) {
      return NextResponse.json(
        { error: "Verification session expired — sign in again" },
        { status: 401 }
      );
    }

    /* ROUND 81 — BAN gate on the MFA completion path (mirrors the password
     * and passkey-first boundaries — no side doors into a suspended workspace). */
    const ban = computeBan(row);
    if (ban.active) {
      await logAudit({
        actorType: "instance",
        actorId: row.id,
        actorName: "workspace · passkey",
        action: "instance.loginFailed",
        targetLabel: "banned",
        meta: { ban: ban.kind ?? "active", passkey: "refused" },
      });
      return NextResponse.json(
        {
          error: "This workspace is suspended by the platform — access is refused until the suspension is lifted",
          code: "BANNED",
          ban,
        },
        { status: 403 }
      );
    }

    await setInstanceSession(row.id, row.sessionVersion ?? 0, {
      ip,
      userAgent: req.headers.get("user-agent"),
    });
    await db.activity.create({ data: { instanceId: row.id, kind: "actLogin" } });
    await logAudit({
      actorType: "instance",
      actorId: row.id,
      actorName: "workspace · passkey",
      action: "instance.login",
      targetLabel: toInstanceDTO(row).org.name || row.systemId,
      meta: { passkey: "passed" },
    });

    return NextResponse.json({ ok: true, instance: toInstanceDTO(row) });
  }

  return NextResponse.json({ error: "Unknown step" }, { status: 400 });
}
