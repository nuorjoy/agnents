import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { resolveInstanceSession } from "@/lib/server/instance-session";
import { readAdminEmail } from "@/lib/server/instance-mapper";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * GET /api/instances/[id]/auth/session — silent session restore probe.
 * Returns { authenticated, adminEmail } without exposing instance data to
 * anonymous callers (the dashboard fetch happens after sign-in).
 *
 * ROUND 37 (task 3-a) + round 49 (jti revocation):
 *  - stale-epoch OR jti-revoked tokens (workspace password rotated / logout
 *    bump / "sign out this device") are rejected with the same 401
 *    INSTANCE_STALE shape /api/instances/mine and requireInstanceAccess use
 *    — the probe must not restore a revoked session;
 *  - the admin email is read through readAdminEmail (sealed vault column),
 *    not a raw JSON.parse that would hand the client the ciphertext.
 */
export async function GET(_req: Request, { params }: RouteContext) {
  const { id } = await params;
  try {
    const sessionState = await resolveInstanceSession();
    if (sessionState.status === "invalid") {
      return NextResponse.json(
        { error: "Session expired — sign in again", code: "INSTANCE_STALE" },
        { status: 401 }
      );
    }
    if (sessionState.status === "none" || sessionState.instanceId !== id) {
      return NextResponse.json({ authenticated: false });
    }
    // The instance must still exist for the session to count as valid.
    // ROUND 87 — a trashed (soft-deleted) workspace reads as signed out.
    const row = await db.instance.findUnique({
      where: { id, deletedAt: null },
      select: { adminJson: true },
    });
    if (!row) {
      return NextResponse.json({ authenticated: false });
    }
    return NextResponse.json({ authenticated: true, adminEmail: readAdminEmail(row.adminJson) });
  } catch (error) {
    console.error(`GET /api/instances/${id}/auth/session failed:`, error);
    return NextResponse.json({ authenticated: false });
  }
}
