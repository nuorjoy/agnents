import { tenantTransferCreate } from "@/server/domains/wallet/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 144 — POST /api/instances/[id]/wallet/transfer — EXECUTE an
 * inter-wallet transfer (any workspace owner can send money to any other
 * wallet's UNIQUE 8-digit number).
 *
 * The strict gate order (all server-side, none bypassable):
 *   1. the WORKSPACE OWNER session (an admin-console principal is 403);
 *   2. the owner's SECRET PIN — Argon2id-verified against the SAME hashed
 *      PIN that arms the shift system (428 PIN_NOT_SET before one is
 *      defined; 401 PIN_INVALID throttled fail-closed);
 *   3. the amount parsed from the RAW dual-numeral string (١٢٣ / 1,234.50
 *      both legal) and bounded 1..10,000 SAR;
 *   4. the atomic two-sided CAS engine — ONE transaction debits the sender,
 *      credits the receiver, appends both verifiable ledger rows (kind
 *      "transfer", one shared TRF- reference + linkId) and writes the
 *      zero-delay notification row on BOTH workspaces (zero-sum law);
 *   5. unconditional audit.
 */
export const POST = tenantTransferCreate;
