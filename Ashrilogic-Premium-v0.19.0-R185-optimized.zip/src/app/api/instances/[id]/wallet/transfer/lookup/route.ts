import { tenantTransferLookup } from "@/server/domains/wallet/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 144 — POST /api/instances/[id]/wallet/transfer/lookup — resolve a
 * wallet NUMBER to the receiver preview (org name + system + number) the
 * sender confirms BEFORE executing a transfer. Workspace OWNER session
 * only; throttled (enumeration resistance — an unauthenticated flood never
 * reaches this surface).
 */
export const POST = tenantTransferLookup;
