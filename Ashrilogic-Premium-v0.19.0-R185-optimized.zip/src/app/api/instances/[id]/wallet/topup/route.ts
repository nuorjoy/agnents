import { tenantTopupCreate } from "@/server/domains/wallet/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 141 — POST /api/instances/[id]/wallet/topup — create a wallet
 * TOP-UP REQUEST. The body carries ONLY { amount, methodId } where amount
 * is the RAW dual-numeral string (١٢٣ / 1,234.50 both legal — parsed +
 * bounded server-side, 5..10,000 SAR). The server resolves the console
 * payment method, stamps a WLT-XXXX-XXXX-XXXX reference, seals the request
 * with an HMAC integrity hash and returns server-built payment
 * instructions. Any previous pending top-up is cancelled atomically (one
 * live request at a time). Super-Admin confirmation credits the wallet.
 */
export const POST = tenantTopupCreate;
