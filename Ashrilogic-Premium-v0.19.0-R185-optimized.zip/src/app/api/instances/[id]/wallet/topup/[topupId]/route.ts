import { tenantTopupCancel } from "@/server/domains/wallet/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 141 — PATCH /api/instances/[id]/wallet/topup/[topupId] — cancel
 * the workspace's OWN pending top-up request ({ action: "cancel" }).
 * Cross-tenant ids are plain 404s.
 */
export const PATCH = tenantTopupCancel;
