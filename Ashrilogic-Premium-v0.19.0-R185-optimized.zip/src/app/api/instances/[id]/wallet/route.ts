import { tenantOverview } from "@/server/domains/wallet/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 141 — GET /api/instances/[id]/wallet — the workspace's Ashrilogic
 * wallet projection: the live balance (INTEGER MINOR units), the pending
 * top-up total, the recent append-only ledger rows (each carrying its
 * balanceAfterMinor chain link) and the top-up requests. Works while
 * TRIAL-LOCKED — the wallet is a subscription surface.
 */
export const GET = tenantOverview;
