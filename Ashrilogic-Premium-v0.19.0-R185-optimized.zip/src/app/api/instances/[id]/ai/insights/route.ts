import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { zodError } from "@/lib/server/instance-mapper";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { featureGateResponse } from "@/lib/server/entitlement";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { isAiEnabledForWorkspaces, aiQuotaExhausted, loadAiRow, consumeAiUsage } from "@/lib/server/ai-settings";
import { parseOrderSnapshot } from "@/lib/server/order-snapshot";
import type { AiInsightsDTO } from "@/lib/types";
import ZAI from "z-ai-web-dev-sdk";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

type RouteContext = { params: Promise<{ id: string }> };

/**
 * ROUND 41 — Premium AI Insights.
 *
 * GET  — availability probe for every workspace dashboard: { enabled }.
 *        enabled = the Super-Admin master switch is ON AND the platform
 *        monthly quota is not exhausted. 401 without a session.
 *
 * POST — deep AI analysis of THIS workspace's data (tenant-scoped):
 *        monthly revenue trend (real site orders, 12 months), item
 *        frequency + per-item monthly growth (order items + module
 *        records), customer/team counts. A compact JSON summary (≤40 items,
 *        ≤12 months, ≤200 record samples) goes to the LLM which answers
 *        STRICT JSON in Arabic matching AiInsightsDTO.
 *
 * Hardening: origin guard via requireInstanceAccess(req), bounded body
 * read (10 KB), durable per-instance limiter (12 / 10 min), quota gate
 * (429 AI_QUOTA), fenced-JSON parse (502 AI_PARSE), provider failure
 * (502 AI_UNAVAILABLE), audit row on every successful run. The usage
 * counter increments ONLY after a successful analysis. The audit actor
 * comes from the guard principal (its session branch is already
 * readAdminEmail-derived and masked inside requireInstanceAccess).
 */

/** Deep-analysis throttling: 12 runs per 10 minutes per instance. */
const AI_RULE = { limit: 12, windowMs: 600000 };

/** body caps — the summary sent upstream stays compact */
const MAX_ITEMS = 40;
const MAX_MONTHS = 12;
const MAX_RECORD_SAMPLES = 200;
const MAX_ORDERS = 800;

/** request body — scope "all" (whole workspace) or one module id;
 * lang = the requester's UI language so the analysis content follows it
 * (round 41 — multilingual AI; ar/en/hi produce native-language analyses,
 * every other locale falls back to English content). */
const insightsRequestSchema = z.object({
  scope: z.string().trim().min(1).max(64).optional(),
  lang: z.enum(["ar", "en", "hi"]).optional(),
});

/** Email-shaped values are PII — mask them for the audit trail (same
 *  helper the tickets/module-records routes use). */
const EMAIL_SHAPE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function auditActorName(name: string): string {
  return EMAIL_SHAPE.test(name) ? maskEmail(name) : name;
}

/* ------------------- ROUND 81 — VERIFICATION LAYER --------------------- */

/** Arabic/Latin name normalization for fuzzy grounding: lowercase, strip
 *  diacritics + tatweel, fold alef/ya/ha variants, drop punctuation. */
function normName(value: string): string {
  return value
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670]/g, "")
    .replace(/\u0640/g, "")
    .replace(/[\u0622\u0623\u0625]/g, "\u0627")
    .replace(/\u0649/g, "\u064A")
    .replace(/\u0629/g, "\u0647")
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** Build the REAL item universe from the tenant's actual data: aggregated
 *  order/record item names + every record's first cell + the org name —
 *  capped so the upstream prompt stays compact. */
function buildItemUniverse(
  items: Map<string, ItemAgg>,
  records: { dataJson: string }[],
  orgName: string
): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  const push = (raw: string) => {
    const name = raw.trim().slice(0, 80);
    if (!name) return;
    const key = normName(name);
    if (!key || seen.has(key)) return;
    seen.add(key);
    out.push(name);
  };
  for (const name of items.keys()) push(name);
  for (const record of records) {
    try {
      const values = JSON.parse(record.dataJson) as unknown[];
      if (Array.isArray(values) && typeof values[0] === "string") push(values[0]);
    } catch {
      /* corrupt row — skip */
    }
  }
  push(orgName);
  return out.slice(0, 120);
}

/** Is a composed LLM entry grounded in the universe? The entry mentions a
 *  real item when it CONTAINS the item's normalized name, or one of its
 *  significant tokens (≥4 chars) — robust to prose around the name. */
function entryGrounded(entry: string, universeKeys: { full: string[]; tokens: string[][] }): boolean {
  const hay = normName(entry);
  if (!hay) return false;
  for (let i = 0; i < universeKeys.full.length; i++) {
    if (universeKeys.full[i] && hay.includes(universeKeys.full[i])) return true;
    for (const token of universeKeys.tokens[i]) {
      if (token.length >= 4 && hay.includes(token)) return true;
    }
  }
  return false;
}

/** Dominant-script check: the composed prose must carry the REQUESTED
 *  language's script (Arabic letters for ar, Devanagari for hi, Latin for
 *  en) — catches wrong-language generations before display. */
function languageOkFor(lang: "ar" | "en" | "hi", prose: string): boolean {
  const arabic = (prose.match(/[\u0600-\u06FF]/g) ?? []).length;
  const devanagari = (prose.match(/[\u0900-\u097F]/g) ?? []).length;
  const latin = (prose.match(/[A-Za-z]/g) ?? []).length;
  if (arabic + devanagari + latin < 40) return true; /* too little prose to judge */
  switch (lang) {
    case "ar":
      return arabic > latin && arabic > devanagari;
    case "hi":
      return devanagari > latin;
    default:
      return latin > arabic && latin > devanagari;
  }
}

/** Org name for audit target labels (orgJson is plaintext — fine to read). */
function orgLabel(orgJson: string | null | undefined): string {
  try {
    const name = (JSON.parse(orgJson ?? "{}") as { name?: unknown }).name;
    return typeof name === "string" ? name : "";
  } catch {
    return "";
  }
}

/**
 * Modules whose rows represent ITEMS (stock lines, medicines, menu dishes,
 * assets…). Their first dataJson cell is the item name — feeding these into
 * the item-frequency aggregation is what surfaces "الأكثر طلباً" for
 * inventory/pharmacy-style workspaces even before any site order exists.
 */
const ITEM_MODULE_KEYS = new Set([
  "inventory",
  "pharmacy",
  "pharmacy-management",
  "medicines",
  "products",
  "stocktake",
  "warehouse",
  "warehouses",
  "warehouse-management",
  "menu",
  "suppliers",
  "assets",
  "beds",
  "branches",
  "store",
  "commercial-bookstore",
]);

/* ------------------------------- helpers -------------------------------- */

function monthKeyOf(date: Date): string {
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}`;
}

interface ItemAgg {
  qty: number;
  orderCount: number;
  recordCount: number;
  monthlyQty: Map<string, number>;
}

function bumpItem(map: Map<string, ItemAgg>, name: string, qty: number, month: string, source: "order" | "record") {
  const key = name.trim().slice(0, 80);
  if (!key) return;
  const agg = map.get(key) ?? { qty: 0, orderCount: 0, recordCount: 0, monthlyQty: new Map() };
  agg.qty += qty;
  if (source === "order") agg.orderCount += 1;
  else agg.recordCount += 1;
  agg.monthlyQty.set(month, (agg.monthlyQty.get(month) ?? 0) + qty);
  map.set(key, agg);
}

/** LLM arrays → bounded Arabic string arrays (3..6 entries, no empties). */
function coerceStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  const out: string[] = [];
  for (const entry of value) {
    if (typeof entry !== "string") continue;
    const text = entry.replace(/\s+/g, " ").trim().slice(0, 300);
    if (text.length > 0) out.push(text);
    if (out.length >= 6) break;
  }
  return out.length >= 3 ? out : [];
}

function coerceProse(value: unknown, max: number): string {
  return typeof value === "string" ? value.replace(/\s+/g, " ").trim().slice(0, max) : "";
}

/* -------------------------------- GET ----------------------------------- */

export async function GET(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "overview.view" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const featureLock = await featureGateResponse(id, "aiInsights");
  if (featureLock) return featureLock;
  return NextResponse.json({ enabled: await isAiEnabledForWorkspaces() });
}

/* -------------------------------- POST ---------------------------------- */

export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;

  const guard = await requireInstanceAccess(id, req, { permission: "overview.view" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const featureLock = await featureGateResponse(id, "aiInsights");
  if (featureLock) return featureLock;
  const actor = guard.principal;

  const body = await readJson(req, 10_000);
  if (!body.ok) return body.response;

  const parsedBody = insightsRequestSchema.safeParse(body.data);
  if (!parsedBody.success) {
    return NextResponse.json({ error: zodError(parsedBody.error) }, { status: 400 });
  }
  const scope = parsedBody.data.scope && parsedBody.data.scope !== "all" ? parsedBody.data.scope : "all";
  const analysisLang = parsedBody.data.lang ?? "ar";

  /* durable per-instance limiter (client IP keeps the key unique per caller) */
  if (await rateLimited(`inst-ai:${clientIp(req)}:${id}`, AI_RULE)) {
    return tooManyRequests(AI_RULE, { error: "Too many analyses — try again later", code: "AI_RATE" });
  }

  /* master switch + platform quota */
  const aiRow = await loadAiRow();
  if (!aiRow.enabled) {
    return NextResponse.json(
      { error: "AI analytics are not enabled for this system", code: "AI_DISABLED" },
      { status: 403 }
    );
  }
  if (aiQuotaExhausted(aiRow)) {
    return NextResponse.json(
      { error: "AI quota exhausted for this month", code: "AI_QUOTA" },
      { status: 429 }
    );
  }

  try {
    const instanceRow = await db.instance.findUnique({
      where: { id, deletedAt: null },
      select: { id: true, systemId: true, orgJson: true },
    });
    if (!instanceRow) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }

    /* ---------------- tenant-scoped data gathering (ROUND 87 — live rows
       only: trashed orders/records/customers/members never feed the AI) --- */
    const orders = await db.siteOrder.findMany({
      where: { instanceId: id, deletedAt: null },
      select: { itemsJson: true, total: true, status: true, createdAt: true },
      orderBy: { createdAt: "desc" },
      take: MAX_ORDERS,
    });
    const records = await db.moduleRecord.findMany({
      where:
        scope !== "all"
          ? { instanceId: id, moduleId: scope, deletedAt: null }
          : { instanceId: id, deletedAt: null },
      select: { moduleId: true, dataJson: true, createdAt: true },
      orderBy: { createdAt: "desc" },
      take: MAX_RECORD_SAMPLES,
    });
    const [customerCount, memberCount] = await Promise.all([
      db.siteCustomer.count({ where: { instanceId: id, deletedAt: null } }),
      db.teamMember.count({ where: { instanceId: id, deletedAt: null } }),
    ]);

    /* ---------------- aggregation ---------------- */
    const now = new Date();
    const monthKeys: string[] = [];
    for (let i = MAX_MONTHS - 1; i >= 0; i--) {
      monthKeys.push(monthKeyOf(new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i, 1))));
    }
    const months = monthKeys.map((key) => ({ key, orders: 0, revenue: 0 }));
    const monthIndex = new Map(monthKeys.map((key, i) => [key, i] as const));
    const statusCounts: Record<string, number> = {};

    const items = new Map<string, ItemAgg>();

    for (const order of orders) {
      const month = monthKeyOf(new Date(order.createdAt));
      const idx = monthIndex.get(month);
      if (idx !== undefined) {
        months[idx].orders += 1;
        if (order.status !== "cancelled") months[idx].revenue += order.total / 100;
      }
      statusCounts[order.status] = (statusCounts[order.status] ?? 0) + 1;
      /* Shared snapshot parser (v2 envelope + legacy v1 arrays + malformed
         degradation) — a local JSON.parse here saw every v2 order as an
         empty item list and silently emptied the item analytics. */
      const snapshot = parseOrderSnapshot(order.itemsJson);
      for (const line of snapshot.items) {
        const name = typeof line.name === "string" ? line.name : "";
        const qty =
          Number.isFinite(line.qty) && line.qty > 0 ? Math.round(line.qty) : 1;
        if (name.trim()) bumpItem(items, name, qty, month, "order");
      }
    }

    for (const record of records) {
      const month = monthKeyOf(new Date(record.createdAt));
      if (ITEM_MODULE_KEYS.has(record.moduleId)) {
        try {
          const values = JSON.parse(record.dataJson) as unknown[];
          const name = Array.isArray(values) && typeof values[0] === "string" ? values[0] : "";
          if (name.trim()) bumpItem(items, name, 1, month, "record");
        } catch {
          /* corrupt dataJson — skip */
        }
      }
    }

    const rowsAnalyzed = orders.length + records.length;
    if (rowsAnalyzed === 0 && customerCount === 0 && memberCount === 0) {
      return NextResponse.json(
        { error: "Not enough data yet — add records and orders first", code: "AI_EMPTY" },
        { status: 422 }
      );
    }

    const topItems = [...items.entries()]
      .sort((a, b) => b[1].qty + b[1].recordCount - (a[1].qty + a[1].recordCount))
      .slice(0, MAX_ITEMS)
      .map(([name, agg]) => ({
        name,
        totalQty: agg.qty,
        orderCount: agg.orderCount,
        recordCount: agg.recordCount,
        monthlyQty: Object.fromEntries([...agg.monthlyQty.entries()].slice(-MAX_MONTHS)),
      }));
    const itemsConsidered = items.size;

    const org = (() => {
      try {
        return JSON.parse(instanceRow.orgJson ?? "{}") as { name?: string; currency?: string };
      } catch {
        return {} as { name?: string; currency?: string };
      }
    })();

    /* ---------------- compact summary → LLM ---------------- */
    /* ROUND 81 — the ALLOWED item list travels with the summary: the model
     * is instructed to name ONLY these items, and the verification layer
     * below enforces it against the same universe after generation. */
    const itemUniverse = buildItemUniverse(items, records, org.name ?? "");
    const summary = {
      org: { name: org.name ?? "", system: instanceRow.systemId, currency: org.currency ?? "SAR" },
      scope: scope === "all" ? "entire workspace" : `module "${scope}" (focus this module's records)`,
      customers: customerCount,
      teamMembers: memberCount,
      months: months.map((m) => ({ month: m.key, orders: m.orders, revenue: Math.round(m.revenue * 100) / 100 })),
      orderStatuses: statusCounts,
      topItems,
      allowedItems: itemUniverse,
      recordSamples: records.slice(0, MAX_RECORD_SAMPLES).map((r) => {
        let values: string[] = [];
        try {
          const parsedVals = JSON.parse(r.dataJson) as unknown[];
          if (Array.isArray(parsedVals)) {
            values = parsedVals
              .filter((v): v is string => typeof v === "string")
              .slice(0, 6)
              .map((v) => {
            let s = v.replace(/\s+/g, " ").trim().slice(0, 60);
            s = s.replace(/[\w.+-]+@[\w-]+\.[\w.-]+/g, "[email]");
            s = s.replace(/\+?\d{9,15}/g, "[phone]");
            s = s.replace(/\b\d{10,}\b/g, "[id]");
            return s;
          });
          }
        } catch {
          /* skip */
        }
        return { module: r.moduleId, createdAt: monthKeyOf(new Date(r.createdAt)), values };
      }),
    };

    const LANGUAGE_INSTRUCTIONS: Record<"ar" | "en" | "hi", string> = {
      ar: "CRITICAL: Write ALL your output strings in fluent professional ARABIC (Arabic script).",
      en: "CRITICAL: Write ALL your output strings in fluent professional ENGLISH. Data values (organization/product names) may stay in their original script inside your sentences, but every sentence you compose MUST be English.",
      hi: "CRITICAL: Write ALL your output strings in fluent professional HINDI using Devanagari script (natural Indian SaaS tone). Data values (organization/product names) may stay in their original script inside your sentences, but every sentence you compose MUST be Hindi in Devanagari — never Arabic or English prose.",
    };

    const SYSTEM_PROMPT =
      "You are an expert business data analyst for SaaS workspaces (hospitals, pharmacies, restaurants, schools, retail...). " +
      "Analyze the provided workspace data summary and respond with STRICT JSON ONLY — no markdown fences, no commentary. " +
      LANGUAGE_INSTRUCTIONS[analysisLang] + " " +
      'Return exactly this JSON shape: {"title": string (short headline), "summary": string (executive summary, 2-4 sentences), ' +
      '"salesTrend": string (the revenue/sales trajectory as prose), ' +
      '"productGrowth": string[] (3-6 fastest-growing products/items, one per entry), ' +
      '"seasons": string[] (3-6 detected selling seasons / demand patterns), ' +
      '"topItems": string[] (3-6 most requested items/medicines, one per entry), ' +
      '"recommendations": string[] (3-6 actionable recommendations), ' +
      '"risks": string[] (3-6 notes & risks), ' +
      '"confidence": number (0-100, your confidence in this analysis)}. ' +
      "Ground every entry in the actual data (months, quantities, item names). Never invent product names that are not in the data. " +
      "If a category has no signal, still return plausible data-driven entries about the available items.";

    const dataPrompt =
      "Analyze this workspace data summary and respond with the strict JSON described. " +
      `REMEMBER: your output language is ${analysisLang === "ar" ? "ARABIC" : analysisLang === "hi" ? "HINDI (Devanagari script)" : "ENGLISH"}.\n\n` +
      JSON.stringify(summary);

    let completion;
    try {
      const zai = await ZAI.create();
      completion = await zai.chat.completions.create({
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: dataPrompt },
        ],
        thinking: { type: "disabled" },
      });
    } catch (error) {
      console.error(
        `POST /api/instances/${id}/ai/insights provider call failed:`,
        error instanceof Error ? error.message : error
      );
      return NextResponse.json(
        { error: "AI provider unavailable — try again later", code: "AI_UNAVAILABLE" },
        { status: 502 }
      );
    }

    const raw = completion.choices[0]?.message?.content ?? "";
    const cleaned = raw
      .trim()
      .replace(/^```(?:json)?\s*/i, "")
      .replace(/\s*```$/, "");
    let parsedLLM: unknown;
    try {
      parsedLLM = JSON.parse(cleaned);
    } catch {
      return NextResponse.json(
        { error: "AI analysis failed — try again", code: "AI_PARSE" },
        { status: 502 }
      );
    }
    if (!parsedLLM || typeof parsedLLM !== "object") {
      return NextResponse.json(
        { error: "AI analysis failed — try again", code: "AI_PARSE" },
        { status: 502 }
      );
    }
    const obj = parsedLLM as Record<string, unknown>;

    const title = coerceProse(obj.title, 120);
    const summaryText = coerceProse(obj.summary, 900);
    const salesTrend = coerceProse(obj.salesTrend, 900);
    const productGrowth = coerceStringArray(obj.productGrowth);
    const seasons = coerceStringArray(obj.seasons);
    const topItemsOut = coerceStringArray(obj.topItems);
    const recommendations = coerceStringArray(obj.recommendations);
    const risks = coerceStringArray(obj.risks);
    const confidenceRaw = typeof obj.confidence === "number" && Number.isFinite(obj.confidence) ? obj.confidence : 75;

    if (!title || !summaryText || !salesTrend || productGrowth.length === 0 || topItemsOut.length === 0) {
      return NextResponse.json(
        { error: "AI analysis failed — try again", code: "AI_PARSE" },
        { status: 502 }
      );
    }

    /* ---------------- ROUND 81 — VERIFICATION BEFORE DISPLAY ----------------
     *
     * The owner demanded the engine "verify and review the results well
     * before showing them to the user". Every item claim in topItems /
     * productGrowth is cross-checked against the REAL tenant item universe
     * (Arabic-normalized fuzzy containment); ungrounded entries are STRIPPED.
     * The composed prose is script-checked against the requested language.
     * An analysis whose grounding collapses (<40%) or that failed the
     * language check is REFUSED outright (502 AI_VERIFICATION) — the user
     * retries instead of ever reading hallucinated items. */
    const universeKeys = itemUniverse.map((name) => {
      const normalized = normName(name);
      return {
        full: normalized,
        tokens: normalized.split(" ").filter((token) => token.length >= 4),
      };
    });
    const groundList = (entries: string[]): { grounded: string[]; stripped: number } => {
      const grounded: string[] = [];
      let stripped = 0;
      for (const entry of entries) {
        if (entryGrounded(entry, { full: universeKeys.map((u) => u.full), tokens: universeKeys.map((u) => u.tokens) })) {
          grounded.push(entry);
        } else {
          stripped += 1;
        }
      }
      return { grounded, stripped };
    };

    const growthVerdict = groundList(productGrowth);
    const topVerdict = groundList(topItemsOut);
    const checkedClaims = growthVerdict.grounded.length + growthVerdict.stripped + topVerdict.grounded.length + topVerdict.stripped;
    const groundedClaims = growthVerdict.grounded.length + topVerdict.grounded.length;
    const strippedUngrounded = growthVerdict.stripped + topVerdict.stripped;
    const groundingPct = checkedClaims > 0 ? Math.round((groundedClaims / checkedClaims) * 100) : 100;

    const languageOk = languageOkFor(analysisLang, `${title} ${summaryText} ${salesTrend}`);

    /* after stripping, the two item lists must still carry signal */
    if (topVerdict.grounded.length === 0 && growthVerdict.grounded.length === 0) {
      return NextResponse.json(
        { error: "AI analysis could not be verified against your data — try again", code: "AI_VERIFICATION" },
        { status: 502 }
      );
    }
    if (groundingPct < 40 || !languageOk) {
      return NextResponse.json(
        { error: "AI analysis failed verification — try again", code: "AI_VERIFICATION" },
        { status: 502 }
      );
    }

    const verification = {
      verified: true,
      groundingPct,
      checkedClaims,
      groundedClaims,
      strippedUngrounded,
      languageOk,
      reviewedAt: new Date().toISOString(),
    };

    const dto: AiInsightsDTO = {
      title,
      summary: summaryText,
      salesTrend,
      productGrowth: growthVerdict.grounded.length > 0 ? growthVerdict.grounded : productGrowth,
      seasons,
      topItems: topVerdict.grounded.length > 0 ? topVerdict.grounded : topItemsOut,
      recommendations,
      risks,
      confidence: Math.max(0, Math.min(100, Math.round(confidenceRaw))),
      rowsAnalyzed,
      itemsConsidered,
      generatedAt: new Date().toISOString(),
      verification,
    };

    /* usage counter increments ONLY on a successful analysis */
    await consumeAiUsage();

    await logAudit({
      actorType: actor.kind === "admin" ? "admin" : "instance",
      actorId: actor.actorId,
      actorName: auditActorName(actor.actorName),
      action: "instance.aiAnalysis",
      targetLabel: orgLabel(instanceRow.orgJson) || instanceRow.systemId,
      meta: { rows: String(rowsAnalyzed), scope, grounding: String(groundingPct), stripped: String(strippedUngrounded) },
    });

    return NextResponse.json(dto);
  } catch (error) {
    console.error(`POST /api/instances/${id}/ai/insights failed:`, error);
    return NextResponse.json({ error: "Failed to run AI analysis" }, { status: 500 });
  }
}
