import { NextResponse } from "next/server";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { onlineAdminCount, presenceOf } from "@/lib/server/presence";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * POST /api/instances/[id]/presence — ROUND 172 (premium presence
 * heartbeat, tenant side).
 *
 * Every system dashboard beats every 45s while its tab is open. Like the
 * console heartbeat, the call itself is the touch:
 * requireInstanceAccess → checkSessionRecord("instance", …) refreshes the
 * workspace session's lastSeenAt — the Super Admin console's subscriber
 * rows flip to green the moment an owner is actually inside their system.
 *
 * Response:
 *  - me — the workspace owner's own presence (the «مالك النظام» card in
 *    the team view + the session card in security settings).
 *  - support.onlineAdmins — distinct online PLATFORM admins (count only,
 *    never identities): the premium «فريق الدعم متصل الآن» indicator every
 *    system dashboard shows in its topbar.
 *  - serverTime — ISO now for skew-free relative labels.
 *
 * Same tenant isolation law as every [id] surface: a foreign caller gets
 * 404 (unknown workspace) / 401 (no session) — never another tenant's data.
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, req);
  if (guard instanceof NextResponse) return guard;

  try {
    const me = await presenceOf("instance", id);
    return NextResponse.json({
      me,
      support: { onlineAdmins: await onlineAdminCount() },
      serverTime: new Date().toISOString(),
    });
  } catch (error) {
    console.error("POST /api/instances/[id]/presence failed:", error);
    return NextResponse.json({ error: "Presence unavailable" }, { status: 500 });
  }
}
