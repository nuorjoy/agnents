import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { readJson } from "@/lib/server/http";
import { zodError } from "@/lib/server/instance-mapper";
import { requireInstanceAccess, checkInstancePassword } from "@/lib/server/instance-session";
import { revokeAllSessions } from "@/lib/server/sessions";
import { logAudit } from "@/lib/server/audit";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

const disableSchema = z.object({
  /** proof-of-knowledge: the workspace password (the OWNER's own decision) */
  password: z.string().min(1).max(128),
  /** optional free-text reason (≤ 200) kept on the row + audit trail */
  reason: z.string().trim().max(200).optional(),
});

/**
 * POST /api/instances/[id]/self-disable — ROUND 87 (account lifecycle): the
 * workspace owner DISABLES their own account (تعطيل الحساب).
 *
 * Strict contract:
 *  - OWNER SESSION ONLY (platform admins govern through the ban levers,
 *    which are a different, stricter concept);
 *  - password proof-of-knowledge required;
 *  - the pause is total and instant: every live workspace session is
 *    revoked, login refuses with WORKSPACE_DISABLED, every API surface
 *    locks (entitlement lockReason "disabled"), and the public website +
 *    e-store render the paused hold screen;
 *  - re-activation is one password proof away at the login step (the login
 *    route's reactivate path) — nothing is lost, nothing is deleted;
 *  - audited unconditionally as a SECURITY action (instance.selfDisable).
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "settings.manage" });
  if (guard instanceof NextResponse) return guard;

  /* owner-session only: the platform's own pause lever is the ban */
  if (guard.principal.kind !== "session") {
    return NextResponse.json(
      { error: "Only the workspace owner may disable their own account", code: "OWNER_ONLY" },
      { status: 403 }
    );
  }

  const body = await readJson(req);
  if (!body.ok) return body.response;
  const parsed = disableSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }

  try {
    const row = await db.instance.findUnique({
      where: { id },
      select: { passwordHash: true, disabledAt: true, deletedAt: true, orgJson: true },
    });
    if (!row || row.deletedAt) {
      return NextResponse.json({ error: "Workspace not found" }, { status: 404 });
    }
    if (row.disabledAt) {
      return NextResponse.json(
        { error: "This workspace is already disabled", code: "ALREADY_DISABLED" },
        { status: 409 }
      );
    }

    /* proof-of-knowledge: the workspace password record */
    const pw = checkInstancePassword(parsed.data.password, row.passwordHash);
    if (!pw.ok) {
      await logAudit({
        actorType: "instance",
        actorId: id,
        actorName: guard.principal.actorName,
        action: "instance.selfDisable",
        targetLabel: "password-proof-failed",
      });
      return NextResponse.json(
        { error: "Incorrect password — disabling the account requires the workspace password", code: "PASSWORD_PROOF" },
        { status: 403 }
      );
    }

    const now = new Date();
    /* the pause + the epoch bump land atomically; sessions die after */
    await db.instance.update({
      where: { id },
      data: {
        disabledAt: now,
        disabledReason: parsed.data.reason ?? null,
        sessionVersion: { increment: 1 },
      },
    });
    await revokeAllSessions("instance", id);

    let orgName = "";
    try {
      orgName = (JSON.parse(row.orgJson) as { name?: string }).name ?? "";
    } catch {
      /* corrupt orgJson — audit with the id */
    }

    await logAudit({
      actorType: "instance",
      actorId: id,
      actorName: guard.principal.actorName,
      action: "instance.selfDisable",
      targetLabel: orgName || id.slice(0, 8),
      meta: { ...(parsed.data.reason ? { reason: parsed.data.reason } : {}), at: now.toISOString() },
    });

    return NextResponse.json({ ok: true, disabledAt: now.toISOString() });
  } catch (error) {
    console.error(`POST /api/instances/${id}/self-disable failed:`, error);
    return NextResponse.json({ error: "Failed to disable the account" }, { status: 500 });
  }
}
