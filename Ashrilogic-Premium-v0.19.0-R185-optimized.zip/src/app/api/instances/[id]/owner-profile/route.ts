import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { readOwnerProfile, zodError } from "@/lib/server/instance-mapper";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { trialLockResponse } from "@/lib/server/entitlement";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { COUNTRIES } from "@/data/countries";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * ROUND 84 (owner profile gate) — /api/instances/[id]/owner-profile
 *
 * The STRICT completion surface behind the blocking dashboard gate: right
 * after a system is created, the platform requires the workspace OWNER's
 * personal data (gender, date of birth, personal address, nationality, job
 * title, personal phone) before the workspace unlocks. The gate mirrors
 * this server-side verdict — it is dismissable only when `completed: true`.
 *
 *  - GET  — the owner's stored profile + completed flag.
 *  - PUT  — STRICT zod validation of every field; writes the ownerProfileJson
 *           column (with a completedAt stamp) together with an activity row
 *           in one transaction.
 *
 * Authorization: the WORKSPACE OWNER session only — platform admins manage
 * tenants but the profile is the owner's personal completion step (403 for
 * non-owner principals, 401 without a session — requireInstanceAccess).
 */

/* The shared country catalog (single source of truth — src/data/countries,
 * re-exported by the wizard's wizard-shared so the wizard org step and this
 * gate render the identical list). Validation accepts exactly these ISO
 * alpha-2 codes. */
const COUNTRY_CODES = COUNTRIES.map((c) => c.code);

/** Personal international phone: optional leading +, then 8–15 digits. */
const OWNER_PHONE_RE = /^\+?[0-9]{8,15}$/;

/** Mean tropical year — age math for the 13–120 birth-date window. */
const YEAR_MS = 365.2425 * 24 * 60 * 60 * 1000;
const MIN_AGE_YEARS = 13;
const MAX_AGE_YEARS = 120;

const ownerProfileSchema = z.object({
  gender: z.enum(["male", "female"]),
  birthDate: z
    .string()
    .trim()
    .regex(/^\d{4}-\d{2}-\d{2}$/, "invalid date")
    .refine((v) => {
      const t = Date.parse(`${v}T00:00:00Z`);
      if (Number.isNaN(t) || t >= Date.now()) return false;
      const ageYears = (Date.now() - t) / YEAR_MS;
      return ageYears >= MIN_AGE_YEARS && ageYears <= MAX_AGE_YEARS;
    }, `age must be between ${MIN_AGE_YEARS} and ${MAX_AGE_YEARS} years`),
  address: z.string().trim().min(10).max(220),
  nationality: z.enum(COUNTRY_CODES),
  jobTitle: z.string().trim().min(2).max(80),
  phone: z.string().trim().regex(OWNER_PHONE_RE, "invalid phone"),
});

/**
 * GET /api/instances/[id]/owner-profile — the stored owner profile with its
 * completed flag. Owner session only (admins read the same projection inside
 * the authenticated instance DTO).
 */
export async function GET(_req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id);
  if (guard instanceof NextResponse) return guard;
  if (guard.principal.kind !== "session") {
    return NextResponse.json(
      { error: "Owner sign-in required for the personal profile", code: "OWNER_ONLY" },
      { status: 403 }
    );
  }

  try {
    /* ROUND 87 — a trashed (soft-deleted) workspace reads as gone */
    const row = await db.instance.findUnique({
      where: { id, deletedAt: null },
      select: { ownerProfileJson: true },
    });
    if (!row) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }
    return NextResponse.json(readOwnerProfile(row.ownerProfileJson));
  } catch (error) {
    console.error(`GET /api/instances/${id}/owner-profile failed:`, error);
    return NextResponse.json({ error: "Failed to fetch owner profile" }, { status: 500 });
  }
}

/**
 * PUT /api/instances/[id]/owner-profile — STRICT completion write. Every
 * field is validated (gender enum · real past birth date aged 13–120 ·
 * address ≥ 10 chars · nationality inside the shared COUNTRIES catalog ·
 * job title ≥ 2 chars · phone ^\+?[0-9]{8,15}$); a passing payload is
 * stamped with completedAt and stored atomically with an actSettingsUpdated
 * activity row. Trial-locked workspaces refuse the write like every other
 * business surface (the client gate never renders while locked anyway).
 */
export async function PUT(req: Request, { params }: RouteContext) {
  const { id } = await params;

  /* guard BEFORE the bounded body read (established route order). */
  const guard = await requireInstanceAccess(id, req);
  if (guard instanceof NextResponse) return guard;
  if (guard.principal.kind !== "session") {
    return NextResponse.json(
      { error: "Owner sign-in required for the personal profile", code: "OWNER_ONLY" },
      { status: 403 }
    );
  }

  const trialLock = await trialLockResponse(id);
  if (trialLock) return trialLock;

  /* the profile body is tiny — a 10KB cap is generous headroom. */
  const body = await readJson(req, 10_000);
  if (!body.ok) return body.response;

  const parsed = ownerProfileSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }

  try {
    /* ROUND 87 — a trashed (soft-deleted) workspace refuses the write too */
    const existing = await db.instance.findUnique({
      where: { id, deletedAt: null },
      select: { id: true, systemId: true, orgJson: true },
    });
    if (!existing) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }
    let orgName = "";
    try {
      const org = JSON.parse(existing.orgJson) as { name?: string };
      orgName = org.name ?? "";
    } catch {
      // corrupt orgJson — audit with the systemId instead
    }

    const completedAt = new Date().toISOString();
    const profile = { ...parsed.data, completedAt };

    /* Activity row + column write in ONE transaction (the settings-update
     * pattern from PATCH /api/instances/[id] — a refresh of the activity
     * include picks the new row up atomically). */
    await db.$transaction([
      db.activity.create({ data: { instanceId: id, kind: "actSettingsUpdated" } }),
      db.instance.update({ where: { id }, data: { ownerProfileJson: JSON.stringify(profile) } }),
    ]);

    await logAudit({
      actorType: "instance",
      actorId: guard.principal.actorId,
      actorName: guard.principal.actorName,
      action: "instance.update",
      targetLabel: orgName || existing.systemId,
      meta: { ownerProfile: "completed" },
    });

    return NextResponse.json({ completed: true, profile });
  } catch (error) {
    console.error(`PUT /api/instances/${id}/owner-profile failed:`, error);
    return NextResponse.json({ error: "Failed to save owner profile" }, { status: 500 });
  }
}
