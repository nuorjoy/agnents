import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { activityCreateSchema, toActivityDTO, zodError } from "@/lib/server/instance-mapper";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { trialLockResponse } from "@/lib/server/entitlement";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { readJson } from "@/lib/server/http";
import { clampLimit, decodeKeyset, encodeKeyset, keysetPredicate } from "@/lib/server/keyset";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

const DEFAULT_LIMIT = 20;
const MAX_LIMIT = 100;

/** ROUND 37 (task 3-c) — manual-entry throttle: 30 writes / 10 min per
 *  instance + source IP. Checked AFTER the session guard so only
 *  authenticated requests register durable hits (an unauthenticated flood
 *  can never grow the rate-limit table). */
const ACTIVITY_RULE = { limit: 30, windowMs: 10 * 60 * 1000 };

/**
 * GET /api/instances/[id]/activities?limit=20&cursor=<opaque> — activity
 * feed, newest first, KEYSET-paginated (ROUND 57).
 *
 * Contract: `{ activities, nextCursor, total }` —
 *  - `nextCursor` is null exactly when the feed is exhausted; pass it back
 *    verbatim as `?cursor=` to fetch the next page;
 *  - `total` is the instance-wide row count (drives the true "total" KPI —
 *    no longer bounded by the loaded window). ROUND 145 (perf): it is
 *    computed and returned ONLY on the first page (no cursor) — cursor
 *    pages are poll/load-more traffic where the count is unused (clients
 *    keep the first page's value);
 *  - pages are STABLE under concurrent inserts: the cursor encodes the last
 *    `(createdAt, id)` of the page, and the next page resumes strictly
 *    after that row on the same total order the ORDER BY uses.
 *
 * Authorized by the workspace session or an admin session.
 */
export async function GET(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, undefined, { permission: "activity.view" });
  if (guard instanceof NextResponse) return guard;

  try {
    /* ROUND 145 (perf) — the instance-existence re-probe was deleted:
     * requireInstanceAccess already 404s missing/trashed workspaces on
     * both authorization paths (session + admin) before this handler. */

    const url = new URL(req.url);
    const limit = clampLimit(url.searchParams.get("limit"), DEFAULT_LIMIT, MAX_LIMIT);
    const cursorRaw = url.searchParams.get("cursor");
    const cursor = cursorRaw ? decodeKeyset(cursorRaw) : null;
    /* a supplied-but-malformed cursor is a client bug, not a fresh page:
     * answering 400 keeps a broken pager loud instead of silently looping. */
    if (cursorRaw && !cursor) {
      return NextResponse.json(
        { error: "Invalid pagination cursor", code: "BAD_CURSOR" },
        { status: 400 }
      );
    }

    /* take limit + 1 — the extra row only signals hasMore (never returned) */
    const rows = await db.activity.findMany({
      where: { instanceId: id, ...(cursor ? keysetPredicate(cursor) : {}) },
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: limit + 1,
    });
    const hasMore = rows.length > limit;
    const page = hasMore ? rows.slice(0, limit) : rows;
    const nextCursor = hasMore && page.length > 0 ? encodeKeyset(page[page.length - 1]) : null;

    /* ROUND 145 (perf) — the instance-wide count only ships on the FIRST
     * page (no cursor): it re-ran on every 20s poll and every load-more
     * even though it only depends on the instance, not the page. */
    const total = cursor ? undefined : await db.activity.count({ where: { instanceId: id } });

    return NextResponse.json({
      activities: page.map(toActivityDTO),
      nextCursor,
      total,
    });
  } catch (error) {
    console.error(`GET /api/instances/${id}/activities failed:`, error);
    return NextResponse.json({ error: "Failed to list activities" }, { status: 500 });
  }
}

/**
 * POST /api/instances/[id]/activities — record a manual activity entry.
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;

  /* ROUND 42 — guard BEFORE the bounded body read (cross-tenant callers
   * can no longer burn the read + zod parse or probe validation).
   * ROUND 82 (batch-5 audit fix) — a WRITE needs a WRITE permission: the
   * manual entry is an operational record, so the gate is modules.edit
   * (owner/manager/staff + platform super/admin) instead of the read-only
   * activity.view; the read-only roles stay denied. */
  const guard = await requireInstanceAccess(id, req, { permission: "modules.edit" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: manual activity WRITES are a business
     surface (the billing view READS this feed, so GET above stays open). */
  const trialLock = await trialLockResponse(id);
  if (trialLock) return trialLock;

  /* ROUND 37 (task 3-c) — bounded body read (declared + streamed caps) in
   * place of the unbounded req.json(); parse order preserved. */
  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = activityCreateSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const { kind, meta } = parsed.data;

  /* ROUND 37 (task 3-c) — durable, restart-safe throttle on manual entries
   * (was: no limit at all on this write surface). */
  if (await rateLimited(`inst-activity:${id}:${clientIp(req)}`, ACTIVITY_RULE)) {
    return tooManyRequests(ACTIVITY_RULE, { error: "Too many activity entries — try again shortly" });
  }

  try {
    const instance = await db.instance.findUnique({ where: { id }, select: { id: true } });
    if (!instance) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }

    const row = await db.activity.create({
      data: { instanceId: id, kind, metaJson: meta ? JSON.stringify(meta) : null },
    });
    return NextResponse.json(toActivityDTO(row), { status: 201 });
  } catch (error) {
    console.error(`POST /api/instances/${id}/activities failed:`, error);
    return NextResponse.json({ error: "Failed to create activity" }, { status: 500 });
  }
}
