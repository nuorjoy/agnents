import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { zodError } from "@/lib/server/instance-mapper";
import { siteContentSchema } from "@/lib/server/site-mapper";
import { toInstanceDTO } from "@/lib/server/instance-mapper";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { featureGateResponse } from "@/lib/server/entitlement";
import { logAudit, maskEmail } from "@/lib/server/audit";
import {rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { readJson } from "@/lib/server/http";
import ZAI from "z-ai-web-dev-sdk";
import type { SiteContent } from "@/lib/types";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

type RouteContext = { params: Promise<{ id: string }> };

/** ROUND 37 (task 3-c) — durable per-instance limiter: 12 runs / 10 min.
 * Replaces the former in-memory 45s cooldown Map: the quota now lives in
 * the database rate-limit table, so it SURVIVES restarts, is shared across
 * processes, and a restart can no longer reset an abusive instance's
 * cooldown (the old Map's reset-on-restart weakness). */
const TRANSLATE_RULE = { limit: 12, windowMs: 10 * 60 * 1000 };

/** Email-shaped values are PII — mask them for the audit trail; plain admin
 *  handles ("sarah.super") pass through so the trail stays correlatable. */
const EMAIL_SHAPE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function auditActorName(name: string): string {
  return EMAIL_SHAPE.test(name) ? maskEmail(name) : name;
}

/** Max lengths mirroring the EN content schema (defensive trim). */
const EN_LIMITS = {
  tagline: 90,
  heroTitle: 120,
  heroDesc: 400,
  aboutTitle: 120,
  about: 1500,
  contactAddress: 220,
  workingHours: 200,
  serviceTitle: 80,
  serviceDesc: 200,
} as const;

const clamp = (v: unknown, max: number): string =>
  typeof v === "string" ? v.replace(/\s+/g, " ").trim().slice(0, max) : "";

/**
 * POST /api/instances/[id]/site/translate — AI draft translations for the
 * website's English content (round 33).
 *
 * Body: the CURRENT editor content (SiteContent). The server collects every
 * field whose Arabic original is non-empty but whose EN translation is
 * missing, asks the LLM for natural marketing English, and returns ONLY the
 * suggested translations — nothing is persisted: the owner reviews the
 * draft in the editor and saves through the normal PUT flow. Requires a
 * workspace session for THIS instance; durable 12/10-min per-instance
 * limiter; audited.
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "website.manage" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const featureLock = await featureGateResponse(id, "translations");
  if (featureLock) return featureLock;
  const actor = guard.principal;

  /* ROUND 37 (task 3-c) — bounded body read (2 MB, same cap as the site PUT:
   * the body is the full editor content and can carry the logo data-URL). */
  const body = await readJson(req, 2_000_000);
  if (!body.ok) return body.response;

  const parsed = siteContentSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  /* ROUND 67 — brand-asset fields are OPTIONAL on the write schema (the
   * site PUT merge-keeps them); normalize to the full SiteContent shape.
   * ROUND 87 — the whole schema is now optional (PATCH law); normalize the
   * editor-owned text fields too (the editor always sends them, but a
   * patch-style caller may omit any field). */
  const content: SiteContent = {
    ...parsed.data,
    tagline: parsed.data.tagline ?? "",
    heroTitle: parsed.data.heroTitle ?? "",
    heroDesc: parsed.data.heroDesc ?? "",
    aboutTitle: parsed.data.aboutTitle ?? "",
    about: parsed.data.about ?? "",
    services: parsed.data.services ?? [],
    contactEmail: parsed.data.contactEmail ?? "",
    contactPhone: parsed.data.contactPhone ?? "",
    contactAddress: parsed.data.contactAddress ?? "",
    socialLinks: parsed.data.socialLinks ?? [],
    workingHours: parsed.data.workingHours ?? "",
    logoUrl: parsed.data.logoUrl ?? "",
    signatureUrl: parsed.data.signatureUrl ?? "",
    stampUrl: parsed.data.stampUrl ?? "",
    signatureScale: parsed.data.signatureScale ?? 1,
    stampScale: parsed.data.stampScale ?? 1,
    /* ROUND 68 — invoice prefix (optional on write, normalize to "") */
    invoicePrefix: parsed.data.invoicePrefix ?? "",
    /* ROUND 84 (84-LEGAL) — legal texts are read-only for translation
     * (Arabic by design); normalize to the full SiteContent shape. */
    privacyPolicy: parsed.data.privacyPolicy ?? "",
    termsOfUse: parsed.data.termsOfUse ?? "",
    /* ROUND 86 — colors/fonts/langs are optional on the write schema;
     * normalize to the full SiteContent shape ("" = platform default). */
    storeTheme: parsed.data.storeTheme ?? "",
    siteFont: parsed.data.siteFont ?? "",
    storeFont: parsed.data.storeFont ?? "",
    dashFont: parsed.data.dashFont ?? "",
    dashTheme: parsed.data.dashTheme ?? "",
  };

  /* ROUND 37 (task 3-c) — durable limiter (was: in-memory cooldown Map). */
  if (await rateLimited(`inst-translate:${id}`, TRANSLATE_RULE)) {
    return tooManyRequests(TRANSLATE_RULE, { error: "Translation is busy — try again in a moment", code: "RATE" });
  }

  /* collect the untranslated payload for the model */
  const en = content.en;
  const need = (arVal: string, enVal: string | undefined): string | null =>
    arVal.trim().length > 0 && !(enVal ?? "").trim() ? arVal : null;

  const fields: Record<string, string> = {};
  const map: [string, string, string | undefined][] = [
    ["tagline", content.tagline, en?.tagline],
    ["heroTitle", content.heroTitle, en?.heroTitle],
    ["heroDesc", content.heroDesc, en?.heroDesc],
    ["aboutTitle", content.aboutTitle, en?.aboutTitle],
    ["about", content.about, en?.about],
    ["contactAddress", content.contactAddress, en?.contactAddress],
    ["workingHours", content.workingHours, en?.workingHours],
  ];
  for (const [key, arVal, enVal] of map) {
    const v = need(arVal, enVal);
    if (v) fields[key] = v;
  }
  const services = content.services
    .map((s, i) => ({
      index: i,
      title: need(s.title, s.titleEn),
      desc: need(s.desc, s.descEn),
    }))
    .filter((s) => s.title || s.desc);

  const fieldCount = Object.keys(fields).length;
  const serviceCount = services.length;
  if (fieldCount === 0 && serviceCount === 0) {
    return NextResponse.json({ error: "NOTHING_TO_TRANSLATE" }, { status: 422 });
  }

  const instanceRow = await db.instance.findUnique({ where: { id } });
  if (!instanceRow) {
    return NextResponse.json({ error: "Instance not found" }, { status: 404 });
  }

  try {
    const zai = await ZAI.create();
    const system =
      "You are a professional Arabic-to-English translator specializing in business website marketing copy. " +
      "Respond with VALID JSON ONLY — no markdown fences, no commentary, exactly matching the requested schema. " +
      "Translations must be natural, concise, professional marketing English. Keep brand/company names as written. " +
      "Preserve tone and keep the same approximate length as the source. Keep numbers and times formatted naturally for English.";

    const user =
      "Translate the following Arabic website fields into English.\n\n" +
      `Fields (return an object with exactly these keys, each translated): ${JSON.stringify(fields)}\n\n` +
      (serviceCount > 0
        ? `Service cards (return an array "services" of objects {"index": <same index>, "title": "<translation or empty>", "desc": "<translation or empty>"}): ${JSON.stringify(services.map((s) => ({ index: s.index, title: s.title, desc: s.desc })))}\n\n`
        : "") +
      'Return JSON: {"<each field key>": "<english>", "services": [{"index": number, "title": string, "desc": string}]}';

    const completion = await zai.chat.completions.create({
      messages: [
        { role: "assistant", content: system },
        { role: "user", content: user },
      ],
      thinking: { type: "disabled" },
    });

    const raw = completion.choices[0]?.message?.content ?? "";
    const cleaned = raw
      .trim()
      .replace(/^```(?:json)?\s*/i, "")
      .replace(/\s*```$/, "");
    let parsedLLM: unknown;
    try {
      parsedLLM = JSON.parse(cleaned);
    } catch {
      return NextResponse.json({ error: "TRANSLATE_PARSE" }, { status: 502 });
    }
    if (!parsedLLM || typeof parsedLLM !== "object") {
      return NextResponse.json({ error: "TRANSLATE_PARSE" }, { status: 502 });
    }
    const obj = parsedLLM as Record<string, unknown>;

    /* accept ONLY what was requested — the model sometimes hallucinates
     * extra keys/services when the payload is small; unknown suggestions
     * are dropped so the owner never sees unrelated drafts. */
    const result = {
      en: {
        tagline: fields.tagline !== undefined ? clamp(obj.tagline, EN_LIMITS.tagline) : "",
        heroTitle: fields.heroTitle !== undefined ? clamp(obj.heroTitle, EN_LIMITS.heroTitle) : "",
        heroDesc: fields.heroDesc !== undefined ? clamp(obj.heroDesc, EN_LIMITS.heroDesc) : "",
        aboutTitle: fields.aboutTitle !== undefined ? clamp(obj.aboutTitle, EN_LIMITS.aboutTitle) : "",
        about: fields.about !== undefined ? clamp(obj.about, EN_LIMITS.about) : "",
        contactAddress:
          fields.contactAddress !== undefined ? clamp(obj.contactAddress, EN_LIMITS.contactAddress) : "",
        workingHours:
          fields.workingHours !== undefined ? clamp(obj.workingHours, EN_LIMITS.workingHours) : "",
      },
      services: Array.isArray(obj.services)
        ? (obj.services as Record<string, unknown>[])
            .map((s) => ({
              index: typeof s.index === "number" ? s.index : -1,
              titleEn: clamp(s.title, EN_LIMITS.serviceTitle),
              descEn: clamp(s.desc, EN_LIMITS.serviceDesc),
            }))
            .filter((s) => {
              const wanted = services.find((w) => w.index === s.index);
              if (!wanted) return false;
              return (
                (wanted.title !== null && s.titleEn.length > 0) ||
                (wanted.desc !== null && s.descEn.length > 0)
              );
            })
        : [],
    };

    const suggested =
      Object.values(result.en).filter((v) => v.length > 0).length + result.services.length;
    if (suggested === 0) {
      return NextResponse.json({ error: "TRANSLATE_EMPTY" }, { status: 502 });
    }

    const instance = toInstanceDTO(instanceRow);
    await logAudit({
      actorType: actor.kind === "admin" ? "admin" : "instance",
      actorId: actor.actorId,
      actorName: auditActorName(actor.actorName),
      action: "instance.siteTranslate",
      targetLabel: instance.org.name || instance.systemId,
      meta: { fields: String(fieldCount), services: String(serviceCount), suggested: String(suggested) },
    });

    return NextResponse.json(result);
  } catch (error) {
    console.error(`POST /api/instances/${id}/site/translate failed:`, error);
    return NextResponse.json({ error: "TRANSLATE_FAILED" }, { status: 502 });
  }
}
