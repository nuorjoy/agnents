import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toInstanceDTO, zodError } from "@/lib/server/instance-mapper";
import {
  defaultSiteContent,
  readSiteContent,
  sitePayloadSchema,
  toSiteDTO,
} from "@/lib/server/site-mapper";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { featureGateResponse } from "@/lib/server/entitlement";
import { withStorageQuotaWrite } from "@/lib/server/usage";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { ImageValidationError } from "@/lib/server/upload-validation";
import { isManagedImageRef, storeImageDataUrl } from "@/lib/server/image-store";
import { SYSTEM_MAP } from "@/data/catalog";
import { categoryTheme } from "@/lib/site-themes";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/** Email-shaped values are PII — mask them for the audit trail; plain admin
 *  handles ("sarah.super") pass through so the trail stays correlatable. */
const EMAIL_SHAPE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function auditActorName(name: string): string {
  return EMAIL_SHAPE.test(name) ? maskEmail(name) : name;
}

/**
 * GET /api/instances/[id]/site — the workspace's public website record.
 * Requires a workspace session for THIS instance (or an admin session).
 *
 * Auto-creates the DRAFT on first access: the owner opens the "الموقع
 * الإلكتروني" dashboard view, the site is initialized from the instance's
 * own data (smart defaults), and they review → launch. No blank pages.
 */
export async function GET(_req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, undefined, { permission: "website.manage" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const featureLock = await featureGateResponse(id, "publicWebsite");
  if (featureLock) return featureLock;

  try {
    const instanceRow = await db.instance.findUnique({ where: { id } });
    if (!instanceRow) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }

    let siteRow = await db.site.findUnique({ where: { instanceId: id } });
    if (!siteRow) {
      const instance = toInstanceDTO(instanceRow);
      /* the draft inherits the visual identity of ITS system's sector */
      const system = SYSTEM_MAP[instanceRow.systemId];
      const categoryId = system ? system.c : undefined;
      siteRow = await db.site.create({
        data: {
          instanceId: id,
          published: false,
          theme: categoryTheme(categoryId),
          views: 0,
          contentJson: JSON.stringify(defaultSiteContent(instance)),
        },
      });
    }

    return NextResponse.json(toSiteDTO(siteRow));
  } catch (error) {
    console.error(`GET /api/instances/${id}/site failed:`, error);
    return NextResponse.json({ error: "Failed to fetch site" }, { status: 500 });
  }
}

/**
 * PUT /api/instances/[id]/site — save website content / theme / publish
 * state. Publishing (false → true) stamps launchedAt, records an
 * actSiteLaunched activity and an instance.siteLaunch audit entry so the
 * launch moment is part of the workspace story.
 */
export async function PUT(req: Request, { params }: RouteContext) {
  const { id } = await params;

  /* ROUND 42 — guard BEFORE the bounded body read: an unauthenticated or
   * cross-tenant caller can no longer burn a 2 MB read + zod parse, and
   * the route never reveals its validation behavior to non-owners. */
  const guard = await requireInstanceAccess(id, req, { permission: "website.manage" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const featureLock = await featureGateResponse(id, "publicWebsite");
  if (featureLock) return featureLock;
  const actor = guard.principal;

  /* ROUND 37 (task 3-c) — bounded body read: 2 MB cap (the payload carries
   * the logo data-URL; the write schema caps it at 1M chars ≈ 1 MB). */
  const body = await readJson(req, 2_000_000);
  if (!body.ok) return body.response;

  const parsed = sitePayloadSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const data = parsed.data;

  try {
    const instanceRow = await db.instance.findUnique({ where: { id } });
    if (!instanceRow) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }
    const instance = toInstanceDTO(instanceRow);
    const targetLabel = instance.org.name || instance.systemId;

    let siteRow = await db.site.findUnique({ where: { instanceId: id } });

    /* ROUND 37 (task 3-c) — server-side logo validation. The payload schema
     * only checks the data-URL SHAPE; nothing about the bytes was verified
     * until then (spoofed MIME, polyglots, decompression bombs, EXIF payloads
     * all persisted verbatim). The submitted logo is inspected with sharp
     * (magic bytes, dimension / pixel caps) and RE-ENCODED to a clean WebP —
     * the returned value REPLACES the input before anything is persisted.
     *
     * ROUND 40 (P2 — storage layer): the sanitized bytes now live as a
     * content-addressed FILE (storage/images/<sha256>.webp, see
     * image-store.ts) and the persisted logoUrl is the short reference
     * /api/images/<sha256> instead of ~700KB of inline base64. Semantics:
     *   • "" = "no logo" — stays empty, never validated;
     *   • a MANAGED ref (/api/images/<64hex>) — persisted AS-IS: it was
     *     minted by THIS server from already-validated bytes (editors echo
     *     the stored ref back on unrelated saves, or reference an existing
     *     asset) — no sharp re-encode, byte-identical idempotence;
     *   • an echo of the STORED value (legacy data-URL rows not yet
     *     migrated) — skipped, so re-saving never re-encodes / re-degrades;
     *   • any other data-URL — full pipeline + stored, ImageValidationError
     *     → 400 with its user-presentable message.
     * Only the persisted asset fields are transformed; the rest of the
     * payload passes through unchanged. Runs AFTER auth so anonymous callers
     * can never burn sharp CPU on crafted images.
     *
     * ROUND 67 — the exact same pipeline now covers ALL THREE brand assets:
     * the logo, the invoice SIGNATURE and the invoice STAMP (identical
     * semantics per field, evaluated independently). Asset fields are
     * OPTIONAL on the write schema; a field ABSENT from the payload keeps
     * its stored value (merge-keep), so a stale editor bundle can never
     * wipe a brand asset it does not know about — while "" (present) still
     * means "remove". */
    if (data.content !== undefined) {
      /* ROUND 87 — THE PATCH MERGE: the base is the STORED content (or the
       * smart defaults on a first save) and ONLY fields PRESENT in the
       * payload overlay it. Absent = keep stored — for EVERY field, not
       * just the brand assets (round 67) or the styling set (round 86).
       * This is the server half of the fix that makes cross-surface
       * stale-echo reverts impossible: a payload that does not carry a
       * field can never clobber it. */
      const storedContent = siteRow
        ? readSiteContent(siteRow.contentJson)
        : defaultSiteContent(instance);
      const merged: Record<string, unknown> = {
        ...storedContent,
        ...Object.fromEntries(
          Object.entries(data.content as Record<string, unknown>).filter(
            ([, v]) => v !== undefined
          )
        ),
      };
      const ASSET_FIELDS = ["logoUrl", "signatureUrl", "stampUrl"] as const;
      const next = { ...merged };
      for (const field of ASSET_FIELDS) {
        const incoming = next[field];
        if (typeof incoming !== "string" || incoming === "") continue;
        if (isManagedImageRef(incoming)) {
          /* server-minted, pre-validated — persist verbatim (dedupe by ref) */
        } else if (incoming !== (storedContent?.[field] ?? "")) {
          try {
            const stored = await storeImageDataUrl(incoming, {
              maxInputBytes: 3 * 1024 * 1024,
              maxOutputBytes: 700 * 1024,
            });
            next[field] = stored.url;
          } catch (error) {
            if (error instanceof ImageValidationError) {
              return NextResponse.json({ error: error.message }, { status: 400 });
            }
            throw error;
          }
        }
      }
      /* the merge resolved every field to a definite value; the cast is sound
         because every source is either a validated write-schema value or the
         stored full SiteContent. */
      data.content = next as typeof data.content;
    }

    if (!siteRow) {
      // first save on an unsaved draft — the PATCH MERGE above already
      // resolved data.content against the smart defaults; persist that.
      siteRow = await db.site.create({
        data: {
          instanceId: id,
          published: false,
          theme: data.theme ?? "aurora",
          views: 0,
          contentJson: JSON.stringify(
            (data.content as unknown as object) ?? defaultSiteContent(instance)
          ),
        },
      });
    }

    const wasPublished = siteRow.published;
    const nowPublished = data.published ?? wasPublished;
    const launching = !wasPublished && nowPublished;

    let contentChanged = false;
    if (data.content !== undefined) {
      try {
        contentChanged = JSON.stringify(data.content) !== siteRow.contentJson;
      } catch {
        contentChanged = true;
      }
    }
    const themeChanged = data.theme !== undefined && data.theme !== siteRow.theme;

    /* ROUND 47/171 — storage-quota gate: website content REPLACES the
       stored JSON, so the projection nets out the outgoing bytes first.
       The check and the update commit atomically under the tenant's
       storage-quota advisory lock. Non-content field updates (theme /
       published / launch) do not affect usage and skip the gate. */
    let updated: Awaited<ReturnType<typeof db.site.update>>;
    if (data.content !== undefined) {
      const incoming = Buffer.byteLength(JSON.stringify(data.content), "utf8");
      const outgoing = Buffer.byteLength(siteRow.contentJson ?? "", "utf8");
      const gated = await withStorageQuotaWrite(
        id,
        { incomingBytes: incoming, replaceBytes: Math.min(incoming, outgoing) },
        (tx) =>
          tx.site.update({
            where: { id: siteRow.id },
            data: {
              contentJson: JSON.stringify(data.content),
              ...(data.theme !== undefined ? { theme: data.theme } : {}),
              ...(data.published !== undefined ? { published: nowPublished } : {}),
              ...(launching ? { launchedAt: new Date() } : {}),
            },
          })
      );
      if (!gated.ok) return gated.response;
      updated = gated.result;
    } else {
      updated = await db.site.update({
        where: { id: siteRow.id },
        data: {
          ...(data.theme !== undefined ? { theme: data.theme } : {}),
          ...(data.published !== undefined ? { published: nowPublished } : {}),
          ...(launching ? { launchedAt: new Date() } : {}),
        },
      });
    }

    /* ROUND 117 — when brand assets (logo/signature/stamp) were replaced or
     * cleared, the OLD content's managed refs are re-checked against a
     * fresh reference scan and reclaimed when nothing holds them anymore
     * (fire-and-forget; an unchanged ref stays referenced and survives). */
    if (data.content !== undefined) {
      const oldRefs = [...(siteRow.contentJson ?? "").matchAll(/\/api\/images\/([a-f0-9]{64})/g)].map(
        (m) => (m[1] ? `/api/images/${m[1]}` : "")
      );
      if (oldRefs.length > 0) {
        const { releaseImageRefs } = await import("@/lib/server/image-ref-gc");
        void releaseImageRefs(oldRefs).catch(() => undefined);
      }
    }

    if (launching) {
      await db.activity.create({
        data: { instanceId: id, kind: "actSiteLaunched", metaJson: JSON.stringify({ views: "0" }) },
      });
    } else if (contentChanged || themeChanged || data.published !== undefined) {
      await db.activity.create({ data: { instanceId: id, kind: "actSettingsUpdated" } });
    }

    const actorName = auditActorName(actor.actorName);
    await logAudit(
      launching
        ? {
            actorType: actor.kind === "admin" ? "admin" : "instance",
            actorId: actor.actorId,
            actorName,
            action: "instance.siteLaunch",
            targetLabel,
            meta: { theme: updated.theme },
          }
        : {
            actorType: actor.kind === "admin" ? "admin" : "instance",
            actorId: actor.actorId,
            actorName,
            action: "instance.siteUpdate",
            targetLabel,
            meta: {
              ...(contentChanged ? { content: "updated" } : {}),
              ...(themeChanged ? { theme: data.theme } : {}),
              ...(data.published !== undefined && !launching
                ? { published: nowPublished ? "true" : "false" }
                : {}),
            },
          }
    );

    return NextResponse.json(toSiteDTO(updated));
  } catch (error) {
    console.error(`PUT /api/instances/${id}/site failed:`, error);
    return NextResponse.json({ error: "Failed to update site" }, { status: 500 });
  }
}
