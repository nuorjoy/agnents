import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { siteCustomerStatusRead } from "@/lib/server/admin-mapper";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { trialLockResponse } from "@/lib/server/entitlement";
import { decryptField } from "@/lib/server/crypto-vault";
import type { SiteCustomerDTO } from "@/lib/types";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * GET /api/instances/[id]/site/customers — the subscriber workspace's view of
 * the members registered through ITS public website (round 29, "عملاء الموقع").
 *
 * Requires a workspace session for THIS instance (or an admin session). Each
 * row joins a live inquiry count: public support tickets linked to this
 * instance whose requester email matches the customer (mirrors the admin
 * Sites customer manager). 404 { code: "SITE_NOT_FOUND" } when the instance
 * has no website yet — the view then points the owner to the website view.
 */
export async function GET(_req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, undefined, { permission: "customers.view" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const trialLock = await trialLockResponse(id);
  if (trialLock) return trialLock;

  try {
    const site = await db.site.findUnique({
      where: { instanceId: id },
      select: { instanceId: true },
    });
    if (!site) {
      return NextResponse.json(
        { error: "This workspace has no website yet", code: "SITE_NOT_FOUND" },
        { status: 404 }
      );
    }

    const customers = await db.siteCustomer.findMany({
      where: { instanceId: id, deletedAt: null },
      orderBy: [{ createdAt: "desc" }],
      select: {
        id: true,
        name: true,
        email: true,
        emailIndex: true,
        phone: true,
        status: true,
        lastLoginAt: true,
        createdAt: true,
        /* ROUND 75 — verification state drives the owner console chips */
        emailVerifiedAt: true,
      },
      take: 500,
    });

    /* inquiry counts — public tickets linked to this instance. ROUND 36
       (perf): matched through the requesterEmailIndex BLIND INDEX (no
       per-ticket AES-GCM decrypt; mirrors the admin Sites manager). */
    const tickets = await db.supportTicket.groupBy({
      by: ["requesterEmailIndex"],
      where: { instanceId: id, source: "public" },
      _count: { _all: true },
    });
    const inquiriesByIndex = new Map<string, number>();
    for (const ticket of tickets) {
      if (ticket.requesterEmailIndex) {
        inquiriesByIndex.set(ticket.requesterEmailIndex, ticket._count._all);
      }
    }

    const rows: SiteCustomerDTO[] = customers.map((row) => {
      const email = decryptField(row.email) ?? "";
      return {
        id: row.id,
        name: row.name,
        email,
        phone: decryptField(row.phone) ?? null,
        status: siteCustomerStatusRead.parse(row.status),
        inquiries: inquiriesByIndex.get(row.emailIndex ?? "") ?? 0,
        createdAt: row.createdAt.toISOString(),
        lastLoginAt: row.lastLoginAt ? row.lastLoginAt.toISOString() : null,
        emailVerified: row.emailVerifiedAt !== null,
      };
    });

    return NextResponse.json(rows);
  } catch (error) {
    console.error(`GET /api/instances/${id}/site/customers failed:`, error);
    return NextResponse.json({ error: "Failed to list site customers" }, { status: 500 });
  }
}
