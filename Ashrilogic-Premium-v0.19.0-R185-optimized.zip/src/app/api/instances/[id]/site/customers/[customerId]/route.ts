import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { siteCustomerModerateSchema } from "@/lib/server/admin-mapper";
import { zodError } from "@/lib/server/instance-mapper";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { trialLockResponse } from "@/lib/server/entitlement";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { decryptField } from "@/lib/server/crypto-vault";
import { readJson } from "@/lib/server/http";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import {
  issueVerifyToken,
  orgDisplayName,
  sendVerificationEmail,
  verificationUrl,
} from "@/lib/server/verification";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string; customerId: string }> };

/** staff re-dispatch throttle: one verification email / minute / customer
 *  (mirrors the customer-initiated resend cooldown). */
const STAFF_RESEND_RULE = { limit: 1, windowMs: 60 * 1000 };

/**
 * PATCH /api/instances/[id]/site/customers/[customerId] — the workspace owner
 * moderates one member registered through their public website:
 *
 *  - { status } — ban blocks future sign-ins and cuts off the live session
 *    (the public /me guard rejects banned accounts); unban restores access
 *    (round 29). Audit: siteCustomer.moderate.
 *  - { verify: true } — ROUND 75 staff-assisted email confirmation: the
 *    owner confirmed the customer's identity out-of-band (in person, by
 *    phone), so the address is marked verified without a link. Audit:
 *    siteCustomer.verify.
 *  - { resendVerify: true } — ROUND 75 re-dispatch: rotates the single-use
 *    token and mails a fresh link (SMTP / dev spool). The owner never sees
 *    the link itself. Audit: siteCustomer.verifyResend.
 *
 * All writes are instance-scoped (a foreign customer id is a flat 404) and
 * audited with surface "dashboard-customers".
 */
export async function PATCH(req: Request, { params }: RouteContext) {
  const { id, customerId } = await params;

  /* ROUND 42 — guard BEFORE the bounded body read (cross-tenant callers
   * can no longer burn the read + zod parse or probe validation). */
  const guard = await requireInstanceAccess(id, req, { permission: "support.manage" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const trialLock = await trialLockResponse(id);
  if (trialLock) return trialLock;
  const actor = guard.principal;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = siteCustomerModerateSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const { status, verify, resendVerify } = parsed.data;

  try {
    const existing = await db.siteCustomer.findUnique({
      where: { id: customerId },
      select: {
        id: true,
        instanceId: true,
        name: true,
        email: true,
        status: true,
        emailVerifiedAt: true,
      },
    });
    if (!existing || existing.instanceId !== id) {
      return NextResponse.json({ error: "Customer not found on this site" }, { status: 404 });
    }
    const masked = maskEmail(decryptField(existing.email) ?? "");

    /* ---- ROUND 75 staff-assisted verification ---- */
    if (verify || resendVerify) {
      if (resendVerify) {
        if (
          await rateLimited(`verify-resend:${customerId}:${clientIp(req)}`, STAFF_RESEND_RULE, {
            failClosed: true,
          })
        ) {
          return tooManyRequests(STAFF_RESEND_RULE, { error: "Please wait a minute between dispatches", code: "RESEND_COOLDOWN" });
        }
        const orgName = await orgDisplayName(id);
        const { token } = await issueVerifyToken(customerId);
        const sent = await sendVerificationEmail({
          to: decryptField(existing.email) ?? "",
          name: existing.name,
          url: verificationUrl(new URL(req.url).origin, id, token),
          orgName,
        });
        await logAudit({
          actorType: actor.kind === "admin" ? "admin" : "instance",
          actorId: actor.actorId,
          actorName: actor.actorName,
          action: "siteCustomer.verifyResend",
          targetLabel: masked,
          meta: { surface: "dashboard-customers", site: id, customer: customerId, sent: String(sent) },
        });
        return NextResponse.json({ ok: true, resent: sent });
      }

      /* verify: true — idempotent no-op guard keeps the audit trail honest */
      if (existing.emailVerifiedAt) {
        return NextResponse.json(
          { error: "Customer already verified", code: "ALREADY_VERIFIED" },
          { status: 409 }
        );
      }
      await db.siteCustomer.update({
        where: { id: customerId },
        data: { emailVerifiedAt: new Date(), verifyTokenHash: null, verifyTokenExpiresAt: null },
      });
      await logAudit({
        actorType: actor.kind === "admin" ? "admin" : "instance",
        actorId: actor.actorId,
        actorName: actor.actorName,
        action: "siteCustomer.verify",
        targetLabel: masked,
        meta: { surface: "dashboard-customers", site: id, customer: customerId },
      });
      return NextResponse.json({ ok: true });
    }

    /* ---- classic status moderation (round 29) ---- */
    if (!status) {
      return NextResponse.json({ error: "Nothing to do" }, { status: 422 });
    }
    if (existing.status === status) {
      return NextResponse.json({ error: "Customer already in this state" }, { status: 409 });
    }

    const row = await db.siteCustomer.update({
      where: { id: customerId },
      data: { status: status ?? existing.status },
      select: { id: true, name: true, email: true },
    });

    /* ROUND 37 — audit PII: masked email in targetLabel/meta (the raw
       address never enters the trail); correlation via the customer id.
       No password reset exists on this route — moderation only, and a ban
       already cuts the live session via the public /me guard. */
    await logAudit({
      actorType: actor.kind === "admin" ? "admin" : "instance",
      actorId: actor.actorId,
      actorName: actor.actorName,
      action: "siteCustomer.moderate",
      targetLabel: `${maskEmail(decryptField(row.email) ?? "")} · ${status}`,
      meta: { surface: "dashboard-customers", site: id, customer: customerId, status },
    });

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error(`PATCH /api/instances/${id}/site/customers/${customerId} failed:`, error);
    return NextResponse.json({ error: "Failed to update customer" }, { status: 500 });
  }
}

/**
 * DELETE /api/instances/[id]/site/customers/[customerId] — permanently remove
 * a website member's account from this workspace's site (their filed
 * inquiries remain in the support inbox). Audit-logged with surface
 * "dashboard-customers".
 */
export async function DELETE(_req: Request, { params }: RouteContext) {
  const { id, customerId } = await params;

  const guard = await requireInstanceAccess(id, _req, { permission: "support.manage" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const trialLock = await trialLockResponse(id);
  if (trialLock) return trialLock;
  const actor = guard.principal;

  try {
    const existing = await db.siteCustomer.findUnique({
      where: { id: customerId },
      select: { id: true, instanceId: true, name: true, email: true, deletedAt: true },
    });
    if (!existing || existing.instanceId !== id || existing.deletedAt) {
      return NextResponse.json({ error: "Customer not found on this site" }, { status: 404 });
    }

    /* ROUND 87 (trash) — soft delete: the customer moves to the workspace
       trash (email blind index mangled so a fresh signup with the same
       address never collides; orders stay attached and restorable). The
       customer's live sessions die with the epoch bump. */
    await db.siteCustomer.update({
      where: { id: existing.id },
      data: { sessionVersion: { increment: 1 } },
    });
    const { softDelete } = await import("@/lib/server/trash");
    const result = await softDelete("siteCustomer", existing.id, {
      kind: actor.kind === "admin" ? "admin" : "instance",
      actorId: actor.actorId,
      actorName: actor.actorName,
    }, { instanceScope: id });
    if (!result.ok) {
      return NextResponse.json({ error: "Failed to delete customer" }, { status: result.status });
    }
    await logAudit({
      actorType: actor.kind === "admin" ? "admin" : "instance",
      actorId: actor.actorId,
      actorName: actor.actorName,
      action: "siteCustomer.delete",
      /* ROUND 37 — masked email; correlation via the customer id in meta */
      targetLabel: maskEmail(decryptField(existing.email) ?? ""),
      meta: { surface: "dashboard-customers", site: id, customer: customerId, name: existing.name, soft: "true" },
    });

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error(`DELETE /api/instances/${id}/site/customers/${customerId} failed:`, error);
    return NextResponse.json({ error: "Failed to delete customer" }, { status: 500 });
  }
}
