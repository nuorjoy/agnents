import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toTicketDTO } from "@/lib/server/admin-mapper";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { trialLockResponse } from "@/lib/server/entitlement";
import type { SiteInquiryTriageDTO } from "@/lib/types";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/** Max triage rows served (newest activity first). */
const TRIAGE_CAP = 200;

/**
 * ROUND 74 — GET /api/instances/[id]/site/inquiries
 *
 * The owner's triage inbox: the public support inquiries filed through
 * THEIR website (source "public", instance-scoped) — the same blind-index
 * join the customers console counts with, now with the full text so the
 * owner can read AND reply without leaving the workspace.
 *
 * Optional `?customer=<siteCustomerId>` drills into ONE customer (resolved
 * through the email blind index server-side — the address never travels in
 * the query string). 404 { code: "SITE_NOT_FOUND" } mirrors the customers
 * route when the workspace has no website yet.
 */
export async function GET(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, undefined, { permission: "support.manage" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse an expired trial. */
  const trialLock = await trialLockResponse(id);
  if (trialLock) return trialLock;

  try {
    const site = await db.site.findUnique({
      where: { instanceId: id },
      select: { instanceId: true },
    });
    if (!site) {
      return NextResponse.json(
        { error: "This workspace has no website yet", code: "SITE_NOT_FOUND" },
        { status: 404 }
      );
    }

    /* optional per-customer drill-down — the blind index is resolved from
     * the SiteCustomer row (which must belong to THIS instance) so the
     * filter can never be aimed at another workspace's tickets. ROUND 87 —
     * a trashed (soft-deleted) customer 404s here like any vanished row. */
    const customerParam = new URL(req.url).searchParams.get("customer");
    let emailIndex: string | null = null;
    if (customerParam) {
      const customer = await db.siteCustomer.findUnique({
        where: { id: customerParam, deletedAt: null },
        select: { emailIndex: true, instanceId: true },
      });
      if (!customer || customer.instanceId !== id) {
        return NextResponse.json({ error: "Customer not found" }, { status: 404 });
      }
      emailIndex = customer.emailIndex;
    }

    const rows = await db.supportTicket.findMany({
      where: {
        instanceId: id,
        source: "public",
        ...(emailIndex !== null ? { requesterEmailIndex: emailIndex } : {}),
      },
      orderBy: [{ updatedAt: "desc" }, { id: "desc" }],
      take: TRIAGE_CAP,
    });

    /* replyUnread — the org drafted a reply the customer hasn't opened yet
     * (drives the "لم يقرأه العميل" chip in the triage dialog). */
    const rowsDto: SiteInquiryTriageDTO[] = rows.map((row) => ({
      ...toTicketDTO(row),
      replyUnread: row.reply != null && row.replyReadAt == null,
    }));

    return NextResponse.json(rowsDto);
  } catch (error) {
    console.error(`GET /api/instances/${id}/site/inquiries failed:`, error);
    return NextResponse.json({ error: "Failed to list site inquiries" }, { status: 500 });
  }
}
