import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  encryptProfileJson,
  memberCreateSchema,
  memberUpdateSchema,
  readMemberProfile,
  toMemberDTO,
  zodError,
} from "@/lib/server/instance-mapper";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { trialLockResponse } from "@/lib/server/entitlement";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { encryptField } from "@/lib/server/crypto-vault";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/** Round 36 — absolute member cap even without an assigned package. */
const ABSOLUTE_MEMBER_CAP = 500;

/** ROUND 147 — TOCTOU closure marker: thrown from INSIDE the create
 *  transaction when the live seat count has already hit the plan cap
 *  (two concurrent invites can both pass the friendly pre-check above the
 *  transaction and then race past it). The POST catch below translates it
 *  into the byte-identical 403 refusal the pre-check emits — rolling the
 *  transaction back so NO row is ever created past the cap. */
class PlanUserLimitError extends Error {
  constructor(
    readonly limit: number,
    readonly hasPackage: boolean,
  ) {
    super("PLAN_USER_LIMIT");
    this.name = "PlanUserLimitError";
  }
}

/** Email-shaped values are PII — mask them for the audit trail; plain admin
 *  handles ("sarah.super") pass through so the trail stays correlatable. */
const EMAIL_SHAPE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function auditActorName(name: string): string {
  return EMAIL_SHAPE.test(name) ? maskEmail(name) : name;
}

/** GET /api/instances/[id]/members — team roster (oldest first, bounded). */
export async function GET(_req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, undefined, { permission: "team.view" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const trialLock = await trialLockResponse(id);
  if (trialLock) return trialLock;

  try {
    /* ROUND 145 (perf) — the instance-existence re-probe was deleted:
     * requireInstanceAccess already 404s missing/trashed workspaces on
     * both authorization paths (session + admin) before this handler —
     * trashed workspaces never serve a team roster. */
    const rows = await db.teamMember.findMany({
      where: { instanceId: id, deletedAt: null },
      orderBy: { createdAt: "asc" },
      take: 200,
    });
    return NextResponse.json(rows.map(toMemberDTO));
  } catch (error) {
    console.error(`GET /api/instances/${id}/members failed:`, error);
    return NextResponse.json({ error: "Failed to list members" }, { status: 500 });
  }
}

/**
 * POST /api/instances/[id]/members — invite a team member and log actUserAdded.
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;

  /* ROUND 42 — guard BEFORE the bounded body read (cross-tenant callers
   * can no longer burn the read + zod parse or probe validation). */
  const guard = await requireInstanceAccess(id, req, { permission: "team.manage" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const trialLock = await trialLockResponse(id);
  if (trialLock) return trialLock;

  /* ROUND 37 (task 3-c) — bounded body read in place of the unbounded
   * req.json(); parse order preserved. */
  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = memberCreateSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const data = parsed.data;

  try {
    const instance = await db.instance.findUnique({
      where: { id, deletedAt: null },
      select: { id: true, packageId: true, package: { select: { maxUsers: true, nameEn: true } } },
    });
    if (!instance) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }

    /* ROUND 36 — business-rule enforcement: the assigned plan's maxUsers
       caps the team size (the 6th member on a 5-user plan is refused with
       403 even when the client is bypassed). No package → absolute cap.
       ROUND 87 — trashed members release their seat (live count only). */
    const count = await db.teamMember.count({ where: { instanceId: id, deletedAt: null } });
    const limit = instance.packageId
      ? Math.min(instance.package?.maxUsers ?? ABSOLUTE_MEMBER_CAP, ABSOLUTE_MEMBER_CAP)
      : ABSOLUTE_MEMBER_CAP;
    if (count >= limit) {
      return NextResponse.json(
        {
          error:
            instance.packageId
              ? `Your plan allows at most ${limit} team members — upgrade to add more`
              : `Team size is capped at ${limit} members`,
          code: "PLAN_USER_LIMIT",
        },
        { status: 403 }
      );
    }

    /* member + activity trail land atomically (round 36) */
    const row = await db.$transaction(async (tx) => {
      /* ROUND 147 — TOCTOU closure (owner's rule: the team may NEVER exceed
       * the package/units): the seat count is re-read from INSIDE the same
       * transaction that creates the row — the count is the race surface
       * (the package row is not), so the limit value stays the one computed
       * from the fetch above. Belt+braces with the pre-check: an identical
         refusal, but now no concurrent invite can slip a row past the cap. */
      const liveCount = await tx.teamMember.count({ where: { instanceId: id, deletedAt: null } });
      if (liveCount >= limit) {
        throw new PlanUserLimitError(limit, instance.packageId != null);
      }
      const created = await tx.teamMember.create({
        data: {
          instanceId: id,
          name: data.name,
          /* round 35 — team email sealed at rest */
          email: encryptField(data.email) ?? "",
          role: data.role,
          /* ROUND 68 — extended profile sealed as one envelope */
          profileJson: encryptProfileJson({
            phone: data.phone,
            jobTitle: data.jobTitle,
            birthDate: data.birthDate,
            gender: data.gender,
            avatarUrl: data.avatarUrl,
            nameAlt: data.nameAlt,
            jobTitleAlt: data.jobTitleAlt,
          }),
        },
      });
      await tx.activity.create({
        data: { instanceId: id, kind: "actUserAdded", metaJson: JSON.stringify({ name: data.name }) },
      });
      return created;
    });
    await logAudit({
      actorType: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: auditActorName(guard.principal.actorName),
      action: "instance.memberAdd",
      targetLabel: data.name,
    });
    return NextResponse.json(toMemberDTO(row), { status: 201 });
  } catch (error) {
    /* ROUND 147 — the in-transaction seat re-check refuses with the EXACT
     * body/code/message of the pre-check above (403 PLAN_USER_LIMIT). */
    if (error instanceof PlanUserLimitError) {
      return NextResponse.json(
        {
          error: error.hasPackage
            ? `Your plan allows at most ${error.limit} team members — upgrade to add more`
            : `Team size is capped at ${error.limit} members`,
          code: "PLAN_USER_LIMIT",
        },
        { status: 403 }
      );
    }
    console.error(`POST /api/instances/${id}/members failed:`, error);
    return NextResponse.json({ error: "Failed to add member" }, { status: 500 });
  }
}

/**
 * PATCH /api/instances/[id]/members?memberId=X — ROUND 68 — update one
 * member's core fields and/or extended profile (phone / jobTitle / birthDate
 * / gender / avatar). Every field is optional; `null` explicitly clears an
 * optional profile field. The member must belong to THIS instance (scoped
 * lookup). Audit-logged as instance.memberUpdate.
 */
export async function PATCH(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const memberId = new URL(req.url).searchParams.get("memberId") ?? "";
  if (!memberId) {
    return NextResponse.json({ error: "memberId is required" }, { status: 400 });
  }

  const guard = await requireInstanceAccess(id, req, { permission: "team.manage" });
  if (guard instanceof NextResponse) return guard;

  const trialLock = await trialLockResponse(id);
  if (trialLock) return trialLock;

  /* ROUND 68 — bounded body: the payload may carry an avatar data-URL
     (cropper output ≈≤165k chars) → 2 MB cap like module records. */
  const body = await readJson(req, 2_000_000);
  if (!body.ok) return body.response;

  const parsed = memberUpdateSchema.safeParse(body.data);
  if (!parsed.success) {
    /* ROUND 145 (perf) — 422 → 400: a zod parse failure is a malformed
     * request, matching the POST branch's contract. */
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const data = parsed.data;

  /* nothing to do — reject empty bodies instead of writing a no-op row */
  const touched =
    data.name !== undefined ||
    data.email !== undefined ||
    data.role !== undefined ||
    data.phone !== undefined ||
    data.jobTitle !== undefined ||
    data.birthDate !== undefined ||
    data.gender !== undefined ||
    data.avatarUrl !== undefined ||
    data.nameAlt !== undefined ||
    data.jobTitleAlt !== undefined;
  if (!touched) {
    return NextResponse.json({ error: "No fields to update" }, { status: 400 });
  }

  try {
    /* scoped lookup — a member id from another instance must never match;
     * ROUND 146 — a trashed member is dead to the live PATCH surface too
     * (DELETE already filtered; trash owns restore from here) */
    const member = await db.teamMember.findFirst({ where: { id: memberId, instanceId: id, deletedAt: null } });
    if (!member) {
      return NextResponse.json({ error: "Member not found" }, { status: 404 });
    }

    /* merge the incoming profile patch over the stored envelope (absent
       fields keep their stored value; null clears → "") */
    const stored = readMemberProfile(member.profileJson);
    const nextProfile = {
      phone: data.phone !== undefined ? (data.phone ?? "") : stored.phone,
      jobTitle: data.jobTitle !== undefined ? (data.jobTitle ?? "") : stored.jobTitle,
      birthDate: data.birthDate !== undefined ? (data.birthDate ?? "") : stored.birthDate,
      gender: data.gender !== undefined ? (data.gender ?? "") : stored.gender,
      avatarUrl: data.avatarUrl !== undefined ? (data.avatarUrl ?? "") : stored.avatarUrl,
      nameAlt: data.nameAlt !== undefined ? (data.nameAlt ?? "") : stored.nameAlt,
      jobTitleAlt: data.jobTitleAlt !== undefined ? (data.jobTitleAlt ?? "") : stored.jobTitleAlt,
    };

    const updated = await db.teamMember.update({
      where: { id: member.id },
      data: {
        ...(data.name !== undefined ? { name: data.name } : {}),
        ...(data.email !== undefined ? { email: encryptField(data.email) ?? "" } : {}),
        ...(data.role !== undefined ? { role: data.role } : {}),
        profileJson: encryptProfileJson(nextProfile),
      },
    });

    await logAudit({
      actorType: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: auditActorName(guard.principal.actorName),
      action: "instance.memberUpdate",
      targetLabel: updated.name,
    });
    return NextResponse.json(toMemberDTO(updated));
  } catch (error) {
    console.error(`PATCH /api/instances/${id}/members failed:`, error);
    return NextResponse.json({ error: "Failed to update member" }, { status: 500 });
  }
}
