import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { trialLockResponse } from "@/lib/server/entitlement";
import { logAudit } from "@/lib/server/audit";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string; memberId: string }> };

/**
 * DELETE /api/instances/[id]/members/[memberId] — remove a team member
 * (must belong to the instance) and log actUserRemoved with their name.
 * Authorized by the workspace session or an admin session.
 */
export async function DELETE(_req: Request, { params }: RouteContext) {
  const { id, memberId } = await params;
  // Belt-and-braces: an undefined param key must never reach the scoped
  // lookup (Prisma drops undefined filters — the row id becomes unchecked).
  if (!memberId || typeof memberId !== "string") {
    return NextResponse.json({ error: "Member id is required" }, { status: 400 });
  }
  const guard = await requireInstanceAccess(id, _req, { permission: "team.manage" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const trialLock = await trialLockResponse(id);
  if (trialLock) return trialLock;

  try {
    // Scoped lookup: a member id from another instance must not match.
    const member = await db.teamMember.findFirst({
      where: { id: memberId, instanceId: id, deletedAt: null },
    });
    if (!member) {
      return NextResponse.json({ error: "Member not found" }, { status: 404 });
    }

    /* ROUND 87 (trash) — soft delete: the member moves to the workspace
       trash (restorable for the retention window) and leaves the team list
       on the spot. */
    const { softDelete } = await import("@/lib/server/trash");
    const result = await softDelete("teamMember", member.id, {
      kind: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: guard.principal.actorName,
    }, { instanceScope: id });
    if (!result.ok) {
      return NextResponse.json({ error: "Failed to remove member" }, { status: result.status });
    }
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error(`DELETE /api/instances/${id}/members/${memberId} failed:`, error);
    return NextResponse.json({ error: "Failed to remove member" }, { status: 500 });
  }
}
