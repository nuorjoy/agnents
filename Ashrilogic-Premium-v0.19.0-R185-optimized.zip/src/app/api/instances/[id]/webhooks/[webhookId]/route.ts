import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { featureGateResponse } from "@/lib/server/entitlement";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { assertSafeWebhookUrl, isWebhookEvent, newWebhookSecret, openWebhookSecret, sealWebhookSecret } from "@/lib/server/webhooks";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string; webhookId: string }> };

/**
 * ROUND 113 — one webhook endpoint's management surface.
 *
 * PATCH  — partial update (url / events / label / active) and secret
 *          ROTATION (`rotate: true` → a fresh secret is minted; the new
 *          secret is returned in THIS response only). Rotating is the
 *          documented response to a suspected leak.
 * DELETE — soft delete (house trash convention): dispatching to the
 *          endpoint stops immediately; the row stays restorable with its
 *          secret intact.
 *
 * The tenant scope is enforced on every read/write: the row must belong
 * to THIS workspace or the route answers 404 (never a cross-tenant leak).
 */

const WEBHOOK_WRITE_RULE = { limit: 20, windowMs: 10 * 60 * 1000 };

const EMAIL_SHAPE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function auditActorName(name: string): string {
  return EMAIL_SHAPE.test(name) ? maskEmail(name) : name;
}

const patchSchema = z
  .object({
    url: z.string().trim().min(8).max(2048).optional(),
    events: z.array(z.string()).min(1).max(3).optional(),
    description: z.string().trim().max(120).nullable().optional(),
    active: z.boolean().optional(),
    rotate: z.boolean().optional(),
  })
  .refine((v) => Object.values(v).some((x) => x !== undefined), {
    message: "Nothing to update",
  });

export async function PATCH(req: Request, { params }: RouteContext) {
  const { id, webhookId } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "orders.manage" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 141 (strict enforcement) — the server-side store gate (the
   * dashboard view's FeatureGate mirrored at the API seam). */
  const gate = await featureGateResponse(id, "store");
  if (gate) return gate;

  if (await rateLimited(`webhook-write:${id}:${clientIp(req)}`, WEBHOOK_WRITE_RULE)) {
    return tooManyRequests(WEBHOOK_WRITE_RULE, { error: "Too many changes — try again shortly", code: "RATE" });
  }

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = patchSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid webhook update payload" }, { status: 400 });
  }

  try {
    const row = await db.webhookEndpoint.findFirst({
      where: { id: webhookId, instanceId: id },
    });
    if (!row || row.deletedAt != null) {
      return NextResponse.json({ error: "Webhook not found" }, { status: 404 });
    }

    if (parsed.data.url != null && parsed.data.url !== row.url) {
      const verdict = assertSafeWebhookUrl(parsed.data.url);
      if (!verdict.ok) {
        return NextResponse.json(
          { error: "Only public https destinations are allowed", code: "URL" },
          { status: 400 }
        );
      }
      parsed.data.url = verdict.url;
    }

    let events: string[] | undefined;
    if (parsed.data.events != null) {
      const unique = [...new Set(parsed.data.events)];
      if (unique.some((e) => !isWebhookEvent(e)) || unique.length === 0) {
        return NextResponse.json({ error: "Unknown event type" }, { status: 400 });
      }
      events = unique;
    }

    const rotate = parsed.data.rotate === true;
    /* ROUND 162 — the fresh secret is minted HERE so the response can
     * return the plaintext while the row stores only the sealed form. */
    const rotatedSecret = rotate ? newWebhookSecret() : null;
    const updated = await db.webhookEndpoint.update({
      where: { id: row.id },
      data: {
        ...(parsed.data.url != null ? { url: parsed.data.url } : {}),
        ...(events != null ? { eventsJson: JSON.stringify(events) } : {}),
        ...(parsed.data.description !== undefined
          ? { description: parsed.data.description }
          : {}),
        ...(parsed.data.active != null ? { active: parsed.data.active } : {}),
        ...(rotatedSecret != null ? { secret: sealWebhookSecret(rotatedSecret) } : {}),
      },
    });

    await logAudit({
      actorType: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: auditActorName(guard.principal.actorName),
      action: rotate ? "instance.webhookRotate" : "instance.webhookUpdate",
      targetLabel: row.url,
    });

    return NextResponse.json(
      {
        id: updated.id,
        url: updated.url,
        events: JSON.parse(updated.eventsJson) as string[],
        active: updated.active,
        description: updated.description,
        secretHint: (rotatedSecret ?? openWebhookSecret(updated.secret)).slice(-4),
        updatedAt: updated.updatedAt.toISOString(),
        /* the ONE response that ever carries the (new) secret */
        ...(rotatedSecret != null ? { secret: rotatedSecret } : {}),
      },
      { status: 200, headers: { "Cache-Control": "no-store" } }
    );
  } catch (error) {
    console.error(`PATCH /api/instances/${id}/webhooks/${webhookId} failed:`, error);
    return NextResponse.json({ error: "Failed to update the webhook" }, { status: 500 });
  }
}

export async function DELETE(req: Request, { params }: RouteContext) {
  const { id, webhookId } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "orders.manage" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 141 (strict enforcement) — same store gate as PATCH. */
  const gate = await featureGateResponse(id, "store");
  if (gate) return gate;

  try {
    /* scope-guarded soft delete: tenant mismatch answers 404 */
    const applied = await db.webhookEndpoint.updateMany({
      where: { id: webhookId, instanceId: id, deletedAt: null },
      data: { deletedAt: new Date(), active: false },
    });
    if (applied.count !== 1) {
      return NextResponse.json({ error: "Webhook not found" }, { status: 404 });
    }

    await logAudit({
      actorType: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: auditActorName(guard.principal.actorName),
      action: "instance.webhookDelete",
      targetLabel: webhookId,
    });

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error(`DELETE /api/instances/${id}/webhooks/${webhookId} failed:`, error);
    return NextResponse.json({ error: "Failed to delete the webhook" }, { status: 500 });
  }
}
