import { NextResponse } from "next/server";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { redeliverWebhookDelivery } from "@/lib/server/webhooks";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string; webhookId: string; deliveryId: string }> };

/**
 * ROUND 116 — POST /api/instances/[id]/webhooks/[webhookId]/deliveries/[deliveryId]/redeliver
 *
 * Manually re-enqueue one FAILED or EXHAUSTED delivery (R115's
 * recommendation): a NEW pending delivery row is created with the event +
 * payload copied VERBATIM (byte-identical canonical JSON — the receiver's
 * HMAC verification is unchanged) and dispatched immediately, signed with
 * the endpoint's CURRENT secret (rotate-after-leak + redeliver is the
 * documented recovery flow). Receivers stay idempotent per the at-least-once
 * contract — they must key on (order id, event).
 *
 * Eligibility (enforced in redeliverWebhookDelivery, tenant-scoped TWICE):
 *   failed | exhausted rows on an ACTIVE, non-deleted endpoint; at most one
 *   LIVE redelivery per original; the endpoint's pending backlog stays
 *   bounded. Pending/succeeded rows answer 409 (already in flight / already
 *   delivered) — forcing duplicates is receiver spam, not debugging.
 *
 * Security: requireInstanceAccess (orders.manage, origin-guarded per the
 * mutation-coverage gate) + a dedicated actor throttle + the sealed
 * instance.webhookRedeliver audit action.
 */

/* tighter than the endpoint-edit rule — a redelivery is an exceptional
 * operational action, not routine config churn */
const REDELIVER_RULE = { limit: 10, windowMs: 10 * 60 * 1000 };

const EMAIL_SHAPE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function auditActorName(name: string): string {
  return EMAIL_SHAPE.test(name) ? maskEmail(name) : name;
}

const STATUS_BY_REASON: Record<string, number> = {
  "endpoint-not-found": 404,
  "delivery-not-found": 404,
  /* state conflicts — the resource exists, the action does not apply */
  "endpoint-deleted": 409,
  "endpoint-paused": 409,
  "not-redeliverable": 409,
  "redelivery-in-flight": 409,
  "queue-busy": 409,
};

export async function POST(req: Request, { params }: RouteContext) {
  const { id, webhookId, deliveryId } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "orders.manage" });
  if (guard instanceof NextResponse) return guard;

  if (await rateLimited(`webhook-redeliver:${id}:${clientIp(req)}`, REDELIVER_RULE)) {
    return tooManyRequests(REDELIVER_RULE, {
      error: "Too many redeliveries — try again shortly",
      code: "RATE",
    });
  }

  try {
    const verdict = await redeliverWebhookDelivery(id, webhookId, deliveryId);
    if (!verdict.ok) {
      const status = STATUS_BY_REASON[verdict.reason] ?? 409;
      return NextResponse.json(
        { error: `Redelivery refused (${verdict.reason})`, code: verdict.reason },
        { status, headers: { "Cache-Control": "no-store" } }
      );
    }

    await logAudit({
      actorType: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: auditActorName(guard.principal.actorName),
      action: "instance.webhookRedeliver",
      targetLabel: deliveryId,
    });

    return NextResponse.json(verdict.delivery, {
      status: 200,
      headers: { "Cache-Control": "no-store" },
    });
  } catch (error) {
    console.error(
      `POST /api/instances/${id}/webhooks/${webhookId}/deliveries/${deliveryId}/redeliver failed:`,
      error
    );
    return NextResponse.json({ error: "Failed to redeliver the delivery" }, { status: 500 });
  }
}
