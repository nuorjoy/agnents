import { NextResponse } from "next/server";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { listEndpointDeliveries } from "@/lib/server/webhooks";
import { clampLimit, decodeKeyset } from "@/lib/server/keyset";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string; webhookId: string }> };

/**
 * ROUND 115 — GET /api/instances/[id]/webhooks/[webhookId]/deliveries
 *
 * One endpoint's DELIVERY HISTORY (keyset-paginated, newest first) —
 * the drill-down behind the R114 webhooks console's history button:
 * event, status, attempts, response status, sanitized error class, the
 * retry backoff's next-attempt time and the EXACT canonical payload the
 * receiver was handed (the signature covers precisely these bytes).
 *
 * Contract: `{ deliveries, nextCursor }` — nextCursor is null exactly
 * when the history is exhausted (the platform-wide opaque-cursor
 * contract of /activities and /orders). A supplied-but-malformed cursor
 * answers 400 (loud, never a silent page-1 loop).
 *
 * Security: the requireInstanceAccess guard (origin/maintenance/session/
 * permission chain, orders.manage) + double tenant scoping inside
 * listEndpointDeliveries (a foreign endpointId → 404, never a leak).
 * Soft-deleted endpoints stay readable — history is audit material.
 */

const DEFAULT_LIMIT = 10;
const MAX_LIMIT = 50;

export async function GET(req: Request, { params }: RouteContext) {
  const { id, webhookId } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "orders.manage" });
  if (guard instanceof NextResponse) return guard;

  try {
    const url = new URL(req.url);
    const limit = clampLimit(url.searchParams.get("limit"), DEFAULT_LIMIT, MAX_LIMIT);
    const cursorRaw = url.searchParams.get("cursor");
    const cursor = cursorRaw ? decodeKeyset(cursorRaw) : null;
    /* a supplied-but-malformed cursor is a client bug, not a fresh page */
    if (cursorRaw && !cursor) {
      return NextResponse.json(
        { error: "Invalid pagination cursor", code: "BAD_CURSOR" },
        { status: 400 }
      );
    }

    const page = await listEndpointDeliveries(id, webhookId, { limit, cursor });
    if (!page) {
      return NextResponse.json({ error: "Webhook not found" }, { status: 404 });
    }
    return NextResponse.json(page, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error(`GET /api/instances/${id}/webhooks/${webhookId}/deliveries failed:`, error);
    return NextResponse.json({ error: "Failed to load delivery history" }, { status: 500 });
  }
}
