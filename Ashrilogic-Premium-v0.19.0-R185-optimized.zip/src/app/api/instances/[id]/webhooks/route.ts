import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { featureGateResponse } from "@/lib/server/entitlement";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import {
  WEBHOOK_EVENTS,
  assertSafeWebhookUrl,
  isWebhookEvent,
  newWebhookSecret,
  openWebhookSecret,
  parseEndpointEvents,
  sealWebhookSecret,
} from "@/lib/server/webhooks";
import type { WebhookEndpoint } from "@prisma/client";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * ROUND 113 — order-event webhook endpoints (owner integration surface).
 *
 * GET  — list the workspace's endpoints (delivery stats joined in).
 *        The SIGNING SECRET IS NEVER RETURNED after creation (Stripe
 *        convention): the DTO exposes only a hint of its last 4 hex chars
 *        so an operator can correlate a rotation without re-learning the
 *        secret itself.
 * POST — register a destination (url + events + label). The signing
 *        secret is generated server-side and returned EXACTLY ONCE in
 *        the 201 response.
 *
 * Security: the requireInstanceAccess guard (origin/maintenance/session/
 * permission chain) with the `orders.manage` permission — webhook config
 * is store-integration material. Mutations are throttled per tenant×IP.
 */

const WEBHOOK_WRITE_RULE = { limit: 20, windowMs: 10 * 60 * 1000 };
const WEBHOOK_LIST_CAP = 50;

const EMAIL_SHAPE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function auditActorName(name: string): string {
  return EMAIL_SHAPE.test(name) ? maskEmail(name) : name;
}

/** list DTO — secret REDACTED (creation/rotation responses are the only
 *  places the full secret ever appears); the hint reflects the PLAINTEXT
 *  secret's last 4 chars (sealed rows are opened first — ROUND 162). */
export function toWebhookDTO(
  row: WebhookEndpoint,
  stats?: { deliveries: number; lastDeliveryAt: string | null }
) {
  return {
    id: row.id,
    url: row.url,
    events: parseEndpointEvents(row.eventsJson),
    active: row.active,
    description: row.description,
    secretHint: openWebhookSecret(row.secret).slice(-4),
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
    deleted: row.deletedAt != null,
    ...(stats ? { deliveries: stats.deliveries, lastDeliveryAt: stats.lastDeliveryAt } : {}),
  };
}

const createSchema = z.object({
  url: z.string().trim().min(8).max(2048),
  events: z.array(z.string()).min(1).max(WEBHOOK_EVENTS.length),
  description: z.string().trim().max(120).optional(),
});

export async function GET(_req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, undefined, { permission: "orders.manage" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 141 (strict enforcement) — the API mirrors the dashboard view's
   * FeatureGate: webhooks are STORE-integration material; a trial-locked
   * or store-less workspace is refused server-side, not just visually. */
  const gate = await featureGateResponse(id, "store");
  if (gate) return gate;

  try {
    const rows = await db.webhookEndpoint.findMany({
      where: { instanceId: id },
      orderBy: { createdAt: "desc" },
      take: WEBHOOK_LIST_CAP,
    });
    /* delivery stats per endpoint (bounded: ≤50 endpoints × one grouped
     * query — no per-row N+1) */
    const stats = await db.webhookDelivery.groupBy({
      by: ["endpointId"],
      where: { instanceId: id },
      _count: { _all: true },
      _max: { createdAt: true },
    });
    const statById = new Map(stats.map((s) => [s.endpointId, s]));
    return NextResponse.json(
      rows.map((r) => {
        const s = statById.get(r.id);
        return toWebhookDTO(r, {
          deliveries: s?._count._all ?? 0,
          lastDeliveryAt: s?._max.createdAt?.toISOString() ?? null,
        });
      })
    );
  } catch (error) {
    console.error(`GET /api/instances/${id}/webhooks failed:`, error);
    return NextResponse.json({ error: "Failed to load webhooks" }, { status: 500 });
  }
}

export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "orders.manage" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 141 (strict enforcement) — same server-side store gate as GET. */
  const gate = await featureGateResponse(id, "store");
  if (gate) return gate;

  if (await rateLimited(`webhook-write:${id}:${clientIp(req)}`, WEBHOOK_WRITE_RULE)) {
    return tooManyRequests(WEBHOOK_WRITE_RULE, { error: "Too many changes — try again shortly", code: "RATE" });
  }

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = createSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "A webhook needs an https URL, 1–3 event types and an optional label" },
      { status: 400 }
    );
  }

  /* SSRF guard BEFORE the row lands (re-validated at dispatch time) */
  const urlVerdict = assertSafeWebhookUrl(parsed.data.url);
  if (!urlVerdict.ok) {
    const reason =
      urlVerdict.reason === "scheme"
        ? "Only https destinations are allowed (http is limited to localhost)"
        : urlVerdict.reason === "private-host"
          ? "The destination host is not reachable from the public internet"
          : urlVerdict.reason === "userinfo"
            ? "Credentials in the URL are not supported"
            : urlVerdict.reason === "port"
              ? "Only port 443 is allowed for https destinations (add WEBHOOK_ALLOWED_HTTPS_PORTS for other ports)"
              : "That does not look like a valid URL";
    return NextResponse.json({ error: reason, code: "URL" }, { status: 400 });
  }

  /* event set validation — unknown types are refused, not dropped */
  const events = [...new Set(parsed.data.events)];
  if (events.some((e) => !isWebhookEvent(e)) || events.length === 0) {
    return NextResponse.json(
      { error: `Events must be one of: ${WEBHOOK_EVENTS.join(", ")}` },
      { status: 400 }
    );
  }

  try {
    /* hard ceiling per workspace — fan-out cost is linear in endpoints */
    const existing = await db.webhookEndpoint.count({
      where: { instanceId: id, deletedAt: null },
    });
    if (existing >= 10) {
      return NextResponse.json(
        { error: "A workspace can register at most 10 webhook endpoints", code: "CAP" },
        { status: 400 }
      );
    }

    const secret = newWebhookSecret();
    const row = await db.webhookEndpoint.create({
      data: {
        instanceId: id,
        url: urlVerdict.url,
        /* ROUND 162 — sealed at rest; the plaintext is returned in THIS
         * response only and never persists unsealed. */
        secret: sealWebhookSecret(secret),
        eventsJson: JSON.stringify(events),
        active: true,
        description: parsed.data.description ?? null,
      },
    });

    await logAudit({
      actorType: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: auditActorName(guard.principal.actorName),
      action: "instance.webhookCreate",
      targetLabel: urlVerdict.url,
    });

    /* the ONE response that ever carries the full secret */
    return NextResponse.json(
      { ...toWebhookDTO(row), secret },
      { status: 201, headers: { "Cache-Control": "no-store" } }
    );
  } catch (error) {
    console.error(`POST /api/instances/${id}/webhooks failed:`, error);
    return NextResponse.json({ error: "Failed to create the webhook" }, { status: 500 });
  }
}
