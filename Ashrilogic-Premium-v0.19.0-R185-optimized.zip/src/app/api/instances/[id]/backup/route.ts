import { NextResponse } from "next/server";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { featureGateResponse } from "@/lib/server/entitlement";
import {rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { buildInstanceBackupCached } from "@/lib/server/backup-cache";
import { BackupTooLargeError } from "@/lib/server/backup";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/** Backup downloads are full-tenant reads — 6 per hour per instance. */
const BACKUP_RULE = { windowMs: 3_600_000, limit: 6 };

/** Email-shaped values are PII — mask them for the audit trail; plain admin
 *  handles ("sarah.super") pass through so the trail stays correlatable. */
const EMAIL_SHAPE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function auditActorName(name: string): string {
  return EMAIL_SHAPE.test(name) ? maskEmail(name) : name;
}

/** UTC filename stamp: YYYYMMDD-HHmm. */
function fileStamp(now: Date): string {
  const p2 = (n: number) => String(n).padStart(2, "0");
  return `${now.getUTCFullYear()}${p2(now.getUTCMonth() + 1)}${p2(now.getUTCDate())}-${p2(now.getUTCHours())}${p2(now.getUTCMinutes())}`;
}

/**
 * GET /api/instances/[id]/backup — download a complete, integrity-sealed
 * JSON snapshot of THIS workspace (round 41). Authorized by the workspace
 * session (origin-guarded) or a managing admin session. The response is an
 * attachment; the audit trail records the record count + digest prefix so
 * every downloaded backup is provable.
 *
 * The build goes through the snapshot cache (backup-cache.ts): a freshness
 * fingerprint proves a cached envelope still matches the tenant's data
 * before it is served, and concurrent downloads coalesce onto ONE build.
 * Same sync GET contract, same envelope bytes; ASHRILOGIC_BACKUP_CACHE_DISABLE
 * restores the exact pre-cache behavior.
 */
export async function GET(req: Request, { params }: RouteContext) {
  const { id } = await params;

  const guard = await requireInstanceAccess(id, req, { permission: "settings.manage" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const featureLock = await featureGateResponse(id, "backup");
  if (featureLock) return featureLock;

  if (await rateLimited(`inst-backup:${id}`, BACKUP_RULE)) {
    return tooManyRequests(BACKUP_RULE, { error: "Too many backup downloads — please wait a moment before trying again" });
  }

  try {
    /* Snapshot cache (the sustained-load backlog item): a freshness
     * fingerprint verifies the cached envelope still matches the tenant's
     * data before serving it, and concurrent requests coalesce onto one
     * build — the API contract (sync GET, same envelope bytes) is unchanged.
     * The per-request rate-limit accounting above still runs FIRST, so a
     * cache hit consumes the same quota as a fresh download. */
    const result = await buildInstanceBackupCached(id, { enforceSizeCeiling: true });
    if (!result) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }
    const { envelope } = result;

    await logAudit({
      actorType: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: auditActorName(guard.principal.actorName),
      action: "instance.backup",
      targetLabel: envelope.meta.orgName || envelope.meta.systemId,
      meta: {
        records: String(envelope.meta.totalRecords),
        checksum: envelope.meta.checksum.slice(0, 16),
        /* cache: hit = fingerprint-verified cached snapshot, miss = fresh
         * build, join = coalesced onto an in-flight build; ms = wall time */
        cache: result.cache,
        ms: String(result.elapsedMs),
      },
    });

    const filename = `ashrilogic-backup-${envelope.meta.systemId}-${fileStamp(new Date())}.json`;

    /* the serialized body was cached at build time (byte-identical to a
       fresh JSON.stringify) — a cache hit skips the full-tenant read AND
       the re-serialization. The X-Backup-* headers are operational
       observability (non-visual; downloads never render them). */
    return new NextResponse(result.serialized, {
      status: 200,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Content-Disposition": `attachment; filename="${filename}"`,
        "Cache-Control": "no-store",
        "X-Backup-Cache": result.cache,
        "X-Backup-Built-At": new Date(result.builtAt).toISOString(),
      },
    });
  } catch (error) {
    /* the envelope (with embedded image bytes) exceeds what the restore
       upload path could ever accept — fail the BUILD loudly with actionable
       guidance instead of handing the tenant a file they cannot restore */
    if (error instanceof BackupTooLargeError) {
      return NextResponse.json(
        {
          error:
            "Backup exceeds the portable file size limit — remove unused product photos and try again, or contact support for a platform-level backup",
          code: "BACKUP_TOO_LARGE",
        },
        { status: 413 }
      );
    }
    console.error(`GET /api/instances/${id}/backup failed:`, error);
    return NextResponse.json({ error: "Failed to build backup" }, { status: 500 });
  }
}
