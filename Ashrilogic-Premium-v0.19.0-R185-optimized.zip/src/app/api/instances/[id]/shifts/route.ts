import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireInstanceAccess, assertInstancePermission } from "@/lib/server/instance-session";
import { trialLockResponse } from "@/lib/server/entitlement";
import { rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { readJson } from "@/lib/server/http";
import { zodError } from "@/lib/server/instance-mapper";
import { verifyPasswordArgon2id } from "@/lib/server/crypto-vault";
import { logAudit, maskEmail } from "@/lib/server/audit";
import {
  getOpenShift,
  instanceShiftsEnabled,
  nextShiftCode,
  toShiftDTO,
  computeShiftAggregates,
  shiftMinorUnits,
} from "@/lib/server/shift-gate";
import type { ShiftsResponseDTO } from "@/lib/types";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/** KDF-backed attempts: a wrong shift-code flood must not burn Argon2 CPU. */
const SHIFT_CODE_RULE = { limit: 10, windowMs: 10 * 60 * 1000 };
/** ROUND 145 — the SHARED fail-closed PIN budget: 6 wrong PINs / 10 min per
 *  workspace. The SAME secret (shiftCodeHash) arms the wallet transfers,
 *  and their controller burns the SAME `pin-fail:${id}` key — one secret,
 *  ONE budget (previously this route's failures counted only against the
 *  fail-open shift-open action throttle, leaving a second independent
 *  guessing budget ≈ 2.3k guesses/day across both surfaces). */
const PIN_FAIL_RULE = { limit: 6, windowMs: 10 * 60 * 1000 };

const openShiftSchema = z.object({
  /** the owner's PERSONAL secret shift code (Argon2id-verified) */
  code: z.string().min(1).max(64),
  /** declared opening float (display units, ≥ 0) */
  openingCash: z.number().min(0).max(10_000_000).default(0),
});

/** ROUND 134 — the الورديات module-disabled refusal shared by every
 * mutating shift endpoint (open/close/code): the shift SYSTEM itself is
 * toggled off on this workspace — there is nothing to operate. */
function shiftsModuleDisabledResponse(): NextResponse {
  return NextResponse.json(
    {
      error: "The shifts module is disabled on this workspace — enable الورديات in the modules control first",
      code: "SHIFTS_MODULE_DISABLED",
    },
    { status: 403 }
  );
}

/**
 * GET /api/instances/[id]/shifts — the workspace's shift state: the open
 * shift (with LIVE aggregates recomputed from the POS records born inside
 * its window), the last 20 closed shifts, and whether the secret shift code
 * has been defined. Read-only: NO shift gate (the UI needs this to know the
 * state in the first place). ROUND 134: with the الورديات module disabled
 * the payload carries the moduleDisabled marker and no state — every
 * client gate stands down on exactly the same condition the server's own
 * gate is suspended by.
 */
export async function GET(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "modules.view" });
  if (guard instanceof NextResponse) return guard;

  const trialLock = await trialLockResponse(id);
  if (trialLock) return trialLock;

  try {
    if (!(await instanceShiftsEnabled(id))) {
      const payload: ShiftsResponseDTO = {
        current: null,
        history: [],
        codeSet: false,
        codeLen: null,
        moduleDisabled: true,
      };
      return NextResponse.json(payload);
    }

    const [instance, open, history] = await Promise.all([
      db.instance.findUnique({ where: { id }, select: { shiftCodeHash: true, shiftCodeLen: true } }),
      getOpenShift(id),
      db.shift.findMany({
        where: { instanceId: id, status: "closed" },
        orderBy: { closedAt: "desc" },
        take: 20,
      }),
    ]);

    const payload: ShiftsResponseDTO = {
      current: open ? toShiftDTO(open, await computeShiftAggregates(open)) : null,
      history: history.map((row) => toShiftDTO(row)),
      codeSet: Boolean(instance?.shiftCodeHash),
      /* ROUND 144 (advanced PIN) — the persisted length so the PIN entry
       * surfaces render exactly the owner's chosen number of cells. */
      codeLen: instance?.shiftCodeLen ?? null,
    };
    return NextResponse.json(payload);
  } catch (error) {
    console.error(`GET /api/instances/${id}/shifts failed:`, error);
    return NextResponse.json({ error: "Failed to load shift state" }, { status: 500 });
  }
}

/**
 * POST /api/instances/[id]/shifts — OPEN a shift. The owner's directive:
 * «لفتح الوردية يجب إدخال الكود السري الخاص بك بدقة» — the PERSONAL SECRET
 * SHIFT CODE must be presented and Argon2id-verified. Refused with 428 when
 * no code has been defined yet, 401 on a wrong code, 409 when a shift is
 * already open. Audit-logged.
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, req);
  if (guard instanceof NextResponse) return guard;

  const trialLock = await trialLockResponse(id);
  if (trialLock) return trialLock;

  /* ROUND 134 — the module toggle is the law's switch: disabled → the
   * whole shift surface refuses (nothing can be opened while off). */
  if (!(await instanceShiftsEnabled(id))) return shiftsModuleDisabledResponse();

  const permCheck = await assertInstancePermission(guard.principal, "modules.edit");
  if (permCheck) return permCheck;

  if (await rateLimited(`shift-open:${id}`, SHIFT_CODE_RULE)) {
    return tooManyRequests(SHIFT_CODE_RULE, { error: "Too many shift-open attempts — try again shortly" });
  }

  const body = await readJson(req, 8_000);
  if (!body.ok) return body.response;

  const parsed = openShiftSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) || "code is required" }, { status: 422 });
  }

  try {
    const instance = await db.instance.findUnique({
      where: { id },
      select: { shiftCodeHash: true },
    });
    if (!instance) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }
    if (!instance.shiftCodeHash) {
      return NextResponse.json(
        {
          error: "The secret shift code has not been defined yet — set it first",
          code: "SHIFT_CODE_NOT_SET",
        },
        { status: 428 }
      );
    }
    if (!verifyPasswordArgon2id(parsed.data.code, instance.shiftCodeHash)) {
      /* ROUND 145 — the SHARED fail-closed PIN budget (mirrors the wallet
       * transfer controller's exact declaration: same `pin-fail:${id}` key,
       * same 6/10min rule, same failClosed posture, same 429 envelope). */
      if (await rateLimited(`pin-fail:${id}`, PIN_FAIL_RULE, { failClosed: true })) {
        return tooManyRequests(PIN_FAIL_RULE, {
          error: "Too many incorrect PIN attempts — try again later",
          code: "RATE_LIMITED",
        });
      }
      await logAudit({
        actorType: guard.principal.kind === "admin" ? "admin" : "instance",
        actorId: guard.principal.actorId,
        actorName: maskEmail(guard.principal.actorName),
        action: "instance.shiftOpen",
        targetLabel: "FAILED (wrong code)",
        meta: { result: "denied" },
      });
      return NextResponse.json(
        { error: "The secret shift code is incorrect", code: "SHIFT_CODE_INVALID" },
        { status: 401 }
      );
    }

    /* one open shift per workspace — re-checked after the auth proof */
    const existing = await getOpenShift(id);
    if (existing) {
      return NextResponse.json(
        { error: "A shift is already open on this workspace", code: "SHIFT_ALREADY_OPEN", shiftCode: existing.code },
        { status: 409 }
      );
    }

    const row = await db.shift.create({
      data: {
        instanceId: id,
        code: await nextShiftCode(id),
        openedBy: guard.principal.actorName,
        openedById: guard.principal.sessionJti ?? null,
        openingCash: shiftMinorUnits(parsed.data.openingCash),
        status: "open",
      },
    });

    await logAudit({
      actorType: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: maskEmail(guard.principal.actorName),
      action: "instance.shiftOpen",
      targetLabel: row.code,
      meta: { openingCash: String(row.openingCash) },
    });

    return NextResponse.json({ shift: toShiftDTO(row, await computeShiftAggregates(row)) }, { status: 201 });
  } catch (error) {
    console.error(`POST /api/instances/${id}/shifts failed:`, error);
    return NextResponse.json({ error: "Failed to open shift" }, { status: 500 });
  }
}
