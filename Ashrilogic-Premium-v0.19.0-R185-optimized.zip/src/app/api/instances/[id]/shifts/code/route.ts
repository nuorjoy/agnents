import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireInstanceAccess, assertInstancePermission, checkInstancePassword } from "@/lib/server/instance-session";
import { rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { readJson } from "@/lib/server/http";
import { zodError } from "@/lib/server/instance-mapper";
import { hashPasswordArgon2id } from "@/lib/server/crypto-vault";
import { logAudit, maskEmail } from "@/lib/server/audit";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/** KDF-backed: a wrong-password flood must not burn Argon2 CPU. */
const CODE_SET_RULE = { limit: 8, windowMs: 10 * 60 * 1000 };

const codeSchema = z.object({
  /** identity proof: the WORKSPACE password (Argon2id-verified) */
  currentPassword: z.string().min(1).max(128),
  /** the new secret shift code: 4-8 digits, numeric only */
  newCode: z
    .string()
    .trim()
    .regex(/^\d{4,8}$/, "The shift code must be 4-8 digits"),
  /** ROUND 144 (advanced PIN) — the CHOSEN length (4..8). Optional for
   *  backward compatibility: absent → the code's own length wins. */
  length: z.number().int().min(4).max(8).optional(),
});

/**
 * PUT /api/instances/[id]/shifts/code — define or change the owner's PERSONAL
 * SECRET SHIFT CODE (Argon2id-hashed, distinct from the login password).
 * Requires the WORKSPACE PASSWORD as identity proof (the shift code is a
 * business-critical secret: whoever can prove the account password is the
 * owner). The open/close endpoints verify this code; the first definition
 * unblocks the whole shift system (428 SHIFT_CODE_NOT_SET before that).
 */
export async function PUT(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, req);
  if (guard instanceof NextResponse) return guard;

  /* ROUND 144 (advanced PIN) — the secret PIN is the owner's PERSONAL
   * confirmation code for BOTH the shift system AND inter-wallet
   * transfers, so its definition surface stays available even when the
   * الورديات module itself is toggled off (only the shift OPEN/CLOSE law
   * stands down with the module — the PIN remains the transfer proof).
   * The open/close endpoints below still refuse while the module is off. */

  const permCheck = await assertInstancePermission(guard.principal, "modules.edit");
  if (permCheck) return permCheck;

  if (await rateLimited(`shift-code:${id}`, CODE_SET_RULE)) {
    return tooManyRequests(CODE_SET_RULE, { error: "Too many attempts — try again shortly" });
  }

  const body = await readJson(req, 8_000);
  if (!body.ok) return body.response;

  const parsed = codeSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json(
      { error: zodError(parsed.error) || "currentPassword and newCode are required" },
      { status: 400 }
    );
  }

  try {
    const instance = await db.instance.findUnique({
      where: { id },
      select: { passwordHash: true },
    });
    if (!instance) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }

    const check = checkInstancePassword(parsed.data.currentPassword, instance.passwordHash);
    if (!check.ok) {
      return NextResponse.json(
        { error: "The workspace password is incorrect", code: "PASSWORD_INVALID" },
        { status: 401 }
      );
    }

    await db.instance.update({
      where: { id },
      data: {
        shiftCodeHash: hashPasswordArgon2id(parsed.data.newCode),
        /* ROUND 144 (advanced PIN) — persist the code's exact length so
         * every PIN entry surface (shift open/close + wallet transfers)
         * renders EXACTLY that many cells for the owner. */
        shiftCodeLen: parsed.data.length ?? parsed.data.newCode.length,
        /* persist a bootstrapped/upgraded login hash while we are here
         * (checkInstancePassword's contract: the caller persists) */
        ...(check.hash && check.hash !== instance.passwordHash ? { passwordHash: check.hash } : {}),
      },
    });

    await logAudit({
      actorType: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: maskEmail(guard.principal.actorName),
      action: "instance.shiftCode",
      targetLabel: "shift secret code",
      meta: { defined: "1" },
    });

    return NextResponse.json({ ok: true, codeSet: true });
  } catch (error) {
    console.error(`PUT /api/instances/${id}/shifts/code failed:`, error);
    return NextResponse.json({ error: "Failed to set the shift code" }, { status: 500 });
  }
}
