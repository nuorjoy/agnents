import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireInstanceAccess, assertInstancePermission } from "@/lib/server/instance-session";
import { trialLockResponse } from "@/lib/server/entitlement";
import { rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { readJson } from "@/lib/server/http";
import { zodError } from "@/lib/server/instance-mapper";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { getOpenShift, instanceShiftsEnabled, toShiftDTO, computeShiftAggregates, expectedDrawerCash, shiftMinorUnits } from "@/lib/server/shift-gate";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

const CLOSE_RULE = { limit: 15, windowMs: 10 * 60 * 1000 };

const closeShiftSchema = z.object({
  /** the counted cash drawer at close (display units, ≥ 0) */
  countedCash: z.number().min(0).max(10_000_000),
  /** optional closing note (≤ 300 chars) */
  note: z.string().trim().max(300).optional(),
});

/**
 * POST /api/instances/[id]/shifts/close — CLOSE the open shift with the
 * counted drawer. The server computes the expected drawer (declared float +
 * cash sales born inside the window) and the variance (counted − expected;
 * negative = shortage), then FREEZES the live aggregates onto the row.
 * Refused with 409 when no shift is open. Audit-logged.
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, req);
  if (guard instanceof NextResponse) return guard;

  const trialLock = await trialLockResponse(id);
  if (trialLock) return trialLock;

  /* ROUND 134 — الورديات module toggle: disabled → the shift surface
   * refuses (nothing to close while the system is off). */
  if (!(await instanceShiftsEnabled(id))) {
    return NextResponse.json(
      { error: "The shifts module is disabled on this workspace", code: "SHIFTS_MODULE_DISABLED" },
      { status: 403 }
    );
  }

  const permCheck = await assertInstancePermission(guard.principal, "modules.edit");
  if (permCheck) return permCheck;

  if (await rateLimited(`shift-close:${id}`, CLOSE_RULE)) {
    return tooManyRequests(CLOSE_RULE, { error: "Too many shift-close attempts — try again shortly" });
  }

  const body = await readJson(req, 8_000);
  if (!body.ok) return body.response;

  const parsed = closeShiftSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) || "countedCash is required" }, { status: 400 });
  }

  try {
    const open = await getOpenShift(id);
    if (!open) {
      return NextResponse.json(
        { error: "No shift is open on this workspace", code: "NO_OPEN_SHIFT" },
        { status: 409 }
      );
    }

    const live = await computeShiftAggregates(open);
    const expected = expectedDrawerCash(open, live);
    const counted = shiftMinorUnits(parsed.data.countedCash);
    const variance = counted - expected;

    const row = await db.shift.update({
      where: { id: open.id },
      data: {
        status: "closed",
        closedAt: new Date(),
        closedBy: guard.principal.actorName,
        closingNote: parsed.data.note?.trim() || null,
        countedCash: counted,
        expectedCash: expected,
        variance,
        salesCount: live.salesCount,
        salesTotal: live.salesTotal,
        discountTotal: live.discountTotal,
        cashTotal: live.cashTotal,
        cardTotal: live.cardTotal,
      },
    });

    await logAudit({
      actorType: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: maskEmail(guard.principal.actorName),
      action: "instance.shiftClose",
      targetLabel: row.code,
      meta: {
        sales: String(live.salesCount),
        total: String(live.salesTotal),
        variance: String(variance),
      },
    });

    return NextResponse.json({ shift: toShiftDTO(row, live) });
  } catch (error) {
    console.error(`POST /api/instances/${id}/shifts/close failed:`, error);
    return NextResponse.json({ error: "Failed to close shift" }, { status: 500 });
  }
}
