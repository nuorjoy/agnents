import { tenantCancel } from "@/server/domains/addon-orders/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 141 — PATCH /api/instances/[id]/addon-orders/[orderId] — cancel the
 * workspace's own pending add-on purchase request ({ action: "cancel" }).
 * Cross-tenant order ids are 404s, never actionable.
 */
export const PATCH = tenantCancel;
