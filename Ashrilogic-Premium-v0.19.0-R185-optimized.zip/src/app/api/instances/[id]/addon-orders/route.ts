import { tenantCreate, tenantList } from "@/server/domains/addon-orders/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 141 — متجر الإضافات (the Add-ons Store).
 *
 * GET  /api/instances/[id]/addon-orders — the add-on catalog with each
 *      feature's live active state + the workspace's own add-on order
 *      history. Works while TRIAL-LOCKED — this is a billing surface.
 * POST /api/instances/[id]/addon-orders — create an add-on purchase
 *      request. The body carries ONLY { features[], cycle, methodId } —
 *      no amount, no currency, no reference. The server validates every
 *      key against the catalog + the live effective map (already-active
 *      features are refused), recomputes the price from the add-on
 *      catalog, resolves the payment method from the console-managed
 *      dynamic list, stamps a unique reference, seals the order with an
 *      HMAC integrity hash and returns method-specific payment
 *      instructions built server-side. Any previous pending add-on order
 *      is cancelled atomically (one live request at a time).
 */
export const GET = tenantList;
export const POST = tenantCreate;
