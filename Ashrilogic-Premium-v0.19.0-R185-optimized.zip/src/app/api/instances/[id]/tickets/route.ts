import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { toTicketDTO } from "@/lib/server/admin-mapper";
import { zodError, readAdminEmail } from "@/lib/server/instance-mapper";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { blindIndex, encryptField } from "@/lib/server/crypto-vault";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/** Local schema — the client localizes subject/message, the server validates. */
const upgradeRequestSchema = z.object({
  packageId: z.string().min(1).max(64),
  subject: z.string().min(3).max(120),
  message: z.string().min(10).max(2000),
});

/** Upgrade-request throttling: 5 per 10 minutes per IP + instance. */
const TICKET_RULE = { limit: 5, windowMs: 10 * 60 * 1000 };

/** Email-shaped values are PII — mask them for the audit trail; plain admin
 *  handles ("sarah.super") pass through so the trail stays correlatable. */
const EMAIL_SHAPE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function auditActorName(name: string): string {
  return EMAIL_SHAPE.test(name) ? maskEmail(name) : name;
}

/**
 * POST /api/instances/[id]/tickets — file a plan-upgrade request from the
 * subscriber dashboard. Creates an open medium-priority *billing* ticket tied
 * to this instance (source: "instance"), attributed to the instance admin.
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;

  /* ROUND 42 — guard BEFORE the bounded body read (cross-tenant callers
   * can no longer burn the read + zod parse or probe validation). */
  const guard = await requireInstanceAccess(id, req, { permission: "support.manage" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 37 (task 3-c) — bounded body read in place of the unbounded
   * req.json(); parse order preserved. */
  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = upgradeRequestSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const { packageId, subject, message } = parsed.data;

  if (await rateLimited(`inst-ticket:${clientIp(req)}:${id}`, TICKET_RULE)) {
    return tooManyRequests(TICKET_RULE, { error: "Too many requests submitted, please try again later" });
  }

  try {
    /* ROUND 87 — trashed (soft-deleted) workspaces never file tickets
     * (defense in depth: the session guard already rejects them). */
    const instance = await db.instance.findUnique({
      where: { id, deletedAt: null },
      select: { id: true, adminJson: true },
    });
    if (!instance) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }

    const pkg = await db.package.findUnique({
      where: { id: packageId },
      select: { id: true, active: true },
    });
    if (!pkg || !pkg.active) {
      return NextResponse.json({ error: "Unknown or inactive package" }, { status: 404 });
    }

    // Instance admin identity. ROUND 37 (task 3-c): round 35 sealed the login
    // email inside adminJson (enc:v1:… envelope), so the raw JSON.parse below
    // could no longer find an "@" — every sealed workspace silently filed its
    // upgrade tickets under the noreply fallback. The email is now read
    // through the vault: readAdminEmail() decrypts sealed rows and passes
    // legacy plaintext through unchanged (never throws).
    let adminName = "Subscriber";
    let adminEmail = "noreply@ashrilogic.com";
    try {
      const parsedAdmin = JSON.parse(instance.adminJson ?? "{}") as {
        name?: unknown;
      };
      if (typeof parsedAdmin.name === "string" && parsedAdmin.name.length > 0) {
        adminName = parsedAdmin.name.slice(0, 80);
      }
    } catch {
      // keep the defaults when the JSON is unreadable
    }
    const adminEmailPlain = readAdminEmail(instance.adminJson);
    if (adminEmailPlain.includes("@")) {
      adminEmail = adminEmailPlain.slice(0, 120);
    }

    const row = await db.supportTicket.create({
      data: {
        subject,
        message,
        requesterName: adminName,
        /* round 35 — sealed at rest + blind-indexed */
        requesterEmail: encryptField(adminEmail) ?? "",
        requesterEmailIndex: blindIndex(adminEmail) ?? "",
        category: "billing",
        priority: "medium",
        status: "open",
        instanceId: id,
        source: "instance",
      },
    });
    await logAudit({
      actorType: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: auditActorName(guard.principal.actorName),
      action: "instance.upgradeRequest",
      targetLabel: subject.slice(0, 120),
    });
    return NextResponse.json(toTicketDTO(row), { status: 201 });
  } catch (error) {
    console.error(`POST /api/instances/${id}/tickets failed:`, error);
    return NextResponse.json({ error: "Failed to submit request" }, { status: 500 });
  }
}
