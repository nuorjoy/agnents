import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { trialLockResponse } from "@/lib/server/entitlement";
import { toDisplayUnits } from "@/lib/server/money";
import { parseOrderSnapshot, parseStatusHistory } from "@/lib/server/order-snapshot";
import { clampLimit, decodeKeyset, encodeKeyset, keysetPredicate } from "@/lib/server/keyset";
import type { SiteOrderAdminDTO, SiteOrderDTO, SiteOrderItemDTO, SiteOrderStatus } from "@/lib/types";
import type { SiteOrder, SiteCustomer } from "@prisma/client";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

const ORDER_STATUSES = new Set([
  "pending",
  "confirmed",
  "preparing",
  "ready",
  "completed",
  "cancelled",
]);

/** ROUND 50 FIX — v2 snapshot shape (minor-unit prices, the format every
 *  order has used since the money migration) was not parsed here: owner-side
 *  rows rendered with EMPTY item lists and raw minor-unit totals. ROUND 54:
 *  parsing moved to the SHARED order-snapshot lib (single source of truth,
 *  also carrying the placement-time image refs); legacy v1 arrays keep
 *  rendering, totals and discounts convert to display units, and the
 *  tracking/discount fields flow to the dashboard. */
function toOrderDTO(row: SiteOrder): SiteOrderDTO {
  const { items: parsedItems, legacy } = parseOrderSnapshot(row.itemsJson);
  const items: SiteOrderItemDTO[] = parsedItems.map((it) =>
    legacy ? { ...it, image: it.image ?? null } : { ...it, price: toDisplayUnits(it.price), image: it.image ?? null }
  );
  const total = legacy ? row.total : toDisplayUnits(row.total);
  const discount = legacy ? 0 : toDisplayUnits(row.discount);
  return {
    id: row.id,
    code: row.code,
    items,
    total,
    discount,
    couponCode: row.couponCode,
    currency: row.currency,
    status: (ORDER_STATUSES.has(row.status) ? row.status : "pending") as SiteOrderStatus,
    note: row.note,
    statusNote: row.statusNote,
    // ROUND 56 — the lifecycle trail (empty array on legacy/NULL rows)
    statusHistory: parseStatusHistory(row.statusHistoryJson),
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

const DEFAULT_LIMIT = 20;
const MAX_LIMIT = 100;

/**
 * GET /api/instances/[id]/orders?status=&limit=&cursor= — the workspace
 * owner's storefront order queue (round 36), KEYSET-paginated (ROUND 57).
 *
 * Contract: `{ orders, nextCursor, counts }` —
 *  - `status` (optional) filters the PAGE; `counts` are always
 *    instance-wide (they drive the KPI strip + filter chips, so they must
 *    not shrink with the loaded window). ROUND 145 (perf): `counts` ship
 *    ONLY on the first page (no cursor) — they are page-independent, so
 *    cursor pages skip the aggregate scans and omit the field (clients
 *    keep the first page's value);
 *  - `nextCursor` is null exactly when this filter is exhausted; pass it
 *    back verbatim as `?cursor=` for the next page;
 *  - pages are stable under concurrent placements (keyset on the same
 *    `(createdAt, id)` total order the ORDER BY uses).
 *
 * Each row carries the customer's display name (scoped to this instance).
 */
export async function GET(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, undefined, { permission: "orders.manage" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const trialLock = await trialLockResponse(id);
  if (trialLock) return trialLock;

  const url = new URL(req.url);
  const status = (url.searchParams.get("status") ?? "").trim().toLowerCase();
  const statusFilter = status && ORDER_STATUSES.has(status) ? status : null;
  const limit = clampLimit(url.searchParams.get("limit"), DEFAULT_LIMIT, MAX_LIMIT);
  const cursorRaw = url.searchParams.get("cursor");
  const cursor = cursorRaw ? decodeKeyset(cursorRaw) : null;
  /* malformed cursor → loud 400 (never silently re-read page one) */
  if (cursorRaw && !cursor) {
    return NextResponse.json(
      { error: "Invalid pagination cursor", code: "BAD_CURSOR" },
      { status: 400 }
    );
  }

  try {
    const site = await db.site.findUnique({
      where: { instanceId: id },
      select: { instanceId: true },
    });
    if (!site) {
      return NextResponse.json(
        { error: "This workspace has no website yet", code: "SITE_NOT_FOUND" },
        { status: 404 }
      );
    }

    const where = {
      instanceId: id,
      deletedAt: null,
      ...(statusFilter ? { status: statusFilter } : {}),
      ...(cursor ? keysetPredicate(cursor) : {}),
    };

    /* take limit + 1 — the extra row only signals hasMore (never returned) */
    const rows = await db.siteOrder.findMany({
      where,
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: limit + 1,
      include: { customer: { select: { id: true, name: true } } },
    });
    const hasMore = rows.length > limit;
    const page = hasMore ? rows.slice(0, limit) : rows;
    const nextCursor = hasMore && page.length > 0 ? encodeKeyset(page[page.length - 1]) : null;

    const orders: SiteOrderAdminDTO[] = page.map((row) => ({
      ...toOrderDTO(row),
      customerId: row.customer.id,
      customerName: row.customer.name,
    }));

    /* ROUND 145 (perf) — cursor pages skip the instance-wide aggregates:
     * they are page-independent, so recomputing them on every load-more
     * and every notifications/store poll refetch was pure waste. Every
     * client reads the FIRST page's counts (pages[0] / cursorless probes)
     * and keeps it. */
    if (cursor) {
      return NextResponse.json({ orders, nextCursor });
    }

    /* instance-wide aggregates (independent of page + status filter): one
     * groupBy for per-status counts + one aggregate for counted revenue
     * (cancelled orders never count toward sales — the KPI strip's own
     * definition). Cheap indexed scans on instanceId. */
    const byStatusRows = await db.siteOrder.groupBy({
      by: ["status"],
      _count: { _all: true },
      where: { instanceId: id, deletedAt: null },
    });
    const byStatus: Record<string, number> = {};
    let all = 0;
    let open = 0;
    for (const row of byStatusRows) {
      const n = row._count._all;
      byStatus[row.status] = n;
      all += n;
      if (row.status === "confirmed" || row.status === "preparing" || row.status === "ready") {
        open += n;
      }
    }
    const revenueRow = await db.siteOrder.aggregate({
      _sum: { total: true },
      where: { instanceId: id, status: { not: "cancelled" }, deletedAt: null },
    });

    return NextResponse.json({
      orders,
      nextCursor,
      counts: {
        all,
        pending: byStatus["pending"] ?? 0,
        open,
        completed: byStatus["completed"] ?? 0,
        cancelled: byStatus["cancelled"] ?? 0,
        byStatus,
        /** counted revenue (net of cancelled) in DISPLAY units */
        revenue: toDisplayUnits(revenueRow._sum.total ?? 0),
      },
    });
  } catch (error) {
    console.error(`GET /api/instances/${id}/orders failed:`, error);
    return NextResponse.json({ error: "Failed to load orders" }, { status: 500 });
  }
}

/** Type re-export guard (keeps the SiteCustomer import honest for the mapper). */
export type { SiteCustomer };
