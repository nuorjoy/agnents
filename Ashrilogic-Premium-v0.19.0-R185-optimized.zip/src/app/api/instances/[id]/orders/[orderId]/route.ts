import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { trialLockResponse } from "@/lib/server/entitlement";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { toDisplayUnits } from "@/lib/server/money";
import { parseStatusHistory } from "@/lib/server/order-snapshot";
import { decryptField } from "@/lib/server/crypto-vault";
import { sendOrderStatusNotice } from "@/lib/server/mail";
import { issueReceiptToken } from "@/lib/server/receipt-token";
import { enqueueWebhookEvent } from "@/lib/server/webhooks";
import {
  isValidTransition,
  compensateOrderReservations,
  type OrderStatus,
} from "@/lib/server/order-lifecycle";
import { shiftGateResponse } from "@/lib/server/shift-gate";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string; orderId: string }> };

const statusUpdateSchema = z.object({
  status: z.enum(["confirmed", "preparing", "ready", "completed", "cancelled"]),
  /** optional customer-facing note ("we will call you when it's ready") */
  statusNote: z.string().trim().max(300).optional(),
  /** ROUND 56 — when true (default) and the guest left an email, the status
   *  change also dispatches a branded tracking notice (SMTP or dev spool). */
  notify: z.boolean().optional(),
});

/** Email-shaped values are PII — mask them for the audit trail; plain admin
 *  handles ("sarah.super") pass through so the trail stays correlatable. */
const EMAIL_SHAPE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function auditActorName(name: string): string {
  return EMAIL_SHAPE.test(name) ? maskEmail(name) : name;
}

/** how many CAS retries when a concurrent transition wins the append race */
const HISTORY_RETRIES = 3;

/**
 * PATCH /api/instances/[id]/orders/[orderId] — the workspace owner advances
 * an order through its lifecycle (round 36). Scoped to the instance; the
 * order must belong to THIS workspace (tenant isolation); transitions are
 * audited and the change lands on the order's activity trail.
 *
 * ROUND 56 — every transition is now also appended to the order's
 * PERSISTENT status history (`statusHistoryJson`): the customer tracking
 * view renders WHEN each step happened, not just the current position.
 * The append is compare-and-swap (predicated on the exact trail string
 * that was read), so two concurrent PATCHes can never lose an entry —
 * the loser retries against the fresh trail.
 */
export async function PATCH(req: Request, { params }: RouteContext) {
  const { id, orderId } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "orders.manage" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const trialLock = await trialLockResponse(id);
  if (trialLock) return trialLock;

  /* ROUND 133 — نظام الورديات: fulfilling an order is a business mutation →
     refused with 403 SHIFT_REQUIRED while no shift is open. */
  const shiftGate = await shiftGateResponse(id);
  if (shiftGate) return shiftGate;

  /* ROUND 37 (task 3-c) — bounded body read in place of the unbounded
   * req.json(); parse order preserved. */
  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = statusUpdateSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "status must be one of confirmed, preparing, ready, completed, cancelled" },
      { status: 400 }
    );
  }

  try {
    /* ------------------ same-state no-op (idempotent PATCH) -------------
     * A repeated transition to the order's CURRENT status is a no-op: the
     * current row is returned, nothing is appended to the trail, no email
     * is dispatched, no compensation runs. Retried/duplicate PATCHes are
     * absorbed instead of duplicating side effects. */
    {
      /* ROUND 146 — trashed orders are dead to the live lifecycle surface
       * (the trash system owns restore/purge); findFirst lets the soft-delete
       * predicate ride the same id lookup. */
      const current = await db.siteOrder.findFirst({
        where: { id: orderId, deletedAt: null },
        select: { id: true, instanceId: true, status: true, statusNote: true, statusHistoryJson: true, updatedAt: true, code: true },
      });
      if (!current || current.instanceId !== id) {
        return NextResponse.json({ error: "Order not found" }, { status: 404 });
      }
      if (current.status === parsed.data.status) {
        return NextResponse.json({
          id: current.id,
          status: current.status,
          statusNote: current.statusNote,
          notified: false,
          statusHistory: parseStatusHistory(current.statusHistoryJson),
          updatedAt: current.updatedAt.toISOString(),
        });
      }
      /* LIFECYCLE GATE: only legal transitions (state machine — see
         order-lifecycle.ts). Illegal jumps are a clean 409, never a silent
         write. */
      if (!isValidTransition(current.status as OrderStatus, parsed.data.status)) {
        return NextResponse.json(
          {
            error: `Cannot transition order from ${current.status} to ${parsed.data.status}`,
            code: "INVALID_TRANSITION",
          },
          { status: 409 }
        );
      }
    }

    /* ------------------ CAS-append the lifecycle trail ------------------
     * Loop: read the current trail, append the new event, and land the
     * WHOLE update (status + note + trail) in ONE status-predicated
     * updateMany guarded by BOTH the open-order check and the exact
     * statusHistoryJson that was read. A concurrent writer that lands
     * first forces a retry with the fresh trail — no lost entries. */
    const eventAt = new Date().toISOString();
    const noteForTrail = parsed.data.statusNote?.trim() || null;

    let row: Awaited<ReturnType<typeof db.siteOrder.findUnique>> = null;
    let landed = false;

    for (let attempt = 0; attempt < HISTORY_RETRIES && !landed; attempt++) {
      const existing = await db.siteOrder.findFirst({ where: { id: orderId, deletedAt: null } });
      if (!existing || existing.instanceId !== id) {
        return NextResponse.json({ error: "Order not found" }, { status: 404 });
      }
      /* closed orders exit the loop immediately (no wasted retries) */
      if (existing.status === "completed" || existing.status === "cancelled") {
        return NextResponse.json(
          { error: "This order is already closed", code: "ORDER_CLOSED" },
          { status: 409 }
        );
      }
      /* TERMINAL-STATE CAS: `completed` and `cancelled` are closed forever.
       * The status-predicated updateMany makes the check and the write ONE
       * atomic step — two concurrent PATCHes can no longer both pass the
       * open-order check and let the last writer resurrect a closed order
       * (e.g. cancelled → completed). The loser gets a clean 409.
       * Transitions among OPEN states remain free (kitchens legitimately
       * send orders back a step); only the closed states are terminal. */
      const trail = parseStatusHistory(existing.statusHistoryJson);
      trail.push({
        status: parsed.data.status,
        note: noteForTrail,
        at: eventAt,
      });
      const nextTrailJson = JSON.stringify(trail.slice(-40));

      const transition = await db.siteOrder.updateMany({
        where: {
          id: orderId,
          deletedAt: null,
          status: { notIn: ["completed", "cancelled"] },
          statusHistoryJson: existing.statusHistoryJson ?? null,
        },
        data: {
          status: parsed.data.status,
          ...(parsed.data.statusNote !== undefined ? { statusNote: parsed.data.statusNote } : {}),
          statusHistoryJson: nextTrailJson,
        },
      });
      if (transition.count === 1) {
        landed = true;
        row = await db.siteOrder.findFirst({ where: { id: orderId, deletedAt: null } });
      }
      /* count 0 → either the order closed OR a concurrent transition won
       * the trail append — re-read and retry; the next iteration returns
       * the clean ORDER_CLOSED 409 if this order is genuinely closed. */
    }

    if (!landed) {
      const current = await db.siteOrder.findFirst({
        where: { id: orderId, deletedAt: null },
        select: { status: true, instanceId: true },
      });
      if (!current || current.instanceId !== id) {
        return NextResponse.json({ error: "Order not found" }, { status: 404 });
      }
      return NextResponse.json(
        { error: "This order is already closed", code: "ORDER_CLOSED" },
        { status: 409 }
      );
    }
    if (!row) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    /* ----------------- CANCELLATION COMPENSATION (exactly-once) --------
     * The transition CAS above landed exactly once, so compensation runs
     * exactly once: the cancelled order's stock and coupon reservations
     * are released back. ROUND 120 — a fully-resolved release lands the
     * durable `compensatedAt` marker; a partial/pending release stays
     * NULL and the order-compensation-repair sweep re-drives it (crash
     * between the transition and the release is no longer a leak). */
    let compensation: { releasedStockUnits: number; releasedCouponUse: boolean } | null = null;
    if (parsed.data.status === "cancelled") {
      try {
        const outcome = await compensateOrderReservations({
          id: row.id,
          instanceId: row.instanceId,
          itemsJson: row.itemsJson,
          couponCode: row.couponCode,
          couponId: row.couponId,
        });
        compensation = {
          releasedStockUnits: outcome.releasedStockUnits,
          releasedCouponUse: outcome.releasedCouponUse,
        };
        if (outcome.resolved) {
          /* land the durable marker — the repair sweep's signal that this
           * order is done; CAS so a concurrent writer never sees it flip
           * twice (and never resurrects it over an operator's clear) */
          await db.siteOrder.updateMany({
            where: { id: row.id, compensatedAt: null, status: "cancelled" },
            data: { compensatedAt: new Date() },
          });
        }
        if (outcome.skipped.length > 0) {
          console.warn(
            `order ${orderId.slice(0, 8)} cancellation compensation partial: ${outcome.skipped.join("; ")}`
          );
        }
      } catch (error) {
        console.error(
          `order ${orderId.slice(0, 8)} cancellation compensation failed:`,
          error instanceof Error ? error.message : error
        );
      }
    }

    await logAudit({
      actorType: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: auditActorName(guard.principal.actorName),
      action: "instance.update",
      targetLabel: `Order ${orderId.slice(0, 8).toUpperCase()}`,
      meta: { order: parsed.data.status },
    });

    /* ------------- ROUND 56 — customer email notice (best-effort) -------
     * The owner opts out per transition (`notify:false`). The guest's
     * sealed email is decrypted IN-PROCESS only; delivery failure never
     * fails the transition — the status change is already durable.
     * EMAIL SYSTEM: the envelope is assembled by the DOMAIN SENDER
     * (sendOrderStatusNotice → Mail Service → provider) — this route no
     * longer hand-rolls the transport call, and every notice lands in the
     * EmailLog delivery trail typed "orderStatus". */
    let notified = false;
    if (parsed.data.notify !== false && row.code) {
      try {
        const customer = await db.siteCustomer.findUnique({
          where: { id: row.customerId },
          select: { name: true, email: true },
        });
        const email = customer ? (decryptField(customer.email) ?? "").trim() : "";
        if (customer && email && EMAIL_SHAPE.test(email)) {
          const orgName = await orgDisplayName(id);
          const origin = new URL(req.url).origin;
          notified = await sendOrderStatusNotice({
            customerEmail: email,
            instanceId: id,
            orderId: row.id,
            customerName: customer.name,
            trackingCode: row.code,
            status: parsed.data.status as
              | "confirmed"
              | "preparing"
              | "ready"
              | "completed"
              | "cancelled",
            note: noteForTrail,
            orgName,
            totalFormatted: formatMinor(row.total, row.currency),
            lang: await orgLang(id),
            trackingUrl: `${origin}/sites/${id}/store#tracking`,
            /* ROUND 121 — the standalone receipt link (MAC-sealed token,
               30-day TTL — the SAME primitive the tracking endpoint
               issues): the notice's own secondary affordance so the guest
               reaches the printable receipt straight from the email. The
               owner opted into this mail; the link exposes only the guest
               projection (no unit prices, no identity). */
            receiptUrl: `${origin}/sites/${id}/receipt?token=${encodeURIComponent(
              issueReceiptToken(id, row.id)
            )}`,
          });
        }
      } catch (mailError) {
        /* never let a mail hiccup fail a durable transition */
        console.error(
          `order-status notice for ${orderId.slice(0, 8)} failed:`,
          mailError instanceof Error ? mailError.message : mailError
        );
      }
    }

    /* ROUND 113 — order-event webhook fan-out (best-effort, fire-and-
     * forget: the transition is already durable). A cancellation emits the
     * dedicated `order.cancelled` event; every other legal transition
     * emits `order.status_changed`. The same-state no-op above never
     * reaches here, so no duplicate events. The payload mirrors the
     * response contract (id/code/status/note); money totals live on the
     * order.placed payload (legacy-v1-aware there) — receivers correlate
     * by order id. */
    void enqueueWebhookEvent(
      id,
      row.status === "cancelled" ? "order.cancelled" : "order.status_changed",
      {
        id: row.id,
        code: row.code,
        status: row.status,
        statusNote: row.statusNote,
        updatedAt: row.updatedAt.toISOString(),
      }
    );

    return NextResponse.json({
      id: row.id,
      status: row.status,
      statusNote: row.statusNote,
      notified,
      statusHistory: parseStatusHistory(row.statusHistoryJson),
      updatedAt: row.updatedAt.toISOString(),
      ...(compensation
        ? {
            compensation: {
              releasedStockUnits: compensation.releasedStockUnits,
              releasedCouponUse: compensation.releasedCouponUse,
            },
          }
        : {}),
    });
  } catch (error) {
    console.error(`PATCH /api/instances/${id}/orders/${orderId} failed:`, error);
    return NextResponse.json({ error: "Failed to update the order" }, { status: 500 });
  }
}

/** workspace display name (fallback: "Ashrilogic") — one bounded read. */
async function orgDisplayName(instanceId: string): Promise<string> {
  const instance = await db.instance.findUnique({
    where: { id: instanceId },
    select: { orgJson: true },
  });
  try {
    const org = JSON.parse(instance?.orgJson ?? "{}") as { name?: unknown };
    if (typeof org.name === "string" && org.name.trim()) return org.name.trim();
  } catch {
    /* fall through */
  }
  return "Ashrilogic";
}

/** workspace language preference (drives the notice language). */
async function orgLang(instanceId: string): Promise<"ar" | "en" | "hi"> {
  const instance = await db.instance.findUnique({
    where: { id: instanceId },
    select: { orgJson: true },
  });
  try {
    const org = JSON.parse(instance?.orgJson ?? "{}") as { lang?: unknown };
    if (org.lang === "en" || org.lang === "hi") return org.lang;
  } catch {
    /* fall through */
  }
  return "ar";
}

/** minor-units total → localized display string for the notice. */
function formatMinor(totalMinor: number, currency: string): string {
  try {
    return new Intl.NumberFormat("en", {
      style: "currency",
      currency: /^[A-Za-z]{3}$/.test(currency) ? currency : "SAR",
    }).format(toDisplayUnits(totalMinor));
  } catch {
    return `${toDisplayUnits(totalMinor)} ${currency || "SAR"}`;
  }
}

/**
 * DELETE /api/instances/[id]/orders/[orderId] — ROUND 87 (trash): the owner
 * moves an order to the workspace trash. The order leaves the console, the
 * customer account and the public tracker at once (its unique tracking
 * code is mangled, the original kept for conflict-checked restore) while
 * staying restorable for the retention window. Strictly scoped to this
 * workspace; audited like every order lifecycle transition.
 */
export async function DELETE(req: Request, { params }: RouteContext) {
  const { id, orderId } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "orders.manage" });
  if (guard instanceof NextResponse) return guard;

  const trialLock = await trialLockResponse(id);
  if (trialLock) return trialLock;

  /* ROUND 133 — نظام الورديات: order mutation → 403 SHIFT_REQUIRED while
     no shift is open (the strict, non-bypassable shift law). */
  const shiftGate = await shiftGateResponse(id);
  if (shiftGate) return shiftGate;

  try {
    const existing = await db.siteOrder.findFirst({
      where: { id: orderId, instanceId: id, deletedAt: null },
      select: { id: true, code: true, status: true },
    });
    if (!existing) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    const { softDelete } = await import("@/lib/server/trash");
    const result = await softDelete("siteOrder", existing.id, {
      kind: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: guard.principal.actorName,
    }, { instanceScope: id });
    if (!result.ok) {
      return NextResponse.json({ error: "Failed to delete the order" }, { status: result.status });
    }
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error(`DELETE /api/instances/${id}/orders/${orderId} failed:`, error);
    return NextResponse.json({ error: "Failed to delete the order" }, { status: 500 });
  }
}
