import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/server/admin-session";
import { computeEntitlement } from "@/lib/server/entitlement";
import { computeWorkspaceUsage, storageQuotaMb } from "@/lib/server/usage";
import { instanceAuditWhere, logAudit } from "@/lib/server/audit";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * ROUND 136 — GET /api/admin/instances/[id]/ops — the STRONG per-instance
 * telemetry drilldown: the Super-Admin console's live connection to ONE
 * tenant system, the same redaction contract as /api/admin/ops (identifiers,
 * counts and ages ONLY — the org name is fine, the admin directory already
 * shows it; NO emails/phones, masked or otherwise).
 *
 * SUPER-ADMIN ONLY (the deep posture of a single workspace — operator
 * need-to-know, not moderator material).
 *
 * Envelope (additive, read-only):
 *   instance — id, org name, systemId, demo flag, live entitlement state +
 *              lockReason, plan identity (name/maxModules/maxStorageMb),
 *              term state (paid expiry / trial window + days left), ban
 *              state, session epoch
 *   health   — active sessions, last-activity age, real storage usage vs
 *              quota (+pct), live member count, enabled modules vs the
 *              plan's module limit
 *   store    — the workspace's retail catalog posture (products, low stock,
 *              order pipeline counts, completed-order revenue + currency)
 *   site     — public-website posture (live, views, customers, inquiries)
 *   webhooks — integration endpoints (active count, 24h failed deliveries)
 *   shifts   — the cashier-shift posture (open count, last close instant)
 *   audit    — the instance's audit linkage (total rows + the newest 5,
 *              action keys only — the trail's own masking already applies)
 *
 * Every query is instanceId-scoped and bounded (records ≤ 400, audit ≤ 5).
 * The drilldown itself is audit-logged ("admin.instanceOps", business trail,
 * meta.instance stamped so the instance filter catches it).
 */

/* The store-module resolution law — mirrors /api/admin/stores (ROUND 66:
 * menu outranks inventory; restaurant storefronts sell dishes). */
const STORE_MODULE_PRIORITY = ["pharmacy", "products", "menu", "inventory"] as const;
const STORE_COLUMNS: Record<string, { name: number; stock: number; price: number }> = {
  pharmacy: { name: 0, stock: 4, price: 5 },
  inventory: { name: 0, stock: 3, price: 4 },
  products: { name: 0, stock: 3, price: 4 },
  menu: { name: 0, stock: 3, price: 2 },
};
const LOW_STOCK_THRESHOLD = 5;
const RECORD_CAP = 400;

function readModules(modulesJson: string): string[] {
  try {
    const parsed = JSON.parse(modulesJson ?? "[]") as unknown;
    return Array.isArray(parsed) ? parsed.filter((m): m is string => typeof m === "string") : [];
  } catch {
    return [];
  }
}

function readOrgName(orgJson: string, fallback: string): string {
  try {
    const parsed = JSON.parse(orgJson ?? "{}") as { name?: unknown };
    return typeof parsed.name === "string" && parsed.name.trim() ? parsed.name.trim() : fallback;
  } catch {
    return fallback;
  }
}

function readCurrency(orgJson: string): string {
  try {
    const parsed = JSON.parse(orgJson ?? "{}") as { currency?: unknown };
    return typeof parsed.currency === "string" && parsed.currency.trim() ? parsed.currency.trim() : "SAR";
  } catch {
    return "SAR";
  }
}

function parseNumber(raw: string | undefined): number {
  if (raw == null) return 0;
  const n = Number(String(raw).replace(/[^\d.-]/g, ""));
  return Number.isFinite(n) && n >= 0 ? n : 0;
}

/** Sellable catalog posture (the storefront filters, mirrored): rows with a
 *  name + a price, not marked out/expired, stock > 0. */
function catalogStats(
  moduleId: string,
  records: { dataJson: string; statusKey: string }[]
): { products: number; lowStock: number } {
  const cols = STORE_COLUMNS[moduleId] ?? { name: 0, stock: 3, price: 4 };
  let products = 0;
  let lowStock = 0;
  for (const record of records) {
    let values: string[] = [];
    try {
      const parsed = JSON.parse(record.dataJson ?? "[]") as unknown;
      if (Array.isArray(parsed)) values = parsed.map((v) => (typeof v === "string" ? v : ""));
    } catch {
      continue;
    }
    const at = (i: number) => (i < values.length ? values[i] : "");
    const name = at(cols.name).trim();
    const price = parseNumber(at(cols.price));
    if (!name || price <= 0) continue;
    if (record.statusKey === "out" || record.statusKey === "expired") continue;
    const stock = Math.floor(parseNumber(at(cols.stock)));
    if (stock <= 0) continue;
    products += 1;
    if (stock <= LOW_STOCK_THRESHOLD) lowStock += 1;
  }
  return { products, lowStock };
}

export async function GET(_req: Request, { params }: RouteContext) {
  const guard = await requireAdmin(["super"]);
  if (guard instanceof NextResponse) return guard;

  const { id } = await params;

  try {
    const row = await db.instance.findUnique({
      where: { id },
      select: {
        id: true,
        systemId: true,
        orgJson: true,
        modulesJson: true,
        demo: true,
        deletedAt: true,
        packageId: true,
        trialEndsAt: true,
        planActivatedAt: true,
        planCycle: true,
        planExpiresAt: true,
        featureOverridesJson: true,
        bannedPermanently: true,
        bannedUntil: true,
        bannedReason: true,
        bannedAt: true,
        sessionVersion: true,
        package: {
          select: { capabilitiesJson: true, nameAr: true, nameEn: true, maxModules: true, maxStorageMb: true },
        },
      },
    });
    /* ROUND 87 — a trashed workspace is governed by the trash console, not
     * this surface; unknown ids read identically (no existence oracle). */
    if (!row || row.deletedAt) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }

    const now = Date.now();
    const modules = readModules(row.modulesJson);
    const orgName = readOrgName(row.orgJson, row.systemId);
    const currency = readCurrency(row.orgJson);
    const entitlement = computeEntitlement(row);

    const storeModuleId =
      STORE_MODULE_PRIORITY.find((candidate) => modules.includes(candidate)) ?? null;

    const [
      lastActivity,
      activeSessions,
      membersCount,
      siteRow,
      customersCount,
      inquiriesCount,
      activeEndpoints,
      failedDeliveries,
      openShifts,
      lastClosedShift,
      orderGroups,
      recordRows,
      auditRows,
      auditTotal,
    ] = await Promise.all([
      db.activity.findFirst({
        where: { instanceId: id },
        orderBy: { createdAt: "desc" },
        select: { createdAt: true },
      }),
      db.sessionRecord.count({
        where: { scope: "instance", subjectId: id, revokedAt: null, expiresAt: { gt: new Date(now) } },
      }),
      db.teamMember.count({ where: { instanceId: id, deletedAt: null } }),
      db.site.findUnique({ where: { instanceId: id }, select: { published: true, views: true } }),
      db.siteCustomer.count({ where: { instanceId: id, deletedAt: null } }),
      db.supportTicket.count({ where: { instanceId: id } }),
      db.webhookEndpoint.count({ where: { instanceId: id, deletedAt: null, active: true } }),
      db.webhookDelivery.count({
        where: {
          instanceId: id,
          status: { in: ["failed", "exhausted"] },
          createdAt: { gte: new Date(now - 24 * 60 * 60 * 1000) },
        },
      }),
      db.shift.count({ where: { instanceId: id, status: "open" } }),
      db.shift.findFirst({
        where: { instanceId: id, closedAt: { not: null } },
        orderBy: { closedAt: "desc" },
        select: { closedAt: true },
      }),
      db.siteOrder.groupBy({
        by: ["status"],
        where: { instanceId: id, deletedAt: null },
        _count: { _all: true },
        _sum: { total: true },
      }),
      storeModuleId
        ? db.moduleRecord.findMany({
            where: { instanceId: id, moduleId: storeModuleId, deletedAt: null },
            orderBy: [{ createdAt: "desc" }, { id: "desc" }],
            take: RECORD_CAP,
            select: { dataJson: true, statusKey: true },
          })
        : Promise.resolve([] as { dataJson: string; statusKey: string }[]),
      db.auditLog.findMany({
        where: instanceAuditWhere(id),
        orderBy: [{ createdAt: "desc" }, { id: "desc" }],
        take: 5,
        select: { id: true, action: true, actorType: true, targetLabel: true, createdAt: true },
      }),
      db.auditLog.count({ where: instanceAuditWhere(id) }),
    ]);

    /* order pipeline (all live statuses) + completed-order revenue (minor
     * units → major units, one currency — the org's own) */
    let ordersCount = 0;
    let ordersCompleted = 0;
    let revenueMinor = 0;
    for (const group of orderGroups) {
      ordersCount += group._count._all;
      if (group.status === "completed") {
        ordersCompleted += group._count._all;
        revenueMinor += group._sum.total ?? 0;
      }
    }
    const catalog = storeModuleId ? catalogStats(storeModuleId, recordRows) : { products: 0, lowStock: 0 };

    /* real storage accounting (server-computed ground truth — usage.ts) */
    const quotaMb = storageQuotaMb(entitlement, row.package?.maxStorageMb ?? null);
    const usage = await computeWorkspaceUsage(id, quotaMb);

    /* the drilldown itself is audit-logged (business trail; the meta.instance
     * stamp makes the row findable by the instance audit filter) */
    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "admin.instanceOps",
      targetLabel: orgName,
      meta: { instance: id },
    });

    return NextResponse.json({
      instance: {
        id: row.id,
        name: orgName,
        systemId: row.systemId,
        demo: row.demo,
        entitlement: { state: entitlement.state, lockReason: entitlement.lockReason },
        plan: row.package
          ? {
              nameAr: row.package.nameAr,
              nameEn: row.package.nameEn,
              maxModules: row.package.maxModules,
              maxStorageMb: row.package.maxStorageMb,
            }
          : null,
        term: {
          planActivatedAt: entitlement.planActivatedAt,
          planCycle: entitlement.planCycle,
          planExpiresAt: entitlement.planExpiresAt,
          planDaysLeft: entitlement.planDaysLeft,
          trialEndsAt: entitlement.trialEndsAt,
          trialDaysLeft: entitlement.trialDaysLeft,
        },
        ban: entitlement.ban,
        sessionVersion: row.sessionVersion ?? 0,
      },
      health: {
        activeSessions,
        lastActivityAt: lastActivity ? lastActivity.createdAt.toISOString() : null,
        lastActivityAgeMs: lastActivity ? Math.max(0, now - lastActivity.createdAt.getTime()) : null,
        storageUsedBytes: usage.totalBytes,
        storageQuotaMb: quotaMb,
        storagePct: usage.pct,
        membersCount,
        modulesEnabled: modules.length,
        planModuleLimit: row.package?.maxModules ?? null,
      },
      store: {
        moduleId: storeModuleId,
        productsCount: catalog.products,
        lowStockCount: catalog.lowStock,
        ordersCount,
        ordersCompleted,
        revenue: revenueMinor > 0 ? { currency, value: revenueMinor / 100 } : null,
      },
      site: {
        live: siteRow?.published ?? false,
        views: siteRow?.views ?? 0,
        customersCount,
        inquiriesCount,
      },
      webhooks: {
        activeEndpoints,
        failedDeliveries24h: failedDeliveries,
      },
      shifts: {
        openCount: openShifts,
        lastClosedAt: lastClosedShift?.closedAt ? lastClosedShift.closedAt.toISOString() : null,
      },
      audit: {
        total: auditTotal,
        recent: auditRows.map((r) => ({
          id: r.id,
          action: r.action,
          actorType: r.actorType,
          targetLabel: r.targetLabel,
          createdAt: r.createdAt.toISOString(),
        })),
      },
      generatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error(`GET /api/admin/instances/[id]/ops failed:`, error);
    return NextResponse.json({ error: "Failed to load instance ops" }, { status: 500 });
  }
}
