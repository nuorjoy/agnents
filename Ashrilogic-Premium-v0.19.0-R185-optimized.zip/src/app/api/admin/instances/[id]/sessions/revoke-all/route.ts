import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/server/admin-session";
import { revokeAllSessions } from "@/lib/server/sessions";
import { logAudit } from "@/lib/server/audit";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * ROUND 136 — POST /api/admin/instances/[id]/sessions/revoke-all — the
 * STRICT Super-Admin session lever for a single tenant system: bumps the
 * workspace's session epoch (sessionVersion) AND revokes every live
 * SessionRecord in the same action — the exact twin of the subscriber ban
 * lever (PATCH /api/admin/subscribers/[id]) without touching ban state.
 *
 * Every outstanding workspace token dies instantly (requireInstanceAccess
 * re-checks the epoch on the next request; the registry rows are stamped
 * revokedAt now) — the tenant's owners re-authenticate with their password.
 *
 * SUPER-ADMIN ONLY (session invalidation is the strongest non-destructive
 * access lever — admin/moderator roles keep the subscriber-governance
 * surfaces they already own). Response: { revoked: <destroyed count> } —
 * the number of live sessions that were destroyed by THIS call.
 *
 * Audit: "admin.instanceSessionsRevoke" (SECURITY trail — unconditional,
 * retention floor) with the destroyed count + the meta.instance stamp so
 * the instance audit filter catches the row.
 */
export async function POST(req: Request, { params }: RouteContext) {
  const guard = await requireAdmin(["super"], req);
  if (guard instanceof NextResponse) return guard;

  const { id } = await params;

  try {
    const row = await db.instance.findUnique({
      where: { id },
      select: { id: true, systemId: true, orgJson: true, sessionVersion: true, deletedAt: true },
    });
    /* a trashed workspace already had every session revoked by the trash
     * engine — unknown/trashed ids read identically (no existence oracle) */
    if (!row || row.deletedAt) {
      return NextResponse.json({ error: "Instance not found" }, { status: 404 });
    }

    let orgName = row.systemId;
    try {
      const parsed = JSON.parse(row.orgJson ?? "{}") as { name?: unknown };
      if (typeof parsed.name === "string" && parsed.name.trim()) orgName = parsed.name.trim();
    } catch {
      /* corrupt orgJson — audit with the systemId instead */
    }

    /* count the live sessions BEFORE the revocation so the response tells
     * the operator exactly how many device sessions this lever destroyed */
    const now = new Date();
    const liveSessions = await db.sessionRecord.count({
      where: { scope: "instance", subjectId: id, revokedAt: null, expiresAt: { gt: now } },
    });

    /* bump the epoch + revoke the registry rows — both layers, one action
     * (belt-and-braces, mirroring the ban lever's exact sequence) */
    await db.instance.update({
      where: { id },
      data: { sessionVersion: { increment: 1 } },
    });
    await revokeAllSessions("instance", id);

    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "admin.instanceSessionsRevoke",
      targetLabel: orgName,
      meta: { instance: id, revoked: String(liveSessions) },
    });

    return NextResponse.json({ revoked: liveSessions });
  } catch (error) {
    console.error(`POST /api/admin/instances/[id]/sessions/revoke-all failed:`, error);
    return NextResponse.json({ error: "Failed to revoke sessions" }, { status: 500 });
  }
}
