import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { clearSessionCookie, getSessionUser } from "@/lib/server/admin-session";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { originViolation } from "@/lib/server/origin-guard";
import { revokeAllSessions } from "@/lib/server/sessions";

export const dynamic = "force-dynamic";

/** Email-shaped usernames are PII — masked for the trail; plain handles pass. */
const EMAIL_SHAPE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function auditActorName(username: string): string {
  return EMAIL_SHAPE.test(username) ? maskEmail(username) : username;
}

/**
 * POST /api/admin/logout — clears the HTTP-only session cookie, records the
 * sign-out in the audit trail (when a session was still active), and —
 * ROUND 37 (task 3-a) — bumps the admin's session epoch so the logout is a
 * SERVER-SIDE revocation: every outstanding token for that admin dies with
 * it, not just the cookie in the browser that happened to ask.
 */
export async function POST(req: Request) {
  try {
    /* same-origin guard first — a cross-site page must not be able to log an
       ambient-cookie admin out (logout CSRF). */
    const violation = originViolation(req);
    if (violation) return violation;

    const user = await getSessionUser();
    await clearSessionCookie();
    if (user) {
      await db.adminUser.update({
        where: { id: user.id },
        data: { sessionVersion: { increment: 1 } },
      });
      /* ROUND 45 — mirror the epoch revocation in the session registry */
      await revokeAllSessions("admin", user.id);
      await logAudit({ actorType: "admin", actorId: user.id, actorName: auditActorName(user.username), action: "admin.logout" });
    }
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("POST /api/admin/logout failed:", error);
    return NextResponse.json({ error: "Logout failed" }, { status: 500 });
  }
}
