import { adminTopupAction } from "@/server/domains/wallet/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 141 — PATCH /api/admin/wallet-topups/[id] — confirm receipt
 * ({ action: "paid" } — credits the wallet ATOMICALLY: the status flip +
 * the CAS balance delta + the "topup" ledger row in ONE transaction) or
 * cancel ({ action: "cancelled" }). super/admin only — money-moving, so
 * the audit row is unconditional (retention floor).
 */
export const PATCH = adminTopupAction;
