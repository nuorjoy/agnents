import { adminTopupList } from "@/server/domains/wallet/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 141 — GET /api/admin/wallet-topups?status= — the console's wallet
 * top-up requests queue (org + system identity per row, live effective
 * status, HMAC integrity flags).
 */
export const GET = adminTopupList;
