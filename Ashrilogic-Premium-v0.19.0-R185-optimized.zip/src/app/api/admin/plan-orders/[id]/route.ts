import { adminConfirmOrCancel } from "@/server/domains/plan-orders/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 47 — PATCH /api/admin/plan-orders/[id] — the console confirms a
 * payment receipt ({ action: "paid" }) or cancels a request
 * ({ action: "cancelled" }). super/admin only (moderator/viewer 403).
 *
 * Confirming a payment is the ACTIVATION event: inside one transaction the
 * order is sealed paid and the workspace receives the package + activation
 * timestamp + purchased cycle — instantly restoring a trial-locked
 * workspace and its stopped public site / e-store.
 *
 * ROUND 125 — the handler moved to the plan-orders domain
 * (src/server/domains/plan-orders): this file is the thin route delegation.
 */
export const PATCH = adminConfirmOrCancel;
