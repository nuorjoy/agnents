import { adminList } from "@/server/domains/plan-orders/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 47 — GET /api/admin/plan-orders — the console's activation-requests
 * queue (Payments view). Admin-guarded; returns every plan order with the
 * owning workspace identity (org name + system), live effective status and
 * the HMAC integrity flag. Optional ?status=pending|paid|cancelled filter.
 *
 * ROUND 125 — the handler moved to the plan-orders domain
 * (src/server/domains/plan-orders): this file is the thin route delegation.
 */
export const GET = adminList;
