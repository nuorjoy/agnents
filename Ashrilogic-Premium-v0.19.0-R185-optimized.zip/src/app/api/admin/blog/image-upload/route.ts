import { NextResponse } from "next/server";
import { z } from "zod";
import { zodError } from "@/lib/server/instance-mapper";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { storeImageDataUrl } from "@/lib/server/image-store";
import { rateLimited, tooManyRequests } from "@/lib/server/rate-limit";

export const dynamic = "force-dynamic";

/**
 * BLOG CONSOLE — inline image upload (ROUND 129).
 *
 * The editor's rich toolbar inserts inline images into the safe-markdown
 * body as `![alt](/api/images/<id>)` managed refs. This route is the upload
 * leg: a data-URL in, a stored ref out — the SAME sanitized pipeline the
 * post cover uses (decode → sniff magic bytes → re-encode, ≤1.5MB output),
 * so inline images inherit the cover's guarantees (no executable SVG/HTML
 * ever lands in storage, size bounded, GC-managed through the image
 * reference engine like every other managed asset).
 *
 * super/admin only (content authority — same as the blog write routes);
 * 30 uploads / 10 min per admin; audited with the resulting ref.
 */

const UPLOAD_RULE = { limit: 30, windowMs: 10 * 60 * 1000 };

const inlineImageSchema = z.object({
  image: z.string().min(30).max(8_000_000),
});

export async function POST(req: Request) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  if (await rateLimited(`blog-img:${guard.user.id}`, UPLOAD_RULE)) {
    return tooManyRequests(UPLOAD_RULE, { error: "Too many image uploads — try again shortly" });
  }

  const body = await readJson(req, 8_500_000);
  if (!body.ok) return body.response;

  const parsed = inlineImageSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }

  try {
    const stored = await storeImageDataUrl(parsed.data.image, { maxOutputBytes: 1_500_000 });
    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "blog.image-upload",
      targetLabel: stored.url,
      meta: { ref: stored.url },
    });
    return NextResponse.json({ url: stored.url }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Invalid image";
    return NextResponse.json({ error: `Image rejected — ${message}` }, { status: 400 });
  }
}
