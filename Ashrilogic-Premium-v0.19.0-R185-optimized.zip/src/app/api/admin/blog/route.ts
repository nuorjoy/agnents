import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  blogPostWriteSchema,
  computeReadMinutes,
  dedupeSlug,
  isStoredCover,
  toAdminBlogPostDTO,
} from "@/lib/server/blog-mapper";
import { zodError } from "@/lib/server/instance-mapper";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { invalidateBlogFacetsCache } from "@/lib/server/blog-feed";
import { readJson } from "@/lib/server/http";
import { storeImageDataUrl, isManagedImageRef } from "@/lib/server/image-store";
import { slugify } from "@/lib/markdown";
import type { Prisma } from "@prisma/client";

export const dynamic = "force-dynamic";

/**
 * BLOG CONSOLE — post list + create.
 *
 * GET  — every post (drafts included), paginated, optional `status` filter
 *        and `q` search over the bilingual titles + slug. Any authenticated
 *        admin role (operational visibility, no secrets).
 * POST — create a post. super/admin only (content authority). The cover may
 *        arrive as a data-URL upload (stored through the sanitized image
 *        pipeline, ≤1.5MB output) or an existing managed ref; the slug is
 *        derived from the English title when omitted and de-duplicated;
 *        readMinutes recomputes server-side on every write.
 */

const PAGE_SIZE_DEFAULT = 12;
const PAGE_SIZE_MAX = 50;

function isUniqueConstraintError(error: unknown): boolean {
  return Boolean(error && typeof error === "object" && (error as { code?: string }).code === "P2002");
}

export async function GET(req: Request) {
  const guard = await requireAdmin();
  if (guard instanceof NextResponse) return guard;

  try {
    const url = new URL(req.url);
    const page = Math.max(1, Number.parseInt(url.searchParams.get("page") ?? "1", 10) || 1);
    const pageSize = Math.min(
      PAGE_SIZE_MAX,
      Math.max(1, Number.parseInt(url.searchParams.get("pageSize") ?? String(PAGE_SIZE_DEFAULT), 10) || PAGE_SIZE_DEFAULT)
    );
    const status = url.searchParams.get("status") ?? "";
    const q = (url.searchParams.get("q") ?? "").trim().slice(0, 80);

    const where: Prisma.BlogPostWhereInput = {
      ...(status === "draft" || status === "published" ? { status } : {}),
      ...(q
        ? {
            OR: [
              { titleAr: { contains: q } },
              { titleEn: { contains: q } },
              { slug: { contains: q } },
            ],
          }
        : {}),
    };

    const [rows, total] = await Promise.all([
      db.blogPost.findMany({
        where,
        orderBy: [{ createdAt: "desc" }],
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      db.blogPost.count({ where }),
    ]);

    return NextResponse.json({ rows: rows.map(toAdminBlogPostDTO), total, page, pageSize });
  } catch (error) {
    console.error("GET /api/admin/blog failed:", error);
    return NextResponse.json({ error: "Failed to list posts" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = blogPostWriteSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const data = parsed.data;

  /* a post needs at least the Arabic title to exist (English optional but
     strongly encouraged — the EN card falls back to the AR title) */
  const titleAr = data.titleAr?.trim() ?? "";
  if (!titleAr) {
    return NextResponse.json({ error: "titleAr is required" }, { status: 400 });
  }

  try {
    /* resolve the cover: data-URL → store; managed ref → keep as-is */
    let coverImage = "";
    if (typeof data.coverImage === "string" && data.coverImage.length > 0) {
      if (isManagedImageRef(data.coverImage)) {
        coverImage = data.coverImage;
      } else {
        try {
          const stored = await storeImageDataUrl(data.coverImage, { maxOutputBytes: 1_500_000 });
          coverImage = stored.url;
        } catch (error) {
          const message = error instanceof Error ? error.message : "Invalid cover image";
          return NextResponse.json({ error: `Cover image rejected — ${message}` }, { status: 400 });
        }
      }
    } else if (isStoredCover(typeof data.coverImage === "string" ? data.coverImage : "")) {
      coverImage = data.coverImage as string;
    }

    /* slug: explicit → as-is (must be free); else derived + de-duplicated */
    const slugBase =
      data.slug?.trim() ||
      slugify(data.titleEn?.trim() || titleAr) ||
      `post-${Date.now()}`;
    const explicitSlug = Boolean(data.slug?.trim());
    let slug = explicitSlug
      ? slugBase
      : await dedupeSlug(slugBase, async (candidate) => {
          return (await db.blogPost.findUnique({ where: { slug: candidate }, select: { id: true } })) !== null;
        });
    const contentAr = data.contentAr ?? "";
    const contentEn = data.contentEn ?? "";
    let row: Awaited<ReturnType<typeof db.blogPost.create>> | null = null;
    for (let attempt = 0; attempt < 10; attempt++) {
      if (await db.blogPost.findUnique({ where: { slug }, select: { id: true } })) {
        if (explicitSlug) return NextResponse.json({ error: "Slug already in use" }, { status: 409 });
        slug = await dedupeSlug(slugBase, async (candidate) => {
          return (await db.blogPost.findUnique({ where: { slug: candidate }, select: { id: true } })) !== null;
        });
      }
      try {
        row = await db.blogPost.create({
          data: {
            slug,
            titleAr,
            titleEn: data.titleEn?.trim() || titleAr,
            excerptAr: data.excerptAr ?? "",
            excerptEn: data.excerptEn ?? "",
            contentAr,
            contentEn,
            coverImage,
            tagsJson: JSON.stringify(data.tags ?? []),
            /* ROUND 129 — the author is SERVER-STAMPED from the acting admin
             * (owner directive: «يتم تحديد الكاتب تلقائياً غير قابل للتغيير»);
             * any client-provided authorName is deliberately ignored. */
            authorName: guard.user.name?.trim() || guard.user.username || "Ashrilogic",
            status: data.status === "published" ? "published" : "draft",
            featured: data.featured ?? false,
            readMinutes: computeReadMinutes(contentAr, contentEn),
            publishedAt: data.status === "published" ? new Date() : null,
          },
        });
        break;
      } catch (error) {
        if (!isUniqueConstraintError(error)) throw error;
        if (explicitSlug) return NextResponse.json({ error: "Slug already in use" }, { status: 409 });
        slug = await dedupeSlug(slugBase, async (candidate) => {
          return (await db.blogPost.findUnique({ where: { slug: candidate }, select: { id: true } })) !== null;
        });
      }
    }
    if (!row) return NextResponse.json({ error: "Could not allocate a unique slug" }, { status: 409 });

    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "blog.create",
      targetLabel: row.titleAr,
      meta: {
        slug: row.slug,
        status: row.status,
        ...(row.featured ? { featured: "true" } : {}),
        ...(coverImage ? { cover: "uploaded" } : {}),
      },
    });

    /* ROUND 173 — the new post's tags/status feed the public chips and
     * feed: drop the facets cache so the change is visible immediately
     * (same-process; the 60s TTL bounds every other process). */
    invalidateBlogFacetsCache();

    return NextResponse.json(toAdminBlogPostDTO(row), { status: 201 });
  } catch (error) {
    console.error("POST /api/admin/blog failed:", error);
    return NextResponse.json({ error: "Failed to create post" }, { status: 500 });
  }
}
