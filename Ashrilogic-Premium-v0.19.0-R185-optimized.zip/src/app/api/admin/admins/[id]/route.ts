import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { adminUserUpdateSchema, toAdminUserDTO, zodError } from "@/lib/server/admin-mapper";
import { requireAdmin, hashPassword } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { blindIndex, encryptField } from "@/lib/server/crypto-vault";
import { readJson } from "@/lib/server/http";
import { ImageValidationError } from "@/lib/server/upload-validation";
import { isManagedImageRef, storeImageDataUrl } from "@/lib/server/image-store";

export const dynamic = "force-dynamic";

/**
 * PATCH /api/admin/admins/[id] — update an account (role, status, details,
 * optional password reset). The seed super-admin cannot be demoted,
 * suspended or deleted — it is the last-resort recovery account for the panel.
 * Requires super/admin.
 */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const { id } = await params;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = adminUserUpdateSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const data = parsed.data;

  /* ROUND 36 — creating or promoting a SUPER account is a super-only
     operation (a plain admin could otherwise mint a super and take over
     the platform). */
  if (data.role === "super" && guard.user.role !== "super") {
    return NextResponse.json(
      { error: "Only a super admin can grant the super role" },
      { status: 403 }
    );
  }

  try {
    const existing = await db.adminUser.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Admin not found" }, { status: 404 });
    }

    /* ROUND 36 — the primary super-admin's identity fields (username,
       email) AND password are protected too: a plain admin could previously
       rotate the root recovery account's password and take it over. Only a
       super admin may touch any of these on that row.
       *
       * ROUND 158 — the primary super-admin can NEVER be suspended
       * (active: false is blocked for ALL roles, including super), but CAN
       * be reactivated (active: true is allowed by any admin). This protects
       * the platform's root account from being locked out while allowing
       * recovery if it was ever accidentally suspended. */
    const isPrimarySuperAdmin = existing.username === "admin" && existing.role === "super";
    /* SUSPEND BLOCK: nobody can set active=false on the primary admin */
    if (isPrimarySuperAdmin && data.active === false) {
      return NextResponse.json(
        { error: "The primary super-admin account cannot be suspended — it is permanently protected" },
        { status: 403 }
      );
    }
    /* IDENTITY BLOCK: non-super admins cannot touch identity fields */
    if (
      isPrimarySuperAdmin &&
      guard.user.role !== "super" &&
      (data.role !== undefined ||
        data.password !== undefined ||
        data.username !== undefined ||
        data.email !== undefined)
    ) {
      return NextResponse.json({ error: "The primary super-admin account is protected" }, { status: 403 });
    }

    /* ROUND 37 — PRIVILEGE ESCALATION FIX: previously a plain `admin` could
       reset the password of (or demote / disable / re-email) ANY non-primary
       super account, silently taking it over. Modifying a super-admin row
       in ANY way — password, role, active, email, profile fields — now
       requires the acting admin to BE a super admin. The promotion guard
       above (role → "super") stays as the first line; this closes the
       target-side hole. */
    if (existing.role === "super" && guard.user.role !== "super") {
      return NextResponse.json(
        { error: "Only a super admin can modify super-admin accounts" },
        { status: 403 }
      );
    }

    /* ROUND 37 — server-side avatar validation (see POST above): sharp
       verifies magic bytes / dimensions and re-encodes to a clean WebP; the
       RETURNED value is persisted, never the client's bytes. `null` (clear
       avatar) passes through untouched.
       ROUND 40 (P2): sanitized bytes live as content-addressed files and the
       persisted value is the /api/images/<sha256> reference. A MANAGED ref
       (already minted by this server) is kept AS-IS — idempotent echo. */
    if (typeof data.avatarUrl === "string" && data.avatarUrl.length > 0) {
      if (isManagedImageRef(data.avatarUrl)) {
        /* server-minted, pre-validated — keep as-is */
      } else {
        try {
          const stored = await storeImageDataUrl(data.avatarUrl, { maxOutputBytes: 400 * 1024 });
          data.avatarUrl = stored.url;
        } catch (error) {
          if (error instanceof ImageValidationError) {
            return NextResponse.json({ error: error.message }, { status: 400 });
          }
          throw error;
        }
      }
    }

    if (data.username !== undefined || data.email !== undefined) {
      /* round 35 — email uniqueness via blind index (sealed column) */
      const clash = await db.adminUser.findFirst({
        where: {
          id: { not: id },
          OR: [
            ...(data.username !== undefined ? [{ username: data.username }] : []),
            ...(data.email !== undefined ? [{ emailIndex: blindIndex(data.email) ?? undefined }] : []),
          ],
        },
        select: { username: true },
      });
      if (clash) {
        return NextResponse.json(
          { error: clash.username === data.username ? "Username already exists" : "Email already exists" },
          { status: 409 }
        );
      }
    }

    const { password, birthDate, email, address, ...rest } = data;
    const row = await db.adminUser.update({
      where: { id },
      data: {
        ...rest,
        /* round 35 — re-seal the sensitive fields when they change */
        ...(email !== undefined ? { email: encryptField(email) ?? "", emailIndex: blindIndex(email) ?? "" } : {}),
        ...(address !== undefined ? { address: address ? encryptField(address) ?? null : null } : {}),
        ...(birthDate !== undefined ? { birthDate: birthDate ? new Date(birthDate) : null } : {}),
        ...(password
          ? {
              passwordHash: hashPassword(password),
              /* round 36 — bump the session epoch: every outstanding session
                 for THIS admin (including the current one) is revoked; the
                 caller's own browser is re-issued below. */
              sessionVersion: { increment: 1 },
            }
          : {}),
        ...(data.active === false
          ? {
              /* round 36 — disabling the account also revokes its sessions */
              sessionVersion: { increment: 1 },
            }
          : {}),
      },
    });
    /* round 36 — keep the ACTING admin signed in when they rotated their own
       password (fresh token at the new epoch); every other session dies.
       ROUND 45 — the registry rows mirror the revocation (and a fresh row is
       created for the surviving session by setSessionCookie). */
    if (password || data.active === false) {
      const { revokeAllSessions } = await import("@/lib/server/sessions");
      await revokeAllSessions("admin", row.id);
    }
    if ((password || data.active === false) && row.id === guard.user.id) {
      const { setSessionCookie, sessionTtlMs } = await import("@/lib/server/admin-session");
      await setSessionCookie(row.id, row.sessionVersion ?? 0, await sessionTtlMs());
    }

    /* ROUND 117 — the replaced/cleared avatar's storage is reclaimed the
     * moment nothing references it (fresh scan inside releaseImageRefs). */
    if (data.avatarUrl !== undefined && isManagedImageRef(existing.avatarUrl ?? "")) {
      const { releaseImageRefs } = await import("@/lib/server/image-ref-gc");
      void releaseImageRefs([existing.avatarUrl]).catch(() => undefined);
    }

    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "admin.update",
      targetLabel: row.username,
      meta: {
        ...(password ? { password: "reset" } : {}),
        ...(data.active !== undefined ? { active: String(data.active) } : {}),
        ...(data.role !== undefined ? { role: data.role } : {}),
      },
    });
    return NextResponse.json(toAdminUserDTO(row));
  } catch (error) {
    console.error("PATCH /api/admin/admins/[id] failed:", error);
    return NextResponse.json({ error: "Failed to update admin" }, { status: 500 });
  }
}

/**
 * DELETE /api/admin/admins/[id] — permanently remove an account.
 * Requires the super role.
 */
export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const guard = await requireAdmin(["super"], _req);
  if (guard instanceof NextResponse) return guard;

  const { id } = await params;
  try {
    const existing = await db.adminUser.findUnique({
      where: { id },
      select: { username: true, role: true, name: true, deletedAt: true },
    });
    if (!existing || existing.deletedAt) {
      return NextResponse.json({ error: "Admin not found" }, { status: 404 });
    }
    if (existing.username === "admin" && existing.role === "super") {
      return NextResponse.json({ error: "The primary super-admin account is protected" }, { status: 403 });
    }

    /* ROUND 87 (trash) — soft delete: the admin moves to the platform trash
       (username + email blind index mangled, originals kept for
       conflict-checked restore) and cannot sign in from this instant;
       live sessions were revoked by the engine. PURGE (super, from the
       trash console) is the only hard delete. */
    const { softDelete } = await import("@/lib/server/trash");
    const result = await softDelete("adminUser", id, {
      kind: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
    });
    if (!result.ok) {
      return NextResponse.json({ error: "Failed to delete admin" }, { status: result.status });
    }
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("DELETE /api/admin/admins/[id] failed:", error);
    return NextResponse.json({ error: "Failed to delete admin" }, { status: 500 });
  }
}
