import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { adminUserCreateSchema, seedAdminDefaults, toAdminUserDTO, zodError } from "@/lib/server/admin-mapper";
import { requireAdmin, hashPassword } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { blindIndex, encryptField } from "@/lib/server/crypto-vault";
import { readJson } from "@/lib/server/http";
import { ImageValidationError } from "@/lib/server/upload-validation";
import { isManagedImageRef, storeImageDataUrl } from "@/lib/server/image-store";
import { presenceMapFor } from "@/lib/server/presence";

export const dynamic = "force-dynamic";

/**
 * GET /api/admin/admins — all control-panel accounts (newest first).
 * ROUND 36: PII-bearing read restricted to super/admin/moderator (viewer
 * sessions no longer see decrypted staff emails/addresses).
 * ROUND 172: every row carries `presence` (live online/offline from the
 * session registry) — ONE grouped query for the whole directory, so the
 * «المسؤولون» rows render their premium green/red state on first paint;
 * the console presence heartbeat keeps it fresh afterwards.
 */
export async function GET() {
  const guard = await requireAdmin(["super", "admin", "moderator"]);
  if (guard instanceof NextResponse) return guard;

  try {
    await seedAdminDefaults(db);
    const rows = await db.adminUser.findMany({
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: 200,
    });
    const presence = await presenceMapFor(
      "admin",
      rows.map((r) => r.id)
    );
    return NextResponse.json(
      rows.map((row) => {
        const dto = toAdminUserDTO(row);
        dto.presence = presence.get(row.id) ?? { online: false, lastSeenAt: null };
        return dto;
      })
    );
  } catch (error) {
    console.error("GET /api/admin/admins failed:", error);
    return NextResponse.json({ error: "Failed to list admins" }, { status: 500 });
  }
}

/**
 * POST /api/admin/admins — create a control-panel account.
 * Username and email are unique (email via blind index — round 35); role must
 * be one of the STAFF_ROLES enum. Requires super/admin. The optional
 * `password` (min 8 chars, round 37) is stored as an Argon2id record so the
 * new account can actually sign in.
 */
export async function POST(req: Request) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = adminUserCreateSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const data = parsed.data;

  /* ROUND 37 — server-side avatar validation: nothing about the client's
     data-URL claim is trusted (MIME label, base64 content, dimensions).
     sharp verifies the actual magic bytes, caps dimensions/pixels
     (decompression bombs) and re-encodes to a clean WebP (EXIF/GPS/trailing
     bytes stripped). The RETURNED value replaces the input before it ever
     reaches the database; the mapper's 600k-char cap is only a pre-filter.
     ROUND 40 (P2): the sanitized bytes now live as a content-addressed FILE
     (storage/images/<sha256>.webp) and the persisted avatarUrl is the short
     reference /api/images/<sha256>. A MANAGED ref (already minted by this
     server) is persisted AS-IS — no re-encode, idempotent echo. */
  if (typeof data.avatarUrl === "string" && data.avatarUrl.length > 0) {
    if (isManagedImageRef(data.avatarUrl)) {
      /* server-minted, pre-validated — keep as-is */
    } else {
      try {
        const stored = await storeImageDataUrl(data.avatarUrl, { maxOutputBytes: 400 * 1024 });
        data.avatarUrl = stored.url;
      } catch (error) {
        if (error instanceof ImageValidationError) {
          return NextResponse.json({ error: error.message }, { status: 400 });
        }
        throw error;
      }
    }
  }

  /* ROUND 36 — minting a SUPER account is super-only (an admin granting
     themselves super would unlock admin deletion + destructive ops). */
  if (data.role === "super" && guard.user.role !== "super") {
    return NextResponse.json(
      { error: "Only a super admin can create a super admin" },
      { status: 403 }
    );
  }

  try {
    /* round 35 — uniqueness: username plaintext + email via blind index */
    const clash = await db.adminUser.findFirst({
      where: {
        OR: [
          { username: data.username },
          { emailIndex: blindIndex(data.email) ?? undefined },
        ],
      },
      select: { username: true },
    });
    if (clash) {
      return NextResponse.json(
        { error: clash.username === data.username ? "Username already exists" : "Email already exists" },
        { status: 409 }
      );
    }

    const { password, birthDate, email, address, ...rest } = data;
    const row = await db.adminUser.create({
      data: {
        ...rest,
        /* round 35 — email + address sealed at rest, email blind-indexed */
        email: encryptField(email) ?? "",
        emailIndex: blindIndex(email) ?? "",
        ...(address ? { address: encryptField(address) ?? null } : {}),
        ...(birthDate ? { birthDate: new Date(birthDate) } : {}),
        ...(password ? { passwordHash: hashPassword(password) } : {}),
      },
    });
    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "admin.create",
      targetLabel: row.username,
      meta: { role: row.role },
    });
    return NextResponse.json(toAdminUserDTO(row), { status: 201 });
  } catch (error) {
    console.error("POST /api/admin/admins failed:", error);
    return NextResponse.json({ error: "Failed to create admin" }, { status: 500 });
  }
}
