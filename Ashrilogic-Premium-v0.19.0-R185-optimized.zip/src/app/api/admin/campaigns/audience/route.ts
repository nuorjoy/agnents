import { adminAudiencePreview } from "@/server/domains/campaigns/controller";

export const dynamic = "force-dynamic";

/**
 * /api/admin/campaigns/audience — the SEGMENTED composer's live audience
 * preview (ROUND 167, tenant messaging).
 *
 * GET ?target=subscribers|tenants|tenants:plan&packageId=… — the exact
 * population a campaign claim would snapshot and the dispatcher would walk,
 * resolved BEFORE anything is claimed (the wallet-grants preview law):
 *   - subscribers  → active + restricted newsletter subscribers;
 *   - tenants      → every LIVE instance's owner mailbox;
 *   - tenants:plan → owners whose instance's CURRENT package matches
 *                    (validated against a live package row → 404 otherwise).
 *
 * Read posture: any authenticated super/admin (the composer's live count).
 */
export const GET = adminAudiencePreview;
