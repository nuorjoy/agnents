import { adminList, adminCreate } from "@/server/domains/campaigns/controller";

export const dynamic = "force-dynamic";

/**
 * /api/admin/campaigns — the newsletter-campaign archive.
 *
 * ROUND 165 — the handler bodies moved into the campaigns domain
 * (src/server/domains/campaigns/controller.ts); this file is now a thin
 * delegation, the canonical route shape for every migrated surface:
 *
 *   route.ts → domain controller → domain service → domain repository
 *
 * The send path (PATCH on [id]) is a CLAIM — bulk delivery never runs
 * inside an HTTP request (the durable dispatcher owns it; see the
 * domain service header for the full lifecycle).
 */

/** GET — the campaign archive (latest first) + the live audience estimate. */
export const GET = adminList;

/** POST — create a DRAFT (super/admin only; audited). */
export const POST = adminCreate;
