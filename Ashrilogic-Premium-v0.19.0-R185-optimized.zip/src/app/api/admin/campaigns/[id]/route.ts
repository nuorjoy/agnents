import { adminSendOrEdit, adminRemove } from "@/server/domains/campaigns/controller";

export const dynamic = "force-dynamic";

/**
 * /api/admin/campaigns/[id] — one campaign.
 *
 * ROUND 165 — the handler bodies moved into the campaigns domain
 * (src/server/domains/campaigns/controller.ts); this file is a thin
 * delegation (route → controller → service → repository).
 *
 * THE SEND PATH (PATCH { action: "send" }) is a CLAIM: the draft
 * transitions to "sending" (CAS — one concurrent sender wins) and the
 * response returns immediately. The durable dispatcher enqueues every
 * audience subscriber as a per-recipient EmailLog row (keyset cursor
 * pagination — NO truncation at any list size), delivers in bounded
 * batches with retries + dead-lettering, and stamps "sent" ONLY when
 * every per-recipient delivery reached a terminal state.
 */

/**
 * PATCH — two guarded operations (super/admin):
 *  - { action: "send" } : claim the draft for background dispatch;
 *  - { subject, body }  : edit a draft in place.
 * Returns 409 when the target is not a draft (or is mid-dispatch).
 */
export const PATCH = adminSendOrEdit;

/** DELETE — remove a draft or an archived sent record (audited; a
 *  mid-flight "sending" campaign refuses with 409). */
export const DELETE = adminRemove;
