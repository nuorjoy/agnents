import { NextResponse } from "next/server";
import { z } from "zod";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { addBannedIp, listBannedIps, type BannedIpRecord } from "@/lib/server/ip-ban";

export const dynamic = "force-dynamic";

/**
 * ROUND 158 (security) — /api/admin/security/ip-ban — the platform-wide IP
 * banlist surface (the directive's strict "حظر، سماح" control).
 *
 * The list is enforced by BOTH login routes (Super Admin + tenant
 * dashboard) BEFORE any password verification — a banned IP cannot sign in
 * to either surface. The list lives on the singleton PlatformSetting row
 * (bannedIpsJson), rides the platform-settings TTL cache, and is mutated
 * only through this super-admin-only route.
 *
 *   • GET  → { ips: BannedIpRecord[] }   (super only)
 *   • POST → { ips: BannedIpRecord[] }   body { ip: string, note?: string }
 *
 * Mutations are STRICT-AUDITED with their own action name (security.ipban)
 * so a ban/unban never hides inside a generic settings row; the audit meta
 * records the IP itself (it is the actionable operational signal, not PII).
 */
const addSchema = z.strictObject({
  ip: z.string().trim().min(1).max(64),
  note: z.string().trim().max(120).optional(),
});

export async function GET() {
  const guard = await requireAdmin(["super"]);
  if (guard instanceof NextResponse) return guard;
  try {
    const ips = await listBannedIps();
    return NextResponse.json({ ips });
  } catch (error) {
    console.error("GET /api/admin/security/ip-ban failed:", error);
    return NextResponse.json({ error: "Failed to load the IP banlist" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const guard = await requireAdmin(["super"], req);
  if (guard instanceof NextResponse) return guard;

  const body = await readJson(req);
  if (!body.ok) return body.response;
  const parsed = addSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: "A valid IP address is required" }, { status: 400 });
  }

  try {
    const ips: BannedIpRecord[] = await addBannedIp(parsed.data.ip, parsed.data.note);
    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "security.ipban",
      targetLabel: "platform IP banlist",
      meta: {
        action: "add",
        ip: ips.find((r) => r.ip === parsed.data.ip)?.ip ?? parsed.data.ip,
        count: String(ips.length),
      },
    });
    return NextResponse.json({ ips });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed to add the IP";
    console.error("POST /api/admin/security/ip-ban failed:", error);
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
