import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { removeBannedIp, type BannedIpRecord } from "@/lib/server/ip-ban";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ ip: string }> };

/**
 * ROUND 158 (security) — DELETE /api/admin/security/ip-ban/[ip] — remove
 * an IP from the platform banlist (the directive's "سماح" / allow action).
 *
 * The path segment is the raw IP (URL-encoded by the client). Idempotent:
 * removing a missing IP returns the current list unchanged.
 */
export async function DELETE(_req: Request, { params }: RouteContext) {
  const guard = await requireAdmin(["super"], _req);
  if (guard instanceof NextResponse) return guard;

  const { ip } = await params;
  /* decodeURIComponent handles the URL-encoded forms the client emits
   * (dotted quads are safe, but IPv6 literals arrive %5B…%5D-bracketed). */
  const rawIp = decodeURIComponent(ip ?? "");
  if (!rawIp) {
    return NextResponse.json({ error: "An IP address is required" }, { status: 400 });
  }

  try {
    const ips: BannedIpRecord[] = await removeBannedIp(rawIp);
    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "security.ipban",
      targetLabel: "platform IP banlist",
      meta: {
        action: "remove",
        ip: rawIp,
        count: String(ips.length),
      },
    });
    return NextResponse.json({ ips });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed to remove the IP";
    console.error("DELETE /api/admin/security/ip-ban/[ip] failed:", error);
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
