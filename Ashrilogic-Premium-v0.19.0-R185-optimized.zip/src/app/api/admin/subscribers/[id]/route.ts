import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { readAdminEmail, sealAdminSection, zodError } from "@/lib/server/instance-mapper";
import { requireAdmin, hashPassword } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { revokeAllSessions } from "@/lib/server/sessions";
import { computeEntitlement } from "@/lib/server/entitlement";
import { EMAIL_RE, PASSWORD_RE } from "@/lib/validation";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * ROUND 81 — Super-Admin subscriber governance API.
 *
 * PATCH /api/admin/subscribers/[id] — precise, audited platform management
 * of a subscriber's IDENTITY and ACCESS from the console (requires the
 * managing tier: super/admin — mirroring every other subscriber lever):
 *
 *   { action: "profile", orgName?, adminEmail?, adminName?, phone? }
 *       Deep-merges the org/admin sections. An email change re-seals
 *       adminJson AND flips its HMAC blind index ATOMICALLY (login + "my
 *       systems" resolve by the index — see /api/instances/[id] PATCH for
 *       the consistency contract this mirrors).
 *
 *   { action: "password", password }
 *       Rotates the workspace password (Argon2id), bumps the session epoch
 *       and revokes every live workspace session — the console-side twin
 *       of the owner's proof-of-knowledge rotation.
 *
 *   { action: "ban", kind: "temporary", until: ISO, reason? }
 *       Suspends the workspace until an exact instant (self-lifting — the
 *       entitlement engine computes it live; no scheduler).
 *
 *   { action: "ban", kind: "permanent", reason? }
 *       Suspends the workspace until the platform lifts it.
 *
 *   { action: "unban" }
 *       Lifts any active ban instantly (everything resumes on the next
 *       request — login, APIs, public site, store).
 *
 * Every action writes an audit row (actor = the managing admin). Ban
 * actions additionally kill outstanding sessions immediately.
 */

const reasonSchema = z
  .string()
  .trim()
  .max(280)
  .transform((v) => (v.length === 0 ? null : v))
  .nullable()
  .optional();

const subscriberPatchSchema = z.discriminatedUnion("action", [
  z.object({
    action: z.literal("profile"),
    orgName: z.string().trim().min(2).max(120).optional(),
    adminName: z.string().trim().min(2).max(120).optional(),
    adminEmail: z.string().trim().toLowerCase().max(254).optional(),
    phone: z.string().trim().max(24).optional(),
  }),
  z.object({
    action: z.literal("password"),
    password: z.string().min(8).max(128),
  }),
  /* one ban variant (kind carries the flavor — zod discriminated unions
   * cannot host two members with the same discriminator value); the refine
   * enforces the temporary flavor's `until` requirement */
  z
    .object({
      action: z.literal("ban"),
      kind: z.enum(["temporary", "permanent"]),
      until: z.string().datetime({ offset: true }).optional(),
      reason: reasonSchema,
    })
    .refine((v) => v.kind !== "temporary" || typeof v.until === "string", {
      message: "until (ISO) is required for a temporary ban",
    }),
  z.object({
    action: z.literal("unban"),
  }),
]);

/** Read + validate the stored org/admin sections (fail-soft mirrors of the
 *  mapper's read schemas — the admin console edits real live rows). */
function readSections(orgJson: string, adminJson: string) {
  let org: { name?: string; phone?: string } = {};
  let admin: { name?: string; email?: string; role?: string; twoFA?: boolean; avatarUrl?: string | null } = {};
  try {
    org = JSON.parse(orgJson) as typeof org;
  } catch {
    /* corrupt orgJson — the merge below still writes a clean section */
  }
  try {
    const parsed = JSON.parse(adminJson) as { email?: unknown };
    admin = parsed as typeof admin;
    /* the login email is SEALED — decrypt for the merge (re-sealed below) */
    if (typeof parsed.email === "string" && parsed.email.includes(":")) {
      admin.email = readAdminEmail(adminJson);
    }
  } catch {
    /* corrupt adminJson */
  }
  return { org, admin };
}

export async function PATCH(req: Request, { params }: RouteContext) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const { id } = await params;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = subscriberPatchSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const data = parsed.data;

  try {
    const current = await db.instance.findUnique({
      where: { id },
      select: {
        id: true,
        systemId: true,
        orgJson: true,
        adminJson: true,
        packageId: true,
        trialEndsAt: true,
        planActivatedAt: true,
        planCycle: true,
        planExpiresAt: true,
        featureOverridesJson: true,
        bannedPermanently: true,
        bannedUntil: true,
        bannedReason: true,
        bannedAt: true,
        sessionVersion: true,
        package: { select: { capabilitiesJson: true, nameAr: true, nameEn: true } },
      },
    });
    if (!current) {
      return NextResponse.json({ error: "Subscriber not found" }, { status: 404 });
    }

    const orgLabel = (() => {
      try {
        return (JSON.parse(current.orgJson) as { name?: string }).name ?? current.systemId;
      } catch {
        return current.systemId;
      }
    })();

    /* ---------------------- profile (identity) edit ---------------------- */
    if (data.action === "profile") {
      if (
        data.orgName === undefined &&
        data.adminName === undefined &&
        data.adminEmail === undefined &&
        data.phone === undefined
      ) {
        return NextResponse.json({ error: "Nothing to update" }, { status: 400 });
      }
      if (data.adminEmail !== undefined && !EMAIL_RE.test(data.adminEmail)) {
        return NextResponse.json({ error: "Invalid admin email" }, { status: 400 });
      }
      if (data.phone !== undefined && data.phone.length > 0 && !/^\+?[0-9\s().-]{6,24}$/.test(data.phone)) {
        return NextResponse.json({ error: "Invalid phone number" }, { status: 400 });
      }

      const { org, admin } = readSections(current.orgJson, current.adminJson);
      const nextOrg = {
        ...org,
        ...(data.orgName !== undefined ? { name: data.orgName } : {}),
        ...(data.phone !== undefined ? { phone: data.phone } : {}),
      };
      const nextAdmin = {
        name: data.adminName ?? admin.name ?? "Administrator",
        email: data.adminEmail ?? admin.email ?? "",
        role: admin.role === "manager" ? ("manager" as const) : ("owner" as const),
        twoFA: admin.twoFA === true,
        avatarUrl: admin.avatarUrl ?? null,
      };
      const emailChanged =
        data.adminEmail !== undefined &&
        nextAdmin.email.trim().toLowerCase() !== String(admin.email ?? "").trim().toLowerCase();

      const sealed = sealAdminSection(nextAdmin);

      const row = await db.instance.update({
        where: { id },
        data: {
          orgJson: JSON.stringify(nextOrg),
          adminJson: sealed.adminJson,
          /* email changed → the blind index flips in the SAME write (login +
             "my systems" resolve by the index — never a stale half-state) */
          ...(emailChanged ? { adminEmailIndex: sealed.adminEmailIndex } : {}),
        },
      });

      await logAudit({
        actorType: "admin",
        actorId: guard.user.id,
        actorName: guard.user.username,
        action: "instance.update",
        targetLabel: orgLabel,
        meta: {
          surface: "admin-subscribers",
          ...(data.orgName !== undefined ? { orgName: "changed" } : {}),
          ...(data.phone !== undefined ? { phone: "changed" } : {}),
          ...(data.adminName !== undefined ? { adminName: "changed" } : {}),
          ...(emailChanged ? { email: "changed" } : {}),
        },
      });

      return NextResponse.json({
        ok: true,
        entitlement: computeEntitlement(row),
        changed: {
          orgName: data.orgName !== undefined,
          phone: data.phone !== undefined,
          adminName: data.adminName !== undefined,
          adminEmail: emailChanged,
        },
      });
    }

    /* ---------------------- password rotation ---------------------- */
    if (data.action === "password") {
      if (!PASSWORD_RE.test(data.password)) {
        return NextResponse.json(
          { error: "Password must be at least 8 characters and include letters and digits" },
          { status: 400 }
        );
      }
      const row = await db.instance.update({
        where: { id },
        data: {
          passwordHash: hashPassword(data.password),
          /* bump the session epoch — every outstanding workspace token dies
           * instantly (the owner signs in with the new password) */
          sessionVersion: { increment: 1 },
        },
      });
      await revokeAllSessions("instance", id);

      await logAudit({
        actorType: "admin",
        actorId: guard.user.id,
        actorName: guard.user.username,
        action: "instance.password",
        targetLabel: orgLabel,
        meta: { surface: "admin-subscribers" },
      });

      return NextResponse.json({ ok: true, entitlement: computeEntitlement(row) });
    }

    /* ---------------------- ban / unban (governance) ---------------------- */
    if (data.action === "ban") {
      const untilDate = data.kind === "temporary" && data.until ? new Date(data.until) : null;
      if (data.kind === "temporary") {
        if (!untilDate || Number.isNaN(untilDate.getTime())) {
          return NextResponse.json({ error: "Invalid ban end date" }, { status: 400 });
        }
        if (untilDate.getTime() <= Date.now() + 60_000) {
          return NextResponse.json(
            { error: "The temporary ban must end at least one minute from now" },
            { status: 400 }
          );
        }
      }

      const row = await db.instance.update({
        where: { id },
        data: {
          bannedPermanently: data.kind === "permanent",
          bannedUntil: data.kind === "temporary" ? untilDate : null,
          bannedReason: data.reason ?? null,
          bannedAt: new Date(),
          /* kill every live workspace session immediately (belt-and-braces —
           * requireInstanceAccess re-checks the ban on every request too) */
          sessionVersion: { increment: 1 },
        },
      });
      await revokeAllSessions("instance", id);

      await logAudit({
        actorType: "admin",
        actorId: guard.user.id,
        actorName: guard.user.username,
        action: "instance.ban",
        targetLabel: orgLabel,
        meta: {
          kind: data.kind,
          ...(data.kind === "temporary" && untilDate ? { until: untilDate.toISOString() } : {}),
          ...(data.reason ? { reason: data.reason.slice(0, 160) } : {}),
        },
      });

      return NextResponse.json({ ok: true, entitlement: computeEntitlement(row) });
    }

    /* action === "unban" */
    const wasBanned =
      current.bannedPermanently ||
      (current.bannedUntil !== null && current.bannedUntil.getTime() > Date.now());
    if (!wasBanned) {
      return NextResponse.json({ error: "This workspace is not banned" }, { status: 400 });
    }
    const row = await db.instance.update({
      where: { id },
      data: {
        bannedPermanently: false,
        bannedUntil: null,
        bannedReason: null,
        bannedAt: null,
      },
    });

    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "instance.unban",
      targetLabel: orgLabel,
      meta: { previous: current.bannedPermanently ? "permanent" : "temporary" },
    });

    return NextResponse.json({ ok: true, entitlement: computeEntitlement(row) });
  } catch (error) {
    console.error(`PATCH /api/admin/subscribers/[id] failed:`, error);
    return NextResponse.json({ error: "Failed to update subscriber" }, { status: 500 });
  }
}
