import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/admin-session";
import { sendWeeklyReport } from "@/lib/server/platform-notifications";

export const dynamic = "force-dynamic";

/**
 * POST /api/admin/notifications/weekly — the console's «إرسال التقرير
 * الآن» button (ROUND 89). Builds and delivers THIS ISO week's platform
 * report through the exact weekly-digest pipeline (aggregation → mailer →
 * support inbox → NotificationLog with the week idempotency key). An
 * explicit operator action: it runs even when the «التقرير الأسبوعي»
 * toggle is off (the operator is choosing to send), but still refuses to
 * double-send a week that already has a row — same law as the scheduler.
 */
export async function POST(req: Request) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  try {
    const result = await sendWeeklyReport({ manual: true });
    return NextResponse.json(result);
  } catch (error) {
    console.error("POST /api/admin/notifications/weekly failed:", error);
    return NextResponse.json({ error: "Failed to send weekly report" }, { status: 500 });
  }
}
