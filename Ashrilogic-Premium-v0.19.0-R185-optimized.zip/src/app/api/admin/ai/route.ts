import { NextResponse } from "next/server";
import { z } from "zod";
import { zodError } from "@/lib/server/instance-mapper";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { getAiSettingsDTO, applyAiSettingsPatch } from "@/lib/server/ai-settings";

export const dynamic = "force-dynamic";

/**
 * ROUND 41 — Super-Admin AI/API control panel.
 *
 * GET   — the panel state as AiSettingsDTO. The sealed provider key NEVER
 *         leaves the server: the DTO exposes `hasApiKey` only.
 * PATCH — partial update: master switch, model label, monthly quota, a NEW
 *         provider key (sealed with AES-256-GCM before it touches storage)
 *         and key rotation (drops the stored one).
 *
 * Hardening: SUPER-ONLY role gate on both verbs, same-origin guard (req is
 * passed to requireAdmin on the mutation), bounded body read, strict Zod
 * validation, audit row listing only the CHANGED field names (never the
 * key itself).
 */

const aiSettingsUpdateSchema = z.object({
  enabled: z.boolean().optional(),
  model: z.string().trim().min(1).max(60).optional(),
  monthlyQuota: z.number().int().min(0).max(100_000).optional(),
  apiKey: z.string().trim().min(10).max(500).optional(),
  rotateKey: z.boolean().optional(),
});

export async function GET() {
  const guard = await requireAdmin(["super"]);
  if (guard instanceof NextResponse) return guard;

  try {
    return NextResponse.json(await getAiSettingsDTO());
  } catch (error) {
    console.error("GET /api/admin/ai failed:", error);
    return NextResponse.json({ error: "Failed to load AI settings" }, { status: 500 });
  }
}

export async function PATCH(req: Request) {
  const guard = await requireAdmin(["super"], req);
  if (guard instanceof NextResponse) return guard;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = aiSettingsUpdateSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const patch = parsed.data;

  /* an empty patch is a no-op request — reject instead of auditing noise */
  if (Object.keys(patch).length === 0) {
    return NextResponse.json({ error: "No settings provided" }, { status: 400 });
  }

  try {
    const dto = await applyAiSettingsPatch(patch);

    /* audit ONLY the changed field names — the key value never enters the
     * trail (its presence/rotation is the security-relevant fact) */
    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "admin.aiSettings",
      targetLabel: "ai/api control panel",
      meta: Object.keys(patch).reduce<Record<string, string>>((acc, key) => {
        if (key === "apiKey") acc[key] = "sealed";
        else if (key === "rotateKey") acc[key] = patch.rotateKey ? "rotated" : "kept";
        else acc[key] = String((patch as Record<string, unknown>)[key]);
        return acc;
      }, {}),
    });

    return NextResponse.json(dto);
  } catch (error) {
    console.error("PATCH /api/admin/ai failed:", error);
    return NextResponse.json({ error: "Failed to save AI settings" }, { status: 500 });
  }
}
