import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";

export const dynamic = "force-dynamic";

/**
 * ROUND 137 — /api/admin/security-policy — the SPLIT security-policy
 * surface (Phase 2, finding 3).
 *
 * History: the platform 2FA toggle (`PlatformSetting.twoFARequired`) used
 * to ride the general /api/admin/settings PATCH — which forced that ENTIRE
 * endpoint into the MFA-enrollment allowlist (a super admin with no second
 * factor had to reach the toggle through it). A broad endpoint exemption
 * where a narrow capability is intended is a policy hole: EVERY settings
 * mutation (mail config, payments, identity…) inherited the no-MFA escape.
 *
 * This route is the narrow replacement:
 *   • SUPER-ADMIN ONLY (the policy is a platform-wide security control);
 *   • an EXPLICIT FIELD ALLOWLIST — twoFARequired today, the recovery/
 *     security-policy controls that grow here tomorrow; every other field
 *     is refused, not silently dropped;
 *   • STRICT AUDIT — its own `security-policy.update` action with before/
 *     after values (a security-control change must never hide inside a
 *     generic settings row);
 *   • MFA-exempt BY DESIGN (the documented break-glass: a super admin
 *     must always be able to reach the 2FA toggle itself — mirroring how
 *     GitHub keeps the policy owner unlocked). /api/admin/settings is no
 *     longer exempt: its mutations enforce MFA like every other surface.
 *
 * GET returns the security-policy view (super only — it is an operator
 * surface, and the settings GET already exposes the flag read-only to
 * admins for display parity).
 */

/** The explicit, narrow mutation allowlist for this route. STRICT shape:
 *  any foreign field refuses the WHOLE payload (a security-policy write
 *  is never partially honored — no silent field stripping). */
const securityPolicyUpdateSchema = z
  .strictObject({
    twoFARequired: z.boolean(),
  })
  .partial()
  .refine((data) => Object.keys(data).length > 0, {
    message: "At least one security-policy field must be provided",
  });

export async function GET() {
  const guard = await requireAdmin(["super"]);
  if (guard instanceof NextResponse) return guard;

  try {
    const row = await db.platformSetting.findUnique({
      where: { id: "global" },
      select: { twoFARequired: true },
    });
    return NextResponse.json({ twoFARequired: row?.twoFARequired === true });
  } catch (error) {
    console.error("GET /api/admin/security-policy failed:", error);
    return NextResponse.json({ error: "Failed to load the security policy" }, { status: 500 });
  }
}

export async function PATCH(req: Request) {
  const guard = await requireAdmin(["super"], req);
  if (guard instanceof NextResponse) return guard;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = securityPolicyUpdateSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Only the documented security-policy fields may be changed here" },
      { status: 400 }
    );
  }

  try {
    const before = await db.platformSetting.findUnique({
      where: { id: "global" },
      select: { twoFARequired: true },
    });
    const row = await db.platformSetting.update({
      where: { id: "global" },
      data: parsed.data,
    });
    /* STRICT AUDIT — a security-control flip records the operator, the
     * before→after transition and the route identity. The action name is
     * dedicated (never mixed into settings.update). */
    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "security-policy.update",
      targetLabel: "platform security policy",
      meta: {
        ...("twoFARequired" in parsed.data
          ? {
              twoFARequired: `${before?.twoFARequired === true} → ${row.twoFARequired === true}`,
            }
          : {}),
      },
    });
    return NextResponse.json({ twoFARequired: row.twoFARequired === true });
  } catch (error) {
    console.error("PATCH /api/admin/security-policy failed:", error);
    return NextResponse.json({ error: "Failed to save the security policy" }, { status: 500 });
  }
}
