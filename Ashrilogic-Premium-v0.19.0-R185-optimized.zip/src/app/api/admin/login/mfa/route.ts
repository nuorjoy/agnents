import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toAdminUserDTO } from "@/lib/server/admin-mapper";
import {
  sessionTtlMs,
  setSessionCookie,
  verifyMfaTicket,
} from "@/lib/server/admin-session";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { originViolation } from "@/lib/server/origin-guard";
import { logAudit, maskEmail } from "@/lib/server/audit";

/* usernames pass through; email-shaped handles are masked for the trail */
const EMAIL_SHAPE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function auditActorName(username: string): string {
  return EMAIL_SHAPE.test(username) ? maskEmail(username) : username;
}
import { readJson } from "@/lib/server/http";
import { verifyMfaLogin } from "@/lib/server/mfa";

export const dynamic = "force-dynamic";

/** Second-factor attempt throttling: 8 tries / 5 minutes per IP. */
const MFA_RULE = { limit: 8, windowMs: 5 * 60 * 1000 };
/** ROUND 146 — per-ACCOUNT second-factor budget (fail closed). The per-IP
 *  rule alone let a password-compromised account grind the 6-digit TOTP
 *  space across rotating IPs within the 5-min ticket TTL (~8k distributed
 *  guesses ≈ 2.4% hit chance per window). The account rule caps the grind
 *  at 8 attempts TOTAL per window no matter how many IPs deliver them —
 *  the exact LOGIN_USER_RULE idiom the password step already carries. */
const MFA_USER_RULE = { limit: 8, windowMs: 5 * 60 * 1000 };

/**
 * ROUND 45 — POST /api/admin/login/mfa — finish the two-step admin login.
 *
 * Body: { ticket, code } where `ticket` is the short-lived HMAC ticket from
 * POST /api/admin/login (password already verified) and `code` is a live
 * TOTP code or a single-use backup code. On success the real session cookie
 * is issued (with its SessionRecord row).
 *
 * Hardening: origin guard, bounded body, durable rate limit (fail closed),
 * ticket epoch check (a password change mid-flight kills outstanding
 * tickets), MFA row re-read (disenrollment mid-flight kills the challenge),
 * uniform 401s (no oracle which factor failed), audited completions.
 */
export async function POST(req: Request) {
  const violation = originViolation(req);
  if (violation) return violation;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const ticket = (body.data as { ticket?: unknown }).ticket;
  const code = (body.data as { code?: unknown }).code;
  if (
    typeof ticket !== "string" ||
    typeof code !== "string" ||
    !ticket ||
    !/^[0-9A-Za-z-]{4,20}$/.test(code.trim())
  ) {
    return NextResponse.json({ error: "Invalid verification request" }, { status: 400 });
  }

  const ip = clientIp(req);
  if (await rateLimited(`admin-mfa:${ip}`, MFA_RULE, { failClosed: true })) {
    return tooManyRequests(MFA_RULE, { error: "Too many verification attempts, please try again later" });
  }

  const payload = verifyMfaTicket(ticket);
  if (!payload) {
    return NextResponse.json(
      { error: "Verification session expired — sign in again" },
      { status: 401 }
    );
  }

  try {
    /* ROUND 87 — a trashed (soft-deleted) admin account never finishes 2FA
     * (uniform 401 like every other dead-session path). */
    const row = await db.adminUser.findUnique({ where: { id: payload.uid, deletedAt: null } });
    if (!row || !row.active || (row.sessionVersion ?? 0) !== payload.ver) {
      return NextResponse.json(
        { error: "Verification session expired — sign in again" },
        { status: 401 }
      );
    }

    /* ROUND 146 — the account-scoped budget, AFTER the ticket/row prove
     * WHICH account is grinding, BEFORE the code is checked. Refusals use
     * the same message the IP rule serves (one uniform 429 shape). */
    if (await rateLimited(`admin-mfa-acct:${row.id}`, MFA_USER_RULE, { failClosed: true })) {
      return tooManyRequests(MFA_USER_RULE, {
        error: "Too many verification attempts, please try again later",
      });
    }

    const ok = await verifyMfaLogin("admin", row.id, code.trim());
    if (!ok) {
      await logAudit({
        actorType: "admin",
        actorId: row.id,
        actorName: auditActorName(row.username),
        action: "admin.loginFailed",
        meta: { mfa: "invalid-code" },
      });
      return NextResponse.json({ error: "Incorrect verification code" }, { status: 401 });
    }

    const updated = await db.adminUser.update({
      where: { id: row.id },
      data: { lastLoginAt: new Date() },
    });

    await setSessionCookie(row.id, row.sessionVersion ?? 0, await sessionTtlMs(), {
      ip,
      userAgent: req.headers.get("user-agent"),
    });
    await logAudit({
      actorType: "admin",
      actorId: row.id,
      actorName: auditActorName(row.username),
      action: "admin.login",
      meta: { mfa: "passed" },
    });
    return NextResponse.json(toAdminUserDTO(updated));
  } catch (error) {
    console.error("POST /api/admin/login/mfa failed:", error);
    return NextResponse.json({ error: "Verification failed" }, { status: 500 });
  }
}
