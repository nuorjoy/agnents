import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { seedAdminDefaults, toAdminUserDTO } from "@/lib/server/admin-mapper";
import { blindIndex } from "@/lib/server/crypto-vault";
import {
  checkPassword,
  hashPassword,
  issueMfaTicket,
  needsPasswordUpgrade,
  setSessionCookie,
  sessionTtlMs,
} from "@/lib/server/admin-session";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { isIpBanned } from "@/lib/server/ip-ban";
import { originViolation } from "@/lib/server/origin-guard";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { verifyPasswordArgon2id, hashPasswordArgon2id } from "@/lib/server/crypto-vault";
import { isMfaEnabled } from "@/lib/server/mfa";
import { hasCredentials } from "@/lib/server/webauthn";

export const dynamic = "force-dynamic";

/** Login-attempt throttling: 10 tries per 10 minutes per IP + username. */
const LOGIN_RULE = { limit: 10, windowMs: 10 * 60 * 1000 };
/**
 * ROUND 37 (task 3-a) — per-IP AGGREGATE cap across ALL usernames.
 * Credential-stuffing sweeps rotate a different username on every request so
 * the per-username key never trips; 30 attempts / 10 min per source IP
 * throttles the sweep itself. Both rules fail CLOSED — a durable-store
 * outage refuses the request instead of failing open on credentials.
 */
const LOGIN_IP_RULE = { limit: 30, windowMs: 10 * 60 * 1000 };
/**
 * ROUND 145 — per-ACCOUNT cap (the instance-login twin's idiom,
 * src/app/api/instances/auth/login/route.ts `inst-login-email`): the
 * ip+username key resets with every rotated source IP, so a distributed
 * guesser gets a FRESH per-ip+username budget on every request. The
 * account-scoped key caps the guesses on ONE account regardless of the
 * source. 8 / 10 min, fail-closed.
 */
const LOGIN_USER_RULE = { limit: 8, windowMs: 10 * 60 * 1000 };

/* ROUND 36 — timing equalizer: unknown usernames burn one Argon2id verify
   so response times cannot distinguish existing accounts. */
let timingHash: string | null = null;
function burnTimingEqualizer(password: string): void {
  timingHash ??= hashPasswordArgon2id("ashrilogic-admin-timing-equalizer");
  verifyPasswordArgon2id(password, timingHash);
}

/** Email-shaped values are PII — mask them for the audit trail; plain
    handles ("sarah.super") pass through so the trail stays correlatable. */
const EMAIL_SHAPE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function auditActorName(username: string): string {
  return EMAIL_SHAPE.test(username) ? maskEmail(username) : username;
}

/**
 * POST /api/admin/login — real server-side credential check.
 *
 * ROUND 83 — the identifier accepts the USERNAME **or the registered EMAIL**:
 * email-shaped values resolve through the sealed-email blind index
 * (HMAC-SHA256, case-insensitive) instead of the username column, so
 * "admin" and "admin@ashrilogic.com" open the same account. Lookup order is
 * username-first (deterministic when a username string collides with another
 * account's email — not possible for the seeded set, but explicit anyway).
 *
 * Verifies the password against the AdminUser table (Argon2id records; legacy
 * SHA-256 digests verify then transparently re-hash on login — round 35),
 * bootstraps a password hash for freshly seeded accounts on their first
 * login, refreshes `lastLoginAt`, and drops an HTTP-only session cookie that
 * every /api/admin/* handler verifies (see `requireAdmin`).
 */
export async function POST(req: Request) {
  const violation = originViolation(req);
  if (violation) return violation;

  /* ROUND 37 (task 3-a) — bounded body read (declared + streamed caps) in
     place of the unbounded req.json(). */
  const body = await readJson(req);
  if (!body.ok) return body.response;

  const username = (body.data as { username?: unknown }).username;
  const password = (body.data as { password?: unknown }).password;
  if (typeof username !== "string" || typeof password !== "string" || !username.trim() || !password) {
    return NextResponse.json(
      { error: "username and password are required" },
      { status: 400 }
    );
  }
  /* Bounded BEFORE it reaches the durable rate-limit key: an oversized
     username would otherwise persist megabytes into the SQLite limiter
     (the body cap alone allows 1.5 MB per request). Real handles are
     far shorter than any account field the schema admits. */
  if (username.length > 64 || password.length > 72) {
    return NextResponse.json({ error: "Invalid username or password" }, { status: 401 });
  }

  const ip = clientIp(req);
  /* ROUND 158 (security) — platform-wide IP banlist: the FIRST guard after
   * the request is parsed. A banned IP cannot sign into the Super Admin
   * console (or any tenant dashboard — see /api/instances/auth/login) —
   * refused BEFORE any rate-limit accounting, BEFORE any password
   * verification, BEFORE any timing equalizer. The check reads through the
   * cached platform settings (10s propagation). Fail-open when the store
   * is unavailable: the ban never locks EVERYONE out, and the rate limiter
   * + password check still apply. */
  if (await isIpBanned(ip)) {
    await logAudit({
      actorType: "admin",
      actorName: auditActorName(username.trim()),
      action: "admin.loginBlocked",
      meta: { reason: "ip-banned" },
    });
    return NextResponse.json(
      { error: "This IP address is blocked", code: "IP_BLOCKED" },
      { status: 403 }
    );
  }
  /* ROUND 146 — the per-account throttle keys carry the account handle's
   * BLIND INDEX, never the plaintext: email-shaped handles would otherwise
   * persist as PII in the durable RateLimitHit table (which rides every
   * sealed backup) — the exact discipline the instance-login twins and the
   * emailIndex lookup below already keep. Same limiter signature, same
   * failClosed posture, same message — only the key material changes. */
  const accountKey = blindIndex(username.trim()) ?? "";
  if (await rateLimited(`admin-login-ip:${ip}`, LOGIN_IP_RULE, { failClosed: true })) {
    return tooManyRequests(LOGIN_IP_RULE, { error: "Too many sign-in attempts, please try again later" });
  }
  if (await rateLimited(`admin-login:${ip}:${accountKey}`, LOGIN_RULE, { failClosed: true })) {
    return tooManyRequests(LOGIN_RULE, { error: "Too many sign-in attempts, please try again later" });
  }
  /* ROUND 145 — the account-only budget (mirrors the instance login's
   * inst-login-email rule: same limiter call signature, same failClosed
   * posture, same error mapping to 429 — both rules applied). */
  if (await rateLimited(`admin-login-user:${accountKey}`, LOGIN_USER_RULE, { failClosed: true })) {
    return tooManyRequests(LOGIN_USER_RULE, { error: "Too many sign-in attempts for this account, please try again later" });
  }

  try {
    // make sure a fresh database has the seeded accounts before checking
    await seedAdminDefaults(db);

    const identifier = username.trim();
    /* ROUND 83 — username OR email resolution: email-shaped identifiers go
       through the blind index (sealed-email equality without decryption);
       plain handles keep the exact username path.
       ROUND 87 — trashed (soft-deleted) admin accounts never sign in (their
       username/emailIndex are mangled to tombstones; the filter is the
       belt+suspenders — uniform 401, no oracle). */
    let row = await db.adminUser.findUnique({ where: { username: identifier, deletedAt: null } });
    if (!row && EMAIL_SHAPE.test(identifier)) {
      row = await db.adminUser.findUnique({
        where: { emailIndex: blindIndex(identifier) ?? "", deletedAt: null },
      });
    }
    if (!row) {
      /* ROUND 36 — uniform failure + timing equalizer (no username
         enumeration via body OR response time) */
      burnTimingEqualizer(password);
      await logAudit({ actorType: "admin", actorName: auditActorName(username.trim()), action: "admin.loginFailed" });
      return NextResponse.json({ error: "Invalid username or password" }, { status: 401 });
    }
    if (!row.active) {
      /* ROUND 36 — disabled accounts respond with the SAME generic 401 as
         bad passwords (the distinct 403 revealed account existence) */
      burnTimingEqualizer(password);
      await logAudit({
        actorType: "admin",
        actorId: row.id,
        actorName: auditActorName(row.username),
        action: "admin.loginFailed",
        meta: { disabled: "true" },
      });
      return NextResponse.json({ error: "Invalid username or password" }, { status: 401 });
    }

    if (!checkPassword(password, row.passwordHash)) {
      await logAudit({ actorType: "admin", actorId: row.id, actorName: auditActorName(row.username), action: "admin.loginFailed" });
      return NextResponse.json({ error: "Invalid username or password" }, { status: 401 });
    }

    /* ROUND 45 — two-factor gate: when TOTP MFA is enrolled the password
     * alone is NOT enough. A short-lived HMAC ticket (scope "admin-mfa",
     * 5 min, epoch-bound) is returned instead of a session; the finish step
     * is POST /api/admin/login/mfa. Passkeys enrolled alongside are offered
     * as the challenge alternative. */
    if (await isMfaEnabled("admin", row.id)) {
      const passkeys = await hasCredentials("admin", row.id);
      await logAudit({
        actorType: "admin",
        actorId: row.id,
        actorName: auditActorName(row.username),
        action: "admin.login",
        meta: { mfa: "challenge" },
      });
      return NextResponse.json({
        mfaRequired: true,
        ticket: issueMfaTicket(row.id, row.sessionVersion ?? 0),
        passkeys,
        name: row.name,
      });
    }

    // bootstrap (seeded rows, NULL hash) + transparent legacy→Argon2id upgrade
    const data: { lastLoginAt: Date; passwordHash?: string } = {
      lastLoginAt: new Date(),
    };
    if (!row.passwordHash || needsPasswordUpgrade(row.passwordHash)) {
      data.passwordHash = hashPassword(password);
    }
    const updated = await db.adminUser.update({ where: { id: row.id }, data });

    await setSessionCookie(row.id, row.sessionVersion ?? 0, await sessionTtlMs(), {
      ip,
      userAgent: req.headers.get("user-agent"),
    });
    await logAudit({
      actorType: "admin",
      actorId: row.id,
      actorName: auditActorName(row.username),
      action: "admin.login",
    });
    /* ROUND 89 — the «إلزام المصادقة الثنائية» platform toggle: this admin
     * has NO second factor enrolled (no TOTP, no passkey) while the policy
     * is ON. The session is still issued (they must be able to REACH the
     * enrollment flow) but the response carries mfaEnrollRequired so the
     * console opens the enrollment gate, and requireAdmin enforces the
     * policy on every non-allowlisted admin API call. */
    const enforce2fa = await db.platformSetting
      .findUnique({ where: { id: "global" }, select: { twoFARequired: true } })
      .then((s) => s?.twoFARequired === true)
      .catch(() => false);
    const enrolled2fa = (await isMfaEnabled("admin", row.id)) || (await hasCredentials("admin", row.id));
    return NextResponse.json({
      ...toAdminUserDTO(updated),
      ...(enforce2fa && !enrolled2fa ? { mfaEnrollRequired: true } : {}),
    });
  } catch (error) {
    console.error("POST /api/admin/login failed:", error);
    return NextResponse.json({ error: "Login failed" }, { status: 500 });
  }
}
