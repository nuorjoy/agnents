import { adminUpdate, adminRemove } from "@/server/domains/promotions/controller";

export const dynamic = "force-dynamic";

/**
 * /api/admin/promotions/[id] — one promotion banner.
 *
 *  - PATCH  — update (super/admin; the window pair is validated against the
 *    MERGED row so a partial patch cannot produce startsAt ≥ endsAt;
 *    audited platform.promotionUpdate);
 *  - DELETE — remove (super/admin; audited platform.promotionDelete).
 */
export const PATCH = adminUpdate;

export const DELETE = adminRemove;
