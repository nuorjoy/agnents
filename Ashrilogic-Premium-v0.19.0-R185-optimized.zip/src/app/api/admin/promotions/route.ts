import { adminList, adminCreate } from "@/server/domains/promotions/controller";

export const dynamic = "force-dynamic";

/**
 * /api/admin/promotions — the Super-Admin promotion banner console
 * (ROUND 169, العروض الترويجية).
 *
 *   route.ts → domain controller → domain service → domain repository
 *
 *  - GET  — the archive (?status=live|upcoming|expired|all, bounded);
 *  - POST — create (super/admin; zod-validated bilingual copy + theme +
 *    in-app CTA href + strictly-ordered future window; audited
 *    platform.promotionCreate).
 */
export const GET = adminList;

export const POST = adminCreate;
