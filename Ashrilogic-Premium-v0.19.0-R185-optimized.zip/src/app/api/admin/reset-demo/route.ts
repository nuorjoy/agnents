import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { seedAdminDefaults, seedDemoInstances, rearmSeedMemos } from "@/lib/server/admin-mapper";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";

export const dynamic = "force-dynamic";

/** Destructive wipe + reseed throttling (round 36). */
const RESET_RULE = { limit: 4, windowMs: 10 * 60 * 1000 };

/**
 * POST /api/admin/reset-demo — delete every demo instance and re-seed the
 * backdated showcase subscribers (plan assignments included). Real (non-demo)
 * instances are untouched.
 *
 * ROUND 36: SUPER-only (destructive platform operation — was admin-allowed),
 * rate-limited, transactional (demo ticket cleanup + wipe land atomically),
 * and re-arms the seeding memos so the next requests observe the fresh state.
 */
export async function POST(req: Request) {
  /* ROUND 37 (task 3-a) — the demo-reset affordance must not exist in
     production: no auth probing, no rate-limit write, no error detail —
     the route answers 404 exactly like a non-existent endpoint. The gate
     mirrors the runtime secret guard: only development, test, or an
     explicit ALLOW_DEMO_SECRETS=1 opt-in may reach it — an unset or
     staging-labeled NODE_ENV keeps the route dead. */
  if (
    process.env.NODE_ENV !== "development" &&
    process.env.NODE_ENV !== "test" &&
    process.env.ALLOW_DEMO_SECRETS !== "1"
  ) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const guard = await requireAdmin(["super"], req);
  if (guard instanceof NextResponse) return guard;

  if (await rateLimited(`reset-demo:${clientIp(req)}`, RESET_RULE)) {
    return tooManyRequests(RESET_RULE, { error: "Too many reset requests — please wait before resetting again" });
  }

  try {
    /* collect demo ids first — SupportTicket.instanceId is a plain column
       (no FK cascade), so their tickets + storefront orders must be removed
       explicitly and atomically with the wipe.
       ROUND 87 — TRASHED (soft-deleted) demo rows are NOT hard-deleted here
       (hard delete is the trash engine's PURGE-only law); the wipe only
       clears LIVE demo rows, and the reseed counts live rows too. */
    const demoRows = await db.instance.findMany({
      where: { demo: true, deletedAt: null },
      select: { id: true },
    });
    const demoIds = demoRows.map((row) => row.id);

    const removed = await db.$transaction(async (tx) => {
      if (demoIds.length > 0) {
        await tx.supportTicket.deleteMany({ where: { instanceId: { in: demoIds } } });
        await tx.siteOrder.deleteMany({ where: { instanceId: { in: demoIds } } });
      }
      return tx.instance.deleteMany({ where: { demo: true, deletedAt: null } });
    });

    /* the wipe invalidated the once-guarded seeding state — re-arm so the
       reseed below actually runs inside THIS process */
    rearmSeedMemos();

    // re-seed: demo specs reference the default packages — ensure they exist
    await seedAdminDefaults(db);
    await seedDemoInstances(db);

    const seeded = await db.instance.count({ where: { demo: true, deletedAt: null } });
    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "instance.resetDemo",
      meta: { removed: String(removed.count), seeded: String(seeded) },
    });
    return NextResponse.json({ ok: true, removed: removed.count, seeded });
  } catch (error) {
    console.error("POST /api/admin/reset-demo failed:", error);
    return NextResponse.json({ error: "Failed to reset demo data" }, { status: 500 });
  }
}
