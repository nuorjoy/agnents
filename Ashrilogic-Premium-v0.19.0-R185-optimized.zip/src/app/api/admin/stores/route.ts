import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/server/admin-session";
import type { AdminStoreDTO, AdminStoresDTO } from "@/lib/types";
import type { Instance, ModuleRecord } from "@prisma/client";

export const dynamic = "force-dynamic";

/**
 * ROUND 46 — GET /api/admin/stores — the control panel's Stores view (F-8).
 *
 * Aggregates EVERY tenant storefront in one admin-guarded read:
 *  - which retail module powers the catalog (store-mapper priority) + currency
 *  - catalog stats derived live from the module records (products, low/out
 *    of stock, stock value, category count)
 *  - the full order pipeline (pending / active / completed / cancelled) and
 *    completed-order revenue per store
 *  - public-website state (published, views) so the panel shows whether the
 *    storefront is actually live
 *
 * No PII leaves this endpoint (org names + counters only), and the query is
 * bounded: instances ≤ 500, records ≤ 400/store, orders ≤ 1000/store.
 */

const INSTANCE_CAP = 500;
const RECORD_CAP = 400;

export async function GET() {
  const guard = await requireAdmin();
  if (guard instanceof NextResponse) return guard;

  try {
    /* ROUND 49 — N+1 elimination: the former per-instance record + order
       scans (2 queries × instance count — up to ~1,001 sequential round
       trips) became ONE window-capped record query + ONE grouped order
       aggregation, regardless of tenant count. The instance fetch is also
       column-narrowed: sealed/PII columns are never read for aggregation.
       ROUND 87 — TRASHED (soft-deleted) workspaces vanish from the Stores
       view (their products/orders no longer aggregate). */
    const instances = await db.instance.findMany({
      where: { deletedAt: null },
      orderBy: [{ createdAt: "desc" }],
      take: INSTANCE_CAP,
      select: {
        id: true,
        systemId: true,
        orgJson: true,
        modulesJson: true,
        createdAt: true,
        site: { select: { published: true, views: true } },
      },
    });

    const storeRows = instances.filter((row) => storeModuleId(row) !== null);
    const storeIds = storeRows.map((row) => row.id);

    /* ONE window-capped query preserves the per-store "newest 400 records"
       semantics exactly (ROW_NUMBER partitioned per instance + module).
       PostgreSQL: every identifier is QUOTED — the schema's camel-cased
       table/column names fold to lowercase when unquoted (SQLite was
       case-insensitive; PostgreSQL is not). */
    const recordRows = storeIds.length
      ? await db.$queryRaw<
          { instanceId: string; moduleId: string; dataJson: string; statusKey: string }[]
        >(Prisma.sql`
            SELECT "instanceId" AS "instanceId", "moduleId" AS "moduleId",
                   "dataJson" AS "dataJson", "statusKey" AS "statusKey"
            FROM (
              SELECT "instanceId", "moduleId", "dataJson", "statusKey",
                     ROW_NUMBER() OVER (
                       PARTITION BY "instanceId", "moduleId"
                       ORDER BY "createdAt" DESC, "id" DESC
                     ) AS rn
              FROM "ModuleRecord"
              WHERE "instanceId" IN (${Prisma.join(storeIds)}) AND "deletedAt" IS NULL
            ) ranked
            WHERE rn <= ${RECORD_CAP}
          `)
      : [];

    const recordsByInstance = new Map<
      string,
      { moduleId: string; dataJson: string; statusKey: string }[]
    >();
    for (const record of recordRows) {
      const list = recordsByInstance.get(record.instanceId) ?? [];
      list.push({
        moduleId: record.moduleId,
        dataJson: record.dataJson,
        statusKey: record.statusKey,
      });
      recordsByInstance.set(record.instanceId, list);
    }

    /* ONE grouped aggregation replaces the per-instance order scans — exact
       counts, completed-revenue sums and last-order timestamps per store.
       ROUND 87 — trashed (soft-deleted) orders never aggregate. */
    const orderGroups = storeIds.length
      ? await db.siteOrder.groupBy({
          by: ["instanceId", "status"],
          where: { instanceId: { in: storeIds }, deletedAt: null },
          _count: { _all: true },
          _sum: { total: true },
          _max: { createdAt: true },
        })
      : [];
    const orderAggByInstance = new Map<string, OrderAggregate>();
    for (const group of orderGroups) {
      const agg = orderAggByInstance.get(group.instanceId) ?? emptyOrderAggregate();
      const count = group._count._all;
      agg.orders += count;
      switch (group.status) {
        case "pending":
          agg.pending += count;
          break;
        case "confirmed":
        case "preparing":
        case "ready":
          agg.active += count;
          break;
        case "completed":
          agg.completed += count;
          agg.revenue += group._sum.total ?? 0;
          break;
        case "cancelled":
          agg.cancelled += count;
          break;
      }
      const stamp = group._max.createdAt;
      if (stamp && (!agg.lastOrderAt || stamp > agg.lastOrderAt)) agg.lastOrderAt = stamp;
      orderAggByInstance.set(group.instanceId, agg);
    }

    const stores = storeRows.map((row) =>
      toStoreDto(
        row,
        recordsByInstance.get(row.id) ?? [],
        orderAggByInstance.get(row.id) ?? emptyOrderAggregate()
      )
    );

    /* platform-wide totals (revenue grouped per currency, major units) */
    const revenueByCurrency = new Map<string, number>();
    for (const store of stores) {
      if (store.revenue > 0) {
        revenueByCurrency.set(
          store.currency,
          (revenueByCurrency.get(store.currency) ?? 0) + store.revenue / 100
        );
      }
    }

    const totals: AdminStoresDTO["totals"] = {
      stores: stores.length,
      withCatalog: stores.filter((s) => s.moduleId !== null).length,
      products: stores.reduce((sum, s) => sum + s.products, 0),
      orders: stores.reduce((sum, s) => sum + s.orders, 0),
      ordersPending: stores.reduce((sum, s) => sum + s.ordersPending, 0),
      revenue: [...revenueByCurrency.entries()]
        .sort((a, b) => b[1] - a[1])
        .map(([currency, value]) => ({ currency, value: Math.round(value * 100) / 100 })),
    };

    return NextResponse.json({ stores, totals });
  } catch (error) {
    console.error("GET /api/admin/stores failed:", error);
    return NextResponse.json({ error: "Failed to list stores" }, { status: 500 });
  }
}

/* ------------------------------ aggregation ------------------------------ */

/* ROUND 66 — aligned with store-mapper.ts: menu now outranks inventory
 * (restaurant storefronts sell dishes, not back-office kitchen stock) and
 * the menu column layout is [item, category, price, stock, rating, status]. */
const STORE_MODULE_PRIORITY = ["pharmacy", "products", "menu", "inventory"] as const;
const STORE_COLUMNS: Record<string, { name: number; category: number; stock: number; price: number }> = {
  pharmacy: { name: 0, category: 1, stock: 4, price: 5 },
  inventory: { name: 0, category: 2, stock: 3, price: 4 },
  products: { name: 0, category: 2, stock: 3, price: 4 },
  menu: { name: 0, category: 1, stock: 3, price: 2 },
};
const LOW_STOCK_THRESHOLD = 5;

function readModules(row: Pick<Instance, "modulesJson">): string[] {
  try {
    const parsed = JSON.parse(row.modulesJson ?? "[]") as unknown;
    return Array.isArray(parsed) ? parsed.filter((m): m is string => typeof m === "string") : [];
  } catch {
    return [];
  }
}

function storeModuleId(row: Pick<Instance, "modulesJson">): string | null {
  const modules = readModules(row);
  for (const candidate of STORE_MODULE_PRIORITY) {
    if (modules.includes(candidate)) return candidate;
  }
  return null;
}

function readCurrency(row: Pick<Instance, "orgJson">): string {
  try {
    const org = JSON.parse(row.orgJson ?? "{}") as { currency?: unknown };
    return typeof org.currency === "string" && org.currency.trim() ? org.currency.trim() : "SAR";
  } catch {
    return "SAR";
  }
}

function parseNumber(raw: string | undefined): number {
  if (raw == null) return 0;
  const n = Number(String(raw).replace(/[^\d.-]/g, ""));
  return Number.isFinite(n) && n >= 0 ? n : 0;
}

function catalogStats(moduleId: string, records: Pick<ModuleRecord, "dataJson" | "statusKey">[]): {
  products: number;
  lowStock: number;
  outOfStock: number;
  stockValue: number;
  categories: Set<string>;
} {
  const cols = STORE_COLUMNS[moduleId] ?? { name: 0, category: 2, stock: 3, price: 4 };
  const categories = new Set<string>();
  let products = 0;
  let lowStock = 0;
  let outOfStock = 0;
  let stockValue = 0;
  for (const record of records) {
    let values: string[] = [];
    try {
      const parsed = JSON.parse(record.dataJson ?? "[]") as unknown;
      if (Array.isArray(parsed)) values = parsed.map((v) => (typeof v === "string" ? v : ""));
    } catch {
      continue;
    }
    const at = (i: number) => (i < values.length ? values[i] : "");
    const name = at(cols.name).trim();
    const category = at(cols.category).trim();
    const stock = Math.floor(parseNumber(at(cols.stock)));
    const price = Math.round(parseNumber(at(cols.price)) * 100) / 100;
    if (!name || price <= 0) continue;
    /* sellable catalog rows (mirrors the public storefront filters) */
    if (record.statusKey === "out" || record.statusKey === "expired") continue;
    if (stock <= 0) continue;
    products += 1;
    if (category) categories.add(category);
    if (stock <= LOW_STOCK_THRESHOLD) lowStock += 1;
    outOfStock += stock === 0 ? 1 : 0; /* defensive (stock>0 above) */
    stockValue += price * stock;
  }
  return { products, lowStock, outOfStock, stockValue: Math.round(stockValue * 100) / 100, categories };
}

/* Column-narrowed instance projection used by the aggregation. */
type StoreInstanceRow = Pick<Instance, "id" | "systemId" | "orgJson" | "modulesJson" | "createdAt"> & {
  site: { published: boolean; views: number } | null;
};

/* Per-store order pipeline totals (assembled from the grouped aggregation). */
interface OrderAggregate {
  orders: number;
  pending: number;
  active: number;
  completed: number;
  cancelled: number;
  revenue: number;
  lastOrderAt: Date | null;
}

function emptyOrderAggregate(): OrderAggregate {
  return {
    orders: 0,
    pending: 0,
    active: 0,
    completed: 0,
    cancelled: 0,
    revenue: 0,
    lastOrderAt: null,
  };
}

function toStoreDto(
  row: StoreInstanceRow,
  records: { moduleId: string; dataJson: string; statusKey: string }[],
  orderAgg: OrderAggregate
): AdminStoreDTO {
  const moduleId = storeModuleId(row);
  const currency = readCurrency(row);

  /* the window query returns rows for every module partition of the
     instance — only the chosen store module's partition feeds the stats,
     exactly like the former per-instance moduleId-scoped query. */
  const catalog = moduleId
    ? catalogStats(
        moduleId,
        records.filter((r) => r.moduleId === moduleId)
      )
    : { products: 0, lowStock: 0, outOfStock: 0, stockValue: 0, categories: new Set<string>() };

  return {
    instanceId: row.id,
    orgName: computeOrgName(row),
    systemId: row.systemId,
    moduleId,
    currency,
    sitePublished: row.site?.published ?? false,
    siteViews: row.site?.views ?? 0,
    products: catalog.products,
    lowStock: catalog.lowStock,
    outOfStock: catalog.outOfStock,
    stockValue: catalog.stockValue,
    categories: catalog.categories.size,
    orders: orderAgg.orders,
    ordersPending: orderAgg.pending,
    ordersActive: orderAgg.active,
    ordersCompleted: orderAgg.completed,
    ordersCancelled: orderAgg.cancelled,
    revenue: orderAgg.revenue,
    lastOrderAt: orderAgg.lastOrderAt ? orderAgg.lastOrderAt.toISOString() : null,
    createdAt: row.createdAt.toISOString(),
  };
}

function computeOrgName(row: Pick<Instance, "systemId" | "orgJson">): string {
  try {
    const org = JSON.parse(row.orgJson ?? "{}") as { name?: unknown };
    return typeof org.name === "string" && org.name.trim() ? org.name.trim() : row.systemId;
  } catch {
    return row.systemId;
  }
}
