import { adminList, adminPatch } from "@/server/domains/enterprise-quotes/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 167 — طلبات المؤسسات: the Super Admin quotes inbox (super+admin).
 *
 *  GET /api/admin/enterprise-quotes — keyset pages (newest first):
 *  ?status=new|contacted|quoted|won|lost filter, ?cursor (opaque, loud 400
 *  when malformed), ?limit (1..100, default 20). Rows carry the MASKED
 *  address (n***@domain) — plaintext recovery rides the one-time
 *  sealed-email reveal lever (targetType "quote"), never this feed.
 *
 *  PATCH /api/admin/enterprise-quotes — { id, status?, adminNotes? }: the
 *  one-directional pipeline new → contacted → quoted → won|lost (400
 *  QUOTE_INVALID_TRANSITION on an illegal move, 404 QUOTE_NOT_FOUND on an
 *  unknown id), stamping contactedAt/quotedAt/closedAt on entry. Every
 *  mutation writes a platform.quoteStatus audit row.
 */
export const GET = adminList;
export const PATCH = adminPatch;
