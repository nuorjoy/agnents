import { adminList } from "@/server/domains/addon-orders/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 141 — GET /api/admin/addon-orders — the console's add-on purchase
 * queue (org context attached, newest first, optional ?status= filter).
 */
export const GET = adminList;
