import { adminConfirmOrCancel } from "@/server/domains/addon-orders/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 141 — PATCH /api/admin/addon-orders/[id] — confirm receipt
 * ({ action: "paid" }) or cancel ({ action: "cancelled" }) an add-on
 * purchase. CONFIRMATION ACTIVATES the ordered features: they merge into
 * Instance.featureOverridesJson as force-ON in the same transaction,
 * instantly unlocking them workspace-wide (audited as
 * instance.addonActivate — an entitlement-changing SECURITY action).
 */
export const PATCH = adminConfirmOrCancel;
