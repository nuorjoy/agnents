import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import {rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import type { RegistrationResponseJSON } from "@simplewebauthn/server";
import {
  crossDeviceQrSvg,
  finishPasskeyRegistration,
  listCredentials,
  startPasskeyRegistration,
} from "@/lib/server/webauthn";

export const dynamic = "force-dynamic";

/** Registration throttling: 8 attempts / 10 min per admin. */
const REG_RULE = { limit: 8, windowMs: 10 * 60 * 1000 };

/**
 * ROUND 45 — POST /api/admin/passkeys — Passkey management for the
 * signed-in admin.
 *
 * GET  — the account's passkey list (metadata only — device type, backed-up
 *        flag, dates; key material NEVER leaves the server).
 * POST — registration STEP 1: fresh creation options (challenges expire in
 *        3 minutes, existing credentials are excluded).
 * PUT  — registration STEP 2: { name, response } — the authenticator's
 *        attestation is verified against the stored challenge, and only the
 *        PUBLIC key + counter are persisted.
 */
export async function GET() {
  const guard = await requireAdmin(undefined);
  if (guard instanceof NextResponse) return guard;
  return NextResponse.json({ credentials: await listCredentials("admin", guard.user.id) });
}

export async function POST(req: Request) {
  const guard = await requireAdmin(undefined, req);
  if (guard instanceof NextResponse) return guard;
  const user = guard.user;

  if (await rateLimited(`admin-passkey-reg:${user.id}`, REG_RULE, { failClosed: true })) {
    return tooManyRequests(REG_RULE, { error: "Too many attempts — try again later" });
  }

  /* ROUND 46 — the client may pass the settings URL it sits on; when it
     lives on this origin the response carries a premium violet QR the
     user scans with a phone to enroll a passkey on that device.
     Bounded read (4 KB cap): the registration body is tiny, so an oversized
     payload is abuse, not input — same policy as every other mutation. */
  let returnTo: string | undefined;
  const body = await readJson(req, 4_000);
  const raw = body.ok ? (body.data as { returnTo?: unknown } | undefined) : undefined;
  if (typeof raw?.returnTo === "string") {
    returnTo = raw.returnTo;
  }

  try {
    const options = await startPasskeyRegistration(
      req,
      "admin",
      user.id,
      user.username,
      user.name
    );
    const crossDeviceQr = await crossDeviceQrSvg(req, returnTo);
    return NextResponse.json({ options, ...(crossDeviceQr ? { crossDeviceQr } : {}) });
  } catch (error) {
    console.error("POST /api/admin/passkeys failed:", error);
    return NextResponse.json({ error: "Failed to start passkey registration" }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  const guard = await requireAdmin(undefined, req);
  if (guard instanceof NextResponse) return guard;
  const user = guard.user;

  const body = await readJson(req, 200_000);
  if (!body.ok) return body.response;

  const name = (body.data as { name?: unknown }).name;
  const response = (body.data as { response?: unknown }).response;
  if (typeof name !== "string" || name.length > 60) {
    return NextResponse.json({ error: "Invalid passkey name" }, { status: 400 });
  }
  if (!response || typeof response !== "object" || !("id" in response)) {
    return NextResponse.json({ error: "Invalid registration response" }, { status: 400 });
  }

  try {
    const result = await finishPasskeyRegistration(
      req,
      "admin",
      user.id,
      name,
      response as RegistrationResponseJSON
    );
    if (!result.ok) {
      const message =
        result.error === "EXPIRED"
          ? "The registration window expired — try again"
          : result.error === "DUPLICATE"
            ? "This passkey is already registered"
            : "Passkey verification failed — try again";
      return NextResponse.json({ error: message, code: result.error }, { status: 400 });
    }

    await logAudit({
      actorType: "admin",
      actorId: user.id,
      actorName: user.username,
      action: "admin.update",
      targetLabel: "passkey registered",
      meta: { credential: result.id.slice(0, 12) },
    });

    return NextResponse.json({ ok: true, credentials: await listCredentials("admin", user.id) });
  } catch (error) {
    console.error("PUT /api/admin/passkeys failed:", error);
    return NextResponse.json({ error: "Failed to register passkey" }, { status: 500 });
  }
}
