import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { listCredentials, removePasskey } from "@/lib/server/webauthn";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * ROUND 45 — DELETE /api/admin/passkeys/[id] — remove one of the admin's own
 * passkeys (credential id). Owners manage only their own credentials: the
 * subject is pinned to the session's admin id inside removePasskey.
 */
export async function DELETE(req: Request, { params }: RouteContext) {
  const guard = await requireAdmin(undefined, req);
  if (guard instanceof NextResponse) return guard;
  const user = guard.user;
  const { id } = await params;

  const ok = await removePasskey("admin", user.id, id);
  if (!ok) {
    return NextResponse.json({ error: "Passkey not found" }, { status: 404 });
  }

  await logAudit({
    actorType: "admin",
    actorId: user.id,
    actorName: user.username,
    action: "admin.update",
    targetLabel: "passkey removed",
    meta: { credential: id.slice(0, 12) },
  });

  return NextResponse.json({ ok: true, credentials: await listCredentials("admin", user.id) });
}
