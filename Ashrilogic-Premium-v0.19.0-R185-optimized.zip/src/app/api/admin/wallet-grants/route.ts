import { adminAudience, adminGrant } from "@/server/domains/wallet-grants/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 168 — منح المحفظة (Super-Admin bulk wallet grants), super+admin.
 *
 *  GET /api/admin/wallet-grants?target=all|plan&packageId=… — the audience
 *  preview: { target, count, packageName } for the composer's live count
 *  and the confirmation receipt (the EXACT live-subscriber audience a
 *  grant would credit — trial workspaces included in target=all).
 *
 *  POST /api/admin/wallet-grants — { target: "all" | "plan", packageId?,
 *  amountMinor (integer minor units, $1..$100k per recipient), note? } —
 *  executes the bulk credit: bounded keyset batches of per-recipient CAS
 *  transactions (WalletTxn kind "grant", reference "grant:<grantId>" +
 *  one activity feed row each), then one platform.walletGrant audit
 *  summary row. Response: { grantId, audience, credited, skipped,
 *  amountMinor }.
 */
export const GET = adminAudience;
export const POST = adminGrant;
