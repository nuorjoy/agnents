import { NextResponse } from "next/server";
import { ctxAdmin, routeHandler } from "@/lib/server/route";
import {
  consumeRevealToken,
  mintRevealToken,
  revealConsumeSchema,
  revealMintSchema,
} from "@/lib/server/email-reveal";

export const dynamic = "force-dynamic";

/**
 * ROUND 166 — استعادة البريد المختوم: the one-time sealed-email reveal
 * surface (super-only, audited, rate-limited).
 *
 *  POST /api/admin/email-reveal — mint a single-use reveal token for one
 *  sealed mailbox row: { targetType, targetId, instanceId?, reason }.
 *  The response carries the RAW token EXACTLY ONCE (+ expiry); only its
 *  sha256 is stored. 201 on success.
 *
 *  PUT /api/admin/email-reveal — consume a token: { token }. Atomic
 *  single-use CAS claim; the response carries the decrypted email for THIS
 *  ONE request (never persisted anywhere). 410 REVEAL_REUSED / REVEAL_EXPIRED
 *  on the single-use/expiry laws, 404 REVEAL_NOT_FOUND on an unknown hash.
 *
 * Both stages assert requireAdmin(["super"]) with the Request (origin CSRF
 * + the ROUND-89 MFA-enrollment policy gate — a privileged PII lever is
 * exactly the mutation class that gate exists for) and re-check the role
 * inside the service (defense in depth).
 */

/** Mint throttle: 10 mints / 10 min per super admin + IP. */
const MINT_RULE = { limit: 10, windowMs: 10 * 60 * 1000 };
/** Consume throttle: 20 consumes / 10 min per super admin + IP. */
const CONSUME_RULE = { limit: 20, windowMs: 10 * 60 * 1000 };

export const POST = routeHandler(
  "mint email reveal token",
  {
    origin: true,
    admin: { roles: ["super"], withRequest: true },
    rateLimit: {
      key: (parts) => `email-reveal-mint:${parts.adminId()}:${parts.ip}`,
      rule: MINT_RULE,
      body: { error: "Too many reveal tokens minted — try again later", code: "RATE_LIMITED" },
    },
  },
  async (ctx): Promise<NextResponse> => {
    const admin = ctxAdmin(ctx);
    const input = await ctx.parseBody(revealMintSchema);
    const result = await mintRevealToken(admin, input);
    /* the RAW token is in this response exactly once — never logged */
    return NextResponse.json(result, { status: 201 });
  }
);

export const PUT = routeHandler(
  "consume email reveal token",
  {
    origin: true,
    admin: { roles: ["super"], withRequest: true },
    rateLimit: {
      key: (parts) => `email-reveal-consume:${parts.adminId()}:${parts.ip}`,
      rule: CONSUME_RULE,
      body: { error: "Too many reveal attempts — try again later", code: "RATE_LIMITED" },
    },
  },
  async (ctx): Promise<NextResponse> => {
    const admin = ctxAdmin(ctx);
    const input = await ctx.parseBody(revealConsumeSchema);
    const result = await consumeRevealToken(admin, input);
    /* the plaintext email is in this response exactly once — never logged */
    return NextResponse.json(result);
  }
);
