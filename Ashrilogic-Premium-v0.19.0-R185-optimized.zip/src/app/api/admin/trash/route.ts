import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/admin-session";
import { readJson } from "@/lib/server/http";
import { zodError } from "@/lib/server/instance-mapper";
import { z } from "zod";
import {
  listTrash,
  purgeExpired,
  purgeItem,
  restoreItem,
  softDelete,
  TRASH_ENTITIES,
  type TrashEntity,
} from "@/lib/server/trash";

export const dynamic = "force-dynamic";

const entityEnum = z.enum(TRASH_ENTITIES);

/**
 * GET /api/admin/trash — the Super Admin trash console feed.
 * Query params: entity (filter), q (search), limit (1..200, default 50),
 * offset. Every read FIRST runs the retention sweep (expired rows are
 * destroyed permanently before the feed is served — the "صارمة" law), then
 * returns { items, stats } with per-entity counts, expiring-soon count and
 * the retention window.
 */
export async function GET(req: Request) {
  const guard = await requireAdmin(["super", "admin", "moderator"], req);
  if (guard instanceof NextResponse) return guard;

  try {
    void purgeExpired().catch(() => undefined);

    const url = new URL(req.url);
    const entityRaw = url.searchParams.get("entity");
    const q = url.searchParams.get("q");
    const rawLimit = url.searchParams.get("limit");
    const rawOffset = url.searchParams.get("offset");

    const entity = entityRaw && TRASH_ENTITIES.includes(entityRaw as TrashEntity)
      ? (entityRaw as TrashEntity)
      : null;
    const limit = rawLimit !== null ? Math.min(200, Math.max(1, Number.parseInt(rawLimit, 10) || 50)) : 50;
    const offset = rawOffset !== null ? Math.max(0, Number.parseInt(rawOffset, 10) || 0) : 0;

    const result = await listTrash({
      entity,
      search: q,
      limit,
      offset,
      includePlatformEntities: true,
    });
    return NextResponse.json(result);
  } catch (error) {
    console.error("GET /api/admin/trash failed:", error);
    return NextResponse.json({ error: "Failed to read trash" }, { status: 500 });
  }
}

const actionSchema = z.object({
  action: z.enum(["restore", "purge", "purgeExpired"]),
  entity: entityEnum.optional(),
  id: z.string().min(1).max(64).optional(),
  reason: z.string().max(200).optional(),
});

/**
 * POST /api/admin/trash — restore / purge ONE item, or run the retention
 * sweep explicitly (purgeExpired). Strict permission law:
 *   - instance + adminUser rows are GOVERNANCE entities → super only;
 *   - tenant business rows → admin tier sufficient;
 *   - moderator is read-only (403 here).
 */
export async function POST(req: Request) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const body = await readJson(req);
  if (!body.ok) return body.response;
  const parsed = actionSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const { action } = parsed.data;
  const user = guard.user;
  const actor = { kind: "admin" as const, actorId: user.id, actorName: user.name };

  try {
    if (action === "purgeExpired") {
      const result = await purgeExpired();
      return NextResponse.json({ ok: true, purged: result.purged });
    }

    const entity = parsed.data.entity;
    const id = parsed.data.id;
    if (!entity || !id) {
      return NextResponse.json({ error: "entity and id are required" }, { status: 400 });
    }
    /* governance entities are super-only */
    if ((entity === "instance" || entity === "adminUser") && user.role !== "super") {
      return NextResponse.json(
        { error: "Restoring or purging workspaces and admin accounts requires the super role", code: "SUPER_ONLY" },
        { status: 403 }
      );
    }

    if (action === "restore") {
      const result = await restoreItem(entity, id, actor);
      if (!result.ok) {
        return NextResponse.json(
          { error: result.message ?? "Restore failed", code: result.code ?? "RESTORE_FAILED" },
          { status: result.status }
        );
      }
      return NextResponse.json({ ok: true, label: result.label ?? null });
    }

    const result = await purgeItem(entity, id, actor);
    if (!result.ok) {
      return NextResponse.json(
        { error: "Purge failed", code: result.code ?? "PURGE_FAILED" },
        { status: result.status }
      );
    }
    return NextResponse.json({ ok: true, label: result.label ?? null });
  } catch (error) {
    console.error("POST /api/admin/trash failed:", error);
    return NextResponse.json({ error: "Trash action failed" }, { status: 500 });
  }
}
