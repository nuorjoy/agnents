import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { toAdminSectorPartnerDTO, toPartnerCandidateDTO } from "@/lib/server/blog-mapper";
import { zodError } from "@/lib/server/instance-mapper";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { CATEGORIES, SYSTEM_MAP } from "@/data/catalog";

export const dynamic = "force-dynamic";

/**
 * TRUSTED-SECTOR CONSOLE — showcase + candidates in one read, plus create.
 *
 * GET  — the curated rows (joined back to their REAL registered workspaces:
 *        live org name, system, registration date) + the candidate list of
 *        live workspaces NOT yet showcased (org name, sector, plan, date).
 *        Any authenticated admin role (operational visibility).
 * POST — add a registered workspace to the showcase. super/admin only.
 *        `sector` defaults to the workspace system's catalog category;
 *        icon/colors default to that category's identity; sortOrder
 *        appends to the end of the strip.
 */

const CATEGORY_IDS = new Set(CATEGORIES.map((c) => c.id));
const HEX_COLOR = /^#[0-9a-fA-F]{6}$/;

const partnerCreateSchema = z.object({
  instanceId: z.string().trim().min(1).max(64),
  nameAr: z.string().trim().max(120).optional(),
  nameEn: z.string().trim().max(120).optional(),
  sector: z
    .string()
    .trim()
    .max(40)
    .refine((v) => CATEGORY_IDS.has(v), "sector: unknown category id")
    .optional(),
  icon: z.string().trim().min(1).max(40).optional(),
  c1: z.string().trim().regex(HEX_COLOR, "c1: hex color required").optional(),
  c2: z.string().trim().regex(HEX_COLOR, "c2: hex color required").optional(),
  visible: z.boolean().optional(),
  sortOrder: z.number().int().min(0).max(999).optional(),
});

/** systemId → catalog category id ("" for unknown systems). */
function sectorOfSystem(systemId: string): string {
  return SYSTEM_MAP[systemId]?.c ?? "";
}

export async function GET() {
  const guard = await requireAdmin();
  if (guard instanceof NextResponse) return guard;

  try {
    const [rows, instances, packages] = await Promise.all([
      db.sectorPartner.findMany({
        orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
        include: { instance: { select: { id: true, systemId: true, orgJson: true, createdAt: true } } },
      }),
      db.instance.findMany({
        where: { deletedAt: null },
        select: {
          id: true,
          systemId: true,
          orgJson: true,
          createdAt: true,
          packageId: true,
        },
        orderBy: { createdAt: "desc" },
        take: 100,
      }),
      db.package.findMany({ select: { id: true, nameAr: true } }),
    ]);

    const planLabels = new Map<string, string>(packages.map((p) => [p.id, p.nameAr]));
    const showcased = new Set(rows.map((r) => r.instanceId));

    const mappedRows = rows
      .filter((row) => row.instance !== null)
      .map((row) => toAdminSectorPartnerDTO(row, row.instance));

    /* candidates: live workspaces with a resolvable org name, newest first */
    const candidates = instances
      .map((inst) =>
        toPartnerCandidateDTO(
          inst,
          sectorOfSystem,
          inst.packageId ? (planLabels.get(inst.packageId) ?? "") : "",
          showcased.has(inst.id)
        )
      )
      .filter((c) => c.orgName.length > 0 && c.sector.length > 0 && !c.alreadyShowcased);

    return NextResponse.json({ rows: mappedRows, candidates });
  } catch (error) {
    console.error("GET /api/admin/partners failed:", error);
    return NextResponse.json({ error: "Failed to load partners console" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = partnerCreateSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const data = parsed.data;

  try {
    const inst = await db.instance.findFirst({
      where: { id: data.instanceId, deletedAt: null },
      select: { id: true, systemId: true, orgJson: true, createdAt: true },
    });
    if (!inst) {
      return NextResponse.json({ error: "Workspace not found or trashed" }, { status: 404 });
    }

    const existing = await db.sectorPartner.findUnique({
      where: { instanceId: inst.id },
      select: { id: true },
    });
    if (existing) {
      return NextResponse.json({ error: "Workspace already showcased" }, { status: 409 });
    }

    /* sector defaults to the system's category; identity to the category's
       palette — the admin may override both in the same request */
    const sector = data.sector ?? sectorOfSystem(inst.systemId);
    if (!CATEGORY_IDS.has(sector)) {
      return NextResponse.json({ error: "sector: unknown category id" }, { status: 400 });
    }
    const cat = CATEGORIES.find((c) => c.id === sector)!;
    const icon = data.icon ?? cat.icon;
    const c1 = data.c1 ?? cat.c1;
    const c2 = data.c2 ?? cat.c2;

    const maxOrder = await db.sectorPartner.aggregate({ _max: { sortOrder: true } });
    const row = await db.sectorPartner.create({
      data: {
        instanceId: inst.id,
        nameAr: data.nameAr ?? "",
        nameEn: data.nameEn ?? "",
        sector,
        icon,
        c1,
        c2,
        visible: data.visible ?? true,
        sortOrder: data.sortOrder ?? (maxOrder._max.sortOrder ?? -1) + 1,
      },
      include: { instance: { select: { id: true, systemId: true, orgJson: true, createdAt: true } } },
    });

    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "partner.create",
      targetLabel: row.nameAr || inst.systemId,
      meta: { sector, visible: String(row.visible), sortOrder: String(row.sortOrder) },
    });

    return NextResponse.json(toAdminSectorPartnerDTO(row, inst), { status: 201 });
  } catch (error) {
    console.error("POST /api/admin/partners failed:", error);
    return NextResponse.json({ error: "Failed to add showcase entry" }, { status: 500 });
  }
}
