import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { toAdminSectorPartnerDTO } from "@/lib/server/blog-mapper";
import { zodError } from "@/lib/server/instance-mapper";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { CATEGORIES } from "@/data/catalog";
import type { Prisma } from "@prisma/client";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * TRUSTED-SECTOR CONSOLE — single showcase entry update + delete.
 * super/admin only. The reordering action arrives as explicit sortOrder
 * swaps (the console sends the two affected rows' new positions).
 */

const CATEGORY_IDS = new Set(CATEGORIES.map((c) => c.id));
const HEX_COLOR = /^#[0-9a-fA-F]{6}$/;

const partnerUpdateSchema = z.object({
  nameAr: z.string().trim().max(120).optional(),
  nameEn: z.string().trim().max(120).optional(),
  sector: z
    .string()
    .trim()
    .max(40)
    .refine((v) => CATEGORY_IDS.has(v), "sector: unknown category id")
    .optional(),
  icon: z.string().trim().min(1).max(40).optional(),
  c1: z.string().trim().regex(HEX_COLOR, "c1: hex color required").optional(),
  c2: z.string().trim().regex(HEX_COLOR, "c2: hex color required").optional(),
  visible: z.boolean().optional(),
  sortOrder: z.number().int().min(0).max(999).optional(),
});

export async function PATCH(req: Request, ctx: RouteContext) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const { id } = await ctx.params;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = partnerUpdateSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const data = parsed.data;

  if (Object.keys(data).length === 0) {
    return NextResponse.json({ error: "No changes provided" }, { status: 400 });
  }

  try {
    const current = await db.sectorPartner.findUnique({
      where: { id },
      include: { instance: { select: { id: true, systemId: true, orgJson: true, createdAt: true } } },
    });
    if (!current || current.instance === null) {
      return NextResponse.json({ error: "Showcase entry not found" }, { status: 404 });
    }

    const patch: Prisma.SectorPartnerUpdateInput = {};
    if (typeof data.nameAr === "string") patch.nameAr = data.nameAr;
    if (typeof data.nameEn === "string") patch.nameEn = data.nameEn;
    if (typeof data.sector === "string") patch.sector = data.sector;
    if (typeof data.icon === "string") patch.icon = data.icon;
    if (typeof data.c1 === "string") patch.c1 = data.c1;
    if (typeof data.c2 === "string") patch.c2 = data.c2;
    if (typeof data.visible === "boolean") patch.visible = data.visible;
    if (typeof data.sortOrder === "number") patch.sortOrder = data.sortOrder;

    const row = await db.sectorPartner.update({
      where: { id },
      data: patch,
      include: { instance: { select: { id: true, systemId: true, orgJson: true, createdAt: true } } },
    });

    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "partner.update",
      targetLabel: row.nameAr || row.instance.systemId,
      meta: Object.keys(data).reduce<Record<string, string>>((acc, key) => {
        acc[key] = String((data as Record<string, unknown>)[key]);
        return acc;
      }, {}),
    });

    return NextResponse.json(toAdminSectorPartnerDTO(row, row.instance));
  } catch (error) {
    console.error("PATCH /api/admin/partners/[id] failed:", error);
    return NextResponse.json({ error: "Failed to update showcase entry" }, { status: 500 });
  }
}

export async function DELETE(req: Request, ctx: RouteContext) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const { id } = await ctx.params;

  try {
    const current = await db.sectorPartner.findUnique({
      where: { id },
      include: { instance: { select: { id: true, systemId: true, orgJson: true, createdAt: true } } },
    });
    if (!current || current.instance === null) {
      return NextResponse.json({ error: "Showcase entry not found" }, { status: 404 });
    }

    await db.sectorPartner.delete({ where: { id } });

    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "partner.delete",
      targetLabel: current.nameAr || current.instance.systemId,
      meta: { sector: current.sector, sortOrder: String(current.sortOrder) },
    });

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("DELETE /api/admin/partners/[id] failed:", error);
    return NextResponse.json({ error: "Failed to remove showcase entry" }, { status: 500 });
  }
}
