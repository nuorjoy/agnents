import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/admin-session";
import { readJson } from "@/lib/server/http";
import {
  legalDraftSchema,
  readPlatformLegalBundle,
  resetPlatformLegalDoc,
  savePlatformLegalDoc,
} from "@/lib/server/legal-docs";
import type { LegalDocKey, LegalDocLocale } from "@/lib/platform-legal-defaults";

export const dynamic = "force-dynamic";

/**
 * ROUND 117 — LEGAL DOCUMENTS CONSOLE API.
 *
 * GET    /api/admin/legal  — the whole bundle (both keys × ar/en/hi):
 *                            row ?? code default, with updatedAt/version/
 *                            customized per locale. Any authenticated admin
 *                            role (operational visibility).
 * PUT    /api/admin/legal  — publish one draft { key, locale, title, intro,
 *                            sections[] }. super/admin only. Zod-validated,
 *                            versioned, attributed, sealed-audited
 *                            (admin.legalDocUpdate); live on the public
 *                            /privacy + /terms pages immediately (they are
 *                            force-dynamic).
 * DELETE /api/admin/legal  — reset one key × locale to the code default
 *                            { key, locale }. super/admin only. Sealed
 *                            audit (admin.legalDocReset).
 */
export async function GET() {
  const guard = await requireAdmin();
  if (guard instanceof NextResponse) return guard;

  try {
    const docs = await readPlatformLegalBundle();
    return NextResponse.json({ docs }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("GET /api/admin/legal failed:", error);
    return NextResponse.json({ error: "Could not load the legal documents" }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const body = await readJson(req, 400_000);
  if (!body.ok) return body.response;

  const parsed = legalDraftSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid document — check the title, intro and sections bounds", details: parsed.error.issues.map((i) => `${i.path.join(".")}: ${i.message}`) },
      { status: 400 }
    );
  }

  try {
    const result = await savePlatformLegalDoc(parsed.data, {
      id: guard.user.id,
      name: guard.user.name,
    });
    if (!result.ok) {
      return NextResponse.json({ error: result.error }, { status: 400 });
    }
    return NextResponse.json({ doc: result.doc, version: result.version });
  } catch (error) {
    console.error("PUT /api/admin/legal failed:", error);
    return NextResponse.json({ error: "Could not publish the document" }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const body = await readJson(req, 2_000);
  if (!body.ok) return body.response;

  const key = (body.data as { key?: unknown }).key;
  const locale = (body.data as { locale?: unknown }).locale;
  if (
    (key !== "privacy" && key !== "terms") ||
    (locale !== "ar" && locale !== "en" && locale !== "hi")
  ) {
    return NextResponse.json({ error: "Unknown document or locale" }, { status: 400 });
  }

  try {
    const result = await resetPlatformLegalDoc(key as LegalDocKey, locale as LegalDocLocale, {
      id: guard.user.id,
      name: guard.user.name,
    });
    if (!result.ok) {
      return NextResponse.json({ error: result.error }, { status: 409 });
    }
    return NextResponse.json({ doc: result.doc });
  } catch (error) {
    console.error("DELETE /api/admin/legal failed:", error);
    return NextResponse.json({ error: "Could not reset the document" }, { status: 500 });
  }
}
