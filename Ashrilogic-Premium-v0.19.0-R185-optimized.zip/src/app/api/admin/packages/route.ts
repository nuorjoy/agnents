import { adminCreate, adminList } from "@/server/domains/packages/controller";

export const dynamic = "force-dynamic";

/**
 * GET  /api/admin/packages — all subscription plans (any authenticated
 *        admin; seeds the default plans on an empty table).
 * POST /api/admin/packages — create a plan (super/admin; at most one plan
 *        carries the `popular` flag — creating a popular plan clears the
 *        others, transactionally).
 *
 * ROUND 124 — the handlers moved to the packages domain
 * (src/server/domains/packages): this file is the thin route delegation.
 */
export const GET = adminList;
export const POST = adminCreate;
