import { adminRemove, adminUpdate } from "@/server/domains/packages/controller";

export const dynamic = "force-dynamic";

/**
 * PATCH  /api/admin/packages/[id] — update a plan (super/admin; marking a
 *         plan popular clears the flag from every other plan inside the
 *         same transaction).
 * DELETE /api/admin/packages/[id] — permanently remove a plan (super/admin).
 *
 * ROUND 124 — the handlers moved to the packages domain
 * (src/server/domains/packages): this file is the thin route delegation.
 */
export const PATCH = adminUpdate;
export const DELETE = adminRemove;
