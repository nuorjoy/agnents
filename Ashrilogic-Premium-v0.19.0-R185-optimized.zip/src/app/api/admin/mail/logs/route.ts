import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/admin-session";
import { db } from "@/lib/db";
import { maskEmail } from "@/lib/server/audit";
import type { EmailLogDTO, EmailLogPageDTO } from "@/lib/types";

export const dynamic = "force-dynamic";

/**
 * EMAIL SYSTEM — the DELIVERY LOGS feed (Communications → Email).
 *
 * GET ?page=&pageSize=&status=&type=&q= — the paginated EmailLog trail:
 * every envelope the Mail Service dispatched with its transport outcome,
 * attempts, error class and provider message id.
 *
 * Hardening: super + admin roles. NON-super roles see the recipient
 * MASKED (s***@domain.com — the same convention the audit trail uses);
 * the super admin sees the full mailbox (the trail is the transport
 * diagnostics surface, and the console already displays decrypted
 * customer emails elsewhere under stricter gates). No secrets ever
 * appear in a log row — errors are scrubbed at write time.
 */

const MAX_PAGE_SIZE = 50;

const STATUS_VALUES = new Set(["sent", "failed", "skipped"]);
const TYPE_VALUES = new Set([
  "verification",
  "passwordReset",
  "welcome",
  "securityAlert",
  "subscription",
  "orderStatus",
  "campaign",
  "platformEvent",
  "weeklyDigest",
  "test",
  "system",
]);

function numParam(url: URL, name: string, fallback: number, min: number, max: number): number {
  const raw = url.searchParams.get(name);
  if (raw === null) return fallback;
  const parsed = Number.parseInt(raw, 10);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, parsed));
}

export async function GET(req: Request) {
  const guard = await requireAdmin(["super", "admin"]);
  if (guard instanceof NextResponse) return guard;

  try {
    const url = new URL(req.url);
    const page = numParam(url, "page", 1, 1, 100_000);
    const pageSize = numParam(url, "pageSize", 20, 1, MAX_PAGE_SIZE);
    const status = url.searchParams.get("status");
    const type = url.searchParams.get("type");
    const q = url.searchParams.get("q")?.trim().slice(0, 120) ?? "";

    const where = {
      ...(status && STATUS_VALUES.has(status) ? { status } : {}),
      ...(type && TYPE_VALUES.has(type) ? { type } : {}),
      ...(q
        ? {
            OR: [
              { subject: { contains: q } },
              { recipient: { contains: q.toLowerCase() } },
            ],
          }
        : {}),
    };

    const [rows, total] = await Promise.all([
      db.emailLog.findMany({
        where,
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      db.emailLog.count({ where }),
    ]);

    const full = guard.user.role === "super";
    const dtos: EmailLogDTO[] = rows.map((row) => ({
      id: row.id,
      type: row.type,
      recipient: full ? row.recipient : (maskEmail(row.recipient) ?? row.recipient),
      subject: row.subject,
      provider: row.provider,
      status: row.status,
      messageId: row.messageId,
      attempts: row.attempts,
      error: row.error,
      errorClass: row.errorClass,
      instanceId: row.instanceId,
      sentAt: row.sentAt?.toISOString() ?? null,
      deliveredAt: row.deliveredAt?.toISOString() ?? null,
      failedAt: row.failedAt?.toISOString() ?? null,
      createdAt: row.createdAt.toISOString(),
    }));

    const payload: EmailLogPageDTO = { rows: dtos, total, page, pageSize };
    return NextResponse.json(payload);
  } catch (error) {
    console.error("GET /api/admin/mail/logs failed:", error);
    return NextResponse.json({ error: "Failed to load email logs" }, { status: 500 });
  }
}
