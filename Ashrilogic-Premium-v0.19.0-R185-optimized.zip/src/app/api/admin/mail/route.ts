import { NextResponse } from "next/server";
import { z } from "zod";
import { zodError } from "@/lib/server/instance-mapper";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { getMailSettingsDTO, applyMailSettingsPatch } from "@/lib/server/mail/settings";
import { getMailHealth } from "@/lib/server/mail/health";
import type { MailPanelDTO } from "@/lib/types";

export const dynamic = "force-dynamic";

/**
 * EMAIL SYSTEM — the Communications → Email control panel.
 *
 * GET   — the panel state (MailSettingsDTO: the sealed password reduced to
 *         `hasPassword`) + the point-in-time health snapshot. Any admin
 *         role may READ (operational visibility); the health probe is real
 *         (connection verify + SPF/DKIM/DMARC DNS lookups).
 * PATCH — Super-Admin ONLY: partial update of the SMTP configuration,
 *         sender identity, timeouts and the welcome toggle. A NEW SMTP
 *         password is sealed with AES-256-GCM before it touches storage;
 *         `rotatePassword` drops the stored one.
 *
 * Hardening mirrors the AI panel: strict role gate, same-origin guard on
 * the mutation, bounded body read, strict Zod validation, and an audit row
 * listing ONLY the changed field names (never the password itself).
 */

const mailSettingsUpdateSchema = z.object({
  enabled: z.boolean().optional(),
  host: z.string().trim().max(253).optional(),
  port: z.number().int().min(1).max(65_535).optional(),
  secure: z.enum(["none", "starttls", "tls"]).optional(),
  username: z.string().trim().max(200).optional(),
  password: z.string().min(4).max(400).optional(),
  rotatePassword: z.boolean().optional(),
  fromName: z.string().trim().max(80).optional(),
  fromEmail: z.string().trim().email().max(254).optional(),
  replyTo: z.string().trim().max(254).optional(),
  timeoutMs: z.number().int().min(3_000).max(60_000).optional(),
  sendWelcome: z.boolean().optional(),
});

export async function GET() {
  const guard = await requireAdmin(["super", "admin"]);
  if (guard instanceof NextResponse) return guard;

  try {
    const [settings, health] = await Promise.all([getMailSettingsDTO(), getMailHealth()]);
    /* least privilege: a non-super admin sees the username MASKED (they can
     * still operate the health/test/logs surfaces — the credential itself
     * is super-only, exactly like the AI panel's sealed key) */
    if (guard.user.role !== "super" && settings.username.length > 0) {
      settings.username = `${settings.username.slice(0, 2)}•••`;
    }
    const payload: MailPanelDTO = { settings, health };
    return NextResponse.json(payload);
  } catch (error) {
    console.error("GET /api/admin/mail failed:", error);
    return NextResponse.json({ error: "Failed to load mail settings" }, { status: 500 });
  }
}

export async function PATCH(req: Request) {
  const guard = await requireAdmin(["super"], req);
  if (guard instanceof NextResponse) return guard;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = mailSettingsUpdateSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const patch = parsed.data;

  /* an empty patch is a no-op request — reject instead of auditing noise */
  if (Object.keys(patch).length === 0) {
    return NextResponse.json({ error: "No settings provided" }, { status: 400 });
  }

  try {
    const dto = await applyMailSettingsPatch(patch);

    /* audit ONLY the changed field names — the password value never enters
     * the trail (its presence/rotation is the security-relevant fact).
     * mail.settings rides the SECURITY trail (see audit.ts). */
    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "mail.settings",
      targetLabel: "communications → email",
      meta: Object.keys(patch).reduce<Record<string, string>>((acc, key) => {
        if (key === "password") acc[key] = "sealed";
        else if (key === "rotatePassword") acc[key] = patch.rotatePassword ? "rotated" : "kept";
        else acc[key] = String((patch as Record<string, unknown>)[key]);
        return acc;
      }, {}),
    });

    return NextResponse.json(dto);
  } catch (error) {
    console.error("PATCH /api/admin/mail failed:", error);
    return NextResponse.json({ error: "Failed to save mail settings" }, { status: 500 });
  }
}
