import { NextResponse } from "next/server";
import { getSessionJti, requireAdmin } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { listSessions, revokeAllSessions, revokeOtherSessions } from "@/lib/server/sessions";
import { readJson } from "@/lib/server/http";

export const dynamic = "force-dynamic";

/**
 * ROUND 45 — POST /api/admin/sessions/revoke-all — sign out EVERY OTHER
 * device (the current session survives so the admin is not logged out by
 * their own security action). Returns the remaining list.
 *
 * ROUND 46 — `{ includeCurrent: true }` escalates to "sign out EVERYWHERE":
 * every session including the one making the request is revoked (the client
 * then routes back to the login screen). Explicit, opt-in and audited — the
 * destructive variant can never fire by accident.
 */
export async function POST(req: Request) {
  const guard = await requireAdmin(undefined, req);
  if (guard instanceof NextResponse) return guard;

  const body = await readJson(req);
  if (!body.ok) return body.response;
  const includeCurrent =
    (body.data as { includeCurrent?: unknown }).includeCurrent === true;

  const currentJti = await getSessionJti();
  let revoked: number;
  if (includeCurrent) {
    const before = await listSessions("admin", guard.user.id);
    await revokeAllSessions("admin", guard.user.id);
    revoked = before.length;
  } else {
    revoked = await revokeOtherSessions("admin", guard.user.id, currentJti);
  }

  await logAudit({
    actorType: "admin",
    actorId: guard.user.id,
    actorName: guard.user.username,
    action: "admin.update",
    targetLabel: includeCurrent ? "all sessions signed out" : "sessions revoked",
    meta: { count: String(revoked) },
  });

  return NextResponse.json({
    ok: true,
    revoked,
    signedOutEverywhere: includeCurrent,
    sessions: await listSessions("admin", guard.user.id),
  });
}
