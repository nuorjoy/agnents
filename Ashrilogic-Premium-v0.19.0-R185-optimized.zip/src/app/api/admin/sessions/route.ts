import { NextResponse } from "next/server";
import { getSessionJti, requireAdmin } from "@/lib/server/admin-session";
import { listSessions } from "@/lib/server/sessions";

export const dynamic = "force-dynamic";

/**
 * ROUND 45 — GET /api/admin/sessions — the signed-in admin's ACTIVE
 * sessions (device, IP, last activity) with the current session's jti marked,
 * powering the "active sessions" security card. Revocation lives at
 * DELETE /api/admin/sessions/[id] and POST /api/admin/sessions/revoke-all.
 */
export async function GET() {
  const guard = await requireAdmin(undefined);
  if (guard instanceof NextResponse) return guard;

  const [sessions, currentJti] = await Promise.all([
    listSessions("admin", guard.user.id),
    getSessionJti(),
  ]);
  return NextResponse.json({ sessions, currentJti: currentJti ?? null });
}
