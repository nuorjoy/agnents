import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { listSessions, revokeSession } from "@/lib/server/sessions";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * ROUND 45 — DELETE /api/admin/sessions/[id] — revoke ONE of the admin's own
 * sessions (sign out a single device). Revoking the CURRENT session is
 * allowed (it equals a logout — the next request 401s). The subject is
 * pinned to the session's admin id, so ids can never cross accounts.
 */
export async function DELETE(req: Request, { params }: RouteContext) {
  const guard = await requireAdmin(undefined, req);
  if (guard instanceof NextResponse) return guard;
  const { id } = await params;

  const ok = await revokeSession("admin", guard.user.id, id);
  if (!ok) {
    return NextResponse.json({ error: "Session not found" }, { status: 404 });
  }

  await logAudit({
    actorType: "admin",
    actorId: guard.user.id,
    actorName: guard.user.username,
    action: "admin.update",
    targetLabel: "session revoked",
    meta: { session: id.slice(0, 10) },
  });

  return NextResponse.json({ ok: true, sessions: await listSessions("admin", guard.user.id) });
}
