import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/server/admin-session";
import { authWorkDepth } from "@/lib/server/crypto-vault";
import { __backupCacheStatsForTests } from "@/lib/server/backup-cache";
import { webhookOpsStats } from "@/lib/server/webhooks";
import { anchorFilePath } from "@/lib/server/audit-anchor";
import { stat } from "node:fs/promises";

export const dynamic = "force-dynamic";

/**
 * GET /api/admin/ops — OPERATIONAL SUBSYSTEM TELEMETRY (Phase 19 follow-up:
 * the structured ops.* log lines exist for log pipelines; this endpoint
 * gives the platform console a QUERYABLE snapshot of the hardened
 * subsystems' live state so operators see them without shell access).
 *
 * SUPER-ADMIN ONLY (the data is infrastructure posture: table sizes, cache
 * state, lease holders — operator-need-to-know, not moderator material).
 *
 * Payload contract (additive, read-only, no secrets — identifiers, counts
 * and ages only; the redaction contract of oplog.ts applies here too):
 *   provider        — "sqlite" | "postgresql" (the active runtime)
 *   audit           — row counts + chained share + anchor presence
     *                    + ROUND 121 chain health (rows since the anchor,
     *                    anchor age — the unanchored tail at a glance)
 *   idempotency     — guard row counts by status + oldest completed age
 *   schedulerLeases — active job leases (job, holder pid, age, TTL)
 *   backupCache     — entries/bytes/build-hit-miss-join counters
 *   rateLimit       — table size (window state volume)
 *   authWork        — current argon2 backpressure window depth
 *   emailQueueDepth — EmailLog rows awaiting delivery confirmation
 */

export async function GET() {
  const guard = await requireAdmin(["super"]);
  if (guard instanceof NextResponse) return guard;

  try {
    const now = Date.now();

    const [
      auditTotal,
      auditChained,
      auditAnchor,
      idemCompleted,
      idemInFlight,
      idemOldest,
      leases,
      rateLimitRows,
      emailPending,
    ] = await Promise.all([
      db.auditLog.count(),
      db.auditLog.count({ where: { chainHash: { not: null } } }),
      db.auditChainAnchor.findUnique({ where: { id: "global" } }),
      db.orderIdempotency.count({ where: { status: "completed" } }),
      db.orderIdempotency.count({ where: { status: "in_flight" } }),
      db.orderIdempotency.findFirst({
        where: { status: "completed" },
        orderBy: { completedAt: "asc" },
        select: { completedAt: true },
      }),
      db.schedulerLease.findMany({
        orderBy: { job: "asc" },
        select: { job: true, holder: true, acquiredAt: true, expiresAt: true },
      }),
      db.rateLimitHit.count(),
      db.emailLog.count({ where: { status: "sent", deliveredAt: null } }),
    ]);

    /* ROUND 122 — the anchor JOURNAL's freshness: how long since the
     * off-host copy path (the R119 export / the R118 hourly safety-net
     * ticks that append to it) last wrote the file. A stale journal on a
     * live chain is the operator's cue to export (the WORM-gap telemetry
     * next to rowsSinceAnchor). */
    let anchorJournal: { exists: boolean; lastWriteAgeHours: number | null; bytes: number } = {
      exists: false,
      lastWriteAgeHours: null,
      bytes: 0,
    };
    try {
      const jst = await stat(anchorFilePath());
      anchorJournal = {
        exists: true,
        lastWriteAgeHours: Math.round(((now - jst.mtimeMs) / 3_600_000) * 10) / 10,
        bytes: jst.size,
      };
    } catch {
      /* never anchored or unreadable — the card shows the absent state */
    }

    const backupCache = __backupCacheStatsForTests();

    /* ROUND 121 — CHAIN HEALTH: the unanchored tail (rows written after
     * the anchor row — the chain growth since the last anchor event, i.e.
     * the stretch that exists ONLY in this database until the next
     * off-host journal export) and the anchor's age. Both null while no
     * anchor exists (the whole chain is the tail then — surfaced by the
     * existing anchored=false flag). */
    let rowsSinceAnchor: number | null = null;
    let anchorAgeHours: number | null = null;
    if (auditAnchor) {
      anchorAgeHours = Math.round(((now - auditAnchor.anchoredAt.getTime()) / 3_600_000) * 10) / 10;
      const anchorRow = await db.auditLog.findUnique({
        where: { id: auditAnchor.anchorRowId },
        select: { createdAt: true },
      });
      if (anchorRow) {
        rowsSinceAnchor = await db.auditLog.count({
          where: { createdAt: { gt: anchorRow.createdAt } },
        });
      }
    }

    return NextResponse.json({
      provider: "postgresql",
      audit: {
        totalRows: auditTotal,
        chainedRows: auditChained,
        anchored: auditAnchor !== null,
        anchorUpdatedAt: auditAnchor?.anchoredAt?.toISOString() ?? null,
        rowsSinceAnchor,
        anchorAgeHours,
        /* ROUND 122 — the off-host journal copy path's freshness */
        anchorJournal,
      },
      idempotency: {
        completedGuards: idemCompleted,
        inFlightGuards: idemInFlight,
        oldestCompletedAgeHours:
          idemOldest?.completedAt != null
            ? Math.round(((now - idemOldest.completedAt.getTime()) / 3_600_000) * 10) / 10
            : null,
      },
      schedulerLeases: leases.map((l) => ({
        job: l.job,
        /* holder is "pid-randomhex" — the pid prefix is the operational
           signal (which process owns the tick); the random tail adds
           nothing for diagnostics and is trimmed */
        holderPid: l.holder.split("-")[0] ?? l.holder,
        ageMs: now - l.acquiredAt.getTime(),
        expiresInMillis: l.expiresAt.getTime() - now,
      })),
      backupCache: {
        entries: backupCache.entries,
        bytes: backupCache.bytes,
        builds: backupCache.builds,
        hits: backupCache.hits,
        misses: backupCache.misses,
        joins: backupCache.joins,
        evictions: backupCache.evictions,
      },
      rateLimit: { windowRows: rateLimitRows },
      authWork: { windowDepth: authWorkDepth() },
      emailQueue: { pendingDeliveryConfirmations: emailPending },
      /* ROUND 113 — webhook subsystem (counts only; the redaction contract
         holds — no URLs, no secrets, no endpoint output) */
      webhooks: await webhookOpsStats(),
      generatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error("GET /api/admin/ops failed:", error);
    return NextResponse.json({ error: "Failed to load ops telemetry" }, { status: 500 });
  }
}
