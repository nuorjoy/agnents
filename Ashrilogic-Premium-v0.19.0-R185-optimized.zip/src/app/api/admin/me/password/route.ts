import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  getSessionUser,
  hashPassword,
  checkPassword,
  setSessionCookie,
  sessionTtlMs,
} from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { originViolation } from "@/lib/server/origin-guard";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { revokeAllSessions } from "@/lib/server/sessions";
import { z } from "zod";

export const dynamic = "force-dynamic";

/** Self-service password rotation: 6 attempts / 10 min per admin. */
const RULE = { limit: 6, windowMs: 10 * 60 * 1000 };

const bodySchema = z.object({
  currentPassword: z.string().min(1).max(200),
  newPassword: z.string().min(8).max(200),
});

/**
 * ROUND 46 (F-4) — POST /api/admin/me/password — self-service password
 * change for the SIGNED-IN admin account (control-panel Settings →
 * Account Security).
 *
 *  - the CURRENT password must verify (no takeover via a stray cookie);
 *  - the new password is stored as an Argon2id record only (never in any
 *    JSON blob, never serialized back);
 *  - every OTHER session-registry row is revoked ("other devices signed
 *    out"); the caller's own session keeps working right here;
 *  - origin-guarded, bounded body, durable fail-closed rate limit, audited.
 */
export async function POST(req: Request) {
  const violation = originViolation(req);
  if (violation) return violation;

  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ error: "No active session" }, { status: 401 });
  }

  if (await rateLimited(`admin-selfpw:${user.id}`, RULE, { failClosed: true })) {
    return tooManyRequests(RULE, { error: "Too many attempts — try again later" });
  }

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = bodySchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "New password must be at least 8 characters" },
      { status: 400 }
    );
  }
  const { currentPassword, newPassword } = parsed.data;

  /* ROUND 87 — a trashed (soft-deleted) admin account cannot rotate its
   * password (the session subject reads as gone; belt+suspenders on top of
   * the admin-session guard). */
  const row = await db.adminUser.findUnique({
    where: { id: user.id, deletedAt: null },
    select: { passwordHash: true },
  });
  if (!row) {
    return NextResponse.json({ error: "Account not found" }, { status: 404 });
  }

  if (!checkPassword(currentPassword, row.passwordHash)) {
    return NextResponse.json(
      { error: "The current password is incorrect", code: "WRONG_PASSWORD" },
      { status: 401 }
    );
  }

  /* rotate: Argon2id hash only. The session epoch is bumped in the same
   * write so every outstanding admin token (including pre-registry ones)
   * stops verifying immediately; the registry is swept and the ACTOR keeps
   * working in this browser through a fresh token at the new epoch — same
   * posture as the workspace-owner rotation flow. */
  const updated = await db.adminUser.update({
    where: { id: user.id },
    data: {
      passwordHash: hashPassword(newPassword),
      sessionVersion: { increment: 1 },
    },
    select: { sessionVersion: true },
  });

  await revokeAllSessions("admin", user.id);

  await setSessionCookie(user.id, updated.sessionVersion ?? 0, await sessionTtlMs(), {
    ip: clientIp(req),
    userAgent: req.headers.get("user-agent"),
  });

  await logAudit({
    actorType: "admin",
    actorId: user.id,
    actorName: user.username,
    action: "admin.update",
    targetLabel: "own password rotated",
    meta: { self: "password", ip: clientIp(req) ?? "—" },
  });

  return NextResponse.json({ ok: true });
}
