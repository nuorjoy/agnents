import { NextResponse } from "next/server";
import { getSessionUser, mfaEnrollmentRequired } from "@/lib/server/admin-session";

export const dynamic = "force-dynamic";

/**
 * GET /api/admin/me — resolve the current admin session from the cookie.
 * 200 + AdminUserDTO when a valid, active session exists; 401 otherwise.
 * The client auth store calls this once on mount to restore the session.
 *
 * ROUND 89 — the payload now carries `mfaEnrollRequired` when the platform
 * «إلزام المصادقة الثنائية» toggle is ON and this admin has no second
 * factor enrolled; the console renders the blocking enrollment gate until
 * the flow completes (the API layer enforces the same policy on mutating
 * routes via requireAdmin).
 */
export async function GET() {
  try {
    const user = await getSessionUser();
    if (!user) {
      return NextResponse.json({ error: "No active session" }, { status: 401 });
    }
    const enrollRequired = await mfaEnrollmentRequired(user.id).catch(() => false);
    return NextResponse.json({ ...user, mfaEnrollRequired: enrollRequired });
  } catch (error) {
    console.error("GET /api/admin/me failed:", error);
    return NextResponse.json({ error: "Failed to read session" }, { status: 500 });
  }
}
