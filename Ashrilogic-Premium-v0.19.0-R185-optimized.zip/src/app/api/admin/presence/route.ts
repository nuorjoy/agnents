import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/admin-session";
import {
  adminDirectoryPresence,
  instanceDirectoryPresence,
  onlineAdminCount,
  presenceOf,
  type PresenceDTO,
} from "@/lib/server/presence";

export const dynamic = "force-dynamic";

/**
 * POST /api/admin/presence — ROUND 172 (premium presence heartbeat).
 *
 * The Super-Admin console beats every 45s while its tab is open. The call
 * itself IS the heartbeat: requireAdmin → getSessionUser →
 * checkSessionRecord refreshes the caller's SessionRecord.lastSeenAt
 * (throttled to once a minute server-side), so no extra write path exists.
 *
 * Response (live presence snapshot):
 *  - me.id / me.presence — the caller's own status (any staff role).
 *  - admins — per-adminId presence map (super/admin/moderator only; the
 *    same roles that may read the admins directory).
 *  - instances — per-instanceId presence map of every LIVE workspace's
 *    owner session (super/admin/moderator — the console views that render
 *    the systems/subscribers rows).
 *  - support.onlineAdmins — distinct online platform admins (viewer-safe:
 *    a count, never identities).
 *  - serverTime — ISO "now" so clients render relative «آخر ظهور» labels
 *    without trusting a skewed local clock.
 *
 * Mutating verb (the touch) + same-origin CSRF gate via requireAdmin(…, req).
 */
export async function POST(req: Request) {
  const guard = await requireAdmin(["super", "admin", "moderator", "viewer"], req);
  if (guard instanceof NextResponse) return guard;

  try {
    const me = await presenceOf("admin", guard.user.id);

    /* PII-scoping mirrors the admins-directory gate (super/admin/moderator):
     * viewer sessions keep the heartbeat (their own presence stays fresh)
     * but never see per-id maps of staff or tenants. */
    const canSeeMaps =
      guard.user.role === "super" || guard.user.role === "admin" || guard.user.role === "moderator";

    let admins: Record<string, PresenceDTO> | undefined;
    let instances: Record<string, PresenceDTO> | undefined;

    if (canSeeMaps) {
      admins = await adminDirectoryPresence();
      instances = await instanceDirectoryPresence();
    }

    return NextResponse.json({
      me: { id: guard.user.id, presence: me },
      admins,
      instances,
      support: { onlineAdmins: await onlineAdminCount() },
      serverTime: new Date().toISOString(),
    });
  } catch (error) {
    console.error("POST /api/admin/presence failed:", error);
    return NextResponse.json({ error: "Presence unavailable" }, { status: 500 });
  }
}
