import { adminAdjust } from "@/server/domains/wallet/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 141 — POST /api/admin/wallet-adjust — a direct console wallet
 * credit/debit (a complimentary balance or a correction): { instanceId,
 * amount (raw dual-numeral string), direction: "credit" | "debit", note? }.
 * super/admin only — MONEY-MOVING (unconditional audit + retention floor).
 */
export const POST = adminAdjust;
