import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toAdminUserDTO } from "@/lib/server/admin-mapper";
import {
  sessionTtlMs,
  setSessionCookie,
  verifyMfaTicket,
} from "@/lib/server/admin-session";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { originViolation } from "@/lib/server/origin-guard";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import type { AuthenticationResponseJSON } from "@simplewebauthn/server";
import { finishPasskeyLogin, startPasskeyLogin } from "@/lib/server/webauthn";

export const dynamic = "force-dynamic";

/** Passkey-login throttling: 10 / 5 min per IP. */
const PK_RULE = { limit: 10, windowMs: 5 * 60 * 1000 };

/**
 * ROUND 45 — POST /api/admin/passkey-login — passkey sign-in for the control
 * panel, in BOTH shapes:
 *
 *  { step: "start" }                → DISCOVERABLE (usernameless) options:
 *    the browser lists every passkey created for this origin; the account is
 *    resolved from the credential id at finish time.
 *  { step: "start", ticket }        → PINNED options for the admin whose
 *    password already verified (the second-factor alternative — the ticket
 *    is the short-lived admin-mfa ticket from POST /api/admin/login).
 *  { step: "finish", response }     → verify the assertion (+ ticket when the
 *    start was pinned) and issue the real session cookie.
 *
 * Hardening: origin guard, bounded body, durable IP limiter (fail closed),
 * single-use 3-minute challenges, counter-based clone detection, epoch
 * re-check (password change mid-flight revokes), audited successes.
 */
export async function POST(req: Request) {
  const violation = originViolation(req);
  if (violation) return violation;

  const body = await readJson(req, 200_000);
  if (!body.ok) return body.response;

  const step = (body.data as { step?: unknown }).step;
  const ticket = (body.data as { ticket?: unknown }).ticket;
  const response = (body.data as { response?: unknown }).response;

  const ip = clientIp(req);
  if (await rateLimited(`admin-passkey-login:${ip}`, PK_RULE, { failClosed: true })) {
    return tooManyRequests(PK_RULE, { error: "Too many attempts — try again later" });
  }

  /* ------------------------------ STEP 1 ------------------------------ */
  if (step === "start") {
    let subjectId: string | null = null;
    if (typeof ticket === "string" && ticket) {
      const payload = verifyMfaTicket(ticket);
      if (!payload) {
        return NextResponse.json(
          { error: "Verification session expired — sign in again" },
          { status: 401 }
        );
      }
      subjectId = payload.uid;
    }
    const started = await startPasskeyLogin(req, "admin", subjectId);
    if (!started.ok) {
      return NextResponse.json(
        { error: "No passkeys registered for this account yet" },
        { status: 400 }
      );
    }
    return NextResponse.json({ options: started.options });
  }

  /* ------------------------------ STEP 2 ------------------------------ */
  if (step === "finish") {
    if (!response || typeof response !== "object" || !("id" in response)) {
      return NextResponse.json({ error: "Invalid assertion" }, { status: 400 });
    }
    /* a pinned finish MUST present the same ticket family (mfa step);
     * discoverable finish carries none */
    let pinnedUid: string | null = null;
    if (typeof ticket === "string" && ticket) {
      const payload = verifyMfaTicket(ticket);
      if (!payload) {
        return NextResponse.json(
          { error: "Verification session expired — sign in again" },
          { status: 401 }
        );
      }
      pinnedUid = payload.uid;
    }

    const result = await finishPasskeyLogin(req, "admin", response as AuthenticationResponseJSON);
    if (!result.ok) {
      const message =
        result.error === "EXPIRED"
          ? "The sign-in window expired — try again"
          : result.error === "UNKNOWN_CREDENTIAL"
            ? "This passkey is not registered"
            : "Passkey verification failed — try again";
      return NextResponse.json({ error: message, code: result.error }, { status: 401 });
    }

    /* pinned flow: the assertion MUST belong to the ticket's admin */
    if (pinnedUid && result.subjectId !== pinnedUid) {
      return NextResponse.json({ error: "Passkey verification failed" }, { status: 401 });
    }

    /* ROUND 87 — a trashed (soft-deleted) admin account never signs in with
     * a passkey (uniform 401). */
    const row = await db.adminUser.findUnique({ where: { id: result.subjectId, deletedAt: null } });
    if (!row || !row.active) {
      return NextResponse.json({ error: "Passkey verification failed" }, { status: 401 });
    }
    if (typeof ticket === "string" && ticket) {
      const payload = verifyMfaTicket(ticket);
      if (!payload || (row.sessionVersion ?? 0) !== payload.ver) {
        return NextResponse.json(
          { error: "Verification session expired — sign in again" },
          { status: 401 }
        );
      }
    }

    const updated = await db.adminUser.update({
      where: { id: row.id },
      data: { lastLoginAt: new Date() },
    });

    await setSessionCookie(row.id, row.sessionVersion ?? 0, await sessionTtlMs(), {
      ip,
      userAgent: req.headers.get("user-agent"),
    });
    await logAudit({
      actorType: "admin",
      actorId: row.id,
      actorName: row.username,
      action: "admin.login",
      meta: { passkey: "passed" },
    });
    return NextResponse.json(toAdminUserDTO(updated));
  }

  return NextResponse.json({ error: "Unknown step" }, { status: 400 });
}
