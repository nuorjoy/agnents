import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/admin-session";
import { clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { readJson } from "@/lib/server/http";
import { logAudit } from "@/lib/server/audit";
import { collectImageRefGcPlan, runImageRefGc } from "@/lib/server/image-ref-gc";

export const dynamic = "force-dynamic";

/** Plan-preview throttling (the scan touches every image-bearing column). */
const PLAN_RULE = { limit: 30, windowMs: 5 * 60 * 1000 };
/** Manual-run throttling — the sweep itself is lease-protected; this bounds
 *  a trigger-happy operator hammering the button (and the plan re-scan). */
const RUN_RULE = { limit: 6, windowMs: 10 * 60 * 1000 };

/** Clamp for the grace window (hours): 0 (immediate) … 7 days. */
function clampGrace(v: unknown, fallback: number): number {
  const n = typeof v === "number" ? v : Number(v);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(168, Math.max(0, Math.round(n)));
}

/** The console-shaped plan (counts + bytes only — no id lists over the wire). */
function planDto(plan: Awaited<ReturnType<typeof collectImageRefGcPlan>>) {
  return {
    graceHours: plan.graceHours,
    referenced: plan.referenced,
    unreferencedCount: plan.unreferenced.length,
    unreferencedFresh: plan.unreferencedFresh,
    rowsMissingFile: plan.rowsMissingFile,
    imagesBytes: plan.imagesBytes,
    reclaimableBytes: plan.reclaimableBytes + plan.orphanPlan.reclaimableBytes,
    orphanPlan: plan.orphanPlan,
  };
}

/**
 * ROUND 117 — the ADMIN STORAGE GC CONSOLE API.
 *
 * GET  /api/admin/storage/gc?grace=24 — the DRY-RUN plan: how many image
 *      asset rows are unreferenced past the grace window, how many bytes
 *      they + the orphan files (no row) would reclaim, how many are still
 *      within grace (kept), total managed bytes on disk. super/admin.
 *
 * POST /api/admin/storage/gc { graceHours? } — run the sweep NOW under the
 *      same SchedulerLease the hourly safety net uses (multi-instance
 *      safe; a concurrent tick answers leaseHeld instead of double-running).
 *      super/admin + origin guard + 2FA mutation gate. Every manual run is
 *      sealed-audited (admin.storageGc) with the actor and the reclaim
 *      accounting; the internal sweep also writes its system.gc row when
 *      it actually reclaims something.
 *
 * The TARGETED hooks (releaseImageRefs after every replace/clear/purge)
 * remain the primary reclamation path — this console is the operator's
 * on-demand backstop for the batch window.
 */
export async function GET(req: Request) {
  const guard = await requireAdmin(["super", "admin"]);
  if (guard instanceof NextResponse) return guard;

  const url = new URL(req.url);
  const grace = clampGrace(url.searchParams.get("grace"), 24);

  const ip = clientIp(req);
  if (await rateLimited(`storage-gc-plan:${guard.user.id}:${ip}`, PLAN_RULE, { failClosed: true })) {
    return tooManyRequests(PLAN_RULE, { error: "Too many plan requests — slow down" });
  }

  try {
    const plan = await collectImageRefGcPlan({ graceHours: grace });
    return NextResponse.json({ plan: planDto(plan) }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("GET /api/admin/storage/gc failed:", error);
    return NextResponse.json({ error: "Could not collect the storage plan" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const body = await readJson(req, 2_000);
  if (!body.ok) return body.response;

  const data = body.data as { graceHours?: unknown };
  const grace = clampGrace(data.graceHours, 24);

  if (await rateLimited(`storage-gc-run:${guard.user.id}`, RUN_RULE, { failClosed: true })) {
    return tooManyRequests(RUN_RULE, { error: "Too many manual runs — try again later" });
  }

  try {
    /* pre-plan: distinguish "nothing to reclaim" (clean no-op) from
     * "lease held" (another tick is mid-sweep) for the console UX */
    const before = await collectImageRefGcPlan({ graceHours: grace });
    const hasWork =
      before.unreferenced.length > 0 || before.orphanPlan.reclaimableBytes > 0;

    let outcome: Awaited<ReturnType<typeof runImageRefGc>> = null;
    let leaseHeld = false;
    if (hasWork) {
      outcome = await runImageRefGc(grace);
      leaseHeld = outcome === null;
    }

    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.name,
      action: "admin.storageGc",
      targetLabel: `grace ${grace}h`,
      meta: {
        graceHours: String(grace),
        noOp: hasWork ? "false" : "true",
        leaseHeld: leaseHeld ? "true" : "false",
        deletedRows: String(outcome?.deletedRows ?? 0),
        deletedFiles: String(outcome?.deletedFiles ?? 0),
        deletedOrphans: String(outcome?.orphan.deletedOrphans ?? 0),
        deletedTemp: String(outcome?.orphan.deletedTemp ?? 0),
        reclaimedBytes: String(
          (outcome?.reclaimedBytes ?? 0) + (outcome?.orphan.reclaimedBytes ?? 0)
        ),
      },
    });

    const plan = await collectImageRefGcPlan({ graceHours: grace });
    return NextResponse.json(
      {
        ran: !!outcome,
        leaseHeld,
        result: outcome,
        plan: planDto(plan),
      },
      { headers: { "Cache-Control": "no-store" } }
    );
  } catch (error) {
    console.error("POST /api/admin/storage/gc failed:", error);
    return NextResponse.json({ error: "The sweep could not run — try again" }, { status: 500 });
  }
}
