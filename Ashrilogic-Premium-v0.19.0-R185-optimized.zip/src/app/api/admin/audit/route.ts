import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/server/admin-session";
import { AUDIT_ACTOR_TYPES, instanceAuditWhere, type AuditActorType } from "@/lib/server/audit";

export const dynamic = "force-dynamic";

const MAX_LIMIT = 100;

/**
 * GET /api/admin/audit — newest audit-trail entries with optional filters.
 * Query params: actorType (admin|instance|public|system), action (exact key),
 * limit (1..100, default 50), instanceId (ROUND 136 — per-instance linkage
 * via instanceAuditWhere: workspace-actor rows + meta.instance-stamped
 * platform rows). Returns { entries, total } so the view can show "N of M"
 * while paging through the newest window.
 *
 * ROUND 136 — the instanceId filter is additive and READ-ONLY (no audit row
 * for reading the trail); every role's existing row masking is unchanged
 * (masking is applied at WRITE time — actor names are already masked).
 */
export async function GET(req: Request) {
  const guard = await requireAdmin(["super", "admin", "moderator"]);
  if (guard instanceof NextResponse) return guard;

  const url = new URL(req.url);
  const actorTypeRaw = url.searchParams.get("actorType");
  const action = url.searchParams.get("action");
  const rawLimit = url.searchParams.get("limit");
  /* ROUND 136 — the per-instance drilldown filter (bounded sanity: a 1..64
   * non-empty token; an unusable value is ignored rather than 400ing so the
   * console never hard-fails on a hand-edited URL). */
  const instanceIdRaw = url.searchParams.get("instanceId");
  const instanceId =
    instanceIdRaw && instanceIdRaw.trim().length >= 1 && instanceIdRaw.trim().length <= 64
      ? instanceIdRaw.trim()
      : undefined;

  const actorType =
    actorTypeRaw && (AUDIT_ACTOR_TYPES as readonly string[]).includes(actorTypeRaw)
      ? (actorTypeRaw as AuditActorType)
      : undefined;

  let limit = 50;
  if (rawLimit !== null) {
    const parsed = Number.parseInt(rawLimit, 10);
    if (Number.isFinite(parsed)) limit = Math.min(MAX_LIMIT, Math.max(1, parsed));
  }

  const where = {
    ...(actorType ? { actorType } : {}),
    ...(action ? { action } : {}),
    ...(instanceId ? instanceAuditWhere(instanceId) : {}),
  };

  try {
    const [rows, total] = await Promise.all([
      db.auditLog.findMany({
        where,
        orderBy: [{ createdAt: "desc" }, { id: "desc" }],
        take: limit,
      }),
      db.auditLog.count({ where }),
    ]);

    const entries = rows.map((row) => {
      let meta: Record<string, string> | undefined;
      if (row.metaJson) {
        try {
          const parsed = JSON.parse(row.metaJson) as Record<string, unknown>;
          meta = Object.fromEntries(
            Object.entries(parsed).map(([key, value]) => [key, String(value)])
          );
        } catch {
          // corrupt meta — omit it
        }
      }
      return {
        id: row.id,
        actorType: row.actorType as "admin" | "instance" | "public" | "system",
        actorId: row.actorId,
        actorName: row.actorName,
        action: row.action,
        targetLabel: row.targetLabel,
        meta,
        createdAt: row.createdAt.toISOString(),
      };
    });

    return NextResponse.json({ entries, total });
  } catch (error) {
    console.error("GET /api/admin/audit failed:", error);
    return NextResponse.json({ error: "Failed to load audit trail" }, { status: 500 });
  }
}
