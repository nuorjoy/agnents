import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/admin-session";
import { clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { readJson } from "@/lib/server/http";
import { logAudit } from "@/lib/server/audit";
import { appendHeadAnchor, verifyHeadAnchor } from "@/lib/server/audit-anchor";

export const dynamic = "force-dynamic";

/** Status-read throttling (one head snapshot + one file read + one row read). */
const GET_RULE = { limit: 30, windowMs: 5 * 60 * 1000 };
/** Manual-anchor throttling — the append itself is trivial; this bounds a
 *  trigger-happy operator hammering the button (and the audit row it writes). */
const POST_RULE = { limit: 6, windowMs: 10 * 60 * 1000 };

/**
 * ROUND 118 — the AUDIT-CHAIN ANCHOR CONSOLE API.
 *
 * GET /api/admin/audit/anchor — the live verdict: the newest verified
 *      external anchor (time, head-hash prefix, rows covered), the chain's
 *      current head, rows appended since the anchor, and the verdict
 *      (ok / unanchored / stale / truncated / tampered / no-chain).
 *      super/admin.
 *
 * POST /api/admin/audit/anchor — seal a FRESH anchor NOW: the audit row
 *      (admin.auditAnchor) is written FIRST so the anchor covers it too,
 *      then the current head is MAC-sealed and appended to the external
 *      file. super/admin + origin guard + fail-closed rate limiters.
 *
 * The hourly safety net (audit-anchor.ts startAuditAnchorSafetyNet) keeps
 * the anchor fresh on its own; this console is the operator's on-demand
 * pin (before an export, after an incident review, during an audit).
 */
export async function GET(req: Request) {
  const guard = await requireAdmin(["super", "admin"]);
  if (guard instanceof NextResponse) return guard;

  const ip = clientIp(req);
  if (await rateLimited(`audit-anchor-status:${guard.user.id}:${ip}`, GET_RULE, { failClosed: true })) {
    return tooManyRequests(GET_RULE, { error: "Too many status requests — slow down" });
  }

  try {
    const verdict = await verifyHeadAnchor();
    return NextResponse.json(
      {
        status: verdict.status,
        anchor: verdict.anchor
          ? {
              trigger: verdict.anchor.trigger,
              anchoredAt: verdict.anchor.anchoredAt,
              headHashPrefix: `${verdict.anchor.headHash.slice(0, 16)}…`,
              totalRows: verdict.anchor.totalRows,
              chainedRows: verdict.anchor.chainedRows,
            }
          : null,
        head: verdict.head,
        anchoredRowPresent: verdict.anchoredRowPresent,
        rowsSinceAnchor: verdict.rowsSinceAnchor,
        tailCorrupt: verdict.tailCorrupt,
        unreadable: verdict.unreadable,
        anchorAgeMs: verdict.anchorAgeMs,
      },
      { headers: { "Cache-Control": "no-store" } }
    );
  } catch (error) {
    console.error("GET /api/admin/audit/anchor failed:", error);
    return NextResponse.json({ error: "Could not verify the audit anchor" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  /* no body is required; accept-and-ignore an empty one for symmetry */
  const body = await readJson(req, 500);
  if (!body.ok) return body.response;

  if (await rateLimited(`audit-anchor-run:${guard.user.id}`, POST_RULE, { failClosed: true })) {
    return tooManyRequests(POST_RULE, { error: "Too many manual anchors — try again later" });
  }

  try {
    /* the audit row FIRST: the fresh anchor then pins a chain that already
     * includes the record of this very action */
    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.name,
      action: "admin.auditAnchor",
      targetLabel: "manual",
    });

    const result = await appendHeadAnchor("manual");
    if (!result.ok) {
      return NextResponse.json({ error: result.error }, { status: 409 });
    }

    const verdict = await verifyHeadAnchor();
    return NextResponse.json(
      {
        anchored: true,
        payload: {
          anchoredAt: result.payload.anchoredAt,
          headHashPrefix: `${result.payload.headHash.slice(0, 16)}…`,
          totalRows: result.payload.totalRows,
          chainedRows: result.payload.chainedRows,
        },
        status: verdict.status,
      },
      { headers: { "Cache-Control": "no-store" } }
    );
  } catch (error) {
    console.error("POST /api/admin/audit/anchor failed:", error);
    return NextResponse.json({ error: "The anchor could not be sealed — try again" }, { status: 500 });
  }
}
