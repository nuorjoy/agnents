import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/admin-session";
import { clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { readAnchorJournalForExport } from "@/lib/server/audit-anchor";

export const dynamic = "force-dynamic";

/** Export throttling — the file is tiny; this bounds hammering (each request
 *  is a filesystem read + potentially large response buffer). */
const EXPORT_RULE = { limit: 12, windowMs: 10 * 60 * 1000 };

/** Hard cap on the exported journal (bytes) — a runaway/corrupted file must
 *  never produce an unbounded response; the operator investigates instead. */
const MAX_EXPORT_BYTES = 8 * 1024 * 1024;

/**
 * ROUND 119 — GET /api/admin/audit/anchor/export
 *
 * Downloads the audit-chain anchor journal (data/audit-anchors.jsonl) as a
 * plain-text attachment so the operator can copy the MAC-sealed trust points
 * to OFF-HOST storage (WORM bucket, printed archive, a separate machine) —
 * the operational closing of the "same-host attacker rewrites both the DB
 * and the journal" gap documented in audit-anchor.ts.
 *
 * The export is the RAW journal exactly as it sits on disk (including a
 * partial last line — forensic value beats prettiness for an integrity
 * artifact). super/admin; 404 when the platform has never anchored.
 */
export async function GET(req: Request) {
  const guard = await requireAdmin(["super", "admin"]);
  if (guard instanceof NextResponse) return guard;

  const ip = clientIp(req);
  if (await rateLimited(`audit-anchor-export:${guard.user.id}:${ip}`, EXPORT_RULE, { failClosed: true })) {
    return tooManyRequests(EXPORT_RULE, { error: "Too many export requests — slow down" });
  }

  try {
    const journal = await readAnchorJournalForExport();
    if (!journal) {
      return NextResponse.json(
        { error: "No anchor journal exists yet — anchor the chain first" },
        { status: 404 }
      );
    }

    const bytes = Buffer.byteLength(journal.text, "utf8");
    if (bytes > MAX_EXPORT_BYTES) {
      return NextResponse.json(
        { error: "The anchor journal is abnormally large — investigate before exporting" },
        { status: 413 }
      );
    }

    /* stable, sortable filename: audit-anchors-<iso-date>.jsonl */
    const day = new Date().toISOString().slice(0, 10);
    return new NextResponse(journal.text, {
      status: 200,
      headers: {
        "Content-Type": "application/jsonl; charset=utf-8",
        "Content-Disposition": `attachment; filename="audit-anchors-${day}.jsonl"`,
        "Cache-Control": "no-store",
        "X-Anchor-Lines": String(journal.lines),
      },
    });
  } catch (error) {
    console.error("GET /api/admin/audit/anchor/export failed:", error);
    return NextResponse.json({ error: "Could not read the anchor journal" }, { status: 500 });
  }
}
