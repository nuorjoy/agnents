import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/server/admin-session";
import { toActivityDTO } from "@/lib/server/instance-mapper";
import { clampLimit, decodeKeyset, encodeKeyset, keysetPredicate } from "@/lib/server/keyset";
import type { AdminActivityDTO } from "@/lib/types";

/* ROUND 65 — admin-wide activity stream. */

export const dynamic = "force-dynamic";

const DEFAULT_LIMIT = 20;
const MAX_LIMIT = 100;

/* Org filter dropdown cap — ample for the console; the feed itself is
 * never bounded by it. */
const ORGS_CAP = 50;

/**
 * Org display name from the stored `orgJson` column. Fail-soft twin of
 * instance-mapper's private `orgRead` idiom (the mapper keeps its read
 * schemas private): a guarded single-field parse where corrupt JSON
 * degrades to "" instead of a 500.
 */
function orgNameOf(orgJson: string | null | undefined): string {
  if (orgJson == null || orgJson === "") return "";
  try {
    const parsed = JSON.parse(orgJson) as { name?: unknown };
    if (typeof parsed.name !== "string") return "";
    return parsed.name.trim().slice(0, 120);
  } catch {
    return "";
  }
}

/**
 * GET /api/admin/activities?limit=20&cursor=<opaque> — ROUND 65: the
 * ADMIN-WIDE activity stream (every instance, newest first), keyset-
 * paginated on the same `(createdAt, id)` total order as the instance
 * feed (ROUND 57 helpers).
 *
 * Contract: `{ activities, nextCursor, total, orgs }` —
 *  - each activity is enriched with the originating `instanceId`, the org
 *    display name (`orgName`) and the catalog `systemId`;
 *  - `nextCursor` is null exactly when the feed is exhausted (same opaque
 *    cursor contract — stable under concurrent inserts);
 *  - `total` is the PLATFORM-WIDE activity count across ALL instances
 *    (drives the honest "total" KPI);
 *  - `orgs` lists the distinct organizations present in the FULL feed
 *    (id = instance id — the org filter's value), sorted by name, capped
 *    at 50 entries.
 *
 * Authorized by any admin session (role-agnostic read surface).
 */
export async function GET(req: Request) {
  const guard = await requireAdmin();
  if (guard instanceof NextResponse) return guard;

  try {
    const url = new URL(req.url);
    const limit = clampLimit(url.searchParams.get("limit"), DEFAULT_LIMIT, MAX_LIMIT);
    const cursorRaw = url.searchParams.get("cursor");
    const cursor = cursorRaw ? decodeKeyset(cursorRaw) : null;
    /* a supplied-but-malformed cursor is a client bug, not a fresh page:
     * answering 400 keeps a broken pager loud instead of silently looping. */
    if (cursorRaw && !cursor) {
      return NextResponse.json(
        { error: "Invalid pagination cursor", code: "BAD_CURSOR" },
        { status: 400 }
      );
    }

    /* take limit + 1 — the extra row only signals hasMore (never returned).
       ROUND 87 — activities of TRASHED (soft-deleted) workspaces vanish
       from the live feed (the instance relation filter). */
    const rows = await db.activity.findMany({
      where: { instance: { deletedAt: null }, ...(cursor ? keysetPredicate(cursor) : {}) },
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: limit + 1,
      include: { instance: { select: { id: true, systemId: true } } },
    });
    const hasMore = rows.length > limit;
    const page = hasMore ? rows.slice(0, limit) : rows;
    const nextCursor = hasMore && page.length > 0 ? encodeKeyset(page[page.length - 1]) : null;

    /* platform-wide row count of LIVE workspaces' activities (ROUND 87 —
     * trashed instances' rows no longer feed the "total" KPI, matching the
     * filtered feed above). */
    const total = await db.activity.count({ where: { instance: { deletedAt: null } } });

    /* org directory: every LIVE instance's org name read ONCE (SQLite stores
     * OrgInfo as a JSON string column — resolved exactly the way the
     * instance mapper reads it, via the fail-soft twin above).
     * ROUND 87 — trashed workspaces never appear in the dropdown. */
    const instances = await db.instance.findMany({
      where: { deletedAt: null },
      select: { id: true, systemId: true, orgJson: true },
    });
    const orgNameById = new Map(instances.map((i) => [i.id, orgNameOf(i.orgJson)]));

    /* distinct orgs across the FULL feed (not just the loaded page) — one
     * indexed groupBy; the filter dropdown's value is the instance id.
     * ROUND 87 — live workspaces' activities only. */
    const activeIds = new Set(
      (
        await db.activity.groupBy({
          by: ["instanceId"],
          where: { instance: { deletedAt: null } },
        })
      ).map((g) => g.instanceId)
    );
    const orgs = instances
      .filter((i) => activeIds.has(i.id))
      .map((i) => ({ id: i.id, name: orgNameById.get(i.id) ?? "" }))
      .sort((a, b) => a.name.localeCompare(b.name))
      .slice(0, ORGS_CAP);

    const activities: AdminActivityDTO[] = page.map((row) => ({
      ...toActivityDTO(row),
      instanceId: row.instance.id,
      orgName: orgNameById.get(row.instance.id) ?? "",
      systemId: row.instance.systemId,
    }));

    return NextResponse.json({ activities, nextCursor, total, orgs });
  } catch (error) {
    console.error("GET /api/admin/activities failed:", error);
    return NextResponse.json({ error: "Failed to list activities" }, { status: 500 });
  }
}
