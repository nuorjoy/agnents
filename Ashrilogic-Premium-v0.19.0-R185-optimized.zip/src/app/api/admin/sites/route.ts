import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/server/admin-session";

export const dynamic = "force-dynamic";

/** Lenient org-name read from the instance's orgJson column. */
export function readOrgName(raw: string): string {
  if (!raw) return "—";
  try {
    const parsed: unknown = JSON.parse(raw);
    if (parsed && typeof parsed === "object" && "name" in parsed) {
      const name = (parsed as { name?: unknown }).name;
      if (typeof name === "string" && name.trim().length > 0) return name.trim();
    }
  } catch {
    /* fail-soft */
  }
  return "—";
}

/** Upper bound on listed site rows — mirrors the instance listing cap. */
const SITE_CAP = 500;

/**
 * GET /api/admin/sites — every public website linked to a provisioned system
 * (round 27): org + system identity, theme, publish state, views, launch date,
 * customer-account count and public-inquiry count per site. Any authed admin.
 */
export async function GET() {
  const guard = await requireAdmin();
  if (guard instanceof NextResponse) return guard;

  try {
    /* ROUND 87 — sites of TRASHED (soft-deleted) workspaces vanish from the
     * admin Sites manager (they live in the trash engine's own surface), and
     * trashed customer rows no longer count. */
    const [rows, customers, inquiries] = await Promise.all([
      db.site.findMany({
        where: { instance: { deletedAt: null } },
        orderBy: { createdAt: "desc" },
        take: SITE_CAP,
        include: { instance: { select: { orgJson: true, systemId: true, demo: true } } },
      }),
      db.siteCustomer.groupBy({ by: ["instanceId"], _count: { _all: true }, where: { deletedAt: null } }),
      db.supportTicket.groupBy({ by: ["instanceId"], _count: { _all: true } }),
    ]);

    const customerCount = new Map(customers.map((c) => [c.instanceId, c._count._all]));
    const inquiryCount = new Map(inquiries.map((i) => [i.instanceId, i._count._all]));

    return NextResponse.json(
      rows.map((row) => ({
        id: row.id,
        instanceId: row.instanceId,
        orgName: readOrgName(row.instance.orgJson),
        systemId: row.instance.systemId,
        demo: row.instance.demo,
        theme: row.theme,
        published: row.published,
        views: row.views,
        launchedAt: row.launchedAt ? row.launchedAt.toISOString() : null,
        createdAt: row.createdAt.toISOString(),
        customers: customerCount.get(row.instanceId) ?? 0,
        inquiries: inquiryCount.get(row.instanceId) ?? 0,
      }))
    );
  } catch (error) {
    console.error("GET /api/admin/sites failed:", error);
    return NextResponse.json({ error: "Failed to load sites" }, { status: 500 });
  }
}
