import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/server/admin-session";

export const dynamic = "force-dynamic";

/** Lenient org-name read (same contract as ../route.ts). */
function readOrgName(raw: string): string {
  if (!raw) return "—";
  try {
    const parsed: unknown = JSON.parse(raw);
    if (parsed && typeof parsed === "object" && "name" in parsed) {
      const name = (parsed as { name?: unknown }).name;
      if (typeof name === "string" && name.trim().length > 0) return name.trim();
    }
  } catch {
    /* fail-soft */
  }
  return "—";
}

const WEEKS = 12;
const WEEK_MS = 7 * 86_400_000;

/**
 * GET /api/admin/sites/trends — customer analytics over time (round 31).
 *
 * Trailing 12 weekly buckets (7-day windows ending "now") of:
 *  - customer-account signups per site (SiteCustomer.createdAt),
 *  - public inquiries per instance (SupportTicket, source "public"),
 * plus platform totals (active/banned, 7-day deltas, 30-day signups) and the
 * top sites by signups in the window. Any authed admin.
 *
 * ROUND 36 (perf) — totals come from SQL counts/groupBy and the weekly
 * series only loads rows INSIDE the 12-week window (the former path pulled
 * entire tables into memory).
 */
export async function GET() {
  const guard = await requireAdmin();
  if (guard instanceof NextResponse) return guard;

  try {
    const now = Date.now();
    const windowStart = new Date(now - WEEKS * WEEK_MS);

    /* ROUND 87 — LIVE rows only: trashed (soft-deleted) customers and the
     * sites of trashed workspaces never feed the trends analytics. */
    const [
      customerTotal,
      customersByStatus,
      perSiteTotals,
      windowCustomers,
      inquiryTotal,
      windowInquiries,
      sites,
    ] = await Promise.all([
      db.siteCustomer.count({ where: { deletedAt: null } }),
      db.siteCustomer.groupBy({ by: ["status"], _count: { _all: true }, where: { deletedAt: null } }),
      db.siteCustomer.groupBy({ by: ["instanceId"], _count: { _all: true }, where: { deletedAt: null } }),
      db.siteCustomer.findMany({
        where: { createdAt: { gte: windowStart }, deletedAt: null },
        select: { instanceId: true, createdAt: true },
        take: 5000,
      }),
      db.supportTicket.count({ where: { source: "public" } }),
      db.supportTicket.findMany({
        where: { source: "public", createdAt: { gte: windowStart } },
        select: { instanceId: true, createdAt: true },
        take: 5000,
      }),
      db.site.findMany({
        where: { instance: { deletedAt: null } },
        select: {
          instanceId: true,
          published: true,
          instance: { select: { orgJson: true, systemId: true } },
        },
        take: 500,
      }),
    ]);

    const bucketOf = (t: number) => {
      const age = now - t;
      if (age < 0 || age >= WEEKS * WEEK_MS) return -1;
      return WEEKS - 1 - Math.floor(age / WEEK_MS);
    };

    const weeks = Array.from({ length: WEEKS }, () => ({ signups: 0, inquiries: 0 }));
    const perSite = new Map<string, { signups: number; customers: number }>();
    for (const group of perSiteTotals) {
      perSite.set(group.instanceId, { signups: 0, customers: group._count._all });
    }
    /* round 32 — per-site weekly series (aligned with `weeks`) for the
     * sparkline column in the admin Sites table */
    const perSiteSeries = new Map<string, number[]>();
    const seriesFor = (instanceId: string): number[] => {
      let s = perSiteSeries.get(instanceId);
      if (!s) {
        s = Array.from({ length: WEEKS }, () => 0);
        perSiteSeries.set(instanceId, s);
      }
      return s;
    };

    for (const c of windowCustomers) {
      const site = perSite.get(c.instanceId) ?? { signups: 0, customers: 0 };
      const b = bucketOf(new Date(c.createdAt).getTime());
      if (b >= 0) {
        weeks[b].signups += 1;
        site.signups += 1;
        seriesFor(c.instanceId)[b] += 1;
      }
      perSite.set(c.instanceId, site);
    }

    for (const t of windowInquiries) {
      const b = bucketOf(new Date(t.createdAt).getTime());
      if (b >= 0) {
        weeks[b].inquiries += 1;
      }
    }

    const statusCount = (status: string) =>
      customersByStatus.find((g) => g.status === status)?._count._all ?? 0;

    const totals = {
      customers: customerTotal,
      active: statusCount("active"),
      banned: statusCount("banned"),
      inquiries: inquiryTotal,
      signups7d: weeks[WEEKS - 1].signups,
      signupsPrev7d: weeks[WEEKS - 2].signups,
      signups30d: weeks.slice(-4).reduce((s, w) => s + w.signups, 0),
      avgPerWeek:
        Math.round(
          (weeks.reduce((s, w) => s + w.signups, 0) / WEEKS) * 10
        ) / 10,
    };

    const orgByInstance = new Map(
      sites.map((s) => [s.instanceId, readOrgName(s.instance.orgJson)])
    );
    const systemByInstance = new Map(
      sites.map((s) => [s.instanceId, s.instance.systemId])
    );

    const topSites = [...perSite.entries()]
      .filter(([id, v]) => v.customers > 0 && orgByInstance.has(id))
      .sort((a, b) => b[1].signups - a[1].signups || b[1].customers - a[1].customers)
      .slice(0, 4)
      .map(([id, v]) => ({
        instanceId: id,
        orgName: orgByInstance.get(id) ?? "—",
        systemId: systemByInstance.get(id) ?? "",
        signups: v.signups,
        customers: v.customers,
      }));

    return NextResponse.json({
      weeks: weeks.map((w, i) => ({
        /* window start (inclusive) — the client formats + labels it */
        start: new Date(now - (WEEKS - i) * WEEK_MS).toISOString(),
        signups: w.signups,
        inquiries: w.inquiries,
      })),
      totals,
      topSites,
      perSite: Object.fromEntries(perSiteSeries.entries()),
    });
  } catch (error) {
    console.error("GET /api/admin/sites/trends failed:", error);
    return NextResponse.json({ error: "Failed to load site trends" }, { status: 500 });
  }
}
