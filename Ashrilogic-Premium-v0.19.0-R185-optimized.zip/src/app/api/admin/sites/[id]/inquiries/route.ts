import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toTicketDTO } from "@/lib/server/admin-mapper";
import { requireAdmin } from "@/lib/server/admin-session";
import type { SiteInquiryTriageDTO } from "@/lib/types";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/** Max triage rows served (newest activity first) — mirrors the owner route. */
const TRIAGE_CAP = 200;

/**
 * ROUND 77 — GET /api/admin/sites/[id]/inquiries
 *
 * The Super Admin's triage inbox for ONE public website (the [id] is the
 * Site's INSTANCE id): every support inquiry filed through that site's
 * contact form (source "public", instance-scoped), with the full text so an
 * admin can read AND reply without impersonating the workspace owner.
 *
 * This is the platform-side twin of ROUND 74's owner route
 * (/api/instances/[id]/site/inquiries) — same blind-index join, same DTO,
 * same cap. Optional `?customer=<siteCustomerId>` drills into ONE customer
 * (resolved through the email blind index server-side — the address never
 * travels in the query string). Any authenticated admin/moderator (read).
 */
export async function GET(req: Request, { params }: RouteContext) {
  const guard = await requireAdmin(["super", "admin", "moderator"]);
  if (guard instanceof NextResponse) return guard;

  const { id } = await params;

  try {
    const site = await db.site.findUnique({
      where: { instanceId: id },
      select: { instanceId: true },
    });
    if (!site) {
      return NextResponse.json(
        { error: "This workspace has no website yet", code: "SITE_NOT_FOUND" },
        { status: 404 }
      );
    }

    /* optional per-customer drill-down — the blind index is resolved from
     * the SiteCustomer row (which must belong to THIS instance) so the
     * filter can never be aimed at another workspace's tickets.
     * ROUND 87 — a trashed (soft-deleted) customer 404s like any vanished
     * row. */
    const customerParam = new URL(req.url).searchParams.get("customer");
    let emailIndex: string | null = null;
    if (customerParam) {
      const customer = await db.siteCustomer.findUnique({
        where: { id: customerParam, deletedAt: null },
        select: { emailIndex: true, instanceId: true },
      });
      if (!customer || customer.instanceId !== id) {
        return NextResponse.json({ error: "Customer not found" }, { status: 404 });
      }
      emailIndex = customer.emailIndex;
    }

    const rows = await db.supportTicket.findMany({
      where: {
        instanceId: id,
        source: "public",
        ...(emailIndex !== null ? { requesterEmailIndex: emailIndex } : {}),
      },
      orderBy: [{ updatedAt: "desc" }, { id: "desc" }],
      take: TRIAGE_CAP,
    });

    /* replyUnread — a drafted reply the customer hasn't opened yet (drives
     * the «لم يقرأه العميل» chip in the triage dialog). */
    const rowsDto: SiteInquiryTriageDTO[] = rows.map((row) => ({
      ...toTicketDTO(row),
      replyUnread: row.reply != null && row.replyReadAt == null,
    }));

    return NextResponse.json(rowsDto);
  } catch (error) {
    console.error(`GET /api/admin/sites/${id}/inquiries failed:`, error);
    return NextResponse.json({ error: "Failed to list site inquiries" }, { status: 500 });
  }
}
