import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toTicketDTO, ticketUpdateSchema, zodError } from "@/lib/server/admin-mapper";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import type { SiteInquiryTriageDTO } from "@/lib/types";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string; ticketId: string }> };

/**
 * ROUND 77 — PATCH /api/admin/sites/[id]/inquiries/[ticketId]
 *
 * The Super Admin's triage write on ONE public inquiry of a workspace's
 * website (fired from the sites-customers sheet): { reply?, status?,
 * priority? } (any combination, at least one). Super/admin only.
 *
 * Security posture (mirrors ROUND 74's owner route exactly):
 *  - the ticket is looked up with `id AND instanceId AND source:"public"` —
 *    a foreign workspace's ticket id (or an internal/billing ticket) can
 *    never be touched from here (404, no oracle);
 *  - a fresh reply RESETS replyReadAt (the customer's account button
 *    re-badges with the unread count);
 *  - a reply on a resolved/closed thread without an explicit status
 *    re-opens the conversation as "pending";
 *  - the write lands in the audit trail as admin.siteInquiryTriage.
 */
export async function PATCH(req: Request, { params }: RouteContext) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const { id, ticketId } = await params;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = ticketUpdateSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const data = parsed.data;

  try {
    /* instance-scoped existence check — anything that is not THIS
     * workspace's public website inquiry is a flat 404. */
    const existing = await db.supportTicket.findFirst({
      where: { id: ticketId, instanceId: id, source: "public" },
      select: { id: true, status: true },
    });
    if (!existing) {
      return NextResponse.json({ error: "Inquiry not found" }, { status: 404 });
    }

    /* a new reply re-opens a resolved/closed thread so the requester
     * sees the conversation continue (mirrors the admin triage route). */
    const shouldReopen = data.reply !== undefined && data.status === undefined;
    const status =
      shouldReopen && ["resolved", "closed"].includes(existing.status)
        ? "pending"
        : data.status;

    const row = await db.supportTicket.update({
      where: { id: ticketId },
      data: {
        ...(status !== undefined ? { status } : {}),
        ...(data.priority !== undefined ? { priority: data.priority } : {}),
        /* a fresh reply is unread until the customer opens the history */
        ...(data.reply !== undefined ? { reply: data.reply, replyReadAt: null } : {}),
      },
    });

    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "admin.siteInquiryTriage",
      targetLabel: row.subject.slice(0, 120),
      meta: {
        site: id,
        ...(status !== undefined ? { status } : {}),
        ...(data.priority !== undefined ? { priority: data.priority } : {}),
        ...(data.reply !== undefined ? { reply: "sent" } : {}),
      },
    });

    const dto: SiteInquiryTriageDTO = {
      ...toTicketDTO(row),
      replyUnread: data.reply !== undefined,
    };
    return NextResponse.json(dto);
  } catch (error) {
    console.error(`PATCH /api/admin/sites/${id}/inquiries/${ticketId} failed:`, error);
    return NextResponse.json({ error: "Failed to update inquiry" }, { status: 500 });
  }
}
