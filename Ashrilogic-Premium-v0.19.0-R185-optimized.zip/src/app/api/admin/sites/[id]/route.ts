import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { readOrgName } from "@/app/api/admin/sites/route";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";

export const dynamic = "force-dynamic";

const publishSchema = z.object({
  published: z.boolean(),
});

/**
 * PATCH /api/admin/sites/[id] — publish / unpublish a public website from the
 * control panel (round 27). Mirrors the owner-side launch switch and writes
 * the same audit trail (actor = admin). Requires super/admin.
 */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const { id } = await params;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = publishSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: "published (boolean) is required" }, { status: 400 });
  }

  try {
    const existing = await db.site.findUnique({
      where: { id },
      include: { instance: { select: { orgJson: true } } },
    });
    if (!existing) {
      return NextResponse.json({ error: "Site not found" }, { status: 404 });
    }

    const row = await db.site.update({
      where: { id },
      data: {
        published: parsed.data.published,
        /* publishing from the control panel stamps the launch moment too */
        ...(parsed.data.published && !existing.launchedAt ? { launchedAt: new Date() } : {}),
      },
    });

    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "instance.siteUpdate",
      targetLabel: readOrgName(existing.instance.orgJson),
      meta: { published: String(parsed.data.published), surface: "admin-sites" },
    });

    return NextResponse.json({
      ok: true,
      site: {
        id: row.id,
        instanceId: row.instanceId,
        theme: row.theme,
        published: row.published,
        views: row.views,
        launchedAt: row.launchedAt ? row.launchedAt.toISOString() : null,
      },
    });
  } catch (error) {
    console.error("PATCH /api/admin/sites/[id] failed:", error);
    return NextResponse.json({ error: "Failed to update site" }, { status: 500 });
  }
}
