import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { siteCustomerModerateSchema, toSiteCustomerAdminDTO, zodError } from "@/lib/server/admin-mapper";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { decryptField } from "@/lib/server/crypto-vault";
import { readJson } from "@/lib/server/http";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import {
  issueVerifyToken,
  orgDisplayName,
  sendVerificationEmail,
  verificationUrl,
} from "@/lib/server/verification";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string; customerId: string }> };

/** staff re-dispatch throttle (mirrors the customer + owner routes). */
const STAFF_RESEND_RULE = { limit: 1, windowMs: 60 * 1000 };

/** the fresh row projection shared by the verify + status paths below. */
async function freshCustomerDTO(instanceId: string, customerId: string, email: string) {
  const row = await db.siteCustomer.findUniqueOrThrow({
    where: { id: customerId },
    select: {
      id: true,
      name: true,
      email: true,
      emailIndex: true,
      phone: true,
      status: true,
      lastLoginAt: true,
      createdAt: true,
      updatedAt: true,
      emailVerifiedAt: true,
    },
  });
  const inquiries = row.emailIndex
    ? await db.supportTicket.count({
        where: { instanceId, source: "public", requesterEmailIndex: row.emailIndex },
      })
    : 0;
  return {
    ok: true as const,
    customer: toSiteCustomerAdminDTO(
      { ...row, email, phone: decryptField(row.phone) ?? null },
      inquiries
    ),
  };
}

/**
 * PATCH /api/admin/sites/[id]/customers/[customerId] — moderate one customer
 * account on a public website (round 28): ban blocks future sign-ins and
 * cuts off live sessions (the /me guard rejects banned accounts); unban
 * restores access. Super/admin only, audit-logged.
 *
 * ROUND 75 — the body also accepts { verify: true } (staff-assisted email
 * confirmation) and { resendVerify: true } (re-dispatch the single-use
 * verification mail through the platform mailer — the admin never sees
 * the link). Audit: siteCustomer.verify / siteCustomer.verifyResend.
 */
export async function PATCH(req: Request, { params }: RouteContext) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const { id, customerId } = await params;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = siteCustomerModerateSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const { status, verify, resendVerify } = parsed.data;

  try {
    const existing = await db.siteCustomer.findUnique({
      where: { id: customerId },
      select: {
        id: true,
        instanceId: true,
        name: true,
        email: true,
        status: true,
        emailVerifiedAt: true,
      },
    });
    if (!existing || existing.instanceId !== id) {
      return NextResponse.json({ error: "Customer not found on this site" }, { status: 404 });
    }
    const email = decryptField(existing.email) ?? "";

    /* ---- ROUND 75 staff-assisted verification ---- */
    if (verify || resendVerify) {
      if (resendVerify) {
        if (
          await rateLimited(`verify-resend:${customerId}:${clientIp(req)}`, STAFF_RESEND_RULE, {
            failClosed: true,
          })
        ) {
          return tooManyRequests(STAFF_RESEND_RULE, { error: "Please wait a minute between dispatches", code: "RESEND_COOLDOWN" });
        }
        const orgName = await orgDisplayName(id);
        const { token } = await issueVerifyToken(customerId);
        const sent = await sendVerificationEmail({
          to: email,
          name: existing.name,
          url: verificationUrl(new URL(req.url).origin, id, token),
          orgName,
        });
        await logAudit({
          actorType: "admin",
          actorId: guard.user.id,
          actorName: guard.user.username,
          action: "siteCustomer.verifyResend",
          targetLabel: maskEmail(email),
          meta: { site: id, customer: customerId, sent: String(sent) },
        });
        return NextResponse.json(await freshCustomerDTO(id, customerId, email));
      }

      if (existing.emailVerifiedAt) {
        return NextResponse.json(
          { error: "Customer already verified", code: "ALREADY_VERIFIED" },
          { status: 409 }
        );
      }
      await db.siteCustomer.update({
        where: { id: customerId },
        data: { emailVerifiedAt: new Date(), verifyTokenHash: null, verifyTokenExpiresAt: null },
      });
      await logAudit({
        actorType: "admin",
        actorId: guard.user.id,
        actorName: guard.user.username,
        action: "siteCustomer.verify",
        targetLabel: maskEmail(email),
        meta: { site: id, customer: customerId },
      });
      return NextResponse.json(await freshCustomerDTO(id, customerId, email));
    }

    /* ---- classic status moderation (round 28) ---- */
    if (!status) {
      return NextResponse.json({ error: "Nothing to do" }, { status: 422 });
    }
    if (existing.status === status) {
      return NextResponse.json({ error: "Customer already in this state" }, { status: 409 });
    }

    const row = await db.siteCustomer.update({
      where: { id: customerId },
      data: { status },
      select: { id: true, name: true, email: true, status: true },
    });

    /* ROUND 37 — audit PII: masked email only; the row is correlated via
       the customer id kept in meta. The response DTO is rebuilt through
       freshCustomerDTO (decrypted fields + live inquiry join — matches the
       next GET exactly). */
    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "siteCustomer.moderate",
      targetLabel: `${maskEmail(decryptField(row.email) ?? "")} · ${status}`,
      meta: { site: id, customer: customerId, status },
    });

    return NextResponse.json(await freshCustomerDTO(id, customerId, decryptField(row.email) ?? ""));
  } catch (error) {
    console.error(`PATCH /api/admin/sites/${id}/customers/${customerId} failed:`, error);
    return NextResponse.json({ error: "Failed to update customer" }, { status: 500 });
  }
}

/**
 * DELETE /api/admin/sites/[id]/customers/[customerId] — permanently remove a
 * customer account from a public website (their filed inquiries remain in the
 * support inbox). Super/admin only, audit-logged.
 */
export async function DELETE(_req: Request, { params }: RouteContext) {
  const guard = await requireAdmin(["super", "admin"], _req);
  if (guard instanceof NextResponse) return guard;

  const { id, customerId } = await params;

  try {
    const existing = await db.siteCustomer.findUnique({
      where: { id: customerId },
      select: { id: true, instanceId: true, email: true, name: true, deletedAt: true },
    });
    if (!existing || existing.instanceId !== id || existing.deletedAt) {
      return NextResponse.json({ error: "Customer not found on this site" }, { status: 404 });
    }

    /* ROUND 87 (trash) — soft delete: the customer moves to the workspace
       trash (email blind index mangled; orders stay attached + restorable).
       The customer's live sessions die with the epoch bump. */
    await db.siteCustomer.update({
      where: { id: existing.id },
      data: { sessionVersion: { increment: 1 } },
    });
    const { softDelete } = await import("@/lib/server/trash");
    const result = await softDelete("siteCustomer", existing.id, {
      kind: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
    }, { instanceScope: id });
    if (!result.ok) {
      return NextResponse.json({ error: "Failed to delete customer" }, { status: result.status });
    }
    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "siteCustomer.delete",
      /* ROUND 37 — masked email; correlation via the customer id in meta */
      targetLabel: maskEmail(decryptField(existing.email) ?? ""),
      meta: { site: id, customer: customerId, name: existing.name, soft: "true" },
    });

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error(`DELETE /api/admin/sites/${id}/customers/${customerId} failed:`, error);
    return NextResponse.json({ error: "Failed to delete customer" }, { status: 500 });
  }
}
