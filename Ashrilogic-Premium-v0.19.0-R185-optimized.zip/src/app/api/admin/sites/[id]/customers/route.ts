import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toSiteCustomerAdminDTO } from "@/lib/server/admin-mapper";
import { requireAdmin } from "@/lib/server/admin-session";
import { decryptField } from "@/lib/server/crypto-vault";

export const dynamic = "force-dynamic";

/**
 * GET /api/admin/sites/[id]/customers — the registered customer accounts of
 * one public website (round 28, admin Sites view → customer manager sheet).
 *
 * The [id] path parameter is the Site's INSTANCE id (the public URL slug).
 * Each row joins a live inquiry count: support tickets linked to this
 * instance whose requester email matches the customer (source public).
 * Any authenticated admin.
 */
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const guard = await requireAdmin(["super", "admin", "moderator"]);
  if (guard instanceof NextResponse) return guard;

  const { id } = await params;

  try {
    const site = await db.site.findUnique({
      where: { instanceId: id },
      select: { instanceId: true },
    });
    if (!site) {
      return NextResponse.json({ error: "Site not found" }, { status: 404 });
    }

    /* ROUND 87 — trashed (soft-deleted) customer rows vanish from the admin
     * customer manager (they live in the trash engine's own surface). */
    const customers = await db.siteCustomer.findMany({
      where: { instanceId: id, deletedAt: null },
      orderBy: [{ createdAt: "desc" }],
      select: {
        id: true,
        name: true,
        email: true,
        emailIndex: true,
        phone: true,
        status: true,
        lastLoginAt: true,
        createdAt: true,
        updatedAt: true,
        /* ROUND 75 — verification state for the admin sheet chips */
        emailVerifiedAt: true,
      },
      take: 500,
    });

    /* inquiry counts — public tickets linked to this instance, matched via
       the customer's email. ROUND 36 (perf): tickets are matched through the
       requesterEmailIndex BLIND INDEX (no per-ticket AES-GCM decrypt) and
       each customer email is decrypted ONCE (was twice per row). */
    const tickets = await db.supportTicket.groupBy({
      by: ["requesterEmailIndex"],
      where: { instanceId: id, source: "public" },
      _count: { _all: true },
    });
    const inquiriesByIndex = new Map<string, number>();
    for (const ticket of tickets) {
      if (ticket.requesterEmailIndex) {
        inquiriesByIndex.set(ticket.requesterEmailIndex, ticket._count._all);
      }
    }

    /* ROUND 77 — OPEN (open+pending) inquiries of the whole site: drives
       the amber "مفتوحة الآن" sub-badge on the KPI cell so staff triage
       backlog is visible BEFORE opening the dialog. */
    const openInquiries = await db.supportTicket.count({
      where: { instanceId: id, source: "public", status: { in: ["open", "pending"] } },
    });

    const rows = customers.map((row) => {
      const email = decryptField(row.email) ?? "";
      return toSiteCustomerAdminDTO(
        {
          ...row,
          email,
          phone: decryptField(row.phone) ?? null,
        },
        inquiriesByIndex.get(row.emailIndex ?? "") ?? 0
      );
    });

    return NextResponse.json({
      customers: rows,
      counts: {
        total: rows.length,
        active: rows.filter((c) => c.status === "active").length,
        banned: rows.filter((c) => c.status === "banned").length,
        inquiries: rows.reduce((sum, c) => sum + c.inquiries, 0),
        openInquiries,
      },
    });
  } catch (error) {
    console.error(`GET /api/admin/sites/${id}/customers failed:`, error);
    return NextResponse.json({ error: "Failed to list site customers" }, { status: 500 });
  }
}
