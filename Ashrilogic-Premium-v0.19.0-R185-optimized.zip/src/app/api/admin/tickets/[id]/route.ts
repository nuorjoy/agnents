import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toTicketDTO, ticketUpdateSchema, zodError } from "@/lib/server/admin-mapper";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { notifyEvent } from "@/lib/server/platform-notifications";

export const dynamic = "force-dynamic";

/**
 * PATCH /api/admin/tickets/[id] — triage update: status, priority or reply.
 * Sending a reply on a closed/resolved ticket re-opens the conversation.
 * Requires super/admin/moderator.
 */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const guard = await requireAdmin(["super", "admin", "moderator"], req);
  if (guard instanceof NextResponse) return guard;

  const { id } = await params;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = ticketUpdateSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const data = parsed.data;

  try {
    const existing = await db.supportTicket.findUnique({
      where: { id },
      select: { id: true, status: true, priority: true, subject: true },
    });
    if (!existing) {
      return NextResponse.json({ error: "Ticket not found" }, { status: 404 });
    }

    // A new reply re-opens a closed/resolved ticket so the requester sees it.
    const shouldReopen = data.reply !== undefined && data.status === undefined;
    const status = shouldReopen && ["resolved", "closed"].includes(existing.status)
      ? "pending"
      : data.status;

    const row = await db.supportTicket.update({
      where: { id },
      data: {
        ...(status !== undefined ? { status } : {}),
        ...(data.priority !== undefined ? { priority: data.priority } : {}),
        ...(data.reply !== undefined ? { reply: data.reply } : {}),
      },
    });
    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "ticket.update",
      targetLabel: row.subject.slice(0, 120),
      meta: {
        ...(status !== undefined ? { status } : {}),
        ...(data.priority !== undefined ? { priority: data.priority } : {}),
        ...(data.reply !== undefined ? { reply: "sent" } : {}),
      },
    });
    /* ROUND 89 — the «إشعارات البريد» toggle's second event: a ticket just
     * got triaged INTO the urgent lane (high/urgent) from something lower.
     * Fire-and-safe — the triage already succeeded. */
    const escalated =
      data.priority !== undefined &&
      ["high", "urgent"].includes(data.priority) &&
      !["high", "urgent"].includes(existing.priority ?? "");
    if (escalated) {
      const priority = data.priority as string;
      void notifyEvent({
        eventKey: "ticket.urgent",
        title: `تذكرة ${priority === "urgent" ? "عاجلة جداً" : "عالية الأولوية"}: ${row.subject.slice(0, 60)}`,
        body: `رفع ${guard.user.name} أولوية التذكرة إلى «${priority}». الحالة الحالية: ${row.status}.`,
        meta: { ticket: row.id, priority, status: row.status },
      }).catch(() => undefined);
    }
    return NextResponse.json(toTicketDTO(row));
  } catch (error) {
    console.error("PATCH /api/admin/tickets/[id] failed:", error);
    return NextResponse.json({ error: "Failed to update ticket" }, { status: 500 });
  }
}

/**
 * DELETE /api/admin/tickets/[id] — permanently remove a ticket.
 * Requires super/admin.
 */
export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const guard = await requireAdmin(["super", "admin"], _req);
  if (guard instanceof NextResponse) return guard;

  const { id } = await params;
  try {
    const existing = await db.supportTicket.findUnique({
      where: { id },
      select: { id: true, subject: true },
    });
    if (!existing) {
      return NextResponse.json({ error: "Ticket not found" }, { status: 404 });
    }
    await db.supportTicket.delete({ where: { id } });
    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "ticket.delete",
      targetLabel: existing.subject.slice(0, 120),
    });
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("DELETE /api/admin/tickets/[id] failed:", error);
    return NextResponse.json({ error: "Failed to delete ticket" }, { status: 500 });
  }
}
