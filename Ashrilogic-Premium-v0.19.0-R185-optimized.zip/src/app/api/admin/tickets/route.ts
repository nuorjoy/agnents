import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  seedAdminDefaults,
  ticketBulkDeleteSchema,
  ticketBulkUpdateSchema,
  ticketCreateSchema,
  toTicketDTO,
  zodError,
} from "@/lib/server/admin-mapper";
import { blindIndex, encryptField } from "@/lib/server/crypto-vault";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";

export const dynamic = "force-dynamic";

/**
 * GET /api/admin/tickets — the support inbox, newest first.
 * Seeds a few representative sample tickets on an empty table.
 * Any authenticated admin.
 */
export async function GET() {
  const guard = await requireAdmin();
  if (guard instanceof NextResponse) return guard;

  try {
    await seedAdminDefaults(db);
    const rows = await db.supportTicket.findMany({
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: 200,
    });
    /* ROUND 37 — PII minimization: a read-only `viewer` session sees MASKED
       requester emails (maskEmail keeps the first character + domain for
       correlation); moderator/admin/super keep the full address because
       they triage and reply. DTO shape is unchanged — only the value. */
    const dtos = rows.map(toTicketDTO);
    const visible =
      guard.user.role === "viewer"
        ? dtos.map((t) => ({ ...t, requesterEmail: maskEmail(t.requesterEmail) }))
        : dtos;
    return NextResponse.json(visible);
  } catch (error) {
    console.error("GET /api/admin/tickets failed:", error);
    return NextResponse.json({ error: "Failed to list tickets" }, { status: 500 });
  }
}

/**
 * PATCH /api/admin/tickets — round-28 BULK triage: apply one status and/or
 * priority to MANY tickets at once ({ ids, status?, priority? }).
 * updateMany + a single audit row. Requires super/admin/moderator.
 */
export async function PATCH(req: Request) {
  const guard = await requireAdmin(["super", "admin", "moderator"], req);
  if (guard instanceof NextResponse) return guard;

  const read = await readJson(req);
  if (!read.ok) return read.response;

  const parsed = ticketBulkUpdateSchema.safeParse(read.data);
  if (!parsed.success) {
    return NextResponse.json(
      { error: zodError(parsed.error) || "ids[] and at least one of status / priority are required" },
      { status: 400 }
    );
  }
  const { ids, status, priority } = parsed.data;

  try {
    const data: { status?: string; priority?: string } = {};
    if (status !== undefined) data.status = status;
    if (priority !== undefined) data.priority = priority;

    const result = await db.supportTicket.updateMany({
      where: { id: { in: ids } },
      data,
    });

    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "ticket.bulkUpdate",
      targetLabel: `${result.count} ticket(s)`,
      meta: {
        ...(status !== undefined ? { status } : {}),
        ...(priority !== undefined ? { priority } : {}),
        bulk: "true",
      },
    });

    return NextResponse.json({ ok: true, updated: result.count });
  } catch (error) {
    console.error("PATCH /api/admin/tickets (bulk) failed:", error);
    return NextResponse.json({ error: "Bulk update failed" }, { status: 500 });
  }
}

/**
 * DELETE /api/admin/tickets — round-28 BULK delete ({ ids }): remove many
 * tickets at once (deleteMany + a single audit row). Requires super/admin.
 */
export async function DELETE(req: Request) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const read = await readJson(req);
  if (!read.ok) return read.response;

  const parsed = ticketBulkDeleteSchema.safeParse(read.data);
  if (!parsed.success) {
    return NextResponse.json({ error: "ids[] (1..200) required" }, { status: 400 });
  }

  try {
    const result = await db.supportTicket.deleteMany({
      where: { id: { in: parsed.data.ids } },
    });
    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "ticket.bulkDelete",
      targetLabel: `${result.count} ticket(s) deleted`,
      meta: { bulk: "true", deleted: String(result.count) },
    });
    return NextResponse.json({ ok: true, removed: result.count });
  } catch (error) {
    console.error("DELETE /api/admin/tickets (bulk) failed:", error);
    return NextResponse.json({ error: "Bulk delete failed" }, { status: 500 });
  }
}

/**
 * POST /api/admin/tickets — file a new ticket (used by the panel and
 * available for future public intake). instanceId is optional and, when
 * provided, must reference an existing instance. Requires super/admin.
 */
export async function POST(req: Request) {
  const guard = await requireAdmin(["super", "admin", "moderator"], req);
  if (guard instanceof NextResponse) return guard;

  const read = await readJson(req);
  if (!read.ok) return read.response;

  const parsed = ticketCreateSchema.safeParse(read.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const data = parsed.data;

  try {
    if (data.instanceId) {
      /* ROUND 87 — tickets link to LIVE workspaces only (a trashed
       * instance is "Unknown" here). */
      const instance = await db.instance.findUnique({
        where: { id: data.instanceId, deletedAt: null },
        select: { id: true },
      });
      if (!instance) {
        return NextResponse.json({ error: "Unknown instance" }, { status: 404 });
      }
    }

    const row = await db.supportTicket.create({
      data: {
        subject: data.subject,
        message: data.message,
        requesterName: data.requesterName,
        /* round 35 — sealed at rest + blind-indexed */
        requesterEmail: encryptField(data.requesterEmail) ?? "",
        requesterEmailIndex: blindIndex(data.requesterEmail) ?? "",
        category: data.category,
        priority: data.priority,
        instanceId: data.instanceId ?? null,
      },
    });
    return NextResponse.json(toTicketDTO(row), { status: 201 });
  } catch (error) {
    console.error("POST /api/admin/tickets failed:", error);
    return NextResponse.json({ error: "Failed to create ticket" }, { status: 500 });
  }
}
