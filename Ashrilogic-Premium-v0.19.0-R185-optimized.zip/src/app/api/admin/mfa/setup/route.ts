import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import {rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import {
  confirmMfaEnrollment,
  getMfaStatus,
  otpauthQrSvg,
  startMfaEnrollment,
} from "@/lib/server/mfa";

export const dynamic = "force-dynamic";

/** Enrollment throttling: 6 starts / 10 min per admin. */
const SETUP_RULE = { limit: 6, windowMs: 10 * 60 * 1000 };

/**
 * ROUND 45 — admin TOTP enrollment (two-step), for every admin account.
 *
 * GET   — status for the settings screen: { enabled, pending, backupCodesLeft }
 * POST  — START: mints a fresh sealed secret (disabled) and returns the
 *         otpauth URI + a server-rendered QR SVG. Restarting an unconfirmed
 *         enrollment is allowed; a CONFIRMED one must be disabled first.
 * PUT   — CONFIRM: { code } verifies a live code, ENABLES MFA and returns
 *         the ten one-time backup codes (their only plaintext moment).
 *
 * The sealed secret is NEVER returned after this step — the QR is the only
 * channel, and it exists solely inside the enrollment response.
 */
export async function GET() {
  const guard = await requireAdmin(undefined);
  if (guard instanceof NextResponse) return guard;
  return NextResponse.json(await getMfaStatus("admin", guard.user.id));
}

export async function POST(req: Request) {
  const guard = await requireAdmin(undefined, req);
  if (guard instanceof NextResponse) return guard;
  const user = guard.user;

  if (await rateLimited(`admin-mfa-setup:${user.id}`, SETUP_RULE, { failClosed: true })) {
    return tooManyRequests(SETUP_RULE, { error: "Too many enrollment attempts — try again later" });
  }

  const label = user.email.includes("@") ? user.email : user.username;
  const started = await startMfaEnrollment("admin", user.id, label);
  if ("alreadyEnabled" in started) {
    return NextResponse.json(
      { error: "Two-factor is already enabled — disable it first" },
      { status: 409 }
    );
  }

  await logAudit({
    actorType: "admin",
    actorId: user.id,
    actorName: user.username,
    action: "admin.update",
    targetLabel: "two-factor enrollment",
    meta: { mfa: "setup-started" },
  });

  return NextResponse.json({
    otpauth: started.otpauth,
    secret: started.secret,
    qrSvg: await otpauthQrSvg(started.otpauth),
  });
}

export async function PUT(req: Request) {
  const guard = await requireAdmin(undefined, req);
  if (guard instanceof NextResponse) return guard;
  const user = guard.user;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const code = (body.data as { code?: unknown }).code;
  if (typeof code !== "string" || !/^\d{6}$/.test(code.trim())) {
    return NextResponse.json({ error: "Enter the 6-digit code from your app" }, { status: 400 });
  }

  const result = await confirmMfaEnrollment("admin", user.id, code.trim());
  if (!result.ok) {
    return NextResponse.json(
      {
        error:
          result.reason === "invalid"
            ? "Incorrect code — try again"
            : "Start the enrollment first",
      },
      { status: 400 }
    );
  }

  await logAudit({
    actorType: "admin",
    actorId: user.id,
    actorName: user.username,
    action: "admin.update",
    targetLabel: "two-factor authentication",
    meta: { mfa: "enabled" },
  });

  return NextResponse.json({
    ok: true,
    backupCodes: result.backupCodes,
    status: await getMfaStatus("admin", user.id),
  });
}
