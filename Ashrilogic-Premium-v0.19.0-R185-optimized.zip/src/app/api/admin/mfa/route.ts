import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import {rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import {
  disableMfa,
  getMfaStatus,
  regenerateBackupCodes,
} from "@/lib/server/mfa";

export const dynamic = "force-dynamic";

/** Management-action throttling: 10 / 10 min per admin (disarm + regen). */
const MGMT_RULE = { limit: 10, windowMs: 10 * 60 * 1000 };

/**
 * ROUND 45 — POST /api/admin/mfa — MFA management for the signed-in admin.
 *
 * body { action: "disable" | "regenerate-backups", code } — both actions
 * require a live TOTP code or an unused backup code, so an attacker with a
 * stolen session cookie can never silently disarm the second factor.
 *
 * Enrollment (start/confirm) + status live in /api/admin/mfa/setup.
 */
export async function POST(req: Request) {
  const guard = await requireAdmin(undefined, req);
  if (guard instanceof NextResponse) return guard;
  const user = guard.user;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const action = (body.data as { action?: unknown }).action;
  const code = (body.data as { code?: unknown }).code;
  if (
    typeof action !== "string" ||
    typeof code !== "string" ||
    !/^[0-9A-Za-z-]{4,20}$/.test(code.trim())
  ) {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }

  if (await rateLimited(`admin-mfa-mgmt:${user.id}`, MGMT_RULE, { failClosed: true })) {
    return tooManyRequests(MGMT_RULE, { error: "Too many attempts — try again later" });
  }

  if (action === "disable") {
    const ok = await disableMfa("admin", user.id, code.trim());
    if (!ok) {
      return NextResponse.json({ error: "Incorrect verification code" }, { status: 401 });
    }
    await logAudit({
      actorType: "admin",
      actorId: user.id,
      actorName: user.username,
      action: "admin.update",
      targetLabel: "two-factor authentication",
      meta: { mfa: "disabled" },
    });
    return NextResponse.json({ ok: true, status: await getMfaStatus("admin", user.id) });
  }

  if (action === "regenerate-backups") {
    const result = await regenerateBackupCodes("admin", user.id, code.trim());
    if (!result.ok) {
      return NextResponse.json({ error: "Incorrect verification code" }, { status: 401 });
    }
    await logAudit({
      actorType: "admin",
      actorId: user.id,
      actorName: user.username,
      action: "admin.update",
      targetLabel: "two-factor backup codes",
      meta: { mfa: "backups-regenerated" },
    });
    return NextResponse.json({ ok: true, backupCodes: result.backupCodes });
  }

  return NextResponse.json({ error: "Unknown action" }, { status: 400 });
}
