import { NextResponse } from "next/server";
import { db } from "@/lib/db";

/**
 * Ashrilogic — LIVENESS probe (ROUND 113).
 *
 * The Kubernetes/PM2/UptimeRobot contract: "is the PROCESS able to serve
 * and did the database answer a trivial query JUST NOW" — nothing else.
 * Distinct from /api/status (the human/operator dashboard: migration
 * phase, backup freshness, response times, s-maxage caching) and from
 * /api/readyz (traffic readiness). Design points:
 *
 *   - NO CACHING: `no-store` — a probe must always reflect THIS instant
 *     (a cached "200" during a hang is exactly the failure mode probes
 *     exist to catch).
 *   - BOUNDED: the DB roundtrip races a 2s alarm — a wedged DB answers
 *     503 "degraded" instead of hanging the prober (health checks that
 *     hang forever take the whole monitoring stack down with them).
 *   - LEAKS NOTHING: a boolean verdict and the elapsed ms. No business
 *     counts, no migration phase, no backup state — a public endpoint.
 */
export const dynamic = "force-dynamic";

const DB_ALARM_MS = 2_000;

/** bounded DB ping: true when a trivial query resolved within the alarm */
async function dbPing(): Promise<boolean> {
  return new Promise<boolean>((resolve) => {
    const timer = setTimeout(() => resolve(false), DB_ALARM_MS);
    timer.unref?.();
    db.platformSetting
      .findFirst({ select: { id: true } })
      .then(
        () => {
          clearTimeout(timer);
          resolve(true);
        },
        () => {
          clearTimeout(timer);
          resolve(false);
        }
      );
  });
}

export async function GET() {
  const started = Date.now();
  const ok = await dbPing();
  return NextResponse.json(
    { ok, elapsedMs: Date.now() - started },
    { status: ok ? 200 : 503, headers: { "Cache-Control": "no-store" } }
  );
}
