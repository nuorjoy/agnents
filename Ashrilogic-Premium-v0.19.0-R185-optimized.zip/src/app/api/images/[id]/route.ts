import { NextResponse } from "next/server";
import { getImageAsset } from "@/lib/server/image-store";

export const dynamic = "force-dynamic";

/**
 * GET /api/images/[id] — public serving of stored image assets (ROUND 40).
 *
 * Images are CONTENT-ADDRESSED: the id is the sha256 hex digest of the exact
 * bytes stored on disk (storage/images/<id>.webp), minted by THIS server from
 * the sanitized (sharp-re-encoded WebP) upload — see image-store.ts. Because
 * the bytes for a given id can never change:
 *
 *  - the response is fully cacheable: `Cache-Control: public, max-age=1y,
 *    immutable` + a STRONG `ETag: "<id>"` (If-None-Match → 304, empty body);
 *  - the Content-Type comes from the DB row recorded at mint time — NEVER
 *    from the request — so a stored asset can't be re-interpreted as HTML;
 *    global X-Content-Type-Options: nosniff (next.config.ts) still applies.
 *
 * This route is intentionally PUBLIC/unauthenticated: site logos are public
 * website assets (same trust level as /_next/static files). There is no path
 * traversal: the id must match ^[a-f0-9]{64}$ and the file name is derived
 * from that validated id only. No rate limiting: immutable, cacheable assets
 * behave like static files.
 */

const ID_RE = /^[a-f0-9]{64}$/;
const CACHE_CONTROL = "public, max-age=31536000, immutable";

/** Parse If-None-Match (comma list per RFC 9110; `*` matches anything). */
function etagMatches(ifNoneMatch: string | null, etag: string): boolean {
  if (!ifNoneMatch) return false;
  if (ifNoneMatch.trim() === "*") return true;
  return ifNoneMatch
    .split(",")
    .map((candidate) => candidate.trim())
    .includes(etag);
}

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse> {
  const { id } = await params;
  if (!ID_RE.test(id)) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const asset = await getImageAsset(id);
  if (!asset) {
    /* unknown id, missing file or missing row — uniform 404 */
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const etag = `"${id}"`;
  if (etagMatches(req.headers.get("if-none-match"), etag)) {
    return new NextResponse(null, {
      status: 304,
      headers: {
        ETag: etag,
        "Cache-Control": CACHE_CONTROL,
      },
    });
  }

  return new NextResponse(new Uint8Array(asset.buffer), {
    status: 200,
    headers: {
      "Content-Type": asset.mime,
      "Content-Length": String(asset.buffer.length),
      "Cache-Control": CACHE_CONTROL,
      ETag: etag,
    },
  });
}
