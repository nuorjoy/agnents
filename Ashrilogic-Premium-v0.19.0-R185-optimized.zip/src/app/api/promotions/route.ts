import { publicList } from "@/server/domains/promotions/controller";

export const dynamic = "force-dynamic";

/**
 * /api/promotions — the PUBLIC site-promotion feed (ROUND 169, العروض
 * الترويجية — the landing banner strip's data source).
 *
 * Returns the ACTIVE promotions whose [startsAt..endsAt] window contains
 * now — lowest sortOrder first, at most 3 — projected onto the PUBLIC
 * display fields only (bilingual title/message/badge/CTA copy, theme,
 * discountPct, the window the countdown + dismiss key need). No internal
 * timestamps, no admin-only state.
 *
 * Guard surface (the /api/identity + /api/packages public-feed law): no
 * auth, a standard per-IP public read throttle, and a short public cache
 * with a stale-while-revalidate tail — a schedule flip converges on every
 * visitor within a minute without hammering the DB.
 */
export const GET = publicList;
