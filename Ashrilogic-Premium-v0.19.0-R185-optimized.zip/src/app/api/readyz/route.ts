import { NextResponse } from "next/server";
import { db } from "@/lib/db";

/**
 * Ashrilogic — READINESS probe (ROUND 113).
 *
 * "Should the load balancer route NEW traffic to THIS instance right
 * now?" — a different question from liveness. Verdict input: the DATABASE
 * answers a trivial query within the alarm window (same bounded-ping
 * contract as /api/healthz).
 *
 *   - Backup freshness is DELIBERATELY NOT a readiness input: a stale
 *     backup is an operational degradation (visible in /api/status and
 *     the admin ops telemetry), not a reason to shed traffic.
 *   - NO CACHING (no-store), no business data, public and anonymous.
 */
export const dynamic = "force-dynamic";

const DB_ALARM_MS = 2_000;

/** bounded DB ping: true when a trivial query resolved within the alarm */
async function dbPing(): Promise<boolean> {
  return new Promise<boolean>((resolve) => {
    const timer = setTimeout(() => resolve(false), DB_ALARM_MS);
    timer.unref?.();
    db.platformSetting
      .findFirst({ select: { id: true } })
      .then(
        () => {
          clearTimeout(timer);
          resolve(true);
        },
        () => {
          clearTimeout(timer);
          resolve(false);
        }
      );
  });
}

interface ReadinessVerdict {
  ok: boolean;
  reason?: string;
  elapsedMs: number;
}

export async function GET() {
  const started = Date.now();

  if (!(await dbPing())) {
    const body: ReadinessVerdict = { ok: false, reason: "database", elapsedMs: Date.now() - started };
    return NextResponse.json(body, { status: 503, headers: { "Cache-Control": "no-store" } });
  }

  const body: ReadinessVerdict = { ok: true, elapsedMs: Date.now() - started };
  return NextResponse.json(body, {
    status: 200,
    headers: { "Cache-Control": "no-store" },
  });
}
