import { NextResponse } from "next/server";
import { getVideoAsset, getVideoAssetRange, videoAssetVitals } from "@/lib/server/media-store";

export const dynamic = "force-dynamic";

/**
 * GET /api/videos/[id] — public serving of stored video assets (ROUND 140).
 *
 * The image route's exact discipline (content-addressed bytes, strong ETag,
 * immutable cache, Content-Type from the DB row minted by THIS server —
 * never from the request; global nosniff still applies) PLUS single-part
 * HTTP Range support: browsers (notably Safari) probe video with
 * `Range: bytes=0-1` and seeking requires 206 answers, so a video store
 * without Range is not a playable store.
 *
 * Intentionally PUBLIC/unauthenticated (same trust level as /api/images):
 * a product video is public storefront media, and the id must match
 * ^[a-f0-9]{64}$ — the sha256 of the exact stored bytes, minted by the
 * validated upload route. No path traversal: the file name is derived from
 * the validated id only.
 */

const ID_RE = /^[a-f0-9]{64}$/;
const CACHE_CONTROL = "public, max-age=31536000, immutable";

/** Parse If-None-Match (comma list per RFC 9110; `*` matches anything). */
function etagMatches(ifNoneMatch: string | null, etag: string): boolean {
  if (!ifNoneMatch) return false;
  if (ifNoneMatch.trim() === "*") return true;
  return ifNoneMatch
    .split(",")
    .map((candidate) => candidate.trim())
    .includes(etag);
}

/** Parse a single-part `Range: bytes=start-end` header (open end allowed). */
function parseRange(
  header: string | null,
  size: number
): { kind: "range"; start: number; end: number } | { kind: "unsatisfiable" } | null {
  if (!header) return null;
  const raw = header.trim();
  if (!/^bytes=\d*-\d*$/.test(raw)) return null;
  const m = /^bytes=(\d*)-(\d*)$/.exec(raw);
  if (!m) return null;
  const [, rawStart, rawEnd] = m;
  if (rawStart === "" && rawEnd === "") return null;
  let start: number;
  let end: number;
  if (rawStart === "") {
    const n = Number(rawEnd);
    if (!Number.isSafeInteger(n) || n <= 0 || size <= 0) return { kind: "unsatisfiable" };
    start = Math.max(0, size - Math.min(n, size));
    end = size - 1;
  } else {
    start = Number(rawStart);
    end = rawEnd === "" ? size - 1 : Math.min(Number(rawEnd), size - 1);
  }
  if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || end < start || start >= size) {
    return { kind: "unsatisfiable" };
  }
  return { kind: "range", start, end };
}

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse> {
  const { id } = await params;
  if (!ID_RE.test(id)) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const vitals = await videoAssetVitals(id);
  if (!vitals) {
    /* unknown id, missing row or missing file — uniform 404 */
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const etag = `"${id}"`;
  if (etagMatches(req.headers.get("if-none-match"), etag)) {
    return new NextResponse(null, {
      status: 304,
      headers: { ETag: etag, "Cache-Control": CACHE_CONTROL },
    });
  }

  /* The Range leg fetches ONLY the requested byte window from storage. */
  const range = parseRange(req.headers.get("range"), vitals.bytes);
  if (range?.kind === "unsatisfiable") {
    return new NextResponse(null, {
      status: 416,
      headers: {
        "Content-Range": `bytes */${vitals.bytes}`,
        "Accept-Ranges": "bytes",
        "Cache-Control": CACHE_CONTROL,
        ETag: etag,
      },
    });
  }
  if (range?.kind === "range") {
    const slice = await getVideoAssetRange(id, range.start, range.end);
    if (!slice) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return new NextResponse(new Uint8Array(slice.buffer), {
      status: 206,
      headers: {
        "Content-Type": slice.mime,
        "Content-Length": String(slice.buffer.length),
        "Content-Range": `bytes ${range.start}-${range.start + slice.buffer.length - 1}/${slice.bytes}`,
        "Accept-Ranges": "bytes",
        "Cache-Control": CACHE_CONTROL,
        ETag: etag,
      },
    });
  }

  const asset = await getVideoAsset(id);
  if (!asset) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return new NextResponse(new Uint8Array(asset.buffer), {
    status: 200,
    headers: {
      "Content-Type": asset.mime,
      "Content-Length": String(asset.buffer.length),
      "Accept-Ranges": "bytes",
      "Cache-Control": CACHE_CONTROL,
      ETag: etag,
    },
  });
}
