import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { computeEntitlement } from "@/lib/server/entitlement";

export const dynamic = "force-dynamic";

/**
 * GET /api/testimonials — public customer-review feed. Aggregates REAL
 * customer reviews (SiteReview rows left on storefront products) across
 * every LIVE workspace:
 *
 *  - only visible, non-trashed reviews with a 4★+ rating and a written body;
 *  - only workspaces that are live (deletedAt null) AND whose public site is
 *    published (site.published) — a draft/trashed storefront never showcases;
 *  - entitlement-safe: banned / disabled / term-locked workspaces are excluded
 *    (computeEntitlement(row).state !== "locked" — their public presence is
 *    held, so their reviews must not leak either);
 *  - the best 9 by rating desc, then recency desc.
 *
 * Fail-open by design: any error answers `{ testimonials: [] }`.
 *
 * ROUND 89 — the landing «آراء ملاك الأنظمة» section now renders SIX curated
 * sector-leader (system-owner) testimonials exclusively and no longer
 * consumes this feed; the route stays as a public, documented API for
 * programmatic consumers.
 */
export async function GET() {
  try {
    const reviews = await db.siteReview.findMany({
      where: {
        deletedAt: null,
        hidden: false,
        rating: { gte: 4 },
        body: { not: null },
      },
      select: {
        rating: true,
        name: true,
        body: true,
        createdAt: true,
        instanceId: true,
      },
      orderBy: { createdAt: "desc" },
      take: 60,
    });

    if (reviews.length === 0) {
      return NextResponse.json({ testimonials: [] });
    }

    /* one grouped instance read for the whole window — live + published site
     * (relation filter, the admin-sites pattern) + every field the pure
     * entitlement engine needs to reject banned/locked workspaces. */
    const ids = Array.from(new Set(reviews.map((r) => r.instanceId)));
    const instances = await db.instance.findMany({
      where: {
        id: { in: ids },
        deletedAt: null,
        site: { published: true },
      },
      select: {
        id: true,
        orgJson: true,
        packageId: true,
        trialEndsAt: true,
        planActivatedAt: true,
        planCycle: true,
        planExpiresAt: true,
        featureOverridesJson: true,
        bannedPermanently: true,
        bannedUntil: true,
        bannedReason: true,
        bannedAt: true,
        disabledAt: true,
        package: { select: { capabilitiesJson: true, nameAr: true, nameEn: true } },
      },
    });

    /* instance id → sealed org display name; locked workspaces and rows
     * whose org name never parses are dropped (never attributed wrongly). */
    const orgNames = new Map<string, string>();
    for (const inst of instances) {
      if (computeEntitlement(inst).state === "locked") continue;
      try {
        const org = JSON.parse(inst.orgJson ?? "{}") as { name?: unknown };
        if (typeof org.name === "string" && org.name.trim()) {
          orgNames.set(inst.id, org.name.trim());
        }
      } catch {
        /* unparseable orgJson — skip this instance's reviews */
      }
    }

    const testimonials = reviews
      .filter((r) => orgNames.has(r.instanceId) && typeof r.body === "string")
      .map((r) => ({
        name: r.name,
        rating: r.rating,
        body: r.body as string,
        createdAt: r.createdAt.toISOString(),
        orgName: orgNames.get(r.instanceId) ?? "",
      }))
      .sort((a, b) => b.rating - a.rating || b.createdAt.localeCompare(a.createdAt))
      .slice(0, 9);

    return NextResponse.json({ testimonials });
  } catch (error) {
    console.error("GET /api/testimonials failed:", error);
    return NextResponse.json({ testimonials: [] });
  }
}
