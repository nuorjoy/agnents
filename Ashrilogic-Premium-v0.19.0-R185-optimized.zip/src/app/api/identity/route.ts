import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { readPlatformIdentity } from "@/lib/server/admin-mapper";

export const dynamic = "force-dynamic";

/**
 * GET /api/identity — PUBLIC platform brand identity feed.
 *
 * No auth: the brand (logos / favicon / colors / fonts / radius / gradient /
 * default theme) is public by definition — every visitor's browser needs it
 * to paint the platform correctly. Served from the singleton PlatformSetting
 * row (identityJson, fail-soft to null = the shipped violet defaults).
 *
 * Caching follows the public-feed pattern (catalog / status): 60s of fresh
 * public caching with a short stale-while-revalidate tail — brand changes
 * converge everywhere within a minute without hammering the DB.
 *
 * NEVER 500s: any failure (DB down, corrupt row) fails OPEN with
 * `{ identity: null, siteNameAr, siteNameEn }` — consumers then keep the
 * platform defaults and the site stays fully usable.
 */
export async function GET() {
  /* the byte-match fallback for a missing/unreadable settings row — the
     same defaults the Prisma schema seeds */
  const fallback = {
    identity: null,
    siteNameAr: "أشرِيلوجيك",
    siteNameEn: "Ashrilogic",
  };
  try {
    const row = await db.platformSetting.findUnique({ where: { id: "global" } });
    const payload = row
      ? {
          identity: readPlatformIdentity(row.identityJson),
          siteNameAr: row.siteNameAr,
          siteNameEn: row.siteNameEn,
        }
      : fallback;
    return NextResponse.json(payload, {
      headers: { "Cache-Control": "public, max-age=60, stale-while-revalidate=300" },
    });
  } catch (error) {
    console.error("GET /api/identity failed:", error);
    return NextResponse.json(fallback, {
      headers: { "Cache-Control": "public, max-age=30" },
    });
  }
}
