import { publicSubmit } from "@/server/domains/enterprise-quotes/controller";

export const dynamic = "force-dynamic";

/**
 * ROUND 167 — طلبات المؤسسات: PUBLIC quote-request endpoint for the landing
 * Enterprise card's «اطلب عرض سعر مخصص» dialog.
 *
 *  POST /api/enterprise-quotes — { name, email, company?, teamSize,
 *  systemsCount, notes? }. The lead's email is SEALED at rest with a blind
 *  index (crypto-vault — the Subscriber law); an ACTIVE quote
 *  (new/contacted/quoted) with the same address answers 200
 *  { ok: true, alreadySubmitted: true } instead of a second row. 201 on a
 *  fresh lead. Guards: same-origin CSRF gate + per-IP throttle (5/10min —
 *  the subscribe law) BEFORE the bounded body read; the zod 400 envelope
 *  carries the first offending field.
 */
export const POST = publicSubmit;
