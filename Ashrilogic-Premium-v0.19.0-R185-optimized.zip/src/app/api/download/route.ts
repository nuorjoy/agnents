import { NextResponse } from "next/server";
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";

export const dynamic = "force-dynamic";

/**
 * ROUND 132 (documented) → implemented ROUND 134: the delivery download
 * API. The delivery ZIP lives in `public/downloads/` (served canonically
 * at `/downloads/<file>` as a static asset); this route adds the
 * operator-friendly forms the owner's ticket asked for:
 *
 *   GET /api/download                → the NEWEST archive in the folder
 *                                       (mtime-desc), streamed with an
 *                                       `attachment` Content-Disposition
 *                                       (a click SAVES instead of navigating).
 *   GET /api/download?file=<name>    → that exact archive.
 *
 * SECURITY CONTRACT:
 *   • `file` is validated against a STRICT allowlist shape
 *     (Ashrilogic-Premium-v…-<tag>.zip — letters/digits/dots/dashes only,
 *     no traversal, no separators) AND must actually exist inside
 *     public/downloads — the response then streams ONLY that file.
 *   • Anything else answers 404 with zero filesystem information.
 *   • Public by design: the delivery archive is a public artifact (the
 *     same bytes `/downloads/<file>` serves anonymously); no tenant data,
 *     no auth gate. Cache-Control: no-store keeps the "newest archive"
 *     form honest across re-deliveries.
 *   • The folder is enumerated fresh per request; an empty/missing folder
 *     answers a loud 404 (the delivery contract is broken, not papered
 *     over with an empty 200).
 */
const DOWNLOADS_DIR = join(process.cwd(), "public", "downloads");

/** the strict delivery-archive name shape (no separators, no traversal). */
const ARCHIVE_NAME_RE = /^Ashrilogic-Premium-v[0-9A-Za-z.]+-[0-9A-Za-z.-]+\.zip$/;

/** the archives currently in the folder, newest-first (mtime desc). */
function listArchives(): { name: string; mtime: number; size: number }[] {
  try {
    return readdirSync(DOWNLOADS_DIR)
      .filter((name) => ARCHIVE_NAME_RE.test(name))
      .map((name) => {
        const stat = statSync(join(DOWNLOADS_DIR, name));
        return { name, mtime: stat.mtimeMs, size: stat.size };
      })
      .sort((a, b) => b.mtime - a.mtime);
  } catch {
    return [];
  }
}

export async function GET(req: Request): Promise<NextResponse | Response> {
  const url = new URL(req.url);
  const requested = url.searchParams.get("file");

  const archives = listArchives();
  const chosen = requested
    ? archives.find((a) => a.name === requested) /* allowlist + existence */
    : archives[0]; /* newest */

  if (!chosen) {
    return NextResponse.json(
      {
        error: requested
          ? "Unknown archive name"
          : "No delivery archive is currently published",
        code: "DOWNLOAD_NOT_FOUND",
      },
      { status: 404, headers: { "Cache-Control": "no-store" } }
    );
  }

  try {
    const bytes = readFileSync(join(DOWNLOADS_DIR, chosen.name));
    return new Response(new Uint8Array(bytes), {
      status: 200,
      headers: {
        "content-type": "application/zip",
        "content-length": String(chosen.size),
        "content-disposition": `attachment; filename="${chosen.name}"`,
        "x-content-type-options": "nosniff",
        "cache-control": "no-store",
      },
    });
  } catch {
    return NextResponse.json(
      { error: "The archive disappeared while streaming — retry", code: "DOWNLOAD_GONE" },
      { status: 404, headers: { "Cache-Control": "no-store" } }
    );
  }
}
