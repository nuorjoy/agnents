import { NextResponse } from "next/server";
import { clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { originViolation } from "@/lib/server/origin-guard";
import { readJson } from "@/lib/server/http";
import type { AuthenticationResponseJSON } from "@simplewebauthn/server";
import { finishCrossDeviceLogin, isCrossDeviceTokenShape } from "@/lib/server/cross-device-login";

export const dynamic = "force-dynamic";

/** Phone-side finish throttling: 10 / 5 min per IP. */
const FINISH_RULE = { limit: 10, windowMs: 5 * 60 * 1000 };

type RouteContext = { params: Promise<{ token: string }> };

/**
 * ROUND 117 — POST /api/cross-device/[token]/finish — the PHONE submits
 * the WebAuthn assertion it produced with the bridge's options. The
 * verification path is the platform's standard one (finishPasskeyLogin,
 * pinned to the bridge's own challenge): signature against the stored
 * public key, clone-detection counter, user-verification requirement,
 * single-use challenge. On success the bridge flips to "approved" and
 * the DESKTOP's next claim poll issues the session there.
 *
 * A failed assertion consumes the challenge → the bridge is dead: the
 * answer tells the phone so and the desktop regenerates a fresh QR
 * (regeneration is the recovery path by design).
 *
 * Security: origin guard (this is a same-origin fetch from the login
 * page), bounded body (assertions are ~1-4 KB), durable IP limiter.
 */
export async function POST(req: Request, { params }: RouteContext) {
  const violation = originViolation(req);
  if (violation) return violation;

  const { token } = await params;
  if (!isCrossDeviceTokenShape(token)) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const body = await readJson(req, 200_000);
  if (!body.ok) return body.response;

  const response = (body.data as { response?: unknown }).response;
  if (!response || typeof response !== "object" || !("id" in response)) {
    return NextResponse.json({ error: "Invalid assertion" }, { status: 400 });
  }

  const ip = clientIp(req);
  if (await rateLimited(`cd-login-finish:${ip}`, FINISH_RULE, { failClosed: true })) {
    return tooManyRequests(FINISH_RULE, { error: "Too many attempts — try again later" });
  }

  const result = await finishCrossDeviceLogin(
    req,
    token,
    response as AuthenticationResponseJSON,
    ip
  );
  if (result.ok) {
    return NextResponse.json({ ok: true, status: result.status });
  }
  const map: Record<typeof result.error, { message: string; status: number }> = {
    NOT_FOUND: { message: "Not found", status: 404 },
    EXPIRED: { message: "Not found", status: 404 },
    NOT_PENDING: { message: "This sign-in request is already completed", status: 409 },
    VERIFICATION_FAILED: { message: "Passkey verification failed — try again", status: 401 },
    ACCOUNT_REFUSED: { message: "This passkey cannot sign in right now", status: 401 },
  };
  const verdict = map[result.error];
  return NextResponse.json({ error: verdict.message, code: result.error }, { status: verdict.status });
}
