import { NextResponse } from "next/server";
import { clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { getCrossDeviceLogin, isCrossDeviceTokenShape } from "@/lib/server/cross-device-login";

export const dynamic = "force-dynamic";

/** Phone-side fetch throttling: 60 / 3 min per IP (page load + retries). */
const GET_RULE = { limit: 60, windowMs: 3 * 60 * 1000 };

type RouteContext = { params: Promise<{ token: string }> };

/**
 * ROUND 117 — GET /api/cross-device/[token] — the PHONE step of the
 * cross-device passkey login: the login page opened from the QR detects
 * ?cd=<token> and fetches the authentication options here to run the
 * native browser ceremony ON THE PHONE (where the passkey lives).
 *
 * A PENDING bridge hands out the options; approved/claimed bridges answer
 * {status} only. Any miss (bad shape / unknown token / expired) is a
 * uniform 404 — the token is a 256-bit random secret, there is no
 * enumeration surface to protect beyond silence.
 *
 * No origin guard: a top-level QR-scan NAVIGATION carries no Origin
 * header; the fetch this route serves happens from the SAME origin's
 * login page after it loads. The rate limit is durable + fail closed.
 */
export async function GET(req: Request, { params }: RouteContext) {
  const { token } = await params;
  if (!isCrossDeviceTokenShape(token)) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const ip = clientIp(req);
  if (await rateLimited(`cd-login-get:${ip}`, GET_RULE, { failClosed: true })) {
    return tooManyRequests(GET_RULE, { error: "Too many requests — try again later" });
  }

  const state = await getCrossDeviceLogin(token);
  if (!state.ok) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  return NextResponse.json(state, { headers: { "Cache-Control": "no-store" } });
}
