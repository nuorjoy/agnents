import { NextResponse } from "next/server";
import { clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { originViolation } from "@/lib/server/origin-guard";
import { readJson } from "@/lib/server/http";
import { isCrossDeviceScope, startCrossDeviceLogin } from "@/lib/server/cross-device-login";

export const dynamic = "force-dynamic";

/** Bridge-creation throttling: 10 / 5 min per IP. */
const START_RULE = { limit: 10, windowMs: 5 * 60 * 1000 };

/**
 * ROUND 117 — POST /api/cross-device — desktop step 1 of the passkey
 * cross-device login: mint the bridge + the QR markup the dialog renders.
 *
 * Body: { scope: "admin" | "instance" }. The QR encodes the scope's login
 * page with ?cd=<token>; the phone completes the ceremony there (see the
 * [token] routes). No account information is returned — the flow is
 * usernameless until the phone's assertion resolves the subject.
 *
 * Security: origin guard, bounded body, durable IP limiter (fail closed).
 */
export async function POST(req: Request) {
  const violation = originViolation(req);
  if (violation) return violation;

  const body = await readJson(req, 2_000);
  if (!body.ok) return body.response;

  const scope = (body.data as { scope?: unknown }).scope;
  if (!isCrossDeviceScope(scope)) {
    return NextResponse.json({ error: "Unknown scope" }, { status: 400 });
  }

  const ip = clientIp(req);
  if (await rateLimited(`cd-login-start:${ip}:${scope}`, START_RULE, { failClosed: true })) {
    return tooManyRequests(START_RULE, { error: "Too many attempts — try again later" });
  }

  const started = await startCrossDeviceLogin(req, scope);
  if (!started.ok) {
    const message =
      started.error === "NO_CREDENTIALS"
        ? "No passkeys registered on this platform yet"
        : "Could not start the cross-device sign-in — try again";
    return NextResponse.json({ error: message, code: started.error }, { status: 400 });
  }
  return NextResponse.json(started.start, { headers: { "Cache-Control": "no-store" } });
}
