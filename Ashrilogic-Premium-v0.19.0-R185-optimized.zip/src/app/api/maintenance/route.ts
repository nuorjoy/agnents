import { NextResponse } from "next/server";
import { getCachedPlatformSettings } from "@/lib/server/platform-settings-cache";
import { resolveInstanceSession } from "@/lib/server/instance-session";

export const dynamic = "force-dynamic";

/**
 * GET /api/maintenance — the PUBLIC platform-state probe (ROUND 89).
 *
 * Powers the maintenance-mode + closed-signup gates on the client shell:
 *  - `maintenance` → the «وضع الصيانة» toggle (console Settings → الأمان
 *    والجلسات). Anonymous visitors get the premium maintenance screen;
 *    a signed-in WORKSPACE OWNER bypasses it (they must keep operating
 *    their system while the platform's public face is under maintenance).
 *    The admin console (/admin) is never gated — it is how the toggle is
 *    switched back off.
 *  - `signupAllowed` → the «السماح بالتسجيل» toggle, mirrored here so the
 *    landing wizard entry can disable itself with a precise chip instead
 *    of waiting for the 403 on submit.
 *
 * No auth: the response leaks nothing sensitive (two booleans + the site
 * name that the landing already renders publicly).
 */
export async function GET() {
  try {
    /* ROUND 145 (perf) — the shared 10s TTL cache (platform-settings-cache):
     * this public probe runs on every shell poll per visitor, so the row is
     * now read at most once per 10s per process. 10s maintenance-mode /
     * signup-gate propagation is the documented staleness trade-off; a read
     * error still lands in the fail-open catch below. */
    const row = await getCachedPlatformSettings();
    /* owners keep working during maintenance — resolve their session
     * cheaply (cookie verify + registry check, no PII read) */
    let ownerBypass = false;
    if (row?.maintenanceMode) {
      const session = await resolveInstanceSession();
      ownerBypass = session.status === "valid";
    }
    return NextResponse.json({
      maintenance: row?.maintenanceMode === true && !ownerBypass,
      signupAllowed: row?.allowSignup !== false,
      siteNameAr: row?.siteNameAr || "أشرِيلوجيك",
      siteNameEn: row?.siteNameEn || "Ashrilogic",
    });
  } catch (error) {
    console.error("GET /api/maintenance failed:", error);
    /* fail-open with defaults — a broken probe must never take the site down */
    return NextResponse.json({ maintenance: false, signupAllowed: true });
  }
}
