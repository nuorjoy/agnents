import type { MetadataRoute } from "next";
import { SYSTEMS } from "@/data/catalog";
import { SITE_URL } from "@/lib/site-url";
import {
  SITEMAP_MAX_URLS_PER_SHARD,
  chunkUrls,
  coreUrlCount,
  loadSitemapSiteEntries,
  loadSitemapBlogEntries,
  resolveShardPlan,
  type SiteSitemapEntry,
} from "@/lib/server/sitemap-plan";

/**
 * Ashrilogic — dynamic sitemap, SHARDED via generateSitemaps.
 *
 * Next.js App Router convention: exporting `generateSitemaps()` alongside
 * the default `sitemap()` splits the sitemap into per-shard files served at
 * `/sitemap/<id>.xml`. Shard 0 is the deterministic core (static marketing
 * routes + the 102 catalog system pages); sites and blog shards follow —
 * every shard bounded by SITEMAP_MAX_URLS_PER_SHARD (25,000 URLs, 50%
 * headroom under the sitemap-protocol 50,000-URL / 50MB-per-file ceiling).
 *
 * WHY SHARDED: the pre-sharding generator concatenated every source into a
 * single /sitemap.xml whose DESIGN CEILING was 5 + 102 + 40,000 + 10,000 =
 * 50,107 URLs — 107 over the protocol limit at production row counts
 * (20k sites × 2 URLs + 10k blog posts). Google truncates oversized
 * sitemaps at 50,000 URLs, silently dropping the newest blog posts from
 * discovery. The shard plan lives in src/lib/server/sitemap-plan.ts and is
 * shared with robots.ts (single source of truth; robots.txt lists exactly
 * the shards that exist). Boundary behavior is pinned by
 * tests/security/seo-sitemap.test.ts.
 *
 * DELIBERATELY EXCLUDED (sensitive — unchanged posture):
 *  - /admin, /admin/login     (Super-Admin — never listed publicly)
 *  - /login                   (owner login — transactional)
 *  - /api/*                   (all APIs — non-content)
 *  - /sites/* /account        (customer-account portal — private)
 *  - /sites/* /receipt        (token-gated receipt — private)
 *  - draft / stopped / trashed / locked tenant sites (noindex — would
 *    promise indexable URLs the pages refuse)
 *  - tenant storefront URLs when the entitlement does NOT enable the store
 *    feature (the store page serves noindex there)
 *  - draft blog posts
 *
 * ROUND 166 — CRAWL-EFFICIENCY: revalidate = 3600 (ISR). Each shard is
 * fully deterministic given the DB state, so a cached copy is byte-stable
 * between regenerations; crawlers hit the CDN cache instead of recomputing
 * the bounded queries per fetch.
 */
export const revalidate = 3600;

/**
 * BUILD_DATE — a deterministic lastModified for static routes. Using `new Date()`
 * would tell Google "every static page changed today" on every sitemap fetch,
 * defeating the crawl-efficiency purpose of lastModified. This constant is
 * the release anchor; update it when static content actually changes.
 */
const BUILD_DATE = new Date("2026-09-27T00:00:00.000Z");

/** The shard id map — numeric ids: 0 = core, 1..S = sites, S+1..S+B = blog. */
export async function generateSitemaps() {
  const plan = await resolveShardPlan();
  return plan.ids.map((id) => ({ id }));
}

/** The deterministic core shard: static marketing routes + the 102 systems. */
function coreShard(): MetadataRoute.Sitemap {
  const base = SITE_URL;
  const now = BUILD_DATE; // deterministic — see BUILD_DATE doc above

  const staticRoutes: MetadataRoute.Sitemap = [
    {
      url: `${base}/`,
      lastModified: now,
      changeFrequency: "weekly",
      priority: 1.0,
    },
    {
      url: `${base}/compare`,
      lastModified: now,
      changeFrequency: "weekly",
      priority: 0.8,
    },
    {
      url: `${base}/blog`,
      lastModified: now,
      changeFrequency: "daily",
      priority: 0.8,
    },
    {
      url: `${base}/privacy`,
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.4,
    },
    {
      url: `${base}/terms`,
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.4,
    },
  ];

  // all 102 system detail pages — high priority (product pages)
  const systemRoutes: MetadataRoute.Sitemap = SYSTEMS.map((s) => ({
    url: `${base}/systems/${s.id}`,
    lastModified: now,
    changeFrequency: "weekly",
    priority: 0.8,
  }));

  return [...staticRoutes, ...systemRoutes];
}

/** The tenant-sites shards — chunked to ≤ SITEMAP_MAX_URLS_PER_SHARD URLs. */
function siteShardUrls(entries: SiteSitemapEntry[]): MetadataRoute.Sitemap[] {
  const base = SITE_URL;
  const urls = entries.flatMap((site) => {
    const siteUrl: MetadataRoute.Sitemap = [
      {
        url: `${base}/sites/${site.instanceId}`,
        lastModified: site.updatedAt,
        changeFrequency: "weekly" as const,
        priority: 0.6,
      },
    ];
    if (site.includeStore) {
      siteUrl.push({
        url: `${base}/sites/${site.instanceId}/store`,
        lastModified: site.updatedAt,
        changeFrequency: "weekly" as const,
        priority: 0.6,
      });
    }
    return siteUrl;
  });
  return chunkUrls(urls).map((chunk) => chunk);
}

/** The blog shards — newest first, chunked to ≤ SITEMAP_MAX_URLS_PER_SHARD. */
function blogShardUrls(
  posts: { slug: string; lastModified: Date }[]
): MetadataRoute.Sitemap[] {
  const base = SITE_URL;
  const urls = posts.map((post) => ({
    url: `${base}/blog/${post.slug}`,
    lastModified: post.lastModified,
    changeFrequency: "weekly" as const,
    priority: 0.7,
  }));
  return chunkUrls(urls).map((chunk) => chunk);
}

export default async function sitemap({
  id,
}: {
  id: Promise<string> | string | number;
}): Promise<MetadataRoute.Sitemap> {
  /* The shard id arrives from the URL path (/sitemap/<id>.xml). Next.js
   * 16 passes it as a Promise resolving to the raw string segment (the
   * async-params convention — see the metadata-route loader's
   * `handler({ id: targetIdPromise })`); normalize every historical form
   * (Promise<string>, string, number) to a shard index. */
  const rawId = id instanceof Promise ? await id : id;
  const shardId =
    typeof rawId === "number" ? rawId : Number.parseInt(String(rawId), 10);
  if (!Number.isInteger(shardId)) return [];

  /* Core shard — deterministic, no DB. The plan resolves the shard-count
   * mapping; a shard id beyond the resolved plan (DB degraded between the
   * generateSitemaps resolution and this render) degrades to a valid EMPTY
   * sitemap, never a broken one. */
  if (shardId === 0) return coreShard();

  const [siteEntries, blogEntries] = await Promise.all([
    loadSitemapSiteEntries(),
    loadSitemapBlogEntries(),
  ]);
  const siteShards = siteShardUrls(siteEntries);
  const blogShards = blogShardUrls(blogEntries);
  const idToShard = new Map<number, MetadataRoute.Sitemap>();
  siteShards.forEach((shard, index) => idToShard.set(1 + index, shard));
  blogShards.forEach((shard, index) =>
    idToShard.set(1 + siteShards.length + index, shard)
  );
  return idToShard.get(shardId) ?? [];
}

/* Static re-export so the shard sizing contract is visible at the route
 * boundary (and asserted by the seo-sitemap regression test). */
export { SITEMAP_MAX_URLS_PER_SHARD, coreUrlCount };
