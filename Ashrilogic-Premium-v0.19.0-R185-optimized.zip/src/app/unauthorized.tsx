import { UnauthorizedView } from "@/components/error-pages/unauthorized-view";

/**
 * Ashrilogic — 401 (unauthorized) page.
 *
 * Rendered when `unauthorized()` is called from a Server Component (Next.js
 * 15+ convention). The UI lives in the client `UnauthorizedView` because it
 * depends on `useT()` and the app store.
 */
export default function Unauthorized() {
  return <UnauthorizedView />;
}
