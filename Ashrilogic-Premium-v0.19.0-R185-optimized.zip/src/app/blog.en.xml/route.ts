import { buildBlogFeed, renderEmptyFeedXml, feedHeaders } from "@/lib/server/rss";

/**
 * Ashrilogic — RSS 2.0 ENGLISH mirror of the public blog feed
 * (ROUND 179 — R178 recommendation b).
 *
 * Route: GET /blog.en.xml — a separate STATIC route (not a ?lang=
 * query on /blog.xml) so both channels keep identical pure-ISR cache
 * semantics: no request read, `revalidate = 3600`, per-URL CDN caching,
 * and feed readers get the distinct standard URL they prefer.
 *
 * Same shared data layer as /blog and /api/blog (loadBlogFeedPage via
 * buildBlogFeed) — the EN and AR item sets are identical by
 * construction; only the channel language and the per-item field
 * preference change (EN title/excerpt with graceful fallback to the AR
 * field for untranslated posts, see src/lib/server/rss.ts).
 *
 * Discovery: the root layout emits both alternate links on every page:
 * /blog.xml (AR, the canonical channel) and /blog.en.xml (EN mirror).
 */
export const revalidate = 3600;

export async function GET() {
  try {
    const xml = await buildBlogFeed("en");
    return new Response(xml, { status: 200, headers: feedHeaders() });
  } catch (error) {
    console.error("GET /blog.en.xml failed:", error);
    /* Fail-open with a VALID empty channel (same posture as /blog.xml). */
    return new Response(renderEmptyFeedXml("en"), {
      status: 200,
      headers: {
        "Content-Type": "application/rss+xml; charset=utf-8",
        "Cache-Control": "public, max-age=0, s-maxage=60, stale-while-revalidate=600",
      },
    });
  }
}
