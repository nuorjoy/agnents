import { buildBlogFeed, renderEmptyFeedXml, feedHeaders } from "@/lib/server/rss";

/**
 * Ashrilogic — RSS 2.0 feed for the public blog (ROUND 178; ROUND 179
 * extracted the channel builder into src/lib/server/rss.ts so the AR and
 * EN mirrors can never drift).
 *
 * Route: GET /blog.xml — the standard blog-feed URL (folder name is the
 * route path; the dot is legal and intentional). Served with the exact
 * feed content type + a CDN-friendly Cache-Control, and exported with
 * `revalidate = 3600` so production serves the XML from ISR (the same
 * caching posture as the sharded sitemap) instead of re-rendering per
 * hit. The underlying data is the SAME shared server layer as /blog and
 * /api/blog (loadBlogFeedPage), so the feed can never drift from the
 * rendered listing; the tag-facet scan inside it is TTL-cached.
 *
 * Language policy (deliberate): the site is Arabic-first (html lang=ar,
 * AR canonical titles for SEO) — so this URL is the AR channel (language
 * "ar", AR titles/excerpts). The EN mirror lives at /blog.en.xml (ROUND
 * 179). HI readers get the full experience on site.
 *
 * Discovery: the root layout emits
 * `<link rel="alternate" type="application/rss+xml" href="/blog.xml">`
 * (plus the EN mirror) on every page (feed autodiscovery).
 */
export const revalidate = 3600;

export async function GET() {
  try {
    const xml = await buildBlogFeed("ar");
    return new Response(xml, { status: 200, headers: feedHeaders() });
  } catch (error) {
    console.error("GET /blog.xml failed:", error);
    /* Fail-open with a VALID empty channel — a feed reader should never
     * see a broken XML document because of a DB hiccup. */
    return new Response(renderEmptyFeedXml("ar"), {
      status: 200,
      headers: {
        "Content-Type": "application/rss+xml; charset=utf-8",
        "Cache-Control": "public, max-age=0, s-maxage=60, stale-while-revalidate=600",
      },
    });
  }
}
