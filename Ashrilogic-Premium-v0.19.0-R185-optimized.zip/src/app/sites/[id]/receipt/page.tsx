import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { SYSTEM_MAP } from "@/data/catalog";
import { readSiteContent } from "@/lib/server/site-mapper";
import { siteTheme } from "@/lib/site-themes";
import { computeEntitlement } from "@/lib/server/entitlement";
import { verifyReceiptToken } from "@/lib/server/receipt-token";
import { guestOrderProjection } from "@/lib/server/order-guest";
import { ReceiptPageView } from "@/components/site/receipt-page-view";
import { SiteStoppedScreen } from "@/components/site/site-stopped";

/**
 * ROUND 119 — the PUBLIC STANDALONE RECEIPT PAGE
 * (/sites/[instanceId]/receipt?token=…).
 *
 * The emailable/shareable face of the R62 printable receipt: the token is
 * minted ONLY by the tracking endpoint after the caller proved knowledge of
 * the tracking code AND the placement phone, and is MAC-sealed (HKDF
 * purpose-separated key), scoped to this site + this order, valid 30 days
 * (see receipt-token.ts for the full security posture).
 *
 * Gates, in order:
 *  1. token invalid / expired / scoped to another site → the generic 404
 *     (no oracle beyond "this link is not usable" — same verdict for every
 *     failure mode, byte-identical to a missing site);
 *  2. missing site / draft (unpublished) / missing-or-trashed order → the
 *     same generic 404;
 *  3. stopped workspace (trial/term lock, ban, store feature off) → the
 *     premium stopped screen (an honest explanation for a link that worked
 *     yesterday — the token may outlive the workspace's active state);
 *  4. otherwise → the guest projection (PII-free, price-column-free — the
 *     SHARED builder the track API uses) on the standalone receipt page.
 *
 * The page never touches a session: the token IS the capability, exactly
 * like the tracking code + phone pair it was minted behind.
 */
export const dynamic = "force-dynamic";

type PageProps = {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ token?: string | string[] }>;
};

/** The store-surface stop gate (same semantics as the track API: locked
 *  workspace or missing store feature). */
function storeStopReason(
  row: {
    packageId: string | null;
    trialEndsAt: Date | null;
    planExpiresAt?: Date | null;
    featureOverridesJson?: string | null;
    bannedPermanently?: boolean | null;
    bannedUntil?: Date | null;
    package?: { capabilitiesJson?: string | null; nameAr?: string; nameEn?: string } | null;
  }
): "trial" | "plan" | "feature" | "ban" | null {
  const ent = computeEntitlement(row);
  if (ent.state === "locked") {
    if (ent.lockReason === "ban") return "ban";
    return ent.lockReason === "plan" ? "plan" : "trial";
  }
  if (ent.features.store !== true) return "feature";
  return null;
}

function orgNameOf(orgJson: string, fallback: string): string {
  try {
    return (JSON.parse(orgJson) as { name?: string }).name?.trim() || fallback;
  } catch {
    return fallback;
  }
}

export async function generateMetadata({ params, searchParams }: PageProps): Promise<Metadata> {
  const { id } = await params;
  /* the page leaks nothing to crawlers: no org identity in any metadata
     until the token verifies AND the site is live. */
  const sp = await searchParams;
  const tokenRaw = Array.isArray(sp.token) ? sp.token[0] : sp.token;
  const claims = verifyReceiptToken(tokenRaw);
  if (!claims || claims.instanceId !== id) {
    /* Task 6 — Arabic receipt fallback (was English "Receipt"). */
    return { title: { absolute: "إيصال" }, robots: { index: false, follow: false } };
  }
  const row = await db.instance.findUnique({
    where: { id },
    include: { site: true, package: true },
  });
  if (!row || !row.site || !row.site.published || storeStopReason(row) !== null) {
    /* Task 6 — Arabic receipt fallback (was English "Receipt"). */
    return { title: { absolute: "إيصال" }, robots: { index: false, follow: false } };
  }
  const system = SYSTEM_MAP[row.systemId];
  const orgName = orgNameOf(row.orgJson, system?.nameEn ?? row.systemId);
  /* absolute (escapes the root layout's "%s · Ashrilogic" template) —
     the receipt is a document, not a landing page. */
  return {
    /* Task 6 — Arabic receipt label (was "Receipt"); absolute title
       (escapes the root layout template) — the receipt is a document,
       not a landing page. */
    title: { absolute: `${orgName} — إيصال` },
    robots: { index: false, follow: false },
  };
}

export default async function ReceiptLinkPage({ params, searchParams }: PageProps) {
  const { id } = await params;

  /* 1 — the token: verify + site-scope binding, or the generic 404 */
  const sp = await searchParams;
  const tokenRaw = Array.isArray(sp.token) ? sp.token[0] : sp.token;
  const claims = verifyReceiptToken(tokenRaw);
  if (!claims || claims.instanceId !== id) notFound();

  /* 2 — the site: live + published */
  const row = await db.instance.findUnique({
    where: { id },
    include: { site: true, package: true },
  });
  if (!row || !row.site || !row.site.published) notFound();

  /* 3 — stopped workspace: the honest stopped screen */
  const stopReason = storeStopReason(row);
  if (stopReason !== null) {
    const system = SYSTEM_MAP[row.systemId];
    const theme = siteTheme(row.site.theme);
    return (
      <SiteStoppedScreen
        orgName={orgNameOf(row.orgJson, system?.nameEn ?? row.systemId)}
        systemNameAr={system?.nameAr ?? row.systemId}
        c1={theme.c1}
        c2={theme.c2}
        reason={stopReason}
      />
    );
  }

  /* 4 — the order: this site's, not trashed, guest projection only */
  const order = await db.siteOrder.findFirst({
    where: { id: claims.orderId, instanceId: id, deletedAt: null },
    select: {
      code: true,
      itemsJson: true,
      total: true,
      discount: true,
      couponCode: true,
      currency: true,
      status: true,
      statusNote: true,
      statusHistoryJson: true,
      createdAt: true,
      updatedAt: true,
    },
  });
  if (!order) notFound();

  const projection = guestOrderProjection(order);

  const content = readSiteContent(row.site.contentJson);
  const system = SYSTEM_MAP[row.systemId];
  const orgName = orgNameOf(row.orgJson, system?.nameEn ?? row.systemId);
  /* ROUND 86 — the e-store's independent accent theme (same resolution as
     the storefront: content.storeTheme wins, else the site theme). */
  const theme = siteTheme(content.storeTheme || row.site.theme);
  const orgContact =
    [content.contactPhone, content.contactAddress].filter(Boolean).join(" · ") || null;

  return (
    <ReceiptPageView
      instanceId={id}
      orgName={orgName}
      c1={theme.c1}
      c2={theme.c2}
      systemIcon={system?.icon ?? "boxes"}
      logoUrl={content.logoUrl}
      orgContact={orgContact}
      /* ROUND 122 — the page's own verified token: rendered into the
       * screen-only QR (beam this page to a phone). */
      receiptToken={typeof tokenRaw === "string" ? tokenRaw : null}
      data={{
        code: projection.code,
        items: projection.items.map((it) => ({
          name: it.name,
          qty: it.qty,
          /* the guest projection renders qty-only lines (no unit prices) —
             the R62 contract shared with the tracking dialog */
          unitPrice: null,
        })),
        total: projection.total,
        discount: projection.discount,
        couponCode: projection.couponCode,
        currency: projection.currency,
        status: projection.status,
        statusHistory: projection.statusHistory,
        createdAt: projection.createdAt,
        updatedAt: projection.updatedAt,
      }}
    />
  );
}
