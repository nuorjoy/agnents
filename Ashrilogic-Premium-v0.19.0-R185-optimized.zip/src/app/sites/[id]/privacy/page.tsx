import type { Metadata } from "next";
import { SITE_URL } from "@/lib/site-url";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { SYSTEM_MAP } from "@/data/catalog";
import { readSiteContent } from "@/lib/server/site-mapper";
import { defaultPrivacyPolicy } from "@/lib/legal-defaults";
import { siteTheme } from "@/lib/site-themes";
import { t } from "@/lib/i18n";
import { resolveInstanceSession } from "@/lib/server/instance-session";
import { getSessionUser } from "@/lib/server/admin-session";
import { computeEntitlement } from "@/lib/server/entitlement";
import { LegalPageView } from "@/components/site/legal-page-view";
import { SiteStoppedScreen } from "@/components/site/site-stopped";

import "@/lib/i18n/fragments/app";
/**
 * ROUND 84 (84-LEGAL) — the PUBLIC PRIVACY-POLICY page of a provisioned
 * system's website (/sites/[instanceId]/privacy).
 *
 * The gates mirror the website loader EXACTLY (/sites/[id]/page.tsx):
 *  - a stopped workspace (trial/term lock, missing public-website feature,
 *    or a platform ban) serves the premium stopped screen for EVERYONE
 *    (owner included) — ROUND 47/79 semantics;
 *  - draft sites render ONLY for the workspace owner (session cookie) or
 *    an authenticated admin, marked by the live-preview banner;
 *  - everything else falls through to the premium 404.
 *
 * The served text is the owner's customized privacyPolicy when present,
 * otherwise the professional DEFAULT Arabic copy (legal-defaults.ts)
 * interpolated with the organization's own name.
 */
export const dynamic = "force-dynamic";

type PageProps = { params: Promise<{ id: string }> };

/** ROUND 47 → ROUND 81 — the legal pages stop with the WEBSITE they
 *  belong to (lock / plan / feature gating / ban). Same helper shape as
 *  the site + storefront loaders. */
function legalStopReason(
  row: {
    packageId: string | null;
    trialEndsAt: Date | null;
    planExpiresAt?: Date | null;
    featureOverridesJson?: string | null;
    bannedPermanently?: boolean | null;
    bannedUntil?: Date | null;
    package?: { capabilitiesJson?: string | null; nameAr?: string; nameEn?: string } | null;
  }
): "trial" | "plan" | "feature" | "ban" | null {
  const ent = computeEntitlement(row);
  if (ent.state === "locked") {
    if (ent.lockReason === "ban") return "ban";
    return ent.lockReason === "plan" ? "plan" : "trial";
  }
  if (ent.features.publicWebsite !== true) return "feature";
  return null;
}

/** The org display name for the legal identity (orgJson is the source of
 *  truth; the catalog system name is the last-resort fallback). */
function orgNameOf(orgJson: string, fallback: string): string {
  try {
    return (JSON.parse(orgJson) as { name?: string }).name?.trim() || fallback;
  } catch {
    return fallback;
  }
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params;
  const row = await db.instance.findUnique({
    where: { id },
    include: { site: true, package: true },
  });
  if (!row || !row.site) return { title: { absolute: "الموقع غير موجود" } };

  /* stopped workspaces (lock or plan gating) expose no metadata and stay
     out of the index while access is restored. */
  if (legalStopReason(row) !== null) {
    return { title: { absolute: "الموقع غير متاح مؤقتًا" }, robots: { index: false, follow: false } };
  }

  /* drafts leak no metadata — anonymous crawlers get the generic not-found
     metadata (same gate + session resolution as the site page). */
  if (!row.site.published) {
    const sessionState = await resolveInstanceSession();
    const ownerPreview = sessionState.status === "valid" && sessionState.instanceId === row.id;
    const admin = ownerPreview ? null : await getSessionUser();
    if (!ownerPreview && !admin) {
      return { title: { absolute: "الموقع غير موجود" }, robots: { index: false, follow: false } };
    }
  }

  const system = SYSTEM_MAP[row.systemId];
  const orgName = orgNameOf(row.orgJson, system?.nameEn ?? row.systemId);
  /* ROUND 84 — the page name + the site identity, ABSOLUTE (escapes the
   * root layout's "%s · Ashrilogic" template): the tab shows the legal
   * page's own name from the FIRST server paint, byte-matching the
   * client's default-language (ar) docTitleSitePrivacy template —
   * useDocumentTitle re-commits the same string on mount. */
  const title = t("ar", "docTitleSitePrivacy", { org: orgName });
  const description = t("ar", "legalPrivacyDesc", { org: orgName });

  const canonical = `${SITE_URL}/sites/${row.id}/privacy`;
  const icons = [{ url: `/api/instances/${row.id}/favicon.png`, type: "image/png" }];
  return {
    title: { absolute: title },
    description,
    alternates: {
      canonical,
    },
    ...(icons ? { icons: { icon: icons } } : {}),
    openGraph: {
      title,
      description,
      url: canonical,
      type: "website",
      siteName: "Ashrilogic",
      images: [{ url: "/og.png", width: 1200, height: 630, alt: title }],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: ["/og.png"],
    },
    /* drafts (owner preview) stay out of search results */
    robots: { index: row.site.published, follow: true },
  };
}

export default async function LegalPrivacyPage({ params }: PageProps) {
  const { id } = await params;
  const row = await db.instance.findUnique({
    where: { id },
    include: { site: true, package: true },
  });
  if (!row || !row.site) notFound();

  /* ROUND 47/79 — stop gate: stopped for EVERYONE (owner included); the
   * page comes back the moment a plan activates / renews / upgrades. */
  const stopReason = legalStopReason(row);
  if (stopReason !== null) {
    const system = SYSTEM_MAP[row.systemId];
    const theme = siteTheme(row.site.theme);
    return (
      <SiteStoppedScreen
        orgName={orgNameOf(row.orgJson, system?.nameEn ?? row.systemId)}
        systemNameAr={system?.nameAr ?? row.systemId}
        c1={theme.c1}
        c2={theme.c2}
        reason={stopReason}
      />
    );
  }

  /* drafts are previewable only by the workspace owner or an admin */
  if (!row.site.published) {
    /* Round 49: full session resolution (jti registry + epoch) — a revoked
       or stale workspace cookie no longer previews drafts. */
    const sessionState = await resolveInstanceSession();
    const ownerPreview = sessionState.status === "valid" && sessionState.instanceId === row.id;
    const admin = ownerPreview ? null : await getSessionUser();
    if (!ownerPreview && !admin) notFound();
  }

  const content = readSiteContent(row.site.contentJson);
  const system = SYSTEM_MAP[row.systemId];
  const orgName = orgNameOf(row.orgJson, system?.nameEn ?? row.systemId);
  /* ROUND 84 (84-LEGAL) — "" (or whitespace-only) renders the professional
   * DEFAULT Arabic copy interpolated with the org's name; a non-empty
   * custom text renders exactly as authored. */
  const text = content.privacyPolicy.trim().length > 0
    ? content.privacyPolicy
    : defaultPrivacyPolicy(orgName);
  const theme = siteTheme(row.site.theme);

  return (
    <LegalPageView
      kind="privacy"
      instanceId={row.id}
      orgName={orgName}
      text={text}
      updatedAt={row.site.updatedAt.toISOString()}
      c1={theme.c1}
      c2={theme.c2}
      systemIcon={system?.icon ?? "boxes"}
      logoUrl={content.logoUrl}
      preview={!row.site.published}
      /* ROUND 86 — the site's own font + visitor languages (the legal pages
         are part of the public website surface). */
      siteFont={content.siteFont}
      siteLangs={content.siteLangs}
    />
  );
}
