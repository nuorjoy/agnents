import type { Metadata } from "next";
import { SITE_URL } from "@/lib/site-url";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { SYSTEM_MAP, CATEGORY_MAP } from "@/data/catalog";
import { readSiteContent } from "@/lib/server/site-mapper";
import { siteTheme } from "@/lib/site-themes";
import { safeJsonLd } from "@/lib/safe-json-ld";
import { resolveInstanceSession } from "@/lib/server/instance-session";
import { getSessionUser } from "@/lib/server/admin-session";
import { computeEntitlement } from "@/lib/server/entitlement";
import {
  attachRatingAggregates,
  loadStoreProducts,
  storeModuleId,
} from "@/lib/server/store-mapper";
import { StoreProductDetail } from "@/components/site/store-product-detail";
import { SiteStoppedScreen } from "@/components/site/site-stopped";

/**
 * Ashrilogic — ROUND 156 — the SSR product detail page.
 *
 * The user's directive:
 *   «في جميع الأنظمة (المتجر الإلكتروني) لا تجعل المنتجات تظهر كـPopup
 *    بل اجعل لكل منتج صفحة بطريقة احترافية وPremium وتكون متقدمة
 *    ومتكاملة».
 *
 * The storefront used to peek a product through a popup dialog (round 61);
 * this dedicated route replaces that popup with a server-rendered product
 * page — premium gallery + price/sale + variants + add-to-cart + related
 * + Schema.org Product JSON-LD for crawlers. Mirrors the storefront
 * loader's gates exactly (stop / draft / ban / feature) so a hidden or
 * out-of-stock row 404s at its own URL (the public mapper
 * `loadStoreProducts` already filters them — its list IS the truth).
 *
 * URL shape: /sites/[instanceId]/store/products/[recordId]
 * Works for EVERY store catalog module (pharmacy / inventory / products /
 * menu) because the public store mapper derives the catalog module from
 * the instance's enabled modules.
 */
export const dynamic = "force-dynamic";

type PageProps = { params: Promise<{ id: string; recordId: string }> };

/** ROUND 47 → ROUND 81 — the storefront stops when the workspace is locked
 *  (trial/term ended) OR the plan does not include the store feature OR the
 *  workspace is BANNED. Mirrors src/app/sites/[id]/store/page.tsx. */
function storeStopReason(
  row: {
    packageId: string | null;
    trialEndsAt: Date | null;
    planExpiresAt?: Date | null;
    featureOverridesJson?: string | null;
    bannedPermanently?: boolean | null;
    bannedUntil?: Date | null;
    package?: { capabilitiesJson?: string | null; nameAr?: string; nameEn?: string } | null;
  }
): "trial" | "plan" | "feature" | "ban" | null {
  const ent = computeEntitlement(row);
  if (ent.state === "locked") {
    if (ent.lockReason === "ban") return "ban";
    return ent.lockReason === "plan" ? "plan" : "trial";
  }
  if (ent.features.store !== true) return "feature";
  return null;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id, recordId } = await params;
  const row = await db.instance.findUnique({
    where: { id, deletedAt: null },
    include: { site: true, package: true },
  });
  if (!row || !row.site) return { title: { absolute: "الموقع غير موجود" } };

  if (storeStopReason(row) !== null) {
    return { title: { absolute: "الموقع غير متاح مؤقتًا" }, robots: { index: false, follow: false } };
  }

  /* drafts leak no metadata — anonymous crawlers get the generic 404 metadata */
  if (!row.site.published) {
    const sessionState = await resolveInstanceSession();
    const ownerPreview = sessionState.status === "valid" && sessionState.instanceId === row.id;
    const admin = ownerPreview ? null : await getSessionUser();
    if (!ownerPreview && !admin) {
      return { title: { absolute: "الموقع غير موجود" }, robots: { index: false, follow: false } };
    }
  }

  const content = readSiteContent(row.site.contentJson);
  let orgName = "";
  try {
    orgName = (JSON.parse(row.orgJson) as { name?: string }).name ?? "";
  } catch {
    /* corrupt orgJson */
  }
  const system = SYSTEM_MAP[row.systemId];
  const storeName = orgName || content.heroTitle || (system ? system.nameEn : "Store");

  /* load the product (same path as the page body) so the metadata reflects
   * the real title + image; a missing product returns the generic 404 metadata. */
  const moduleId = storeModuleId(row);
  if (!moduleId) return { title: { absolute: "الموقع غير موجود" } };
  const products = await loadStoreProducts(row);
  const product = products.find((p) => p.recordId === recordId);
  if (!product) {
    return { title: { absolute: "المنتج غير موجود" }, robots: { index: false, follow: false } };
  }

  const title = `${product.name} — ${storeName}`;
  const description = product.category
    ? `${product.name} · ${product.category}`
    : product.name;
  const canonical = `${SITE_URL}/sites/${row.id}/store/products/${encodeURIComponent(recordId)}`;
  const icons = [{ url: `/api/instances/${row.id}/favicon.png`, type: "image/png" }];
  const ogImage = product.imageRef ?? product.gallery?.[0] ?? undefined;

  return {
    title: { absolute: title },
    description,
    alternates: {
      canonical,
    },
    icons: { icon: icons },
    openGraph: {
      title,
      description,
      url: canonical,
      type: "website",
      siteName: "Ashrilogic",
      ...(ogImage ? { images: [{ url: ogImage, alt: product.name }] } : {}),
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      ...(ogImage ? { images: [ogImage] } : {}),
    },
    robots: { index: row.site.published, follow: true },
  };
}

/** Schema.org Product JSON-LD — built only from owner-controlled + already-
 *  loaded catalog columns; routed through safeJsonLd. */
function productJsonLd(args: {
  name: string;
  description: string;
  price: number;
  salePrice: number | null;
  currency: string;
  imageRef: string | null;
  gallery: string[];
  ratingAvg: number | null;
  ratingCount: number;
  stock: number;
  url: string;
  orgName: string;
}) {
  const { name, description, price, salePrice, currency, imageRef, gallery, ratingAvg, ratingCount, stock, url, orgName } = args;
  const photos = [
    ...(imageRef ? [imageRef] : []),
    ...gallery.filter((src) => src !== imageRef),
  ];
  return {
    "@context": "https://schema.org",
    "@type": "Product",
    name,
    description,
    image: photos,
    sku: undefined,
    brand: { "@type": "Brand", name: orgName },
    offers: {
      "@type": "Offer",
      price: (salePrice ?? price).toFixed(2),
      priceCurrency: currency,
      availability: stock > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
      url,
      ...(salePrice != null ? { priceValidUntil: undefined } : {}),
    },
    ...(ratingCount > 0 && ratingAvg != null
      ? {
          aggregateRating: {
            "@type": "AggregateRating",
            ratingValue: ratingAvg,
            reviewCount: ratingCount,
            bestRating: 5,
            worstRating: 1,
          },
        }
      : {}),
  };
}

export default async function StoreProductPage({ params }: PageProps) {
  const { id, recordId } = await params;
  /* a trashed (soft-deleted) workspace's storefront 404s for everyone. */
  const row = await db.instance.findUnique({
    where: { id, deletedAt: null },
    include: { site: true, package: true },
  });
  if (!row || !row.site) notFound();

  const stopReason = storeStopReason(row);
  if (stopReason !== null) {
    const system = SYSTEM_MAP[row.systemId];
    const cat = system ? CATEGORY_MAP[system.c] : undefined;
    const theme = siteTheme(row.site.theme);
    let orgName = "";
    try {
      orgName = (JSON.parse(row.orgJson) as { name?: string }).name ?? "";
    } catch {
      /* corrupt orgJson */
    }
    return (
      <SiteStoppedScreen
        orgName={orgName}
        systemNameAr={system?.nameAr ?? row.systemId}
        c1={cat?.c1 ?? theme.c1}
        c2={cat?.c2 ?? theme.c2}
        reason={stopReason}
      />
    );
  }

  /* drafts are previewable only by the workspace owner or an admin */
  if (!row.site.published) {
    const sessionState = await resolveInstanceSession();
    const ownerPreview = sessionState.status === "valid" && sessionState.instanceId === row.id;
    const admin = ownerPreview ? null : await getSessionUser();
    if (!ownerPreview && !admin) notFound();
  }

  const content = readSiteContent(row.site.contentJson);
  const system = SYSTEM_MAP[row.systemId];
  const cat = system ? CATEGORY_MAP[system.c] : undefined;
  const theme = siteTheme(content.storeTheme || row.site.theme);
  const c1 = cat?.c1 ?? theme.c1;
  const c2 = cat?.c2 ?? theme.c2;

  let orgName = "";
  try {
    orgName = (JSON.parse(row.orgJson) as { name?: string }).name ?? "";
  } catch {
    /* corrupt orgJson */
  }
  const storeName = orgName || content.heroTitle || (system ? system.nameEn : "Store");

  /* loadStoreProducts already filters hidden/out-of-stock rows (the public
   * catalog IS the source of truth). A product not in the list 404s. */
  const moduleId = storeModuleId(row);
  if (!moduleId) notFound();
  const products = await loadStoreProducts(row);
  /* attach rating aggregates BEFORE the lookup so the product detail
   * surface renders the same stars as the storefront grid. */
  await attachRatingAggregates(products, row.id);
  const product = products.find((p) => p.recordId === recordId);
  if (!product) notFound();

  /* related products: same category siblings (≤6, the current product
   * excluded) drawn from the SAME fetched catalog (zero new queries). */
  const related = product.category
    ? products.filter((p) => p.recordId !== product.recordId && p.category === product.category).slice(0, 6)
    : [];

  const currency =
    (JSON.parse(row.orgJson ?? "{}") as { currency?: string }).currency?.trim() || "SAR";

  const canonical = `${SITE_URL}/sites/${row.id}/store/products/${encodeURIComponent(recordId)}`;

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: safeJsonLd(
            productJsonLd({
              name: product.name,
              description: product.category ? `${product.name} · ${product.category}` : product.name,
              price: product.price,
              salePrice: product.salePrice,
              currency,
              imageRef: product.imageRef,
              gallery: product.gallery,
              ratingAvg: product.ratingAvg,
              ratingCount: product.ratingCount,
              stock: product.stock,
              url: canonical,
              orgName: storeName,
            })
          ),
        }}
      />
      <StoreProductDetail
        instanceId={row.id}
        orgName={storeName}
        orgTagline={content.tagline}
        systemIcon={system?.icon ?? "boxes"}
        c1={c1}
        c2={c2}
        logoUrl={content.logoUrl}
        published={row.site.published}
        orgContact={
          [content.contactPhone, content.contactAddress].filter(Boolean).join(" · ") || undefined
        }
        storeFont={content.storeFont}
        storeLangs={content.storeLangs}
        product={product}
        related={related}
        currency={currency}
      />
    </>
  );
}
