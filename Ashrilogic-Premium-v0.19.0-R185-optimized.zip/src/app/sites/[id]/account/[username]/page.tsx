import { Suspense } from "react";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { SYSTEM_MAP } from "@/data/catalog";
import { readSiteContent } from "@/lib/server/site-mapper";
import { siteTheme } from "@/lib/site-themes";
import { t } from "@/lib/i18n";
import { resolveInstanceSession } from "@/lib/server/instance-session";
import { getSessionUser } from "@/lib/server/admin-session";
import { computeEntitlement } from "@/lib/server/entitlement";
import { isValidHandleShape } from "@/lib/server/member-handle";
import { MemberPageView } from "@/components/site/member-page-view";
import { SiteStoppedScreen } from "@/components/site/site-stopped";

import "@/lib/i18n/fragments/app";
/**
 * ROUND 141 — the member's DEDICATED profile page
 * (/sites/[instanceId]/account/<username>).
 *
 * The owner's directive: member profiles must never open as a popup — a
 * real page carries the member's OWN username in the URL, professional
 * and Premium, on BOTH the public website (الموقع الإلكتروني) and the
 * e-store (المتجر الإلكتروني). This is that page: the signed-in member
 * lands here from the header account button on either surface.
 *
 * PRIVACY MODEL — the username in the URL is a HANDLE, never a data key:
 * every panel on this page reads through the customer SESSION APIs, which
 * project ONLY the session owner's own data. A visitor opening someone
 * else's handle (or a guessable one) sees the premium "not available"
 * screen — zero member data is ever derived from the URL itself.
 *
 * The gates mirror the account portal EXACTLY (stopped workspaces serve
 * the stopped screen for everyone; drafts preview only for the workspace
 * owner or an admin).
 */
export const dynamic = "force-dynamic";

type PageProps = { params: Promise<{ id: string; username: string }> };

/** ROUND 47/81 — the account portal stops with the surfaces it serves. */
function accountStopReason(
  row: {
    packageId: string | null;
    trialEndsAt: Date | null;
    planExpiresAt?: Date | null;
    featureOverridesJson?: string | null;
    bannedPermanently?: boolean | null;
    bannedUntil?: Date | null;
    package?: { capabilitiesJson?: string | null; nameAr?: string; nameEn?: string } | null;
  }
): "trial" | "plan" | "feature" | "ban" | null {
  const ent = computeEntitlement(row);
  if (ent.state === "locked") {
    if (ent.lockReason === "ban") return "ban";
    return ent.lockReason === "plan" ? "plan" : "trial";
  }
  if (ent.features.publicWebsite !== true && ent.features.store !== true) return "feature";
  return null;
}

function orgNameOf(orgJson: string, fallback: string): string {
  try {
    return (JSON.parse(orgJson) as { name?: string }).name?.trim() || fallback;
  } catch {
    return fallback;
  }
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id, username } = await params;
  const row = await db.instance.findUnique({
    where: { id },
    include: { site: true, package: true },
  });
  if (!row || !row.site) return { title: { absolute: "الموقع غير موجود" } };
  if (accountStopReason(row) !== null) {
    return { title: { absolute: "الموقع غير متاح مؤقتًا" }, robots: { index: false, follow: false } };
  }
  if (!row.site.published) {
    const sessionState = await resolveInstanceSession();
    const ownerPreview = sessionState.status === "valid" && sessionState.instanceId === row.id;
    const admin = ownerPreview ? null : await getSessionUser();
    if (!ownerPreview && !admin) {
      return { title: { absolute: "الموقع غير موجود" }, robots: { index: false, follow: false } };
    }
  }

  /* member profile pages are NEVER indexed — the handle is a private URL */
  const system = SYSTEM_MAP[row.systemId];
  const orgName = orgNameOf(row.orgJson, system?.nameEn ?? row.systemId);
  return {
    title: { absolute: t("ar", "memberDocTitle", { org: orgName }) },
    robots: { index: false, follow: false },
    icons: { icon: [{ url: `/api/instances/${row.id}/favicon.png`, type: "image/png" }] },
  };
}

export default async function MemberProfilePage({ params }: PageProps) {
  const { id, username } = await params;
  const row = await db.instance.findUnique({
    where: { id },
    include: { site: true, package: true },
  });
  if (!row || !row.site) notFound();

  /* stop gate: stopped for EVERYONE (owner included) */
  const stopReason = accountStopReason(row);
  if (stopReason !== null) {
    const system = SYSTEM_MAP[row.systemId];
    const theme = siteTheme(row.site.theme);
    return (
      <SiteStoppedScreen
        orgName={orgNameOf(row.orgJson, system?.nameEn ?? row.systemId)}
        systemNameAr={system?.nameAr ?? row.systemId}
        c1={theme.c1}
        c2={theme.c2}
        reason={stopReason}
      />
    );
  }

  /* drafts are previewable only by the workspace owner or an admin */
  if (!row.site.published) {
    const sessionState = await resolveInstanceSession();
    const ownerPreview = sessionState.status === "valid" && sessionState.instanceId === row.id;
    const admin = ownerPreview ? null : await getSessionUser();
    if (!ownerPreview && !admin) notFound();
  }

  /* handle shape gate — anything malformed is a plain 404 (no enumeration
   * signal: a valid-shaped unknown handle reads identically below) */
  if (!isValidHandleShape(decodeURIComponent(username))) notFound();

  const content = readSiteContent(row.site.contentJson);
  const system = SYSTEM_MAP[row.systemId];
  const orgName = orgNameOf(row.orgJson, system?.nameEn ?? row.systemId);
  /* the member page follows the E-STORE's identity (same law as the account
   * portal: its own storeTheme when set, else the website theme). */
  const theme = siteTheme(content.storeTheme || row.site.theme);
  const ent = computeEntitlement(row);
  const storeLive = ent.features.store === true;

  return (
    <Suspense
      fallback={
        <div className="grid min-h-screen place-items-center bg-background" aria-busy="true" aria-label="Loading">
          <div className="flex flex-col items-center gap-4">
            <span
              className="grid h-14 w-14 animate-pulse place-items-center rounded-2xl text-white shadow-lg"
              style={{ backgroundImage: `linear-gradient(135deg, ${theme.c1}, ${theme.c2})` }}
              aria-hidden="true"
            >
              <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                <circle cx="12" cy="8" r="4" />
                <path d="M4 21c0-4 3.6-7 8-7s8 3 8 7" />
              </svg>
            </span>
            <span className="h-1.5 w-40 overflow-hidden rounded-full bg-slate-200 dark:bg-white/10">
              <span className="splash-slide block h-full w-1/2 rounded-full bg-linear-to-l from-brand-600 to-brand-400" />
            </span>
          </div>
        </div>
      }
    >
      <MemberPageView
        instanceId={row.id}
        username={decodeURIComponent(username).toLowerCase()}
        orgName={orgName}
        systemIcon={system?.icon ?? "boxes"}
        c1={theme.c1}
        c2={theme.c2}
        logoUrl={content.logoUrl}
        storeLive={storeLive}
        preview={!row.site.published}
        storeFont={content.storeFont}
      />
    </Suspense>
  );
}
