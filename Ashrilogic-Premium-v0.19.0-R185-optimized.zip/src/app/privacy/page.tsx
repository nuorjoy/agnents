import type { Metadata } from "next";
import { cache } from "react";
import { SITE_URL } from "@/lib/site-url";
import { readPlatformLegalDoc } from "@/lib/server/legal-docs";
import { resolveLandingLang } from "@/lib/server/landing-lang";
import { dictLang } from "@/lib/locales";
import { PlatformLegalView } from "@/components/legal/platform-legal-view";
import { SsrLangProvider } from "@/components/ssr-lang-provider";

import "@/lib/i18n/fragments/app";
/**
 * Ashrilogic — ROUND 117 — the PLATFORM privacy policy (/privacy).
 *
 * Server-rendered (force-dynamic) so a console publish is live on the
 * next request: the page reads the LegalDoc rows for every locale (the
 * console-edited row when one exists, the code-carried default
 * otherwise) and hands ALL variants to the language-aware view (the
 * visitor's language picks client-side; hi falls back en → ar — the
 * same chain the server uses).
 *
 * ROUND 185 — the tab title speaks the visitor's language from the first
 * server byte: generateMetadata resolves the ashrlc-lang cookie and titles
 * the page with the LOCALIZED doc title (previously a static Arabic title
 * for everyone). React cache() shares the LegalDoc reads between
 * generateMetadata and the page body (one DB round-trip, the blog-article
 * pattern). The view is wrapped in SsrLangProvider so its useT() island
 * SSR-renders the visitor's language — no Arabic-first flash.
 */

export const dynamic = "force-dynamic";

const CANONICAL = `${SITE_URL}/privacy`;

/* React cache(): generateMetadata + the page body share ONE read per
 * locale per request (the R183 blog-article contract). */
const readPrivacyDoc = cache((langCode: "ar" | "en" | "hi") => readPlatformLegalDoc("privacy", langCode));

export async function generateMetadata(): Promise<Metadata> {
  const lang = await resolveLandingLang();
  const dl = dictLang(lang);
  /* the localized doc title (console-edited row or code default) + the
   * per-language brand suffix — absolute so the root template (Arabic
   * brand) never appends a second suffix. AR renders byte-identical to
   * the pre-R185 template output. */
  const doc = await readPrivacyDoc(dl);
  const title = `${doc.title} · ${dl === "ar" ? "أشرِيلوجيك" : "Ashrilogic"}`;
  return {
    title: { absolute: title },
    description:
      "سياسة خصوصية منصة أشرِيلوجيك — كيف نجمع البيانات ونستخدمها ونحميها، وحقوقك الكاملة تجاهها. Ashrilogic privacy policy.",
    alternates: { canonical: CANONICAL },
    openGraph: {
      title: "سياسة الخصوصية · أشرِيلوجيك",
      description: "كيف نجمع بياناتك ونستخدمها ونحميها — وحقوقك الكاملة تجاهها.",
      url: CANONICAL,
      type: "website",
      siteName: "أشرِيلوجيك · Ashrilogic",
      images: [{ url: "/og.png", width: 1200, height: 630, alt: "Ashrilogic privacy policy" }],
    },
    robots: { index: true, follow: true },
  };
}

export default async function PrivacyPage() {
  /* every locale variant in one payload (few KB) — the view picks the
   * visitor language; the server stays the single read path. */
  const [ar, en, hi] = await Promise.all([
    readPrivacyDoc("ar"),
    readPrivacyDoc("en"),
    readPrivacyDoc("hi"),
  ]);
  const lang = await resolveLandingLang();

  return (
    <SsrLangProvider lang={lang}>
      <PlatformLegalView
        kind="privacy"
        docs={{
          ar: { key: "privacy", title: ar.title, intro: ar.intro, sections: ar.sections, updatedAt: ar.updatedAt, version: ar.version, customized: ar.customized },
          en: { key: "privacy", title: en.title, intro: en.intro, sections: en.sections, updatedAt: en.updatedAt, version: en.version, customized: en.customized },
          hi: { key: "privacy", title: hi.title, intro: hi.intro, sections: hi.sections, updatedAt: hi.updatedAt, version: hi.version, customized: hi.customized },
        }}
      />
    </SsrLangProvider>
  );
}
