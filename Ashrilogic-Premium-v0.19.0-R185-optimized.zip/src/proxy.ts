import { NextRequest, NextResponse } from "next/server";

/**
 * Ashrilogic — CSP proxy (round 38: nonce-based hardening; renamed from
 * middleware.ts to proxy.ts per the Next.js 16 convention — behavior is
 * byte-identical).
 *
 * Content-Security-Policy is owned HERE (not next.config.ts) because the
 * script-src directive carries a per-request NONCE: every document response
 * gets a fresh nonce, and Next.js applies it to the inline script tags it
 * renders (bootstrap + flight payloads) when it sees the CSP header on the
 * request. That removes `script-src 'unsafe-inline'` — the single largest
 * CSP weakness of the previous static policy: any injected inline script
 * without the nonce no longer executes.
 *
 * - `strict-dynamic` is deliberately NOT used: it disables host allowlists
 *   in supporting browsers, which breaks Turbopack's dev-runtime scripts
 *   (they load same-origin without nonces). 'self' + nonce keeps the dev
 *   server functional while still blocking nonce-less INLINE scripts.
 *   Revisit only with a production build smoke-test (documented P2+).
 * - Development keeps 'unsafe-eval' (React Refresh HMR requirement).
 * - 'unsafe-inline' remains ONLY on style-src (Tailwind runtime + framer
 *   motion write style attributes; style injection is not script execution).
 * - The remaining security headers (nosniff, frame-options, …) stay in
 *   next.config.ts and apply to every response; only the CSP moved here.
 *
 * Static assets are excluded from the matcher — CSP governs documents.
 */

const isDev = process.env.NODE_ENV !== "production";

export function proxy(request: NextRequest) {
  const nonce = Buffer.from(crypto.randomUUID()).toString("base64");

  const csp = [
    "default-src 'self'",
    `script-src 'self' 'nonce-${nonce}'${isDev ? " 'unsafe-eval'" : ""}`,
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data: blob:",
    "font-src 'self' data:",
    "connect-src 'self'",
    "media-src 'self' blob:",
    "worker-src 'self' blob:",
    "frame-src 'self'",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
    ...(isDev ? [] : ["upgrade-insecure-requests"]),
  ].join("; ");

  const requestHeaders = new Headers(request.headers);
  // x-nonce + the CSP on the REQUEST make Next nonce its rendered scripts
  requestHeaders.set("x-nonce", nonce);
  requestHeaders.set("Content-Security-Policy", csp);

  const response = NextResponse.next({ request: { headers: requestHeaders } });
  response.headers.set("Content-Security-Policy", csp);
  return response;
}

export const config = {
  matcher: [
    /*
     * Run on all document routes except Next.js internals and static files:
     *   - _next/static (build assets), _next/image (optimized images)
     *   - files with a static extension (images, manifests, robots, sitemap)
     */
    "/((?!_next/static|_next/image|favicon\\.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico|txt|xml|webmanifest|jpg|png|css|js|map|woff2?)).*)",
  ],
};
