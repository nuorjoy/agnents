// Ashrilogic — secure first-admin provisioning (PRODUCTION BOOTSTRAP).
//
// Production builds seed NO control-panel accounts (demo seeding is disabled
// and the demo-password bootstrap never activates). The first super admin is
// provisioned by this script instead — credentials come from the environment
// or CLI flags, never from source code:
//
//   INIT_ADMIN_USERNAME   (default: admin)
//   INIT_ADMIN_NAME       (default: Platform Administrator)
//   INIT_ADMIN_EMAIL      (default: admin@ashrilogic.local)
//   INIT_ADMIN_PASSWORD   (REQUIRED — >= 12 chars, or --gen to generate)
//
// Usage:
//   INIT_ADMIN_PASSWORD='...' bun scripts/bootstrap-admin.ts
//   bun scripts/bootstrap-admin.ts --password '...' --username admin --gen
//
// The script refuses weak passwords, never logs the secret, and will not
// silently overwrite an existing admin's password without --force.

import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const MIN_PASSWORD_LENGTH = 12;

function arg(name: string): string | undefined {
  const flag = `--${name}`;
  const idx = process.argv.indexOf(flag);
  if (idx !== -1 && idx + 1 < process.argv.length) return process.argv[idx + 1];
  return undefined;
}

function generatePassword(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
  const bytes = new Uint8Array(24);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join("");
}

async function main(): Promise<void> {
  // hashPasswordArgon2id is imported lazily so the module's env fail-fast
  // (ADMIN_SESSION_SECRET/ASHRILOGIC_DATA_KEY in production) runs AFTER the
  // argument checks produce readable errors.
  const username = arg("username") ?? process.env.INIT_ADMIN_USERNAME ?? "admin";
  const name = arg("name") ?? process.env.INIT_ADMIN_NAME ?? "Platform Administrator";
  const email = (arg("email") ?? process.env.INIT_ADMIN_EMAIL ?? "admin@ashrilogic.local")
    .trim()
    .toLowerCase();
  const force = process.argv.includes("--force");
  const wantsGenerated = process.argv.includes("--gen");
  const password = arg("password") ?? process.env.INIT_ADMIN_PASSWORD;

  if (!password && !wantsGenerated) {
    console.error(
      "INIT_ADMIN_PASSWORD is required (>= 12 chars) — or pass --gen to generate a strong random password."
    );
    process.exit(1);
  }
  const finalPassword = password ?? generatePassword();
  if (finalPassword.length < MIN_PASSWORD_LENGTH) {
    console.error(`Password must be at least ${MIN_PASSWORD_LENGTH} characters.`);
    process.exit(1);
  }

  const { hashPasswordArgon2id, encryptField, blindIndex } = await import(
    "@/lib/server/crypto-vault"
  );

  const existing = await db.adminUser.findUnique({ where: { username } });
  if (existing) {
    if (existing.passwordHash && !force) {
      console.error(
        `Admin "${username}" already has a password — pass --force to rotate it (all its sessions are revoked).`
      );
      process.exit(1);
    }
    await db.adminUser.update({
      where: { id: existing.id },
      data: {
        name,
        email: encryptField(email) ?? "",
        emailIndex: blindIndex(email) ?? "",
        role: "super",
        active: true,
        passwordHash: hashPasswordArgon2id(finalPassword),
        /* rotate the session epoch — every outstanding token dies */
        sessionVersion: { increment: 1 },
      },
    });
    console.log(`Existing admin "${username}" was (re)provisioned as super with a fresh Argon2id password.`);
  } else {
    await db.adminUser.create({
      data: {
        username,
        name,
        email: encryptField(email) ?? "",
        emailIndex: blindIndex(email) ?? "",
        role: "super",
        active: true,
        passwordHash: hashPasswordArgon2id(finalPassword),
      },
    });
    console.log(`Super admin "${username}" provisioned.`);
  }

  if (wantsGenerated || !password) {
    // generated credential — printed ONCE, never logged elsewhere
    console.log(`Generated password: ${finalPassword}`);
    console.log("Store it securely now — it cannot be recovered (only rotated).");
  } else {
    console.log("Password set from the supplied environment/flag value.");
  }
  await db.$disconnect();
}

main().catch(async (error) => {
  console.error("bootstrap-admin failed:", error instanceof Error ? error.message : error);
  await db.$disconnect();
  process.exit(1);
});
