/// <reference types="bun-types" />
/**
 * Ashrilogic — webhook system tests (ROUND 113).
 *
 * Covers the order-event webhook contract WITHOUT a live server:
 *
 *  1. SIGNATURES: sign → verify roundtrip; tampered body rejected;
 *     replay outside the tolerance window rejected; malformed headers
 *     rejected; constant-time comparison (hex length mismatch).
 *  2. SSRF GUARD: https accepted; http refused EXCEPT loopback hosts;
 *     userinfo refused; private/reserved IP literals refused (IPv4 + IPv6
 *     incl. v4-mapped); garbage refused.
 *  3. QUEUE + DISPATCH: enqueue fans out only to ACTIVE endpoints
 *     subscribed to the event; delivery attempts against a stubbed fetch
 *     succeed (2xx) and fail (500 + network) with the documented retry
 *     backoff; exhaustion after MAX_ATTEMPTS; endpoint-disabled mid-queue
 *     exhausts cleanly; the result write is CAS-guarded.
 *  4. RETENTION: terminal rows past the window are swept; pending rows
 *     survive.
 */

import { describe, expect, test, beforeAll, afterAll } from "bun:test";
import { ensureDemoEnv, getTestDb } from "./test-setup";

ensureDemoEnv();

let db: Awaited<ReturnType<typeof getTestDb>>;
let webhooks: typeof import("@/lib/server/webhooks");

const INSTANCE = "webhook-test-instance";
const OTHER = "webhook-test-other";

/* ROUND 120 — transport + DNS stubs (the offline battery must never
 * perform real DNS or TCP; the production path pins the connection to
 * the validated address through node:http(s) with a custom lookup). */
const fetchCalls: {
  url: string;
  body: string;
  headers: Record<string, string>;
  pin: { ip: string; family: number } | null;
}[] = [];
let fetchMode: "ok" | "fail-500" | "network-error" = "ok";

function stubTransport() {
  webhooks.__setWebhookDnsForTests(async (_hostname) => [
    { address: "93.184.216.34", family: 4 },
  ]);
  webhooks.__setWebhookTransportForTests(async (url, headers, body, _timeout, pin) => {
    fetchCalls.push({ url, body, headers, pin });
    if (fetchMode === "network-error") throw new Error("fetch failed");
    if (fetchMode === "fail-500") {
      return { ok: false, status: 500, errorClass: "invalid-response" };
    }
    return { ok: true, status: 200 };
  });
}

beforeAll(async () => {
  db = await getTestDb();
  webhooks = await import("@/lib/server/webhooks");
  stubTransport();

  for (const id of [INSTANCE, OTHER]) {
    await db.instance.create({
      data: {
        id,
        systemId: "inventory",
        orgJson: JSON.stringify({ name: "Hook Test", currency: "SAR" }),
        adminJson: "{}",
        prefsJson: "{}",
        modulesJson: JSON.stringify(["inventory"]),
      },
    });
  }
});

afterAll(async () => {
  webhooks.__setWebhookTransportForTests(null);
  webhooks.__setWebhookDnsForTests(null);
  try {
    await db.instance.deleteMany({ where: { id: { in: [INSTANCE, OTHER] } } });
    await db.webhookEndpoint.deleteMany({});
    await db.webhookDelivery.deleteMany({});
  } catch {
    /* throwaway DB — fresh anyway */
  }
});

/* ------------------------------------------------------------------ */
/* 1 — signatures                                                      */
/* ------------------------------------------------------------------ */

describe("webhook signatures", () => {
  const SECRET = "a".repeat(64);
  const BODY = JSON.stringify({ type: "order.placed", order: { id: "o1" } });

  test("sign → verify roundtrip", () => {
    const header = webhooks.signWebhook(SECRET, 1_700_000_000, BODY);
    expect(header).toMatch(/^t=1700000000,v1=[0-9a-f]{64}$/);
    expect(
      webhooks.verifyWebhookSignature(SECRET, header, BODY, 1_700_000_000)
    ).toBe(true);
  });

  test("tampered body rejected", () => {
    const header = webhooks.signWebhook(SECRET, 1_700_000_000, BODY);
    expect(
      webhooks.verifyWebhookSignature(SECRET, header, BODY + " ", 1_700_000_000)
    ).toBe(false);
  });

  test("wrong secret rejected (without throwing)", () => {
    const header = webhooks.signWebhook("b".repeat(64), 1_700_000_000, BODY);
    expect(
      webhooks.verifyWebhookSignature(SECRET, header, BODY, 1_700_000_000)
    ).toBe(false);
  });

  test("stale timestamp (replay window) rejected", () => {
    const now = Math.floor(Date.now() / 1000);
    const header = webhooks.signWebhook(SECRET, now - 3600, BODY); // 1h old
    expect(webhooks.verifyWebhookSignature(SECRET, header, BODY, now)).toBe(false);
  });

  test("malformed headers rejected", () => {
    const now = Math.floor(Date.now() / 1000);
    expect(webhooks.verifyWebhookSignature(SECRET, "garbage", BODY, now)).toBe(false);
    expect(webhooks.verifyWebhookSignature(SECRET, "t=abc,v1=xyz", BODY, now)).toBe(false);
    expect(webhooks.verifyWebhookSignature(SECRET, "v1=abcd", BODY, now)).toBe(false);
    // v1 of the wrong length (hex but short) — length mismatch path
    const good = webhooks.signWebhook(SECRET, now, BODY);
    const shortV1 = good.replace(/v1=[0-9a-f]{64}/, "v1=abcd");
    expect(webhooks.verifyWebhookSignature(SECRET, shortV1, BODY, now)).toBe(false);
  });
});

/* ------------------------------------------------------------------ */
/* 2 — SSRF guard                                                      */
/* ------------------------------------------------------------------ */

describe("webhook URL guard", () => {
  test("https public hosts accepted (443 / allowlisted ports only)", () => {
    for (const url of [
      "https://example.com/hook",
      "https://hooks.merchant.io/events",
      "https://api.example.sa/order-events?source=ashrilogic",
    ]) {
      expect(webhooks.assertSafeWebhookUrl(url).ok).toBe(true);
    }
    // ROUND 120 — arbitrary high ports are refused by default (SSRF
    // lateral-move surface); operators opt in via the env allowlist.
    const verdict = webhooks.assertSafeWebhookUrl("https://hooks.merchant.io:8443/events");
    expect(verdict.ok).toBe(false);
    if (!verdict.ok) expect(verdict.reason).toBe("port");
    const prev = process.env.WEBHOOK_ALLOWED_HTTPS_PORTS;
    process.env.WEBHOOK_ALLOWED_HTTPS_PORTS = "8443, 9443, 0, 99999, junk";
    expect(webhooks.assertSafeWebhookUrl("https://hooks.merchant.io:8443/events").ok).toBe(true);
    expect(webhooks.assertSafeWebhookUrl("https://hooks.merchant.io:9443/events").ok).toBe(true);
    // invalid entries in the allowlist are ignored, not fatal
    expect(webhooks.assertSafeWebhookUrl("https://hooks.merchant.io:9999/events").ok).toBe(false);
    process.env.WEBHOOK_ALLOWED_HTTPS_PORTS = prev;
  });

  test("ROUND 120 — https to loopback NAMES refused (dispatch DNS guard would refuse them anyway)", () => {
    expect(webhooks.assertSafeWebhookUrl("https://localhost/hook").ok).toBe(false);
    expect(webhooks.assertSafeWebhookUrl("https://127.0.0.1/hook").ok).toBe(false);
    expect(webhooks.assertSafeWebhookUrl("https://[::1]/hook").ok).toBe(false);
  });

  test("http refused for public hosts — allowed ONLY on loopback", () => {
    expect(webhooks.assertSafeWebhookUrl("http://example.com/hook").ok).toBe(false);
    expect(webhooks.assertSafeWebhookUrl("http://192.168.1.5/hook").ok).toBe(false);
    for (const url of ["http://localhost:3030/hook", "http://127.0.0.1:9/hook", "http://[::1]/hook"]) {
      expect(webhooks.assertSafeWebhookUrl(url).ok).toBe(true);
    }
  });

  test("userinfo in URL refused", () => {
    expect(webhooks.assertSafeWebhookUrl("https://user:pass@example.com/hook").ok).toBe(false);
  });

  test("private/reserved IPv4 literals refused over https", () => {
    for (const host of ["10.0.0.5", "172.16.0.1", "192.168.0.10", "127.0.0.1", "169.254.169.254", "100.64.0.1", "0.0.0.0", "224.0.0.1"]) {
      expect(webhooks.assertSafeWebhookUrl(`https://${host}/hook`).ok).toBe(false);
    }
  });

  test("private IPv6 literals refused (incl. IPv4-mapped decimal + hexadecimal forms)", () => {
    for (const host of [
      "::1",
      "::",
      "fe80::1",
      "fd00::1234",
      "ff02::1",
      "2001:db8::1",
      "::ffff:10.0.0.5",
      "::ffff:7f00:1",        // 127.0.0.1
      "::ffff:a9fe:a9fe",    // 169.254.169.254
      "::ffff:c0a8:0101",    // 192.168.1.1
    ]) {
      expect(webhooks.assertSafeWebhookUrl(`https://${host}/hook`).ok).toBe(false);
    }
  });

  test("public IPv4-mapped IPv6 remains accepted", () => {
    expect(webhooks.assertSafeWebhookUrl("https://[::ffff:0808:0808]/hook").ok).toBe(true);
  });

  test("garbage refused", () => {
    for (const url of ["", "not a url", "file:///etc/passwd", "gopher://localhost/x", "https://"]) {
      expect(webhooks.assertSafeWebhookUrl(url).ok).toBe(false);
    }
  });
});

/* ------------------------------------------------------------------ */
/* 3 — queue + dispatch                                                 */
/* ------------------------------------------------------------------ */

describe("webhook queue + dispatch", () => {
  test("enqueue fans out ONLY to active endpoints subscribed to the event", async () => {
    await db.webhookEndpoint.createMany({
      data: [
        {
          id: "ep-subscribed",
          instanceId: INSTANCE,
          url: "https://hooks.example.com/a",
          secret: "s".repeat(64),
          eventsJson: JSON.stringify(["order.placed", "order.cancelled"]),
          active: true,
        },
        {
          id: "ep-other-event",
          instanceId: INSTANCE,
          url: "https://hooks.example.com/b",
          secret: "s".repeat(64),
          eventsJson: JSON.stringify(["order.status_changed"]),
          active: true,
        },
        {
          id: "ep-inactive",
          instanceId: INSTANCE,
          url: "https://hooks.example.com/c",
          secret: "s".repeat(64),
          eventsJson: JSON.stringify(["order.placed"]),
          active: false,
        },
        {
          id: "ep-other-tenant",
          instanceId: OTHER,
          url: "https://hooks.example.com/d",
          secret: "s".repeat(64),
          eventsJson: JSON.stringify(["order.placed"]),
          active: true,
        },
      ],
    });

    fetchMode = "ok";
    fetchCalls.length = 0;
    const queued = await webhooks.enqueueWebhookEvent(INSTANCE, "order.placed", {
      id: "order-1",
      status: "pending",
    });
    expect(queued).toBe(1); // only ep-subscribed
    // give the opportunistic void dispatch a beat to land
    await new Promise((r) => setTimeout(r, 150));

    const rows = await db.webhookDelivery.findMany({ where: { instanceId: INSTANCE } });
    expect(rows.length).toBe(1);
    expect(rows[0].endpointId).toBe("ep-subscribed");
    expect(rows[0].status).toBe("succeeded");
    expect(rows[0].deliveredAt).not.toBeNull();
    expect(rows[0].attempts).toBe(1);

    // the POST went to the subscribed endpoint with a valid signature
    expect(fetchCalls.length).toBe(1);
    expect(fetchCalls[0].url).toBe("https://hooks.example.com/a");
    const payload = JSON.parse(fetchCalls[0].body) as { type: string; instanceId: string };
    expect(payload.type).toBe("order.placed");
    expect(payload.instanceId).toBe(INSTANCE);
    expect(
      webhooks.verifyWebhookSignature(
        "s".repeat(64),
        fetchCalls[0].headers["x-ashrilogic-signature"],
        fetchCalls[0].body
      )
    ).toBe(true);
  });

  test("failing endpoint (500) → failed + backoff; retries exhaust at max attempts", async () => {
    await new Promise((r) => setTimeout(r, 250)); /* settle straggler dispatches */
    await db.webhookEndpoint.update({
      where: { id: "ep-subscribed" },
      data: { url: "https://hooks.example.com/fail" },
    });
    await db.webhookDelivery.deleteMany({});

    fetchMode = "fail-500";
    fetchCalls.length = 0;
    await webhooks.enqueueWebhookEvent(INSTANCE, "order.placed", { id: "order-2" });
    await new Promise((r) => setTimeout(r, 300));
    // immediate first attempt fails, schedules the backoff
    let row = await db.webhookDelivery.findFirstOrThrow({});
    expect(row.status).toBe("failed");
    expect(row.attempts).toBe(1);
    expect(row.responseStatus).toBe(500);
    expect(row.error).toBe("invalid-response");
    expect(row.nextAttemptAt).not.toBeNull();

    // force the row due and re-dispatch through the exhaustion ladder
    for (let i = 2; i <= 5; i++) {
      await db.webhookDelivery.update({
        where: { id: row.id },
        data: { nextAttemptAt: new Date(Date.now() - 1000) },
      });
      await webhooks.dispatchDueWebhooks();
      row = await db.webhookDelivery.findFirstOrThrow({});
      expect(row.attempts).toBe(i);
      if (i < 5) {
        expect(row.status).toBe("failed");
        expect(row.nextAttemptAt).not.toBeNull();
      } else {
        expect(row.status).toBe("exhausted");
        expect(row.exhaustedAt).not.toBeNull();
        expect(row.nextAttemptAt).not.toBeNull();
      }
    }
    // exhausted rows are NOT due anymore
    await webhooks.dispatchDueWebhooks();
    row = await db.webhookDelivery.findFirstOrThrow({});
    expect(row.attempts).toBe(5);
  });

  test("network error classification + disabled endpoint mid-queue exhausts cleanly", async () => {
    await db.webhookDelivery.deleteMany({});
    fetchMode = "network-error";

    await webhooks.enqueueWebhookEvent(INSTANCE, "order.placed", { id: "order-3" });
    await new Promise((r) => setTimeout(r, 150));
    let row = await db.webhookDelivery.findFirstOrThrow({});
    expect(row.status).toBe("failed");
    expect(row.error).toBe("network");

    // disable the endpoint → the pending retry exhausts with the reason
    await db.webhookEndpoint.update({
      where: { id: "ep-subscribed" },
      data: { active: false },
    });
    await db.webhookDelivery.update({
      where: { id: row.id },
      data: { nextAttemptAt: new Date(Date.now() - 1000) },
    });
    await webhooks.dispatchDueWebhooks();
    row = await db.webhookDelivery.findFirstOrThrow({});
    expect(row.status).toBe("exhausted");
    expect(row.error).toBe("endpoint-disabled");
    expect(row.deliveredAt).toBeNull();
  });

  test("unsafe stored URL is refused at dispatch (never fetched)", async () => {
    await db.webhookDelivery.deleteMany({});
    fetchCalls.length = 0;
    // write a row whose endpoint URL the create-path would have refused —
    // the dispatch-time re-validation must refuse it too
    await db.webhookEndpoint.update({
      where: { id: "ep-subscribed" },
      data: { active: true, url: "https://169.254.169.254/latest/meta-data" },
    });
    await webhooks.enqueueWebhookEvent(INSTANCE, "order.placed", { id: "order-4" });
    await new Promise((r) => setTimeout(r, 150));
    const row = await db.webhookDelivery.findFirstOrThrow({});
    expect(row.status).toBe("failed");
    expect(row.error).toBe("unsafe-url");
    expect(fetchCalls.length).toBe(0); // never hit the network
  });
});

/* ------------------------------------------------------------------ */
/* 4 — retention                                                        */
/* ------------------------------------------------------------------ */

describe("webhook retention sweep", () => {
  test("terminal rows past the window are swept; fresh + pending survive", async () => {
    await db.webhookDelivery.deleteMany({});
    const old = new Date(Date.now() - 31 * 24 * 60 * 60 * 1000);
    await db.webhookDelivery.createMany({
      data: [
        { id: "old-ok", endpointId: "ep-subscribed", instanceId: INSTANCE, event: "order.placed", payloadJson: "{}", status: "succeeded", createdAt: old, deliveredAt: old },
        { id: "old-exhausted", endpointId: "ep-subscribed", instanceId: INSTANCE, event: "order.placed", payloadJson: "{}", status: "exhausted", createdAt: old, exhaustedAt: old },
        { id: "new-ok", endpointId: "ep-subscribed", instanceId: INSTANCE, event: "order.placed", payloadJson: "{}", status: "succeeded" },
        { id: "old-pending", endpointId: "ep-subscribed", instanceId: INSTANCE, event: "order.placed", payloadJson: "{}", status: "pending", createdAt: old },
      ],
    });
    // reset the module-level sweep throttle for the test
    await (webhooks as unknown as { sweepWebhookRetention: (now: number) => Promise<void> }).sweepWebhookRetention(Date.now());
    const remaining = await db.webhookDelivery.findMany({ select: { id: true } });
    const ids = remaining.map((r) => r.id).sort();
    expect(ids).toEqual(["new-ok", "old-pending"]);
  });
});

/* ------------------------------------------------------------------ */
/* 5 — delivery history (ROUND 115)                                     */
/* ------------------------------------------------------------------ */

describe("webhook delivery history", () => {
  test("foreign tenant's endpoint id → null (route answers 404, never a leak)", async () => {
    await db.webhookDelivery.deleteMany({});
    await db.webhookEndpoint.create({
      data: {
        id: "ep-foreign",
        instanceId: OTHER,
        url: "https://hooks.example.com/foreign",
        secret: "f".repeat(64),
        eventsJson: JSON.stringify(["order.placed"]),
        active: true,
      },
    });
    const page = await webhooks.listEndpointDeliveries(INSTANCE, "ep-foreign", { limit: 10 });
    expect(page).toBeNull();
  });

  test("ROUND 118 — liveBacklog counts pending + failed rows, on every page", async () => {
    await db.webhookDelivery.deleteMany({});
    /* a controlled mix: 2 pending (in queue), 1 failed (in backoff),
     * 3 succeeded + 1 exhausted (terminal — NOT backlog) */
    const mk = (id: string, status: string, extra: Record<string, unknown> = {}) => ({
      id,
      endpointId: "ep-subscribed",
      instanceId: INSTANCE,
      event: "order.placed",
      payloadJson: JSON.stringify({ id }),
      status,
      createdAt: new Date(Date.now() - 60_000),
      ...extra,
    });
    await db.webhookDelivery.createMany({
      data: [
        mk("bl-p1", "pending"),
        mk("bl-p2", "pending"),
        mk("bl-f1", "failed", { attempts: 1, nextAttemptAt: new Date(Date.now() + 60_000) }),
        mk("bl-s1", "succeeded", { attempts: 1, deliveredAt: new Date() }),
        mk("bl-s2", "succeeded", { attempts: 1, deliveredAt: new Date() }),
        mk("bl-s3", "succeeded", { attempts: 1, deliveredAt: new Date() }),
        mk("bl-e1", "exhausted", {
          attempts: 5,
          nextAttemptAt: null,
          exhaustedAt: new Date(),
        }),
      ],
    });

    /* page 1 (small page) still carries the FULL backlog count — the
       footer must not depend on which slice is loaded */
    const page = await webhooks.listEndpointDeliveries(INSTANCE, "ep-subscribed", { limit: 2 });
    expect(page).not.toBeNull();
    expect(page!.liveBacklog).toBe(3);

    /* the backlog is tenant-scoped with the endpoint: rows on a foreign
       endpoint never inflate it */
    await db.webhookEndpoint.create({
      data: {
        id: "ep-bl-other",
        instanceId: OTHER,
        url: "https://hooks.example.com/bl",
        secret: "b".repeat(64),
        eventsJson: JSON.stringify(["order.placed"]),
        active: true,
      },
    });
    await db.webhookDelivery.createMany({
      data: [mk("bl-x1", "pending"), mk("bl-x2", "pending")].map((r) => ({
        ...r,
        endpointId: "ep-bl-other",
        instanceId: OTHER,
      })),
    });
    const again = await webhooks.listEndpointDeliveries(INSTANCE, "ep-subscribed", { limit: 2 });
    expect(again!.liveBacklog).toBe(3);
  });

  test("keyset pagination: newest-first pages, no overlap/skip, exhausted cursor is null", async () => {
    await db.webhookDelivery.deleteMany({});
    /* 7 deliveries with DISTINCT createdAt values (ties are covered by the
       shared keyset contract already exercised by the activity feed) */
    const rows = Array.from({ length: 7 }, (_, i) => ({
      id: `hist-${i}`,
      endpointId: "ep-subscribed",
      instanceId: INSTANCE,
      event: "order.placed",
      payloadJson: JSON.stringify({ n: i }),
      status: i === 0 ? "pending" : "succeeded",
      attempts: i === 0 ? 0 : 1,
      createdAt: new Date(Date.now() - (7 - i) * 60_000),
      deliveredAt: i === 0 ? null : new Date(Date.now() - (7 - i) * 60_000 + 500),
    }));
    await db.webhookDelivery.createMany({ data: rows });

    /* page 1: 3 rows, newest first, cursor present */
    const p1 = await webhooks.listEndpointDeliveries(INSTANCE, "ep-subscribed", { limit: 3 });
    expect(p1).not.toBeNull();
    expect(p1!.deliveries.map((d) => d.id)).toEqual(["hist-6", "hist-5", "hist-4"]);
    expect(p1!.nextCursor).toBeTypeOf("string");

    /* page 2 + 3 via the opaque cursor (decoded exactly like the route) */
    const { decodeKeyset } = await import("@/lib/server/keyset");
    const cur1 = decodeKeyset(p1!.nextCursor);
    expect(cur1).not.toBeNull();
    const p2 = await webhooks.listEndpointDeliveries(INSTANCE, "ep-subscribed", {
      limit: 3,
      cursor: cur1,
    });
    expect(p2!.deliveries.map((d) => d.id)).toEqual(["hist-3", "hist-2", "hist-1"]);
    const cur2 = decodeKeyset(p2!.nextCursor);
    const p3 = await webhooks.listEndpointDeliveries(INSTANCE, "ep-subscribed", {
      limit: 3,
      cursor: cur2,
    });
    /* last page: single row, cursor exhausted */
    expect(p3!.deliveries.map((d) => d.id)).toEqual(["hist-0"]);
    expect(p3!.nextCursor).toBeNull();

    /* pages never overlap or skip */
    const all = [...p1!.deliveries, ...p2!.deliveries, ...p3!.deliveries].map((d) => d.id);
    expect(new Set(all).size).toBe(7);
  });

  test("DTO shape: sanitized fields, verbatim payload, soft-deleted endpoint stays readable", async () => {
    await db.webhookDelivery.deleteMany({});
    /* an endpoint this tenant SOFT-DELETED — its history is audit material */
    await db.webhookEndpoint.create({
      data: {
        id: "ep-deleted",
        instanceId: INSTANCE,
        url: "https://hooks.example.com/gone",
        secret: "d".repeat(64),
        eventsJson: JSON.stringify(["order.cancelled"]),
        active: false,
        deletedAt: new Date(),
      },
    });
    const payload = JSON.stringify({ type: "order.cancelled", order: { code: "X1" } });
    await db.webhookDelivery.create({
      data: {
        endpointId: "ep-deleted",
        instanceId: INSTANCE,
        event: "order.cancelled",
        payloadJson: payload,
        status: "failed",
        attempts: 2,
        responseStatus: 500,
        error: "invalid-response",
        nextAttemptAt: new Date(Date.now() + 60_000),
      },
    });
    const page = await webhooks.listEndpointDeliveries(INSTANCE, "ep-deleted", { limit: 10 });
    expect(page).not.toBeNull();
    expect(page!.deliveries).toHaveLength(1);
    const dto = page!.deliveries[0]!;
    expect(dto.event).toBe("order.cancelled");
    expect(dto.status).toBe("failed");
    expect(dto.attempts).toBe(2);
    expect(dto.responseStatus).toBe(500);
    expect(dto.error).toBe("invalid-response");
    expect(dto.payload).toBe(payload);
    expect(dto.nextAttemptAt).toBeTypeOf("string");
    expect(dto.deliveredAt).toBeNull();
    /* foreign deliveries on the SAME endpoint id can never appear: the
       instanceId filter rides every query */
    const foreign = await webhooks.listEndpointDeliveries(OTHER, "ep-deleted", { limit: 10 });
    expect(foreign).toBeNull(); // endpoint belongs to INSTANCE, not OTHER
  });
});

/* ------------------------------------------------------------------ */
/* 6 — manual redelivery (ROUND 116)                                    */
/* ------------------------------------------------------------------ */

describe("webhook manual redelivery", () => {
  const PAYLOAD = JSON.stringify({
    type: "order.placed",
    createdAt: "2026-09-19T00:00:00.000Z",
    instanceId: INSTANCE,
    order: { id: "o-r116", code: "R116" },
  });

  async function seedEndpoint(overrides: Record<string, unknown> = {}) {
    await db.webhookEndpoint.deleteMany({ where: { id: "ep-r116" } });
    return db.webhookEndpoint.create({
      data: {
        id: "ep-r116",
        instanceId: INSTANCE,
        url: "http://localhost:3030/hook",
        secret: "1".repeat(64),
        eventsJson: JSON.stringify(["order.placed"]),
        active: true,
        ...overrides,
      },
    });
  }

  async function seedDelivery(overrides: Record<string, unknown> = {}) {
    await db.webhookDelivery.deleteMany({ where: { id: "dl-r116" } });
    return db.webhookDelivery.create({
      data: {
        id: "dl-r116",
        endpointId: "ep-r116",
        instanceId: INSTANCE,
        event: "order.placed",
        payloadJson: PAYLOAD,
        status: "failed",
        attempts: 1,
        responseStatus: 500,
        error: "invalid-response",
        nextAttemptAt: new Date(Date.now() + 60_000),
        ...overrides,
      },
    });
  }

  test("eligibility matrix: failed + exhausted OK; pending + succeeded refused; deleted + paused refused", async () => {
    await db.webhookDelivery.deleteMany({});

    /* failed → ok (new pending row, verbatim payload + event, lineage set) */
    await seedEndpoint();
    await seedDelivery({ status: "failed" });
    const failedCase = await webhooks.redeliverWebhookDelivery(INSTANCE, "ep-r116", "dl-r116");
    expect(failedCase.ok).toBe(true);
    if (failedCase.ok) {
      expect(failedCase.delivery.status).toBe("pending");
      expect(failedCase.delivery.event).toBe("order.placed");
      expect(failedCase.delivery.payload).toBe(PAYLOAD);
      expect(failedCase.delivery.redeliveredFrom).toBe("dl-r116");
      expect(failedCase.delivery.attempts).toBe(0);
    }

    /* exhausted → ok */
    await db.webhookDelivery.deleteMany({});
    await seedDelivery({ status: "exhausted", attempts: 5, nextAttemptAt: null, exhaustedAt: new Date() });
    const exhaustedCase = await webhooks.redeliverWebhookDelivery(INSTANCE, "ep-r116", "dl-r116");
    expect(exhaustedCase.ok).toBe(true);

    /* pending → not-redeliverable (already in flight) */
    await db.webhookDelivery.deleteMany({});
    await seedDelivery({ status: "pending", attempts: 0, nextAttemptAt: null });
    const pendingCase = await webhooks.redeliverWebhookDelivery(INSTANCE, "ep-r116", "dl-r116");
    expect(pendingCase).toEqual({ ok: false, reason: "not-redeliverable" });

    /* succeeded → not-redeliverable (delivered — a forced duplicate is
       receiver spam, not debugging) */
    await db.webhookDelivery.deleteMany({});
    await seedDelivery({ status: "succeeded", attempts: 1, nextAttemptAt: null, deliveredAt: new Date() });
    const okCase = await webhooks.redeliverWebhookDelivery(INSTANCE, "ep-r116", "dl-r116");
    expect(okCase).toEqual({ ok: false, reason: "not-redeliverable" });

    /* soft-deleted endpoint → endpoint-deleted (history stays readable,
       but a deleted destination never dispatches) */
    await db.webhookDelivery.deleteMany({});
    await seedEndpoint({ deletedAt: new Date(), active: false });
    await seedDelivery({ status: "exhausted", attempts: 5, nextAttemptAt: null });
    const deletedCase = await webhooks.redeliverWebhookDelivery(INSTANCE, "ep-r116", "dl-r116");
    expect(deletedCase).toEqual({ ok: false, reason: "endpoint-deleted" });

    /* paused endpoint → endpoint-paused (the sweeper would exhaust it) */
    await db.webhookDelivery.deleteMany({});
    await seedEndpoint({ active: false });
    await seedDelivery({ status: "exhausted", attempts: 5, nextAttemptAt: null });
    const pausedCase = await webhooks.redeliverWebhookDelivery(INSTANCE, "ep-r116", "dl-r116");
    expect(pausedCase).toEqual({ ok: false, reason: "endpoint-paused" });
  });

  test("foreign tenant: unknown endpoint AND foreign delivery are refused, never a leak", async () => {
    await db.webhookDelivery.deleteMany({});
    /* endpoint belongs to OTHER; asking as INSTANCE → endpoint-not-found */
    await db.webhookEndpoint.deleteMany({ where: { id: "ep-r116-foreign" } });
    await db.webhookEndpoint.create({
      data: {
        id: "ep-r116-foreign",
        instanceId: OTHER,
        url: "https://hooks.example.com/x",
        secret: "2".repeat(64),
        eventsJson: JSON.stringify(["order.placed"]),
        active: true,
      },
    });
    await db.webhookDelivery.create({
      data: {
        id: "dl-r116-foreign",
        endpointId: "ep-r116-foreign",
        instanceId: OTHER,
        event: "order.placed",
        payloadJson: PAYLOAD,
        status: "exhausted",
        attempts: 5,
      },
    });
    const wrongEndpoint = await webhooks.redeliverWebhookDelivery(
      INSTANCE,
      "ep-r116-foreign",
      "dl-r116-foreign"
    );
    expect(wrongEndpoint).toEqual({ ok: false, reason: "endpoint-not-found" });

    /* own endpoint, but the delivery row is another tenant's → 404-class */
    await seedEndpoint();
    const wrongDelivery = await webhooks.redeliverWebhookDelivery(
      INSTANCE,
      "ep-r116",
      "dl-r116-foreign"
    );
    expect(wrongDelivery).toEqual({ ok: false, reason: "delivery-not-found" });
  });

  test("redelivery dispatches VERBATIM payload signed with the CURRENT secret (rotate → redeliver flow)", async () => {
    await db.webhookDelivery.deleteMany({});
    fetchCalls.length = 0;
    fetchMode = "ok";

    const ROTATED = "9".repeat(64);
    await seedEndpoint({ secret: ROTATED });
    await seedDelivery({ status: "exhausted", attempts: 5, nextAttemptAt: null });

    const verdict = await webhooks.redeliverWebhookDelivery(INSTANCE, "ep-r116", "dl-r116");
    expect(verdict.ok).toBe(true);

    /* the fire-and-forget dispatch settles against the stubbed fetch —
       poll the DB (bounded) until the manual row is succeeded */
    let row: { status: string } | null = null;
    for (let i = 0; i < 50 && !row; i++) {
      const found = await db.webhookDelivery.findFirst({
        where: { redeliveredFrom: "dl-r116" },
        select: { status: true },
      });
      if (found?.status === "succeeded") row = found;
      else await new Promise((r) => setTimeout(r, 20));
    }
    expect(row?.status).toBe("succeeded");

    /* the receiver saw EXACTLY the canonical payload bytes, the correct
       event header, and a signature that verifies under the ROTATED
       secret (the pre-rotation secret must NOT verify) */
    const call = fetchCalls.find((c) => c.body === PAYLOAD);
    expect(call).toBeDefined();
    expect(call!.headers["x-ashrilogic-event"]).toBe("order.placed");
    expect(
      webhooks.verifyWebhookSignature(ROTATED, call!.headers["x-ashrilogic-signature"], PAYLOAD)
    ).toBe(true);
    expect(
      webhooks.verifyWebhookSignature("1".repeat(64), call!.headers["x-ashrilogic-signature"], PAYLOAD)
    ).toBe(false);
  });

  test("one LIVE redelivery chain per original; terminal children never block a fresh one", async () => {
    await db.webhookDelivery.deleteMany({});
    await seedEndpoint();
    await seedDelivery({ status: "failed" });

    /* first redelivery lands */
    const first = await webhooks.redeliverWebhookDelivery(INSTANCE, "ep-r116", "dl-r116");
    expect(first.ok).toBe(true);
    if (!first.ok) return;

    /* let the fire-and-forget dispatch settle its verdict on the child
       FIRST (deterministic state — no racing the dispatcher) */
    for (let i = 0; i < 50; i++) {
      const child = await db.webhookDelivery.findUnique({
        where: { id: first.delivery.id },
        select: { status: true },
      });
      if (child && child.status !== "pending") break;
      await new Promise((r) => setTimeout(r, 20));
    }

    /* force the child into a live state (pending or failed-in-backoff) —
       a second manual redelivery of the SAME original is refused */
    await db.webhookDelivery.update({
      where: { id: first.delivery.id },
      data: { status: "pending", nextAttemptAt: null },
    });
    const second = await webhooks.redeliverWebhookDelivery(INSTANCE, "ep-r116", "dl-r116");
    expect(second).toEqual({ ok: false, reason: "redelivery-in-flight" });

    /* also live: failed inside its backoff window */
    await db.webhookDelivery.update({
      where: { id: first.delivery.id },
      data: { status: "failed", nextAttemptAt: new Date(Date.now() + 60_000) },
    });
    const secondB = await webhooks.redeliverWebhookDelivery(INSTANCE, "ep-r116", "dl-r116");
    expect(secondB).toEqual({ ok: false, reason: "redelivery-in-flight" });

    /* child gone terminal (succeeded) → the owner may redeliver again */
    await db.webhookDelivery.update({
      where: { id: first.delivery.id },
      data: { status: "succeeded", deliveredAt: new Date(), nextAttemptAt: null },
    });
    const third = await webhooks.redeliverWebhookDelivery(INSTANCE, "ep-r116", "dl-r116");
    expect(third.ok).toBe(true);
  });

  test("endpoint live-row backlog at the cap → queue-busy", async () => {
    await db.webhookDelivery.deleteMany({});
    await seedEndpoint();
    await seedDelivery({ status: "failed" });
    /* 4 more live rows (pending) → the endpoint holds 5 live rows */
    await db.webhookDelivery.createMany({
      data: Array.from({ length: 4 }, (_, i) => ({
        id: `dl-r116-busy-${i}`,
        endpointId: "ep-r116",
        instanceId: INSTANCE,
        event: "order.placed",
        payloadJson: PAYLOAD,
        status: "pending",
      })),
    });
    const verdict = await webhooks.redeliverWebhookDelivery(INSTANCE, "ep-r116", "dl-r116");
    expect(verdict).toEqual({ ok: false, reason: "queue-busy" });
  });

  test("ops stats gain the manualRedeliveries counter (rows with lineage)", async () => {
    await db.webhookDelivery.deleteMany({});
    await seedEndpoint();
    await seedDelivery({ status: "failed" });
    await webhooks.redeliverWebhookDelivery(INSTANCE, "ep-r116", "dl-r116");
    /* settle the redelivery's fire-and-forget dispatch so it cannot bleed
     * into the next describe's transport-call assertions */
    await new Promise((r) => setTimeout(r, 250));
    const stats = await webhooks.webhookOpsStats();
    expect(stats.manualRedeliveries).toBe(1);
  });
});

/* ------------------------------------------------------------------ */
/* ROUND 120 — dispatch-time DNS validation + pinned transport (SSRF)  */
/* ------------------------------------------------------------------ */

describe("ROUND 120 — dispatch-time DNS validation (SSRF / rebinding)", () => {
  test("hostname resolving to a PRIVATE address never reaches the transport", async () => {
    await new Promise((r) => setTimeout(r, 250)); /* settle stragglers */
    await db.webhookDelivery.deleteMany({});
    await db.webhookEndpoint.update({
      where: { id: "ep-subscribed" },
      data: { active: true, url: "https://attacker.example.com/hook" },
    });
    // static private A record — the create-path guard cannot see it
    webhooks.__setWebhookDnsForTests(async () => [{ address: "169.254.169.254", family: 4 }]);
    fetchCalls.length = 0;
    await webhooks.enqueueWebhookEvent(INSTANCE, "order.placed", { id: "order-dns-1" });
    await new Promise((r) => setTimeout(r, 300));
    const row = await db.webhookDelivery.findFirstOrThrow({});
    expect(row.status).toBe("failed");
    expect(row.error).toBe("dns");
    expect(fetchCalls.filter((c) => c.url.startsWith("https://attacker.example.com")).length).toBe(0); // the POST never left the process
  });

  test("ANY private record in the answer set fails closed (mixed A records)", async () => {
    await db.webhookDelivery.deleteMany({});
    webhooks.__setWebhookDnsForTests(async () => [
      { address: "93.184.216.34", family: 4 },
      { address: "10.0.0.8", family: 4 }, // one poisoned record is enough
    ]);
    fetchCalls.length = 0;
    await webhooks.enqueueWebhookEvent(INSTANCE, "order.placed", { id: "order-dns-2" });
    await new Promise((r) => setTimeout(r, 300));
    const row = await db.webhookDelivery.findFirstOrThrow({});
    expect(row.error).toBe("dns");
    expect(fetchCalls.filter((c) => c.url.startsWith("https://attacker.example.com")).length).toBe(0);
  });

  test("private IPv6 / ULA resolution refused too", async () => {
    await db.webhookDelivery.deleteMany({});
    webhooks.__setWebhookDnsForTests(async () => [{ address: "fd12::1", family: 6 }]);
    fetchCalls.length = 0;
    await webhooks.enqueueWebhookEvent(INSTANCE, "order.placed", { id: "order-dns-3" });
    await new Promise((r) => setTimeout(r, 300));
    const row = await db.webhookDelivery.findFirstOrThrow({});
    expect(row.error).toBe("dns");
    expect(fetchCalls.filter((c) => c.url.startsWith("https://attacker.example.com")).length).toBe(0);
  });

  test("DNS resolution failure classifies as dns (not network)", async () => {
    await db.webhookDelivery.deleteMany({});
    webhooks.__setWebhookDnsForTests(async () => {
      throw new Error("ENOTFOUND");
    });
    fetchCalls.length = 0;
    await webhooks.enqueueWebhookEvent(INSTANCE, "order.placed", { id: "order-dns-4" });
    await new Promise((r) => setTimeout(r, 300));
    const row = await db.webhookDelivery.findFirstOrThrow({});
    expect(row.error).toBe("dns");
    expect(fetchCalls.filter((c) => c.url.startsWith("https://attacker.example.com")).length).toBe(0);
  });

  test("valid public resolution pins the connection to the validated IP", async () => {
    await db.webhookDelivery.deleteMany({});
    webhooks.__setWebhookDnsForTests(async () => [{ address: "203.0.113.10", family: 4 }]);
    fetchCalls.length = 0;
    fetchMode = "ok";
    await webhooks.enqueueWebhookEvent(INSTANCE, "order.placed", { id: "order-dns-5" });
    await new Promise((r) => setTimeout(r, 300));
    const row = await db.webhookDelivery.findFirstOrThrow({});
    expect(row.status).toBe("succeeded");
    // the transport received the PIN — the connect-time address equals the
    // dispatch-time validated address (no rebinding gap by construction)
    const call = fetchCalls.find((c) => c.url.startsWith("https://attacker.example.com"));
    expect(call).toBeDefined();
    expect(call?.pin).toEqual({ ip: "203.0.113.10", family: 4 });
  });

  test("rebind sequence: validation resolves public, second lookup private — the PIN still holds", async () => {
    await db.webhookDelivery.deleteMany({});
    let calls = 0;
    webhooks.__setWebhookDnsForTests(async () => {
      calls += 1;
      // the attacker's DNS flips AFTER validation — irrelevant: the
      // transport's connect-time lookup is the PINNED address, never a
      // fresh resolution
      return [{ address: calls <= 1 ? "203.0.113.10" : "169.254.169.254", family: 4 }];
    });
    fetchCalls.length = 0;
    await webhooks.enqueueWebhookEvent(INSTANCE, "order.placed", { id: "order-dns-6" });
    await new Promise((r) => setTimeout(r, 300));
    const row = await db.webhookDelivery.findFirstOrThrow({});
    expect(row.status).toBe("succeeded");
    const call = fetchCalls.find((c) => c.url.startsWith("https://attacker.example.com"));
    expect(call?.pin).toEqual({ ip: "203.0.113.10", family: 4 });
  });

  test("https IP-literal public host pins the literal (no DNS at all)", async () => {
    await db.webhookDelivery.deleteMany({});
    let dnsCalls = 0;
    webhooks.__setWebhookDnsForTests(async () => {
      dnsCalls += 1;
      return [{ address: "203.0.113.10", family: 4 }];
    });
    await db.webhookEndpoint.update({
      where: { id: "ep-subscribed" },
      data: { url: "https://203.0.113.7/hook" },
    });
    fetchCalls.length = 0;
    await webhooks.enqueueWebhookEvent(INSTANCE, "order.placed", { id: "order-dns-7" });
    await new Promise((r) => setTimeout(r, 300));
    expect(dnsCalls).toBe(0); // literals never resolve
    const call = fetchCalls.find((c) => c.url.startsWith("https://203.0.113.7"));
    expect(call).toBeDefined();
    expect(call?.pin).toEqual({ ip: "203.0.113.7", family: 4 });
  });

  test("redirect responses are their own sanitized error class", async () => {
    await db.webhookDelivery.deleteMany({});
    await db.webhookEndpoint.update({
      where: { id: "ep-subscribed" },
      data: { url: "https://hooks.example.com/redirect-me" },
    });
    webhooks.__setWebhookDnsForTests(async () => [{ address: "203.0.113.10", family: 4 }]);
    webhooks.__setWebhookTransportForTests(async (url, headers, body) => {
      fetchCalls.push({ url, body, headers, pin: null });
      return { ok: false, status: 302, errorClass: "redirect" };
    });
    await webhooks.enqueueWebhookEvent(INSTANCE, "order.placed", { id: "order-dns-8" });
    await new Promise((r) => setTimeout(r, 150));
    const row = await db.webhookDelivery.findFirstOrThrow({});
    expect(row.error).toBe("redirect");
    expect(row.status).toBe("failed");
    // restore the standing stub for later suites
    stubTransport();
  });
});

/* -------------------- ROUND 146 — IPv6 classifier completeness -------------------- */

describe("ROUND 146 — private IPv6 literals: NAT64 + hex IPv4-compatible forms", () => {
  test("NAT64 well-known prefix 64:ff9b::/96 embeds IPv4 and is classified (dotted + hex)", () => {
    // private IPv4 embedded in NAT64 — both textual forms must be refused
    expect(webhooks.assertSafeWebhookUrl("https://[64:ff9b::127.0.0.1]/hook").ok).toBe(false);
    expect(webhooks.assertSafeWebhookUrl("https://[64:ff9b::7f00:1]/hook").ok).toBe(false);
    expect(webhooks.assertSafeWebhookUrl("https://[64:ff9b::169.254.169.254]/hook").ok).toBe(false);
    expect(webhooks.assertSafeWebhookUrl("https://[64:ff9b::a9fe:a9fe]/hook").ok).toBe(false);
    expect(webhooks.assertSafeWebhookUrl("https://[64:ff9b::192.168.1.1]/hook").ok).toBe(false);
    // a PUBLIC IPv4 behind NAT64 stays accepted (the prefix itself is not banned)
    expect(webhooks.assertSafeWebhookUrl("https://[64:ff9b::8.8.8.8]/hook").ok).toBe(true);
    expect(webhooks.assertSafeWebhookUrl("https://[64:ff9b::0808:0808]/hook").ok).toBe(true);
  });

  test("hex IPv4-compatible forms (::7f00:1) are classified like the dotted form", () => {
    expect(webhooks.assertSafeWebhookUrl("https://[::127.0.0.1]/hook").ok).toBe(false); // dotted (pre-existing)
    expect(webhooks.assertSafeWebhookUrl("https://[::7f00:1]/hook").ok).toBe(false); // hex (ROUND 146)
    expect(webhooks.assertSafeWebhookUrl("https://[::a9fe:a9fe]/hook").ok).toBe(false); // 169.254.169.254
    // a public compatible address is not private — accepted
    expect(webhooks.assertSafeWebhookUrl("https://[::0808:0808]/hook").ok).toBe(true);
  });
});
