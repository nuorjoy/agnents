# Ashrilogic Premium

**منصة أنظمة إدارية سحابية متكاملة — 102 نظامًا إداريًا جاهزًا في شيفرة واحدة.**
A multi-tenant SaaS platform shipping **102 ready administrative systems**
(one codebase, catalog-driven), e-commerce storefronts, workspace
dashboards, public websites, and a hardened Super-Admin console.

Next.js 16 App Router · TypeScript strict · Tailwind CSS 4 · shadcn/ui ·
Prisma 6 (PostgreSQL) · TanStack Query · Zustand ·
RTL-first Arabic product with full EN/HI parity.

---

## Quick start

```bash
cp .env.example .env         # set DATABASE_URL (PostgreSQL) + the two root secrets
bun install
bunx prisma migrate deploy   # apply the versioned schema migrations
bun run db:generate          # generate the Prisma client
bun run seed:demo            # demo workspaces + catalog + orders
bun run dev                  # http://localhost:3000
```

Demo credentials (dev/test only — production never arms them, see
`src/lib/server/runtime-guard.ts`; the seeded super-admin password is
provisioned via `scripts/bootstrap-admin.ts` on real deployments):
Super Admin `admin` / `ashrilogic2024` on a freshly seeded database ·
workspace owner `sarah@elite-hospital.com` / `hospital2024x`.

## Documentation map

| Document | Purpose |
| --- | --- |
| `AGENTS.md` | **The engineering convention set — read before touching code** (hard rules, architecture map, round history) |
| `LICENSE` | The bilingual proprietary commercial EULA (Arabic authoritative) |
| `DEPLOYMENT.md` | Production deployment guide (Vercel + Neon PostgreSQL) |
| `docs/engineering/ARCHITECTURE.md` | Authoritative architecture map — layers, domains, API layering, enforcement |
| `docs/engineering/SECURITY-MODEL.md` | Authoritative security model — sessions, tenant isolation, rate limits, webhooks, secrets |
| `docs/engineering/DATA-MODEL.md` | Authoritative data model — dual schema, money fields, JSON policy, backups |
| `docs/engineering/API-ARCHITECTURE.md` | Authoritative API contract — routeHandler, error model, migration protocol |
| `docs/engineering/TEST-MATRIX.md` | Authoritative verification inventory — CI gates, offline/live suites |
| `docs/engineering/TECHNICAL-DEBT.md` | Engineering debt register — categorized P0-P3 with status per entry |

## Verification contract

A change is done when `bunx tsc --noEmit` is clean, `bunx eslint src/`
reports 0 errors, the offline security battery passes
(`bash .zscripts/test-battery.sh`), and the golden paths were exercised
in a real browser. "It compiles" is never sufficient.

## Release

```bash
bash .zscripts/package-release.sh R146
```

The tag is **required** — the packager stages from an explicit allowlist
and fails the build if any runtime artifact (`.env`, databases, `storage/`,
logs) ever reaches the archive.
