// Ashrilogic — no-op seed.
// The catalog is static bundled data (src/data/catalog.ts); instances are
// created at runtime through the wizard (POST /api/instances). Nothing to seed.
export async function main() {
  console.log("Ashrilogic: nothing to seed — catalog is static, instances are user-created.")
}

main()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
