# Ashrilogic — Versioned Database Migrations

## The strategy

PostgreSQL is the platform's only database engine. Production schema
changes are **versioned migrations**, never `db:push`:

| Command | Environment | Purpose |
|---|---|---|
| `bun run db:migrate` | development | Creates a NEW versioned migration from schema edits (reviewable, reversible) and applies it |
| `bun run db:deploy` | **production** | Applies pending versioned migrations only (no drift detection writes, no data loss) |
| `bun run db:push` | dev/sandbox ONLY | Fast schema sync for throwaway databases — **NEVER the production source of truth** |
| `bun run db:generate` | all | Regenerates the Prisma client from `prisma/schema.prisma` |
| `bun run migrate:sqlite` | operator, one-time | Imports an existing SQLite database's DATA into the PostgreSQL database (see `scripts/migrate-sqlite-to-postgres.ts`) |

## Rules

1. **Every schema change is a migration file** under `prisma/migrations/<stamp>_<name>/migration.sql` — versioned, reviewable, reversible where realistically possible.
2. **Edit `prisma/schema.prisma`, then run `bun run db:migrate`** to generate the migration. Review the generated SQL before committing it.
3. **Destructive changes** require the documented compatibility path: introduce the compatible schema → backfill → verify → switch reads/writes → remove legacy — never a single destructive migration.
4. **The baseline** `20260928000000_postgres_baseline` captures the full schema at the PostgreSQL cutover (v0.15.3). Fresh installs: `bun run db:deploy` + `bun run bootstrap:admin` + (demo only) `bun run seed:demo`.

## Migrating an existing SQLite deployment

Operators moving a live SQLite database (the pre-cutover architecture)
onto PostgreSQL run the one-time importer:

```bash
# 1. provision the PostgreSQL schema (fresh database)
DATABASE_URL='postgresql://…' bun run db:deploy

# 2. import the SQLite data (non-destructive; validates counts + relations)
DATABASE_URL='postgresql://…' \
LEGACY_SQLITE_PATH='./db/custom.db' \
bun run migrate:sqlite
```

The importer reads the legacy SQLite file READ-ONLY, copies every table in
foreign-key-safe order, preserves ids/timestamps/unique values exactly, and
validates row counts + critical records before reporting success. The
legacy SQLite file is never modified; keep it as the rollback artifact.
