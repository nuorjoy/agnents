-- ROUND 165 — durable campaign dispatch lifecycle.
-- Additive-only columns on NewsletterCampaign: the enqueue-done marker, the
-- dispatch cursor (idempotent resume across crashes/ticks), the enqueue
-- count (no silent truncation), and the terminal per-recipient outcome
-- counts stamped at completion. Existing rows (draft/sent) are untouched;
-- the new "sending" status is only ever written by the claim transition
-- draft -> sending.
ALTER TABLE "NewsletterCampaign"
  ADD COLUMN "dispatchCursor" TEXT,
  ADD COLUMN "dispatchEnqueueDone" BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN "dispatchEnqueued" INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN "delivered" INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN "failed" INTEGER NOT NULL DEFAULT 0;
