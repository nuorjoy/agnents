-- ROUND 171 — DB-backed business invariants:
--  1. ModuleRecord unique record-code law («كل ID فريد تماماً»):
--     normalized codeKey column + composite unique (NULLs coexist).
--  2. WalletTxn exactly-once grants: nullable dedupeKey + unique.
--  3. Admin (platform-wide) trash-feed deletedAt indexes (6 tenant tables).
-- All new columns start NULL (safe with the new unique constraints);
-- codeKey is backfilled by scripts/backfill-record-codekey.ts.

ALTER TABLE "ModuleRecord" ADD COLUMN "codeKey" TEXT;

-- CreateIndex
CREATE UNIQUE INDEX "ModuleRecord_instanceId_moduleId_codeKey_key" ON "ModuleRecord"("instanceId", "moduleId", "codeKey");

ALTER TABLE "WalletTxn" ADD COLUMN "dedupeKey" TEXT;

-- CreateIndex
CREATE UNIQUE INDEX "WalletTxn_instanceId_dedupeKey_key" ON "WalletTxn"("instanceId", "dedupeKey");

-- CreateIndex (admin trash feed — deletedAt-only lookups)
CREATE INDEX "SiteOrder_deletedAt_idx" ON "SiteOrder"("deletedAt");
CREATE INDEX "SiteCustomer_deletedAt_idx" ON "SiteCustomer"("deletedAt");
CREATE INDEX "StoreCoupon_deletedAt_idx" ON "StoreCoupon"("deletedAt");
CREATE INDEX "TeamMember_deletedAt_idx" ON "TeamMember"("deletedAt");
CREATE INDEX "SiteReview_deletedAt_idx" ON "SiteReview"("deletedAt");
CREATE INDEX "ModuleRecord_deletedAt_idx" ON "ModuleRecord"("deletedAt");
