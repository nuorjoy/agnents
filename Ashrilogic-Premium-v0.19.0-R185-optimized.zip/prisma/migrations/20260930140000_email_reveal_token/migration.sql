-- ROUND 166 — one-time sealed-email reveal tokens (استعادة البريد المختوم).
-- Additive table only; no existing row is touched and the vault seal itself
-- is NOT weakened — the token row stores the sha256 of a raw 32-byte token,
-- NEVER the plaintext email it eventually unseals exactly once.
-- CreateTable
CREATE TABLE "EmailRevealToken" (
    "id" TEXT NOT NULL,
    "createdById" TEXT NOT NULL,
    "createdByName" TEXT NOT NULL,
    "targetType" TEXT NOT NULL,
    "targetId" TEXT NOT NULL,
    "instanceId" TEXT,
    "tokenHash" TEXT NOT NULL,
    "reason" TEXT NOT NULL,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "usedAt" TIMESTAMP(3),
    "usedByName" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "EmailRevealToken_pkey" PRIMARY KEY ("id")
);

-- CreateIndex — the consume path resolves by sha256(raw token): UNIQUE.
CREATE UNIQUE INDEX "EmailRevealToken_tokenHash_key" ON "EmailRevealToken"("tokenHash");

-- CreateIndex (desc — the minter's history feed reads newest first)
CREATE INDEX "EmailRevealToken_createdById_createdAt_idx" ON "EmailRevealToken"("createdById", "createdAt" DESC);
