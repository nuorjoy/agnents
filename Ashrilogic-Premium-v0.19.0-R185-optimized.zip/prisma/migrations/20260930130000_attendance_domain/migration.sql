-- ROUND 166 — attendance domain (الحضور والغياب, SAMS).
-- Four additive tables; the derived daily state is NEVER persisted (it is
-- computed from Movements + Policy + Allowances — absence is not a
-- movement). Existing rows are untouched: every column carries its default
-- or is nullable, and the Instance back-relations are metadata-only.
-- CreateTable
CREATE TABLE "AttendancePolicy" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "dayStartMin" INTEGER NOT NULL DEFAULT 480,
    "dayEndMin" INTEGER NOT NULL DEFAULT 1080,
    "graceMin" INTEGER NOT NULL DEFAULT 10,
    "absenceEvalMin" INTEGER NOT NULL DEFAULT 1260,
    "requireReview" BOOLEAN NOT NULL DEFAULT true,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AttendancePolicy_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AttendanceMovement" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "studentCode" TEXT NOT NULL,
    "direction" TEXT NOT NULL,
    "method" TEXT NOT NULL,
    "occurredAt" TIMESTAMP(3) NOT NULL,
    "recordedById" TEXT NOT NULL,
    "recordedByName" TEXT NOT NULL,
    "qrTokenId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "AttendanceMovement_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AttendanceQrToken" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "tokenHash" TEXT NOT NULL,
    "studentCode" TEXT NOT NULL,
    "direction" TEXT NOT NULL,
    "gateLabel" TEXT,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "usedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "AttendanceQrToken_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AttendanceAllowance" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "studentCode" TEXT NOT NULL,
    "kind" TEXT NOT NULL,
    "startsAt" TIMESTAMP(3) NOT NULL,
    "endsAt" TIMESTAMP(3) NOT NULL,
    "note" TEXT,
    "createdById" TEXT NOT NULL,
    "createdByName" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "AttendanceAllowance_pkey" PRIMARY KEY ("id")
);

-- CreateIndex — one policy per workspace (the lazy upsert target).
CREATE UNIQUE INDEX "AttendancePolicy_instanceId_key" ON "AttendancePolicy"("instanceId");

-- CreateIndex (desc — the feed order the day queries read)
CREATE INDEX "AttendanceMovement_instanceId_studentCode_occurredAt_idx" ON "AttendanceMovement"("instanceId", "studentCode", "occurredAt" DESC);

-- CreateIndex
CREATE INDEX "AttendanceMovement_instanceId_occurredAt_idx" ON "AttendanceMovement"("instanceId", "occurredAt" DESC);

-- CreateIndex — tokenHash lookup is the redeem path: UNIQUE (sha256(raw)).
CREATE UNIQUE INDEX "AttendanceQrToken_tokenHash_key" ON "AttendanceQrToken"("tokenHash");

-- CreateIndex
CREATE INDEX "AttendanceQrToken_instanceId_createdAt_idx" ON "AttendanceQrToken"("instanceId", "createdAt" DESC);

-- CreateIndex
CREATE INDEX "AttendanceAllowance_instanceId_studentCode_startsAt_endsAt_idx" ON "AttendanceAllowance"("instanceId", "studentCode", "startsAt", "endsAt");

-- AddForeignKey
ALTER TABLE "AttendancePolicy" ADD CONSTRAINT "AttendancePolicy_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AttendanceMovement" ADD CONSTRAINT "AttendanceMovement_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AttendanceQrToken" ADD CONSTRAINT "AttendanceQrToken_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AttendanceAllowance" ADD CONSTRAINT "AttendanceAllowance_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;
