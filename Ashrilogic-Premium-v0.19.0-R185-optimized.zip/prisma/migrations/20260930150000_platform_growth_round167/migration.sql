-- ROUND 167 — platform growth schema (one additive migration, zero row rewrites):
--   1. Package: maxSystems (created-systems ceiling) + customPricing (Enterprise tier)
--   2. AdminUser: nameEn (bilingual admin identity)
--   3. NewsletterCampaign: audience + kind (tenant messaging segments)
--   4. AttendancePolicy: shiftsJson (دوام صباحي/مسائي/جزئي schedule)
--   5. PlatformSetting: welcomeBonusJson (new-subscriber grant)
--   6. NEW Promotion (site event banners — Black Friday / New Year / Eid)
--   7. NEW EnterpriseQuote (custom-pricing lead pipeline)
-- Every column carries a server default so existing rows keep their exact behavior.

-- 1. Package
ALTER TABLE "Package" ADD COLUMN "maxSystems" INTEGER NOT NULL DEFAULT 1;
ALTER TABLE "Package" ADD COLUMN "customPricing" BOOLEAN NOT NULL DEFAULT false;

-- 2. AdminUser
ALTER TABLE "AdminUser" ADD COLUMN "nameEn" TEXT;

-- 3. NewsletterCampaign
ALTER TABLE "NewsletterCampaign" ADD COLUMN "audience" TEXT NOT NULL DEFAULT 'subscribers';
ALTER TABLE "NewsletterCampaign" ADD COLUMN "kind" TEXT NOT NULL DEFAULT 'broadcast';

-- 4. AttendancePolicy
ALTER TABLE "AttendancePolicy" ADD COLUMN "shiftsJson" TEXT NOT NULL DEFAULT '';

-- 5. PlatformSetting
ALTER TABLE "PlatformSetting" ADD COLUMN "welcomeBonusJson" TEXT NOT NULL DEFAULT '';

-- 6. Promotion — CreateTable
CREATE TABLE "Promotion" (
    "id" TEXT NOT NULL,
    "titleAr" TEXT NOT NULL,
    "titleEn" TEXT NOT NULL,
    "messageAr" TEXT NOT NULL DEFAULT '',
    "messageEn" TEXT NOT NULL DEFAULT '',
    "theme" TEXT NOT NULL DEFAULT 'sale',
    "badgeAr" TEXT NOT NULL DEFAULT '',
    "badgeEn" TEXT NOT NULL DEFAULT '',
    "discountPct" INTEGER NOT NULL DEFAULT 0,
    "ctaTextAr" TEXT NOT NULL DEFAULT '',
    "ctaTextEn" TEXT NOT NULL DEFAULT '',
    "ctaHref" TEXT NOT NULL DEFAULT '',
    "startsAt" TIMESTAMP(3) NOT NULL,
    "endsAt" TIMESTAMP(3) NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Promotion_pkey" PRIMARY KEY ("id")
);

-- CreateIndex (the active-window picker scans [startsAt..endsAt] over active rows)
CREATE INDEX "Promotion_active_startsAt_endsAt_idx" ON "Promotion"("active", "startsAt", "endsAt");
CREATE INDEX "Promotion_sortOrder_idx" ON "Promotion"("sortOrder");

-- 7. EnterpriseQuote — CreateTable
CREATE TABLE "EnterpriseQuote" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "emailIndex" TEXT,
    "company" TEXT NOT NULL DEFAULT '',
    "teamSize" TEXT NOT NULL DEFAULT '1-10',
    "systemsCount" INTEGER NOT NULL DEFAULT 1,
    "notes" TEXT NOT NULL DEFAULT '',
    "status" TEXT NOT NULL DEFAULT 'new',
    "adminNotes" TEXT NOT NULL DEFAULT '',
    "contactedAt" TIMESTAMP(3),
    "quotedAt" TIMESTAMP(3),
    "closedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "EnterpriseQuote_pkey" PRIMARY KEY ("id")
);

-- CreateIndex (dedupe + Super-Admin search resolve by the blind index)
CREATE UNIQUE INDEX "EnterpriseQuote_emailIndex_key" ON "EnterpriseQuote"("emailIndex");
CREATE INDEX "EnterpriseQuote_status_idx" ON "EnterpriseQuote"("status");
CREATE INDEX "EnterpriseQuote_createdAt_idx" ON "EnterpriseQuote"("createdAt");
