-- ROUND 166: converge the plan/addon money family to the documented
-- integer-minor-units contract (src/lib/server/money.ts — "ALL persisted
-- monetary values are INTEGER MINOR UNITS"). Existing rows ×100.
--
-- NOTES (operator runbook):
--  * PENDING PlanOrder/AddonOrder rows created BEFORE this migration lose
--    their HMAC integrity seal (the hash covers amount, and it cannot be
--    recomputed in SQL) — confirming/cancelling them will fail 409
--    ORDER_INTEGRITY. Their 48h window has typically lapsed anyway; let
--    them expire and have tenants re-request.
--  * The console-managed add-on price overrides (PlatformSetting.
--    addonsPricingJson) store MAJOR-unit integers and CANNOT be safely
--    rescaled inside SQL as a JSON blob — the column is RESET to the empty
--    default so resolveAddonPrices() falls back to the NEW minor-unit
--    DEFAULT_ADDON_PRICES; re-enter custom prices from the console
--    (Settings → add-on pricing) after upgrading, in minor units.
--  * Historical PlanOrders are NEVER deleted; the seed tier restructure
--    (USD packages) converges Package rows separately on next boot.
UPDATE "Package" SET "priceMonthly" = "priceMonthly" * 100, "priceYearly" = "priceYearly" * 100;
UPDATE "PlanOrder" SET "amount" = "amount" * 100;
UPDATE "AddonOrder" SET "amount" = "amount" * 100;
UPDATE "PlatformSetting" SET "addonsPricingJson" = '' WHERE "addonsPricingJson" <> '';
