-- ROUND 165 — deep tenant phone-uniqueness index.
-- The signup deep-check scanned EVERY Instance row (parsing orgJson per row)
-- on every availability probe and provisioning; the persisted
-- normalizePhoneDeep(org.phone) comparison key turns it into an indexed
-- point lookup. NULL on legacy rows — backfill via
-- scripts/backfill-org-phone-index.ts; the deep-check retains a bounded
-- legacy fallback for un-backfilled stores.
ALTER TABLE "Instance" ADD COLUMN "orgPhoneIndex" TEXT;
CREATE INDEX "Instance_orgPhoneIndex_idx" ON "Instance"("orgPhoneIndex");
