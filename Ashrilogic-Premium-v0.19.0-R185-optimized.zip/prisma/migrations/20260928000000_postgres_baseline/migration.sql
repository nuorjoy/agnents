-- CreateSchema
CREATE SCHEMA IF NOT EXISTS "public";

-- CreateTable
CREATE TABLE "Instance" (
    "id" TEXT NOT NULL,
    "systemId" TEXT NOT NULL,
    "orgJson" TEXT NOT NULL,
    "adminJson" TEXT NOT NULL,
    "prefsJson" TEXT NOT NULL,
    "modulesJson" TEXT NOT NULL,
    "ownerProfileJson" TEXT,
    "passwordHash" TEXT,
    "shiftCodeHash" TEXT,
    "packageId" TEXT,
    "demo" BOOLEAN NOT NULL DEFAULT false,
    "trialEndsAt" TIMESTAMP(3),
    "planActivatedAt" TIMESTAMP(3),
    "planCycle" TEXT,
    "planExpiresAt" TIMESTAMP(3),
    "featureOverridesJson" TEXT DEFAULT '{}',
    "bannedPermanently" BOOLEAN NOT NULL DEFAULT false,
    "bannedUntil" TIMESTAMP(3),
    "bannedReason" TEXT,
    "bannedAt" TIMESTAMP(3),
    "deletedAt" TIMESTAMP(3),
    "deletedById" TEXT,
    "deletedByName" TEXT,
    "deleteReason" TEXT,
    "disabledAt" TIMESTAMP(3),
    "disabledReason" TEXT,
    "walletMinor" INTEGER NOT NULL DEFAULT 0,
    "walletNo" INTEGER,
    "shiftCodeLen" INTEGER,
    "adminEmailIndex" TEXT,
    "sessionVersion" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Instance_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ModuleRecord" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "moduleId" TEXT NOT NULL,
    "dataJson" TEXT NOT NULL,
    "statusKey" TEXT NOT NULL DEFAULT '',
    "shiftId" TEXT,
    "metaJson" TEXT,
    "imageRef" TEXT,
    "featured" BOOLEAN NOT NULL DEFAULT false,
    "salePrice" INTEGER,
    "saleEndsAt" TIMESTAMP(3),
    "galleryJson" TEXT,
    "paymentsJson" TEXT,
    "videosJson" TEXT,
    "storeVisible" BOOLEAN NOT NULL DEFAULT true,
    "variantsJson" TEXT,
    "deletedAt" TIMESTAMP(3),
    "deletedById" TEXT,
    "deletedByName" TEXT,
    "deleteReason" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ModuleRecord_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Shift" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "openedBy" TEXT NOT NULL,
    "openedById" TEXT,
    "openedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "closedAt" TIMESTAMP(3),
    "closedBy" TEXT,
    "closingNote" TEXT,
    "openingCash" INTEGER NOT NULL DEFAULT 0,
    "countedCash" INTEGER,
    "expectedCash" INTEGER,
    "variance" INTEGER,
    "salesCount" INTEGER NOT NULL DEFAULT 0,
    "salesTotal" INTEGER NOT NULL DEFAULT 0,
    "discountTotal" INTEGER NOT NULL DEFAULT 0,
    "cashTotal" INTEGER NOT NULL DEFAULT 0,
    "cardTotal" INTEGER NOT NULL DEFAULT 0,
    "status" TEXT NOT NULL DEFAULT 'open',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Shift_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Site" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "published" BOOLEAN NOT NULL DEFAULT false,
    "theme" TEXT NOT NULL DEFAULT 'aurora',
    "views" INTEGER NOT NULL DEFAULT 0,
    "contentJson" TEXT NOT NULL DEFAULT '{}',
    "launchedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Site_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SiteCustomer" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "emailIndex" TEXT,
    "phone" TEXT,
    "passwordHash" TEXT,
    "status" TEXT NOT NULL DEFAULT 'active',
    "sessionVersion" INTEGER NOT NULL DEFAULT 0,
    "emailVerifiedAt" TIMESTAMP(3),
    "phoneVerifiedAt" TIMESTAMP(3),
    "verifyTokenHash" TEXT,
    "verifyTokenExpiresAt" TIMESTAMP(3),
    "resetTokenHash" TEXT,
    "resetTokenExpiresAt" TIMESTAMP(3),
    "addressesJson" TEXT,
    "paymentMethodsJson" TEXT,
    "username" TEXT,
    "avatarUrl" TEXT,
    "deletedAt" TIMESTAMP(3),
    "deletedById" TEXT,
    "deletedByName" TEXT,
    "deleteReason" TEXT,
    "deletedKey" TEXT,
    "lastLoginAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "SiteCustomer_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SiteOrder" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "customerId" TEXT NOT NULL,
    "itemsJson" TEXT NOT NULL,
    "total" INTEGER NOT NULL DEFAULT 0,
    "currency" TEXT NOT NULL DEFAULT 'SAR',
    "status" TEXT NOT NULL DEFAULT 'pending',
    "note" TEXT,
    "statusNote" TEXT,
    "discount" INTEGER NOT NULL DEFAULT 0,
    "couponCode" TEXT,
    "couponId" TEXT,
    "code" TEXT,
    "phoneIndex" TEXT,
    "statusHistoryJson" TEXT,
    "compensatedAt" TIMESTAMP(3),
    "deletedAt" TIMESTAMP(3),
    "deletedById" TEXT,
    "deletedByName" TEXT,
    "deleteReason" TEXT,
    "deletedKey" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "SiteOrder_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "OrderIdempotency" (
    "key" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "requestHash" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'in_flight',
    "orderId" TEXT,
    "responseJson" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completedAt" TIMESTAMP(3),

    CONSTRAINT "OrderIdempotency_pkey" PRIMARY KEY ("key")
);

-- CreateTable
CREATE TABLE "CouponRedemption" (
    "id" TEXT NOT NULL,
    "orderId" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "couponId" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "releasedAt" TIMESTAMP(3),

    CONSTRAINT "CouponRedemption_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "OrderReservation" (
    "id" TEXT NOT NULL,
    "orderId" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "recordId" TEXT NOT NULL,
    "moduleId" TEXT NOT NULL,
    "stockColumn" INTEGER NOT NULL,
    "qty" INTEGER NOT NULL,
    "state" TEXT NOT NULL DEFAULT 'reserved',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "releasedAt" TIMESTAMP(3),

    CONSTRAINT "OrderReservation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SiteReview" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "recordId" TEXT NOT NULL,
    "rating" INTEGER NOT NULL,
    "name" TEXT NOT NULL,
    "body" TEXT,
    "hidden" BOOLEAN NOT NULL DEFAULT false,
    "authorIndex" TEXT,
    "deletedAt" TIMESTAMP(3),
    "deletedById" TEXT,
    "deletedByName" TEXT,
    "deleteReason" TEXT,
    "deletedKey" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "SiteReview_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "StoreCoupon" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "kind" TEXT NOT NULL,
    "value" INTEGER NOT NULL,
    "minSubtotal" INTEGER,
    "maxUses" INTEGER,
    "usedCount" INTEGER NOT NULL DEFAULT 0,
    "startsAt" TIMESTAMP(3),
    "expiresAt" TIMESTAMP(3),
    "active" BOOLEAN NOT NULL DEFAULT true,
    "deletedAt" TIMESTAMP(3),
    "deletedById" TEXT,
    "deletedByName" TEXT,
    "deleteReason" TEXT,
    "deletedKey" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "StoreCoupon_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ImageAsset" (
    "id" TEXT NOT NULL,
    "mime" TEXT NOT NULL,
    "width" INTEGER,
    "height" INTEGER,
    "bytes" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ImageAsset_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "MediaAsset" (
    "id" TEXT NOT NULL,
    "mime" TEXT NOT NULL,
    "bytes" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "MediaAsset_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RateLimitHit" (
    "id" TEXT NOT NULL,
    "key" TEXT NOT NULL,
    "at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "RateLimitHit_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Activity" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "kind" TEXT NOT NULL,
    "metaJson" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Activity_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TeamMember" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "role" TEXT NOT NULL DEFAULT 'staff',
    "profileJson" TEXT,
    "deletedAt" TIMESTAMP(3),
    "deletedById" TEXT,
    "deletedByName" TEXT,
    "deleteReason" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "TeamMember_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Subscriber" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "emailIndex" TEXT,
    "tag" TEXT,
    "status" TEXT NOT NULL DEFAULT 'active',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Subscriber_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AdminUser" (
    "id" TEXT NOT NULL,
    "username" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "emailIndex" TEXT,
    "role" TEXT NOT NULL DEFAULT 'admin',
    "active" BOOLEAN NOT NULL DEFAULT true,
    "gender" TEXT,
    "avatarUrl" TEXT,
    "birthDate" TIMESTAMP(3),
    "address" TEXT,
    "passwordHash" TEXT,
    "sessionVersion" INTEGER NOT NULL DEFAULT 0,
    "deletedAt" TIMESTAMP(3),
    "deletedById" TEXT,
    "deletedByName" TEXT,
    "deleteReason" TEXT,
    "deletedKey" TEXT,
    "lastLoginAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AdminUser_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Package" (
    "id" TEXT NOT NULL,
    "nameAr" TEXT NOT NULL,
    "nameEn" TEXT NOT NULL,
    "descAr" TEXT NOT NULL,
    "descEn" TEXT NOT NULL,
    "priceMonthly" INTEGER NOT NULL DEFAULT 0,
    "priceYearly" INTEGER NOT NULL DEFAULT 0,
    "currency" TEXT NOT NULL DEFAULT 'SAR',
    "featuresJson" TEXT NOT NULL DEFAULT '[]',
    "featuresEnJson" TEXT NOT NULL DEFAULT '[]',
    "maxUsers" INTEGER NOT NULL DEFAULT 5,
    "maxModules" INTEGER NOT NULL DEFAULT 10,
    "maxStorageMb" INTEGER NOT NULL DEFAULT 512,
    "discountPct" INTEGER NOT NULL DEFAULT 0,
    "yearlyDiscountPct" INTEGER NOT NULL DEFAULT 0,
    "capabilitiesJson" TEXT DEFAULT '[]',
    "popular" BOOLEAN NOT NULL DEFAULT false,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Package_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PlanOrder" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "packageId" TEXT NOT NULL,
    "cycle" TEXT NOT NULL,
    "amount" INTEGER NOT NULL,
    "currency" TEXT NOT NULL,
    "method" TEXT NOT NULL,
    "methodId" TEXT NOT NULL DEFAULT '',
    "methodLabel" TEXT NOT NULL DEFAULT '',
    "status" TEXT NOT NULL DEFAULT 'pending',
    "reference" TEXT NOT NULL,
    "integrityHash" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "paidAt" TIMESTAMP(3),
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "PlanOrder_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AddonOrder" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "featuresJson" TEXT NOT NULL,
    "cycle" TEXT NOT NULL,
    "amount" INTEGER NOT NULL,
    "currency" TEXT NOT NULL,
    "method" TEXT NOT NULL,
    "methodId" TEXT NOT NULL DEFAULT '',
    "methodLabel" TEXT NOT NULL DEFAULT '',
    "status" TEXT NOT NULL DEFAULT 'pending',
    "reference" TEXT NOT NULL,
    "integrityHash" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "paidAt" TIMESTAMP(3),
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AddonOrder_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "WalletTxn" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "kind" TEXT NOT NULL,
    "amountMinor" INTEGER NOT NULL,
    "balanceAfterMinor" INTEGER NOT NULL,
    "reference" TEXT NOT NULL DEFAULT '',
    "linkId" TEXT NOT NULL DEFAULT '',
    "note" TEXT NOT NULL DEFAULT '',
    "actorType" TEXT NOT NULL DEFAULT 'system',
    "actorName" TEXT NOT NULL DEFAULT '',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "WalletTxn_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "WalletTopup" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "amountMinor" INTEGER NOT NULL,
    "currency" TEXT NOT NULL DEFAULT 'SAR',
    "method" TEXT NOT NULL,
    "methodId" TEXT NOT NULL DEFAULT '',
    "methodLabel" TEXT NOT NULL DEFAULT '',
    "status" TEXT NOT NULL DEFAULT 'pending',
    "reference" TEXT NOT NULL,
    "integrityHash" TEXT NOT NULL,
    "note" TEXT NOT NULL DEFAULT '',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "paidAt" TIMESTAMP(3),
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "WalletTopup_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SupportTicket" (
    "id" TEXT NOT NULL,
    "subject" TEXT NOT NULL,
    "message" TEXT NOT NULL,
    "requesterName" TEXT NOT NULL,
    "requesterEmail" TEXT NOT NULL,
    "requesterEmailIndex" TEXT,
    "category" TEXT NOT NULL DEFAULT 'general',
    "priority" TEXT NOT NULL DEFAULT 'medium',
    "status" TEXT NOT NULL DEFAULT 'open',
    "reply" TEXT,
    "replyReadAt" TIMESTAMP(3),
    "instanceId" TEXT,
    "source" TEXT NOT NULL DEFAULT 'internal',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "SupportTicket_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AuditLog" (
    "id" TEXT NOT NULL,
    "actorType" TEXT NOT NULL,
    "actorId" TEXT,
    "actorName" TEXT NOT NULL,
    "action" TEXT NOT NULL,
    "targetLabel" TEXT,
    "metaJson" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "prevChainHash" TEXT,
    "chainHash" TEXT,

    CONSTRAINT "AuditLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "MfaSecret" (
    "id" TEXT NOT NULL,
    "scope" TEXT NOT NULL,
    "subjectId" TEXT NOT NULL,
    "secretSealed" TEXT NOT NULL,
    "enabled" BOOLEAN NOT NULL DEFAULT false,
    "confirmedAt" TIMESTAMP(3),
    "backupCodesJson" TEXT NOT NULL DEFAULT '[]',
    "lastUsedTimestep" INTEGER,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "MfaSecret_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "WebauthnCredential" (
    "id" TEXT NOT NULL,
    "scope" TEXT NOT NULL,
    "subjectId" TEXT NOT NULL,
    "publicKey" TEXT NOT NULL,
    "counter" INTEGER NOT NULL DEFAULT 0,
    "deviceType" TEXT,
    "backedUp" BOOLEAN NOT NULL DEFAULT false,
    "transports" TEXT,
    "name" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lastUsedAt" TIMESTAMP(3),

    CONSTRAINT "WebauthnCredential_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "WebauthnChallenge" (
    "id" TEXT NOT NULL,
    "scope" TEXT NOT NULL,
    "subjectId" TEXT NOT NULL,
    "challenge" TEXT NOT NULL,
    "purpose" TEXT NOT NULL,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "WebauthnChallenge_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SessionRecord" (
    "id" TEXT NOT NULL,
    "scope" TEXT NOT NULL,
    "subjectId" TEXT NOT NULL,
    "ip" TEXT,
    "userAgent" TEXT,
    "device" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lastSeenAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "revokedAt" TIMESTAMP(3),

    CONSTRAINT "SessionRecord_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PlatformSetting" (
    "id" TEXT NOT NULL,
    "siteNameAr" TEXT NOT NULL DEFAULT 'أشرِيلوجيك',
    "siteNameEn" TEXT NOT NULL DEFAULT 'Ashrilogic',
    "supportEmail" TEXT NOT NULL DEFAULT 'support@ashrilogic.com',
    "supportPhone" TEXT NOT NULL DEFAULT '+249912179779',
    "defaultLang" TEXT NOT NULL DEFAULT 'ar',
    "packageCurrency" TEXT NOT NULL DEFAULT 'SAR',
    "maintenanceMode" BOOLEAN NOT NULL DEFAULT false,
    "allowSignup" BOOLEAN NOT NULL DEFAULT true,
    "twoFARequired" BOOLEAN NOT NULL DEFAULT false,
    "sessionTimeout" INTEGER NOT NULL DEFAULT 30,
    "notifEmail" BOOLEAN NOT NULL DEFAULT true,
    "weeklyDigest" BOOLEAN NOT NULL DEFAULT true,
    "autoBackup" BOOLEAN NOT NULL DEFAULT true,
    "backupFreq" TEXT NOT NULL DEFAULT 'daily',
    "auditLog" BOOLEAN NOT NULL DEFAULT true,
    "dataRetention" INTEGER NOT NULL DEFAULT 90,
    "socialJson" TEXT NOT NULL DEFAULT '',
    "newsletterEmailsJson" TEXT NOT NULL DEFAULT '',
    "aiJson" TEXT NOT NULL DEFAULT '',
    "paymentsJson" TEXT NOT NULL DEFAULT '',
    "identityJson" TEXT NOT NULL DEFAULT '',
    "smtpJson" TEXT NOT NULL DEFAULT '',
    "trashRetentionDays" INTEGER NOT NULL DEFAULT 30,
    "addonsPricingJson" TEXT NOT NULL DEFAULT '',
    "bannedIpsJson" TEXT NOT NULL DEFAULT '[]',
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "PlatformSetting_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SchedulerLease" (
    "job" TEXT NOT NULL,
    "holder" TEXT NOT NULL,
    "acquiredAt" TIMESTAMP(3) NOT NULL,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "epoch" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "SchedulerLease_pkey" PRIMARY KEY ("job")
);

-- CreateTable
CREATE TABLE "NotificationLog" (
    "id" TEXT NOT NULL,
    "kind" TEXT NOT NULL,
    "eventKey" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "recipient" TEXT NOT NULL,
    "transport" TEXT NOT NULL,
    "delivered" BOOLEAN NOT NULL DEFAULT false,
    "error" TEXT,
    "metaJson" TEXT NOT NULL DEFAULT '{}',
    "sentAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "weekKey" TEXT,

    CONSTRAINT "NotificationLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EmailLog" (
    "id" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "recipient" TEXT NOT NULL,
    "subject" TEXT NOT NULL,
    "provider" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "messageId" TEXT,
    "attempts" INTEGER NOT NULL DEFAULT 1,
    "error" TEXT,
    "errorClass" TEXT,
    "idempotencyKey" TEXT,
    "instanceId" TEXT,
    "bodyJson" TEXT,
    "sentAt" TIMESTAMP(3),
    "deliveredAt" TIMESTAMP(3),
    "failedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "EmailLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "WebhookEndpoint" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "url" TEXT NOT NULL,
    "secret" TEXT NOT NULL,
    "eventsJson" TEXT NOT NULL DEFAULT '[]',
    "active" BOOLEAN NOT NULL DEFAULT true,
    "description" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "deletedAt" TIMESTAMP(3),

    CONSTRAINT "WebhookEndpoint_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "WebhookDelivery" (
    "id" TEXT NOT NULL,
    "endpointId" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "event" TEXT NOT NULL,
    "payloadJson" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "attempts" INTEGER NOT NULL DEFAULT 0,
    "leaseId" TEXT,
    "workerId" TEXT,
    "lockedUntil" TIMESTAMP(3),
    "startedAt" TIMESTAMP(3),
    "nextAttemptAt" TIMESTAMP(3),
    "responseStatus" INTEGER,
    "error" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "deliveredAt" TIMESTAMP(3),
    "exhaustedAt" TIMESTAMP(3),
    "redeliveredFrom" TEXT,

    CONSTRAINT "WebhookDelivery_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "NewsletterCampaign" (
    "id" TEXT NOT NULL,
    "subject" TEXT NOT NULL,
    "body" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'draft',
    "recipients" INTEGER NOT NULL DEFAULT 0,
    "sentFrom" TEXT,
    "sentAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "NewsletterCampaign_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "BlogPost" (
    "id" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "titleAr" TEXT NOT NULL,
    "titleEn" TEXT NOT NULL,
    "excerptAr" TEXT NOT NULL DEFAULT '',
    "excerptEn" TEXT NOT NULL DEFAULT '',
    "contentAr" TEXT NOT NULL DEFAULT '',
    "contentEn" TEXT NOT NULL DEFAULT '',
    "coverImage" TEXT NOT NULL DEFAULT '',
    "tagsJson" TEXT NOT NULL DEFAULT '[]',
    "authorName" TEXT NOT NULL DEFAULT 'Ashrilogic',
    "status" TEXT NOT NULL DEFAULT 'draft',
    "featured" BOOLEAN NOT NULL DEFAULT false,
    "views" INTEGER NOT NULL DEFAULT 0,
    "readMinutes" INTEGER NOT NULL DEFAULT 3,
    "publishedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "BlogPost_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SectorPartner" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "nameAr" TEXT NOT NULL DEFAULT '',
    "nameEn" TEXT NOT NULL DEFAULT '',
    "sector" TEXT NOT NULL,
    "icon" TEXT NOT NULL DEFAULT 'building',
    "c1" TEXT NOT NULL DEFAULT '#6d5dfb',
    "c2" TEXT NOT NULL DEFAULT '#06b6d4',
    "visible" BOOLEAN NOT NULL DEFAULT true,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "SectorPartner_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RestoreLease" (
    "instanceId" TEXT NOT NULL,
    "holder" TEXT NOT NULL,
    "acquiredAt" TIMESTAMP(3) NOT NULL,
    "expiresAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "RestoreLease_pkey" PRIMARY KEY ("instanceId")
);

-- CreateTable
CREATE TABLE "AuditChainAnchor" (
    "id" TEXT NOT NULL DEFAULT 'global',
    "anchorPrevHash" TEXT NOT NULL,
    "anchorRowId" TEXT NOT NULL,
    "anchoredAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AuditChainAnchor_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CrossDeviceLogin" (
    "id" TEXT NOT NULL,
    "scope" TEXT NOT NULL,
    "optionsJson" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "subjectId" TEXT,
    "createdIp" TEXT,
    "finishedIp" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "claimedAt" TIMESTAMP(3),

    CONSTRAINT "CrossDeviceLogin_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "LegalDoc" (
    "key" TEXT NOT NULL,
    "locale" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "intro" TEXT NOT NULL,
    "sectionsJson" TEXT NOT NULL,
    "version" INTEGER NOT NULL DEFAULT 1,
    "updatedById" TEXT,
    "updatedByName" TEXT,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "LegalDoc_pkey" PRIMARY KEY ("key","locale")
);

-- CreateIndex
CREATE UNIQUE INDEX "Instance_walletNo_key" ON "Instance"("walletNo");

-- CreateIndex
CREATE INDEX "Instance_trialEndsAt_idx" ON "Instance"("trialEndsAt");

-- CreateIndex
CREATE INDEX "Instance_planExpiresAt_idx" ON "Instance"("planExpiresAt");

-- CreateIndex
CREATE INDEX "Instance_adminEmailIndex_idx" ON "Instance"("adminEmailIndex");

-- CreateIndex
CREATE INDEX "Instance_systemId_idx" ON "Instance"("systemId");

-- CreateIndex
CREATE INDEX "Instance_packageId_idx" ON "Instance"("packageId");

-- CreateIndex
CREATE INDEX "Instance_createdAt_idx" ON "Instance"("createdAt");

-- CreateIndex
CREATE INDEX "Instance_demo_idx" ON "Instance"("demo");

-- CreateIndex
CREATE INDEX "Instance_bannedPermanently_bannedUntil_idx" ON "Instance"("bannedPermanently", "bannedUntil");

-- CreateIndex
CREATE INDEX "Instance_deletedAt_idx" ON "Instance"("deletedAt");

-- CreateIndex
CREATE INDEX "Instance_disabledAt_idx" ON "Instance"("disabledAt");

-- CreateIndex
CREATE INDEX "ModuleRecord_instanceId_moduleId_idx" ON "ModuleRecord"("instanceId", "moduleId");

-- CreateIndex
CREATE INDEX "ModuleRecord_instanceId_deletedAt_idx" ON "ModuleRecord"("instanceId", "deletedAt");

-- CreateIndex
CREATE INDEX "ModuleRecord_instanceId_shiftId_idx" ON "ModuleRecord"("instanceId", "shiftId");

-- CreateIndex
CREATE INDEX "ModuleRecord_instanceId_storeVisible_idx" ON "ModuleRecord"("instanceId", "storeVisible");

-- CreateIndex
CREATE INDEX "Shift_instanceId_status_idx" ON "Shift"("instanceId", "status");

-- CreateIndex
CREATE INDEX "Shift_instanceId_openedAt_idx" ON "Shift"("instanceId", "openedAt");

-- CreateIndex
CREATE UNIQUE INDEX "Shift_instanceId_code_key" ON "Shift"("instanceId", "code");

-- CreateIndex
CREATE UNIQUE INDEX "Site_instanceId_key" ON "Site"("instanceId");

-- CreateIndex
CREATE INDEX "Site_published_idx" ON "Site"("published");

-- CreateIndex
CREATE INDEX "SiteCustomer_instanceId_idx" ON "SiteCustomer"("instanceId");

-- CreateIndex
CREATE INDEX "SiteCustomer_status_idx" ON "SiteCustomer"("status");

-- CreateIndex
CREATE INDEX "SiteCustomer_instanceId_verifyTokenHash_idx" ON "SiteCustomer"("instanceId", "verifyTokenHash");

-- CreateIndex
CREATE INDEX "SiteCustomer_instanceId_resetTokenHash_idx" ON "SiteCustomer"("instanceId", "resetTokenHash");

-- CreateIndex
CREATE INDEX "SiteCustomer_instanceId_deletedAt_idx" ON "SiteCustomer"("instanceId", "deletedAt");

-- CreateIndex
CREATE UNIQUE INDEX "SiteCustomer_instanceId_emailIndex_key" ON "SiteCustomer"("instanceId", "emailIndex");

-- CreateIndex
CREATE UNIQUE INDEX "SiteCustomer_instanceId_username_key" ON "SiteCustomer"("instanceId", "username");

-- CreateIndex
CREATE INDEX "SiteOrder_instanceId_phoneIndex_idx" ON "SiteOrder"("instanceId", "phoneIndex");

-- CreateIndex
CREATE INDEX "SiteOrder_instanceId_status_idx" ON "SiteOrder"("instanceId", "status");

-- CreateIndex
CREATE INDEX "SiteOrder_status_compensatedAt_idx" ON "SiteOrder"("status", "compensatedAt");

-- CreateIndex
CREATE INDEX "SiteOrder_instanceId_createdAt_idx" ON "SiteOrder"("instanceId", "createdAt");

-- CreateIndex
CREATE INDEX "SiteOrder_customerId_createdAt_idx" ON "SiteOrder"("customerId", "createdAt");

-- CreateIndex
CREATE INDEX "SiteOrder_instanceId_deletedAt_idx" ON "SiteOrder"("instanceId", "deletedAt");

-- CreateIndex
CREATE UNIQUE INDEX "SiteOrder_instanceId_code_key" ON "SiteOrder"("instanceId", "code");

-- CreateIndex
CREATE INDEX "OrderIdempotency_createdAt_idx" ON "OrderIdempotency"("createdAt");

-- CreateIndex
CREATE INDEX "OrderIdempotency_instanceId_idx" ON "OrderIdempotency"("instanceId");

-- CreateIndex
CREATE UNIQUE INDEX "CouponRedemption_orderId_key" ON "CouponRedemption"("orderId");

-- CreateIndex
CREATE INDEX "CouponRedemption_couponId_idx" ON "CouponRedemption"("couponId");

-- CreateIndex
CREATE INDEX "CouponRedemption_instanceId_releasedAt_idx" ON "CouponRedemption"("instanceId", "releasedAt");

-- CreateIndex
CREATE INDEX "OrderReservation_instanceId_state_idx" ON "OrderReservation"("instanceId", "state");

-- CreateIndex
CREATE INDEX "OrderReservation_state_createdAt_idx" ON "OrderReservation"("state", "createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "OrderReservation_orderId_recordId_key" ON "OrderReservation"("orderId", "recordId");

-- CreateIndex
CREATE INDEX "SiteReview_instanceId_recordId_hidden_idx" ON "SiteReview"("instanceId", "recordId", "hidden");

-- CreateIndex
CREATE INDEX "SiteReview_instanceId_hidden_idx" ON "SiteReview"("instanceId", "hidden");

-- CreateIndex
CREATE INDEX "SiteReview_instanceId_deletedAt_idx" ON "SiteReview"("instanceId", "deletedAt");

-- CreateIndex
CREATE UNIQUE INDEX "SiteReview_instanceId_recordId_authorIndex_key" ON "SiteReview"("instanceId", "recordId", "authorIndex");

-- CreateIndex
CREATE INDEX "StoreCoupon_instanceId_active_idx" ON "StoreCoupon"("instanceId", "active");

-- CreateIndex
CREATE INDEX "StoreCoupon_instanceId_deletedAt_idx" ON "StoreCoupon"("instanceId", "deletedAt");

-- CreateIndex
CREATE UNIQUE INDEX "StoreCoupon_instanceId_code_key" ON "StoreCoupon"("instanceId", "code");

-- CreateIndex
CREATE INDEX "ImageAsset_createdAt_idx" ON "ImageAsset"("createdAt");

-- CreateIndex
CREATE INDEX "MediaAsset_createdAt_idx" ON "MediaAsset"("createdAt");

-- CreateIndex
CREATE INDEX "RateLimitHit_key_at_idx" ON "RateLimitHit"("key", "at");

-- CreateIndex
CREATE INDEX "Activity_instanceId_createdAt_idx" ON "Activity"("instanceId", "createdAt");

-- CreateIndex
CREATE INDEX "Activity_createdAt_idx" ON "Activity"("createdAt");

-- CreateIndex
CREATE INDEX "TeamMember_instanceId_idx" ON "TeamMember"("instanceId");

-- CreateIndex
CREATE INDEX "TeamMember_instanceId_deletedAt_idx" ON "TeamMember"("instanceId", "deletedAt");

-- CreateIndex
CREATE UNIQUE INDEX "Subscriber_emailIndex_key" ON "Subscriber"("emailIndex");

-- CreateIndex
CREATE INDEX "Subscriber_tag_idx" ON "Subscriber"("tag");

-- CreateIndex
CREATE INDEX "Subscriber_status_idx" ON "Subscriber"("status");

-- CreateIndex
CREATE UNIQUE INDEX "AdminUser_username_key" ON "AdminUser"("username");

-- CreateIndex
CREATE UNIQUE INDEX "AdminUser_emailIndex_key" ON "AdminUser"("emailIndex");

-- CreateIndex
CREATE INDEX "AdminUser_role_idx" ON "AdminUser"("role");

-- CreateIndex
CREATE INDEX "AdminUser_deletedAt_idx" ON "AdminUser"("deletedAt");

-- CreateIndex
CREATE INDEX "Package_active_sortOrder_idx" ON "Package"("active", "sortOrder");

-- CreateIndex
CREATE UNIQUE INDEX "PlanOrder_reference_key" ON "PlanOrder"("reference");

-- CreateIndex
CREATE INDEX "PlanOrder_instanceId_status_idx" ON "PlanOrder"("instanceId", "status");

-- CreateIndex
CREATE INDEX "PlanOrder_status_createdAt_idx" ON "PlanOrder"("status", "createdAt");

-- CreateIndex
CREATE INDEX "PlanOrder_packageId_idx" ON "PlanOrder"("packageId");

-- CreateIndex
CREATE UNIQUE INDEX "AddonOrder_reference_key" ON "AddonOrder"("reference");

-- CreateIndex
CREATE INDEX "AddonOrder_instanceId_status_idx" ON "AddonOrder"("instanceId", "status");

-- CreateIndex
CREATE INDEX "AddonOrder_status_createdAt_idx" ON "AddonOrder"("status", "createdAt");

-- CreateIndex
CREATE INDEX "WalletTxn_instanceId_createdAt_idx" ON "WalletTxn"("instanceId", "createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "WalletTopup_reference_key" ON "WalletTopup"("reference");

-- CreateIndex
CREATE INDEX "WalletTopup_instanceId_status_idx" ON "WalletTopup"("instanceId", "status");

-- CreateIndex
CREATE INDEX "WalletTopup_status_createdAt_idx" ON "WalletTopup"("status", "createdAt");

-- CreateIndex
CREATE INDEX "SupportTicket_status_updatedAt_idx" ON "SupportTicket"("status", "updatedAt");

-- CreateIndex
CREATE INDEX "SupportTicket_requesterEmailIndex_idx" ON "SupportTicket"("requesterEmailIndex");

-- CreateIndex
CREATE INDEX "SupportTicket_instanceId_source_idx" ON "SupportTicket"("instanceId", "source");

-- CreateIndex
CREATE INDEX "AuditLog_createdAt_idx" ON "AuditLog"("createdAt");

-- CreateIndex
CREATE INDEX "AuditLog_actorType_action_idx" ON "AuditLog"("actorType", "action");

-- CreateIndex
CREATE INDEX "AuditLog_chainHash_idx" ON "AuditLog"("chainHash");

-- CreateIndex
CREATE INDEX "MfaSecret_scope_subjectId_idx" ON "MfaSecret"("scope", "subjectId");

-- CreateIndex
CREATE UNIQUE INDEX "MfaSecret_scope_subjectId_key" ON "MfaSecret"("scope", "subjectId");

-- CreateIndex
CREATE INDEX "WebauthnCredential_scope_subjectId_idx" ON "WebauthnCredential"("scope", "subjectId");

-- CreateIndex
CREATE UNIQUE INDEX "WebauthnCredential_scope_subjectId_id_key" ON "WebauthnCredential"("scope", "subjectId", "id");

-- CreateIndex
CREATE INDEX "WebauthnChallenge_expiresAt_idx" ON "WebauthnChallenge"("expiresAt");

-- CreateIndex
CREATE INDEX "WebauthnChallenge_scope_subjectId_purpose_idx" ON "WebauthnChallenge"("scope", "subjectId", "purpose");

-- CreateIndex
CREATE INDEX "SessionRecord_scope_subjectId_lastSeenAt_idx" ON "SessionRecord"("scope", "subjectId", "lastSeenAt");

-- CreateIndex
CREATE INDEX "SessionRecord_expiresAt_idx" ON "SessionRecord"("expiresAt");

-- CreateIndex
CREATE INDEX "SchedulerLease_expiresAt_idx" ON "SchedulerLease"("expiresAt");

-- CreateIndex
CREATE INDEX "NotificationLog_sentAt_idx" ON "NotificationLog"("sentAt");

-- CreateIndex
CREATE UNIQUE INDEX "NotificationLog_eventKey_weekKey_key" ON "NotificationLog"("eventKey", "weekKey");

-- CreateIndex
CREATE UNIQUE INDEX "EmailLog_idempotencyKey_key" ON "EmailLog"("idempotencyKey");

-- CreateIndex
CREATE INDEX "EmailLog_createdAt_idx" ON "EmailLog"("createdAt");

-- CreateIndex
CREATE INDEX "EmailLog_status_createdAt_idx" ON "EmailLog"("status", "createdAt");

-- CreateIndex
CREATE INDEX "EmailLog_type_createdAt_idx" ON "EmailLog"("type", "createdAt");

-- CreateIndex
CREATE INDEX "WebhookEndpoint_instanceId_active_deletedAt_idx" ON "WebhookEndpoint"("instanceId", "active", "deletedAt");

-- CreateIndex
CREATE INDEX "WebhookDelivery_status_nextAttemptAt_idx" ON "WebhookDelivery"("status", "nextAttemptAt");

-- CreateIndex
CREATE INDEX "WebhookDelivery_instanceId_createdAt_idx" ON "WebhookDelivery"("instanceId", "createdAt");

-- CreateIndex
CREATE INDEX "WebhookDelivery_redeliveredFrom_idx" ON "WebhookDelivery"("redeliveredFrom");

-- CreateIndex
CREATE INDEX "NewsletterCampaign_status_idx" ON "NewsletterCampaign"("status");

-- CreateIndex
CREATE INDEX "NewsletterCampaign_createdAt_idx" ON "NewsletterCampaign"("createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "BlogPost_slug_key" ON "BlogPost"("slug");

-- CreateIndex
CREATE INDEX "BlogPost_status_publishedAt_idx" ON "BlogPost"("status", "publishedAt");

-- CreateIndex
CREATE INDEX "BlogPost_createdAt_idx" ON "BlogPost"("createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "SectorPartner_instanceId_key" ON "SectorPartner"("instanceId");

-- CreateIndex
CREATE INDEX "SectorPartner_visible_sortOrder_idx" ON "SectorPartner"("visible", "sortOrder");

-- CreateIndex
CREATE INDEX "RestoreLease_expiresAt_idx" ON "RestoreLease"("expiresAt");

-- CreateIndex
CREATE INDEX "CrossDeviceLogin_expiresAt_idx" ON "CrossDeviceLogin"("expiresAt");

-- CreateIndex
CREATE INDEX "CrossDeviceLogin_scope_status_idx" ON "CrossDeviceLogin"("scope", "status");

-- AddForeignKey
ALTER TABLE "Instance" ADD CONSTRAINT "Instance_packageId_fkey" FOREIGN KEY ("packageId") REFERENCES "Package"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ModuleRecord" ADD CONSTRAINT "ModuleRecord_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Shift" ADD CONSTRAINT "Shift_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Site" ADD CONSTRAINT "Site_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SiteCustomer" ADD CONSTRAINT "SiteCustomer_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SiteOrder" ADD CONSTRAINT "SiteOrder_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SiteOrder" ADD CONSTRAINT "SiteOrder_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "SiteCustomer"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SiteReview" ADD CONSTRAINT "SiteReview_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "StoreCoupon" ADD CONSTRAINT "StoreCoupon_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Activity" ADD CONSTRAINT "Activity_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TeamMember" ADD CONSTRAINT "TeamMember_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PlanOrder" ADD CONSTRAINT "PlanOrder_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PlanOrder" ADD CONSTRAINT "PlanOrder_packageId_fkey" FOREIGN KEY ("packageId") REFERENCES "Package"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AddonOrder" ADD CONSTRAINT "AddonOrder_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "WalletTxn" ADD CONSTRAINT "WalletTxn_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "WalletTopup" ADD CONSTRAINT "WalletTopup_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "WebhookEndpoint" ADD CONSTRAINT "WebhookEndpoint_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SectorPartner" ADD CONSTRAINT "SectorPartner_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;

