# TEST-MATRIX

The authoritative verification inventory: the four-phase test battery, the
CI gate sequence, the test-file census by category, and the verification
contract a change must satisfy before it is called done. Debt items that
gate future work: [TECHNICAL-DEBT.md](./TECHNICAL-DEBT.md).

## The 4-phase battery (`.zscripts/test-battery.sh`, ROUND 104)

OOM-aware, unattended, classified, honest. Exit codes: 0 all PASS · 1 real
failures (server alive, assertions failed) · 2 inconclusive after retries.

| Phase | What runs |
| --- | --- |
| 1 — offline | every `tests/security/*.test.ts` EXCEPT the live suites, ONE bun process per file (the solo pattern — cross-suite rate-limit contamination is impossible), against the throwaway `TEST_DATABASE_URL` fixture (force-reset per process) |
| 2 — live suites | for each live suite: free headroom → STOP any dev server → start a FRESH one (turbopack, 2048 MB heap) → `bun test --smol` → classify PASS / INFRA (server died mid-suite → restart + retry, max LIVE_ATTEMPTS) / FAIL (never retried away) |
| 2a — tenant-isolation slicing (ROUND 105) | the live tenant-isolation suite runs as 10 sequential slices (`TENANT_ISOLATION_SLICE=1..10`), each on a FRESH server: slice 1 provisions both tenants, slices 2–10 rejoin by blind index + fresh logins; a server-independent cleanup slice (99) ALWAYS runs afterwards |
| 3 — restore | stop the battery server; bring the environment back to managed state via `.zscripts/dev.sh`, verified ready before exit |

Live suites (always excluded from phase 1; `LIVE_SUITES` can only narrow):
`tenant-isolation`, `tenant-isolation-modern`, `trial-entitlement`,
`plan-assignment`, `http-routes`, `packages-routes`, `store-routes`.
Cross-session lock: `/tmp/ashrilogic-battery.lock` (flock). The battery
NEVER touches the live databases.

## CI gates (`.github/workflows/ci.yml`)

PostgreSQL 17 service container; actions pinned to exact commit SHAs; Bun
pinned 1.3.14; `bun install --frozen-lockfile`. In order:

1. **Dependency vulnerability gate (OSV)** — every direct dependency
   checked against Google's OSV index (`scripts/dependency-vuln-scan.ts`,
   zero extra deps). A FIXABLE vulnerability fails the release; unfixed
   industry CVEs are reported and tracked without blocking.
2. **SBOM** — CycloneDX 1.5 bill of materials, uploaded as a build
   artifact (release provenance).
3. **Repo hygiene** — `.env` / live DB files / `storage/` never git-tracked.
4. **Prisma generate** (single provider).
5. **tsc --noEmit** (TypeScript strict).
6. **eslint** `src/ scripts/ tests/` — 0 errors is the AGENTS.md contract.
7. **Caddy security gate — strict** (`check-caddy-security.sh --strict`):
   a regression to dynamic-port proxying or a MISSING production Caddyfile
   fails the build; "SKIPPED" is not a valid production result.
8. **Offline battery** — `prisma migrate deploy` first (broken migration
   history fails the build), then each offline suite, one process per file.
9. **i18n usage report** — advisory, never fails CI.

## Test-file census (tests/security/)

**82 `*.test.ts` files** (verified count, ROUND 165), plus the shared
`test-setup.ts` fixture and `code-only.ts` helper. By category:

- **Sessions / auth**: tokens, mfa-sessions, mfa-fail-closed,
  cross-device-login, password-generator
- **Secrets / crypto / PII**: secret-policy (NEW), crypto-vault, re-seal,
  audit-mask, id-display-policy
- **Guards / HTTP envelope**: rate-limit, proxy-trust (NEW), origin-guard,
  route-guards, route-wrapper, http-body
- **Storage / uploads / GC**: storage-invariant (NEW), object-store,
  storage-migration, image-store, upload-validation, media-upload-dos,
  image-gc, image-ref-gc, product-media, module-record-image
- **Backup / restore**: backup-cache, backup-completeness, backup-crypto,
  backup-offsite-copy, backup-safety-net, snapshot-health, import-backup,
  restore-lease
- **Audit chain**: audit-chain, audit-chain-anchor, audit-head-anchor
- **Money / orders / wallet / coupons**: money, order-guest,
  order-idempotency, order-snapshot-daily, orders-domain, coupon-identity,
  coupon-patch, coupons, featured-sale, sale-window-analytics, wallet-cas,
  wallet-transfer, plan-orders-domain, plan-orders-wallet-race,
  store-module-gate, tenant-uniqueness
- **Domains**: packages-domain, store-domain, campaign-dispatch (NEW)
- **Webhooks / mail**: webhooks, webhook-claims, webhook-http-production,
  mail-spool
- **Jobs / retention**: job-lease-hardening, retention-sweeps
- **Platform surfaces**: health-probes, admin-instance-ops,
  instance-route-coverage, mutation-coverage, legal-docs, partners-feed,
  markdown-links, markdown-rich, module-grandfathering
- **Live-server suites (7)**: see phase 2 above

**The 4 ROUND-165 suites — 25 new tests**: secret-policy (6),
storage-invariant (7), proxy-trust (7), campaign-dispatch (5: claim
CAS/409/404, no-truncation 7@batch-2, crash-resume idempotency,
invalid-address skip + dead-letter).

## The verification contract

A change is done when ALL of:

1. `bunx tsc --noEmit` — clean.
2. `bunx eslint src/` — **0 errors** (247 warnings = the tracked pre-existing
   baseline; see TECHNICAL-DEBT).
3. The offline security battery passes (`bash .zscripts/test-battery.sh`;
   the ROUND-165 session recorded 76/76 offline PASS).
4. The golden paths were exercised in a real browser.

"It compiles" is never sufficient (AGENTS.md §17).
