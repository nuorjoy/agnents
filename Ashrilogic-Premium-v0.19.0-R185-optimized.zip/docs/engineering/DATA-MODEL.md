# DATA-MODEL

The authoritative conventions for Ashrilogic's PostgreSQL schema
(`prisma/schema.prisma`, single provider): the money-unit law and its one
exception family, the JSON-as-String policy, soft-delete mechanics, the
lease/outbox model family, and the migration history. Security of the
sealed-field family: [SECURITY-MODEL.md](./SECURITY-MODEL.md).

## Money convention

**The law** (`src/lib/server/money.ts`): ALL wallet/store/order money is
INTEGER MINOR UNITS (factor 100; 199 SAR → 19900). Floating-point never
touches stored money — floats appear only at the display boundary,
converted once per DTO. Client-supplied totals are never trusted; prices
are re-derived server-side from module records at order time.
`MAX_MINOR_UNITS = 2_000_000_000` — anything above is rejected
(`isValidMinorUnits`).

Applies to: `SiteOrder.total`, order item snapshots, `WalletTxn.amountMinor`
+ `balanceAfterMinor`, `WalletTopup.amountMinor`, `Shift.salesTotal`.

**The exception family — MAJOR units** (historical billing convention,
documented per-column in the schema): `Package.priceMonthly` /
`Package.priceYearly`, `PlanOrder.amount`, `AddonOrder.amount`,
`addonsPricingJson`. Each is a server-computed snapshot — the client never
sends an amount.

**The single conversion seam**: `toMinorUnits(amount)` at wallet checkout —
exactly two call sites: `plan-orders/service.ts:161` and
`addon-orders/service.ts:128`. Every other money path is minor-native end
to end.

**Int32 margins (tracked debt — TECHNICAL-DEBT P3):**
- `priceYearly × 100` near the WALLET_CAP at the conversion seam — one
  guard from overflow for extreme catalog prices.
- `Shift.salesTotal` is an uncapped running sum (Int) — no overflow guard.

## JSON-as-String policy

| Class | Examples | Rule |
| --- | --- | --- |
| **Immutable snapshots** | order items (`itemsJson`), payment-method snapshots (`methodJson`), `WebhookDelivery.payloadJson` | written once at the event, never mutated — the snapshot IS the record (re-serialization never rewrites history; webhook receivers verify the exact bytes) |
| **Mutable state** | `Instance.contentJson`, `ModuleRecord.dataJson`, `Instance.orgJson` | read-modify-write by owning service |
| **Sealed PII** | email, phone, TOTP secrets, SMTP settings | AES-256-GCM envelopes (`crypto-vault.ts`) + HMAC-SHA256 **blind indexes** for lookups (`emailIndex`, `authorIndex`, `orgPhoneIndex`) — ciphertext in the value column, deterministic index in the twin column |

## Soft delete

- **Tuples**: `deletedAt DateTime?` + `deletedKey` (JSON preserving the
  mangled unique key's original — username, code, email index) on
  `SiteCustomer`, `SiteOrder`, `StoreCoupon`, `SiteReview`, `AdminUser`,
  `WebhookEndpoint`. Restore un-mangles; conflict-checked.
- Queries filter `deletedAt: null` (indexed `@@index([instanceId, deletedAt])`).
- **Tombstone mangling**: deleted `SiteCustomer.emailIndex` → `del:<id>`;
  `StoreCoupon.code` → `DEL-<id>` — creation of a colliding key stays legal
  while the trash row survives.
- **Trashed orders keep their reservations** — trash is restorable; a
  restore must not double-release stock/coupon quota (order-lifecycle.ts
  business rule).

## Tenant-keyed unique constraints

| Model | Constraint |
| --- | --- |
| ModuleRecord | `@@unique([instanceId, code])` (ROUND 134 — per-workspace) |
| SiteCustomer | `@@unique([instanceId, emailIndex])`, `@@unique([instanceId, username])` |
| SiteOrder | `@@unique([instanceId, code])` |
| StoreCoupon | `@@unique([instanceId, code])` |
| SiteReview | `@@unique([instanceId, recordId, authorIndex])` |
| MfaSecret / WebauthnCredential | `@@unique([scope, subjectId])`, `@@unique([scope, subjectId, id])` |
| NotificationLog | `@@unique([eventKey, weekKey])` |

**Cascade rules**: `Instance` is the parent — tenant purge cascades scoped
children (the purge sweep is application-driven). `Package` is **Restrict**:
referencing plan orders block destructive package changes. The ledger
family (`WalletTxn`, `CouponRedemption`, `OrderReservation`) is
**FK-less by design** — rows must survive referenced-row trash/purge
(`@@unique([orderId, recordId])`, `@@unique([orderId, couponId])` keep
them deduplicated).

## Lease / job / outbox models

| Model | Role |
| --- | --- |
| `SchedulerLease` | the distributed job lock: CAS claim (absent/expired/own row — never a live foreign row), **fencing epoch** incremented per (re)acquire, heartbeat renewal, token-matched release |
| `RestoreLease` | per-tenant restore lock; expired leases take over, release drops only own row |
| `WebhookDelivery` | CAS-claimed outbox: pending → processing (leaseId/workerId/lockedUntil) → terminal; attempts-CAS result writes |
| `EmailLog` | mail outbox (PENDING row persisted BEFORE delivery — ROUND 120) + per-recipient campaign ledger (type `campaign`, `idempotencyKey campaign:<cid>:<sid>`, stable Message-ID) |
| `OrderIdempotency` | duplicate-submission absorption at order placement |
| `CouponRedemption` / `OrderReservation` | quota + stock durability; released by the order-compensation sweep |
| `NewsletterCampaign` | dispatch state: `dispatchCursor`, `dispatchEnqueueDone`, `dispatchEnqueued`, `delivered`, `failed` (ROUND 165) |
| `AuditChainAnchor` | sealed chain-head records backing the external anchor file |

## Migrations

`prisma/migrations/` — versioned, `migrate deploy` is the production path
(the squashed `20260928000000_postgres_baseline` is the PostgreSQL-only
baseline after the SQLite cutover):

1. `20260929100000_campaign_durable_dispatch` — additive-only columns on
   `NewsletterCampaign` (cursor, enqueue-done marker, enqueue count,
   terminal delivered/failed counts). Existing rows untouched; `sending`
   is only ever written by the draft→sending claim.
2. `20260929110000_tenant_phone_index` — `Instance.orgPhoneIndex` +
   index; **NULL on legacy rows — backfill via
   `bun run backfill:phone-index`** (release protocol, OPERATIONS.md);
   the deep-check retains a bounded legacy fallback.

Both ROUND-165 migrations are additive-only: no data rewrite, safe to
deploy ahead of code.
