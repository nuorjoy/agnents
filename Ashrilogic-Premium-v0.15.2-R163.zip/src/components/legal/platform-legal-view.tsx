"use client";

/**
 * Ashrilogic — ROUND 117 — the PLATFORM legal document view.
 *
 * Renders Ashrilogic's own privacy policy / terms of use (the
 * console-editable LegalDoc rows) as a premium reading experience:
 *
 *  - a topbar with the brand tile, the platform wordmark and a
 *    print-to-PDF affordance (the page is print-styled: the aurora and
 *    the sidebar drop out, the document prints cleanly);
 *  - a hero band: gradient medallion, title, the live last-reviewed
 *    chip + version badge (v0 = the code default — rendered as the
 *    «النسخة المعتمدة» chip);
 *  - a sticky table-of-contents sidebar (desktop) driven by the shared
 *    useScrollSpy hook — the active section highlights with the brand
 *    gradient rail; mobile collapses it into a compact scrollable
 *    chip-row;
 *  - the sections: numbered medallions, the heading, and the body split
 *    into paragraphs (blank-line separated — same reading rhythm as the
 *    per-site legal pages);
 *  - language-aware: the page receives ALL locale variants from the
 *    server (few KB) and picks the visitor's language client-side with
 *    the same fallback chain the server uses (hi → en → ar).
 *
 * Dark/light aware, RTL/LTR aware, fully keyboard navigable (real
 * anchors, real focus states), min-h-screen flex column with the footer
 * pushed to the bottom (safe-bottom).
 */
import { useMemo } from "react";
import { motion } from "framer-motion";
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { grad } from "@/lib/utils";
import { PlatformBrandTile, usePlatformWordmark } from "@/components/shared/platform-brand";
import { useScrollSpy } from "@/hooks/use-scrollspy";
import type { LegalDocKey, LegalDocLocale } from "@/lib/platform-legal-defaults";

export interface LegalDocViewPayload {
  key: LegalDocKey;
  title: string;
  intro: string;
  sections: { heading: string; body: string }[];
  updatedAt: string | null;
  version: number;
  customized?: boolean;
}

export interface PlatformLegalViewProps {
  kind: LegalDocKey;
  /** every locale variant resolved server-side (row ?? default) */
  docs: Partial<Record<LegalDocLocale, LegalDocViewPayload>>;
}

const GRADS: Record<LegalDocKey, { c1: string; c2: string; icon: string }> = {
  privacy: { c1: "#6d5dfb", c2: "#06b6d4", icon: "shield-check" },
  terms: { c1: "#059669", c2: "#10b981", icon: "scale" },
};

function fullDate(iso: string, lang: string): string {
  try {
    return new Date(iso).toLocaleDateString(lang === "ar" ? "ar" : lang === "hi" ? "hi" : "en-GB", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  } catch {
    return iso.slice(0, 10);
  }
}

export function PlatformLegalView({ kind, docs }: PlatformLegalViewProps) {
  const { t, lang } = useT();
  const wordmark = usePlatformWordmark();
  const theme = GRADS[kind];

  const doc = useMemo(() => {
    const wanted = (lang as LegalDocLocale) ?? "ar";
    return docs[wanted] ?? docs.en ?? docs.ar!;
  }, [docs, lang]);

  const sectionIds = useMemo(
    () => doc.sections.map((_, i) => `sec-${i}`),
    [doc]
  );
  const active = useScrollSpy(sectionIds, 96);

  const print = () => window.print();

  return (
    <div className="print-legal-scope relative flex min-h-screen flex-col bg-slate-50/60 dark:bg-transparent">
      {/* ambient gradient wash (ROUND 118: print-hide — never in the ink) */}
      <div className="print-hide pointer-events-none fixed inset-0 -z-10" aria-hidden="true">
        <div
          className="absolute -top-24 start-1/4 h-72 w-72 rounded-full blur-3xl opacity-[0.16] dark:opacity-[0.12]"
          style={{ background: `radial-gradient(circle, ${theme.c1}, transparent 70%)` }}
        />
        <div
          className="absolute bottom-0 end-1/4 h-80 w-80 rounded-full blur-3xl opacity-[0.12] dark:opacity-[0.09]"
          style={{ background: `radial-gradient(circle, ${theme.c2}, transparent 70%)` }}
        />
      </div>

      {/* the topbar (ROUND 118: print-hide — the printed document needs no
          chrome; the sections below carry the print-doc scope) */}
      <header className="print-hide sticky top-0 z-40 border-b border-slate-200/70 bg-white/80 backdrop-blur-md dark:border-white/[0.07] dark:bg-slate-950/70">
        <div className="mx-auto flex h-14 max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
          <a href="/" className="flex items-center gap-2.5 rounded-xl focus-visible:ring-4 focus-visible:ring-brand-500/20">
            <PlatformBrandTile
              variant="main"
              className="h-8 w-8 rounded-lg"
              fallback={
                <span
                  className="grid h-8 w-8 place-items-center rounded-lg text-white"
                  style={{ backgroundImage: grad(theme.c1, theme.c2) }}
                  aria-hidden="true"
                >
                  <CatIcon name="boxes" className="h-3.5 w-3.5" />
                </span>
              }
            />
            <span className="font-display text-[15px] font-extrabold">
              <span className="text-gradient">{wordmark}</span>
            </span>
          </a>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={print}
              className="hidden h-9 items-center gap-1.5 rounded-xl border border-slate-200 bg-white/80 px-3.5 text-[12px] font-bold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 sm:flex dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
            >
              <CatIcon name="printer" className="h-3.5 w-3.5" />
              {t("legalPrint")}
            </button>
            <a
              href="/"
              className="flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 bg-white/80 px-3.5 text-[12px] font-bold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
            >
              <CatIcon name="arrow-left" className="h-3.5 w-3.5 rtl:rotate-180" />
              {t("legalBackHome")}
            </a>
          </div>
        </div>
      </header>

      {/* the hero band (ROUND 118: print-hide — the print-only doc header
          inside the article carries the title into the ink instead) */}
      <section className="print-hide relative border-b border-slate-200/70 bg-white/60 dark:border-white/[0.07] dark:bg-white/[0.02]">
        <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 sm:py-14">
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="flex flex-col items-start gap-5 sm:flex-row sm:items-center"
          >
            <span
              className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
              style={{ backgroundImage: grad(theme.c1, theme.c2), boxShadow: `0 16px 32px -12px ${theme.c1}55` }}
              aria-hidden="true"
            >
              <CatIcon name={theme.icon} className="h-7 w-7" />
            </span>
            <div className="min-w-0">
              <p className="flex flex-wrap items-center gap-2">
                <span className="inline-flex items-center gap-1.5 rounded-full border border-brand-200 bg-brand-50 px-3 py-1 text-[11px] font-bold text-brand-600 dark:border-brand-500/25 dark:bg-brand-500/10 dark:text-brand-300">
                  <CatIcon name="sparkles" className="h-3 w-3" />
                  {t(kind === "privacy" ? "legalPrivacyChip" : "legalTermsChip")}
                </span>
                <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white/70 px-3 py-1 text-[11px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400">
                  <CatIcon name="clock" className="h-3 w-3" />
                  {doc.updatedAt
                    ? t("legalUpdated", { date: fullDate(doc.updatedAt, lang) })
                    : t("legalCanonical")}
                </span>
                {doc.customized ? (
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-[11px] font-bold text-emerald-600 dark:border-emerald-500/25 dark:bg-emerald-500/10 dark:text-emerald-300">
                    <CatIcon name="badge-check" className="h-3 w-3" />
                    {t("legalVersion", { v: String(doc.version) })}
                  </span>
                ) : null}
              </p>
              <h1 className="mt-2.5 font-display text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl dark:text-white">
                {doc.title}
              </h1>
              <p className="mt-3 max-w-3xl text-[14px] leading-relaxed text-slate-600 dark:text-slate-400">
                {doc.intro}
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* mobile TOC chips (ROUND 118: print-hide) */}
      <div className="print-hide border-b border-slate-200/70 bg-white/60 lg:hidden dark:border-white/[0.07] dark:bg-white/[0.02]">
        <div className="mx-auto flex max-w-6xl gap-2 overflow-x-auto px-4 py-3 sm:px-6" aria-label={t("legalToc")}>
          {doc.sections.map((s, i) => (
            <a
              key={i}
              href={`#sec-${i}`}
              className="shrink-0 rounded-full border border-slate-200 bg-white/70 px-3 py-1 text-[11px] font-bold text-slate-500 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400 dark:hover:text-brand-300"
            >
              {i + 1}. {s.heading.length > 28 ? `${s.heading.slice(0, 28)}…` : s.heading}
            </a>
          ))}
        </div>
      </div>

      {/* the document body */}
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-10 sm:px-6 lg:py-14">
        <div className="grid gap-10 lg:grid-cols-[240px_minmax(0,1fr)]">
          {/* desktop sticky TOC (ROUND 118: print-hide) */}
          <aside className="print-hide hidden lg:block">
            <nav className="sticky top-24" aria-label={t("legalToc")}>
              <p className="mb-3 flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                <CatIcon name="list" className="h-3.5 w-3.5" />
                {t("legalToc")}
              </p>
              <ol className="space-y-1 border-s-2 border-slate-200 dark:border-white/10">
                {doc.sections.map((s, i) => {
                  const isActive = active === `sec-${i}`;
                  return (
                    <li key={i} className="relative">
                      {isActive ? (
                        <span
                          className="absolute -start-[2px] top-1/2 h-5 w-[2px] -translate-y-1/2 rounded-full"
                          style={{ backgroundImage: grad(theme.c1, theme.c2) }}
                          aria-hidden="true"
                        />
                      ) : null}
                      <a
                        href={`#sec-${i}`}
                        className={`block rounded-e-lg px-3 py-1.5 text-[12.5px] font-semibold leading-snug transition ${
                          isActive
                            ? "text-brand-600 dark:text-brand-300"
                            : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"
                        }`}
                      >
                        {i + 1}. {s.heading}
                      </a>
                    </li>
                  );
                })}
              </ol>
            </nav>
          </aside>

          {/* the sections — ROUND 118: `print-legal-doc` scopes the flow
              print stylesheet (multi-page: natural pagination, ink-safe) so
              ONLY the document reaches the paper; the print-only header
              below carries the title + review date into the ink */}
          <article className="print-legal-doc min-w-0 space-y-8">
            {/* print-only document header (never rendered on screen) */}
            <header className="print-only border-b border-slate-200 pb-4">
              <h1 className="font-display text-[22px] font-extrabold text-slate-900">{doc.title}</h1>
              <p className="mt-1.5 text-[11px] font-bold text-slate-500">
                {wordmark}
                {doc.updatedAt
                  ? ` · ${t("legalUpdated", { date: fullDate(doc.updatedAt, lang) })}`
                  : doc.customized
                    ? ` · ${t("legalVersion", { v: String(doc.version) })}`
                    : ` · ${t("legalCanonical")}`}
              </p>
            </header>
            {doc.sections.map((s, i) => (
              <motion.section
                key={i}
                id={`sec-${i}`}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                className="scroll-mt-24 rounded-2xl border border-slate-200/80 bg-white/80 p-5 sm:p-7 dark:border-white/[0.07] dark:bg-white/[0.03]"
              >
                <h2 className="flex items-start gap-3 font-display text-[17px] font-extrabold text-slate-900 sm:text-[18px] dark:text-white">
                  <span
                    className="grid h-8 w-8 shrink-0 place-items-center rounded-xl text-[12px] font-black text-white shadow-md"
                    style={{ backgroundImage: grad(theme.c1, theme.c2) }}
                    aria-hidden="true"
                  >
                    {i + 1}
                  </span>
                  <span className="min-w-0 pt-1">{s.heading}</span>
                </h2>
                <div className="mt-3 space-y-3 sm:ps-11">
                  {s.body
                    .split(/\n\n+/)
                    .filter((p) => p.trim().length > 0)
                    .map((p, j) => (
                      <p key={j} className="text-[13.5px] font-medium leading-[1.9] text-slate-600 dark:text-slate-300">
                        {p.trim()}
                      </p>
                    ))}
                </div>
              </motion.section>
            ))}
          </article>
        </div>
      </main>

      {/* the footer (ROUND 118: print-hide on the paper output) */}
      <footer className="print-hide safe-bottom mt-auto border-t border-slate-200/70 bg-white/70 backdrop-blur-sm dark:border-white/[0.07] dark:bg-white/[0.02]">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-4 sm:px-6">
          <p className="flex items-center gap-1.5 text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" aria-hidden="true" />
            {wordmark} — {t(kind === "privacy" ? "docTitleLegalPrivacy" : "docTitleLegalTerms")}
          </p>
          <div className="flex items-center gap-4 text-[11px] font-bold text-slate-400 dark:text-slate-500">
            <a href={kind === "privacy" ? "/terms" : "/privacy"} className="transition hover:text-brand-600 dark:hover:text-brand-300">
              {kind === "privacy" ? t("legalLinkTerms") : t("legalLinkPrivacy")}
            </a>
            <a href="/" className="transition hover:text-brand-600 dark:hover:text-brand-300">
              {t("legalBackHome")}
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
