"use client";

/**
 * Ashrilogic — ROUND 141: the member's DEDICATED profile page
 * (/sites/<id>/account/<username>).
 *
 * The owner's directive: member profiles must NEVER open as a popup — a
 * real page carries the member's OWN username in the URL, professional
 * and Premium, on BOTH the public website (الموقع الإلكتروني) and the
 * e-store (المتجر الإلكتروني).
 *
 * ROUND 144 — THE CRASH FIX: the five reused account panels
 * (Profile/Addresses/Payments/Orders/Inquiries) all read through
 * useStoreAccount(), which throws outside <StoreAccountProvider>. This
 * page never mounted the provider — so the member console crashed on
 * render. The provider now wraps the whole page tree and owns the ONE
 * ["store-account", instanceId] query (the page's private duplicate probe
 * is gone — the context feeds every branch below).
 *
 * Design:
 *  - the URL handle is an ADDRESS, never a data key: every panel reads
 *    through the customer SESSION APIs (which project only the session
 *    owner's data) — a visitor opening someone else's handle sees the
 *    premium "not available" screen with zero information;
 *  - the signed-in member whose handle matches gets the full premium
 *    console: the @username hero (avatar, name, verified state, member
 *    since) + the five real panels (profile / addresses / payments /
 *    orders / inquiries) reused VERBATIM from the account console;
 *  - a guest is invited to the account portal (sign in) — the page never
 *    reveals whether the handle exists.
 *
 * Conventions mirror account-page-view.tsx exactly (RTL logical classes,
 * grad()/hexAlpha() theming, CatIcon vocabulary, 44px touch targets,
 * safe-bottom footer, the store's font + accent scope).
 */
import { useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { useT, type I18nKey } from "@/lib/i18n";
import { logoutStoreAccount } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { SkipLink } from "@/components/skip-link";
import { useDocumentTitle } from "@/hooks/use-document-title";
import { useBrandFavicon } from "@/hooks/use-brand-favicon";
import { cn, grad, hexAlpha } from "@/lib/utils";
import { fontVars, accentVars } from "@/lib/surface-styling";
import {
  StoreAccountProvider,
  useStoreAccount,
  mapAccountError,
  AcctAvatarEditor,
} from "@/components/site/store-account";
import {
  ProfilePanel,
  AddressesPanel,
  PaymentsPanel,
  OrdersPanel,
  InquiriesPanel,
} from "@/components/site/store-account-sheet";

export interface MemberPageViewProps {
  instanceId: string;
  /** the URL's handle (already server-validated shape + lowercased) */
  username: string;
  orgName: string;
  systemIcon: string;
  c1: string;
  c2: string;
  logoUrl?: string;
  storeLive: boolean;
  preview: boolean;
  storeFont?: string;
}

const TABS: { value: string; icon: string; labelKey: I18nKey }[] = [
  { value: "profile", icon: "user-round", labelKey: "acctTabProfile" },
  { value: "addresses", icon: "map-pin", labelKey: "acctTabAddresses" },
  { value: "payments", icon: "credit-card", labelKey: "acctTabPayments" },
  { value: "orders", icon: "package", labelKey: "acctTabOrders" },
  { value: "inquiries", icon: "message-square", labelKey: "acctTabInquiries" },
];

export function MemberPageView(props: MemberPageViewProps) {
  /* ROUND 144 — the five account panels read through useStoreAccount(),
   * which REQUIRES the provider: mounting it here (above the whole page
   * tree — hero, tab strip, panels region and every gating branch) both
   * fixes the crash and gives the page the single shared
   * ["store-account", instanceId] session probe. */
  return (
    <StoreAccountProvider instanceId={props.instanceId}>
      <MemberPageInner {...props} />
    </StoreAccountProvider>
  );
}

function MemberPageInner({
  instanceId,
  username,
  orgName,
  systemIcon,
  c1,
  c2,
  logoUrl,
  storeLive,
  preview,
  storeFont,
}: MemberPageViewProps) {
  const { t, lang } = useT();
  const router = useRouter();
  const [tab, setTab] = useState("profile");

  /* ROUND 147 — ?tab= deep links (the live-reply toast's CTA lands on
   * ?tab=inquiries). ONE-SHOT read at the first CLIENT render through the
   * codebase's previous-value pattern (setState during render — the same
   * idiom the account sheet uses to reset its tab on open): no effect-body
   * setState (cascading renders), no useSearchParams (would need a
   * Suspense boundary here) and no hydration desync — the server pass has
   * no window and BOTH passes render the pending probe's skeleton, which
   * never depends on the tab. */
  const [tabBootstrapped, setTabBootstrapped] = useState(false);
  if (!tabBootstrapped) {
    setTabBootstrapped(true);
    if (typeof window !== "undefined") {
      const wanted = new URLSearchParams(window.location.search).get("tab");
      if (wanted && TABS.some((entry) => entry.value === wanted)) {
        setTab(wanted);
      }
    }
  }

  useDocumentTitle("memberDocTitle", { org: orgName });
  useBrandFavicon(instanceId);

  /* the SESSION probe — owned by the StoreAccountProvider above (the URL
   * handle never fetches anything by itself). */
  const { account, loading } = useStoreAccount();

  /* the handle verdict: the session owner's handle must match the URL —
   * anything else is the neutral "not available" screen (guests too). */
  const isOwner = account != null && account.username === username;

  const signOut = useMutation({
    mutationFn: () => logoutStoreAccount(instanceId),
    onSuccess: () => {
      toast.success(t("acctSignedOutToast"));
      router.push(storeLive ? `/sites/${instanceId}/store` : `/sites/${instanceId}`);
    },
    onError: (e: Error) => toast.error(mapAccountError(e, t)),
  });

  const siteHref = `/sites/${instanceId}`;
  const storeHref = `/sites/${instanceId}/store`;
  const homeHref = storeLive ? storeHref : siteHref;

  const memberSince = useMemo(() => {
    if (!account) return "";
    try {
      return new Date(account.createdAt).toLocaleDateString(lang === "ar" ? "ar" : "en", {
        year: "numeric",
        month: "long",
      });
    } catch {
      return "";
    }
  }, [account, lang]);

  return (
    <div
      className="brand-scope surface-font-scope relative flex min-h-screen flex-col bg-background"
      dir={lang === "ar" ? "rtl" : "ltr"}
      style={{ ...fontVars(storeFont), ...accentVars(c1) }}
    >
      <SkipLink target="member-page-main" />

      {/* decorative background */}
      <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden="true" />
      <div
        className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[420px] opacity-60"
        style={{ background: `radial-gradient(60% 50% at 50% 0%, ${hexAlpha(c1, 0.14)}, transparent 70%)` }}
        aria-hidden="true"
      />

      {/* draft preview banner (owner / admin only — server-gated) */}
      {preview ? (
        <div className="border-b border-amber-300/60 bg-amber-100/90 px-4 py-2 text-center backdrop-blur-sm dark:border-amber-500/30 dark:bg-amber-500/15">
          <p className="inline-flex items-center gap-2 text-[11.5px] font-extrabold text-amber-800 dark:text-amber-300">
            <CatIcon name="eye" className="h-3.5 w-3.5" />
            {t("acctPagePreviewBanner")}
          </p>
        </div>
      ) : null}

      {/* ---------------- mini header ---------------- */}
      <header className="border-b border-slate-200/70 bg-white/80 backdrop-blur-xl dark:border-white/[0.07] dark:bg-ink-950/80">
        <div className="mx-auto flex h-16 max-w-5xl items-center gap-2.5 px-4 sm:px-6">
          <Link href={homeHref} className="flex min-w-0 items-center gap-2.5">
            {logoUrl ? (
              <span
                className="grid h-10 w-10 shrink-0 place-items-center overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-lg dark:border-white/10 dark:bg-white/90"
                aria-hidden="true"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={logoUrl} alt="" className="h-full w-full object-contain p-1" />
              </span>
            ) : (
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg"
                style={{ backgroundImage: grad(c1, c2), boxShadow: `0 8px 20px -8px ${hexAlpha(c1, 0.8)}` }}
              >
                <CatIcon name={systemIcon} className="h-[15px] w-[15px]" />
              </span>
            )}
            <span className="min-w-0">
              <span className="block truncate text-[13.5px] font-extrabold text-slate-900 dark:text-white">
                {orgName}
              </span>
              <span className="block truncate text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                {t("memberPageCrumb")}
              </span>
            </span>
          </Link>

          <div className="ms-auto flex items-center gap-2">
            <Button
              type="button"
              onClick={() => router.push(homeHref)}
              className="h-10 gap-2 rounded-xl border border-slate-200 bg-white px-3.5 text-[12px] font-bold text-slate-600 shadow-sm transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
            >
              <CatIcon name="arrow-right" className="h-4 w-4 rtl:rotate-180" />
              <span className="hidden sm:inline">{t("memberBackHome")}</span>
            </Button>
            {isOwner ? (
              <Button
                type="button"
                onClick={() => signOut.mutate()}
                disabled={signOut.isPending}
                className="h-10 gap-2 rounded-xl px-3.5 text-[12px] font-bold text-rose-600 shadow-sm transition hover:bg-rose-500/10 dark:text-rose-300"
              >
                <CatIcon name="log-out" className="h-4 w-4" />
                <span className="hidden sm:inline">{t("selectSignOut")}</span>
              </Button>
            ) : null}
          </div>
        </div>
      </header>

      {/* ---------------- main ---------------- */}
      <main id="member-page-main" className="mx-auto w-full max-w-5xl flex-1 px-4 py-8 sm:px-6 lg:py-10">
        {loading ? (
          /* ---------------- loading ---------------- */
          <div className="mx-auto max-w-2xl space-y-5" aria-busy="true">
            <Skeleton className="h-40 w-full rounded-3xl" />
            <Skeleton className="h-11 w-full rounded-2xl" />
            <Skeleton className="h-64 w-full rounded-3xl" />
          </div>
        ) : !isOwner ? (
          /* ---------------- neutral not-available screen ----------------
           * guests AND visitors of someone else's handle read IDENTICALLY:
           * the page never reveals whether the handle exists. */
          <div className="mx-auto max-w-md py-16 text-center">
            <span
              className="mx-auto grid h-20 w-20 place-items-center rounded-3xl text-white shadow-xl"
              style={{ backgroundImage: grad(c1, c2), boxShadow: `0 16px 34px -12px ${hexAlpha(c1, 0.7)}` }}
            >
              <CatIcon name="lock" className="h-9 w-9" />
            </span>
            <h1 className="mt-6 font-display text-[20px] font-extrabold text-slate-900 dark:text-white">
              {t("memberNotYouTitle")}
            </h1>
            <p className="mx-auto mt-2.5 max-w-[42ch] text-[13px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
              {t("memberNotYouDesc")}
            </p>
            <div className="mt-7 flex flex-wrap items-center justify-center gap-2.5">
              <Button
                type="button"
                onClick={() => router.push(`/sites/${instanceId}/account`)}
                className="h-11 gap-2 rounded-xl px-5 text-[13px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-[0.99]"
                style={{ backgroundImage: grad(c1, c2) }}
              >
                <CatIcon name="log-in" className="h-4 w-4" />
                {t("memberSignInCta")}
              </Button>
              <Button
                type="button"
                onClick={() => router.push(homeHref)}
                className="h-11 gap-2 rounded-xl border border-slate-200 bg-white px-5 text-[12.5px] font-bold text-slate-700 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200"
              >
                <CatIcon name="arrow-right" className="h-4 w-4 rtl:rotate-180" />
                {t("memberBackHome")}
              </Button>
            </div>
          </div>
        ) : (
          /* ---------------- the member's premium console ---------------- */
          <div className="space-y-6">
            {/* the @username hero */}
            <section
              className="card-in relative overflow-hidden rounded-3xl border border-slate-200/70 p-6 dark:border-white/[0.07]"
              style={{
                backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.12)}, ${hexAlpha(c2, 0.08)} 55%, transparent)`,
              }}
            >
              <div
                className="pointer-events-none absolute -end-16 -top-20 h-56 w-56 rounded-full"
                style={{ background: `radial-gradient(circle, ${hexAlpha(c1, 0.25)}, transparent 70%)` }}
                aria-hidden="true"
              />
              <div className="relative flex flex-col items-start gap-5 sm:flex-row sm:items-center">
                {/* ROUND 147 — the member's own avatar with its edit
                    affordances (upload / change / remove) — own-profile
                    only by construction: the hero renders for the session
                    owner whose handle matches the URL. */}
                <AcctAvatarEditor c1={c1} c2={c2} />
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h1 className="truncate font-display text-[19px] font-extrabold text-slate-900 dark:text-white">
                      {account.name}
                    </h1>
                    {/* ROUND L (TASK STORE-PROFILE) — the PREMIUM VERIFICATION
                        BADGE (blue checkmark). Shown ONLY when BOTH the
                        email AND the phone are verified — the owner's
                        directive: «لا تعطي العميل شعار التوثيق إلا بعد أن
                        يقوم (البريد الإلكتروني، رقم الهاتف) معاً بدقة تامة».
                        If either is unverified, NO badge is shown — the
                        per-channel chips below tell the customer what's
                        still missing. */}
                    {account.emailVerified && account.phoneVerified ? (
                      <span
                        title={t("acctVerifiedBadgeTooltip")}
                        className="inline-flex shrink-0 items-center gap-1 rounded-full border border-sky-300/60 bg-sky-500/10 px-2 py-0.5 text-[9.5px] font-extrabold text-sky-600 dark:border-sky-400/40 dark:text-sky-300"
                      >
                        {/* the premium blue checkmark — a small filled circle
                            with a white tick (matches the Twitter/Instagram
                            verified-mark vocabulary). */}
                        <span className="relative grid h-3.5 w-3.5 place-items-center">
                          <span
                            aria-hidden="true"
                            className="absolute inset-0 rounded-full"
                            style={{ backgroundImage: "linear-gradient(135deg, #38bdf8, #2563eb)" }}
                          />
                          <CatIcon
                            name="check"
                            className="relative h-2.5 w-2.5 text-white"
                          />
                        </span>
                        {t("acctVerifiedBadge")}
                      </span>
                    ) : null}
                    {/* the per-channel verification chips — these stay visible
                        individually so the customer knows exactly what's
                        missing for the premium badge to appear. */}
                    <span
                      className={cn(
                        "inline-flex shrink-0 items-center gap-1 rounded-full border px-2 py-0.5 text-[9.5px] font-extrabold",
                        account.emailVerified
                          ? "border-emerald-300/60 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
                          : "border-amber-300/70 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300"
                      )}
                    >
                      <CatIcon
                        name={account.emailVerified ? "badge-check" : "mail-warning"}
                        className="h-3 w-3"
                      />
                      {t(account.emailVerified ? "acctVerifiedChip" : "acctUnverifiedChip")}
                    </span>
                    <span
                      className={cn(
                        "inline-flex shrink-0 items-center gap-1 rounded-full border px-2 py-0.5 text-[9.5px] font-extrabold",
                        account.phoneVerified
                          ? "border-emerald-300/60 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
                          : "border-amber-300/70 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300"
                      )}
                      title={t("acctPhoneUnverifiedChipHint")}
                    >
                      <CatIcon
                        name={account.phoneVerified ? "badge-check" : "phone"}
                        className="h-3 w-3"
                      />
                      {t(account.phoneVerified ? "acctVerifiedChip" : "acctPhoneUnverifiedChip")}
                    </span>
                  </div>
                  {/* ROUND L — the handle (the page's identity). Auto-detect
                      direction: Arabic-letter handles render RTL (dir="rtl",
                      text-end alignment) per the directive «يجب أن يدعم التنسيق
                      العربي بدقة مع محاذاة النصوص من اليمين»; latin/digit
                      handles stay LTR (the historical default). */}
                  <p
                    dir={/[\u0621-\u064a]/.test(account.username || username) ? "rtl" : "ltr"}
                    className={cn(
                      "mt-1.5 truncate font-mono text-[13.5px] font-extrabold",
                      /[\u0621-\u064a]/.test(account.username || username) ? "text-end" : "text-start"
                    )}
                    style={{ color: c1 }}
                  >
                    @{account.username || username}
                  </p>
                  <p className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                    <span className="inline-flex items-center gap-1.5">
                      <CatIcon name="mail" className="h-3 w-3" />
                      <span dir="ltr" className="max-w-[220px] truncate">{account.email}</span>
                    </span>
                    {memberSince ? (
                      <span className="inline-flex items-center gap-1.5">
                        <CatIcon name="calendar" className="h-3 w-3" />
                        {t("memberSince", { date: memberSince })}
                      </span>
                    ) : null}
                  </p>
                </div>
                {/* the shareable profile link chip (copy) */}
                <button
                  type="button"
                  onClick={() => {
                    const url = `${window.location.origin}/sites/${instanceId}/account/${account.username || username}`;
                    void navigator.clipboard?.writeText(url).then(
                      () => toast.success(t("memberLinkCopied")),
                      () => toast.error(t("errorText"))
                    );
                  }}
                  className="inline-flex h-10 shrink-0 items-center gap-2 rounded-xl border border-slate-200 bg-white/80 px-3.5 text-[11.5px] font-extrabold text-slate-600 shadow-sm transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
                >
                  <CatIcon name="link" className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">{t("memberCopyLink")}</span>
                </button>
              </div>
            </section>

            {/* the tab strip */}
            <div
              role="tablist"
              aria-label={t("memberTabsAria")}
              className="nice-scroll flex h-12 w-full items-center gap-1 overflow-x-auto rounded-2xl bg-slate-100 p-1 dark:bg-white/5"
            >
              {TABS.map((tabDef) => {
                const active = tab === tabDef.value;
                return (
                  <button
                    key={tabDef.value}
                    type="button"
                    role="tab"
                    aria-selected={active}
                    onClick={() => setTab(tabDef.value)}
                    className={cn(
                      "inline-flex h-10 shrink-0 items-center gap-1.5 rounded-xl px-3.5 text-[12.5px] font-extrabold transition",
                      active
                        ? "bg-white text-slate-900 shadow-sm dark:bg-white/10 dark:text-white"
                        : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white"
                    )}
                  >
                    <CatIcon name={tabDef.icon} className="h-3.5 w-3.5" />
                    {t(tabDef.labelKey)}
                  </button>
                );
              })}
            </div>

            {/* the active panel — the SAME premium components the account
                console uses (verbatim, session-scoped data) */}
            <div className="member-panel-in">
              {tab === "profile" ? <ProfilePanel instanceId={instanceId} c1={c1} c2={c2} /> : null}
              {tab === "addresses" ? <AddressesPanel instanceId={instanceId} c1={c1} c2={c2} /> : null}
              {tab === "payments" ? <PaymentsPanel instanceId={instanceId} c1={c1} c2={c2} /> : null}
              {tab === "orders" ? (
                <OrdersPanel instanceId={instanceId} c1={c1} c2={c2} orgName={orgName} logoUrl={logoUrl} />
              ) : null}
              {tab === "inquiries" ? <InquiriesPanel instanceId={instanceId} c1={c1} c2={c2} /> : null}
            </div>
          </div>
        )}
      </main>

      {/* ---------------- footer ---------------- */}
      <footer className="safe-bottom mt-auto border-t border-slate-200/70 bg-white/60 py-4 backdrop-blur-sm dark:border-white/[0.07] dark:bg-white/[0.02]">
        <p className="flex flex-wrap items-center justify-center gap-2 px-4 text-center text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
          <CatIcon name="shield-check" className="h-3 w-3 text-emerald-500" />
          {t("acctPageSecureNote")}
          <span className="text-slate-300 dark:text-slate-600">·</span>
          © {new Date().getFullYear()} {orgName}
          <span className="text-slate-300 dark:text-slate-600">·</span>
          {lang === "ar" ? "مدعوم بأشرِيلوجيك" : "Powered by Ashrilogic"}
        </p>
      </footer>
    </div>
  );
}
