"use client";

/**
 * ROUND 55 — the STANDALONE Amazon-grade premium storefront.
 * (/sites/[instanceId]/store — server loader: src/app/sites/[id]/store/page.tsx)
 *
 * The user's demands, verbatim:
 *   "عند فتح الموقع الإلكتروني لا يجب أن يكون المتجر داخله — كل واحد قائم
 *    بذاته ومنفصل عن الآخر" — the website and the store are two standalone
 *    experiences (ROUND 57: the website shows NOTHING store-related at all —
 *    no gateway, no nav link; this standalone page is the only store surface);
 *   "المتجر الإلكتروني يجب أن يكون متجر متكامل واحترافي مثل أمازون/وول مارت
 *    بطريقة Premium" — this page IS that store.
 *
 * Amazon/Walmart-inspired shopping anatomy, in the platform's own design
 * language (glass surfaces, rounded-2xl/3xl, slate palette, brand gradient
 * via grad(c1,c2), hexAlpha tints, CatIcon, RTL-first logical classes —
 * renders LTR just as cleanly):
 *
 *   1. sticky store header — brand + "متجر إلكتروني" badge + a LARGE
 *      search bar with an Amazon-style department select BEFORE the input
 *      (its own row below the brand row on mobile);
 *   2. category nav strip — horizontally scrollable "الكل" + category chips
 *      with honest counts + the round-54 quick-filter toggles (مميزة /
 *      عليها عرض);
 *   3. deals band — hero cards for featured/sale products with countdown
 *      chips and direct add-to-cart;
 *   4. results toolbar — live result count, one-tap-clear active filter
 *      chips and a sort select (most popular / price asc / price desc);
 *   5. product grid — 2/3/4 responsive columns of the shared
 *      StoreProductCard with 12-then-+12 load-more pagination;
 *   6. benefits strip — the trust bar (secure checkout · fast delivery ·
 *      easy returns · always-on support);
 *   8. store footer — org + © + back-to-website + powered-by + lang/theme
 *      toggles (exact site-header patterns);
 *   9. cart FAB (start corner) + the shared guest StoreCartSheet — the cart
 *      state lives HERE now (the website page is cart-free);
 *  10. ROUND 65 — customer accounts: StoreAccountProvider probes the session
 *      once; ROUND 85: guests LINK to the DEDICATED account page
 *      (/sites/[id]/account — sign-up / sign-in / forgot password, no
 *      popup); ROUND 141: signed-in members LINK to their DEDICATED profile
 *      page (/sites/[id]/account/<username>) — the popup sheet is retired
 *      on BOTH the public website and the e-store (the owner's directive);
 *  11. ROUND 147 — Amazon/Walmart-grade navigation ADDITIONS (existing
 *      surfaces untouched): a departments panel (Popover on desktop /
 *      bottom Sheet on mobile) over the category chips; a sticky desktop
 *      filter rail (price bounds · rating floor · in-stock · the round-54
 *      quick toggles) with a mobile twin in a Sheet; breadcrumbs above the
 *      results toolbar; q + category reflected into the URL via
 *      history.replaceState; the cart PERSISTED per instance
 *      (use-store-cart.ts — the wishlist's localStorage/uSES pattern);
 *      a recently-viewed rail (localStorage ids, merged against the live
 *      catalog); the quick view gains a variant picker + related-products
 *      rows; the cart sheet gains saved-address shipping (signed-in) and
 *      sends the chosen variant label with each placement line.
 *
 * DATA: ONE react-query over the EXISTING public store API (search +
 * category run server-side, 300ms-debounced) — zero new API surface; the
 * guest checkout, coupons and sale windows (rounds
 * 36–54) are untouched. All ROUND 147 facets are CLIENT-side over the
 * fetched page's products.
 */
import { useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { useTheme } from "next-themes";
import dynamic from "next/dynamic";
import { toast } from "sonner";
import type { SiteProductDTO } from "@/lib/types";
import { useT, type I18nKey } from "@/lib/i18n";
import { fetchSiteStore } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { grad, hexAlpha, cn } from "@/lib/utils";
import { fontVars, accentVars, surfaceLangs } from "@/lib/surface-styling";
import { SurfaceLangSwitcher } from "@/components/site/surface-lang-switcher";
import { useDocumentTitle } from "@/hooks/use-document-title";
import { useBrandFavicon } from "@/hooks/use-brand-favicon";
import { useWishlist } from "@/hooks/use-wishlist";
import { useStoreCart } from "@/hooks/use-store-cart";
import { SkipLink } from "@/components/skip-link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Reveal } from "@/components/landing/reveal";
import { StoreBackToTop } from "@/components/site/store-back-to-top";
import {
  StoreAccountButton,
  StoreAccountProvider,
} from "@/components/site/store-account";
import {
  nf,
  fmtPrice,
  SaleCountdownChip,
  StoreCartSheet,
  StoreProductCard,
  StoreProductQuickView,
  StoreReviewsDialog,
  StoreShareDialog,
  StoreWishlistSheet,
} from "@/components/site/store-shared";

/* ------------------------------------------------------------------ */
/* ROUND 85 — lazy account sheet                                         */
/* ------------------------------------------------------------------ */

/** The signed-in account home is a SEPARATE lazy chunk
 * (store-account-sheet.tsx, split out of store-account.tsx in ROUND 85):
 * guests never download it — they are linked to the dedicated account page
 * (/sites/[id]/account) instead — and the storefront's first paint skips
 * the whole panel bundle. */

/* ------------------------------------------------------------------ */
/* constants                                                           */
/* ------------------------------------------------------------------ */

/** client-side pagination: first page + per-click increment */
const PAGE_SIZE = 12;

/** ROUND 147 — the rating-floor chips (4/3/2/1 stars & up) */
const RATING_STEPS: readonly number[] = [4, 3, 2, 1];

/** ROUND 147 — the recently-viewed list cap (ids only, newest first) */
const RECENT_CAP = 12;

/** ROUND 147 — the per-instance recently-viewed localStorage key */
const recentKey = (instanceId: string) => `ashrilogic:recentstore:${instanceId}`;

/** ROUND 147 — the recently-viewed tiny store: the wishlist's
 *  useSyncExternalStore architecture in miniature — localStorage IS the
 *  store (per-instance ids, cap 12, newest first), React just subscribes.
 *  SSR renders the stable empty list and React swaps in the client
 *  snapshot after hydration (documented uSES behavior — no markup
 *  mismatch); the native `storage` event syncs OTHER tabs and a private
 *  event syncs this one. Corrupt storage degrades to an empty list. */
const RECENT_EVENT = "ashrilogic:recentstore";
const EMPTY_RECENT: string[] = [];
let recentCacheKey = "";
let recentCacheIds: string[] = EMPTY_RECENT;

function readRecentIds(instanceId: string): string[] {
  let raw: string | null = null;
  try {
    raw = window.localStorage.getItem(recentKey(instanceId));
  } catch {
    return EMPTY_RECENT;
  }
  const key = `${instanceId}\u0000${raw ?? ""}`;
  if (key !== recentCacheKey) {
    recentCacheKey = key;
    try {
      const parsed: unknown = raw ? JSON.parse(raw) : [];
      recentCacheIds = Array.isArray(parsed)
        ? parsed
            .filter((id): id is string => typeof id === "string" && id.length > 0 && id.length <= 64)
            .slice(0, RECENT_CAP)
        : EMPTY_RECENT;
    } catch {
      recentCacheIds = EMPTY_RECENT;
    }
  }
  return recentCacheIds;
}

/** write-through mutation: localStorage first (source of truth), then the
 *  same-tab event so every subscriber re-reads immediately. */
function writeRecentIds(instanceId: string, next: string[]): void {
  try {
    window.localStorage.setItem(recentKey(instanceId), JSON.stringify(next));
  } catch {
    /* quota / private mode — keep the in-memory cache usable this session */
    recentCacheIds = next;
    recentCacheKey = `${instanceId}\u0000__volatile__`;
    window.dispatchEvent(new Event(RECENT_EVENT));
    return;
  }
  window.dispatchEvent(new Event(RECENT_EVENT));
}

/** stable server/hydration snapshot getter — NEVER mutates EMPTY_RECENT */
function getServerRecent(): string[] {
  return EMPTY_RECENT;
}

/** sort modes (client-side over the fetched page) */
type SortMode = "default" | "priceAsc" | "priceDesc";

const SORT_OPTIONS: { value: SortMode; key: I18nKey }[] = [
  { value: "default", key: "storefrontSortDefault" },
  { value: "priceAsc", key: "storefrontSortPriceAsc" },
  { value: "priceDesc", key: "storefrontSortPriceDesc" },
];

/** Radix Select forbids empty-string item values — sentinel for "all". */
const ALL_CATS = "__all__";

/** the trust-bar tiles (icon + label + one-line promise) */
const BENEFITS: { icon: string; label: I18nKey; desc: I18nKey }[] = [
  { icon: "shield-check", label: "storefrontBenefitsSecure", desc: "storefrontBenefitsSecureDesc" },
  { icon: "truck", label: "storefrontBenefitsFast", desc: "storefrontBenefitsFastDesc" },
  { icon: "refresh-cw", label: "storefrontBenefitsReturns", desc: "storefrontBenefitsReturnsDesc" },
  { icon: "headset", label: "storefrontBenefitsSupport", desc: "storefrontBenefitsSupportDesc" },
];

/* ------------------------------------------------------------------ */
/* props                                                               */
/* ------------------------------------------------------------------ */

export interface StorefrontViewProps {
  instanceId: string;
  orgName: string;
  orgTagline: string;
  systemIcon: string;
  c1: string;
  c2: string;
  logoUrl: string;
  published: boolean;
  /** ROUND 62 — store contact channel (phone · address) for the receipt footer */
  orgContact?: string;
  /** ROUND 86 — the e-store's OWN font choice (SurfaceFontKey; "" = the
   *  platform default stack). The store page resolves it from the site
   *  content so the storefront renders with its independent identity. */
  storeFont?: string;
  /** ROUND 86 — the e-store's OWN visitor languages (surfaceLangs of
   *  content.storeLangs — the header switcher obeys the owner's selection). */
  storeLangs?: string[];
}

/* ------------------------------------------------------------------ */
/* hero deal card (deals band)                                         */
/* ------------------------------------------------------------------ */

/**
 * A bigger-than-grid deal card for the horizontal "عروض اليوم" band:
 * product photo (or themed initial), struck regular + rose sale price,
 * −N% pill, live countdown chip and a DIRECT add-to-cart button.
 */
function StoreDealCard({
  product,
  currency,
  c1,
  c2,
  onAdd,
}: {
  product: SiteProductDTO;
  currency: string;
  c1: string;
  c2: string;
  onAdd: (product: SiteProductDTO, qty: number) => void;
}) {
  const { t, lang } = useT();
  const onSale = product.salePrice != null;
  const effective = onSale ? (product.salePrice as number) : product.price;
  const salePct = onSale ? Math.round((1 - effective / product.price) * 100) : 0;
  const photo = product.imageRef;

  return (
    <article
      className={cn(
        "card-in group flex w-[228px] shrink-0 snap-start flex-col overflow-hidden rounded-3xl border bg-white shadow-soft transition-all duration-300 hover:-translate-y-1 hover:border-transparent hover:shadow-lift dark:bg-white/[0.035] sm:w-[256px]",
        product.featured
          ? "border-amber-300/70 ring-1 ring-amber-400/50 dark:border-amber-400/30"
          : "border-slate-200/80 dark:border-white/10"
      )}
    >
      {photo ? (
        <div className="relative aspect-[4/3] overflow-hidden">
          <img
            src={photo}
            alt={t("storePhotoAlt", { name: product.name })}
            loading="lazy"
            decoding="async"
            className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.06]"
          />
          <span
            aria-hidden="true"
            className="pointer-events-none absolute inset-x-0 bottom-0 h-10 bg-gradient-to-t from-black/35 to-transparent"
          />
          {product.featured ? (
            <span
              title={t("storeFeaturedBadge")}
              className="absolute top-2.5 inline-flex items-center gap-1 rounded-full border border-amber-300/70 bg-gradient-to-l from-amber-400 to-orange-500 px-2 py-0.5 text-[10px] font-extrabold text-white shadow-md start-2.5"
            >
              <CatIcon name="star" className="h-[9px] w-[9px] fill-current" />
              {t("storeFeaturedBadge")}
            </span>
          ) : null}
          {onSale ? (
            <span
              title={t("storeSaleBadge", { p: nf(lang, salePct) })}
              dir="ltr"
              className="absolute top-2.5 rounded-full bg-rose-600 px-2 py-0.5 text-[10.5px] font-black text-white shadow-md end-2.5"
            >
              −{nf(lang, salePct)}%
            </span>
          ) : null}
        </div>
      ) : (
        <div
          className="relative grid aspect-[4/3] w-full place-items-center"
          style={{
            backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.16)}, ${hexAlpha(c2, 0.16)})`,
          }}
          aria-hidden="true"
        >
          <span className="font-display text-[44px] font-black" style={{ color: c1 }}>
            {product.name.trim().charAt(0)}
          </span>
          {product.featured ? (
            <span
              title={t("storeFeaturedBadge")}
              className="absolute top-2.5 inline-flex items-center gap-1 rounded-full border border-amber-300/70 bg-gradient-to-l from-amber-400 to-orange-500 px-2 py-0.5 text-[10px] font-extrabold text-white shadow-md start-2.5"
            >
              <CatIcon name="star" className="h-[9px] w-[9px] fill-current" />
              {t("storeFeaturedBadge")}
            </span>
          ) : null}
          {onSale ? (
            <span
              title={t("storeSaleBadge", { p: nf(lang, salePct) })}
              dir="ltr"
              className="absolute top-2.5 rounded-full bg-rose-600 px-2 py-0.5 text-[10.5px] font-black text-white shadow-md end-2.5"
            >
              −{nf(lang, salePct)}%
            </span>
          ) : null}
        </div>
      )}

      <div className="flex flex-1 flex-col p-4">
        {product.category ? (
          <span
            className="mb-1 inline-flex w-fit min-w-0 items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-extrabold"
            style={{ borderColor: hexAlpha(c1, 0.3), backgroundColor: hexAlpha(c1, 0.07), color: c1 }}
            title={product.category}
          >
            <CatIcon name="tag" className="h-[8px] w-[8px] shrink-0" />
            <span className="max-w-28 truncate">{product.category}</span>
          </span>
        ) : null}
        <h3
          className="line-clamp-1 font-display text-[14px] font-extrabold text-slate-900 dark:text-white"
          title={product.name}
        >
          {product.name}
        </h3>
        {onSale ? (
          <div dir="ltr" className="mt-1.5 flex items-end gap-2">
            <span className="text-start font-display text-[13px] font-bold tabular-nums text-slate-400 line-through dark:text-slate-500">
              {fmtPrice(lang, product.price, currency)}
            </span>
            <span className="text-start font-display text-[22px] font-black tabular-nums text-rose-600 dark:text-rose-400">
              {fmtPrice(lang, effective, currency)}
            </span>
          </div>
        ) : (
          <p
            dir="ltr"
            className="mt-1.5 text-start font-display text-[21px] font-black tabular-nums"
            style={{ color: c1 }}
          >
            {fmtPrice(lang, product.price, currency)}
          </p>
        )}
        {onSale && product.saleEndsAt ? (
          <SaleCountdownChip endsAt={product.saleEndsAt} />
        ) : null}
        <div className="mt-auto pt-3.5">
          <Button
            type="button"
            onClick={() => onAdd(product, 1)}
            className="h-10 w-full gap-1.5 rounded-xl text-[12px] font-bold text-white shadow-lg transition hover:brightness-110 active:scale-95"
            style={{
              backgroundImage: grad(c1, c2),
              boxShadow: `0 10px 22px -10px ${hexAlpha(c1, 0.75)}`,
            }}
          >
            <CatIcon name="shopping-cart" className="h-4 w-4" />
            {t("storeAdd")}
          </Button>
        </div>
      </div>
    </article>
  );
}

/* ------------------------------------------------------------------ */
/* ROUND 147 — the compact recently-viewed card                        */
/* ------------------------------------------------------------------ */

/**
 * One compact recently-viewed rail card: product photo (or themed initial),
 * the name (opens the quick view — the same handler the grid cards use, so
 * opening it RE-RECORDS the product at the list's front), the effective
 * price with a struck regular when a sale is live, and a direct
 * add-to-cart. Deliberately NOT StoreProductCard (which stays untouched):
 * this is a slim row-card vocabulary sized for the horizontal rail.
 */
function StoreRecentCard({
  product,
  currency,
  c1,
  c2,
  onAdd,
  onOpen,
  staggerIndex,
}: {
  product: SiteProductDTO;
  currency: string;
  c1: string;
  c2: string;
  onAdd: (product: SiteProductDTO, qty: number) => void;
  onOpen: () => void;
  staggerIndex?: number;
}) {
  const { t, lang } = useT();
  const onSale = product.salePrice != null;
  const effective = onSale ? (product.salePrice as number) : product.price;
  const photo = product.imageRef;

  return (
    <article
      className="card-in group flex w-[148px] shrink-0 snap-start flex-col overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-soft transition-all duration-300 hover:-translate-y-1 hover:border-transparent hover:shadow-lift sm:w-[164px] dark:border-white/10 dark:bg-white/[0.035]"
      style={staggerIndex != null ? ({ "--i": staggerIndex } as React.CSSProperties) : undefined}
    >
      {/* photo (or themed initial) — clicking peeks the quick view */}
      {photo ? (
        <button
          type="button"
          onClick={onOpen}
          aria-label={t("storeQuickViewAria", { name: product.name })}
          title={t("storeQuickViewAria", { name: product.name })}
          className="relative block aspect-[4/3] w-full overflow-hidden"
        >
          <img
            src={photo}
            alt={t("storePhotoAlt", { name: product.name })}
            loading="lazy"
            decoding="async"
            className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.06]"
          />
        </button>
      ) : (
        <button
          type="button"
          onClick={onOpen}
          aria-label={t("storeQuickViewAria", { name: product.name })}
          title={t("storeQuickViewAria", { name: product.name })}
          className="grid aspect-[4/3] w-full place-items-center"
          style={{
            backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.16)}, ${hexAlpha(c2, 0.16)})`,
          }}
        >
          <span className="font-display text-[32px] font-black" style={{ color: c1 }}>
            {product.name.trim().charAt(0) || "؟"}
          </span>
        </button>
      )}

      <div className="flex flex-1 flex-col p-3">
        <h3
          className="line-clamp-2 min-h-9 text-[12px] font-extrabold leading-snug text-slate-900 dark:text-white"
          title={product.name}
        >
          <button
            type="button"
            onClick={onOpen}
            className="text-start decoration-2 underline-offset-4 transition hover:underline"
          >
            {product.name}
          </button>
        </h3>
        <p
          dir="ltr"
          className="mt-1 text-start font-display text-[14px] font-black tabular-nums"
          style={{ color: c1 }}
        >
          {onSale ? (
            <>
              <span className="me-1.5 text-[10.5px] font-bold text-slate-400 line-through dark:text-slate-500">
                {fmtPrice(lang, product.price, currency)}
              </span>
              {fmtPrice(lang, effective, currency)}
            </>
          ) : (
            fmtPrice(lang, product.price, currency)
          )}
        </p>
        <div className="mt-auto pt-2.5">
          <Button
            type="button"
            onClick={() => onAdd(product, 1)}
            className="h-9 w-full gap-1.5 rounded-xl text-[11px] font-bold text-white shadow-md transition hover:brightness-110 active:scale-95"
            style={{ backgroundImage: grad(c1, c2) }}
          >
            <CatIcon name="shopping-cart" className="h-3.5 w-3.5" />
            {t("storeAdd")}
          </Button>
        </div>
      </div>
    </article>
  );
}

/* ------------------------------------------------------------------ */
/* the storefront view                                                 */
/* ------------------------------------------------------------------ */

export function StorefrontView({
  instanceId,
  orgName,
  orgTagline,
  systemIcon,
  c1,
  c2,
  logoUrl,
  published,
  orgContact,
  storeFont,
  storeLangs,
}: StorefrontViewProps) {
  const { t, lang } = useT();
  const { resolvedTheme, setTheme } = useTheme();
  const router = useRouter();
  const ar = lang === "ar";
  const siteHref = `/sites/${instanceId}`;

  /* ---------------- state ---------------- */
  const [searchInput, setSearchInput] = useState("");
  const [debouncedQ, setDebouncedQ] = useState("");
  const [category, setCategory] = useState("");
  /* ROUND 54 quick filters, promoted to the storefront's nav strip (and
   * ROUND 147: mirrored inside the new filter rail — same state, ONE
   * source of truth; the strip toggles stay as they were) */
  const [onlyFeatured, setOnlyFeatured] = useState(false);
  const [onlySale, setOnlySale] = useState(false);
  const [sortMode, setSortMode] = useState<SortMode>("default");
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);

  /* ROUND 147 — client-side facets over the fetched page's products:
   * price bounds (raw strings, parsed + validated below), a rating floor
   * and an in-stock-only toggle — all applied AFTER the server's
   * search/category pass, zero new queries. */
  const [priceMin, setPriceMin] = useState("");
  const [priceMax, setPriceMax] = useState("");
  const [ratingMin, setRatingMin] = useState(0);
  const [onlyInStock, setOnlyInStock] = useState(false);

  /* ROUND 147 — the mobile filter Sheet + the departments panels (the
   * desktop departments ride a Popover; the mobile twin is a bottom
   * Sheet — SEPARATE open states so one host can never force the other
   * open across a breakpoint switch/rotation) */
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [departmentsOpen, setDepartmentsOpen] = useState(false);
  const [departmentsSheetOpen, setDepartmentsSheetOpen] = useState(false);

  /* cart — ROUND 147: persisted per instance in localStorage through the
   * use-store-cart hook (mirrors the wishlist's useSyncExternalStore
   * architecture: cross-tab, hydration-safe, capped at 60 lines). The
   * round-55 "transient cart lost on reload" gap is closed; the line shape
   * is the same StoreCartItem, now carrying the chosen variant label. */
  const cart = useStoreCart(instanceId);
  const [cartOpen, setCartOpen] = useState(false);

  /* ROUND 60 — scroll-aware sticky header: a soft layered shadow once the
   * page scrolls (the classic premium detail — the blurred header gains
   * depth exactly when it starts floating over content). Mount-time scroll
   * position is irrelevant (fresh loads are at the top). */
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  /* ROUND 58 — the guest wishlist: localStorage-backed, per-instance,
   * cross-tab synced. The FAB + sheet live beside the cart. */
  const wishlist = useWishlist(instanceId);
  const [wishlistOpen, setWishlistOpen] = useState(false);

  /* ROUND 60 — the share dialog (QR + copy link). Only offered on
   * PUBLISHED stores — sharing a draft preview link is pointless. */
  const [shareOpen, setShareOpen] = useState(false);

  /* ROUND 65/85 — the customer account surface: the auth DIALOG is gone
   * (guests LINK to the dedicated account page from the header button);
   * only the signed-in account sheet still mounts here — lazily. */

  /* ROUND 61 — the product quick view (Amazon-style detail peek); the
   * dialog stays mounted and swaps its product, so qty/photo state resets
   * per product inside the component (previous-value pattern). */
  const [quickView, setQuickView] = useState<SiteProductDTO | null>(null);

  /* ROUND 63 — the product reviews & ratings dialog; `reviewsProduct`
   * doubles as both the open flag AND the current product (closing clears
   * it — the dialog's own state resets per product inside itself). */
  const [reviewsProduct, setReviewsProduct] = useState<SiteProductDTO | null>(null);

  /* ROUND 59 — springy FAB badge pop: whenever the wishlist count
   * INCREASES, the little count badge replays the 0.5s badge-pop keyframe
   * (pure CSS, reduced-motion safe). Growth is detected DURING render via
   * React's documented previous-value pattern (react-hooks v7 gates
   * setState-in-effect as an error); only the auto-clear timer lives in an
   * effect, with its timeout cleaned up on every re-run — leak-free. The
   * badge mounting at 0→1 (or after hydration restores saved items) pops
   * too — a nice "you have saved items" cue. */
  const [badgePop, setBadgePop] = useState(false);
  const [prevWishCount, setPrevWishCount] = useState(wishlist.count);
  if (wishlist.count !== prevWishCount) {
    if (wishlist.count > prevWishCount) setBadgePop(true);
    setPrevWishCount(wishlist.count);
  }
  useEffect(() => {
    if (!badgePop) return;
    const id = window.setTimeout(() => setBadgePop(false), 500);
    return () => window.clearTimeout(id);
  }, [badgePop]);

  /* debounced server-side search (300ms) — same pattern as the old section */
  useEffect(() => {
    const id = window.setTimeout(() => setDebouncedQ(searchInput.trim()), 300);
    return () => window.clearTimeout(id);
  }, [searchInput]);

  /* ROUND 147 — URL-synced state: q + category ride the address bar via
   * history.replaceState (no navigation, no re-render). Initialization
   * reads window.location.search ONCE on mount. Effects run in declaration
   * order, so the hydration effect below flips the guard BEFORE the sync
   * effect's first pass; the sync effect also skips its own mount pass
   * (urlSyncedOnce) so a shared link like ?q=…&category=… is never
   * transiently wiped from the address bar. */
  const urlHydratedRef = useRef(false);
  const urlSyncedOnceRef = useRef(false);
  useEffect(() => {
    /* eslint-disable react-hooks/set-state-in-effect -- ROUND 147: one-shot
     * URL truth at mount (shared ?q=&category= links land pre-filtered) —
     * the state flips ONCE and never again, so the cascading-render hazard
     * this rule guards against cannot occur; deriving in render instead
     * would mismatch SSR hydration (the admin-login ROUND 117 precedent,
     * same justification shape). */
    try {
      const params = new URLSearchParams(window.location.search);
      const q = (params.get("q") ?? "").slice(0, 80).trim();
      const cat = (params.get("category") ?? "").slice(0, 120);
      if (q) {
        setSearchInput(q);
        setDebouncedQ(q);
      }
      if (cat) setCategory(cat);
    } catch {
      /* location unavailable — state simply stays empty */
    }
    /* eslint-enable react-hooks/set-state-in-effect */
    urlHydratedRef.current = true;
  }, []);
  useEffect(() => {
    if (!urlHydratedRef.current) return;
    if (!urlSyncedOnceRef.current) {
      /* the mount pass IS the hydrated URL — nothing to reflect yet */
      urlSyncedOnceRef.current = true;
      return;
    }
    try {
      const params = new URLSearchParams();
      if (debouncedQ) params.set("q", debouncedQ);
      if (category) params.set("category", category);
      const qs = params.toString();
      window.history.replaceState(
        null,
        "",
        qs ? `${window.location.pathname}?${qs}` : window.location.pathname
      );
    } catch {
      /* history unavailable (embedded webview) — state is unaffected */
    }
  }, [debouncedQ, category]);

  /* ROUND 147 — recently viewed: the tiny uSES store above (the wishlist's
   * architecture — no load-in-effect setState at all). Recording is a pure
   * write-through: dedupe move-to-front, cap 12, fired from the quick-view
   * open handler. */
  const recentSubscribe = useCallback(
    (onStoreChange: () => void) => {
      const onStorage = (e: StorageEvent) => {
        if (e.key === recentKey(instanceId)) onStoreChange();
      };
      window.addEventListener("storage", onStorage);
      window.addEventListener(RECENT_EVENT, onStoreChange);
      return () => {
        window.removeEventListener("storage", onStorage);
        window.removeEventListener(RECENT_EVENT, onStoreChange);
      };
    },
    [instanceId]
  );
  const recentGetSnapshot = useCallback(() => readRecentIds(instanceId), [instanceId]);
  const recentIds = useSyncExternalStore(recentSubscribe, recentGetSnapshot, getServerRecent);
  const recordRecent = (recordId: string) => {
    writeRecentIds(
      instanceId,
      [recordId, ...readRecentIds(instanceId).filter((id) => id !== recordId)].slice(0, RECENT_CAP)
    );
  };

  /* ---------------- data ----------------
   * ONE query over the EXISTING public store API (search + category run
   * server-side). Same key pattern as the old embedded section, so a
   * website→store hand-off shares the ["site-store", id, "", ""] cache. */
  const storeQuery = useQuery({
    queryKey: ["site-store", instanceId, debouncedQ, category],
    queryFn: () =>
      fetchSiteStore(instanceId, {
        q: debouncedQ || undefined,
        category: category || undefined,
      }),
    staleTime: 30_000,
    retry: 0,
  });

  /* products memoized once so the derived pools below get a stable
   * dependency (the raw `?? []` fallback would churn identities) */
  const products = useMemo(() => storeQuery.data?.products ?? [], [storeQuery.data]);
  const categories = storeQuery.data?.categories ?? [];
  const categoryCounts = storeQuery.data?.categoryCounts ?? {};
  const currency = storeQuery.data?.currency ?? "SAR";

  /* quick-filter pools (counts over the CURRENT server-filtered page) */
  const featuredCount = useMemo(() => products.filter((p) => p.featured).length, [products]);
  const saleCount = useMemo(() => products.filter((p) => p.salePrice != null).length, [products]);

  /* deals band pool — featured OR on-sale items (server already sorts
   * featured-first, so the row leads with the merchant's picks) */
  const dealProducts = useMemo(
    () => products.filter((p) => p.featured || p.salePrice != null),
    [products]
  );

  /* the visible list: quick filters + ROUND 147 facets + client-side sort.
   * "الأكثر رواجاً" keeps the server order (featured-first, stable); price
   * sorts use the EFFECTIVE price (sale ?? regular) — what the cart
   * actually charges. */
  const effectiveOf = (p: SiteProductDTO) => (p.salePrice != null ? p.salePrice : p.price);

  /* ROUND 147 — price-bound validation: raw strings parse to floors/
   * ceils (display units, applied on the EFFECTIVE price); empty or
   * non-numeric or negative bounds are skipped, and an inverted pair
   * (floor > ceil) marks the inputs invalid (aria-invalid + rose ring via
   * the Input's aria-invalid styles) and applies NEITHER bound — honest,
   * never silently "fixing" what the visitor typed. */
  const priceMinNum = Number.parseFloat(priceMin);
  const priceMaxNum = Number.parseFloat(priceMax);
  const priceMinOk = priceMin === "" || (Number.isFinite(priceMinNum) && priceMinNum >= 0);
  const priceMaxOk = priceMax === "" || (Number.isFinite(priceMaxNum) && priceMaxNum >= 0);
  const priceBoundsOk =
    priceMinOk &&
    priceMaxOk &&
    !(priceMin !== "" && priceMax !== "" && priceMinNum > priceMaxNum);
  const priceFloor = priceBoundsOk && priceMin !== "" ? priceMinNum : null;
  const priceCeil = priceBoundsOk && priceMax !== "" ? priceMaxNum : null;

  const visibleProducts = useMemo(() => {
    const filtered = products.filter(
      (p) =>
        (!onlyFeatured || p.featured) &&
        (!onlySale || p.salePrice != null) &&
        (!onlyInStock || (p.stock > 0 && p.statusKey !== "out")) &&
        (ratingMin === 0 || (p.ratingAvg ?? 0) >= ratingMin) &&
        (priceFloor == null || effectiveOf(p) >= priceFloor) &&
        (priceCeil == null || effectiveOf(p) <= priceCeil)
    );
    if (sortMode === "default") return filtered;
    const sorted = [...filtered];
    sorted.sort((a, b) =>
      sortMode === "priceAsc" ? effectiveOf(a) - effectiveOf(b) : effectiveOf(b) - effectiveOf(a)
    );
    return sorted;
  }, [products, onlyFeatured, onlySale, onlyInStock, ratingMin, priceFloor, priceCeil, sortMode]);

  /* ROUND 147 — the client-facet summary: any facet active at all? and the
   * one-tap reset for every client-side filter (quick toggles included) */
  const hasClientFilters =
    onlyFeatured ||
    onlySale ||
    onlyInStock ||
    ratingMin > 0 ||
    priceFloor != null ||
    priceCeil != null;
  const clientFilterCount =
    (onlyFeatured ? 1 : 0) +
    (onlySale ? 1 : 0) +
    (onlyInStock ? 1 : 0) +
    (ratingMin > 0 ? 1 : 0) +
    (priceFloor != null ? 1 : 0) +
    (priceCeil != null ? 1 : 0);
  const clearClientFilters = () => {
    setOnlyFeatured(false);
    setOnlySale(false);
    setOnlyInStock(false);
    setRatingMin(0);
    setPriceMin("");
    setPriceMax("");
    setVisibleCount(PAGE_SIZE);
  };

  /* client-side load-more pagination */
  const pageItems = visibleProducts.slice(0, visibleCount);
  const remaining = Math.max(0, visibleProducts.length - pageItems.length);

  /* active filter chips for the results toolbar */
  const activeFilters: {
    key: string;
    icon: string;
    label: string;
    clear: () => void;
    tone: "brand" | "amber" | "rose";
  }[] = [];
  if (debouncedQ) {
    activeFilters.push({
      key: "q",
      icon: "search",
      label: `«${debouncedQ}»`,
      clear: () => {
        setSearchInput("");
        setDebouncedQ("");
        setVisibleCount(PAGE_SIZE);
      },
      tone: "brand",
    });
  }
  if (category) {
    activeFilters.push({
      key: "cat",
      icon: "tag",
      label: category,
      clear: () => {
        setCategory("");
        setVisibleCount(PAGE_SIZE);
      },
      tone: "brand",
    });
  }
  if (onlyFeatured) {
    activeFilters.push({
      key: "featured",
      icon: "star",
      label: t("storeFilterFeatured"),
      clear: () => {
        setOnlyFeatured(false);
        setVisibleCount(PAGE_SIZE);
      },
      tone: "amber",
    });
  }
  if (onlySale) {
    activeFilters.push({
      key: "sale",
      icon: "ticket-percent",
      label: t("storeFilterOnSale"),
      clear: () => {
        setOnlySale(false);
        setVisibleCount(PAGE_SIZE);
      },
      tone: "rose",
    });
  }
  /* ROUND 147 — the client-facet SUMMARY chip (price/rating/stock/quick):
   * one tap clears every client-side filter at once */
  if (hasClientFilters) {
    activeFilters.push({
      key: "filters",
      icon: "sliders",
      label: `${t("storeFiltersActive")} (${nf(lang, clientFilterCount)})`,
      clear: clearClientFilters,
      tone: "brand",
    });
  }

  /* ---------------- cart handlers (ROUND 147 — persisted via use-store-cart) ---------------- */

  /** The charged unit price: the chosen VARIANT's override when the quick
   *  view's picker was used (round 141), else the EFFECTIVE price (active
   *  sale — round 52); the server re-derives the same value at placement.
   *  The variant's own stock carve-out caps the line when present. */
  const addToCart = (product: SiteProductDTO, qty: number, variantLabel?: string) => {
    const variant =
      variantLabel != null
        ? product.variants.find((v) => v.name === variantLabel)
        : undefined;
    const max = Math.min(99, Math.max(1, Math.floor(variant?.stock ?? product.stock) || 1));
    const unitPrice =
      variant?.price != null
        ? variant.price
        : product.salePrice != null
          ? product.salePrice
          : product.price;
    cart.add({
      recordId: product.recordId,
      name: product.name,
      price: unitPrice,
      qty: Math.min(max, qty),
      max,
      imageRef: product.imageRef,
      ...(variantLabel != null ? { variant: variantLabel } : {}),
    });
    toast.success(t("storeAdded", { name: product.name }));
  };
  const cartCount = cart.count;

  /* ---------------- ROUND 58 — wishlist wiring ---------------- */

  /* toggle from any product card (snapshot the CURRENT catalog truth so the
   * sheet always opens with fresh-looking data even before any merge) */
  const toggleWishlist = (product: SiteProductDTO) => {
    const saved = wishlist.toggle({
      recordId: product.recordId,
      name: product.name,
      price: product.price,
      salePrice: product.salePrice ?? null,
      currency,
      category: product.category,
      imageRef: product.imageRef,
      addedAt: new Date().toISOString(),
    });
    toast.success(saved ? t("wishlistAdded", { name: product.name }) : t("wishlistRemoved", { name: product.name }));
  };

  /* the sheet's rows: FRESH catalog data wins by recordId; snapshot-only
   * rows (added under a filter that hides them now) keep their saved price
   * with an OPTIMISTIC stock cap — the server re-verifies at placement. */
  const wishlistProducts = useMemo(() => {
    const byId = new Map(products.map((p) => [p.recordId, p]));
    return wishlist.items
      .map((item) => {
        const fresh = byId.get(item.recordId);
        if (fresh) return { ...fresh, addedAt: item.addedAt };
        return {
          recordId: item.recordId,
          name: item.name,
          category: item.category,
          price: item.price,
          stock: 99,
          statusKey: "",
          imageRef: item.imageRef,
          /* ROUND 140 — snapshot-only rows carry no gallery/videos (the
           * fresh catalog row merges above when the product is still live). */
          gallery: [],
          videos: [],
          storeVisible: true,
          /* ROUND 141 — snapshot-only rows carry no variants (the fresh
           * catalog row merges above when the product is still live). */
          variants: [],
          featured: false,
          salePrice: item.salePrice,
          saleEndsAt: null,
          /* ROUND 63 — the new DTO aggregate fields (snapshot-only rows
           * carry no rating data; fresh catalog rows merge above) */
          ratingAvg: null,
          ratingCount: 0,
          addedAt: item.addedAt,
        } satisfies SiteProductDTO & { addedAt: string };
      })
      .sort((a, b) => (a.addedAt < b.addedAt ? 1 : -1));
  }, [wishlist.items, products]);

  /* add a wishlist row straight into the cart (qty 1, effective price) */
  const addWishlistItemToCart = (product: SiteProductDTO) => {
    addToCart(product, 1);
  };

  /* ---------------- ROUND 147 — quick view + recently viewed wiring ---------------- */

  /** ROUND 156 — openQuickView now NAVIGATES to the SSR product detail page
   *  instead of opening the popup (the user's directive: «لا تجعل المنتجات
   *  تظهر كـPopup بل اجعل لكل منتج صفحة بطريقة احترافية وPremium»). The
   *  recently-viewed rail still records the visit; the StoreProductQuickView
   *  dialog state is kept declared so its bare shell renders identically
   *  (never opens from the grid now). The dedicated page lives at
   *  /sites/[id]/store/products/[recordId] and carries the Schema.org
   *  Product JSON-LD. */
  const openQuickView = (product: SiteProductDTO) => {
    recordRecent(product.recordId);
    router.push(`/sites/${instanceId}/store/products/${encodeURIComponent(product.recordId)}`);
  };

  /* same-category siblings for the quick view's related rows (≤6, the
   * current product excluded) — drawn from the SAME fetched catalog, so a
   * narrowed search honestly narrows the related set (zero new queries) */
  const quickViewRelated = useMemo(() => {
    if (quickView == null || !quickView.category) return [];
    return products
      .filter((p) => p.recordId !== quickView.recordId && p.category === quickView.category)
      .slice(0, 6);
  }, [quickView, products]);

  /* the recently-viewed rail rows: LIVE catalog data wins by recordId;
   * ids the live catalog no longer carries drop out entirely (the rail
   * never renders a product the merchant removed) */
  const recentProducts = useMemo(() => {
    if (recentIds.length === 0) return [];
    const byId = new Map(products.map((p) => [p.recordId, p]));
    return recentIds.map((id) => byId.get(id)).filter((p): p is SiteProductDTO => p != null);
  }, [recentIds, products]);

  /* ---------------- shared chrome ---------------- */

  /* language-aware tab title (follows the AR/EN toggle instantly) */
  useDocumentTitle("storefrontDocTitle", { org: orgName });

  /* ROUND 67 — the org identity becomes the browser-tab favicon while
     the store is open, server-composed as a PREMIUM CIRCULAR badge (same
     circular route as the website view and the dashboard); the logo ref
     doubles as a cache-buster. */
  useBrandFavicon(instanceId, logoUrl || undefined);

  /* the search bar — ONE element rendered in the desktop row AND in the
     mobile row below it (identical behavior, CSS decides placement) */
  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setDebouncedQ(searchInput.trim());
    setVisibleCount(PAGE_SIZE);
  };

  const searchBar = (
    <form
      role="search"
      onSubmit={submitSearch}
      className="flex h-11 w-full items-stretch overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm outline-none transition focus-within:border-transparent focus-within:shadow-lg focus-within:shadow-brand-500/15 focus-within:ring-4 focus-within:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:focus-within:bg-white/[0.07]"
    >
      {/* Amazon-style department select BEFORE the input (desktop widths) */}
      <div className="hidden shrink-0 sm:block">
        <Select
          value={category || ALL_CATS}
          onValueChange={(v) => {
            setCategory(v === ALL_CATS ? "" : v);
            setVisibleCount(PAGE_SIZE);
          }}
        >
          <SelectTrigger
            aria-label={t("storefrontSearchCat")}
            /* ROUND 88 — suppressHydrationWarning: Radix's aria-controls is
               driven by React's useId, which Next 16's dev runtime can
               recompute differently across Turbopack HMR re-hydration passes
               (a known React/Next dev artifact, NOT an app defect — live E2E
               proves the ids match on every cold load). Suppression is
               attribute-scoped to this trigger only: the tree stays honest,
               the console stays clean for the owner. */
            suppressHydrationWarning
            className="h-full w-36 rounded-none rounded-s-2xl border-0 border-e border-slate-200 bg-slate-50/80 px-3 text-[11.5px] font-extrabold text-slate-600 shadow-none hover:bg-slate-100/80 dark:border-white/10 dark:bg-white/[0.06] dark:text-slate-300 dark:hover:bg-white/[0.09] md:w-44"
          >
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL_CATS}>{t("storefrontSearchCat")}</SelectItem>
            {categories.map((cat) => (
              <SelectItem key={cat} value={cat}>
                {cat}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* the query input */}
      <div className="relative min-w-0 flex-1">
        <CatIcon
          name="search"
          className="pointer-events-none absolute start-3.5 top-1/2 h-[13px] w-[13px] -translate-y-1/2 text-slate-400"
        />
        <input
          type="search"
          value={searchInput}
          onChange={(e) => setSearchInput(e.target.value)}
          placeholder={t("storeSearchPh")}
          aria-label={t("storeSearchPh")}
          maxLength={80}
          className="h-11 w-full bg-transparent ps-11 pe-9 text-[13px] font-semibold text-slate-800 outline-none placeholder:font-normal placeholder:text-slate-400 dark:text-slate-100 dark:placeholder:text-slate-500"
        />
        {searchInput ? (
          <button
            type="button"
            onClick={() => {
              setSearchInput("");
              setDebouncedQ("");
              setVisibleCount(PAGE_SIZE);
            }}
            aria-label={t("storeSearchPh")}
            title={t("storeSearchPh")}
            className="absolute end-3 top-1/2 grid h-7 w-7 -translate-y-1/2 place-items-center rounded-full text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-white/10 dark:hover:text-slate-300"
          >
            <CatIcon name="x" className="h-3.5 w-3.5" />
          </button>
        ) : null}
      </div>

      {/* the submit — a full-height brand-gradient magnifier */}
      <button
        type="submit"
        aria-label={t("storeSearchPh")}
        className="grid w-12 shrink-0 place-items-center text-white shadow-lg transition hover:brightness-110 active:scale-95 sm:w-14"
        style={{ backgroundImage: grad(c1, c2) }}
      >
        <CatIcon name="search" className="h-[17px] w-[17px]" />
      </button>
    </form>
  );

  /* ---------------- ROUND 147 — the filter rail (desktop aside + mobile Sheet twin) ----------------
   * One JSX body, TWO hosts: the sticky desktop rail beside the product
   * grid (hidden lg:block) and the mobile Sheet opened from the results
   * toolbar. All state lives HERE in the storefront (no local state inside
   * the rail), so both hosts stay perfectly in sync by construction.
   * The round-54 quick toggles integrate verbatim (same state as the nav
   * strip chips) — one source of truth. */
  const filterRailContent = (
    <div className="space-y-5">
      {/* rail header — title + the clear-all reset */}
      <div className="flex items-center justify-between gap-2">
        <p className="flex items-center gap-2.5 font-display text-[14px] font-extrabold text-slate-900 dark:text-white">
          <span
            className="grid h-8 w-8 shrink-0 place-items-center rounded-xl text-white shadow-md"
            style={{ backgroundImage: grad(c1, c2) }}
          >
            <CatIcon name="sliders" className="h-4 w-4" />
          </span>
          {t("storeFilters")}
        </p>
        {hasClientFilters ? (
          <button
            type="button"
            onClick={clearClientFilters}
            className="inline-flex h-8 shrink-0 items-center gap-1 rounded-full border border-slate-200 bg-white px-2.5 text-[10.5px] font-bold text-slate-400 transition hover:border-slate-300 hover:text-slate-600 active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-500 dark:hover:text-slate-300"
          >
            <CatIcon name="x" className="h-3 w-3" />
            {t("storeFiltersClear")}
          </button>
        ) : null}
      </div>

      {/* quick toggles — the round-54 pair, integrated into the rail */}
      <fieldset className="space-y-2">
        <legend className="sr-only">{t("storeFilters")}</legend>
        {featuredCount > 0 && !storeQuery.isPending ? (
          <button
            type="button"
            onClick={() => {
              setOnlyFeatured((v) => !v);
              setVisibleCount(PAGE_SIZE);
            }}
            aria-pressed={onlyFeatured}
            title={t("storeFilterFeaturedTitle", { n: nf(lang, featuredCount) })}
            className={cn(
              "flex min-h-11 w-full items-center justify-between gap-2 rounded-xl border px-3 py-2 text-[12px] font-extrabold transition active:scale-[0.98]",
              onlyFeatured
                ? "border-amber-300 bg-amber-500/15 text-amber-700 shadow-sm shadow-amber-500/20 dark:border-amber-500/40 dark:text-amber-300"
                : "border-amber-200/70 bg-amber-50/60 text-amber-600/90 hover:border-amber-300 dark:border-amber-500/25 dark:bg-amber-500/10 dark:text-amber-300/80 dark:hover:bg-amber-500/15"
            )}
          >
            <span className="flex min-w-0 items-center gap-2">
              <CatIcon
                name="star"
                className={cn(
                  "h-4 w-4 shrink-0",
                  onlyFeatured && "fill-amber-400 text-amber-500 dark:fill-amber-400/80"
                )}
              />
              <span className="truncate">{t("storeFilterFeatured")}</span>
            </span>
            <span
              dir="ltr"
              className={cn(
                "shrink-0 rounded-full px-1.5 text-[10px] font-black tabular-nums",
                onlyFeatured
                  ? "bg-amber-500/20 text-amber-800 dark:bg-amber-500/25 dark:text-amber-200"
                  : "bg-amber-500/15 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300"
              )}
            >
              {nf(lang, featuredCount)}
            </span>
          </button>
        ) : null}
        {saleCount > 0 && !storeQuery.isPending ? (
          <button
            type="button"
            onClick={() => {
              setOnlySale((v) => !v);
              setVisibleCount(PAGE_SIZE);
            }}
            aria-pressed={onlySale}
            title={t("storeFilterSaleTitle", { n: nf(lang, saleCount) })}
            className={cn(
              "flex min-h-11 w-full items-center justify-between gap-2 rounded-xl border px-3 py-2 text-[12px] font-extrabold transition active:scale-[0.98]",
              onlySale
                ? "border-rose-300 bg-rose-500/15 text-rose-700 shadow-sm shadow-rose-500/20 dark:border-rose-500/40 dark:text-rose-300"
                : "border-rose-200/70 bg-rose-50/60 text-rose-600/90 hover:border-rose-300 dark:border-rose-500/25 dark:bg-rose-500/10 dark:text-rose-300/80 dark:hover:bg-rose-500/15"
            )}
          >
            <span className="flex min-w-0 items-center gap-2">
              <CatIcon name="ticket-percent" className="h-4 w-4 shrink-0" />
              <span className="truncate">{t("storeFilterOnSale")}</span>
            </span>
            <span
              dir="ltr"
              className={cn(
                "shrink-0 rounded-full px-1.5 text-[10px] font-black tabular-nums",
                onlySale
                  ? "bg-rose-500/20 text-rose-800 dark:bg-rose-500/25 dark:text-rose-200"
                  : "bg-rose-500/15 text-rose-700 dark:bg-rose-500/20 dark:text-rose-300"
              )}
            >
              {nf(lang, saleCount)}
            </span>
          </button>
        ) : null}
      </fieldset>

      {/* price range — two numeric bounds on the EFFECTIVE price; the ≥ / ≤
       * glyphs are language-neutral adornments; an inverted pair marks the
       * inputs invalid (aria-invalid) and applies neither bound */}
      <fieldset className="space-y-2">
        <legend className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
          {t("storeFiltersPrice")}
        </legend>
        <div className="flex items-center gap-2">
          <div className="relative min-w-0 flex-1">
            <span
              aria-hidden="true"
              className="pointer-events-none absolute start-2.5 top-1/2 -translate-y-1/2 text-[12px] font-black text-slate-400 dark:text-slate-500"
            >
              ≥
            </span>
            <Input
              type="number"
              inputMode="decimal"
              min={0}
              step="any"
              value={priceMin}
              onChange={(e) => {
                setPriceMin(e.target.value);
                setVisibleCount(PAGE_SIZE);
              }}
              aria-label={`${t("storeFiltersPrice")} ≥`}
              aria-invalid={!priceBoundsOk || !priceMinOk ? true : undefined}
              className="h-9 rounded-xl bg-white ps-6 text-[12.5px] font-bold tabular-nums dark:bg-white/[0.04]"
            />
          </div>
          <span
            aria-hidden="true"
            className="shrink-0 text-[11px] font-black text-slate-300 dark:text-slate-600"
          >
            —
          </span>
          <div className="relative min-w-0 flex-1">
            <span
              aria-hidden="true"
              className="pointer-events-none absolute start-2.5 top-1/2 -translate-y-1/2 text-[12px] font-black text-slate-400 dark:text-slate-500"
            >
              ≤
            </span>
            <Input
              type="number"
              inputMode="decimal"
              min={0}
              step="any"
              value={priceMax}
              onChange={(e) => {
                setPriceMax(e.target.value);
                setVisibleCount(PAGE_SIZE);
              }}
              aria-label={`${t("storeFiltersPrice")} ≤`}
              aria-invalid={!priceBoundsOk || !priceMaxOk ? true : undefined}
              className="h-9 rounded-xl bg-white ps-6 text-[12.5px] font-bold tabular-nums dark:bg-white/[0.04]"
            />
          </div>
        </div>
      </fieldset>

      {/* rating floor — 4/3/2/1 chips; tapping the active chip lifts it */}
      <fieldset className="space-y-2">
        <legend className="text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
          {t("storeFiltersRating")}
        </legend>
        <div className="flex flex-wrap gap-1.5">
          {RATING_STEPS.map((n) => {
            const active = ratingMin === n;
            return (
              <button
                key={n}
                type="button"
                onClick={() => {
                  setRatingMin(active ? 0 : n);
                  setVisibleCount(PAGE_SIZE);
                }}
                aria-pressed={active}
                className={cn(
                  "inline-flex h-9 items-center gap-1.5 rounded-full border px-3 text-[11px] font-extrabold transition active:scale-95",
                  active
                    ? "border-amber-300 bg-amber-500/15 text-amber-700 shadow-sm shadow-amber-500/20 dark:border-amber-500/40 dark:text-amber-300"
                    : "border-slate-200 bg-white/60 text-slate-500 hover:border-slate-300 hover:text-slate-700 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-400 dark:hover:text-slate-200"
                )}
              >
                <CatIcon
                  name="star"
                  className={cn(
                    "h-3.5 w-3.5",
                    active && "fill-amber-400 text-amber-500 dark:fill-amber-400/80"
                  )}
                />
                {t("storeFiltersRatingUp", { n: nf(lang, n) })}
              </button>
            );
          })}
        </div>
      </fieldset>

      {/* in-stock only — a premium switch row */}
      <label className="flex min-h-11 cursor-pointer items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white/60 px-3 py-2 transition hover:border-slate-300 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-white/20">
        <span className="flex min-w-0 items-center gap-2 text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
          <CatIcon name="package-check" className="h-4 w-4 shrink-0 text-emerald-500 dark:text-emerald-300" />
          <span className="truncate">{t("storeFiltersInStock")}</span>
        </span>
        <Switch
          checked={onlyInStock}
          onCheckedChange={(v) => {
            setOnlyInStock(v);
            setVisibleCount(PAGE_SIZE);
          }}
          tone="success"
          aria-label={t("storeFiltersInStock")}
        />
      </label>
    </div>
  );

  /* ---------------- ROUND 147 — the departments panel ----------------
   * One body, TWO hosts: a Popover (desktop) anchored on the category nav
   * strip and a bottom Sheet (mobile). Selecting a department is EXACTLY
   * the category chip filter (toggles off when re-tapped); "كل الأقسام"
   * resets it. Counts are the honest unfiltered categoryCounts. */
  const departmentsPanelContent = (close: () => void) => (
    <div className="p-3">
      <p className="px-1 pb-2 text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
        {t("storeDepartments")}
      </p>
      <div className="nice-scroll max-h-80 space-y-1.5 overflow-y-auto pe-1">
        {/* كل الأقسام — the reset row */}
        <button
          type="button"
          onClick={() => {
            setCategory("");
            setVisibleCount(PAGE_SIZE);
            close();
          }}
          aria-pressed={category === ""}
          title={t("storeCatCountTitle", { n: nf(lang, products.length) })}
          className={cn(
            "flex w-full items-center justify-between gap-2 rounded-xl border px-3 py-2.5 text-[12px] font-extrabold transition active:scale-[0.98]",
            category === ""
              ? "border-brand-400 bg-brand-500/10 text-brand-600 ring-1 ring-brand-400/30 dark:border-brand-500/50 dark:text-brand-300 dark:ring-brand-500/25"
              : "border-slate-200 bg-white/70 text-slate-600 hover:border-slate-300 hover:text-slate-800 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:text-white"
          )}
        >
          <span className="flex min-w-0 items-center gap-2">
            <CatIcon name="grid-3x3" className="h-4 w-4 shrink-0" />
            <span className="truncate">{t("storeDepartmentsAll")}</span>
          </span>
          <span
            dir="ltr"
            className={cn(
              "shrink-0 rounded-full px-1.5 text-[10px] font-black tabular-nums",
              category === ""
                ? "bg-brand-500/15 text-brand-700 dark:bg-brand-500/20 dark:text-brand-200"
                : "bg-slate-100 text-slate-500 dark:bg-white/10 dark:text-slate-400"
            )}
          >
            {nf(lang, products.length)}
          </span>
        </button>
        {/* the departments themselves */}
        {categories.map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => {
              setCategory(category === cat ? "" : cat);
              setVisibleCount(PAGE_SIZE);
              close();
            }}
            aria-pressed={category === cat}
            title={t("storeCatCountTitle", { n: nf(lang, categoryCounts[cat] ?? 0) })}
            className={cn(
              "flex w-full items-center justify-between gap-2 rounded-xl border px-3 py-2.5 text-[12px] font-extrabold transition active:scale-[0.98]",
              category === cat
                ? "border-brand-400 bg-brand-500/10 text-brand-600 ring-1 ring-brand-400/30 dark:border-brand-500/50 dark:text-brand-300 dark:ring-brand-500/25"
                : "border-slate-200 bg-white/70 text-slate-600 hover:border-slate-300 hover:text-slate-800 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:text-white"
            )}
          >
            <span className="flex min-w-0 items-center gap-2">
              <CatIcon name="tag" className="h-3.5 w-3.5 shrink-0" />
              <span className="truncate" title={cat}>
                {cat}
              </span>
            </span>
            <span
              dir="ltr"
              className={cn(
                "shrink-0 rounded-full px-1.5 text-[10px] font-black tabular-nums",
                category === cat
                  ? "bg-brand-500/15 text-brand-700 dark:bg-brand-500/20 dark:text-brand-200"
                  : "bg-slate-100 text-slate-500 dark:bg-white/10 dark:text-slate-400"
              )}
            >
              {nf(lang, categoryCounts[cat] ?? 0)}
            </span>
          </button>
        ))}
      </div>
    </div>
  );

  /* ---------------- render ---------------- */

  return (
    <StoreAccountProvider instanceId={instanceId}>
    {/* ROUND 86 — the e-store's INDEPENDENT styling scope: its OWN font
        (storeFont) and its OWN accent ramp (accentVars over the resolved
        store theme — storeTheme, or the site theme when "follow" is
        chosen). Every brand-* utility + .font-display element below
        follows the store's identity, separate from the website. */}
    <div
      className="brand-scope surface-font-scope relative flex min-h-screen flex-col bg-background"
      style={{ ...fontVars(storeFont), ...accentVars(c1) }}
    >
      {/* skip-to-content — first focusable element */}
      <SkipLink target="top" />

      {/* decorative background */}
      <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden="true" />
      <div
        className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[420px] opacity-60"
        style={{
          background: `radial-gradient(60% 50% at 50% 0%, ${hexAlpha(c1, 0.14)}, transparent 70%)`,
        }}
        aria-hidden="true"
      />

      {/* draft preview banner (owner / admin only — server-gated) */}
      {!published ? (
        <div className="border-b border-amber-300/60 bg-amber-100/90 px-4 py-2 text-center backdrop-blur-sm dark:border-amber-500/30 dark:bg-amber-500/15">
          <p className="inline-flex items-center gap-2 text-[11.5px] font-extrabold text-amber-800 dark:text-amber-300">
            <CatIcon name="eye" className="h-3.5 w-3.5" />
            {t("sitePreviewBanner")}
          </p>
        </div>
      ) : null}

      {/* ---------------------------------------------- store header --- */}
      <header
        className={cn(
          "sticky top-0 z-40 border-b border-slate-200/70 bg-white/80 backdrop-blur-xl transition-shadow duration-300 dark:border-white/[0.07] dark:bg-ink-950/80",
          scrolled && "shadow-[0_10px_30px_-12px_rgba(15,23,42,0.18)] dark:shadow-[0_10px_30px_-12px_rgba(0,0,0,0.6)]"
        )}
      >
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          {/* brand row */}
          <div className="flex h-16 items-center gap-3">
            {/* back to the standalone website */}
            <a
              href={siteHref}
              aria-label={t("storefrontBackToSite")}
              title={t("storefrontBackToSite")}
              className="hidden h-10 w-10 place-items-center rounded-xl border border-slate-200 text-slate-500 transition hover:border-transparent hover:shadow-lift active:scale-95 dark:border-white/10 dark:text-slate-400 sm:grid"
            >
              <CatIcon name={ar ? "arrow-right" : "arrow-left"} className="h-4 w-4" />
            </a>

            {/* the brand — tapping it returns to the website (store "home") */}
            <a href={siteHref} className="flex min-w-0 items-center gap-2.5">
              {logoUrl ? (
                <span
                  className="grid h-10 w-10 shrink-0 place-items-center overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-lg dark:border-white/10 dark:bg-white/90"
                  aria-hidden="true"
                >
                  <img src={logoUrl} alt="" className="h-full w-full object-contain p-1" />
                </span>
              ) : (
                <span
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg"
                  style={{ backgroundImage: grad(c1, c2), boxShadow: `0 8px 20px -8px ${hexAlpha(c1, 0.8)}` }}
                >
                  <CatIcon name={systemIcon} className="h-[15px] w-[15px]" />
                </span>
              )}
              <span className="min-w-0 leading-none">
                <span className="flex items-center gap-2">
                  <span className="truncate font-display text-[14.5px] font-extrabold text-slate-900 dark:text-white">
                    {orgName}
                  </span>
                  <span
                    className="hidden shrink-0 rounded-full border px-2 py-0.5 text-[9.5px] font-extrabold sm:inline-flex"
                    style={{
                      borderColor: hexAlpha(c1, 0.35),
                      backgroundColor: hexAlpha(c1, 0.08),
                      color: c1,
                    }}
                  >
                    {t("storeBadge")}
                  </span>
                </span>
                {orgTagline ? (
                  <span className="mt-0.5 hidden truncate text-[10.5px] font-bold text-slate-400 dark:text-slate-500 lg:block">
                    {orgTagline}
                  </span>
                ) : null}
              </span>
            </a>

            {/* desktop search — centered, LARGE */}
            <div className="mx-auto hidden w-full max-w-2xl md:block">{searchBar}</div>

            {/* toggles (exact site-header patterns) */}
            <div className="ms-auto flex items-center gap-1.5 md:ms-0">
              {/* ROUND 86 — the visitor-language switcher obeys the owner's
                  enabled set (Settings → التفضيلات → لغات الزوار) */}
              <SurfaceLangSwitcher langs={surfaceLangs(storeLangs)} />

              {/* theme toggle — icons flip via CSS, no hydration mismatch */}
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
                aria-label={t("siteThemeToggle")}
                className="h-11 w-11 rounded-xl text-slate-500 dark:text-slate-400"
              >
                <CatIcon name="sun" className="hidden h-4 w-4 dark:block" />
                <CatIcon name="moon" className="block h-4 w-4 dark:hidden" />
              </Button>

              {/* ROUND 60 — share this store (QR + copy link) */}
              {published ? (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setShareOpen(true)}
                  aria-label={t("storeShareAria")}
                  title={t("storeShareAria")}
                  className="h-11 w-11 rounded-xl text-slate-500 transition hover:scale-105 hover:text-slate-800 active:scale-95 dark:text-slate-400 dark:hover:text-white"
                >
                  <CatIcon name="share-2" className="h-[17px] w-[17px]" />
                </Button>
              ) : null}

              {/* ROUND 65/85 — the customer account entry (guest link to
               * the dedicated account page / signed-in initials avatar),
               * right beside the cart */}
              <StoreAccountButton
                instanceId={instanceId}
                authNext={`/sites/${instanceId}/store`}
                  c1={c1}
                c2={c2}
              />

              {/* open cart (always reachable — the cart lives here) */}
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setCartOpen(true)}
                aria-label={t("storeCartAria")}
                title={t("storeCartAria")}
                className="relative h-11 w-11 rounded-xl text-slate-500 dark:text-slate-400"
              >
                <CatIcon name="shopping-cart" className="h-[18px] w-[18px]" />
                {cartCount > 0 ? (
                  <span
                    dir="ltr"
                    className="absolute -top-0.5 -end-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-rose-500 px-1 text-[10px] font-black tabular-nums text-white ring-2 ring-white dark:ring-ink-950"
                  >
                    {nf(lang, cartCount)}
                  </span>
                ) : null}
              </Button>
            </div>
          </div>

          {/* mobile search — its own row below the brand row */}
          <div className="pb-3 md:hidden">{searchBar}</div>
        </div>
      </header>

      {/* ------------------------------------------ category nav strip --- */}
      <nav
        aria-label={t("storefrontCatAria")}
        className="border-b border-slate-200/70 bg-white/70 backdrop-blur-sm dark:border-white/[0.07] dark:bg-white/[0.02]"
      >
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="nice-scroll flex items-center gap-2 overflow-x-auto py-2.5">
            {/* ROUND 147 — the departments affordance: a Popover grid on
                desktop; the same panel in a bottom Sheet on mobile. It
                filters EXACTLY like the category chips beside it (and كل
                الأقسام resets). */}
            <div className="hidden shrink-0 sm:block">
              <Popover open={departmentsOpen} onOpenChange={setDepartmentsOpen}>
                <PopoverTrigger asChild>
                  <button
                    type="button"
                    aria-label={t("storeDepartments")}
                    title={t("storeDepartments")}
                    className={cn(
                      "inline-flex h-9 items-center gap-1.5 rounded-full border px-3.5 text-[11.5px] font-extrabold transition active:scale-95",
                      category
                        ? "border-brand-300 bg-brand-500/10 text-brand-600 dark:border-brand-500/40 dark:text-brand-300"
                        : "border-slate-200 bg-white/60 text-slate-500 hover:border-slate-300 hover:text-slate-700 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-400 dark:hover:text-slate-200"
                    )}
                  >
                    <CatIcon name="grid-3x3" className="h-3.5 w-3.5" />
                    {t("storeDepartments")}
                    <CatIcon
                      name="chevron-down"
                      className={cn("h-3 w-3 transition-transform", departmentsOpen && "rotate-180")}
                    />
                  </button>
                </PopoverTrigger>
                <PopoverContent
                  align="start"
                  sideOffset={8}
                  aria-label={t("storeDepartments")}
                  className="w-72 rounded-2xl border-slate-200 bg-white p-0 shadow-lift dark:border-white/10 dark:bg-ink-900"
                >
                  {departmentsPanelContent(() => setDepartmentsOpen(false))}
                </PopoverContent>
              </Popover>
            </div>
            <button
              type="button"
              onClick={() => setDepartmentsSheetOpen(true)}
              aria-label={t("storeDepartments")}
              title={t("storeDepartments")}
              className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-full border border-slate-200 bg-white/60 px-3.5 text-[11.5px] font-extrabold text-slate-500 transition hover:border-slate-300 hover:text-slate-700 active:scale-95 sm:hidden dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-400 dark:hover:text-slate-200"
            >
              <CatIcon name="grid-3x3" className="h-3.5 w-3.5" />
              {t("storeDepartments")}
              <CatIcon name="chevron-down" className="h-3 w-3" />
            </button>

            {/* "الكل" */}
            <button
              type="button"
              onClick={() => {
                setCategory("");
                setVisibleCount(PAGE_SIZE);
              }}
              aria-pressed={category === ""}
              title={t("storeCatCountTitle", { n: nf(lang, products.length) })}
              className={cn(
                "inline-flex h-9 shrink-0 items-center gap-1.5 rounded-full border px-3.5 text-[11.5px] font-extrabold transition active:scale-95",
                category === ""
                  ? "border-brand-300 bg-brand-500/10 text-brand-600 dark:border-brand-500/40 dark:text-brand-300"
                  : "border-slate-200 bg-white/60 text-slate-500 hover:border-slate-300 hover:text-slate-700 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-400 dark:hover:text-slate-200"
              )}
            >
              {t("storeCatAll")}
              <span
                className={cn(
                  "rounded-full px-1.5 text-[10px] font-black tabular-nums",
                  category === ""
                    ? "bg-brand-500/15 text-brand-700 dark:bg-brand-500/20 dark:text-brand-200"
                    : "bg-slate-100 text-slate-500 dark:bg-white/10 dark:text-slate-400"
                )}
              >
                {nf(lang, products.length)}
              </span>
            </button>

            {/* category chips (honest unfiltered counts) */}
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => {
                  setCategory(category === cat ? "" : cat);
                  setVisibleCount(PAGE_SIZE);
                }}
                aria-pressed={category === cat}
                title={t("storeCatCountTitle", { n: nf(lang, categoryCounts[cat] ?? 0) })}
                className={cn(
                  "inline-flex h-9 max-w-40 shrink-0 items-center gap-1.5 rounded-full border px-3.5 text-[11.5px] font-extrabold transition active:scale-95",
                  category === cat
                    ? "border-brand-300 bg-brand-500/10 text-brand-600 dark:border-brand-500/40 dark:text-brand-300"
                    : "border-slate-200 bg-white/60 text-slate-500 hover:border-slate-300 hover:text-slate-700 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-400 dark:hover:text-slate-200"
                )}
              >
                <span className="truncate">{cat}</span>
                <span
                  className={cn(
                    "shrink-0 rounded-full px-1.5 text-[10px] font-black tabular-nums",
                    category === cat
                      ? "bg-brand-500/15 text-brand-700 dark:bg-brand-500/20 dark:text-brand-200"
                      : "bg-slate-100 text-slate-500 dark:bg-white/10 dark:text-slate-400"
                  )}
                >
                  {nf(lang, categoryCounts[cat] ?? 0)}
                </span>
              </button>
            ))}

            {/* ROUND 54 quick filters — مميزة (amber) / عليها عرض (rose) */}
            {featuredCount > 0 && !storeQuery.isPending ? (
              <button
                type="button"
                onClick={() => {
                  setOnlyFeatured((v) => !v);
                  setVisibleCount(PAGE_SIZE);
                }}
                aria-pressed={onlyFeatured}
                title={t("storeFilterFeaturedTitle", { n: nf(lang, featuredCount) })}
                className={cn(
                  "inline-flex h-9 shrink-0 items-center gap-1.5 rounded-full border px-3.5 text-[11.5px] font-extrabold transition active:scale-95",
                  onlyFeatured
                    ? "border-amber-300 bg-amber-500/15 text-amber-700 shadow-sm shadow-amber-500/20 dark:border-amber-500/40 dark:text-amber-300"
                    : "border-amber-200/70 bg-amber-50/60 text-amber-600/90 hover:border-amber-300 hover:bg-amber-100/60 dark:border-amber-500/25 dark:bg-amber-500/10 dark:text-amber-300/80 dark:hover:bg-amber-500/15"
                )}
              >
                <CatIcon
                  name="star"
                  className={cn(
                    "h-3.5 w-3.5",
                    onlyFeatured && "fill-amber-400 text-amber-500 dark:fill-amber-400/80"
                  )}
                />
                {t("storeFilterFeatured")}
                <span
                  className={cn(
                    "rounded-full px-1.5 text-[10px] font-black tabular-nums",
                    onlyFeatured
                      ? "bg-amber-500/20 text-amber-800 dark:bg-amber-500/25 dark:text-amber-200"
                      : "bg-amber-500/15 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300"
                  )}
                >
                  {nf(lang, featuredCount)}
                </span>
              </button>
            ) : null}
            {saleCount > 0 && !storeQuery.isPending ? (
              <button
                type="button"
                onClick={() => {
                  setOnlySale((v) => !v);
                  setVisibleCount(PAGE_SIZE);
                }}
                aria-pressed={onlySale}
                title={t("storeFilterSaleTitle", { n: nf(lang, saleCount) })}
                className={cn(
                  "inline-flex h-9 shrink-0 items-center gap-1.5 rounded-full border px-3.5 text-[11.5px] font-extrabold transition active:scale-95",
                  onlySale
                    ? "border-rose-300 bg-rose-500/15 text-rose-700 shadow-sm shadow-rose-500/20 dark:border-rose-500/40 dark:text-rose-300"
                    : "border-rose-200/70 bg-rose-50/60 text-rose-600/90 hover:border-rose-300 hover:bg-rose-100/60 dark:border-rose-500/25 dark:bg-rose-500/10 dark:text-rose-300/80 dark:hover:bg-rose-500/15"
                )}
              >
                <CatIcon name="ticket-percent" className="h-3.5 w-3.5" />
                {t("storeFilterOnSale")}
                <span
                  className={cn(
                    "rounded-full px-1.5 text-[10px] font-black tabular-nums",
                    onlySale
                      ? "bg-rose-500/20 text-rose-800 dark:bg-rose-500/25 dark:text-rose-200"
                      : "bg-rose-500/15 text-rose-700 dark:bg-rose-500/20 dark:text-rose-300"
                  )}
                >
                  {nf(lang, saleCount)}
                </span>
              </button>
            ) : null}

            {/* reset (only when a quick filter is active) */}
            {onlyFeatured || onlySale ? (
              <button
                type="button"
                onClick={() => {
                  setOnlyFeatured(false);
                  setOnlySale(false);
                  setVisibleCount(PAGE_SIZE);
                }}
                className="inline-flex h-9 shrink-0 items-center gap-1 rounded-full border border-slate-200 bg-white/60 px-3 text-[11px] font-bold text-slate-400 transition hover:border-slate-300 hover:text-slate-600 active:scale-95 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-500 dark:hover:text-slate-300"
              >
                <CatIcon name="x" className="h-3 w-3" />
                {t("storeFilterReset")}
              </button>
            ) : null}

          </div>
        </div>
      </nav>

      <main id="top" className="flex-1">
        {/* --------------------------------------------- deals band --- */}
        {dealProducts.length > 0 ? (
          <section className="cv-auto px-4 pt-8 sm:px-6" aria-labelledby="store-deals-heading">
            <div className="mx-auto max-w-6xl">
              <Reveal>
                <div className="flex items-center justify-between gap-3">
                  <h2
                    id="store-deals-heading"
                    className="flex items-center gap-2.5 font-display text-[18px] font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-[20px]"
                  >
                    <span
                      className="grid h-9 w-9 place-items-center rounded-2xl text-white shadow-lg"
                      style={{ backgroundImage: grad(c1, c2) }}
                    >
                      <CatIcon name="percent" className="h-4 w-4" />
                    </span>
                    {t("storefrontDeals")}
                  </h2>
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-rose-200 bg-rose-50/80 px-3 py-1 text-[11px] font-extrabold text-rose-600 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-300">
                    <CatIcon name="sparkles" className="h-3 w-3" />
                    {nf(lang, dealProducts.length)}
                  </span>
                </div>
              </Reveal>
              <Reveal delay={0.06}>
                <div className="nice-scroll -mx-4 mt-4 flex snap-x gap-4 overflow-x-auto px-4 pb-2 sm:mx-0 sm:px-0">
                  {dealProducts.map((product) => (
                    <StoreDealCard
                      key={product.recordId}
                      product={product}
                      currency={currency}
                      c1={c1}
                      c2={c2}
                      onAdd={addToCart}
                    />
                  ))}
                </div>
              </Reveal>
            </div>
          </section>
        ) : null}

        {/* ------------ ROUND 147 — filter rail + breadcrumbs + results --- */}
        <section className="cv-auto px-4 pt-8 pb-12 sm:px-6">
          <div className="mx-auto max-w-6xl lg:flex lg:items-start lg:gap-6">
            {/* the desktop filter rail — sticky beside the results (the
                mobile twin opens in a Sheet from the toolbar below; both
                hosts render the SAME rail body, so they stay in sync by
                construction — all state lives up in the storefront) */}
            <aside className="hidden w-64 shrink-0 lg:block" aria-label={t("storeFilters")}>
              <div className="rounded-3xl border border-slate-200/80 bg-white/70 p-4 shadow-soft backdrop-blur-sm lg:sticky lg:top-28 dark:border-white/10 dark:bg-white/[0.03]">
                {filterRailContent}
              </div>
            </aside>

            <div className="min-w-0 flex-1">
              {/* breadcrumbs — store root / active category / active search
                  query (truncated). RTL-aware separators point toward the
                  NEXT crumb in reading order (the file's arrow idiom). */}
              <nav
                aria-label={t("storeBreadcrumbStore")}
                className="flex flex-wrap items-center gap-x-1 gap-y-1 text-[11.5px] font-bold text-slate-500 dark:text-slate-400"
              >
                {category || debouncedQ ? (
                  <button
                    type="button"
                    onClick={() => {
                      setCategory("");
                      setSearchInput("");
                      setDebouncedQ("");
                      setVisibleCount(PAGE_SIZE);
                    }}
                    className="rounded-lg px-1.5 py-1 font-extrabold transition hover:bg-slate-100 hover:text-slate-800 dark:hover:bg-white/5 dark:hover:text-white"
                  >
                    {t("storeBreadcrumbStore")}
                  </button>
                ) : (
                  <span
                    aria-current="page"
                    className="px-1.5 py-1 font-extrabold text-slate-700 dark:text-slate-200"
                  >
                    {t("storeBreadcrumbStore")}
                  </span>
                )}
                {category ? (
                  <>
                    <CatIcon
                      name={ar ? "arrow-left" : "arrow-right"}
                      className="h-3 w-3 shrink-0 text-slate-300 dark:text-slate-600"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        setCategory("");
                        setVisibleCount(PAGE_SIZE);
                      }}
                      title={category}
                      className="max-w-40 truncate rounded-lg px-1.5 py-1 font-extrabold transition hover:bg-slate-100 hover:text-slate-800 dark:hover:bg-white/5 dark:hover:text-white"
                    >
                      {category}
                    </button>
                  </>
                ) : null}
                {debouncedQ ? (
                  <>
                    <CatIcon
                      name={ar ? "arrow-left" : "arrow-right"}
                      className="h-3 w-3 shrink-0 text-slate-300 dark:text-slate-600"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        setSearchInput("");
                        setDebouncedQ("");
                        setVisibleCount(PAGE_SIZE);
                      }}
                      title={debouncedQ}
                      className="max-w-48 truncate rounded-lg px-1.5 py-1 font-extrabold transition hover:bg-slate-100 hover:text-slate-800 dark:hover:bg-white/5 dark:hover:text-white"
                    >
                      «{debouncedQ}»
                    </button>
                  </>
                ) : null}
              </nav>

              {/* --------------------------------------- results toolbar --- */}
              <div className="mt-2 flex flex-wrap items-center gap-2.5">
                <p className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  {t("storeCount", { n: nf(lang, visibleProducts.length) })}
                </p>

                {/* active filter chips — one tap clears each */}
                {activeFilters.map((chip) => (
                  <button
                    key={chip.key}
                    type="button"
                    onClick={chip.clear}
                    className={cn(
                      "inline-flex h-8 max-w-48 items-center gap-1.5 rounded-full border px-3 text-[11px] font-extrabold transition active:scale-95",
                      chip.tone === "amber"
                        ? "border-amber-300 bg-amber-500/15 text-amber-700 dark:border-amber-500/40 dark:text-amber-300"
                        : chip.tone === "rose"
                          ? "border-rose-300 bg-rose-500/15 text-rose-700 dark:border-rose-500/40 dark:text-rose-300"
                          : "border-brand-300 bg-brand-500/10 text-brand-600 dark:border-brand-500/40 dark:text-brand-300"
                    )}
                  >
                    <CatIcon name={chip.icon} className="h-3 w-3 shrink-0" />
                    <span className="truncate">{chip.label}</span>
                    <CatIcon name="x" className="h-3 w-3 shrink-0 opacity-70" />
                  </button>
                ))}

                {/* ROUND 147 — the mobile filter entry (the desktop rail is
                    always mounted beside the grid); the badge counts the
                    active client-side facets */}
                <div className="lg:hidden">
                  <button
                    type="button"
                    onClick={() => setFiltersOpen(true)}
                    aria-haspopup="dialog"
                    aria-label={t("storeFilters")}
                    title={t("storeFilters")}
                    className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 text-[11.5px] font-extrabold text-slate-600 shadow-sm transition hover:border-slate-300 active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:border-white/25"
                  >
                    <CatIcon name="sliders" className="h-3.5 w-3.5" />
                    {t("storeFilters")}
                    {clientFilterCount > 0 ? (
                      <span
                        dir="ltr"
                        className="grid h-4.5 min-w-4.5 place-items-center rounded-full bg-brand-500 px-1 text-[9.5px] font-black tabular-nums text-white"
                      >
                        {nf(lang, clientFilterCount)}
                      </span>
                    ) : null}
                  </button>
                </div>

                {/* sort select (client-side over the fetched page) */}
                <div className="ms-auto">
                  <Select value={sortMode} onValueChange={(v) => setSortMode(v as SortMode)}>
                    <SelectTrigger
                      aria-label={t("storefrontSortLabel")}
                      /* ROUND 88 — same useId/HMR artifact guard as the
                         department select above (attribute-scoped suppression) */
                      suppressHydrationWarning
                      className="h-9 rounded-xl border-slate-200 bg-white text-[11.5px] font-extrabold text-slate-600 shadow-sm dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
                    >
                      <span className="flex items-center gap-1.5">
                        <CatIcon name="sliders" className="h-3.5 w-3.5 text-slate-400" />
                        <span className="hidden sm:inline">{t("storefrontSortLabel")}:</span>
                        <SelectValue />
                      </span>
                    </SelectTrigger>
                    <SelectContent>
                      {SORT_OPTIONS.map((opt) => (
                        <SelectItem key={opt.value} value={opt.value}>
                          {t(opt.key)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* ------------------------------------------ product grid --- */}
              <div className="pt-5">
                {storeQuery.isPending ? (
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-3 xl:grid-cols-4">
                    {Array.from({ length: PAGE_SIZE }).map((_, i) => (
                      <Skeleton key={i} className="h-56 rounded-3xl" />
                    ))}
                  </div>
                ) : visibleProducts.length === 0 && hasClientFilters && products.length > 0 ? (
                  /* ROUND 54/147 — client filters emptied the page (the catalog
                     itself still has products): targeted empty state with a
                     one-tap clear-ALL-filters reset */
                  <div className="rounded-3xl border-2 border-dashed border-amber-200 bg-amber-50/40 p-10 text-center dark:border-amber-500/25 dark:bg-amber-500/5">
                    <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-amber-500/15 text-amber-500 dark:text-amber-300">
                      <CatIcon name="sliders" className="h-6 w-6" />
                    </div>
                    <h3 className="mt-4 font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                      {t("storeFilterEmpty")}
                    </h3>
                    <p className="mx-auto mt-1 max-w-sm text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
                      {t("storeFilterEmptyDesc")}
                    </p>
                    <button
                      type="button"
                      onClick={clearClientFilters}
                      className="mx-auto mt-5 inline-flex h-10 items-center gap-1.5 rounded-full border border-amber-300 bg-white px-5 text-[12px] font-extrabold text-amber-700 shadow-sm transition hover:bg-amber-50 active:scale-95 dark:border-amber-500/40 dark:bg-transparent dark:text-amber-300 dark:hover:bg-amber-500/10"
                    >
                      <CatIcon name="x" className="h-3.5 w-3.5" />
                      {t("storeFiltersClear")}
                    </button>
                  </div>
                ) : products.length === 0 ? (
                  /* no results at all (empty catalog or no search matches) */
                  <div className="rounded-3xl border-2 border-dashed border-slate-200 p-10 text-center dark:border-white/10">
                    <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
                      <CatIcon name="search" className="h-6 w-6" />
                    </div>
                    <h3 className="mt-4 font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                      {t("storeEmpty")}
                    </h3>
                    <p className="mx-auto mt-1 max-w-sm text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
                      {t("storeEmptyDesc")}
                    </p>
                  </div>
                ) : (
                  <>
                    {/* ROUND 147 — with the desktop rail reserving w-64, the
                     grid breathes at 3 columns on lg and returns to 4 on xl
                     (2/3 columns below lg are EXACTLY as they were) */}
                    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-3 xl:grid-cols-4">
                      {pageItems.map((product, i) => (
                        /* ROUND 61 — wave-stagger the card entrance (the card-in
                         * keyframe reads --i; capped at 11 so late pages don't
                         * wait through a long cascade after load-more) */
                        <StoreProductCard
                          key={product.recordId}
                          product={product}
                          currency={currency}
                          c1={c1}
                          c2={c2}
                          onAdd={addToCart}
                          wishlisted={wishlist.has(product.recordId)}
                          onToggleWishlist={toggleWishlist}
                          onQuickView={() => openQuickView(product)}
                          staggerIndex={Math.min(i, 11)}
                        />
                      ))}
                    </div>

                    {/* load more — +12 per tap, honest remaining count */}
                    {remaining > 0 ? (
                      <div className="mt-8 flex justify-center">
                        <button
                          type="button"
                          onClick={() => setVisibleCount((v) => v + PAGE_SIZE)}
                          className="inline-flex h-11 items-center gap-2 rounded-2xl border border-slate-200 bg-white px-6 text-[12.5px] font-extrabold text-slate-700 shadow-sm transition hover:border-transparent hover:shadow-lift active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200"
                        >
                          <CatIcon name="chevron-down" className="h-4 w-4" />
                          {t("storefrontLoadMore")}
                          <span
                            dir="ltr"
                            className="rounded-full bg-slate-100 px-2 py-0.5 text-[10.5px] font-black tabular-nums text-slate-500 dark:bg-white/10 dark:text-slate-400"
                          >
                            +{nf(lang, remaining)}
                          </span>
                        </button>
                      </div>
                    ) : null}
                  </>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* -------------------------- ROUND 147 — recently viewed rail --- */}
        {recentProducts.length > 0 ? (
          <section aria-labelledby="store-recent-heading" className="px-4 pb-10 sm:px-6">
            <div className="mx-auto max-w-6xl">
              <Reveal>
                <h2
                  id="store-recent-heading"
                  className="flex items-center gap-2.5 font-display text-[16px] font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-[18px]"
                >
                  <span
                    className="grid h-8 w-8 place-items-center rounded-xl text-white shadow-lg"
                    style={{ backgroundImage: grad(c1, c2) }}
                  >
                    <CatIcon name="clock-rotate-left" className="h-4 w-4" />
                  </span>
                  {t("storeRecentlyViewed")}
                </h2>
              </Reveal>
              <Reveal delay={0.06}>
                <div className="nice-scroll -mx-4 mt-4 flex snap-x gap-3 overflow-x-auto px-4 pb-2 sm:mx-0 sm:px-0">
                  {recentProducts.map((product, i) => (
                    <StoreRecentCard
                      key={product.recordId}
                      product={product}
                      currency={currency}
                      c1={c1}
                      c2={c2}
                      onAdd={addToCart}
                      onOpen={() => openQuickView(product)}
                      staggerIndex={Math.min(i, 11)}
                    />
                  ))}
                </div>
              </Reveal>
            </div>
          </section>
        ) : null}

        {/* --------------------------------------- benefits strip --- */}
        <section className="border-t border-slate-200/70 bg-white/60 px-4 py-10 backdrop-blur-sm dark:border-white/[0.07] dark:bg-white/[0.02] sm:px-6">
          <div className="mx-auto max-w-6xl">
            <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
              {BENEFITS.map((b, i) => (
                <Reveal key={b.icon} delay={0.05 * i} className="min-w-0">
                  <div className="flex h-full items-center gap-3 rounded-2xl border border-slate-200/80 bg-white p-4 shadow-soft dark:border-white/10 dark:bg-white/[0.03]">
                    <span
                      className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
                      style={{
                        backgroundImage: grad(c1, c2),
                        boxShadow: `0 10px 24px -10px ${hexAlpha(c1, 0.8)}`,
                      }}
                    >
                      <CatIcon name={b.icon} className="h-[18px] w-[18px]" />
                    </span>
                    <div className="min-w-0">
                      <p className="font-display text-[13px] font-extrabold text-slate-900 dark:text-white">
                        {t(b.label)}
                      </p>
                      <p className="mt-0.5 text-[10.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                        {t(b.desc)}
                      </p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

      </main>

      {/* ---------------------------------------------- store footer --- */}
      <footer className="safe-bottom mt-auto border-t border-slate-200/70 bg-white/70 py-8 backdrop-blur-sm dark:border-white/[0.07] dark:bg-white/[0.02]">
        <div className="mx-auto flex max-w-6xl flex-col items-center gap-4 px-4 text-center sm:px-6">
          <div className="flex items-center gap-2.5">
            {logoUrl ? (
              <span
                className="grid h-9 w-9 place-items-center overflow-hidden rounded-xl border border-slate-200/80 bg-white shadow-md dark:border-white/10 dark:bg-white/90"
                aria-hidden="true"
              >
                <img src={logoUrl} alt="" className="h-full w-full object-contain p-1" />
              </span>
            ) : (
              <span
                className="grid h-8 w-8 place-items-center rounded-xl text-white shadow-lg"
                style={{ backgroundImage: grad(c1, c2) }}
              >
                <CatIcon name={systemIcon} className="h-[13px] w-[13px]" />
              </span>
            )}
            <div className="text-start leading-none">
              <p className="font-display text-[13px] font-extrabold text-slate-900 dark:text-white">
                {orgName}
              </p>
              <p className="mt-0.5 text-[10px] font-bold text-slate-400 dark:text-slate-500">
                © {nf(lang, new Date().getFullYear())} — {t("siteFooterRights")}
              </p>
            </div>
          </div>

          {/* the store's own identity line */}
          <p className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white/70 px-3.5 py-1.5 text-[11px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-400">
            <CatIcon name="shopping-cart" className="h-3 w-3" />
            {t("storeBadge")} — {orgName}
          </p>

          {/* back to the standalone website + share the store (published) */}
          <div className="flex flex-wrap items-center justify-center gap-2.5">
            <a
              href={siteHref}
              className="inline-flex h-10 items-center gap-2 rounded-2xl border border-slate-200 bg-white px-5 text-[12px] font-bold text-slate-700 shadow-sm transition hover:border-transparent hover:shadow-lift active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200"
            >
              <CatIcon name={ar ? "arrow-right" : "arrow-left"} className="h-3.5 w-3.5" />
              {t("storefrontBackToSite")}
            </a>
            {published ? (
              <button
                type="button"
                onClick={() => setShareOpen(true)}
                className="inline-flex h-10 items-center gap-2 rounded-2xl border border-slate-200 bg-white px-5 text-[12px] font-bold text-slate-700 shadow-sm transition hover:border-transparent hover:shadow-lift active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200"
              >
                <CatIcon name="share-2" className="h-3.5 w-3.5" />
                {t("storeShareAria")}
              </button>
            ) : null}
          </div>

          {/* ROUND 84 (84-LEGAL) — the public legal pages (privacy & terms) */}
          <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-1.5">
            <a
              href={`/sites/${instanceId}/privacy`}
              className="inline-flex items-center gap-1.5 text-[11.5px] font-bold text-slate-400 transition hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300"
            >
              <CatIcon name="shield-check" className="h-3.5 w-3.5" />
              {t("legalPrivacyTitle")}
            </a>
            <span className="text-[10px] text-slate-300 dark:text-slate-600" aria-hidden="true">
              •
            </span>
            <a
              href={`/sites/${instanceId}/terms`}
              className="inline-flex items-center gap-1.5 text-[11.5px] font-bold text-slate-400 transition hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300"
            >
              <CatIcon name="scale" className="h-3.5 w-3.5" />
              {t("legalTermsTitle")}
            </a>
          </div>

          <p className="flex items-center gap-1.5 text-[11px] font-bold text-slate-400 dark:text-slate-500">
            {t("sitePoweredBy")}
            <a
              href="/"
              className="inline-flex items-center gap-1.5 rounded-lg px-2 py-1 font-extrabold text-gradient transition hover:bg-slate-100 dark:hover:bg-white/5"
            >
              <CatIcon name="boxes" className="h-3.5 w-3.5" />
              Ashrilogic
            </a>
          </p>
        </div>
      </footer>

      {/* ------------------ ROUND 56 — themed back-to-top (end corner) --- */}
      <StoreBackToTop c1={c1} c2={c2} />

      {/* ------------- ROUND 58 — floating wishlist FAB (rose, above cart) --- */}
      <button
        type="button"
        onClick={() => setWishlistOpen(true)}
        aria-label={t("wishlistAria")}
        title={t("wishlistAria")}
        className="animate-heart-pop fixed bottom-[5.75rem] start-5 z-40 grid h-12 w-12 place-items-center rounded-2xl border border-rose-200/70 bg-white text-rose-500 shadow-xl transition hover:-translate-y-1 hover:shadow-2xl active:scale-95 sm:h-13 sm:w-13 dark:border-rose-500/30 dark:bg-ink-900 dark:text-rose-300"
      >
        <CatIcon name="heart" className={cn("h-5 w-5", wishlist.count > 0 && "fill-current")} />
        {wishlist.count > 0 ? (
          <span
            dir="ltr"
            className={cn(
              "absolute -top-1.5 -end-1.5 grid h-5 min-w-5 place-items-center rounded-full bg-rose-500 px-1 text-[10px] font-black tabular-nums text-white ring-2 ring-white dark:ring-ink-950",
              badgePop && "badge-pop"
            )}
          >
            {nf(lang, wishlist.count)}
          </span>
        ) : null}
      </button>

      {/* --------------------------------------- floating cart FAB --- */}
      <button
        type="button"
        onClick={() => setCartOpen(true)}
        aria-label={t("storeCartAria")}
        title={t("storeCartAria")}
        className="fixed bottom-5 start-5 z-40 grid h-13 w-13 place-items-center rounded-2xl text-white shadow-xl transition hover:-translate-y-1 hover:shadow-2xl active:scale-95 sm:h-14 sm:w-14"
        style={{
          backgroundImage: grad(c1, c2),
          boxShadow: `0 16px 32px -10px ${hexAlpha(c1, 0.75)}`,
        }}
      >
        <CatIcon name="shopping-cart" className="h-6 w-6" />
        {cartCount > 0 ? (
          <span
            dir="ltr"
            className="absolute -top-1.5 -end-1.5 grid h-5 min-w-5 place-items-center rounded-full bg-rose-500 px-1 text-[10px] font-black tabular-nums text-white ring-2 ring-white dark:ring-ink-950"
          >
            {nf(lang, cartCount)}
          </span>
        ) : null}
      </button>

      {/* --------------------------- the cart sheet (guest checkout) --- */}
      <StoreCartSheet
        open={cartOpen}
        onOpenChange={setCartOpen}
        instanceId={instanceId}
        cart={cart.items}
        currency={currency}
        c1={c1}
        c2={c2}
        onQty={cart.setQty}
        onRemove={cart.remove}
        onClear={cart.clear}
      />

      {/* ------------------ ROUND 58 — the wishlist sheet (guest) --- */}
      <StoreWishlistSheet
        open={wishlistOpen}
        onOpenChange={setWishlistOpen}
        items={wishlistProducts}
        currency={currency}
        c1={c1}
        c2={c2}
        onAdd={addWishlistItemToCart}
        onRemove={wishlist.remove}
        onClear={wishlist.clear}
      />

      {/* ---------------- ROUND 60 — the share dialog (QR + link) --- */}
      <StoreShareDialog
        open={shareOpen}
        onOpenChange={setShareOpen}
        instanceId={instanceId}
        orgName={orgName}
        c1={c1}
        c2={c2}
      />

      {/* ------------ ROUND 61 — the product quick-view dialog --- */}
      <StoreProductQuickView
        open={quickView !== null}
        onOpenChange={(next) => {
          if (!next) setQuickView(null);
        }}
        product={quickView}
        currency={currency}
        c1={c1}
        c2={c2}
        onAdd={addToCart}
        onToggleWishlist={toggleWishlist}
        wishlisted={quickView ? wishlist.has(quickView.recordId) : false}
        onOpenReviews={(p) => setReviewsProduct(p)}
        related={quickViewRelated}
        onSwitchProduct={openQuickView}
      />

      {/* ---------- ROUND 63 — the reviews & ratings dialog --- */}
      <StoreReviewsDialog
        open={reviewsProduct !== null}
        onOpenChange={(next) => {
          if (!next) setReviewsProduct(null);
        }}
        product={reviewsProduct}
        instanceId={instanceId}
        c1={c1}
        c2={c2}
      />

      {/* -------- ROUND 147 — the mobile departments bottom sheet (the
          desktop twin is the Popover on the category strip; BOTH render
          the same departmentsPanelContent body) --- */}
      <Sheet open={departmentsSheetOpen} onOpenChange={setDepartmentsSheetOpen}>
        <SheetContent
          side="bottom"
          className="mx-auto max-h-[75vh] w-full gap-0 overflow-y-auto rounded-t-3xl p-0 sm:max-w-md"
        >
          <SheetHeader
            className="border-b border-slate-200/70 px-5 py-4 pe-14 dark:border-white/10"
            style={{
              backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.14)}, ${hexAlpha(c2, 0.14)})`,
            }}
          >
            <SheetTitle className="flex items-center gap-2.5 font-display text-[15px] font-extrabold">
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
                style={{ backgroundImage: grad(c1, c2) }}
              >
                <CatIcon name="grid-3x3" className="h-4 w-4" />
              </span>
              {t("storeDepartments")}
            </SheetTitle>
            <SheetDescription className="sr-only">{t("storeDepartments")}</SheetDescription>
          </SheetHeader>
          {departmentsPanelContent(() => setDepartmentsSheetOpen(false))}
        </SheetContent>
      </Sheet>

      {/* -------- ROUND 147 — the mobile filter sheet (the desktop twin is
          the sticky rail beside the grid; BOTH render the same
          filterRailContent body — one source of state) --- */}
      <Sheet open={filtersOpen} onOpenChange={setFiltersOpen}>
        <SheetContent
          side={lang === "ar" ? "right" : "left"}
          className="w-full gap-0 overflow-y-auto p-0 sm:max-w-xs"
        >
          <SheetHeader
            className="border-b border-slate-200/70 px-5 py-4 pe-14 dark:border-white/10"
            style={{
              backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.14)}, ${hexAlpha(c2, 0.14)})`,
            }}
          >
            <SheetTitle className="flex items-center gap-2.5 font-display text-[15px] font-extrabold">
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
                style={{ backgroundImage: grad(c1, c2) }}
              >
                <CatIcon name="sliders" className="h-4 w-4" />
              </span>
              {t("storeFilters")}
            </SheetTitle>
            <SheetDescription className="sr-only">{t("storeFilters")}</SheetDescription>
          </SheetHeader>
          <div className="p-5">{filterRailContent}</div>
        </SheetContent>
      </Sheet>

    </div>
    </StoreAccountProvider>
  );
}

export default StorefrontView;
