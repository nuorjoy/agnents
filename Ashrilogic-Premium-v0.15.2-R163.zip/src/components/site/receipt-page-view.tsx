"use client";

/**
 * Ashrilogic — ROUND 119 — the STANDALONE RECEIPT PAGE VIEW.
 *
 * The token-verified, emailable/shareable face of a guest's printable
 * order receipt (/sites/[id]/receipt?token=…): a slim print-hidden chrome
 * (back-to-store link + the print affordance + the link-validity note)
 * around the EXACT R62 receipt paper (ReceiptPaper — the same component
 * the tracking dialog renders, so the paper is pixel-identical whichever
 * surface prints it).
 *
 * The paper carries the R36 `.print-doc` root: under @media print only the
 * paper reaches the paper (theme-agnostic ink on white); this page's chrome
 * is `print:hidden` so nothing else bleeds into the print dialog.
 *
 * NEW surface — nothing existing was touched visually.
 */
import { useMemo, useState } from "react";
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { cn, grad, hexAlpha } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { SkipLink } from "@/components/skip-link";
import { ReceiptPaper, type OrderReceiptData, type ReceiptIdentity } from "@/components/site/order-receipt";

export interface ReceiptPageViewProps {
  instanceId: string;
  orgName: string;
  c1: string;
  c2: string;
  systemIcon: string;
  logoUrl: string;
  orgContact: string | null;
  /** the guest projection (PII-free) resolved server-side */
  data: OrderReceiptData;
  /** ROUND 122 — the page's own bearer token (already verified server-
   *  side): rendered into a screen-only QR so a desktop visitor can beam
   *  this page to their phone. Never rendered when absent. */
  receiptToken: string | null;
}

export function ReceiptPageView({
  instanceId,
  orgName,
  c1,
  c2,
  systemIcon,
  logoUrl,
  orgContact,
  data,
  receiptToken,
}: ReceiptPageViewProps) {
  const { t, lang } = useT();

  /* the paper's issue timestamp — minted once per page mount (the R62
   * discipline: a re-render never re-dates the receipt) */
  const issued = useMemo(() => new Date().toISOString(), []);

  /* ROUND 122 — the server-minted QR for THIS page's own link (same
   * bearer token; the endpoint verifies it before minting anything) */
  const [qrState, setQrState] = useState<"loading" | "ok" | "error">("loading");
  const qrSrc =
    receiptToken !== null
      ? `/api/sites/${instanceId}/receipt-qr?token=${encodeURIComponent(receiptToken)}`
      : null;

  const print = () => {
    window.setTimeout(() => window.print(), 60);
  };

  const identity: ReceiptIdentity = {
    orgName,
    logoUrl,
    c1,
    c2,
    orgContact,
    /* the guest projection never carries the owner's signature/stamp */
  };

  const storeHref = `/sites/${instanceId}/store#tracking`;

  return (
    <div className="relative flex min-h-screen flex-col bg-slate-50/60 dark:bg-transparent">
      {/* skip-to-content — first focusable element (print:hidden) */}
      <div className="print:hidden">
        <SkipLink target="receipt-top" />
      </div>

      {/* ------------------------------------------------ top bar ------- */}
      <header className="print:hidden sticky top-0 z-40 border-b border-slate-200/70 bg-white/80 backdrop-blur-xl dark:border-white/[0.07] dark:bg-ink-950/80">
        <div className="mx-auto flex h-16 max-w-3xl items-center gap-3 px-4 sm:px-6">
          {/* back to the store's tracking section */}
          <a
            href={storeHref}
            aria-label={t("rcptPageBackStore")}
            title={t("rcptPageBackStore")}
            className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-slate-200 text-slate-500 transition hover:border-transparent hover:shadow-lift active:scale-95 dark:border-white/10 dark:text-slate-400"
          >
            <CatIcon name={lang === "ar" ? "arrow-right" : "arrow-left"} className="h-4 w-4" />
          </a>

          {/* the brand */}
          <a href={storeHref} className="flex min-w-0 items-center gap-2.5">
            {logoUrl ? (
              <span
                className="grid h-10 w-10 shrink-0 place-items-center overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-lg dark:border-white/10 dark:bg-white/90"
                aria-hidden="true"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={logoUrl} alt="" className="h-full w-full object-contain p-1" />
              </span>
            ) : (
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg"
                style={{ backgroundImage: grad(c1, c2), boxShadow: `0 8px 20px -8px ${hexAlpha(c1, 0.8)}` }}
              >
                <CatIcon name={systemIcon} className="h-[15px] w-[15px]" />
              </span>
            )}
            <span className="min-w-0 leading-none">
              <span className="block truncate font-display text-[14.5px] font-extrabold text-slate-900 dark:text-white">
                {orgName}
              </span>
              <span className="mt-0.5 block truncate text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                {t("rcptTitle")}
              </span>
            </span>
          </a>

          <div className="ms-auto flex items-center gap-2">
            <Button
              type="button"
              onClick={print}
              className="h-10 gap-2 rounded-2xl px-5 text-[12px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95"
              style={{
                backgroundImage: grad(c1, c2),
                boxShadow: `0 12px 26px -10px ${hexAlpha(c1, 0.75)}`,
              }}
            >
              <CatIcon name="printer" className="h-4 w-4" />
              <span className="hidden sm:inline">{t("printBtn")}</span>
            </Button>
          </div>
        </div>
      </header>

      {/* ------------------------------------------------ the paper ----- */}
      <main id="receipt-top" className="flex flex-1 items-start justify-center px-4 py-10 sm:py-14">
        <div className="w-full max-w-[440px]">
          <ReceiptPaper data={data} identity={identity} issued={issued} lang={lang} />

          {/* link-validity note (screen only) */}
          <p
            className={cn(
              "print:hidden mt-5 flex items-center justify-center gap-1.5 text-center",
              "text-[11px] font-semibold text-slate-400 dark:text-slate-500"
            )}
          >
            <CatIcon name="calendar-clock" className="h-3.5 w-3.5 shrink-0" />
            {t("rcptLinkNote")}
          </p>

          {/* ROUND 122 — the page's own QR (screen only, never on paper):
              a desktop visitor beams this receipt to their phone. The QR
              is minted server-side (SVG; the token is verified there) —
              same discipline as the tracking dialog's panel. */}
          {qrSrc !== null ? (
            <div className="print:hidden mx-auto mt-4 flex w-full max-w-[220px] flex-col items-center gap-2 rounded-2xl border border-slate-200 bg-white/80 px-4 py-4 shadow-sm dark:border-white/10 dark:bg-white/[0.03]">
              <span
                className="relative grid h-[132px] w-[132px] place-items-center overflow-hidden rounded-xl bg-white p-2"
                aria-label={t("rcptQrBtn")}
              >
                {qrState === "error" ? (
                  <CatIcon name="qr" className="h-9 w-9 text-slate-300" />
                ) : (
                  /* eslint-disable-next-line @next/next/no-img-element */
                  <img
                    src={qrSrc}
                    alt={t("rcptQrBtn")}
                    onLoad={() => setQrState("ok")}
                    onError={() => setQrState("error")}
                    className={cn(
                      "h-full w-full object-contain transition-opacity duration-300",
                      qrState === "loading" ? "opacity-0" : "opacity-100"
                    )}
                  />
                )}
                {qrState === "loading" ? (
                  <CatIcon name="refresh-cw" className="absolute h-4 w-4 animate-spin text-slate-300" />
                ) : null}
              </span>
              <p className="text-center text-[10px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                {t("rcptQrHint")}
              </p>
            </div>
          ) : null}
        </div>
      </main>

      {/* ------------------------------------------------ footer -------- */}
      <footer className="print:hidden safe-bottom mt-auto border-t border-slate-200/70 bg-white/70 py-6 backdrop-blur-sm dark:border-white/[0.07] dark:bg-white/[0.02]">
        <p className="flex items-center justify-center gap-1.5 text-[11px] font-bold text-slate-400 dark:text-slate-500">
          {orgName}
          <span className="text-slate-300 dark:text-slate-600" aria-hidden="true">•</span>
          <a
            href={`/sites/${instanceId}`}
            className="rounded-lg px-1.5 py-0.5 font-extrabold text-gradient transition hover:bg-slate-100 dark:hover:bg-white/5"
          >
            {t("rcptPageVisitSite")}
          </a>
        </p>
      </footer>
    </div>
  );
}

export default ReceiptPageView;
