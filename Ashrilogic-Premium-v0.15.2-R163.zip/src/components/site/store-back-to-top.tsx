"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";

/** show the button once the page is scrolled this far (px) */
const SHOW_AFTER = 600;

/**
 * ROUND 56 — the storefront's own back-to-top control.
 *
 * Mirrors the landing's scroll-progress-ring pattern but is THEME-AWARE
 * (the ring + inner button carry the workspace brand gradient) and pinned
 * to the inline-END corner — the inline-start corner belongs to the cart
 * FAB. Long product grids make this a daily-use affordance; 52px target
 * (≥44px touch requirement), respects reduced-motion.
 */
export function StoreBackToTop({ c1, c2 }: { c1: string; c2: string }) {
  const { t } = useT();
  const [visible, setVisible] = useState(false);
  const [progress, setProgress] = useState(0);
  const reducedMotion = useReducedMotion();

  useEffect(() => {
    let raf = 0;
    const update = () => {
      const scrollTop = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const pct = docHeight > 0 ? Math.min(1, scrollTop / docHeight) : 0;
      setProgress(pct);
      setVisible(scrollTop > SHOW_AFTER);
    };
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll, { passive: true });
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  // SVG ring geometry
  const size = 52;
  const stroke = 3;
  const r = (size - stroke) / 2;
  const circumference = 2 * Math.PI * r;
  const dashOffset = circumference * (1 - progress);
  /* unique gradient id per theme pair — two instances never collide */
  const gradientId = `store-btt-${c1.slice(1)}-${c2.slice(1)}`;

  return (
    <AnimatePresence>
      {visible ? (
        <motion.button
          type="button"
          onClick={() => window.scrollTo({ top: 0, behavior: reducedMotion ? "auto" : "smooth" })}
          aria-label={t("backToTop")}
          title={t("backToTop")}
          initial={reducedMotion ? { opacity: 0 } : { opacity: 0, scale: 0.5, y: 12 }}
          animate={reducedMotion ? { opacity: 1 } : { opacity: 1, scale: 1, y: 0 }}
          exit={reducedMotion ? { opacity: 0 } : { opacity: 0, scale: 0.5, y: 12 }}
          transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
          className="focus-glow fixed bottom-5 end-5 z-40 grid cursor-pointer place-items-center rounded-full active:scale-95 sm:bottom-8 sm:end-8"
          style={{ width: size, height: size }}
        >
          {/* progress ring SVG (track + themed progress arc) */}
          <svg
            width={size}
            height={size}
            className="absolute inset-0 -rotate-90"
            aria-hidden="true"
          >
            <circle
              cx={size / 2}
              cy={size / 2}
              r={r}
              fill="none"
              strokeWidth={stroke}
              className="stroke-slate-200/70 dark:stroke-white/10"
            />
            <circle
              cx={size / 2}
              cy={size / 2}
              r={r}
              fill="none"
              strokeWidth={stroke}
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={dashOffset}
              className="transition-[stroke-dashoffset] duration-150 ease-out"
              style={{ stroke: `url(#${gradientId})` }}
            />
            <defs>
              <linearGradient id={gradientId} x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor={c1} />
                <stop offset="100%" stopColor={c2} />
              </linearGradient>
            </defs>
          </svg>
          {/* inner themed button */}
          <span
            className="grid h-9 w-9 place-items-center rounded-full text-white shadow-lg transition-shadow duration-300 hover:shadow-xl"
            style={{
              backgroundImage: `linear-gradient(135deg, ${c1}, ${c2})`,
              boxShadow: `0 10px 24px -8px ${c1}bb`,
            }}
            aria-hidden="true"
          >
            <CatIcon name="arrow-up" className="h-4 w-4" />
          </span>
        </motion.button>
      ) : null}
    </AnimatePresence>
  );
}

export default StoreBackToTop;
