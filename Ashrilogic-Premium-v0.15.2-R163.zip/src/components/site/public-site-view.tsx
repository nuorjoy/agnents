"use client";

/**
 * Ashrilogic V2 — the PUBLIC WEBSITE rendered for a provisioned system
 * (round 24, /sites/[instanceId]).
 *
 * A complete, professional organization website:
 *  - sticky blur header with the org brand, anchor nav, the unified-account
 *    entry (ROUND 70; ROUND 85 — guests are LINKED to the dedicated
 *    account page, signed-in visitors get the lazy account sheet), AR/EN +
 *    theme toggles and a contact CTA;
 *  - hero with the theme accent (badge → headline → tagline → copy →
 *    two CTAs → live stats), a strip of the system's real module chips;
 *  - services grid, about section with org facts, CTA band;
 *  - contact section: copy-to-clipboard info cards + a real inquiry form
 *    that files a support ticket LINKED to this system (lands in the
 *    admin inbox with instanceId);
 *  - footer with the "powered by Ashrilogic" attribution.
 *
 * Owner preview mode (draft site + session) shows an amber banner instead
 * of 404, so the dashboard's live-preview iframe always renders the real
 * page. Published pages ping the visit counter once per session.
 *
 * ROUND 57 — FULL SEPARATION: the e-commerce store NEVER appears inside
 * the website — no gateway band, no nav link, no product previews, zero
 * store queries on this page. The storefront is its own standalone entity
 * served at /sites/[instanceId]/store (src/components/site/
 * storefront-view.tsx); this page is a pure organization website.
 *
 * Fully AR/EN (RTL/LTR), dark/light aware, mobile-first, sticky footer.
 */
import { Fragment, useEffect, useState } from "react";
import type { ReactNode } from "react";
import { useMutation } from "@tanstack/react-query";
import { useTheme } from "next-themes";
import dynamic from "next/dynamic";
import { toast } from "sonner";
import { MODULE_MAP } from "@/data/catalog";
import {
  DEFAULT_SITE_BLOCKS,
  TOP_LEVEL_SITE_BLOCKS,
  isBlockVisible,
  type InstanceDTO,
  type SiteBlockLayout,
  type SiteDTO,
} from "@/lib/types";
import { useT } from "@/lib/i18n";
import { pingSiteVisit, sendSiteInquiry } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { grad, hexAlpha } from "@/lib/utils";
import { siteTheme } from "@/lib/site-themes";
import { fontVars, accentVars, surfaceLangs } from "@/lib/surface-styling";
import { SurfaceLangSwitcher } from "@/components/site/surface-lang-switcher";
import { SOCIAL_LINKS } from "@/lib/social";
import { useDocumentTitle } from "@/hooks/use-document-title";
import { useBrandFavicon } from "@/hooks/use-brand-favicon";
import { SkipLink } from "@/components/skip-link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Reveal } from "@/components/landing/reveal";
import {
  StoreAccountButton,
  StoreAccountProvider,
  useStoreAccountMirror,
} from "@/components/site/store-account";
import { countryName, nf } from "@/lib/format";

/* ------------------------------------------------------------------ */
/* ROUND 85 — lazy account sheet                                         */
/* ------------------------------------------------------------------ */

/** The signed-in account home is a SEPARATE lazy chunk
 * (store-account-sheet.tsx, split out of store-account.tsx in ROUND 85):
 * guests never download it — the dedicated account page
 * (/sites/[id]/account) serves them now — and the website's first paint
 * skips the whole panel bundle. */

/* ------------------------------------------------ contact form -------- */

function InquiryForm({ instanceId }: { instanceId: string }) {
  const { t } = useT();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  /* ROUND 70 — unified account: the signed-in customer's identity prefills
   * the inquiry once the session probe resolves (previous-value pattern —
   * values the visitor already typed are never clobbered; the email rides
   * the account's sealed address so the ticket's blind index lands on the
   * customer's service record in the owner's console automatically). */
  const account = useStoreAccountMirror();
  const [prevAccount, setPrevAccount] = useState(account);
  if (account !== prevAccount) {
    setPrevAccount(account);
    if (account) {
      if (!name.trim()) setName(account.name);
      if (!email.trim()) setEmail(account.email);
    }
  }

  const send = useMutation({
    mutationFn: () =>
      sendSiteInquiry(instanceId, { name: name.trim(), email: email.trim(), message: message.trim() }),
    onSuccess: () => {
      toast.success(t("siteFormSent"));
      setName("");
      setEmail("");
      setMessage("");
    },
    onError: (e: Error) => {
      toast.error(e.message || t("siteFormErr"));
    },
  });

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) {
      toast.error(t("gateErrEmpty"));
      return;
    }
    send.mutate();
  };

  if (send.isSuccess) {
    return (
      <div className="rounded-2xl border border-emerald-300/60 bg-emerald-50 p-6 text-center dark:border-emerald-500/30 dark:bg-emerald-500/10">
        <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
          <CatIcon name="check" className="h-6 w-6" />
        </span>
        <p className="mt-3 font-display text-[15px] font-extrabold text-emerald-700 dark:text-emerald-300">
          {t("siteFormSent")}
        </p>
        <p className="mt-1 text-[12.5px] leading-relaxed text-emerald-600/80 dark:text-emerald-400/80">
          {t("siteFormSentDesc")}
        </p>
        <Button
          variant="outline"
          size="sm"
          onClick={() => send.reset()}
          className="mt-4 h-9 rounded-xl border-emerald-300/70 px-4 text-[12px] font-bold text-emerald-700 hover:bg-emerald-100 dark:border-emerald-500/40 dark:text-emerald-300 dark:hover:bg-emerald-500/10"
        >
          {t("siteFormAgain")}
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-3.5">
      {/* ROUND 70 — linked-account chip: shown while the session is live so
          the visitor knows the inquiry rides their unified account record */}
      {account ? (
        <div
          role="status"
          className="flex items-center gap-2.5 rounded-xl border px-3.5 py-2.5"
          style={{
            borderColor: "rgba(16,185,129,0.35)",
            backgroundColor: "rgba(16,185,129,0.08)",
          }}
        >
          <span
            aria-hidden="true"
            className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-400"
          >
            <CatIcon name="badge-check" className="h-4 w-4" />
          </span>
          <p className="min-w-0 flex-1 text-[11.5px] font-bold leading-relaxed text-emerald-700 dark:text-emerald-300">
            {t("siteFormAcctHint")}
          </p>
        </div>
      ) : null}
      <div className="grid gap-3.5 sm:grid-cols-2">
        <div className="space-y-1.5">
          <Label htmlFor="site-inq-name" className="text-[12px] font-bold">
            {t("siteFormName")}
          </Label>
          <Input
            id="site-inq-name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder={t("siteFormNamePh")}
            maxLength={80}
            autoComplete="name"
            className="h-11 rounded-xl"
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="site-inq-email" className="text-[12px] font-bold">
            {t("siteFormEmail")}
          </Label>
          <Input
            id="site-inq-email"
            type="email"
            dir="ltr"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="name@email.com"
            maxLength={160}
            autoComplete="email"
            className="h-11 rounded-xl text-start"
          />
        </div>
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="site-inq-msg" className="text-[12px] font-bold">
          {t("siteFormMessage")}
        </Label>
        <textarea
          id="site-inq-msg"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder={t("siteFormMessagePh")}
          maxLength={1200}
          rows={4}
          className="w-full resize-none rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-[13px] shadow-sm outline-none transition placeholder:text-slate-400 focus:border-brand-400 focus:ring-2 focus:ring-brand-400/20 dark:border-white/10 dark:bg-white/[0.04] dark:text-white dark:placeholder:text-slate-500"
        />
      </div>
      <Button
        type="submit"
        disabled={send.isPending}
        className="h-11 w-full gap-2 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 text-[13px] font-bold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-[0.99] dark:from-brand-500 dark:to-brand-400"
      >
        {send.isPending ? (
          <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
        ) : (
          <CatIcon name="send" className="h-4 w-4" />
        )}
        {send.isPending ? t("siteFormSending") : t("siteFormSubmit")}
      </Button>
    </form>
  );
}

/* ------------------------------------------------ copy chip ----------- */

function CopyRow({
  icon,
  value,
  label,
  ltr,
}: {
  icon: string;
  value: string;
  label: string;
  ltr?: boolean;
}) {
  const { t } = useT();
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      toast.success(t("toastCopied"));
    } catch {
      toast.error(t("errorText"));
    }
  };
  return (
    <button
      type="button"
      onClick={copy}
      className="group flex w-full items-center gap-3 rounded-2xl border border-slate-200 bg-white p-3.5 text-start transition hover:border-transparent hover:shadow-lift dark:border-white/10 dark:bg-white/[0.03] dark:hover:bg-white/[0.05]"
      aria-label={`${t("toastCopied")} — ${label}`}
    >
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-slate-100 text-slate-500 transition group-hover:bg-brand-500/10 group-hover:text-brand-600 dark:bg-white/5 dark:text-slate-400">
        <CatIcon name={icon} className="h-4 w-4" />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block text-[10.5px] font-bold uppercase tracking-wide text-slate-400 dark:text-slate-500">
          {label}
        </span>
        <span
          className="block truncate font-mono text-[13px] font-semibold text-slate-800 dark:text-slate-200"
          dir={ltr ? "ltr" : undefined}
        >
          {value}
        </span>
      </span>
      <CatIcon
        name="copy"
        className="h-3.5 w-3.5 shrink-0 text-slate-300 transition group-hover:text-brand-500 dark:text-slate-600"
      />
    </button>
  );
}

/* ------------------------------------------------ the view ------------ */

export interface PublicSiteViewProps {
  site: SiteDTO;
  instance: InstanceDTO;
  membersCount: number;
  systemIcon: string;
  systemNameAr: string;
  systemNameEn: string;
  categoryIconColor: { c1: string; c2: string };
  preview: boolean;
}

export function PublicSiteView({
  site,
  instance,
  membersCount,
  systemIcon,
  systemNameAr,
  systemNameEn,
  categoryIconColor,
  preview,
}: PublicSiteViewProps) {
  const { t, lang } = useT();
  const { resolvedTheme, setTheme } = useTheme();
  const [navOpen, setNavOpen] = useState(false);
  /* ROUND 70 — THE UNIFIED ACCOUNT: the same SiteCustomer credential now
   * serves BOTH online services of this system — the website AND the store.
   * The customer session cookie is instance-scoped (not store-scoped), so
   * mounting the account provider here gives the website the identical
   * sign-in state the storefront sees: register on either surface, use it
   * everywhere. Guests see the sign-in entry (ROUND 85: it LINKS to the
   * dedicated account page — no popup); signed-in visitors see their
   * initials avatar + the full account sheet (profile / addresses / cards /
   * orders — the store orders ride the same query keys). */

  /* ROUND 75 — the emailed verification link redirects here with
   * ?verified=1 (confirmed) or ?verified=0 (expired / consumed / bad
   * shape). Turn the flag into a toast once, then scrub it from the URL so
   * a refresh (or a shared link) never re-toasts; the account provider's
   * probe refetches naturally on load, so a successful verification flips
   * the sheet's banner + chip without any extra wiring. */
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const flag = params.get("verified");
    if (flag !== "1" && flag !== "0") return;
    params.delete("verified");
    const qs = params.toString();
    const next = `${window.location.pathname}${qs ? `?${qs}` : ""}${window.location.hash}`;
    window.history.replaceState(window.history.state, "", next);
    if (flag === "1") {
      toast.success(t("siteVerifiedToast"));
    } else {
      toast.error(t("siteVerifyFailedToast"));
    }
  }, [t]);

  const theme = siteTheme(site.theme);
  const c1 = theme.c1;
  const c2 = theme.c2;
  const ar = lang === "ar";
  const systemName = ar ? systemNameAr : systemNameEn;
  /* round 32 — bilingual authored content: in EN mode every translated
   * field renders its English text; untranslated fields gracefully fall
   * back to the Arabic primary (per field, so partial translations are
   * safe and never mix mid-sentence). */
  const en = site.content.en;
  const pick = (enVal: string | undefined, arVal: string): string =>
    !ar && typeof enVal === "string" && enVal.trim().length > 0 ? enVal : arVal;
  const orgName = pick(en?.heroTitle, site.content.heroTitle || instance.org.name);
  const tagline = pick(en?.tagline, site.content.tagline);
  const heroDesc = pick(en?.heroDesc, site.content.heroDesc);
  const aboutTitle = pick(en?.aboutTitle, site.content.aboutTitle);
  const aboutText = pick(en?.about, site.content.about);
  const workingHours = pick(en?.workingHours, site.content.workingHours);
  const contactAddress = pick(en?.contactAddress, site.content.contactAddress);
  const sinceYear = new Date(instance.createdAt).getFullYear();
  const teamSize = membersCount + 1;
  const country = countryName(lang, instance.org.country);

  /* round 35 — canvas layout (order + visibility of the sections). Absent
   * layout -> the default order (the historical rendering, byte-identical
   * for every existing site); invisible blocks are skipped below. */
  const layoutBlocks: SiteBlockLayout[] = site.content.layout?.blocks ?? DEFAULT_SITE_BLOCKS;
  const visible = (key: string) =>
    isBlockVisible(layoutBlocks, key as Parameters<typeof isBlockVisible>[1]);
  const orderedSections = layoutBlocks.filter((b) =>
    (TOP_LEVEL_SITE_BLOCKS as readonly string[]).includes(b.key)
  );

  /* round 29 → ROUND 84 — language-aware tab title: the PAGE NAME ONLY (the
   * site's own name — no system-name suffix), following the AR/EN toggle. */
  useDocumentTitle("docTitleSite", { org: orgName });

  /* round 29 — public social links (registry order, href-filtered) */
  const socialLinks = site.content.socialLinks
    .filter((l) => l.href.trim().length > 0 && /^https?:\/\//.test(l.href.trim()))
    .map((l) => {
      const meta = SOCIAL_LINKS.find((s) => s.icon === l.icon);
      return {
        icon: l.icon,
        href: l.href.trim(),
        color: meta?.color ?? "#64748b",
        label: meta ? (ar ? meta.labelAr : meta.labelEn) : l.icon,
      };
    });
  const whatsappLink = socialLinks.find((l) => l.icon === "whatsapp") ?? null;

  /* ROUND 67 — the org identity becomes the browser-tab favicon while the
     site is open, server-composed as a PREMIUM CIRCULAR badge (logo + the
     platform's signature gradient ring; the circular brand mark when no
     logo is stored). The logo ref doubles as a cache-buster; removed on
     unmount so the tab returns to the platform icon. */
  const logoUrl = site.content.logoUrl;
  useBrandFavicon(site.instanceId, logoUrl || undefined);

  /* icon flips via CSS (`dark:` variants) — no hydration mismatch, no
     mounted-state; the target theme is read at click time (always fresh) */

  /* visit ping — once per browser session, published pages only */
  useEffect(() => {
    if (preview) return;
    const key = `ashrilogic-site-visit:${site.instanceId}`;
    try {
      if (sessionStorage.getItem(key)) return;
      sessionStorage.setItem(key, "1");
    } catch {
      /* private mode — still ping once per mount */
    }
    pingSiteVisit(site.instanceId).catch(() => {
      /* counter is best-effort */
    });
  }, [preview, site.instanceId]);

  /* ROUND 57 — the store is a FULLY standalone entity: this page runs ZERO
   * store queries and never renders a store link, gateway or preview. The
   * storefront is reachable only via its own URL (/sites/[id]/store). */

  const navItems = (
    [
      { href: "#services", label: t("siteNavServices"), block: "services" },
      { href: "#about", label: t("siteNavAbout"), block: "about" },
      { href: "#contact", label: t("siteNavContact"), block: "contact" },
    ] as const
  ).filter((item) => visible(item.block));

  const stats = [
    { value: nf(lang, site.content.services.length), label: t("siteStatsServices") },
    { value: nf(lang, instance.modules.length), label: t("siteStatsModules") },
    { value: nf(lang, teamSize), label: t("siteStatsTeam") },
    { value: nf(lang, sinceYear), label: t("siteStatsSince") },
  ];
  /* ---------------- round 35 — section order (canvas layout) ----------------
   * The five renderable sections, held as values so <main> can render them
   * in the owner-authored block order (invisible blocks skipped; an absent
   * layout yields the historical default order — byte-identical output). */
  const sectionHero = (
        /* ------------------------------------------------ hero ---------- */
        <section className="relative overflow-hidden px-4 pb-16 pt-14 sm:px-6 sm:pt-20 lg:pb-20 lg:pt-24">
          <div className="mx-auto max-w-6xl">
            <div className="mx-auto max-w-3xl text-center">
              <Reveal>
                <span
                  className="inline-flex items-center gap-2 rounded-full border px-3.5 py-1.5 text-[11px] font-extrabold"
                  style={{
                    borderColor: hexAlpha(c1, 0.35),
                    backgroundColor: hexAlpha(c1, 0.08),
                    color: c1,
                  }}
                >
                  <CatIcon name={systemIcon} className="h-[12px] w-[12px]" />
                  {systemName}
                </span>
              </Reveal>

              <Reveal delay={0.06}>
                <h1 className="mt-5 font-display text-[30px] font-black leading-[1.15] tracking-tight text-slate-900 dark:text-white sm:text-5xl lg:text-[56px]">
                  {orgName}
                </h1>
              </Reveal>

              {tagline ? (
                <Reveal delay={0.1}>
                  <p
                    className="mt-4 font-display text-[15px] font-extrabold sm:text-[18px]"
                    style={{ color: c1 }}
                  >
                    {tagline}
                  </p>
                </Reveal>
              ) : null}

              {heroDesc ? (
                <Reveal delay={0.14}>
                  <p className="mx-auto mt-4 max-w-2xl text-[13.5px] leading-relaxed text-slate-600 dark:text-slate-400 sm:text-[15px]">
                    {heroDesc}
                  </p>
                </Reveal>
              ) : null}

              {/* round 35 — hero CTAs only target visible sections */}
              {visible("contact") || visible("services") ? (
                <Reveal delay={0.18}>
                  <div className="mt-8 flex flex-wrap items-center justify-center gap-2.5">
                    {visible("contact") ? (
                      <a
                        href="#contact"
                        className="inline-flex h-11 items-center gap-2 rounded-2xl px-6 text-[13px] font-bold text-white shadow-lg transition hover:brightness-110 active:scale-95"
                        style={{
                          backgroundImage: grad(c1, c2),
                          boxShadow: `0 14px 30px -12px ${hexAlpha(c1, 0.75)}`,
                        }}
                      >
                        <CatIcon name="message-circle" className="h-4 w-4" />
                        {t("siteHeroCtaContact")}
                      </a>
                    ) : null}
                    {visible("services") ? (
                      <a
                        href="#services"
                        className="inline-flex h-11 items-center gap-2 rounded-2xl border border-slate-200 bg-white px-6 text-[13px] font-bold text-slate-700 shadow-sm transition hover:border-transparent hover:shadow-lift active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200"
                      >
                        <CatIcon name="sparkles" className="h-4 w-4" />
                        {t("siteHeroCtaServices")}
                      </a>
                    ) : null}
                  </div>
                </Reveal>
              ) : null}

              {/* stats */}
              <Reveal delay={0.24}>
                <dl className="mx-auto mt-10 grid max-w-2xl grid-cols-2 gap-3 sm:grid-cols-4">
                  {stats.map((stat) => (
                    <div
                      key={stat.label}
                      className="rounded-2xl border border-slate-200/80 bg-white/80 px-3 py-3.5 text-center backdrop-blur-sm dark:border-white/10 dark:bg-white/[0.03]"
                    >
                      <dd
                        className="font-display text-[22px] font-black tabular-nums"
                        style={{ color: c1 }}
                      >
                        {stat.value}
                      </dd>
                      <dt className="mt-0.5 text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
                        {stat.label}
                      </dt>
                    </div>
                  ))}
                </dl>
              </Reveal>
            </div>

            {/* real module chips of the linked system */}
            {instance.modules.length > 0 ? (
              <Reveal delay={0.3}>
                <div className="mt-10 border-t border-dashed border-slate-200 pt-6 dark:border-white/10">
                  <p className="text-center text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                    {t("siteModulesStrip")}
                  </p>
                  <div className="mt-3 flex flex-wrap items-center justify-center gap-1.5">
                    {instance.modules.slice(0, 12).map((key) => {
                      const m = MODULE_MAP[key];
                      return (
                        <span
                          key={key}
                          className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-[11px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
                        >
                          <span
                            className="grid h-4 w-4 place-items-center rounded text-white"
                            style={{
                              backgroundImage: grad(categoryIconColor.c1, categoryIconColor.c2),
                            }}
                            aria-hidden="true"
                          >
                            <CatIcon name={m?.icon ?? "cubes"} className="h-[8px] w-[8px]" />
                          </span>
                          {m ? (ar ? m.nameAr : m.nameEn) : key}
                        </span>
                      );
                    })}
                  </div>
                </div>
              </Reveal>
            ) : null}
          </div>
        </section>
  );

  const sectionServices = site.content.services.length > 0 ? (
          <section
            id="services"
            className="cv-auto scroll-mt-20 border-y border-slate-200/70 bg-white/60 px-4 py-16 backdrop-blur-sm dark:border-white/[0.07] dark:bg-white/[0.02] sm:px-6 lg:py-20"
          >
            <div className="mx-auto max-w-6xl">
              <div className="mx-auto max-w-2xl text-center">
                <Reveal>
                  <span
                    className="inline-flex items-center gap-2 rounded-full border px-3.5 py-1.5 text-[11px] font-extrabold"
                    style={{
                      borderColor: hexAlpha(c1, 0.35),
                      backgroundColor: hexAlpha(c1, 0.08),
                      color: c1,
                    }}
                  >
                    <CatIcon name="sparkles" className="h-[12px] w-[12px]" />
                    {t("siteServicesBadge")}
                  </span>
                </Reveal>
                <Reveal delay={0.06}>
                  <h2 className="mt-4 font-display text-[26px] font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-4xl">
                    {t("siteServicesTitle")}
                  </h2>
                </Reveal>
                <Reveal delay={0.1}>
                  <p className="mx-auto mt-3 max-w-xl text-[13.5px] leading-relaxed text-slate-600 dark:text-slate-400 sm:text-[14.5px]">
                    {t("siteServicesDesc", { org: orgName })}
                  </p>
                </Reveal>
              </div>

              <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {site.content.services.map((service, i) => (
                  <Reveal key={`${service.title}-${i}`} delay={0.05 * (i % 3)} className="min-w-0">
                    <article className="card-in group h-full rounded-3xl border border-slate-200/80 bg-white p-5 shadow-soft transition-all duration-300 hover:-translate-y-1 hover:border-transparent hover:shadow-lift dark:border-white/10 dark:bg-white/[0.035]">
                      <span
                        className="grid h-12 w-12 place-items-center rounded-2xl text-white shadow-lg"
                        style={{
                          backgroundImage: grad(c1, c2),
                          boxShadow: `0 10px 24px -10px ${hexAlpha(c1, 0.8)}`,
                        }}
                      >
                        <CatIcon name={service.icon} className="h-[19px] w-[19px]" />
                      </span>
                      <h3 className="mt-4 font-display text-[16px] font-extrabold text-slate-900 dark:text-white">
                        {pick(service.titleEn, service.title)}
                      </h3>
                      {service.desc ? (
                        <p className="mt-1.5 text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
                          {pick(service.descEn, service.desc)}
                        </p>
                      ) : null}
                    </article>
                  </Reveal>
                ))}
              </div>
            </div>
          </section>
  ) : null;

  const sectionAbout = (
        /* ------------------------------------------------ about --------- */
        <section id="about" className="cv-auto scroll-mt-20 px-4 py-16 sm:px-6 lg:py-20">
          <div className="mx-auto grid max-w-6xl items-start gap-8 lg:grid-cols-[1.2fr_0.8fr]">
            <Reveal className="min-w-0">
              <div>
                <span
                  className="inline-flex items-center gap-2 rounded-full border px-3.5 py-1.5 text-[11px] font-extrabold"
                  style={{
                    borderColor: hexAlpha(c1, 0.35),
                    backgroundColor: hexAlpha(c1, 0.08),
                    color: c1,
                  }}
                >
                  <CatIcon name="house" className="h-[12px] w-[12px]" />
                  {t("siteAboutBadge")}
                </span>
                <h2 className="mt-4 font-display text-[26px] font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-4xl">
                  {aboutTitle}
                </h2>
                <p className="mt-5 whitespace-pre-line text-[14px] leading-[1.9] text-slate-600 dark:text-slate-400 sm:text-[15px]">
                  {aboutText}
                </p>
              </div>
            </Reveal>

            <Reveal delay={0.08} className="min-w-0">
              <aside className="overflow-hidden rounded-3xl border border-slate-200/80 bg-white shadow-soft dark:border-white/10 dark:bg-white/[0.03]">
                <div className="px-5 py-4" style={{ backgroundImage: grad(c1, c2, 135) }}>
                  <p className="flex items-center gap-2 font-display text-[13px] font-extrabold text-white">
                    <CatIcon name="server" className="h-4 w-4" />
                    {t("siteFactsTitle")}
                  </p>
                </div>
                <dl className="divide-y divide-slate-100 dark:divide-white/[0.06]">
                  {[
                    { icon: "boxes", label: t("siteFactsSystem"), value: systemName },
                    {
                      icon: "cubes",
                      label: t("siteFactsModules"),
                      value: `${nf(lang, instance.modules.length)} ${t("siteStatsModulesUnit")}`,
                    },
                    {
                      icon: "users",
                      label: t("siteFactsTeam"),
                      value: `${nf(lang, teamSize)}`,
                    },
                    ...(country
                      ? [{ icon: "globe", label: t("userSheetCountry"), value: country }]
                      : []),
                    ...(instance.org.timezone
                      ? [{ icon: "clock", label: t("userSheetSystem"), value: instance.org.timezone }]
                      : []),
                  ].map((fact) => (
                    <div key={fact.label} className="flex items-center gap-3 px-5 py-3.5">
                      <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-slate-100 text-slate-500 dark:bg-white/5 dark:text-slate-400">
                        <CatIcon name={fact.icon} className="h-3.5 w-3.5" />
                      </span>
                      <dt className="text-[11.5px] font-bold text-slate-400 dark:text-slate-500">
                        {fact.label}
                      </dt>
                      <dd
                        className="ms-auto max-w-[55%] truncate text-[12.5px] font-extrabold text-slate-800 dark:text-slate-200"
                        dir={fact.value.match(/^[A-Za-z0-9\s/+-]+$/) ? "ltr" : undefined}
                      >
                        {fact.value}
                      </dd>
                    </div>
                  ))}
                </dl>
              </aside>
            </Reveal>
          </div>
        </section>
  );

  const sectionCta = (
        /* ------------------------------------------------ CTA band ------ */
        <section className="px-4 pb-16 sm:px-6">
          <div className="mx-auto max-w-6xl">
            <Reveal>
              <div
                className="relative overflow-hidden rounded-[28px] px-6 py-12 text-center sm:px-10 sm:py-14"
                style={{ backgroundImage: grad(c1, c2, 120) }}
              >
                <div
                  className="pointer-events-none absolute inset-0 opacity-20"
                  style={{
                    backgroundImage:
                      "radial-gradient(circle at 20% 20%, rgba(255,255,255,.5) 0, transparent 40%), radial-gradient(circle at 80% 80%, rgba(255,255,255,.4) 0, transparent 40%)",
                  }}
                  aria-hidden="true"
                />
                <h2 className="relative font-display text-[24px] font-black tracking-tight text-white sm:text-[32px]">
                  {t("siteCtaTitle", { org: orgName })}
                </h2>
                <p className="relative mx-auto mt-3 max-w-xl text-[13.5px] leading-relaxed text-white/85 sm:text-[15px]">
                  {t("siteCtaDesc")}
                </p>
                {/* round 35 — the CTA button follows the contact block's visibility */}
                {visible("contact") ? (
                  <a
                    href="#contact"
                    className="relative mt-7 inline-flex h-12 items-center gap-2 rounded-2xl bg-white px-7 text-[13.5px] font-extrabold shadow-xl transition hover:brightness-95 active:scale-95"
                    style={{ color: c1 }}
                  >
                    <CatIcon name="send" className="h-4 w-4" />
                    {t("siteCtaBtn")}
                  </a>
                ) : null}
              </div>
            </Reveal>
          </div>
        </section>
  );

  /* contact-inner cards (hours / social blocks) */
  const hoursCard = workingHours ? (
                    <div className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
                      <span
                        className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white"
                        style={{ backgroundImage: grad(c1, c2) }}
                      >
                        <CatIcon name="clock" className="h-4 w-4" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block text-[10.5px] font-bold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                          {t("siteHoursFact")}
                        </span>
                        <span className="block text-[12.5px] font-bold leading-relaxed text-slate-800 dark:text-slate-200">
                          {workingHours}
                        </span>
                      </span>
                    </div>
                  ) : null;

  const socialCard = socialLinks.length > 0 ? (
                    <div className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/[0.03]">
                      <p className="mb-3 text-[10.5px] font-bold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                        {t("siteSocialFollow")}
                      </p>
                      <div className="flex flex-wrap items-center gap-2">
                        {socialLinks.map((l) => (
                          <a
                            key={l.icon}
                            href={l.href}
                            target="_blank"
                            rel="noopener noreferrer"
                            title={l.label}
                            aria-label={l.label}
                            className="grid h-10 w-10 place-items-center rounded-xl text-white shadow-md transition hover:-translate-y-0.5 hover:shadow-lg active:scale-95"
                            style={{ backgroundColor: l.color, boxShadow: `0 8px 18px -8px ${hexAlpha(l.color, 0.9)}` }}
                          >
                            <CatIcon name={l.icon} className="h-[17px] w-[17px]" />
                          </a>
                        ))}
                      </div>
                    </div>
                  ) : null;

  const contactInnerBlocks = layoutBlocks.filter(
    (b) => b.key === "hours" || b.key === "social"
  );

  const sectionContact = (
        /* ------------------------------------------------ contact ------- */
        <section
          id="contact"
          className="scroll-mt-20 border-t border-slate-200/70 bg-white/60 px-4 py-16 backdrop-blur-sm dark:border-white/[0.07] dark:bg-white/[0.02] sm:px-6 lg:py-20"
        >
          <div className="mx-auto max-w-6xl">
            <div className="mx-auto max-w-2xl text-center">
              <Reveal>
                <span
                  className="inline-flex items-center gap-2 rounded-full border px-3.5 py-1.5 text-[11px] font-extrabold"
                  style={{
                    borderColor: hexAlpha(c1, 0.35),
                    backgroundColor: hexAlpha(c1, 0.08),
                    color: c1,
                  }}
                >
                  <CatIcon name="message-circle" className="h-[12px] w-[12px]" />
                  {t("siteContactBadge")}
                </span>
              </Reveal>
              <Reveal delay={0.06}>
                <h2 className="mt-4 font-display text-[26px] font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-4xl">
                  {t("siteContactTitle")}
                </h2>
              </Reveal>
              <Reveal delay={0.1}>
                <p className="mx-auto mt-3 max-w-xl text-[13.5px] leading-relaxed text-slate-600 dark:text-slate-400 sm:text-[14.5px]">
                  {t("siteContactDesc")}
                </p>
              </Reveal>
            </div>

            <div className="mt-10 grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
              {/* info cards */}
              <Reveal className="min-w-0">
                <div className="space-y-3">
                  {site.content.contactEmail ? (
                    <CopyRow icon="mail" value={site.content.contactEmail} label={t("gateEmail")} ltr />
                  ) : null}
                  {site.content.contactPhone ? (
                    <CopyRow icon="phone" value={site.content.contactPhone} label={t("wzOrgPhone")} ltr />
                  ) : null}
                  {contactAddress ? (
                    <CopyRow icon="map-pin" value={contactAddress} label={t("wzOrgAddress")} />
                  ) : null}
                  {/* round 35 — the hours/social cards render inside the contact
                      column, ordered by their position in the layout blocks
                      array; invisible blocks are skipped (default: hours, social) */}
                  {contactInnerBlocks.map((block) =>
                    block.visible ? (
                      <Fragment key={block.key}>
                        {block.key === "hours" ? hoursCard : socialCard}
                      </Fragment>
                    ) : null
                  )}

                  <div className="rounded-2xl border border-dashed border-slate-300 bg-white/70 p-4 dark:border-white/10 dark:bg-white/[0.02]">
                    <p className="flex items-start gap-2.5 text-[12px] leading-relaxed text-slate-500 dark:text-slate-400">
                      <CatIcon name="shield-check" className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" />
                      {t("siteContactNote")}
                    </p>
                  </div>
                </div>
              </Reveal>

              {/* inquiry form (guest visitors — fields start empty) */}
              <Reveal delay={0.08} className="min-w-0">
                <div className="rounded-3xl border border-slate-200/80 bg-white p-5 shadow-soft dark:border-white/10 dark:bg-white/[0.03] sm:p-6">
                  <h3 className="font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                    {t("siteFormTitle")}
                  </h3>
                  <p className="mb-4 mt-1 text-[12px] text-slate-500 dark:text-slate-400">
                    {t("siteFormDesc")}
                  </p>
                  <InquiryForm instanceId={site.instanceId} />
                </div>
              </Reveal>
            </div>
          </div>
        </section>
  );

  /* hours/social render as INNER contact blocks (contactInnerBlocks), never at
     the top level — the Partial keyed by the full block union keeps the lookup
     noImplicitAny-safe while `orderedSections` only ever yields the 5 top-level
     keys (TOP_LEVEL_SITE_BLOCKS filter above). */
  const sectionNodes: Partial<Record<SiteBlockLayout["key"], ReactNode>> = {
    hero: sectionHero,
    services: sectionServices,
    about: sectionAbout,
    cta: sectionCta,
    contact: sectionContact,
  };

  return (
    <StoreAccountProvider instanceId={site.instanceId}>
    {/* ROUND 86 — per-surface styling scope: the owner-selected FONT
        (--font-sans-app/--font-display-app) and the site-theme ACCENT ramp
        (color-mix over the theme c1) re-resolve at this root, so every
        brand-* utility + .font-display element below follows the site's own
        identity instead of the platform default. Classes: surface-font-scope
        re-anchors the body stack, brand-scope re-resolves the brand-following
        tokens in BOTH light and dark (globals.css). */}
    <div
      className="brand-scope surface-font-scope relative flex min-h-screen flex-col bg-background"
      style={{ ...fontVars(site.content.siteFont), ...accentVars(theme.c1) }}
    >
      {/* skip-to-content — first focusable element (targets the main's #top) */}
      <SkipLink target="top" />

      {/* decorative background */}
      <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden="true" />
      <div
        className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[560px] opacity-60"
        style={{
          background: `radial-gradient(60% 50% at 50% 0%, ${hexAlpha(c1, 0.14)}, transparent 70%)`,
        }}
        aria-hidden="true"
      />

      {/* draft preview banner (owner / admin only) */}
      {preview ? (
        <div className="border-b border-amber-300/60 bg-amber-100/90 px-4 py-2 text-center backdrop-blur-sm dark:border-amber-500/30 dark:bg-amber-500/15">
          <p className="inline-flex items-center gap-2 text-[11.5px] font-extrabold text-amber-800 dark:text-amber-300">
            <CatIcon name="eye" className="h-3.5 w-3.5" />
            {t("sitePreviewBanner")}
          </p>
        </div>
      ) : null}

      {/* ------------------------------------------------ header --------- */}
      <header className="sticky top-0 z-40 border-b border-slate-200/70 bg-white/80 backdrop-blur-xl dark:border-white/[0.07] dark:bg-ink-950/80">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-3 px-4 sm:px-6">
          <a href="#top" className="flex min-w-0 items-center gap-2.5">
            {logoUrl ? (
              /* round 29 — the organization's own logo leads the header */
              <span
                className="grid h-10 w-10 shrink-0 place-items-center overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-lg dark:border-white/10 dark:bg-white/90"
                aria-hidden="true"
              >
                { }
                <img src={logoUrl} alt="" className="h-full w-full object-contain p-1" />
              </span>
            ) : (
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg"
                style={{ backgroundImage: grad(c1, c2), boxShadow: `0 8px 20px -8px ${hexAlpha(c1, 0.8)}` }}
              >
                <CatIcon name={systemIcon} className="h-[15px] w-[15px]" />
              </span>
            )}
            <span className="min-w-0 leading-none">
              <span className="block truncate font-display text-[14.5px] font-extrabold text-slate-900 dark:text-white">
                {orgName}
              </span>
              <span className="mt-0.5 hidden truncate text-[10.5px] font-bold text-slate-400 dark:text-slate-500 sm:block">
                {tagline}
              </span>
            </span>
          </a>

          <nav className="ms-auto hidden items-center gap-1 md:flex" aria-label={t("siteNavAria")}>
            {navItems.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="rounded-xl px-3.5 py-2 text-[12.5px] font-bold text-slate-600 transition hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-white/[0.06] dark:hover:text-white"
              >
                {item.label}
              </a>
            ))}
          </nav>

          <div className="ms-auto flex items-center gap-1.5 md:ms-0">
            {/* ROUND 70/85 — the unified-account entry (guest: link to the
             * dedicated account page · signed-in: initials avatar). Same
             * credential as the store — the session cookie is
             * instance-scoped. */}
            <StoreAccountButton
              instanceId={site.instanceId}
              authNext={`/sites/${site.instanceId}`}
              c1={c1}
              c2={c2}
            />

            {/* ROUND 86 — the visitor-language switcher obeys the owner's
                enabled set (Settings → التفضيلات → لغات الزوار) */}
            <SurfaceLangSwitcher langs={surfaceLangs(site.content.siteLangs)} />

            {/* theme toggle — icons flip via CSS, no hydration mismatch */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
              aria-label={t("siteThemeToggle")}
              className="h-11 w-11 rounded-xl text-slate-500 dark:text-slate-400"
            >
              <CatIcon name="sun" className="hidden h-4 w-4 dark:block" />
              <CatIcon name="moon" className="block h-4 w-4 dark:hidden" />
            </Button>

            {/* mobile nav toggle */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setNavOpen((v) => !v)}
              aria-expanded={navOpen}
              aria-label={t("siteNavAria")}
              className="h-11 w-11 rounded-xl text-slate-500 md:hidden dark:text-slate-400"
            >
              <CatIcon name={navOpen ? "x" : "menu"} className="h-4 w-4" />
            </Button>
            {/* round 35 — the contact CTA follows the contact block's visibility */}
            {visible("contact") ? (
              <Button
                size="sm"
                asChild
                className="hidden h-9 rounded-xl px-4 text-[12px] font-bold text-white shadow-lg sm:inline-flex"
                style={{
                  backgroundImage: grad(c1, c2),
                  boxShadow: `0 10px 24px -10px ${hexAlpha(c1, 0.8)}`,
                }}
              >
                <a href="#contact">{t("siteHeroCtaContact")}</a>
              </Button>
            ) : null}
          </div>
        </div>

        {/* mobile nav sheet */}
        {navOpen ? (
          <nav
            className="border-t border-slate-200/70 px-4 py-3 md:hidden dark:border-white/[0.07]"
            aria-label={t("siteNavAria")}
          >
            <div className="mx-auto flex max-w-6xl flex-col gap-1">
              {navItems.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  onClick={() => setNavOpen(false)}
                  className="rounded-xl px-3.5 py-2.5 text-[13px] font-bold text-slate-700 transition hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-white/[0.06]"
                >
                  {item.label}
                </a>
              ))}
              {visible("contact") ? (
                <a
                  href="#contact"
                  onClick={() => setNavOpen(false)}
                  className="mt-1 rounded-xl px-3.5 py-2.5 text-center text-[12.5px] font-bold text-white"
                  style={{ backgroundImage: grad(c1, c2) }}
                >
                  {t("siteHeroCtaContact")}
                </a>
              ) : null}
            </div>
          </nav>
        ) : null}
      </header>

      <main id="top" className="flex-1">
        {/* round 35 — the sections render in the owner's canvas order
            (invisible blocks are skipped; absent layout = the default
            order, byte-identical to the pre-canvas rendering).
            ROUND 57 — nothing store-related ever renders inside the
            website: the storefront is a fully standalone entity at
            /sites/[id]/store. */}
        {orderedSections.map((block) =>
          block.visible ? (
            <Fragment key={block.key}>{sectionNodes[block.key]}</Fragment>
          ) : null
        )}
      </main>

      {/* ------------------------------------------------ footer --------- */}
      <footer className="safe-bottom mt-auto border-t border-slate-200/70 bg-white/70 py-8 backdrop-blur-sm dark:border-white/[0.07] dark:bg-white/[0.02]">
        <div className="mx-auto flex max-w-6xl flex-col items-center gap-4 px-4 text-center sm:px-6">
          <div className="flex items-center gap-2.5">
            {logoUrl ? (
              <span
                className="grid h-9 w-9 place-items-center overflow-hidden rounded-xl border border-slate-200/80 bg-white shadow-md dark:border-white/10 dark:bg-white/90"
                aria-hidden="true"
              >
                { }
                <img src={logoUrl} alt="" className="h-full w-full object-contain p-1" />
              </span>
            ) : (
              <span
                className="grid h-8 w-8 place-items-center rounded-xl text-white shadow-lg"
                style={{ backgroundImage: grad(c1, c2) }}
              >
                <CatIcon name={systemIcon} className="h-[13px] w-[13px]" />
              </span>
            )}
            <div className="text-start leading-none">
              <p className="font-display text-[13px] font-extrabold text-slate-900 dark:text-white">
                {orgName}
              </p>
              <p className="mt-0.5 text-[10px] font-bold text-slate-400 dark:text-slate-500">
                © {nf(lang, sinceYear)} — {t("siteFooterRights")}
              </p>
            </div>
          </div>

          {/* round 35 — the footer social row follows the social block */}
          {visible("social") && socialLinks.length > 0 ? (
            <div className="flex flex-wrap items-center justify-center gap-2">
              {socialLinks.map((l) => (
                <a
                  key={`footer-${l.icon}`}
                  href={l.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  title={l.label}
                  aria-label={l.label}
                  className="grid h-8 w-8 place-items-center rounded-lg text-white/95 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md active:scale-95"
                  style={{ backgroundColor: l.color }}
                >
                  <CatIcon name={l.icon} className="h-[14px] w-[14px]" />
                </a>
              ))}
            </div>
          ) : null}

          {/* ROUND 84 (84-LEGAL) — the public legal pages (privacy & terms) */}
          <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-1.5">
            <a
              href={`/sites/${site.instanceId}/privacy`}
              className="inline-flex items-center gap-1.5 text-[11.5px] font-bold text-slate-400 transition hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300"
            >
              <CatIcon name="shield-check" className="h-3.5 w-3.5" />
              {t("legalPrivacyTitle")}
            </a>
            <span className="text-[10px] text-slate-300 dark:text-slate-600" aria-hidden="true">
              •
            </span>
            <a
              href={`/sites/${site.instanceId}/terms`}
              className="inline-flex items-center gap-1.5 text-[11.5px] font-bold text-slate-400 transition hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300"
            >
              <CatIcon name="scale" className="h-3.5 w-3.5" />
              {t("legalTermsTitle")}
            </a>
          </div>

          <p className="flex items-center gap-1.5 text-[11px] font-bold text-slate-400 dark:text-slate-500">
            {t("sitePoweredBy")}
            <a
              href="/"
              className="inline-flex items-center gap-1.5 rounded-lg px-2 py-1 font-extrabold text-gradient transition hover:bg-slate-100 dark:hover:bg-white/5"
            >
              <CatIcon name="boxes" className="h-3.5 w-3.5" />
              Ashrilogic
            </a>
          </p>
        </div>
      </footer>

      {/* round 29 — floating WhatsApp quick-chat button (follows the social block) */}
      {visible("social") && whatsappLink ? (
        <a
          href={whatsappLink.href}
          target="_blank"
          rel="noopener noreferrer"
          aria-label={t("siteWhatsAppChat")}
          title={t("siteWhatsAppChat")}
          className="fixed bottom-5 z-40 grid h-13 w-13 place-items-center rounded-2xl text-white shadow-xl transition hover:-translate-y-1 hover:shadow-2xl active:scale-95 end-5 sm:h-14 sm:w-14"
          style={{
            backgroundColor: "#25d366",
            boxShadow: "0 16px 32px -10px rgba(37, 211, 102, 0.75)",
          }}
        >
          <CatIcon name="whatsapp" className="h-6 w-6" />
        </a>
      ) : null}

      {/* ROUND 55 — the floating cart button + cart sheet moved to the
          standalone storefront page; the website itself is cart-free. */}

      {/* ------- ROUND 70/85 — unified account: the auth dialog is GONE
          (guests LINK to the dedicated account page — one credential, one
          account); the lazily-imported account sheet serves the signed-in
          visitor with the same panels the storefront mounts. */}
    </div>
    </StoreAccountProvider>
  );
}

export default PublicSiteView;
