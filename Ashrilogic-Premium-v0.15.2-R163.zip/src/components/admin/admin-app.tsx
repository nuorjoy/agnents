"use client";

/**
 * Ashrilogic — admin shell.
 *
 * Auth gate backed by `useAdminAuth` (server-verified HTTP-only cookie
 * session). Super-admin credentials are provisioned at bootstrap time
 * (scripts/bootstrap-admin.ts) and are never carried in source. On
 * mount the shell awaits a one-shot /api/admin/me restore so a valid cookie
 * session paints the panel directly (no login-card flash); anonymous
 * visitors get the premium login screen.
 *
 * When authed, renders the premium admin layout: sticky top bar (brand +
 * "Admin Panel V2" + logged-in identity chip + lang toggle + logout), left
 * sidebar (collapsible on mobile → horizontal pill nav) and the active view.
 *
 * ROUND 55 — logout returns to the CONTROL-PANEL LOGIN SCREEN (/admin/login)
 * instead of the public site: panel staff re-authenticate without a detour
 * through the marketing page, and the admin session ends where it started.
 */
import { useEffect, useRef, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { useTheme } from "next-themes";
import { toast } from "sonner";
import { useIsFetching, useQueryClient, useQuery } from "@tanstack/react-query";
import { useAdminAuth } from "@/lib/admin-auth";
import {
  fetchAdminMe,
  fetchAdminPlanOrders,
  fetchAdminSites,
  fetchAdminStores,
  fetchAdminUsers,
  fetchAuditEntries,
  fetchPackages,
  fetchPlatformSettings,
  fetchTickets,
} from "@/lib/api-client";
import { AdminNotifications } from "@/components/admin/admin-notifications";
import { AdminLogin } from "@/components/admin/admin-login";
import { AdminSidebar, type AdminView } from "@/components/admin/admin-sidebar";
import { useSidebarPin, ADMIN_SIDEBAR_PIN_KEY } from "@/hooks/use-sidebar-pin";
import { AdminOverview } from "@/components/admin/admin-overview";
import dynamic from "next/dynamic";
import { Skeleton } from "@/components/ui/skeleton";
import { AdminIdentityMenu } from "@/components/admin/admin-identity-menu";
import { LangMenu } from "@/components/lang-menu";
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { cn, grad } from "@/lib/utils";
import { useDocumentTitle } from "@/hooks/use-document-title";
import { TwoFactorCard } from "@/components/security/security-cards";
import type { I18nKey } from "@/lib/i18n";
import { SkipLink } from "@/components/skip-link";

/* ROUND 42 — performance: admin views (subscribers, sites, systems,
   activity, settings, admins, audit, packages, support, newsletter and
   the ⌘K palette) are lazy chunks — the /admin first paint ships only the
   shell + overview (+login for anonymous), the rest loads per view. */
function AdminViewSkeleton() {
  return (
    <div aria-busy="true" aria-label="Loading" className="space-y-4">
      <div className="flex items-center gap-3">
        <Skeleton className="h-10 w-10 rounded-2xl" />
        <div className="flex-1 space-y-2">
          <Skeleton className="h-5 w-64 rounded-lg" />
          <Skeleton className="h-3 w-96 max-w-full rounded-lg" />
        </div>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-24 w-full rounded-2xl" />
        ))}
      </div>
      <Skeleton className="h-80 w-full rounded-2xl" />
    </div>
  );
}

const AdminSubscribers = dynamic(
  () => import("@/components/admin/admin-subscribers").then((m) => m.AdminSubscribers),
  { ssr: false, loading: AdminViewSkeleton }
);
const AdminSites = dynamic(
  () => import("@/components/admin/admin-sites").then((m) => m.AdminSites),
  { ssr: false, loading: AdminViewSkeleton }
);
const AdminStores = dynamic(
  () => import("@/components/admin/admin-stores").then((m) => m.AdminStores),
  { ssr: false, loading: AdminViewSkeleton }
);
const AdminSystems = dynamic(
  () => import("@/components/admin/admin-systems").then((m) => m.AdminSystems),
  { ssr: false, loading: AdminViewSkeleton }
);
/* CONTENT SYSTEM — the official site's content consoles */
const AdminBlog = dynamic(
  () => import("@/components/admin/admin-blog").then((m) => m.AdminBlog),
  { ssr: false, loading: AdminViewSkeleton }
);
const AdminPartners = dynamic(
  () => import("@/components/admin/admin-partners").then((m) => m.AdminPartners),
  { ssr: false, loading: AdminViewSkeleton }
);
const AdminActivity = dynamic(
  () => import("@/components/admin/admin-activity").then((m) => m.AdminActivity),
  { ssr: false, loading: AdminViewSkeleton }
);
const AdminSettings = dynamic(
  () => import("@/components/admin/admin-settings").then((m) => m.AdminSettings),
  { ssr: false, loading: AdminViewSkeleton }
);
const AdminAdmins = dynamic(
  () => import("@/components/admin/admin-admins").then((m) => m.AdminAdmins),
  { ssr: false, loading: AdminViewSkeleton }
);
const AdminAudit = dynamic(
  () => import("@/components/admin/admin-audit").then((m) => m.AdminAudit),
  { ssr: false, loading: AdminViewSkeleton }
);
/* ROUND 87 — the platform trash console (سلة المحذوفات) */
const AdminTrash = dynamic(
  () => import("@/components/admin/admin-trash").then((m) => m.AdminTrash),
  { ssr: false, loading: AdminViewSkeleton }
);
/* ROUND 114 — the operations telemetry console (التشغيل) */
const AdminOps = dynamic(
  () => import("@/components/admin/admin-ops").then((m) => m.AdminOps),
  { ssr: false, loading: AdminViewSkeleton }
);
/* ROUND 117 — the platform legal documents console (المستندات القانونية) */
const AdminLegal = dynamic(
  () => import("@/components/admin/admin-legal").then((m) => m.AdminLegal),
  { ssr: false, loading: AdminViewSkeleton }
);
/* ROUND 142 — the official-site mobile-app storefront controls (تطبيق
   الموبايل): Google Play + App Store links + publish toggle. */
const AdminMobileApp = dynamic(
  () => import("@/components/admin/admin-mobile-app").then((m) => m.AdminMobileApp),
  { ssr: false, loading: AdminViewSkeleton }
);
const AdminPackages = dynamic(
  () => import("@/components/admin/admin-packages").then((m) => m.AdminPackages),
  { ssr: false, loading: AdminViewSkeleton }
);
/* ROUND 47 — activation requests (طلبات التفعيل) console view */
const AdminPlanOrders = dynamic(
  () => import("@/components/admin/admin-plan-orders").then((m) => m.AdminPlanOrders),
  { ssr: false, loading: AdminViewSkeleton }
);
const AdminSupport = dynamic(
  () => import("@/components/admin/admin-support").then((m) => m.AdminSupport),
  { ssr: false, loading: AdminViewSkeleton }
);
const AdminNewsletter = dynamic(
  () => import("@/components/admin/admin-newsletter").then((m) => m.AdminNewsletter),
  { ssr: false, loading: AdminViewSkeleton }
);
const AdminPalette = dynamic(
  () => import("@/components/admin/admin-palette").then((m) => m.AdminPalette),
  { ssr: false }
);

/** per-view document-title keys — the tab reflects the active admin view */
const ADMIN_TITLE_KEYS: Record<AdminView, I18nKey> = {
  overview: "docTitleAdminOverview",
  subscribers: "docTitleAdminSubscribers",
  sites: "docTitleAdminSites",
  stores: "docTitleAdminStores",
  systems: "docTitleAdminSystems",
  blog: "docTitleAdminBlog",
  partners: "docTitleAdminPartners",
  activity: "docTitleAdminActivity",
  packages: "docTitleAdminPackages",
  planOrders: "docTitleAdminPlanOrders",
  support: "docTitleAdminSupport",
  admins: "docTitleAdminAdmins",
  audit: "docTitleAdminAudit",
  ops: "docTitleAdminOps",
  legal: "docTitleAdminLegal",
  trash: "docTitleAdminTrash",
  mobileApp: "docTitleAdminMobileApp",
  settings: "docTitleAdminSettings",
  newsletter: "docTitleAdminNewsletter",
};

/* ROUND 45 — professional data refresh (all active views, parallel).
 * Isolated component: `useIsFetching` ticks on EVERY in-flight query;
 * keeping that subscription here (instead of the AdminApp shell) stops
 * background warm-ups from re-rendering the entire admin tree. */
function AdminRefreshButton() {
  const { t } = useT();
  const queryClient = useQueryClient();
  const [refreshing, setRefreshing] = useState(false);
  const fetchingCount = useIsFetching();

  const handleRefresh = async () => {
    if (refreshing) return;
    setRefreshing(true);
    const started = performance.now();
    try {
      const before = queryClient.getQueryCache().getAll().filter((q) => q.isActive()).length;
      await queryClient.refetchQueries({ type: "active" });
      const ms = Math.max(1, Math.round(performance.now() - started));
      toast.success(t("refrDone", { count: String(before), ms: String(ms) }));
    } catch {
      toast.error(t("refrFailed"));
    } finally {
      setRefreshing(false);
    }
  };

  return (
    <button
      type="button"
      onClick={() => void handleRefresh()}
      disabled={refreshing || fetchingCount > 0}
      aria-label={t("refrTip")}
      title={t("refrTip")}
      className="flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 px-2.5 text-slate-600 transition hover:border-brand-300 hover:text-brand-600 disabled:cursor-progress dark:border-white/10 dark:text-slate-300"
    >
      <CatIcon
        name="refresh-cw"
        className={cn(
          "h-[13px] w-[13px]",
          (refreshing || fetchingCount > 0) && "animate-spin"
        )}
      />
      <span className="hidden text-[10.5px] font-extrabold text-slate-400 dark:text-slate-500 md:inline">
        {t("refrTip")}
      </span>
    </button>
  );
}

export function AdminApp() {
  const { t, lang } = useT();
  const { resolvedTheme, setTheme } = useTheme();
  const { authed, user, login, loginMfa, loginPasskey, applyUser, logout, restore } = useAdminAuth();
  const router = useRouter();
  const pathname = usePathname();
  const queryClient = useQueryClient();

  /* round 29 — session warm-up: the admin views' queries are prefetched as
   * soon as an admin session exists, using the EXACT queryKeys+queryFns the
   * views use, staggered in a small timeout cascade so the panel still
   * paints instantly. Fixes the "support page not responding / slow load"
   * report: the tickets route compiled + queried only on first click before.
   * Runs once per session (ref-guard). */
  const warmedRef = useRef(false);
  useEffect(() => {
    if (!authed) {
      warmedRef.current = false;
      return;
    }
    if (warmedRef.current) return;
    warmedRef.current = true;

    const timers = [
      /* the reported slow one first — support inbox (route + cold query) */
      window.setTimeout(() => {
        void queryClient.prefetchQuery({ queryKey: ["tickets"], queryFn: fetchTickets });
      }, 0),
      window.setTimeout(() => {
        void queryClient.prefetchQuery({ queryKey: ["admin-users"], queryFn: fetchAdminUsers });
        void queryClient.prefetchQuery({ queryKey: ["platform-settings"], queryFn: fetchPlatformSettings });
      }, 300),
      window.setTimeout(() => {
        void queryClient.prefetchQuery({ queryKey: ["admin-sites"], queryFn: fetchAdminSites });
        void queryClient.prefetchQuery({ queryKey: ["admin-packages"], queryFn: fetchPackages });
        void queryClient.prefetchQuery({ queryKey: ["admin-stores"], queryFn: fetchAdminStores });
        /* ROUND 47 — activation-requests warm-up (the "All" variant powers
           the KPI strip and matches the view's default filter) */
        void queryClient.prefetchQuery({
          queryKey: ["admin-plan-orders", "all"],
          queryFn: () => fetchAdminPlanOrders(),
        });
      }, 900),
      window.setTimeout(() => {
        /* same key + URL the newsletter view builds for its default filters */
        void queryClient.prefetchQuery({
          queryKey: ["newsletter-admin", "", ""],
          queryFn: async () => {
            const res = await fetch(`/api/admin/newsletter?${new URLSearchParams().toString()}`);
            if (!res.ok) throw new Error("failed");
            return res.json();
          },
        });
        /* audit view defaults (actor "all", limit 50) */
        void queryClient.prefetchQuery({
          queryKey: ["audit", "all", 50],
          queryFn: () => fetchAuditEntries({ limit: 50 }),
        });
      }, 1500),
    ];
    return () => timers.forEach((h) => window.clearTimeout(h));
  }, [authed, queryClient]);

  /* one-shot session restore (cookie → user) — gates the first paint */
  const [restored, setRestored] = useState(false);
  useEffect(() => {
    let alive = true;
    restore().finally(() => {
      if (alive) setRestored(true);
    });
    return () => {
      alive = false;
    };
  }, [restore]);

    /* premium desktop auto-collapse: rail's pinned state owned here so the
   * main content's padding reacts to it (hover is local to the
   * AdminSidebar; only the pin flip shifts the main content). */
  const sidebarPin = useSidebarPin();
  const [sidebarHovered, setSidebarHovered] = useState(false);
  const sidebarExpanded = sidebarPin.isPinned || sidebarHovered;

const [adminView, setAdminView] = useState<AdminView>("overview");
  /* subscribers plan filter — set by the overview plan-distribution meters,
     reset whenever the sidebar is used to navigate */
  const [subscribersPlan, setSubscribersPlan] = useState("all");
  /* subscribers signup-month filter ("YYYY-MM") — set by the overview growth
     chart click-through, reset on sidebar navigation */
  const [subscribersMonth, setSubscribersMonth] = useState("all");
  /* admin command palette (⌘K) — only while authed; the shortcut is owned
     here so it never fires on the login screen */
  const [paletteOpen, setPaletteOpen] = useState(false);

  const handleSidebarSelect = (view: AdminView) => {
    setSubscribersPlan("all");
    setSubscribersMonth("all");
    setAdminView(view);
  };

  /* language-aware tab title — follows the active admin view instantly
     (the login screen carries the sign-in title) */
  useDocumentTitle(authed ? ADMIN_TITLE_KEYS[adminView] : "docTitleLogin");

  const handlePlanSelect = (planId: string) => {
    setSubscribersPlan(planId);
    setAdminView("subscribers");
  };

  /* growth-chart click-through: deep-link subscribers filtered by signup month */
  const handleMonthSelect = (monthKey: string) => {
    setSubscribersMonth(monthKey);
    setAdminView("subscribers");
  };

  // Authenticated visitors on the explicit login route land on /admin instead.
  useEffect(() => {
    if (authed && pathname === "/admin/login") {
      router.replace("/admin");
    }
  }, [authed, pathname, router]);

  /* app-wide shortcut: ⌘K / Ctrl+K + secondary ⌘J / Ctrl+J (authed only) */
  useEffect(() => {
    if (!authed) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.altKey || !(e.ctrlKey || e.metaKey)) return;
      const key = e.key.toLowerCase();
      if (key !== "k" && key !== "j") return;
      e.preventDefault();
      setPaletteOpen(true);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [authed]);

  /* ROUND 36 — premium welcome space inputs: time-of-day greeting, matching
     icon, and the localized role chip for the signed-in admin. */
  const hour = new Date().getHours();
  const timeGreeting = t(
    hour < 5
      ? "adminWelcomeNight"
      : hour < 12
        ? "adminWelcomeMorning"
        : hour < 17
          ? "adminWelcomeAfternoon"
          : hour < 22
            ? "adminWelcomeEvening"
            : "adminWelcomeNight"
  );
  const welcomeIcon =
    hour < 5 ? "moon" : hour < 12 ? "sunrise" : hour < 17 ? "sun" : hour < 22 ? "sunset" : "moon";
  /* ROUND 55 — post-logout redirect to the CONTROL-PANEL login screen (the
     admin session ends where it started — no detour to the public site).
     Full page load so every admin-scoped query cache dies with the cookie. */
  const handleLogout = () => {
    logout();
    window.location.assign("/admin/login");
  };

  /* brief branded loader while the cookie session resolves */
  if (!restored) {
    return (
      <div className="mesh grid min-h-screen place-items-center bg-background" aria-busy="true">
        <div className="flex flex-col items-center gap-4">
          <span
            className="grid h-14 w-14 animate-pulse place-items-center rounded-2xl text-white shadow-lg shadow-brand-500/30"
            style={{ backgroundImage: grad("#6d5dfb", "#06b6d4") }}
            aria-hidden="true"
          >
            <CatIcon name="boxes" className="h-6 w-6" />
          </span>
          <p className="text-[12px] font-bold text-slate-400 dark:text-slate-500">{t("adminSessionRestore")}</p>
        </div>
      </div>
    );
  }

  if (!authed) {
    return <AdminLogin auth={{ login, loginMfa, loginPasskey, applyUser }} />;
  }

  /* ROUND 89 — the «إلزام المصادقة الثنائية» console gate: the platform
     policy is ON and this admin has no second factor. The full console is
     replaced by the enrollment screen (requireAdmin refuses every
     non-allowlisted mutation API-side with 403 MFA_ENROLLMENT_REQUIRED).
     The gate polls /api/admin/me: the moment enrollment registers (the
     server-side probe cache clears within ~4s), the shell reloads with
     full access restored. */
  if (user?.mfaEnrollRequired) {
    return (
      <MfaEnrollmentGate
        adminName={user.name}
        onLogout={() => {
          logout();
          window.location.assign("/admin/login");
        }}
      />
    );
  }

  return (
    <div className="flex min-h-screen flex-col overflow-x-clip bg-background">
      {/* skip-to-content — first focusable element (targets #admin-main) */}
      <SkipLink target="admin-main" />

      {/* decorative mesh background */}
      <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden />

      {/* sticky top bar */}
      <header className="sticky top-0 z-40 border-b border-slate-200/70 bg-white/85 backdrop-blur-xl dark:border-white/[0.07] dark:bg-[#05080f]/80">
        <div className="flex h-16 items-center gap-2 px-4 sm:gap-3 sm:px-6 lg:ps-[17rem] lg:pe-8">
          {/* brand (mobile — sidebar is hidden) */}
          <span
            className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg shadow-brand-500/25 lg:hidden"
            style={{ backgroundImage: grad("#6d5dfb", "#06b6d4") }}
            aria-hidden="true"
          >
            <CatIcon name="boxes" className="h-[14px] w-[14px]" />
          </span>

          <div className="min-w-0 flex-1">
            {/* ROUND 36 — premium personalized welcome space (replaces the
                static panel title): time-of-day greeting + the admin's name
                + role chip + the executive subtitle. */}
            <div className="flex min-w-0 items-center gap-2.5">
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-2xl text-white shadow-lg shadow-brand-500/25"
                style={{ backgroundImage: grad("#6d5dfb", "#d946ef") }}
                aria-hidden="true"
              >
                <CatIcon name={welcomeIcon} className="h-[15px] w-[15px]" />
              </span>
              <div className="min-w-0">
                <div className="flex min-w-0 items-center gap-2">
                  <h1 className="truncate font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                    {user ? t("adminWelcomeName", { name: user.name }) : timeGreeting}
                  </h1>
                </div>
                <p className="hidden truncate text-[10.5px] font-semibold text-slate-500 dark:text-slate-400 sm:block">
                  {t("adminWelcomeSub")}
                </p>
              </div>
            </div>
          </div>

          {/* actions */}
          <div className="ms-auto flex items-center gap-1.5">
            {/* command palette trigger */}
            <button
              type="button"
              onClick={() => setPaletteOpen(true)}
              aria-label={t("ariaAdminPalette")}
              title={t("ariaAdminPalette")}
              className="flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 px-2.5 text-slate-600 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:text-slate-300"
            >
              <CatIcon name="command" className="h-[13px] w-[13px]" />
              <span className="hidden text-[10.5px] font-extrabold text-slate-400 dark:text-slate-500 md:inline">Ctrl K</span>
            </button>

            {/* ROUND 45 — professional data refresh (isolated; see above) */}
            <AdminRefreshButton />

            {/* platform operational status — replaces the old "back to site" button */}
            <span
              className="hidden h-10 items-center gap-2 rounded-xl border border-emerald-200/80 bg-emerald-50/70 px-3 text-[11.5px] font-extrabold text-emerald-700 sm:inline-flex dark:border-emerald-500/25 dark:bg-emerald-500/10 dark:text-emerald-300"
              title={t("adminStatusTip")}
            >
              <span className="relative flex h-2 w-2" aria-hidden="true">
                <span className="absolute inset-0 rounded-full bg-emerald-500/40" />
                <span className="relative m-auto h-1.5 w-1.5 rounded-full bg-emerald-500" />
              </span>
              {t("adminStatusOk")}
            </span>

            {/* notifications */}
            {/* ROUND 141 — the REAL-EVENT bell: rows deep-link into the
                console views (payments / support / subscribers). */}
            <AdminNotifications
              onNavigate={(view) => {
                setAdminView(view);
              }}
            />

            {/* theme toggle */}
            <button
              type="button"
              onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
              aria-label={t("ariaTheme")}
              title={t("ariaTheme")}
              className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 text-slate-600 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:text-slate-300"
            >
              <CatIcon name={resolvedTheme === "dark" ? "sun" : "moon"} className="h-[14px] w-[14px]" />
            </button>

            {/* language switcher (10 locales) */}
            <LangMenu />

            {/* logged-in identity — clickable premium admin card (round 26) */}
            {user ? (
              <AdminIdentityMenu
                user={user}
                onNavigate={(view) => handleSidebarSelect(view)}
                onLogout={handleLogout}
              />
            ) : null}

            {/* logout */}
            <button
              type="button"
              onClick={handleLogout}
              aria-label={t("adminLogout")}
              title={t("adminLogout")}
              className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 text-slate-600 transition hover:border-rose-300 hover:bg-rose-50 hover:text-rose-600 dark:border-white/10 dark:text-slate-300 dark:hover:bg-rose-500/10 dark:hover:text-rose-300"
            >
              <CatIcon name="log-out" className="h-[14px] w-[14px]" />
            </button>
          </div>
        </div>
      </header>

      {/* sidebar + content — column on mobile (pill nav above content) so the
          content column keeps the full viewport width; row on lg+ (the fixed
          desktop sidebar is out-of-flow, content offsets via ps-64) */}
      <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
        <AdminSidebar
          active={adminView}
          onSelect={handleSidebarSelect}
          onLogout={handleLogout}
          isPinned={sidebarPin.isPinned}
          onTogglePin={sidebarPin.toggle}
          isHovered={sidebarHovered}
          onHoverChange={setSidebarHovered}
        />

        <div className={cn("flex min-w-0 flex-1 flex-col transition-all duration-300 ease-in-out", sidebarExpanded ? "lg:ps-64" : "lg:ps-16")}>
          <main
            id="admin-main"
            className="flex-1 px-4 py-6 sm:px-6 lg:px-8"
            aria-label={t("adminTitle")}
          >
            <div key={adminView} className="step-in">
              {adminView === "overview" ? (
                <AdminOverview
                  onPlanSelect={handlePlanSelect}
                  onMonthSelect={handleMonthSelect}
                  onBrowseAll={() => handleSidebarSelect("subscribers")}
                />
              ) : null}
              {adminView === "subscribers" ? (
                <AdminSubscribers
                  planFilter={subscribersPlan}
                  onPlanFilterChange={setSubscribersPlan}
                  monthFilter={subscribersMonth}
                  onMonthFilterChange={setSubscribersMonth}
                />
              ) : null}
              {adminView === "sites" ? <AdminSites /> : null}
              {adminView === "stores" ? <AdminStores /> : null}
              {adminView === "systems" ? <AdminSystems /> : null}
              {adminView === "blog" ? <AdminBlog /> : null}
              {adminView === "partners" ? <AdminPartners /> : null}
              {adminView === "activity" ? <AdminActivity /> : null}
              {adminView === "settings" ? <AdminSettings /> : null}
              {adminView === "admins" ? <AdminAdmins /> : null}
              {adminView === "audit" ? <AdminAudit /> : null}
              {/* ROUND 114 — operations telemetry (super-admin subsystem snapshot) */}
              {adminView === "ops" ? <AdminOps /> : null}
              {/* ROUND 117 — the platform legal documents console */}
              {adminView === "legal" ? <AdminLegal /> : null}
              {/* ROUND 142 — the official-site mobile-app storefront controls */}
              {adminView === "mobileApp" ? <AdminMobileApp /> : null}
              {adminView === "trash" ? <AdminTrash /> : null}
              {adminView === "packages" ? <AdminPackages /> : null}
              {adminView === "planOrders" ? <AdminPlanOrders /> : null}
              {adminView === "support" ? <AdminSupport /> : null}
              {adminView === "newsletter" ? <AdminNewsletter /> : null}
            </div>
          </main>

          {/* sticky footer */}
          <footer className="safe-bottom mt-auto border-t border-slate-200/70 px-4 py-3 sm:px-6 lg:px-8 dark:border-white/[0.07]">
            <p className="flex flex-wrap items-center justify-between gap-2 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
              <span className="flex items-center gap-1.5">
                <span
                  className="grid h-4 w-4 place-items-center rounded text-white"
                  style={{ backgroundImage: grad("#6d5dfb", "#06b6d4") }}
                  aria-hidden="true"
                >
                  <CatIcon name="boxes" className="h-[8px] w-[8px]" />
                </span>
                Ashrilogic · {t("adminTitle")}
              </span>
              <span>{t("footerRights")}</span>
            </p>
          </footer>
        </div>
      </div>

      {/* admin command palette (⌘K / Ctrl+K) */}
      <AdminPalette
        open={paletteOpen}
        onOpenChange={setPaletteOpen}
        onNavigate={handleSidebarSelect}
        onPlanSelect={handlePlanSelect}
        onLogout={handleLogout}
      />
    </div>
  );
}

/* ================================================================== */
/* ROUND 89 — the «إلزام المصادقة الثنائية» blocking enrollment gate    */
/* ================================================================== */

/**
 * Replaces the whole console while the platform two-factor policy is ON
 * and the signed-in admin has no second factor. Embeds the standard admin
 * TwoFactorCard (QR + live-code enrollment — the same flow as the security
 * settings) and polls /api/admin/me: the moment the server-side probe
 * clears (≤ ~4s enrollment cache), the shell reloads itself with full
 * access restored. A logout escape is always available.
 */
function MfaEnrollmentGate({
  adminName,
  onLogout,
}: {
  adminName: string;
  onLogout: () => void;
}) {
  const { t, lang } = useT();
  const reloadedRef = useRef(false);

  /* poll the me probe — enrollment clears mfaEnrollRequired server-side */
  const meProbe = useQuery({
    queryKey: ["admin-me-2fa-gate"],
    queryFn: fetchAdminMe,
    refetchInterval: 5_000,
    retry: 1,
  });

  useEffect(() => {
    if (!reloadedRef.current && meProbe.data && meProbe.data.mfaEnrollRequired !== true) {
      reloadedRef.current = true;
      window.location.reload();
    }
  }, [meProbe.data]);

  return (
    <div className="mesh grid min-h-screen place-items-center overflow-x-clip bg-background px-4 py-8" dir={lang === "ar" ? "rtl" : "ltr"}>
      <div className="w-full max-w-xl">
        {/* header */}
        <div className="card-in mb-4 rounded-3xl border border-amber-300/50 bg-linear-to-br from-amber-50/90 to-white p-5 shadow-xl shadow-amber-500/10 dark:border-amber-400/20 dark:from-amber-500/10 dark:to-[#0a0f1c] sm:p-6">
          <div className="flex items-start gap-3.5">
            <span
              className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg shadow-amber-500/25"
              style={{ backgroundImage: grad("#f59e0b", "#ea580c") }}
              aria-hidden="true"
            >
              <CatIcon name="shield" className="h-5 w-5" />
            </span>
            <div className="min-w-0 flex-1">
              <h1 className="font-display text-[17px] font-extrabold leading-snug text-slate-900 dark:text-white">
                {t("mfaGateTitle")}
              </h1>
              <p className="mt-1 text-[12.5px] font-semibold leading-relaxed text-slate-600 dark:text-slate-300">
                {t("mfaGateDesc")}
              </p>
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <span className="rounded-full bg-amber-500/10 px-2.5 py-1 text-[10.5px] font-extrabold text-amber-600 dark:text-amber-400">
                  {adminName}
                </span>
                <span className="flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-2.5 py-1 text-[10.5px] font-extrabold text-emerald-600 dark:text-emerald-400">
                  <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-500" aria-hidden="true" />
                  {t("mfaGateStep")}
                </span>
                <button
                  type="button"
                  onClick={onLogout}
                  className="ms-auto text-[11px] font-bold text-slate-400 underline-offset-2 transition hover:text-rose-500 hover:underline"
                >
                  {t("adminLogout")}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* the standard enrollment card (QR + live code) */}
        <TwoFactorCard scope={{ kind: "admin" }} />
      </div>
    </div>
  );
}

export default AdminApp;
