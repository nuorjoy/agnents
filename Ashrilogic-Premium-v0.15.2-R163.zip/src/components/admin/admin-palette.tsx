"use client";

/**
 * Ashrilogic — admin command palette (⌘K / Ctrl+K, ⌘J / Ctrl+J).
 *
 * Premium Linear/Vercel-style palette rendered inside the authenticated admin
 * shell. Contents:
 *   1. Views       — jump between the 9 admin views (shares ADMIN_NAV with the
 *                    sidebar so labels/icons never drift).
 *   2. Subscribers — deep-link the Subscribers view pre-filtered to a live
 *                    package ("المشتركون حسب الباقة") incl. the no-plan bucket.
 *   3. Actions     — theme toggle, language toggle, back to site, logout.
 *
 * The keyboard shortcut itself is owned by `AdminApp` (it must never fire on
 * the login screen); this component only renders + filters + runs.
 */
import { useCallback, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useTheme } from "next-themes";
import { toast } from "sonner";
import { fetchPackages } from "@/lib/api-client";
import { useT } from "@/lib/i18n";
import { localeNativeLabel, nextLocale } from "@/lib/locales";
import { useAppStore } from "@/lib/store";
import type { Lang } from "@/lib/types";
import { arabicMatches } from "@/lib/search";
import { CatIcon } from "@/components/icon";
import { cn, grad } from "@/lib/utils";
import { ADMIN_NAV, type AdminView } from "@/components/admin/admin-sidebar";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandShortcut,
} from "@/components/ui/command";

/* delay before running a selected action so the dialog finishes its close
   animation (scroll unlock / focus return) first — mirrors the main palette */
const RUN_DELAY_MS = 240;

/* polished item treatment: hover wash + selected ring + gradient inset bar
   on the inline-start side (RTL-safe via logical inset) — matches the main
   command palette exactly so both feel like one system */
const CP_ITEM =
  "relative rounded-xl py-2.5 outline-none transition-colors duration-150 " +
  "hover:bg-slate-100 dark:hover:bg-white/[0.05] " +
  "data-[selected=true]:bg-slate-100 data-[selected=true]:ring-1 data-[selected=true]:ring-brand-500/25 " +
  "dark:data-[selected=true]:bg-white/[0.06] " +
  "before:absolute before:inset-y-1.5 before:start-1.5 before:w-[3px] before:rounded-full " +
  "before:bg-linear-to-b before:from-brand-500 before:to-fuchsia-500 before:opacity-0 " +
  "before:transition-opacity before:duration-150 hover:before:opacity-100 " +
  "data-[selected=true]:before:opacity-100";

/* icon + gradient palette cycled per plan item (matches PLAN_STYLES family) */
const PLAN_ICON_STYLES = [
  { icon: "rocket", c1: "#06b6d4", c2: "#0891b2" },
  { icon: "sparkles", c1: "#6d5dfb", c2: "#d946ef" },
  { icon: "building", c1: "#f59e0b", c2: "#ea580c" },
  { icon: "gem", c1: "#10b981", c2: "#059669" },
] as const;

interface PlanItem {
  id: string;
  name: string;
  price?: number;
  currency?: string;
  icon: string;
  c1: string;
  c2: string;
}

export function AdminPalette({
  open,
  onOpenChange,
  onNavigate,
  onPlanSelect,
  onLogout,
}: {
  open: boolean;
  /** controlled open/close (AdminApp owns the keyboard shortcut) */
  onOpenChange: (open: boolean) => void;
  onNavigate: (view: AdminView) => void;
  /** deep-link: Subscribers view pre-filtered to a plan id or "none" */
  onPlanSelect: (planId: string) => void;
  onLogout: () => void;
}) {
  const { t, lang } = useT();
  const setLang = useAppStore((s) => s.setLang);
  const { resolvedTheme, setTheme } = useTheme();
  const [query, setQuery] = useState("");

  const packagesQuery = useQuery({
    queryKey: ["admin-packages"],
    queryFn: fetchPackages,
    staleTime: 60_000,
  });

  const handleOpenChange = useCallback(
    (next: boolean) => {
      onOpenChange(next);
      if (!next) setQuery("");
    },
    [onOpenChange]
  );

  /* close the dialog, wait out the close animation, then run the action */
  const run = useCallback(
    (action: () => void) => {
      onOpenChange(false);
      setQuery("");
      setTimeout(action, RUN_DELAY_MS);
    },
    [onOpenChange]
  );

  /* ---- subscribers-by-plan group (live packages + the no-plan bucket) --- */
  const planItems = useMemo<PlanItem[]>(() => {
    const styleOf = (sortOrder: number) =>
      PLAN_ICON_STYLES[Math.abs(sortOrder - 1) % PLAN_ICON_STYLES.length];
    const items: PlanItem[] = (packagesQuery.data ?? []).map((pkg) => ({
      id: pkg.id,
      name: lang === "ar" ? pkg.nameAr : pkg.nameEn,
      price: pkg.priceMonthly,
      currency: pkg.currency,
      ...styleOf(pkg.sortOrder),
    }));
    items.push({
      id: "none",
      name: t("adminPlanNoPlan"),
      icon: "circle-help",
      c1: "#94a3b8",
      c2: "#64748b",
    });
    const q = query.trim();
    if (!q) return items;
    return items.filter((p) => arabicMatches(p.name, q));
  }, [packagesQuery.data, lang, query, t]);

  /* ---- navigation group (shared with the sidebar) ---------------------- */
  const navItems = useMemo(
    () =>
      ADMIN_NAV.map((n) => ({
        id: n.id,
        label: t(n.labelKey),
        icon: n.icon,
      })),
    [t]
  );

  const visibleNav = useMemo(() => {
    const q = query.trim();
    if (!q) return navItems;
    return navItems.filter((n) => arabicMatches(n.label, q));
  }, [query, navItems]);

  /* ---- quick actions ----------------------------------------------------- */
  const actions = useMemo(
    () => [
      {
        id: "theme",
        label: t("cpTheme"),
        icon: resolvedTheme === "dark" ? "sun" : "moon",
        danger: false,
        action: () => setTheme(resolvedTheme === "dark" ? "light" : "dark"),
      },
      {
        id: "lang",
        label: t("cpLang"),
        icon: "globe",
        danger: false,
        action: () => {
          const next: Lang = nextLocale(lang);
          setLang(next);
          toast.success(localeNativeLabel(next));
        },
      },
      {
        id: "logout",
        label: t("adminLogout"),
        icon: "log-out",
        danger: true,
        action: onLogout,
      },
    ],
    [t, resolvedTheme, setTheme, lang, setLang, onLogout]
  );

  const visibleActions = useMemo(() => {
    const q = query.trim();
    if (!q) return actions;
    return actions.filter((a) => arabicMatches(a.label, q));
  }, [query, actions]);

  const groupHeading = (text: string) => (
    <span className="text-[10px] font-extrabold uppercase text-slate-400 dark:text-slate-500">
      {text}
    </span>
  );

  return (
    <CommandDialog
      open={open}
      onOpenChange={handleOpenChange}
      title={t("admPaletteTitle")}
      description={t("admPaletteDesc")}
      showCloseButton={false}
      commandProps={{ shouldFilter: false }}
      className="top-[12%] translate-y-0 rounded-2xl border-slate-200/80 bg-popover/95 shadow-lift backdrop-blur-2xl sm:max-w-xl dark:border-white/10 dark:bg-[#0a0f1c]/90"
    >
      <CommandInput
        value={query}
        onValueChange={setQuery}
        placeholder={t("admPalettePh")}
        className="text-[13px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 dark:text-slate-100 dark:placeholder:text-slate-500"
      />

      <CommandList className="max-h-[min(56vh,420px)] py-2">
        <CommandEmpty className="py-8 text-[12.5px] font-semibold text-slate-400 dark:text-slate-500">
          {t("cpNoResults")}
        </CommandEmpty>

        {/* views */}
        {visibleNav.length > 0 ? (
          <CommandGroup heading={groupHeading(t("cpNavigation"))}>
            {visibleNav.map((n) => (
              <CommandItem
                key={n.id}
                value={`nav-${n.id}`}
                onSelect={() => run(() => onNavigate(n.id as AdminView))}
                className={CP_ITEM}
              >
                <CatIcon name={n.icon} className="h-4 w-4 text-brand-500" />
                <span className="text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                  {n.label}
                </span>
                <CommandShortcut className="kbd ml-auto inline-flex text-[10px]">
                  {t("cpQuickNav")}
                </CommandShortcut>
              </CommandItem>
            ))}
          </CommandGroup>
        ) : null}

        {/* subscribers by plan */}
        {planItems.length > 0 ? (
          <CommandGroup heading={groupHeading(t("admPalettePlans"))}>
            {planItems.map((p) => (
              <CommandItem
                key={p.id}
                value={`plan-${p.id}`}
                onSelect={() => run(() => onPlanSelect(p.id))}
                className={CP_ITEM}
              >
                <span
                  className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white"
                  style={{ backgroundImage: grad(p.c1, p.c2) }}
                  aria-hidden="true"
                >
                  <CatIcon name={p.icon} className="h-[13px] w-[13px]" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[12.5px] font-bold text-slate-800 dark:text-slate-100">
                    {p.name}
                  </span>
                  {p.price !== undefined ? (
                    <span dir="ltr" className="block text-start text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                      {p.price} {p.currency ?? "SAR"}
                    </span>
                  ) : null}
                </span>
                <CommandShortcut className="kbd ml-auto inline-flex text-[10px]">
                  {t("admPaletteFilterHint")}
                </CommandShortcut>
              </CommandItem>
            ))}
          </CommandGroup>
        ) : null}

        {/* quick actions */}
        {visibleActions.length > 0 ? (
          <CommandGroup heading={groupHeading(t("cpActions"))}>
            {visibleActions.map((a) => (
              <CommandItem
                key={a.id}
                value={`act-${a.id}`}
                onSelect={() => run(a.action)}
                className={cn(CP_ITEM, a.danger && "text-rose-600 dark:text-rose-400")}
              >
                <CatIcon
                  name={a.icon}
                  className={a.danger ? "h-4 w-4 text-rose-500" : "h-4 w-4 text-brand-500"}
                />
                <span
                  className={cn(
                    "text-[12.5px] font-bold",
                    a.danger
                      ? "text-rose-600 dark:text-rose-400"
                      : "text-slate-700 dark:text-slate-200"
                  )}
                >
                  {a.label}
                </span>
              </CommandItem>
            ))}
          </CommandGroup>
        ) : null}
      </CommandList>

      {/* footer: admin context chip + keyboard hint (mirrors the main palette) */}
      <div className="flex items-center justify-between gap-2 border-t border-slate-200/70 px-3 py-2 dark:border-white/10">
        <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-[10px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-400">
          <CatIcon name="shield-user" className="h-[10px] w-[10px] text-brand-500" />
          {t("admPaletteCtx")}
        </span>
        <span className="text-[10px] font-semibold text-slate-400 dark:text-slate-500">
          {t("cpKeysHint")}
        </span>
      </div>
    </CommandDialog>
  );
}

export default AdminPalette;
