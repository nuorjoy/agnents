"use client";

/**
 * Ashrilogic — admin subscriber detail Sheet.
 *
 * A premium slide-over drawer that shows the full profile of a single
 * provisioned instance: organization info, subscription plan (live
 * assign / unassign), admin account, preferences, enabled modules
 * (resolved to localized names) and recent activity. Read-only except
 * the plan assignment — everything else is edited in the system's own
 * dashboard.
 *
 * ROUND 79 — the plan card is followed by TWO platform-lever sections:
 *   • «مدة الاشتراك» (subscription term): current planExpiresAt with a
 *     days-left tone chip (emerald >7d / amber ≤7d / rose expired or ≤2d),
 *     a native date editor + quick-action chips (+30d / +1y / unlimited)
 *     saving through PATCH updateInstance({ planExpiresAt }) — a past date
 *     hard-locks the workspace, renewal restores it.
 *   • «مزايا النظام» (System features): per-feature tri-state control over
 *     the 8-key catalog (follow plan / force-on / force-off) with the plan
 *     baseline chip + a LIVE effective-state chip recomputed client-side
 *     via resolveInstanceFeatures(); saved through
 *     updateInstance({ featureOverrides }) — the server validates + audits.
 */
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CATEGORY_MAP, MODULE_MAP, SYSTEM_MAP, systemMods } from "@/data/catalog";
import {
  adminWalletAdjust,
  fetchInstance,
  fetchInstanceOps,
  fetchPackages,
  fetchWallet,
  revokeInstanceSessions,
  updateInstance,
} from "@/lib/api-client";
import { apiErrorText } from "@/lib/api-errors";
import { amountInputIsNeutral, parseAmountInputToMinor } from "@/lib/amount-input";
import { useAdminAuth } from "@/lib/admin-auth";
import { useT, type I18nKey } from "@/lib/i18n";
import { intlLocale } from "@/lib/locales";
import type { InstanceDTO, Lang, PackageSummaryDTO, SystemDef } from "@/lib/types";
import {
  FEATURE_GROUPS,
  FEATURE_META,
  PLAN_FEATURES,
  discountedPrice,
  effectiveYearlyPct,
  isPlanFeature,
  type PlanFeature,
  resolveInstanceFeatures,
} from "@/lib/plan-features";
import { CatIcon } from "@/components/icon";
import { SubscriberBanSection } from "@/components/admin/subscriber-governance";
import { auditActionLabelKey } from "@/components/admin/admin-audit";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PremiumDateInput } from "@/components/ui/premium-date-input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  IconTile,
  MeterBar,
  ACT_STYLE,
  dateOnly,
  fullDate,
  relativeTime,
} from "@/components/dashboard/dash-shared";
import { cn, fmtNum, grad } from "@/lib/utils";

/* Localized region name (per-locale); raw code fallback. */
function regionName(code: string, lang: Lang): string {
  if (!/^[A-Za-z]{2}$/.test(code)) return code || "—";
  try {
    return new Intl.DisplayNames([intlLocale(lang)], { type: "region" }).of(code) ?? code;
  } catch {
    return code;
  }
}

/**
 * Direction-aware detail field.
 *
 * Arabic (RTL sheet): LTR values (emails, phone numbers, timezone, currency
 * codes) still READ left-to-right but ALIGN to the sheet's start edge (the
 * right side) so every value sits exactly under its label — the detail view
 * reads as one aligned Arabic column. Non-LTR values flow naturally.
 */
function Field({ label, value, ltr, mono }: { label: string; value: React.ReactNode; ltr?: boolean; mono?: boolean }) {
  const { lang } = useT();
  return (
    <div className="min-w-0">
      <p className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
        {label}
      </p>
      <p
        dir={ltr ? "ltr" : undefined}
        className={cn(
          "mt-0.5 truncate text-[12.5px] font-bold text-slate-700 dark:text-slate-200",
          mono && "font-mono text-[11.5px]",
          ltr && (lang === "ar" ? "text-end" : "text-start")
        )}
      >
        {value}
      </p>
    </div>
  );
}

function SectionCard({
  title,
  icon,
  c1,
  c2,
  children,
}: {
  title: string;
  icon: string;
  c1: string;
  c2: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-slate-200/80 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]">
      <h3 className="mb-3 flex items-center gap-2 text-[12px] font-extrabold uppercase tracking-wider text-slate-600 dark:text-slate-300">
        <span
          className="grid h-6 w-6 place-items-center rounded-lg text-white"
          style={{ backgroundImage: grad(c1, c2) }}
          aria-hidden="true"
        >
          <CatIcon name={icon} className="h-[10px] w-[10px]" />
        </span>
        {title}
      </h3>
      {children}
    </section>
  );
}

function PrefToggle({ label, on, c1, c2 }: { label: string; on: boolean; c1: string; c2: string }) {
  return (
    <div
      className={cn(
        "flex items-center justify-between gap-2 rounded-xl border px-3 py-2 transition",
        on
          ? "border-brand-300/60 bg-brand-50/40 dark:border-brand-500/30 dark:bg-brand-500/10"
          : "border-slate-200 bg-slate-50/60 dark:border-white/10 dark:bg-white/[0.02]"
      )}
    >
      <span className="text-[11.5px] font-bold text-slate-600 dark:text-slate-300">{label}</span>
      <span
        className="grid h-5 w-5 place-items-center rounded-full text-white"
        style={{ backgroundImage: on ? grad(c1, c2) : "linear-gradient(135deg,#cbd5e1,#94a3b8)" }}
        aria-hidden="true"
      >
        <CatIcon name={on ? "check" : "x"} className="h-[10px] w-[10px]" />
      </span>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* ROUND 79 — term management + per-tenant feature overrides            */
/* ------------------------------------------------------------------ */

/** FEATURE_META ships lucide names as data; `file-down` is not in the
 *  project icon registry, so map it to the closest registered icon. */
const FEAT_ICON_FIX: Record<string, string> = { "file-down": "download" };
function featIcon(icon: string): string {
  return FEAT_ICON_FIX[icon] ?? icon;
}

/** ISO instant → local `yyyy-mm-dd` for the native date input ("" for null). */
function toDateInputValue(iso: string | null): string {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

/** Quick-add target: max(now, current unexpired term) + days — the server's
 *  renewal stacking law (an early extension never loses days). */
function quickAddDate(expiresIso: string | null, days: number): string {
  const current = expiresIso ? new Date(expiresIso).getTime() : null;
  const base = current && current > Date.now() ? current : Date.now();
  return new Date(base + days * 24 * 60 * 60 * 1000).toISOString();
}

/** Tone law for a days-left chip: emerald >7d · amber ≤7d · rose ≤2d/expired. */
function daysTone(daysLeft: number | null, expired: boolean): "emerald" | "amber" | "rose" {
  if (expired || daysLeft === null || daysLeft <= 2) return "rose";
  if (daysLeft <= 7) return "amber";
  return "emerald";
}

const TONE_CHIP: Record<"emerald" | "amber" | "rose" | "sky" | "violet" | "slate", string> = {
  emerald: "border-emerald-300/70 bg-emerald-500/10 text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/15 dark:text-emerald-300",
  amber: "border-amber-300/70 bg-amber-500/10 text-amber-700 dark:border-amber-500/30 dark:bg-amber-500/15 dark:text-amber-300",
  rose: "border-rose-300/70 bg-rose-500/10 text-rose-700 dark:border-rose-500/30 dark:bg-rose-500/15 dark:text-rose-300",
  sky: "border-sky-300/70 bg-sky-500/10 text-sky-700 dark:border-sky-500/30 dark:bg-sky-500/15 dark:text-sky-300",
  violet: "border-violet-300/70 bg-violet-500/10 text-violet-700 dark:border-violet-500/30 dark:bg-violet-500/15 dark:text-violet-300",
  slate: "border-slate-300/70 bg-slate-500/[0.08] text-slate-500 dark:border-white/15 dark:bg-white/10 dark:text-slate-400",
};

/** Small inline status chip (rounded-full pill with an icon). */
function StatusChip({
  tone,
  icon,
  children,
  title,
}: {
  tone: keyof typeof TONE_CHIP;
  icon: string;
  children: React.ReactNode;
  title?: string;
}) {
  return (
    <span
      title={title}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10.5px] font-extrabold",
        TONE_CHIP[tone]
      )}
    >
      <CatIcon name={icon} className="h-3 w-3 shrink-0" />
      {children}
    </span>
  );
}

/**
 * «مدة الاشتراك» — the paid-term lever. Shows the live planExpiresAt with a
 * tone-coded countdown; edits a native date (RTL-safe) or fires quick-action
 * chips (+30d / +1y stack from the FARTHEST current horizon, matching the
 * server's renewal semantics); «إلغاء المدة» clears to unlimited (null).
 */
function TermSection({ inst }: { inst: InstanceDTO }) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const ent = inst.entitlement;
  const hasPkg = inst.packageId !== null && inst.packageId !== "";
  const expires = ent.planExpiresAt;

  /* keyed draft state — resets automatically per instance (pkgPick pattern) */
  const [termPick, setTermPick] = useState<{ forId: string; value: string }>({ forId: "", value: "" });
  const draft = termPick.forId === inst.id ? termPick.value : toDateInputValue(expires);

  const termMutation = useMutation({
    mutationFn: (planExpiresAt: string | null) => updateInstance(inst.id, { planExpiresAt }),
    onSuccess: () => {
      toast.success(t("termSaved"));
      queryClient.invalidateQueries({ queryKey: ["instances"] });
      queryClient.invalidateQueries({ queryKey: ["instance", inst.id] });
      queryClient.invalidateQueries({ queryKey: ["instance", inst.id, "admin-detail"] });
    },
    onError: (error: Error) => toast.error(apiErrorText(error, t)),
  });

  /* quick-add stacks from max(now, current unexpired term) — renewal law */
  const applyQuickAdd = (days: number) => {
    setTermPick({ forId: inst.id, value: toDateInputValue(quickAddDate(expires, days)) });
  };

  const saveTerm = () => {
    if (draft === "") {
      termMutation.mutate(null);
      return;
    }
    /* end-of-day LOCAL time — an expiry date locks at the day's close, not
       at 00:00 UTC (timezone-friendly for Arabic-first tenants) */
    const d = new Date(`${draft}T23:59:59`);
    if (Number.isNaN(d.getTime())) {
      toast.error(t("termInvalid"));
      return;
    }
    termMutation.mutate(d.toISOString());
  };

  const planExpired = ent.state === "locked" && ent.lockReason === "plan";
  const trialLocked = ent.state === "locked" && ent.lockReason === "trial";
  const inTrial = ent.state === "trial";

  return (
    <SectionCard title={t("termTitle")} icon="calendar-clock" c1="#06b6d4" c2="#0891b2">
      {/* current state — tone-coded */}
      <div className="flex flex-wrap items-center gap-1.5">
        {hasPkg && !expires ? (
          <StatusChip tone="sky" icon="infinity">{t("termUnlimited")}</StatusChip>
        ) : null}
        {hasPkg && expires ? (
          <>
            <StatusChip
              tone={daysTone(ent.planDaysLeft, planExpired)}
              icon={planExpired ? "lock" : "calendar-clock"}
            >
              {planExpired
                ? t("termExpiredChip")
                : t("termDaysLeft", { n: fmtNum(ent.planDaysLeft ?? 0, lang) })}
            </StatusChip>
            <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
              {t("termEndsOn", { date: dateOnly(expires, lang) })}
            </span>
          </>
        ) : null}
        {!hasPkg && (inTrial || trialLocked) && ent.trialEndsAt ? (
          <>
            <StatusChip tone="violet" icon="sparkles">{t("featTrialFullAccess")}</StatusChip>
            <StatusChip tone={trialLocked ? "rose" : daysTone(ent.trialDaysLeft, trialLocked)} icon="hourglass">
              {trialLocked
                ? t("termExpiredChip")
                : t("termTrialChip", { date: dateOnly(ent.trialEndsAt, lang) })}
            </StatusChip>
          </>
        ) : null}
        {!hasPkg && !inTrial && !trialLocked ? (
          <StatusChip tone="slate" icon="infinity">{t("featSourcePlatform")}</StatusChip>
        ) : null}
      </div>

      {/* editor — the lever only bites once a plan is assigned */}
      {hasPkg ? (
        <div className="mt-3 space-y-2.5">
          <div className="grid grid-cols-2 gap-2.5">
            <div className="col-span-2 sm:col-span-1">
              <label
                htmlFor={`term-date-${inst.id}`}
                className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500"
              >
                {t("termDateLabel")}
              </label>
              {/* R163 — the shared premium date field (the sheet's h-10
                  rhythm): brand calendar tile at the field's far right in
                  Arabic, clear-X + Arabic long-form hint built in. */}
              <PremiumDateInput
                id={`term-date-${inst.id}`}
                value={draft}
                onChange={(e) => setTermPick({ forId: inst.id, value: e.target.value })}
                disabled={termMutation.isPending}
                wrapperClassName="mt-1"
              />
            </div>
            <div className="col-span-2 flex flex-wrap items-center gap-1.5 sm:col-span-1 sm:items-end">
              {[
                { days: 30, label: t("termQuick30"), icon: "calendar-days" },
                { days: 365, label: t("termQuickYear"), icon: "calendar-range" },
              ].map((quick) => (
                <button
                  key={`term-q-${quick.days}`}
                  type="button"
                  onClick={() => applyQuickAdd(quick.days)}
                  disabled={termMutation.isPending}
                  title={t("termQuickHint")}
                  className="inline-flex items-center gap-1 rounded-full border border-sky-300/70 bg-sky-500/[0.07] px-2.5 py-1.5 text-[10.5px] font-extrabold text-sky-700 transition hover:border-sky-400 hover:bg-sky-500/15 active:scale-95 disabled:opacity-50 dark:border-sky-500/30 dark:bg-sky-500/10 dark:text-sky-300"
                >
                  <CatIcon name={quick.icon} className="h-3 w-3" />
                  {quick.label}
                </button>
              ))}
              <button
                type="button"
                onClick={() => setTermPick({ forId: inst.id, value: "" })}
                disabled={termMutation.isPending}
                aria-pressed={draft === ""}
                className="inline-flex items-center gap-1 rounded-full border border-slate-200 bg-white/70 px-2.5 py-1.5 text-[10.5px] font-extrabold text-slate-500 transition hover:border-rose-300 hover:text-rose-600 active:scale-95 disabled:opacity-50 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400 dark:hover:text-rose-300"
              >
                <CatIcon name="infinity" className="h-3 w-3" />
                {t("termQuickUnlimited")}
              </button>
            </div>
          </div>

          <p className="flex items-start gap-1.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            <CatIcon name="info" className="mt-px h-3 w-3 shrink-0" />
            {t("termNote")}
          </p>

          <Button
            type="button"
            onClick={saveTerm}
            disabled={termMutation.isPending}
            className="h-10 w-full rounded-xl bg-linear-to-r from-sky-500 to-cyan-500 px-4 text-[12.5px] font-extrabold text-white shadow-lg shadow-sky-500/30 transition hover:from-sky-600 hover:to-cyan-600 active:scale-95 disabled:opacity-50"
          >
            <CatIcon
              name={termMutation.isPending ? "refresh-cw" : "calendar-check"}
              className={cn("h-4 w-4", termMutation.isPending && "animate-spin")}
            />
            {termMutation.isPending ? t("adminPkgSaving") : t("termSave")}
          </Button>
        </div>
      ) : (
        <p className="mt-2.5 flex items-start gap-1.5 rounded-xl border border-dashed border-slate-200 bg-slate-50/50 px-3 py-2.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:border-white/10 dark:bg-white/[0.02] dark:text-slate-500">
          <CatIcon name="info" className="mt-px h-3 w-3 shrink-0" />
          {t("termNoPackageNote")}
        </p>
      )}
    </SectionCard>
  );
}

/**
 * «مزايا النظام» — per-tenant tri-state overrides over the 8-key catalog.
 * For every feature: icon + label + description, the PLAN baseline chip, a
 * 3-option segmented control (follow plan / force-on / force-off) and the
 * EFFECTIVE state chip recomputed live through resolveInstanceFeatures()
 * (overrides beat the plan AND the trial window — same law as the server).
 */
function FeatureOverridesSection({
  inst,
  pkg,
}: {
  inst: InstanceDTO;
  pkg: PackageSummaryDTO | null;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();

  /* the saved platform switches (server-sanitized: valid keys only) */
  const savedOverrides = useMemo(() => {
    const out: Partial<Record<PlanFeature, boolean>> = {};
    for (const [k, v] of Object.entries(inst.featureOverrides ?? {})) {
      if (isPlanFeature(k) && typeof v === "boolean") out[k] = v;
    }
    return out;
  }, [inst.featureOverrides]);

  /* keyed draft state — resets automatically per instance */
  const [ovPick, setOvPick] = useState<{
    forId: string;
    map: Partial<Record<PlanFeature, boolean>>;
  }>({ forId: "", map: {} });
  const draft: Partial<Record<PlanFeature, boolean>> =
    ovPick.forId === inst.id ? ovPick.map : savedOverrides;

  const planCaps = useMemo(
    () => (pkg?.capabilities ?? []).filter(isPlanFeature),
    [pkg]
  );

  /* LIVE effective map from the draft — the exact server resolution law */
  const effective = useMemo(
    () =>
      resolveInstanceFeatures({
        state: inst.entitlement.state,
        hasPackage: pkg !== null,
        capabilities: planCaps,
        overrides: draft,
      }),
    [inst.entitlement.state, pkg, planCaps, draft]
  );

  const overridesMutation = useMutation({
    mutationFn: (featureOverrides: Record<string, boolean>) =>
      updateInstance(inst.id, { featureOverrides }),
    onSuccess: () => {
      toast.success(t("featOverridesSaved"));
      queryClient.invalidateQueries({ queryKey: ["instances"] });
      queryClient.invalidateQueries({ queryKey: ["instance", inst.id] });
      queryClient.invalidateQueries({ queryKey: ["instance", inst.id, "admin-detail"] });
    },
    onError: (error: Error) => toast.error(apiErrorText(error, t)),
  });

  const setMode = (key: PlanFeature, mode: "default" | "on" | "off") => {
    setOvPick((prev) => {
      const base = prev.forId === inst.id ? prev.map : savedOverrides;
      const map = { ...base };
      if (mode === "default") delete map[key];
      else map[key] = mode === "on";
      return { forId: inst.id, map };
    });
  };

  const draftCount = Object.keys(draft).length;
  const dirty = JSON.stringify(draft) !== JSON.stringify(savedOverrides);

  return (
    <SectionCard title={t("featOverridesTitle")} icon="sliders" c1="#8b5cf6" c2="#7c3aed">
      <p className="text-[10.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
        {t("featOverridesDesc")}
      </p>

      {/* status line — override count + assigned plan baseline */}
      <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
        {draftCount > 0 ? (
          <StatusChip tone="violet" icon="toggle-right">
            {t("featOverridesCount", { n: fmtNum(draftCount, lang) })}
          </StatusChip>
        ) : null}
        <StatusChip tone={pkg ? "amber" : "sky"} icon={pkg ? "crown" : "infinity"}>
          {pkg
            ? lang === "ar"
              ? pkg.nameAr
              : pkg.nameEn
            : t("featSourcePlatform")}
        </StatusChip>
        {dirty ? (
          <span className="ms-auto inline-flex items-center gap-1 rounded-full bg-violet-500/10 px-2 py-0.5 text-[10px] font-extrabold text-violet-600 dark:bg-violet-500/15 dark:text-violet-300">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-violet-500 dark:bg-violet-300" aria-hidden="true" />
          </span>
        ) : null}
      </div>

      {/* grouped tri-state rows */}
      <div className="mt-3 space-y-3">
        {FEATURE_GROUPS.map((group) => {
          const groupKeys = PLAN_FEATURES.filter((key) => FEATURE_META[key].group === group.key);
          return (
            <div key={`ov-grp-${group.key}`}>
              <p className="mb-1.5 text-[10px] font-extrabold uppercase tracking-wider text-violet-500/80 dark:text-violet-300/70">
                {t(group.labelKey)}
              </p>
              <div className="space-y-2">
                {groupKeys.map((key) => {
                  const meta = FEATURE_META[key];
                  const mode: "default" | "on" | "off" =
                    key in draft ? (draft[key] === true ? "on" : "off") : "default";
                  const inPlan = pkg ? planCaps.includes(key) : null;
                  const eff = effective[key].enabled;
                  const segBtn = (m: "default" | "on" | "off", label: string) => (
                    <button
                      key={`ov-${key}-${m}`}
                      type="button"
                      role="radio"
                      aria-checked={mode === m}
                      disabled={overridesMutation.isPending}
                      onClick={() => setMode(key, m)}
                      className={cn(
                        "inline-flex h-9 min-w-0 flex-1 items-center justify-center gap-1 px-1.5 text-[10.5px] font-extrabold transition active:scale-95 disabled:opacity-60",
                        mode === m
                          ? m === "on"
                            ? "bg-emerald-500 text-white shadow-md shadow-emerald-500/25"
                            : m === "off"
                              ? "bg-rose-500 text-white shadow-md shadow-rose-500/25"
                              : "bg-slate-600 text-white shadow-md"
                          : "text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300"
                      )}
                    >
                      {label}
                    </button>
                  );
                  return (
                    <div
                      key={`ov-${key}`}
                      className={cn(
                        "rounded-xl border p-3 transition",
                        mode === "on"
                          ? "border-emerald-300/60 bg-emerald-50/40 dark:border-emerald-500/25 dark:bg-emerald-500/[0.06]"
                          : mode === "off"
                            ? "border-rose-300/60 bg-rose-50/40 dark:border-rose-500/25 dark:bg-rose-500/[0.05]"
                            : "border-slate-200/80 bg-white/60 dark:border-white/10 dark:bg-white/[0.03]"
                      )}
                    >
                      {/* identity + plan baseline */}
                      <div className="flex items-start gap-2.5">
                        <span
                          className={cn(
                            "grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white transition",
                            eff ? "shadow-md" : "opacity-45 saturate-50"
                          )}
                          style={{ backgroundImage: grad("#8b5cf6", "#d946ef") }}
                          aria-hidden="true"
                        >
                          <CatIcon name={featIcon(meta.icon)} className="h-[13px] w-[13px]" />
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="flex flex-wrap items-center gap-1.5">
                            <span className="text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                              {t(meta.labelKey)}
                            </span>
                            {inPlan === null ? (
                              <span className="inline-flex items-center gap-1 rounded-full border border-sky-300/70 bg-sky-500/10 px-1.5 py-px text-[9.5px] font-extrabold text-sky-700 dark:border-sky-500/30 dark:bg-sky-500/15 dark:text-sky-300">
                                {t("featSourcePlatform")}
                              </span>
                            ) : (
                              <span
                                className={cn(
                                  "inline-flex items-center gap-1 rounded-full px-1.5 py-px text-[9.5px] font-extrabold",
                                  inPlan
                                    ? "bg-emerald-500/10 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300"
                                    : "bg-slate-500/10 text-slate-500 dark:bg-white/10 dark:text-slate-400"
                                )}
                              >
                                {inPlan ? t("featPlanIncluded") : t("featNotIncluded")}
                              </span>
                            )}
                          </p>
                          <p className="mt-0.5 text-[10.5px] font-semibold leading-snug text-slate-400 dark:text-slate-500">
                            {t(meta.descKey)}
                          </p>
                        </div>
                        {/* effective state — recomputed live from the draft */}
                        <span
                          className={cn(
                            "inline-flex shrink-0 items-center gap-1 rounded-full border px-2 py-0.5 text-[9.5px] font-extrabold",
                            eff
                              ? TONE_CHIP.emerald
                              : "border-slate-300/70 bg-slate-500/[0.08] text-slate-500 dark:border-white/15 dark:bg-white/10 dark:text-slate-400"
                          )}
                          title={t("featEffLabel")}
                        >
                          <CatIcon name={eff ? "circle-check" : "circle-x"} className="h-2.5 w-2.5" />
                          <span className="hidden sm:inline">{t("featEffLabel")}: </span>
                          {t(eff ? "featEffOn" : "featEffOff")}
                        </span>
                      </div>

                      {/* tri-state segmented control */}
                      <div
                        role="radiogroup"
                        aria-label={t(meta.labelKey)}
                        className="mt-2.5 flex overflow-hidden rounded-xl border border-slate-200 bg-slate-50/70 p-0.5 dark:border-white/10 dark:bg-white/[0.04]"
                      >
                        {segBtn("default", t("featOverrideMode"))}
                        {segBtn("on", t("featOverrideOn"))}
                        {segBtn("off", t("featOverrideOff"))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {/* actions — save (explicit overrides only) + reset-to-plan */}
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <Button
          type="button"
          onClick={() => overridesMutation.mutate(draft)}
          disabled={overridesMutation.isPending || !dirty}
          className="h-10 flex-1 rounded-xl bg-linear-to-r from-violet-600 to-fuchsia-500 px-4 text-[12.5px] font-extrabold text-white shadow-lg shadow-violet-500/30 transition hover:from-violet-700 hover:to-fuchsia-600 active:scale-95 disabled:opacity-50"
        >
          <CatIcon
            name={overridesMutation.isPending ? "refresh-cw" : "save"}
            className={cn("h-4 w-4", overridesMutation.isPending && "animate-spin")}
          />
          {overridesMutation.isPending ? t("adminPkgSaving") : t("featOverridesApply")}
        </Button>
        {Object.keys(savedOverrides).length > 0 || draftCount > 0 ? (
          <Button
            type="button"
            variant="outline"
            onClick={() => {
              setOvPick({ forId: inst.id, map: {} });
              overridesMutation.mutate({});
            }}
            disabled={overridesMutation.isPending}
            title={t("featOverrideClear")}
            className="h-10 rounded-xl border-slate-200 px-3.5 text-[12px] font-bold text-slate-500 transition hover:border-violet-300 hover:text-violet-600 active:scale-95 dark:border-white/10 dark:text-slate-400 dark:hover:border-violet-500/40 dark:hover:text-violet-300"
          >
            <CatIcon name="rotate-ccw" className="h-4 w-4" />
            {t("featOverrideClear")}
          </Button>
        ) : null}
      </div>
    </SectionCard>
  );
}

/* ------------------------------------------------------------------ */
/* ROUND 136 — instance ops & health (the strong per-instance          */
/* connection: super-only telemetry drilldown + session-revocation     */
/* strict lever)                                                       */
/* ------------------------------------------------------------------ */

/** Localized byte formatting (the admin-ops console's helper, locale-aware). */
function fmtBytes(bytes: number, lang: Lang): string {
  if (bytes >= 1024 * 1024 * 1024) return `${fmtNum(Math.round((bytes / (1024 * 1024 * 1024)) * 10) / 10, lang)} GB`;
  if (bytes >= 1024 * 1024) return `${fmtNum(Math.round((bytes / (1024 * 1024)) * 10) / 10, lang)} MB`;
  if (bytes >= 1024) return `${fmtNum(Math.round((bytes / 1024) * 10) / 10, lang)} KB`;
  return `${fmtNum(bytes, lang)} B`;
}

/** One label/value row inside the ops card (the ops MetricRow language). */
function OpsMetric({
  label,
  value,
  tone = "neutral",
  ltr = false,
}: {
  label: string;
  value: string;
  tone?: "good" | "warn" | "bad" | "neutral";
  ltr?: boolean;
}) {
  return (
    <li className="flex items-center justify-between gap-3 py-1.5 first:pt-0 last:pb-0">
      <span className="flex min-w-0 items-center gap-1.5 text-[11px] font-bold text-slate-500 dark:text-slate-400">
        {label}
      </span>
      <span
        dir={ltr ? "ltr" : undefined}
        className={cn(
          "shrink-0 rounded-lg px-2 py-0.5 text-[11px] font-extrabold tabular-nums",
          tone === "good" && "bg-emerald-500/10 text-emerald-600 dark:text-emerald-300",
          tone === "warn" && "bg-amber-500/10 text-amber-600 dark:text-amber-300",
          tone === "bad" && "bg-rose-500/10 text-rose-600 dark:text-rose-300",
          tone === "neutral" && "bg-slate-500/10 text-slate-700 dark:bg-white/[0.06] dark:text-slate-200"
        )}
      >
        {value}
      </span>
    </li>
  );
}

/**
 * «تشغيل النظام وصحته» — the on-demand telemetry drilldown. SUPER-ONLY (the
 * route itself refuses anything else — the gate here is cosmetic): a small
 * refresh button arms the query, then the card renders the composite health
 * band (emerald healthy / amber warnings / rose locked-banned), the storage
 * meter, the sessions + revoke-all strict ceremony (checkbox acknowledgment,
 * the ban-dialog idiom), the store/site/webhook/shift posture chips and the
 * last 5 audit rows linked to THIS workspace (from the ops call — the audit
 * view itself lives behind the console's own navigation).
 */
function InstanceOpsSection({ inst }: { inst: InstanceDTO }) {
  const { t, lang } = useT();
  const { user } = useAdminAuth();
  const isSuper = user?.role === "super";
  const queryClient = useQueryClient();

  /* armed per instance — resets automatically when another sheet opens */
  const [opsArmedFor, setOpsArmedFor] = useState<string | null>(null);
  const armed = isSuper && opsArmedFor === inst.id;

  const opsQuery = useQuery({
    queryKey: ["instance-ops", inst.id],
    queryFn: () => fetchInstanceOps(inst.id),
    enabled: armed,
    retry: 0,
  });

  /* the revoke ceremony state (the ban dialog's ack idiom, inline) */
  const [revokeArmed, setRevokeArmed] = useState(false);
  const [ack, setAck] = useState(false);

  const revokeMutation = useMutation({
    mutationFn: () => revokeInstanceSessions(inst.id),
    onSuccess: (data) => {
      toast.success(
        data.revoked > 0 ? t("opsRevokeDone", { n: fmtNum(data.revoked, lang) }) : t("opsRevokeNone")
      );
      setRevokeArmed(false);
      setAck(false);
      void queryClient.invalidateQueries({ queryKey: ["instance-ops", inst.id] });
    },
    onError: (error: Error) => toast.error(apiErrorText(error, t)),
  });

  if (!isSuper) return null;

  const ops = opsQuery.data;

  /* composite health verdict: rose = locked or banned (platform hold),
   * amber = storage > 80% or webhook delivery failures, emerald = healthy */
  let verdict: { tone: "emerald" | "amber" | "rose"; key: I18nKey; icon: string } = {
    tone: "emerald",
    key: "opsHealthGood",
    icon: "circle-check",
  };
  if (ops) {
    const held = ops.instance.ban.active || ops.instance.entitlement.state === "locked";
    const warn =
      (ops.health.storagePct !== null && ops.health.storagePct > 80) || ops.webhooks.failedDeliveries24h > 0;
    if (held) verdict = { tone: "rose", key: "opsHealthBad", icon: "octagon-x" };
    else if (warn) verdict = { tone: "amber", key: "opsHealthWarn", icon: "triangle-alert" };
  }

  const storagePct = ops?.health.storagePct ?? null;
  const storageColor =
    storagePct === null
      ? grad("#10b981", "#059669", 90)
      : storagePct > 80
        ? grad("#f59e0b", "#d97706", 90)
        : grad("#10b981", "#059669", 90);

  return (
    <SectionCard title={t("opsSectionTitle")} icon="gauge" c1="#0ea5e9" c2="#0284c7">
      <p className="text-[10.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
        {t("opsSectionDesc")}
      </p>

      {!armed ? (
        <Button
          type="button"
          onClick={() => setOpsArmedFor(inst.id)}
          className="mt-3 h-10 w-full rounded-xl bg-linear-to-r from-sky-600 to-cyan-700 px-4 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95"
        >
          <CatIcon name="activity" className="h-4 w-4" />
          {t("opsLoadBtn")}
        </Button>
      ) : opsQuery.isPending ? (
        <div className="mt-3 space-y-2">
          <Skeleton className="h-8 w-full rounded-xl" />
          <Skeleton className="h-10 w-full rounded-xl" />
          <Skeleton className="h-24 w-full rounded-xl" />
        </div>
      ) : opsQuery.isError || !ops ? (
        <div className="mt-3 space-y-2.5 text-center">
          <p className="text-[11.5px] font-bold text-rose-600 dark:text-rose-400">{t("opsLoadTelemetryFailed")}</p>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => void opsQuery.refetch()}
            className="h-9 rounded-xl px-4 text-[11.5px] font-bold"
          >
            <CatIcon name="refresh-cw" className={cn("h-3.5 w-3.5", opsQuery.isFetching && "animate-spin")} />
            {t("retryText")}
          </Button>
        </div>
      ) : (
        <div className="mt-3 space-y-3">
          {/* composite health band */}
          <div className="flex flex-wrap items-center gap-1.5">
            <StatusChip tone={verdict.tone} icon={verdict.icon}>{t(verdict.key)}</StatusChip>
            <StatusChip
              tone={ops.instance.entitlement.state === "active" ? "sky" : "slate"}
              icon={ops.instance.entitlement.state === "trial" ? "sparkles" : ops.instance.entitlement.state === "locked" ? "lock" : "badge-check"}
            >
              {ops.instance.entitlement.state === "active"
                ? t("featSourcePlatform")
                : ops.instance.entitlement.state === "trial"
                  ? t("featTrialFullAccess")
                  : t("termExpiredChip")}
            </StatusChip>
            {ops.instance.demo ? (
              <StatusChip tone="violet" icon="flask-conical">{t("adminDemoBadge")}</StatusChip>
            ) : null}
          </div>

          {/* core metrics */}
          <ul className="divide-y divide-slate-100 dark:divide-white/[0.06]">
            <OpsMetric
              label={t("opsSessionsLabel")}
              value={fmtNum(ops.health.activeSessions, lang)}
              tone={ops.health.activeSessions > 0 ? "good" : "neutral"}
              ltr
            />
            <OpsMetric
              label={t("opsLastActivityLabel")}
              value={ops.health.lastActivityAt ? relativeTime(ops.health.lastActivityAt, lang) : t("opsNeverActive")}
            />
            <OpsMetric
              label={t("opsMembersLabel")}
              value={fmtNum(ops.health.membersCount, lang)}
              ltr
            />
            <OpsMetric
              label={t("adminModulesEnabled")}
              value={`${fmtNum(ops.health.modulesEnabled, lang)} / ${ops.health.planModuleLimit !== null ? fmtNum(ops.health.planModuleLimit, lang) : "∞"}`}
              tone={
                ops.health.planModuleLimit !== null && ops.health.modulesEnabled >= ops.health.planModuleLimit
                  ? "warn"
                  : "neutral"
              }
              ltr
            />
          </ul>

          {/* storage meter (server-computed ground truth) */}
          <div>
            <div className="mb-1 flex items-center justify-between text-[11px] font-bold">
              <span className="text-slate-500 dark:text-slate-400">{t("opsStorageLabel")}</span>
              <span className="text-slate-700 dark:text-slate-200">
                {fmtBytes(ops.health.storageUsedBytes, lang)} /{" "}
                {ops.health.storageQuotaMb !== null
                  ? `${fmtNum(ops.health.storageQuotaMb, lang)} MB`
                  : t("opsStorageUnlimited")}
                {storagePct !== null ? ` · ${fmtNum(storagePct, lang)}%` : ""}
              </span>
            </div>
            <MeterBar value={storagePct ?? 0} color={storageColor} />
          </div>

          {/* posture chips: store / site / integrations / shifts */}
          <div className="grid grid-cols-2 gap-2">
            <div className="rounded-xl border border-slate-200/80 bg-white/60 p-2.5 dark:border-white/10 dark:bg-white/[0.03]">
              <p className="flex items-center gap-1.5 text-[10.5px] font-extrabold text-slate-500 dark:text-slate-400">
                <CatIcon name="store" className="h-3 w-3 text-amber-500" />
                {t("opsStoreChip")}
              </p>
              {ops.store.moduleId ? (
                <p className="mt-1 text-[10.5px] font-semibold leading-relaxed text-slate-600 dark:text-slate-300">
                  {fmtNum(ops.store.productsCount, lang)} {t("opsStoreProducts")} · {fmtNum(ops.store.lowStockCount, lang)}{" "}
                  {t("opsStoreLowStock")} · {fmtNum(ops.store.ordersCount, lang)} {t("opsStoreOrders")}
                  {ops.store.revenue
                    ? ` · ${fmtNum(ops.store.revenue.value, lang)} ${ops.store.revenue.currency} ${t("opsStoreRevenue")}`
                    : ""}
                </p>
              ) : (
                <p className="mt-1 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">{t("opsStoreNone")}</p>
              )}
            </div>
            <div className="rounded-xl border border-slate-200/80 bg-white/60 p-2.5 dark:border-white/10 dark:bg-white/[0.03]">
              <p className="flex items-center gap-1.5 text-[10.5px] font-extrabold text-slate-500 dark:text-slate-400">
                <CatIcon name="globe" className="h-3 w-3 text-teal-500" />
                {t("opsSiteChip")}
              </p>
              <p className="mt-1 text-[10.5px] font-semibold leading-relaxed text-slate-600 dark:text-slate-300">
                <StatusChip tone={ops.site.live ? "emerald" : "slate"} icon={ops.site.live ? "rocket" : "pencil"}>
                  {t(ops.site.live ? "opsSiteLive" : "opsSiteDraft")}
                </StatusChip>
              </p>
              <p className="mt-1 text-[10.5px] font-semibold text-slate-500 dark:text-slate-400">
                {fmtNum(ops.site.views, lang)} {t("opsSiteViews")} · {fmtNum(ops.site.customersCount, lang)}{" "}
                {t("opsSiteCustomers")} · {fmtNum(ops.site.inquiriesCount, lang)} {t("opsSiteInquiries")}
              </p>
            </div>
            <div className="rounded-xl border border-slate-200/80 bg-white/60 p-2.5 dark:border-white/10 dark:bg-white/[0.03]">
              <p className="flex items-center gap-1.5 text-[10.5px] font-extrabold text-slate-500 dark:text-slate-400">
                <CatIcon name="webhook" className="h-3 w-3 text-violet-500" />
                {t("opsWebhookChip")}
              </p>
              <p className="mt-1 text-[10.5px] font-semibold leading-relaxed text-slate-600 dark:text-slate-300">
                {fmtNum(ops.webhooks.activeEndpoints, lang)} {t("opsWebhookActive")} ·{" "}
                <span className={ops.webhooks.failedDeliveries24h > 0 ? "text-amber-600 dark:text-amber-300" : undefined}>
                  {fmtNum(ops.webhooks.failedDeliveries24h, lang)} {t("opsWebhookFailed")}
                </span>
              </p>
            </div>
            <div className="rounded-xl border border-slate-200/80 bg-white/60 p-2.5 dark:border-white/10 dark:bg-white/[0.03]">
              <p className="flex items-center gap-1.5 text-[10.5px] font-extrabold text-slate-500 dark:text-slate-400">
                <CatIcon name="clock" className="h-3 w-3 text-emerald-500" />
                {t("opsShiftChip")}
              </p>
              <p className="mt-1 text-[10.5px] font-semibold leading-relaxed text-slate-600 dark:text-slate-300">
                {t("opsShiftOpenCount", { n: fmtNum(ops.shifts.openCount, lang)})}
                {ops.shifts.lastClosedAt ? ` · ${t("opsShiftLastClosed")}: ${relativeTime(ops.shifts.lastClosedAt, lang)}` : ""}
              </p>
            </div>
          </div>

          {/* the strict lever: revoke every live workspace session */}
          <div className="rounded-xl border border-rose-200/70 bg-rose-500/[0.04] p-3 dark:border-rose-500/25 dark:bg-rose-500/[0.05]">
            {!revokeArmed ? (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setRevokeArmed(true)}
                disabled={revokeMutation.isPending}
                className="h-9 w-full gap-2 rounded-xl border-rose-200 text-[11.5px] font-extrabold text-rose-600 transition hover:bg-rose-500/10 active:scale-95 disabled:opacity-50 dark:border-rose-500/30 dark:text-rose-300"
              >
                <CatIcon name="log-out" className="h-3.5 w-3.5" />
                {t("opsRevokeBtn")}
              </Button>
            ) : (
              <div className="space-y-2.5">
                <label className="flex cursor-pointer items-start gap-2.5 rounded-xl border border-rose-300/70 bg-rose-500/[0.05] p-2.5 dark:border-rose-500/30">
                  <Checkbox checked={ack} onCheckedChange={(v) => setAck(v === true)} className="mt-0.5" />
                  <span className="text-[11px] font-bold leading-relaxed text-slate-700 dark:text-slate-200">
                    {t("opsRevokeAck")}
                  </span>
                </label>
                <div className="flex flex-wrap items-center gap-2">
                  <Button
                    type="button"
                    size="sm"
                    onClick={() => revokeMutation.mutate()}
                    disabled={!ack || revokeMutation.isPending}
                    className="h-9 flex-1 gap-2 rounded-xl bg-rose-600 px-4 text-[11.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60"
                  >
                    <CatIcon
                      name={revokeMutation.isPending ? "refresh-cw" : "octagon-x"}
                      className={cn("h-3.5 w-3.5", revokeMutation.isPending && "animate-spin")}
                    />
                    {t("opsRevokeConfirm")}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setRevokeArmed(false);
                      setAck(false);
                    }}
                    disabled={revokeMutation.isPending}
                    className="h-9 rounded-xl px-4 text-[11.5px] font-bold"
                  >
                    {t("dlgCancel")}
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* the last 5 audit rows linked to THIS workspace (from the ops call) */}
          <div>
            <p className="mb-1.5 flex items-center gap-1.5 text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              <CatIcon name="scroll-text" className="h-3 w-3" />
              {t("opsAuditMiniTitle")}
              <span className="ms-auto normal-case tracking-normal">{fmtNum(ops.audit.total, lang)}</span>
            </p>
            {ops.audit.recent.length > 0 ? (
              <ul className="space-y-1">
                {ops.audit.recent.map((row) => {
                  const labelKey = auditActionLabelKey(row.action);
                  return (
                    <li
                      key={row.id}
                      className="flex items-center gap-2 rounded-lg border border-slate-100 bg-white/50 px-2.5 py-1.5 dark:border-white/[0.06] dark:bg-white/[0.02]"
                    >
                      <span className="min-w-0 flex-1 truncate text-[11px] font-bold text-slate-600 dark:text-slate-300">
                        {labelKey ? t(labelKey) : row.action}
                      </span>
                      <span className="shrink-0 text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                        {relativeTime(row.createdAt, lang)}
                      </span>
                    </li>
                  );
                })}
              </ul>
            ) : (
              <p className="py-2 text-center text-[11px] font-semibold text-slate-400 dark:text-slate-500">
                {t("opsAuditMiniEmpty")}
              </p>
            )}
          </div>

          {/* manual refresh */}
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => void opsQuery.refetch()}
            disabled={opsQuery.isFetching}
            className="h-9 w-full gap-2 rounded-xl text-[11.5px] font-bold"
          >
            <CatIcon name="refresh-cw" className={cn("h-3.5 w-3.5", opsQuery.isFetching && "animate-spin")} />
            {t("opsRefreshBtn")}
          </Button>
        </div>
      )}
    </SectionCard>
  );
}

/* ------------------------------------------------------------------ */
/* ROUND 136 — strict module control (super-only toggle grid)          */
/* ------------------------------------------------------------------ */

/**
 * «الوحدات» — the modules card. SUPER admins get the full toggle grid over
 * the system's catalog (PATCH /api/instances/[id] { modules } through the
 * same admin dual-cookie mutation path as the plan lever; the server
 * enforces the catalog allowlist, the PLAN_MODULE_LIMIT 403 and the
 * SHIFT_OPEN_MUST_CLOSE 409 — both surface as precise localized toasts).
 * Non-super roles keep the exact former read-only card.
 */
function ModulesSection({
  inst,
  sys,
  c1,
  c2,
}: {
  inst: InstanceDTO;
  sys: SystemDef | undefined;
  c1: string;
  c2: string;
}) {
  const { t, lang } = useT();
  const { user } = useAdminAuth();
  const isSuper = user?.role === "super";
  const queryClient = useQueryClient();

  const catalogModules = useMemo(() => (sys ? systemMods(sys) : []), [sys]);
  const modsTotal = catalogModules.length;
  /* ROUND 136 — legacy drift chips: modules already enabled on the instance
     but outside the system's current catalog (historical shipments). They
     stay preserved in every replacement list (the server grandfather-clause
     keeps them legal) and render as locked amber chips so the operator sees
     the full truth instead of an invisible module. */
  const legacyModules = useMemo(
    () => inst.modules.filter((m) => !catalogModules.includes(m)),
    [inst.modules, catalogModules]
  );

  /* keyed draft state — resets automatically per instance (pkgPick pattern) */
  const [modsPick, setModsPick] = useState<{ forId: string; list: string[] }>({ forId: "", list: [] });
  const draft = modsPick.forId === inst.id ? modsPick.list : inst.modules;
  const dirty = isSuper && JSON.stringify(draft) !== JSON.stringify(inst.modules);

  const modulesMutation = useMutation({
    mutationFn: (modules: string[]) => updateInstance(inst.id, { modules }),
    onSuccess: () => {
      toast.success(t("modsSavedToast"));
      queryClient.invalidateQueries({ queryKey: ["instances"] });
      queryClient.invalidateQueries({ queryKey: ["instance", inst.id] });
      queryClient.invalidateQueries({ queryKey: ["instance", inst.id, "admin-detail"] });
    },
    onError: (error: Error) => toast.error(apiErrorText(error, t)),
  });

  const toggle = (moduleId: string) => {
    setModsPick((prev) => {
      const base = prev.forId === inst.id ? prev.list : inst.modules;
      const list = base.includes(moduleId)
        ? base.filter((m) => m !== moduleId)
        : [...base, moduleId];
      return { forId: inst.id, list };
    });
  };

  return (
    <SectionCard title={t("adminDetailModules")} icon="cubes" c1="#0ea5e9" c2="#0284c7">
      <div className="mb-3">
        <div className="mb-1 flex items-center justify-between text-[11px] font-bold">
          <span className="text-slate-500 dark:text-slate-400">
            {t("modsCountChip", { n: fmtNum(draft.length, lang), total: fmtNum(modsTotal, lang) })}
          </span>
          <span className={cn(dirty ? "text-amber-600 dark:text-amber-300" : "text-brand-600 dark:text-brand-300")}>
            {fmtNum(Math.round((draft.length / Math.max(1, modsTotal)) * 100), lang)}
            {lang === "ar" ? "٪" : "%"}
          </span>
        </div>
        <MeterBar value={(draft.length / Math.max(1, modsTotal)) * 100} color={grad(c1, c2, 90)} />
      </div>

      {isSuper ? (
        <div className="space-y-3">
          <p className="flex items-start gap-1.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            <CatIcon name="info" className="mt-px h-3 w-3 shrink-0" />
            {t("modsEditHint")}
          </p>
          <div className="flex flex-wrap gap-1.5">
            {catalogModules.map((modId) => {
              const mod = MODULE_MAP[modId];
              const enabled = draft.includes(modId);
              return (
                <button
                  key={modId}
                  type="button"
                  aria-pressed={enabled}
                  disabled={modulesMutation.isPending}
                  onClick={() => toggle(modId)}
                  className={cn(
                    "inline-flex items-center gap-1 rounded-lg border px-2 py-1 text-[10.5px] font-bold transition active:scale-95 disabled:opacity-60",
                    enabled
                      ? "border-emerald-300/70 bg-emerald-500/10 text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/15 dark:text-emerald-300"
                      : "border-slate-200 bg-slate-50/60 text-slate-500 hover:border-slate-300 hover:text-slate-700 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-400 dark:hover:text-slate-200"
                  )}
                >
                  <CatIcon name={enabled ? "toggle-right" : "toggle-left"} className="h-3 w-3" />
                  <CatIcon name={mod?.icon ?? "cubes"} className="h-[9px] w-[9px]" />
                  {mod ? (lang === "ar" ? mod.nameAr : mod.nameEn) : modId}
                </button>
              );
            })}
          </div>
          {legacyModules.length > 0 ? (
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500">{t("modsLegacyChip")}</span>
              {legacyModules.map((modId) => (
                <span
                  key={modId}
                  dir="ltr"
                  className="inline-flex items-center gap-1 rounded-lg border border-amber-300/60 bg-amber-500/10 px-2 py-1 text-[10.5px] font-bold text-amber-700 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-300"
                >
                  <CatIcon name="lock" className="h-[9px] w-[9px]" />
                  {modId}
                </span>
              ))}
            </div>
          ) : null}
          <Button
            type="button"
            onClick={() => modulesMutation.mutate(draft)}
            disabled={!dirty || modulesMutation.isPending}
            className="h-10 w-full rounded-xl bg-linear-to-r from-sky-600 to-cyan-700 px-4 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:opacity-50"
          >
            <CatIcon
              name={modulesMutation.isPending ? "refresh-cw" : "save"}
              className={cn("h-4 w-4", modulesMutation.isPending && "animate-spin")}
            />
            {modulesMutation.isPending ? t("adminPkgSaving") : t("modsSaveBtn")}
          </Button>
        </div>
      ) : (
        <div className="space-y-2.5">
          <div className="flex flex-wrap gap-1.5">
            {inst.modules.map((modId) => {
              const mod = MODULE_MAP[modId];
              return (
                <Badge
                  key={modId}
                  className="gap-1 rounded-lg bg-slate-100 px-2 py-1 text-[10.5px] font-bold text-slate-600 dark:bg-white/10 dark:text-slate-300"
                >
                  <CatIcon name={mod?.icon ?? "cubes"} className="h-[9px] w-[9px]" />
                  {mod ? (lang === "ar" ? mod.nameAr : mod.nameEn) : modId}
                </Badge>
              );
            })}
          </div>
          <p className="flex items-start gap-1.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            <CatIcon name="info" className="mt-px h-3 w-3 shrink-0" />
            {t("modsSuperOnlyNote")}
          </p>
        </div>
      )}
    </SectionCard>
  );
}

/** ROUND 48 — per-plan icon identity (same palette cycle as the tenant
 * billing view's PLAN_STYLES, for console/tenant consistency). */
const PLAN_STYLES = [
  { icon: "rocket", c1: "#06b6d4", c2: "#0891b2" },
  { icon: "sparkles", c1: "#6d5dfb", c2: "#d946ef" },
  { icon: "building", c1: "#f59e0b", c2: "#ea580c" },
  { icon: "gem", c1: "#10b981", c2: "#059669" },
] as const;

/** Mini card for the currently assigned subscription plan. */
function AssignedPlanCard({ pkg }: { pkg: PackageSummaryDTO }) {
  const { t, lang } = useT();
  return (
    <div className="rounded-xl border border-amber-200/80 bg-linear-to-br from-amber-50/90 to-orange-50/60 p-3.5 dark:border-amber-500/20 dark:from-amber-500/10 dark:to-orange-500/5">
      <div className="flex items-start justify-between gap-2">
        <div className="flex min-w-0 items-start gap-2.5">
          <span
            className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
            style={{ backgroundImage: grad("#f59e0b", "#d97706") }}
            aria-hidden="true"
          >
            <CatIcon name="crown" className="h-4 w-4" />
          </span>
          <div className="min-w-0">
            <p className="truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
              {lang === "ar" ? pkg.nameAr : pkg.nameEn}
            </p>
            <p className="mt-0.5 truncate text-[11px] font-semibold text-slate-500 dark:text-slate-400">
              {lang === "ar" ? pkg.descAr : pkg.descEn}
            </p>
          </div>
        </div>
        {pkg.popular ? (
          <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-linear-to-r from-amber-500 to-orange-500 px-2 py-0.5 text-[10px] font-extrabold text-white shadow-md">
            <CatIcon name="star" className="h-[9px] w-[9px] fill-white" />
            {t("pkgPopularBadge")}
          </span>
        ) : null}
      </div>

      <div className="mt-3 flex flex-wrap items-end gap-1.5">
        {/* ROUND 79 → ROUND 80 — live discounted prices per cycle (monthly
            promotion chip + the dedicated annual promotion chip) */}
        {pkg.discountPct > 0 ? (
          <span dir="ltr" className="mb-0.5 self-center text-[12px] font-bold tabular-nums text-amber-500/70 line-through decoration-rose-400/70 dark:text-amber-200/40">
            {fmtNum(pkg.priceMonthly, lang)}
          </span>
        ) : null}
        <span className="font-display text-[22px] font-extrabold leading-none text-slate-900 dark:text-white">
          {fmtNum(discountedPrice(pkg.priceMonthly, pkg.discountPct), lang)}
        </span>
        <span className="text-[11.5px] font-bold text-slate-500 dark:text-slate-400">{pkg.currency}</span>
        <span className="pb-0.5 text-[11px] font-semibold text-slate-400 dark:text-slate-500">
          {t("adminPkgPerMonth")}
        </span>
        {pkg.discountPct > 0 ? (
          <span className="mb-0.5 inline-flex shrink-0 items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-extrabold text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400">
            <CatIcon name="percent" className="h-[9px] w-[9px]" />
            {t("pkgDiscountChip", { pct: fmtNum(pkg.discountPct, lang) })}
          </span>
        ) : null}
        {effectiveYearlyPct(pkg) > 0 ? (
          <span className="mb-0.5 inline-flex shrink-0 items-center gap-1 rounded-full bg-teal-500/10 px-2 py-0.5 text-[10px] font-extrabold text-teal-600 dark:bg-teal-500/15 dark:text-teal-300">
            <CatIcon name="calendar-range" className="h-[9px] w-[9px]" />
            {t("pkgDiscountChipYearly", { pct: fmtNum(effectiveYearlyPct(pkg), lang) })}
          </span>
        ) : null}
      </div>

      <div className="mt-3 grid grid-cols-2 gap-2">
        <span className="inline-flex min-w-0 items-center gap-1.5 rounded-lg bg-white/70 px-2.5 py-1.5 text-[10.5px] font-bold text-slate-500 dark:bg-white/10 dark:text-slate-400">
          <CatIcon name="users" className="h-[11px] w-[11px] shrink-0 text-amber-500" />
          <span className="truncate">{t("adminPkgLimitUsers")}</span>
          <span className="ms-auto shrink-0 font-extrabold text-slate-800 dark:text-slate-100">
            {fmtNum(pkg.maxUsers, lang)}
          </span>
        </span>
        <span className="inline-flex min-w-0 items-center gap-1.5 rounded-lg bg-white/70 px-2.5 py-1.5 text-[10.5px] font-bold text-slate-500 dark:bg-white/10 dark:text-slate-400">
          <CatIcon name="cubes" className="h-[11px] w-[11px] shrink-0 text-amber-500" />
          <span className="truncate">{t("adminPkgLimitModules")}</span>
          <span className="ms-auto shrink-0 font-extrabold text-slate-800 dark:text-slate-100">
            {fmtNum(pkg.maxModules, lang)}
          </span>
        </span>
      </div>
    </div>
  );
}

export function SubscriberDetailSheet({
  instance,
  open,
  onOpenChange,
}: {
  instance: InstanceDTO | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { t, lang } = useT();

  const detailQuery = useQuery({
    queryKey: ["instance", instance?.id, "admin-detail"],
    queryFn: () => fetchInstance(instance!.id),
    enabled: open && !!instance,
  });

  const queryClient = useQueryClient();

  /* every plan (incl. inactive) — same ["packages"] cache as the packages view */
  const packagesQuery = useQuery({
    queryKey: ["admin-packages"],
    queryFn: fetchPackages,
    staleTime: 30_000,
  });

  const instId = instance?.id ?? "";

  const assignMutation = useMutation({
    mutationFn: (packageId: string | null) => updateInstance(instId, { packageId }),
    onSuccess: () => {
      toast.success(t("adminPkgSaved"));
      queryClient.invalidateQueries({ queryKey: ["instances"] });
      queryClient.invalidateQueries({ queryKey: ["instance", instId] });
      queryClient.invalidateQueries({ queryKey: ["instance", instId, "admin-detail"] });
    },
    /* ROUND 46 (F-7) — plan-assignment rejections localize by error code
       (PACKAGE_ADMIN_ONLY / PLAN_MODULE_LIMIT / …) instead of raw English */
    onError: (error: Error) => toast.error(apiErrorText(error, t)),
  });

  /* plan section reads the freshest DTO available (detail query first) so
     assignments land live while the sheet is open */
  const live = detailQuery.data?.instance ?? instance;
  const packages = packagesQuery.data;
  const activePackages = packages?.filter((p) => p.active) ?? [];

  const currentPkg: PackageSummaryDTO | null =
    live?.package ?? (live?.packageId ? packages?.find((p) => p.id === live.packageId) ?? null : null);

  /* keyed select state — resets automatically whenever another instance opens */
  const [pkgPick, setPkgPick] = useState<{ forId: string; value: string }>({ forId: "", value: "" });
  const selectedPkg = (pkgPick.forId === instId ? pkgPick.value : "") || live?.packageId || "";

  const sys = instance ? SYSTEM_MAP[instance.systemId] : undefined;
  const cat = sys ? CATEGORY_MAP[sys.c] : undefined;
  const c1 = cat?.c1 ?? "#6d5dfb";
  const c2 = cat?.c2 ?? "#0ea5e9";

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side={lang === "ar" ? "right" : "left"}
        className="w-full gap-0 overflow-y-auto p-0 sm:max-w-lg"
      >
        {instance ? (
          <>
            {/* header */}
            {/* pe-14 clears the sheet's floating close (X) button so the
                header text never renders beneath it (round 35 fix) */}
            <SheetHeader className="border-b border-slate-200/70 bg-slate-50/80 px-5 py-4 pe-14 dark:border-white/10 dark:bg-white/[0.03]">
              <SheetTitle className="flex items-center gap-3">
                <IconTile icon={sys?.icon ?? "boxes"} c1={c1} c2={c2} size="md" />
                <div className="min-w-0">
                  <p className="flex flex-wrap items-center gap-1.5 truncate font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                    <span className="truncate">
                      {sys ? (lang === "ar" ? sys.nameAr : sys.nameEn) : instance.systemId}
                    </span>
                    {instance.demo ? (
                      <span
                        className="inline-flex shrink-0 items-center gap-1 rounded-md bg-violet-100 px-1.5 py-0.5 text-[10px] font-bold text-violet-700 dark:bg-violet-500/15 dark:text-violet-300"
                        title={t("adminDemoHint")}
                      >
                        <CatIcon name="flask-conical" className="h-[9px] w-[9px]" />
                        {t("adminDemoBadge")}
                      </span>
                    ) : null}
                  </p>
                  <p className="truncate text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                    {instance.org.name}
                  </p>
                </div>
              </SheetTitle>
              <SheetDescription className="sr-only">{t("adminDetailTitle")}</SheetDescription>
            </SheetHeader>

            <div className="space-y-4 p-5">
              {/* timestamps */}
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-xl border border-slate-200/80 bg-white/60 p-3 dark:border-white/10 dark:bg-white/[0.03]">
                  <p className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                    {t("adminDetailCreated")}
                  </p>
                  <p className="mt-0.5 text-[12px] font-bold text-slate-700 dark:text-slate-200">
                    {fullDate(instance.createdAt, lang)}
                  </p>
                  <p className="text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                    {relativeTime(instance.createdAt, lang)}
                  </p>
                </div>
                <div className="rounded-xl border border-slate-200/80 bg-white/60 p-3 dark:border-white/10 dark:bg-white/[0.03]">
                  <p className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                    {t("adminDetailUpdated")}
                  </p>
                  <p className="mt-0.5 text-[12px] font-bold text-slate-700 dark:text-slate-200">
                    {fullDate(instance.updatedAt, lang)}
                  </p>
                  <p className="text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                    {relativeTime(instance.updatedAt, lang)}
                  </p>
                </div>
              </div>

              {/* organization */}
              <SectionCard title={t("adminDetailOrg")} icon="building" c1={c1} c2={c2}>
                <div className="grid grid-cols-2 gap-3">
                  <div className="col-span-2">
                    <Field label={t("wzOrgName")} value={instance.org.name} />
                  </div>
                  <Field label={t("adminDetailCountry")} value={regionName(instance.org.country, lang)} />
                  <Field label={t("adminDetailCurrency")} value={instance.org.currency} ltr mono />
                  <Field label={t("adminDetailTimezone")} value={instance.org.timezone} ltr mono />
                  <div className="col-span-2">
                    <Field label={t("adminDetailAddress")} value={instance.org.address || "—"} />
                  </div>
                  <div className="col-span-2">
                    <Field label={t("adminDetailPhone")} value={instance.org.phone || "—"} ltr mono />
                  </div>
                </div>
              </SectionCard>

              {/* subscription plan */}
              <SectionCard title={t("adminDetailPackage")} icon="crown" c1="#f59e0b" c2="#d97706">
                {packagesQuery.isPending ? (
                  <div className="space-y-2">
                    <Skeleton className="h-[104px] w-full rounded-xl" />
                    <Skeleton className="h-3.5 w-24 rounded-md" />
                    <Skeleton className="h-[86px] w-full rounded-2xl" />
                    <Skeleton className="h-10 w-full rounded-xl" />
                  </div>
                ) : (
                  <>
                    {currentPkg ? (
                      <AssignedPlanCard pkg={currentPkg} />
                    ) : (
                      <div className="rounded-xl border border-dashed border-slate-200 bg-slate-50/50 px-3 py-3 text-center dark:border-white/10 dark:bg-white/[0.02]">
                        <p className="text-[12px] font-bold text-slate-500 dark:text-slate-400">
                          {t("adminDetailNoPackage")}
                        </p>
                        <p className="mt-0.5 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                          {t("adminDetailNoPackageDesc")}
                        </p>
                      </div>
                    )}

                    {activePackages.length > 0 ? (
                      <div className="mt-2.5 space-y-2">
                        {/* ROUND 48 — premium RTL plan cards (replaces the
                            cramped dropdown rows): every active plan is a
                            selectable card anchored from the far right with
                            the full Arabic identity, price and caps at a
                            glance. */}
                        <p className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                          {t("adminPkgChoose")}
                        </p>
                        <div className="space-y-2">
                          {activePackages.map((p, i) => {
                            const style = PLAN_STYLES[i % PLAN_STYLES.length];
                            const isCurrent = live?.packageId === p.id;
                            const isSelected = selectedPkg === p.id;
                            return (
                              <button
                                type="button"
                                key={p.id}
                                aria-pressed={isSelected}
                                disabled={assignMutation.isPending}
                                onClick={() => setPkgPick({ forId: instId, value: p.id })}
                                className={cn(
                                  "block w-full rounded-2xl border p-3.5 text-start transition-all duration-200 active:scale-[0.99]",
                                  isSelected
                                    ? "border-amber-400 bg-amber-50/50 ring-2 ring-amber-500/70 dark:border-amber-500/50 dark:bg-amber-500/[0.08] dark:ring-amber-500/40"
                                    : "border-slate-200/80 bg-white/60 hover:border-amber-300/70 hover:bg-amber-50/30 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-amber-500/30 dark:hover:bg-amber-500/[0.04]",
                                  assignMutation.isPending && "cursor-wait opacity-60"
                                )}
                              >
                                <span className="flex items-start gap-3">
                                  <span
                                    className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-md"
                                    style={{ backgroundImage: grad(style.c1, style.c2) }}
                                    aria-hidden="true"
                                  >
                                    <CatIcon name={style.icon} className="h-[14px] w-[14px]" />
                                  </span>
                                  <span className="min-w-0 flex-1">
                                    <span className="flex flex-wrap items-center gap-1.5">
                                      <span className="truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
                                        {lang === "ar" ? p.nameAr : p.nameEn}
                                      </span>
                                      {p.popular ? (
                                        <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-linear-to-r from-amber-500 to-orange-500 px-2 py-px text-[11px] font-extrabold text-white shadow-md">
                                          <CatIcon name="star" className="h-[8px] w-[8px] fill-white" />
                                          {t("pkgPopularBadge")}
                                        </span>
                                      ) : null}
                                      {isCurrent ? (
                                        <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-amber-300/70 bg-amber-100 px-2 py-px text-[11px] font-extrabold text-amber-700 dark:border-amber-500/30 dark:bg-amber-500/15 dark:text-amber-300">
                                          <CatIcon name="crown" className="h-[8px] w-[8px]" />
                                          {t("adminPkgCurrent")}
                                        </span>
                                      ) : null}
                                    </span>
                                    <span className="mt-0.5 block truncate text-[11px] font-semibold text-slate-400 dark:text-slate-500">
                                      {lang === "ar" ? p.descAr : p.descEn}
                                    </span>
                                    <span className="mt-2.5 flex flex-wrap items-center justify-between gap-2">
                                      <span className="flex min-w-0 flex-wrap items-baseline gap-1.5">
                                        <span className="font-display text-[17px] font-extrabold leading-none tabular-nums text-slate-900 dark:text-white">
                                          {fmtNum(p.priceMonthly, lang)}
                                        </span>
                                        <span className="text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
                                          {p.currency}
                                        </span>
                                        <span className="text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                                          {t("adminPkgPerMonth")}
                                        </span>
                                      </span>
                                      <span className="flex shrink-0 items-center gap-1.5">
                                        <span className="inline-flex items-center gap-1 rounded-md bg-slate-100 px-1.5 py-px text-[11px] font-extrabold text-slate-500 dark:bg-white/10 dark:text-slate-400">
                                          <CatIcon name="users" className="h-2.5 w-2.5" />
                                          {fmtNum(p.maxUsers, lang)}
                                        </span>
                                        <span className="inline-flex items-center gap-1 rounded-md bg-slate-100 px-1.5 py-px text-[11px] font-extrabold text-slate-500 dark:bg-white/10 dark:text-slate-400">
                                          <CatIcon name="cubes" className="h-2.5 w-2.5" />
                                          {fmtNum(p.maxModules, lang)}
                                        </span>
                                      </span>
                                    </span>
                                  </span>
                                  {/* selection dot — inline-end edge */}
                                  <span
                                    className={cn(
                                      "grid h-5 w-5 shrink-0 self-center place-items-center rounded-full border-2 transition",
                                      isSelected
                                        ? "border-amber-500 bg-amber-500 text-white"
                                        : "border-slate-300 dark:border-white/20"
                                    )}
                                    aria-hidden="true"
                                  >
                                    {isSelected ? <CatIcon name="check" className="h-3 w-3" /> : null}
                                  </span>
                                </span>
                              </button>
                            );
                          })}
                        </div>

                        <div className="flex flex-wrap items-center gap-2">
                          <Button
                            type="button"
                            onClick={() => assignMutation.mutate(selectedPkg || null)}
                            disabled={
                              !selectedPkg || selectedPkg === (live?.packageId ?? null) || assignMutation.isPending
                            }
                            className="h-10 flex-1 rounded-xl bg-linear-to-r from-amber-500 to-orange-500 px-4 text-[12.5px] font-extrabold text-white shadow-lg shadow-amber-500/30 transition hover:from-amber-600 hover:to-orange-600 active:scale-95 disabled:opacity-50 disabled:active:scale-100"
                          >
                            <CatIcon
                              name={assignMutation.isPending ? "refresh-cw" : "crown"}
                              className={cn("h-4 w-4", assignMutation.isPending && "animate-spin")}
                            />
                            {assignMutation.isPending ? t("adminPkgSaving") : t("adminPkgAssign")}
                          </Button>
                          {currentPkg ? (
                            <Button
                              type="button"
                              variant="outline"
                              onClick={() => assignMutation.mutate(null)}
                              disabled={assignMutation.isPending}
                              className="h-10 rounded-xl border-rose-200 bg-transparent px-3.5 text-[12.5px] font-bold text-rose-600 transition hover:bg-rose-50 hover:text-rose-700 active:scale-95 dark:border-rose-500/30 dark:text-rose-400 dark:hover:bg-rose-500/10 disabled:opacity-50 disabled:active:scale-100"
                            >
                              <CatIcon
                                name={assignMutation.isPending ? "refresh-cw" : "trash-2"}
                                className={cn("h-4 w-4", assignMutation.isPending && "animate-spin")}
                              />
                              {t("adminPkgUnassign")}
                            </Button>
                          ) : null}
                        </div>
                      </div>
                    ) : null}
                  </>
                )}
              </SectionCard>

              {/* ROUND 79 — subscription term (paid-term expiry lever) */}
              {live ? <TermSection inst={live} /> : null}

              {/* ROUND 81 — platform governance: ban state (live chip +
                  reason + self-lift instant + one-click lift) */}
              {live ? <SubscriberBanSection inst={live} /> : null}

              {/* ROUND 141 (wallet) — محفظة Ashrilogic: the live balance +
                  the Super-Admin adjustment lever (credit/debit) */}
              {live ? <SubscriberWalletSection inst={live} /> : null}

              {/* ROUND 136 — instance ops & health (super-only drilldown:
                  telemetry on demand + the revoke-all-sessions strict lever) */}
              {live ? <InstanceOpsSection inst={live} /> : null}

              {/* ROUND 79 — per-tenant «مزايا النظام» overrides */}
              {live ? <FeatureOverridesSection inst={live} pkg={currentPkg} /> : null}

              {/* admin */}
              <SectionCard title={t("adminDetailAdmin")} icon="user-tie" c1="#10b981" c2="#059669">
                <div className="grid grid-cols-2 gap-3">
                  <div className="col-span-2">
                    <Field label={t("wzAdminName")} value={instance.admin.name} />
                  </div>
                  <div className="col-span-2">
                    <Field label={t("adminDetailEmail")} value={instance.admin.email} ltr />
                  </div>
                  <Field label={t("adminDetailRole")} value={instance.admin.role === "owner" ? t("wzAdminRoleOwner") : t("wzAdminRoleManager")} />
                  <Field label={t("adminDetailStatus")} value={t("adminStatusActive")} />
                  <div className="col-span-2">
                    <PrefToggle
                      label={t("adminDetail2FA")}
                      on={instance.admin.twoFA}
                      c1="#10b981"
                      c2="#059669"
                    />
                  </div>
                </div>
              </SectionCard>

              {/* preferences */}
              <SectionCard title={t("adminDetailPrefs")} icon="sliders" c1="#d946ef" c2="#c026d3">
                <div className="grid grid-cols-2 gap-3">
                  <Field label={t("adminDetailLang")} value={instance.prefs.lang === "ar" ? "العربية" : "English"} />
                  <Field label={t("adminDetailTheme")} value={instance.prefs.theme} />
                </div>
                <div className="mt-3 grid grid-cols-2 gap-2">
                  <PrefToggle label={t("wzPrefsNotif")} on={instance.prefs.notif} c1="#f59e0b" c2="#ea580c" />
                  <PrefToggle label={t("wzPrefsBackup")} on={instance.prefs.backup} c1="#06b6d4" c2="#0891b2" />
                  <PrefToggle label={t("wzPrefsAudit")} on={instance.prefs.audit} c1="#8b5cf6" c2="#7c3aed" />
                  <PrefToggle label={t("wzPrefsDemo")} on={instance.prefs.demo} c1="#ec4899" c2="#db2777" />
                </div>
              </SectionCard>

              {/* ROUND 136 — modules: SUPER gets the strict toggle grid
                  (PATCH /api/instances/[id] {modules}), everyone else the
                  exact former read-only card */}
              {live ? <ModulesSection inst={live} sys={sys} c1={c1} c2={c2} /> : null}

              {/* recent activity */}
              <SectionCard title={t("adminDetailActivity")} icon="activity" c1="#8b5cf6" c2="#7c3aed">
                {detailQuery.isPending ? (
                  <div className="space-y-2">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <Skeleton key={i} className="h-9 w-full rounded-lg" />
                    ))}
                  </div>
                ) : detailQuery.data && detailQuery.data.instance.activities.length > 0 ? (
                  <ul className="space-y-1.5">
                    {detailQuery.data.instance.activities.slice(0, 6).map((act) => {
                      const st = ACT_STYLE[act.kind];
                      return (
                        <li
                          key={act.id}
                          className="flex items-center gap-2.5 rounded-lg border border-slate-100 bg-white/50 px-2.5 py-2 dark:border-white/[0.06] dark:bg-white/[0.02]"
                        >
                          <span
                            className="grid h-6 w-6 shrink-0 place-items-center rounded-md text-white"
                            style={{ backgroundImage: grad(st.c1, st.c2) }}
                            aria-hidden="true"
                          >
                            <CatIcon name={st.icon} className="h-[9px] w-[9px]" />
                          </span>
                          <span className="min-w-0 flex-1 truncate text-[11.5px] font-bold text-slate-600 dark:text-slate-300">
                            {t(act.kind)}
                          </span>
                          <span className="shrink-0 text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                            {relativeTime(act.createdAt, lang)}
                          </span>
                        </li>
                      );
                    })}
                  </ul>
                ) : (
                  <p className="py-4 text-center text-[12px] font-semibold text-slate-400 dark:text-slate-500">
                    {t("adminDetailNoActivity")}
                  </p>
                )}
              </SectionCard>
            </div>
          </>
        ) : null}
      </SheetContent>
    </Sheet>
  );
}

/* ==================================================================== */
/* ROUND 141 (wallet) — the subscriber's Ashrilogic wallet section        */
/* ==================================================================== */

/** The wallet card inside the subscriber sheet: the live balance (the
 *  append-only ledger's CAS-safe truth) + the Super-Admin adjustment lever
 *  (a complimentary credit or a corrective debit — raw dual-numeral input,
 *  money-moving: unconditional audit + retention floor server-side). */
function SubscriberWalletSection({ inst }: { inst: InstanceDTO }) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const { user } = useAdminAuth();
  const canManage = user?.role === "super" || user?.role === "admin";
  const [adjustOpen, setAdjustOpen] = useState(false);

  /* the wallet projection (admin can read any workspace's wallet) */
  const walletQuery = useQuery({
    queryKey: ["admin-wallet", inst.id],
    queryFn: () => fetchWallet(inst.id),
    enabled: !!inst.id,
    staleTime: 15_000,
  });
  const wallet = walletQuery.data ?? null;
  const balanceMajor = wallet ? wallet.balanceMinor / 100 : 0;

  return (
    <SectionCard title={t("adminWalletCardTitle")} icon="wallet" c1="#059669" c2="#0f766e">
      <div className="flex flex-wrap items-center gap-3">
        <span
          className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
          style={{ backgroundImage: grad("#059669", "#0f766e"), boxShadow: "0 10px 24px -10px rgba(5,150,105,0.7)" }}
          aria-hidden="true"
        >
          <CatIcon name="wallet" className="h-5 w-5" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[11px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
            {t("adminWalletCardBalance")}
          </p>
          {walletQuery.isPending ? (
            <Skeleton className="mt-1 h-7 w-28 rounded-lg" />
          ) : (
            <p dir="ltr" className="mt-0.5 font-display text-[24px] font-extrabold leading-none tabular-nums text-slate-900 dark:text-white">
              {fmtNum(balanceMajor, lang)}
              <span className="ms-1.5 text-[11px] font-bold text-slate-400">SAR</span>
            </p>
          )}
          {wallet && wallet.pendingTopupMinor > 0 ? (
            <p className="mt-1 inline-flex items-center gap-1 rounded-full bg-amber-500/10 px-2 py-0.5 text-[10px] font-extrabold text-amber-600 dark:text-amber-300">
              <CatIcon name="hourglass" className="h-3 w-3" />
              {t("walletPendingChip", { amount: fmtNum(wallet.pendingTopupMinor / 100, lang) })}
            </p>
          ) : null}
        </div>
        {canManage ? (
          <Button
            type="button"
            onClick={() => setAdjustOpen(true)}
            className="h-10 gap-2 rounded-xl bg-linear-to-l from-emerald-600 to-teal-500 px-4 text-[12px] font-extrabold text-white shadow-lg shadow-emerald-500/20 transition hover:brightness-110 active:scale-95"
          >
            <CatIcon name="sliders" className="h-4 w-4" />
            {t("adminWalletCardAdjust")}
          </Button>
        ) : null}
      </div>

      {/* the last ledger rows — the append-only trail at a glance */}
      {wallet && wallet.txns.length > 0 ? (
        <div className="mt-3 space-y-1.5 border-t border-dashed border-slate-200/80 pt-3 dark:border-white/10">
          {wallet.txns.slice(0, 3).map((txn) => {
            const credit = txn.amountMinor > 0;
            return (
              <div key={txn.id} className="flex items-center gap-2 text-[11px]">
                <span
                  className={cn(
                    "inline-flex shrink-0 items-center gap-1 rounded-full px-2 py-px font-extrabold",
                    credit
                      ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-300"
                      : "bg-rose-500/10 text-rose-600 dark:text-rose-300"
                  )}
                >
                  <CatIcon name={credit ? "arrow-down-to-line" : "arrow-up-from-line"} className="h-2.5 w-2.5" />
                  {t(
                    txn.kind === "topup"
                      ? "walletTxnTopup"
                      : txn.kind === "debit"
                        ? "walletTxnDebit"
                        : txn.kind === "refund"
                          ? "walletTxnRefund"
                          : "walletTxnAdjust"
                  )}
                </span>
                <span dir="ltr" className={cn("shrink-0 font-extrabold tabular-nums", credit ? "text-emerald-600 dark:text-emerald-300" : "text-rose-500 dark:text-rose-300")}>
                  {credit ? "+" : "−"}
                  {fmtNum(Math.abs(txn.amountMinor) / 100, lang)}
                </span>
                <span className="min-w-0 flex-1 truncate font-semibold text-slate-400 dark:text-slate-500">
                  {txn.reference || txn.note || ""}
                </span>
                <span className="shrink-0 text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                  {t("walletBalanceAfter", { amount: fmtNum(txn.balanceAfterMinor / 100, lang) })}
                </span>
              </div>
            );
          })}
        </div>
      ) : null}

      {/* the adjustment dialog (credit/debit — money-moving) */}
      <WalletAdjustDialog
        open={adjustOpen}
        onOpenChange={setAdjustOpen}
        inst={inst}
        onDone={() => {
          void queryClient.invalidateQueries({ queryKey: ["admin-wallet", inst.id] });
          void queryClient.invalidateQueries({ queryKey: ["admin-wallet-topups"] });
        }}
      />
    </SectionCard>
  );
}

/** The Super-Admin wallet adjustment dialog: direction + raw dual-numeral
 *  amount + note → POST /api/admin/wallet-adjust (audited unconditionally). */
function WalletAdjustDialog({
  open,
  onOpenChange,
  inst,
  onDone,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  inst: InstanceDTO;
  onDone: () => void;
}) {
  const { t, lang } = useT();
  const [amountRaw, setAmountRaw] = useState("");
  const [direction, setDirection] = useState<"credit" | "debit">("credit");
  const [note, setNote] = useState("");

  const parsed = parseAmountInputToMinor(amountRaw);
  const neutral = amountInputIsNeutral(amountRaw);
  const amountOk = parsed.ok;

  const adjust = useMutation({
    mutationFn: () => {
      if (!parsed.ok) return Promise.reject(new Error(t("walletTopupInvalid")));
      return adminWalletAdjust({
        instanceId: inst.id,
        amount: amountRaw.trim(),
        direction,
        note: note.trim() || undefined,
      });
    },
    onSuccess: () => {
      toast.success(t("adminWalletAdjustDone"));
      setAmountRaw("");
      setNote("");
      onOpenChange(false);
      onDone();
    },
    onError: (error: unknown) => toast.error(apiErrorText(error, t)),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl sm:max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2.5 font-display text-[16px] font-extrabold text-slate-900 dark:text-white">
            <span
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg"
              style={{ backgroundImage: grad("#059669", "#0f766e") }}
              aria-hidden="true"
            >
              <CatIcon name="sliders" className="h-4 w-4" />
            </span>
            {t("adminWalletAdjustTitle")}
          </DialogTitle>
          <DialogDescription className="ps-[46px] text-[12px] leading-relaxed">
            {t("adminWalletAdjustDesc")}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3.5">
          {/* direction toggle */}
          <div className="grid grid-cols-2 gap-2">
            {(["credit", "debit"] as const).map((dir) => (
              <button
                key={dir}
                type="button"
                onClick={() => setDirection(dir)}
                aria-pressed={direction === dir}
                className={cn(
                  "flex h-11 items-center justify-center gap-2 rounded-xl border text-[12px] font-extrabold transition",
                  direction === dir
                    ? dir === "credit"
                      ? "border-emerald-500 bg-emerald-500/[0.08] text-emerald-600 ring-2 ring-emerald-500/40 dark:text-emerald-300"
                      : "border-rose-500 bg-rose-500/[0.08] text-rose-600 ring-2 ring-rose-500/40 dark:text-rose-300"
                    : "border-slate-200 text-slate-500 hover:border-slate-300 dark:border-white/10 dark:text-slate-400"
                )}
              >
                <CatIcon name={dir === "credit" ? "arrow-down-to-line" : "arrow-up-from-line"} className="h-4 w-4" />
                {t(dir === "credit" ? "adminWalletCredit" : "adminWalletDebit")}
              </button>
            ))}
          </div>

          {/* dual-numeral amount */}
          <div className="space-y-1.5">
            <label htmlFor="wallet-adjust-amount" className="text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
              {t("adminWalletAdjustAmount")}
            </label>
            <Input
              id="wallet-adjust-amount"
              value={amountRaw}
              onChange={(e) => setAmountRaw(e.target.value)}
              placeholder={t("walletAmountPh")}
              inputMode="decimal"
              autoComplete="off"
              dir="auto"
              aria-invalid={!neutral && !amountOk ? true : undefined}
              className={cn(
                "h-12 rounded-xl text-center font-display text-[20px] font-extrabold tabular-nums",
                !neutral && !amountOk && "border-rose-400 focus-visible:ring-rose-400/30"
              )}
            />
            <p className={cn("text-[10.5px] font-semibold", !neutral && !amountOk ? "text-rose-500" : "text-slate-400 dark:text-slate-500")}>
              {t("walletAmountHint")}
            </p>
          </div>

          {/* note */}
          <div className="space-y-1.5">
            <label htmlFor="wallet-adjust-note" className="text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
              {t("adminWalletAdjustNote")}
            </label>
            <Input
              id="wallet-adjust-note"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder={t("adminWalletAdjustNotePh")}
              maxLength={160}
              className="h-10 rounded-xl text-[12.5px] font-semibold"
            />
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={adjust.isPending}
              className="h-10 rounded-xl px-5 text-[12.5px] font-bold"
            >
              {t("modRecCancelBtn")}
            </Button>
            <Button
              type="button"
              disabled={!amountOk || adjust.isPending}
              onClick={() => adjust.mutate()}
              className={cn(
                "h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:opacity-60",
                direction === "credit"
                  ? "bg-linear-to-l from-emerald-600 to-teal-500"
                  : "bg-linear-to-l from-rose-600 to-red-500"
              )}
            >
              {adjust.isPending ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : <CatIcon name="check" className="h-4 w-4" />}
              {t(direction === "credit" ? "adminWalletCredit" : "adminWalletDebit")}
            </Button>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default SubscriberDetailSheet;
