"use client";

/**
 * Ashrilogic — admin platform settings view.
 *
 * Settings hub: a sticky section navigator (Account / General / Payments /
 * Social / Security / Notifications / Data & Backup / AI) beside iOS-style
 * setting rows (icon + label + description + control). Edits live in a local
 * draft with dirty tracking — Save PATCHes only the changed fields, Restore
 * discards local edits after an explicit confirm. Singleton row via
 * /api/admin/settings. ROUND 48 — the payments section is a DYNAMIC
 * methods manager: any number of banks / e-wallets / PayPal / Stripe
 * methods, added / edited / deleted here without touching code.
 */
import { useEffect, useMemo, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useTheme } from "next-themes";
import { toast } from "sonner";
import { changeAdminPassword, fetchAiSettings, fetchPlatformSettings, testAiConnection, updateAiSettings, updatePlatformSettings, updateSecurityPolicy } from "@/lib/api-client";
import { useAdminAuth, useAdminCanManage } from "@/lib/admin-auth";
import { ApiError } from "@/lib/api-client";
import {
  BannedIpsCard,
  PasskeysCard,
  SessionsCard,
  TwoFactorCard,
} from "@/components/security/security-cards";
import { useT, type I18nKey } from "@/lib/i18n";
import type {
  AiSettingsDTO,
  PaymentMethod,
  PaymentMethodOptionDTO,
  PaymentsSettingsDTO,
  PlatformIdentityDTO,
  PlatformSettingsDTO,
  PlatformSettingsPayload,
  SocialLinkSetting,
} from "@/lib/types";
import { SOCIAL_LINKS, DEFAULT_SOCIAL_SETTINGS } from "@/lib/social";
import { LOCALES } from "@/lib/locales";
import { DEFAULT_ADDON_PRICES } from "@/lib/addons";
import { FEATURE_META, PLAN_FEATURES, type PlanFeature } from "@/lib/plan-features";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad } from "@/lib/utils";
/* ROUND 87 — the shared image pipeline (validate → decode → compress) for
   the identity logo uploads, and the font registry behind the font pickers. */
import { analyzeImage, ImageAnalysisError } from "@/lib/image-tools";
import { surfaceFont } from "@/lib/surface-styling";
/* invalidation key of the public identity feed (the bridge + every
   usePlatformIdentity consumer share it) */
import { IDENTITY_QUERY_KEY } from "@/components/shared/identity-bridge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { DashCard, MeterBar, ViewHeading, relativeTime } from "@/components/dashboard/dash-shared";
import { NotificationFeed } from "@/components/admin/notification-feed";
import { AdminMailSection } from "@/components/admin/admin-mail";

/* ---------------- settings domain ---------------- */

type SettingsDraft = Omit<PlatformSettingsDTO, "updatedAt">;

/* ROUND 47 — payments is a NESTED object: the local edits overlay keeps a
   PARTIAL payments object (only the touched fields); the draft below merges
   it over the server value so the PATCH always carries the complete object. */
type SettingsEdits = Partial<Omit<SettingsDraft, "payments">> & {
  payments?: Partial<PaymentsSettingsDTO>;
};

const SETTING_KEYS = [
  "siteNameAr",
  "siteNameEn",
  "supportEmail",
  "supportPhone",
  "defaultLang",
  "packageCurrency",
  "maintenanceMode",
  "allowSignup",
  "twoFARequired",
  "sessionTimeout",
  "notifEmail",
  "weeklyDigest",
  "autoBackup",
  "backupFreq",
  "auditLog",
  "dataRetention",
  "socialLinks",
  /* ROUND 47 — nested payment-receiving details (bank + wallet) */
  "payments",
  /* ROUND 87 — the brand identity object + the strict trash retention
     window (both PATCH through the same dirty diff) */
  "identity",
  "trashRetentionDays",
  /* ROUND 141 — the dynamic add-on pricing table (console-controlled
     overrides; the complete object PATCHes, payments law) */
  "addonsPricing",
] as const satisfies readonly (keyof SettingsDraft)[];

const SECTIONS = [
  /* ROUND 45 — personal account security comes first: 2FA + passkeys +
     active sessions for the SIGNED-IN admin (separate from the platform's
     global security policy below). */
  { id: "account", icon: "fingerprint", titleKey: "setSectionAccount" },
  /* ROUND 87 — the platform brand identity (logos / colors / fonts /
     elements / appearance) — second, right after the personal account. */
  { id: "identity", icon: "fingerprint", titleKey: "setSectionIdentity" },
  { id: "general", icon: "sliders", titleKey: "setSectionGeneral" },
  /* ROUND 47 — platform payment-receiving details (bank + wallet) shown to
     tenants on plan activation invoices. */
  { id: "payments", icon: "credit-card", titleKey: "setSectionPayments" },
  { id: "social", icon: "share-2", titleKey: "setSectionSocial" },
  { id: "security", icon: "shield-check", titleKey: "setSectionSecurity" },
  { id: "notifications", icon: "bell", titleKey: "setSectionNotif" },
  /* EMAIL SYSTEM — Communications → Email: the unified mail pipeline's
     console surface (SMTP config, sender identity, test email, health,
     delivery logs). Renders for every admin role; the credential form is
     super-only inside the section (routes enforce it independently). */
  { id: "email", icon: "mail", titleKey: "setSectionEmail" },
  { id: "data", icon: "database-backup", titleKey: "setSectionData" },
  /* ROUND 41 — Super-Admin-only AI/API control panel (nav entry rendered
     only for the super role; the section itself is gated the same way). */
  { id: "ai", icon: "brain", titleKey: "aiAdminTitle" },
] as const;

type SectionId = (typeof SECTIONS)[number]["id"];

const SESSION_MIN = 5;
const SESSION_MAX = 1440;
/* round 26 — retention is a curated set (incl. "no retention"), 0..730 */
const RETENTION_MIN = 0;
const RETENTION_MAX = 3650;
/* ROUND 87 — strict trash retention window bounds (server: 7..365 days) */
const TRASH_RETENTION_MIN = 7;
const TRASH_RETENTION_MAX = 365;

const RETENTION_OPTIONS = [
  { days: 0, key: "setRetentionNone" },
  { days: 7, key: "setRetentionWeek" },
  { days: 14, key: "setRetention2Weeks" },
  { days: 30, key: "setRetentionMonth" },
  { days: 90, key: "setRetention3Months" },
  { days: 180, key: "setRetention6Months" },
  { days: 365, key: "setRetentionYear" },
  { days: 730, key: "setRetention2Years" },
] as const;

/* ROUND 55 — the platform's package-currency options (one source with the
   server enum): USD / SAR / AED lead (the requested trio), the package
   editor's remaining three follow. The symbol + Arabic name make the picker
   self-explanatory without a legend. */
const PKG_CURRENCY_OPTIONS = [
  { code: "USD", symbol: "$", nameAr: "دولار أمريكي", nameEn: "US Dollar" },
  { code: "SAR", symbol: "ر.س", nameAr: "ريال سعودي", nameEn: "Saudi Riyal" },
  { code: "AED", symbol: "د.إ", nameAr: "درهم إماراتي", nameEn: "UAE Dirham" },
  { code: "EGP", symbol: "ج.م", nameAr: "جنيه مصري", nameEn: "Egyptian Pound" },
  { code: "EUR", symbol: "€", nameAr: "يورو", nameEn: "Euro" },
  { code: "GBP", symbol: "£", nameAr: "جنيه إسترليني", nameEn: "British Pound" },
] as const;

/** Field vocabulary shared with the admin login card. */
const FIELD_INPUT =
  "h-11 rounded-xl border-slate-200 bg-slate-50/80 px-3.5 text-[13px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:focus:bg-white/[0.07]";

const clampInt = (n: number, min: number, max: number) =>
  Math.min(max, Math.max(min, Math.round(n)));

function toDraft(dto: PlatformSettingsDTO): SettingsDraft {
  const { updatedAt: _updatedAt, ...draft } = dto;
  /* ROUND 141 — the pricing editor works on the EFFECTIVE table: the
     baseline ladder under the stored overrides (so an untouched editor is
     never spuriously dirty); the PATCH then carries the complete effective
     table — the resolver treats it identically. */
  return {
    ...draft,
    addonsPricing: {
      monthly: { ...DEFAULT_ADDON_PRICES, ...dto.addonsPricing.monthly },
    },
  };
}

/** Diff of editable fields; numeric fields are clamped to their server bounds. */
function diffSettings(initial: SettingsDraft, draft: SettingsDraft): PlatformSettingsPayload {
  const out: PlatformSettingsPayload = {};
  for (const key of SETTING_KEYS) {
    if (initial[key] === draft[key]) continue;
    if (key === "sessionTimeout") {
      out.sessionTimeout = clampInt(draft.sessionTimeout, SESSION_MIN, SESSION_MAX);
    } else if (key === "dataRetention") {
      out.dataRetention = clampInt(draft.dataRetention, RETENTION_MIN, RETENTION_MAX);
    } else if (key === "socialLinks") {
      /* arrays never compare by reference — structural diff via JSON */
      if (JSON.stringify(initial.socialLinks) !== JSON.stringify(draft.socialLinks)) {
        out.socialLinks = draft.socialLinks;
      }
    } else if (key === "payments") {
      /* ROUND 47 — nested object: structural diff; the payload carries the
         COMPLETE merged payments object (never a partial) */
      if (JSON.stringify(initial.payments) !== JSON.stringify(draft.payments)) {
        out.payments = draft.payments;
      }
    } else if (key === "identity") {
      /* ROUND 87 — the identity object: structural diff (null ≡ every
         default); the payload carries the COMPLETE object, payments law */
      if (JSON.stringify(initial.identity) !== JSON.stringify(draft.identity)) {
        out.identity = draft.identity;
      }
    } else if (key === "trashRetentionDays") {
      /* ROUND 87 — clamped to the strict server bounds */
      if (initial.trashRetentionDays !== draft.trashRetentionDays) {
        out.trashRetentionDays = clampInt(draft.trashRetentionDays, TRASH_RETENTION_MIN, TRASH_RETENTION_MAX);
      }
    } else if (key === "addonsPricing") {
      /* ROUND 141 — the pricing table: structural diff; the payload carries
         the COMPLETE effective table (payments law). An empty override
         table on the server still diffs structurally against the effective
         editor table only when the operator actually changed something. */
      if (JSON.stringify(initial.addonsPricing) !== JSON.stringify(draft.addonsPricing)) {
        out.addonsPricing = draft.addonsPricing;
      }
    } else {
      (out as Record<string, unknown>)[key] = draft[key];
    }
  }
  return out;
}

/* ---------------- small building blocks ---------------- */

/** One social network row: brand tile + editable URL + visibility switch. */
function SocialLinkRow({
  row,
  onChange,
}: {
  row: SocialLinkSetting;
  onChange: (next: SocialLinkSetting) => void;
}) {
  const { t, lang } = useT();
  const meta = SOCIAL_LINKS.find((m) => m.icon === row.icon);
  const label = meta ? (lang === "ar" ? meta.labelAr : meta.labelEn) : row.icon;
  const live = row.enabled && row.href.trim().length > 0;

  return (
    <div className="flex flex-col gap-3 py-4 sm:flex-row sm:items-center sm:gap-5">
      <div className="flex min-w-0 flex-1 items-center gap-3">
        <span
          aria-hidden="true"
          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
          style={{ backgroundColor: meta?.color ?? "#64748b" }}
        >
          <CatIcon name={row.icon} className="h-[13px] w-[13px]" />
        </span>
        <div className="min-w-0">
          <p className="flex items-center gap-2 text-[12.5px] font-extrabold leading-tight text-slate-800 dark:text-slate-100">
            <span className="truncate">{label}</span>
            <span
              className={cn(
                "inline-flex shrink-0 items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-extrabold",
                live
                  ? "border-emerald-300/70 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
                  : "border-slate-300/70 bg-slate-500/10 text-slate-500 dark:border-white/15 dark:text-slate-400"
              )}
            >
              <span className={cn("h-1.5 w-1.5 rounded-full", live ? "bg-emerald-500" : "bg-slate-400")} aria-hidden="true" />
              {live ? t("setSocialLiveChip") : t("setSocialHiddenChip")}
            </span>
          </p>
          <p className="mt-0.5 text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("setSocialHint")}
          </p>
        </div>
      </div>
      <div className="flex shrink-0 items-center gap-2.5">
        <div className="relative w-full sm:w-56">
          <CatIcon
            name="link"
            className="pointer-events-none absolute start-3.5 top-1/2 h-[13px] w-[13px] -translate-y-1/2 text-slate-400"
          />
          <Input
            dir="ltr"
            type="url"
            inputMode="url"
            value={row.href}
            maxLength={300}
            aria-label={`${label} — ${t("setSocialUrl")}`}
            placeholder={t("setSocialUrlPh")}
            onChange={(e) => onChange({ ...row, href: e.target.value })}
            className={`${FIELD_INPUT} w-full ps-9 text-start`}
          />
        </div>
        <Switch
          checked={row.enabled}
          onCheckedChange={(v) => onChange({ ...row, enabled: v })}
          aria-label={`${label} — ${live ? t("setSocialLiveChip") : t("setSocialHiddenChip")}`}
        />
      </div>
    </div>
  );
}

function SettingSwitch({
  id,
  label,
  checked,
  onCheckedChange,
  warn,
}: {
  id: string;
  label: string;
  checked: boolean;
  onCheckedChange: (value: boolean) => void;
  warn?: boolean;
}) {
  return (
    <Switch
      id={id}
      tone={warn ? "warn" : "brand"}
      checked={checked}
      onCheckedChange={onCheckedChange}
      aria-label={label}
    />
  );
}

function SettingRow({
  icon,
  c1,
  c2,
  warning,
  label,
  desc,
  htmlFor,
  children,
}: {
  icon?: string;
  c1?: string;
  c2?: string;
  warning?: boolean;
  label: string;
  desc?: string;
  htmlFor?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-3 py-4 sm:flex-row sm:items-center sm:justify-between sm:gap-6">
      <div className="flex min-w-0 items-center gap-3">
        {icon ? (
          <span
            aria-hidden="true"
            className={cn(
              "grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white",
              warning
                ? "bg-linear-to-br from-amber-400 to-orange-500 shadow-md shadow-amber-500/25"
                : undefined
            )}
            style={warning ? undefined : { backgroundImage: grad(c1 ?? "#6d5dfb", c2 ?? "#06b6d4") }}
          >
            <CatIcon name={icon} className="h-[12px] w-[12px]" />
          </span>
        ) : null}
        <div className="min-w-0">
          <Label
            htmlFor={htmlFor}
            className="block text-[12.5px] font-extrabold leading-tight text-slate-800 dark:text-slate-100"
          >
            {label}
          </Label>
          {desc ? (
            <p className="mt-0.5 max-w-md text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {desc}
            </p>
          ) : null}
        </div>
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

/** Numeric field with inline unit suffix; clamps to bounds on blur. */
function NumberField({
  id,
  label,
  value,
  onCommit,
  min,
  max,
  suffix,
}: {
  id: string;
  label: string;
  value: number;
  onCommit: (value: number) => void;
  min: number;
  max: number;
  suffix: string;
}) {
  const [raw, setRaw] = useState(String(value));

  /* re-sync the display when the committed value changes elsewhere (save / restore) */
  useEffect(() => {
    setRaw(String(value));
  }, [value]);

  const commit = (next: string) => {
    const parsed = Number.parseInt(next, 10);
    const clamped = Number.isNaN(parsed) ? value : clampInt(parsed, min, max);
    setRaw(String(clamped));
    onCommit(clamped);
  };

  return (
    /* round 26 overlap fix — the unit rides BESIDE the input as a bordered
       chip instead of an absolutely-positioned overlay, so the digits and
       the unit can never collide in either reading direction */
    <div className="flex w-full items-center gap-1.5 sm:w-44">
      <Input
        id={id}
        type="number"
        inputMode="numeric"
        dir="ltr"
        min={min}
        max={max}
        value={raw}
        aria-label={label}
        onChange={(e) => {
          setRaw(e.target.value);
          const parsed = Number.parseInt(e.target.value, 10);
          if (!Number.isNaN(parsed)) onCommit(parsed);
        }}
        onBlur={() => commit(raw)}
        className={`${FIELD_INPUT} w-full min-w-0 flex-1 appearance-none text-start [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none`}
      />
      <span
        aria-hidden="true"
        className="grid h-11 w-14 shrink-0 select-none place-items-center rounded-xl border border-slate-200 bg-slate-100/70 text-[10.5px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-400"
      >
        {suffix}
      </span>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* ROUND 87 (identity) — the platform brand identity section (الهوية)  */
/* ------------------------------------------------------------------ */

/** The identity font enum (mirrors the server schema). */
const IDENTITY_FONTS = ["tajawal", "cairo", "inter"] as const;
type IdentityFontKey = (typeof IDENTITY_FONTS)[number];

/** The gradient presets — swatch pairs byte-match the platform hero ramp. */
const IDENTITY_GRADIENTS = [
  { key: "primary", c1: "#6d5dfb", c2: "#06b6d4", labelKey: "idGradientPrimary" },
  { key: "sunset", c1: "#f59e0b", c2: "#f43f5e", labelKey: "idGradientSunset" },
  { key: "ocean", c1: "#0ea5e9", c2: "#6366f1", labelKey: "idGradientOcean" },
] as const;

/** The default-theme tiles (null = the platform default, dark). */
const IDENTITY_THEMES = [
  { key: "dark", icon: "moon", labelKey: "idThemeDark" },
  { key: "light", icon: "sun", labelKey: "idThemeLight" },
  { key: "system", icon: "monitor", labelKey: "idThemeSystem" },
] as const;

/* Platform defaults surfaced in the pickers/previews (a null field renders
   identically — only the stored value differs). */
const IDENTITY_DEFAULT_PRIMARY = "#6d5dfb";
const IDENTITY_DEFAULT_ACCENT = "#06b6d4";
const IDENTITY_DEFAULT_RADIUS = 12;

/* file gates — the server caps each stored data-URL at 1M chars (~750KB
   binary): small files join the draft byte-exact (SVG/ICO MUST — no canvas
   re-encode exists for them), oversized rasters run the shared analyzeImage
   compression pipeline first. */
const IDENTITY_MAX_FILE_BYTES = 2 * 1024 * 1024;
const IDENTITY_MAX_DATAURL_CHARS = 950_000;
const IDENTITY_LOGO_ACCEPT = "image/png,image/svg+xml,image/x-icon,image/webp";
const IDENTITY_FAVICON_ACCEPT = "image/png,image/x-icon,image/vnd.microsoft.icon";

/** The image types analyzeImage can re-encode (SVG/ICO cannot). */
const IDENTITY_RASTER_RE = /^image\/(png|jpe?g|webp)$/;

/**
 * One identity image tile (main logo / mini logo / favicon): the current
 * image preview (or a dashed empty state), upload/replace through a hidden
 * file input (FileReader → data-URL, the admin-avatar approach, ~2MB gate)
 * and remove (→ null). NOTHING saves on its own — every edit rides the
 * shared settings draft + the sticky Save button, exactly like every other
 * settings field.
 */
function IdentityImageRow({
  id,
  title,
  desc,
  hint,
  accept,
  value,
  previewClass,
  analyzeOptions,
  canManage,
  round = false,
  onChange,
}: {
  id: string;
  title: string;
  desc: string;
  hint: string;
  accept: string;
  value: string | null | undefined;
  previewClass: string;
  analyzeOptions: { outputSize: number; outputSizeSmall: number; targetBytes: number; minDimension: number };
  canManage: boolean;
  /** ROUND 89 — circular Premium presentation (the favicon tile): a glowing
   *  brand halo + double ring frame + white circular stage, mirroring how
   *  modern browsers render a favicon in tab circles / bookmark bars. */
  round?: boolean;
  onChange: (next: string | null) => void;
}) {
  const { t } = useT();
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);

  const onFile = async (file: File | undefined | null) => {
    if (!file || busy) return;
    if (file.size > IDENTITY_MAX_FILE_BYTES) {
      toast.error(t("siteLogoTooLarge"), { description: hint });
      return;
    }
    if (!file.type.startsWith("image/")) {
      toast.error(t("siteLogoBadType"));
      return;
    }
    setBusy(true);
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(new Error("read"));
        reader.readAsDataURL(file);
      });
      if (dataUrl.length <= IDENTITY_MAX_DATAURL_CHARS) {
        /* byte-exact (covers SVG / ICO and every reasonably-sized raster) */
        onChange(dataUrl);
        return;
      }
      /* an oversized raster gets the shared compression pipeline; a huge
         SVG/ICO has no re-encode path — refuse with the size hint */
      if (IDENTITY_RASTER_RE.test(file.type)) {
        const result = await analyzeImage(file, {
          maxInputBytes: IDENTITY_MAX_FILE_BYTES,
          ...analyzeOptions,
        });
        onChange(result.dataUrl);
      } else {
        toast.error(t("siteLogoTooLarge"), { description: hint });
      }
    } catch (error) {
      const code = error instanceof ImageAnalysisError ? error.code : "corrupt";
      const key: I18nKey =
        code === "bad-type"
          ? "siteLogoBadType"
          : code === "too-large"
            ? "siteLogoTooLarge"
            : code === "tiny"
              ? "siteLogoTiny"
              : "siteLogoCorrupt";
      toast.error(t(key));
    } finally {
      setBusy(false);
      /* allow re-picking the same file */
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  const has = typeof value === "string" && value.length > 0;

  return (
    <div className="flex flex-col gap-3 py-4 sm:flex-row sm:items-center sm:gap-5">
      <div className="flex min-w-0 flex-1 items-start gap-3">
        {has ? (
          round ? (
            /* the circular Premium favicon stage — halo + ring + white disc */
            <span className={cn("relative grid shrink-0 place-items-center", previewClass)}>
              <span
                aria-hidden="true"
                className="absolute -inset-1.5 rounded-full bg-linear-to-br from-brand-500/30 via-fuchsia-400/25 to-cyan-300/30 blur-[6px]"
              />
              <span
                aria-hidden="true"
                className="absolute -inset-[3px] rounded-full border border-slate-200/90 dark:border-white/15"
              />
              <span className="relative grid h-full w-full place-items-center overflow-hidden rounded-full border border-slate-200/70 bg-white shadow-lg ring-2 ring-white dark:border-white/10 dark:bg-white dark:ring-white/15">
                {/* eslint-disable-next-line @next/next/no-img-element -- draft identity data-URL staged for preview; next/image optimization does not apply */}
                <img src={value} alt="" className="h-full w-full object-cover" />
              </span>
            </span>
          ) : (
            <span
              className={cn(
                "grid shrink-0 place-items-center overflow-hidden rounded-2xl border border-slate-200/80 bg-slate-50 p-1.5 dark:border-white/10 dark:bg-white/[0.04]",
                previewClass
              )}
            >
              <img src={value} alt="" className="h-full w-full object-contain" />
            </span>
          )
        ) : (
          <span
            aria-hidden="true"
            className={cn(
              "grid shrink-0 place-items-center border border-dashed border-slate-300/80 bg-white/50 text-slate-400 dark:border-white/15 dark:bg-white/[0.02] dark:text-slate-500",
              round ? "rounded-full" : "rounded-2xl",
              previewClass
            )}
          >
            <CatIcon name="image" className="h-5 w-5" />
          </span>
        )}
        <div className="min-w-0">
          <p className="text-[12.5px] font-extrabold leading-tight text-slate-800 dark:text-slate-100">
            {title}
          </p>
          <p className="mt-0.5 text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {desc}
          </p>
          <p className="mt-1 text-[10.5px] font-bold leading-relaxed text-slate-400/90 dark:text-slate-500">
            {hint}
          </p>
        </div>
      </div>
      {canManage ? (
        <div className="flex shrink-0 flex-wrap items-center gap-2">
          <input
            ref={inputRef}
            id={id}
            type="file"
            accept={accept}
            className="hidden"
            onChange={(e) => void onFile(e.target.files?.[0])}
          />
          <Button
            type="button"
            variant="outline"
            onClick={() => inputRef.current?.click()}
            disabled={busy}
            className="h-9 gap-1.5 rounded-xl border-slate-200 px-3.5 text-[11.5px] font-bold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 disabled:opacity-50 dark:border-white/10 dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
          >
            {busy ? (
              <CatIcon name="refresh-cw" className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <CatIcon name="upload" className="h-3.5 w-3.5" />
            )}
            {has ? t("idReplaceBtn") : t("idUploadBtn")}
          </Button>
          {has ? (
            <Button
              type="button"
              variant="outline"
              onClick={() => onChange(null)}
              disabled={busy}
              className="h-9 gap-1.5 rounded-xl border-slate-200 px-3.5 text-[11.5px] font-bold text-slate-600 transition hover:border-rose-300 hover:text-rose-600 active:scale-95 disabled:opacity-50 dark:border-white/10 dark:text-slate-300 dark:hover:border-rose-400/50 dark:hover:text-rose-300"
            >
              <CatIcon name="x" className="h-3.5 w-3.5" />
              {t("idRemoveBtn")}
            </Button>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

/**
 * One brand color field: a Premium swatch tile (a transparent native color
 * input over it opens the picker) + a hex text input beside it. The picker
 * always SHOWS a color (the platform default when unset); the hex input only
 * commits valid #rrggbb values and reverts invalid ones on blur — the
 * NumberField law, applied to colors.
 */
function IdentityColorField({
  id,
  label,
  value,
  fallback,
  canManage,
  onChange,
}: {
  id: string;
  label: string;
  value: string | null | undefined;
  fallback: string;
  canManage: boolean;
  onChange: (next: string | null) => void;
}) {
  const committed = value ?? fallback;
  /* `typed` holds ONLY an in-progress (possibly invalid) hex; the displayed
     value derives from it — no re-sync effect needed, and external value
     changes (save / restore / the picker itself) are never clobbered */
  const [typed, setTyped] = useState<string | null>(null);
  const shown = typed ?? committed;

  return (
    <div className="min-w-0 space-y-1.5">
      <Label htmlFor={id} className="block text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
        {label}
      </Label>
      <div className="flex items-center gap-2">
        <span className="relative grid h-11 w-11 shrink-0 place-items-center overflow-hidden rounded-xl border border-slate-200 bg-slate-50/80 dark:border-white/10 dark:bg-white/[0.04]">
          <input
            type="color"
            value={committed}
            aria-label={label}
            disabled={!canManage}
            onChange={(e) => {
              setTyped(null);
              onChange(e.target.value.toLowerCase());
            }}
            className="absolute inset-0 h-full w-full cursor-pointer opacity-0 disabled:cursor-not-allowed"
          />
          <span
            aria-hidden="true"
            className="h-6 w-6 rounded-lg border border-white/50 shadow-sm"
            style={{ backgroundColor: committed }}
          />
        </span>
        <Input
          id={id}
          dir="ltr"
          value={shown}
          maxLength={7}
          disabled={!canManage}
          onChange={(e) => {
            const next = e.target.value;
            if (!/^#[0-9a-fA-F]{0,6}$/.test(next)) return;
            setTyped(next);
            if (/^#[0-9a-fA-F]{6}$/.test(next)) onChange(next.toLowerCase());
          }}
          onBlur={() => setTyped(null)}
          className={`${FIELD_INPUT} w-full min-w-0 flex-1 text-start`}
        />
      </div>
    </div>
  );
}

/**
 * The identity tab's LIVE official-site preview: a miniature browser window
 * replaying the landing header + hero EXACTLY as visitors will see them
 * under the CURRENT (unsaved) identity draft — the uploaded logo on its
 * white stage or the shipped gradient tile, the wordmark in the chosen
 * display font, CTAs in the chosen primary at the chosen radius, the chosen
 * gradient preset on the hero banner, and a viewport chrome that flips
 * light/dark with the chosen default-visitor theme (system → follows the
 * operator's console theme). Pure presentation over the same draft state
 * the cards below edit — every tweak reflects instantly, zero saves.
 */
function IdentityLandingPreview({
  value,
  siteName,
  siteNameEn,
}: {
  value: PlatformIdentityDTO | null;
  siteName: string;
  siteNameEn: string;
}) {
  const { t, lang } = useT();
  const { resolvedTheme } = useTheme();

  const primary = value?.primaryColor ?? IDENTITY_DEFAULT_PRIMARY;
  const accent = value?.accentColor ?? IDENTITY_DEFAULT_ACCENT;
  const radius = value?.radius ?? IDENTITY_DEFAULT_RADIUS;
  const displayFont = value?.displayFont ?? null;
  const bodyFont = value?.bodyFont ?? null;
  const displayStack = displayFont
    ? surfaceFont(displayFont)?.display ?? "var(--font-display-app)"
    : "var(--font-display-app)";
  const bodyStack = bodyFont ? surfaceFont(bodyFont)?.sans ?? "var(--font-sans-app)" : "var(--font-sans-app)";

  /* the hero ramp rides the chosen gradient preset (the primary preset is
     DYNAMIC — it follows the live primary/accent draft above it) */
  const preset = IDENTITY_GRADIENTS.find((g) => g.key === (value?.gradient ?? "primary"));
  const heroGrad =
    value?.gradient && value.gradient !== "primary" && preset ? grad(preset.c1, preset.c2) : grad(primary, accent);

  /* viewport chrome — the chosen default visitor theme (system → console) */
  const theme = value?.defaultTheme ?? "dark";
  const dark = theme === "dark" || (theme === "system" && resolvedTheme === "dark");

  /* the header tile shows the uploaded logo (main, mini as fallback) on its
     white stage — exactly what the landing renders once saved */
  const logoUrl = value?.logoUrl || value?.logoMiniUrl || null;

  const r = `${radius}px`;

  return (
    <div
      dir={lang === "ar" ? "rtl" : "ltr"}
      className="overflow-hidden rounded-2xl border border-slate-200/80 bg-slate-100/70 shadow-inner dark:border-white/10 dark:bg-slate-900/50"
    >
      {/* browser chrome — dots + URL pill + window hint */}
      <div className="flex items-center gap-2 border-b border-slate-200/80 bg-white/70 px-3 py-2 dark:border-white/10 dark:bg-white/[0.04]">
        <span className="flex shrink-0 items-center gap-1.5" aria-hidden="true">
          <span className="h-2.5 w-2.5 rounded-full bg-rose-400" />
          <span className="h-2.5 w-2.5 rounded-full bg-amber-400" />
          <span className="h-2.5 w-2.5 rounded-full bg-emerald-400" />
        </span>
        <span
          dir="ltr"
          className="mx-auto flex min-w-0 max-w-[220px] items-center gap-1.5 truncate rounded-full border border-slate-200 bg-white px-3 py-1 text-[10.5px] font-bold text-slate-400 dark:border-white/10 dark:bg-white/[0.06] dark:text-slate-500"
        >
          {/* ROUND 89 — the favicon renders as a circular browser-style chip
              inside the URL pill, exactly like a real tab bar */}
          {value?.faviconUrl ? (
            <span className="grid h-3.5 w-3.5 shrink-0 place-items-center overflow-hidden rounded-full bg-white ring-1 ring-slate-200 dark:ring-white/20">
              {/* eslint-disable-next-line @next/next/no-img-element -- draft identity data-URL staged for preview; next/image optimization does not apply */}
              <img src={value.faviconUrl} alt="" className="h-full w-full object-cover" />
            </span>
          ) : (
            <span
              aria-hidden="true"
              className="grid h-3.5 w-3.5 shrink-0 place-items-center rounded-full bg-linear-to-br from-brand-500/70 to-cyan-400/70"
            />
          )}
          <CatIcon name="lock" className="h-2.5 w-2.5 shrink-0 text-emerald-500" />
          <span className="truncate">{siteNameEn || "ashrilogic"}</span>
        </span>
        <span className="w-10 shrink-0" aria-hidden="true" />
      </div>

      {/* viewport — replays the landing header + hero under the draft identity */}
      <div
        style={{ fontFamily: bodyStack }}
        className={cn(
          "min-h-[210px] space-y-4 p-4 transition-colors",
          dark ? "bg-[#05080f] text-slate-200" : "bg-white text-slate-700"
        )}
      >
        {/* mini landing header */}
        <div className="flex items-center justify-between gap-3">
          <div className="flex min-w-0 items-center gap-2">
            {logoUrl ? (
              <span
                className="grid h-8 w-8 shrink-0 place-items-center overflow-hidden border border-slate-200/80 bg-white dark:border-white/10 dark:bg-white/90"
                style={{ borderRadius: r }}
              >
                {/* eslint-disable-next-line @next/next/no-img-element -- draft identity data-URL staged for preview; next/image optimization does not apply */}
                <img src={logoUrl} alt="" className="h-full w-full object-contain p-0.5" />
              </span>
            ) : (
              <span
                className="grid h-8 w-8 shrink-0 place-items-center text-white"
                style={{ borderRadius: r, backgroundImage: heroGrad }}
                aria-hidden="true"
              >
                <CatIcon name="boxes" className="h-3 w-3" />
              </span>
            )}
            <span className="min-w-0">
              <span
                className="block truncate text-[13px] font-extrabold leading-none"
                style={{
                  fontFamily: displayStack,
                  color: dark ? "#ffffff" : "#0f172a",
                }}
              >
                {siteName || "Ashrilogic"}
              </span>
              <span className="mt-0.5 block text-[8px] font-semibold text-slate-400">
                {t("brandTagline")}
              </span>
            </span>
          </div>
          <div className="hidden items-center gap-2 sm:flex">
            {[t("navSystems"), t("navFeatures"), t("navPricing")].map((label) => (
              <span key={label} className="text-[9.5px] font-bold text-slate-400">
                {label}
              </span>
            ))}
          </div>
          <span
            className="shrink-0 px-3 py-1.5 text-[9.5px] font-extrabold text-white"
            style={{ backgroundColor: primary, borderRadius: r }}
          >
            {t("startNow")}
          </span>
        </div>

        {/* mini hero banner — the chosen gradient preset + display font */}
        <div
          className="relative overflow-hidden p-4"
          style={{ borderRadius: `calc(${r} + 6px)`, backgroundImage: heroGrad }}
        >
          <div className="relative z-10 max-w-[75%]">
            <p className="text-[15px] font-extrabold leading-snug text-white" style={{ fontFamily: displayStack }}>
              {t("heroTitle1")} {t("heroTitle2")}
            </p>
            <p className="mt-1 text-[10px] font-medium leading-relaxed text-white/85">
              {t("heroTitle3")}
            </p>
            <span
              className="mt-2.5 inline-block bg-white/95 px-3 py-1.5 text-[9.5px] font-extrabold"
              style={{ borderRadius: r, color: primary }}
            >
              {t("startNow")}
            </span>
          </div>
          {/* soft radial shine — the landing hero's light bloom */}
          <span
            className="pointer-events-none absolute inset-0"
            style={{ background: "radial-gradient(320px circle at 85% 20%, rgba(255,255,255,0.22), transparent 65%)" }}
            aria-hidden="true"
          />
        </div>

        {/* mini feature trio — the chosen radius on light card surfaces */}
        <div className="grid grid-cols-3 gap-2">
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className={cn(
                "block h-12 p-2",
                dark ? "bg-white/[0.05]" : "bg-slate-50"
              )}
              style={{
                borderRadius: r,
                border: i === 0 ? `1.5px solid ${primary}55` : undefined,
              }}
              aria-hidden="true"
            >
              <span
                className="mb-1.5 block h-3 w-3"
                style={{ borderRadius: `calc(${r} / 2)`, backgroundImage: i === 1 ? heroGrad : undefined, backgroundColor: i !== 1 ? `${primary}30` : undefined }}
              />
              <span className={cn("block h-1.5 w-3/4 rounded-full", dark ? "bg-white/15" : "bg-slate-200")} />
              <span className={cn("mt-1 block h-1.5 w-1/2 rounded-full", dark ? "bg-white/10" : "bg-slate-100")} />
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------- ROUND 87 (identity) --*/

/**
 * The الهوية section — the LIVE official-site preview browser plus FIVE
 * Premium cards over the shared settings draft: the logos (three upload
 * tiles), the brand colors (with a live preview strip), the fonts (with a
 * live font preview card), the brand elements (radius slider + gradient
 * picker) and the appearance (default theme). Every edit rides the SAME
 * dirty diff + sticky Save as the rest of the console — nothing here saves
 * on its own.
 */
function IdentitySection({
  value,
  siteName,
  siteNameEn,
  canManage,
  onChange,
}: {
  value: PlatformIdentityDTO | null;
  siteName: string;
  siteNameEn: string;
  canManage: boolean;
  onChange: (next: PlatformIdentityDTO) => void;
}) {
  const { t, lang } = useT();

  const set = (patch: Partial<PlatformIdentityDTO>) => onChange({ ...value, ...patch });

  const primary = value?.primaryColor ?? IDENTITY_DEFAULT_PRIMARY;
  const accent = value?.accentColor ?? IDENTITY_DEFAULT_ACCENT;
  const radius = value?.radius ?? IDENTITY_DEFAULT_RADIUS;
  const displayFont = value?.displayFont ?? null;
  const bodyFont = value?.bodyFont ?? null;

  /* the REAL font stacks: the surface registry's canonical per-face stacks,
     falling back to the globals.css root variables (the platform defaults) */
  const displayStack = displayFont
    ? surfaceFont(displayFont)?.display ?? "var(--font-display-app)"
    : "var(--font-display-app)";
  const bodyStack = bodyFont
    ? surfaceFont(bodyFont)?.sans ?? "var(--font-sans-app)"
    : "var(--font-sans-app)";

  const fontSelect = (mode: "display" | "body") => {
    const current = mode === "display" ? displayFont : bodyFont;
    const label = mode === "display" ? t("idFontDisplay") : t("idFontBody");
    return (
      <div className="min-w-0 space-y-1.5">
        <Label className="block text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
          {label}
        </Label>
        <Select
          value={current ?? "__default"}
          onValueChange={(v) =>
            set(mode === "display" ? { displayFont: v === "__default" ? null : (v as IdentityFontKey) } : { bodyFont: v === "__default" ? null : (v as IdentityFontKey) })
          }
          dir={lang === "ar" ? "rtl" : "ltr"}
          disabled={!canManage}
        >
          <SelectTrigger
            id={mode === "display" ? "id-font-display" : "id-font-body"}
            className={`${FIELD_INPUT} w-full justify-between`}
          >
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="rounded-xl">
            <SelectGroup>
              <SelectItem value="__default" className="text-[12.5px] font-bold">
                {t("cfsFontDefault")}
              </SelectItem>
              {IDENTITY_FONTS.map((key) => {
                const def = surfaceFont(key);
                return (
                  <SelectItem key={key} value={key} className="text-[12.5px] font-bold">
                    {def ? (lang === "ar" ? def.labelAr : def.labelEn) : key}
                  </SelectItem>
                );
              })}
            </SelectGroup>
          </SelectContent>
        </Select>
      </div>
    );
  };

  return (
    <div className="space-y-5">
      {/* card 0 — the LIVE official-site preview browser (every card below
          edits the draft this replays) */}
      <DashCard title={t("idPreviewTitle")} icon="eye">
        <p className="text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
          {t("idPreviewDesc")}
        </p>
        <div className="mt-4">
          <IdentityLandingPreview value={value} siteName={siteName} siteNameEn={siteNameEn} />
        </div>
      </DashCard>

      {/* card 1 — the logos (main / mini / favicon) */}
      <DashCard title={t("setSectionIdentity")} icon="fingerprint">
        <div className="divide-y divide-slate-100 dark:divide-white/[0.06]">
          <IdentityImageRow
            id="id-logo-file"
            title={t("idCardLogo")}
            desc={t("idCardLogoDesc")}
            hint={t("idLogoHint")}
            accept={IDENTITY_LOGO_ACCEPT}
            value={value?.logoUrl ?? null}
            previewClass="h-16 w-16"
            analyzeOptions={{ outputSize: 512, outputSizeSmall: 320, targetBytes: 380 * 1024, minDimension: 64 }}
            canManage={canManage}
            onChange={(next) => set({ logoUrl: next })}
          />
          <IdentityImageRow
            id="id-logo-mini-file"
            title={t("idCardLogoMini")}
            desc={t("idCardLogoMiniDesc")}
            hint={t("idLogoHint")}
            accept={IDENTITY_LOGO_ACCEPT}
            value={value?.logoMiniUrl ?? null}
            previewClass="h-12 w-12"
            analyzeOptions={{ outputSize: 256, outputSizeSmall: 160, targetBytes: 200 * 1024, minDimension: 32 }}
            canManage={canManage}
            onChange={(next) => set({ logoMiniUrl: next })}
          />
          <IdentityImageRow
            id="id-favicon-file"
            title={t("idCardFavicon")}
            desc={t("idCardFaviconDesc")}
            hint={t("idFaviconHint")}
            accept={IDENTITY_FAVICON_ACCEPT}
            value={value?.faviconUrl ?? null}
            previewClass="h-14 w-14"
            analyzeOptions={{ outputSize: 128, outputSizeSmall: 96, targetBytes: 100 * 1024, minDimension: 16 }}
            canManage={canManage}
            round
            onChange={(next) => set({ faviconUrl: next })}
          />
        </div>
      </DashCard>

      {/* card 2 — brand colors */}
      <DashCard title={t("idCardColors")} icon="palette">
        <div className="grid gap-4 sm:grid-cols-2">
          <IdentityColorField
            id="id-color-primary"
            label={t("idColorPrimary")}
            value={value?.primaryColor ?? null}
            fallback={IDENTITY_DEFAULT_PRIMARY}
            canManage={canManage}
            onChange={(next) => set({ primaryColor: next })}
          />
          <IdentityColorField
            id="id-color-accent"
            label={t("idColorAccent")}
            value={value?.accentColor ?? null}
            fallback={IDENTITY_DEFAULT_ACCENT}
            canManage={canManage}
            onChange={(next) => set({ accentColor: next })}
          />
        </div>
        {/* live preview strip — a mini brand button + gradient bar in the
            chosen colors, at the chosen corner radius */}
        <div className="mt-4 rounded-2xl border border-slate-200/80 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]">
          <div className="flex flex-wrap items-center gap-4">
            <span
              className="inline-flex h-10 select-none items-center px-5 text-[12.5px] font-extrabold text-white"
              style={{ backgroundColor: primary, borderRadius: `${radius}px` }}
            >
              {siteName}
            </span>
            <span
              aria-hidden="true"
              className="h-3 min-w-32 flex-1 rounded-full"
              style={{ backgroundImage: grad(primary, accent, 90) }}
            />
            <span className="flex shrink-0 items-center gap-2" aria-hidden="true">
              <span className="h-6 w-6 rounded-lg border border-slate-200 dark:border-white/10" style={{ backgroundColor: primary }} title={primary} />
              <span className="h-6 w-6 rounded-lg border border-slate-200 dark:border-white/10" style={{ backgroundColor: accent }} title={accent} />
            </span>
          </div>
        </div>
        <div className="mt-3 flex justify-end border-t border-dashed border-slate-200 pt-3 dark:border-white/10">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            disabled={!canManage || (value?.primaryColor == null && value?.accentColor == null)}
            onClick={() => set({ primaryColor: null, accentColor: null })}
            className="h-8 gap-1.5 rounded-lg px-3 text-[11px] font-bold text-slate-500 transition hover:text-brand-600 dark:text-slate-400 dark:hover:text-brand-300"
          >
            <CatIcon name="clock-rotate-left" className="h-3.5 w-3.5" />
            {t("idColorsReset")}
          </Button>
        </div>
      </DashCard>

      {/* card 3 — fonts */}
      <DashCard title={t("idCardFonts")} icon="languages">
        <div className="grid gap-4 sm:grid-cols-2">
          {fontSelect("display")}
          {fontSelect("body")}
        </div>
        {/* live preview — the headline in the chosen display font, the body
            copy in the chosen body font */}
        <div className="mt-4 rounded-2xl border border-slate-200/80 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]">
          <p className="text-[10.5px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500">
            {t("idFontPreviewTitle")}
          </p>
          <p
            className="mt-2 text-[20px] font-extrabold leading-snug text-slate-900 dark:text-white"
            style={{ fontFamily: displayStack }}
          >
            {t("idFontPreviewHead")}
          </p>
          <p
            className="mt-2 max-w-xl text-[13px] font-medium leading-relaxed text-slate-600 dark:text-slate-300"
            style={{ fontFamily: bodyStack }}
          >
            {t("idFontPreviewBody")}
          </p>
        </div>
      </DashCard>

      {/* card 4 — brand elements (radius + gradient) */}
      <DashCard title={t("idCardElements")} icon="shapes">
        {/* corner radius */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between gap-3">
            <Label htmlFor="id-radius" className="text-[12px] font-extrabold text-slate-800 dark:text-slate-100">
              {t("idRadiusLabel")}
            </Label>
            <span
              dir="ltr"
              className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-slate-100/70 px-2.5 py-1 text-[10.5px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-400"
            >
              {fmtNum(radius, lang)} px
            </span>
          </div>
          <input
            id="id-radius"
            type="range"
            min={4}
            max={28}
            step={1}
            value={radius}
            disabled={!canManage}
            aria-label={t("idRadiusLabel")}
            onChange={(e) => set({ radius: Number.parseInt(e.target.value, 10) })}
            className="w-full cursor-pointer disabled:cursor-not-allowed"
            style={{ accentColor: primary }}
          />
          {/* live radius preview — outline / solid / gradient chips */}
          <div className="flex items-center gap-3 pt-1" aria-hidden="true">
            <span className="h-9 w-14 border-2" style={{ borderRadius: `${radius}px`, borderColor: primary }} />
            <span className="h-9 w-14" style={{ borderRadius: `${radius}px`, backgroundColor: primary }} />
            <span className="h-9 w-20" style={{ borderRadius: `${radius}px`, backgroundImage: grad(primary, accent, 90) }} />
          </div>
        </div>
        {/* brand gradient */}
        <div className="mt-5 space-y-2.5 border-t border-dashed border-slate-200 pt-4 dark:border-white/10">
          <p className="text-[12px] font-extrabold text-slate-800 dark:text-slate-100">{t("idGradientLabel")}</p>
          <div className="grid grid-cols-3 gap-2.5">
            {IDENTITY_GRADIENTS.map((g) => {
              const active = (value?.gradient ?? "primary") === g.key;
              return (
                <button
                  key={g.key}
                  type="button"
                  disabled={!canManage}
                  aria-pressed={active}
                  onClick={() => set({ gradient: g.key })}
                  className={cn(
                    "rounded-2xl border p-3 text-center transition-all duration-200 active:scale-95 disabled:cursor-not-allowed disabled:opacity-60",
                    active
                      ? "border-brand-500 bg-brand-50/60 ring-2 ring-brand-500/50 dark:border-brand-500/60 dark:bg-brand-500/[0.08]"
                      : "border-slate-200/80 bg-white/60 hover:border-brand-300/70 hover:bg-brand-50/40 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-brand-500/30 dark:hover:bg-brand-500/[0.05]"
                  )}
                >
                  <span
                    className="block h-8 w-full rounded-lg shadow-sm"
                    style={{ backgroundImage: grad(g.c1, g.c2) }}
                    aria-hidden="true"
                  />
                  <span className="mt-1.5 block text-[11px] font-extrabold leading-tight text-slate-800 dark:text-slate-100">
                    {t(g.labelKey)}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </DashCard>

      {/* card 5 — appearance (default visitor theme) */}
      <DashCard title={t("idCardAppearance")} icon="monitor">
        <p className="text-[12px] font-extrabold text-slate-800 dark:text-slate-100">{t("idThemeLabel")}</p>
        <div className="mt-2.5 grid grid-cols-3 gap-2.5">
          {IDENTITY_THEMES.map((th) => {
            const active = (value?.defaultTheme ?? "dark") === th.key;
            return (
              <button
                key={th.key}
                type="button"
                disabled={!canManage}
                aria-pressed={active}
                onClick={() => set({ defaultTheme: th.key })}
                className={cn(
                  "flex flex-col items-center gap-1.5 rounded-2xl border p-3 text-center transition-all duration-200 active:scale-95 disabled:cursor-not-allowed disabled:opacity-60",
                  active
                    ? "border-brand-500 bg-brand-50/60 ring-2 ring-brand-500/50 dark:border-brand-500/60 dark:bg-brand-500/[0.08]"
                    : "border-slate-200/80 bg-white/60 hover:border-brand-300/70 hover:bg-brand-50/40 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-brand-500/30 dark:hover:bg-brand-500/[0.05]"
                )}
              >
                <span
                  className={cn(
                    "grid h-9 w-9 place-items-center rounded-xl text-white shadow-md",
                    !active && "bg-slate-400 dark:bg-slate-600"
                  )}
                  style={active ? { backgroundImage: grad(primary, accent) } : undefined}
                  aria-hidden="true"
                >
                  <CatIcon name={th.icon} className="h-4 w-4" />
                </span>
                <span className="text-[11px] font-extrabold leading-tight text-slate-800 dark:text-slate-100">
                  {t(th.labelKey)}
                </span>
              </button>
            );
          })}
        </div>
      </DashCard>
    </div>
  );
}

/* ---------------- ROUND 41 — Super-Admin AI/API control panel ---------------- */

/**
 * The AI/API card: master switch, model label, monthly quota + usage meter,
 * sealed provider key (write-only), key rotation and a live connectivity
 * test. SUPER-ONLY — the parent renders this section (and its nav entry)
 * only for user.role === "super", mirroring the super-only posture of the
 * /api/admin/ai routes. The key itself NEVER renders back: the server DTO
 * exposes hasApiKey, the input shows a bullet placeholder when a key exists.
 */
function AiAdminSection() {
  const { t, lang } = useT();

  const [dto, setDto] = useState<AiSettingsDTO | null>(null);
  const [loadFailed, setLoadFailed] = useState(false);
  const [enabled, setEnabled] = useState(false);
  const [model, setModel] = useState("");
  const [quota, setQuota] = useState(500);
  const [apiKey, setApiKey] = useState("");
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [rotating, setRotating] = useState(false);

  /* panel state loads once on mount (the parent gates the render to super) */
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await fetchAiSettings();
        if (cancelled) return;
        setDto(data);
        setEnabled(data.enabled);
        setModel(data.model);
        setQuota(data.monthlyQuota);
      } catch {
        if (!cancelled) setLoadFailed(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const applyDto = (data: AiSettingsDTO) => {
    setDto(data);
    setEnabled(data.enabled);
    setModel(data.model);
    setQuota(data.monthlyQuota);
  };

  const save = async () => {
    if (saving) return;
    setSaving(true);
    try {
      const data = await updateAiSettings({
        enabled,
        model: model.trim() || "glm-4.6",
        monthlyQuota: clampInt(quota, 0, 100_000),
        /* only seal a NEW key when one was typed (min provider-key length) */
        ...(apiKey.trim().length >= 10 ? { apiKey: apiKey.trim() } : {}),
      });
      applyDto(data);
      setApiKey("");
      toast.success(t("aiSavedToast"));
    } catch (error) {
      toast.error(error instanceof Error ? error.message : t("setSaveErr"));
    } finally {
      setSaving(false);
    }
  };

  const rotate = async () => {
    if (rotating) return;
    setRotating(true);
    try {
      const data = await updateAiSettings({ rotateKey: true });
      applyDto(data);
      setApiKey("");
      toast.success(t("aiSavedToast"));
    } catch (error) {
      toast.error(error instanceof Error ? error.message : t("setSaveErr"));
    } finally {
      setRotating(false);
    }
  };

  const test = async () => {
    if (testing) return;
    setTesting(true);
    try {
      const res = await testAiConnection();
      if (res.ok) {
        toast.success(t("aiTestOk"), { description: res.detail });
      } else {
        toast.error(t("aiTestFail"), { description: res.detail });
      }
    } catch (error) {
      toast.error(t("aiTestFail"), {
        description: error instanceof Error ? error.message : undefined,
      });
    } finally {
      setTesting(false);
    }
  };

  if (loadFailed) {
    return (
      <DashCard title={t("aiAdminTitle")} icon="brain">
        <div className="py-8 text-center">
          <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-rose-100 text-rose-500 dark:bg-rose-500/10 dark:text-rose-300">
            <CatIcon name="circle-alert" className="h-5 w-5" />
          </div>
          <p className="mt-3 text-[13px] font-extrabold text-slate-700 dark:text-slate-200">{t("errorText")}</p>
          <Button
            type="button"
            variant="outline"
            onClick={() => {
              setLoadFailed(false);
              /* re-run the mount probe */
              void (async () => {
                try {
                  applyDto(await fetchAiSettings());
                } catch {
                  setLoadFailed(true);
                }
              })();
            }}
            className="mt-4 h-10 gap-2 rounded-xl px-4 text-[12px] font-bold"
          >
            <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
            {t("retryText")}
          </Button>
        </div>
      </DashCard>
    );
  }

  if (!dto) {
    return (
      <DashCard title={t("aiAdminTitle")} icon="brain">
        <div className="space-y-3">
          {[0, 1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-14 rounded-2xl" />
          ))}
        </div>
      </DashCard>
    );
  }

  const quotaPct = dto.monthlyQuota > 0 ? Math.min(100, (dto.usedThisMonth / dto.monthlyQuota) * 100) : 0;
  const quotaColor =
    quotaPct >= 90
      ? "linear-gradient(90deg,#f43f5e,#e11d48)"
      : quotaPct >= 70
        ? "linear-gradient(90deg,#f59e0b,#d97706)"
        : "linear-gradient(90deg,#06b6d4,#0891b2)";

  return (
    <DashCard
      title={t("aiAdminTitle")}
      icon="brain"
      action={
        <div className="flex items-center gap-2">
          <Badge className="rounded-full bg-fuchsia-500/10 px-2.5 py-0.5 text-[10px] font-extrabold text-fuchsia-600 hover:bg-fuchsia-500/10 dark:text-fuchsia-300">
            {t("aiSuperOnly")}
          </Badge>
          <Badge
            className={cn(
              "gap-1 rounded-full px-2.5 py-0.5 text-[10px] font-extrabold",
              dto.enabled
                ? "bg-emerald-500/15 text-emerald-600 hover:bg-emerald-500/15 dark:text-emerald-300"
                : "bg-rose-500/15 text-rose-600 hover:bg-rose-500/15 dark:text-rose-300"
            )}
          >
            <span className={cn("h-1.5 w-1.5 rounded-full", dto.enabled ? "bg-emerald-500" : "bg-rose-500")} aria-hidden="true" />
            {dto.enabled ? t("aiStatusOn") : t("aiStatusOff")}
          </Badge>
        </div>
      }
    >
      <p className="mb-2 max-w-lg text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
        {t("aiAdminDesc")}
      </p>
      <div className="divide-y divide-slate-100 dark:divide-white/[0.06]">
        <SettingRow
          icon="wand-sparkles"
          c1="#6d5dfb"
          c2="#d946ef"
          label={t("aiMasterToggle")}
          desc={t("aiMasterToggleD")}
          htmlFor="set-ai-enabled"
        >
          <SettingSwitch
            id="set-ai-enabled"
            label={t("aiMasterToggle")}
            checked={enabled}
            onCheckedChange={setEnabled}
          />
        </SettingRow>
        <SettingRow icon="cpu" c1="#06b6d4" c2="#0891b2" label={t("aiModelLabel")} htmlFor="set-ai-model">
          <Input
            id="set-ai-model"
            dir="ltr"
            value={model}
            maxLength={60}
            placeholder="glm-4.6"
            onChange={(e) => setModel(e.target.value)}
            className={`${FIELD_INPUT} w-full text-start sm:w-56`}
          />
        </SettingRow>
        <SettingRow icon="gauge" c1="#f59e0b" c2="#d97706" label={t("aiMonthlyQuota")} htmlFor="set-ai-quota">
          <div className="flex w-full items-center gap-1.5 sm:w-44">
            <Input
              id="set-ai-quota"
              type="number"
              inputMode="numeric"
              dir="ltr"
              min={0}
              max={100000}
              value={quota}
              aria-label={t("aiMonthlyQuota")}
              onChange={(e) => {
                const parsed = Number.parseInt(e.target.value, 10);
                setQuota(Number.isNaN(parsed) ? 0 : parsed);
              }}
              onBlur={() => setQuota((q) => clampInt(q, 0, 100_000))}
              className={`${FIELD_INPUT} w-full min-w-0 flex-1 appearance-none text-start [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none`}
            />
            <span
              aria-hidden="true"
              className="grid h-11 w-14 shrink-0 select-none place-items-center rounded-xl border border-slate-200 bg-slate-100/70 text-[10.5px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-400"
            >
              {t("pkgPerMonth")}
            </span>
          </div>
        </SettingRow>
        <SettingRow icon="chart-pie" c1="#8b5cf6" c2="#6d28d9" label={t("aiQuotaUsed")}>
          <div className="flex w-full flex-col items-end gap-1.5 sm:w-52">
            <p className="font-display text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
              {fmtNum(dto.usedThisMonth, lang)} / {fmtNum(dto.monthlyQuota, lang)}
            </p>
            <MeterBar value={quotaPct} color={quotaColor} />
          </div>
        </SettingRow>
        <SettingRow icon="key-round" c1="#10b981" c2="#059669" label={t("aiApiKeyLabel")} htmlFor="set-ai-key">
          <div className="flex w-full flex-col items-end gap-1.5 sm:w-64">
            <div className="relative w-full">
              <CatIcon
                name="key-round"
                className="pointer-events-none absolute start-3.5 top-1/2 h-[13px] w-[13px] -translate-y-1/2 text-slate-400"
              />
              <Input
                id="set-ai-key"
                type="password"
                dir="ltr"
                autoComplete="new-password"
                value={apiKey}
                maxLength={500}
                placeholder={dto.hasApiKey ? "••••••••" : t("aiApiKeyPh")}
                onChange={(e) => setApiKey(e.target.value)}
                className={`${FIELD_INPUT} w-full ps-9 text-start`}
              />
            </div>
            <p className="max-w-full text-end text-[10px] font-bold leading-relaxed text-slate-400 dark:text-slate-500">
              {t("aiApiKeyHint")}
            </p>
          </div>
        </SettingRow>
      </div>

      {/* actions — test / rotate / save */}
      <div className="mt-4 flex flex-wrap items-center justify-end gap-2 border-t border-dashed border-slate-200 pt-4 dark:border-white/10">
        <Button
          type="button"
          variant="outline"
          onClick={test}
          disabled={testing || saving}
          className="h-10 gap-2 rounded-xl border-slate-200 px-4 text-[12px] font-bold text-slate-600 transition hover:border-cyan-300 hover:text-cyan-600 active:scale-95 disabled:opacity-50 dark:border-white/10 dark:text-slate-300 dark:hover:border-cyan-400/50 dark:hover:text-cyan-300"
        >
          <CatIcon name="plug-zap" className="h-3.5 w-3.5" />
          {testing ? <CatIcon name="refresh-cw" className="h-3.5 w-3.5 animate-spin" /> : null}
          {t("aiTestBtn")}
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={rotate}
          disabled={rotating || saving || !dto.hasApiKey}
          title={!dto.hasApiKey ? t("aiApiKeyHint") : undefined}
          className="h-10 gap-2 rounded-xl border-rose-200 px-4 text-[12px] font-bold text-rose-600 transition hover:border-rose-300 hover:text-rose-700 active:scale-95 disabled:opacity-50 dark:border-rose-500/30 dark:text-rose-300 dark:hover:border-rose-400/50 dark:hover:text-rose-200"
        >
          <CatIcon name="refresh-cw" className={cn("h-3.5 w-3.5", rotating && "animate-spin")} />
          {t("aiResetKey")}
        </Button>
        <Button
          type="button"
          onClick={save}
          disabled={saving}
          className="h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-50"
          style={{ backgroundImage: grad("#6d5dfb", "#d946ef") }}
        >
          {saving ? (
            <CatIcon name="refresh-cw" className="h-3.5 w-3.5 animate-spin" />
          ) : (
            <CatIcon name="save" className="h-3.5 w-3.5" />
          )}
          {t("aiSaveBtn")}
        </Button>
      </div>
    </DashCard>
  );
}

/* ---------------- view ---------------- */

/* ------------------------------------------------------------------ */
/* ROUND 46 (F-4) — self-service password rotation card                */
/* ------------------------------------------------------------------ */

function AdminMyPasswordCard() {
  const { t } = useT();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [show, setShow] = useState(false);

  const rotate = useMutation({
    mutationFn: () => changeAdminPassword(current, next),
    onSuccess: () => {
      toast.success(t("adminMyPasswordDone"));
      setCurrent("");
      setNext("");
      setConfirm("");
    },
    onError: (error: Error) => {
      const wrong = error instanceof ApiError && error.code === "WRONG_PASSWORD";
      toast.error(t(wrong ? "adminMyPasswordWrong" : "errGenericAction"));
    },
  });

  const mismatch = confirm.length > 0 && confirm !== next;
  const valid =
    current.length > 0 && next.length >= 8 && confirm === next && !mismatch;

  return (
    <DashCard title={t("adminMyPassword")} icon="key-round">
      <p className="text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
        {t("adminMyPasswordDesc")}
      </p>
      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        <div className="space-y-1.5">
          <Label htmlFor="my-pw-current" className="text-[12px] font-bold">
            {t("adminMyPasswordCurrent")}
          </Label>
          <Input
            id="my-pw-current"
            type={show ? "text" : "password"}
            dir="ltr"
            value={current}
            onChange={(e) => setCurrent(e.target.value)}
            disabled={rotate.isPending}
            className={`${FIELD_INPUT} text-start`}
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="my-pw-next" className="text-[12px] font-bold">
            {t("adminMyPasswordNew")}
          </Label>
          <Input
            id="my-pw-next"
            type={show ? "text" : "password"}
            dir="ltr"
            value={next}
            onChange={(e) => setNext(e.target.value)}
            disabled={rotate.isPending}
            aria-invalid={next.length > 0 && next.length < 8}
            className={`${FIELD_INPUT} text-start`}
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="my-pw-confirm" className="text-[12px] font-bold">
            {t("adminMyPasswordConfirm2")}
          </Label>
          <Input
            id="my-pw-confirm"
            type={show ? "text" : "password"}
            dir="ltr"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            disabled={rotate.isPending}
            aria-invalid={mismatch}
            className={`${FIELD_INPUT} text-start`}
          />
        </div>
      </div>
      <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => setShow((v) => !v)}
          className="inline-flex items-center gap-1.5 text-[11px] font-bold text-slate-400 transition hover:text-brand-600 dark:hover:text-brand-300"
        >
          <CatIcon name={show ? "eye-off" : "eye"} className="h-3.5 w-3.5" />
          {t(show ? "wsPwHide" : "wsPwShow")}
        </button>
        <Button
          type="button"
          onClick={() => rotate.mutate()}
          disabled={!valid || rotate.isPending}
          className="h-10 gap-1.5 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 disabled:opacity-50"
          style={{ backgroundImage: grad("#6d5dfb", "#a855f7") }}
        >
          <CatIcon
            name={rotate.isPending ? "refresh-cw" : "key-round"}
            className={cn("h-4 w-4", rotate.isPending && "animate-spin")}
          />
          {t("adminMyPasswordSubmit")}
        </Button>
      </div>
      {mismatch ? (
        <p className="mt-2 text-[11px] font-bold text-rose-500" role="alert">
          {t("adminMyPasswordMismatch")}
        </p>
      ) : null}
    </DashCard>
  );
}

/* ------------------------------------------------------------------ */
/* ROUND 48 — dynamic payment methods manager (console)                */
/* ------------------------------------------------------------------ */

/** Per-kind visual identity — the same gradients the tenant billing view
 * and the activation-requests console use, so a method looks identical on
 * every surface (bank sky / wallet amber / paypal cyan / stripe violet). */
const METHOD_KIND_META: Record<
  PaymentMethod,
  { icon: string; c1: string; c2: string; labelKey: I18nKey; descKey: I18nKey }
> = {
  bank: { icon: "landmark", c1: "#0ea5e9", c2: "#0369a1", labelKey: "payKindBank", descKey: "payKindBankDesc" },
  wallet: { icon: "wallet", c1: "#f59e0b", c2: "#d97706", labelKey: "payKindWallet", descKey: "payKindWalletDesc" },
  paypal: { icon: "at-sign", c1: "#06b6d4", c2: "#0891b2", labelKey: "payKindPaypal", descKey: "payKindPaypalDesc" },
  stripe: { icon: "credit-card", c1: "#8b5cf6", c2: "#7c3aed", labelKey: "payKindStripe", descKey: "payKindStripeDesc" },
};

const METHOD_KINDS: readonly PaymentMethod[] = ["bank", "wallet", "paypal", "stripe"];

/** Hard cap mirroring the server's MAX_PAYMENT_METHODS (plan-orders.ts). */
const MAX_PAY_METHODS = 12;

/** Client-side id for a new method (event handlers only — the server
 * re-sanitizes the whole list on save anyway). */
function newMethodIdLocal(): string {
  return `pm_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
}

/** Dialog-level validation before a method joins the draft list:
 * label always required; a bank needs its name AND an account number or
 * IBAN; a wallet needs its number; a paypal/stripe link, when filled,
 * must be an absolute http(s) URL. */
function methodDraftValid(m: PaymentMethodOptionDTO): boolean {
  if (!m.label.trim()) return false;
  if (m.kind === "bank") {
    if (!m.bankName?.trim()) return false;
    if (!m.accountNumber?.trim() && !m.iban?.trim()) return false;
  }
  if (m.kind === "wallet" && !m.walletNumber?.trim()) return false;
  if ((m.kind === "paypal" || m.kind === "stripe") && m.link && m.link.trim()) {
    if (!/^https?:\/\//i.test(m.link.trim())) return false;
  }
  return true;
}

/** One labeled receiving-info field inside the method dialog. LTR islands
 * (IBAN, account numbers, emails, links) render dir="ltr" while staying
 * anchored to the dialog's start edge. */
function MethodField({
  id,
  label,
  value,
  onChange,
  placeholder,
  maxLength,
  ltr,
  mono,
  className,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  maxLength?: number;
  ltr?: boolean;
  mono?: boolean;
  className?: string;
}) {
  return (
    <div className={cn("min-w-0 space-y-1.5", className)}>
      <Label htmlFor={id} className="block text-[11px] font-extrabold text-slate-600 dark:text-slate-300">
        {label}
      </Label>
      <Input
        id={id}
        dir={ltr ? "ltr" : undefined}
        value={value}
        placeholder={placeholder}
        maxLength={maxLength}
        onChange={(e) => onChange(e.target.value)}
        className={cn(`${FIELD_INPUT} w-full text-start`, mono && "font-mono text-[12px] tracking-wide")}
      />
    </div>
  );
}

/** Muted receiving-info summary under a method row (bank name + IBAN /
 * wallet number / PayPal email / Stripe link). Falls back to the kind
 * description when no receiving detail exists yet. */
function MethodSummaryLine({ method }: { method: PaymentMethodOptionDTO }) {
  const { t } = useT();
  const meta = METHOD_KIND_META[method.kind];

  const parts: React.ReactNode[] = [];
  const addPart = (key: string, node: React.ReactNode) => {
    if (parts.length > 0) {
      parts.push(
        <span key={`sep-${key}`} aria-hidden="true" className="text-slate-300 dark:text-slate-600">
          ·
        </span>
      );
    }
    parts.push(<span key={key} className="min-w-0 truncate">{node}</span>);
  };

  if (method.kind === "bank") {
    if (method.bankName) addPart("bank", method.bankName);
    const account = method.iban || method.accountNumber;
    if (account) addPart("account", <span dir="ltr" className="font-mono tracking-wide">{account}</span>);
  } else if (method.kind === "wallet") {
    if (method.walletHolder) addPart("holder", method.walletHolder);
    if (method.walletNumber) {
      addPart("number", <span dir="ltr" className="font-mono tracking-wide">{method.walletNumber}</span>);
    }
  } else if (method.kind === "paypal") {
    if (method.email) addPart("email", <span dir="ltr" className="font-mono">{method.email}</span>);
    if (method.link) addPart("link", <span dir="ltr">{method.link}</span>);
  } else {
    if (method.link) addPart("link", <span dir="ltr">{method.link}</span>);
  }

  if (parts.length === 0) {
    return (
      <p className="mt-1 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
        {t(meta.descKey)}
      </p>
    );
  }
  return (
    <p className="mt-1 flex min-w-0 flex-wrap items-center gap-x-1.5 gap-y-0.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
      {parts}
    </p>
  );
}

/* ==================================================================== */
/* ROUND 141 — the dynamic add-on pricing manager (التسعير الديناميكي)     */
/* ==================================================================== */

/** The console's add-on price ladder editor: one row per catalog feature
 *  with its live monthly price (SAR major units) + a per-row default chip
 *  + the reset-to-defaults lever. NOTHING saves on its own — every edit
 *  rides the settings overlay and commits through the sticky Save button;
 *  the moment it lands, every tenant's add-on store + checkout + the
 *  server's own order pricing switch to the new table INSTANTLY. */
function AddonPricingManager({
  table,
  onChange,
  canManage,
}: {
  table: Record<string, number>;
  onChange: (monthly: Record<string, number>) => void;
  canManage: boolean;
}) {
  const { t, lang } = useT();

  const patch = (feature: PlanFeature, raw: string) => {
    const parsed = Math.round(Number(raw.replace(/[^0-9.]/g, "")));
    const price = Number.isFinite(parsed) ? Math.min(10_000, Math.max(1, parsed)) : 1;
    onChange({ ...table, [feature]: price });
  };

  const overridden = PLAN_FEATURES.filter((f) => table[f] !== DEFAULT_ADDON_PRICES[f]);

  return (
    <section aria-label={t("setPricingTitle")}>
      <div className="mb-3 flex flex-wrap items-center gap-2.5">
        <span
          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md"
          style={{ backgroundImage: grad("#8b5cf6", "#d946ef") }}
          aria-hidden="true"
        >
          <CatIcon name="puzzle" className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
            {t("setPricingTitle")}
          </p>
          <p className="mt-0.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("setPricingDesc")}
          </p>
        </div>
        {overridden.length > 0 && canManage ? (
          <Button
            type="button"
            variant="outline"
            onClick={() => onChange({ ...DEFAULT_ADDON_PRICES })}
            className="h-8 gap-1.5 rounded-lg px-3 text-[10.5px] font-bold text-slate-500"
          >
            <CatIcon name="rotate-ccw" className="h-3 w-3" />
            {t("setPricingReset")}
          </Button>
        ) : null}
      </div>

      <div className="grid gap-1.5 sm:grid-cols-2">
        {PLAN_FEATURES.map((feature) => {
          const meta = FEATURE_META[feature];
          const value = table[feature] ?? DEFAULT_ADDON_PRICES[feature];
          const isDefault = value === DEFAULT_ADDON_PRICES[feature];
          return (
            <label
              key={feature}
              className="flex items-center gap-2.5 rounded-xl border border-slate-200/80 bg-white/70 px-3 py-2 transition focus-within:border-brand-400 focus-within:ring-4 focus-within:ring-brand-500/10 dark:border-white/10 dark:bg-white/[0.03]"
            >
              <span
                className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white"
                style={{ backgroundImage: grad(meta?.icon ? "#8b5cf6" : "#64748b", "#d946ef") }}
                aria-hidden="true"
              >
                <CatIcon name={meta?.icon ?? "puzzle"} className="h-3.5 w-3.5" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[11.5px] font-extrabold text-slate-700 dark:text-slate-200">
                  {meta ? t(meta.labelKey) : feature}
                </span>
                <span className="mt-0.5 flex items-center gap-1.5">
                  <span dir="ltr" className="text-[9.5px] font-bold tabular-nums text-slate-400 dark:text-slate-500">
                    {t("setPricingDefault")}: {fmtNum(DEFAULT_ADDON_PRICES[feature], lang)}
                  </span>
                  {!isDefault ? (
                    <span className="inline-flex items-center gap-0.5 rounded-full bg-violet-500/15 px-1.5 py-px text-[8.5px] font-extrabold text-violet-600 dark:text-violet-300">
                      <CatIcon name="pen-line" className="h-2 w-2" />
                      {t("setPricingCustom")}
                    </span>
                  ) : null}
                </span>
              </span>
              <span className="flex shrink-0 items-center gap-1" dir="ltr">
                <input
                  type="number"
                  min={1}
                  max={10000}
                  step={1}
                  value={value}
                  disabled={!canManage}
                  onChange={(e) => patch(feature, e.target.value)}
                  aria-label={`${feature} price`}
                  className="h-9 w-[74px] rounded-lg border border-slate-200 bg-slate-50/80 px-2 text-end text-[12.5px] font-extrabold tabular-nums text-slate-800 transition focus:border-brand-400 focus:bg-white focus:ring-4 focus:ring-brand-500/15 disabled:opacity-60 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-100"
                />
                <span className="text-[10px] font-bold text-slate-400">SAR</span>
              </span>
            </label>
          );
        })}
      </div>

      <p className="mt-2.5 flex items-start gap-1.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
        <CatIcon name="zap" className="mt-0.5 h-3 w-3 shrink-0 text-violet-400" />
        {t("setPricingHint")}
      </p>
    </section>
  );
}

/* ==================================================================== */

/**
 * The console's dynamic payment-methods manager: any number of banks /
 * e-wallets / PayPal / Stripe methods live in the settings draft as
 * `payments.methods`. Add + edit share one dialog (kind selector +
 * kind-specific receiving fields); delete sits behind the existing
 * confirm-dialog pattern. NOTHING saves on its own — every edit rides the
 * section overlay (`updatePayment("methods", …)`) and commits through the
 * sticky Save button exactly like every other settings field.
 */
function PaymentMethodsManager({
  methods,
  onChange,
  canManage,
}: {
  methods: PaymentMethodOptionDTO[];
  onChange: (next: PaymentMethodOptionDTO[]) => void;
  canManage: boolean;
}) {
  const { t, lang } = useT();

  /* add/edit dialog — null = closed; the mode drives the shared form.
     draftMethod is only replaced on open, so closing never blanks the
     form mid-exit-animation. */
  const [dialog, setDialog] = useState<{ mode: "add" } | { mode: "edit"; index: number } | null>(null);
  const [draftMethod, setDraftMethod] = useState<PaymentMethodOptionDTO | null>(null);
  const [pendingDelete, setPendingDelete] = useState<PaymentMethodOptionDTO | null>(null);

  const editing = dialog?.mode === "edit" ? dialog : null;
  /* an existing method's kind is its identity (orders reference the id) —
     locked while editing */
  const kindLocked = editing !== null;
  const atMax = methods.length >= MAX_PAY_METHODS;

  const setDraft = <K extends keyof PaymentMethodOptionDTO>(key: K, value: PaymentMethodOptionDTO[K]) => {
    setDraftMethod((d) => (d ? { ...d, [key]: value } : d));
  };

  const openAdd = () => {
    setDraftMethod({ id: newMethodIdLocal(), kind: "bank", label: "", active: true });
    setDialog({ mode: "add" });
  };

  const openEdit = (index: number) => {
    const source = methods[index];
    if (!source) return;
    setDraftMethod({ ...source });
    setDialog({ mode: "edit", index });
  };

  const closeDialog = () => setDialog(null);

  const confirmDialog = () => {
    if (!draftMethod) return;
    if (!methodDraftValid(draftMethod)) {
      toast.error(t("errGenericAction"));
      return;
    }
    const next =
      editing !== null
        ? methods.map((row, i) => (i === editing.index ? draftMethod : row))
        : [...methods, draftMethod];
    onChange(next);
    setDialog(null);
  };

  const removeMethod = (target: PaymentMethodOptionDTO) => {
    onChange(methods.filter((row) => row.id !== target.id));
    setPendingDelete(null);
  };

  const countChip = t("payMethodsCount", { count: fmtNum(methods.length, lang) });

  return (
    <div>
      {/* header — title + hint + live count chip + add button */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="flex items-center gap-2 font-display text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
            <CatIcon name="credit-card" className="h-4 w-4 shrink-0 text-brand-500 dark:text-brand-300" />
            {t("payMethodsTitle")}
          </p>
          <p className="mt-0.5 max-w-lg text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("payMethodsHint")}
          </p>
        </div>
        {canManage ? (
          <div className="flex shrink-0 items-center gap-2">
            <span
              title={countChip}
              className={cn(
                "inline-flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-extrabold",
                atMax
                  ? "border-amber-300/70 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300"
                  : "border-slate-200 bg-slate-500/10 text-slate-500 dark:border-white/10 dark:text-slate-400"
              )}
            >
              <CatIcon name="credit-card" className="h-[10px] w-[10px]" />
              {countChip}
            </span>
            <Button
              type="button"
              onClick={openAdd}
              disabled={atMax}
              title={atMax ? countChip : undefined}
              className="h-9 gap-1.5 rounded-xl px-4 text-[11.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-50"
              style={{ backgroundImage: grad("#6d5dfb", "#d946ef") }}
            >
              <CatIcon name="plus" className="h-3.5 w-3.5" />
              {t("payAddMethod")}
            </Button>
          </div>
        ) : (
          <span
            className={cn(
              "inline-flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-extrabold",
              atMax
                ? "border-amber-300/70 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300"
                : "border-slate-200 bg-slate-500/10 text-slate-500 dark:border-white/10 dark:text-slate-400"
            )}
          >
            <CatIcon name="credit-card" className="h-[10px] w-[10px]" />
            {countChip}
          </span>
        )}
      </div>

      {/* methods list / empty state */}
      {methods.length === 0 ? (
        <div className="mt-3.5 rounded-2xl border border-dashed border-slate-300/80 bg-white/50 px-4 py-8 text-center dark:border-white/15 dark:bg-white/[0.02]">
          <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-brand-500/10 text-brand-500 dark:text-brand-300">
            <CatIcon name="credit-card" className="h-5 w-5" />
          </div>
          <p className="mx-auto mt-2.5 max-w-sm text-[12px] font-bold leading-relaxed text-slate-500 dark:text-slate-400">
            {t("payMethodsEmptyConsole")}
          </p>
          {canManage ? (
            <Button
              type="button"
              onClick={openAdd}
              className="mt-4 h-9 gap-1.5 rounded-xl px-4 text-[11.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
              style={{ backgroundImage: grad("#6d5dfb", "#d946ef") }}
            >
              <CatIcon name="plus" className="h-3.5 w-3.5" />
              {t("payAddMethod")}
            </Button>
          ) : null}
        </div>
      ) : (
        <ul className="mt-3.5 space-y-2.5">
          {methods.map((m, i) => {
            const meta = METHOD_KIND_META[m.kind];
            return (
              <li
                key={m.id}
                className="rounded-2xl border border-slate-200/80 bg-white/70 p-3.5 transition hover:border-brand-200 dark:border-white/10 dark:bg-white/[0.04] dark:hover:border-brand-500/25"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="flex min-w-0 flex-1 items-start gap-3">
                    <span
                      className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-md"
                      style={{ backgroundImage: grad(meta.c1, meta.c2) }}
                      aria-hidden="true"
                    >
                      <CatIcon name={meta.icon} className="h-[14px] w-[14px]" />
                    </span>
                    <div className="min-w-0">
                      <p className="flex flex-wrap items-center gap-x-2 gap-y-1">
                        <span className="truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
                          {m.label}
                        </span>
                        <span
                          className="inline-flex shrink-0 items-center gap-1 rounded-full px-2 py-px text-[11px] font-extrabold"
                          style={{ color: meta.c2, backgroundColor: `${meta.c1}1f` }}
                        >
                          <CatIcon name={meta.icon} className="h-2.5 w-2.5" />
                          {t(meta.labelKey)}
                        </span>
                      </p>
                      <MethodSummaryLine method={m} />
                    </div>
                  </div>
                  <div className="flex shrink-0 items-center gap-2.5">
                    <div className="flex flex-col items-center gap-1">
                      <span
                        className={cn(
                          "text-[11px] font-extrabold",
                          m.active
                            ? "text-emerald-600 dark:text-emerald-300"
                            : "text-slate-400 dark:text-slate-500"
                        )}
                      >
                        {m.active ? t("payMethodActive") : t("payMethodInactive")}
                      </span>
                      <Switch
                        checked={m.active}
                        onCheckedChange={(v) =>
                          onChange(methods.map((row) => (row.id === m.id ? { ...row, active: v } : row)))
                        }
                        disabled={!canManage}
                        aria-label={`${m.label} — ${t(m.active ? "payMethodActive" : "payMethodInactive")}`}
                      />
                    </div>
                    {canManage ? (
                      <span className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => openEdit(i)}
                          aria-label={`${t("payEditMethod")} — ${m.label}`}
                          title={t("payEditMethod")}
                          className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
                        >
                          <CatIcon name="pencil" className="h-[13px] w-[13px]" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setPendingDelete(m)}
                          aria-label={`${t("payMethodDelete")} — ${m.label}`}
                          title={t("payMethodDelete")}
                          className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-rose-300 hover:text-rose-600 active:scale-95 dark:border-white/10 dark:text-slate-300 dark:hover:border-rose-400/50 dark:hover:text-rose-300"
                        >
                          <CatIcon name="trash-2" className="h-[13px] w-[13px]" />
                        </button>
                      </span>
                    ) : null}
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}

      {/* add / edit dialog (shared) */}
      <Dialog open={dialog !== null} onOpenChange={(o) => !o && closeDialog()}>
        <DialogContent
          dir={lang === "ar" ? "rtl" : "ltr"}
          className="max-h-[85vh] gap-0 overflow-y-auto rounded-3xl p-0 sm:max-w-lg"
        >
          <DialogHeader className="border-b border-slate-200/70 px-5 py-4 dark:border-white/10">
            <DialogTitle className="flex items-center gap-2.5 font-display text-[16px] font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-8 w-8 shrink-0 place-items-center rounded-xl text-white shadow-md"
                style={{ backgroundImage: grad("#6d5dfb", "#d946ef") }}
                aria-hidden="true"
              >
                <CatIcon name={editing !== null ? "pencil" : "plus"} className="h-[13px] w-[13px]" />
              </span>
              {editing !== null ? t("payEditMethod") : t("payAddMethod")}
            </DialogTitle>
            <DialogDescription className="text-[12px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("payMethodsHint")}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 px-5 py-4">
            {/* kind selector — locked while editing an existing method */}
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {METHOD_KINDS.map((kind) => {
                const meta = METHOD_KIND_META[kind];
                const selected = draftMethod?.kind === kind;
                return (
                  <button
                    type="button"
                    key={kind}
                    onClick={() => setDraft("kind", kind)}
                    disabled={kindLocked}
                    aria-pressed={selected}
                    className={cn(
                      "flex flex-col items-center gap-1.5 rounded-2xl border p-3 text-center transition-all duration-200 active:scale-95",
                      selected
                        ? "border-brand-500 bg-brand-50/60 ring-2 ring-brand-500/60 dark:border-brand-500/60 dark:bg-brand-500/[0.08]"
                        : "border-slate-200/80 bg-white/60 hover:border-brand-300/70 hover:bg-brand-50/40 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-brand-500/30 dark:hover:bg-brand-500/[0.05]",
                      kindLocked && "cursor-not-allowed opacity-60"
                    )}
                  >
                    <span
                      className="grid h-9 w-9 place-items-center rounded-xl text-white shadow-md"
                      style={{ backgroundImage: grad(meta.c1, meta.c2) }}
                      aria-hidden="true"
                    >
                      <CatIcon name={meta.icon} className="h-[13px] w-[13px]" />
                    </span>
                    <span className="text-[11px] font-extrabold leading-tight text-slate-800 dark:text-slate-100">
                      {t(meta.labelKey)}
                    </span>
                    <span className="text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                      {t(meta.descKey)}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* common: label + active */}
            <div className="space-y-1.5">
              <Label htmlFor="pay-method-label" className="block text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                {t("payMethodLabel")} <span className="text-rose-500">*</span>
              </Label>
              <Input
                id="pay-method-label"
                value={draftMethod?.label ?? ""}
                placeholder={t("payMethodLabelPh")}
                maxLength={120}
                onChange={(e) => setDraft("label", e.target.value)}
                className={`${FIELD_INPUT} w-full text-start`}
              />
            </div>

            <div className="flex items-center justify-between gap-3 rounded-xl border border-slate-200/80 bg-white/60 px-3.5 py-2.5 dark:border-white/10 dark:bg-white/[0.03]">
              <div className="min-w-0">
                <p className="text-[12px] font-extrabold text-slate-800 dark:text-slate-100">
                  {draftMethod?.active ? t("payMethodActive") : t("payMethodInactive")}
                </p>
                <p className="mt-0.5 text-[10px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
                  {t("payMethodActiveHint")}
                </p>
              </div>
              <Switch
                checked={draftMethod?.active ?? true}
                onCheckedChange={(v) => setDraft("active", v)}
                aria-label={t("payMethodActiveHint")}
              />
            </div>

            {/* kind-specific receiving fields */}
            {draftMethod?.kind === "bank" ? (
              <div className="grid gap-3 sm:grid-cols-2">
                <MethodField
                  id="pay-m-bank-name"
                  label={t("payBankName")}
                  value={draftMethod.bankName ?? ""}
                  onChange={(v) => setDraft("bankName", v)}
                  maxLength={120}
                  className="sm:col-span-2"
                />
                <MethodField
                  id="pay-m-account-holder"
                  label={t("payAccountHolder")}
                  value={draftMethod.accountHolder ?? ""}
                  onChange={(v) => setDraft("accountHolder", v)}
                  maxLength={120}
                />
                <MethodField
                  id="pay-m-swift"
                  label={t("paySwiftCode")}
                  value={draftMethod.swift ?? ""}
                  onChange={(v) => setDraft("swift", v)}
                  maxLength={24}
                  ltr
                  mono
                />
                <MethodField
                  id="pay-m-account-number"
                  label={t("payAccountNumber")}
                  value={draftMethod.accountNumber ?? ""}
                  onChange={(v) => setDraft("accountNumber", v)}
                  maxLength={64}
                  ltr
                  mono
                />
                <MethodField
                  id="pay-m-iban"
                  label={t("payIbanNumber")}
                  value={draftMethod.iban ?? ""}
                  onChange={(v) => setDraft("iban", v)}
                  maxLength={64}
                  ltr
                  mono
                />
              </div>
            ) : null}

            {draftMethod?.kind === "wallet" ? (
              <div className="grid gap-3 sm:grid-cols-2">
                <MethodField
                  id="pay-m-wallet-holder"
                  label={t("payWalletHolder")}
                  value={draftMethod.walletHolder ?? ""}
                  onChange={(v) => setDraft("walletHolder", v)}
                  maxLength={120}
                />
                <MethodField
                  id="pay-m-wallet-network"
                  label={t("payWalletNetwork")}
                  value={draftMethod.walletNetwork ?? ""}
                  onChange={(v) => setDraft("walletNetwork", v)}
                  maxLength={60}
                />
                <MethodField
                  id="pay-m-wallet-number"
                  label={t("payWalletNumber")}
                  value={draftMethod.walletNumber ?? ""}
                  onChange={(v) => setDraft("walletNumber", v)}
                  maxLength={64}
                  ltr
                  mono
                  className="sm:col-span-2"
                />
              </div>
            ) : null}

            {draftMethod?.kind === "paypal" ? (
              <div className="grid gap-3 sm:grid-cols-2">
                <MethodField
                  id="pay-m-paypal-email"
                  label={t("payPaypalEmail")}
                  value={draftMethod.email ?? ""}
                  onChange={(v) => setDraft("email", v)}
                  maxLength={190}
                  ltr
                  mono
                  className="sm:col-span-2"
                />
                <MethodField
                  id="pay-m-paypal-link"
                  label={t("payLink")}
                  value={draftMethod.link ?? ""}
                  onChange={(v) => setDraft("link", v)}
                  placeholder={t("payLinkPh")}
                  maxLength={300}
                  ltr
                  className="sm:col-span-2"
                />
              </div>
            ) : null}

            {draftMethod?.kind === "stripe" ? (
              <div className="grid gap-3 sm:grid-cols-2">
                <MethodField
                  id="pay-m-stripe-link"
                  label={t("payLink")}
                  value={draftMethod.link ?? ""}
                  onChange={(v) => setDraft("link", v)}
                  placeholder={t("payLinkPh")}
                  maxLength={300}
                  ltr
                  className="sm:col-span-2"
                />
              </div>
            ) : null}
          </div>

          <div className="flex items-center justify-end gap-2 border-t border-dashed border-slate-200 px-5 py-4 dark:border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={closeDialog}
              className="h-10 rounded-xl px-5 text-[12.5px] font-bold"
            >
              {t("dlgCancel")}
            </Button>
            <Button
              type="button"
              onClick={confirmDialog}
              disabled={!draftMethod || draftMethod.label.trim().length === 0}
              className="h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-50"
              style={{ backgroundImage: grad("#6d5dfb", "#d946ef") }}
            >
              <CatIcon name="check" className="h-4 w-4" />
              {t("setSave")}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* delete confirm — existing dialog pattern */}
      <AlertDialog open={pendingDelete !== null} onOpenChange={(o) => !o && setPendingDelete(null)}>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-linear-to-br from-rose-500 to-rose-600 text-white shadow-md shadow-rose-500/25"
                aria-hidden="true"
              >
                <CatIcon name="trash-2" className="h-4 w-4" />
              </span>
              {t("payMethodDelete")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {pendingDelete ? `${pendingDelete.label} — ` : ""}
              {t("payMethodDeleteDesc")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold">
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => pendingDelete && removeMethod(pendingDelete)}
              className="h-10 gap-2 rounded-xl bg-rose-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95"
            >
              <CatIcon name="trash-2" className="h-4 w-4" />
              {t("payMethodDelete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export function AdminSettings() {
  const { t, lang } = useT();
  /* round 29 — below-admin roles read the settings, only super/admin save
     (the server PATCH is super/admin-guarded anyway) */
  const canManage = useAdminCanManage();
  /* ROUND 41 — the AI/API control panel (and its nav entry) is SUPER-ONLY:
     non-super roles never see it, mirroring the /api/admin/ai guards. */
  const { user } = useAdminAuth();
  const isSuper = user?.role === "super";
  /* EMAIL SYSTEM — the mail console surfaces (settings/health/test/logs)
     are operator-class: super + admin only. Moderators/viewers neither
     see the nav entry nor render the section — the routes 403 them
     independently (the verified least-privilege posture). */
  const isMailOperator = user?.role === "super" || user?.role === "admin";
  const queryClient = useQueryClient();

  const [activeSection, setActiveSection] = useState<SectionId>("general");
  const [edits, setEdits] = useState<SettingsEdits>({});
  const [confirmReset, setConfirmReset] = useState(false);

  const query = useQuery({
    queryKey: ["platform-settings"],
    queryFn: fetchPlatformSettings,
    staleTime: 60_000,
  });

  const server = query.data ?? null;

  /* effective draft = server row overlaid with local edits; payments is
     nested, so its partial overlay merges OVER the server object — the
     draft (and any PATCH built from it) always holds the complete set of
     payment fields, never a partial */
  const draft = useMemo<SettingsDraft | null>(() => {
    if (!server) return null;
    const base = toDraft(server);
    return { ...base, ...edits, payments: { ...base.payments, ...(edits.payments ?? {}) } };
  }, [server, edits]);

  const ready = draft !== null;

  /* scroll-spy: highlight the section currently crossing the viewport band
     (the AI section only exists in the DOM for the super role) */
  const visibleSections = useMemo(
    () => SECTIONS.filter((s) => (s.id !== "ai" || isSuper) && (s.id !== "email" || isMailOperator)),
    [isSuper, isMailOperator]
  );
  useEffect(() => {
    if (!ready) return;
    const observer = new IntersectionObserver(
      (entries) => {
        let top: number | null = null;
        let id: SectionId | null = null;
        for (const entry of entries) {
          if (!entry.isIntersecting) continue;
          if (top === null || entry.boundingClientRect.top < top) {
            top = entry.boundingClientRect.top;
            id = entry.target.getAttribute("data-section") as SectionId | null;
          }
        }
        if (id) setActiveSection(id);
      },
      { rootMargin: "-96px 0px -55% 0px" }
    );
    for (const section of visibleSections) {
      const el = document.getElementById(`settings-section-${section.id}`);
      if (el) observer.observe(el);
    }
    return () => observer.disconnect();
  }, [ready, visibleSections]);

  const dirty = useMemo(() => {
    if (!server || !draft) return null;
    return diffSettings(toDraft(server), draft);
  }, [server, draft]);

  const isDirty = dirty !== null && Object.keys(dirty).length > 0;

  /* ROUND 48 — captured at submit time (before the PATCH fires) whether the
     dynamic METHODS list itself was in the diff; a note-only payments edit
     keeps the generic toast. Read back in the mutation's onSuccess via the
     ref so the closure always sees the submit-time value. */
  const methodsInDiffRef = useRef(false);
  /* ROUND 137 — double-submit guard for the security-policy leg of the
     save (it runs outside the react-query mutation, so no isPending) */
  const policyInFlightRef = useRef(false);

  /* ROUND 87 — same ceremony for the identity: "saved" when the identity
     object was in the diff, "removed" when a logo/favicon element was
     cleared back to its default (its own toast), null when untouched. */
  const identityToastRef = useRef<null | "saved" | "removed">(null);

  const save = useMutation({
    mutationFn: (payload: PlatformSettingsPayload) => updatePlatformSettings(payload),
    onSuccess: (data) => {
      queryClient.setQueryData(["platform-settings"], data);
      queryClient.invalidateQueries({ queryKey: ["platform-settings"] });
      /* ROUND 87 — the PUBLIC identity feed follows the save immediately:
      the bridge + every usePlatformIdentity consumer share this key. */
      queryClient.invalidateQueries({ queryKey: IDENTITY_QUERY_KEY });
      const toastKey: I18nKey =
        identityToastRef.current === "removed"
          ? "idRemoveToast"
          : identityToastRef.current === "saved"
            ? "idSavedToast"
            : methodsInDiffRef.current
              ? "payMethodSaved"
              : "setSaved";
      toast.success(t(toastKey));
    },
    onError: (error: Error) =>
      toast.error(error.message ? `${t("setSaveErr")} — ${error.message}` : t("setSaveErr")),
  });

  /* ROUND 137 — the 2FA policy rides its OWN dedicated route (super-only,
     strict-audit /api/admin/security-policy); the general settings PATCH
     no longer accepts the field. POLICY-FIRST ordering: a refused policy
     change aborts the whole save (the operator sees the toggle's error —
     nothing half-saves), a policy-only save needs no settings call at
     all. Behavior-only change — the UI surface is untouched. */
  const submit = () => {
    if (!server || !draft || !dirty || Object.keys(dirty).length === 0 || save.isPending || policyInFlightRef.current) return;
    methodsInDiffRef.current =
      dirty.payments !== undefined &&
      JSON.stringify(toDraft(server).payments.methods) !== JSON.stringify(draft.payments.methods);
    /* ROUND 87 — identity toast selection: a removed element (logo/mini/
       favicon cleared) gets its own message; any other identity edit the
       saved one. */
    identityToastRef.current = null;
    if (dirty.identity !== undefined) {
      const before = toDraft(server).identity ?? null;
      const after = dirty.identity ?? null;
      const elementKeys: Array<keyof PlatformIdentityDTO> = ["logoUrl", "logoMiniUrl", "faviconUrl"];
      identityToastRef.current = elementKeys.some((k) => {
        const prev = before ? before[k] : undefined;
        const next = after ? after[k] : undefined;
        return typeof prev === "string" && prev.length > 0 && !(typeof next === "string" && next.length > 0);
      })
        ? "removed"
        : "saved";
    }
    const { twoFARequired, ...settingsDiff } = dirty;
    if (twoFARequired === undefined) {
      save.mutate(settingsDiff);
      return;
    }
    /* the policy leg runs outside the react-query mutation — a small ref
       guard stands in for its isPending double-submit protection */
    policyInFlightRef.current = true;
    void (async () => {
      try {
        const policy = await updateSecurityPolicy({ twoFARequired });
        /* the cache write clears the toggle's dirtiness through the same
           dirty-memo the settings save relies on */
        queryClient.setQueryData<PlatformSettingsDTO>(["platform-settings"], (prev) =>
          prev ? { ...prev, twoFARequired: policy.twoFARequired } : prev
        );
        if (Object.keys(settingsDiff).length === 0) {
          toast.success(t("setSaved"));
          return;
        }
        save.mutate(settingsDiff);
      } catch (error) {
        toast.error(
          error instanceof Error && error.message
            ? `${t("setSaveErr")} — ${error.message}`
            : t("setSaveErr")
        );
      } finally {
        policyInFlightRef.current = false;
      }
    })();
  };

  /* restore = discard local edits, never a server reset */
  const discard = () => {
    setConfirmReset(false);
    setEdits({});
    query.refetch();
    toast.success(t("setResetDone"));
  };

  const update = <K extends keyof SettingsDraft>(key: K, value: SettingsDraft[K]) => {
    setEdits((e) => ({ ...e, [key]: value }));
  };

  /* ROUND 47 — nested payments edit: only the touched field rides in the
     overlay; the draft memo above fills in the rest from the server row */
  const updatePayment = <K extends keyof PaymentsSettingsDTO>(key: K, value: PaymentsSettingsDTO[K]) => {
    setEdits((e) => ({ ...e, payments: { ...(e.payments ?? {}), [key]: value } }));
  };

  const jumpTo = (id: SectionId) => {
    setActiveSection(id);
    document.getElementById(`settings-section-${id}`)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  if (query.isError) {
    return (
      <div className="space-y-5">
        <ViewHeading title={t("setTitle")} desc={t("setDesc")} />
        <DashCard>
          <div className="py-14 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-rose-100 text-rose-500 dark:bg-rose-500/10 dark:text-rose-300">
              <CatIcon name="circle-alert" className="h-6 w-6" />
            </div>
            <p className="mt-3 font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("errorText")}
            </p>
            {query.error instanceof Error ? (
              <p className="mx-auto mt-1 max-w-sm text-[12px] font-semibold text-slate-400 dark:text-slate-500">
                {query.error.message}
              </p>
            ) : null}
            <Button
              type="button"
              variant="outline"
              onClick={() => query.refetch()}
              className="mt-5 h-11 gap-2 rounded-xl px-5 text-[12.5px] font-bold"
            >
              <CatIcon name="refresh-cw" className="h-4 w-4" />
              {t("retryText")}
            </Button>
          </div>
        </DashCard>
      </div>
    );
  }

  if (query.isPending || !draft) {
    return (
      <div className="space-y-5">
        <ViewHeading title={t("setTitle")} desc={t("setDesc")} />
        <Skeleton className="h-11 w-64 rounded-xl" />
        <div className="grid gap-5 lg:grid-cols-3">
          <Skeleton className="h-40 rounded-3xl lg:col-span-1" />
          <div className="space-y-4 lg:col-span-2">
            {[0, 1, 2].map((i) => (
              <Skeleton key={i} className="h-56 rounded-3xl" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <ViewHeading title={t("setTitle")} desc={t("setDesc")} />

      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
        className="space-y-5"
      >
        {/* actions — always in the header, never sticky */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          {query.data ? (
            <Badge
              variant="secondary"
              className="gap-1.5 rounded-full bg-slate-500/10 px-3 py-1 text-[11px] font-bold text-slate-500 dark:text-slate-400"
            >
              <CatIcon name="clock" className="h-3 w-3" />
              <span>
                {t("setLastSaved")}: {relativeTime(query.data.updatedAt, lang)}
              </span>
            </Badge>
          ) : (
            <span />
          )}
          <div className="ms-auto flex items-center gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setConfirmReset(true)}
              disabled={save.isPending || !canManage}
              title={!canManage ? t("adminNoPerm") : undefined}
              className="h-11 gap-2 rounded-xl border-slate-200 px-4 text-[12.5px] font-bold text-slate-600 transition hover:border-rose-300 hover:text-rose-600 active:scale-95 disabled:opacity-50 dark:border-white/10 dark:text-slate-300 dark:hover:border-rose-400/50 dark:hover:text-rose-300"
            >
              <CatIcon name="clock-rotate-left" className="h-4 w-4" />
              {t("setReset")}
            </Button>
            <Button
              type="submit"
              disabled={!isDirty || save.isPending || !canManage}
              title={!canManage ? t("adminNoPerm") : undefined}
              className="h-11 gap-2 rounded-xl bg-linear-to-l from-brand-600 via-fuchsia-500 to-cyan-400 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/30 transition hover:brightness-110 active:scale-95 disabled:opacity-50"
            >
              {save.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="save" className="h-4 w-4" />
              )}
              {t("setSave")}
            </Button>
          </div>
        </div>

        <div className="grid gap-5 lg:grid-cols-3">
          {/* section navigator */}
          <nav aria-label={t("setTitle")} className="lg:col-span-1">
            <DashCard className="lg:sticky lg:top-24">
              <ul className="flex gap-1.5 overflow-x-auto pb-0.5 lg:flex-col lg:gap-1.5 lg:overflow-visible lg:pb-0">
                {/* ROUND 41 — the AI/API nav entry is super-only (same gate
                    as the section itself; the route enforces it anyway) */}
                {visibleSections.map((section) => {
                  const active = activeSection === section.id;
                  return (
                    <li key={section.id} className="shrink-0 lg:w-full lg:shrink">
                      <button
                        type="button"
                        onClick={() => jumpTo(section.id)}
                        aria-current={active ? "true" : undefined}
                        className={cn(
                          "flex min-h-11 w-full items-center gap-2.5 rounded-xl border px-3.5 text-[12px] font-extrabold transition active:scale-95",
                          active
                            ? "border-brand-300/70 bg-brand-500/10 text-brand-600 shadow-sm shadow-brand-500/10 dark:border-brand-500/40 dark:bg-brand-500/10 dark:text-brand-300"
                            : "border-transparent text-slate-500 hover:border-slate-200 hover:bg-slate-50 dark:text-slate-400 dark:hover:border-white/10 dark:hover:bg-white/5"
                        )}
                      >
                        <CatIcon
                          name={section.icon}
                          className={cn(
                            "h-4 w-4",
                            active
                              ? "text-brand-500 dark:text-brand-300"
                              : "text-slate-400 dark:text-slate-500"
                          )}
                        />
                        <span className="whitespace-nowrap">{t(section.titleKey)}</span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </DashCard>
          </nav>

          {/* sections */}
          <div className="space-y-5 lg:col-span-2">
            {/* general */}
            {/* ROUND 45 — personal account security (2FA · passkeys · sessions) */}
            <div id="settings-section-account" data-section="account" className="scroll-mt-24">
              <div className="mb-1 space-y-1">
                <p className="text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
                  {t("setAccountDesc")}
                </p>
              </div>
              <div className="space-y-5">
                <TwoFactorCard scope={{ kind: "admin" }} />
                <PasskeysCard scope={{ kind: "admin" }} />
                <SessionsCard scope={{ kind: "admin" }} />
                {/* ROUND 46 (F-4) — self-service password rotation */}
                <AdminMyPasswordCard />
              </div>
            </div>

            {/* ROUND 87 — the platform brand identity (الهوية): logos /
                colors / fonts / elements / appearance. Every edit rides the
                shared dirty diff + sticky Save (the payments law). */}
            <div id="settings-section-identity" data-section="identity" className="scroll-mt-24">
              <IdentitySection
                value={draft.identity ?? null}
                siteName={draft.siteNameAr}
                siteNameEn={draft.siteNameEn}
                canManage={canManage}
                onChange={(next) => update("identity", next)}
              />
            </div>

            <div id="settings-section-general" data-section="general" className="scroll-mt-24">
              <DashCard title={t("setSectionGeneral")} icon="sliders">
                <div className="divide-y divide-slate-100 dark:divide-white/[0.06]">
                  <SettingRow icon="wand-sparkles" c1="#8b5cf6" c2="#7c3aed" label={t("setSiteNameAr")} htmlFor="set-site-name-ar">
                    <Input
                      id="set-site-name-ar"
                      value={draft.siteNameAr}
                      onChange={(e) => update("siteNameAr", e.target.value)}
                      maxLength={60}
                      className={`${FIELD_INPUT} w-full sm:w-56`}
                    />
                  </SettingRow>
                  <SettingRow icon="globe" c1="#06b6d4" c2="#0891b2" label={t("setSiteNameEn")} htmlFor="set-site-name-en">
                    <Input
                      id="set-site-name-en"
                      dir="ltr"
                      value={draft.siteNameEn}
                      onChange={(e) => update("siteNameEn", e.target.value)}
                      maxLength={60}
                      className={`${FIELD_INPUT} w-full text-start sm:w-56`}
                    />
                  </SettingRow>
                  <SettingRow icon="mail" c1="#10b981" c2="#059669" label={t("setSupportEmail")} htmlFor="set-support-email">
                    <Input
                      id="set-support-email"
                      type="email"
                      dir="ltr"
                      value={draft.supportEmail}
                      onChange={(e) => update("supportEmail", e.target.value)}
                      className={`${FIELD_INPUT} w-full text-start sm:w-56`}
                    />
                  </SettingRow>
                  <SettingRow icon="phone" c1="#f59e0b" c2="#d97706" label={t("setSupportPhone")} htmlFor="set-support-phone">
                    <Input
                      id="set-support-phone"
                      type="tel"
                      dir="ltr"
                      value={draft.supportPhone}
                      onChange={(e) => update("supportPhone", e.target.value)}
                      className={`${FIELD_INPUT} w-full text-start sm:w-56`}
                    />
                  </SettingRow>
                  <SettingRow icon="globe" c1="#6d5dfb" c2="#4b35c9" label={t("setDefaultLang")} htmlFor="set-default-lang">
                    <Select
                      value={draft.defaultLang}
                      onValueChange={(v) => update("defaultLang", v as SettingsDraft["defaultLang"])}
                      dir={lang === "ar" ? "rtl" : "ltr"}
                    >
                      <SelectTrigger id="set-default-lang" className={`${FIELD_INPUT} w-full justify-between sm:w-44`}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="rounded-xl">
                        <SelectGroup>
                          {/* ROUND 55 — the platform default language now lists
                              ALL 11 registry locales (server enum widened too) */}
                          {LOCALES.map((loc) => (
                            <SelectItem key={loc.code} value={loc.code} className="text-[12.5px] font-bold">
                              {loc.native}
                            </SelectItem>
                          ))}
                        </SelectGroup>
                      </SelectContent>
                    </Select>
                  </SettingRow>
                  {/* ROUND 55 — dynamic default currency for packages
                      (USD / SAR / AED …): no code edits, applies to every NEW
                      package the console creates; existing rows are untouched */}
                  <SettingRow
                    icon="banknote"
                    c1="#10b981"
                    c2="#047857"
                    label={t("setPkgCurrency")}
                    desc={t("setPkgCurrencyHint")}
                    htmlFor="set-pkg-currency"
                  >
                    <Select
                      value={draft.packageCurrency}
                      onValueChange={(v) => update("packageCurrency", v as SettingsDraft["packageCurrency"])}
                      dir={lang === "ar" ? "rtl" : "ltr"}
                    >
                      <SelectTrigger id="set-pkg-currency" className={`${FIELD_INPUT} w-full justify-between sm:w-56`}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="rounded-xl">
                        <SelectGroup>
                          {PKG_CURRENCY_OPTIONS.map((cur) => (
                            <SelectItem key={cur.code} value={cur.code} className="text-[12.5px] font-bold">
                              <span className="flex items-center gap-2">
                                <span
                                  dir="ltr"
                                  className="grid h-6 w-9 shrink-0 place-items-center rounded-md border border-slate-200 bg-slate-50 text-[10.5px] font-extrabold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300"
                                >
                                  {cur.code}
                                </span>
                                <span className="min-w-0 truncate">
                                  {lang === "ar" ? cur.nameAr : cur.nameEn}
                                  <span className="ms-1.5 text-slate-400 dark:text-slate-500" dir="ltr">
                                    {cur.symbol}
                                  </span>
                                </span>
                              </span>
                            </SelectItem>
                          ))}
                        </SelectGroup>
                      </SelectContent>
                    </Select>
                  </SettingRow>
                </div>
              </DashCard>
            </div>

            {/* ROUND 48 — payments: the console-managed DYNAMIC list of
                payment methods (banks / e-wallets / PayPal / Stripe) shown
                to tenants on activation invoices — no code edits, ever */}
            <div id="settings-section-payments" data-section="payments" className="scroll-mt-24">
              <DashCard title={t("setSectionPayments")} icon="credit-card">
                <p className="mb-3 text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                  {t("paySettingsDesc")}
                </p>
                <PaymentMethodsManager
                  methods={draft.payments.methods}
                  onChange={(next) => updatePayment("methods", next)}
                  canManage={canManage}
                />
                <div className="mt-4 border-t border-dashed border-slate-200 pt-1 dark:border-white/10">
                  <SettingRow icon="notebook-pen" c1="#64748b" c2="#475569" label={t("payNote")} htmlFor="set-pay-note">
                    <Textarea
                      id="set-pay-note"
                      rows={2}
                      value={draft.payments.note}
                      onChange={(e) => updatePayment("note", e.target.value)}
                      maxLength={280}
                      disabled={!canManage}
                      aria-label={t("payNote")}
                      className="w-full rounded-xl border-slate-200 bg-slate-50/80 px-3.5 py-2.5 text-[12.5px] font-semibold leading-relaxed text-slate-800 transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 disabled:opacity-60 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 sm:w-72"
                    />
                  </SettingRow>
                </div>

                {/* ROUND 141 — the dynamic add-on pricing table (التسعير
                    الديناميكي): every price here is LIVE on the tenants'
                    add-on store the moment the save lands — zero code. */}
                <div className="mt-5 border-t border-dashed border-slate-200 pt-4 dark:border-white/10">
                  <AddonPricingManager
                    table={draft.addonsPricing.monthly}
                    onChange={(monthly) => update("addonsPricing", { monthly })}
                    canManage={canManage}
                  />
                </div>
              </DashCard>
            </div>

            {/* social links */}
            <div id="settings-section-social" data-section="social" className="scroll-mt-24">
              <DashCard title={t("setSectionSocial")} icon="share-2">
                <p className="mb-2 text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                  {t("setSocialDesc")}
                </p>
                <div className="divide-y divide-slate-100 dark:divide-white/[0.06]">
                  {draft.socialLinks.map((row) => (
                    <SocialLinkRow
                      key={row.icon}
                      row={row}
                      onChange={(next) => {
                        const socialLinks = draft.socialLinks.map((r) => (r.icon === next.icon ? next : r));
                        update("socialLinks", socialLinks);
                      }}
                    />
                  ))}
                </div>
                <div className="mt-3 flex justify-end border-t border-dashed border-slate-200 pt-3 dark:border-white/10">
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      update("socialLinks", DEFAULT_SOCIAL_SETTINGS.map((s) => ({ ...s })));
                      toast.success(t("setSocialResetDone"));
                    }}
                    className="h-8 gap-1.5 rounded-lg px-3 text-[11px] font-bold text-slate-500 transition hover:text-brand-600 dark:text-slate-400 dark:hover:text-brand-300"
                  >
                    <CatIcon name="clock-rotate-left" className="h-3.5 w-3.5" />
                    {t("setSocialReset")}
                  </Button>
                </div>
              </DashCard>
            </div>

            {/* security */}
            <div id="settings-section-security" data-section="security" className="scroll-mt-24">
              <DashCard title={t("setSectionSecurity")} icon="shield-check">
                <div className="divide-y divide-slate-100 dark:divide-white/[0.06]">
                  <SettingRow
                    icon="triangle-alert"
                    warning
                    label={t("setMaintenance")}
                    desc={t("setMaintenanceDesc")}
                    htmlFor="set-maintenance"
                  >
                    <SettingSwitch
                      id="set-maintenance"
                      label={t("setMaintenance")}
                      warn={draft.maintenanceMode}
                      checked={draft.maintenanceMode}
                      onCheckedChange={(v) => update("maintenanceMode", v)}
                    />
                  </SettingRow>
                  <SettingRow
                    icon="user-plus"
                    c1="#06b6d4"
                    c2="#0e7490"
                    label={t("setAllowSignup")}
                    desc={t("setAllowSignupDesc")}
                    htmlFor="set-signup"
                  >
                    <SettingSwitch
                      id="set-signup"
                      label={t("setAllowSignup")}
                      checked={draft.allowSignup}
                      onCheckedChange={(v) => update("allowSignup", v)}
                    />
                  </SettingRow>
                  <SettingRow
                    icon="key-round"
                    c1="#10b981"
                    c2="#059669"
                    label={t("setTwoFA")}
                    desc={t("setTwoFADesc")}
                    htmlFor="set-twofa"
                  >
                    <SettingSwitch
                      id="set-twofa"
                      label={t("setTwoFA")}
                      checked={draft.twoFARequired}
                      onCheckedChange={(v) => update("twoFARequired", v)}
                    />
                  </SettingRow>
                  <SettingRow
                    icon="clock"
                    c1="#f59e0b"
                    c2="#ea580c"
                    label={t("setSessionTimeout")}
                    desc={t("setSessionTimeoutDesc")}
                    htmlFor="set-session-timeout"
                  >
                    <NumberField
                      id="set-session-timeout"
                      label={t("setSessionTimeout")}
                      value={draft.sessionTimeout}
                      onCommit={(v) => update("sessionTimeout", v)}
                      min={SESSION_MIN}
                      max={SESSION_MAX}
                      suffix={t("setMinutes")}
                    />
                  </SettingRow>
                </div>
              </DashCard>

              {/* ROUND 158 (security) — the platform-wide IP banlist:
                  the strict ban/allow surface the directive demands. Renders
                  right under the security policy card so the two security
                  controls stay visually grouped. */}
              <BannedIpsCard />
            </div>

            {/* notifications */}
            <div id="settings-section-notifications" data-section="notifications" className="scroll-mt-24">
              <DashCard title={t("setSectionNotif")} icon="bell">
                <div className="divide-y divide-slate-100 dark:divide-white/[0.06]">
                  <SettingRow
                    icon="bell"
                    c1="#f59e0b"
                    c2="#ea580c"
                    label={t("setNotifEmail")}
                    desc={t("setNotifEmailDesc")}
                    htmlFor="set-notif-email"
                  >
                    <SettingSwitch
                      id="set-notif-email"
                      label={t("setNotifEmail")}
                      checked={draft.notifEmail}
                      onCheckedChange={(v) => update("notifEmail", v)}
                    />
                  </SettingRow>
                  <SettingRow
                    icon="chart-pie"
                    c1="#d946ef"
                    c2="#c026d3"
                    label={t("setWeeklyDigest")}
                    desc={t("setWeeklyDigestDesc")}
                    htmlFor="set-weekly-digest"
                  >
                    <SettingSwitch
                      id="set-weekly-digest"
                      label={t("setWeeklyDigest")}
                      checked={draft.weeklyDigest}
                      onCheckedChange={(v) => update("weeklyDigest", v)}
                    />
                  </SettingRow>
                </div>
                {/* ROUND 89 — the live dispatch log + the two real test
                    actions: proof the toggles above actually DO things */}
                <NotificationFeed />
              </DashCard>
            </div>

            {/* EMAIL SYSTEM — Communications → Email (the unified mail
                pipeline's console surface; operator-class roles only —
                moderator/viewer see neither nav entry nor section, and the
                routes 403 them independently) */}
            {isMailOperator ? (
              <div id="settings-section-email" data-section="email" className="scroll-mt-24">
                <AdminMailSection isSuper={isSuper} />
              </div>
            ) : null}

            {/* data & backup */}
            <div id="settings-section-data" data-section="data" className="scroll-mt-24">
              <DashCard title={t("setSectionData")} icon="database-backup">
                <div className="divide-y divide-slate-100 dark:divide-white/[0.06]">
                  <SettingRow
                    icon="database-backup"
                    c1="#06b6d4"
                    c2="#0284c7"
                    label={t("setAutoBackup")}
                    desc={t("setAutoBackupDesc")}
                    htmlFor="set-auto-backup"
                  >
                    <SettingSwitch
                      id="set-auto-backup"
                      label={t("setAutoBackup")}
                      checked={draft.autoBackup}
                      onCheckedChange={(v) => update("autoBackup", v)}
                    />
                  </SettingRow>
                  <SettingRow
                    icon="refresh-cw"
                    c1="#0ea5e9"
                    c2="#0369a1"
                    label={t("setBackupFreq")}
                    desc={t("setBackupFreqDesc")}
                    htmlFor="set-backup-freq"
                  >
                    <Select
                      value={draft.backupFreq}
                      onValueChange={(v) => update("backupFreq", v as SettingsDraft["backupFreq"])}
                      dir={lang === "ar" ? "rtl" : "ltr"}
                    >
                      <SelectTrigger id="set-backup-freq" className={`${FIELD_INPUT} w-full justify-between sm:w-40`}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="rounded-xl">
                        <SelectGroup>
                          <SelectItem value="daily" className="text-[12.5px] font-bold">
                            {t("setFreqDaily")}
                          </SelectItem>
                          <SelectItem value="weekly" className="text-[12.5px] font-bold">
                            {t("setFreqWeekly")}
                          </SelectItem>
                          <SelectItem value="monthly" className="text-[12.5px] font-bold">
                            {t("setFreqMonthly")}
                          </SelectItem>
                        </SelectGroup>
                      </SelectContent>
                    </Select>
                  </SettingRow>
                  <SettingRow
                    icon="clock-rotate-left"
                    c1="#8b5cf6"
                    c2="#6d28d9"
                    label={t("setAuditLog")}
                    desc={t("setAuditLogDesc")}
                    htmlFor="set-audit-log"
                  >
                    <SettingSwitch
                      id="set-audit-log"
                      label={t("setAuditLog")}
                      checked={draft.auditLog}
                      onCheckedChange={(v) => update("auditLog", v)}
                    />
                  </SettingRow>
                  <SettingRow
                    icon="archive"
                    c1="#64748b"
                    c2="#475569"
                    label={t("setDataRetention")}
                    desc={t("setDataRetentionDesc")}
                    htmlFor="set-data-retention"
                  >
                    <div className="flex w-full flex-col items-end gap-1.5 sm:w-48">
                      {/* curated retention periods — none → 2 years */}
                      <Select
                        value={String(draft.dataRetention)}
                        onValueChange={(v) => update("dataRetention", Number.parseInt(v, 10))}
                        dir={lang === "ar" ? "rtl" : "ltr"}
                      >
                        <SelectTrigger
                          id="set-data-retention"
                          className={`${FIELD_INPUT} w-full justify-between sm:w-48`}
                        >
                          <CatIcon
                            name={draft.dataRetention === 0 ? "trash-2" : "archive"}
                            className={cn(
                              "h-[13px] w-[13px] shrink-0",
                              draft.dataRetention === 0 ? "text-rose-500" : "text-slate-400"
                            )}
                          />
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="rounded-xl">
                          <SelectGroup>
                            {RETENTION_OPTIONS.map((opt) => (
                              <SelectItem key={opt.days} value={String(opt.days)} className="text-[12.5px] font-bold">
                                {t(opt.key)}
                              </SelectItem>
                            ))}
                            {/* a previously-saved custom value stays selectable */}
                            {!RETENTION_OPTIONS.some((o) => o.days === draft.dataRetention) ? (
                              <SelectItem value={String(draft.dataRetention)} className="text-[12.5px] font-bold">
                                {fmtNum(draft.dataRetention, lang)} {t("setDays")}
                              </SelectItem>
                            ) : null}
                          </SelectGroup>
                        </SelectContent>
                      </Select>
                      {draft.dataRetention === 0 ? (
                        <p className="flex items-center gap-1.5 rounded-lg border border-rose-200/70 bg-rose-500/[0.06] px-2.5 py-1.5 text-end text-[10px] font-bold leading-relaxed text-rose-600 dark:border-rose-500/25 dark:text-rose-300">
                          <CatIcon name="triangle-alert" className="h-3 w-3 shrink-0" />
                          {t("setRetentionNoneNote")}
                        </p>
                      ) : null}
                    </div>
                  </SettingRow>
                  {/* ROUND 87 — STRICT trash retention window (7..365 days).
                      SUPER-ONLY visibility (the AI-section gate pattern — the
                      PATCH route independently 403s non-super writes): a plain
                      admin must not shorten how long soft-deleted evidence
                      survives before the automatic purge. */}
                  {isSuper ? (
                    <SettingRow
                      icon="trash-2"
                      c1="#f43f5e"
                      c2="#e11d48"
                      label={t("trashKpiRetention")}
                      htmlFor="set-trash-retention"
                    >
                      <NumberField
                        id="set-trash-retention"
                        label={t("trashKpiRetention")}
                        value={draft.trashRetentionDays}
                        onCommit={(v) => update("trashRetentionDays", v)}
                        min={TRASH_RETENTION_MIN}
                        max={TRASH_RETENTION_MAX}
                        suffix={t("setDays")}
                      />
                    </SettingRow>
                  ) : null}
                </div>
              </DashCard>
            </div>

            {/* ROUND 41 — AI / APIs (Super-Admin only; nothing renders for
                any other role — the /api/admin/ai routes enforce it too) */}
            {isSuper ? (
              <div id="settings-section-ai" data-section="ai" className="scroll-mt-24">
                <AiAdminSection />
              </div>
            ) : null}
          </div>
        </div>
      </form>

      {/* restore confirm — discards local edits only */}
      <AlertDialog open={confirmReset} onOpenChange={setConfirmReset}>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display text-lg font-extrabold text-slate-900 dark:text-white">
              {t("setResetConfirm")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] text-slate-500 dark:text-slate-400">
              {t("setResetMsg")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold">
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={discard}
              className="h-10 gap-2 rounded-xl bg-linear-to-l from-brand-600 via-fuchsia-500 to-cyan-400 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
            >
              <CatIcon name="clock-rotate-left" className="h-4 w-4" />
              {t("setReset")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default AdminSettings;
