"use client";

/**
 * Ashrilogic — admin packages management view (الباقات).
 *
 * Manages the subscription plans shown on the public pricing page:
 * KPI cards (active plans / featured plan / avg. monthly price / yearly
 * savings), a filterable grid of premium plan cards that mirrors the
 * pricing-section design language (gradient tiles, check bullets, gradient
 * ring for the featured plan), an add/edit Dialog with full PackagePayload
 * form (names + descriptions AR/EN, prices + currency, limits, features
 * one-per-line, popular/active switches) and delete confirmation.
 *
 * ROUND 79 — the form gained TWO premium editors:
 *   • «التخفيض / Discount» — preset chip row (0…50 ladder from the frozen
 *     catalog) + validated custom percent (0…90) + a LIVE preview showing
 *     the crossed-out base → discounted price for BOTH cycles plus the
 *     monthly savings chip; persisted as PackagePayload.discountPct.
 *   • «مزايا الباقة / Plan capabilities» — the 8 machine feature keys as
 *     grouped switch rows (FEATURE_GROUPS order), a live «{n} من 8» count
 *     chip and a per-tier "restore defaults" shortcut whenever the typed
 *     name matches a standard tier; persisted as PackagePayload.capabilities.
 * The plan CARDS mirror both live: crossed-out base + discounted price +
 * «خصم {pct}٪» chip, and a capabilities chip row (count + first labels).
 *
 * ROUND 87 — «المزايا» became a STRICT, RICH authoring experience
 * (directive: «قم بإضافة المزيد من المزايا بدقة وتأكد أنه صارم جداً»):
 *   • the two textareas gained a LIVE LINT strip that mirrors the server's
 *     exact judgments (per-line length 2..200, normalized duplicates, the
 *     3..24 count law, the AR↔EN parity contract, plus a gentle warning
 *     when an "English" line still carries Arabic script);
 *   • «مكتبة المزايا الاحترافية» — a curated bilingual benefits library
 *     (36 professional suggestions across 6 categories + 3 full TIER
 *     PRESETS): one tap appends the AR AND EN lines together, so pricing
 *     parity holds by construction; already-added suggestions check off;
 *   • the submit is REFUSED with a precise toast while any hard lint
 *     issue stands, and saved lines are normalized exactly the way the
 *     server will (bullets stripped, whitespace collapsed).
 */
import { useEffect, useMemo, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  createPackage,
  deletePackage,
  fetchInstances,
  fetchPackages,
  fetchPlatformSettings,
  updateInstance,
  updatePackage,
} from "@/lib/api-client";
import { useAdminCanManage } from "@/lib/admin-auth";
import { useT, type I18nKey } from "@/lib/i18n";
import type { PackageDTO, PackagePayload } from "@/lib/types";
import {
  BENEFIT_LIBRARY,
  TIER_PRESETS,
  benefitAlreadyAdded,
  type BenefitSuggestion,
} from "@/lib/package-benefit-library";
import {
  DEFAULT_CAPABILITIES,
  DISCOUNT_PRESETS,
  FEATURE_GROUPS,
  FEATURE_META,
  MAX_DISCOUNT_PCT,
  MAX_PACKAGE_FEATURES,
  MIN_PACKAGE_FEATURES,
  PACKAGE_FEATURE_MAX_CHARS,
  PACKAGE_FEATURE_MIN_CHARS,
  PLAN_FEATURES,
  type PlanFeature,
  discountedPrice,
  effectiveYearlyPct,
  lintFeatureLines,
  normalizeFeatureLine,
  rawFeatureLines,
  standardTierOf,
} from "@/lib/plan-features";
import { CATEGORY_MAP, SYSTEM_MAP } from "@/data/catalog";
import { formatBytes } from "@/lib/image-tools";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, hexAlpha } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { ViewHeading } from "@/components/dashboard/dash-shared";
import { KpiCard } from "@/components/shared/kpi-card";
import { PackageQuotaEditor } from "@/components/admin/pkg-quota-editor";

/* ---------------- visual vocabulary (shared with admin-login) ---------------- */

const FIELD_LABEL = "text-[11px] font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400";
const FIELD_INPUT =
  "h-11 rounded-xl border-slate-200 bg-slate-50/80 px-3.5 text-[13px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:focus:bg-white/[0.07]";

/** Deterministic icon + gradient cycle for plan cards (by sortOrder). */
const PLAN_STYLES = [
  { icon: "package", c1: "#06b6d4", c2: "#0891b2" },
  { icon: "gem", c1: "#6d5dfb", c2: "#d946ef" },
  { icon: "crown", c1: "#f59e0b", c2: "#ea580c" },
  { icon: "star", c1: "#10b981", c2: "#059669" },
] as const;

const CURRENCIES = ["SAR", "AED", "EGP", "USD", "EUR", "GBP"] as const;

type PkgFilter = "all" | "active" | "popular";

/** ROUND 79 — localized display names for the three standard tiers (used by
 *  the “restore default capabilities” hint in the package form). */
const TIER_LABEL: Record<"starter" | "professional" | "enterprise", I18nKey> = {
  starter: "pkgTierStarter",
  professional: "pkgTierProfessional",
  enterprise: "pkgTierEnterprise",
};

/** ROUND 79 — FEATURE_META ships lucide names as data; `file-down` is not in
 *  the project icon registry, so map it to the closest registered icon
 *  (everything else resolves natively). Pure display, never persisted. */
const FEAT_ICON_FIX: Record<string, string> = { "file-down": "download" };
function featIcon(icon: string): string {
  return FEAT_ICON_FIX[icon] ?? icon;
}

/* ---------------- KPI card ---------------- */
/* Consolidated into src/components/shared/kpi-card.tsx (sub prop). */

/* ---------------- plan card (pricing-section design language) ---------------- */

function PlanCard({
  pkg,
  index,
  assignCount,
  canManage,
  onEdit,
  onDelete,
  onAssign,
}: {
  pkg: PackageDTO;
  index: number;
  /** how many instances currently have this plan assigned (live data) */
  assignCount?: number;
  /** round 29 — below-admin roles may assign but not edit/delete plans */
  canManage: boolean;
  onEdit: (pkg: PackageDTO) => void;
  onDelete: (id: string) => void;
  onAssign: (pkg: PackageDTO) => void;
}) {
  const { t, lang } = useT();
  const style = PLAN_STYLES[
    ((((pkg.sortOrder - 1) % PLAN_STYLES.length) + PLAN_STYLES.length) % PLAN_STYLES.length)
  ];
  const name = lang === "ar" ? pkg.nameAr : pkg.nameEn;
  const desc = (lang === "ar" ? pkg.descAr : pkg.descEn) || "—";
  const allFeatures = lang === "ar" ? pkg.features : pkg.featuresEn.length > 0 ? pkg.featuresEn : pkg.features;
  /* round 26 — show six bullets, expand inline to the full curated list */
  const [expanded, setExpanded] = useState(false);
  const visibleCount = expanded ? allFeatures.length : Math.min(6, allFeatures.length);
  const features = allFeatures.slice(0, visibleCount);
  const overflow = allFeatures.length - features.length;

  return (
    <article
      className={cn(
        "glass-card card-in group relative flex flex-col overflow-hidden rounded-3xl p-5 transition-shadow duration-300",
        pkg.popular
          ? "shadow-xl shadow-brand-500/15 hover:shadow-2xl hover:shadow-brand-500/25"
          : "hover:shadow-lift"
      )}
      style={{ "--i": index } as React.CSSProperties}
    >
      {/* hover glow accent */}
      <div
        className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-100"
        style={{ background: `radial-gradient(400px circle at 50% 0%, ${hexAlpha(style.c1, 0.08)}, transparent 70%)` }}
        aria-hidden="true"
      />

      {/* gradient ring for the featured plan */}
      {pkg.popular ? (
        <span
          className="pointer-events-none absolute inset-0 rounded-3xl p-[2px]"
          style={{
            background: grad(style.c1, style.c2),
            WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)",
            WebkitMaskComposite: "xor",
            maskComposite: "exclude",
          } as React.CSSProperties}
          aria-hidden="true"
        />
      ) : null}

      {/* featured badge */}
      {pkg.popular ? (
        <span
          className="absolute end-4 top-4 z-10 inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-extrabold text-white shadow-md"
          style={{ backgroundImage: grad(style.c1, style.c2) }}
        >
          <CatIcon name="star" className="h-[9px] w-[9px] fill-white" />
          {t("pkgPopularBadge")}
        </span>
      ) : null}

      {/* plan header */}
      <div className="relative flex items-start gap-3">
        <span
          className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-white shadow-lg transition-transform duration-300 group-hover:scale-110"
          style={{ backgroundImage: grad(style.c1, style.c2) }}
          aria-hidden="true"
        >
          <CatIcon name={style.icon} className="h-[17px] w-[17px]" />
        </span>
        <div className={cn("min-w-0 flex-1", pkg.popular && "pe-16")}>
          <h3 className="truncate font-display text-[17px] font-extrabold text-slate-900 dark:text-white">
            {name}
          </h3>
          <p className="mt-1 line-clamp-2 text-[12px] leading-snug text-slate-500 dark:text-slate-400">
            {desc}
          </p>
        </div>
      </div>

      {/* price — ROUND 79 → ROUND 80: per-cycle crossed-out base + live
          discounted price + chip (monthly promotion + dedicated annual) */}
      <div className="relative mt-4 flex flex-wrap items-end gap-x-1.5 gap-y-1">
        {pkg.discountPct > 0 ? (
          <span
            dir="ltr"
            className="mb-1 self-center text-[12px] font-bold tabular-nums text-slate-400 line-through decoration-rose-400/80 decoration-2 dark:text-slate-500"
          >
            {fmtNum(pkg.priceMonthly, lang)}
          </span>
        ) : null}
        <span className="font-display text-3xl font-extrabold leading-none text-slate-900 dark:text-white">
          {fmtNum(discountedPrice(pkg.priceMonthly, pkg.discountPct), lang)}
        </span>
        <span className="text-[12px] font-bold text-slate-500 dark:text-slate-400">{pkg.currency}</span>
        <span className="pb-0.5 text-[11px] font-semibold text-slate-400 dark:text-slate-500">
          {t("pkgPerMonth")}
        </span>
        {pkg.discountPct > 0 ? (
          <span className="mb-0.5 inline-flex shrink-0 items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10.5px] font-extrabold text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400">
            <CatIcon name="percent" className="h-[10px] w-[10px]" />
            {t("pkgDiscountChip", { pct: fmtNum(pkg.discountPct, lang) })}
          </span>
        ) : null}
      </div>
      <p className="relative mt-1.5 flex flex-wrap items-center gap-x-1.5 gap-y-0.5 text-[11px] font-bold text-slate-400 dark:text-slate-500">
        {(() => {
          /* ROUND 80 — the annual row uses the DEDICATED yearly promotion
             (0 = inherit the monthly one) — same law as order amounts. */
          const yPct = effectiveYearlyPct(pkg);
          return (
            <>
              {yPct > 0 ? (
                <span dir="ltr" className="tabular-nums line-through decoration-rose-400/70">
                  {fmtNum(pkg.priceYearly, lang)}
                </span>
              ) : null}
              <span dir="ltr" className={cn("tabular-nums", yPct > 0 && "font-extrabold text-slate-500 dark:text-slate-400")}>
                {fmtNum(discountedPrice(pkg.priceYearly, yPct), lang)} {pkg.currency}
              </span>
              <span className="mx-1.5 text-slate-300 dark:text-slate-600" aria-hidden="true">
                ·
              </span>
              {t("pkgYear")}
              {yPct > 0 ? (
                <span className="ms-1 inline-flex shrink-0 items-center gap-1 rounded-full bg-teal-500/10 px-2 py-0.5 text-[10px] font-extrabold text-teal-600 dark:bg-teal-500/15 dark:text-teal-300">
                  <CatIcon name="percent" className="h-[9px] w-[9px]" />
                  {t("pkgDiscountChipYearly", { pct: fmtNum(yPct, lang) })}
                </span>
              ) : null}
            </>
          );
        })()}
      </p>

      {/* ROUND 79 — machine capabilities: count + first feature labels */}
      {(() => {
        const caps = pkg.capabilities.filter((c): c is PlanFeature =>
          (PLAN_FEATURES as readonly string[]).includes(c)
        );
        return (
          <div className="relative mt-2.5 flex flex-wrap items-center gap-1.5">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-violet-500/10 px-2.5 py-1 text-[10.5px] font-extrabold text-violet-700 dark:bg-violet-500/15 dark:text-violet-300">
              <CatIcon name="sparkles" className="h-[11px] w-[11px]" />
              {t("pkgCapsCount", { n: fmtNum(caps.length, lang), total: fmtNum(PLAN_FEATURES.length, lang) })}
            </span>
            {caps.slice(0, 3).map((cap) => (
              <span
                key={`${pkg.id}-cap-${cap}`}
                className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-500 dark:bg-white/10 dark:text-slate-400"
              >
                <CatIcon name={featIcon(FEATURE_META[cap].icon)} className="h-[9px] w-[9px]" />
                {t(FEATURE_META[cap].labelKey)}
              </span>
            ))}
          </div>
        );
      })()}

      {/* limits + status */}
      <div className="relative mt-4 flex flex-wrap items-center gap-1.5">
        <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-2.5 py-1 text-[10.5px] font-extrabold text-slate-600 dark:bg-white/10 dark:text-slate-300">
          <CatIcon name="users" className="h-[11px] w-[11px]" />
          {fmtNum(pkg.maxUsers, lang)}
        </span>
        <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-2.5 py-1 text-[10.5px] font-extrabold text-slate-600 dark:bg-white/10 dark:text-slate-300">
          <CatIcon name="boxes" className="h-[11px] w-[11px]" />
          {fmtNum(pkg.maxModules, lang)}
        </span>
        {/* ROUND 47 — workspace storage allowance chip */}
        <span
          title={t("storageQuotaPlan")}
          className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-2.5 py-1 text-[10.5px] font-extrabold text-slate-600 dark:bg-white/10 dark:text-slate-300"
        >
          <CatIcon name="hard-drive" className="h-[11px] w-[11px]" />
          {formatBytes(pkg.maxStorageMb * 1024 * 1024, lang)}
        </span>
        {assignCount !== undefined && assignCount > 0 ? (
          <button
            type="button"
            onClick={() => onAssign(pkg)}
            title={t("pkgAssignAction")}
            className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10.5px] font-extrabold transition active:scale-95"
            style={{
              color: style.c2,
              backgroundColor: hexAlpha(style.c1, 0.12),
            }}
          >
            <CatIcon name="user-plus" className="h-[11px] w-[11px]" />
            {t("pkgAssignChip", { n: fmtNum(assignCount, lang) })}
          </button>
        ) : null}
        <span className="ms-auto">
          <Badge
            className={cn(
              "rounded-full px-2.5 py-0.5 text-[10.5px] font-extrabold",
              pkg.active
                ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                : "bg-slate-500/10 text-slate-500 dark:text-slate-400"
            )}
          >
            {t(pkg.active ? "pkgActiveBadge" : "pkgInactiveBadge")}
          </Badge>
        </span>
      </div>

      {/* features — capped + scrollable when fully expanded */}
      <ul className="relative mt-4 flex-1 space-y-2 max-h-72 overflow-y-auto nice-scroll pe-1">
        {features.map((feature, i) => (
          <li
            key={`${pkg.id}-f-${i}`}
            className="flex items-start gap-2.5 text-[12px] font-semibold text-slate-600 dark:text-slate-300"
          >
            <span
              className="mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full text-white"
              style={{ backgroundImage: grad(style.c1, style.c2) }}
              aria-hidden="true"
            >
              <CatIcon name="check" className="h-[8px] w-[8px]" />
            </span>
            <span className="min-w-0 line-clamp-1">{feature}</span>
          </li>
        ))}
        {overflow > 0 ? (
          <li>
            <button
              type="button"
              onClick={() => setExpanded((v) => !v)}
              aria-expanded={expanded}
              className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-[10.5px] font-extrabold text-slate-500 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
            >
              <CatIcon name={expanded ? "chevron-up" : "chevron-down"} className="h-3 w-3" />
              <span dir="ltr" className="tabular-nums">+{fmtNum(overflow, lang)}</span>
              <span>{t(expanded ? "pkgFeaturesCollapse" : "priceMoreFeatures")}</span>
            </button>
          </li>
        ) : expanded ? (
          <li>
            <button
              type="button"
              onClick={() => setExpanded(false)}
              className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-extrabold text-slate-400 transition hover:text-slate-600 active:scale-95 dark:hover:text-slate-300"
            >
              <CatIcon name="chevron-up" className="h-3 w-3" />
              {t("pkgFeaturesCollapse")}
            </button>
          </li>
        ) : null}
      </ul>

      {/* actions */}
      <div className="relative mt-5 flex items-center gap-1.5 border-t border-slate-200/60 pt-4 dark:border-white/[0.06]">
        {canManage ? (
          <>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => onEdit(pkg)}
              className="h-9 min-w-0 flex-1 rounded-xl border-slate-200 px-3 text-[11.5px] font-bold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:text-slate-300"
            >
              <CatIcon name="pencil" className="h-3.5 w-3.5 shrink-0" />
              <span className="truncate">{t("pkgEditTitle")}</span>
            </Button>
            {/* ROUND 65 — direct verification loop: opens the live pricing
                section (fresh tab = fresh public fetch) right after an edit */}
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => window.open("/#pricing", "_blank", "noopener,noreferrer")}
              aria-label={`${t("pkgViewOnSite")} — ${name}`}
              title={t("pkgViewOnSite")}
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-slate-400 transition hover:border-brand-300 hover:text-brand-600 dark:text-slate-500 dark:hover:text-brand-300"
            >
              <CatIcon name="external-link" className="h-4 w-4" />
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => onDelete(pkg.id)}
              aria-label={`${t("pkgDeleteTitle")} — ${name}`}
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-slate-400 transition hover:bg-rose-500/10 hover:text-rose-600 dark:text-slate-500 dark:hover:text-rose-300"
            >
              <CatIcon name="trash-2" className="h-4 w-4" />
            </Button>
          </>
        ) : (
          <span
            title={t("adminNoPerm")}
            className="inline-flex h-9 min-w-0 flex-1 items-center justify-center gap-1.5 rounded-xl border border-dashed border-slate-300 px-3 text-[11px] font-bold text-slate-400 dark:border-white/15 dark:text-slate-500"
          >
            <CatIcon name="lock" className="h-3.5 w-3.5" />
            <span className="truncate">{t("adminNoPerm")}</span>
          </span>
        )}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              type="button"
              aria-label={t("pkgColActions")}
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-slate-200 text-slate-500 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:text-slate-300"
            >
              <CatIcon name="ellipsis-vertical" className="h-[14px] w-[14px]" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-52">
            <DropdownMenuItem onClick={() => onAssign(pkg)}>
              <CatIcon name="user-plus" className="h-4 w-4" />
              {t("pkgAssignAction")}
            </DropdownMenuItem>
            {/* ROUND 65 — verification loop for every admin role */}
            <DropdownMenuItem
              onClick={() => window.open("/#pricing", "_blank", "noopener,noreferrer")}
            >
              <CatIcon name="external-link" className="h-4 w-4" />
              {t("pkgViewOnSite")}
            </DropdownMenuItem>
            {canManage ? (
              <>
                <DropdownMenuItem onClick={() => onEdit(pkg)}>
                  <CatIcon name="pencil" className="h-4 w-4" />
                  {t("pkgEditTitle")}
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={() => onDelete(pkg.id)}
                  className="text-rose-600 focus:text-rose-600 dark:text-rose-400 dark:focus:text-rose-400"
                >
                  <CatIcon name="trash-2" className="h-4 w-4" />
                  {t("pkgDeleteTitle")}
                </DropdownMenuItem>
              </>
            ) : null}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </article>
  );
}

/* ---------------- assign-to-subscriber dialog ---------------- */

/**
 * Assigns (or clears) a package on subscriber instances right from the
 * packages view — the inverse of the subscribers detail-sheet flow. Rows are
 * multi-selectable (click / checkbox / select-all) and a sticky bulk bar
 * assigns or clears the plan for the whole selection in one pass. Rows
 * already on this plan keep their emerald wash + badge so the current state
 * is readable at a glance.
 *
 * Mounted conditionally by the parent (fresh search + selection state per
 * open / per plan).
 */
function AssignPlanDialog({ pkg, onClose }: { pkg: PackageDTO; onClose: () => void }) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  /* live progress for large bulk selections — updated per completed request */
  const [progress, setProgress] = useState<{ done: number; total: number } | null>(null);

  const instancesQuery = useQuery({
    queryKey: ["instances"],
    queryFn: fetchInstances,
    enabled: true,
  });

  const instances = useMemo(() => {
    const list = instancesQuery.data ?? [];
    const q = search.trim().toLowerCase();
    if (!q) return list;
    return list.filter((inst) => {
      const sys = SYSTEM_MAP[inst.systemId];
      const sysName = sys ? (lang === "ar" ? sys.nameAr : sys.nameEn) : inst.systemId;
      return (
        inst.org.name.toLowerCase().includes(q) ||
        inst.admin.email.toLowerCase().includes(q) ||
        inst.admin.name.toLowerCase().includes(q) ||
        sysName.toLowerCase().includes(q)
      );
    });
  }, [instancesQuery.data, search, lang]);

  const toggle = (id: string) =>
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  const allShownSelected =
    instances.length > 0 && instances.every((i) => selected.has(i.id));

  const toggleAll = () =>
    setSelected((prev) => {
      if (instances.length > 0 && instances.every((i) => prev.has(i.id))) {
        return new Set();
      }
      return new Set(instances.map((i) => i.id));
    });

  /** number of selected rows that already sit on this plan (enables "clear") */
  const selectedOnPlan = useMemo(
    () =>
      (instancesQuery.data ?? []).filter(
        (i) => selected.has(i.id) && i.package?.id === pkg.id
      ).length,
    [instancesQuery.data, selected, pkg.id]
  );

  const bulk = useMutation({
    mutationFn: async ({ packageId, ids }: { packageId: string | null; ids: string[] }) => {
      /* sequential with per-item progress so very large selections show a
         live "n / total" bar instead of one opaque spinner */
      setProgress({ done: 0, total: ids.length });
      let done = 0;
      for (const id of ids) {
        await updateInstance(id, { packageId });
        done += 1;
        setProgress({ done, total: ids.length });
      }
    },
    onSuccess: (_data, { ids }) => {
      setProgress(null);
      toast.success(t("pkgAssignBulkSuccess", { n: fmtNum(ids.length, lang) }));
      queryClient.invalidateQueries({ queryKey: ["instances"] });
      queryClient.invalidateQueries({ queryKey: ["instance"] });
      queryClient.invalidateQueries({ queryKey: ["admin-packages"] });
      /* ROUND 65 — public mirrors of package data stay fresh too */
      queryClient.invalidateQueries({ queryKey: ["public-packages"] });
      setSelected(new Set());
    },
    onError: (err: Error) => {
      setProgress(null);
      toast.error(`${t("errorText")}: ${err.message}`);
    },
  });

  const name = lang === "ar" ? pkg.nameAr : pkg.nameEn;
  const style = PLAN_STYLES[
    ((((pkg.sortOrder - 1) % PLAN_STYLES.length) + PLAN_STYLES.length) % PLAN_STYLES.length)
  ];

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="gap-0 overflow-hidden rounded-3xl p-0 sm:max-w-md">
        <DialogHeader className="sr-only">
          <DialogTitle>{t("pkgAssignTitle")}</DialogTitle>
          <DialogDescription>{t("pkgAssignDesc", { name })}</DialogDescription>
        </DialogHeader>

        {/* gradient banner — plan identity + select-all */}
        <div
          className="relative flex items-center gap-3 border-b border-slate-200/70 px-5 py-4 dark:border-white/10"
          style={{
            backgroundImage: `linear-gradient(135deg, ${hexAlpha(style.c1, 0.14)}, ${hexAlpha(style.c2, 0.14)})`,
          }}
        >
          <span
            aria-hidden="true"
            className="absolute -end-8 -top-12 h-28 w-28 rounded-full"
            style={{ background: `radial-gradient(circle, ${hexAlpha(style.c1, 0.28)}, transparent 70%)` }}
          />
          <span
            className="relative grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
            style={{ backgroundImage: grad(style.c1, style.c2) }}
            aria-hidden="true"
          >
            <CatIcon name={style.icon} className="h-[15px] w-[15px]" />
          </span>
          <div className="relative min-w-0 flex-1">
            <p className="truncate font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
              {name}
            </p>
            <p dir="ltr" className="text-start text-[11px] font-bold text-slate-500 dark:text-slate-400">
              {fmtNum(pkg.priceMonthly, lang)} {pkg.currency}
              <span className="mx-1 text-slate-300 dark:text-slate-600">·</span>
              {t("pkgPerMonth")}
            </p>
          </div>
          {instances.length > 0 ? (
            <button
              type="button"
              onClick={toggleAll}
              aria-pressed={allShownSelected}
              className="relative inline-flex shrink-0 items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/70 px-2.5 py-1.5 text-[10px] font-extrabold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:bg-white/[0.06] dark:text-slate-300"
            >
              <CatIcon name={allShownSelected ? "x" : "check-check"} className="h-3 w-3" />
              <span className="hidden sm:inline">{t(allShownSelected ? "pkgAssignDeselect" : "pkgAssignSelectAll")}</span>
            </button>
          ) : null}
        </div>

        <div className="space-y-3 p-5">
          {/* search */}
          <div className="relative">
            <CatIcon
              name="search"
              className="pointer-events-none absolute start-3 top-1/2 h-[14px] w-[14px] -translate-y-1/2 text-slate-400"
            />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t("adminSearchPh")}
              aria-label={t("adminSearchPh")}
              className={`${FIELD_INPUT} ps-9`}
            />
          </div>

          {/* instances list — click a row to toggle selection */}
          <div className="max-h-80 overflow-y-auto pe-1 nice-scroll">
            {instancesQuery.isPending ? (
              <div className="space-y-2">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-16 rounded-2xl" />
                ))}
              </div>
            ) : instances.length === 0 ? (
              <div className="py-10 text-center">
                <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5">
                  <CatIcon name="users" className="h-5 w-5" />
                </div>
                <p className="mt-2.5 text-[12.5px] font-bold text-slate-500 dark:text-slate-400">
                  {t("adminNoSubscribers")}
                </p>
              </div>
            ) : (
              <ul className="space-y-2">
                {instances.map((inst) => {
                  const sys = SYSTEM_MAP[inst.systemId];
                  const cat = sys ? CATEGORY_MAP[sys.c] : undefined;
                  const c1 = cat?.c1 ?? "#6d5dfb";
                  const c2 = cat?.c2 ?? "#0ea5e9";
                  const current = inst.package;
                  const onThisPlan = current?.id === pkg.id;
                  const isSelected = selected.has(inst.id);
                  return (
                    <li key={inst.id}>
                      <label
                        className={cn(
                          "flex cursor-pointer items-center gap-3 rounded-2xl border p-3 transition",
                          onThisPlan || isSelected
                            ? "border-emerald-300/60 bg-emerald-50/60 dark:border-emerald-500/25 dark:bg-emerald-500/[0.07]"
                            : "border-slate-200/80 bg-slate-50/40 hover:border-brand-300/60 hover:bg-brand-50/40 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-brand-500/30 dark:hover:bg-white/[0.05]"
                        )}
                      >
                        <Checkbox
                          checked={isSelected}
                          onCheckedChange={() => toggle(inst.id)}
                          aria-label={inst.org.name}
                          className="h-[18px] w-[18px] shrink-0 rounded-[6px] data-[state=checked]:border-emerald-500 data-[state=checked]:bg-emerald-500 data-[state=checked]:text-white"
                        />
                        <span
                          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white"
                          style={{ backgroundImage: grad(c1, c2) }}
                          aria-hidden="true"
                        >
                          <CatIcon name={sys?.icon ?? "boxes"} className="h-[13px] w-[13px]" />
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                            {inst.org.name}
                            {onThisPlan ? (
                              <span className="ms-1.5 inline-flex items-center gap-1 rounded-full bg-emerald-500/15 px-1.5 py-px align-middle text-[11px] font-extrabold text-emerald-600 dark:text-emerald-400">
                                <CatIcon name="badge-check" className="h-[9px] w-[9px]" />
                                {t("pkgAssignBadge")}
                              </span>
                            ) : null}
                          </span>
                          <span dir="ltr" className="block truncate text-start text-[10.5px] font-semibold text-slate-500 dark:text-slate-400">
                            {inst.admin.email}
                          </span>
                          <span className="mt-0.5 flex items-center gap-1 text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                            <CatIcon name="gem" className="h-[9px] w-[9px]" />
                            {t("pkgAssignCurrent")}:
                            <span className="font-bold normal-case tracking-normal text-slate-600 dark:text-slate-300">
                              {current
                                ? lang === "ar"
                                  ? current.nameAr
                                  : current.nameEn
                                : t("pkgAssignCurrentNoPlan")}
                            </span>
                          </span>
                        </span>
                      </label>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </div>

        {/* sticky bulk-action bar — appears once anything is selected */}
        {selected.size > 0 ? (
          <div className="sticky bottom-0 border-t border-slate-200/80 bg-white/95 px-5 py-3 backdrop-blur-xl dark:border-white/10 dark:bg-[#0b1222]/95">
            {/* live progress track for large selections */}
            {progress ? (
              <div className="mb-2.5">
                <div className="mb-1 flex items-center justify-between text-[10px] font-extrabold text-slate-500 dark:text-slate-400">
                  <span className="inline-flex items-center gap-1">
                    <CatIcon name="refresh-cw" className="h-3 w-3 animate-spin text-brand-500" />
                    {t("pkgAssignProgress", {
                      done: fmtNum(progress.done, lang),
                      total: fmtNum(progress.total, lang),
                    })}
                  </span>
                  <span className="tabular-nums">
                    {Math.round((progress.done / progress.total) * 100)}%
                  </span>
                </div>
                <div
                  className="h-1.5 w-full overflow-hidden rounded-full bg-slate-200/80 dark:bg-white/10"
                  role="progressbar"
                  aria-valuemin={0}
                  aria-valuemax={progress.total}
                  aria-valuenow={progress.done}
                >
                  <div
                    className="h-full rounded-full transition-[width] duration-300 ease-out"
                    style={{
                      width: `${(progress.done / progress.total) * 100}%`,
                      backgroundImage: grad(style.c1, style.c2),
                    }}
                  />
                </div>
              </div>
            ) : null}
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-brand-500/10 px-2.5 py-1 text-[10.5px] font-extrabold text-brand-700 dark:bg-brand-500/15 dark:text-brand-300">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-brand-500 dark:bg-brand-300" aria-hidden="true" />
                {progress
                  ? t("pkgAssignProgress", {
                      done: fmtNum(progress.done, lang),
                      total: fmtNum(progress.total, lang),
                    })
                  : t("pkgAssignSelected", { n: fmtNum(selected.size, lang) })}
              </span>
              <div className="ms-auto flex items-center gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  disabled={bulk.isPending || selectedOnPlan === 0}
                  onClick={() => bulk.mutate({ packageId: null, ids: [...selected] })}
                  title={selectedOnPlan === 0 ? undefined : `${t("pkgAssignBulkClear")} (${fmtNum(selectedOnPlan, lang)})`}
                  className="h-8 rounded-xl border-slate-200 px-3 text-[10.5px] font-bold text-slate-500 transition hover:border-rose-300 hover:text-rose-600 dark:border-white/10 dark:text-slate-400 dark:hover:text-rose-300"
                >
                  <CatIcon name="x" className="h-3 w-3" />
                  {t("pkgAssignBulkClear")}
                </Button>
                <Button
                  type="button"
                  size="sm"
                  disabled={bulk.isPending}
                  onClick={() => bulk.mutate({ packageId: pkg.id, ids: [...selected] })}
                  className="h-8 rounded-xl px-4 text-[10.5px] font-extrabold text-white shadow-md transition hover:brightness-110 active:scale-95 disabled:opacity-60"
                  style={{ backgroundImage: grad(style.c1, style.c2) }}
                >
                  {bulk.isPending ? (
                    <CatIcon name="refresh-cw" className="h-3 w-3 animate-spin" />
                  ) : (
                    <CatIcon name="user-plus" className="h-3 w-3" />
                  )}
                  {t("pkgAssignBulkBtn")}
                </Button>
              </div>
            </div>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}

/* ---------------- add / edit dialog ---------------- */

interface PackageFormState {
  nameAr: string;
  nameEn: string;
  descAr: string;
  descEn: string;
  monthly: string;
  yearly: string;
  currency: string;
  maxUsers: string;
  maxModules: string;
  /* ROUND 47 — workspace storage allowance in MB (0..10240) */
  maxStorage: string;
  sortOrder: string;
  features: string;
  featuresEn: string;
  /* ROUND 79 — live discount percentage (whole 0..90) — monthly cycle */
  discountPct: string;
  /* ROUND 80 — dedicated ANNUAL-cycle discount (whole 0..90; 0 = inherit
   * the monthly promotion) */
  yearlyDiscountPct: string;
  /* ROUND 79 — machine capability keys unlocked by this plan */
  capabilities: PlanFeature[];
  popular: boolean;
  active: boolean;
}

function emptyForm(nextSort: number): PackageFormState {
  return {
    nameAr: "",
    nameEn: "",
    descAr: "",
    descEn: "",
    monthly: "0",
    yearly: "0",
    currency: "SAR",
    maxUsers: "5",
    maxModules: "10",
    /* ROUND 47 — sensible default allowance for a fresh plan (512 MB) */
    maxStorage: "512",
    sortOrder: String(nextSort),
    features: "",
    featuresEn: "",
    /* ROUND 79 — a fresh plan starts with NO discount and the starter
     * capability set (deny-by-default: an unnamed plan is never full access;
     * named tiers get the “restore defaults” hint in the capabilities
     * section). */
    discountPct: "0",
    yearlyDiscountPct: "0",
    capabilities: [...DEFAULT_CAPABILITIES.starter],
    popular: false,
    active: true,
  };
}

function toFormState(pkg: PackageDTO): PackageFormState {
  return {
    nameAr: pkg.nameAr,
    nameEn: pkg.nameEn,
    descAr: pkg.descAr,
    descEn: pkg.descEn,
    monthly: String(pkg.priceMonthly),
    yearly: String(pkg.priceYearly),
    currency: pkg.currency,
    maxUsers: String(pkg.maxUsers),
    maxModules: String(pkg.maxModules),
    /* preserve the live server-enforced allowance when editing */
    maxStorage: String(pkg.maxStorageMb),
    sortOrder: String(pkg.sortOrder),
    features: pkg.features.join("\n"),
    featuresEn: pkg.featuresEn.join("\n"),
    /* ROUND 79 — the DTO already resolves legacy empty capability lists to
     * the tier defaults, so the form materializes exactly what is enforced. */
    discountPct: String(pkg.discountPct ?? 0),
    yearlyDiscountPct: String(pkg.yearlyDiscountPct ?? 0),
    capabilities: pkg.capabilities.filter((c): c is PlanFeature =>
      (PLAN_FEATURES as readonly string[]).includes(c)
    ),
    popular: pkg.popular,
    active: pkg.active,
  };
}

function SwitchRow({
  id,
  label,
  icon,
  checked,
  onCheckedChange,
}: {
  id: string;
  label: string;
  icon: string;
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 bg-slate-50/60 px-3.5 py-2.5 dark:border-white/10 dark:bg-white/[0.02]">
      <Label htmlFor={id} className="flex cursor-pointer items-center gap-2 text-[12.5px] font-bold text-slate-600 dark:text-slate-300">
        <CatIcon name={icon} className="h-3.5 w-3.5 text-brand-500" />
        {label}
      </Label>
      <Switch id={id} checked={checked} onCheckedChange={onCheckedChange} />
    </div>
  );
}

/* ================================================================== */
/* ROUND 87 — the STRICT features authoring layer (المزايا)            */
/* ================================================================== */

/** Arabic script detector — an "English" line that still carries Arabic
 *  letters is a translation left undone (gentle warning, never a blocker:
 *  the server only judges length/duplicates/parity). */
const ARABIC_SCRIPT = /[\u0600-\u06FF\u0750-\u077F]/;

interface LintIssueView {
  line: number;
  kind: "short" | "long" | "duplicate" | "min" | "max" | "arabic";
  text?: string;
}

/**
 * The live lint strip under ONE features textarea — renders the EXACT
 * verdicts the server will produce (same helpers, same thresholds), so the
 * owner never discovers a 400 after "saving". Hard issues (length /
 * duplicates / count) show in rose; soft warnings (Arabic in the EN list)
 * show in amber.
 */
function FeatureLintStrip({
  count,
  issues,
  parity,
  enMode,
  hintWhenEmpty,
}: {
  count: number;
  issues: LintIssueView[];
  /** null = not applicable (AR side); true = parity OK; false = mismatch */
  parity: null | { ar: number; en: number };
  /** the strip belongs to the ENGLISH list (enables fallback + parity copy) */
  enMode: boolean;
  hintWhenEmpty: string;
}) {
  const { t, lang } = useT();
  const hard = issues.filter((i) => i.kind !== "arabic");
  const soft = issues.filter((i) => i.kind === "arabic");
  const minOk = count >= MIN_PACKAGE_FEATURES;
  const maxOk = count <= MAX_PACKAGE_FEATURES;
  const parityOk = !parity || parity.ar === parity.en;

  const stateTone = !minOk || !maxOk || hard.length > 0 || !parityOk
    ? "border-rose-200 bg-rose-50/60 dark:border-rose-500/25 dark:bg-rose-500/[0.07]"
    : soft.length > 0
      ? "border-amber-200 bg-amber-50/60 dark:border-amber-500/25 dark:bg-amber-500/[0.07]"
      : "border-emerald-200 bg-emerald-50/60 dark:border-emerald-500/25 dark:bg-emerald-500/[0.07]";
  const stateIcon = !minOk || !maxOk || hard.length > 0 || !parityOk ? "octagon-alert" : soft.length > 0 ? "triangle-alert" : "circle-check";
  const stateToneText = !minOk || !maxOk || hard.length > 0 || !parityOk
    ? "text-rose-700 dark:text-rose-300"
    : soft.length > 0
      ? "text-amber-700 dark:text-amber-300"
      : "text-emerald-700 dark:text-emerald-300";

  return (
    <div className={`mt-1.5 rounded-xl border px-3 py-2 text-[10.5px] font-semibold leading-relaxed ${stateTone}`}>
      <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1">
        <span className={`inline-flex items-center gap-1 font-extrabold ${stateToneText}`}>
          <CatIcon name={stateIcon} className="h-3 w-3 shrink-0" />
          {fmtNum(count, lang)} / {fmtNum(MAX_PACKAGE_FEATURES, lang)}
        </span>
        {!minOk ? (
          <span className="text-rose-600 dark:text-rose-300">
            {t("pkgLintMin", { n: fmtNum(MIN_PACKAGE_FEATURES, lang) })}
          </span>
        ) : null}
        {!maxOk ? (
          <span className="text-rose-600 dark:text-rose-300">{t("pkgLintMax")}</span>
        ) : null}
        {parity !== null ? (
          parityOk ? (
            <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-300">
              <CatIcon name="circle-check" className="h-3 w-3" />
              {t("pkgLintParityOk", { n: fmtNum(parity.en, lang) })}
            </span>
          ) : (
            <span className="text-rose-600 dark:text-rose-300">
              {t("pkgLintParity", { ar: fmtNum(parity.ar, lang), en: fmtNum(parity.en, lang) })}
            </span>
          )
        ) : null}
        {enMode && count === 0 && hintWhenEmpty ? (
          <span className="text-slate-500 dark:text-slate-400">{hintWhenEmpty}</span>
        ) : null}
        {minOk && maxOk && hard.length === 0 && parityOk && soft.length === 0 && count > 0 ? (
          <span className="text-emerald-600 dark:text-emerald-300">{t("pkgLintOk")}</span>
        ) : null}
      </div>
      {/* precise, line-addressed verdicts — at most the first 3, the count chip carries the rest */}
      {issues.length > 0 ? (
        <ul className="mt-1 space-y-0.5">
          {issues.slice(0, 3).map((issue, i) => (
            <li
              key={`lint-${i}-${issue.line}-${issue.kind}`}
              className={cn(
                "flex items-start gap-1.5",
                issue.kind === "arabic"
                  ? "text-amber-700 dark:text-amber-300"
                  : "text-rose-600 dark:text-rose-300"
              )}
            >
              <CatIcon
                name={issue.kind === "arabic" ? "languages" : "octagon-alert"}
                className="mt-px h-2.5 w-2.5 shrink-0"
              />
              <span className="min-w-0">
                {issue.kind === "min" || issue.kind === "max" ? (
                  t(issue.kind === "min" ? "pkgLintMin" : "pkgLintMax", { n: fmtNum(MIN_PACKAGE_FEATURES, lang) })
                ) : issue.kind === "arabic" ? (
                  t("pkgLintEnArabic", { n: fmtNum(issue.line, lang) })
                ) : issue.kind === "duplicate" ? (
                  t("pkgLintDup", { n: fmtNum(issue.line, lang), text: issue.text ?? "" })
                ) : (
                  t("pkgLintLineLen", {
                    n: fmtNum(issue.line, lang),
                    min: fmtNum(PACKAGE_FEATURE_MIN_CHARS, lang),
                    max: fmtNum(PACKAGE_FEATURE_MAX_CHARS, lang),
                  })
                )}
              </span>
            </li>
          ))}
          {issues.length > 3 ? (
            <li className="text-slate-400 dark:text-slate-500">
              + {fmtNum(issues.length - 3, lang)}…
            </li>
          ) : null}
        </ul>
      ) : null}
    </div>
  );
}

/**
 * «مكتبة المزايا الاحترافية» — the curated bilingual suggestion library.
 * One tap appends the AR + EN pair TOGETHER (parity by construction);
 * suggestions already in the Arabic list check off; the three TIER PRESETS
 * fill both lists with a full professional baseline. Collapsible so the
 * dialog stays calm until the owner wants more.
 */
function BenefitsLibraryCard({
  featuresAr,
  count,
  onAdd,
  onFill,
  tier,
}: {
  featuresAr: string;
  count: number;
  onAdd: (pair: BenefitSuggestion) => void;
  onFill: (tier: "starter" | "professional" | "enterprise") => void;
  tier: "starter" | "professional" | "enterprise" | null;
}) {
  const { t, lang } = useT();
  const [open, setOpen] = useState(false);
  const maxed = count >= MAX_PACKAGE_FEATURES;
  const addedCount = useMemo(
    () =>
      BENEFIT_LIBRARY.reduce(
        (acc, cat) => acc + cat.items.filter((item) => benefitAlreadyAdded(item, featuresAr)).length,
        0
      ),
    [featuresAr]
  );
  const totalCount = useMemo(
    () => BENEFIT_LIBRARY.reduce((acc, cat) => acc + cat.items.length, 0),
    []
  );

  return (
    <div className="rounded-2xl border border-violet-200/70 bg-linear-to-br from-violet-50/40 to-fuchsia-50/20 p-3.5 dark:border-violet-500/20 dark:from-violet-500/[0.06] dark:to-fuchsia-500/[0.04]">
      {/* header — title + live progress + collapse toggle */}
      <div className="flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          aria-expanded={open}
          className="inline-flex items-center gap-1.5 text-start text-[11px] font-extrabold uppercase tracking-wider text-violet-700 transition hover:text-violet-800 dark:text-violet-300 dark:hover:text-violet-200"
        >
          <CatIcon
            name={open ? "chevron-up" : "chevron-down"}
            className="h-3.5 w-3.5 shrink-0"
          />
          {t("pkgLibTitle")}
        </button>
        <span className="inline-flex items-center gap-1 rounded-full bg-violet-500/10 px-2 py-0.5 text-[10px] font-extrabold text-violet-700 dark:bg-violet-500/15 dark:text-violet-300">
          <CatIcon name="sparkles" className="h-[9px] w-[9px]" />
          {fmtNum(addedCount, lang)} / {fmtNum(totalCount, lang)}
        </span>
        {maxed ? (
          <span className="inline-flex items-center gap-1 rounded-full bg-rose-500/10 px-2 py-0.5 text-[10px] font-extrabold text-rose-600 dark:bg-rose-500/15 dark:text-rose-300">
            <CatIcon name="octagon-alert" className="h-[9px] w-[9px]" />
            {t("pkgLibMaxed", { n: fmtNum(MAX_PACKAGE_FEATURES, lang) })}
          </span>
        ) : null}
        {/* tier presets — replace both lists with a professional baseline */}
        <span className="ms-auto hidden items-center gap-1.5 sm:inline-flex">
          {(["starter", "professional", "enterprise"] as const).map((key) => (
            <button
              key={`preset-${key}`}
              type="button"
              onClick={() => onFill(key)}
              title={t("pkgLibFillHint", { tier: t(TIER_LABEL[key]) })}
              className={cn(
                "inline-flex items-center gap-1 rounded-full border px-2 py-1 text-[10px] font-extrabold transition active:scale-95",
                tier === key
                  ? "border-violet-400 bg-violet-500/15 text-violet-700 dark:border-violet-400/60 dark:bg-violet-500/20 dark:text-violet-200"
                  : "border-violet-300/60 bg-white/80 text-violet-600 hover:border-violet-400 hover:bg-violet-500/10 dark:border-violet-500/30 dark:bg-white/[0.05] dark:text-violet-300"
              )}
            >
              <CatIcon name="wand-sparkles" className="h-2.5 w-2.5" />
              {t(TIER_LABEL[key])}
            </button>
          ))}
        </span>
      </div>
      {/* tier presets — visible row on narrow screens */}
      <div className="mt-2 flex items-center gap-1.5 sm:hidden">
        {(["starter", "professional", "enterprise"] as const).map((key) => (
          <button
            key={`preset-m-${key}`}
            type="button"
            onClick={() => onFill(key)}
            className="inline-flex items-center gap-1 rounded-full border border-violet-300/60 bg-white/80 px-2 py-1 text-[10px] font-extrabold text-violet-600 transition active:scale-95 dark:border-violet-500/30 dark:bg-white/[0.05] dark:text-violet-300"
          >
            <CatIcon name="wand-sparkles" className="h-2.5 w-2.5" />
            {t(TIER_LABEL[key])}
          </button>
        ))}
      </div>
      <p className="mt-1.5 text-[10.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
        {t("pkgLibSub")}
      </p>

      {/* the catalog itself — categorized bilingual chips */}
      {open ? (
        <div className="mt-3 space-y-3">
          {BENEFIT_LIBRARY.map((category) => (
            <div key={`lib-${category.key}`}>
              <p className="mb-1.5 flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-wider text-violet-500/80 dark:text-violet-300/70">
                <CatIcon name={category.icon} className="h-3 w-3 shrink-0" />
                {t(category.labelKey)}
              </p>
              <div className="flex flex-wrap gap-1.5">
                {category.items.map((item, i) => {
                  const added = benefitAlreadyAdded(item, featuresAr);
                  return (
                    <button
                      key={`chip-${category.key}-${i}`}
                      type="button"
                      onClick={() => onAdd(item)}
                      disabled={added || maxed}
                      title={lang === "ar" ? item.en : item.ar}
                      aria-pressed={added}
                      className={cn(
                        "group inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1.5 text-[11px] font-bold transition active:scale-95",
                        added
                          ? "border-emerald-300 bg-emerald-50 text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300"
                          : "border-slate-200 bg-white text-slate-600 hover:border-violet-400 hover:bg-violet-50 hover:text-violet-700 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:border-violet-400/60 dark:hover:bg-violet-500/10"
                      )}
                    >
                      <CatIcon
                        name={added ? "check" : "plus"}
                        className={cn("h-2.5 w-2.5 shrink-0", added && "text-emerald-600 dark:text-emerald-400")}
                      />
                      <span dir="auto" className="min-w-0">{item.ar}</span>
                      {added ? (
                        <span className="text-[9px] font-extrabold uppercase text-emerald-500/70">
                          {t("pkgLibAdded")}
                        </span>
                      ) : null}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
}

function PackageDialog({
  open,
  onOpenChange,
  editing,
  nextSort,
  packages,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editing: PackageDTO | null;
  nextSort: number;
  /** ROUND 89 — the platform's live plans (the smart quota engine's
   *  comparison set for the price-positioned recommendation) */
  packages: PackageDTO[];
}) {
  const { t, lang } = useT();
  /* ROUND 65 — DIRTY GUARD: an accidental overlay click / Escape / X used
     to close this 14-field form silently, discarding every edit with NO
     confirmation (the root cause behind "my plan edits never show on the
     site" — the save never actually happened). Now: overlay clicks never
     close a dirty form, Escape and the guarded X open a discard confirm. */
  const [dirty, setDirty] = useState(false);
  const [confirmDiscard, setConfirmDiscard] = useState(false);

  /* No close-reset effect needed (lint-clean): PackageForm remounts on every
     open and its mount-time dirty effect reports false, re-arming the guard;
     the discard action resets the confirm in its event handler. */

  const requestClose = () => {
    if (dirty) setConfirmDiscard(true);
    else onOpenChange(false);
  };

  return (
    <>
      <Dialog
        open={open}
        onOpenChange={(o) => {
          if (!o) requestClose();
        }}
      >
        <DialogContent
          showCloseButton={false}
          onInteractOutside={(e) => e.preventDefault()}
          onEscapeKeyDown={(e) => {
            e.preventDefault();
            requestClose();
          }}
          className="max-h-[85vh] overflow-y-auto rounded-3xl sm:max-w-2xl"
        >
          {/* guarded close (replaces the default unguarded Radix X) */}
          <button
            type="button"
            onClick={requestClose}
            aria-label={t("dlgCancel")}
            title={t("dlgCancel")}
            className="absolute end-4 top-4 z-10 grid h-8 w-8 place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 active:scale-95 dark:hover:bg-white/10 dark:hover:text-slate-200"
          >
            <CatIcon name="x" className="h-[15px] w-[15px]" />
          </button>
          <DialogHeader className="text-start">
            <DialogTitle className="pe-10 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              {t(editing ? "pkgEditTitle" : "pkgAddTitle")}
            </DialogTitle>
            <DialogDescription className="text-[13px] text-slate-500 dark:text-slate-400">
              {t(editing ? "pkgEditDesc" : "pkgAddDesc")}
            </DialogDescription>
          </DialogHeader>
          {/* Remounts on every dialog open (content unmounts while closed),
              so the form state initializes fresh from the edited plan. */}
          <PackageForm
            key={editing?.id ?? "new"}
            editing={editing}
            nextSort={nextSort}
            packages={packages}
            onDone={() => onOpenChange(false)}
            onDirtyChange={setDirty}
          />
        </DialogContent>
      </Dialog>

      {/* ROUND 65 — discard confirmation for a dirty form (only while the
          package dialog itself is open — a parent-level close can never
          strand this confirm on screen) */}
      <AlertDialog open={confirmDiscard && open} onOpenChange={setConfirmDiscard}>
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display text-lg font-extrabold text-slate-900 dark:text-white">
              {t("pkgDirtyTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] text-slate-500 dark:text-slate-400">
              {t("pkgDirtyDesc")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold">
              {t("pkgDirtyKeep")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                setConfirmDiscard(false);
                onOpenChange(false);
              }}
              className="h-10 rounded-xl bg-rose-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95"
            >
              {t("pkgDirtyDiscard")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

function PackageForm({
  editing,
  nextSort,
  packages,
  onDone,
  onDirtyChange,
}: {
  editing: PackageDTO | null;
  nextSort: number;
  /** ROUND 89 — the live platform plans (quota recommendation set) */
  packages: PackageDTO[];
  onDone: () => void;
  /** ROUND 65 — lifts the dirty flag so the dialog can guard discards */
  onDirtyChange?: (dirty: boolean) => void;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const [form, setForm] = useState<PackageFormState>(() =>
    editing ? toFormState(editing) : emptyForm(nextSort)
  );
  const [attempted, setAttempted] = useState(false);

  /* ROUND 55 — the platform's default package currency (console Settings →
     general) preselects the currency field of every NEW package. The row is
     cached by the admin session warm-up (same ["platform-settings"] key),
     so it usually resolves before the dialog even opens. DERIVED (not
     synced): the effective currency is the user's explicit choice once they
     touch the select, otherwise the live platform default — no effect, no
     cascading setState. */
  const [currencyTouched, setCurrencyTouched] = useState(false);
  const settings = useQuery({
    queryKey: ["platform-settings"],
    queryFn: fetchPlatformSettings,
    staleTime: 60_000,
  });
  const effectiveCurrency =
    editing || currencyTouched || !settings.data
      ? form.currency
      : settings.data.packageCurrency;

  /* ROUND 65 — dirty tracking: the form is dirty when ANY field drifted
     from its mount-time snapshot (or the currency select was touched on a
     NEW package — the effective currency is the platform default then).
     The snapshot is a useState value (never a ref read during render). */
  const [initialSnapshot] = useState(form);
  const onDirtyChangeRef = useRef(onDirtyChange);
  const dirty = useMemo(
    () =>
      JSON.stringify(form) !== JSON.stringify(initialSnapshot) ||
      (!editing && currencyTouched),
    [form, initialSnapshot, currencyTouched, editing]
  );
  useEffect(() => {
    onDirtyChangeRef.current?.(dirty);
  }, [dirty]);
  /* reset the parent flag on unmount (save / discard both close the dialog) */
  useEffect(
    () => () => {
      onDirtyChangeRef.current?.(false);
    },
    []
  );

  const save = useMutation({
    mutationFn: (payload: PackagePayload) =>
      editing ? updatePackage(editing.id, payload) : createPackage(payload),
    onSuccess: () => {
      toast.success(t(editing ? "pkgUpdated" : "pkgSaved"));
      queryClient.invalidateQueries({ queryKey: ["admin-packages"] });
      /* ROUND 65 — the landing pricing section, the plans comparison and the
         workspace billing view all read the PUBLIC feed: invalidate it in the
         same commit so a same-session visit shows the edit instantly. */
      queryClient.invalidateQueries({ queryKey: ["public-packages"] });
      onDone();
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  const monthlyNum = Number(form.monthly);
  const yearlyNum = Number(form.yearly);
  const pricesValid = Number.isFinite(monthlyNum) && Number.isFinite(yearlyNum);
  /* ROUND 47 — storage allowance must be a whole 0..10240 MB figure */
  const storageNum = Number(form.maxStorage);
  const storageValid =
    Number.isFinite(storageNum) &&
    Number.isInteger(storageNum) &&
    storageNum >= 0 &&
    storageNum <= 10240;
  const savings =
    pricesValid && monthlyNum > 0
      ? Math.round((1 - yearlyNum / (monthlyNum * 12)) * 100)
      : null;
  /* ROUND 79 → ROUND 80 — discounts: whole percent, 0..MAX_DISCOUNT_PCT
   * (90), each cycle independently (monthly + dedicated annual) */
  const discountNum = Number(form.discountPct);
  const discountValid =
    form.discountPct.trim() !== "" &&
    Number.isFinite(discountNum) &&
    Number.isInteger(discountNum) &&
    discountNum >= 0 &&
    discountNum <= MAX_DISCOUNT_PCT;
  const discountPct = discountValid ? discountNum : 0;
  const yearlyDiscountNum = Number(form.yearlyDiscountPct);
  const yearlyDiscountValid =
    form.yearlyDiscountPct.trim() !== "" &&
    Number.isFinite(yearlyDiscountNum) &&
    Number.isInteger(yearlyDiscountNum) &&
    yearlyDiscountNum >= 0 &&
    yearlyDiscountNum <= MAX_DISCOUNT_PCT;
  const yearlyDiscountPct = yearlyDiscountValid ? yearlyDiscountNum : 0;
  const effYearlyPct = effectiveYearlyPct({ discountPct, yearlyDiscountPct });
  const effMonthly = discountedPrice(pricesValid ? monthlyNum : 0, discountPct);
  const effYearly = discountedPrice(pricesValid ? yearlyNum : 0, effYearlyPct);
  const monthlySaving = pricesValid ? Math.max(0, monthlyNum - effMonthly) : 0;
  const yearlySaving = pricesValid ? Math.max(0, yearlyNum - effYearly) : 0;
  /* ROUND 80 — is the annual editor simply inheriting the monthly pct? */
  const yearlyInherits = yearlyDiscountPct === 0;
  /* ROUND 79 — the tier hint follows the name being typed (live) */
  const tier = standardTierOf(form.nameAr, form.nameEn);

  /* ROUND 87 — the STRICT features lints, mirrored EXACTLY from the write
   * schema: length 2..200 per line, normalized duplicates, count 3..24,
   * EN either empty (fallback) or EXACTLY matching the AR count. The strip
   * renders these live; handleSubmit refuses while any hard issue stands. */
  const arLint = useMemo(() => lintFeatureLines(form.features), [form.features]);
  const enLint = useMemo(() => {
    const base = lintFeatureLines(form.featuresEn);
    /* EN-specific soft warnings: an English line still carrying Arabic
       script is a translation left undone (never a server 400 — the owner
       sees it in amber and decides). */
    const arabicIssues: LintIssueView[] = rawFeatureLines(form.featuresEn)
      .map((line, idx): LintIssueView | null =>
        line.trim().length > 0 && ARABIC_SCRIPT.test(line)
          ? { line: idx + 1, kind: "arabic" }
          : null
      )
      .filter((x): x is LintIssueView => x !== null);
    return { ...base, issues: [...base.issues, ...arabicIssues] };
  }, [form.featuresEn]);
  /* the strict parity contract: EN empty = AR fallback; EN present must
     match AR's count exactly (the pricing page renders 1:1 bullets). */
  const enCount = enLint.count;
  const parity: { ar: number; en: number } | null =
    enCount > 0 ? { ar: arLint.count, en: enCount } : null;
  const featuresHardOk =
    arLint.valid &&
    (enCount === 0 || (enLint.valid && enCount === arLint.count));

  /** one-tap library add: appends the AR line AND the EN line together.
   *  When the EN list is empty (AR-fallback mode), entering bilingual mode
   *  needs EVERY AR line's counterpart — library matches fill them, and
   *  lines without a library match fall back to the AR text itself (the
   *  lint strip flags them amber "needs translation" — precise, strict,
   *  never silent). */
  const addBenefit = (pair: BenefitSuggestion) => {
    setForm((f) => {
      const appendLine = (raw: string, line: string) =>
        raw.trim().length === 0 ? line : `${raw.replace(/\s+$/, "")}\n${line}`;
      const arLines = rawFeatureLines(f.features).map(normalizeFeatureLine).filter(Boolean);
      const enLines = rawFeatureLines(f.featuresEn).map(normalizeFeatureLine).filter(Boolean);
      if (enLines.length === 0 && arLines.length > 0) {
        /* entering bilingual mode — mirror every existing AR line */
        const libEn = new Map<string, string>();
        for (const cat of BENEFIT_LIBRARY) {
          for (const item of cat.items) libEn.set(item.ar, item.en);
        }
        const mirrored = arLines.map((line) => libEn.get(line) ?? line);
        return {
          ...f,
          features: appendLine(f.features, pair.ar),
          featuresEn: [...mirrored, pair.en].join("\n"),
        };
      }
      return {
        ...f,
        features: appendLine(f.features, pair.ar),
        featuresEn: appendLine(f.featuresEn, pair.en),
      };
    });
  };

  /** tier preset fill — REPLACES both lists with the professional baseline
   *  (bilingual parity by construction; the dirty guard still lets the
   *  owner discard the whole dialog if the fill was a mistake). */
  const fillPreset = (key: "starter" | "professional" | "enterprise") => {
    const preset = TIER_PRESETS[key];
    setForm((f) => ({
      ...f,
      features: preset.map((p) => p.ar).join("\n"),
      featuresEn: preset.map((p) => p.en).join("\n"),
    }));
    toast.success(t("pkgLibFilled", { tier: t(TIER_LABEL[key]), n: fmtNum(preset.length, lang) }));
  };

  /* ROUND 79 — toggle one machine capability key in the form state */
  const toggleCapability = (key: PlanFeature, on: boolean) =>
    setForm((f) => ({
      ...f,
      capabilities: on
        ? f.capabilities.includes(key)
          ? f.capabilities
          : [...f.capabilities, key]
        : f.capabilities.filter((k) => k !== key),
    }));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const nameOk = form.nameAr.trim().length > 0 && form.nameEn.trim().length > 0;
    const priceOk = pricesValid && monthlyNum >= 0 && yearlyNum >= 0;
    if (!nameOk || !priceOk) {
      setAttempted(true);
      toast.error(t(nameOk ? "pkgErrPrice" : "pkgErrName"));
      return;
    }
    if (!discountValid || !yearlyDiscountValid) {
      setAttempted(true);
      toast.error(t("pkgDiscountInvalid"));
      return;
    }
    /* ROUND 87 — the STRICT features gate: refuse the submit while any
     * hard lint issue stands (length / duplicates / count / parity) —
     * the exact judgments the write schema will make, so a 400 can never
     * surprise the owner after "saving". */
    if (!featuresHardOk) {
      setAttempted(true);
      const firstHard = arLint.issues[0] ?? enLint.issues.find((i) => i.kind !== "arabic");
      if (firstHard && (firstHard.kind === "duplicate" || firstHard.text)) {
        toast.error(t("pkgErrFeatures") + (firstHard.text ? ` — ${firstHard.text}` : ""));
      } else {
        toast.error(t("pkgErrFeatures"));
      }
      return;
    }
    const users = Number(form.maxUsers);
    const mods = Number(form.maxModules);
    const sort = Number(form.sortOrder);
    save.mutate({
      nameAr: form.nameAr.trim(),
      nameEn: form.nameEn.trim(),
      descAr: form.descAr.trim(),
      descEn: form.descEn.trim(),
      priceMonthly: monthlyNum,
      priceYearly: yearlyNum,
      currency: effectiveCurrency,
      /* ROUND 87 — saved lines are normalized EXACTLY the way the server
         will (bullets stripped, whitespace collapsed) — what the lint
         previewed is what gets persisted, byte-for-byte. */
      features: arLint.lines.map(normalizeFeatureLine).filter(Boolean),
      featuresEn: enLint.lines.map(normalizeFeatureLine).filter(Boolean),
      maxUsers: Number.isFinite(users) && users >= 1 ? Math.round(users) : 1,
      maxModules: Number.isFinite(mods) && mods >= 1 ? Math.round(mods) : 1,
      /* ROUND 47 — storage allowance: whole MB, clamped to 0..10240 (the
         field is flagged invalid below; submission never sends garbage) */
      maxStorageMb:
        Number.isFinite(storageNum) && storageNum >= 0
          ? Math.min(10240, Math.round(storageNum))
          : 512,
      /* ROUND 79 → ROUND 80 — live discounts per cycle (validated above) +
       * machine capabilities (switch-driven, so every key is already
       * catalog-valid) */
      discountPct,
      yearlyDiscountPct,
      capabilities: form.capabilities,
      sortOrder: Number.isFinite(sort) ? Math.round(sort) : 0,
      popular: form.popular,
      active: form.active,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
          {/* names */}
          <div className="grid gap-3.5 sm:grid-cols-2">
            <div>
              <Label htmlFor="pkg-name-ar" className={FIELD_LABEL}>
                {t("pkgNameAr")} <span className="text-rose-500">*</span>
              </Label>
              <Input
                id="pkg-name-ar"
                value={form.nameAr}
                onChange={(e) => setForm((f) => ({ ...f, nameAr: e.target.value }))}
                className={`${FIELD_INPUT} mt-1.5`}
                aria-invalid={attempted && !form.nameAr.trim() ? true : undefined}
              />
            </div>
            <div>
              <Label htmlFor="pkg-name-en" className={FIELD_LABEL}>
                {t("pkgNameEn")} <span className="text-rose-500">*</span>
              </Label>
              <Input
                id="pkg-name-en"
                dir="ltr"
                value={form.nameEn}
                onChange={(e) => setForm((f) => ({ ...f, nameEn: e.target.value }))}
                className={`${FIELD_INPUT} mt-1.5 text-start`}
                aria-invalid={attempted && !form.nameEn.trim() ? true : undefined}
              />
            </div>
          </div>

          {/* descriptions */}
          <div className="grid gap-3.5 sm:grid-cols-2">
            <div>
              <Label htmlFor="pkg-desc-ar" className={FIELD_LABEL}>
                {t("pkgDescAr")}
              </Label>
              <Textarea
                id="pkg-desc-ar"
                rows={2}
                value={form.descAr}
                onChange={(e) => setForm((f) => ({ ...f, descAr: e.target.value }))}
                className="mt-1.5 min-h-[64px] rounded-xl border-slate-200 bg-slate-50/80 px-3.5 py-2.5 text-[13px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100"
              />
            </div>
            <div>
              <Label htmlFor="pkg-desc-en" className={FIELD_LABEL}>
                {t("pkgDescEn")}
              </Label>
              <Textarea
                id="pkg-desc-en"
                dir="ltr"
                rows={2}
                value={form.descEn}
                onChange={(e) => setForm((f) => ({ ...f, descEn: e.target.value }))}
                className="mt-1.5 min-h-[64px] rounded-xl border-slate-200 bg-slate-50/80 px-3.5 py-2.5 text-start text-[13px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100"
              />
            </div>
          </div>

          {/* prices + currency */}
          <div className="grid gap-3.5 sm:grid-cols-3">
            <div>
              <Label htmlFor="pkg-monthly" className={FIELD_LABEL}>
                {t("pkgMonthly")}
              </Label>
              <Input
                id="pkg-monthly"
                type="number"
                min={0}
                step="any"
                inputMode="decimal"
                value={form.monthly}
                onChange={(e) => setForm((f) => ({ ...f, monthly: e.target.value }))}
                className={`${FIELD_INPUT} mt-1.5`}
                aria-invalid={attempted && !(pricesValid && monthlyNum >= 0) ? true : undefined}
              />
            </div>
            <div>
              <Label htmlFor="pkg-yearly" className={FIELD_LABEL}>
                {t("pkgYearly")}
              </Label>
              <Input
                id="pkg-yearly"
                type="number"
                min={0}
                step="any"
                inputMode="decimal"
                value={form.yearly}
                onChange={(e) => setForm((f) => ({ ...f, yearly: e.target.value }))}
                className={`${FIELD_INPUT} mt-1.5`}
                aria-invalid={attempted && !(pricesValid && yearlyNum >= 0) ? true : undefined}
              />
            </div>
            <div>
              <Label htmlFor="pkg-currency" className={FIELD_LABEL}>
                {t("pkgCurrency")}
              </Label>
              <SelectCurrency
                value={effectiveCurrency}
                onChange={(currency) => {
                  setCurrencyTouched(true);
                  setForm((f) => ({ ...f, currency }));
                }}
                label={t("pkgCurrency")}
              />
            </div>
          </div>

          {/* live yearly-savings hint (soft amber warning when negative) */}
          {savings !== null ? (
            <p
              className={cn(
                "-mt-1 flex items-center gap-1.5 text-[11px] font-bold",
                savings >= 0
                  ? "text-emerald-600 dark:text-emerald-400"
                  : "text-amber-600 dark:text-amber-400"
              )}
            >
              <CatIcon
                name={savings >= 0 ? "trending-up" : "circle-alert"}
                className="h-3.5 w-3.5 shrink-0"
              />
              {t("pkgKpiYearly")}: {fmtNum(savings, lang)}%
            </p>
          ) : null}

          {/* ROUND 79 → ROUND 80 — PER-CYCLE discount editor: two independent
              rows (monthly promotion + dedicated ANNUAL promotion), each with
              preset chips + custom percent; the live preview shows every
              cycle's crossed-out base → discounted price with its own chip.
              yearly = 0 ⇒ «يتبع الشهري» (inherits the monthly promotion). */}
          <div
            className={cn(
              "rounded-2xl border p-3.5",
              attempted && (!discountValid || !yearlyDiscountValid)
                ? "border-rose-300 bg-rose-50/50 dark:border-rose-500/40 dark:bg-rose-500/[0.06]"
                : "border-emerald-200/80 bg-linear-to-br from-emerald-50/70 to-teal-50/40 dark:border-emerald-500/20 dark:from-emerald-500/[0.08] dark:to-teal-500/[0.04]"
            )}
          >
            {[
              {
                key: "monthly" as const,
                label: t("pkgDiscountMonthlyLabel"),
                chip: discountPct > 0 ? t("pkgDiscountChip", { pct: fmtNum(discountPct, lang) }) : null,
                value: form.discountPct,
                onValue: (v: string) => setForm((f) => ({ ...f, discountPct: v })),
                valid: discountValid,
                num: discountNum,
                inputId: "pkg-discount",
                inheritNote: null as string | null,
              },
              {
                key: "yearly" as const,
                label: t("pkgDiscountYearlyLabel"),
                chip: effYearlyPct > 0 ? t("pkgDiscountChipYearly", { pct: fmtNum(effYearlyPct, lang) }) : null,
                value: form.yearlyDiscountPct,
                onValue: (v: string) => setForm((f) => ({ ...f, yearlyDiscountPct: v })),
                valid: yearlyDiscountValid,
                num: yearlyDiscountNum,
                inputId: "pkg-discount-yearly",
                inheritNote: yearlyInherits ? t("pkgYearlyInherit", { pct: fmtNum(discountPct, lang) }) : null,
              },
            ].map((cycle) => (
              <div key={cycle.key} className={cycle.key === "yearly" ? "mt-3 border-t border-dashed border-emerald-200/70 pt-3 dark:border-emerald-500/20" : undefined}>
                <div className="flex flex-wrap items-center gap-2">
                  <Label htmlFor={cycle.inputId} className={FIELD_LABEL}>
                    {cycle.label}
                  </Label>
                  {cycle.chip ? (
                    <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-extrabold text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400">
                      <CatIcon name="percent" className="h-[9px] w-[9px]" />
                      {cycle.chip}
                    </span>
                  ) : null}
                  {cycle.inheritNote ? (
                    <span className="inline-flex items-center gap-1 rounded-full bg-sky-500/10 px-2 py-0.5 text-[10px] font-extrabold text-sky-600 dark:bg-sky-500/15 dark:text-sky-300">
                      <CatIcon name="link" className="h-[9px] w-[9px]" />
                      {cycle.inheritNote}
                    </span>
                  ) : null}
                  {/* custom percent input — whole number 0..90 */}
                  <div className="ms-auto flex items-center gap-1.5">
                    <Input
                      id={cycle.inputId}
                      type="number"
                      min={0}
                      max={MAX_DISCOUNT_PCT}
                      step={1}
                      inputMode="numeric"
                      dir="ltr"
                      value={cycle.value}
                      onChange={(e) => cycle.onValue(e.target.value)}
                      aria-invalid={attempted && !cycle.valid ? true : undefined}
                      aria-label={`${cycle.label} — ${t("pkgDiscountCustom")}`}
                      className="h-9 w-20 rounded-xl border-slate-200 bg-white/80 px-2.5 text-start text-[12.5px] font-extrabold tabular-nums text-slate-800 transition focus:border-emerald-400 focus:shadow-lg focus:shadow-emerald-500/15 focus:ring-4 focus:ring-emerald-500/15 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-100"
                    />
                    <span className="text-[12px] font-extrabold text-slate-400 dark:text-slate-500">
                      {lang === "ar" ? "٪" : "%"}
                    </span>
                  </div>
                </div>

                {/* preset chip row — 0% renders as «بدون تخفيض» */}
                <div className="mt-2.5 flex flex-wrap gap-1.5">
                  {DISCOUNT_PRESETS.map((preset) => {
                    const active = cycle.valid && cycle.num === preset;
                    return (
                      <button
                        key={`disc-${cycle.key}-${preset}`}
                        type="button"
                        onClick={() => cycle.onValue(String(preset))}
                        aria-pressed={active}
                        className={cn(
                          "inline-flex min-w-11 items-center justify-center gap-1 rounded-full border px-2.5 py-1.5 text-[11px] font-extrabold transition active:scale-95",
                          active
                            ? "border-emerald-400 bg-emerald-500 text-white shadow-md shadow-emerald-500/25"
                            : "border-slate-200 bg-white/70 text-slate-500 hover:border-emerald-300 hover:text-emerald-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400 dark:hover:border-emerald-500/40 dark:hover:text-emerald-300"
                        )}
                      >
                        {preset === 0 ? t("pkgDiscountNone") : `${fmtNum(preset, lang)}${lang === "ar" ? "٪" : "%"}`}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}

            {/* live preview — per-cycle crossed-out base → discounted + savings chips */}
            {(discountPct > 0 || effYearlyPct > 0) && pricesValid ? (
              <div className="mt-3 space-y-1.5 rounded-xl border border-emerald-200/60 bg-white/70 p-2.5 dark:border-emerald-500/20 dark:bg-white/[0.04]">
                {[
                  { label: t("pkgMonthly"), base: monthlyNum, eff: effMonthly, pct: discountPct, saving: monthlySaving, saveKey: "pkgDiscountSaves" as const },
                  { label: t("pkgYearly"), base: yearlyNum, eff: effYearly, pct: effYearlyPct, saving: yearlySaving, saveKey: "pkgYearlySaves" as const },
                ].map((row) => (
                  <div key={row.label}>
                    <p className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[12px]">
                      <span className="min-w-14 shrink-0 font-extrabold text-slate-500 dark:text-slate-400">
                        {row.label}
                      </span>
                      {row.pct > 0 ? (
                        <span dir="ltr" className="tabular-nums text-slate-400 line-through decoration-rose-400/80 decoration-2 dark:text-slate-500">
                          {fmtNum(row.base, lang)}
                        </span>
                      ) : null}
                      {row.pct > 0 ? (
                        <CatIcon name="arrow-left" className="h-3 w-3 shrink-0 rotate-0 text-emerald-500 rtl:rotate-180" />
                      ) : null}
                      <span dir="ltr" className="tabular-nums font-extrabold text-emerald-600 dark:text-emerald-400">
                        {fmtNum(row.eff, lang)} {effectiveCurrency}
                      </span>
                    </p>
                    {row.pct > 0 ? (
                      <p className="flex items-center gap-1.5 pt-0.5 text-[10.5px] font-bold text-emerald-600 dark:text-emerald-400">
                        <CatIcon name="piggy-bank" className="h-3.5 w-3.5 shrink-0" />
                        {t(row.saveKey, {
                          amount: fmtNum(row.saving, lang),
                          currency: effectiveCurrency,
                        })}
                      </p>
                    ) : null}
                  </div>
                ))}
              </div>
            ) : (
              <p className="mt-2.5 flex items-center gap-1.5 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                <CatIcon name="lightbulb" className="h-3 w-3 shrink-0" />
                {t("pkgDiscountHint")}
              </p>
            )}
          </div>

          {/* ROUND 89 — the SMART QUOTA EDITOR (حصة الباقة الذكية): the
              three plain number inputs are replaced by one engineered
              cockpit — a live price-positioned recommendation, tier
              presets, log-scale sliders with smart steppers, capacity
              level badges and business hints. The submit path and the
              server write schema are untouched. */}
          <PackageQuotaEditor
            users={form.maxUsers}
            modules={form.maxModules}
            storage={form.maxStorage}
            onUsersChange={(maxUsers) => setForm((f) => ({ ...f, maxUsers }))}
            onModulesChange={(maxModules) => setForm((f) => ({ ...f, maxModules }))}
            onStorageChange={(maxStorage) => setForm((f) => ({ ...f, maxStorage }))}
            packages={packages}
            editingId={editing?.id ?? null}
            priceMonthly={pricesValid ? monthlyNum : 0}
            currency={effectiveCurrency}
            attempted={attempted}
          />

          {/* sort order — kept as its own compact field */}
          <div className="grid gap-3.5 sm:grid-cols-2">
            <div>
              <Label htmlFor="pkg-sort" className={FIELD_LABEL}>
                {t("pkgSort")}
              </Label>
              <Input
                id="pkg-sort"
                type="number"
                step={1}
                inputMode="numeric"
                value={form.sortOrder}
                onChange={(e) => setForm((f) => ({ ...f, sortOrder: e.target.value }))}
                className={`${FIELD_INPUT} mt-1.5`}
              />
            </div>
            <div className="self-end">
              {/* keeps the grid rhythm even with a single field */}
              <p className="flex items-center gap-1.5 rounded-xl border border-dashed border-slate-200 px-3.5 py-2.5 text-[10.5px] font-semibold text-slate-400 dark:border-white/10 dark:text-slate-500">
                <CatIcon name="sliders" className="h-3 w-3 shrink-0 text-brand-400" />
                {t("pkgQuotaDesc")}
              </p>
            </div>
          </div>

          {/* flags */}
          <div className="grid gap-2.5 sm:grid-cols-2">
            <SwitchRow
              id="pkg-popular"
              label={t("pkgPopular")}
              icon="star"
              checked={form.popular}
              onCheckedChange={(popular) => setForm((f) => ({ ...f, popular }))}
            />
            <SwitchRow
              id="pkg-active"
              label={t("pkgActive")}
              icon="circle-check"
              checked={form.active}
              onCheckedChange={(active) => setForm((f) => ({ ...f, active }))}
            />
          </div>

          {/* features (AR + EN) — ROUND 87: the STRICT authoring experience.
              Textareas stay (power users), the LIVE LINT strip mirrors the
              server's exact verdicts under each, and the bilingual library
              card below offers one-tap professional suggestions. */}
          <div className="grid gap-3.5 sm:grid-cols-2">
            <div>
              <div className="flex items-center gap-2">
                <Label htmlFor="pkg-features" className={FIELD_LABEL}>
                  {t("pkgFeatures")}
                </Label>
                <span className="text-[10px] font-extrabold text-slate-400 dark:text-slate-500">
                  {fmtNum(arLint.count, lang)} / {fmtNum(MAX_PACKAGE_FEATURES, lang)}
                </span>
              </div>
              <Textarea
                id="pkg-features"
                rows={6}
                value={form.features}
                onChange={(e) => setForm((f) => ({ ...f, features: e.target.value }))}
                placeholder={t("pkgFeaturesPh")}
                aria-invalid={attempted && !arLint.valid ? true : undefined}
                className="mt-1.5 min-h-[120px] rounded-xl border-slate-200 bg-slate-50/80 px-3.5 py-2.5 text-[13px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100"
              />
              <FeatureLintStrip
                count={arLint.count}
                issues={arLint.issues as LintIssueView[]}
                parity={null}
                enMode={false}
                hintWhenEmpty=""
              />
              <p className="mt-1.5 flex items-center gap-1.5 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                <CatIcon name="lightbulb" className="h-3 w-3 shrink-0" />
                {t("pkgFeaturesHint")}
              </p>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <Label htmlFor="pkg-features-en" className={FIELD_LABEL}>
                  {t("pkgFeaturesEn")}
                </Label>
                <span className="text-[10px] font-extrabold text-slate-400 dark:text-slate-500">
                  {fmtNum(enLint.count, lang)}
                </span>
              </div>
              <Textarea
                id="pkg-features-en"
                dir="ltr"
                rows={6}
                value={form.featuresEn}
                onChange={(e) => setForm((f) => ({ ...f, featuresEn: e.target.value }))}
                placeholder={t("pkgFeaturesEnPh")}
                aria-invalid={
                  attempted && parity !== null && parity.ar !== parity.en ? true : undefined
                }
                className="mt-1.5 min-h-[120px] rounded-xl border-slate-200 bg-slate-50/80 px-3.5 py-2.5 text-start text-[13px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100"
              />
              <FeatureLintStrip
                count={enLint.count}
                issues={enLint.issues as LintIssueView[]}
                parity={parity}
                enMode
                hintWhenEmpty={t("pkgLintEnFallback")}
              />
              <p className="mt-1.5 flex items-center gap-1.5 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                <CatIcon name="globe" className="h-3 w-3 shrink-0" />
                {t("pkgFeaturesEnHint")}
              </p>
            </div>
          </div>

          {/* ROUND 87 — مكتبة المزايا الاحترافية: the curated bilingual
              suggestion library + the three tier presets (see the component
              doc above) */}
          <BenefitsLibraryCard
            featuresAr={form.features}
            count={arLint.count}
            onAdd={addBenefit}
            onFill={fillPreset}
            tier={tier}
          />

          {/* ROUND 79 — machine capabilities editor: grouped switch rows over
              the 8-key catalog; a standard-tier name reveals the "restore
              defaults" shortcut; a live count chip tracks the selection */}
          <div className="rounded-2xl border border-violet-200/70 bg-linear-to-br from-violet-50/50 to-fuchsia-50/30 p-3.5 dark:border-violet-500/20 dark:from-violet-500/[0.07] dark:to-fuchsia-500/[0.04]">
            <div className="flex flex-wrap items-center gap-2">
              <Label className={FIELD_LABEL}>{t("pkgCapsTitle")}</Label>
              <span className="inline-flex items-center gap-1 rounded-full bg-violet-500/10 px-2 py-0.5 text-[10px] font-extrabold text-violet-700 dark:bg-violet-500/15 dark:text-violet-300">
                <CatIcon name="sparkles" className="h-[9px] w-[9px]" />
                {t("pkgCapsCount", { n: fmtNum(form.capabilities.length, lang), total: fmtNum(PLAN_FEATURES.length, lang) })}
              </span>
              {/* standard-tier shortcut — appears when the typed name matches */}
              {tier ? (
                <button
                  type="button"
                  onClick={() =>
                    setForm((f) => ({ ...f, capabilities: [...DEFAULT_CAPABILITIES[tier]] }))
                  }
                  className="ms-auto inline-flex items-center gap-1.5 rounded-full border border-violet-300/70 bg-white/80 px-2.5 py-1.5 text-[10.5px] font-extrabold text-violet-700 transition hover:border-violet-400 hover:bg-violet-500/10 active:scale-95 dark:border-violet-500/30 dark:bg-white/[0.05] dark:text-violet-300 dark:hover:border-violet-400/60"
                >
                  <CatIcon name="rotate-ccw" className="h-3 w-3" />
                  {t("pkgCapsResetTier", { tier: t(TIER_LABEL[tier]) })}
                </button>
              ) : null}
            </div>
            <p className="mt-1.5 text-[10.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
              {t("pkgCapsSub")}
            </p>

            {/* grouped switch rows */}
            <div className="mt-3 space-y-3">
              {FEATURE_GROUPS.map((group) => {
                const groupKeys = PLAN_FEATURES.filter(
                  (key) => FEATURE_META[key].group === group.key
                );
                return (
                  <div key={`grp-${group.key}`}>
                    <p className="mb-1.5 text-[10px] font-extrabold uppercase tracking-wider text-violet-500/80 dark:text-violet-300/70">
                      {t(group.labelKey)}
                    </p>
                    <div className="space-y-1.5">
                      {groupKeys.map((key) => {
                        const meta = FEATURE_META[key];
                        const on = form.capabilities.includes(key);
                        return (
                          <div
                            key={`cap-${key}`}
                            className={cn(
                              "flex items-start justify-between gap-3 rounded-xl border px-3 py-2.5 transition",
                              on
                                ? "border-violet-300/60 bg-white/80 dark:border-violet-500/30 dark:bg-white/[0.05]"
                                : "border-slate-200/80 bg-slate-50/50 dark:border-white/10 dark:bg-white/[0.02]"
                            )}
                          >
                            <Label
                              htmlFor={`cap-${key}`}
                              className="flex cursor-pointer items-start gap-2.5 text-start"
                            >
                              <span
                                className={cn(
                                  "grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white transition",
                                  on ? "shadow-md" : "opacity-45 saturate-50"
                                )}
                                style={{ backgroundImage: grad("#8b5cf6", "#d946ef") }}
                                aria-hidden="true"
                              >
                                <CatIcon name={featIcon(meta.icon)} className="h-[13px] w-[13px]" />
                              </span>
                              <span className="min-w-0">
                                <span className="block text-[12.5px] font-bold leading-snug text-slate-700 dark:text-slate-200">
                                  {t(meta.labelKey)}
                                </span>
                                <span className="mt-0.5 block text-[10.5px] font-semibold leading-snug text-slate-400 dark:text-slate-500">
                                  {t(meta.descKey)}
                                </span>
                              </span>
                            </Label>
                            <Switch
                              id={`cap-${key}`}
                              checked={on}
                              onCheckedChange={(v) => toggleCapability(key, v)}
                              aria-label={t(meta.labelKey)}
                              className="mt-1 shrink-0"
                            />
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
            <p className="mt-2.5 flex items-center gap-1.5 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
              <CatIcon name="info" className="h-3 w-3 shrink-0" />
              {t("pkgCapsHint")}
            </p>
          </div>

          <DialogFooter className="gap-2 pt-1">
            <DialogClose asChild>
              <Button
                type="button"
                variant="outline"
                disabled={save.isPending}
                className="h-10 rounded-xl border-slate-200 px-5 text-[12.5px] font-bold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:text-slate-300"
              >
                {t("dlgCancel")}
              </Button>
            </DialogClose>
            <Button
              type="submit"
              disabled={save.isPending}
              className="h-10 gap-2 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
            >
              {save.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name="save" className="h-4 w-4" />
              )}
              {t(editing ? "pkgUpdateBtn" : "pkgAddBtn")}
            </Button>
          </DialogFooter>
    </form>
  );
}

/* ---------------- currency select ---------------- */

function SelectCurrency({
  value,
  onChange,
  label,
}: {
  value: string;
  onChange: (currency: string) => void;
  label: string;
}) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger id="pkg-currency" aria-label={label} className={`${FIELD_INPUT} mt-1.5`}>
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {CURRENCIES.map((c) => (
          <SelectItem key={c} value={c}>
            {c}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

/* ---------------- main view ---------------- */

export function AdminPackages() {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  /* round 29 — plan editing is super/admin (server-enforced); assigning
     plans to subscribers stays open to every admin role */
  const canManage = useAdminCanManage();

  const [filter, setFilter] = useState<PkgFilter>("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<PackageDTO | null>(null);
  const [pendingDelete, setPendingDelete] = useState<string | null>(null);
  const [assignTarget, setAssignTarget] = useState<PackageDTO | null>(null);

  const query = useQuery({ queryKey: ["admin-packages"], queryFn: fetchPackages });

  /* live instances — powers the assign-count chips + the assign dialog */
  const instancesQuery = useQuery({
    queryKey: ["instances"],
    queryFn: fetchInstances,
    staleTime: 30_000,
  });

  const assignCounts = useMemo(() => {
    const counts = new Map<string, number>();
    for (const inst of instancesQuery.data ?? []) {
      if (inst.package) counts.set(inst.package.id, (counts.get(inst.package.id) ?? 0) + 1);
    }
    return counts;
  }, [instancesQuery.data]);

  const packages = useMemo(
    () =>
      [...(query.data ?? [])].sort(
        (a, b) => a.sortOrder - b.sortOrder || a.createdAt.localeCompare(b.createdAt)
      ),
    [query.data]
  );

  const stats = useMemo(() => {
    const active = packages.filter((p) => p.active);
    const popular = packages.find((p) => p.popular) ?? null;
    const avgPrice =
      active.length > 0 ? active.reduce((s, p) => s + p.priceMonthly, 0) / active.length : null;
    const withMonthly = packages.filter((p) => p.priceMonthly > 0);
    const savings =
      withMonthly.length > 0
        ? Math.round(
            withMonthly.reduce((s, p) => s + (1 - p.priceYearly / (p.priceMonthly * 12)) * 100, 0) /
              withMonthly.length
          )
        : null;
    const currency =
      active.length > 0 && active.every((p) => p.currency === active[0].currency)
        ? active[0].currency
        : null;
    return {
      activeCount: active.length,
      popularCount: packages.filter((p) => p.popular).length,
      popular,
      avgPrice,
      savings,
      currency,
    };
  }, [packages]);

  const visible = useMemo(
    () =>
      packages.filter((p) =>
        filter === "all" ? true : filter === "active" ? p.active : p.popular
      ),
    [packages, filter]
  );

  const remove = useMutation({
    mutationFn: (id: string) => deletePackage(id),
    onSuccess: () => {
      toast.success(t("pkgRemoved"));
      queryClient.invalidateQueries({ queryKey: ["admin-packages"] });
      /* ROUND 65 — keep the landing pricing + comparison + billing views in
         sync with deletions in the same SPA session */
      queryClient.invalidateQueries({ queryKey: ["public-packages"] });
      setPendingDelete(null);
    },
    onError: (error: Error) => toast.error(`${t("errorText")}: ${error.message}`),
  });

  const openAdd = () => {
    setEditing(null);
    setDialogOpen(true);
  };

  const openEdit = (pkg: PackageDTO) => {
    setEditing(pkg);
    setDialogOpen(true);
  };

  const nextSort =
    packages.length > 0 ? Math.max(...packages.map((p) => p.sortOrder)) + 1 : 1;

  const pending = query.isPending;
  const kpiValue = (node: React.ReactNode, fallback = "—") => (pending ? <Skeleton className="h-8 w-16" /> : node ?? fallback);

  const tabs: { value: PkgFilter; label: string; count: number }[] = [
    { value: "all", label: t("supFilterAll"), count: packages.length },
    { value: "active", label: t("pkgActive"), count: stats.activeCount },
    { value: "popular", label: t("pkgPopularBadge"), count: stats.popularCount },
  ];

  return (
    <div className="space-y-5">
      <ViewHeading title={t("pkgTitle")} desc={t("pkgDesc")} />

      {/* KPI cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard
          index={0}
          label={t("pkgKpiActive")}
          value={kpiValue(fmtNum(stats.activeCount, lang), "0")}
          icon="circle-check"
          c1="#10b981"
          c2="#059669"
        />
        <KpiCard
          index={1}
          label={t("pkgKpiPopular")}
          value={kpiValue(fmtNum(stats.popularCount, lang), "0")}
          sub={
            stats.popular
              ? lang === "ar"
                ? stats.popular.nameAr
                : stats.popular.nameEn
              : undefined
          }
          icon="crown"
          c1="#f59e0b"
          c2="#d97706"
        />
        <KpiCard
          index={2}
          label={t("pkgKpiAvgPrice")}
          value={kpiValue(
            stats.avgPrice !== null
              ? `${fmtNum(Math.round(stats.avgPrice), lang)}${stats.currency ? ` ${stats.currency}` : ""}`
              : "—"
          )}
          icon="banknote"
          c1="#06b6d4"
          c2="#0891b2"
        />
        <KpiCard
          index={3}
          label={t("pkgKpiYearly")}
          value={kpiValue(stats.savings !== null ? `${fmtNum(stats.savings, lang)}%` : "—")}
          icon="percent"
          c1="#d946ef"
          c2="#c026d3"
        />
      </div>

      {/* plans */}
      <section className="glass-card card-in rounded-3xl p-4 sm:p-5" style={{ "--i": 4 } as React.CSSProperties}>
        {/* filter tabs + add */}
        <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <Tabs value={filter} onValueChange={(v) => setFilter(v as PkgFilter)}>
            <TabsList className="h-10 gap-1 rounded-2xl border border-slate-200/80 bg-white/70 p-1 dark:border-white/10 dark:bg-white/[0.04]">
              {tabs.map((tab) => (
                <TabsTrigger
                  key={tab.value}
                  value={tab.value}
                  className="h-8 gap-1.5 rounded-xl px-3.5 text-[12px] font-extrabold text-slate-500 transition data-[state=active]:bg-linear-to-br data-[state=active]:from-brand-500 data-[state=active]:to-fuchsia-500 data-[state=active]:text-white data-[state=active]:shadow-lg dark:text-slate-400 dark:data-[state=active]:text-white"
                >
                  {tab.label}
                  <span className="rounded-full bg-slate-900/10 px-1.5 py-px text-[11px] font-extrabold tabular-nums dark:bg-white/15">
                    {fmtNum(tab.count, lang)}
                  </span>
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
          {canManage ? (
            <Button
              type="button"
              onClick={openAdd}
              className="h-10 w-full gap-1.5 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-4 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95 sm:w-auto"
            >
              <CatIcon name="plus" className="h-4 w-4" />
              {t("pkgAddBtn")}
            </Button>
          ) : (
            <span
              title={t("adminNoPerm")}
              className="inline-flex h-10 w-full items-center justify-center gap-1.5 rounded-xl border border-dashed border-slate-300 px-4 text-[11px] font-bold text-slate-400 sm:w-auto dark:border-white/15 dark:text-slate-500"
            >
              <CatIcon name="lock" className="h-3.5 w-3.5" />
              <span className="truncate">{t("adminNoPerm")}</span>
            </span>
          )}
        </div>

        {pending ? (
          <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-[21rem] w-full rounded-3xl" />
            ))}
          </div>
        ) : query.isError ? (
          <div className="py-14 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-rose-100 text-rose-500 dark:bg-rose-500/10 dark:text-rose-400">
              <CatIcon name="circle-alert" className="h-6 w-6" />
            </div>
            <p className="mt-3 font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("errorText")}
            </p>
            <Button
              type="button"
              variant="outline"
              onClick={() => query.refetch()}
              className="mt-4 h-10 gap-1.5 rounded-xl border-slate-200 px-5 text-[12.5px] font-bold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:text-slate-300"
            >
              <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
              {t("retryText")}
            </Button>
          </div>
        ) : visible.length === 0 ? (
          <div className="py-14 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
              <CatIcon name="package" className="h-6 w-6" />
            </div>
            <p className="mt-3 font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("pkgEmpty")}
            </p>
            <p className="mx-auto mt-1 max-w-sm text-[12px] font-semibold text-slate-400 dark:text-slate-500">
              {t("pkgEmptyDesc")}
            </p>
            {canManage ? (
              <Button
                type="button"
                onClick={openAdd}
                className="mt-5 h-10 gap-1.5 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
              >
                <CatIcon name="plus" className="h-4 w-4" />
                {t("pkgAddBtn")}
              </Button>
            ) : null}
          </div>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
            {visible.map((pkg, i) => (
              <PlanCard
                key={pkg.id}
                pkg={pkg}
                index={i}
                assignCount={instancesQuery.isPending ? undefined : (assignCounts.get(pkg.id) ?? 0)}
                canManage={canManage}
                onEdit={openEdit}
                onDelete={setPendingDelete}
                onAssign={setAssignTarget}
              />
            ))}
          </div>
        )}
      </section>

      {/* add / edit dialog */}
      <PackageDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        editing={editing}
        nextSort={nextSort}
        packages={packages}
      />

      {/* assign-to-subscriber dialog — mounted per open for fresh state */}
      {assignTarget ? (
        <AssignPlanDialog
          key={assignTarget.id}
          pkg={assignTarget}
          onClose={() => setAssignTarget(null)}
        />
      ) : null}

      {/* delete confirm */}
      <AlertDialog
        open={pendingDelete !== null}
        onOpenChange={(o) => !o && setPendingDelete(null)}
      >
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display text-lg font-extrabold text-slate-900 dark:text-white">
              {t("pkgDeleteTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] text-slate-500 dark:text-slate-400">
              {t("pkgDeleteMsg")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel
              className="h-10 rounded-xl px-5 text-[12.5px] font-bold"
              disabled={remove.isPending}
            >
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => pendingDelete && remove.mutate(pendingDelete)}
              disabled={remove.isPending}
              className="h-10 rounded-xl bg-rose-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60"
            >
              {remove.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : null}
              {t("pkgDeleteConfirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default AdminPackages;
