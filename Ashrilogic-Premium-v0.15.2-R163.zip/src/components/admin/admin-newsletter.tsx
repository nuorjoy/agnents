"use client";

/**
 * Ashrilogic — admin newsletter view (full management + moderation).
 *
 * Round 22: listing + bulk-add + retag + delete.
 * Round 26 (premium): full row-level moderation —
 *  - status badges (active / banned / restricted) with explanatory tooltips
 *  - "edit details" dialog (email + tag in one place)
 *  - ban / restrict / reactivate behind descriptive confirm dialogs
 *  - moderation KPI strip (total · active · banned · restricted)
 *  - status filter chips beside the tag chips
 *  - Arabic-first typography (no letter-spacing on Arabic labels, LTR emails
 *    end-aligned inside the RTL reading flow)
 * Round 29: dynamic newsletter emails — a DB-driven list of inboxes
 * ("بريد النشرة البريدية") managed add/edit/delete from a premium card at
 * the top of the view with ZERO code edits at runtime, plus viewer-role
 * gating on every mutation control (enforcement stays server-side).
 * All flows through the admin-guarded /api/admin/newsletter endpoint.
 */
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { fetchPlatformSettings, updatePlatformSettings, fetchAdminCampaigns, createAdminCampaign, updateAdminCampaign, sendAdminCampaign, deleteAdminCampaign } from "@/lib/api-client";
import { useAdminCanManage } from "@/lib/admin-auth";
import { useT } from "@/lib/i18n";
import type { CampaignDTO, NewsletterEmailSetting, NewsletterSubscriberDTO, SubscriberStatus } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, labelTrack } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { EMAIL_RE } from "@/lib/validation";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  DashCard,
  IconTile,
  ViewHeading,
  fullDate,
  relativeTime,
} from "@/components/dashboard/dash-shared";

type Subscriber = NewsletterSubscriberDTO;

interface NewsletterResponse {
  count: number;
  filtered: number;
  tags: string[];
  subscribers: Subscriber[];
}

interface AddResult {
  ok: boolean;
  added: number;
  skipped: number;
  invalid: string[];
  count: number;
}


/* ---------------- round 29: dynamic newsletter emails ---------------- */

/** server-side cap (settingsUpdateSchema) — mirrored for the UI hint */
const NEWS_EMAIL_MAX = 10;

/** themed mail-tile gradients cycling across the rows */
const NEWS_EMAIL_TILE = [
  { c1: "#6d5dfb", c2: "#d946ef" },
  { c1: "#0ea5e9", c2: "#6366f1" },
  { c1: "#10b981", c2: "#059669" },
  { c1: "#f59e0b", c2: "#d97706" },
  { c1: "#f43f5e", c2: "#e11d48" },
  { c1: "#06b6d4", c2: "#0891b2" },
] as const;

/* Live parse of the multi-email textarea: valid / invalid / duplicate-in-batch */
function parseDraft(raw: string): { valid: string[]; invalid: string[] } {
  const tokens = raw
    .split(/[\n\r,;\s]+/)
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean);
  const seen = new Set<string>();
  const valid: string[] = [];
  const invalid: string[] = [];
  for (const token of tokens) {
    if (seen.has(token)) continue;
    seen.add(token);
    if (EMAIL_RE.test(token)) valid.push(token);
    else invalid.push(token);
  }
  return { valid, invalid };
}

/* ---------------- status vocabulary ---------------- */

const STATUS_STYLE: Record<SubscriberStatus, { border: string; dot: string; icon: string }> = {
  active: {
    border: "border-emerald-400/60 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300",
    dot: "bg-emerald-500",
    icon: "circle-check",
  },
  banned: {
    border: "border-rose-400/60 bg-rose-500/10 text-rose-600 dark:border-rose-500/40 dark:text-rose-300",
    dot: "bg-rose-500",
    icon: "ban",
  },
  restricted: {
    border: "border-amber-400/60 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-400",
    dot: "bg-amber-500",
    icon: "shield-alert",
  },
};

const STATUS_KEY: Record<SubscriberStatus, "adminNewsStatusActive" | "adminNewsStatusBanned" | "adminNewsStatusRestricted"> = {
  active: "adminNewsStatusActive",
  banned: "adminNewsStatusBanned",
  restricted: "adminNewsStatusRestricted",
};

const STATUS_HINT_KEY: Record<
  SubscriberStatus,
  "adminNewsStatusActiveHint" | "adminNewsStatusBannedHint" | "adminNewsStatusRestrictedHint"
> = {
  active: "adminNewsStatusActiveHint",
  banned: "adminNewsStatusBannedHint",
  restricted: "adminNewsStatusRestrictedHint",
};

function StatusBadge({ status }: { status: SubscriberStatus }) {
  const { t } = useT();
  const style = STATUS_STYLE[status];
  return (
    <span
      title={t(STATUS_HINT_KEY[status])}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10.5px] font-extrabold",
        style.border
      )}
    >
      <CatIcon name={style.icon} className="h-[11px] w-[11px]" />
      {t(STATUS_KEY[status])}
    </span>
  );
}

/**
 * Round 29 — the DB-driven newsletter email list ("بريد النشرة البريدية").
 * Every mutation (add / edit / delete) PATCHes the WHOLE array through
 * updatePlatformSettings({ newsletterEmails }) — no code edits at runtime.
 * Add/edit share one small dialog; delete sits behind a count-aware
 * bilingual AlertDialog. Read-only for roles below admin.
 */
function NewsletterEmailsCard() {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const canManage = useAdminCanManage();

  const [dialog, setDialog] = useState<{ mode: "create" } | { mode: "edit"; index: number } | null>(null);
  const [formEmail, setFormEmail] = useState("");
  const [formLabel, setFormLabel] = useState("");
  const [emailInvalid, setEmailInvalid] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<NewsletterEmailSetting | null>(null);

  const query = useQuery({
    queryKey: ["platform-settings"],
    queryFn: fetchPlatformSettings,
    staleTime: 60_000,
  });

  const emails = useMemo(() => query.data?.newsletterEmails ?? [], [query.data]);
  const editing = dialog?.mode === "edit" ? dialog : null;

  const save = useMutation({
    mutationFn: (next: NewsletterEmailSetting[]) => updatePlatformSettings({ newsletterEmails: next }),
    onSuccess: () => {
      toast.success(t("newsEmailsSaved"));
      setDialog(null);
      setPendingDelete(null);
      queryClient.invalidateQueries({ queryKey: ["platform-settings"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const openCreate = () => {
    if (emails.length >= NEWS_EMAIL_MAX) return;
    setFormEmail("");
    setFormLabel("");
    setEmailInvalid(false);
    setDialog({ mode: "create" });
  };

  const openEdit = (index: number) => {
    setFormEmail(emails[index]?.email ?? "");
    setFormLabel(emails[index]?.label ?? "");
    setEmailInvalid(false);
    setDialog({ mode: "edit", index });
  };

  const submit = () => {
    const email = formEmail.trim().toLowerCase();
    if (!EMAIL_RE.test(email)) {
      setEmailInvalid(true);
      toast.error(t("newsEmailsErrEmail"));
      return;
    }
    const duplicate = emails.some(
      (row, i) => row.email.toLowerCase() === email && !(editing !== null && editing.index === i)
    );
    if (duplicate) {
      toast.error(t("newsEmailsErrDup"));
      return;
    }
    const entry: NewsletterEmailSetting = { email, label: formLabel.trim().slice(0, 60) };
    const next = editing !== null ? emails.map((row, i) => (i === editing.index ? entry : row)) : [...emails, entry];
    save.mutate(next);
  };

  const removeEmail = (target: NewsletterEmailSetting) => {
    save.mutate(emails.filter((row) => row.email !== target.email));
  };

  const full = emails.length >= NEWS_EMAIL_MAX;

  return (
    <DashCard>
      {/* header — identity tile + description + count chip + add button */}
      <div className="flex flex-wrap items-center gap-4">
        <IconTile icon="mail" c1="#0ea5e9" c2="#6366f1" size="lg" />
        <div className="min-w-0 flex-1">
          <p className="font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
            {t("newsEmailsTitle")}
          </p>
          <p className="mt-0.5 max-w-xl text-[11.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            {t("newsEmailsDesc")}
          </p>
        </div>
        <span
          dir="ltr"
          title={t("newsEmailsMax", { max: fmtNum(NEWS_EMAIL_MAX, lang) })}
          className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-sky-200 bg-sky-500/10 px-3 py-1 text-[11px] font-extrabold tabular-nums text-sky-600 dark:border-sky-500/30 dark:text-sky-300"
        >
          <CatIcon name="inbox" className="h-[11px] w-[11px]" />
          {fmtNum(emails.length, lang)} / {fmtNum(NEWS_EMAIL_MAX, lang)}
        </span>
        {canManage ? (
          <Button
            type="button"
            size="sm"
            onClick={openCreate}
            disabled={full || save.isPending}
            title={full ? t("newsEmailsMax", { max: fmtNum(NEWS_EMAIL_MAX, lang) }) : undefined}
            className="h-9 gap-1.5 rounded-lg bg-linear-to-l from-sky-600 to-indigo-500 px-3 text-[11px] font-extrabold text-white shadow-lg shadow-sky-500/25 transition hover:brightness-110 active:scale-95"
          >
            <CatIcon name="plus" className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">{t("newsEmailsAdd")}</span>
          </Button>
        ) : null}
      </div>

      {/* rows / states */}
      {query.isPending ? (
        <div className="mt-4 space-y-2.5">
          {Array.from({ length: 2 }).map((_, i) => (
            <Skeleton key={i} className="h-11 w-full rounded-xl" />
          ))}
        </div>
      ) : query.isError ? (
        <div className="mt-4 flex flex-wrap items-center gap-2.5 rounded-xl border border-rose-200 bg-rose-50/60 px-3.5 py-3 dark:border-rose-500/25 dark:bg-rose-500/10">
          <CatIcon name="circle-alert" className="h-4 w-4 shrink-0 text-rose-500 dark:text-rose-400" />
          <p className="min-w-0 flex-1 truncate text-[12px] font-bold text-rose-600 dark:text-rose-300">{t("errorText")}</p>
          <Button type="button" variant="outline" size="sm" onClick={() => query.refetch()} className="h-8 rounded-lg px-3 text-[11px] font-bold">
            <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
            {t("retryText")}
          </Button>
        </div>
      ) : emails.length === 0 ? (
        <div className="mt-4 rounded-2xl border border-dashed border-slate-300/80 bg-slate-50/50 px-4 py-8 text-center dark:border-white/15 dark:bg-white/[0.02]">
          <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-sky-500/10 text-sky-500 dark:text-sky-300">
            <CatIcon name="inbox" className="h-5 w-5" />
          </div>
          <p className="mt-2.5 font-display text-[13.5px] font-extrabold text-slate-700 dark:text-slate-200">
            {t("newsEmailsTitle")}
          </p>
          <p className="mx-auto mt-1 max-w-sm text-[11.5px] font-semibold text-slate-400 dark:text-slate-500">
            {t("newsEmailsEmpty")}
          </p>
          {canManage ? (
            <Button
              type="button"
              size="sm"
              onClick={openCreate}
              className="mt-4 h-9 gap-1.5 rounded-xl bg-linear-to-l from-sky-600 to-indigo-500 px-4 text-[11.5px] font-extrabold text-white shadow-lg shadow-sky-500/25"
            >
              <CatIcon name="plus" className="h-3.5 w-3.5" />
              {t("newsEmailsAdd")}
            </Button>
          ) : null}
        </div>
      ) : (
        <ul className="mt-4 divide-y divide-slate-100 dark:divide-white/[0.05]">
          {emails.map((row, i) => {
            const tile = NEWS_EMAIL_TILE[i % NEWS_EMAIL_TILE.length];
            return (
              <li
                key={row.email}
                className="flex flex-wrap items-center gap-x-3 gap-y-1.5 rounded-xl px-1.5 py-2.5 transition hover:bg-slate-50/70 dark:hover:bg-white/[0.03]"
              >
                <span
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-sm"
                  style={{ backgroundImage: grad(tile.c1, tile.c2) }}
                  aria-hidden="true"
                >
                  <CatIcon name="mail" className="h-[14px] w-[14px]" />
                </span>
                <span
                  dir="ltr"
                  className={cn(
                    "min-w-0 flex-1 truncate font-mono text-[12.5px] font-bold text-slate-700 dark:text-slate-200",
                    lang === "ar" ? "text-end" : "text-start"
                  )}
                >
                  {row.email}
                </span>
                {row.label ? (
                  <span
                    title={row.label}
                    className="inline-flex max-w-[170px] shrink-0 items-center gap-1 truncate rounded-full border border-fuchsia-200 bg-fuchsia-500/10 px-2.5 py-1 text-[10.5px] font-extrabold text-fuchsia-600 dark:border-fuchsia-500/30 dark:text-fuchsia-300"
                  >
                    <CatIcon name="tag" className="h-[10px] w-[10px] shrink-0" />
                    <span className="truncate">{row.label}</span>
                  </span>
                ) : null}
                {canManage ? (
                  <span className="flex shrink-0 items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => openEdit(i)}
                      aria-label={`${t("newsEmailsEdit")} — ${row.email}`}
                      title={t("newsEmailsEdit")}
                      className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:text-slate-300"
                    >
                      <CatIcon name="pencil" className="h-[13px] w-[13px]" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setPendingDelete(row)}
                      aria-label={`${t("newsEmailsDelete")} — ${row.email}`}
                      title={t("newsEmailsDelete")}
                      className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-rose-300 hover:text-rose-600 active:scale-95 dark:border-white/10 dark:text-slate-300 dark:hover:border-rose-400/50 dark:hover:text-rose-300"
                    >
                      <CatIcon name="trash-2" className="h-[13px] w-[13px]" />
                    </button>
                  </span>
                ) : null}
              </li>
            );
          })}
        </ul>
      )}

      {/* add / edit dialog (shared) */}
      <Dialog open={dialog !== null} onOpenChange={(o) => !o && setDialog(null)}>
        <DialogContent className="rounded-3xl sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2.5 font-display text-[16px] font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-linear-to-br from-sky-500 to-indigo-500 text-white"
                aria-hidden="true"
              >
                <CatIcon name={editing !== null ? "pencil" : "plus"} className="h-[13px] w-[13px]" />
              </span>
              {editing !== null ? t("newsEmailsEdit") : t("newsEmailsAdd")}
            </DialogTitle>
            <DialogDescription className="text-[12px] text-slate-500 dark:text-slate-400">
              {t("newsEmailsDesc")}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3.5">
            <div className="space-y-1.5">
              <Label htmlFor="news-email-field" className="text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                {t("newsEmailsEmail")} <span className="text-rose-500">*</span>
              </Label>
              <div className="relative">
                <CatIcon
                  name="mail"
                  className="pointer-events-none absolute start-3.5 top-1/2 h-[14px] w-[14px] -translate-y-1/2 text-slate-400"
                />
                <Input
                  id="news-email-field"
                  type="email"
                  dir="ltr"
                  value={formEmail}
                  onChange={(e) => {
                    setFormEmail(e.target.value);
                    setEmailInvalid(false);
                  }}
                  placeholder="name@example.com"
                  maxLength={160}
                  autoFocus
                  aria-invalid={emailInvalid || undefined}
                  className={cn(
                    "h-11 rounded-xl ps-10 text-start text-[12.5px] font-semibold",
                    emailInvalid &&
                      "border-rose-400 focus:border-rose-400 focus:ring-rose-500/15 focus:shadow-rose-500/10"
                  )}
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="news-email-label" className="text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                {t("newsEmailsLabel")}
              </Label>
              <Input
                id="news-email-label"
                value={formLabel}
                onChange={(e) => setFormLabel(e.target.value)}
                placeholder={t("newsEmailsLabelPh")}
                maxLength={60}
                className="h-11 rounded-xl text-[12.5px] font-semibold"
              />
            </div>
            <p className="flex items-center gap-1.5 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
              <CatIcon name="inbox" className="h-3 w-3 shrink-0" />
              {t("newsEmailsMax", { max: fmtNum(NEWS_EMAIL_MAX, lang) })}
            </p>
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setDialog(null)}
              disabled={save.isPending}
              className="h-10 rounded-xl px-5 text-[12.5px] font-bold"
            >
              {t("dlgCancel")}
            </Button>
            <Button
              type="button"
              onClick={submit}
              disabled={save.isPending || formEmail.trim().length === 0}
              className="h-10 gap-2 rounded-xl bg-linear-to-l from-sky-600 to-indigo-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-sky-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-50"
            >
              <CatIcon name={save.isPending ? "refresh-cw" : "save"} className={cn("h-4 w-4", save.isPending && "animate-spin")} />
              {t("profileSave")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* delete confirm — count-aware bilingual */}
      <AlertDialog open={pendingDelete !== null} onOpenChange={(o) => !o && setPendingDelete(null)}>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-linear-to-br from-rose-500 to-rose-600 text-white shadow-lg shadow-rose-500/25"
                aria-hidden="true"
              >
                <CatIcon name="trash-2" className="h-[15px] w-[15px]" />
              </span>
              {t("newsEmailsDelete")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {pendingDelete
                ? t("newsEmailsDeleteMsg", {
                    email: pendingDelete.email,
                    count: fmtNum(emails.filter((row) => row.email !== pendingDelete.email).length, lang),
                  })
                : ""}
            </AlertDialogDescription>
          </AlertDialogHeader>
          {pendingDelete ? (
            <p
              dir="ltr"
              className="truncate rounded-xl border border-dashed border-slate-300 bg-slate-50/60 px-3.5 py-2.5 text-center font-mono text-[12px] font-bold text-slate-600 dark:border-white/15 dark:bg-white/[0.03] dark:text-slate-300"
            >
              {pendingDelete.email}
            </p>
          ) : null}
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={save.isPending}>
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => pendingDelete && removeEmail(pendingDelete)}
              disabled={save.isPending}
              className="h-10 rounded-xl bg-rose-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60"
            >
              {save.isPending ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : null}
              {t("adminDeleteConfirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashCard>
  );
}

/* ---------------- round 33: email campaigns (composer + archive) ---------------- */

/**
 * The الحملات البريدية section: campaign KPI strip, a premium composer
 * dialog (subject + body + live audience estimate + character counter), a
 * send confirm that records the audience snapshot, an email-mockup preview
 * and the full archive list (drafts editable, sent read-only — both
 * deletable as records). Super/admin manage; viewers read.
 */
function CampaignsCard() {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const canManage = useAdminCanManage();

  const query = useQuery({
    queryKey: ["admin-campaigns"],
    queryFn: fetchAdminCampaigns,
    staleTime: 30_000,
    retry: 1,
  });

  const campaigns = query.data?.campaigns ?? [];
  const audience = query.data?.audience ?? 0;

  /* composer dialog (create / edit-draft) */
  const [composer, setComposer] = useState<{ mode: "create" } | { mode: "edit"; id: string } | null>(null);
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  /* send / delete confirms + preview */
  const [confirmSend, setConfirmSend] = useState<CampaignDTO | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<CampaignDTO | null>(null);
  const [preview, setPreview] = useState<CampaignDTO | null>(null);

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["admin-campaigns"] });

  const saveDraft = useMutation({
    mutationFn: () =>
      composer?.mode === "edit"
        ? updateAdminCampaign(composer.id, { subject: subject.trim(), body: body.trim() })
        : createAdminCampaign({ subject: subject.trim(), body: body.trim() }),
    onSuccess: () => {
      toast.success(t(composer?.mode === "edit" ? "newsCampaignUpdatedToast" : "newsCampaignCreatedToast"));
      setComposer(null);
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message || t("errorText")),
  });

  const send = useMutation({
    mutationFn: (id: string) => sendAdminCampaign(id),
    onSuccess: (row) => {
      toast.success(t("newsCampaignSentToast", { n: fmtNum(row.recipients, lang) }));
      setConfirmSend(null);
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message || t("errorText")),
  });

  const remove = useMutation({
    mutationFn: (id: string) => deleteAdminCampaign(id),
    onSuccess: () => {
      toast.success(t("newsCampaignDeletedToast"));
      setConfirmDelete(null);
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message || t("errorText")),
  });

  const submit = () => {
    const s = subject.trim();
    const b = body.trim();
    if (s.length < 3 || s.length > 120) {
      toast.error(t("newsCampaignErrSubject"));
      return;
    }
    if (b.length < 10 || b.length > 5000) {
      toast.error(t("newsCampaignErrBody"));
      return;
    }
    saveDraft.mutate();
  };

  const openCreate = () => {
    setSubject("");
    setBody("");
    setComposer({ mode: "create" });
  };

  const openEdit = (c: CampaignDTO) => {
    setSubject(c.subject);
    setBody(c.body);
    setComposer({ mode: "edit", id: c.id });
  };

  const stats = {
    total: campaigns.length,
    drafts: campaigns.filter((c) => c.status === "draft").length,
    sent: campaigns.filter((c) => c.status === "sent").length,
    recipients: campaigns.reduce((sum, c) => sum + (c.status === "sent" ? c.recipients : 0), 0),
  };

  return (
    <DashCard>
      {/* header */}
      <div className="flex flex-wrap items-center gap-4">
        <IconTile icon="megaphone" c1="#0ea5e9" c2="#6d5dfb" size="lg" />
        <div className="min-w-0 flex-1">
          <h2 className="font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
            {t("newsCampaignsTitle")}
          </h2>
          <p className="mt-0.5 text-[12px] leading-relaxed text-slate-500 dark:text-slate-400">
            {t("newsCampaignsDesc")}
          </p>
        </div>
        {canManage ? (
          <Button
            type="button"
            size="sm"
            onClick={openCreate}
            className="h-9 gap-1.5 rounded-lg bg-linear-to-l from-sky-600 to-brand-500 px-3.5 text-[11px] font-extrabold text-white shadow-lg shadow-sky-500/25 transition hover:brightness-110 active:scale-95"
          >
            <CatIcon name="plus" className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">{t("newsCampaignsNew")}</span>
          </Button>
        ) : null}
      </div>

      {/* KPI strip */}
      <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
        {(
          [
            { label: t("newsCampaignKpiTotal"), value: stats.total, icon: "megaphone", c1: "#0ea5e9", c2: "#0891b2", cls: "text-sky-600 dark:text-sky-300" },
            { label: t("newsCampaignKpiDrafts"), value: stats.drafts, icon: "pencil", c1: "#f59e0b", c2: "#d97706", cls: "text-amber-600 dark:text-amber-300" },
            { label: t("newsCampaignKpiSent"), value: stats.sent, icon: "send", c1: "#10b981", c2: "#059669", cls: "text-emerald-600 dark:text-emerald-300" },
            { label: t("newsCampaignKpiRecipients"), value: stats.recipients, icon: "users", c1: "#d946ef", c2: "#c026d3", cls: "text-fuchsia-600 dark:text-fuchsia-300" },
          ] as const
        ).map((cell) => (
          <div
            key={cell.label}
            className="group flex items-center gap-2.5 rounded-xl border border-slate-200/80 bg-white/70 px-3 py-2.5 transition hover:-translate-y-0.5 hover:shadow-soft dark:border-white/10 dark:bg-white/[0.03]"
          >
            <span
              className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white shadow-sm transition-transform duration-300 group-hover:scale-105"
              style={{ backgroundImage: grad(cell.c1, cell.c2) }}
            >
              <CatIcon name={cell.icon} className="h-3.5 w-3.5" />
            </span>
            <div className="min-w-0">
              <p className={cn("truncate text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                {cell.label}
              </p>
              <p dir="ltr" className={cn("text-start font-display text-[16px] font-extrabold tabular-nums", cell.cls)}>
                {query.isPending ? "…" : fmtNum(cell.value, lang)}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* archive list */}
      <div className="mt-4">
        {query.isPending ? (
          <div className="space-y-2.5">
            {Array.from({ length: 2 }).map((_, i) => (
              <Skeleton key={i} className="h-20 w-full rounded-2xl" />
            ))}
          </div>
        ) : query.isError ? (
          <div className="rounded-2xl border border-rose-200 bg-rose-50/70 p-5 text-center text-[12.5px] font-bold text-rose-600 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-300">
            {t("errorText")}
          </div>
        ) : campaigns.length === 0 ? (
          <div className="rounded-2xl border-2 border-dashed border-slate-200 p-7 text-center dark:border-white/10">
            <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-sky-500/10 text-sky-500 dark:text-sky-300">
              <CatIcon name="megaphone" className="h-5 w-5" />
            </div>
            <p className="mt-3 font-display text-[13.5px] font-extrabold text-slate-600 dark:text-slate-300">
              {t("newsCampaignsEmpty")}
            </p>
            <p className="mx-auto mt-1 max-w-sm text-[11.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
              {t("newsCampaignsEmptyDesc")}
            </p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {campaigns.map((c) => {
              const sent = c.status === "sent";
              return (
                <article
                  key={c.id}
                  className="group rounded-2xl border border-slate-200/80 bg-white/80 p-3.5 transition hover:border-sky-300/70 hover:shadow-soft dark:border-white/[0.07] dark:bg-white/[0.03] dark:hover:border-sky-500/40"
                >
                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      className={cn(
                        "inline-flex shrink-0 items-center gap-1 rounded-full border px-2.5 py-0.5 text-[10px] font-extrabold",
                        sent
                          ? "border-emerald-400/60 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
                          : "border-amber-400/60 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-400"
                      )}
                    >
                      <CatIcon name={sent ? "send" : "pencil"} className="h-[10px] w-[10px]" />
                      {t(sent ? "newsCampaignSentBadge" : "newsCampaignDraftBadge")}
                    </span>
                    <p className="min-w-0 flex-1 truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
                      {c.subject}
                    </p>
                    <span
                      title={c.createdAt ? fullDate(c.createdAt, lang) : undefined}
                      className="shrink-0 text-[10.5px] font-bold text-slate-400 dark:text-slate-500"
                    >
                      {relativeTime(c.createdAt, lang)}
                    </span>
                  </div>

                  <p className="mt-1.5 line-clamp-2 text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                    {c.body}
                  </p>

                  <div className="mt-2.5 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-2.5 dark:border-white/[0.06]">
                    {sent ? (
                      <>
                        <span
                          title={c.sentAt ? fullDate(c.sentAt, lang) : undefined}
                          dir="ltr"
                          className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2.5 py-0.5 text-[10.5px] font-extrabold tabular-nums text-emerald-600 dark:text-emerald-300"
                        >
                          <CatIcon name="users" className="h-[10px] w-[10px]" />
                          {fmtNum(c.recipients, lang)}
                        </span>
                        <span className="text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                          {t("newsCampaignColSentAt")}: {c.sentAt ? relativeTime(c.sentAt, lang) : "—"}
                        </span>
                        {c.sentFrom ? (
                          <span
                            dir="ltr"
                            title={c.sentFrom}
                            className="hidden max-w-[220px] truncate rounded-full bg-slate-100 px-2.5 py-0.5 text-[10px] font-bold text-slate-500 sm:inline dark:bg-white/10 dark:text-slate-400"
                          >
                            <CatIcon name="mail" className="me-1 inline h-[10px] w-[10px]" />
                            {c.sentFrom}
                          </span>
                        ) : null}
                      </>
                    ) : (
                      <span className="text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                        {t("newsCampaignsDraftHint")}
                      </span>
                    )}

                    <div className="ms-auto flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setPreview(c)}
                        aria-label={`${t("newsCampaignViewBtn")} — ${c.subject}`}
                        title={t("newsCampaignViewBtn")}
                        className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-sky-300 hover:text-sky-600 active:scale-95 dark:border-white/10 dark:text-slate-300 dark:hover:border-sky-500/40 dark:hover:text-sky-300"
                      >
                        <CatIcon name="eye" className="h-[14px] w-[14px]" />
                      </button>
                      {canManage && !sent ? (
                        <>
                          <button
                            type="button"
                            onClick={() => openEdit(c)}
                            aria-label={`${t("newsCampaignEditBtn")} — ${c.subject}`}
                            title={t("newsCampaignEditBtn")}
                            className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
                          >
                            <CatIcon name="pencil" className="h-[14px] w-[14px]" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmSend(c)}
                            aria-label={`${t("newsCampaignSend")} — ${c.subject}`}
                            title={t("newsCampaignSend")}
                            className="grid h-8 w-8 place-items-center rounded-lg border border-emerald-200 text-emerald-600 transition hover:border-emerald-400 hover:bg-emerald-50 hover:text-emerald-700 active:scale-95 dark:border-emerald-500/30 dark:text-emerald-300 dark:hover:bg-emerald-500/10"
                          >
                            <CatIcon name="send" className="h-[14px] w-[14px]" />
                          </button>
                        </>
                      ) : null}
                      {canManage ? (
                        <button
                          type="button"
                          onClick={() => setConfirmDelete(c)}
                          aria-label={`${t("newsCampaignDeleteBtn")} — ${c.subject}`}
                          title={t("newsCampaignDeleteBtn")}
                          className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-rose-300 hover:bg-rose-50 hover:text-rose-600 active:scale-95 dark:border-white/10 dark:text-slate-300 dark:hover:border-rose-500/40 dark:hover:bg-rose-500/10 dark:hover:text-rose-300"
                        >
                          <CatIcon name="trash" className="h-[14px] w-[14px]" />
                        </button>
                      ) : null}
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>

      {/* ---------------- composer dialog (create / edit draft) ---------------- */}
      <Dialog open={composer !== null} onOpenChange={(o) => !o && setComposer(null)}>
        <DialogContent className="max-w-lg rounded-3xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-8 w-8 place-items-center rounded-xl text-white"
                style={{ backgroundImage: grad("#0ea5e9", "#6d5dfb") }}
              >
                <CatIcon name={composer?.mode === "edit" ? "pencil" : "megaphone"} className="h-4 w-4" />
              </span>
              {t(composer?.mode === "edit" ? "newsCampaignComposerEditTitle" : "newsCampaignComposerTitle")}
            </DialogTitle>
            <DialogDescription className="text-[12.5px] leading-relaxed">
              {t("newsCampaignsDraftHint")}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="campaign-subject" className="text-[12px] font-bold">
                {t("newsCampaignSubject")}
              </Label>
              <Input
                id="campaign-subject"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder={t("newsCampaignSubjectPh")}
                maxLength={120}
                className="h-10 rounded-xl text-[13px] font-semibold"
              />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label htmlFor="campaign-body" className="text-[12px] font-bold">
                  {t("newsCampaignBody")}
                </Label>
                <span dir="ltr" className="font-mono text-[10px] font-bold tabular-nums text-slate-400 dark:text-slate-500">
                  {t("newsCampaignChars", { n: fmtNum(body.length, lang) })} / ٥٬٠٠٠
                </span>
              </div>
              <Textarea
                id="campaign-body"
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder={t("newsCampaignBodyPh")}
                maxLength={5000}
                rows={7}
                className="rounded-xl text-[13px] leading-relaxed"
              />
            </div>
            <p className="flex items-center gap-2 rounded-xl border border-sky-200/70 bg-sky-500/[0.06] px-3 py-2 text-[11.5px] font-bold text-sky-700 dark:border-sky-500/30 dark:bg-sky-500/10 dark:text-sky-300">
              <CatIcon name="users" className="h-3.5 w-3.5 shrink-0" />
              {t("newsCampaignAudience", { n: fmtNum(audience, lang) })}
            </p>
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setComposer(null)}
              disabled={saveDraft.isPending}
              className="h-10 rounded-xl px-4 text-[12px] font-bold"
            >
              {t("newsCampaignCancelBtn")}
            </Button>
            <Button
              type="button"
              onClick={submit}
              disabled={saveDraft.isPending}
              className="h-10 gap-2 rounded-xl bg-linear-to-l from-sky-600 to-brand-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-sky-500/25 transition hover:brightness-110 active:scale-95"
            >
              <CatIcon
                name={saveDraft.isPending ? "refresh-cw" : composer?.mode === "edit" ? "check" : "plus"}
                className={cn("h-4 w-4", saveDraft.isPending && "animate-spin")}
              />
              {t(composer?.mode === "edit" ? "newsCampaignUpdateBtn" : "newsCampaignCreateBtn")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ---------------- preview dialog (email mockup) ---------------- */}
      <Dialog open={preview !== null} onOpenChange={(o) => !o && setPreview(null)}>
        <DialogContent className="max-w-lg rounded-3xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-8 w-8 place-items-center rounded-xl text-white"
                style={{ backgroundImage: grad("#0ea5e9", "#0891b2") }}
              >
                <CatIcon name="eye" className="h-4 w-4" />
              </span>
              {t("newsCampaignViewTitle")}
            </DialogTitle>
          </DialogHeader>

          {preview ? (
            <div className="overflow-hidden rounded-2xl border border-slate-200 dark:border-white/10">
              {/* email header strip */}
              <div className="space-y-1.5 border-b border-slate-200 bg-slate-50/80 px-4 py-3 dark:border-white/10 dark:bg-white/[0.04]">
                <div className="flex flex-wrap items-center gap-1.5 text-[11px] font-bold text-slate-500 dark:text-slate-400">
                  <CatIcon name="mail" className="h-3 w-3 text-slate-400" />
                  {t("newsCampaignViewFrom")}:
                  <span dir="ltr" className="truncate font-mono text-slate-700 dark:text-slate-200">
                    {preview.sentFrom || "newsletter@ashrilogic.com"}
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-1.5 text-[11px] font-bold text-slate-500 dark:text-slate-400">
                  <CatIcon name="users" className="h-3 w-3 text-slate-400" />
                  {t("newsCampaignViewTo")}:
                  <span className="text-slate-700 dark:text-slate-200">
                    {t("newsCampaignAudience", {
                      n: fmtNum(preview.status === "sent" ? preview.recipients : audience, lang),
                    })}
                  </span>
                </div>
              </div>
              {/* subject + body as received */}
              <div className="px-4 py-4">
                <p className="font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                  {preview.subject}
                </p>
                <p className="mt-3 whitespace-pre-line text-[13px] leading-[1.85] text-slate-600 dark:text-slate-300">
                  {preview.body}
                </p>
              </div>
            </div>
          ) : null}

          <p className="flex items-start gap-1.5 text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            <CatIcon name="info" className="mt-px h-3.5 w-3.5 shrink-0" />
            {t("newsCampaignViewNote")}
          </p>
        </DialogContent>
      </Dialog>

      {/* ---------------- send confirm ---------------- */}
      <AlertDialog open={confirmSend !== null} onOpenChange={(o) => !o && setConfirmSend(null)}>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-8 w-8 place-items-center rounded-xl text-white"
                style={{ backgroundImage: grad("#10b981", "#059669") }}
              >
                <CatIcon name="send" className="h-4 w-4" />
              </span>
              {t("newsCampaignSendTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("newsCampaignSendMsg", { n: fmtNum(audience, lang) })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={send.isPending}>
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => confirmSend && send.mutate(confirmSend.id)}
              disabled={send.isPending}
              className="h-10 gap-2 rounded-xl bg-emerald-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:bg-emerald-700 active:scale-95 disabled:opacity-60"
            >
              <CatIcon name={send.isPending ? "refresh-cw" : "send"} className={cn("h-4 w-4", send.isPending && "animate-spin")} />
              {t("newsCampaignSendBtn")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ---------------- delete confirm ---------------- */}
      <AlertDialog open={confirmDelete !== null} onOpenChange={(o) => !o && setConfirmDelete(null)}>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display text-lg font-extrabold text-slate-900 dark:text-white">
              {t("newsCampaignDeleteTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("newsCampaignDeleteMsg", {
                subject: confirmDelete ? confirmDelete.subject.slice(0, 40) : "",
              })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={remove.isPending}>
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => confirmDelete && remove.mutate(confirmDelete.id)}
              disabled={remove.isPending}
              className="h-10 gap-2 rounded-xl bg-rose-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60"
            >
              <CatIcon name={remove.isPending ? "refresh-cw" : "trash"} className={cn("h-4 w-4", remove.isPending && "animate-spin")} />
              {t("newsCampaignDeleteConfirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashCard>
  );
}

export function AdminNewsletter() {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  /* round 29 — viewers read the lists, only super/admin manage them */
  const canManage = useAdminCanManage();
  const [pendingDelete, setPendingDelete] = useState<Subscriber | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [retagTarget, setRetagTarget] = useState<Subscriber | null>(null);
  const [retagValue, setRetagValue] = useState("");
  const [editTarget, setEditTarget] = useState<Subscriber | null>(null);
  const [editEmail, setEditEmail] = useState("");
  const [editTag, setEditTag] = useState("");
  const [editEmailInvalid, setEditEmailInvalid] = useState(false);
  const [pendingModeration, setPendingModeration] = useState<{ sub: Subscriber; next: "banned" | "restricted" } | null>(null);
  const [search, setSearch] = useState("");
  const [tagFilter, setTagFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState<"" | SubscriberStatus>("");
  /* round-27 bulk selection — Set of row ids */
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [bulkModeration, setBulkModeration] = useState<"banned" | "restricted" | "delete" | null>(null);
  const [bulkTagOpen, setBulkTagOpen] = useState(false);
  const [bulkTagValue, setBulkTagValue] = useState("");

  /* add-dialog form state */
  const [draftEmails, setDraftEmails] = useState("");
  const [draftTag, setDraftTag] = useState("");

  const parsed = useMemo(() => parseDraft(draftEmails), [draftEmails]);

  const query = useQuery<NewsletterResponse>({
    queryKey: ["newsletter-admin", search, tagFilter],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (search.trim()) params.set("q", search.trim());
      if (tagFilter) params.set("tag", tagFilter);
      const res = await fetch(`/api/admin/newsletter?${params.toString()}`);
      if (!res.ok) throw new Error("failed");
      return res.json();
    },
    staleTime: 10_000,
  });

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["newsletter-admin"] });
    queryClient.invalidateQueries({ queryKey: ["newsletter-subscribers"] });
  };

  /* bulk add */
  const add = useMutation({
    mutationFn: async (payload: { emails: string; tag: string }): Promise<AddResult> => {
      const res = await fetch("/api/admin/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error ?? "failed");
      return data as AddResult;
    },
    onSuccess: (result) => {
      if (result.added > 0 && result.skipped === 0 && result.invalid.length === 0) {
        toast.success(t("adminNewsAddedToast", { added: fmtNum(result.added, lang) }));
      } else if (result.added === 0) {
        toast.info(t("adminNewsSkippedToast", { skipped: fmtNum(result.skipped + result.invalid.length, lang) }));
      } else {
        toast.success(
          t("adminNewsMixedToast", {
            added: fmtNum(result.added, lang),
            skipped: fmtNum(result.skipped + result.invalid.length, lang),
          })
        );
      }
      setAddOpen(false);
      setDraftEmails("");
      setDraftTag("");
      invalidate();
    },
    onError: () => toast.error(t("adminNewsAddErr")),
  });

  /* shared row PATCH — retag / edit / moderate */
  const patchRow = useMutation({
    mutationFn: async (payload: { id: string; tag?: string; email?: string; status?: SubscriberStatus }) => {
      const res = await fetch("/api/admin/newsletter", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error ?? "failed");
      return data as { ok: boolean; subscriber: Subscriber };
    },
    onSuccess: (_result, payload) => {
      if (payload.status) toast.success(t("adminNewsModerateDone"));
      else if (payload.email !== undefined) toast.success(t("adminNewsEditSaved"));
      setRetagTarget(null);
      setEditTarget(null);
      setPendingModeration(null);
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  /* delete a row */
  const remove = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch("/api/admin/newsletter", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
      if (!res.ok) throw new Error("delete failed");
      return res.json();
    },
    onSuccess: () => {
      toast.success(t("adminDeleteConfirm"));
      setPendingDelete(null);
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  /* round-27 bulk mutations — one status/tag across many rows */
  const bulkPatch = useMutation({
    mutationFn: async (payload: { ids: string[]; status?: SubscriberStatus; tag?: string }) => {
      const res = await fetch("/api/admin/newsletter", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error ?? "failed");
      return data as { ok: boolean; updated: number };
    },
    onSuccess: (result, payload) => {
      toast.success(
        payload.status !== undefined
          ? t("adminNewsBulkDone", { count: fmtNum(result.updated, lang) })
          : t("adminNewsBulkDone", { count: fmtNum(result.updated, lang) })
      );
      setBulkModeration(null);
      setBulkTagOpen(false);
      setBulkTagValue("");
      setSelected(new Set());
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const bulkRemove = useMutation({
    mutationFn: async (ids: string[]) => {
      const res = await fetch("/api/admin/newsletter", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error ?? "failed");
      return data as { ok: boolean; removed: number };
    },
    onSuccess: (result) => {
      toast.success(t("adminNewsBulkRemoved", { count: fmtNum(result.removed, lang) }));
      setBulkModeration(null);
      setSelected(new Set());
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const subscribers = query.data?.subscribers ?? [];
  const tags = query.data?.tags ?? [];
  const counts = useMemo(
    () => ({
      total: subscribers.length,
      active: subscribers.filter((s) => s.status === "active").length,
      banned: subscribers.filter((s) => s.status === "banned").length,
      restricted: subscribers.filter((s) => s.status === "restricted").length,
    }),
    [subscribers]
  );

  const visible = useMemo(
    () => (statusFilter ? subscribers.filter((s) => s.status === statusFilter) : subscribers),
    [subscribers, statusFilter]
  );

  const exportCsv = () => {
    if (visible.length === 0) {
      toast.error(t("adminExportEmpty"));
      return;
    }
    const headers = ["email", "tag", "status", "subscribedAt"];
    const esc = (v: string) => (/[",\n]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v);
    const rows = visible.map((s) => [esc(s.email), esc(s.tag ?? ""), esc(s.status), esc(s.createdAt)].join(","));
    const csv = [headers.join(","), ...rows].join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "ashrilogic-newsletter-subscribers.csv";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success(t("adminExportDone"));
  };

  /* ----- selection helpers ----- */
  const allVisibleSelected = visible.length > 0 && visible.every((s) => selected.has(s.id));
  const someSelected = selected.size > 0;

  const toggleRow = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleAllVisible = () => {
    setSelected((prev) => {
      if (visible.every((s) => prev.has(s.id))) {
        visible.forEach((s) => prev.delete(s.id));
        return new Set(prev);
      }
      visible.forEach((s) => prev.add(s.id));
      return new Set(prev);
    });
  };

  const bulkPending = bulkPatch.isPending || bulkRemove.isPending;

  const submitAdd = () => {
    if (parsed.valid.length === 0) {
      toast.error(t("adminNewsAddErr"));
      return;
    }
    add.mutate({ emails: draftEmails, tag: draftTag.trim() });
  };

  const openEdit = (sub: Subscriber) => {
    setEditTarget(sub);
    setEditEmail(sub.email);
    setEditTag(sub.tag ?? "");
    setEditEmailInvalid(false);
  };

  const submitEdit = () => {
    if (!editTarget) return;
    const emailOk = EMAIL_RE.test(editEmail.trim());
    setEditEmailInvalid(!emailOk);
    if (!emailOk) {
      toast.error(t("staffErrEmail"));
      return;
    }
    patchRow.mutate({
      id: editTarget.id,
      email: editEmail.trim(),
      tag: editTag.trim(),
    });
  };

  const pending = patchRow.isPending || remove.isPending;

  return (
    <div className="space-y-5">
      <ViewHeading title={t("adminNewsTitle")} desc={t("adminNewsDesc")} />

      {/* round 29 — dynamic newsletter emails (DB-driven, top of the view) */}
      <NewsletterEmailsCard />

      {/* round 33 — email campaigns (composer + archive) */}
      <CampaignsCard />

      {/* KPI card + moderation strip */}
      <DashCard>
        <div className="flex flex-wrap items-center gap-4">
          <IconTile icon="mail" c1="#6d5dfb" c2="#d946ef" size="lg" />
          <div className="min-w-0 flex-1">
            <p className={cn("text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
              {t("adminNewsCount")}
            </p>
            <div className="mt-0.5 font-display text-3xl font-extrabold text-slate-900 dark:text-white">
              {query.isPending ? <Skeleton className="h-8 w-16" /> : fmtNum(counts.total, lang)}
            </div>
          </div>
          <Badge className="gap-1.5 rounded-full bg-brand-500/10 px-3 py-1 text-[11px] font-extrabold text-brand-600 dark:text-brand-300">
            <CatIcon name="mail" className="h-[11px] w-[11px]" />
            {t("adminNewsletter")}
          </Badge>
          <div className="flex items-center gap-1.5">
            {canManage ? (
              <Button
                type="button"
                size="sm"
                onClick={() => setAddOpen(true)}
                className="h-9 gap-1.5 rounded-lg bg-linear-to-l from-brand-600 to-brand-500 px-3 text-[11px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
              >
                <CatIcon name="user-plus" className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">{t("adminNewsAddBtn")}</span>
              </Button>
            ) : null}
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={exportCsv}
              disabled={visible.length === 0}
              className="h-9 gap-1.5 rounded-lg border-slate-200 px-2.5 text-[11px] font-bold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 disabled:opacity-40 dark:border-white/10 dark:text-slate-300"
            >
              <CatIcon name="file-output" className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">{t("adminExportCsv")}</span>
            </Button>
          </div>
        </div>

        {/* moderation KPI strip — clickable status filters
            (round 35: 4×1 on desktop, 2×2 on phones — mobile-first) */}
        <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
          {(
            [
              { key: "" as const, label: t("adminNewsCount"), value: counts.total, icon: "users", c1: "#6d5dfb", c2: "#4b35c9" },
              { key: "active" as const, label: t("adminNewsKpiActive"), value: counts.active, icon: "circle-check", c1: "#10b981", c2: "#059669" },
              { key: "banned" as const, label: t("adminNewsKpiBanned"), value: counts.banned, icon: "ban", c1: "#f43f5e", c2: "#e11d48" },
              { key: "restricted" as const, label: t("adminNewsKpiRestricted"), value: counts.restricted, icon: "shield-alert", c1: "#f59e0b", c2: "#d97706" },
            ] as const
          ).map((cell) => {
            const selected = statusFilter === cell.key;
            return (
              <button
                key={cell.key || "all"}
                type="button"
                onClick={() => setStatusFilter(cell.key)}
                aria-pressed={selected}
                title={cell.label}
                className={cn(
                  "group flex items-center gap-2.5 rounded-xl border px-3 py-2.5 text-start transition active:scale-[0.98]",
                  selected
                    ? "border-brand-300/80 bg-brand-500/[0.06] dark:border-brand-500/40 dark:bg-brand-500/10"
                    : "border-slate-200/80 bg-white/70 hover:border-slate-300 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-white/20"
                )}
              >
                <span
                  className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white shadow-sm"
                  style={{ backgroundImage: grad(cell.c1, cell.c2) }}
                  aria-hidden="true"
                >
                  <CatIcon name={cell.icon} className="h-[13px] w-[13px]" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className={cn("block truncate text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                    {cell.label}
                  </span>
                  <span dir="ltr" className="block text-start text-[15px] font-extrabold tabular-nums text-slate-800 dark:text-slate-100">
                    {query.isPending ? "…" : fmtNum(cell.value, lang)}
                  </span>
                </span>
              </button>
            );
          })}
        </div>

        {/* search + tag filter */}
        <div className="mt-4 flex flex-col gap-2.5 sm:flex-row sm:items-center">
          <div className="relative max-w-md flex-1">
            <CatIcon
              name="search"
              className="pointer-events-none absolute start-3.5 top-1/2 h-[13px] w-[13px] -translate-y-1/2 text-slate-400"
            />
            <Input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t("adminSearchPh")}
              aria-label={t("adminSearchPh")}
              className="h-10 rounded-xl border-slate-200 bg-slate-50/80 ps-10 pe-3 text-[12.5px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100"
            />
          </div>
          {/* tag filter chips */}
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              onClick={() => setTagFilter("")}
              className={cn(
                "inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[10.5px] font-extrabold transition active:scale-95",
                tagFilter === ""
                  ? "border-brand-300 bg-brand-500/10 text-brand-600 dark:border-brand-500/40 dark:text-brand-300"
                  : "border-slate-200 bg-white text-slate-500 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-400"
              )}
            >
              <CatIcon name="layers" className="h-[10px] w-[10px]" />
              {t("adminNewsTagAll")}
              {counts.total > 0 ? <span className="opacity-60">· {fmtNum(counts.total, lang)}</span> : null}
            </button>
            {tags.map((tag) => (
              <button
                key={tag}
                type="button"
                onClick={() => setTagFilter(tagFilter === tag ? "" : tag)}
                className={cn(
                  "inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[10.5px] font-extrabold transition active:scale-95",
                  tagFilter === tag
                    ? "border-fuchsia-300 bg-fuchsia-500/10 text-fuchsia-600 dark:border-fuchsia-500/40 dark:text-fuchsia-300"
                    : "border-slate-200 bg-white text-slate-500 hover:border-fuchsia-300 hover:text-fuchsia-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-400"
                )}
              >
                <CatIcon name="tag" className="h-[10px] w-[10px]" />
                {tag}
              </button>
            ))}
          </div>
        </div>
      </DashCard>

      {/* subscribers table */}
      <DashCard title={t("adminNewsRecent")} icon="clock">
        {query.isPending ? (
          <div className="space-y-3">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-12 w-full rounded-xl" />
            ))}
          </div>
        ) : visible.length === 0 ? (
          <div className="py-14 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5">
              <CatIcon name="mail" className="h-6 w-6" />
            </div>
            <p className="mt-3 font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("adminNewsEmpty")}
            </p>
            <p className="mx-auto mt-1 max-w-sm text-[12px] font-semibold text-slate-400 dark:text-slate-500">
              {t("adminNewsEmptyDesc")}
            </p>
            {canManage ? (
              <Button
                type="button"
                size="sm"
                onClick={() => setAddOpen(true)}
                className="mt-4 h-9 gap-1.5 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-4 text-[11.5px] font-extrabold text-white shadow-lg shadow-brand-500/25"
              >
                <CatIcon name="user-plus" className="h-3.5 w-3.5" />
                {t("adminNewsAddBtn")}
              </Button>
            ) : null}
          </div>
        ) : (
          <div className="max-h-[480px] overflow-y-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-200/70 dark:border-white/10">
                  {/* round-27 bulk selection — select-all checkbox */}
                  <th className="w-9 pb-2">
                    <Checkbox
                      checked={allVisibleSelected ? true : someSelected ? "indeterminate" : false}
                      onCheckedChange={toggleAllVisible}
                      aria-label={t("adminNewsSelectAll")}
                      disabled={!canManage || visible.length === 0}
                      className="data-[state=checked]:border-brand-500 data-[state=checked]:bg-brand-500 data-[state=indeterminate]:border-brand-500 data-[state=indeterminate]:bg-brand-500/80"
                    />
                  </th>
                  <th className={cn("pb-2 text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                    {t("adminNewsColEmail")}
                  </th>
                  <th className={cn("pb-2 text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                    {t("adminNewsColTag")}
                  </th>
                  <th className={cn("pb-2 text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                    {t("adminNewsColStatus")}
                  </th>
                  <th className={cn("pb-2 text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                    {t("adminNewsColDate")}
                  </th>
                  <th className={cn("pb-2 text-end text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                    {t("adminColActions")}
                  </th>
                </tr>
              </thead>
              <tbody>
                {visible.map((sub) => (
                  <tr
                    key={sub.id}
                    className={cn(
                      "border-b border-slate-100 last:border-0 transition-colors dark:border-white/[0.05]",
                      selected.has(sub.id) && "bg-brand-500/[0.045] dark:bg-brand-500/[0.07]"
                    )}
                  >
                    <td className="py-2.5">
                      <Checkbox
                        checked={selected.has(sub.id)}
                        onCheckedChange={() => toggleRow(sub.id)}
                        aria-label={`${t("adminNewsSelected")} — ${sub.email}`}
                        disabled={!canManage}
                        className="data-[state=checked]:border-brand-500 data-[state=checked]:bg-brand-500"
                      />
                    </td>
                    <td className="py-2.5">
                      <div className="flex items-center gap-2.5">
                        <span
                          className={cn(
                            "grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white",
                            sub.status === "banned"
                              ? "bg-linear-to-br from-rose-500 to-rose-600"
                              : sub.status === "restricted"
                                ? "bg-linear-to-br from-amber-400 to-orange-500"
                                : "bg-linear-to-br from-brand-500 to-fuchsia-500"
                          )}
                          aria-hidden="true"
                        >
                          <CatIcon
                            name={sub.status === "banned" ? "mail-x" : sub.status === "restricted" ? "mail-warning" : "at-sign"}
                            className="h-[12px] w-[12px]"
                          />
                        </span>
                        <span
                          dir="ltr"
                          className={cn(
                            "truncate text-[12.5px] font-bold text-slate-700 dark:text-slate-200",
                            sub.status === "banned" && "line-through decoration-rose-400/70 decoration-2",
                            lang === "ar" ? "text-end" : "text-start"
                          )}
                        >
                          {sub.email}
                        </span>
                      </div>
                    </td>
                    <td className="py-2.5">
                      {sub.tag ? (
                        <button
                          type="button"
                          disabled={!canManage}
                          onClick={() => {
                            setRetagTarget(sub);
                            setRetagValue(sub.tag ?? "");
                          }}
                          title={t("adminNewsColTag")}
                          className="inline-flex max-w-[120px] items-center gap-1 truncate rounded-full border border-fuchsia-200 bg-fuchsia-500/10 px-2.5 py-1 text-[10.5px] font-extrabold text-fuchsia-600 transition hover:border-fuchsia-300 hover:bg-fuchsia-500/20 active:scale-95 disabled:cursor-not-allowed disabled:opacity-70 dark:border-fuchsia-500/30 dark:text-fuchsia-300"
                        >
                          <CatIcon name="tag" className="h-[10px] w-[10px] shrink-0" />
                          <span className="truncate">{sub.tag}</span>
                          {canManage ? <CatIcon name="pencil" className="h-[9px] w-[9px] shrink-0 opacity-60" /> : null}
                        </button>
                      ) : (
                        <button
                          type="button"
                          disabled={!canManage}
                          onClick={() => {
                            setRetagTarget(sub);
                            setRetagValue("");
                          }}
                          className="inline-flex items-center gap-1 rounded-full border border-dashed border-slate-300 px-2.5 py-1 text-[10.5px] font-bold text-slate-400 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 disabled:cursor-not-allowed disabled:opacity-70 dark:border-white/15 dark:text-slate-500"
                        >
                          <CatIcon name="plus" className="h-[10px] w-[10px]" />
                          {t("adminNewsNoTag")}
                        </button>
                      )}
                    </td>
                    <td className="py-2.5">
                      <StatusBadge status={sub.status} />
                    </td>
                    <td className="py-2.5">
                      <p className="whitespace-nowrap text-start text-[11.5px] font-bold text-slate-600 dark:text-slate-300">
                        {fullDate(sub.createdAt, lang)}
                      </p>
                      <p className="text-start text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                        {relativeTime(sub.createdAt, lang)}
                      </p>
                      {/* round 28 — last moderation touch (skipped when untouched) */}
                      {sub.updatedAt !== sub.createdAt ? (
                        <p
                          title={fullDate(sub.updatedAt, lang)}
                          className="text-start text-[11px] font-bold text-slate-400/90 dark:text-slate-500"
                        >
                          <CatIcon name="clock-rotate-left" className="me-0.5 inline h-[8px] w-[8px] align-[-1px]" aria-hidden="true" />
                          {t("adminNewsTouched")} {relativeTime(sub.updatedAt, lang)}
                        </p>
                      ) : null}
                    </td>
                    <td className="py-2.5">
                      {/* round 35 — actions column: the trigger is aligned with
                          the header word via an inline-flex wrapper (a bare
                          `grid` button is block-level and ignores text-end,
                          which left it floating toward the table middle) */}
                      <div className="flex justify-end">
                      {/* premium actions menu — edit / ban / restrict / delete
                          (round 29: viewers get a quiet lock instead) */}
                      {canManage ? (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <button
                              type="button"
                              aria-label={`${t("adminColActions")} — ${sub.email}`}
                              className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:text-slate-300"
                            >
                              <CatIcon name="ellipsis-vertical" className="h-[14px] w-[14px]" />
                            </button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-64 rounded-2xl">
                            <DropdownMenuItem
                              onClick={() => openEdit(sub)}
                              className="gap-2.5 rounded-lg py-2.5 text-[12.5px] font-bold"
                            >
                              <CatIcon name="user-round-pen" className="h-4 w-4 text-brand-500" />
                              <span className="flex min-w-0 flex-col">
                                <span className="truncate">{t("adminNewsActionEdit")}</span>
                                <span className="truncate text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                                  {t("adminNewsActionEditDesc")}
                                </span>
                              </span>
                            </DropdownMenuItem>

                            {/* moderation — ban / restrict or undo */}
                            {sub.status !== "banned" ? (
                              <DropdownMenuItem
                                onClick={() => setPendingModeration({ sub, next: "banned" })}
                                className="gap-2.5 rounded-lg py-2.5 text-[12.5px] font-bold text-rose-600 focus:text-rose-600 dark:text-rose-400 dark:focus:text-rose-400"
                              >
                                <CatIcon name="ban" className="h-4 w-4" />
                                <span className="flex min-w-0 flex-col">
                                  <span className="truncate">{t("adminNewsActionBan")}</span>
                                  <span className="truncate text-[10px] font-semibold text-rose-400/80 dark:text-rose-400/70">
                                    {t("adminNewsActionBanDesc")}
                                  </span>
                                </span>
                              </DropdownMenuItem>
                            ) : (
                              <DropdownMenuItem
                                onClick={() => patchRow.mutate({ id: sub.id, status: "active" })}
                                disabled={pending}
                                className="gap-2.5 rounded-lg py-2.5 text-[12.5px] font-bold text-emerald-600 focus:text-emerald-600 dark:text-emerald-400 dark:focus:text-emerald-400"
                              >
                                <CatIcon name="circle-check" className="h-4 w-4" />
                                <span className="flex min-w-0 flex-col">
                                  <span className="truncate">{t("adminNewsActionUnban")}</span>
                                  <span className="truncate text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                                    {t("adminNewsStatusActiveHint")}
                                  </span>
                                </span>
                              </DropdownMenuItem>
                            )}

                            {sub.status !== "restricted" ? (
                              <DropdownMenuItem
                                onClick={() => setPendingModeration({ sub, next: "restricted" })}
                                className="gap-2.5 rounded-lg py-2.5 text-[12.5px] font-bold text-amber-600 focus:text-amber-600 dark:text-amber-400 dark:focus:text-amber-400"
                              >
                                <CatIcon name="shield-alert" className="h-4 w-4" />
                                <span className="flex min-w-0 flex-col">
                                  <span className="truncate">{t("adminNewsActionRestrict")}</span>
                                  <span className="truncate text-[10px] font-semibold text-amber-500/80 dark:text-amber-400/70">
                                    {t("adminNewsActionRestrictDesc")}
                                  </span>
                                </span>
                              </DropdownMenuItem>
                            ) : (
                              <DropdownMenuItem
                                onClick={() => patchRow.mutate({ id: sub.id, status: "active" })}
                                disabled={pending}
                                className="gap-2.5 rounded-lg py-2.5 text-[12.5px] font-bold text-emerald-600 focus:text-emerald-600 dark:text-emerald-400 dark:focus:text-emerald-400"
                              >
                                <CatIcon name="circle-check" className="h-4 w-4" />
                                <span className="flex min-w-0 flex-col">
                                  <span className="truncate">{t("adminNewsActionUnrestrict")}</span>
                                  <span className="truncate text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                                    {t("adminNewsStatusActiveHint")}
                                  </span>
                                </span>
                              </DropdownMenuItem>
                            )}

                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              onClick={() => setPendingDelete(sub)}
                              className="gap-2.5 rounded-lg py-2.5 text-[12.5px] font-bold text-rose-600 focus:text-rose-600 dark:text-rose-400 dark:focus:text-rose-400"
                            >
                              <CatIcon name="trash-2" className="h-4 w-4" />
                              {t("adminActionDelete")}
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      ) : (
                        <span
                          title={t("adminNoPerm")}
                          className="inline-grid h-8 w-8 place-items-center rounded-lg border border-dashed border-slate-200 text-slate-300 dark:border-white/10 dark:text-slate-600"
                        >
                          <CatIcon name="lock" className="h-[13px] w-[13px]" />
                        </span>
                      )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </DashCard>

      {/* round-27 floating bulk-action bar — appears while rows are selected
          (round 29: hidden for roles that cannot moderate) */}
      {someSelected && canManage ? (
        <div
          role="toolbar"
          aria-label={t("adminNewsBulkTitle")}
          className="fixed bottom-5 left-1/2 z-50 w-[min(92vw,640px)] -translate-x-1/2 animate-in slide-in-from-bottom-4 fade-in rounded-2xl border border-slate-200/80 bg-white/95 p-2.5 shadow-2xl shadow-slate-900/15 backdrop-blur-xl dark:border-white/10 dark:bg-[#0b1220]/95 dark:shadow-black/40"
        >
          <div className="flex flex-wrap items-center gap-2">
            {/* count chip */}
            <span className="ms-1 inline-flex shrink-0 items-center gap-1.5 rounded-xl bg-brand-500/10 px-3 py-1.5 text-[12px] font-extrabold text-brand-600 dark:text-brand-300">
              <CatIcon name="check-check" className="h-[13px] w-[13px]" />
              <span dir="ltr" className="tabular-nums">{fmtNum(selected.size, lang)}</span>
              {t("adminNewsSelected")}
            </span>
            <span className="hidden h-6 w-px shrink-0 bg-slate-200 sm:block dark:bg-white/10" aria-hidden="true" />

            {/* actions */}
            <button
              type="button"
              onClick={() => setBulkModeration("banned")}
              disabled={bulkPending}
              className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50 px-3 text-[11.5px] font-extrabold text-rose-600 transition hover:bg-rose-100 active:scale-95 disabled:opacity-50 dark:border-rose-500/25 dark:bg-rose-500/10 dark:text-rose-300 dark:hover:bg-rose-500/20"
            >
              <CatIcon name="ban" className="h-[13px] w-[13px]" />
              {t("adminNewsBulkBan")}
            </button>
            <button
              type="button"
              onClick={() => setBulkModeration("restricted")}
              disabled={bulkPending}
              className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-amber-200 bg-amber-50 px-3 text-[11.5px] font-extrabold text-amber-600 transition hover:bg-amber-100 active:scale-95 disabled:opacity-50 dark:border-amber-500/25 dark:bg-amber-500/10 dark:text-amber-300 dark:hover:bg-amber-500/20"
            >
              <CatIcon name="shield-alert" className="h-[13px] w-[13px]" />
              {t("adminNewsBulkRestrict")}
            </button>
            <button
              type="button"
              onClick={() => bulkPatch.mutate({ ids: [...selected], status: "active" })}
              disabled={bulkPending}
              className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-emerald-200 bg-emerald-50 px-3 text-[11.5px] font-extrabold text-emerald-600 transition hover:bg-emerald-100 active:scale-95 disabled:opacity-50 dark:border-emerald-500/25 dark:bg-emerald-500/10 dark:text-emerald-300 dark:hover:bg-emerald-500/20"
            >
              <CatIcon name="circle-check" className="h-[13px] w-[13px]" />
              {t("adminNewsBulkActivate")}
            </button>
            <button
              type="button"
              onClick={() => {
                setBulkTagValue("");
                setBulkTagOpen(true);
              }}
              disabled={bulkPending}
              className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-fuchsia-200 bg-fuchsia-50 px-3 text-[11.5px] font-extrabold text-fuchsia-600 transition hover:bg-fuchsia-100 active:scale-95 disabled:opacity-50 dark:border-fuchsia-500/25 dark:bg-fuchsia-500/10 dark:text-fuchsia-300 dark:hover:bg-fuchsia-500/20"
            >
              <CatIcon name="tag" className="h-[13px] w-[13px]" />
              {t("adminNewsBulkTag")}
            </button>
            <button
              type="button"
              onClick={() => setBulkModeration("delete")}
              disabled={bulkPending}
              className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-rose-300 bg-rose-600 px-3 text-[11.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-50"
            >
              <CatIcon name="trash-2" className="h-[13px] w-[13px]" />
              {t("adminNewsBulkDelete")}
            </button>

            {/* clear selection */}
            <button
              type="button"
              onClick={() => setSelected(new Set())}
              className="ms-auto inline-flex h-9 shrink-0 items-center gap-1 rounded-xl px-2.5 text-[11.5px] font-bold text-slate-400 transition hover:text-slate-600 active:scale-95 dark:hover:text-slate-200"
            >
              <CatIcon name="x" className="h-[13px] w-[13px]" />
              <span className="hidden sm:inline">{t("adminNewsBulkClear")}</span>
            </button>
          </div>
        </div>
      ) : null}

      {/* bulk moderation confirm — ban / restrict / delete */}
      <AlertDialog open={bulkModeration !== null} onOpenChange={(o) => !o && setBulkModeration(null)}>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className={cn(
                  "grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg",
                  bulkModeration === "banned"
                    ? "bg-linear-to-br from-rose-500 to-rose-600 shadow-rose-500/25"
                    : bulkModeration === "restricted"
                      ? "bg-linear-to-br from-amber-400 to-orange-500 shadow-amber-500/25"
                      : "bg-linear-to-br from-slate-600 to-slate-700 shadow-slate-500/25"
                )}
                aria-hidden="true"
              >
                <CatIcon
                  name={bulkModeration === "banned" ? "ban" : bulkModeration === "restricted" ? "shield-alert" : "trash-2"}
                  className="h-[15px] w-[15px]"
                />
              </span>
              {bulkModeration === "delete" ? t("adminNewsBulkDelete") : t("adminNewsBulkTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {bulkModeration === "banned"
                ? t("adminNewsBulkBanMsg", { count: fmtNum(selected.size, lang) })
                : bulkModeration === "restricted"
                  ? t("adminNewsBulkRestrictMsg", { count: fmtNum(selected.size, lang) })
                  : t("adminNewsBulkDeleteMsg", { count: fmtNum(selected.size, lang) })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="flex max-h-32 flex-wrap gap-1.5 overflow-y-auto rounded-xl border border-dashed border-slate-300 bg-slate-50/60 p-2.5 dark:border-white/15 dark:bg-white/[0.03]">
            {[...selected].slice(0, 12).map((id) => {
              const sub = subscribers.find((s) => s.id === id);
              return sub ? (
                <span
                  key={id}
                  dir="ltr"
                  className="truncate rounded-full bg-white px-2 py-0.5 font-mono text-[10.5px] font-semibold text-slate-500 dark:bg-white/10 dark:text-slate-300"
                >
                  {sub.email}
                </span>
              ) : null;
            })}
            {selected.size > 12 ? (
              <span dir="ltr" className="rounded-full bg-slate-100 px-2 py-0.5 text-[10.5px] font-extrabold text-slate-500 dark:bg-white/10 dark:text-slate-400">
                +{fmtNum(selected.size - 12, lang)}
              </span>
            ) : null}
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={bulkPending}>
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (bulkModeration === "delete") {
                  bulkRemove.mutate([...selected]);
                } else if (bulkModeration) {
                  bulkPatch.mutate({ ids: [...selected], status: bulkModeration });
                }
              }}
              disabled={bulkPending}
              className={cn(
                "h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition active:scale-95 disabled:opacity-60",
                bulkModeration === "banned"
                  ? "bg-rose-600 shadow-rose-500/25 hover:bg-rose-700"
                  : bulkModeration === "restricted"
                    ? "bg-linear-to-l from-amber-500 to-orange-500 shadow-amber-500/25 hover:brightness-110"
                    : "bg-slate-700 shadow-slate-500/25 hover:bg-slate-800"
              )}
            >
              {bulkPending ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : null}
              {t("adminNewsBulkApply", { count: fmtNum(selected.size, lang) })}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* bulk tag dialog */}
      <Dialog open={bulkTagOpen} onOpenChange={setBulkTagOpen}>
        <DialogContent className="rounded-3xl sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2.5 font-display text-[16px] font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-linear-to-br from-fuchsia-500 to-brand-500 text-white"
                aria-hidden="true"
              >
                <CatIcon name="tags" className="h-[13px] w-[13px]" />
              </span>
              {t("adminNewsBulkTag")}
            </DialogTitle>
            <DialogDescription className="text-[12px] text-slate-500 dark:text-slate-400">
              {t("adminNewsBulkTagMsg", { count: fmtNum(selected.size, lang) })}
            </DialogDescription>
          </DialogHeader>
          <Input
            value={bulkTagValue}
            onChange={(e) => setBulkTagValue(e.target.value)}
            placeholder={t("adminNewsAddTagPh")}
            maxLength={40}
            className="h-11 rounded-xl text-[12.5px] font-semibold"
            autoFocus
          />
          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => bulkPatch.mutate({ ids: [...selected], tag: "" })}
              disabled={bulkPending}
              className="h-10 rounded-xl px-4 text-[12px] font-bold text-slate-500"
            >
              <CatIcon name="trash-2" className="h-3.5 w-3.5" />
              {t("adminNewsNoTag")}
            </Button>
            <Button
              type="button"
              onClick={() => bulkPatch.mutate({ ids: [...selected], tag: bulkTagValue })}
              disabled={bulkPending}
              className="h-10 gap-2 rounded-xl bg-linear-to-l from-fuchsia-600 to-brand-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-fuchsia-500/25 transition hover:brightness-110 active:scale-95"
            >
              <CatIcon name={bulkPending ? "refresh-cw" : "check"} className={cn("h-4 w-4", bulkPending && "animate-spin")} />
              {t("adminNewsBulkApply", { count: fmtNum(selected.size, lang) })}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* add subscribers dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="rounded-3xl sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-linear-to-br from-brand-500 to-fuchsia-500 text-white shadow-lg shadow-brand-500/25"
                aria-hidden="true"
              >
                <CatIcon name="user-plus" className="h-[15px] w-[15px]" />
              </span>
              {t("adminNewsAddTitle")}
            </DialogTitle>
            <DialogDescription className="text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("adminNewsAddDesc")}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="news-emails" className="text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                {t("adminNewsColEmail")}
              </Label>
              <Textarea
                id="news-emails"
                dir="ltr"
                value={draftEmails}
                onChange={(e) => setDraftEmails(e.target.value)}
                placeholder={t("adminNewsAddPh")}
                rows={5}
                className="text-start font-mono text-[12px] font-semibold leading-relaxed"
              />
              {/* live parse preview */}
              {draftEmails.trim() ? (
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2.5 py-1 text-[10.5px] font-extrabold text-emerald-600 dark:text-emerald-300">
                    <CatIcon name="circle-check" className="h-[11px] w-[11px]" />
                    {fmtNum(parsed.valid.length, lang)}
                  </span>
                  {parsed.invalid.length > 0 ? (
                    <span className="inline-flex items-center gap-1 rounded-full bg-rose-500/10 px-2.5 py-1 text-[10.5px] font-extrabold text-rose-600 dark:text-rose-300">
                      <CatIcon name="circle-alert" className="h-[11px] w-[11px]" />
                      {fmtNum(parsed.invalid.length, lang)}
                    </span>
                  ) : null}
                  {parsed.valid[0] ? (
                    <span dir="ltr" className="truncate font-mono text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                      {parsed.valid[0]}
                      {parsed.valid.length > 1 ? ` +${parsed.valid.length - 1}` : ""}
                    </span>
                  ) : null}
                </div>
              ) : null}
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="news-tag" className="text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                {t("adminNewsAddTagLabel")}
              </Label>
              <Input
                id="news-tag"
                value={draftTag}
                onChange={(e) => setDraftTag(e.target.value)}
                placeholder={t("adminNewsAddTagPh")}
                maxLength={40}
                className="h-10 rounded-xl text-[12.5px] font-semibold"
              />
              <p className="text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                {t("adminNewsAddTagHint")}
              </p>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setAddOpen(false)}
              disabled={add.isPending}
              className="h-10 rounded-xl px-5 text-[12.5px] font-bold"
            >
              {t("adminNewsAddCancel")}
            </Button>
            <Button
              type="button"
              onClick={submitAdd}
              disabled={add.isPending || parsed.valid.length === 0}
              className="h-10 gap-2 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-50"
            >
              <CatIcon name={add.isPending ? "refresh-cw" : "user-plus"} className={cn("h-4 w-4", add.isPending && "animate-spin")} />
              {add.isPending ? t("adminNewsAddSubmitting") : t("adminNewsAddSubmit")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* edit details dialog — email + tag together */}
      <Dialog open={editTarget !== null} onOpenChange={(o) => !o && setEditTarget(null)}>
        <DialogContent className="rounded-3xl sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2.5 font-display text-[16px] font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-linear-to-br from-brand-500 to-fuchsia-500 text-white"
                aria-hidden="true"
              >
                <CatIcon name="user-round-pen" className="h-[13px] w-[13px]" />
              </span>
              {t("adminNewsEditTitle")}
            </DialogTitle>
            <DialogDescription
              dir="ltr"
              className="truncate text-end font-mono text-[11.5px] text-slate-500 dark:text-slate-400"
            >
              {editTarget?.email}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3.5">
            <div className="space-y-1.5">
              <Label htmlFor="news-edit-email" className="text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                {t("adminNewsEditEmail")}
              </Label>
              <div className="relative">
                <CatIcon
                  name="mail"
                  className="pointer-events-none absolute start-3.5 top-1/2 h-[14px] w-[14px] -translate-y-1/2 text-slate-400"
                />
                <Input
                  id="news-edit-email"
                  type="email"
                  dir="ltr"
                  value={editEmail}
                  onChange={(e) => {
                    setEditEmail(e.target.value);
                    setEditEmailInvalid(false);
                  }}
                  placeholder={t("adminNewsEditEmailPh")}
                  maxLength={160}
                  autoFocus
                  aria-invalid={editEmailInvalid || undefined}
                  className={cn(
                    "h-11 rounded-xl ps-10 text-start text-[12.5px] font-semibold",
                    editEmailInvalid &&
                      "border-rose-400 focus:border-rose-400 focus:ring-rose-500/15 focus:shadow-rose-500/10"
                  )}
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="news-edit-tag" className="text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300">
                {t("adminNewsAddTagLabel")}
              </Label>
              <Input
                id="news-edit-tag"
                value={editTag}
                onChange={(e) => setEditTag(e.target.value)}
                placeholder={t("adminNewsAddTagPh")}
                maxLength={40}
                className="h-11 rounded-xl text-[12.5px] font-semibold"
              />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setEditTarget(null)}
              disabled={patchRow.isPending}
              className="h-10 rounded-xl px-5 text-[12.5px] font-bold"
            >
              {t("dlgCancel")}
            </Button>
            <Button
              type="button"
              onClick={submitEdit}
              disabled={patchRow.isPending}
              className="h-10 gap-2 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-50"
            >
              <CatIcon name={patchRow.isPending ? "refresh-cw" : "save"} className={cn("h-4 w-4", patchRow.isPending && "animate-spin")} />
              {t("profileSave")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* moderation confirm — ban / restrict with explanatory copy */}
      <AlertDialog
        open={pendingModeration !== null}
        onOpenChange={(o) => !o && setPendingModeration(null)}
      >
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className={cn(
                  "grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg",
                  pendingModeration?.next === "banned"
                    ? "bg-linear-to-br from-rose-500 to-rose-600 shadow-rose-500/25"
                    : "bg-linear-to-br from-amber-400 to-orange-500 shadow-amber-500/25"
                )}
                aria-hidden="true"
              >
                <CatIcon
                  name={pendingModeration?.next === "banned" ? "ban" : "shield-alert"}
                  className="h-[15px] w-[15px]"
                />
              </span>
              {pendingModeration?.next === "banned" ? t("adminNewsModerateTitle") : t("adminNewsRestrictTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {pendingModeration
                ? t(pendingModeration.next === "banned" ? "adminNewsModerateMsg" : "adminNewsRestrictMsg", {
                    email: pendingModeration.sub.email,
                  })
                : ""}
            </AlertDialogDescription>
          </AlertDialogHeader>
          {pendingModeration ? (
            <p
              dir="ltr"
              className={cn(
                "truncate rounded-xl border border-dashed border-slate-300 bg-slate-50/60 px-3.5 py-2.5 text-center font-mono text-[12px] font-bold text-slate-600 dark:border-white/15 dark:bg-white/[0.03] dark:text-slate-300"
              )}
            >
              {pendingModeration.sub.email}
            </p>
          ) : null}
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={patchRow.isPending}>
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() =>
                pendingModeration &&
                patchRow.mutate({ id: pendingModeration.sub.id, status: pendingModeration.next })
              }
              disabled={patchRow.isPending}
              className={cn(
                "h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition active:scale-95 disabled:opacity-60",
                pendingModeration?.next === "banned"
                  ? "bg-rose-600 shadow-rose-500/25 hover:bg-rose-700"
                  : "bg-linear-to-l from-amber-500 to-orange-500 shadow-amber-500/25 hover:brightness-110"
              )}
            >
              {patchRow.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name={pendingModeration?.next === "banned" ? "ban" : "shield-alert"} className="h-4 w-4" />
              )}
              {pendingModeration?.next === "banned" ? t("adminNewsConfirmBan") : t("adminNewsConfirmRestrict")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* retag dialog */}
      <Dialog open={retagTarget !== null} onOpenChange={(o) => !o && setRetagTarget(null)}>
        <DialogContent className="rounded-3xl sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2.5 font-display text-[16px] font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-linear-to-br from-fuchsia-500 to-brand-500 text-white"
                aria-hidden="true"
              >
                <CatIcon name="tag" className="h-[13px] w-[13px]" />
              </span>
              {t("adminNewsColTag")}
            </DialogTitle>
            <DialogDescription dir="ltr" className="truncate text-end font-mono text-[11.5px] text-slate-500 dark:text-slate-400">
              {retagTarget?.email}
            </DialogDescription>
          </DialogHeader>
          <Input
            value={retagValue}
            onChange={(e) => setRetagValue(e.target.value)}
            placeholder={t("adminNewsAddTagPh")}
            maxLength={40}
            className="h-10 rounded-xl text-[12.5px] font-semibold"
            autoFocus
          />
          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => retagTarget && patchRow.mutate({ id: retagTarget.id, tag: "" })}
              disabled={patchRow.isPending}
              className="h-10 rounded-xl px-4 text-[12px] font-bold text-slate-500"
            >
              <CatIcon name="trash-2" className="h-3.5 w-3.5" />
              {t("adminNewsNoTag")}
            </Button>
            <Button
              type="button"
              onClick={() => retagTarget && patchRow.mutate({ id: retagTarget.id, tag: retagValue })}
              disabled={patchRow.isPending}
              className="h-10 gap-2 rounded-xl bg-linear-to-l from-fuchsia-600 to-brand-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-fuchsia-500/25 transition hover:brightness-110 active:scale-95"
            >
              <CatIcon name={patchRow.isPending ? "refresh-cw" : "check"} className={cn("h-4 w-4", patchRow.isPending && "animate-spin")} />
              {t("profileSave")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* delete confirm */}
      <AlertDialog open={pendingDelete !== null} onOpenChange={(o) => !o && setPendingDelete(null)}>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display text-lg font-extrabold text-slate-900 dark:text-white">
              {t("adminDeleteTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] text-slate-500 dark:text-slate-400">
              {t("adminDeleteMsg")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={remove.isPending}>
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => pendingDelete && remove.mutate(pendingDelete.id)}
              disabled={remove.isPending}
              className="h-10 rounded-xl bg-rose-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60"
            >
              {remove.isPending ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : null}
              {t("adminDeleteConfirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default AdminNewsletter;
