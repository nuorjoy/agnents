"use client";

/**
 * Ashrilogic — ROUND 47 — admin Activation Requests view (طلبات التفعيل).
 *
 * The console's payment-confirmation queue, powered by
 * GET /api/admin/plan-orders (admin-guarded, optional ?status= filter) and
 * PATCH /api/admin/plan-orders/[id] with { action: "paid" | "cancelled" }.
 *
 * Confirming a payment activates the requested plan for the tenant and
 * instantly resumes a trial-locked workspace (system, website and e-store);
 * cancelling closes the request. Amounts are ALWAYS server-computed from
 * the live package — the client never sends money figures — and every row
 * is HMAC integrity-verified server-side (chip on the card).
 *
 * Layout (mirrors the round-46 Stores view): slim info banner → KPI strip →
 * status filter chips → premium order cards (mobile one-column, desktop
 * two-column) with bilingual plan identity, cycle/method chips, localized
 * dates, expiry countdown and the confirm / cancel actions.
 */
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { SYSTEM_MAP } from "@/data/catalog";
import {
  adminAddonOrderAction,
  adminPlanOrderAction,
  adminWalletTopupAction,
  fetchAdminAddonOrders,
  fetchAdminPlanOrders,
  fetchAdminWalletTopups,
} from "@/lib/api-client";
import { apiErrorText } from "@/lib/api-errors";
import { useAdminCanManage } from "@/lib/admin-auth";
import { intlLocale, useT, type I18nKey } from "@/lib/i18n";
import type { AdminAddonOrderDTO, AdminPlanOrderDTO, AdminWalletTopupDTO, Lang, PaymentMethod } from "@/lib/types";
import { FEATURE_META, type PlanFeature } from "@/lib/plan-features";
import { CatIcon } from "@/components/icon";
import { cn, copyText, fmtNum, grad, labelTrack } from "@/lib/utils";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { DashCard, IconTile, ViewHeading } from "@/components/dashboard/dash-shared";

type OrderFilter = "all" | "pending" | "paid" | "cancelled";

/* ---------------- helpers ---------------- */

/** Localized "medium date + short time" stamp (ar-EG for Arabic). */
function formatStamp(date: string, lang: Lang): string {
  try {
    return new Intl.DateTimeFormat(intlLocale(lang), {
      dateStyle: "medium",
      timeStyle: "short",
    }).format(new Date(date));
  } catch {
    return new Date(date).toLocaleString();
  }
}

/**
 * Countdown label for a pending request's payment window — honors the
 * Arabic number-agreement law (ROUND 80/81): 1 → ساعة واحدة · 2 → ساعتان ·
 * 3–10 → ساعات · 11+ → ساعة (same for minutes). Returns null once the
 * window has passed (expired state).
 */
function expiresInLabel(
  expiresAt: string,
  lang: Lang,
  t: (key: I18nKey, vars?: Record<string, string | number>) => string
): string | null {
  const ms = new Date(expiresAt).getTime() - Date.now();
  if (ms <= 0) return null;
  const hours = Math.floor(ms / 3_600_000);
  if (hours > 0) {
    if (lang === "ar") {
      if (hours >= 11) return t("durHoursMany", { hours: fmtNum(hours, lang) });
      if (hours >= 3) return t("durHoursFew", { hours: fmtNum(hours, lang) });
      if (hours === 2) return t("durHoursTwo");
      return t("durHoursOne");
    }
    if (lang === "hi") return t(hours >= 3 ? "durHoursFew" : "durHoursMany", { hours: fmtNum(hours, lang) });
    return `${fmtNum(hours, lang)} hr`;
  }
  const minutes = Math.max(1, Math.ceil(ms / 60_000));
  if (lang === "ar") {
    if (minutes >= 11) return t("durMinutesMany", { minutes: fmtNum(minutes, lang) });
    if (minutes >= 3) return t("durMinutesFew", { minutes: fmtNum(minutes, lang) });
    if (minutes === 2) return t("durMinutesTwo");
    return t("durMinutesOne");
  }
  return t(minutes >= 3 ? "durMinutesFew" : "durMinutesMany", { minutes: fmtNum(minutes, lang) });
}

/** ROUND 48 — per-KIND icon + gradient identity (mirrors the console
 * settings manager and the tenant billing view; the concrete methods are
 * console-managed and dynamic). */
const METHOD_META: Record<PaymentMethod, { icon: string; c1: string; c2: string }> = {
  bank: { icon: "landmark", c1: "#0ea5e9", c2: "#0369a1" },
  wallet: { icon: "wallet", c1: "#f59e0b", c2: "#d97706" },
  paypal: { icon: "at-sign", c1: "#06b6d4", c2: "#0891b2" },
  stripe: { icon: "credit-card", c1: "#8b5cf6", c2: "#7c3aed" },
};

/** Generic kind label — used only when a row carries no methodLabel
 * snapshot (legacy pre-round-48 orders). */
const KIND_LABEL_KEY: Record<PaymentMethod, I18nKey> = {
  bank: "payMethodBank",
  wallet: "payMethodWallet",
  paypal: "payMethodPaypal",
  stripe: "payMethodStripe",
};

/* ---------------- KPI card (mirrors the Stores view) ---------------- */

function OrderKpi({
  label,
  value,
  icon,
  c1,
  c2,
  index,
  lang,
}: {
  label: string;
  value: React.ReactNode;
  icon: string;
  c1: string;
  c2: string;
  index: number;
  lang: Lang;
}) {
  return (
    <article
      className="glass-card card-in group relative overflow-hidden rounded-3xl p-4 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lift sm:p-5"
      style={{ "--i": index } as React.CSSProperties}
    >
      <span
        className="absolute inset-x-0 top-0 h-1 origin-center scale-x-0 transition-transform duration-300 group-hover:scale-x-100"
        style={{ backgroundImage: grad(c1, c2, 90) }}
        aria-hidden="true"
      />
      <div className="flex items-center gap-3">
        <span
          className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-white shadow-lg transition-transform duration-300 group-hover:scale-105"
          style={{ backgroundImage: grad(c1, c2) }}
        >
          <CatIcon name={icon} className="h-[18px] w-[18px]" />
        </span>
        <div className="min-w-0 flex-1">
          <p className={cn("truncate text-[10.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
            {label}
          </p>
          {/* ROUND 81 — full Arabic RTL: Arabic-Indic figures flow natively
              RTL and align to the reading edge (right) beside the Arabic
              label — the forced dir="ltr" painted them as a detached LTR
              island (numbers jumping to the wrong edge + wrong currency
              side). English keeps its LTR posture untouched. */}
          <p
            dir={lang === "en" ? "ltr" : undefined}
            className="mt-0.5 truncate text-start font-display text-[26px] font-extrabold tabular-nums leading-tight text-slate-900 dark:text-white"
          >
            {value}
          </p>
        </div>
      </div>
    </article>
  );
}

/* ---------------- order card ---------------- */

function OrderCard({
  order,
  index,
  canManage,
}: {
  order: AdminPlanOrderDTO;
  index: number;
  canManage: boolean;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  /* which confirm dialog is open (null = closed) */
  const [confirmAction, setConfirmAction] = useState<"paid" | "cancelled" | null>(null);

  const sys = SYSTEM_MAP[order.systemId];
  const method = METHOD_META[order.method];
  /* ROUND 48 — the console-defined method snapshot at order time; legacy
     rows (pre-round-48) fall back to the generic kind label */
  const methodLabel = order.methodLabel.trim() || t(KIND_LABEL_KEY[order.method]);
  const planName = lang === "ar" ? order.packageNameAr : order.packageName;
  const systemName = sys ? (lang === "ar" ? sys.nameAr : sys.nameEn) : order.systemId;
  /* ROUND 81 — full-Arabic RTL: the countdown phrase now honors the number
     agreement law (ساعتان / ساعات / ساعة) instead of a flat unit word. */
  const expires = expiresInLabel(order.expiresAt, lang, t);

  const copyRef = () => {
    copyText(order.reference)
      .then(() => toast.success(t("secCopied")))
      .catch(() => toast.error(t("errGenericAction")));
  };

  const act = useMutation({
    mutationFn: (action: "paid" | "cancelled") => adminPlanOrderAction(order.id, action),
    onSuccess: (_data, action) => {
      toast.success(t(action === "paid" ? "adminPOConfirmed" : "adminPOCancelled"));
      setConfirmAction(null);
      /* every filtered variant + the tenant lists that show plan state */
      queryClient.invalidateQueries({ queryKey: ["admin-plan-orders"] });
      queryClient.invalidateQueries({ queryKey: ["instances"] });
    },
    onError: (error: Error) => {
      toast.error(apiErrorText(error, t));
      setConfirmAction(null);
    },
  });

  const statusChip =
    order.effectiveStatus === "pending" ? (
      <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-amber-300/70 bg-amber-500/10 px-2.5 py-1 text-[10px] font-extrabold text-amber-600 dark:border-amber-500/40 dark:text-amber-300">
        <span className="relative flex h-2 w-2" aria-hidden="true">
          <span className="absolute inset-0 animate-ping rounded-full bg-amber-500/50" />
          <span className="relative m-auto h-1.5 w-1.5 rounded-full bg-amber-500" />
        </span>
        {t("orderStatusPending")}
      </span>
    ) : order.effectiveStatus === "paid" ? (
      <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-emerald-300/70 bg-emerald-500/10 px-2.5 py-1 text-[10px] font-extrabold text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300">
        <CatIcon name="badge-check" className="h-3 w-3" />
        {t("orderStatusPaid")}
      </span>
    ) : order.effectiveStatus === "cancelled" ? (
      <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-slate-300/70 bg-slate-500/10 px-2.5 py-1 text-[10px] font-extrabold text-slate-400 dark:border-white/10 dark:text-slate-500">
        <CatIcon name="circle-x" className="h-3 w-3" />
        {t("orderStatusCancelled")}
      </span>
    ) : (
      <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-rose-300/70 bg-rose-500/10 px-2.5 py-1 text-[10px] font-extrabold text-rose-600 dark:border-rose-500/40 dark:text-rose-300">
        <CatIcon name="clock" className="h-3 w-3" />
        {t("orderStatusExpired")}
      </span>
    );

  return (
    <article
      className="glass-card card-in group relative overflow-hidden rounded-3xl p-5"
      style={{ "--i": index } as React.CSSProperties}
    >
      {/* header: tenant identity + payment reference + status */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <IconTile icon={method.icon} c1={method.c1} c2={method.c2} size="md" />
          <div className="min-w-0">
            <p className="truncate font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
              {order.orgName}
            </p>
            <p className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] font-bold text-slate-400 dark:text-slate-500">
              <span className="truncate">{systemName}</span>
              <button
                type="button"
                onClick={copyRef}
                title={t("secCopyTip")}
                aria-label={`${t("adminPOReference")}: ${order.reference}`}
                className="inline-flex items-center gap-1 rounded-full border border-slate-200 bg-slate-50 px-2 py-px text-[11px] font-extrabold text-slate-500 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-400 dark:hover:text-brand-300"
              >
                <span dir="ltr" className="font-mono tracking-wide">{order.reference}</span>
                <CatIcon name="copy" className="h-2.5 w-2.5" />
              </button>
            </p>
          </div>
        </div>
        {statusChip}
      </div>

      {/* plan / amount / method / created */}
      <div className="mt-4 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
        <div className="rounded-2xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
          <p className={cn("text-[11px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500", labelTrack(lang))}>
            {t("adminPOPlan")}
          </p>
          <p className="mt-0.5 flex flex-wrap items-center gap-1.5">
            <span className="truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">{planName}</span>
            <span className="inline-flex items-center gap-1 rounded-full bg-brand-500/10 px-2 py-px text-[11px] font-extrabold text-brand-600 dark:text-brand-300">
              <CatIcon name={order.cycle === "yearly" ? "calendar-range" : "calendar-days"} className="h-2.5 w-2.5" />
              {t(order.cycle === "yearly" ? "planCycleYearly" : "planCycleMonthly")}
            </span>
          </p>
        </div>
        <div className="rounded-2xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
          <p className={cn("text-[11px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500", labelTrack(lang))}>
            {t("adminPOAmount")}
          </p>
          {/* ROUND 81 — full Arabic RTL: the currency code reads as a natural
              Arabic SUFFIX (figure first at the reading edge, currency to its
              left) — never a Latin-ordered LTR island. */}
          <p
            dir={lang === "en" ? "ltr" : undefined}
            className="mt-0.5 text-start text-[15px] font-extrabold tabular-nums text-slate-800 dark:text-slate-100"
          >
            {fmtNum(order.amount, lang)} <span className="text-[11px] font-bold text-slate-400">{order.currency}</span>
          </p>
          {/* ROUND 79 — amounts are server-computed snapshots of the live
              discounted price; the note keeps that explicit for reviewers */}
          <p className="mt-1 text-[9.5px] font-semibold text-slate-400 dark:text-slate-500">
            {t("adminPODiscountNote")}
          </p>
        </div>
        <div className="rounded-2xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
          <p className={cn("text-[11px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500", labelTrack(lang))}>
            {t("adminPOMethod")}
          </p>
          <p className="mt-0.5">
            <span
              title={methodLabel}
              className="inline-flex max-w-full items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-extrabold"
              style={{ color: method.c2, backgroundColor: `${method.c1}1f` }}
            >
              <CatIcon name={method.icon} className="h-2.5 w-2.5 shrink-0" />
              <span className="truncate">{methodLabel}</span>
            </span>
          </p>
        </div>
        <div className="rounded-2xl border border-slate-200/70 bg-white/70 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
          <p className={cn("text-[11px] font-extrabold uppercase tracking-wide text-slate-400 dark:text-slate-500", labelTrack(lang))}>
            {t("adminPOCreated")}
          </p>
          <p className="mt-0.5 truncate text-[11.5px] font-extrabold text-slate-800 dark:text-slate-100">
            {formatStamp(order.createdAt, lang)}
          </p>
        </div>
      </div>

      {/* meta line: expiry countdown / paid-at / HMAC integrity */}
      <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1.5 border-t border-slate-200/70 pt-2.5 text-[10.5px] font-bold text-slate-400 dark:border-white/[0.06] dark:text-slate-500">
        {order.effectiveStatus === "pending" && expires ? (
          <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400">
            <CatIcon name="hourglass" className="h-3 w-3" />
            {t("adminPOExpiresIn", { time: expires })}
          </span>
        ) : null}
        {order.paidAt ? (
          <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
            <CatIcon name="badge-check" className="h-3 w-3" />
            {t("adminPOPaidAt")}: {formatStamp(order.paidAt, lang)}
          </span>
        ) : null}
        {order.integrityVerified ? (
          <span
            title={t("adminPOIntegrity")}
            className="ms-auto inline-flex items-center gap-1 rounded-full border border-emerald-300/60 bg-emerald-500/[0.08] px-2 py-px text-[11px] font-extrabold text-emerald-600 dark:border-emerald-500/30 dark:text-emerald-300"
          >
            <CatIcon name="shield-check" className="h-2.5 w-2.5" />
            {t("adminPOIntegrity")}
          </span>
        ) : null}
      </div>

      {/* actions — pending, non-expired requests only (super/admin) */}
      {canManage && order.effectiveStatus === "pending" ? (
        <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-dashed border-slate-200 pt-3.5 dark:border-white/10">
          <Button
            type="button"
            onClick={() => setConfirmAction("paid")}
            className="h-9 gap-1.5 rounded-xl px-4 text-[11.5px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:brightness-110 active:scale-95"
            style={{ backgroundImage: grad("#10b981", "#059669") }}
          >
            <CatIcon name="badge-check" className="h-3.5 w-3.5" />
            {t("adminPOConfirm")}
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => setConfirmAction("cancelled")}
            className="h-9 gap-1.5 rounded-xl border-rose-200 px-4 text-[11.5px] font-bold text-rose-600 transition hover:border-rose-300 hover:text-rose-700 active:scale-95 dark:border-rose-500/30 dark:text-rose-300 dark:hover:border-rose-400/50 dark:hover:text-rose-200"
          >
            <CatIcon name="x" className="h-3.5 w-3.5" />
            {t("adminPOCancel")}
          </Button>
          {act.isPending ? (
            <span className="inline-flex items-center gap-1.5 text-[10.5px] font-extrabold text-slate-400 dark:text-slate-500">
              <CatIcon name="refresh-cw" className="h-3 w-3 animate-spin" />
            </span>
          ) : null}
        </div>
      ) : null}

      {/* confirm / cancel dialog */}
      <AlertDialog open={confirmAction !== null} onOpenChange={(o) => !o && setConfirmAction(null)}>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display text-lg font-extrabold text-slate-900 dark:text-white">
              {t(confirmAction === "paid" ? "adminPOConfirmTitle" : "adminPOCancel")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] text-slate-500 dark:text-slate-400">
              {confirmAction === "paid"
                ? t("adminPOConfirmDesc", { plan: planName, org: order.orgName })
                : `${planName} · ${order.orgName} — ${fmtNum(order.amount, lang)} ${order.currency}`}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={act.isPending}>
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => confirmAction && act.mutate(confirmAction)}
              disabled={act.isPending}
              className={cn(
                "h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:opacity-60",
                confirmAction === "paid"
                  ? "bg-emerald-600 shadow-emerald-500/25 hover:bg-emerald-700"
                  : "bg-rose-600 shadow-rose-500/25 hover:bg-rose-700"
              )}
            >
              {act.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name={confirmAction === "paid" ? "badge-check" : "x"} className="h-4 w-4" />
              )}
              {t(confirmAction === "paid" ? "adminPOConfirm" : "adminPOCancel")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </article>
  );
}

/* ---------------- view ---------------- */

export function AdminPlanOrders() {
  const { t, lang } = useT();
  const canManage = useAdminCanManage();
  const [statusFilter, setStatusFilter] = useState<OrderFilter>("all");

  /* full dataset — powers the KPI strip (stable across filter chips; deduped
     with the list query whenever the "All" chip is active) */
  const kpiQuery = useQuery({
    queryKey: ["admin-plan-orders", "all"],
    queryFn: () => fetchAdminPlanOrders(),
  });

  /* server-filtered list — refetches per status chip */
  const query = useQuery({
    queryKey: ["admin-plan-orders", statusFilter],
    queryFn: () => fetchAdminPlanOrders(statusFilter === "all" ? undefined : statusFilter),
  });

  const allOrders = useMemo(() => kpiQuery.data ?? [], [kpiQuery.data]);

  /* chips follow effectiveStatus: the "pending" chip excludes requests whose
     payment window already lapsed (they keep their rose chip under "All") */
  const orders = useMemo(() => {
    const list = query.data ?? [];
    return statusFilter === "pending" ? list.filter((o) => o.effectiveStatus === "pending") : list;
  }, [query.data, statusFilter]);

  const kpiPending = allOrders.filter((o) => o.effectiveStatus === "pending").length;
  const kpiPaid = allOrders.filter((o) => o.status === "paid").length;

  /* confirmed revenue grouped per currency → "١٩٩ SAR + ٥٠ USD" chips */
  const revenue = useMemo(() => {
    const map = new Map<string, number>();
    for (const o of allOrders) {
      if (o.status === "paid") map.set(o.currency, (map.get(o.currency) ?? 0) + o.amount);
    }
    return [...map.entries()];
  }, [allOrders]);

  const revenueLabel =
    revenue.length > 0
      ? revenue
          .slice(0, 2)
          .map(([currency, value]) => `${fmtNum(value, lang)} ${currency}`)
          .join(" + ")
      : "—";

  const kpiValue = (node: React.ReactNode, fallback = "—") =>
    kpiQuery.isPending ? <Skeleton className="h-7 w-16" /> : node ?? fallback;

  const FILTERS: { key: OrderFilter; label: string }[] = [
    { key: "all", label: t("adminPOFilterAll") },
    { key: "pending", label: t("orderStatusPending") },
    { key: "paid", label: t("orderStatusPaid") },
    { key: "cancelled", label: t("orderStatusCancelled") },
  ];

  return (
    <div className="space-y-5">
      <ViewHeading title={t("adminPOTitle")} desc={t("adminPODesc")} />

      {/* slim info banner — what confirming actually does */}
      <div className="flex items-start gap-2.5 rounded-2xl border border-cyan-200/70 bg-cyan-50/70 px-4 py-3 text-[11.5px] font-semibold leading-relaxed text-cyan-800 dark:border-cyan-500/25 dark:bg-cyan-500/[0.08] dark:text-cyan-200">
        <CatIcon name="info" className="mt-0.5 h-4 w-4 shrink-0" />
        <p>{t("adminPONote")}</p>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <OrderKpi index={0} lang={lang} icon="hourglass" c1="#f59e0b" c2="#ea580c" label={t("adminPOKpiPending")} value={kpiValue(fmtNum(kpiPending, lang), "0")} />
        <OrderKpi index={1} lang={lang} icon="circle-check" c1="#10b981" c2="#059669" label={t("adminPOKpiPaid")} value={kpiValue(fmtNum(kpiPaid, lang), "0")} />
        <OrderKpi index={2} lang={lang} icon="hand-coins" c1="#06b6d4" c2="#0891b2" label={t("adminPOKpiRevenue")} value={kpiValue(revenueLabel)} />
        <OrderKpi index={3} lang={lang} icon="receipt" c1="#6d5dfb" c2="#a855f7" label={t("adminPOFilterAll")} value={kpiValue(fmtNum(allOrders.length, lang), "0")} />
      </div>

      {/* toolbar: status filter chips + live count */}
      <DashCard>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-1.5">
            {FILTERS.map((f) => (
              <button
                key={f.key}
                type="button"
                onClick={() => setStatusFilter(f.key)}
                className={cn(
                  "h-9 rounded-xl px-3.5 text-[11.5px] font-extrabold transition active:scale-95",
                  statusFilter === f.key
                    ? "bg-linear-to-r from-brand-600 to-brand-500 text-white shadow-lg shadow-brand-500/25"
                    : "border border-slate-200 bg-white/70 text-slate-500 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:text-brand-300"
                )}
              >
                {f.label}
              </button>
            ))}
          </div>
          <Badge variant="secondary" className="rounded-full px-3 py-1 text-[11px] font-extrabold text-slate-600 dark:text-slate-300">
            {fmtNum(orders.length, lang)} / {fmtNum(allOrders.length, lang)}
          </Badge>
        </div>
      </DashCard>

      {/* orders list */}
      {query.isPending ? (
        <div className="grid gap-4 lg:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-64 w-full rounded-3xl" />
          ))}
        </div>
      ) : query.isError ? (
        <DashCard>
          <div className="py-12 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-rose-100 text-rose-500 dark:bg-rose-500/10 dark:text-rose-300">
              <CatIcon name="circle-alert" className="h-6 w-6" />
            </div>
            <p className="mt-3 font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("errorText")}
            </p>
            <Button
              type="button"
              variant="outline"
              onClick={() => query.refetch()}
              className="mt-4 h-10 gap-2 rounded-xl border-slate-200 px-5 text-[12.5px] font-bold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:text-slate-300"
            >
              <CatIcon name="refresh-cw" className="h-4 w-4" />
              {t("retryText")}
            </Button>
          </div>
        </DashCard>
      ) : orders.length === 0 ? (
        /* premium dashed empty card */
        <div className="rounded-3xl border-2 border-dashed border-slate-300/70 bg-white/50 p-10 text-center dark:border-white/10 dark:bg-white/[0.02]">
          <span className="mx-auto grid h-16 w-16 place-items-center rounded-3xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
            <CatIcon name="receipt" className="h-7 w-7" />
          </span>
          <p className="mt-4 text-[13px] font-extrabold text-slate-600 dark:text-slate-300">
            {t("adminPOEmpty")}
          </p>
          <p className="mx-auto mt-1 max-w-sm text-[11.5px] font-semibold text-slate-400 dark:text-slate-500">
            {t("adminPONote")}
          </p>
        </div>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {orders.map((order, i) => (
            <OrderCard key={order.id} order={order} index={i} canManage={canManage} />
          ))}
        </div>
      )}

      {/* ROUND 141 — متجر الإضافات: the console's add-on purchase queue
          rides directly under the plan queue (one Payments view). */}
      <AdminAddonOrders canManage={canManage} />

      {/* ROUND 141 (wallet) — the wallet top-up requests queue: confirming
          credits the tenant's Ashrilogic wallet ATOMICALLY (the CAS balance
          flip + the ledger row in one transaction). */}
      <AdminWalletTopups canManage={canManage} />
    </div>
  );
}

/* ================================================================== */
/* ROUND 141 — the add-on orders queue (طلبات الإضافات)                */
/* ================================================================== */

/** One console row of the add-on queue: org identity + the ordered feature
 *  labels + amount + status + the confirm/cancel actions. Confirming
 *  force-ONs the ordered features on the workspace instantly. */
function AddonOrderCard({
  order,
  index,
  canManage,
}: {
  order: AdminAddonOrderDTO;
  index: number;
  canManage: boolean;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const [pendingAction, setPendingAction] = useState<"paid" | "cancelled" | null>(null);

  const act = useMutation({
    mutationFn: (action: "paid" | "cancelled") => adminAddonOrderAction(order.id, action),
    onSuccess: (result, action) => {
      toast.success(
        action === "paid"
          ? t("adminAddonConfirmed", { n: String(result.activatedFeatures.length) })
          : t("adminAddonCancelled")
      );
      setPendingAction(null);
      void queryClient.invalidateQueries({ queryKey: ["admin-addon-orders"] });
    },
    onError: (error: unknown) => toast.error(apiErrorText(error, t)),
  });

  const method = METHOD_META[order.method] ?? METHOD_META.bank;
  const expiry = order.effectiveStatus === "pending" ? expiresInLabel(order.expiresAt, lang, t) : null;

  return (
    <article
      className="card-in relative overflow-hidden rounded-3xl border border-slate-200/80 bg-white/80 p-5 dark:border-white/[0.07] dark:bg-white/[0.03]"
      style={{ animationDelay: `${Math.min(index, 8) * 60}ms` }}
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate font-display text-[14px] font-extrabold text-slate-800 dark:text-slate-100">
            {order.orgName || order.instanceId.slice(0, 10)}
          </p>
          <p dir="ltr" className="mt-0.5 truncate font-mono text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
            {order.reference}
          </p>
        </div>
        <span
          className={cn(
            "shrink-0 rounded-full border px-2.5 py-1 text-[10px] font-extrabold",
            order.effectiveStatus === "pending"
              ? "border-amber-300/70 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300"
              : order.effectiveStatus === "paid"
                ? "border-emerald-300/70 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
                : order.effectiveStatus === "expired"
                  ? "border-rose-300/70 bg-rose-500/10 text-rose-500 dark:border-rose-500/40 dark:text-rose-300"
                  : "border-slate-300/70 bg-slate-500/10 text-slate-500 dark:border-white/10 dark:text-slate-400"
          )}
        >
          {t(
            order.effectiveStatus === "pending"
              ? "orderStatusPending"
              : order.effectiveStatus === "paid"
                ? "orderStatusPaid"
                : order.effectiveStatus === "expired"
                  ? "addonStatusExpired"
                  : "orderStatusCancelled"
          )}
        </span>
      </div>

      {/* the ordered add-ons */}
      <div className="mt-3 flex flex-wrap gap-1.5">
        {order.features.map((feature) => {
          const meta = FEATURE_META[feature as PlanFeature];
          return (
            <span
              key={feature}
              className="inline-flex items-center gap-1 rounded-full border border-violet-300/60 bg-violet-500/10 px-2 py-0.5 text-[10px] font-extrabold text-violet-600 dark:border-violet-500/40 dark:bg-violet-500/10 dark:text-violet-300"
            >
              <CatIcon name={meta?.icon ?? "puzzle"} className="h-2.5 w-2.5" />
              {t(meta?.labelKey ?? "dashAddons")}
            </span>
          );
        })}
      </div>

      {/* meta line: amount + cycle + method + date */}
      <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1.5 border-t border-dashed border-slate-200/80 pt-3 text-[10.5px] font-bold text-slate-400 dark:border-white/10 dark:text-slate-500">
        <span dir="ltr" className="font-display text-[13px] font-extrabold tabular-nums text-slate-700 dark:text-slate-200">
          {fmtNum(order.amount, lang)} {order.currency}
        </span>
        <span className="inline-flex items-center gap-1">
          <CatIcon name="repeat" className="h-3 w-3" />
          {t(order.cycle === "yearly" ? "addonsCycleYearly" : "addonsCycleMonthly")}
        </span>
        <span className="inline-flex items-center gap-1">
          <CatIcon name={method.icon} className="h-3 w-3" />
          {order.methodLabel || t("payMethodBank")}
        </span>
        <span className="inline-flex items-center gap-1">
          <CatIcon name="clock" className="h-3 w-3" />
          {formatStamp(order.createdAt, lang)}
        </span>
        {expiry ? (
          <span className="inline-flex items-center gap-1 text-amber-500">
            <CatIcon name="hourglass" className="h-3 w-3" />
            {expiry}
          </span>
        ) : null}
        {order.integrityVerified ? (
          <span className="inline-flex items-center gap-1 text-emerald-500" title={t("orderIntegrityOk")}>
            <CatIcon name="shield-check" className="h-3 w-3" />
          </span>
        ) : null}
      </div>

      {/* actions */}
      {order.effectiveStatus === "pending" && canManage ? (
        <div className="mt-3.5 flex items-center gap-2">
          <Button
            type="button"
            disabled={act.isPending}
            onClick={() => setPendingAction("paid")}
            className="h-9 flex-1 gap-1.5 rounded-xl bg-linear-to-r from-emerald-500 to-emerald-600 px-4 text-[11.5px] font-extrabold text-white shadow-md shadow-emerald-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
          >
            <CatIcon name="circle-check" className="h-3.5 w-3.5" />
            {t("adminPOConfirmBtn")}
          </Button>
          <Button
            type="button"
            disabled={act.isPending}
            onClick={() => setPendingAction("cancelled")}
            className="h-9 gap-1.5 rounded-xl border border-rose-200 bg-white px-4 text-[11.5px] font-bold text-rose-600 transition hover:bg-rose-500/10 active:scale-95 disabled:opacity-60 dark:border-rose-500/30 dark:bg-white/[0.04] dark:text-rose-300"
          >
            <CatIcon name="x" className="h-3.5 w-3.5" />
            {t("adminPOCancelBtn")}
          </Button>
        </div>
      ) : null}

      {/* the confirm dialog */}
      <AlertDialog open={pendingAction !== null} onOpenChange={(o) => !o && setPendingAction(null)}>
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg"
                style={{
                  backgroundImage:
                    pendingAction === "paid"
                      ? "linear-gradient(135deg,#10b981,#059669)"
                      : "linear-gradient(135deg,#f43f5e,#e11d48)",
                }}
                aria-hidden="true"
              >
                <CatIcon name={pendingAction === "paid" ? "circle-check" : "x"} className="h-4 w-4" />
              </span>
              {pendingAction === "paid" ? t("adminAddonConfirmTitle") : t("adminPOCancelTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {pendingAction === "paid" ? t("adminAddonConfirmDesc") : t("adminPOCancelDesc")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={act.isPending}>
              {t("modRecCancelBtn")}
            </AlertDialogCancel>
            <AlertDialogAction
              disabled={act.isPending}
              onClick={() => pendingAction && act.mutate(pendingAction)}
              className={cn(
                "h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg",
                pendingAction === "paid"
                  ? "bg-linear-to-r from-emerald-500 to-emerald-600"
                  : "bg-linear-to-r from-rose-500 to-rose-600"
              )}
            >
              {act.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : (
                <CatIcon name={pendingAction === "paid" ? "check" : "x"} className="h-4 w-4" />
              )}
              {pendingAction === "paid" ? t("adminPOConfirmBtn") : t("adminPOCancelBtn")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </article>
  );
}

/** The add-on queue section: KPI chips + filter + the cards. */
function AdminAddonOrders({ canManage }: { canManage: boolean }) {
  const { t, lang } = useT();
  const [statusFilter, setStatusFilter] = useState<OrderFilter>("pending");

  const query = useQuery({
    queryKey: ["admin-addon-orders", statusFilter],
    queryFn: () => fetchAdminAddonOrders(statusFilter === "all" ? undefined : statusFilter),
  });

  const orders = useMemo(() => {
    const list = query.data ?? [];
    return statusFilter === "pending" ? list.filter((o) => o.effectiveStatus === "pending") : list;
  }, [query.data, statusFilter]);

  const pendingCount = orders.filter((o) => o.effectiveStatus === "pending").length;

  return (
    <DashCard
      title={t("adminAddonsTitle")}
      icon="puzzle"
      action={
        <span className="rounded-full border border-violet-300/60 bg-violet-500/10 px-2.5 py-0.5 text-[10.5px] font-extrabold text-violet-600 dark:border-violet-500/40 dark:text-violet-300">
          {fmtNum(pendingCount, lang)}
        </span>
      }
    >
      {/* filter chips */}
      <div className="mb-3.5 flex flex-wrap items-center gap-1.5">
        {(
          [
            { key: "pending", label: t("orderStatusPending") },
            { key: "all", label: t("adminPOFilterAll") },
            { key: "paid", label: t("orderStatusPaid") },
            { key: "cancelled", label: t("orderStatusCancelled") },
          ] as { key: OrderFilter; label: string }[]
        ).map((f) => (
          <button
            key={f.key}
            type="button"
            onClick={() => setStatusFilter(f.key)}
            className={cn(
              "h-8 rounded-xl px-3 text-[11px] font-extrabold transition active:scale-95",
              statusFilter === f.key
                ? "bg-linear-to-r from-violet-600 to-fuchsia-500 text-white shadow-lg shadow-violet-500/25"
                : "border border-slate-200 bg-white/70 text-slate-500 hover:border-violet-300 hover:text-violet-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:text-violet-300"
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      {query.isPending ? (
        <div className="grid gap-3 lg:grid-cols-2">
          {Array.from({ length: 2 }).map((_, i) => (
            <Skeleton key={i} className="h-48 rounded-3xl" />
          ))}
        </div>
      ) : orders.length === 0 ? (
        <p className="rounded-2xl border-2 border-dashed border-slate-200 py-6 text-center text-[12px] font-bold text-slate-400 dark:border-white/10 dark:text-slate-500">
          {t("adminAddonsEmpty")}
        </p>
      ) : (
        <div className="grid gap-3 lg:grid-cols-2">
          {orders.map((order, i) => (
            <AddonOrderCard key={order.id} order={order} index={i} canManage={canManage} />
          ))}
        </div>
      )}

      <p className="mt-3 text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
        {t("adminAddonsNote")}
      </p>
    </DashCard>
  );
}

export default AdminPlanOrders;

/* ================================================================== */
/* ROUND 141 (wallet) — the wallet top-up requests queue                */
/* ================================================================== */

/** One console row of the top-up queue: workspace identity + the requested
 *  amount + method chip + reference + status + confirm/cancel. Confirming
 *  credits the wallet atomically (CAS + ledger row in one transaction). */
function WalletTopupCard({
  topup,
  index,
  canManage,
}: {
  topup: AdminWalletTopupDTO;
  index: number;
  canManage: boolean;
}) {
  const { t, lang } = useT();
  const queryClient = useQueryClient();
  const [pendingAction, setPendingAction] = useState<"paid" | "cancelled" | null>(null);

  const act = useMutation({
    mutationFn: (action: "paid" | "cancelled") => adminWalletTopupAction(topup.id, action),
    onSuccess: (_result, action) => {
      toast.success(action === "paid" ? t("adminWalletConfirmed") : t("adminWalletCancelled"));
      setPendingAction(null);
      void queryClient.invalidateQueries({ queryKey: ["admin-wallet-topups"] });
    },
    onError: (error: unknown) => toast.error(apiErrorText(error, t)),
  });

  const method = METHOD_META[topup.method] ?? METHOD_META.bank;
  const expired = topup.effectiveStatus === "expired";
  const amountMajor = topup.amountMinor / 100;

  return (
    <article
      className="glass-card card-in group relative overflow-hidden rounded-3xl p-4"
      style={{ animationDelay: `${Math.min(index, 6) * 45}ms` }}
    >
      {/* header: workspace identity + amount */}
      <div className="flex flex-wrap items-center gap-3">
        <span
          className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
          style={{ backgroundImage: grad("#059669", "#0f766e"), boxShadow: "0 10px 24px -10px rgba(5,150,105,0.7)" }}
          aria-hidden="true"
        >
          <CatIcon name="wallet" className="h-5 w-5" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
            {topup.orgName || topup.systemId || "—"}
          </p>
          <p dir="ltr" className="mt-0.5 truncate font-mono text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
            {topup.reference}
          </p>
        </div>
        <div className="shrink-0 text-end">
          <p dir="ltr" className="font-display text-[19px] font-extrabold leading-none tabular-nums text-slate-900 dark:text-white">
            {fmtNum(amountMajor, lang)}
            <span className="ms-1 text-[10px] font-bold text-slate-400">{topup.currency}</span>
          </p>
          <p className="mt-1 text-[10px] font-bold text-slate-400 dark:text-slate-500">
            {formatStamp(topup.createdAt, lang)}
          </p>
        </div>
      </div>

      {/* chips: method + integrity + status */}
      <div className="mt-3 flex flex-wrap items-center gap-1.5">
        <span
          className="inline-flex items-center gap-1 rounded-full px-2 py-px text-[10.5px] font-extrabold"
          style={{ color: method.c2, backgroundColor: `${method.c1}1f` }}
        >
          <CatIcon name={method.icon} className="h-2.5 w-2.5" />
          {topup.methodLabel || t(KIND_LABEL_KEY[topup.method])}
        </span>
        {topup.integrityVerified ? (
          <span
            title={t("orderIntegrityOk")}
            className="inline-flex items-center gap-1 rounded-full border border-emerald-300/60 bg-emerald-500/[0.08] px-2 py-px text-[10.5px] font-extrabold text-emerald-600 dark:border-emerald-500/30 dark:text-emerald-300"
          >
            <CatIcon name="shield-check" className="h-2.5 w-2.5" />
            {t("orderIntegrityOk")}
          </span>
        ) : null}
        <span
          className={cn(
            "inline-flex items-center gap-1 rounded-full px-2 py-px text-[10.5px] font-extrabold",
            topup.effectiveStatus === "paid"
              ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-300"
              : topup.effectiveStatus === "pending"
                ? "bg-amber-500/15 text-amber-600 dark:text-amber-300"
                : "bg-slate-500/10 text-slate-500 dark:text-slate-400"
          )}
        >
          <CatIcon
            name={topup.effectiveStatus === "paid" ? "circle-check" : topup.effectiveStatus === "pending" ? "hourglass" : "circle-x"}
            className="h-2.5 w-2.5"
          />
          {t(
            topup.effectiveStatus === "pending"
              ? "orderStatusPending"
              : topup.effectiveStatus === "paid"
                ? "orderStatusPaid"
                : topup.effectiveStatus === "expired"
                  ? "addonStatusExpired"
                  : "orderStatusCancelled"
          )}
        </span>
      </div>

      {/* actions */}
      {canManage && topup.status === "pending" && !expired ? (
        <div className="mt-3.5 flex flex-wrap items-center gap-2 border-t border-dashed border-slate-200/80 pt-3 dark:border-white/10">
          <Button
            type="button"
            onClick={() => setPendingAction("paid")}
            disabled={act.isPending}
            className="h-9 gap-1.5 rounded-xl bg-linear-to-l from-emerald-600 to-teal-500 px-4 text-[11.5px] font-extrabold text-white shadow-lg shadow-emerald-500/20 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
          >
            <CatIcon name="circle-check" className="h-3.5 w-3.5" />
            {t("adminPOConfirmBtn")}
          </Button>
          <Button
            type="button"
            onClick={() => setPendingAction("cancelled")}
            disabled={act.isPending}
            className="h-9 gap-1.5 rounded-xl border border-rose-200 px-4 text-[11.5px] font-extrabold text-rose-600 transition hover:border-rose-300 hover:bg-rose-500/10 active:scale-95 disabled:opacity-60 dark:border-rose-500/30 dark:text-rose-300"
          >
            <CatIcon name="x" className="h-3.5 w-3.5" />
            {t("adminPOCancelBtn")}
          </Button>
        </div>
      ) : null}

      {/* the confirm/cancel ceremony (the plan-orders idiom) */}
      <AlertDialog open={pendingAction !== null} onOpenChange={(o) => !o && setPendingAction(null)}>
        <AlertDialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5 text-[15px] font-extrabold">
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white"
                style={{
                  backgroundImage:
                    pendingAction === "paid"
                      ? "linear-gradient(135deg,#10b981,#047857)"
                      : "linear-gradient(135deg,#f43f5e,#e11d48)",
                }}
                aria-hidden="true"
              >
                <CatIcon name={pendingAction === "paid" ? "circle-check" : "x"} className="h-4 w-4" />
              </span>
              {pendingAction === "paid" ? t("adminWalletConfirmTitle") : t("adminPOCancelTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {pendingAction === "paid"
                ? t("adminWalletConfirmDesc", {
                    amount: fmtNum(amountMajor, lang),
                    org: topup.orgName || topup.systemId || "—",
                  })
                : t("adminPOCancelDesc")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl px-5 text-[12.5px] font-bold" disabled={act.isPending}>
              {t("modRecCancelBtn")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => pendingAction && act.mutate(pendingAction)}
              disabled={act.isPending}
              className={cn(
                "h-10 gap-2 rounded-xl px-5 text-[12.5px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:opacity-60",
                pendingAction === "paid"
                  ? "bg-linear-to-l from-emerald-600 to-teal-500"
                  : "bg-linear-to-l from-rose-600 to-red-500"
              )}
            >
              {act.isPending ? <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" /> : null}
              {pendingAction === "paid" ? t("adminPOConfirmBtn") : t("adminPOCancelBtn")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </article>
  );
}

/** The wallet top-ups queue section: KPI chips + filter + the cards. */
function AdminWalletTopups({ canManage }: { canManage: boolean }) {
  const { t, lang } = useT();
  const [statusFilter, setStatusFilter] = useState<OrderFilter>("pending");

  const query = useQuery({
    queryKey: ["admin-wallet-topups", statusFilter],
    queryFn: () => fetchAdminWalletTopups(statusFilter === "all" ? undefined : statusFilter),
  });

  const topups = useMemo(() => {
    const list = query.data ?? [];
    return statusFilter === "pending" ? list.filter((o) => o.effectiveStatus === "pending") : list;
  }, [query.data, statusFilter]);

  const pendingCount = topups.filter((o) => o.effectiveStatus === "pending").length;

  return (
    <DashCard
      title={t("adminWalletQueueTitle")}
      icon="wallet"
      action={
        <span className="rounded-full border border-emerald-300/60 bg-emerald-500/10 px-2.5 py-0.5 text-[10.5px] font-extrabold text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300">
          {fmtNum(pendingCount, lang)}
        </span>
      }
    >
      {/* filter chips */}
      <div className="mb-3.5 flex flex-wrap items-center gap-1.5">
        {(
          [
            { key: "pending", label: t("orderStatusPending") },
            { key: "all", label: t("adminPOFilterAll") },
            { key: "paid", label: t("orderStatusPaid") },
            { key: "cancelled", label: t("orderStatusCancelled") },
          ] as { key: OrderFilter; label: string }[]
        ).map((f) => (
          <button
            key={f.key}
            type="button"
            onClick={() => setStatusFilter(f.key)}
            className={cn(
              "h-8 rounded-xl px-3 text-[11px] font-extrabold transition active:scale-95",
              statusFilter === f.key
                ? "bg-linear-to-r from-emerald-600 to-teal-500 text-white shadow-lg shadow-emerald-500/25"
                : "border border-slate-200 bg-white/70 text-slate-500 hover:border-emerald-300 hover:text-emerald-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:text-emerald-300"
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      {query.isPending ? (
        <div className="grid gap-3 lg:grid-cols-2">
          {Array.from({ length: 2 }).map((_, i) => (
            <Skeleton key={i} className="h-40 rounded-3xl" />
          ))}
        </div>
      ) : topups.length === 0 ? (
        <p className="rounded-2xl border-2 border-dashed border-slate-200 py-6 text-center text-[12px] font-bold text-slate-400 dark:border-white/10 dark:text-slate-500">
          {t("adminWalletQueueEmpty")}
        </p>
      ) : (
        <div className="grid gap-3 lg:grid-cols-2">
          {topups.map((topup, i) => (
            <WalletTopupCard key={topup.id} topup={topup} index={i} canManage={canManage} />
          ))}
        </div>
      )}

      <p className="mt-3 text-[11px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
        {t("adminWalletQueueNote")}
      </p>
    </DashCard>
  );
}
