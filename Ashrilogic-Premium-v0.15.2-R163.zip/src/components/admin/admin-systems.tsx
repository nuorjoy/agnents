"use client";

/**
 * Ashrilogic — admin systems view (the 102-systems catalog + LIVE adoption).
 *
 * ROUND 136 — the catalog browser is no longer purely static: the view fetches
 * the admin instances directory (GET /api/instances — admin session, the same
 * ["instances"] react-query cache every console surface shares) and computes
 * per-systemId ADOPTION live — how many provisioned workspaces run each of
 * the 102 systems, split real vs demo. Rendered as:
 *   • a top KPI band — systems in live use / total live instances / the
 *     most-adopted system,
 *   • per-category headers with the sector's provisioned total,
 *   • per-system cards with an emerald adoption chip (demo count secondary),
 *     next to the existing module-count identity.
 *
 * Search + category grouping + every pre-existing card idiom (glass-card,
 * grad, IconTile, the bilingual sub-line) are unchanged; the adoption layer
 * is additive and degrades to the former static view if the directory query
 * fails.
 */
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { CATEGORIES, SYSTEMS, systemMods } from "@/data/catalog";
import { fetchInstances } from "@/lib/api-client";
import { useT } from "@/lib/i18n";
import type { SystemDef } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { cn, fmtNum, grad, labelTrack, normalizeSearch } from "@/lib/utils";
import { IconTile, ViewHeading } from "@/components/dashboard/dash-shared";

function matchesSearch(sys: SystemDef, q: string): boolean {
  if (!q) return true;
  const haystack = [sys.id, sys.nameAr, sys.nameEn].join(" ");
  return normalizeSearch(haystack).includes(q);
}

/** Live adoption posture for one systemId (from the instances directory). */
interface Adoption {
  total: number;
  demo: number;
}

export function AdminSystems() {
  const { t, lang } = useT();
  const [search, setSearch] = useState("");

  /* ROUND 136 — the live instances directory (admin session; the shared
   * ["instances"] cache key keeps adoption in sync with the subscribers
   * view's mutations). */
  const instancesQuery = useQuery({
    queryKey: ["instances"],
    queryFn: fetchInstances,
  });

  const adoption = useMemo(() => {
    const map = new Map<string, Adoption>();
    const rows = instancesQuery.data ?? [];
    for (const inst of rows) {
      const current = map.get(inst.systemId) ?? { total: 0, demo: 0 };
      current.total += 1;
      if (inst.demo) current.demo += 1;
      map.set(inst.systemId, current);
    }
    return map;
  }, [instancesQuery.data]);

  const adoptedSystems = adoption.size;
  const totalInstances = useMemo(
    () => [...adoption.values()].reduce((sum, a) => sum + a.total, 0),
    [adoption]
  );
  const mostAdopted = useMemo(() => {
    let best: { sys: SystemDef; count: number } | null = null;
    for (const [systemId, a] of adoption) {
      if (!best || a.total > best.count) {
        const sys = SYSTEMS.find((s) => s.id === systemId);
        if (sys) best = { sys, count: a.total };
      }
    }
    return best;
  }, [adoption]);

  const filteredByCat = useMemo(() => {
    const q = normalizeSearch(search.trim());
    return CATEGORIES.map((cat) => {
      const systems = SYSTEMS.filter((s) => s.c === cat.id && matchesSearch(s, q));
      return { cat, systems };
    }).filter((g) => g.systems.length > 0);
  }, [search]);

  const totalShown = useMemo(
    () => filteredByCat.reduce((sum, g) => sum + g.systems.length, 0),
    [filteredByCat]
  );

  const kpis: { icon: string; c1: string; c2: string; label: string; value: string; sub?: string }[] = [
    {
      icon: "circle-check",
      c1: "#10b981",
      c2: "#059669",
      label: t("sysKpiAdopted"),
      value: `${fmtNum(adoptedSystems, lang)} / ${fmtNum(SYSTEMS.length, lang)}`,
    },
    {
      icon: "boxes",
      c1: "#0ea5e9",
      c2: "#0284c7",
      label: t("sysKpiInstances"),
      value: fmtNum(totalInstances, lang),
    },
    {
      icon: "crown",
      c1: "#f59e0b",
      c2: "#d97706",
      label: t("sysKpiTopSystem"),
      value: mostAdopted
        ? lang === "ar"
          ? mostAdopted.sys.nameAr
          : mostAdopted.sys.nameEn
        : t("sysMostAdoptedNone"),
      sub: mostAdopted ? fmtNum(mostAdopted.count, lang) : undefined,
    },
  ];

  return (
    <div className="space-y-5">
      <ViewHeading title={t("adminSystems")} desc={t("adminSubtitle")} />

      {/* ROUND 136 — live adoption KPI band (degrades to skeletons while the
          directory resolves; the catalog below never depends on it) */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        {kpis.map((kpi) => (
          <div key={kpi.label} className="glass-card card-in rounded-2xl p-4">
            <div className="flex items-center gap-3">
              <span
                className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-lg"
                style={{ backgroundImage: grad(kpi.c1, kpi.c2) }}
                aria-hidden="true"
              >
                <CatIcon name={kpi.icon} className="h-[14px] w-[14px]" />
              </span>
              <div className="min-w-0 flex-1">
                <p className={cn("text-[10.5px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                  {kpi.label}
                </p>
                {instancesQuery.isPending ? (
                  <Skeleton className="mt-1 h-5 w-24" />
                ) : (
                  <p className="mt-0.5 flex items-baseline gap-1.5 truncate font-display text-[16px] font-extrabold text-slate-900 dark:text-white">
                    {kpi.value}
                    {kpi.sub ? (
                      <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-300">
                        ({kpi.sub})
                      </span>
                    ) : null}
                  </p>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
      <p className="flex items-center gap-1.5 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
        <CatIcon name="lock" className="h-3 w-3 shrink-0" />
        {t("sysAdoptionNote")}
      </p>

      {/* search */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative max-w-md flex-1">
          <CatIcon
            name="search"
            className="pointer-events-none absolute start-3.5 top-1/2 h-[13px] w-[13px] -translate-y-1/2 text-slate-400"
          />
          <Input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t("adminSearchPh")}
            aria-label={t("adminSearchPh")}
            className="h-10 rounded-xl border-slate-200 bg-slate-50/80 ps-10 pe-3 text-[12.5px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:focus:bg-white/[0.07]"
          />
        </div>
        <Badge
          variant="secondary"
          className="self-start rounded-full px-3 py-1 text-[11px] font-extrabold text-slate-600 dark:text-slate-300 sm:self-auto"
        >
          {fmtNum(totalShown, lang)} / {fmtNum(SYSTEMS.length, lang)} {t("adminCatalogCount")}
        </Badge>
      </div>

      {/* catalog grouped by category */}
      <div className="space-y-7">
        {filteredByCat.map(({ cat, systems }) => {
          const catAdopted = systems.reduce((sum, s) => sum + (adoption.get(s.id)?.total ?? 0), 0);
          return (
            <section key={cat.id} aria-label={lang === "ar" ? cat.nameAr : cat.nameEn}>
              <header className="mb-3 flex items-center gap-3">
                <IconTile icon={cat.icon} c1={cat.c1} c2={cat.c2} />
                <div className="min-w-0 flex-1">
                  <h2 className="truncate font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                    {lang === "ar" ? cat.nameAr : cat.nameEn}
                  </h2>
                  <p className="flex flex-wrap items-center gap-x-2 text-[11px] font-bold text-slate-400 dark:text-slate-500">
                    <span>
                      {fmtNum(systems.length, lang)} {t("adminSystems")} ·{" "}
                      {fmtNum(cat.mods.length, lang)} {t("adminModulesEnabled")}
                    </span>
                    {catAdopted > 0 ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-extrabold text-emerald-700 dark:text-emerald-300">
                        <CatIcon name="trending-up" className="h-2.5 w-2.5" />
                        {t("sysCatAdoption", { n: fmtNum(catAdopted, lang) })}
                      </span>
                    ) : null}
                  </p>
                </div>
              </header>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {systems.map((sys) => {
                  const adopted = adoption.get(sys.id);
                  return (
                    <article
                      key={sys.id}
                      className="glass-card card-in group rounded-2xl p-4 transition-shadow duration-300 hover:shadow-lift"
                    >
                      <div className="flex items-start gap-3">
                        <span
                          className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-lg"
                          style={{
                            backgroundImage: `linear-gradient(135deg, ${cat.c1}, ${cat.c2})`,
                          }}
                          aria-hidden="true"
                        >
                          <CatIcon name={sys.icon} className="h-[14px] w-[14px]" />
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="truncate font-display text-[13px] font-extrabold text-slate-900 dark:text-white">
                            {lang === "ar" ? sys.nameAr : sys.nameEn}
                          </p>
                          {/* ROUND 85 — the opposite-language name replaces the
                              hidden SYS-xxx code as the card's sub-line */}
                          <p dir={lang === "ar" ? "ltr" : "rtl"} className="truncate text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                            {lang === "ar" ? sys.nameEn : sys.nameAr}
                          </p>
                        </div>
                      </div>
                      <p className="mt-2.5 line-clamp-2 text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                        {lang === "ar" ? sys.descAr : sys.descEn}
                      </p>
                      <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-3 dark:border-white/[0.06]">
                        <Badge className="rounded-full bg-brand-500/10 px-2.5 py-0.5 text-[11px] font-extrabold text-brand-600 dark:text-brand-300">
                          {/* round 29 — the system's EFFECTIVE module count (specialized
                              systems override the category set) */}
                          {fmtNum(systemMods(sys).length, lang)} {t("adminModulesEnabled")}
                        </Badge>
                        <CatIcon
                          name="arrow-left"
                          className="h-3.5 w-3.5 text-slate-300 transition group-hover:text-brand-500 rtl:rotate-180 dark:text-slate-600"
                        />
                      </div>
                      {/* ROUND 136 — the LIVE adoption chip (emerald count, demo
                          secondary); zero-adoption systems say so honestly */}
                      <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
                        {adopted && adopted.total > 0 ? (
                          <>
                            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2.5 py-0.5 text-[10.5px] font-extrabold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
                              <CatIcon name="circle-check" className="h-2.5 w-2.5" />
                              {t("sysAdoptedChip", { n: fmtNum(adopted.total, lang) })}
                            </span>
                            {adopted.demo > 0 ? (
                              <span className="inline-flex items-center gap-1 rounded-full bg-violet-500/10 px-2.5 py-0.5 text-[10px] font-extrabold text-violet-700 dark:bg-violet-500/15 dark:text-violet-300">
                                <CatIcon name="flask-conical" className="h-2.5 w-2.5" />
                                {t("sysAdoptedDemoChip", { n: fmtNum(adopted.demo, lang) })}
                              </span>
                            ) : null}
                          </>
                        ) : (
                          <span className="inline-flex items-center gap-1 rounded-full bg-slate-500/[0.08] px-2.5 py-0.5 text-[10px] font-bold text-slate-400 dark:bg-white/10 dark:text-slate-500">
                            <CatIcon name="circle-dot" className="h-2.5 w-2.5" />
                            {t("sysZeroAdoption")}
                          </span>
                        )}
                      </div>
                    </article>
                  );
                })}
              </div>
            </section>
          );
        })}

        {filteredByCat.length === 0 ? (
          <div className="py-14 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5">
              <CatIcon name="search" className="h-6 w-6" />
            </div>
            <p className="mt-3 font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("adminNoSubscribers")}
            </p>
          </div>
        ) : null}
      </div>
    </div>
  );
}

export default AdminSystems;
