"use client";

/**
 * ROUND 89 — the SMART PACKAGE QUOTA EDITOR (حصة الباقة الذكية).
 *
 * Owner directive: «عند حقل حصة الباقة اجعله ذكي جداً واحترافي» — the
 * three plain number inputs (users / modules / storage) inside the package
 * dialog are replaced by one engineered quota cockpit:
 *
 *  ① SMART RECOMMENDATION — a live engine (recommendQuota) that positions
 *     this plan's monthly price among the platform's OTHER active packages
 *     and interpolates a proportional triplet (log-aware for users, linear
 *     for modules, GB-aware for storage), snapping to professional round
 *     numbers. With fewer than two comparison plans it falls back to the
 *     standard price ladder. One tap applies it.
 *  ② QUICK PRESETS — the three platform tier triplets as chips
 *     (الأساسية / الاحترافية / المؤسسات); the current triplet auto-badges
 *     «مخصص» the moment it matches no preset.
 *  ③ THREE SMART ROWS — each quota gets a gradient icon tile, a live
 *     capacity LEVEL badge (خفيف / متوازن / عالي / أقصى), a log-scale
 *     slider with smart steppers (the step grows with the value), a
 *     precision number input, and a contextual business hint (team size,
 *     module count, human-readable bytes + platform-ceiling percent).
 *
 * The parent owns the string form fields exactly as before (the submit
 * path and server schema are untouched: users 1..10000, modules 1..200,
 * storage 0..10240 MB — server-enforced on every workspace write).
 */

import { useMemo } from "react";
import { toast } from "sonner";
import { useT, type I18nKey } from "@/lib/i18n";
import type { PackageDTO } from "@/lib/types";
import { formatBytes } from "@/lib/image-tools";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";

/* ------------------------------------------------------------------ */
/* bounds + presets (mirror the write schema in admin-mapper.ts)       */
/* ------------------------------------------------------------------ */

export const QUOTA_BOUNDS = {
  users: { min: 1, max: 10000 },
  modules: { min: 1, max: 200 },
  storage: { min: 0, max: 10240 },
} as const;

/** the platform's standard tier triplets (admin-mapper defaults). */
export const QUOTA_PRESETS: Record<"starter" | "professional" | "enterprise", QuotaTriplet> = {
  starter: { users: 5, modules: 10, storage: 512 },
  professional: { users: 25, modules: 50, storage: 2048 },
  enterprise: { users: 10000, modules: 200, storage: 10240 },
};

export interface QuotaTriplet {
  users: number;
  modules: number;
  storage: number;
}

/* ------------------------------------------------------------------ */
/* the recommendation engine (pure, no React)                          */
/* ------------------------------------------------------------------ */

/** snap a users figure to a professional round number. */
function niceUsers(v: number): number {
  const r = v <= 20 ? 1 : v <= 200 ? 5 : 50;
  return Math.max(QUOTA_BOUNDS.users.min, Math.min(QUOTA_BOUNDS.users.max, Math.round(v / r) * r));
}
function niceModules(v: number): number {
  const r = v <= 15 ? 1 : 5;
  return Math.max(QUOTA_BOUNDS.modules.min, Math.min(QUOTA_BOUNDS.modules.max, Math.round(v / r) * r));
}
function niceStorage(v: number): number {
  const r = v <= 1024 ? 64 : 256;
  return Math.max(QUOTA_BOUNDS.storage.min, Math.min(QUOTA_BOUNDS.storage.max, Math.round(v / r) * r));
}

const clampTriplet = (t: QuotaTriplet): QuotaTriplet => ({
  users: niceUsers(t.users),
  modules: niceModules(t.modules),
  storage: niceStorage(t.storage),
});

/**
 * Position `price` among the other ACTIVE plans' monthly prices and
 * interpolate a proportional quota triplet:
 *  - at/below the cheapest → 80% of its quotas (a visibly cheaper tier);
 *  - at/above the priciest → 125% of its quotas (capped at the bounds);
 *  - between two neighbors → linear interpolation by price position.
 * With fewer than two comparison plans the standard price ladder decides
 * (≤99 starter · ≤499 professional · else enterprise).
 */
export function recommendQuota(
  price: number,
  others: { price: number; users: number; modules: number; storage: number }[]
): QuotaTriplet | null {
  if (!Number.isFinite(price) || price <= 0) return null;
  const sorted = [...others].sort((a, b) => a.price - b.price);
  if (sorted.length >= 2) {
    const cheapest = sorted[0];
    const priciest = sorted[sorted.length - 1];
    if (price <= cheapest.price) {
      return clampTriplet({
        users: cheapest.users * 0.8,
        modules: cheapest.modules * 0.8,
        storage: cheapest.storage * 0.8,
      });
    }
    if (price >= priciest.price) {
      return clampTriplet({
        users: priciest.users * 1.25,
        modules: priciest.modules * 1.25,
        storage: priciest.storage * 1.25,
      });
    }
    for (let i = 0; i < sorted.length - 1; i++) {
      const lo = sorted[i];
      const hi = sorted[i + 1];
      if (price >= lo.price && price <= hi.price) {
        const span = hi.price - lo.price;
        const t = span > 0 ? (price - lo.price) / span : 0.5;
        return clampTriplet({
          users: lo.users + (hi.users - lo.users) * t,
          modules: lo.modules + (hi.modules - lo.modules) * t,
          storage: lo.storage + (hi.storage - lo.storage) * t,
        });
      }
    }
  }
  /* fallback — the standard price ladder */
  if (price <= 99) return { ...QUOTA_PRESETS.starter };
  if (price <= 499) return { ...QUOTA_PRESETS.professional };
  return { ...QUOTA_PRESETS.enterprise };
}

/* ------------------------------------------------------------------ */
/* log-scale slider mapping (users 1..10000, modules 1..200)           */
/* ------------------------------------------------------------------ */

const SCALE_STEPS = 1000;

function toPos(value: number, min: number, max: number): number[] {
  const v = Math.max(min, Math.min(max, Math.max(1, Math.round(value))));
  const pos = Math.round((Math.log(v) - Math.log(Math.max(1, min))) / (Math.log(max) - Math.log(Math.max(1, min))) * SCALE_STEPS);
  return [Math.max(0, Math.min(SCALE_STEPS, pos))];
}

function fromPos(pos: number, min: number, max: number): number {
  const v = Math.exp(Math.log(Math.max(1, min)) + (pos / SCALE_STEPS) * (Math.log(max) - Math.log(Math.max(1, min))));
  return Math.max(min, Math.min(max, Math.round(v)));
}

/** the stepper's smart step — grows with the value (1 → 5 → 10 → 50). */
function smartStep(value: number, kind: "users" | "modules" | "storage"): number {
  if (kind === "users") return value < 10 ? 1 : value < 50 ? 5 : value < 500 ? 10 : 50;
  if (kind === "modules") return value < 15 ? 1 : 5;
  return value < 1024 ? 128 : 512;
}

/* ------------------------------------------------------------------ */
/* capacity level model                                                */
/* ------------------------------------------------------------------ */

type Level = "light" | "balanced" | "high" | "max";

const LEVEL_STYLE: Record<Level, string> = {
  light: "bg-slate-500/10 text-slate-600 dark:bg-slate-400/10 dark:text-slate-300",
  balanced: "bg-amber-500/10 text-amber-600 dark:bg-amber-400/15 dark:text-amber-300",
  high: "bg-emerald-500/10 text-emerald-600 dark:bg-emerald-400/15 dark:text-emerald-300",
  max: "bg-brand-500/10 text-brand-600 dark:bg-brand-400/15 dark:text-brand-300",
};
const LEVEL_KEY: Record<Level, I18nKey> = {
  light: "pkgQuotaLevelLight",
  balanced: "pkgQuotaLevelBalanced",
  high: "pkgQuotaLevelHigh",
  max: "pkgQuotaLevelMax",
};

function usersLevel(v: number): Level {
  if (v <= 10) return "light";
  if (v <= 50) return "balanced";
  if (v <= 500) return "high";
  return "max";
}
function modulesLevel(v: number): Level {
  if (v <= 8) return "light";
  if (v <= 24) return "balanced";
  if (v <= 80) return "high";
  return "max";
}
function storageLevel(v: number): Level {
  if (v <= 512) return "light";
  if (v <= 2048) return "balanced";
  if (v <= 5120) return "high";
  return "max";
}

/* ------------------------------------------------------------------ */
/* one smart quota row                                                 */
/* ------------------------------------------------------------------ */

interface QuotaRowProps {
  id: string;
  kind: "users" | "modules" | "storage";
  icon: string;
  gradient: string;
  labelKey: I18nKey;
  unitKey: I18nKey;
  value: string;
  onChange: (v: string) => void;
  attempted: boolean;
  /** slider uses a log scale (users/modules) or linear (storage) */
  scale: "log" | "linear";
  level: Level;
  hint: React.ReactNode;
}

function QuotaRow({
  id,
  kind,
  icon,
  gradient,
  labelKey,
  unitKey,
  value,
  onChange,
  attempted,
  scale,
  level,
  hint,
}: QuotaRowProps) {
  const { t, lang } = useT();
  const bounds = QUOTA_BOUNDS[kind];
  const parsed = Number(value);
  const numeric = Number.isFinite(parsed) ? parsed : NaN;
  const valid =
    Number.isFinite(numeric) && Number.isInteger(numeric) && numeric >= bounds.min && numeric <= bounds.max;
  const shown = valid ? numeric : bounds.min;

  const min = bounds.min;
  const max = bounds.max;
  const sliderValue = scale === "log" ? toPos(shown, min, max) : [Math.round((shown / max) * SCALE_STEPS)];
  const step = smartStep(shown, kind);

  const emit = (n: number) => {
    const clamped = Math.max(min, Math.min(max, Math.round(n)));
    onChange(String(clamped));
  };

  const onSlider = (positions: number[]) => {
    const pos = positions[0] ?? 0;
    emit(scale === "log" ? fromPos(pos, min, max) : Math.round((pos / SCALE_STEPS) * max));
  };

  const nudge = (dir: 1 | -1) => emit(shown + dir * step);

  const fmtShown = (n: number) =>
    kind === "storage" ? formatBytes(n * 1024 * 1024, lang) : fmtNum(n, lang);

  return (
    <div className="rounded-2xl border border-slate-200 bg-slate-50/60 p-3 dark:border-white/10 dark:bg-white/[0.02]">
      {/* header: icon tile + label + capacity level badge */}
      <div className="flex items-center justify-between gap-2">
        <Label htmlFor={id} className="flex cursor-pointer items-center gap-2 text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
          <span
            aria-hidden="true"
            className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-white shadow-sm"
            style={{ backgroundImage: gradient }}
          >
            <CatIcon name={icon} className="h-3.5 w-3.5" />
          </span>
          {t(labelKey)}
        </Label>
        <span className={cn("rounded-full px-2 py-px text-[10px] font-extrabold", LEVEL_STYLE[level])}>
          {t(LEVEL_KEY[level])}
        </span>
      </div>

      {/* control rail: stepper − / slider / + and the precision input */}
      <div className="mt-2.5 flex items-center gap-2" dir={lang === "ar" ? "rtl" : "ltr"}>
        <button
          type="button"
          onClick={() => nudge(-1)}
          aria-label={t("pkgQuotaMinus")}
          title={t("pkgQuotaMinus")}
          disabled={shown <= min}
          className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-slate-200 bg-white text-slate-500 transition hover:border-brand-300 hover:text-brand-600 active:scale-90 disabled:cursor-not-allowed disabled:opacity-40 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400 dark:hover:border-brand-400/40"
        >
          <CatIcon name="minus" className="h-3.5 w-3.5" />
        </button>

        <div className="relative min-w-0 flex-1">
          <Slider
            id={`${id}-slider`}
            min={0}
            max={SCALE_STEPS}
            step={1}
            value={sliderValue}
            onValueChange={onSlider}
            aria-label={t(labelKey)}
            className="mx-1 py-2"
          />
        </div>

        <button
          type="button"
          onClick={() => nudge(1)}
          aria-label={t("pkgQuotaPlus")}
          title={t("pkgQuotaPlus")}
          disabled={shown >= max}
          className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-slate-200 bg-white text-slate-500 transition hover:border-brand-300 hover:text-brand-600 active:scale-90 disabled:cursor-not-allowed disabled:opacity-40 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400 dark:hover:border-brand-400/40"
        >
          <CatIcon name="plus" className="h-3.5 w-3.5" />
        </button>

        {/* precision input — the canonical numeric field */}
        <Input
          id={id}
          type="number"
          inputMode="numeric"
          dir="ltr"
          min={min}
          max={max}
          step={1}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onBlur={() => {
            /* normalize on blur: empty/invalid restores the bounds, values
             * outside clamp — the submit path stays a second safety net */
            if (!valid) emit(Number.isFinite(numeric) ? Math.round(numeric) : min);
          }}
          aria-invalid={attempted && !valid ? true : undefined}
          className="h-8 w-[5.5rem] shrink-0 rounded-lg border-slate-200 bg-white px-2 text-center text-[12.5px] font-extrabold tabular-nums text-slate-800 shadow-none outline-none transition focus:border-brand-400 focus:shadow-lg focus:shadow-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100"
        />
      </div>

      {/* the business hint line */}
      <p className="mt-1.5 flex flex-wrap items-center gap-x-1.5 gap-y-0.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
        {hint}
        {kind !== "storage" ? (
          <span className="rounded-full bg-slate-500/10 px-1.5 py-px text-[9.5px] font-bold text-slate-500 dark:bg-white/10 dark:text-slate-400" dir="ltr">
            {fmtShown(shown)} {t(unitKey)}
          </span>
        ) : null}
      </p>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* the editor                                                          */
/* ------------------------------------------------------------------ */

const TIER_KEY: Record<"starter" | "professional" | "enterprise", I18nKey> = {
  starter: "pkgTierStarter",
  professional: "pkgTierProfessional",
  enterprise: "pkgTierEnterprise",
};

export interface PackageQuotaEditorProps {
  users: string;
  modules: string;
  storage: string;
  onUsersChange: (v: string) => void;
  onModulesChange: (v: string) => void;
  onStorageChange: (v: string) => void;
  /** the platform's live packages — powers the smart recommendation */
  packages: PackageDTO[];
  /** the edited package's id (excluded from the comparison set) */
  editingId: string | null;
  /** the plan's live monthly price (drives the recommendation) */
  priceMonthly: number;
  currency: string;
  /** parent submit-attempted flag — surfaces invalid inputs */
  attempted: boolean;
}

export function PackageQuotaEditor({
  users,
  modules,
  storage,
  onUsersChange,
  onModulesChange,
  onStorageChange,
  packages,
  editingId,
  priceMonthly,
  currency,
  attempted,
}: PackageQuotaEditorProps) {
  const { t, lang } = useT();

  const usersNum = Number(users);
  const modulesNum = Number(modules);
  const storageNum = Number(storage);
  const usersOk = Number.isInteger(usersNum) && usersNum >= QUOTA_BOUNDS.users.min && usersNum <= QUOTA_BOUNDS.users.max;
  const modulesOk = Number.isInteger(modulesNum) && modulesNum >= QUOTA_BOUNDS.modules.min && modulesNum <= QUOTA_BOUNDS.modules.max;
  const storageOk = Number.isInteger(storageNum) && storageNum >= QUOTA_BOUNDS.storage.min && storageNum <= QUOTA_BOUNDS.storage.max;
  const usersShown = usersOk ? usersNum : QUOTA_PRESETS.starter.users;
  const modulesShown = modulesOk ? modulesNum : QUOTA_PRESETS.starter.modules;
  const storageShown = storageOk ? storageNum : QUOTA_PRESETS.starter.storage;

  /* the comparison set: other ACTIVE plans with a real price */
  const others = useMemo(
    () =>
      packages
        .filter((p) => p.active && p.id !== editingId && p.priceMonthly > 0)
        .map((p) => ({ price: p.priceMonthly, users: p.maxUsers, modules: p.maxModules, storage: p.maxStorageMb })),
    [packages, editingId]
  );
  const rec = useMemo(() => recommendQuota(priceMonthly, others), [priceMonthly, others]);

  /* the current triplet vs the tier presets → matched | custom */
  const current: QuotaTriplet = { users: usersShown, modules: modulesShown, storage: storageShown };
  const matchedPreset = (Object.keys(QUOTA_PRESETS) as ("starter" | "professional" | "enterprise")[]).find(
    (k) =>
      QUOTA_PRESETS[k].users === current.users &&
      QUOTA_PRESETS[k].modules === current.modules &&
      QUOTA_PRESETS[k].storage === current.storage
  );

  /* does the recommendation differ from the current triplet? */
  const recDiffers =
    rec !== null &&
    (rec.users !== current.users || rec.modules !== current.modules || rec.storage !== current.storage);

  /* the platform's average users (comparison hint inside the users row) */
  const avgUsers = others.length > 0 ? Math.round(others.reduce((s, o) => s + o.users, 0) / others.length) : null;

  const applyPreset = (k: "starter" | "professional" | "enterprise") => {
    const preset = QUOTA_PRESETS[k];
    onUsersChange(String(preset.users));
    onModulesChange(String(preset.modules));
    onStorageChange(String(preset.storage));
    toast.success(t("pkgQuotaPresetApplied", { name: t(TIER_KEY[k]) }));
  };

  const applyRec = () => {
    if (!rec) return;
    onUsersChange(String(rec.users));
    onModulesChange(String(rec.modules));
    onStorageChange(String(rec.storage));
    toast.success(t("pkgQuotaRecApplied"));
  };

  const storagePctOfMax = Math.round((storageShown / QUOTA_BOUNDS.storage.max) * 100);

  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-3.5 dark:border-white/10 dark:bg-white/[0.02]">
      {/* section header */}
      <div className="flex items-center gap-2.5">
        <span
          aria-hidden="true"
          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-md shadow-brand-500/20"
          style={{ backgroundImage: grad("#6d5dfb", "#06b6d4") }}
        >
          <CatIcon name="sliders" className="h-4 w-4" />
        </span>
        <div className="min-w-0">
          <h4 className="font-display text-[13.5px] font-extrabold text-slate-900 dark:text-white">
            {t("pkgQuotaTitle")}
          </h4>
          <p className="text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
            {t("pkgQuotaDesc")}
          </p>
        </div>
      </div>

      {/* ① smart recommendation */}
      {recDiffers && rec ? (
        <div className="mt-3 rounded-2xl border border-brand-200/70 bg-linear-to-br from-brand-50/80 to-cyan-50/60 p-3 dark:border-brand-400/20 dark:from-brand-500/10 dark:to-cyan-500/5">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <p className="flex items-center gap-1.5 text-[12px] font-extrabold text-brand-700 dark:text-brand-300">
                <CatIcon name="wand-sparkles" className="h-3.5 w-3.5 shrink-0" />
                {t("pkgQuotaRecTitle")}
                <span dir="ltr" className="tabular-nums">
                  · {fmtNum(priceMonthly, lang)} {currency}
                </span>
              </p>
              <p className="mt-0.5 text-[10.5px] font-semibold text-slate-500 dark:text-slate-400">
                {others.length >= 2 ? t("pkgQuotaRecDesc") : t("pkgQuotaRecFallback")}
              </p>
            </div>
            <button
              type="button"
              onClick={applyRec}
              className="h-8 shrink-0 rounded-lg bg-linear-to-l from-brand-600 to-cyan-500 px-3 text-[11px] font-extrabold text-white shadow-md shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
            >
              {t("pkgQuotaRecApply")}
            </button>
          </div>
          {/* the recommended triplet as diff chips */}
          <div className="mt-2 flex flex-wrap gap-1.5" dir="ltr">
            {[
              { icon: "users", cur: current.users, rec: rec.users, suffix: "" },
              { icon: "cubes", cur: current.modules, rec: rec.modules, suffix: "" },
              { icon: "hard-drive", cur: current.storage, rec: rec.storage, suffix: " MB" },
            ].map((chip) => (
              <span
                key={chip.icon}
                className="inline-flex items-center gap-1.5 rounded-full border border-white/60 bg-white/80 px-2.5 py-1 text-[11px] font-extrabold tabular-nums text-slate-600 shadow-sm dark:border-white/10 dark:bg-white/[0.06] dark:text-slate-300"
              >
                <CatIcon name={chip.icon} className="h-3 w-3 text-brand-500" />
                <span className="text-slate-400 dark:text-slate-500">{chip.cur}</span>
                <CatIcon name="arrow-left" className="h-2.5 w-2.5 text-slate-300 dark:text-slate-600" />
                <span className="text-brand-600 dark:text-brand-300">
                  {chip.rec}
                  {chip.suffix}
                </span>
              </span>
            ))}
          </div>
        </div>
      ) : null}

      {/* ② quick presets */}
      <div className="mt-3">
        <p className="mb-1.5 text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
          {t("pkgQuotaPresets")}
        </p>
        <div className="flex flex-wrap items-center gap-1.5">
          {(Object.keys(QUOTA_PRESETS) as ("starter" | "professional" | "enterprise")[]).map((k) => (
            <button
              key={k}
              type="button"
              onClick={() => applyPreset(k)}
              aria-pressed={matchedPreset === k}
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[11px] font-extrabold transition active:scale-95",
                matchedPreset === k
                  ? "border-brand-400 bg-brand-500/10 text-brand-600 shadow-sm dark:border-brand-400/40 dark:text-brand-300"
                  : "border-slate-200 bg-white text-slate-600 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-300 dark:hover:border-brand-400/40"
              )}
            >
              <CatIcon name={k === "starter" ? "sprout" : k === "professional" ? "gem" : "crown"} className="h-3 w-3" />
              {t(TIER_KEY[k])}
              <span dir="ltr" className="tabular-nums opacity-60">
                {QUOTA_PRESETS[k].users}/{QUOTA_PRESETS[k].modules}
              </span>
            </button>
          ))}
          {matchedPreset ? null : (
            <span className="inline-flex items-center gap-1 rounded-full bg-slate-500/10 px-2.5 py-1 text-[10.5px] font-extrabold text-slate-500 dark:bg-white/10 dark:text-slate-400">
              <CatIcon name="fingerprint" className="h-3 w-3" />
              {t("pkgQuotaCustom")}
            </span>
          )}
        </div>
      </div>

      {/* ③ the three smart rows */}
      <div className="mt-3 grid gap-2.5">
        <QuotaRow
          id="pkg-max-users"
          kind="users"
          icon="users"
          gradient={grad("#6d5dfb", "#a78bfa")}
          labelKey="pkgQuotaUsers"
          unitKey="pkgQuotaUsersUnit"
          value={users}
          onChange={onUsersChange}
          attempted={attempted}
          scale="log"
          level={usersLevel(usersShown)}
          hint={
            <>
              <CatIcon name="target" className="h-3 w-3 shrink-0 text-brand-400" />
              {t("pkgQuotaTeamHint", { n: fmtNum(usersShown, lang) })}
              {avgUsers !== null ? (
                <>
                  <span className="text-slate-300 dark:text-slate-600" aria-hidden="true">·</span>
                  <span className={cn(usersShown >= avgUsers ? "text-emerald-500" : "text-amber-500")}>
                    {t("pkgQuotaUsersAvg", { n: fmtNum(avgUsers, lang) })}
                  </span>
                </>
              ) : null}
            </>
          }
        />
        <QuotaRow
          id="pkg-max-modules"
          kind="modules"
          icon="cubes"
          gradient={grad("#06b6d4", "#0891b2")}
          labelKey="pkgQuotaModules"
          unitKey="pkgQuotaModulesUnit"
          value={modules}
          onChange={onModulesChange}
          attempted={attempted}
          scale="log"
          level={modulesLevel(modulesShown)}
          hint={
            <>
              <CatIcon name="layers" className="h-3 w-3 shrink-0 text-cyan-500" />
              {t("pkgQuotaModulesHint", { n: fmtNum(modulesShown, lang) })}
            </>
          }
        />
        <QuotaRow
          id="pkg-max-storage"
          kind="storage"
          icon="hard-drive"
          gradient={grad("#10b981", "#059669")}
          labelKey="pkgQuotaStorage"
          unitKey="pkgQuotaStorageUnit"
          value={storage}
          onChange={onStorageChange}
          attempted={attempted}
          scale="linear"
          level={storageLevel(storageShown)}
          hint={
            storageShown === 0 ? (
              <>
                <CatIcon name="circle-alert" className="h-3 w-3 shrink-0 text-amber-500" />
                <span className="text-amber-600 dark:text-amber-400">{t("pkgQuotaNoStorage")}</span>
              </>
            ) : (
              <>
                <CatIcon name="hard-drive" className="h-3 w-3 shrink-0 text-emerald-500" />
                {formatBytes(storageShown * 1024 * 1024, lang)}
                <span className="text-slate-300 dark:text-slate-600" aria-hidden="true">·</span>
                {t("pkgQuotaStorageOfMax", { pct: storagePctOfMax })}
              </>
            )
          }
        />
      </div>
    </section>
  );
}
