"use client";

/**
 * Ashrilogic — admin audit view.
 *
 * Security timeline over the AuditLog table: who did what, when and to
 * which target. Filters by actor surface (admin / workspace / public /
 * system) + free-text search; "show more" pages through the newest window
 * (the API caps each fetch at 100 entries).
 *
 * ROUND 118 — the CHAIN ANCHOR card (additive, rendered above the timeline):
 * the audit-chain head-anchor verdict + the operator's on-demand "anchor
 * now" pin (the MAC-sealed external trust point — see audit-anchor.ts).
 */
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  anchorAuditChainNow,
  downloadAuditAnchorJournal,
  fetchAuditAnchorStatus,
  fetchAuditEntries,
  type AuditAnchorStatus,
  type AuditAnchorStatusDTO,
} from "@/lib/api-client";
import type { AuditAction, AuditActorType } from "@/lib/types";
import { useT, type I18nKey } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { cn, grad } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { DashCard, ViewHeading, fullDate, relativeTime } from "@/components/dashboard/dash-shared";

/** Action label keys + timeline tile styling (icon + gradient). */
const ACTION_META: Record<AuditAction, { key: I18nKey; icon: string; c1: string; c2: string }> = {
  "admin.login": { key: "auditActAdminLogin", icon: "log-in", c1: "#10b981", c2: "#059669" },
  "admin.loginFailed": { key: "auditActAdminLoginFailed", icon: "circle-alert", c1: "#f43f5e", c2: "#e11d48" },
  "admin.logout": { key: "auditActAdminLogout", icon: "log-out", c1: "#64748b", c2: "#475569" },
  "admin.create": { key: "auditActAdminCreate", icon: "user-plus", c1: "#6d5dfb", c2: "#4b35c9" },
  "admin.update": { key: "auditActAdminUpdate", icon: "user-cog", c1: "#8b5cf6", c2: "#7c3aed" },
  "admin.delete": { key: "auditActAdminDelete", icon: "user-minus", c1: "#f43f5e", c2: "#be123c" },
  "package.create": { key: "auditActPackageCreate", icon: "package-plus", c1: "#f59e0b", c2: "#d97706" },
  "package.update": { key: "auditActPackageUpdate", icon: "package-check", c1: "#f59e0b", c2: "#b45309" },
  "package.delete": { key: "auditActPackageDelete", icon: "package-open", c1: "#f43f5e", c2: "#b45309" },
  "settings.update": { key: "auditActSettingsUpdate", icon: "cog", c1: "#64748b", c2: "#475569" },
  "ticket.create": { key: "auditActTicketCreate", icon: "headset", c1: "#06b6d4", c2: "#0891b2" },
  "ticket.update": { key: "auditActTicketUpdate", icon: "headset", c1: "#06b6d4", c2: "#0e7490" },
  "ticket.delete": { key: "auditActTicketDelete", icon: "trash", c1: "#f43f5e", c2: "#be123c" },
  "instance.create": { key: "auditActInstanceCreate", icon: "rocket", c1: "#6d5dfb", c2: "#0ea5e9" },
  "instance.update": { key: "auditActInstanceUpdate", icon: "pencil", c1: "#8b5cf6", c2: "#6d28d9" },
  "instance.delete": { key: "auditActInstanceDelete", icon: "trash", c1: "#f43f5e", c2: "#be123c" },
  "instance.siteUpdate": { key: "auditActInstanceSiteUpdate", icon: "pencil", c1: "#0ea5e9", c2: "#6366f1" },
  "instance.siteLaunch": { key: "auditActInstanceSiteLaunch", icon: "rocket", c1: "#6d5dfb", c2: "#ec4899" },
  "instance.login": { key: "auditActInstanceLogin", icon: "log-in", c1: "#10b981", c2: "#047857" },
  "instance.loginFailed": { key: "auditActInstanceLoginFailed", icon: "circle-alert", c1: "#f43f5e", c2: "#e11d48" },
  "instance.logout": { key: "auditActInstanceLogout", icon: "log-out", c1: "#64748b", c2: "#475569" },
  /* ROUND 133 — نظام الورديات (shift system) */
  "instance.shiftOpen": { key: "auditActInstanceShiftOpen", icon: "clock", c1: "#10b981", c2: "#059669" },
  "instance.shiftClose": { key: "auditActInstanceShiftClose", icon: "timer-off", c1: "#f59e0b", c2: "#d97706" },
  "instance.shiftCode": { key: "auditActInstanceShiftCode", icon: "key-round", c1: "#10b981", c2: "#0e7490" },
  "instance.loyaltySync": { key: "auditActInstanceLoyaltySync", icon: "award", c1: "#8b5cf6", c2: "#7c3aed" },
  /* ROUND 134 — deep tenant-identity uniqueness (masked PII only) */
  "instance.duplicateBlock": { key: "auditActInstanceDuplicateBlock", icon: "user-x", c1: "#f43f5e", c2: "#e11d48" },
  /* ROUND 136 — Super-Admin strict instance connection: the per-instance
   * ops drilldown (telemetry read probe) + the session-revocation lever. */
  "admin.instanceOps": { key: "auditActAdminInstanceOps", icon: "gauge", c1: "#0ea5e9", c2: "#0284c7" },
  "admin.instanceSessionsRevoke": { key: "auditActAdminInstanceSessionsRevoke", icon: "log-out", c1: "#e11d48", c2: "#be123c" },
  "instance.password": { key: "auditActInstancePassword", icon: "key-round", c1: "#10b981", c2: "#0e7490" },
  "instance.memberAdd": { key: "auditActInstanceMemberAdd", icon: "user-plus", c1: "#0ea5e9", c2: "#0284c7" },
  "instance.memberUpdate": { key: "auditActInstanceMemberUpdate", icon: "user-cog", c1: "#0ea5e9", c2: "#0369a1" },
  "instance.memberRemove": { key: "auditActInstanceMemberRemove", icon: "user-minus", c1: "#f43f5e", c2: "#be123c" },
  "instance.ticketCreate": { key: "auditActInstanceTicketCreate", icon: "headset", c1: "#06b6d4", c2: "#0891b2" },
  "instance.upgradeRequest": { key: "auditActInstanceUpgradeRequest", icon: "trending-up", c1: "#f59e0b", c2: "#ea580c" },
  "instance.resetDemo": { key: "auditActInstanceResetDemo", icon: "database-backup", c1: "#8b5cf6", c2: "#c026d3" },
  /* ROUND 81 — governance ban levers (subscriber suspension + lift) */
  "instance.ban": { key: "auditActInstanceBan", icon: "octagon-x", c1: "#e11d48", c2: "#881337" },
  "instance.unban": { key: "auditActInstanceUnban", icon: "badge-check", c1: "#10b981", c2: "#047857" },
  /* ROUND 41 (task 4) — labels reuse the settings-view backup card titles
   * (bkBackupCard / bkRestoreCard); no new i18n keys were added. */
  "instance.backup": { key: "bkBackupCard", icon: "cloud-upload", c1: "#06b6d4", c2: "#0e7490" },
  "instance.restore": { key: "bkRestoreCard", icon: "clock-rotate-left", c1: "#10b981", c2: "#059669" },
  /* ROUND 41 (task 3 — AI insights) — labels reuse the AI panel titles
   * (aiPanelTitle / aiAdminTitle); no new i18n keys were added. */
  "instance.aiAnalysis": { key: "aiPanelTitle", icon: "brain", c1: "#6d5dfb", c2: "#d946ef" },
  "admin.aiSettings": { key: "aiAdminTitle", icon: "wand-sparkles", c1: "#8b5cf6", c2: "#c026d3" },
  "newsletter.add": { key: "auditActNewsletterAdd", icon: "mail", c1: "#6d5dfb", c2: "#d946ef" },
  /* ROUND 118 — the audit-chain head anchor lifecycle: the console's
   * manual pin (admin) + the safety net's sealed verdict ALERT (system). */
  "admin.auditAnchor": { key: "auditActAuditAnchor", icon: "anchor", c1: "#0ea5e9", c2: "#0369a1" },
  "system.auditAnchor": { key: "auditActSystemAnchor", icon: "octagon-alert", c1: "#f43f5e", c2: "#9f1239" },
  /* ROUND 158 — platform-wide IP banlist: blocked login attempts + the
   * console's mutation surface. Visually red (security/governance family). */
  "admin.loginBlocked": { key: "auditActAdminLoginBlocked", icon: "ban", c1: "#f43f5e", c2: "#be123c" },
  "instance.loginBlocked": { key: "auditActInstanceLoginBlocked", icon: "ban", c1: "#f43f5e", c2: "#be123c" },
  "security.ipban": { key: "auditActSecurityIpban", icon: "shield-alert", c1: "#f59e0b", c2: "#b45309" },
};

/** Actor surface chips. */
const ACTOR_META: Record<AuditActorType, { key: I18nKey; icon: string; c1: string; c2: string }> = {
  admin: { key: "auditActorAdmin", icon: "shield-user", c1: "#6d5dfb", c2: "#4b35c9" },
  instance: { key: "auditActorInstance", icon: "boxes", c1: "#0ea5e9", c2: "#0369a1" },
  public: { key: "auditActorPublic", icon: "globe", c1: "#10b981", c2: "#047857" },
  system: { key: "auditActorSystem", icon: "cpu", c1: "#64748b", c2: "#475569" },
};

/**
 * ROUND 136 — resolve an audit action's localized label key (null when the
 * action has no dedicated entry — callers fall back to the raw dot-key).
 * Exported so the subscriber sheet's instance-ops mini-list renders the SAME
 * labels the full audit timeline does (one vocabulary, two surfaces).
 */
export function auditActionLabelKey(action: string): I18nKey | null {
  const meta = ACTION_META[action as AuditAction];
  return meta ? meta.key : null;
}

const ACTOR_FILTERS: { value: string; key: I18nKey; icon: string }[] = [
  { value: "all", key: "auditAll", icon: "layers" },
  { value: "admin", key: "auditActorAdmin", icon: "shield-user" },
  { value: "instance", key: "auditActorInstance", icon: "boxes" },
  { value: "public", key: "auditActorPublic", icon: "globe" },
  { value: "system", key: "auditActorSystem", icon: "cpu" },
];

function AuditSkeleton() {
  return (
    <div className="space-y-3">
      {Array.from({ length: 7 }).map((_, i) => (
        <div key={i} className="flex items-center gap-3">
          <Skeleton className="h-10 w-10 rounded-xl" />
          <div className="flex-1 space-y-1.5">
            <Skeleton className="h-3.5 w-48" />
            <Skeleton className="h-2.5 w-32" />
          </div>
          <Skeleton className="h-2.5 w-16" />
        </div>
      ))}
    </div>
  );
}

/* ------------------------------------------ ROUND 118: the anchor ---- */

/** Verdict presentation: tone + icon + label key per status. */
const ANCHOR_STATUS_META: Record<
  AuditAnchorStatus,
  { icon: string; c1: string; c2: string; key: I18nKey; tone: "good" | "warn" | "bad" | "neutral" }
> = {
  ok: { icon: "link", c1: "#10b981", c2: "#047857", key: "auditAnchorOk", tone: "good" },
  unanchored: { icon: "anchor", c1: "#64748b", c2: "#475569", key: "auditAnchorUnanchored", tone: "neutral" },
  "no-chain": { icon: "circle-dot", c1: "#64748b", c2: "#475569", key: "auditAnchorNoChain", tone: "neutral" },
  stale: { icon: "hourglass", c1: "#f59e0b", c2: "#d97706", key: "auditAnchorStale", tone: "warn" },
  truncated: { icon: "scissors", c1: "#f43f5e", c2: "#be123c", key: "auditAnchorTruncated", tone: "bad" },
  tampered: { icon: "octagon-alert", c1: "#f43f5e", c2: "#9f1239", key: "auditAnchorTampered", tone: "bad" },
};

/** One label/value row inside the anchor card (the ops MetricRow language). */
function AnchorMetric({
  label,
  value,
  tone = "neutral",
  mono = false,
}: {
  label: string;
  value: string;
  tone?: "good" | "warn" | "bad" | "neutral";
  mono?: boolean;
}) {
  return (
    <li className="flex items-center justify-between gap-3 py-2 first:pt-0 last:pb-0">
      <span className="flex min-w-0 items-center gap-2 text-[12px] font-bold text-slate-500 dark:text-slate-400">
        {label}
      </span>
      <span
        dir={mono ? "ltr" : undefined}
        className={cn(
          "shrink-0 rounded-lg px-2 py-0.5 text-[12px] font-extrabold tabular-nums",
          mono && "font-mono",
          tone === "good" && "bg-emerald-500/10 text-emerald-600 dark:text-emerald-300",
          tone === "warn" && "bg-amber-500/10 text-amber-600 dark:text-amber-300",
          tone === "bad" && "bg-rose-500/10 text-rose-600 dark:text-rose-300",
          tone === "neutral" && "bg-slate-500/10 text-slate-700 dark:bg-white/[0.06] dark:text-slate-200"
        )}
      >
        {value}
      </span>
    </li>
  );
}

/**
 * ROUND 118 — the chain-head anchor card: live external-anchor verdict
 * (the newest sealed pin vs the current chain head) + the on-demand
 * "anchor now" action. Purely ADDITIVE — rendered above the timeline.
 */
function AuditAnchorCard() {
  const { t, lang } = useT();
  const queryClient = useQueryClient();

  const statusQuery = useQuery({
    queryKey: ["audit-anchor-status"],
    queryFn: () => fetchAuditAnchorStatus(),
    refetchInterval: false,
    staleTime: 0,
    retry: 0,
  });

  const anchorMutation = useMutation({
    mutationFn: () => anchorAuditChainNow(),
    onSuccess: (data) => {
      toast.success(
        t("auditAnchorDone", {
          hash: data.payload.headHashPrefix,
          rows: data.payload.totalRows,
        })
      );
      void queryClient.invalidateQueries({ queryKey: ["audit-anchor-status"] });
    },
    onError: (e: Error) => toast.error(e.message || t("auditAnchorFailed")),
  });

  /* ROUND 119 — the off-host journal export (blob save; 404 when never
   * anchored — the toast explains instead of a dead download) */
  const exportMutation = useMutation({
    mutationFn: () => downloadAuditAnchorJournal(),
    onSuccess: () => toast.success(t("auditAnchorExportDone")),
    onError: (e: Error) => toast.error(e.message || t("auditAnchorExportFailed")),
  });

  const data: AuditAnchorStatusDTO | undefined = statusQuery.data;
  const meta = data ? ANCHOR_STATUS_META[data.status] : undefined;
  const busy = statusQuery.isFetching || anchorMutation.isPending;
  const exportBusy = exportMutation.isPending;

  return (
    <DashCard title={t("auditAnchorTitle")} icon="anchor">
      {statusQuery.isPending ? (
        <div className="grid place-items-center py-6">
          <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin text-brand-400" />
        </div>
      ) : statusQuery.isError || !data || !meta ? (
        <div className="space-y-3 py-2 text-center">
          <p className="text-[11.5px] font-bold text-slate-400 dark:text-slate-500">
            {t("auditAnchorLoadFailed")}
          </p>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => void statusQuery.refetch()}
            className="h-8 gap-2 rounded-xl text-[11.5px] font-bold"
          >
            <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
            {t("retryText")}
          </Button>
        </div>
      ) : (
        <>
          {/* the verdict chip — hard findings scream, healthy states whisper */}
          <div className="mb-3 flex flex-wrap items-center gap-2.5">
            <span
              className="inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[11px] font-extrabold text-white shadow-md"
              style={{ backgroundImage: grad(meta.c1, meta.c2) }}
            >
              <CatIcon name={meta.icon} className="h-3.5 w-3.5" />
              {t(meta.key)}
            </span>
            {data.tailCorrupt ? (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-300/60 bg-amber-500/10 px-2.5 py-1 text-[10.5px] font-extrabold text-amber-600 dark:border-amber-500/40 dark:text-amber-300">
                <CatIcon name="triangle-alert" className="h-3 w-3" />
                {t("auditAnchorTailWarn")}
              </span>
            ) : null}
          </div>

          <ul className="divide-y divide-slate-100 dark:divide-white/[0.06]">
            <AnchorMetric
              label={t("auditAnchorLast")}
              value={
                data.anchor
                  ? `${relativeTime(data.anchor.anchoredAt, lang)} · ${t(
                      data.anchor.trigger === "manual" ? "auditAnchorManual" : "auditAnchorAuto"
                    )}`
                  : t("auditAnchorNever")
              }
              tone={data.status === "ok" ? "good" : meta.tone}
            />
            <AnchorMetric
              label={t("auditAnchorHead")}
              value={data.anchor ? data.anchor.headHashPrefix : "—"}
              mono
            />
            <AnchorMetric
              label={t("auditAnchorRows")}
              value={data.anchor ? String(data.anchor.totalRows) : "—"}
              tone={data.status === "ok" ? "good" : meta.tone}
            />
            <AnchorMetric
              label={t("auditAnchorSince")}
              value={String(data.rowsSinceAnchor)}
              tone={data.rowsSinceAnchor > 0 ? "good" : "neutral"}
            />
          </ul>

          {/* the on-demand pin + the journal export + the manual refresh (same
              affordances as the R117 storage-GC card) */}
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <Button
              type="button"
              size="sm"
              onClick={() => anchorMutation.mutate()}
              disabled={busy}
              className="h-9 gap-2 rounded-xl bg-linear-to-l from-sky-600 to-cyan-700 px-4 text-[11.5px] font-extrabold text-white shadow-lg transition hover:brightness-110"
            >
              <CatIcon
                name="anchor"
                className={cn("h-3.5 w-3.5", anchorMutation.isPending && "animate-pulse")}
              />
              {t("auditAnchorBtn")}
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => exportMutation.mutate()}
              disabled={exportBusy || data?.status === "no-chain"}
              title={t("auditAnchorExportHint")}
              className="h-9 gap-2 rounded-xl text-[11.5px] font-bold"
            >
              <CatIcon
                name="download"
                className={cn("h-3.5 w-3.5", exportBusy && "animate-bounce")}
              />
              {t("auditAnchorExportBtn")}
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => void statusQuery.refetch()}
              disabled={busy}
              className="h-9 gap-2 rounded-xl text-[11.5px] font-bold"
            >
              <CatIcon
                name="refresh-cw"
                className={cn("h-3.5 w-3.5", statusQuery.isFetching && "animate-spin")}
              />
              {t("retryText")}
            </Button>
          </div>

          <p className="mt-3 flex items-start gap-1.5 text-[10.5px] font-semibold leading-relaxed text-slate-400 dark:text-slate-500">
            <CatIcon name="lock" className="mt-0.5 h-3 w-3 shrink-0" />
            {t("auditAnchorNote")}
          </p>
        </>
      )}
    </DashCard>
  );
}

export function AdminAudit({ instanceId }: { instanceId?: string } = {}) {
  const { t, lang } = useT();
  const [actor, setActor] = useState("all");
  const [search, setSearch] = useState("");
  const [limit, setLimit] = useState(50);
  /* ROUND 136 — optional per-instance linkage filter (workspace-actor rows +
   * meta.instance-stamped platform rows); additive — undefined keeps today's
   * behavior byte-for-byte (the default call site passes no props). */
  const instanceFilter = instanceId?.trim() || undefined;

  const query = useQuery({
    queryKey: ["audit", actor, limit, instanceFilter ?? "-"],
    queryFn: () =>
      fetchAuditEntries({
        actorType: actor === "all" ? undefined : actor,
        limit,
        instanceId: instanceFilter,
      }),
  });

  const entries = useMemo(() => {
    const list = query.data?.entries ?? [];
    const q = search.trim().toLowerCase();
    if (!q) return list;
    return list.filter((e) =>
      [e.actorName, e.targetLabel ?? "", e.action, t(ACTION_META[e.action]?.key ?? "auditTitle")]
        .join(" ")
        .toLowerCase()
        .includes(q)
    );
  }, [query.data, search, t]);

  const total = query.data?.total ?? 0;

  return (
    <div className="space-y-5">
      <ViewHeading title={t("auditTitle")} desc={t("auditDesc")} />

      {/* ROUND 118 — the external chain-anchor verdict (additive card) */}
      <AuditAnchorCard />

      {/* filter bar */}
      <div className="flex flex-wrap items-center gap-2.5">
        {/* ROUND 136 — active per-instance filter chip (only when a caller
            passes one; the default view renders nothing extra) */}
        {instanceFilter ? (
          <span className="inline-flex items-center gap-1.5 rounded-full border border-sky-300/70 bg-sky-500/10 px-3 py-1 text-[11px] font-extrabold text-sky-700 dark:border-sky-500/30 dark:bg-sky-500/15 dark:text-sky-300">
            <CatIcon name="boxes" className="h-3 w-3" />
            <span dir="ltr" className="max-w-40 truncate font-mono">{instanceFilter}</span>
          </span>
        ) : null}
        <div
          className="flex flex-wrap gap-1.5 rounded-2xl border border-slate-200 bg-white p-1.5 dark:border-white/10 dark:bg-white/[0.03]"
          role="group"
          aria-label={t("auditActorFilter")}
        >
          {ACTOR_FILTERS.map((f) => (
            <button
              key={f.value}
              type="button"
              onClick={() => {
                setActor(f.value);
                setLimit(50);
              }}
              aria-pressed={actor === f.value}
              className={cn(
                "inline-flex h-8 items-center gap-1.5 rounded-xl px-3 text-[11.5px] font-extrabold transition active:scale-95",
                actor === f.value
                  ? "bg-brand-500/10 text-brand-600 shadow-[0_0_16px_-6px_rgba(109,93,251,0.5)] dark:text-brand-300"
                  : "text-slate-500 hover:bg-slate-100 hover:text-slate-800 dark:text-slate-400 dark:hover:bg-white/[0.06] dark:hover:text-white"
              )}
            >
              <CatIcon name={f.icon} className="h-[12px] w-[12px]" />
              {t(f.key)}
            </button>
          ))}
        </div>

        <div className="relative min-w-44 flex-1">
          <CatIcon
            name="search"
            className="pointer-events-none absolute inset-y-0 start-3 my-auto h-[14px] w-[14px] text-slate-400"
          />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t("auditSearchPh")}
            className="h-10 rounded-2xl ps-9 text-[12.5px]"
            aria-label={t("auditSearchPh")}
          />
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={() => query.refetch()}
          disabled={query.isFetching}
          className="h-10 rounded-2xl px-4 text-[12px] font-bold"
        >
          <CatIcon name="refresh-cw" className={cn("h-3.5 w-3.5", query.isFetching && "animate-spin")} />
          <span className="hidden sm:inline">{t("retryText")}</span>
        </Button>
      </div>

      <DashCard
        title={t("auditTitle")}
        icon="scroll-text"
        action={
          <span className="rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-[10.5px] font-extrabold text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-400">
            {t("auditCount", { shown: entries.length, total })}
          </span>
        }
      >
        {query.isPending ? (
          <AuditSkeleton />
        ) : query.isError ? (
          <div className="py-10 text-center">
            <p className="text-[13px] font-bold text-rose-600 dark:text-rose-400">{t("errorText")}</p>
            <Button
              variant="outline"
              onClick={() => query.refetch()}
              className="mt-3 h-10 rounded-xl px-5 text-[12.5px] font-bold"
            >
              <CatIcon name="refresh-cw" className="h-4 w-4" />
              {t("retryText")}
            </Button>
          </div>
        ) : entries.length === 0 ? (
          <div className="py-12 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5">
              <CatIcon name="scroll-text" className="h-6 w-6" />
            </div>
            <p className="mt-3 font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("auditEmpty")}
            </p>
            <p className="mx-auto mt-1 max-w-sm text-[12px] font-semibold text-slate-400 dark:text-slate-500">
              {t("auditEmptyDesc")}
            </p>
          </div>
        ) : (
          <>
            <ol className="relative max-h-[640px] space-y-1 overflow-y-auto pe-1">
              {entries.map((e) => {
                const action = ACTION_META[e.action] ?? {
                  /* the cast is LOAD-BEARING (ROUND 145 audit): this fallback
                   * literal has no contextual type, so without it `key` widens
                   * to string and t(action.key) below stops compiling. */
                  key: "auditTitle" as I18nKey,
                  icon: "activity",
                  c1: "#64748b",
                  c2: "#475569",
                };
                const actorMeta = ACTOR_META[e.actorType] ?? ACTOR_META.system;
                return (
                  <li
                    key={e.id}
                    className="relative flex gap-3 rounded-2xl p-3 transition hover:bg-slate-50 dark:hover:bg-white/5"
                  >
                    <span
                      className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white"
                      style={{ backgroundImage: grad(action.c1, action.c2) }}
                      title={t(action.key)}
                    >
                      <CatIcon name={action.icon} className="h-[13px] w-[13px]" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                        <span>{t(action.key)}</span>
                        {e.targetLabel ? (
                          <span className="truncate font-extrabold text-slate-500 dark:text-slate-400" dir="auto">
                            · {e.targetLabel}
                          </span>
                        ) : null}
                      </p>
                      <p className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                        <span
                          className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-extrabold text-white"
                          style={{ backgroundImage: grad(actorMeta.c1, actorMeta.c2) }}
                        >
                          <CatIcon name={actorMeta.icon} className="h-2.5 w-2.5" />
                          {t(actorMeta.key)}
                        </span>
                        <span dir="ltr" className="truncate">
                          {e.actorName}
                        </span>
                      </p>
                      {e.meta && Object.keys(e.meta).length > 0 ? (
                        <div className="mt-1.5 flex flex-wrap gap-1.5">
                          {Object.entries(e.meta).slice(0, 4).map(([k, v]) => (
                            <span
                              key={k}
                              className="rounded-full border border-slate-200 bg-slate-50 px-2 py-0.5 text-[10px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-400"
                              dir="auto"
                            >
                              {k}: {v}
                            </span>
                          ))}
                        </div>
                      ) : null}
                      <p
                        className="mt-1 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500"
                        title={fullDate(e.createdAt, lang)}
                        dir="auto"
                      >
                        {relativeTime(e.createdAt, lang)}
                      </p>
                    </div>
                  </li>
                );
              })}
            </ol>

            {limit < 100 && (total > limit || (query.data?.entries.length ?? 0) >= limit) ? (
              <div className="mt-4 flex justify-center">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setLimit((l) => Math.min(100, l + 50))}
                  disabled={query.isFetching}
                  className="h-9 rounded-xl px-5 text-[12px] font-bold"
                >
                  <CatIcon name="chevron-down" className="h-3.5 w-3.5" />
                  {t("auditShowMore")}
                </Button>
              </div>
            ) : null}
          </>
        )}
      </DashCard>

      <p className="flex items-center justify-center gap-1.5 text-center text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
        <CatIcon name="lock" className="h-3 w-3 shrink-0" />
        {t("auditSecureNote")}
      </p>
    </div>
  );
}

export default AdminAudit;
