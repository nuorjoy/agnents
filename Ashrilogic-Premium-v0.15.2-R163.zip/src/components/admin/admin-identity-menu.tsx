"use client";

/**
 * Ashrilogic — admin identity menu (round 26).
 *
 * The topbar identity chip becomes a premium, fully-clickable profile card:
 * a role-gradient banner with the admin's photo / gender icon / initials,
 * a verified-session strip, an account meta grid (last login, member since,
 * account state, role-permission count) and quick navigation into the panel
 * (overview / settings / admins / audit) ending with logout. Mirrors the
 * subscriber dashboard's user-menu design language.
 */
import { useQuery } from "@tanstack/react-query";
import { useT } from "@/lib/i18n";
import type { AdminUserDTO } from "@/lib/types";
import { fetchPlatformSettings } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, labelTrack } from "@/lib/utils";
import { fullDate, relativeTime } from "@/components/dashboard/dash-shared";
import { AdminAvatar } from "@/components/admin/admin-admins";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

/** role → gradient + icon vocabulary shared with the topbar chip */
const ROLE_STYLE: Record<AdminUserDTO["role"], { c1: string; c2: string; icon: string; key: "staffRoleSuper" | "staffRoleAdmin" | "staffRoleModerator" | "staffRoleViewer" }> = {
  super: { c1: "#f59e0b", c2: "#d97706", icon: "crown", key: "staffRoleSuper" },
  admin: { c1: "#6d5dfb", c2: "#4b35c9", icon: "shield-user", key: "staffRoleAdmin" },
  moderator: { c1: "#06b6d4", c2: "#0891b2", icon: "shield-check", key: "staffRoleModerator" },
  viewer: { c1: "#64748b", c2: "#475569", icon: "eye", key: "staffRoleViewer" },
};

/** informational permission counts per role (matrix lives in admin-admins) */
const ROLE_PERMS: Record<AdminUserDTO["role"], { allowed: number; total: number }> = {
  super: { allowed: 5, total: 5 },
  admin: { allowed: 4, total: 5 },
  moderator: { allowed: 2, total: 5 },
  viewer: { allowed: 0, total: 5 },
};

export function AdminIdentityMenu({
  user,
  onNavigate,
  onLogout,
}: {
  user: AdminUserDTO;
  /** jump to a control-panel view (quick navigation items) */
  onNavigate: (view: "overview" | "settings" | "admins" | "audit") => void;
  onLogout: () => void;
}) {
  const { t, lang } = useT();
  const role = ROLE_STYLE[user.role];
  const perms = ROLE_PERMS[user.role];

  /* live settings snapshot — resolves the session-timeout fact in the card */
  const settings = useQuery({
    queryKey: ["platform-settings"],
    queryFn: fetchPlatformSettings,
    staleTime: 60_000,
  });

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-label={t("adminIdentityMenu")}
          title={t("adminIdentityMenu")}
          className="group hidden h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white/70 px-2 pe-3 outline-none transition-all duration-200 hover:border-brand-300 hover:shadow-md hover:shadow-brand-500/10 focus-visible:ring-4 focus-visible:ring-brand-500/20 active:scale-[0.97] md:flex dark:border-white/10 dark:bg-white/[0.04] dark:hover:border-brand-500/40"
        >
          <AdminAvatar admin={user} size="sm" />
          <span className="min-w-0 flex flex-col leading-tight text-start">
            <span className="max-w-32 truncate text-[11.5px] font-extrabold text-slate-800 dark:text-slate-100">
              {user.name}
            </span>
            <span
              className="flex items-center gap-1 text-[11px] font-extrabold uppercase tracking-wider"
              style={{ color: role.c1 }}
            >
              <CatIcon name={role.icon} className="h-[9px] w-[9px]" />
              <span className={labelTrack(lang)}>{t(role.key)}</span>
            </span>
          </span>
          <CatIcon
            name="chevron-down"
            className={cn(
              "h-3 w-3 text-slate-400 transition-transform duration-200 group-hover:translate-y-0.5 dark:text-slate-500"
            )}
          />
        </button>
      </DropdownMenuTrigger>

      <DropdownMenuContent
        align="end"
        aria-label={t("adminIdentityMenu")}
        className="w-80 rounded-2xl border-slate-200/80 p-0 shadow-lift dark:border-white/10"
      >
        {/* profile banner — role gradient tint + soft radial accents */}
        <div
          className="relative flex items-center gap-3 overflow-hidden rounded-t-[15px] px-3 py-3"
          style={{
            backgroundImage: `linear-gradient(135deg, ${role.c1}26, ${role.c2}26)`,
          }}
        >
          <span
            aria-hidden="true"
            className="absolute -end-6 -top-10 h-20 w-20 rounded-full"
            style={{ background: `radial-gradient(circle, ${role.c1}47, transparent 70%)` }}
          />
          <span
            aria-hidden="true"
            className="absolute -bottom-12 -start-5 h-24 w-24 rounded-full"
            style={{ background: `radial-gradient(circle, ${role.c2}38, transparent 70%)` }}
          />
          <AdminAvatar admin={user} size="lg" className="relative" />
          <div className="relative min-w-0 flex-1">
            <p className="truncate text-start text-[14px] font-extrabold leading-tight text-slate-900 dark:text-white">
              {user.name}
            </p>
            <p
              dir="ltr"
              className={cn(
                "truncate text-[11px] font-semibold leading-tight text-slate-500 dark:text-slate-400",
                lang === "ar" ? "text-end" : "text-start"
              )}
            >
              {user.email}
            </p>
            <p className="mt-1 flex min-w-0 flex-wrap items-center gap-1.5">
              <span
                className="inline-flex shrink-0 items-center gap-1 rounded-full border bg-white/70 px-1.5 py-px text-[11px] font-extrabold text-slate-600 dark:bg-white/10 dark:text-slate-300"
                style={{ borderColor: `${role.c1}55`, color: role.c1 }}
              >
                <CatIcon name={role.icon} className="h-[8px] w-[8px]" />
                {t(role.key)}
              </span>
              <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-emerald-200 bg-emerald-50/90 px-1.5 py-px text-[11px] font-extrabold text-emerald-700 dark:border-emerald-500/25 dark:bg-emerald-500/10 dark:text-emerald-300">
                <CatIcon name="badge-check" className="h-[8px] w-[8px]" />
                {t("adminIdSessionVerified")}
              </span>
            </p>
          </div>
        </div>

        {/* account meta grid */}
        <div className="grid grid-cols-2 gap-x-2 gap-y-2 border-b border-slate-200/70 px-3 py-2.5 dark:border-white/[0.07]">
          <div className="min-w-0">
            <p className={cn("text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
              {t("adminIdLastLogin")}
            </p>
            <p
              title={user.lastLoginAt ? fullDate(user.lastLoginAt, lang) : undefined}
              className="truncate text-start text-[11.5px] font-bold text-slate-700 dark:text-slate-200"
            >
              {user.lastLoginAt ? relativeTime(user.lastLoginAt, lang) : "—"}
            </p>
          </div>
          <div className="min-w-0">
            <p className={cn("text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
              {t("adminIdMemberSince")}
            </p>
            <p title={fullDate(user.createdAt, lang)} className="truncate text-start text-[11.5px] font-bold text-slate-700 dark:text-slate-200">
              {relativeTime(user.createdAt, lang)}
            </p>
          </div>
          <div className="min-w-0">
            <p className={cn("text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
              {t("adminIdAccountState")}
            </p>
            <span
              className={cn(
                "mt-0.5 inline-flex items-center gap-1 rounded-full px-1.5 py-0.5 text-[11px] font-extrabold",
                user.active
                  ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300"
                  : "bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300"
              )}
            >
              <span className={cn("h-1.5 w-1.5 rounded-full", user.active ? "bg-emerald-500" : "bg-rose-500")} aria-hidden="true" />
              {t(user.active ? "staffActive" : "staffInactive")}
            </span>
          </div>
          <div className="min-w-0">
            <p className={cn("text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
              {t("adminIdRolePerms")}
            </p>
            <p dir="ltr" className="text-start text-[11.5px] font-bold tabular-nums text-slate-700 dark:text-slate-200">
              {fmtNum(perms.allowed, lang)} / {fmtNum(perms.total, lang)}
            </p>
          </div>
          {/* session facts — timeout from live settings */}
          <div className="col-span-2 min-w-0 rounded-xl border border-slate-200/80 bg-slate-50/60 px-2.5 py-2 dark:border-white/10 dark:bg-white/[0.03]">
            <div className="flex items-center justify-between gap-2">
              <span className="flex items-center gap-1.5 text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
                <CatIcon name="clock" className="h-3 w-3 text-slate-400" />
                {t("setSessionTimeout")}
              </span>
              <span dir="ltr" className="inline-flex items-center rounded-full border border-slate-200 bg-white px-2 py-0.5 text-[11px] font-extrabold tabular-nums text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
                {settings.data ? `${fmtNum(settings.data.sessionTimeout, lang)} ${t("setMinutes")}` : "—"}
              </span>
            </div>
          </div>
        </div>

        {/* secure session strip */}
        <div className="flex items-center justify-between gap-2 border-b border-slate-200/70 bg-emerald-50/40 px-3 py-2 dark:border-white/[0.07] dark:bg-emerald-500/[0.06]">
          <span className="flex items-center gap-1.5 text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
            <CatIcon name="shield-check" className="h-3.5 w-3.5 text-emerald-500" />
            {t("adminIdSecureNote")}
          </span>
        </div>

        {/* quick navigation */}
        <p className={cn("px-3 pb-1 pt-2.5 text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
          {t("adminIdQuickNav")}
        </p>
        <div className="pb-1">
          <DropdownMenuItem
            onClick={() => onNavigate("overview")}
            className="mx-1.5 rounded-lg px-2.5 py-2 text-[12.5px] font-semibold"
          >
            <CatIcon name="chart-pie" className="h-[15px] w-[15px]" />
            {t("adminIdGoOverview")}
          </DropdownMenuItem>
          <DropdownMenuItem
            onClick={() => onNavigate("settings")}
            className="mx-1.5 rounded-lg px-2.5 py-2 text-[12.5px] font-semibold"
          >
            <CatIcon name="sliders" className="h-[15px] w-[15px]" />
            {t("adminIdGoSettings")}
          </DropdownMenuItem>
          <DropdownMenuItem
            onClick={() => onNavigate("admins")}
            className="mx-1.5 rounded-lg px-2.5 py-2 text-[12.5px] font-semibold"
          >
            <CatIcon name="shield-user" className="h-[15px] w-[15px]" />
            {t("adminIdGoAdmins")}
          </DropdownMenuItem>
          <DropdownMenuItem
            onClick={() => onNavigate("audit")}
            className="mx-1.5 rounded-lg px-2.5 py-2 text-[12.5px] font-semibold"
          >
            <CatIcon name="clock-rotate-left" className="h-[15px] w-[15px]" />
            {t("adminIdGoAudit")}
          </DropdownMenuItem>
        </div>

        <DropdownMenuSeparator className="mx-3 my-1.5 bg-slate-200/80 dark:bg-white/[0.07]" />

        <DropdownMenuItem
          onClick={onLogout}
          className="mx-1.5 mb-1.5 rounded-lg px-2.5 py-2 text-[12.5px] font-semibold text-rose-600 focus:text-rose-600 dark:text-rose-400 dark:focus:text-rose-400"
        >
          <CatIcon name="log-out" className="h-[15px] w-[15px]" />
          {t("adminLogout")}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export default AdminIdentityMenu;
