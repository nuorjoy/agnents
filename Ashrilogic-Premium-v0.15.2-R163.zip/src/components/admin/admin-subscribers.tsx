"use client";

/**
 * Ashrilogic — admin subscribers view.
 *
 * Lists every provisioned instance (subscriber) from `fetchInstances`,
 * supports a debounced search (org / admin email / admin name / system id
 * / system name), renders a Table on desktop and Cards on mobile, and
 * exposes per-row actions: "Open System Dashboard" (sets current instance +
 * view=dashboard) and "Delete" (AlertDialog confirm → deleteInstance + toast).
 * Each row also shows the assigned subscription plan as a compact chip and
 * the plan name (EN) is exported as a CSV/JSON column.
 */
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CATEGORY_MAP, MODULE_MAP, SYSTEM_MAP } from "@/data/catalog";
import { deleteInstance, fetchInstances, resetDemoData } from "@/lib/api-client";
import { useAdminCanManage } from "@/lib/admin-auth";
import { useT } from "@/lib/i18n";
import { intlLocale } from "@/lib/locales";
import { useAppStore } from "@/lib/store";
import type { InstanceDTO, Lang } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, labelTrack, normalizeSearch } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DashCard,
  IconTile,
  ViewHeading,
  fullDate,
  relativeTime,
} from "@/components/dashboard/dash-shared";
import { SubscriberDetailSheet } from "@/components/admin/subscriber-detail-sheet";
import {
  BanChip,
  BanSubscriberDialog,
  EditSubscriberDialog,
  UnbanSubscriberDialog,
} from "@/components/admin/subscriber-governance";

/** Localized region name ("SA" → "السعودية" / "Saudi Arabia" — per-locale);
    raw code fallback. */
function regionName(code: string, lang: Lang): string {
  if (!/^[A-Za-z]{2}$/.test(code)) return code || "—";
  try {
    return new Intl.DisplayNames([intlLocale(lang)], { type: "region" }).of(code) ?? code;
  } catch {
    return code;
  }
}

function PlanChip({ inst }: { inst: InstanceDTO }) {
  const { t, lang } = useT();
  const pkg = inst.package;
  return pkg ? (
    <span className="inline-flex max-w-full items-center gap-1 rounded-md bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-700 dark:bg-amber-500/15 dark:text-amber-300">
      <CatIcon name="crown" className="h-[9px] w-[9px] shrink-0" />
      <span className="truncate">{lang === "ar" ? pkg.nameAr : pkg.nameEn}</span>
    </span>
  ) : (
    <span className="inline-flex items-center rounded-md bg-slate-100 px-1.5 py-0.5 text-[10px] font-bold text-slate-400 dark:bg-white/5 dark:text-slate-500">
      {t("adminSubsNoPkg")}
    </span>
  );
}

/** ROUND 79 — workspace-state chip: surfaces locked workspaces, running
 *  trials and soon-expiring paid terms on the subscribers rows (click-free
 *  status only — the levers live in the detail sheet). Renders nothing for
 *  healthy, non-urgent rows (and for the sanitized public projection, whose
 *  neutral entitlement carries nulls). */
function EntitlementChip({ inst }: { inst: InstanceDTO }) {
  const { t, lang } = useT();
  const ent = inst.entitlement;
  if (!ent) return null;
  if (ent.state === "locked") {
    return (
      <span
        title={t("subsStateLockedHint")}
        className="inline-flex items-center gap-1 rounded-md bg-rose-100 px-1.5 py-0.5 text-[10px] font-bold text-rose-700 dark:bg-rose-500/15 dark:text-rose-300"
      >
        <CatIcon name="lock" className="h-[9px] w-[9px] shrink-0" />
        {t("subsStateLocked")}
      </span>
    );
  }
  if (ent.state === "trial") {
    return (
      <span
        title={t("featTrialFullAccess")}
        className="inline-flex items-center gap-1 rounded-md bg-violet-100 px-1.5 py-0.5 text-[10px] font-bold text-violet-700 dark:bg-violet-500/15 dark:text-violet-300"
      >
        <CatIcon name="hourglass" className="h-[9px] w-[9px] shrink-0" />
        {t("subsStateTrial")}
        {ent.trialDaysLeft !== null ? (
          <span className="tabular-nums">{fmtNum(ent.trialDaysLeft, lang)}</span>
        ) : null}
      </span>
    );
  }
  if (ent.planDaysLeft !== null && ent.planDaysLeft <= 7) {
    return (
      <span
        title={t("subsStateTermSoon")}
        className="inline-flex items-center gap-1 rounded-md bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-700 dark:bg-amber-500/15 dark:text-amber-300"
      >
        <CatIcon name="calendar-clock" className="h-[9px] w-[9px] shrink-0" />
        {t("subsStateTermSoon")}
        <span className="tabular-nums">{fmtNum(ent.planDaysLeft, lang)}</span>
      </span>
    );
  }
  return null;
}

/** violet chip marking seeded showcase data (not a real subscriber) */
function DemoBadge() {
  const { t } = useT();
  return (
    <span
      className="inline-flex items-center gap-1 rounded-md bg-violet-100 px-1.5 py-0.5 text-[10px] font-bold text-violet-700 dark:bg-violet-500/15 dark:text-violet-300"
      title={t("adminDemoHint")}
    >
      <CatIcon name="flask-conical" className="h-[9px] w-[9px] shrink-0" />
      {t("adminDemoBadge")}
    </span>
  );
}

function matchesQuery(inst: InstanceDTO, q: string): boolean {
  if (!q) return true;
  const sys = SYSTEM_MAP[inst.systemId];
  const haystack = [
    inst.org.name,
    inst.admin.email,
    inst.admin.name,
    inst.systemId,
    sys?.nameAr ?? "",
    sys?.nameEn ?? "",
  ].join(" ");
  return normalizeSearch(haystack).includes(q);
}

/** plan filter: "all" | "none" (no plan assigned) | package id */
function matchesPlan(inst: InstanceDTO, plan: string): boolean {
  if (plan === "all") return true;
  if (plan === "none") return !inst.package;
  return inst.package?.id === plan;
}

/** month filter: "all" | ISO "YYYY-MM" (instance createdAt bucket) */
function matchesMonth(inst: InstanceDTO, month: string): boolean {
  if (month === "all") return true;
  return inst.createdAt.slice(0, 7) === month;
}

/** distinct signup months present in the data (newest first) */
function monthOptionsOf(
  instances: InstanceDTO[],
  lang: Lang
): { key: string; label: string }[] {
  const keys = new Set<string>();
  for (const inst of instances) keys.add(inst.createdAt.slice(0, 7));
  return [...keys]
    .sort((a, b) => b.localeCompare(a))
    .map((key) => {
      const [y, m] = key.split("-").map(Number);
      const d = new Date(y, m - 1, 1);
      const label = new Intl.DateTimeFormat(intlLocale(lang), {
        year: "numeric",
        month: "long",
      }).format(d);
      return { key, label };
    });
}

function RowActions({
  instance,
  canManage,
  onOpen,
  onView,
  onDelete,
  onEdit,
  onBan,
  onUnban,
}: {
  instance: InstanceDTO;
  canManage: boolean;
  onOpen: (id: string) => void;
  onView: (inst: InstanceDTO) => void;
  onDelete: (id: string) => void;
  onEdit: (inst: InstanceDTO) => void;
  onBan: (inst: InstanceDTO, kind: "temporary" | "permanent") => void;
  onUnban: (inst: InstanceDTO) => void;
}) {
  const { t } = useT();
  const banned = instance.entitlement?.ban?.active === true;
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-label={t("adminColActions")}
          className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:text-slate-300"
        >
          <CatIcon name="ellipsis-vertical" className="h-[14px] w-[14px]" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-60">
        <DropdownMenuItem onClick={() => onView(instance)}>
          <CatIcon name="eye" className="h-4 w-4" />
          {t("adminDetailView")}
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => onOpen(instance.id)}>
          <CatIcon name="external-link" className="h-4 w-4" />
          {t("adminActionView")}
        </DropdownMenuItem>
        {canManage ? (
          <>
            <DropdownMenuSeparator />
            {/* ROUND 81 — precise console-side identity edit (name / phone /
                email / password) — the owner's twin, audited */}
            <DropdownMenuItem onClick={() => onEdit(instance)}>
              <CatIcon name="user-pen" className="h-4 w-4" />
              {t("subsEditData")}
            </DropdownMenuItem>
            {banned ? (
              <DropdownMenuItem
                onClick={() => onUnban(instance)}
                className="text-emerald-600 focus:text-emerald-600 dark:text-emerald-400 dark:focus:text-emerald-400"
              >
                <CatIcon name="badge-check" className="h-4 w-4" />
                {t("subsUnban")}
              </DropdownMenuItem>
            ) : (
              <>
                <DropdownMenuItem
                  onClick={() => onBan(instance, "temporary")}
                  className="text-amber-600 focus:text-amber-600 dark:text-amber-400 dark:focus:text-amber-400"
                >
                  <CatIcon name="hourglass" className="h-4 w-4" />
                  {t("subsBanTemp")}
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => onBan(instance, "permanent")}
                  className="text-rose-600 focus:text-rose-600 dark:text-rose-400 dark:focus:text-rose-400"
                >
                  <CatIcon name="octagon-x" className="h-4 w-4" />
                  {t("subsBanPerm")}
                </DropdownMenuItem>
              </>
            )}
          </>
        ) : null}
        <DropdownMenuSeparator />
        <DropdownMenuItem
          onClick={() => onDelete(instance.id)}
          className="text-rose-600 focus:text-rose-600 dark:text-rose-400 dark:focus:text-rose-400"
        >
          <CatIcon name="trash-2" className="h-4 w-4" />
          {t("adminActionDelete")}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function EmptyState() {
  const { t } = useT();
  return (
    <div className="py-14 text-center">
      <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5">
        <CatIcon name="users" className="h-6 w-6" />
      </div>
      <p className="mt-3 font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
        {t("adminNoSubscribers")}
      </p>
      <p className="mx-auto mt-1 max-w-sm text-[12px] font-semibold text-slate-400 dark:text-slate-500">
        {t("adminNoSubscribersDesc")}
      </p>
    </div>
  );
}

export function AdminSubscribers({
  planFilter,
  onPlanFilterChange,
  monthFilter,
  onMonthFilterChange,
}: {
  planFilter?: string;
  onPlanFilterChange?: (plan: string) => void;
  monthFilter?: string;
  onMonthFilterChange?: (month: string) => void;
}) {
  const { t, lang } = useT();
  const router = useRouter();
  const setCurrentInstance = useAppStore((s) => s.setCurrentInstance);
  const setView = useAppStore((s) => s.setView);
  const queryClient = useQueryClient();
  /* round 29 — reset-demo is a platform mutation (super/admin at the API) */
  const canManage = useAdminCanManage();

  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  const [pendingDelete, setPendingDelete] = useState<string | null>(null);
  const [detailInstance, setDetailInstance] = useState<InstanceDTO | null>(null);
  /* reset-demo confirm dialog (destructive-ish: wipes + re-seeds showcase rows) */
  const [confirmResetDemo, setConfirmResetDemo] = useState(false);
  /* ROUND 81 — governance dialogs: identity edit + temporary/permanent ban
   * + unban (all canManage-gated in the actions menu) */
  const [editInstance, setEditInstance] = useState<InstanceDTO | null>(null);
  const [banTarget, setBanTarget] = useState<{ inst: InstanceDTO; kind: "temporary" | "permanent" } | null>(null);
  const [unbanTarget, setUnbanTarget] = useState<InstanceDTO | null>(null);

  /* plan filter — controlled from the admin shell (overview deep-links),
     falls back to local state when the shell doesn't manage it */
  const [localPlan, setLocalPlan] = useState("all");
  const plan = planFilter ?? localPlan;
  const setPlan = onPlanFilterChange ?? setLocalPlan;

  /* signup-month filter — same controlled/local pattern as the plan filter */
  const [localMonth, setLocalMonth] = useState("all");
  const month = monthFilter ?? localMonth;
  const setMonth = onMonthFilterChange ?? setLocalMonth;

  useEffect(() => {
    const h = window.setTimeout(() => setDebounced(normalizeSearch(search.trim())), 150);
    return () => window.clearTimeout(h);
  }, [search]);

  const query = useQuery({
    queryKey: ["instances"],
    queryFn: fetchInstances,
  });

  const instances = query.data ?? [];

  /* filter options — the distinct plans actually assigned (id + localized name) */
  const planOptions = useMemo(() => {
    const map = new Map<string, string>();
    for (const inst of instances) {
      if (inst.package) {
        map.set(inst.package.id, lang === "ar" ? inst.package.nameAr : inst.package.nameEn);
      }
    }
    return [...map.entries()].map(([id, name]) => ({ id, name }));
  }, [instances, lang]);

  const filtered = useMemo(
    () => instances.filter((i) => matchesQuery(i, debounced) && matchesPlan(i, plan) && matchesMonth(i, month)),
    [instances, debounced, plan, month]
  );

  /* distinct signup months for the month filter (from the unfiltered list) */
  const monthOptions = useMemo(() => monthOptionsOf(instances, lang), [instances, lang]);
  const monthLabel = (key: string) => monthOptions.find((m) => m.key === key)?.label ?? key;

  const filtersActive = plan !== "all" || month !== "all";

  /* ----- cohort summary — composed stats for the active filter set ----- */
  const cohort = useMemo(() => {
    const total = instances.length;
    const size = filtered.length;
    const real = filtered.filter((i) => !i.demo).length;
    const demo = size - real;
    const modules = filtered.reduce((s, i) => s + (i.modules?.length ?? 0), 0);
    /* projected monthly revenue of the cohort (mixed currencies kept as-is) */
    const mrrByCurrency = new Map<string, number>();
    for (const inst of filtered) {
      if (!inst.package) continue;
      const cur = inst.package.currency;
      mrrByCurrency.set(cur, (mrrByCurrency.get(cur) ?? 0) + inst.package.priceMonthly);
    }
    const mrr = [...mrrByCurrency.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([cur, value]) => ({ cur, value }));
    /* systems touched by this cohort (distinct, capped for display) */
    const systemsTouched = new Set(filtered.map((i) => i.systemId)).size;
    return {
      total, size, real, demo, modules, mrr, systemsTouched,
      share: total > 0 ? Math.round((size / total) * 100) : 0,
    };
  }, [instances, filtered]);

  /* ----- reset demo data — delete + re-seed the backdated showcase rows ----- */
  const resetDemo = useMutation({
    mutationFn: resetDemoData,
    onSuccess: (result) => {
      toast.success(t("adminResetDemoDone", { removed: result.removed, seeded: result.seeded }));
      queryClient.invalidateQueries({ queryKey: ["instances"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const remove = useMutation({
    mutationFn: (id: string) => deleteInstance(id),
    onSuccess: () => {
      toast.success(t("adminDeleteConfirm"));
      queryClient.invalidateQueries({ queryKey: ["instances"] });
      setPendingDelete(null);
    },
    onError: (error: Error) => toast.error(`${t("adminLoginErr")}: ${error.message}`),
  });

  const openDashboard = (id: string) => {
    setCurrentInstance(id);
    setView("dashboard");
    /* ROUND 81 — the tenant dashboard renders at the app root ("/"), NOT
     * inside the /admin shell: after arming the persisted store the console
     * must actually navigate there — the click previously did nothing
     * visible from /admin (store armed, surface never shown). */
    router.push("/");
  };

  /* ----- client-side export (CSV / JSON) of the filtered list ----- */

  const exportData = (format: "csv" | "json") => {
    if (filtered.length === 0) {
      toast.error(t("adminExportEmpty"));
      return;
    }
    const rows = filtered.map((inst) => {
      const sys = SYSTEM_MAP[inst.systemId];
      const cat = sys ? CATEGORY_MAP[sys.c] : undefined;
      return {
        id: inst.id,
        systemId: inst.systemId,
        systemName: lang === "ar" ? sys?.nameAr ?? "" : sys?.nameEn ?? "",
        category: lang === "ar" ? cat?.nameAr ?? "" : cat?.nameEn ?? "",
        orgName: inst.org.name,
        orgCountry: inst.org.country,
        orgCurrency: inst.org.currency,
        orgPhone: inst.org.phone,
        adminName: inst.admin.name,
        adminEmail: inst.admin.email,
        adminRole: inst.admin.role,
        modules: inst.modules.length,
        /* ROUND 46 (F-7) — export carries the READER's language plan name */
        plan: inst.package ? (lang === "ar" ? inst.package.nameAr : inst.package.nameEn) : "",
        demo: inst.demo ? "yes" : "no",
        createdAt: inst.createdAt,
      };
    });

    let blob: Blob;
    let filename: string;
    if (format === "json") {
      blob = new Blob([JSON.stringify(rows, null, 2)], { type: "application/json" });
      filename = "ashrilogic-subscribers.json";
    } else {
      const headers = Object.keys(rows[0]);
      const esc = (v: unknown) => {
        const s = String(v ?? "");
        return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
      };
      const csv = [headers.join(","), ...rows.map((r) => headers.map((h) => esc((r as Record<string, unknown>)[h])).join(","))].join("\n");
      blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" });
      filename = "ashrilogic-subscribers.csv";
    }
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success(t("adminExportDone"));
  };

  return (
    <div className="space-y-5">
      <ViewHeading title={t("adminSubscribers")} desc={t("adminSubtitle")} />

      <DashCard>
        {/* search + plan filter + count + export */}
        <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-col gap-2.5 sm:flex-row sm:items-center">
            <div className="relative max-w-md flex-1">
              <CatIcon
                name="search"
                className="pointer-events-none absolute start-3.5 top-1/2 h-[13px] w-[13px] -translate-y-1/2 text-slate-400"
              />
              <Input
                type="search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={t("adminSearchPh")}
                aria-label={t("adminSearchPh")}
                className="h-10 rounded-xl border-slate-200 bg-slate-50/80 ps-10 pe-3 text-[12.5px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:focus:bg-white/[0.07]"
              />
            </div>
            {/* plan filter — synced with the overview plan-distribution deep-links */}
            <Select value={plan} onValueChange={setPlan}>
              <SelectTrigger
                aria-label={t("adminSubsPlanFilter")}
                className="h-10 w-full rounded-xl border-slate-200 bg-slate-50/80 text-[12.5px] font-semibold text-slate-800 transition focus:border-brand-400 focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:focus:bg-white/[0.07] sm:w-52"
              >
                <CatIcon name="gem" className="h-[13px] w-[13px] shrink-0 text-brand-500" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="max-h-64">
                <SelectGroup>
                  <SelectItem value="all">
                    {t("adminSubsPlanAll")}
                  </SelectItem>
                  {planOptions.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.name}
                    </SelectItem>
                  ))}
                  <SelectItem value="none">{t("adminPlanNoPlan")}</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
            {/* signup-month filter — synced with the overview growth-chart deep-links */}
            <Select value={month} onValueChange={setMonth}>
              <SelectTrigger
                aria-label={t("adminSubsMonthFilter")}
                className="h-10 w-full rounded-xl border-slate-200 bg-slate-50/80 text-[12.5px] font-semibold text-slate-800 transition focus:border-brand-400 focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:focus:bg-white/[0.07] sm:w-52"
              >
                <CatIcon
                  name="calendar"
                  className={cn(
                    "h-[13px] w-[13px] shrink-0",
                    month !== "all" ? "text-emerald-500" : "text-slate-400"
                  )}
                />
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="max-h-64">
                <SelectGroup>
                  <SelectItem value="all">
                    {t("adminSubsMonthAll")}
                  </SelectItem>
                  {monthOptions.map((m) => (
                    <SelectItem key={m.key} value={m.key}>
                      {m.label}
                    </SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center gap-2">
            <Badge
              variant="secondary"
              className="rounded-full px-3 py-1 text-[11px] font-extrabold text-slate-600 dark:text-slate-300"
            >
              {fmtNum(filtered.length, lang)} {t("adminSubscribers")}
            </Badge>
            <div className="flex items-center gap-1.5">
              {/* reset demo data — wipes + re-seeds the showcase subscribers
                  (round 29: super/admin only — matches the API guard) */}
              {canManage ? (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setConfirmResetDemo(true)}
                  disabled={resetDemo.isPending}
                  title={t("adminResetDemoHint")}
                  className="h-9 gap-1.5 rounded-lg border-violet-200 px-2.5 text-[11px] font-bold text-violet-600 transition hover:border-violet-300 hover:bg-violet-50 hover:text-violet-700 disabled:opacity-40 dark:border-violet-500/25 dark:text-violet-300 dark:hover:bg-violet-500/10 dark:hover:text-violet-200"
                >
                  <CatIcon
                    name={resetDemo.isPending ? "refresh-cw" : "database-backup"}
                    className={cn("h-3.5 w-3.5", resetDemo.isPending && "animate-spin")}
                  />
                  <span className="hidden md:inline">{t("adminResetDemoBtn")}</span>
                </Button>
              ) : null}
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => exportData("csv")}
                disabled={filtered.length === 0}
                className="h-9 gap-1.5 rounded-lg border-slate-200 px-2.5 text-[11px] font-bold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 disabled:opacity-40 dark:border-white/10 dark:text-slate-300"
              >
                <CatIcon name="file-output" className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">{t("adminExportCsv")}</span>
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => exportData("json")}
                disabled={filtered.length === 0}
                className="h-9 gap-1.5 rounded-lg border-slate-200 px-2.5 text-[11px] font-bold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 disabled:opacity-40 dark:border-white/10 dark:text-slate-300"
              >
                <CatIcon name="file-output" className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">{t("adminExportJson")}</span>
              </Button>
            </div>
          </div>
        </div>

        {/* cohort summary — appears when a plan/month deep-link composes a filtered cohort */}
        {filtersActive ? (
          <div className="mb-4 overflow-hidden rounded-2xl border border-brand-200/70 bg-linear-to-l from-brand-500/[0.07] via-fuchsia-500/[0.05] to-cyan-400/[0.06] dark:border-brand-500/20 dark:from-brand-500/10 dark:via-fuchsia-500/[0.07] dark:to-cyan-400/[0.08]">
            {/* chips row — clearable summary of the applied deep-links */}
            <div className="flex flex-wrap items-center gap-2 px-3.5 pt-3">
              <span className={cn("inline-flex items-center gap-1.5 text-[10px] font-extrabold uppercase text-brand-600 dark:text-brand-300", labelTrack(lang))}>
                <CatIcon name="users" className="h-3 w-3" />
                {t("adminCohortTitle")}
              </span>
              {plan !== "all" ? (
                <button
                  type="button"
                  onClick={() => setPlan("all")}
                  className="group inline-flex max-w-full items-center gap-1.5 rounded-full border border-brand-200 bg-white/80 px-2.5 py-1 text-[10.5px] font-extrabold text-brand-700 transition hover:border-brand-300 hover:bg-brand-500/10 active:scale-95 dark:border-brand-500/30 dark:bg-brand-500/15 dark:text-brand-300"
                >
                  <CatIcon name="gem" className="h-3 w-3 shrink-0 text-brand-500" />
                  <span className="truncate">
                    {plan === "none"
                      ? t("adminPlanNoPlan")
                      : planOptions.find((p) => p.id === plan)?.name ?? plan}
                  </span>
                  <CatIcon name="x" className="h-3 w-3 shrink-0 opacity-50 transition group-hover:opacity-100" />
                </button>
              ) : null}
              {month !== "all" ? (
                <button
                  type="button"
                  onClick={() => setMonth("all")}
                  className="group inline-flex max-w-full items-center gap-1.5 rounded-full border border-emerald-200 bg-white/80 px-2.5 py-1 text-[10.5px] font-extrabold text-emerald-700 transition hover:border-emerald-300 hover:bg-emerald-500/10 active:scale-95 dark:border-emerald-500/30 dark:bg-emerald-500/15 dark:text-emerald-300"
                >
                  <CatIcon name="calendar" className="h-3 w-3 shrink-0 text-emerald-500" />
                  <span className="truncate">{monthLabel(month)}</span>
                  <CatIcon name="x" className="h-3 w-3 shrink-0 opacity-50 transition group-hover:opacity-100" />
                </button>
              ) : null}
              <button
                type="button"
                onClick={() => {
                  setPlan("all");
                  setMonth("all");
                }}
                className="ms-auto inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[10.5px] font-extrabold text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 active:scale-95 dark:hover:bg-white/5 dark:hover:text-slate-300"
              >
                <CatIcon name="rotate-ccw" className="h-3 w-3" />
                {t("adminSubsFiltersClear")}
              </button>
            </div>

            {/* cohort KPI strip — size / share / real-vs-demo / systems / modules / MRR */}
            <div className="grid grid-cols-2 gap-px border-t border-brand-200/50 bg-brand-200/40 sm:grid-cols-3 lg:grid-cols-6 dark:border-brand-500/15 dark:bg-white/[0.06]">
              {[
                {
                  icon: "users",
                  label: t("adminCohortSize"),
                  value: `${fmtNum(cohort.size, lang)} · ${fmtNum(cohort.share, lang)}%`,
                },
                {
                  icon: "user-check",
                  label: t("adminCohortReal"),
                  value: fmtNum(cohort.real, lang),
                },
                {
                  icon: "flask-conical",
                  label: t("adminCohortDemo"),
                  value: fmtNum(cohort.demo, lang),
                },
                {
                  icon: "boxes",
                  label: t("adminCohortSystems"),
                  value: fmtNum(cohort.systemsTouched, lang),
                },
                {
                  icon: "grid-3x3",
                  label: t("adminCohortModules"),
                  value: fmtNum(cohort.modules, lang),
                },
                {
                  icon: "hand-coins",
                  label: t("adminCohortMrr"),
                  value:
                    cohort.mrr.length > 0
                      ? cohort.mrr
                          .slice(0, 2)
                          .map((m) => `${fmtNum(m.value, lang)} ${m.cur}`)
                          .join(" + ")
                      : "—",
                },
              ].map((cell) => (
                <div key={cell.label} className="flex items-center gap-2.5 bg-white/85 px-3.5 py-2.5 dark:bg-[#0b1220]/85">
                  <span
                    className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white shadow-sm shadow-slate-900/10 dark:shadow-black/30"
                    style={{ backgroundImage: grad("#6d5dfb", "#06b6d4") }}
                    aria-hidden="true"
                  >
                    <CatIcon name={cell.icon} className="h-[13px] w-[13px]" />
                  </span>
                  <span className="min-w-0">
                    <span className={cn("block text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {cell.label}
                    </span>
                    <span className="block truncate text-[13px] font-extrabold tabular-nums text-slate-800 dark:text-slate-100">
                      {cell.value}
                    </span>
                  </span>
                </div>
              ))}
            </div>
          </div>
        ) : null}

        {query.isPending ? (
          <div className="space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-14 w-full rounded-xl" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <EmptyState />
        ) : (
          <>
            {/* desktop table */}
            <div className="hidden md:block">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-200/70 dark:border-white/10">
                    <TableHead className={cn("text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {t("adminColSystem")}
                    </TableHead>
                    <TableHead className={cn("text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {t("adminColOrg")}
                    </TableHead>
                    <TableHead className={cn("text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {t("adminColAdmin")}
                    </TableHead>
                    <TableHead className={cn("text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {t("adminColModules")}
                    </TableHead>
                    <TableHead className={cn("text-start text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {t("adminColCreated")}
                    </TableHead>
                    <TableHead className={cn("text-end text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500", labelTrack(lang))}>
                      {t("adminColActions")}
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((inst) => {
                    const sys = SYSTEM_MAP[inst.systemId];
                    const cat = sys ? CATEGORY_MAP[sys.c] : undefined;
                    const c1 = cat?.c1 ?? "#6d5dfb";
                    const c2 = cat?.c2 ?? "#0ea5e9";
                    return (
                      <TableRow key={inst.id}>
                        <TableCell>
                          <div className="flex items-center gap-2.5">
                            <IconTile icon={sys?.icon ?? "boxes"} c1={c1} c2={c2} size="sm" />
                            <div className="min-w-0">
                              <p className="truncate text-start text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                                {sys ? (lang === "ar" ? sys.nameAr : sys.nameEn) : inst.systemId}
                              </p>
                              {/* ROUND 85 — internal SYS-xxx codes are hidden
                                  from every user surface; the sector label
                                  carries the sub-line instead */}
                              <p className="truncate text-[10px] font-bold text-slate-400 dark:text-slate-500">
                                {cat ? (lang === "ar" ? cat.nameAr : cat.nameEn) : ""}
                              </p>
                              <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                                <PlanChip inst={inst} />
                                <EntitlementChip inst={inst} />
                                <BanChip inst={inst} />
                                {inst.demo ? <DemoBadge /> : null}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <p className="truncate text-start text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                            {inst.org.name}
                          </p>
                          <p className="text-start text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                            {regionName(inst.org.country, lang)}
                          </p>
                        </TableCell>
                        <TableCell>
                          {/* admin identity — name first (identity line), email
                              below it: LTR readability, start-edge aligned in RTL */}
                          <p className="truncate text-start text-[12px] font-extrabold text-slate-700 dark:text-slate-200">
                            {inst.admin.name}
                          </p>
                          <p
                            dir="ltr"
                            className={cn(
                              "truncate text-[11px] font-semibold text-slate-400 dark:text-slate-500",
                              lang === "ar" ? "text-end" : "text-start"
                            )}
                          >
                            {inst.admin.email}
                          </p>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col items-start gap-1">
                            <Badge className="rounded-full bg-brand-500/10 px-2.5 py-0.5 text-[11px] font-extrabold tabular-nums text-brand-600 dark:text-brand-300">
                              {fmtNum(inst.modules.length, lang)}
                            </Badge>
                            {/* module detail preview — first two localized names */}
                            <p className="max-w-[160px] truncate text-start text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                              {inst.modules
                                .slice(0, 2)
                                .map((m) => {
                                  const mod = MODULE_MAP[m];
                                  return mod ? (lang === "ar" ? mod.nameAr : mod.nameEn) : m;
                                })
                                .join(lang === "ar" ? " · " : ", ")}
                              {inst.modules.length > 2 ? (lang === "ar" ? " · …" : ", …") : ""}
                            </p>
                          </div>
                        </TableCell>
                        <TableCell>
                          <p dir={lang === "ar" ? "rtl" : "ltr"} className="whitespace-nowrap text-start text-[11.5px] font-bold text-slate-600 dark:text-slate-300">
                            {fullDate(inst.createdAt, lang)}
                          </p>
                          <p className="text-start text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                            {relativeTime(inst.createdAt, lang)}
                          </p>
                        </TableCell>
                        <TableCell className="text-end">
                          <div className="inline-flex">
                            <RowActions
                              instance={inst}
                              canManage={canManage}
                              onOpen={openDashboard}
                              onView={setDetailInstance}
                              onDelete={setPendingDelete}
                              onEdit={setEditInstance}
                              onBan={(inst2, kind) => setBanTarget({ inst: inst2, kind })}
                              onUnban={setUnbanTarget}
                            />
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>

            {/* mobile cards */}
            <ul className="space-y-3 md:hidden">
              {filtered.map((inst) => {
                const sys = SYSTEM_MAP[inst.systemId];
                const cat = sys ? CATEGORY_MAP[sys.c] : undefined;
                const c1 = cat?.c1 ?? "#6d5dfb";
                const c2 = cat?.c2 ?? "#0ea5e9";
                return (
                  <li
                    key={inst.id}
                    className="rounded-2xl border border-slate-200/80 bg-white/80 p-4 dark:border-white/[0.07] dark:bg-white/[0.03]"
                  >
                    <div className="flex items-start gap-3">
                      <IconTile icon={sys?.icon ?? "boxes"} c1={c1} c2={c2} />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">
                          {sys ? (lang === "ar" ? sys.nameAr : sys.nameEn) : inst.systemId}
                        </p>
                        <p className="truncate text-[11.5px] font-bold text-slate-600 dark:text-slate-300">
                          {inst.org.name} · {regionName(inst.org.country, lang)}
                        </p>
                        <p className="truncate text-[11px] font-extrabold text-slate-700 dark:text-slate-200">
                          {inst.admin.name}
                        </p>
                        <p
                          dir="ltr"
                          className={cn(
                            "truncate text-[11px] font-semibold text-slate-400 dark:text-slate-500",
                            lang === "ar" ? "text-end" : "text-start"
                          )}
                        >
                          {inst.admin.email}
                        </p>
                        <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                          <PlanChip inst={inst} />
                          <EntitlementChip inst={inst} />
                          <BanChip inst={inst} />
                          {inst.demo ? <DemoBadge /> : null}
                        </div>
                      </div>
                      <RowActions
                        instance={inst}
                        canManage={canManage}
                        onOpen={openDashboard}
                        onView={setDetailInstance}
                        onDelete={setPendingDelete}
                        onEdit={setEditInstance}
                        onBan={(inst2, kind) => setBanTarget({ inst: inst2, kind })}
                        onUnban={setUnbanTarget}
                      />
                    </div>
                    <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-3 dark:border-white/[0.06]">
                      <Badge className="rounded-full bg-brand-500/10 px-2.5 py-0.5 text-[11px] font-extrabold text-brand-600 dark:text-brand-300">
                        {fmtNum(inst.modules.length, lang)} {t("adminColModules")}
                      </Badge>
                      <p dir={lang === "ar" ? "rtl" : "ltr"} className="text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                        {relativeTime(inst.createdAt, lang)}
                      </p>
                    </div>
                  </li>
                );
              })}
            </ul>
          </>
        )}
      </DashCard>

      {/* delete confirm */}
      <AlertDialog
        open={pendingDelete !== null}
        onOpenChange={(o) => !o && setPendingDelete(null)}
      >
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display text-lg font-extrabold text-slate-900 dark:text-white">
              {t("adminDeleteTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] text-slate-500 dark:text-slate-400">
              {t("adminDeleteMsg")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel
              className="h-10 rounded-xl px-5 text-[12.5px] font-bold"
              disabled={remove.isPending}
            >
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => pendingDelete && remove.mutate(pendingDelete)}
              disabled={remove.isPending}
              className={cn(
                "h-10 rounded-xl bg-rose-600 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-700 active:scale-95 disabled:opacity-60"
              )}
            >
              {remove.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : null}
              {t("adminDeleteConfirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* reset demo data confirm */}
      <AlertDialog open={confirmResetDemo} onOpenChange={setConfirmResetDemo}>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 font-display text-lg font-extrabold text-slate-900 dark:text-white">
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg shadow-violet-500/25"
                style={{ backgroundImage: grad("#8b5cf6", "#6d5dfb") }}
                aria-hidden="true"
              >
                <CatIcon name="database-backup" className="h-[15px] w-[15px]" />
              </span>
              {t("adminResetDemoTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
              {t("adminResetDemoMsg")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel
              className="h-10 rounded-xl px-5 text-[12.5px] font-bold"
              disabled={resetDemo.isPending}
            >
              {t("dlgCancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault(); // keep the dialog open while pending
                resetDemo.mutate(undefined, { onSuccess: () => setConfirmResetDemo(false) });
              }}
              disabled={resetDemo.isPending}
              className="h-10 gap-2 rounded-xl bg-linear-to-l from-violet-600 to-fuchsia-500 px-5 text-[12.5px] font-extrabold text-white shadow-lg shadow-violet-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
            >
              {resetDemo.isPending ? (
                <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
              ) : null}
              {t("adminResetDemoConfirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* subscriber detail drawer */}
      <SubscriberDetailSheet
        instance={detailInstance}
        open={detailInstance !== null}
        onOpenChange={(o) => !o && setDetailInstance(null)}
      />

      {/* ROUND 81 — governance dialogs (identity edit + ban + unban) */}
      <EditSubscriberDialog
        inst={editInstance}
        open={editInstance !== null}
        onOpenChange={(o) => !o && setEditInstance(null)}
      />
      <BanSubscriberDialog
        inst={banTarget?.inst ?? null}
        kind={banTarget?.kind ?? "temporary"}
        open={banTarget !== null}
        onOpenChange={(o) => !o && setBanTarget(null)}
      />
      <UnbanSubscriberDialog
        inst={unbanTarget}
        open={unbanTarget !== null}
        onOpenChange={(o) => !o && setUnbanTarget(null)}
      />
    </div>
  );
}

export default AdminSubscribers;
