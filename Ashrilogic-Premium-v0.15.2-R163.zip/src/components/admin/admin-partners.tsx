"use client";

/**
 * Ashrilogic — Super Admin TRUSTED-SECTOR console (قيادات القطاعات).
 *
 * Precise control over the landing «قيادات قطاعية تختار Ashrilogic» strip:
 *  - KPI strip (visible · hidden · available candidates · sectors covered);
 *  - a LIVE marquee preview — exactly how the homepage strip renders now;
 *  - the showcase table: real registered org name, sector chip, registration
 *    date, visibility switch, order arrows (explicit sortOrder swaps), edit
 *    (display-name overrides + sector + icon + identity colors) and delete;
 *  - the candidates card: REAL live workspaces not yet showcased (org name,
 *    system, sector, plan, registration date) with one-click add — identity
 *    defaults derive from the org's catalog sector.
 *
 * Mutations hit /api/admin/partners(+[id]); every write is audited
 * server-side. Viewer/moderator roles keep read-only visibility (the server
 * enforces; the UI mirrors it, same as every other console).
 */
import { useCallback, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  createSectorPartner,
  deleteSectorPartner,
  fetchAdminPartners,
  updateSectorPartner,
} from "@/lib/api-client";
import { useAdminCanManage } from "@/lib/admin-auth";
import { useT } from "@/lib/i18n";
import type { AdminSectorPartnerDTO, PartnerCandidateDTO } from "@/lib/types";
import { CATEGORIES } from "@/data/catalog";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad } from "@/lib/utils";
import { ViewHeading, IconTile, DashCard, dateOnly } from "@/components/dashboard/dash-shared";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

/** sector id → catalog label/icon/colors (client-side catalog is the
 *  same module the public sectors section renders from). */
const CATEGORY_MAP = new Map(CATEGORIES.map((c) => [c.id, c]));

function sectorName(sector: string, lang: string): string {
  const cat = CATEGORY_MAP.get(sector);
  return cat ? (lang === "ar" ? cat.nameAr : cat.nameEn) : sector;
}

/* ------------------------------------------------------------------ */
/* edit dialog state                                                   */
/* ------------------------------------------------------------------ */

interface EditState {
  id: string;
  instanceId: string;
  orgName: string;
  nameAr: string;
  nameEn: string;
  sector: string;
  icon: string;
  c1: string;
  c2: string;
}

/* ------------------------------------------------------------------ */
/* main view                                                           */
/* ------------------------------------------------------------------ */

export function AdminPartners() {
  const { t, lang } = useT();
  const canManage = useAdminCanManage();
  const queryClient = useQueryClient();

  const [editOpen, setEditOpen] = useState(false);
  const [edit, setEdit] = useState<EditState | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<AdminSectorPartnerDTO | null>(null);
  const [addTarget, setAddTarget] = useState<PartnerCandidateDTO | null>(null);

  const consoleQuery = useQuery({
    queryKey: ["admin-partners"],
    queryFn: fetchAdminPartners,
  });

  const rows = consoleQuery.data?.rows ?? [];
  const candidates = consoleQuery.data?.candidates ?? [];

  const invalidate = useCallback(() => {
    void queryClient.invalidateQueries({ queryKey: ["admin-partners"] });
    void queryClient.invalidateQueries({ queryKey: ["public-partners"] });
  }, [queryClient]);

  /* ---------------- mutations ---------------- */

  const addMutation = useMutation({
    mutationFn: (candidate: PartnerCandidateDTO) =>
      createSectorPartner({ instanceId: candidate.instanceId }),
    onSuccess: () => {
      toast.success(t("partnerAdded"));
      invalidate();
      setAddTarget(null);
    },
    onError: (error: Error) => toast.error(error.message || t("partnerSaveFailed")),
  });

  const updateMutation = useMutation({
    mutationFn: (args: { id: string; payload: Record<string, unknown> }) =>
      updateSectorPartner(args.id, args.payload),
    onSuccess: () => invalidate(),
    onError: (error: Error) => toast.error(error.message || t("partnerSaveFailed")),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => deleteSectorPartner(id),
    onSuccess: () => {
      toast.success(t("partnerDeleted"));
      invalidate();
      setDeleteTarget(null);
    },
    onError: (error: Error) => toast.error(error.message || t("partnerSaveFailed")),
  });

  /* reorder = explicit adjacent sortOrder swap (two sequential patches) */
  const moveMutation = useMutation({
    mutationFn: async (args: { row: AdminSectorPartnerDTO; dir: -1 | 1 }) => {
      const { row, dir } = args;
      const list = [...rows].sort((a, b) => a.sortOrder - b.sortOrder);
      const index = list.findIndex((r) => r.id === row.id);
      const other = list[index + dir];
      if (!other) return;
      await updateSectorPartner(row.id, { sortOrder: other.sortOrder });
      await updateSectorPartner(other.id, { sortOrder: row.sortOrder });
    },
    onSuccess: () => invalidate(),
    onError: (error: Error) => toast.error(error.message || t("partnerSaveFailed")),
  });

  const saveEdit = useCallback(() => {
    if (!edit) return;
    updateMutation.mutate(
      {
        id: edit.id,
        payload: {
          nameAr: edit.nameAr,
          nameEn: edit.nameEn,
          sector: edit.sector,
          icon: edit.icon,
          c1: edit.c1,
          c2: edit.c2,
        },
      },
      {
        onSuccess: () => {
          toast.success(t("partnerSaved"));
          setEditOpen(false);
        },
      }
    );
  }, [edit, updateMutation, t]);

  const openEdit = useCallback((row: AdminSectorPartnerDTO) => {
    setEdit({
      id: row.id,
      instanceId: row.instanceId,
      orgName: row.orgName,
      nameAr: row.nameAr === row.orgName ? "" : row.nameAr,
      nameEn: row.nameEn === row.orgName ? "" : row.nameEn,
      sector: row.sector,
      icon: row.icon,
      c1: row.c1,
      c2: row.c2,
    });
    setEditOpen(true);
  }, []);

  /* ---------------- derived ---------------- */

  const visibleRows = rows.filter((r) => r.visible);
  const hiddenCount = rows.length - visibleRows.length;
  const sectorsCovered = new Set(rows.filter((r) => r.visible).map((r) => r.sector)).size;
  const orderedRows = [...rows].sort((a, b) => a.sortOrder - b.sortOrder);

  /* ---------------- render ---------------- */

  return (
    <div className="space-y-6">
      <ViewHeading title={t("adminPartners")} desc={t("partnerConsoleDesc")} />

      {/* KPI strip */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {(
          [
            { label: t("partnerKpiShown"), value: visibleRows.length, icon: "eye", c1: "#10b981", c2: "#059669" },
            { label: t("partnerKpiHidden"), value: hiddenCount, icon: "eye-off", c1: "#f59e0b", c2: "#f97316" },
            { label: t("partnerKpiCandidates"), value: candidates.length, icon: "plus", c1: "#06b6d4", c2: "#0ea5e9" },
            { label: t("partnerKpiSectors"), value: sectorsCovered, icon: "network", c1: "#6d5dfb", c2: "#8b5cf6" },
          ] as const
        ).map((kpi) => (
          <DashCard key={kpi.label}>
            <div className="flex items-center gap-3">
              <IconTile icon={kpi.icon} c1={kpi.c1} c2={kpi.c2} />
              <div className="min-w-0">
                <p className="truncate text-[10.5px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  {kpi.label}
                </p>
                <p className="font-display text-xl font-extrabold tabular-nums text-slate-900 dark:text-white">
                  {fmtNum(kpi.value, lang)}
                </p>
              </div>
            </div>
          </DashCard>
        ))}
      </div>

      {/* live marquee preview — exactly what the homepage renders */}
      <DashCard title={t("partnerPreviewTitle")} icon="newspaper">
        <p className="mb-4 text-[12px] font-semibold text-slate-500 dark:text-slate-400">
          {t("partnerPreviewDesc")}
        </p>
        {visibleRows.length > 0 ? (
          <div className="relative overflow-hidden rounded-2xl border border-slate-200/70 bg-slate-50/60 p-4 dark:border-white/10 dark:bg-white/[0.02]">
            <div className="no-scrollbar flex gap-3 overflow-x-auto">
              {visibleRows.map((row) => (
                <div
                  key={row.id}
                  className="flex shrink-0 items-center gap-2.5 rounded-2xl border border-slate-200/70 bg-white/80 px-4 py-2.5 dark:border-white/[0.08] dark:bg-white/[0.04]"
                >
                  <span
                    className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white shadow-sm"
                    style={{ backgroundImage: grad(row.c1, row.c2) }}
                    aria-hidden="true"
                  >
                    <CatIcon name={row.icon} className="h-[12px] w-[12px]" />
                  </span>
                  <span className="whitespace-nowrap font-display text-[12.5px] font-extrabold text-slate-700 dark:text-slate-200">
                    {lang === "ar" ? row.displayAr : row.displayEn}
                  </span>
                  <span className="ms-1 inline-flex items-center gap-1 whitespace-nowrap rounded-full bg-emerald-50 px-2 py-0.5 text-[9.5px] font-extrabold text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400">
                    <CatIcon name="badge-check" className="h-[8px] w-[8px]" aria-hidden="true" />
                    {t("partnerSince")} {new Date(row.since).getFullYear()}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="rounded-2xl border border-dashed border-slate-200 py-8 text-center dark:border-white/10">
            <p className="text-[12.5px] font-semibold text-slate-400 dark:text-slate-500">
              {t("partnerShowcaseEmpty")}
            </p>
          </div>
        )}
      </DashCard>

      {/* showcase table */}
      <DashCard title={t("partnerShowcaseTitle")} icon="network">
        <p className="mb-4 text-[12px] font-semibold text-slate-500 dark:text-slate-400">
          {t("partnerShowcaseDesc")}
        </p>
        {consoleQuery.isLoading ? (
          <div className="space-y-2">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-16 animate-pulse rounded-2xl bg-slate-100/70 dark:bg-white/[0.04]" aria-hidden="true" />
            ))}
          </div>
        ) : orderedRows.length === 0 ? (
          <div className="py-10 text-center">
            <div className="mx-auto grid h-16 w-16 place-items-center rounded-3xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
              <CatIcon name="network" className="h-6 w-6" />
            </div>
            <p className="mx-auto mt-4 max-w-md text-[12.5px] font-semibold text-slate-500 dark:text-slate-400">
              {t("partnerShowcaseEmpty")}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto nice-scrollbar">
            <table className="w-full min-w-[820px]">
              <thead>
                <tr className="border-b border-slate-200/70 dark:border-white/10">
                  {(
                    [
                      t("partnerColOrg"),
                      t("partnerColSector"),
                      t("partnerColSince"),
                      t("partnerColVisible"),
                      t("partnerColOrder"),
                      canManage ? t("partnerColActions") : "",
                    ] as const
                  ).map((head, i) => (
                    <th
                      key={i}
                      className={cn(
                        "p-3 text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500",
                        i === 0 ? "text-start" : "text-center",
                        i === 5 && !canManage && "hidden"
                      )}
                    >
                      {head}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {orderedRows.map((row, index) => {
                  const cat = CATEGORY_MAP.get(row.sector);
                  return (
                    <tr
                      key={row.id}
                      className="border-b border-slate-100 transition-colors hover:bg-slate-50/60 dark:border-white/[0.05] dark:hover:bg-white/[0.02]"
                    >
                      <td className="p-3">
                        <div className="flex items-center gap-3">
                          <span
                            className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-sm"
                            style={{ backgroundImage: grad(row.c1, row.c2) }}
                            aria-hidden="true"
                          >
                            <CatIcon name={row.icon} className="h-[13px] w-[13px]" />
                          </span>
                          <div className="min-w-0">
                            <p className="truncate text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                              {row.displayAr}
                            </p>
                            <p className="truncate text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                              {row.displayEn}
                              {row.nameAr === "" || row.nameAr === row.orgName ? "" : ` · ${t("partnerOrgName")}: ${row.orgName}`}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="p-3 text-center">
                        <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-[10.5px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
                          <CatIcon name={cat?.icon ?? "building"} className="h-[9px] w-[9px]" style={{ color: row.c1 }} />
                          {sectorName(row.sector, lang)}
                        </span>
                      </td>
                      <td className="p-3 text-center text-[11.5px] font-bold text-slate-500 dark:text-slate-400">
                        {dateOnly(row.since, lang)}
                      </td>
                      <td className="p-3">
                        <div className="flex justify-center">
                          <Switch
                            checked={row.visible}
                            disabled={!canManage || updateMutation.isPending}
                            onCheckedChange={(v) =>
                              updateMutation.mutate({ id: row.id, payload: { visible: v } })
                            }
                            aria-label={row.visible ? t("partnerVisibleOn") : t("partnerVisibleOff")}
                          />
                        </div>
                      </td>
                      <td className="p-3">
                        {canManage ? (
                          <div className="flex items-center justify-center gap-1">
                            <button
                              type="button"
                              disabled={index === 0 || moveMutation.isPending}
                              onClick={() => moveMutation.mutate({ row, dir: -1 })}
                              title={t("partnerMoveUp")}
                              aria-label={t("partnerMoveUp")}
                              className="grid h-8 w-8 cursor-pointer place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-brand-600 active:scale-90 disabled:opacity-30 dark:text-slate-500 dark:hover:bg-white/10 dark:hover:text-brand-300"
                            >
                              <CatIcon name="chevron-up" className="h-[14px] w-[14px]" />
                            </button>
                            <button
                              type="button"
                              disabled={index === orderedRows.length - 1 || moveMutation.isPending}
                              onClick={() => moveMutation.mutate({ row, dir: 1 })}
                              title={t("partnerMoveDown")}
                              aria-label={t("partnerMoveDown")}
                              className="grid h-8 w-8 cursor-pointer place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-brand-600 active:scale-90 disabled:opacity-30 dark:text-slate-500 dark:hover:bg-white/10 dark:hover:text-brand-300"
                            >
                              <CatIcon name="chevron-down" className="h-[14px] w-[14px]" />
                            </button>
                          </div>
                        ) : null}
                      </td>
                      {canManage ? (
                        <td className="p-3">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              type="button"
                              onClick={() => openEdit(row)}
                              title={t("partnerEdit")}
                              aria-label={t("partnerEdit")}
                              className="grid h-8 w-8 cursor-pointer place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-brand-600 active:scale-90 dark:text-slate-500 dark:hover:bg-white/10 dark:hover:text-brand-300"
                            >
                              <CatIcon name="pencil" className="h-[14px] w-[14px]" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setDeleteTarget(row)}
                              title={t("partnerDeleteTitle")}
                              aria-label={t("partnerDeleteTitle")}
                              className="grid h-8 w-8 cursor-pointer place-items-center rounded-lg text-slate-400 transition hover:bg-rose-50 hover:text-rose-500 active:scale-90 dark:text-slate-500 dark:hover:bg-rose-500/10 dark:hover:text-rose-400"
                            >
                              <CatIcon name="trash-2" className="h-[14px] w-[14px]" />
                            </button>
                          </div>
                        </td>
                      ) : null}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </DashCard>

      {/* candidates card */}
      <DashCard title={t("partnerCandidatesTitle")} icon="plus">
        <p className="mb-4 text-[12px] font-semibold text-slate-500 dark:text-slate-400">
          {t("partnerCandidatesDesc")}
        </p>
        {consoleQuery.isLoading ? (
          <div className="space-y-2">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="h-16 animate-pulse rounded-2xl bg-slate-100/70 dark:bg-white/[0.04]" aria-hidden="true" />
            ))}
          </div>
        ) : candidates.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-slate-200 py-8 text-center dark:border-white/10">
            <p className="text-[12.5px] font-semibold text-slate-400 dark:text-slate-500">
              {t("partnerCandidatesEmpty")}
            </p>
          </div>
        ) : (
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {candidates.map((candidate) => {
              const cat = CATEGORY_MAP.get(candidate.sector);
              return (
                <div
                  key={candidate.instanceId}
                  className="group flex items-center gap-3 rounded-2xl border border-slate-200/80 bg-white/70 p-3.5 transition-all duration-200 hover:border-brand-200 hover:shadow-md dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-brand-500/30"
                >
                  <span
                    className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-sm"
                    style={{ backgroundImage: grad(cat?.c1 ?? "#6d5dfb", cat?.c2 ?? "#06b6d4") }}
                    aria-hidden="true"
                  >
                    <CatIcon name={cat?.icon ?? "building"} className="h-[13px] w-[13px]" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                      {candidate.orgName}
                    </p>
                    <p className="truncate text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                      {sectorName(candidate.sector, lang)} · {dateOnly(candidate.registeredAt, lang)}
                      {candidate.planLabel ? ` · ${candidate.planLabel}` : ""}
                    </p>
                  </div>
                  {canManage ? (
                    <Button
                      size="sm"
                      onClick={() => setAddTarget(candidate)}
                      disabled={addMutation.isPending}
                      className="h-8 shrink-0 rounded-lg bg-brand-500/10 px-3 text-[11px] font-extrabold text-brand-600 shadow-sm transition hover:bg-brand-500/20 active:scale-95 dark:text-brand-300"
                    >
                      <CatIcon name="plus" className="h-[11px] w-[11px]" />
                      {t("partnerAdd")}
                    </Button>
                  ) : null}
                </div>
              );
            })}
          </div>
        )}
      </DashCard>

      {/* ---------------- add confirm dialog ---------------- */}
      <Dialog open={addTarget !== null} onOpenChange={(open) => !open && setAddTarget(null)}>
        <DialogContent className="w-[min(94vw,480px)] rounded-3xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2.5 font-display text-[15px] font-extrabold">
              <IconTile icon="badge-check" c1="#10b981" c2="#059669" size="sm" />
              {t("partnerAdd")}
            </DialogTitle>
            <DialogDescription>
              {addTarget ? (
                <span className="mt-1 block text-[12.5px] leading-relaxed">
                  <strong className="font-extrabold text-slate-700 dark:text-slate-200">{addTarget.orgName}</strong>
                  {" · "}
                  {sectorName(addTarget.sector, lang)} · {dateOnly(addTarget.registeredAt, lang)}
                </span>
              ) : null}
            </DialogDescription>
          </DialogHeader>
          {addTarget ? (
            <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-4 dark:border-white/10 dark:bg-white/[0.03]">
              <div className="flex items-center gap-3">
                {(() => {
                  const cat = CATEGORY_MAP.get(addTarget.sector);
                  return (
                    <span
                      className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-white shadow-md"
                      style={{ backgroundImage: grad(cat?.c1 ?? "#6d5dfb", cat?.c2 ?? "#06b6d4") }}
                      aria-hidden="true"
                    >
                      <CatIcon name={cat?.icon ?? "building"} className="h-4 w-4" />
                    </span>
                  );
                })()}
                <div className="min-w-0 flex-1">
                  <p className="truncate font-display text-[13.5px] font-extrabold text-slate-800 dark:text-slate-100">
                    {addTarget.orgName}
                  </p>
                  <p className="text-[11px] font-bold text-slate-400 dark:text-slate-500">
                    {t("partnerSince")} {new Date(addTarget.registeredAt).getFullYear()} · {sectorName(addTarget.sector, lang)}
                  </p>
                </div>
              </div>
              <p className="mt-3 text-[11px] leading-relaxed font-semibold text-slate-500 dark:text-slate-400">
                {t("partnerEdIdentityHint")}
              </p>
            </div>
          ) : null}
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddTarget(null)} className="rounded-xl">
              {t("blogEdCancel")}
            </Button>
            <Button
              onClick={() => addTarget && addMutation.mutate(addTarget)}
              disabled={addMutation.isPending}
              className="rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-5 font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
            >
              <CatIcon name="plus" className="h-[13px] w-[13px]" />
              {t("partnerAdd")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ---------------- edit dialog ---------------- */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-h-[90vh] w-[min(94vw,560px)] overflow-y-auto nice-scrollbar rounded-3xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2.5 font-display text-[15px] font-extrabold">
              <IconTile icon="pencil-line" c1="#6d5dfb" c2="#d946ef" size="sm" />
              {t("partnerEdit")}
            </DialogTitle>
            <DialogDescription>
              {edit ? (
                <span className="mt-1 block text-[12px]">
                  {t("partnerOrgName")}: <strong className="font-extrabold">{edit.orgName}</strong>
                </span>
              ) : null}
            </DialogDescription>
          </DialogHeader>

          {edit ? (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label htmlFor="pt-name-ar" className="text-[11.5px] font-bold">
                    {t("partnerEdNameAr")}
                  </Label>
                  <Input
                    id="pt-name-ar"
                    dir="rtl"
                    value={edit.nameAr}
                    onChange={(e) => setEdit({ ...edit, nameAr: e.target.value })}
                    className="h-10 rounded-xl text-[12.5px] font-semibold"
                    placeholder={edit.orgName}
                    maxLength={120}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="pt-name-en" className="text-[11.5px] font-bold">
                    {t("partnerEdNameEn")}
                  </Label>
                  <Input
                    id="pt-name-en"
                    dir="ltr"
                    value={edit.nameEn}
                    onChange={(e) => setEdit({ ...edit, nameEn: e.target.value })}
                    className="h-10 rounded-xl text-[12.5px] font-semibold"
                    placeholder={edit.orgName}
                    maxLength={120}
                  />
                </div>
              </div>
              <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                {t("partnerEdNameHint")}
              </p>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label htmlFor="pt-sector" className="text-[11.5px] font-bold">
                    {t("partnerEdSector")}
                  </Label>
                  <select
                    id="pt-sector"
                    value={edit.sector}
                    onChange={(e) => {
                      const next = e.target.value;
                      const cat = CATEGORY_MAP.get(next);
                      setEdit({
                        ...edit,
                        sector: next,
                        icon: cat?.icon ?? edit.icon,
                        c1: cat?.c1 ?? edit.c1,
                        c2: cat?.c2 ?? edit.c2,
                      });
                    }}
                    className="h-10 w-full cursor-pointer rounded-xl border border-slate-200 bg-white px-3 text-[12.5px] font-bold text-slate-700 outline-none transition focus-visible:ring-4 focus-visible:ring-brand-500/15 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200"
                  >
                    {CATEGORIES.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {lang === "ar" ? cat.nameAr : cat.nameEn}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="pt-icon" className="text-[11.5px] font-bold">
                    {t("partnerEdIcon")}
                  </Label>
                  <div className="flex items-center gap-2">
                    <span
                      className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-sm"
                      style={{ backgroundImage: grad(edit.c1, edit.c2) }}
                      aria-hidden="true"
                    >
                      <CatIcon name={edit.icon} className="h-[13px] w-[13px]" />
                    </span>
                    <Input
                      id="pt-icon"
                      dir="ltr"
                      value={edit.icon}
                      onChange={(e) => setEdit({ ...edit, icon: e.target.value.trim().toLowerCase() })}
                      className="h-10 rounded-xl font-mono text-[12px]"
                      maxLength={40}
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-1.5">
                <Label className="text-[11.5px] font-bold">{t("partnerEdColors")}</Label>
                <div className="flex items-center gap-3">
                  <label className="flex cursor-pointer items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 dark:border-white/10 dark:bg-white/[0.04]">
                    <input
                      type="color"
                      value={edit.c1}
                      onChange={(e) => setEdit({ ...edit, c1: e.target.value })}
                      className="h-6 w-6 cursor-pointer rounded-md border-0 bg-transparent p-0"
                      aria-label="c1"
                    />
                    <span className="font-mono text-[11px] font-bold text-slate-500 dark:text-slate-400">{edit.c1}</span>
                  </label>
                  <label className="flex cursor-pointer items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 dark:border-white/10 dark:bg-white/[0.04]">
                    <input
                      type="color"
                      value={edit.c2}
                      onChange={(e) => setEdit({ ...edit, c2: e.target.value })}
                      className="h-6 w-6 cursor-pointer rounded-md border-0 bg-transparent p-0"
                      aria-label="c2"
                    />
                    <span className="font-mono text-[11px] font-bold text-slate-500 dark:text-slate-400">{edit.c2}</span>
                  </label>
                </div>
                <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                  {t("partnerEdIdentityHint")}
                </p>
              </div>

              {/* live mini preview */}
              <div className="flex items-center justify-center rounded-2xl border border-slate-200/70 bg-slate-50/60 p-5 dark:border-white/10 dark:bg-white/[0.02]">
                <div className="flex items-center gap-2.5 rounded-2xl border border-slate-200/70 bg-white px-4 py-2.5 dark:border-white/[0.08] dark:bg-white/[0.04]">
                  <span
                    className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white shadow-sm"
                    style={{ backgroundImage: grad(edit.c1, edit.c2) }}
                    aria-hidden="true"
                  >
                    <CatIcon name={edit.icon} className="h-[12px] w-[12px]" />
                  </span>
                  <span className="whitespace-nowrap font-display text-[12.5px] font-extrabold text-slate-700 dark:text-slate-200">
                    {lang === "ar" ? edit.nameAr || edit.orgName : edit.nameEn || edit.orgName}
                  </span>
                </div>
              </div>
            </div>
          ) : null}

          <DialogFooter>
            <Button variant="outline" onClick={() => setEditOpen(false)} className="rounded-xl">
              {t("blogEdCancel")}
            </Button>
            <Button
              onClick={saveEdit}
              disabled={updateMutation.isPending}
              className="rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-6 font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
            >
              <CatIcon name="save" className="h-[13px] w-[13px]" />
              {t("partnerSaved")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ---------------- delete confirm ---------------- */}
      <AlertDialog open={deleteTarget !== null} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 font-display">
              <IconTile icon="triangle-alert" c1="#e11d48" c2="#be123c" size="sm" />
              {t("partnerDeleteTitle")}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {t("partnerDeleteDesc", { name: deleteTarget?.displayAr ?? "" })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-xl">{t("blogEdCancel")}</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteTarget && deleteMutation.mutate(deleteTarget.id)}
              disabled={deleteMutation.isPending}
              className="rounded-xl bg-rose-600 font-extrabold text-white hover:bg-rose-500"
            >
              <CatIcon name="trash-2" className="h-[13px] w-[13px]" />
              {t("partnerDeleteTitle")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default AdminPartners;
