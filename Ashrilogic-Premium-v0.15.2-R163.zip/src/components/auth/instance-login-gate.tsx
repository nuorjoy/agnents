"use client";

/**
 * Ashrilogic — subscriber workspace sign-in gate.
 *
 * Premium overlay used in three flows:
 *  - my-systems "open"      → verify, then enter the dashboard
 *  - my-systems "delete"    → verify, then remove the workspace (the gate
 *                             doubles as the destructive confirmation)
 *  - dashboard session lost → inline re-auth (fetch 401) without losing state
 *
 * The sign-in panel additionally carries two auxiliary flows (never offered
 * on the destructive confirmation): "forgot password" files a public support
 * ticket and confirms with the created request id, and "don't have an
 * account" flips to a compact create-account panel that hands navigation
 * back to the parent through `onNavigateToCreate`.
 *
 * The gate never receives or exposes instance data beyond the public card
 * fields; credentials are POSTed to /api/instances/[id]/auth/login which
 * drops the HTTP-only workspace cookie.
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { CATEGORY_MAP, SYSTEM_MAP } from "@/data/catalog";
import { useT } from "@/lib/i18n";
import {
  ApiError,
  instanceLogin,
  instanceMfaLogin,
  submitPublicTicket,
} from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { grad, cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PremiumEmailInput } from "@/components/ui/premium-contact";
import { OtpInput, normalizeDigits } from "@/components/security/security-cards";
import { Label } from "@/components/ui/label";
import { PremiumClose } from "@/components/ui/premium-close";
import { EMAIL_RE } from "@/lib/validation";

export type GateIntent = "open" | "delete" | "reauth";

/**
 * Panel variant: the sign-in form, the forgot-password flow
 * (form → sent confirmation), or the create-account info panel.
 */
export type GateMode = "signin" | "forgot" | "sent" | "create";

export interface GateTarget {
  id: string;
  /** org name (or empty for the reauth variant) */
  name: string;
  systemId: string;
  /** prefilled workspace admin email when known (my-systems card data) */
  emailHint?: string;
}

const FOCUSABLE =
  "a[href], button:not([disabled]), input:not([disabled]), select, textarea, [tabindex]:not([tabindex='-1'])";

/* deliberately simple: non-blank local part + @ + domain + TLD */

export function InstanceLoginGate({
  target,
  intent,
  onClose,
  onSuccess,
  onNavigateToCreate,
}: {
  target: GateTarget;
  intent: GateIntent;
  onClose: () => void;
  onSuccess: () => void;
  /**
   * Optional parent action for "I don't have an account" — typically scrolls
   * the landing library / opens the wizard. When absent the create panel
   * hides its primary button and only keeps the back-to-sign-in link.
   */
  onNavigateToCreate?: () => void;
}) {
  const { t, lang } = useT();
  const [mode, setMode] = useState<GateMode>("signin");
  const [email, setEmail] = useState(target.emailHint ?? "");
  const [password, setPassword] = useState("");
  const [visible, setVisible] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [shake, setShake] = useState(0);
  const [sentId, setSentId] = useState<string | null>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const emailRef = useRef<HTMLInputElement>(null);

  const system = SYSTEM_MAP[target.systemId];
  const cat = system ? CATEGORY_MAP[system.c] : undefined;
  const c1 = cat?.c1 ?? "#6d5dfb";
  const c2 = cat?.c2 ?? "#0ea5e9";
  const sysName = system ? (lang === "ar" ? system.nameAr : system.nameEn) : target.name;

  const destructive = intent === "delete";
  /* auxiliary flows never appear on the destructive confirmation — it stays
     a minimal verify form (no links, no footer notes). */
  const canForgot = intent !== "delete";
  const canCreate = intent === "open";
  const showDemo = mode === "signin" && (intent === "open" || intent === "reauth");

  /* Re-focus the first control whenever the panel mode flips so the focus
     trap keeps working across the sign-in ⇄ forgot/sent/create switches. */
  useEffect(() => {
    if (mode === "signin" || mode === "forgot") {
      emailRef.current?.focus();
      return;
    }
    const primary = panelRef.current?.querySelector<HTMLElement>("[data-gate-primary]");
    const fallback = panelRef.current?.querySelector<HTMLElement>(FOCUSABLE);
    (primary ?? fallback)?.focus();
  }, [mode]);

  /* ROUND 45 — workspace 2FA: the password step may return a challenge
   * ticket instead of a session; the panel swaps to the code step. */
  const [mfa, setMfa] = useState<{ ticket: string; passkeys: boolean } | null>(null);
  const [mfaCode, setMfaCode] = useState("");
  /* ROUND 46 — backup-code mode for the challenge + 6-digit validity */
  const [backupMode, setBackupMode] = useState(false);
  const codeValid = backupMode
    ? mfaCode.trim().length >= 4
    : normalizeDigits(mfaCode).replace(/\D/g, "").length === 6;


  const login = useMutation({
    mutationFn: () => instanceLogin(target.id, { email: email.trim(), password }),
    onSuccess: (result) => {
      if ("mfaRequired" in result) {
        setMfa({ ticket: result.ticket, passkeys: result.passkeys });
        setMfaCode("");
        setError(null);
        return;
      }
      toast.success(t("gateWelcomeToast"));
      onSuccess();
    },
    onError: (e: Error) => {
      setError(e.message || t("errorText"));
      setShake((s) => s + 1);
      setPassword("");
    },
  });

  /* TOTP / backup code completion */
  const mfaVerify = useMutation({
    mutationFn: () => instanceMfaLogin(mfa!.ticket, mfaCode.trim()),
    onSuccess: () => {
      toast.success(t("gateWelcomeToast"));
      setMfa(null);
      setMfaCode("");
      onSuccess();
    },
    onError: (e: Error) => {
      setError(e instanceof ApiError && e.status === 401 ? t("mfaBadCode") : e.message || t("errorText"));
      setShake((s) => s + 1);
    },
  });

  /* passkey completion of the challenge */
  const mfaPasskey = useMutation({
    mutationFn: async () => {
      const { startAuthentication } = await import("@simplewebauthn/browser");
      const startRes = await fetch(
        `/api/instances/${encodeURIComponent(target.id)}/auth/passkey`,
        {
          method: "POST",
          credentials: "same-origin",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ step: "start", ticket: mfa!.ticket }),
        }
      );
      if (!startRes.ok) {
        const data = (await startRes.json().catch(() => ({}))) as { error?: string };
        throw new Error(data.error ?? "Passkey sign-in failed");
      }
      const { options } = (await startRes.json()) as {
        options: Parameters<typeof startAuthentication>[0]["optionsJSON"];
      };
      const assertion = await startAuthentication({ optionsJSON: options });
      const finishRes = await fetch(
        `/api/instances/${encodeURIComponent(target.id)}/auth/passkey`,
        {
          method: "POST",
          credentials: "same-origin",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ step: "finish", ticket: mfa!.ticket, response: assertion }),
        }
      );
      if (!finishRes.ok) {
        const data = (await finishRes.json().catch(() => ({}))) as { error?: string };
        throw new Error(data.error ?? "Passkey verification failed");
      }
      return (await finishRes.json()) as { ok: boolean };
    },
    onSuccess: () => {
      toast.success(t("gateWelcomeToast"));
      setMfa(null);
      setMfaCode("");
      onSuccess();
    },
    onError: (e: Error) => {
      if (e.name === "NotAllowedError") {
        toast.info(t("secPasskeyCancelled"));
        return;
      }
      setError(e.message || t("errorText"));
      setShake((s) => s + 1);
    },
  });

  /* Forgot password → public support ticket carrying the requester email and
     the workspace name; the created ticket id becomes the request id chip. */
  const forgot = useMutation({
    mutationFn: () =>
      submitPublicTicket({
        name: email.trim(),
        email: email.trim(),
        category: "technical",
        subject: t("gateForgotSubject"),
        message: t("gateForgotMessage", { email: email.trim(), name: target.name || sysName }),
      }),
    onSuccess: (ticket) => {
      setSentId(ticket.id);
      setError(null);
      setMode("sent");
    },
    onError: (e: Error) => {
      setError(e.message || t("errorText"));
      setShake((s) => s + 1);
    },
  });

  const busy = login.isPending || forgot.isPending || mfaVerify.isPending || mfaPasskey.isPending;

  const switchMode = (next: GateMode) => {
    setError(null);
    setShake(0);
    setMode(next);
  };

  /* Escape closes (unless a submit is in flight); Tab is trapped inside. */
  const onKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLDivElement>) => {
      if (e.key === "Escape" && !busy) {
        e.preventDefault();
        onClose();
        return;
      }
      if (e.key === "Tab" && panelRef.current) {
        const items = Array.from(panelRef.current.querySelectorAll<HTMLElement>(FOCUSABLE)).filter(
          (el) => el.offsetParent !== null
        );
        if (items.length === 0) return;
        const first = items[0];
        const last = items[items.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    },
    [onClose, busy]
  );

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!email.trim() || !password) {
      setError(t("gateErrEmpty"));
      setShake((s) => s + 1);
      return;
    }
    login.mutate();
  };

  const submitForgot = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!EMAIL_RE.test(email.trim())) {
      setError(t("gateForgotErrEmail"));
      setShake((s) => s + 1);
      return;
    }
    forgot.mutate();
  };

  return (
    <div
      className="fixed inset-0 z-[110] overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-label={t("gateTitle")}
      onKeyDown={onKeyDown}
    >
      {/* backdrop */}
      <button
        type="button"
        aria-label={t("dlgCancel")}
        tabIndex={-1}
        onClick={() => !busy && onClose()}
        className="absolute inset-0 cursor-default bg-slate-950/70 backdrop-blur-md"
      />

      <div className="relative flex min-h-screen items-start justify-center p-3 sm:items-center sm:p-6">
        <div
          ref={panelRef}
          tabIndex={-1}
          key={`${mode}-${shake}`}
          className={cn(
            "gate-in w-full max-w-md rounded-3xl border border-slate-200/90 bg-white p-7 shadow-lift outline-none dark:border-white/10 dark:bg-ink-900",
            shake > 0 && "gate-shake"
          )}
          dir={lang === "ar" ? "rtl" : "ltr"}
        >
          {/* header — the workspace tile + name stay put across every mode */}
          <div className="flex items-center gap-3.5">
            <span
              className="grid h-[52px] w-[52px] shrink-0 place-items-center rounded-2xl text-white shadow-lg"
              style={{ backgroundImage: grad(c1, c2), boxShadow: `0 12px 28px -12px ${c1}` }}
            >
              <CatIcon name={system?.icon ?? "boxes"} className="h-5 w-5" />
            </span>
            <div className="min-w-0 flex-1">
              <h2 className="truncate font-display text-[16px] font-extrabold text-slate-900 dark:text-white">
                {target.name || t("gateTitle")}
              </h2>
              <p className="truncate text-[11.5px] font-bold text-slate-400 dark:text-slate-500">
                {sysName} · {t("gateSubtitle")}
              </p>
            </div>
            <PremiumClose
              label={t("dlgCancel")}
              onClick={() => !busy && onClose()}
              disabled={busy}
            />
          </div>

          {mode === "sent" ? (
            /* ---------------------- recovery sent ---------------------- */
            <div className="mt-6 text-center">
              <motion.div
                initial={{ scale: 0.35, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
                className="mx-auto grid h-14 w-14 place-items-center rounded-2xl border border-emerald-300/60 bg-emerald-500/10 text-emerald-500 dark:border-emerald-500/30 dark:bg-emerald-500/15 dark:text-emerald-400"
              >
                <CatIcon name="circle-check" className="h-7 w-7" />
              </motion.div>
              <h3 className="mt-4 font-display text-[18px] font-extrabold text-slate-900 dark:text-white">
                {t("gateForgotSentTitle")}
              </h3>
              <p className="mx-auto mt-2 max-w-[36ch] text-[12.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                {t("gateForgotSentDesc")}
              </p>
              {sentId ? (
                <div
                  dir="ltr"
                  className="mx-auto mt-4 inline-flex max-w-full items-center gap-2.5 rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 dark:border-white/10 dark:bg-white/[0.04]"
                >
                  <span className="shrink-0 text-[10.5px] font-bold uppercase tracking-wide text-slate-400 dark:text-slate-500">
                    {t("gateForgotSentRef")}
                  </span>
                  <span className="truncate font-mono text-[11.5px] font-bold tracking-[0.08em] text-slate-700 dark:text-slate-200">
                    {sentId.slice(0, 8).toUpperCase()}
                  </span>
                </div>
              ) : null}
              <Button
                variant="outline"
                data-gate-primary
                onClick={() => switchMode("signin")}
                className="mt-5 h-11 w-full rounded-xl text-[13px] font-extrabold text-slate-600 transition hover:border-brand-300 hover:text-brand-600 dark:text-slate-300 dark:hover:border-brand-500/50 dark:hover:text-brand-300"
              >
                <CatIcon name="arrow-left" className="h-4 w-4 rtl:rotate-180" />
                {t("gateForgotBack")}
              </Button>
            </div>
          ) : mode === "create" ? (
            /* ---------------------- create account ---------------------- */
            <div className="mt-5">
              <div className="flex items-start gap-3 rounded-2xl border border-brand-200 bg-brand-50/60 p-3.5 dark:border-brand-500/30 dark:bg-brand-500/10">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-linear-to-br from-brand-500 to-fuchsia-500 text-white shadow-lg shadow-brand-500/25">
                  <CatIcon name="rocket" className="h-[15px] w-[15px]" />
                </span>
                <div className="min-w-0">
                  <p className="text-[12.5px] font-extrabold text-brand-700 dark:text-brand-300">
                    {t("gateCreateTitle")}
                  </p>
                  <p className="mt-1 text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                    {t("gateCreateDesc")}
                  </p>
                </div>
              </div>

              {onNavigateToCreate ? (
                <Button
                  data-gate-primary
                  onClick={onNavigateToCreate}
                  className="mt-4 h-11 w-full rounded-xl bg-linear-to-l from-brand-600 to-brand-500 text-[13px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
                >
                  <CatIcon name="rocket" className="h-4 w-4" />
                  {t("gateCreateBtn")}
                </Button>
              ) : null}

              <button
                type="button"
                onClick={() => switchMode("signin")}
                data-gate-primary={onNavigateToCreate ? undefined : true}
                className="mt-3.5 flex w-full cursor-pointer items-center justify-center gap-1.5 rounded-xl py-1.5 text-[11.5px] font-bold text-slate-400 transition hover:text-brand-600 hover:underline dark:text-slate-500 dark:hover:text-brand-300"
              >
                <CatIcon name="arrow-left" className="h-3.5 w-3.5 rtl:rotate-180" />
                {t("gateForgotBack")}
              </button>
            </div>
          ) : (
            /* ---------------------- verify / recover ---------------------- */
            <>
              {/* intent strip */}
              <div
                className={cn(
                  "mt-4 flex items-center gap-2.5 rounded-2xl border p-3",
                  destructive
                    ? "border-rose-200 bg-rose-50/70 dark:border-rose-500/30 dark:bg-rose-500/10"
                    : "border-brand-200 bg-brand-50/60 dark:border-brand-500/30 dark:bg-brand-500/10"
                )}
              >
                <span
                  className={cn(
                    "grid h-8 w-8 shrink-0 place-items-center rounded-xl text-white",
                    destructive
                      ? "bg-linear-to-br from-rose-500 to-red-600"
                      : "bg-linear-to-br from-brand-500 to-fuchsia-500"
                  )}
                >
                  <CatIcon
                    name={
                      mode === "forgot"
                        ? "key-round"
                        : destructive
                          ? "triangle-alert"
                          : "shield-check"
                    }
                    className="h-[13px] w-[13px]"
                  />
                </span>
                <p
                  className={cn(
                    "text-[12px] font-bold leading-snug",
                    destructive ? "text-rose-700 dark:text-rose-300" : "text-brand-700 dark:text-brand-300"
                  )}
                >
                  {mode === "forgot"
                    ? t("gateForgotTitle")
                    : t(
                        intent === "delete"
                          ? "gateIntentDelete"
                          : intent === "reauth"
                            ? "gateIntentReauth"
                            : "gateIntentOpen"
                      )}
                </p>
              </div>

              {mode === "forgot" ? (
                <p className="mt-3 text-[11.5px] font-semibold leading-relaxed text-slate-500 dark:text-slate-400">
                  {t("gateForgotDesc")}
                </p>
              ) : null}

              {/* error banner */}
              {error ? (
                <div
                  role="alert"
                  className="mt-3 flex items-center gap-2.5 rounded-2xl border border-rose-200 bg-rose-50/80 px-3.5 py-2.5 dark:border-rose-500/30 dark:bg-rose-500/10"
                >
                  <CatIcon name="circle-alert" className="h-4 w-4 shrink-0 text-rose-500" />
                  <p className="min-w-0 text-[12px] font-bold text-rose-700 dark:text-rose-300">{error}</p>
                </div>
              ) : null}

              {mode === "signin" && mfa ? (
                /* ---------------- ROUND 45 — 2FA step ---------------- */
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (codeValid) mfaVerify.mutate();
                  }}
                  className="mt-4 space-y-4"
                >
                  <div>
                    {backupMode ? (
                      <>
                        <Label
                          htmlFor="gate-mfa-backup"
                          className="text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
                        >
                          {t("mfaLoginCodeLabel")}
                        </Label>
                        <Input
                          id="gate-mfa-backup"
                          dir="ltr"
                          autoFocus
                          value={mfaCode}
                          onChange={(e) => setMfaCode(normalizeDigits(e.target.value.trim()).slice(0, 12))}
                          placeholder="XXXX-XXXX"
                          disabled={mfaVerify.isPending || mfaPasskey.isPending}
                          className="mt-1.5 h-11 rounded-xl text-center font-black tracking-[0.2em]"
                        />
                      </>
                    ) : (
                      <>
                        <Label
                          htmlFor="gate-otp-0"
                          className="flex items-center justify-center gap-1.5 text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
                        >
                          <CatIcon name="shield-check" className="h-3.5 w-3.5 text-emerald-500" />
                          {t("mfaLoginCodeLabel")}
                        </Label>
                        <div className="mt-2">
                          <OtpInput
                            idPrefix="gate-otp"
                            value={mfaCode}
                            onChange={setMfaCode}
                            disabled={mfaVerify.isPending || mfaPasskey.isPending}
                            invalid={!!error}
                            autoFocus
                            onComplete={() => mfaVerify.mutate()}
                            onEnter={() => mfaVerify.mutate()}
                          />
                        </div>
                      </>
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        setBackupMode((v) => !v);
                        setMfaCode("");
                        setError(null);
                      }}
                      className="mx-auto mt-2.5 flex items-center gap-1.5 text-[10.5px] font-bold text-slate-400 transition hover:text-brand-600 dark:hover:text-brand-300"
                    >
                      <CatIcon name={backupMode ? "hash" : "key-round"} className="h-3 w-3" />
                      {t(backupMode ? "mfaLoginUseCode" : "mfaLoginBackupHint")}
                    </button>
                  </div>

                  <Button
                    type="submit"
                    disabled={mfaVerify.isPending || mfaPasskey.isPending || !codeValid}
                    className="h-11 w-full rounded-xl bg-linear-to-l from-emerald-600 to-emerald-500 text-[13px] font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
                  >
                    {mfaVerify.isPending ? (
                      <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                    ) : (
                      <CatIcon name="shield-check" className="h-4 w-4" />
                    )}
                    {t("mfaLoginSubmit")}
                  </Button>

                  {mfa.passkeys ? (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => mfaPasskey.mutate()}
                      disabled={mfaVerify.isPending || mfaPasskey.isPending}
                      className="h-11 w-full gap-2 rounded-xl border-brand-300 text-[12.5px] font-extrabold text-brand-600 transition hover:border-brand-400 hover:bg-brand-50/60 disabled:opacity-60 dark:border-brand-500/40 dark:text-brand-300 dark:hover:bg-brand-500/10"
                    >
                      <CatIcon
                        name={mfaPasskey.isPending ? "refresh-cw" : "fingerprint"}
                        className={mfaPasskey.isPending ? "h-4 w-4 animate-spin" : "h-4 w-4"}
                      />
                      {t("mfaLoginPasskey")}
                    </Button>
                  ) : null}

                  <button
                    type="button"
                    onClick={() => {
                      setMfa(null);
                      setMfaCode("");
                      setError(null);
                    }}
                    className="mx-auto flex items-center gap-1.5 text-[11.5px] font-bold text-slate-400 transition hover:text-slate-600 dark:hover:text-slate-200"
                  >
                    <CatIcon name="arrow-left" className="h-3.5 w-3.5 rtl:rotate-180" />
                    {t("mfaLoginBack")}
                  </button>
                </form>
              ) : mode === "signin" ? (
                <form onSubmit={submit} className="mt-4 space-y-4">
                  <PremiumEmailInput
                    id="gate-email"
                    label="gateEmail"
                    value={email}
                    onChange={setEmail}
                    required
                    placeholder="wzAdminEmailPh"
                    autoComplete="email"
                    inputRef={emailRef}
                    disabled={login.isPending}
                  />

                  <div>
                    <Label
                      htmlFor="gate-password"
                      className="text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300"
                    >
                      {t("wzPwLabel")}
                    </Label>
                    <div className="relative">
                      <Input
                        id="gate-password"
                        type={visible ? "text" : "password"}
                        dir="ltr"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••"
                        autoComplete="current-password"
                        disabled={login.isPending}
                        className="h-11 rounded-xl pe-11 text-start"
                      />
                      <button
                        type="button"
                        onClick={() => setVisible((v) => !v)}
                        aria-label={t(visible ? "wzPwHide" : "wzPwShow")}
                        className="absolute inset-y-0 end-0 me-2.5 grid h-7 w-7 place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-white/10 dark:hover:text-slate-200"
                      >
                        <CatIcon name={visible ? "eye-off" : "eye"} className="h-[14px] w-[14px]" />
                      </button>
                    </div>
                  </div>

                  {canForgot ? (
                    <div className="flex justify-end">
                      <button
                        type="button"
                        onClick={() => switchMode("forgot")}
                        disabled={login.isPending}
                        className="cursor-pointer text-[11.5px] font-bold text-brand-600 transition hover:underline disabled:opacity-50 dark:text-brand-300"
                      >
                        {t("gateForgotPw")}
                      </button>
                    </div>
                  ) : null}

                  <Button
                    type="submit"
                    disabled={login.isPending}
                    className={cn(
                      "h-11 w-full rounded-xl text-[13px] font-extrabold text-white shadow-lg transition hover:brightness-110 active:scale-95 disabled:opacity-60",
                      destructive
                        ? "bg-destructive shadow-rose-500/25 hover:bg-destructive/90"
                        : "bg-linear-to-l from-brand-600 to-brand-500 shadow-brand-500/25"
                    )}
                  >
                    {login.isPending ? (
                      <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                    ) : (
                      <CatIcon
                        name={destructive ? "trash" : intent === "reauth" ? "refresh-cw" : "log-in"}
                        className="h-4 w-4"
                      />
                    )}
                    {t(
                      intent === "delete" ? "gateDeleteBtn" : intent === "reauth" ? "gateReauthBtn" : "gateOpenBtn"
                    )}
                  </Button>
                </form>
              ) : (
                <form onSubmit={submitForgot} className="mt-4 space-y-4">
                  <PremiumEmailInput
                    id="gate-forgot-email"
                    label="gateForgotEmailLabel"
                    value={email}
                    onChange={setEmail}
                    required
                    placeholder="wzAdminEmailPh"
                    autoComplete="email"
                    inputRef={emailRef}
                    disabled={forgot.isPending}
                  />

                  <Button
                    type="submit"
                    disabled={forgot.isPending}
                    className="h-11 w-full rounded-xl bg-linear-to-l from-brand-600 to-brand-500 text-[13px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
                  >
                    {forgot.isPending ? (
                      <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                    ) : (
                      <CatIcon name="key-round" className="h-4 w-4" />
                    )}
                    {t("gateForgotSend")}
                  </Button>
                </form>
              )}

              {canCreate && mode === "signin" ? (
                <p className="mt-4 text-center text-[11.5px] font-bold text-slate-400 dark:text-slate-500">
                  {t("gateNoAccount")}
                  <button
                    type="button"
                    onClick={() => switchMode("create")}
                    className="ms-1.5 cursor-pointer text-brand-600 transition hover:underline dark:text-brand-300"
                  >
                    {t("gateNoAccountCta")}
                  </button>
                </p>
              ) : null}
            </>
          )}

          {/* demo hint — only the plain sign-in variants (open / reauth) */}
          {showDemo ? (
            <p className="mt-4 flex items-center justify-center gap-1.5 text-center text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
              <CatIcon name="info" className="h-3 w-3 shrink-0" />
              {t("gateDemoHint")}
            </p>
          ) : null}

          {/* secure note — every non-destructive variant */}
          {!destructive ? (
            <p
              className={cn(
                "flex items-center justify-center gap-1.5 text-center text-[10.5px] font-semibold text-slate-400 dark:text-slate-500",
                showDemo ? "mt-2.5" : "mt-4"
              )}
            >
              <CatIcon name="shield-check" className="h-3 w-3 shrink-0 text-emerald-500" />
              {t("gateSecureNote")}
            </p>
          ) : null}
        </div>
      </div>
    </div>
  );
}
