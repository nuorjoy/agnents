"use client";

import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { cn } from "@/lib/utils";
import { Reveal } from "@/components/landing/reveal";

interface Feature {
  icon: string;
  tileClass: string;
  shadowClass: string;
  titleKey:
    | "feat1T"
    | "feat2T"
    | "feat3T"
    | "feat4T"
    | "feat5T"
    | "feat6T"
    | "feat7T"
    | "feat8T";
  descKey:
    | "feat1D"
    | "feat2D"
    | "feat3D"
    | "feat4D"
    | "feat5D"
    | "feat6D"
    | "feat7D"
    | "feat8D";
}

/* Eight professional advantages (round 34: "تحليل ودمج ذكي" removed,
   replaced by the real platform capabilities — public website per system,
   detail module workspaces, support & reliability). */
const FEATURES: Feature[] = [
  {
    icon: "wand-sparkles",
    tileClass: "from-brand-500 to-fuchsia-500",
    shadowClass: "shadow-brand-500/25",
    titleKey: "feat1T",
    descKey: "feat1D",
  },
  {
    icon: "gauge",
    tileClass: "from-emerald-500 to-teal-600",
    shadowClass: "shadow-emerald-500/25",
    titleKey: "feat2T",
    descKey: "feat2D",
  },
  {
    icon: "languages",
    tileClass: "from-rose-500 to-pink-600",
    shadowClass: "shadow-rose-500/25",
    titleKey: "feat3T",
    descKey: "feat3D",
  },
  {
    icon: "globe",
    tileClass: "from-cyan-500 to-sky-600",
    shadowClass: "shadow-cyan-500/25",
    titleKey: "feat4T",
    descKey: "feat4D",
  },
  {
    icon: "shield",
    tileClass: "from-fuchsia-500 to-purple-600",
    shadowClass: "shadow-fuchsia-500/25",
    titleKey: "feat5T",
    descKey: "feat5D",
  },
  {
    icon: "zap",
    tileClass: "from-amber-500 to-orange-600",
    shadowClass: "shadow-amber-500/25",
    titleKey: "feat6T",
    descKey: "feat6D",
  },
  {
    icon: "grid-3x3",
    tileClass: "from-brand-600 to-brand-800",
    shadowClass: "shadow-brand-600/25",
    titleKey: "feat7T",
    descKey: "feat7D",
  },
  {
    icon: "headset",
    tileClass: "from-teal-500 to-cyan-600",
    shadowClass: "shadow-teal-500/25",
    titleKey: "feat8T",
    descKey: "feat8D",
  },
];

export function FeaturesSection() {
  const { t } = useT();
  return (
    <section
      id="features"
      className="relative scroll-mt-20 overflow-hidden border-y border-slate-200/70 bg-white/60 px-4 py-16 backdrop-blur-sm dark:border-white/[0.07] dark:bg-white/[0.02] sm:px-6 lg:px-8 lg:py-20"
    >
      {/* decorative gradient mesh */}
      <div className="pointer-events-none absolute inset-0 -z-10 opacity-50" aria-hidden>
        <div className="absolute start-1/4 top-0 h-72 w-72 rounded-full bg-brand-500/8 blur-3xl" />
        <div className="absolute end-1/4 bottom-0 h-80 w-80 rounded-full bg-fuchsia-500/8 blur-3xl" />
      </div>
      <div className="mx-auto max-w-7xl">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3.5 py-1.5 text-[11px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
              <CatIcon name="sparkles" className="h-[11px] w-[11px] text-brand-500" />
              <span>{t("whyBadge")}</span>
            </span>
            <h2 className="mt-5 font-display text-[28px] font-extrabold tracking-tight sm:text-4xl">
              <span>{t("whyTitle1")} </span>
              <span className="text-gradient">{t("whyTitle2")}</span>
            </h2>
          </Reveal>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((feature, i) => (
            <Reveal key={feature.titleKey} delay={Math.min(i, 7) * 0.05} className="h-full">
              <article className="group h-full rounded-3xl border border-slate-200/80 bg-white p-6 transition-all duration-300 hover:-translate-y-1.5 hover:border-brand-200 hover:shadow-lift dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-brand-500/30">
                <span
                  className={cn(
                    "grid h-12 w-12 place-items-center rounded-2xl bg-linear-to-br text-white shadow-lg transition-transform duration-300 group-hover:scale-110",
                    feature.tileClass,
                    feature.shadowClass
                  )}
                >
                  <CatIcon name={feature.icon} className="h-5 w-5" />
                </span>
                <h3 className="mt-5 font-display text-lg font-extrabold">{t(feature.titleKey)}</h3>
                <p className="mt-2 text-[13px] leading-relaxed text-slate-600 dark:text-slate-400">
                  {t(feature.descKey)}
                </p>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export default FeaturesSection;
