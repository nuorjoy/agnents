"use client";

/**
 * Ashrilogic — public support section.
 *
 * Split layout: the left column lists the contact channels (live email /
 * phone from the platform settings, with a response-time card) plus the
 * support perks; the right column is the public ticket form. The form is
 * validated per-field on blur + submit, feeds the admin support inbox via
 * POST /api/support (server-side zod + per-IP rate limit), and swaps to a
 * confirmation state with the ticket reference on success.
 */
import { useState, useSyncExternalStore, type CSSProperties, type FormEvent } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { ApiError, fetchSupportContact, submitPublicTicket } from "@/lib/api-client";
import type { TicketCategory } from "@/lib/types";
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { cn, grad, hexAlpha } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Reveal } from "@/components/landing/reveal";
import { EMAIL_RE } from "@/lib/validation";

/* ------------------------------------------------------------------ */
/* vocabulary                                                          */
/* ------------------------------------------------------------------ */


const CATEGORY_OPTIONS: {
  value: TicketCategory;
  labelKey: "supCatTechnical" | "supCatBilling" | "supCatGeneral" | "supCatFeature";
}[] = [
  { value: "technical", labelKey: "supCatTechnical" },
  { value: "billing", labelKey: "supCatBilling" },
  { value: "general", labelKey: "supCatGeneral" },
  { value: "feature", labelKey: "supCatFeature" },
];

const PERK_KEYS = ["pubSupPerk1", "pubSupPerk2", "pubSupPerk3"] as const;

/* ROUND 64 — hydration guard primitives (the codebase's useSyncExternalStore
   idiom, cf. use-wishlist / admin-auth): false on the server AND during the
   client's hydration render, true on every post-hydration render — without
   any effect-time setState. */
const noopSubscribe = () => () => {};
const clientMounted = () => true;
const serverMounted = () => false;

/** Input style — the canonical wizard look (WZ_INPUT). */
const SUP_INPUT = cn(
  "h-11 w-full rounded-xl border-slate-200 bg-slate-50/80 px-3.5 text-[13px] font-semibold text-slate-800",
  "placeholder:font-normal placeholder:text-slate-400 transition",
  "focus:border-brand-400 focus:bg-white focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15",
  "dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100 dark:placeholder:text-slate-500 dark:focus:bg-white/[0.07]",
  "aria-invalid:border-rose-300 aria-invalid:ring-2 aria-invalid:ring-rose-500/20 dark:aria-invalid:border-rose-500/40"
);

const SUP_LABEL = "mb-1.5 block text-[11.5px] font-extrabold text-slate-600 dark:text-slate-300";

/* ------------------------------------------------------------------ */
/* form state                                                          */
/* ------------------------------------------------------------------ */

interface FormState {
  name: string;
  email: string;
  category: TicketCategory;
  subject: string;
  message: string;
}

type ErrorField = "name" | "email" | "subject" | "message";
type Touched = Record<ErrorField, boolean>;

const INITIAL_FORM: FormState = {
  name: "",
  email: "",
  category: "technical",
  subject: "",
  message: "",
};

const ALL_TOUCHED: Touched = { name: true, email: true, subject: true, message: true };
const NONE_TOUCHED: Touched = { name: false, email: false, subject: false, message: false };

/* ------------------------------------------------------------------ */
/* small building blocks                                               */
/* ------------------------------------------------------------------ */

function FieldError({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <p role="alert" className="mt-1 flex items-center gap-1 text-[11px] font-bold text-rose-500 dark:text-rose-400">
      <CatIcon name="triangle-alert" className="h-[11px] w-[11px] shrink-0" />
      <span>{message}</span>
    </p>
  );
}

interface Channel {
  icon: string;
  c1: string;
  c2: string;
  titleKey: "pubSupChannel1T" | "pubSupChannel2T" | "pubSupChannel3T";
  descKey: "pubSupChannel1D" | "pubSupChannel2D" | "pubSupChannel3D";
  /** live value (email / phone) — rendered only once loaded */
  value?: string;
  href?: string;
}

/* ------------------------------------------------------------------ */
/* section                                                             */
/* ------------------------------------------------------------------ */

export function SupportSection() {
  const { t, lang } = useT();

  const [form, setForm] = useState<FormState>(INITIAL_FORM);
  const [touched, setTouched] = useState<Touched>(NONE_TOUCHED);
  const [sentId, setSentId] = useState<string | null>(null);

  /* ROUND 64 — hydration guard. This section is a LAZY chunk, while the
     ["support-contact"] query is ALSO fired by the statically-imported
     landing footer during the initial hydration pass — so by the time this
     chunk mounts, the react-query cache can already hold resolved data.
     Rendering the live email/phone anchor on the first client render would
     mismatch the SSR skeleton (the server always renders pending) and fail
     hydration. Gate the live values behind this post-hydration flag: the
     hydration render is deterministic (skeleton), the anchor swaps in right
     after — with zero effect-time setState (house rule). */
  const mounted = useSyncExternalStore(noopSubscribe, clientMounted, serverMounted);

  const contact = useQuery({
    queryKey: ["support-contact"],
    queryFn: fetchSupportContact,
    staleTime: 300_000,
  });

  const submit = useMutation({
    mutationFn: submitPublicTicket,
    onSuccess: (ticket) => {
      setSentId(ticket.id);
      toast.success(t("pubSupSentTitle"));
    },
    onError: (error: Error) => {
      if (error instanceof ApiError && error.status === 429) {
        toast.error(t("pubSupErrRate"));
      } else {
        toast.error(error.message || t("errorText"));
      }
    },
  });

  /* ---------- per-field validation (mirror of the server schema) ---------- */

  const errorFor = (field: ErrorField): string | null => {
    const value = form[field].trim();
    switch (field) {
      case "name":
        return value.length < 2 ? t("pubSupErrName") : null;
      case "email":
        return EMAIL_RE.test(value) ? null : t("pubSupErrEmail");
      case "subject":
        return value.length < 3 ? t("pubSupErrSubject") : null;
      case "message":
        return value.length < 10 ? t("pubSupErrMessage") : null;
    }
  };

  const shown = (field: ErrorField): string | null =>
    touched[field] ? errorFor(field) : null;

  const touch = (field: ErrorField) => setTouched((prev) => ({ ...prev, [field]: true }));

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (submit.isPending) return;

    setTouched(ALL_TOUCHED);
    const hasError = (["name", "email", "subject", "message"] as const).some(
      (field) => errorFor(field) !== null
    );
    if (hasError) return;

    submit.mutate({
      name: form.name.trim(),
      email: form.email.trim(),
      category: form.category,
      subject: form.subject.trim(),
      message: form.message.trim(),
    });
  };

  const resetForm = () => {
    setForm(INITIAL_FORM);
    setTouched(NONE_TOUCHED);
    setSentId(null);
    submit.reset();
  };

  /* ---------- contact channels (live values when loaded) ---------- */

  const phoneHref = contact.data
    ? `tel:${contact.data.supportPhone.replace(/[\s-]/g, "")}`
    : undefined;

  const channels: Channel[] = [
    {
      icon: "mail",
      c1: "#6d5dfb",
      c2: "#d946ef",
      titleKey: "pubSupChannel1T",
      descKey: "pubSupChannel1D",
      value: contact.data?.supportEmail,
      href: contact.data ? `mailto:${contact.data.supportEmail}` : undefined,
    },
    {
      icon: "phone",
      c1: "#06b6d4",
      c2: "#0891b2",
      titleKey: "pubSupChannel2T",
      descKey: "pubSupChannel2D",
      value: contact.data?.supportPhone,
      href: phoneHref,
    },
    {
      icon: "timer",
      c1: "#f59e0b",
      c2: "#ea580c",
      titleKey: "pubSupChannel3T",
      descKey: "pubSupChannel3D",
    },
  ];

  return (
    <section id="support" className="scroll-mt-20 px-4 py-16 sm:px-6 lg:px-8 lg:py-20">
      <div className="mx-auto max-w-7xl">
        {/* heading */}
        <div className="mx-auto max-w-3xl text-center">
          <Reveal>
            <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3.5 py-1.5 text-[11px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
              <CatIcon name="life-buoy" className="h-[11px] w-[11px] text-brand-500" />
              <span>{t("pubSupBadge")}</span>
            </span>
            <h2 className="mt-5 font-display text-[28px] font-extrabold leading-tight tracking-tight sm:text-4xl">
              <span>{t("pubSupTitle1")} </span>
              <span className="text-gradient">{t("pubSupTitle2")}</span>
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-[14px] leading-relaxed text-slate-600 dark:text-slate-400 sm:text-[15px]">
              {t("pubSupDesc")}
            </p>
          </Reveal>
        </div>

        <div className="mt-10 grid gap-5 lg:grid-cols-5 lg:items-start">
          {/* LEFT — contact channels + perks */}
          <Reveal className="lg:col-span-2">
            <div className="space-y-4">
              {channels.map((channel, i) => (
                <div
                  key={channel.icon}
                  className="glass-card card-in group flex items-center gap-3.5 rounded-2xl p-4 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg"
                  style={{ "--i": i } as CSSProperties}
                >
                  <span
                    className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg transition-transform duration-300 group-hover:scale-110"
                    style={{
                      backgroundImage: grad(channel.c1, channel.c2),
                      boxShadow: `0 10px 24px -10px ${hexAlpha(channel.c1, 0.8)}`,
                    }}
                    aria-hidden="true"
                  >
                    <CatIcon name={channel.icon} className="h-[17px] w-[17px]" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-extrabold text-slate-900 dark:text-white">
                      {t(channel.titleKey)}
                    </p>
                    {mounted && channel.value ? (
                      <a
                        href={channel.href}
                        dir="ltr"
                        className={cn(
                          "mt-0.5 block truncate font-mono text-[12px] font-bold text-brand-600 transition hover:text-brand-500 dark:text-brand-300 dark:hover:text-brand-200",
                          /* ROUND 55 — full Arabic alignment: the LTR email /
                             phone VALUE stays logically ordered (dir=ltr) but
                             is anchored to the FAR RIGHT edge on the Arabic
                             page so it lines up under the Arabic title. */
                          lang === "ar" && "text-end"
                        )}
                      >
                        {channel.value}
                      </a>
                    ) : contact.isPending || !mounted ? (
                      <span
                        className="mt-1 block h-3 w-24 animate-pulse rounded-full bg-slate-200/80 dark:bg-white/10"
                        aria-hidden="true"
                      />
                    ) : null}
                    <p className="mt-0.5 text-[11.5px] font-medium text-slate-500 dark:text-slate-400">
                      {t(channel.descKey)}
                    </p>
                  </div>
                </div>
              ))}

              {/* perks */}
              <div
                className="glass-card card-in rounded-2xl p-4"
                style={{ "--i": 3 } as CSSProperties}
              >
                <ul className="space-y-2.5">
                  {PERK_KEYS.map((key) => (
                    <li
                      key={key}
                      className="flex items-center gap-2.5 text-[12.5px] font-semibold text-slate-600 dark:text-slate-300"
                    >
                      <span
                        className="grid h-4.5 w-4.5 shrink-0 place-items-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400"
                        aria-hidden="true"
                      >
                        <CatIcon name="shield-check" className="h-[10px] w-[10px]" />
                      </span>
                      <span>{t(key)}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </Reveal>

          {/* RIGHT — ticket form */}
          <Reveal delay={0.1} className="lg:col-span-3">
            <div className="glass-card rounded-3xl p-5 sm:p-6">
              {sentId ? (
                /* ---------- success state ---------- */
                <div className="step-in flex flex-col items-center py-8 text-center sm:py-10">
                  <span
                    className="grid h-16 w-16 place-items-center rounded-full text-white shadow-lg shadow-brand-500/30"
                    style={{ backgroundImage: grad("#6d5dfb", "#06b6d4") }}
                    aria-hidden="true"
                  >
                    <CatIcon name="badge-check" className="h-8 w-8" />
                  </span>
                  <h3 className="mt-5 font-display text-xl font-extrabold text-slate-900 dark:text-white">
                    {t("pubSupSentTitle")}
                  </h3>
                  <p className="mt-2 max-w-sm text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
                    {t("pubSupSentDesc")}
                  </p>
                  <span className="mt-5 inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-[11px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400">
                    {t("pubSupSentRef")}
                    <span
                      dir="ltr"
                      className="font-mono text-[11px] font-extrabold tracking-[0.12em] text-brand-600 dark:text-brand-300"
                    >
                      {sentId.slice(-8).toUpperCase()}
                    </span>
                  </span>
                  <button
                    type="button"
                    onClick={resetForm}
                    className="mt-6 inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-5 text-[12.5px] font-extrabold text-slate-700 transition hover:border-brand-300 hover:text-brand-600 hover:shadow-md active:scale-95 dark:border-white/10 dark:bg-white/5 dark:text-slate-200 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
                  >
                    <CatIcon name="refresh-cw" className="h-3.5 w-3.5" />
                    {t("pubSupSentAnother")}
                  </button>
                </div>
              ) : (
                /* ---------- form state ---------- */
                <>
                  <div className="flex items-start gap-3.5 border-b border-slate-200/70 pb-4 dark:border-white/10">
                    <span
                      className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg shadow-brand-500/25"
                      style={{ backgroundImage: grad("#6d5dfb", "#06b6d4") }}
                      aria-hidden="true"
                    >
                      <CatIcon name="headset" className="h-5 w-5" />
                    </span>
                    <div>
                      <h3 className="font-display text-[17px] font-extrabold text-slate-900 dark:text-white">
                        {t("pubSupFormTitle")}
                      </h3>
                      <p className="mt-0.5 text-[12px] text-slate-500 dark:text-slate-400">
                        {t("pubSupFormDesc")}
                      </p>
                    </div>
                  </div>

                  <form onSubmit={handleSubmit} noValidate className="mt-5 space-y-4">
                    {/* name + email */}
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div>
                        <Label htmlFor="sup-name" className={SUP_LABEL}>
                          {t("pubSupName")}
                        </Label>
                        <Input
                          id="sup-name"
                          value={form.name}
                          onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                          onBlur={() => touch("name")}
                          placeholder={t("pubSupNamePh")}
                          autoComplete="name"
                          aria-invalid={Boolean(shown("name")) || undefined}
                          className={SUP_INPUT}
                        />
                        <FieldError message={shown("name")} />
                      </div>
                      <div>
                        <Label htmlFor="sup-email" className={SUP_LABEL}>
                          {t("pubSupEmail")}
                        </Label>
                        <Input
                          id="sup-email"
                          type="email"
                          dir="ltr"
                          value={form.email}
                          onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                          onBlur={() => touch("email")}
                          placeholder={t("pubSupEmailPh")}
                          autoComplete="email"
                          aria-invalid={Boolean(shown("email")) || undefined}
                          className={SUP_INPUT}
                        />
                        <FieldError message={shown("email")} />
                      </div>
                    </div>

                    {/* category */}
                    <div>
                      <Label htmlFor="sup-category" className={SUP_LABEL}>
                        {t("pubSupCategory")}
                      </Label>
                      <Select
                        value={form.category}
                        onValueChange={(v) => setForm((f) => ({ ...f, category: v as TicketCategory }))}
                      >
                        <SelectTrigger
                          id="sup-category"
                          className={cn(
                            SUP_INPUT,
                            "h-11 w-full justify-between data-[size=default]:h-11"
                          )}
                        >
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="rounded-xl">
                          <SelectGroup>
                            {CATEGORY_OPTIONS.map((option) => (
                              <SelectItem
                                key={option.value}
                                value={option.value}
                                className="text-[12.5px] font-bold"
                              >
                                {t(option.labelKey)}
                              </SelectItem>
                            ))}
                          </SelectGroup>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* subject */}
                    <div>
                      <Label htmlFor="sup-subject" className={SUP_LABEL}>
                        {t("pubSupSubject")}
                      </Label>
                      <Input
                        id="sup-subject"
                        value={form.subject}
                        onChange={(e) => setForm((f) => ({ ...f, subject: e.target.value }))}
                        onBlur={() => touch("subject")}
                        placeholder={t("pubSupSubjectPh")}
                        aria-invalid={Boolean(shown("subject")) || undefined}
                        className={SUP_INPUT}
                      />
                      <FieldError message={shown("subject")} />
                    </div>

                    {/* message */}
                    <div>
                      <Label htmlFor="sup-message" className={SUP_LABEL}>
                        {t("pubSupMessage")}
                      </Label>
                      <Textarea
                        id="sup-message"
                        rows={5}
                        value={form.message}
                        onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
                        onBlur={() => touch("message")}
                        placeholder={t("pubSupMessagePh")}
                        aria-invalid={Boolean(shown("message")) || undefined}
                        className={cn(
                          SUP_INPUT,
                          "h-auto min-h-[118px] resize-y py-2.5 leading-relaxed"
                        )}
                      />
                      <FieldError message={shown("message")} />
                    </div>

                    <button
                      type="submit"
                      disabled={submit.isPending}
                      className="mt-1 inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 text-[13px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95 disabled:cursor-not-allowed disabled:opacity-70"
                    >
                      {submit.isPending ? (
                        <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
                      ) : (
                        <CatIcon name="telegram" className="h-4 w-4" />
                      )}
                      {submit.isPending ? t("pubSupSending") : t("pubSupSubmit")}
                    </button>
                  </form>
                </>
              )}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

export default SupportSection;
