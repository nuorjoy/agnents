"use client";

import { useEffect, useState } from "react";

/**
 * Ashrilogic — scroll progress bar.
 *
 * A 3px fixed gradient bar (brand → fuchsia → cyan) pinned to the very top of
 * the viewport, showing how far the page has been scrolled. Anchored to the
 * inline-start edge so it grows right-to-left under RTL. The scroll listener
 * is rAF-throttled and passive.
 */
export function ScrollProgress() {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    let raf = 0;
    const update = () => {
      const doc = document.documentElement;
      const max = doc.scrollHeight - doc.clientHeight;
      setProgress(max > 0 ? Math.min(1, doc.scrollTop / max) : 0);
    };
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  return (
    <div
      aria-hidden="true"
      className="pointer-events-none fixed inset-x-0 top-0 z-[60] h-[3px]"
    >
      <div
        className="absolute inset-y-0 start-0 h-full rounded-e-full bg-linear-to-r from-brand-500 via-fuchsia-500 to-cyan-400"
        style={{ width: `${progress * 100}%` }}
      />
    </div>
  );
}

export default ScrollProgress;
