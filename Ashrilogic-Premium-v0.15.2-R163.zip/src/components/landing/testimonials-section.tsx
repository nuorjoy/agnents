"use client";

/**
 * Ashrilogic — testimonials section (آراء ملاك الأنظمة).
 *
 * Premium social-proof block: a badge + gradient headline and SIX curated
 * testimonial cards — system OWNERS (sector leaders) explaining how
 * important their systems are and the value the systems delivered to
 * their organizations — plus an animated stats strip powered by
 * `useCountUp` (triggers on scroll-in).
 *
 * ROUND 89 — the section was re-scoped by product decision: ONLY owner
 * (sector-leader) opinions render, EXACTLY six, i18n-complete (AR/EN/HI).
 * The public customer-review feed (/api/testimonials) is no longer a data
 * source for this section.
 */
import { useT } from "@/lib/i18n";
import { useCountUp } from "@/hooks/use-count-up";
import { CatIcon } from "@/components/icon";
import { Reveal } from "@/components/landing/reveal";
import { cn, grad } from "@/lib/utils";

interface Testimonial {
  nameAr: string;
  nameEn: string;
  roleKey: "test1Role" | "test2Role" | "test3Role" | "test4Role" | "test5Role" | "test6Role";
  quoteKey: "test1Quote" | "test2Quote" | "test3Quote" | "test4Quote" | "test5Quote" | "test6Quote";
  c1: string;
  c2: string;
  icon: string;
}

/* exactly six system owners — sector leaders, one flagship persona per
   sector (healthcare / education / restaurants / retail / logistics /
   real estate), each explaining the system's importance + benefit. */
const TESTIMONIALS: Testimonial[] = [
  {
    nameAr: "د. خالد العتيبي",
    nameEn: "Dr. Khalid Al-Otaibi",
    roleKey: "test1Role",
    quoteKey: "test1Quote",
    c1: "#f43f5e",
    c2: "#ec4899",
    icon: "heart-pulse",
  },
  {
    nameAr: "م. سارة المنصور",
    nameEn: "Eng. Sarah Al-Mansour",
    roleKey: "test2Role",
    quoteKey: "test2Quote",
    c1: "#8b5cf6",
    c2: "#6366f1",
    icon: "graduation-cap",
  },
  {
    nameAr: "أ. عبدالله الحربي",
    nameEn: "Mr. Abdullah Al-Harbi",
    roleKey: "test3Role",
    quoteKey: "test3Quote",
    c1: "#f59e0b",
    c2: "#ea580c",
    icon: "utensils",
  },
  {
    nameAr: "أ. ريم الدوسري",
    nameEn: "Ms. Reem Al-Dossari",
    roleKey: "test4Role",
    quoteKey: "test4Quote",
    c1: "#10b981",
    c2: "#0e7490",
    icon: "shopping-bag",
  },
  {
    nameAr: "م. طارق الشمري",
    nameEn: "Eng. Tariq Al-Shammari",
    roleKey: "test5Role",
    quoteKey: "test5Quote",
    c1: "#06b6d4",
    c2: "#0891b2",
    icon: "truck",
  },
  {
    nameAr: "أ. فهد القحطاني",
    nameEn: "Mr. Fahad Al-Qahtani",
    roleKey: "test6Role",
    quoteKey: "test6Quote",
    c1: "#d946ef",
    c2: "#a855f7",
    icon: "house",
  },
];

function Stars({ rating }: { rating: number }) {
  const filled = Math.max(0, Math.min(5, Math.round(rating)));
  return (
    <div className="flex items-center gap-0.5" aria-label={`${filled} / 5`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <CatIcon
          key={i}
          name="star"
          className={cn(
            "h-[13px] w-[13px]",
            i < filled
              ? "fill-amber-400 text-amber-400"
              : "fill-slate-200 text-slate-200 dark:fill-white/10 dark:text-white/10"
          )}
        />
      ))}
    </div>
  );
}

function Avatar({ t, c1, c2, icon, name }: { t: string; c1: string; c2: string; icon: string; name: string }) {
  return (
    <div className="flex items-center gap-3">
      <span
        className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
        style={{ backgroundImage: grad(c1, c2), boxShadow: `0 8px 20px -8px ${c1}` }}
        aria-hidden="true"
      >
        <CatIcon name={icon} className="h-[16px] w-[16px]" />
      </span>
      <div className="min-w-0">
        <p className="truncate font-display text-[14px] font-extrabold text-slate-900 dark:text-white">
          {name}
        </p>
        <p className="truncate text-[11px] font-semibold text-slate-500 dark:text-slate-400">
          {t}
        </p>
      </div>
    </div>
  );
}

function StatCounter({ target, suffix, label }: { target: number; suffix?: string; label: string }) {
  const { ref, value } = useCountUp(target);
  return (
    <div className="text-center">
      <p className="font-display text-3xl font-extrabold sm:text-4xl">
        <span className="bg-clip-text text-transparent bg-linear-to-br from-brand-500 via-fuchsia-500 to-cyan-400">
          <span ref={ref}>
            {value.toLocaleString("en-US")}
            {suffix}
          </span>
        </span>
      </p>
      <p className="mt-1 text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
        {label}
      </p>
    </div>
  );
}

export function TestimonialsSection() {
  const { t, lang } = useT();

  return (
    <section id="testimonials" className="relative scroll-mt-20 overflow-hidden px-4 py-16 sm:px-6 lg:px-8 lg:py-20">
      {/* decorative gradient mesh background */}
      <div
        className="pointer-events-none absolute inset-0 -z-10 opacity-60"
        aria-hidden="true"
      >
        <div className="absolute -start-20 top-10 h-72 w-72 rounded-full bg-brand-500/10 blur-3xl" />
        <div className="absolute end-0 top-1/2 h-80 w-80 rounded-full bg-fuchsia-500/8 blur-3xl" />
        <div className="absolute -end-10 bottom-0 h-64 w-64 rounded-full bg-cyan-400/10 blur-3xl" />
      </div>
      <div className="mx-auto max-w-7xl">
        {/* heading */}
        <div className="mx-auto max-w-3xl text-center">
          <Reveal>
            <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3.5 py-1.5 text-[11px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
              <CatIcon name="quote" className="h-[11px] w-[11px] text-brand-500" />
              <span>{t("testBadge")}</span>
            </span>
            <h2 className="mt-5 font-display text-[28px] font-extrabold leading-tight tracking-tight sm:text-4xl">
              <span>{t("testTitle1")} </span>
              <span className="text-gradient">{t("testTitle2")}</span>
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-[14px] leading-relaxed text-slate-600 dark:text-slate-400 sm:text-[15px]">
              {t("testDesc")}
            </p>
          </Reveal>
        </div>

        {/* testimonial cards — EXACTLY six system owners (sector leaders) */}
        <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {TESTIMONIALS.map((tm, i) => (
            <Reveal key={tm.roleKey} delay={(i % 3) * 0.1}>
              <figure
                className={cn(
                  "glass-card card-in group relative flex h-full flex-col overflow-hidden rounded-3xl p-6 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-lift"
                )}
                style={{ ["--i" as string]: i }}
              >
                {/* decorative quote mark */}
                <CatIcon
                  name="quote"
                  className="pointer-events-none absolute end-4 top-4 h-10 w-10 text-slate-100 transition-colors duration-300 group-hover:text-slate-200 dark:text-white/[0.04] dark:group-hover:text-white/[0.06]"
                />
                <Stars rating={5} />
                <blockquote className="relative mt-4 line-clamp-6 flex-1 text-[13.5px] leading-relaxed text-slate-700 dark:text-slate-300">
                  &ldquo;{t(tm.quoteKey)}&rdquo;
                </blockquote>
                <figcaption className="mt-5 border-t border-dashed border-slate-200 pt-4 dark:border-white/10">
                  <Avatar
                    t={t(tm.roleKey)}
                    c1={tm.c1}
                    c2={tm.c2}
                    icon={tm.icon}
                    name={lang === "ar" ? tm.nameAr : tm.nameEn}
                  />
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>

        {/* animated stats strip */}
        <Reveal delay={0.15}>
          <div className="glass-card mt-10 grid grid-cols-2 gap-4 rounded-3xl p-6 sm:p-8 md:grid-cols-4">
            {/* counts must match the catalog (SYSTEMS / CATEGORIES / MODULES) */}
            <StatCounter target={102} label={t("statSystems")} />
            <StatCounter target={16} label={t("statSectors")} />
            <StatCounter target={142} label={t("statModules")} />
            <StatCounter target={24} suffix="/7" label={t("statSupport")} />
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export default TestimonialsSection;
