"use client";

/**
 * Ashrilogic — newsletter signup form.
 *
 * Inline email + subscribe form backed by the real `/api/subscribe` route.
 * Client-side pre-validation, server-side validation, loading state, and
 * localized success/error toasts. Falls back gracefully on network errors.
 */
import { useState } from "react";
import { toast } from "sonner";
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { EMAIL_RE } from "@/lib/validation";


export function NewsletterForm() {
  const { t, lang } = useT();
  const [email, setEmail] = useState("");
  const [pending, setPending] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!EMAIL_RE.test(email.trim())) {
      toast.error(t("newsErr"));
      return;
    }
    setPending(true);
    try {
      const res = await fetch("/api/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim() }),
      });
      const data = (await res.json()) as { ok?: boolean; error?: string; message?: string };
      if (res.ok && data.ok) {
        toast.success(t("newsDone"));
        setEmail("");
      } else {
        toast.error(data.error || t("newsErr"));
      }
    } catch {
      toast.error(t("newsErr"));
    } finally {
      setPending(false);
    }
  };

  return (
    <form onSubmit={submit} className="w-full">
      <div className="flex flex-col gap-2 sm:flex-row">
        <div className="relative flex-1">
          <CatIcon
            name="mail"
            className="pointer-events-none absolute start-3 top-1/2 h-[14px] w-[14px] -translate-y-1/2 text-slate-400"
          />
          <Input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder={t("newsPh")}
            aria-label={t("newsPh")}
            autoComplete="email"
            /* ROUND 55 — full Arabic formatting: the placeholder (بريدك
               الإلكتروني) anchors to the FAR RIGHT on the Arabic page. Typed
               addresses still render as a clean LTR run — the Unicode bidi
               algorithm keeps contiguous latin runs correctly ordered inside
               the RTL paragraph. */
            dir={lang === "ar" ? "rtl" : "ltr"}
            className="h-11 rounded-xl border-slate-200 bg-white ps-9 pe-3 text-[13px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus:border-brand-400 focus:shadow-lg focus:shadow-brand-500/15 focus:ring-4 focus:ring-brand-500/15 dark:border-white/10 dark:bg-white/5 dark:text-slate-100 dark:placeholder:text-slate-500"
          />
        </div>
        <Button
          type="submit"
          disabled={pending}
          className="h-11 shrink-0 gap-2 rounded-xl bg-linear-to-l from-brand-600 via-brand-500 to-fuchsia-500 px-5 text-[13px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95 disabled:opacity-70"
        >
          {pending ? (
            <CatIcon name="refresh-cw" className="h-4 w-4 animate-spin" />
          ) : (
            <CatIcon name="send" className="h-4 w-4" />
          )}
          {t("newsBtn")}
        </Button>
      </div>
      <p className="mt-2 flex items-center gap-1.5 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
        <CatIcon name="shield-check" className="h-[11px] w-[11px] text-emerald-500" />
        {t("newsPrivacy")}
      </p>
    </form>
  );
}

export default NewsletterForm;

