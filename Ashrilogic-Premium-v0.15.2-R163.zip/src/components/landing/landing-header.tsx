"use client";

import { useState } from "react";
import { usePathname } from "next/navigation";
import { useTheme } from "next-themes";
import { useT } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import { useScrollSpy } from "@/hooks/use-scrollspy";
import { CatIcon } from "@/components/icon";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { openShortcutsHelp } from "@/components/landing/keyboard-shortcuts-help";
import { LangMenu } from "@/components/lang-menu";
import { PlatformBrandTile, usePlatformWordmark } from "@/components/shared/platform-brand";
import { cn } from "@/lib/utils";

/** Nav anchor links shared by desktop nav and the mobile sheet. */
interface NavLink {
  href: string;
  label: string;
  id: string;
}

function useNavLinks(): NavLink[] {
  const { t } = useT();
  return [
    { href: "/#systems", label: t("navSystems"), id: "systems" },
    { href: "/#sectors", label: t("navSectors"), id: "sectors" },
    { href: "/#features", label: t("navFeatures"), id: "features" },
    { href: "/#pricing", label: t("navPricing"), id: "pricing" },
    { href: "/compare", label: t("navCompare"), id: "compare" },
    { href: "/blog", label: t("navBlog"), id: "blog" },
    { href: "/#faq", label: t("navFaq"), id: "faq" },
  ];
}

/** Language switcher (globe + current locale label → 10-language menu). */
function LangToggle({ onToggle }: { onToggle?: () => void }) {
  return <LangMenu onPick={onToggle} />;
}

/** Theme toggle button — the icon flips via CSS (`dark:` variants) so there is
    no SSR hydration mismatch and no mounted-state; the target theme is read
    from resolvedTheme at click time (always fresh). */
function ThemeToggle({ onToggle }: { onToggle?: () => void }) {
  const { t } = useT();
  const { resolvedTheme, setTheme } = useTheme();
  return (
    <button
      type="button"
      aria-label={t("ariaTheme")}
      onClick={() => {
        setTheme(resolvedTheme === "light" ? "dark" : "light");
        onToggle?.();
      }}
      className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 bg-white text-slate-600 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:bg-white/5 dark:text-slate-300"
    >
      <CatIcon name="sun" className="hidden h-[15px] w-[15px] dark:block" />
      <CatIcon name="moon" className="block h-[15px] w-[15px] dark:hidden" />
    </button>
  );
}

export function LandingHeader() {
  const { t, lang } = useT();
  const links = useNavLinks();
  const [open, setOpen] = useState(false);
  const activeId = useScrollSpy(links.map((l) => l.id), 80);
  const wordmark = usePlatformWordmark();
  /* real-page links (/compare, /blog) highlight on their own
   * routes — the scrollspy only tracks in-page section anchors */
  const pathname = usePathname();

  // Sheet slides in from the physical side the hamburger sits on
  // (end side of the header → left in RTL, right in LTR).
  const sheetSide = lang === "ar" ? "left" : "right";

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200/70 bg-white/80 backdrop-blur-xl dark:border-white/[0.07] dark:bg-[#05080f]/75">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-2 px-4 sm:px-6 lg:px-8">
        {/* Brand */}
        <a href="/#top" className="group flex items-center gap-2.5">
          <PlatformBrandTile
            variant="main"
            className="h-10 w-10 rounded-xl shadow-brand-500/30"
            fallback={
              <span className="relative grid h-10 w-10 place-items-center rounded-xl bg-linear-to-br from-brand-500 via-fuchsia-500 to-cyan-400 text-white shadow-lg shadow-brand-500/30 transition-transform duration-300 group-hover:scale-105">
                <CatIcon name="boxes" className="h-[15px] w-[15px]" />
                <span className="absolute -bottom-0.5 -start-0.5 h-2.5 w-2.5 rounded-full bg-emerald-400 ring-2 ring-white dark:ring-[#05080f]" />
              </span>
            }
          />
          <span className="leading-none">
            <span className="block font-display text-[17px] font-extrabold tracking-tight">
              <span className="text-gradient">{wordmark}</span>
            </span>
            <span className="mt-0.5 block text-[10px] font-semibold tracking-wide text-slate-500 dark:text-slate-400">
              {t("brandTagline")}
            </span>
          </span>
        </a>

        {/* Desktop nav */}
        <nav className="hidden items-center gap-0.5 lg:flex" aria-label={t("navMenu")}>
          {links.map((link) => {
            const active = activeId === link.id || pathname === link.href;
            return (
              <a
                key={link.href}
                href={link.href}
                aria-current={active ? "true" : undefined}
                className={cn(
                  "relative rounded-lg px-3 py-2 text-[13px] font-semibold transition-colors",
                  active
                    ? "text-brand-600 dark:text-brand-300"
                    : "text-slate-600 hover:bg-slate-100 hover:text-brand-600 dark:text-slate-300 dark:hover:bg-white/5 dark:hover:text-brand-300"
                )}
              >
                {link.label}
                {active ? (
                  <span
                    className="absolute inset-x-2.5 -bottom-px h-0.5 rounded-full bg-linear-to-r from-brand-500 to-fuchsia-500"
                    aria-hidden="true"
                  />
                ) : null}
              </a>
            );
          })}
        </nav>

        {/* Controls */}
        <div className="flex items-center gap-1.5">
          <div className="hidden items-center gap-1.5 sm:flex">
            <LangToggle />
            <ThemeToggle />
            <button
              type="button"
              onClick={() => openShortcutsHelp()}
              aria-label={t("kbHelpTitle")}
              title={`${t("kbHelpTitle")} (?)`}
              className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 bg-white text-slate-600 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:bg-white/5 dark:text-slate-300"
            >
              <CatIcon name="command" className="h-[15px] w-[15px]" />
            </button>
          </div>

          {/* dedicated sign-in button — the premium /login page (round 23) */}
          <a
            href="/login"
            className="hidden items-center gap-2 rounded-xl border border-brand-300/70 bg-brand-500/10 px-4 py-2.5 text-[13px] font-extrabold text-brand-700 shadow-sm shadow-brand-500/10 transition-all duration-200 hover:border-brand-400 hover:bg-brand-500/15 hover:shadow-md hover:shadow-brand-500/20 active:scale-95 dark:border-brand-500/40 dark:bg-brand-500/10 dark:text-brand-300 dark:hover:bg-brand-500/20 sm:inline-flex"
          >
            <span className="grid h-5 w-5 place-items-center rounded-md bg-linear-to-br from-brand-500 to-fuchsia-500 text-white shadow-sm">
              <CatIcon name="log-in" className="h-[11px] w-[11px] rtl:rotate-180" />
            </span>
            <span>{t("navLogin")}</span>
          </a>

          <a
            href="/#systems"
            className="hidden items-center gap-2 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-4 py-2.5 text-[13px] font-bold text-white shadow-lg shadow-brand-500/25 transition hover:shadow-brand-500/40 hover:brightness-110 active:scale-95 sm:inline-flex"
          >
            <CatIcon name="rocket" className="h-[11px] w-[11px]" />
            <span>{t("startNow")}</span>
          </a>

          {/* Mobile menu */}
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <button
                type="button"
                aria-label={t("navMenu")}
                className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 bg-white text-slate-600 transition hover:border-brand-300 hover:text-brand-600 active:scale-95 sm:hidden dark:border-white/10 dark:bg-white/5 dark:text-slate-300"
              >
                <CatIcon name="bars" className="h-[18px] w-[18px]" />
              </button>
            </SheetTrigger>
            <SheetContent side={sheetSide} className="w-[85vw] max-w-xs p-0">
              <SheetHeader className="border-b border-slate-200/70 pb-4 dark:border-white/10">
                <SheetTitle className="flex items-center gap-2.5">
                  <PlatformBrandTile
                    variant="mini"
                    className="h-9 w-9 rounded-xl shadow-brand-500/30"
                    fallback={
                      <span className="grid h-9 w-9 place-items-center rounded-xl bg-linear-to-br from-brand-500 via-fuchsia-500 to-cyan-400 text-white shadow-lg shadow-brand-500/30">
                        <CatIcon name="boxes" className="h-[14px] w-[14px]" />
                      </span>
                    }
                  />
                  <span className="font-display text-[15px] font-extrabold">
                    <span className="text-gradient">{wordmark}</span>
                  </span>
                </SheetTitle>
                <SheetDescription className="sr-only">{t("brandTagline")}</SheetDescription>
              </SheetHeader>

              <nav className="flex flex-col gap-1 p-4" aria-label={t("navMenu")}>
                {links.map((link) => (
                  <a
                    key={link.href}
                    href={link.href}
                    onClick={() => setOpen(false)}
                    className="rounded-xl px-3.5 py-3 text-[14px] font-bold text-slate-600 transition hover:bg-slate-100 hover:text-brand-600 dark:text-slate-300 dark:hover:bg-white/5 dark:hover:text-brand-300"
                  >
                    {link.label}
                  </a>
                ))}
              </nav>

              {/* mobile: sign-in + start-now actions */}
              <div className="flex flex-col gap-2 px-4 pb-2">
                <a
                  href="/login"
                  onClick={() => setOpen(false)}
                  className="flex items-center justify-center gap-2 rounded-xl border border-brand-300/70 bg-brand-500/10 px-4 py-3 text-[13.5px] font-extrabold text-brand-700 transition active:scale-95 dark:border-brand-500/40 dark:text-brand-300"
                >
                  <CatIcon name="log-in" className="h-[14px] w-[14px] rtl:rotate-180" />
                  {t("navLogin")}
                </a>
                <a
                  href="/#systems"
                  onClick={() => setOpen(false)}
                  className="flex items-center justify-center gap-2 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-4 py-3 text-[13.5px] font-bold text-white shadow-lg shadow-brand-500/25 transition active:scale-95"
                >
                  <CatIcon name="rocket" className="h-[13px] w-[13px]" />
                  {t("startNow")}
                </a>
              </div>

              <div className="mt-auto flex items-center gap-2 border-t border-slate-200/70 p-4 dark:border-white/10">
                <LangToggle onToggle={() => setOpen(false)} />
                <ThemeToggle />
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}

export default LandingHeader;
