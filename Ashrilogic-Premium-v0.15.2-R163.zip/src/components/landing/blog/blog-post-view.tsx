"use client";

/**
 * Ashrilogic — /blog/[slug]: the article reader.
 *
 * Fetches GET /api/blog/[slug] (published only; the read itself increments
 * the view counter server-side). Renders the body through the SAFE markdown
 * renderer (src/lib/markdown.ts — HTML-escaped first, allow-listed tags out;
 * no raw HTML ever passes through). The reading direction follows the
 * post's locale: Arabic bodies render RTL, English bodies LTR, regardless
 * of the interface language. Share row + related posts + newsletter CTA.
 */
import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { useT, type I18nKey } from "@/lib/i18n";
import { fetchBlogPost } from "@/lib/api-client";
import { renderMarkdown } from "@/lib/markdown";
import { CatIcon } from "@/components/icon";
import { Reveal } from "@/components/landing/reveal";
import { LandingHeader } from "@/components/landing/landing-header";
import { LandingFooter } from "@/components/landing/landing-footer";
import { ScrollProgress } from "@/components/landing/scroll-progress";
import { BackToTop } from "@/components/landing/back-to-top";
import { NewsletterForm } from "@/components/landing/newsletter-form";
import { useDocumentTitle } from "@/hooks/use-document-title";
import { cn, fmtNum, grad } from "@/lib/utils";

/** Deterministic gradient palettes for the article hero (no uploaded cover). */
const HERO_PALETTES: [string, string, string][] = [
  ["#6d5dfb", "#d946ef", "sparkles"],
  ["#06b6d4", "#0ea5e9", "compass"],
  ["#f59e0b", "#f97316", "banknote"],
  ["#10b981", "#059669", "shield-check"],
  ["#ec4899", "#db2777", "heart-pulse"],
  ["#8b5cf6", "#7c3aed", "graduation-cap"],
];

function heroPalette(key: string): [string, string, string] {
  let hash = 0;
  for (let i = 0; i < key.length; i++) hash = (hash * 31 + key.charCodeAt(i)) >>> 0;
  return HERO_PALETTES[hash % HERO_PALETTES.length];
}

function fmtDate(iso: string | null, lang: string): string {
  if (!iso) return "";
  try {
    return new Intl.DateTimeFormat(lang === "ar" ? "ar" : lang === "hi" ? "hi" : "en", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }).format(new Date(iso));
  } catch {
    return iso.slice(0, 10);
  }
}

/* ------------------------------------------------ share row ---------- */

function ShareRow({ url, title }: { url: string; title: string }) {
  const { t } = useT();

  const links: { icon: string; label: string; href: string; c1: string; c2: string }[] = [
    {
      icon: "twitter",
      label: "X",
      href: `https://twitter.com/intent/tweet?text=${encodeURIComponent(title)}&url=${encodeURIComponent(url)}`,
      c1: "#0f172a",
      c2: "#334155",
    },
    {
      icon: "whatsapp",
      label: "WhatsApp",
      href: `https://wa.me/?text=${encodeURIComponent(`${title} ${url}`)}`,
      c1: "#10b981",
      c2: "#059669",
    },
    {
      icon: "linkedin",
      label: "LinkedIn",
      href: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`,
      c1: "#0a66c2",
      c2: "#084d8d",
    },
  ];

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      toast.success(t("blogCopied"));
    } catch {
      toast.error(t("blogCopyLink"));
    }
  };

  return (
    <div className="flex flex-wrap items-center gap-2">
      <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
        {t("blogShare")}
      </span>
      {links.map((link) => (
        <a
          key={link.label}
          href={link.href}
          target="_blank"
          rel="noopener noreferrer"
          aria-label={`${link.label}`}
          title={link.label}
          className="grid h-9 w-9 place-items-center rounded-xl text-white shadow-md transition-all duration-200 hover:-translate-y-0.5 hover:brightness-110 active:scale-95"
          style={{ backgroundImage: grad(link.c1, link.c2) }}
        >
          <CatIcon name={link.icon} className="h-[13px] w-[13px]" />
        </a>
      ))}
      <button
        type="button"
        onClick={copy}
        aria-label={t("blogCopyLink")}
        title={t("blogCopyLink")}
        className="grid h-9 w-9 cursor-pointer place-items-center rounded-xl border border-slate-200 bg-white text-slate-500 shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
      >
        <CatIcon name="copy" className="h-[13px] w-[13px]" />
      </button>
    </div>
  );
}

/* ------------------------------------------------ article view ------- */

export function BlogPostView({ slug }: { slug: string }) {
  const { t, lang } = useT();
  useDocumentTitle("docTitleBlogPost");

  const postQuery = useQuery({
    queryKey: ["public-blog-post", slug],
    queryFn: () => fetchBlogPost(slug),
    retry: 1,
  });

  const post = postQuery.data;
  const error = postQuery.error;

  /* the body renders in ITS OWN locale direction: the Arabic body is always
   * RTL and the English body always LTR — independent of the UI language */
  const bodyLang: "ar" | "en" = lang === "en" && post && post.contentEn.trim().length > 0 ? "en" : "ar";
  const body = post ? (bodyLang === "ar" ? post.contentAr : post.contentEn) : "";
  const bodyHtml = useMemo(() => renderMarkdown(body), [body]);

  if (postQuery.isLoading) {
    return (
      <div className="relative flex min-h-screen flex-col">
        <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden="true" />
        <LandingHeader />
        <main className="mx-auto w-full max-w-3xl flex-1 px-4 py-16 sm:px-6">
          <div className="h-72 animate-pulse rounded-3xl" aria-hidden="true" />
          <div className="mt-8 h-8 w-3/4 animate-pulse rounded-xl" aria-hidden="true" />
          <div className="mt-4 h-4 w-full animate-pulse rounded-lg" aria-hidden="true" />
          <div className="mt-3 h-4 w-5/6 animate-pulse rounded-lg" aria-hidden="true" />
          <div className="mt-3 h-4 w-4/6 animate-pulse rounded-lg" aria-hidden="true" />
        </main>
        <LandingFooter />
      </div>
    );
  }

  if (error || !post) {
    return (
      <div className="relative flex min-h-screen flex-col">
        <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden="true" />
        <LandingHeader />
        <main className="mx-auto flex w-full max-w-3xl flex-1 flex-col items-center justify-center px-4 py-24 text-center sm:px-6">
          <div className="grid h-20 w-20 place-items-center rounded-3xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
            <CatIcon name="circle-x" className="h-8 w-8" />
          </div>
          <h1 className="mt-5 font-display text-2xl font-extrabold">{t("sysDetailNotFound")}</h1>
          <p className="mt-2 max-w-sm text-[13px] text-slate-500 dark:text-slate-400">
            {t("sysDetailNotFoundDesc")}
          </p>
          <a
            href="/blog"
            className="mt-6 inline-flex items-center gap-2 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-5 py-3 text-[13px] font-bold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95"
          >
            <CatIcon name="arrow-right" className="h-[11px] w-[11px] rtl:rotate-180" />
            {t("blogBack")}
          </a>
        </main>
        <LandingFooter />
      </div>
    );
  }

  const title = lang === "ar" || !post.titleEn ? post.titleAr : post.titleEn;
  const excerpt = lang === "ar" || !post.excerptEn ? post.excerptAr : post.excerptEn;
  const [c1, c2, icon] = heroPalette(post.id);
  const shareUrl = typeof window !== "undefined" ? window.location.href : `https://ashrilogic.com/blog/${post.slug}`;

  return (
    <div className="relative flex min-h-screen flex-col">
      <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden="true" />
      <LandingHeader />
      <ScrollProgress />
      <BackToTop />

      <main className="flex-1 px-4 py-10 sm:px-6 lg:px-8 lg:py-14">
        <article className="mx-auto max-w-3xl">
          {/* breadcrumb */}
          <Reveal>
            <nav aria-label="breadcrumb" className="flex items-center gap-2 text-[12px] font-bold text-slate-400 dark:text-slate-500">
              <a href="/" className="transition hover:text-brand-600 dark:hover:text-brand-300">
                Ashrilogic
              </a>
              <CatIcon name="arrow-right" className="h-[9px] w-[9px] rtl:rotate-180" aria-hidden="true" />
              <a href="/blog" className="transition hover:text-brand-600 dark:hover:text-brand-300">
                {t("navBlog")}
              </a>
              <CatIcon name="arrow-right" className="h-[9px] w-[9px] rtl:rotate-180" aria-hidden="true" />
              <span className="truncate text-slate-600 dark:text-slate-300">{title}</span>
            </nav>
          </Reveal>

          {/* hero */}
          <Reveal delay={0.05}>
            <header className="mt-6">
              {post.tags.length > 0 ? (
                <div className="flex flex-wrap gap-1.5">
                  {post.tags.map((tg) => (
                    <a
                      key={tg}
                      href={`/blog?tag=${encodeURIComponent(tg)}`}
                      className="rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-[10.5px] font-bold text-slate-500 transition hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-400 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
                    >
                      #{tg}
                    </a>
                  ))}
                </div>
              ) : null}

              <h1 className="mt-4 font-display text-[26px] font-extrabold leading-tight tracking-tight text-slate-900 dark:text-white sm:text-4xl">
                {title}
              </h1>
              <p className="mt-4 text-[14px] leading-relaxed text-slate-500 dark:text-slate-400 sm:text-[15px]">
                {excerpt}
              </p>

              {/* meta row */}
              <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-y border-slate-200/70 py-4 dark:border-white/10">
                <div className="flex items-center gap-3">
                  <span
                    className="grid h-10 w-10 place-items-center rounded-2xl text-sm font-extrabold text-white shadow-lg"
                    style={{ backgroundImage: grad(c1, c2) }}
                    aria-hidden="true"
                  >
                    {(post.authorName || "A").trim().charAt(0).toUpperCase()}
                  </span>
                  <div className="leading-tight">
                    <p className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                      {t("blogBy")} {post.authorName}
                    </p>
                    <p className="mt-0.5 flex items-center gap-1.5 text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                      <CatIcon name="calendar" className="h-[10px] w-[10px]" />
                      {fmtDate(post.publishedAt, lang)}
                      <span className="mx-0.5">·</span>
                      <CatIcon name="clock" className="h-[10px] w-[10px]" />
                      {fmtNum(post.readMinutes, lang)} {t("blogMinRead")}
                      <span className="mx-0.5">·</span>
                      <CatIcon name="eye" className="h-[10px] w-[10px]" />
                      {fmtNum(post.views, lang)} {t("blogViews")}
                    </p>
                  </div>
                </div>
                <ShareRow url={shareUrl} title={title} />
              </div>
            </header>
          </Reveal>

          {/* cover */}
          <Reveal delay={0.08}>
            <div className="relative mt-8 h-56 overflow-hidden rounded-3xl shadow-lift sm:h-72 lg:h-80">
              {post.coverImage ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={post.coverImage}
                  alt={title}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="relative h-full w-full" style={{ backgroundImage: grad(c1, c2, 135) }}>
                  <span className="pointer-events-none absolute inset-0 opacity-25" style={{ backgroundImage: "radial-gradient(520px circle at 30% 20%, rgba(255,255,255,0.9), transparent 60%)" }} aria-hidden="true" />
                  <span className="absolute bottom-5 end-5 grid h-14 w-14 place-items-center rounded-3xl bg-white/25 text-white backdrop-blur-sm" aria-hidden="true">
                    <CatIcon name={icon} className="h-6 w-6" />
                  </span>
                </div>
              )}
            </div>
          </Reveal>

          {/* body — rendered in the body's own locale direction */}
          <Reveal delay={0.1}>
            <div
              dir={bodyLang === "ar" ? "rtl" : "ltr"}
              lang={bodyLang}
              className={cn(
                "blog-prose mt-10",
                /* typography: a scoped allow-list of element styles (the
                   renderer only ever emits h2/h3/p/strong/code/a/ul/ol/li/
                   blockquote/hr — see src/lib/markdown.ts) */
                "text-[14.5px] leading-[1.9] text-slate-600 dark:text-slate-300",
                "[&_h2]:mt-10 [&_h2]:mb-4 [&_h2]:font-display [&_h2]:text-[20px] [&_h2]:font-extrabold [&_h2]:leading-snug [&_h2]:text-slate-900 dark:[&_h2]:text-white sm:[&_h2]:text-[22px]",
                "[&_h3]:mt-8 [&_h3]:mb-3 [&_h3]:font-display [&_h3]:text-[16.5px] [&_h3]:font-extrabold [&_h3]:text-slate-800 dark:[&_h3]:text-slate-100",
                "[&_h2]:before:bg-linear-to-r [&_h2]:before:from-brand-500 [&_h2]:before:to-fuchsia-500",
                "[&_p]:mt-4 [&_p]:mb-4",
                "[&_strong]:font-extrabold [&_strong]:text-slate-800 dark:[&_strong]:text-slate-100",
                "[&_code]:rounded-md [&_code]:bg-slate-100 [&_code]:px-1.5 [&_code]:py-0.5 [&_code]:font-mono [&_code]:text-[12.5px] [&_code]:text-brand-600 dark:[&_code]:bg-white/10 dark:[&_code]:text-brand-300",
                "[&_a]:font-bold [&_a]:text-brand-600 [&_a]:underline [&_a]:underline-offset-2 [&_a]:transition dark:[&_a]:text-brand-300 dark:[&_a]:hover:brightness-125",
                "[&_ul]:mt-4 [&_ul]:mb-4 [&_ul]:space-y-2 [&_ul]:ps-1",
                "[&_ol]:mt-4 [&_ol]:mb-4 [&_ol]:space-y-2 [&_ol]:list-decimal [&_ol]:ps-6",
                "[&_ul]:list-none",
                "[&_ul>li]:relative [&_ul>li]:ps-6",
                "[&_ul>li]:before:absolute [&_ul>li]:before:start-0 [&_ul>li]:before:top-[0.7em] [&_ul>li]:before:h-1.5 [&_ul>li]:before:w-1.5 [&_ul>li]:before:rounded-full [&_ul>li]:before:bg-brand-500",
                "[&_ol>li]:marker:font-bold [&_ol>li]:marker:text-brand-500",
                "[&_blockquote]:mt-6 [&_blockquote]:mb-6 [&_blockquote]:rounded-2xl [&_blockquote]:border-s-4 [&_blockquote]:border-brand-400 [&_blockquote]:bg-brand-500/[0.06] [&_blockquote]:p-4 [&_blockquote]:text-[13.5px] [&_blockquote]:font-semibold [&_blockquote]:leading-relaxed [&_blockquote]:text-slate-700 dark:[&_blockquote]:border-brand-500 dark:[&_blockquote]:bg-brand-500/10 dark:[&_blockquote]:text-slate-200",
                "[&_hr]:my-10 [&_hr]:h-px [&_hr]:border-0 [&_hr]:bg-linear-to-r [&_hr]:from-transparent [&_hr]:via-slate-300 [&_hr]:to-transparent dark:[&_hr]:via-white/20"
              )}
              dangerouslySetInnerHTML={{ __html: bodyHtml }}
            />
          </Reveal>

          {/* closing share + divider */}
          <Reveal delay={0.12}>
            <div className="mt-12 flex flex-wrap items-center justify-between gap-4 border-t border-slate-200/70 pt-6 dark:border-white/10">
              <a
                href="/blog"
                className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-[12.5px] font-extrabold text-slate-600 shadow-sm transition hover:border-brand-300 hover:text-brand-600 active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
              >
                <CatIcon name="arrow-right" className="h-[11px] w-[11px] rtl:rotate-180" />
                {t("blogBack")}
              </a>
              <ShareRow url={shareUrl} title={title} />
            </div>
          </Reveal>

          {/* related posts */}
          {post.related.length > 0 ? (
            <section className="mt-14" aria-label={t("blogRelated")}>
              <h2 className="flex items-center gap-2.5 font-display text-xl font-extrabold text-slate-900 dark:text-white">
                <span className="grid h-8 w-8 place-items-center rounded-xl bg-linear-to-br from-brand-500 to-fuchsia-500 text-white shadow-md" aria-hidden="true">
                  <CatIcon name="link" className="h-[12px] w-[12px]" />
                </span>
                {t("blogRelated")}
              </h2>
              <div className="mt-6 grid gap-5 sm:grid-cols-3">
                {post.related.map((rel, i) => {
                  const relTitle = lang === "ar" || !rel.titleEn ? rel.titleAr : rel.titleEn;
                  const [rc1, rc2, ricon] = heroPalette(rel.id);
                  return (
                    <Reveal key={rel.id} delay={i * 0.06} className="h-full">
                      <a
                        href={`/blog/${rel.slug}`}
                        className="glass-card group flex h-full flex-col overflow-hidden rounded-3xl transition-all duration-300 hover:-translate-y-1.5 hover:shadow-lift"
                      >
                        <div className="relative h-28 overflow-hidden">
                          {rel.coverImage ? (
                            // eslint-disable-next-line @next/next/no-img-element
                            <img src={rel.coverImage} alt={relTitle} loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                          ) : (
                            <div className="relative h-full w-full" style={{ backgroundImage: grad(rc1, rc2, 135) }}>
                              <span className="absolute bottom-2.5 end-2.5 grid h-8 w-8 place-items-center rounded-xl bg-white/25 text-white backdrop-blur-sm" aria-hidden="true">
                                <CatIcon name={ricon} className="h-[12px] w-[12px]" />
                              </span>
                            </div>
                          )}
                        </div>
                        <div className="flex flex-1 flex-col p-4">
                          <h3 className="font-display text-[13.5px] font-extrabold leading-snug text-slate-900 transition-colors group-hover:text-brand-600 dark:text-white dark:group-hover:text-brand-300">
                            {relTitle}
                          </h3>
                          <span className="mt-auto flex items-center gap-1.5 pt-3 text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                            <CatIcon name="clock" className="h-[10px] w-[10px]" />
                            {fmtNum(rel.readMinutes, lang)} {t("blogMinRead")}
                          </span>
                        </div>
                      </a>
                    </Reveal>
                  );
                })}
              </div>
            </section>
          ) : null}

          {/* newsletter CTA */}
          <Reveal delay={0.1}>
            <section className="mt-14">
              <div className="grid items-center gap-5 rounded-3xl border border-slate-200/70 bg-linear-to-r from-brand-600/5 via-fuchsia-500/5 to-cyan-400/5 p-5 sm:grid-cols-2 sm:p-6 dark:border-white/10">
                <div>
                  <h4 className="flex items-center gap-2 font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                    <span className="grid h-7 w-7 place-items-center rounded-lg bg-linear-to-br from-brand-500 to-fuchsia-500 text-white">
                      <CatIcon name="send" className="h-[12px] w-[12px]" />
                    </span>
                    {t("blogCtaTitle")}
                  </h4>
                  <p className="mt-1.5 text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
                    {t("blogCtaDesc")}
                  </p>
                </div>
                <NewsletterForm />
              </div>
            </section>
          </Reveal>
        </article>
      </main>

      <LandingFooter />
    </div>
  );
}

export default BlogPostView;
