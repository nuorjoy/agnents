"use client";

/**
 * Ashrilogic — pricing section (live, DB-backed).
 *
 * Plans come from GET /api/packages (admin-managed, ACTIVE only). Each card
 * keeps the premium design language of the original static section: glass
 * card, category gradient icon, hover glow, popular gradient ring + badge,
 * check bullets and a gradient CTA. Bilingual display follows the app
 * language (Arabic name/features by default, English when available). If the
 * API fails or returns no plans, the section falls back to the original
 * static tiers so pricing never breaks.
 */
import { useState } from "react";
import type { CSSProperties } from "react";
import { useQuery } from "@tanstack/react-query";
import { useT } from "@/lib/i18n";
import { fetchPublicPackages } from "@/lib/api-client";
import { cycleDiscountPct, discountedPrice, effectiveYearlyPct } from "@/lib/plan-features";
import { CatIcon } from "@/components/icon";
import { Reveal } from "@/components/landing/reveal";
import { cn, fmtNum, grad, hexAlpha } from "@/lib/utils";

type Cycle = "monthly" | "yearly";

/** Static fallback tiers (previous hard-coded pricing) — used only when the
 *  live packages request fails or yields an empty list. */
const PLANS = [
  {
    id: "starter",
    nameKey: "priceStarter",
    descKey: "priceStarterDesc",
    icon: "rocket",
    c1: "#06b6d4",
    c2: "#0891b2",
    monthly: 199,
    ctaKey: "priceCta",
    popular: false,
    features: ["priceFeat1Starter", "priceFeat2", "priceFeat3", "priceFeat4"],
  },
  {
    id: "pro",
    nameKey: "pricePro",
    descKey: "priceProDesc",
    icon: "sparkles",
    c1: "#6d5dfb",
    c2: "#d946ef",
    monthly: 499,
    ctaKey: "priceCta",
    popular: true,
    features: ["priceFeat1Pro", "priceFeat2", "priceFeat3", "priceFeat4Pro", "priceFeat5Pro", "priceFeat6Pro"],
  },
  {
    id: "enterprise",
    nameKey: "priceEnterprise",
    descKey: "priceEnterpriseDesc",
    icon: "building",
    c1: "#f59e0b",
    c2: "#ea580c",
    monthly: 1299,
    ctaKey: "priceCtaContact",
    popular: false,
    features: ["priceFeat1Ent", "priceFeat2", "priceFeat3", "priceFeat4Ent", "priceFeat5Ent", "priceFeat6Ent"],
  },
] as const;

/** Icon + gradient palette cycled by plan index so rows of 3–4 stay varied. */
const PLAN_STYLES = [
  { icon: "rocket", c1: "#06b6d4", c2: "#0891b2" },
  { icon: "sparkles", c1: "#6d5dfb", c2: "#d946ef" },
  { icon: "building", c1: "#f59e0b", c2: "#ea580c" },
  { icon: "gem", c1: "#10b981", c2: "#059669" },
] as const;

/** One renderable plan card — resolved for language + billing cycle. */
interface PlanCardVM {
  key: string;
  name: string;
  desc: string;
  /** ROUND 79 — the EFFECTIVE (discounted) price for the selected cycle */
  price: number;
  /** ROUND 79 — the crossed-out list price (present only when discounted) */
  basePrice?: number;
  /** ROUND 79 — live discount percentage (0 = none) */
  discountPct?: number;
  currencyLabel: string;
  features: string[];
  /** total feature count (may exceed the visible slice) */
  featureCount: number;
  /** ROUND 67 — explicit custom-domain gating on the card itself: the
   *  BASIC tier (first plan) cannot attach a professional domain to the
   *  store or the public site; every higher tier includes it. */
  domainIncluded: boolean;
  icon: string;
  c1: string;
  c2: string;
  popular: boolean;
  /** CTA copy + scroll target (primary id, then a graceful fallback id). */
  ctaKey: "priceCta" | "priceCtaContact";
  ctaTarget: string;
  ctaFallback?: string;
}

function Check({ c1 }: { c1: string }) {
  return (
    <span
      className="grid h-4.5 w-4.5 shrink-0 place-items-center rounded-full text-white"
      style={{ backgroundColor: c1, width: 18, height: 18 }}
      aria-hidden="true"
    >
      <CatIcon name="check" className="h-[10px] w-[10px]" />
    </span>
  );
}

/** Shared premium card — used for live DB plans and the static fallback alike. */
function PlanCard({ plan, delay, perMonthLabel, popularLabel }: {
  plan: PlanCardVM;
  delay: number;
  perMonthLabel: string;
  popularLabel: string;
}) {
  const { t, lang } = useT();

  return (
    <Reveal delay={delay}>
      <div
        className={cn(
          "group relative flex h-full flex-col overflow-hidden rounded-3xl border p-6 transition-all duration-300 hover:-translate-y-1.5",
          plan.popular
            ? "border-transparent bg-white shadow-xl shadow-brand-500/10 dark:bg-white/[0.05] hover:shadow-2xl hover:shadow-brand-500/20"
            : "border-slate-200/80 bg-white/70 backdrop-blur-sm hover:shadow-lg hover:border-brand-300/60 dark:border-white/10 dark:bg-white/[0.03] dark:hover:border-brand-500/30"
        )}
        style={
          plan.popular
            ? { boxShadow: "0 0 0 2px transparent, 0 20px 50px -20px rgba(109,93,251,0.4)" }
            : undefined
        }
      >
        {/* hover glow accent */}
        <div
          className="pointer-events-none absolute inset-0 -z-10 opacity-0 transition-opacity duration-300 group-hover:opacity-100"
          style={{
            background: `radial-gradient(400px circle at 50% 0%, ${hexAlpha(plan.c1, 0.08)}, transparent 70%)`,
          }}
          aria-hidden="true"
        />
        {/* gradient ring for popular plan */}
        {plan.popular ? (
          <span
            className="pointer-events-none absolute inset-0 rounded-3xl p-[2px]"
            style={{ background: grad(plan.c1, plan.c2), WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", maskComposite: "exclude" } as CSSProperties}
            aria-hidden="true"
          />
        ) : null}

        {/* popular badge */}
        {plan.popular ? (
          <span
            className="absolute end-5 top-5 inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-extrabold text-white shadow-md"
            style={{ backgroundImage: grad(plan.c1, plan.c2) }}
          >
            <CatIcon name="star" className="h-[9px] w-[9px] fill-white" />
            {popularLabel}
          </span>
        ) : null}

        {/* plan header */}
        <div className="relative">
          <span
            className="grid h-12 w-12 place-items-center rounded-2xl text-white shadow-lg transition-transform duration-300 group-hover:scale-110"
            style={{ backgroundImage: grad(plan.c1, plan.c2) }}
            aria-hidden="true"
          >
            <CatIcon name={plan.icon} className="h-[17px] w-[17px]" />
          </span>
          <h3 className="mt-4 font-display text-[18px] font-extrabold text-slate-900 dark:text-white">
            {plan.name}
          </h3>
          <p className="mt-1 text-[12px] text-slate-500 dark:text-slate-400">
            {plan.desc}
          </p>
        </div>

        {/* price — ROUND 79: crossed-out list price → live discounted price
            (the same discountedPrice() the server uses for order amounts) +
            an emerald «وفّر {pct}٪» chip next to the figure */}
        <div className="relative mt-5 flex flex-wrap items-end gap-x-1.5 gap-y-1">
          {plan.basePrice !== undefined && plan.discountPct ? (
            <span
              dir="ltr"
              className="mb-1.5 self-center text-[13px] font-bold tabular-nums text-slate-400 line-through decoration-rose-400/80 decoration-2 dark:text-slate-500"
            >
              <span className="sr-only">{t("priceInsteadOf")} </span>
              {plan.basePrice.toLocaleString("en-US")}
            </span>
          ) : null}
          <span className="font-display text-4xl font-extrabold text-slate-900 dark:text-white">
            {plan.price.toLocaleString("en-US")}
          </span>
          <span className="mb-1 text-[13px] font-bold text-slate-500 dark:text-slate-400">
            {plan.currencyLabel}
          </span>
          <span className="mb-1 text-[11px] font-semibold text-slate-400 dark:text-slate-500">
            {perMonthLabel}
          </span>
          {plan.discountPct ? (
            <span className="mb-1 inline-flex shrink-0 items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10.5px] font-extrabold text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400">
              <CatIcon name="percent" className="h-[10px] w-[10px]" />
              {t("priceSavePct", { n: fmtNum(plan.discountPct, lang), pct: fmtNum(plan.discountPct, lang) })}
            </span>
          ) : null}
        </div>

        {/* features */}
        <ul className="relative mt-5 flex-1 space-y-2.5">
          {plan.features.map((feature, i) => (
            <li key={`${plan.key}-${i}`} className="flex items-start gap-2.5 text-[12.5px] font-semibold text-slate-600 dark:text-slate-300">
              <Check c1={plan.c1} />
              <span>{feature}</span>
            </li>
          ))}
          {plan.featureCount > plan.features.length ? (
            <li className="pt-0.5">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-2.5 py-1 text-[11px] font-extrabold text-slate-500 dark:bg-white/10 dark:text-slate-400">
                <CatIcon name="sparkles" className="h-[11px] w-[11px]" style={{ color: plan.c1 }} />
                +{fmtNum(plan.featureCount - plan.features.length, lang)}
                <span>{t("priceMoreFeatures")}</span>
              </span>
            </li>
          ) : null}
        </ul>

        {/* ROUND 67 — explicit custom-domain gating line: the basic tier is
            honestly marked as NOT carrying the professional domain for the
            store + public website; higher tiers show it as a highlighted
            inclusion (mirrors the compare matrix row). */}
        <div className="relative mt-4 flex items-center gap-2.5 border-t border-dashed border-slate-200 pt-3.5 dark:border-white/10">
          {plan.domainIncluded ? (
            <span className="grid h-[18px] w-[18px] shrink-0 place-items-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400" aria-hidden="true">
              <CatIcon name="check" className="h-[10px] w-[10px]" />
            </span>
          ) : (
            <span className="grid h-[18px] w-[18px] shrink-0 place-items-center rounded-full bg-slate-100 text-slate-400 dark:bg-white/10 dark:text-slate-500" aria-hidden="true">
              <CatIcon name="x" className="h-[10px] w-[10px]" />
            </span>
          )}
          <span
            className={cn(
              "text-[11.5px] font-bold leading-snug",
              plan.domainIncluded
                ? "text-emerald-600 dark:text-emerald-400"
                : "text-slate-400 dark:text-slate-500"
            )}
          >
            {t(plan.domainIncluded ? "priceDomainYes" : "priceDomainNo")}
          </span>
        </div>

        {/* CTA */}
        <button
          type="button"
          onClick={() => {
            const el =
              document.getElementById(plan.ctaTarget) ??
              (plan.ctaFallback ? document.getElementById(plan.ctaFallback) : null);
            el?.scrollIntoView({ behavior: "smooth", block: "start" });
          }}
          className={cn(
            "relative mt-6 inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl text-[13px] font-extrabold transition-all duration-200 hover:-translate-y-0.5 active:scale-95",
            plan.popular
              ? "text-white shadow-lg shadow-brand-500/25 hover:brightness-110 hover:shadow-xl hover:shadow-brand-500/40"
              : "border border-slate-200 bg-white text-slate-700 hover:border-brand-300 hover:text-brand-600 hover:shadow-md dark:border-white/10 dark:bg-white/5 dark:text-slate-200 dark:hover:border-brand-500/40"
          )}
          style={plan.popular ? { backgroundImage: grad(plan.c1, plan.c2) } : undefined}
        >
          {t(plan.ctaKey)}
          <CatIcon name="arrow-left" className="h-3.5 w-3.5 rtl:rotate-180" />
        </button>
      </div>
    </Reveal>
  );
}

/** Loading placeholder — mirrors the card layout with pulse blocks. */
function SkeletonCard({ delay }: { delay: number }) {
  const bar = "rounded-full bg-slate-200 dark:bg-white/10";
  return (
    <Reveal delay={delay}>
      <div
        className="flex h-full flex-col rounded-3xl border border-slate-200/80 bg-white/70 p-6 backdrop-blur-sm dark:border-white/10 dark:bg-white/[0.03]"
        aria-hidden="true"
      >
        <div className="animate-pulse">
          <div className="h-12 w-12 rounded-2xl bg-slate-200 dark:bg-white/10" />
          <div className={cn("mt-4 h-4 w-24", bar)} />
          <div className={cn("mt-2 h-2.5 w-40", bar)} />
          <div className="mt-5 h-9 w-28 rounded-lg bg-slate-200 dark:bg-white/10" />
          <div className="mt-6 space-y-2.5">
            {[88, 76, 84, 64].map((w, i) => (
              <div key={i} className={cn("h-2.5", bar)} style={{ width: `${w}%` }} />
            ))}
          </div>
          <div className="mt-6 h-11 w-full rounded-xl bg-slate-200 dark:bg-white/10" />
        </div>
      </div>
    </Reveal>
  );
}

export function PricingSection() {
  const { t, lang } = useT();
  const [cycle, setCycle] = useState<Cycle>("monthly");

  const query = useQuery({
    queryKey: ["public-packages"],
    queryFn: fetchPublicPackages,
    staleTime: 60_000,
  });

  const dbPlans = query.data && query.data.length > 0 ? query.data : null;
  const pending = query.isPending;

  /** ROUND 65 → ROUND 79 → ROUND 80 — live yearly saving: the BEST saving
   *  across all plans, computed from the EFFECTIVE prices with each cycle's
   *  OWN promotion (monthly pct for monthly; the dedicated annual pct for
   *  yearly — 0 inherits the monthly promotion). Heterogeneous discounts
   *  advertise the strongest true saving, never a stale first-row number,
   *  and never a hard-coded percentage. */
  let savePct: number | null = null;
  if (dbPlans) {
    for (const pkg of dbPlans) {
      const monthlyPct = pkg.discountPct ?? 0;
      const yearlyPct = effectiveYearlyPct(pkg);
      const effMonthly = discountedPrice(pkg.priceMonthly, monthlyPct);
      const effYearly = discountedPrice(pkg.priceYearly, yearlyPct);
      if (effMonthly > 0 && effYearly > 0 && effYearly < effMonthly * 12) {
        const planSaving = Math.round((1 - effYearly / (effMonthly * 12)) * 100);
        if (savePct === null || planSaving > savePct) savePct = planSaving;
      }
    }
  }

  /* ---------------- card view models ---------------- */

  const liveCards: PlanCardVM[] = dbPlans
    ? dbPlans.map((pkg, i) => {
        const style = PLAN_STYLES[i % PLAN_STYLES.length];
        const isLast = i === dbPlans.length - 1;
        /* ROUND 79 → ROUND 80 — the card price is the LIVE effective price
           under the SELECTED CYCLE's own promotion (monthly pct or the
           dedicated annual pct — the same cycleDiscountPct law the server
           stamps on order amounts); the crossed-out list price rides along
           when that cycle's promotion is live. */
        const pct = cycleDiscountPct(pkg, cycle);
        const base = cycle === "monthly" ? pkg.priceMonthly : pkg.priceYearly;
        const effective = discountedPrice(base, pct);
        return {
          key: `pkg-${pkg.id}`,
          name: lang === "ar" ? pkg.nameAr : pkg.nameEn,
          desc: lang === "ar" ? pkg.descAr : pkg.descEn,
          price: effective,
          basePrice: pct > 0 ? base : undefined,
          discountPct: pct > 0 ? pct : undefined,
          currencyLabel: pkg.currency,
          features: (lang === "ar" ? pkg.features : pkg.featuresEn.length > 0 ? pkg.featuresEn : pkg.features).slice(0, 6),
          featureCount: (lang === "ar" ? pkg.features : pkg.featuresEn.length > 0 ? pkg.featuresEn : pkg.features).length,
          /* ROUND 67 — the first (basic) tier is the only one WITHOUT the
             custom professional domain for the store + public website */
          domainIncluded: i > 0,
          icon: style.icon,
          c1: style.c1,
          c2: style.c2,
          popular: pkg.popular,
          ctaKey: isLast ? "priceCtaContact" : "priceCta",
          ctaTarget: isLast ? "support" : "systems",
          ctaFallback: isLast ? "cta" : undefined,
        };
      })
    : [];

  const staticCards: PlanCardVM[] = PLANS.map((plan) => ({
    key: `static-${plan.id}`,
    name: t(plan.nameKey),
    desc: t(plan.descKey),
    price: cycle === "yearly" ? Math.round(plan.monthly * 0.8) : plan.monthly,
    currencyLabel: t("priceCurrency"),
    features: plan.features.map((fk) => t(fk as "priceFeat1Starter")),
    featureCount: plan.features.length,
    domainIncluded: plan.id !== "starter",
    icon: plan.icon,
    c1: plan.c1,
    c2: plan.c2,
    popular: plan.popular ?? false,
    ctaKey: plan.ctaKey,
    ctaTarget: plan.id === "enterprise" ? "download" : "systems",
  }));

  const cards = dbPlans ? liveCards : staticCards;

  return (
    <section id="pricing" className="scroll-mt-20 px-4 py-16 sm:px-6 lg:px-8 lg:py-20">
      <div className="mx-auto max-w-7xl">
        {/* heading */}
        <div className="mx-auto max-w-3xl text-center">
          <Reveal>
            <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3.5 py-1.5 text-[11px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
              <CatIcon name="tag" className="h-[11px] w-[11px] text-brand-500" />
              <span>{t("priceBadge")}</span>
            </span>
            <h2 className="mt-5 font-display text-[28px] font-extrabold leading-tight tracking-tight sm:text-4xl">
              <span>{t("priceTitle1")} </span>
              <span className="text-gradient">{t("priceTitle2")}</span>
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-[14px] leading-relaxed text-slate-600 dark:text-slate-400 sm:text-[15px]">
              {t("priceDesc")}
            </p>
            {/* ROUND CONTENT — the full comparison matrix now lives on /compare */}
            <a
              href="/compare"
              className="group mt-5 inline-flex items-center gap-2 rounded-full border border-brand-200 bg-brand-500/[0.07] px-4 py-2 text-[12px] font-extrabold text-brand-700 transition-all duration-200 hover:border-brand-300 hover:bg-brand-500/15 hover:shadow-md hover:shadow-brand-500/20 active:scale-95 dark:border-brand-500/30 dark:bg-brand-500/10 dark:text-brand-300 dark:hover:bg-brand-500/20"
            >
              <CatIcon name="scale" className="h-[12px] w-[12px] transition-transform duration-200 group-hover:scale-110" />
              <span>{t("cmpBadge")}</span>
              <CatIcon name="arrow-right" className="h-[11px] w-[11px] transition-transform duration-200 group-hover:translate-x-0.5 rtl:rotate-180 rtl:group-hover:-translate-x-0.5" aria-hidden="true" />
            </a>
          </Reveal>
        </div>

        {/* billing cycle toggle */}
        <Reveal delay={0.08}>
          <div className="mt-8 flex items-center justify-center">
            <div
              className="inline-flex items-center gap-1 rounded-2xl border border-slate-200 bg-white/70 p-1 backdrop-blur-sm dark:border-white/10 dark:bg-white/[0.04]"
              role="group"
              aria-label={t("priceBadge")}
            >
              {(["monthly", "yearly"] as const).map((c) => {
                const active = cycle === c;
                return (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setCycle(c)}
                    aria-pressed={active}
                    className={cn(
                      "relative inline-flex items-center gap-2 rounded-xl px-4 py-2 text-[12.5px] font-extrabold transition-all duration-200",
                      active
                        ? "text-white shadow-lg"
                        : "text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200"
                    )}
                    style={active ? { backgroundImage: grad("#6d5dfb", "#d946ef") } : undefined}
                  >
                    {t(c === "monthly" ? "priceMonthly" : "priceYearly")}
                    {c === "yearly" ? (
                      <span
                        className={cn(
                          "rounded-full px-1.5 py-0.5 text-[11px] font-extrabold",
                          active ? "bg-white/25 text-white" : "bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400"
                        )}
                      >
                        {dbPlans
                          ? savePct && savePct > 0
                            ? t("priceSavePct", { n: savePct, pct: savePct })
                            : null
                          : t("priceYearlySave")}
                      </span>
                    ) : null}
                  </button>
                );
              })}
            </div>
          </div>
        </Reveal>

        {/* plans */}
        <div
          className={cn(
            "mt-10 grid gap-5 lg:grid-cols-3",
            dbPlans && dbPlans.length === 4 && "xl:grid-cols-4"
          )}
          aria-busy={pending}
        >
          {pending ? (
            [0, 1, 2].map((i) => <SkeletonCard key={i} delay={i * 0.1} />)
          ) : (
            cards.map((plan, i) => (
              <PlanCard
                key={plan.key}
                plan={plan}
                delay={i * 0.1}
                perMonthLabel={t("pricePerMonth")}
                popularLabel={t("pricePopular")}
              />
            ))
          )}
        </div>

        {/* ROUND 79 — the 14-Day Full-Access positioning banner: every new
            workspace starts with FULL access for two weeks; the only limits
            are the clearly-stated costly/sensitive ones (storage, usage). */}
        <Reveal delay={0.16}>
          <div className="mx-auto mt-8 flex max-w-3xl flex-col items-center gap-2.5 rounded-3xl border border-emerald-200/70 bg-linear-to-br from-emerald-50/70 to-teal-50/40 px-5 py-4 text-center sm:flex-row sm:text-start dark:border-emerald-500/20 dark:from-emerald-500/[0.08] dark:to-teal-500/[0.05]">
            <span
              className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg shadow-emerald-500/25"
              style={{ backgroundImage: grad("#10b981", "#0d9488") }}
              aria-hidden="true"
            >
              <CatIcon name="sparkles" className="h-5 w-5" />
            </span>
            <span className="min-w-0">
              <span className="flex flex-wrap items-center justify-center gap-2 sm:justify-start">
                <span className="font-display text-[14px] font-extrabold text-emerald-700 dark:text-emerald-300">
                  {t("featTrialFullAccess")}
                </span>
                <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-extrabold text-emerald-600 dark:bg-emerald-500/20 dark:text-emerald-300">
                  <CatIcon name="calendar-check" className="h-[10px] w-[10px]" />
                  {t("priceCta")}
                </span>
              </span>
              <span className="mt-1 block text-[12px] font-semibold leading-relaxed text-emerald-800/80 dark:text-emerald-200/70">
                {t("featTrialFullAccessDesc")}
              </span>
            </span>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export default PricingSection;
