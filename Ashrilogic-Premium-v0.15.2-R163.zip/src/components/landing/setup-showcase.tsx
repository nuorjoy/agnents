"use client";

/**
 * Ashrilogic — cinematic setup showcase (round 34).
 *
 * A "video-like" auto-playing simulation of the full 7-step setup journey,
 * rendered purely with DOM + CSS (no video file, no external service):
 *
 *  - a vertical 7-step tracker (real wizard step names) lights up in sync,
 *  - a browser-chrome stage window plays each scene: welcome tiles, form
 *    fields typing themselves, module toggles flipping on, the admin card,
 *    preference pills, the review checklist, and finally the launch burst
 *    into a live mini-dashboard with counting KPIs,
 *  - the whole timeline loops automatically, only animating while visible
 *    (IntersectionObserver) and freezing to a static end-state under
 *    prefers-reduced-motion.
 *
 * Every string is i18n'd; logical CSS properties keep the stage mirroring
 * correctly in RTL (Arabic) and LTR (all other locales).
 */
import { useEffect, useMemo, useRef, useState } from "react";
import { useT, type I18nKey } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { Reveal } from "@/components/landing/reveal";
import { cn, grad } from "@/lib/utils";

/* ---------------- timeline constants ---------------- */

/** ms per sub-tick — every scene plays SUB_TICKS ticks. */
const TICK_MS = 520;
const SUB_TICKS = 5;
const SCENES = 7;
const LOOP_TICKS = SCENES * SUB_TICKS;

/** gradient palette cycled per step (matches the wizard's tiles). */
const STEP_STYLES = [
  { c1: "#6d5dfb", c2: "#8b5cf6" },
  { c1: "#06b6d4", c2: "#0891b2" },
  { c1: "#d946ef", c2: "#c026d3" },
  { c1: "#f59e0b", c2: "#ea580c" },
  { c1: "#10b981", c2: "#059669" },
  { c1: "#8b5cf6", c2: "#7c3aed" },
  { c1: "#ef4444", c2: "#be185d" },
] as const;

const STEP_KEYS: { name: I18nKey; icon: string; desc: I18nKey }[] = [
  { name: "wzStepWelcome", icon: "party-popper", desc: "showcaseScene1Desc" },
  { name: "wzStepOrg", icon: "building", desc: "showcaseScene2Desc" },
  { name: "wzStepModules", icon: "grid-3x3", desc: "showcaseScene3Desc" },
  { name: "wzStepAdmin", icon: "user-round-check", desc: "showcaseScene4Desc" },
  { name: "wzStepPrefs", icon: "sliders", desc: "showcaseScene5Desc" },
  { name: "wzStepReview", icon: "list-checks", desc: "showcaseScene6Desc" },
  { name: "wzStepDone", icon: "rocket", desc: "showcaseScene7Desc" },
];

/* ---------------- tiny building blocks ---------------- */

function TypingText({ text, chars, className }: { text: string; chars: number; className?: string }) {
  return (
    <span className={cn("relative inline-block", className)} dir="auto">
      {text.slice(0, Math.max(0, chars))}
      <span
        className="ms-0.5 inline-block h-[0.95em] w-[1.5px] translate-y-[0.1em] animate-pulse bg-brand-500 align-middle"
        aria-hidden="true"
      />
    </span>
  );
}

function FieldShell({
  label,
  filled,
  children,
}: {
  label: string;
  filled: boolean;
  children: React.ReactNode;
}) {
  return (
    <div className="w-full">
      <span className="mb-1 block text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
        {label}
      </span>
      <div
        className={cn(
          "flex h-8 items-center rounded-lg border px-2.5 text-[11.5px] font-semibold transition-colors duration-300",
          filled
            ? "border-emerald-300 bg-emerald-50/60 text-slate-700 dark:border-emerald-500/40 dark:bg-emerald-500/[0.07] dark:text-slate-200"
            : "border-slate-200 bg-white text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400"
        )}
      >
        {children}
        {filled ? (
          <span className="ms-auto grid h-4 w-4 shrink-0 place-items-center rounded-full bg-emerald-500 text-white">
            <CatIcon name="check" className="h-2.5 w-2.5" />
          </span>
        ) : null}
      </div>
    </div>
  );
}

/* ---------------- the seven scenes ---------------- */

function SceneWelcome({ tick }: { tick: number }) {
  const { t } = useT();
  /* ROUND 87 (13-e) — the trash + account-control chips join step 1: the
     showcase grid now sells 9 first-class capabilities in a 3×3 layout. */
  const chips = [
    { icon: "gauge", key: "wzFeature1" },
    { icon: "globe", key: "wzFeature7" },
    { icon: "chart-pie", key: "wzFeature2" },
    { icon: "users", key: "wzFeature8" },
    { icon: "language", key: "wzFeature4" },
    { icon: "smartphone", key: "wzFeature6" },
    { icon: "shopping-cart", key: "wzFeature9" },
    { icon: "trash-2", key: "wzFeature10" },
    { icon: "user-cog", key: "wzFeature11" },
  ] as const;
  /* ROUND 68 — 9 chips vs 5 sub-ticks: the reveal pops three chips per tick
     and lands all 9 by the 3rd tick (3 · 6 · 9) — snappy, never stranded. */
  const revealed = Math.min((tick + 1) * 3, chips.length);
  return (
    <div className="flex h-full flex-col items-center justify-center gap-3 p-5 text-center">
      <span
        className="grid h-14 w-14 place-items-center rounded-2xl text-white shadow-lg shadow-brand-500/30 transition-transform duration-500"
        style={{ backgroundImage: grad("#6d5dfb", "#d946ef"), transform: `scale(${tick >= 0 ? 1 : 0.6})` }}
      >
        <CatIcon name="heart-pulse" className="h-5 w-5" />
      </span>
      <div>
        <p className="text-[13px] font-extrabold text-slate-800 dark:text-slate-100">{t("showcaseWizardLabel")}</p>
        <p className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">{t("showcaseScene1Desc")}</p>
      </div>
      <div className="mt-1 grid w-full max-w-xs grid-cols-3 gap-1.5">
        {chips.map((c, i) => (
          <span
            key={c.key}
            className={cn(
              "flex items-center gap-1.5 rounded-xl border px-2 py-1.5 text-start text-[10px] font-bold leading-tight transition-all duration-400",
              /* ROUND 68 — the e-store chip reads as first-class: brand-active
                 border/fill + a tiny live emerald dot, matching the module
                 tiles' active treatment. */
              c.key === "wzFeature9"
                ? "border-brand-300 bg-brand-50/70 text-slate-700 dark:border-brand-500/40 dark:bg-brand-500/10 dark:text-slate-200"
                : "border-slate-200/80 bg-slate-50/60 text-slate-600 dark:border-white/10 dark:bg-white/[0.03] dark:text-slate-300",
              i < revealed ? "translate-y-0 opacity-100" : "translate-y-1.5 opacity-0"
            )}
          >
            <span
              className="grid h-5 w-5 shrink-0 place-items-center rounded-md text-white"
              style={{ backgroundImage: grad("#6d5dfb", "#8b5cf6") }}
            >
              <CatIcon name={c.icon} className="h-[9px] w-[9px]" />
            </span>
            {t(c.key)}
            {c.key === "wzFeature9" ? (
              <span className="ms-auto h-1.5 w-1.5 shrink-0 animate-pulse rounded-full bg-emerald-500" aria-hidden="true" />
            ) : null}
          </span>
        ))}
      </div>
    </div>
  );
}

function SceneOrg({ tick }: { tick: number }) {
  const { t } = useT();
  const speed = 3; // chars per tick
  const nameLen = tick * speed;
  const nameDone = tick >= 2;
  const countryDone = tick >= 3;
  const addressDone = tick >= 4;
  return (
    <div className="flex h-full flex-col justify-center gap-3 p-5">
      <p className="text-[11px] font-bold text-slate-500 dark:text-slate-400">{t("showcaseScene2Desc")}</p>
      <FieldShell label={t("wzOrgName")} filled={nameDone}>
        <TypingText text={t("showcaseOrgNameSample")} chars={nameLen} />
      </FieldShell>
      <FieldShell label={t("wzOrgCountry")} filled={countryDone}>
        {countryDone ? (
          <span>{t("showcaseOrgCountrySample")}</span>
        ) : (
          <TypingText text={t("showcaseOrgCountrySample")} chars={(tick - 2) * 6} />
        )}
      </FieldShell>
      <FieldShell label={t("wzOrgAddress")} filled={addressDone}>
        {addressDone ? <span>{t("showcaseOrgAddressSample")}</span> : <span className="text-slate-300">…</span>}
      </FieldShell>
    </div>
  );
}

function SceneModules({ tick }: { tick: number }) {
  const { t } = useT();
  const mods = [
    { icon: "user-round", key: "showcaseModulePatients" },
    { icon: "calendar-check", key: "showcaseModuleAppointments" },
    { icon: "file-invoice", key: "showcaseModuleInvoices" },
    { icon: "boxes", key: "showcaseModuleInventory" },
    { icon: "pill-bottle", key: "showcaseModulePharmacy" },
    { icon: "users", key: "showcaseModuleStaff" },
  ] as const;
  const on = Math.min(tick + 1, mods.length);
  return (
    <div className="flex h-full flex-col justify-center gap-3 p-5">
      <p className="text-[11px] font-bold text-slate-500 dark:text-slate-400">{t("showcaseScene3Desc")}</p>
      <div className="grid grid-cols-3 gap-1.5">
        {mods.map((m, i) => {
          const active = i < on;
          return (
            <span
              key={m.key}
              className={cn(
                "flex flex-col items-center gap-1 rounded-xl border px-1.5 py-2 text-center transition-all duration-300",
                active
                  ? "border-brand-300 bg-brand-50/70 dark:border-brand-500/40 dark:bg-brand-500/10"
                  : "border-slate-200/80 bg-slate-50/50 opacity-50 dark:border-white/10 dark:bg-white/[0.02]"
              )}
            >
              <span
                className={cn(
                  "grid h-6 w-6 place-items-center rounded-lg text-white transition-all duration-300",
                  active ? "scale-100" : "scale-90"
                )}
                style={{ backgroundImage: grad("#6d5dfb", "#d946ef") }}
              >
                <CatIcon name={m.icon} className="h-[11px] w-[11px]" />
              </span>
              <span className="text-[11px] font-bold leading-tight text-slate-600 dark:text-slate-300">{t(m.key)}</span>
              <span
                className={cn(
                  "grid h-3.5 w-3.5 place-items-center rounded-full transition-all duration-300",
                  active ? "scale-100 bg-emerald-500 text-white" : "scale-75 bg-slate-200 text-transparent dark:bg-white/10"
                )}
              >
                <CatIcon name="check" className="h-2 w-2" />
              </span>
            </span>
          );
        })}
      </div>
    </div>
  );
}

function SceneAdmin({ tick }: { tick: number }) {
  const { t } = useT();
  const nameLen = tick * 4;
  const nameDone = tick >= 2;
  const emailDone = tick >= 4;
  return (
    <div className="flex h-full flex-col items-center justify-center gap-3 p-5">
      <p className="text-[11px] font-bold text-slate-500 dark:text-slate-400">{t("showcaseScene4Desc")}</p>
      <span
        className="grid h-14 w-14 place-items-center rounded-full text-[15px] font-extrabold text-white shadow-lg shadow-brand-500/30"
        style={{ backgroundImage: grad("#8b5cf6", "#d946ef") }}
      >
        {t("showcaseAdminSample").replace("د. ", "").charAt(0)}
      </span>
      <div className="w-full max-w-[260px] space-y-2.5">
        <FieldShell label={t("wzAdminName")} filled={nameDone}>
          <TypingText text={t("showcaseAdminSample")} chars={nameLen} />
        </FieldShell>
        <FieldShell label={t("wzAdminEmail")} filled={emailDone}>
          {emailDone ? (
            <span dir="ltr">{t("showcaseAdminEmailSample")}</span>
          ) : (
            <TypingText text={t("showcaseAdminEmailSample")} chars={(tick - 2) * 8} />
          )}
        </FieldShell>
      </div>
    </div>
  );
}

function ScenePrefs({ tick }: { tick: number }) {
  const { t } = useT();
  /* ROUND 55 — the language row carries an "11" capability chip: the
     platform speaks all eleven registry locales (showcase mirror of the
     wizard's + owner settings' 11-language selectors). */
  const prefs = [
    { icon: "languages", label: t("showcasePrefLang"), badge: "11" },
    { icon: "moon", label: t("showcasePrefTheme") },
    { icon: "bell", label: t("showcasePrefNotif") },
  ];
  const on = Math.min(tick + 1, prefs.length);
  return (
    <div className="flex h-full flex-col justify-center gap-3 p-5">
      <p className="text-[11px] font-bold text-slate-500 dark:text-slate-400">{t("showcaseScene5Desc")}</p>
      <div className="space-y-1.5">
        {prefs.map((p, i) => {
          const active = i < on;
          return (
            <div
              key={p.label}
              className={cn(
                "flex items-center gap-2.5 rounded-xl border px-3 py-2 transition-all duration-300",
                active
                  ? "border-brand-300 bg-brand-50/60 dark:border-brand-500/40 dark:bg-brand-500/10"
                  : "border-slate-200/80 bg-slate-50/50 opacity-60 dark:border-white/10 dark:bg-white/[0.02]"
              )}
            >
              <span
                className="grid h-6 w-6 place-items-center rounded-lg text-white"
                style={{ backgroundImage: grad("#10b981", "#059669") }}
              >
                <CatIcon name={p.icon} className="h-[11px] w-[11px]" />
              </span>
              <span className="text-[11px] font-bold text-slate-600 dark:text-slate-300">{p.label}</span>
              {"badge" in p && p.badge ? (
                <span
                  dir="ltr"
                  className={cn(
                    "ms-1 inline-flex items-center rounded-full border px-1.5 py-px text-[9.5px] font-extrabold tabular-nums transition-colors duration-300",
                    active
                      ? "border-brand-300 bg-white/80 text-brand-600 dark:border-brand-500/40 dark:bg-white/10 dark:text-brand-300"
                      : "border-slate-200 bg-slate-50 text-slate-400 dark:border-white/10 dark:bg-white/5 dark:text-slate-500"
                  )}
                >
                  {p.badge}
                </span>
              ) : null}
              {/* toggle */}
              <span
                className={cn(
                  "ms-auto flex h-4 w-7 items-center rounded-full px-0.5 transition-colors duration-300",
                  active ? "justify-end bg-emerald-500" : "justify-start bg-slate-300 dark:bg-white/15"
                )}
              >
                <span className="h-3 w-3 rounded-full bg-white shadow-sm" />
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function SceneReview({ tick }: { tick: number }) {
  const { t } = useT();
  const rows = [
    { icon: "building", label: t("showcaseReviewRowOrg") },
    { icon: "grid-3x3", label: t("showcaseReviewRowModules") },
    { icon: "user-round-check", label: t("showcaseReviewRowAdmin") },
  ];
  const on = Math.min(tick + 1, rows.length);
  const launchReady = tick >= 4;
  return (
    <div className="flex h-full flex-col justify-center gap-3 p-5">
      <p className="text-[11px] font-bold text-slate-500 dark:text-slate-400">{t("showcaseScene6Desc")}</p>
      <div className="space-y-1.5">
        {rows.map((r, i) => {
          const active = i < on;
          return (
            <div
              key={r.label}
              className={cn(
                "flex items-center gap-2.5 rounded-xl border px-3 py-2 transition-all duration-300",
                active
                  ? "border-emerald-300/70 bg-emerald-50/50 dark:border-emerald-500/30 dark:bg-emerald-500/[0.06]"
                  : "border-slate-200/80 bg-slate-50/50 opacity-60 dark:border-white/10 dark:bg-white/[0.02]"
              )}
            >
              <span
                className={cn(
                  "grid h-5 w-5 place-items-center rounded-full transition-all duration-300",
                  active ? "bg-emerald-500 text-white" : "bg-slate-200 text-transparent dark:bg-white/10"
                )}
              >
                <CatIcon name="check" className="h-2.5 w-2.5" />
              </span>
              <span className="text-[11px] font-bold text-slate-600 dark:text-slate-300">{r.label}</span>
              <CatIcon name={r.icon} className="ms-auto h-3.5 w-3.5 text-slate-300 dark:text-slate-600" />
            </div>
          );
        })}
      </div>
      {/* progress */}
      <div className="mt-1">
        <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-200/80 dark:bg-white/10">
          <div
            className="h-full rounded-full bg-linear-to-l from-brand-600 to-fuchsia-500 transition-all duration-500"
            style={{ width: `${Math.min(100, (tick + 1) * 20)}%` }}
          />
        </div>
      </div>
      {launchReady ? (
        <span className="mx-auto inline-flex items-center gap-1.5 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-4 py-2 text-[11px] font-extrabold text-white shadow-lg shadow-brand-500/30">
          <CatIcon name="rocket" className="h-3.5 w-3.5" />
          {t("showcaseLaunchBtn")}
        </span>
      ) : null}
    </div>
  );
}

function SceneDashboard({ tick }: { tick: number }) {
  const { t } = useT();
  const kpis = [
    { icon: "user-round", label: t("showcaseKpi1"), value: 248, c1: "#6d5dfb", c2: "#8b5cf6" },
    { icon: "calendar-check", label: t("showcaseKpi2"), value: 36, c1: "#10b981", c2: "#059669" },
    { icon: "banknote", label: t("showcaseKpi3"), value: 84200, c1: "#f59e0b", c2: "#ea580c" },
  ];
  const progress = Math.min(1, (tick + 1) / SUB_TICKS);
  const bars = [38, 55, 47, 70, 62, 84, 78, 92];
  /* ROUND 68 — e-store strip: every launched system ships with its own
     storefront, so the live mini-dashboard surfaces it next to the KPIs —
     gradient tile + title (wzFeature9), ready chip, three popping product
     thumbnails and a counting "orders today" value. */
  const products = [
    { icon: "pill-bottle", c1: "#6d5dfb", c2: "#8b5cf6" },
    { icon: "boxes", c1: "#06b6d4", c2: "#0891b2" },
    { icon: "smartphone", c1: "#f59e0b", c2: "#ea580c" },
  ] as const;
  return (
    <div className="relative flex h-full flex-col justify-center gap-2.5 p-5">
      {/* launch confetti */}
      <span className="pointer-events-none absolute inset-0" aria-hidden="true">
        {tick <= 2
          ? [12, 28, 45, 61, 78, 90].map((left, i) => (
              <span
                key={i}
                className="absolute top-3 h-1.5 w-1.5 rounded-full animate-confetti"
                style={{
                  insetInlineStart: `${left}%`,
                  backgroundColor: ["#6d5dfb", "#d946ef", "#06b6d4", "#10b981", "#f59e0b", "#ef4444"][i % 6],
                  animationDelay: `${i * 90}ms`,
                }}
              />
            ))
          : null}
      </span>
      <div className="flex items-center gap-2">
        <span className="grid h-6 w-6 place-items-center rounded-lg bg-linear-to-br from-brand-500 to-fuchsia-500 text-white">
          <CatIcon name="gauge" className="h-3 w-3" />
        </span>
        <span className="text-[12px] font-extrabold text-slate-800 dark:text-slate-100">{t("showcaseDashboardLabel")}</span>
        <span className="ms-auto inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2 py-0.5 text-[11px] font-extrabold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
          {t("badgeLive")}
        </span>
      </div>
      <div className="grid grid-cols-3 gap-1.5">
        {kpis.map((k) => (
          <div
            key={k.label}
            className="rounded-xl border border-slate-200/80 bg-white/70 p-2 text-center dark:border-white/10 dark:bg-white/[0.03]"
          >
            <span
              className="mx-auto grid h-6 w-6 place-items-center rounded-lg text-white"
              style={{ backgroundImage: grad(k.c1, k.c2) }}
            >
              <CatIcon name={k.icon} className="h-[11px] w-[11px]" />
            </span>
            <p className="mt-1.5 font-display text-[15px] font-extrabold tabular-nums text-slate-900 dark:text-white">
              {Math.round(k.value * progress).toLocaleString("en-US")}
            </p>
            <p className="text-[11px] font-bold leading-tight text-slate-500 dark:text-slate-400">{k.label}</p>
          </div>
        ))}
      </div>
      {/* e-store strip (platform storefront) */}
      <div className="flex h-12 min-w-0 items-center gap-2 rounded-xl border border-slate-200/80 bg-white/70 px-2.5 dark:border-white/10 dark:bg-white/[0.03]">
        <span
          className="grid h-6 w-6 shrink-0 place-items-center rounded-lg text-white shadow-sm shadow-brand-500/25"
          style={{ backgroundImage: grad("#6d5dfb", "#d946ef") }}
        >
          <CatIcon name="shopping-cart" className="h-3 w-3" />
        </span>
        <span className="min-w-0 truncate text-[11.5px] font-extrabold text-slate-800 dark:text-slate-100">
          {t("wzFeature9")}
        </span>
        <span className="hidden shrink-0 items-center gap-1 rounded-full bg-emerald-100 px-1.5 py-0.5 text-[9.5px] font-extrabold text-emerald-700 sm:inline-flex dark:bg-emerald-500/15 dark:text-emerald-300">
          <span className="h-1 w-1 animate-pulse rounded-full bg-emerald-500" />
          {t("showcaseStoreReady")}
        </span>
        {/* mini product thumbnails — staggered pop-in like SceneWelcome's chips */}
        <span className="flex shrink-0 items-center gap-1">
          {products.map((p, i) => (
            <span
              key={p.icon}
              className={cn(
                "grid h-[18px] w-[18px] place-items-center rounded-md text-white transition-all duration-300",
                i < Math.min(tick + 1, 3) ? "translate-y-0 scale-100 opacity-100" : "translate-y-1 scale-75 opacity-0"
              )}
              style={{ backgroundImage: grad(p.c1, p.c2) }}
            >
              <CatIcon name={p.icon} className="h-[9px] w-[9px]" />
            </span>
          ))}
        </span>
        <span className="ms-auto flex shrink-0 items-baseline gap-1">
          <span className="font-display text-[13px] font-extrabold tabular-nums text-slate-900 dark:text-white">
            {Math.round(18 * progress)}
          </span>
          <span className="text-[9.5px] font-bold text-slate-500 dark:text-slate-400">{t("showcaseStoreOrders")}</span>
        </span>
      </div>
      {/* sparkline */}
      <div className="flex h-12 items-end justify-between gap-1 rounded-xl border border-slate-200/80 bg-white/70 px-2.5 pb-2 pt-2 dark:border-white/10 dark:bg-white/[0.03]">
        {bars.map((h, i) => (
          <span
            key={i}
            className="chart-bar w-full rounded-t-sm bg-linear-to-t from-brand-600 to-fuchsia-400"
            style={{ height: `${h * progress}%`, animationDelay: `${i * 40}ms` }}
          />
        ))}
      </div>
    </div>
  );
}

/* ---------------- the section ---------------- */

export function SetupShowcase() {
  const { t } = useT();
  const [tick, setTick] = useState(0);
  const [visible, setVisible] = useState(false);
  const [reduced, setReduced] = useState(false);
  const stageRef = useRef<HTMLDivElement>(null);

  /* reduced-motion + visibility observers */
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const apply = () => setReduced(mq.matches);
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, []);

  useEffect(() => {
    const el = stageRef.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => setVisible(entries.some((e) => e.isIntersecting)),
      { threshold: 0.25 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  /* the timeline — loops forever while visible & motion allowed */
  useEffect(() => {
    if (reduced || !visible) return;
    const id = window.setInterval(() => setTick((v) => (v + 1) % LOOP_TICKS), TICK_MS);
    return () => window.clearInterval(id);
  }, [reduced, visible]);

  /* static end-state under reduced motion */
  const safeTick = reduced ? LOOP_TICKS - 1 : tick;
  const scene = Math.floor(safeTick / SUB_TICKS);
  const subTick = safeTick % SUB_TICKS;

  const scenes = useMemo(
    () => [
      <SceneWelcome key="s1" tick={subTick} />,
      <SceneOrg key="s2" tick={subTick} />,
      <SceneModules key="s3" tick={subTick} />,
      <SceneAdmin key="s4" tick={subTick} />,
      <ScenePrefs key="s5" tick={subTick} />,
      <SceneReview key="s6" tick={subTick} />,
      <SceneDashboard key="s7" tick={subTick} />,
    ],
    [subTick]
  );

  const onCta = () => {
    document.getElementById("systems")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <section id="showcase" className="scroll-mt-20 px-4 py-16 sm:px-6 lg:px-8 lg:py-20">
      <div className="mx-auto max-w-7xl">
        {/* heading */}
        <div className="mx-auto max-w-3xl text-center">
          <Reveal>
            <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3.5 py-1.5 text-[11px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
              <CatIcon name="play" className="h-[11px] w-[11px] text-brand-500" />
              <span>{t("showcaseBadge")}</span>
            </span>
            <h2 className="mt-5 font-display text-[28px] font-extrabold leading-tight tracking-tight sm:text-4xl">
              <span className="me-2">{t("showcaseTitle1")}</span>
              <span className="text-gradient">{t("showcaseTitle2")}</span>
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-[14px] leading-relaxed text-slate-600 dark:text-slate-400 sm:text-[15px]">
              {t("showcaseDesc")}
            </p>
          </Reveal>
        </div>

        {/* stage */}
        <Reveal delay={0.1}>
          <div
            ref={stageRef}
            className="glass-card mt-10 overflow-hidden rounded-3xl p-4 sm:p-6 lg:p-8"
            role="img"
            aria-label={`${t("showcaseTitle1")} ${t("showcaseTitle2")}`}
          >
            {/* mobile-first single column; explicit minmax(0,1fr) track + min-w-0
                children keep the 7-step tracker (horizontal scroller) from
                inflating the implicit grid track to its content width (~1100px
                on phones) and clipping the browser stage. */}
            <div className="grid min-w-0 grid-cols-1 gap-5 lg:grid-cols-[290px_1fr] lg:gap-8">
              {/* step tracker */}
              <div className="order-2 min-w-0 lg:order-1">
                {/* horizontal on mobile, vertical on lg */}
                <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar lg:flex-col lg:overflow-visible lg:pb-0">
                  {STEP_KEYS.map((step, i) => {
                    const style = STEP_STYLES[i % STEP_STYLES.length];
                    const active = i === scene;
                    const done = i < scene;
                    return (
                      <div
                        key={step.name}
                        className={cn(
                          "flex min-w-[150px] items-center gap-2.5 rounded-2xl border px-3 py-2.5 transition-all duration-300 lg:min-w-0",
                          active
                            ? "border-brand-300 bg-brand-50/70 shadow-md shadow-brand-500/10 dark:border-brand-500/40 dark:bg-brand-500/10"
                            : done
                              ? "border-emerald-200 bg-emerald-50/40 dark:border-emerald-500/25 dark:bg-emerald-500/[0.05]"
                              : "border-slate-200/70 bg-white/50 opacity-70 dark:border-white/[0.07] dark:bg-white/[0.02]"
                        )}
                      >
                        <span
                          className={cn(
                            "grid h-8 w-8 shrink-0 place-items-center rounded-xl text-white shadow-sm transition-transform duration-300",
                            active && "scale-110"
                          )}
                          style={{ backgroundImage: grad(style.c1, style.c2) }}
                        >
                          <CatIcon name={done ? "check" : step.icon} className="h-[13px] w-[13px]" />
                        </span>
                        <span className="hidden min-w-0 lg:block">
                          <span className="block text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                            {t("showcaseStepLabel")} {i + 1} / {SCENES}
                          </span>
                          <span className="block truncate text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                            {t(step.name)}
                          </span>
                          <span className="block truncate text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                            {t(step.desc)}
                          </span>
                        </span>
                        <span className="text-[11.5px] font-extrabold text-slate-700 lg:hidden dark:text-slate-200">
                          {t(step.name)}
                        </span>
                        {active ? (
                          <span className="ms-auto hidden h-2 w-2 shrink-0 animate-pulse rounded-full bg-brand-500 lg:block" />
                        ) : null}
                      </div>
                    );
                  })}
                </div>

                {/* legend under the tracker (desktop) */}
                <div className="mt-4 hidden flex-col gap-1.5 lg:flex">
                  <span className="inline-flex w-fit items-center gap-1.5 rounded-full bg-emerald-100 px-2.5 py-1 text-[10px] font-extrabold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
                    <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-500" />
                    {t("showcaseLiveChip")}
                  </span>
                  <span className="text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                    {t("showcaseAutoLoop")}
                  </span>
                </div>
              </div>

              {/* browser stage */}
              <div className="order-1 min-w-0 lg:order-2">
                <div className="overflow-hidden rounded-2xl border border-slate-200/80 bg-white/80 shadow-soft dark:border-white/10 dark:bg-[#0a0f1c]/80">
                  {/* chrome bar */}
                  <div className="flex items-center gap-2 border-b border-slate-200/70 px-3.5 py-2.5 dark:border-white/[0.07]">
                    <span className="flex gap-1.5" aria-hidden="true">
                      <span className="h-2.5 w-2.5 rounded-full bg-rose-400" />
                      <span className="h-2.5 w-2.5 rounded-full bg-amber-400" />
                      <span className="h-2.5 w-2.5 rounded-full bg-emerald-400" />
                    </span>
                    <span
                      className="mx-auto flex h-6 w-40 items-center justify-center gap-1.5 rounded-full bg-slate-100 px-3 text-[11px] font-bold text-slate-500 dark:bg-white/[0.06] dark:text-slate-400"
                      dir="ltr"
                    >
                      <CatIcon name="lock" className="h-[9px] w-[9px] text-emerald-500" />
                      ashrilogic.com
                    </span>
                    <span className="text-[11px] font-extrabold tabular-nums text-slate-400 dark:text-slate-500" dir="ltr">
                      {scene + 1}/{SCENES}
                    </span>
                  </div>
                  {/* scene body — fixed min-height avoids layout jumps between scenes */}
                  <div className="relative h-[300px] sm:h-[320px]">
                    <div key={scene} className="step-in absolute inset-0">
                      {scenes[scene]}
                    </div>
                  </div>
                  {/* bottom progress bar */}
                  <div className="h-1 w-full bg-slate-100 dark:bg-white/[0.05]">
                    <div
                      className="h-full bg-linear-to-l from-brand-600 to-fuchsia-500 transition-all duration-500 ease-linear"
                      style={{ width: `${((safeTick + 1) / LOOP_TICKS) * 100}%` }}
                    />
                  </div>
                </div>

                {/* CTA row */}
                <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                  <p className="text-[11.5px] font-semibold text-slate-500 dark:text-slate-400">
                    {t(STEP_KEYS[scene].desc)}
                  </p>
                  <button
                    type="button"
                    onClick={onCta}
                    className="inline-flex h-10 items-center gap-2 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-4 text-[12.5px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:shadow-brand-500/40 hover:brightness-110 active:scale-95"
                  >
                    <CatIcon name="mouse-pointer-click" className="h-[14px] w-[14px]" />
                    {t("showcaseCta")}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </Reveal>

        {/* hint */}
        <p className="mt-4 text-center text-[11px] font-semibold text-slate-400 dark:text-slate-500">
          {t("showcaseCtaHint")}
        </p>
      </div>
    </section>
  );
}

export default SetupShowcase;
