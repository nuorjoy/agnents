"use client";

/**
 * Ashrilogic — partners trust strip.
 *
 * A compact social-proof band placed high on the landing page (right after
 * the hero/tech strip). Shows a "Trusted by" label + a marquee of REAL
 * REGISTERED sector organizations, curated by the Super Admin console
 * (قيادات القطاعات): every card maps to a live workspace on the platform
 * and carries a verified-registration chip. The display name honors the
 * console's override and falls back to the workspace's live org name.
 *
 * ROUND 134-C — owner directive: the OFFICIAL WEBSITE no longer reveals
 * each partner's join date («عميل منذ YYYY» is admin-console-only — see
 * admin-partners.tsx). Public cards render icon + name only; the partnerSince
 * dictionary key stays for the console.
 *
 * The marquee viewport is pinned LTR so the shared `marquee` keyframes
 * (translateX 0 → -50%) stay seamless on the Arabic RTL page — an RTL
 * track anchors to the right edge and would slide the whole row out of
 * view mid-loop. Each chip carries its own dir, so Arabic cards keep the
 * icon on the reading-start side.
 *
 * Fallback: when the curated showcase is EMPTY (a fresh install where no
 * Super Admin has curated anything yet), the strip renders the original
 * static placeholder set so the section never breaks visually.
 */
import { useQuery } from "@tanstack/react-query";
import { useT } from "@/lib/i18n";
import type { Lang } from "@/lib/types";
import type { SectorPartnerDTO } from "@/lib/types";
import { fetchSectorPartners } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { Reveal } from "@/components/landing/reveal";
import { grad } from "@/lib/utils";

interface PartnerCard {
  key: string;
  icon: string;
  nameAr: string;
  nameEn: string;
  c1: string;
  c2: string;
  /** true when the card maps to a real registered workspace */
  verified: boolean;
}

/** Static placeholder set — ONLY rendered while the curated showcase is
 *  empty (fresh installs). Fictional-but-realistic names, as before. */
const PLACEHOLDER_PARTNERS: PartnerCard[] = [
  { key: "ph-1", icon: "heart-pulse", nameAr: "النخبة الطبية", nameEn: "Elite Medical", c1: "#f43f5e", c2: "#ec4899", verified: false },
  { key: "ph-2", icon: "graduation-cap", nameAr: "جامعة المستقبل", nameEn: "Future University", c1: "#8b5cf6", c2: "#6366f1", verified: false },
  { key: "ph-3", icon: "store", nameAr: "أسواق المدينة", nameEn: "City Markets", c1: "#f59e0b", c2: "#ea580c", verified: false },
  { key: "ph-4", icon: "utensils", nameAr: "مطاعم الذواقة", nameEn: "Gourmet Restaurants", c1: "#10b981", c2: "#059669", verified: false },
  { key: "ph-5", icon: "building", nameAr: "مجموعة الأعمال", nameEn: "Business Group", c1: "#06b6d4", c2: "#0ea5e9", verified: false },
  { key: "ph-6", icon: "hotel", nameAr: "فنادق اللؤلؤ", nameEn: "Pearl Hotels", c1: "#d946ef", c2: "#c026d3", verified: false },
  { key: "ph-7", icon: "truck", nameAr: "النقل السريع", nameEn: "Swift Logistics", c1: "#6d5dfb", c2: "#8b5cf6", verified: false },
  { key: "ph-8", icon: "factory", nameAr: "الصناعات الحديثة", nameEn: "Modern Industries", c1: "#0891b2", c2: "#06b6d4", verified: false },
];

/** DB rows → marquee cards (join dates stay private — R134-C). */
function toCards(partners: SectorPartnerDTO[]): PartnerCard[] {
  return partners.map((p) => ({
    key: p.id,
    icon: p.icon,
    nameAr: p.nameAr,
    nameEn: p.nameEn,
    c1: p.c1,
    c2: p.c2,
    verified: true,
  }));
}

export function PartnersStrip() {
  const { t, lang } = useT();

  /* live curated showcase — the static set renders while loading OR when
   * the console has curated nothing yet (fresh install) */
  const partnersQuery = useQuery({
    queryKey: ["public-partners"],
    queryFn: fetchSectorPartners,
    staleTime: 60_000,
    retry: 1,
  });
  const live = partnersQuery.data?.partners ?? [];
  const cards: PartnerCard[] = live.length > 0 ? toCards(live) : PLACEHOLDER_PARTNERS;

  return (
    <section className="px-4 py-10 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <Reveal>
          <div className="flex flex-col items-center gap-6">
            <div className="text-center">
              <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1 text-[10.5px] font-bold uppercase tracking-wider text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-400">
                <CatIcon name="badge-check" className="h-[11px] w-[11px] text-emerald-500" />
                {t("partnersBadge")}
              </span>
              <h2 className="mt-4 font-display text-[20px] font-extrabold tracking-tight sm:text-2xl">
                <span className="me-2">{t("partnersTitle1")}</span>
                <span className="text-gradient">{t("partnersTitle2")}</span>
              </h2>
              <p className="mx-auto mt-2 max-w-xl text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
                {t("partnersDesc")}
              </p>
            </div>

            {/* marquee row — viewport pinned LTR (seamless keyframes on the
                RTL page); duplicated groups make -50% land exactly on the
                seam; pauses on hover, stops under prefers-reduced-motion */}
            <div className="relative w-full overflow-hidden" dir="ltr">
              {/* edge fades */}
              <div className="pointer-events-none absolute inset-y-0 start-0 z-10 w-16 bg-gradient-to-r from-background to-transparent dark:from-[#05080f]" aria-hidden="true" />
              <div className="pointer-events-none absolute inset-y-0 end-0 z-10 w-16 bg-gradient-to-l from-background to-transparent dark:from-[#05080f]" aria-hidden="true" />

              <div className="flex w-max animate-[marquee_32s_linear_infinite] items-center hover:[animation-play-state:paused] motion-reduce:animate-none">
                <MarqueeGroup cards={cards} lang={lang} />
                {/* duplicate — decorative, hidden from assistive tech */}
                <MarqueeGroup cards={cards} lang={lang} hidden />
              </div>
            </div>

            {/* verified-registration footnote — only when real orgs render */}
            {live.length > 0 ? (
              <p className="flex items-center gap-1.5 text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                <CatIcon name="shield-check" className="h-[11px] w-[11px] text-emerald-500" />
                {t("partnerRealChip")}
              </p>
            ) : null}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/**
 * One marquee copy — the trailing padding equals the inter-chip gap, so the
 * duplicated track's -50% translation lands exactly on the seam (no jump).
 * Chips carry their own dir: Arabic keeps the icon on the reading-start
 * (right) side, Latin locales keep it on the left.
 */
function MarqueeGroup({ cards, lang, hidden = false }: { cards: PartnerCard[]; lang: Lang; hidden?: boolean }) {
  return (
    <div
      className="flex items-center gap-4 pe-4 sm:gap-6 sm:pe-6"
      aria-hidden={hidden || undefined}
    >
      {cards.map((p) => (
        <div
          key={p.key}
          dir={lang === "ar" ? "rtl" : "ltr"}
          className="group flex shrink-0 items-center gap-2.5 rounded-2xl border border-slate-200/70 bg-white/60 px-4 py-2.5 backdrop-blur-sm transition-all duration-200 hover:-translate-y-1 hover:border-brand-300/60 hover:shadow-lg hover:shadow-brand-500/10 dark:border-white/[0.08] dark:bg-white/[0.03] dark:hover:border-brand-500/30"
        >
          <span
            className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white shadow-sm transition-transform duration-200 group-hover:scale-110"
            style={{ backgroundImage: grad(p.c1, p.c2) }}
            aria-hidden="true"
          >
            <CatIcon name={p.icon} className="h-[12px] w-[12px]" />
          </span>
          <span className="whitespace-nowrap font-display text-[12.5px] font-extrabold text-slate-700 dark:text-slate-200">
            {lang === "ar" ? p.nameAr : p.nameEn}
          </span>
        </div>
      ))}
    </div>
  );
}

export default PartnersStrip;
