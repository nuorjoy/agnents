"use client";

import { useQuery } from "@tanstack/react-query";
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { SocialLinks } from "@/components/social-links";
import { fetchSupportContact } from "@/lib/api-client";
import { SUPPORT_CHANNELS } from "@/lib/social";
import { PlatformBrandTile, usePlatformWordmark } from "@/components/shared/platform-brand";

const YEAR = new Date().getFullYear();

interface FooterCol {
  title: string;
  links: { href: string; label: string }[];
}

const SYSTEM_LINKS_KEYS = ["footerHealth", "footerEducation", "footerRetail", "footerHospitality"] as const;

export function LandingFooter() {
  const { t } = useT();
  const wordmark = usePlatformWordmark();
  /* contact channels mirror the control-panel Settings state (fail-soft) */
  const { data: contact } = useQuery({
    queryKey: ["support-contact"],
    queryFn: fetchSupportContact,
    staleTime: 60_000,
    retry: 1,
  });
  const supportEmail = contact?.supportEmail ?? SUPPORT_CHANNELS.email;
  const supportPhone = contact?.supportPhone ?? SUPPORT_CHANNELS.phone;

  const systemCol: FooterCol = {
    title: t("footerSystems"),
    links: SYSTEM_LINKS_KEYS.map((key) => ({ href: "/#systems", label: t(key) })),
  };
  const platformCol: FooterCol = {
    title: t("footerPlatform"),
    links: [
      { href: "/#support", label: t("footerSupport") },
      { href: "/#features", label: t("navFeatures") },
      { href: "/#sectors", label: t("navSectors") },
      { href: "/#systems", label: t("footerLibrary") },
      /* ROUND 117 — the platform legal pages (console-editable) */
      { href: "/privacy", label: t("footerPrivacy") },
      { href: "/terms", label: t("footerTerms") },
    ],
  };

  const contactItems = [
    { icon: "mail", value: supportEmail, href: `mailto:${supportEmail}` },
    { icon: "phone", value: supportPhone, href: `tel:${supportPhone.replace(/\s+/g, "")}` },
    { icon: "map-pin", value: t("footerRemote") },
  ];

  return (
    <footer className="safe-bottom mt-auto border-t border-slate-200/70 bg-white/70 backdrop-blur-sm dark:border-white/[0.07] dark:bg-white/[0.02]">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          {/* Brand + social */}
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="flex items-center gap-2.5">
              <PlatformBrandTile
                variant="main"
                className="h-10 w-10 rounded-xl shadow-brand-500/25"
                fallback={
                  <span className="grid h-10 w-10 place-items-center rounded-xl bg-linear-to-br from-brand-500 via-fuchsia-500 to-cyan-400 text-white shadow-lg shadow-brand-500/25">
                    <CatIcon name="boxes" className="h-[15px] w-[15px]" />
                  </span>
                }
              />
              <span className="font-display text-[17px] font-extrabold">
                <span className="text-gradient">{wordmark}</span>
              </span>
            </div>
            <p className="mt-4 max-w-xs text-[13px] leading-relaxed text-slate-600 dark:text-slate-400">
              {t("footerDesc")}
            </p>
            <div className="mt-5">
              <p className="mb-2.5 text-[11px] font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                {t("footerFollowUs")}
              </p>
              <SocialLinks variant="compact" />
            </div>
          </div>

          {/* Systems */}
          <div>
            <h4 className="text-[12px] font-extrabold uppercase tracking-wider text-slate-900 dark:text-white">
              {systemCol.title}
            </h4>
            <ul className="mt-4 space-y-2.5 text-[13px] text-slate-600 dark:text-slate-400">
              {systemCol.links.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="transition hover:text-brand-600 dark:hover:text-brand-300">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Platform */}
          <div>
            <h4 className="text-[12px] font-extrabold uppercase tracking-wider text-slate-900 dark:text-white">
              {platformCol.title}
            </h4>
            <ul className="mt-4 space-y-2.5 text-[13px] text-slate-600 dark:text-slate-400">
              {platformCol.links.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="transition hover:text-brand-600 dark:hover:text-brand-300">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-[12px] font-extrabold uppercase tracking-wider text-slate-900 dark:text-white">
              {t("footerContact")}
            </h4>
            <ul className="mt-4 space-y-2.5 text-[13px] text-slate-600 dark:text-slate-400">
              {contactItems.map((item) => (
                <li key={item.icon} className="flex items-center gap-2">
                  <CatIcon name={item.icon} className="h-4 w-4 shrink-0 text-brand-500" />
                  {item.href ? (
                    <a
                      href={item.href}
                      className="transition hover:text-brand-600 dark:hover:text-brand-300"
                      dir="ltr"
                    >
                      {item.value}
                    </a>
                  ) : (
                    <span>{item.value}</span>
                  )}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-3 border-t border-slate-200 pt-6 text-center dark:border-white/10 sm:flex-row sm:text-start">
          <p className="text-[12px] text-slate-500 dark:text-slate-400">
            © {YEAR} {wordmark} — {t("footerRights")}
          </p>
          {/* ROUND 55 — the crafted-with-love credit: heart icon in a soft
              rose→fuchsia gradient, brand-colored team name */}
          <p className="inline-flex items-center gap-1.5 text-[12px] font-semibold text-slate-500 dark:text-slate-400">
            <span
              className="grid h-4.5 w-4.5 place-items-center rounded-full text-white shadow-sm"
              style={{ backgroundImage: "linear-gradient(135deg,#f43f5e,#d946ef)" }}
              aria-hidden="true"
            >
              <CatIcon name="heart" className="h-[10px] w-[10px]" />
            </span>
            <span>{t("footerMade")}</span>
          </p>
        </div>
      </div>
    </footer>
  );
}

export default LandingFooter;
