import { FAQS } from "@/lib/structured-data";
import { safeJsonLd } from "@/lib/safe-json-ld";
import { SITE_URL } from "@/lib/site-url";

/**
 * Ashrilogic — JSON-LD structured data (Task 3-c SEO round).
 *
 * Renders four schema.org blocks for rich search results:
 *  - Organization: brand identity + social profiles (knowledge panel).
 *  - WebSite: the platform website with a SearchAction hint (sitelinks
 *    search box — Google's "search this site" affordance).
 *  - SoftwareApplication: the product itself (app rich result).
 *  - FAQPage: the 8 FAQ Q&A pairs (FAQ rich result).
 *
 * Server component — emitted once in <head> via the root layout. Every
 * block serializes through `safeJsonLd` (script-context escaping) —
 * defense-in-depth even though these values are build-time constants today.
 *
 * The canonical `url` / `logo` resolve to SITE_URL (env-overridable) so a
 * preview/staging deployment never advertises the wrong canonical host to
 * Google's knowledge graph.
 */
export function StructuredData() {
  const org = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "Ashrilogic",
    alternateName: "أشرِيلوجيك",
    url: SITE_URL,
    logo: `${SITE_URL}/favicon.svg`,
    image: `${SITE_URL}/og.png`,
    description:
      "102 premium management systems across 16 sectors with full multilingual support (Arabic, English, Hindi), a smart 7-step setup wizard, and an executive dashboard.",
    /* foundingDate + foundingLocation REMOVED — unverified business data.
     * Restore ONLY when the platform has a verified business identity on file. */
    /* sameAs REMOVED — social URLs should come from PlatformSetting.socialJson,
     * not hardcoded build constants. The platform identity is centralized in
     * /api/identity. See docs/engineering/TECHNICAL-DEBT.md P2-1. */
  };

  const website = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: "أشرِيلوجيك · Ashrilogic",
    alternateName: "Ashrilogic",
    url: SITE_URL,
    description:
      "102 premium management systems with full multilingual support, a smart 7-step setup wizard, and an executive dashboard.",
    inLanguage: ["ar", "en", "hi"],
    publisher: { "@type": "Organization", name: "Ashrilogic" },
  };

  const app = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    name: "Ashrilogic",
    alternateName: "أشرِيلوجيك",
    applicationCategory: "BusinessApplication",
    operatingSystem: "Web",
    url: SITE_URL,
    description:
      "102 premium management systems across 16 sectors with full multilingual support, a 7-step setup wizard, and an executive dashboard.",
    /* offers REMOVED — pricing must come from the canonical source
     * (packages API / billing). Hardcoding a price in JSON-LD risks
     * divergence from the actual billing surface. See
     * docs/engineering/TECHNICAL-DEBT.md P2-1. */
    /* aggregateRating REMOVED (P2-1 fix) — no real review aggregation
     * exists. Google penalizes fabricated AggregateRating data. Restore
     * ONLY when real SiteReview aggregation is wired in. See
     * docs/engineering/TECHNICAL-DEBT.md P2-1. */
    featureList: [
      "102 management systems across 16 sectors",
      "Smart 7-step setup wizard",
      "Executive dashboard with live charts",
      "Full Arabic/English/Hindi RTL/LTR support",
      "Dark mode",
      "Super-Admin control panel",
      "CSV/JSON export",
      "24/7 support",
    ],
  };

  const faqPage = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: FAQS.map((f) => ({
      "@type": "Question",
      name: f.q,
      acceptedAnswer: {
        "@type": "Answer",
        text: f.a,
      },
    })),
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: safeJsonLd(org) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: safeJsonLd(website) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: safeJsonLd(app) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: safeJsonLd(faqPage) }}
      />
    </>
  );
}
