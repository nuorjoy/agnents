import { db } from "@/lib/db";
import type {
  AuthenticationResponseJSON,
  AuthenticatorTransportFuture,
  PublicKeyCredentialCreationOptionsJSON,
  PublicKeyCredentialRequestOptionsJSON,
  RegistrationResponseJSON,
} from "@simplewebauthn/server";
import {
  generateAuthenticationOptions,
  generateRegistrationOptions,
  verifyAuthenticationResponse,
  verifyRegistrationResponse,
} from "@simplewebauthn/server";

/**
 * Ashrilogic — ROUND 45 — WebAuthn / Passkey support (server side).
 *
 * Backs BOTH account surfaces:
 *  - scope "admin"    → control-panel AdminUser accounts
 *  - scope "instance" → tenant workspace accounts
 *
 * SECURITY POSTURE:
 *  - The private key NEVER touches this server (it stays sealed inside the
 *    user's authenticator / OS keystore). We persist only the PUBLIC COSE
 *    key + the clone-detection counter, and NEVER serialize either to a
 *    client response — the list endpoints expose metadata only (name,
 *    dates, transports, device type).
 *  - Challenges are single-purpose ("register" | "login"), bound to their
 *    scope+subject, and expire after 3 minutes; a fresh challenge sweep
 *    removes stale rows opportunistically.
 *  - RP identity is derived from the REQUEST (x-forwarded-host chain first —
 *    the platform sits behind a reverse proxy), so passkeys work on every
 *    deployment domain without code changes.
 */

export type WebauthnScope = "admin" | "instance";

const CHALLENGE_TTL_MS = 3 * 60 * 1000;

/* ------------------------------ RP identity ----------------------------- */

/**
 * Effective host for this request: the forwarded chain first (proxy world),
 * then the request URL host. Port stripped — RP IDs are registrable domains.
 */
export function effectiveHost(req: Request): string {
  const forwarded = req.headers.get("x-forwarded-host");
  if (forwarded) {
    const first = forwarded.split(",")[0]!.trim();
    if (first) return first.split(":")[0]!;
  }
  try {
    return new URL(req.url).host.split(":")[0]!;
  } catch {
    return "localhost";
  }
}

/** Effective https-ness: forwarded proto wins (proxy terminates TLS). */
function effectiveProtocol(req: Request): "https" | "http" {
  const proto = req.headers.get("x-forwarded-proto")?.split(",")[0]?.trim();
  if (proto === "https" || proto === "http") return proto;
  try {
    return new URL(req.url).protocol === "https:" ? "https" : "http";
  } catch {
    return "http";
  }
}

/**
 * ROUND 55 — the WebAuthn ORIGIN puzzle, solved properly.
 *
 * WHY passkeys "refused to work" behind the sandbox/preview proxy: the
 * gateway stamps `X-Forwarded-Proto` with the scheme of ITS OWN listener
 * (plain http when an outer TLS-terminating proxy forwards to it), so the
 * computed origin was `http://<public-host>` while the browser performed the
 * ceremony on `https://<public-host>` — verify{Registration,Authentication}
 * Response rejected every assertion with a silent origin mismatch.
 *
 * The fix resolves a SET of acceptable origins, all bound to OUR host:
 *  1. the computed origin (x-forwarded-proto / request URL), and
 *  2. the BROWSER-DECLARED `Origin` request header — but ONLY when its host
 *     equals the effective host (the same trust chain the CSRF origin-guard
 *     uses). The browser sets that header itself; JavaScript cannot forge it
 *     cross-site, and a non-browser client that fakes it still has to produce
 *     a WebAuthn signature made ON OUR DOMAIN — which they cannot.
 *  3. the https twin of the host (localhost stays http-eligible: it is a
 *     secure context by spec, and dev servers run on it).
 *
 * simplewebauthn accepts `expectedOrigin: string | string[]`, so both the
 * registration and the authentication verifiers consume the whole set —
 * whichever scheme the ceremony actually ran on verifies cleanly, and a
 * lookalike domain can never register or authenticate (host binding holds).
 */
export function rpConfig(req: Request): { rpID: string; rpName: string; origin: string; origins: string[] } {
  const host = effectiveHost(req);
  const computed = `${effectiveProtocol(req)}://${host}`;
  const origins = new Set<string>([computed, `https://${host}`]);
  if (host === "localhost" || host === "127.0.0.1" || host.endsWith(".localhost")) {
    origins.add(`http://${host}`);
  }
  const declared = req.headers.get("origin");
  if (declared) {
    try {
      const parsed = new URL(declared);
      if (
        parsed.host.split(":")[0]!.toLowerCase() === host &&
        (parsed.protocol === "https:" || parsed.protocol === "http:")
      ) {
        origins.add(parsed.origin);
      }
    } catch {
      /* malformed Origin header — ignored, the computed set stands */
    }
  }
  return { rpID: host, rpName: "Ashrilogic", origin: computed, origins: [...origins] };
}

/* --------------------- ROUND 46 — cross-device passkey QR ---------------------- */

/**
 * Server-rendered QR for the passkey "add on another device" flow: the user
 * scans it with their phone, opens the SAME origin there, signs in and
 * registers the passkey with that device's biometrics (the standard
 * GitHub/Google cross-device enrollment pattern).
 *
 * SECURITY: the client supplies only a PATH ("/admin") — never a full URL —
 * and the server builds the target against ITS OWN perceived origin
 * (x-forwarded-host aware), so the phone always scans a URL this deployment
 * really serves. Path validation: must start with "/", no protocol-relative
 * "//", no userinfo tricks, bounded length. The endpoint is never an open
 * QR generator. The premium violet module color matches the passkey surface.
 */
export async function crossDeviceQrSvg(req: Request, path: string | undefined): Promise<string | null> {
  if (!path || typeof path !== "string") return null;
  if (!path.startsWith("/") || path.startsWith("//")) return null;
  if (path.length > 200 || /[\s\\]/.test(path)) return null;
  const { origin } = rpConfig(req);
  let target: URL;
  try {
    target = new URL(path, origin);
  } catch {
    return null;
  }
  if (target.origin !== origin) return null;

  const { default: QRCode } = await import("qrcode");
  return QRCode.toString(target.toString(), {
    type: "svg",
    errorCorrectionLevel: "H",
    margin: 1,
    color: { dark: "#6d28d9", light: "#ffffff" },
  });
}

/* --------------------------- challenge storage -------------------------- */

async function sweepChallenges(): Promise<void> {
  await db.webauthnChallenge.deleteMany({ where: { expiresAt: { lt: new Date() } } });
}

async function storeChallenge(
  scope: WebauthnScope,
  subjectId: string,
  challenge: string,
  purpose: "register" | "login"
): Promise<void> {
  await db.webauthnChallenge.create({
    data: {
      scope,
      subjectId,
      challenge,
      purpose,
      expiresAt: new Date(Date.now() + CHALLENGE_TTL_MS),
    },
  });
  /* opportunistic sweep (bounded: only rows past expiry) */
  void sweepChallenges().catch(() => undefined);
}

async function consumeChallenge(
  scope: WebauthnScope,
  subjectId: string,
  challenge: string,
  purpose: "register" | "login"
): Promise<boolean> {
  /* single-use: delete-then-check (SQLite serializes writers) */
  const deleted = await db.webauthnChallenge.deleteMany({
    where: { scope, subjectId, challenge, purpose },
  });
  return deleted.count > 0;
}

/* ------------------------------ credential IO --------------------------- */

interface CredentialRow {
  id: string;
  publicKey: string;
  counter: number;
  transports: string | null;
  name: string | null;
  deviceType: string | null;
  backedUp: boolean;
  createdAt: Date;
  lastUsedAt: Date | null;
}

function parseTransports(raw: string | null): AuthenticatorTransportFuture[] {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw) as unknown;
    return Array.isArray(parsed) ? (parsed.filter((t) => typeof t === "string") as AuthenticatorTransportFuture[]) : [];
  } catch {
    return [];
  }
}

/** Client-safe credential metadata (NO key material, ever). */
export interface WebauthnCredentialDTO {
  id: string;
  name: string;
  deviceType: string | null;
  backedUp: boolean;
  createdAt: string;
  lastUsedAt: string | null;
}

export async function listCredentials(
  scope: WebauthnScope,
  subjectId: string
): Promise<WebauthnCredentialDTO[]> {
  const rows = await db.webauthnCredential.findMany({
    where: { scope, subjectId },
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      name: true,
      deviceType: true,
      backedUp: true,
      createdAt: true,
      lastUsedAt: true,
    },
  });
  return rows.map((r) => ({
    id: r.id,
    name: r.name ?? "Passkey",
    deviceType: r.deviceType,
    backedUp: r.backedUp,
    createdAt: r.createdAt.toISOString(),
    lastUsedAt: r.lastUsedAt?.toISOString() ?? null,
  }));
}

async function getCredentialRow(
  scope: WebauthnScope,
  subjectId: string,
  credentialId: string
): Promise<CredentialRow | null> {
  return db.webauthnCredential.findUnique({
    where: { scope_subjectId_id: { scope, subjectId, id: credentialId } },
  });
}

export async function hasCredentials(scope: WebauthnScope, subjectId: string): Promise<boolean> {
  const row = await db.webauthnCredential.findFirst({
    where: { scope, subjectId },
    select: { id: true },
  });
  return !!row;
}

/* ------------------------------ registration ---------------------------- */

/** STEP 1 — registration options for the authenticated account. */
export async function startPasskeyRegistration(
  req: Request,
  scope: WebauthnScope,
  subjectId: string,
  userName: string,
  userDisplayName: string
): Promise<PublicKeyCredentialCreationOptionsJSON> {
  const { rpID, rpName } = rpConfig(req);

  const existing = await db.webauthnCredential.findMany({
    where: { scope, subjectId },
    select: { id: true, transports: true },
  });

  const options = await generateRegistrationOptions({
    rpName,
    rpID,
    userID: new TextEncoder().encode(subjectId),
    userName: userName.slice(0, 64),
    userDisplayName: userDisplayName.slice(0, 120),
    attestationType: "none",
    authenticatorSelection: {
      residentKey: "preferred",
      /* UV is REQUIRED at enrollment too: a credential enrolled without
         user-verification capability could never satisfy the login gate
         below — rejecting it here prevents locking its owner out. */
      userVerification: "required",
    },
    excludeCredentials: existing.map((c) => ({
      id: c.id,
      transports: parseTransports(c.transports),
    })),
  });

  await storeChallenge(scope, subjectId, options.challenge, "register");
  return options;
}

/** STEP 2 — verify the authenticator's registration response and persist. */
export async function finishPasskeyRegistration(
  req: Request,
  scope: WebauthnScope,
  subjectId: string,
  label: string,
  response: RegistrationResponseJSON
): Promise<{ ok: true; id: string } | { ok: false; error: string }> {
  const { rpID, origins } = rpConfig(req);

  const row = await db.webauthnChallenge.findFirst({
    where: { scope, subjectId, purpose: "register" },
    orderBy: { createdAt: "desc" },
  });
  if (!row || row.expiresAt < new Date()) {
    return { ok: false, error: "EXPIRED" };
  }
  if (!(await consumeChallenge(scope, subjectId, row.challenge, "register"))) {
    return { ok: false, error: "EXPIRED" };
  }

  try {
    const verification = await verifyRegistrationResponse({
      response,
      expectedChallenge: row.challenge,
      /* ROUND 55 — the full acceptable-origin set (proxy-scheme proof) */
      expectedOrigin: origins,
      expectedRPID: rpID,
      /* Enrolled credentials must be user-verifying (see options above). */
      requireUserVerification: true,
    });

    if (!verification.verified || !verification.registrationInfo) {
      return { ok: false, error: "INVALID" };
    }
    const info = verification.registrationInfo;
    const credentialId = info.credential.id;
    const transports = response.response.transports ?? [];

    const conflict = await getCredentialRow(scope, subjectId, credentialId);
    if (conflict) {
      return { ok: false, error: "DUPLICATE" };
    }

    await db.webauthnCredential.create({
      data: {
        id: credentialId,
        scope,
        subjectId,
        publicKey: Buffer.from(info.credential.publicKey).toString("base64url"),
        counter: info.credential.counter,
        deviceType: info.credentialDeviceType,
        backedUp: info.credentialBackedUp,
        transports: JSON.stringify(transports),
        name: label.trim().slice(0, 60) || null,
        lastUsedAt: new Date(),
      },
    });
    return { ok: true, id: credentialId };
  } catch {
    return { ok: false, error: "INVALID" };
  }
}

/** Remove a passkey (owners manage their own credentials). */
export async function removePasskey(
  scope: WebauthnScope,
  subjectId: string,
  credentialId: string
): Promise<boolean> {
  const deleted = await db.webauthnCredential.deleteMany({
    where: { scope, subjectId, id: credentialId },
  });
  return deleted.count > 0;
}

/* ----------------------------- authentication --------------------------- */

/**
 * Login step 1 — authentication options. When `subjectId` is known the
 * allow-list pins this account's credentials; when null the options are
 * DISCOVERABLE (usernameless — the browser lists every passkey for this RP;
 * the finish step resolves the account from the credential id).
 */
export async function startPasskeyLogin(
  req: Request,
  scope: WebauthnScope,
  subjectId: string | null
): Promise<{ ok: true; options: PublicKeyCredentialRequestOptionsJSON } | { ok: false; error: string }> {
  const { rpID } = rpConfig(req);

  let allowCredentials: { id: string; transports?: AuthenticatorTransportFuture[] }[] | undefined;
  if (subjectId) {
    const rows = await db.webauthnCredential.findMany({
      where: { scope, subjectId },
      select: { id: true, transports: true },
    });
    if (rows.length === 0) return { ok: false, error: "NO_CREDENTIALS" };
    allowCredentials = rows.map((c) => ({ id: c.id, transports: parseTransports(c.transports) }));
  }

  const options = await generateAuthenticationOptions({
    rpID,
    /* Passkeys act as the MFA second factor on this platform — the "something
       you are/have" property only holds when the authenticator re-verifies
       the user (biometric/PIN) at every ceremony. */
    userVerification: "required",
    ...(allowCredentials ? { allowCredentials } : {}),
  });

  await storeChallenge(scope, subjectId ?? "*", options.challenge, "login");
  return { ok: true, options };
}

/**
 * Login step 2 — verify the assertion. Resolves the SUBJECT from the
 * credential id (works for both pinned and discoverable flows), checks the
 * challenge, verifies the signature against the stored public key, enforces
 * the clone-detection counter, and stamps lastUsedAt.
 *
 * ROUND 117 — optional `pinnedChallenge`: the CROSS-DEVICE bridge knows its
 * OWN challenge (the one embedded in the options the phone signed). Passing
 * it pins verification to exactly that challenge instead of "the newest
 * live one" — the desktop may have started its own native ceremony in the
 * meantime, which would otherwise shadow the bridge challenge in the
 * newest-first lookup and fail the phone's assertion with a phantom
 * mismatch. The pinned challenge is still consumed single-use through the
 * SAME store, so all single-use semantics hold.
 */
export async function finishPasskeyLogin(
  req: Request,
  scope: WebauthnScope,
  response: AuthenticationResponseJSON,
  pinnedChallenge?: string
): Promise<{ ok: true; subjectId: string } | { ok: false; error: string }> {
  const { rpID, origins } = rpConfig(req);

  const credential = await db.webauthnCredential.findUnique({
    where: { id: response.id },
  });
  if (!credential || credential.scope !== scope) {
    return { ok: false, error: "UNKNOWN_CREDENTIAL" };
  }

  let expected: string;
  if (typeof pinnedChallenge === "string" && pinnedChallenge) {
    /* ROUND 117 — the bridge's own challenge, single-use as everywhere */
    if (
      !(await consumeChallenge(scope, credential.subjectId, pinnedChallenge, "login")) &&
      !(await consumeChallenge(scope, "*", pinnedChallenge, "login"))
    ) {
      return { ok: false, error: "EXPIRED" };
    }
    expected = pinnedChallenge;
  } else {
    const challengeRows = await db.webauthnChallenge.findMany({
      where: {
        scope,
        purpose: "login",
        /* the challenge may be pinned to this subject OR discoverable ("*") */
        subjectId: { in: [credential.subjectId, "*"] },
      },
      orderBy: { createdAt: "desc" },
      take: 5,
    });
    const live = challengeRows.find((r) => r.expiresAt >= new Date());
    if (!live) return { ok: false, error: "EXPIRED" };
    if (
      !(await consumeChallenge(scope, credential.subjectId, live.challenge, "login")) &&
      !(await consumeChallenge(scope, "*", live.challenge, "login"))
    ) {
      return { ok: false, error: "EXPIRED" };
    }
    expected = live.challenge;
  }

  try {
    const verification = await verifyAuthenticationResponse({
      response,
      expectedChallenge: expected,
      /* ROUND 55 — the full acceptable-origin set (proxy-scheme proof) */
      expectedOrigin: origins,
      expectedRPID: rpID,
      credential: {
        id: credential.id,
        publicKey: new Uint8Array(Buffer.from(credential.publicKey, "base64url")),
        counter: credential.counter,
        transports: parseTransports(credential.transports),
      },
      requireUserVerification: true,
    });

    if (!verification.verified) return { ok: false, error: "INVALID" };

    await db.webauthnCredential.update({
      where: { id: credential.id },
      data: { counter: verification.authenticationInfo.newCounter, lastUsedAt: new Date() },
    });
    return { ok: true, subjectId: credential.subjectId };
  } catch {
    return { ok: false, error: "INVALID" };
  }
}
