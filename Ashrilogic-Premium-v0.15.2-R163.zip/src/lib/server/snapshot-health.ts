import { createHash } from "node:crypto";
import { existsSync, mkdtempSync, readdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { storageRoot } from "./platform-backup";
import { decryptBackupArtifact, isBackupEnvelope, resolveBackupMasterKeys } from "./backup-crypto";

/**
 * Ashrilogic — platform snapshot health (ROUND 104).
 *
 * The DR story is complete end-to-end (platform snapshots + off-volume
 * mirror + verified restore CLIs), but it had a blind spot: BETWEEN backups,
 * nothing watched the snapshots themselves. Bit rot, a partially-filled
 * volume, or an interrupted mirror write would surface only at RESTORE
 * time — the worst possible moment to learn the DR artifact is bad.
 *
 * This module closes that gap with a READ-ONLY verification of the NEWEST
 * platform snapshot, surfaced through /api/status:
 *
 *   • the newest snapshot directory resolves (name + manifest present)
 *   • manifest.json parses and its database.db entry is intact on disk
 *   • the snapshot's SQLite file passes PRAGMA quick_check (opened
 *     READ-ONLY through bun:sqlite — the live DB is never touched)
 *   • when the manifest carries databaseSha256 (ROUND 104+ manifests),
 *     the actual bytes still hash to it — post-write corruption of the
 *     database copy is detected, not just pre-write
 *   • every manifest image entry still exists and still hashes to its
 *     recorded digest (image digests were verified at BACKUP time only)
 *
 * VERDICT DISCIPLINE — this feeds a PUBLIC, anonymous endpoint, so the
 * result carries ZERO business data and ZERO filesystem paths:
 *   ok          — everything above passed
 *   snapshot    — the snapshot directory NAME (a timestamp, nothing else)
 *   ageHours    — hours since the snapshot was created
 *   issues      — machine-readable CODES only (see SnapshotIssue)
 *
 * COST discipline — /api/status is polled frequently; a full re-hash of a
 * ~6MB snapshot on every poll would be waste. Results are cached in
 * process memory for CACHE_TTL_MS and can be bypassed with { force: true }
 * (the status route always serves the cache; operators get a fresh verdict
 * at most every 10 minutes, which is far tighter than the daily/weekly
 * backup cadence the verdict describes).
 */

/** Machine-readable issue codes — NEVER strings from errors (paths leak). */
export type SnapshotIssue =
  | "NO_SNAPSHOT"
  | "MANIFEST_INVALID"
  | "DATABASE_MISSING"
  | "DATABASE_CORRUPT"
  | "DATABASE_DIGEST_MISMATCH"
  /* ROUND 137 — the database member is an ASHBC1 envelope but no master
   * key resolves in THIS process: the snapshot cannot be verified (and
   * could not be restored) until the key is provisioned. */
  | "DATABASE_ENCRYPTED_NO_KEY"
  | "IMAGE_MISSING"
  | "IMAGE_DIGEST_MISMATCH"
  | "IMAGES_UNVERIFIED"
  | "VERIFY_ERROR";

export interface SnapshotHealth {
  ok: boolean;
  /** newest snapshot directory name (timestamp-shaped) — null pre-first-backup */
  snapshot: string | null;
  /** hours since the snapshot's manifest createdAt — null pre-first-backup */
  ageHours: number | null;
  /** ISO timestamp of the verification itself (not the snapshot) */
  verifiedAt: string;
  issues: SnapshotIssue[];
}

const SNAPSHOT_DIR = /^ashrilogic-\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}$/;
const CACHE_TTL_MS = 10 * 60 * 1000;

interface CacheEntry {
  at: number;
  health: SnapshotHealth;
}

/* process-wide cache (survives hot reloads via globalThis, mirroring the
   platform-backup scheduler state pattern) */
const STATE_FLAG = "__ashrilogicSnapshotHealthCache";
const g = globalThis as Record<string, unknown>;

function readCache(): CacheEntry | null {
  return (g[STATE_FLAG] as CacheEntry | undefined) ?? null;
}

function writeCache(entry: CacheEntry): void {
  g[STATE_FLAG] = entry;
}

/** Test seam — reset the TTL cache between fixture scenarios. */
export function clearSnapshotHealthCache(): void {
  delete g[STATE_FLAG];
}

interface ManifestShape {
  createdAt?: string;
  database?: string;
  databaseSha256?: string;
  /* ROUND 137 — the database member is an ASHBC1 envelope (local at-rest
   * encryption). databaseSha256 stays the PLAINTEXT digest. */
  databaseEncrypted?: boolean;
  images?: Array<{ file?: string; sha256?: string; verified?: boolean }>;
  imagesUnverified?: number;
}

function sha256File(path: string): string {
  return createHash("sha256").update(readFileSync(path)).digest("hex");
}

/** Minimal read-only SQLite handle that works under BOTH server runtimes:
 *  the dev server runs next-server under Node (node:sqlite), while the
 *  production standalone server and `bun test` run under Bun (bun:sqlite).
 *  Only what PRAGMA quick_check needs — open readonly, one scalar query,
 *  close. A file that will not open as SQLite under EITHER runtime throws
 *  (→ DATABASE_CORRUPT at the call site). */
interface RoSqlite {
  quickCheck(): string | null | undefined;
  close(): void;
}

async function openReadonlySqlite(path: string): Promise<RoSqlite> {
  try {
    /* Bun runtime (bun test, production standalone server.js under bun) */
    const { Database } = (await import("bun:sqlite")) as typeof import("bun:sqlite");
    const db = new Database(path, { readonly: true });
    return {
      quickCheck: () =>
        (db.query("PRAGMA quick_check").get() as Record<string, unknown> | null)?.["quick_check"] as
          | string
          | null,
      close: () => db.close(),
    };
  } catch {
    /* Node runtime (next dev / next-server) — node:sqlite (Node ≥ 22.5) */
    const { DatabaseSync } = (await import("node:sqlite")) as typeof import("node:sqlite");
    const db = new DatabaseSync(path, { readOnly: true });
    return {
      quickCheck: () =>
        (db.prepare("PRAGMA quick_check").get() as Record<string, unknown> | null)?.["quick_check"] as
          | string
          | null,
      close: () => db.close(),
    };
  }
}

/** Newest snapshot directory under <storageRoot>/backups, or null.
 *  Names are UTC ISO timestamps — lexicographic order IS chronological
 *  order (the same invariant the off-volume mirror's retention relies on),
 *  and unlike mtime it is immune to touch/copy artifacts. */
function newestSnapshotDir(backups: string): string | null {
  if (!existsSync(backups)) return null;
  const candidates = readdirSync(backups)
    .filter((f) => SNAPSHOT_DIR.test(f))
    .sort()
    .reverse();
  return candidates[0] ?? null;
}

/** Verify the newest platform snapshot. READ-ONLY: the live database and
 *  every snapshot byte are opened read-only; nothing is written anywhere. */
export async function verifyLatestSnapshotHealth(
  opts: { force?: boolean } = {}
): Promise<SnapshotHealth> {
  const cached = readCache();
  if (!opts.force && cached && Date.now() - cached.at < CACHE_TTL_MS) {
    return cached.health;
  }

  const health = await computeHealth();
  writeCache({ at: Date.now(), health });
  return health;
}

async function computeHealth(): Promise<SnapshotHealth> {
  const verifiedAt = new Date().toISOString();
  const issues: SnapshotIssue[] = [];
  try {
    const backups = join(storageRoot(), "backups");
    const newest = newestSnapshotDir(backups);
    if (!newest) {
      return { ok: false, snapshot: null, ageHours: null, verifiedAt, issues: ["NO_SNAPSHOT"] };
    }
    const dir = join(backups, newest);

    /* manifest must parse; shape is validated defensively (a truncated or
       hand-edited manifest is a DR incident, not a crash) */
    let manifest: ManifestShape;
    try {
      manifest = JSON.parse(readFileSync(join(dir, "manifest.json"), "utf8")) as ManifestShape;
    } catch {
      return {
        ok: false,
        snapshot: newest,
        ageHours: null,
        verifiedAt,
        issues: ["MANIFEST_INVALID"],
      };
    }

    const ageHours =
      manifest.createdAt && !Number.isNaN(Date.parse(manifest.createdAt))
        ? Math.max(0, (Date.now() - Date.parse(manifest.createdAt)) / 3_600_000)
        : null;

    /* the database copy itself */
    const dbPath = join(dir, "database.db");
    if (!existsSync(dbPath)) {
      issues.push("DATABASE_MISSING");
    } else {
      /* ROUND 137 — encrypted members decrypt in-memory for verification
       * (digest) and through a PRIVATE TEMP DIR for the SQLite quick_check
       * (the decrypted bytes never touch the snapshot directory). */
      let plainBytes: Buffer | null = null;
      const raw = readFileSync(dbPath);
      if (isBackupEnvelope(raw)) {
        const keys = resolveBackupMasterKeys();
        if (!keys.available) {
          issues.push("DATABASE_ENCRYPTED_NO_KEY");
          plainBytes = null;
        } else {
          const opened = decryptBackupArtifact(raw, {
            active: keys.active,
            previous: keys.previous,
          });
          if (!opened.ok) {
            issues.push("DATABASE_DIGEST_MISMATCH"); /* envelope tampered /
              unknown key — fail visible, never guess */
            plainBytes = null;
          } else {
            plainBytes = opened.plain;
          }
        }
      } else {
        plainBytes = raw;
      }
      if (plainBytes !== null) {
        if (typeof manifest.databaseSha256 === "string") {
          /* ROUND 104+ manifests — detect post-write bit rot (ROUND 137:
           * the digest is computed over the DECRYPTED plaintext) */
          if (createHash("sha256").update(plainBytes).digest("hex") !== manifest.databaseSha256) {
            issues.push("DATABASE_DIGEST_MISMATCH");
          }
        }
        /* quick_check on a READ-ONLY connection — the snapshot only; the
           live DB is never opened by this module. A file that will not even
           OPEN as SQLite (torn write, foreign bytes) is corrupt, not an
           internal error. Runtime-agnostic adapter: bun:sqlite under Bun,
           node:sqlite under the Node dev server. Encrypted members verify
           through a decrypted copy in a private temp dir. */
        let checkPath = dbPath;
        let tempDir: string | null = null;
        if (isBackupEnvelope(raw)) {
          try {
            tempDir = mkdtempSync(join(tmpdir(), "ash-snapshot-health-"));
            checkPath = join(tempDir, "database.db");
            writeFileSync(checkPath, plainBytes);
          } catch {
            tempDir = null;
            checkPath = dbPath; /* fall back — the open below fails safely */
          }
        }
        try {
          const sqlite = await openReadonlySqlite(checkPath);
          try {
            if (sqlite.quickCheck() !== "ok") issues.push("DATABASE_CORRUPT");
          } finally {
            sqlite.close();
          }
        } catch {
          issues.push("DATABASE_CORRUPT");
        } finally {
          if (tempDir !== null) {
            rmSync(tempDir, { recursive: true, force: true });
          }
        }
      }
    }

    /* image inventory — every recorded file present + digest-stable.
       Missing and tampered are INDEPENDENT findings: one must never mask
       the other. */
    const imagesDir = join(dir, "images");
    let imageMissing = false;
    let imageTampered = false;
    for (const img of manifest.images ?? []) {
      if (typeof img.file !== "string" || typeof img.sha256 !== "string") {
        imageTampered = true; /* malformed entry — digest-level doubt */
        continue;
      }
      const p = join(imagesDir, img.file);
      if (!existsSync(p)) {
        imageMissing = true;
        continue;
      }
      if (sha256File(p) !== img.sha256) {
        imageTampered = true;
      }
    }
    if (imageMissing) issues.push("IMAGE_MISSING");
    if (imageTampered) issues.push("IMAGE_DIGEST_MISMATCH");
    if ((manifest.imagesUnverified ?? 0) > 0) issues.push("IMAGES_UNVERIFIED");

    return { ok: issues.length === 0, snapshot: newest, ageHours, verifiedAt, issues };
  } catch {
    /* any unexpected failure is reported as a CODE — never a stack trace /
       path on a public endpoint */
    return { ok: false, snapshot: null, ageHours: null, verifiedAt, issues: ["VERIFY_ERROR"] };
  }
}
