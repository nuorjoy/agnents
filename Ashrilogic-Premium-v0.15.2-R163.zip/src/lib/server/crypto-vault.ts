import {
  createCipheriv,
  createDecipheriv,
  createHmac,
  hkdfSync,
  randomBytes,
  timingSafeEqual,
  createHash,
} from "node:crypto";
import { argon2id } from "@noble/hashes/argon2.js";
import { loadSecret } from "@/lib/server/runtime-guard";

/**
 * Ashrilogic — field-level cryptography vault (round 35).
 *
 * Two independent primitives back the platform's data-at-rest protection:
 *
 * 1. PASSWORDS — Argon2id (the Memory-Hard winner of the Password Hashing
 *    Competition) with OWASP-recommended parameters (m=19 MiB, t=2, p=1,
 *    128-bit salt). PHC-style self-describing records:
 *
 *        $argon2id$v=1$m=19456,t=2,p=1$<salt-b64>$<hash-b64>
 *
 *    Legacy SHA-256 digests keep verifying (transparent upgrade-on-login:
 *    a successful legacy check returns the upgraded Argon2id record so the
 *    caller persists it — the stored hash migrates itself over time).
 *
 * 2. SENSITIVE FIELDS — AES-256-GCM envelope encryption with per-record
 *    random IV + 128-bit auth tag. The data key is derived through HKDF-SHA256
 *    from ASHRILOGIC_DATA_KEY (set it in production!) with distinct
 *    info-strings per purpose, so the AES key, the blind-index key and any
 *    future field family never reuse key material:
 *
 *        enc:v1:<iv-b64>:<tag-b64>:<ciphertext-b64>
 *
 *    Values carrying the `enc:v1:` marker decrypt on read; anything else
 *    passes through unchanged (legacy plaintext rows get re-encrypted on
 *    their next write and were migrated by the round-35 backfill).
 *
 *    LOOKUPS over encrypted fields (login by email, dedupe, uniqueness) use
 *    keyed HMAC-SHA256 BLIND INDEXES — deterministic per value, but
 *    irreversible without the index key. Email columns therefore store
 *    ciphertext while `emailIndex` stores the blind index used in WHERE
 *    clauses.
 *
 * No payment instruments are ever stored by the platform (no card/bank
 * fields exist in the schema) — the vault covers every sensitive field the
 * data model actually persists (phones, emails, addresses).
 */

/* ------------------------------- key material ------------------------------ */

function loadDataKeySecret(): string {
  return loadSecret({
    envVar: "ASHRILOGIC_DATA_KEY",
    minLen: 16,
    demoValue: "ashrilogic-demo-field-encryption-key-rotate-me",
    label: "field-encryption root key",
  });
}

const DATA_KEY_SECRET = loadDataKeySecret();

const KEY_LEN = 32; // AES-256 / HMAC-SHA256
const INFO_AES = "ashrilogic/field-aes-256-gcm/v1";
const INFO_INDEX = "ashrilogic/blind-index-hmac/v1";

function derive(info: string): Buffer {
  return Buffer.from(
    hkdfSync("sha256", Buffer.from(DATA_KEY_SECRET, "utf8"), Buffer.alloc(0), info, KEY_LEN)
  );
}

/** AES-256-GCM data key (never used for anything else). */
const AES_KEY = derive(INFO_AES);
/** HMAC-SHA256 blind-index key (never used for anything else). */
const INDEX_KEY = derive(INFO_INDEX);

/* --------------------------------- Argon2id -------------------------------- */

/** OWASP-recommended Argon2id parameters (19 MiB, 2 iterations, 1 lane). */
const ARGON2_PARAMS = { t: 2, m: 19456, p: 1, dkLen: 32 } as const;
const ARGON2_TAG = "$argon2id";
const ARGON2_PARAM_SUFFIX = "m=19456,t=2,p=1";
/** marker prefix of the legacy pre-round-35 digests (unsalted SHA-256 hex). */
const LEGACY_SHA256_LEN = 64;

/* AUTH-WORK BACKPRESSURE (Phase 12): Argon2id is memory-hard BY DESIGN
 * (~250-300ms CPU each) and runs synchronously on the event loop — a
 * distributed credential flood at ≥ ~4 attempts/second would starve every
 * other request. The per-IP rate limiter already blunts single-source
 * floods; this is the PROCESS-WIDE shed: a sliding window over recent
 * argon2 computations refuses (fails auth fast) once the sustained rate
 * exceeds AUTH_WORK_LIMIT per window. Honest traffic never reaches it —
 * it takes a sustained flood; security parameters are NOT weakened. */
const AUTH_WORK_LIMIT = 20;
const AUTH_WORK_WINDOW_MS = 10_000;
const authWorkStamps: number[] = [];

/** true when the process has absorbed too many KDF computations in the
 *  recent window — the caller fails the attempt without spending CPU. */
function authWorkSaturated(now: number): boolean {
  while (authWorkStamps.length > 0 && now - authWorkStamps[0]! > AUTH_WORK_WINDOW_MS) {
    authWorkStamps.shift();
  }
  return authWorkStamps.length >= AUTH_WORK_LIMIT;
}

function recordAuthWork(now: number): void {
  authWorkStamps.push(now);
}

/** Exposed for tests: clear the backpressure window. */
export function __resetAuthWorkWindowForTests(): void {
  authWorkStamps.length = 0;
}

/** Exposed for tests: saturate the window with N cheap stamps (the gate's
 * behavior is what matters — not burning N real KDFs to prove it). */
export function __saturateAuthWorkForTests(count: number): void {
  const now = Date.now();
  for (let i = 0; i < count; i++) authWorkStamps.push(now);
}

/** Exposed for ops diagnostics: current window depth (never secrets). */
export function authWorkDepth(): number {
  authWorkSaturated(Date.now());
  return authWorkStamps.length;
}

/**
 * Hash a password with Argon2id into a self-describing PHC-style record.
 * ~250-300ms by design — memory-hard KDFs are supposed to cost.
 */
export function hashPasswordArgon2id(password: string): string {
  /* ROUND 120 — the backpressure gate covers the HASH path too (the
   * pre-120 gate guarded only verifyPasswordArgon2id: a register /
   * password-change flood burned KDF CPU through this function while
   * login floods were being shed). A saturated hash call THROWS — the
   * callers are authenticated, low-rate flows (register, reset, change);
   * a sustained flood reaching this gate is an attack, not traffic. */
  const now = Date.now();
  if (authWorkSaturated(now)) {
    console.warn(
      JSON.stringify({
        ts: new Date().toISOString(),
        level: "warn",
        event: "ops.auth.backpressure",
        result: "hash attempt shed (sustained KDF flood)",
      })
    );
    throw new Error("AUTH_WORK_SATURATED");
  }
  recordAuthWork(now);
  const salt = randomBytes(16);
  const hash = argon2id(
    Buffer.from(password, "utf8"),
    salt,
    ARGON2_PARAMS
  );
  return [
    ARGON2_TAG,
    "v=1",
    ARGON2_PARAM_SUFFIX,
    salt.toString("base64"),
    Buffer.from(hash).toString("base64"),
  ].join("$");
}

/** True when the stored record is a (legacy) unsalted SHA-256 hex digest. */
export function isLegacyPasswordHash(storedHash: string | null | undefined): boolean {
  if (!storedHash) return false;
  return !storedHash.startsWith(ARGON2_TAG);
}

/**
 * Verify a password against a stored hash — accepts current Argon2id records
 * AND legacy SHA-256 digests (demo-era rows), in constant time where the
 * comparison allows it.
 */
export function verifyPasswordArgon2id(
  password: string,
  storedHash: string | null | undefined
): boolean {
  if (!storedHash) return false;
  if (storedHash.startsWith(ARGON2_TAG)) {
    const parts = storedHash.split("$").filter(Boolean); // [argon2id, v=1, params, salt, hash]
    if (parts.length !== 5) return false;
    const [, , params, saltB64, hashB64] = parts;
    if (params !== ARGON2_PARAM_SUFFIX) return false;
    /* backpressure gate: under a sustained credential flood the attempt
       fails fast WITHOUT spending another ~300ms of CPU — the flood gets
       failures, the event loop gets to keep serving everything else */
    const now = Date.now();
    if (authWorkSaturated(now)) {
      console.warn(
        JSON.stringify({
          ts: new Date().toISOString(),
          level: "warn",
          event: "ops.auth.backpressure",
          result: "credential attempt shed (sustained KDF flood)",
        })
      );
      return false;
    }
    recordAuthWork(now);
    try {
      const salt = Buffer.from(saltB64, "base64");
      const expected = Buffer.from(hashB64, "base64");
      const actual = Buffer.from(
        argon2id(Buffer.from(password, "utf8"), salt, ARGON2_PARAMS)
      );
      return (
        actual.length === expected.length && timingSafeEqual(actual, expected)
      );
    } catch {
      return false;
    }
  }
  // legacy unsalted SHA-256 (hex) — verified then upgraded by the caller
  const legacy = createHash("sha256").update(password, "utf8").digest("hex");
  if (storedHash.length !== LEGACY_SHA256_LEN) return false;
  const a = Buffer.from(legacy, "hex");
  const b = Buffer.from(storedHash, "hex");
  return a.length === b.length && timingSafeEqual(a, b);
}

/* ------------------------------ field encryption --------------------------- */

const VAULT_MARKER = "enc:v1:";

/**
 * Encrypt a sensitive field (AES-256-GCM, fresh IV every call). Returns the
 * self-describing `enc:v1:iv:tag:ct` envelope; empty input stays empty.
 */
export function encryptField(plaintext: string | null | undefined): string | null | undefined {
  if (plaintext === null || plaintext === undefined) return plaintext;
  if (plaintext === "") return "";
  if (plaintext.startsWith(VAULT_MARKER)) return plaintext; // already sealed
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", AES_KEY, iv);
  const ct = Buffer.concat([
    cipher.update(Buffer.from(plaintext, "utf8")),
    cipher.final(),
  ]);
  const tag = cipher.getAuthTag();
  return `${VAULT_MARKER}${iv.toString("base64")}:${tag.toString("base64")}:${ct.toString("base64")}`;
}

/**
 * Decrypt a vault envelope. Legacy plaintext (no marker) is returned as-is so
 * pre-migration rows keep rendering while the backfill converges the store.
 * A corrupted/tampered envelope (GCM auth failure) degrades to "" rather than
 * throwing — the row stays visible, only the sealed cell is masked.
 */
/** ROUND 120 — decrypt-failure telemetry counter (ops surface only):
 *  a GCM auth failure on a SEALED cell means at-rest tampering or a key
 *  mismatch; silently masking it as "" (the documented compatibility
 *  behavior, kept) hid the signal entirely. Corrupt counts are visible
 *  via vaultCorruptionCount() for /api/admin/ops. */
let vaultCorrupt = 0;
export function vaultCorruptionCount(): number {
  return vaultCorrupt;
}
/** test seam */
export function __resetVaultCorruptionForTests(): void {
  vaultCorrupt = 0;
}

/** The typed decrypt outcome — callers on SECURITY-CRITICAL paths (auth,
 *  identity, financial) can discriminate missing/legacy/corrupt instead
 *  of conflating them with "empty". */
export type DecryptOutcome =
  | { kind: "missing"; value: undefined }
  | { kind: "empty"; value: "" }
  | { kind: "legacy-plaintext"; value: string }
  | { kind: "decrypted"; value: string }
  | { kind: "corrupt"; value: "" };

export function decryptFieldTyped(
  sealed: string | null | undefined
): DecryptOutcome {
  if (sealed === null || sealed === undefined) return { kind: "missing", value: undefined };
  if (sealed === "") return { kind: "empty", value: "" };
  if (!sealed.startsWith(VAULT_MARKER)) return { kind: "legacy-plaintext", value: sealed };
  const parts = sealed.slice(VAULT_MARKER.length).split(":");
  if (parts.length !== 3) {
    vaultCorrupt += 1;
    return { kind: "corrupt", value: "" };
  }
  const [ivB64, tagB64, ctB64] = parts;
  try {
    const decipher = createDecipheriv(
      "aes-256-gcm",
      AES_KEY,
      Buffer.from(ivB64, "base64")
    );
    decipher.setAuthTag(Buffer.from(tagB64, "base64"));
    const pt = Buffer.concat([
      decipher.update(Buffer.from(ctB64, "base64")),
      decipher.final(),
    ]);
    return { kind: "decrypted", value: pt.toString("utf8") };
  } catch {
    /* GCM auth failure / malformed base64 / wrong envelope shape —
     * REDACTED telemetry: the count and a sampled event, never the
     * ciphertext, key material, or the (unavailable) plaintext */
    vaultCorrupt += 1;
    console.warn(
      JSON.stringify({
        ts: new Date().toISOString(),
        level: "warn",
        event: "ops.vault.decrypt-failed",
        result: "sealed cell failed GCM authentication",
      })
    );
    return { kind: "corrupt", value: "" };
  }
}

export function decryptField(sealed: string | null | undefined): string | null | undefined {
  /* null/undefined pass through UNCHANGED (the pre-ROUND-120 contract the
   * callers rely on — typed discrimination lives in decryptFieldTyped) */
  if (sealed === null) return null;
  if (sealed === undefined) return undefined;
  return decryptFieldTyped(sealed).value;
}

/** True when the stored value is a sealed vault envelope. */
export function isSealedField(value: string | null | undefined): boolean {
  return typeof value === "string" && value.startsWith(VAULT_MARKER);
}

/* -------------------------------- blind index ------------------------------ */

/**
 * Keyed HMAC-SHA256 blind index — deterministic per value for WHERE clauses,
 * irreversible without INDEX_KEY. Lower-cased + trimmed so email lookups
 * survive case drift ("A@x.com" === "a@x.com").
 */
export function blindIndex(value: string | null | undefined): string | null | undefined {
  if (value === null || value === undefined) return value;
  const normalized = value.trim().toLowerCase();
  if (normalized === "") return "";
  return createHmac("sha256", INDEX_KEY).update(normalized, "utf8").digest("hex");
}
