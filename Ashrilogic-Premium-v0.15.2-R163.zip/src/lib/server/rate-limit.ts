import { randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import { db, currentProvider } from "@/lib/db";
import { opLog } from "@/lib/server/oplog";

/**
 * Ashrilogic — durable rate limiter.
 *
 * Sliding-window limiter backed by the `RateLimitHit` table so limits
 * survive restarts and are shared across processes. Each check is ONE
 * atomic SQL statement:
 *
 *   INSERT INTO RateLimitHit (id, key, at)
 *   SELECT <id>, <key>, <now>
 *   WHERE (SELECT COUNT(*) FROM RateLimitHit
 *          WHERE key = <key> AND at >= <window-start>) < <limit>
 *
 * On SQLite, serialized writers make the count and the insert a single
 * unit — N concurrent requests can never all observe "under the limit"
 * before any hit lands (the count-then-insert TOCTOU window is gone).
 *
 * ROUND 120 — on PostgreSQL the guarded INSERT…SELECT alone is NOT
 * concurrency-safe: READ COMMITTED's statement snapshot cannot see
 * concurrent UNCOMMITTED inserts, so N pooled connections can each
 * observe COUNT < limit and all insert (over-admission — up to N×limit
 * admissions under a burst; MVCC snapshot isolation guarantees the
 * OPPOSITE of atomicity here). The fix is a per-key ADVISORY TRANSACTION
 * LOCK taken in the SAME transaction as the guarded insert: contenders
 * on one key serialize on the lock (released at COMMIT), so the count
 * and the insert become one critical section per key. Cross-key hash
 * collisions only over-serialize (safe direction). The lock WAIT is
 * bounded by the interactive transaction timeout — a flood on one key
 * queues, and requests that exceed the budget refuse (fail-closed callers)
 * or fall back (fail-open callers) exactly as a store outage would.
 *
 * Refused requests perform no write at all, so flooding a
 * limited key does not grow the table. The table is swept
 * opportunistically to stay bounded.
 *
 * Failure posture: security-sensitive callers (login, password reset,
 * registration) pass `failClosed: true` — if the durable store is
 * unavailable the request is REFUSED instead of silently failing open.
 * Availability-first endpoints keep the process-local fallback.
 *
 * Client IP: the RIGHTMOST x-forwarded-for entry is used — this deployment's
 * gateway overwrites the header with the real client address, and append-mode
 * proxies append the real client last; client-supplied spoofed hops can only
 * ever appear on the LEFT, so they are ignored. The app MUST sit behind such
 * a proxy (see README deployment section) — direct exposure lets callers
 * forge their IP.
 */

export interface RateLimitRule {
  /** max hits per window */
  limit: number;
  /** window length in milliseconds */
  windowMs: number;
}

export interface RateLimitOptions {
  /**
   * When true, a durable-store failure REFUSES the request (fail closed).
   * Use for authentication / credential / security-relevant endpoints.
   */
  failClosed?: boolean;
}

/** opportunistic sweep cadence — keeps the hit table tiny */
const SWEEP_INTERVAL_MS = 10 * 60 * 1000;
/** rows older than this are always dead weight */
const MAX_RETENTION_MS = 24 * 60 * 60 * 1000;

let lastSweep = 0;
let sweepInFlight = false;

async function sweep(now: number): Promise<void> {
  if (sweepInFlight || now - lastSweep < SWEEP_INTERVAL_MS) return;
  sweepInFlight = true;
  lastSweep = now;
  try {
    await db.rateLimitHit.deleteMany({
      where: { at: { lt: new Date(now - MAX_RETENTION_MS) } },
    });
  } catch {
    /* sweep is best-effort — the window query below still prunes logically */
  } finally {
    sweepInFlight = false;
  }
}

/**
 * ROUND 147 — normalize a client address for STORAGE and DISPLAY.
 *
 * The deployment's dual-stack gateway (Caddy on an IPv6 socket) reports IPv4
 * clients in the IPv4-mapped IPv6 form `::ffff:127.0.0.1`; Node's own remote
 * addresses and some proxies do the same. Left raw, one physical client
 * alternates between two identities — two limiter buckets (double the abuse
 * budget) and an ugly `::ffff:` artifact on every session row the security
 * console renders. Normalization collapses the forms to the plain IPv4
 * dotted quad; the IPv6 loopback `::1` collapses to `127.0.0.1` for the same
 * one-identity reason (both spellings are the same machine). IPv6 addresses
 * outside the mapped/loopback forms pass through untouched. Non-IP sentinel
 * values ("local") pass through untouched.
 */
export function normalizeClientIp(value: string): string {
  let ip = value.trim();
  /* bracketed IPv6 literal form some proxies emit: [::ffff:1.2.3.4] */
  if (ip.startsWith("[") && ip.endsWith("]")) ip = ip.slice(1, -1);
  const lower = ip.toLowerCase();
  if (lower === "::1") return "127.0.0.1";
  /* IPv4-mapped IPv6: ::ffff:a.b.c.d (case-insensitive, any leading zeros
   * are not valid input we honor — the canonical form is matched directly) */
  if (lower.startsWith("::ffff:")) {
    const v4 = ip.slice(7);
    /* only collapse when the tail is a real dotted quad (never a bare IPv6
     * suffix like ::ffff:0 — that stays untouched rather than corrupting) */
    if (/^\d{1,3}(\.\d{1,3}){3}$/.test(v4)) return v4;
  }
  return ip;
}

/** Client IP — rightmost XFF hop (proxy-appended real IP; spoofed hops are leftmost). */
export function clientIp(req: Request): string {
  /* ROUND 161 — TRUST_PROXY_MODE hardening (P1-9 fix).
   *
   * Modes:
   * - "always" (default): trust XFF/X-Real-IP (current behavior — requires
   *   a reverse proxy that overwrites XFF in overwrite mode).
   * - "never": ignore all forwarded headers; use the socket peer.
   * - "conditional": trust XFF ONLY when the request arrives from a
   *   trusted edge IP (TRUSTED_EDGE_IPS allowlist) or when Vercel's
   *   own x-vercel-forwarded-for header is present.
   *
   * Default is "always" for backward compatibility — the deployment
   * contract requires Caddy in front. Operators who want the strict
   * posture set TRUST_PROXY_MODE=conditional + TRUSTED_EDGE_IPS.
   */
  const mode = (process.env.TRUST_PROXY_MODE ?? "always").trim().toLowerCase();

  if (mode === "never") {
    /* Direct exposure mode — do NOT trust any forwarded header */
    return "direct";
  }

  const xff = req.headers.get("x-forwarded-for");
  const real = req.headers.get("x-real-ip")?.trim();

  if (mode === "conditional") {
    /* Check if the request came from a trusted edge */
    const trustedIps = (process.env.TRUSTED_EDGE_IPS ?? "")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    const vercelFwd = req.headers.get("x-vercel-forwarded-for");

    /* Trust if: Vercel header present (Vercel is the edge) OR the
     * real-IP matches a trusted edge IP. */
    const isTrusted = !!vercelFwd || (trustedIps.length > 0 && real && trustedIps.includes(real));

    if (!isTrusted) {
      /* Untrusted source — do NOT trust XFF (could be forged) */
      return "untrusted";
    }
  }

  /* mode === "always" or conditional + trusted */
  if (xff) {
    const hops = xff.split(",").map((h) => h.trim()).filter(Boolean);
    if (hops.length > 0) return normalizeClientIp(hops[hops.length - 1]);
  }
  if (real) return normalizeClientIp(real);
  return "local";
}

/* ------------------------------------------------------------------ */
/* ROUND 113 — the shared 429 builder (RFC 6585 Retry-After)           */
/* ------------------------------------------------------------------ */

/**
 * ROUND 120 — 63-bit FNV-1a of the limiter key: the PostgreSQL advisory
 * lock space. Collisions between different keys only OVER-SERIALIZE those
 * keys for one statement pair (the safe direction — never under-admit);
 * the masked result is a non-negative integer < 2^63, exactly
 * representable as a JS Number and a PG bigint. (Hex-string BigInt
 * construction keeps the literal ES2017-target compatible.)
 */
export function advisoryLockKey(key: string): bigint {
  let hash = BigInt("0xcbf29ce484222325"); /* FNV-1a 64-bit offset basis */
  const prime = BigInt("0x100000001b3"); /* FNV-1a 64-bit prime */
  const mask = BigInt("0x7fffffffffffffff"); /* 63-bit mask */
  for (const byte of Buffer.from(key, "utf8")) {
    hash ^= BigInt(byte);
    hash = (hash * prime) & mask;
  }
  return hash;
}

/**
 * Build the canonical rate-limit refusal response.
 *
 * `Retry-After: ceil(windowMs / 1000)` — the DOCUMENTED upper bound: when
 * the window holds `limit` hits, waiting one full window guarantees the
 * oldest hit slides out and the key re-admits (assuming no other traffic
 * on the key — for a flood the header is honest, not exact; the limiter
 * keeps counting). Well-behaved clients (axios-retry, scrappers, payment
 * retries) back off from the header instead of hammering the endpoint;
 * browsers ignore it gracefully (the JSON error message stays).
 *
 * Usage (call sites keep their exact body shape — message, code fields):
 *   return tooManyRequests(LOGIN_RULE, { error: "Too many attempts" });
 */
export function tooManyRequests(
  rule: RateLimitRule,
  body: Record<string, unknown> = { error: "Too many requests — please try again later" }
): NextResponse {
  const response = NextResponse.json(body, { status: 429 });
  response.headers.set("Retry-After", String(Math.ceil(rule.windowMs / 1000)));
  response.headers.set("X-RateLimit-Limit", String(rule.limit));
  response.headers.set("X-RateLimit-Window-Seconds", String(Math.ceil(rule.windowMs / 1000)));
  return response;
}

/**
 * Register a hit; resolves true when the key is over the limit (refuse).
 * Atomic under concurrency (single guarded INSERT), durable across restarts.
 */
export async function rateLimited(
  key: string,
  rule: RateLimitRule,
  opts: RateLimitOptions = {}
): Promise<boolean> {
  const now = Date.now();
  void sweep(now);
  try {
    const since = now - rule.windowMs;
    // ONE statement: insert only while the in-window count is under the
    // limit. Provider branches differ ONLY in the timestamp representation:
    // SQLite stores DateTime as ms-since-epoch integers; PostgreSQL stores
    // real timestamps (Date parameters bind natively through node-postgres).
    let inserted: number;
    if (currentProvider() === "postgresql") {
      /* ROUND 120 — advisory-transaction-lock + guarded INSERT in ONE
       * transaction: the per-key critical section that READ COMMITTED
       * cannot provide on its own (see the module header). Lock waits are
       * bounded by the interactive transaction timeout — a flood queues
       * and over-budget waiters refuse/fall back, never over-admit. */
      inserted = await db.$transaction(
        async (tx) => {
          await tx.$executeRaw`SELECT pg_advisory_xact_lock(${advisoryLockKey(key)})`;
          return tx.$executeRaw`
            INSERT INTO "RateLimitHit" ("id", "key", "at")
            SELECT ${randomUUID()}, ${key}, ${new Date(now)}
            WHERE (
              SELECT COUNT(*) FROM "RateLimitHit"
              WHERE "key" = ${key} AND "at" >= ${new Date(since)}
            ) < ${rule.limit}`;
        },
        { timeout: 10_000 }
      );
    } else {
      inserted = await db.$executeRaw`
        INSERT INTO RateLimitHit (id, key, at)
        SELECT ${randomUUID()}, ${key}, ${now}
        WHERE (
          SELECT COUNT(*) FROM RateLimitHit
          WHERE key = ${key} AND at >= ${since}
        ) < ${rule.limit}`;
    }
    if (inserted !== 1) {
      /* refusal telemetry, SAMPLED 1/8 — a flood must not make the log the
       * new amplification surface; the key (IP or keyed digest) is the
       * actionable operational signal */
      if (Math.random() < 0.125) {
        opLog.warn("rate-limit.refused", { key, result: "over limit" });
      }
    }
    return inserted !== 1;
  } catch {
    if (opts.failClosed) {
      // durable store unavailable on a security endpoint — refuse
      return true;
    }
    // DB unavailability must not lock users out entirely — fail open with a
    // process-local guard so obvious floods still get throttled.
    return localFallback(key, rule, now);
  }
}

/* ------- in-process fallback (also covers pre-push dev schemas) ---------- */

const BUCKETS: Map<string, number[]> = new Map();
const MAX_BUCKETS = 20_000;

function localFallback(key: string, rule: RateLimitRule, now: number): boolean {
  if (BUCKETS.size > MAX_BUCKETS) BUCKETS.clear();
  const stamps = (BUCKETS.get(key) ?? []).filter((ts) => now - ts < rule.windowMs);
  if (stamps.length >= rule.limit) {
    BUCKETS.set(key, stamps);
    return true;
  }
  stamps.push(now);
  BUCKETS.set(key, stamps);
  return false;
}
