import { NextResponse } from "next/server";
/* Prisma.raw removed — we use $queryRawUnsafe with baked-in cast (ROUND 155) */
import { db, currentProvider } from "@/lib/db";
import type { EntitlementDTO } from "@/lib/server/entitlement";

/**
 * ROUND 47 — REAL workspace storage accounting (tamper-proof by design).
 *
 * The number shown to tenants and enforced on writes is computed EXCLUSIVELY
 * on the server from the database's own ground truth:
 *
 *   - byte lengths of every tenant JSON column (SQLite LENGTH(CAST(x AS BLOB))
 *     — true octet size, not character count),
 *   - row counts per table,
 *   - content-addressed image assets actually referenced by this workspace
 *     (parsed from the site content, resolved against ImageAsset.bytes).
 *
 * No client input participates in the computation, and the quota is enforced
 * on every data write (module records, site content, customers, public
 * orders) — a tenant cannot out-grow their plan by any client-side trick.
 */

/** Storage allowance during the free trial (MB) — full-featured window. */
export const TRIAL_STORAGE_MB = 1024;

/** Hard ceiling applied when no quota can be resolved (safety net). */
export const FALLBACK_QUOTA_MB = 512;

export interface UsageBreakdownItem {
  /** i18n key suffix for the label */
  key: "core" | "records" | "site" | "customers" | "orders" | "team" | "activities" | "images";
  bytes: number;
  rows: number | null;
}

export interface WorkspaceUsageDTO {
  /** total JSON payload bytes owned by this workspace */
  dataBytes: number;
  /** image assets referenced by this workspace (bytes on disk) */
  imageBytes: number;
  /** dataBytes + imageBytes */
  totalBytes: number;
  /** allowance in bytes; null = unlimited */
  quotaBytes: number | null;
  /** usage vs quota in percent (null when unlimited) */
  pct: number | null;
  breakdown: UsageBreakdownItem[];
  computedAt: string;
}

interface RawBytes {
  bytes: bigint | number | null;
  rows: bigint | number | null;
}

function num(value: bigint | number | null | undefined): number {
  if (value === null || value === undefined) return 0;
  return typeof value === "bigint" ? Number(value) : value;
}

/** Image references live inside the site contentJson as /api/images/<sha256>. */
const IMAGE_REF = /\/api\/images\/([a-f0-9]{64})/g;

async function referencedImageBytes(instanceId: string): Promise<number> {
  const site = await db.site.findUnique({
    where: { instanceId },
    select: { contentJson: true },
  });
  if (!site?.contentJson) return 0;
  const ids = new Set<string>();
  for (const match of site.contentJson.matchAll(IMAGE_REF)) ids.add(match[1]);
  if (ids.size === 0) return 0;
  const rows = await db.imageAsset.findMany({
    where: { id: { in: [...ids] } },
    select: { bytes: true },
  });
  return rows.reduce((sum, r) => sum + r.bytes, 0);
}

/**
 * Compute the full, real usage snapshot for a workspace. All queries are
 * instanceId-scoped and indexed — cheap enough to call on every write.
 */
export async function computeWorkspaceUsage(
  instanceId: string,
  quotaMb: number | null
): Promise<WorkspaceUsageDTO> {
  /* Byte-length idiom per engine: SQLite LENGTH(CAST(x AS BLOB)) (octets of
   * the UTF-8 text in its integer/blob view) vs PostgreSQL OCTET_LENGTH(x)
   * (native octet size).
   *
   * ROUND 155 FIX — Prisma.raw() inside a $queryRaw tagged template does NOT
   * reliably interpolate the ::text cast on PostgreSQL when the Prisma namespace
   * is from the SQLite client (@prisma/client). The cast is silently stripped,
   * causing «function sum(jsonb) does not exist» on JSON columns.
   *
   * The fix uses $queryRawUnsafe with the SQL string built directly (the cast
   * is baked into the string, not passed through Prisma.raw). The instanceId
   * parameter is passed as a bound $1 parameter (SQL-injection-safe).
   *
   * OCTET_LENGTH on text returns the byte size of the UTF-8 representation,
   * which is exactly what the SQLite BLOB cast measures. */
  const isPg = currentProvider() === "postgresql";
  const len = isPg
    ? (col: string) => `OCTET_LENGTH("${col}"::text)`
    : (col: string) => `LENGTH(CAST("${col}" AS BLOB))`;

  const [core, records, site, customers, orders, team, activities, imageBytes] =
    await Promise.all([
      db.$queryRawUnsafe<RawBytes[]>(
        `SELECT COALESCE(SUM(${len("orgJson")}) + SUM(${len("adminJson")}) + SUM(${len("prefsJson")}) + SUM(${len("modulesJson")}), 0) AS bytes, 1 AS rows FROM "Instance" WHERE "id" = $1`,
        instanceId
      ),
      db.$queryRawUnsafe<RawBytes[]>(
        `SELECT COALESCE(SUM(${len("dataJson")}), 0) AS bytes, COUNT(*) AS rows FROM "ModuleRecord" WHERE "instanceId" = $1 AND "deletedAt" IS NULL`,
        instanceId
      ),
      db.$queryRawUnsafe<RawBytes[]>(
        `SELECT COALESCE(SUM(${len("contentJson")}), 0) AS bytes, COUNT(*) AS rows FROM "Site" WHERE "instanceId" = $1`,
        instanceId
      ),
      db.$queryRawUnsafe<RawBytes[]>(
        `SELECT COALESCE(SUM(${len("name")}) + SUM(${len("email")}) + SUM(${len("phone")}) + SUM(${len("passwordHash")}), 0) AS bytes, COUNT(*) AS rows FROM "SiteCustomer" WHERE "instanceId" = $1 AND "deletedAt" IS NULL`,
        instanceId
      ),
      db.$queryRawUnsafe<RawBytes[]>(
        `SELECT COALESCE(SUM(${len("itemsJson")}), 0) AS bytes, COUNT(*) AS rows FROM "SiteOrder" WHERE "instanceId" = $1 AND "deletedAt" IS NULL`,
        instanceId
      ),
      db.$queryRawUnsafe<RawBytes[]>(
        `SELECT COALESCE(SUM(${len("name")}) + SUM(${len("email")}), 0) AS bytes, COUNT(*) AS rows FROM "TeamMember" WHERE "instanceId" = $1 AND "deletedAt" IS NULL`,
        instanceId
      ),
      db.$queryRawUnsafe<RawBytes[]>(
        `SELECT COALESCE(SUM(${len("metaJson")}), 0) AS bytes, COUNT(*) AS rows FROM "Activity" WHERE "instanceId" = $1`,
        instanceId
      ),
      referencedImageBytes(instanceId),
    ]);

  const first = (rows: RawBytes[]): UsageBreakdownItem["bytes"] => num(rows[0]?.bytes);
  const firstRows = (rows: RawBytes[]): number => num(rows[0]?.rows);

  const breakdown: UsageBreakdownItem[] = [
    { key: "records", bytes: first(records), rows: firstRows(records) },
    { key: "site", bytes: first(site), rows: firstRows(site) },
    { key: "customers", bytes: first(customers), rows: firstRows(customers) },
    { key: "orders", bytes: first(orders), rows: firstRows(orders) },
    { key: "team", bytes: first(team), rows: firstRows(team) },
    { key: "activities", bytes: first(activities), rows: firstRows(activities) },
    { key: "core", bytes: first(core), rows: 1 },
    { key: "images", bytes: imageBytes, rows: imageBytes > 0 ? 1 : 0 },
  ];

  const dataBytes = breakdown.reduce((sum, item) => (item.key === "images" ? sum : sum + item.bytes), 0);
  const totalBytes = dataBytes + imageBytes;
  const quotaBytes = quotaMb === null ? null : quotaMb * 1024 * 1024;

  return {
    dataBytes,
    imageBytes,
    totalBytes,
    quotaBytes,
    pct: quotaBytes === null ? null : Math.min(100, Math.round((totalBytes / quotaBytes) * 100)),
    breakdown,
    computedAt: new Date().toISOString(),
  };
}

/**
 * Resolve the storage allowance (MB) for a workspace from its entitlement +
 * package maxStorageMb. null = unlimited (only for grandfathered rows with
 * neither package nor trial clock).
 */
export function storageQuotaMb(
  entitlement: Pick<EntitlementDTO, "state">,
  packageMaxStorageMb: number | null
): number | null {
  if (entitlement.state === "active") {
    // active = plan assigned OR no clock at all
    return packageMaxStorageMb === null ? null : Math.max(0, packageMaxStorageMb);
  }
  // trial / locked without a plan → the trial allowance applies
  return packageMaxStorageMb === null ? TRIAL_STORAGE_MB : Math.max(packageMaxStorageMb, TRIAL_STORAGE_MB);
}

/**
 * WRITE-TIME QUOTA GATE. Call before persisting tenant data. `incomingBytes`
 * is the size of the NEW payload (the computation already includes existing
 * rows). Returns a 403 response when the write would exceed the allowance,
 * null when it may proceed.
 */
export async function storageQuotaResponse(
  instanceId: string,
  incomingBytes: number,
  opts: { replaceBytes?: number } = {}
): Promise<NextResponse | null> {
  const instance = await db.instance.findUnique({
    where: { id: instanceId, deletedAt: null },
    select: {
      packageId: true,
      trialEndsAt: true,
      planActivatedAt: true,
      planCycle: true,
      /* ROUND 79 — the paid-term expiry joins the entitlement inputs so a
       * plan-expired workspace resolves state "locked" here too. */
      planExpiresAt: true,
      package: { select: { maxStorageMb: true } },
    },
  });
  /* ROUND 87 — a trashed (soft-deleted) workspace reads as unknown (no
   * quota problem; its writes are refused upstream anyway). */
  if (!instance) return null; // unknown instance — not a quota problem

  const { computeEntitlement } = await import("@/lib/server/entitlement");
  const entitlement = computeEntitlement(instance);
  const quotaMb = storageQuotaMb(entitlement, instance.package?.maxStorageMb ?? null);
  if (quotaMb === null || quotaMb <= 0) return null; // unlimited

  const usage = await computeWorkspaceUsage(instanceId, quotaMb);
  const projected = usage.totalBytes - (opts.replaceBytes ?? 0) + Math.max(0, incomingBytes);
  if (projected <= quotaMb * 1024 * 1024) return null;

  return NextResponse.json(
    {
      error: `Storage quota exceeded — your plan allows ${quotaMb} MB. Free up space or upgrade your plan`,
      code: "STORAGE_QUOTA_EXCEEDED",
    },
    { status: 403 }
  );
}
