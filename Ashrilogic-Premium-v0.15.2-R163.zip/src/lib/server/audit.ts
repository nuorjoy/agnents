import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { computeChainHash } from "@/lib/server/audit-chain";
import { maybeRunScheduledBackup } from "@/lib/server/platform-backup";

/**
 * Ashrilogic — audit trail writer.
 *
 * Two distinct trails share one table:
 *
 *  - BUSINESS ACTIVITY logging (package edits, ticket triage, module
 *    records, newsletter work) — gated by the admin-visible `auditLog`
 *    platform setting. Turning it off stops routine noise, nothing more.
 *
 *  - SECURITY AUDIT logging (logins and failures, password changes, account
 *    creation/deletion/disable, role changes, security settings changes,
 *    session invalidation, destructive operations) — ALWAYS written. No
 *    admin setting can silently disable, thin out or shorten the security
 *    trail: those rows are exempt from the `auditLog` toggle AND from any
 *    retention window shorter than 90 days.
 *
 * Writes are fire-and-forget with an error swallow: an audit failure must
 * never fail the user's request (the console surfaces it instead).
 *
 * PII: audit rows carry IDs and MASKED identifiers, never raw emails/phones
 * (see maskEmail). All free-text fields are control-character-sanitized and
 * length-capped to block log-injection via attacker-controlled strings.
 */

export const AUDIT_ACTOR_TYPES = ["admin", "instance", "public", "system"] as const;
export type AuditActorType = (typeof AUDIT_ACTOR_TYPES)[number];

export const AUDIT_ACTIONS = [
  "admin.login",
  "admin.loginFailed",
  /* ROUND 158 — IP banlist enforcement on the Super Admin login route. */
  "admin.loginBlocked",
  "admin.logout",
  "admin.create",
  "admin.update",
  "admin.delete",
  /* ROUND 136 — Super-Admin strict instance connection: the per-instance
   * ops telemetry drilldown (read probe, business trail) + the console-side
   * "revoke every workspace session" lever (session invalidation — a
   * SECURITY action, see SECURITY_ACTIONS). */
  "admin.instanceOps",
  "admin.instanceSessionsRevoke",
  "package.create",
  "package.update",
  "package.delete",
  "settings.update",
  /* ROUND 137 — the SPLIT security-policy surface: the platform 2FA
   * toggle (and future recovery/security controls) mutates through its
   * own dedicated, super-only, strict-audit route — a security-control
   * change must never hide inside a generic settings.update row. */
  "security-policy.update",
  /* ROUND 158 — the super-admin console's IP banlist mutation surface. */
  "security.ipban",
  /* ROUND 89 — the platform notification engine's delivery trail (weekly
   * digest sends, both scheduler- and console-triggered). */
  "notification.weeklySent",
  "ticket.create",
  "ticket.update",
  "ticket.delete",
  "ticket.bulkUpdate",
  "ticket.bulkDelete",
  /* ROUND 75 — staff-assisted email confirmation + verification-email
   * re-dispatch (tenant-side customer-service writes, not security). */
  "siteCustomer.verify",
  "siteCustomer.verifyResend",
  "siteCustomer.moderate",
  "siteCustomer.delete",
  "customer.login",
  "customer.loginFailed",
  "customer.loginBlocked",
  "customer.logout",
  "customer.register",
  "customer.verify",
  "customer.verificationResend",
  "instance.create",
  "instance.update",
  "instance.delete",
  "instance.siteUpdate",
  "instance.siteLaunch",
  "instance.siteTranslate",
  "instance.login",
  "instance.loginFailed",
  /* ROUND 158 — IP banlist enforcement on the tenant login route. */
  "instance.loginBlocked",
  "instance.logout",
  "instance.password",
  "instance.memberAdd",
  "instance.memberUpdate",
  "instance.memberRemove",
  /* ROUND 78 — strict RBAC: a platform admin was refused a tenant-surface
   * operation because their tier lacks the required permission (the guard
   * in requireInstanceAccess logs this on every PERMISSION_DENIED). */
  "instance.permissionDenied",
  "instance.ticketCreate",
  "instance.upgradeRequest",
  "instance.resetDemo",
  /* ROUND 81 — platform governance: ban / unban of a subscriber workspace
   * (strictness class: a ban cuts EVERY surface incl. login — always
   * audited; unban restores access). */
  "instance.ban",
  "instance.unban",
  /* ROUND 41 — AI insights engine (workspace deep-analysis runs + the
   * Super-Admin AI/API control panel). Registered here so the strictly-typed
   * AuditEntry accepts them (same registry pattern as instance.siteTranslate). */
  "instance.aiAnalysis",
  "admin.aiSettings",
  /* ROUND 41 (task 4) — workspace backup/restore engine. Registered here so
   * the strictly-typed AuditEntry accepts them; instance.restore is a
   * SECURITY action (destructive whole-tenant write) — see SECURITY_ACTIONS. */
  "instance.backup",
  "instance.restore",
  /* ROUND 97 — tenant backup create-from-backup DR import (offline CLI:
   * scripts/import-backup.ts). Registered so the strictly-typed AuditEntry
   * accepts it; a SECURITY action — see SECURITY_ACTIONS. */
  "instance.import",
  /* EMAIL SYSTEM — the mail/SMTP control-panel write (transport config +
   * sealed credentials: a change alters every outbound communication path,
   * so it rides the security trail unconditionally) and the admin test
   * round-trip (operational probe, not a secret toucher — business trail). */
  "mail.settings",
  "mail.testSend",
  "newsletter.add",
  "newsletter.update",
  "newsletter.emails",
  "campaign.create",
  "campaign.update",
  "campaign.send",
  "campaign.delete",
  /* CONTENT SYSTEM — the official blog + trusted-sector showcase console
   * writes (Super-Admin composed content: posts lifecycle and the curated
   * partner strip. Business trail — content visibility, not credentials). */
  "blog.create",
  "blog.update",
  "blog.delete",
  /* ROUND 129 — inline article image uploads (rich editor): asset trail. */
  "blog.image-upload",
  "partner.create",
  "partner.update",
  "partner.delete",
  "moduleRecord.create",
  "moduleRecord.update",
  "moduleRecord.delete",
  /* ROUND 140 — product media uploads (gallery photos + video clips minted
   * by the store media route; asset trail with the resulting ref). */
  "store.media-upload",
  /* ROUND 133 — نظام الورديات (shift system): open/close the cashier shift
   * (strict business gate — every business mutation refuses while closed and
   * sign-out refuses while open) + the secret-code change (security trail:
   * KDF-verified) + the loyalty auto-sync engine runs. */
  "instance.shiftOpen",
  "instance.shiftClose",
  "instance.shiftCode",
  "instance.loyaltySync",
  /* ROUND 134 — deep tenant-identity uniqueness: a provisioning attempt was
   * refused because the typed email/phone was ALREADY used (deep scan:
   * trashed + demo rows included). Security trail; masked PII only. */
  "instance.duplicateBlock",
  /* ROUND 47 — plan-purchase payment orders + subscription activation.
   * instance.planOrderCreate / instance.planOrderCancel are tenant-side
   * writes on the billing flow; instance.planActivate is the platform-side
   * confirmation that assigns a paid plan (and restores a trial-locked
   * workspace) — a SECURITY action (entitlement-changing). */
  "instance.planOrderCreate",
  "instance.planOrderCancel",
  "instance.planActivate",
  /* ROUND 141 — متجر الإضافات: add-on purchase orders + the platform-side
   * activation that force-ONs the ordered features (entitlement-changing —
   * a SECURITY action like instance.planActivate). */
  "instance.addonOrderCreate",
  "instance.addonOrderCancel",
  "instance.addonActivate",
  /* ROUND 141 (wallet) — محفظة Ashrilogic: the top-up request lifecycle
   * (tenant-side), the platform-side confirmation that credits the wallet
   * (a MONEY-MOVING action — audit row mandatory), the console adjustment
   * lever, and the instant wallet checkout's debit trail. */
  "instance.walletTopupCreate",
  "instance.walletTopupCancel",
  "wallet.topupConfirm",
  "wallet.adjust",
  /* ROUND 144 — inter-wallet transfers: a MONEY-MOVING action between two
   * tenant wallets; audited unconditionally (both the failed-PIN attempts
   * and the executed receipts). */
  "instance.walletTransfer",
  /* ROUND 50 — storefront promotions (coupon lifecycle) + order tracking.
   * Registered here so the strictly-typed AuditEntry accepts them; they are
   * tenant-side writes on the e-commerce surface (not security actions). */
  "instance.couponCreate",
  "instance.couponUpdate",
  "instance.couponDelete",
  /* ROUND 74 — the owner's reply/status/priority triage on a public website
   * inquiry (tenant-side customer-service write, not a security action). */
  "instance.inquiryTriage",
  /* ROUND 113 — order-event webhook endpoint lifecycle (tenant-side
   * integration config writes; rotation is a credential-adjacent action
   * logged with the same target-label discipline as other secrets). */
  "instance.webhookCreate",
  "instance.webhookUpdate",
  "instance.webhookRotate",
  "instance.webhookDelete",
  /* ROUND 116 — manual redelivery of a terminal (failed/exhausted) webhook
   * delivery: a transport-level replay of the tenant's own order event
   * (payload verbatim, CURRENT secret). Tenant-side integration write on
   * the business trail — the endpoint's own lifecycle actions above carry
   * the credential-adjacent trail. */
  "instance.webhookRedeliver",
  /* ROUND 77 — the Super Admin's twin triage, fired from the sites-customers
   * sheet (platform-side customer-service write, not a security action). */
  "admin.siteInquiryTriage",
  /* ROUND 117 — the platform legal documents console (privacy policy /
   * terms of use): every publish is versioned + attributed; a reset removes
   * the console draft and returns the locale to the code default. */
  "admin.legalDocUpdate",
  "admin.legalDocReset",
  /* ROUND 117 — the admin storage console's manual GC run (unreferenced
   * assets + orphan files): a destructive storage operation, always
   * audited with the reclaim stats. */
  "admin.storageGc",
  /* ROUND 118 — the audit-chain HEAD ANCHOR (external trust point,
   * see audit-anchor.ts): the console's manual "anchor now" pins the
   * chain head into the MAC-sealed external file (business trail — the
   * anchor CREATES tamper evidence; system.auditAnchor below is the
   * safety net's sealed ALERT). */
  "admin.auditAnchor",
  "system.auditAnchor",
  /* ROUND 96 — ASHRILOGIC_DATA_KEY rotation re-seal (see
   * scripts/re-seal-secrets.ts): a SECURITY action — every envelope, blind
   * index and the audit chain itself is re-keyed; the trail must survive. */
  "system.reseal",
  /* ROUND 105 — image-store orphan garbage collection (see
   * scripts/gc-images.ts): deletes unreferenced content-addressed files —
   * a destructive storage operation, always audited. */
  "system.gc",
  /* ROUND 87 (trash) — the soft-delete / restore / purge lifecycle. Every
   * purge is a PERMANENT destructive write and every restore reverses one,
   * so both ride the SECURITY trail; soft-delete keeps its entity-specific
   * business action above (instance.delete, moduleRecord.delete, …) with
   * meta.soft = true. instance.selfDelete / selfDisable / selfEnable are
   * the owner's own account lifecycle; siteCustomer.selfDelete is the
   * customer's permanent self-service deletion (GDPR-style, no trash). */
  "trash.restore",
  "trash.purge",
  "trash.purgeExpired",
  "instance.orderDelete",
  "instance.reviewDelete",
  "instance.selfDelete",
  "instance.selfDisable",
  "instance.selfEnable",
  "siteCustomer.selfDelete",
] as const;
export type AuditAction = (typeof AUDIT_ACTIONS)[number];

/**
 * Actions that belong to the SECURITY trail — written unconditionally and
 * protected by the retention floor. Authentication events, account lifecycle
 * (create/delete/disable/role), credential changes, security settings and
 * destructive operations.
 */
const SECURITY_ACTIONS = new Set<string>([
  "admin.login",
  "admin.loginFailed",
  "admin.logout",
  "admin.create",
  "admin.update",
  "admin.delete",
  /* ROUND 136 — the Super-Admin session-revocation lever kills every live
   * workspace token for a tenant: unconditional trail, retention floor. */
  "admin.instanceSessionsRevoke",
  "settings.update",
  /* ROUND 137 — the 2FA-policy flip is a platform-wide security control:
   * unconditional trail + retention floor. */
  "security-policy.update",
  /* EMAIL SYSTEM — changing the outbound mail transport (host, credentials,
   * sender identity) changes where EVERY platform email goes: credential-
   * class security settings — unconditional trail + retention floor. */
  "mail.settings",
  "siteCustomer.moderate",
  "siteCustomer.delete",
  "customer.login",
  "customer.loginFailed",
  "customer.loginBlocked",
  "customer.logout",
  "customer.register",
  "customer.verify",
  "instance.create",
  "instance.delete",
  "instance.login",
  "instance.loginFailed",
  "instance.logout",
  "instance.password",
  "instance.resetDemo",
  /* ROUND 41 (task 4) — a restore rewrites the whole tenant transactionally;
   * it is a destructive operation, so its audit rows are unconditional
   * (no admin toggle can disable or thin them out). */
  "instance.restore",
  /* ROUND 97 — a DR import CREATES a whole tenant from a backup file (new
   * owner credentials + the restore engine's full-tenant write) — a
   * platform-side security operation, always audited unconditionally. */
  "instance.import",
  /* ROUND 47 — plan activation changes entitlement (unlocks a workspace +
   * its public site): always audited, retention floor applies. */
  "instance.planActivate",
  /* ROUND 141 — the add-on activation force-ONs features past the plan tier
   * (entitlement-changing) and the wallet top-up confirmation MOVES MONEY
   * onto a tenant balance: both always audited, retention floor applies. */
  "instance.addonActivate",
  "wallet.topupConfirm",
  "wallet.adjust",
  /* ROUND 96 — ASHRILOGIC_DATA_KEY rotation re-seal run (all vault
   * envelopes + blind indexes + the audit chain itself re-keyed); a
   * security-critical platform operation — always audited. */
  "system.reseal",
  /* ROUND 105 — image-store orphan GC execution (unreferenced content-
   * addressed files deleted from storage/images); a destructive storage
   * operation — always audited, retention floor applies. */
  "system.gc",
  /* ROUND 118 — the audit-anchor safety net's sealed ALERT: the hourly
   * verification found the live chain TRUNCATED or TAMPERED against the
   * external anchor (an ongoing integrity incident — unconditional
   * security trail, retention floor applies). */
  "system.auditAnchor",
  /* ROUND 87 (trash) — purges are the only permanent data destruction, and
   * restores reverse a deletion; both are unconditional. The owner's own
   * account lifecycle (self-delete / disable / enable) and the customer's
   * permanent self-deletion are account-lifecycle security events too. */
  "trash.restore",
  "trash.purge",
  "trash.purgeExpired",
  "instance.selfDelete",
  "instance.selfDisable",
  "instance.selfEnable",
  "siteCustomer.selfDelete",
]);

/* ------------------------------------------------------------------ */
/* ROUND 136 — per-instance audit filtering                             */
/* ------------------------------------------------------------------ */

/**
 * The AuditLog table has NO dedicated instance relation column (verified
 * against prisma/schema.prisma — actor/actorType/metaJson only), so an
 * instance filter is DERIVED from the two linkage signals rows already
 * carry:
 *
 *  1. WORKSPACE-ACTOR rows — every row a tenant's own workspace writes
 *     carries actorType "instance" + actorId = the instance id (logins,
 *     password rotations, updates, shifts, module writes, …). This covers
 *     the entire historical trail with zero migration.
 *  2. PLATFORM-ACTOR rows stamped with the ROUND 136 meta convention
 *     meta.instance = <instanceId> — the metaJson string contains
 *     `"instance":"<id>"` (the exact JSON fragment, so a similar key like
 *     "instanceId" can never false-match). The Super-Admin levers of this
 *     round (admin.instanceOps / admin.instanceSessionsRevoke) stamp it.
 *
 * The clause is exported so /api/admin/audit?instanceId= and the per-instance
 * ops drilldown compute the SAME linkage — one law, two surfaces.
 */
export function instanceAuditWhere(instanceId: string): Prisma.AuditLogWhereInput {
  return {
    OR: [
      { actorType: "instance", actorId: instanceId },
      { metaJson: { contains: `"instance":"${instanceId}"` } },
    ],
  };
}

/** Security rows survive at least this long regardless of the retention setting. */
const SECURITY_RETENTION_FLOOR_DAYS = 90;

export interface AuditEntry {
  actorType: AuditActorType;
  actorId?: string;
  actorName: string;
  action: AuditAction;
  targetLabel?: string;
  meta?: Record<string, string>;
}

/* ------------------------- PII-safe text helpers --------------------------- */

/** Strip control characters (log-injection) and cap length. */
function sanitizeAuditText(value: string, max: number): string {
  return value
    .replace(/[\u0000-\u001f\u007f-\u009f]/g, " ")
    .trim()
    .slice(0, max);
}

/**
 * Mask an email for audit storage: keeps at most the first character of the
 * local part plus the domain — enough for correlation, useless for PII
 * harvesting. ("sarah@elite-hospital.com" → "s***@elite-hospital.com")
 */
export function maskEmail(email: string | null | undefined): string {
  if (!email) return "";
  const sanitized = String(email).replace(/[\u0000-\u001f\u007f-\u009f]/g, "").trim();
  const at = sanitized.lastIndexOf("@");
  if (at <= 0 || at === sanitized.length - 1) {
    return "***";
  }
  const local = sanitized.slice(0, at);
  const domain = sanitized.slice(at + 1);
  const head = local.slice(0, 1).toLowerCase();
  return `${head.length ? head + "***" : "***"}@${domain}`.slice(0, 120);
}

/* ------------------- settings cache + retention sweep --------------------- */

const SETTINGS_TTL_MS = 60 * 1000; // re-read at most once a minute
const PRUNE_INTERVAL_MS = 10 * 60 * 1000; // retention sweep cadence

let cached = { auditLog: true, dataRetention: 90, readAt: 0 };
let lastPrune = 0;
let pruneInFlight = false;

async function refreshSettings(): Promise<void> {
  const now = Date.now();
  if (now - cached.readAt < SETTINGS_TTL_MS) return;
  try {
    const row = await db.platformSetting.findUnique({
      where: { id: "global" },
      select: { auditLog: true, dataRetention: true },
    });
    cached = {
      auditLog: row?.auditLog ?? true,
      dataRetention: row?.dataRetention ?? 90,
      readAt: now,
    };
  } catch {
    cached.readAt = now; // fail-open: keep auditing with last-known values
  }
}

/** Business rows obey the retention setting; security rows keep the floor.
 *
 * DELETES ARE CHUNKED (ROUND 65 reliability): the whole data model leans
 * on interactive transactions through Prisma's single pooled SQLite
 * connection (connection_limit=1) — one unbounded deleteMany on a large
 * retention window monopolizes that connection long enough for live
 * traffic's CAS transactions to hit the 5s socket timeout (measured:
 * P1008 under admin-console load). Each retention statement therefore
 * deletes in bounded ID batches, yielding the connection between chunks
 * so concurrent orders/sessions/audit writes interleave instead of
 * queueing behind a full-table sweep. */
async function pruneIfNeeded(): Promise<void> {
  const now = Date.now();
  if (pruneInFlight || now - lastPrune < PRUNE_INTERVAL_MS) return;
  pruneInFlight = true;
  lastPrune = now;
  try {
    if (cached.dataRetention > 0) {
      const businessCutoff = new Date(now - cached.dataRetention * 86_400_000);
      const securityCutoff = new Date(
        now - Math.max(cached.dataRetention, SECURITY_RETENTION_FLOOR_DAYS) * 86_400_000
      );
      /* CHAINED rows are pruned TOO (ROUND 96 — anchored pruning): the
       * audit-chain anchor (AuditChainAnchor singleton) records the hash of
       * the LAST row pruned below the retention window, so verification
       * starts from that trust boundary — deleting the oldest links no
       * longer orphans the successors. The anchor is written BEFORE the
       * deletes (a crash between leaves the anchor pointing at a
       * still-present row — harmless; the reverse order would break
       * verification). The unchained (NULL-hash) sweeps below stay
       * exactly as they were. */
      const hasOldChainedBusiness = await db.auditLog.findFirst({
        where: {
          createdAt: { lt: businessCutoff },
          action: { notIn: [...SECURITY_ACTIONS] },
          chainHash: { not: null },
        },
        select: { id: true },
      });
      const hasOldChainedSecurity = await db.auditLog.findFirst({
        where: {
          createdAt: { lt: securityCutoff },
          action: { in: [...SECURITY_ACTIONS] },
          chainHash: { not: null },
        },
        select: { id: true },
      });
      if (hasOldChainedBusiness || hasOldChainedSecurity) {
        /* the OLDEST RETAINED chained row — matched by NEITHER delete
         * predicate below. Its prevChainHash is the hash of the last row
         * the sweep will remove: the trust boundary. */
        const oldestRetained = await db.auditLog.findFirst({
          where: {
            chainHash: { not: null },
            NOT: [
              { action: { notIn: [...SECURITY_ACTIONS] }, createdAt: { lt: businessCutoff } },
              { action: { in: [...SECURITY_ACTIONS] }, createdAt: { lt: securityCutoff } },
            ],
          },
          orderBy: [{ createdAt: "asc" }, { id: "asc" }],
          select: { id: true, prevChainHash: true },
        });
        /* prevChainHash null = the retained chain starts at genesis —
         * nothing older exists, so the old-chained findings above must be
         * chain/time-order artifacts; skip chained pruning entirely
         * (retain beats corrupt). */
        if (oldestRetained && oldestRetained.prevChainHash !== null) {
          await db.auditChainAnchor.upsert({
            where: { id: "global" },
            create: {
              id: "global",
              anchorPrevHash: oldestRetained.prevChainHash,
              anchorRowId: oldestRetained.id,
            },
            update: {
              anchorPrevHash: oldestRetained.prevChainHash,
              anchorRowId: oldestRetained.id,
            },
          });
          // business chained rows: honor the configured window (CHUNKED)
          await deleteChunked({
            createdAt: { lt: businessCutoff },
            action: { notIn: [...SECURITY_ACTIONS] },
            chainHash: { not: null },
          });
          // security chained rows: never shorter than the floor (CHUNKED)
          await deleteChunked({
            createdAt: { lt: securityCutoff },
            action: { in: [...SECURITY_ACTIONS] },
            chainHash: { not: null },
          });
        }
      }
      /* unchained (legacy / fallback) rows — the previous behavior,
       * unchanged: no chain links are affected by removing them. */
      // business rows: honor the configured window (CHUNKED)
      await deleteChunked({
        createdAt: { lt: businessCutoff },
        action: { notIn: [...SECURITY_ACTIONS] },
        chainHash: null,
      });
      // security rows: never shorter than the floor (CHUNKED)
      await deleteChunked({
        createdAt: { lt: securityCutoff },
        action: { in: [...SECURITY_ACTIONS] },
        chainHash: null,
      });
      await db.activity.deleteMany({ where: { createdAt: { lt: businessCutoff } } });
    }
  } catch (error) {
    console.error("retention prune failed:", error);
  } finally {
    pruneInFlight = false;
  }
}

/* ---------------------- chunked retention deletes ---------------------- */

/** Delete rows matching `where` in bounded ID batches. Each batch is one
 *  short statement; the connection is yielded between batches so live
 *  CAS transactions interleave with the sweep instead of queueing behind
 *  a single full-window delete (the P1008 socket-timeout root cause). */
const PRUNE_CHUNK = 500;

async function deleteChunked(
  where: Prisma.AuditLogWhereInput
): Promise<number> {
  let deleted = 0;
  for (;;) {
    /* batch = oldest PRUNE_CHUNK matching ids (deterministic order) */
    const ids = await db.auditLog.findMany({
      where,
      orderBy: [{ createdAt: "asc" }, { id: "asc" }],
      take: PRUNE_CHUNK,
      select: { id: true },
    });
    if (ids.length === 0) return deleted;
    const removed = await db.auditLog.deleteMany({
      where: { id: { in: ids.map((r) => r.id) } },
    });
    deleted += removed.count;
    if (ids.length < PRUNE_CHUNK) return deleted;
  }
}

/** The sanitized, persistable row shape logAudit builds before chaining. */
interface AuditRowData {
  actorType: string;
  actorId: string | null;
  actorName: string;
  action: string;
  targetLabel: string | null;
  metaJson: string | null;
  createdAt: Date;
}

/**
 * Append one hash-chained row (round 38): read the chain HEAD inside the
 * same transaction that inserts, so each row's prevChainHash is the hash of
 * the previously CHAINED row. A rare concurrent-write race can still fork
 * (two rows referencing the same prev) — the verifier reports forks; and if
 * the transactional path itself fails, the event is STILL recorded with
 * NULL hashes (a visible gap beats a silently missing security event).
 */
async function writeChainedRow(data: AuditRowData): Promise<void> {
  try {
    await db.$transaction(async (tx) => {
      const head = await tx.auditLog.findFirst({
        where: { chainHash: { not: null } },
        orderBy: { createdAt: "desc" },
        select: { chainHash: true },
      });
      const prevChainHash = head?.chainHash ?? null;
      const chainHash = computeChainHash({
        prevChainHash,
        actorType: data.actorType,
        actorId: data.actorId,
        actorName: data.actorName,
        action: data.action,
        targetLabel: data.targetLabel,
        metaJson: data.metaJson,
        createdAtISO: data.createdAt.toISOString(),
      });
      await tx.auditLog.create({
        data: { ...data, prevChainHash, chainHash },
      });
    });
  } catch (error) {
    console.error("chained audit write failed — recording unchained:", error instanceof Error ? error.message : error);
    try {
      await db.auditLog.create({ data: { ...data, prevChainHash: null, chainHash: null } });
    } catch (fallbackError) {
      console.error("audit write failed:", fallbackError instanceof Error ? fallbackError.message : fallbackError);
    }
  }
}

export async function logAudit(entry: AuditEntry): Promise<void> {
  try {
    const isSecurityAction = SECURITY_ACTIONS.has(entry.action);
    await refreshSettings();
    // business logging honors the admin toggle; the security trail is
    // unconditional — no setting can switch it off
    if (!isSecurityAction && !cached.auditLog) return;
    void pruneIfNeeded();
    /* every business mutation nudges the opportunistic backup scheduler
       (one timestamp check per wakeup window — see platform-backup.ts) */
    void maybeRunScheduledBackup();
    await writeChainedRow({
      actorType: entry.actorType,
      actorId: entry.actorId ?? null,
      actorName: sanitizeAuditText(entry.actorName, 120),
      action: entry.action,
      targetLabel: entry.targetLabel ? sanitizeAuditText(entry.targetLabel, 160) : null,
      metaJson: entry.meta
        ? JSON.stringify(
            Object.fromEntries(
              Object.entries(entry.meta).map(([k, v]) => [k, sanitizeAuditText(v, 200)])
            )
          )
        : null,
      /* explicit timestamp so the chain hash covers the exact stored value */
      createdAt: new Date(),
    });
  } catch (error) {
    console.error("audit write failed:", error);
  }
}
