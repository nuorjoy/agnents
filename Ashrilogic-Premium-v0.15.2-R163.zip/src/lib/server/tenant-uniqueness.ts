/**
 * Ashrilogic — deep tenant identity uniqueness engine (ROUND 134-E).
 *
 * The owner's directive: «قم بالتحقق بطريقة عميقة جداً من أي مستأجر جديد
 * يريد استخدام النظام انه (البريد الإلكتروني، رقم الهاتف) غير مستخدم
 * سابقاً» — before ANY new tenant is provisioned, verify DEEPLY that both
 * the login email and the org phone number were never used before.
 *
 * "Deep" means the scan ignores the filters every listing surface applies:
 *   - NO deletedAt filter — a soft-deleted (trashed) workspace still OWNS
 *     its email and phone; the identity cannot be re-registered while the
 *     row awaits purge/restore.
 *   - NO demo filter — platform showcase rows are real rows holding real
 *     contact identities; a signup colliding with a demo row is refused
 *     exactly like any other.
 *
 * Matching strategy per field:
 *   - EMAIL: the canonical path is the keyed HMAC blind index
 *     (adminEmailIndex === blindIndex(normalizeEmail(candidate))) — no
 *     decryption, no PII in memory. Legacy rows with a NULL/empty index
 *     fall back to decrypting adminJson (readAdminEmail) and comparing
 *     normalized emails; that fallback is BOUNDED (LEGACY_SCAN_CAP) so a
 *     pathological legacy store cannot turn a signup into a full decrypt
 *     sweep. The live database has zero null-index rows (backfilled) —
 *     the fallback exists for restored/converging stores.
 *   - PHONE: org phones live inside the orgJson column (no index exists),
 *     so every row's org.phone is parsed (tolerating malformed JSON) and
 *     compared through normalizePhoneDeep — the strict comparison key
 *     (digits only, Arabic-Indic digits folded to Western, one leading
 *     international prefix "00" or "+" dropped, LAST 9 DIGITS when long
 *     enough) so "+966 50 123 4567", "00966501234567", "٠٥٠١٢٣٤٥٦٧"-style
 *     and "+966-501-234567" all collide with each other exactly like a
 *     human would expect.
 *
 * Efficiency: ONE findMany with a slim select + a single in-memory pass —
 * instance counts are ≤ ~500 rows (LIST_CAP), and the scan runs only on
 * provisioning / availability probes which are already rate-limited.
 *
 * PII discipline: the returned collision values are instance IDs (for the
 * audit trail only — NEVER sent to the client), and this module never
 * embeds a raw email or phone in a thrown error.
 */
import { blindIndex } from "@/lib/server/crypto-vault";
import { normalizeEmail, readAdminEmail } from "@/lib/server/instance-mapper";

/* ------------------------------------------------------------------ */
/* machine codes (wire contract with the wizard's error mapping)       */
/* ------------------------------------------------------------------ */

/** 409 machine code — the signup email is already registered. */
export const TENANT_EMAIL_USED = "EMAIL_ALREADY_USED";
/** 409 machine code — the signup phone is already registered. */
export const TENANT_PHONE_USED = "PHONE_ALREADY_USED";

/* ------------------------------------------------------------------ */
/* phone normalization (pure — exported as the test target)           */
/* ------------------------------------------------------------------ */

/**
 * Fold Arabic-Indic (٠-٩) and Eastern Arabic-Indic (۰-۹) digits to their
 * Western counterparts — a toWesternDigits-style transform for input that
 * arrived through an Arabic keyboard layout.
 */
function toWesternDigits(text: string): string {
  return text.replace(/[٠-٩۰-۹]/g, (ch) => {
    const code = ch.charCodeAt(0);
    /* ٠ = U+0660 … ٩ = U+0669; ۰ = U+06F0 … ۹ = U+06F9 */
    const base = code >= 0x0660 && code <= 0x0669 ? 0x0660 : 0x06f0;
    return String(code - base);
  });
}

/**
 * Deep phone comparison key.
 *
 * 1. Arabic-Indic digits → Western digits
 * 2. strip whitespace + punctuation (dashes, dots, slashes, parentheses…)
 * 3. strip ONE leading international prefix ("+" already vanished with the
 *    punctuation strip; a leading "00" pair is dropped here)
 * 4. comparison key = the LAST 9 DIGITS when at least 9 digits remain,
 *    else the whole digit string (short/hotline numbers compare verbatim)
 *
 * Pure function, never throws, never returns PII beyond digits.
 */
export function normalizePhoneDeep(raw: string): string {
  if (typeof raw !== "string" || raw === "") return "";
  const digits = toWesternDigits(raw).replace(/\D/g, "");
  if (digits === "") return "";
  let national = digits;
  if (national.startsWith("00")) national = national.slice(2);
  return national.length >= 9 ? national.slice(-9) : national;
}

/* ------------------------------------------------------------------ */
/* deep check engine                                                   */
/* ------------------------------------------------------------------ */

/** Candidate identity to verify (either side may be omitted). */
export interface TenantIdentityInput {
  email?: string;
  phone?: string;
}

/** Collision report — instance IDs for the AUDIT TRAIL only (never client-facing). */
export interface TenantIdentityCollisions {
  /** instance id already owning the email, or null when free */
  emailUsedBy: string | null;
  /** instance id already owning the phone, or null when free */
  phoneUsedBy: string | null;
}

/** Bounded legacy fallback: NULL-adminEmailIndex rows decrypted per scan. */
const LEGACY_SCAN_CAP = 500;

/** org.phone from a stored orgJson column — lenient, malformed JSON tolerated. */
function orgPhoneOf(orgJson: string | null): string {
  if (!orgJson) return "";
  try {
    const parsed = JSON.parse(orgJson) as { phone?: unknown };
    return typeof parsed.phone === "string" ? parsed.phone : "";
  } catch {
    return "";
  }
}

/**
 * Deep uniqueness check across EVERY Instance row (live + soft-deleted +
 * demo). One slim findMany + one in-memory pass; the e-mail side prefers
 * the blind index (no decryption) and only falls back to decrypting the
 * sealed adminJson for legacy NULL-index rows (bounded by LEGACY_SCAN_CAP).
 *
 * Never throws PII: database failures bubble as plain Prisma errors to the
 * caller's catch (rendered as a generic 500).
 */
export async function deepCheckTenantIdentity(
  db: import("@prisma/client").PrismaClient,
  identity: TenantIdentityInput
): Promise<TenantIdentityCollisions> {
  const result: TenantIdentityCollisions = { emailUsedBy: null, phoneUsedBy: null };

  const wantEmail = typeof identity.email === "string" && identity.email.trim() !== "";
  const wantPhone = typeof identity.phone === "string" && identity.phone.trim() !== "";
  if (!wantEmail && !wantPhone) return result;

  const candidateEmail = wantEmail ? normalizeEmail(identity.email as string) : "";
  const candidateEmailIndex = wantEmail ? (blindIndex(candidateEmail) ?? "") : "";
  const candidatePhoneKey = wantPhone ? normalizePhoneDeep(identity.phone as string) : "";
  if (candidateEmailIndex === "" && candidatePhoneKey === "") return result;

  /* NO deletedAt filter, NO demo filter — "deep" includes soft-deleted and
   * showcase rows by design (see the module header). */
  const rows = await db.instance.findMany({
    select: { id: true, adminEmailIndex: true, adminJson: true, orgJson: true, deletedAt: true },
    orderBy: { id: "asc" },
  });

  let legacyScanned = 0;
  for (const row of rows) {
    /* EMAIL — blind index first; legacy NULL-index rows decrypt (bounded). */
    if (candidateEmailIndex !== "" && result.emailUsedBy === null) {
      if (row.adminEmailIndex) {
        if (row.adminEmailIndex === candidateEmailIndex) result.emailUsedBy = row.id;
      } else if (legacyScanned < LEGACY_SCAN_CAP) {
        legacyScanned += 1;
        const stored = normalizeEmail(readAdminEmail(row.adminJson));
        if (stored !== "" && stored === candidateEmail) result.emailUsedBy = row.id;
      }
    }

    /* PHONE — orgJson org.phone, normalized comparison, empty skipped. */
    if (candidatePhoneKey !== "" && result.phoneUsedBy === null) {
      const storedPhone = orgPhoneOf(row.orgJson);
      if (storedPhone !== "" && normalizePhoneDeep(storedPhone) === candidatePhoneKey) {
        result.phoneUsedBy = row.id;
      }
    }

    if (result.emailUsedBy !== null && result.phoneUsedBy !== null) break;
  }

  return result;
}
