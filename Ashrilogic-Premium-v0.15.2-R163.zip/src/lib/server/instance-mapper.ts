/**
 * Ashrilogic — server-side instance mapper.
 *
 * SQLite stores OrgInfo/AdminInfo/PrefsInfo/modules as JSON *strings*
 * (no Json/Array column types). This module is the ONLY place that touches
 * those columns:
 *  - WRITE  : strict Zod payload schemas (routes reject invalid bodies with 400)
 *  - READ   : lenient Zod schemas with per-field `.catch()` defaults — stored
 *             JSON is NEVER trusted without validation, and a corrupt field
 *             degrades to a sane default instead of a 500.
 */
import { z } from "zod";
import type { Activity, Instance, Package, TeamMember } from "@prisma/client";
import type {
  ActivityDTO,
  ActivityKind,
  AdminInfo,
  CreateInstancePayload,
  EntitlementInfoDTO,
  InstanceDTO,
  OrgInfo,
  OwnerProfileDTO,
  PackageSummaryDTO,
  PrefsInfo,
  TeamMemberDTO,
  UpdateInstancePayload,
} from "@/lib/types";
import { blindIndex, decryptField, encryptField } from "@/lib/server/crypto-vault";
import { computeEntitlement } from "@/lib/server/entitlement";
import { parseCapabilities, parseOverrides, standardTierOf, PLAN_FEATURES } from "@/lib/plan-features";

/* Password bounds shared by provisioning and the change-password flow.
 * 8 is the same floor the control-panel admin schema enforces — a workspace
 * credential owns an entire tenant, so it must not be weaker than staff
 * accounts (demo bootstrap passwords all exceed it). */
export const PASSWORD_MIN = 8;
export const PASSWORD_MAX = 72;
const passwordSchema = z.string().min(PASSWORD_MIN).max(PASSWORD_MAX);

/* ROUND 36 — hard upper bounds on every externally controlled string/array
   (DoS + DB-bloat protection; zod v4 has NO default max on z.string()). */
const SHORT_TEXT = 120; // names, currencies, roles
const MID_TEXT = 220; // addresses, phones, emails, timezone-ish strings
const MODULES_MAX = 64; // catalog systems never exceed ~15 modules

/* ------------------------------------------------------------------ */
/* Runtime enums (kept structurally in sync with src/lib/types.ts)     */
/* ------------------------------------------------------------------ */

export const ACTIVITY_KINDS = [
  "actCreated",
  "actLogin",
  "actBackup",
  "actModuleEnabled",
  "actModuleDisabled",
  "actUserAdded",
  "actUserRemoved",
  "actSettingsUpdated",
  "actDataImported",
  "actReportGenerated",
  "actReportExported",
  "actInvoiceCreated",
  "actCouponCreated",
  "actSiteLaunched",
  "actExit",
  /* ROUND 87 (trash) — workspace trash lifecycle feed entries. */
  "actTrashed",
  "actRestored",
  "actPurged",
  /* ROUND 141 (owner notifications) — the storefront/public-site customer
   * events + the wallet's money events. These MUST stay readable on the DTO
   * path: the lenient read enum below feeds the notifications center, and a
   * missing kind here would be .catch-rewritten into actSettingsUpdated and
   * silently vanish from the feed. */
  "actOrderReceived",
  "actReviewReceived",
  "actInquiryReceived",
  "actWalletTopup",
  "actWalletDebit",
  /* ROUND 144 — inter-wallet transfers (sender + receiver rows). */
  "actWalletTransfer",
] as const satisfies readonly ActivityKind[];

export const MEMBER_ROLES = ["manager", "staff", "viewer"] as const satisfies readonly TeamMemberDTO["role"][];
export const MEMBER_GENDERS = ["male", "female"] as const satisfies readonly NonNullable<TeamMemberDTO["gender"]>[];
export const ADMIN_ROLES = ["owner", "manager"] as const satisfies readonly AdminInfo["role"][];
export const LANGS = ["ar", "en"] as const satisfies readonly PrefsInfo["lang"][];
export const THEMES = ["light", "dark", "auto"] as const satisfies readonly PrefsInfo["theme"][];

/* ------------------------------------------------------------------ */
/* Strict write schemas (request bodies)                               */
/* ------------------------------------------------------------------ */

export const createInstanceSchema = z.object({
  systemId: z.string().min(1).max(64),
  org: z.object({
    name: z.string().trim().min(1).max(SHORT_TEXT),
    country: z.string().max(SHORT_TEXT),
    currency: z.string().max(SHORT_TEXT),
    timezone: z.string().max(SHORT_TEXT),
    address: z.string().max(MID_TEXT),
    phone: z.string().max(MID_TEXT),
  }),
  admin: z.object({
    name: z.string().trim().min(1).max(SHORT_TEXT),
    email: z.email().max(254),
    role: z.enum(ADMIN_ROLES),
    twoFA: z.boolean(),
    /** workspace login password — hashed server-side, never persisted in adminJson */
    password: passwordSchema,
  }),
  prefs: z.object({
    lang: z.enum(LANGS),
    theme: z.enum(THEMES),
    notif: z.boolean(),
    backup: z.boolean(),
    audit: z.boolean(),
    demo: z.boolean(),
  }),
  modules: z.array(z.string().min(1).max(64)).min(1).max(MODULES_MAX),
}) satisfies z.ZodType<CreateInstancePayload>;

/** PATCH payload — every section optional, sections themselves deep-partial. */
const updateShape = z
  .object({
    org: z.object({
      name: z.string().trim().min(1).max(SHORT_TEXT),
      country: z.string().max(SHORT_TEXT),
      currency: z.string().max(SHORT_TEXT),
      timezone: z.string().max(SHORT_TEXT),
      address: z.string().max(MID_TEXT),
      phone: z.string().max(MID_TEXT),
    }).partial(),
    admin: z.object({
      name: z.string().trim().min(1).max(SHORT_TEXT),
      email: z.email().max(254),
      role: z.enum(ADMIN_ROLES),
      twoFA: z.boolean(),
      /** workspace login password — hashed server-side, never persisted in adminJson */
      password: passwordSchema,
      /** ROUND 64 — owner profile photo (cropper-emitted JPEG data-URL);
          null clears it. 600k chars = the control-panel avatar cap. */
      avatarUrl: z.string().max(600_000).nullable(),
    }).partial(),
    prefs: z.object({
      lang: z.enum(LANGS),
      theme: z.enum(THEMES),
      notif: z.boolean(),
      backup: z.boolean(),
      audit: z.boolean(),
      demo: z.boolean(),
    }).partial(),
    modules: z.array(z.string().min(1).max(64)).min(1).max(MODULES_MAX),
    /** assign a subscription plan (cuid) or clear it (null) */
    packageId: z.string().min(1).max(64).nullable(),
    /** ROUND 47 — billing cycle purchased with the assignment (admin-side;
        the plan-order flow sets it automatically on payment confirmation) */
    planCycle: z.enum(["monthly", "yearly"]).nullable(),
    /** ROUND 79 — ADMIN ONLY: absolute end of the current paid term (ISO
     *  date or null = unlimited/platform-managed). A past date locks the
     *  workspace immediately (renewal restores). */
    planExpiresAt: z.string().datetime().nullable(),
    /** ROUND 79 — ADMIN ONLY: per-tenant feature switches. Keys validated
     *  against the catalog (PARTIAL record — only provided keys count);
     *  unknown keys are stripped before the write. */
    featureOverrides: z.partialRecord(
      z.enum(PLAN_FEATURES),
      z.boolean()
    ),
    /** Proof-of-knowledge for `admin.password` rotation: workspace sessions
     *  must present the CURRENT password (admins are exempt server-side).
     *  Bound to PASSWORD_MAX so the Argon2id verifier never receives
     *  unbounded input. */
    currentPassword: z.string().min(1).max(PASSWORD_MAX),
  })
  .partial();

export const updateInstanceSchema = updateShape.refine(
  (data) =>
    data.org !== undefined ||
    data.admin !== undefined ||
    data.prefs !== undefined ||
    data.modules !== undefined ||
    data.packageId !== undefined ||
    data.planCycle !== undefined ||
    data.planExpiresAt !== undefined ||
    data.featureOverrides !== undefined,
  { message: "At least one of org, admin, prefs, modules, packageId, planCycle, planExpiresAt or featureOverrides must be provided" }
) satisfies z.ZodType<UpdateInstancePayload>;

export const activityCreateSchema = z.object({
  kind: z.enum(ACTIVITY_KINDS),
  meta: z.record(z.string().max(64), z.string().max(200)).optional().refine(
    (meta) => !meta || Object.keys(meta).length <= 20,
    { message: "meta must hold at most 20 keys" }
  ),
});

/* ---------------- ROUND 68 — extended member profile ---------------- */

/** Loose international phone shape (digits, spaces, dashes, dots, parens,
 *  an optional leading +). Bounded to keep the sealed column small. */
const memberPhoneSchema = z
  .string()
  .trim()
  .max(24)
  .regex(/^\+?[0-9\s().-]{3,24}$/, "invalid phone");

/** ISO calendar date (yyyy-mm-dd) between 1900-01-01 and 2100-12-31. */
const memberBirthSchema = z
  .string()
  .trim()
  .regex(/^\d{4}-\d{2}-\d{2}$/, "invalid date")
  .refine((v) => {
    const d = new Date(`${v}T00:00:00Z`);
    return (
      !Number.isNaN(d.getTime()) &&
      d.getTime() >= Date.parse("1900-01-01T00:00:00Z") &&
      d.getTime() <= Date.parse("2100-12-31T00:00:00Z")
    );
  }, "invalid date");

/** Circular-cropped avatar produced by the shared cropper (288px JPEG,
 *  ≈≤120KB → data-URL ≈≤165k chars). Cap far above to absorb re-encodes. */
const memberAvatarSchema = z
  .string()
  .max(400_000)
  .startsWith("data:image/");

/** Shared optional profile fragment for create + patch bodies. */
const memberProfileShape = {
  phone: memberPhoneSchema.optional(),
  jobTitle: z.string().trim().max(80).optional(),
  birthDate: memberBirthSchema.optional(),
  gender: z.enum(MEMBER_GENDERS).optional(),
  avatarUrl: memberAvatarSchema.optional(),
  /* Task 2-b — second-language identity lines (bilingual teams): same
     bounds as jobTitle; optional + trimmed on the write side. */
  nameAlt: z.string().trim().max(80).optional(),
  jobTitleAlt: z.string().trim().max(80).optional(),
} as const;

/** Sealed profileJson envelope (write side — routes build it with
 *  encryptProfileJson below). Read side is lenient with .catch(""). */
const memberProfileRead = z.object({
  phone: z.string().catch(""),
  jobTitle: z.string().catch(""),
  birthDate: z.string().catch(""),
  gender: z.union([z.enum(MEMBER_GENDERS), z.literal("")]).catch(""),
  avatarUrl: z.string().catch(""),
  nameAlt: z.string().catch(""),
  jobTitleAlt: z.string().catch(""),
});

export type MemberProfileInput = {
  phone?: string;
  jobTitle?: string;
  birthDate?: string;
  /** "" serializes as "not provided" inside the sealed envelope */
  gender?: (typeof MEMBER_GENDERS)[number] | "";
  avatarUrl?: string;
  nameAlt?: string;
  jobTitleAlt?: string;
};

/** Serialize + seal the extended profile (never stores PII in the clear). */
export function encryptProfileJson(profile: MemberProfileInput): string | null {
  return (
    encryptField(
      JSON.stringify({
        phone: profile.phone ?? "",
        jobTitle: profile.jobTitle ?? "",
        birthDate: profile.birthDate ?? "",
        gender: profile.gender ?? "",
        avatarUrl: profile.avatarUrl ?? "",
        nameAlt: profile.nameAlt ?? "",
        jobTitleAlt: profile.jobTitleAlt ?? "",
      })
    ) ?? null
  );
}

/** Decrypt + validate a stored profileJson column (fail-soft → defaults). */
export function readMemberProfile(column: string | null | undefined) {
  if (!column) return memberProfileRead.parse({});
  try {
    const raw = decryptField(column);
    if (!raw) return memberProfileRead.parse({});
    return memberProfileRead.parse(JSON.parse(raw));
  } catch {
    return memberProfileRead.parse({});
  }
}

export const memberCreateSchema = z.object({
  name: z.string().trim().min(1).max(SHORT_TEXT),
  email: z.email().max(254),
  role: z.enum(MEMBER_ROLES),
  ...memberProfileShape,
});

/** ROUND 68 — PATCH body: every field optional; null explicitly clears the
 *  optional profile fields (phone/jobTitle/birthDate/gender/avatarUrl). */
export const memberUpdateSchema = z.object({
  name: z.string().trim().min(1).max(SHORT_TEXT).optional(),
  email: z.email().max(254).optional(),
  role: z.enum(MEMBER_ROLES).optional(),
  phone: memberPhoneSchema.nullable().optional(),
  jobTitle: z.string().trim().max(80).nullable().optional(),
  birthDate: memberBirthSchema.nullable().optional(),
  gender: z.enum(MEMBER_GENDERS).nullable().optional(),
  avatarUrl: memberAvatarSchema.max(400_000).nullable().optional(),
  nameAlt: z.string().trim().max(80).nullable().optional(),
  jobTitleAlt: z.string().trim().max(80).nullable().optional(),
});
export type MemberUpdateInput = z.infer<typeof memberUpdateSchema>;

/** Compact, human-readable message from a Zod error (surfaces in toasts). */
export function zodError(error: z.ZodError): string {
  const parts = error.issues.slice(0, 3).map((issue) => {
    const path = issue.path.join(".");
    return path ? `${path}: ${issue.message}` : issue.message;
  });
  return `Validation failed — ${parts.join(" · ")}`;
}

/* ------------------------------------------------------------------ */
/* Lenient read schemas (stored JSON columns — fail-soft)              */
/* ------------------------------------------------------------------ */

const orgRead = z.object({
  name: z.string().catch(""),
  country: z.string().catch(""),
  currency: z.string().catch(""),
  timezone: z.string().catch(""),
  address: z.string().catch(""),
  phone: z.string().catch(""),
});

const adminRead = z.object({
  name: z.string().catch(""),
  email: z.string().catch(""),
  role: z.enum(ADMIN_ROLES).catch("owner"),
  twoFA: z.boolean().catch(false),
  /* ROUND 64 — owner profile photo (circular JPEG data-URL); lenient per-field
     catch so a legacy/garbage value degrades to "no photo" without nuking the
     whole admin section (the file's established read-schema idiom). */
  avatarUrl: z.string().max(600_000).nullable().catch(null),
});

const prefsRead = z.object({
  lang: z.enum(LANGS).catch("en"),
  theme: z.enum(THEMES).catch("auto"),
  notif: z.boolean().catch(true),
  backup: z.boolean().catch(true),
  audit: z.boolean().catch(true),
  demo: z.boolean().catch(false),
});

const modulesRead = z.array(z.string().catch("")).catch([]);

/* ---------------- ROUND 84 — owner personal profile ---------------- */

/** Lenient read schema for the stored ownerProfileJson column (fail-soft:
    NULL, corrupt or legacy values degrade to "not completed" — never a 500).
    Mirrors the memberProfileRead idiom, including the "" = unset gender. */
const ownerProfileRead = z.object({
  gender: z.union([z.enum(MEMBER_GENDERS), z.literal("")]).catch(""),
  birthDate: z.string().catch(""),
  address: z.string().catch(""),
  nationality: z.string().catch(""),
  jobTitle: z.string().catch(""),
  phone: z.string().catch(""),
  completedAt: z.string().catch(""),
});

const EMPTY_OWNER_PROFILE = ownerProfileRead.parse({});

/** Read + validate the stored owner-profile column. The ONLY writer is the
    strict PUT /owner-profile route (every field + completedAt stamped
    atomically), so completeness == every required field present; anything
    else (NULL, partial, corrupt) keeps `completed: false` — the blocking
    dashboard gate re-opens until the owner submits a valid full profile. */
export function readOwnerProfile(column: string | null | undefined): OwnerProfileDTO {
  const parsed = readJsonColumn(column, ownerProfileRead, EMPTY_OWNER_PROFILE);
  const { gender } = parsed;
  const missing =
    gender === "" ||
    parsed.birthDate === "" ||
    parsed.address === "" ||
    parsed.nationality === "" ||
    parsed.jobTitle === "" ||
    parsed.phone === "" ||
    parsed.completedAt === "";
  if (missing) return { completed: false };
  /* `gender` is narrowed to MemberGender here; the spread override hands
     the DTO its strictly-typed profile. */
  return { completed: true, profile: { ...parsed, gender } };
}

/* ROUND 144 — activity meta values arrive from BOTH the platform (string
 * snapshots) and the money engines (numbers: amount/total/items). The read
 * schema accepts string | number | boolean and STRINGIFIES everything, so a
 * numeric amount can never fail the record parse and drop the whole meta
 * map (the old z.record(string, string) silently discarded the wallet and
 * order metas — the notifications center rendered them detail-less). */
const activityMetaRead = z.record(
  z.string(),
  z.union([z.string(), z.number(), z.boolean()]).transform((v) => String(v))
);
const activityKindRead = z.enum(ACTIVITY_KINDS).catch("actSettingsUpdated");
const memberRoleRead = z.enum(MEMBER_ROLES).catch("staff");

const DEFAULT_ORG: OrgInfo = { name: "", country: "", currency: "", timezone: "", address: "", phone: "" };
const DEFAULT_ADMIN: AdminInfo = { name: "", email: "", role: "owner", twoFA: false };
const DEFAULT_PREFS: PrefsInfo = { lang: "en", theme: "auto", notif: true, backup: true, audit: true, demo: false };

/** Parse a stored JSON-string column with a lenient schema; fall back on any error. */
function readJsonColumn<T>(raw: string | null | undefined, schema: z.ZodType<T>, fallback: T): T {
  if (raw == null || raw === "") return fallback;
  try {
    const parsed = schema.safeParse(JSON.parse(raw));
    return parsed.success ? parsed.data : fallback;
  } catch {
    return fallback;
  }
}

/* ------------------------------------------------------------------ */
/* adminJson PII sealing (workspace login email)                      */
/* ------------------------------------------------------------------ */

/**
 * Normalize an email for storage/lookup (trim + lowercase — matches the
 * blind-index normalization in crypto-vault.ts).
 */
export function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

/**
 * Serialize the admin section with the login email SEALED (AES-256-GCM
 * envelope) and its blind index derived. The email is the workspace's
 * authentication identifier — the same protection class as AdminUser /
 * SiteCustomer emails. Legacy plaintext rows decrypt as-is (no marker →
 * passthrough) until scripts/backfill-instance-pii.ts converges the store.
 * Returns the adminJson string plus the derived adminEmailIndex.
 */
export function sealAdminSection(admin: {
  name: string;
  email: string;
  role: "owner" | "manager";
  twoFA: boolean;
  /** ROUND 64 — owner profile photo rides inside the sealed adminJson */
  avatarUrl?: string | null;
}): { adminJson: string; adminEmailIndex: string } {
  const email = normalizeEmail(admin.email);
  return {
    adminJson: JSON.stringify({ ...admin, email: encryptField(email) ?? "" }),
    adminEmailIndex: blindIndex(email) ?? "",
  };
}

/**
 * Read the workspace admin email from a stored adminJson column (sealed at
 * rest; legacy plaintext passes through). Never throws.
 */
export function readAdminEmail(adminJson: string | null | undefined): string {
  try {
    const parsed = JSON.parse(adminJson ?? "{}") as { email?: unknown };
    if (typeof parsed.email === "string") return decryptField(parsed.email) ?? "";
  } catch {
    /* corrupt adminJson */
  }
  return "";
}

/* ------------------------------------------------------------------ */
/* DTO mappers                                                         */
/* ------------------------------------------------------------------ */

export function toActivityDTO(row: Activity): ActivityDTO {
  return {
    id: row.id,
    kind: activityKindRead.parse(row.kind),
    meta: readJsonColumn(row.metaJson, activityMetaRead, undefined),
    createdAt: row.createdAt.toISOString(),
  };
}

export function toMemberDTO(row: TeamMember): TeamMemberDTO {
  const profile = readMemberProfile(row.profileJson);
  return {
    id: row.id,
    name: row.name,
    /* round 35 — sealed column decrypted for the DTO */
    email: decryptField(row.email) ?? "",
    role: memberRoleRead.parse(row.role),
    /* ROUND 68 — sealed extended profile */
    phone: profile.phone,
    jobTitle: profile.jobTitle,
    birthDate: profile.birthDate,
    gender: profile.gender,
    avatarUrl: profile.avatarUrl,
    /* Task 2-b — second-language identity lines */
    nameAlt: profile.nameAlt,
    jobTitleAlt: profile.jobTitleAlt,
    createdAt: row.createdAt.toISOString(),
  };
}

/** Compact plan summary for instance DTOs (local — avoids a mapper import cycle). */
export function toPackageSummaryDTO(row: Package): PackageSummaryDTO {
  return {
    id: row.id,
    nameAr: row.nameAr,
    nameEn: row.nameEn,
    descAr: row.descAr,
    descEn: row.descEn,
    priceMonthly: row.priceMonthly,
    priceYearly: row.priceYearly,
    currency: row.currency,
    popular: row.popular,
    maxUsers: row.maxUsers,
    maxModules: row.maxModules,
    maxStorageMb: row.maxStorageMb,
    /* ROUND 79 → ROUND 80 — dynamic promotions (per cycle) + plan
     * capabilities ride the summary so billing cards, invoices and lock
     * screens price/label correctly. */
    discountPct: row.discountPct ?? 0,
    yearlyDiscountPct: row.yearlyDiscountPct ?? 0,
    capabilities: parseCapabilities(
      row.capabilitiesJson ?? "[]",
      standardTierOf(row.nameAr, row.nameEn)
    ),
  };
}

/** The exact site shape toInstanceDTO reads (matches `site: true` AND the
    slim `select: { published, theme, views, contentJson }` include).
 *  ROUND 45 — contentJson joins the slim select so the summary can carry
 *  the BRAND LOGO (see toSiteSummaryDTO). */
type SiteSummaryRow = { published: boolean; theme: string; views: number; contentJson?: string | null };

/** Build the site summary (with logo + invoice assets) from a slim row.
 *  ROUND 67 — the summary also carries the invoice signature/stamp refs and
 *  scales so owner-facing receipts (orders panel) print them without
 *  loading the full site content.
 *  ROUND 86 — the summary also carries the colors/fonts choices (dashTheme,
 *  dashFont, storeTheme, storeFont) so the dashboard shell and the store
 *  page can style themselves without the full content. */
function siteSummary(row: SiteSummaryRow): {
  published: boolean;
  theme: string;
  views: number;
  logoUrl: string;
  signatureUrl: string;
  stampUrl: string;
  signatureScale: number;
  stampScale: number;
  invoicePrefix: string;
  dashTheme: string;
  dashFont: string;
  storeTheme: string;
  storeFont: string;
} {
  let logoUrl = "";
  let signatureUrl = "";
  let stampUrl = "";
  let signatureScale = 1;
  let stampScale = 1;
  let invoicePrefix = "";
  let dashTheme = "";
  let dashFont = "";
  let storeTheme = "";
  let storeFont = "";
  try {
    const parsed = JSON.parse(row.contentJson ?? "{}") as {
      logoUrl?: unknown;
      signatureUrl?: unknown;
      stampUrl?: unknown;
      signatureScale?: unknown;
      stampScale?: unknown;
      invoicePrefix?: unknown;
      dashTheme?: unknown;
      dashFont?: unknown;
      storeTheme?: unknown;
      storeFont?: unknown;
    };
    if (typeof parsed.logoUrl === "string") logoUrl = parsed.logoUrl;
    if (typeof parsed.signatureUrl === "string") signatureUrl = parsed.signatureUrl;
    if (typeof parsed.stampUrl === "string") stampUrl = parsed.stampUrl;
    if (typeof parsed.signatureScale === "number") signatureScale = parsed.signatureScale;
    if (typeof parsed.stampScale === "number") stampScale = parsed.stampScale;
    if (typeof parsed.invoicePrefix === "string") invoicePrefix = parsed.invoicePrefix;
    if (typeof parsed.dashTheme === "string") dashTheme = parsed.dashTheme;
    if (typeof parsed.dashFont === "string") dashFont = parsed.dashFont;
    if (typeof parsed.storeTheme === "string") storeTheme = parsed.storeTheme;
    if (typeof parsed.storeFont === "string") storeFont = parsed.storeFont;
  } catch {
    /* corrupt contentJson — no brand assets */
  }
  return {
    published: row.published,
    theme: row.theme,
    views: row.views,
    logoUrl,
    signatureUrl,
    stampUrl,
    signatureScale,
    stampScale,
    invoicePrefix,
    dashTheme,
    dashFont,
    storeTheme,
    storeFont,
  };
}

/**
 * Map a Prisma Instance row (with optional eagerly-loaded activities,
 * expected to be pre-sorted newest-first by the caller, an optional
 * package relation, and an optional site relation) to its DTO. All JSON
 * columns are re-validated — never trust stored JSON.
 */
export function toInstanceDTO(
  row: Instance & {
    activities?: Activity[];
    package?: Package | null;
    site?: SiteSummaryRow | null;
  }
): InstanceDTO {
  const admin = readJsonColumn(row.adminJson, adminRead, DEFAULT_ADMIN);
  /* ROUND 47 → ROUND 79 — entitlement is computed from the live columns on
     EVERY read (trial clock + paid-term expiry + the effective feature map);
     it never round-trips through client state. */
  const entitlement: EntitlementInfoDTO = computeEntitlement({
    packageId: row.packageId,
    trialEndsAt: row.trialEndsAt,
    planActivatedAt: row.planActivatedAt,
    planCycle: row.planCycle,
    planExpiresAt: row.planExpiresAt,
    featureOverridesJson: row.featureOverridesJson,
    bannedPermanently: row.bannedPermanently,
    bannedUntil: row.bannedUntil,
    bannedReason: row.bannedReason,
    bannedAt: row.bannedAt,
    package: row.package
      ? { capabilitiesJson: row.package.capabilitiesJson, nameAr: row.package.nameAr, nameEn: row.package.nameEn }
      : null,
  });
  return {
    id: row.id,
    systemId: row.systemId,
    org: readJsonColumn(row.orgJson, orgRead, DEFAULT_ORG),
    /* sealed login email — decrypted for the authenticated DTO only */
    admin: { ...admin, email: decryptField(admin.email) ?? "" },
    prefs: readJsonColumn(row.prefsJson, prefsRead, DEFAULT_PREFS),
    /* ROUND 144 — the wallet's unique transfer number + live balance mirror
     * (both read straight off the row — list surfaces like «أنظمتك المنشأة»
     * render them without a second wallet round-trip). */
    walletNo: row.walletNo ?? null,
    walletMinor: row.walletMinor ?? 0,
    /* ROUND 84 — owner personal-profile completeness (authenticated DTO
       only; toSanitizedInstanceDTO omits the field entirely). */
    ownerProfile: readOwnerProfile(row.ownerProfileJson),
    modules: readJsonColumn(row.modulesJson, modulesRead, []),
    packageId: row.packageId ?? null,
    package: row.package ? toPackageSummaryDTO(row.package) : null,
    site: row.site ? siteSummary(row.site) : null,
    demo: row.demo ?? false,
    entitlement,
    /* ROUND 79 — admin-console mirror of the per-tenant platform switches
     * (the EFFECTIVE map is entitlement.features; this is what the console
     * edits). Sanitized callers overwrite it with {}). */
    featureOverrides: parseOverrides(row.featureOverridesJson ?? "{}"),
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
    activities: (row.activities ?? []).map(toActivityDTO),
  };
}

/**
 * ROUND 36 — anonymous-safe SANITIZED projection for the public directory
 * (GET /api/instances without an authenticated caller). Returns the full
 * InstanceDTO SHAPE (so typed clients keep working) with every sensitive
 * field blanked: no admin identity, no contact channels, no address, no
 * prefs, no activities, no package assignment. Only the showcase-card
 * fields (org name, system, module-count-compatible list, site summary)
 * carry real data — module ids are static public catalog values.
 */
export function toSanitizedInstanceDTO(
  row: Pick<
    Instance,
    "id" | "systemId" | "orgJson" | "modulesJson" | "demo" | "createdAt"
  > & { site?: SiteSummaryRow | null }
): InstanceDTO {
  const org = readJsonColumn(row.orgJson, orgRead, DEFAULT_ORG);
  const modules = readJsonColumn(row.modulesJson, modulesRead, []);
  return {
    id: row.id,
    systemId: row.systemId,
    org: { ...DEFAULT_ORG, name: org.name },
    admin: { ...DEFAULT_ADMIN },
    prefs: { ...DEFAULT_PREFS },
    modules,
    packageId: null,
    package: null,
    site: row.site ? siteSummary(row.site) : null,
    demo: row.demo ?? false,
    /* sanitized projection: neutral entitlement — the public directory never
       leaks trial state; real gating happens server-side per request. */
    entitlement: {
      state: "active",
      trialEndsAt: null,
      trialDaysLeft: null,
      trialHoursLeft: null,
      trialMsLeft: null,
      planActivatedAt: null,
      planCycle: null,
      planExpiresAt: null,
      planDaysLeft: null,
      lockReason: null,
      ban: { active: false, kind: null, until: null, reason: null, at: null },
      features: {},
    },
    featureOverrides: {},
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.createdAt.toISOString(),
    activities: [],
  };
}
