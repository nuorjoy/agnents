/**
 * Ashrilogic — ROUND 141 (dynamic add-on pricing — التسعير الديناميكي).
 *
 * The owner's directive: the add-on store's prices are PLATFORM-CONTROLLED
 * at runtime — a price change from the console takes effect IMMEDIATELY on
 * every surface (the store's catalog cards, the checkout preview, and the
 * server's own order amounts) with ZERO code changes.
 *
 * Storage: PlatformSetting.addonsPricingJson — { monthly: Record<featureKey,
 * price> } (MAJOR units, the Package.priceMonthly convention). Only KNOWN
 * feature keys survive the sanitize pass; only sane integers (1..10000)
 * ride through. Absent keys fall back to the baseline ladder in
 * src/lib/addons.ts.
 *
 * Reads happen on EVERY order creation + catalog projection (a single-row
 * lookup) — no cache, no restart, no code deploy: the definition of "live".
 */
import { db } from "@/lib/db";
import {
  DEFAULT_ADDON_PRICES,
  buildAddonCatalog,
  yearlyAddonPrice,
  type AddonCatalogEntry,
} from "@/lib/addons";
import { PLAN_FEATURES, type PlanFeature } from "@/lib/plan-features";

/** The stored shape (the console PATCHes the complete object). */
export interface AddonPricingTable {
  monthly: Partial<Record<PlanFeature, number>>;
}

const PRICE_MIN = 1;
const PRICE_MAX = 10_000;

/** Sanitize a raw stored/payload table: known keys only, integer prices in
 *  range only — everything else is dropped (never trusted). */
export function sanitizeAddonPricing(raw: unknown): AddonPricingTable {
  const out: AddonPricingTable = { monthly: {} };
  if (typeof raw !== "object" || raw === null) return out;
  const monthly = (raw as { monthly?: unknown }).monthly;
  if (typeof monthly !== "object" || monthly === null) return out;
  for (const key of Object.keys(monthly)) {
    if (!PLAN_FEATURES.includes(key as PlanFeature)) continue;
    const value = (monthly as Record<string, unknown>)[key];
    const price =
      typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
    if (Number.isInteger(price) && price >= PRICE_MIN && price <= PRICE_MAX) {
      out.monthly[key as PlanFeature] = price;
    }
  }
  return out;
}

/** Read the platform's live overrides (empty table when never configured). */
export async function readAddonPricing(): Promise<AddonPricingTable> {
  const row = await db.platformSetting.findUnique({
    where: { id: "global" },
    select: { addonsPricingJson: true },
  });
  if (!row?.addonsPricingJson) return { monthly: {} };
  try {
    return sanitizeAddonPricing(JSON.parse(row.addonsPricingJson));
  } catch {
    return { monthly: {} };
  }
}

/** The LIVE per-feature monthly table: the baseline ladder under the
 *  platform overrides. This is the single server-side price authority. */
export async function resolveAddonPrices(): Promise<Record<PlanFeature, number>> {
  const overrides = await readAddonPricing();
  return { ...DEFAULT_ADDON_PRICES, ...overrides.monthly };
}

/** The LIVE catalog (canonical order, live prices) — the store's projection. */
export async function liveAddonCatalog(): Promise<AddonCatalogEntry[]> {
  return buildAddonCatalog(await resolveAddonPrices());
}

/** The server-authoritative order total (major units) under the LIVE table.
 *  Recomputed on every order — the client's preview number is never
 *  trusted, exactly like plan orders. */
export async function liveAddonOrderAmount(
  features: PlanFeature[],
  cycle: "monthly" | "yearly"
): Promise<number> {
  const prices = await resolveAddonPrices();
  let total = 0;
  for (const feature of features) {
    const monthly = prices[feature] ?? DEFAULT_ADDON_PRICES[feature] ?? 0;
    total += cycle === "yearly" ? yearlyAddonPrice(monthly) : monthly;
  }
  return total;
}
