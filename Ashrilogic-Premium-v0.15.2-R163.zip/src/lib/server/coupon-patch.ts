import { z } from "zod";
import type { StoreCoupon } from "@prisma/client";
import { db } from "@/lib/db";
import { COUPON_KINDS } from "./coupons";
import { MAX_MINOR_UNITS, isValidMinorUnits } from "./money";

/**
 * Ashrilogic — coupon partial update (engine for
 * PATCH /api/instances/[id]/store/coupons/[couponId]).
 *
 * LOST-UPDATE GUARD (reliability audit 2-c, LOW finding — closed here): the
 * merge base is read INSIDE the write transaction. The former route shape
 * fetched the row BEFORE the transaction and re-wrote EVERY field from that
 * stale snapshot (`data.X ?? existing.X` with `existing` minutes-stale by
 * the time the transaction opened) — two concurrent owner edits silently
 * reverted each other: editor B's {value} patch rewrote editor A's freshly
 * committed maxUses/minSubtotal/active back to B's stale pre-read values,
 * with a 200 and no trace. With the read inside the transaction and the
 * platform's serialized single writer (`connection_limit=1`), a competing
 * PATCH — or a guest order's coupon CAS — serializes entirely before or
 * after THIS read→merge→write, so disjoint concurrent edits all survive.
 *
 * The route keeps: session/permission/feature gates, rate limiting, body
 * parsing, audit logging, and DTO shaping. This engine owns the DB law:
 * scoped lookup, every bound re-checked against the CURRENT row, the
 * update, and the activity trail — all inside ONE transaction.
 */

/* partial update — every field optional, all bounds re-checked */
export const couponPatchSchema = z
  .object({
    kind: z.enum(COUPON_KINDS).optional(),
    value: z.number().int().optional(),
    minSubtotal: z.number().int().min(1).max(MAX_MINOR_UNITS).nullable().optional(),
    maxUses: z.number().int().min(1).max(1_000_000).nullable().optional(),
    startsAt: z.string().datetime().nullable().optional(),
    expiresAt: z.string().datetime().nullable().optional(),
    active: z.boolean().optional(),
  })
  .refine((v) => Object.keys(v).length > 0, { message: "nothing to update" });

export type CouponPatchInput = z.infer<typeof couponPatchSchema>;

/** Mapped abort — carries the route's existing HTTP semantics out of the
 *  transaction without poisoning it as a server error. Never crosses a
 *  process boundary; never serialized anywhere. */
class CouponPatchAbort extends Error {
  constructor(
    readonly status: number,
    readonly error: string
  ) {
    super(error);
  }
}

export type CouponPatchResult =
  | { ok: true; row: StoreCoupon }
  | { ok: false; status: number; error: string };

/**
 * Apply one partial coupon update atomically. The code is immutable (order
 * history references it); every other field is merged from the row as of
 * the transaction's own read. Returns the updated row, or the mapped
 * 404/400 semantics the route has always answered with. Unexpected errors
 * propagate — the route maps them to its existing 500 path.
 */
export async function applyCouponPatch(
  instanceId: string,
  couponId: string,
  data: CouponPatchInput
): Promise<CouponPatchResult> {
  try {
    const row = await db.$transaction(async (tx) => {
      /* scoped lookup INSIDE the transaction: a cross-tenant id stays a
       * plain 404 and the merge base is the CURRENT committed row;
       * ROUND 146 — a trashed coupon is dead to the live PATCH engine */
      const existing = await tx.storeCoupon.findFirst({
        where: { id: couponId, instanceId, deletedAt: null },
      });
      if (!existing) throw new CouponPatchAbort(404, "Coupon not found");

      /* every bound re-checked against the merged (current + patch) state */
      const kind = data.kind ?? (existing.kind === "fixed" ? "fixed" : "percent");
      const value = data.value ?? existing.value;
      if (
        kind === "percent"
          ? !(value >= 1 && value <= 99)
          : !(isValidMinorUnits(value) && value > 0)
      ) {
        throw new CouponPatchAbort(
          400,
          "percent coupons take 1–99; fixed coupons take a positive minor-unit amount"
        );
      }
      const startsAt =
        data.startsAt !== undefined ? (data.startsAt ? new Date(data.startsAt) : null) : existing.startsAt;
      const expiresAt =
        data.expiresAt !== undefined ? (data.expiresAt ? new Date(data.expiresAt) : null) : existing.expiresAt;
      if (startsAt && expiresAt && startsAt >= expiresAt) {
        throw new CouponPatchAbort(400, "the redemption window must start before it ends");
      }

      const updated = await tx.storeCoupon.update({
        where: { id: existing.id },
        data: {
          kind,
          value,
          minSubtotal: data.minSubtotal !== undefined ? data.minSubtotal : existing.minSubtotal,
          maxUses: data.maxUses !== undefined ? data.maxUses : existing.maxUses,
          startsAt,
          expiresAt,
          active: data.active !== undefined ? data.active : existing.active,
        },
      });
      await tx.activity.create({
        data: {
          instanceId,
          kind: "actCouponUpdated",
          metaJson: JSON.stringify({ code: existing.code, active: updated.active }),
        },
      });
      return updated;
    });
    return { ok: true, row };
  } catch (error) {
    if (error instanceof CouponPatchAbort) {
      return { ok: false, status: error.status, error: error.error };
    }
    throw error;
  }
}
