/**
 * Ashrilogic — sustained-load migration trigger.
 *
 * Sustained SQLite pressure may START migration READINESS (the PREPARING
 * phase: triggers + manifest — no datasource change, no data movement). It
 * can NEVER switch databases: every later phase is operator-driven through
 * the verification-gated cutover.
 *
 * Signals (all configurable, all requiring a SUSTAINED window — a single
 * spike never triggers anything):
 *  - write-probe latency p95 over a rolling sample window (a real
 *    INSERT+DELETE through the same engine the app writes through)
 *  - probe failures (SQLITE_BUSY / socket timeouts) per 10 minutes
 *
 * Env thresholds:
 *   MIGRATION_TRIGGER_WRITE_P95_MS    (default 250)
 *   MIGRATION_TRIGGER_BUSY_PER_10MIN  (default 20)
 *   MIGRATION_TRIGGER_SUSTAIN_MIN     (default 10 — sustained minutes)
 *   MIGRATION_TRIGGER_ENABLED         (default "1"; "0" disables entirely)
 */

import { db } from "@/lib/db";
import { currentProvider } from "@/lib/db";
import { getMigrationStatus, beginPreparation } from "./controller";
import { migLog } from "./logger";

const PROBE_INTERVAL_MS = 30_000;
const SAMPLE_WINDOW = 40; /* ~20 minutes of samples */

interface TriggerState {
  started: boolean;
  latencies: number[]; /* rolling probe latencies */
  busyWindow: number[]; /* probe-failure timestamps */
  sustainedSince: number | null;
}
const STATE_FLAG = "__ashrilogicMigrationTrigger";
const g = globalThis as Record<string, unknown>;
const state: TriggerState = (g[STATE_FLAG] as TriggerState) ?? {
  started: false,
  latencies: [],
  busyWindow: [],
  sustainedSince: null,
};
g[STATE_FLAG] = state;

function num(name: string, fallback: number): number {
  const v = Number(process.env[name]);
  return Number.isFinite(v) && v > 0 ? v : fallback;
}

/** One real write through the engine: INSERT + DELETE on MigrationProbe. */
async function probe(): Promise<{ latencyMs: number; ok: boolean }> {
  const t0 = Date.now();
  try {
    await db.$executeRawUnsafe(
      `INSERT INTO "MigrationProbe" ("ts", "latencyMs", "ok") VALUES (?, -1, 1)`
    );
    await db.$executeRawUnsafe(
      `DELETE FROM "MigrationProbe" WHERE "id" = (SELECT MAX("id") FROM "MigrationProbe")`
    );
    return { latencyMs: Date.now() - t0, ok: true };
  } catch {
    return { latencyMs: Date.now() - t0, ok: false };
  }
}

function p95(values: number[]): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  return sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * 0.95))]!;
}

/** Evaluate thresholds; returns true when the sustained condition holds. */
function evaluate(now: number): boolean {
  const p95Ms = num("MIGRATION_TRIGGER_WRITE_P95_MS", 250);
  const busyPer10 = num("MIGRATION_TRIGGER_BUSY_PER_10MIN", 20);
  const sustainMin = num("MIGRATION_TRIGGER_SUSTAIN_MIN", 10);

  state.busyWindow = state.busyWindow.filter((t) => now - t < 600_000);
  const writeP95 = p95(state.latencies);
  const busy = state.busyWindow.length;
  const pressured = writeP95 > p95Ms && busy >= busyPer10;

  if (pressured) {
    state.sustainedSince ??= now;
    return now - state.sustainedSince >= sustainMin * 60_000;
  }
  state.sustainedSince = null;
  return false;
}

/** Register the sampler (instrumentation.ts calls this once per process). */
export function startMigrationLoadTrigger(): void {
  if (state.started) return;
  if (process.env.MIGRATION_TRIGGER_ENABLED === "0") return;
  /* the probe table (MigrationProbe) is SQLite-only — once the app runs on
     PostgreSQL the SQLite→PG migration is DONE by definition and the
     sampler would only record guaranteed failures */
  if (currentProvider() !== "sqlite") {
    migLog.info("load-trigger.skipped", {
      detail: "app runs on PostgreSQL — SQLite load signals are no longer meaningful",
    });
    return;
  }
  state.started = true;

  const tick = async (): Promise<void> => {
    try {
      const status = await getMigrationStatus();
      /* only a steady-state (or archived) system can BEGIN a preparation */
      if (status.state !== "SQLITE_ONLY" && status.state !== "SQLITE_ARCHIVED") return;

      const result = await probe();
      state.latencies.push(result.latencyMs);
      if (state.latencies.length > SAMPLE_WINDOW) state.latencies.shift();
      if (!result.ok) state.busyWindow.push(Date.now());

      if (evaluate(Date.now())) {
        const p95Ms = p95(state.latencies);
        const busy = state.busyWindow.length;
        state.sustainedSince = null;
        migLog.warn("load-trigger.fired", {
          phase: status.state,
          result: `sustained write p95 ${p95Ms}ms · ${busy} busy/10min — starting migration READINESS`,
        });
        /* readiness only — NEVER a datasource switch */
        await beginPreparation();
      }
    } catch (error) {
      /* the trigger must never destabilize the app */
      migLog.warn("load-trigger.error", {
        detail: error instanceof Error ? error.message.slice(0, 200) : String(error),
      });
    }
  };

  setInterval(() => void tick(), PROBE_INTERVAL_MS).unref?.();
  migLog.info("load-trigger.registered", {
    detail: `probe every ${PROBE_INTERVAL_MS / 1000}s · p95>${num("MIGRATION_TRIGGER_WRITE_P95_MS", 250)}ms · busy>${num("MIGRATION_TRIGGER_BUSY_PER_10MIN", 20)}/10min sustained ${num("MIGRATION_TRIGGER_SUSTAIN_MIN", 10)}min`,
  });
}
