/**
 * Ashrilogic — migration controller facade (SQLite → PostgreSQL).
 *
 * Single entry point for the CLI (scripts/pg-migrate.ts), the health
 * endpoint (/api/status) and the load-signal trigger. Every operation is
 * state-checked, logged, and resumable — the controller NEVER auto-switches
 * the datasource: the primary flip is executeCutover() + operator confirm,
 * and even that only after the verification battery proves equivalence.
 */

import { randomBytes } from "node:crypto";
import { existsSync } from "node:fs";
import { controlDb } from "./control-db";
import {
  readState,
  writeState,
  updateManifest,
  type ActionResult,
  type MigrationStateName,
  type MigrationManifest,
} from "./state-machine";
import { installTriggers, uninstallTriggers, currentWatermark, pendingEventCount } from "./change-capture";
import { createMigrationSnapshot, migrationsDir } from "./snapshot";
import { runInitialCopy, setTableMetaCache } from "./copy";
import { replayPendingEvents } from "./replay";
import { runVerification } from "./verify";
import {
  createShadowFromSnapshot,
  liveTableColumns,
  resolveConfiguredTarget,
  type MigrationTarget,
} from "./target";
import {
  requestCutover,
  executeCutover,
  rollbackToSqlite,
  archiveSqlite,
  type CutoverHandle,
} from "./cutover";
import { migLog } from "./logger";
import { join } from "node:path";

export interface MigrationStatus {
  state: MigrationStateName;
  migrationId: string | null;
  target: string | null;
  lastReplayedSequence: number;
  snapshotWatermark: number | null;
  pendingEvents: number;
  failedReplays: number;
  lastError?: { at: string; phase: string; message: string };
  verification?: MigrationManifest["verification"];
  rollbackWindowClosesAt?: string;
}

export async function getMigrationStatus(): Promise<MigrationStatus> {
  const current = await readState();
  const pending = current.migrationId
    ? await pendingEventCount(current.lastReplayedSequence)
    : 0;
  return {
    state: current.state,
    migrationId: current.migrationId,
    target: current.manifest?.target.descriptor ?? null,
    lastReplayedSequence: current.lastReplayedSequence,
    snapshotWatermark: current.snapshotWatermark,
    pendingEvents: pending,
    failedReplays: current.failedReplays,
    lastError: current.manifest?.lastError,
    verification: current.manifest?.verification,
    rollbackWindowClosesAt: current.manifest?.rollback?.windowClosesAt,
  };
}

/** Resolve the target for a run: configured PG, or an explicit shadow path.
 *  A shadow is initialized ONCE (first use); later phases REUSE the file —
 *  re-initialization would destroy the copied state. */
async function targetFor(
  manifest: MigrationManifest,
  shadowPath?: string
): Promise<MigrationTarget> {
  if (shadowPath) {
    if (!existsSync(shadowPath)) {
      const { target } = await createShadowFromSnapshot(
        join(migrationsDir(), manifest.migrationId, "snapshot.db"),
        shadowPath
      );
      return target;
    }
    const { openShadowTarget } = await import("./target");
    return openShadowTarget(shadowPath);
  }
  return resolveConfiguredTarget();
}

/** SQLITE_ONLY → PREPARING: mint the run, install change-capture triggers. */
export async function beginPreparation(options: {
  shadowPath?: string;
} = {}): Promise<ActionResult> {
  const current = await readState();
  if (current.state !== "SQLITE_ONLY") {
    return { ok: false, from: current.state, reason: `migration already active (${current.state})` };
  }
  const migrationId = randomBytes(16).toString("hex");
  const targetDescriptor = options.shadowPath
    ? `sqlite-shadow:${options.shadowPath}`
    : process.env.DATABASE_URL_POSTGRES
      ? "postgres:configured"
      : "postgres:unset";

  await writeState("PREPARING", {
    migrationId,
    manifest: {
      migrationId,
      startedAt: new Date().toISOString(),
      target: {
        kind: options.shadowPath ? "sqlite-shadow" : "postgres",
        descriptor: targetDescriptor,
      },
    },
    lastReplayedSequence: 0,
    snapshotWatermark: null,
    failedReplays: 0,
  });
  await installTriggers();
  migLog.info("preparation.started", {
    migrationId,
    phase: "PREPARING",
    result: "capture triggers live",
  });
  return { ok: true, from: "SQLITE_ONLY", to: "PREPARING" };
}

/** PREPARING → SNAPSHOT_CREATED: consistent snapshot + watermark. */
export async function snapshotStep(): Promise<ActionResult<{ path: string; watermark: number }>> {
  const current = await readState();
  if (current.state !== "PREPARING" || !current.manifest) {
    return { ok: false, from: current.state, reason: `state is ${current.state}, expected PREPARING` };
  }
  const snap = await createMigrationSnapshot(current.manifest.migrationId);
  await writeState("SNAPSHOT_CREATED", { snapshotWatermark: snap.watermark });
  await updateManifest("SNAPSHOT_CREATED", (m) => {
    m.snapshot = {
      path: snap.path,
      watermark: snap.watermark,
      createdAt: new Date().toISOString(),
      rowCounts: snap.rowCounts,
    };
  });
  return { ok: true, from: "PREPARING", to: "SNAPSHOT_CREATED", data: { path: snap.path, watermark: snap.watermark } };
}

/** SNAPSHOT_CREATED → INITIAL_COPY → CHANGE_CAPTURE: copy + first replay. */
export async function copyStep(options: {
  shadowPath?: string;
} = {}): Promise<ActionResult<{ copiedRows: number; appliedEvents: number }>> {
  const current = await readState();
  if (
    (current.state !== "SNAPSHOT_CREATED" && current.state !== "INITIAL_COPY") ||
    !current.manifest
  ) {
    return { ok: false, from: current.state, reason: `state is ${current.state}, expected SNAPSHOT_CREATED` };
  }
  const manifest = current.manifest;
  const target = await targetFor(manifest, options.shadowPath);

  const ping = await target.ping();
  if (!ping.ok) {
    return {
      ok: false,
      from: current.state,
      reason: `target missing tables: ${ping.missingTables.join(", ")} — create the schema first (prisma db push --schema prisma/schema.postgres.prisma)`,
    };
  }

  if (current.state === "SNAPSHOT_CREATED") {
    await writeState("INITIAL_COPY");
  }

  const meta = await liveTableColumns();
  setTableMetaCache(meta);
  const copy = await runInitialCopy(target, manifest.snapshot!.path, {
    ...manifest,
  });

  /* replay starts AT the snapshot watermark: events ≤ watermark are already
     inside the snapshot image (replaying them would apply stale pre-snapshot
     values over the copied state — the watermark IS the copy/replay boundary) */
  const watermark = current.snapshotWatermark ?? 0;
  await writeState("CHANGE_CAPTURE", {
    manifest: copy.manifest,
    lastReplayedSequence: watermark,
  });

  /* first catch-up right after the copy — strictly post-watermark events */
  const replay = await replayPendingEvents(
    target,
    meta,
    manifest.migrationId,
    watermark
  );
  if (replay.halted) {
    return { ok: false, from: "CHANGE_CAPTURE", reason: `replay halted: ${replay.halted.reason}` };
  }
  return {
    ok: true,
    from: current.state,
    to: "CHANGE_CAPTURE",
    data: { copiedRows: copy.progress.copiedRows, appliedEvents: replay.applied },
  };
}

/** CHANGE_CAPTURE/REPLAYING: catch-up replay pass. */
export async function replayStep(options: {
  shadowPath?: string;
} = {}): Promise<ActionResult<{ applied: number; pending: number }>> {
  const current = await readState();
  if (
    (current.state !== "CHANGE_CAPTURE" && current.state !== "REPLAYING") ||
    !current.manifest
  ) {
    return { ok: false, from: current.state, reason: `state is ${current.state}, expected CHANGE_CAPTURE` };
  }
  const target = await targetFor(current.manifest, options.shadowPath);
  const meta = await liveTableColumns();
  const replay = await replayPendingEvents(
    target,
    meta,
    current.manifest.migrationId,
    current.lastReplayedSequence
  );
  if (replay.halted) {
    return { ok: false, from: current.state, reason: `replay halted: ${replay.halted.reason}` };
  }
  return {
    ok: true,
    from: current.state,
    to: current.state,
    data: { applied: replay.applied, pending: replay.pendingAfter },
  };
}

/** CHANGE_CAPTURE/REPLAYING → VERIFYING → READY_FOR_CUTOVER (or back). */
export async function verifyStep(options: {
  shadowPath?: string;
} = {}): Promise<ActionResult<{ failures: string[] }>> {
  const current = await readState();
  if (
    (current.state !== "CHANGE_CAPTURE" && current.state !== "REPLAYING") ||
    !current.manifest
  ) {
    return { ok: false, from: current.state, reason: `state is ${current.state}, expected CHANGE_CAPTURE` };
  }
  const target = await targetFor(current.manifest, options.shadowPath);
  const result = await requestCutover(target);
  if (!result.ok) {
    return {
      ok: false,
      from: current.state,
      reason: result.reason ?? "verification failed",
      data: { failures: result.failures ?? [] },
    };
  }
  return { ok: true, from: current.state, to: "READY_FOR_CUTOVER", data: { failures: [] } };
}

export { executeCutover, rollbackToSqlite, archiveSqlite, type CutoverHandle };

/** Finalize a rollback after the operator repointed DATABASE_URL back to
 *  SQLite and restarted (the runbook's `complete-rollback` command).
 *  IDEMPOTENT: an already-steady system is a no-op success; a state that
 *  was never rolled back is an explicit refusal (never auto-destructive). */
export async function completeRollback(): Promise<ActionResult> {
  const current = await readState();
  if (current.state === "SQLITE_ONLY") {
    return { ok: true, from: current.state, to: "SQLITE_ONLY" };
  }
  if (current.state !== "ROLLBACK_WINDOW" && current.state !== "POSTGRES_PRIMARY") {
    return {
      ok: false,
      from: current.state,
      reason:
        `state ${current.state} cannot be completed — run \`rollback\` from ROLLBACK_WINDOW first, repoint DATABASE_URL to SQLite, restart, then complete`,
    };
  }
  /* POSTGRES_PRIMARY → SQLITE_ONLY has no direct edge; walk the legal
     chain POSTGRES_PRIMARY → ROLLBACK_WINDOW → SQLITE_ONLY (each step
     audited by writeState) */
  if (current.state === "POSTGRES_PRIMARY") {
    await updateManifest("ROLLBACK_WINDOW", (m) => {
      m.rollback = { ...m.rollback, executedAt: new Date().toISOString() };
    });
  }
  await updateManifest("SQLITE_ONLY", (m) => {
    m.rollback = { ...m.rollback, completedAt: new Date().toISOString() };
    m.lastError = {
      at: new Date().toISOString(),
      phase: "SQLITE_ONLY",
      message: "rollback completed via complete-rollback command",
    };
  });
  /* ROUND 120 — reset the replay checkpoint with the completion: the run
   * is OVER, and a stale lastReplayedSequence would make the NEXT run's
   * replay skip re-numbered events (an abortMigration clear restarts the
   * event sequence at 1) and the cutover's watermark equality check would
   * rightly refuse. Steady state carries a clean checkpoint. */
  await writeState("SQLITE_ONLY", { lastReplayedSequence: 0, failedReplays: 0 });
  return { ok: true, from: current.state, to: "SQLITE_ONLY" };
}

/** Full dry-run pipeline against a sqlite-shadow target (test/sandbox). */
export async function runShadowDryRun(shadowPath: string): Promise<{
  ok: boolean;
  steps: Array<{ step: string; ok: boolean; detail?: string }>;
}> {
  const steps: Array<{ step: string; ok: boolean; detail?: string }> = [];
  const track = (step: string, r: { ok: boolean; reason?: string; data?: unknown }) => {
    steps.push({ step, ok: r.ok, detail: r.reason ?? JSON.stringify(r.data ?? {}).slice(0, 200) });
    return r.ok;
  };

  const prep = await beginPreparation({ shadowPath });
  if (!track("preparation", prep)) return { ok: false, steps };
  const snap = await snapshotStep();
  if (!track("snapshot", snap)) return { ok: false, steps };
  const copy = await copyStep({ shadowPath });
  if (!track("copy", copy)) return { ok: false, steps };
  const verify = await verifyStep({ shadowPath });
  if (!track("verification", verify)) return { ok: false, steps };
  return { ok: true, steps };
}

/** Abort an in-flight migration back to steady state (operator action). */
export async function abortMigration(): Promise<ActionResult> {
  const current = await readState();
  const abortable: MigrationStateName[] = [
    "PREPARING",
    "SNAPSHOT_CREATED",
    "INITIAL_COPY",
    "CHANGE_CAPTURE",
    "REPLAYING",
    "VERIFYING",
    "READY_FOR_CUTOVER",
    "QUIESCING", /* ROUND 120 — a persisted-but-unfrozen quiesce (freeze-holder died or openExclusive failed) is abortable to steady state */
  ];
  if (!abortable.includes(current.state)) {
    return { ok: false, from: current.state, reason: `state ${current.state} cannot be aborted to steady state` };
  }
  await uninstallTriggers();
  await writeState("SQLITE_ONLY", {
    migrationId: null,
    manifest: null,
    lastReplayedSequence: 0,
    snapshotWatermark: null,
    failedReplays: 0,
  });
  /* confirm the singleton reset (writeState same-state upsert keeps row) */
  await controlDb().migrationState.update({
    where: { id: "singleton" },
    data: { migrationId: null, manifestJson: null },
  });
  /* the capture log + seal chain belong to the run — a fresh preparation
     must not see stale events above its (zero) watermark */
  await controlDb().$executeRawUnsafe(`DELETE FROM "MigrationEvent"`);
  await controlDb().$executeRawUnsafe(`DELETE FROM "MigrationEventSeal"`);
  migLog.info("migration.aborted", { phase: "SQLITE_ONLY", result: "steady state restored" });
  return { ok: true, from: current.state, to: "SQLITE_ONLY" };
}

/** Pending event count helper for health reporting. */
export async function replicationLag(): Promise<number> {
  const current = await readState();
  if (!current.migrationId) return 0;
  const watermark = await currentWatermark();
  return Math.max(0, watermark - current.lastReplayedSequence);
}
