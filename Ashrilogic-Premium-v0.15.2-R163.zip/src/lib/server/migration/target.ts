/**
 * Ashrilogic — migration target adapters (SQLite → PostgreSQL).
 *
 * The controller talks to the target through ONE interface with two
 * implementations:
 *
 *  - PostgresTarget     — the real thing. Provisioned via
 *    DATABASE_URL_POSTGRES (schema created by the operator with
 *    `prisma db push --schema prisma/schema.postgres.prisma --skip-generate`,
 *    verified by ping() before ANY copy phase may start). Uses node-postgres
 *    with parameterized statements only — identifiers are validated against
 *    a strict identifier regex and values never touch SQL text.
 *
 *  - SqliteShadowTarget — a standalone SQLite file standing in for the
 *    target (dry-run + the sandbox test path): schema-cloned from the
 *    migration snapshot, business rows cleared, capture triggers removed.
 *    It exercises the ENTIRE controller (copy, replay, verification,
 *    cutover gates) without a PostgreSQL server. It is a test harness, not
 *    a deployment mode.
 *
 * Both adapters normalize reads back to the canonical SQLite value form
 * (dates → ms integers, booleans → 0/1) so the verification battery compares
 * engines apples-to-apples.
 */

import { createHash } from "node:crypto";
import { copyFileSync, existsSync } from "node:fs";
import { controlDb } from "./control-db";
import {
  BUSINESS_TABLES,
  toCanonicalValue,
  toPostgresValue,
  type TableColumns,
} from "./tables";
import { migLog } from "./logger";

const IDENT_RE = /^[A-Za-z_][A-Za-z0-9_]*$/;

function q(name: string): string {
  if (!IDENT_RE.test(name)) throw new Error(`unsafe identifier: ${name}`);
  return `"${name}"`;
}

export interface PingResult {
  ok: boolean;
  missingTables: string[];
}

export interface MigrationTarget {
  readonly kind: "postgres" | "sqlite-shadow";
  /** Safe display descriptor — a DSN is NEVER persisted or logged raw. */
  descriptor(): string;
  ping(): Promise<PingResult>;
  upsertRow(
    table: string,
    meta: TableColumns,
    row: Record<string, unknown>
  ): Promise<void>;
  deleteRow(table: string, meta: TableColumns, pkValue: string): Promise<void>;
  countRows(table: string): Promise<number>;
  countByTenant(table: string): Promise<Map<string, number>>;
  readRows(
    table: string,
    meta: TableColumns,
    afterPk: string | null,
    limit: number
  ): Promise<Record<string, unknown>[]>;
  readRowByPk(
    table: string,
    meta: TableColumns,
    pkValue: string
  ): Promise<Record<string, unknown> | null>;
  close(): Promise<void>;
}

/* ------------------------------ shadow target ------------------------------ */

export interface ShadowHandle {
  target: MigrationTarget;
  path: string;
}

/**
 * Create a sqlite-shadow target from the migration snapshot: copy the file,
 * clear every business table (reverse FK order), drop the capture triggers
 * the snapshot carries, and clear the copied event log. The result is an
 * empty schema-faithful target with all constraints live.
 */
export async function createShadowFromSnapshot(
  snapshotPath: string,
  shadowPath: string
): Promise<ShadowHandle> {
  if (!existsSync(snapshotPath)) {
    throw new Error(`snapshot not found: ${snapshotPath}`);
  }
  copyFileSync(snapshotPath, shadowPath);
  const { Database } = await import("bun:sqlite");
  const sqlite = new Database(shadowPath);
  try {
    sqlite.exec("PRAGMA foreign_keys = OFF");
    for (const table of [...BUSINESS_TABLES].reverse()) {
      sqlite.exec(`DELETE FROM ${q(table)}`);
    }
    for (const row of sqlite
      .query("SELECT name FROM sqlite_master WHERE type='trigger' AND name LIKE '_mig_%'")
      .all() as { name: string }[]) {
      sqlite.exec(`DROP TRIGGER IF EXISTS ${q(row.name)}`);
    }
    try {
      sqlite.exec(`DELETE FROM "MigrationEvent"`);
      sqlite.exec(`DELETE FROM "MigrationState"`);
    } catch {
      /* infra tables absent in a foreign snapshot — the shadow does not need them */
    }
    sqlite.exec("PRAGMA foreign_keys = ON");
    sqlite.close();
  } catch (e) {
    sqlite.close();
    throw e;
  }
  return { target: new SqliteShadowTarget(shadowPath), path: shadowPath };
}

/** Open an EXISTING shadow target (resume path — never re-initializes:
 *  re-creating would wipe the copied state and verification would rightly
 *  fail with every table empty). Throws when the file is absent. */
export function openShadowTarget(shadowPath: string): MigrationTarget {
  if (!existsSync(shadowPath)) {
    throw new Error(
      `shadow target not found: ${shadowPath} — run the copy phase first (or shadow-run)`
    );
  }
  return new SqliteShadowTarget(shadowPath);
}

class SqliteShadowTarget implements MigrationTarget {
  readonly kind = "sqlite-shadow" as const;
  constructor(private readonly path: string) {}

  descriptor(): string {
    return `sqlite-shadow:${this.path}`;
  }

  private async withDb<T>(
    fn: (sqlite: import("bun:sqlite").Database) => T | Promise<T>
  ): Promise<T> {
    const { Database } = await import("bun:sqlite");
    const sqlite = new Database(this.path);
    try {
      return await fn(sqlite);
    } finally {
      sqlite.close();
    }
  }

  async ping(): Promise<PingResult> {
    return this.withDb((sqlite) => {
      const missing: string[] = [];
      for (const table of BUSINESS_TABLES) {
        const row = sqlite
          .query("SELECT COUNT(*) AS c FROM sqlite_master WHERE type='table' AND name = ?")
          .get(table) as { c: number };
        if (row.c === 0) missing.push(table);
      }
      return { ok: missing.length === 0, missingTables: missing };
    });
  }

  async upsertRow(
    table: string,
    meta: TableColumns,
    row: Record<string, unknown>
  ): Promise<void> {
    await this.withDb((sqlite) => {
      const cols = meta.columns.map((c) => q(c));
      const placeholders = meta.columns.map(() => "?").join(", ");
      const values = meta.columns.map((c) =>
        c === meta.pk ? row[c] : normalizeForSqlite(row[c])
      );
      const updates = meta.columns
        .filter((c) => c !== meta.pk)
        .map((c) => `${q(c)} = excluded.${q(c)}`)
        .join(", ");
      sqlite
        .query(
          `INSERT INTO ${q(table)} (${cols.join(", ")}) VALUES (${placeholders})
           ON CONFLICT(${q(meta.pk)}) DO UPDATE SET ${updates}`
        )
        .run(...(values as unknown[] as import("bun:sqlite").SQLQueryBindings[]));
      return undefined;
    });
  }

  async deleteRow(
    table: string,
    _meta: TableColumns,
    pkValue: string
  ): Promise<void> {
    await this.withDb((sqlite) => {
      sqlite
        .query(`DELETE FROM ${q(table)} WHERE "id" = ?`)
        .run(pkValue);
      return undefined;
    });
  }

  async countRows(table: string): Promise<number> {
    return this.withDb((sqlite) =>
      Number((sqlite.query(`SELECT COUNT(*) AS c FROM ${q(table)}`).get() as { c: number }).c)
    );
  }

  async countByTenant(table: string): Promise<Map<string, number>> {
    return this.withDb((sqlite) => {
      const rows = sqlite
        .query(`SELECT "instanceId" AS t, COUNT(*) AS c FROM ${q(table)} GROUP BY "instanceId"`)
        .all() as { t: string; c: number }[];
      return new Map(rows.map((r) => [r.t, Number(r.c)]));
    });
  }

  async readRows(
    table: string,
    meta: TableColumns,
    afterPk: string | null,
    limit: number
  ): Promise<Record<string, unknown>[]> {
    return this.withDb((sqlite) => {
      const rows = afterPk
        ? (sqlite
            .query(`SELECT * FROM ${q(table)} WHERE ${q(meta.pk)} > ? ORDER BY ${q(meta.pk)} ASC LIMIT ?`)
            .all(afterPk, limit) as Record<string, unknown>[])
        : (sqlite
            .query(`SELECT * FROM ${q(table)} ORDER BY ${q(meta.pk)} ASC LIMIT ?`)
            .all(limit) as Record<string, unknown>[]);
      return rows;
    });
  }

  async readRowByPk(
    table: string,
    meta: TableColumns,
    pkValue: string
  ): Promise<Record<string, unknown> | null> {
    return this.withDb((sqlite) =>
      (sqlite
        .query(`SELECT * FROM ${q(table)} WHERE ${q(meta.pk)} = ?`)
        .get(pkValue) as Record<string, unknown> | null) ?? null
    );
  }

  async close(): Promise<void> {
    /* per-operation connections — nothing to hold */
  }
}

/** SQLite write normalization (shadow target already speaks SQLite forms). */
function normalizeForSqlite(v: unknown): unknown {
  if (v === undefined) return null;
  if (v instanceof Date) return v.getTime();
  if (typeof v === "boolean") return v ? 1 : 0;
  return v;
}

/* ------------------------------ postgres target ----------------------------- */

export interface PostgresTargetOptions {
  /** Raw DSN — used for the connection, never logged or persisted. */
  dsn: string;
}

export async function createPostgresTarget(
  options: PostgresTargetOptions
): Promise<MigrationTarget> {
  const { Client } = await import("pg");
  const client = new Client({ connectionString: options.dsn });
  await client.connect();
  return new PostgresTarget(client, options.dsn);
}

class PostgresTarget implements MigrationTarget {
  readonly kind = "postgres" as const;
  constructor(
    private readonly client: import("pg").Client,
    private readonly dsn: string
  ) {}

  descriptor(): string {
    const digest = createHash("sha256").update(this.dsn, "utf8").digest("hex").slice(0, 12);
    return `postgres:<dsn-sha256:${digest}>`;
  }

  async ping(): Promise<PingResult> {
    const res = await this.client.query(
      `SELECT table_name FROM information_schema.tables
       WHERE table_schema = 'public'`
    );
    const present = new Set(res.rows.map((r: { table_name: string }) => r.table_name));
    const missing = BUSINESS_TABLES.filter((t) => !present.has(t));
    return { ok: missing.length === 0, missingTables: missing };
  }

  async upsertRow(
    table: string,
    meta: TableColumns,
    row: Record<string, unknown>
  ): Promise<void> {
    const cols = meta.columns.map((c) => q(c));
    const placeholders = meta.columns.map((_, i) => `$${i + 1}`).join(", ");
    const values = meta.columns.map((c) => {
      const raw = c === meta.pk ? row[c] : row[c] ?? null;
      return toPostgresValue(raw, meta.types.get(c) ?? "TEXT");
    });
    const updates = meta.columns
      .filter((c) => c !== meta.pk)
      .map((c, i) => `${q(c)} = EXCLUDED.${q(c)}`)
      .join(", ");
    const conflictIdx = meta.columns.indexOf(meta.pk) + 1;
    await this.client.query(
      `INSERT INTO ${q(table)} (${cols.join(", ")}) VALUES (${placeholders})
       ON CONFLICT (${q(meta.pk)}) DO UPDATE SET ${updates}`,
      values
    );
    void conflictIdx;
  }

  async deleteRow(
    table: string,
    _meta: TableColumns,
    pkValue: string
  ): Promise<void> {
    await this.client.query(`DELETE FROM ${q(table)} WHERE "id" = $1`, [pkValue]);
  }

  async countRows(table: string): Promise<number> {
    const res = await this.client.query(`SELECT COUNT(*)::int AS c FROM ${q(table)}`);
    return Number(res.rows[0]?.c ?? 0);
  }

  async countByTenant(table: string): Promise<Map<string, number>> {
    const res = await this.client.query(
      `SELECT "instanceId" AS t, COUNT(*)::int AS c FROM ${q(table)} GROUP BY "instanceId"`
    );
    return new Map(
      res.rows.map((r: { t: string; c: number }) => [r.t, Number(r.c)])
    );
  }

  async readRows(
    table: string,
    meta: TableColumns,
    afterPk: string | null,
    limit: number
  ): Promise<Record<string, unknown>[]> {
    const res = afterPk
      ? await this.client.query(
          `SELECT * FROM ${q(table)} WHERE ${q(meta.pk)} > $1 ORDER BY ${q(meta.pk)} ASC LIMIT $2`,
          [afterPk, limit]
        )
      : await this.client.query(
          `SELECT * FROM ${q(table)} ORDER BY ${q(meta.pk)} ASC LIMIT $1`,
          [limit]
        );
    return res.rows.map((row: Record<string, unknown>) => {
      const canonical: Record<string, unknown> = {};
      for (const [col, value] of Object.entries(row)) {
        canonical[col] = toCanonicalValue(value, meta.types.get(col) ?? "TEXT");
      }
      return canonical;
    });
  }

  async readRowByPk(
    table: string,
    meta: TableColumns,
    pkValue: string
  ): Promise<Record<string, unknown> | null> {
    const res = await this.client.query(
      `SELECT * FROM ${q(table)} WHERE ${q(meta.pk)} = $1`,
      [pkValue]
    );
    const row = res.rows[0] as Record<string, unknown> | undefined;
    if (!row) return null;
    const canonical: Record<string, unknown> = {};
    for (const [col, value] of Object.entries(row)) {
      canonical[col] = toCanonicalValue(value, meta.types.get(col) ?? "TEXT");
    }
    return canonical;
  }

  async close(): Promise<void> {
    await this.client.end();
    migLog.info("target.postgres.closed", {});
  }
}

/** Resolve the configured target from the environment (postgres when
 *  DATABASE_URL_POSTGRES is provisioned; throws otherwise — the shadow
 *  target is constructed explicitly by tooling/tests, not implicitly). */
export async function resolveConfiguredTarget(): Promise<MigrationTarget> {
  const dsn = process.env.DATABASE_URL_POSTGRES?.trim();
  if (!dsn) {
    throw new Error(
      "DATABASE_URL_POSTGRES is not provisioned — provide a PostgreSQL target or run the shadow dry-run explicitly"
    );
  }
  return createPostgresTarget({ dsn });
}

/** Column metadata for every business table from the LIVE SQLite schema. */
export async function liveTableColumns(): Promise<Map<string, TableColumns>> {
  const { tableColumnsOf } = await import("./tables");
  const cache = new Map<string, { name: string; type: string; pk: number }[]>();
  for (const table of BUSINESS_TABLES) {
    cache.set(
      table,
      (await controlDb().$queryRawUnsafe(
        `SELECT name, type, pk FROM pragma_table_info('${table}')`
      )) as { name: string; type: string; pk: number }[]
    );
  }
  return tableColumnsOf((table) => cache.get(table) ?? []);
}
