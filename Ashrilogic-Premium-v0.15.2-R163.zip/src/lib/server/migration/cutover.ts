/**
 * Ashrilogic — migration cutover (SQLite → PostgreSQL).
 *
 * CUTOVER SEQUENCE (each step gated; ANY failure aborts with the SQLite
 * source untouched — a partially-cut-over system is structurally impossible):
 *
 *   requestCutover():  READY_FOR_CUTOVER required. Catches replay up, runs
 *                      the full verification battery; failures send the run
 *                      back to CHANGE_CAPTURE with the report recorded.
 *
 *   executeCutover():  write freeze (BEGIN EXCLUSIVE on a dedicated
 *                      connection — every other writer, including the app's
 *                      Prisma pool, blocks) → drain in-flight writes →
 *                      flush remaining events → final watermark check →
 *                      FINAL full verification on the frozen source →
 *                      CUTOVER state + operator runbook. The freeze is HELD
 *                      (the handle keeps the transaction open) while the
 *                      operator repoints DATABASE_URL and restarts.
 *
 *   confirmPostgresPrimary(): operator confirms the app serves from
 *                      PostgreSQL → lock released → POSTGRES_PRIMARY →
 *                      ROLLBACK_WINDOW (retention: snapshot, manifest,
 *                      checkpoints, verification reports — all preserved).
 *
 *   abortCutover():    releases the freeze and returns to CHANGE_CAPTURE —
 *                      SQLite remained primary throughout; nothing to undo.
 *
 *   rollbackToSqlite(): only during ROLLBACK_WINDOW. The SQLite source was
 *                      FROZEN at cutover and never written after, so the
 *                      reverse direction needs NO migration — rollback is
 *                      repointing DATABASE_URL back and restarting. ROUND
 *                      120: the reverse-sync tool salvages the primary-period
 *                      writes BEFORE the repoint (see reverse-sync.ts) — the
 *                      documented trade-off is closed by tooling, not by hope.
 */

import { readState, updateManifest, canTransition, writeState } from "./state-machine";
import { currentWatermark, pendingEventCount } from "./change-capture";
import { replayPendingEvents } from "./replay";
import { runVerification } from "./verify";
import { rawAccess } from "./sqlite-access";
import { liveTableColumns, type MigrationTarget } from "./target";
import { migLog } from "./logger";
import { controlDb, sqliteControlPath } from "./control-db";

/** Configurable rollback window (hours) — env-tunable per deployment. */
const ROLLBACK_WINDOW_HOURS = Number(process.env.MIGRATION_ROLLBACK_WINDOW_HOURS ?? 72);

export interface CutoverHandle {
  /** releases the write freeze and rolls the state back to CHANGE_CAPTURE */
  abort(): Promise<void>;
  /** operator confirmed PG is primary — release + POSTGRES_PRIMARY */
  confirm(): Promise<{ ok: boolean; reason?: string }>;
  /** the migrationId of the run */
  migrationId: string;
}

/** ROUND 121 — SPLIT-BRAIN REGRESSION (proven empirically, see
 * tests/security/sqlite-wal-splitbrain.test.ts):
 *
 * SQLite deletes the -wal/-shm sidecars when the last connection to a WAL
 * database CLOSES. The app's Prisma pool is an in-process Rust engine
 * whose open file descriptors are INVISIBLE to that "last connection"
 * check — a bun:sqlite connection that took BEGIN EXCLUSIVE and then
 * closed DELETED the live WAL under the engine. The engine kept writing
 * into the DELETED INODE (its fds stay valid), so every subsequent commit
 * became permanently invisible to every new reader: a silent split-brain.
 * Observed as the cutover watermark gate bouncing healthy runs
 * ("replayed N ≠ committed N-1") and as stale MigrationEvent views.
 *
 * THE FIX: the freeze connection is a per-process, per-file KEEPER — it is
 * opened once and NEVER closed. release() rolls the exclusive transaction
 * back (releasing the freeze) but keeps the connection (and therefore the
 * WAL) alive for the whole process lifetime. */
const globalForFreeze = globalThis as unknown as {
  ashrilogicFreezeKeepers?: Map<string, import("bun:sqlite").Database>;
};

async function freezeKeeper(dbFile: string): Promise<import("bun:sqlite").Database> {
  const { Database } = await import("bun:sqlite");
  let keepers = globalForFreeze.ashrilogicFreezeKeepers;
  if (!keepers) {
    keepers = new Map();
    globalForFreeze.ashrilogicFreezeKeepers = keepers;
  }
  const existing = keepers.get(dbFile);
  if (existing) return existing;
  const sqlite = new Database(dbFile);
  sqlite.exec("PRAGMA busy_timeout = 10000");
  keepers.set(dbFile, sqlite);
  return sqlite;
}

/** Open the SQLite file path from DATABASE_URL (bun:sqlite connection). */
async function openExclusive(dbFileOverride?: string): Promise<{
  sqlite: import("bun:sqlite").Database;
  release: () => Promise<void>;
}> {
  /* the freeze always targets the CONTROL-PLANE SQLite file (resolved via
     ASHRILOGIC_SQLITE_FILE or a file: DATABASE_URL) — never whatever the
     app happens to point at post-cutover */
  const dbFile = dbFileOverride ?? sqliteControlPath();
  if (!dbFile) throw new Error("SQLite control plane not resolvable");
  const sqlite = await freezeKeeper(dbFile);
  sqlite.exec("PRAGMA busy_timeout = 10000");

  /* ROUND 121 — WAL CHECKPOINT *BEFORE* THE FREEZE (outside any
   * transaction). The R120 placement ran the checkpoint INSIDE BEGIN
   * EXCLUSIVE, where SQLite refuses it — every run threw SQLITE_LOCKED
   * ("database table is locked") and the swallowing catch made the whole
   * "WAL checkpoint under freeze" a silent NO-OP (proven empirically).
   * Outside the transaction the checkpoint actually runs: committed WAL
   * frames are merged into the main file and the WAL is reset, so the
   * watermark reads below resolve against the true committed state.
   * busy=1 (another reader holds an old snapshot) merely means a partial
   * checkpoint — harmless, the shm-coordinated reads stay correct. */
  try {
    sqlite.query("PRAGMA wal_checkpoint(TRUNCATE)").all();
  } catch {
    /* non-WAL journal modes / transient refusal — the shm-coordinated
     * reads below remain correct without the checkpoint */
  }

  /* BEGIN EXCLUSIVE = the write freeze: no other connection may write
     (readers under WAL continue). Held until commit/rollback. */
  sqlite.exec("BEGIN EXCLUSIVE");
  return {
    sqlite,
    release: async () => {
      /* ROLL BACK the exclusive transaction (releases the freeze) but DO
       * NOT CLOSE the keeper connection — closing would delete -wal/-shm
       * out from under the Prisma engine (see freezeKeeper). The keeper
       * stays open for the process lifetime; it holds no locks once the
       * transaction is rolled back. */
      sqlite.exec("ROLLBACK");
    },
  };
}

/**
 * Pre-cutover gate: catch up replay, then run the full verification battery.
 * FAILURES ARE FINAL HERE — the run returns to CHANGE_CAPTURE with the
 * report persisted; cutover NEVER proceeds on a failed report.
 */
export async function requestCutover(
  target: MigrationTarget
): Promise<{ ok: boolean; reason?: string; failures?: string[] }> {
  const current = await readState();
  if (current.state !== "READY_FOR_CUTOVER") {
    /* allow re-request from CHANGE_CAPTURE/REPLAYING after a prior verify */
    if (current.state !== "CHANGE_CAPTURE" && current.state !== "REPLAYING") {
      return { ok: false, reason: `state is ${current.state}, expected READY_FOR_CUTOVER` };
    }
  }
  const manifest = current.manifest;
  if (!manifest) return { ok: false, reason: "missing manifest" };

  const meta = await liveTableColumns();
  const catchUp = await replayPendingEvents(
    target,
    meta,
    manifest.migrationId,
    current.lastReplayedSequence
  );
  if (catchUp.halted) {
    return { ok: false, reason: `replay halted at #${catchUp.halted.sequence}: ${catchUp.halted.reason}` };
  }
  const pending = await pendingEventCount(catchUp.lastSequence);
  if (pending > 0) {
    return { ok: false, reason: `replication lag remains (${pending} events) — retry` };
  }

  const report = await runVerification(target, meta, pending);
  await updateManifest(
    current.state === "READY_FOR_CUTOVER" || canTransition(current.state, "VERIFYING")
      ? "VERIFYING"
      : current.state,
    (m) => {
      m.verification = {
        ranAt: report.ranAt,
        ok: report.ok,
        checks: report.checks.length,
        failures: report.failures.slice(0, 50),
        reportDigest: report.digest,
      };
    }
  );

  if (!report.ok) {
    /* verification failure → ABORT the cutover attempt, keep replicating */
    if (canTransition("VERIFYING", "CHANGE_CAPTURE")) {
      await updateManifest("CHANGE_CAPTURE", () => undefined);
    }
    return {
      ok: false,
      reason: "verification failed",
      failures: report.failures,
    };
  }
  await updateManifest("READY_FOR_CUTOVER", (m) => {
    m.cutover = { requestedAt: new Date().toISOString() };
  });
  return { ok: true };
}

/**
 * The real cutover: freeze → drain → flush → final verify → hold.
 *
 * CRASH-SAFETY CONTRACT: the SQLite state row is NOT touched while the
 * exclusive freeze is held — the write would sit uncommitted inside the
 * lock-holder transaction (invisible to every other connection). The
 * persisted state stays READY_FOR_CUTOVER for the whole freeze: a crash
 * mid-cutover rolls the transaction back, releases the lock, and leaves
 * the run exactly where it was (nothing changed, nothing half-cut-over).
 * The CUTOVER phase is a RUNTIME fact owned by the returned handle; the
 * confirm/abort closures persist the outcome AFTER releasing the freeze.
 *
 * The returned handle owns the freeze; the calling process MUST keep
 * running until confirm() or abort().
 */
export async function executeCutover(
  target: MigrationTarget,
  dbFileOverride?: string
): Promise<
  | {
      ok: true;
      handle: CutoverHandle;
      frozen: {
        frozenAt: string;
        finalWatermark: number;
        verifiedAt: string;
        operatorSteps: string[];
      };
    }
  | { ok: false; reason: string; failures?: string[] }
> {
  const current = await readState();
  if (current.state !== "READY_FOR_CUTOVER") {
    return { ok: false, reason: `state is ${current.state}, expected READY_FOR_CUTOVER` };
  }
  const manifest = current.manifest;
  if (!manifest) return { ok: false, reason: "missing manifest" };

  /* ROUND 120 — persist QUIESCING BEFORE the freeze: /api/readyz's
   * migration-draining 503 now covers the REAL write-freeze window (the
   * pre-120 drain states were never persisted during the actual freeze,
   * so the LB kept routing and writes failed hard instead of draining).
   * Crash between this write and the freeze: the boot reconciler's
   * mid-cutover-crash path (QUIESCING with no live holder) flags the
   * state for operator resolution — never auto-destructive. */
  try {
    await writeState("QUIESCING", { manifest, migrationId: manifest.migrationId });
  } catch (error) {
    return {
      ok: false,
      reason: `quiesce transition failed (concurrent controller?): ${
        error instanceof Error ? error.message : String(error)
      }`,
    };
  }
  const bounceFromQuiesce = async (phase: string, message: string) => {
    try {
      await updateManifest("CHANGE_CAPTURE", (m) => {
        m.lastError = { at: new Date().toISOString(), phase, message: message.slice(0, 500) };
      });
    } catch {
      /* the state stayed QUIESCING — the reconciler's mid-cutover-crash
       * path takes over at the next boot; log it loudly */
      migLog.error("cutover.bounce-failed", {
        migrationId: manifest.migrationId,
        phase: "QUIESCING",
        result: `${phase}: ${message.slice(0, 200)}`,
      });
    }
  };

  let lock: Awaited<ReturnType<typeof openExclusive>>;
  try {
    lock = await openExclusive(dbFileOverride);
  } catch (e) {
    await bounceFromQuiesce("CUTOVER", `write freeze failed: ${e instanceof Error ? e.message : String(e)}`);
    return { ok: false, reason: `write freeze failed: ${e instanceof Error ? e.message : String(e)}` };
  }
  const sql = rawAccess(lock.sqlite);

  try {
    /* every controller access flows through the lock-holder connection */
    const meta = await liveTableColumns();

    /* flush every event committed before the freeze */
    const flush = await replayPendingEvents(
      target,
      meta,
      manifest.migrationId,
      current.lastReplayedSequence,
      100_000,
      sql
    );
    if (flush.halted) {
      await lock.release();
      await bounceFromQuiesce("CUTOVER", `flush halted at #${flush.halted.sequence}: ${flush.halted.reason}`);
      return {
        ok: false,
        reason: `flush halted at #${flush.halted.sequence}: ${flush.halted.reason}`,
      };
    }

    /* final watermark — with the freeze held, no new events can appear
       (read through the lock-holder connection; the pool is frozen) */
    const watermark = await currentWatermark(sql);
    if (flush.lastSequence !== watermark) {
      await lock.release();
      migLog.error("cutover.watermark-mismatch", {
        migrationId: manifest.migrationId,
        phase: "CUTOVER",
        result: `replayed ${flush.lastSequence} ≠ committed ${watermark}`,
      });
      await bounceFromQuiesce(
        "CUTOVER",
        `final watermark mismatch: replayed ${flush.lastSequence} ≠ committed ${watermark}`
      );
      return {
        ok: false,
        reason: `final watermark mismatch: replayed ${flush.lastSequence} ≠ committed ${watermark}`,
      };
    }

    /* FINAL integrity verification — source is frozen, so this report is
       exact; any failure aborts with NOTHING changed */
    const report = await runVerification(target, meta, 0, sql);
    if (!report.ok) {
      await lock.release();
      await bounceFromQuiesce(
        "CUTOVER",
        `final verification failed: ${report.failures.slice(0, 3).join("; ")}`
      );
      return {
        ok: false,
        reason: "final verification failed — cutover aborted",
        failures: report.failures,
      };
    }

    const frozen = {
      frozenAt: new Date().toISOString(),
      finalWatermark: watermark,
      verifiedAt: report.ranAt,
      operatorSteps: [
        "1. Keep the cutover process RUNNING (it holds the SQLite write freeze).",
        `2. Repoint the app: set DATABASE_URL to the PostgreSQL DSN (${target.descriptor()}).`,
        "3. Restart the application; verify GET /api/status reports the PostgreSQL health.",
        "4. bun scripts/pg-migrate.ts confirm-primary",
        "5. To abort instead: bun scripts/pg-migrate.ts abort-cutover",
      ],
    };

    migLog.info("cutover.frozen", {
      migrationId: manifest.migrationId,
      phase: "CUTOVER",
      sequence: watermark,
      result: "holding write freeze — awaiting operator confirmation",
    });

    return {
      ok: true,
      frozen,
      handle: {
        migrationId: manifest.migrationId,
        abort: async () => {
          /* release the freeze and bounce QUIESCING → CHANGE_CAPTURE (the
           * documented abort-cutover transition): SQLite was primary
           * throughout, capture resumes, the run may re-attempt */
          await lock.release();
          try {
            await writeState("CHANGE_CAPTURE", { manifest, migrationId: manifest.migrationId });
          } catch {
            /* concurrent writer moved the row — the reconciler resolves */
          }
          migLog.info("cutover.aborted", {
            migrationId: manifest.migrationId,
            phase: "CHANGE_CAPTURE",
            result: "freeze released — SQLite remained primary, capture resumed",
          });
        },
        confirm: async () => {
          /* integrity of the frozen source before it becomes the rollback
             artifact — an unverifiable rollback anchor blocks confirmation */
          const integrity = await sql.query<{ integrity_check: string }>(
            "PRAGMA integrity_check"
          );
          if (integrity[0]?.integrity_check !== "ok") {
            return {
              ok: false,
              reason: "SQLite integrity_check failed on the frozen source — do not proceed",
            };
          }
          /* persist the cutover record + open the rollback window — AFTER
             releasing the freeze so the writes are visible and durable.
             ROUND 120 — the outcome is persisted THROUGH the state machine
             (CUTOVER → POSTGRES_PRIMARY → ROLLBACK_WINDOW) so the
             legal-transition validator and the state.transition audit
             trail cover the flip; the pre-120 raw update bypassed both. */
          await lock.release();
          manifest.cutover = {
            requestedAt: manifest.cutover?.requestedAt ?? frozen.frozenAt,
            frozenAt: frozen.frozenAt,
            finalWatermark: frozen.finalWatermark,
            verifiedAt: frozen.verifiedAt,
          };
          manifest.rollback = {
            windowClosesAt: new Date(
              Date.now() + ROLLBACK_WINDOW_HOURS * 3600_000
            ).toISOString(),
          };
          try {
            await writeState("CUTOVER", { manifest, migrationId: manifest.migrationId });
            await writeState("POSTGRES_PRIMARY", { manifest, migrationId: manifest.migrationId });
            await writeState("ROLLBACK_WINDOW", { manifest, migrationId: manifest.migrationId });
          } catch (error) {
            return {
              ok: false,
              reason: `outcome persistence failed (concurrent controller?): ${
                error instanceof Error ? error.message : String(error)
              } — the freeze was released; run reconcile or confirm-primary again`,
            };
          }
          migLog.info("cutover.confirmed", {
            migrationId: manifest.migrationId,
            phase: "ROLLBACK_WINDOW",
            result: `PostgreSQL is primary · rollback window ${ROLLBACK_WINDOW_HOURS}h`,
          });
          return { ok: true };
        },
      },
    };
  } catch (error) {
    await lock.release();
    const message = error instanceof Error ? error.message : String(error);
    await bounceFromQuiesce("CUTOVER", message);
    return { ok: false, reason: `cutover error: ${message}` };
  }
}

/**
 * Explicit rollback during the window. The frozen SQLite source is the
 * complete cutover-time state; ROUND 120's reverse-sync tooling (bun
 * scripts/pg-migrate.ts reverse-sync --audit|--apply) salvages the
 * PostgreSQL-primary-period writes into the source BEFORE this step —
 * rollback is no longer "re-apply manually if required". The app repoints
 * DATABASE_URL back to SQLite and restarts; the controller verifies the
 * source file's integrity first and clears to steady state.
 */
export async function rollbackToSqlite(
  dbFileOverride?: string,
  opts: { force?: boolean } = {}
): Promise<{ ok: boolean; reason?: string; steps?: string[] }> {
  const current = await readState();
  if (current.state !== "ROLLBACK_WINDOW") {
    return { ok: false, reason: `state is ${current.state}, expected ROLLBACK_WINDOW` };
  }
  const manifest = current.manifest;
  if (!manifest) return { ok: false, reason: "missing manifest" };

  /* ROUND 120 — the rollback window is ENFORCED, not advisory: past the
   * window the operator must acknowledge with --force (the window bounds
   * the exposure the reverse-sync exists to close). */
  const closesAt = manifest.rollback?.windowClosesAt;
  if (closesAt && Date.parse(closesAt) < Date.now() && !opts.force) {
    return {
      ok: false,
      reason: `rollback window closed at ${closesAt} — pass --force to roll back anyway (reverse-sync the primary-period writes first: bun scripts/pg-migrate.ts reverse-sync --audit)`,
    };
  }

  const { Database } = await import("bun:sqlite");
  const dbFile = dbFileOverride ?? sqliteControlPath();
  if (!dbFile) return { ok: false, reason: "SQLite control plane not resolvable" };
  const sqlite = new Database(dbFile, { readonly: true });
  const integrity = sqlite.query("PRAGMA integrity_check").get() as
    | { integrity_check: string }
    | undefined;
  sqlite.close();
  if (integrity?.integrity_check !== "ok") {
    return { ok: false, reason: "frozen SQLite source failed integrity_check — investigate before rollback" };
  }

  const steps = [
    "1. Salvage the primary-period writes: bun scripts/pg-migrate.ts reverse-sync --audit (review) then --apply (idempotent).",
    "2. Stop the application.",
    "3. Restore DATABASE_URL to the SQLite file path (pre-cutover value).",
    "4. Restart the application; verify GET /api/status.",
    "5. Run: bun scripts/pg-migrate.ts complete-rollback",
  ];
  /* The state stays ROLLBACK_WINDOW (with the execution recorded) until the
   * operator completes the repoint — complete-rollback (or the boot-time
   * split-brain reconciler) flips it to SQLITE_ONLY only once SQLite is
   * genuinely serving again. Never mark the primary flipped before it is. */
  await updateManifest("ROLLBACK_WINDOW", (m) => {
    m.rollback = { ...m.rollback, executedAt: new Date().toISOString() };
  });
  migLog.info("rollback.executed", {
    migrationId: manifest.migrationId,
    phase: "ROLLBACK_WINDOW",
    result: "rollback initiated — SQLite repoint pending (finalize with complete-rollback)",
  });
  return { ok: true, steps };
}

/** Close the rollback window — archive the SQLite source (files retained). */
export async function archiveSqlite(): Promise<{ ok: boolean; reason?: string }> {
  const current = await readState();
  if (current.state !== "ROLLBACK_WINDOW") {
    return { ok: false, reason: `state is ${current.state}, expected ROLLBACK_WINDOW` };
  }
  await updateManifest("SQLITE_ARCHIVED", () => undefined);
  migLog.info("sqlite.archived", {
    migrationId: current.migrationId ?? undefined,
    phase: "SQLITE_ARCHIVED",
    result: "rollback window closed — SQLite files retained as archive",
  });
  return { ok: true };
}
