/**
 * Ashrilogic — migration table registry (SQLite → PostgreSQL).
 *
 * The authoritative table/column metadata is INTROSPECTED from the live
 * SQLite schema (PRAGMA table_info) — the registry below only classifies
 * tables by role and copy order. Introspection keeps the controller honest:
 * a schema change that adds a column flows into events/copy/verification
 * automatically instead of silently drifting from a hand-maintained list.
 *
 * Column classification per declared type (Prisma db push conventions):
 *   DATETIME → INTEGER ms in SQLite → timestamp(3) in PostgreSQL
 *   BOOLEAN  → 0/1 in SQLite        → boolean in PostgreSQL
 *   TEXT / INTEGER → pass through unchanged
 */

/** Tenant-scoped tables (carry instanceId — every event is tagged with it). */
export const TENANT_TABLES: ReadonlySet<string> = new Set([
  "ModuleRecord",
  "Site",
  "SiteCustomer",
  "SiteOrder",
  "SiteReview",
  "StoreCoupon",
  "Activity",
  "TeamMember",
  "PlanOrder",
  "WebhookEndpoint",
  "OrderReservation",
  "CouponRedemption",
]);

/**
 * Business tables in FK-safe copy order (parents before children).
 * Instance comes first; SiteOrder last (customer + instance parents).
 */
export const BUSINESS_TABLES: readonly string[] = [
  "Package",
  "Instance",
  "ModuleRecord",
  "Site",
  "TeamMember",
  "SiteCustomer",
  "StoreCoupon",
  "ImageAsset",
  "Subscriber",
  "AdminUser",
  "SupportTicket",
  "Activity",
  "AuditLog",
  "MfaSecret",
  "WebauthnCredential",
  "SessionRecord",
  "PlanOrder",
  "PlatformSetting",
  "NotificationLog",
  "NewsletterCampaign",
  "SiteReview",
  "SiteOrder",
  "OrderIdempotency",
  "WebhookEndpoint",
  // ROUND 120 ledgers — children of SiteOrder, replicated with it
  "OrderReservation",
  "CouponRedemption",
];

/**
 * Tables that NEVER replicate — each exclusion is explicit and documented:
 *  - MigrationEvent / MigrationState / MigrationProbe: controller
 *    infrastructure (replicating them would recurse and corrupt the run)
 *  - RateLimitHit: 24h sliding-window security state — a fresh window on
 *    the target is the correct semantics, not data loss
 *  - WebauthnChallenge: minutes-TTL one-time challenges — never valid
 *    across a migration
 */
export const EXCLUDED_TABLES: ReadonlyMap<string, string> = new Map([
  ["MigrationEvent", "controller infrastructure (change-capture log)"],
  ["MigrationState", "controller infrastructure (state machine)"],
  ["MigrationEventSeal", "controller infrastructure (seal chain)"],
  ["MigrationProbe", "controller infrastructure (load sampler)"],
  ["RateLimitHit", "transient 24h security window — regenerates"],
  ["WebauthnChallenge", "minutes-TTL one-time challenges"],
  ["WebhookDelivery", "transport log — fresh queue on the target is the correct semantics (ROUND 113)"],
]);

export interface TableColumns {
  table: string;
  /** ordered column names as declared */
  columns: string[];
  /** declared types by column (TEXT | INTEGER | BOOLEAN | DATETIME) */
  types: Map<string, string>;
  pk: string;
}

const IDENT_RE = /^[A-Za-z_][A-Za-z0-9_]*$/;

/** Read-only introspection of all business tables via a PRAGMA handle. */
export function tableColumnsOf(
  pragmaFn: (table: string) => { name: string; type: string; pk: number }[]
): Map<string, TableColumns> {
  const out = new Map<string, TableColumns>();
  for (const table of BUSINESS_TABLES) {
    if (!IDENT_RE.test(table)) continue; // defensive — our own constants
    const rows = pragmaFn(table);
    if (rows.length === 0) continue;
    const columns = rows.map((r) => r.name).filter((c) => IDENT_RE.test(c));
    const types = new Map(rows.map((r) => [r.name, r.type.toUpperCase()]));
    const pkRow = rows.find((r) => r.pk > 0);
    if (!pkRow) continue; // every business table has a single pk
    out.set(table, { table, columns, types, pk: pkRow.name });
  }
  return out;
}

/** Canonical row serialization for checksums/events — deterministic order
 *  (declared column order), values normalized to the STORAGE form (dates as
 *  ms integers, booleans as 0/1) so a Prisma-sourced row (Date objects /
 *  booleans) and a raw-SQLite-sourced row (integers) serialize IDENTICALLY. */
export function canonicalRowJson(
  row: Record<string, unknown>,
  meta: TableColumns
): string {
  const parts: string[] = [];
  for (const col of meta.columns) {
    const raw = row[col] === undefined ? null : row[col];
    const v = toCanonicalValue(raw, meta.types.get(col) ?? "TEXT");
    parts.push(JSON.stringify(col) + ":" + JSON.stringify(v));
  }
  return "{" + parts.join(",") + "}";
}

/** Convert a SQLite-stored value to the PostgreSQL write form. */
export function toPostgresValue(
  value: unknown,
  declaredType: string
): unknown {
  if (value === null || value === undefined) return null;
  switch (declaredType) {
    case "DATETIME":
      // SQLite stores Prisma DateTime as INTEGER milliseconds
      return typeof value === "number" ? new Date(value) : new Date(Number(value));
    case "BOOLEAN":
      return value === 1 || value === true || value === "1";
    default:
      return value;
  }
}

/** Normalize a target-side value back to the canonical (SQLite) form so
 *  chunk checksums compare apples to apples across both engines. */
export function toCanonicalValue(
  value: unknown,
  declaredType: string
): unknown {
  if (value === null || value === undefined) return null;
  switch (declaredType) {
    case "DATETIME": {
      if (value instanceof Date) return value.getTime();
      if (typeof value === "number") return value;
      const t = Date.parse(String(value));
      return Number.isNaN(t) ? null : t;
    }
    case "BOOLEAN":
      return value === true || value === 1 ? 1 : 0;
    default:
      return value;
  }
}
