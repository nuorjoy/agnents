/**
 * Ashrilogic — migration initial copy (SQLite → PostgreSQL).
 *
 * Copies every business table from the CONSISTENT SNAPSHOT (never the live
 * file) into the target, in FK-safe parent-first order, in bounded chunks
 * keyed by primary key. Resumable: the manifest records the last copied pk
 * per table; a crashed copy restarts from the checkpoints instead of zero,
 * and upsert-by-pk makes re-copied chunks converge instead of duplicating.
 */

import { BUSINESS_TABLES } from "./tables";
import { openSnapshotReader } from "./snapshot";
import type { MigrationTarget } from "./target";
import type { MigrationManifest } from "./state-machine";
import { migLog } from "./logger";

const CHUNK = 500;

export interface CopyProgress {
  copiedRows: number;
  completedTables: number;
  totalTables: number;
}

/** DONE marker for a fully copied table (pk space is text — a sentinel). */
const DONE = "__copy_done__";

/**
 * Run (or resume) the initial copy. Reads `manifest.copy.checkpoints`,
 * advances them, and returns the updated manifest — the caller persists it
 * with the state transition.
 */
export async function runInitialCopy(
  target: MigrationTarget,
  snapshotPath: string,
  manifest: MigrationManifest
): Promise<{ manifest: MigrationManifest; progress: CopyProgress }> {
  manifest.copy = manifest.copy ?? { checkpoints: {} };
  const checkpoints = manifest.copy.checkpoints;

  const reader = await openSnapshotReader(snapshotPath);
  let copiedRows = 0;
  let completedTables = 0;
  try {
    for (const table of BUSINESS_TABLES) {
      if (checkpoints[table] === DONE) {
        completedTables++;
        continue;
      }
      let afterPk: string | null = checkpoints[table] ?? null;
      for (;;) {
        const rows = reader.rows(table, afterPk, CHUNK);
        if (rows.length === 0) break;
        for (const row of rows) {
          const meta = tableMetaFor(table);
          await target.upsertRow(table, meta, row);
        }
        copiedRows += rows.length;
        afterPk = String(rows[rows.length - 1]!.id);
        checkpoints[table] = afterPk;
      }
      checkpoints[table] = DONE;
      completedTables++;
    }
  } finally {
    reader.close();
  }
  manifest.copy.completedAt = new Date().toISOString();
  migLog.info("copy.completed", {
    migrationId: manifest.migrationId,
    phase: "INITIAL_COPY",
    result: `${copiedRows} rows · ${completedTables}/${BUSINESS_TABLES.length} tables`,
  });
  return { manifest, progress: { copiedRows, completedTables, totalTables: BUSINESS_TABLES.length } };
}

/* table metadata holder — set by the controller before copy/replay runs
   (avoids re-introspecting per row) */
let tableMetaCache: Map<string, import("./tables").TableColumns> | null = null;

export function setTableMetaCache(meta: Map<string, import("./tables").TableColumns>): void {
  tableMetaCache = meta;
}

function tableMetaFor(table: string): import("./tables").TableColumns {
  const meta = tableMetaCache?.get(table);
  if (!meta) throw new Error(`table metadata not loaded for ${table} — controller bug`);
  return meta;
}
