/**
 * Ashrilogic — dedicated SQLite control-plane client for the migration
 * controller.
 *
 * WHY THIS EXISTS (split-brain prevention): the migration controller's
 * state tables (MigrationState / MigrationEvent / MigrationProbe) live in
 * the SQLite control plane and are INTENTIONALLY absent from the
 * PostgreSQL target schema. After the operator repoints DATABASE_URL to
 * PostgreSQL, the application's shared client (`@/lib/db`) becomes a
 * PostgreSQL client — a controller that kept using it would lose its own
 * state mid-run (post-cutover commands such as confirm-primary, rollback,
 * archive, status would hit a PostgreSQL server that has no
 * MigrationState table and can never have one).
 *
 * The control plane is therefore pinned to the SQLite file EXPLICITLY:
 *   1. ASHRILOGIC_SQLITE_FILE — the documented post-cutover setting (the
 *      operator knows the frozen source path; the cutover operator steps
 *      and the manifest record it too);
 *   2. pre-cutover default — DATABASE_URL itself when it is a `file:` URL
 *      (the control plane IS the live database then).
 * Neither resolved → hard error with instructions. No guessing, no
 * silently talking to the wrong engine.
 *
 * The client is a plain PrismaClient generated from the SQLite schema
 * (the default @prisma/client import) with the datasource overridden to
 * the resolved file — independent of DATABASE_URL.
 */

import { PrismaClient } from "@prisma/client";
import { db as appDb, currentProvider } from "@/lib/db";

/** Resolved control-plane SQLite file URL (file:… form). */
export function sqliteControlUrl(): string {
  const explicit = (process.env.ASHRILOGIC_SQLITE_FILE ?? "").trim();
  if (explicit) {
    return explicit.startsWith("file:") ? explicit : `file:${explicit}`;
  }
  const appUrl = (process.env.DATABASE_URL ?? "").trim();
  if (appUrl.startsWith("file:")) return appUrl;
  throw new Error(
    "SQLite control plane not resolvable: DATABASE_URL points at PostgreSQL and ASHRILOGIC_SQLITE_FILE is not set. " +
      "Set ASHRILOGIC_SQLITE_FILE to the migration source SQLite file path (recorded in the migration manifest and the cutover operator steps) to run post-cutover controller commands."
  );
}

const globalForControl = globalThis as unknown as {
  ashrilogicControlDb: PrismaClient | undefined;
};

/** The controller's own SQLite client — one per process, lazily created.
 *
 * PRE-CUTOVER OPTIMIZATION: when no ASHRILOGIC_SQLITE_FILE override exists
 * and DATABASE_URL itself is the SQLite file, the control plane IS the
 * live application database — the shared app client is reused (one pool,
 * one WAL connection budget) instead of opening a second connection to
 * the same file. Post-cutover (PG app / SQLite control) or with an
 * explicit override, a dedicated client is created against the resolved
 * file, fully independent of DATABASE_URL. */
export function controlDb(): PrismaClient {
  const existing = globalForControl.ashrilogicControlDb;
  if (existing) return existing;
  const explicit = (process.env.ASHRILOGIC_SQLITE_FILE ?? "").trim();
  if (!explicit && currentProvider() === "sqlite") {
    /* the control plane IS the live application database — reuse the shared
       app client (one pool, one WAL connection budget) */
    globalForControl.ashrilogicControlDb = appDb;
    return appDb;
  }
  const client = new PrismaClient({
    datasources: { db: { url: sqliteControlUrl() } },
  });
  globalForControl.ashrilogicControlDb = client;
  return client;
}

/** Path-only form of the control-plane file (for bun:sqlite openers). */
export function sqliteControlPath(): string {
  return sqliteControlUrl().replace(/^file:/, "").replace(/\?.*$/, "");
}
