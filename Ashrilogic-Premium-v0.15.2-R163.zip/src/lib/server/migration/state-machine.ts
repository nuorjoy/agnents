/**
 * Ashrilogic — migration state machine (SQLite → PostgreSQL).
 *
 * The migration is an explicit, auditable, resumable STATE MACHINE persisted
 * in the MigrationState singleton row. A high-load signal (or an operator)
 * may only ever START the machine (PREPARING) — no signal, threshold or code
 * path switches DATABASE_URL; the primary flip is the operator-confirmed
 * CUTOVER step with its verification gates.
 *
 *   SQLITE_ONLY → PREPARING → SNAPSHOT_CREATED → INITIAL_COPY →
 *   CHANGE_CAPTURE → REPLAYING → VERIFYING → READY_FOR_CUTOVER →
 *   QUIESCING → CUTOVER → POSTGRES_PRIMARY → ROLLBACK_WINDOW → SQLITE_ARCHIVED
 *
 * Crash safety: every phase transition is one row UPDATE, and every phase
 * carries its checkpoints in manifestJson — a restarted process resumes from
 * the persisted state instead of restarting the run.
 */

import { randomBytes } from "node:crypto";
import { controlDb } from "./control-db";
import { migLog } from "./logger";

export const MIGRATION_STATES = [
  "SQLITE_ONLY",
  "PREPARING",
  "SNAPSHOT_CREATED",
  "INITIAL_COPY",
  "CHANGE_CAPTURE",
  "REPLAYING",
  "VERIFYING",
  "READY_FOR_CUTOVER",
  "QUIESCING",
  "CUTOVER",
  "POSTGRES_PRIMARY",
  "ROLLBACK_WINDOW",
  "SQLITE_ARCHIVED",
] as const;

export type MigrationStateName = (typeof MIGRATION_STATES)[number];

/** Allowed forward transitions — the controller enforces this table.
 *  Every in-flight state may transition to SQLITE_ONLY: that is the explicit
 *  operator ABORT (abortMigration) — triggers removed, capture log cleared,
 *  SQLite untouched. It is never taken automatically. */
const TRANSITIONS: Partial<Record<MigrationStateName, MigrationStateName[]>> = {
  SQLITE_ONLY: ["PREPARING"],
  PREPARING: ["SNAPSHOT_CREATED", "SQLITE_ONLY"],
  SNAPSHOT_CREATED: ["INITIAL_COPY", "SQLITE_ONLY"],
  INITIAL_COPY: ["CHANGE_CAPTURE", "SQLITE_ONLY"],
  CHANGE_CAPTURE: ["REPLAYING", "VERIFYING", "SQLITE_ONLY"],
  REPLAYING: ["VERIFYING", "SQLITE_ONLY"],
  VERIFYING: ["READY_FOR_CUTOVER", "CHANGE_CAPTURE", "SQLITE_ONLY"],
  READY_FOR_CUTOVER: ["QUIESCING", "CHANGE_CAPTURE", "SQLITE_ONLY"],
  QUIESCING: ["CUTOVER", "CHANGE_CAPTURE", "SQLITE_ONLY"],
  CUTOVER: ["POSTGRES_PRIMARY", "CHANGE_CAPTURE"],
  POSTGRES_PRIMARY: ["ROLLBACK_WINDOW"],
  ROLLBACK_WINDOW: ["SQLITE_ARCHIVED", "SQLITE_ONLY"],
  SQLITE_ARCHIVED: [],
};

export interface MigrationManifest {
  migrationId: string;
  startedAt: string;
  target: {
    kind: "postgres" | "sqlite-shadow";
    /** PG DSN is NEVER persisted — only a digest for correlation */
    descriptor: string;
  };
  snapshot?: {
    path: string;
    watermark: number;
    createdAt: string;
    rowCounts: Record<string, number>;
  };
  copy?: {
    checkpoints: Record<string, string | null>; // table → last copied pk
    completedAt?: string;
  };
  verification?: {
    ranAt: string;
    ok: boolean;
    checks: number;
    failures: string[];
    reportDigest?: string;
  };
  cutover?: {
    requestedAt?: string;
    frozenAt?: string;
    finalWatermark?: number;
    verifiedAt?: string;
    confirmedAt?: string;
    operatorSteps?: string[];
  };
  rollback?: {
    windowClosesAt?: string;
    executedAt?: string;
    completedAt?: string;
  };
  lastError?: { at: string; phase: string; message: string };
}

export interface MigrationStateRow {
  state: MigrationStateName;
  migrationId: string | null;
  manifest: MigrationManifest | null;
  lastReplayedSequence: number;
  snapshotWatermark: number | null;
  failedReplays: number;
  updatedAt: Date;
}

export type ActionResult<T = unknown> =
  | { ok: true; from: MigrationStateName; to: MigrationStateName; data?: T }
  | { ok: false; from: MigrationStateName; reason: string; data?: T };

const SINGLETON = "singleton";

export async function readState(): Promise<MigrationStateRow> {
  const row = await controlDb().migrationState.findUnique({ where: { id: SINGLETON } });
  if (!row) {
    return {
      state: "SQLITE_ONLY",
      migrationId: null,
      manifest: null,
      lastReplayedSequence: 0,
      snapshotWatermark: null,
      failedReplays: 0,
      updatedAt: new Date(),
    };
  }
  return {
    state: (MIGRATION_STATES as readonly string[]).includes(row.state)
      ? (row.state as MigrationStateName)
      : "SQLITE_ONLY",
    migrationId: row.migrationId,
    manifest: row.manifestJson ? safeParse(row.manifestJson) : null,
    lastReplayedSequence: row.lastReplayedSequence,
    snapshotWatermark: row.snapshotWatermark,
    failedReplays: row.failedReplays,
    updatedAt: row.updatedAt,
  };
}

function safeParse(raw: string): MigrationManifest | null {
  try {
    return JSON.parse(raw) as MigrationManifest;
  } catch {
    return null;
  }
}

/** Persisted-state mutation: one transition + manifest/checkpoint updates.
 *  The transition table is enforced — illegal jumps throw (programming
 *  error), operator-facing flows check `canTransition` first.
 *
 *  ROUND 120 — the write is a CAS: the UPDATE is predicated on the state
 *  this function VALIDATED against, so a concurrent controller process
 *  that advanced the row between our read and our write makes the
 *  predicate miss (count 0) and this call FAILS loudly instead of
 *  last-writer-winning over an unknown transition (two operators / CLI +
 *  load-trigger could previously both validate against a stale read and
 *  each land their own transition — the second silently overwriting the
 *  first, e.g. a fresh PREPARING manifest orphaning the first run's
 *  snapshot directory). Same-state patches (checkpoint progress within
 *  one phase) remain last-write-wins — the single-controller discipline
 *  the checkpoints were designed for. */
export async function writeState(
  to: MigrationStateName,
  patch: {
    migrationId?: string | null;
    manifest?: MigrationManifest | null;
    lastReplayedSequence?: number;
    snapshotWatermark?: number | null;
    failedReplays?: number;
  } = {}
): Promise<void> {
  const current = await readState();
  if (current.state !== to) {
    const allowed = TRANSITIONS[current.state] ?? [];
    if (!allowed.includes(to)) {
      throw new Error(
        `illegal migration transition ${current.state} → ${to} (allowed: ${allowed.join(", ") || "none"})`
      );
    }
  }
  const data = {
    state: to,
    ...(patch.migrationId !== undefined ? { migrationId: patch.migrationId } : {}),
    ...(patch.manifest !== undefined
      ? { manifestJson: patch.manifest === null ? null : JSON.stringify(patch.manifest) }
      : {}),
    ...(patch.lastReplayedSequence !== undefined
      ? { lastReplayedSequence: patch.lastReplayedSequence }
      : {}),
    ...(patch.snapshotWatermark !== undefined
      ? { snapshotWatermark: patch.snapshotWatermark }
      : {}),
    ...(patch.failedReplays !== undefined
      ? { failedReplays: patch.failedReplays }
      : {}),
  };
  /* CAS: the update lands ONLY when the row still carries the state this
   * call validated against; a concurrent transition makes it miss */
  const applied = await controlDb().migrationState.updateMany({
    where: { id: SINGLETON, state: current.state },
    data,
  });
  if (applied.count === 0) {
    /* absent row (first-ever write) → create; a racing twin's create wins
     * the unique key and this call fails cleanly (never overwrite) */
    try {
      await controlDb().migrationState.create({
        data: {
          id: SINGLETON,
          ...data,
          lastReplayedSequence: patch.lastReplayedSequence ?? 0,
          snapshotWatermark: patch.snapshotWatermark ?? null,
          failedReplays: patch.failedReplays ?? 0,
        },
      });
    } catch (error) {
      if ((error as { code?: string })?.code === "P2002") {
        throw new Error(
          `concurrent migration state transition detected (validated ${current.state}, row moved) — one controller at a time`
        );
      }
      throw error;
    }
  }
  migLog.info("state.transition", {
    migrationId: patch.migrationId ?? current.migrationId ?? undefined,
    phase: to,
    result: `${current.state}→${to}`,
  });
}

export function canTransition(
  from: MigrationStateName,
  to: MigrationStateName
): boolean {
  if (from === to) return true;
  return (TRANSITIONS[from] ?? []).includes(to);
}

/** Read-modify-write the manifest with the transition (single-writer
 *  controller discipline: the CLI/process holds the run). */
export async function updateManifest(
  to: MigrationStateName,
  mutate: (m: MigrationManifest) => void
): Promise<MigrationManifest> {
  const current = await readState();
  const manifest: MigrationManifest = current.manifest ?? {
    migrationId: randomBytes(16).toString("hex"),
    startedAt: new Date().toISOString(),
    target: { kind: "postgres", descriptor: "unset" },
  };
  mutate(manifest);
  await writeState(to, { manifest, migrationId: manifest.migrationId });
  return manifest;
}

/** Record a phase error into the manifest (visible, never swallowed). */
export async function recordPhaseError(
  phase: string,
  message: string
): Promise<void> {
  const current = await readState();
  if (!current.manifest) return;
  await updateManifest(current.state, (m) => {
    m.lastError = { at: new Date().toISOString(), phase, message: message.slice(0, 500) };
  });
}
