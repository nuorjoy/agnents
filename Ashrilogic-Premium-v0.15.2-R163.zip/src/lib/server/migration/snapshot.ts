/**
 * Ashrilogic — migration snapshot (SQLite → PostgreSQL).
 *
 * The initial copy MUST read a transactionally-consistent point-in-time
 * image — NEVER the live database file while writes occur. `VACUUM INTO`
 * produces exactly that (the same primitive the platform backup uses):
 * a self-contained, consistent snapshot including the WAL contents.
 *
 * Watermark semantics: the capture triggers are installed BEFORE the
 * snapshot is taken, and the watermark (max MigrationEvent sequence at
 * snapshot time) is recorded from the LIVE database immediately before the
 * VACUUM. Events committed after the watermark may or may not already be
 * inside the snapshot image (the VACUUM's read point races forward writes) —
 * replaying them again is SAFE because application is idempotent
 * (upsert-by-pk / delete-by-pk). Idempotent replay absorbs the boundary
 * race; nothing between "triggers installed" and "replay caught up" can be
 * lost.
 */

import { existsSync } from "node:fs";
import { mkdirSync } from "node:fs";
import { join } from "node:path";
import { Prisma } from "@prisma/client";
import { controlDb } from "./control-db";
import { BUSINESS_TABLES } from "./tables";
import { currentWatermark } from "./change-capture";
import { migLog } from "./logger";

/** Directory holding migration artifacts (snapshot + verification reports). */
export function migrationsDir(): string {
  const storage =
    process.env.ASHRILOGIC_STORAGE_DIR ?? join(process.cwd(), "storage");
  return join(storage, "migrations");
}

export interface SnapshotResult {
  path: string;
  watermark: number;
  rowCounts: Record<string, number>;
}

/** Row counts per business table inside the SNAPSHOT (not the live DB). */
export async function snapshotRowCounts(
  snapshotPath: string
): Promise<Record<string, number>> {
  const counts: Record<string, number> = {};
  const reader = await openSnapshotReader(snapshotPath);
  for (const table of BUSINESS_TABLES) {
    counts[table] = reader.count(table);
  }
  reader.close();
  return counts;
}

/** Open the snapshot file read-only (the copy phase never writes it). */
export async function openSnapshotReader(snapshotPath: string) {
  const { Database } = await import("bun:sqlite");
  const sqlite = new Database(snapshotPath, { readonly: true });
  return {
    count: (table: string): number =>
      Number((sqlite.query(`SELECT COUNT(*) AS c FROM "${table}"`).get() as { c: number }).c),
    rows: (table: string, afterPk: string | null, limit: number): Record<string, unknown>[] =>
      afterPk
        ? (sqlite
            .query(`SELECT * FROM "${table}" WHERE "id" > ? ORDER BY "id" ASC LIMIT ?`)
            .all(afterPk, limit) as Record<string, unknown>[])
        : (sqlite
            .query(`SELECT * FROM "${table}" ORDER BY "id" ASC LIMIT ?`)
            .all(limit) as Record<string, unknown>[]),
    close: () => sqlite.close(),
  };
}

/**
 * Take the consistent snapshot + record the watermark. Returns the artifact
 * metadata for the manifest. The snapshot directory is keyed by migrationId
 * so a resumed run reuses its own snapshot.
 */
export async function createMigrationSnapshot(
  migrationId: string
): Promise<SnapshotResult> {
  const dir = join(migrationsDir(), migrationId);
  mkdirSync(dir, { recursive: true });
  const path = join(dir, "snapshot.db");

  /* watermark FIRST (live), then the image — see the boundary-race note
     above; idempotent replay makes the overlap safe in both directions */
  const watermark = await currentWatermark();

  if (!existsSync(path)) {
    await controlDb().$executeRaw(Prisma.sql`VACUUM INTO ${path}`);
  } else {
    /* resumed run — the existing snapshot stays authoritative */
    migLog.info("snapshot.reused", { migrationId, phase: "SNAPSHOT_CREATED" });
  }

  const rowCounts = await snapshotRowCounts(path);
  migLog.info("snapshot.created", {
    migrationId,
    phase: "SNAPSHOT_CREATED",
    result: `${BUSINESS_TABLES.length} tables · watermark ${watermark}`,
    detail: `${path}`,
  });
  return { path, watermark, rowCounts };
}
