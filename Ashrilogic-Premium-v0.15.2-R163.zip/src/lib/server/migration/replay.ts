/**
 * Ashrilogic — migration event replay (SQLite → PostgreSQL).
 *
 * Applies captured change events (sequence > snapshot watermark, then
 * sequence > last replayed checkpoint) to the target:
 *  - ORDERED: strictly ascending by sequence
 *  - IDEMPOTENT: upsert-by-pk for insert/update, delete-by-pk for delete —
 *    the same event applied twice converges (this is what makes the
 *    snapshot/replay boundary race safe)
 *  - RESUMABLE: the last applied sequence is checkpointed in MigrationState
 *    (batched every CHECKPOINT_EVERY events — a crash re-applies at most one
 *    small batch, never from zero)
 *  - DUPLICATE-SAFE / CRASH-SAFE: by idempotency + checkpointing
 *  - TENANT-SAFE: every tenant-table event is validated — the row's
 *    instanceId must match the event's tenantId claim; a mismatch quarantines
 *    the run (NEVER applied, NEVER skipped silently)
 *  - FAILURE-VISIBLE: an event that fails to apply is retried with backoff;
 *    after MAX_ATTEMPTS the run halts in place with the failure recorded —
 *    a failed event never silently disappears
 */

import { readEvents, validateEventTenant, pendingEventCount, type MigrationEventRow } from "./change-capture";
import { prismaAccess, type SqlAccess } from "./sqlite-access";
import type { MigrationTarget } from "./target";
import type { TableColumns } from "./tables";
import { migLog } from "./logger";

const CHECKPOINT_EVERY = 50;
const MAX_ATTEMPTS = 3;

export interface ReplayOutcome {
  applied: number;
  lastSequence: number;
  pendingAfter: number;
  halted?: { sequence: number; reason: string };
}

/** Parse an event payload JSON (canonical full-row form). */
function payloadOf(ev: MigrationEventRow): Record<string, unknown> | null {
  const raw = ev.op === "delete" ? ev.beforeJson : ev.afterJson;
  if (!raw) return null;
  try {
    return JSON.parse(raw) as Record<string, unknown>;
  } catch {
    return null;
  }
}

/** Apply ONE event to the target (idempotent). */
async function applyEvent(
  target: MigrationTarget,
  ev: MigrationEventRow,
  meta: Map<string, TableColumns>
): Promise<void> {
  const tableMeta = meta.get(ev.tableName);
  if (!tableMeta) {
    throw new Error(`no metadata for table ${ev.tableName} — schema drift between capture and replay`);
  }
  if (ev.op === "delete") {
    await target.deleteRow(ev.tableName, tableMeta, ev.recordId);
    return;
  }
  const row = payloadOf(ev);
  if (!row) {
    throw new Error(`event ${ev.sequence} (${ev.tableName}/${ev.recordId}) has no payload`);
  }
  const pkValue = row[tableMeta.pk];
  if (typeof pkValue !== "string") {
    throw new Error(`event ${ev.sequence} payload missing pk ${tableMeta.pk}`);
  }
  await target.upsertRow(ev.tableName, tableMeta, row);
}

/**
 * Replay pending events until caught up (or halted). Updates the persisted
 * lastReplayedSequence checkpoint and returns the outcome. `maxEvents` caps
 * the batch (the controller calls repeatedly). `sql` routes through the
 * lock-holder connection during the exclusive cutover window.
 */
export async function replayPendingEvents(
  target: MigrationTarget,
  meta: Map<string, TableColumns>,
  migrationId: string,
  startSequence: number,
  maxEvents = 5_000,
  sql: SqlAccess = prismaAccess()
): Promise<ReplayOutcome> {
  let applied = 0;
  let lastSequence = startSequence;
  let sinceCheckpoint = 0;

  for (;;) {
    if (applied >= maxEvents) break;
    const batch = await readEvents(lastSequence, Math.min(200, maxEvents - applied), sql);
    if (batch.length === 0) break;

    for (const ev of batch) {
      /* tenant safety gate — a cross-tenant forged event halts the run */
      const tenantCheck = validateEventTenant(ev);
      if (!tenantCheck.ok) {
        await recordHalt(sql, migrationId, ev, tenantCheck.reason);
        return {
          applied,
          lastSequence,
          pendingAfter: await pendingEventCount(lastSequence, sql),
          halted: { sequence: ev.sequence, reason: tenantCheck.reason },
        };
      }

      let appliedOk = false;
      let lastError: unknown = null;
      for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
        try {
          await applyEvent(target, ev, meta);
          appliedOk = true;
          break;
        } catch (error) {
          lastError = error;
          await sleep(50 * attempt);
        }
      }
      if (!appliedOk) {
        const reason = lastError instanceof Error ? lastError.message : String(lastError);
        await recordHalt(sql, migrationId, ev, reason);
        return {
          applied,
          lastSequence,
          pendingAfter: await pendingEventCount(lastSequence, sql),
          halted: { sequence: ev.sequence, reason },
        };
      }

      applied++;
      lastSequence = ev.sequence;
      sinceCheckpoint++;

      if (sinceCheckpoint >= CHECKPOINT_EVERY) {
        await saveCheckpoint(sql, lastSequence);
        sinceCheckpoint = 0;
      }
    }
  }

  await saveCheckpoint(sql, lastSequence);
  const pendingAfter = await pendingEventCount(lastSequence, sql);
  migLog.info("replay.batch", {
    migrationId,
    phase: "REPLAYING",
    sequence: lastSequence,
    result: `applied ${applied} · pending ${pendingAfter}`,
  });
  return { applied, lastSequence, pendingAfter };
}

async function saveCheckpoint(sql: SqlAccess, lastSequence: number): Promise<void> {
  await sql.execute(
    `UPDATE "MigrationState" SET "lastReplayedSequence" = ?, "updatedAt" = ? WHERE "id" = 'singleton'`,
    [lastSequence, Date.now()]
  );
}

async function recordHalt(
  sql: SqlAccess,
  migrationId: string,
  ev: MigrationEventRow,
  reason: string
): Promise<void> {
  migLog.error("replay.halted", {
    migrationId,
    phase: "REPLAYING",
    eventId: ev.eventId,
    sequence: ev.sequence,
    table: ev.tableName,
    result: "HALTED",
    detail: reason.slice(0, 300),
  });
  await sql.execute(
    `UPDATE "MigrationState" SET "failedReplays" = "failedReplays" + 1, "updatedAt" = ? WHERE "id" = 'singleton'`,
    [Date.now()]
  );
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
