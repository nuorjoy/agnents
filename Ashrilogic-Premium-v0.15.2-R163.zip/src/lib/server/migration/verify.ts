/**
 * Ashrilogic — migration verification battery (SQLite → PostgreSQL).
 *
 * The ZERO-DATA-LOSS invariant lives here: a migration NEVER reports success
 * unless every check proves source/target equivalence. The battery compares
 * the LIVE SQLite source against the target across:
 *
 *   1. table counts (every business table)
 *   2. per-tenant counts (every tenant-scoped table grouped by instanceId)
 *   3. primary-key parity (missing + extra rows listed, not just counted)
 *   4. foreign-key integrity on the target
 *   5. monetary totals — SUM(total) + SUM(discount) per tenant and global
 *      (integer minor units, exact equality)
 *   6. chunked deterministic checksums — rows ordered by pk, 500-row chunks,
 *      HMAC over the canonical row serialization (content equality, not
 *      just counts — the scalable substitute for row-by-row diffing)
 *   7. image reference integrity — every /api/images/<sha> reference resolves
 *      to an ImageAsset row on the target, and the bytes exist on disk
 *   8. sealed-field marker parity — every AES-256-GCM envelope column keeps
 *      its enc:v1: marker in the target (bit-level passthrough proof)
 *   9. NULL parity per column
 *  10. JSON-column validity on the target
 *
 * A report with ANY failure has ok:false — the controller then NEVER
 * advances toward cutover on that report.
 */

import { createHash, createHmac } from "node:crypto";
import {
  BUSINESS_TABLES,
  TENANT_TABLES,
  canonicalRowJson,
  type TableColumns,
} from "./tables";
import { readStoredImageBytes } from "@/lib/server/image-store";
import { prismaAccess, type SqlAccess } from "./sqlite-access";
import type { MigrationTarget } from "./target";
import { migLog } from "./logger";

export interface VerificationCheck {
  name: string;
  ok: boolean;
  detail?: string;
}

export interface VerificationReport {
  ok: boolean;
  ranAt: string;
  pendingEvents: number;
  checks: VerificationCheck[];
  failures: string[];
  /** digest over the canonical report — recorded in the manifest */
  digest: string;
}

const CHUNK = 500;

/** FK relationships enforced on the target (child → parent). */
const FK_RELATIONS: ReadonlyArray<{ child: string; column: string; parent: string }> = [
  { child: "ModuleRecord", column: "instanceId", parent: "Instance" },
  { child: "Site", column: "instanceId", parent: "Instance" },
  { child: "SiteCustomer", column: "instanceId", parent: "Instance" },
  { child: "SiteOrder", column: "instanceId", parent: "Instance" },
  { child: "SiteOrder", column: "customerId", parent: "SiteCustomer" },
  { child: "SiteReview", column: "instanceId", parent: "Instance" },
  { child: "StoreCoupon", column: "instanceId", parent: "Instance" },
  { child: "Activity", column: "instanceId", parent: "Instance" },
  { child: "TeamMember", column: "instanceId", parent: "Instance" },
  { child: "PlanOrder", column: "instanceId", parent: "Instance" },
  { child: "PlanOrder", column: "packageId", parent: "Package" },
  { child: "Instance", column: "packageId", parent: "Package" },
];

/** Columns holding AES-256-GCM envelopes (marker parity is checked). */
const SEALED_COLUMNS: ReadonlyArray<{ table: string; column: string }> = [
  { table: "SiteCustomer", column: "email" },
  { table: "SiteCustomer", column: "phone" },
  { table: "TeamMember", column: "email" },
  { table: "TeamMember", column: "profileJson" },
  { table: "Subscriber", column: "email" },
  { table: "AdminUser", column: "email" },
  { table: "AdminUser", column: "address" },
  { table: "SupportTicket", column: "requesterEmail" },
  { table: "MfaSecret", column: "secretSealed" },
  { table: "Instance", column: "ownerProfileJson" },
];

/** JSON-string columns validated for parseability on the target. */
const JSON_COLUMNS: ReadonlyArray<{ table: string; column: string }> = [
  { table: "Instance", column: "orgJson" },
  { table: "Instance", column: "adminJson" },
  { table: "Instance", column: "prefsJson" },
  { table: "Instance", column: "modulesJson" },
  { table: "Instance", column: "featureOverridesJson" },
  { table: "ModuleRecord", column: "dataJson" },
  { table: "Site", column: "contentJson" },
  { table: "SiteCustomer", column: "addressesJson" },
  { table: "SiteCustomer", column: "paymentMethodsJson" },
  { table: "SiteOrder", column: "itemsJson" },
  { table: "SiteOrder", column: "statusHistoryJson" },
  { table: "Activity", column: "metaJson" },
  { table: "AuditLog", column: "metaJson" },
  { table: "Package", column: "featuresJson" },
  { table: "Package", column: "featuresEnJson" },
  { table: "Package", column: "capabilitiesJson" },
];

/* ------------------------------ source reads ------------------------------ */

async function sourceCount(source: SqlAccess, table: string): Promise<number> {
  const rows = await source.query<{ c: number | bigint }>(`SELECT COUNT(*) AS c FROM "${table}"`);
  return Number(rows[0]?.c ?? 0);
}

async function sourceTenantCounts(
  source: SqlAccess,
  table: string
): Promise<Map<string, number>> {
  const rows = await source.query<{ t: string; c: number | bigint }>(
    `SELECT "instanceId" AS t, COUNT(*) AS c FROM "${table}" GROUP BY "instanceId"`
  );
  return new Map(rows.map((r) => [r.t, Number(r.c)]));
}

async function sourceRows(
  source: SqlAccess,
  table: string,
  afterPk: string | null,
  limit: number
): Promise<Record<string, unknown>[]> {
  return source.query<Record<string, unknown>>(
    afterPk
      ? `SELECT * FROM "${table}" WHERE "id" > ? ORDER BY "id" ASC LIMIT ?`
      : `SELECT * FROM "${table}" ORDER BY "id" ASC LIMIT ?`,
    afterPk ? [afterPk, limit] : [limit]
  );
}

async function sourceMoneyTotals(
  source: SqlAccess
): Promise<Map<string, { total: number; discount: number }>> {
  const rows = await source.query<{ t: string; total: number | bigint; discount: number | bigint }>(
    `SELECT "instanceId" AS t, COALESCE(SUM("total"),0) AS total, COALESCE(SUM("discount"),0) AS discount
     FROM "SiteOrder" GROUP BY "instanceId"`
  );
  return new Map(rows.map((r) => [r.t, { total: Number(r.total), discount: Number(r.discount) }]));
}

/* --------------------------------- battery -------------------------------- */

/** Chunked deterministic checksum over one table's full content. */
async function chunkedChecksums(
  table: string,
  meta: TableColumns,
  read: (table: string, afterPk: string | null, limit: number) => Promise<Record<string, unknown>[]>,
  keyMaterial: string
): Promise<string[]> {
  const sums: string[] = [];
  let afterPk: string | null = null;
  for (;;) {
    const rows = await read(table, afterPk, CHUNK);
    if (rows.length === 0) break;
    const chunkInput = rows.map((r) => canonicalRowJson(r, meta)).join("\n");
    sums.push(
      createHmac("sha256", Buffer.from(keyMaterial, "utf8"))
        .update(chunkInput, "utf8")
        .digest("hex")
    );
    afterPk = String(rows[rows.length - 1]![meta.pk]);
  }
  return sums;
}

export async function runVerification(
  target: MigrationTarget,
  meta: Map<string, TableColumns>,
  pendingEvents: number,
  source: SqlAccess = prismaAccess()
): Promise<VerificationReport> {
  const checks: VerificationCheck[] = [];
  const failures: string[] = [];

  const add = (name: string, ok: boolean, detail?: string) => {
    checks.push({ name, ok, detail });
    if (!ok) failures.push(detail ? `${name}: ${detail}` : name);
  };

  /* 1 — table counts */
  for (const table of BUSINESS_TABLES) {
    const m = meta.get(table);
    if (!m) {
      add(`schema.${table}`, false, "missing metadata");
      continue;
    }
    const src = await sourceCount(source, table);
    const dst = await target.countRows(table);
    add(
      `count.${table}`,
      src === dst,
      `source=${src} target=${dst}${pendingEvents > 0 ? ` (pending events: ${pendingEvents})` : ""}`
    );
  }

  /* 2 — per-tenant counts */
  for (const table of TENANT_TABLES) {
    const src = await sourceTenantCounts(source, table);
    const dst = await target.countByTenant(table);
    let mismatch: string | null = null;
    for (const [tenant, n] of src) {
      if ((dst.get(tenant) ?? 0) !== n) {
        mismatch = `tenant ${tenant}: source=${n} target=${dst.get(tenant) ?? 0}`;
        break;
      }
    }
    if (!mismatch) {
      for (const [tenant, n] of dst) {
        if (!src.has(tenant) && n > 0) {
          mismatch = `target has rows for unknown tenant ${tenant} (${n})`;
          break;
        }
      }
    }
    add(`tenant-count.${table}`, !mismatch, mismatch ?? undefined);
  }

  /* 3 — PK parity + 6 — chunked checksums (one pass per table) */
  for (const table of BUSINESS_TABLES) {
    const m = meta.get(table);
    if (!m) continue;
    const srcPks = new Set<string>();
    let afterPk: string | null = null;
    for (;;) {
      const rows = await sourceRows(source, table, afterPk, 5000);
      if (rows.length === 0) break;
      for (const r of rows) srcPks.add(String(r[m.pk]));
      afterPk = String(rows[rows.length - 1]![m.pk]);
    }
    const dstPks = new Set<string>();
    afterPk = null;
    for (;;) {
      const rows = await target.readRows(table, m, afterPk, 5000);
      if (rows.length === 0) break;
      for (const r of rows) dstPks.add(String(r[m.pk]));
      afterPk = String(rows[rows.length - 1]![m.pk]);
    }
    const missing = [...srcPks].filter((p) => !dstPks.has(p)).slice(0, 10);
    const extra = [...dstPks].filter((p) => !srcPks.has(p)).slice(0, 10);
    add(
      `pk-parity.${table}`,
      srcPks.size === dstPks.size && missing.length === 0 && extra.length === 0,
      missing.length || extra.length
        ? `missing ${srcPks.size - dstPks.size > 0 ? srcPks.size - dstPks.size : 0} (e.g. ${missing.join(",")}) · extra ${dstPks.size - srcPks.size > 0 ? dstPks.size - srcPks.size : 0} (e.g. ${extra.join(",")})`
        : `${srcPks.size} rows`
    );

    /* deterministic content checksums — the strict equality proof */
    const srcSums = await chunkedChecksums(
      table,
      m,
      (t, after, limit) => sourceRows(source, t, after, limit),
      "ashrilogic-migration-verify"
    );
    const dstSums = await chunkedChecksums(
      table,
      m,
      (t, after, limit) => target.readRows(t, m, after, limit),
      "ashrilogic-migration-verify"
    );
    const same =
      srcSums.length === dstSums.length &&
      srcSums.every((s, i) => s === dstSums[i]);
    add(
      `checksum.${table}`,
      same,
      same
        ? `${srcSums.length} chunk(s)`
        : `chunk digests differ (source ${srcSums.length} vs target ${dstSums.length} chunks — content mismatch beyond counts)`
    );
  }

  /* 4 — FK integrity on the target */
  for (const rel of FK_RELATIONS) {
    const m = meta.get(rel.child);
    if (!m) continue;
    const parentPks = new Set<string>();
    let afterPk: string | null = null;
    for (;;) {
      const rows = await target.readRows(rel.parent, meta.get(rel.parent)!, afterPk, 5000);
      if (rows.length === 0) break;
      for (const r of rows) parentPks.add(String(r[meta.get(rel.parent)!.pk]));
      afterPk = String(rows[rows.length - 1]![meta.get(rel.parent)!.pk]);
    }
    let orphans = 0;
    afterPk = null;
    for (;;) {
      const rows = await target.readRows(rel.child, m, afterPk, 5000);
      if (rows.length === 0) break;
      for (const r of rows) {
        const v = r[rel.column];
        if (v !== null && v !== undefined && !parentPks.has(String(v))) orphans++;
      }
      afterPk = String(rows[rows.length - 1]![m.pk]);
    }
    add(`fk.${rel.child}.${rel.column}`, orphans === 0, orphans ? `${orphans} orphan(s)` : undefined);
  }

  /* 5 — monetary totals (exact integer equality) */
  {
    const src = await sourceMoneyTotals(source);
    const dst = await target.countByTenant("SiteOrder"); // tenant key set
    const dstTotals = new Map<string, { total: number; discount: number }>();
    let afterPk: string | null = null;
    const m = meta.get("SiteOrder")!;
    for (;;) {
      const rows = await target.readRows("SiteOrder", m, afterPk, 5000);
      if (rows.length === 0) break;
      for (const r of rows) {
        const tenant = String(r.instanceId);
        const acc = dstTotals.get(tenant) ?? { total: 0, discount: 0 };
        acc.total += Number(r.total ?? 0);
        acc.discount += Number(r.discount ?? 0);
        dstTotals.set(tenant, acc);
      }
      afterPk = String(rows[rows.length - 1]![m.pk]);
    }
    let moneyOk = true;
    let moneyDetail: string | undefined;
    for (const [tenant, srcAcc] of src) {
      const dstAcc = dstTotals.get(tenant);
      if (!dstAcc || dstAcc.total !== srcAcc.total || dstAcc.discount !== srcAcc.discount) {
        moneyOk = false;
        moneyDetail = `tenant ${tenant}: source total=${srcAcc.total} discount=${srcAcc.discount} · target total=${dstAcc?.total ?? "absent"} discount=${dstAcc?.discount ?? "absent"}`;
        break;
      }
    }
    if (moneyOk && dstTotals.size !== src.size) {
      moneyOk = false;
      moneyDetail = `tenant sets differ (source ${src.size} · target ${dstTotals.size})`;
    }
    void dst;
    add("money.siteorder-totals", moneyOk, moneyDetail);
  }

  /* 7 — image references: target rows must resolve to ImageAsset rows +
         the bytes must exist on disk AND hash-verify (content-addressed
         names make recomputation cheap to trust: a corrupt or truncated
         file fails the check and blocks cutover — "database moved, bytes
         didn't" is exactly the failure this gate exists for). */
  {
    const m = meta.get("ModuleRecord")!;
    const assets = new Set<string>();
    let afterPk: string | null = null;
    for (;;) {
      const rows = await target.readRows("ImageAsset", meta.get("ImageAsset")!, afterPk, 5000);
      if (rows.length === 0) break;
      for (const r of rows) assets.add(String(r.id));
      afterPk = String(rows[rows.length - 1]![meta.get("ImageAsset")!.pk]);
    }
    let dangling = 0;
    let missingFiles = 0;
    let corruptFiles = 0;
    const verifiedHashes = new Map<string, boolean | null>(); /* hash → verified|null(missing) */
    afterPk = null;
    for (;;) {
      const rows = await target.readRows("ModuleRecord", m, afterPk, 5000);
      if (rows.length === 0) break;
      for (const r of rows) {
        const ref = r.imageRef;
        if (typeof ref !== "string" || ref === "") continue;
        const hash = ref.slice("/api/images/".length);
        if (!assets.has(hash)) dangling++;
        /* ROUND 122 — bytes through the object storage adapter (local FS
         * by default; S3 when configured). Sanitized uploads are bounded
         * (≤2MB) — a buffer hash is fine (the backup envelope already
         * buffers them). null = missing; mismatch = corrupt. */
        let verified: boolean | null | undefined = verifiedHashes.get(hash);
        if (verified === undefined) {
          const bytes = await readStoredImageBytes(hash);
          verified =
            bytes === null
              ? null
              : createHash("sha256").update(bytes).digest("hex") === hash;
          verifiedHashes.set(hash, verified);
        }
        if (verified === null) missingFiles++;
        else if (!verified) corruptFiles++;
      }
      afterPk = String(rows[rows.length - 1]![m.pk]);
    }
    add(
      "images.references",
      dangling === 0 && missingFiles === 0 && corruptFiles === 0,
      dangling || missingFiles || corruptFiles
        ? `${dangling} dangling ref(s) · ${missingFiles} missing file(s) · ${corruptFiles} corrupt file(s)`
        : undefined
    );
  }

  /* 8 — sealed-envelope marker parity (bit-level passthrough proof) */
  for (const { table, column } of SEALED_COLUMNS) {
    const m = meta.get(table);
    if (!m || !m.columns.includes(column)) continue;
    const srcSealed = await countSealed(source, table, column);
    const dstSealed = await countSealedOnTarget(target, table, m, column);
    add(
      `sealed.${table}.${column}`,
      srcSealed === dstSealed,
      `source=${srcSealed} target=${dstSealed}`
    );
  }

  /* 9 — NULL parity per column (aggregate counts) */
  for (const table of BUSINESS_TABLES) {
    const m = meta.get(table);
    if (!m) continue;
    for (const col of m.columns) {
      const srcNulls = await countNulls(source, table, col);
      const dstNulls = await countNullsOnTarget(target, table, m, col);
      if (srcNulls !== dstNulls) {
        add(`nulls.${table}.${col}`, false, `source=${srcNulls} target=${dstNulls}`);
      }
    }
    add(`nulls.${table}`, true, "all columns match");
  }

  /* 10 — JSON-column validity on the target */
  {
    let invalidJson = 0;
    for (const { table, column } of JSON_COLUMNS) {
      const m = meta.get(table);
      if (!m || !m.columns.includes(column)) continue;
      let afterPk: string | null = null;
      for (;;) {
        const rows = await target.readRows(table, m, afterPk, 5000);
        if (rows.length === 0) break;
        for (const r of rows) {
          const v = r[column];
          if (typeof v === "string" && v !== "") {
            try {
              JSON.parse(v);
            } catch {
              invalidJson++;
            }
          }
        }
        afterPk = String(rows[rows.length - 1]![m.pk]);
      }
    }
    add("json.validity", invalidJson === 0, invalidJson ? `${invalidJson} invalid value(s)` : undefined);
  }

  const ok = failures.length === 0;
  const report: VerificationReport = {
    ok,
    ranAt: new Date().toISOString(),
    pendingEvents,
    checks,
    failures,
    digest: createHash("sha256")
      .update(JSON.stringify({ ok, pendingEvents, failures }))
      .digest("hex"),
  };
  migLog.info("verification.completed", {
    phase: "VERIFYING",
    result: ok ? "PASS" : "FAIL",
    detail: `${checks.length} checks · ${failures.length} failure(s) · pending ${pendingEvents}`,
  });
  return report;
}

async function countSealed(source: SqlAccess, table: string, column: string): Promise<number> {
  const rows = await source.query<{ c: number | bigint }>(
    `SELECT COUNT(*) AS c FROM "${table}" WHERE "${column}" LIKE 'enc:v1:%'`
  );
  return Number(rows[0]?.c ?? 0);
}

async function countSealedOnTarget(
  target: MigrationTarget,
  table: string,
  m: TableColumns,
  column: string
): Promise<number> {
  let sealed = 0;
  let afterPk: string | null = null;
  for (;;) {
    const rows = await target.readRows(table, m, afterPk, 5000);
    if (rows.length === 0) break;
    for (const r of rows) {
      const v = r[column];
      if (typeof v === "string" && v.startsWith("enc:v1:")) sealed++;
    }
    afterPk = String(rows[rows.length - 1]![m.pk]);
  }
  return sealed;
}

async function countNulls(source: SqlAccess, table: string, column: string): Promise<number> {
  const rows = await source.query<{ c: number | bigint }>(
    `SELECT COUNT(*) AS c FROM "${table}" WHERE "${column}" IS NULL`
  );
  return Number(rows[0]?.c ?? 0);
}

async function countNullsOnTarget(
  target: MigrationTarget,
  table: string,
  m: TableColumns,
  column: string
): Promise<number> {
  let nulls = 0;
  let afterPk: string | null = null;
  for (;;) {
    const rows = await target.readRows(table, m, afterPk, 5000);
    if (rows.length === 0) break;
    for (const r of rows) {
      if (r[column] === null || r[column] === undefined) nulls++;
    }
    afterPk = String(rows[rows.length - 1]![m.pk]);
  }
  return nulls;
}
