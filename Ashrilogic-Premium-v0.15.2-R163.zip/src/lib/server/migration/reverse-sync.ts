/**
 * Ashrilogic — REVERSE-SYNC SALVAGE (ROUND 120).
 *
 * Closes the rollback data-loss gap: writes accepted by PostgreSQL during
 * the primary period (confirm() → rollback) were previously NOT in the
 * frozen SQLite source — the pre-120 runbook literally said "re-apply
 * them manually if required". This module salvages them BEFORE the
 * repoint, in the ROLLBACK_WINDOW phase only:
 *
 *   --audit (default): diff PostgreSQL vs the frozen SQLite source and
 *     REPORT the deltas (row counts per table, bounded pk samples, and
 *     PG-side rows that no longer exist in SQLite) — zero writes, zero
 *     risk, the operator reviews before anything moves.
 *
 *   --apply: idempotently upsert the PG-side INSERT/UPDATE deltas into
 *     the frozen SQLite source, in the FK-safe BUSINESS_TABLES order,
 *     parameterized statements, then re-audit to prove zero remaining
 *     deltas. Deletes on the PG side are NEVER applied (the frozen
 *     source keeps its rows — a conservative salvage; the audit reports
 *     them so the operator can decide).
 *
 * Built ENTIRELY on the migration engine's existing primitives:
 *   - the PG target's readRows (canonicalized, chunked by pk)
 *   - the shadow-target's upsertRow (the SAME idempotent write path the
 *     forward migration used — parameterized, FK-aware normalization)
 *   - canonicalRowJson for the content comparison (the verification
 *     battery's serialization — apples to apples across engines)
 *
 * GUARDS:
 *   - state MUST be ROLLBACK_WINDOW (the only phase where this makes
 *     sense: PG was primary, we are rolling back)
 *   - the target DSN comes from the manifest's recorded target OR
 *     DATABASE_URL_POSTGRES (resolveConfiguredTarget)
 *   - the frozen source is copied to a work file first (--apply): the
 *     frozen artifact is never written in place — the operator points
 *     the rollback at the WORK file (or the runbook's copy step)
 */

import { copyFileSync, existsSync, mkdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { readState } from "./state-machine";
import { BUSINESS_TABLES, canonicalRowJson, type TableColumns } from "./tables";
import { openShadowTarget, resolveConfiguredTarget, type MigrationTarget } from "./target";
import { migrationsDir } from "./snapshot";
import { sqliteControlPath } from "./control-db";
import { migLog } from "./logger";

/** chunk size for the diff scan (pk-ordered, constant memory) */
const CHUNK = 500;
/** how many sample pks per table the audit report lists */
const SAMPLE_LIMIT = 5;

export interface ReverseSyncTableReport {
  table: string;
  /** rows present in PG but MISSING in SQLite (would be INSERTed) */
  inserts: number;
  /** rows present in BOTH but with DIFFERENT content (would be UPDATEd) */
  updates: number;
  /** rows present in SQLite but ABSENT in PG (reported, NEVER applied) */
  sqliteOnly: number;
  /** sample pks of the insert/update deltas (bounded) */
  samplePks: string[];
}

export interface ReverseSyncReport {
  ok: boolean;
  mode: "audit" | "apply";
  ranAt: string;
  /** the SQLite file the diff ran against (the work copy in apply mode) */
  sourceFile: string;
  tables: ReverseSyncTableReport[];
  totalInserts: number;
  totalUpdates: number;
  totalSqliteOnly: number;
  /** apply mode only: zero remaining deltas after the write pass */
  cleanAfterApply?: boolean;
  reason?: string;
}

/**
 * Diff one table: PG rows (pk-ordered chunks) vs the SQLite source rows.
 * Returns the deltas + the row map for the apply phase.
 */
async function diffTable(
  pgTarget: MigrationTarget,
  sqliteTarget: MigrationTarget,
  table: string,
  meta: TableColumns
): Promise<{
  inserts: string[]; /* pks present in PG, missing in SQLite */
  updates: string[]; /* pks present in both, content differs */
  sqliteOnly: number; /* pks present in SQLite, absent in PG */
  pgRows: Map<string, Record<string, unknown>>;
}> {
  const inserts: string[] = [];
  const updates: string[] = [];
  const pgRows = new Map<string, Record<string, unknown>>();
  const seenInPg = new Set<string>();

  let afterPk: string | null = null;
  for (;;) {
    const rows = await pgTarget.readRows(table, meta, afterPk, CHUNK);
    if (rows.length === 0) break;
    for (const row of rows) {
      const pk = String(row[meta.pk] ?? "");
      if (!pk) continue;
      seenInPg.add(pk);
      pgRows.set(pk, row);
      const local = await sqliteTarget.readRowByPk(table, meta, pk);
      if (!local) {
        inserts.push(pk);
      } else if (
        canonicalRowJson(row, meta) !== canonicalRowJson(local, meta)
      ) {
        updates.push(pk);
      }
    }
    afterPk = String(rows[rows.length - 1][meta.pk] ?? "");
    if (rows.length < CHUNK) break;
  }

  /* the reverse direction: count SQLite-only rows (chunked, same order) */
  let sqliteOnly = 0;
  let afterLocal: string | null = null;
  for (;;) {
    const rows = await sqliteTarget.readRows(table, meta, afterLocal, CHUNK);
    if (rows.length === 0) break;
    for (const row of rows) {
      const pk = String(row[meta.pk] ?? "");
      if (!seenInPg.has(pk)) sqliteOnly += 1;
    }
    afterLocal = String(rows[rows.length - 1][meta.pk] ?? "");
    if (rows.length < CHUNK) break;
  }

  return { inserts, updates, sqliteOnly, pgRows };
}

/**
 * Run the reverse-sync. `mode: "audit"` never writes; `mode: "apply"`
 * copies the frozen source to <snapshotDir>/reverse-sync.db, applies the
 * deltas there (parameterized upserts, FK-safe order), and re-audits.
 *
 * `dbFileOverride` routes the whole flow at a specific SQLite file (tests
 * / shadow runs); production resolves the frozen control-plane path.
 * `pgTargetOverride` injects a specific target (the offline battery uses
 * a sqlite-shadow stand-in for the PG side; production resolves
 * DATABASE_URL_POSTGRES).
 */
export async function reverseSync(
  mode: "audit" | "apply",
  dbFileOverride?: string,
  pgTargetOverride?: MigrationTarget
): Promise<ReverseSyncReport> {
  const current = await readState();
  if (current.state !== "ROLLBACK_WINDOW") {
    return {
      ok: false,
      mode,
      ranAt: new Date().toISOString(),
      sourceFile: dbFileOverride ?? "(unresolved)",
      tables: [],
      totalInserts: 0,
      totalUpdates: 0,
      totalSqliteOnly: 0,
      reason: `state is ${current.state}, expected ROLLBACK_WINDOW (reverse-sync salvages the PG-primary period only)`,
    };
  }
  const manifest = current.manifest;
  if (!manifest) {
    return {
      ok: false,
      mode,
      ranAt: new Date().toISOString(),
      sourceFile: dbFileOverride ?? "(unresolved)",
      tables: [],
      totalInserts: 0,
      totalUpdates: 0,
      totalSqliteOnly: 0,
      reason: "missing manifest",
    };
  }

  const frozenFile = dbFileOverride ?? sqliteControlPath();
  if (!frozenFile || !existsSync(frozenFile)) {
    return {
      ok: false,
      mode,
      ranAt: new Date().toISOString(),
      sourceFile: frozenFile ?? "(unresolved)",
      tables: [],
      totalInserts: 0,
      totalUpdates: 0,
      totalSqliteOnly: 0,
      reason: `frozen SQLite source not found: ${frozenFile}`,
    };
  }

  /* the work file: apply mode NEVER writes the frozen artifact in place */
  let workFile = frozenFile;
  if (mode === "apply") {
    const dir = join(migrationsDir(), manifest.migrationId ?? "run");
    mkdirSync(dir, { recursive: true });
    workFile = join(dir, "reverse-sync.db");
    copyFileSync(frozenFile, workFile);
  }

  const pgTarget = pgTargetOverride ?? (await resolveConfiguredTarget());
  const sqliteTarget = openShadowTarget(workFile);

  const tables: ReverseSyncTableReport[] = [];
  let totalInserts = 0;
  let totalUpdates = 0;
  let totalSqliteOnly = 0;

  /* table meta introspected from the SQLite WORK FILE (the frozen source's
   * own schema — the same introspection the forward migration used, run
   * against the file we are actually reading/writing) */
  const { Database } = await import("bun:sqlite");
  const introspect = new Database(workFile, { readonly: true });
  let meta: Map<string, TableColumns>;
  try {
    const { tableColumnsOf } = await import("./tables");
    meta = tableColumnsOf((table: string) =>
      introspect.query(`SELECT name, type, pk FROM pragma_table_info('${table}')`).all() as {
        name: string;
        type: string;
        pk: number;
      }[]
    );
  } finally {
    introspect.close();
  }

  try {
    for (const table of BUSINESS_TABLES) {
      const tableMeta = meta.get(table);
      if (!tableMeta) continue;
      const diff = await diffTable(pgTarget, sqliteTarget, table, tableMeta);
      totalInserts += diff.inserts.length;
      totalUpdates += diff.updates.length;
      totalSqliteOnly += diff.sqliteOnly;
      const samplePks = [...diff.inserts, ...diff.updates].slice(0, SAMPLE_LIMIT);
      tables.push({
        table,
        inserts: diff.inserts.length,
        updates: diff.updates.length,
        sqliteOnly: diff.sqliteOnly,
        samplePks,
      });

      /* APPLY: the idempotent upsert path the forward migration used —
       * parameterized, FK-safe order (BUSINESS_TABLES), canonical values */
      if (mode === "apply") {
        for (const pk of [...diff.inserts, ...diff.updates]) {
          const row = diff.pgRows.get(pk);
          if (row) await sqliteTarget.upsertRow(table, tableMeta, row);
        }
      }
    }

    let cleanAfterApply: boolean | undefined;
    if (mode === "apply") {
      /* prove the deltas are gone: a full re-audit must find zero
       * insert/update deltas (sqliteOnly is reported, never applied) */
      let remaining = 0;
      for (const table of BUSINESS_TABLES) {
        const tableMeta = meta.get(table);
        if (!tableMeta) continue;
        const recheck = await diffTable(pgTarget, sqliteTarget, table, tableMeta);
        remaining += recheck.inserts.length + recheck.updates.length;
      }
      cleanAfterApply = remaining === 0;
      migLog.info("reverse-sync.applied", {
        migrationId: manifest.migrationId,
        result: `salvaged ${totalInserts} insert(s) + ${totalUpdates} update(s) into ${workFile} · clean=${cleanAfterApply}`,
      });
    } else {
      migLog.info("reverse-sync.audited", {
        migrationId: manifest.migrationId,
        result: `PG-primary-period deltas: ${totalInserts} insert(s) · ${totalUpdates} update(s) · ${totalSqliteOnly} sqlite-only`,
      });
    }

    return {
      ok: true,
      mode,
      ranAt: new Date().toISOString(),
      sourceFile: workFile,
      tables,
      totalInserts,
      totalUpdates,
      totalSqliteOnly,
      cleanAfterApply,
    };
  } finally {
    await pgTarget.close();
  }
}
