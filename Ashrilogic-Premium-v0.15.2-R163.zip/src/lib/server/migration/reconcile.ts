/**
 * Ashrilogic — migration state reconciliation at startup (split-brain guard).
 *
 * THE HOLE THIS CLOSES: the migration state machine lives in the SQLite
 * control plane, but the APPLICATION serves from whatever DATABASE_URL
 * points at. Between "operator repoints DATABASE_URL + restarts" and
 * "confirm-primary lands", the two sources of truth can disagree:
 *
 *   - app on PostgreSQL, SQLite state still READY_FOR_CUTOVER/CUTOVER —
 *     the operator flipped the DSN but the freeze-holder process died
 *     (or the marker was never written) before persisting the outcome;
 *   - app on SQLite, state still POSTGRES_PRIMARY/ROLLBACK_WINDOW — the
 *     operator rolled the DSN back but never ran the completion command.
 *
 * Both are SPLIT-BRAIN: a later destructive action (rollback, archive,
 * re-cutover) taken from the stale state could destroy the wrong primary.
 * This module runs at every server boot and reconciles the persisted
 * state to the OBSERVED runtime reality (the app's provider), through
 * LEGAL state-machine transitions only, each one audited. Destructive
 * rollback while ambiguous is exactly what becomes impossible.
 *
 * Reconciliation is conservative:
 *   - it only ever ADVANCES the machine in the direction reality already
 *     took (PG serving → primary record; SQLite serving → steady state);
 *   - UNRESOLVABLE configurations (PG serving with no cutover record at
 *     all, control plane unreachable) are logged CRITICAL with operator
 *     guidance — never silently patched over.
 */

import { currentProvider } from "@/lib/db";
import { readState, canTransition, updateManifest, MIGRATION_STATES } from "./state-machine";
import { migLog } from "./logger";

/** Legal transition chain from any in-flight state to POSTGRES_PRIMARY +
 *  ROLLBACK_WINDOW (the "PG is serving" reconciliation target). */
const TO_PG_PRIMARY: Partial<Record<string, string[]>> = {
  READY_FOR_CUTOVER: ["QUIESCING", "CUTOVER", "POSTGRES_PRIMARY", "ROLLBACK_WINDOW"],
  QUIESCING: ["CUTOVER", "POSTGRES_PRIMARY", "ROLLBACK_WINDOW"],
  CUTOVER: ["POSTGRES_PRIMARY", "ROLLBACK_WINDOW"],
  POSTGRES_PRIMARY: ["ROLLBACK_WINDOW"],
  ROLLBACK_WINDOW: [],
};

/** Legal chain when SQLite is serving again (rollback landed implicitly). */
const TO_SQLITE_ONLY: Partial<Record<string, string[]>> = {
  POSTGRES_PRIMARY: ["ROLLBACK_WINDOW", "SQLITE_ONLY"],
  ROLLBACK_WINDOW: ["SQLITE_ONLY"],
  CUTOVER: ["CHANGE_CAPTURE"], // freeze-holder died mid-freeze; abort semantics
};

export interface ReconciliationResult {
  action: "consistent" | "reconciled" | "critical" | "unresolvable" | "skipped";
  detail: string;
  transitions?: string[];
}

function isState(name: string): name is (typeof MIGRATION_STATES)[number] {
  return (MIGRATION_STATES as readonly string[]).includes(name);
}

/** Walk a legal chain from the current state, mutating the manifest once. */
async function walkChain(
  chain: string[],
  cause: string
): Promise<{ transitions: string[] } | { blocked: string }> {
  const walked: string[] = [];
  for (const step of chain) {
    if (!isState(step)) return { blocked: `illegal state name ${step}` };
    if (!(await canTransitionTo(step))) {
      return { blocked: `transition to ${step} rejected` };
    }
    await updateManifest(step, (m) => {
      m.lastError = {
        at: new Date().toISOString(),
        phase: step,
        message: `startup reconciliation: ${cause}`,
      };
    });
    walked.push(step);
  }
  return { transitions: walked };
}

async function canTransitionTo(step: string): Promise<boolean> {
  if (!isState(step)) return false;
  const current = await readState();
  return canTransition(current.state, step);
}

/**
 * Reconcile the persisted migration state against the app's live provider.
 * NEVER throws — reconciliation failure degrades to a critical log entry.
 */
export async function reconcileMigrationState(): Promise<ReconciliationResult> {
  const provider = currentProvider();
  let current;
  try {
    current = await readState();
  } catch (error) {
    const detail =
      error instanceof Error ? error.message.slice(0, 300) : String(error);
    migLog.error("reconcile.control-plane-unreachable", {
      detail,
      result: "OPERATOR ACTION REQUIRED (see message) — server continues on the configured provider",
    });
    return {
      action: "unresolvable",
      detail: `control plane unreachable: ${detail}`,
    };
  }

  const state = current.state;
  const migrationId = current.migrationId ?? undefined;

  /* ---------- case 1: app serves from PostgreSQL ---------------------- */
  if (provider === "postgresql") {
    if (state === "ROLLBACK_WINDOW" || state === "SQLITE_ARCHIVED") {
      return { action: "consistent", detail: `PG primary, state ${state}` };
    }
    const chain = TO_PG_PRIMARY[state];
    if (chain) {
      const walked = await walkChain(
        chain,
        `app serves PostgreSQL (DATABASE_URL) while state was ${state} — completing the cutover record`
      );
      if ("transitions" in walked) {
        migLog.warn("reconcile.split-brain-resolved", {
          migrationId,
          phase: "ROLLBACK_WINDOW",
          result: `PG serving with stale state ${state} — reconciled via ${walked.transitions.join("→")}`,
        });
        return {
          action: "reconciled",
          detail: `PG primary serving; state ${state} advanced to ROLLBACK_WINDOW`,
          transitions: walked.transitions,
        };
      }
      migLog.error("reconcile.split-brain-unresolved", {
        migrationId,
        phase: state,
        result: walked.blocked,
        detail: "PostgreSQL is serving but the migration record cannot be advanced — run `bun scripts/pg-migrate.ts status` and resolve manually; do NOT run rollback while ambiguous",
      });
      return { action: "critical", detail: walked.blocked };
    }

    if (state === "SQLITE_ONLY" || state === "PREPARING" || state === "SNAPSHOT_CREATED" ||
        state === "INITIAL_COPY" || state === "CHANGE_CAPTURE" || state === "REPLAYING" ||
        state === "VERIFYING") {
      /* PG serving with NO cutover record — the target was never verified
         or even populated; this is an unvalidated manual flip */
      migLog.error("reconcile.postgres-without-cutover", {
        migrationId,
        phase: state,
        result: "DATABASE_URL points at PostgreSQL but no cutover was ever confirmed — the target database may be empty or stale",
        detail: "verify the PostgreSQL database contents before serving traffic; the migration record shows no completed cutover",
      });
      return {
        action: "critical",
        detail: `PG primary with pre-cutover state ${state} — verify target data before serving traffic`,
      };
    }
    return { action: "consistent", detail: `PG primary, state ${state}` };
  }

  /* ---------- case 2: app serves from SQLite --------------------------- */
  if (state === "SQLITE_ONLY" || state === "PREPARING" || state === "SNAPSHOT_CREATED" ||
      state === "INITIAL_COPY" || state === "CHANGE_CAPTURE" || state === "REPLAYING" ||
      state === "VERIFYING" || state === "READY_FOR_CUTOVER") {
    return { action: "consistent", detail: `SQLite primary, state ${state}` };
  }
  if (state === "CUTOVER" || state === "QUIESCING") {
    /* the freeze-holder died mid-freeze (the freeze itself auto-released
       with the process); the run may abort or re-attempt — never auto-
       destructive */
    migLog.warn("reconcile.mid-cutover-crash", {
      migrationId,
      phase: state,
      result: "cutover freeze-holder is gone (crash) — resolve with `bun scripts/pg-migrate.ts abort-cutover` (SQLite stayed primary) or re-run `cutover`",
    });
    return {
      action: "critical",
      detail: `state ${state} without a live freeze-holder — run abort-cutover or re-run cutover`,
    };
  }
  const chain = TO_SQLITE_ONLY[state];
  if (chain) {
    const walked = await walkChain(
      chain,
      `app serves SQLite (DATABASE_URL) while state was ${state} — recording the implicit rollback`
    );
    if ("transitions" in walked) {
      migLog.warn("reconcile.rollback-resolved", {
        migrationId,
        phase: "SQLITE_ONLY",
        result: `SQLite serving with state ${state} — reconciled via ${walked.transitions.join("→")}`,
      });
      return {
        action: "reconciled",
        detail: `SQLite primary serving; state ${state} reconciled to SQLITE_ONLY`,
        transitions: walked.transitions,
      };
    }
    migLog.error("reconcile.rollback-unresolved", {
      migrationId,
      phase: state,
      result: walked.blocked,
    });
    return { action: "critical", detail: walked.blocked };
  }
  if (state === "SQLITE_ARCHIVED") {
    /* archived control plane, SQLite serving again — operator revived the
       archive; treat as steady state but surface it */
    migLog.warn("reconcile.sqlite-revived", {
      migrationId,
      phase: state,
      result: "SQLite is serving after the rollback window was archived — acceptable steady state, migration record retained",
    });
    return { action: "skipped", detail: `SQLite serving with archived record` };
  }
  return { action: "consistent", detail: `SQLite primary, state ${state}` };
}
