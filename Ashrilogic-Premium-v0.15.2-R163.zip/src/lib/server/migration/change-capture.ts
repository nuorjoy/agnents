/**
 * Ashrilogic — durable change capture (SQLite → PostgreSQL).
 *
 * Change capture is implemented with SQLITE TRIGGERS, not application-code
 * hooks: every INSERT/UPDATE/DELETE on a business table appends a
 * MigrationEvent row INSIDE THE SAME TRANSACTION as the source mutation —
 * the capture record is committed atomically with the change it describes.
 * No code path can write a row without leaving an event (raw SQL, scripts,
 * future refactors included), and no application-log parsing is involved.
 *
 * Triggers are installed ONLY while a migration run is active (PREPARING →
 * CUTOVER/ROLLBACK): a steady-state SQLITE_ONLY deployment pays zero
 * capture overhead.
 *
 * Event sealing: each event carries an HMAC-SHA256 checksum (key derived
 * from ASHRILOGIC_DATA_KEY via HKDF, domain-separated) computed on first
 * read and verified on EVERY later read — a tampered event halts replay
 * instead of being applied.
 */

import { createHmac, hkdfSync } from "node:crypto";
import { controlDb } from "./control-db";
import { BUSINESS_TABLES, TENANT_TABLES } from "./tables";
import { migLog } from "./logger";
import { prismaAccess, type SqlAccess } from "./sqlite-access";

const IDENT_RE = /^[A-Za-z_][A-Za-z0-9_]*$/;

export interface MigrationEventRow {
  sequence: number;
  eventId: string;
  tenantId: string | null;
  tableName: string;
  recordId: string;
  op: "insert" | "update" | "delete";
  beforeJson: string | null;
  afterJson: string | null;
  ts: number;
  checksum: string | null;
}

/* ------------------------------ event sealing ----------------------------- */

let sealedKey: Buffer | null = null;

/** HKDF-derived event checksum key (domain-separated from every other key). */
function eventKey(): Buffer {
  if (sealedKey) return sealedKey;
  const secret =
    process.env.ASHRILOGIC_DATA_KEY ?? "ashrilogic-demo-field-encryption-key-rotate-me";
  sealedKey = Buffer.from(
    hkdfSync("sha256", Buffer.from(secret, "utf8"), Buffer.alloc(0), "ashrilogic/migration-event-hmac/v1", 32)
  );
  return sealedKey;
}

/** Canonical event serialization — the checksum input. */
export function canonicalEventJson(e: {
  sequence: number;
  eventId: string;
  tenantId: string | null;
  tableName: string;
  recordId: string;
  op: string;
  beforeJson: string | null;
  afterJson: string | null;
  ts: number;
}): string {
  return JSON.stringify([
    e.sequence,
    e.eventId,
    e.tenantId,
    e.tableName,
    e.recordId,
    e.op,
    e.beforeJson,
    e.afterJson,
    e.ts,
  ]);
}

export function eventChecksum(e: Parameters<typeof canonicalEventJson>[0]): string {
  return createHmac("sha256", eventKey()).update(canonicalEventJson(e), "utf8").digest("hex");
}

/* ------------------------------ trigger install ---------------------------- */

function quoteIdent(name: string): string {
  if (!IDENT_RE.test(name)) throw new Error(`unsafe identifier: ${name}`);
  return `"${name}"`;
}

/** Deterministic trigger names (≤ SQLite's 31-char identifier budget used
 *  conservatively with the _mig_ prefix + table + op suffix). */
function triggerName(table: string, op: "ins" | "upd" | "del"): string {
  return `_mig_${table.slice(0, 14)}_${op}`;
}

interface ColumnMeta {
  name: string;
  type: string;
  pk: number;
}

/** Generate the three capture triggers for one table. */
function triggerSqlFor(table: string, cols: ColumnMeta[]): string[] {
  const q = quoteIdent(table);
  const tenantExpr = TENANT_TABLES.has(table);
  const colList = cols.map((c) => quoteIdent(c.name)).join(", ");
  const afterObj = `json_object(${cols.map((c) => `'${c.name}', ${ref("NEW", c.name)}`).join(", ")})`;
  const beforeObj = `json_object(${cols.map((c) => `'${c.name}', ${ref("OLD", c.name)}`).join(", ")})`;
  const pkCol = cols.find((c) => c.pk > 0)?.name ?? "id";

  const base = (op: string, row: "NEW" | "OLD") =>
    `INSERT INTO "MigrationEvent" ("eventId", "tenantId", "tableName", "recordId", "op", "beforeJson", "afterJson", "ts")
     VALUES (
       lower(hex(randomblob(16))),
       ${tenantExpr ? `${row}."instanceId"` : "NULL"},
       '${table}',
       ${row}.${quoteIdent(pkCol)},
       '${op}',
       ${op === "insert" ? "NULL" : op === "delete" ? beforeObj : beforeObj},
       ${op === "delete" ? "NULL" : afterObj},
       CAST(strftime('%s','now') AS INTEGER) * 1000
     )`;

  return [
    `CREATE TRIGGER ${quoteIdent(triggerName(table, "ins"))} AFTER INSERT ON ${q} BEGIN ${base("insert", "NEW")}; END`,
    `CREATE TRIGGER ${quoteIdent(triggerName(table, "upd"))} AFTER UPDATE ON ${q} BEGIN ${base("update", "NEW")}; END`,
    `CREATE TRIGGER ${quoteIdent(triggerName(table, "del"))} AFTER DELETE ON ${q} BEGIN ${base("delete", "OLD")}; END`,
  ];
}

/** NEW/OLD row reference with NULL-safe pass-through. */
function ref(row: "NEW" | "OLD", col: string): string {
  return `${row}.${quoteIdent(col)}`;
}

/** Install capture triggers on every business table (idempotent).
 *
 * Also installs the EVENT-LOG GUARDS: while a run is active, UPDATE and
 * DELETE on MigrationEvent / MigrationEventSeal raise RAISE(ABORT) — the
 * captured stream is APPEND-ONLY at the SQL boundary. That is the
 * capture-time authenticity guarantee: no SQL path can rewrite or remove
 * an event after the transaction that captured it (the lazy per-row
 * checksum stays as the file-level tamper detector; the guards make the
 * log immutable through SQL). uninstallTriggers drops the guards for
 * legitimate teardown (abort clears the log, controller maintenance). */
export async function installTriggers(): Promise<number> {
  let installed = 0;
  for (const table of BUSINESS_TABLES) {
    const cols = (await controlDb().$queryRawUnsafe(
      `SELECT name, type, pk FROM pragma_table_info('${table}')`
    )) as ColumnMeta[];
    if (cols.length === 0) continue;
    for (const sql of triggerSqlFor(table, cols)) {
      // drop-then-create keeps the DDL idempotent across re-runs
      const name = sql.match(/CREATE TRIGGER "([^"]+)"/)?.[1];
      if (name) {
        await controlDb().$executeRawUnsafe(`DROP TRIGGER IF EXISTS ${quoteIdent(name)}`);
      }
      await controlDb().$executeRawUnsafe(sql);
      installed++;
    }
  }
  for (const guard of eventGuardSql()) {
    const name = guard.match(/CREATE TRIGGER "([^"]+)"/)?.[1];
    if (name) {
      await controlDb().$executeRawUnsafe(`DROP TRIGGER IF EXISTS ${quoteIdent(name)}`);
    }
    await controlDb().$executeRawUnsafe(guard);
    installed++;
  }
  migLog.info("capture.triggers.installed", { result: `${installed} triggers (incl. event-log append guards)` });
  return installed;
}

/** Append-only guards for the event log + seal chain (SQL-level integrity). */
function eventGuardSql(): string[] {
  return [
    `CREATE TRIGGER "_mig_evt_guard_upd" BEFORE UPDATE ON "MigrationEvent" BEGIN SELECT RAISE(ABORT, 'MigrationEvent is append-only during a migration run'); END`,
    `CREATE TRIGGER "_mig_evt_guard_del" BEFORE DELETE ON "MigrationEvent" BEGIN SELECT RAISE(ABORT, 'MigrationEvent is append-only during a migration run'); END`,
    `CREATE TRIGGER "_mig_seal_guard_upd" BEFORE UPDATE ON "MigrationEventSeal" BEGIN SELECT RAISE(ABORT, 'MigrationEventSeal is append-only during a migration run'); END`,
    `CREATE TRIGGER "_mig_seal_guard_del" BEFORE DELETE ON "MigrationEventSeal" BEGIN SELECT RAISE(ABORT, 'MigrationEventSeal is append-only during a migration run'); END`,
  ];
}

/** Remove every capture trigger + event-log guard (steady state / rollback /
 *  archive / controlled log maintenance). */
export async function uninstallTriggers(): Promise<number> {
  let removed = 0;
  for (const table of BUSINESS_TABLES) {
    for (const op of ["ins", "upd", "del"] as const) {
      const name = triggerName(table, op);
      await controlDb().$executeRawUnsafe(`DROP TRIGGER IF EXISTS ${quoteIdent(name)}`);
      removed++;
    }
  }
  for (const name of ["_mig_evt_guard_upd", "_mig_evt_guard_del", "_mig_seal_guard_upd", "_mig_seal_guard_del"]) {
    await controlDb().$executeRawUnsafe(`DROP TRIGGER IF EXISTS ${quoteIdent(name)}`);
    removed++;
  }
  migLog.info("capture.triggers.removed", { result: `${removed} triggers` });
  return removed;
}

/** Are triggers currently installed (capture live)? */
export async function triggersInstalled(): Promise<boolean> {
  const rows = (await controlDb().$queryRawUnsafe(
    `SELECT COUNT(*) AS c FROM sqlite_master WHERE type='trigger' AND name LIKE '\\_mig\\_%' ESCAPE '\\'`
  )) as { c: number }[];
  return (rows[0]?.c ?? 0) > 0;
}

/* ------------------------------ watermark + read --------------------------- */

/** Max event sequence committed so far (the current capture position).
 *  `sql` routes through the lock-holder connection during the exclusive
 *  cutover window (the Prisma pool is frozen then). */
export async function currentWatermark(
  sql: SqlAccess = prismaAccess()
): Promise<number> {
  const rows = await sql.query<{ w: number | bigint }>(
    `SELECT COALESCE(MAX("sequence"), 0) AS w FROM "MigrationEvent"`
  );
  return Number(rows[0]?.w ?? 0);
}

/**
 * Read events strictly after `afterSequence`, ascending, sealed + verified.
 *
 * SEAL MODEL (capture-time immutability + read-time chain): the event table
 * itself is APPEND-ONLY while a run is active (RAISE(ABORT) guards — see
 * installTriggers), so captured events cannot be modified or removed
 * through ANY SQL path. The seal CHAIN (MigrationEventSeal, also
 * append-only) is written on first read:
 *   sealHash_i = HMAC(key, sealHash_{i-1} || canonicalEvent_i)
 * anchored on a genesis constant, so removing or mutating an event (or
 * reordering) breaks the chain at the next sealed event and halts replay
 * — tampered events are NEVER applied. The legacy per-row `checksum`
 * column is populated read-time as a redundant per-row digest (kept for
 * runbook compatibility / verify-audit tooling).
 *
 * `sql` routes through the lock-holder connection during the exclusive
 * cutover window (Prisma's pool is frozen then).
 */
export async function readEvents(
  afterSequence: number,
  limit = 500,
  sql: SqlAccess = prismaAccess()
): Promise<MigrationEventRow[]> {
  const rows = await sql.query<{
    sequence: number | bigint;
    eventId: string;
    tenantId: string | null;
    tableName: string;
    recordId: string;
    op: string;
    beforeJson: string | null;
    afterJson: string | null;
    ts: number | bigint;
    checksum: string | null;
  }>(
    `SELECT "sequence", "eventId", "tenantId", "tableName", "recordId", "op",
            "beforeJson", "afterJson", "ts", "checksum"
     FROM "MigrationEvent" WHERE "sequence" > ? ORDER BY "sequence" ASC LIMIT ?`,
    [afterSequence, limit]
  );
  if (rows.length === 0) return [];

  /* the chain value BEFORE the first event of this batch (genesis when the
     log starts here) — read from the LAST sealed row ≤ afterSequence */
  const lastSealed = await sql.query<{ sealHash: string }>(
    `SELECT "sealHash" FROM "MigrationEventSeal" WHERE "sequence" <= ? ORDER BY "sequence" DESC LIMIT 1`,
    [afterSequence]
  );
  let chainHash = lastSealed[0]?.sealHash ?? genesisSeal();

  /* seals covering this batch's range (verified below) */
  const batchEnd = Number(rows[rows.length - 1]!.sequence);
  const sealRows = await sql.query<{ sequence: number | bigint; sealHash: string }>(
    `SELECT "sequence", "sealHash" FROM "MigrationEventSeal"
     WHERE "sequence" > ? AND "sequence" <= ? ORDER BY "sequence" ASC`,
    [afterSequence, batchEnd]
  );
  const sealed = new Map<number, string>();
  for (const s of sealRows) sealed.set(Number(s.sequence), s.sealHash);

  const out: MigrationEventRow[] = [];
  for (const r of rows) {
    const ev: MigrationEventRow = {
      sequence: Number(r.sequence),
      eventId: r.eventId,
      tenantId: r.tenantId,
      tableName: r.tableName,
      recordId: r.recordId,
      op: r.op as MigrationEventRow["op"],
      beforeJson: r.beforeJson,
      afterJson: r.afterJson,
      ts: Number(r.ts),
      checksum: r.checksum,
    };

    /* advance the chain over THIS event and verify/extend the seal */
    chainHash = chainSeal(chainHash, canonicalEventJson(ev));
    const existing = sealed.get(ev.sequence);
    if (existing === undefined) {
      /* first read — seal it (append-only INSERT; a guard blocks rewrites) */
      await sql.execute(
        `INSERT INTO "MigrationEventSeal" ("sequence", "sealHash", "sealedAt") VALUES (?, ?, ?)`,
        [ev.sequence, chainHash, Date.now()]
      );
      sealed.set(ev.sequence, chainHash);
    } else if (existing !== chainHash) {
      /* sealed content no longer chains — the event (or an earlier one in
         the chain) was modified/removed/reordered — halt, never apply */
      throw new Error(
        `migration event ${ev.sequence} (${ev.tableName}/${ev.recordId}) broke the seal chain — halting replay`
      );
    }

    /* legacy per-row digest: populate read-time for tooling compatibility;
       an existing MISMATCH is a second, independent tamper signal */
    const rowDigest = eventChecksum(ev);
    if (ev.checksum === null) {
      try {
        await sql.execute(
          `UPDATE "MigrationEvent" SET "checksum" = ? WHERE "sequence" = ?`,
          [rowDigest, ev.sequence]
        );
      } catch {
        /* the append-only guard rejects the UPDATE while a run is active —
           the seal chain is the authoritative integrity boundary; the
           legacy column stays NULL and is NOT a failure */
      }
      ev.checksum = rowDigest;
    } else if (ev.checksum !== rowDigest) {
      throw new Error(
        `migration event ${ev.sequence} (${ev.tableName}/${ev.recordId}) failed its integrity checksum — halting replay`
      );
    }
    out.push(ev);
  }
  return out;
}

/** Genesis anchor of the seal chain (domain-separated constant). */
function genesisSeal(): string {
  return createHmac("sha256", eventKey())
    .update("ashrilogic/migration-event-chain/genesis/v1")
    .digest("hex");
}

/** One chain step: HMAC over (previous seal hash || canonical event). */
function chainSeal(prevHash: string, canonical: string): string {
  return createHmac("sha256", eventKey())
    .update(`${prevHash}|${canonical}`, "utf8")
    .digest("hex");
}

/** Structural validation of an event against the live schema (tenant
 *  safety: the row's instanceId must equal the event's tenantId claim). */
export function validateEventTenant(
  ev: MigrationEventRow
): { ok: true } | { ok: false; reason: string } {
  if (!TENANT_TABLES.has(ev.tableName)) return { ok: true };
  const payload = ev.op === "delete" ? ev.beforeJson : ev.afterJson;
  if (!payload) return { ok: false, reason: "missing payload" };
  try {
    const row = JSON.parse(payload) as Record<string, unknown>;
    if (typeof row.instanceId !== "string" || row.instanceId !== ev.tenantId) {
      return {
        ok: false,
        reason: `tenant mismatch: event claims ${ev.tenantId} but row carries ${String(row.instanceId)}`,
      };
    }
    return { ok: true };
  } catch {
    return { ok: false, reason: "unparseable payload" };
  }
}

/** Count events pending after a sequence (replication lag). */
export async function pendingEventCount(
  afterSequence: number,
  sql: SqlAccess = prismaAccess()
): Promise<number> {
  const rows = await sql.query<{ c: number | bigint }>(
    `SELECT COUNT(*) AS c FROM "MigrationEvent" WHERE "sequence" > ?`,
    [afterSequence]
  );
  return Number(rows[0]?.c ?? 0);
}
