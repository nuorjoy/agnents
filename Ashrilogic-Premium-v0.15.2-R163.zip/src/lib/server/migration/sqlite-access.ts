/**
 * Ashrilogic — unified SQLite access for the migration controller.
 *
 * Two backing implementations, one interface:
 *  - PrismaSqlAccess — the application's pooled Prisma client (every phase
 *    except the exclusive-lock cutover window).
 *  - RawSqlAccess    — a dedicated bun:sqlite connection. REQUIRED while the
 *    controller holds BEGIN EXCLUSIVE during QUIESCING/CUTOVER: every other
 *    connection (including Prisma's pool) is blocked by the controller's own
 *    write freeze, so ALL controller SQLite traffic must flow through the
 *    lock-holder connection itself.
 */

export interface SqlAccess {
  /** SELECT rows. */
  query<T = Record<string, unknown>>(sql: string, params?: unknown[]): Promise<T[]>;
  /** INSERT/UPDATE/DELETE (no result). */
  execute(sql: string, params?: unknown[]): Promise<void>;
}

export function prismaAccess(): SqlAccess {
  // lazy import avoids a module cycle (control-db ← many migration modules)
  const dbPromise = import("./control-db").then((m) => m.controlDb());
  return {
    async query<T>(sql: string, params: unknown[] = []): Promise<T[]> {
      const db = await dbPromise;
      if (params.length === 0) return (await db.$queryRawUnsafe(sql)) as T[];
      return (await db.$queryRawUnsafe(sql, ...params)) as T[];
    },
    async execute(sql: string, params: unknown[] = []): Promise<void> {
      const db = await dbPromise;
      if (params.length === 0) {
        await db.$executeRawUnsafe(sql);
      } else {
        await db.$executeRawUnsafe(sql, ...params);
      }
    },
  };
}

export function rawAccess(sqlite: import("bun:sqlite").Database): SqlAccess {
  return {
    async query<T>(sql: string, params: unknown[] = []): Promise<T[]> {
      return (params.length === 0
        ? sqlite.query(sql).all()
        : sqlite.query(sql).all(...(params as import("bun:sqlite").SQLQueryBindings[]))) as T[];
    },
    async execute(sql: string, params: unknown[] = []): Promise<void> {
      if (params.length === 0) sqlite.query(sql).run();
      else sqlite.query(sql).run(...(params as import("bun:sqlite").SQLQueryBindings[]));
    },
  };
}
