/**
 * Ashrilogic — structured migration logging.
 *
 * Every line is a single JSON object with the correlation keys the runbook
 * needs (migrationId, phase, tenantId, eventId, sequence, duration, result).
 *
 * REDACTION CONTRACT (mirrors the platform-wide logging policy): row
 * payloads, sealed envelopes, passwords, session tokens and key material are
 * NEVER logged — only identifiers, counts and digests. The change-capture
 * payload lives in MigrationEvent rows, not in logs.
 */

type Level = "info" | "warn" | "error";

export interface LogFields {
  migrationId?: string;
  phase?: string;
  tenantId?: string;
  eventId?: string;
  sequence?: number;
  table?: string;
  durationMs?: number;
  result?: string;
  detail?: string;
  [key: string]: unknown;
}

function emit(level: Level, event: string, fields: LogFields): void {
  const line = JSON.stringify({
    ts: new Date().toISOString(),
    level,
    event: `migration.${event}`,
    ...fields,
  });
  if (level === "error") console.error(line);
  else if (level === "warn") console.warn(line);
  else console.info(line);
}

export const migLog = {
  info: (event: string, fields: LogFields = {}) => emit("info", event, fields),
  warn: (event: string, fields: LogFields = {}) => emit("warn", event, fields),
  error: (event: string, fields: LogFields = {}) => emit("error", event, fields),
};
