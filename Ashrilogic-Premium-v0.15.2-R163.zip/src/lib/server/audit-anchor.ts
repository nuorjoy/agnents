import { createHmac, hkdfSync, timingSafeEqual } from "node:crypto";
import { appendFile, mkdir, readFile } from "node:fs/promises";
import { dirname } from "node:path";
import { join } from "node:path";
import { existsSync } from "node:fs";
import { db } from "@/lib/db";
import { loadSecret } from "@/lib/server/runtime-guard";
import { withJobLease } from "@/lib/server/job-lease";
import { logAudit } from "@/lib/server/audit";
import { opLog } from "@/lib/server/oplog";

/**
 * Ashrilogic — ROUND 118 — AUDIT-CHAIN HEAD ANCHOR.
 *
 * The audit hash chain (round 38) is tamper-EVIDENT inside the database:
 * row edits, mid-chain deletions and forks are all caught by
 * verifyChainHashes. Its documented honesty limit was always the TAIL —
 * an attacker with a DATABASE-ONLY compromise can delete the NEWEST rows
 * and leave a valid, shorter chain. The ROUND 96 anchor covers the BOTTOM
 * boundary (retention pruning); nothing pinned the top.
 *
 * THE HEAD ANCHOR closes that gap:
 *
 *   periodically (hourly safety net, or the console's "anchor now") the
 *   chain's CURRENT HEAD — the newest row's id + chainHash + counts — is
 *   sealed into a compact JSON line and APPENDED to a file that lives
 *   OUTSIDE the database file (data/audit-anchors.jsonl). The seal is an
 *   HMAC over the canonical payload with a key HKDF-derived from
 *   ASHRILOGIC_DATA_KEY under a purpose string DISTINCT from the chain
 *   key (purpose separation: the chain key can never mint anchors and
 *   vice versa; a data-key rotation invalidates both, and the documented
 *   re-seal path re-derives them together).
 *
 * What verification can then PROVE that the in-DB chain cannot:
 *   TRUNCATED — the row that was the head at anchor time is gone while
 *               it is still inside every legitimate retention window
 *               (a newer-than-anchor row can never be retention-pruned);
 *   TAMPERED  — that row still exists but its stored hash no longer
 *               matches the sealed hash (the row was rewritten);
 *   STALE     — the anchor file has not been refreshed inside the safety
 *               net's freshness horizon (investigate the scheduler/lease).
 *
 * Honest limits (documented, by design):
 *   - rows appended AND deleted BETWEEN two anchor ticks were never
 *     pinned — the hourly cadence bounds that window to one hour;
 *   - the file is append-only on the same host: an attacker with BOTH
 *     filesystem and key access can forge anything (the anchor raises
 *     the bar against DB-only compromises, it is not WORM storage);
 *   - a partially-written last line (crash mid-append) is reported as
 *     tailCorrupt and the last VERIFIABLE line is used instead.
 */

/* ------------------------------- key material ------------------------------ */

function loadAnchorKeySecret(): string {
  return loadSecret({
    envVar: "ASHRILOGIC_DATA_KEY",
    minLen: 16,
    demoValue: "ashrilogic-demo-field-encryption-key-rotate-me",
    label: "audit-anchor key",
  });
}

const ANCHOR_KEY = Buffer.from(
  hkdfSync(
    "sha256",
    Buffer.from(loadAnchorKeySecret(), "utf8"),
    Buffer.alloc(0),
    /* deliberately distinct from audit-chain-hmac/v1 — purpose separation */
    "ashrilogic/audit-anchor-hmac/v1",
    32
  )
);

/** The MAC over an anchor line's canonical payload (exported for tests). */
export function computeAnchorMac(canonical: string): string {
  return createHmac("sha256", ANCHOR_KEY).update(canonical, "utf8").digest("hex");
}

/* ------------------------------ anchor storage ----------------------------- */

/** The sealed payload — one JSON line per anchor event. */
export interface HeadAnchorPayload {
  v: 1;
  trigger: "auto" | "manual";
  anchoredAt: string;
  /** id of the newest CHAINED row at anchor time */
  headRowId: string;
  /** its chainHash — the pinned trust point */
  headHash: string;
  /** total audit rows (chained + unchained) at anchor time */
  totalRows: number;
  /** chained rows only (hash coverage accounting) */
  chainedRows: number;
}

/**
 * Repository root — resolved lazily (never at module import: tests override
 * env/cwd before the first dynamic import). Same discipline as image-store.
 */
function repoRoot(): string {
  let dir = process.cwd();
  for (let i = 0; i < 6; i++) {
    if (existsSync(join(dir, "package.json")) && existsSync(join(dir, "prisma"))) {
      return dir;
    }
    const parent = dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return process.cwd();
}

/**
 * The anchor file — OUTSIDE the database (the entire point). Override with
 * ASHRILOGIC_AUDIT_ANCHOR_FILE (tests point it at a temp file; production
 * may point it at mounted WORM storage).
 */
export function anchorFilePath(): string {
  return process.env.ASHRILOGIC_AUDIT_ANCHOR_FILE ?? join(repoRoot(), "data", "audit-anchors.jsonl");
}

/** Canonical, unambiguous serialization — a fixed-order JSON array. */
export function canonicalAnchorJson(p: HeadAnchorPayload): string {
  return JSON.stringify([
    p.v,
    p.trigger,
    p.anchoredAt,
    p.headRowId,
    p.headHash,
    p.totalRows,
    p.chainedRows,
  ]);
}

/** Verify one line's MAC (line = canonical + `,mac` fields in an object). */
function verifyLine(line: string): HeadAnchorPayload | null {
  try {
    const parsed = JSON.parse(line) as Record<string, unknown>;
    const { v, trigger, anchoredAt, headRowId, headHash, totalRows, chainedRows, mac } = parsed;
    if (
      v !== 1 ||
      (trigger !== "auto" && trigger !== "manual") ||
      typeof anchoredAt !== "string" ||
      typeof headRowId !== "string" ||
      typeof headHash !== "string" ||
      typeof totalRows !== "number" ||
      typeof chainedRows !== "number" ||
      typeof mac !== "string"
    ) {
      return null;
    }
    const payload: HeadAnchorPayload = { v, trigger, anchoredAt, headRowId, headHash, totalRows, chainedRows };
    const expected = computeAnchorMac(canonicalAnchorJson(payload));
    /* constant-time compare of the hex digests */
    const a = Buffer.from(expected, "hex");
    const b = Buffer.from(mac, "hex");
    if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
    return payload;
  } catch {
    return null;
  }
}

/* ------------------------------ chain head read ----------------------------- */

export interface ChainHeadInfo {
  headRowId: string;
  headHash: string;
  totalRows: number;
  chainedRows: number;
}

/** Snapshot the chain's current head (null when no chained rows exist). */
export async function getChainHead(): Promise<ChainHeadInfo | null> {
  const [head, totalRows, chainedRows] = await Promise.all([
    db.auditLog.findFirst({
      where: { chainHash: { not: null } },
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      select: { id: true, chainHash: true },
    }),
    db.auditLog.count(),
    db.auditLog.count({ where: { chainHash: { not: null } } }),
  ]);
  if (!head) return null;
  return {
    headRowId: head.id,
    headHash: head.chainHash as string,
    totalRows,
    chainedRows,
  };
}

/* ------------------------------ anchor appends ------------------------------ */

/**
 * Seal + append the current head as one JSON line. Returns the payload
 * (null when there is nothing to anchor — a chainless install).
 * Never throws to the caller's request path: a storage failure returns
 * { ok: false } so the console can surface it.
 */
export async function appendHeadAnchor(
  trigger: "auto" | "manual"
): Promise<{ ok: true; payload: HeadAnchorPayload } | { ok: false; error: string }> {
  try {
    const head = await getChainHead();
    if (!head) return { ok: false, error: "no chained rows to anchor" };

    const payload: HeadAnchorPayload = {
      v: 1,
      trigger,
      anchoredAt: new Date().toISOString(),
      headRowId: head.headRowId,
      headHash: head.headHash,
      totalRows: head.totalRows,
      chainedRows: head.chainedRows,
    };
    const line = `${JSON.stringify({ ...payload, mac: computeAnchorMac(canonicalAnchorJson(payload)) })}\n`;

    const file = anchorFilePath();
    await mkdir(dirname(file), { recursive: true });
    await appendFile(file, line, "utf8");
    return { ok: true, payload };
  } catch (error) {
    const message = error instanceof Error ? error.message : "unknown anchor failure";
    opLog.warn("audit-anchor.append-failed", { trigger, result: message });
    return { ok: false, error: message };
  }
}

/* ------------------------------ anchor reading ------------------------------ */

export interface ReadAnchorResult {
  /** the last MAC-verified anchor (null when none) */
  anchor: HeadAnchorPayload | null;
  /** the file's last line failed MAC/parse (partial write / tamper) */
  tailCorrupt: boolean;
  /** the file exists but is empty */
  empty: boolean;
  /** the file could not be read at all */
  unreadable: boolean;
}

/**
 * Read + verify the newest usable anchor. A corrupt TAIL line is reported
 * separately (tailCorrupt) while the last VERIFIABLE line still anchors —
 * a crash mid-append must never blind the whole mechanism.
 */
export async function readLatestHeadAnchor(): Promise<ReadAnchorResult> {
  let raw: string;
  try {
    raw = await readFile(anchorFilePath(), "utf8");
  } catch (error) {
    /* ENOENT = never anchored (a fresh install — not an error state);
     * anything else (EACCES, EMFILE…) = the file exists but cannot be
     * read — surfaced separately so the console can say so. */
    const code = (error as NodeJS.ErrnoException)?.code;
    if (code === "ENOENT") {
      return { anchor: null, tailCorrupt: false, empty: false, unreadable: false };
    }
    return { anchor: null, tailCorrupt: false, empty: false, unreadable: true };
  }
  const lines = raw.split("\n").filter((l) => l.trim().length > 0);
  if (lines.length === 0) return { anchor: null, tailCorrupt: false, empty: true, unreadable: false };

  /* walk from the end: skip at most ONE bad tail (partial write), then the
   * first verifiable line wins; anything before it was superseded anyway */
  let tailCorrupt = false;
  for (let i = lines.length - 1; i >= 0; i--) {
    const payload = verifyLine(lines[i]);
    if (payload) return { anchor: payload, tailCorrupt, empty: false, unreadable: false };
    if (i === lines.length - 1) tailCorrupt = true;
    /* a second unverifiable line deeper in the file = the file itself is
     * suspect; keep walking — the verdict layer also gets tailCorrupt */
  }
  return { anchor: null, tailCorrupt: true, empty: false, unreadable: false };
}

/* ------------------------------- the verdict -------------------------------- */

export type HeadAnchorStatus =
  | "ok" /* anchored, current, chain intact at the pinned point */
  | "unanchored" /* chain exists but was never anchored (pre-first-tick) */
  | "no-chain" /* no chained rows at all (fresh install) */
  | "stale" /* anchor too old to adjudicate / safety net not refreshing */
  | "truncated" /* the pinned head row vanished inside every retention window */
  | "tampered"; /* the pinned head row exists but its hash was rewritten */

export interface HeadAnchorVerdict {
  status: HeadAnchorStatus;
  /** the last verified anchor (null when none) */
  anchor: HeadAnchorPayload | null;
  /** the chain's current head (null when no chained rows) */
  head: ChainHeadInfo | null;
  /** does the anchored head row still exist? (false when anchor == null) */
  anchoredRowPresent: boolean;
  /** rows appended since the anchor's timestamp (informational) */
  rowsSinceAnchor: number;
  /** the anchor file's tail was corrupt (partial write / tamper) */
  tailCorrupt: boolean;
  /** the anchor file could not be read (missing parent dir = unreadable) */
  unreadable: boolean;
  anchorAgeMs: number | null;
}

/** Staleness horizon: the auto-anchor ticks hourly — 2× + slack. */
export const ANCHOR_STALE_MS = 2 * 60 * 60 * 1000 + 5 * 60 * 1000;

/** The legitimate-retention floor below the anchored head row: no row newer
 *  than the anchor can be retention-pruned while the anchor is younger
 *  than the security floor (90 days) — the demo default retention. */
const RETENTION_FLOOR_MS = 90 * 24 * 60 * 60 * 1000;

/**
 * Compare the live chain against the newest verified anchor.
 *
 * Verdict precedence: hard findings (tampered / truncated) beat staleness;
 * staleness beats ok; missing anchor beats everything for a live chain.
 */
export async function verifyHeadAnchor(): Promise<HeadAnchorVerdict> {
  const [read, head] = await Promise.all([readLatestHeadAnchor(), getChainHead()]);
  const base: HeadAnchorVerdict = {
    status: "unanchored",
    anchor: read.anchor,
    head,
    anchoredRowPresent: false,
    rowsSinceAnchor: 0,
    tailCorrupt: read.tailCorrupt,
    unreadable: read.unreadable,
    anchorAgeMs: null,
  };

  if (!head) {
    /* no chained rows: an anchor over a chain that is now entirely gone
     * is the definition of truncation; otherwise a fresh install */
    return { ...base, status: read.anchor ? "truncated" : "no-chain" };
  }
  if (!read.anchor) return { ...base, status: "unanchored" };

  const anchor = read.anchor;
  const anchorAgeMs = Date.now() - new Date(anchor.anchoredAt).getTime();
  const verdict: HeadAnchorVerdict = { ...base, anchorAgeMs };

  const [anchoredRow, since] = await Promise.all([
    db.auditLog.findUnique({
      where: { id: anchor.headRowId },
      select: { chainHash: true },
    }),
    db.auditLog.count({ where: { createdAt: { gte: new Date(anchor.anchoredAt) } } }),
  ]);
  verdict.anchoredRowPresent = anchoredRow !== null;
  verdict.rowsSinceAnchor = since;

  if (anchoredRow) {
    /* the pinned row exists — its stored hash must match the seal */
    if (anchoredRow.chainHash !== anchor.headHash) {
      return { ...verdict, status: "tampered" };
    }
  } else {
    /* the pinned row is GONE: legitimate only via retention pruning, and
     * a row that was the NEWEST at anchor time is younger than the anchor
     * itself — while the anchor is inside the floor that is impossible */
    if (anchorAgeMs < RETENTION_FLOOR_MS) {
      return { ...verdict, status: "truncated" };
    }
    return { ...verdict, status: "stale" };
  }

  /* freshness: the hourly safety net should have re-anchored by now */
  if (anchorAgeMs > ANCHOR_STALE_MS) {
    return { ...verdict, status: "stale" };
  }
  return { ...verdict, status: "ok" };
}

/* --------------------------- journal export -------------------------------- */

export interface AnchorJournalExport {
  /** the RAW file bytes as text (every line, sealed or not — the operator
   *  gets the journal exactly as it sits on disk, including a partial tail:
   *  forensic value beats prettiness for an integrity artifact) */
  text: string;
  /** non-empty line count (size sanity for the route) */
  lines: number;
}

/**
 * ROUND 119 — read the anchor journal for an OFF-HOST EXPORT (the console's
 * download button): the raw text + the line count. Returns null when the
 * file does not exist (never anchored — the route answers 404).
 *
 * The export is the operational half of the WORM story: the file lives on
 * the same host as the database, so an attacker with host access could
 * rewrite both — an operator who copies each export to separate/off-site
 * storage closes that gap without any platform-side WORM dependency.
 */
export async function readAnchorJournalForExport(): Promise<AnchorJournalExport | null> {
  let text: string;
  try {
    text = await readFile(anchorFilePath(), "utf8");
  } catch (error) {
    const code = (error as NodeJS.ErrnoException)?.code;
    if (code === "ENOENT") return null;
    throw error; /* unreadable-but-present: surfaced as a 500 by the route */
  }
  const lines = text.split("\n").filter((l) => l.trim().length > 0).length;
  return { text, lines };
}

/* --------------------------- hourly safety net ------------------------------ */

const TICK_MS = 60 * 60 * 1000;
/** lease TTL < tick interval: a crashed holder self-heals before the next round */
const LEASE_TTL_MS = 50 * 60 * 1000;

const FLAG = "__ashrilogicAuditAnchor" as const;

interface AnchorState {
  timer: ReturnType<typeof setInterval> | null;
}

function state(): AnchorState {
  const g = globalThis as Record<string, unknown>;
  const existing = g[FLAG] as AnchorState | undefined;
  if (existing) return existing;
  const fresh: AnchorState = { timer: null };
  g[FLAG] = fresh;
  return fresh;
}

async function tick(): Promise<void> {
  await withJobLease(
    "audit-anchor",
    LEASE_TTL_MS,
    async () => {
    /* verdict FIRST: a bad verdict writes the sealed system alert (the
     * alert row itself then gets covered by the fresh anchor below) */
    const before = await verifyHeadAnchor();
    if (before.status === "truncated" || before.status === "tampered") {
      await logAudit({
        actorType: "system",
        actorName: "audit-anchor",
        action: "system.auditAnchor",
        targetLabel: before.status,
        meta: {
          anchoredAt: before.anchor?.anchoredAt ?? "-",
          anchoredRows: String(before.anchor?.totalRows ?? 0),
          currentRows: String(before.head?.totalRows ?? 0),
          anchoredRowPresent: before.anchoredRowPresent ? "true" : "false",
        },
      });
    }
    /* then re-anchor — the hourly pin. Quiet chains re-anchor the same
     * head: that REFRESHES anchoredAt (the staleness horizon), which is
     * exactly what keeps the mechanism adjudicable. */
    await appendHeadAnchor("auto");
    },
    { failure: "skip" } /* ROUND 120 — correctness-sensitive seal: fail closed on lease-store outage */
  );
}

/** Register the standing auto-anchor (idempotent across dev reloads). */
export function startAuditAnchorSafetyNet(): void {
  const s = state();
  if (s.timer != null) return;
  /* first tick soon after boot — the anchor freshness clock starts with
   * the process; then the steady hourly cadence */
  setTimeout(() => void tick().catch(() => {}), 30_000).unref?.();
  s.timer = setInterval(() => void tick().catch(() => {}), TICK_MS);
  s.timer.unref?.();
}
