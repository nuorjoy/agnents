/**
 * Ashrilogic — secret bootstrap guard (shared by every env-bound key).
 *
 * All long-lived key material (session HMAC secret, field-encryption root
 * key, audit-chain key, order-integrity key) resolves through this single
 * loader so the demo-fallback policy is enforced consistently:
 *
 *   1. A provisioned env secret of sufficient length always wins.
 *   2. NODE_ENV=production FAILS FAST when the secret is missing or weak —
 *      never silently fall back to a source-known constant.
 *   3. Development and test environments may use the documented demo
 *      constants (the sandbox and the security regression suite rely on
 *      them; test-setup.ts pins NODE_ENV=development before importing).
 *   4. Any OTHER environment shape (NODE_ENV unset — e.g. a standalone
 *      server started without NODE_ENV — or a staging label) refuses to
 *      run on demo secrets unless the operator EXPLICITLY opts in with
 *      ALLOW_DEMO_SECRETS=1. This closes the silent-compromise window
 *      where a production-shaped deployment inherits public constants
 *      and every session token becomes forgeable.
 *
 * The guard also emits a loud one-time banner whenever demo material is
 * live, because silent fallbacks are how weak deployments stay weak.
 */

const BANNER_FLAG = "__ashrilogicDemoSecretsBanner";

function env(): string | undefined {
  return process.env.NODE_ENV;
}

function explicitOptIn(): boolean {
  return process.env.ALLOW_DEMO_SECRETS === "1";
}

function banner(label: string): void {
  const g = globalThis as Record<string, unknown>;
  if (g[BANNER_FLAG]) return;
  g[BANNER_FLAG] = true;
  const scope = globalThis.console ?? console;
  scope.warn?.(
    `⚠ ${label}: running on DEMO key material — tokens/encrypted fields are forgeable by anyone with the source. ` +
      `Provision real secrets (see .env.example) before any non-local exposure.`
  );
}

export interface SecretSpec {
  envVar: "ADMIN_SESSION_SECRET" | "ASHRILOGIC_DATA_KEY";
  minLen: number;
  demoValue: string;
  label: string;
}

/**
 * Resolve a long-lived secret. Order: provisioned env value → demo constant
 * (dev/test/explicit opt-in) → hard failure with actionable guidance.
 */
export function loadSecret(spec: SecretSpec): string {
  const provisioned = process.env[spec.envVar];
  if (provisioned && provisioned.length >= spec.minLen) return provisioned;

  const mode = env();
  if (mode === "production") {
    throw new Error(
      `${spec.envVar} is required in production — set a cryptographically strong ${spec.label} (>= ${spec.minLen} chars)`
    );
  }
  if (mode === "development" || mode === "test") {
    banner(spec.envVar);
    return spec.demoValue;
  }
  if (explicitOptIn()) {
    banner(spec.envVar);
    return spec.demoValue;
  }
  throw new Error(
    `${spec.envVar} is not provisioned and NODE_ENV is "${mode ?? "unset"}". ` +
      `Refusing to start on demo key material outside development/test. ` +
      `Either provision real secrets (see .env.example) or, for a local demo only, ` +
      `set NODE_ENV=development (and ALLOW_DEMO_SECRETS=1 for custom environments).`
  );
}
