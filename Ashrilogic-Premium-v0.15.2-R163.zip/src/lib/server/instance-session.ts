import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { checkPassword, hashPassword, needsPasswordUpgrade } from "@/lib/server/admin-session";
import { getSessionUser } from "@/lib/server/admin-session";
import { issueToken, verifyToken } from "@/lib/server/tokens";
import { originViolation } from "@/lib/server/origin-guard";
import { INSTANCE_COOKIE_NAME } from "@/lib/server/cookie-names";
import { readAdminEmail } from "@/lib/server/instance-mapper";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { computeBan } from "@/lib/server/entitlement";
import { maintenanceBlock } from "@/lib/server/maintenance";
import { getCachedPlatformSettings } from "@/lib/server/platform-settings-cache";
import { PERMISSION_IDS, type PermissionId } from "@/lib/permissions";
import {
  checkSessionRecord,
  newSessionId,
  recordSession,
  touchSession,
} from "@/lib/server/sessions";

/**
 * Ashrilogic — subscriber workspace sessions.
 *
 * Every provisioned system instance is a workspace: its dashboard, team,
 * tickets and settings are gated behind an HTTP-only cookie session issued
 * after an email + password check against the instance admin account
 * (adminJson + passwordHash).
 *
 *  - The cookie is single-slot: signing into workspace B replaces a session
 *    for workspace A (one active workspace per browser, like real SaaS).
 *  - `requireInstanceAccess(id)` accepts EITHER the instance session OR an
 *    authenticated admin (super/admin only — round 35 permissions review),
 *    so the admin panel keeps managing instances.
 *  - ROUND 36 — tokens carry the instance's SESSION EPOCH; a workspace
 *    password change bumps the row and instantly revokes every outstanding
 *    session. Mutating handlers pass their Request for the same-origin
 *    (CSRF) check.
 *  - Legacy/seeded instances with a NULL passwordHash bootstrap it from the
 *    documented demo password on first login (non-production only).
 *  - Provisioning (POST /api/instances) signs the new owner in immediately.
 */

export const INSTANCE_COOKIE = INSTANCE_COOKIE_NAME;
export const INSTANCE_TTL_MS = 12 * 60 * 60 * 1000; // 12 hours (fallback)

/**
 * ROUND 89 — the platform «مدة الجلسة» setting (console Settings → الأمان
 * والجلسات, minutes 5..1440) now drives the WORKSPACE OWNER session TTL
 * exactly like it already drove admin sessions: issued at login time from
 * the live settings row, with the 12-hour fallback when the row is
 * unreadable. One settings row, one session law, every privileged scope.
 * ROUND 145 (perf) — reads the shared 10s TTL platform-settings cache
 * (login-path reader; identical error semantics to the direct read).
 */
export async function instanceSessionTtlMs(): Promise<number> {
  try {
    const row = await getCachedPlatformSettings();
    if (row && Number.isFinite(row.sessionTimeout) && row.sessionTimeout >= 5) {
      return Math.min(row.sessionTimeout, 1440) * 60 * 1000;
    }
  } catch {
    /* settings unreadable — default TTL */
  }
  return INSTANCE_TTL_MS;
}

export interface InstancePrincipal {
  /** how this request is authorized */
  kind: "session" | "admin";
  instanceId: string;
  /** actor for the audit trail (admin name, or the workspace admin email) */
  actorName: string;
  actorId?: string;
  /** ROUND 78 — the platform admin's staff role (admin path only) —
   *  consumed by assertInstancePermission for the tier check. */
  adminRole?: "super" | "admin";
  /** jti of the workspace session (absent for the admin-panel path) */
  sessionJti?: string;
}

/* ------------------------------- cookies ------------------------------- */

export interface InstanceSessionMeta {
  ip?: string | null;
  userAgent?: string | null;
}

/**
 * Issue the workspace session cookie AND its registry row (ROUND 45 —
 * active sessions per workspace).
 */
export async function setInstanceSession(
  instanceId: string,
  ver = 0,
  meta?: InstanceSessionMeta
): Promise<void> {
  const jti = newSessionId();
  const ttl = await instanceSessionTtlMs();
  const { token, expiresAt } = issueToken("instance", instanceId, ttl, ver, jti);
  const store = await cookies();
  store.set(INSTANCE_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: expiresAt,
  });
  await recordSession({
    scope: "instance",
    subjectId: instanceId,
    jti,
    ip: meta?.ip ?? null,
    userAgent: meta?.userAgent ?? null,
    expiresAt,
  });
}

/** jti of the CURRENT workspace session cookie. */
export async function getInstanceSessionJti(): Promise<string | undefined> {
  const store = await cookies();
  return verifyToken(store.get(INSTANCE_COOKIE)?.value, "instance")?.jti;
}

/* --------------------- ROUND 45 — MFA login ticket ----------------------- */

const INSTANCE_MFA_TICKET_TTL_MS = 5 * 60 * 1000;

/**
 * Short-lived ticket between "workspace password verified" and "second
 * factor verified". Scope "instance-mfa" is never a session; it expires in
 * 5 minutes and carries the workspace epoch.
 */
export function issueInstanceMfaTicket(instanceId: string, ver: number, emailIndex: string): string {
  /* sub carries instanceId|emailIndex so the finish step can re-resolve the
   * exact workspace (shared admin email may own several) without trusting
   * the client. */
  const { token } = issueToken(
    "instance-mfa",
    `${instanceId}|${emailIndex}`,
    INSTANCE_MFA_TICKET_TTL_MS,
    ver
  );
  return token;
}

export function verifyInstanceMfaTicket(
  token: string | undefined
): { instanceId: string; emailIndex: string; ver: number } | null {
  const payload = verifyToken(token, "instance-mfa");
  if (!payload) return null;
  const [instanceId, emailIndex] = payload.sub.split("|");
  if (!instanceId || !emailIndex) return null;
  return { instanceId, emailIndex, ver: payload.ver ?? 0 };
}

export async function clearInstanceSession(): Promise<void> {
  const store = await cookies();
  store.set(INSTANCE_COOKIE, "", {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 0,
  });
}

/** Resolve the workspace id the current cookie session is bound to (if any). */
export async function getInstanceSessionId(): Promise<string | null> {
  const store = await cookies();
  const payload = verifyToken(store.get(INSTANCE_COOKIE)?.value, "instance");
  return payload?.sub ?? null;
}

/**
 * Resolve the session token's epoch (the sessionVersion it was issued at).
 * Null when no instance session exists — lets PII-bearing read routes reject
 * password-rotated tokens the same way requireInstanceAccess does.
 */
export async function getInstanceSessionEpoch(): Promise<number | null> {
  const store = await cookies();
  const payload = verifyToken(store.get(INSTANCE_COOKIE)?.value, "instance");
  return payload ? (payload.ver ?? 0) : null;
}

/** Resolve the session payload (id + epoch + jti) when it matches the given instance. */
async function getInstanceSession(
  instanceId: string
): Promise<{ sub: string; ver: number; jti?: string } | null> {
  const store = await cookies();
  const payload = verifyToken(store.get(INSTANCE_COOKIE)?.value, "instance");
  if (!payload || payload.sub !== instanceId) return null;
  return { sub: payload.sub, ver: payload.ver ?? 0, jti: payload.jti };
}

/* --------------------- full session resolution -------------------------- */

export type InstanceSessionState =
  | { status: "none" }
  /** token present but revoked (jti signed out) or stale (epoch rotated) */
  | { status: "invalid" }
  | { status: "valid"; instanceId: string };

/**
 * Resolve the workspace session cookie through BOTH revocation layers —
 * the SessionRecord registry ("sign out this device") AND the instance
 * epoch (password rotation) — in one place. Read paths that previously
 * checked the epoch alone let a jti-revoked cookie keep serving the
 * owner's workspace DTOs until the raw cookie TTL; this helper closes
 * that gap for every caller. "none" (no cookie) lets callers fall back
 * to their anonymous projection; "invalid" maps to the shared 401
 * INSTANCE_STALE shape.
 */
export async function resolveInstanceSession(): Promise<InstanceSessionState> {
  const store = await cookies();
  const payload = verifyToken(store.get(INSTANCE_COOKIE)?.value, "instance");
  if (!payload) return { status: "none" };
  const record = await checkSessionRecord("instance", payload.sub, payload.jti);
  if (!record.valid) return { status: "invalid" };
  const row = await db.instance.findUnique({
    where: { id: payload.sub },
    select: { sessionVersion: true },
  });
  if (!row || (row.sessionVersion ?? 0) !== (payload.ver ?? 0)) return { status: "invalid" };
  if (record.touch && payload.jti) void touchSession(payload.jti);
  return { status: "valid", instanceId: payload.sub };
}

/* ------------------------------- guards -------------------------------- */

/**
 * Route-handler guard for /api/instances/[id]/* surfaces. The request is
 * authorized when the cookie session matches the instance, or when a valid
 * admin session of a MANAGING role exists (admin-panel management flows).
 * Usage:
 *
 *   const guard = await requireInstanceAccess(id);
 *   if (guard instanceof NextResponse) return guard;
 *   // guard.principal describes the actor (audit logging)
 *
 * Round 35 (permissions review): the admin path previously accepted ANY
 * authenticated admin — including read-only viewer/moderator roles — which
 * let those roles mutate subscriber workspaces through this surface even
 * though every UI already gated those actions to super/admin. The admin path
 * is now restricted to super/admin, mirroring the /api/admin/* posture
 * (moderators keep their support-triage rights on /api/admin/tickets only).
 *
 * ROUND 78 — STRICT PERMISSIONS: callers may declare the PermissionId an
 * operation requires (see src/lib/permissions.ts — the single source of
 * truth). The workspace-owner session carries the full owner set; platform
 * staff are tiered (super = full mandate, admin = everything EXCEPT tenant
 * governance: role management, billing, workspace settings incl. backups).
 * Denial is 403 PERMISSION_DENIED + an instance.permissionDenied audit row.
 */

/** options for requireInstanceAccess */
export interface InstanceAccessOptions {
  /** ROUND 78 — the permission this operation requires (strict RBAC). */
  permission?: PermissionId;
}

/** platform-`admin` tier on TENANT surfaces: full catalog minus tenant
 *  governance (owner-only under the strict matrix). super bypasses. */
const ADMIN_TIER: ReadonlySet<PermissionId> = new Set(
  PERMISSION_IDS.filter(
    (p) => p !== "team.manage" && p !== "billing.manage" && p !== "settings.manage"
  )
);

export async function requireInstanceAccess(
  instanceId: string,
  req?: Request,
  opts?: InstanceAccessOptions
): Promise<{ principal: InstancePrincipal } | NextResponse> {
  if (req) {
    const violation = originViolation(req);
    if (violation) return violation;
  }
  /* ROUND 96 — maintenance window: while a restore of THIS tenant is in
   * flight (durable lease, maintenance.ts), mutating surfaces fail fast
   * with 503 instead of queueing on the SQLite write lock for the whole
   * restore transaction (and being wiped by its teardown phase). GETs
   * keep serving the WAL-consistent pre-restore snapshot. The restore
   * route itself is unaffected: its guard call runs BEFORE the lease is
   * acquired. */
  if (req) {
    const maintenance = await maintenanceBlock(instanceId, req);
    if (maintenance) return maintenance;
  }
  const session = await getInstanceSession(instanceId);
  if (session) {
    /* ROUND 45 — per-session revocation ("sign out other devices") */
    const record = await checkSessionRecord("instance", instanceId, session.jti);
    if (!record.valid) {
      return NextResponse.json(
        { error: "Session expired — sign in again", code: "INSTANCE_STALE" },
        { status: 401 }
      );
    }
    const row = await db.instance.findUnique({
      where: { id: instanceId },
      select: {
        adminJson: true,
        sessionVersion: true,
        bannedPermanently: true,
        bannedUntil: true,
        bannedReason: true,
        bannedAt: true,
        /* ROUND 87 — trash + owner-disable gates (belt-and-braces: a
         * soft-delete or self-disable already revoked every session and
         * bumped the epoch; these checks close the same-request window). */
        deletedAt: true,
        disabledAt: true,
        disabledReason: true,
      },
    });
    /* ROUND 87 — a trashed workspace no longer exists on any surface. */
    if (row?.deletedAt) {
      return NextResponse.json(
        { error: "Workspace not found", code: "INSTANCE_NOT_FOUND" },
        { status: 404 }
      );
    }
    /* ROUND 87 — owner self-disable: every session-authenticated surface
     * refuses (business AND billing AND MFA — the owner re-activates with
     * password proof at the login step). */
    if (row?.disabledAt) {
      return NextResponse.json(
        {
          error: "This workspace is disabled by its owner — reactivate it at sign-in to resume",
          code: "WORKSPACE_DISABLED",
        },
        { status: 403 }
      );
    }
    // stale epoch (password changed since issue) → treat as signed out
    if ((row?.sessionVersion ?? 0) !== session.ver) {
      return NextResponse.json(
        { error: "Session expired — sign in again", code: "INSTANCE_STALE" },
        { status: 401 }
      );
    }
    /* ROUND 81 — BAN: a banned workspace refuses EVERY session-authenticated
     * surface (business AND billing AND MFA — stricter than a lock, which
     * keeps subscription surfaces alive). Applying a ban also bumps the
     * session epoch, so outstanding tokens die instantly; this check is the
     * belt-and-braces layer for tokens issued in the same request window.
     * The platform-admin path below deliberately BYPASSES the ban — the
     * console must keep managing (inspect, edit, lift) the banned tenant. */
    const ban = computeBan(row ?? {});
    if (ban.active) {
      await logAudit({
        actorType: "instance",
        actorId: instanceId,
        actorName: "workspace",
        action: "instance.loginFailed",
        targetLabel: "banned-access-attempt",
        meta: { ban: ban.kind ?? "active" },
      });
      return NextResponse.json(
        {
          error: "This workspace is suspended by the platform — access is refused until the suspension is lifted",
          code: "BANNED",
          ban,
        },
        { status: 403 }
      );
    }
    if (record.touch && session.jti) void touchSession(session.jti);
    /* sealed adminJson — decrypt the login email for the audit actor;
       masked (never raw PII) and ciphertext-proof */
    let actorName = "workspace";
    const email = readAdminEmail(row?.adminJson);
    if (email) {
      actorName = maskEmail(email);
    } else {
      try {
        const admin = JSON.parse(row?.adminJson ?? "{}") as { name?: string };
        actorName = admin.name ?? actorName;
      } catch {
        // corrupt adminJson — keep the generic actor
      }
    }
    return { principal: { kind: "session", instanceId, actorName, sessionJti: session.jti } };
  }

  const admin = await getSessionUser();
  if (admin) {
    if (admin.role !== "super" && admin.role !== "admin") {
      return NextResponse.json(
        {
          error: "This action requires one of: super, admin",
          code: "INSTANCE_FORBIDDEN_ROLE",
        },
        { status: 403 }
      );
    }
    /* ROUND 82 (batch-5 audit fix) — the tenant must actually EXIST on the
     * admin path: a ghost id previously slipped through every admin-path
     * surface as an empty 200 (module-records returned `{records:[]}` for
     * non-existent instance ids). The session path already resolves the
     * row above; only the admin path skipped it. */
    const exists = await db.instance.findUnique({
      where: { id: instanceId },
      select: { id: true, deletedAt: true },
    });
    /* ROUND 87 — a trashed workspace is GONE for admin-path surfaces too:
     * the platform governs it exclusively through the trash console
     * (restore / purge). (An owner-disabled workspace stays manageable —
     * the platform did not pause it.) */
    if (!exists || exists.deletedAt) {
      return NextResponse.json(
        { error: "Workspace not found", code: "INSTANCE_NOT_FOUND" },
        { status: 404 }
      );
    }
    /* ROUND 78 — STRICT permission gate for platform staff on TENANT
     * surfaces: super keeps the full mandate; admin keeps everything
     * EXCEPT tenant governance (role management, billing, workspace
     * settings incl. backups). Any other admin role is deny-by-default
     * (already refused above). Enforced BEFORE the route's own logic. */
    if (opts?.permission) {
      const granted = admin.role === "super" || ADMIN_TIER.has(opts.permission);
      if (!granted) {
        await logAudit({
          actorType: "admin",
          actorId: admin.id,
          actorName: admin.name,
          action: "instance.permissionDenied",
          targetLabel: opts.permission,
        });
        return NextResponse.json(
          {
            error: `This action requires the '${opts.permission}' permission (platform admins hold it only as super)`,
            code: "PERMISSION_DENIED",
          },
          { status: 403 }
        );
      }
    }
    return { principal: { kind: "admin", instanceId, actorName: admin.name, actorId: admin.id, adminRole: admin.role } };
  }

  return NextResponse.json(
    { error: "Workspace sign-in required", code: "INSTANCE_AUTH" },
    { status: 401 }
  );
}

/**
 * ROUND 78 — post-guard permission assertion for the rare case where the
 * required permission only becomes known AFTER the request body is parsed
 * (module-records POST/PATCH: the moduleId rides the payload, and the
 * inventory surface demands its own dedicated permission). Returns the
 * 403 PERMISSION_DENIED response (audit-logged) when the principal's tier
 * lacks the permission, else null. The workspace-owner session passes
 * everything (owner = full set); platform staff use the ADMIN_TIER split.
 */
export async function assertInstancePermission(
  principal: InstancePrincipal,
  permission: PermissionId
): Promise<NextResponse | null> {
  /* the workspace owner carries the full owner set — nothing to assert */
  if (principal.kind === "session") return null;
  const granted = principal.adminRole === "super" || ADMIN_TIER.has(permission);
  if (granted) return null;
  await logAudit({
    actorType: "admin",
    actorId: principal.actorId,
    actorName: principal.actorName,
    action: "instance.permissionDenied",
    targetLabel: permission,
  });
  return NextResponse.json(
    {
      error: `This action requires the '${permission}' permission (platform admins hold it only as super)`,
      code: "PERMISSION_DENIED",
    },
    { status: 403 }
  );
}

/* ------------------------------ passwords ------------------------------ */

export interface PasswordCheck {
  ok: boolean;
  /** true when a NULL hash was bootstrapped and must be persisted by the caller */
  bootstrapped: boolean;
  /** true when a legacy SHA-256 digest verified and was re-hashed as Argon2id */
  upgraded: boolean;
  /** the hash the caller should persist (bootstrap/upgrade) or the stored one */
  hash: string | null;
}

/**
 * Verify a workspace password. A NULL stored hash accepts the documented
 * demo password once and returns its digest so the caller persists it
 * (legacy rows migrate themselves on first login). Round 35: legacy SHA-256
 * digests that verify are transparently upgraded to Argon2id — `upgraded`
 * is set and `hash` carries the fresh Argon2id record to persist.
 */
export function checkInstancePassword(
  password: string,
  storedHash: string | null
): PasswordCheck {
  if (storedHash) {
    const ok = checkPassword(password, storedHash);
    if (ok && needsPasswordUpgrade(storedHash)) {
      const rehash = hashPassword(password);
      return { ok: true, bootstrapped: false, upgraded: true, hash: rehash };
    }
    return { ok, bootstrapped: false, upgraded: false, hash: storedHash };
  }
  const ok = checkPassword(password, null);
  return { ok, bootstrapped: ok, upgraded: false, hash: ok ? hashPassword(password) : null };
}
