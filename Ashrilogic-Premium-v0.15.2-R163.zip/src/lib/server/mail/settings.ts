import { createHash } from "node:crypto";
import { db } from "@/lib/db";
import { encryptField, decryptField } from "@/lib/server/crypto-vault";
import type { MailSettingsDTO } from "@/lib/types";

/**
 * AshriLogic — EMAIL SYSTEM — mail/SMTP configuration state.
 *
 * The whole configuration persists as ONE JSON string inside the singleton
 * PlatformSetting row (`smtpJson`, id "global" — the exact pattern of
 * aiJson / paymentsJson; SQLite has no nested columns):
 *
 *   { enabled, provider, host, port, secure, username, passwordSealed,
 *     fromName, fromEmail, replyTo, timeoutMs, sendWelcome }
 *
 * Security posture (mirrors the AI panel):
 *  - The SMTP password is sealed with AES-256-GCM (`encryptField`) and
 *    NEVER leaves the server — the DTO exposes `hasPassword` only.
 *  - Decryption happens in-memory per send, never persisted, never logged.
 *
 * TRANSPORT RESOLUTION (strict, non-breaking precedence):
 *   1. smtpJson enabled + complete (host + fromEmail) → SMTP via the
 *      DB config (admin-managed dynamic settings).
 *   2. else SMTP_URL env set        → SMTP via the env URL (the legacy
 *      deployment-level path — existing installs keep working untouched).
 *   3. else                         → dev spool (verifiable .eml outbox).
 */

/** PlatformSetting singleton id (admin-mapper convention). */
const SETTINGS_ID = "global";

/** Supported transport encryption modes for the DB SMTP config. */
export type MailSecureMode = "none" | "starttls" | "tls";

/** The persisted JSON shape (passwordSealed is the ONLY secret-bearing field). */
export interface MailSettingsRow {
  enabled: boolean;
  /** transport adapter — "smtp" today; future: "resend" | "ses" */
  provider: string;
  host: string;
  port: number;
  secure: MailSecureMode;
  username: string;
  passwordSealed: string | null;
  fromName: string;
  fromEmail: string;
  replyTo: string;
  /** per-attempt socket/connection timeout (ms) */
  timeoutMs: number;
  /** send a welcome letter on customer signup (in ADDITION to verification) */
  sendWelcome: boolean;
}

/** Platform defaults when smtpJson is empty / unreadable (env path applies). */
export const MAIL_DEFAULTS: MailSettingsRow = {
  enabled: false,
  provider: "smtp",
  host: "",
  port: 587,
  secure: "starttls",
  username: "",
  passwordSealed: null,
  fromName: "Ashrilogic",
  fromEmail: "",
  replyTo: "",
  timeoutMs: 15_000,
  sendWelcome: false,
};

const SECURE_MODES: readonly MailSecureMode[] = ["none", "starttls", "tls"];

function parseSecure(value: unknown, fallback: MailSecureMode): MailSecureMode {
  return typeof value === "string" && (SECURE_MODES as readonly string[]).includes(value)
    ? (value as MailSecureMode)
    : fallback;
}

function boundedPort(value: unknown): number {
  if (typeof value === "number" && Number.isFinite(value)) {
    const port = Math.round(value);
    if (port >= 1 && port <= 65_535) return port;
  }
  return MAIL_DEFAULTS.port;
}

function boundedTimeout(value: unknown): number {
  if (typeof value === "number" && Number.isFinite(value)) {
    const ms = Math.round(value);
    if (ms >= 3_000 && ms <= 60_000) return ms;
  }
  return MAIL_DEFAULTS.timeoutMs;
}

/** Defensive parse — a corrupt/legacy cell degrades to platform defaults. */
function parseRow(smtpJson: string | null | undefined): MailSettingsRow {
  if (!smtpJson) return { ...MAIL_DEFAULTS };
  try {
    const parsed = JSON.parse(smtpJson) as Partial<MailSettingsRow>;
    return {
      enabled: typeof parsed.enabled === "boolean" ? parsed.enabled : MAIL_DEFAULTS.enabled,
      provider:
        typeof parsed.provider === "string" && parsed.provider.trim().length > 0
          ? parsed.provider.trim().slice(0, 20)
          : MAIL_DEFAULTS.provider,
      host:
        typeof parsed.host === "string" ? parsed.host.trim().slice(0, 253) : "",
      port: boundedPort(parsed.port),
      secure: parseSecure(parsed.secure, MAIL_DEFAULTS.secure),
      username: typeof parsed.username === "string" ? parsed.username.slice(0, 200) : "",
      passwordSealed:
        typeof parsed.passwordSealed === "string" && parsed.passwordSealed.length > 0
          ? parsed.passwordSealed
          : null,
      fromName:
        typeof parsed.fromName === "string" ? parsed.fromName.trim().slice(0, 80) : "",
      fromEmail:
        typeof parsed.fromEmail === "string" ? parsed.fromEmail.trim().slice(0, 254) : "",
      replyTo:
        typeof parsed.replyTo === "string" ? parsed.replyTo.trim().slice(0, 254) : "",
      timeoutMs: boundedTimeout(parsed.timeoutMs),
      sendWelcome:
        typeof parsed.sendWelcome === "boolean" ? parsed.sendWelcome : MAIL_DEFAULTS.sendWelcome,
    };
  } catch {
    return { ...MAIL_DEFAULTS };
  }
}

/** Read the stored row (defaults when the singleton/cell is missing). */
export async function loadMailRow(): Promise<MailSettingsRow> {
  try {
    const row = await db.platformSetting.findUnique({
      where: { id: SETTINGS_ID },
      select: { smtpJson: true },
    });
    return parseRow(row?.smtpJson);
  } catch {
    return { ...MAIL_DEFAULTS };
  }
}

/** Persist the row back into smtpJson (create singleton if missing). */
async function saveRow(row: MailSettingsRow): Promise<void> {
  await db.platformSetting.upsert({
    where: { id: SETTINGS_ID },
    update: { smtpJson: JSON.stringify(row) },
    create: { id: SETTINGS_ID, smtpJson: JSON.stringify(row) },
  });
}

/** Whether the DB config is complete enough to take precedence over env. */
export function dbConfigComplete(row: MailSettingsRow): boolean {
  return row.host.length > 0 && row.fromEmail.length > 0;
}

/* ------------------------------------------------------------------ */
/* the resolved runtime (what the service actually sends through)      */
/* ------------------------------------------------------------------ */

export type MailActiveMode = "smtp-db" | "smtp-env" | "spool";

/** Everything the provider layer needs, resolved once per send/bulk job. */
export interface ResolvedMailRuntime {
  mode: MailActiveMode;
  providerName: "smtp" | "spool";
  /** envelope sender "Display Name <mailbox@domain>" */
  from: string;
  fromEmail: string;
  replyTo: string | null;
  timeoutMs: number;
  /** SMTP connection facts — present only in smtp modes (password in-memory) */
  smtp: {
    host: string;
    port: number;
    /** implicit TLS (465-style) */
    secure: boolean;
    /** force STARTTLS upgrade (fail when unavailable) */
    requireTLS: boolean;
    username: string | null;
    /** decrypted in-memory ONLY — never persisted, never logged */
    password: string | null;
  } | null;
  /** cache key for the transport pool (rotates when ANY field changes) */
  configKey: string;
}

const ENV_DEFAULT_FROM = "Ashrilogic <no-reply@ashrilogic.com>";

function envSmtpUrl(): string | null {
  const raw = process.env.SMTP_URL?.trim();
  return raw && raw.length > 0 ? raw : null;
}

function envFrom(): string {
  const raw = process.env.MAIL_FROM?.trim();
  return raw && raw.length > 0 ? raw : ENV_DEFAULT_FROM;
}

/** sha256 config fingerprint (invalidates pooled transports on change). */
function configKeyOf(parts: Record<string, string | number | boolean | null>): string {
  return createHash("sha256").update(JSON.stringify(parts)).digest("hex").slice(0, 32);
}

/**
 * Resolve the ACTIVE transport for this send. Pure precedence:
 * DB (enabled + complete) → env SMTP_URL → spool. Never throws.
 */
export async function resolveMailRuntime(): Promise<ResolvedMailRuntime> {
  const row = await loadMailRow();
  const dbReady = row.enabled && dbConfigComplete(row);

  if (dbReady) {
    const password = row.passwordSealed ? decryptField(row.passwordSealed) : null;
    return {
      mode: "smtp-db",
      providerName: "smtp",
      from: `${row.fromName || "Ashrilogic"} <${row.fromEmail}>`,
      fromEmail: row.fromEmail,
      replyTo: row.replyTo.length > 0 ? row.replyTo : null,
      timeoutMs: row.timeoutMs,
      smtp: {
        host: row.host,
        port: row.port,
        secure: row.secure === "tls",
        requireTLS: row.secure === "starttls",
        username: row.username.length > 0 ? row.username : null,
        password: password && password.length > 0 ? password : null,
      },
      configKey: configKeyOf({
        p: "db",
        host: row.host,
        port: row.port,
        secure: row.secure,
        u: row.username,
        pw: row.passwordSealed ?? "",
        from: row.fromEmail,
      }),
    };
  }

  const url = envSmtpUrl();
  if (url) {
    return {
      mode: "smtp-env",
      providerName: "smtp",
      from: envFrom(),
      fromEmail: envFrom(),
      replyTo: null,
      timeoutMs: MAIL_DEFAULTS.timeoutMs,
      smtp: null, // the env adapter consumes the raw URL directly
      configKey: configKeyOf({ p: "env", url }),
    };
  }

  return {
    mode: "spool",
    providerName: "spool",
    from: envFrom(),
    fromEmail: envFrom(),
    replyTo: null,
    timeoutMs: MAIL_DEFAULTS.timeoutMs,
    smtp: null,
    configKey: "spool",
  };
}

/** Compat surface: the transport mode the console chip displays. */
export async function mailTransportMode(): Promise<"smtp" | "spool"> {
  const runtime = await resolveMailRuntime();
  return runtime.providerName;
}

/* ------------------------------------------------------------------ */
/* the client-safe DTO + the Super-Admin patch                          */
/* ------------------------------------------------------------------ */

/** Client-safe DTO — the sealed password is reduced to a boolean. */
export async function toMailSettingsDTO(row: MailSettingsRow): Promise<MailSettingsDTO> {
  const runtime = await resolveMailRuntime();
  return {
    enabled: row.enabled,
    provider: row.provider,
    host: row.host,
    port: row.port,
    secure: row.secure,
    username: row.username,
    fromName: row.fromName,
    fromEmail: row.fromEmail,
    replyTo: row.replyTo,
    timeoutMs: row.timeoutMs,
    sendWelcome: row.sendWelcome,
    hasPassword: row.passwordSealed !== null,
    activeMode: runtime.mode,
  };
}

/** Admin panel read (client-safe). */
export async function getMailSettingsDTO(): Promise<MailSettingsDTO> {
  return toMailSettingsDTO(await loadMailRow());
}

/** The patch the Super-Admin route validated with Zod. */
export interface MailSettingsPatch {
  enabled?: boolean;
  host?: string;
  port?: number;
  secure?: MailSecureMode;
  username?: string;
  /** write-only: seals a NEW SMTP password */
  password?: string;
  /** drops the stored password (the client then sends a fresh one or none) */
  rotatePassword?: boolean;
  fromName?: string;
  fromEmail?: string;
  replyTo?: string;
  timeoutMs?: number;
  sendWelcome?: boolean;
}

/**
 * Super-Admin panel write. `password` seals a NEW SMTP password;
 * `rotatePassword` drops the stored one. Returns the client-safe DTO.
 */
export async function applyMailSettingsPatch(patch: MailSettingsPatch): Promise<MailSettingsDTO> {
  const row = await loadMailRow();
  const next: MailSettingsRow = { ...row };
  if (patch.enabled !== undefined) next.enabled = patch.enabled;
  if (patch.host !== undefined) next.host = patch.host.trim().slice(0, 253);
  if (patch.port !== undefined) next.port = boundedPort(patch.port);
  if (patch.secure !== undefined) next.secure = patch.secure;
  if (patch.username !== undefined) next.username = patch.username.slice(0, 200);
  if (patch.rotatePassword) next.passwordSealed = null;
  if (patch.password !== undefined && patch.password.length > 0) {
    /* seal FIRST — the plaintext password never touches storage or logs */
    next.passwordSealed = encryptField(patch.password) ?? null;
  }
  if (patch.fromName !== undefined) next.fromName = patch.fromName.trim().slice(0, 80);
  if (patch.fromEmail !== undefined) next.fromEmail = patch.fromEmail.trim().slice(0, 254);
  if (patch.replyTo !== undefined) next.replyTo = patch.replyTo.trim().slice(0, 254);
  if (patch.timeoutMs !== undefined) next.timeoutMs = boundedTimeout(patch.timeoutMs);
  if (patch.sendWelcome !== undefined) next.sendWelcome = patch.sendWelcome;
  await saveRow(next);
  return toMailSettingsDTO(next);
}
