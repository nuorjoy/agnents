import { db } from "@/lib/db";
import { sendMail } from "./service";
import { loadMailRow } from "./settings";
import { renderTestEmail } from "./templates/test";
import { renderWelcomeEmail } from "./templates/welcome";
import { renderSecurityAlertEmail } from "./templates/security-alert";
import { renderSubscriptionEmail } from "./templates/subscription";
import { renderOrderStatusHtml, renderOrderStatusText, orderStatusSubject, type OrderStatusMailInput } from "./templates/order-status";

/**
 * AshriLogic — EMAIL SYSTEM — the DOMAIN SENDER layer.
 *
 * The typed façade application code is meant to call: each business mail
 * flow gets ONE named function that renders its template, tags its
 * EmailLog type and hands the envelope to the Mail Service. Routes never
 * assemble envelopes by hand — they call these.
 *
 * All senders are BEST-EFFORT by contract (return boolean, never throw):
 * a mail failure must never fail the business operation that triggered it
 * (the platform's standing convention).
 */

/* ------------------------------------------------------------------ */
/* order status notices (owner transitions — the storefront lifecycle)  */
/* ------------------------------------------------------------------ */

/** The order notice input: the template fields + delivery context. */
export type OrderStatusNoticeInput = OrderStatusMailInput & {
  /** the decrypted customer mailbox (decryption stays at the call site) */
  customerEmail: string;
  /** tenant context for the EmailLog trail */
  instanceId?: string;
  /** the order row id — REQUIRED for the send's IDEMPOTENCY KEY
   *  (`orderStatus:{orderId}:{status}`): a retried/duplicated transition
   *  can never double-mail the customer (EmailLog.idempotencyKey is unique
   *  and the service short-circuits on an already-delivered key). */
  orderId: string;
};

export async function sendOrderStatusNotice(input: OrderStatusNoticeInput): Promise<boolean> {
  const { customerEmail, instanceId, orderId, ...template } = input;
  return sendMail(
    {
      to: customerEmail,
      subject: orderStatusSubject(template),
      text: renderOrderStatusText(template),
      html: renderOrderStatusHtml(template),
    },
    {
      type: "orderStatus",
      ...(instanceId ? { instanceId } : {}),
      idempotencyKey: `orderStatus:${orderId}:${template.status}`,
    }
  );
}

/* ------------------------------------------------------------------ */
/* the admin's test round-trip                                          */
/* ------------------------------------------------------------------ */

export interface TestEmailDiagnostics {
  mode: string;
  provider: string;
  sender: string;
  /** host:port (NO credentials) — empty in spool mode */
  endpoint: string;
}

export async function sendTestEmail(params: {
  to: string;
  orgName: string;
  diagnostics: TestEmailDiagnostics;
}): Promise<boolean> {
  const diagAr = [
    `مسار الإرسال: ${params.diagnostics.mode}`,
    `المزوّد: ${params.diagnostics.provider}`,
    `المرسِل: ${params.diagnostics.sender}`,
    params.diagnostics.endpoint ? `الخادم: ${params.diagnostics.endpoint}` : "",
    "",
    "تُرسل هذه الرسالة عبر نفس مسار جميع رسائل المنصة (Mail Service → Provider).",
  ]
    .filter((l) => l !== "" || true)
    .join("\n");
  const diagEn = [
    `Transport path: ${params.diagnostics.mode}`,
    `Provider: ${params.diagnostics.provider}`,
    `Sender: ${params.diagnostics.sender}`,
    params.diagnostics.endpoint ? `Endpoint: ${params.diagnostics.endpoint}` : "",
    "",
    "This message travels the same path as every platform email (Mail Service → Provider).",
  ]
    .filter((l) => l !== "" || true)
    .join("\n");

  const rendered = renderTestEmail({
    to: params.to,
    orgName: params.orgName,
    diagnosticsAr: diagAr,
    diagnosticsEn: diagEn,
  });
  return sendMail({ to: params.to, subject: rendered.subject, text: rendered.text, html: rendered.html }, { type: "test" });
}

/* ------------------------------------------------------------------ */
/* welcome letter (optional — mail settings sendWelcome toggle)         */
/* ------------------------------------------------------------------ */

export async function sendWelcomeEmail(input: {
  to: string;
  name: string;
  orgName: string;
  siteUrl: string;
}): Promise<boolean> {
  const rendered = renderWelcomeEmail(input);
  return sendMail(
    { to: input.to, subject: rendered.subject, text: rendered.text, html: rendered.html },
    { type: "welcome" }
  );
}

/** Whether the platform wants a welcome letter on signup (settings gate). */
export async function welcomeMailEnabled(): Promise<boolean> {
  const row = await loadMailRow();
  return row.sendWelcome;
}

/* ------------------------------------------------------------------ */
/* security alerts                                                      */
/* ------------------------------------------------------------------ */

export async function sendSecurityAlertEmail(input: {
  to: string;
  name: string;
  orgName: string;
  eventAr: string;
  eventEn: string;
  instanceId?: string;
}): Promise<boolean> {
  const rendered = renderSecurityAlertEmail(input);
  return sendMail(
    { to: input.to, subject: rendered.subject, text: rendered.text, html: rendered.html },
    { type: "securityAlert", ...(input.instanceId ? { instanceId: input.instanceId } : {}) }
  );
}

/* ------------------------------------------------------------------ */
/* subscription lifecycle letters                                       */
/* ------------------------------------------------------------------ */

export async function sendSubscriptionEmail(input: {
  to: string;
  name: string;
  orgName: string;
  event: "activated" | "renewed" | "expiring" | "expired";
  planName: string;
  amountFormatted?: string;
  validUntil?: string;
}): Promise<boolean> {
  const rendered = renderSubscriptionEmail(input);
  return sendMail(
    { to: input.to, subject: rendered.subject, text: rendered.text, html: rendered.html },
    { type: "subscription" }
  );
}

/* ------------------------------------------------------------------ */
/* org display name (sealed orgJson.name — the letterhead convention)    */
/* ------------------------------------------------------------------ */

/** workspace display name for mail letterheads (sealed orgJson.name,
 *  fallback "Ashrilogic") — one bounded read, never throws. */
export async function orgDisplayName(instanceId: string): Promise<string> {
  try {
    const instance = await db.instance.findUnique({
      where: { id: instanceId, deletedAt: null },
      select: { orgJson: true },
    });
    const org = JSON.parse(instance?.orgJson ?? "{}") as { name?: unknown };
    if (typeof org.name === "string" && org.name.trim()) return org.name.trim();
  } catch {
    /* fall through to the fallback */
  }
  return "Ashrilogic";
}
