/**
 * AshriLogic — EMAIL SYSTEM — the public API barrel.
 *
 *   ┌─────────────────────────────────────────────────────────────┐
 *   │  Application (routes, domain modules)                        │
 *   │      ↓ domain senders (notify.ts, verification.ts,           │
 *   │                       platform-notifications.ts)             │
 *   │  Mail Service (service.ts) — retry·backoff·logging·idem      │
 *   │      ↓ provider adapter (providers/smtp | providers/spool)   │
 *   │  SMTP / Email Provider                                       │
 *   └─────────────────────────────────────────────────────────────┘
 *
 * Adding a provider = one new file in providers/ implementing MailProvider
 * + one resolution branch in settings.ts. The service, the templates and
 * every caller stay untouched.
 *
 * The names `sendMail` / `sendBulkMail` / `mailTransportMode` are the exact
 * API of the former src/lib/server/mailer.ts — consumers migrated by
 * import path only, zero behavior change (the env SMTP_URL path and the
 * dev spool are preserved as the legacy/fallback transports).
 */

/* the service */
export {
  sendMail,
  sendBulkMail,
  purgeExpiredEmailLogs,
  type MailType,
  type OutgoingMail,
  type SendMailOptions,
  type MailDispatchResult,
} from "./service";

/* settings (transport resolution + admin panel state) */
export {
  loadMailRow,
  getMailSettingsDTO,
  applyMailSettingsPatch,
  resolveMailRuntime,
  mailTransportMode,
  MAIL_DEFAULTS,
  type MailSettingsRow,
  type MailSettingsPatch,
  type MailSecureMode,
  type MailActiveMode,
  type ResolvedMailRuntime,
} from "./settings";

/* health (connection + SPF/DKIM/DMARC + trail stats) */
export { getMailHealth, type DnsCheck, type DnsCheckStatus } from "./health";

/* domain senders (the typed façade application code should call) */
export {
  sendOrderStatusNotice,
  sendTestEmail,
  sendWelcomeEmail,
  welcomeMailEnabled,
  sendSecurityAlertEmail,
  sendSubscriptionEmail,
  orgDisplayName,
  type OrderStatusNoticeInput,
  type TestEmailDiagnostics,
} from "./notify";

/* templates (relocated VERBATIM — same renderers the platform shipped) */
export {
  renderCampaignText,
  renderCampaignHtml,
} from "./templates/campaign";
export {
  orderStatusSubject,
  renderOrderStatusText,
  renderOrderStatusHtml,
  type OrderStatusMailStatus,
  type OrderStatusMailInput,
} from "./templates/order-status";
export { renderVerificationEmail } from "./templates/verification";
export { renderPasswordResetEmail } from "./templates/password-reset";
