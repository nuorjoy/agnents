/**
 * Ashrilogic — per-instance KPI stats (ROUND 61 / H-8: real aggregates).
 *
 * Two tiers:
 *
 *  1. REAL — when the workspace has real order history (a storefront that
 *     actually took orders), `computeInstanceStatsFromDb` derives:
 *       revenue       → SiteOrder totals grouped by month (last 12 months,
 *                       honest zeros for empty months, minor units kept —
 *                       the display layer treats them like every other
 *                       money amount it renders);
 *       users         → team members + site customers (real people);
 *       activityToday → Activity rows in the last 24h.
 *     The result carries `demo: false`.
 *
 *  2. SHOWCASE — workspaces without real orders keep the deterministic
 *     demo metrics (stable per instance id — no Math.random, SSR/CSR and
 *     repeated fetches agree) and carry `demo: true`, which the dashboard
 *     surfaces as an honest "demo data" badge.
 *
 * Tasks breakdown / health remain platform estimations in both tiers (they
 * are pipeline/infrastructure metaphors with no backing table); the UI
 * labels them "estimated".
 */
import { db } from "@/lib/db";
import { seededRandom } from "@/lib/utils";
import { intlLocale } from "@/lib/locales";
import { toDisplayUnits } from "@/lib/server/money";
import type { InstanceStats, Lang } from "@/lib/types";

const TASKS_BREAKDOWN_COLORS = ["#10b981", "#6d5dfb", "#f59e0b", "#94a3b8"] as const;
const HEALTH_COLORS = ["#10b981", "#06b6d4", "#f59e0b", "#8b5cf6"] as const;

/** Real aggregates for a SET of instances — batched: 4 queries total,
 *  regardless of how many instances are asked about (export safety). */
export interface InstanceAggregates {
  /** instanceId → real users count (members + site customers) */
  users: Map<string, number>;
  /** instanceId → real 24h activity count */
  activityToday: Map<string, number>;
  /** instanceId → (year-month key → order revenue total, minor units) */
  revenueByMonth: Map<string, Map<string, number>>;
  /** instanceIds that have ≥1 order (the real-mode trigger) */
  hasOrders: Set<string>;
  /** instanceId → the store's currency (from its orders; ISO code) */
  currency: Map<string, string>;
}

/** Month bucket key "YYYY-MM" in LOCAL time (labels are local months). */
function monthKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

/**
 * Batched real aggregates for the given instance ids. Never throws — a
 * database hiccup degrades to "no aggregates" and callers fall back to the
 * deterministic showcase tier (fail-soft, like the rate limiter's posture).
 */
export async function loadInstanceAggregates(instanceIds: string[]): Promise<InstanceAggregates> {
  const empty: InstanceAggregates = {
    users: new Map(),
    activityToday: new Map(),
    revenueByMonth: new Map(),
    hasOrders: new Set(),
    currency: new Map(),
  };
  if (instanceIds.length === 0) return empty;
  try {
    const since24h = new Date(Date.now() - 24 * 60 * 60 * 1000);

    /* 12-month window start (first day of the month 11 months back) */
    const now = new Date();
    const windowStart = new Date(now.getFullYear(), now.getMonth() - 11, 1);

    const [memberRows, customerRows, activityRows, orderRows] = await Promise.all([
      /* ROUND 87 — LIVE rows only: trashed (soft-deleted) members,
       * customers and orders never feed the KPI aggregates. */
      db.teamMember.groupBy({
        by: ["instanceId"],
        where: { instanceId: { in: instanceIds }, deletedAt: null },
        _count: { _all: true },
      }),
      db.siteCustomer.groupBy({
        by: ["instanceId"],
        where: { instanceId: { in: instanceIds }, deletedAt: null },
        _count: { _all: true },
      }),
      db.activity.groupBy({
        by: ["instanceId"],
        where: { instanceId: { in: instanceIds }, createdAt: { gte: since24h } },
        _count: { _all: true },
      }),
      db.siteOrder.findMany({
        where: { instanceId: { in: instanceIds }, createdAt: { gte: windowStart }, deletedAt: null },
        select: { instanceId: true, createdAt: true, total: true, currency: true },
      }),
    ]);

    const users = new Map<string, number>();
    for (const r of memberRows) users.set(r.instanceId, (users.get(r.instanceId) ?? 0) + r._count._all);
    for (const r of customerRows) users.set(r.instanceId, (users.get(r.instanceId) ?? 0) + r._count._all);

    const activityToday = new Map<string, number>();
    for (const r of activityRows) activityToday.set(r.instanceId, r._count._all);

    const revenueByMonth = new Map<string, Map<string, number>>();
    const hasOrders = new Set<string>();
    const currency = new Map<string, string>();
    for (const o of orderRows) {
      hasOrders.add(o.instanceId);
      const key = monthKey(o.createdAt);
      const perInstance = revenueByMonth.get(o.instanceId) ?? new Map<string, number>();
      perInstance.set(key, (perInstance.get(key) ?? 0) + o.total);
      revenueByMonth.set(o.instanceId, perInstance);
      if (!currency.has(o.instanceId) && /^[A-Za-z]{3}$/.test(o.currency)) {
        currency.set(o.instanceId, o.currency.toUpperCase());
      }
    }

    return { users, activityToday, revenueByMonth, hasOrders, currency };
  } catch {
    return empty;
  }
}

/** The deterministic showcase tier — stable per instance id (no random). */
export function computeInstanceStats(instanceId: string, lang: Lang): InstanceStats {
  const rng = seededRandom(instanceId);
  const now = new Date();

  // Revenue: last 12 months ending now, increasing trend + seeded noise, 15000..60000.
  const monthFmt = new Intl.DateTimeFormat(intlLocale(lang), { month: "short" });
  const revenue: InstanceStats["revenue"] = [];
  for (let i = 11; i >= 0; i--) {
    const monthDate = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const progress = (11 - i) / 11; // 0 → 1 over the window
    const trend = 18000 + 39000 * progress;
    const noise = (rng() - 0.5) * 12000;
    const value = Math.round(Math.min(60000, Math.max(15000, trend + noise)));
    revenue.push({ label: monthFmt.format(monthDate), value });
  }

  const activityToday = 400 + Math.round(rng() * 1200); // 400..1600
  const users = 8 + Math.round(rng() * 56); // 8..64
  const uptime = Number((99.1 + rng() * 0.89).toFixed(2)); // 99.1..99.99

  // Labels are i18n keys — the client localizes ("done","progress","review","todo").
  const tasksBreakdown: InstanceStats["tasksBreakdown"] = (
    ["done", "progress", "review", "todo"] as const
  ).map((label, i) => ({
    label,
    value: 20 + Math.round(rng() * 40), // 20..60
    color: TASKS_BREAKDOWN_COLORS[i],
  }));

  const health: InstanceStats["health"] = (
    ["database", "api", "storage", "cache"] as const
  ).map((label, i) => ({
    label,
    value: 90 + Math.round(rng() * 9), // 90..99
    color: HEALTH_COLORS[i],
  }));

  /* showcase tier — flagged so the dashboard can label it honestly */
  return { revenue, activityToday, users, uptime, tasksBreakdown, health, demo: true };
}

/**
 * The DB-backed tier (ROUND 61 / H-8): real aggregates when the workspace
 * has real order history, showcase fallback otherwise. `agg` comes from
 * `loadInstanceAggregates` (one batched call per request, not per row).
 */
export function computeInstanceStatsFromDb(
  instanceId: string,
  lang: Lang,
  agg: InstanceAggregates
): InstanceStats {
  const showcase = computeInstanceStats(instanceId, lang);
  if (!agg.hasOrders.has(instanceId)) return showcase;

  /* REAL tier — rebuild the three real KPIs; uptime/tasks/health keep the
   * deterministic showcase shapes (platform estimations, labeled as such) */
  const now = new Date();
  const monthFmt = new Intl.DateTimeFormat(intlLocale(lang), { month: "short" });
  const perMonth = agg.revenueByMonth.get(instanceId) ?? new Map<string, number>();

  const revenue: InstanceStats["revenue"] = [];
  for (let i = 11; i >= 0; i--) {
    const monthDate = new Date(now.getFullYear(), now.getMonth() - i, 1);
    /* SiteOrder.total is integer MINOR units — the stats tier speaks display
     * units (the showcase numbers do too), so convert here, once, centrally */
    const value = toDisplayUnits(perMonth.get(monthKey(monthDate)) ?? 0);
    revenue.push({ label: monthFmt.format(monthDate), value });
  }

  return {
    ...showcase,
    revenue,
    users: agg.users.get(instanceId) ?? 0,
    activityToday: agg.activityToday.get(instanceId) ?? 0,
    demo: false,
    /* the real revenue's denomination (orders share one store currency) */
    currency: agg.currency.get(instanceId),
  };
}
