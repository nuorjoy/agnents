/**
 * Ashrilogic — typed AR/EN/HI dictionary (composed from domain modules).
 *
 * Round 60 split: the former 9,335-line src/lib/i18n.ts monolith is now
 * src/lib/i18n/domains/{landing,auth,wizard,dashboard,site,admin,store,common}.ts.
 * This composer spreads the per-domain fragments back into the exact same
 * AR/EN/HI dictionaries — the public API (I18nKey, I18N, t, useT and the
 * locale-helper re-exports) is byte-for-byte the same contract as before.
 *
 * - `t()` is a pure function usable on the server and the client.
 * - `useT()` is a client hook reading the current language from the app store.
 */
import { useCallback } from "react";
import { useAppStore } from "@/lib/store";
import type { Lang } from "@/lib/types";
import { landing } from "./domains/landing";
import { auth } from "./domains/auth";
import { wizard } from "./domains/wizard";
import { dashboard } from "./domains/dashboard";
import { site } from "./domains/site";
import { admin } from "./domains/admin";
import { store } from "./domains/store";
import { inventory } from "./domains/inventory";
import { features } from "./domains/features";
import { business } from "./domains/business";
import { common } from "./domains/common";

const AR = { ...landing.ar, ...auth.ar, ...wizard.ar, ...dashboard.ar, ...site.ar, ...admin.ar, ...store.ar, ...inventory.ar, ...features.ar, ...business.ar, ...common.ar };
const EN = { ...landing.en, ...auth.en, ...wizard.en, ...dashboard.en, ...site.en, ...admin.en, ...store.en, ...inventory.en, ...features.en, ...business.en, ...common.en };
const HI = { ...landing.hi, ...auth.hi, ...wizard.hi, ...dashboard.hi, ...site.hi, ...admin.hi, ...store.hi, ...inventory.hi, ...features.hi, ...business.hi, ...common.hi };

export type I18nKey = keyof typeof AR;

/**
 * Dictionaries per language. `ar` and `en` are complete; every other locale
 * (fr, es, pt, de, zh-CN, ja, ko, tr) is technically wired and resolves to
 * the ENGLISH dictionary until its own translations are filled in — so no
 * key ever renders as undefined. To activate a locale, add its dictionary
 * here (e.g. `fr: FR`) — the switcher, RTL/LTR and Intl formatting already
 * work (see src/lib/locales.ts).
 */
const DICTS: Partial<Record<Lang, Record<I18nKey, string>>> = { ar: AR, en: EN, hi: HI };

/** Kept for compatibility: the two complete dictionaries. */
export const I18N = { ar: AR, en: EN, hi: HI } as const;

/* ROUND 131 — the business-suite domain (verified complete for the type
 * parity the composer enforces on HI). */

/**
 * Translate a key for the given language.
 * Pure function — safe on the server and the client.
 * Falls back to English for locales without a dictionary, then to the key
 * itself (never undefined). Interpolates `{var}` placeholders when `vars`
 * is provided.
 */
export function t(lang: Lang, key: I18nKey, vars?: Record<string, string | number>): string {
  const dict: Record<I18nKey, string> = DICTS[lang] ?? EN;
  const raw = dict[key] ?? key;
  if (!vars) return raw;
  return raw.replace(/\{(\w+)\}/g, (match, name: string) =>
    vars[name] !== undefined ? String(vars[name]) : match
  );
}

/* Locale helpers (10-language registry) — re-exported for convenience. */
export { LOCALES, localeMeta, dirFor, intlLocale, localeNativeLabel, localeShortLabel, nextLocale } from "@/lib/locales";

/**
 * Client hook: reads the current language from the app store and returns
 * memoized translation helpers bound to it.
 */
export function useT(): {
  lang: Lang;
  t: (key: I18nKey, vars?: Record<string, string | number>) => string;
} {
  const lang = useAppStore((s) => s.lang);
  const translate = useCallback(
    (key: I18nKey, vars?: Record<string, string | number>) => t(lang, key, vars),
    [lang]
  );
  return { lang, t: translate };
}

