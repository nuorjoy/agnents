/**
 * Ashrilogic — central record-code engine (ROUND 68).
 *
 * ONE maintainable source of truth for every module's record identifier:
 * invoices, inventory, patients, products, reports, customers, the medical
 * file … every module whose preset declares an `id`-kind column.
 *
 *  Format:   {PREFIX}-{N}   e.g. INV-00000001
 *  Capacity: the numeric tail is zero-padded to `RECORD_CODE_MIN_DIGITS`
 *            (8) → 99,999,999 records per module before the padding simply
 *            WIDENS (the formatter never truncates, so record #100,000,000
 *            renders INV-100000000 — a 9-digit tail — with no migration).
 *  Continuity: `nextRecordCode` scans the existing codes (any width, any
 *            prefix) and continues from the highest numeric tail, so mixed
 *            legacy widths (INV-2026-0148, MRN-010240 …) and new 8-digit
 *            codes coexist and still never collide.
 *
 * The module prefix registry lives in module-data.ts (`codePrefixFor`) so
 * the code format and the module catalog evolve in one file. The invoice
 * prefix is owner-configurable (settings → الهوية والعلامة → invoice
 * prefix) — callers pass their resolved prefix in; this module never reads
 * app state (pure, server/client safe, unit-testable).
 */

/** Minimum digits of the numeric tail (the platform's 8+ digit mandate). */
export const RECORD_CODE_MIN_DIGITS = 8;

/** Hard ceiling on the numeric tail — 15 digits is the JS safe-integer
 *  scale; beyond this `nextRecordCode` refuses to roll over (defensive). */
export const RECORD_CODE_MAX_NUMBER = 9_999_999_999_999_999;

/** Default invoice prefix when the owner has not configured one. */
export const DEFAULT_INVOICE_PREFIX = "INV";

/** Invoice codes keep their classic year-qualified shape
 *  ({PREFIX}-{YYYY}-{8 digits}) — seeds read INV-2026-00001400, so the
 *  year segment preserves visual continuity while the tail is 8 digits. */
function invoiceTail(code: string): number | null {
  const m = /-(\d+)$/.exec(code.trim());
  return m ? Number(m[1]) : null;
}

/** Format a record code: uppercase prefix + zero-padded numeric tail. */
export function formatRecordCode(prefix: string, n: number): string {
  const clean = prefix.trim().toUpperCase().slice(0, 12) || DEFAULT_INVOICE_PREFIX;
  const safe = Math.max(1, Math.min(RECORD_CODE_MAX_NUMBER, Math.floor(n)));
  const tail = String(safe).padStart(RECORD_CODE_MIN_DIGITS, "0");
  return `${clean}-${tail}`;
}

/** Format an invoice code with the classic year segment:
 *  {PREFIX}-{YYYY}-00000001. */
export function formatInvoiceCode(prefix: string, n: number, year = new Date().getFullYear()): string {
  const clean = prefix.trim().toUpperCase().slice(0, 12) || DEFAULT_INVOICE_PREFIX;
  const safe = Math.max(1, Math.min(RECORD_CODE_MAX_NUMBER, Math.floor(n)));
  const tail = String(safe).padStart(RECORD_CODE_MIN_DIGITS, "0");
  return `${clean}-${year}-${tail}`;
}

/** Extract the numeric tail of any record code (`INV-00000001` → 1,
 *  `INV-2026-00001400` → 1400, `MRN-010240` → 10240 — any width).
 *  Non-codes → null. */
export function recordCodeSuffix(code: string): number | null {
  const m = /-(\d+)$/.exec(code.trim());
  if (!m) return null;
  const n = Number(m[1]);
  return Number.isSafeInteger(n) ? n : null;
}

/**
 * The next free code for a module: one higher than the highest numeric
 * tail found in the existing codes (codes without a numeric tail are
 * ignored; an empty set starts at 1).
 *
 * `invoice` mode keeps the year-qualified format; every other module uses
 * the plain {PREFIX}-{tail} shape.
 */
export function nextRecordCode(
  prefix: string,
  existingCodes: readonly string[],
  opts?: { invoice?: boolean; year?: number }
): string {
  const invoice = opts?.invoice ?? false;
  let max = 0;
  for (const code of existingCodes) {
    const n = invoice ? invoiceTail(code) : recordCodeSuffix(code);
    if (n !== null && n > max) max = n;
  }
  const next = max >= RECORD_CODE_MAX_NUMBER ? max : max + 1;
  return invoice
    ? formatInvoiceCode(prefix, next, opts?.year)
    : formatRecordCode(prefix, next);
}
