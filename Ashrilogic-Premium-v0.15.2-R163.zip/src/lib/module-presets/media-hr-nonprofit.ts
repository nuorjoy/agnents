/**
 * Ashrilogic — MEDIA + HR + ENTERTAINMENT + LEGAL + NONPROFIT + GENERAL
 * domain preset family (ROUND 132).
 *
 * The third curated demo-dataset split out of module-data.ts PRESETS: the
 * media family (campaigns, leads, content, publishing, analytics, billing,
 * creative, distribution), the HR family (leaves, recruitment, training,
 * performance, benefits, onboarding, timeclock), the entertainment family
 * (tournaments, sessions), the legal family (cases, hearings, timetracking,
 * deadlines), the nonprofit family (donations, volunteers, beneficiaries,
 * fundraising, communications) and the general-service family (jobs,
 * warranty, pricing). module-data merges this map; this file NEVER imports
 * module-data back — preset-kit is the single shared toolkit, so the
 * dependency graph stays acyclic.
 *
 * Demo-code series: one distinct 500-wide band per module inside
 * 66000–80000 (CMP-00066000 … PRC-00080000) — no overlap with any other
 * preset band, so every record code reads as its own series while
 * nextRecordCode continuity stays per-module. Status pools are
 * emerald-dominant and several columns are derived from the drawn status
 * (spend vs budget, rating vs score, checkout vs check-in, raised vs goal)
 * so the workspace KPIs stay analyzable.
 */
import {
  count,
  dateStr,
  money,
  padded,
  pctStr,
  person,
  phone,
  pick,
  recordCode,
  timeStr,
  yesNo,
} from "@/lib/module-presets/preset-kit";
import type { ModulePreset } from "@/lib/module-presets/preset-kit";
import type { Lang } from "@/lib/types";

/* ------------------------------------------------------------------ */
/* shared local helpers + bilingual pools                               */
/* ------------------------------------------------------------------ */

const AR_MONTHS = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
const EN_MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

/** shifts an ISO display date by n days (deterministic, timezone-safe). */
function shiftDate(iso: string, days: number): string {
  const d = new Date(`${iso}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return `${d.getUTCFullYear()}-${padded(d.getUTCMonth() + 1, 2)}-${padded(d.getUTCDate(), 2)}`;
}

/** performance-review rating label derived from the numeric score. */
function ratingLabel(score: number, lang: Lang): string {
  if (score >= 90) return lang === "ar" ? "ممتاز" : "Outstanding";
  if (score >= 80) return lang === "ar" ? "يتجاوز التوقعات" : "Exceeds expectations";
  if (score >= 70) return lang === "ar" ? "يحقق التوقعات" : "Meets expectations";
  if (score >= 60) return lang === "ar" ? "يحتاج تحسين" : "Needs improvement";
  return lang === "ar" ? "لا يحقق التوقعات" : "Below expectations";
}

/* ------------------------------------------------------------------ */
/* media — campaigns / leads / content / publishing / analytics /       */
/* billing / creative / distribution                                    */
/* ------------------------------------------------------------------ */

const AR_CAMPAIGNS = ["إطلاق التطبيق الجديد", "تخفيضات نهاية الموسم", "الجمعة البيضاء", "التوسع في الرياض", "الوعي بالعلامة التجارية", "إعادة استهداف المتسوقين", "حملة رمضان", "العودة إلى المدارس", "الترويج للباقة السنوية", "افتتاح فرع جدة"];
const EN_CAMPAIGNS = ["New app launch", "End-of-season sale", "White Friday", "Riyadh expansion", "Brand awareness", "Shopper retargeting", "Ramadan campaign", "Back to school", "Annual plan promo", "Jeddah branch opening"];
const AR_AD_CHANNELS = ["بحث ممول PPC", "سوشيال ميديا", "إعلانات عرضية Display", "بريد إلكتروني", "مؤثرون", "تحسين محركات البحث SEO"];
const EN_AD_CHANNELS = ["Paid search PPC", "Social media", "Display ads", "Email", "Influencers", "SEO"];

const AR_LEAD_SOURCES = ["الموقع الإلكتروني", "لينكدإن", "إحالة عميل", "إعلانات جوجل", "معرض تجاري", "نشرة بريدية", "بحث مباشر"];
const EN_LEAD_SOURCES = ["Website", "LinkedIn", "Client referral", "Google Ads", "Trade fair", "Newsletter", "Direct search"];
const AR_LEAD_STAGES = ["تأهيل", "متابعة", "عرض سعر", "تفاوض"];
const EN_LEAD_STAGES = ["Qualifying", "Nurturing", "Quotation", "Negotiation"];

/** [title-ar, type-ar, title-en, type-en] — one index keeps them coherent. */
const CONTENT_POOL: readonly [string, string, string, string][] = [
  ["دليل التسويق بالمحتوى 2026", "مقال مدونة", "Content marketing guide 2026", "Blog article"],
  ["كيف نعمل؟ قصة عميل", "دراسة حالة", "How we work: a client story", "Case study"],
  ["شرح الخدمة في 90 ثانية", "فيديو", "Our service in 90 seconds", "Video"],
  ["إحصاءات القطاع بالأرقام", "إنفوجرافيك", "The industry in numbers", "Infographic"],
  ["حلقة: مستقبل التجزئة", "بودكاست", "Episode: the future of retail", "Podcast"],
  ["نصائح لإدارة فريق عن بُعد", "مقال مدونة", "Tips for managing remote teams", "Blog article"],
  ["أفضل الممارسات الأمنية", "مقال مدونة", "Security best practices", "Blog article"],
  ["مقدمة في تحليل البيانات", "فيديو", "Intro to data analytics", "Video"],
  ["قصص نجاح المتدربين", "فيديو", "Trainee success stories", "Video"],
  ["العام في رسوم بيانية", "إنفوجرافيك", "The year in charts", "Infographic"],
];

const AR_PUB_CHANNELS = ["إكس (تويتر)", "إنستغرام", "يوتيوب", "لينكدإن", "تيك توك", "النشرة البريدية", "مدونة الشركة"];
const EN_PUB_CHANNELS = ["X (Twitter)", "Instagram", "YouTube", "LinkedIn", "TikTok", "Newsletter", "Company blog"];

const AR_REPORTS = ["تقرير حركة الموقع", "تقرير قمع التحويل", "تقرير الإيرادات", "تقرير الجمهور", "تقرير الأداء الإعلاني", "تقرير الاحتفاظ بالعملاء"];
const EN_REPORTS = ["Site traffic report", "Conversion funnel report", "Revenue report", "Audience report", "Ad performance report", "Customer retention report"];
/** [metric-ar, metric-en, min, max, decimals] — value ranges per metric. */
const METRICS: readonly [string, string, number, number, boolean][] = [
  ["الجلسات", "Sessions", 4200, 98000, false],
  ["معدل التحويل %", "Conversion rate %", 1.2, 9.8, true],
  ["معدل الارتداد %", "Bounce rate %", 28, 72, true],
  ["متوسط مدة الجلسة (ثانية)", "Avg. session duration (s)", 95, 420, false],
  ["نسبة النقر CTR %", "Ad CTR %", 0.8, 6.5, true],
  ["تكلفة اكتساب العميل", "Customer acquisition cost", 18, 240, false],
];

const AR_CLIENTS = ["شركة أفق الرقمية", "مؤسسة نما التجارية", "مجموعة الواحة", "شركة بناء المستقبل", "معادن الخليج", "شركة تقنية الوادي", "الشركة السعودية للأغذية", "مجموعة الريان القابضة"];
const EN_CLIENTS = ["Ufuq Digital Co.", "Nama Trading Est.", "Al Waha Group", "Build Future Co.", "Gulf Minerals", "Wadi Tech Co.", "Saudi Foods Co.", "Al Rayan Holding"];

const AR_ASSETS = ["هوية معرض الرياض", "بانر الجمعة البيضاء", "فيديو إعلاني 30 ثانية", "شعار فرع جدة", "قصة سوشيال رمضان", "غلاف النشرة البريدية", "بوستر مؤتمر التقنية", "دليل الهوية البصرية", "إعلان مدرج يوتيوب"];
const EN_ASSETS = ["Riyadh expo identity", "White Friday banner", "30s ad video", "Jeddah branch logo", "Ramadan social story", "Newsletter cover", "Tech conference poster", "Brand guideline book", "YouTube pre-roll ad"];
const AR_CREATIVE_TYPES = ["شعار", "بانر", "فيديو", "بوستر", "هوية", "موشن جرافيك"];
const EN_CREATIVE_TYPES = ["Logo", "Banner", "Video", "Poster", "Identity", "Motion graphic"];

const AR_CARRIERS = ["أرامكس", "سمسا إكسبريس", "ناقل", "البريد السعودي", "أسطول داخلي"];
const EN_CARRIERS = ["Aramex", "SMSA Express", "Naqel", "Saudi Post", "In-house fleet"];
const AR_REGIONS = ["الرياض", "جدة", "الدمام", "مكة المكرمة", "المدينة المنورة", "المنطقة الشرقية", "عسير"];
const EN_REGIONS = ["Riyadh", "Jeddah", "Dammam", "Makkah", "Madinah", "Eastern Province", "Asir"];

/* ------------------------------------------------------------------ */
/* HR — leaves / recruitment / training / performance / benefits /      */
/* onboarding / timeclock                                              */
/* ------------------------------------------------------------------ */

/** [type-ar, type-en, minDays, maxDays] — leave length follows the type. */
const LEAVE_TYPES: readonly [string, string, number, number][] = [
  ["إجازة سنوية", "Annual leave", 3, 20],
  ["إجازة مرضية", "Sick leave", 1, 10],
  ["إجازة طارئة", "Emergency leave", 1, 3],
  ["إجازة غير مدفوعة", "Unpaid leave", 5, 30],
  ["إجازة أمومة", "Maternity leave", 45, 70],
  ["إجازة حج", "Hajj leave", 7, 14],
];

const AR_POSITIONS = ["مدير تسويق رقمي", "مهندس برمجيات أول", "محلل بيانات", "أخصائي موارد بشرية", "مدير حسابات", "مصمم واجهات UI/UX", "مسؤول مبيعات", "محاسب أول", "مدير منتج"];
const EN_POSITIONS = ["Digital marketing manager", "Senior software engineer", "Data analyst", "HR specialist", "Account manager", "UI/UX designer", "Sales executive", "Senior accountant", "Product manager"];
const AR_RECRUIT_STAGES = ["فرز أولي", "مقابلة تقنية", "مقابلة نهائية", "عرض وظيفي"];
const EN_RECRUIT_STAGES = ["Screening", "Technical interview", "Final interview", "Offer"];
const AR_RECRUIT_SOURCES = ["لينكدإن", "بوابة التوظيف", "إحالة موظف", "مكتب توظيف", "معرض وظائف"];
const EN_RECRUIT_SOURCES = ["LinkedIn", "Careers portal", "Employee referral", "Recruiting agency", "Job fair"];

const AR_PROGRAMS = ["تحليل البيانات بـ Excel", "القيادة الإدارية", "الأمن السيبراني الأساسي", "إدارة المشاريع PMP", "خدمة العملاء المتميزة", "السلامة المهنية", "Power BI للمديرين", "مهارات التفاوض", "إدارة الوقت"];
const EN_PROGRAMS = ["Data analysis with Excel", "Managerial leadership", "Cybersecurity basics", "PMP project management", "Customer service excellence", "Occupational safety", "Power BI for managers", "Negotiation skills", "Time management"];

const AR_BENEFITS = ["تأمين طبي", "بدل سكن", "بدل نقل", "تأمين أسنان", "مكافأة أداء", "اشتراك نادٍ رياضي", "بدل هاتف", "تأمين حوادث"];
const EN_BENEFITS = ["Medical insurance", "Housing allowance", "Transport allowance", "Dental coverage", "Performance bonus", "Gym membership", "Phone allowance", "Accident insurance"];

const AR_ONBOARD_ROLES = ["أخصائي تسويق", "مهندس برمجيات", "محلل بيانات", "مسؤول موارد بشرية", "مصمم واجهات", "مسؤول دعم فني", "محاسب", "مسؤول مشتريات"];
const EN_ONBOARD_ROLES = ["Marketing specialist", "Software engineer", "Data analyst", "HR officer", "UI designer", "Support specialist", "Accountant", "Procurement officer"];

/* ------------------------------------------------------------------ */
/* entertainment + legal + nonprofit + general                          */
/* ------------------------------------------------------------------ */

const AR_TOURNAMENTS = ["دوري أبطال الرياض", "كأس الخليج الودّي", "دوري رمضان التنافسي", "بطولة المدارس", "كأس آسيا الافتراضي", "دوري الرياض الإلكتروني", "بطولة نهاية الموسم"];
const EN_TOURNAMENTS = ["Riyadh Champions Cup", "Gulf Friendly Cup", "Ramadan Competitive League", "Schools Championship", "Virtual Asian Cup", "Riyadh Esports League", "Season Finale"];
const AR_GAMES = ["كرة القدم", "كرة السلة", "إلكترونية — فيفا", "إلكترونية — كول أوف ديوتي", "تنس الطاولة", "كرة الطائرة", "بادل"];
const EN_GAMES = ["Football", "Basketball", "Esports — FIFA", "Esports — Call of Duty", "Table tennis", "Volleyball", "Padel"];

const AR_SESSIONS = ["تدريب تكتيكي", "تمرين لياقي", "جلسة تحليل فيديو", "معسكر مفتوح", "تدريب حراس المرمى", "ورشة إعداد ذهني", "حصة تجريبية"];
const EN_SESSIONS = ["Tactical drill", "Fitness session", "Video analysis", "Open camp", "Goalkeeper training", "Mental prep workshop", "Trial session"];

const AR_CASE_SUBJECTS = ["نزاع عقد توريد", "مطالبة مالية", "قضية عمالية", "إخلاء عقاري", "تعويض حادث مروري", "تزوير مستندات", "تنفيذ حكم", "تعدي على ملكية فكرية"];
const EN_CASE_SUBJECTS = ["Supply contract dispute", "Financial claim", "Labor case", "Eviction case", "Traffic accident compensation", "Document forgery", "Judgment enforcement", "IP infringement"];
const AR_CASE_TYPES = ["مدنية", "تجارية", "جنائية", "عمالية"];
const EN_CASE_TYPES = ["Civil", "Commercial", "Criminal", "Labor"];
const AR_COURTS = ["المحكمة العامة بالرياض", "المحكمة التجارية بالرياض", "المحكمة العمالية", "محكمة الاستئناف", "المحكمة الجزائية", "المحكمة العامة بجدة"];
const EN_COURTS = ["Riyadh General Court", "Riyadh Commercial Court", "Labor Court", "Court of Appeal", "Criminal Court", "Jeddah General Court"];

const AR_MATTERS = ["قضية نزاع التوريد", "مشروع إعادة التصميم", "موقع التجارة الإلكترونية", "حملة الإطلاق الكبرى", "مراجعة عقد الامتياز", "التحضير للمحاكمة", "اندماج الشركة الناشئة"];
const EN_MATTERS = ["Supply dispute case", "Redesign project", "E-commerce website", "Flagship launch campaign", "Franchise contract review", "Trial preparation", "Startup merger"];
const AR_TT_TASKS = ["بحث قانوني", "صياغة مذكرة", "اجتماع مع العميل", "تصميم واجهات", "مراجعة تقنية", "كتابة محتوى", "اختبارات قبول"];
const EN_TT_TASKS = ["Legal research", "Brief drafting", "Client meeting", "UI design", "Technical review", "Content writing", "Acceptance testing"];

const AR_DEADLINE_TYPES = ["تقديم مذكرة", "تسليم مشروع", "تجديد رخصة", "سداد ضريبة القيمة المضافة", "انتهاء عقد", "رد على استئناف", "تسليم تقرير ربعي"];
const EN_DEADLINE_TYPES = ["Brief filing", "Project delivery", "License renewal", "VAT payment", "Contract expiry", "Appeal response", "Quarterly report"];

const AR_DON_METHODS = ["تحويل بنكي", "مدى", "Apple Pay", "نقداً", "شيك"];
const EN_DON_METHODS = ["Bank transfer", "Mada", "Apple Pay", "Cash", "Cheque"];
const AR_DON_CAMPAIGNS = ["كفالة أيتام", "إفطار صائم", "سقيا الماء", "حملة الشتاء", "سلال الغذاء", "دعم التعليم", "المساعدات الطبية", "الإغاثة الطارئة"];
const EN_DON_CAMPAIGNS = ["Orphan sponsorship", "Iftar meals", "Water wells", "Winter drive", "Food baskets", "Education support", "Medical aid", "Emergency relief"];

const AR_VOL_ROLES = ["تنظيم الفعاليات", "تغليف الوجبات", "تدريس الأطفال", "قيادة فريق", "دعم لوجستي", "زيارة المرضى", "إدارة وسائل التواصل"];
const EN_VOL_ROLES = ["Event coordination", "Meal packing", "Children tutoring", "Team leading", "Logistics support", "Hospital visits", "Social media"];

const AR_BEN_CATEGORIES = ["أسر متعففة", "أيتام", "كبار السن", "ذوو الإعاقة", "مرضى مزمنون"];
const EN_BEN_CATEGORIES = ["Families in need", "Orphans", "Elderly", "Persons with disabilities", "Chronic patients"];
const AR_AID_TYPES = ["سلة غذائية", "دفع إيجار", "فاتورة كهرباء", "دعم تعليمي", "أجهزة طبية", "كسوة الشتاء"];
const EN_AID_TYPES = ["Food basket", "Rent payment", "Electricity bill", "Education support", "Medical equipment", "Winter clothing"];

const AR_FUND_CAMPAIGNS = ["بناء مستشفى الميدان", "تجهيز مدرسة نموذجية", "حفر آبار المياه", "مركز تأهيل الأطفال", "أسطول الإغاثة", "كراسي متحركة للمحتاجين", "مخيمات الشتاء"];
const EN_FUND_CAMPAIGNS = ["Field hospital construction", "Model school build-out", "Water well drilling", "Child rehab center", "Relief fleet", "Wheelchairs for those in need", "Winter camps"];

const AR_COMM_AUDIENCES = ["المتبرعون النشطون", "المستفيدون", "المتطوعون", "مجتمع المدرسة", "العملاء الحاليون", "المشتركون الجدد"];
const EN_COMM_AUDIENCES = ["Active donors", "Beneficiaries", "Volunteers", "School community", "Current customers", "New subscribers"];
/** [channel-ar, channel-en, openRateMin, openRateMax] — reach varies by channel. */
const COMM_CHANNELS: readonly [string, string, number, number][] = [
  ["رسائل نصية SMS", "SMS", 58, 94],
  ["بريد إلكتروني", "Email", 16, 42],
  ["إشعارات التطبيق", "Push notifications", 10, 32],
  ["واتساب", "WhatsApp", 62, 96],
];

const AR_JOB_TYPES = ["تركيب مكيف سبليت", "صيانة غسالة أوتوماتيك", "إصلاح تسريب مياه", "تمديد كهرباء منزلي", "دهان غرفة كاملة", "تركيب إضاءة LED", "صيانة مصعد", "فحص شبكة التكييف"];
const EN_JOB_TYPES = ["Split AC installation", "Washing machine repair", "Water leak repair", "Home electrical wiring", "Full room painting", "LED lighting install", "Elevator maintenance", "HVAC network check"];
const AR_PRIORITIES = ["عاجل", "عادي", "منخفض"];
const EN_PRIORITIES = ["Urgent", "Normal", "Low"];

const AR_WARRANTY_ITEMS = ["مكيف سبليت 24 ألف", "غسالة أوتوماتيك", "ثلاجة باب جانبي", "شاشة 65 بوصة", "فرن بلتي", "مكيف مركزي", "سخان مياه", "شفاط مطبخ"];
const EN_WARRANTY_ITEMS = ["24K BTU split AC", "Front-load washer", "Side-by-side fridge", '65" TV', "Built-in oven", "Central AC unit", "Water heater", "Kitchen hood"];

const AR_PRICING_PLANS = ["الباقة الأساسية", "باقة الأعمال", "الباقة الاحترافية", "خطة الصيانة الذهبية", "الاشتراك المميز", "باقة الفرق"];
const EN_PRICING_PLANS = ["Starter plan", "Business plan", "Professional plan", "Gold maintenance plan", "Premium subscription", "Team plan"];
const AR_TIERS = ["شهري", "سنوي", "ربع سنوي"];
const EN_TIERS = ["Monthly", "Yearly", "Quarterly"];

/* ------------------------------------------------------------------ */
/* the 29 media + HR + entertainment + legal + nonprofit + general      */
/* presets                                                             */
/* ------------------------------------------------------------------ */

export const MEDIA_HR_NPO_PRESETS: Record<string, ModulePreset> = {
  /* الحملات */
  campaigns: {
    cols: [
      { key: "code", ar: "رقم الحملة", en: "Campaign #", kind: "id" },
      { key: "campaign", ar: "الحملة", en: "Campaign", kind: "text" },
      { key: "channel", ar: "القناة", en: "Channel", kind: "text" },
      { key: "budget", ar: "الميزانية", en: "Budget", kind: "money" },
      { key: "spend", ar: "المصروف", en: "Spend", kind: "money" },
      { key: "conversions", ar: "التحويلات", en: "Conversions", kind: "num" },
      { key: "roas", ar: "العائد على الإنفاق", en: "ROAS", kind: "num" },
      { key: "launch", ar: "تاريخ الإطلاق", en: "Launch", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "live", ar: "فعّالة", en: "Live", tone: "emerald" },
      { key: "scheduled", ar: "مجدولة", en: "Scheduled", tone: "sky" },
      { key: "paused", ar: "متوقفة مؤقتاً", en: "Paused", tone: "amber" },
      { key: "ended", ar: "منتهية", en: "Ended", tone: "slate" },
      { key: "under", ar: "أقل من المستهدف", en: "Under target", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["live", "live", "live", "scheduled", "paused", "ended", "under"]);
      const budget = money(rng, 8000, 150000);
      const spendFactor =
        st === "scheduled" ? 0 : st === "ended" ? 0.85 + rng() * 0.15 : st === "paused" ? 0.3 + rng() * 0.3 : st === "under" ? 0.5 + rng() * 0.4 : 0.25 + rng() * 0.65;
      const roas = st === "under" ? 0.4 + rng() * 0.9 : 1.8 + rng() * 4.2;
      const spend = Math.round(budget * spendFactor * 100) / 100;
      return [
        recordCode("CMP", 66000 + i),
        lang === "ar" ? pick(rng, AR_CAMPAIGNS) : pick(rng, EN_CAMPAIGNS),
        lang === "ar" ? pick(rng, AR_AD_CHANNELS) : pick(rng, EN_AD_CHANNELS),
        budget.toFixed(2),
        spend.toFixed(2),
        String(count(rng, 40, 3400)),
        roas.toFixed(2),
        dateStr(rng),
        st,
      ];
    },
    count: [16, 28],
    moneyKey: "budget",
  },

  /* العملاء المحتملون */
  leads: {
    cols: [
      { key: "code", ar: "رقم العميل المحتمل", en: "Lead #", kind: "id" },
      { key: "name", ar: "الاسم", en: "Name", kind: "text" },
      { key: "source", ar: "المصدر", en: "Source", kind: "text" },
      { key: "score", ar: "درجة التأهيل", en: "Score", kind: "num" },
      { key: "stage", ar: "المرحلة", en: "Stage", kind: "text" },
      { key: "value", ar: "القيمة المتوقعة", en: "Expected value", kind: "money" },
      { key: "owner", ar: "المسؤول", en: "Owner", kind: "text" },
      { key: "date", ar: "تاريخ الاستلام", en: "Received", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "qualified", ar: "مؤهل", en: "Qualified", tone: "emerald" },
      { key: "new", ar: "جديد", en: "New", tone: "sky" },
      { key: "nurture", ar: "قيد المتابعة", en: "Nurturing", tone: "amber" },
      { key: "contacted", ar: "تم التواصل", en: "Contacted", tone: "violet" },
      { key: "lost", ar: "مفقود", en: "Lost", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["qualified", "qualified", "qualified", "new", "nurture", "contacted", "lost"]);
      const score = st === "qualified" ? count(rng, 70, 98) : st === "lost" ? count(rng, 15, 45) : count(rng, 40, 85);
      return [
        recordCode("LED", 66500 + i),
        person(rng, lang),
        lang === "ar" ? pick(rng, AR_LEAD_SOURCES) : pick(rng, EN_LEAD_SOURCES),
        String(score),
        lang === "ar" ? pick(rng, AR_LEAD_STAGES) : pick(rng, EN_LEAD_STAGES),
        money(rng, 2500, 240000).toFixed(2),
        person(rng, lang),
        dateStr(rng),
        st,
      ];
    },
    count: [18, 30],
    moneyKey: "value",
  },

  /* المحتوى */
  content: {
    cols: [
      { key: "code", ar: "رقم المحتوى", en: "Asset #", kind: "id" },
      { key: "title", ar: "العنوان", en: "Title", kind: "text" },
      { key: "type", ar: "النوع", en: "Type", kind: "text" },
      { key: "author", ar: "الكاتب", en: "Author", kind: "text" },
      { key: "words", ar: "عدد الكلمات", en: "Word count", kind: "num" },
      { key: "views", ar: "المشاهدات", en: "Views", kind: "num" },
      { key: "date", ar: "تاريخ النشر", en: "Published", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "published", ar: "منشور", en: "Published", tone: "emerald" },
      { key: "scheduled", ar: "مجدول", en: "Scheduled", tone: "sky" },
      { key: "review", ar: "قيد التحرير", en: "In editing", tone: "amber" },
      { key: "draft", ar: "مسودة", en: "Draft", tone: "violet" },
      { key: "archived", ar: "مؤرشف", en: "Archived", tone: "slate" },
    ],
    row: (rng, i, lang) => {
      const c = pick(rng, CONTENT_POOL);
      const st = pick(rng, ["published", "published", "published", "published", "scheduled", "review", "draft", "archived"]);
      return [
        recordCode("CNT", 67000 + i),
        lang === "ar" ? c[0] : c[2],
        lang === "ar" ? c[1] : c[3],
        person(rng, lang),
        String(count(rng, 350, 2800)),
        st === "published" || st === "archived" ? String(count(rng, 120, 46000)) : "—",
        dateStr(rng),
        st,
      ];
    },
    count: [16, 26],
  },

  /* النشر */
  publishing: {
    cols: [
      { key: "code", ar: "رقم النشر", en: "Post #", kind: "id" },
      { key: "channel", ar: "القناة", en: "Channel", kind: "text" },
      { key: "planned", ar: "التاريخ المخطط", en: "Planned", kind: "date" },
      { key: "slot", ar: "الوقت المخطط", en: "Slot", kind: "text" },
      { key: "published", ar: "تاريخ النشر الفعلي", en: "Published", kind: "date" },
      { key: "reach", ar: "الوصول", en: "Reach", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "published", ar: "تم النشر", en: "Published", tone: "emerald" },
      { key: "scheduled", ar: "مجدول", en: "Scheduled", tone: "sky" },
      { key: "delayed", ar: "متأخر", en: "Delayed", tone: "amber" },
      { key: "cancelled", ar: "ملغى", en: "Cancelled", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["published", "published", "published", "published", "scheduled", "delayed", "cancelled"]);
      const planned = dateStr(rng);
      const published =
        st === "published" ? shiftDate(planned, count(rng, -1, 1)) : st === "delayed" ? shiftDate(planned, count(rng, 3, 9)) : "—";
      return [
        recordCode("PUB", 67500 + i),
        lang === "ar" ? pick(rng, AR_PUB_CHANNELS) : pick(rng, EN_PUB_CHANNELS),
        planned,
        timeStr(rng),
        published,
        st === "published" ? String(count(rng, 800, 240000)) : "—",
        st,
      ];
    },
    count: [16, 28],
  },

  /* التحليلات */
  analytics: {
    cols: [
      { key: "code", ar: "رقم التقرير", en: "Report #", kind: "id" },
      { key: "report", ar: "التقرير", en: "Report", kind: "text" },
      { key: "metric", ar: "المؤشر", en: "Metric", kind: "text" },
      { key: "value", ar: "القيمة", en: "Value", kind: "num" },
      { key: "delta", ar: "التغير عن الفترة السابقة", en: "Period delta", kind: "text" },
      { key: "period", ar: "الفترة", en: "Period", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "ready", ar: "جاهز", en: "Ready", tone: "emerald" },
      { key: "scheduled", ar: "مجدول", en: "Scheduled", tone: "sky" },
      { key: "drafting", ar: "قيد الإعداد", en: "Drafting", tone: "amber" },
      { key: "anomaly", ar: "شذوذ في البيانات", en: "Data anomaly", tone: "rose" },
      { key: "archived", ar: "مؤرشف", en: "Archived", tone: "slate" },
    ],
    row: (rng, i, lang) => {
      const m = pick(rng, METRICS);
      const st = pick(rng, ["ready", "ready", "ready", "ready", "scheduled", "drafting", "anomaly", "archived"]);
      const raw = st === "anomaly" ? pctStr(rng, -28, -8) : pctStr(rng, -6.5, 18.5);
      const delta = raw.startsWith("-") ? `${raw}%` : `+${raw}%`;
      const v = m[2] + rng() * (m[3] - m[2]);
      const monthIdx = Math.floor(rng() * 12);
      return [
        recordCode("ANL", 68000 + i),
        lang === "ar" ? pick(rng, AR_REPORTS) : pick(rng, EN_REPORTS),
        lang === "ar" ? m[0] : m[1],
        m[4] ? v.toFixed(1) : String(Math.round(v)),
        delta,
        `${lang === "ar" ? AR_MONTHS[monthIdx] : EN_MONTHS[monthIdx]} 2026`,
        st,
      ];
    },
    count: [14, 24],
  },

  /* الفوترة */
  billing: {
    cols: [
      { key: "code", ar: "رقم كشف الفوترة", en: "Statement #", kind: "id" },
      { key: "client", ar: "العميل", en: "Client", kind: "text" },
      { key: "invoices", ar: "عدد الفواتير", en: "Invoices", kind: "num" },
      { key: "amount", ar: "إجمالي المبلغ", en: "Total amount", kind: "money" },
      { key: "period", ar: "الفترة", en: "Period", kind: "text" },
      { key: "due", ar: "تاريخ الاستحقاق", en: "Due", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "paid", ar: "مدفوعة", en: "Paid", tone: "emerald" },
      { key: "partial", ar: "مدفوعة جزئياً", en: "Partially paid", tone: "amber" },
      { key: "pending", ar: "مستحقة", en: "Pending", tone: "sky" },
      { key: "overdue", ar: "متأخرة", en: "Overdue", tone: "rose" },
      { key: "disputed", ar: "متنازع عليها", en: "Disputed", tone: "violet" },
    ],
    row: (rng, i, lang) => {
      const monthIdx = Math.floor(rng() * 12);
      return [
        recordCode("BIL", 68500 + i),
        lang === "ar" ? pick(rng, AR_CLIENTS) : pick(rng, EN_CLIENTS),
        String(count(rng, 1, 24)),
        money(rng, 2400, 180000).toFixed(2),
        `${lang === "ar" ? AR_MONTHS[monthIdx] : EN_MONTHS[monthIdx]} 2026`,
        dateStr(rng),
        pick(rng, ["paid", "paid", "paid", "paid", "partial", "pending", "overdue", "disputed"]),
      ];
    },
    count: [16, 28],
    moneyKey: "amount",
  },

  /* الإبداع */
  creative: {
    cols: [
      { key: "code", ar: "رقم العمل", en: "Asset #", kind: "id" },
      { key: "asset", ar: "العمل الإبداعي", en: "Asset", kind: "text" },
      { key: "type", ar: "النوع", en: "Type", kind: "text" },
      { key: "designer", ar: "المصمم", en: "Designer", kind: "text" },
      { key: "revisions", ar: "عدد التعديلات", en: "Revisions", kind: "num" },
      { key: "cost", ar: "تكلفة التنفيذ", en: "Production cost", kind: "money" },
      { key: "due", ar: "الموعد النهائي", en: "Due", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "approved", ar: "معتمد", en: "Approved", tone: "emerald" },
      { key: "review", ar: "قيد المراجعة", en: "In review", tone: "amber" },
      { key: "inprogress", ar: "جاري التصميم", en: "Designing", tone: "violet" },
      { key: "revision", ar: "قيد التعديل", en: "In revision", tone: "sky" },
      { key: "rejected", ar: "مرفوض", en: "Rejected", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["approved", "approved", "approved", "review", "inprogress", "revision", "rejected"]);
      const revisions =
        st === "revision" || st === "rejected" ? count(rng, 3, 7) : st === "approved" ? count(rng, 0, 2) : count(rng, 1, 3);
      return [
        recordCode("CRE", 69000 + i),
        lang === "ar" ? pick(rng, AR_ASSETS) : pick(rng, EN_ASSETS),
        lang === "ar" ? pick(rng, AR_CREATIVE_TYPES) : pick(rng, EN_CREATIVE_TYPES),
        person(rng, lang),
        String(revisions),
        money(rng, 800, 9500).toFixed(2),
        dateStr(rng),
        st,
      ];
    },
    count: [16, 26],
    moneyKey: "cost",
  },

  /* التوزيع */
  distribution: {
    cols: [
      { key: "code", ar: "رقم الشحنة", en: "Shipment #", kind: "id" },
      { key: "carrier", ar: "الناقل", en: "Carrier", kind: "text" },
      { key: "region", ar: "المنطقة", en: "Region", kind: "text" },
      { key: "deliveries", ar: "عدد التوصيلات", en: "Deliveries", kind: "num" },
      { key: "cost", ar: "تكلفة التوزيع", en: "Distribution cost", kind: "money" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "delivered", ar: "تم التسليم", en: "Delivered", tone: "emerald" },
      { key: "transit", ar: "قيد النقل", en: "In transit", tone: "sky" },
      { key: "delayed", ar: "متأخر", en: "Delayed", tone: "amber" },
      { key: "returned", ar: "مرتجع", en: "Returned", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const deliveries = count(rng, 40, 420);
      const cost = Math.round(deliveries * money(rng, 8, 18) * 100) / 100;
      return [
        recordCode("DST", 69500 + i),
        lang === "ar" ? pick(rng, AR_CARRIERS) : pick(rng, EN_CARRIERS),
        lang === "ar" ? pick(rng, AR_REGIONS) : pick(rng, EN_REGIONS),
        String(deliveries),
        cost.toFixed(2),
        dateStr(rng),
        pick(rng, ["delivered", "delivered", "delivered", "delivered", "transit", "delayed", "returned"]),
      ];
    },
    count: [14, 24],
    moneyKey: "cost",
  },

  /* الإجازات */
  leaves: {
    cols: [
      { key: "code", ar: "رقم الطلب", en: "Request #", kind: "id" },
      { key: "employee", ar: "الموظف", en: "Employee", kind: "text" },
      { key: "type", ar: "نوع الإجازة", en: "Leave type", kind: "text" },
      { key: "days", ar: "عدد الأيام", en: "Days", kind: "num" },
      { key: "from", ar: "من", en: "From", kind: "date" },
      { key: "to", ar: "إلى", en: "To", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "approved", ar: "معتمدة", en: "Approved", tone: "emerald" },
      { key: "pending", ar: "بانتظار الموافقة", en: "Awaiting approval", tone: "amber" },
      { key: "rejected", ar: "مرفوضة", en: "Rejected", tone: "rose" },
      { key: "cancelled", ar: "ملغاة", en: "Cancelled", tone: "slate" },
    ],
    row: (rng, i, lang) => {
      const t = pick(rng, LEAVE_TYPES);
      const days = count(rng, t[2], t[3]);
      const from = dateStr(rng);
      return [
        recordCode("LVE", 70000 + i),
        person(rng, lang),
        lang === "ar" ? t[0] : t[1],
        String(days),
        from,
        shiftDate(from, days - 1),
        pick(rng, ["approved", "approved", "approved", "approved", "pending", "rejected", "cancelled"]),
      ];
    },
    count: [18, 30],
  },

  /* التوظيف */
  recruitment: {
    cols: [
      { key: "code", ar: "رقم الطلب الوظيفي", en: "Requisition #", kind: "id" },
      { key: "position", ar: "الوظيفة", en: "Position", kind: "text" },
      { key: "candidate", ar: "المرشح", en: "Candidate", kind: "text" },
      { key: "stage", ar: "المرحلة", en: "Stage", kind: "text" },
      { key: "score", ar: "درجة التقييم", en: "Score", kind: "num" },
      { key: "source", ar: "مصدر المرشح", en: "Source", kind: "text" },
      { key: "date", ar: "تاريخ التقديم", en: "Applied", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "hired", ar: "تم التعيين", en: "Hired", tone: "emerald" },
      { key: "offered", ar: "عرض قيد المراجعة", en: "Offer pending", tone: "violet" },
      { key: "interviewing", ar: "في المقابلات", en: "Interviewing", tone: "sky" },
      { key: "screening", ar: "الفرز الأولي", en: "Screening", tone: "amber" },
      { key: "rejected", ar: "مرفوض", en: "Rejected", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["hired", "hired", "interviewing", "interviewing", "offered", "screening", "rejected"]);
      const score = st === "rejected" ? count(rng, 40, 64) : st === "hired" ? count(rng, 82, 98) : count(rng, 55, 90);
      return [
        recordCode("RCR", 70500 + i),
        lang === "ar" ? pick(rng, AR_POSITIONS) : pick(rng, EN_POSITIONS),
        person(rng, lang),
        lang === "ar" ? pick(rng, AR_RECRUIT_STAGES) : pick(rng, EN_RECRUIT_STAGES),
        String(score),
        lang === "ar" ? pick(rng, AR_RECRUIT_SOURCES) : pick(rng, EN_RECRUIT_SOURCES),
        dateStr(rng),
        st,
      ];
    },
    count: [18, 30],
  },

  /* التدريب */
  training: {
    cols: [
      { key: "code", ar: "رقم البرنامج", en: "Program #", kind: "id" },
      { key: "program", ar: "البرنامج التدريبي", en: "Program", kind: "text" },
      { key: "trainer", ar: "المدرب", en: "Trainer", kind: "text" },
      { key: "seats", ar: "المقاعد", en: "Seats", kind: "num" },
      { key: "hours", ar: "الساعات التدريبية", en: "Training hours", kind: "num" },
      { key: "cost", ar: "التكلفة", en: "Cost", kind: "money" },
      { key: "date", ar: "تاريخ الانعقاد", en: "Starts", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "confirmed", ar: "مؤكد", en: "Confirmed", tone: "emerald" },
      { key: "open", ar: "التسجيل مفتوح", en: "Registration open", tone: "sky" },
      { key: "waitlist", ar: "قائمة انتظار", en: "Waitlist", tone: "amber" },
      { key: "cancelled", ar: "ملغى", en: "Cancelled", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const seats = count(rng, 8, 40);
      const perSeat = money(rng, 350, 900);
      return [
        recordCode("TRA", 71000 + i),
        lang === "ar" ? pick(rng, AR_PROGRAMS) : pick(rng, EN_PROGRAMS),
        person(rng, lang),
        String(seats),
        String(count(rng, 4, 40)),
        Math.round(seats * perSeat * 100 / 100).toFixed(2),
        dateStr(rng),
        pick(rng, ["confirmed", "confirmed", "confirmed", "open", "open", "waitlist", "cancelled"]),
      ];
    },
    count: [14, 26],
    moneyKey: "cost",
  },

  /* الأداء */
  performance: {
    cols: [
      { key: "code", ar: "رقم التقييم", en: "Review #", kind: "id" },
      { key: "employee", ar: "الموظف", en: "Employee", kind: "text" },
      { key: "cycle", ar: "دورة التقييم", en: "Cycle", kind: "text" },
      { key: "score", ar: "الدرجة", en: "Score", kind: "num" },
      { key: "rating", ar: "التقدير", en: "Rating", kind: "text" },
      { key: "goals", ar: "نسبة تحقيق الأهداف %", en: "Goals met %", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "met", ar: "حقق الأهداف", en: "Goals met", tone: "emerald" },
      { key: "developing", ar: "قيد التطوير", en: "Developing", tone: "amber" },
      { key: "pip", ar: "خطة تحسين الأداء", en: "Improvement plan", tone: "rose" },
      { key: "pending", ar: "لم يُقيّم بعد", en: "Not yet reviewed", tone: "sky" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["met", "met", "met", "met", "developing", "pip", "pending"]);
      if (st === "pending") {
        return [
          recordCode("PRF", 71500 + i),
          person(rng, lang),
          lang === "ar" ? "تقييم 2026 — النصف الأول" : "2026 H1",
          "—",
          "—",
          "—",
          st,
        ];
      }
      const score = st === "met" ? count(rng, 70, 98) : st === "developing" ? count(rng, 60, 74) : count(rng, 45, 62);
      return [
        recordCode("PRF", 71500 + i),
        person(rng, lang),
        lang === "ar" ? "تقييم 2026 — النصف الأول" : "2026 H1",
        String(score),
        ratingLabel(score, lang),
        pctStr(rng, 42, 100),
        st,
      ];
    },
    count: [16, 28],
  },

  /* المزايا */
  benefits: {
    cols: [
      { key: "code", ar: "رقم الميزة", en: "Benefit #", kind: "id" },
      { key: "employee", ar: "الموظف", en: "Employee", kind: "text" },
      { key: "benefit", ar: "الميزة", en: "Benefit", kind: "text" },
      { key: "value", ar: "القيمة", en: "Value", kind: "money" },
      { key: "effective", ar: "تاريخ السريان", en: "Effective", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "سارية", en: "Active", tone: "emerald" },
      { key: "pending", ar: "قيد الاعتماد", en: "Pending approval", tone: "amber" },
      { key: "suspended", ar: "موقوفة", en: "Suspended", tone: "rose" },
      { key: "ended", ar: "منتهية", en: "Ended", tone: "slate" },
    ],
    row: (rng, i, lang) => [
      recordCode("BNF", 72000 + i),
      person(rng, lang),
      lang === "ar" ? pick(rng, AR_BENEFITS) : pick(rng, EN_BENEFITS),
      money(rng, 150, 9500).toFixed(2),
      dateStr(rng),
      pick(rng, ["active", "active", "active", "active", "active", "pending", "suspended", "ended"]),
    ],
    count: [16, 26],
    moneyKey: "value",
  },

  /* التهيئة */
  onboarding: {
    cols: [
      { key: "code", ar: "رقم التهيئة", en: "Onboarding #", kind: "id" },
      { key: "employee", ar: "الموظف الجديد", en: "New hire", kind: "text" },
      { key: "role", ar: "الدور", en: "Role", kind: "text" },
      { key: "progress", ar: "إنجاز قائمة التهيئة %", en: "Checklist %", kind: "num" },
      { key: "mentor", ar: "المرشد", en: "Mentor", kind: "text" },
      { key: "start", ar: "تاريخ المباشرة", en: "Start", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "completed", ar: "مكتملة", en: "Completed", tone: "emerald" },
      { key: "inprogress", ar: "قيد التهيئة", en: "In progress", tone: "sky" },
      { key: "upcoming", ar: "تبدأ قريباً", en: "Starting soon", tone: "amber" },
      { key: "withdrawn", ar: "انسحب", en: "Withdrawn", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["completed", "completed", "completed", "inprogress", "inprogress", "upcoming", "withdrawn"]);
      const progress =
        st === "completed" ? "100.0" : st === "inprogress" ? pctStr(rng, 15, 90) : st === "upcoming" ? "0.0" : "—";
      return [
        recordCode("ONB", 72500 + i),
        person(rng, lang),
        lang === "ar" ? pick(rng, AR_ONBOARD_ROLES) : pick(rng, EN_ONBOARD_ROLES),
        progress,
        person(rng, lang),
        dateStr(rng),
        st,
      ];
    },
    count: [14, 24],
  },

  /* ساعة الدوام */
  timeclock: {
    cols: [
      { key: "code", ar: "رقم البصمة", en: "Punch #", kind: "id" },
      { key: "employee", ar: "الموظف", en: "Employee", kind: "text" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "checkin", ar: "الحضور", en: "Check-in", kind: "text" },
      { key: "checkout", ar: "الانصراف", en: "Check-out", kind: "text" },
      { key: "hours", ar: "ساعات العمل", en: "Worked hours", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "present", ar: "حاضر", en: "Present", tone: "emerald" },
      { key: "late", ar: "تأخر الحضور", en: "Late arrival", tone: "amber" },
      { key: "onleave", ar: "في إجازة", en: "On leave", tone: "violet" },
      { key: "absent", ar: "غائب", en: "Absent", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["present", "present", "present", "present", "late", "onleave", "absent"]);
      if (st === "onleave" || st === "absent") {
        return [recordCode("TMC", 73000 + i), person(rng, lang), dateStr(rng), "—", "—", "0", st];
      }
      const inH = st === "late" ? 9 : count(rng, 7, 8);
      const inM = padded(Math.floor(rng() * 12) * 5, 2);
      const workedMin = Math.round((6.5 + rng() * 3) * 60);
      const total = inH * 60 + Number(inM) + workedMin;
      return [
        recordCode("TMC", 73000 + i),
        person(rng, lang),
        dateStr(rng),
        `${padded(inH, 2)}:${inM}`,
        `${padded(Math.floor(total / 60), 2)}:${padded(total % 60, 2)}`,
        (workedMin / 60).toFixed(1),
        st,
      ];
    },
    count: [20, 30],
  },

  /* البطولات */
  tournaments: {
    cols: [
      { key: "code", ar: "رقم البطولة", en: "Tournament #", kind: "id" },
      { key: "tournament", ar: "البطولة", en: "Tournament", kind: "text" },
      { key: "game", ar: "اللعبة / الرياضة", en: "Game / sport", kind: "text" },
      { key: "teams", ar: "عدد الفرق", en: "Teams", kind: "num" },
      { key: "prize", ar: "قيمة الجوائز", en: "Prize pool", kind: "money" },
      { key: "date", ar: "تاريخ الانطلاق", en: "Starts", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "completed", ar: "اكتملت", en: "Completed", tone: "emerald" },
      { key: "ongoing", ar: "جارية", en: "Ongoing", tone: "violet" },
      { key: "registration", ar: "التسجيل مفتوح", en: "Registration open", tone: "amber" },
      { key: "upcoming", ar: "قادمة", en: "Upcoming", tone: "sky" },
      { key: "cancelled", ar: "ملغاة", en: "Cancelled", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["completed", "completed", "completed", "ongoing", "registration", "upcoming", "cancelled"]);
      const teams = count(rng, 4, 32);
      const prize = Math.round((teams * money(rng, 450, 5200)) * 100) / 100;
      return [
        recordCode("TNT", 73500 + i),
        lang === "ar" ? pick(rng, AR_TOURNAMENTS) : pick(rng, EN_TOURNAMENTS),
        lang === "ar" ? pick(rng, AR_GAMES) : pick(rng, EN_GAMES),
        String(teams),
        prize.toFixed(2),
        dateStr(rng),
        st,
      ];
    },
    count: [14, 22],
    moneyKey: "prize",
  },

  /* الجلسات */
  sessions: {
    cols: [
      { key: "code", ar: "رقم الجلسة", en: "Session #", kind: "id" },
      { key: "session", ar: "الجلسة", en: "Session", kind: "text" },
      { key: "coach", ar: "المدرب", en: "Coach", kind: "text" },
      { key: "players", ar: "عدد اللاعبين", en: "Players", kind: "num" },
      { key: "duration", ar: "المدة (دقيقة)", en: "Duration (min)", kind: "num" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "completed", ar: "أقيمت", en: "Completed", tone: "emerald" },
      { key: "scheduled", ar: "مجدولة", en: "Scheduled", tone: "sky" },
      { key: "rescheduled", ar: "أُعيد جدولتها", en: "Rescheduled", tone: "amber" },
      { key: "cancelled", ar: "ملغاة", en: "Cancelled", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      recordCode("SNS", 74000 + i),
      lang === "ar" ? pick(rng, AR_SESSIONS) : pick(rng, EN_SESSIONS),
      person(rng, lang),
      String(count(rng, 4, 24)),
      String(count(rng, 30, 120)),
      dateStr(rng),
      pick(rng, ["completed", "completed", "completed", "completed", "scheduled", "rescheduled", "cancelled"]),
    ],
    count: [16, 28],
  },

  /* القضايا */
  cases: {
    cols: [
      { key: "code", ar: "رقم القضية", en: "Case #", kind: "id" },
      { key: "case", ar: "موضوع القضية", en: "Subject", kind: "text" },
      { key: "client", ar: "الموكّل", en: "Client", kind: "text" },
      { key: "type", ar: "نوع الدعوى", en: "Case type", kind: "text" },
      { key: "court", ar: "المحكمة", en: "Court", kind: "text" },
      { key: "filed", ar: "تاريخ قيد الدعوى", en: "Filed", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "closed", ar: "فُصلت", en: "Closed", tone: "emerald" },
      { key: "active", ar: "نشطة", en: "Active", tone: "sky" },
      { key: "suspended", ar: "موقوفة", en: "Suspended", tone: "amber" },
      { key: "appealed", ar: "مستأنفة", en: "Appealed", tone: "violet" },
      { key: "dismissed", ar: "مرفوضة", en: "Dismissed", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      recordCode("CAS", 74500 + i),
      lang === "ar" ? pick(rng, AR_CASE_SUBJECTS) : pick(rng, EN_CASE_SUBJECTS),
      person(rng, lang),
      lang === "ar" ? pick(rng, AR_CASE_TYPES) : pick(rng, EN_CASE_TYPES),
      lang === "ar" ? pick(rng, AR_COURTS) : pick(rng, EN_COURTS),
      dateStr(rng),
      pick(rng, ["closed", "closed", "closed", "active", "active", "suspended", "appealed", "dismissed"]),
    ],
    count: [16, 28],
  },

  /* الجلسات القضائية */
  hearings: {
    cols: [
      { key: "code", ar: "رقم الجلسة", en: "Hearing #", kind: "id" },
      { key: "case", ar: "القضية", en: "Case", kind: "text" },
      { key: "court", ar: "المحكمة", en: "Court", kind: "text" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "time", ar: "الوقت", en: "Time", kind: "text" },
      { key: "judge", ar: "القاضي", en: "Judge", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "held", ar: "انعقدت", en: "Held", tone: "emerald" },
      { key: "upcoming", ar: "قادمة", en: "Upcoming", tone: "sky" },
      { key: "postponed", ar: "أُجّلت", en: "Postponed", tone: "amber" },
      { key: "cancelled", ar: "ألغيت", en: "Cancelled", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      recordCode("HRS", 75000 + i),
      lang === "ar" ? pick(rng, AR_CASE_SUBJECTS) : pick(rng, EN_CASE_SUBJECTS),
      lang === "ar" ? pick(rng, AR_COURTS) : pick(rng, EN_COURTS),
      dateStr(rng),
      timeStr(rng),
      lang === "ar" ? `القاضي ${person(rng, lang)}` : `Judge ${person(rng, lang)}`,
      pick(rng, ["held", "held", "held", "held", "upcoming", "postponed", "cancelled"]),
    ],
    count: [16, 26],
  },

  /* تتبع الوقت */
  timetracking: {
    cols: [
      { key: "code", ar: "رقم القيد", en: "Entry #", kind: "id" },
      { key: "matter", ar: "الملف / المشروع", en: "Matter / project", kind: "text" },
      { key: "member", ar: "عضو الفريق", en: "Team member", kind: "text" },
      { key: "task", ar: "المهمة", en: "Task", kind: "text" },
      { key: "hours", ar: "الساعات", en: "Hours", kind: "num" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "billable", ar: "قابل للفوترة", en: "Billable", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "logged", ar: "مسجّل", en: "Logged", tone: "emerald" },
      { key: "approved", ar: "معتمد", en: "Approved", tone: "sky" },
      { key: "invoiced", ar: "مفوتر", en: "Invoiced", tone: "violet" },
      { key: "draft", ar: "مسودة", en: "Draft", tone: "amber" },
      { key: "rejected", ar: "مرفوض", en: "Rejected", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      recordCode("TTK", 75500 + i),
      lang === "ar" ? pick(rng, AR_MATTERS) : pick(rng, EN_MATTERS),
      person(rng, lang),
      lang === "ar" ? pick(rng, AR_TT_TASKS) : pick(rng, EN_TT_TASKS),
      (1 + rng() * 7.5).toFixed(1),
      dateStr(rng),
      yesNo(rng, lang),
      pick(rng, ["logged", "logged", "logged", "approved", "approved", "invoiced", "draft", "rejected"]),
    ],
    count: [18, 30],
  },

  /* المواعيد النهائية */
  deadlines: {
    cols: [
      { key: "code", ar: "رقم الموعد", en: "Deadline #", kind: "id" },
      { key: "matter", ar: "الملف / المشروع", en: "Matter / project", kind: "text" },
      { key: "type", ar: "النوع", en: "Type", kind: "text" },
      { key: "due", ar: "تاريخ الاستحقاق", en: "Due", kind: "date" },
      { key: "daysLeft", ar: "الأيام المتبقية", en: "Days left", kind: "num" },
      { key: "owner", ar: "المسؤول", en: "Owner", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "done", ar: "مُنجز", en: "Done", tone: "emerald" },
      { key: "ontrack", ar: "في الوقت", en: "On track", tone: "sky" },
      { key: "duesoon", ar: "قريب", en: "Due soon", tone: "amber" },
      { key: "overdue", ar: "متأخر", en: "Overdue", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["done", "done", "done", "ontrack", "ontrack", "duesoon", "overdue"]);
      const daysLeft =
        st === "done" ? "—" : st === "ontrack" ? String(count(rng, 8, 45)) : st === "duesoon" ? String(count(rng, 0, 7)) : String(-count(rng, 1, 30));
      return [
        recordCode("DDL", 76000 + i),
        lang === "ar" ? pick(rng, AR_MATTERS) : pick(rng, EN_MATTERS),
        lang === "ar" ? pick(rng, AR_DEADLINE_TYPES) : pick(rng, EN_DEADLINE_TYPES),
        dateStr(rng),
        daysLeft,
        person(rng, lang),
        st,
      ];
    },
    count: [16, 26],
  },

  /* التبرعات */
  donations: {
    cols: [
      { key: "code", ar: "رقم التبرع", en: "Donation #", kind: "id" },
      { key: "donor", ar: "المتبرع", en: "Donor", kind: "text" },
      { key: "amount", ar: "المبلغ", en: "Amount", kind: "money" },
      { key: "method", ar: "طريقة الدفع", en: "Method", kind: "text" },
      { key: "campaign", ar: "الحملة", en: "Campaign", kind: "text" },
      { key: "date", ar: "تاريخ التبرع", en: "Date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "received", ar: "تم استلامه", en: "Received", tone: "emerald" },
      { key: "pledged", ar: "تعهد", en: "Pledged", tone: "sky" },
      { key: "processing", ar: "قيد المعالجة", en: "Processing", tone: "amber" },
      { key: "refunded", ar: "مسترد", en: "Refunded", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      recordCode("DON", 76500 + i),
      person(rng, lang),
      money(rng, 25, 45000).toFixed(2),
      lang === "ar" ? pick(rng, AR_DON_METHODS) : pick(rng, EN_DON_METHODS),
      lang === "ar" ? pick(rng, AR_DON_CAMPAIGNS) : pick(rng, EN_DON_CAMPAIGNS),
      dateStr(rng),
      pick(rng, ["received", "received", "received", "received", "pledged", "processing", "refunded"]),
    ],
    count: [18, 30],
    moneyKey: "amount",
  },

  /* المتطوعون */
  volunteers: {
    cols: [
      { key: "code", ar: "رقم المتطوع", en: "Volunteer #", kind: "id" },
      { key: "name", ar: "الاسم", en: "Name", kind: "text" },
      { key: "role", ar: "الدور التطوعي", en: "Role", kind: "text" },
      { key: "hours", ar: "ساعات التطوع", en: "Volunteer hours", kind: "num" },
      { key: "since", ar: "متطوع منذ", en: "Volunteering since", kind: "date" },
      { key: "phone", ar: "الجوال", en: "Mobile", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "نشط", en: "Active", tone: "emerald" },
      { key: "new", ar: "جديد", en: "New", tone: "sky" },
      { key: "break", ar: "إجازة مؤقتة", en: "On break", tone: "amber" },
      { key: "inactive", ar: "غير نشط", en: "Inactive", tone: "slate" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["active", "active", "active", "active", "new", "break", "inactive"]);
      const hours = st === "new" ? count(rng, 1, 12) : st === "inactive" ? count(rng, 4, 60) : count(rng, 20, 420);
      return [
        recordCode("VOL", 77000 + i),
        person(rng, lang),
        lang === "ar" ? pick(rng, AR_VOL_ROLES) : pick(rng, EN_VOL_ROLES),
        String(hours),
        dateStr(rng),
        phone(rng),
        st,
      ];
    },
    count: [16, 26],
  },

  /* المستفيدون */
  beneficiaries: {
    cols: [
      { key: "code", ar: "رقم الملف", en: "File #", kind: "id" },
      { key: "name", ar: "المستفيد", en: "Beneficiary", kind: "text" },
      { key: "family", ar: "عدد أفراد الأسرة", en: "Family size", kind: "num" },
      { key: "category", ar: "الفئة", en: "Category", kind: "text" },
      { key: "aid", ar: "نوع الدعم", en: "Aid type", kind: "text" },
      { key: "since", ar: "مستفيد منذ", en: "Beneficiary since", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "receiving", ar: "يتلقى الدعم", en: "Receiving aid", tone: "emerald" },
      { key: "waitlist", ar: "قائمة الانتظار", en: "Waitlist", tone: "amber" },
      { key: "urgent", ar: "حالة عاجلة", en: "Urgent", tone: "rose" },
      { key: "selfsufficient", ar: "اكتفى ذاتياً", en: "Self-sufficient", tone: "sky" },
      { key: "closed", ar: "مغلق الملف", en: "File closed", tone: "slate" },
    ],
    row: (rng, i, lang) => [
      recordCode("BFC", 77500 + i),
      person(rng, lang),
      String(count(rng, 1, 11)),
      lang === "ar" ? pick(rng, AR_BEN_CATEGORIES) : pick(rng, EN_BEN_CATEGORIES),
      lang === "ar" ? pick(rng, AR_AID_TYPES) : pick(rng, EN_AID_TYPES),
      dateStr(rng),
      pick(rng, ["receiving", "receiving", "receiving", "receiving", "waitlist", "urgent", "selfsufficient", "closed"]),
    ],
    count: [18, 30],
  },

  /* جمع التبرعات */
  fundraising: {
    cols: [
      { key: "code", ar: "رقم الحملة", en: "Campaign #", kind: "id" },
      { key: "campaign", ar: "الحملة", en: "Campaign", kind: "text" },
      { key: "goal", ar: "الهدف", en: "Goal", kind: "money" },
      { key: "raised", ar: "المُجمع", en: "Raised", kind: "money" },
      { key: "donors", ar: "عدد المتبرعين", en: "Donors", kind: "num" },
      { key: "end", ar: "تاريخ الانتهاء", en: "Ends", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "achieved", ar: "بلغت الهدف", en: "Goal reached", tone: "emerald" },
      { key: "active", ar: "جارية", en: "Active", tone: "sky" },
      { key: "ending", ar: "قاربت الانتهاء", en: "Ending soon", tone: "amber" },
      { key: "ended", ar: "منتهية", en: "Ended", tone: "slate" },
      { key: "stalled", ar: "متوقفة", en: "Stalled", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["achieved", "achieved", "achieved", "active", "active", "active", "ending", "ended", "stalled"]);
      const goal = money(rng, 50000, 1800000);
      const factor =
        st === "achieved"
          ? 1 + rng() * 0.18
          : st === "ending"
            ? 0.6 + rng() * 0.35
            : st === "ended"
              ? 0.35 + rng() * 0.55
              : st === "stalled"
                ? 0.05 + rng() * 0.2
                : 0.1 + rng() * 0.75;
      const raised = Math.round(goal * factor * 100) / 100;
      return [
        recordCode("FND", 78000 + i),
        lang === "ar" ? pick(rng, AR_FUND_CAMPAIGNS) : pick(rng, EN_FUND_CAMPAIGNS),
        goal.toFixed(2),
        raised.toFixed(2),
        String(count(rng, 12, 2400)),
        dateStr(rng),
        st,
      ];
    },
    count: [14, 24],
    moneyKey: "raised",
  },

  /* التواصل */
  communications: {
    cols: [
      { key: "code", ar: "رقم الرسالة", en: "Message #", kind: "id" },
      { key: "audience", ar: "الجمهور", en: "Audience", kind: "text" },
      { key: "channel", ar: "القناة", en: "Channel", kind: "text" },
      { key: "sent", ar: "عدد المرسل", en: "Sent", kind: "num" },
      { key: "openrate", ar: "معدل الفتح %", en: "Open rate %", kind: "num" },
      { key: "date", ar: "تاريخ الإرسال", en: "Sent", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "sent", ar: "أُرسلت", en: "Sent", tone: "emerald" },
      { key: "scheduled", ar: "مجدولة", en: "Scheduled", tone: "sky" },
      { key: "drafting", ar: "قيد الإعداد", en: "Drafting", tone: "amber" },
      { key: "failed", ar: "فشل الإرسال", en: "Failed", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const ch = pick(rng, COMM_CHANNELS);
      const st = pick(rng, ["sent", "sent", "sent", "sent", "scheduled", "drafting", "failed"]);
      return [
        recordCode("CMC", 78500 + i),
        lang === "ar" ? pick(rng, AR_COMM_AUDIENCES) : pick(rng, EN_COMM_AUDIENCES),
        lang === "ar" ? ch[0] : ch[1],
        String(count(rng, 200, 48000)),
        st === "sent" ? pctStr(rng, ch[2], ch[3]) : "—",
        dateStr(rng),
        st,
      ];
    },
    count: [14, 26],
  },

  /* الأعمال */
  jobs: {
    cols: [
      { key: "code", ar: "رقم العمل", en: "Job #", kind: "id" },
      { key: "job", ar: "نوع العمل", en: "Job type", kind: "text" },
      { key: "client", ar: "العميل", en: "Client", kind: "text" },
      { key: "technician", ar: "الفني", en: "Technician", kind: "text" },
      { key: "priority", ar: "الأولوية", en: "Priority", kind: "text" },
      { key: "fee", ar: "الأجرة", en: "Fee", kind: "money" },
      { key: "date", ar: "تاريخ الطلب", en: "Requested", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "completed", ar: "منجز", en: "Completed", tone: "emerald" },
      { key: "scheduled", ar: "مجدول", en: "Scheduled", tone: "sky" },
      { key: "inprogress", ar: "جاري العمل", en: "In progress", tone: "amber" },
      { key: "cancelled", ar: "ملغى", en: "Cancelled", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const pIdx = pick(rng, [0, 1, 1, 2]);
      const fee = pIdx === 0 ? money(rng, 400, 2600) : pIdx === 1 ? money(rng, 150, 1200) : money(rng, 90, 400);
      return [
        recordCode("JOB", 79000 + i),
        lang === "ar" ? pick(rng, AR_JOB_TYPES) : pick(rng, EN_JOB_TYPES),
        person(rng, lang),
        person(rng, lang),
        lang === "ar" ? AR_PRIORITIES[pIdx] : EN_PRIORITIES[pIdx],
        fee.toFixed(2),
        dateStr(rng),
        pick(rng, ["completed", "completed", "completed", "completed", "scheduled", "scheduled", "inprogress", "cancelled"]),
      ];
    },
    count: [18, 30],
    moneyKey: "fee",
  },

  /* الضمان */
  warranty: {
    cols: [
      { key: "code", ar: "رقم الضمان", en: "Warranty #", kind: "id" },
      { key: "item", ar: "المنتج", en: "Item", kind: "text" },
      { key: "serial", ar: "الرقم التسلسلي", en: "Serial", kind: "text" },
      { key: "client", ar: "العميل", en: "Client", kind: "text" },
      { key: "start", ar: "بداية الضمان", en: "Start", kind: "date" },
      { key: "end", ar: "نهاية الضمان", en: "End", kind: "date" },
      { key: "claims", ar: "عدد المطالبات", en: "Claims", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "ساري", en: "Active", tone: "emerald" },
      { key: "expiring", ar: "قارب الانتهاء", en: "Expiring soon", tone: "amber" },
      { key: "expired", ar: "منتهي", en: "Expired", tone: "slate" },
      { key: "void", ar: "ملغي", en: "Void", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["active", "active", "active", "active", "expiring", "expired", "void"]);
      const start = dateStr(rng);
      const spanDays = st === "expired" ? count(rng, 30, 120) : st === "expiring" ? count(rng, 300, 380) : count(rng, 400, 1095);
      return [
        recordCode("WRN", 79500 + i),
        lang === "ar" ? pick(rng, AR_WARRANTY_ITEMS) : pick(rng, EN_WARRANTY_ITEMS),
        `SN-${padded(count(rng, 1, 999999), 6)}`,
        person(rng, lang),
        start,
        shiftDate(start, spanDays),
        String(count(rng, 0, 4)),
        st,
      ];
    },
    count: [16, 26],
  },

  /* التسعير */
  pricing: {
    cols: [
      { key: "code", ar: "رمز الباقة", en: "Plan #", kind: "id" },
      { key: "plan", ar: "الباقة", en: "Plan", kind: "text" },
      { key: "tier", ar: "دورة الفوترة", en: "Billing tier", kind: "text" },
      { key: "base", ar: "السعر الأساسي", en: "Base price", kind: "money" },
      { key: "discount", ar: "الخصم %", en: "Discount %", kind: "num" },
      { key: "validFrom", ar: "سارية من", en: "Valid from", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "سارية", en: "Active", tone: "emerald" },
      { key: "promo", ar: "عرض ترويجي", en: "Promotional", tone: "sky" },
      { key: "upcoming", ar: "قادمة", en: "Upcoming", tone: "amber" },
      { key: "retired", ar: "موقوفة", en: "Retired", tone: "slate" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["active", "active", "active", "active", "promo", "promo", "upcoming", "retired"]);
      return [
        recordCode("PRC", 80000 + i),
        lang === "ar" ? pick(rng, AR_PRICING_PLANS) : pick(rng, EN_PRICING_PLANS),
        lang === "ar" ? pick(rng, AR_TIERS) : pick(rng, EN_TIERS),
        money(rng, 99, 2900).toFixed(2),
        st === "promo" ? pctStr(rng, 5, 25) : "0.0",
        dateStr(rng),
        st,
      ];
    },
    count: [14, 22],
    moneyKey: "base",
  },
};

export const MEDIA_HR_NPO_CODE_PREFIXES: Record<string, string> = {
  campaigns: "CMP",
  leads: "LED",
  content: "CNT",
  publishing: "PUB",
  analytics: "ANL",
  billing: "BIL",
  creative: "CRE",
  distribution: "DST",
  leaves: "LVE",
  recruitment: "RCR",
  training: "TRA",
  performance: "PRF",
  benefits: "BNF",
  onboarding: "ONB",
  timeclock: "TMC",
  tournaments: "TNT",
  sessions: "SNS",
  cases: "CAS",
  hearings: "HRS",
  timetracking: "TTK",
  deadlines: "DDL",
  donations: "DON",
  volunteers: "VOL",
  beneficiaries: "BFC",
  fundraising: "FND",
  communications: "CMC",
  jobs: "JOB",
  warranty: "WRN",
  pricing: "PRC",
};
