/**
 * Ashrilogic — ROUND 132 domain preset family #2: hospitality, professional
 * services and finance (21 modules).
 *
 * Split out of module-data.ts PRESETS so the flagship registry stays
 * navigable. This file owns the vocabulary for the hospitality family
 * (reservations, kitchen, tables, delivery, events, reviews, housekeeping),
 * the services family (services, scheduling, contracts, reminders,
 * subscriptions, commissions) and the finance family (accounting, taxes,
 * reconciliation, expenses, payroll, bankfeeds, quotations, documents).
 * module-data merges these maps; this file NEVER imports module-data back —
 * preset-kit is the single shared toolkit (person/pick/money/…), so the
 * dependency graph stays acyclic.
 *
 * Demo-code series: one distinct 500-wide band per module inside
 * 31000–41000 (RSV-00031000 … DOC-00041000) — no overlap with the
 * module-data bands, so every record code reads as its own series while
 * nextRecordCode continuity stays per-module.
 */
import {
  count,
  dateStr,
  money,
  padded,
  pctStr,
  person,
  phone,
  pick,
  recordCode,
  timeStr,
  yesNo,
} from "@/lib/module-presets/preset-kit";
import type { ModulePreset } from "@/lib/module-presets/preset-kit";

/* ------------------------------------------------------------------ */
/* shared bilingual pools (used by several finance/services presets)    */
/* ------------------------------------------------------------------ */

const AR_MONTHS = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
const EN_MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const AR_DAYS = ["الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد"];
const EN_DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
const AR_BANKS = ["مصرف الراجحي", "البنك الأهلي السعودي", "بنك الرياض", "بنك ساب", "مصرف الإنماء", "البنك السعودي الفرنسي"];
const EN_BANKS = ["Al Rajhi Bank", "Saudi National Bank", "Riyad Bank", "SAB", "Alinma Bank", "Banque Saudi Fransi"];

/* ------------------------------------------------------------------ */
/* the 21 hospitality + services + finance presets                      */
/* ------------------------------------------------------------------ */

export const HOSP_SVC_FIN_PRESETS: Record<string, ModulePreset> = {
  /* الحجوزات — حجوزات الضيافة مع سعر الليلة وإجمالي الإقامة */
  reservations: {
    cols: [
      { key: "code", ar: "رقم الحجز", en: "Booking #", kind: "id" },
      { key: "guest", ar: "النزيل", en: "Guest", kind: "text" },
      { key: "phone", ar: "الجوال", en: "Mobile", kind: "text" },
      { key: "roomType", ar: "نوع الغرفة", en: "Room type", kind: "text" },
      { key: "nights", ar: "الليالي", en: "Nights", kind: "num" },
      { key: "guests", ar: "عدد الضيوف", en: "Guests", kind: "num" },
      { key: "checkin", ar: "تاريخ الوصول", en: "Check-in", kind: "date" },
      { key: "total", ar: "إجمالي الحجز", en: "Total", kind: "money" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "confirmed", ar: "مؤكد", en: "Confirmed", tone: "emerald" },
      { key: "checkedin", ar: "نزلاء", en: "Checked-in", tone: "sky" },
      { key: "pending", ar: "بانتظار التأكيد", en: "Pending", tone: "amber" },
      { key: "cancelled", ar: "ملغى", en: "Cancelled", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const nights = count(rng, 1, 14);
      const rate = money(rng, 320, 950);
      return [
        recordCode("RSV", 31000 + i),
        person(rng, lang),
        phone(rng),
        lang === "ar"
          ? pick(rng, ["غرفة مفردة", "غرفة مزدوجة", "غرفة ديلوكس", "جناح عائلي", "جناح أعمال", "جناح ملكي"])
          : pick(rng, ["Single room", "Double room", "Deluxe room", "Family suite", "Business suite", "Royal suite"]),
        String(nights),
        String(count(rng, 1, 6)),
        dateStr(rng),
        (Math.round(rate * nights * 100) / 100).toFixed(2),
        pick(rng, ["confirmed", "confirmed", "checkedin", "confirmed", "pending", "cancelled"]),
      ];
    },
    count: [18, 30],
    moneyKey: "total",
  },

  /* المطبخ — تذاكر الشيف بقوائم الأطباق العالمية ودرجات نضج الأستيك */
  kitchen: {
    cols: [
      { key: "code", ar: "رقم التذكرة", en: "Ticket #", kind: "id" },
      { key: "dish", ar: "الطبق الرئيسي", en: "Main dish", kind: "text" },
      { key: "station", ar: "القسم", en: "Station", kind: "text" },
      { key: "items", ar: "البنود", en: "Items", kind: "num" },
      { key: "spec", ar: "المواصفة", en: "Spec", kind: "text" },
      { key: "chef", ar: "الشيف", en: "Chef", kind: "text" },
      { key: "started", ar: "بدء التحضير", en: "Started", kind: "text" },
      { key: "ready", ar: "جاهز عند", en: "Ready by", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "ready", ar: "جاهز", en: "Ready", tone: "emerald" },
      { key: "served", ar: "مُقدَّم", en: "Served", tone: "sky" },
      { key: "preparing", ar: "جارٍ التحضير", en: "Preparing", tone: "amber" },
      { key: "queued", ar: "في الانتظار", en: "Queued", tone: "slate" },
      { key: "delayed", ar: "متأخر", en: "Delayed", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const stations = lang === "ar"
        ? ["الشواية", "الفرن", "المقالي", "السلطات", "الحلويات", "التجهيز"]
        : ["Grill", "Oven", "Fryer", "Garde manger", "Pastry", "Prep"];
      const si = Math.floor(rng() * stations.length);
      const doneness = lang === "ar"
        ? pick(rng, ["نادر", "وسط دموي", "وسط", "وسط جيد", "مطبوخ جيداً"])
        : pick(rng, ["Rare", "Medium rare", "Medium", "Medium well", "Well done"]);
      const mods = lang === "ar"
        ? pick(rng, ["بدون بصل", "صوص جانبي", "إضافة جبن", "بدون مخلل", "حار إضافي"])
        : pick(rng, ["No onions", "Sauce on side", "Extra cheese", "No pickles", "Extra spicy"]);
      const startH = count(rng, 10, 20);
      const startM = Math.floor(rng() * 12) * 5;
      const readyTotal = startH * 60 + startM + count(rng, 8, 42);
      const readyH = Math.min(Math.floor(readyTotal / 60), 23);
      const readyM = readyTotal % 60;
      return [
        recordCode("KCH", 31500 + i),
        lang === "ar"
          ? pick(rng, ["أستيك واجيو", "سلمون مشوي بالأعشاب", "ريزوتو الكمأة", "دجاج تندوري", "كبسة لحم الضأن", "باستا كاربونارا", "برغر أنجوس", "رافيولي السبانخ", "كاري أخضر تايلندي", "مشاوي مشكلة فاخرة"])
          : pick(rng, ["Wagyu steak", "Herb-roasted salmon", "Truffle risotto", "Tandoori chicken", "Lamb kabsa", "Carbonara", "Angus burger", "Spinach ravioli", "Thai green curry", "Premium mixed grill"]),
        stations[si],
        String(count(rng, 1, 12)),
        si === 0 ? doneness : mods,
        person(rng, lang),
        `${padded(startH, 2)}:${padded(startM, 2)}`,
        `${padded(readyH, 2)}:${padded(readyM, 2)}`,
        pick(rng, ["ready", "ready", "ready", "served", "preparing", "preparing", "queued", "delayed"]),
      ];
    },
    count: [16, 26],
  },

  /* الطاولات — خريطة طاولات المطعم بمناطقها وحدود الإنفاق */
  tables: {
    cols: [
      { key: "code", ar: "رقم الطاولة", en: "Table #", kind: "id" },
      { key: "zone", ar: "المنطقة", en: "Zone", kind: "text" },
      { key: "seats", ar: "المقاعد", en: "Seats", kind: "num" },
      { key: "minOrder", ar: "الحد الأدنى للفاتورة", en: "Min spend", kind: "money" },
      { key: "waiter", ar: "النادل", en: "Server", kind: "text" },
      { key: "guests", ar: "الضيوف الحاليون", en: "Current guests", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "occupied", ar: "مشغولة", en: "Occupied", tone: "emerald" },
      { key: "reserved", ar: "محجوزة", en: "Reserved", tone: "violet" },
      { key: "free", ar: "شاغرة", en: "Free", tone: "sky" },
      { key: "cleaning", ar: "تنظيف", en: "Cleaning", tone: "amber" },
      { key: "blocked", ar: "محجوبة", en: "Blocked", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["occupied", "occupied", "occupied", "reserved", "free", "cleaning", "blocked"]);
      const seats = count(rng, 2, 12);
      return [
        recordCode("TBL", 32000 + i),
        lang === "ar"
          ? pick(rng, ["الصالة الرئيسية", "التراس الخارجي", "الجناح الخاص", "البار", "الحديقة", "الطابق العلوي"])
          : pick(rng, ["Main hall", "Outdoor terrace", "Private room", "Bar", "Garden", "Mezzanine"]),
        String(seats),
        money(rng, 0, 850).toFixed(2),
        person(rng, lang),
        st === "occupied" ? String(count(rng, 1, seats)) : "0",
        st,
      ];
    },
    count: [18, 28],
    moneyKey: "minOrder",
  },

  /* التوصيل — مندوبو التوصيل بالأحياء والمسافات والرسوم */
  delivery: {
    cols: [
      { key: "code", ar: "رقم الطلبية", en: "Delivery #", kind: "id" },
      { key: "order", ar: "رقم الطلب", en: "Order", kind: "text" },
      { key: "courier", ar: "المندوب", en: "Courier", kind: "text" },
      { key: "zone", ar: "الحي", en: "District", kind: "text" },
      { key: "km", ar: "المسافة (كم)", en: "Distance (km)", kind: "num" },
      { key: "fee", ar: "رسوم التوصيل", en: "Fee", kind: "money" },
      { key: "eta", ar: "الوصول المتوقع", en: "ETA", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "delivered", ar: "تم التوصيل", en: "Delivered", tone: "emerald" },
      { key: "assigned", ar: "تم التعيين", en: "Assigned", tone: "sky" },
      { key: "onroute", ar: "في الطريق", en: "On route", tone: "amber" },
      { key: "cancelled", ar: "ملغى", en: "Cancelled", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const km = 1.2 + rng() * 17.8;
      const fee = Math.round((10 + km * 1.15) * 100) / 100;
      return [
        recordCode("DLV", 32500 + i),
        `ORD-${padded(25200 + i, 8)}`,
        person(rng, lang),
        lang === "ar"
          ? pick(rng, ["حي النخيل", "حي الملقا", "وسط المدينة", "حي الياسمين", "الحي الدبلوماسي", "حي القادسية"])
          : pick(rng, ["Al Nakheel", "Al Malqa", "Downtown", "Al Yasmin", "Diplomatic Quarter", "Al Qadisiyah"]),
        km.toFixed(1),
        fee.toFixed(2),
        timeStr(rng),
        pick(rng, ["delivered", "delivered", "delivered", "onroute", "assigned", "cancelled"]),
      ];
    },
    count: [18, 30],
    moneyKey: "fee",
  },

  /* المناسبات — المناسبات والقاعات وقوائم الطعام والميزانيات */
  events: {
    cols: [
      { key: "code", ar: "رقم المناسبة", en: "Event #", kind: "id" },
      { key: "name", ar: "المناسبة", en: "Event", kind: "text" },
      { key: "venue", ar: "القاعة", en: "Venue", kind: "text" },
      { key: "menu", ar: "قائمة الطعام", en: "Menu", kind: "text" },
      { key: "guests", ar: "عدد المدعوين", en: "Guests", kind: "num" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "budget", ar: "الميزانية", en: "Budget", kind: "money" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "confirmed", ar: "مؤكدة", en: "Confirmed", tone: "emerald" },
      { key: "completed", ar: "منتهية", en: "Completed", tone: "sky" },
      { key: "planning", ar: "قيد التخطيط", en: "Planning", tone: "amber" },
      { key: "cancelled", ar: "ملغاة", en: "Cancelled", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const guests = count(rng, 40, 600);
      const perGuest = money(rng, 260, 850);
      return [
        recordCode("EVT", 33000 + i),
        lang === "ar"
          ? pick(rng, ["حفل زفاف", "مؤتمر تقني", "حفل تخرج", "معرض تجاري", "حفل عشاء فاخر", "ورشة عمل", "حفل خطوبة", "اجتماع مجلس إدارة"])
          : pick(rng, ["Wedding reception", "Tech conference", "Graduation gala", "Trade exhibition", "Gala dinner", "Workshop", "Engagement party", "Board meeting"]),
        lang === "ar"
          ? pick(rng, ["قاعة الماس", "قاعة الياسمين", "مركز المؤتمرات", "قاعة اللؤلؤ", "حديقة الفيصلية", "استراحة الواحة"])
          : pick(rng, ["Diamond Hall", "Jasmine Hall", "Convention Center", "Pearl Hall", "Faisaliah Garden", "Oasis Resort"]),
        lang === "ar"
          ? pick(rng, ["بوفيه مفتوح", "قائمة ثلاثية الأطباق", "عشاء فاخر جالس", "حلويات ومشروبات", "قائمة تذوق مخصصة"])
          : pick(rng, ["Open buffet", "Three-course set menu", "Seated gala dinner", "Desserts & beverages", "Custom tasting menu"]),
        String(guests),
        dateStr(rng),
        (Math.round(guests * perGuest * 100) / 100).toFixed(2),
        pick(rng, ["confirmed", "confirmed", "confirmed", "completed", "planning", "cancelled"]),
      ];
    },
    count: [14, 24],
    moneyKey: "budget",
  },

  /* التقييمات — مراجعات القنوات مع التقييم والتعليقات */
  reviews: {
    cols: [
      { key: "code", ar: "رقم التقييم", en: "Review #", kind: "id" },
      { key: "reviewer", ar: "المقيم", en: "Reviewer", kind: "text" },
      { key: "channel", ar: "القناة", en: "Channel", kind: "text" },
      { key: "rating", ar: "التقييم", en: "Rating", kind: "num" },
      { key: "comment", ar: "التعليق", en: "Comment", kind: "text" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "published", ar: "منشور", en: "Published", tone: "emerald" },
      { key: "pending", ar: "قيد الإشراف", en: "Pending", tone: "amber" },
      { key: "flagged", ar: "مُبلَّغ عنه", en: "Flagged", tone: "rose" },
      { key: "archived", ar: "مؤرشف", en: "Archived", tone: "slate" },
    ],
    row: (rng, i, lang) => [
      recordCode("REV", 33500 + i),
      person(rng, lang),
      lang === "ar"
        ? pick(rng, ["قوقل", "إنستقرام", "فيسبوك", "تويتر X", "TripAdvisor", "استبيان مباشر"])
        : pick(rng, ["Google", "Instagram", "Facebook", "X", "TripAdvisor", "Direct survey"]),
      String(pick(rng, [5, 5, 4, 4, 4, 5, 3, 4, 2, 1])),
      lang === "ar"
        ? pick(rng, ["خدمة ممتازة وتجربة لا تُنسى", "الطعم رائع والمكان هادئ", "التوصيل تأخر قليلاً", "النظافة على مستوى عالٍ", "قيمة ممتازة مقابل السعر", "يحتاج تحسين سرعة الاستجابة"])
        : pick(rng, ["Outstanding service, unforgettable experience", "Great taste and a calm ambiance", "Delivery arrived slightly late", "Spotless cleanliness", "Excellent value for the price", "Response speed could improve"]),
      dateStr(rng),
      pick(rng, ["published", "published", "published", "pending", "flagged", "archived"]),
    ],
    count: [16, 28],
  },

  /* التدبير المنزلي — مهام الغرف وورديات التنظيف */
  housekeeping: {
    cols: [
      { key: "code", ar: "رقم المهمة", en: "Task #", kind: "id" },
      { key: "room", ar: "الغرفة", en: "Room", kind: "text" },
      { key: "task", ar: "نوع المهمة", en: "Task", kind: "text" },
      { key: "staff", ar: "الموظف", en: "Staff", kind: "text" },
      { key: "shift", ar: "الوردية", en: "Shift", kind: "text" },
      { key: "minutes", ar: "المدة (دقيقة)", en: "Minutes", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "done", ar: "مكتملة", en: "Done", tone: "emerald" },
      { key: "inspected", ar: "مفحوصة", en: "Inspected", tone: "violet" },
      { key: "inprogress", ar: "جارية", en: "In progress", tone: "amber" },
      { key: "scheduled", ar: "مجدولة", en: "Scheduled", tone: "sky" },
      { key: "escalated", ar: "تحتاج متابعة", en: "Escalated", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      recordCode("HPK", 34000 + i),
      `${Math.floor(i / 10) + 1}${padded((i % 10) + 1, 2)}`,
      lang === "ar"
        ? pick(rng, ["تنظيف كامل", "تجديد الفرش", "تعقيم الحمام", "تنظيف جاف", "ترتيب مسائي", "تلميع الأرضيات"])
        : pick(rng, ["Full turnover", "Linen change", "Bathroom sanitization", "Dry cleaning", "Evening turndown", "Floor polishing"]),
      person(rng, lang),
      lang === "ar" ? pick(rng, ["صباحية", "مسائية", "ليلية"]) : pick(rng, ["Morning", "Evening", "Night"]),
      String(count(rng, 15, 95)),
      pick(rng, ["done", "done", "done", "inspected", "inprogress", "scheduled", "escalated"]),
    ],
    count: [16, 26],
  },

  /* الخدمات — كتالوج الخدمات بالأسعار والمدة والحجز الفوري */
  services: {
    cols: [
      { key: "code", ar: "رقم الخدمة", en: "Service #", kind: "id" },
      { key: "service", ar: "الخدمة", en: "Service", kind: "text" },
      { key: "category", ar: "التصنيف", en: "Category", kind: "text" },
      { key: "minutes", ar: "المدة (دقيقة)", en: "Duration (min)", kind: "num" },
      { key: "price", ar: "السعر", en: "Price", kind: "money" },
      { key: "provider", ar: "مقدم الخدمة", en: "Provider", kind: "text" },
      { key: "instant", ar: "حجز فوري", en: "Instant booking", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "متاحة", en: "Active", tone: "emerald" },
      { key: "seasonal", ar: "موسمية", en: "Seasonal", tone: "violet" },
      { key: "paused", ar: "موقوفة", en: "Paused", tone: "amber" },
      { key: "archived", ar: "مؤرشفة", en: "Archived", tone: "slate" },
    ],
    row: (rng, i, lang) => [
      recordCode("SVC", 34500 + i),
      lang === "ar"
        ? pick(rng, ["تنظيف جاف VIP", "مساج استرخائي", "باقة حلاقة فاخرة", "روتين سبا متكامل", "خدمة الكونسيرج", "تلميع وتفصيل سيارة", "تدريب شخصي", "تنسيق حدائق", "تصوير احترافي"])
        : pick(rng, ["VIP dry cleaning", "Relaxing massage", "Premium barber package", "Full spa ritual", "Concierge service", "Car detailing", "Personal training", "Gardening & landscaping", "Professional photography"]),
      lang === "ar"
        ? pick(rng, ["عناية شخصية", "صيانة", "ترفيه", "ضيافة", "لياقة", "أعمال"])
        : pick(rng, ["Personal care", "Maintenance", "Leisure", "Hospitality", "Fitness", "Business"]),
      String(count(rng, 30, 180)),
      money(rng, 45, 1200).toFixed(2),
      person(rng, lang),
      yesNo(rng, lang),
      pick(rng, ["active", "active", "active", "seasonal", "paused", "archived"]),
    ],
    count: [14, 24],
    moneyKey: "price",
  },

  /* الجدولة — جداول ورديات الموظفين بالساعات والتغطية */
  scheduling: {
    cols: [
      { key: "code", ar: "رقم الجدولة", en: "Roster #", kind: "id" },
      { key: "staff", ar: "الموظف", en: "Staff", kind: "text" },
      { key: "shift", ar: "الوردية", en: "Shift", kind: "text" },
      { key: "day", ar: "اليوم", en: "Day", kind: "text" },
      { key: "start", ar: "البداية", en: "Start", kind: "text" },
      { key: "end", ar: "النهاية", en: "End", kind: "text" },
      { key: "hours", ar: "الساعات", en: "Hours", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "confirmed", ar: "مؤكدة", en: "Confirmed", tone: "emerald" },
      { key: "scheduled", ar: "مجدولة", en: "Scheduled", tone: "sky" },
      { key: "swapped", ar: "مُبدَّلة", en: "Swapped", tone: "amber" },
      { key: "open", ar: "غير مغطاة", en: "Open", tone: "rose" },
      { key: "leave", ar: "إجازة", en: "Leave", tone: "slate" },
    ],
    row: (rng, i, lang) => {
      const startH = count(rng, 6, 18);
      const endH = Math.min(startH + count(rng, 4, 9), 23);
      const shifts = lang === "ar" ? ["صباحية", "مسائية", "ليلية"] : ["Morning", "Evening", "Night"];
      const si = startH < 12 ? 0 : startH < 17 ? 1 : 2;
      return [
        recordCode("SCH", 35000 + i),
        person(rng, lang),
        shifts[si],
        lang === "ar" ? pick(rng, AR_DAYS) : pick(rng, EN_DAYS),
        `${padded(startH, 2)}:${padded(Math.floor(rng() * 12) * 5, 2)}`,
        `${padded(endH, 2)}:${padded(Math.floor(rng() * 12) * 5, 2)}`,
        String(endH - startH),
        pick(rng, ["confirmed", "confirmed", "confirmed", "scheduled", "swapped", "open", "leave"]),
      ];
    },
    count: [18, 30],
  },

  /* العقود — العقود السارية والقيم وتواريخ التجديد */
  contracts: {
    cols: [
      { key: "code", ar: "رقم العقد", en: "Contract #", kind: "id" },
      { key: "client", ar: "العميل", en: "Client", kind: "text" },
      { key: "type", ar: "النوع", en: "Type", kind: "text" },
      { key: "value", ar: "القيمة", en: "Value", kind: "money" },
      { key: "start", ar: "تاريخ البدء", en: "Start", kind: "date" },
      { key: "end", ar: "تاريخ الانتهاء", en: "End", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "ساري", en: "Active", tone: "emerald" },
      { key: "renewed", ar: "مُجدد", en: "Renewed", tone: "sky" },
      { key: "expiring", ar: "قارب الانتهاء", en: "Expiring", tone: "amber" },
      { key: "expired", ar: "منتهي", en: "Expired", tone: "slate" },
      { key: "terminated", ar: "مفسخ", en: "Terminated", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      recordCode("CTR", 35500 + i),
      person(rng, lang),
      lang === "ar"
        ? pick(rng, ["سنوي", "دعم فني", "اشتراك", "صيانة دورية", "مشروع محدد", "إطاري"])
        : pick(rng, ["Annual", "Support", "Subscription", "Recurring maintenance", "Fixed project", "Framework"]),
      money(rng, 18000, 520000).toFixed(2),
      dateStr(rng),
      dateStr(rng),
      pick(rng, ["active", "active", "active", "renewed", "expiring", "expired", "terminated"]),
    ],
    count: [16, 28],
    moneyKey: "value",
  },

  /* التذكيرات — تذكيرات العملاء عبر القنوات بمواعيد الاستحقاق */
  reminders: {
    cols: [
      { key: "code", ar: "رقم التذكير", en: "Reminder #", kind: "id" },
      { key: "subject", ar: "الموضوع", en: "Subject", kind: "text" },
      { key: "channel", ar: "القناة", en: "Channel", kind: "text" },
      { key: "dueDate", ar: "تاريخ الاستحقاق", en: "Due date", kind: "date" },
      { key: "dueTime", ar: "وقت الاستحقاق", en: "Due time", kind: "text" },
      { key: "recipient", ar: "المستلم", en: "Recipient", kind: "text" },
      { key: "phone", ar: "الجوال", en: "Mobile", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "sent", ar: "مُرسل", en: "Sent", tone: "emerald" },
      { key: "scheduled", ar: "مجدول", en: "Scheduled", tone: "sky" },
      { key: "queued", ar: "في الانتظار", en: "Queued", tone: "amber" },
      { key: "failed", ar: "فاشل", en: "Failed", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      recordCode("RMD", 36000 + i),
      lang === "ar"
        ? pick(rng, ["موعد سداد الفاتورة", "تجديد الاشتراك", "متابعة صيانة", "تأكيد الموعد", "استبيان رضا العميل", "موعد تسليم الطلب", "تجديد الرخصة التجارية"])
        : pick(rng, ["Invoice payment due", "Subscription renewal", "Maintenance follow-up", "Appointment confirmation", "Satisfaction survey", "Order handover", "Trade license renewal"]),
      lang === "ar"
        ? pick(rng, ["رسالة نصية", "بريد إلكتروني", "واتساب"])
        : pick(rng, ["SMS", "Email", "WhatsApp"]),
      dateStr(rng),
      timeStr(rng),
      person(rng, lang),
      phone(rng),
      pick(rng, ["sent", "sent", "sent", "scheduled", "queued", "failed"]),
    ],
    count: [16, 26],
  },

  /* الاشتراكات — اشتراكات العملاء بالخطط ودورات التجديد */
  subscriptions: {
    cols: [
      { key: "code", ar: "رقم الاشتراك", en: "Subscription #", kind: "id" },
      { key: "customer", ar: "العميل", en: "Customer", kind: "text" },
      { key: "plan", ar: "الخطة", en: "Plan", kind: "text" },
      { key: "cycle", ar: "دورة الفوترة", en: "Billing cycle", kind: "text" },
      { key: "price", ar: "السعر", en: "Price", kind: "money" },
      { key: "renewal", ar: "تاريخ التجديد", en: "Renewal", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "نشط", en: "Active", tone: "emerald" },
      { key: "trial", ar: "تجريبي", en: "Trial", tone: "violet" },
      { key: "expiring", ar: "قارب الانتهاء", en: "Expiring", tone: "amber" },
      { key: "suspended", ar: "موقوف", en: "Suspended", tone: "rose" },
      { key: "cancelled", ar: "ملغى", en: "Cancelled", tone: "slate" },
    ],
    row: (rng, i, lang) => [
      recordCode("SUB", 36500 + i),
      person(rng, lang),
      lang === "ar"
        ? pick(rng, ["أساسية", "احترافية", "ممتازة", "شركات"])
        : pick(rng, ["Basic", "Professional", "Premium", "Enterprise"]),
      lang === "ar"
        ? pick(rng, ["شهري", "ربع سنوي", "سنوي"])
        : pick(rng, ["Monthly", "Quarterly", "Annual"]),
      money(rng, 95, 4800).toFixed(2),
      dateStr(rng),
      pick(rng, ["active", "active", "active", "trial", "expiring", "suspended", "cancelled"]),
    ],
    count: [16, 28],
    moneyKey: "price",
  },

  /* العمولات — عمولات المفوضين بوعاء العمولة والنسب والمبالغ */
  commissions: {
    cols: [
      { key: "code", ar: "رقم العمولة", en: "Commission #", kind: "id" },
      { key: "agent", ar: "المفوض", en: "Agent", kind: "text" },
      { key: "source", ar: "المصدر", en: "Source", kind: "text" },
      { key: "base", ar: "وعاء العمولة", en: "Base", kind: "money" },
      { key: "rate", ar: "النسبة %", en: "Rate %", kind: "num" },
      { key: "amount", ar: "العمولة", en: "Amount", kind: "money" },
      { key: "period", ar: "الفترة", en: "Period", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "paid", ar: "مدفوعة", en: "Paid", tone: "emerald" },
      { key: "approved", ar: "معتمدة", en: "Approved", tone: "sky" },
      { key: "pending", ar: "قيد الاحتساب", en: "Pending", tone: "amber" },
      { key: "disputed", ar: "محل نزاع", en: "Disputed", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const base = money(rng, 8500, 96000);
      const rate = pctStr(rng, 2, 12);
      const amount = Math.round((base * Number(rate)) / 100) / 100;
      return [
        recordCode("COM", 37000 + i),
        person(rng, lang),
        lang === "ar"
          ? pick(rng, ["مبيعات مباشرة", "اشتراكات", "عقود سنوية", "حزم ترويجية", "تحويل عملاء"])
          : pick(rng, ["Direct sales", "Subscriptions", "Annual contracts", "Promo bundles", "Referrals"]),
        base.toFixed(2),
        rate,
        amount.toFixed(2),
        lang === "ar" ? pick(rng, AR_MONTHS) : pick(rng, EN_MONTHS),
        pick(rng, ["paid", "paid", "paid", "approved", "pending", "disputed"]),
      ];
    },
    count: [16, 26],
    moneyKey: "amount",
  },

  /* المحاسبة — القيود اليومية بين المدين والدائن */
  accounting: {
    cols: [
      { key: "code", ar: "رقم القيد", en: "Entry #", kind: "id" },
      { key: "entry", ar: "وصف القيد", en: "Description", kind: "text" },
      { key: "account", ar: "الحساب", en: "Account", kind: "text" },
      { key: "debit", ar: "مدين", en: "Debit", kind: "money" },
      { key: "credit", ar: "دائن", en: "Credit", kind: "money" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "posted", ar: "مسجل", en: "Posted", tone: "emerald" },
      { key: "reviewed", ar: "مراجع", en: "Reviewed", tone: "sky" },
      { key: "draft", ar: "مسودة", en: "Draft", tone: "amber" },
      { key: "voided", ar: "ملغى", en: "Voided", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const amount = money(rng, 500, 85000);
      const isDebit = rng() > 0.5;
      return [
        recordCode("ACC", 37500 + i),
        lang === "ar"
          ? pick(rng, ["قيد مبيعات يومي", "قيد مشتريات", "قيد رواتب", "قيد إهلاك", "قيد تسوية", "قيد إيراد تأجير", "قيد مصروفات تشغيل"])
          : pick(rng, ["Daily sales entry", "Purchases entry", "Payroll entry", "Depreciation entry", "Adjustment entry", "Rental revenue entry", "Operating expense entry"]),
        lang === "ar"
          ? pick(rng, ["النقد والبنك", "المدينون", "الأصول الثابتة", "الدائنون", "الإيرادات", "مصروفات التشغيل", "ضريبة القيمة المضافة المستحقة", "رأس المال"])
          : pick(rng, ["Cash & bank", "Receivables", "Fixed assets", "Payables", "Revenue", "Operating expenses", "VAT payable", "Equity"]),
        isDebit ? amount.toFixed(2) : "0.00",
        isDebit ? "0.00" : amount.toFixed(2),
        dateStr(rng),
        pick(rng, ["posted", "posted", "posted", "reviewed", "draft", "voided"]),
      ];
    },
    count: [16, 28],
    moneyKey: "debit",
  },

  /* الضرائب — إقرارات ضريبة القيمة المضافة 15% والاستقطاع */
  taxes: {
    cols: [
      { key: "code", ar: "رقم الإقرار", en: "Filing #", kind: "id" },
      { key: "period", ar: "الفترة", en: "Period", kind: "text" },
      { key: "type", ar: "نوع الضريبة", en: "Tax type", kind: "text" },
      { key: "due", ar: "الضريبة المستحقة", en: "Due", kind: "money" },
      { key: "paid", ar: "المسدد", en: "Paid", kind: "money" },
      { key: "filingDate", ar: "تاريخ التقديم", en: "Filed on", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "paid", ar: "مسدد", en: "Paid", tone: "emerald" },
      { key: "filed", ar: "مقدم", en: "Filed", tone: "sky" },
      { key: "partial", ar: "سداد جزئي", en: "Partial", tone: "amber" },
      { key: "overdue", ar: "متأخر", en: "Overdue", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["paid", "paid", "filed", "partial", "overdue"]);
      const due = money(rng, 3200, 185000);
      const paidAmt = st === "paid" ? due : st === "partial" ? Math.round(due * 45) / 100 : 0;
      return [
        recordCode("TAX", 38000 + i),
        lang === "ar" ? `${pick(rng, AR_MONTHS)} 2026` : `${pick(rng, EN_MONTHS)} 2026`,
        lang === "ar"
          ? pick(rng, ["ضريبة القيمة المضافة 15%", "ضريبة الاستقطاع", "الضريبة الانتقائية"])
          : pick(rng, ["VAT 15%", "Withholding tax", "Excise tax"]),
        due.toFixed(2),
        paidAmt.toFixed(2),
        dateStr(rng),
        st,
      ];
    },
    count: [14, 24],
    moneyKey: "due",
  },

  /* التسويات — التسويات البنكية ومطابقة الكشوف */
  reconciliation: {
    cols: [
      { key: "code", ar: "رقم التسوية", en: "Rec #", kind: "id" },
      { key: "statement", ar: "الكشف", en: "Statement", kind: "text" },
      { key: "bank", ar: "البنك", en: "Bank", kind: "text" },
      { key: "matched", ar: "عمليات مطابقة", en: "Matched", kind: "num" },
      { key: "unmatched", ar: "غير مطابقة", en: "Unmatched", kind: "num" },
      { key: "amount", ar: "مبلغ التسوية", en: "Amount", kind: "money" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "reconciled", ar: "مسوّاة", en: "Reconciled", tone: "emerald" },
      { key: "inprogress", ar: "جارية المطابقة", en: "In progress", tone: "amber" },
      { key: "review", ar: "مراجعة الفروقات", en: "Review diffs", tone: "violet" },
      { key: "open", ar: "فروقات مفتوحة", en: "Open", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const matched = count(rng, 40, 320);
      const unmatched = count(rng, 0, 14);
      return [
        recordCode("REC", 38500 + i),
        lang === "ar" ? `كشف ${pick(rng, AR_MONTHS)} 2026` : `${pick(rng, EN_MONTHS)} 2026 statement`,
        lang === "ar" ? pick(rng, AR_BANKS) : pick(rng, EN_BANKS),
        String(matched),
        String(unmatched),
        money(rng, 25000, 480000).toFixed(2),
        dateStr(rng),
        pick(rng, ["reconciled", "reconciled", "inprogress", "review", "open"]),
      ];
    },
    count: [14, 22],
    moneyKey: "amount",
  },

  /* المصروفات — سجل المصروفات البسيط والمستقل (the owner's directive:
   * «احذف الصفحة كاملة وأعد تطويرها بطريقة بسيطة وجذابة وPremium تخص فقط
   * المنصرفات مع إمكانية رفع صورة للإيصال اختياري بدقة»). The complex
   * financial breakdown is GONE (no vendor · invoiceRef · gross · tax ·
   * net · recurring) — the module now tracks ONLY what an expense actually
   * is: code · title · category · amount · date · method · notes · status
   * (8 cols, down from 12). The optional receipt image rides the record's
   * existing imageRef field (uploaded in the add/edit dialog) — the preset
   * carries no column for it because the photo is metadata, not a column
   * value. Three simple statuses (paid · pending · cancelled) replace the
   * 4-state approval workflow. moneyKey is `amount` (the single outlay). */
  expenses: {
    cols: [
      { key: "code", ar: "رقم المصروف", en: "Expense #", kind: "id" },
      { key: "title", ar: "البند", en: "Title", kind: "text" },
      { key: "category", ar: "التصنيف", en: "Category", kind: "text" },
      { key: "amount", ar: "المبلغ", en: "Amount", kind: "money" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "method", ar: "طريقة الدفع", en: "Payment Method", kind: "text" },
      { key: "notes", ar: "ملاحظات", en: "Notes", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "paid", ar: "مدفوع", en: "Paid", tone: "emerald" },
      { key: "pending", ar: "معلّق", en: "Pending", tone: "amber" },
      { key: "cancelled", ar: "ملغى", en: "Cancelled", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      /* one vocabulary per category — the demo row's title and category
       * always agree (the owner's «بطريقة دقيقة جداً»). */
      const cats = lang === "ar"
        ? ["رواتب", "إيجار", "مرافق", "صيانة", "مشتريات", "تسويق", "ضرائب", "أخرى"]
        : ["Salaries", "Rent", "Utilities", "Maintenance", "Purchases", "Marketing", "Taxes", "Other"];
      const titles = lang === "ar"
        ? ["راتب الموظفين", "فاتورة الكهرباء", "إيجار المكتب", "صيانة دورية", "مشتريات مكتبية", "حملة تسويقية", "ضريبة القيمة المضافة", "مصروفات متنوعة"]
        : ["Staff salary", "Electricity bill", "Office rent", "Periodic maintenance", "Office supplies", "Marketing campaign", "VAT payment", "Miscellaneous"];
      const idx = Math.floor(rng() * cats.length);
      return [
        recordCode("EXP", 39000 + i),
        titles[idx],
        cats[idx],
        money(rng, 100, 15000).toFixed(2),
        dateStr(rng),
        pick(rng, lang === "ar" ? ["نقداً", "تحويل بنكي", "بطاقة"] : ["Cash", "Bank transfer", "Card"]),
        rng() > 0.5 ? (lang === "ar" ? "تم السداد" : "Paid in full") : "",
        pick(rng, ["paid", "paid", "paid", "pending", "cancelled"]),
      ];
    },
    count: [12, 24],
    moneyKey: "amount",
  },

  /* الرواتب — مسيرات الرواتب بالبدلات والاستقطاعات والصافي */
  payroll: {
    cols: [
      { key: "code", ar: "رقم القسيمة", en: "Payslip #", kind: "id" },
      { key: "employee", ar: "الموظف", en: "Employee", kind: "text" },
      { key: "month", ar: "الشهر", en: "Month", kind: "text" },
      { key: "basic", ar: "الراتب الأساسي", en: "Basic", kind: "money" },
      { key: "allowances", ar: "البدلات", en: "Allowances", kind: "money" },
      { key: "deductions", ar: "الاستقطاعات", en: "Deductions", kind: "money" },
      { key: "net", ar: "الصافي", en: "Net", kind: "money" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "paid", ar: "مدفوع", en: "Paid", tone: "emerald" },
      { key: "approved", ar: "معتمد", en: "Approved", tone: "sky" },
      { key: "processing", ar: "قيد المعالجة", en: "Processing", tone: "amber" },
      { key: "held", ar: "موقوف", en: "Held", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const basic = money(rng, 7000, 24000);
      const allowances = money(rng, 900, 6800);
      const deductions = money(rng, 150, 2400);
      const net = Math.round((basic + allowances - deductions) * 100) / 100;
      return [
        recordCode("PRL", 39500 + i),
        person(rng, lang),
        lang === "ar" ? pick(rng, AR_MONTHS) : pick(rng, EN_MONTHS),
        basic.toFixed(2),
        allowances.toFixed(2),
        deductions.toFixed(2),
        net.toFixed(2),
        pick(rng, ["paid", "paid", "paid", "approved", "processing", "held"]),
      ];
    },
    count: [16, 28],
    moneyKey: "net",
  },

  /* البنوك — تغذية الحسابات البنكية اليومية بالوارد والصادر */
  bankfeeds: {
    cols: [
      { key: "code", ar: "رقم التغذية", en: "Feed #", kind: "id" },
      { key: "bank", ar: "البنك", en: "Bank", kind: "text" },
      { key: "account", ar: "الحساب", en: "Account", kind: "text" },
      { key: "txns", ar: "عدد العمليات", en: "Txns", kind: "num" },
      { key: "inflow", ar: "الوارد", en: "Inflow", kind: "money" },
      { key: "outflow", ar: "الصادر", en: "Outflow", kind: "money" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "synced", ar: "مزامن", en: "Synced", tone: "emerald" },
      { key: "reconciled", ar: "مسوّى", en: "Reconciled", tone: "sky" },
      { key: "importing", ar: "قيد الاستيراد", en: "Importing", tone: "amber" },
      { key: "failed", ar: "فاشل", en: "Failed", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      recordCode("BNK", 40000 + i),
      lang === "ar" ? pick(rng, AR_BANKS) : pick(rng, EN_BANKS),
      `SA${padded(count(rng, 3, 88), 2)} 8000 ****${padded(count(rng, 1024, 9899), 4)}`,
      String(count(rng, 35, 480)),
      money(rng, 14000, 920000).toFixed(2),
      money(rng, 9000, 760000).toFixed(2),
      dateStr(rng),
      pick(rng, ["synced", "synced", "synced", "reconciled", "importing", "failed"]),
    ],
    count: [16, 26],
    moneyKey: "inflow",
  },

  /* عروض الأسعار — عروض الأسعار بالخصومات ومدة الصلاحية */
  quotations: {
    cols: [
      { key: "code", ar: "رقم العرض", en: "Quote #", kind: "id" },
      { key: "client", ar: "العميل", en: "Client", kind: "text" },
      { key: "items", ar: "عدد البنود", en: "Items", kind: "num" },
      { key: "subtotal", ar: "المجموع الفرعي", en: "Subtotal", kind: "money" },
      { key: "discount", ar: "الخصم", en: "Discount", kind: "money" },
      { key: "total", ar: "الإجمالي", en: "Total", kind: "money" },
      { key: "valid", ar: "صالح حتى", en: "Valid until", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "accepted", ar: "مقبول", en: "Accepted", tone: "emerald" },
      { key: "sent", ar: "مُرسل", en: "Sent", tone: "sky" },
      { key: "negotiating", ar: "قيد التفاوض", en: "Negotiating", tone: "amber" },
      { key: "expired", ar: "منتهي", en: "Expired", tone: "slate" },
      { key: "declined", ar: "مرفوض", en: "Declined", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const subtotal = money(rng, 2500, 185000);
      const discount = money(rng, 0, Math.max(80, Math.round(subtotal * 0.15)));
      const total = Math.round((subtotal - discount) * 100) / 100;
      return [
        recordCode("QTE", 40500 + i),
        person(rng, lang),
        String(count(rng, 2, 28)),
        subtotal.toFixed(2),
        discount.toFixed(2),
        total.toFixed(2),
        dateStr(rng),
        pick(rng, ["accepted", "accepted", "accepted", "sent", "sent", "negotiating", "expired", "declined"]),
      ];
    },
    count: [16, 26],
    moneyKey: "total",
  },

  /* المستندات — أرشيف المستندات بالأنواع والأحجام */
  documents: {
    cols: [
      { key: "code", ar: "رقم المستند", en: "Doc #", kind: "id" },
      { key: "title", ar: "العنوان", en: "Title", kind: "text" },
      { key: "type", ar: "النوع", en: "Type", kind: "text" },
      { key: "owner", ar: "المالك", en: "Owner", kind: "text" },
      { key: "size", ar: "الحجم (ك.ب)", en: "Size (KB)", kind: "num" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "approved", ar: "معتمد", en: "Approved", tone: "emerald" },
      { key: "shared", ar: "مشارك", en: "Shared", tone: "sky" },
      { key: "pending", ar: "قيد المراجعة", en: "Pending", tone: "amber" },
      { key: "confidential", ar: "سري", en: "Confidential", tone: "violet" },
      { key: "voided", ar: "لاغٍ", en: "Voided", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      recordCode("DOC", 41000 + i),
      lang === "ar"
        ? pick(rng, ["فاتورة مبيعات الربع الأول", "عقد صيانة سنوي", "صورة الهوية الوطنية", "تقرير الأداء الشهري", "إيصال استلام نقدية", "السجل التجاري 2026", "رخصة البلدية", "شهادة ضريبية"])
        : pick(rng, ["Q1 sales invoice", "Annual maintenance contract", "National ID copy", "Monthly performance report", "Cash receipt", "2026 CR extract", "Municipality license", "Tax certificate"]),
      lang === "ar"
        ? pick(rng, ["فاتورة", "عقد", "هوية", "تقرير", "إيصال", "سجل تجاري", "رخصة"])
        : pick(rng, ["Invoice", "Contract", "ID", "Report", "Receipt", "CR extract", "License"]),
      person(rng, lang),
      String(count(rng, 48, 8600)),
      dateStr(rng),
      pick(rng, ["approved", "approved", "approved", "shared", "pending", "confidential", "voided"]),
    ],
    count: [16, 28],
  },
};

/* ------------------------------------------------------------------ */
/* record-code prefix registry (mirrors the module-data single source)  */
/* ------------------------------------------------------------------ */

/**
 * The code prefix each of the 21 modules uses for NEW rows created in the
 * workspace (record-code.ts formats {PREFIX}-00000001 — 8+ digit capacity).
 * The prefixes match the seeded row codes' series so generated codes and
 * demo codes read as one continuous series per module.
 */
export const HOSP_SVC_FIN_CODE_PREFIXES: Record<string, string> = {
  reservations: "RSV",
  kitchen: "KCH",
  tables: "TBL",
  delivery: "DLV",
  events: "EVT",
  reviews: "REV",
  housekeeping: "HPK",
  services: "SVC",
  scheduling: "SCH",
  contracts: "CTR",
  reminders: "RMD",
  subscriptions: "SUB",
  commissions: "COM",
  accounting: "ACC",
  taxes: "TAX",
  reconciliation: "REC",
  expenses: "EXP",
  payroll: "PRL",
  bankfeeds: "BNK",
  quotations: "QTE",
  documents: "DOC",
};
