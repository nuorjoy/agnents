/**
 * Ashrilogic — HEALTH + EDUCATION domain preset family (ROUND 132).
 *
 * Curated demo-dataset presets for the 20 health/education workspace modules:
 * the clinical family (radiology, ehr, operations, emergency, telemedicine,
 * insurance, beds) and the campus family (teachers, courses, grades,
 * attendance, fees, exams, timetable, parents, transport, library, cafeteria,
 * elearning, certificates). Pure data + deterministic row generators over the
 * shared preset-kit — the same generators the flagship presets use, imported
 * here WITHOUT any cycle back into module-data (module-data merges this file,
 * never the reverse). Every id band is a distinct 500-wide slice of the
 * 20000–89000 record-code space; every status pool is emerald-dominant so the
 * workspace KPIs read like a healthy operation.
 */
import { person, pick, phone, padded, money, dateStr, timeStr, count, pctStr, yesNo, recordCode } from "@/lib/module-presets/preset-kit";
import type { ModulePreset } from "@/lib/module-presets/preset-kit";

/* ------------------------------------------------------------------ */
/* bilingual domain vocabulary — health                                 */
/* ------------------------------------------------------------------ */

const AR_RAD_TYPES = ["أشعة مقطعية CT", "رنين مغناطيسي MRI", "سونار Ultrasound", "أشعة سينية X-Ray", "ماموجرام Mammogram", "فلوروسكوبي Fluoroscopy"];
const EN_RAD_TYPES = ["CT scan", "MRI", "Ultrasound", "X-Ray", "Mammogram", "Fluoroscopy"];

const AR_BODY = ["الرأس", "الصدر", "البطن", "الحوض", "العمود الفقري", "الكتف", "الركبة", "الجيوب الأنفية"];
const EN_BODY = ["Head", "Chest", "Abdomen", "Pelvis", "Spine", "Shoulder", "Knee", "Sinuses"];

const BLOOD_TYPES = ["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"];

const AR_ALLERGIES = ["لا يوجد", "البنسلين", "غبار الطلع", "المكسرات", "الأسبرين", "اللاكتوز", "السلفا"];
const EN_ALLERGIES = ["None", "Penicillin", "Pollen", "Nuts", "Aspirin", "Lactose", "Sulfa"];

const AR_CHRONIC = ["لا يوجد", "سكري النوع الثاني", "ارتفاع ضغط الدم", "الربو", "قصور القلب", "خلل الغدة الدرقية"];
const EN_CHRONIC = ["None", "Type 2 diabetes", "Hypertension", "Asthma", "Heart failure", "Thyroid disorder"];

const AR_SURGERIES = ["استئصال الزائدة الدودية", "ولادة قيصرية", "استئصال اللوزتين", "إزالة المرارة بالمنظار", "تثبيت كسر داخلي", "إصلاح فتق إربي", "منظار الركبة", "جراحة الدوالي"];
const EN_SURGERIES = ["Appendectomy", "Cesarean section", "Tonsillectomy", "Laparoscopic cholecystectomy", "Internal fracture fixation", "Inguinal hernia repair", "Knee arthroscopy", "Varicose vein surgery"];

const AR_COMPLAINTS = ["ألم في الصدر", "كسر بالذراع", "ضيق في التنفس", "حرارة مرتفعة", "جروح نازفة", "ألم بطن حاد", "إصابة في الرأس", "حرق سطحي"];
const EN_COMPLAINTS = ["Chest pain", "Arm fracture", "Shortness of breath", "High fever", "Bleeding wounds", "Acute abdominal pain", "Head injury", "Superficial burn"];

const AR_SPECIALTIES = ["باطنية", "أطفال", "جلدية", "نفسية", "تغذية علاجية", "أسنان", "نساء وولادة", "مخ وأعصاب"];
const EN_SPECIALTIES = ["Internal medicine", "Pediatrics", "Dermatology", "Psychiatry", "Clinical nutrition", "Dentistry", "OB/GYN", "Neurology"];

const AR_INSURERS = ["شركة التأمين التعاوني", "بوبا العربية للتأمين", "ميدغلف للتأمين", "تكافل الراجحي", "الأهلية للتأمين الصحي"];
const EN_INSURERS = ["Tawuniya Insurance", "Bupa Arabia", "MedGulf", "Al Rajhi Takaful", "Al Ahlia Health"];

const AR_PLANS = ["الخطة الأساسية", "الخطة الفضية", "الخطة الذهبية", "الخطة البلاتينية", "الخطة المميزة"];
const EN_PLANS = ["Basic plan", "Silver plan", "Gold plan", "Platinum plan", "VIP plan"];

const AR_WARDS = ["قسم الباطنية", "قسم الجراحة", "قسم الأطفال", "العناية المركزة", "قسم النساء والولادة", "قسم الطوارئ"];
const EN_WARDS = ["Internal medicine", "Surgery ward", "Pediatrics ward", "ICU", "Maternity ward", "Emergency ward"];

/* ------------------------------------------------------------------ */
/* bilingual domain vocabulary — education                              */
/* ------------------------------------------------------------------ */

const AR_SUBJECTS = ["الرياضيات", "الفيزياء", "الكيمياء", "الأحياء", "اللغة العربية", "اللغة الإنجليزية", "الدراسات الاجتماعية", "التربية الإسلامية", "الحاسب الآلي"];
const EN_SUBJECTS = ["Mathematics", "Physics", "Chemistry", "Biology", "Arabic language", "English language", "Social studies", "Islamic studies", "Computer science"];

const AR_DEGREES = ["بكالوريوس", "ماجستير", "دكتوراه"];
const EN_DEGREES = ["Bachelor", "Master", "PhD"];

/* [course-ar, subject-ar, course-en, subject-en] — one index keeps the
 * course name and its subject coherent in both languages. */
const COURSE_POOL: readonly [string, string, string, string][] = [
  ["الجبر الخطي", "الرياضيات", "Linear algebra", "Mathematics"],
  ["التفاضل والتكامل", "الرياضيات", "Calculus", "Mathematics"],
  ["الميكانيكا الكلاسيكية", "الفيزياء", "Classical mechanics", "Physics"],
  ["الكهرومغناطيسية", "الفيزياء", "Electromagnetism", "Physics"],
  ["الكيمياء العضوية", "الكيمياء", "Organic chemistry", "Chemistry"],
  ["الكيمياء العامة", "الكيمياء", "General chemistry", "Chemistry"],
  ["بيولوجيا الخلية", "الأحياء", "Cell biology", "Biology"],
  ["النحو والصرف", "اللغة العربية", "Grammar and morphology", "Arabic language"],
  ["الأدب العربي الحديث", "اللغة العربية", "Modern Arabic literature", "Arabic language"],
  ["المحادثة والإنشاء", "اللغة الإنجليزية", "Conversation and composition", "English language"],
  ["قواعد البيانات", "الحاسب الآلي", "Databases", "Computer science"],
  ["البرمجة بلغة بايثون", "الحاسب الآلي", "Python programming", "Computer science"],
];

const AR_GRADES = ["الصف السابع", "الصف الثامن", "الصف التاسع", "الصف العاشر", "الصف الحادي عشر", "الصف الثاني عشر"];
const EN_GRADES = ["Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12"];

const AR_TERMS = ["الفصل الأول", "الفصل الثاني", "الفصل الثالث"];
const EN_TERMS = ["Term 1", "Term 2", "Term 3"];

const AR_FEE_TYPES = ["الرسوم الدراسية", "النقل المدرسي", "الزي المدرسي", "الأنشطة اللاصفية", "الامتحانات الدولية", "المقصف"];
const EN_FEE_TYPES = ["Tuition", "School transport", "Uniform", "Extracurricular", "International exams", "Cafeteria"];

const AR_EXAM_NAMES = ["اختبار قصير", "اختبار الفترة الأولى", "اختبار منتصف الفصل", "اختبار الفترة الثانية", "الاختبار النهائي", "اختبار عملي"];
const EN_EXAM_NAMES = ["Short quiz", "First period test", "Midterm", "Second period test", "Final exam", "Practical"];

const AR_DAYS = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس"];
const EN_DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"];

const AR_SECTIONS = ["السابع/أ", "السابع/ب", "الثامن/أ", "التاسع/ب", "العاشر/أ", "الحادي عشر/ع", "الثاني عشر/أ"];
const EN_SECTIONS = ["7-A", "7-B", "8-A", "9-B", "10-A", "11-S", "12-A"];

const AR_RELATIONS = ["الأب", "الأم", "الوصي", "الأخ الأكبر", "الجد"];
const EN_RELATIONS = ["Father", "Mother", "Guardian", "Elder brother", "Grandfather"];

/* الكليات - للجامعات (university-management flagship module) */
const AR_COLLEGES = [
  "كلية الطب البشري",
  "كلية الهندسة",
  "كلية علوم الحاسب",
  "كلية إدارة الأعمال",
  "كلية الحقوق",
  "كلية الصيدلة",
  "كلية طب الأسنان",
  "كلية العلوم",
  "كلية الآداب",
  "كلية التربية",
  "كلية الزراعة",
  "كلية الطب البيطري",
];
const EN_COLLEGES = [
  "Faculty of Medicine",
  "Faculty of Engineering",
  "Faculty of Computer Science",
  "Faculty of Business Administration",
  "Faculty of Law",
  "Faculty of Pharmacy",
  "Faculty of Dentistry",
  "Faculty of Science",
  "Faculty of Arts",
  "Faculty of Education",
  "Faculty of Agriculture",
  "Faculty of Veterinary Medicine",
];

/* أولياء الأمور — المهن وجهات العمل والمدن (parent profile enrichment) */
const AR_OCCUPATIONS = ["طبيب", "مهندس", "محاسب", "معلم", "محامي", "تاجر", "موظف حكومي", "ضابط", "صيدلي", "ممرض", "مدير", "رجل أعمال"];
const EN_OCCUPATIONS = ["Doctor", "Engineer", "Accountant", "Teacher", "Lawyer", "Merchant", "Government Employee", "Officer", "Pharmacist", "Nurse", "Manager", "Businessman"];
const AR_WORKPLACES = ["وزارة الصحة", "شركة أرامكو", "مستشفى الملك فيصل", "وزارة التعليم", "البنك الأهلي", "هيئة الاتصالات", "الديوان الملكي", "وزارة الداخلية", "محكمة الرياض", "جامعة الملك سعود"];
const EN_WORKPLACES = ["Ministry of Health", "Saudi Aramco", "King Faisal Hospital", "Ministry of Education", "NCB Bank", "Communications Authority", "Royal Court", "Ministry of Interior", "Riyadh Court", "King Saud University"];
const AR_CITIES = ["الرياض", "جدة", "الدمام", "مكة المكرمة", "المدينة المنورة", "أبها", "تبوك", "بريدة", "حائل", "نجران"];
const EN_CITIES = ["Riyadh", "Jeddah", "Dammam", "Mecca", "Madinah", "Abha", "Tabuk", "Buraidah", "Hail", "Najran"];

const AR_ROUTES = ["حي الياسمين — المدرسة", "حي النرجس — المدرسة", "حي الملقا — المدرسة", "حي القيروان — المدرسة", "حي حطين — المدرسة", "حي الشفا — المدرسة"];
const EN_ROUTES = ["Al Yasmin — School", "Al Narjis — School", "Al Malqa — School", "Al Qairawan — School", "Al Hitten — School", "Al Shifa — School"];

const AR_PLATES = ["أ ب ج", "د ح ك", "ر س ن", "ط و ق", "ل م ع"];
const EN_PLATES = ["ABJ", "DHK", "RSN", "TWQ", "LMA"];

/* ROUND LIB — Premium library books pool (education sector). Authentic
 * Arabic literary titles from across the Arab world (Egypt, Levant, Iraq,
 * Maghreb, Andalusia) paired with their original authors and a coarse
 * category. Bilingual: the EN list mirrors the AR list row-for-row so the
 * same seeded PRNG picks the same book in either language. */
const AR_BOOKS: [string, string, string][] = [
  ["مقدمة ابن خلدون", "عبد الرحمن بن خلدون", "تاريخ واجتماع"],
  ["الأيام", "طه حسين", "أدب وسيرة"],
  ["زقاق المدق", "نجيب محفوظ", "رواية"],
  ["النبي", "جبران خليل جبران", "أدب وفلسفة"],
  ["رسالة الغفران", "أبو العلاء المعري", "أدب كلاسيكي"],
  ["الطريق إلى مكة", "محمد أسد", "سيرة ورحلات"],
  ["ساق البامبو", "سعود السنعوسي", "رواية معاصرة"],
  ["مدن الملح", "عبد الرحمن منيف", "رواية"],
  ["الثابت والمتحول", "عبد الله العروي", "فكر وفلسفة"],
  ["باب الشمس", "إلياس خوري", "رواية"],
  ["الوقائع الغريبة في اختفاء سعيد أبي النحس المتنبي", "إلياس خوري", "رواية"],
  ["ثلاثية غرناطة", "رضوى عاشور", "رواية تاريخية"],
  ["اللص والكلاب", "نجيب محفوظ", "رواية"],
  ["موسم الهجرة إلى الشمال", "الطيب صالح", "رواية"],
  ["عزازيل", "يوسف زيدان", "رواية تاريخية"],
  ["الكرنك", "نجيب محفوظ", "رواية اجتماعية"],
  ["أبو نواس: الحسن بن هانئ", "إبراهيم عبد القادر المازني", "سيرة"],
  ["ديوان المتنبي", "أبو الطيب المتنبي", "شعر"],
  ["مطولات الجاحظ", "أبو عثمان الجاحظ", "أدب كلاسيكي"],
  ["الإكليل", "نزار قباني", "شعر"],
];
const EN_BOOKS: [string, string, string][] = [
  ["Muqaddimah", "Ibn Khaldun", "History & Society"],
  ["The Days", "Taha Hussein", "Memoir"],
  ["Midaq Alley", "Naguib Mahfouz", "Novel"],
  ["The Prophet", "Khalil Gibran", "Literature & Philosophy"],
  ["The Epistle of Forgiveness", "Al-Ma'arri", "Classic Literature"],
  ["The Road to Mecca", "Muhammad Asad", "Biography"],
  ["The Bamboo Stalk", "Saud Alsanousi", "Contemporary Novel"],
  ["Cities of Salt", "Abdul Rahman Munif", "Novel"],
  ["The Crisis of the Arab Intellectual", "Abdullah Laroui", "Philosophy"],
  ["Gate of the Sun", "Elias Khoury", "Novel"],
  ["Yalo", "Elias Khoury", "Novel"],
  ["Granada Trilogy", "Radwa Ashour", "Historical Novel"],
  ["The Thief and the Dogs", "Naguib Mahfouz", "Novel"],
  ["Season of Migration to the North", "Tayeb Salih", "Novel"],
  ["Azazeel", "Youssef Ziedan", "Historical Novel"],
  ["Karnak Cafe", "Naguib Mahfouz", "Social Novel"],
  ["Abu Nuwas: Al-Hasan ibn Hani", "Ibrahim Al-Mazini", "Biography"],
  ["Diwan al-Mutanabbi", "Al-Mutanabbi", "Poetry"],
  ["Al-Jahiz Anthology", "Al-Jahiz", "Classic Literature"],
  ["The Wreath", "Nizar Qabbani", "Poetry"],
];
const AR_PUBLISHERS = ["دار الشروق", "دار الساقي", "الهيئة المصرية العامة للكتاب", "دار المدى", "المركز الثقافي العربي", "دار الآداب", "مكتبة مصر"];
const EN_PUBLISHERS = ["Shorouk", "Saqi Books", "Egyptian General Book Org.", "Al-Mada", "Arab Cultural Center", "Dar Al-Adab", "Maktabat Misr"];

const AR_CAF_ITEMS = ["ساندويتش جبن", "كرواسون بالشوكولاتة", "عصير برتقال طازج", "سلطة فواكه", "شاي كرك", "قهوة لاتيه", "كب كيك", "ماء بارد", "شريحة بيتزا", "زبادي بالفواكه"];
const EN_CAF_ITEMS = ["Cheese sandwich", "Chocolate croissant", "Fresh orange juice", "Fruit salad", "Karak tea", "Latte coffee", "Cupcake", "Cold water", "Pizza slice", "Fruit yogurt"];

const AR_CAF_CATS = ["مخبوزات", "مشروبات", "وجبات خفيفة", "حلويات", "خيارات صحية"];
const EN_CAF_CATS = ["Bakery", "Beverages", "Snacks", "Desserts", "Healthy"];

const AR_LESSONS = ["مقدمة الدرس", "محاضرة مسجلة", "شرح تفصيلي", "تمارين تطبيقية", "ورشة تفاعلية", "مراجعة نهائية"];
const EN_LESSONS = ["Lesson intro", "Recorded lecture", "Detailed lecture", "Applied exercises", "Interactive workshop", "Final review"];

const AR_CERT_TYPES = ["شهادة إتمام مقرر", "شهادة تفوق دراسي", "شهادة حضور ورشة", "شهادة معتمدة دولياً", "شهادة مشاركة"];
const EN_CERT_TYPES = ["Course completion", "Academic excellence", "Workshop attendance", "Internationally accredited", "Participation"];

const AR_ISSUERS = ["وزارة التعليم", "الهيئة السعودية للتقويم والاعتماد", "معهد التدريب المهني", "المركز الدولي للاعتماد"];
const EN_ISSUERS = ["Ministry of Education", "Saudi accreditation authority", "Vocational training institute", "International accreditation center"];

/* ------------------------------------------------------------------ */
/* presets                                                              */
/* ------------------------------------------------------------------ */

export const HEALTH_EDU_PRESETS: Record<string, ModulePreset> = {
  /* الأشعة */
  radiology: {
    cols: [
      { key: "code", ar: "رقم الفحص", en: "Exam #", kind: "id" },
      { key: "patient", ar: "المريض", en: "Patient", kind: "text" },
      { key: "exam", ar: "نوع الفحص", en: "Exam type", kind: "text" },
      { key: "bodyPart", ar: "المنطقة", en: "Body part", kind: "text" },
      { key: "doctor", ar: "الطبيب", en: "Radiologist", kind: "text" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "price", ar: "السعر", en: "Price", kind: "money" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "read", ar: "تمت القراءة", en: "Read", tone: "emerald" },
      { key: "pending", ar: "بانتظار التقرير", en: "Pending report", tone: "amber" },
      { key: "urgent", ar: "عاجل", en: "Urgent", tone: "rose" },
      { key: "scheduled", ar: "مجدول", en: "Scheduled", tone: "sky" },
    ],
    row: (rng, i, lang) => [
      recordCode("RAD", 21000 + i),
      person(rng, lang),
      lang === "ar" ? pick(rng, AR_RAD_TYPES) : pick(rng, EN_RAD_TYPES),
      lang === "ar" ? pick(rng, AR_BODY) : pick(rng, EN_BODY),
      lang === "ar" ? `د. ${person(rng, lang)}` : `Dr. ${person(rng, lang)}`,
      dateStr(rng),
      money(rng, 240, 3400).toFixed(2),
      pick(rng, ["read", "read", "read", "pending", "urgent", "scheduled"]),
    ],
    count: [18, 28],
    moneyKey: "price",
  },

  /* الملف الطبي */
  ehr: {
    cols: [
      { key: "code", ar: "رقم الملف", en: "Record #", kind: "id" },
      { key: "patient", ar: "المريض", en: "Patient", kind: "text" },
      { key: "bloodType", ar: "فصيلة الدم", en: "Blood type", kind: "text" },
      { key: "allergies", ar: "الحساسية", en: "Allergies", kind: "text" },
      { key: "chronic", ar: "أمراض مزمنة", en: "Chronic conditions", kind: "text" },
      { key: "insured", ar: "مؤمّن", en: "Insured", kind: "text" },
      { key: "updated", ar: "آخر تحديث", en: "Last update", kind: "date" },
      { key: "visits", ar: "عدد الزيارات", en: "Visits", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "ملف نشط", en: "Active", tone: "emerald" },
      { key: "review", ar: "بحاجة مراجعة", en: "Needs review", tone: "amber" },
      { key: "critical", ar: "حالة حرجة", en: "Critical", tone: "rose" },
      { key: "archived", ar: "مؤرشف", en: "Archived", tone: "slate" },
    ],
    row: (rng, i, lang) => [
      recordCode("EHR", 21500 + i),
      person(rng, lang),
      pick(rng, BLOOD_TYPES),
      lang === "ar" ? pick(rng, AR_ALLERGIES) : pick(rng, EN_ALLERGIES),
      lang === "ar" ? pick(rng, AR_CHRONIC) : pick(rng, EN_CHRONIC),
      yesNo(rng, lang),
      dateStr(rng),
      String(count(rng, 1, 42)),
      pick(rng, ["active", "active", "active", "review", "critical", "archived"]),
    ],
    count: [20, 30],
  },

  /* العمليات */
  operations: {
    cols: [
      { key: "code", ar: "رقم العملية", en: "Case #", kind: "id" },
      { key: "patient", ar: "المريض", en: "Patient", kind: "text" },
      { key: "surgery", ar: "نوع الجراحة", en: "Procedure", kind: "text" },
      { key: "surgeon", ar: "الجراح", en: "Surgeon", kind: "text" },
      { key: "room", ar: "غرفة العمليات", en: "OR room", kind: "text" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "duration", ar: "المدة (دقيقة)", en: "Duration (min)", kind: "num" },
      { key: "cost", ar: "التكلفة", en: "Cost", kind: "money" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "done", ar: "مكتملة", en: "Completed", tone: "emerald" },
      { key: "inprogress", ar: "جارية", en: "In progress", tone: "amber" },
      { key: "scheduled", ar: "مجدولة", en: "Scheduled", tone: "sky" },
      { key: "cancelled", ar: "ملغاة", en: "Cancelled", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      recordCode("OPR", 22000 + i),
      person(rng, lang),
      lang === "ar" ? pick(rng, AR_SURGERIES) : pick(rng, EN_SURGERIES),
      lang === "ar" ? `د. ${person(rng, lang)}` : `Dr. ${person(rng, lang)}`,
      `OR-${padded(count(rng, 1, 8), 2)}`,
      dateStr(rng),
      String(count(rng, 40, 320)),
      money(rng, 5200, 64000).toFixed(2),
      pick(rng, ["done", "done", "done", "scheduled", "inprogress", "cancelled"]),
    ],
    count: [16, 26],
    moneyKey: "cost",
  },

  /* الطوارئ */
  emergency: {
    cols: [
      { key: "code", ar: "رقم الحالة", en: "Case #", kind: "id" },
      { key: "patient", ar: "المريض", en: "Patient", kind: "text" },
      { key: "triage", ar: "مستوى الفرز", en: "Triage level", kind: "num" },
      { key: "complaint", ar: "الشكوى", en: "Complaint", kind: "text" },
      { key: "arrival", ar: "وقت الوصول", en: "Arrival", kind: "text" },
      { key: "doctor", ar: "الطبيب", en: "Doctor", kind: "text" },
      { key: "wait", ar: "مدة الانتظار (دقيقة)", en: "Wait (min)", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "treated", ar: "تم العلاج", en: "Treated", tone: "emerald" },
      { key: "treating", ar: "تحت العلاج", en: "In treatment", tone: "sky" },
      { key: "waiting", ar: "بانتظار الطبيب", en: "Waiting", tone: "amber" },
      { key: "critical", ar: "حرج", en: "Critical", tone: "rose" },
      { key: "transferred", ar: "محوّل", en: "Transferred", tone: "violet" },
    ],
    row: (rng, i, lang) => {
      const triage = pick(rng, [1, 2, 3, 3, 3, 4, 4, 4, 5, 5]);
      const wait = triage <= 2 ? count(rng, 0, 12) : triage === 3 ? count(rng, 8, 45) : count(rng, 25, 130);
      const st =
        triage <= 2
          ? pick(rng, ["critical", "critical", "treating"])
          : pick(rng, ["treated", "treated", "treated", "treating", "waiting", "transferred"]);
      return [
        recordCode("EMG", 22500 + i),
        person(rng, lang),
        String(triage),
        lang === "ar" ? pick(rng, AR_COMPLAINTS) : pick(rng, EN_COMPLAINTS),
        timeStr(rng),
        lang === "ar" ? `د. ${person(rng, lang)}` : `Dr. ${person(rng, lang)}`,
        String(wait),
        st,
      ];
    },
    count: [18, 30],
  },

  /* الطب عن بعد */
  telemedicine: {
    cols: [
      { key: "code", ar: "رقم الاستشارة", en: "Consult #", kind: "id" },
      { key: "patient", ar: "المريض", en: "Patient", kind: "text" },
      { key: "doctor", ar: "الطبيب", en: "Doctor", kind: "text" },
      { key: "specialty", ar: "التخصص", en: "Specialty", kind: "text" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "time", ar: "الوقت", en: "Time", kind: "text" },
      { key: "minutes", ar: "المدة (دقيقة)", en: "Duration (min)", kind: "num" },
      { key: "fee", ar: "أتعاب الاستشارة", en: "Consult fee", kind: "money" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "completed", ar: "مكتملة", en: "Completed", tone: "emerald" },
      { key: "scheduled", ar: "مجدولة", en: "Scheduled", tone: "sky" },
      { key: "noshow", ar: "لم يحضر", en: "No-show", tone: "rose" },
      { key: "cancelled", ar: "ملغاة", en: "Cancelled", tone: "slate" },
    ],
    row: (rng, i, lang) => [
      recordCode("TLC", 23000 + i),
      person(rng, lang),
      lang === "ar" ? `د. ${person(rng, lang)}` : `Dr. ${person(rng, lang)}`,
      lang === "ar" ? pick(rng, AR_SPECIALTIES) : pick(rng, EN_SPECIALTIES),
      dateStr(rng),
      timeStr(rng),
      String(count(rng, 10, 45)),
      money(rng, 90, 650).toFixed(2),
      pick(rng, ["completed", "completed", "completed", "scheduled", "noshow", "cancelled"]),
    ],
    count: [18, 30],
    moneyKey: "fee",
  },

  /* التأمين */
  insurance: {
    cols: [
      { key: "code", ar: "رقم البوليصة", en: "Policy #", kind: "id" },
      { key: "holder", ar: "المستفيد", en: "Policy holder", kind: "text" },
      { key: "provider", ar: "شركة التأمين", en: "Provider", kind: "text" },
      { key: "plan", ar: "الخطة", en: "Plan", kind: "text" },
      { key: "coverage", ar: "نسبة التغطية %", en: "Coverage %", kind: "num" },
      { key: "premium", ar: "القسط السنوي", en: "Annual premium", kind: "money" },
      { key: "expiry", ar: "تاريخ الانتهاء", en: "Expiry", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "سارية", en: "Active", tone: "emerald" },
      { key: "renewing", ar: "قاربت الانتهاء", en: "Renewal soon", tone: "amber" },
      { key: "expired", ar: "منتهية", en: "Expired", tone: "rose" },
      { key: "suspended", ar: "موقوفة", en: "Suspended", tone: "slate" },
    ],
    row: (rng, i, lang) => [
      recordCode("INS", 23500 + i),
      person(rng, lang),
      lang === "ar" ? pick(rng, AR_INSURERS) : pick(rng, EN_INSURERS),
      lang === "ar" ? pick(rng, AR_PLANS) : pick(rng, EN_PLANS),
      pctStr(rng, 50, 100),
      money(rng, 1800, 26000).toFixed(2),
      dateStr(rng),
      pick(rng, ["active", "active", "active", "active", "renewing", "expired", "suspended"]),
    ],
    count: [16, 26],
    moneyKey: "premium",
  },

  /* الأسرّة */
  beds: {
    cols: [
      { key: "code", ar: "رقم السرير", en: "Bed #", kind: "id" },
      { key: "bed", ar: "رمز السرير", en: "Bed label", kind: "text" },
      { key: "ward", ar: "القسم", en: "Ward", kind: "text" },
      { key: "floor", ar: "الطابق", en: "Floor", kind: "num" },
      { key: "rate", ar: "التعرفة/ليلة", en: "Rate/night", kind: "money" },
      { key: "patient", ar: "المريض", en: "Patient", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "occupied", ar: "مشغول", en: "Occupied", tone: "emerald" },
      { key: "vacant", ar: "شاغر", en: "Vacant", tone: "sky" },
      { key: "cleaning", ar: "تنظيف", en: "Cleaning", tone: "amber" },
      { key: "maintenance", ar: "صيانة", en: "Maintenance", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["occupied", "occupied", "occupied", "vacant", "cleaning", "maintenance"]);
      return [
        recordCode("BED", 24000 + i),
        `${pick(rng, ["A", "B", "C", "D"])}-${padded(count(rng, 1, 28), 2)}`,
        lang === "ar" ? pick(rng, AR_WARDS) : pick(rng, EN_WARDS),
        String(count(rng, 1, 6)),
        money(rng, 350, 2900).toFixed(2),
        st === "occupied" ? person(rng, lang) : "—",
        st,
      ];
    },
    count: [24, 30],
    moneyKey: "rate",
  },

  /* المعلمون */
  teachers: {
    cols: [
      { key: "code", ar: "الرقم الوظيفي", en: "Staff #", kind: "id" },
      { key: "name", ar: "المعلم", en: "Teacher", kind: "text" },
      { key: "subject", ar: "المادة", en: "Subject", kind: "text" },
      { key: "degree", ar: "المؤهل", en: "Degree", kind: "text" },
      { key: "classes", ar: "الحصص الأسبوعية", en: "Weekly periods", kind: "num" },
      { key: "phone", ar: "الجوال", en: "Mobile", kind: "text" },
      { key: "joined", ar: "تاريخ التعيين", en: "Joined", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "نشط", en: "Active", tone: "emerald" },
      { key: "training", ar: "دورة تدريبية", en: "In training", tone: "sky" },
      { key: "leave", ar: "إجازة", en: "On leave", tone: "amber" },
      { key: "ended", ar: "منتهي التعاقد", en: "Contract ended", tone: "slate" },
    ],
    row: (rng, i, lang) => [
      recordCode("TCH", 24500 + i),
      person(rng, lang),
      lang === "ar" ? pick(rng, AR_SUBJECTS) : pick(rng, EN_SUBJECTS),
      lang === "ar" ? pick(rng, AR_DEGREES) : pick(rng, EN_DEGREES),
      String(count(rng, 4, 26)),
      phone(rng),
      dateStr(rng),
      pick(rng, ["active", "active", "active", "active", "training", "leave", "ended"]),
    ],
    count: [16, 28],
  },

  /* المقررات */
  courses: {
    cols: [
      { key: "code", ar: "رمز المقرر", en: "Course #", kind: "id" },
      { key: "course", ar: "المقرر", en: "Course", kind: "text" },
      { key: "subject", ar: "المادة", en: "Subject", kind: "text" },
      { key: "grade", ar: "الصف", en: "Grade level", kind: "text" },
      { key: "teacher", ar: "المعلم", en: "Teacher", kind: "text" },
      { key: "hours", ar: "الساعات", en: "Hours", kind: "num" },
      { key: "students", ar: "عدد الطلاب", en: "Students", kind: "num" },
      { key: "fee", ar: "الرسوم", en: "Fee", kind: "money" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "open", ar: "مفتوح للتسجيل", en: "Open", tone: "emerald" },
      { key: "full", ar: "مكتمل العدد", en: "Full", tone: "sky" },
      { key: "closed", ar: "مغلق", en: "Closed", tone: "slate" },
      { key: "cancelled", ar: "ملغى", en: "Cancelled", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const c = pick(rng, COURSE_POOL);
      return [
        recordCode("CRS", 25000 + i),
        lang === "ar" ? c[0] : c[2],
        lang === "ar" ? c[1] : c[3],
        lang === "ar" ? pick(rng, AR_GRADES) : pick(rng, EN_GRADES),
        person(rng, lang),
        String(count(rng, 30, 120)),
        String(count(rng, 14, 180)),
        money(rng, 450, 4800).toFixed(2),
        pick(rng, ["open", "open", "open", "full", "cancelled", "closed"]),
      ];
    },
    count: [18, 28],
    moneyKey: "fee",
  },

  /* الدرجات */
  grades: {
    cols: [
      { key: "code", ar: "رقم النتيجة", en: "Result #", kind: "id" },
      { key: "student", ar: "الطالب", en: "Student", kind: "text" },
      { key: "subject", ar: "المادة", en: "Subject", kind: "text" },
      { key: "term", ar: "الفصل", en: "Term", kind: "text" },
      { key: "score", ar: "الدرجة", en: "Score", kind: "num" },
      { key: "grade", ar: "التقدير", en: "Grade", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "passed", ar: "ناجح", en: "Passed", tone: "emerald" },
      { key: "review", ar: "تحت المراجعة", en: "Under review", tone: "amber" },
      { key: "failed", ar: "راسب", en: "Failed", tone: "rose" },
      { key: "incomplete", ar: "غير مكتمل", en: "Incomplete", tone: "slate" },
    ],
    row: (rng, i, lang) => {
      const score = count(rng, 38, 100);
      const letter =
        score >= 95 ? "A+" : score >= 90 ? "A" : score >= 85 ? "B+" : score >= 80 ? "B" : score >= 75 ? "C+" : score >= 70 ? "C" : score >= 60 ? "D" : "F";
      return [
        recordCode("GRD", 25500 + i),
        person(rng, lang),
        lang === "ar" ? pick(rng, AR_SUBJECTS) : pick(rng, EN_SUBJECTS),
        lang === "ar" ? pick(rng, AR_TERMS) : pick(rng, EN_TERMS),
        String(score),
        letter,
        score >= 60 ? pick(rng, ["passed", "passed", "passed", "review"]) : pick(rng, ["failed", "failed", "review", "incomplete"]),
      ];
    },
    count: [20, 30],
  },

  /* الحضور */
  attendance: {
    cols: [
      { key: "code", ar: "رقم السجل", en: "Record #", kind: "id" },
      { key: "student", ar: "الطالب", en: "Student", kind: "text" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "checkin", ar: "الحضور", en: "Check-in", kind: "text" },
      { key: "checkout", ar: "الانصراف", en: "Check-out", kind: "text" },
      { key: "hours", ar: "الساعات", en: "Hours", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "present", ar: "حاضر", en: "Present", tone: "emerald" },
      { key: "late", ar: "متأخر", en: "Late", tone: "amber" },
      { key: "absent", ar: "غائب", en: "Absent", tone: "rose" },
      { key: "excused", ar: "غياب بعذر", en: "Excused", tone: "violet" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["present", "present", "present", "present", "late", "absent", "excused"]);
      const absent = st === "absent" || st === "excused";
      const checkin = st === "late" ? `${padded(count(rng, 9, 12), 2)}:${padded(count(rng, 1, 11) * 5, 2)}` : timeStr(rng);
      const hours = st === "present" ? count(rng, 5, 9) : st === "late" ? count(rng, 3, 7) : 0;
      return [
        recordCode("ATT", 26000 + i),
        person(rng, lang),
        dateStr(rng),
        absent ? "—" : checkin,
        absent ? "—" : timeStr(rng),
        String(hours),
        st,
      ];
    },
    count: [20, 30],
  },

  /* الرسوم */
  fees: {
    cols: [
      { key: "code", ar: "رقم الفاتورة", en: "Fee #", kind: "id" },
      { key: "student", ar: "الطالب", en: "Student", kind: "text" },
      { key: "type", ar: "نوع الرسوم", en: "Fee type", kind: "text" },
      { key: "term", ar: "الفصل", en: "Term", kind: "text" },
      { key: "amount", ar: "المبلغ", en: "Amount", kind: "money" },
      { key: "paid", ar: "المدفوع", en: "Paid", kind: "money" },
      { key: "due", ar: "تاريخ الاستحقاق", en: "Due date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "paid", ar: "مدفوعة", en: "Paid", tone: "emerald" },
      { key: "partial", ar: "مدفوعة جزئياً", en: "Partial", tone: "amber" },
      { key: "unpaid", ar: "غير مدفوعة", en: "Unpaid", tone: "slate" },
      { key: "overdue", ar: "متأخرة", en: "Overdue", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const amount = money(rng, 600, 14000);
      const st = pick(rng, ["paid", "paid", "paid", "partial", "unpaid", "overdue"]);
      const paid = st === "paid" ? amount : st === "partial" ? money(rng, Math.round(amount * 0.25), Math.round(amount * 0.85)) : 0;
      return [
        recordCode("FEE", 26500 + i),
        person(rng, lang),
        lang === "ar" ? pick(rng, AR_FEE_TYPES) : pick(rng, EN_FEE_TYPES),
        lang === "ar" ? pick(rng, AR_TERMS) : pick(rng, EN_TERMS),
        amount.toFixed(2),
        paid.toFixed(2),
        dateStr(rng),
        st,
      ];
    },
    count: [20, 30],
    moneyKey: "amount",
  },

  /* الامتحانات */
  exams: {
    cols: [
      { key: "code", ar: "رقم الاختبار", en: "Exam #", kind: "id" },
      { key: "exam", ar: "الاختبار", en: "Exam", kind: "text" },
      { key: "subject", ar: "المادة", en: "Subject", kind: "text" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "duration", ar: "المدة (دقيقة)", en: "Duration (min)", kind: "num" },
      { key: "students", ar: "عدد الطلاب", en: "Students", kind: "num" },
      { key: "avg", ar: "المتوسط", en: "Avg score", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "graded", ar: "مصحح", en: "Graded", tone: "emerald" },
      { key: "pending", ar: "بانتظار التصحيح", en: "Pending grading", tone: "amber" },
      { key: "scheduled", ar: "مجدول", en: "Scheduled", tone: "sky" },
      { key: "cancelled", ar: "ملغى", en: "Cancelled", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["graded", "graded", "graded", "pending", "scheduled", "cancelled"]);
      return [
        recordCode("EXM", 27000 + i),
        lang === "ar" ? pick(rng, AR_EXAM_NAMES) : pick(rng, EN_EXAM_NAMES),
        lang === "ar" ? pick(rng, AR_SUBJECTS) : pick(rng, EN_SUBJECTS),
        dateStr(rng),
        String(count(rng, 30, 180)),
        String(count(rng, 16, 240)),
        st === "graded" ? (48 + rng() * 49).toFixed(1) : st === "pending" ? (40 + rng() * 52).toFixed(1) : "—",
        st,
      ];
    },
    count: [16, 28],
  },

  /* الجداول */
  timetable: {
    cols: [
      { key: "code", ar: "رمز الحصة", en: "Slot #", kind: "id" },
      { key: "section", ar: "الشعبة", en: "Section", kind: "text" },
      { key: "day", ar: "اليوم", en: "Day", kind: "text" },
      { key: "period", ar: "الحصة", en: "Period", kind: "num" },
      { key: "subject", ar: "المادة", en: "Subject", kind: "text" },
      { key: "teacher", ar: "المعلم", en: "Teacher", kind: "text" },
      { key: "room", ar: "القاعة", en: "Room", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "نافذ", en: "Active", tone: "emerald" },
      { key: "substituted", ar: "حصة بديلة", en: "Substituted", tone: "amber" },
      { key: "rescheduled", ar: "مؤجلة", en: "Rescheduled", tone: "sky" },
      { key: "cancelled", ar: "ملغاة", en: "Cancelled", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      recordCode("TTB", 27500 + i),
      lang === "ar" ? pick(rng, AR_SECTIONS) : pick(rng, EN_SECTIONS),
      lang === "ar" ? pick(rng, AR_DAYS) : pick(rng, EN_DAYS),
      String(count(rng, 1, 7)),
      lang === "ar" ? pick(rng, AR_SUBJECTS) : pick(rng, EN_SUBJECTS),
      person(rng, lang),
      `R-${padded(count(rng, 8, 48), 2)}`,
      pick(rng, ["active", "active", "active", "active", "substituted", "rescheduled", "cancelled"]),
    ],
    count: [18, 30],
  },

  /* الكليات - للجامعات (university-management flagship module) */
  colleges: {
    cols: [
      { key: "code", ar: "رمز الكلية", en: "College Code", kind: "id" },
      { key: "name", ar: "اسم الكلية", en: "College Name", kind: "text" },
      { key: "dean", ar: "العميد", en: "Dean", kind: "text" },
      { key: "departments", ar: "عدد الأقسام", en: "Departments", kind: "num" },
      { key: "students", ar: "الطلاب", en: "Students", kind: "num" },
      { key: "established", ar: "تأسست", en: "Established", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "نشطة", en: "Active", tone: "emerald" },
      { key: "preparing", ar: "قيد التجهيز", en: "Preparing", tone: "amber" },
      { key: "closed", ar: "مغلقة", en: "Closed", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      recordCode("COL", 100 + i),
      pick(rng, lang === "ar" ? AR_COLLEGES : EN_COLLEGES),
      person(rng, lang),
      String(Math.floor(rng() * 12) + 3),
      String(Math.floor(rng() * 850) + 120),
      `${1950 + Math.floor(rng() * 75)}-09-01`,
      pick(rng, ["active", "active", "active", "preparing", "closed"]),
    ],
    count: [6, 12],
  },

  /* أولياء الأمور */
  parents: {
    cols: [
      { key: "code", ar: "رقم ولي الأمر", en: "Parent #", kind: "id" },
      { key: "parent", ar: "ولي الأمر", en: "Parent", kind: "text" },
      { key: "nationalId", ar: "رقم الهوية", en: "National ID", kind: "id" },
      { key: "phone", ar: "الجوال", en: "Mobile", kind: "text" },
      { key: "altPhone", ar: "هاتف بديل", en: "Alt. Phone", kind: "text" },
      { key: "email", ar: "البريد الإلكتروني", en: "Email", kind: "text" },
      { key: "occupation", ar: "المهنة", en: "Occupation", kind: "text" },
      { key: "workplace", ar: "جهة العمل", en: "Workplace", kind: "text" },
      { key: "city", ar: "المدينة", en: "City", kind: "text" },
      { key: "address", ar: "العنوان", en: "Address", kind: "text" },
      { key: "student", ar: "الطالب", en: "Student", kind: "text" },
      { key: "relation", ar: "صلة القرابة", en: "Relation", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "linked", ar: "مربوط بالحساب", en: "Linked", tone: "emerald" },
      { key: "pending", ar: "بحاجة ربط", en: "Pending", tone: "amber" },
      { key: "inactive", ar: "غير نشط", en: "Inactive", tone: "slate" },
    ],
    row: (rng, i, lang) => [
      recordCode("PAR", 28000 + i),
      person(rng, lang),
      `${1000000000 + Math.floor(rng() * 8999999999)}`,
      phone(rng),
      phone(rng),
      `${person(rng, "en").toLowerCase().replace(/\s+/g, ".")}@example.com`,
      pick(rng, lang === "ar" ? AR_OCCUPATIONS : EN_OCCUPATIONS),
      pick(rng, lang === "ar" ? AR_WORKPLACES : EN_WORKPLACES),
      pick(rng, lang === "ar" ? AR_CITIES : EN_CITIES),
      `${Math.floor(rng() * 199) + 1} ${lang === "ar" ? "شارع الملك فهد" : "King Fahd St"}`,
      person(rng, lang),
      lang === "ar" ? pick(rng, AR_RELATIONS) : pick(rng, EN_RELATIONS),
      pick(rng, ["linked", "linked", "linked", "pending", "inactive"]),
    ],
    count: [16, 28],
  },

  /* النقل */
  transport: {
    cols: [
      { key: "code", ar: "رقم المسار", en: "Route #", kind: "id" },
      { key: "route", ar: "المسار", en: "Route", kind: "text" },
      { key: "driver", ar: "السائق", en: "Driver", kind: "text" },
      { key: "plate", ar: "رقم اللوحة", en: "Plate", kind: "text" },
      { key: "stops", ar: "نقاط التوقف", en: "Stops", kind: "num" },
      { key: "capacity", ar: "سعة الحافلة", en: "Capacity", kind: "num" },
      { key: "students", ar: "الطلاب", en: "Students", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "نشط", en: "Active", tone: "emerald" },
      { key: "full", ar: "مكتمل", en: "Full", tone: "sky" },
      { key: "maintenance", ar: "صيانة", en: "Maintenance", tone: "amber" },
      { key: "suspended", ar: "موقوف", en: "Suspended", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const capacity = count(rng, 30, 66);
      const digits = String(count(rng, 1000, 9899));
      return [
        recordCode("TRN", 28500 + i),
        lang === "ar" ? pick(rng, AR_ROUTES) : pick(rng, EN_ROUTES),
        person(rng, lang),
        lang === "ar" ? `${digits} ${pick(rng, AR_PLATES)}` : `${digits} ${pick(rng, EN_PLATES)}`,
        String(count(rng, 5, 22)),
        String(capacity),
        String(count(rng, 18, capacity)),
        pick(rng, ["active", "active", "active", "full", "maintenance", "suspended"]),
      ];
    },
    count: [14, 24],
  },

  /* المكتبة — Premium library preset (education sector).
   * ROUND LIB: authentic bilingual literary catalog (titles + authors +
   * categories) drawn from across the Arab world, rich shelf metadata
   * (publisher / year / ISBN / shelf code) and a four-state status pool
   * (available / borrowed / reserved / lost). The same seeded PRNG picks
   * the same book in either language. */
  library: {
    cols: [
      { key: "code", ar: "رمز الكتاب", en: "Book #", kind: "id" },
      { key: "title", ar: "العنوان", en: "Title", kind: "text" },
      { key: "author", ar: "المؤلف", en: "Author", kind: "text" },
      { key: "category", ar: "التصنيف", en: "Category", kind: "text" },
      { key: "isbn", ar: "رقم ISBN", en: "ISBN", kind: "id" },
      { key: "publisher", ar: "الناشر", en: "Publisher", kind: "text" },
      { key: "year", ar: "سنة النشر", en: "Year", kind: "num" },
      { key: "copies", ar: "النسخ", en: "Copies", kind: "num" },
      { key: "available", ar: "المتاحة", en: "Available", kind: "num" },
      { key: "shelf", ar: "الرف", en: "Shelf", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "available", ar: "متاح", en: "Available", tone: "emerald" },
      { key: "borrowed", ar: "مُعار", en: "Borrowed", tone: "amber" },
      { key: "reserved", ar: "محجوز", en: "Reserved", tone: "sky" },
      { key: "lost", ar: "مفقود", en: "Lost", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const books = lang === "ar" ? AR_BOOKS : EN_BOOKS;
      const idx = Math.floor(rng() * books.length);
      const [title, author, category] = books[idx];
      const copies = count(rng, 2, 12);
      const available = count(rng, 0, copies);
      const shelf = `${String.fromCharCode(65 + Math.floor(rng() * 6))}-${count(rng, 1, 99)}`;
      const st = available === 0 ? "borrowed" : available <= Math.max(1, Math.floor(copies * 0.3)) ? "reserved" : rng() > 0.95 ? "lost" : "available";
      return [
        recordCode("LIB", 29000 + i),
        title,
        author,
        category,
        `978-${count(rng, 100, 999)}-${padded(count(rng, 1, 999999), 6)}-${count(rng, 0, 9)}`,
        lang === "ar" ? pick(rng, AR_PUBLISHERS) : pick(rng, EN_PUBLISHERS),
        String(1960 + Math.floor(rng() * 65)),
        String(copies),
        String(available),
        shelf,
        st,
      ];
    },
    count: [20, 40],
  },

  /* المقصف */
  cafeteria: {
    cols: [
      { key: "code", ar: "رمز الصنف", en: "Item #", kind: "id" },
      { key: "item", ar: "الصنف", en: "Item", kind: "text" },
      { key: "category", ar: "الفئة", en: "Category", kind: "text" },
      { key: "price", ar: "السعر", en: "Price", kind: "money" },
      { key: "sold", ar: "المبيعات اليومية", en: "Sold/day", kind: "num" },
      { key: "stock", ar: "المخزون", en: "Stock", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "instock", ar: "متوفر", en: "In stock", tone: "emerald" },
      { key: "low", ar: "منخفض", en: "Low", tone: "amber" },
      { key: "out", ar: "نفد", en: "Out", tone: "rose" },
      { key: "expired", ar: "منتهي الصلاحية", en: "Expired", tone: "slate" },
    ],
    row: (rng, i, lang) => {
      const stock = count(rng, 0, 260);
      const st = rng() > 0.92 ? "expired" : stock === 0 ? "out" : stock < 40 ? "low" : "instock";
      return [
        recordCode("CAF", 29500 + i),
        lang === "ar" ? pick(rng, AR_CAF_ITEMS) : pick(rng, EN_CAF_ITEMS),
        lang === "ar" ? pick(rng, AR_CAF_CATS) : pick(rng, EN_CAF_CATS),
        money(rng, 2, 26).toFixed(2),
        String(count(rng, 4, 280)),
        String(stock),
        st,
      ];
    },
    count: [16, 26],
    moneyKey: "price",
  },

  /* التعليم الإلكتروني */
  elearning: {
    cols: [
      { key: "code", ar: "رمز الدرس", en: "Lesson #", kind: "id" },
      { key: "course", ar: "المقرر", en: "Course", kind: "text" },
      { key: "lesson", ar: "الدرس", en: "Lesson", kind: "text" },
      { key: "duration", ar: "المدة (دقيقة)", en: "Duration (min)", kind: "num" },
      { key: "enrolled", ar: "المسجلون", en: "Enrolled", kind: "num" },
      { key: "completion", ar: "نسبة الإكمال %", en: "Completion %", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "published", ar: "منشور", en: "Published", tone: "emerald" },
      { key: "pending", ar: "قيد المراجعة", en: "In review", tone: "amber" },
      { key: "draft", ar: "مسودة", en: "Draft", tone: "sky" },
      { key: "archived", ar: "مؤرشف", en: "Archived", tone: "slate" },
    ],
    row: (rng, i, lang) => {
      const c = pick(rng, COURSE_POOL);
      const st = pick(rng, ["published", "published", "published", "pending", "draft", "archived"]);
      return [
        recordCode("ELN", 30000 + i),
        lang === "ar" ? c[0] : c[2],
        lang === "ar" ? pick(rng, AR_LESSONS) : pick(rng, EN_LESSONS),
        String(count(rng, 8, 90)),
        String(count(rng, 30, 850)),
        st === "draft" || st === "archived" ? "—" : pctStr(rng, 18, 97),
        st,
      ];
    },
    count: [16, 26],
  },

  /* الشهادات */
  certificates: {
    cols: [
      { key: "code", ar: "رقم الشهادة", en: "Cert #", kind: "id" },
      { key: "student", ar: "الطالب", en: "Student", kind: "text" },
      { key: "type", ar: "نوع الشهادة", en: "Type", kind: "text" },
      { key: "issuer", ar: "جهة الإصدار", en: "Issuer", kind: "text" },
      { key: "issued", ar: "تاريخ الإصدار", en: "Issued", kind: "date" },
      { key: "verify", ar: "رمز التحقق", en: "Verify code", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "valid", ar: "سارية", en: "Valid", tone: "emerald" },
      { key: "reissue", ar: "بحاجة إصدار", en: "Reissue needed", tone: "amber" },
      { key: "expired", ar: "منتهية", en: "Expired", tone: "slate" },
      { key: "revoked", ar: "ملغاة", en: "Revoked", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      recordCode("CRT", 30500 + i),
      person(rng, lang),
      lang === "ar" ? pick(rng, AR_CERT_TYPES) : pick(rng, EN_CERT_TYPES),
      lang === "ar" ? pick(rng, AR_ISSUERS) : pick(rng, EN_ISSUERS),
      dateStr(rng),
      `VC-${padded(count(rng, 1, 999999), 6)}`,
      pick(rng, ["valid", "valid", "valid", "valid", "reissue", "expired", "revoked"]),
    ],
    count: [16, 26],
  },
};

export const HEALTH_EDU_CODE_PREFIXES: Record<string, string> = {
  radiology: "RAD",
  ehr: "EHR",
  operations: "OPR",
  emergency: "EMG",
  telemedicine: "TLC",
  insurance: "INS",
  beds: "BED",
  teachers: "TCH",
  courses: "CRS",
  grades: "GRD",
  attendance: "ATT",
  fees: "FEE",
  exams: "EXM",
  timetable: "TTB",
  colleges: "COL",
  parents: "PAR",
  transport: "TRN",
  library: "LIB",
  cafeteria: "CAF",
  elearning: "ELN",
  certificates: "CRT",
};
