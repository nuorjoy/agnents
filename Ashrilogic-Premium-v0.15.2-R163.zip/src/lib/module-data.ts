/**
 * Ashrilogic — deterministic demo datasets for the module workspace.
 *
 * Clicking an ENABLED module card opens a premium detail workspace (round 25).
 * Real production tables are out of demo scope, so each module renders a
 * realistic, STABLE dataset derived from a seeded PRNG (mulberry32) keyed by
 * `instanceId + moduleId` — the same workspace always shows the same rows,
 * across reloads and users, which is what makes it feel like real data.
 *
 * Layout:
 *  - MODULE_PRESETS: curated column/status/row generators for the flagship
 *    modules (patients, appointments, pharmacy, inventory, invoices, …) plus
 *    the round-29 gym / barbershop / driving-school family (members, coaches,
 *    classes, workouts, equipment, measurements, nutrition, lockers, queue,
 *    vehicles, lessons, memberships).
 *  - genericPreset(): semantic fallback for the remaining ~120 modules —
 *    still localized and plausible, never empty.
 *  - buildModuleDataset(): assembles rows + KPIs + a 12-bar weekly series +
 *    status distribution for the workspace charts.
 *
 * ROUND 80 — every id-kind demo code carries an 8-digit zero-padded tail
 * ({PREFIX}-00000001, e.g. MRN-00010240 / INV-2026-00001400), matching the
 * RECORD_CODE_MIN_DIGITS = 8 mandate in record-code.ts. The numeric SERIES
 * (base numbers, +i increments, rng draws) is untouched — only the pad width
 * changed — so stable-PRNG determinism and nextRecordCode continuity hold.
 * Realistic semantic numbers are exempt: vehicle license plates, hotel room
 * numbers, dates/times and phone generators keep their own natural widths.
 */
import type { Lang } from "@/lib/types";
import type { ProductVariantDTO } from "@/lib/types";
import { SYSTEM_MAP } from "@/data/catalog";
/* ROUND 141 (㉕) — the structured payment ledger rides ModuleRow so the
   print-doc builders (module workspace, business suite, inventory) can
   print the settlement strip; the pure PaymentEntry type keeps this a
   PURE module (no db, no next/server). */
import type { PaymentEntry } from "@/lib/payment-methods";
/* ROUND 132 — the shared row-generator toolkit (person/pick/padded/money/
 * dateStr/timeStr/phone + name pools) lives in module-presets/preset-kit so
 * the DOMAIN preset families import the same generators without cycles. */
import { person, pick, phone, padded, money, dateStr, timeStr, AR_LAST, EN_LAST } from "@/lib/module-presets/preset-kit";
import { toArabicDigits } from "@/lib/utils";
/* ROUND 132 — the four domain preset families (93 modules of real bilingual
 * vocabulary: health/education, hospitality/services/finance, logistics/
 * agriculture/industry, media/HR/fun/legal/nonprofit/general) merge into the
 * registry below — the genericPreset fallback stays for anything uncataloged. */
import { HEALTH_EDU_PRESETS, HEALTH_EDU_CODE_PREFIXES } from "@/lib/module-presets/health-education";
import { HOSP_SVC_FIN_PRESETS, HOSP_SVC_FIN_CODE_PREFIXES } from "@/lib/module-presets/hospitality-services-finance";
import { OPS_PRESETS, OPS_CODE_PREFIXES } from "@/lib/module-presets/operations";
import { MEDIA_HR_NPO_PRESETS, MEDIA_HR_NPO_CODE_PREFIXES } from "@/lib/module-presets/media-hr-nonprofit";

/* ------------------------------------------------------------------ */
/* seeded PRNG                                                          */
/* ------------------------------------------------------------------ */

function seedFrom(text: string): number {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function mulberry32(seed: number): () => number {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ------------------------------------------------------------------ */
/* types                                                                */
/* ------------------------------------------------------------------ */

export type CellKind = "text" | "num" | "money" | "date" | "status" | "id";

export interface ColDef {
  key: string;
  ar: string;
  en: string;
  kind: CellKind;
}

export type StatusTone = "emerald" | "amber" | "rose" | "sky" | "violet" | "slate";

export interface StatusDef {
  key: string;
  ar: string;
  en: string;
  tone: StatusTone;
}

export interface ModulePreset {
  cols: ColDef[];
  statuses: StatusDef[];
  /** row values aligned with cols (the status column carries a status key).
   *  ROUND 129 — the optional FOURTH parameter is the workspace's catalog
   *  sector id (health / education / retail / …): curated presets may
   *  ignore it (their rows are already domain-correct), while generic +
   *  inventory rows use it to draw sector-MATCHED vocabulary so every
   * system's demo data speaks its own domain. Existing 3-arg row functions
   * remain assignable (parameter contravariance). */
  row: (rng: () => number, i: number, lang: Lang, sector?: string) => string[];
  count: [number, number];
  /** money column key used for the "total value" KPI (optional) */
  moneyKey?: string;
}

export interface ModuleRow {
  id: string;
  values: string[];
  statusKey: string;
  /** ROUND 141 (㉕) — the structured 7-method payment ledger (absent on
   *  demo rows — only real records carry it). */
  payments?: PaymentEntry[];
  /** ROUND 141 (product extras) — the FULL ordered photo gallery (cover
   *  first) + video clips + variant rows; absent on demo rows. */
  gallery?: string[];
  videos?: string[];
  variants?: ProductVariantDTO[];
  /** ROUND 156 — the optional cover/ receipt image (managed /api/images
   *  ref; null/absent on demo rows). Mirrors the ModuleRecordDTO contract
   *  so the business-record-dialog can read the receipt image on edit. */
  imageRef?: string | null;
}

export interface ModuleKpis {
  total: number;
  monthly: number;
  active: number;
  value: number;
  growth: number;
}

export interface ModuleDataset {
  cols: ColDef[];
  statuses: StatusDef[];
  rows: ModuleRow[];
  kpis: ModuleKpis;
  /** 12 deterministic bars for the mini activity chart */
  series: number[];
  statusDist: { key: string; count: number }[];
  /** money column key when the preset defines one (drives the value KPI) */
  valueKey: string | null;
}

/* ------------------------------------------------------------------ */
/* localized value pools                                                */
/* ------------------------------------------------------------------ */

/* ROUND 132 — the name pools + generator helpers moved to
 * module-presets/preset-kit.ts (imported above). */

const AR_DOCTORS = ["د. خالد الأحمد", "د. منى السالم", "د. عبدالرحمن العمري", "د. لمى الشهري", "د. فيصل النعيمي", "د. أمل الرشيد"];
const EN_DOCTORS = ["Dr. Khalid Alahmad", "Dr. Muna Alsalem", "Dr. Abdulrahman Alomari", "Dr. Lama Alshehri", "Dr. Faisal Alnaimi"];

const AR_CITIES = ["الرياض", "جدة", "الدمام", "مكة المكرمة", "المدينة المنورة", "الخبر", "أبها", "تبوك"];
const EN_CITIES = ["Riyadh", "Jeddah", "Dammam", "Makkah", "Madinah", "Khobar", "Abha", "Tabuk"];

const AR_DEPTS = ["قسم الطوارئ", "الباطنية", "الجراحة العامة", "الأطفال", "النساء والولادة", "العظام", "العيون", "المختبر"];
const EN_DEPTS = ["Emergency", "Internal Medicine", "General Surgery", "Pediatrics", "Obstetrics", "Orthopedics", "Ophthalmology", "Laboratory"];

const AR_DRUGS = ["بنادول 500mg", "أوجمنتين 1g", "فنتولين بخاخ", "نورفاسك 5mg", "جلوكوفاج 850mg", "زيرتك 10mg", "بروفين 400mg", "كونكور 5mg", "ليباتور 20mg", "نيكسيم 40mg", "أموكسيل 500mg", "فيتامين د3"];
const AR_DRUG_CATS = ["مسكنات", "مضادات حيوية", "مضادات حساسية", "قلب وضغط", "سكري", "فيتامينات", "جهاز تنفسي"];

const AR_SUPPLY = ["قفازات طبية 100حبة", "سرنجات 5ml", "شاش معقم", "كمامات N95", "محلول ملحي 500ml", "جهاز قياس ضغط رقمي", "ميزان حرارة بالأشعة", "مفاصل طبية", "أوراق ECG", "أنابيب اختبار"];
const EN_SUPPLY = ["Medical gloves ×100", "Syringes 5ml", "Sterile gauze", "N95 masks", "Saline 500ml", "Digital BP monitor", "IR thermometer", "Medical tape", "ECG paper", "Test tubes"];

const AR_PRODUCTS = ["أرز بسمتي 5كجم", "زيت دوار الشمس 1.8ل", "حليب طويل الأجل 1ل", "سكر ناعم 2كجم", "شاي أحمر 100كيس", "قهوة مختصة 250غ", "معجون أسنان 120مل", "منظف أرضيات 1ل", "مناديل ورقية", "ماء معدني 40×330مل"];
const EN_PRODUCTS = ["Basmati rice 5kg", "Sunflower oil 1.8L", "UHT milk 1L", "Sugar 2kg", "Black tea 100 bags", "Specialty coffee 250g", "Toothpaste 120ml", "Floor cleaner 1L", "Paper tissues", "Water 40×330ml"];

const AR_MENU = ["كبسة لحم", "مندي دجاج", "برياني روبيان", "شاورما عربي", "سلطة سيزر", "برجر أنجوس", "معكرونة ألفريدو", "عصير برتقال طازج"];
const EN_MENU = ["Lamb kabsa", "Chicken mandi", "Shrimp biryani", "Arabic shawarma", "Caesar salad", "Angus burger", "Alfredo pasta", "Fresh orange juice"];

const AR_CHANNELS = ["الفرع", "تطبيق التوصيل", "الهاتف", "الموقع"];
const EN_CHANNELS = ["Branch", "Delivery app", "Phone", "Website"];

const AR_SVCS = ["استشارة عامة", "فحص شامل", "تنظيف أسنان", "جلسة علاج طبيعي", "تحليل مخبري", "تجميل جلد"];
const EN_SVCS = ["General consult", "Full checkup", "Teeth cleaning", "Physio session", "Lab test", "Dermatology"];

/* ---- ROUND 131 — business-suite vocabulary (the 10 premium commerce
   modules: POS / products / customers / suppliers / purchases /
   promotions / returns / loyalty / branches / reports / stocktake) ---- */

const AR_BRANCHES = ["الفرع الرئيسي", "فرع الملقا", "فرع النخيل", "فرع العليا", "فرع الياسمين", "فرع الشاطئ"];
const EN_BRANCHES = ["Main branch", "Malqa branch", "Nakheel branch", "Olaya branch", "Yasmin branch", "Beach branch"];

const AR_PAY_METHODS = ["مدى", "نقداً", "شبكة", "Apple Pay", "تحويل", "قسيمة"];
const EN_PAY_METHODS = ["Mada", "Cash", "EFTPOS", "Apple Pay", "Transfer", "Voucher"];

const AR_PROD_CATS = ["بقالة", "مشروبات", "عناية شخصية", "منظفات", "ألبان ومبردات", "مخبوزات", "وجبات خفيفة", "منزل ومطبخ"];
const EN_PROD_CATS = ["Grocery", "Beverages", "Personal care", "Cleaning", "Dairy & chilled", "Bakery", "Snacks", "Home & kitchen"];

const AR_PROMO_TYPES = ["خصم نسبة", "خصم مبلغ", "اشترِ واحصل", "نقاط مضاعفة", "شحن مجاني"];
const EN_PROMO_TYPES = ["Percent off", "Amount off", "BOGO", "Double points", "Free shipping"];

const AR_PROMO_SCOPES = ["كل المنتجات", "فئة محددة", "عملاء جدد", "أعضاء الولاء", "الطلب الأول"];
const EN_PROMO_SCOPES = ["All products", "Category", "New customers", "Loyalty members", "First order"];

const AR_RETURN_REASONS = ["منتج تالف", "خطأ في الطلب", "لم يطابق الوصف", "انتهاء صلاحية", "رضا غير مضمون", "حساسية/أعراض"];
const EN_RETURN_REASONS = ["Damaged item", "Wrong item", "Not as described", "Expired", "Satisfaction guarantee", "Allergic reaction"];

const AR_REPORT_PERIODS = ["يومي", "أسبوعي", "شهري", "ربع سنوي", "سنوي"];
const EN_REPORT_PERIODS = ["Daily", "Weekly", "Monthly", "Quarterly", "Yearly"];

const AR_REPORT_NAMES = [
  "ملخص المبيعات حسب القناة",
  "أرباح الفروع",
  "دوران المخزون",
  "أفضل ٥٠ منتجاً",
  "تحليل سلة المشتريات",
  "العملاء الخاملون",
  "تقادم الأرصدة المستحقة",
  "الضريبة والالتزام",
  "نسب المرتجعات",
  "أداء الموردين",
  "فعالية العروض",
  "استرداد الولاء",
];
const EN_REPORT_NAMES = [
  "Sales by channel summary",
  "Branch profitability",
  "Inventory turnover",
  "Top 50 products",
  "Basket analysis",
  "Dormant customers",
  "Receivables aging",
  "Tax & compliance",
  "Returns ratio",
  "Supplier performance",
  "Promotion effectiveness",
  "Loyalty redemption",
];

/* ROUND 155 — reports preset rebuilt as a report-management system. The
 * owner's directive: «في جميع الأنظمة عند صفحة (التقارير) قم بتطوير الصفحة
 * واجعلها متقدمة ومتكاملة». The preset grows to 10 cols (code · title ·
 * type · period · generatedBy · format · size · rows · generated · status)
 * + 5 statuses (generated · generating · scheduled · failed · archived).
 * The bilingual report-format + file-size pools drive the new cells. */
const AR_REPORT_TYPES = ["مبيعات", "مخزون", "مالي", "عملاء", "ضريبي", "تشغيلي", "موارد بشرية", "أداء"];
const EN_REPORT_TYPES = ["Sales", "Inventory", "Financial", "Customers", "Tax", "Operational", "HR", "Performance"];

const AR_REPORT_FORMATS = ["PDF", "Excel", "CSV", "JSON"];
const EN_REPORT_FORMATS = ["PDF", "Excel", "CSV", "JSON"];

/** deterministic bilingual file-size string for the i-th report (stable
 *  across renders so the table cell doesn't shift on re-mount). Returns a
 *  value like "2.4 MB" or "880 KB". */
function reportSize(i: number, lang: Lang): string {
  const seed = (i * 7 + 3) % 24;
  const inKb = 80 + seed * 220 + ((i * 13) % 480);
  if (inKb >= 1024) {
    const mb = (inKb / 1024).toFixed(1);
    return lang === "ar" ? `${toArabicDigits(mb)} ميجابايت` : `${mb} MB`;
  }
  const kb = String(inKb);
  return lang === "ar" ? `${toArabicDigits(kb)} كيلوبايت` : `${kb} KB`;
}

const AR_INV_ZONES = ["مستودع الفرع", "المستودع المركزي", "منطقة الاستلام", "رف العرض"];
const EN_INV_ZONES = ["Branch stockroom", "Central warehouse", "Receiving zone", "Display shelf"];

const AR_PURCHASE_CATS = ["توريد دوري", "طلب طارئ", "عقد سنوي", "شراء موسمي", "توريد افتتاحي"];
const EN_PURCHASE_CATS = ["Routine supply", "Urgent order", "Annual contract", "Seasonal buy", "Opening stock"];

/* ---- ROUND 78 — inventory vocabulary (reorder point / location /
   supplier demo pools for the dedicated premium inventory workspace) ---- */
const AR_INV_LOCATIONS = ["مستودع رئيسي", "مستودع فرعي", "رف A", "رف B", "غرفة التعقيم", "ثلاجة المستلزمات", "منطقة الاستلام"];
const EN_INV_LOCATIONS = ["Main warehouse", "Secondary warehouse", "Shelf A", "Shelf B", "Sterilization room", "Supplies fridge", "Receiving area"];
const AR_INV_SUPPLIERS = ["شركة المستلزمات الوطنية", "مؤسسة التوريد الطبي", "شركة الرياض للتجهيزات", "مورد الخليج الموحد", "الشركة العالمية للتقنية الطبية"];
const EN_INV_SUPPLIERS = ["National Supplies Co.", "Medical Supply Est.", "Riyadh Equipment Co.", "Unified Gulf Supplier", "Global MedTech Co."];

/* ---- round 29: gym / barbershop / driving-school vocabulary ---- */

const AR_COACHES = ["كابتن خالد الشمري", "كابتن ماجد الدوسري", "كابتن نورة العتيبي", "كابتن سلطان الحربي", "كابتن ريم القحطاني", "كابتن فهد الغامدي", "كابتن دانة السبيعي"];
const EN_COACHES = ["Coach Khalid Alshammari", "Coach Majed Aldosari", "Coach Noura Alotaibi", "Coach Sultan Alharbi", "Coach Reem Alqahtani", "Coach Fahad Alghamdi", "Coach Dana Alsubaie"];

const AR_SPECIALTIES = ["كمال الأجسام", "لياقة عامة", "كروس فيت", "يوغا", "ملاكمة", "تأهيل"];
const EN_SPECIALTIES = ["Bodybuilding", "General Fitness", "CrossFit", "Yoga", "Boxing", "Rehab"];

const AR_CERTS = ["ISSA معتمد", "NASM-CPT", "كروس فيت L2", "CPR/AED", "ACE معتمد", "بكالوريوس علوم رياضة"];
const EN_CERTS = ["ISSA Certified", "NASM-CPT", "CrossFit L2", "CPR/AED", "ACE Certified", "BSc Sports Science"];

const AR_GYM_PLANS = ["شهري", "ربع سنوي", "نص سنوي", "سنوي", "سنوي VIP"];
const EN_GYM_PLANS = ["Monthly", "Quarterly", "Semi-annual", "Annual", "VIP Annual"];

const AR_CLASS_NAMES = ["كروس فيت", "يوغا صباحية", "سبينينغ", "بوتكامب", "زومبا", "ملاكمة", "تمدد واسترخاء", "كروس فيت متقدم"];
const EN_CLASS_NAMES = ["CrossFit", "Morning Yoga", "Spinning", "Bootcamp", "Zumba", "Boxing", "Stretch & Relax", "Advanced CrossFit"];

const AR_HALLS = ["قاعة A", "قاعة B", "قاعة C", "استوديو 1", "استوديو 2"];
const EN_HALLS = ["Hall A", "Hall B", "Hall C", "Studio 1", "Studio 2"];

const AR_DAYS = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
const EN_DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

const AR_WORKOUT_PROGRAMS = ["برنامج المبتدئين", "تضخيم متقدم", "تجفيف", "قوة ٥×٥", "تحمل القلب", "تأهيل ما بعد الإصابة", "لياقة عامة"];
const EN_WORKOUT_PROGRAMS = ["Starter Plan", "Advanced Hypertrophy", "Cutting", "5×5 Strength", "Cardio Endurance", "Post-Injury Rehab", "General Fitness"];

const AR_GOALS = ["خسارة وزن", "بناء عضل", "قوة", "تحمل", "تأهيل"];
const EN_GOALS = ["Weight loss", "Muscle gain", "Strength", "Endurance", "Rehab"];

const AR_LEVELS = ["مبتدئ", "متوسط", "متقدم"];
const EN_LEVELS = ["Beginner", "Intermediate", "Advanced"];

const AR_GYM_EQUIP = ["جهاز المشي", "دراجة ثابتة", "جهاز التجديف", "بنش ضغط", "راك القرفصاء", "دمبل قابل للتعديل", "كيبل كروس", "سميث ماشين", "بنش معدل", "جهاز الإليبتيكال"];
const EN_GYM_EQUIP = ["Treadmill", "Stationary Bike", "Rowing Machine", "Press Bench", "Squat Rack", "Adjustable Dumbbells", "Cable Crossover", "Smith Machine", "Incline Bench", "Elliptical"];

const AR_GYM_ZONES = ["منطقة الأثقال", "الكارديو", "الوظيفي", "التمدد"];
const EN_GYM_ZONES = ["Weights Area", "Cardio", "Functional", "Stretching"];

const AR_NUTRITION_PLANS = ["خطة التوازن", "خطة التجفيف", "تضخيم عضلي", "كيتو مرن", "نباتي متوازن", "أداء رياضي"];
const EN_NUTRITION_PLANS = ["Balance Plan", "Cutting Plan", "Muscle Bulk", "Flexible Keto", "Balanced Vegan", "Athlete Performance"];

const AR_LOCKER_TYPES = ["يومي", "شهري", "سنوي"];
const EN_LOCKER_TYPES = ["Daily", "Monthly", "Annual"];

const AR_BARBER_SVCS = ["قص شعر", "حلاقة ذقن", "تصفيف", "علاج شعر", "صبغة"];
const EN_BARBER_SVCS = ["Haircut", "Beard Trim", "Styling", "Hair Treatment", "Coloring"];

const AR_BARBER_PLANS = ["باقة القص الشهرية", "باقة العناية الفاخرة", "عضوية ربع سنوية", "باقة العريس", "عضوية سنوية VIP"];
const EN_BARBER_PLANS = ["Monthly Cut Package", "Premium Care Package", "Quarterly Membership", "Groom Package", "VIP Annual"];

const AR_CARS = ["تويوتا كورولا", "هيونداي إلنترا", "كيا سيراتو", "تويوتا يارس", "شيفروليه كروز", "نيسان صني"];
const EN_CARS = ["Toyota Corolla", "Hyundai Elantra", "Kia Cerato", "Toyota Yaris", "Chevrolet Cruze", "Nissan Sunny"];

const AR_INSTRUCTORS = ["أ. سعد الدوسري", "أ. ماجد الحربي", "أ. بندر العتيبي", "أ. ريم القحطاني", "أ. تركي المطيري"];
const EN_INSTRUCTORS = ["Saad Aldosari", "Majed Alharbi", "Bandar Alotaibi", "Reem Alqahtani", "Turki Almutairi"];

/* ---- ROUND 149 — university-context student vocabulary: college +
   specialization + academic year + credit hours. The students preset is
   shared across K-12 / kindergarten / university / institute / e-learning,
   so the new columns ride ALONGSIDE the existing K-12 "grade" column — K-12
   workspaces keep showing grade, university workspaces additionally show
   college / specialization / year / credits (parents want full info either
   way). AR_SPECIALIZATIONS is distinct from the gym AR_SPECIALTIES above. */
const AR_COLLEGES_STU = ["كلية الطب", "كلية الهندسة", "كلية الحاسب", "كلية إدارة الأعمال", "كلية الصيدلة", "كلية الحقوق", "كلية العلوم", "كلية الآداب"];
const EN_COLLEGES_STU = ["Medicine", "Engineering", "Computer Science", "Business", "Pharmacy", "Law", "Science", "Arts"];
const AR_SPECIALIZATIONS = ["علوم حاسب", "هندسة مدنية", "طب عام", "إدارة أعمال", "صيدلة سريرية", "قانون عام", "فيزياء", "لغة عربية", "كيمياء", "رياضيات", "هندسة معمارية", "تمريض"];
const EN_SPECIALIZATIONS = ["Computer Science", "Civil Engineering", "General Medicine", "Business Admin", "Clinical Pharmacy", "Public Law", "Physics", "Arabic Language", "Chemistry", "Mathematics", "Architecture", "Nursing"];

/* ------------------------------------------------------------------ */
/* ROUND 129 — sector vocabulary (system-matched demo data)            */
/* ------------------------------------------------------------------ */

/**
 * One sector's domain vocabulary — every pool is a bilingual [ar, en] pair.
 * The generic fallback preset and the inventory preset draw from these so a
 * hotel workspace's demo rows read like a hotel (rooms, buffets, housekeeping
 * supplies) while a clinic's read like a clinic — the owner's directive:
 * «كل نظام يجب أن يحصل على بيانات متطابقة له». Unknown/absent sector → the
 * historical generic pools (nothing changes for callers that pass nothing).
 */
export interface SectorVocab {
  /** generic-preset record titles ("what this row is about") */
  things: [string[], string[]];
  /** generic-preset category labels */
  cats: [string[], string[]];
  /** inventory item names */
  invItems: [string[], string[]];
  /** inventory category labels */
  invCats: [string[], string[]];
  /** inventory supplier org names */
  invSuppliers: [string[], string[]];
  /** inventory storage location labels */
  invLocations: [string[], string[]];
}

const SECTOR_VOCAB: Record<string, SectorVocab> = {
  health: {
    things: [
      ["استشارة تخصصية", "فحص دم شامل", "أشعة صدر", "تطعيم موسمي", "جلسة علاج طبيعي", "تحليل هرمونات", "فحص نظر شامل", "متابعة حمل", "غسيل كلوي", "فحص سمع"],
      ["Specialist consult", "Full blood panel", "Chest X-ray", "Seasonal vaccine", "Physio session", "Hormone panel", "Full eye exam", "Pregnancy follow-up", "Dialysis session", "Hearing test"],
    ],
    cats: [
      ["علاجية", "تشخيصية", "مخبرية", "وقائية", "إدارية"],
      ["Therapeutic", "Diagnostic", "Laboratory", "Preventive", "Administrative"],
    ],
    invItems: [AR_SUPPLY, EN_SUPPLY],
    invCats: [
      ["مستهلكات طبية", "أجهزة", "تعقيم", "مخبريات", "قرطاسية"],
      ["Consumables", "Devices", "Sterilization", "Lab items", "Stationery"],
    ],
    invSuppliers: [AR_INV_SUPPLIERS, EN_INV_SUPPLIERS],
    invLocations: [AR_INV_LOCATIONS, EN_INV_LOCATIONS],
  },
  education: {
    things: [
      ["اختبار منتصف الفصل", "مشروع تخرج", "رحلة علمية", "دورة تقوية", "بطاقة تقييم مهارات", "مسابقة ثقافية", "حصة افتراضية", "تقرير أداء فصلي", "ورشة مواهب", "بطاقة تكرار"],
      ["Midterm exam", "Graduation project", "Science trip", "Reinforcement course", "Skills rubric", "Cultural contest", "Virtual class", "Term report card", "Talent workshop", "Attendance card"],
    ],
    cats: [
      ["أكاديمية", "أنشطة", "تقييم", "إدارية", "تقنية"],
      ["Academic", "Activities", "Assessment", "Administrative", "Technical"],
    ],
    invItems: [
      ["كتب منهجية", "دفاتر A4", "أقلام حبر", "طباشير أبيض", "أجهزة عرض", "طاولات مختبر", "كراسي فصول", "سبورات ذكية", "حقيبة رياضيات", "أوراق رسم"],
      ["Curriculum books", "A4 notebooks", "Ink pens", "White chalk", "Projectors", "Lab tables", "Classroom chairs", "Smart boards", "Math kits", "Drawing paper"],
    ],
    invCats: [
      ["قرطاسية", "أثاث تعليمي", "تقنية", "مختبرات", "رياضة"],
      ["Stationery", "Furniture", "Technology", "Labs", "Sports"],
    ],
    invSuppliers: [
      ["مؤسسة التوريد المدرسي", "شركة التعليمات الحديثة", "مكتبة النور التجارية", "شركة التقنية التعليمية", "مؤسسة القرطاسية الموحدة"],
      ["School Supply Est.", "Modern Educationals Co.", "Al-Noor Bookstore", "EdTech Co.", "Unified Stationery Est."],
    ],
    invLocations: [
      ["مستودع المدرسة", "غرفة القرطاسية", "مختبر العلوم", "معرض الحاسب", "الصالة الرياضية"],
      ["School warehouse", "Stationery room", "Science lab", "Computer hall", "Sports hall"],
    ],
  },
  retail: {
    things: [
      ["فاتورة مبيعات نقدية", "استبدال منتج", "طلب توريد أسبوعي", "عرض ترويجي موسمي", "جرد رف", "خصم ولاء", "مرتجع مشتريات", "طلب مخصص", "تحديث أسعار", "بطاقة هدية"],
      ["Cash sale invoice", "Product exchange", "Weekly supply order", "Seasonal promo", "Shelf count", "Loyalty discount", "Purchase return", "Custom order", "Price update", "Gift card"],
    ],
    cats: [
      ["مبيعات", "مخزون", "عروض", "عملاء", "فروع"],
      ["Sales", "Stock", "Promotions", "Customers", "Branches"],
    ],
    invItems: [AR_PRODUCTS, EN_PRODUCTS],
    invCats: [
      ["بقالة", "مشروبات", "منظفات", "عناية شخصية", "أدوات منزلية"],
      ["Grocery", "Beverages", "Cleaning", "Personal care", "Household"],
    ],
    invSuppliers: [
      ["شركة التوزيع الغذائي", "مؤسسة الجملة التجارية", "شركة المستهلكات الموحدة", "موزع المشروبات الوطني", "شركة المنظفات الحديثة"],
      ["Food Distribution Co.", "Wholesale Trade Est.", "Consumer Goods Co.", "National Beverage Dist.", "Modern Detergents Co."],
    ],
    invLocations: [
      ["مستودع الفرع", "رف A", "رف B", "غرفة التبريد", "منطقة الاستلام"],
      ["Branch warehouse", "Shelf A", "Shelf B", "Cold room", "Receiving area"],
    ],
  },
  hospitality: {
    things: [
      ["حجز جناح ليلتين", "بوفيه إفطار", "حفلة خاصة", "تنظيف يومي", "طلب خدمة غرف", "ترقية غرفة", "حجز قاعة مؤتمرات", "خدمة كبار الشخصيات", "عربة ضيافة", "تحضير حدث"],
      ["Suite booking · 2 nights", "Breakfast buffet", "Private party", "Daily housekeeping", "Room-service order", "Room upgrade", "Conference hall booking", "VIP service", "Hospitality cart", "Event setup"],
    ],
    cats: [
      ["إقامة", "مطعم", "فعاليات", "صيانة", "خدمات"],
      ["Stay", "Restaurant", "Events", "Maintenance", "Services"],
    ],
    invItems: [
      ["مناشف حمام", "شراشف قطنية", "مواد تنظيف", "مستلزمات إفطار", "أدوات مطبخ", "صابون ضيافة", "أكواب ورقية", "معطر جو", "مفاتيح مغناطيسية", "عربات خدمة"],
      ["Bath towels", "Cotton bed sheets", "Cleaning supplies", "Breakfast supplies", "Kitchenware", "Guest soap", "Paper cups", "Air freshener", "Magnetic keycards", "Service carts"],
    ],
    invCats: [
      ["غرف ونوم", "مطبخ", "تنظيف", "ضيافة", "صيانة"],
      ["Rooms & linens", "Kitchen", "Cleaning", "Guest amenities", "Maintenance"],
    ],
    invSuppliers: [
      ["شركة الفنادق للتجهيزات", "مؤسسة الغسيل المركزي", "شركة الضيافة الموحدة", "موزع المواد الغذائية", "مؤسسة النظافة الفندقية"],
      ["Hotel Equipment Co.", "Central Laundry Est.", "Hospitality Supplies Co.", "Food Distributor", "Hotel Hygiene Est."],
    ],
    invLocations: [
      ["مستودع الفندق", "غرفة الكتان", "المطبخ الرئيسي", "غرفة الصيانة", "الطابق الأول"],
      ["Hotel warehouse", "Linen room", "Main kitchen", "Maintenance room", "First floor"],
    ],
  },
  services: {
    things: [
      ["حجز موعد خدمة", "عقد صيانة سنوي", "جلسة استشارية", "متابعة بعد الخدمة", "طلب خدمة عاجلة", "تجديد اشتراك", "زيارة ميدانية", "عرض سعر", "معاينة مجانية", "خدمة كبار"],
      ["Service booking", "Annual maintenance contract", "Advisory session", "Post-service follow-up", "Urgent service request", "Subscription renewal", "Site visit", "Price quote", "Free inspection", "Premium service"],
    ],
    cats: [
      ["حجوزات", "خدمات", "عقود", "متابعة", "فواتير"],
      ["Bookings", "Services", "Contracts", "Follow-up", "Invoicing"],
    ],
    invItems: [
      ["أدوات فنية", "معدات قياس", "زي موحد", "مستهلكات تشغيل", "أجهزة محمولة", "عدد صيانة", "خوذ سلامة", "أسلاك وتوصيلات", "بطاريات", "طباعة مستندات"],
      ["Technical tools", "Measurement devices", "Uniforms", "Operational consumables", "Portable devices", "Maintenance tools", "Safety helmets", "Wiring & connectors", "Batteries", "Document printing"],
    ],
    invCats: [
      ["معدات", "مستهلكات", "زي ومظهر", "تقنية", "مستندات"],
      ["Equipment", "Consumables", "Uniforms", "Technology", "Documents"],
    ],
    invSuppliers: [
      ["شركة العدد الفنية", "مؤسسة التجهيزات الخدمية", "شركة السلامة المهنية", "موزع التقنية المحمولة", "مطبعة النظام"],
      ["Technical Tools Co.", "Service Equipment Est.", "Occupational Safety Co.", "Portable Tech Dist.", "Alnizam Press"],
    ],
    invLocations: [
      ["مستودع المقر", "سيارة الفريق", "غرفة الأدوات", "مكتب المشرف", "خزانة المستندات"],
      ["HQ warehouse", "Team vehicle", "Tools room", "Supervisor office", "Documents cabinet"],
    ],
  },
  finance: {
    things: [
      ["قيد يومية", "تسوية بنكية", "إقرار ضريبي", "فاتورة مورد", "أمر صرف", "مذكرة تسوية", "تقرير تدفق نقدي", "مراجعة ربع سنوية", "تحويل رواتب", "مخصص ديون"],
      ["Journal entry", "Bank reconciliation", "Tax filing", "Vendor invoice", "Payment order", "Adjustment memo", "Cash-flow report", "Quarterly review", "Payroll transfer", "Debt provision"],
    ],
    cats: [
      ["إيرادات", "مصروفات", "ضرائب", "مراجعات", "تحويلات"],
      ["Revenue", "Expenses", "Taxes", "Reviews", "Transfers"],
    ],
    invItems: [
      ["دفاتر قيود", "طابعات فواتير", "خزائن حديدية", "أوراق مالية", "أجهزة حاسبة", "حبر طابعات", "ملفات أرشفة", "أختام رسمية", "ماسحات مستندات", "سجلات رسمية"],
      ["Ledger books", "Invoice printers", "Steel cabinets", "Security paper", "Calculators", "Printer ink", "Archive files", "Official seals", "Document scanners", "Official registers"],
    ],
    invCats: [
      ["قرطاسية مالية", "تقنية", "أمن", "أرشفة", "عام"],
      ["Financial stationery", "Technology", "Security", "Archiving", "General"],
    ],
    invSuppliers: [
      ["شركة الأنظمة المالية", "مؤسسة القرطاسية المكتبية", "شركة الحماية والأمان", "موزع الأجهزة المكتبية", "مركز الأرشفة الرقمي"],
      ["Financial Systems Co.", "Office Stationery Est.", "Protection & Safety Co.", "Office Devices Dist.", "Digital Archiving Center"],
    ],
    invLocations: [
      ["قسم المحاسبة", "غرفة الأرشيف", "الخزينة", "مكتب المراجع", "مستودع المقر"],
      ["Accounting dept.", "Archive room", "Vault", "Auditor office", "HQ warehouse"],
    ],
  },
  logistics: {
    things: [
      ["بوليصة شحن دولي", "صيانة دورية شاحنة", "إدخال مستودع", "تخليص جمركي", "مسار توصيل يومي", "تتبع شحنة", "تحميل حاوية", "تقرير أسطول", "إعادة جدولة", "توزيع فروع"],
      ["International shipment BOL", "Truck periodic maintenance", "Warehouse intake", "Customs clearance", "Daily delivery route", "Shipment tracking", "Container loading", "Fleet report", "Rescheduling", "Branch distribution"],
    ],
    cats: [
      ["شحن", "أسطول", "مستودعات", "تخليص", "توصيل"],
      ["Shipping", "Fleet", "Warehousing", "Clearance", "Delivery"],
    ],
    invItems: [
      ["إطارات شاحنات", "زيول ديزل", "أحزمة تثبيت", "بطاريات مركبات", "زي سائقين", "ملصقات شحن", "أغلفة بلاستيك", "رافعات يدوية", "أجهزة تتبع GPS", "أدوات إصلاح"],
      ["Truck tires", "Diesel drums", "Securing straps", "Vehicle batteries", "Driver uniforms", "Shipping labels", "Plastic wraps", "Hand jacks", "GPS trackers", "Repair tools"],
    ],
    invCats: [
      ["قطع مركبات", "وقود", "تغليف", "تقنية", "أمان"],
      ["Vehicle parts", "Fuel", "Packaging", "Technology", "Safety"],
    ],
    invSuppliers: [
      ["شركة قطع غيار النقل", "محطات الوقود الموحدة", "شركة مواد التغليف", "موزع أجهزة التتبع", "شركة السلامة المرورية"],
      ["Transport Spare Parts Co.", "Unified Fuel Stations", "Packaging Materials Co.", "Tracking Devices Dist.", "Road Safety Co."],
    ],
    invLocations: [
      ["المستودع الرئيسي", "ساحة الشاحنات", "غرفة الصيانة", "منصة التحميل", "مستودع فرعي"],
      ["Main warehouse", "Truck yard", "Maintenance bay", "Loading dock", "Secondary warehouse"],
    ],
  },
  agriculture: {
    things: [
      ["دورة ري ذكية", "تطعيم قطيع", "حصاد موسمي", "تقرير إنتاج", "خلطة علف", "فحص تربة", "صيانة مضخات", "شحنة تصدير", "مراقبة بيوت محمية", "تسجيل محصول"],
      ["Smart irrigation cycle", "Herd vaccination", "Seasonal harvest", "Production report", "Feed mix", "Soil test", "Pump maintenance", "Export shipment", "Greenhouse monitoring", "Crop logging"],
    ],
    cats: [
      ["إنتاج", "ري", "صحة حيوان", "حصاد", "مستلزمات"],
      ["Production", "Irrigation", "Animal health", "Harvest", "Supplies"],
    ],
    invItems: [
      ["بذور محسّنة", "أسمدة مركبة", "مبيدات آمنة", "خراطيم ري", "أعلاف مركزة", "لقاحات بيطرية", "أغطية بيوت محمية", "مضخات مياه", "قفازات زراعية", "صناديق حصاد"],
      ["Improved seeds", "Compound fertilizers", "Safe pesticides", "Irrigation hoses", "Concentrated feed", "Veterinary vaccines", "Greenhouse covers", "Water pumps", "Farm gloves", "Harvest crates"],
    ],
    invCats: [
      ["بذور وأسمدة", "ري", "أعلاف", "بيطرية", "أدوات"],
      ["Seeds & fertilizers", "Irrigation", "Feed", "Veterinary", "Tools"],
    ],
    invSuppliers: [
      ["شركة المستلزمات الزراعية", "مؤسسة الأعلاف الوطنية", "شركة الري الحديث", "الشركة البيطرية الموحدة", "مؤسسة البذور المحسّنة"],
      ["Agricultural Supplies Co.", "National Feed Est.", "Modern Irrigation Co.", "United Veterinary Co.", "Improved Seeds Est."],
    ],
    invLocations: [
      ["مخزن المزرعة", "غرفة الأعلاف", "وحدة الري", "البيت المحمي", "ساحة الحصاد"],
      ["Farm store", "Feed room", "Irrigation unit", "Greenhouse", "Harvest yard"],
    ],
  },
  industry: {
    things: [
      ["أمر تشغيل", "صيانة وقائية لخط", "فحص جودة دفعة", "إجراء سلامة", "رسم هندسي", "تقرير معاينة", "طلب مواد", "اختبار تحمل", "شهادة مطابقة", "تفريغ حمولة"],
      ["Work order", "Line preventive maintenance", "Batch QC inspection", "Safety procedure", "Engineering drawing", "Inspection report", "Material request", "Stress test", "Compliance certificate", "Unloading"],
    ],
    cats: [
      ["إنتاج", "صيانة", "جودة", "سلامة", "مشاريع"],
      ["Production", "Maintenance", "Quality", "Safety", "Projects"],
    ],
    invItems: [
      ["قفازات صناعية", "خوذ سلامة", "زي مقاوم للحرارة", "قطع غيار خطوط", "زيوت تشغيل", "مثاقب كهربائية", "أسلاك لحام", "أقراص قطع", "مواد تغليف", "أجهزة قياس"],
      ["Industrial gloves", "Safety helmets", "Heat-resistant suits", "Line spare parts", "Machine oils", "Electric drills", "Welding wires", "Cutting discs", "Packaging materials", "Measurement devices"],
    ],
    invCats: [
      ["سلامة", "قطع غيار", "مواد خام", "أدوات", "تغليف"],
      ["Safety", "Spare parts", "Raw materials", "Tools", "Packaging"],
    ],
    invSuppliers: [
      ["شركة السلامة الصناعية", "مؤسسة قطع الغيار الآلية", "شركة المعادن الأولية", "موزع الأدوات الكهربائية", "شركة التغليف الصناعي"],
      ["Industrial Safety Co.", "Machine Spare Parts Est.", "Primary Metals Co.", "Power Tools Dist.", "Industrial Packaging Co."],
    ],
    invLocations: [
      ["مخزن المصنع", "خط الإنتاج A", "غرفة الأدوات", "منطقة الصيانة", "ساحة الخامات"],
      ["Factory store", "Production line A", "Tools room", "Maintenance zone", "Raw yard"],
    ],
  },
  media: {
    things: [
      ["حملة إعلانية موسمية", "منشور محتوى", "هوية بصرية", "جدولة نشر", "تقرير وصول", "إعلان ممول", "مقال تحريري", "تصوير احترافي", "نشرة بريدية", "مؤثر صوتي"],
      ["Seasonal ad campaign", "Content post", "Visual identity", "Publishing schedule", "Reach report", "Sponsored ad", "Editorial article", "Professional shoot", "Newsletter", "Sound effect"],
    ],
    cats: [
      ["حملات", "محتوى", "تصميم", "نشر", "تحليلات"],
      ["Campaigns", "Content", "Design", "Publishing", "Analytics"],
    ],
    invItems: [
      ["كاميرات احترافية", "عدسات تصوير", "حوامل إضاءة", "بطاقات ذاكرة", "حواسيب تحرير", "تراخيص خطوط", "ميكروفونات", "خلفيات استوديو", "هاردات أرشفة", "لوحات رسم"],
      ["Pro cameras", "Camera lenses", "Light stands", "Memory cards", "Editing workstations", "Font licenses", "Microphones", "Studio backdrops", "Archive drives", "Drawing tablets"],
    ],
    invCats: [
      ["تقنية", "إضاءة", "صوت", "تراخيص", "مكاتب"],
      ["Technology", "Lighting", "Audio", "Licenses", "Office"],
    ],
    invSuppliers: [
      ["شركة المعدات الإعلامية", "موزع التقنية الإبداعية", "شركة التراخيص الرقمية", "مؤسسة الاستوديو المتكامل", "شركة الصوتيات الاحترافية"],
      ["Media Equipment Co.", "Creative Tech Dist.", "Digital Licenses Co.", "Full Studio Est.", "Pro Audio Co."],
    ],
    invLocations: [
      ["استوديو التصوير", "غرفة المونتاج", "مخزن المعدات", "مكتب الإبداع", "خزانة التراخيص"],
      ["Photo studio", "Editing room", "Equipment store", "Creative office", "Licenses cabinet"],
    ],
  },
  hr: {
    things: [
      ["طلب توظيف", "مسير رواتب شهري", "دورة تدريبية", "تقييم أداء سنوي", "طلب إجازة", "مكافأة تميّز", "تسوية نهاية خدمة", "برنامج تهيئة", "ترقية وظيفية", "استبيان رضا"],
      ["Recruitment request", "Monthly payroll", "Training course", "Annual performance review", "Leave request", "Excellence bonus", "End-of-service settlement", "Onboarding program", "Promotion", "Satisfaction survey"],
    ],
    cats: [
      ["توظيف", "رواتب", "تدريب", "أداء", "إجازات"],
      ["Recruitment", "Payroll", "Training", "Performance", "Leave"],
    ],
    invItems: [
      ["زي موحد", "بطاقات تعريف", "أجهزة بصمة", "قرطاسية مكتبية", "ميداليات تكريم", "درع إنجاز", "لوحات إرشادية", "أجهزة تكييف", "كتب تطوير", "بطاقات هدايا"],
      ["Uniforms", "ID cards", "Biometric devices", "Office stationery", "Honor medals", "Achievement shields", "Signage boards", "AC units", "Development books", "Gift cards"],
    ],
    invCats: [
      ["زي", "تقنية", "قرطاسية", "تكريم", "عام"],
      ["Uniforms", "Technology", "Stationery", "Recognition", "General"],
    ],
    invSuppliers: [
      ["شركة الخدمات المواردية", "مؤسسة التجهيزات المكتبية", "شركة أنظمة الحضور", "مركز التدريب المعتمد", "مؤسسة الهدايا والدروع"],
      ["HR Services Co.", "Office Equipment Est.", "Attendance Systems Co.", "Certified Training Center", "Gifts & Shields Est."],
    ],
    invLocations: [
      ["مكتب الموارد", "غرفة التدريب", "مخزن عام", "الاستقبال", "خزانة الملفات"],
      ["HR office", "Training room", "General store", "Reception", "Files cabinet"],
    ],
  },
  fun: {
    things: [
      ["تذكرة جلسة", "بطولة أسبوعية", "تجديد اشتراك", "حجز خاص", "بطاقة هدايا", "مسابقة موسمية", "حفلة خاصة", "فعالية عائلية", "رحلة ملاهي", "درس تدريبي"],
      ["Session ticket", "Weekly tournament", "Subscription renewal", "Private booking", "Gift card", "Seasonal contest", "Private party", "Family event", "Park trip", "Coaching lesson"],
    ],
    cats: [
      ["جلسات", "اشتراكات", "بطولات", "معدات", "ضيافة"],
      ["Sessions", "Subscriptions", "Tournaments", "Equipment", "Hospitality"],
    ],
    invItems: [
      ["زحاليق", "كرات رياضية", "أجهزة ألعاب", "أحبال أمان", "زي персонаل", "بطاقات RFID", "أكواب تذكارية", "إضاءة مسرح", "مكبرات صوت", "مستلزمات حفلات"],
      ["Slides", "Sports balls", "Gaming machines", "Safety harnesses", "Staff uniforms", "RFID cards", "Souvenir cups", "Stage lighting", "Speakers", "Party supplies"],
    ],
    invCats: [
      ["ألعاب", "تقنية", "صوتيات", "زي", "مستهلكات"],
      ["Games", "Technology", "Audio", "Uniforms", "Consumables"],
    ],
    invSuppliers: [
      ["شركة أجهزة الترفيه", "مؤسسة الصوت والإضاءة", "شركة بطاقات الدخول", "موزع الألعاب الرياضية", "مؤسسة الضيافة والفعاليات"],
      ["Entertainment Machines Co.", "Sound & Light Est.", "Entry Cards Co.", "Sports Games Dist.", "Events & Hospitality Est."],
    ],
    invLocations: [
      ["غرفة الأجهزة", "منطقة الألعاب", "مخزن الصوتيات", "مكتب الإدارة", "خزانة البطاقات"],
      ["Machines room", "Games area", "Audio store", "Admin office", "Cards cabinet"],
    ],
  },
  legal: {
    things: [
      ["مذكرة دفاع", "عقد خدمات", "استشارة قانونية", "جلسة محكمة", "مراجعة عقد", "طلب توثيق", "إنذار نظامي", "لائحة اعتراض", "تقرير خبرة", "متابعة تنفيذ"],
      ["Defense memo", "Service agreement", "Legal consultation", "Court hearing", "Contract review", "Notarization request", "Formal notice", "Objection brief", "Expert report", "Enforcement follow-up"],
    ],
    cats: [
      ["قضايا", "عقود", "استشارات", "جلسات", "متابعة"],
      ["Cases", "Contracts", "Consultations", "Hearings", "Follow-up"],
    ],
    invItems: [
      ["ملفات قضايا", "أختام رسمية", "ورق قانوني فاخر", "طابعات مستندات", "خزائن محكمة", "أجهزة تسجيل جلسات", "كتب قانونية", "بطاقات مرافعين", "قرطاسية مكتبية", "ماسحات مستندات"],
      ["Case files", "Official seals", "Premium legal paper", "Document printers", "Court cabinets", "Hearing recorders", "Law books", "Counsel cards", "Office stationery", "Document scanners"],
    ],
    invCats: [
      ["مستندات", "قرطاسية", "تقنية", "أرشفة", "مرجع"],
      ["Documents", "Stationery", "Technology", "Archiving", "Reference"],
    ],
    invSuppliers: [
      ["مؤسسة التجهيزات القانونية", "شركة الأرشفة الرقمية", "مكتبة القانون التجارية", "موزع الأجهزة المكتبية", "مطبعة الوثائق"],
      ["Legal Equipment Est.", "Digital Archiving Co.", "Commercial Law Bookstore", "Office Devices Dist.", "Documents Press"],
    ],
    invLocations: [
      ["مكتب المحامي", "غرفة الأرشيف", "خزانة القضايا", "الاستقبال", "غرفة الجلسات"],
      ["Counsel office", "Archive room", "Cases cabinet", "Reception", "Meeting room"],
    ],
  },
  nonprofit: {
    things: [
      ["حملة تبرعات", "تسجيل متطوع", "فعالية مجتمعية", "مشروع خيري", "توزيع سلال", "تقرير شفافية", "منحة تعليمية", "رعاية أيتام", "ورشة توعية", "شكر داعمين"],
      ["Donation drive", "Volunteer signup", "Community event", "Charity project", "Basket distribution", "Transparency report", "Education grant", "Orphan care", "Awareness workshop", "Donor appreciation"],
    ],
    cats: [
      ["تبرعات", "فعاليات", "متطوعون", "مشاريع", "تواصل"],
      ["Donations", "Events", "Volunteers", "Projects", "Communication"],
    ],
    invItems: [
      ["سلال غذائية", "بطاقات متطوعين", "قمصان فعاليات", "لافتات إرشادية", "أجهزة تسجيل", "مياه معدنية", "أدوية أساسية", "أغطية شتوية", "قرطاسية أطفال", "أجهزة عرض"],
      ["Food baskets", "Volunteer vests", "Event t-shirts", "Guidance banners", "Registration devices", "Water bottles", "Basic medicines", "Winter blankets", "Children stationery", "Projectors"],
    ],
    invCats: [
      ["إغاثة", "فعاليات", "تقنية", "قرطاسية", "عام"],
      ["Relief", "Events", "Technology", "Stationery", "General"],
    ],
    invSuppliers: [
      ["شركة الإغاثة الموحدة", "مؤسسة الفعاليات الخيرية", "شركة التجهيزات المجتمعية", "موزع المواد الغذائية", "مطبعة اللافتات"],
      ["United Relief Co.", "Charity Events Est.", "Community Supplies Co.", "Food Materials Dist.", "Banners Press"],
    ],
    invLocations: [
      ["مخزن الجمعية", "غرفة التوزيع", "مقر الفعاليات", "مكتب التنسيق", "خزانة التسجيل"],
      ["Association store", "Distribution room", "Events HQ", "Coordination office", "Registration cabinet"],
    ],
  },
  general: {
    things: [
      ["طلب صيانة", "زيارة فنية", "تمديد ضمان", "تركيب جهاز", "معاينة موقع", "فاتورة خدمة", "متابعة عميل", "قطع غيار", "استشارة فنية", "أمر شراء"],
      ["Maintenance request", "Technical visit", "Warranty extension", "Device install", "Site inspection", "Service invoice", "Client follow-up", "Spare parts", "Technical consult", "Purchase order"],
    ],
    cats: [
      ["أعمال", "مواعيد", "ضمان", "طلبات", "متابعة"],
      ["Jobs", "Appointments", "Warranty", "Requests", "Follow-up"],
    ],
    invItems: [
      ["عدد صيانة", "قطع غيار شائعة", "مواد تركيب", "أجهزة قياس", "زي فني", "سلالم ألومنيوم", "مثاقب وشفرات", "مواد عزل", "أدوات سباكة", "أسلاك كهربائية"],
      ["Maintenance tools", "Common spare parts", "Install materials", "Measurement devices", "Technician suits", "Aluminum ladders", "Drills & blades", "Insulation materials", "Plumbing tools", "Electrical wires"],
    ],
    invCats: [
      ["عدد", "قطع غيار", "مواد", "تقنية", "زي"],
      ["Tools", "Spare parts", "Materials", "Technology", "Uniforms"],
    ],
    invSuppliers: [
      ["شركة العدد الصناعية", "مؤسسة قطع الغيار الموحدة", "شركة مواد البناء", "موزع الأجهزة الفنية", "مؤسسة السلامة المهنية"],
      ["Industrial Tools Co.", "Unified Spare Parts Est.", "Building Materials Co.", "Technical Devices Dist.", "Occupational Safety Est."],
    ],
    invLocations: [
      ["سيارة الفني", "مخزن الورشة", "غرفة العدد", "منطقة التركيب", "مكتب الاستقبال"],
      ["Technician vehicle", "Workshop store", "Tools room", "Install zone", "Reception office"],
    ],
  },
};

/** Module ids that describe PEOPLE (customers/staff/members…) — the
 *  generic preset keeps person names for these even under a sector flavor;
 *  everything else (documents/reports/tasks/assets…) draws sector THINGS.
 *  Plural-aware: "clients"/"members"/"beneficiaries" singularize before
 *  the root test. */
const ENTITY_MODULE_RE =
  /(customer|client|student|teacher|staff|driver|member|supplier|partner|employee|patient|parent|volunteer|owner|subscriber|player|crew|lead|beneficiar|nurse|doctor|guest|waiter|team|user|coach|instructor|agent|visitor|contact|author|participant|applicant|trainee|guardian|account)$/;

function isEntityModule(moduleId: string): boolean {
  if (ENTITY_MODULE_RE.test(moduleId)) return true;
  /* crude singularization (s / es / ies) — enough for catalog ids */
  const singular = moduleId.replace(/(ies|es|s)$/, "");
  return singular.length > 2 && ENTITY_MODULE_RE.test(singular);
}

function sectorVocabOf(sector: string | undefined): SectorVocab | null {
  return sector ? (SECTOR_VOCAB[sector] ?? null) : null;
}
/* ROUND 132 — person/pick/phone/padded/money/dateStr/timeStr moved to
 * module-presets/preset-kit.ts (single source, imported above). */

/* ------------------------------------------------------------------ */
/* presets                                                              */
/* ------------------------------------------------------------------ */

const PRESETS: Record<string, ModulePreset> = {
  patients: {
    cols: [
      { key: "code", ar: "رقم الملف", en: "File #", kind: "id" },
      { key: "name", ar: "المريض", en: "Patient", kind: "text" },
      { key: "age", ar: "العمر", en: "Age", kind: "num" },
      { key: "gender", ar: "الجنس", en: "Gender", kind: "text" },
      { key: "phone", ar: "الجوال", en: "Mobile", kind: "text" },
      { key: "lastVisit", ar: "آخر زيارة", en: "Last visit", kind: "date" },
      { key: "doctor", ar: "الطبيب", en: "Doctor", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "stable", ar: "مستقر", en: "Stable", tone: "emerald" },
      { key: "followup", ar: "تحت المتابعة", en: "Follow-up", tone: "sky" },
      { key: "critical", ar: "حرج", en: "Critical", tone: "rose" },
      { key: "routine", ar: "متابعة دورية", en: "Routine", tone: "violet" },
    ],
    row: (rng, i, lang) => [
      `MRN-${padded(10240 + i, 8)}`,
      person(rng, lang),
      String(Math.floor(rng() * 62) + 3),
      lang === "ar" ? (rng() > 0.5 ? "ذكر" : "أنثى") : rng() > 0.5 ? "Male" : "Female",
      phone(rng),
      dateStr(rng),
      pick(rng, lang === "ar" ? AR_DOCTORS : EN_DOCTORS),
      pick(rng, ["stable", "followup", "critical", "routine", "stable", "stable"]),
    ],
    count: [22, 34],
  },

  appointments: {
    cols: [
      { key: "code", ar: "رقم الموعد", en: "Appt #", kind: "id" },
      { key: "patient", ar: "المريض", en: "Patient", kind: "text" },
      { key: "doctor", ar: "الطبيب", en: "Doctor", kind: "text" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "time", ar: "الوقت", en: "Time", kind: "text" },
      { key: "type", ar: "النوع", en: "Type", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "confirmed", ar: "مؤكد", en: "Confirmed", tone: "emerald" },
      { key: "waiting", ar: "بانتظار", en: "Waiting", tone: "amber" },
      { key: "done", ar: "مكتمل", en: "Completed", tone: "sky" },
      { key: "cancelled", ar: "ملغى", en: "Cancelled", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      `APT-${padded(4100 + i, 8)}`,
      person(rng, lang),
      pick(rng, lang === "ar" ? AR_DOCTORS : EN_DOCTORS),
      dateStr(rng),
      timeStr(rng),
      lang === "ar" ? pick(rng, ["فحص أولي", "متابعة", "استشارة", "طوارئ"]) : pick(rng, ["First exam", "Follow-up", "Consult", "Emergency"]),
      pick(rng, ["confirmed", "waiting", "done", "cancelled", "confirmed", "done"]),
    ],
    count: [18, 30],
  },

  prescriptions: {
    cols: [
      { key: "code", ar: "الرقم", en: "Rx #", kind: "id" },
      { key: "patient", ar: "المريض", en: "Patient", kind: "text" },
      { key: "drug", ar: "الدواء", en: "Drug", kind: "text" },
      { key: "dose", ar: "الجرعة", en: "Dose", kind: "text" },
      { key: "doctor", ar: "الطبيب", en: "Doctor", kind: "text" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "new", ar: "جديدة", en: "New", tone: "sky" },
      { key: "dispensed", ar: "صُرفت", en: "Dispensed", tone: "emerald" },
      { key: "expired", ar: "منتهية", en: "Expired", tone: "slate" },
    ],
    row: (rng, i, lang) => [
      `RX-${padded(7300 + i, 8)}`,
      person(rng, lang),
      pick(rng, AR_DRUGS),
      pick(rng, ["1×3", "1×2", "2×2", "1×1", "5ml×3"]),
      pick(rng, lang === "ar" ? AR_DOCTORS : EN_DOCTORS),
      dateStr(rng),
      pick(rng, ["new", "dispensed", "dispensed", "expired"]),
    ],
    count: [16, 26],
  },

  lab: {
    cols: [
      { key: "code", ar: "رقم التحليل", en: "Test #", kind: "id" },
      { key: "patient", ar: "المريض", en: "Patient", kind: "text" },
      { key: "type", ar: "نوع التحليل", en: "Test type", kind: "text" },
      { key: "result", ar: "النتيجة", en: "Result", kind: "text" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "ready", ar: "جاهز", en: "Ready", tone: "emerald" },
      { key: "processing", ar: "قيد التنفيذ", en: "Processing", tone: "amber" },
      { key: "sent", ar: "مرسل للطبيب", en: "Sent to doctor", tone: "sky" },
    ],
    row: (rng, i, lang) => [
      `LAB-${padded(5200 + i, 8)}`,
      person(rng, lang),
      lang === "ar"
        ? pick(rng, ["صورة دم كاملة CBC", "سكر صائم FBS", "دهون الدم", "وظائف الكبد", "وظائف الكلى", "فيتامين د", "هرمونات الغدة"])
        : pick(rng, ["CBC", "Fasting glucose", "Lipid panel", "Liver function", "Renal function", "Vitamin D", "Thyroid panel"]),
      lang === "ar" ? pick(rng, ["طبيعي", "طبيعي", "مرتفع قليلاً", "بحاجة لمقارنة"]) : pick(rng, ["Normal", "Normal", "Slightly high", "Compare needed"]),
      dateStr(rng),
      pick(rng, ["ready", "processing", "sent", "ready"]),
    ],
    count: [14, 24],
  },

  pharmacy: {
    cols: [
      { key: "drug", ar: "الدواء", en: "Drug", kind: "text" },
      { key: "category", ar: "الفئة", en: "Category", kind: "text" },
      { key: "batch", ar: "رقم التشغيلة", en: "Batch", kind: "id" },
      { key: "expiry", ar: "تاريخ الانتهاء", en: "Expiry", kind: "date" },
      { key: "stock", ar: "الكمية", en: "Stock", kind: "num" },
      { key: "price", ar: "السعر", en: "Price", kind: "money" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "instock", ar: "متوفر", en: "In stock", tone: "emerald" },
      { key: "low", ar: "منخفض", en: "Low stock", tone: "amber" },
      { key: "out", ar: "نفد", en: "Out", tone: "rose" },
      { key: "expired", ar: "منتهي", en: "Expired", tone: "slate" },
    ],
    row: (rng, i, lang) => {
      const stock = Math.floor(rng() * 240);
      return [
        pick(rng, AR_DRUGS),
        pick(rng, AR_DRUG_CATS),
        `B-${padded(8800 + i, 8)}`,
        dateStr(rng),
        String(stock),
        money(rng, 8, 145).toFixed(2),
        stock > 80 ? "instock" : stock > 25 ? "low" : stock > 0 ? "low" : "out",
      ];
    },
    count: [18, 30],
    moneyKey: "price",
  },

  inventory: {
    /* ROUND 78 — the first 7 columns keep their EXACT legacy order (stored
       rows align to them); the workspace extension columns are APPENDED:
       reorder point, storage location, supplier, expiry date. Readers
       tolerate missing trailing values (see src/lib/inventory-data.ts). */
    cols: [
      { key: "item", ar: "الصنف", en: "Item", kind: "text" },
      { key: "sku", ar: "رمز الصنف", en: "SKU", kind: "id" },
      { key: "category", ar: "الفئة", en: "Category", kind: "text" },
      { key: "qty", ar: "الكمية", en: "Qty", kind: "num" },
      { key: "unit", ar: "تكلفة الوحدة", en: "Unit cost", kind: "money" },
      { key: "total", ar: "القيمة", en: "Value", kind: "money" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
      { key: "reorder", ar: "حد إعادة الطلب", en: "Reorder point", kind: "num" },
      { key: "location", ar: "الموقع", en: "Location", kind: "text" },
      { key: "supplier", ar: "المورد", en: "Supplier", kind: "text" },
      { key: "expiry", ar: "تاريخ الانتهاء", en: "Expiry", kind: "date" },
    ],
    statuses: [
      { key: "instock", ar: "متوفر", en: "In stock", tone: "emerald" },
      { key: "low", ar: "منخفض", en: "Low", tone: "amber" },
      { key: "out", ar: "نفد", en: "Out", tone: "rose" },
      { key: "ordered", ar: "طلب شراء", en: "Reorder", tone: "sky" },
    ],
    row: (rng, _i, lang, sector) => {
      const v = sector ? sectorVocabOf(sector) : null;
      const li = lang === "ar" ? 0 : 1;
      const qty = Math.floor(rng() * 400);
      const unit = money(rng, 3, 260);
      /* reorder point coherent with the status law below: everything at or
         below the point is low / ordered / out, everything above is healthy */
      const reorder = 30 + Math.floor(rng() * 40);
      /* ~28% of stock items are non-perishable (no expiry); the rest expire
         between Oct 2026 and Dec 2027 so the workspace's expiry chips have
         realistic soon/ok spreads (stable — never depends on wall clock) */
      const hasExpiry = rng() > 0.28;
      const m = 10 + Math.floor(rng() * 15);
      const expiry = hasExpiry
        ? `${2026 + Math.floor((m - 1) / 12)}-${padded(((m - 1) % 12) + 1, 2)}-${padded(Math.floor(rng() * 28) + 1, 2)}`
        : "";
      /* ROUND 129 — sector-MATCHED vocabulary: a hotel's stock reads like a
       * hotel (linen, kitchen, guest amenities), a farm's like a farm…
       * Unknown sector keeps the historical medical/general supplies. */
      return [
        v ? pick(rng, v.invItems[li]) : pick(rng, lang === "ar" ? AR_SUPPLY : EN_SUPPLY),
        `SKU-${padded(Math.floor(rng() * 90000) + 10000, 8)}`,
        v
          ? pick(rng, v.invCats[li])
          : lang === "ar"
            ? pick(rng, ["مستهلكات طبية", "أجهزة", "قرطاسية", "تعقيم", "مخبريات"])
            : pick(rng, ["Consumables", "Devices", "Stationery", "Sterilization", "Lab items"]),
        String(qty),
        unit.toFixed(2),
        (unit * qty).toFixed(2),
        qty > 150 ? "instock" : qty > 40 ? "low" : qty > 0 ? "ordered" : "out",
        String(reorder),
        v ? pick(rng, v.invLocations[li]) : pick(rng, lang === "ar" ? AR_INV_LOCATIONS : EN_INV_LOCATIONS),
        v ? pick(rng, v.invSuppliers[li]) : pick(rng, lang === "ar" ? AR_INV_SUPPLIERS : EN_INV_SUPPLIERS),
        expiry,
      ];
    },
    count: [20, 32],
    moneyKey: "total",
  },

  invoices: {
    cols: [
      { key: "code", ar: "رقم الفاتورة", en: "Invoice #", kind: "id" },
      { key: "client", ar: "العميل", en: "Client", kind: "text" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "amount", ar: "المبلغ", en: "Amount", kind: "money" },
      { key: "vat", ar: "الضريبة", en: "VAT", kind: "money" },
      { key: "total", ar: "الإجمالي", en: "Total", kind: "money" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "paid", ar: "مدفوعة", en: "Paid", tone: "emerald" },
      { key: "pending", ar: "معلقة", en: "Pending", tone: "amber" },
      { key: "overdue", ar: "متأخرة", en: "Overdue", tone: "rose" },
      { key: "void", ar: "ملغاة", en: "Void", tone: "slate" },
    ],
    row: (rng, i, lang) => {
      const amount = money(rng, 220, 9800);
      const vat = Math.round(amount * 0.15 * 100) / 100;
      return [
        `INV-2026-${padded(1400 + i, 8)}`,
        person(rng, lang),
        dateStr(rng),
        amount.toFixed(2),
        vat.toFixed(2),
        (amount + vat).toFixed(2),
        pick(rng, ["paid", "paid", "pending", "overdue", "paid", "void"]),
      ];
    },
    count: [24, 36],
    moneyKey: "total",
  },

  /* ROUND 131 — premium CRM preset (9 cols): visits + loyalty points join
   *  orders/spend for RFM-style segmentation. */
  customers: {
    cols: [
      { key: "name", ar: "العميل", en: "Customer", kind: "text" },
      { key: "phone", ar: "الجوال", en: "Mobile", kind: "text" },
      { key: "city", ar: "المدينة", en: "City", kind: "text" },
      { key: "orders", ar: "المشتريات", en: "Orders", kind: "num" },
      { key: "spent", ar: "إجمالي الشراء", en: "Total spent", kind: "money" },
      { key: "points", ar: "نقاط الولاء", en: "Loyalty points", kind: "num" },
      { key: "visits", ar: "الزيارات", en: "Visits", kind: "num" },
      { key: "last", ar: "آخر تعامل", en: "Last order", kind: "date" },
      { key: "status", ar: "الفئة", en: "Tier", kind: "status" },
    ],
    statuses: [
      { key: "gold", ar: "ماسي", en: "Gold", tone: "amber" },
      { key: "active", ar: "نشط", en: "Active", tone: "emerald" },
      { key: "silver", ar: "فضي", en: "Silver", tone: "sky" },
      { key: "inactive", ar: "خامل", en: "Inactive", tone: "slate" },
    ],
    row: (rng, _i, lang) => {
      const orders = Math.floor(rng() * 90) + 1;
      const tier = pick(rng, ["gold", "active", "active", "silver", "inactive"]);
      return [
        person(rng, lang),
        phone(rng),
        pick(rng, lang === "ar" ? AR_CITIES : EN_CITIES),
        String(orders),
        money(rng, 400, 42000).toFixed(2),
        String(Math.floor(orders * (12 + rng() * 30))),
        String(Math.floor(orders * (1.3 + rng()))),
        dateStr(rng),
        tier,
      ];
    },
    count: [22, 34],
    moneyKey: "spent",
  },

  /* ROUND 149 — staff preset EXPANDED to a professional HR dossier (17
   *  columns): employee code, name, national ID, gender, birth date,
   *  department, job title, email, mobile, hire date, contract type,
   *  contract end, shift, salary, bank, IBAN, status. Statuses gained the
   *  new «suspended» state (rose tone). The owner's directive:
   *    «طور من تفاصيل الموظفون ليكون اكثر دقة واحترافية». */
  staff: {
    cols: [
      { key: "code", ar: "الرقم الوظيفي", en: "Employee #", kind: "id" },
      { key: "name", ar: "اسم الموظف", en: "Employee Name", kind: "text" },
      { key: "nationalId", ar: "رقم الهوية", en: "National ID", kind: "id" },
      { key: "gender", ar: "الجنس", en: "Gender", kind: "text" },
      { key: "birthDate", ar: "تاريخ الميلاد", en: "Birth Date", kind: "date" },
      { key: "dept", ar: "القسم", en: "Department", kind: "text" },
      { key: "role", ar: "المسمى الوظيفي", en: "Job Title", kind: "text" },
      { key: "email", ar: "البريد الإلكتروني", en: "Email", kind: "text" },
      { key: "phone", ar: "الجوال", en: "Mobile", kind: "text" },
      { key: "hired", ar: "تاريخ التعيين", en: "Hired Date", kind: "date" },
      { key: "contract", ar: "نوع العقد", en: "Contract Type", kind: "text" },
      { key: "endDate", ar: "نهاية العقد", en: "Contract End", kind: "date" },
      { key: "shift", ar: "الوردية", en: "Shift", kind: "text" },
      { key: "salary", ar: "الراتب", en: "Salary", kind: "money" },
      { key: "bank", ar: "البنك", en: "Bank", kind: "text" },
      { key: "iban", ar: "الآيبان", en: "IBAN", kind: "id" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "onduty", ar: "في الخدمة", en: "On duty", tone: "emerald" },
      { key: "leave", ar: "في إجازة", en: "On leave", tone: "amber" },
      { key: "task", ar: "مهمة خارجية", en: "Field task", tone: "sky" },
      { key: "suspended", ar: "موقوف", en: "Suspended", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      /* a stable Latin-shaped email handle derived from the EN name pool —
       * the same rng window the bilingual `person()` reads, so the demo
       * row stays deterministic per index across reloads.
       *
       * ROUND 150 — TASK J: salary now correlates with ROLE × CONTRACT
       * (the owner's «بطريقة دقيقة جداً» directive). Each role owns a
       * realistic SAR/month band; the contract-type factor scales it
       * (full 100%, part-time 60%, temporary 85%, internship 35%). A
       * junior receptionist on an internship no longer reads as earning
       * the same as a full-time supervisor. */
      const fullName = person(rng, lang);
      const enHandle = person(rng, "en").toLowerCase().replace(/\s+/g, ".");
      const ROLES_AR = ["أخصائي", "ممرض/ة", "فني", "مشرف", "منسق", "محاسب", "موظف استقبال"];
      const ROLES_EN = ["Specialist", "Nurse", "Technician", "Supervisor", "Coordinator", "Accountant", "Receptionist"];
      /* [minBase, maxBase] per role index — SAR/month, full-time baseline */
      const SALARY_BANDS: [number, number][] = [
        [5000, 9000],   /* Specialist */
        [5000, 9000],   /* Nurse     */
        [4500, 8000],   /* Technician */
        [9000, 14000],  /* Supervisor */
        [6000, 10000],  /* Coordinator */
        [8000, 15000],  /* Accountant */
        [4500, 7000],   /* Receptionist */
      ];
      const CONTRACTS_AR = ["دوام كامل", "دوام جزئي", "عقد مؤقت", "تدريب"];
      const CONTRACTS_EN = ["Full-time", "Part-time", "Temporary", "Internship"];
      /* contract factor — internship ~35%, part-time ~60%, temporary ~85% */
      const CONTRACT_FACTOR = [1.0, 0.6, 0.85, 0.35];
      const roleIdx = Math.floor(rng() * ROLES_AR.length);
      const contractIdx = Math.floor(rng() * CONTRACTS_AR.length);
      /* `noUncheckedIndexedAccess` is OFF (tsconfig), so array access
       * returns T directly — no `!` post-fix needed and ESLint-clean. */
      const band = SALARY_BANDS[roleIdx] ?? [4500, 7000];
      const smin = band[0];
      const smax = band[1];
      const factor = CONTRACT_FACTOR[contractIdx] ?? 1;
      const baseSalary = money(rng, smin, smax);
      const salary = Math.round(baseSalary * factor * 100) / 100;
      return [
        `STF-${padded(4500 + i, 8)}`,
        fullName,
        String(1000000000 + Math.floor(rng() * 8999999999)),
        pick(rng, lang === "ar" ? ["ذكر", "أنثى"] : ["Male", "Female"]),
        `${1985 + Math.floor(rng() * 20)}-${padded(Math.floor(rng() * 12) + 1, 2)}-${padded(Math.floor(rng() * 28) + 1, 2)}`,
        pick(rng, lang === "ar" ? AR_DEPTS : EN_DEPTS),
        lang === "ar" ? ROLES_AR[roleIdx] : ROLES_EN[roleIdx],
        `${enHandle}@example.com`,
        phone(rng),
        dateStr(rng),
        lang === "ar" ? CONTRACTS_AR[contractIdx] : CONTRACTS_EN[contractIdx],
        `${2027 + Math.floor(rng() * 3)}-12-31`,
        pick(rng, lang === "ar" ? ["صباحية", "مسائية", "ليلية", "متناوبة"] : ["Morning", "Evening", "Night", "Rotating"]),
        salary.toFixed(2),
        pick(rng, lang === "ar" ? ["البنك الأهلي", "بنك الراجحي", "بنك الرياض", "البنك الإنماء", "البنك السعودي الفرنسي"] : ["NCB", "Al Rajhi", "Riyad Bank", "Alinma", "Saudi Fransi"]),
        `SA${padded(Math.floor(rng() * 999999999999999), 22)}`,
        pick(rng, ["onduty", "onduty", "onduty", "leave", "task", "suspended"]),
      ];
    },
    count: [16, 28],
    moneyKey: "salary",
  },

  orders: {
    cols: [
      { key: "code", ar: "رقم الطلب", en: "Order #", kind: "id" },
      { key: "customer", ar: "العميل", en: "Customer", kind: "text" },
      { key: "items", ar: "الأصناف", en: "Items", kind: "text" },
      { key: "total", ar: "الإجمالي", en: "Total", kind: "money" },
      { key: "channel", ar: "القناة", en: "Channel", kind: "text" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "new", ar: "جديد", en: "New", tone: "sky" },
      { key: "prep", ar: "قيد التحضير", en: "Preparing", tone: "amber" },
      { key: "ready", ar: "جاهز", en: "Ready", tone: "violet" },
      { key: "delivered", ar: "تم التسليم", en: "Delivered", tone: "emerald" },
      { key: "cancelled", ar: "ملغى", en: "Cancelled", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      `ORD-${padded(9300 + i, 8)}`,
      person(rng, lang),
      pick(rng, lang === "ar" ? AR_MENU : EN_MENU),
      money(rng, 45, 780).toFixed(2),
      pick(rng, lang === "ar" ? AR_CHANNELS : EN_CHANNELS),
      dateStr(rng),
      pick(rng, ["new", "prep", "ready", "delivered", "delivered", "cancelled"]),
    ],
    count: [20, 32],
    moneyKey: "total",
  },

  /* ROUND 131 — the flagship commerce catalog preset (13 cols): bilingual
   *  name, SKU + barcode, category, full pricing (cost/price/VAT/margin),
   *  stock + reorder point, monthly velocity + status. Sector-matched names
   *  via the R129 vocab (row arg 4) — a hospital's products read medical. */
  products: {
    cols: [
      { key: "name", ar: "المنتج", en: "Product", kind: "text" },
      { key: "nameEn", ar: "الاسم بالإنجليزية", en: "English name", kind: "text" },
      { key: "sku", ar: "رمز المنتج", en: "SKU", kind: "id" },
      { key: "barcode", ar: "الباركود", en: "Barcode", kind: "id" },
      { key: "category", ar: "الفئة", en: "Category", kind: "text" },
      { key: "cost", ar: "التكلفة", en: "Cost", kind: "money" },
      { key: "price", ar: "سعر البيع", en: "Price", kind: "money" },
      { key: "vat", ar: "الضريبة %", en: "VAT %", kind: "num" },
      { key: "margin", ar: "هامش الربح %", en: "Margin %", kind: "num" },
      { key: "stock", ar: "المخزون", en: "Stock", kind: "num" },
      { key: "reorder", ar: "حد إعادة الطلب", en: "Reorder point", kind: "num" },
      { key: "sold", ar: "المبيعات الشهرية", en: "Monthly sold", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "نشط", en: "Active", tone: "emerald" },
      { key: "low", ar: "مخزون منخفض", en: "Low stock", tone: "amber" },
      { key: "out", ar: "نفد", en: "Out", tone: "rose" },
      { key: "archived", ar: "مؤرشف", en: "Archived", tone: "slate" },
    ],
    row: (rng, _i, lang, sector) => {
      const v = sector ? SECTOR_VOCAB[sector] : undefined;
      /* the SAME pool index feeds both locales so the bilingual pair stays
       * coherent (الاسم العربي ↔ English name describe one product) */
      const idx = Math.floor(rng() * (v ? v.invItems[0].length : AR_PRODUCTS.length));
      const nameAr = v ? v.invItems[0][idx % v.invItems[0].length] : AR_PRODUCTS[idx % AR_PRODUCTS.length];
      const nameEn = v ? v.invItems[1][idx % v.invItems[1].length] : EN_PRODUCTS[idx % EN_PRODUCTS.length];
      const catIdx = Math.floor(rng() * (v ? v.invCats[0].length : AR_PROD_CATS.length));
      const catAr = v ? v.invCats[0][catIdx % v.invCats[0].length] : AR_PROD_CATS[catIdx % AR_PROD_CATS.length];
      const catEn = v ? v.invCats[1][catIdx % v.invCats[1].length] : EN_PROD_CATS[catIdx % EN_PROD_CATS.length];
      const cost = money(rng, 4, 160);
      const price = Math.round((cost * (1.18 + rng() * 0.55)) * 100) / 100;
      const margin = Math.round(((price - cost) / price) * 1000) / 10;
      /* ROUND 150 — TASK J: stock floor raised from 0 → 20 so an "active"
       * catalog item rarely renders as zero-stock (the `out` status stays
       * reachable via the explicit `pick` fallback the way it always was). */
      const stock = Math.floor(rng() * 480) + 20;
      const reorder = Math.floor(rng() * 40) + 8;
      const st = stock === 0 ? "out" : stock <= reorder ? "low" : pick(rng, ["active", "active", "active", "archived"]);
      return [
        lang === "ar" ? nameAr : nameEn,
        nameEn,
        `SKU-${padded(Math.floor(rng() * 90000) + 10000, 8)}`,
        `62${padded(Math.floor(rng() * 900000000) + 100000000, 9)}`,
        lang === "ar" ? catAr : catEn,
        cost.toFixed(2),
        price.toFixed(2),
        "15",
        margin.toFixed(1),
        String(stock),
        String(reorder),
        String(Math.floor(rng() * 320)),
        st,
      ];
    },
    count: [18, 30],
    moneyKey: "price",
  },

  /* ROUND 131 — the premium POS ledger (10 cols): branch + cashier + full
   *  money decomposition (subtotal/discount/total) + payment method. */
  pos: {
    cols: [
      { key: "code", ar: "رقم العملية", en: "Txn #", kind: "id" },
      { key: "cashier", ar: "الكاشير", en: "Cashier", kind: "text" },
      { key: "branch", ar: "الفرع", en: "Branch", kind: "text" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "time", ar: "الوقت", en: "Time", kind: "text" },
      { key: "items", ar: "عدد البنود", en: "Items", kind: "num" },
      { key: "discount", ar: "الخصم", en: "Discount", kind: "money" },
      { key: "total", ar: "المبلغ", en: "Amount", kind: "money" },
      { key: "method", ar: "طريقة الدفع", en: "Payment", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "completed", ar: "مكتملة", en: "Completed", tone: "emerald" },
      { key: "refunded", ar: "مرتجعة", en: "Refunded", tone: "rose" },
      { key: "held", ar: "معلّقة", en: "Held", tone: "amber" },
    ],
    row: (rng, i, lang) => [
      `POS-${padded(61000 + i, 8)}`,
      person(rng, lang),
      pick(rng, lang === "ar" ? AR_BRANCHES : EN_BRANCHES),
      dateStr(rng),
      timeStr(rng),
      String(Math.floor(rng() * 18) + 1),
      money(rng, 0, 60).toFixed(2),
      money(rng, 25, 1450).toFixed(2),
      pick(rng, lang === "ar" ? AR_PAY_METHODS : EN_PAY_METHODS),
      pick(rng, ["completed", "completed", "completed", "refunded", "held"]),
    ],
    count: [24, 36],
    moneyKey: "total",
  },

  rooms: {
    cols: [
      { key: "room", ar: "الغرفة", en: "Room", kind: "id" },
      { key: "type", ar: "النوع", en: "Type", kind: "text" },
      { key: "floor", ar: "الطابق", en: "Floor", kind: "num" },
      { key: "rate", ar: "السعر/ليلة", en: "Rate/night", kind: "money" },
      { key: "guest", ar: "النزيل", en: "Guest", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "occupied", ar: "مشغولة", en: "Occupied", tone: "emerald" },
      { key: "vacant", ar: "شاغرة", en: "Vacant", tone: "sky" },
      { key: "cleaning", ar: "تنظيف", en: "Cleaning", tone: "amber" },
      { key: "maintenance", ar: "صيانة", en: "Maintenance", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["occupied", "vacant", "cleaning", "maintenance", "occupied"]);
      return [
        `${Math.floor(i / 12) + 1}${padded((i % 12) + 1, 2)}`,
        lang === "ar" ? pick(rng, ["مفردة", "مزدوجة", "جناح عائلي", "جناح ملكي"]) : pick(rng, ["Single", "Double", "Family suite", "Royal suite"]),
        String(Math.floor(i / 12) + 1),
        money(rng, 220, 1900).toFixed(2),
        st === "occupied" ? person(rng, lang) : "—",
        st,
      ];
    },
    count: [24, 36],
    moneyKey: "rate",
  },

  bookings: {
    cols: [
      { key: "code", ar: "رقم الحجز", en: "Booking #", kind: "id" },
      { key: "customer", ar: "العميل", en: "Customer", kind: "text" },
      { key: "service", ar: "الخدمة", en: "Service", kind: "text" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "time", ar: "الوقت", en: "Time", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "confirmed", ar: "مؤكد", en: "Confirmed", tone: "emerald" },
      { key: "pending", ar: "بانتظار التأكيد", en: "Pending", tone: "amber" },
      { key: "completed", ar: "منتهي", en: "Completed", tone: "sky" },
      { key: "cancelled", ar: "ملغى", en: "Cancelled", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      `BKG-${padded(3300 + i, 8)}`,
      person(rng, lang),
      pick(rng, lang === "ar" ? AR_SVCS : EN_SVCS),
      dateStr(rng),
      timeStr(rng),
      pick(rng, ["confirmed", "pending", "completed", "cancelled", "confirmed"]),
    ],
    count: [16, 26],
  },

  payments: {
    cols: [
      { key: "code", ar: "المرجع", en: "Ref", kind: "id" },
      { key: "invoice", ar: "الفاتورة", en: "Invoice", kind: "text" },
      { key: "method", ar: "الطريقة", en: "Method", kind: "text" },
      { key: "amount", ar: "المبلغ", en: "Amount", kind: "money" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "captured", ar: "مقبوض", en: "Captured", tone: "emerald" },
      { key: "processing", ar: "قيد المعالجة", en: "Processing", tone: "amber" },
      { key: "failed", ar: "فاشل", en: "Failed", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      `PAY-${padded(20200 + i, 8)}`,
      `INV-2026-${padded(1400 + Math.floor(rng() * 200), 8)}`,
      lang === "ar" ? pick(rng, ["تحويل بنكي", "مدى", "شبكة", "نقداً"]) : pick(rng, ["Bank transfer", "Mada", "EFTPOS", "Cash"]),
      money(rng, 150, 8600).toFixed(2),
      dateStr(rng),
      pick(rng, ["captured", "captured", "processing", "failed"]),
    ],
    count: [20, 30],
    moneyKey: "amount",
  },

  /* ROUND 131 — premium vendor preset (9 cols): named contact + lead time
   *  + on-time rating join the balance exposure. */
  suppliers: {
    cols: [
      { key: "name", ar: "المورد", en: "Supplier", kind: "text" },
      { key: "spec", ar: "التخصص", en: "Category", kind: "text" },
      { key: "contact", ar: "مسؤول التواصل", en: "Contact", kind: "text" },
      { key: "phone", ar: "الجوال", en: "Mobile", kind: "text" },
      { key: "lead", ar: "مدة التوريد (يوم)", en: "Lead time (days)", kind: "num" },
      { key: "rating", ar: "الالتزام بالتسليم %", en: "On-time %", kind: "num" },
      { key: "lastSupply", ar: "آخر توريد", en: "Last supply", kind: "date" },
      { key: "due", ar: "المستحق", en: "Balance due", kind: "money" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "تعاون نشط", en: "Active", tone: "emerald" },
      { key: "paused", ar: "موقوف مؤقتاً", en: "Paused", tone: "amber" },
      { key: "blacklist", ar: "مستبعد", en: "Blacklisted", tone: "rose" },
    ],
    row: (rng, _i, lang) => [
      lang === "ar"
        ? `${pick(rng, ["شركة", "مؤسسة", "مصنع"])} ${pick(rng, AR_LAST)} ${pick(rng, ["للتجارة", "للمستلزمات الطبية", "للتوريدات", "للصناعات"])}`
        : `${pick(rng, ["Co.", "Est.", "Ind."])} ${pick(rng, EN_LAST)} ${pick(rng, ["Trading", "Medical Supplies", "Provision", "Industries"])}`,
      lang === "ar" ? pick(rng, ["مستهلكات طبية", "أدوية", "أجهزة", "أغذية", "قرطاسية"]) : pick(rng, ["Consumables", "Pharma", "Devices", "Foods", "Stationery"]),
      person(rng, lang),
      phone(rng),
      String(Math.floor(rng() * 14) + 2),
      String(Math.floor(rng() * 16) + 84),
      dateStr(rng),
      money(rng, 0, 68000).toFixed(2),
      pick(rng, ["active", "active", "paused", "blacklist"]),
    ],
    count: [12, 20],
    moneyKey: "due",
  },

  menu: {
    cols: [
      { key: "item", ar: "الطبق", en: "Dish", kind: "text" },
      { key: "category", ar: "القسم", en: "Section", kind: "text" },
      { key: "price", ar: "السعر", en: "Price", kind: "money" },
      /* ROUND 66 — was "طلبات الشهر / Monthly orders"; now the available
       * PORTION count. The public storefront (store-mapper.ts) reads this
       * cell as the purchasable stock: it gates availability, caps the cart
       * quantity and is compare-and-swap decremented on placement — the old
       * orders counter semantic made purchases silently eat the popularity
       * metric. Order analytics live in the orders/KDS modules instead. */
      { key: "stock", ar: "الكمية المتوفرة", en: "Available", kind: "num" },
      { key: "rating", ar: "التقييم", en: "Rating", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "متاح", en: "Available", tone: "emerald" },
      { key: "seasonal", ar: "موسمي", en: "Seasonal", tone: "violet" },
      { key: "soldout", ar: "غير متاح", en: "Sold out", tone: "rose" },
    ],
    row: (rng, _i, lang) => [
      pick(rng, lang === "ar" ? AR_MENU : EN_MENU),
      lang === "ar" ? pick(rng, ["الأطباق الرئيسية", "المشروبات", "السلطات", "الحلويات"]) : pick(rng, ["Mains", "Drinks", "Salads", "Desserts"]),
      money(rng, 12, 140).toFixed(2),
      String(Math.floor(rng() * 60) + 8),
      (3.6 + rng() * 1.4).toFixed(1),
      pick(rng, ["active", "active", "seasonal", "soldout"]),
    ],
    count: [12, 20],
    moneyKey: "price",
  },

  /* ROUND 154 — students preset: studentUuid REMOVED per owner directive
   * («احذف معرّف النظام بشكل كامل»). The `code` column (STU-00008801) is
   * the ONLY internal ID — renamed from «الرقم الأكاديمي» to «معرّف الطالب»
   * per the directive. `universityId` (الرقم الجامعي) stays as the
   * university-issued official number. */
  students: {
    cols: [
      { key: "code", ar: "معرّف الطالب", en: "Student ID", kind: "id" },
      { key: "universityId", ar: "الرقم الجامعي", en: "University ID", kind: "text" },
      { key: "name", ar: "الطالب", en: "Student", kind: "text" },
      { key: "grade", ar: "الصف", en: "Grade", kind: "text" },
      { key: "college", ar: "الكلية", en: "College", kind: "text" },
      { key: "specialization", ar: "التخصص", en: "Specialization", kind: "text" },
      { key: "year", ar: "السنة الدراسية", en: "Academic Year", kind: "text" },
      { key: "credits", ar: "الساعات المعتمدة", en: "Credit Hours", kind: "num" },
      { key: "guardian", ar: "ولي الأمر", en: "Guardian", kind: "text" },
      { key: "attendance", ar: "نسبة الحضور", en: "Attendance", kind: "num" },
      { key: "gpa", ar: "المعدل", en: "GPA", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "excellent", ar: "متميز", en: "Excellent", tone: "emerald" },
      { key: "good", ar: "جيد", en: "Good", tone: "sky" },
      { key: "watch", ar: "بحاجة متابعة", en: "Needs follow-up", tone: "amber" },
      { key: "risk", ar: "تحت التحذير", en: "At risk", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      /* ROUND 150 — TASK J: GPA widens to the realistic 2.0–4.5 band
       * (was 2.0–4.0, never reached the «excellent» ≥4.5 tier); credits
       * now spans 30–120 inclusive (was 30–119, the off-by-one). */
      const gpa = (2 + rng() * 2.5).toFixed(2);
      /* ROUND 154 — studentUuid removed; universityId: realistic 8-digit
       * university number. */
      return [
        `STU-${padded(8800 + i, 8)}`,
        `${2024000000 + Math.floor(rng() * 999999)}`,
        person(rng, lang),
        `${Math.floor(rng() * 12) + 1}${lang === "ar" ? " ر" : ""}`,
        /* ROUND 149 — university-context columns */
        pick(rng, lang === "ar" ? AR_COLLEGES_STU : EN_COLLEGES_STU),
        pick(rng, lang === "ar" ? AR_SPECIALIZATIONS : EN_SPECIALIZATIONS),
        `${Math.floor(rng() * 6) + 1}${lang === "ar" ? " سنة" : " yr"}`,
        String(Math.floor(rng() * 91) + 30),
        person(rng, lang),
        `${Math.floor(rng() * 15) + 85}%`,
        gpa,
        Number(gpa) >= 4.5 ? "excellent" : Number(gpa) >= 3.5 ? "good" : Number(gpa) >= 2.5 ? "watch" : "risk",
      ];
    },
    count: [22, 32],
  },

  /* ---------------- round 29: gym / barbershop / driving-school ---------------- */

  members: {
    cols: [
      { key: "code", ar: "رقم العضوية", en: "Member #", kind: "id" },
      { key: "name", ar: "العضو", en: "Member", kind: "text" },
      { key: "phone", ar: "الجوال", en: "Mobile", kind: "text" },
      { key: "plan", ar: "الباقة", en: "Plan", kind: "text" },
      { key: "coach", ar: "المدرب", en: "Coach", kind: "text" },
      { key: "joined", ar: "الانضمام", en: "Joined", kind: "date" },
      { key: "lastVisit", ar: "آخر حضور", en: "Last visit", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "نشط", en: "Active", tone: "emerald" },
      { key: "renewed", ar: "متجدد", en: "Renewed", tone: "sky" },
      { key: "expired", ar: "منتهي", en: "Expired", tone: "rose" },
      { key: "frozen", ar: "مجمّد", en: "Frozen", tone: "amber" },
    ],
    row: (rng, i, lang) => [
      `MBR-${padded(15200 + i, 8)}`,
      person(rng, lang),
      phone(rng),
      pick(rng, lang === "ar" ? AR_GYM_PLANS : EN_GYM_PLANS),
      pick(rng, lang === "ar" ? AR_COACHES : EN_COACHES),
      dateStr(rng),
      dateStr(rng),
      pick(rng, ["active", "active", "renewed", "expired", "frozen"]),
    ],
    count: [24, 36],
  },

  coaches: {
    cols: [
      { key: "name", ar: "المدرب", en: "Coach", kind: "text" },
      { key: "spec", ar: "التخصص", en: "Specialty", kind: "text" },
      { key: "cert", ar: "الشهادة", en: "Certification", kind: "text" },
      { key: "clients", ar: "العملاء", en: "Clients", kind: "num" },
      { key: "rating", ar: "التقييم", en: "Rating", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "available", ar: "متاح", en: "Available", tone: "emerald" },
      { key: "full", ar: "مزدحم", en: "Fully booked", tone: "amber" },
      { key: "leave", ar: "إجازة", en: "On leave", tone: "slate" },
    ],
    row: (rng, _i, lang) => [
      pick(rng, lang === "ar" ? AR_COACHES : EN_COACHES),
      pick(rng, lang === "ar" ? AR_SPECIALTIES : EN_SPECIALTIES),
      pick(rng, lang === "ar" ? AR_CERTS : EN_CERTS),
      String(Math.floor(rng() * 38) + 6),
      (4.1 + rng() * 0.9).toFixed(1),
      pick(rng, ["available", "available", "full", "leave"]),
    ],
    count: [10, 16],
  },

  classes: {
    cols: [
      { key: "name", ar: "الحصة", en: "Class", kind: "text" },
      { key: "coach", ar: "المدرب", en: "Coach", kind: "text" },
      { key: "hall", ar: "القاعة", en: "Hall", kind: "text" },
      { key: "day", ar: "اليوم", en: "Day", kind: "text" },
      { key: "time", ar: "الوقت", en: "Time", kind: "text" },
      { key: "seats", ar: "المقاعد", en: "Seats", kind: "num" },
      { key: "booked", ar: "المحجوز", en: "Booked", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "open", ar: "متاحة", en: "Open", tone: "emerald" },
      { key: "filling", ar: "شبه ممتلئة", en: "Filling fast", tone: "amber" },
      { key: "full", ar: "مكتملة", en: "Full", tone: "rose" },
    ],
    row: (rng, _i, lang) => {
      const seats = Math.floor(rng() * 14) + 12;
      const booked = Math.floor(rng() * (seats + 1));
      return [
        pick(rng, lang === "ar" ? AR_CLASS_NAMES : EN_CLASS_NAMES),
        pick(rng, lang === "ar" ? AR_COACHES : EN_COACHES),
        pick(rng, lang === "ar" ? AR_HALLS : EN_HALLS),
        pick(rng, lang === "ar" ? AR_DAYS : EN_DAYS),
        timeStr(rng),
        String(seats),
        String(booked),
        booked >= seats ? "full" : booked >= seats * 0.7 ? "filling" : "open",
      ];
    },
    count: [12, 20],
  },

  workouts: {
    cols: [
      { key: "program", ar: "البرنامج", en: "Program", kind: "text" },
      { key: "member", ar: "العضو", en: "Member", kind: "text" },
      { key: "goal", ar: "الهدف", en: "Goal", kind: "text" },
      { key: "sessions", ar: "جلسات/أسبوع", en: "Sessions/week", kind: "num" },
      { key: "level", ar: "المستوى", en: "Level", kind: "text" },
      { key: "duration", ar: "المدة", en: "Duration", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "نشطة", en: "Active", tone: "emerald" },
      { key: "done", ar: "مكتملة", en: "Completed", tone: "sky" },
      { key: "paused", ar: "متوقفة", en: "Paused", tone: "amber" },
    ],
    row: (rng, _i, lang) => [
      pick(rng, lang === "ar" ? AR_WORKOUT_PROGRAMS : EN_WORKOUT_PROGRAMS),
      person(rng, lang),
      pick(rng, lang === "ar" ? AR_GOALS : EN_GOALS),
      String(Math.floor(rng() * 4) + 3),
      pick(rng, lang === "ar" ? AR_LEVELS : EN_LEVELS),
      `${Math.floor(rng() * 12) + 4}${lang === "ar" ? " أسابيع" : " weeks"}`,
      pick(rng, ["active", "active", "done", "paused"]),
    ],
    count: [14, 24],
  },

  equipment: {
    cols: [
      { key: "name", ar: "الجهاز", en: "Machine", kind: "text" },
      { key: "serial", ar: "الرقم التسلسلي", en: "Serial #", kind: "id" },
      { key: "zone", ar: "القسم", en: "Zone", kind: "text" },
      { key: "lastService", ar: "آخر صيانة", en: "Last service", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "new", ar: "جديد", en: "New", tone: "emerald" },
      { key: "needs", ar: "يحتاج صيانة", en: "Needs service", tone: "amber" },
      { key: "under", ar: "تحت الصيانة", en: "Under maintenance", tone: "rose" },
      { key: "retired", ar: "مركون", en: "Retired", tone: "slate" },
    ],
    row: (rng, i, lang) => [
      pick(rng, lang === "ar" ? AR_GYM_EQUIP : EN_GYM_EQUIP),
      `EQ-${padded(31100 + i, 8)}`,
      pick(rng, lang === "ar" ? AR_GYM_ZONES : EN_GYM_ZONES),
      dateStr(rng),
      pick(rng, ["new", "new", "needs", "under", "retired"]),
    ],
    count: [18, 30],
  },

  measurements: {
    cols: [
      { key: "member", ar: "العضو", en: "Member", kind: "text" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "weight", ar: "الوزن (كجم)", en: "Weight (kg)", kind: "num" },
      { key: "fat", ar: "الدهون %", en: "Fat %", kind: "num" },
      { key: "muscle", ar: "العضلات %", en: "Muscle %", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "improving", ar: "تحسن", en: "Improving", tone: "emerald" },
      { key: "stable", ar: "ثابت", en: "Stable", tone: "sky" },
      { key: "watch", ar: "بحاجة متابعة", en: "Needs follow-up", tone: "amber" },
    ],
    row: (rng, _i, lang) => [
      person(rng, lang),
      dateStr(rng),
      (52 + rng() * 62).toFixed(1),
      (8 + rng() * 28).toFixed(1),
      (30 + rng() * 25).toFixed(1),
      pick(rng, ["improving", "improving", "stable", "watch"]),
    ],
    count: [16, 26],
  },

  nutrition: {
    cols: [
      { key: "plan", ar: "الخطة", en: "Plan", kind: "text" },
      { key: "member", ar: "العضو", en: "Member", kind: "text" },
      { key: "calories", ar: "السعرات", en: "Calories", kind: "num" },
      { key: "protein", ar: "البروتين (غ)", en: "Protein (g)", kind: "num" },
      { key: "meals", ar: "الوجبات", en: "Meals", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "سارية", en: "Active", tone: "emerald" },
      { key: "review", ar: "بحاجة مراجعة", en: "Needs review", tone: "amber" },
      { key: "ended", ar: "منتهية", en: "Ended", tone: "slate" },
    ],
    row: (rng, _i, lang) => [
      pick(rng, lang === "ar" ? AR_NUTRITION_PLANS : EN_NUTRITION_PLANS),
      person(rng, lang),
      String(Math.floor(rng() * 1700) + 1400),
      String(Math.floor(rng() * 150) + 90),
      String(Math.floor(rng() * 4) + 3),
      pick(rng, ["active", "active", "review", "ended"]),
    ],
    count: [12, 20],
  },

  lockers: {
    cols: [
      { key: "code", ar: "الخزانة", en: "Locker", kind: "id" },
      { key: "member", ar: "العضو", en: "Member", kind: "text" },
      { key: "type", ar: "النوع", en: "Type", kind: "text" },
      { key: "start", ar: "البداية", en: "Start", kind: "date" },
      { key: "end", ar: "الانتهاء", en: "End", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "occupied", ar: "مشغولة", en: "Occupied", tone: "emerald" },
      { key: "vacant", ar: "متاحة", en: "Vacant", tone: "sky" },
      { key: "maintenance", ar: "صيانة", en: "Maintenance", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["occupied", "occupied", "vacant", "maintenance"]);
      /* ISO dates compare lexicographically — keep start ≤ end */
      let start = dateStr(rng);
      let end = dateStr(rng);
      if (end < start) { const t = start; start = end; end = t; }
      return [
        `LK-${padded(210 + i, 8)}`,
        st === "occupied" ? person(rng, lang) : "—",
        pick(rng, lang === "ar" ? AR_LOCKER_TYPES : EN_LOCKER_TYPES),
        start,
        end,
        st,
      ];
    },
    count: [20, 32],
  },

  queue: {
    cols: [
      { key: "num", ar: "الرقم", en: "Ticket", kind: "id" },
      { key: "customer", ar: "العميل", en: "Customer", kind: "text" },
      { key: "service", ar: "الخدمة", en: "Service", kind: "text" },
      { key: "time", ar: "الوقت", en: "Time", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "waiting", ar: "بانتظار", en: "Waiting", tone: "amber" },
      { key: "serving", ar: "في الخدمة", en: "In service", tone: "sky" },
      { key: "done", ar: "تم", en: "Done", tone: "emerald" },
      { key: "left", ar: "انصرف", en: "Left", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      `Q-${padded(10 + i, 8)}`,
      person(rng, lang),
      pick(rng, lang === "ar" ? AR_BARBER_SVCS : EN_BARBER_SVCS),
      timeStr(rng),
      pick(rng, ["waiting", "waiting", "serving", "done", "left"]),
    ],
    count: [10, 16],
  },

  vehicles: {
    cols: [
      { key: "name", ar: "المركبة", en: "Vehicle", kind: "text" },
      { key: "plate", ar: "اللوحة", en: "Plate", kind: "id" },
      { key: "type", ar: "النوع", en: "Type", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
      { key: "lastService", ar: "آخر صيانة", en: "Last service", kind: "date" },
    ],
    statuses: [
      { key: "ready", ar: "جاهزة", en: "Ready", tone: "emerald" },
      { key: "inlesson", ar: "في الدرس", en: "In lesson", tone: "sky" },
      { key: "service", ar: "صيانة", en: "Maintenance", tone: "amber" },
      { key: "down", ar: "معطلة", en: "Out of service", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      pick(rng, lang === "ar" ? AR_CARS : EN_CARS),
      lang === "ar"
        ? `${padded(3100 + i, 4)} ${pick(rng, ["ر س ن", "ب ط ح", "ع ب د", "ك م ل", "د ج س"])}`
        : `${pick(rng, ["RSN", "BTH", "ABD", "KML", "DJS"])} ${padded(3100 + i, 4)}`,
      lang === "ar"
        ? pick(rng, ["تدريب أوتوماتيك", "تدريب مانوال", "سيدان مزدوجة", "هاتشبك صغيرة"])
        : pick(rng, ["Automatic trainer", "Manual trainer", "Dual sedan", "Compact hatchback"]),
      pick(rng, ["ready", "ready", "inlesson", "service", "down"]),
      dateStr(rng),
    ],
    count: [10, 18],
  },

  lessons: {
    cols: [
      { key: "code", ar: "الدرس", en: "Lesson", kind: "id" },
      { key: "student", ar: "الطالب", en: "Student", kind: "text" },
      { key: "instructor", ar: "المدرّب", en: "Instructor", kind: "text" },
      { key: "vehicle", ar: "المركبة", en: "Vehicle", kind: "text" },
      { key: "date", ar: "الموعد", en: "Date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "scheduled", ar: "مجدول", en: "Scheduled", tone: "sky" },
      { key: "completed", ar: "مكتمل", en: "Completed", tone: "emerald" },
      { key: "cancelled", ar: "ملغي", en: "Cancelled", tone: "rose" },
      { key: "noshow", ar: "غياب", en: "No-show", tone: "amber" },
    ],
    row: (rng, i, lang) => [
      `LES-${padded(4400 + i, 8)}`,
      person(rng, lang),
      pick(rng, lang === "ar" ? AR_INSTRUCTORS : EN_INSTRUCTORS),
      pick(rng, lang === "ar" ? AR_CARS : EN_CARS),
      dateStr(rng),
      pick(rng, ["scheduled", "completed", "completed", "cancelled", "noshow"]),
    ],
    count: [16, 28],
  },

  memberships: {
    cols: [
      { key: "code", ar: "العضوية", en: "Membership #", kind: "id" },
      { key: "customer", ar: "العميل", en: "Customer", kind: "text" },
      { key: "plan", ar: "الباقة", en: "Package", kind: "text" },
      { key: "start", ar: "البدء", en: "Start", kind: "date" },
      { key: "end", ar: "الانتهاء", en: "End", kind: "date" },
      { key: "value", ar: "القيمة", en: "Value", kind: "money" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "سارية", en: "Active", tone: "emerald" },
      { key: "expiring", ar: "تنتهي قريباً", en: "Expiring soon", tone: "amber" },
      { key: "expired", ar: "منتهية", en: "Expired", tone: "rose" },
      { key: "cancelled", ar: "ملغاة", en: "Cancelled", tone: "slate" },
    ],
    row: (rng, i, lang) => {
      /* ISO dates compare lexicographically — keep start ≤ end */
      let start = dateStr(rng);
      let end = dateStr(rng);
      if (end < start) { const t = start; start = end; end = t; }
      return [
        `MSP-${padded(7100 + i, 8)}`,
        person(rng, lang),
        pick(rng, lang === "ar" ? AR_BARBER_PLANS : EN_BARBER_PLANS),
        start,
        end,
        money(rng, 120, 2400).toFixed(2),
        pick(rng, ["active", "active", "expiring", "expired", "cancelled"]),
      ];
    },
    count: [14, 24],
    moneyKey: "value",
  },

  /* ------------------------------------------------------------------ */
  /* ROUND 131 — the premium business-suite presets (the 10 commerce    */
  /* modules the owner directed: purchases, promotions, returns,        */
  /* loyalty, branches, reports, stocktake join the upgraded            */
  /* pos/products/customers/suppliers above).                           */
  /* ------------------------------------------------------------------ */

  purchases: {
    cols: [
      { key: "code", ar: "رقم أمر الشراء", en: "PO #", kind: "id" },
      { key: "supplier", ar: "المورد", en: "Supplier", kind: "text" },
      { key: "category", ar: "نوع التوريد", en: "Type", kind: "text" },
      { key: "items", ar: "عدد الأصناف", en: "Line items", kind: "num" },
      { key: "total", ar: "إجمالي التوريد", en: "PO total", kind: "money" },
      { key: "method", ar: "طريقة السداد", en: "Payment", kind: "text" },
      { key: "expected", ar: "التاريخ المتوقع", en: "Expected", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "received", ar: "مستلم", en: "Received", tone: "emerald" },
      { key: "partial", ar: "مستلم جزئياً", en: "Partially received", tone: "sky" },
      { key: "pending", ar: "بانتظار الاستلام", en: "Pending", tone: "amber" },
      { key: "cancelled", ar: "ملغى", en: "Cancelled", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      `PUR-${padded(5200 + i, 8)}`,
      lang === "ar"
        ? `${pick(rng, ["شركة", "مؤسسة"])} ${pick(rng, AR_LAST)} ${pick(rng, ["للتوريدات", "للتجارة", "للمستلزمات"])}`
        : `${pick(rng, ["Co.", "Est."])} ${pick(rng, EN_LAST)} ${pick(rng, ["Provision", "Trading", "Supplies"])}`,
      pick(rng, lang === "ar" ? AR_PURCHASE_CATS : EN_PURCHASE_CATS),
      String(Math.floor(rng() * 40) + 3),
      money(rng, 850, 96000).toFixed(2),
      pick(rng, lang === "ar" ? ["تحويل بنكي", "مدى تجاري", "ائتمان 30 يوم", "نقداً"] : ["Bank transfer", "Corporate mada", "Net-30 credit", "Cash"]),
      dateStr(rng),
      pick(rng, ["received", "received", "partial", "pending", "cancelled"]),
    ],
    count: [14, 24],
    moneyKey: "total",
  },

  promotions: {
    cols: [
      { key: "code", ar: "رمز العرض", en: "Promo code", kind: "id" },
      { key: "name", ar: "اسم العرض", en: "Offer", kind: "text" },
      { key: "type", ar: "نوع الخصم", en: "Discount type", kind: "text" },
      { key: "value", ar: "قيمة الخصم", en: "Value", kind: "num" },
      { key: "scope", ar: "نطاق التطبيق", en: "Scope", kind: "text" },
      { key: "usage", ar: "مرات الاستخدام", en: "Redemptions", kind: "num" },
      { key: "cap", ar: "سقف الاستخدام", en: "Usage cap", kind: "num" },
      { key: "ends", ar: "ينتهي في", en: "Ends", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "جارٍ الآن", en: "Running", tone: "emerald" },
      { key: "scheduled", ar: "مجدول", en: "Scheduled", tone: "sky" },
      { key: "paused", ar: "موقوف مؤقتاً", en: "Paused", tone: "amber" },
      { key: "expired", ar: "منتهي", en: "Expired", tone: "slate" },
    ],
    row: (rng, i, lang) => {
      const type = pick(rng, lang === "ar" ? AR_PROMO_TYPES : EN_PROMO_TYPES);
      const isPercent = type === (lang === "ar" ? "خصم نسبة" : "Percent off");
      const cap = Math.floor(rng() * 800) + 100;
      const usage = Math.floor(rng() * cap);
      const statusPick = usage >= cap ? "expired" : pick(rng, ["active", "active", "scheduled", "paused", "expired"]);
      return [
        `PRM-${padded(2400 + i, 8)}`,
        lang === "ar"
          ? pick(rng, ["عرض نهاية الأسبوع", "خصم الولاء الذهبي", "باقة العائلة", "تخفيضات الموسم", "عرض الافتتاح", "خصم التطبيق"])
          : pick(rng, ["Weekend offer", "Golden loyalty discount", "Family bundle", "Seasonal markdown", "Opening offer", "App-exclusive"]),
        type,
        (isPercent ? Math.floor(rng() * 30) + 5 : money(rng, 10, 150)).toFixed(isPercent ? 0 : 2),
        pick(rng, lang === "ar" ? AR_PROMO_SCOPES : EN_PROMO_SCOPES),
        String(usage),
        String(cap),
        dateStr(rng),
        statusPick,
      ];
    },
    count: [10, 18],
  },

  returns: {
    cols: [
      { key: "code", ar: "رقم المرتجع", en: "RMA #", kind: "id" },
      { key: "order", ar: "رقم الطلب الأصلي", en: "Original order", kind: "text" },
      { key: "customer", ar: "العميل", en: "Customer", kind: "text" },
      { key: "item", ar: "الصنف المرتجع", en: "Returned item", kind: "text" },
      { key: "qty", ar: "الكمية", en: "Qty", kind: "num" },
      { key: "value", ar: "قيمة الاسترداد", en: "Refund value", kind: "money" },
      { key: "reason", ar: "سبب الإرجاع", en: "Reason", kind: "text" },
      { key: "date", ar: "تاريخ الطلب", en: "Requested", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "approved", ar: "معتمد", en: "Approved", tone: "emerald" },
      { key: "pending", ar: "بانتظار الفحص", en: "Pending inspection", tone: "amber" },
      { key: "refunded", ar: "مُسترد", en: "Refunded", tone: "sky" },
      { key: "rejected", ar: "مرفوض", en: "Rejected", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      `RET-${padded(3100 + i, 8)}`,
      `ORD-${padded(9300 + Math.floor(rng() * 300), 8)}`,
      person(rng, lang),
      pick(rng, lang === "ar" ? AR_PRODUCTS : EN_PRODUCTS),
      String(Math.floor(rng() * 4) + 1),
      money(rng, 15, 680).toFixed(2),
      pick(rng, lang === "ar" ? AR_RETURN_REASONS : EN_RETURN_REASONS),
      dateStr(rng),
      pick(rng, ["approved", "approved", "pending", "refunded", "rejected"]),
    ],
    count: [12, 20],
    moneyKey: "value",
  },

  loyalty: {
    cols: [
      { key: "member", ar: "عضو الولاء", en: "Member", kind: "text" },
      { key: "phone", ar: "الجوال", en: "Mobile", kind: "text" },
      { key: "points", ar: "نقاط الولاء", en: "Points", kind: "num" },
      { key: "earned", ar: "نقاط الشهر", en: "Points this month", kind: "num" },
      { key: "redeemed", ar: "نقاط مستبدلة", en: "Redeemed", kind: "num" },
      { key: "value", ar: "قيمة المكافآت", en: "Rewards value", kind: "money" },
      { key: "visits", ar: "الزيارات", en: "Visits", kind: "num" },
      { key: "expiry", ar: "انتهاء النقاط", en: "Points expiry", kind: "date" },
      { key: "status", ar: "المستوى", en: "Tier", kind: "status" },
    ],
    statuses: [
      { key: "platinum", ar: "بلاتيني", en: "Platinum", tone: "violet" },
      { key: "gold", ar: "ماسي", en: "Gold", tone: "amber" },
      { key: "silver", ar: "فضي", en: "Silver", tone: "sky" },
      { key: "bronze", ar: "برونزي", en: "Bronze", tone: "emerald" },
    ],
    row: (rng, _i, lang) => {
      const points = Math.floor(rng() * 12000) + 300;
      const tier = points > 9000 ? "platinum" : points > 5500 ? "gold" : points > 2500 ? "silver" : "bronze";
      return [
        person(rng, lang),
        phone(rng),
        String(points),
        String(Math.floor(rng() * 900)),
        String(Math.floor(rng() * 5000)),
        money(rng, 20, 950).toFixed(2),
        String(Math.floor(rng() * 90) + 2),
        dateStr(rng),
        tier,
      ];
    },
    count: [16, 26],
    moneyKey: "value",
  },

  branches: {
    cols: [
      { key: "name", ar: "الفرع", en: "Branch", kind: "text" },
      { key: "city", ar: "المدينة", en: "City", kind: "text" },
      { key: "manager", ar: "مدير الفرع", en: "Manager", kind: "text" },
      { key: "staff", ar: "عدد الموظفين", en: "Staff", kind: "num" },
      { key: "daily", ar: "متوسط المبيعات اليومية", en: "Avg daily sales", kind: "money" },
      { key: "monthly", ar: "المبيعات الشهرية", en: "Monthly sales", kind: "money" },
      { key: "growth", ar: "النمو الشهري %", en: "Monthly growth %", kind: "num" },
      { key: "opened", ar: "تاريخ الافتتاح", en: "Opened", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "open", ar: "يعمل", en: "Operating", tone: "emerald" },
      { key: "renovating", ar: "قيد التجديد", en: "Renovating", tone: "amber" },
      { key: "soon", ar: "افتتاح قريباً", en: "Opening soon", tone: "sky" },
      { key: "closed", ar: "مغلق", en: "Closed", tone: "slate" },
    ],
    row: (rng, _i, lang) => {
      const branch = pick(rng, lang === "ar" ? AR_BRANCHES : EN_BRANCHES);
      const daily = money(rng, 1800, 32000);
      return [
        branch,
        pick(rng, lang === "ar" ? AR_CITIES : EN_CITIES),
        person(rng, lang),
        String(Math.floor(rng() * 40) + 6),
        daily.toFixed(2),
        (daily * 30).toFixed(2),
        (rng() * 24 - 6).toFixed(1),
        dateStr(rng),
        branch === (lang === "ar" ? "فرع الشاطئ" : "Beach branch") ? "soon" : pick(rng, ["open", "open", "open", "renovating", "closed"]),
      ];
    },
    count: [5, 7],
    moneyKey: "monthly",
  },

  /* ROUND 155 — reports preset rebuilt as an advanced + integrated report
   * management system (the owner's directive: «قم بتطوير الصفحة واجعلها
   * متقدمة ومتكاملة»). 10 cols: code · title · type · period · generatedBy ·
   * format · size · rows · generated · status. 5 statuses: generated (the
   * ready→generated rename, clearer management-system vocabulary) ·
   * generating · scheduled · failed · archived. The bilingual type / format
   * / size pools drive the new cells; the generator's seed keeps the file
   * size + the generated-by name stable per row index. */
  reports: {
    cols: [
      { key: "code", ar: "رمز التقرير", en: "Report #", kind: "id" },
      { key: "title", ar: "عنوان التقرير", en: "Report title", kind: "text" },
      { key: "type", ar: "نوع التقرير", en: "Report type", kind: "text" },
      { key: "period", ar: "الدورية", en: "Period", kind: "text" },
      { key: "generatedBy", ar: "أنشأه", en: "Generated by", kind: "text" },
      { key: "format", ar: "الصيغة", en: "Format", kind: "text" },
      { key: "size", ar: "الحجم", en: "Size", kind: "text" },
      { key: "rows", ar: "عدد السجلات", en: "Rows", kind: "num" },
      { key: "generated", ar: "آخر توليد", en: "Last generated", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "generated", ar: "مُولّد", en: "Generated", tone: "emerald" },
      { key: "generating", ar: "قيد التوليد", en: "Generating", tone: "amber" },
      { key: "scheduled", ar: "مجدول تلقائياً", en: "Auto-scheduled", tone: "sky" },
      { key: "failed", ar: "فشل التوليد", en: "Failed", tone: "rose" },
      { key: "archived", ar: "مؤرشف", en: "Archived", tone: "slate" },
    ],
    row: (rng, i, lang) => [
      `RPT-${padded(4500 + i, 8)}`,
      pick(rng, lang === "ar" ? AR_REPORT_NAMES : EN_REPORT_NAMES),
      pick(rng, lang === "ar" ? AR_REPORT_TYPES : EN_REPORT_TYPES),
      pick(rng, lang === "ar" ? AR_REPORT_PERIODS : EN_REPORT_PERIODS),
      person(rng, lang),
      pick(rng, lang === "ar" ? AR_REPORT_FORMATS : EN_REPORT_FORMATS),
      reportSize(i, lang),
      String(Math.floor(rng() * 9000) + 120),
      dateStr(rng),
      pick(rng, ["generated", "generated", "scheduled", "generating", "failed", "archived"]),
    ],
    count: [14, 22],
  },

  stocktake: {
    cols: [
      { key: "code", ar: "رقم الجرد", en: "Count #", kind: "id" },
      { key: "zone", ar: "موقع الجرد", en: "Zone", kind: "text" },
      { key: "scheduled", ar: "تاريخ الجرد", en: "Scheduled", kind: "date" },
      { key: "counter", ar: "فريق الجرد", en: "Counted by", kind: "text" },
      { key: "items", ar: "أصناف مجرودة", en: "Items counted", kind: "num" },
      { key: "variance", ar: "فرق الكمية", en: "Qty variance", kind: "num" },
      { key: "value", ar: "قيمة الفرق", en: "Variance value", kind: "money" },
      { key: "accuracy", ar: "دقة الجرد %", en: "Accuracy %", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "reviewed", ar: "مراجع ومعتمد", en: "Reviewed", tone: "emerald" },
      { key: "inprogress", ar: "جارٍ العدّ", en: "In progress", tone: "amber" },
      { key: "planned", ar: "مخطط", en: "Planned", tone: "sky" },
      { key: "closed", ar: "مغلق", en: "Closed", tone: "slate" },
    ],
    row: (rng, i, lang) => {
      const items = Math.floor(rng() * 900) + 60;
      const variance = Math.floor(rng() * 40) - 28;
      const accuracy = (96 + rng() * 3.9).toFixed(1);
      return [
        `STK-${padded(1600 + i, 8)}`,
        pick(rng, lang === "ar" ? AR_INV_ZONES : EN_INV_ZONES),
        dateStr(rng),
        person(rng, lang),
        String(items),
        String(variance),
        money(rng, 40, 5200).toFixed(2),
        accuracy,
        pick(rng, ["reviewed", "reviewed", "inprogress", "planned", "closed"]),
      ];
    },
    count: [10, 16],
    moneyKey: "value",
  },

  /* ============================================================
     ROUND 153 — SAMS module presets (Student Accommodation)
     ============================================================ */

  /* المباني — dormBuildings (SAMS — distinct from hospitality `rooms`) */
  dormBuildings: {
    cols: [
      { key: "code", ar: "رمز المبنى", en: "Building #", kind: "id" },
      { key: "name", ar: "اسم المبنى", en: "Building Name", kind: "text" },
      { key: "type", ar: "النوع", en: "Type", kind: "text" },
      { key: "floors", ar: "الأدوار", en: "Floors", kind: "num" },
      { key: "capacity", ar: "السعة", en: "Capacity", kind: "num" },
      { key: "occupied", ar: "الإشغال", en: "Occupied", kind: "num" },
      { key: "address", ar: "العنوان", en: "Address", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "نشط", en: "Active", tone: "emerald" },
      { key: "maintenance", ar: "صيانة", en: "Maintenance", tone: "amber" },
      { key: "full", ar: "مكتمل", en: "Full", tone: "sky" },
      { key: "closed", ar: "مغلق", en: "Closed", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const cap = Math.floor(rng() * 200) + 80;
      const occ = Math.floor(cap * (0.6 + rng() * 0.4));
      return [
        `BLG-${padded(100 + i, 6)}`,
        lang === "ar" ? `مبنى ${pick(rng, ["أ", "ب", "ج", "د", "هـ"])} - السكن الطلابي` : `Building ${pick(rng, ["A", "B", "C", "D", "E"])} - Student Housing`,
        pick(rng, lang === "ar" ? ["سكن ذكور", "سكن إناث", "سكن مختلط", "سكن عائلي"] : ["Male", "Female", "Mixed", "Family"]),
        String(Math.floor(rng() * 8) + 3),
        String(cap),
        String(occ),
        lang === "ar" ? `الحرم الجامعي - ${pick(rng, ["المدخل الشمالي", "المدخل الشرقي", "المدخل الجنوبي"])}` : `Campus - ${pick(rng, ["North Gate", "East Gate", "South Gate"])}`,
        occ >= cap ? "full" : occ >= cap * 0.9 ? "active" : pick(rng, ["active", "active", "maintenance"]),
      ];
    },
    count: [6, 12],
  },

  /* الغرف — dormRooms (SAMS — distinct from hospitality `rooms`) */
  dormRooms: {
    cols: [
      { key: "code", ar: "رمز الغرفة", en: "Room #", kind: "id" },
      { key: "building", ar: "المبنى", en: "Building", kind: "text" },
      { key: "floor", ar: "الدور", en: "Floor", kind: "num" },
      { key: "type", ar: "النوع", en: "Type", kind: "text" },
      { key: "capacity", ar: "السعة", en: "Capacity", kind: "num" },
      { key: "monthlyRate", ar: "الإيجار الشهري", en: "Monthly Rate", kind: "money" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "available", ar: "متاحة", en: "Available", tone: "emerald" },
      { key: "occupied", ar: "مشغولة", en: "Occupied", tone: "sky" },
      { key: "reserved", ar: "محجوزة", en: "Reserved", tone: "amber" },
      { key: "maintenance", ar: "صيانة", en: "Maintenance", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const cap = pick(rng, [1, 2, 3, 4, 6]);
      return [
        `RM-${padded(2000 + i, 6)}`,
        lang === "ar" ? `مبنى ${pick(rng, ["أ", "ب", "ج", "د"])}` : `Building ${pick(rng, ["A", "B", "C", "D"])}`,
        String(Math.floor(rng() * 8) + 1),
        lang === "ar" ? (cap === 1 ? "مفردة" : cap === 2 ? "مزدوجة" : cap === 3 ? "ثلاثية" : cap === 4 ? "رباعية" : "جماعية") : (cap === 1 ? "Single" : cap === 2 ? "Double" : cap === 3 ? "Triple" : cap === 4 ? "Quad" : "Dormitory"),
        String(cap),
        money(rng, 800, 3500).toFixed(2),
        pick(rng, ["available", "available", "occupied", "occupied", "reserved", "maintenance"]),
      ];
    },
    count: [20, 40],
    moneyKey: "monthlyRate",
  },

  /* الساكنون — residents (student tenants) */
  residents: {
    cols: [
      { key: "code", ar: "رمز الساكن", en: "Resident #", kind: "id" },
      { key: "name", ar: "الساكن", en: "Resident", kind: "text" },
      { key: "universityId", ar: "الرقم الجامعي", en: "University ID", kind: "text" },
      { key: "university", ar: "الجامعة", en: "University", kind: "text" },
      { key: "college", ar: "الكلية", en: "College", kind: "text" },
      { key: "room", ar: "الغرفة", en: "Room", kind: "text" },
      { key: "building", ar: "المبنى", en: "Building", kind: "text" },
      { key: "leaseStart", ar: "بداية العقد", en: "Lease Start", kind: "date" },
      { key: "leaseEnd", ar: "نهاية العقد", en: "Lease End", kind: "date" },
      { key: "monthlyRate", ar: "الإيجار الشهري", en: "Monthly Rate", kind: "money" },
      { key: "phone", ar: "الجوال", en: "Mobile", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "مقيم", en: "Residing", tone: "emerald" },
      { key: "notice", ar: "إخلاء قريب", en: "Notice Period", tone: "amber" },
      { key: "vacated", ar: "أخلغ", en: "Vacated", tone: "slate" },
      { key: "overdue", ar: "متأخر", en: "Overdue", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      `RES-${padded(3000 + i, 6)}`,
      person(rng, lang),
      `${2024000000 + Math.floor(rng() * 999999)}`,
      lang === "ar" ? pick(rng, ["جامعة الملك سعود", "جامعة الملك عبدالعزيز", "جامعة الإمام", "جامعة الملك فهد"]) : pick(rng, ["King Saud Univ", "King Abdulaziz Univ", "Imam Univ", "KFUPM"]),
      pick(rng, lang === "ar" ? AR_COLLEGES_STU : EN_COLLEGES_STU),
      `RM-${padded(2000 + Math.floor(rng() * 40), 6)}`,
      lang === "ar" ? `مبنى ${pick(rng, ["أ", "ب", "ج", "د"])}` : `Building ${pick(rng, ["A", "B", "C", "D"])}`,
      dateStr(rng),
      `${2026 + Math.floor(rng() * 2)}-06-30`,
      money(rng, 800, 3500).toFixed(2),
      phone(rng),
      pick(rng, ["active", "active", "active", "notice", "overdue", "vacated"]),
    ],
    count: [24, 48],
    moneyKey: "monthlyRate",
  },

  /* عقود الإيجار — leases */
  leases: {
    cols: [
      { key: "code", ar: "رقم العقد", en: "Lease #", kind: "id" },
      { key: "resident", ar: "الساكن", en: "Resident", kind: "text" },
      { key: "room", ar: "الغرفة", en: "Room", kind: "text" },
      { key: "startDate", ar: "تاريخ البدء", en: "Start Date", kind: "date" },
      { key: "endDate", ar: "تاريخ الانتهاء", en: "End Date", kind: "date" },
      { key: "totalAmount", ar: "الإجمالي", en: "Total", kind: "money" },
      { key: "paidAmount", ar: "المدفوع", en: "Paid", kind: "money" },
      { key: "balance", ar: "المتبقي", en: "Balance", kind: "money" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "ساري", en: "Active", tone: "emerald" },
      { key: "paid", ar: "مدفوع", en: "Paid", tone: "sky" },
      { key: "partial", ar: "جزئي", en: "Partial", tone: "amber" },
      { key: "expired", ar: "منتهي", en: "Expired", tone: "slate" },
      { key: "terminated", ar: "ملغى", en: "Terminated", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const total = money(rng, 9600, 42000);
      const paid = Math.round(total * (0.3 + rng() * 0.7) * 100) / 100;
      const balance = Math.round((total - paid) * 100) / 100;
      return [
        `LSE-${padded(5000 + i, 6)}`,
        person(rng, lang),
        `RM-${padded(2000 + Math.floor(rng() * 40), 6)}`,
        dateStr(rng),
        `${2026 + Math.floor(rng() * 2)}-06-30`,
        total.toFixed(2),
        paid.toFixed(2),
        balance.toFixed(2),
        balance === 0 ? "paid" : balance < total * 0.3 ? "partial" : pick(rng, ["active", "active", "partial", "expired"]),
      ];
    },
    count: [20, 36],
    moneyKey: "totalAmount",
  },
};

/* ROUND 132 — the merged registry: the historical curated presets + the four
 * domain families. The spread order keeps curated entries authoritative on
 * any (theoretical) key overlap. */
const ALL_PRESETS: Record<string, ModulePreset> = {
  ...PRESETS,
  ...HEALTH_EDU_PRESETS,
  ...HOSP_SVC_FIN_PRESETS,
  ...OPS_PRESETS,
  ...MEDIA_HR_NPO_PRESETS,
};

/* Semantic fallback for every other module — localized + plausible. */
/* ROUND 129 — sector-aware generic fallback: when the workspace's system
 * sector is known (the row's FOURTH runtime argument — see buildModuleDataset),
 * the "category" column draws sector categories and the "name" column draws
 * sector THINGS for thing-like modules (people-like modules keep person
 * names). No sector → the historical generic pools, byte-for-byte. */
function genericPreset(moduleId: string): ModulePreset {
  const entityLike = isEntityModule(moduleId);
  return {
    cols: [
      { key: "code", ar: "المرجع", en: "Ref", kind: "id" },
      { key: "name", ar: "الاسم", en: "Name", kind: "text" },
      { key: "category", ar: "التصنيف", en: "Category", kind: "text" },
      { key: "qty", ar: "الكمية", en: "Qty", kind: "num" },
      { key: "value", ar: "القيمة", en: "Value", kind: "money" },
      { key: "date", ar: "آخر تحديث", en: "Updated", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "نشط", en: "Active", tone: "emerald" },
      { key: "pending", ar: "قيد المراجعة", en: "Pending", tone: "amber" },
      { key: "archived", ar: "مؤرشف", en: "Archived", tone: "slate" },
      { key: "flagged", ar: "بحاجة إجراء", en: "Action needed", tone: "rose" },
    ],
    row: (rng, i, lang, rowSector) => {
      const v = rowSector ? sectorVocabOf(rowSector) : null;
      const li = lang === "ar" ? 0 : 1;
      return [
        `${moduleId.slice(0, 3).toUpperCase()}-${padded(1000 + i, 8)}`,
        entityLike || !v
          ? person(rng, lang)
          : pick(rng, v.things[li]),
        v
          ? pick(rng, v.cats[li])
          : lang === "ar"
            ? pick(rng, ["أساسي", "ثانوي", "موسمي", "استثنائي"])
            : pick(rng, ["Primary", "Secondary", "Seasonal", "Exceptional"]),
        String(Math.floor(rng() * 300)),
        money(rng, 80, 5200).toFixed(2),
        dateStr(rng),
        pick(rng, ["active", "active", "pending", "archived", "flagged"]),
      ];
    },
    count: [16, 26],
    moneyKey: "value",
  };
}

/* ------------------------------------------------------------------ */
/* ROUND 68 — record-code prefix registry (single source of truth)      */
/* ------------------------------------------------------------------ */

/**
 * The code prefix every module's records use when the workspace creates a
 * NEW row (record-code.ts formats {PREFIX}-00000001 — 8+ digit capacity).
 * Matches the prefixes the seed rows already carry, so generated codes and
 * seeded codes read as one continuous series. Unlisted modules fall back
 * to the first three letters of their id, upper-cased — adding a module to
 * the registry later is a one-line change.
 */
const MODULE_CODE_PREFIXES: Record<string, string> = {
  patients: "MRN",
  appointments: "APT",
  prescriptions: "RX",
  lab: "LAB",
  pharmacy: "RX",
  inventory: "SKU",
  invoices: "INV",
  customers: "CUS",
  staff: "STF",
  orders: "ORD",
  /* ROUND 153 — SAMS module prefixes */
  dormBuildings: "BLG",
  dormRooms: "RM",
  residents: "RES",
  leases: "LSE",
  products: "SKU",
  pos: "POS",
  rooms: "RM",
  bookings: "BKG",
  payments: "PAY",
  suppliers: "SUP",
  purchases: "PUR",
  promotions: "PRM",
  returns: "RET",
  loyalty: "LYL",
  branches: "BRH",
  stocktake: "STK",
  menu: "DSH",
  students: "STU",
  members: "MBR",
  coaches: "CCH",
  classes: "CLS",
  workouts: "WOD",
  equipment: "EQ",
  measurements: "MSR",
  nutrition: "NTR",
  lockers: "LK",
  queue: "TCK",
  vehicles: "VEH",
  lessons: "LES",
  memberships: "MSP",
  /* document-ish modules surfaced across systems */
  ehr: "EHR",
  reports: "RPT",
  medicalfile: "MRF",
  medicalrecords: "MRF",
  /* ROUND 132 — the four domain families' prefix registries merge here so
   * the generated record codes and the seeded demo rows read as one series. */
  ...HEALTH_EDU_CODE_PREFIXES,
  ...HOSP_SVC_FIN_CODE_PREFIXES,
  ...OPS_CODE_PREFIXES,
  ...MEDIA_HR_NPO_CODE_PREFIXES,
};

export function codePrefixFor(moduleId: string): string {
  return MODULE_CODE_PREFIXES[moduleId] ?? moduleId.slice(0, 3).toUpperCase();
}

export function modulePreset(moduleId: string): ModulePreset {
  return ALL_PRESETS[moduleId] ?? genericPreset(moduleId);
}
/* ------------------------------------------------------------------ */
/* dataset assembly                                                     */
/* ------------------------------------------------------------------ */

/** Resolve a system's catalog sector id ("" when unknown/absent). */
function sectorOfSystem(systemId: string | undefined): string | undefined {
  if (!systemId) return undefined;
  return SYSTEM_MAP[systemId]?.c ?? undefined;
}

export function buildModuleDataset(
  instanceId: string,
  moduleId: string,
  lang: Lang,
  currency: string,
  /** ROUND 129 — the workspace's systemId: the demo rows draw
   *  sector-MATCHED vocabulary (see SECTOR_VOCAB). Optional/absent →
   *  the historical generic pools (backward compatible). */
  systemId?: string
): ModuleDataset & { currency: string } {
  const preset = modulePreset(moduleId);
  const sector = sectorOfSystem(systemId);
  const rng = mulberry32(seedFrom(`${instanceId}:${moduleId}`));
  const count = preset.count[0] + Math.floor(rng() * (preset.count[1] - preset.count[0] + 1));

  const rows: ModuleRow[] = Array.from({ length: count }, (_, i) => {
    const values = preset.row(rng, i, lang, sector);
    /* the status key lives in the preset's "status" column — LAST by
       convention; resolved by column kind so presets that place it earlier
       (e.g. vehicles) also assemble correctly. */
    const statusIndex = preset.cols.findIndex((c) => c.kind === "status");
    const statusKey = values[statusIndex >= 0 ? statusIndex : values.length - 1];
    return { id: `${moduleId}-${i + 1}`, values, statusKey };
  });

  /* KPIs */
  const moneyIndex = preset.moneyKey
    ? preset.cols.findIndex((c) => c.key === preset.moneyKey)
    : -1;
  const value =
    moneyIndex >= 0
      ? rows.reduce((sum, r) => sum + (Number(r.values[moneyIndex]) || 0), 0)
      : 0;
  const monthly = Math.max(1, Math.round(count * (0.15 + rng() * 0.25)));
  const active = rows.filter((r) => {
    const st = preset.statuses.find((s) => s.key === r.statusKey);
    return st ? st.tone === "emerald" || st.tone === "sky" : false;
  }).length;
  const growth = Math.round((rng() * 32 - 6) * 10) / 10;

  /* 12-bar series (deterministic daily volumes) */
  const series = Array.from({ length: 12 }, () => Math.floor(rng() * 40) + 6);

  /* status distribution (table order) */
  const statusDist = preset.statuses
    .map((s) => ({ key: s.key, count: rows.filter((r) => r.statusKey === s.key).length }))
    .filter((d) => d.count > 0);

  return {
    cols: preset.cols,
    statuses: preset.statuses,
    rows,
    kpis: { total: count, monthly, active, value, growth },
    series,
    statusDist,
    valueKey: preset.moneyKey ?? null,
    currency,
  };
}

/* ------------------------------------------------------------------ */
/* round 30 — REAL (user-created) records dataset                      */
/* ------------------------------------------------------------------ */

/** One persisted row as delivered by the API (module-record-mapper). */
export interface ModuleRecordInput {
  id: string;
  values: string[];
  statusKey: string;
  /** ROUND 141 (㉕) — the structured payment ledger (paymentsJson). */
  payments?: PaymentEntry[];
  /** ROUND 141 (product extras) — gallery/videos/variants as delivered by
   *  the record DTO (absent = none). */
  gallery?: string[];
  videos?: string[];
  variants?: ProductVariantDTO[];
  /** ROUND 156 — the cover/receipt image ref (managed /api/images URL).
   *  Absent on demo rows; carried through so the add/edit dialog can
   *  prefill the receipt image on edit. */
  imageRef?: string | null;
  createdAt: string;
  updatedAt: string;
}

/**
 * Build the workspace dataset from the owner's REAL rows (round 30):
 *  - cols/statuses come from the module preset (same shape as the demo set);
 *  - rows are the persisted records, newest first;
 *  - KPIs are computed from the real data (total / last-30-days / positive
 *    statuses / money sum), growth compares the last two 30-day windows;
 *  - the 12-bar series buckets creation dates into the last 12 weeks;
 *  - the status distribution counts real rows (unknown keys are grouped
 *    under their raw key label with a slate tone).
 */
export function buildRecordsDataset(
  moduleId: string,
  records: ModuleRecordInput[],
  lang: Lang,
  currency: string,
  /** ROUND 129 — optional systemId: preset cols stay the contract, but the
   *  resolved sector keeps the demo fallback coherent when rows are absent. */
  systemId?: string
): ModuleDataset & { currency: string } {
  const preset = modulePreset(moduleId);

  /* rows — values are realigned to the preset cols (short arrays pad with
     empty strings; extra values are kept but never displayed) */
  const rows: ModuleRow[] = records.map((r) => {
    const values = preset.cols.map((_c, i) => r.values[i] ?? "");
    const statusIndex = preset.cols.findIndex((c) => c.kind === "status");
    return {
      id: r.id,
      values,
      statusKey: r.statusKey || (statusIndex >= 0 ? r.values[statusIndex] ?? "" : ""),
      /* ROUND 141 (㉕) — the structured payment ledger rides the row so the
         record dialog prefill + the print-doc builders see it. */
      payments: r.payments ?? [],
      /* ROUND 141 (product extras) — gallery/videos/variants ride the row so
         the add/edit record dialog prefills them on the catalog module. */
      gallery: r.gallery ?? [],
      videos: r.videos ?? [],
      variants: r.variants ?? [],
      /* ROUND 156 — the cover/receipt image rides the row so the add/edit
         dialog prefills it on the expenses module. */
      imageRef: r.imageRef ?? null,
    };
  });

  const now = Date.now();
  const DAY = 86_400_000;
  const created = records.map((r) => new Date(r.createdAt).getTime() || now);
  const inLast = (days: number) => created.filter((t) => now - t < days * DAY).length;
  const monthly = inLast(30);
  const previous = inLast(60) - monthly;
  const growth =
    previous > 0
      ? Math.max(-99, Math.min(999, Math.round(((monthly - previous) / previous) * 1000) / 10))
      : monthly > 0
        ? 100
        : 0;

  const moneyIndex = preset.moneyKey
    ? preset.cols.findIndex((c) => c.key === preset.moneyKey)
    : -1;
  const value =
    moneyIndex >= 0
      ? rows.reduce((sum, r) => sum + (Number(r.values[moneyIndex]) || 0), 0)
      : 0;
  const active = rows.filter((r) => {
    const st = preset.statuses.find((s) => s.key === r.statusKey);
    return st ? st.tone === "emerald" || st.tone === "sky" : false;
  }).length;

  /* 12 weekly buckets over the last 84 days */
  const weekStart = now - 84 * DAY;
  const series = Array.from({ length: 12 }, (_, i) => {
    const from = weekStart + i * 7 * DAY;
    const to = from + 7 * DAY;
    return created.filter((t) => t >= from && t < to).length;
  });

  /* status distribution — preset order first, then unknown real keys */
  const dist = preset.statuses
    .map((s) => ({ key: s.key, count: rows.filter((r) => r.statusKey === s.key).length }))
    .filter((d) => d.count > 0);
  const known = new Set(preset.statuses.map((s) => s.key));
  const unknownKeys = [...new Set(rows.map((r) => r.statusKey).filter((k) => k && !known.has(k)))];
  for (const key of unknownKeys) {
    dist.push({ key, count: rows.filter((r) => r.statusKey === key).length });
  }

  return {
    cols: preset.cols,
    statuses: preset.statuses,
    rows,
    kpis: { total: rows.length, monthly, active, value, growth },
    series,
    statusDist: dist,
    valueKey: preset.moneyKey ?? null,
    currency,
  };
}
