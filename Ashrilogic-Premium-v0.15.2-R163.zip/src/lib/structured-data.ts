/**
 * Ashrilogic — structured-data source.
 *
 * English FAQ Q&A pairs used by the JSON-LD FAQPage schema (search engines
 * index English best). Kept in sync with the AR/EN i18n FAQ keys.
 */
export const FAQS: { q: string; a: string }[] = [
  {
    q: "Do I need technical expertise to set up my system?",
    a: "Not at all. The smart setup wizard walks you through 7 visual steps — org data, modules, admin, preferences — then launches a ready-to-use dashboard instantly.",
  },
  {
    q: "Are the systems multilingual?",
    a: "Yes — the platform is fully multilingual (11 languages: Arabic, English, and Hindi with complete translations, plus French, Spanish, Portuguese, German, Chinese, Japanese, Korean, and Turkish fully wired) with instant RTL/LTR switching across the entire platform — UI, modules, settings, and dashboard.",
  },
  {
    q: "Can I modify modules after launch?",
    a: "Absolutely. You can enable or disable any module from the dashboard at any time without data loss, with every change tracked in the activity log.",
  },
  {
    q: "What about my data security?",
    a: "Two-factor auth, full audit log, multi-level roles, daily automatic backups, and multi-layer protection for each system individually.",
  },
  {
    q: "Is there a trial version?",
    a: "Yes, you can enable demo data during setup to explore the system before entering your real data.",
  },
  {
    q: "How do I get technical support?",
    a: "Support is available 24/7 via email, phone, and the help center, plus official social media channels for fast response.",
  },
  {
    q: "Is my data isolated from other organizations?",
    a: "Yes — every system runs in a fully isolated workspace: inventory, invoices, customers, settings, website, and messages are strictly separated per tenant, with encrypted storage and a tamper-evident audit trail.",
  },
  {
    q: "Do the systems work on phones and tablets?",
    a: "Absolutely — the entire platform is built mobile-first and adapts seamlessly to every screen size, from phones to tablets to desktops, with no layout overlap or loss of functionality.",
  },
];
