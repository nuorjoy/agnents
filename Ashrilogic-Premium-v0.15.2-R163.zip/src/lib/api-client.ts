/**
 * Ashrilogic — typed client-side fetch helpers for the REST API.
 * All requests use relative URLs (gateway-safe), same-origin credentials and
 * JSON headers. Non-2xx responses throw an `ApiError` carrying the server's
 * `{ error }` message so react-query can surface it in toasts.
 */
import type {
  ActivityDTO,
  ActivityKind,
  AddonCatalogItemDTO,
  AddonOrderCreatePayload,
  AddonOrderCreateResult,
  AddonOrderDTO,
  AdminNotifFeedDTO,
  AdminWalletTopupDTO,
  AdminAddonOrderDTO,
  AdminPlanOrderDTO,
  AdminSubscriberGovernanceResult,
  AdminSiteDTO,
  AdminStoresDTO,
  CouponPreviewDTO,
  SiteOrderAdminDTO,
  SiteOrderDTO,
  SiteOrderStatus,
  SiteOrderTrackedDTO,
  SiteInquiryDTO,
  SiteInquiryTriageDTO,
  OrderStatusEvent,
  OrderPageDTO,
  ActivityPageDTO,
  AdminActivityPageDTO,
  SiteProductDTO,
  StoreAccountDTO,
  StoreAddressDTO,
  StorePaymentMethodDTO,
  SiteReviewDTO,
  SiteReviewsPageDTO,
  OwnerReviewDTO,
  OwnerReviewsPageDTO,
  StoreCouponDTO,
  AdminSiteTrendsDTO,
  AdminUserDTO,
  AdminUserPayload,
  AiInsightsDTO,
  AiSettingsDTO,
  AiSettingsPayload,
  EmailLogPageDTO,
  MailPanelDTO,
  MailSettingsDTO,
  MailSettingsPayload,
  MailTestResultDTO,
  AuditEntryDTO,
  BackupVerifyDTO,
  BlogCardDTO,
  BlogPageDTO,
  BlogPostDTO,
  BlogPostPayload,
  AdminBlogPageDTO,
  AdminBlogPostDTO,
  AdminPartnersDTO,
  AdminSectorPartnerDTO,
  SectorPartnerDTO,
  SectorPartnerPayload,
  CampaignDTO,
  Catalog,
  CreateInstancePayload,
  InstanceDTO,
  InstanceStats,
  MfaChallengeDTO,
  MfaSetupDTO,
  MfaStatusDTO,
  ModuleRecordDTO,
  OwnerProfileDTO,
  OwnerProfilePayload,
  PackageDTO,
  PackagePayload,
  PaymentInstructionsDTO,
  PlanOrderCreateResult,
  WalletDTO,
  WalletLookupDTO,
  WalletTransferReceiptDTO,
  WalletTopupDTO,
  PlanOrderCreatePayload,
  PlanOrderDTO,
  TenantPaymentMethodDTO,
  PlatformSettingsDTO,
  PlatformSettingsPayload,
  PublicTicketPayload,
  SiteCustomerAdminDTO,
  SiteCustomerCountsDTO,
  SiteCustomerStatus,
  SiteCustomerDTO as WorkspaceSiteCustomerDTO,
  SiteContent,
  SiteDTO,
  SessionInfoDTO,
  SessionsDTO,
  SitePayload,
  SupportContactDTO,
  SupportTicketDTO,
  SupportTicketPayload,
  TeamMemberDTO,
  TeamMemberPayload,
  UpdateInstancePayload,
  UpdateTeamMemberPayload,
  WebauthnCredentialDTO,
  WorkspaceUsageDTO,
  ShiftDTO,
  ShiftsResponseDTO,
} from "@/lib/types";

/** Error thrown for non-2xx API responses; message comes from the server. */
export class ApiError extends Error {
  readonly status: number;
  /** machine-readable error code from the JSON body, when present
   * (round 40: routes return {error, code} — e.g. "BANNED" vs
   * "EMAIL_UNVERIFIED", both 403 — callers need the code to pick the
   * right localized presentation instead of guessing by status). */
  readonly code?: string;
  /** ROUND 86 — the precise seconds a cooldown 429 asks the client to wait
   *  (forgot-password resend: { error: "FORGOT_COOLDOWN", retryAfterSec }). */
  readonly retryAfterSec?: number;

  constructor(message: string, status: number, code?: string, retryAfterSec?: number) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
    this.retryAfterSec = retryAfterSec;
  }
}

async function request<T>(url: string, init?: RequestInit): Promise<T> {
  const headers: Record<string, string> = { ...(init?.headers as Record<string, string> | undefined) };
  if (init?.body !== undefined) headers["Content-Type"] = "application/json";

  const res = await fetch(url, { ...init, credentials: "same-origin", headers });

  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    let code: string | undefined;
    let retryAfterSec: number | undefined;
    try {
      const data = (await res.json()) as { error?: string; code?: string; retryAfterSec?: number };
      if (data && typeof data.error === "string" && data.error) {
        message = data.error;
        /* routes answer 429 with the machine code inside {error} — keep the
           raw message AND surface it as code so callers switch on it */
        if (res.status === 429 && /^[A-Z_]+$/.test(data.error)) code = data.error;
      }
      if (data && typeof data.code === "string" && data.code) code = data.code;
      if (
        data &&
        typeof data.retryAfterSec === "number" &&
        Number.isFinite(data.retryAfterSec) &&
        data.retryAfterSec > 0
      ) {
        retryAfterSec = Math.floor(data.retryAfterSec);
      }
    } catch {
      // non-JSON error body — keep the generic message
    }
    throw new ApiError(message, res.status, code, retryAfterSec);
  }

  if (res.status === 204) return undefined as T;
  return (await res.json()) as T;
}

function post<T>(url: string, body: unknown): Promise<T> {
  return request<T>(url, { method: "POST", body: JSON.stringify(body) });
}

function put<T>(url: string, body: unknown): Promise<T> {
  return request<T>(url, { method: "PUT", body: JSON.stringify(body) });
}

function patch<T>(url: string, body: unknown): Promise<T> {
  return request<T>(url, { method: "PATCH", body: JSON.stringify(body) });
}

/* ----------------------------- catalog ----------------------------- */

export async function fetchCatalog(): Promise<Catalog> {
  return request<Catalog>("/api/catalog");
}

/* ---------------------------- instances ----------------------------- */

/**
 * Instance directory — authentication-aware (round 36). Anonymous callers
 * receive the minimal PUBLIC projection; signed-in owners receive their own
 * full DTOs; admins receive the full panel list. Components that need the
 * owner-scoped list should prefer `fetchMyInstances`.
 */
export async function fetchInstances(): Promise<InstanceDTO[]> {
  return request<InstanceDTO[]>("/api/instances");
}

/**
 * Round 36 — authenticated "my systems" listing (the signed-in owner's
 * workspaces, full DTOs). 401 for anonymous callers — use `fetchInstances`
 * (public projection) as the anonymous fallback.
 */
export async function fetchMyInstances(): Promise<InstanceDTO[]> {
  return request<InstanceDTO[]>("/api/instances/mine");
}

/**
 * ROUND 82 (batch-5 ②) — verify the signed-in owner's CURRENT workspace
 * password while provisioning ANOTHER system from the «أنظمتك المنشأة»
 * screen ("reuse my account" mode). 200 ⇒ { ok, admin:{name,email} } for
 * the wizard prefill; 401 ⇒ wrong password (surfaced inline, no shake).
 */
export async function verifyOwnerPassword(
  password: string
): Promise<{ ok: boolean; admin: { name: string; email: string } }> {
  return request<{ ok: boolean; admin: { name: string; email: string } }>(
    "/api/instances/mine/verify-password",
    {
      method: "POST",
      body: JSON.stringify({ password }),
    }
  );
}

/**
 * Round 36 — email-first workspace sign-in with SERVER-SIDE credential
 * resolution (no public directory, no enumeration). Returns the
 * authenticated instance + how many workspaces share the email.
 */
export interface InstanceLoginResult {
  ok: boolean;
  instance: InstanceDTO;
  owned: number;
}

/** The MFA challenge returned instead of a session (ROUND 45). */
export interface InstanceMfaChallenge {
  ok: boolean;
  mfaRequired: true;
  instanceId: string;
  orgName: string;
  systemId: string;
  ticket: string;
  passkeys: boolean;
  owned: number;
}

export async function instanceLoginByEmail(
  payload: { email: string; password: string; reactivate?: boolean }
): Promise<InstanceLoginResult | InstanceMfaChallenge> {
  return post<InstanceLoginResult | InstanceMfaChallenge>(
    "/api/instances/auth/login",
    payload
  );
}

export async function fetchInstance(
  id: string
): Promise<{ instance: InstanceDTO; stats: InstanceStats; members: TeamMemberDTO[] }> {
  return request<{ instance: InstanceDTO; stats: InstanceStats; members: TeamMemberDTO[] }>(
    `/api/instances/${encodeURIComponent(id)}`
  );
}

export async function createInstance(payload: CreateInstancePayload): Promise<InstanceDTO> {
  return post<InstanceDTO>("/api/instances", payload);
}

/** ROUND 134-E — wizard availability probe result (booleans only, by design). */
export interface TenantAvailabilityResult {
  /** true when the probed email is unclaimed (or was not probed) */
  emailFree: boolean;
  /** true when the probed phone is already registered (or was not probed) */
  phoneUsed: boolean;
}

/**
 * ROUND 134-E — live signup availability probe (deep semantics: the verdict
 * covers live + soft-deleted + demo rows, exactly like the submit-time
 * guard). At least one of email/phone must be provided.
 */
export async function checkTenantAvailability(payload: {
  email?: string;
  phone?: string;
}): Promise<TenantAvailabilityResult> {
  return post<TenantAvailabilityResult>("/api/instances/check-availability", payload);
}

export async function updateInstance(id: string, payload: UpdateInstancePayload): Promise<InstanceDTO> {
  return patch<InstanceDTO>(`/api/instances/${encodeURIComponent(id)}`, payload);
}

/* ------------------ ROUND 136 — Super-Admin instance ops ------------------ */

/** One posture chip row of the ops drilldown's audit mini-list (action key +
 *  actor surface + age only — the trail's own masking already applies). */
export interface InstanceOpsAuditRow {
  id: string;
  action: string;
  actorType: string;
  targetLabel: string | null;
  createdAt: string;
}

/** GET /api/admin/instances/[id]/ops envelope (super-only, ids/counts/ages
 *  ONLY — no PII keys by design; the org name is the admin-directory-level
 *  identity the console already shows). */
export interface InstanceOpsDTO {
  instance: {
    id: string;
    name: string;
    systemId: string;
    demo: boolean;
    entitlement: { state: "active" | "trial" | "locked"; lockReason: string | null };
    plan: { nameAr: string; nameEn: string; maxModules: number | null; maxStorageMb: number | null } | null;
    term: {
      planActivatedAt: string | null;
      planCycle: string | null;
      planExpiresAt: string | null;
      planDaysLeft: number | null;
      trialEndsAt: string | null;
      trialDaysLeft: number | null;
    };
    ban: { active: boolean; kind: string | null; until: string | null; reason: string | null; at: string | null };
    sessionVersion: number;
  };
  health: {
    activeSessions: number;
    lastActivityAt: string | null;
    lastActivityAgeMs: number | null;
    storageUsedBytes: number;
    storageQuotaMb: number | null;
    storagePct: number | null;
    membersCount: number;
    modulesEnabled: number;
    planModuleLimit: number | null;
  };
  store: {
    moduleId: string | null;
    productsCount: number;
    lowStockCount: number;
    ordersCount: number;
    ordersCompleted: number;
    revenue: { currency: string; value: number } | null;
  };
  site: { live: boolean; views: number; customersCount: number; inquiriesCount: number };
  webhooks: { activeEndpoints: number; failedDeliveries24h: number };
  shifts: { openCount: number; lastClosedAt: string | null };
  audit: { total: number; recent: InstanceOpsAuditRow[] };
  generatedAt: string;
}

/** ROUND 136 — the per-instance ops telemetry drilldown (super-only). */
export async function fetchInstanceOps(id: string): Promise<InstanceOpsDTO> {
  return request<InstanceOpsDTO>(`/api/admin/instances/${encodeURIComponent(id)}/ops`);
}

/** ROUND 136 — the strict session lever: bumps the workspace session epoch
 *  + revokes every live registry row; resolves with the destroyed count. */
export async function revokeInstanceSessions(id: string): Promise<{ revoked: number }> {
  return request<{ revoked: number }>(
    `/api/admin/instances/${encodeURIComponent(id)}/sessions/revoke-all`,
    { method: "POST", body: JSON.stringify({}) }
  );
}

export async function deleteInstance(
  id: string,
  payload?: { password?: string; reason?: string }
): Promise<void> {
  await request<{ ok: boolean }>(`/api/instances/${encodeURIComponent(id)}`, {
    method: "DELETE",
    ...(payload ? { body: JSON.stringify(payload) } : {}),
  });
}

/* ------------------ ROUND 87 (trash) — platform + workspace ------------------ */

/** Trash item row as served by /api/admin/trash + /api/instances/[id]/trash. */
export interface TrashItemDTO {
  id: string;
  entity: string;
  instanceId: string | null;
  instanceLabel: string | null;
  label: string;
  detail: string | null;
  deletedAt: string;
  deletedByName: string | null;
  deleteReason: string | null;
  expiresAt: string;
  daysLeft: number;
  meta: Record<string, string | number | boolean | null>;
}

export interface TrashStatsDTO {
  total: number;
  byEntity: Record<string, number>;
  expiringSoon: number;
  oldestAt: string | null;
  retentionDays: number;
}

export interface TrashListDTO {
  items: TrashItemDTO[];
  stats: TrashStatsDTO;
}

export async function fetchAdminTrash(params: {
  entity?: string | null;
  q?: string | null;
  limit?: number;
  offset?: number;
}): Promise<TrashListDTO> {
  const qs = new URLSearchParams();
  if (params.entity) qs.set("entity", params.entity);
  if (params.q) qs.set("q", params.q);
  if (params.limit) qs.set("limit", String(params.limit));
  if (params.offset) qs.set("offset", String(params.offset));
  return request<TrashListDTO>(`/api/admin/trash${qs.size ? `?${qs}` : ""}`);
}

export async function adminTrashAction(payload: {
  action: "restore" | "purge" | "purgeExpired";
  entity?: string;
  id?: string;
}): Promise<{ ok: boolean; label?: string | null; purged?: number }> {
  return post<{ ok: boolean; label?: string | null; purged?: number }>("/api/admin/trash", payload);
}

export async function fetchInstanceTrash(
  id: string,
  params: { entity?: string | null; q?: string | null; limit?: number; offset?: number }
): Promise<TrashListDTO> {
  const qs = new URLSearchParams();
  if (params.entity) qs.set("entity", params.entity);
  if (params.q) qs.set("q", params.q);
  if (params.limit) qs.set("limit", String(params.limit));
  if (params.offset) qs.set("offset", String(params.offset));
  return request<TrashListDTO>(`/api/instances/${encodeURIComponent(id)}/trash${qs.size ? `?${qs}` : ""}`);
}

export async function instanceTrashAction(
  id: string,
  payload: { action: "restore" | "purge"; entity: string; id: string }
): Promise<{ ok: boolean; label?: string | null }> {
  return post<{ ok: boolean; label?: string | null }>(
    `/api/instances/${encodeURIComponent(id)}/trash`,
    payload
  );
}

/* -------------- ROUND 87 (account lifecycle) — owner self-service ------------- */

export async function disableOwnWorkspace(
  id: string,
  payload: { password: string; reason?: string }
): Promise<{ ok: boolean; disabledAt: string }> {
  return post<{ ok: boolean; disabledAt: string }>(
    `/api/instances/${encodeURIComponent(id)}/self-disable`,
    payload
  );
}

/* --------------------- plan orders + usage (ROUND 47) --------------------- */

/** ROUND 47 — real server-computed storage usage (tamper-proof by design). */
export async function fetchInstanceUsage(id: string): Promise<WorkspaceUsageDTO> {
  return request<WorkspaceUsageDTO>(`/api/instances/${encodeURIComponent(id)}/usage`);
}

/** ROUND 47 — the workspace's own activation/payment requests. */
export async function fetchPlanOrders(id: string): Promise<PlanOrderDTO[]> {
  return request<PlanOrderDTO[]>(`/api/instances/${encodeURIComponent(id)}/plan-orders`);
}

/** ROUND 48 — ACTIVE console-managed payment methods (tenant-safe subset:
 * id + kind + label; receiving details live on the server-built invoice). */
export async function fetchPlanMethods(id: string): Promise<TenantPaymentMethodDTO[]> {
  return request<TenantPaymentMethodDTO[]>(`/api/instances/${encodeURIComponent(id)}/plan-methods`);
}

/**
 * ROUND 47 — create a plan-activation payment request. The payload carries
 * NO money: the server recomputes the amount from the live package price.
 * ROUND 141 — payload.payWith "wallet" selects the INSTANT wallet checkout
 * (returns the paid order + the fresh instance + the post-debit balance).
 */
export async function createPlanOrder(
  id: string,
  payload: PlanOrderCreatePayload
): Promise<PlanOrderCreateResult> {
  return post<PlanOrderCreateResult>(
    `/api/instances/${encodeURIComponent(id)}/plan-orders`,
    payload
  );
}

/** ROUND 47 — tenant cancels their own pending activation request. */
export async function cancelPlanOrder(id: string, orderId: string): Promise<PlanOrderDTO> {
  return patch<PlanOrderDTO>(
    `/api/instances/${encodeURIComponent(id)}/plan-orders/${encodeURIComponent(orderId)}`,
    { action: "cancel" }
  );
}

/* --------------------- add-on orders (ROUND 141) --------------------- */

/** ROUND 141 — the add-on catalog (live active states) + own history. */
export async function fetchAddonCatalog(
  id: string
): Promise<{ features: AddonCatalogItemDTO[]; orders: AddonOrderDTO[] }> {
  return request<{ features: AddonCatalogItemDTO[]; orders: AddonOrderDTO[] }>(
    `/api/instances/${encodeURIComponent(id)}/addon-orders`
  );
}

/** ROUND 141 — create an add-on purchase request (server-priced).
 *  payWith "wallet" selects the INSTANT wallet checkout. */
export async function createAddonOrder(
  id: string,
  payload: AddonOrderCreatePayload
): Promise<AddonOrderCreateResult> {
  return post<AddonOrderCreateResult>(
    `/api/instances/${encodeURIComponent(id)}/addon-orders`,
    payload
  );
}

/* ------------------- wallet — محفظة Ashrilogic (ROUND 141) ------------------- */

/** ROUND 141 — the workspace's wallet projection (balance in minor units,
 *  the pending top-up total, the append-only ledger + top-up requests). */
export async function fetchWallet(id: string): Promise<WalletDTO> {
  return request<WalletDTO>(`/api/instances/${encodeURIComponent(id)}/wallet`);
}

/** ROUND 144 — resolve a wallet NUMBER to the receiver preview the sender
 *  confirms before executing a transfer (owner session only). ROUND 145 —
 *  the preview carries identity ONLY: never the receiver's balance (the
 *  server strips it at the engine boundary — see WalletLookupDTO). */
export async function lookupWalletReceiver(
  id: string,
  walletNo: number
): Promise<{ receiver: WalletLookupDTO }> {
  return post<{ receiver: WalletLookupDTO }>(
    `/api/instances/${encodeURIComponent(id)}/wallet/transfer/lookup`,
    { walletNo }
  );
}

/** ROUND 144 — EXECUTE an inter-wallet transfer (PIN-gated, atomic,
 *  zero-sum; the amount is the RAW dual-numeral string parsed server-side). */
export async function transferWalletFunds(
  id: string,
  payload: { toWalletNo: number; amount: string; note?: string; pin: string }
): Promise<{ receipt: WalletTransferReceiptDTO }> {
  return post<{ receipt: WalletTransferReceiptDTO }>(
    `/api/instances/${encodeURIComponent(id)}/wallet/transfer`,
    payload
  );
}

/** ROUND 141 — create a wallet top-up REQUEST. The amount is the RAW
 *  dual-numeral string (١٢٣ / 1,234.50 both legal) — the server parses,
 *  bounds and prices it. Returns the request + server-built instructions. */
export async function createWalletTopup(
  id: string,
  payload: { amount: string; methodId: string }
): Promise<{ topup: WalletTopupDTO; instructions: PaymentInstructionsDTO }> {
  return post<{ topup: WalletTopupDTO; instructions: PaymentInstructionsDTO }>(
    `/api/instances/${encodeURIComponent(id)}/wallet/topup`,
    payload
  );
}

/** ROUND 141 — tenant cancels their own pending top-up request. */
export async function cancelWalletTopup(
  id: string,
  topupId: string
): Promise<{ ok: true }> {
  return patch<{ ok: true }>(
    `/api/instances/${encodeURIComponent(id)}/wallet/topup/${encodeURIComponent(topupId)}`,
    { action: "cancel" }
  );
}

/** ROUND 141 — the Super-Admin aggregated notification feed (real events:
 *  pending queues + open tickets + new subscribers). */
export async function fetchAdminNotifFeed(): Promise<AdminNotifFeedDTO> {
  return request<AdminNotifFeedDTO>(`/api/admin/notifications`);
}

/** ROUND 141 — the console's wallet top-up requests queue. */
export async function fetchAdminWalletTopups(
  status?: "pending" | "paid" | "cancelled"
): Promise<AdminWalletTopupDTO[]> {
  const q = status ? `?status=${encodeURIComponent(status)}` : "";
  return request<AdminWalletTopupDTO[]>(`/api/admin/wallet-topups${q}`);
}

/** ROUND 141 — the console confirms a top-up (credits the wallet atomically)
 *  or cancels it. */
export async function adminWalletTopupAction(
  topupId: string,
  action: "paid" | "cancelled"
): Promise<{ ok: true; balanceAfterMinor?: number }> {
  return patch<{ ok: true; balanceAfterMinor?: number }>(
    `/api/admin/wallet-topups/${encodeURIComponent(topupId)}`,
    { action }
  );
}

/** ROUND 141 — the console's direct wallet adjustment (credit/debit). */
export async function adminWalletAdjust(payload: {
  instanceId: string;
  amount: string;
  direction: "credit" | "debit";
  note?: string;
}): Promise<{ ok: true; balanceAfterMinor: number }> {
  return post<{ ok: true; balanceAfterMinor: number }>(`/api/admin/wallet-adjust`, payload);
}

/** ROUND 141 — tenant cancels their own pending add-on request. */
export async function cancelAddonOrder(id: string, orderId: string): Promise<AddonOrderDTO> {
  return patch<AddonOrderDTO>(
    `/api/instances/${encodeURIComponent(id)}/addon-orders/${encodeURIComponent(orderId)}`,
    { action: "cancel" }
  );
}

/* ---------------------------- activities ---------------------------- */

/** ROUND 57 — one page of the keyset-paginated activity feed (dashboard
 *  activity view). Pass the returned `nextCursor` back verbatim for the
 *  next page; `total` is the instance-wide count. */
export async function fetchActivitiesPage(
  id: string,
  opts: { limit?: number; cursor?: string | null } = {}
): Promise<ActivityPageDTO> {
  const qs = new URLSearchParams();
  if (opts.limit !== undefined) qs.set("limit", String(opts.limit));
  if (opts.cursor) qs.set("cursor", opts.cursor);
  const suffix = qs.size > 0 ? `?${qs.toString()}` : "";
  return request<ActivityPageDTO>(
    `/api/instances/${encodeURIComponent(id)}/activities${suffix}`
  );
}

/** Bounded newest-first window (billing view + legacy call sites).
 *  Maps the paginated envelope back to a plain array — callers that don't
 *  page keep their original contract. */
export async function fetchActivities(id: string, limit = 20): Promise<ActivityDTO[]> {
  const page = await request<ActivityPageDTO>(
    `/api/instances/${encodeURIComponent(id)}/activities?limit=${limit}`
  );
  return page.activities;
}

/** ROUND 65 — admin-wide activity stream (control panel النشاط view): every
 *  instance's events in ONE keyset-paginated feed, org/system-enriched.
 *  Same cursor contract as the instance feed; `orgs` powers the org filter. */
export async function fetchAdminActivitiesPage(
  opts: { limit?: number; cursor?: string | null } = {}
): Promise<AdminActivityPageDTO> {
  const qs = new URLSearchParams();
  if (opts.limit !== undefined) qs.set("limit", String(opts.limit));
  if (opts.cursor) qs.set("cursor", opts.cursor);
  const suffix = qs.size > 0 ? `?${qs.toString()}` : "";
  return request<AdminActivityPageDTO>(`/api/admin/activities${suffix}`);
}

export async function addActivity(
  id: string,
  kind: ActivityKind,
  meta?: Record<string, string>
): Promise<ActivityDTO> {
  return post<ActivityDTO>(`/api/instances/${encodeURIComponent(id)}/activities`, { kind, meta });
}

/* ------------------------- upgrade requests ------------------------- */

/** Plan-upgrade request filed from the subscriber dashboard (billing ticket). */
export async function requestPlanUpgrade(
  id: string,
  payload: { packageId: string; subject: string; message: string }
): Promise<SupportTicketDTO> {
  return post<SupportTicketDTO>(`/api/instances/${encodeURIComponent(id)}/tickets`, payload);
}

/* ------------------------ workspace sessions ------------------------- */

/** Workspace sign-in — sets the HTTP-only instance cookie on success. */
export async function instanceLogin(
  id: string,
  payload: { email: string; password: string }
): Promise<{ ok: boolean; instance: InstanceDTO } | InstanceMfaChallenge> {
  return post<{ ok: boolean; instance: InstanceDTO } | InstanceMfaChallenge>(
    `/api/instances/${encodeURIComponent(id)}/auth/login`,
    payload
  );
}

/** Workspace sign-out — clears the instance cookie. */
export async function instanceLogout(id: string): Promise<void> {
  await request<{ ok: boolean }>(`/api/instances/${encodeURIComponent(id)}/auth/login`, {
    method: "DELETE",
  });
}

/** Silent probe: is the browser already signed into this workspace? */
export async function fetchInstanceSession(
  id: string
): Promise<{ authenticated: boolean; adminEmail?: string }> {
  return request<{ authenticated: boolean; adminEmail?: string }>(
    `/api/instances/${encodeURIComponent(id)}/auth/session`
  );
}

/* ------------------------------ members ----------------------------- */

export async function fetchMembers(id: string): Promise<TeamMemberDTO[]> {
  return request<TeamMemberDTO[]>(`/api/instances/${encodeURIComponent(id)}/members`);
}

export async function addMember(id: string, payload: TeamMemberPayload): Promise<TeamMemberDTO> {
  return post<TeamMemberDTO>(`/api/instances/${encodeURIComponent(id)}/members`, payload);
}

/** ROUND 68 — update one member's core fields and/or extended profile. */
export async function updateMember(
  id: string,
  memberId: string,
  payload: UpdateTeamMemberPayload
): Promise<TeamMemberDTO> {
  return request<TeamMemberDTO>(
    `/api/instances/${encodeURIComponent(id)}/members?memberId=${encodeURIComponent(memberId)}`,
    { method: "PATCH", body: JSON.stringify(payload) }
  );
}

export async function removeMember(id: string, memberId: string): Promise<void> {
  await request<{ ok: boolean }>(
    `/api/instances/${encodeURIComponent(id)}/members/${encodeURIComponent(memberId)}`,
    { method: "DELETE" }
  );
}

/* ------------------------------ export ------------------------------ */

/** Direct download URL for the CSV/JSON export (used by link/button href). */
export function instanceExportUrl(
  id: string,
  type: "activities" | "members" | "summary",
  format: "csv" | "json" = "csv"
): string {
  return `/api/instances/${encodeURIComponent(id)}/export?type=${type}${
    format === "json" ? "&format=json" : ""
  }`;
}

/* ------------------------ public website (round 24) ------------------ */

/* NOTE: `WorkspaceSiteCustomerDTO` is the owner-facing row from
 * types.ts (round 29 "عملاء الموقع" view); the locally exported
 * SiteCustomerDTO below it stays the visitor's own self-record. */

/** The workspace's website record (auto-creates the draft server-side). */
export async function fetchSite(id: string): Promise<SiteDTO> {
  return request<SiteDTO>(`/api/instances/${encodeURIComponent(id)}/site`);
}

/** Save website content / theme / publish state (workspace session). */
export async function updateSite(id: string, payload: SitePayload): Promise<SiteDTO> {
  return request<SiteDTO>(`/api/instances/${encodeURIComponent(id)}/site`, {
    method: "PUT",
    body: JSON.stringify(payload),
  });
}

/** Round 33 — AI draft translations for the EN site content (workspace
 *  session; returns suggestions only — nothing is persisted). */
export interface SiteTranslateResult {
  en: {
    tagline: string;
    heroTitle: string;
    heroDesc: string;
    aboutTitle: string;
    about: string;
    contactAddress: string;
    workingHours: string;
  };
  services: { index: number; titleEn: string; descEn: string }[];
}

export async function translateSiteContent(
  id: string,
  content: SiteContent
): Promise<SiteTranslateResult> {
  return post<SiteTranslateResult>(
    `/api/instances/${encodeURIComponent(id)}/site/translate`,
    content
  );
}

/** Public visit ping from a published site page (best-effort counter). */
export async function pingSiteVisit(id: string): Promise<{ ok: boolean; views: number | null }> {
  return post<{ ok: boolean; views: number | null }>(
    `/api/sites/${encodeURIComponent(id)}/visit`,
    {}
  );
}

/** Public inquiry form on a published site → linked support ticket. */
export async function sendSiteInquiry(
  id: string,
  payload: { name: string; email: string; message: string }
): Promise<SupportTicketDTO> {
  return post<SupportTicketDTO>(`/api/sites/${encodeURIComponent(id)}/contact`, payload);
}

/* ------------- workspace site customers (round 29, "عملاء الموقع") ------------- */

/**
 * List the members registered through THIS workspace's public website,
 * newest first, each with a live public-inquiry count. 404 (code
 * SITE_NOT_FOUND) when the instance has no website yet.
 */
export async function fetchInstanceSiteCustomers(
  id: string
): Promise<WorkspaceSiteCustomerDTO[]> {
  return request<WorkspaceSiteCustomerDTO[]>(
    `/api/instances/${encodeURIComponent(id)}/site/customers`
  );
}

/** Ban or reactivate one website member (banning cuts off their live session). */
export async function setInstanceSiteCustomerStatus(
  id: string,
  customerId: string,
  status: SiteCustomerStatus
): Promise<{ ok: boolean }> {
  return patch<{ ok: boolean }>(
    `/api/instances/${encodeURIComponent(id)}/site/customers/${encodeURIComponent(customerId)}`,
    { status }
  );
}

/** ROUND 75 — owner-side verification actions on one website member:
 *  `verify` marks the address confirmed on the customer's behalf (the
 *  staff-assisted path — identity confirmed in person / by phone),
 *  `resendVerify` re-dispatches the single-use verification email. */
export async function verifyInstanceSiteCustomer(
  id: string,
  customerId: string,
  action: "verify" | "resendVerify"
): Promise<{ ok: boolean; resent?: boolean }> {
  return patch<{ ok: boolean; resent?: boolean }>(
    `/api/instances/${encodeURIComponent(id)}/site/customers/${encodeURIComponent(customerId)}`,
    action === "verify" ? { verify: true } : { resendVerify: true }
  );
}

/** Permanently remove one website member's account (inquiries survive). */
export async function deleteInstanceSiteCustomer(
  id: string,
  customerId: string
): Promise<void> {
  await request<{ ok: boolean }>(
    `/api/instances/${encodeURIComponent(id)}/site/customers/${encodeURIComponent(customerId)}`,
    { method: "DELETE" }
  );
}

/* ------------------- round 30 — module-workspace records ------------- */

/** The REAL (user-created) rows of one module workspace, newest first. */
export async function fetchModuleRecords(
  id: string,
  moduleId: string
): Promise<ModuleRecordDTO[]> {
  const data = await request<{ records: ModuleRecordDTO[] }>(
    `/api/instances/${encodeURIComponent(id)}/module-records?moduleId=${encodeURIComponent(moduleId)}`
  );
  return data.records;
}

/** Create one real row inside a module workspace. */
export async function createModuleRecord(
  id: string,
  payload: {
    moduleId: string;
    values: string[];
    statusKey: string;
    image?: string;
    /** ROUND 133 — POS customer linkage (drives the loyalty engine). */
    meta?: { customerPhone: string; customerName: string };
    /** ROUND 141 (㉕) — the structured payment ledger (≤4 entries over the
     *  7 canonical methods). */
    payments?: import("@/lib/payment-methods").PaymentEntry[];
    /** ROUND 141 (product extras) — the FULL ordered photo gallery (cover
     *  first), managed refs, ≤6; mirrors updateModuleRecord. */
    gallery?: string[];
    /** ROUND 141 (product extras) — the variant rows ([] clears). */
    variants?: { id?: string; name: string; price?: number; stock?: number; sku?: string }[];
  }
): Promise<ModuleRecordDTO> {
  return post<ModuleRecordDTO>(
    `/api/instances/${encodeURIComponent(id)}/module-records`,
    payload
  );
}

/** Edit one real row (values, statusKey, the product photo and/or the
 *  merchandising flags — featured / sale price in minor units, null clears). */
export async function updateModuleRecord(
  id: string,
  recordId: string,
  payload: {
    values?: string[];
    statusKey?: string;
    image?: string;
    /** ROUND 141 (㉕) — the structured payment ledger (undefined = keep;
     *  [] clears). */
    payments?: import("@/lib/payment-methods").PaymentEntry[];
    featured?: boolean;
    salePrice?: number | null;
    /** ROUND 53 — sale end window (ISO 8601; null = open-ended). */
    saleEndsAt?: string | null;
    /** ROUND 140 — the FULL ordered photo gallery (cover first), managed
     *  refs, ≤6; [] clears. Mutually exclusive with `image`. */
    gallery?: string[];
    /** ROUND 140 — up to 2 managed /api/videos refs; [] clears. */
    videos?: string[];
    /** ROUND 140 — the storefront visibility checkmark (FALSE hides the
     *  product + its media from the public store). */
    storeVisible?: boolean;
  }
): Promise<ModuleRecordDTO> {
  return patch<ModuleRecordDTO>(
    `/api/instances/${encodeURIComponent(id)}/module-records/${encodeURIComponent(recordId)}`,
    payload
  );
}

/* ---------------- ROUND 140 — product media uploads ---------------- */

/** Upload ONE product gallery photo (canvas-compressed or raw ≤8 MB JPEG/
 *  PNG/WEBP data-URL) — the server re-encodes to clean WebP and returns the
 *  managed /api/images ref to commit via updateModuleRecord({ gallery }). */
export async function uploadStoreImage(
  id: string,
  dataUrl: string
): Promise<{ url: string; kind: "image" }> {
  return post<{ url: string; kind: "image" }>(
    `/api/instances/${encodeURIComponent(id)}/store/media`,
    { image: dataUrl }
  );
}

/** Upload ONE product video clip (raw bytes ≤10 MB; MP4/WebM/MOV verified
 *  by magic bytes server-side) — returns the managed /api/videos ref. */
export async function uploadStoreVideo(
  id: string,
  file: File
): Promise<{ url: string; kind: "video" }> {
  const form = new FormData();
  form.append("video", file);
  const res = await fetch(
    `/api/instances/${encodeURIComponent(id)}/store/media`,
    {
      method: "POST",
      credentials: "same-origin",
      body: form,
    }
  );
  if (!res.ok) {
    let message = `Upload failed (${res.status})`;
    try {
      const data = (await res.json()) as { error?: string };
      if (data?.error) message = data.error;
    } catch {
      /* non-JSON error body — keep the generic message */
    }
    throw new ApiError(message, res.status);
  }
  return (await res.json()) as { url: string; kind: "video" };
}

/** Remove one real row. */
export async function deleteModuleRecord(
  id: string,
  recordId: string
): Promise<void> {
  await request<{ ok: boolean }>(
    `/api/instances/${encodeURIComponent(id)}/module-records/${encodeURIComponent(recordId)}`,
    { method: "DELETE" }
  );
}

/* ----------------- ROUND 133 — نظام الورديات (shift system) ------------- */

/** The workspace's shift state: the open shift (live aggregates), the last
 *  20 closed shifts, and whether the secret shift code is defined. */
export async function fetchShifts(id: string): Promise<ShiftsResponseDTO> {
  return request<ShiftsResponseDTO>(
    `/api/instances/${encodeURIComponent(id)}/shifts`
  );
}

/** OPEN a shift — requires the owner's secret shift code (Argon2id-verified
 *  server-side) and the declared opening float. */
export async function openShift(
  id: string,
  payload: { code: string; openingCash: number }
): Promise<{ shift: ShiftDTO }> {
  return post<{ shift: ShiftDTO }>(
    `/api/instances/${encodeURIComponent(id)}/shifts`,
    payload
  );
}

/** CLOSE the open shift with the counted drawer — the server computes the
 *  expected drawer, the variance, and freezes the aggregates. */
export async function closeShift(
  id: string,
  payload: { countedCash: number; note?: string }
): Promise<{ shift: ShiftDTO }> {
  return post<{ shift: ShiftDTO }>(
    `/api/instances/${encodeURIComponent(id)}/shifts/close`,
    payload
  );
}

/** Define or change the owner's secret shift code (requires the workspace
 *  password as identity proof; the code is 4-8 digits). ROUND 144 — the
 *  CHOSEN length rides along so the server persists it (codeLen). */
export async function setShiftCode(
  id: string,
  payload: { currentPassword: string; newCode: string; length?: number }
): Promise<{ ok: boolean; codeSet: boolean }> {
  return put<{ ok: boolean; codeSet: boolean }>(
    `/api/instances/${encodeURIComponent(id)}/shifts/code`,
    payload
  );
}

/** The loyalty page's sync action — recompute customers from the REAL sales
 *  and rebuild the loyalty rows. */
export async function resyncLoyalty(
  id: string
): Promise<{
  ok: boolean;
  result: { customersSynced: number; loyaltyRows: number; loyaltyCreated: number; totalPoints: number };
}> {
  return post<{
    ok: boolean;
    result: { customersSynced: number; loyaltyRows: number; loyaltyCreated: number; totalPoints: number };
  }>(`/api/instances/${encodeURIComponent(id)}/loyalty/resync`, {});
}

/* --------------------- site customers (round 25 → round 44) --------------------- */

/* ROUND 44 — the member-login process was removed from the public websites:
 * login / register / logout / session / my-orders client functions and their
 * API routes are GONE. Storefront checkout is GUEST checkout — the order
 * carries the visitor's contact details (see placeSiteOrder below). The
 * SiteCustomerDTO type remains the shape the workspace owner's Customers
 * views consume (a different, owner-facing endpoint). */
export interface SiteCustomerDTO {
  name: string;
  email: string;
  phone: string | null;
  memberSince: string;
  lastLoginAt?: string | null;
  inquiries?: number;
}

/* ------------------------------ admins ------------------------------ */

export async function fetchAdminUsers(): Promise<AdminUserDTO[]> {
  return request<AdminUserDTO[]>("/api/admin/admins");
}

export async function createAdminUser(payload: AdminUserPayload): Promise<AdminUserDTO> {
  return post<AdminUserDTO>("/api/admin/admins", payload);
}

export async function updateAdminUser(id: string, payload: Partial<AdminUserPayload>): Promise<AdminUserDTO> {
  return patch<AdminUserDTO>(`/api/admin/admins/${encodeURIComponent(id)}`, payload);
}

export async function deleteAdminUser(id: string): Promise<void> {
  await request<{ ok: boolean }>(`/api/admin/admins/${encodeURIComponent(id)}`, { method: "DELETE" });
}

/* ------------------------------ admin sites (round 27) ------------------------------ */

export async function fetchAdminSites(): Promise<AdminSiteDTO[]> {
  return request<AdminSiteDTO[]>("/api/admin/sites");
}

/** ROUND 46 — admin Stores view: every tenant storefront + platform totals. */
export async function fetchAdminStores(): Promise<AdminStoresDTO> {
  return request<AdminStoresDTO>("/api/admin/stores");
}

/** ROUND 46 (F-4) — self-service password rotation for the signed-in admin. */
export async function changeAdminPassword(
  currentPassword: string,
  newPassword: string
): Promise<{ ok: boolean }> {
  return post<{ ok: boolean }>("/api/admin/me/password", {
    currentPassword,
    newPassword,
  });
}

export async function setAdminSitePublished(id: string, published: boolean): Promise<{ ok: boolean }> {
  return patch<{ ok: boolean }>(`/api/admin/sites/${encodeURIComponent(id)}`, { published });
}

/* -------------------- admin plan orders (ROUND 47) -------------------- */

/** ROUND 47 — the console's activation-requests queue (Payments view). */
export async function fetchAdminPlanOrders(status?: "pending" | "paid" | "cancelled"): Promise<AdminPlanOrderDTO[]> {
  const suffix = status ? `?status=${status}` : "";
  return request<AdminPlanOrderDTO[]>(`/api/admin/plan-orders${suffix}`);
}

/**
 * ROUND 47 — confirm a payment receipt (activates the plan + restores a
 * trial-locked workspace) or cancel a request. super/admin only.
 */
export async function adminPlanOrderAction(
  orderId: string,
  action: "paid" | "cancelled"
): Promise<{ order: AdminPlanOrderDTO; instance: InstanceDTO }> {
  return patch<{ order: AdminPlanOrderDTO; instance: InstanceDTO }>(
    `/api/admin/plan-orders/${encodeURIComponent(orderId)}`,
    { action }
  );
}

/* -------------------- admin add-on orders (ROUND 141) -------------------- */

/** ROUND 141 — the console's add-on purchase queue (Payments view). */
export async function fetchAdminAddonOrders(status?: "pending" | "paid" | "cancelled"): Promise<AdminAddonOrderDTO[]> {
  const suffix = status ? `?status=${status}` : "";
  return request<AdminAddonOrderDTO[]>(`/api/admin/addon-orders${suffix}`);
}

/**
 * ROUND 141 — confirm an add-on payment (force-ONs the ordered features on
 * the workspace instantly) or cancel the request. super/admin only.
 */
export async function adminAddonOrderAction(
  orderId: string,
  action: "paid" | "cancelled"
): Promise<{ order: AdminAddonOrderDTO; activatedFeatures: string[] }> {
  return patch<{ order: AdminAddonOrderDTO; activatedFeatures: string[] }>(
    `/api/admin/addon-orders/${encodeURIComponent(orderId)}`,
    { action }
  );
}

/* --------------- ROUND 81 — subscriber governance (Super Admin) --------------- */

/** Console-side edit of a subscriber's identity fields (institution name,
 *  admin email/name, phone). Email changes re-seal + re-index server-side. */
export async function adminUpdateSubscriberProfile(
  instanceId: string,
  payload: { orgName?: string; adminName?: string; adminEmail?: string; phone?: string }
): Promise<AdminSubscriberGovernanceResult> {
  return patch<AdminSubscriberGovernanceResult>(
    `/api/admin/subscribers/${encodeURIComponent(instanceId)}`,
    { action: "profile", ...payload }
  );
}

/** Console-side workspace password rotation (revokes every live session). */
export async function adminResetSubscriberPassword(
  instanceId: string,
  password: string
): Promise<AdminSubscriberGovernanceResult> {
  return patch<AdminSubscriberGovernanceResult>(
    `/api/admin/subscribers/${encodeURIComponent(instanceId)}`,
    { action: "password", password }
  );
}

/** Suspend a workspace — temporary (self-lifting at `until`) or permanent. */
export async function adminBanSubscriber(
  instanceId: string,
  kind: "temporary" | "permanent",
  options?: { until?: string; reason?: string | null }
): Promise<AdminSubscriberGovernanceResult> {
  return patch<AdminSubscriberGovernanceResult>(
    `/api/admin/subscribers/${encodeURIComponent(instanceId)}`,
    kind === "temporary"
      ? { action: "ban", kind, until: options?.until, reason: options?.reason ?? null }
      : { action: "ban", kind, reason: options?.reason ?? null }
  );
}

/** Lift an active ban — everything resumes on the next request. */
export async function adminUnbanSubscriber(
  instanceId: string
): Promise<AdminSubscriberGovernanceResult> {
  return patch<AdminSubscriberGovernanceResult>(
    `/api/admin/subscribers/${encodeURIComponent(instanceId)}`,
    { action: "unban" }
  );
}

/* --------------------- site customer trends (round 31) --------------------- */

/** Customer analytics over time — weekly signup/inquiry buckets + totals. */
export async function fetchAdminSiteTrends(): Promise<AdminSiteTrendsDTO> {
  return request<AdminSiteTrendsDTO>("/api/admin/sites/trends");
}

/* --------------------- newsletter campaigns (round 33) --------------------- */

/** Campaign archive (latest first) + the live audience estimate for drafts. */
export async function fetchAdminCampaigns(): Promise<{
  campaigns: CampaignDTO[];
  audience: number;
}> {
  return request<{ campaigns: CampaignDTO[]; audience: number }>("/api/admin/campaigns");
}

/** Create a campaign DRAFT (subject + body). */
export async function createAdminCampaign(payload: {
  subject: string;
  body: string;
}): Promise<CampaignDTO> {
  return post<CampaignDTO>("/api/admin/campaigns", payload);
}

/** Edit a DRAFT campaign in place. */
export async function updateAdminCampaign(
  id: string,
  payload: { subject: string; body: string }
): Promise<CampaignDTO> {
  return patch<CampaignDTO>(`/api/admin/campaigns/${encodeURIComponent(id)}`, payload);
}

/** Stamp a DRAFT as sent (recipients + sentFrom snapshot server-side). */
export async function sendAdminCampaign(id: string): Promise<CampaignDTO> {
  return patch<CampaignDTO>(`/api/admin/campaigns/${encodeURIComponent(id)}`, { action: "send" });
}

/** Delete a campaign (draft or sent archive record). */
export async function deleteAdminCampaign(id: string): Promise<void> {
  await request<void>(`/api/admin/campaigns/${encodeURIComponent(id)}`, { method: "DELETE" });
}

/* --------------------- per-site customers (round 28) --------------------- */

/** List the registered customer accounts of one public website + counts. */
export async function fetchSiteCustomers(
  instanceId: string
): Promise<{ customers: SiteCustomerAdminDTO[]; counts: SiteCustomerCountsDTO }> {
  return request<{ customers: SiteCustomerAdminDTO[]; counts: SiteCustomerCountsDTO }>(
    `/api/admin/sites/${encodeURIComponent(instanceId)}/customers`
  );
}

/** Ban or reactivate one customer account (cuts off live sessions when banned). */
export async function setSiteCustomerStatus(
  instanceId: string,
  customerId: string,
  status: SiteCustomerStatus
): Promise<{ ok: boolean }> {
  return patch<{ ok: boolean }>(
    `/api/admin/sites/${encodeURIComponent(instanceId)}/customers/${encodeURIComponent(customerId)}`,
    { status }
  );
}

/** ROUND 75 — Super Admin verification actions on a site customer
 *  (staff-assisted confirm or verification-email re-dispatch). */
export async function verifySiteCustomerAdmin(
  instanceId: string,
  customerId: string,
  action: "verify" | "resendVerify"
): Promise<{ ok: boolean; customer?: SiteCustomerAdminDTO }> {
  return patch<{ ok: boolean; customer?: SiteCustomerAdminDTO }>(
    `/api/admin/sites/${encodeURIComponent(instanceId)}/customers/${encodeURIComponent(customerId)}`,
    action === "verify" ? { verify: true } : { resendVerify: true }
  );
}

/** Permanently remove a customer account from a site. */
export async function deleteSiteCustomer(instanceId: string, customerId: string): Promise<void> {
  await request<{ ok: boolean }>(
    `/api/admin/sites/${encodeURIComponent(instanceId)}/customers/${encodeURIComponent(customerId)}`,
    { method: "DELETE" }
  );
}

/* ------------- ROUND 77 — Super Admin site-inquiry triage ------------- */

/** The public inquiries of ONE website (Super Admin triage inbox), optionally
 *  scoped to a single customer (resolved server-side via the blind index). */
export async function fetchAdminSiteInquiries(
  instanceId: string,
  customerId?: string
): Promise<SiteInquiryTriageDTO[]> {
  const qs = customerId ? `?customer=${encodeURIComponent(customerId)}` : "";
  return request<SiteInquiryTriageDTO[]>(
    `/api/admin/sites/${encodeURIComponent(instanceId)}/inquiries${qs}`
  );
}

/** Super Admin triage write on one public inquiry ({ reply?, status?, priority? }). */
export async function triageAdminSiteInquiry(
  instanceId: string,
  ticketId: string,
  payload: { reply?: string; status?: string; priority?: string }
): Promise<SiteInquiryTriageDTO> {
  return patch<SiteInquiryTriageDTO>(
    `/api/admin/sites/${encodeURIComponent(instanceId)}/inquiries/${encodeURIComponent(ticketId)}`,
    payload
  );
}

/* --------------------- storefront customer accounts (round 65) -------------------- */

/** Sign-up state probe: the storefront boots guest-first; this returns the
 *  signed-in account when a live session cookie exists (200, never 401). */
export async function fetchStoreAccount(
  instanceId: string
): Promise<{ signedIn: boolean; account?: StoreAccountDTO; unreadReplies?: number }> {
  return request<{ signedIn: boolean; account?: StoreAccountDTO; unreadReplies?: number }>(
    `/api/sites/${encodeURIComponent(instanceId)}/account`
  );
}

/** Sign UP — creates the account (or upgrades a matching guest row) and
 *  signs the shopper in (the cookie is HttpOnly server-side). ROUND 75 —
 *  new signups start UNVERIFIED; the response hint carries the dispatch
 *  state (sent / expiresAt, plus devLink on dev-demo deployments). */
export async function registerStoreAccount(
  instanceId: string,
  payload: { name: string; email: string; password: string; phone?: string; username?: string }
): Promise<{ account: StoreAccountDTO; verify?: StoreVerifyHintDTO }> {
  const data = await post<{ account: StoreAccountDTO; verify?: StoreVerifyHintDTO }>(
    `/api/sites/${encodeURIComponent(instanceId)}/account/register`,
    payload
  );
  return { account: data.account, verify: data.verify };
}

/** ROUND 75 — dispatch hint riding the register response. */
export interface StoreVerifyHintDTO {
  sent: boolean;
  expiresAt: string;
  /** dev/demo deployments only — the verification link itself (never
   *  returned in production, where it only travels by email). */
  devLink?: string;
}

/** ROUND 75 — the signed-in customer asks for a fresh verification email
 *  (rotates the single-use token; one request / minute server-side). */
export async function resendStoreVerification(
  instanceId: string
): Promise<StoreVerifyHintDTO> {
  return post<StoreVerifyHintDTO>(
    `/api/sites/${encodeURIComponent(instanceId)}/account/verify/resend`,
    {}
  );
}

/** Sign IN — exchanges credentials for the session cookie. */
export async function loginStoreAccount(
  instanceId: string,
  payload: { email: string; password: string }
): Promise<StoreAccountDTO> {
  const data = await post<{ account: StoreAccountDTO }>(
    `/api/sites/${encodeURIComponent(instanceId)}/account/login`,
    payload
  );
  return data.account;
}

/* ------------------------------------------------------------------ */
/* ROUND 85 — the dedicated account page's forgot-password flow        */
/* ------------------------------------------------------------------ */

/** ROUND 85 — forgot-password dispatch hint (neutral shape — the server
 *  never reveals whether the address owns an account). */
export interface StoreForgotHintDTO {
  ok: boolean;
  sent: boolean;
  expiresAt: string;
  /** dev/demo deployments only — the reset link itself (production hands
   *  it solely to the mailer). */
  devLink?: string;
}

/** ROUND 85 — «نسيت كلمة المرور»: request a single-use reset token for
 *  the account page's forgot mode (always resolves, never an oracle). */
export async function forgotStorePassword(
  instanceId: string,
  payload: { email: string }
): Promise<StoreForgotHintDTO> {
  return post<StoreForgotHintDTO>(
    `/api/sites/${encodeURIComponent(instanceId)}/account/forgot`,
    payload
  );
}

/** ROUND 85 — consume the emailed token on the account page's reset mode:
 *  replaces the password, kills every outstanding session and signs the
 *  customer in on this device right away. */
export async function resetStorePassword(
  instanceId: string,
  payload: { token: string; password: string }
): Promise<StoreAccountDTO> {
  const data = await post<{ ok: boolean; account: StoreAccountDTO }>(
    `/api/sites/${encodeURIComponent(instanceId)}/account/reset`,
    payload
  );
  return data.account;
}

/** Sign OUT (this device). Idempotent. */
export async function logoutStoreAccount(instanceId: string): Promise<void> {
  await post(`/api/sites/${encodeURIComponent(instanceId)}/account/logout`, {});
}

/** Profile self-service (name / phone / username). The username is subject
 *  to the same server-side uniqueness check the register route runs. */
export async function updateStoreProfile(
  instanceId: string,
  payload: { name?: string; phone?: string | null; username?: string }
): Promise<StoreAccountDTO> {
  const data = await patch<{ account: StoreAccountDTO }>(
    `/api/sites/${encodeURIComponent(instanceId)}/account`,
    payload
  );
  return data.account;
}

/* ROUND L (TASK STORE-PROFILE) — debounce-probe the customer-level
 *  username uniqueness (the signup form + the profile's Edit Username card
 *  both call this on every keystroke, debounced 350ms). The server is the
 *  source of truth — the chip is UX only; the register / PATCH routes
 *  re-validate before persisting. */
export interface StoreUsernameCheckDTO {
  /** the typed handle is free inside this site (no live row owns it). */
  available: boolean;
  /** the typed handle passed the shape regex (3-30 chars, allowed chars).
   *  false = invalid shape — the chip stays red without leaking why. */
  valid: boolean;
}

export async function checkStoreUsername(
  instanceId: string,
  username: string
): Promise<StoreUsernameCheckDTO> {
  return post<StoreUsernameCheckDTO>(
    `/api/sites/${encodeURIComponent(instanceId)}/account/check-username`,
    { username }
  );
}

/** Add a shipping address (address-book pattern, capped server-side). */
export async function addStoreAddress(
  instanceId: string,
  address: Omit<StoreAddressDTO, "id">
): Promise<StoreAccountDTO> {
  const data = await post<{ account: StoreAccountDTO }>(
    `/api/sites/${encodeURIComponent(instanceId)}/account/addresses`,
    address
  );
  return data.account;
}

/** Merge-edit one saved address (any subset of fields). */
export async function updateStoreAddress(
  instanceId: string,
  addressId: string,
  patchBody: Partial<Omit<StoreAddressDTO, "id">>
): Promise<StoreAccountDTO> {
  const data = await patch<{ account: StoreAccountDTO }>(
    `/api/sites/${encodeURIComponent(instanceId)}/account/addresses/${encodeURIComponent(addressId)}`,
    patchBody
  );
  return data.account;
}

/** Remove one saved address. */
export async function deleteStoreAddress(
  instanceId: string,
  addressId: string
): Promise<StoreAccountDTO> {
  const data = await request<{ account: StoreAccountDTO }>(
    `/api/sites/${encodeURIComponent(instanceId)}/account/addresses/${encodeURIComponent(addressId)}`,
    { method: "DELETE" }
  );
  return data.account;
}

/** Save a card — the server LUKHN-checks, brand-detects and persists ONLY
 *  {brand, last4, expiry, holder}; the number never round-trips back. */
export async function addStorePaymentMethod(
  instanceId: string,
  card: {
    number: string;
    holder: string;
    expMonth: number;
    expYear: number;
    isDefault?: boolean;
  }
): Promise<StoreAccountDTO> {
  const data = await post<{ account: StoreAccountDTO }>(
    `/api/sites/${encodeURIComponent(instanceId)}/account/payment-methods`,
    card
  );
  return data.account;
}

/** Remove a saved card. */
export async function deleteStorePaymentMethod(
  instanceId: string,
  methodId: string
): Promise<StoreAccountDTO> {
  const data = await request<{ account: StoreAccountDTO }>(
    `/api/sites/${encodeURIComponent(instanceId)}/account/payment-methods/${encodeURIComponent(methodId)}`,
    { method: "DELETE" }
  );
  return data.account;
}

/** The signed-in shopper's order history (newest first). */
export async function fetchStoreAccountOrders(
  instanceId: string
): Promise<SiteOrderDTO[]> {
  const data = await request<{ orders: SiteOrderDTO[] }>(
    `/api/sites/${encodeURIComponent(instanceId)}/account/orders`
  );
  return data.orders;
}

/** ROUND 73 — the signed-in customer's own support-inquiry history
 *  (newest activity first — the account sheet's "استفساراتي" tab). */
export async function fetchStoreAccountInquiries(
  instanceId: string
): Promise<{ inquiries: SiteInquiryDTO[]; unreadCount: number }> {
  const data = await request<{ inquiries: SiteInquiryDTO[]; unreadCount: number }>(
    `/api/sites/${encodeURIComponent(instanceId)}/account/inquiries`
  );
  return { inquiries: data.inquiries, unreadCount: data.unreadCount ?? 0 };
}

/** ROUND 74 — owner triage: the public website inquiries of THIS workspace
 * (optionally drilled into one customer via their site account id). */
export async function fetchInstanceSiteInquiries(
  instanceId: string,
  customerId?: string
): Promise<SiteInquiryTriageDTO[]> {
  const qs = customerId ? `?customer=${encodeURIComponent(customerId)}` : "";
  return request<SiteInquiryTriageDTO[]>(
    `/api/instances/${encodeURIComponent(instanceId)}/site/inquiries${qs}`
  );
}

/** ROUND 74 — owner triage write: reply / status / priority on ONE public
 * inquiry (any combination; at least one field). */
export async function triageInstanceSiteInquiry(
  instanceId: string,
  ticketId: string,
  payload: { reply?: string; status?: string; priority?: string }
): Promise<SiteInquiryTriageDTO> {
  return request<SiteInquiryTriageDTO>(
    `/api/instances/${encodeURIComponent(instanceId)}/site/inquiries/${encodeURIComponent(ticketId)}`,
    { method: "PATCH", body: JSON.stringify(payload) }
  );
}

/* --------------------- storefront (round 36) --------------------- */

/** Public storefront catalog for a published site (products + categories). */
export async function fetchSiteStore(
  instanceId: string,
  opts?: { q?: string; category?: string }
): Promise<{
  available: boolean;
  moduleId: string | null;
  currency: string;
  products: SiteProductDTO[];
  categories: string[];
  /** ROUND 51 — per-category counts over the UNFILTERED catalog (chip badges). */
  categoryCounts: Record<string, number>;
}> {
  const params = new URLSearchParams();
  if (opts?.q) params.set("q", opts.q);
  if (opts?.category) params.set("category", opts.category);
  const qs = params.toString();
  return request<{
    available: boolean;
    moduleId: string | null;
    currency: string;
    products: SiteProductDTO[];
    categories: string[];
    categoryCounts: Record<string, number>;
  }>(`/api/sites/${encodeURIComponent(instanceId)}/store${qs ? `?${qs}` : ""}`);
}

/**
 * Place a storefront order — GUEST checkout (round 44): no session, the
 * visitor supplies contact details with the order; prices are still resolved
 * server-side only. ROUND 50: an optional couponCode is re-validated and
 * re-priced server-side at placement.
 */
export async function placeSiteOrder(
  instanceId: string,
  payload: {
    items: { recordId: string; qty: number }[];
    note?: string;
    customer: { name: string; phone?: string; email?: string };
    couponCode?: string;
  }
): Promise<SiteOrderDTO> {
  return post<SiteOrderDTO>(`/api/sites/${encodeURIComponent(instanceId)}/orders`, payload);
}

/** ROUND 50 — validate a coupon against the current cart (public checkout).
 *  The previewed discount is advisory; placement always re-derives it. */
export async function validateSiteCoupon(
  instanceId: string,
  payload: { code: string; subtotal: number }
): Promise<CouponPreviewDTO> {
  return post<CouponPreviewDTO>(
    `/api/sites/${encodeURIComponent(instanceId)}/store/coupon`,
    payload
  );
}

/** ROUND 50 — track a guest order by code + phone (public, no account). */
export async function trackSiteOrder(
  instanceId: string,
  payload: { code: string; phone: string }
): Promise<SiteOrderTrackedDTO> {
  return post<SiteOrderTrackedDTO>(
    `/api/sites/${encodeURIComponent(instanceId)}/orders/track`,
    payload
  );
}

/** ROUND 57 — the workspace owner's storefront order queue (keyset-
 *  paginated). `status` filters the page; `counts` are always instance-
 *  wide. Pass the returned `nextCursor` back verbatim for the next page. */
export async function fetchInstanceOrders(
  instanceId: string,
  opts: { status?: string; limit?: number; cursor?: string | null } = {}
): Promise<OrderPageDTO> {
  const qs = new URLSearchParams();
  if (opts.status) qs.set("status", opts.status);
  if (opts.limit !== undefined) qs.set("limit", String(opts.limit));
  if (opts.cursor) qs.set("cursor", opts.cursor);
  const suffix = qs.size > 0 ? `?${qs.toString()}` : "";
  return request<OrderPageDTO>(
    `/api/instances/${encodeURIComponent(instanceId)}/orders${suffix}`
  );
}

/* ------------------------- owner storefront status (round 44) ------------------------- */

/** Owner-scoped E-Store status (availability, product count, categories) —
 *  answers for DRAFT sites too, unlike the public store route.
 *  ROUND 51 — now carries the full owner catalog (unfiltered by sellability)
 *  so the products console can manage photos per row. */
export interface InstanceStoreStatusDTO {
  available: boolean;
  moduleId: string | null;
  currency: string;
  published: boolean;
  categories: string[];
  productCount: number;
  products: SiteProductDTO[];
}

export async function fetchInstanceStoreStatus(
  instanceId: string
): Promise<InstanceStoreStatusDTO> {
  return request<InstanceStoreStatusDTO>(
    `/api/instances/${encodeURIComponent(instanceId)}/store`
  );
}

/** Advance an order's lifecycle (owner action, audited). */
export async function updateInstanceOrder(
  instanceId: string,
  orderId: string,
  payload: { status: SiteOrderStatus; statusNote?: string; notify?: boolean }
): Promise<{
  id: string;
  status: SiteOrderStatus;
  statusNote: string | null;
  /** ROUND 56 — true when a customer email notice was dispatched */
  notified: boolean;
  statusHistory: OrderStatusEvent[];
  updatedAt: string;
}> {
  return patch<{
    id: string;
    status: SiteOrderStatus;
    statusNote: string | null;
    notified: boolean;
    statusHistory: OrderStatusEvent[];
    updatedAt: string;
  }>(`/api/instances/${encodeURIComponent(instanceId)}/orders/${encodeURIComponent(orderId)}`, payload);
}

/* ------------------ owner coupons (ROUND 50 — promotions) ------------------ */

/** The owner's coupon list (dashboard E-Store view). */
export async function fetchInstanceCoupons(
  instanceId: string
): Promise<{ coupons: StoreCouponDTO[] }> {
  return request<{ coupons: StoreCouponDTO[] }>(
    `/api/instances/${encodeURIComponent(instanceId)}/store/coupons`
  );
}

export interface CouponCreatePayload {
  code: string;
  kind: "percent" | "fixed";
  /** percent: 1–99 · fixed: minor units */
  value: number;
  minSubtotal?: number | null;
  maxUses?: number | null;
  startsAt?: string | null;
  expiresAt?: string | null;
  active?: boolean;
}

export async function createInstanceCoupon(
  instanceId: string,
  payload: CouponCreatePayload
): Promise<StoreCouponDTO> {
  return post<StoreCouponDTO>(
    `/api/instances/${encodeURIComponent(instanceId)}/store/coupons`,
    payload
  );
}

export async function updateInstanceCoupon(
  instanceId: string,
  couponId: string,
  payload: Partial<Omit<CouponCreatePayload, "code">>
): Promise<StoreCouponDTO> {
  return patch<StoreCouponDTO>(
    `/api/instances/${encodeURIComponent(instanceId)}/store/coupons/${encodeURIComponent(couponId)}`,
    payload
  );
}

export async function deleteInstanceCoupon(
  instanceId: string,
  couponId: string
): Promise<void> {
  await request<{ ok: boolean }>(
    `/api/instances/${encodeURIComponent(instanceId)}/store/coupons/${encodeURIComponent(couponId)}`,
    { method: "DELETE" }
  );
}

/* ----------------- ROUND 114 — order-event webhooks (owner) ----------------- */

/** List DTO — the signing secret is NEVER included (the server redacts it
 *  to a 4-char hint after creation; only the create/rotate responses ever
 *  carry the full secret). */
export interface WebhookEndpointDTO {
  id: string;
  url: string;
  events: string[];
  active: boolean;
  description: string | null;
  secretHint: string;
  createdAt: string;
  updatedAt: string;
  deleted: boolean;
  /** per-endpoint delivery stats (joined server-side) */
  deliveries?: number;
  lastDeliveryAt?: string | null;
}

export interface WebhookCreatePayload {
  url: string;
  events: string[];
  description?: string;
}

export interface WebhookUpdatePayload {
  url?: string;
  events?: string[];
  description?: string | null;
  active?: boolean;
  /** rotates the signing secret — the response carries the new secret ONCE */
  rotate?: boolean;
}

export async function fetchInstanceWebhooks(
  instanceId: string
): Promise<WebhookEndpointDTO[]> {
  return request<WebhookEndpointDTO[]>(
    `/api/instances/${encodeURIComponent(instanceId)}/webhooks`
  );
}

export async function createInstanceWebhook(
  instanceId: string,
  payload: WebhookCreatePayload
): Promise<WebhookEndpointDTO & { secret: string }> {
  return post<WebhookEndpointDTO & { secret: string }>(
    `/api/instances/${encodeURIComponent(instanceId)}/webhooks`,
    payload
  );
}

export async function updateInstanceWebhook(
  instanceId: string,
  webhookId: string,
  payload: WebhookUpdatePayload
): Promise<WebhookEndpointDTO & { secret?: string }> {
  return patch<WebhookEndpointDTO & { secret?: string }>(
    `/api/instances/${encodeURIComponent(instanceId)}/webhooks/${encodeURIComponent(webhookId)}`,
    payload
  );
}

export async function deleteInstanceWebhook(
  instanceId: string,
  webhookId: string
): Promise<void> {
  await request<{ ok: boolean }>(
    `/api/instances/${encodeURIComponent(instanceId)}/webhooks/${encodeURIComponent(webhookId)}`,
    { method: "DELETE" }
  );
}

/* ROUND 115 — one endpoint's delivery history (keyset-paginated). */

export interface WebhookDeliveryDTO {
  id: string;
  event: string;
  status: string;
  attempts: number;
  responseStatus: number | null;
  /** sanitized transport error CLASS ("timeout" | "network" | "dns" | …) */
  error: string | null;
  createdAt: string;
  deliveredAt: string | null;
  exhaustedAt: string | null;
  /** present while a failed delivery waits for its backoff retry */
  nextAttemptAt: string | null;
  /** canonical JSON body as dispatched (the signature covers EXACTLY this) */
  payload: string;
  /** ROUND 116 — the original delivery id on manually redelivered rows */
  redeliveredFrom: string | null;
}

export interface WebhookDeliveryPageDTO {
  deliveries: WebhookDeliveryDTO[];
  /** null exactly when the history is exhausted */
  nextCursor: string | null;
  /** ROUND 118 — the endpoint's LIVE BACKLOG: deliveries still to be
   *  delivered (pending + failed rows inside their retry backoff) — the
   *  queue depth behind the history dialog's footer. */
  liveBacklog: number;
}

export async function fetchWebhookDeliveries(
  instanceId: string,
  webhookId: string,
  opts: { limit?: number; cursor?: string | null } = {}
): Promise<WebhookDeliveryPageDTO> {
  const qs = new URLSearchParams();
  if (opts.limit !== undefined) qs.set("limit", String(opts.limit));
  if (opts.cursor) qs.set("cursor", opts.cursor);
  const suffix = qs.size > 0 ? `?${qs.toString()}` : "";
  return request<WebhookDeliveryPageDTO>(
    `/api/instances/${encodeURIComponent(instanceId)}/webhooks/${encodeURIComponent(webhookId)}/deliveries${suffix}`
  );
}

/* ROUND 116 — manual redelivery of one failed/exhausted delivery: the
 * response is the freshly enqueued PENDING row (payload copied verbatim,
 * signed at dispatch with the endpoint's CURRENT secret). */
export async function redeliverWebhookDelivery(
  instanceId: string,
  webhookId: string,
  deliveryId: string
): Promise<WebhookDeliveryDTO> {
  return post<WebhookDeliveryDTO>(
    `/api/instances/${encodeURIComponent(instanceId)}/webhooks/${encodeURIComponent(webhookId)}/deliveries/${encodeURIComponent(deliveryId)}/redeliver`,
    {}
  );
}

/* ----------------- ROUND 114 — admin ops telemetry snapshot ----------------- */

/** GET /api/admin/ops — the hardened subsystems' live state (super-admin
 *  only; identifiers/counts/ages only, never secrets). */
export interface AdminOpsSnapshotDTO {
  provider: "sqlite" | "postgresql";
  audit: {
    totalRows: number;
    chainedRows: number;
    anchored: boolean;
    anchorUpdatedAt: string | null;
    /** ROUND 121 — chain health: rows written after the anchor row (the
     *  unanchored tail — null while no anchor exists). */
    rowsSinceAnchor: number | null;
    /** ROUND 121 — hours since the anchor was last written (null while no
     *  anchor exists). */
    anchorAgeHours: number | null;
    /** ROUND 122 — the off-host anchor journal's freshness (exists, hours
     *  since its last write, byte size — the export/safety-net cadence). */
    anchorJournal: {
      exists: boolean;
      lastWriteAgeHours: number | null;
      bytes: number;
    };
  };
  idempotency: {
    completedGuards: number;
    inFlightGuards: number;
    oldestCompletedAgeHours: number | null;
  };
  schedulerLeases: Array<{
    job: string;
    holderPid: string;
    ageMs: number;
    expiresInMillis: number;
  }>;
  backupCache: {
    entries: number;
    bytes: number;
    builds: number;
    hits: number;
    misses: number;
    joins: number;
    evictions: number;
  };
  rateLimit: { windowRows: number };
  authWork: { windowDepth: number };
  emailQueue: { pendingDeliveryConfirmations: number };
  webhooks: {
    endpoints: number;
    activeEndpoints: number;
    pendingDeliveries: number;
    failedDeliveries: number;
    exhaustedDeliveries: number;
    succeededDeliveries: number;
    /** ROUND 116 — rows enqueued by the manual redelivery action */
    manualRedeliveries: number;
  };
  generatedAt: string;
}

export async function fetchAdminOps(): Promise<AdminOpsSnapshotDTO> {
  return request<AdminOpsSnapshotDTO>("/api/admin/ops");
}

/* ----------------- ROUND 117 — platform legal documents ----------------- */

export interface LegalDocDTO {
  key: "privacy" | "terms";
  locale: "ar" | "en" | "hi";
  title: string;
  intro: string;
  sections: { heading: string; body: string }[];
  updatedAt: string | null;
  version: number;
  updatedById: string | null;
  customized: boolean;
}

/** The whole legal bundle (both keys × ar/en/hi). */
export async function fetchLegalDocs(): Promise<LegalDocDTO[]> {
  const data = await request<{ docs: LegalDocDTO[] }>("/api/admin/legal");
  return data.docs;
}

/** Publish one console draft (versioned + attributed + audited). */
export async function saveLegalDoc(
  draft: Omit<LegalDocDTO, "updatedAt" | "version" | "customized" | "updatedById">
): Promise<{ doc: LegalDocDTO; version: number }> {
  return request<{ doc: LegalDocDTO; version: number }>("/api/admin/legal", {
    method: "PUT",
    body: JSON.stringify(draft),
  });
}

/** Reset one key × locale to the code default. */
export async function resetLegalDoc(
  key: "privacy" | "terms",
  locale: "ar" | "en" | "hi"
): Promise<{ doc: LegalDocDTO }> {
  return request<{ doc: LegalDocDTO }>("/api/admin/legal", {
    method: "DELETE",
    body: JSON.stringify({ key, locale }),
  });
}

/* ----------------- ROUND 117 — cross-device login bridge ---------------- */

export interface CrossDeviceStartDTO {
  token: string;
  qrSvg: string;
  expiresAt: string;
}

/** Desktop step 1 — mint the bridge + the QR markup. */
export async function crossDeviceStart(scope: "admin" | "instance"): Promise<CrossDeviceStartDTO> {
  return request<CrossDeviceStartDTO>("/api/cross-device", {
    method: "POST",
    body: JSON.stringify({ scope }),
  });
}

/* ----------------- ROUND 117 — admin storage GC console ----------------- */

export interface StorageGcPlanDTO {
  graceHours: number;
  referenced: number;
  unreferencedCount: number;
  unreferencedFresh: number;
  rowsMissingFile: number;
  imagesBytes: number;
  reclaimableBytes: number;
  orphanPlan: {
    orphans: number;
    tempStale: number;
    foreign: number;
    reclaimableBytes: number;
  };
}

export interface StorageGcRunDTO {
  ran: boolean;
  leaseHeld: boolean;
  result: {
    deletedRows: number;
    deletedFiles: number;
    reclaimedBytes: number;
    vanished: number;
    orphan: { deletedOrphans: number; deletedTemp: number; reclaimedBytes: number; vanished: number };
  } | null;
  plan: StorageGcPlanDTO;
}

/** The dry-run storage plan (unreferenced assets + orphan files). */
export async function fetchStorageGcPlan(graceHours = 24): Promise<StorageGcPlanDTO> {
  const data = await request<{ plan: StorageGcPlanDTO }>(
    `/api/admin/storage/gc?grace=${encodeURIComponent(graceHours)}`
  );
  return data.plan;
}

/** Run the storage sweep now (lease-protected + audited server-side). */
export async function runStorageGc(graceHours = 24): Promise<StorageGcRunDTO> {
  return request<StorageGcRunDTO>("/api/admin/storage/gc", {
    method: "POST",
    body: JSON.stringify({ graceHours }),
  });
}

/* ---------------------------- admin auth ---------------------------- */

/** Server-side login — sets the HTTP-only session cookie on success. */
export async function adminLogin(
  payload: { username: string; password: string }
): Promise<AdminUserDTO | MfaChallengeDTO> {
  return post<AdminUserDTO>("/api/admin/login", payload);
}

/** Server-side logout — clears the HTTP-only session cookie. */
export async function adminLogout(): Promise<void> {
  await post<{ ok: boolean }>("/api/admin/logout", {});
}

/** Resolve the current session from the cookie (401 when anonymous). */
export async function fetchAdminMe(): Promise<AdminUserDTO> {
  return request<AdminUserDTO>("/api/admin/me");
}

/* -------------- ROUND 89 — platform notifications + gates -------------- */

/** Public platform-state probe: { maintenance, signupAllowed, siteNameAr/En }.
 *  Owners bypass maintenance server-side (they keep operating). */
export async function fetchMaintenanceState(): Promise<{
  maintenance: boolean;
  signupAllowed: boolean;
  siteNameAr: string;
  siteNameEn: string;
}> {
  return request<{ maintenance: boolean; signupAllowed: boolean; siteNameAr: string; siteNameEn: string }>(
    "/api/maintenance"
  );
}

/** The notifications-tab activity feed (last dispatches + transport mode). */
export async function fetchAdminNotifications(): Promise<{
  notifications: import("./types").NotificationLogDTO[];
  transport: "smtp" | "spool";
}> {
  return request<{ notifications: import("./types").NotificationLogDTO[]; transport: "smtp" | "spool" }>(
    "/api/admin/notifications"
  );
}

/** Fire a REAL test notice through the notifEmail pipeline. */
export async function sendTestNotification(): Promise<{
  sent: boolean;
  reason?: "setting-off";
  delivered?: boolean;
  transport?: "smtp" | "spool";
  recipient?: string;
}> {
  return post<{ sent: boolean; reason?: "setting-off"; delivered?: boolean; transport?: "smtp" | "spool"; recipient?: string }>(
    "/api/admin/notifications/test",
    {}
  );
}

/** Build + deliver THIS week's platform report right now. */
export async function sendWeeklyReportNow(): Promise<{
  outcome: "sent" | "skipped-off" | "skipped-already" | "error";
  weekKey: string;
  delivered?: boolean;
  transport?: "smtp" | "spool";
  error?: string;
}> {
  return post<{
    outcome: "sent" | "skipped-off" | "skipped-already" | "error";
    weekKey: string;
    delivered?: boolean;
    transport?: "smtp" | "spool";
    error?: string;
  }>("/api/admin/notifications/weekly", {});
}

/** Delete + re-seed the backdated demo subscribers (super/admin only). */
export async function resetDemoData(): Promise<{ ok: boolean; removed: number; seeded: number }> {
  return post<{ ok: boolean; removed: number; seeded: number }>("/api/admin/reset-demo", {});
}

/* ----------------------------- packages ----------------------------- */

export async function fetchPackages(): Promise<PackageDTO[]> {
  return request<PackageDTO[]>("/api/admin/packages");
}

/** Public landing pricing — active plans only. */
export async function fetchPublicPackages(): Promise<PackageDTO[]> {
  return request<PackageDTO[]>("/api/packages");
}

export async function createPackage(payload: PackagePayload): Promise<PackageDTO> {
  return post<PackageDTO>("/api/admin/packages", payload);
}

export async function updatePackage(id: string, payload: Partial<PackagePayload>): Promise<PackageDTO> {
  return patch<PackageDTO>(`/api/admin/packages/${encodeURIComponent(id)}`, payload);
}

export async function deletePackage(id: string): Promise<void> {
  await request<{ ok: boolean }>(`/api/admin/packages/${encodeURIComponent(id)}`, { method: "DELETE" });
}

/* ------------------------------ support ----------------------------- */

/** Public support contact channels + dashboard-controlled social links. */
export async function fetchSupportContact(): Promise<SupportContactDTO> {
  return request<SupportContactDTO>("/api/support");
}

/** Public ticket submission (landing support section). */
export async function submitPublicTicket(payload: PublicTicketPayload): Promise<SupportTicketDTO> {
  return post<SupportTicketDTO>("/api/support", payload);
}

/* ----------------------------- audit trail ---------------------------- */

export async function fetchAuditEntries(params?: {
  actorType?: string;
  action?: string;
  limit?: number;
  /** ROUND 136 — per-instance linkage filter (workspace-actor rows +
   *  meta.instance-stamped platform rows). */
  instanceId?: string;
}): Promise<{ entries: AuditEntryDTO[]; total: number }> {
  const search = new URLSearchParams();
  if (params?.actorType) search.set("actorType", params.actorType);
  if (params?.action) search.set("action", params.action);
  if (params?.limit) search.set("limit", String(params.limit));
  if (params?.instanceId) search.set("instanceId", params.instanceId);
  const qs = search.toString();
  return request<{ entries: AuditEntryDTO[]; total: number }>(
    `/api/admin/audit${qs ? `?${qs}` : ""}`
  );
}

/* ROUND 118 — the audit-chain head anchor console (external trust point). */

export type AuditAnchorStatus =
  | "ok"
  | "unanchored"
  | "no-chain"
  | "stale"
  | "truncated"
  | "tampered";

export interface AuditAnchorStatusDTO {
  status: AuditAnchorStatus;
  anchor: {
    trigger: "auto" | "manual";
    anchoredAt: string;
    headHashPrefix: string;
    totalRows: number;
    chainedRows: number;
  } | null;
  head: { headRowId: string; headHash: string; totalRows: number; chainedRows: number } | null;
  anchoredRowPresent: boolean;
  rowsSinceAnchor: number;
  tailCorrupt: boolean;
  unreadable: boolean;
  anchorAgeMs: number | null;
}

/** The live anchor verdict (chain head vs the newest external seal). */
export async function fetchAuditAnchorStatus(): Promise<AuditAnchorStatusDTO> {
  return request<AuditAnchorStatusDTO>("/api/admin/audit/anchor");
}

/** Seal a fresh anchor now (audited server-side; returns the new verdict). */
export async function anchorAuditChainNow(): Promise<{
  anchored: true;
  payload: { anchoredAt: string; headHashPrefix: string; totalRows: number; chainedRows: number };
  status: AuditAnchorStatus;
}> {
  return request("/api/admin/audit/anchor", {
    method: "POST",
    body: JSON.stringify({}),
  });
}

/** ROUND 119 — download the anchor journal (raw JSONL blob save) for
 *  off-host storage. Throws ApiError on 404 (never anchored) / 413. */
export async function downloadAuditAnchorJournal(): Promise<void> {
  const res = await fetch("/api/admin/audit/anchor/export", {
    credentials: "same-origin",
  });
  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    try {
      const data = (await res.json()) as { error?: string };
      if (data?.error) message = data.error;
    } catch {
      /* non-JSON body */
    }
    throw new ApiError(message, res.status);
  }
  const disposition = res.headers.get("Content-Disposition") ?? "";
  const match = /filename="([^"]+)"/.exec(disposition);
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = match?.[1] ?? "audit-anchors.jsonl";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/* ------------------------------ tickets ----------------------------- */

export async function fetchTickets(): Promise<SupportTicketDTO[]> {
  return request<SupportTicketDTO[]>("/api/admin/tickets");
}

export async function createTicket(payload: SupportTicketPayload): Promise<SupportTicketDTO> {
  return post<SupportTicketDTO>("/api/admin/tickets", payload);
}

export async function updateTicket(
  id: string,
  payload: { status?: SupportTicketDTO["status"]; priority?: SupportTicketDTO["priority"]; reply?: string }
): Promise<SupportTicketDTO> {
  return patch<SupportTicketDTO>(`/api/admin/tickets/${encodeURIComponent(id)}`, payload);
}

/** Round 28 — bulk triage: one status and/or priority across many tickets. */
export async function bulkUpdateTickets(
  ids: string[],
  payload: { status?: SupportTicketDTO["status"]; priority?: SupportTicketDTO["priority"] }
): Promise<{ ok: boolean; updated: number }> {
  return patch<{ ok: boolean; updated: number }>("/api/admin/tickets", { ids, ...payload });
}

/** Round 28 — bulk delete many tickets at once. */
export async function bulkDeleteTickets(ids: string[]): Promise<{ ok: boolean; removed: number }> {
  return request<{ ok: boolean; removed: number }>("/api/admin/tickets", {
    method: "DELETE",
    body: JSON.stringify({ ids }),
  });
}

export async function deleteTicket(id: string): Promise<void> {
  await request<{ ok: boolean }>(`/api/admin/tickets/${encodeURIComponent(id)}`, { method: "DELETE" });
}

/* ----------------------------- settings ----------------------------- */

export async function fetchPlatformSettings(): Promise<PlatformSettingsDTO> {
  return request<PlatformSettingsDTO>("/api/admin/settings");
}

export async function updatePlatformSettings(payload: PlatformSettingsPayload): Promise<PlatformSettingsDTO> {
  return patch<PlatformSettingsDTO>("/api/admin/settings", payload);
}

/* ROUND 137 — the SPLIT security-policy surface: the platform 2FA toggle
 * mutates through its own dedicated super-only route (strict audit, the
 * documented MFA break-glass), never through the general settings PATCH. */
export async function updateSecurityPolicy(payload: { twoFARequired: boolean }): Promise<{ twoFARequired: boolean }> {
  return patch<{ twoFARequired: boolean }>("/api/admin/security-policy", payload);
}

/* -------------------- ROUND 41 — AI insights + Super-Admin AI/API controls -------------------- */

/** Availability probe — { enabled } for the current workspace (404-free). */
export async function fetchAiStatus(instanceId: string): Promise<{ enabled: boolean }> {
  return request<{ enabled: boolean }>(
    `/api/instances/${encodeURIComponent(instanceId)}/ai/insights`
  );
}

/** Run (or re-run) a deep AI analysis of the workspace's data.
 * `lang` (ar/en/hi) makes the analysis CONTENT follow the requester's UI
 * language — the prompt adapts server-side (round 41 multilingual AI). */
export async function requestAiInsights(
  instanceId: string,
  payload: { scope?: "all" | string; lang?: "ar" | "en" | "hi" } = {}
): Promise<AiInsightsDTO> {
  return post<AiInsightsDTO>(
    `/api/instances/${encodeURIComponent(instanceId)}/ai/insights`,
    payload
  );
}

/** Super Admin — read the AI/API control-panel state (key never returned). */
export async function fetchAiSettings(): Promise<AiSettingsDTO> {
  return request<AiSettingsDTO>("/api/admin/ai");
}

/** Super Admin — update the AI/API control panel (key sealed server-side). */
export async function updateAiSettings(payload: AiSettingsPayload): Promise<AiSettingsDTO> {
  return patch<AiSettingsDTO>("/api/admin/ai", payload);
}

/** Super Admin — live provider connectivity test. */
export async function testAiConnection(): Promise<{ ok: boolean; detail: string }> {
  return post<{ ok: boolean; detail: string }>("/api/admin/ai/test", {});
}

/* -------------------- EMAIL SYSTEM — communications → email -------------------- */

/** Admin — read the mail/SMTP panel state + the health snapshot. */
export async function fetchMailPanel(): Promise<MailPanelDTO> {
  return request<MailPanelDTO>("/api/admin/mail");
}

/** Super Admin — update the mail/SMTP panel (password sealed server-side). */
export async function updateMailSettings(payload: MailSettingsPayload): Promise<MailSettingsDTO> {
  return patch<MailSettingsDTO>("/api/admin/mail", payload);
}

/** Admin — send a test email through the exact production pipeline. */
export async function sendTestMail(to: string): Promise<MailTestResultDTO> {
  return post<MailTestResultDTO>("/api/admin/mail/test", { to });
}

/** Admin — the paginated EmailLog delivery trail. */
export async function fetchEmailLogs(params: {
  page?: number;
  pageSize?: number;
  status?: string;
  type?: string;
  q?: string;
}): Promise<EmailLogPageDTO> {
  const search = new URLSearchParams();
  if (params.page) search.set("page", String(params.page));
  if (params.pageSize) search.set("pageSize", String(params.pageSize));
  if (params.status) search.set("status", params.status);
  if (params.type) search.set("type", params.type);
  if (params.q) search.set("q", params.q);
  const qs = search.toString();
  return request<EmailLogPageDTO>(`/api/admin/mail/logs${qs ? `?${qs}` : ""}`);
}

/* -------------------- CONTENT SYSTEM — public blog + partners -------------------- */

/** Public — published blog feed (paginated, optional tag filter). */
export async function fetchBlogPosts(params?: {
  page?: number;
  pageSize?: number;
  tag?: string;
}): Promise<BlogPageDTO> {
  const search = new URLSearchParams();
  if (params?.page) search.set("page", String(params.page));
  if (params?.pageSize) search.set("pageSize", String(params.pageSize));
  if (params?.tag) search.set("tag", params.tag);
  const qs = search.toString();
  return request<BlogPageDTO>(`/api/blog${qs ? `?${qs}` : ""}`);
}

/** Public — one published article (increments views) + related posts. */
export async function fetchBlogPost(slug: string): Promise<BlogPostDTO & { related: BlogCardDTO[] }> {
  return request<BlogPostDTO & { related: BlogCardDTO[] }>(
    `/api/blog/${encodeURIComponent(slug)}`
  );
}

/** Public — the curated trusted-sector marquee (real registered orgs). */
export async function fetchSectorPartners(): Promise<{ partners: SectorPartnerDTO[] }> {
  return request<{ partners: SectorPartnerDTO[] }>("/api/partners");
}

/** Admin — the blog console feed (drafts included; status filter + search). */
export async function fetchAdminBlogPosts(params?: {
  page?: number;
  pageSize?: number;
  status?: string;
  q?: string;
}): Promise<AdminBlogPageDTO> {
  const search = new URLSearchParams();
  if (params?.page) search.set("page", String(params.page));
  if (params?.pageSize) search.set("pageSize", String(params.pageSize));
  if (params?.status) search.set("status", params.status);
  if (params?.q) search.set("q", params.q);
  const qs = search.toString();
  return request<AdminBlogPageDTO>(`/api/admin/blog${qs ? `?${qs}` : ""}`);
}

/** Admin — create a blog post (cover uploads ride coverImage as a data URL). */
export async function createBlogPost(payload: BlogPostPayload): Promise<AdminBlogPostDTO> {
  return post<AdminBlogPostDTO>("/api/admin/blog", payload);
}

/** Admin — update a blog post (partial). */
export async function updateBlogPost(id: string, payload: BlogPostPayload): Promise<AdminBlogPostDTO> {
  return patch<AdminBlogPostDTO>(`/api/admin/blog/${encodeURIComponent(id)}`, payload);
}

/** Admin — delete a blog post. */
export async function deleteBlogPost(id: string): Promise<void> {
  await request<{ ok: boolean }>(`/api/admin/blog/${encodeURIComponent(id)}`, { method: "DELETE" });
}

/** Admin — upload an INLINE article image (data-URL → managed ref).
 *  ROUND 129: the rich editor's image insert uses this for uploads; the
 *  returned /api/images/<id> ref is what the safe-markdown body stores. */
export async function uploadBlogImage(dataUrl: string): Promise<string> {
  const res = await post<{ url: string }>("/api/admin/blog/image-upload", { image: dataUrl });
  return res.url;
}

/** Admin — the trusted-sector console (showcase rows + live candidates). */
export async function fetchAdminPartners(): Promise<AdminPartnersDTO> {
  return request<AdminPartnersDTO>("/api/admin/partners");
}

/** Admin — add a registered workspace to the showcase. */
export async function createSectorPartner(payload: SectorPartnerPayload): Promise<AdminSectorPartnerDTO> {
  return post<AdminSectorPartnerDTO>("/api/admin/partners", payload);
}

/** Admin — update a showcase entry (visibility, order, identity, overrides). */
export async function updateSectorPartner(
  id: string,
  payload: SectorPartnerPayload
): Promise<AdminSectorPartnerDTO> {
  return patch<AdminSectorPartnerDTO>(`/api/admin/partners/${encodeURIComponent(id)}`, payload);
}

/** Admin — remove a showcase entry. */
export async function deleteSectorPartner(id: string): Promise<void> {
  await request<{ ok: boolean }>(`/api/admin/partners/${encodeURIComponent(id)}`, { method: "DELETE" });
}


/* -------------------- ROUND 41 — backup & restore -------------------- */

/** Download a full, integrity-checked backup of the workspace (blob save). */
export async function downloadInstanceBackup(instanceId: string): Promise<void> {
  const res = await fetch(`/api/instances/${encodeURIComponent(instanceId)}/backup`, {
    credentials: "same-origin",
  });
  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    try {
      const data = (await res.json()) as { error?: string };
      if (data?.error) message = data.error;
    } catch {
      /* non-JSON body */
    }
    throw new ApiError(message, res.status);
  }
  const disposition = res.headers.get("Content-Disposition") ?? "";
  const match = /filename="([^"]+)"/.exec(disposition);
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = match?.[1] ?? `ashrilogic-backup-${instanceId}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/** Parse a user-selected backup file into its JSON payload.
 * Fail-soft with a typed ApiError (a non-JSON or truncated file must not
 * surface as a raw SyntaxError rejection), and pre-check the size so an
 * accidental multi-GB selection never enters memory — the route-level
 * cap stays the enforcing boundary. */
function parseBackupFile(file: File): Promise<unknown> {
  const MAX_BACKUP_BYTES = 26 * 1024 * 1024; // mirrors the restore route cap
  if (file.size > MAX_BACKUP_BYTES) {
    return Promise.reject(
      new ApiError("Backup file exceeds the 25 MB limit", 413, "BACKUP_TOO_LARGE")
    );
  }
  return file.text().then((text) => {
    try {
      return JSON.parse(text) as unknown;
    } catch {
      throw new ApiError("The selected file is not a valid Ashrilogic backup", 400, "BACKUP_NOT_JSON");
    }
  });
}

/** Verify an uploaded backup file (integrity + ownership gate). */
export async function verifyInstanceBackup(
  instanceId: string,
  file: File
): Promise<BackupVerifyDTO> {
  const payload = await parseBackupFile(file);
  return post<BackupVerifyDTO>(
    `/api/instances/${encodeURIComponent(instanceId)}/restore`,
    { verifyOnly: true, payload }
  );
}

/** Restore the workspace from a verified backup file (transactional). */
export async function restoreInstanceBackup(
  instanceId: string,
  file: File
): Promise<{ ok: boolean; restored: number }> {
  const payload = await parseBackupFile(file);
  return post<{ ok: boolean; restored: number }>(
    `/api/instances/${encodeURIComponent(instanceId)}/restore`,
    { verifyOnly: false, payload }
  );
}

/* ------------- ROUND 45 — security: 2FA / passkeys / sessions ------------- */

/* ------------------------- admin (control panel) ------------------------- */

/** The signed-in admin's TOTP status. */
export async function fetchAdminMfaStatus(): Promise<MfaStatusDTO> {
  return request<MfaStatusDTO>("/api/admin/mfa/setup");
}

/** Start admin TOTP enrollment (otpauth + QR — exists only in this payload). */
export async function startAdminMfaSetup(): Promise<MfaSetupDTO> {
  return post<MfaSetupDTO>("/api/admin/mfa/setup", {});
}

/** Confirm admin TOTP enrollment with a live code → backup codes (once). */
export async function confirmAdminMfaSetup(
  code: string
): Promise<{ ok: boolean; backupCodes: string[]; status: MfaStatusDTO }> {
  return put<{ ok: boolean; backupCodes: string[]; status: MfaStatusDTO }>(
    "/api/admin/mfa/setup",
    { code }
  );
}

/** Admin MFA management (disable / regenerate backups) — code-gated. */
export async function manageAdminMfa(
  action: "disable" | "regenerate-backups",
  code: string
): Promise<{ ok: boolean; backupCodes?: string[]; status?: MfaStatusDTO }> {
  return post<{ ok: boolean; backupCodes?: string[]; status?: MfaStatusDTO }>("/api/admin/mfa", {
    action,
    code,
  });
}

/** The admin's passkeys (metadata only). */
export async function fetchAdminPasskeys(): Promise<{ credentials: WebauthnCredentialDTO[] }> {
  return request<{ credentials: WebauthnCredentialDTO[] }>("/api/admin/passkeys");
}

/** Finish an admin passkey registration (server verifies the attestation). */
export async function finishAdminPasskey(
  name: string,
  response: unknown
): Promise<{ ok: boolean; credentials: WebauthnCredentialDTO[] }> {
  return put<{ ok: boolean; credentials: WebauthnCredentialDTO[] }>("/api/admin/passkeys", {
    name,
    response,
  });
}

/** Remove one of the admin's passkeys. */
export async function removeAdminPasskey(
  credentialId: string
): Promise<{ ok: boolean; credentials: WebauthnCredentialDTO[] }> {
  return request<{ ok: boolean; credentials: WebauthnCredentialDTO[] }>(
    `/api/admin/passkeys/${encodeURIComponent(credentialId)}`,
    { method: "DELETE" }
  );
}

/** The admin's active sessions (+ the current one's jti). */
export async function fetchAdminSessions(): Promise<SessionsDTO> {
  return request<SessionsDTO>("/api/admin/sessions");
}

/** Revoke one admin session (sign out a single device). */
export async function revokeAdminSession(
  jti: string
): Promise<{ ok: boolean; sessions: SessionInfoDTO[] }> {
  return request<{ ok: boolean; sessions: SessionInfoDTO[] }>(
    `/api/admin/sessions/${encodeURIComponent(jti)}`,
    { method: "DELETE" }
  );
}

/** Sign out every OTHER admin session. */
export async function revokeOtherAdminSessions(): Promise<{
  ok: boolean;
  revoked: number;
  sessions: SessionInfoDTO[];
}> {
  return post<{ ok: boolean; revoked: number; sessions: SessionInfoDTO[] }>(
    "/api/admin/sessions/revoke-all",
    {}
  );
}

/** ROUND 46 — sign out EVERYWHERE (this device included). */
export async function signOutEverywhereAdmin(): Promise<{
  ok: boolean;
  revoked: number;
  signedOutEverywhere: boolean;
}> {
  return post<{ ok: boolean; revoked: number; signedOutEverywhere: boolean }>(
    "/api/admin/sessions/revoke-all",
    { includeCurrent: true }
  );
}

/* ---------------------- tenant (workspace) surfaces ---------------------- */

/** The workspace's TOTP status. */
export async function fetchInstanceMfaStatus(instanceId: string): Promise<MfaStatusDTO> {
  return request<MfaStatusDTO>(`/api/instances/${encodeURIComponent(instanceId)}/mfa/setup`);
}

/** Start workspace TOTP enrollment. */
export async function startInstanceMfaSetup(instanceId: string): Promise<MfaSetupDTO> {
  return post<MfaSetupDTO>(`/api/instances/${encodeURIComponent(instanceId)}/mfa/setup`, {});
}

/** Confirm workspace TOTP enrollment → backup codes (once). */
export async function confirmInstanceMfaSetup(
  instanceId: string,
  code: string
): Promise<{ ok: boolean; backupCodes: string[]; status: MfaStatusDTO }> {
  return put<{ ok: boolean; backupCodes: string[]; status: MfaStatusDTO }>(
    `/api/instances/${encodeURIComponent(instanceId)}/mfa/setup`,
    { code }
  );
}

/** Workspace MFA management (disable / regenerate backups) — code-gated. */
export async function manageInstanceMfa(
  instanceId: string,
  action: "disable" | "regenerate-backups",
  code: string
): Promise<{ ok: boolean; backupCodes?: string[]; status?: MfaStatusDTO }> {
  return post<{ ok: boolean; backupCodes?: string[]; status?: MfaStatusDTO }>(
    `/api/instances/${encodeURIComponent(instanceId)}/mfa`,
    { action, code }
  );
}

/** The workspace's passkeys (metadata only). */
export async function fetchInstancePasskeys(
  instanceId: string
): Promise<{ credentials: WebauthnCredentialDTO[] }> {
  return request<{ credentials: WebauthnCredentialDTO[] }>(
    `/api/instances/${encodeURIComponent(instanceId)}/passkeys`
  );
}

/** Finish a workspace passkey registration. */
export async function finishInstancePasskey(
  instanceId: string,
  name: string,
  response: unknown
): Promise<{ ok: boolean; credentials: WebauthnCredentialDTO[] }> {
  return put<{ ok: boolean; credentials: WebauthnCredentialDTO[] }>(
    `/api/instances/${encodeURIComponent(instanceId)}/passkeys`,
    { name, response }
  );
}

/** Remove one workspace passkey. */
export async function removeInstancePasskey(
  instanceId: string,
  credentialId: string
): Promise<{ ok: boolean; credentials: WebauthnCredentialDTO[] }> {
  return request<{ ok: boolean; credentials: WebauthnCredentialDTO[] }>(
    `/api/instances/${encodeURIComponent(instanceId)}/passkeys/${encodeURIComponent(credentialId)}`,
    { method: "DELETE" }
  );
}

/** The workspace's active sessions (+ current jti for owner sessions). */
export async function fetchInstanceSessions(instanceId: string): Promise<SessionsDTO> {
  return request<SessionsDTO>(
    `/api/instances/${encodeURIComponent(instanceId)}/auth/sessions`
  );
}

/** Revoke one workspace session. */
export async function revokeInstanceSession(
  instanceId: string,
  jti: string
): Promise<{ ok: boolean; sessions: SessionInfoDTO[] }> {
  return request<{ ok: boolean; sessions: SessionInfoDTO[] }>(
    `/api/instances/${encodeURIComponent(instanceId)}/auth/sessions/${encodeURIComponent(jti)}`,
    { method: "DELETE" }
  );
}

/** Sign out every OTHER workspace session. */
export async function revokeOtherInstanceSessions(
  instanceId: string
): Promise<{ ok: boolean; revoked: number; sessions: SessionInfoDTO[] }> {
  return post<{ ok: boolean; revoked: number; sessions: SessionInfoDTO[] }>(
    `/api/instances/${encodeURIComponent(instanceId)}/auth/sessions/revoke-all`,
    {}
  );
}

/** ROUND 46 — sign out EVERYWHERE (this device included). */
export async function signOutEverywhereInstance(
  instanceId: string
): Promise<{ ok: boolean; revoked: number; signedOutEverywhere: boolean }> {
  return post<{ ok: boolean; revoked: number; signedOutEverywhere: boolean }>(
    `/api/instances/${encodeURIComponent(instanceId)}/auth/sessions/revoke-all`,
    { includeCurrent: true }
  );
}

/** Finish the workspace login's TOTP step (ticket + code → session). */
export async function instanceMfaLogin(
  ticket: string,
  code: string
): Promise<{ ok: boolean; instance: InstanceDTO }> {
  return post<{ ok: boolean; instance: InstanceDTO }>("/api/instances/auth/login/mfa", {
    ticket,
    code,
  });
}

/**
 * ROUND 56 — passkey-FIRST sign-in for system owners (usernameless,
 * workspace-scoped): startAuthentication with the discoverable options from
 * /api/instances/auth/passkey-login, then verify the assertion — the server
 * resolves the owning workspace from the credential id and opens the
 * workspace session.
 */
export async function instancePasskeyLogin(): Promise<{ ok: boolean; instance: InstanceDTO }> {
  const { startAuthentication } = await import("@simplewebauthn/browser");
  const startRes = await fetch("/api/instances/auth/passkey-login", {
    method: "POST",
    credentials: "same-origin",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ step: "start" }),
  });
  if (!startRes.ok) {
    const data = (await startRes.json().catch(() => ({}))) as { error?: string };
    throw new ApiError(data.error ?? "Passkey sign-in failed", startRes.status);
  }
  const { options } = (await startRes.json()) as {
    options: Parameters<typeof startAuthentication>[0]["optionsJSON"];
  };
  const assertion = await startAuthentication({ optionsJSON: options });
  const finishRes = await fetch("/api/instances/auth/passkey-login", {
    method: "POST",
    credentials: "same-origin",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ step: "finish", response: assertion }),
  });
  if (!finishRes.ok) {
    const data = (await finishRes.json().catch(() => ({}))) as { error?: string };
    throw new ApiError(data.error ?? "Passkey verification failed", finishRes.status);
  }
  return (await finishRes.json()) as { ok: boolean; instance: InstanceDTO };
}

/** Admin-panel login — TOTP/backup step (ticket + code → session). */
export async function adminMfaLogin(
  ticket: string,
  code: string
): Promise<AdminUserDTO> {
  return post<AdminUserDTO>("/api/admin/login/mfa", { ticket, code });
}

/* ----------------- product reviews & ratings (ROUND 63) ----------------- */

/** Public reviews for one storefront product (keyset-paginated, newest
 *  first) plus the recomputed visible-only rating summary (mean, count and
 *  the exact per-star histogram). Pass the returned `nextCursor` back
 *  verbatim for the next page. */
export async function fetchProductReviews(
  siteId: string,
  recordId: string,
  cursor?: string
): Promise<SiteReviewsPageDTO> {
  const qs = new URLSearchParams({ recordId });
  if (cursor) qs.set("cursor", cursor);
  return request<SiteReviewsPageDTO>(
    `/api/sites/${encodeURIComponent(siteId)}/store/reviews?${qs.toString()}`
  );
}

/** Submit a guest review — or UPDATE it: the server upserts one review per
 *  visitor per product, so `updated: true` means an existing review was
 *  revised (its moderation state is untouched). */
export async function submitProductReview(
  siteId: string,
  payload: { recordId: string; rating: number; name: string; body?: string }
): Promise<{ review: SiteReviewDTO; updated: boolean }> {
  return post<{ review: SiteReviewDTO; updated: boolean }>(
    `/api/sites/${encodeURIComponent(siteId)}/store/reviews`,
    payload
  );
}

/** Owner console — the moderation feed over ALL reviews (visible + hidden),
 *  keyset-paginated, with console-wide aggregates (total / hiddenCount / avg). */
export async function fetchInstanceReviews(
  instanceId: string,
  cursor?: string
): Promise<OwnerReviewsPageDTO> {
  const qs = new URLSearchParams();
  if (cursor) qs.set("cursor", cursor);
  const suffix = qs.size > 0 ? `?${qs.toString()}` : "";
  return request<OwnerReviewsPageDTO>(
    `/api/instances/${encodeURIComponent(instanceId)}/store/reviews${suffix}`
  );
}

/** Owner moderation — hide (true) or restore (false) one review. Hidden rows
 *  vanish from every public read AND every public aggregate. */
export async function setInstanceReviewHidden(
  instanceId: string,
  reviewId: string,
  hidden: boolean
): Promise<{ review: OwnerReviewDTO }> {
  return patch<{ review: OwnerReviewDTO }>(
    `/api/instances/${encodeURIComponent(instanceId)}/store/reviews/${encodeURIComponent(reviewId)}`,
    { hidden }
  );
}

/** Owner moderation — permanently remove one review. */
export async function deleteInstanceReview(
  instanceId: string,
  reviewId: string
): Promise<{ ok: boolean }> {
  return request<{ ok: boolean }>(
    `/api/instances/${encodeURIComponent(instanceId)}/store/reviews/${encodeURIComponent(reviewId)}`,
    { method: "DELETE" }
  );
}

/* ----------------- ROUND 84 (84-PROFILE) — owner profile gate ----------------- */

/**
 * ROUND 84 — the workspace owner's stored personal profile + completed flag
 * (GET /api/instances/[id]/owner-profile; owner session only — 403/401
 * otherwise). `completed === false` keeps the blocking dashboard gate up.
 */
export async function fetchOwnerProfile(id: string): Promise<OwnerProfileDTO> {
  return request<OwnerProfileDTO>(
    `/api/instances/${encodeURIComponent(id)}/owner-profile`
  );
}

/**
 * ROUND 84 — STRICT completion write (PUT /api/instances/[id]/owner-profile):
 * every field is server-validated (gender enum · birth date aged 13–120 ·
 * address ≥ 10 · nationality inside the shared COUNTRIES catalog · job title
 * ≥ 2 · phone ^\\+?[0-9]{8,15}$); a passing payload is stamped with
 * completedAt and unlocks the dashboard in place.
 */
export async function saveOwnerProfile(
  id: string,
  profile: OwnerProfilePayload
): Promise<OwnerProfileDTO> {
  return put<OwnerProfileDTO>(
    `/api/instances/${encodeURIComponent(id)}/owner-profile`,
    profile
  );
}

/* ------------- ROUND 147 — customer avatar (own profile surfaces) ---------------- */

/**
 * ROUND 147 — upload the signed-in customer's avatar photo. `dataUrl` is the
 * canvas-compressed data-URL the member page mints client-side; the server
 * runs the FULL image pipeline (magic bytes / dimension / bomb caps / sharp
 * re-encode) and persists a MANAGED /api/images/<sha> ref on the session
 * owner's row. 400 carries the pipeline's user-presentable message verbatim
 * (same error mapping every account mutation uses — ApiError.message).
 * Returns the fresh account (write-through target for ["store-account", id]).
 */
export async function uploadStoreAccountAvatar(
  instanceId: string,
  dataUrl: string
): Promise<StoreAccountDTO> {
  const data = await post<{ account: StoreAccountDTO }>(
    `/api/sites/${encodeURIComponent(instanceId)}/account/avatar`,
    { image: dataUrl }
  );
  return data.account;
}

/** ROUND 147 — remove the avatar (back to the initials tile). Idempotent
 *  server-side; returns the fresh account. */
export async function removeStoreAccountAvatar(
  instanceId: string
): Promise<StoreAccountDTO> {
  const data = await request<{ account: StoreAccountDTO }>(
    `/api/sites/${encodeURIComponent(instanceId)}/account/avatar`,
    { method: "DELETE" }
  );
  return data.account;
}

/* ---------------- ROUND 158 (security) — platform IP banlist ---------------- */

/** The platform's banned IP list (one record per banned address). */
export interface BannedIpDTO {
  /** normalized dotted-quad / IPv6 (no ::ffff: prefix) */
  ip: string;
  /** ISO timestamp the ban was added — empty for legacy entries */
  addedAt: string;
  /** free-form admin note (max 120 chars) — never the actor name */
  note?: string;
}

/** GET /api/admin/security/ip-ban — the current banlist (super only). */
export async function fetchBannedIps(): Promise<{ ips: BannedIpDTO[] }> {
  return request<{ ips: BannedIpDTO[] }>("/api/admin/security/ip-ban");
}

/** POST /api/admin/security/ip-ban — add an IP to the banlist (idempotent). */
export async function banIp(
  ip: string,
  note?: string
): Promise<{ ips: BannedIpDTO[] }> {
  return post<{ ips: BannedIpDTO[] }>("/api/admin/security/ip-ban", { ip, note });
}

/** DELETE /api/admin/security/ip-ban/[ip] — remove an IP (idempotent). */
export async function unbanIp(
  ip: string
): Promise<{ ips: BannedIpDTO[] }> {
  return request<{ ips: BannedIpDTO[] }>(
    `/api/admin/security/ip-ban/${encodeURIComponent(ip)}`,
    { method: "DELETE" }
  );
}
