import type { Lang } from "@/lib/types";
import { intlLocale } from "@/lib/locales";

/**
 * Shared client-side number/money/country formatting.
 *
 * Single source of truth for locale-aware formatting on the CLIENT (the
 * server twin with integer-minor-unit money lives in
 * src/lib/server/money.ts). Previously the same helpers were re-implemented
 * in six+ modules — behavioral drift between storefront surfaces is the
 * direct consequence; this module ends that. Pure functions, no React, no
 * client-only imports — safe for any component tree (including the public
 * website, which must NOT depend on the store's cart/account graph).
 */

/** locale-aware numerals (Arabic-Indic for AR, native digits otherwise) */
export function nf(lang: Lang, n: number): string {
  try {
    return new Intl.NumberFormat(intlLocale(lang)).format(n);
  } catch {
    return String(n);
  }
}

/** localized country name (fail-soft) */
export function countryName(lang: Lang, code: string): string | null {
  if (!code) return null;
  try {
    return new Intl.DisplayNames([intlLocale(lang)], { type: "region" }).of(code) ?? null;
  } catch {
    return null;
  }
}

/** storefront money formatting — locale-aware + the store's own currency. */
export function fmtPrice(lang: Lang, amount: number, currency: string): string {
  try {
    return new Intl.NumberFormat(intlLocale(lang), {
      style: "currency",
      currency: /^[A-Za-z]{3}$/.test(currency) ? currency : "SAR",
      maximumFractionDigits: 2,
    }).format(amount);
  } catch {
    return `${nf(lang, amount)} ${currency || "SAR"}`;
  }
}
