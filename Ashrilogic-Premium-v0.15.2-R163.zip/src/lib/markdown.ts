/**
 * Ashrilogic — SAFE markdown subset renderer (content system).
 *
 * Blog bodies are authored in the Super Admin console as a deliberately small
 * markdown subset and rendered with this module — **no raw HTML ever passes
 * through**. The pipeline escapes every HTML entity FIRST, then converts the
 * markdown tokens into the allow-listed tag set, so the output is XSS-safe by
 * construction (nothing to sanitize afterwards because nothing unsafe can
 * enter). Shared by:
 *   - the public article view (/blog/[slug])
 *   - the admin editor live preview
 *   - the API layer (reading-time estimation is the same word counter)
 *
 * Supported subset:
 *   ## / ###        headings            (h2, h3)
 *   **text**        bold                (strong)
 *   `text`          inline code         (code)
 *   - item          unordered lists     (ul > li, consecutive lines)
 *   1. item         ordered lists       (ol > li, consecutive lines)
 *   > quote         blockquote          (single or multi-line)
 *   ---             horizontal rule     (hr)
 *   [t](url)        links               (http/https/mailto, schemeless
 *                                        domains → https, root-relative
 *                                        /paths → internal links — ROUND 131;
 *                                        validated + whitespace-tolerant)
 *   ![alt](url)     images              (http/https or managed /api/images/
 *                                        refs ONLY — ROUND 129; self-styled
 *                                        so every renderer shows them alike)
 *   bare URLs       autolinks           (ROUND 131 — a pasted https://… or
 *                                        www.… link becomes a real anchor
 *                                        without any markup; trailing
 *                                        punctuation stays outside; never
 *                                        re-links inside <a>/<img>/<code>)
 *   <https://…>     angle autolinks     (ROUND 131 — the markdown-standard
 *                                        bracketed form normalizes to a link)
 *   <a href…>       paste normalization (ROUND 131 — links copied as raw HTML
 *                                        from other editors are converted to
 *                                        the safe [t](url) form pre-escape;
 *                                        the href passes the SAME validation)
 *   :icon:          inline icon badges  (ROUND 129 — a fixed whitelist of 25
 *                                        lucide-shaped glyphs, emitted as
 *                                        self-contained inline <svg> with
 *                                        currentColor stroke; unknown keys
 *                                        render as literal text)
 *   blank-line-separated paragraphs
 *
 * ROUND 131 — the link pipeline is direction-robust: bidi control characters
 * (RLM/LRM/isolates) pasted from RTL editors are stripped from targets, and
 * targets are trimmed, so a link typed in an Arabic body renders exactly
 * like one typed in English. Internal (/…) links open in the SAME tab (no
 * target/rel hardening needed); external links keep the noopener/noreferrer/
 * nofollow + target=_blank hardening.
 */

/** Every HTML-sensitive character becomes an entity BEFORE any token work. */
function escapeHtml(input: string): string {
  return input
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/** Bidi control characters (RLM/LRM/ALM + isolates) sneak into URLs pasted
 *  from RTL editors and silently break every URL regex — stripped globally. */
const BIDI_CTRL = /[\u200E\u200F\u200B\u202A-\u202E\u2066-\u2069]/g;

function stripBidi(input: string): string {
  return input.replace(BIDI_CTRL, "");
}

/** A validated link target. `internal` (root-relative /path) links stay in
 *  the same tab; everything external keeps the full hardening attributes. */
interface HrefTarget {
  href: string;
  internal: boolean;
}

/** Schemeless host-shaped targets (example.sa, www.x.com/path) get https.
 *  Root-relative /… targets are internal. http/https/mailto pass as-is. */
const DOMAIN_LIKE = /^[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+(?:\/[^\s]*)?$/;

/** Only these link targets may leave the renderer as an href. */
function safeHref(raw: string): HrefTarget | null {
  const href = stripBidi(raw).trim();
  if (!href) return null;
  const lower = href.toLowerCase();
  if (lower.startsWith("http://") || lower.startsWith("https://") || lower.startsWith("mailto:")) {
    return { href, internal: false };
  }
  /* root-relative internal path: /compare, /packages — never //host (protocol
   * relative) which is external, and never a backslash form: WHATWG URL
   * parsing treats "\" like "/" in special schemes, so /\evil.com navigates
   * to evil.com while looking "internal" (ROUND 146 integrity closure). */
  if (href.startsWith("/") && !href.startsWith("//") && !href.includes("\\")) {
    return { href, internal: true };
  }
  /* schemeless but host-shaped: www.example.com, example.sa/pricing → the
   * only safe assumption is https (browsers would guess the same). */
  if (DOMAIN_LIKE.test(href) && !href.includes("@")) {
    return { href: `https://${href}`, internal: false };
  }
  return null;
}

/** External anchor with the standing hardening attributes. */
function externalAnchor(href: string, label: string): string {
  return `<a href="${escapeAttr(href)}" rel="noopener noreferrer nofollow" target="_blank">${label}</a>`;
}

/** Internal anchor — same-tab navigation, no target/rel needed. */
function internalAnchor(href: string, label: string): string {
  return `<a href="${escapeAttr(href)}">${label}</a>`;
}

/** Image sources: http(s) OR a root-relative managed image ref
 *  (the sanitized /api/images/<id> pipeline — ROUND 129). Nothing else
 *  (no data: URLs — bodies are stored text; no javascript:/relative paths). */
function safeImgSrc(raw: string): string | null {
  const src = raw.trim();
  const lower = src.toLowerCase();
  if (lower.startsWith("http://") || lower.startsWith("https://")) return src;
  /* managed refs are exact-shaped: /api/images/<id> — no query, no fragment */
  if (/^\/api\/images\/[a-z0-9]+$/i.test(src)) return src;
  return null;
}

/* ------------------------------------------------------------------ */
/* ROUND 131 — raw-source normalization (runs BEFORE any escaping)        */
/* ------------------------------------------------------------------ */

/** Angle autolinks <https://x.com> and raw-HTML anchors pasted from other
 *  editors become the safe [label](url) form with VALIDATED targets — a
 *  hostile href (javascript:/data:) stays raw and therefore stays escaped
 *  literal text downstream. Runs on the un-escaped source, so the attribute
 *  quotes here are real quotes. */
function normalizeRawLinks(source: string): string {
  let s = stripBidi(source);

  /* <https://example.com/path> → [url](url) (the markdown-standard form) */
  s = s.replace(/<((?:https?:\/\/|www\.)[^\s<>]+)>/g, (match, url: string) => {
    const target = safeHref(url);
    return target ? `[${url}](${target.href})` : match;
  });

  /* <a href="URL" …>TEXT</a> → [TEXT](URL) — authors paste rich links from
   *  mail clients / word processors; inner tags in TEXT are dropped, the
   *  href must validate. Multi-line anchors tolerated (paragraph joins keep
   * them on one logical line only when they were authored so — the render
   * pipeline splits lines first, so this pass runs per normalized WHOLE
   * document before line splitting). */
  s = s.replace(
    /<a\s[^>]*href\s*=\s*["']([^"']+)['"][^>]*>([\s\S]*?)<\/a>/gi,
    (match, url: string, text: string) => {
      const clean = String(text).replace(/<[^>]+>/g, "").replace(/\[[\]]/g, "").trim().slice(0, 120);
      const target = safeHref(String(url));
      return target && clean ? `[${clean}](${target.href})` : match;
    }
  );

  return s;
}

/* ------------------------------------------------------------------ */
/* ROUND 129 — inline icon badges (fixed whitelist, emitted as svg)      */
/* ------------------------------------------------------------------ */

/** One lucide-shaped primitive in a 24×24 viewBox. */
 type MdIconShape =
  | { t: "p"; d: string }
  | { t: "c"; cx: number; cy: number; r: number }
  | { t: "r"; x: number; y: number; w: number; h: number; rx?: number }
  | { t: "e"; cx: number; cy: number; rx: number; ry: number };

/** The curated badge set (path data extracted from lucide v0.525.0 — ISC).
 *  Keys double as editor-picker ids and match the CatIcon registry names,
 *  so the picker previews exactly what the renderer emits. */
const MD_ICON_SHAPES: Record<string, MdIconShape[]> = {
  rocket: [
    { t: "p", d: "M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z" },
    { t: "p", d: "m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z" },
    { t: "p", d: "M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0" },
    { t: "p", d: "M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5" },
  ],
  "shield-check": [
    { t: "p", d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" },
    { t: "p", d: "m9 12 2 2 4-4" },
  ],
  lock: [
    { t: "r", x: 3, y: 11, w: 18, h: 11, rx: 2 },
    { t: "p", d: "M7 11V7a5 5 0 0 1 10 0v4" },
  ],
  sparkles: [
    { t: "p", d: "M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z" },
    { t: "p", d: "M20 3v4" },
    { t: "p", d: "M22 5h-4" },
    { t: "p", d: "M4 17v2" },
    { t: "p", d: "M5 18H3" },
  ],
  lightbulb: [
    { t: "p", d: "M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5" },
    { t: "p", d: "M9 18h6" },
    { t: "p", d: "M10 22h4" },
  ],
  zap: [
    { t: "p", d: "M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z" },
  ],
  target: [
    { t: "c", cx: 12, cy: 12, r: 10 },
    { t: "c", cx: 12, cy: 12, r: 6 },
    { t: "c", cx: 12, cy: 12, r: 2 },
  ],
  "trending-up": [
    { t: "p", d: "M16 7h6v6" },
    { t: "p", d: "m22 7-8.5 8.5-5-5L2 17" },
  ],
  star: [
    { t: "p", d: "M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z" },
  ],
  check: [{ t: "p", d: "M20 6 9 17l-5-5" }],
  info: [
    { t: "c", cx: 12, cy: 12, r: 10 },
    { t: "p", d: "M12 16v-4" },
    { t: "p", d: "M12 8h.01" },
  ],
  "triangle-alert": [
    { t: "p", d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3" },
    { t: "p", d: "M12 9v4" },
    { t: "p", d: "M12 17h.01" },
  ],
  globe: [
    { t: "c", cx: 12, cy: 12, r: 10 },
    { t: "p", d: "M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20" },
    { t: "p", d: "M2 12h20" },
  ],
  database: [
    { t: "e", cx: 12, cy: 5, rx: 9, ry: 3 },
    { t: "p", d: "M3 5V19A9 3 0 0 0 21 19V5" },
    { t: "p", d: "M3 12A9 3 0 0 0 21 12" },
  ],
  cloud: [{ t: "p", d: "M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z" }],
  users: [
    { t: "p", d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" },
    { t: "p", d: "M16 3.128a4 4 0 0 1 0 7.744" },
    { t: "p", d: "M22 21v-2a4 4 0 0 0-3-3.87" },
    { t: "c", cx: 9, cy: 7, r: 4 },
  ],
  calendar: [
    { t: "p", d: "M8 2v4" },
    { t: "p", d: "M16 2v4" },
    { t: "r", x: 3, y: 4, w: 18, h: 18, rx: 2 },
    { t: "p", d: "M3 10h18" },
  ],
  briefcase: [
    { t: "r", x: 2, y: 6, w: 20, h: 14, rx: 2 },
    { t: "p", d: "M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" },
  ],
  award: [
    { t: "p", d: "m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526" },
    { t: "c", cx: 12, cy: 8, r: 6 },
  ],
  flag: [
    { t: "p", d: "M4 22V4a1 1 0 0 1 .4-.8A6 6 0 0 1 8 2c3 0 5 2 7.333 2q2 0 3.067-.8A1 1 0 0 1 20 4v10a1 1 0 0 1-.4.8A6 6 0 0 1 16 16c-3 0-5-2-8-2a6 6 0 0 0-4 1.528" },
  ],
  compass: [
    { t: "p", d: "m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z" },
    { t: "c", cx: 12, cy: 12, r: 10 },
  ],
  key: [
    { t: "p", d: "m15.5 7.5 2.3 2.3a1 1 0 0 0 1.4 0l2.1-2.1a1 1 0 0 0 0-1.4L19 4" },
    { t: "p", d: "m21 2-9.6 9.6" },
    { t: "c", cx: 7.5, cy: 15.5, r: 5.5 },
  ],
  "heart-pulse": [
    { t: "p", d: "M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" },
    { t: "p", d: "M3.22 12H9.5l.5-1 2 4.5 2-7 1.5 3.5h5.27" },
  ],
  bell: [
    { t: "p", d: "M10.268 21a2 2 0 0 0 3.464 0" },
    { t: "p", d: "M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326" },
  ],
  "graduation-cap": [
    { t: "p", d: "M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z" },
    { t: "p", d: "M22 10v6" },
    { t: "p", d: "M6 12.5V16a6 3 0 0 0 12 0v-3.5" },
  ],
};

/** Editor-facing whitelist (picker order = insertion order). */
export const MD_ICON_KEYS: readonly string[] = Object.keys(MD_ICON_SHAPES);

function mdShapeSvg(shape: MdIconShape): string {
  switch (shape.t) {
    case "p":
      return `<path d="${shape.d}"/>`;
    case "c":
      return `<circle cx="${shape.cx}" cy="${shape.cy}" r="${shape.r}"/>`;
    case "r":
      return `<rect x="${shape.x}" y="${shape.y}" width="${shape.w}" height="${shape.h}" rx="${shape.rx ?? 0}"/>`;
    case "e":
      return `<ellipse cx="${shape.cx}" cy="${shape.cy}" rx="${shape.rx}" ry="${shape.ry}"/>`;
  }
}

/** A fixed-attribute inline <svg> (currentColor stroke, 18px, baseline-
 *  aligned) — the shape data comes only from the whitelist above, never from
 *  the document, so the emission is XSS-safe by construction. */
function mdIconSvg(key: string): string {
  const shapes = MD_ICON_SHAPES[key].map(mdShapeSvg).join("");
  return `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" role="img" aria-label="${key}" style="display:inline-block;vertical-align:-3px;margin:0 2px">${shapes}</svg>`;
}

/** Inline pass: bold, code, links, images, icon badges — applied to
 *  already-escaped text. IMAGES run BEFORE links so the `![alt](url)` form
 *  is not half-consumed by the link pattern; BARE-URL AUTOLINKS run after
 *  the explicit forms (ROUND 131) and skip <code>/<a>/<img> segments so a
 *  URL already inside an anchor is never linked twice; ICON tokens run
 *  LAST and skip `<code>` segments so literal code samples keep their
 *  `:key:` text. */
function renderInline(escaped: string): string {
  let out = escaped;

  /* `code` → <code> (run first so ** inside backticks stays literal) */
  out = out.replace(/`([^`\n]+)`/g, "<code>$1</code>");

  /* **bold** → <strong> */
  out = out.replace(/\*\*([^*\n]+)\*\*/g, "<strong>$1</strong>");

  /* ![alt](url) → <img> (validated source; alt fully escaped already) —
   * ROUND 129. Self-styled (max-width + rounded + margins) so the public
   * view, the admin preview and the excerpt contexts render alike. */
  out = out.replace(/!\[([^\]\n]*)\]\(\s*([^)\s]+)\s*\)/g, (match, alt: string, url: string) => {
    const src = safeImgSrc(stripBidi(url));
    if (!src) return match;
    const srcAttr = src.replace(/"/g, "%22");
    return `<img src="${srcAttr}" alt="${alt}" loading="lazy" decoding="async" style="max-width:100%;height:auto;border-radius:12px;margin:6px 0"/>`;
  });

  /* [label](url) → <a> (validated target — http/https/mailto, schemeless
   *  domains upgraded to https, root-relative /paths internal — ROUND 131;
   *  the \s* trims tolerate the typed `[label]( url )` form) */
  out = out.replace(/\[([^\]\n]+)\]\(\s*([^)\s]+)\s*\)/g, (match, label: string, url: string) => {
    const target = safeHref(url);
    if (!target) return match; // not a target we vouch for — render as literal text
    return target.internal
      ? internalAnchor(target.href, label)
      : externalAnchor(target.href, label);
  });

  /* bare-URL autolinks — ROUND 131 (https://… and www.… in plain text) */
  out = autolinkBareUrls(out);

  /* :icon: → whitelisted inline svg (skips code segments) — ROUND 129 */
  out = out
    .split(/(<code>[\s\S]*?<\/code>)/g)
    .map((segment) =>
      segment.startsWith("<code>")
        ? segment
        : segment.replace(/:([a-z][a-z0-9-]{1,30}):/g, (match, key: string) =>
            MD_ICON_SHAPES[key] ? mdIconSvg(key) : match
          )
    )
    .join("");

  return out;
}

/* Trailing punctuation that peels off an autolinked URL (Latin + Arabic
 * sentence punctuation) — sentence ends never become part of the href. */
const AUTOLINK_TRAIL = ".,;:!?)\u0022'»؟؛،";

/** Segments that must never be autolinked inside: code spans, whole anchors
 *  (the explicit-link pass already ran) and self-closed images. */
const SKIP_SEGMENT = /(<code>[\s\S]*?<\/code>|<a [^>]*>[\s\S]*?<\/a>|<img [^>]*>)/g;

/** The bare-URL autolink pass (ROUND 131). Input is already-escaped inline
 *  HTML — entities like &amp; inside a URL are legal in href attributes and
 *  stay as-is. */
function autolinkBareUrls(inline: string): string {
  return inline
    .split(SKIP_SEGMENT)
    .map((segment) => {
      if (segment.startsWith("<code>") || segment.startsWith("<a ") || segment.startsWith("<img ")) {
        return segment;
      }
      return segment.replace(
        /https?:\/\/[^\s<]+|(?<![a-zA-Z0-9@._-])www\.[^\s<]+/g,
        (match) => {
          let url = match;
          while (url.length > 8 && AUTOLINK_TRAIL.includes(url.charAt(url.length - 1))) {
            url = url.slice(0, -1);
          }
          const target = safeHref(url);
          if (!target || target.internal) return match;
          const trail = match.slice(url.length);
          return externalAnchor(target.href, url) + trail;
        }
      );
    })
    .join("");
}

/** Escapes a URL for safe inclusion in an attribute position. */
function escapeAttr(input: string): string {
  return input.replace(/"/g, "%22").replace(/'/g, "%27").replace(/</g, "%3C").replace(/>/g, "%3E");
}

/**
 * Renders the safe-markdown subset to an HTML string.
 * The output uses only: h2, h3, p, strong, code, a, ul, ol, li, blockquote, hr.
 */
export function renderMarkdown(source: string): string {
  /* ROUND 131 — normalize pasted/typed raw link forms + strip bidi control
   *  characters BEFORE any escaping or line splitting. */
  const normalized = normalizeRawLinks((source ?? "").replace(/\r\n/g, "\n"));
  const lines = normalized.split("\n");
  const html: string[] = [];

  let i = 0;
  const flushParagraph = (buffer: string[]): void => {
    if (buffer.length > 0) {
      html.push(`<p>${renderInline(buffer.map(escapeHtml).join("<br />"))}</p>`);
      buffer.length = 0;
    }
  };

  const paragraph: string[] = [];

  while (i < lines.length) {
    const raw = lines[i];
    const line = raw.trimEnd();
    const trimmed = line.trim();

    /* blank line — paragraph break */
    if (trimmed === "") {
      flushParagraph(paragraph);
      i++;
      continue;
    }

    /* horizontal rule */
    if (/^(-{3,}|\*{3,}|_{3,})$/.test(trimmed)) {
      flushParagraph(paragraph);
      html.push("<hr />");
      i++;
      continue;
    }

    /* headings */
    const heading = /^(#{2,3})\s+(.+)$/.exec(trimmed);
    if (heading) {
      flushParagraph(paragraph);
      const level = heading[1].length === 2 ? "h2" : "h3";
      html.push(`<${level}>${renderInline(escapeHtml(heading[2]))}</${level}>`);
      i++;
      continue;
    }

    /* blockquote — consecutive `>` lines merge into one blockquote */
    if (trimmed.startsWith(">")) {
      flushParagraph(paragraph);
      const quote: string[] = [];
      while (i < lines.length && lines[i].trim().startsWith(">")) {
        quote.push(lines[i].trim().replace(/^>\s?/, ""));
        i++;
      }
      html.push(`<blockquote>${renderInline(quote.map(escapeHtml).join("<br />"))}</blockquote>`);
      continue;
    }

    /* unordered list — consecutive `- ` lines */
    if (/^[-•]\s+/.test(trimmed)) {
      flushParagraph(paragraph);
      const items: string[] = [];
      while (i < lines.length && /^[-•]\s+/.test(lines[i].trim())) {
        items.push(`<li>${renderInline(escapeHtml(lines[i].trim().replace(/^[-•]\s+/, "")))}</li>`);
        i++;
      }
      html.push(`<ul>${items.join("")}</ul>`);
      continue;
    }

    /* ordered list — consecutive `1. ` style lines */
    if (/^\d+[.)]\s+/.test(trimmed)) {
      flushParagraph(paragraph);
      const items: string[] = [];
      while (i < lines.length && /^\d+[.)]\s+/.test(lines[i].trim())) {
        items.push(`<li>${renderInline(escapeHtml(lines[i].trim().replace(/^\d+[.)]\s+/, "")))}</li>`);
        i++;
      }
      html.push(`<ol>${items.join("")}</ol>`);
      continue;
    }

    /* plain text — accumulates into the current paragraph */
    paragraph.push(line);
    i++;
  }

  flushParagraph(paragraph);
  return html.join("\n");
}

/** Rough word counter that treats Arabic and Latin text identically. */
export function countWords(source: string): number {
  const matches = (source ?? "").trim().match(/[\p{L}\p{N}']+/gu);
  return matches ? matches.length : 0;
}

/**
 * Reading-time estimate in whole minutes (avg 200 wpm, floor of 1).
 * The SAME function runs in the admin editor (live estimate) and inside the
 * write API (stored value) so the badge can never disagree with the article.
 */
export function readingMinutes(...sources: string[]): number {
  const words = sources.reduce((sum, s) => sum + countWords(s), 0);
  return Math.max(1, Math.round(words / 200));
}

/** Escapes a string for safe inclusion in a URL path segment (slugs). */
export function slugify(input: string): string {
  return (input ?? "")
    .trim()
    .toLowerCase()
    .replace(/['"()]/g, "")
    .replace(/[^\p{L}\p{N}]+/gu, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 96);
}

/* Exported for potential attribute builders in article views. */
export { escapeAttr as escapeUrl };
