"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { AppView, DashView, Lang, WizardDraft } from "@/lib/types";

/**
 * Persisted-storage key. Round 35 renamed the key from the legacy
 * "ashrilogic-v2-ui" to "ashrilogic-ui" (the platform's name is Ashrilogic,
 * not Ashrilogic V2) — the one-time migration below copies any legacy
 * persisted state onto the new key so users keep their language, favorites,
 * wizard drafts and active workspace across the rename.
 */
const STORE_KEY = "ashrilogic-ui";
const LEGACY_STORE_KEY = "ashrilogic-v2-ui";

if (typeof window !== "undefined") {
  try {
    if (localStorage.getItem(STORE_KEY) === null) {
      const legacy = localStorage.getItem(LEGACY_STORE_KEY);
      if (legacy !== null) {
        localStorage.setItem(STORE_KEY, legacy);
      }
    }
    localStorage.removeItem(LEGACY_STORE_KEY);
  } catch {
    /* private mode / storage disabled — persist simply no-ops */
  }
}

interface UIState {
  /** top-level app view */
  view: AppView;
  /** current dash view when view === "dashboard" */
  dashView: DashView;
  /** the module whose premium workspace is open (dashView === "module") */
  activeModuleId: string | null;
  /** wizard draft (survives accidental closes within a session) */
  wizardDraft: WizardDraft | null;
  /** the instance the dashboard is bound to */
  currentInstanceId: string | null;
  /** the workspace just signed into — highlighted on the system select screen */
  selectHighlightId: string | null;
  /** owner email that signed in — the select screen only lists THEIR systems */
  selectOwnerEmail: string | null;
  /** ROUND 82 (batch-5 ②) — the signed-in owner launching the wizard from
   *  the «أنظمتك المنشأة» screen. Non-null ⇒ the wizard's admin step offers
   *  "reuse my current account" (same email + current password, verified
   *  server-side) so every system lands on ONE account. Never persisted. */
  wizardOwner: { name: string; email: string } | null;
  /** mobile sidebar */
  sidebarOpen: boolean;
  /** language (mirrored to <html lang/dir> by LangProvider effect) */
  lang: Lang;
  /** pinned/favorite system ids (landing library) — persisted */
  favorites: string[];
  /** global command palette open state (never persisted) */
  paletteOpen: boolean;
  /** ROUND 78 — strict-RBAC preview lens: the owner may preview the
   *  dashboard through a member role's permissions ("view as"). Never
   *  persisted — a reload always returns the owner's full lens. */
  rolePreview: "off" | "manager" | "staff" | "viewer";

  setView: (v: AppView) => void;
  setDashView: (v: DashView) => void;
  /** open a module workspace (or clear the selection) */
  setActiveModuleId: (moduleId: string | null) => void;
  startWizard: (draft: WizardDraft) => void;
  consentAccepted: boolean;
  setConsentAccepted: (accepted: boolean) => void;
  updateDraft: (patch: Partial<WizardDraft>) => void;
  clearDraft: () => void;
  setCurrentInstance: (id: string | null) => void;
  setSelectHighlightId: (id: string | null) => void;
  setSelectOwnerEmail: (email: string | null) => void;
  /** ROUND 82 — arm/clear the wizard owner-reuse context */
  setWizardOwner: (owner: { name: string; email: string } | null) => void;
  setSidebarOpen: (open: boolean) => void;
  setLang: (lang: Lang) => void;
  /** exit dashboard → landing */
  exitToLanding: () => void;
  /** pin/unpin a system in the landing favorites */
  toggleFavorite: (systemId: string) => void;
  /** global command palette (⌘K / ⌘J) */
  setPaletteOpen: (open: boolean) => void;
  /** ROUND 78 — set/clear the role-preview lens ("off" restores the owner) */
  setRolePreview: (role: "off" | "manager" | "staff" | "viewer") => void;
}

export const useAppStore = create<UIState>()(
  persist(
    (set) => ({
      view: "landing",
      dashView: "overview",
      activeModuleId: null,
      wizardDraft: null,
      currentInstanceId: null,
      selectHighlightId: null,
      selectOwnerEmail: null,
      wizardOwner: null,
      sidebarOpen: false,
      lang: "ar",
      favorites: [],
      paletteOpen: false,
      rolePreview: "off",

      setView: (v) => set({ view: v }),
      setDashView: (v) => set({ dashView: v }),
      setActiveModuleId: (moduleId) => set({ activeModuleId: moduleId }),
      startWizard: (draft) => set({ wizardDraft: draft, view: "wizard", consentAccepted: false }),
    consentAccepted: false,
    setConsentAccepted: (accepted) => set({ consentAccepted: accepted }),
      updateDraft: (patch) =>
        set((s) => (s.wizardDraft ? { wizardDraft: { ...s.wizardDraft, ...patch } } : s)),
      clearDraft: () => set({ wizardDraft: null }),
      setCurrentInstance: (id) => set({ currentInstanceId: id }),
      setSelectHighlightId: (id) => set({ selectHighlightId: id }),
      setSelectOwnerEmail: (email) => set({ selectOwnerEmail: email }),
      setWizardOwner: (owner) => set({ wizardOwner: owner }),
      setSidebarOpen: (open) => set({ sidebarOpen: open }),
      setLang: (lang) => set({ lang }),
      exitToLanding: () =>
        set({
          view: "landing",
          dashView: "overview",
          activeModuleId: null,
          sidebarOpen: false,
          selectHighlightId: null,
          selectOwnerEmail: null,
          rolePreview: "off",
        }),
      toggleFavorite: (systemId) =>
        set((s) => ({
          favorites: s.favorites.includes(systemId)
            ? s.favorites.filter((id) => id !== systemId)
            : [...s.favorites, systemId],
        })),
      setPaletteOpen: (open) => set({ paletteOpen: open }),
      setRolePreview: (role) => set({ rolePreview: role }),
    }),
    {
      name: STORE_KEY,
      storage: createJSONStorage(() => localStorage),
      /* ROUND 143 — persisted-state migration: the «التقارير» dash view was
       * renamed to the specialized «الإشعارات» center. A persisted
       * dashView:"reports" (a user who had the old page open) maps onto
       * "notifications" so nobody ever lands on a blank main area. */
      version: 2,
      migrate: (persisted, version) => {
        const state = persisted as Partial<UIState> | undefined;
        /* the string cast is deliberate: the legacy value predates the
         * DashView rename, so the type system can no longer name it. */
        if (version < 2 && state && (state.dashView as string) === "reports") {
          return { ...state, dashView: "notifications" as DashView };
        }
        return state ?? {};
      },
      // only persist what makes sense across reloads
      partialize: (s) => ({
        lang: s.lang,
        currentInstanceId: s.currentInstanceId,
        view: s.view === "dashboard" || s.view === "wizard" ? s.view : "landing",
        dashView: s.dashView,
        // the open module workspace survives reloads (like the dash view)
        activeModuleId: s.activeModuleId,
        // wizard draft survives accidental reloads / HMR (restored with its
        // step) — ROUND 36 SECURITY: the admin password + confirmation are
        // STRIPPED before persisting. Credentials never touch localStorage
        // (they stay transient in memory only); the user re-enters them on
        // the admin step after a reload.
        wizardDraft: s.wizardDraft
          ? {
              ...s.wizardDraft,
              admin: {
                ...s.wizardDraft.admin,
                password: "",
                confirm: "",
              },
            }
          : null,
        // pinned/favorite systems survive reloads
        favorites: s.favorites,
      }),
    }
  )
);
