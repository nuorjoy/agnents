/**
 * ROUND 89 — Next.js server instrumentation hook.
 *
 * Runs once per server process (dev server boot, production start). Used to
 * register the platform's standing schedulers:
 *
 *  - the WEEKLY DIGEST clock (console Settings → الإشعارات → التقرير
 *    الأسبوعي): ticks every 15 minutes and delivers the platform's weekly
 *    performance report for any ISO week that has no NotificationLog row
 *    yet — idempotent across dev reloads and downtime catch-ups.
 *  - the MIGRATION LOAD TRIGGER (SQLite → PostgreSQL readiness): a real
 *    write-probe sampler; SUSTAINED write-latency/busy pressure can only
 *    ever START migration readiness (PREPARING) — never switch databases.
 *    Disable entirely with MIGRATION_TRIGGER_ENABLED=0.
 *  - the PLATFORM BACKUP SAFETY NET (ROUND 112): ticks every 15 minutes
 *    and calls the scheduled-backup evaluation, whose freshness gate is
 *    DISK-based (newest snapshot age). Closes the zero-traffic gap — the
 *    opportunistic nudges only fire on audited mutations, so a quiet
 *    platform used to go snapshot-less silently.
 *
 * Edge runtime is skipped explicitly (NEXT_RUNTIME !== "nodejs"); the
 * schedulers own a Prisma client + the mailer, both node-only.
 */
export async function register(): Promise<void> {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;

  /* ROUND 161 — P1-11 fix: production storage invariant.
   * In production, local filesystem storage is NOT durable (Vercel
   * serverless /tmp is ephemeral). Refuse to boot (or warn loudly) if
   * ASHRILOGIC_STORAGE_DRIVER is not "s3" in production. */
  if (process.env.NODE_ENV === "production") {
    const driver = (process.env.ASHRILOGIC_STORAGE_DRIVER ?? "local").trim().toLowerCase();
    if (driver === "local") {
      console.warn(
        "[instrumentation] WARNING: ASHRILOGIC_STORAGE_DRIVER=local in production! " +
        "Uploaded images, mail spool, and backups will be lost on container restart. " +
        "Set ASHRILOGIC_STORAGE_DRIVER=s3 + S3_ENDPOINT/S3_BUCKET/S3_ACCESS_KEY_ID/S3_SECRET_ACCESS_KEY for durable storage."
      );
    }
  }

  try {
    /* MIGRATION SPLIT-BRAIN GUARD — reconcile the SQLite control-plane
       state against the provider the app actually serves from BEFORE any
       scheduler or write path runs. Destructive migration commands can
       never act on a stale primary record. */
    const { reconcileMigrationState } = await import("./lib/server/migration/reconcile");
    const verdict = await reconcileMigrationState();
    console.log(`[instrumentation] migration-state reconciliation: ${verdict.action} — ${verdict.detail}`);
  } catch (error) {
    /* instrumentation must never block server boot */
    console.error("[instrumentation] migration-state reconciliation failed:", error);
  }
  try {
    const { startWeeklyDigestScheduler } = await import("./lib/server/platform-notifications");
    startWeeklyDigestScheduler();
    console.log("[instrumentation] weekly-digest scheduler registered");
  } catch (error) {
    /* instrumentation must never block server boot */
    console.error("[instrumentation] scheduler registration failed:", error);
  }
  try {
    const { startMigrationLoadTrigger } = await import("./lib/server/migration/load-signals");
    startMigrationLoadTrigger();
  } catch (error) {
    console.error("[instrumentation] migration load-trigger registration failed:", error);
  }
  try {
    const { startBackupSafetyNet } = await import("./lib/server/platform-backup");
    startBackupSafetyNet();
    console.log("[instrumentation] platform backup safety-net registered");
  } catch (error) {
    console.error("[instrumentation] backup safety-net registration failed:", error);
  }
  try {
    /* ROUND 87 — daily trash retention sweep (expired soft-deleted rows
       are destroyed permanently; cheap no-op when nothing is due). */
    const { startTrashRetentionSafetyNet } = await import("./lib/server/trash");
    startTrashRetentionSafetyNet();
    console.log("[instrumentation] trash retention safety-net registered");
  } catch (error) {
    console.error("[instrumentation] trash retention safety-net registration failed:", error);
  }
  try {
    /* ROUND 113 — webhook dispatcher: due retries + fresh enqueues sweep
       every 60s under a SchedulerLease (multi-instance safe). Events
       enqueued by a request also self-dispatch opportunistically; this
       standing pass is the reliability net (crashed dispatch passes,
       backoff-due retries, retention sweep). */
    const { startWebhookDispatcher } = await import("./lib/server/webhook-dispatch");
    startWebhookDispatcher();
    console.log("[instrumentation] webhook dispatcher registered");
  } catch (error) {
    console.error("[instrumentation] webhook dispatcher registration failed:", error);
  }
  try {
    /* ROUND 117 — unreferenced-image GC safety net: hourly sweep under a
       SchedulerLease. Reclaims the storage behind replaced/cleared/purged
       images (rows whose references are gone past the 24h grace) plus the
       ROUND 105 orphan half (files with no row) in the same tick. */
    const { startImageRefGcSafetyNet } = await import("./lib/server/image-ref-gc");
    startImageRefGcSafetyNet();
    console.log("[instrumentation] image-ref GC safety-net registered");
  } catch (error) {
    console.error("[instrumentation] image-ref GC safety-net registration failed:", error);
  }
  try {
    /* ROUND 140 — unreferenced-VIDEO GC safety net: the same discipline as
       the image sweep, applied to the product media clips (MediaAsset rows
       + storage/media/<sha>.<ext> files) referenced from
       ModuleRecord.videosJson. Hourly, under its own SchedulerLease. */
    const { startMediaRefGcSafetyNet } = await import("./lib/server/media-ref-gc");
    startMediaRefGcSafetyNet();
    console.log("[instrumentation] media-ref GC safety-net registered");
  } catch (error) {
    console.error("[instrumentation] media-ref GC safety-net registration failed:", error);
  }
  try {
    /* ROUND 118 — audit-chain HEAD ANCHOR safety net: hourly tick under a
       SchedulerLease. Seals the chain's current head (id + hash + counts)
       into the MAC-verified external file (data/audit-anchors.jsonl) so a
       database-only compromise cannot silently truncate the newest audit
       rows; a bad verdict (truncated/tampered) writes the sealed
       system.auditAnchor alert onto the chain itself. */
    const { startAuditAnchorSafetyNet } = await import("./lib/server/audit-anchor");
    startAuditAnchorSafetyNet();
    console.log("[instrumentation] audit-chain anchor safety-net registered");
  } catch (error) {
    console.error("[instrumentation] audit-chain anchor safety-net registration failed:", error);
  }
  try {
    /* ROUND 120 — order compensation repair sweep: re-drives cancelled
       orders whose stock/coupon release did not fully land (crash between
       the cancel CAS and the release, or a partial CAS-conflict skip)
       until their compensatedAt marker is set. Durable compensation —
       reservations are never leaked silently anymore. */
    const { startOrderCompensationSweep } = await import("./lib/server/order-compensation");
    startOrderCompensationSweep();
    console.log("[instrumentation] order-compensation repair sweep registered");
  } catch (error) {
    console.error("[instrumentation] order-compensation sweep registration failed:", error);
  }
  try {
    /* ROUND 120 — mail outbox sweeper: sendMail persists a PENDING
       EmailLog row (full envelope) BEFORE delivery; this sweep re-drives
       the rows a crashed process left pending (durable email delivery
       for business-critical notices). */
    const { startMailOutboxSweeper } = await import("./lib/server/mail/outbox-sweeper");
    startMailOutboxSweeper();
    console.log("[instrumentation] mail outbox sweeper registered");
  } catch (error) {
    console.error("[instrumentation] mail outbox sweeper registration failed:", error);
  }
}
