import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import type { AdminAddonOrderDTO, AddonOrderDTO } from "@/lib/types";
import {
  cancelAddonOrder,
  catalogProjectionFor,
  confirmAddonOrderPaid,
  createAddonOrder,
  effectiveFeatureMap,
  toAddonOrderDTO,
} from "@/lib/server/addon-orders";
import { buildInstructions, findPaymentMethod, readPaymentsSettings, WALLET_CHECKOUT_METHOD_ID } from "@/lib/server/plan-orders";
import { toMinorUnits } from "@/lib/server/money";
import { payOrderFromWallet, refundWalletDebit } from "@/lib/server/wallet";
import { HttpError } from "@/lib/server/route";
import { logAudit, maskEmail } from "@/lib/server/audit";
import type { PlanCycle } from "@/lib/types";
import * as repository from "./repository";

/**
 * Ashrilogic — ROUND 141 (متجر الإضافات): the add-on orders SERVICE.
 *
 * Business flows for the Add-ons Store surface (tenant create/list/cancel)
 * and the console's confirmation queue — the mirror of the plan-orders
 * service with the feature-override activation step.
 */

export interface TenantPrincipal {
  kind: string;
  actorId?: string;
  actorName: string;
}

/** The console's queue (org context attached for the admin rows). */
export async function listConsole(status?: "pending" | "paid" | "cancelled"): Promise<AdminAddonOrderDTO[]> {
  const rows = await repository.listForConsole(status);
  return rows.map((row) => {
    const dto = toAddonOrderDTO(row);
    let orgName = "";
    try {
      orgName = (JSON.parse(row.instance?.orgJson ?? "{}") as { name?: string }).name?.trim() || "";
    } catch {
      orgName = "";
    }
    return { ...dto, orgName, systemId: row.instance?.systemId ?? "" };
  });
}

/** The workspace's own add-on order history (newest first). */
export async function listOwn(instanceId: string): Promise<AddonOrderDTO[]> {
  const rows = await repository.listForInstance(instanceId);
  return rows.map(toAddonOrderDTO);
}

/** The workspace's add-on CATALOG with live active states + LIVE prices
 *  (ROUND 141 dynamic pricing — console overrides apply instantly). */
export async function catalogFor(
  instanceId: string
): Promise<{ features: Awaited<ReturnType<typeof catalogProjectionFor>>; orders: AddonOrderDTO[] }> {
  const instance = await repository.findLiveInstance(instanceId);
  if (!instance) throw new HttpError(404, "Instance not found");
  const effective = await effectiveFeatureMap(instance);
  return {
    features: await catalogProjectionFor(effective),
    orders: await listOwn(instanceId),
  };
}

/** Console confirm/cancel (the feature-override merge runs on "paid"). */
export async function confirmOrCancel(
  orderId: string,
  action: "paid" | "cancelled",
  admin: { id: string; name: string }
) {
  const result =
    action === "paid"
      ? await confirmAddonOrderPaid(orderId)
      : await cancelAddonOrder(orderId);
  if (!result.ok) throw new HttpError(result.status, result.error, result.code);

  await logAudit({
    actorType: "admin",
    actorId: admin.id,
    actorName: admin.name,
    action: "instance.addonActivate",
    targetLabel: `${result.order.reference} · ${result.instance.id.slice(0, 8)}`,
    meta: {
      features: result.order.featuresJson,
      action,
      activatedFeatures: result.activatedFeatures.join(","),
    },
  });

  const fresh = await db.instance.findUnique({
    where: { id: result.instance.id },
    select: { featureOverridesJson: true },
  });
  return {
    order: toAddonOrderDTO(result.order),
    activatedFeatures: result.activatedFeatures,
    overrides: fresh?.featureOverridesJson ?? null,
  };
}

/** Tenant create: validate → price server-side → order + instructions.
 *  ROUND 141 — payWith "wallet" selects the INSTANT wallet checkout
 *  (debit + confirm + force-ON activation, no admin round-trip). */
export async function createOwn(
  instanceId: string,
  input: { features: string[]; cycle: PlanCycle; methodId: string; payWith?: "wallet" },
  principal: TenantPrincipal
) {
  const instance = await repository.findLiveInstance(instanceId);
  if (!instance) throw new HttpError(404, "Instance not found");

  const result = await createAddonOrder(
    instance,
    input.features,
    input.cycle,
    input.payWith === "wallet" ? WALLET_CHECKOUT_METHOD_ID : input.methodId
  );
  if (!result.ok) throw new HttpError(result.status, result.error, result.code);

  /* ------------------ ROUND 141 — the INSTANT wallet checkout ------------------
   * Same compensating law as plan orders: debit (CAS) → confirm (the
   * force-ON feature merge) → refund + cancel when confirmation fails. */
  if (input.payWith === "wallet") {
    const amountMinor = toMinorUnits(result.order.amount);
    const pay = await payOrderFromWallet({
      instanceId: instance.id,
      amountMinor,
      linkId: result.order.id,
      reference: result.order.reference,
      note: `إضافات: ${result.order.featuresJson}`,
    });
    if (!pay.ok) {
      await cancelAddonOrder(result.order.id);
      throw new HttpError(pay.status, pay.error, pay.code);
    }
    const confirm = await confirmAddonOrderPaid(result.order.id);
    /* ROUND 162 — the ORDER_NOT_PENDING→paid race (the plan-orders twin):
     * a concurrently-confirmed order must NOT be refunded — the debit
     * already bought the activated features. Only compensate when the
     * order did NOT end up paid. */
    let paidOrder = confirm.ok ? confirm.order : null;
    if (!confirm.ok) {
      const raced =
        confirm.code === "ORDER_NOT_PENDING"
          ? await repository.findPaidOrder(result.order.id)
          : null;
      if (raced) {
        paidOrder = raced;
      } else {
        await refundWalletDebit({
          instanceId: instance.id,
          amountMinor,
          linkId: result.order.id,
          reference: result.order.reference,
          note: "استرداد تلقائي — تعذر تفعيل طلب الإضافات",
        });
        await cancelAddonOrder(result.order.id);
        throw new HttpError(confirm.status, confirm.error, confirm.code);
      }
    }
    if (!paidOrder) {
      /* unreachable structurally (both arms assign a row or throw) —
       * kept for the type system and as defense in depth */
      throw new HttpError(500, "Order confirmation failed");
    }
    /* ROUND 141 (owner notifications) — the instant wallet payment rides
     * the workspace activity feed (zero-delay bell). */
    await db.activity.create({
      data: {
        instanceId: instance.id,
        kind: "actWalletDebit",
        metaJson: JSON.stringify({ amount: amountMinor / 100, addons: result.order.featuresJson }),
      },
    });
    await logAudit({
      actorType: principal.kind === "admin" ? "admin" : "instance",
      actorId: principal.actorId,
      actorName: maskEmail(principal.actorName),
      action: "instance.addonOrderCreate",
      targetLabel: result.order.reference,
      meta: {
        features: result.order.featuresJson,
        cycle: result.order.cycle,
        method: "wallet",
        methodLabel: "محفظة Ashrilogic",
        amount: String(result.order.amount),
        currency: result.order.currency,
        walletPaid: "instant",
        activated: "true",
      },
    });
    return {
      order: toAddonOrderDTO(paidOrder),
      walletPaid: true as const,
      balanceAfterMinor: pay.balanceAfterMinor,
    };
  }

  const payments = await readPaymentsSettings();
  const method = findPaymentMethod(payments, result.order.methodId || input.methodId);
  if (!method) {
    /* the historical post-create inconsistency envelope (the order EXISTS
       but its method vanished from the console list) */
    throw new HttpError(500, "Payment method not found");
  }
  const instructions = buildInstructions(method, result.order.reference, payments);

  await logAudit({
    actorType: principal.kind === "admin" ? "admin" : "instance",
    actorId: principal.actorId,
    actorName: maskEmail(principal.actorName),
    action: "instance.addonOrderCreate",
    targetLabel: result.order.reference,
    meta: {
      features: result.order.featuresJson,
      cycle: result.order.cycle,
      method: result.order.method,
      methodLabel: result.order.methodLabel,
      amount: String(result.order.amount),
      currency: result.order.currency,
    },
  });

  return { order: toAddonOrderDTO(result.order), instructions };
}

/** Tenant cancel-own (cross-tenant ids are 404s, never actionable). */
export async function cancelOwn(instanceId: string, orderId: string, principal: TenantPrincipal) {
  const ref = await repository.findOrderInstanceRef(orderId);
  if (!ref || ref.instanceId !== instanceId) {
    throw new HttpError(404, "Order not found");
  }
  const result = await cancelAddonOrder(orderId);
  if (!result.ok) throw new HttpError(result.status, result.error, result.code);

  await logAudit({
    actorType: principal.kind === "admin" ? "admin" : "instance",
    actorId: principal.actorId,
    actorName: maskEmail(principal.actorName),
    action: "instance.addonOrderCancel",
    targetLabel: result.order.reference,
    meta: { features: result.order.featuresJson },
  });

  return toAddonOrderDTO(result.order);
}

/** A silent helper so NextResponse stays imported for future handlers. */
export const _nextJson = NextResponse.json;
