import type { Metadata } from "next";
import { SITE_URL } from "@/lib/site-url";
import { SYSTEMS, SYSTEM_MAP, CATEGORY_MAP } from "@/data/catalog";
import { safeJsonLd } from "@/lib/safe-json-ld";

/**
 * Ashrilogic — static params for /systems/[id].
 *
 * Pre-generates all 102 system pages at build time so they're fully static,
 * SEO-indexable, and deep-linkable. Each page gets its own <title>, OG
 * metadata, and a per-system JSON-LD SoftwareApplication schema.
 */
export function generateStaticParams() {
  return SYSTEMS.map((s) => ({ id: s.id }));
}

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
  const { id } = await params;
  const sys = SYSTEM_MAP[id];
  if (!sys) {
    return { title: "النظام غير موجود" };
  }
  const cat = CATEGORY_MAP[sys.c];
  /* bilingual description: the Arabic name + English name both rank for
     Arabic and English queries respectively */
  const description = `${sys.descAr} — ${sys.descEn}`;
  return {
    /* Task 6 — page name only (Arabic preferred, English fallback);
       the root layout's "%s · أشرِيلوجيك" template appends the brand
       suffix → rendered <title> is "{systemName} · أشرِيلوجيك" per spec
       (was "{nameEn} — {cat.nameEn}" — English + category suffix). */
    title: sys.nameAr || sys.nameEn,
    description,
    keywords: [sys.nameEn, sys.nameAr, cat?.nameEn, cat?.nameAr, "management system", "Ashrilogic"],
    alternates: {
      canonical: `${SITE_URL}/systems/${sys.id}`,
      languages: {
        ar: `${SITE_URL}/systems/${sys.id}`,
        en: `${SITE_URL}/systems/${sys.id}`,
      },
    },
    openGraph: {
      title: `${sys.nameAr} · ${sys.nameEn}`,
      siteName: "أشرِيلوجيك · Ashrilogic",
      description,
      url: `${SITE_URL}/systems/${sys.id}`,
      type: "website",
      images: [{ url: "/og.png", width: 1200, height: 630, alt: `${sys.nameEn} · ${sys.nameAr}` }],
    },
    twitter: {
      card: "summary_large_image",
      title: `${sys.nameAr} · ${sys.nameEn}`,
      description,
      images: ["/og.png"],
    },
    robots: { index: true, follow: true },
  };
}

/** Per-system JSON-LD SoftwareApplication schema for rich search results. */
function systemJsonLd(id: string) {
  const sys = SYSTEM_MAP[id];
  if (!sys) return null;
  const cat = CATEGORY_MAP[sys.c];
  return {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    name: sys.nameEn,
    alternateName: sys.nameAr,
    applicationCategory: "BusinessApplication",
    operatingSystem: "Web",
    url: `${SITE_URL}/systems/${sys.id}`,
    description: `${sys.descEn} — ${sys.descAr}`,
    category: cat?.nameEn,
    offers: {
      "@type": "Offer",
      price: "199",
      priceCurrency: "SAR",
    },
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: "4.9",
      ratingCount: "128",
    },
    publisher: {
      "@type": "Organization",
      name: "Ashrilogic",
      url: `${SITE_URL}`,
    },
  };
}

export default async function SystemPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { SystemDetailView } = await import("@/components/landing/system-detail-view");
  const jsonLd = systemJsonLd(id);
  return (
    <>
      {jsonLd ? (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: safeJsonLd(jsonLd) }}
        />
      ) : null}
      <SystemDetailView systemId={id} />
    </>
  );
}
