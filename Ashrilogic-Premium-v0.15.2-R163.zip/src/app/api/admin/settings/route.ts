import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { seedAdminDefaults, settingsUpdateSchema, toSettingsDTO, zodError } from "@/lib/server/admin-mapper";
import { sanitizeAddonPricing } from "@/lib/server/addon-pricing";
import { requireAdmin } from "@/lib/server/admin-session";
import { invalidatePlatformSettingsCache } from "@/lib/server/platform-settings-cache";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";

export const dynamic = "force-dynamic";

/**
 * GET /api/admin/settings — the singleton platform settings row.
 * Creates the default row on first read. Any authenticated admin.
 * Financial receiving details (bank accounts / IBANs / wallet numbers) and
 * the campaign email list are need-to-know: they are stripped from the
 * payload for roles below admin — the console renders the payments section
 * for super admins only anyway, so nothing legitimate changes.
 */
export async function GET() {
  const guard = await requireAdmin();
  if (guard instanceof NextResponse) return guard;

  try {
    await seedAdminDefaults(db);
    const row = await db.platformSetting.findUniqueOrThrow({ where: { id: "global" } });
    const dto = await toSettingsDTO(row);
    if (guard.user.role !== "super" && guard.user.role !== "admin") {
      const { payments, ...rest } = dto;
      return NextResponse.json({ ...rest, payments: null, newsletterEmails: [] });
    }
    return NextResponse.json(dto);
  } catch (error) {
    console.error("GET /api/admin/settings failed:", error);
    return NextResponse.json({ error: "Failed to load settings" }, { status: 500 });
  }
}

/**
 * PATCH /api/admin/settings — partially update platform settings.
 * Only whitelisted fields pass the strict Zod schema. Requires super/admin.
 * ROUND 37: the SECURITY audit controls (`auditLog`, `dataRetention`) are
 * super-only — a plain admin must not be able to switch off / thin out the
 * audit trail that records their own actions.
 * ROUND 137: `twoFARequired` is GONE from this surface — the 2FA policy
 * mutates through the dedicated super-only /api/admin/security-policy
 * route, and this endpoint therefore no longer sits in the MFA-enrollment
 * allowlist (its mutations enforce MFA like every other admin surface).
 */
export async function PATCH(req: Request) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  /* ROUND 87 — the identity object can carry up to three ~1M-char image
     data-URLs, so the settings PATCH reads its body with a widened cap
     (the default 1.5MB would refuse a fully-dressed identity save). */
  const body = await readJson(req, 4_000_000);
  if (!body.ok) return body.response;

  const parsed = settingsUpdateSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }

  /* ROUND 37 — security-toggle protection: `auditLog` gates business
     activity logging and `dataRetention` prunes the trail — handing those
     to a non-super admin would let them disable/shorten the record of their
     own behavior. ROUND 87 — `trashRetentionDays` joins the same super-only
     class: it bounds how long ANY soft-deleted evidence survives. Everything
     else keeps the existing super/admin gating. */
  if (
    guard.user.role !== "super" &&
    (parsed.data.auditLog !== undefined ||
      parsed.data.dataRetention !== undefined ||
      parsed.data.trashRetentionDays !== undefined)
  ) {
    return NextResponse.json(
      { error: "Security audit and trash retention settings require a super admin" },
      { status: 403 }
    );
  }
  const data = parsed.data;

  /* socialLinks travels as a JSON array in the API but is stored as a
     JSON string column (SQLite) — serialize + strip it from the Prisma
     payload. Round 29: same pattern for the newsletter email list.
     ROUND 47: same pattern for the payment-receiving details.
     ROUND 87: same pattern for the brand identity object. */
  const { socialLinks, newsletterEmails, payments, identity, addonsPricing, ...scalarFields } = data;
  const prismaData: Record<string, unknown> = { ...scalarFields };
  if (socialLinks) {
    prismaData.socialJson = JSON.stringify(socialLinks);
  }
  if (newsletterEmails) {
    prismaData.newsletterEmailsJson = JSON.stringify(newsletterEmails);
  }
  if (payments) {
    prismaData.paymentsJson = JSON.stringify(payments);
  }
  if (identity) {
    prismaData.identityJson = JSON.stringify(identity);
  }
  /* ROUND 141 — the dynamic add-on pricing table: sanitized server-side
   *  (known keys + in-range integer prices only), stored as JSON, and
   *  LIVE on the next order + catalog projection (zero code changes). */
  if (addonsPricing) {
    prismaData.addonsPricingJson = JSON.stringify(sanitizeAddonPricing(addonsPricing));
  }

  try {
    const row = await db.platformSetting.update({ where: { id: "global" }, data: prismaData });
    /* ROUND 145 (perf) — the shared platform-settings TTL cache must never
     * serve the pre-write snapshot to maintenance / session-TTL / payments
     * readers: drop the entry the moment the write commits. */
    invalidatePlatformSettingsCache();
    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "settings.update",
      meta: Object.keys(data).slice(0, 6).reduce<Record<string, string>>((acc, key) => {
        const value = (data as Record<string, unknown>)[key];
        acc[key] =
          key === "socialLinks"
            ? `${(socialLinks ?? []).length} networks`
            : key === "newsletterEmails"
              ? `${(newsletterEmails ?? []).length} emails`
              : /* ROUND 48 — summarize the dynamic methods list (kinds + count),
                   never the raw receiving details */
                key === "payments"
                ? `${(payments?.methods ?? []).length} methods`
                : /* ROUND 87 — the identity object can embed full data-URL
                   images: never let those bytes reach the audit trail —
                   record only THAT the identity was touched */
                  key === "identity"
                  ? "true"
                  : /* ROUND 141 — the pricing table summarizes by override
                     count, never the raw table */
                    key === "addonsPricing"
                    ? `${Object.keys(addonsPricing?.monthly ?? {}).length} overrides`
                    : /* ROUND 37 — never store a raw address in the trail */
                    key === "supportEmail"
                    ? maskEmail(String(value))
                    : String(value);
        return acc;
      }, {}),
    });
    /* round 29 — dedicated trail row whenever the dynamic newsletter email
       list itself was touched (add / edit / delete from its own admin card) */
    if (newsletterEmails) {
      await logAudit({
        actorType: "admin",
        actorId: guard.user.id,
        actorName: guard.user.username,
        action: "newsletter.emails",
        targetLabel: "newsletter emails",
        meta: { count: String(newsletterEmails.length) },
      });
    }
    return NextResponse.json(await toSettingsDTO(row));
  } catch (error) {
    console.error("PATCH /api/admin/settings failed:", error);
    return NextResponse.json({ error: "Failed to save settings" }, { status: 500 });
  }
}
