import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { SUBSCRIBER_STATUSES, subscriberStatusRead } from "@/lib/server/admin-mapper";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { blindIndex, decryptField, encryptField } from "@/lib/server/crypto-vault";
import { readJson } from "@/lib/server/http";

export const dynamic = "force-dynamic";

/** Server-side email shape — RFC 5322 "atext" local part (see subscribe route):
 *  hostile fragments never enter the sealed campaign list. */
const EMAIL_RE = /^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?)+$/;

/** Split a free-form multi-email payload: commas, semicolons, newlines, spaces. */
function parseEmails(raw: string): string[] {
  return raw
    .split(/[\n\r,;\s]+/)
    .map((e) => e.trim().toLowerCase())
    .filter((e) => e.length > 0);
}

const bulkSchema = z.object({
  emails: z.string().min(1).max(20_000),
  tag: z.string().trim().max(40).optional().or(z.literal("")),
});

/* round-26 row actions — retag AND/OR edit the address AND/OR moderate the status */
const rowSchema = z
  .object({
    id: z.string().min(1),
    tag: z.string().trim().max(40).optional(),
    email: z.email().optional(),
    status: z.enum(SUBSCRIBER_STATUSES).optional(),
  })
  .refine((data) => data.tag !== undefined || data.email !== undefined || data.status !== undefined, {
    message: "At least one of tag / email / status is required",
  });

/* round-27 bulk moderation — apply one status/tag to MANY rows at once */
const bulkModerationSchema = z
  .object({
    ids: z.array(z.string().min(1)).min(1).max(500),
    tag: z.string().trim().max(40).optional(),
    status: z.enum(SUBSCRIBER_STATUSES).optional(),
  })
  .refine((data) => data.tag !== undefined || data.status !== undefined, {
    message: "At least one of tag / status is required for bulk actions",
  });

const bulkDeleteSchema = z.object({
  ids: z.array(z.string().min(1)).min(1).max(500),
});

/**
 * GET /api/admin/newsletter — the full subscriber list.
 * Optional ?q= search (email/tag substring) and ?tag= exact filter
 * ("__none__" = untagged only). Any authenticated admin.
 */
export async function GET(req: Request) {
  const guard = await requireAdmin(["super", "admin", "moderator"]);
  if (guard instanceof NextResponse) return guard;

  const url = new URL(req.url);
  /* ROUND 37 — cap the free-text search param: it is compared in-memory
     against up to 5000 decrypted rows, so an unbounded ?q= is both a scan
     amplifier and a log-noise vector. 120 chars is far beyond any real
     email/tag substring. */
  const q = (url.searchParams.get("q") ?? "").slice(0, 120).trim().toLowerCase();
  const tag = (url.searchParams.get("tag") ?? "").trim();

  try {
    /* ROUND 36 (perf) — the former path loaded + decrypted EVERY subscriber
       row on every view. Now: tag filtering runs in SQL, the tag list comes
       from a SQL groupBy, the total from a count, and rows are bounded to
       the newest SCAN_CAP for the (sealed-email) substring search — the
       decrypted response page stays capped at 500. */
    const tagWhere =
      tag === "" ? undefined : tag === "__none__" ? { tag: null } : { tag };

    const [count, tags, rows] = await Promise.all([
      db.subscriber.count({ where: tagWhere }),
      db.subscriber.groupBy({ by: ["tag"], _count: { _all: true } }).then((groups) =>
        groups.map((g) => g.tag).filter((x): x is string => !!x).sort()
      ),
      db.subscriber.findMany({
        where: tagWhere,
        orderBy: { createdAt: "desc" },
        take: 5000, // scan cap for the sealed-email substring search
        select: { id: true, email: true, tag: true, status: true, createdAt: true, updatedAt: true },
      }),
    ]);

    /* round 35 — the email column is sealed; decrypt for search + response */
    const view = rows.map((s) => ({ ...s, email: decryptField(s.email) ?? "" }));

    const filtered = view.filter((s) => {
      const matchesQ = !q || s.email.toLowerCase().includes(q) || (s.tag ?? "").toLowerCase().includes(q);
      return matchesQ;
    });

    return NextResponse.json({
      count,
      filtered: q ? filtered.length : count,
      tags,
      subscribers: filtered.slice(0, 500),
    });
  } catch (error) {
    console.error("GET /api/admin/newsletter failed:", error);
    return NextResponse.json({ error: "Failed to load subscribers" }, { status: 500 });
  }
}

/**
 * POST /api/admin/newsletter — bulk-add subscribers.
 * Accepts one or many emails (comma / newline / space separated) plus an
 * optional organizer tag. Duplicates are skipped, invalid addresses are
 * reported per-address. Requires super/admin.
 */
export async function POST(req: Request) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const read = await readJson(req);
  if (!read.ok) return read.response;

  const parsed = bulkSchema.safeParse(read.data);
  if (!parsed.success) {
    return NextResponse.json({ error: "emails (string) and optional tag are required" }, { status: 400 });
  }

  const emails = parseEmails(parsed.data.emails);
  const tag = (parsed.data.tag ?? "").trim() || null;

  if (emails.length === 0) {
    return NextResponse.json({ error: "No email addresses found" }, { status: 422 });
  }
  if (emails.length > 200) {
    return NextResponse.json({ error: "Max 200 addresses per batch" }, { status: 422 });
  }

  const invalid = emails.filter((e) => !EMAIL_RE.test(e));
  const valid = [...new Set(emails.filter((e) => EMAIL_RE.test(e)))];

  if (valid.length === 0) {
    return NextResponse.json({ error: "No valid email addresses", invalid }, { status: 422 });
  }

  try {
    /* resolve existing rows first (SQLite createMany has no skipDuplicates).
       round 35 — dedupe via blind indexes; emails sealed on insert. */
    const existing = await db.subscriber.findMany({
      where: { emailIndex: { in: valid.map((e) => blindIndex(e) ?? "").filter(Boolean) } },
      select: { emailIndex: true },
    });
    const existingSet = new Set(existing.map((row) => row.emailIndex));
    const fresh = valid.filter((email) => !existingSet.has(blindIndex(email) ?? ""));

    if (fresh.length > 0) {
      await db.subscriber.createMany({
        data: fresh.map((email) => ({
          email: encryptField(email) ?? "",
          emailIndex: blindIndex(email) ?? "",
          tag,
        })),
      });
    }

    const added = fresh.length;
    const skipped = valid.length - added;

    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "newsletter.add",
      targetLabel: `${added} subscriber(s)${tag ? ` · ${tag}` : ""}`,
      meta: { added: String(added), skipped: String(skipped), invalid: String(invalid.length), tag: tag ?? "" },
    });

    return NextResponse.json(
      { ok: true, added, skipped, invalid, tag, count: await db.subscriber.count() },
      { status: 201 }
    );
  } catch (error) {
    console.error("POST /api/admin/newsletter failed:", error);
    return NextResponse.json({ error: "Bulk insert failed" }, { status: 500 });
  }
}

/**
 * PATCH /api/admin/newsletter — row-level actions on one subscriber:
 * retag, edit the email address, and moderate the status
 * (ban / restrict / reactivate). Requires super/admin.
 */
export async function PATCH(req: Request) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const read = await readJson(req);
  if (!read.ok) return read.response;
  const body: unknown = read.data;

  /* ---------- round-27 bulk path (ids[]) ---------- */
  if (body && typeof body === "object" && "ids" in body && Array.isArray((body as { ids?: unknown }).ids)) {
    const bulk = bulkModerationSchema.safeParse(body);
    if (!bulk.success) {
      return NextResponse.json({ error: "ids[] and at least one of tag / status are required" }, { status: 400 });
    }
    const { ids, status } = bulk.data;
    const tag = bulk.data.tag !== undefined ? bulk.data.tag.trim() || null : undefined;

    try {
      const data: { status?: string; tag?: string | null } = {};
      if (status !== undefined) data.status = status;
      if (tag !== undefined) data.tag = tag;
      const result = await db.subscriber.updateMany({
        where: { id: { in: ids } },
        data,
      });
      await logAudit({
        actorType: "admin",
        actorId: guard.user.id,
        actorName: guard.user.username,
        action: "newsletter.update",
        targetLabel: `${result.count} subscriber(s)`,
        meta: {
          ...(status !== undefined ? { status, bulk: "true" } : {}),
          ...(tag !== undefined ? { tag: tag ?? "", bulk: "true" } : {}),
        },
      });
      return NextResponse.json({ ok: true, updated: result.count });
    } catch (error) {
      console.error("PATCH /api/admin/newsletter (bulk) failed:", error);
      return NextResponse.json({ error: "Bulk update failed" }, { status: 500 });
    }
  }

  /* ---------- single-row path (round 26) ---------- */
  const parsed = rowSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "id and at least one action field are required" }, { status: 400 });
  }

  const { id, email, status } = parsed.data;
  const tag = parsed.data.tag !== undefined ? parsed.data.tag.trim() || null : undefined;

  try {
    /* email edit — validate format + uniqueness via the blind index (round 35) */
    if (email !== undefined) {
      if (!EMAIL_RE.test(email)) {
        return NextResponse.json({ error: "Invalid email address" }, { status: 422 });
      }
      const clash = await db.subscriber.findFirst({
        where: { emailIndex: blindIndex(email) ?? undefined, id: { not: id } },
        select: { email: true },
      });
      if (clash) {
        return NextResponse.json({ error: "Email already exists" }, { status: 409 });
      }
    }

    const row = await db.subscriber.update({
      where: { id },
      data: {
        ...(tag !== undefined ? { tag } : {}),
        ...(email !== undefined
          ? { email: encryptField(email.toLowerCase()) ?? "", emailIndex: blindIndex(email) ?? "" }
          : {}),
        ...(status !== undefined ? { status } : {}),
      },
      select: { id: true, email: true, tag: true, status: true, createdAt: true, updatedAt: true },
    });

    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "newsletter.update",
      /* ROUND 37 — masked address in the trail, never the raw value */
      targetLabel: maskEmail(decryptField(row.email) ?? ""),
      meta: {
        ...(tag !== undefined ? { tag: tag ?? "" } : {}),
        ...(email !== undefined ? { email: "edited" } : {}),
        ...(status !== undefined ? { status } : {}),
      },
    });

    return NextResponse.json({
      ok: true,
      subscriber: {
        ...row,
        email: decryptField(row.email) ?? "",
        status: subscriberStatusRead.parse(row.status),
      },
    });
  } catch (error) {
    /* ROUND 36 — P2025 = row-not-found (the only legitimate 404); real
       faults (crypto/DB) surface as 500 with a server-side log instead of
       masking as "not found". */
    if ((error as { code?: string })?.code === "P2025") {
      return NextResponse.json({ error: "Subscriber not found" }, { status: 404 });
    }
    console.error("PATCH /api/admin/newsletter failed:", error);
    return NextResponse.json({ error: "Failed to update subscriber" }, { status: 500 });
  }
}

/**
 * DELETE /api/admin/newsletter — remove a subscriber by id (admin-guarded).
 */
export async function DELETE(req: Request) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const read = await readJson(req);
  if (!read.ok) return read.response;
  /* shape-checked below (Array.isArray / typeof) before any use */
  const body = read.data as { id?: unknown; ids?: unknown };

  /* ---------- round-27 bulk delete (ids[]) ---------- */
  if (Array.isArray(body.ids)) {
    const bulk = bulkDeleteSchema.safeParse(body);
    if (!bulk.success) {
      return NextResponse.json({ error: "ids[] (1..500) required" }, { status: 400 });
    }
    try {
      const result = await db.subscriber.deleteMany({ where: { id: { in: bulk.data.ids } } });
      await logAudit({
        actorType: "admin",
        actorId: guard.user.id,
        actorName: guard.user.username,
        action: "newsletter.update",
        targetLabel: `${result.count} subscriber(s) deleted`,
        meta: { bulk: "true", deleted: String(result.count) },
      });
      return NextResponse.json({ ok: true, removed: result.count, count: await db.subscriber.count() });
    } catch (error) {
      console.error("DELETE /api/admin/newsletter (bulk) failed:", error);
      return NextResponse.json({ error: "Bulk delete failed" }, { status: 500 });
    }
  }

  const id = typeof body.id === "string" ? body.id : "";
  if (!id) {
    return NextResponse.json({ error: "Subscriber id required" }, { status: 400 });
  }

  try {
    await db.subscriber.delete({ where: { id } });
    return NextResponse.json({ ok: true, count: await db.subscriber.count() });
  } catch (error) {
    if ((error as { code?: string })?.code === "P2025") {
      return NextResponse.json({ error: "Subscriber not found" }, { status: 404 });
    }
    console.error("DELETE /api/admin/newsletter failed:", error);
    return NextResponse.json({ error: "Failed to remove subscriber" }, { status: 500 });
  }
}
