import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/server/admin-session";

export const dynamic = "force-dynamic";

/**
 * ROUND 141 (Super-Admin notification upgrade, directive ㉝) — the
 * REAL-EVENT console feed, aggregated server-side in ONE call:
 *
 *   GET /api/admin/notifications
 *
 *   - PENDING plan orders (the activation queue: confirm to activate),
 *   - PENDING add-on orders (the feature-unlock queue),
 *   - PENDING wallet top-up requests (the credit queue),
 *   - OPEN support tickets (urgent first),
 *   - NEW subscribers (last 7 days).
 *
 * Every item carries the org/system identity + a stable id the console's
 * unread marker keys on. The bell polls this every 30 seconds — a real
 * operational queue, replacing the old client-side derivation from the
 * instances list.
 */

function orgNameOf(orgJson: string | null | undefined, fallback: string): string {
  try {
    const org = JSON.parse(orgJson ?? "{}") as { name?: unknown };
    if (typeof org.name === "string" && org.name.trim()) return org.name.trim();
  } catch {
    /* corrupt orgJson — fall back */
  }
  return fallback;
}

export async function GET(req: Request) {
  const guard = await requireAdmin(undefined, req);
  if (guard instanceof NextResponse) return guard;

  const now = Date.now();

  const [planOrders, addonOrders, topups, tickets, subscribers] = await Promise.all([
    db.planOrder.findMany({
      where: { status: "pending", expiresAt: { gt: new Date(now) } },
      orderBy: { createdAt: "desc" },
      take: 10,
      include: { instance: { select: { orgJson: true, systemId: true } }, package: { select: { nameAr: true, nameEn: true } } },
    }),
    db.addonOrder.findMany({
      where: { status: "pending", expiresAt: { gt: new Date(now) } },
      orderBy: { createdAt: "desc" },
      take: 10,
      include: { instance: { select: { orgJson: true, systemId: true } } },
    }),
    db.walletTopup.findMany({
      where: { status: "pending", expiresAt: { gt: new Date(now) } },
      orderBy: { createdAt: "desc" },
      take: 10,
      include: { instance: { select: { orgJson: true, systemId: true } } },
    }),
    db.supportTicket.findMany({
      where: { status: { in: ["open", "pending"] } },
      orderBy: [{ priority: "desc" }, { createdAt: "desc" }],
      take: 10,
      select: { id: true, subject: true, priority: true, status: true, createdAt: true, instanceId: true },
    }),
    db.instance.findMany({
      where: { createdAt: { gt: new Date(now - 7 * 24 * 60 * 60 * 1000) }, deletedAt: null },
      orderBy: { createdAt: "desc" },
      take: 8,
      select: { id: true, orgJson: true, systemId: true, createdAt: true },
    }),
  ]);

  const items = [
    ...planOrders.map((o) => ({
      id: `plan-${o.id}`,
      kind: "planOrder" as const,
      orgName: orgNameOf(o.instance?.orgJson, o.instance?.systemId ?? "—"),
      label: o.package?.nameAr ?? "",
      labelEn: o.package?.nameEn ?? "",
      amount: o.amount,
      currency: o.currency,
      reference: o.reference,
      createdAt: o.createdAt.toISOString(),
    })),
    ...addonOrders.map((o) => ({
      id: `addon-${o.id}`,
      kind: "addonOrder" as const,
      orgName: orgNameOf(o.instance?.orgJson, o.instance?.systemId ?? "—"),
      label: "",
      labelEn: "",
      amount: o.amount,
      currency: o.currency,
      reference: o.reference,
      createdAt: o.createdAt.toISOString(),
    })),
    ...topups.map((o) => ({
      id: `topup-${o.id}`,
      kind: "topup" as const,
      orgName: orgNameOf(o.instance?.orgJson, o.instance?.systemId ?? "—"),
      label: "",
      labelEn: "",
      amount: o.amountMinor / 100,
      currency: o.currency,
      reference: o.reference,
      createdAt: o.createdAt.toISOString(),
    })),
    ...tickets.map((tk) => ({
      id: `ticket-${tk.id}`,
      kind: "ticket" as const,
      orgName: tk.subject,
      label: tk.priority,
      labelEn: tk.priority,
      amount: null,
      currency: "",
      reference: "",
      createdAt: tk.createdAt.toISOString(),
    })),
    ...subscribers.map((inst) => ({
      id: `sub-${inst.id}`,
      kind: "subscriber" as const,
      orgName: orgNameOf(inst.orgJson, inst.systemId),
      label: inst.systemId,
      labelEn: inst.systemId,
      amount: null,
      currency: "",
      reference: "",
      createdAt: inst.createdAt.toISOString(),
    })),
  ].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  return NextResponse.json({
    items,
    counts: {
      planOrders: planOrders.length,
      addonOrders: addonOrders.length,
      topups: topups.length,
      tickets: tickets.length,
      subscribers: subscribers.length,
    },
    generatedAt: new Date().toISOString(),
  });
}
