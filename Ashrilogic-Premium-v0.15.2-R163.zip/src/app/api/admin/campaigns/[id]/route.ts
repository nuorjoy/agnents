import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { decryptField } from "@/lib/server/crypto-vault";
import { renderCampaignHtml, renderCampaignText, sendBulkMail } from "@/lib/server/mail";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

const editSchema = z.object({
  subject: z.string().trim().min(3).max(120),
  body: z.string().trim().min(10).max(5000),
});

const sendSchema = z.object({ action: z.literal("send") });

/** Read the platform's newsletter sending emails (labels for the snapshot). */
async function sendingAddresses(): Promise<string> {
  const row = await db.platformSetting.findUnique({ where: { id: "global" } });
  if (!row?.newsletterEmailsJson) return "";
  try {
    const list = JSON.parse(row.newsletterEmailsJson) as { email?: string }[];
    const emails = (Array.isArray(list) ? list : [])
      .map((e) => (typeof e.email === "string" ? e.email.trim() : ""))
      .filter((e) => e.length > 0);
    return emails.slice(0, 3).join(", ");
  } catch {
    return "";
  }
}

/**
 * PATCH /api/admin/campaigns/[id] — two guarded operations (super/admin):
 *  - { action: "send" }  : stamp the DRAFT as sent — recipients snapshots the
 *    active+restricted subscriber count, sentFrom snapshots the sending
 *    address(es), sentAt = now. Sent campaigns are immutable afterwards.
 *  - { subject, body }   : edit a DRAFT in place.
 * Returns 409 when the target is not a draft.
 */
export async function PATCH(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const existing = await db.newsletterCampaign.findUnique({ where: { id } });
  if (!existing) {
    return NextResponse.json({ error: "Campaign not found" }, { status: 404 });
  }

  /* ---- send ---- */
  const asSend = sendSchema.safeParse(body.data);
  if (asSend.success) {
    if (existing.status !== "draft") {
      return NextResponse.json({ error: "CAMPAIGN_ALREADY_SENT" }, { status: 409 });
    }
    try {
      /* Claim the draft FIRST (conditional update) — only one concurrent
       * send can ever transition the row; the loser gets a clean 409.
       * Delivery runs AFTER the claim so a crashed dispatch leaves an
       * honest sent-row with per-recipient results in the audit trail
       * instead of a half-sent "draft" that could be re-blasted. */
      const [recipients, sentFrom] = await Promise.all([
        db.subscriber.count({ where: { status: { in: ["active", "restricted"] } } }),
        sendingAddresses(),
      ]);
      const claimed = await db.newsletterCampaign.updateMany({
        where: { id, status: "draft" },
        data: { status: "sent", recipients, sentFrom: sentFrom || null, sentAt: new Date() },
      });
      if (claimed.count === 0) {
        return NextResponse.json({ error: "CAMPAIGN_ALREADY_SENT" }, { status: 409 });
      }

      /* REAL delivery: every active/restricted subscriber receives the
       * message through the platform mailer (SMTP when provisioned, dev
       * spool otherwise). Sealed addresses are decrypted in-process and
       * never persisted anywhere in delivery form. */
      const subscriberRows = await db.subscriber.findMany({
        where: { status: { in: ["active", "restricted"] } },
        select: { email: true },
        take: 5000,
      });
      const toList = subscriberRows
        .map((row) => decryptField(row.email)?.trim().toLowerCase() ?? "")
        .filter((addr) => addr.length > 3 && addr.includes("@"));
      const dispatch = await sendBulkMail(
        toList,
        {
          subject: existing.subject,
          text: renderCampaignText(existing.subject, existing.body),
          html: renderCampaignHtml(existing.subject, existing.body),
        },
        { type: "campaign" }
      );

      const row = await db.newsletterCampaign.findUniqueOrThrow({ where: { id } });
      await logAudit({
        actorType: "admin",
        actorId: guard.user.id,
        actorName: guard.user.username,
        action: "campaign.send",
        targetLabel: existing.subject.slice(0, 60),
        meta: {
          recipients: String(recipients),
          delivered: String(dispatch.accepted),
          ...(dispatch.rejected > 0 ? { failed: String(dispatch.rejected) } : {}),
          from: sentFrom || "default",
        },
      });
      if (dispatch.rejected > 0) {
        console.error(
          `campaign "${existing.subject.slice(0, 60)}": ${dispatch.rejected}/${toList.length} deliveries failed`
        );
      }
      return NextResponse.json({
        id: row.id,
        subject: row.subject,
        body: row.body,
        status: row.status,
        recipients: row.recipients,
        sentFrom: row.sentFrom,
        sentAt: row.sentAt ? row.sentAt.toISOString() : null,
        createdAt: row.createdAt.toISOString(),
        updatedAt: row.updatedAt.toISOString(),
      });
    } catch (error) {
      console.error(`PATCH /api/admin/campaigns/${id} (send) failed:`, error);
      return NextResponse.json({ error: "Failed to send campaign" }, { status: 500 });
    }
  }

  /* ---- edit draft ---- */
  const asEdit = editSchema.safeParse(body.data);
  if (!asEdit.success) {
    return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
  }
  if (existing.status !== "draft") {
    return NextResponse.json({ error: "CAMPAIGN_ALREADY_SENT" }, { status: 409 });
  }

  try {
    const row = await db.newsletterCampaign.update({
      where: { id },
      data: { subject: asEdit.data.subject, body: asEdit.data.body },
    });
    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "campaign.update",
      targetLabel: asEdit.data.subject.slice(0, 60),
      meta: { subject: "updated" },
    });
    return NextResponse.json({
      id: row.id,
      subject: row.subject,
      body: row.body,
      status: row.status,
      recipients: row.recipients,
      sentFrom: row.sentFrom,
      sentAt: row.sentAt ? row.sentAt.toISOString() : null,
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
    });
  } catch (error) {
    console.error(`PATCH /api/admin/campaigns/${id} failed:`, error);
    return NextResponse.json({ error: "Failed to update campaign" }, { status: 500 });
  }
}

/**
 * DELETE /api/admin/campaigns/[id] — remove a draft or an archived sent
 * record (super/admin only; audited).
 */
export async function DELETE(_req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireAdmin(["super", "admin"], _req);
  if (guard instanceof NextResponse) return guard;

  const existing = await db.newsletterCampaign.findUnique({ where: { id } });
  if (!existing) {
    return NextResponse.json({ error: "Campaign not found" }, { status: 404 });
  }

  try {
    await db.newsletterCampaign.delete({ where: { id } });
    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "campaign.delete",
      targetLabel: existing.subject.slice(0, 60),
      meta: { status: existing.status, recipients: String(existing.recipients) },
    });
    return new NextResponse(null, { status: 204 });
  } catch (error) {
    console.error(`DELETE /api/admin/campaigns/${id} failed:`, error);
    return NextResponse.json({ error: "Failed to delete campaign" }, { status: 500 });
  }
}
