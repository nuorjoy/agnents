import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";

export const dynamic = "force-dynamic";

/** Round 33 — campaign composer payload (strict write). */
export const campaignDraftSchema = z.object({
  subject: z.string().trim().min(3).max(120),
  body: z.string().trim().min(10).max(5000),
});

function zodFirst(error: z.ZodError): string {
  const issue = error.issues[0];
  return issue ? `${issue.path.join(".") || "body"}: ${issue.message}` : "Invalid payload";
}

/** Serialized campaign row (client DTO). */
function toCampaignDTO(row: {
  id: string;
  subject: string;
  body: string;
  status: string;
  recipients: number;
  sentFrom: string | null;
  sentAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}) {
  return {
    id: row.id,
    subject: row.subject,
    body: row.body,
    status: row.status,
    recipients: row.recipients,
    sentFrom: row.sentFrom,
    sentAt: row.sentAt ? row.sentAt.toISOString() : null,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

/**
 * GET /api/admin/campaigns — the campaign archive (latest first, capped at
 * 50). Any authenticated admin can read.
 */
export async function GET() {
  const guard = await requireAdmin();
  if (guard instanceof NextResponse) return guard;

  try {
    /* round 36 — parallel reads (was sequential) */
    const [rows, audience] = await Promise.all([
      db.newsletterCampaign.findMany({
        orderBy: { createdAt: "desc" },
        take: 50,
      }),
      /* audience estimate for drafts: active + restricted subscribers */
      db.subscriber.count({
        where: { status: { in: ["active", "restricted"] } },
      }),
    ]);

    return NextResponse.json({
      campaigns: rows.map(toCampaignDTO),
      audience,
    });
  } catch (error) {
    console.error("GET /api/admin/campaigns failed:", error);
    return NextResponse.json({ error: "Failed to load campaigns" }, { status: 500 });
  }
}

/**
 * POST /api/admin/campaigns — create a DRAFT (super/admin only). Drafts are
 * reviewed in the composer before sending; the create action is audited.
 */
export async function POST(req: Request) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = campaignDraftSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodFirst(parsed.error) }, { status: 400 });
  }

  try {
    const row = await db.newsletterCampaign.create({ data: { ...parsed.data } });
    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "campaign.create",
      targetLabel: parsed.data.subject.slice(0, 60),
      meta: { subject: "created" },
    });
    return NextResponse.json(toCampaignDTO(row), { status: 201 });
  } catch (error) {
    console.error("POST /api/admin/campaigns failed:", error);
    return NextResponse.json({ error: "Failed to create campaign" }, { status: 500 });
  }
}
