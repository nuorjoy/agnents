import { publicList } from "@/server/domains/packages/controller";

export const dynamic = "force-dynamic";

/**
 * GET /api/packages — public pricing feed for the landing section.
 * Returns ACTIVE plans only, ordered by sortOrder. Seeds the three default
 * plans (and backfills English feature bullets) on first read — idempotent.
 *
 * ROUND 124 — the handler moved to the packages domain
 * (src/server/domains/packages): this file is the thin route delegation.
 */
export const GET = publicList;
