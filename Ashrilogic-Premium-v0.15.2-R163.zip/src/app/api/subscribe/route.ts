import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { blindIndex, decryptField, encryptField } from "@/lib/server/crypto-vault";
import { requireAdmin } from "@/lib/server/admin-session";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { originViolation } from "@/lib/server/origin-guard";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";

/**
 * Ashrilogic — newsletter subscribe endpoint.
 *
 * Persists subscribers to the `Subscriber` table (Prisma/SQLite). Validates
 * the email server-side, deduplicates via the keyed blind index (round 35 —
 * the email itself is sealed with AES-256-GCM at rest), and returns a
 * localized success message. No PII beyond the email is stored.
 *
 * ROUND 36 (security):
 *  - POST is rate-limited per IP (public form abuse / list flooding)
 *  - GET + DELETE now REQUIRE an authenticated admin (they expose decrypted
 *    subscriber emails / destroy rows — formerly unauthenticated!)
 *  - internal error details are never returned to the client
 */
/**
 * Server-side email shape — stricter than the client-side UX gate
 * (lib/validation.ts): the local part is limited to RFC 5322 "atext"
 * characters so hostile payloads (HTML/script fragments) can never enter
 * the sealed store even when every downstream renderer escapes them.
 * The weak `[^\s@]+` copy previously accepted `<script>…</script>@x.com`.
 */
const EMAIL_RE = /^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?)+$/;
const SUBSCRIBE_RULE = { limit: 5, windowMs: 10 * 60 * 1000 };

export async function POST(req: Request) {
  const violation = originViolation(req);
  if (violation) return violation;

  /* ROUND 49 — the IP rule runs BEFORE the bounded body read so anonymous
     scanners cannot burn capped JSON parses (invalid payloads used to bypass
     the limit entirely). */
  if (await rateLimited(`subscribe:${clientIp(req)}`, SUBSCRIBE_RULE)) {
    return tooManyRequests(SUBSCRIBE_RULE, { error: "Too many subscribe attempts, please try again later" });
  }

  /* ROUND 37 (task 3-a) — bounded body read in place of the unbounded
     req.json(). */
  const body = await readJson(req);
  if (!body.ok) return body.response;

  const rawEmail = (body.data as { email?: unknown }).email;
  const email = typeof rawEmail === "string" ? rawEmail.trim().toLowerCase() : "";

  if (!email || !EMAIL_RE.test(email) || email.length > 254) {
    return NextResponse.json({ error: "Invalid email address" }, { status: 400 });
  }

  try {
    /* round 35 — upsert keyed on the blind index; the email column holds a
       sealed AES-256-GCM envelope */
    const result = await db.subscriber.upsert({
      where: { emailIndex: blindIndex(email) ?? "" },
      update: {},
      create: { email: encryptField(email) ?? "", emailIndex: blindIndex(email) ?? "" },
      select: { id: true, createdAt: true },
    });

    // if createdAt is within the last 2 seconds, it's a new subscriber
    const isNew = Date.now() - result.createdAt.getTime() < 2000;

    /* ROUND 37 (task 3-a) — new subscriptions land in the (business) audit
        trail with a MASKED address — the submitter email is PII and never
        reaches the log in plaintext. */
    if (isNew) {
      await logAudit({
        actorType: "public",
        actorId: result.id,
        actorName: maskEmail(email),
        action: "newsletter.add",
      });
    }

    return NextResponse.json(
      {
        ok: true,
        message: isNew ? "Subscribed successfully" : "Already subscribed",
      },
      { status: isNew ? 201 : 200 }
    );
  } catch (error) {
    console.error("POST /api/subscribe failed:", error);
    return NextResponse.json({ error: "Subscription failed" }, { status: 500 });
  }
}

/**
 * GET — returns the subscriber count + the 10 most recent.
 * ROUND 36: admin-only (PII-bearing read — formerly public).
 * Moderators get the same masked view policy applied elsewhere in the
 * console (e.g. subscribers sheet): decrypted addresses are a super/admin
 * need-to-know; the moderator surface shows the mask only.
 */
export async function GET() {
  const guard = await requireAdmin(["super", "admin", "moderator"]);
  if (guard instanceof NextResponse) return guard;

  try {
    const count = await db.subscriber.count();
    const recent = await db.subscriber.findMany({
      orderBy: { createdAt: "desc" },
      take: 10,
      select: { id: true, email: true, createdAt: true },
    });
    const unseal = guard.user.role === "super" || guard.user.role === "admin";
    return NextResponse.json({
      count,
      /* round 35 — sealed column decrypted (or masked) for the response */
      recent: recent.map((r) => ({
        ...r,
        email: unseal ? decryptField(r.email) ?? "" : maskEmail(decryptField(r.email) ?? ""),
      })),
    });
  } catch (error) {
    console.error("GET /api/subscribe failed:", error);
    /* ROUND 49 — fail honestly: a storage outage is a 500, not a silent
       empty list the panel would render as "no subscribers". */
    return NextResponse.json({ error: "Failed to load subscribers" }, { status: 500 });
  }
}

/**
 * DELETE — removes a subscriber by id.
 * ROUND 36: admin-only destructive action (formerly unauthenticated!).
 */
export async function DELETE(req: Request) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const payload = (body.data ?? {}) as { id?: unknown };
  const id = typeof payload.id === "string" ? payload.id : "";
  if (!id || id.length > 64) {
    return NextResponse.json({ error: "Subscriber id required" }, { status: 400 });
  }

  try {
    await db.subscriber.delete({ where: { id } });
    return NextResponse.json({ ok: true, count: await db.subscriber.count() });
  } catch (error) {
    const code = (error as { code?: string })?.code;
    if (code === "P2025") {
      return NextResponse.json({ error: "Subscriber not found" }, { status: 404 });
    }
    console.error("DELETE /api/subscribe failed:", error);
    return NextResponse.json({ error: "Failed to remove subscriber" }, { status: 500 });
  }
}
