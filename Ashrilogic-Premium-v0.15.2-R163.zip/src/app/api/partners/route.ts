import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toSectorPartnerDTO } from "@/lib/server/blog-mapper";

export const dynamic = "force-dynamic";

/**
 * GET /api/partners — the curated TRUSTED-SECTOR marquee feed (public).
 *
 * Every row maps to a REAL registered workspace: the join back to Instance
 * guarantees authenticity AND freshness — a trashed (soft-deleted) workspace
 * silently drops out of the showcase, and the display name falls back to the
 * LIVE org name whenever the console override is empty.
 *
 *  - only `visible` rows, ordered by the console's sortOrder;
 *  - `since` carries the workspace's real registration date (the
 *    «عميل منذ YYYY» chip on the marquee card);
 *  - fail-open: any error answers an empty list (the landing strip then falls
 *    back to its static placeholder set — never a broken section).
 */
export async function GET() {
  try {
    const rows = await db.sectorPartner.findMany({
      where: { visible: true },
      orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
      include: {
        instance: {
          select: { id: true, orgJson: true, createdAt: true, deletedAt: true },
        },
      },
    });

    const partners = rows
      /* the join is the truth: soft-deleted workspaces never showcase */
      .filter((row) => row.instance !== null && row.instance.deletedAt === null)
      .map((row) =>
        toSectorPartnerDTO(
          row,
          /* live org name (display override applied inside the mapper) */
          (() => {
            try {
              const org = JSON.parse(row.instance.orgJson ?? "{}") as { name?: unknown };
              return typeof org.name === "string" ? org.name.trim() : "";
            } catch {
              return "";
            }
          })(),
          row.instance.createdAt
        )
      );

    return NextResponse.json({ partners });
  } catch (error) {
    console.error("GET /api/partners failed:", error);
    return NextResponse.json({ partners: [] }, { status: 200 });
  }
}
