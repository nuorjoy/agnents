import { NextResponse } from "next/server";
import { db } from "@/lib/db";

/**
 * Ashrilogic — platform liveness probe.
 *
 * Public and anonymous, so it leaks NOTHING about the business: no tenant
 * counts, no activity volumes (a provisioned-instance count is a revenue
 * proxy — competitor recon material), and no fabricated uptime number.
 * "operational" means exactly one thing: the app process is serving and the
 * database answered a trivial query within the timeout. Uptime percentages
 * belong to a real metrics store, not a deterministic date-seeded constant.
 *
 * ROUND 120 — the DB probe is BOUNDED (the healthz 2s-alarm pattern): the
 * pre-120 unbounded `await db.imageAsset.findFirst` hung the whole route
 * indefinitely on a wedged/exhausted pool (an unauthenticated prober must
 * never hold a connection slot hostage past its own deadline).
 */
export const dynamic = "force-dynamic";

/** probe deadline — matches healthz (DB_ALARM_MS) */
const PROBE_ALARM_MS = 2_000;

/** bounded DB ping: resolves true/false, never hangs */
function dbPing(): Promise<boolean> {
  return new Promise<boolean>((resolve) => {
    const timer = setTimeout(() => resolve(false), PROBE_ALARM_MS);
    timer.unref?.();
    db.imageAsset
      .findFirst({ select: { id: true } })
      .then(
        () => {
          clearTimeout(timer);
          resolve(true);
        },
        () => {
          clearTimeout(timer);
          resolve(false);
        }
      );
  });
}

export async function GET() {
  const started = Date.now();

  try {
    const dbOk = await dbPing();
    if (!dbOk) {
      /* the probe deadline fired (or the query failed): report degraded
       * instead of hanging the prober or pretending health */
      return NextResponse.json(
        {
          status: "degraded",
          dbResponseMs: Date.now() - started,
          checkedAt: new Date().toISOString(),
        },
        { status: 503, headers: { "Cache-Control": "no-store" } }
      );
    }
    /* migration readiness (SQLite → PostgreSQL) — phase + lag only, zero
       business data; a steady-state deployment reports SQLITE_ONLY */
    let migration: { state: string; pendingEvents: number; failedReplays: number } | null =
      null;
    try {
      const { getMigrationStatus } = await import("@/lib/server/migration/controller");
      const status = await getMigrationStatus();
      migration = {
        state: status.state,
        pendingEvents: status.pendingEvents,
        failedReplays: status.failedReplays,
      };
    } catch {
      /* infra tables absent (pre-migration schema) — not part of liveness */
    }
    /* platform snapshot health (ROUND 104) — read-only verification of the
       NEWEST platform backup, cached in-process (10-min TTL). Public-safe:
       verdict + snapshot name + age + CODE-only issues — no paths, no
       business data. Never fatal: a verification failure degrades the
       `backup` field, not the whole liveness probe. */
    let backup: { ok: boolean; snapshot: string | null; ageHours: number | null; issues: string[] } | null =
      null;
    try {
      const { verifyLatestSnapshotHealth } = await import("@/lib/server/snapshot-health");
      const health = await verifyLatestSnapshotHealth();
      backup = {
        ok: health.ok,
        snapshot: health.snapshot,
        ageHours: health.ageHours,
        issues: health.issues,
      };
    } catch {
      /* storage unavailable mid-poll — omit the field, keep liveness clean */
    }
    return NextResponse.json(
      {
        status: "operational",
        dbResponseMs: Date.now() - started,
        checkedAt: new Date().toISOString(),
        ...(migration ? { migration } : {}),
        ...(backup ? { backup } : {}),
      },
      {
        headers: {
          "Cache-Control": "public, s-maxage=30, stale-while-revalidate=60",
        },
      }
    );
  } catch {
    return NextResponse.json(
      {
        status: "degraded",
        dbResponseMs: Date.now() - started,
        checkedAt: new Date().toISOString(),
      },
      { status: 503 }
    );
  }
}
