import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { SYSTEM_MAP, systemMods } from "@/data/catalog";
import {
  createInstanceSchema,
  toInstanceDTO,
  toSanitizedInstanceDTO,
  zodError,
  sealAdminSection,
  readAdminEmail,
  normalizeEmail,
} from "@/lib/server/instance-mapper";
import { seedDemoInstances, seedAdminDefaults } from "@/lib/server/admin-mapper";
import { hashPassword } from "@/lib/server/admin-session";
import { setInstanceSession, resolveInstanceSession } from "@/lib/server/instance-session";
import { getSessionUser } from "@/lib/server/admin-session";
import { logAudit, maskEmail } from "@/lib/server/audit";
import {clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { originViolation } from "@/lib/server/origin-guard";
import { blindIndex } from "@/lib/server/crypto-vault";
import { readJson } from "@/lib/server/http";
import { freshTrialEndsAt, TRIAL_DAYS } from "@/lib/server/entitlement";
import { notifyEvent } from "@/lib/server/platform-notifications";
import {
  deepCheckTenantIdentity,
  normalizePhoneDeep,
  TENANT_EMAIL_USED,
  TENANT_PHONE_USED,
} from "@/lib/server/tenant-uniqueness";

export const dynamic = "force-dynamic";

/** Provisioning throttling: 3 workspaces per hour per IP (+ per-email rule). */
const CREATE_IP_RULE = { limit: 3, windowMs: 60 * 60 * 1000 };
const CREATE_EMAIL_RULE = { limit: 2, windowMs: 60 * 60 * 1000 };
/** Maximum instances returned in one listing (admin surface included). */
const LIST_CAP = 500;

/**
 * GET /api/instances — AUTHENTICATION-AWARE directory (round 36 security).
 *
 *  - anonymous  → minimal PUBLIC projection (showcase cards only: id,
 *                 systemId, org name, site summary) of NON-DEMO instances.
 *                 The former full-DTO public listing leaked every
 *                 subscriber's admin identity, contact channels and
 *                 activity trail to anyone — closed.
 *  - admin      → full DTOs for every instance (panel role, incl. viewer —
 *                 read-only by design, PII-bearing reads are separately
 *                 gated per route).
 *  - workspace  → full DTOs of the signed-in owner's own workspaces only.
 *
 * Also seeds the backdated demo subscribers (idempotent, once-guarded per
 * process) so a fresh database starts with a populated panel.
 */
export async function GET() {
  try {
    await seedDemoInstances(db);

    const admin = await getSessionUser();
    if (admin) {
      /* ROUND 87 — trashed (soft-deleted) workspaces vanish from the admin
       * panel listing too (they live in the trash engine's own surface).
       * ROUND 145 (perf) — the per-row activities include is take: 3 (was
       * 8): no admin listing consumer renders the activity list at all, and
       * the DTO's `activities[0]` (newest) is the only field any surface
       * reads — 500 rows × 8 eagerly-loaded activity rows was pure payload. */
      const rows = await db.instance.findMany({
        where: { deletedAt: null },
        orderBy: [{ createdAt: "desc" }, { id: "desc" }],
        take: LIST_CAP,
        include: {
          activities: { orderBy: [{ createdAt: "desc" }, { id: "desc" }], take: 3 },
          package: true,
          site: { select: { published: true, theme: true, views: true, contentJson: true } },
        },
      });
      const dtos = rows.map(toInstanceDTO);
      /* ROUND 37 — PII minimization for low-privilege panel roles: viewer and
         moderator sessions no longer receive the decrypted workspace login
         email — maskEmail keeps the first character + domain for correlation.
         Org name/industry data is business info and stays. super/admin keep
         the full DTOs (they manage credentials). Response shape unchanged. */
      const visible =
        admin.role === "viewer" || admin.role === "moderator"
          ? dtos.map((dto) => ({
              ...dto,
              admin: { ...dto.admin, email: maskEmail(dto.admin.email) },
            }))
          : dtos;
      return NextResponse.json(visible);
    }

    /* signed-in workspace owner → their own workspaces (full DTOs).
       Round 49: full session resolution (jti registry + epoch) — a revoked
       or stale token falls through to the anonymous showcase projection
       exactly like an absent cookie. */
    const sessionState = await resolveInstanceSession();
    if (sessionState.status === "valid") {
      const sessionId = sessionState.instanceId;
      const session = await db.instance.findUnique({
        where: { id: sessionId, deletedAt: null },
        select: { adminEmailIndex: true, adminJson: true },
      });
      let emailIndex = session?.adminEmailIndex ?? null;
      if (!emailIndex) {
        /* legacy row — derive + persist the index now */
        const email = normalizeEmail(readAdminEmail(session?.adminJson));
        emailIndex = email ? (blindIndex(email) ?? "") : null;
        if (emailIndex) {
          await db.instance.update({ where: { id: sessionId }, data: { adminEmailIndex: emailIndex } });
        }
      }
      if (emailIndex) {
        /* ROUND 87 — a trashed workspace never appears in the owner's own
         * "mine" listing. */
        const rows = await db.instance.findMany({
          where: { adminEmailIndex: emailIndex, deletedAt: null },
          orderBy: [{ createdAt: "desc" }, { id: "desc" }],
          take: LIST_CAP,
          include: {
            activities: { orderBy: [{ createdAt: "desc" }, { id: "desc" }], take: 8 },
            package: true,
            site: { select: { published: true, theme: true, views: true, contentJson: true } },
          },
        });
        return NextResponse.json(rows.map(toInstanceDTO));
      }
    }

    /* anonymous showcase directory — sanitized projection, demo rows hidden.
       ROUND 87 — trashed (soft-deleted) workspaces never showcase. */
    const rows = await db.instance.findMany({
      where: { demo: false, deletedAt: null },
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: 60,
      select: {
        id: true,
        systemId: true,
        orgJson: true,
        modulesJson: true,
        demo: true,
        createdAt: true,
        site: { select: { published: true, theme: true, views: true, contentJson: true } },
      },
    });
    return NextResponse.json(rows.map(toSanitizedInstanceDTO));
  } catch (error) {
    console.error("GET /api/instances failed:", error);
    return NextResponse.json({ error: "Failed to list instances" }, { status: 500 });
  }
}

/**
 * POST /api/instances — provision a new system instance (wizard submit).
 * Round 36 hardening:
 *  - allowSignup platform setting is actually enforced (403 when closed)
 *  - rate-limited per IP AND per admin email (provisioning is expensive —
 *    Argon2id + activity seeding + auto sign-in)
 *  - module ids are validated against the system's catalog (allowlist)
 *  - request bodies are size-guarded by the Zod string/array caps
 * ROUND 134-E — deep tenant identity uniqueness (owner directive): a
 *  FRESH signup must prove BOTH the login email and the org phone were
 *  never used before — across live, soft-deleted AND demo rows (see
 *  src/lib/server/tenant-uniqueness.ts). The ROUND-82 owner-account
 *  reuse flow (a signed-in owner adding another system to the SAME
 *  verified email) stays exempt, preserving its exact prior behavior.
 */
export async function POST(req: Request) {
  const violation = originViolation(req);
  if (violation) return violation;

  /* ROUND 49 — the IP rule runs BEFORE the bounded body read + zod parse
     (provisioning is the most expensive public endpoint); the per-email
     rule stays after parsing because it needs the blind-indexed address. */
  const ip = clientIp(req);
  if (await rateLimited(`inst-create-ip:${ip}`, CREATE_IP_RULE, { failClosed: true })) {
    return tooManyRequests(CREATE_IP_RULE, { error: "Too many systems created from this network — try again later" });
  }

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = createInstanceSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const data = parsed.data;

  if (await rateLimited(`inst-create-email:${blindIndex(data.admin.email) ?? ""}`, CREATE_EMAIL_RULE, { failClosed: true })) {
    return tooManyRequests(CREATE_EMAIL_RULE, { error: "Too many systems created with this email — try again later" });
  }

  const system = SYSTEM_MAP[data.systemId];
  if (!system) {
    return NextResponse.json({ error: `Unknown system: ${data.systemId}` }, { status: 404 });
  }

  /* module allowlist — reject ids outside the chosen system's catalog */
  const catalogModuleIds = new Set(systemMods(system));
  const unknownModule = data.modules.find((moduleId) => !catalogModuleIds.has(moduleId));
  if (unknownModule) {
    return NextResponse.json(
      { error: `Unknown module for this system: ${unknownModule}` },
      { status: 400 }
    );
  }

  try {
    /* platform signup gate (admin settings — enforced server-side) */
    await seedAdminDefaults(db);
    const settings = await db.platformSetting.findUnique({ where: { id: "global" } });
    if (settings && !settings.allowSignup) {
      return NextResponse.json(
        { error: "Public sign-up is currently closed by the platform" },
        { status: 403 }
      );
    }

    /* ROUND 134-E — DEEP identity uniqueness (email + phone, never used
     * before — including soft-deleted and demo rows).
     *
     * Reuse-flow exemption, ROUND 82: a signed-in owner provisioning
     * ANOTHER system on their own login email (password already verified
     * server-side by /api/instances/mine/verify-password) is EXEMPT from
     * both checks — one account across systems is the documented design.
     * The exemption is derived from the SERVER-VERIFIED session + blind
     * index match, never from a client-claimed flag: createInstanceSchema
     * strips unknown keys, so a body-crafted `ownerVerified: true` cannot
     * bypass anything. A trashed owner workspace cannot exempt either
     * (deletedAt check below). NEITHER check applies to that flow —
     * today's behavior preserved exactly. */
    const sessionState = await resolveInstanceSession();
    let ownerReuse = false;
    if (sessionState.status === "valid") {
      const ownerRow = await db.instance.findUnique({
        where: { id: sessionState.instanceId },
        select: { adminEmailIndex: true, adminJson: true, deletedAt: true },
      });
      if (ownerRow && !ownerRow.deletedAt) {
        const candidateIndex = blindIndex(normalizeEmail(data.admin.email)) ?? "";
        ownerReuse = ownerRow.adminEmailIndex
          ? ownerRow.adminEmailIndex === candidateIndex
          : normalizeEmail(readAdminEmail(ownerRow.adminJson)) === normalizeEmail(data.admin.email);
      }
    }
    if (!ownerReuse) {
      const collisions = await deepCheckTenantIdentity(db, {
        email: data.admin.email,
        phone: data.org.phone,
      });
      const emailClash = collisions.emailUsedBy !== null;
      if (emailClash || collisions.phoneUsedBy !== null) {
        /* security trail — the actor is the anonymous signup attempt; the
         * meta carries ONLY masked forms (maskEmail + the last 4 phone
         * digits) plus the colliding instance ID for correlation. The
         * client NEVER receives the raw email/phone or the colliding row.
         * (ROUND 134 principal integration: "instance.duplicateBlock" is
         * now a FIRST-CLASS AuditAction — registered in AUDIT_ACTIONS with
         * console ACTION_META + AR/EN/HI labels — no cast needed.) */
        await logAudit({
          actorType: "public",
          actorName: "signup",
          action: "instance.duplicateBlock",
          targetLabel: emailClash ? "signup-email" : "signup-phone",
          meta: {
            email: maskEmail(normalizeEmail(data.admin.email)),
            phone: `***${normalizePhoneDeep(data.org.phone).slice(-4)}`,
            collidesWith: emailClash
              ? String(collisions.emailUsedBy)
              : String(collisions.phoneUsedBy),
          },
        });
        return NextResponse.json(
          emailClash
            ? {
                error: "This email is already registered in the platform",
                code: TENANT_EMAIL_USED,
              }
            : {
                error: "This phone number is already registered in the platform",
                code: TENANT_PHONE_USED,
              },
          { status: 409 }
        );
      }
    }

    /* ROUND 47 — the FREE TRIAL replaces birth-time plan assignment: every
       new system now runs FULL-FEATURED for TRIAL_DAYS (7) days with no
       package, then locks to billing-only until a plan is activated (see
       entitlement.ts). The module selection is still bounded by the chosen
       system's catalog (allowlist above) — the trial window is generous by
       design so tenants experience the whole product. */

    // Monotonic timestamps keep the seeded trail ordering deterministic even
    // when all four rows land within the same millisecond.
    const base = Date.now();
    const email = normalizeEmail(data.admin.email);
    const sealed = sealAdminSection({
      name: data.admin.name,
      email,
      role: data.admin.role,
      twoFA: data.admin.twoFA,
    });
    const row = await db.instance.create({
      data: {
        systemId: data.systemId,
        orgJson: JSON.stringify(data.org),
        /* sealed login email + blind index (see instance-mapper.ts) */
        adminJson: sealed.adminJson,
        adminEmailIndex: sealed.adminEmailIndex,
        prefsJson: JSON.stringify(data.prefs),
        modulesJson: JSON.stringify(data.modules),
        /* ROUND 47 — free trial window: no package until the tenant activates
           one from the subscription page after (or during) the trial. */
        packageId: null,
        trialEndsAt: freshTrialEndsAt(new Date(base)),
        passwordHash: hashPassword(data.admin.password),
        activities: {
          create: [
            { kind: "actCreated", metaJson: JSON.stringify({ system: data.systemId, trial: String(TRIAL_DAYS) }), createdAt: new Date(base) },
            { kind: "actLogin", createdAt: new Date(base + 1) },
            {
              kind: "actModuleEnabled",
              metaJson: JSON.stringify({ count: String(data.modules.length) }),
              createdAt: new Date(base + 2),
            },
            { kind: "actBackup", createdAt: new Date(base + 3) },
          ],
        },
      },
      include: {
        activities: { orderBy: [{ createdAt: "desc" }, { id: "desc" }], take: 8 },
      },
    });
    // The provisioning owner is signed into the new workspace immediately.
    await setInstanceSession(row.id, row.sessionVersion ?? 0);
    await logAudit({
      actorType: "instance",
      actorId: row.id,
      actorName: maskEmail(email),
      action: "instance.create",
      targetLabel: data.org.name || data.systemId,
      meta: { system: data.systemId, modules: String(data.modules.length), trial: String(TRIAL_DAYS) },
    });
    /* ROUND 89 — the «إشعارات البريد» toggle's first event: a NEW
     * SUBSCRIBER just provisioned a system. Fire-and-safe: a notification
     * failure must never fail the provisioning that already succeeded. */
    void notifyEvent({
      eventKey: "instance.created",
      title: "مشترك جديد أنشأ نظاماً",
      body: `أنشأ «${data.org.name || data.systemId}» نظام ${SYSTEM_MAP[data.systemId]?.nameAr ?? data.systemId} (${data.modules.length} وحدة) — فترة تجريبية ${TRIAL_DAYS} أيام.`,
      meta: { org: data.org.name || data.systemId, system: data.systemId, modules: data.modules.length },
    }).catch(() => undefined);
    return NextResponse.json(toInstanceDTO(row), { status: 201 });
  } catch (error) {
    console.error("POST /api/instances failed:", error);
    return NextResponse.json({ error: "Failed to create instance" }, { status: 500 });
  }
}
