import { NextResponse } from "next/server";
import { readAdminEmail, zodError } from "@/lib/server/instance-mapper";
import { requireInstanceAccess } from "@/lib/server/instance-session";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import {rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { z } from "zod";
import type { RegistrationResponseJSON } from "@simplewebauthn/server";
import {
  crossDeviceQrSvg,
  finishPasskeyRegistration,
  listCredentials,
  startPasskeyRegistration,
} from "@/lib/server/webauthn";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/** Registration throttling: 8 attempts / 10 min per workspace. */
const REG_RULE = { limit: 8, windowMs: 10 * 60 * 1000 };

const finishSchema = z.object({
  name: z.string().trim().min(1).max(60),
  response: z.unknown(),
});

/**
 * ROUND 45 — workspace passkey management (tenant settings security card).
 *
 * GET  — the workspace's passkeys (metadata only — key material NEVER
 *        leaves the server).
 * POST — registration STEP 1 (fresh creation options).
 * PUT  — registration STEP 2: { name, response } — attestation verified
 *        against the stored challenge; only the public key + counter are
 *        persisted.
 *
 * Passkeys authenticate the WORKSPACE account (the owner email + password
 * gate) — the guard accepts the workspace session or a managing admin.
 */
export async function GET(_req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, undefined, { permission: "settings.manage" });
  if (guard instanceof NextResponse) return guard;
  return NextResponse.json({ credentials: await listCredentials("instance", id) });
}

export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "settings.manage" });
  if (guard instanceof NextResponse) return guard;

  if (await rateLimited(`inst-passkey-reg:${id}`, REG_RULE, { failClosed: true })) {
    return tooManyRequests(REG_RULE, { error: "Too many attempts — try again later" });
  }

  /* ROUND 46 — optional cross-device QR (validated same-origin, violet).
   * Bounded read (4 KB cap): the registration body is tiny, so an oversized
   * payload is abuse, not input — same policy as every other mutation. */
  let returnTo: string | undefined;
  const body = await readJson(req, 4_000);
  const raw = body.ok ? (body.data as { returnTo?: unknown } | undefined) : undefined;
  if (typeof raw?.returnTo === "string") {
    returnTo = raw.returnTo;
  }

  const email = await readWorkspaceEmail(id);
  try {
    const options = await startPasskeyRegistration(
      req,
      "instance",
      id,
      email || `workspace-${id.slice(0, 8)}`,
      email || "Workspace"
    );
    const crossDeviceQr = await crossDeviceQrSvg(req, returnTo);
    return NextResponse.json({ options, ...(crossDeviceQr ? { crossDeviceQr } : {}) });
  } catch (error) {
    console.error(`POST /api/instances/${id}/passkeys failed:`, error);
    return NextResponse.json({ error: "Failed to start passkey registration" }, { status: 500 });
  }
}

export async function PUT(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, req, { permission: "settings.manage" });
  if (guard instanceof NextResponse) return guard;
  const actor = guard.principal;

  const body = await readJson(req, 200_000);
  if (!body.ok) return body.response;

  const parsed = finishSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const { name, response } = parsed.data;
  if (!response || typeof response !== "object" || !("id" in response)) {
    return NextResponse.json({ error: "Invalid registration response" }, { status: 400 });
  }

  try {
    const result = await finishPasskeyRegistration(
      req,
      "instance",
      id,
      name,
      response as RegistrationResponseJSON
    );
    if (!result.ok) {
      const message =
        result.error === "EXPIRED"
          ? "The registration window expired — try again"
          : result.error === "DUPLICATE"
            ? "This passkey is already registered"
            : "Passkey verification failed — try again";
      return NextResponse.json({ error: message, code: result.error }, { status: 400 });
    }

    await logAudit({
      actorType: actor.kind === "admin" ? "admin" : "instance",
      actorId: actor.actorId,
      actorName: maskEmail(actor.actorName),
      action: "instance.update",
      targetLabel: "workspace passkey registered",
      meta: { credential: result.id.slice(0, 12) },
    });

    return NextResponse.json({ ok: true, credentials: await listCredentials("instance", id) });
  } catch (error) {
    console.error(`PUT /api/instances/${id}/passkeys failed:`, error);
    return NextResponse.json({ error: "Failed to register passkey" }, { status: 500 });
  }
}

async function readWorkspaceEmail(instanceId: string): Promise<string> {
  const { db } = await import("@/lib/db");
  /* ROUND 87 — a trashed (soft-deleted) workspace reads as no email (the
   * session guard already rejected it; belt+suspenders). */
  const row = await db.instance.findUnique({
    where: { id: instanceId, deletedAt: null },
    select: { adminJson: true },
  });
  return readAdminEmail(row?.adminJson);
}
