import { NextResponse } from "next/server";
import { db } from "@/lib/db";

/**
 * Ashrilogic — READINESS probe (ROUND 113).
 *
 * "Should the load balancer route NEW traffic to THIS instance right
 * now?" — a different question from liveness (a live process can still
 * be mid-cutover and must not receive new writes). Verdict inputs:
 *
 *   1. DATABASE answers a trivial query within the alarm window
 *      (same bounded-ping contract as /api/healthz);
 *   2. MIGRATION PHASE: every state is documented-traffic-safe EXCEPT
 *      QUIESCING and CUTOVER — the two windows where new SQLite writes
 *      are deliberately being drained for the flip. During those the
 *      instance answers 503 NOT_READY until the state machine lands in
 *      POSTGRES_PRIMARY (or rolls back). Pre-migration schemas (the
 *      control tables absent) read as READY — a fresh deployment is not
 *      "unready" for lacking optional controller tables.
 *
 *   - Backup freshness is DELIBERATELY NOT a readiness input: a stale
 *     backup is an operational degradation (visible in /api/status and
 *     the admin ops telemetry), not a reason to shed traffic.
 *   - NO CACHING (no-store), no business data, public and anonymous.
 */
export const dynamic = "force-dynamic";

const DB_ALARM_MS = 2_000;

/** bounded DB ping: true when a trivial query resolved within the alarm */
async function dbPing(): Promise<boolean> {
  return new Promise<boolean>((resolve) => {
    const timer = setTimeout(() => resolve(false), DB_ALARM_MS);
    timer.unref?.();
    db.platformSetting
      .findFirst({ select: { id: true } })
      .then(
        () => {
          clearTimeout(timer);
          resolve(true);
        },
        () => {
          clearTimeout(timer);
          resolve(false);
        }
      );
  });
}

interface ReadinessVerdict {
  ok: boolean;
  reason?: string;
  migration?: string;
  elapsedMs: number;
}

export async function GET() {
  const started = Date.now();

  /* 1 — bounded database ping */
  if (!(await dbPing())) {
    const body: ReadinessVerdict = { ok: false, reason: "database", elapsedMs: Date.now() - started };
    return NextResponse.json(body, { status: 503, headers: { "Cache-Control": "no-store" } });
  }

  /* 2 — traffic-draining migration windows */
  let migration: string | null = null;
  try {
    const { getMigrationStatus } = await import("@/lib/server/migration/controller");
    const status = await getMigrationStatus();
    migration = status.state;
  } catch {
    /* infra tables absent (pre-migration schema) — not a readiness failure */
  }

  const draining = migration === "QUIESCING" || migration === "CUTOVER";
  const body: ReadinessVerdict = draining
    ? {
        ok: false,
        reason: "migration-draining",
        migration: migration ?? undefined,
        elapsedMs: Date.now() - started,
      }
    : { ok: true, ...(migration ? { migration } : {}), elapsedMs: Date.now() - started };
  return NextResponse.json(body, {
    status: draining ? 503 : 200,
    headers: { "Cache-Control": "no-store" },
  });
}
