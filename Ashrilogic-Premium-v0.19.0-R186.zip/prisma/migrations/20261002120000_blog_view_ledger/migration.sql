-- Blog view-dedupe ledger — the public blog's precise view counter
-- (src/lib/server/blog-views.ts).
--
-- One row per (postId, visitorKey, UTC day); the composite unique key is
-- the exactly-once guarantee: the counting transaction inserts the ledger
-- row and increments BlogPost.views together, so a repeat read from the
-- same visitor on the same UTC day rolls back on the unique violation and
-- never double-counts. `visitorKey` stores the keyed HMAC-SHA256 blind
-- index of the client IP (never the raw IP).
--
-- Backwards compatible: purely additive (new table, no column changes on
-- existing tables); existing BlogPost.views values remain the historical
-- lifetime counter and continue to grow — now deduplicated.

-- CreateTable
CREATE TABLE "BlogViewEvent" (
    "id" TEXT NOT NULL,
    "postId" TEXT NOT NULL,
    "visitorKey" TEXT NOT NULL,
    "day" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "BlogViewEvent_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "BlogViewEvent_postId_visitorKey_day_key" ON "BlogViewEvent"("postId", "visitorKey", "day");

-- CreateIndex
CREATE INDEX "BlogViewEvent_createdAt_idx" ON "BlogViewEvent"("createdAt");
