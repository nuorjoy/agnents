"use client";

import { create } from "zustand";

/**
 * Ashrilogic — ROUND 172c (performance): the landing filter bridge.
 *
 * The systems-library filter state (active category) used to be LIFTED
 * React state in the former client landing-page, shared between the
 * sectors grid (writes + smooth-scroll) and the systems library (reads +
 * chip writes). With the landing shell now a SERVER component, the two
 * interactive islands live in separate subtrees — this tiny external
 * store carries the shared filter WITHOUT re-coupling them to a common
 * client parent (zero extra hydration: both islands already hydrate).
 *
 * Identical semantics to the lifted useState: string category id,
 * "all"/"favorites" pseudo-categories included.
 *
 * ROUND 176 — the filter is now SHAREABLE: every setCat mirrors the
 * category into the URL (?cat=<id>) through history.replaceState — the
 * Next-safe URL update (the history entry's state object is preserved,
 * so client-side navigation bookkeeping stays intact; replaceState, not
 * pushState, so browsing the categories does not spam the history stack).
 * "favorites" deliberately LEAVES a clean URL: it is device-local state —
 * a shared ?cat=favorites link would land on an empty grid for everyone
 * else, and the server-side deep-link validation (src/app/page.tsx)
 * rejects it the same way.
 */
interface LandingUiState {
  activeCat: string;
  setCat: (cat: string) => void;
}

/** Mirror the active category into the URL without a navigation. */
function syncCatUrl(cat: string): void {
  if (typeof window === "undefined") return; /* SSR / non-DOM safety */
  try {
    const url = new URL(window.location.href);
    /* only real category ids are deep-linkable — "all" and the local
     * "favorites" pseudo-category both render a clean pathname */
    if (cat === "all" || cat === "favorites") {
      url.searchParams.delete("cat");
    } else {
      url.searchParams.set("cat", cat);
    }
    window.history.replaceState(window.history.state, "", url);
  } catch {
    /* URL manipulation is best-effort — a failure never breaks filtering */
  }
}

export const useLandingUi = create<LandingUiState>((set) => ({
  activeCat: "all",
  setCat: (cat) => {
    set({ activeCat: cat });
    syncCatUrl(cat);
  },
}));
